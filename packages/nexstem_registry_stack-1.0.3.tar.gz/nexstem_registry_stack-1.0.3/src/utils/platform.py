"""
Platform detection and path utilities for cross-platform compatibility
"""

import os
import sys
import platform as py_platform
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from enum import Enum

class Platform(Enum):
    WINDOWS = "windows"
    MACOS = "macos"
    LINUX = "linux"

class Architecture(Enum):
    X64 = "x64"
    X86 = "x86"
    ARM64 = "arm64"

class PlatformInfo:
    def __init__(self):
        self.os = self._detect_os()
        self.arch = self._detect_arch()
        self.lib_ext = self._get_library_extension()
        self.exe_ext = self._get_executable_extension()
        self.path_sep = os.sep
    
    def _detect_os(self) -> Platform:
        system = py_platform.system().lower()
        if system == "windows":
            return Platform.WINDOWS
        elif system == "darwin":
            return Platform.MACOS
        else:
            return Platform.LINUX
    
    def _detect_arch(self) -> Architecture:
        machine = py_platform.machine().lower()
        if machine in ["x86_64", "amd64"]:
            return Architecture.X64
        elif machine in ["i386", "i686", "x86"]:
            return Architecture.X86
        elif machine in ["arm64", "aarch64"]:
            return Architecture.ARM64
        else:
            return Architecture.X64  # Default fallback
    
    def _get_library_extension(self) -> str:
        if self.os == Platform.WINDOWS:
            return ".dll"
        elif self.os == Platform.MACOS:
            return ".dylib"
        else:
            return ".so"
    
    def _get_executable_extension(self) -> str:
        if self.os == Platform.WINDOWS:
            return ".exe"
        else:
            return ""

def get_platform_info() -> PlatformInfo:
    """Get current platform information"""
    return PlatformInfo()

def get_library_extension() -> str:
    """Get platform-specific library extension"""
    return get_platform_info().lib_ext

def get_executable_extension() -> str:
    """Get platform-specific executable extension"""
    return get_platform_info().exe_ext

def get_env_path(env_var: str, fallback: str) -> str:
    """Get path from environment variable or fallback"""
    return os.environ.get(env_var, fallback)

def resolve_library_paths() -> Dict[str, str]:
    """Resolve library paths based on platform and environment variables"""
    platform_info = get_platform_info()
    lib_ext = platform_info.lib_ext
    exe_ext = platform_info.exe_ext
    
    # Base paths from environment or defaults
    if platform_info.os == Platform.WINDOWS:
        base_path = get_env_path('REGISTRY_BASE_PATH', 'C:\\opt\\operators')
        log_dir = get_env_path('REGISTRY_LOG_DIR', 'C:\\opt\\logs')
        executor_path = get_env_path('EXECUTOR_PATH', 'C:\\Program Files\\Registry Stack\\executor_cli.exe')
        operator_registry_path = get_env_path('OPERATOR_REGISTRY_PATH', 'C:\\Program Files\\Registry Stack\\operator_registry.exe')
        pipeline_registry_path = get_env_path('PIPELINE_REGISTRY_PATH', 'C:\\Program Files\\Registry Stack\\pipeline_registry.exe')
        recorder_path = get_env_path('RECORDER_PATH', 'C:\\Program Files\\Registry Stack\\recorder.exe')
        bridge_lib_path = get_env_path('BRIDGE_LIB_PATH', 'C:\\Program Files\\Registry Stack\\executor_bridge.dll')
    else:
        base_path = get_env_path('REGISTRY_BASE_PATH', '/opt/operators')
        log_dir = get_env_path('REGISTRY_LOG_DIR', '/tmp/logs')
        executor_path = get_env_path('EXECUTOR_PATH', '/usr/local/bin/executor_cli')
        operator_registry_path = get_env_path('OPERATOR_REGISTRY_PATH', '/usr/local/bin/operator_registry')
        pipeline_registry_path = get_env_path('PIPELINE_REGISTRY_PATH', '/usr/local/bin/pipeline_registry')
        recorder_path = get_env_path('RECORDER_PATH', '/usr/local/bin/recorder')
        bridge_lib_path = get_env_path('BRIDGE_LIB_PATH', f'/usr/local/lib/registry-stack/libexecutor_bridge{lib_ext}')
    
    return {
        'executor_path': executor_path,
        'operator_registry_path': operator_registry_path,
        'pipeline_registry_path': pipeline_registry_path,
        'recorder_path': recorder_path,
        'bridge_lib_path': bridge_lib_path,
        'base_path': base_path,
        'log_directory': log_dir
    }

def file_exists(file_path: str) -> bool:
    """Check if a file exists and is accessible"""
    try:
        return Path(file_path).is_file()
    except (OSError, ValueError):
        return False

def find_first_existing_file(possible_paths: List[str]) -> Optional[str]:
    """Find the first existing file from a list of possible paths"""
    for file_path in possible_paths:
        if file_exists(file_path):
            return file_path
    return None

def get_possible_library_paths(lib_name: str) -> List[str]:
    """Get possible library paths for a given library name"""
    platform_info = get_platform_info()
    lib_ext = platform_info.lib_ext
    
    possible_paths = []
    
    # Environment variable path
    env_path = os.environ.get(f'{lib_name.upper()}_LIB_PATH')
    if env_path:
        possible_paths.append(env_path)
    
    # Standard installation paths
    if platform_info.os == Platform.WINDOWS:
        possible_paths.extend([
            f'C:\\Program Files\\Registry Stack\\{lib_name}{lib_ext}',
            f'C:\\Program Files\\Registry Stack\\lib\\{lib_name}{lib_ext}',
            f'C:\\Program Files (x86)\\Registry Stack\\{lib_name}{lib_ext}',
            f'C:\\Program Files (x86)\\Registry Stack\\lib\\{lib_name}{lib_ext}',
            f'C:\\Windows\\System32\\{lib_name}{lib_ext}',
            f'C:\\Windows\\SysWOW64\\{lib_name}{lib_ext}'
        ])
    else:
        possible_paths.extend([
            f'/usr/local/lib/registry-stack/lib{lib_name}{lib_ext}',
            f'/usr/local/lib/lib{lib_name}{lib_ext}',
            f'/usr/lib/lib{lib_name}{lib_ext}',
            f'/lib/lib{lib_name}{lib_ext}',
            f'/opt/sw-registry-stack/lib/lib{lib_name}{lib_ext}'
        ])
    
    # Development/build paths
    sw_registry_root = os.environ.get('REGISTRY_ROOT') or os.environ.get('SW_REGISTRY_ROOT')
    if sw_registry_root:
        possible_paths.extend([
            os.path.join(sw_registry_root, 'build', 'src', 'executor', 'Release', f'lib{lib_name}{lib_ext}'),
            os.path.join(sw_registry_root, 'build', 'src', 'operator_registry', 'Release', f'lib{lib_name}{lib_ext}'),
            os.path.join(sw_registry_root, 'build', 'src', 'pipeline_registry', 'Release', f'lib{lib_name}{lib_ext}'),
            os.path.join(sw_registry_root, 'build', 'src', 'recorder', 'Release', f'lib{lib_name}{lib_ext}')
        ])
    
    # Relative to current working directory
    possible_paths.extend([
        os.path.join(os.getcwd(), 'lib', f'lib{lib_name}{lib_ext}'),
        os.path.join(os.getcwd(), 'build', 'lib', f'lib{lib_name}{lib_ext}'),
        os.path.join(os.getcwd(), 'dist', 'lib', f'lib{lib_name}{lib_ext}')
    ])
    
    return [path for path in possible_paths if path]

def resolve_library_path(lib_name: str) -> Optional[str]:
    """Resolve the actual library path for a given library name"""
    possible_paths = get_possible_library_paths(lib_name)
    return find_first_existing_file(possible_paths)

def normalize_path(file_path: str) -> str:
    """Normalize path for current platform"""
    return os.path.normpath(file_path)

def join_paths(*paths: str) -> str:
    """Join paths using platform-appropriate separator"""
    return os.path.join(*paths)

def get_path_separator() -> str:
    """Get platform-specific path separator"""
    return os.sep
