import logging
import os

class DebugAwareLogger:
    def __init__(self, debug: bool = False):
        self._debug = debug
        self._logger = logging.getLogger(__name__)
        if debug:
            self._logger.setLevel(logging.DEBUG)
            if not self._logger.handlers:
                handler = logging.StreamHandler()
                formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] %(message)s')
                handler.setFormatter(formatter)
                self._logger.addHandler(handler)
        else:
            self._logger.setLevel(logging.CRITICAL) # Suppress all logs

    def debug(self, message: str, context: dict = None):
        if self._debug:
            self._logger.debug(f"{message} {context}")

    def info(self, message: str, context: dict = None):
        if self._debug:
            self._logger.info(f"{message} {context}")

    def warning(self, message: str, context: dict = None):
        if self._debug:
            self._logger.warning(f"{message} {context}")

    def error(self, message: str, context: dict = None):
        self._logger.error(f"{message} {context}")

def create_logger(debug: bool = False) -> DebugAwareLogger:
    return DebugAwareLogger(debug)
