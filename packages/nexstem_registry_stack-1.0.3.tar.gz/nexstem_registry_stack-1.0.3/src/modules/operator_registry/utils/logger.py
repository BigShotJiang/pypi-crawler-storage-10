"""
Custom logger for Operator Registry that respects debug configuration.

This module provides a logger factory that respects the debug setting,
hiding all logs when debug=False and showing all logs when debug=True.
"""

import logging
from typing import Optional


class DebugAwareLogger:
    """Logger that respects debug configuration."""
    
    def __init__(self, debug: bool = False):
        """
        Initialize logger with debug configuration.
        
        Args:
            debug: Whether to show debug logs
        """
        self._debug = debug
        self._logger = logging.getLogger(__name__)
        
        # Configure logging level based on debug setting
        if debug:
            self._logger.setLevel(logging.DEBUG)
            # Add a console handler if none exists
            if not self._logger.handlers:
                handler = logging.StreamHandler()
                formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] %(message)s')
                handler.setFormatter(formatter)
                self._logger.addHandler(handler)
        else:
            self._logger.setLevel(logging.CRITICAL)  # Suppress all logs
    
    def debug(self, message: str, *args, **kwargs) -> None:
        """Log debug message only if debug is enabled."""
        if self._debug:
            self._logger.debug(message, *args, **kwargs)
    
    def info(self, message: str, *args, **kwargs) -> None:
        """Log info message only if debug is enabled."""
        if self._debug:
            self._logger.info(message, *args, **kwargs)
    
    def warning(self, message: str, *args, **kwargs) -> None:
        """Log warning message only if debug is enabled."""
        if self._debug:
            self._logger.warning(message, *args, **kwargs)
    
    def error(self, message: str, *args, **kwargs) -> None:
        """Log error message only if debug is enabled."""
        if self._debug:
            self._logger.error(message, *args, **kwargs)


def create_logger(debug: bool = False) -> DebugAwareLogger:
    """
    Create a logger that respects debug configuration.
    
    Args:
        debug: Whether to show debug logs
        
    Returns:
        Logger instance
    """
    return DebugAwareLogger(debug)
