"""
Signal service implementation for Executor.

This module provides the signal service for sending signals to pipeline instances.
"""

import asyncio
import json
import logging
from typing import Optional, Dict, Any
from pathlib import Path
import sys

# Add the src directory to the path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from modules.executor.dto import ExecutorSignalOptions, PipelineSignalResponse
from modules.executor.bridge import ExecutorBridge
from shared.dto.common import ResponseStatus

logger = logging.getLogger(__name__)


class SignalService:
    """Service for sending signals to pipeline instances."""
    
    def __init__(self, bridge_lib_path: str):
        """Initialize the signal service.
        
        Args:
            bridge_lib_path: Path to the executor bridge library
        """
        self.bridge = ExecutorBridge(bridge_lib_path)
        self._is_initialized = False
    
    async def initialize(self) -> None:
        """Initialize the signal service."""
        if not self._is_initialized:
            self.bridge.load()
            self._is_initialized = True
    
    async def signal_pipeline(
        self,
        base_path: str,
        run_id: str,
        signal: str,
        options: ExecutorSignalOptions
    ) -> PipelineSignalResponse:
        """Send a signal to a pipeline instance.
        
        Args:
            base_path: Base path for the executor
            run_id: Pipeline run ID
            signal: Signal to send
            options: Signal options
            
        Returns:
            PipelineSignalResponse: Signal response
        """
        try:
            logger.debug("SignalService.signal_pipeline: starting operation", {
                "base_path": base_path,
                "run_id": run_id,
                "signal": signal,
                "options": options.model_dump() if options else None
            })
            
            # Call the bridge to send the signal
            result = await self.bridge.signal(
                base_path=base_path,
                run_id=run_id,
                signal=signal
            )
            
            logger.debug("SignalService.signal_pipeline: bridge response received", {
                "result": result
            })
            
            return result
        except Exception as e:
            logger.error(f"SignalService.signal_pipeline: error", {
                "base_path": base_path,
                "run_id": run_id,
                "signal": signal,
                "options": options.model_dump() if options else None,
                "error": str(e)
            })
            return PipelineSignalResponse(
                status=ResponseStatus.ERROR,
                message="Failed to send signal to pipeline",
                data=None,
                error={"message": str(e), "type": "execution_error"}
            )
    
    async def close(self) -> None:
        """Close the signal service."""
        if self._is_initialized:
            self.bridge.unload()
            self._is_initialized = False
