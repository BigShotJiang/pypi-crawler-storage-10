from prefect.blocks.core import Block
from langchain.agents import create_agent
from src.dochain.block.openapi_block import OpenAPIBlock
from src.dochain.block.prompt import PromptBlock



class AgentConnBlock(Block):
    _block_type_name = "LangChain Agent"
    _block_type_icon = "🤖"

    openai_block: str                       # 连接块名称
    prompt_block: str                       # 提示词块名称
    tools: List[ToolItem]                   # 工具列表
    temperature: float = 0
    max_iter: int = 5

    def get_agent(self):
        # 只组装，不 invoke
        llm   = OpenAPIBlock.load(self.openai_block).get_langchain_ChatOpenAI()
        prompt= PromptBlock.load(self.prompt_block).render()
        tools = [ToolItem.load(tool) for tool in self.tools]
        return create_agent(llm, tools, prompt)

    def test(self) -> str:
        # 仅一句问候，<3 s
        agent = self.get_agent()
        ans = agent.invoke({"input": "Hi"}, max_iterations=1)
        return f"✅ {ans['output'][:20]}…"
