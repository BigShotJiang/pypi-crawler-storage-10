from prefect.blocks.core import Block
from pydantic import Field
from jinja2 import Template, meta

class PromptBlock(Block):
    _block_type_name = "Prompt Template"
    _logo_url = "https://cdn-icons-png.flaticon.com/512/2920/2920277.png"

    template: str = Field(..., description="Jinja2 模板（留 {{var}} 占位）")
    role: str = Field("system", description="system / user / assistant")
    version: str = Field("v1", description="人工标签，方便回滚")
    desc: str = Field("", description="用途说明（UI 提示）")

    def render(self, **kwargs) -> str:
        """渲染模板，变量缺失会抛异常"""
        return Template(self.template).render(**kwargs)

    def inspect_vars(self) -> list[str]:
        """返回模板里所有 {{var}} 列表，便于前端校验"""
        return list(meta.find_variables(Template(self.template).parse()))

    def test(self) -> str:
        try:
            dummy = self.render()  # 无变量渲染
            return f"✅ valid, vars={self.inspect_vars()}"
        except Exception as e:
            return f"❌ {e}"
