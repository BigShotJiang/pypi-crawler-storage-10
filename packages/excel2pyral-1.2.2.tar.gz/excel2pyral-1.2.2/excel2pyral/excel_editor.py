import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter, column_index_from_string
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
import os
import sys
import time
import json
import argparse
from datetime import datetime
from typing import Any, Dict, List, Optional, Callable, Union
from dataclasses import dataclass
from enum import Enum

# Global debug flag - controlled by command-line argument
DEBUG = False

def debug_print(*args, **kwargs):
    """Print debug messages only if DEBUG flag is enabled"""
    if DEBUG:
        print(*args, **kwargs)

try:
    import tksheet
    TKSHEET_AVAILABLE = True
except ImportError:
    TKSHEET_AVAILABLE = False
    debug_print("Warning: tksheet not available. Install with: pip install tksheet")

# ========================================
# HYBRID UNDO/REDO SYSTEM IMPLEMENTATION
# ========================================

class OperationType(Enum):
    """Categories of operations for routing to appropriate undo system"""
    TKSHEET_CELL = "tksheet_cell"        # Cell value changes, basic formatting
    TKSHEET_SELECTION = "tksheet_selection"  # Selection changes
    CUSTOM_FILE = "custom_file"          # File operations
    CUSTOM_SHEET = "custom_sheet"        # Sheet management
    CUSTOM_STRUCTURE = "custom_structure"  # Row/column operations
    CUSTOM_EXCEL = "custom_excel"        # Excel-specific features

@dataclass
class UndoOperation:
    """Represents an undo operation"""
    operation_type: OperationType
    description: str
    undo_data: Dict[str, Any]
    redo_data: Dict[str, Any]
    timestamp: float

class HybridUndoManager:
    """
    Hybrid Undo/Redo Manager that coordinates between tksheet's built-in undo/redo
    and our custom implementation for optimal performance and functionality.
    """
    
    def __init__(self, excel_editor, sheet=None, max_undo_levels: int = 50):
        self.excel_editor = excel_editor
        self.sheet = sheet
        self.max_undo_levels = max_undo_levels
        
        # Custom undo/redo stacks for Excel-specific operations
        self.custom_undo_stack: List[UndoOperation] = []
        self.custom_redo_stack: List[UndoOperation] = []
        
        # Track which system last performed an operation
        self.last_operation_type: Optional[OperationType] = None
        
        # Operation routing rules
        self.tksheet_operations = {
            OperationType.TKSHEET_CELL,
            OperationType.TKSHEET_SELECTION
        }
        
        self.custom_operations = {
            OperationType.CUSTOM_FILE,
            OperationType.CUSTOM_SHEET,
            OperationType.CUSTOM_STRUCTURE,
            OperationType.CUSTOM_EXCEL
        }
        
        # Configuration
        self.tksheet_undo_enabled = True
        
        debug_print("🔄 Hybrid Undo/Redo Manager initialized")
        debug_print(f"   Max undo levels: {max_undo_levels}")
        debug_print(f"   tksheet operations: {[op.value for op in self.tksheet_operations]}")
        debug_print(f"   Custom operations: {[op.value for op in self.custom_operations]}")
    
    def can_undo(self) -> bool:
        """Check if any undo operation is available"""
        tksheet_can_undo = self._can_tksheet_undo()
        custom_can_undo = len(self.custom_undo_stack) > 0
        return tksheet_can_undo or custom_can_undo
    
    def can_redo(self) -> bool:
        """Check if any redo operation is available"""
        tksheet_can_redo = self._can_tksheet_redo()
        custom_can_redo = len(self.custom_redo_stack) > 0
        return tksheet_can_redo or custom_can_redo
    
    def _can_tksheet_undo(self) -> bool:
        """Check if tksheet has undo operations available"""
        if not self.tksheet_undo_enabled or not self.sheet:
            return False
        try:
            # Check if tksheet has undo capability
            return hasattr(self.sheet, 'undo') and callable(getattr(self.sheet, 'undo'))
        except:
            return False
    
    def _can_tksheet_redo(self) -> bool:
        """Check if tksheet has redo operations available"""
        if not self.tksheet_undo_enabled or not self.sheet:
            return False
        try:
            return hasattr(self.sheet, 'redo') and callable(getattr(self.sheet, 'redo'))
        except:
            return False
    
    def undo(self) -> bool:
        """Unified undo operation that routes to appropriate undo system"""
        debug_print("\n🔄 HYBRID UNDO: Starting undo operation")
        
        # Strategy: Try custom undo first, then tksheet as fallback
        if self.custom_undo_stack:
            debug_print("   📝 Trying custom undo")
            return self._custom_undo()
        elif self._can_tksheet_undo():
            debug_print("   🔄 Trying tksheet undo")
            return self._tksheet_undo()
        
        debug_print("   ❌ No undo operations available")
        return False
    
    def redo(self) -> bool:
        """Unified redo operation that routes to appropriate redo system"""
        debug_print("\n🔄 HYBRID REDO: Starting redo operation")
        
        # Strategy: Try custom redo first, then tksheet as fallback
        if self.custom_redo_stack:
            debug_print("   📝 Trying custom redo")
            return self._custom_redo()
        elif self._can_tksheet_redo():
            debug_print("   🔄 Trying tksheet redo")
            return self._tksheet_redo()
        
        debug_print("   ❌ No redo operations available")
        return False
    
    def _tksheet_undo(self) -> bool:
        """Perform tksheet undo operation"""
        if not self.sheet or not self._can_tksheet_undo():
            return False
        
        try:
            debug_print("      🔄 Executing tksheet undo")
            result = self.sheet.undo()
            
            if result:
                # Sync tksheet changes back to Excel workbook
                self._sync_tksheet_to_excel()
                self.last_operation_type = OperationType.TKSHEET_CELL
                debug_print("      ✅ tksheet undo successful")
                return True
            return False
        except Exception as e:
            debug_print(f"      ❌ tksheet undo failed: {e}")
            return False
    
    def _tksheet_redo(self) -> bool:
        """Perform tksheet redo operation"""
        if not self.sheet or not self._can_tksheet_redo():
            return False
        
        try:
            debug_print("      🔄 Executing tksheet redo")
            result = self.sheet.redo()
            
            if result:
                # Sync tksheet changes back to Excel workbook
                self._sync_tksheet_to_excel()
                self.last_operation_type = OperationType.TKSHEET_CELL
                debug_print("      ✅ tksheet redo successful")
                return True
            return False
        except Exception as e:
            debug_print(f"      ❌ tksheet redo failed: {e}")
            return False
    
    def _sync_tksheet_to_excel(self):
        """Sync tksheet data back to Excel workbook after tksheet operations"""
        if not self.excel_editor or not self.sheet:
            return
        
        try:
            debug_print("      🔄 Syncing tksheet data to Excel workbook")
            data = self.sheet.get_sheet_data()
            
            # Clear existing data in worksheet
            ws = self.excel_editor.ws
            for row in ws.iter_rows():
                for cell in row:
                    cell.value = None
            
            # Write tksheet data to worksheet
            for row_idx, row_data in enumerate(data, start=1):
                for col_idx, cell_value in enumerate(row_data, start=1):
                    if cell_value:  # Only write non-empty values
                        ws.cell(row_idx, col_idx, cell_value)
            
            debug_print("      ✅ Sync completed successfully")
        except Exception as e:
            debug_print(f"      ❌ Error syncing tksheet to Excel: {e}")
    
    def _custom_undo(self) -> bool:
        """Perform custom undo operation using legacy implementation"""
        if not self.custom_undo_stack:
            return False
        
        try:
            operation = self.custom_undo_stack.pop()
            debug_print(f"      📝 Executing custom undo: {operation.description}")
            
            # Execute the actual undo logic using legacy system
            if self.excel_editor and hasattr(self.excel_editor, '_execute_legacy_undo'):
                # Convert operation type back to legacy action type
                # Pass the description from the operation object
                legacy_action_type = self._operation_type_to_legacy_action(
                    operation.operation_type, 
                    operation.undo_data,
                    operation.description  # Pass description from operation
                )
                legacy_action = (legacy_action_type, operation.undo_data)
                success = self.excel_editor._execute_legacy_undo(legacy_action)
                
                if success:
                    # Move to redo stack only if undo was successful
                    self.custom_redo_stack.append(operation)
                    self.last_operation_type = operation.operation_type
                    debug_print(f"      ✅ Custom undo successful: {operation.description}")
                    return True
                else:
                    # Put it back on the undo stack if it failed
                    self.custom_undo_stack.append(operation)
                    debug_print(f"      ❌ Custom undo failed: {operation.description}")
                    return False
            else:
                # Fallback: just move to redo stack and update display
                self.custom_redo_stack.append(operation)
                self.last_operation_type = operation.operation_type
                
                # Update Excel editor display
                if self.excel_editor:
                    self.excel_editor.update_display()
                
                debug_print(f"      ✅ Custom undo successful (display only): {operation.description}")
                return True
            
        except Exception as e:
            debug_print(f"      ❌ Custom undo error: {e}")
            return False
    
    def _custom_redo(self) -> bool:
        """Perform custom redo operation using legacy implementation"""
        if not self.custom_redo_stack:
            return False
        
        try:
            operation = self.custom_redo_stack.pop()
            debug_print(f"      📝 Executing custom redo: {operation.description}")
            
            # Execute the actual redo logic using legacy system
            if self.excel_editor and hasattr(self.excel_editor, '_execute_legacy_redo'):
                # Convert operation type back to legacy action type
                # CRITICAL FIX: Pass description from operation object for proper detection
                legacy_action_type = self._operation_type_to_legacy_action(
                    operation.operation_type, 
                    operation.redo_data, 
                    operation.description,  # Pass description from operation
                    is_redo=True
                )
                legacy_action = (legacy_action_type, operation.redo_data)
                success = self.excel_editor._execute_legacy_redo(legacy_action)
                
                if success:
                    # Move back to undo stack only if redo was successful
                    self.custom_undo_stack.append(operation)
                    self.last_operation_type = operation.operation_type
                    debug_print(f"      ✅ Custom redo successful: {operation.description}")
                    return True
                else:
                    # Put it back on the redo stack if it failed
                    self.custom_redo_stack.append(operation)
                    debug_print(f"      ❌ Custom redo failed: {operation.description}")
                    return False
            else:
                # Fallback: just move to undo stack and update display
                self.custom_undo_stack.append(operation)
                self.last_operation_type = operation.operation_type
                
                # Update Excel editor display
                if self.excel_editor:
                    self.excel_editor.update_display()
                
                debug_print(f"      ✅ Custom redo successful (display only): {operation.description}")
                return True
            
        except Exception as e:
            debug_print(f"      ❌ Custom redo error: {e}")
            return False
    
    def add_custom_operation(self, operation_type: OperationType, 
                           description: str, undo_data: Dict[str, Any] = None, 
                           redo_data: Dict[str, Any] = None) -> None:
        """Add a custom operation to the undo stack"""
        operation = UndoOperation(
            operation_type=operation_type,
            description=description,
            undo_data=undo_data or {},
            redo_data=redo_data or {},
            timestamp=time.time()
        )
        
        self.custom_undo_stack.append(operation)
        
        # Clear redo stack when new operation is added
        self.custom_redo_stack.clear()
        
        # Maintain stack size limit
        if len(self.custom_undo_stack) > self.max_undo_levels:
            self.custom_undo_stack.pop(0)
        
        self.last_operation_type = operation_type
        debug_print(f"   ➕ Added custom operation: {description}")
    
    def notify_tksheet_operation(self, operation_type: OperationType) -> None:
        """Notify the manager that a tksheet operation occurred"""
        self.last_operation_type = operation_type
        debug_print(f"   🔔 Notified of tksheet operation: {operation_type.value}")
    
    def _operation_type_to_legacy_action(self, operation_type: OperationType, data: Dict[str, Any], description: str = '', is_redo: bool = False) -> str:
        """Convert hybrid operation type back to legacy action type"""
        if operation_type == OperationType.CUSTOM_SHEET:
            # Check data to determine specific sheet action
            if 'sheet_name' in data:
                if 'was_active' in data:  # Sheet deletion
                    # For redo of sheet deletion, we want to delete again
                    return 'sheet_delete'
                elif 'old_name' in data:  # Sheet rename
                    return 'sheet_rename'
                else:  # Sheet addition
                    return 'sheet_add'
            return 'sheet_switch'
        
        elif operation_type == OperationType.CUSTOM_STRUCTURE:
            # Check data to determine specific structure action
            # CRITICAL FIX: Check 'operation' field in data FIRST (most reliable)
            operation_field = data.get('operation', '')
            debug_print(f"     🔍 LEGACY ACTION DEBUG: operation field = '{operation_field}'")
            
            # If operation field is present, use it directly (most reliable)
            if operation_field:
                debug_print(f"     ✅ LEGACY ACTION: Using operation field: '{operation_field}'")
                return operation_field
            
            # Fallback: Use description parameter passed from operation object
            desc_to_check = description or data.get('description', '')
            debug_print(f"     🔍 LEGACY ACTION DEBUG: description (param) = '{description}'")
            debug_print(f"     🔍 LEGACY ACTION DEBUG: description (from data) = '{data.get('description', '')}'")
            debug_print(f"     🔍 LEGACY ACTION DEBUG: desc_to_check = '{desc_to_check}'")
            
            if 'insert_position' in data or 'column_index' in data or 'row_number' in data:
                # Determine if it's a row or column operation based on description
                desc_lower = desc_to_check.lower()
                debug_print(f"     🔍 LEGACY ACTION DEBUG: desc_lower = '{desc_lower}'")
                
                if 'column' in desc_lower or 'col' in desc_lower:
                    if 'delete' in desc_lower:
                        debug_print(f"     ✅ LEGACY ACTION: Returning 'column_delete'")
                        return 'column_delete'
                    else:
                        debug_print(f"     ✅ LEGACY ACTION: Returning 'column_insert'")
                        return 'column_insert'
                else:
                    if 'delete' in desc_lower:
                        debug_print(f"     ✅ LEGACY ACTION: Returning 'row_delete'")
                        return 'row_delete'
                    else:
                        debug_print(f"     ✅ LEGACY ACTION: Returning 'row_insert'")
                        return 'row_insert'
            else:
                # No insert_position, column_index, or row_number - default to row_insert
                debug_print(f"     ⚠️ LEGACY ACTION: No position data found, defaulting to 'row_insert'")
                return 'row_insert'
        
        elif operation_type == OperationType.CUSTOM_EXCEL:
            # Check data to determine specific Excel action
            if 'affected_cells' in data:
                # Check if it's a paste operation (including cut_clear)
                if 'type' in data and data['type'] in ['fill_columns', 'fill_rows', 'range', 'fill', 'rows', 'columns', 'cut_clear']:
                    return 'paste_operation'
            # Check for find/replace operations by looking at description string
            desc_to_check = (description or data.get('description', '')).lower()
            if 'replace_single' in desc_to_check or ('find_value' in data and 'cell' in data and 'changes' not in data):
                return 'replace_single'
            elif 'replace_all' in desc_to_check or ('find_value' in data and 'changes' in data):
                return 'replace_all'
            elif 'find_value' in data:
                return 'find_replace'
            else:
                return 'format_change'  # Default fallback
        
        elif operation_type == OperationType.CUSTOM_FILE:
            return 'file_operation'
        
        else:
            # For tksheet operations, return a generic type
            return 'cell_edit'
    
    def get_status(self) -> Dict[str, Any]:
        """Get current status of both undo systems"""
        return {
            "can_undo": self.can_undo(),
            "can_redo": self.can_redo(),
            "custom_undo_count": len(self.custom_undo_stack),
            "custom_redo_count": len(self.custom_redo_stack),
            "tksheet_undo_available": self._can_tksheet_undo(),
            "tksheet_redo_available": self._can_tksheet_redo(),
            "last_operation_type": self.last_operation_type.value if self.last_operation_type else None,
            "tksheet_integration_enabled": self.tksheet_undo_enabled
        }

# ========================================
# END OF HYBRID UNDO/REDO SYSTEM
# ========================================

class ExcelEditorGUI:
    def __init__(self, master, path=None):
        self.master = master
        self.master.geometry("1100x700")  # Smaller initial size for 14-inch laptops
        
        # Track unsaved changes (initialize before update_window_title)
        self.has_unsaved_changes = False
        
        self.path = path
        self.update_window_title()
        # Legacy undo/redo stacks - maintained for compatibility
        self.undo_stack = []
        self.max_undo_stack = 50  # Limit undo history to prevent memory issues
        self.redo_stack = []
        self.max_redo_stack = 10  # Limit redo history to 10 levels as requested
        
        # Initialize hybrid undo/redo manager (will be set up after tksheet is created)
        self.hybrid_undo_manager = None
        
        # Add sync protection to prevent duplicate undo entries
        self.sync_in_progress = False
        
        # Add cell editing session tracking for proper undo behavior
        self.current_edit_session = None  # Track current cell being edited
        self.edit_timer = None  # Timer for debounced undo creation
        self.edit_debounce_delay = 2000  # 2 second delay - should be enough time for user to finish typing
        self.last_edited_cell = None  # Track which cell was last edited
        
        # Auto-save functionality - DISABLED
        self.auto_save_enabled = False  # DISABLED - auto-save removed
        self.auto_save_interval = 1000  # Not used anymore
        self.auto_save_timer = None
        self.last_save_time = time.time()
        
        # Recent files functionality
        self.recent_files = []
        self.max_recent_files = 10
        self.settings_file = os.path.expanduser("~/.excel_editor_settings.json")
        self.load_settings()
        
        # Visual themes and styling
        self.current_theme = "light"  # light, dark
        self.zoom_level = 1.0
        self.show_grid_lines = True
        self.formula_bar_visible = False  # Formula bar disabled
        
        # Initialize icons (using Unicode symbols for cross-platform compatibility)
        self.icons = {
            'save': '💾',
            'open': '📁', 
            'new': '📄',
            'undo': '↶',
            'redo': '↷',
            'copy': '📋',
            'paste': '📌',
            'cut': '✂️',
            'find': '🔍',
            'zoom_in': '🔍+',
            'zoom_out': '🔍-',
            'border': '⊞',
            'auto_save': '⚡',
            'recent': '🕒'
        }
        
        # Copy/paste tracking variables
        self._copy_type = 'cells'  # 'cells', 'rows', 'columns'
        self._copied_data = []
        self._copied_rows = []
        self._copied_cols = []
        self._is_cut = False  # Track if operation is cut (not copy)
        self._cut_cells = []  # Store cells to clear after paste
        
        # Load or create workbook
        if path and os.path.exists(path):
            self.wb = load_workbook(path)
        else:
            self.wb = Workbook()
            self.initialize_empty_workbook()
        self.ws = self.wb.active
        
        self.setup_ui()
        self.update_display()
        # Auto-save disabled - removed self.start_auto_save_timer()
        debug_print(" Auto-save DISABLED - user must save manually with Ctrl+S")
        
        # Force initial toolbar sizing check after window is realized
        # This ensures proper sizing when app starts
        self.master.after(100, self._initial_toolbar_sizing)
    
    def initialize_empty_workbook(self, rows=500, cols=500):
        """Initialize a new workbook - DON'T pre-populate cells!
        
        CRITICAL: We DON'T write empty cells to the workbook anymore.
        This was causing huge files and slow reopening because:
        - Writing 500x500 = 250,000 empty cells
        - max_row/max_column set to 500
        - Reopening tries to load all 250,000 cells = HANG!
        
        Instead, let tksheet handle the visual grid display.
        The workbook only stores actual data cells.
        """
        # Don't populate with empty cells - let tksheet display empty grid visually
        debug_print(f" Initialized new workbook (visual grid: {rows}x{cols}, actual cells: 0)")
    
    def update_window_title(self):
        """Update the window title to show the current file name"""
        unsaved_marker = "*" if self.has_unsaved_changes else ""
        if self.path:
            filename = os.path.basename(self.path)
            self.master.title(f"Excel Editor ({filename}){unsaved_marker}")
        else:
            self.master.title(f"Excel Editor (untitled){unsaved_marker}")
    
    def load_settings(self):
        """Load application settings from file"""
        try:
            if os.path.exists(self.settings_file):
                with open(self.settings_file, 'r') as f:
                    settings = json.load(f)
                    self.recent_files = settings.get('recent_files', [])
                    self.auto_save_enabled = settings.get('auto_save_enabled', True)
                    self.auto_save_interval = settings.get('auto_save_interval', 1000)  # Changed to 1 second for testing
                    self.current_theme = settings.get('theme', 'light')
                    self.zoom_level = settings.get('zoom_level', 1.0)
                    self.show_grid_lines = settings.get('show_grid_lines', True)
                    self.formula_bar_visible = settings.get('formula_bar_visible', True)
                debug_print(f" Settings loaded from: {self.settings_file}")
            else:
                # First run - create settings file with defaults
                debug_print(f"️ Settings file not found. Creating new settings file: {self.settings_file}")
                self.save_settings()
                debug_print(f" Settings file created with default values")
        except Exception as e:
            debug_print(f"Error loading settings: {e}")
    
    def save_settings(self):
        """Save application settings to file"""
        try:
            settings = {
                'recent_files': self.recent_files,
                'auto_save_enabled': self.auto_save_enabled,
                'auto_save_interval': self.auto_save_interval,
                'theme': self.current_theme,
                'zoom_level': self.zoom_level,
                'show_grid_lines': self.show_grid_lines,
                'formula_bar_visible': self.formula_bar_visible
            }
            with open(self.settings_file, 'w') as f:
                json.dump(settings, f, indent=2)
        except Exception as e:
            debug_print(f"Error saving settings: {e}")
    
    def add_to_recent_files(self, file_path):
        """Add a file to the recent files list"""
        if file_path in self.recent_files:
            self.recent_files.remove(file_path)
        self.recent_files.insert(0, file_path)
        if len(self.recent_files) > self.max_recent_files:
            self.recent_files = self.recent_files[:self.max_recent_files]
        self.save_settings()
    
    def start_auto_save_timer(self):
        """Start the auto-save timer - DISABLED"""
        debug_print(" Auto-save timer DISABLED - no auto-save will occur")
        return  # Auto-save completely disabled
    
    def auto_save(self):
        """Perform auto-save if file has been modified - DISABLED"""
        debug_print(" Auto-save DISABLED - function will not execute")
        return  # Auto-save completely disabled
    
    def setup_ui(self):
        # Menu Bar
        menubar = tk.Menu(self.master)
        self.master.config(menu=menubar)
        
        # File Menu
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label=f"{self.icons['new']} New", command=self.new_file, accelerator="Ctrl+N")
        file_menu.add_command(label=f"{self.icons['open']} Open", command=self.load_file, accelerator="Ctrl+O")
        
        # Recent Files submenu
        self.recent_menu = tk.Menu(file_menu, tearoff=0)
        file_menu.add_cascade(label=f"{self.icons['recent']} Recent Files", menu=self.recent_menu)
        self.update_recent_files_menu()
        
        file_menu.add_separator()
        file_menu.add_command(label=f"{self.icons['save']} Save", command=self.save, accelerator="Ctrl+S")
        file_menu.add_command(label="Save As...", command=self.save_as, accelerator="Ctrl+Shift+S")
        file_menu.add_separator()
        # Auto-save removed - users must save manually
        file_menu.add_command(label="Exit", command=self.on_closing)
        
        # Sheet Menu
        sheet_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Sheet", menu=sheet_menu)
        sheet_menu.add_command(label="List Sheets", command=self.list_sheets)
        sheet_menu.add_command(label="Add Sheet", command=self.add_sheet)
        sheet_menu.add_command(label="Rename Sheet", command=self.rename_sheet)
        sheet_menu.add_command(label="Delete Sheet", command=self.delete_sheet)
        
        # Edit Menu
        edit_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Edit", menu=edit_menu)
        edit_menu.add_command(label=f"{self.icons['undo']} Undo", command=self.undo, accelerator="Ctrl+Z")
        edit_menu.add_command(label=f"{self.icons['redo']} Redo", command=self.redo, accelerator="Ctrl+Y")
        edit_menu.add_separator()
        edit_menu.add_command(label=f"{self.icons['copy']} Copy", command=self.copy_selection, accelerator="Ctrl+C")
        edit_menu.add_command(label=f"{self.icons['cut']} Cut", command=self.cut_selection, accelerator="Ctrl+X")
        edit_menu.add_command(label=f"{self.icons['paste']} Paste", command=self.paste_selection, accelerator="Ctrl+V")
        edit_menu.add_separator()
        edit_menu.add_command(label="Clear Cell", command=self.clear_cell, accelerator="Delete")
        edit_menu.add_command(label="Edit Cell (Dialog)", command=self.edit_cell_dialog, accelerator="F2")
        edit_menu.add_separator()
        edit_menu.add_command(label="Select All", command=self.select_all, accelerator="Ctrl+A")
        edit_menu.add_separator()
        edit_menu.add_command(label="Show Undo Stack", command=self.show_undo_stack)
        edit_menu.add_command(label="Clear Undo History", command=self.clear_undo_history)
        
        # View Menu
        view_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="View", menu=view_menu)
        view_menu.add_command(label=f"{self.icons['zoom_in']} Zoom In", command=self.zoom_in, accelerator="Ctrl++")
        view_menu.add_command(label=f"{self.icons['zoom_out']} Zoom Out", command=self.zoom_out, accelerator="Ctrl+-")
        view_menu.add_command(label="Reset Zoom", command=self.reset_zoom, accelerator="Ctrl+0")
        
        # Search Menu
        search_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Search", menu=search_menu)
        search_menu.add_command(label=f"{self.icons['find']} Find Value", command=self.find_value, accelerator="Ctrl+F")
        search_menu.add_command(label="Find and Replace", command=self.find_and_replace, accelerator="Ctrl+H")
        search_menu.add_separator()
        search_menu.add_command(label="Go to Cell", command=self.go_to_cell, accelerator="Ctrl+G")
        search_menu.add_command(label="Read Cell", command=self.read_cell)
        
        # Help Menu
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="Keyboard Shortcuts", command=self.show_keyboard_shortcuts)
        help_menu.add_command(label="About", command=self.show_about)
        
        # Enhanced Toolbar with icons
        self.setup_enhanced_toolbar()
        
        # Context-sensitive row/column operations
        self.setup_context_operations()
        
        # Info label - simplified to avoid font rendering issues
        info_frame = ttk.Frame(self.master)
        info_frame.pack(side="top", fill="x", padx=5, pady=(0, 5))
        ttk.Label(info_frame, text="Tip: Double-click cells to edit directly. Use Ctrl+Z to undo, Ctrl+Y to redo operations", 
                  foreground="blue", font=("Arial", 9)).pack(side="left", padx=5)
        
        # Status Bar with colored selected cell
        self.status_frame = ttk.Frame(self.master, relief=tk.SUNKEN, padding=2)
        self.status_frame.pack(side="bottom", fill="x")
        
        # Main status text (sheet info, etc.)
        self.status_main = ttk.Label(self.status_frame, text="Ready", anchor=tk.W)
        self.status_main.pack(side="left", fill="x", expand=True)
        
        # Selected cell info with separate label and value
        self.status_selected = ttk.Label(self.status_frame, text="None", foreground="green", font=("Arial", 9, "bold"))
        self.status_selected.pack(side="right", padx=(0, 5))
        ttk.Label(self.status_frame, text="Selected:", foreground="blue").pack(side="right", padx=(10, 2))
        
        # Sheet tabs section at bottom (like Excel)
        self.setup_sheet_tabs()
        
        # Main Content Area
        if TKSHEET_AVAILABLE:
            self.setup_tksheet()
        else:
            # Fallback to Treeview if tksheet not available
            self.setup_treeview()
        
        # Keyboard shortcuts - enhanced Excel-like shortcuts with proper event handling
        self.setup_keyboard_shortcuts()
        
        # Global click handler to dismiss any open context menus
        self.master.bind('<Button-1>', self.on_global_click, add="+")
        
        # Bind window closing event
        self.master.protocol("WM_DELETE_WINDOW", self.on_closing)
        
        # Bind window resize event for responsive toolbar - CRITICAL for multi-monitor
        self.master.bind('<Configure>', self.on_window_resize, add="+")
        
        # Initialize context menu tracking
        self.active_context_menu = None
    
    def setup_keyboard_shortcuts(self):
        """Setup keyboard shortcuts with proper event handling"""
        # Define shortcuts with proper event handling functions
        shortcuts = {
            # File operations
            '<Control-n>': self._handle_new_file,
            '<Control-N>': self._handle_new_file,
            '<Control-s>': self._handle_save,
            '<Control-S>': self._handle_save,
            '<Control-o>': self._handle_open,
            '<Control-O>': self._handle_open,
            '<Control-Shift-S>': self._handle_save_as,
            '<Control-Shift-s>': self._handle_save_as,
            
            # Edit operations
            '<Control-z>': self._handle_undo,
            '<Control-Z>': self._handle_undo,
            '<Control-y>': self._handle_redo,
            '<Control-Y>': self._handle_redo,
            '<Control-Shift-Z>': self._handle_redo,
            '<Control-Shift-z>': self._handle_redo,
            
            # Clipboard operations (only if not handled by tksheet)
            '<Control-c>': self._handle_copy,
            '<Control-C>': self._handle_copy,
            '<Control-x>': self._handle_cut,
            '<Control-X>': self._handle_cut,
            '<Control-v>': self._handle_paste,
            '<Control-V>': self._handle_paste,
            '<Control-a>': self._handle_select_all,
            '<Control-A>': self._handle_select_all,
            
            # Navigation
            '<Control-f>': self._handle_find,
            '<Control-F>': self._handle_find,
            '<Control-h>': self._handle_replace,
            '<Control-H>': self._handle_replace,
            '<Control-g>': self._handle_goto,
            '<Control-G>': self._handle_goto,
            
            # View operations - multiple key combinations for zoom
            '<Control-equal>': self._handle_zoom_in,
            '<Control-plus>': self._handle_zoom_in,
            '<Control-KP_Add>': self._handle_zoom_in,
            '<Control-minus>': self._handle_zoom_out,
            '<Control-KP_Subtract>': self._handle_zoom_out,
            '<Control-0>': self._handle_reset_zoom,
            '<Control-KP_0>': self._handle_reset_zoom,
            
            # Function keys
            '<F2>': self._handle_edit_cell,
            '<Delete>': self._handle_delete,
            '<BackSpace>': self._handle_delete,
        }
        
        # Bind all shortcuts to both master window and table (if available)
        for key_combo, handler in shortcuts.items():
            try:
                # Bind to main window
                self.master.bind(key_combo, handler)
                
                # For tksheet, we need to explicitly bind copy/paste/cut shortcuts
                # since we disabled tksheet's built-in versions
                # CRITICAL: DON'T bind Delete/Backspace to table - let tksheet handle them natively during edit
                if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                    if key_combo not in ['<Delete>', '<BackSpace>']:
                        # Bind directly to the table widget to ensure our handlers are called
                        self.table.bind(key_combo, handler, add='+')
                    
            except Exception as e:
                debug_print(f"Warning: Could not bind shortcut {key_combo}: {e}")
    
    # Keyboard shortcut handler methods
    def _handle_new_file(self, event=None):
        """Handle Ctrl+N - New file"""
        self.new_file()
        return "break"
    
    def _handle_save(self, event=None):
        """Handle Ctrl+S - Save file"""
        self.save()
        return "break"
    
    def _handle_open(self, event=None):
        """Handle Ctrl+O - Open file"""
        self.load_file()
        return "break"
    
    def _handle_save_as(self, event=None):
        """Handle Ctrl+Shift+S - Save As"""
        self.save_as()
        return "break"
    
    def _handle_undo(self, event=None):
        """Handle Ctrl+Z - Undo"""
        self.undo()
        return "break"
    
    def _handle_redo(self, event=None):
        """Handle Ctrl+Y or Ctrl+Shift+Z - Redo"""
        self.redo()
        return "break"
    
    def _handle_copy(self, event=None):
        """Handle Ctrl+C - Copy with improved detection"""
        try:
            # Quick check if we're in a text widget
            focus_widget = self.master.focus_get()
            if isinstance(focus_widget, (tk.Entry, tk.Text)):
                # Let the default handler work for text widgets
                return None
            
            # Force our enhanced copy functionality for spreadsheet operations
            debug_print("🔵 COPY: Keyboard shortcut triggered")
            self.copy_selection()
            # Return "break" to prevent tksheet from also processing this
            return "break"
        except Exception as e:
            debug_print(f" Copy error: {e}")
            import traceback
            traceback.print_exc()
            return "break"
    
    def _handle_cut(self, event=None):
        """Handle Ctrl+X - Cut with improved detection"""
        try:
            # Quick check if we're in a text widget
            focus_widget = self.master.focus_get()
            if isinstance(focus_widget, (tk.Entry, tk.Text)):
                # Let the default handler work for text widgets
                return None
            
            # Force our enhanced cut functionality for spreadsheet operations
            debug_print("🔵 CUT: Keyboard shortcut triggered")
            self.cut_selection()
            # Return "break" to prevent tksheet from also processing this
            return "break"
        except Exception as e:
            debug_print(f" Cut error: {e}")
            import traceback
            traceback.print_exc()
            return "break"
    
    def _handle_paste(self, event=None):
        """Handle Ctrl+V - Paste with improved detection"""
        try:
            # Quick check if we're in a text widget
            focus_widget = self.master.focus_get()
            if isinstance(focus_widget, (tk.Entry, tk.Text)):
                # Let the default handler work for text widgets
                return None
            
            # Force our enhanced paste functionality for spreadsheet operations
            debug_print("🔵 PASTE: Keyboard shortcut triggered")
            self.paste_selection()
            # Return "break" to prevent tksheet from also processing this
            return "break"
        except Exception as e:
            debug_print(f" Paste error: {e}")
            import traceback
            traceback.print_exc()
            return "break"
    
    def _handle_select_all(self, event=None):
        """Handle Ctrl+A - Select All"""
        self.select_all()
        return "break"
    
    def _handle_find(self, event=None):
        """Handle Ctrl+F - Find"""
        self.find_value()
        return "break"
    
    def _handle_replace(self, event=None):
        """Handle Ctrl+H - Find and Replace"""
        self.find_and_replace()
        return "break"
    
    def _handle_goto(self, event=None):
        """Handle Ctrl+G - Go to cell"""
        self.go_to_cell()
        return "break"
    
    def _handle_zoom_in(self, event=None):
        """Handle Ctrl++ - Zoom In"""
        self.zoom_in()
        return "break"
    
    def _handle_zoom_out(self, event=None):
        """Handle Ctrl+- - Zoom Out"""
        self.zoom_out()
        return "break"
    
    def _handle_reset_zoom(self, event=None):
        """Handle Ctrl+0 - Reset Zoom"""
        self.reset_zoom()
        return "break"
    
    def _handle_edit_cell(self, event=None):
        """Handle F2 - Edit cell in dialog"""
        self.edit_cell_dialog()
        return "break"
    
    def _handle_delete(self, event=None):
        """Handle Delete/Backspace - Clear cell (only if not in edit mode)"""
        # CRITICAL: If event came from tksheet or its children, don't intercept
        # Let tksheet handle its own delete/backspace naturally during editing
        if event and hasattr(event, 'widget'):
            widget_str = str(event.widget)
            # Check if event came from tksheet or any of its child widgets
            if '.!sheet' in widget_str:
                debug_print(f"⌨️ BACKSPACE: Event from tksheet widget ({widget_str}), allowing tksheet to handle")
                return None  # Don't intercept - let tksheet handle it
        
        # Additional check: If focus is on tksheet, don't intercept
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            try:
                focus_widget = self.master.focus_get()
                if focus_widget:
                    focus_str = str(focus_widget)
                    # If focus is anywhere within tksheet, let tksheet handle it
                    if '.!sheet' in focus_str:
                        debug_print(f"⌨️ BACKSPACE: Focus on tksheet ({focus_str}), allowing tksheet to handle")
                        return None
            except Exception as e:
                debug_print(f"⚠️ BACKSPACE: Error checking focus: {e}")
        
        # Not in tksheet context - clear the cell
        debug_print("⌨️ BACKSPACE: Not in tksheet context, clearing cell")
        self.clear_cell()
        return "break"

    def update_toolbar_sizing(self):
        """Calculate dynamic sizing based on window/screen width - Responsive for all screen sizes"""
        # CRITICAL: Detect which monitor window is currently on
        # This handles dragging between 14-inch laptop and 27-inch monitor
        
        effective_width = 1366  # Default fallback
        
        try:
            # Strategy 1: Get actual window width
            window_width = self.master.winfo_width()
            
            # Strategy 2: Get screen dimensions
            screen_width = self.master.winfo_screenwidth()
            screen_height = self.master.winfo_screenheight()
            
            # Strategy 3: Get window position
            window_x = self.master.winfo_x()
            window_y = self.master.winfo_y()
            
            debug_print(f"📐 DETECT: Window={window_width}px at x={window_x}, Screen={screen_width}x{screen_height}")
            
            # CRITICAL LOGIC: Determine effective screen width
            if window_width > 1:
                # Window is realized
                if window_width > 2000:
                    # Window is very wide - must be on large monitor
                    effective_width = window_width
                    debug_print(f"🖥️ LARGE WINDOW: Using width={effective_width}")
                elif window_x < 0 or window_x > screen_width:
                    # Window is on secondary monitor
                    # Guess monitor size based on typical resolutions
                    if screen_width >= 2560:
                        effective_width = screen_width
                    else:
                        # Window on secondary, assume it's larger
                        effective_width = 2560  # Assume 27-inch monitor
                    debug_print(f"�️ SECONDARY MONITOR: Using width={effective_width}")
                elif window_width > screen_width * 0.8:
                    # Window is close to maximized
                    effective_width = screen_width
                    debug_print(f"🖥️ MAXIMIZED: Using screen width={effective_width}")
                else:
                    # Normal window size
                    effective_width = max(window_width, 1366)
                    debug_print(f"🖥️ NORMAL: Using window width={effective_width}")
            else:
                # Window not yet realized
                effective_width = screen_width if screen_width > 1 else 1366
                debug_print(f"🖥️ NOT REALIZED: Using screen={effective_width}")
                
        except Exception as e:
            debug_print(f"⚠️ DETECT ERROR: {e}, using default 1366px")
            effective_width = 1366
        
        # 🎯 SMART ADAPTIVE ALGORITHM: Calculate sizes based on screen width
        # This automatically adapts to ANY screen size without manual configuration!
        window_width = effective_width
        
        # SMART ADAPTIVE SIZING - Based on proven working values
        # Uses your tested breakpoints as anchors, interpolates for in-between sizes
        
        if window_width < 1400:
            # 14-inch laptop (1366px) - Proven working values
            self.toolbar_font_size = 10
            self.toolbar_padx = 5
            self.toolbar_pady = 3
            self.toolbar_row_col_font = 11
            self.toolbar_button_width = 6
            self.toolbar_frame_padding = 2
            sizing_mode = "14-inch (compact)"
            
        elif window_width < 1800:
            # 15.6-inch to 23-inch (1600-1799px) - Interpolated medium size
            self.toolbar_font_size = 13
            self.toolbar_padx = 8
            self.toolbar_pady = 4
            self.toolbar_row_col_font = 14
            self.toolbar_button_width = 5
            self.toolbar_frame_padding = 3
            sizing_mode = "Medium (15-23 inch)"
            
        else:
            # 24-inch and 27-inch (1920px+) - Proven working large values
            self.toolbar_font_size = 16
            self.toolbar_padx = 10
            self.toolbar_pady = 5
            self.toolbar_row_col_font = 17
            self.toolbar_button_width = 5
            self.toolbar_frame_padding = 3
            sizing_mode = "Large (24-27 inch)"
        
        debug_print(f"🎯 SMART SIZING [{sizing_mode}]: font={self.toolbar_font_size}, padx={self.toolbar_padx}, pady={self.toolbar_pady}, button_width={self.toolbar_button_width}, frame_padding={self.toolbar_frame_padding} for {window_width}px")
    
    def on_window_resize(self, event):
        """Handle window resize events - Update toolbar sizing for responsive design"""
        debug_print(f"🔔 RESIZE EVENT: widget={event.widget}, master={self.master}, match={event.widget == self.master}")
        # Only respond to main window resize, not child widgets
        if event.widget == self.master:
            debug_print(f"✅ RESIZE: Main window resize detected - scheduling toolbar update")
            # Debounce resize events - only update after 200ms of no resizing
            if hasattr(self, '_resize_timer'):
                self.master.after_cancel(self._resize_timer)
                debug_print(f"⏱️ RESIZE: Cancelled previous timer")
            self._resize_timer = self.master.after(200, self._delayed_toolbar_update)
            debug_print(f"⏱️ RESIZE: Scheduled update in 200ms")
    
    def _delayed_toolbar_update(self):
        """Update toolbar sizing after resize debounce delay"""
        old_font = getattr(self, 'toolbar_font_size', 10)
        self.update_toolbar_sizing()
        new_font = self.toolbar_font_size
        
        # Debug: Log toolbar size changes
        debug_print(f"🔧 TOOLBAR RESIZE: Font {old_font} → {new_font} (Window: {self.master.winfo_width()}px, Screen: {self.master.winfo_screenwidth()}px)")
        
        # CRITICAL FIX: Always update buttons, even if font size didn't change
        # This ensures toolbar adapts when dragging between monitors
        self.update_toolbar_buttons_sizing()
        debug_print(f"✅ TOOLBAR: Buttons updated (font={new_font}, padx={self.toolbar_padx}, pady={self.toolbar_pady})")
    
    def _initial_toolbar_sizing(self):
        """Initial toolbar sizing check after window is realized"""
        debug_print(f"🚀 INITIAL SIZING: Window: {self.master.winfo_width()}px, Screen: {self.master.winfo_screenwidth()}px")
        old_font = getattr(self, 'toolbar_font_size', 10)
        self.update_toolbar_sizing()
        new_font = self.toolbar_font_size
        
        # Update existing buttons without rebuilding toolbar frame
        if old_font != new_font:
            debug_print(f"🔧 INITIAL TOOLBAR: Font {old_font} → {new_font} - Updating buttons...")
            self.update_toolbar_buttons_sizing()
        else:
            debug_print(f"✅ INITIAL TOOLBAR: Font {new_font} - No changes needed")
    
    def update_toolbar_buttons_sizing(self):
        """Update button sizes dynamically without destroying toolbar frame"""
        try:
            if not hasattr(self, 'toolbar_frame'):
                debug_print(f"⚠️ No toolbar_frame attribute!")
                return
            
            debug_print(f"🔄 Updating toolbar buttons: font={self.toolbar_font_size}, padx={self.toolbar_padx}, pady={self.toolbar_pady}")
            
            button_count = 0
            label_frame_count = 0
            
            # Update all tk.Button widgets in toolbar and its child frames
            def update_buttons_recursive(widget):
                nonlocal button_count, label_frame_count
                for child in widget.winfo_children():
                    if isinstance(child, tk.Button):
                        # Get current values
                        old_font = child.cget('font')
                        old_padx = child.cget('padx')
                        old_pady = child.cget('pady')
                        
                        # Update button font and padding
                        child.config(
                            font=("Arial", self.toolbar_font_size),
                            padx=self.toolbar_padx,
                            pady=self.toolbar_pady
                        )
                        button_count += 1
                        
                        # Verify the update worked
                        new_font = child.cget('font')
                        new_padx = child.cget('padx')
                        new_pady = child.cget('pady')
                        debug_print(f"  🔘 Button #{button_count} '{child.cget('text')[:15]}': font {old_font}→{new_font}, padx {old_padx}→{new_padx}, pady {old_pady}→{new_pady}")
                    elif isinstance(child, (ttk.Frame, ttk.LabelFrame, tk.Frame)):
                        label_frame_count += 1
                        # Recursively update buttons in child frames
                        update_buttons_recursive(child)
            
            # Update all buttons in toolbar
            debug_print(f"📦 Starting recursive update on toolbar_frame...")
            update_buttons_recursive(self.toolbar_frame)
            debug_print(f"📦 Visited {label_frame_count} frames, updated {button_count} buttons")
            
            # Update zoom label font
            if hasattr(self, 'zoom_label'):
                self.zoom_label.config(font=("Arial", max(8, self.toolbar_font_size - 1)))
                debug_print(f"  📏 Updated zoom_label")
            
            # Update selection info label font
            if hasattr(self, 'selection_info'):
                self.selection_info.config(font=("Arial", self.toolbar_font_size, "italic bold"))
                debug_print(f"  ℹ️ Updated selection_info")
            
            # Update name box font
            if hasattr(self, 'name_box'):
                self.name_box.config(font=("Arial", self.toolbar_font_size))
                debug_print(f"  📝 Updated name_box")
            
            # Update Row/Col buttons with their special font size
            if hasattr(self, 'row_ops_frame'):
                row_btn_count = 0
                for child in self.row_ops_frame.winfo_children():
                    if isinstance(child, tk.Button):
                        child.config(
                            font=("Arial", self.toolbar_font_size),
                            padx=self.toolbar_padx,
                            pady=self.toolbar_pady,
                            width=self.toolbar_button_width
                        )
                        row_btn_count += 1
                debug_print(f"  🔲 Updated {row_btn_count} row operation buttons")
            
            if hasattr(self, 'col_ops_frame'):
                col_btn_count = 0
                for child in self.col_ops_frame.winfo_children():
                    if isinstance(child, tk.Button):
                        child.config(
                            font=("Arial", self.toolbar_font_size),
                            padx=self.toolbar_padx,
                            pady=self.toolbar_pady,
                            width=self.toolbar_button_width
                        )
                        col_btn_count += 1
                debug_print(f"  🔳 Updated {col_btn_count} column operation buttons")
            
            debug_print(f"✅ Toolbar buttons updated successfully! Total buttons: {button_count}")
            
            # CRITICAL: Force toolbar to recalculate layout after button updates
            # Tkinter doesn't automatically re-render when we change button properties
            debug_print(f"🔄 Forcing toolbar layout recalculation...")
            
            # Step 1: Process pending idle tasks
            self.toolbar_frame.update_idletasks()
            self.toolbar_container.update_idletasks()
            
            # Step 2: Force immediate visual update (redraw)
            self.toolbar_frame.update()
            self.toolbar_container.update()
            
            # Step 3: Force pack to recalculate
            self.toolbar_frame.pack_configure()
            
            debug_print(f"✅ Toolbar layout updated and redrawn!")
            
        except Exception as e:
            debug_print(f"⚠️ Error updating toolbar buttons: {e}")
            import traceback
            traceback.print_exc()

    
    def rebuild_toolbar(self):
        """Rebuild the toolbar with updated sizing"""
        if hasattr(self, 'toolbar_frame'):
            # Destroy old toolbar
            self.toolbar_frame.destroy()
            if hasattr(self, 'toolbar_overflow_frame'):
                self.toolbar_overflow_frame.destroy()
            
            # Recreate toolbar with new sizes
            self.setup_enhanced_toolbar()
    
    def setup_enhanced_toolbar(self):
        """Setup enhanced toolbar with icons and modern styling - SMART WRAPPING"""
        # Initialize sizing if not already done
        if not hasattr(self, 'toolbar_font_size'):
            self.update_toolbar_sizing()
        
        # Main toolbar container that allows wrapping
        self.toolbar_container = tk.Frame(self.master, bg="#f8f9fa", relief="raised", bd=1)
        self.toolbar_container.pack(side="top", fill="x", padx=5, pady=2)
        
        # First row - main toolbar operations
        self.toolbar_frame = tk.Frame(self.toolbar_container, bg="#f8f9fa")
        self.toolbar_frame.pack(side="top", fill="x")
        
        # Second row - for overflow when window is narrow (initially empty)
        self.toolbar_overflow_frame = tk.Frame(self.toolbar_container, bg="#f8f9fa")
        # Don't pack yet - will be shown only when needed
        
        # File operations section - responsive padding based on screen size
        file_frame = ttk.LabelFrame(self.toolbar_frame, text="File", padding=self.toolbar_frame_padding)
        file_frame.pack(side="left", padx=2, pady=2)
        
        tk.Button(file_frame, text=f"{self.icons['new']} New", command=self.new_file, 
                  bg="#e3f2fd", fg="#0d47a1", font=("Arial", self.toolbar_font_size), relief="raised",
                  padx=self.toolbar_padx, pady=self.toolbar_pady, cursor="hand2").pack(side="left", padx=1)
        tk.Button(file_frame, text=f"{self.icons['open']} Open", command=self.load_file, 
                  bg="#e8f5e9", fg="#1b5e20", font=("Arial", self.toolbar_font_size), relief="raised",
                  padx=self.toolbar_padx, pady=self.toolbar_pady, cursor="hand2").pack(side="left", padx=1)
        tk.Button(file_frame, text=f"{self.icons['save']} Save", command=self.save, 
                  bg="#fff3e0", fg="#e65100", font=("Arial", self.toolbar_font_size), relief="raised",
                  padx=self.toolbar_padx, pady=self.toolbar_pady, cursor="hand2").pack(side="left", padx=1)
        
        # Edit operations section - responsive padding based on screen size
        edit_frame = ttk.LabelFrame(self.toolbar_frame, text="Edit", padding=self.toolbar_frame_padding)
        edit_frame.pack(side="left", padx=2, pady=2)
        
        tk.Button(edit_frame, text=f"{self.icons['undo']} Undo", command=self.undo, 
                  bg="#f3e5f5", fg="#4a148c", font=("Arial", self.toolbar_font_size), relief="raised",
                  padx=self.toolbar_padx, pady=self.toolbar_pady, cursor="hand2").pack(side="left", padx=1)
        tk.Button(edit_frame, text=f"{self.icons['redo']} Redo", command=self.redo, 
                  bg="#f3e5f5", fg="#4a148c", font=("Arial", self.toolbar_font_size), relief="raised",
                  padx=self.toolbar_padx, pady=self.toolbar_pady, cursor="hand2").pack(side="left", padx=1)
        tk.Button(edit_frame, text=f"{self.icons['copy']} Copy", command=self.copy_selection, 
                  bg="#e1f5fe", fg="#01579b", font=("Arial", self.toolbar_font_size), relief="raised",
                  padx=self.toolbar_padx, pady=self.toolbar_pady, cursor="hand2").pack(side="left", padx=1)
        tk.Button(edit_frame, text=f"{self.icons['cut']} Cut", command=self.cut_selection, 
                  bg="#ffebee", fg="#b71c1c", font=("Arial", self.toolbar_font_size), relief="raised",
                  padx=self.toolbar_padx, pady=self.toolbar_pady, cursor="hand2").pack(side="left", padx=1)
        tk.Button(edit_frame, text=f"{self.icons['paste']} Paste", command=self.paste_selection, 
                  bg="#e8f5e9", fg="#2e7d32", font=("Arial", self.toolbar_font_size), relief="raised",
                  padx=self.toolbar_padx, pady=self.toolbar_pady, cursor="hand2").pack(side="left", padx=1)
        
        # View operations section - responsive padding based on screen size
        view_frame = ttk.LabelFrame(self.toolbar_frame, text="View", padding=self.toolbar_frame_padding)
        view_frame.pack(side="left", padx=2, pady=2)
        
        tk.Button(view_frame, text=f"{self.icons['zoom_in']}", command=self.zoom_in, 
                  bg="#fff9c4", fg="#f57f17", font=("Arial", self.toolbar_font_size), relief="raised",
                  padx=self.toolbar_padx, pady=self.toolbar_pady, cursor="hand2").pack(side="left", padx=1)
        tk.Button(view_frame, text=f"{self.icons['zoom_out']}", command=self.zoom_out, 
                  bg="#fff9c4", fg="#f57f17", font=("Arial", self.toolbar_font_size), relief="raised",
                  padx=self.toolbar_padx, pady=self.toolbar_pady, cursor="hand2").pack(side="left", padx=1)
        
        # Zoom level display
        self.zoom_label = ttk.Label(view_frame, text=f"{int(self.zoom_level * 100)}%", 
                                   font=("Arial", max(8, self.toolbar_font_size - 1)))
        self.zoom_label.pack(side="left", padx=2)
        
        # Search section - responsive padding based on screen size
        search_frame = ttk.LabelFrame(self.toolbar_frame, text="Nav", padding=self.toolbar_frame_padding)
        search_frame.pack(side="left", padx=2, pady=2)
        
        tk.Button(search_frame, text=f"{self.icons['find']} Find", command=self.find_value, 
                  bg="#fce4ec", fg="#880e4f", font=("Arial", self.toolbar_font_size), relief="raised",
                  padx=self.toolbar_padx, pady=self.toolbar_pady, cursor="hand2").pack(side="left", padx=1)
        
        # Name box for navigation
        ttk.Label(search_frame, text="Cell:", font=("Arial", self.toolbar_font_size)).pack(side="left", padx=(4, 2))
        self.name_box = ttk.Entry(search_frame, width=7, font=("Arial", self.toolbar_font_size))
        self.name_box.pack(side="left", padx=1)
        self.name_box.bind('<Return>', self.go_to_name_box_cell)
        self.name_box.bind('<FocusOut>', self.update_name_box)
        
        # Row operations - integrated into main toolbar - Responsive width and padding
        self.row_ops_frame = ttk.LabelFrame(self.toolbar_frame, text="Row", padding=self.toolbar_frame_padding)
        self.row_ops_frame.pack(side="left", padx=2, pady=2)
        
        btn_row_insert_before = tk.Button(self.row_ops_frame, text="+ ↑", 
                   command=self.insert_row_before_selected, 
                   bg="#e1f5fe", fg="#01579b", font=("Arial", self.toolbar_font_size),
                   relief="raised", padx=self.toolbar_padx, pady=self.toolbar_pady, 
                   width=self.toolbar_button_width, cursor="hand2")
        btn_row_insert_before.pack(side="left", padx=1)
        self.create_tooltip(btn_row_insert_before, "Insert row above")
        
        btn_row_insert_after = tk.Button(self.row_ops_frame, text="+ ↓", 
                   command=self.insert_row_after_selected,
                   bg="#e8f5e9", fg="#2e7d32", font=("Arial", self.toolbar_font_size),
                   relief="raised", padx=self.toolbar_padx, pady=self.toolbar_pady, 
                   width=self.toolbar_button_width, cursor="hand2")
        btn_row_insert_after.pack(side="left", padx=1)
        self.create_tooltip(btn_row_insert_after, "Insert row below")
        
        btn_row_delete = tk.Button(self.row_ops_frame, text="×", 
                   command=self.delete_selected_row,
                   bg="#ffebee", fg="#c62828", font=("Arial", self.toolbar_font_size),
                   relief="raised", padx=self.toolbar_padx, pady=self.toolbar_pady, 
                   width=self.toolbar_button_width, cursor="hand2")
        btn_row_delete.pack(side="left", padx=1)
        self.create_tooltip(btn_row_delete, "Delete row")
        
        # Column operations - integrated into main toolbar - Responsive width and padding
        self.col_ops_frame = ttk.LabelFrame(self.toolbar_frame, text="Col", padding=self.toolbar_frame_padding)
        self.col_ops_frame.pack(side="left", padx=2, pady=2)
        
        btn_col_insert_before = tk.Button(self.col_ops_frame, text="+ ←", 
                   command=self.insert_col_before_selected,
                   bg="#f3e5f5", fg="#6a1b9a", font=("Arial", self.toolbar_font_size),
                   relief="raised", padx=self.toolbar_padx, pady=self.toolbar_pady, 
                   width=self.toolbar_button_width, cursor="hand2")
        btn_col_insert_before.pack(side="left", padx=1)
        self.create_tooltip(btn_col_insert_before, "Insert column left")
        
        btn_col_insert_after = tk.Button(self.col_ops_frame, text="+ →", 
                   command=self.insert_col_after_selected,
                   bg="#fff3e0", fg="#e65100", font=("Arial", self.toolbar_font_size),
                   relief="raised", padx=self.toolbar_padx, pady=self.toolbar_pady, 
                   width=self.toolbar_button_width, cursor="hand2")
        btn_col_insert_after.pack(side="left", padx=1)
        self.create_tooltip(btn_col_insert_after, "Insert column right")
        
        btn_col_delete = tk.Button(self.col_ops_frame, text="×", 
                   command=self.delete_selected_col,
                   bg="#ffebee", fg="#c62828", font=("Arial", self.toolbar_font_size),
                   relief="raised", padx=self.toolbar_padx, pady=self.toolbar_pady, 
                   width=self.toolbar_button_width, cursor="hand2")
        btn_col_delete.pack(side="left", padx=1)
        self.create_tooltip(btn_col_delete, "Delete column")
        
        # Selection info - right side of toolbar (reduced padding to give more space for buttons)
        self.selection_info = tk.Label(self.toolbar_frame, text="", 
                                       bg="#f8f9fa", fg="#1565c0", 
                                       font=("Arial", self.toolbar_font_size, "italic bold"))
        self.selection_info.pack(side="right", padx=5, pady=2)  # Reduced from 10 to 5
        
        # Track current selection type and position
        self.current_selection = None  # None, 'row', 'column', 'cell'
        self.current_row = None  # Current row index (0-based)
        self.current_col = None  # Current column index (0-based)
        
        # Store toolbar sections for smart wrapping
        self.toolbar_sections = {
            'file': file_frame,
            'edit': edit_frame,
            'view': view_frame,
            'search': search_frame,
            'row': self.row_ops_frame,
            'col': self.col_ops_frame
        }
        
        # DISABLED: Smart wrapping causes frames to disappear
        # Keeping toolbar as single horizontal line
        # If window too narrow, user can scroll or resize
        
        # Auto-save indicator removed - feature disabled
        # Users must save manually with Ctrl+S or File > Save
    
    def check_toolbar_overflow(self, event=None):
        """Toolbar wrapping disabled - too buggy with frame management"""
        pass
    
    def update_auto_save_button(self):
        """Update the auto-save round button - DISABLED"""
        pass  # Auto-save feature removed
    
    def setup_formula_bar(self):
        """Setup formula bar for cell content editing"""
        if not self.formula_bar_visible:
            return
            
        formula_frame = ttk.Frame(self.master, style="FormulaBar.TFrame")
        formula_frame.pack(side="top", fill="x", padx=5, pady=2)
        
        # Name box (cell address) - simplified without label
        self.formula_name_box = ttk.Entry(formula_frame, width=10, font=("Arial", 10, "bold"))
        self.formula_name_box.pack(side="left", padx=2)
        self.formula_name_box.bind('<Return>', self.go_to_formula_name_box_cell)
        
        # Formula/content bar - simplified without fx label
        self.formula_bar = ttk.Entry(formula_frame, font=("Arial", 10))
        self.formula_bar.pack(side="left", fill="x", expand=True, padx=2)
        self.formula_bar.bind('<Return>', self.apply_formula_bar_content)
        self.formula_bar.bind('<Escape>', self.cancel_formula_bar_edit)
        
        # Store reference for toggling
        self.formula_frame = formula_frame
    
    def on_global_click(self, event):
        """Handle global clicks to dismiss context menus"""
        if hasattr(self, 'active_context_menu') and self.active_context_menu:
            try:
                # Check if the click was outside the context menu
                widget = event.widget
                # If the clicked widget is not part of the context menu, dismiss it
                if not str(widget).startswith(str(self.active_context_menu)):
                    self.active_context_menu.unpost()
                    self.active_context_menu.destroy()
                    self.active_context_menu = None
            except:
                # If there's any error, just clear the reference
                self.active_context_menu = None
    
    def dismiss_context_menu_and_execute(self, action):
        """Dismiss the context menu and then execute the action"""
        # First dismiss the context menu
        if hasattr(self, 'active_context_menu') and self.active_context_menu:
            try:
                self.active_context_menu.unpost()
                self.active_context_menu.destroy()
            except:
                pass
            self.active_context_menu = None
        
        # Then execute the action
        action()
    
    def setup_sheet_tabs(self):
        """Setup sheet tabs interface at bottom like Excel"""
        # Sheet tabs frame at bottom - positioned above status bar
        self.sheet_tabs_frame = ttk.Frame(self.master)
        self.sheet_tabs_frame.pack(side="bottom", fill="x", padx=2, pady=(0, 2), before=self.status_frame)
        
        # Create a frame that looks like Excel's sheet bar
        excel_style_frame = tk.Frame(self.sheet_tabs_frame, bg="#e1e1e1", relief="raised", bd=1)
        excel_style_frame.pack(side="bottom", fill="x")
        
        # Left section - sheet navigation arrows (like Excel)
        nav_frame = tk.Frame(excel_style_frame, bg="#e1e1e1")
        nav_frame.pack(side="left", padx=2, pady=1)
        
        # Sheet navigation buttons - simplified to avoid font rendering issues
        self.nav_first_btn = tk.Button(nav_frame, text="<<", font=("Arial", 8), width=3, height=1,
                                      command=self.nav_to_first_sheet, bg="#f0f0f0", relief="flat")
        self.nav_first_btn.pack(side="left", padx=1)
        
        self.nav_prev_btn = tk.Button(nav_frame, text="<", font=("Arial", 8), width=2, height=1,
                                     command=self.nav_to_prev_sheet, bg="#f0f0f0", relief="flat")
        self.nav_prev_btn.pack(side="left")
        
        self.nav_next_btn = tk.Button(nav_frame, text=">", font=("Arial", 8), width=2, height=1,
                                     command=self.nav_to_next_sheet, bg="#f0f0f0", relief="flat")
        self.nav_next_btn.pack(side="left")
        
        self.nav_last_btn = tk.Button(nav_frame, text=">>", font=("Arial", 8), width=3, height=1,
                                     command=self.nav_to_last_sheet, bg="#f0f0f0", relief="flat")
        self.nav_last_btn.pack(side="left", padx=(0, 3))
        
        # Container for sheet tabs with scrolling capability
        self.tabs_container = tk.Frame(excel_style_frame, bg="#e1e1e1")
        self.tabs_container.pack(side="left", fill="x", expand=True, padx=(5, 0))
        
        # Canvas for scrollable tabs - simplified
        self.tabs_canvas = tk.Canvas(self.tabs_container, height=30, highlightthickness=0, bg="#e1e1e1", bd=0)
        self.scrollable_tabs_frame = tk.Frame(self.tabs_canvas, bg="#e1e1e1")
        
        # Configure scrolling
        self.scrollable_tabs_frame.bind(
            "<Configure>",
            lambda e: self.tabs_canvas.configure(scrollregion=self.tabs_canvas.bbox("all"))
        )
        
        self.tabs_canvas.create_window((0, 0), window=self.scrollable_tabs_frame, anchor="nw")
        
        # Pack canvas only (simplified scrolling)
        self.tabs_canvas.pack(side="top", fill="x", expand=True)
        
        # Right section - add sheet button and horizontal scroll space
        right_frame = tk.Frame(excel_style_frame, bg="#e1e1e1")
        right_frame.pack(side="right", padx=2, pady=1)
        
        # Add sheet button - simplified to avoid font rendering issues
        self.add_sheet_btn = tk.Button(
            right_frame, 
            text="+", 
            font=("Arial", 12, "bold"),
            command=self.add_sheet_tab,
            width=2,
            height=1,
            bg="#f0f0f0",
            relief="flat",
            cursor="hand2"
        )
        self.add_sheet_btn.pack(side="right", padx=(5, 2))
        
        # Store sheet tab buttons
        self.sheet_tab_buttons = {}
        self.active_tab_style = {"relief": "solid", "borderwidth": 1, "bg": "white", "fg": "black"}
        self.inactive_tab_style = {"relief": "flat", "borderwidth": 1, "bg": "#f0f0f0", "fg": "#333333"}
        
        # Create initial tabs
        self.update_sheet_tabs()
        
        # Bind mouse wheel for tab scrolling
        self.tabs_canvas.bind("<MouseWheel>", self.on_tab_mousewheel)
        self.tabs_canvas.bind("<Button-4>", self.on_tab_mousewheel)
        self.tabs_canvas.bind("<Button-5>", self.on_tab_mousewheel)
    
    def setup_context_operations(self):
        """Context operations now integrated into main toolbar - this method kept for compatibility"""
        # Row and Column operations are now part of setup_enhanced_toolbar()
        # This method is kept empty to avoid errors if called elsewhere
        # The toolbar_frame reference is used instead of context_frame
        self.context_frame = self.toolbar_frame  # Point to toolbar for compatibility
        pass
    
    def create_tooltip(self, widget, text):
        """Create a tooltip for a widget with safe font handling"""
        def on_enter(event):
            try:
                tooltip = tk.Toplevel()
                tooltip.wm_overrideredirect(True)
                # Use simple font to avoid rendering issues
                label = tk.Label(tooltip, text=text, background="lightyellow", 
                                relief="solid", borderwidth=1, font=("TkDefaultFont", 9))
                label.pack()
                # Update to get actual tooltip width
                label.update_idletasks()
                tooltip_width = label.winfo_reqwidth()
                # Position tooltip to the left of cursor
                tooltip.wm_geometry(f"+{event.x_root-tooltip_width-10}+{event.y_root+10}")
                widget.tooltip = tooltip
            except Exception as e:
                # Skip tooltip if there's a rendering issue
                pass
        
        def on_leave(event):
            try:
                if hasattr(widget, 'tooltip'):
                    widget.tooltip.destroy()
                    del widget.tooltip
            except:
                pass
        
        widget.bind("<Enter>", on_enter)
        widget.bind("<Leave>", on_leave)
    
    def setup_tksheet(self):
        """Setup tksheet with direct editing capabilities"""
        self.table = tksheet.Sheet(
            self.master,
            show_row_index=True,
            show_header=True,
            show_top_left=True,
            empty_horizontal=0,
            empty_vertical=0,
            row_index_width=60,
            header_height=30
        )
        
        # Enable Excel-like bindings with proper cell selection and editing
        # NOTE: We disable tksheet's built-in copy/cut/paste to use our enhanced versions
        self.table.enable_bindings(
            "all",
            "single_select",      # Single click to select
            "drag_select",        # Drag to select multiple cells
            "column_select",      # Click column header to select column
            "row_select",         # Click row header to select row
            "edit_cell",          # Enable direct cell editing - needed for functionality
            # Commenting out tksheet's built-in clipboard operations - we use our own
            # "copy",
            # "cut", 
            # "paste",
            "delete",
            "arrowkeys",
            "row_height_resize",
            "column_width_resize",
            "rc_select"
        )
        
        # Bind cell edit events to track changes for undo
        self.table.bind("<<SheetModified>>", self.on_cell_modified)
        self.table.bind("<<SheetSelect>>", self.on_cell_selected)
        self.table.bind("<ButtonRelease-1>", self.on_selection_change)
        # Use ButtonRelease instead of Button-1 to not interfere with tksheet's selection
        # self.table.bind("<Button-1>", self.on_cell_click)  # Commented out - was interfering with selection
        
        # Bind to events that indicate user finished editing
        self.table.bind("<Return>", self.on_edit_complete)  # Enter key
        self.table.bind("<Tab>", self.on_edit_complete)     # Tab key  
        self.table.bind("<Escape>", self.on_edit_cancelled)  # Escape key (cancel edit)
        
        # CRITICAL: Explicitly unbind tksheet's default cut/copy/paste to prevent conflicts
        # These must be unbound because tksheet may have default handlers even when not enabled
        self.table.unbind("<Control-c>")
        self.table.unbind("<Control-C>")
        self.table.unbind("<Control-x>")
        self.table.unbind("<Control-X>")
        self.table.unbind("<Control-v>")
        self.table.unbind("<Control-V>")
        debug_print("✂️ SETUP: Unbound tksheet's default Ctrl+C/X/V handlers")
        
        self.table.pack(expand=True, fill="both", padx=5, pady=5)
        
        # Initialize hybrid undo/redo manager after tksheet is set up
        self.hybrid_undo_manager = HybridUndoManager(self, self.table, self.max_undo_stack)
        debug_print("✅ Hybrid undo/redo system initialized with tksheet integration")
    
    def add_to_undo_stack(self, action_type, data):
        """Add an action to the undo stack using hybrid system"""
        debug_print(f" HYBRID ADD: Routing '{action_type}' operation")
        
        # Mark that changes have been made
        self.has_unsaved_changes = True
        self.update_window_title()
        
        # If hybrid manager is not initialized yet, use legacy system
        if not self.hybrid_undo_manager:
            debug_print(f"   ⚠️ Hybrid manager not ready, using legacy system")
            self._legacy_add_to_undo_stack(action_type, data)
            return
        
        # Route simple cell operations to tksheet (let tksheet handle them automatically)
        if action_type in ['cell_edit', 'cell_clear', 'clear_selection']:
            debug_print(f"   📝 Routing to tksheet: {action_type}")
            # For cell operations, just notify the hybrid manager
            self.hybrid_undo_manager.notify_tksheet_operation(OperationType.TKSHEET_CELL)
            return
        
        # Route paste operations to custom system (so they can be undone before structural changes)
        elif action_type == 'paste_operation':
            debug_print(f"   📋 Routing to custom (excel): {action_type}")
            paste_type = data.get('type', 'unknown')
            affected_count = len(data.get('affected_cells', []))
            description = f"Paste {paste_type}: {affected_count} cells"
            self.hybrid_undo_manager.add_custom_operation(
                OperationType.CUSTOM_EXCEL, description, data, data
            )
        
        # Route complex operations to custom system
        elif action_type in ['sheet_add', 'sheet_rename', 'sheet_delete', 'sheet_switch']:
            debug_print(f"   � Routing to custom (sheet): {action_type}")
            description = f"{action_type}: {data.get('sheet_name', data.get('new_sheet', 'sheet'))}"
            self.hybrid_undo_manager.add_custom_operation(
                OperationType.CUSTOM_SHEET, description, data, data
            )
            
        elif action_type in ['row_insert', 'row_delete', 'column_insert', 'column_delete']:
            debug_print(f"   🏗️ Routing to custom (structure): {action_type}")
            position = data.get('insert_position', data.get('row_number', data.get('column_index', 0)))
            description = f"{action_type} at {position}"
            self.hybrid_undo_manager.add_custom_operation(
                OperationType.CUSTOM_STRUCTURE, description, data, data
            )
            
        elif action_type in ['format_change', 'find_replace', 'bulk_cell_edit', 'replace_single', 'replace_all']:
            debug_print(f"   🎨 Routing to custom (excel): {action_type}")
            description = f"{action_type}: {str(data)[:50]}..."
            self.hybrid_undo_manager.add_custom_operation(
                OperationType.CUSTOM_EXCEL, description, data, data
            )
        
        else:
            debug_print(f"   ⚠️ Unknown operation type, using custom: {action_type}")
            # Fallback to custom system
            self.hybrid_undo_manager.add_custom_operation(
                OperationType.CUSTOM_EXCEL, f"Unknown operation: {action_type}", data, data
            )
        
        # Update status
        self.update_undo_redo_status()
    
    def _legacy_add_to_undo_stack(self, action_type, data):
        """Legacy undo stack method for compatibility"""
        self.undo_stack.append((action_type, data))
        
        # Clear redo stack when new operation is performed
        self.redo_stack.clear()
        
        # Limit undo stack size to prevent memory issues
        if len(self.undo_stack) > self.max_undo_stack:
            self.undo_stack.pop(0)
        
        debug_print(f" LEGACY UNDO: Added '{action_type}' to legacy undo stack")
        self.update_undo_redo_status()
    
    def update_undo_redo_status(self):
        """Update status bar to show undo and redo availability using hybrid system"""
        if not hasattr(self, 'status_main'):
            return
        
        try:
            # Use hybrid manager if available, otherwise fall back to legacy
            if self.hybrid_undo_manager:
                status = self.hybrid_undo_manager.get_status()
                
                undo_count = status['custom_undo_count']
                redo_count = status['custom_redo_count']
                tksheet_undo = status['tksheet_undo_available']
                tksheet_redo = status['tksheet_redo_available']
                
                # Build status message
                status_parts = []
                
                if tksheet_undo or undo_count > 0:
                    total_undo = undo_count + (1 if tksheet_undo else 0)
                    status_parts.append(f"{total_undo} undo")
                
                if tksheet_redo or redo_count > 0:
                    total_redo = redo_count + (1 if tksheet_redo else 0)
                    status_parts.append(f"{total_redo} redo")
                
                if status_parts:
                    undo_status = " | ".join(status_parts) + " available"
                else:
                    undo_status = "No undo/redo available"
                
                # Get current sheet info
                sheet_info = ""
                if hasattr(self, 'ws') and self.ws:
                    ws = self.ws
                    sheet_info = f"Sheet: {ws.title} | Rows: {ws.max_row} | Columns: {ws.max_column}"
                
                # Combine status
                if sheet_info:
                    full_status = f"{sheet_info} | {undo_status}"
                else:
                    full_status = undo_status
                
                self.status_main.config(text=full_status)
                debug_print(f" HYBRID STATUS: {full_status}")
                
            else:
                # Legacy status update
                undo_count = len(self.undo_stack)
                redo_count = len(self.redo_stack)
                
                if undo_count > 0 and redo_count > 0:
                    self.status_main.config(text=f"Action recorded - {undo_count} operations can be undone, {redo_count} can be redone")
                elif undo_count > 0:
                    self.status_main.config(text=f"Action recorded - {undo_count} operations can be undone")
                elif redo_count > 0:
                    self.status_main.config(text=f"Ready - {redo_count} operations can be redone")
                else:
                    self.status_main.config(text="Ready")
            
        except Exception as e:
            debug_print(f"️ Error updating undo/redo status: {e}")
            self.status_main.config(text="Ready")
    
    def capture_sheet_state(self):
        """Capture current sheet state for operations that modify entire sheet"""
        data = []
        for row in self.ws.iter_rows(values_only=True):
            data.append([cell for cell in row])
        return {
            'sheet_name': self.ws.title,
            'data': data,
            'max_row': self.ws.max_row,
            'max_column': self.ws.max_column
        }
    
    def get_cell_value_safely(self, cell_address):
        """Safely get cell value, handling None and type conversion properly"""
        try:
            value = self.ws[cell_address].value
            if value is None:
                return ''
            elif isinstance(value, (int, float)):
                return value  # Keep numbers as numbers
            else:
                return str(value)  # Convert other types to string
        except Exception:
            return ''
    
    def restore_sheet_state(self, state):
        """Restore sheet to a previous state"""
        debug_print(f"🔄 RESTORE STATE: Restoring sheet '{state.get('sheet_name', 'unknown')}'")
        
        # Clear current sheet - OPTIMIZED: only clear used range
        if self.ws.max_row and self.ws.max_column:
            for row in self.ws.iter_rows(max_row=self.ws.max_row, max_col=self.ws.max_column):
                for cell in row:
                    cell.value = None
        
        # Restore data to openpyxl
        for row_idx, row_data in enumerate(state['data'], start=1):
            for col_idx, cell_value in enumerate(row_data, start=1):
                if cell_value is not None:
                    self.ws.cell(row_idx, col_idx, cell_value)
        
        # Critical fix: Also update tksheet with the restored data
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            debug_print(f"   📊 Syncing restored data to tksheet")
            # Convert the restored data to the format tksheet expects
            tksheet_data = []
            for row_data in state['data']:
                # Convert None values to empty strings for tksheet
                tksheet_row = [cell_value if cell_value is not None else '' for cell_value in row_data]
                tksheet_data.append(tksheet_row)
            
            # Update tksheet with restored data
            self.table.set_sheet_data(tksheet_data)
            
            # Update headers and row index
            max_col = len(tksheet_data[0]) if tksheet_data else 1
            headers = [get_column_letter(i+1) for i in range(max_col)]
            row_index = [str(i+1) for i in range(len(tksheet_data))]
            
            self.table.headers(headers)
            self.table.row_index(row_index)
            
            debug_print(f"   ✅ tksheet updated with {len(tksheet_data)} rows, {max_col} columns")
        
        debug_print(f" RESTORE STATE: Successfully restored sheet state")
    
    def on_cell_modified(self, event):
        """Called when a cell is modified through direct editing"""
        debug_print(f" EVENT DEBUG: SheetModified event triggered")
        # DON'T sync immediately - just track that cell is being edited
        # Sync will happen when edit is complete (Enter, Tab, click elsewhere)
        self.track_cell_being_edited()
        self.status_main.config(text="Cell being edited...")
    
    def on_cell_selected(self, event):
        """Update cell info and context operations when a cell is selected"""
        debug_print(f" EVENT DEBUG: SheetSelect event triggered")
        
        # Update selected cell display immediately
        self.update_selected_cell_display()
        
        # Update name box and formula bar
        self.update_name_box()
        if hasattr(self, 'formula_bar'):
            self.update_formula_bar()
        
        # Update context operations based on selection
        if hasattr(self, 'context_frame'):
            self.master.after(50, self.update_context_operations)
    
    def on_selection_change(self, event):
        """Handle selection changes for context operations"""
        debug_print(f"️ EVENT DEBUG: ButtonRelease-1 event triggered")
        
        # Finalize any pending edit when user clicks elsewhere
        self.finalize_any_pending_edit("selection change")
        
        # Update selected cell display
        self.update_selected_cell_display()
        
        # Update name box and formula bar
        self.update_name_box()
        if hasattr(self, 'formula_bar'):
            self.update_formula_bar()
        
        # Update context operations based on selection
        if hasattr(self, 'context_frame'):
            self.master.after(100, self.update_context_operations)
    
    def on_cell_click(self, event):
        """Called when user clicks on a cell - finalize any previous edit session and select cell"""
        debug_print(f"️ CLICK DEBUG: Single click - finalizing any pending edits and selecting cell")
        
        # Destroy any active text editor first (this saves the changes)
        try:
            if hasattr(self.table, 'destroy_text_editor'):
                self.table.destroy_text_editor(set_data=True)
        except:
            pass
            
        # When user clicks elsewhere, finalize any cell edit in progress
        self.finalize_any_pending_edit("cell click")
        # Update cell selection display
        self.update_selected_cell_display()
    
    def update_selected_cell_display(self):
        """Update the display to show currently selected cell in status bar"""
        try:
            # Update the status bar with current selection
            undo_count = len(self.undo_stack)
            
            # Get current selected cell info
            selected_cell = "None"
            selected = self.table.get_currently_selected()
            if selected and hasattr(selected, 'row') and hasattr(selected, 'column'):
                row, col = selected.row, selected.column
                if row is not None and col is not None:
                    selected_cell = f"{get_column_letter(col + 1)}{row + 1}"
                    debug_print(f"📍 SELECTION DEBUG: Selected cell {selected_cell}")
            
            # Update main status
            base_status = f"Sheet: {self.ws.title} | Rows: {self.ws.max_row} | Columns: {self.ws.max_column}"
            if undo_count > 0:
                self.status_main.config(text=f"{base_status} | {undo_count} operations can be undone")
            else:
                self.status_main.config(text=base_status)
            
            # Update selected cell with color (only the cell reference)
            self.status_selected.config(text=selected_cell)
        except Exception as e:
            debug_print(f"️ SELECTION DEBUG: Error updating selection display: {e}")
    
    def on_edit_complete(self, event):
        """Called when user presses Enter or Tab to complete editing"""
        debug_print(f"️ EDIT COMPLETE DEBUG: Edit completed via {event.keysym}")
        self.finalize_any_pending_edit(f"{event.keysym} key")
        # Also destroy any active text editor
        try:
            if hasattr(self.table, 'destroy_text_editor'):
                self.table.destroy_text_editor(set_data=True)
        except:
            pass
        
    def on_edit_cancelled(self, event):
        """Called when user presses Escape to cancel editing"""
        debug_print(f" EDIT CANCEL DEBUG: Edit cancelled via Escape")
        self.cancel_any_pending_edit()
        # Also destroy any active text editor without saving
        try:
            if hasattr(self.table, 'destroy_text_editor'):
                self.table.destroy_text_editor(set_data=False)
        except:
            pass
    
    def track_cell_being_edited(self):
        """Track that a cell is currently being edited (but don't create undo yet)"""
        try:
            selected = self.table.get_currently_selected()
            if selected and hasattr(selected, 'row') and hasattr(selected, 'column'):
                row, col = selected.row, selected.column
                if row is not None and col is not None:
                    cell_addr = f"{get_column_letter(col + 1)}{row + 1}"
                    
                    # If this is a new cell being edited, capture its original value
                    if not self.current_edit_session or self.current_edit_session['cell'] != cell_addr:
                        debug_print(f" TRACK DEBUG: Starting to track edits for cell {cell_addr}")
                        
                        # Get original value from workbook
                        original_value = self.ws.cell(row + 1, col + 1).value
                        
                        self.current_edit_session = {
                            'cell': cell_addr,
                            'row': row + 1,
                            'col': col + 1,
                            'original_value': original_value,
                            'edit_in_progress': True
                        }
                        debug_print(f" TRACK DEBUG: Original value for {cell_addr}: '{original_value}'")
                    else:
                        debug_print(f"🔄 TRACK DEBUG: Continuing edit for cell {cell_addr}")
        except Exception as e:
            debug_print(f"️ TRACK DEBUG: Error tracking cell edit: {e}")
    
    def finalize_any_pending_edit(self, trigger):
        """Finalize any edit in progress and create undo entry"""
        if not self.current_edit_session or not self.current_edit_session.get('edit_in_progress'):
            debug_print(f" FINALIZE DEBUG: No pending edit to finalize (trigger: {trigger})")
            return
            
        cell_addr = self.current_edit_session['cell']
        row = self.current_edit_session['row']
        col = self.current_edit_session['col']
        original_value = self.current_edit_session['original_value']
        
        debug_print(f" FINALIZE DEBUG: Finalizing edit for {cell_addr} (trigger: {trigger})")
        
        # Get the current value from tksheet
        try:
            data = self.table.get_sheet_data()
            final_value = data[row - 1][col - 1] if (row - 1 < len(data) and col - 1 < len(data[row - 1])) else ""
            
            debug_print(f" FINALIZE DEBUG: {cell_addr}: '{original_value}' → '{final_value}'")
            
            # Only create undo entry if value actually changed
            if original_value != final_value:
                debug_print(f"➕ FINALIZE DEBUG: Creating undo entry for {cell_addr}")
                self.add_to_undo_stack('cell_edit', {
                    'cell': cell_addr,
                    'old_value': original_value,
                    'new_value': final_value
                })
                
                # Now sync the change to workbook
                self.ws.cell(row, col).value = final_value
                self.status_main.config(text=f"Cell {cell_addr} edited and saved for undo")
            else:
                debug_print(f"🚫 FINALIZE DEBUG: No change for {cell_addr}, not creating undo entry")
                self.status_main.config(text=f"Cell {cell_addr} - no change")
                
        except Exception as e:
            debug_print(f"️ FINALIZE DEBUG: Error finalizing edit: {e}")
        
        # Clear the edit session
        self.current_edit_session = None
        
    def cancel_any_pending_edit(self):
        """Cancel any edit in progress without creating undo entry"""
        if self.current_edit_session and self.current_edit_session.get('edit_in_progress'):
            cell_addr = self.current_edit_session['cell']
            debug_print(f" CANCEL DEBUG: Cancelling edit for {cell_addr}")
            self.current_edit_session = None
            self.status_main.config(text=f"Edit cancelled for {cell_addr}")
    
    def sync_sheet_to_workbook(self):
        """Sync tksheet data back to openpyxl workbook (for save operations, not for undo tracking)"""
        debug_print(f"️ SYNC DEBUG: sync_sheet_to_workbook() called")
        
        # Prevent multiple simultaneous sync operations
        if self.sync_in_progress:
            debug_print(f"️ SYNC DEBUG: Sync already in progress, skipping")
            return
        
        self.sync_in_progress = True
        debug_print(f" SYNC DEBUG: Sync lock acquired")
        try:
            # CRITICAL FIX: Close any active cell editor to commit the data to tksheet
            # before reading it. If a cell is being edited, the data is in the editor
            # widget, not in tksheet's internal data structure yet.
            try:
                # Try different methods to close the editor based on tksheet version
                closed = False
                
                # Method 1: close_text_editor (preferred for newer versions)
                if hasattr(self.table, 'close_text_editor'):
                    try:
                        self.table.close_text_editor(set_data=True)
                        closed = True
                        debug_print(f" SYNC DEBUG: Closed editor via close_text_editor")
                    except Exception as e:
                        debug_print(f" SYNC DEBUG: close_text_editor failed: {e}")
                
                # Method 2: hide_text_editor (alternative method)
                if not closed and hasattr(self.table, 'hide_text_editor'):
                    try:
                        self.table.hide_text_editor(set_data=True)
                        closed = True
                        debug_print(f" SYNC DEBUG: Closed editor via hide_text_editor")
                    except Exception as e:
                        debug_print(f" SYNC DEBUG: hide_text_editor failed: {e}")
                
                # Method 3: destroy_text_editor (last resort)
                if not closed and hasattr(self.table, 'destroy_text_editor'):
                    try:
                        self.table.destroy_text_editor()
                        closed = True
                        debug_print(f" SYNC DEBUG: Closed editor via destroy_text_editor")
                    except Exception as e:
                        debug_print(f" SYNC DEBUG: destroy_text_editor failed: {e}")
                
                # Close any dropdown windows
                if hasattr(self.table, 'close_dropdown_window'):
                    try:
                        self.table.close_dropdown_window()
                    except:
                        pass
                        
                if closed:
                    debug_print(f" SYNC DEBUG: Successfully closed active cell editors")
                else:
                    debug_print(f" SYNC DEBUG: No active editors to close (or all methods failed)")
                    
            except Exception as e:
                debug_print(f" SYNC DEBUG: Error in editor closing block: {e}")
            
            data = self.table.get_sheet_data()
            
            debug_print(f" SYNC DEBUG: Syncing sheet data to workbook (for save)")
            debug_print(f" SYNC DEBUG: Got {len(data)} rows from tksheet")
            
            # OPTIMIZATION: Instead of clearing ALL cells (very slow for 500x500 grid),
            # only clear cells that previously had data and now don't.
            # This dramatically improves save performance.
            
            # First pass: collect all cells with data from tksheet
            cells_with_data = set()
            cells_to_write = {}  # (row, col): value
            
            for row_idx, row_data in enumerate(data, start=1):
                for col_idx, cell_value in enumerate(row_data, start=1):
                    if cell_value is not None and cell_value != "":
                        cells_with_data.add((row_idx, col_idx))
                        cells_to_write[(row_idx, col_idx)] = cell_value
                        debug_print(f" SYNC DEBUG: Found data in cell ({row_idx},{col_idx}): '{cell_value}'")
            
            debug_print(f" SYNC DEBUG: Found {len(cells_with_data)} cells with data")
            
            # Second pass: only clear cells in workbook that have data but shouldn't
            # CRITICAL FIX: Only iterate through the used range (max_row, max_column)
            # Don't iterate through the entire 500x500 grid!
            cleared_count = 0
            if self.ws.max_row and self.ws.max_column:
                # Only iterate through cells that actually exist in the workbook
                for row in self.ws.iter_rows(max_row=self.ws.max_row, max_col=self.ws.max_column):
                    for cell in row:
                        if cell.value is not None:
                            cell_pos = (cell.row, cell.column)
                            if cell_pos not in cells_with_data:
                                cell.value = None
                                cleared_count += 1
            
            debug_print(f" SYNC DEBUG: Cleared {cleared_count} old cells from used range ({self.ws.max_row}x{self.ws.max_column})")
            
            # Third pass: write new data
            for (row_idx, col_idx), cell_value in cells_to_write.items():
                self.ws.cell(row_idx, col_idx, cell_value)
                        
            debug_print(f" SYNC DEBUG: Wrote {len(cells_to_write)} cells to workbook")
            
        except Exception as e:
            debug_print(f" SYNC DEBUG: Sync error: {e}")
            import traceback
            debug_print(traceback.format_exc())
        finally:
            # Always reset the sync flag, even if there was an error
            self.sync_in_progress = False
            debug_print(f" SYNC DEBUG: Sync lock released")
    
    def on_tab_mousewheel(self, event):
        """Handle mouse wheel scrolling on sheet tabs"""
        if event.delta:
            self.tabs_canvas.xview_scroll(int(-1 * (event.delta / 120)), "units")
        elif event.num == 4:
            self.tabs_canvas.xview_scroll(-1, "units")
        elif event.num == 5:
            self.tabs_canvas.xview_scroll(1, "units")
    
    def nav_to_first_sheet(self):
        """Navigate to the first sheet"""
        if self.wb.sheetnames:
            first_sheet = self.wb.sheetnames[0]
            if first_sheet != self.ws.title:
                self.select_sheet_by_name(first_sheet)
    
    def nav_to_prev_sheet(self):
        """Navigate to the previous sheet"""
        current_idx = self.wb.sheetnames.index(self.ws.title)
        if current_idx > 0:
            prev_sheet = self.wb.sheetnames[current_idx - 1]
            self.select_sheet_by_name(prev_sheet)
    
    def nav_to_next_sheet(self):
        """Navigate to the next sheet"""
        current_idx = self.wb.sheetnames.index(self.ws.title)
        if current_idx < len(self.wb.sheetnames) - 1:
            next_sheet = self.wb.sheetnames[current_idx + 1]
            self.select_sheet_by_name(next_sheet)
    
    def nav_to_last_sheet(self):
        """Navigate to the last sheet"""
        if self.wb.sheetnames:
            last_sheet = self.wb.sheetnames[-1]
            if last_sheet != self.ws.title:
                self.select_sheet_by_name(last_sheet)
    
    def update_sheet_tabs(self):
        """Update the sheet tabs display"""
        # Clear existing tabs
        for widget in self.scrollable_tabs_frame.winfo_children():
            widget.destroy()
        self.sheet_tab_buttons.clear()
        
        # Create tab for each sheet
        for i, sheet_name in enumerate(self.wb.sheetnames):
            self.create_sheet_tab(sheet_name, i)
        
        # Update navigation button states
        self.update_nav_button_states()
        
        # Update canvas scroll region
        self.scrollable_tabs_frame.update_idletasks()
        self.tabs_canvas.configure(scrollregion=self.tabs_canvas.bbox("all"))
    
    def update_nav_button_states(self):
        """Update the state of navigation buttons based on current sheet position"""
        if not hasattr(self, 'nav_first_btn'):
            return
        
        current_idx = self.wb.sheetnames.index(self.ws.title) if self.ws.title in self.wb.sheetnames else 0
        total_sheets = len(self.wb.sheetnames)
        
        # Enable/disable navigation buttons
        is_first = (current_idx == 0)
        is_last = (current_idx == total_sheets - 1)
        
        # Update button states and colors
        for btn, enabled in [
            (self.nav_first_btn, not is_first),
            (self.nav_prev_btn, not is_first),
            (self.nav_next_btn, not is_last),
            (self.nav_last_btn, not is_last)
        ]:
            btn.config(
                state="normal" if enabled else "disabled",
                fg="#000000" if enabled else "#cccccc"
            )
    
    def create_sheet_tab(self, sheet_name, index):
        """Create a single sheet tab with Excel-like styling"""
        # Create frame for the tab
        tab_frame = tk.Frame(self.scrollable_tabs_frame, bg="#e1e1e1")
        tab_frame.pack(side="left", padx=1, pady=2)
        
        # Determine if this is the active tab
        is_active = (sheet_name == self.ws.title)
        
        # Create the main tab button with Excel-like appearance
        tab_btn = tk.Button(
            tab_frame,
            text=sheet_name,
            command=lambda name=sheet_name: self.select_sheet_by_name(name),
            font=("Arial", 10, "bold" if is_active else "normal"),
            padx=15,
            pady=5,
            cursor="hand2",
            **self.active_tab_style if is_active else self.inactive_tab_style
        )
        tab_btn.pack(side="left")
        
        # Add hover effects
        def on_enter(e):
            if not is_active:
                tab_btn.config(bg="#e8e8e8")
        
        def on_leave(e):
            if not is_active:
                tab_btn.config(bg="#f0f0f0")
        
        tab_btn.bind("<Enter>", on_enter)
        tab_btn.bind("<Leave>", on_leave)
        
        # Create context menu button - simplified to avoid font rendering issues
        if len(self.wb.sheetnames) > 1:  # Only show if more than one sheet
            context_btn = tk.Button(
                tab_frame,
                text="...",
                command=lambda name=sheet_name: self.show_sheet_context_menu(name, context_btn),
                font=("Arial", 8),
                bg="#d8d8d8" if is_active else "#e8e8e8",
                fg="#666666",
                padx=2,
                pady=4,
                cursor="hand2",
                relief="flat",
                borderwidth=0,
                width=2
            )
            context_btn.pack(side="left")
            
            # Hover effects for context button
            def ctx_on_enter(e):
                context_btn.config(bg="#c0c0c0")
            
            def ctx_on_leave(e):
                context_btn.config(bg="#d8d8d8" if is_active else "#e8e8e8")
            
            context_btn.bind("<Enter>", ctx_on_enter)
            context_btn.bind("<Leave>", ctx_on_leave)
        else:
            context_btn = None
        
        # Store reference
        self.sheet_tab_buttons[sheet_name] = {
            'frame': tab_frame,
            'button': tab_btn,
            'context': context_btn
        }
        
        # Add right-click context menu to the main button
        tab_btn.bind("<Button-3>", lambda e, name=sheet_name: self.show_sheet_context_menu(name, tab_btn))
    
    def show_sheet_context_menu(self, sheet_name, parent_widget):
        """Show context menu for sheet operations"""
        # Destroy any existing context menu first
        if hasattr(self, 'active_context_menu') and self.active_context_menu:
            try:
                self.active_context_menu.destroy()
            except:
                pass
        
        context_menu = tk.Menu(self.master, tearoff=0)
        
        # Only add rename if it's not the only sheet
        context_menu.add_command(
            label=f"Rename '{sheet_name}'", 
            command=lambda: self.dismiss_context_menu_and_execute(lambda: self.rename_sheet_by_name(sheet_name))
        )
        
        # Only add delete if there's more than one sheet
        if len(self.wb.sheetnames) > 1:
            context_menu.add_separator()
            context_menu.add_command(
                label=f"Delete '{sheet_name}'", 
                command=lambda: self.dismiss_context_menu_and_execute(lambda: self.delete_sheet_by_name(sheet_name))
            )
        
        context_menu.add_separator()
        context_menu.add_command(label="Add New Sheet", command=lambda: self.dismiss_context_menu_and_execute(self.add_sheet_tab))
        
        # Store reference to active menu
        self.active_context_menu = context_menu
        
        # Show menu at cursor position
        try:
            context_menu.tk_popup(parent_widget.winfo_rootx(), parent_widget.winfo_rooty() + parent_widget.winfo_height())
        except Exception as e:
            debug_print(f"Error showing context menu: {e}")
        finally:
            # Ensure menu is properly released
            context_menu.grab_release()
    
    def select_sheet_by_name(self, sheet_name):
        """Select sheet by name (for tab clicking)"""
        if sheet_name in self.wb.sheetnames and sheet_name != self.ws.title:
            if TKSHEET_AVAILABLE:
                self.sync_sheet_to_workbook()  # Save current sheet changes
            
            # Save current sheet state for undo
            old_sheet_name = self.ws.title
            self.add_to_undo_stack('sheet_switch', {
                'old_sheet': old_sheet_name,
                'new_sheet': sheet_name
            })
            
            self.ws = self.wb[sheet_name]
            self.update_display()
    
    def add_sheet_tab(self):
        """Add new sheet via tab interface"""
        name = simpledialog.askstring("Add Sheet", "Enter new sheet name:", initialvalue=f"Sheet{len(self.wb.sheetnames)+1}")
        if not name:
            return
        
        # Check if name already exists
        if name in self.wb.sheetnames:
            messagebox.showerror("Error", f"Sheet '{name}' already exists!")
            return
        
        try:
            # Save action for undo
            self.add_to_undo_stack('sheet_add', {
                'sheet_name': name,
                'previous_active': self.ws.title
            })
            
            # Create new sheet
            new_sheet = self.wb.create_sheet(title=name)
            
            # Add 500x500 grid of empty cells to make the sheet more usable
            for row in range(1, 501):  # Rows 1-500
                for col in range(1, 501):  # Columns A-TE (500 columns)
                    new_sheet.cell(row=row, column=col, value="")
            
            self.ws = new_sheet
            self.update_display()
            # Status update instead of popup
            self.status_main.config(text=f"Added sheet: {name} (500x500 grid initialized)")
        except Exception as e:
            # Remove from undo stack if operation failed
            if self.undo_stack and self.undo_stack[-1][0] == 'sheet_add':
                self.undo_stack.pop()
            messagebox.showerror("Error", f"Failed to add sheet:\n{str(e)}")
    
    def rename_sheet_by_name(self, current_name):
        """Rename sheet by name (for context menu)"""
        new_name = simpledialog.askstring("Rename Sheet", f"Current: {current_name}\nEnter new name:", initialvalue=current_name)
        if not new_name or new_name == current_name:
            return
        
        # Check if name already exists
        if new_name in self.wb.sheetnames:
            messagebox.showerror("Error", f"Sheet '{new_name}' already exists!")
            return
        
        try:
            # Save action for undo
            self.add_to_undo_stack('sheet_rename', {
                'old_name': current_name,
                'new_name': new_name
            })
            
            self.wb[current_name].title = new_name
            if self.ws.title == new_name:  # Update current sheet reference if it's the active one
                self.ws = self.wb[new_name]
            self.update_display()
            # Status update instead of popup
            self.status_main.config(text=f"Renamed to: {new_name}")
        except Exception as e:
            # Remove from undo stack if operation failed
            if self.undo_stack and self.undo_stack[-1][0] == 'sheet_rename':
                self.undo_stack.pop()
            messagebox.showerror("Error", f"Failed to rename:\n{str(e)}")
    
    def delete_sheet_by_name(self, sheet_name):
        """Delete sheet by name (for context menu)"""
        if len(self.wb.sheetnames) == 1:
            messagebox.showwarning("Warning", "Cannot delete the only sheet!")
            return
        
        try:
            # Capture sheet data for undo
            sheet_to_delete = self.wb[sheet_name]
            sheet_data = []
            for row in sheet_to_delete.iter_rows(values_only=True):
                sheet_data.append([cell for cell in row])
            
            # Save action for undo
            self.add_to_undo_stack('sheet_delete', {
                'sheet_name': sheet_name,
                'sheet_data': sheet_data,
                'sheet_index': self.wb.sheetnames.index(sheet_name),
                'was_active': (sheet_name == self.ws.title)
            })
            
            self.wb.remove(self.wb[sheet_name])
            if self.ws.title == sheet_name:  # If we deleted the active sheet
                self.ws = self.wb.active
            self.update_display()
            # Status update instead of popup
            self.status_main.config(text=f"Deleted sheet: {sheet_name}")
        except Exception as e:
            # Remove from undo stack if operation failed
            if self.undo_stack and self.undo_stack[-1][0] == 'sheet_delete':
                self.undo_stack.pop()
            messagebox.showerror("Error", f"Failed to delete:\n{str(e)}")
    
    def setup_treeview(self):
        """Fallback table view using Treeview"""
        container = ttk.Frame(self.master)
        container.pack(expand=True, fill="both", padx=5, pady=5)
        
        # Scrollbars
        vsb = ttk.Scrollbar(container, orient="vertical")
        vsb.pack(side="right", fill="y")
        hsb = ttk.Scrollbar(container, orient="horizontal")
        hsb.pack(side="bottom", fill="x")
        
        self.tree = ttk.Treeview(container, yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.tree.pack(expand=True, fill="both")
        
        vsb.config(command=self.tree.yview)
        hsb.config(command=self.tree.xview)
        
        # Note about tksheet
        note = ttk.Label(container, text="Note: Install 'tksheet' for direct cell editing support", 
                        foreground="red", font=("Arial", 10, "bold"))
        note.place(relx=0.5, rely=0.5, anchor="center")
    
    def update_display(self, force_recreate_tksheet=False):
        """Update the display with current sheet data
        
        Args:
            force_recreate_tksheet: If True, completely recreate tksheet widget (for file loads)
        """
        debug_print(f" UPDATE_DISPLAY: Starting display update... (force_recreate={force_recreate_tksheet})")
        if TKSHEET_AVAILABLE:
            debug_print(f" UPDATE_DISPLAY: Calling update_tksheet_display()...")
            self.update_tksheet_display(force_recreate=force_recreate_tksheet)
            debug_print(f" UPDATE_DISPLAY: tksheet display updated")
        else:
            self.update_treeview_display()
        
        # Update sheet tabs
        debug_print(f" UPDATE_DISPLAY: Updating sheet tabs...")
        self.update_sheet_tabs()
        debug_print(f" UPDATE_DISPLAY: Sheet tabs updated")
        
        # Update status with undo information and selected cell
        undo_count = len(self.undo_stack)
        
        # Get current selected cell info
        selected_cell = "None"
        try:
            if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                selected = self.table.get_currently_selected()
                if selected and hasattr(selected, 'row') and hasattr(selected, 'column'):
                    row, col = selected.row, selected.column
                    if row is not None and col is not None:
                        selected_cell = f"{get_column_letter(col + 1)}{row + 1}"
        except:
            pass
        
        # Update main status
        base_status = f"Sheet: {self.ws.title} | Rows: {self.ws.max_row} | Columns: {self.ws.max_column}"
        if undo_count > 0:
            self.status_main.config(text=f"{base_status} | {undo_count} operations can be undone")
        else:
            self.status_main.config(text=base_status)
        
        # Update selected cell with color (only the cell reference)
        self.status_selected.config(text=selected_cell)
        
        # Update context operations based on selection
        if hasattr(self, 'context_frame'):
            self.master.after(100, self.update_context_operations)
    
    def update_tksheet_display(self, force_recreate=False):
        """Update tksheet widget
        
        Args:
            force_recreate: If True, reset the tksheet widget to clear its internal state
                          (No longer destroys/recreates - just clears data for performance)
        """
        debug_print(f" TKSHEET_DISPLAY: Starting... (force_recreate={force_recreate})")
        
        # OPTIMIZED: Instead of destroying and recreating widget (expensive),
        # just clear its data and internal state (fast)
        if force_recreate and hasattr(self, 'table'):
            debug_print(f" TKSHEET_DISPLAY: Resetting tksheet widget state...")
            try:
                # Clear all data and reset state without destroying widget
                self.table.set_sheet_data([[]])  # Clear data
                self.table.headers([])  # Clear headers
                self.table.row_index([])  # Clear row index
                self.table.dehighlight_all()  # Clear any highlights
                self.table.deselect("all")  # Clear selection
                debug_print(f" TKSHEET_DISPLAY: Widget state reset complete")
            except Exception as e:
                debug_print(f" TKSHEET_DISPLAY: Error resetting widget state: {e}")
                # If reset fails, fall back to recreation (rare case)
                debug_print(f" TKSHEET_DISPLAY: Falling back to widget recreation...")
                try:
                    self.table.destroy()
                    self.setup_tksheet()
                    debug_print(f" TKSHEET_DISPLAY: Widget recreated")
                except Exception as e2:
                    debug_print(f" TKSHEET_DISPLAY: Recreation also failed: {e2}")
        
        data = []
        
        # Check if workbook actually has data or is just default empty (1x1)
        has_real_data = False
        if self.ws.max_row and self.ws.max_column:
            # Check if there's actual data beyond the default 1x1 empty cell
            if self.ws.max_row > 1 or self.ws.max_column > 1:
                has_real_data = True
            elif self.ws.max_row == 1 and self.ws.max_column == 1:
                # Check if the single cell actually has data
                cell = self.ws.cell(1, 1)
                if cell.value is not None and str(cell.value).strip() != "":
                    has_real_data = True
        
        debug_print(f" TKSHEET_DISPLAY: has_real_data={has_real_data}")
        
        if has_real_data:
            debug_print(f" Loading data from used range: {self.ws.max_row}x{self.ws.max_column}")
            
            # Safety check: If dimensions are still huge after cleanup, limit the display
            if self.ws.max_row > 1000 or self.ws.max_column > 1000:
                debug_print(f" WARNING: Dimensions still large! Limiting display to first 100x100")
                max_display_rows = min(self.ws.max_row, 100)
                max_display_cols = min(self.ws.max_column, 100)
                debug_print(f" TKSHEET_DISPLAY: Starting iter_rows for limited display...")
                # OPTIMIZED: Use list() directly instead of list comprehension per row
                data = list(self.ws.iter_rows(max_row=max_display_rows, max_col=max_display_cols, values_only=True))
                # Convert tuples to lists and handle None values
                data = [[cell if cell is not None else "" for cell in row] for row in data]
                debug_print(f" TKSHEET_DISPLAY: iter_rows completed")
                debug_print(f" Limited display to {len(data)} rows")
            else:
                # OPTIMIZED: Load all data at once instead of appending row by row
                debug_print(f" TKSHEET_DISPLAY: Starting iter_rows for normal load...")
                data = list(self.ws.iter_rows(max_row=self.ws.max_row, max_col=self.ws.max_column, values_only=True))
                # Convert tuples to lists and handle None values in bulk
                data = [[cell if cell is not None else "" for cell in row] for row in data]
                debug_print(f" TKSHEET_DISPLAY: iter_rows completed")
                debug_print(f" Loaded {len(data)} rows with actual data")
        else:
            # Empty worksheet - create a visual grid for Excel-like experience
            debug_print(f" Empty/new worksheet - creating 500x500 visual grid")
            # OPTIMIZED: Use more efficient grid creation
            empty_row = [""] * 500
            data = [empty_row[:] for _ in range(500)]  # 500 rows x 500 cols
        
        debug_print(f" TKSHEET_DISPLAY: Setting up headers...")
        # Set headers (column letters)
        if has_real_data:
            max_col = min(self.ws.max_column, 100) if self.ws.max_column else 500
        else:
            max_col = 500  # 500 columns for empty sheets
        
        # OPTIMIZED: Generate headers efficiently
        headers = [get_column_letter(i+1) for i in range(max_col)]
        
        # OPTIMIZED: Generate row index efficiently
        row_index = [str(i+1) for i in range(len(data))]
        
        # OPTIMIZED: Set all data in one batch to minimize tksheet updates
        debug_print(f" TKSHEET_DISPLAY: Setting all data on table in batch...")
        self.table.headers(headers)
        self.table.row_index(row_index)
        self.table.set_sheet_data(data)
        self.table.set_all_column_widths(120)
        debug_print(f" TKSHEET_DISPLAY: All data set")
        
        # EXPERIMENTAL: Don't call refresh() at all - let tksheet update naturally
        # The refresh() call might be causing the hang when loading files
        debug_print(f" TKSHEET_DISPLAY: Skipping refresh - letting tksheet update naturally")
        try:
            # Just process pending events, but don't force refresh
            self.master.update_idletasks()
            debug_print(f" TKSHEET_DISPLAY: Processed pending events")
        except Exception as e:
            debug_print(f" TKSHEET_DISPLAY: update_idletasks error (non-fatal): {e}")
        
        debug_print(f" Display updated: {len(data)} rows, {len(headers)} columns")
    
    def _deferred_tksheet_refresh(self):
        """Deferred tksheet refresh - called after event loop processes data"""
        debug_print(f" DEFERRED_REFRESH: Starting tksheet refresh...")
        try:
            self.table.refresh()  # Refresh tksheet display
            debug_print(f" DEFERRED_REFRESH: Refresh completed")
        except Exception as e:
            debug_print(f" DEFERRED_REFRESH: Error (non-fatal): {e}")
    
    def update_treeview_display(self):
        """Update treeview widget (fallback)"""
        # Clear existing
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Setup columns
        max_col = self.ws.max_column or 1
        columns = [get_column_letter(i+1) for i in range(max_col)]
        self.tree["columns"] = columns
        self.tree["show"] = "tree headings"
        
        self.tree.column("#0", width=50, anchor="center")
        self.tree.heading("#0", text="Row")
        
        for col in columns:
            self.tree.column(col, width=100, anchor="w")
            self.tree.heading(col, text=col)
        
        # Insert data
        for idx, row in enumerate(self.ws.iter_rows(values_only=True), start=1):
            values = [cell if cell is not None else "" for cell in row]
            self.tree.insert("", "end", text=str(idx), values=values)
    
    # File Operations
    def new_file(self):
        """Create a new file"""
        if self.check_unsaved_changes():
            self.wb = Workbook()
            self.initialize_empty_workbook()
            self.ws = self.wb.active
            self.path = None
            self.has_unsaved_changes = False  # New file, no unsaved changes yet
            self.update_window_title()
            self.undo_stack.clear()
            self.update_display()
            self.status_main.config(text="New file created with 500x500 cells")
    
    def check_unsaved_changes(self):
        """Check if there are unsaved changes and prompt user"""
        if self.has_unsaved_changes:
            result = messagebox.askyesnocancel(
                "Unsaved Changes", 
                "Do you want to save changes before closing?",
                icon='warning'
            )
            if result is True:  # Yes - save
                self.save()
                return True
            elif result is False:  # No - don't save
                return True
            else:  # Cancel - don't close
                return False
        return True
    
    def on_closing(self):
        """Handle window closing event"""
        if self.check_unsaved_changes():
            self.save_settings()
            self.master.quit()
    
    def toggle_auto_save(self):
        """Toggle auto-save functionality - DISABLED"""
        debug_print(" Auto-save toggle DISABLED - feature permanently off")
        messagebox.showinfo("Auto-Save Disabled", 
                          "Auto-save has been permanently disabled.\n\n"
                          "Please save manually with:\n"
                          "• Ctrl+S\n"
                          "• File → Save")
        return  # Auto-save feature removed
    
    def update_recent_files_menu(self):
        """Update the recent files menu"""
        if not hasattr(self, 'recent_menu'):
            return
        
        # Clear existing items
        self.recent_menu.delete(0, 'end')
        
        if not self.recent_files:
            self.recent_menu.add_command(label="No recent files", state="disabled")
            return
        
        for i, file_path in enumerate(self.recent_files):
            if os.path.exists(file_path):
                filename = os.path.basename(file_path)
                self.recent_menu.add_command(
                    label=f"{i+1}. {filename}", 
                    command=lambda path=file_path: self._load_recent_file_and_close_menu(path),
                    accelerator=f"Ctrl+{i+1}" if i < 9 else ""
                )
        
        self.recent_menu.add_separator()
        self.recent_menu.add_command(label="Clear Recent Files", command=self._clear_recent_files_and_close_menu)
    
    def _load_recent_file_and_close_menu(self, file_path):
        """Wrapper to close menu before loading recent file"""
        # Unpost all menus to close them
        try:
            self.master.tk.call("tk", "menubar", self.master, "")  # Release menubar
        except:
            pass
        # Schedule the actual file load after menu closes
        self.master.after(50, lambda: self.load_recent_file(file_path))
    
    def _clear_recent_files_and_close_menu(self):
        """Wrapper to close menu before clearing recent files"""
        # Unpost all menus to close them
        try:
            self.master.tk.call("tk", "menubar", self.master, "")  # Release menubar
        except:
            pass
        # Schedule the actual clear after menu closes
        self.master.after(50, self.clear_recent_files)
    
    def load_recent_file(self, file_path):
        """Load a file from recent files list"""
        if os.path.exists(file_path):
            if self.check_unsaved_changes():
                # Show progress indicator
                self.show_progress("Loading recent file...")
                self.master.update()
                
                try:
                    self.wb = load_workbook(file_path)
                    self.ws = self.wb.active
                    self.path = file_path
                    self.update_window_title()
                    self.add_to_recent_files(file_path)
                    self.update_recent_files_menu()
                    self.update_display()
                    self.status_main.config(text=f"Loaded: {os.path.basename(file_path)}")
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to load file:\n{str(e)}")
                finally:
                    self.hide_progress()
        else:
            messagebox.showerror("Error", f"File not found: {file_path}")
            self.recent_files.remove(file_path)
            self.update_recent_files_menu()
            self.save_settings()
    
    def clear_recent_files(self):
        """Clear the recent files list"""
        self.recent_files.clear()
        self.update_recent_files_menu()
        self.save_settings()
        self.status_main.config(text="Recent files cleared")
    
    def load_file(self):
        if self.check_unsaved_changes():
            path = filedialog.askopenfilename(
                title="Open Excel File",
                filetypes=[("Excel files", "*.xlsx *.xlsm"), ("All files", "*.*")]
            )
            if not path:
                return
                
            debug_print(f" LOAD_FILE: Starting to load {path}")
            
            # EXPERIMENTAL: Use regular after() with short delay instead of after_idle
            # after_idle might not properly resume event loop after completion
            debug_print(f" LOAD_FILE: Scheduling load with 100ms delay...")
            self.master.after(100, lambda: self._do_load_wrapper(path))
    
    def _do_load_wrapper(self, path):
        """Wrapper that calls _do_load_file and logs when it returns"""
        debug_print(f" LOAD_WRAPPER: About to call _do_load_file...")
        self._do_load_file(path)
        debug_print(f" LOAD_WRAPPER: _do_load_file returned! Scheduling follow-up check...")
        # Schedule a check to run after this to see if event loop is working
        self.master.after(100, lambda: debug_print(f" LOAD_WRAPPER: Event loop is ALIVE 100ms after load!"))
    
    def _do_load_file(self, path):
        """Actually load the file - called after file dialog cleanup"""
        try:
            # Show progress indicator
            self.show_progress("Loading file...")
            self.master.update_idletasks()  # Only process idle tasks, not full update
            
            debug_print(f" LOAD_FILE: Loading workbook...")
            # OPTIMIZED: Load with data_only=True to avoid formula calculation overhead
            # This significantly speeds up loading for files with formulas
            self.wb = load_workbook(path, data_only=True, keep_vba=False)
            self.ws = self.wb.active
            debug_print(f" LOAD_FILE: Workbook loaded, dimensions: {self.ws.max_row}x{self.ws.max_column}")
            
            # CRITICAL FIX: Clean up empty cells from old file format
            # Old files might have 500x500 empty cells, causing slow loading
            debug_print(f" LOAD_FILE: Calling cleanup_empty_cells()...")
            self.cleanup_empty_cells()
            debug_print(f" LOAD_FILE: Cleanup done")
            
            self.path = path
            self.has_unsaved_changes = False  # File just loaded, no unsaved changes
            debug_print(f" LOAD_FILE: Updating window title...")
            self.update_window_title()
            debug_print(f" LOAD_FILE: Adding to recent files...")
            self.add_to_recent_files(path)
            debug_print(f" LOAD_FILE: Updating recent files menu...")
            self.update_recent_files_menu()
            debug_print(f" LOAD_FILE: Updating display...")
            # CRITICAL: Force complete tksheet recreation when loading files
            # This clears any accumulated internal state that causes hanging
            self.update_display(force_recreate_tksheet=True)
            debug_print(f" LOAD_FILE: Display updated")
            
            # Let event loop handle updates naturally (deferred refresh is scheduled)
            # Don't force immediate update() as it may cause tksheet to hang
            
            # Auto-save disabled - no timer started
            # Status update instead of popup
            self.status_main.config(text=f"Loaded: {os.path.basename(path)}")
            debug_print(f" LOAD_FILE: File loaded successfully!")
            debug_print(f" LOAD_FILE: About to exit try block...")
        except Exception as e:
            debug_print(f" LOAD_FILE ERROR: {str(e)}")
            messagebox.showerror("Error", f"Failed to load file:\n{str(e)}")
        finally:
            debug_print(f" LOAD_FILE: Entered finally block")
            self.hide_progress()
            debug_print(f" LOAD_FILE: Progress hidden")
            
            # CRITICAL: Force event loop to process everything and resume normal operation
            debug_print(f" LOAD_FILE: Forcing event loop to process all pending events...")
            try:
                self.master.update()  # Force process ALL events
                debug_print(f" LOAD_FILE: Event loop processing complete")
            except Exception as e:
                debug_print(f" LOAD_FILE: Event loop error: {e}")
            
            debug_print(f" LOAD_FILE: Exiting _do_load_file() - returning control to event loop")
    
    def cleanup_empty_cells(self):
        """Remove empty cells from worksheet to fix files created with old format.
        
        DISABLED FOR NOW - Direct approach: Just refuse to load huge files.
        User should manually clean them or we'll show warning.
        """
        if not self.ws.max_row or not self.ws.max_column:
            debug_print(f" No cleanup needed - worksheet is already empty")
            return
            
        debug_print(f" CLEANUP: Checking worksheet with dimensions {self.ws.max_row}x{self.ws.max_column}")
        
        # If dimensions are huge, show warning and don't try to load
        if self.ws.max_row > 1000 or self.ws.max_column > 1000:
            debug_print(f" WARNING: File has huge dimensions {self.ws.max_row}x{self.ws.max_column}")
            debug_print(f" This file likely has the old format with many empty cells.")
            debug_print(f" Display will be limited to first 100x100 for safety.")
            # Don't try to cleanup - it's still too slow even with _cells
            # Just let the display function handle it with safety limits
        else:
            debug_print(f" Dimensions OK - file will load normally")
    
    def save(self):
        if TKSHEET_AVAILABLE:
            self.sync_sheet_to_workbook()
        
        if not self.path:
            self.save_as()
            return
            
        # Show progress indicator
        self.show_progress("Saving file...")
        self.master.update()
        
        try:
            self.wb.save(self.path)
            self.last_save_time = time.time()
            self.has_unsaved_changes = False  # Clear unsaved changes flag
            self.update_window_title()
            # Status update instead of popup
            self.status_main.config(text=f"Saved: {os.path.basename(self.path)} at {datetime.now().strftime('%H:%M:%S')}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save:\n{str(e)}")
        finally:
            self.hide_progress()
    
    def show_progress(self, message):
        """Show a progress indicator"""
        # Check if progress frame exists AND is still valid (not destroyed)
        if not hasattr(self, 'progress_frame') or not self.progress_frame.winfo_exists():
            debug_print(f" SHOW_PROGRESS: Creating new progress dialog...")
            self.progress_frame = tk.Toplevel(self.master)
            self.progress_frame.title("Please Wait")
            self.progress_frame.geometry("300x100")
            self.progress_frame.resizable(False, False)
            self.progress_frame.transient(self.master)
            self.progress_frame.grab_set()
            
            # Center the progress window
            self.progress_frame.update_idletasks()
            x = (self.progress_frame.winfo_screenwidth() // 2) - (300 // 2)
            y = (self.progress_frame.winfo_screenheight() // 2) - (100 // 2)
            self.progress_frame.geometry(f"300x100+{x}+{y}")
            
            # Progress label
            self.progress_label = ttk.Label(self.progress_frame, text="", font=("Arial", 10))
            self.progress_label.pack(pady=20)
            
            # Progress bar
            self.progress_bar = ttk.Progressbar(self.progress_frame, mode='indeterminate')
            self.progress_bar.pack(pady=10, padx=20, fill="x")
            self.progress_bar.start(10)
            debug_print(f" SHOW_PROGRESS: New progress dialog created")
        
        self.progress_label.config(text=message)
        self.progress_frame.deiconify()
    
    def hide_progress(self):
        """Hide the progress indicator"""
        debug_print(f" HIDE_PROGRESS: Starting...")
        if hasattr(self, 'progress_frame'):
            debug_print(f" HIDE_PROGRESS: Stopping progress bar...")
            try:
                if hasattr(self, 'progress_bar'):
                    self.progress_bar.stop()
                    debug_print(f" HIDE_PROGRESS: Progress bar stopped")
            except Exception as e:
                debug_print(f" HIDE_PROGRESS: Error stopping progress bar: {e}")
            
            debug_print(f" HIDE_PROGRESS: Destroying progress frame...")
            try:
                self.progress_frame.destroy()
                debug_print(f" HIDE_PROGRESS: Progress frame destroyed")
            except Exception as e:
                debug_print(f" HIDE_PROGRESS: Error destroying progress frame: {e}")
            
            # CRITICAL: Delete the attributes so show_progress() will recreate them
            debug_print(f" HIDE_PROGRESS: Deleting progress widget attributes...")
            if hasattr(self, 'progress_frame'):
                delattr(self, 'progress_frame')
            if hasattr(self, 'progress_label'):
                delattr(self, 'progress_label')
            if hasattr(self, 'progress_bar'):
                delattr(self, 'progress_bar')
            debug_print(f" HIDE_PROGRESS: Progress widgets cleaned up")
        else:
            debug_print(f" HIDE_PROGRESS: No progress frame to hide")
    
    def save_as(self):
        if TKSHEET_AVAILABLE:
            self.sync_sheet_to_workbook()
        
        path = filedialog.asksaveasfilename(
            title="Save Excel File As",
            defaultextension=".xlsx",
            filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            self.wb.save(path)
            self.path = path
            self.has_unsaved_changes = False  # Clear unsaved changes flag
            self.update_window_title()
            self.add_to_recent_files(path)
            self.update_recent_files_menu()
            self.update_display()
            self.start_auto_save_timer()
            # Status update instead of popup
            self.status_main.config(text=f"Saved as: {path}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save:\n{str(e)}")
    
    # Clipboard Operations
    def copy_selection(self):
        """Enhanced copy operation that handles single cells, ranges, full rows/columns"""
        debug_print("📋 COPY DEBUG: copy_selection() called")
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            try:
                # Get all selected areas - tksheet can have multiple selections
                selected_areas = []
                
                # Try to get highlighted cells (multiple selection support)
                try:
                    highlighted = self.table.get_highlighted_cells()
                    debug_print(f" COPY DEBUG: highlighted cells = {highlighted}")
                    if highlighted:
                        selected_areas.extend(highlighted)
                except Exception as e:
                    debug_print(f" COPY DEBUG: highlighted cells error: {e}")
                    pass
                
                # Try to get currently selected area
                try:
                    current_selected = self.table.get_currently_selected()
                    debug_print(f" COPY DEBUG: current_selected = {current_selected}")
                    if current_selected:
                        # CRITICAL FIX: Check for box attribute (drag selection)
                        if hasattr(current_selected, 'box') and current_selected.box:
                            box = current_selected.box
                            debug_print(f" COPY DEBUG: Box selection detected from_r={box.from_r}, from_c={box.from_c}, upto_r={box.upto_r}, upto_c={box.upto_c}")
                            # Add all cells in the box (note: upto is exclusive)
                            for row in range(box.from_r, box.upto_r):
                                for col in range(box.from_c, box.upto_c):
                                    selected_areas.append((row, col))
                        elif hasattr(current_selected, 'row') and hasattr(current_selected, 'column'):
                            # Single cell selection
                            debug_print(f" COPY DEBUG: Single cell at row={current_selected.row}, col={current_selected.column}")
                            selected_areas.append((current_selected.row, current_selected.column))
                        elif hasattr(current_selected, 'rows') and hasattr(current_selected, 'columns'):
                            # Range selection 
                            debug_print(f" COPY DEBUG: Range selection rows={current_selected.rows}, cols={current_selected.columns}")
                            for row in current_selected.rows:
                                for col in current_selected.columns:
                                    selected_areas.append((row, col))
                except Exception as e:
                    debug_print(f" COPY DEBUG: current_selected error: {e}")
                    import traceback
                    traceback.print_exc()
                    pass
                
                debug_print(f" COPY DEBUG: selected_areas so far = {selected_areas}")
                
                debug_print(f" COPY DEBUG: selected_areas so far = {selected_areas}")
                
                # Try to get selected rows/columns
                try:
                    selected_rows = self.table.get_selected_rows()
                    selected_cols = self.table.get_selected_columns()
                    debug_print(f" COPY DEBUG: selected_rows = {selected_rows}, selected_cols = {selected_cols}")
                    
                    if selected_rows:
                        # Full row(s) selected
                        max_col = self.ws.max_column or 1
                        for row in selected_rows:
                            for col in range(max_col):
                                selected_areas.append((row, col))
                        self._copy_type = 'rows'
                        self._copied_rows = selected_rows
                    elif selected_cols:
                        # Full column(s) selected  
                        max_row = self.ws.max_row or 1
                        for col in selected_cols:
                            for row in range(max_row):
                                selected_areas.append((row, col))
                        self._copy_type = 'columns'
                        self._copied_cols = selected_cols
                    else:
                        self._copy_type = 'cells'
                except Exception as e:
                    debug_print(f" COPY DEBUG: rows/cols selection error: {e}")
                    self._copy_type = 'cells'
                
                debug_print(f" COPY DEBUG: Final selected_areas = {selected_areas}, copy_type = {self._copy_type}")
                
                if selected_areas:
                    # Remove duplicates while preserving order
                    unique_areas = []
                    seen = set()
                    for area in selected_areas:
                        if area not in seen:
                            unique_areas.append(area)
                            seen.add(area)
                    
                    # Extract data from selected areas
                    copied_data = []
                    rows_data = {}
                    
                    for row, col in unique_areas:
                        # Read from tksheet (live visual data) as authoritative source
                        try:
                            cell_data = self.table.get_cell_data(row, col)
                            cell_data = cell_data if cell_data is not None else ''
                            debug_print(f" COPY DEBUG: Cell ({row}, {col}) data from tksheet = '{cell_data}'")
                        except Exception as e:
                            # Fallback to openpyxl if tksheet fails
                            try:
                                excel_row = row + 1
                                excel_col = col + 1
                                cell_value = self.ws.cell(row=excel_row, column=excel_col).value
                                cell_data = cell_value if cell_value is not None else ''
                                debug_print(f" COPY DEBUG: Cell ({row}, {col}) data from openpyxl (fallback) = '{cell_data}'")
                            except:
                                cell_data = ''
                                debug_print(f" COPY DEBUG: Cell ({row}, {col}) failed both sources, using empty")
                        
                        if row not in rows_data:
                            rows_data[row] = {}
                        rows_data[row][col] = cell_data if cell_data is not None else ""
                    
                    debug_print(f" COPY DEBUG: rows_data = {rows_data}")
                    
                    # Convert to structured format for clipboard
                    if self._copy_type == 'rows':
                        # For full rows, preserve row structure
                        for row in sorted(rows_data.keys()):
                            row_values = []
                            for col in sorted(rows_data[row].keys()):
                                row_values.append(str(rows_data[row][col]))
                            copied_data.append('\t'.join(row_values))
                        clipboard_text = '\n'.join(copied_data)
                        self.status_main.config(text=f"Copied {len(self._copied_rows)} row(s) to clipboard")
                        
                    elif self._copy_type == 'columns':
                        # For full columns, need to transpose data
                        max_row = max(rows_data.keys()) if rows_data else 0
                        for row_idx in range(max_row + 1):
                            if row_idx in rows_data:
                                row_values = []
                                for col in sorted(self._copied_cols):
                                    if col in rows_data[row_idx]:
                                        row_values.append(str(rows_data[row_idx][col]))
                                    else:
                                        row_values.append("")
                                copied_data.append('\t'.join(row_values))
                        clipboard_text = '\n'.join(copied_data)
                        self.status_main.config(text=f"Copied {len(self._copied_cols)} column(s) to clipboard")
                        
                    else:
                        # For cell ranges, create rectangular data
                        min_row = min(row for row, col in unique_areas)
                        max_row = max(row for row, col in unique_areas)
                        min_col = min(col for row, col in unique_areas)
                        max_col = max(col for row, col in unique_areas)
                        
                        for row in range(min_row, max_row + 1):
                            row_values = []
                            for col in range(min_col, max_col + 1):
                                if (row, col) in unique_areas:
                                    # Use data from rows_data (already read from openpyxl)
                                    if row in rows_data and col in rows_data[row]:
                                        cell_data = rows_data[row][col]
                                    else:
                                        cell_data = ""
                                    row_values.append(str(cell_data) if cell_data is not None else "")
                                else:
                                    row_values.append("")
                            copied_data.append('\t'.join(row_values))
                        clipboard_text = '\n'.join(copied_data)
                        
                        if len(unique_areas) == 1:
                            self.status_main.config(text=f"Copied cell to clipboard")
                        else:
                            self.status_main.config(text=f"Copied {len(unique_areas)} cells to clipboard")
                    
                    # Store the copied data and clear/set clipboard
                    self._copied_data = copied_data
                    self._is_cut = False  # Reset cut flag for regular copy
                    self._cut_cells = []  # Clear cut cells list
                    self.master.clipboard_clear()
                    self.master.clipboard_append(clipboard_text)
                    debug_print(f" COPY DEBUG: Copied to clipboard: '{clipboard_text}'")
                    debug_print(f" COPY DEBUG: Stored _copied_data with {len(copied_data)} rows")
                    
                else:
                    debug_print("📋 COPY DEBUG: No selected_areas found!")
                    self.status_main.config(text="No selection to copy")
                    
            except Exception as e:
                debug_print(f"Copy error: {e}")
                import traceback
                traceback.print_exc()
                self.status_main.config(text="Copy failed")
        else:
            # Fallback for non-tksheet mode
            self.status_main.config(text="Copy requires tksheet support")

    def cut_selection(self):
        """Cut selected cells to clipboard - cells will be cleared on paste"""
        debug_print("✂️ CUT DEBUG: cut_selection() called")
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            try:
                # Cancel any pending edit first to ensure we read actual cell values
                if self.current_edit_session:
                    debug_print("✂️ CUT DEBUG: Cancelling pending edit session before cut")
                    self.current_edit_session = None
                
                # Get all selected areas first to check if they have content
                selected_areas = []
                
                try:
                    highlighted = self.table.get_highlighted_cells()
                    if highlighted:
                        selected_areas.extend(highlighted)
                except:
                    pass
                
                try:
                    current_selected = self.table.get_currently_selected()
                    if current_selected:
                        if hasattr(current_selected, 'box') and current_selected.box:
                            box = current_selected.box
                            for row in range(box.from_r, box.upto_r):
                                for col in range(box.from_c, box.upto_c):
                                    selected_areas.append((row, col))
                        elif hasattr(current_selected, 'row') and hasattr(current_selected, 'column'):
                            selected_areas.append((current_selected.row, current_selected.column))
                except:
                    pass
                
                # Check if any selected cell has non-empty content
                unique_areas = list(set(selected_areas))
                has_content = False
                cells_with_content = []
                
                for row, col in unique_areas:
                    # Get cell data from tksheet (live visual data) as authoritative source
                    cell_data = None
                    try:
                        cell_data = self.table.get_cell_data(row, col)
                        cell_data = cell_data if cell_data is not None else ''
                        debug_print(f"️ CUT DEBUG: Cell ({row}, {col}) from tksheet = '{cell_data}'")
                    except Exception as e:
                        debug_print(f"️ CUT DEBUG: Error reading cell ({row}, {col}) from tksheet: {e}")
                        # Fallback to openpyxl
                        try:
                            openpyxl_row = row + 1
                            openpyxl_col = col + 1
                            cell_value = self.ws.cell(row=openpyxl_row, column=openpyxl_col).value
                            cell_data = cell_value if cell_value is not None else ''
                            debug_print(f"️ CUT DEBUG: Cell ({row}, {col}) from openpyxl fallback = '{cell_data}'")
                        except:
                            cell_data = ''
                            debug_print(f"️ CUT DEBUG: Cell ({row}, {col}) failed both sources")
                    
                    if cell_data and str(cell_data).strip():
                        has_content = True
                        cells_with_content.append((row, col, cell_data))
                
                debug_print(f"️ CUT DEBUG: Found {len(cells_with_content)} cells with content out of {len(unique_areas)} selected")
                
                if not has_content:
                    debug_print("✂️ CUT DEBUG: No content to cut - all cells are empty")
                    self.status_main.config(text="Cannot cut empty cells")
                    return
                
                # First, copy the selection
                self.copy_selection()
                
                # IMMEDIATELY clear the cells (Excel-like behavior)
                debug_print(f"️ CUT DEBUG: Immediately clearing {len(unique_areas)} cells")
                cut_affected_cells = []
                
                for row, col in unique_areas:
                    # Convert to 1-based for openpyxl
                    excel_row = row + 1
                    excel_col = col + 1
                    
                    # Get old value for undo
                    old_value = self.ws.cell(row=excel_row, column=excel_col).value
                    old_value = old_value if old_value is not None else ''
                    
                    # Clear in tksheet
                    self.table.set_cell_data(row, col, "")
                    
                    # Clear in openpyxl
                    self.ws.cell(row=excel_row, column=excel_col).value = ""
                    
                    cut_affected_cells.append((row, col, old_value, ""))
                    debug_print(f"️ CUT DEBUG: Cleared cell ({row}, {col}) with value '{old_value}'")
                
                # Add cut operation to undo stack
                if cut_affected_cells:
                    self.add_to_undo_stack('paste_operation', {
                        'type': 'cut_clear',
                        'affected_cells': cut_affected_cells
                    })
                
                # Mark as cut operation (paste will just place data, not clear source)
                self._is_cut = True
                self._cut_cells = []  # Empty since we already cleared
                
                debug_print(f"️ CUT DEBUG: Cut complete - cleared {len(unique_areas)} cells immediately")
                self.status_main.config(text=f"Cut {len(unique_areas)} cell(s) - ready to paste")
                
            except Exception as e:
                debug_print(f"Cut error: {e}")
                import traceback
                traceback.print_exc()
                self.status_main.config(text="Cut failed")
        else:
            self.status_main.config(text="Cut requires tksheet support")

    def paste_selection(self):
        """Enhanced paste operation that handles ranges, full rows/columns"""
        debug_print("📌 PASTE DEBUG: paste_selection() called")
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            try:
                clipboard_text = self.master.clipboard_get()
                debug_print(f"📌 PASTE DEBUG: clipboard_text = '{clipboard_text}'")
                if not clipboard_text:
                    self.status_main.config(text="Clipboard is empty")
                    return
                
                # Parse clipboard data
                lines = clipboard_text.strip().split('\n')
                data_rows = []
                for line in lines:
                    if '\t' in line:
                        data_rows.append(line.split('\t'))
                    else:
                        data_rows.append([line])
                
                debug_print(f"📌 PASTE DEBUG: data_rows = {data_rows}")
                
                if not data_rows:
                    self.status_main.config(text="No valid data to paste")
                    return
                
                # Get current selection/target
                current_selected = self.table.get_currently_selected()
                selected_rows = []
                selected_cols = []
                
                debug_print(f"📌 PASTE DEBUG: current_selected = {current_selected}")
                
                # CRITICAL FIX: Detect column/row selection by type_ attribute OR by box spanning full rows/columns
                is_column_selection = False
                is_row_selection = False
                
                if current_selected and hasattr(current_selected, 'type_'):
                    debug_print(f"📌 PASTE DEBUG: current_selected.type_ = '{current_selected.type_}'")
                    
                    # Check if type explicitly says columns or rows
                    if current_selected.type_ == 'columns':
                        is_column_selection = True
                        # Get column index from current_selected
                        if hasattr(current_selected, 'column'):
                            selected_cols = [current_selected.column]
                        # Also try to get from box
                        if hasattr(current_selected, 'box') and current_selected.box:
                            box = current_selected.box
                            selected_cols = list(range(box.from_c, box.upto_c))
                        debug_print(f"📌 PASTE DEBUG: Detected column selection (type=columns), cols = {selected_cols}")
                        
                    elif current_selected.type_ == 'rows':
                        is_row_selection = True
                        # Get row index from current_selected
                        if hasattr(current_selected, 'row'):
                            selected_rows = [current_selected.row]
                        # Also try to get from box
                        if hasattr(current_selected, 'box') and current_selected.box:
                            box = current_selected.box
                            selected_rows = list(range(box.from_r, box.upto_r))
                        debug_print(f"📌 PASTE DEBUG: Detected row selection (type=rows), rows = {selected_rows}")
                    
                    # CRITICAL: Also check if box spans full rows/columns (even if type='cells')
                    # This handles the case where clicking column header reports type='cells' but box covers all rows
                    elif current_selected.type_ == 'cells' and hasattr(current_selected, 'box') and current_selected.box:
                        box = current_selected.box
                        total_rows = self.table.total_rows()
                        total_cols = self.table.total_columns()
                        
                        debug_print(f"📌 PASTE DEBUG: Box spans from_r={box.from_r}, upto_r={box.upto_r}, from_c={box.from_c}, upto_c={box.upto_c}")
                        debug_print(f"📌 PASTE DEBUG: Total rows={total_rows}, total_cols={total_cols}")
                        
                        # Calculate the span width and height
                        row_span = box.upto_r - box.from_r
                        col_span = box.upto_c - box.from_c
                        
                        debug_print(f"📌 PASTE DEBUG: row_span={row_span}, col_span={col_span}")
                        debug_print(f"📌 PASTE DEBUG: Selection spans {row_span}/{total_rows} rows and {col_span}/{total_cols} columns")
                        
                        # Check if box spans ALL rows (column selection)
                        # A column selection should span all (or most) rows but only a few columns
                        if row_span >= total_rows and col_span < total_cols:
                            is_column_selection = True
                            selected_cols = list(range(box.from_c, box.upto_c))
                            debug_print(f"📌 PASTE DEBUG: ✅ Detected FULL COLUMN selection (spans {row_span}/{total_rows} rows), cols = {selected_cols}")
                        
                        # Check if box spans ALL columns (row selection)
                        # A row selection should span all (or most) columns but only a few rows
                        elif col_span >= total_cols and row_span < total_rows:
                            is_row_selection = True
                            selected_rows = list(range(box.from_r, box.upto_r))
                            debug_print(f"📌 PASTE DEBUG: ✅ Detected FULL ROW selection (spans {col_span}/{total_cols} cols), rows = {selected_rows}")
                        else:
                            debug_print(f"📌 PASTE DEBUG: ❌ Not a full row/column - treating as regular range")
                
                # Also try the old method
                try:
                    old_selected_rows = self.table.get_selected_rows()
                    old_selected_cols = self.table.get_selected_columns()
                    if old_selected_rows and not selected_rows:
                        selected_rows = old_selected_rows
                    if old_selected_cols and not selected_cols:
                        selected_cols = old_selected_cols
                    debug_print(f"📌 PASTE DEBUG: selected_rows = {selected_rows}, selected_cols = {selected_cols}")
                except:
                    pass
                
                # Store old values for undo
                affected_cells = []
                
                # CRITICAL FIX: Check if full column(s) selected - fill with single value
                if selected_cols and len(data_rows) == 1 and len(data_rows[0]) == 1:
                    # User selected full column(s) and is pasting a single value - fill all cells
                    fill_value = data_rows[0][0]
                    debug_print(f"📌 PASTE DEBUG: Filling {len(selected_cols)} column(s) with value '{fill_value}'")
                    
                    for target_col in selected_cols:
                        for row_idx in range(self.table.total_rows()):
                            old_value = self.table.get_cell_data(row_idx, target_col)
                            affected_cells.append((row_idx, target_col, old_value, fill_value))
                            self.table.set_cell_data(row_idx, target_col, fill_value)
                            debug_print(f"📌 PASTE DEBUG: Filled cell ({row_idx}, {target_col}) = '{fill_value}'")
                    
                    # Cancel any pending edit session before paste
                    if self.current_edit_session:
                        debug_print(f"📌 PASTE DEBUG: Cancelling pending edit session")
                        self.current_edit_session = None
                    
                    self.add_to_undo_stack('paste_operation', {
                        'type': 'fill_columns',
                        'affected_cells': affected_cells
                    })
                    
                    # Force refresh and sync to openpyxl
                    debug_print(f"📌 PASTE DEBUG: Forcing tksheet refresh")
                    self.table.refresh()
                    
                    debug_print(f"📌 PASTE DEBUG: Syncing filled column data to openpyxl")
                    for row_idx, target_col, old_value, new_value in affected_cells:
                        excel_row = row_idx + 1
                        excel_col = target_col + 1
                        self.ws.cell(row=excel_row, column=excel_col, value=new_value)
                    
                    self.status_main.config(text=f"Filled {len(selected_cols)} column(s) with value")
                    return
                
                # CRITICAL FIX: Check if full row(s) selected - fill with single value
                elif selected_rows and len(data_rows) == 1 and len(data_rows[0]) == 1:
                    # User selected full row(s) and is pasting a single value - fill all cells
                    fill_value = data_rows[0][0]
                    debug_print(f"📌 PASTE DEBUG: Filling {len(selected_rows)} row(s) with value '{fill_value}'")
                    
                    for target_row in selected_rows:
                        for col_idx in range(self.table.total_columns()):
                            old_value = self.table.get_cell_data(target_row, col_idx)
                            affected_cells.append((target_row, col_idx, old_value, fill_value))
                            self.table.set_cell_data(target_row, col_idx, fill_value)
                            debug_print(f"📌 PASTE DEBUG: Filled cell ({target_row}, {col_idx}) = '{fill_value}'")
                    
                    # Cancel any pending edit session before paste
                    if self.current_edit_session:
                        debug_print(f"📌 PASTE DEBUG: Cancelling pending edit session")
                        self.current_edit_session = None
                    
                    self.add_to_undo_stack('paste_operation', {
                        'type': 'fill_rows',
                        'affected_cells': affected_cells
                    })
                    
                    # Force refresh and sync to openpyxl
                    debug_print(f"📌 PASTE DEBUG: Forcing tksheet refresh")
                    self.table.refresh()
                    
                    debug_print(f"📌 PASTE DEBUG: Syncing filled row data to openpyxl")
                    for target_row, col_idx, old_value, new_value in affected_cells:
                        excel_row = target_row + 1
                        excel_col = col_idx + 1
                        self.ws.cell(row=excel_row, column=excel_col, value=new_value)
                    
                    self.status_main.config(text=f"Filled {len(selected_rows)} row(s) with value")
                    return
                
                # Original logic: Paste full rows to selected rows
                elif selected_rows and hasattr(self, '_copy_type') and self._copy_type == 'rows':
                    # Pasting full rows to selected rows
                    for i, target_row in enumerate(selected_rows):
                        if i < len(data_rows):
                            source_data = data_rows[i]
                            for j, value in enumerate(source_data):
                                if j < self.table.total_columns():
                                    old_value = self.table.get_cell_data(target_row, j)
                                    affected_cells.append((target_row, j, old_value, value))
                                    self.table.set_cell_data(target_row, j, value)
                    
                    self.add_to_undo_stack('paste_operation', {
                        'type': 'rows',
                        'affected_cells': affected_cells
                    })
                    self.status_main.config(text=f"Pasted to {len(selected_rows)} row(s)")
                    
                elif selected_cols and hasattr(self, '_copy_type') and self._copy_type == 'columns':
                    # Pasting full columns to selected columns
                    for i, target_col in enumerate(selected_cols):
                        if i < len(data_rows[0]) if data_rows else 0:
                            # Extract column data from rows
                            for row_idx in range(min(len(data_rows), self.table.total_rows())):
                                if i < len(data_rows[row_idx]):
                                    value = data_rows[row_idx][i]
                                    old_value = self.table.get_cell_data(row_idx, target_col)
                                    affected_cells.append((row_idx, target_col, old_value, value))
                                    self.table.set_cell_data(row_idx, target_col, value)
                    
                    self.add_to_undo_stack('paste_operation', {
                        'type': 'columns', 
                        'affected_cells': affected_cells
                    })
                    self.status_main.config(text=f"Pasted to {len(selected_cols)} column(s)")
                    
                else:
                    # Regular cell/range paste
                    debug_print(f"📌 PASTE DEBUG: Regular cell/range paste path")
                    if current_selected and hasattr(current_selected, 'row') and hasattr(current_selected, 'column'):
                        start_row = current_selected.row
                        start_col = current_selected.column
                        debug_print(f"📌 PASTE DEBUG: start_row = {start_row}, start_col = {start_col}")
                        
                        # Check if we have a range selection for target
                        # CRITICAL FIX: Extract cells from box selection, not just highlighted cells
                        selected_cells = []
                        try:
                            highlighted = self.table.get_highlighted_cells()
                            if highlighted:
                                selected_cells = list(highlighted)
                            debug_print(f"📌 PASTE DEBUG: highlighted = {highlighted}")
                        except:
                            pass
                        
                        # If highlighted_cells is empty, try to extract from box selection
                        if not selected_cells and current_selected and hasattr(current_selected, 'box') and current_selected.box:
                            box = current_selected.box
                            debug_print(f"📌 PASTE DEBUG: Extracting cells from box selection: rows {box.from_r}->{box.upto_r}, cols {box.from_c}->{box.upto_c}")
                            for r in range(box.from_r, box.upto_r):
                                for c in range(box.from_c, box.upto_c):
                                    selected_cells.append((r, c))
                            debug_print(f"📌 PASTE DEBUG: Extracted {len(selected_cells)} cells from box")
                        
                        debug_print(f"📌 PASTE DEBUG: Total selected_cells = {len(selected_cells)}")
                        
                        # If pasting a single value to multiple selected cells, fill all of them
                        if selected_cells and len(selected_cells) > 1 and len(data_rows) == 1 and len(data_rows[0]) == 1:
                            # Paste to all selected cells (fill operation)
                            paste_value = data_rows[0][0] if data_rows and data_rows[0] else ""
                            debug_print(f"📌 PASTE DEBUG: Filling {len(selected_cells)} selected cells with value '{paste_value}'")
                            
                            for row, col in selected_cells:
                                old_value = self.table.get_cell_data(row, col)
                                affected_cells.append((row, col, old_value, paste_value))
                                self.table.set_cell_data(row, col, paste_value)
                                debug_print(f"📌 PASTE DEBUG: Filled cell ({row}, {col}) = '{paste_value}'")
                            
                            # Cancel any pending edit session
                            if self.current_edit_session:
                                debug_print(f"📌 PASTE DEBUG: Cancelling pending edit session")
                                self.current_edit_session = None
                            
                            self.add_to_undo_stack('paste_operation', {
                                'type': 'fill',
                                'affected_cells': affected_cells
                            })
                            
                            # Sync to openpyxl
                            debug_print(f"📌 PASTE DEBUG: Syncing filled cells to openpyxl")
                            for row, col, old_value, new_value in affected_cells:
                                excel_row = row + 1
                                excel_col = col + 1
                                self.ws.cell(row=excel_row, column=excel_col, value=new_value)
                            
                            self.status_main.config(text=f"Filled {len(selected_cells)} cells")
                        else:
                            # Paste range starting from current cell
                            debug_print(f"📌 PASTE DEBUG: Pasting range starting from ({start_row}, {start_col})")
                            
                            # CRITICAL FIX: Cancel any pending edit sessions before pasting
                            # This prevents finalize_any_pending_edit from overwriting our paste
                            if self.current_edit_session:
                                debug_print(f"📌 PASTE DEBUG: Cancelling pending edit session before paste")
                                self.current_edit_session = None
                            
                            for i, row_data in enumerate(data_rows):
                                for j, value in enumerate(row_data):
                                    target_row = start_row + i
                                    target_col = start_col + j
                                    debug_print(f"📌 PASTE DEBUG: Setting cell ({target_row}, {target_col}) = '{value}'")
                                    
                                    if (target_row < self.table.total_rows() and 
                                        target_col < self.table.total_columns()):
                                        old_value = self.table.get_cell_data(target_row, target_col)
                                        affected_cells.append((target_row, target_col, old_value, value))
                                        self.table.set_cell_data(target_row, target_col, value)
                                        debug_print(f"📌 PASTE DEBUG: Successfully set cell ({target_row}, {target_col}) from '{old_value}' to '{value}'")
                            
                            self.add_to_undo_stack('paste_operation', {
                                'type': 'range',
                                'affected_cells': affected_cells
                            })
                            
                            # Sync pasted data to openpyxl (don't refresh yet - wait until after cut clearing)
                            debug_print(f"📌 PASTE DEBUG: Syncing pasted data to openpyxl")
                            for target_row, target_col, old_value, new_value in affected_cells:
                                excel_row = target_row + 1
                                excel_col = target_col + 1
                                self.ws.cell(row=excel_row, column=excel_col, value=new_value)
                                debug_print(f"📌 PASTE DEBUG: Synced openpyxl cell ({excel_row}, {excel_col}) = '{new_value}'")
                            
                            if len(affected_cells) == 1:
                                self.status_main.config(text=f"Pasted to cell")
                            else:
                                self.status_main.config(text=f"Pasted {len(affected_cells)} cells")
                    else:
                        self.status_main.config(text="No target selection for paste")
                
                # Note: Cut cells were already cleared in cut_selection()
                # Just reset the cut flag
                if self._is_cut:
                    debug_print(f"️ CUT DEBUG: Paste complete - cut cells were already cleared")
                    self._is_cut = False
                    self._cut_cells = []
                
            except Exception as e:
                debug_print(f"Paste error: {e}")
                import traceback
                traceback.print_exc()
                self.status_main.config(text="Paste failed")
    
    def clear_selection(self):
        """Clear the currently selected cells"""
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            try:
                selected = self.table.get_currently_selected()
                if selected and hasattr(selected, 'row') and hasattr(selected, 'column'):
                    # Get old value for undo
                    old_value = self.table.get_cell_data(selected.row, selected.column)
                    
                    # Clear the cell
                    self.table.set_cell_data(selected.row, selected.column, '')
                    
                    # Add to undo stack
                    self.add_to_undo_stack('clear_selection', {
                        'cell': f"{get_column_letter(selected.column+1)}{selected.row+1}",
                        'old_value': old_value,
                        'new_value': ''
                    })
                    
                    self.status_main.config(text=f"Cleared cell {get_column_letter(selected.column+1)}{selected.row+1}")
                else:
                    self.status_main.config(text="No selection to clear")
            except Exception as e:
                debug_print(f"Clear selection error: {e}")
    
    def select_all(self):
        """Select all cells in the sheet"""
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            try:
                self.table.select_all()
                self.status_main.config(text="Selected all cells")
            except Exception as e:
                debug_print(f"Select all error: {e}")
    
    # Navigation Functions
    def go_to_cell(self):
        """Go to a specific cell address with enhanced navigation dialog"""
        # Create a custom navigation dialog
        dialog = tk.Toplevel(self.master)
        dialog.title("Go to Cell")
        dialog.geometry("400x250")
        dialog.resizable(False, False)
        dialog.transient(self.master)
        dialog.grab_set()
        
        # Center the dialog
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() // 2) - (400 // 2)
        y = (dialog.winfo_screenheight() // 2) - (250 // 2)
        dialog.geometry(f"400x250+{x}+{y}")
        
        # Variables
        cell_var = tk.StringVar()
        result = {"cell": None}
        
        # Main instruction
        ttk.Label(dialog, text="Navigate to Cell", font=("Arial", 14, "bold")).pack(pady=15)
        
        # Input frame
        input_frame = ttk.Frame(dialog)
        input_frame.pack(pady=15, padx=30, fill="x")
        
        ttk.Label(input_frame, text="Cell Address:", font=("Arial", 11)).pack(anchor="w")
        cell_entry = ttk.Entry(input_frame, textvariable=cell_var, font=("Arial", 12), width=20)
        cell_entry.pack(pady=8, fill="x")
        cell_entry.focus()
        
        # Example text
        ttk.Label(input_frame, text="Examples: A1, B10, Z99", 
                 font=("Arial", 10), foreground="gray").pack(anchor="w", pady=(5, 0))
        
        # Button frame
        button_frame = ttk.Frame(dialog)
        button_frame.pack(pady=20, padx=30, fill="x")
        
        def go_to_cell_action():
            cell = cell_var.get().strip().upper()
            if cell:
                result["cell"] = cell
                dialog.destroy()
            else:
                messagebox.showwarning("Invalid Input", "Please enter a cell address")
        
        def cancel_action():
            dialog.destroy()
        
        # Buttons with proper spacing and larger size
        ttk.Button(button_frame, text="Go to Cell", command=go_to_cell_action, 
                  width=15).pack(side="left", padx=(0, 15), pady=10)
        ttk.Button(button_frame, text="Cancel", command=cancel_action, 
                  width=15).pack(side="left", pady=10)
        
        # Bind Enter key
        cell_entry.bind('<Return>', lambda e: go_to_cell_action())
        dialog.bind('<Escape>', lambda e: cancel_action())
        
        # Wait for dialog to close
        dialog.wait_window()
        
        # Navigate if user entered a cell
        if result["cell"]:
            self.navigate_to_cell(result["cell"])
    
    def go_to_name_box_cell(self, event=None):
        """Go to cell specified in name box"""
        cell = self.name_box.get().strip().upper()
        if cell:
            self.navigate_to_cell(cell)
    
    def go_to_formula_name_box_cell(self, event=None):
        """Go to cell specified in formula name box"""
        if hasattr(self, 'formula_name_box'):
            cell = self.formula_name_box.get().strip().upper()
            if cell:
                self.navigate_to_cell(cell)
    
    def navigate_to_cell(self, cell_address):
        """Navigate to a specific cell and select it"""
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            try:
                # Make navigation case-insensitive
                cell_address = cell_address.upper().strip()
                
                # Parse cell address (e.g., "B10" -> row 9, col 1)
                import re
                match = re.match(r'^([A-Z]+)(\d+)$', cell_address)
                if match:
                    col_letters = match.group(1)
                    row_num = int(match.group(2))
                    
                    # Convert column letters to index
                    col_idx = column_index_from_string(col_letters) - 1
                    row_idx = row_num - 1
                    
                    # Select the cell
                    self.table.select_cell(row_idx, col_idx)
                    self.table.see(row_idx, col_idx)  # Scroll to make it visible
                    
                    # Update name boxes
                    self.update_name_box()
                    if hasattr(self, 'formula_name_box'):
                        self.formula_name_box.delete(0, tk.END)
                        self.formula_name_box.insert(0, cell_address)
                    
                    self.status_main.config(text=f"Navigated to {cell_address}")
                else:
                    self.status_main.config(text=f"Invalid cell address: {cell_address}")
            except Exception as e:
                debug_print(f"Navigate error: {e}")
                self.status_main.config(text=f"Could not navigate to {cell_address}")
    
    def update_name_box(self, event=None):
        """Update the name box with current cell address"""
        try:
            if TKSHEET_AVAILABLE and hasattr(self, 'table') and hasattr(self, 'name_box'):
                selected = self.table.get_currently_selected()
                if selected and hasattr(selected, 'row') and hasattr(selected, 'column'):
                    cell_addr = f"{get_column_letter(selected.column + 1)}{selected.row + 1}"
                    self.name_box.delete(0, tk.END)
                    self.name_box.insert(0, cell_addr)
        except Exception as e:
            debug_print(f"Name box update error: {e}")
    
    # Formatting Functions
    def change_font_size(self):
        """Change font size for selected cells"""
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            try:
                selected = self.table.get_currently_selected()
                if selected and hasattr(selected, 'row') and hasattr(selected, 'column'):
                    size = simpledialog.askinteger("Font Size", "Enter font size (8-72):", minvalue=8, maxvalue=72)
                    if size:
                        # Get cell address
                        cell_addr = f"{get_column_letter(selected.column + 1)}{selected.row + 1}"
                        cell = self.ws[cell_addr]
                        
                        # Get current font
                        current_font = cell.font
                        
                        # Create new font with new size
                        new_font = Font(
                            name=current_font.name,
                            size=size,
                            bold=current_font.bold,
                            italic=current_font.italic,
                            vertAlign=current_font.vertAlign,
                            underline=current_font.underline,
                            strike=current_font.strike,
                            color=current_font.color
                        )
                        
                        # Apply new font
                        cell.font = new_font
                        
                        # Add to undo stack
                        self.add_to_undo_stack('format_change', {
                            'cell': cell_addr,
                            'old_font': current_font,
                            'new_font': new_font,
                            'format_type': 'font_size'
                        })
                        
                        self.status_main.config(text=f"Font size changed to {size} for {cell_addr}")
                else:
                    self.status_main.config(text="No cell selected for formatting")
            except Exception as e:
                debug_print(f"Font size error: {e}")
                self.status_main.config(text="Font size change failed")
        else:
            self.status_main.config(text="Formatting requires tksheet")
    
    def format_borders(self):
        """Add borders to selected cells"""
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            try:
                selected = self.table.get_currently_selected()
                if selected and hasattr(selected, 'row') and hasattr(selected, 'column'):
                    # Get cell address
                    cell_addr = f"{get_column_letter(selected.column + 1)}{selected.row + 1}"
                    cell = self.ws[cell_addr]
                    
                    # Get current border
                    current_border = cell.border
                    
                    # Create border style
                    thin_border = Border(
                        left=Side(style='thin'),
                        right=Side(style='thin'),
                        top=Side(style='thin'),
                        bottom=Side(style='thin')
                    )
                    
                    # Apply border
                    cell.border = thin_border
                    
                    # Add to undo stack
                    self.add_to_undo_stack('format_change', {
                        'cell': cell_addr,
                        'old_border': current_border,
                        'new_border': thin_border,
                        'format_type': 'border'
                    })
                    
                    self.status_main.config(text=f"Border applied to {cell_addr}")
                else:
                    self.status_main.config(text="No cell selected for formatting")
            except Exception as e:
                debug_print(f"Border formatting error: {e}")
                self.status_main.config(text="Border formatting failed")
        else:
            self.status_main.config(text="Formatting requires tksheet")
    
    def auto_fit_columns(self):
        """Auto-fit column widths to content"""
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            try:
                # Get all column data to calculate optimal widths
                data = self.table.get_sheet_data()
                if data:
                    for col_idx in range(len(data[0]) if data else 0):
                        max_width = 50  # Minimum width
                        for row in data:
                            if col_idx < len(row) and row[col_idx]:
                                content_width = len(str(row[col_idx])) * 8 + 20  # Approximate
                                max_width = max(max_width, min(content_width, 300))  # Cap at 300
                        
                        self.table.set_column_width(col_idx, max_width)
                    
                    self.status_main.config(text="Columns auto-fitted to content")
                else:
                    self.status_main.config(text="No data to auto-fit")
            except Exception as e:
                debug_print(f"Auto-fit error: {e}")
                self.status_main.config(text="Auto-fit failed")
            try:
                # Get all column data to calculate optimal widths
                data = self.table.get_sheet_data()
                if data:
                    for col_idx in range(len(data[0]) if data else 0):
                        max_width = 50  # Minimum width
                        for row in data:
                            if col_idx < len(row) and row[col_idx]:
                                content_width = len(str(row[col_idx])) * 8 + 20  # Approximate
                                max_width = max(max_width, min(content_width, 300))  # Cap at 300
                        
                        self.table.set_column_width(col_idx, max_width)
                    
                    self.status_main.config(text="Columns auto-fitted to content")
                else:
                    self.status_main.config(text="No data to auto-fit")
            except Exception as e:
                debug_print(f"Auto-fit error: {e}")
                self.status_main.config(text="Auto-fit failed")
    
    # View Functions
    def zoom_in(self):
        """Zoom in the view"""
        if self.zoom_level < 3.0:  # Max 300%
            self.zoom_level += 0.1
            self.apply_zoom()
            self.status_main.config(text=f"Zoomed to {int(self.zoom_level * 100)}%")
    
    def zoom_out(self):
        """Zoom out the view"""
        if self.zoom_level > 0.5:  # Min 50%
            self.zoom_level -= 0.1
            self.apply_zoom()
            self.status_main.config(text=f"Zoomed to {int(self.zoom_level * 100)}%")
    
    def reset_zoom(self):
        """Reset zoom to 100%"""
        self.zoom_level = 1.0
        self.apply_zoom()
        self.status_main.config(text="Zoom reset to 100%")
    
    def apply_zoom(self):
        """Apply current zoom level"""
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            try:
                # Calculate new dimensions based on zoom
                base_row_height = 25
                base_col_width = 120
                
                new_row_height = int(base_row_height * self.zoom_level)
                new_col_width = int(base_col_width * self.zoom_level)
                
                # Apply to table
                self.table.set_all_row_heights(new_row_height)
                self.table.set_all_column_widths(new_col_width)
                
                # Update zoom label
                if hasattr(self, 'zoom_label'):
                    self.zoom_label.config(text=f"{int(self.zoom_level * 100)}%")
                
                self.save_settings()
            except Exception as e:
                debug_print(f"Zoom apply error: {e}")
    
    def toggle_grid_lines(self):
        """Toggle grid lines visibility"""
        self.show_grid_lines = not self.show_grid_lines
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            try:
                # This is a placeholder - tksheet may not have this exact method
                # You would need to check tksheet documentation for grid line control
                self.status_main.config(text=f"Grid lines {'shown' if self.show_grid_lines else 'hidden'}")
                self.save_settings()
            except Exception as e:
                debug_print(f"Grid lines toggle error: {e}")
    
    def toggle_formula_bar(self):
        """Toggle formula bar visibility"""
        self.formula_bar_visible = not self.formula_bar_visible
        if hasattr(self, 'formula_frame'):
            if self.formula_bar_visible:
                self.formula_frame.pack(side="top", fill="x", padx=5, pady=2, 
                                       after=self.master.children[list(self.master.children.keys())[1]])
            else:
                self.formula_frame.pack_forget()
        self.save_settings()
        self.status_main.config(text=f"Formula bar {'shown' if self.formula_bar_visible else 'hidden'}")
    
    def toggle_theme(self):
        """Toggle between light and dark themes"""
        if self.current_theme == "light":
            self.current_theme = "dark"
            self.apply_dark_theme()
        else:
            self.current_theme = "light"
            self.apply_light_theme()
        self.save_settings()
    
    def apply_light_theme(self):
        """Apply light theme"""
        try:
            style = ttk.Style()
            style.configure("Toolbar.TFrame", background="#f8f9fa")
            style.configure("FormulaBar.TFrame", background="#ffffff")
            self.master.configure(bg="#ffffff")
            self.status_main.config(text="Applied light theme")
        except Exception as e:
            debug_print(f"Light theme error: {e}")
    
    def apply_dark_theme(self):
        """Apply dark theme"""
        try:
            style = ttk.Style()
            style.configure("Toolbar.TFrame", background="#2d3748")
            style.configure("FormulaBar.TFrame", background="#1a202c")
            self.master.configure(bg="#1a202c")
            self.status_main.config(text="Applied dark theme")
        except Exception as e:
            debug_print(f"Dark theme error: {e}")
    
    # Formula Bar Functions
    def apply_formula_bar_content(self, event=None):
        """Apply content from formula bar to current cell"""
        if hasattr(self, 'formula_bar') and TKSHEET_AVAILABLE and hasattr(self, 'table'):
            try:
                content = self.formula_bar.get()
                selected = self.table.get_currently_selected()
                if selected and hasattr(selected, 'row') and hasattr(selected, 'column'):
                    old_value = self.table.get_cell_data(selected.row, selected.column)
                    self.table.set_cell_data(selected.row, selected.column, content)
                    
                    # Add to undo stack
                    self.add_to_undo_stack('formula_bar_edit', {
                        'cell': f"{get_column_letter(selected.column + 1)}{selected.row + 1}",
                        'old_value': old_value,
                        'new_value': content
                    })
                    
                    self.status_main.config(text=f"Updated cell with formula bar content")
            except Exception as e:
                debug_print(f"Formula bar apply error: {e}")
    
    def cancel_formula_bar_edit(self, event=None):
        """Cancel formula bar edit and restore original content"""
        if hasattr(self, 'formula_bar'):
            self.update_formula_bar()
            self.status_main.config(text="Formula bar edit cancelled")
    
    def update_formula_bar(self):
        """Update formula bar with current cell content"""
        if hasattr(self, 'formula_bar') and TKSHEET_AVAILABLE and hasattr(self, 'table'):
            try:
                selected = self.table.get_currently_selected()
                if selected and hasattr(selected, 'row') and hasattr(selected, 'column'):
                    content = self.table.get_cell_data(selected.row, selected.column)
                    self.formula_bar.delete(0, tk.END)
                    if content:
                        self.formula_bar.insert(0, str(content))
                    
                    # Also update formula name box
                    if hasattr(self, 'formula_name_box'):
                        cell_addr = f"{get_column_letter(selected.column + 1)}{selected.row + 1}"
                        self.formula_name_box.delete(0, tk.END)
                        self.formula_name_box.insert(0, cell_addr)
            except Exception as e:
                debug_print(f"Formula bar update error: {e}")
    
    # Sheet Operations
    def list_sheets(self):
        sheets = "\n".join([f"• {sheet}" for sheet in self.wb.sheetnames])
        messagebox.showinfo("Sheet List", f"Available sheets:\n\n{sheets}")
    
    def select_sheet(self):
        """Legacy method - now redirects to tab interface"""
        # This method is kept for compatibility but functionality moved to tabs
        pass
    
    def add_sheet(self):
        """Legacy method - now redirects to tab interface"""
        self.add_sheet_tab()
    
    def rename_sheet(self):
        """Legacy method - now operates on current sheet"""
        current = self.ws.title
        self.rename_sheet_by_name(current)
    
    def delete_sheet(self):
        """Legacy method - now operates on current sheet"""
        current = self.ws.title
        self.delete_sheet_by_name(current)
    
    # Cell Operations
    def read_cell(self):
        cell = simpledialog.askstring("Read Cell", "Enter cell address (e.g., B3):")
        if not cell:
            return
        try:
            value = self.ws[cell.upper()].value
            messagebox.showinfo("Cell Value", f"Cell {cell.upper()}:\n\n{value}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to read cell:\n{str(e)}")
    
    def edit_cell_dialog(self):
        """Edit cell using dialog (alternative to direct editing)"""
        cell = simpledialog.askstring("Edit Cell", "Enter cell address (e.g., B3):")
        if not cell:
            return
        
        cell = cell.upper()
        try:
            current_value = self.ws[cell].value
            new_value = simpledialog.askstring("Edit Cell", 
                f"Cell: {cell}\nCurrent value: {current_value}\n\nEnter new value:")
            
            if new_value is None:  # User cancelled
                return
            
            # Save for undo
            self.add_to_undo_stack('cell_edit', {
                'cell': cell,
                'old_value': current_value,
                'new_value': new_value
            })
            
            self.ws[cell].value = new_value
            self.update_display()
            # Status update instead of popup
            self.status_main.config(text=f"Cell {cell} updated to: {new_value}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to edit cell:\n{str(e)}")
    
    def clear_cell(self):
        if TKSHEET_AVAILABLE:
            try:
                selected = self.table.get_currently_selected()
                if selected and selected.row is not None and selected.column is not None:
                    # Get current value for undo
                    current_value = self.table.get_cell_data(selected.row, selected.column)
                    col_letter = get_column_letter(selected.column + 1)
                    cell_addr = f"{col_letter}{selected.row + 1}"
                    
                    # Save for undo
                    self.add_to_undo_stack('cell_clear', {
                        'cell': cell_addr,
                        'old_value': current_value
                    })
                    
                    self.table.set_cell_data(selected.row, selected.column, "")
                    self.sync_sheet_to_workbook()
                    self.status_main.config(text="Cell cleared")
                    return
            except:
                pass
        
        # Fallback to dialog
        cell = simpledialog.askstring("Clear Cell", "Enter cell address (e.g., B2):")
        if not cell:
            return
        
        cell = cell.upper()
        try:
            old_value = self.ws[cell].value
            
            # Save for undo
            self.add_to_undo_stack('cell_clear', {
                'cell': cell,
                'old_value': old_value
            })
            
            self.ws[cell].value = None
            self.update_display()
            # Status update instead of popup
            self.status_main.config(text=f"Cleared cell {cell} (was: {old_value})")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to clear cell:\n{str(e)}")
    
    # Row/Column Operations
    def insert_row(self):
        row_num = simpledialog.askinteger("Insert Row", "Enter row number:")
        if not row_num:
            return
        
        position = messagebox.askquestion("Insert Position", 
            f"Insert BEFORE row {row_num}?\n\n(No = insert AFTER)")
        
        if position == 'yes':
            insert_at = row_num
        else:
            insert_at = row_num + 1
        
        try:
            # Capture state for undo
            state_before = self.capture_sheet_state()
            
            self.ws.insert_rows(insert_at)
            
            # Save for undo
            self.add_to_undo_stack('row_insert', {
                'insert_position': insert_at,
                'state_before': state_before
            })
            
            self.update_display()
            # Status update instead of popup
            self.status_main.config(text=f"Inserted row at position {insert_at}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to insert row:\n{str(e)}")
    
    def delete_row(self):
        row_num = simpledialog.askinteger("Delete Row", "Enter row number to delete:")
        if not row_num:
            return
        
        try:
            # Capture state for undo
            state_before = self.capture_sheet_state()
            
            self.ws.delete_rows(row_num)
            
            # Save for undo
            self.add_to_undo_stack('row_delete', {
                'row_number': row_num,
                'state_before': state_before
            })
            
            self.update_display()
            # Status update instead of popup
            self.status_main.config(text=f"Deleted row {row_num}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to delete row:\n{str(e)}")
    
    def insert_column(self):
        col_letter = simpledialog.askstring("Insert Column", "Enter column letter (e.g., B):")
        if not col_letter:
            return
        
        col_letter = col_letter.upper()
        try:
            col_idx = column_index_from_string(col_letter)
            
            position = messagebox.askquestion("Insert Position", 
                f"Insert BEFORE column {col_letter}?\n\n(No = insert AFTER)")
            
            if position == 'yes':
                insert_at = col_idx
            else:
                insert_at = col_idx + 1
            
            # Capture state for undo
            state_before = self.capture_sheet_state()
            
            self.ws.insert_cols(insert_at)
            
            # Save for undo
            self.add_to_undo_stack('column_insert', {
                'insert_position': insert_at,
                'state_before': state_before
            })
            
            self.update_display()
            # Status update instead of popup
            self.status_main.config(text=f"Inserted column at {get_column_letter(insert_at)}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to insert column:\n{str(e)}")
    
    def delete_column(self):
        col_letter = simpledialog.askstring("Delete Column", "Enter column letter (e.g., C):")
        if not col_letter:
            return
        
        try:
            col_idx = column_index_from_string(col_letter.upper())
            
            # Capture state for undo
            state_before = self.capture_sheet_state()
            
            self.ws.delete_cols(col_idx)
            
            # Save for undo
            self.add_to_undo_stack('column_delete', {
                'column_index': col_idx,
                'column_letter': col_letter.upper(),
                'state_before': state_before
            })
            
            self.update_display()
            # Status update instead of popup
            self.status_main.config(text=f"Deleted column {col_letter.upper()}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to delete column:\n{str(e)}")
    
    def show_row(self):
        row_num = simpledialog.askinteger("Show Row", "Enter row number to view:")
        if not row_num:
            return
        
        try:
            row_values = [self.ws.cell(row_num, col).value for col in range(1, self.ws.max_column+1)]
            result = "\n".join([f"{get_column_letter(i+1)}: {val}" for i, val in enumerate(row_values)])
            messagebox.showinfo(f"Row {row_num}", result)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to show row:\n{str(e)}")
    
    def show_column(self):
        col_letter = simpledialog.askstring("Show Column", "Enter column letter (e.g., B):")
        if not col_letter:
            return
        
        try:
            col_idx = column_index_from_string(col_letter.upper())
            col_values = [self.ws.cell(row, col_idx).value for row in range(1, self.ws.max_row+1)]
            result = "\n".join([f"Row {i+1}: {val}" for i, val in enumerate(col_values)])
            messagebox.showinfo(f"Column {col_letter.upper()}", result)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to show column:\n{str(e)}")
    
    # Search Operations
    def find_value(self):
        """Enhanced find value with case-insensitive search, replace functionality, and highlighting"""
        debug_print("\n" + "="*80)
        debug_print("🔍 FIND DIALOG: Opening Find & Replace dialog")
        debug_print("="*80)
        
        # CRITICAL: Sync tksheet to workbook before searching to include unsaved cell data
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            debug_print("🔍 FIND: Syncing tksheet to workbook before search...")
            self.sync_sheet_to_workbook()
            debug_print("🔍 FIND: Sync complete")
        
        # Create a custom dialog for find
        dialog = tk.Toplevel(self.master)
        dialog.title("Find & Replace")
        dialog.geometry("550x480")
        dialog.resizable(False, False)
        dialog.transient(self.master)
        
        # Center the dialog
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() // 2) - (550 // 2)
        y = (dialog.winfo_screenheight() // 2) - (480 // 2)
        dialog.geometry(f"550x480+{x}+{y}")

        # Make dialog stay on top but allow other dialogs to appear above it
        dialog.attributes('-topmost', True)
        dialog.focus_set()
        
        # Use grab_set() at the end after all widgets are created
        
        # Variables
        search_val = tk.StringVar()
        replace_val = tk.StringVar()
        case_sensitive = tk.BooleanVar(value=False)
        whole_words = tk.BooleanVar(value=False)
        
        # Search text
        ttk.Label(dialog, text="Find what:", font=("Arial", 10, "bold")).grid(row=0, column=0, padx=10, pady=10, sticky="w")
        search_entry = ttk.Entry(dialog, width=35, textvariable=search_val, font=("Arial", 10))
        search_entry.grid(row=0, column=1, padx=10, pady=10, sticky="ew")
        search_entry.focus()
        
        # Replace text
        ttk.Label(dialog, text="Replace with:", font=("Arial", 10, "bold")).grid(row=1, column=0, padx=10, pady=10, sticky="w")
        replace_entry = ttk.Entry(dialog, width=35, textvariable=replace_val, font=("Arial", 10))
        replace_entry.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
        
        # Options
        ttk.Checkbutton(dialog, text="Case sensitive", variable=case_sensitive).grid(row=2, column=0, columnspan=2, padx=10, pady=5, sticky="w")
        ttk.Checkbutton(dialog, text="Whole words only", variable=whole_words).grid(row=3, column=0, columnspan=2, padx=10, pady=5, sticky="w")
        
        # Results area
        ttk.Label(dialog, text="Search Results:", font=("Arial", 10, "bold")).grid(row=4, column=0, padx=10, pady=(15, 5), sticky="w")
        results_text = tk.Text(dialog, width=55, height=8, font=("Arial", 9))
        results_text.grid(row=5, column=0, columnspan=2, padx=10, pady=5, sticky="ew")
        
        # Scrollbar for results
        scrollbar = ttk.Scrollbar(dialog, orient="vertical", command=results_text.yview)
        scrollbar.grid(row=5, column=2, sticky="ns", pady=5)
        results_text.configure(yscrollcommand=scrollbar.set)
        
        # Store found cell locations for highlighting
        found_cells = []
        currently_highlighted_cells = []  # Track what's currently highlighted
        debug_print(f"🔍 HIGHLIGHT DEBUG: Initialized found_cells list at {id(found_cells)}")
        
        def highlight_cells():
            """Highlight found cells in the sheet"""
            nonlocal currently_highlighted_cells
            
            debug_print(f"🎨 HIGHLIGHT DEBUG: highlight_cells() called")
            debug_print(f"🎨 HIGHLIGHT DEBUG: found_cells has {len(found_cells)} items at {id(found_cells)}")
            cell_addresses = [c['address'] for c in found_cells[:5]]
            debug_print(f"🎨 HIGHLIGHT DEBUG: found_cells content (first 5): {cell_addresses}")
            debug_print(f"🎨 HIGHLIGHT DEBUG: currently_highlighted_cells has {len(currently_highlighted_cells)} items")
            
            if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                try:
                    # STEP 1: Manually dehighlight each previously highlighted cell
                    if currently_highlighted_cells:
                        debug_print(f"🎨 HIGHLIGHT DEBUG: Manually de-highlighting {len(currently_highlighted_cells)} previous cells")
                        for cell_info in currently_highlighted_cells:
                            row, col = cell_info['row'] - 1, cell_info['col'] - 1
                            try:
                                self.table.dehighlight_cells(row=row, column=col)
                                debug_print(f"🎨 HIGHLIGHT DEBUG: De-highlighted {cell_info['address']} at ({row}, {col})")
                            except:
                                pass
                    
                    # Also call global dehighlight as backup
                    self.table.dehighlight_cells()
                    debug_print(f"🎨 HIGHLIGHT DEBUG: Called global dehighlight_cells()")
                    
                    # Force refresh after clearing
                    self.table.redraw(redraw_header=True, redraw_row_index=True)
                    self.table.refresh()
                    self.table.update_idletasks()
                    debug_print(f"🎨 HIGHLIGHT DEBUG: Refresh after clear complete")
                    
                    # STEP 2: Highlight new cells
                    if found_cells:
                        debug_print(f"🎨 HIGHLIGHT DEBUG: Now highlighting {len(found_cells)} new cells")
                        for cell_info in found_cells:
                            row, col = cell_info['row'] - 1, cell_info['col'] - 1
                            debug_print(f"🎨 HIGHLIGHT DEBUG: Highlighting {cell_info['address']} at ({row}, {col})")
                            self.table.highlight_cells(row=row, column=col, bg="#FFFF99", fg="black")
                        
                        # Force refresh after highlighting
                        debug_print(f"🎨 HIGHLIGHT DEBUG: Calling final refresh sequence...")
                        self.table.redraw(redraw_header=True, redraw_row_index=True)
                        self.table.refresh()
                        self.table.update_idletasks()
                        debug_print(f"🎨 HIGHLIGHT DEBUG: Final refresh complete")
                        
                        # Update tracking
                        currently_highlighted_cells = found_cells.copy()
                        
                        self.status_main.config(text=f"Highlighted {len(found_cells)} matching cells")
                        debug_print(f"🎨 HIGHLIGHT DEBUG: Successfully highlighted {len(found_cells)} cells")
                    else:
                        debug_print(f"🎨 HIGHLIGHT DEBUG: No cells to highlight (empty found_cells)")
                        currently_highlighted_cells = []
                        self.status_main.config(text=f"Highlights cleared")
                        
                except Exception as e:
                    debug_print(f"🎨 HIGHLIGHT DEBUG ERROR: {e}")
                    import traceback
                    traceback.print_exc()
            else:
                debug_print(f"🎨 HIGHLIGHT DEBUG: Skipping highlight - tksheet_available={TKSHEET_AVAILABLE}, has_table={hasattr(self, 'table')}, found_cells_empty={not found_cells}")
        
        
        def perform_search():
            nonlocal found_cells
            
            debug_print(f"🔍 SEARCH DEBUG: perform_search() called")
            debug_print(f"🔍 SEARCH DEBUG: found_cells before clear: {len(found_cells)} items at {id(found_cells)}")
            
            # Clear the found_cells list for new search
            # (highlight_cells() will handle visual clearing)
            
            search_text = search_val.get().strip()
            if not search_text:
                results_text.delete(1.0, tk.END)
                results_text.insert(tk.END, "Please enter a search term.")
                return
            
            # Get search options
            is_case_sensitive = case_sensitive.get()
            is_whole_words = whole_words.get()
            
            debug_print(f"🔍 SEARCH DEBUG: Search parameters - case_sensitive={is_case_sensitive}, whole_words={is_whole_words}")
            
            # Clear previous found cells and reset for new search
            debug_print(f"🔍 SEARCH DEBUG: Clearing found_cells (was {len(found_cells)} items)")
            found_cells.clear()
            debug_print(f"🔍 SEARCH DEBUG: found_cells after clear: {len(found_cells)} items at {id(found_cells)}")
            results = []
            
            debug_print(f" SEARCH DEBUG: Searching for '{search_text}', case_sensitive={is_case_sensitive}, whole_words={is_whole_words}")
            
            # Search using cell objects (same as replace functions)
            for row in self.ws.iter_rows():
                for cell in row:
                    if cell.value is not None:
                        cell_text = str(cell.value)
                        
                        # Check for match using identical logic as replace functions
                        match_found = False
                        if is_case_sensitive:
                            if is_whole_words:
                                import re
                                pattern = r'\b' + re.escape(search_text) + r'\b'
                                match_found = bool(re.search(pattern, cell_text))
                            else:
                                match_found = search_text in cell_text
                        else:
                            if is_whole_words:
                                import re
                                pattern = r'\b' + re.escape(search_text) + r'\b'
                                match_found = bool(re.search(pattern, cell_text, re.IGNORECASE))
                            else:
                                match_found = search_text.lower() in cell_text.lower()
                        
                        debug_print(f" SEARCH DEBUG: Cell {cell.coordinate} = '{cell_text}', match = {match_found}")
                        
                        if match_found:
                            cell_address = cell.coordinate
                            results.append(f"{cell_address}: {cell_text}")
                            cell_info = {
                                'address': cell_address,
                                'row': cell.row,
                                'col': cell.column,
                                'value': cell_text
                            }
                            found_cells.append(cell_info)
                            debug_print(f"🔍 SEARCH DEBUG: Added match #{len(found_cells)}: {cell_address} = '{cell_text}'")
            
            debug_print(f"🔍 SEARCH DEBUG: Search complete - found {len(found_cells)} matches")
            debug_print(f"🔍 SEARCH DEBUG: found_cells now at {id(found_cells)}")
            
            # Display results
            results_text.delete(1.0, tk.END)
            if results:
                debug_print(f"🔍 SEARCH DEBUG: Displaying results and calling highlight_cells()")
                results_text.insert(tk.END, f"Found {len(results)} matches:\n\n")
                results_text.insert(tk.END, "\n".join(results[:50]))  # Show first 50
                if len(results) > 50:
                    results_text.insert(tk.END, f"\n\n... and {len(results)-50} more")
                
                # Highlight the found cells
                debug_print(f"🔍 SEARCH DEBUG: About to call highlight_cells() with {len(found_cells)} items")
                highlight_cells()
                debug_print(f"🔍 SEARCH DEBUG: Returned from highlight_cells()")
            else:
                debug_print(f"🔍 SEARCH DEBUG: No matches found - clearing found_cells and calling highlight_cells()")
                results_text.insert(tk.END, f"No matches found for '{search_text}'")
                found_cells.clear()  # Clear instead of reassign to maintain nonlocal reference
                debug_print(f"🔍 SEARCH DEBUG: found_cells cleared, now has {len(found_cells)} items")
                
                # Call highlight_cells() even with empty found_cells to clear highlights
                highlight_cells()
        
        def perform_replace():
            """Replace first found occurrence with fresh search"""
            # CRITICAL: Clear previous highlights before replace operation
            if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                try:
                    self.table.dehighlight_cells()
                except:
                    pass
            
            replace_text = replace_val.get()
            search_text = search_val.get().strip()
            
            if not search_text:
                messagebox.showwarning("No Search Text", "Please enter text to search for.", parent=dialog)
                return
            
            # Get search options
            is_case_sensitive = case_sensitive.get()
            is_whole_words = whole_words.get()
            
            debug_print(f"🔄 REPLACE DEBUG: Searching for '{search_text}' to replace with '{replace_text}'")
            debug_print(f"🔄 REPLACE DEBUG: case_sensitive={is_case_sensitive}, whole_words={is_whole_words}")
            
            # Perform fresh search to find first occurrence
            try:
                first_found = None
                
                for row in self.ws.iter_rows():
                    for cell in row:
                        if cell.value is not None:
                            cell_text = str(cell.value)
                            
                            # Check for match based on settings - IDENTICAL logic to search
                            found = False
                            if is_case_sensitive:
                                if is_whole_words:
                                    import re
                                    pattern = r'\b' + re.escape(search_text) + r'\b'
                                    found = bool(re.search(pattern, cell_text))
                                else:
                                    found = search_text in cell_text
                            else:
                                if is_whole_words:
                                    import re
                                    pattern = r'\b' + re.escape(search_text) + r'\b'
                                    found = bool(re.search(pattern, cell_text, re.IGNORECASE))
                                else:
                                    found = search_text.lower() in cell_text.lower()
                            
                            debug_print(f"🔄 REPLACE DEBUG: Cell {cell.coordinate} = '{cell_text}', match = {found}")
                            
                            if found:
                                first_found = {
                                    'cell': cell,
                                    'address': cell.coordinate,
                                    'old_value': cell_text
                                }
                                break
                    if first_found:
                        break
                
                if not first_found:
                    messagebox.showinfo("No Results", f"No occurrences of '{search_text}' found.", parent=dialog)
                    return
                
                # Perform replacement on first found cell
                cell = first_found['cell']
                old_value = first_found['old_value']
                
                debug_print(f"🔄 REPLACE DEBUG: Found first match in {first_found['address']}: '{old_value}'")
                
                # Perform replacement - only replace FIRST occurrence in the cell
                import re
                if is_case_sensitive:
                    if is_whole_words:
                        pattern = r'\b' + re.escape(search_text) + r'\b'
                        new_value = re.sub(pattern, replace_text, old_value, count=1)
                    else:
                        # Case-sensitive: use replace() which is safe for simple replacement
                        new_value = old_value.replace(search_text, replace_text, 1)  # Replace only first occurrence
                else:
                    if is_whole_words:
                        pattern = r'\b' + re.escape(search_text) + r'\b'
                        new_value = re.sub(pattern, replace_text, old_value, count=1, flags=re.IGNORECASE)
                    else:
                        # Case-insensitive: MUST use re.sub with IGNORECASE to properly replace
                        new_value = re.sub(re.escape(search_text), replace_text, old_value, count=1, flags=re.IGNORECASE)
                
                debug_print(f"🔄 REPLACE DEBUG: Replacing '{old_value}' → '{new_value}'")
                
                cell.value = new_value
                
                # CRITICAL FIX: Update tksheet directly instead of reloading from workbook
                # This preserves the visual grid and only updates the cell that changed
                if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                    row = first_found['cell'].row - 1  # Convert to 0-based
                    col = first_found['cell'].column - 1  # Convert to 0-based
                    # Update tksheet directly
                    self.table.set_cell_data(row, col, new_value)
                    debug_print(f"🔄 REPLACE: Updated tksheet cell ({row},{col}) to '{new_value}'")
                
                # Mark as unsaved changes
                self.has_unsaved_changes = True
                self.update_window_title()
                
                # Add to undo stack using proper format
                undo_data = {
                    'cell': first_found['address'],
                    'old_value': old_value,
                    'find_value': search_text,
                    'replace_value': replace_text
                }
                self.add_to_undo_stack('replace_single', undo_data)
                
                self.status_main.config(text=f"Replaced 1 occurrence in {first_found['address']}")
                
                # Refresh search results
                perform_search()
                
            except Exception as e:
                debug_print(f"🔄 REPLACE ERROR: {str(e)}")
                messagebox.showerror("Error", f"Error performing replacement: {str(e)}", parent=dialog)
        
        def perform_replace_all():
            """Replace all found occurrences with fresh search - avoiding double replacement"""
            # CRITICAL: Clear previous highlights before replace all operation
            if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                try:
                    self.table.dehighlight_cells()
                except:
                    pass
            
            replace_text = replace_val.get()
            search_text = search_val.get().strip()
            
            if not search_text:
                messagebox.showwarning("No Search Text", "Please enter text to search for.", parent=dialog)
                return
            
            # Get search options  
            is_case_sensitive = case_sensitive.get()
            is_whole_words = whole_words.get()
            
            debug_print(f"🔄 REPLACE ALL DEBUG: Searching for '{search_text}' to replace with '{replace_text}'")
            debug_print(f"🔄 REPLACE ALL DEBUG: case_sensitive={is_case_sensitive}, whole_words={is_whole_words}")
            
            # Perform fresh search to get current state of cells
            current_found_cells = []
            
            try:
                for row in self.ws.iter_rows():
                    for cell in row:
                        if cell.value is not None:
                            cell_text = str(cell.value)
                            
                            # DON'T skip cells that contain replacement text - let regex handle it properly
                            # The regex will only replace exact matches, not partial strings
                            # Example: "san" in "sanjay" will become "Sanjay", not "Sanjayjay"
                            
                            # Check for match based on settings - IDENTICAL logic to search
                            found = False
                            if is_case_sensitive:
                                if is_whole_words:
                                    import re
                                    pattern = r'\b' + re.escape(search_text) + r'\b'
                                    found = bool(re.search(pattern, cell_text))
                                else:
                                    found = search_text in cell_text
                            else:
                                if is_whole_words:
                                    import re
                                    pattern = r'\b' + re.escape(search_text) + r'\b'
                                    found = bool(re.search(pattern, cell_text, re.IGNORECASE))
                                else:
                                    found = search_text.lower() in cell_text.lower()
                            
                            debug_print(f"🔄 REPLACE ALL DEBUG: Cell {cell.coordinate} = '{cell_text}', match = {found}")
                            
                            if found:
                                current_found_cells.append({
                                    'address': cell.coordinate,
                                    'row': cell.row,
                                    'col': cell.column,
                                    'value': cell_text,
                                    'cell_obj': cell
                                })
                
                if not current_found_cells:
                    messagebox.showinfo("No Results", f"No occurrences of '{search_text}' found.", parent=dialog)
                    return
                
                # Confirm replacement - ensure dialog appears in front
                dialog.attributes('-topmost', False)  # Temporarily remove topmost to allow confirmation dialog
                confirm_result = messagebox.askyesno("Confirm Replace All", 
                                                   f"Replace all {len(current_found_cells)} occurrences of '{search_text}' with '{replace_text}'?",
                                                   parent=dialog)
                dialog.attributes('-topmost', True)   # Restore topmost after confirmation
                
                if not confirm_result:
                    return
                
                # Perform replacements
                replaced_count = 0
                
                for cell_info in current_found_cells:
                    cell = cell_info['cell_obj']
                    old_value = cell_info['value']
                    
                    debug_print(f"🔄 REPLACE ALL DEBUG: Processing {cell_info['address']}: '{old_value}'")
                    
                    # Perform replacement - only replace FIRST occurrence in each cell
                    import re
                    if is_case_sensitive:
                        if is_whole_words:
                            pattern = r'\b' + re.escape(search_text) + r'\b'
                            new_value = re.sub(pattern, replace_text, old_value, count=1)
                        else:
                            # Case-sensitive: use replace() which is safe for simple replacement
                            new_value = old_value.replace(search_text, replace_text, 1)  # Replace only first occurrence
                    else:
                        if is_whole_words:
                            pattern = r'\b' + re.escape(search_text) + r'\b'
                            new_value = re.sub(pattern, replace_text, old_value, count=1, flags=re.IGNORECASE)
                        else:
                            # Case-insensitive: MUST use re.sub with IGNORECASE to properly replace
                            new_value = re.sub(re.escape(search_text), replace_text, old_value, count=1, flags=re.IGNORECASE)
                    
                    debug_print(f"🔄 REPLACE ALL DEBUG: '{old_value}' → '{new_value}'")
                    
                    cell.value = new_value
                    replaced_count += 1
                
                # CRITICAL FIX: Update tksheet directly instead of reloading from workbook
                # This preserves the visual grid and only updates the cells that changed
                if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                    for cell_info in current_found_cells:
                        row = cell_info['row'] - 1  # Convert to 0-based
                        col = cell_info['col'] - 1  # Convert to 0-based
                        # Get the updated value from the workbook
                        new_cell_value = self.ws.cell(cell_info['row'], cell_info['col']).value
                        # Update tksheet directly
                        self.table.set_cell_data(row, col, new_cell_value)
                        debug_print(f"🔄 REPLACE: Updated tksheet cell ({row},{col}) to '{new_cell_value}'")
                
                # Mark as unsaved changes
                self.has_unsaved_changes = True
                self.update_window_title()
                
                # Add to undo stack using proper format
                changes = []
                for cell_info in current_found_cells:
                    changes.append({
                        'cell': cell_info['address'],
                        'old_value': cell_info['value']
                    })
                
                undo_data = {
                    'changes': changes,
                    'find_value': search_text,
                    'replace_value': replace_text
                }
                self.add_to_undo_stack('replace_all', undo_data)
                
                self.status_main.config(text=f"Replaced {replaced_count} occurrences")
                
                # Refresh search results to show current state
                perform_search()
                
            except Exception as e:
                debug_print(f"🔄 REPLACE ALL ERROR: {str(e)}")
                messagebox.showerror("Error", f"Error performing replacement: {str(e)}", parent=dialog)
        
        def clear_highlights():
            """Clear cell highlights"""
            if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                try:
                    self.table.dehighlight_cells()
                    self.status_main.config(text="Highlights cleared")
                except Exception as e:
                    debug_print(f"Error clearing highlights: {e}")
        
        # Buttons with better spacing
        button_frame = ttk.Frame(dialog)
        button_frame.grid(row=6, column=0, columnspan=2, pady=(20, 25), padx=20, sticky="ew")
        
        # Search buttons
        search_frame = ttk.Frame(button_frame)
        search_frame.pack(side="top", fill="x", pady=(0, 10))
        
        ttk.Button(search_frame, text="🔍 Find All", command=perform_search, 
                  width=15).pack(side="left", padx=(0, 10))
        ttk.Button(search_frame, text="🎯 Clear Highlights", command=clear_highlights, 
                  width=15).pack(side="left", padx=(0, 10))
        
        # Replace buttons
        replace_frame = ttk.Frame(button_frame)
        replace_frame.pack(side="top", fill="x", pady=(0, 10))
        
        ttk.Button(replace_frame, text="📝 Replace", command=perform_replace, 
                  width=15).pack(side="left", padx=(0, 10))
        ttk.Button(replace_frame, text="📝📝 Replace All", command=perform_replace_all, 
                  width=15).pack(side="left", padx=(0, 10))
        
        # Function to clear highlights and close dialog
        def close_dialog():
            """Clear cell highlights and close the dialog"""
            if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                try:
                    # Clear all highlights - call without parameters
                    self.table.dehighlight_cells()
                    # Also try clearing with 'all' parameter as backup
                    try:
                        self.table.dehighlight_cells(all_=True)
                    except:
                        pass  # Some versions might not support this parameter
                    # Force a refresh of the table
                    self.table.refresh()
                    debug_print(" Cleared cell highlights on dialog close")
                except Exception as e:
                    debug_print(f" Error clearing highlights: {e}")
            dialog.destroy()
        
        # Close button - with extra padding at bottom
        close_frame = ttk.Frame(button_frame)
        close_frame.pack(side="top", fill="x", pady=(0, 5))
        ttk.Button(close_frame, text="❌ Close", command=close_dialog, 
                  width=15).pack(side="top")
        
        # Also bind the window close event to clear highlights
        dialog.protocol("WM_DELETE_WINDOW", close_dialog)
        
        # Configure grid weights
        dialog.columnconfigure(1, weight=1)
        
        # Bind Enter key to search
        search_entry.bind('<Return>', lambda e: perform_search())
        replace_entry.bind('<Return>', lambda e: perform_replace())
        
        # Apply grab_set after all widgets are created
        dialog.grab_set()
    
    def find_and_replace(self):
        """Enhanced find and replace with case-insensitive options - calls find_value for consistency"""
        # Use the same dialog as find_value for consistency
        self.find_value()
    
    # Undo Operation
    def undo(self):
        """Unified undo operation using hybrid system"""
        debug_print("\n🔄 EXCEL UNDO: Starting undo operation")
        
        # Use hybrid manager if available, otherwise use legacy system
        if self.hybrid_undo_manager:
            success = self.hybrid_undo_manager.undo()
            
            if success:
                # Update Excel Editor status
                if hasattr(self, 'status_main'):
                    self.status_main.config(text="Undo operation completed")
                debug_print("✅ EXCEL UNDO: Hybrid undo completed successfully")
            else:
                # Show in status bar instead of popup
                if hasattr(self, 'status_main'):
                    self.status_main.config(text="Nothing to undo")
                debug_print("❌ EXCEL UNDO: No operations to undo")
            
            # Update UI state
            self.update_undo_redo_status()
            return success
        else:
            # Legacy undo system
            return self._legacy_undo()
    
    def _legacy_undo(self):
        if not self.undo_stack:
            # Show in status bar instead of popup
            self.status_main.config(text="Nothing to undo")
            return
        
        try:
            action_type, data = self.undo_stack.pop()
            debug_print(f"🔙 UNDO DEBUG: Undoing '{action_type}' operation")
            
            # Create redo data before performing undo
            redo_data = None
            
            if action_type == 'cell_edit':
                # Undo cell edit
                cell = data['cell']
                old_value = data['old_value']
                new_value = data['new_value']
                debug_print(f" UNDO DEBUG: Reverting {cell}: '{new_value}' → '{old_value}'")
                
                # Create redo data - to restore the new_value that we're undoing
                redo_data = {'cell': cell, 'old_value': old_value, 'new_value': new_value}
                
                # Apply undo to openpyxl
                self.ws[cell].value = old_value
                
                # Update tksheet if available
                if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                    try:
                        import re
                        match = re.match(r'^([A-Z]+)(\d+)$', cell)
                        if match:
                            col_letters = match.group(1)
                            row_num = int(match.group(2))
                            col_idx = column_index_from_string(col_letters) - 1
                            row_idx = row_num - 1
                            self.table.set_cell_data(row_idx, col_idx, old_value if old_value is not None else '')
                    except Exception as e:
                        debug_print(f"️ UNDO: Failed to update tksheet for {cell}: {e}")
                
                self.update_display()
                
            elif action_type == 'cell_clear':
                # Undo cell clear
                cell = data['cell']
                old_value = data['old_value']
                debug_print(f"🗑️ UNDO DEBUG: Restoring cleared {cell}: → '{old_value}'")
                
                # Create redo data - should clear the cell again
                current_value = self.get_cell_value_safely(cell)
                redo_data = {'cell': cell, 'old_value': current_value}
                
                # Apply undo to openpyxl
                self.ws[cell].value = old_value
                
                # Update tksheet if available
                if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                    try:
                        import re
                        match = re.match(r'^([A-Z]+)(\d+)$', cell)
                        if match:
                            col_letters = match.group(1)
                            row_num = int(match.group(2))
                            col_idx = column_index_from_string(col_letters) - 1
                            row_idx = row_num - 1
                            self.table.set_cell_data(row_idx, col_idx, old_value if old_value is not None else '')
                    except Exception as e:
                        debug_print(f"️ UNDO: Failed to update tksheet for {cell}: {e}")
                
                self.update_display()
                
            elif action_type == 'bulk_cell_edit':
                # Undo bulk cell edits from direct editing
                changes = data['changes']
                
                # Create redo data
                redo_changes = []
                for change in changes:
                    cell = change['cell']
                    old_value = change['old_value']
                    new_value = change['new_value']
                    current_value = self.get_cell_value_safely(cell)
                    
                    # Apply undo: restore old value to openpyxl
                    self.ws[cell].value = old_value
                    
                    # Update tksheet if available
                    if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                        try:
                            import re
                            match = re.match(r'^([A-Z]+)(\d+)$', cell)
                            if match:
                                col_letters = match.group(1)
                                row_num = int(match.group(2))
                                col_idx = column_index_from_string(col_letters) - 1
                                row_idx = row_num - 1
                                self.table.set_cell_data(row_idx, col_idx, old_value if old_value is not None else '')
                        except Exception as e:
                            debug_print(f"️ UNDO: Failed to update tksheet for {cell}: {e}")
                    
                    # Create redo data: to restore the new value
                    redo_changes.append({
                        'cell': cell,
                        'old_value': old_value,  # After undo, this will be the current value
                        'new_value': new_value   # This is what we want to restore in redo
                    })
                
                redo_data = {'changes': redo_changes}
                self.update_display()
                
            # For complex operations, use a simplified redo approach
            elif action_type in ['sheet_add', 'sheet_rename', 'sheet_delete', 'sheet_switch',
                               'row_insert', 'row_delete', 'column_insert', 'column_delete', 'find_replace']:
                # For complex operations, store the current state as redo data
                redo_data = {'state_before': self.capture_sheet_state()}
                
                # Continue with existing undo logic for these complex operations
                if action_type == 'sheet_add':
                    # Undo sheet addition
                    sheet_name = data['sheet_name']
                    previous_active = data['previous_active']
                    if sheet_name in self.wb.sheetnames:
                        self.wb.remove(self.wb[sheet_name])
                        self.ws = self.wb[previous_active]
                        self.update_display()
                        
                elif action_type == 'sheet_rename':
                    # Undo sheet rename
                    old_name = data['old_name']
                    new_name = data['new_name']
                    if new_name in self.wb.sheetnames:
                        self.wb[new_name].title = old_name
                        self.update_display()
                        
                elif action_type == 'sheet_delete':
                    # Undo sheet deletion
                    sheet_name = data['sheet_name']
                    sheet_data = data['sheet_data']
                    sheet_index = data['sheet_index']
                    was_active = data['was_active']
                    
                    # Create new sheet
                    new_sheet = self.wb.create_sheet(title=sheet_name, index=sheet_index)
                    
                    # Restore data
                    for row_idx, row_data in enumerate(sheet_data, start=1):
                        for col_idx, cell_value in enumerate(row_data, start=1):
                            if cell_value is not None:
                                new_sheet.cell(row_idx, col_idx, cell_value)
                    
                    if was_active:
                        self.ws = new_sheet
                    
                    self.update_display()
                    
                elif action_type == 'sheet_switch':
                    # Undo sheet switch
                    old_sheet = data['old_sheet']
                    if old_sheet in self.wb.sheetnames:
                        self.ws = self.wb[old_sheet]
                        self.update_display()
                        
                elif action_type in ['row_insert', 'row_delete', 'column_insert', 'column_delete', 'find_replace']:
                    # Undo row/column operations and find/replace by restoring entire sheet state
                    state_before = data['state_before']
                    self.restore_sheet_state(state_before)
                    self.update_display()
                    
            elif action_type in ['paste_operation', 'clear_selection', 'replace_single']:
                # Handle cell operations (both single and multiple cells)
                affected_cells = data.get('affected_cells')
                paste_type = data.get('type')
                
                if affected_cells:
                    # New format with multiple cells
                    debug_print(f" UNDO DEBUG: Undoing {action_type} ({paste_type}) for {len(affected_cells)} cells")
                    
                    if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                        for row, col, old_value, _ in affected_cells:
                            self.table.set_cell_data(row, col, old_value if old_value else '')
                            # Also update openpyxl
                            cell_addr = f"{get_column_letter(col+1)}{row+1}"
                            self.ws[cell_addr].value = old_value
                    
                    self.update_display()
                    
                else:
                    # Legacy single cell format
                    cell_addr = data.get('cell')
                    old_value = data.get('old_value')
                    if cell_addr:
                        current_value = str(self.ws[cell_addr].value) if self.ws[cell_addr].value is not None else ''
                        
                        debug_print(f" UNDO DEBUG: Undoing {action_type} for {cell_addr}: restoring '{old_value}'")
                        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                            # Parse cell address
                            import re
                            match = re.match(r'^([A-Z]+)(\d+)$', cell_addr)
                            if match:
                                col_letters = match.group(1)
                                row_num = int(match.group(2))
                                col_idx = column_index_from_string(col_letters) - 1
                                row_idx = row_num - 1
                                self.table.set_cell_data(row_idx, col_idx, old_value if old_value else '')
                        self.ws[cell_addr].value = old_value
                        self.update_display()
                    
            elif action_type == 'replace_all':
                # Undo replace all operation
                changes = data.get('changes', [])
                if changes:
                    debug_print(f" UNDO DEBUG: Undoing replace all for {len(changes)} cells")
                    
                    # Create redo data
                    redo_changes = []
                    for change in changes:
                        cell_addr = change['cell']
                        old_value = change['old_value']
                        current_value = str(self.ws[cell_addr].value) if self.ws[cell_addr].value is not None else ''
                        redo_changes.append({'cell': cell_addr, 'old_value': current_value})
                        
                        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                            # Parse cell address
                            import re
                            match = re.match(r'^([A-Z]+)(\d+)$', cell_addr)
                            if match:
                                col_letters = match.group(1)
                                row_num = int(match.group(2))
                                col_idx = column_index_from_string(col_letters) - 1
                                row_idx = row_num - 1
                                self.table.set_cell_data(row_idx, col_idx, old_value if old_value else '')
                        self.ws[cell_addr].value = old_value
                    
                    redo_data = {'changes': redo_changes, 'find_value': data.get('find_value'), 'replace_value': data.get('replace_value')}
                    self.update_display()
            
            else:
                # For any unhandled action types, create basic redo data
                redo_data = data.copy()  # Simple copy for fallback
            
            # Add to redo stack if we have redo data and space
            if redo_data is not None:
                self.redo_stack.append((action_type, redo_data))
                
                # Limit redo stack size
                if len(self.redo_stack) > self.max_redo_stack:
                    self.redo_stack.pop(0)
                    
                debug_print(f"➡️ REDO DEBUG: Added '{action_type}' to redo stack (size: {len(self.redo_stack)})")
            
            # Update status
            self.update_undo_redo_status()
                
        except Exception as e:
            messagebox.showerror("Error", f"Failed to undo:\n{str(e)}")
            # Re-add the action to undo stack if undo failed
            self.undo_stack.append((action_type, data))
    
    def redo(self):
        """Unified redo operation using hybrid system"""
        debug_print("\n🔄 EXCEL REDO: Starting redo operation")
        
        # Use hybrid manager if available, otherwise use legacy system
        if self.hybrid_undo_manager:
            success = self.hybrid_undo_manager.redo()
            
            if success:
                # Update Excel Editor status
                if hasattr(self, 'status_main'):
                    self.status_main.config(text="Redo operation completed")
                debug_print("✅ EXCEL REDO: Hybrid redo completed successfully")
            else:
                # Show in status bar instead of popup
                if hasattr(self, 'status_main'):
                    self.status_main.config(text="Nothing to redo")
                debug_print("❌ EXCEL REDO: No operations to redo")
            
            # Update UI state
            self.update_undo_redo_status()
            return success
        else:
            # Legacy redo system
            return self._legacy_redo()
    
    def _legacy_redo(self):
        """Legacy redo implementation"""
        if not self.redo_stack:
            messagebox.showinfo("Redo", "Nothing to redo")
            return
        
        try:
            action_type, data = self.redo_stack.pop()
            debug_print(f"📤 REDO DEBUG: Performing '{action_type}' redo")
            
            # Store undo data for the redo operation
            undo_data = None
            
            if action_type == 'cell_edit':
                # Redo cell edit - data format: {'cell': 'A1', 'old_value': 'old', 'new_value': 'new'}
                cell = data['cell']
                new_value = data['new_value']
                
                # Get current value for undo
                current_value = self.get_cell_value_safely(cell)
                undo_data = {
                    'cell': cell,
                    'old_value': current_value,
                    'new_value': new_value
                }
                
                # Apply redo to both openpyxl and tksheet
                self.ws[cell].value = new_value
                
                # Update tksheet if available
                if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                    try:
                        import re
                        match = re.match(r'^([A-Z]+)(\d+)$', cell)
                        if match:
                            col_letters = match.group(1)
                            row_num = int(match.group(2))
                            col_idx = column_index_from_string(col_letters) - 1
                            row_idx = row_num - 1
                            self.table.set_cell_data(row_idx, col_idx, new_value if new_value is not None else '')
                    except Exception as e:
                        debug_print(f"️ REDO: Failed to update tksheet for {cell}: {e}")
                
                self.update_display()
                debug_print(f"🔄 REDO: Cell {cell} set to '{new_value}'")
                
            elif action_type == 'cell_clear':
                # Redo cell clear - data format: {'cell': 'A1', 'old_value': 'old'}
                cell = data['cell']
                
                # Get current value for undo
                current_value = self.get_cell_value_safely(cell)
                undo_data = {
                    'cell': cell,
                    'old_value': current_value
                }
                
                # Apply redo (clear cell) to both openpyxl and tksheet
                self.ws[cell].value = None
                
                # Update tksheet if available
                if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                    try:
                        import re
                        match = re.match(r'^([A-Z]+)(\d+)$', cell)
                        if match:
                            col_letters = match.group(1)
                            row_num = int(match.group(2))
                            col_idx = column_index_from_string(col_letters) - 1
                            row_idx = row_num - 1
                            self.table.set_cell_data(row_idx, col_idx, '')
                    except Exception as e:
                        debug_print(f"️ REDO: Failed to update tksheet for {cell}: {e}")
                
                self.update_display()
                debug_print(f"🗑️ REDO: Cell {cell} cleared")
                
            elif action_type == 'bulk_cell_edit':
                # Redo bulk cell edits - data format: {'changes': [{'cell': 'A1', 'old_value': 'old', 'new_value': 'new'}]}
                changes = data['changes']
                undo_changes = []
                
                # Get current values for undo and apply redo changes
                for change in changes:
                    cell = change['cell']
                    new_value = change['new_value']
                    current_value = self.get_cell_value_safely(cell)
                    
                    undo_changes.append({
                        'cell': cell,
                        'old_value': current_value,
                        'new_value': new_value
                    })
                    
                    # Apply redo change to openpyxl
                    self.ws[cell].value = new_value
                    
                    # Update tksheet if available
                    if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                        try:
                            import re
                            match = re.match(r'^([A-Z]+)(\d+)$', cell)
                            if match:
                                col_letters = match.group(1)
                                row_num = int(match.group(2))
                                col_idx = column_index_from_string(col_letters) - 1
                                row_idx = row_num - 1
                                self.table.set_cell_data(row_idx, col_idx, new_value if new_value is not None else '')
                        except Exception as e:
                            debug_print(f"️ REDO: Failed to update tksheet for {cell}: {e}")
                
                undo_data = {'changes': undo_changes}
                self.update_display()
                debug_print(f" REDO: Applied {len(changes)} cell changes")
                
            elif action_type in ['sheet_add', 'sheet_delete', 'sheet_rename', 'sheet_switch']:
                # Handle sheet operations
                if action_type == 'sheet_add':
                    sheet_name = data['sheet_name']
                    previous_active = data['previous_active']
                    # Undo data: reverse sheet addition
                    undo_data = {'sheet_name': sheet_name, 'previous_active': self.ws.title}
                    # Apply redo: create sheet
                    self.wb.create_sheet(sheet_name)
                    self.update_display()
                    debug_print(f"📄 REDO: Added sheet '{sheet_name}'")
                    
                elif action_type == 'sheet_delete':
                    sheet_name = data['sheet_name']
                    sheet_data = data['sheet_data']
                    sheet_index = data['sheet_index']
                    was_active = data['was_active']
                    # Undo data: restore sheet
                    undo_data = {
                        'sheet_name': sheet_name, 
                        'sheet_data': sheet_data,
                        'sheet_index': sheet_index,
                        'was_active': was_active
                    }
                    # Apply redo: delete sheet
                    if sheet_name in self.wb.sheetnames and len(self.wb.sheetnames) > 1:
                        # Switch to another sheet if deleting active sheet
                        if self.ws.title == sheet_name:
                            other_sheets = [s for s in self.wb.sheetnames if s != sheet_name]
                            if other_sheets:
                                self.ws = self.wb[other_sheets[0]]
                        del self.wb[sheet_name]
                        self.update_display()
                    debug_print(f"🗑️ REDO: Deleted sheet '{sheet_name}'")
                    
                elif action_type == 'sheet_rename':
                    old_name = data['old_name']
                    new_name = data['new_name']
                    # Undo data: reverse the rename
                    undo_data = {'old_name': new_name, 'new_name': old_name}
                    # Apply redo: rename sheet
                    if old_name in self.wb.sheetnames:
                        self.wb[old_name].title = new_name
                        if self.ws.title == old_name:
                            self.ws = self.wb[new_name]
                        self.update_display()
                    debug_print(f" REDO: Renamed sheet '{old_name}' to '{new_name}'")
                    
                elif action_type == 'sheet_switch':
                    old_sheet = data['old_sheet']
                    new_sheet = data['new_sheet']
                    # Undo data: reverse the switch
                    undo_data = {'old_sheet': new_sheet, 'new_sheet': old_sheet}
                    # Apply redo: switch to new sheet
                    if new_sheet in self.wb.sheetnames:
                        self.ws = self.wb[new_sheet]
                        self.update_display()
                    debug_print(f"📂 REDO: Switched to sheet '{new_sheet}'")
                    
            elif action_type in ['row_insert', 'row_delete', 'column_insert', 'column_delete', 'find_replace']:
                # For complex operations, restore state and create reverse undo data
                state_before = data['state_before']
                
                # Capture current state for undo
                undo_data = {'state_before': self.capture_sheet_state()}
                
                # Apply redo: restore the state
                self.restore_sheet_state(state_before)
                self.update_display()
                debug_print(f"🔄 REDO: Restored state for '{action_type}'")
                    
            elif action_type in ['paste_operation', 'clear_selection', 'replace_single']:
                # Handle simple cell operations with correct data format
                cell_addr = data.get('cell')
                old_value = data.get('old_value')
                if cell_addr:
                    current_value = str(self.ws[cell_addr].value) if self.ws[cell_addr].value is not None else ''
                    
                    # Create undo data with correct format
                    undo_data = {'cell': cell_addr, 'old_value': current_value}
                    if action_type == 'replace_single':
                        undo_data.update({
                            'find_value': data.get('find_value'), 
                            'replace_value': data.get('replace_value')
                        })
                    
                    debug_print(f" REDO: Applying {action_type} for {cell_addr}: setting '{old_value}'")
                    
                    # Apply redo operation
                    if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                        # Parse cell address for tksheet
                        import re
                        match = re.match(r'^([A-Z]+)(\d+)$', cell_addr)
                        if match:
                            col_letters = match.group(1)
                            row_num = int(match.group(2))
                            col_idx = column_index_from_string(col_letters) - 1
                            row_idx = row_num - 1
                            self.table.set_cell_data(row_idx, col_idx, old_value if old_value else '')
                    
                    self.ws[cell_addr].value = old_value
                    self.update_display()
                    
            elif action_type == 'replace_all':
                # Redo replace all operation
                changes = data.get('changes', [])
                if changes:
                    debug_print(f" REDO: Redoing replace all for {len(changes)} cells")
                    
                    # Create undo data
                    undo_changes = []
                    for change in changes:
                        cell_addr = change['cell']
                        old_value = change['old_value']
                        current_value = str(self.ws[cell_addr].value) if self.ws[cell_addr].value is not None else ''
                        undo_changes.append({'cell': cell_addr, 'old_value': current_value})
                        
                        # Apply redo operation
                        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                            # Parse cell address for tksheet
                            import re
                            match = re.match(r'^([A-Z]+)(\d+)$', cell_addr)
                            if match:
                                col_letters = match.group(1)
                                row_num = int(match.group(2))
                                col_idx = column_index_from_string(col_letters) - 1
                                row_idx = row_num - 1
                                self.table.set_cell_data(row_idx, col_idx, old_value if old_value else '')
                        
                        self.ws[cell_addr].value = old_value
                    
                    undo_data = {
                        'changes': undo_changes, 
                        'find_value': data.get('find_value'), 
                        'replace_value': data.get('replace_value')
                    }
                    self.update_display()
            
            else:
                # For any unhandled action types, use fallback
                debug_print(f"️ REDO WARNING: Unhandled action type '{action_type}', using fallback")
                undo_data = data.copy()  # Simple copy for fallback
            
            # Add to undo stack if we have undo data
            if undo_data is not None:
                self.undo_stack.append((action_type, undo_data))
                
                # Limit undo stack size
                if len(self.undo_stack) > self.max_undo_stack:
                    self.undo_stack.pop(0)
                    
                debug_print(f"⬅️ UNDO DEBUG: Added '{action_type}' to undo stack (size: {len(self.undo_stack)})")
            
            # Update status
            self.update_undo_redo_status()
                
        except Exception as e:
            messagebox.showerror("Error", f"Failed to redo:\n{str(e)}")
            # Re-add the action to redo stack if redo failed
            self.redo_stack.append((action_type, data))
    
    def _execute_legacy_undo(self, legacy_action):
        """Execute a single legacy undo operation for hybrid system"""
        try:
            action_type, data = legacy_action
            debug_print(f"🔙 HYBRID-LEGACY UNDO: Executing '{action_type}' operation")
            
            # Use the same logic from _legacy_undo but for a single operation
            if action_type == 'paste_operation':
                # Undo paste operation by restoring old values
                affected_cells = data.get('affected_cells', [])
                debug_print(f"     📝 Undoing paste operation: restoring {len(affected_cells)} cells")
                
                for cell_info in affected_cells:
                    row_idx, col_idx, old_value, new_value = cell_info
                    # Restore old value in tksheet
                    self.table.set_cell_data(row_idx, col_idx, old_value)
                    # Restore old value in openpyxl
                    excel_row = row_idx + 1
                    excel_col = col_idx + 1
                    self.ws.cell(row=excel_row, column=excel_col, value=old_value)
                
                self.update_display()
                return True
            
            elif action_type == 'replace_single':
                # Undo single find/replace operation
                cell_addr = data.get('cell')
                old_value = data.get('old_value')
                debug_print(f"     📝 Undoing replace_single: restoring {cell_addr} to '{old_value}'")
                
                # Parse cell address (e.g., "A1" -> row=1, col=1)
                from openpyxl.utils.cell import coordinate_from_string
                col_letter, row_num = coordinate_from_string(cell_addr)
                col_idx = column_index_from_string(col_letter) - 1  # 0-based for tksheet
                row_idx = row_num - 1  # 0-based for tksheet
                
                # Restore old value in tksheet
                self.table.set_cell_data(row_idx, col_idx, old_value)
                # Restore old value in openpyxl
                self.ws.cell(row=row_num, column=col_idx + 1, value=old_value)
                
                self.update_display()
                return True
            
            elif action_type == 'replace_all':
                # Undo replace_all operation
                changes = data.get('changes', [])
                debug_print(f"     📝 Undoing replace_all: restoring {len(changes)} cells")
                
                from openpyxl.utils.cell import coordinate_from_string
                for change_info in changes:
                    cell_addr = change_info.get('cell')
                    old_value = change_info.get('old_value')
                    
                    # Parse cell address
                    col_letter, row_num = coordinate_from_string(cell_addr)
                    col_idx = column_index_from_string(col_letter) - 1  # 0-based for tksheet
                    row_idx = row_num - 1  # 0-based for tksheet
                    
                    # Restore old value in tksheet
                    self.table.set_cell_data(row_idx, col_idx, old_value)
                    # Restore old value in openpyxl
                    self.ws.cell(row=row_num, column=col_idx + 1, value=old_value)
                
                self.update_display()
                return True
            
            elif action_type in ['sheet_add', 'sheet_rename', 'sheet_delete', 'sheet_switch',
                              'row_insert', 'row_delete', 'column_insert', 'column_delete']:
                
                if action_type == 'sheet_add':
                    # Undo sheet addition
                    sheet_name = data['sheet_name']
                    previous_active = data['previous_active']
                    if sheet_name in self.wb.sheetnames:
                        self.wb.remove(self.wb[sheet_name])
                        self.ws = self.wb[previous_active]
                        self.update_display()
                        return True
                        
                elif action_type == 'sheet_rename':
                    # Undo sheet rename
                    old_name = data['old_name']
                    new_name = data['new_name']
                    if new_name in self.wb.sheetnames:
                        self.wb[new_name].title = old_name
                        self.update_display()
                        return True
                        
                elif action_type == 'sheet_delete':
                    # Undo sheet deletion
                    sheet_name = data['sheet_name']
                    sheet_data = data['sheet_data']
                    sheet_index = data['sheet_index']
                    was_active = data['was_active']
                    
                    # Create new sheet
                    new_sheet = self.wb.create_sheet(title=sheet_name, index=sheet_index)
                    
                    # Restore data
                    for row_idx, row_data in enumerate(sheet_data, start=1):
                        for col_idx, cell_value in enumerate(row_data, start=1):
                            if cell_value is not None:
                                new_sheet.cell(row_idx, col_idx, cell_value)
                    
                    if was_active:
                        self.ws = new_sheet
                    
                    self.update_display()
                    return True
                    
                elif action_type == 'sheet_switch':
                    # Undo sheet switch
                    old_sheet = data['old_sheet']
                    if old_sheet in self.wb.sheetnames:
                        self.ws = self.wb[old_sheet]
                        self.update_display()
                        return True
                        
                elif action_type in ['row_insert', 'row_delete', 'column_insert', 'column_delete', 'find_replace']:
                    # For structural operations, handle them specifically instead of just restoring state
                    if action_type == 'row_insert':
                        # Undo row insertion by deleting the inserted row
                        insert_position = data.get('insert_position', 1)
                        debug_print(f"     📝 Undoing row insertion by deleting row at position {insert_position}")
                        
                        # Delete from both openpyxl and tksheet
                        if self.ws.max_row >= insert_position:
                            self.ws.delete_rows(insert_position)
                            if hasattr(self, 'table') and self.table:
                                # tksheet uses 0-based indexing
                                self.table.del_row(insert_position - 1)
                        
                        self.update_display()
                        return True
                        
                    elif action_type == 'column_insert':
                        # Undo column insertion by deleting the inserted column
                        insert_position = data.get('insert_position', data.get('column_index', 1))
                        debug_print(f"     📝 Undoing column insertion by deleting column at position {insert_position}")
                        
                        # Delete from both openpyxl and tksheet
                        if self.ws.max_column >= insert_position:
                            self.ws.delete_cols(insert_position)
                            if hasattr(self, 'table') and self.table:
                                # tksheet uses 0-based indexing
                                self.table.del_column(insert_position - 1)
                        
                        self.update_display()
                        return True
                        
                    elif action_type == 'row_delete':
                        # Undo row deletion by restoring from state
                        state_before = data.get('state_before')
                        if state_before:
                            debug_print(f"     📝 Undoing row deletion by restoring sheet state")
                            self.restore_sheet_state(state_before)
                            self.update_display()
                            return True
                        
                    elif action_type == 'column_delete':
                        # Undo column deletion by restoring from state
                        state_before = data.get('state_before')
                        if state_before:
                            debug_print(f"     📝 Undoing column deletion by restoring sheet state")
                            self.restore_sheet_state(state_before)
                            self.update_display()
                            return True
            
            debug_print(f" HYBRID-LEGACY UNDO: Unsupported action type: {action_type}")
            return False
                    
        except Exception as e:
            debug_print(f" HYBRID-LEGACY UNDO: Error executing {action_type}: {e}")
            return False
    
    def _execute_legacy_redo(self, legacy_action):
        """Execute a single legacy redo operation for hybrid system"""
        try:
            action_type, data = legacy_action
            debug_print(f"📤 HYBRID-LEGACY REDO: Executing '{action_type}' operation")
            
            # Use the same logic from _legacy_redo but for a single operation
            if action_type == 'paste_operation':
                # Redo paste operation by applying new values
                affected_cells = data.get('affected_cells', [])
                debug_print(f"     📝 Redoing paste operation: applying {len(affected_cells)} cells")
                
                for cell_info in affected_cells:
                    row_idx, col_idx, old_value, new_value = cell_info
                    # Apply new value in tksheet
                    self.table.set_cell_data(row_idx, col_idx, new_value)
                    # Apply new value in openpyxl
                    excel_row = row_idx + 1
                    excel_col = col_idx + 1
                    self.ws.cell(row=excel_row, column=excel_col, value=new_value)
                
                self.update_display()
                return True
            
            elif action_type == 'replace_single':
                # Redo single find/replace operation
                cell_addr = data.get('cell')
                find_value = data.get('find_value')
                replace_value = data.get('replace_value')
                old_value = data.get('old_value')
                debug_print(f"     📝 Redoing replace_single: replacing '{find_value}' with '{replace_value}' in {cell_addr}")
                
                # Parse cell address
                from openpyxl.utils.cell import coordinate_from_string
                col_letter, row_num = coordinate_from_string(cell_addr)
                col_idx = column_index_from_string(col_letter) - 1  # 0-based for tksheet
                row_idx = row_num - 1  # 0-based for tksheet
                
                # Perform replacement on old_value to get new_value
                import re
                new_value = re.sub(re.escape(find_value), replace_value, old_value, count=1, flags=re.IGNORECASE)
                
                # Apply new value in tksheet
                self.table.set_cell_data(row_idx, col_idx, new_value)
                # Apply new value in openpyxl
                self.ws.cell(row=row_num, column=col_idx + 1, value=new_value)
                
                self.update_display()
                return True
            
            elif action_type == 'replace_all':
                # Redo replace_all operation
                changes = data.get('changes', [])
                find_value = data.get('find_value')
                replace_value = data.get('replace_value')
                debug_print(f"     📝 Redoing replace_all: replacing '{find_value}' with '{replace_value}' in {len(changes)} cells")
                
                from openpyxl.utils.cell import coordinate_from_string
                import re
                for change_info in changes:
                    cell_addr = change_info.get('cell')
                    old_value = change_info.get('old_value')
                    
                    # Parse cell address
                    col_letter, row_num = coordinate_from_string(cell_addr)
                    col_idx = column_index_from_string(col_letter) - 1  # 0-based for tksheet
                    row_idx = row_num - 1  # 0-based for tksheet
                    
                    # Perform replacement on old_value to get new_value
                    new_value = re.sub(re.escape(find_value), replace_value, old_value, count=1, flags=re.IGNORECASE)
                    
                    # Apply new value in tksheet
                    self.table.set_cell_data(row_idx, col_idx, new_value)
                    # Apply new value in openpyxl
                    self.ws.cell(row=row_num, column=col_idx + 1, value=new_value)
                
                self.update_display()
                return True
            
            elif action_type in ['sheet_add', 'sheet_rename', 'sheet_delete', 'sheet_switch',
                              'row_insert', 'row_delete', 'column_insert', 'column_delete']:
                
                if action_type == 'sheet_add':
                    # Redo sheet addition
                    sheet_name = data['sheet_name']
                    if sheet_name not in self.wb.sheetnames:
                        new_sheet = self.wb.create_sheet(title=sheet_name)
                        self.ws = new_sheet
                        self.update_display()
                        return True
                        
                elif action_type == 'sheet_rename':
                    # Redo sheet rename
                    old_name = data['old_name']
                    new_name = data['new_name']
                    if old_name in self.wb.sheetnames:
                        self.wb[old_name].title = new_name
                        self.update_display()
                        return True
                        
                elif action_type == 'sheet_delete':
                    # Redo sheet deletion
                    sheet_name = data['sheet_name']
                    if sheet_name in self.wb.sheetnames:
                        if len(self.wb.sheetnames) > 1:
                            was_active = (sheet_name == self.ws.title)
                            self.wb.remove(self.wb[sheet_name])
                            if was_active:
                                self.ws = self.wb.active
                            self.update_display()
                            return True
                    
                elif action_type == 'sheet_switch':
                    # Redo sheet switch
                    new_sheet = data['new_sheet']
                    if new_sheet in self.wb.sheetnames:
                        self.ws = self.wb[new_sheet]
                        self.update_display()
                        return True
                        
                elif action_type in ['row_insert', 'row_delete', 'column_insert', 'column_delete', 'find_replace']:
                    # For structural operations, we need to properly redo the operations
                    if action_type == 'row_insert':
                        # Redo row insertion
                        insert_position = data.get('insert_position', 1)
                        debug_print(f"     📝 Redoing row insertion at position {insert_position}")
                        debug_print(f"     📊 BEFORE: Worksheet dimensions: {self.ws.max_row}x{self.ws.max_column}")
                        debug_print(f"     🔍 DEBUG: Full redo data keys = {list(data.keys())}")
                        
                        # Insert in openpyxl worksheet - only insert 1 row
                        # The 'rows' dict in tksheet data is for content restoration, not count
                        self.ws.insert_rows(insert_position, 1)
                        # CRITICAL: Write at least one cell to make openpyxl recognize the new row
                        self.ws.cell(row=insert_position, column=1, value="")
                        debug_print(f"     � AFTER insert_rows: Worksheet dimensions: {self.ws.max_row}x{self.ws.max_column}")
                        
                        # Restore row content if available in tksheet data
                        if 'rows' in data and isinstance(data['rows'], dict):
                            debug_print(f"     📦 Restoring content for {len(data['rows'])} rows from tksheet data")
                            for row_idx_str, row_data in data['rows'].items():
                                row_idx = int(row_idx_str)
                                # row_idx is 0-based from tksheet, convert to 1-based for openpyxl
                                openpyxl_row = row_idx + 1
                                if isinstance(row_data, dict):
                                    for col_idx_str, cell_value in row_data.items():
                                        col_idx = int(col_idx_str)
                                        openpyxl_col = col_idx + 1
                                        self.ws.cell(row=openpyxl_row, column=openpyxl_col, value=cell_value)
                                        debug_print(f"       📝 Restored cell ({openpyxl_row}, {openpyxl_col}) = {cell_value}")
                        
                        # CRITICAL: Reload tksheet from openpyxl to ensure sync
                        # Don't use tksheet.insert_row() as it adds to existing state
                        debug_print(f"     📊 Reloading tksheet from openpyxl to sync...")
                        self.update_tksheet_display()
                        return True
                        
                    elif action_type == 'column_insert':
                        # Redo column insertion
                        insert_position = data.get('insert_position', data.get('column_index', 1))
                        debug_print(f"     📝 Redoing column insertion at position {insert_position}")
                        debug_print(f"     📊 BEFORE: Worksheet dimensions: {self.ws.max_row}x{self.ws.max_column}")
                        debug_print(f"     🔍 DEBUG: Full redo data keys = {list(data.keys())}")
                        
                        # Insert in openpyxl worksheet - only insert 1 column
                        # The 'columns' dict in tksheet data is for content restoration, not count
                        self.ws.insert_cols(insert_position, 1)
                        # CRITICAL: Write at least one cell to make openpyxl recognize the new column
                        self.ws.cell(row=1, column=insert_position, value="")
                        debug_print(f"     📊 AFTER insert_cols: Worksheet dimensions: {self.ws.max_row}x{self.ws.max_column}")
                        
                        # Restore column content if available in tksheet data
                        if 'columns' in data and isinstance(data['columns'], dict):
                            debug_print(f"     📦 Restoring content for {len(data['columns'])} columns from tksheet data")
                            for col_idx_str, col_data in data['columns'].items():
                                col_idx = int(col_idx_str)
                                # col_idx is 0-based from tksheet, convert to 1-based for openpyxl
                                openpyxl_col = col_idx + 1
                                if isinstance(col_data, dict):
                                    for row_idx_str, cell_value in col_data.items():
                                        row_idx = int(row_idx_str)
                                        openpyxl_row = row_idx + 1
                                        self.ws.cell(row=openpyxl_row, column=openpyxl_col, value=cell_value)
                                        debug_print(f"       📝 Restored cell ({openpyxl_row}, {openpyxl_col}) = {cell_value}")
                        
                        # CRITICAL: Reload tksheet from openpyxl to ensure sync
                        # Don't use tksheet.insert_column() as it adds to existing state
                        debug_print(f"     📊 Reloading tksheet from openpyxl to sync...")
                        self.update_tksheet_display()
                        return True
                        
                    elif action_type == 'row_delete':
                        # For row deletion redo, we need the row number that was deleted
                        row_number = data.get('row_number', data.get('insert_position', 1))
                        debug_print(f"     📝 Redoing row deletion at position {row_number}")
                        
                        # Delete from both openpyxl and tksheet
                        self.ws.delete_rows(row_number)
                        if hasattr(self, 'table') and self.table:
                            # tksheet uses 0-based indexing
                            self.table.del_row(row_number - 1)
                        
                        self.update_display()
                        return True
                        
                    elif action_type == 'column_delete':
                        # For column deletion redo, we need the column number that was deleted
                        column_index = data.get('column_index', data.get('insert_position', 1))
                        debug_print(f"     📝 Redoing column deletion at position {column_index}")
                        
                        # Delete from both openpyxl and tksheet
                        self.ws.delete_cols(column_index)
                        if hasattr(self, 'table') and self.table:
                            # tksheet uses 0-based indexing
                            self.table.del_column(column_index - 1)
                        
                        self.update_display()
                        return True
            
            debug_print(f" HYBRID-LEGACY REDO: Unsupported action type: {action_type}")
            return False
                    
        except Exception as e:
            debug_print(f" HYBRID-LEGACY REDO: Error executing {action_type}: {e}")
            return False
    
    def clear_undo_history(self):
        """Clear the undo history"""
        if not self.undo_stack:
            # Show in status bar instead of popup
            self.status_main.config(text="Undo history is already empty")
            return
        
        count = len(self.undo_stack)
        confirm = messagebox.askyesno("Clear Undo History", 
            f"Clear {count} operations from undo history?\n\nThis cannot be undone.")
        
        if confirm:
            self.undo_stack.clear()
            # Show in status bar instead of popup
            self.status_main.config(text=f"Undo history cleared ({count} operations)")
    
    def show_undo_stack(self):
        """Show the current undo stack for debugging"""
        if not self.undo_stack:
            messagebox.showinfo("Undo Stack", "Undo stack is empty")
            return
        
        # Create detailed undo stack display
        stack_info = f"Undo Stack ({len(self.undo_stack)} operations):\n\n"
        
        for i, (action_type, data) in enumerate(reversed(self.undo_stack), 1):
            stack_info += f"{i}. {action_type.upper()}\n"
            
            if action_type == 'bulk_cell_edit':
                changes = data.get('changes', [])
                stack_info += f"   📝 {len(changes)} cell changes:\n"
                for change in changes[:3]:  # Show first 3 changes
                    old_val = str(change['old_value'])[:20] if change['old_value'] else "None"
                    new_val = str(change['new_value'])[:20] if change['new_value'] else "None"
                    stack_info += f"      • {change['cell']}: '{old_val}' → '{new_val}'\n"
                if len(changes) > 3:
                    stack_info += f"      • ... and {len(changes) - 3} more\n"
            
            elif action_type == 'cell_edit':
                cell = data.get('cell', 'unknown')
                old_val = str(data.get('old_value', ''))[:20]
                new_val = str(data.get('new_value', ''))[:20]
                stack_info += f"   📝 Cell {cell}: '{old_val}' → '{new_val}'\n"
            
            elif action_type == 'sheet_add':
                sheet_name = data.get('sheet_name', 'unknown')
                stack_info += f"   📄 Added sheet: {sheet_name}\n"
            
            elif action_type == 'sheet_rename':
                old_name = data.get('old_name', 'unknown')
                new_name = data.get('new_name', 'unknown')
                stack_info += f"   📄 Renamed: {old_name} → {new_name}\n"
            
            elif action_type == 'replace_single':
                cell = data.get('cell', 'unknown')
                old_val = str(data.get('old_value', ''))[:20]
                find_val = str(data.get('find_value', ''))[:20]
                replace_val = str(data.get('replace_value', ''))[:20]
                stack_info += f"   🔍 Replace in {cell}: '{old_val}' ('{find_val}' → '{replace_val}')\n"
            
            elif action_type == 'replace_all':
                changes = data.get('changes', [])
                find_val = str(data.get('find_value', ''))[:20]
                replace_val = str(data.get('replace_value', ''))[:20]
                stack_info += f"   🔍 Replace All: '{find_val}' → '{replace_val}' in {len(changes)} cells\n"
                for change in changes[:2]:  # Show first 2 changes
                    cell = change['cell']
                    old_val = str(change['old_value'])[:15]
                    stack_info += f"      • {cell}: '{old_val}'\n"
                if len(changes) > 2:
                    stack_info += f"      • ... and {len(changes) - 2} more\n"
            
            else:
                stack_info += f"   📋 Data: {str(data)[:50]}...\n"
            
            stack_info += "\n"
        
        # Show in a scrollable dialog
        dialog = tk.Toplevel(self.master)
        dialog.title("Undo Stack Debug")
        dialog.geometry("600x400")
        dialog.resizable(True, True)
        
        # Create text widget with scrollbar
        text_frame = ttk.Frame(dialog)
        text_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        text_widget = tk.Text(text_frame, wrap="word", font=("Courier", 10))
        scrollbar = ttk.Scrollbar(text_frame, orient="vertical", command=text_widget.yview)
        text_widget.configure(yscrollcommand=scrollbar.set)
        
        text_widget.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        text_widget.insert("1.0", stack_info)
        text_widget.config(state="disabled")
        
        # Close button
        ttk.Button(dialog, text="Close", command=dialog.destroy).pack(pady=5)
    
    # Context-sensitive row/column operations
    def insert_row_before_selected(self):
        """Insert a row before the currently selected row"""
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            # Get target row from current selection
            target_row = None
            selected_rows = self.table.get_selected_rows() if hasattr(self.table, 'get_selected_rows') else []
            
            if selected_rows:
                # Full row selected
                target_row = min(selected_rows)
            elif hasattr(self, 'current_row') and self.current_row is not None:
                # Use current cell's row
                target_row = self.current_row
            
            if target_row is not None:
                # Capture state for undo
                state_before = self.capture_sheet_state()
                
                # Insert in tksheet
                self.table.insert_row(target_row)
                
                # Insert in openpyxl worksheet
                self.ws.insert_rows(target_row + 1)  # openpyxl is 1-indexed
                
                # Save for undo
                self.add_to_undo_stack('row_insert', {
                    'operation': 'row_insert',
                    'insert_position': target_row + 1,
                    'state_before': state_before,
                    'description': f'Insert row before row {target_row + 1}'
                })
                
                self.update_display()
                # Update cell selection tracking after row insertion
                if target_row is not None:
                    # Adjust current selection if it was after the inserted row
                    if hasattr(self, 'current_row') and self.current_row is not None and self.current_row >= target_row:
                        self.current_row += 1
                    # Force update the cell info display
                    self.master.after(100, self.update_cell_display_after_operation)
                # Status update instead of popup
                self.status_main.config(text=f"Inserted row before row {target_row + 1}")
            else:
                self.status_main.config(text="No row selected - click on any cell first")
        else:
            # Fallback to dialog-based insertion
            self.insert_row()
    
    def insert_row_after_selected(self):
        """Insert a row after the currently selected row"""
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            # Get target row from current selection
            target_row = None
            selected_rows = self.table.get_selected_rows() if hasattr(self.table, 'get_selected_rows') else []
            
            if selected_rows:
                # Full row selected
                target_row = max(selected_rows)
            elif hasattr(self, 'current_row') and self.current_row is not None:
                # Use current cell's row
                target_row = self.current_row
            
            if target_row is not None:
                insert_row = target_row + 1
                # Capture state for undo
                state_before = self.capture_sheet_state()
                
                # Check if we're trying to insert after the last row
                current_max_row = len(self.table.get_sheet_data()) if self.table.get_sheet_data() else 0
                
                if insert_row >= current_max_row:
                    # Inserting at or beyond the end - use add_row_at_end instead
                    self.add_row_at_end()
                    return
                
                # Insert in openpyxl worksheet first
                self.ws.insert_rows(insert_row + 1)  # openpyxl is 1-indexed
                
                # Insert in tksheet
                try:
                    self.table.insert_row(insert_row)
                except Exception as e:
                    # If tksheet insert fails, at least the openpyxl insert worked
                    debug_print(f"tksheet insert failed: {e}")
                
                # Save for undo
                self.add_to_undo_stack('row_insert', {
                    'operation': 'row_insert',
                    'insert_position': insert_row + 1,
                    'state_before': state_before,
                    'description': f'Insert row after row {target_row + 1}'
                })
                
                self.update_display()
                # Update cell selection tracking after row insertion
                if target_row is not None:
                    # Adjust current selection - inserted after, so current row moves down if >= insert position
                    if hasattr(self, 'current_row') and self.current_row is not None and self.current_row >= insert_row:
                        self.current_row += 1
                    # Force update the cell info display
                    self.master.after(100, self.update_cell_display_after_operation)
                # Status update instead of popup
                self.status_main.config(text=f"Inserted row after row {target_row + 1}")
            else:
                self.status_main.config(text="No row selected - click on any cell first")
        else:
            # Fallback to dialog-based insertion
            self.insert_row()
    
    def delete_selected_row(self):
        """Delete the currently selected row"""
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            # Get target rows from current selection
            target_rows = []
            selected_rows = self.table.get_selected_rows() if hasattr(self.table, 'get_selected_rows') else []
            
            if selected_rows:
                # Full rows selected
                target_rows = selected_rows
            elif hasattr(self, 'current_row') and self.current_row is not None:
                # Use current cell's row
                target_rows = [self.current_row]
            
            if target_rows:
                # Delete directly (can be undone with Ctrl+Z)
                # Capture state for undo
                state_before = self.capture_sheet_state()
                
                # Delete from highest index to lowest to maintain indices
                for row_idx in sorted(target_rows, reverse=True):
                    self.table.delete_row(row_idx)
                    self.ws.delete_rows(row_idx + 1)  # openpyxl is 1-indexed
                
                # Save for undo
                self.add_to_undo_stack('row_delete', {
                    'operation': 'row_delete',
                    'row_numbers': sorted(target_rows),
                    'row_number': min(target_rows),  # For compatibility
                    'state_before': state_before,
                    'description': f'Delete row(s) {sorted(target_rows)}'
                })
                
                self.update_display()
                # Update cell selection tracking after row deletion
                if target_rows:
                    # Adjust current selection if it was after the deleted rows
                    if hasattr(self, 'current_row') and self.current_row is not None:
                        deleted_before = sum(1 for r in target_rows if r <= self.current_row)
                        if self.current_row in target_rows:
                            # Current row was deleted, reset selection
                            self.current_row = None
                            self.current_col = None
                        elif deleted_before > 0:
                            # Adjust row index down by number of deleted rows before current
                            self.current_row -= deleted_before
                    # Force update the cell info display
                    self.master.after(100, self.update_cell_display_after_operation)
                # Status update instead of popup
                self.status_main.config(text=f"Deleted {len(target_rows)} row(s)")
            else:
                self.status_main.config(text="No row selected - click on any cell first")
        else:
            # Fallback to dialog-based deletion
            self.delete_row()
    
    def insert_col_before_selected(self):
        """Insert a column before the currently selected column"""
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            # Get target column from current selection
            target_col = None
            selected_cols = self.table.get_selected_columns() if hasattr(self.table, 'get_selected_columns') else []
            
            if selected_cols:
                # Full column selected
                target_col = min(selected_cols)
            elif hasattr(self, 'current_col') and self.current_col is not None:
                # Use current cell's column
                target_col = self.current_col
            
            if target_col is not None:
                # Capture state for undo
                state_before = self.capture_sheet_state()
                
                # Insert in tksheet
                self.table.insert_column(target_col)
                
                # Insert in openpyxl worksheet
                self.ws.insert_cols(target_col + 1)  # openpyxl is 1-indexed
                
                # Save for undo
                self.add_to_undo_stack('column_insert', {
                    'operation': 'column_insert',
                    'insert_position': target_col + 1,
                    'column_index': target_col + 1,
                    'state_before': state_before,
                    'description': f'Insert column before column {self.get_col_letter(target_col + 1)}'
                })
                
                self.update_display()
                # Update cell selection tracking after column insertion
                if target_col is not None:
                    # Adjust current selection if it was after the inserted column
                    if hasattr(self, 'current_col') and self.current_col is not None and self.current_col >= target_col:
                        self.current_col += 1
                    # Force update the cell info display
                    self.master.after(100, self.update_cell_display_after_operation)
                # Status update instead of popup
                col_letter = self.get_col_letter(target_col)
                self.status_main.config(text=f"Inserted column before column {col_letter}")
            else:
                self.status_main.config(text="No column selected - click on any cell first")
        else:
            # Fallback to dialog-based insertion
            self.insert_column()
    
    def insert_col_after_selected(self):
        """Insert a column after the currently selected column"""
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            # Get target column from current selection
            target_col = None
            selected_cols = self.table.get_selected_columns() if hasattr(self.table, 'get_selected_columns') else []
            
            if selected_cols:
                # Full column selected
                target_col = max(selected_cols)
            elif hasattr(self, 'current_col') and self.current_col is not None:
                # Use current cell's column
                target_col = self.current_col
            
            if target_col is not None:
                insert_col = target_col + 1
                # Capture state for undo
                state_before = self.capture_sheet_state()
                
                # Check if we're trying to insert after the last column
                current_max_col = len(self.table.headers()) if self.table.headers() else 0
                
                if insert_col >= current_max_col:
                    # Inserting at or beyond the end - use add_col_at_end instead
                    self.add_col_at_end()
                    return
                
                # IMPORTANT: Coordinate the insertion properly
                # tksheet uses 0-based indexing, openpyxl uses 1-based indexing
                # For inserting AFTER target_col:
                # - tksheet position: target_col + 1 (0-based)
                # - openpyxl position: target_col + 2 (1-based)
                
                tksheet_insert_pos = target_col + 1  # 0-based position in tksheet
                openpyxl_insert_pos = target_col + 2  # 1-based position in openpyxl
                
                # Insert in openpyxl worksheet first
                self.ws.insert_cols(openpyxl_insert_pos)
                
                # Insert in tksheet at corresponding position
                try:
                    self.table.insert_column(tksheet_insert_pos)
                except Exception as e:
                    # If tksheet insert fails, at least the openpyxl insert worked
                    debug_print(f"tksheet insert failed: {e}")
                    # Try to rollback openpyxl insertion
                    try:
                        self.ws.delete_cols(openpyxl_insert_pos)
                    except:
                        pass
                    messagebox.showerror("Error", f"Failed to insert column: {e}")
                    return
                
                # Save for undo with correct position
                self.add_to_undo_stack('column_insert', {
                    'operation': 'column_insert',
                    'insert_position': openpyxl_insert_pos,
                    'column_index': openpyxl_insert_pos,
                    'state_before': state_before,
                    'description': f'Insert column after column {self.get_col_letter(target_col + 1)}'
                })
                
                self.update_display()
                # Update cell selection tracking after column insertion
                if target_col is not None:
                    # Adjust current selection - inserted after, so current col moves right if >= insert position
                    if hasattr(self, 'current_col') and self.current_col is not None and self.current_col >= insert_col:
                        self.current_col += 1
                    # Force update the cell info display
                    self.master.after(100, self.update_cell_display_after_operation)
                # Status update instead of popup
                col_letter = self.get_col_letter(target_col)
                self.status_main.config(text=f"Inserted column after column {col_letter}")
            else:
                self.status_main.config(text="No column selected - click on any cell first")
        else:
            # Fallback to dialog-based insertion
            self.insert_column()
    
    def delete_selected_col(self):
        """Delete the currently selected column"""
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            # Get target columns from current selection
            target_cols = []
            selected_cols = self.table.get_selected_columns() if hasattr(self.table, 'get_selected_columns') else []
            
            if selected_cols:
                # Full columns selected
                target_cols = selected_cols
            elif hasattr(self, 'current_col') and self.current_col is not None:
                # Use current cell's column
                target_cols = [self.current_col]
            
            if target_cols:
                col_letters = [self.get_col_letter(c) for c in sorted(target_cols)]
                # Delete directly (can be undone with Ctrl+Z)
                # Capture state for undo
                state_before = self.capture_sheet_state()
                
                # Delete from highest index to lowest to maintain indices
                for col_idx in sorted(target_cols, reverse=True):
                    self.table.delete_column(col_idx)
                    self.ws.delete_cols(col_idx + 1)  # openpyxl is 1-indexed
                
                # Save for undo
                self.add_to_undo_stack('column_delete', {
                    'operation': 'column_delete',
                    'column_indices': sorted(target_cols),
                    'column_index': min(target_cols),  # For compatibility
                    'state_before': state_before,
                    'description': f'Delete column(s) {[self.get_col_letter(c+1) for c in sorted(target_cols)]}'
                })
                
                self.update_display()
                # Update cell selection tracking after column deletion
                if target_cols:
                    # Adjust current selection if it was after the deleted columns
                    if hasattr(self, 'current_col') and self.current_col is not None:
                        deleted_before = sum(1 for c in target_cols if c <= self.current_col)
                        if self.current_col in target_cols:
                            # Current column was deleted, reset selection
                            self.current_row = None
                            self.current_col = None
                        elif deleted_before > 0:
                            # Adjust column index left by number of deleted columns before current
                            self.current_col -= deleted_before
                        # Force update the cell info display
                        self.master.after(100, self.update_cell_display_after_operation)
                    # Status update instead of popup
                    self.status_main.config(text=f"Deleted {len(target_cols)} column(s)")
            else:
                self.status_main.config(text="No column selected - click on any cell first")
        else:
            # Fallback to dialog-based deletion
            self.delete_column()
    
    def get_col_letter(self, col_idx):
        """Convert column index to Excel-style letter (A, B, C, ... Z, AA, AB, ...)"""
        result = ""
        while col_idx >= 0:
            result = chr(65 + (col_idx % 26)) + result
            col_idx = col_idx // 26 - 1
        return result
    
    def update_context_operations(self):
        """Update context operations display based on current selection"""
        if not TKSHEET_AVAILABLE or not hasattr(self, 'table') or not self.table:
            self.selection_info.config(text="Direct cell editing not available (tksheet required)")
            return
        
        try:
            # Get current selection
            selected = self.table.get_currently_selected()
            selected_rows = self.table.get_selected_rows() if hasattr(self.table, 'get_selected_rows') else []
            selected_cols = self.table.get_selected_columns() if hasattr(self.table, 'get_selected_columns') else []
            
            # Determine what's selected
            if selected_rows and not selected_cols:
                # Full row(s) selected
                if len(selected_rows) == 1:
                    self.selection_info.config(text=f"Row {selected_rows[0] + 1} selected - use row operations")
                else:
                    self.selection_info.config(text=f"{len(selected_rows)} rows selected - use row operations")
                self.current_selection = 'row'
                self.current_row = selected_rows[0] if selected_rows else None
                self.current_col = None
                
            elif selected_cols and not selected_rows:
                # Full column(s) selected
                if len(selected_cols) == 1:
                    col_letter = self.get_col_letter(selected_cols[0])
                    self.selection_info.config(text=f"Column {col_letter} selected - use column operations")
                else:
                    self.selection_info.config(text=f"{len(selected_cols)} columns selected - use column operations")
                self.current_selection = 'column'
                self.current_col = selected_cols[0] if selected_cols else None
                self.current_row = None
                
            elif selected and hasattr(selected, 'row') and hasattr(selected, 'column'):
                # Individual cell selected - auto-detect row/column
                if selected.row is not None and selected.column is not None:
                    row_num = selected.row + 1
                    col_letter = self.get_col_letter(selected.column)
                    self.selection_info.config(text="")
                    self.current_selection = 'cell'
                    self.current_row = selected.row
                    self.current_col = selected.column
                else:
                    self.selection_info.config(text="")
                    self.current_selection = None
                    self.current_row = None
                    self.current_col = None
            else:
                # No clear selection
                self.selection_info.config(text="")
                self.current_selection = None
                self.current_row = None
                self.current_col = None
                
        except Exception as e:
            # Error in selection detection
            self.selection_info.config(text="")
            self.current_selection = None
            self.current_row = None
            self.current_col = None
    
    def add_row_at_end(self):
        """Add a new row at the end of the sheet"""
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            # Capture state for undo
            state_before = self.capture_sheet_state()
            
            # Get current sheet dimensions
            current_max_row = self.ws.max_row or 1
            current_max_col = self.ws.max_column or 1
            
            # Add row at the end by assigning empty cells to the new row
            new_row_pos = current_max_row + 1
            for col in range(1, current_max_col + 1):
                self.ws.cell(new_row_pos, col, "")
            
            # Add to tksheet at the end
            try:
                current_data = self.table.get_sheet_data()
                new_row = [""] * current_max_col
                current_data.append(new_row)
                self.table.set_sheet_data(current_data)
            except:
                # Fallback: just refresh the display
                pass
            
            # Save for undo
            self.add_to_undo_stack('row_insert', {
                'insert_position': new_row_pos,
                'state_before': state_before
            })
            
            self.update_display()
            self.status_main.config(text=f"Added row at end (row {new_row_pos})")
        else:
            # Fallback
            self.insert_row()
    
    def add_col_at_end(self):
        """Add a new column at the end of the sheet"""
        if TKSHEET_AVAILABLE and hasattr(self, 'table'):
            # Capture state for undo
            state_before = self.capture_sheet_state()
            
            # Get current sheet dimensions
            current_max_row = self.ws.max_row or 1
            current_max_col = self.ws.max_column or 1
            
            # Add column at the end by assigning empty cells to the new column
            new_col_pos = current_max_col + 1
            for row in range(1, current_max_row + 1):
                self.ws.cell(row, new_col_pos, "")
            
            # Add to tksheet at the end
            try:
                current_data = self.table.get_sheet_data()
                # Add empty cell to each row
                for row in current_data:
                    row.append("")
                self.table.set_sheet_data(current_data)
            except:
                # Fallback: just refresh the display
                pass
            
            # Save for undo
            self.add_to_undo_stack('column_insert', {
                'insert_position': new_col_pos,
                'state_before': state_before
            })
            
            self.update_display()
            col_letter = get_column_letter(new_col_pos)
            self.status_main.config(text=f"Added column at end (column {col_letter})")
        else:
            # Fallback
            self.insert_column()
    
    def update_cell_display_after_operation(self):
        """Update cell display and context operations after row/column operations"""
        try:
            # Update the cell info display based on current tracking
            if (hasattr(self, 'current_row') and self.current_row is not None and 
                hasattr(self, 'current_col') and self.current_col is not None):
                col_letter = get_column_letter(self.current_col + 1)
                cell_addr = f"{col_letter}{self.current_row + 1}"
                self.cell_info.config(text=cell_addr)
                
                # Try to reselect the cell in tksheet if available
                if TKSHEET_AVAILABLE and hasattr(self, 'table'):
                    try:
                        # Make sure the cell is within bounds
                        max_row = self.ws.max_row or 1
                        max_col = self.ws.max_column or 1
                        if (self.current_row < max_row and self.current_col < max_col):
                            self.table.select_cell(self.current_row, self.current_col)
                    except:
                        pass
            else:
                self.cell_info.config(text="None")
            
            # Update context operations
            self.update_context_operations()
        except Exception as e:
            # Fallback - just update context operations
            self.update_context_operations()
    
    def hide_all_context_frames(self):
        """Hide all context operation frames"""
        if hasattr(self, 'row_ops_frame'):
            self.row_ops_frame.pack_forget()
        if hasattr(self, 'col_ops_frame'):
            self.col_ops_frame.pack_forget()
    
    # Help Menu Functions
    def show_keyboard_shortcuts(self):
        """Show a dialog with keyboard shortcuts"""
        shortcuts_text = """
KEYBOARD SHORTCUTS

File Operations:
  Ctrl+N          New file
  Ctrl+O          Open file
  Ctrl+S          Save file
  Ctrl+Shift+S    Save As

Edit Operations:
  Ctrl+Z          Undo
  Ctrl+Y          Redo
  Ctrl+C          Copy
  Ctrl+X          Cut
  Ctrl+V          Paste
  Ctrl+A          Select All
  Delete          Clear cell
  F2              Edit cell in dialog

Navigation:
  Ctrl+F          Find value
  Ctrl+H          Find and Replace
  Ctrl+G          Go to cell
  Arrow Keys      Navigate cells

View:
  Ctrl++          Zoom In
  Ctrl+-          Zoom Out
  Ctrl+0          Reset Zoom

Other:
  Double-click    Edit cell directly
  Right-click     Context menu (on sheet tabs)
"""
        
        # Create a dialog window
        dialog = tk.Toplevel(self.master)
        dialog.title("Keyboard Shortcuts")
        dialog.geometry("400x600")
        dialog.transient(self.master)
        dialog.grab_set()
        
        # Add a text widget with scrollbar
        frame = ttk.Frame(dialog, padding=10)
        frame.pack(fill="both", expand=True)
        
        text_widget = tk.Text(frame, wrap="word", font=("Courier", 10), 
                             bg="#f5f5f5", relief="flat", padx=10, pady=10)
        scrollbar = ttk.Scrollbar(frame, command=text_widget.yview)
        text_widget.configure(yscrollcommand=scrollbar.set)
        
        scrollbar.pack(side="right", fill="y")
        text_widget.pack(side="left", fill="both", expand=True)
        
        text_widget.insert("1.0", shortcuts_text)
        text_widget.configure(state="disabled")
        
        # Close button
        btn_frame = ttk.Frame(dialog, padding=10)
        btn_frame.pack(side="bottom", fill="x")
        ttk.Button(btn_frame, text="Close", command=dialog.destroy).pack()
        
        # Center the dialog
        dialog.update_idletasks()
        x = self.master.winfo_x() + (self.master.winfo_width() - dialog.winfo_width()) // 2
        y = self.master.winfo_y() + (self.master.winfo_height() - dialog.winfo_height()) // 2
        dialog.geometry(f"+{x}+{y}")
    
    def show_about(self):
        """Show about dialog"""
        about_text = """Excel Editor GUI
        
A feature-rich Excel file editor with:
• Full Excel file support (.xlsx)
• Undo/Redo functionality
• Cut/Copy/Paste operations
• Find and Replace
• Row/Column operations
• Sheet management
• Auto-save
• Keyboard shortcuts
• And much more!

Built with Python, tkinter, openpyxl, and tksheet.
"""
        messagebox.showinfo("About Excel Editor", about_text)


def main():
    global DEBUG
    
    try:
        # Parse command-line arguments
        parser = argparse.ArgumentParser(description='Excel Editor with tksheet')
        parser.add_argument('file', nargs='?', default=None, help='Excel file to open')
        parser.add_argument('-d', '--debug', action='store_true', help='Enable debug messages')
        args = parser.parse_args()
        
        # Set global debug flag
        DEBUG = args.debug
        
        if DEBUG:
            debug_print("🐛 Debug mode enabled")
        
        root = tk.Tk()
        root.configure(bg='#f0f0f0')  # Set a simple background
        
        # Reduce visual complexity to avoid X11 rendering issues
        root.option_add('*Font', 'Arial 9')  # Use a simple, standard font
        
        app = ExcelEditorGUI(root, args.file)
        
        # Start with a simpler window state
        root.update_idletasks()
        
        debug_print("✅ Excel Editor started successfully")
        if args.file:
            debug_print(f"📁 Loaded file: {args.file}")
        
        root.mainloop()
        
    except Exception as e:
        debug_print(f" Error starting Excel Editor: {e}")
        debug_print("💡 This might be an X11 rendering issue. Try:")
        debug_print("   - Using a simpler window manager")
        debug_print("   - Reducing system font complexity")
        debug_print("   - Running with: DISPLAY=:0 python3 excel_editor.py")
        import sys
        sys.exit(1)


if __name__ == "__main__":
    main()
