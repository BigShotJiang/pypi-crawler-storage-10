"""LLM KG initialisation."""

from .extract import extract

__all__ = ["extract"]
__VERSION__ = "0.0.2"
