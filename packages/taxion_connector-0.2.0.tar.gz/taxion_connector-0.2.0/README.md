# create a venv (optional but recommended)
python -m venv .venv
source .venv/bin/activate

# install tools
pip install --upgrade pip build twine pytest

# run tests
pytest -q

# clean previous builds (optional)
rm -rf dist build *.egg-info

# build sdist + wheel
python -m build

# verify dist contents
ls -la dist
# example output: your-package-name-0.0.1-py3-none-any.whl, your-package-name-0.0.1.tar.gz
