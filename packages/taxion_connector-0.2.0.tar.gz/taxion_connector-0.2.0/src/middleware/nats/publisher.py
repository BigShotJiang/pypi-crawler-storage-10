#!/usr/bin/env python3
"""
NATS Publisher class for WebSocket -> NATS bridge.

This file wraps the procedural helpers into a single `NatsPublisher` class
that manages a pooled NATS connection, publishes raw bytes or envelope
messages, and provides utilities for saving files and detecting file types.

Usage example:
    publisher = NatsPublisher()
    await publisher.start()
    await publisher.publish(b"hello world", headers={"frame_type": "binary"})
    await publisher.close()
"""
from io import BytesIO
import math
import os
import json
import base64
import logging
import socket
import asyncio
from typing import Optional, Dict, Any, Union
from datetime import datetime
import imghdr

from nats.aio.client import Client as NATS
from nats.aio.errors import ErrConnectionClosed, ErrTimeout, ErrNoServers
from nats.errors import FlushTimeoutError

# Optional PDF extraction
try:
    from PyPDF2 import PdfReader
    _HAS_PYPDF2 = True
except Exception:
    PdfReader = None  # type: ignore
    _HAS_PYPDF2 = False

# dotenv is optional
try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
NATS_HOST = os.getenv("NATS_HOST", "localhost")
NATS_PORT = int(os.getenv("NATS_PORT", "4222"))
NATS_SUBJECT = os.getenv("NATS_SUBJECT", "task_queue")
NATS_SERVER_URL = os.getenv("NATS_SERVER_URL", f"nats://{NATS_HOST}:{NATS_PORT}")
NATS_MAX_RECONNECT_ATTEMPTS = int(os.getenv("NATS_MAX_RECONNECT_ATTEMPTS", "10"))
NATS_RECONNECT_WAIT = float(os.getenv("NATS_RECONNECT_WAIT", "2.0"))
UPLOAD_DIR = os.getenv("UPLOAD_DIR", "upload")
os.makedirs(UPLOAD_DIR, exist_ok=True)

logging.basicConfig(level=getattr(logging, LOG_LEVEL.upper(), logging.INFO))
log = logging.getLogger("nats-publisher")


class NatsPublisher:
    def __init__(self, server_url: Optional[str] = None, subject: Optional[str] = None):
        self.server_url = server_url or NATS_SERVER_URL
        self.subject = subject or NATS_SUBJECT
        self._nc: Optional[NATS] = None
        self._connected = asyncio.Event()

    async def init(self, timeout: float = 5.0):
        if self._nc and not getattr(self._nc, "is_closed", True):
            log.debug("NATS already initialized")
            self._connected.set()
            return

        self._nc = NATS()
        try:
            await self._nc.connect(
                servers=[self.server_url],
                max_reconnect_attempts=NATS_MAX_RECONNECT_ATTEMPTS,
                reconnect_time_wait=NATS_RECONNECT_WAIT,
                verbose=True,
            )
            self._connected.set()
            log.info("Connected to NATS at %s", self.server_url)
        except Exception as e:
            log.exception("Failed to connect to NATS: %s", e)
            raise

    async def close(self):
        if not self._nc:
            return
        try:
            # drain ensures pending publishes are delivered
            await self._nc.drain()
            await self._nc.close()
            log.info("NATS connection closed")
        except Exception as e:
            log.exception("Error while closing NATS connection: %s", e)
        finally:
            self._nc = None
            self._connected.clear()

    @staticmethod
    def _strip_b_prefix(doc_string: str) -> str:
        # Accept either b'...' or b"..." style string encodings and remove outer quotes
        if doc_string.startswith("b'") and doc_string.endswith("'"):
            return doc_string[2:-1]
        if doc_string.startswith('b"') and doc_string.endswith('"'):
            return doc_string[2:-1]
        return doc_string

    def parse_document_string(self, doc_string: Union[str, bytes]) -> Optional[Dict[str, Any]]:
        """
        Parse the document string format which might be a Python bytes repr:
        e.g. b'{"headers": {...}, "body_b64": "..."}' or a plain JSON string/bytes.

        Returns a dict on success, or None on failure.
        """
        try:
            if isinstance(doc_string, bytes):
                doc_string = doc_string.decode("utf-8", errors="ignore")

            doc_string = doc_string.strip()
            doc_string = self._strip_b_prefix(doc_string)

            # Some inputs may contain escaped unicode sequences; try to normalize
            try:
                normalized = doc_string.encode("utf-8").decode("unicode_escape")
            except Exception:
                normalized = doc_string

            return json.loads(normalized)
        except json.JSONDecodeError as e:
            log.debug("JSON decode error while parsing document string: %s", e)
            return None
        except Exception as e:
            log.exception("Unexpected error parsing document string: %s", e)
            return None

    def extract_text_from_base64(self, base64_string: str) -> Optional[str]:
        """
        Extract text from base64-encoded PDF. Returns extracted text or None
        if extraction is not possible (e.g., PyPDF2 not installed).
        """
        if not _HAS_PYPDF2:
            log.warning("PyPDF2 not available; cannot extract PDF text.")
            return None
        try:
            pdf_bytes = base64.b64decode(base64_string)
            pdf_file = BytesIO(pdf_bytes)
            text_parts = []
            pdf_reader = PdfReader(pdf_file)
            for page in pdf_reader.pages:
                page_text = page.extract_text()
                if page_text:
                    text_parts.append(page_text)
            return "\n".join(text_parts)
        except Exception as e:
            log.exception("Failed to extract text from PDF: %s", e)
            return None


    async def publish_event(self, subject: str, message: Union[Dict[str, Any], str, bytes],
                            flush_timeout: float = 5.0,
                            max_flush_retries: int = 3,
                            reconnect_on_failure: bool = True):
        """
        Publish an event to NATS robustly.

        - message: dict (published as JSON) or str/bytes (will be parsed if possible).
        - flush_timeout: seconds to wait for flush each attempt.
        - max_flush_retries: how many times to retry flush before giving up.
        - reconnect_on_failure: attempt a reconnect if flush consistently times out.
        """
        if not self._nc or getattr(self._nc, "is_closed", True):
            await self.init()

        parsed: Optional[Dict[str, Any]] = None
        try:
            if isinstance(message, dict):
                parsed = message
            else:
                parsed = self.parse_document_string(message)

            if parsed is None:
                payload_bytes = (
                    message if isinstance(message, (bytes, bytearray))
                    else str(message).encode("utf-8")
                )
                await self._nc.publish(subject, payload_bytes)
                # Try flush with retries (below)
            else:
                # If parsed contains body_b64, optionally save/extract
                body_b64 = parsed.get("body_b64")
                if body_b64:
                    try:
                        body_bytes = base64.b64decode(body_b64)
                    except Exception:
                        body_bytes = body_b64.encode("utf-8")
                    # Save file (non-blocking)
                    try:
                        await self.save_file(body_bytes, filename=parsed.get("filename"))
                    except Exception:
                        log.exception("Failed to save incoming file")

                payload_bytes = json.dumps(parsed).encode("utf-8")
                await self._nc.publish(subject, payload_bytes)

            # Try flushing with retries and exponential backoff
            attempt = 0
            while True:
                try:
                    # The client flush() may already enforce timeouts internally, but
                    # wrapping with asyncio.wait_for ensures we control the timeout.
                    await asyncio.wait_for(self._nc.flush(), timeout=flush_timeout)
                    # success -> break out
                    log.debug("Flush successful on attempt %d", attempt + 1)
                    break
                except (asyncio.TimeoutError, FlushTimeoutError) as e:
                    attempt += 1
                    log.warning("Flush timeout attempt %d/%d for subject %s: %s",
                                attempt, max_flush_retries, subject, e)
                    if attempt >= max_flush_retries:
                        log.error("Exceeded max flush retries (%d) for subject %s", max_flush_retries, subject)
                        # optional reconnect attempt
                        if reconnect_on_failure:
                            try:
                                log.info("Attempting to reconnect to NATS after flush failure...")
                                await self.close()
                                # tiny backoff before reconnect
                                await asyncio.sleep(0.5)
                                await self.init()
                                # One last attempt to republish/flush
                                await self._nc.publish(subject, payload_bytes)
                                await asyncio.wait_for(self._nc.flush(), timeout=flush_timeout)
                                log.info("Re-publish+flush succeeded after reconnect")
                                break
                            except Exception as re:
                                log.exception("Reconnect-and-republish failed: %s", re)
                        # fallback: log and continue without flush
                        log.warning("Continuing without flush; message may not be delivered immediately.")
                        break
                    # backoff before next retry
                    backoff = min(2 ** attempt, 10)  # cap backoff to 10s
                    jitter = backoff * 0.1 * (0.5 - (math.sin(attempt) * 0.5))  # small deterministic jitter
                    await asyncio.sleep(backoff + jitter)
                except (ErrConnectionClosed, ErrTimeout, ErrNoServers) as e:
                    log.exception("NATS error while publishing to %s: %s", subject, e)
                    raise
                except Exception as e:
                    log.exception("Unexpected error while publishing to %s: %s", subject, e)
                    raise

            log.info("Published envelope to %s (len=%d)", subject, len(payload_bytes))
        except Exception:
            log.exception("Failed to publish message to %s", subject)
            raise
        
    async def publish(self, body: bytes, headers: Optional[Dict[str, Any]] = None):
        """
        Convenience helper to publish raw bytes by wrapping them into an envelope
        with base64-encoded body_b64 and optional headers.
        """
        envelope = {
            "headers": headers or {},
            "body_b64": base64.b64encode(body).decode("ascii"),
            "received_at": datetime.utcnow().isoformat() + "Z",
        }
        await self.publish_event(self.subject, envelope)
        log.info("Published bytes len=%d headers=%s", len(body), headers)

    @staticmethod
    def detect_file_extension(data: bytes) -> str:
        img_type = imghdr.what(None, h=data)
        if img_type:
            return f".{img_type}"

        if data.startswith(b"%PDF"):
            return ".pdf"
        if data.startswith(b"PK\x03\x04"):
            # common for DOCX, PPTX, XLSX as they are zipped XML packages
            return ".zip"
        if data.startswith(b"\x1f\x8b"):
            return ".gz"
        if data.startswith(b"{") or data.startswith(b"["):
            return ".json"
        if data.startswith(b"<?xml"):
            return ".xml"
        return ".bin"

    async def save_file(self, data: bytes, filename: Optional[str] = None) -> str:
        """
        Save binary data to the UPLOAD_DIR with a timestamped prefix.
        Returns the path to the saved file.
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        if filename:
            # sanitize filename
            safe_filename = "".join(c for c in filename if c.isalnum() or c in "._- ")
            path = os.path.join(UPLOAD_DIR, f"{timestamp}_{safe_filename}")
        else:
            ext = self.detect_file_extension(data)
            path = os.path.join(UPLOAD_DIR, f"{timestamp}{ext}")

        loop = asyncio.get_running_loop()

        def _write():
            with open(path, "wb") as fh:
                fh.write(data)

        await loop.run_in_executor(None, _write)
        log.info("Saved file %s (%d bytes)", path, len(data))
        return path

    @staticmethod
    async def is_nats_available(server_url: str, timeout: float = 2.0) -> bool:
        """
        Check if NATS is reachable at the given server_url (e.g. nats://host:port).
        """
        try:
            if not server_url.startswith("nats://"):
                raise ValueError("Invalid NATS URL format")

            parts = server_url.replace("nats://", "").split(":")
            host = parts[0]
            port = int(parts[1]) if len(parts) > 1 else 4222

            loop = asyncio.get_running_loop()

            def _check():
                try:
                    with socket.create_connection((host, port), timeout=timeout):
                        return True
                except Exception:
                    return False

            return await loop.run_in_executor(None, _check)
        except Exception as e:
            log.error("Error checking NATS availability for %s: %s", server_url, e)
            return False

    async def start(self):
        """
        Ensure NATS server is reachable, then initialize connection.
        """
        available = await self.is_nats_available(self.server_url)
        if not available:
            log.error("NATS server not available at %s", self.server_url)
            raise ConnectionError(f"NATS not reachable at {self.server_url}")
        await self.init()
        log.info("NatsPublisher started and connected.")
