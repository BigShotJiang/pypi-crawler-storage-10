import os
import json
import base64
import logging
import socket
import time
import random
import re
from typing import Optional, Dict, Any, Tuple

import asyncio
import websockets
from dotenv import load_dotenv
from datetime import datetime
from queue import Full, Empty, Queue

# Use Pillow instead of imghdr for image detection
from PIL import Image, ImageFile

# NATS client
from nats.aio.client import Client as NATS
from nats.aio.errors import ErrConnectionClosed, ErrTimeout, ErrNoServers

load_dotenv()

# -------- Configuration (env overrides) ----------
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
NATS_HOST = os.getenv("NATS_HOST", "localhost")
NATS_PORT = int(os.getenv("NATS_PORT", "4222"))
NATS_SUBJECT = os.getenv("NATS_SUBJECT", "task_queue")  # subject to publish to

WS_HOST = os.getenv("WS_HOST", "0.0.0.0")
WS_PORT = int(os.getenv("WS_PORT", "6789"))

# queue capacity for the background publisher. If 0 -> unbounded.
PUBLISHER_QUEUE_MAXSIZE = int(os.getenv("PUBLISHER_QUEUE_MAXSIZE", "0"))

# timeouts and ping settings (seconds)
WS_SEND_ACK_TIMEOUT = float(os.getenv("WS_SEND_ACK_TIMEOUT", "1.0"))   # seconds to wait when sending ACK/NACK
WS_PING_INTERVAL = float(os.getenv("WS_PING_INTERVAL", "30"))         # keepalive ping
WS_PING_TIMEOUT = float(os.getenv("WS_PING_TIMEOUT", "15"))           # ping timeout

# NATS reconnection/backoff settings
NATS_RECONNECT_WAIT = float(os.getenv("NATS_RECONNECT_WAIT", "2.0"))
NATS_CONNECT_TIMEOUT = float(os.getenv("NATS_CONNECT_TIMEOUT", "5.0"))

# Upload dir
UPLOAD_DIR = os.getenv("UPLOAD_DIR", "upload")
os.makedirs(UPLOAD_DIR, exist_ok=True)

# logging
logging.basicConfig(level=getattr(logging, LOG_LEVEL.upper(), logging.INFO))
log = logging.getLogger("ws-to-nats")


NATS_SUBJECT_SUB = os.getenv("NATS_SUBJECT_SUB", NATS_SUBJECT + ".in")  # subject to subscribe to (override via env)

class NatsSubscriber:
    """
    Async subscriber that connects to NATS and subscribes to a subject.
    When messages arrive it expects a JSON envelope: {"headers": {...}, "body_b64": "..."}
    It will decode the body, save it to UPLOAD_DIR (using headers.get("fileName") if present),
    and call an optional message_handler callback: async def handler(headers, body_bytes, saved_path)
    """
    def __init__(self, host: str, port: int, subject: str, message_handler=None, reconnect_wait: float = 2.0):
        self.host = host
        self.port = port
        self.subject = subject
        self.reconnect_wait = reconnect_wait
        self._nc = NATS()
        self._task: Optional[asyncio.Task] = None
        self._stop = False
        self._loop = asyncio.get_event_loop()
        # message_handler can be an async callable or sync callable; signature (headers, body_bytes, saved_path)
        self.message_handler = message_handler

    def start(self):
        if self._task and not self._task.done():
            return
        self._stop = False
        self._task = self._loop.create_task(self._run())
        log.info("NatsSubscriber started for subject=%s", self.subject)

    async def stop(self):
        log.info("Stopping NatsSubscriber...")
        self._stop = True
        # unsubscribe/close by closing client and waiting for task
        if self._task:
            await asyncio.wait_for(self._task, timeout=5.0)
        try:
            if getattr(self._nc, "is_connected", False):
                await self._nc.drain()
                await self._nc.close()
        except Exception:
            pass
        log.info("NatsSubscriber stopped.")

    async def _ensure_connected(self):
        if getattr(self._nc, "is_connected", False):
            return
        servers = [f"nats://{self.host}:{self.port}"]
        while not self._stop:
            try:
                log.info("Subscriber connecting to NATS at %s:%d ...", self.host, self.port)
                await asyncio.wait_for(self._nc.connect(servers=servers, reconnect_time_wait=self.reconnect_wait), timeout=NATS_CONNECT_TIMEOUT)
                log.info("Subscriber connected to NATS (servers=%s)", servers)
                return
            except (ErrNoServers, asyncio.TimeoutError, Exception) as e:
                log.exception("Subscriber NATS connect failed: %s — retrying in %.1fs", e, self.reconnect_wait)
                await asyncio.sleep(self.reconnect_wait)

    async def _run(self):
        """
        Connect & subscribe. The subscription callback decodes the JSON envelope
        and calls the user handler (if any). Reconnects handled by _ensure_connected.
        """
        try:
            await self._ensure_connected()
            while not self._stop:
                try:
                    # subscribe with callback
                    async def _msg_cb(msg):
                        try:
                            payload = msg.data.decode("utf-8")
                            obj = json.loads(payload)
                            headers = obj.get("headers", {}) or {}
                            body_b64 = obj.get("body_b64")
                            body = base64.b64decode(body_b64) if body_b64 else b""
                            saved_path = None
                            try:
                                saved_path = save_incoming_bytes(body, headers.get("fileName"))
                            except Exception:
                                log.exception("Failed to save incoming message to disk")

                            log.info("Subscriber received message (len=%d) headers=%s saved_path=%s", len(body), headers, saved_path)

                            # call handler if provided (support sync or async)
                            if self.message_handler:
                                try:
                                    if asyncio.iscoroutinefunction(self.message_handler):
                                        await self.message_handler(headers, body, saved_path)
                                    else:
                                        # run sync handler in executor to avoid blocking
                                        await asyncio.get_running_loop().run_in_executor(None, self.message_handler, headers, body, saved_path)
                                except Exception:
                                    log.exception("Subscriber message_handler raised exception")
                        except Exception:
                            log.exception("Error processing NATS message")

                    # ensure connected before subscribing
                    await self._ensure_connected()
                    sub = await self._nc.subscribe(self.subject, cb=_msg_cb)
                    log.info("Subscribed to %s (sid=%s)", self.subject, getattr(sub, 'sid', None))

                    # keep the task alive while connected; NATS client will invoke the callback
                    while not self._stop and getattr(self._nc, "is_connected", False):
                        await asyncio.sleep(0.5)

                    # loop will attempt reconnect if _stop is False
                    if not self._stop:
                        log.warning("NATS connection lost; attempting reconnect in %.1fs", self.reconnect_wait)
                        try:
                            await self._nc.close()
                        except Exception:
                            pass
                        await asyncio.sleep(self.reconnect_wait)

                except Exception as e:
                    log.exception("Subscriber loop error: %s", e)
                    await asyncio.sleep(self.reconnect_wait)
        finally:
            try:
                if getattr(self._nc, "is_connected", False):
                    await self._nc.drain()
                    await self._nc.close()
            except Exception:
                pass
            log.info("NatsSubscriber task exiting")


def detect_extension_from_magic(body: bytes) -> Optional[str]:
    """
    Try to detect a common file extension from the initial bytes (magic/header).
    Returns extension including leading dot (e.g. '.png') or None if unknown.
    This is a lightweight heuristic for common types.
    """
    if not body or len(body) < 4:
        return None

    # PNG: 89 50 4E 47 0D 0A 1A 0A
    if body.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"

    # JPEG: FF D8 FF
    if body.startswith(b"\xff\xd8\xff"):
        return ".jpg"

    # GIF: GIF87a or GIF89a
    if body[:6] in (b"GIF87a", b"GIF89a"):
        return ".gif"

    # PDF: %PDF-
    if body.startswith(b"%PDF-"):
        return ".pdf"

    # ZIP / docx / xlsx / pptx (zip container)
    if body.startswith(b"PK\x03\x04"):
        # could be zip or OOXML docx/xlsx/pptx — leave as .zip
        return ".zip"

    # TIFF (II* or MM*)
    if body.startswith(b"II*\x00") or body.startswith(b"MM\x00*"):
        return ".tiff"

    # MP4 / MOV (ftyp)
    if len(body) >= 12 and body[4:8] == b"ftyp":
        # trust mp4
        return ".mp4"

    # WEBP: RIFF....WEBP
    if body.startswith(b"RIFF") and len(body) >= 12 and body[8:12] == b"WEBP":
        return ".webp"

    # Fallback to Pillow to detect image formats from bytes
    try:
        parser = ImageFile.Parser()
        parser.feed(body)
        img = parser.close()
        if img and getattr(img, 'format', None):
            fmt = img.format.lower()
            if fmt == 'jpeg':
                return '.jpg'
            if fmt == 'png':
                return '.png'
            if fmt == 'gif':
                return '.gif'
            if fmt == 'tiff':
                return '.tiff'
            if fmt == 'webp':
                return '.webp'
            if fmt == 'bmp':
                return '.bmp'
            # unknown but recognized image format
            return f'.{fmt}'
    except Exception:
        # ignore and fall through
        pass

    return None

# helper to save incoming bytes (used by subscriber)
def save_incoming_bytes(body: bytes, file_name: Optional[str] = None) -> Optional[str]:
    try:
        os.makedirs(UPLOAD_DIR, exist_ok=True)
        # prefer provided filename; sanitize lightly
        if file_name:
            safe = re.sub(r'[^A-Za-z0-9._-]', '_', os.path.basename(file_name))[:200]
            base, ext = os.path.splitext(safe)
            if not ext:
                ext = detect_extension_from_magic(body) or ".bin"
                safe = f"{base}{ext}"
            out = os.path.join(UPLOAD_DIR, safe)
        else:
            ext = detect_extension_from_magic(body) or ".bin"
            ts = datetime.utcnow().strftime("%Y%m%dT%H%M%S")
            rnd = random.randint(1000, 9999)
            out = os.path.join(UPLOAD_DIR, f"incoming-{ts}-{rnd}{ext}")

        tmp = out + ".tmp"
        with open(tmp, "wb") as f:
            f.write(body)
        os.replace(tmp, out)
        return out
    except Exception as e:
        log.exception("Failed saving incoming bytes: %s", e)
        return None
