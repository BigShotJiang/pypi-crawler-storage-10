#!/usr/bin/env python3
"""
Kafka Publisher and Subscriber Example
Requirements:
    pip install kafka-python python-dotenv
"""

import os
import json
import logging
from datetime import datetime
from dotenv import load_dotenv
from kafka import KafkaConsumer

# ============================================
# Load environment variables (.env optional)
# ============================================
load_dotenv()

# Logging setup
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
logging.basicConfig(level=getattr(logging, LOG_LEVEL))
log = logging.getLogger("kafka-example")

# ============================================
# Configuration via environment variables
# ============================================
KAFKA_BROKER = os.getenv("KAFKA_BROKER", "localhost:9092")
KAFKA_TOPIC = os.getenv("KAFKA_TOPIC", "my-topic")
KAFKA_CONSUMER_GROUP = os.getenv("KAFKA_CONSUMER_GROUP", "my-consumer-group")
KAFKA_AUTO_OFFSET_RESET = os.getenv("KAFKA_AUTO_OFFSET_RESET", "earliest")  # latest or earliest
KAFKA_ENABLE_AUTO_COMMIT = os.getenv("KAFKA_ENABLE_AUTO_COMMIT", "true").lower() == "true"
KAFKA_PUBLISH_INTERVAL = float(os.getenv("KAFKA_PUBLISH_INTERVAL", "2.0"))  # seconds

# ============================================
# SUBSCRIBER (Consumer)
# ============================================

class KafkaSubscriber:
    def __init__(self, broker: str, topic: str, group_id: str = KAFKA_CONSUMER_GROUP):
        self.broker = broker
        self.topic = topic
        try:
            self.consumer = KafkaConsumer(
                topic,
                bootstrap_servers=[broker],
                group_id=group_id,
                value_deserializer=lambda m: json.loads(m.decode("utf-8")),
                auto_offset_reset=KAFKA_AUTO_OFFSET_RESET,
                enable_auto_commit=KAFKA_ENABLE_AUTO_COMMIT,
            )
            log.info(f"✅ Connected to Kafka broker at {broker} | topic={topic} | group_id={group_id}")
        except Exception as e:
            log.exception(f"❌ Failed to connect to Kafka broker at {broker}: {e}")
            raise

    def consume_messages(self, max_messages: int | None = None):
        """Consume messages from Kafka topic"""
        log.info(f"🧭 Listening for messages on topic '{self.topic}' ...")
        try:
            count = 0
            for message in self.consumer:
                log.info(
                    f"📨 Received | topic={message.topic} partition={message.partition} offset={message.offset}\n"
                    f"   key={message.key} | timestamp={datetime.fromtimestamp(message.timestamp / 1000)}\n"
                    f"   value={json.dumps(message.value, indent=2)}"
                )
                count += 1
                if max_messages and count >= max_messages:
                    break
        except KeyboardInterrupt:
            log.info("⏹️ Stopping consumer...")
        finally:
            self.close()

    def close(self):
        """Close the consumer connection"""
        self.consumer.close()
        log.info("Kafka consumer closed.")