#!/usr/bin/env python3
"""
Kafka Publisher and Subscriber Example
Requirements:
    pip install kafka-python python-dotenv
"""

import os
import json
import time
import logging
from datetime import datetime
from dotenv import load_dotenv
from kafka import KafkaProducer
from kafka.errors import KafkaError

# ============================================
# Load environment variables (.env optional)
# ============================================
load_dotenv()

# Logging setup
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
logging.basicConfig(level=getattr(logging, LOG_LEVEL))
log = logging.getLogger("kafka-example")

# ============================================
# Configuration via environment variables
# ============================================
KAFKA_BROKER = os.getenv("KAFKA_BROKER", "localhost:9092")
KAFKA_TOPIC = os.getenv("KAFKA_TOPIC", "my-topic")
KAFKA_CONSUMER_GROUP = os.getenv("KAFKA_CONSUMER_GROUP", "my-consumer-group")
KAFKA_AUTO_OFFSET_RESET = os.getenv("KAFKA_AUTO_OFFSET_RESET", "earliest")  # latest or earliest
KAFKA_ENABLE_AUTO_COMMIT = os.getenv("KAFKA_ENABLE_AUTO_COMMIT", "true").lower() == "true"
KAFKA_PUBLISH_INTERVAL = float(os.getenv("KAFKA_PUBLISH_INTERVAL", "2.0"))  # seconds

# ============================================
# PRODUCER
# ============================================

class KafkaPublisher:
    def __init__(self, broker: str, topic: str):
        self.broker = broker
        self.topic = topic
        try:
            self.producer = KafkaProducer(
                bootstrap_servers=[broker],
                value_serializer=lambda v: json.dumps(v).encode("utf-8"),
                key_serializer=lambda v: str(v).encode("utf-8") if v else None,
                retries=5,
                linger_ms=5,
            )
            log.info(f"✅ Connected to Kafka broker at {broker}")
        except Exception as e:
            log.exception(f"❌ Failed to connect to Kafka broker at {broker}: {e}")
            raise

    def publish_message(self, key=None, value=None):
        """Publish a JSON message to Kafka topic"""
        try:
            future = self.producer.send(self.topic, key=key, value=value)
            record_metadata = future.get(timeout=10)
            log.info(
                f"📤 Message sent | topic={record_metadata.topic} partition={record_metadata.partition} offset={record_metadata.offset}"
            )
        except KafkaError as e:
            log.exception(f"❌ Kafka publish failed: {e}")
        except Exception:
            log.exception("Unexpected error in Kafka publish")

    def publish_loop(self):
        """Publish dummy messages every N seconds"""
        log.info(f"🌀 Starting publisher loop to topic '{self.topic}' every {KAFKA_PUBLISH_INTERVAL}s")
        try:
            i = 0
            while True:
                msg = {
                    "id": i,
                    "timestamp": datetime.utcnow().isoformat(),
                    "event": "heartbeat",
                    "message": f"Kafka test message {i}"
                }
                self.publish_message(key=f"msg-{i}", value=msg)
                time.sleep(KAFKA_PUBLISH_INTERVAL)
                i += 1
        except KeyboardInterrupt:
            log.info("⏹️ Stopping publisher loop...")
        finally:
            self.close()

    def close(self):
        self.producer.flush()
        self.producer.close()
        log.info("Kafka producer closed.")