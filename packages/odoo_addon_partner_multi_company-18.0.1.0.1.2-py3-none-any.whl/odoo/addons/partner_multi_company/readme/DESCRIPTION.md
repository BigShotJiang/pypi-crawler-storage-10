This modules allows to select in which of the companies you want to use
each of the partners.
