"""

Coco Pharmaceuticals Configurations
"""
