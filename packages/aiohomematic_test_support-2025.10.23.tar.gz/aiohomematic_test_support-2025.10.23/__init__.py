__version__ = "2025.10.23"
"""Module to support aiohomematic testing with a local client."""
