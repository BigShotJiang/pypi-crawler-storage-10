from .langlint_py import *

__doc__ = langlint_py.__doc__
if hasattr(langlint_py, "__all__"):
    __all__ = langlint_py.__all__