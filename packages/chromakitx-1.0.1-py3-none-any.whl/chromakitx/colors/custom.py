from chromakitx.constants import ANSI_RGB_ESCAPE
from chromakitx.exceptions import InvalidColorError
from chromakitx.models import (RGB, HSL, HexColor)
from chromakitx.utils import (hex_to_rgb, hsl_to_rgb)
from chromakitx.protocols import ColorFormattable

class CustomColor(ColorFormattable):
    __slots__: tuple[str] = ('_rgb',)

    def __init__(self, color: RGB | HSL | HexColor) -> None:
        if isinstance(color, RGB):
            self._rgb: RGB = color
        elif isinstance(color, HexColor):
            self._rgb = hex_to_rgb(color)
        elif isinstance(color, HSL):
            self._rgb = hsl_to_rgb(color)
        else:
            raise InvalidColorError(color_value=color, message="CustomColor requires RGB, HSL, or HexColor, got " + type(color).__name__)

    def format(self) -> str:
        (r, g, b) = self._rgb
        return ANSI_RGB_ESCAPE % (r, g, b)
