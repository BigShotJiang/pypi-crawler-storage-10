ANSI_ESCAPE: str = "\x1B[%im"
ANSI_RGB_ESCAPE: str = "\x1B[38;2;%i;%i;%im"

MIN_RGB_VALUE: int = 0
MAX_RGB_VALUE: int = 255
MIN_HSL_VALUE: float = 0.0
MAX_HSL_VALUE: float = 1.0
VALID_HEX_LENGTHS: tuple[int, int] = (3, 6)
VALID_HEX_CHARS: str = "0123456789ABCDEF"
