(devguide)=

```{include} ../CONTRIBUTING.md
```