from typing import List, Optional, Callable, Any, Union, Tuple
import re
import threading
import time
import cv2
import numpy as np
from enum import IntEnum


class Box:
    """
    Represents a bounding box with position, size, confidence, and name.

    表示一个具有位置、大小、置信度和名称的边界框。
    """
    x: int
    """
    The x-coordinate of the top-left corner.

    左上角的x坐标。
    """
    y: int
    """
    The y-coordinate of the top-left corner.

    左上角的y坐标。
    """
    width: int
    """
    The width of the box.

    框的宽度。
    """
    height: int
    """
    The height of the box.

    框的高度。
    """
    confidence: float
    """
    The confidence score of the detection.

    检测的置信度分数。
    """
    name: Optional[str]
    """
    The name associated with the box.

    与框关联的名称。
    """

    def __init__(self, x: int, y: int, width: int = 0, height: int = 0, confidence: float = 1.0,
                 name: Optional[str] = None, to_x: int = -1, to_y: int = -1) -> None:
        """
        Initializes a Box object with position and dimensions.

        使用位置和尺寸初始化Box对象。

        Args:
            x (int): The x-coordinate of the top-left corner. 左上角的x坐标。
            y (int): The y-coordinate of the top-left corner. 左上角的y坐标。
            width (int, optional): The width of the box. Defaults to 0. 框的宽度。默认为0。
            height (int, optional): The height of the box. Defaults to 0. 框的高度。默认为0。
            confidence (float, optional): The confidence score. Defaults to 1.0. 置信度分数。默认为1.0。
            name (Optional[str], optional): The name of the box. Defaults to None. 框的名称。默认为None。
            to_x (int, optional): The x-coordinate of the bottom-right corner. Used if width is not provided. 右下角的x坐标。如果未提供宽度则使用。默认为-1。
            to_y (int, optional): The y-coordinate of the bottom-right corner. Used if height is not provided. 右下角的y坐标。如果未提供高度则使用。默认为-1。
        """
        ...

    def __eq__(self, other: Any) -> bool:
        """
        Checks if two Box objects are equal.

        检查两个Box对象是否相等。

        Args:
            other (Any): The other object to compare. 要比较的其他对象。

        Returns:
            bool: True if equal, False otherwise. 如果相等则为True，否则为False。
        """
        ...

    def area(self) -> int:
        """
        Calculates the area of the box (width * height).

        计算框的面积（宽度 * 高度）。

        Returns:
            int: The area of the box. 框的面积。
        """
        ...

    def in_boundary(self, boxes: List['Box']) -> List['Box']:
        """
        Finds boxes that are completely inside this box.

        查找完全在此框内的框。

        Args:
            boxes (List[Box]): List of boxes to check. 要检查的框列表。

        Returns:
            List[Box]: List of boxes inside this boundary. 在此边界内的框列表。
        """
        ...

    def __repr__(self) -> str:
        """
        Returns a string representation for debugging.

        返回调试用的字符串表示。

        Returns:
            str: The representation string. 表示字符串。
        """
        ...

    def __str__(self) -> str:
        """
        Returns a human-readable string representation.

        返回人类可读的字符串表示。

        Returns:
            str: The string representation. 字符串表示。
        """
        ...

    def scale(self, width_ratio: float, height_ratio: Optional[float] = None) -> 'Box':
        """
        Scales the box by given ratios, keeping the center fixed. Clamps negative positions to 0.

        使用给定的比例缩放框，保持中心固定。将负位置钳位到0。

        Args:
            width_ratio (float): Ratio to scale width. 缩放宽度的比例。
            height_ratio (Optional[float], optional): Ratio to scale height. Defaults to width_ratio. 缩放高度的比例。默认为宽度比例。

        Returns:
            Box: A new scaled Box. 新的缩放Box。
        """
        ...

    def closest_distance(self, other: 'Box') -> float:
        """
        Calculates the closest distance between two boxes (0 if overlapping).

        计算两个框之间的最近距离（如果重叠则为0）。

        Args:
            other (Box): The other box. 另一个框。

        Returns:
            float: The closest distance. 最近距离。
        """
        ...

    def center_distance(self, other: 'Box') -> float:
        """
        Calculates the Euclidean distance between centers of two boxes.

        计算两个框中心之间的欧几里得距离。

        Args:
            other (Box): The other box. 另一个框。

        Returns:
            float: The center distance. 中心距离。
        """
        ...

    def relative_with_variance(self, relative_x: float = 0.5, relative_y: float = 0.5) -> Tuple[int, int]:
        """
        Gets a point inside the box with random variance (up to 10%).

        获取框内带有随机方差（最多10%）的点。

        Args:
            relative_x (float, optional): Relative x position (0-1). Defaults to 0.5. 相对x位置（0-1）。默认为0.5。
            relative_y (float, optional): Relative y position (0-1). Defaults to 0.5. 相对y位置（0-1）。默认为0.5。

        Returns:
            Tuple[int, int]: (x, y) coordinates with variance. 带有方差的(x, y)坐标。
        """
        ...

    def copy(self, x_offset: int = 0, y_offset: int = 0, width_offset: int = 0, height_offset: int = 0,
             name: Optional[str] = None) -> 'Box':
        """
        Creates a copy of the box with offsets.

        创建带有偏移的框副本。

        Args:
            x_offset (int, optional): Offset for x. Defaults to 0. x偏移。默认为0。
            y_offset (int, optional): Offset for y. Defaults to 0. y偏移。默认为0。
            width_offset (int, optional): Offset for width. Defaults to 0. 宽度偏移。默认为0。
            height_offset (int, optional): Offset for height. Defaults to 0. 高度偏移。默认为0。
            name (Optional[str], optional): New name. Defaults to original. 新名称。默认为原名称。

        Returns:
            Box: The copied box. 复制的框。
        """
        ...

    def crop_frame(self, frame: np.ndarray) -> np.ndarray:
        """
        Crops the frame to the box region.

        将帧裁剪到框区域。

        Args:
            frame (np.ndarray): The input frame. 输入帧。

        Returns:
            np.ndarray: The cropped frame. 裁剪后的帧。
        """
        ...

    def center(self) -> Tuple[int, int]:
        """
        Gets the center coordinates of the box.

        获取框的中心坐标。

        Returns:
            Tuple[int, int]: (center_x, center_y). （中心x, 中心y）。
        """
        ...

    def find_closest_box(self, direction: str, boxes: List['Box'], condition: Optional[Callable[[Box], bool]] = None) -> \
    Optional['Box']:
        """
        Finds the closest box in the specified direction.

        在指定方向找到最近的框。

        Args:
            direction (str): Direction ('up', 'down', 'left', 'right', 'all'). 方向（'up', 'down', 'left', 'right', 'all'）。
            boxes (List[Box]): List of boxes to search. 要搜索的框列表。
            condition (Optional[Callable[[Box], bool]], optional): Filter condition. Defaults to None. 过滤条件。默认为None。

        Returns:
            Optional[Box]: The closest box or None. 最近的框或None。
        """
        ...


class ExecutorOperation:
    """
    Base class for executor operations, providing common interaction methods.

    执行器操作的基类，提供常见的交互方法。
    """
    last_click_time: float
    _executor: 'TaskExecutor'
    logger: Any  # Assuming Logger

    def __init__(self, executor: 'TaskExecutor') -> None:
        """
        Initializes with a task executor.

        使用任务执行器初始化。

        Args:
            executor (TaskExecutor): The task executor. 任务执行器。
        """
        ...

    @property
    def executor(self) -> 'TaskExecutor':
        """
        Gets the associated executor.

        获取关联的执行器。

        Returns:
            TaskExecutor: The executor. 执行器。
        """
        ...

    @property
    def debug(self) -> bool:
        """
        Gets the debug flag from executor.

        从执行器获取调试标志。

        Returns:
            bool: Debug mode. 调试模式。
        """
        ...

    def exit_is_set(self) -> bool:
        """
        Checks if the exit event is set.

        检查退出事件是否设置。

        Returns:
            bool: True if set. 如果设置则为True。
        """
        ...

    def get_task_by_class(self, cls: type) -> Optional['BaseTask']:
        """
        Gets a task by class type.

        通过类类型获取任务。

        Args:
            cls (type): The class type. 类类型。

        Returns:
            Optional[BaseTask]: The task or None. 任务或None。
        """
        ...

    def box_in_horizontal_center(self, box: Optional[Box], off_percent: float = 0.02) -> bool:
        """
        Checks if the box is horizontally centered within off-percent tolerance.

        检查框是否在off-percent容差内水平居中。

        Args:
            box (Optional[Box]): The box to check. 要检查的框。
            off_percent (float, optional): Tolerance percentage. Defaults to 0.02. 容差百分比。默认为0.02。

        Returns:
            bool: True if centered. 如果居中则为True。
        """
        ...

    def clipboard(self) -> str:
        """
        Gets the clipboard content.

        获取剪贴板内容。

        Returns:
            str: Clipboard text. 剪贴板文本。
        """
        ...

    def is_scene(self, the_scene: type) -> bool:
        """
        Checks if the current scene matches the given type.

        检查当前场景是否匹配给定类型。

        Args:
            the_scene (type): The scene type. 场景类型。

        Returns:
            bool: True if matches. 如果匹配则为True。
        """
        ...

    def reset_scene(self) -> None:
        """
        Resets the current scene.

        重置当前场景。
        """
        ...

    def click(self, x: Union[int, Box, List[Box]] = -1, y: int = -1, move_back: bool = False,
              name: Optional[str] = None, interval: int = -1, move: bool = True, down_time: float = 0.01,
              after_sleep: float = 0, key: str = 'left') -> bool:
        """
        Performs a mouse click at the specified position.

        在指定位置执行鼠标点击。

        Args:
            x (Union[int, Box, List[Box]], optional): X coordinate or box. Defaults to -1. x坐标或框。默认为-1。
            y (int, optional): Y coordinate. Defaults to -1. y坐标。默认为-1。
            move_back (bool, optional): Move mouse back after click. Defaults to False. 点击后移动鼠标回原位。默认为False。
            name (Optional[str], optional): Name for logging. Defaults to None. 日志名称。默认为None。
            interval (int, optional): Minimum interval between clicks. Defaults to -1. 点击间最小间隔。默认为-1。
            move (bool, optional): Move mouse to position. Defaults to True. 移动鼠标到位置。默认为True。
            down_time (float, optional): Time to hold down. Defaults to 0.01. 按下持续时间。默认为0.01。
            after_sleep (float, optional): Sleep after click. Defaults to 0. 点击后休眠。默认为0。
            key (str, optional): Mouse button ('left', 'right', 'middle'). Defaults to 'left'. 鼠标按钮（'left', 'right', 'middle'）。默认为'left'。

        Returns:
            bool: True if successful. 如果成功则为True。
        """
        ...

    def back(self, *args: Any, **kwargs: Any) -> None:
        """
        Performs a back action (e.g., ESC key).

        执行后退操作（例如ESC键）。

        Args:
            *args (Any): Additional arguments. 额外参数。
            **kwargs (Any): Keyword arguments. 关键字参数。
        """
        ...

    def middle_click(self, *args: Any, **kwargs: Any) -> bool:
        """
        Performs a middle mouse click.

        执行中间鼠标点击。

        Args:
            *args (Any): Additional arguments. 额外参数。
            **kwargs (Any): Keyword arguments. 关键字参数。

        Returns:
            bool: True if successful. 如果成功则为True。
        """
        ...

    def right_click(self, *args: Any, **kwargs: Any) -> bool:
        """
        Performs a right mouse click.

        执行右键鼠标点击。

        Args:
            *args (Any): Additional arguments. 额外参数。
            **kwargs (Any): Keyword arguments. 关键字参数。

        Returns:
            bool: True if successful. 如果成功则为True。
        """
        ...

    def check_interval(self, interval: float) -> bool:
        """
        Checks if enough time has passed since last click.

        检查自上次点击以来是否经过足够时间。

        Args:
            interval (float): Minimum interval. 最小间隔。

        Returns:
            bool: True if interval passed. 如果间隔已过则为True。
        """
        ...

    def is_adb(self) -> bool:
        """
        Checks if the device is ADB-based.

        检查设备是否基于ADB。

        Returns:
            bool: True if ADB. 如果是ADB则为True。
        """
        ...

    def mouse_down(self, x: int = -1, y: int = -1, name: Optional[str] = None, key: str = "left") -> None:
        """
        Presses down the mouse button.

        按下鼠标按钮。

        Args:
            x (int, optional): X coordinate. Defaults to -1. x坐标。默认为-1。
            y (int, optional): Y coordinate. Defaults to -1. y坐标。默认为-1。
            name (Optional[str], optional): Name for logging. Defaults to None. 日志名称。默认为None。
            key (str, optional): Mouse button. Defaults to "left". 鼠标按钮。默认为"left"。
        """
        ...

    def mouse_up(self, name: Optional[str] = None, key: str = "left") -> None:
        """
        Releases the mouse button.

        释放鼠标按钮。

        Args:
            name (Optional[str], optional): Name for logging. Defaults to None. 日志名称。默认为None。
            key (str, optional): Mouse button. Defaults to "left". 鼠标按钮。默认为"left"。
        """
        ...

    def swipe_relative(self, from_x: float, from_y: float, to_x: float, to_y: float, duration: float = 0.5,
                       settle_time: float = 0) -> None:
        """
        Performs a relative swipe gesture.

        执行相对滑动手势。

        Args:
            from_x (float): Starting relative x. 起始相对x。
            from_y (float): Starting relative y. 起始相对y。
            to_x (float): Ending relative x. 结束相对x。
            to_y (float): Ending relative y. 结束相对y。
            duration (float, optional): Duration in seconds. Defaults to 0.5. 持续时间（秒）。默认为0.5。
            settle_time (float, optional): Settle time at end. Defaults to 0. 结束时稳定时间。默认为0。
        """
        ...

    def input_text(self, text: str) -> None:
        """
        Inputs text into the active field.

        将文本输入到活动字段。

        Args:
            text (str): The text to input. 要输入的文本。
        """
        ...

    @property
    def hwnd(self) -> int:
        """
        Gets the window handle.

        获取窗口句柄。

        Returns:
            int: The HWND. HWND。
        """
        ...

    def scroll_relative(self, x: float, y: float, count: int) -> None:
        """
        Performs a relative scroll.

        执行相对滚动。

        Args:
            x (float): Relative x position. 相对x位置。
            y (float): Relative y position. 相对y位置。
            count (int): Scroll count (positive up, negative down). 滚动次数（正向上，负向下）。
        """
        ...

    def scroll(self, x: int, y: int, count: int) -> None:
        """
        Performs a scroll at position.

        在位置执行滚动。

        Args:
            x (int): X coordinate. x坐标。
            y (int): Y coordinate. y坐标。
            count (int): Scroll count. 滚动次数。
        """
        ...

    def swipe(self, from_x: int, from_y: int, to_x: int, to_y: int, duration: float = 0.5, after_sleep: float = 0.1,
              settle_time: float = 0) -> None:
        """
        Performs a swipe gesture.

        执行滑动手势。

        Args:
            from_x (int): Starting x. 起始x。
            from_y (int): Starting y. 起始y。
            to_x (int): Ending x. 结束x。
            to_y (int): Ending y. 结束y。
            duration (float, optional): Duration in seconds. Defaults to 0.5. 持续时间（秒）。默认为0.5。
            after_sleep (float, optional): Sleep after swipe. Defaults to 0.1. 滑动后休眠。默认为0.1。
            settle_time (float, optional): Settle time. Defaults to 0. 稳定时间。默认为0。
        """
        ...

    def screenshot(self, name: str, frame: Optional[np.ndarray] = None, show_box: bool = False,
                   frame_box: Optional[Box] = None) -> None:
        """
        Takes and emits a screenshot.

        拍摄并发出截图。

        Args:
            name (str): Screenshot name. 截图名称。
            frame (Optional[np.ndarray], optional): Frame to use. Defaults to None. 要使用的帧。默认为None。
            show_box (bool, optional): Show box overlay. Defaults to False. 显示框叠加。默认为False。
            frame_box (Optional[Box], optional): Box for frame. Defaults to None. 帧的框。默认为None。
        """
        ...

    def click_box_if_name_match(self, boxes: List[Box], names: Union[str, List[str], re.Pattern, List[re.Pattern]],
                                relative_x: float = 0.5, relative_y: float = 0.5) -> Optional[Box]:
        """
        Clicks the first matching box by name.

        点击第一个匹配名称的框。

        Args:
            boxes (List[Box]): List of boxes. 框列表。
            names (Union[str, List[str], re.Pattern, List[re.Pattern]]): Names or patterns to match. 要匹配的名称或模式。
            relative_x (float, optional): Relative click x. Defaults to 0.5. 相对点击x。默认为0.5。
            relative_y (float, optional): Relative click y. Defaults to 0.5. 相对点击y。默认为0.5。

        Returns:
            Optional[Box]: The clicked box or None. 点击的框或None。
        """
        ...

    def box_of_screen(self, x: float, y: float, to_x: float = 1.0, to_y: float = 1.0, width: float = 0.0,
                      height: float = 0.0, name: Optional[str] = None, hcenter: bool = False,
                      confidence: float = 1.0) -> Box:
        """
        Creates a relative box on the screen.

        在屏幕上创建相对框。

        Args:
            x (float): Relative x start. 相对x起始。
            y (float): Relative y start. 相对y起始。
            to_x (float, optional): Relative x end. Defaults to 1.0. 相对x结束。默认为1.0。
            to_y (float, optional): Relative y end. Defaults to 1.0. 相对y结束。默认为1.0。
            width (float, optional): Relative width. Defaults to 0.0. 相对宽度。默认为0.0。
            height (float, optional): Relative height. Defaults to 0.0. 相对高度。默认为0.0。
            name (Optional[str], optional): Box name. Defaults to None. 框名称。默认为None。
            hcenter (bool, optional): Horizontal center adjustment. Defaults to False. 水平中心调整。默认为False。
            confidence (float, optional): Confidence. Defaults to 1.0. 置信度。默认为1.0。

        Returns:
            Box: The relative box. 相对框。
        """
        ...

    def out_of_ratio(self) -> bool:
        """
        Checks if screen ratio is out of expected.

        检查屏幕比例是否超出预期。

        Returns:
            bool: True if out of ratio. 如果超出比例则为True。
        """
        ...

    def ensure_in_front(self) -> None:
        """
        Ensures the window is in front.

        确保窗口在前台。
        """
        ...

    def box_of_screen_scaled(self, original_screen_width: int, original_screen_height: int, x_original: int,
                             y_original: int, to_x: int = 0, to_y: int = 0, width_original: int = 0,
                             height_original: int = 0, name: Optional[str] = None, hcenter: bool = False,
                             confidence: float = 1.0) -> Box:
        """
        Creates a scaled relative box.

        创建缩放的相对框。

        Args:
            original_screen_width (int): Original width. 原始宽度。
            original_screen_height (int): Original height. 原始高度。
            x_original (int): Original x. 原始x。
            y_original (int): Original y. 原始y。
            to_x (int, optional): Original to x. Defaults to 0. 原始到x。默认为0。
            to_y (int, optional): Original to y. Defaults to 0. 原始到y。默认为0。
            width_original (int, optional): Original width. Defaults to 0. 原始宽度。默认为0。
            height_original (int, optional): Original height. Defaults to 0. 原始高度。默认为0。
            name (Optional[str], optional): Name. Defaults to None. 名称。默认为None。
            hcenter (bool, optional): Horizontal center. Defaults to False. 水平中心。默认为False。
            confidence (float, optional): Confidence. Defaults to 1.0. 置信度。默认为1.0。

        Returns:
            Box: The scaled box. 缩放框。
        """
        ...

    def height_of_screen(self, percent: float) -> int:
        """
        Calculates height based on screen percentage.

        根据屏幕百分比计算高度。

        Args:
            percent (float): Percentage (0-1). 百分比（0-1）。

        Returns:
            int: Pixel height. 像素高度。
        """
        ...

    @property
    def screen_width(self) -> int:
        """
        Gets the screen width.

        获取屏幕宽度。

        Returns:
            int: Width in pixels. 像素宽度。
        """
        ...

    @property
    def screen_height(self) -> int:
        """
        Gets the screen height.

        获取屏幕高度。

        Returns:
            int: Height in pixels. 像素高度。
        """
        ...

    def width_of_screen(self, percent: float) -> int:
        """
        Calculates width based on screen percentage.

        根据屏幕百分比计算宽度。

        Args:
            percent (float): Percentage (0-1). 百分比（0-1）。

        Returns:
            int: Pixel width. 像素宽度。
        """
        ...

    def click_relative(self, x: float, y: float, move_back: bool = False, hcenter: bool = False, move: bool = True,
                       after_sleep: float = 0, name: Optional[str] = None, interval: int = -1, down_time: float = 0.02,
                       key: str = "left") -> None:
        """
        Performs a relative click.

        执行相对点击。

        Args:
            x (float): Relative x (0-1). 相对x（0-1）。
            y (float): Relative y (0-1). 相对y（0-1）。
            move_back (bool, optional): Move back. Defaults to False. 移动回原位。默认为False。
            hcenter (bool, optional): Horizontal center. Defaults to False. 水平中心。默认为False。
            move (bool, optional): Move to position. Defaults to True. 移动到位置。默认为True。
            after_sleep (float, optional): Sleep after. Defaults to 0. 点击后休眠。默认为0。
            name (Optional[str], optional): Name. Defaults to None. 名称。默认为None。
            interval (int, optional): Interval. Defaults to -1. 间隔。默认为-1。
            down_time (float, optional): Down time. Defaults to 0.02. 按下时间。默认为0.02。
            key (str, optional): Key. Defaults to "left". 键。默认为"left"。
        """
        ...

    def middle_click_relative(self, x: float, y: float, move_back: bool = False, down_time: float = 0.01) -> None:
        """
        Performs a relative middle click.

        执行相对中间点击。

        Args:
            x (float): Relative x. 相对x。
            y (float): Relative y. 相对y。
            move_back (bool, optional): Move back. Defaults to False. 移动回原位。默认为False。
            down_time (float, optional): Down time. Defaults to 0.01. 按下时间。默认为0.01。
        """
        ...

    @property
    def height(self) -> int:
        """
        Gets the screen height.

        获取屏幕高度。

        Returns:
            int: Height. 高度。
        """
        ...

    @property
    def width(self) -> int:
        """
        Gets the screen width.

        获取屏幕宽度。

        Returns:
            int: Width. 宽度。
        """
        ...

    def move_relative(self, x: float, y: float) -> None:
        """
        Moves mouse relatively.

        相对移动鼠标。

        Args:
            x (float): Relative x. 相对x。
            y (float): Relative y. 相对y。
        """
        ...

    def move(self, x: int, y: int) -> None:
        """
        Moves the mouse to position.

        将鼠标移动到位置。

        Args:
            x (int): X coordinate. x坐标。
            y (int): Y coordinate. y坐标。
        """
        ...

    def click_box(self, box: Union[Box, List[Box]] = None, relative_x: float = 0.5, relative_y: float = 0.5,
                  raise_if_not_found: bool = False, move_back: bool = False, down_time: float = 0.01,
                  after_sleep: float = 1) -> Optional[Box]:
        """
        Clicks inside a box.

        在框内点击。

        Args:
            box (Union[Box, List[Box]], optional): The box. Defaults to None. 框。默认为None。
            relative_x (float, optional): Relative x in box. Defaults to 0.5. 框内相对x。默认为0.5。
            relative_y (float, optional): Relative y in box. Defaults to 0.5. 框内相对y。默认为0.5。
            raise_if_not_found (bool, optional): Raise exception if not found. Defaults to False. 如果未找到则引发异常。默认为False。
            move_back (bool, optional): Move back. Defaults to False. 移动回原位。默认为False。
            down_time (float, optional): Down time. Defaults to 0.01. 按下时间。默认为0.01。
            after_sleep (float, optional): Sleep after. Defaults to 1. 点击后休眠。默认为1。

        Returns:
            Optional[Box]: The clicked box. 点击的框。
        """
        ...

    def wait_scene(self, scene_type: Optional[type] = None, time_out: float = 0,
                   pre_action: Optional[Callable[[], None]] = None, post_action: Optional[Callable[[], None]] = None) -> \
    Optional[Any]:
        """
        Waits for a scene.

        等待场景。

        Args:
            scene_type (Optional[type], optional): Scene type. Defaults to None. 场景类型。默认为None。
            time_out (float, optional): Timeout. Defaults to 0. 超时。默认为0。
            pre_action (Optional[Callable[[], None]], optional): Action before wait. Defaults to None. 等待前操作。默认为None。
            post_action (Optional[Callable[[], None]], optional): Action after wait. Defaults to None. 等待后操作。默认为None。

        Returns:
            Optional[Any]: Scene result. 场景结果。
        """
        ...

    def sleep(self, timeout: float) -> bool:
        """
        Sleeps for the given time.

        休眠给定时间。

        Args:
            timeout (float): Time in seconds. 秒数。

        Returns:
            bool: True. True。
        """
        ...

    def send_key(self, key: str, down_time: float = 0.02, interval: int = -1, after_sleep: float = 0) -> bool:
        """
        Sends a key press.

        发送按键。

        Args:
            key (str): The key. 键。
            down_time (float, optional): Hold time. Defaults to 0.02. 按住时间。默认为0.02。
            interval (int, optional): Interval. Defaults to -1. 间隔。默认为-1。
            after_sleep (float, optional): Sleep after. Defaults to 0. 按键后休眠。默认为0。

        Returns:
            bool: True if successful. 如果成功则为True。
        """
        ...

    def get_global_config(self, option: str) -> Any:
        """
        Gets a global config value.

        获取全局配置值。

        Args:
            option (str): Option name. 选项名称。

        Returns:
            Any: Config value. 配置值。
        """
        ...

    def get_global_config_desc(self, option: str) -> Optional[str]:
        """
        Gets description for global config.

        获取全局配置描述。

        Args:
            option (str): Option name. 选项名称。

        Returns:
            Optional[str]: Description. 描述。
        """
        ...

    def send_key_down(self, key: str) -> None:
        """
        Presses down a key.

        按下键。

        Args:
            key (str): The key. 键。
        """
        ...

    def send_key_up(self, key: str) -> None:
        """
        Releases a key.

        释放键。

        Args:
            key (str): The key. 键。
        """
        ...

    def wait_until(self, condition: Callable[[], Any], time_out: float = 0,
                   pre_action: Optional[Callable[[], None]] = None, post_action: Optional[Callable[[], None]] = None,
                   settle_time: float = -1, raise_if_not_found: bool = False) -> Optional[Any]:
        """
        Waits until condition is true.

        等待直到条件为真。

        Args:
            condition (Callable[[], Any]): Condition function. 条件函数。
            time_out (float, optional): Timeout. Defaults to 0. 超时。默认为0。
            pre_action (Optional[Callable[[], None]], optional): Pre action. Defaults to None. 前置操作。默认为None。
            post_action (Optional[Callable[[], None]], optional): Post action. Defaults to None. 后置操作。默认为None。
            settle_time (float, optional): Settle time. Defaults to -1. 稳定时间。默认为-1。
            raise_if_not_found (bool, optional): Raise if not found. Defaults to False. 如果未找到则引发异常。默认为False。

        Returns:
            Optional[Any]: Condition result. 条件结果。
        """
        ...

    def wait_click_box(self, condition: Callable[[], Optional[Box]], time_out: float = 0,
                       pre_action: Optional[Callable[[], None]] = None,
                       post_action: Optional[Callable[[], None]] = None, raise_if_not_found: bool = False) -> Optional[
        Box]:
        """
        Waits for box and clicks it.

        等待框并点击它。

        Args:
            condition (Callable[[], Optional[Box]]): Condition for box. 框条件。
            time_out (float, optional): Timeout. Defaults to 0. 超时。默认为0。
            pre_action (Optional[Callable[[], None]], optional): Pre action. Defaults to None. 前置操作。默认为None。
            post_action (Optional[Callable[[], None]], optional): Post action. Defaults to None. 后置操作。默认为None。
            raise_if_not_found (bool, optional): Raise if not found. Defaults to False. 如果未找到则引发异常。默认为False。

        Returns:
            Optional[Box]: The box. 框。
        """
        ...

    def next_frame(self) -> np.ndarray:
        """
        Gets the next frame.

        获取下一帧。

        Returns:
            np.ndarray: The frame. 帧。
        """
        ...

    def adb_ui_dump(self) -> Optional[str]:
        """
        Performs ADB UI dump.

        执行ADB UI转储。

        Returns:
            Optional[str]: Dump XML. 转储XML。
        """
        ...

    @property
    def frame(self) -> np.ndarray:
        """
        Gets the current frame.

        获取当前帧。

        Returns:
            np.ndarray: The frame. 帧。
        """
        ...

    @staticmethod
    def draw_boxes(feature_name: Optional[str] = None, boxes: Optional[List[Box]] = None, color: str = "red",
                   debug: bool = True) -> None:
        """
        Draws boxes on the frame.

        在帧上绘制框。

        Args:
            feature_name (Optional[str], optional): Feature name. Defaults to None. 特征名称。默认为None。
            boxes (Optional[List[Box]], optional): Boxes to draw. Defaults to None. 要绘制的框。默认为None。
            color (str, optional): Color. Defaults to "red". 颜色。默认为"red"。
            debug (bool, optional): Debug mode. Defaults to True. 调试模式。默认为True。
        """
        ...

    def clear_box(self) -> None:
        """
        Clears drawn boxes.

        清除绘制的框。
        """
        ...

    def calculate_color_percentage(self, color: dict, box: Union[Box, str]) -> float:
        """
        Calculates color percentage in box.

        计算框中的颜色百分比。

        Args:
            color (dict): Color range. 颜色范围。
            box (Union[Box, str]): Box or name. 框或名称。

        Returns:
            float: Percentage. 百分比。
        """
        ...

    def adb_shell(self, *args: Any, **kwargs: Any) -> Optional[str]:
        """
        Executes ADB shell command.

        执行ADB shell命令。

        Args:
            *args (Any): Command args. 命令参数。
            **kwargs (Any): Keyword args. 关键字参数。

        Returns:
            Optional[str]: Command output. 命令输出。
        """
        ...


class FindFeature(ExecutorOperation):
    """
    Handles feature finding operations.

    处理特征查找操作。
    """

    def __init__(self, executor: 'TaskExecutor') -> None:
        """
        Initializes with executor.

        使用执行器初始化。

        Args:
            executor (TaskExecutor): The executor. 执行器。
        """
        ...

    def find_feature(self, feature_name: Optional[str] = None, horizontal_variance: float = 0,
                     vertical_variance: float = 0, threshold: float = 0, use_gray_scale: bool = False, x: int = -1,
                     y: int = -1, to_x: int = -1, to_y: int = -1, width: int = -1, height: int = -1,
                     box: Optional[Box] = None, canny_lower: int = 0, canny_higher: int = 0,
                     frame_processor: Optional[Callable[[np.ndarray], np.ndarray]] = None,
                     template: Optional[np.ndarray] = None, match_method: int = cv2.TM_CCOEFF_NORMED,
                     screenshot: bool = False, mask_function: Optional[Callable[[np.ndarray], np.ndarray]] = None,
                     frame: Optional[np.ndarray] = None) -> List[Box]:
        """
        Finds features in the frame.

        在帧中查找特征。

        Args:
            feature_name (Optional[str], optional): Feature name. Defaults to None. 特征名称。默认为None。
            horizontal_variance (float, optional): Horizontal variance. Defaults to 0. 水平方差。默认为0。
            vertical_variance (float, optional): Vertical variance. Defaults to 0. 垂直方差。默认为0。
            threshold (float, optional): Confidence threshold. Defaults to 0. 置信度阈值。默认为0。
            use_gray_scale (bool, optional): Use grayscale. Defaults to False. 使用灰度。默认为False。
            x (int, optional): Search x start. Defaults to -1. 搜索x起始。默认为-1。
            y (int, optional): Search y start. Defaults to -1. 搜索y起始。默认为-1。
            to_x (int, optional): Search x end. Defaults to -1. 搜索x结束。默认为-1。
            to_y (int, optional): Search y end. Defaults to -1. 搜索y结束。默认为-1。
            width (int, optional): Search width. Defaults to -1. 搜索宽度。默认为-1。
            height (int, optional): Search height. Defaults to -1. 搜索高度。默认为-1。
            box (Optional[Box], optional): Search box. Defaults to None. 搜索框。默认为None。
            canny_lower (int, optional): Canny lower threshold. Defaults to 0. Canny下阈值。默认为0。
            canny_higher (int, optional): Canny upper threshold. Defaults to 0. Canny上阈值。默认为0。
            frame_processor (Optional[Callable[[np.ndarray], np.ndarray]], optional): Frame processor. Defaults to None. 帧处理器。默认为None。
            template (Optional[np.ndarray], optional): Template image. Defaults to None. 模板图像。默认为None。
            match_method (int, optional): Matching method. Defaults to cv2.TM_CCOEFF_NORMED. 匹配方法。默认为cv2.TM_CCOEFF_NORMED。
            screenshot (bool, optional): Take screenshot. Defaults to False. 截图。默认为False。
            mask_function (Optional[Callable[[np.ndarray], np.ndarray]], optional): Mask function. Defaults to None. 掩码函数。默认为None。
            frame (Optional[np.ndarray], optional): Input frame. Defaults to None. 输入帧。默认为None。

        Returns:
            List[Box]: Found boxes. 找到的框。
        """
        ...

    def get_feature_by_name(self, name: str) -> Optional[Feature]:
        """
        Gets a feature by name.

        通过名称获取特征。

        Args:
            name (str): Feature name. 特征名称。

        Returns:
            Optional[Feature]: The feature or None. 特征或None。
        """
        ...

    def get_box_by_name(self, name: Union[str, Box]) -> Optional[Box]:
        """
        Gets a box by name or predefined.

        通过名称或预定义获取框。

        Args:
            name (Union[str, Box]): Name or box. 名称或框。

        Returns:
            Optional[Box]: The box or None. 框或None。
        """
        ...

    def find_feature_and_set(self, features: Union[str, List[str]], horizontal_variance: float = 0,
                             vertical_variance: float = 0, threshold: float = 0) -> bool:
        """
        Finds features and sets attributes.

        查找特征并设置属性。

        Args:
            features (Union[str, List[str]]): Feature names. 特征名称。
            horizontal_variance (float, optional): Horizontal variance. Defaults to 0. 水平方差。默认为0。
            vertical_variance (float, optional): Vertical variance. Defaults to 0. 垂直方差。默认为0。
            threshold (float, optional): Threshold. Defaults to 0. 阈值。默认为0。

        Returns:
            bool: True if all found. 如果全部找到则为True。
        """
        ...

    def wait_feature(self, feature: str, horizontal_variance: float = 0, vertical_variance: float = 0,
                     threshold: float = 0, time_out: float = 0, pre_action: Optional[Callable[[], None]] = None,
                     post_action: Optional[Callable[[], None]] = None, use_gray_scale: bool = False,
                     box: Optional[Box] = None, raise_if_not_found: bool = False, canny_lower: int = 0,
                     canny_higher: int = 0, settle_time: float = -1,
                     frame_processor: Optional[Callable[[np.ndarray], np.ndarray]] = None) -> Optional[Box]:
        """
        Waits for a feature.

        等待特征。

        Args:
            feature (str): Feature name. 特征名称。
            horizontal_variance (float, optional): Horizontal variance. Defaults to 0. 水平方差。默认为0。
            vertical_variance (float, optional): Vertical variance. Defaults to 0. 垂直方差。默认为0。
            threshold (float, optional): Threshold. Defaults to 0. 阈值。默认为0。
            time_out (float, optional): Timeout. Defaults to 0. 超时。默认为0。
            pre_action (Optional[Callable[[], None]], optional): Pre action. Defaults to None. 前置操作。默认为None。
            post_action (Optional[Callable[[], None]], optional): Post action. Defaults to None. 后置操作。默认为None。
            use_gray_scale (bool, optional): Use grayscale. Defaults to False. 使用灰度。默认为False。
            box (Optional[Box], optional): Search box. Defaults to None. 搜索框。默认为None。
            raise_if_not_found (bool, optional): Raise if not found. Defaults to False. 如果未找到则引发异常。默认为False。
            canny_lower (int, optional): Canny lower. Defaults to 0. Canny下限。默认为0。
            canny_higher (int, optional): Canny upper. Defaults to 0. Canny上限。默认为0。
            settle_time (float, optional): Settle time. Defaults to -1. 稳定时间。默认为-1。
            frame_processor (Optional[Callable[[np.ndarray], np.ndarray]], optional): Processor. Defaults to None. 处理器。默认为None。

        Returns:
            Optional[Box]: The feature box. 特征框。
        """
        ...

    def wait_click_feature(self, feature: str, horizontal_variance: float = 0, vertical_variance: float = 0,
                           threshold: float = 0, relative_x: float = 0.5, relative_y: float = 0.5, time_out: float = 0,
                           pre_action: Optional[Callable[[], None]] = None,
                           post_action: Optional[Callable[[], None]] = None, box: Optional[Box] = None,
                           raise_if_not_found: bool = True, use_gray_scale: bool = False, canny_lower: int = 0,
                           canny_higher: int = 0, click_after_delay: float = 0, settle_time: float = -1,
                           after_sleep: float = 0) -> bool:
        """
        Waits for feature and clicks it.

        等待特征并点击它。

        Args:
            feature (str): Feature name. 特征名称。
            horizontal_variance (float, optional): Horizontal variance. Defaults to 0. 水平方差。默认为0。
            vertical_variance (float, optional): Vertical variance. Defaults to 0. 垂直方差。默认为0。
            threshold (float, optional): Threshold. Defaults to 0. 阈值。默认为0。
            relative_x (float, optional): Click relative x. Defaults to 0.5. 点击相对x。默认为0.5。
            relative_y (float, optional): Click relative y. Defaults to 0.5. 点击相对y。默认为0.5。
            time_out (float, optional): Timeout. Defaults to 0. 超时。默认为0。
            pre_action (Optional[Callable[[], None]], optional): Pre action. Defaults to None. 前置操作。默认为None。
            post_action (Optional[Callable[[], None]], optional): Post action. Defaults to None. 后置操作。默认为None。
            box (Optional[Box], optional): Search box. Defaults to None. 搜索框。默认为None。
            raise_if_not_found (bool, optional): Raise if not found. Defaults to True. 如果未找到则引发异常。默认为True。
            use_gray_scale (bool, optional): Use grayscale. Defaults to False. 使用灰度。默认为False。
            canny_lower (int, optional): Canny lower. Defaults to 0. Canny下限。默认为0。
            canny_higher (int, optional): Canny upper. Defaults to 0. Canny上限。默认为0。
            click_after_delay (float, optional): Delay before click. Defaults to 0. 点击前延迟。默认为0。
            settle_time (float, optional): Settle time. Defaults to -1. 稳定时间。默认为-1。
            after_sleep (float, optional): Sleep after click. Defaults to 0. 点击后休眠。默认为0。

        Returns:
            bool: True if clicked. 如果点击成功则为True。
        """
        ...

    def find_one(self, feature_name: Optional[str] = None, horizontal_variance: float = 0, vertical_variance: float = 0,
                 threshold: float = 0, use_gray_scale: bool = False, box: Optional[Box] = None, canny_lower: int = 0,
                 canny_higher: int = 0, frame_processor: Optional[Callable[[np.ndarray], np.ndarray]] = None,
                 template: Optional[np.ndarray] = None,
                 mask_function: Optional[Callable[[np.ndarray], np.ndarray]] = None, frame: Optional[np.ndarray] = None,
                 match_method: int = cv2.TM_CCOEFF_NORMED, screenshot: bool = False) -> Optional[Box]:
        """
        Finds one instance of the feature (highest confidence).

        查找特征的一个实例（最高置信度）。

        Args:
            feature_name (Optional[str], optional): Feature name. Defaults to None. 特征名称。默认为None。
            horizontal_variance (float, optional): Horizontal variance. Defaults to 0. 水平方差。默认为0。
            vertical_variance (float, optional): Vertical variance. Defaults to 0. 垂直方差。默认为0。
            threshold (float, optional): Threshold. Defaults to 0. 阈值。默认为0。
            use_gray_scale (bool, optional): Use grayscale. Defaults to False. 使用灰度。默认为False。
            box (Optional[Box], optional): Search box. Defaults to None. 搜索框。默认为None。
            canny_lower (int, optional): Canny lower. Defaults to 0. Canny下限。默认为0。
            canny_higher (int, optional): Canny upper. Defaults to 0. Canny上限。默认为0。
            frame_processor (Optional[Callable[[np.ndarray], np.ndarray]], optional): Processor. Defaults to None. 处理器。默认为None。
            template (Optional[np.ndarray], optional): Template. Defaults to None. 模板。默认为None。
            mask_function (Optional[Callable[[np.ndarray], np.ndarray]], optional): Mask. Defaults to None. 掩码。默认为None。
            frame (Optional[np.ndarray], optional): Frame. Defaults to None. 帧。默认为None。
            match_method (int, optional): Method. Defaults to cv2.TM_CCOEFF_NORMED. 方法。默认为cv2.TM_CCOEFF_NORMED。
            screenshot (bool, optional): Screenshot. Defaults to False. 截图。默认为False。

        Returns:
            Optional[Box]: The box or None. 框或None。
        """
        ...

    def on_feature(self, boxes: List[Box]) -> None:
        """
        Callback when features are found.

        找到特征时的回调。

        Args:
            boxes (List[Box]): Found boxes. 找到的框。
        """
        ...

    def feature_exists(self, feature_name: str) -> bool:
        """
        Checks if feature exists.

        检查特征是否存在。

        Args:
            feature_name (str): Feature name. 特征名称。

        Returns:
            bool: True if exists. 如果存在则为True。
        """
        ...

    def find_best_match_in_box(self, box: Box, to_find: List[str], threshold: float, use_gray_scale: bool = False,
                               canny_lower: int = 0, canny_higher: int = 0,
                               frame_processor: Optional[Callable[[np.ndarray], np.ndarray]] = None,
                               mask_function: Optional[Callable[[np.ndarray], np.ndarray]] = None) -> Optional[Box]:
        """
        Finds the best matching feature in a box.

        在框中找到最佳匹配特征。

        Args:
            box (Box): Search box. 搜索框。
            to_find (List[str]): Feature names to find. 要查找的特征名称。
            threshold (float): Threshold. 阈值。
            use_gray_scale (bool, optional): Grayscale. Defaults to False. 灰度。默认为False。
            canny_lower (int, optional): Canny lower. Defaults to 0. Canny下限。默认为0。
            canny_higher (int, optional): Canny upper. Defaults to 0. Canny上限。默认为0。
            frame_processor (Optional[Callable[[np.ndarray], np.ndarray]], optional): Processor. Defaults to None. 处理器。默认为None。
            mask_function (Optional[Callable[[np.ndarray], np.ndarray]], optional): Mask. Defaults to None. 掩码。默认为None。

        Returns:
            Optional[Box]: Best match or None. 最佳匹配或None。
        """
        ...

    def find_first_match_in_box(self, box: Box, to_find: List[str], threshold: float, use_gray_scale: bool = False,
                                canny_lower: int = 0, canny_higher: int = 0,
                                frame_processor: Optional[Callable[[np.ndarray], np.ndarray]] = None,
                                mask_function: Optional[Callable[[np.ndarray], np.ndarray]] = None) -> Optional[Box]:
        """
        Finds the first matching feature in a box.

        在框中找到第一个匹配特征。

        Args:
            box (Box): Search box. 搜索框。
            to_find (List[str]): Feature names. 特征名称。
            threshold (float): Threshold. 阈值。
            use_gray_scale (bool, optional): Grayscale. Defaults to False. 灰度。默认为False。
            canny_lower (int, optional): Canny lower. Defaults to 0. Canny下限。默认为0。
            canny_higher (int, optional): Canny upper. Defaults to 0. Canny上限。默认为0。
            frame_processor (Optional[Callable[[np.ndarray], np.ndarray]], optional): Processor. Defaults to None. 处理器。默认为None。
            mask_function (Optional[Callable[[np.ndarray], np.ndarray]], optional): Mask. Defaults to None. 掩码。默认为None。

        Returns:
            Optional[Box]: First match or None. 第一个匹配或None。
        """
        ...


class OCR(FindFeature):
    """
    Handles optical character recognition operations.

    处理光学字符识别操作。
    """
    ocr_default_threshold: float
    log_debug: bool

    def __init__(self, executor: 'TaskExecutor') -> None:
        """
        Initializes OCR with executor.

        使用执行器初始化OCR。

        Args:
            executor (TaskExecutor): The executor. 执行器。
        """
        ...

    def get_threshold(self, lib: str, threshold: float) -> float:
        """
        Gets OCR threshold for library.

        获取库的OCR阈值。

        Args:
            lib (str): OCR library. OCR库。
            threshold (float): Provided threshold. 提供的阈值。

        Returns:
            float: Effective threshold. 有效阈值。
        """
        ...

    def ocr(self, x: float = 0, y: float = 0, to_x: float = 1, to_y: float = 1,
            match: Optional[Union[str, List[str], re.Pattern, List[re.Pattern]]] = None, width: int = 0,
            height: int = 0, box: Optional[Union[Box, str]] = None, name: Optional[str] = None, threshold: float = 0,
            frame: Optional[np.ndarray] = None, target_height: int = 0, use_grayscale: bool = False, log: bool = False,
            frame_processor: Optional[Callable[[np.ndarray], np.ndarray]] = None, lib: str = 'default') -> List[Box]:
        """
        Performs OCR on a region.

        在区域执行OCR。

        Args:
            x (float, optional): Relative x start. Defaults to 0. 相对x起始。默认为0。
            y (float, optional): Relative y start. Defaults to 0. 相对y起始。默认为0。
            to_x (float, optional): Relative x end. Defaults to 1. 相对x结束。默认为1。
            to_y (float, optional): Relative y end. Defaults to 1. 相对y结束。默认为1。
            match (Optional[Union[str, List[str], re.Pattern, List[re.Pattern]]], optional): Text match. Defaults to None. 文本匹配。默认为None。
            width (int, optional): Width. Defaults to 0. 宽度。默认为0。
            height (int, optional): Height. Defaults to 0. 高度。默认为0。
            box (Optional[Union[Box, str]], optional): Region box. Defaults to None. 区域框。默认为None。
            name (Optional[str], optional): Region name. Defaults to None. 区域名称。默认为None。
            threshold (float, optional): Threshold. Defaults to 0. 阈值。默认为0。
            frame (Optional[np.ndarray], optional): Frame. Defaults to None. 帧。默认为None。
            target_height (int, optional): Target height for resize. Defaults to 0. 调整大小的目标高度。默认为0。
            use_grayscale (bool, optional): Use grayscale. Defaults to False. 使用灰度。默认为False。
            log (bool, optional): Log results. Defaults to False. 记录结果。默认为False。
            frame_processor (Optional[Callable[[np.ndarray], np.ndarray]], optional): Processor. Defaults to None. 处理器。默认为None。
            lib (str, optional): OCR library. Defaults to 'default'. OCR库。默认为'default'。

        Returns:
            List[Box]: Detected text boxes. 检测到的文本框。
        """
        ...

    def ocr_fun(self, lib: str) -> Callable:
        """
        Gets the OCR function for the library.

        获取库的OCR函数。

        Args:
            lib (str): Library name. 库名称。

        Returns:
            Callable: The OCR function. OCR函数。
        """
        ...

    def fix_match_regex(self, match: Any) -> Any:
        """
        Fixes regex patterns with translations.

        使用翻译修复正则模式。

        Args:
            match (Any): Match patterns. 匹配模式。

        Returns:
            Any: Fixed match. 修复的匹配。
        """
        ...

    def fix_texts(self, detected_boxes: List[Box]) -> None:
        """
        Fixes detected text with translations.

        使用翻译修复检测到的文本。

        Args:
            detected_boxes (List[Box]): Detected boxes. 检测到的框。
        """
        ...

    def add_text_fix(self, fix: dict) -> None:
        """
        Adds text fixes.

        添加文本修复。

        Args:
            fix (dict): Fix dictionary. 修复字典。
        """
        ...

    def onnx_ocr(self, box: Optional[Box], image: np.ndarray, match: Any, scale_factor: float, threshold: float,
                 lib: str) -> Tuple[List[Box], List[Box]]:
        """
        Performs ONNX OCR.

        执行ONNX OCR。

        Args:
            box (Optional[Box]): Region box. 区域框。
            image (np.ndarray): Image. 图像。
            match (Any): Match patterns. 匹配模式。
            scale_factor (float): Scale factor. 缩放因子。
            threshold (float): Threshold. 阈值。
            lib (str): Library. 库。

        Returns:
            Tuple[List[Box], List[Box]]: Detected and all boxes. 检测到的和所有框。
        """
        ...

    def rapid_ocr(self, box: Optional[Box], image: np.ndarray, match: Any, scale_factor: float, threshold: float,
                  lib: str) -> Tuple[List[Box], List[Box]]:
        """
        Performs RapidOCR.

        执行RapidOCR。

        Args:
            box (Optional[Box]): Region box. 区域框。
            image (np.ndarray): Image. 图像。
            match (Any): Match patterns. 匹配模式。
            scale_factor (float): Scale factor. 缩放因子。
            threshold (float): Threshold. 阈值。
            lib (str): Library. 库。

        Returns:
            Tuple[List[Box], List[Box]]: Detected and all boxes. 检测到的和所有框。
        """
        ...

    def duguang_ocr(self, box: Optional[Box], image: np.ndarray, match: Any, scale_factor: float, threshold: float,
                    lib: str) -> Tuple[List[Box], List[Box]]:
        """
        Performs Duguang OCR.

        执行Duguang OCR。

        Args:
            box (Optional[Box]): Region box. 区域框。
            image (np.ndarray): Image. 图像。
            match (Any): Match patterns. 匹配模式。
            scale_factor (float): Scale factor. 缩放因子。
            threshold (float): Threshold. 阈值。
            lib (str): Library. 库。

        Returns:
            Tuple[List[Box], List[Box]]: Detected and all boxes. 检测到的和所有框。
        """
        ...

    def paddle_ocr(self, box: Optional[Box], image: np.ndarray, match: Any, scale_factor: float, threshold: float,
                   lib: str) -> Tuple[List[Box], List[Box]]:
        """
        Performs PaddleOCR.

        执行PaddleOCR。

        Args:
            box (Optional[Box]): Region box. 区域框。
            image (np.ndarray): Image. 图像。
            match (Any): Match patterns. 匹配模式。
            scale_factor (float): Scale factor. 缩放因子。
            threshold (float): Threshold. 阈值。
            lib (str): Library. 库。

        Returns:
            Tuple[List[Box], List[Box]]: Detected and all boxes. 检测到的和所有框。
        """
        ...

    def get_box(self, box: Optional[Box], confidence: float, height: int, pos: Any, scale_factor: float, text: str,
                threshold: float, width: int) -> Optional[Box]:
        """
        Creates a box from OCR result.

        从OCR结果创建框。

        Args:
            box (Optional[Box]): Parent box. 父框。
            confidence (float): Confidence. 置信度。
            height (int): Height. 高度。
            pos (Any): Position. 位置。
            scale_factor (float): Scale. 缩放。
            text (str): Detected text. 检测到的文本。
            threshold (float): Threshold. 阈值。
            width (int): Width. 宽度。

        Returns:
            Optional[Box]: The box or None. 框或None。
        """
        ...

    def wait_click_ocr(self, x: float = 0, y: float = 0, to_x: float = 1, to_y: float = 1, width: int = 0,
                       height: int = 0, box: Optional[Union[Box, str]] = None, name: Optional[str] = None,
                       match: Optional[Union[str, List[str], re.Pattern, List[re.Pattern]]] = None,
                       threshold: float = 0, frame: Optional[np.ndarray] = None, target_height: int = 0,
                       time_out: float = 0, raise_if_not_found: bool = False, recheck_time: float = 0,
                       after_sleep: float = 0, post_action: Optional[Callable[[], None]] = None, log: bool = False,
                       settle_time: float = -1, lib: str = "default") -> Optional[Box]:
        """
        Waits for OCR text and clicks it.

        等待OCR文本并点击它。

        Args:
            x (float, optional): Relative x. Defaults to 0. 相对x。默认为0。
            y (float, optional): Relative y. Defaults to 0. 相对y。默认为0。
            to_x (float, optional): Relative to x. Defaults to 1. 相对到x。默认为1。
            to_y (float, optional): Relative to y. Defaults to 1. 相对到y。默认为1。
            width (int, optional): Width. Defaults to 0. 宽度。默认为0。
            height (int, optional): Height. Defaults to 0. 高度。默认为0。
            box (Optional[Union[Box, str]], optional): Box. Defaults to None. 框。默认为None。
            name (Optional[str], optional): Name. Defaults to None. 名称。默认为None。
            match (Optional[Union[str, List[str], re.Pattern, List[re.Pattern]]], optional): Match. Defaults to None. 匹配。默认为None。
            threshold (float, optional): Threshold. Defaults to 0. 阈值。默认为0。
            frame (Optional[np.ndarray], optional): Frame. Defaults to None. 帧。默认为None。
            target_height (int, optional): Target height. Defaults to 0. 目标高度。默认为0。
            time_out (float, optional): Timeout. Defaults to 0. 超时。默认为0。
            raise_if_not_found (bool, optional): Raise if not found. Defaults to False. 如果未找到则引发异常。默认为False。
            recheck_time (float, optional): Recheck time. Defaults to 0. 重新检查时间。默认为0。
            after_sleep (float, optional): Sleep after. Defaults to 0. 点击后休眠。默认为0。
            post_action (Optional[Callable[[], None]], optional): Post action. Defaults to None. 后置操作。默认为None。
            log (bool, optional): Log. Defaults to False. 记录。默认为False。
            settle_time (float, optional): Settle time. Defaults to -1. 稳定时间。默认为-1。
            lib (str, optional): Library. Defaults to "default". 库。默认为"default"。

        Returns:
            Optional[Box]: Clicked box. 点击的框。
        """
        ...

    def wait_ocr(self, x: float = 0, y: float = 0, to_x: float = 1, to_y: float = 1, width: int = 0, height: int = 0,
                 name: Optional[str] = None, box: Optional[Union[Box, str]] = None,
                 match: Optional[Union[str, List[str], re.Pattern, List[re.Pattern]]] = None, threshold: float = 0,
                 frame: Optional[np.ndarray] = None, target_height: int = 0, time_out: float = 0,
                 post_action: Optional[Callable[[], None]] = None, raise_if_not_found: bool = False, log: bool = False,
                 settle_time: float = -1, lib: str = "default") -> List[Box]:
        """
        Waits for OCR text.

        等待OCR文本。

        Args:
            x (float, optional): Relative x. Defaults to 0. 相对x。默认为0。
            y (float, optional): Relative y. Defaults to 0. 相对y。默认为0。
            to_x (float, optional): Relative to x. Defaults to 1. 相对到x。默认为1。
            to_y (float, optional): Relative to y. Defaults to 1. 相对到y。默认为1。
            width (int, optional): Width. Defaults to 0. 宽度。默认为0。
            height (int, optional): Height. Defaults to 0. 高度。默认为0。
            name (Optional[str], optional): Name. Defaults to None. 名称。默认为None。
            box (Optional[Union[Box, str]], optional): Box. Defaults to None. 框。默认为None。
            match (Optional[Union[str, List[str], re.Pattern, List[re.Pattern]]], optional): Match. Defaults to None. 匹配。默认为None。
            threshold (float, optional): Threshold. Defaults to 0. 阈值。默认为0。
            frame (Optional[np.ndarray], optional): Frame. Defaults to None. 帧。默认为None。
            target_height (int, optional): Target height. Defaults to 0. 目标高度。默认为0。
            time_out (float, optional): Timeout. Defaults to 0. 超时。默认为0。
            post_action (Optional[Callable[[], None]], optional): Post action. Defaults to None. 后置操作。默认为None。
            raise_if_not_found (bool, optional): Raise if not found. Defaults to False. 如果未找到则引发异常。默认为False。
            log (bool, optional): Log. Defaults to False. 记录。默认为False。
            settle_time (float, optional): Settle time. Defaults to -1. 稳定时间。默认为-1。
            lib (str, optional): Library. Defaults to "default". 库。默认为"default"。

        Returns:
            List[Box]: Detected boxes. 检测到的框。
        """
        ...


class BaseTask(OCR):
    """
    Base class for tasks, inheriting OCR capabilities.

    任务基类，继承OCR功能。
    """
    name: str
    description: str
    _enabled: bool
    config: Optional['Config']
    info: 'InfoDict'
    default_config: dict
    config_description: dict
    config_type: dict
    _paused: bool
    lock: threading.Lock
    _handler: Optional[Any]
    running: bool
    exit_after_task: bool
    trigger_interval: float
    last_trigger_time: float
    start_time: float
    icon: Optional[Any]
    supported_languages: List[str]
    first_run_alert: Optional[str]
    show_create_shortcut: bool
    global_config_names: List[str]

    def __init__(self, executor: Optional['TaskExecutor'] = None) -> None:
        """
        Initializes a base task.

        初始化基任务。

        Args:
            executor (Optional[TaskExecutor], optional): The executor. Defaults to None. 执行器。默认为None。
        """
        ...

    def run_task_by_class(self, cls: type) -> None:
        """
        Runs a sub-task by class.

        通过类运行子任务。

        Args:
            cls (type): Sub-task class. 子任务类。
        """
        ...

    def post_init(self) -> None:
        """
        Post-initialization hook.

        后初始化钩子。
        """
        ...

    def create_shortcut(self) -> None:
        """
        Creates a desktop shortcut for the task.

        为任务创建桌面快捷方式。
        """
        ...

    def tr(self, message: str) -> str:
        """
        Translates a message.

        翻译消息。

        Args:
            message (str): Message to translate. 要翻译的消息。

        Returns:
            str: Translated message. 翻译后的消息。
        """
        ...

    def should_trigger(self) -> bool:
        """
        Checks if the task should trigger based on interval.

        根据间隔检查任务是否应触发。

        Returns:
            bool: True if ready. 如果准备好则为True。
        """
        ...

    def is_custom(self) -> bool:
        """
        Checks if the task is custom.

        检查任务是否自定义。

        Returns:
            bool: True if custom. 如果自定义则为True。
        """
        ...

    def add_first_run_alert(self, first_run_alert: str) -> None:
        """
        Adds a first-run alert configuration.

        添加首次运行警报配置。

        Args:
            first_run_alert (str): Alert message. 警报消息。
        """
        ...

    def add_exit_after_config(self) -> None:
        """
        Adds exit-after-task configuration.

        添加任务后退出配置。
        """
        ...

    def get_status(self) -> str:
        """
        Gets the current status of the task.

        获取任务当前状态。

        Returns:
            str: Status string. 状态字符串。
        """
        ...

    def enable(self) -> None:
        """
        Enables the task.

        启用任务。
        """
        ...

    @property
    def handler(self) -> Any:
        """
        Gets the task handler.

        获取任务处理程序。

        Returns:
            Any: The handler. 处理程序。
        """
        ...

    def pause(self) -> None:
        """
        Pauses the task.

        暂停任务。
        """
        ...

    def unpause(self) -> None:
        """
        Unpauses the task.

        恢复任务。
        """
        ...

    @property
    def paused(self) -> bool:
        """
        Checks if paused.

        检查是否暂停。

        Returns:
            bool: True if paused. 如果暂停则为True。
        """
        ...

    def log_info(self, message: Any, notify: bool = False) -> None:
        """
        Logs an info message.

        记录信息消息。

        Args:
            message (Any): Message. 消息。
            notify (bool, optional): Notify user. Defaults to False. 通知用户。默认为False。
        """
        ...

    def log_debug(self, message: Any, notify: bool = False) -> None:
        """
        Logs a debug message.

        记录调试消息。

        Args:
            message (Any): Message. 消息。
            notify (bool, optional): Notify user. Defaults to False. 通知用户。默认为False。
        """
        ...

    def log_error(self, message: Any, exception: Optional[Exception] = None, notify: bool = False) -> None:
        """
        Logs an error message.

        记录错误消息。

        Args:
            message (Any): Message. 消息。
            exception (Optional[Exception], optional): Exception. Defaults to None. 异常。默认为None。
            notify (bool, optional): Notify user. Defaults to False. 通知用户。默认为False。
        """
        ...

    def go_to_tab(self, tab: str) -> None:
        """
        Navigates to a tab.

        导航到选项卡。

        Args:
            tab (str): Tab name. 选项卡名称。
        """
        ...

    def notification(self, message: str, title: Optional[str] = None, error: bool = False, tray: bool = False,
                     show_tab: Optional[str] = None) -> None:
        """
        Shows a notification.

        显示通知。

        Args:
            message (str): Message. 消息。
            title (Optional[str], optional): Title. Defaults to None. 标题。默认为None。
            error (bool, optional): Error type. Defaults to False. 错误类型。默认为False。
            tray (bool, optional): Show in tray. Defaults to False. 在托盘中显示。默认为False。
            show_tab (Optional[str], optional): Tab to show. Defaults to None. 要显示的选项卡。默认为None。
        """
        ...

    @property
    def enabled(self) -> bool:
        """
        Checks if enabled.

        检查是否启用。

        Returns:
            bool: True if enabled. 如果启用则为True。
        """
        ...

    def info_clear(self) -> None:
        """
        Clears task info.

        清除任务信息。
        """
        ...

    def info_incr(self, key: str, inc: int = 1) -> None:
        """
        Increments an info value.

        增加信息值。

        Args:
            key (str): Info key. 信息键。
            inc (int, optional): Increment. Defaults to 1. 增量。默认为1。
        """
        ...

    def info_add_to_list(self, key: str, item: Any) -> None:
        """
        Adds item to info list.

        将项添加到信息列表。

        Args:
            key (str): List key. 列表键。
            item (Any): Item to add. 要添加的项。
        """
        ...

    def info_set(self, key: str, value: Any) -> None:
        """
        Sets an info value.

        设置信息值。

        Args:
            key (str): Info key. 信息键。
            value (Any): Value. 值。
        """
        ...

    def info_get(self, *args: Any, **kwargs: Any) -> Any:
        """
        Gets an info value.

        获取信息值。

        Args:
            *args (Any): Get args. 获取参数。
            **kwargs (Any): Get kwargs. 获取关键字参数。

        Returns:
            Any: Value. 值。
        """
        ...

    def info_add(self, key: str, count: int = 1) -> None:
        """
        Adds to info counter.

        添加到信息计数器。

        Args:
            key (str): Counter key. 计数器键。
            count (int, optional): Count to add. Defaults to 1. 要添加的计数。默认为1。
        """
        ...

    def load_config(self) -> None:
        """
        Loads task configuration.

        加载任务配置。
        """
        ...

    def validate(self, key: str, value: Any) -> Tuple[bool, Optional[str]]:
        """
        Validates config value.

        验证配置值。

        Args:
            key (str): Config key. 配置键。
            value (Any): Value. 值。

        Returns:
            Tuple[bool, Optional[str]]: (valid, message). （有效，消息）。
        """
        ...

    def validate_config(self, key: str, value: Any) -> Optional[str]:
        """
        Validates a config entry.

        验证配置条目。

        Args:
            key (str): Key. 键。
            value (Any): Value. 值。

        Returns:
            Optional[str]: Error message or None. 错误消息或None。
        """
        ...

    def disable(self) -> None:
        """
        Disables the task.

        禁用任务。
        """
        ...

    @property
    def hwnd_title(self) -> str:
        """
        Gets the HWND title.

        获取HWND标题。

        Returns:
            str: Window title. 窗口标题。
        """
        ...

    def run(self) -> None:
        """
        Runs the task logic.

        运行任务逻辑。
        """
        ...

    def trigger(self) -> bool:
        """
        Triggers the task.

        触发任务。

        Returns:
            bool: Trigger result. 触发结果。
        """
        ...

    def on_destroy(self) -> None:
        """
        Cleanup on destroy.

        销毁时清理。
        """
        ...

    def on_create(self) -> None:
        """
        Initialization on create.

        创建时初始化。
        """
        ...

    def set_executor(self, executor: 'TaskExecutor') -> None:
        """
        Sets the executor and initializes.

        设置执行器并初始化。

        Args:
            executor (TaskExecutor): The executor. 执行器。
        """
        ...

    def find_boxes(self, boxes: List[Box], match: Optional[Union[str, List[str]]] = None,
                   boundary: Optional[Union[str, Box]] = None) -> List[Box]:
        """
        Finds boxes by match and boundary.

        通过匹配和边界查找框。

        Args:
            boxes (List[Box]): Input boxes. 输入框。
            match (Optional[Union[str, List[str]]], optional): Name match. Defaults to None. 名称匹配。默认为None。
            boundary (Optional[Union[str, Box]], optional): Boundary box. Defaults to None. 边界框。默认为None。

        Returns:
            List[Box]: Filtered boxes. 过滤后的框。
        """
        ...


class TriggerTask(BaseTask):
    """
    Task that runs periodically.

    定期运行的任务。
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """
        Initializes a trigger task.

        初始化触发任务。

        Args:
            *args (Any): Positional args. 位置参数。
            **kwargs (Any): Keyword args. 关键字参数。
        """
        ...

    def on_create(self) -> None:
        """
        Sets enabled from config.

        从配置设置启用。
        """
        ...

    def get_status(self) -> str:
        """
        Gets enabled/disabled status.

        获取启用/禁用状态。

        Returns:
            str: Status. 状态。
        """
        ...

    def enable(self) -> None:
        """
        Enables and updates config.

        启用并更新配置。
        """
        ...

    def disable(self) -> None:
        """
        Disables and updates config.

        禁用并更新配置。
        """
        ...

class TaskExecutor:
    """
    Executes tasks in a loop.

    在循环中执行任务。
    """
    _frame: Optional[np.ndarray]
    paused: bool
    pause_start: float
    pause_end_time: float
    _last_frame_time: float
    wait_until_timeout: float
    device_manager: 'DeviceManager'
    feature_set: Optional['FeatureSet']
    wait_until_settle_time: float
    wait_scene_timeout: float
    exit_event: Any  # threading.Event
    debug_mode: bool
    debug: bool
    global_config: 'GlobalConfig'
    _ocr_lib: dict
    ocr_target_height: int
    current_task: Optional[BaseTask]
    config_folder: str
    trigger_task_index: int
    trigger_tasks: List[TriggerTask]
    onetime_tasks: List[BaseTask]
    thread: Optional[threading.Thread]
    locale: Any  # QLocale
    scene: Optional[Any]
    text_fix: dict
    ocr_po_translation: Any
    config: dict
    basic_options: dict
    lock: threading.Lock

    def __init__(self, device_manager: 'DeviceManager', wait_until_timeout: float = 10,
                 wait_until_settle_time: float = -1, exit_event: Optional[Any] = None,
                 feature_set: Optional['FeatureSet'] = None, ocr_lib: Optional[dict] = None,
                 config_folder: Optional[str] = None, debug: bool = False,
                 global_config: Optional['GlobalConfig'] = None, ocr_target_height: int = 0,
                 config: Optional[dict] = None) -> None:
        """
        Initializes the task executor.

        初始化任务执行器。

        Args:
            device_manager (DeviceManager): Device manager. 设备管理器。
            wait_until_timeout (float, optional): Wait timeout. Defaults to 10. 等待超时。默认为10。
            wait_until_settle_time (float, optional): Settle time. Defaults to -1. 稳定时间。默认为-1。
            exit_event (Optional[Any], optional): Exit event. Defaults to None. 退出事件。默认为None。
            feature_set (Optional[FeatureSet], optional): Feature set. Defaults to None. 特征集。默认为None。
            ocr_lib (Optional[dict], optional): OCR libs. Defaults to None. OCR库。默认为None。
            config_folder (Optional[str], optional): Config folder. Defaults to None. 配置文件夹。默认为None。
            debug (bool, optional): Debug mode. Defaults to False. 调试模式。默认为False。
            global_config (Optional[GlobalConfig], optional): Global config. Defaults to None. 全局配置。默认为None。
            ocr_target_height (int, optional): OCR target height. Defaults to 0. OCR目标高度。默认为0。
            config (Optional[dict], optional): Config. Defaults to None. 配置。默认为None。
        """
        ...

    def load_tr(self) -> None:
        """
        Loads translations.

        加载翻译。
        """
        ...

    @property
    def interaction(self) -> 'BaseInteraction':
        """
        Gets the interaction handler.

        获取交互处理程序。

        Returns:
            BaseInteraction: Interaction. 交互。
        """
        ...

    @property
    def method(self) -> 'BaseCaptureMethod':
        """
        Gets the capture method.

        获取捕获方法。

        Returns:
            BaseCaptureMethod: Method. 方法。
        """
        ...

    def ocr_lib(self, name: str = "default") -> Any:
        """
        Gets OCR library instance.

        获取OCR库实例。

        Args:
            name (str, optional): Library name. Defaults to "default". 库名称。默认为"default"。

        Returns:
            Any: OCR instance. OCR实例。
        """
        ...

    def nullable_frame(self) -> Optional[np.ndarray]:
        """
        Gets the last frame if available.

        如果可用则获取最后帧。

        Returns:
            Optional[np.ndarray]: Frame or None. 帧或None。
        """
        ...

    def check_frame_and_resolution(self, supported_ratio: Optional[str] = None,
                                   min_size: Optional[Tuple[int, int]] = None, time_out: float = 8.0) -> Tuple[
        bool, str]:
        """
        Checks frame and resolution match.

        检查帧和分辨率匹配。

        Args:
            supported_ratio (Optional[str], optional): Supported ratio e.g. "16:9". 支持比例例如"16:9"。默认为None。
            min_size (Optional[Tuple[int, int]], optional): Minimum size. Defaults to None. 最小尺寸。默认为None。
            time_out (float, optional): Timeout. Defaults to 8.0. 超时。默认为8.0。

        Returns:
            Tuple[bool, str]: (match, resolution_str). （匹配，分辨率字符串）。
        """
        ...

    def can_capture(self) -> bool:
        """
        Checks if capture is possible.

        检查是否可以捕获。

        Returns:
            bool: True if can capture. 如果可以捕获则为True。
        """
        ...

    def next_frame(self) -> np.ndarray:
        """
        Gets the next frame, resetting scene.

        获取下一帧，重置场景。

        Returns:
            np.ndarray: The frame. 帧。
        """
        ...

    def is_executor_thread(self) -> bool:
        """
        Checks if current thread is executor thread.

        检查当前线程是否为执行器线程。

        Returns:
            bool: True if executor thread. 如果是执行器线程则为True。
        """
        ...

    def connected(self) -> bool:
        """
        Checks if connected to device.

        检查是否连接到设备。

        Returns:
            bool: True if connected. 如果连接则为True。
        """
        ...

    @property
    def frame(self) -> np.ndarray:
        """
        Gets the current frame, waiting if paused.

        获取当前帧，如果暂停则等待。

        Returns:
            np.ndarray: The frame. 帧。
        """
        ...

    def check_enabled(self, check_pause: bool = True) -> None:
        """
        Checks if task is enabled, raises if not.

        检查任务是否启用，如果不是则引发异常。

        Args:
            check_pause (bool, optional): Check pause. Defaults to True. 检查暂停。默认为True。
        """
        ...

    def sleep(self, timeout: float) -> None:
        """
        Sleeps with checks for exit and pause.

        带有退出和暂停检查的休眠。

        Args:
            timeout (float): Sleep time. 休眠时间。
        """
        ...

    def pause(self, task: Optional[BaseTask] = None) -> bool:
        """
        Pauses the executor or task.

        暂停执行器或任务。

        Args:
            task (Optional[BaseTask], optional): Task to pause. Defaults to None. 要暂停的任务。默认为None。

        Returns:
            bool: True if paused. 如果暂停则为True。
        """
        ...

    def stop_current_task(self) -> None:
        """
        Stops the current task.

        停止当前任务。
        """
        ...

    def start(self) -> None:
        """
        Starts the executor thread if not running.

        如果未运行则启动执行器线程。
        """
        ...

    def wait_condition(self, condition: Callable[[], Any], time_out: float = 0,
                       pre_action: Optional[Callable[[], None]] = None,
                       post_action: Optional[Callable[[], None]] = None, settle_time: float = -1,
                       raise_if_not_found: bool = False) -> Optional[Any]:
        """
        Waits for condition with settle.

        带有稳定的等待条件。

        Args:
            condition (Callable[[], Any]): Condition. 条件。
            time_out (float, optional): Timeout. Defaults to 0. 超时。默认为0。
            pre_action (Optional[Callable[[], None]], optional): Pre. Defaults to None. 前置。默认为None。
            post_action (Optional[Callable[[], None]], optional): Post. Defaults to None. 后置。默认为None。
            settle_time (float, optional): Settle. Defaults to -1. 稳定。默认为-1。
            raise_if_not_found (bool, optional): Raise. Defaults to False. 引发。默认为False。

        Returns:
            Optional[Any]: Result. 结果。
        """
        ...

    def reset_scene(self, check_enabled: bool = True) -> None:
        """
        Resets the scene and frame.

        重置场景和帧。

        Args:
            check_enabled (bool, optional): Check enabled. Defaults to True. 检查启用。默认为True。
        """
        ...

    def next_task(self) -> Tuple[Optional[BaseTask], bool, bool]:
        """
        Gets the next task to execute.

        获取下一个要执行的任务。

        Returns:
            Tuple[Optional[BaseTask], bool, bool]: (task, cycled, is_trigger). （任务，循环，触发）。
        """
        ...

    def active_trigger_task_count(self) -> int:
        """
        Counts active trigger tasks.

        计数活动触发任务。

        Returns:
            int: Count. 计数。
        """
        ...

    def trigger_sleep(self) -> None:
        """
        Sleeps based on trigger interval.

        根据触发间隔休眠。
        """
        ...

    def execute(self) -> None:
        """
        Main execution loop.

        主要执行循环。
        """
        ...

    def stop(self) -> None:
        """
        Stops the executor.

        停止执行器。
        """
        ...

    def wait_until_done(self) -> None:
        """
        Waits for thread to finish.

        等待线程完成。
        """
        ...

    def get_all_tasks(self) -> List[BaseTask]:
        """
        Gets all tasks.

        获取所有任务。

        Returns:
            List[BaseTask]: All tasks. 所有任务。
        """
        ...

    def get_task_by_class_name(self, class_name: str) -> Optional[BaseTask]:
        """
        Gets task by class name.

        通过类名称获取任务。

        Args:
            class_name (str): Class name. 类名称。

        Returns:
            Optional[BaseTask]: Task or None. 任务或None。
        """
        ...

    def get_task_by_class(self, cls: type) -> Optional[BaseTask]:
        """
        Gets task by class.

        通过类获取任务。

        Args:
            cls (type): Class. 类。

        Returns:
            Optional[BaseTask]: Task or None. 任务或None。
        """
        ...


class TaskDisabledException(Exception):
    """
    Raised when task is disabled.

    当任务禁用时引发。
    """
    ...


class CannotFindException(Exception):
    """
    Raised when cannot find something.

    无法找到某物时引发。
    """
    ...


class FinishedException(Exception):
    """
    Raised when finished.

    完成时引发。
    """
    ...


class WaitFailedException(Exception):
    """
    Raised when wait fails.

    等待失败时引发。
    """
    ...


class InfoDict(dict):
    """
    Dictionary for task info with custom methods.

    用于任务信息的字典，具有自定义方法。
    """

    def __delitem__(self, key: Any) -> None: ...

    def clear(self) -> None: ...

    def __setitem__(self, key: Any, value: Any) -> None: ...

class Feature:
    """
    Represents a feature image with position.

    表示具有位置的特征图像。
    """
    mat: np.ndarray
    scaling: float
    x: int
    y: int
    mask: Optional[np.ndarray]

    def __init__(self, mat: np.ndarray, x: int = 0, y: int = 0, scaling: float = 1) -> None:
        """
        Initializes a feature.

        初始化特征。

        Args:
            mat (np.ndarray): Feature image. 特征图像。
            x (int, optional): X position. Defaults to 0. x位置。默认为0。
            y (int, optional): Y position. Defaults to 0. y位置。默认为0。
            scaling (float, optional): Scaling factor. Defaults to 1. 缩放因子。默认为1。
        """
        ...

    @property
    def width(self) -> int: ...
    @property
    def height(self) -> int: ...

    def scaling(self) -> float: ...

    def __str__(self) -> str: ...


class FeatureSet:
    """
    Manages a set of features for matching.

    管理用于匹配的特征集。
    """
    width: int
    height: int
    default_threshold: float
    default_horizontal_variance: float
    default_vertical_variance: float
    coco_json: str
    debug: bool
    load_success: bool
    feature_dict: dict
    box_dict: dict
    lock: threading.Lock
    feature_processor: Optional[Callable]

    def __init__(self, debug: bool, coco_json: str, default_horizontal_variance: float,
                 default_vertical_variance: float, default_threshold: float = 0.95,
                 feature_processor: Optional[Callable] = None) -> None:
        """
        Initializes feature set from COCO JSON.

        从COCO JSON初始化特征集。

        Args:
            debug (bool): Debug mode. 调试模式。
            coco_json (str): Path to COCO JSON. COCO JSON路径。
            default_horizontal_variance (float): Default h-variance. 默认水平方差。
            default_vertical_variance (float): Default v-variance. 默认垂直方差。
            default_threshold (float, optional): Default threshold. Defaults to 0.95. 默认阈值。默认为0.95。
            feature_processor (Optional[Callable], optional): Processor. Defaults to None. 处理器。默认为None。
        """
        ...

    def feature_exists(self, feature_name: str) -> bool: ...

    def empty(self) -> bool: ...

    def check_size(self, frame: np.ndarray) -> bool: ...

    def process_data(self) -> bool: ...

    def save_images(self, target_folder: str) -> None: ...

    def get_box_by_name(self, mat: np.ndarray, category_name: str) -> Optional[Box]: ...

    def get_feature_by_name(self, mat: np.ndarray, name: str) -> Optional[Feature]: ...

    def find_one_feature(self, mat: np.ndarray, category_name: str, horizontal_variance: float = 0,
                         vertical_variance: float = 0, threshold: float = 0, use_gray_scale: bool = False, x: int = -1,
                         y: int = -1, to_x: int = -1, to_y: int = -1, width: int = -1, height: int = -1,
                         box: Optional[Box] = None, canny_lower: int = 0, canny_higher: int = 0,
                         frame_processor: Optional[Callable[[np.ndarray], np.ndarray]] = None,
                         template: Optional[np.ndarray] = None,
                         mask_function: Optional[Callable[[np.ndarray], np.ndarray]] = None,
                         match_method: int = cv2.TM_CCOEFF_NORMED, screenshot: bool = False) -> List[Box]: ...

    def find_feature(self, mat: np.ndarray, category_name: Union[str, List[str]], horizontal_variance: float = 0,
                     vertical_variance: float = 0, threshold: float = 0, use_gray_scale: bool = False, x: int = -1,
                     y: int = -1, to_x: int = -1, to_y: int = -1, width: int = -1, height: int = -1,
                     box: Optional[Box] = None, canny_lower: int = 0, canny_higher: int = 0,
                     frame_processor: Optional[Callable[[np.ndarray], np.ndarray]] = None,
                     template: Optional[np.ndarray] = None,
                     mask_function: Optional[Callable[[np.ndarray], np.ndarray]] = None,
                     match_method: int = cv2.TM_CCOEFF_NORMED, screenshot: bool = False) -> List[Box]: ...
