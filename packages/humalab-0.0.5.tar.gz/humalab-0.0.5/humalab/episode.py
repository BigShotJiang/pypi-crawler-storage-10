
from humalab.scenario import Scenario
from omegaconf import DictConfig, OmegaConf


class Episode:
    def __init__(self, run_id: str, episode_id: str, scenario_conf: DictConfig):
        self.run_id = run_id
        self.episode_id = episode_id
        self.scenario_conf = scenario_conf

    @property
    def scenario(self) -> DictConfig:
        return self.scenario_conf

    def finish(self):
        print(f"Finishing episode {self.episode_id} for scenario {self.scenario.name}")

    @property
    def yaml(self) -> str:
        """The current scenario configuration as a YAML string.

        Returns:
            str: The current scenario as a YAML string.
        """
        return OmegaConf.to_yaml(self.scenario_conf)
