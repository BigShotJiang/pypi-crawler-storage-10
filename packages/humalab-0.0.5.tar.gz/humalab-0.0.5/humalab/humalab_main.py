from humalab import init, login

from humalab.assets.files.resource_file import ResourceFile
from humalab.assets.files.urdf_file import URDFFile
from humalab.assets.resource_manager import ResourceManager

# hlb_UJRzdxW4B0e4zSuy2PRwdOBu2d1zWQDNbnQykWiOdqw
if __name__ == "__main__":
    login(api_key="hlb_srVXVzRgiVbA_9a0TRcbQmrfkoeEI0STVBX1dUubkiU",
          host="http://localhost:8000")
    
    with init(project="test",
              name="my first run",
              description="testing the humalab sdk",
              tags=["tag1", "tag2"],
              scenario_id="ff85e0c2-ba92-4b08-82df-9e6e87366ecd"
              #scenario_id="941f9f8a-cf5a-4099-8da3-557e44f94037"
              ) as run:
        print(f"Run ID: {run.id}")
        print(f"Run Name: {run.name}")
        print(f"Run Description: {run.description}")
        print(f"Run Tags: {run.tags}")
        print(f"Run Scenario YAML:\n{run.scenario.yaml}")

        scenario = run.scenario
        # Simulate some operations
        # print("CUP position: ", scenario.scenario.cup.position)
        # print("CUP orientation: ", scenario.scenario.cup.orientation)
        # print("Asset: ", scenario.scenario.cup.asset)
        # print("Friction: ", scenario.scenario.cup.friction)
        print("Num Objects: ", scenario.scenario.jkjk)
        scenario.reset()
        print("======================SCENARIO RESET==========================")
        # print("CUP position: ", scenario.scenario.cup.position)
        # print("CUP orientation: ", scenario.scenario.cup.orientation)
        # print("Asset: ", scenario.scenario.cup.asset)
        # print("Friction: ", scenario.scenario.cup.friction)
        print("Num Objects: ", scenario.scenario.jkjk)

    scenario_string = """
scenario:
    cup:
        position: "${uniform_3d: [0.7, 0.7, 0.7], 
                            [1.5, 1.3, 0.7]}"
        orientation: "${uniform: 0.3, 0.7}"
        asset: "${categorical_1d: ['lerobot', 'apple2', 'apple3'], [0.1, 0.3, 0.5]}"
        friction: "${gaussian_1d: 0.3, 0.05}"
    hello: 13
    jkjk: test
    num_objects: "${discrete_1d: 5, 10}"
    dfdjkjk: "hello"
"""
    with init(
        project="test",
        name="my first run",
        description="testing the humalab sdk",
        tags=["tag1", "tag2"],
        scenario=scenario_string,
        auto_create_scenario=False) as run:
        print(f"Run ID: {run.id}")
        print(f"Run Name: {run.name}")
        print(f"Run Description: {run.description}")
        print(f"Run Tags: {run.tags}")
        print(f"Run Scenario YAML:\n{run.scenario.yaml}")

        scenario = run.scenario
        # Simulate some operations
        print("CUP position: ", scenario.scenario.cup.position)
        print("CUP orientation: ", scenario.scenario.cup.orientation)
        print("Asset: ", scenario.scenario.cup.asset)
        print("Friction: ", scenario.scenario.cup.friction)
        print("Num Objects: ", scenario.scenario.num_objects)
        scenario.reset()
        print("======================SCENARIO RESET==========================")
        print("CUP position: ", scenario.scenario.cup.position)
        print("CUP orientation: ", scenario.scenario.cup.orientation)
        print("Asset: ", scenario.scenario.cup.asset)
        print("Friction: ", scenario.scenario.cup.friction)
        print("Num Objects: ", scenario.scenario.num_objects)

    resource = ResourceManager()
    urdf_file: URDFFile = resource.download(project="default", name="lerobot", version=1)
    print("URDF File: ", urdf_file.filename)
    print("URDF Description: ", urdf_file.description)
    print("URDF Created At: ", urdf_file.created_at)
    print("URDF Root Path: ", urdf_file._root_path)
    print("URDF Root Path: ", urdf_file._urdf_filename)

    urdf_file: URDFFile = resource.download(project="default", name="lerobot")
    print("URDF File: ", urdf_file.filename)
    print("URDF Description: ", urdf_file.description)
    print("URDF Created At: ", urdf_file.created_at)
    print("URDF Root Path: ", urdf_file._root_path)
    print("URDF Root Path: ", urdf_file._urdf_filename)

    atlas_file: ResourceFile = resource.download(project="default", name="atlas")
    print("Atlas File: ", atlas_file.filename)
    print("Atlas Description: ", atlas_file.description)
    print("Atlas Created At: ", atlas_file.created_at)

    
    """
    humalab_config = HumalabConfig()
    base_url = humalab_config.base_url
    api_key = humalab_config.api_key
    timeout = humalab_config.timeout

    api_client = HumaLabApiClient(base_url=base_url,
                                    api_key=api_key,
                                    timeout=timeout)
    resource = api_client.get_resource(name="lerobot", version=1)
    print("Resource metadata: ", resource)
    file_content = api_client.download_resource(name="lerobot")
    filename = os.path.basename(resource['resource_url'])
    filename = os.path.join(humalab_config.workspace_path, filename)
    with open(filename, "wb") as f:
        f.write(file_content)
    print(f"Resource file downloaded: {filename}")
    """
