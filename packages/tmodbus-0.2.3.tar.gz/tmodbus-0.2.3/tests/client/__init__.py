"""Unit tests for the tmodbus.client module."""
