"""Unit tests for the tmodbus.utils module."""
