# adk-utils
A collection of reusable utilities (Tools, callbacks etc) for Google ADK based agentic applications
