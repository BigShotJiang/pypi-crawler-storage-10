__author__ = "Kapil Sachdeva"
__application__ = "adk_utils"
__version__ = "0.0.1"
