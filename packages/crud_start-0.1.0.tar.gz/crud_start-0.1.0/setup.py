from setuptools import setup, find_packages

setup(
    author="Clément GARCIN",
    description="A simple CRUD with SQLAlchemy",
    name="crud_start",
    version="0.1.0",
    packages=find_packages(include=["crud", "crud.*"]),
    install_requires=[
        "fastapi",
        "requests",
        "SQLAlchemy",
        "pandas"
    ],
    
)