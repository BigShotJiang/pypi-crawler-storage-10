"""Database schema module for market data store."""
