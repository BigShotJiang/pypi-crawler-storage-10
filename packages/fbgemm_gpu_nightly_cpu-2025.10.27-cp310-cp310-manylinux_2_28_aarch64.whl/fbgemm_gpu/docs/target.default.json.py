
{
    "version": "2025.10.27",
    "target": "default",
    "variant": "cpu"
}
