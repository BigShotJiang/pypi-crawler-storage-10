# Getting Started

```{toctree}
:maxdepth: 1

why-fast-vindex
installation
```

<!-- why-fast-vindex

how-to-use -->
