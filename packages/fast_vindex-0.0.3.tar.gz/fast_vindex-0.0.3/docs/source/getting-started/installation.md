# Installation

`fast-vindex` is a pure python package. It can easily be installed with pip or conda.

::::{tab-set}
:::{tab-item} pip
```bash
pip install fast-vindex
```
:::

:::{tab-item} conda
```bash
conda install fast_vindex
```
:::
::::
