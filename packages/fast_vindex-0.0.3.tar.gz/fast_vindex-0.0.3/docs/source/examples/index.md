# Examples

```{toctree}
:maxdepth: 1

synthetic_example
```
