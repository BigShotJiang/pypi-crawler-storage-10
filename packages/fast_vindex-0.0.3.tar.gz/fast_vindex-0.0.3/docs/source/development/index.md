# Development

```{toctree}
:maxdepth: 1
development
algorithm_step_by_step
supported_features
<!-- investigate_indexes_complexity
some_ideas -->
```
