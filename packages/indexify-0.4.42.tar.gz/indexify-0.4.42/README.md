## Overview

This a package with all Open Source Indexify components and helper tools
available via a CLI.

The CLI allows to:
* Setup a local or a distributed Indexify cluster.
* Build container images for Indexify functions.