def play_outside(weather, temperature):
'
'    if weather == "Sunny":
'
'        if temperature == "Hot":
'
'            return "No"
'
'        else:
'
'            return "Yes"
'
'    elif weather == "Rainy":
'
'        if temperature == "Cool":
'
'            return "Yes"
'
'        else:
'
'            return "No"
