def classify_offer(word):
'
'    spam_count = 10
'
'    ham_count = 10
'
'    offer_in_spam = 4
'
'    offer_in_ham = 1

'
'    p_spam = spam_count / (spam_count + ham_count)
'
'    p_ham = ham_count / (spam_count + ham_count)

'
'    p_offer_given_spam = offer_in_spam / spam_count
'
'    p_offer_given_ham = offer_in_ham / ham_count

'
'    return "Spam" if p_offer_given_spam * p_spam > p_offer_given_ham * p_ham else "Not Spam"
