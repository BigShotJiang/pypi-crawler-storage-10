from setuptools import setup, find_packages

setup(
    name='myclassifier-anish',              # this is the name users will type in pip install
    version='0.1.0',                  # increase this each time you update
    packages=find_packages(),
    install_requires=[],              # dependencies (optional)
    description='Simple ML classifiers by Anish',
    author='Anish Dharnidhar',
    license='MIT',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
)
