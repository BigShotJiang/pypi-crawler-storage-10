# myclassifier

Simple Python classifiers (Decision Tree and Naive Bayes) by Anish.