# Telegram module tests
