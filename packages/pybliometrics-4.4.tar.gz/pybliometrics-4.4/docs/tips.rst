====
Tips
====

.. include:: tips/support.rst
.. include:: tips/configuration.rst
.. include:: tips/database.rst
.. include:: tips/affiliations.rst
.. include:: tips/migration3.rst
.. include:: tips/rename.rst
.. include:: tips/migration1.rst
