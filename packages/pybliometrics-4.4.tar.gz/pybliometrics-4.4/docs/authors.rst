.. include:: ../meta/AUTHORS.rst
