# Check It Out (CzekItOut)

[![Test library](https://github.com/mrfitzpa/czekitout/actions/workflows/test_library.yml/badge.svg)](https://github.com/mrfitzpa/czekitout/actions/workflows/test_library.yml)
[![Code Coverage](https://img.shields.io/endpoint?url=https://gist.githubusercontent.com/mrfitzpa/03df7baa137bcac859f4cb8927a62a23/raw/czekitout_coverage_badge.json)](https://github.com/mrfitzpa/czekitout/actions/workflows/measure_code_coverage.yml)
[![Documentation](https://img.shields.io/badge/docs-read-brightgreen)](https://mrfitzpa.github.io/czekitout)
[![PyPi Version](https://img.shields.io/pypi/v/czekitout.svg)](https://pypi.org/project/czekitout)
[![Conda-Forge Version](https://img.shields.io/conda/vn/conda-forge/czekitout.svg)](https://anaconda.org/conda-forge/czekitout)
[![License](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)

`czekitout` is a Python library that contains a collection of functions that
facilitate validation, and type-conversions, with useful error messages when
exceptions are thrown.

Visit the `czekitout` [website](https://mrfitzpa.github.io/czekitout) for a web
version of the installation instructions, the reference guide, and the examples
archive.

The source code can be found in the [`czekitout` GitHub
repository](https://github.com/mrfitzpa/czekitout).



## Table of contents

- [Instructions for installing and uninstalling
  `czekitout`](#instructions-for-installing-and-uninstalling-czekitout)
  - [Installing `czekitout`](#installing-czekitout)
    - [Installing `czekitout` using
      `pip`](#installing-czekitout-using-pip)
    - [Installing `czekitout` using
      `conda`](#installing-czekitout-using-conda)
  - [Uninstalling `czekitout`](#uninstalling-czekitout)
- [Learning how to use `czekitout`](#learning-how-to-use-czekitout)



## Instructions for installing and uninstalling `czekitout`



### Installing `czekitout`

For all installation scenarios, first open up the appropriate command line
interface. On Unix-based systems, you could open e.g. a terminal. On Windows
systems you could open e.g. an Anaconda Prompt as an administrator.



#### Installing `czekitout` using `pip`

Before installing `czekitout`, make sure that you have activated the (virtual)
environment in which you intend to install said package. After which, simply run
the following command:

    pip install czekitout

The above command will install the latest stable version of `czekitout`.

To install the latest development version from the main branch of the [czekitout
GitHub repository](https://github.com/mrfitzpa/czekitout), one must first clone
the repository by running the following command:

    git clone https://github.com/mrfitzpa/czekitout.git

Next, change into the root of the cloned repository, and then run the following
command:

    pip install .

Note that you must include the period as well. The above command executes a
standard installation of `czekitout`.

Optionally, for additional features in `czekitout`, one can install additional
dependencies upon installing `czekitout`. To install a subset of additional
dependencies (along with the standard installation), run the following command
from the root of the repository:

    pip install .[<selector>]

where `<selector>` can be one of the following:

* `tests`: to install the dependencies necessary for running unit tests;
* `examples`: to install the dependencies necessary for executing files stored
  in `<root>/examples`, where `<root>` is the root of the repository;
* `docs`: to install the dependencies necessary for documentation generation;
* `all`: to install all of the above optional dependencies.

Alternatively, one can run:

    pip install czekitout[<selector>]

elsewhere in order to install the latest stable version of `czekitout`, along
with the subset of additional dependencies specified by `<selector>`.



#### Installing `czekitout` using `conda`

To install `czekitout` using the `conda` package manager, run the following
command:

    conda install -c conda-forge czekitout

The above command will install the latest stable version of `czekitout`.



### Uninstalling `czekitout`

If `czekitout` was installed using `pip`, then to uninstall, run the following
command:

    pip uninstall czekitout

If `czekitout` was installed using `conda`, then to uninstall, run the following
command:

    conda remove czekitout



## Learning how to use `czekitout`

For those new to the `czekitout` library, it is recommended that they take a
look at the [Examples](https://mrfitzpa.github.io/czekitout/examples.html) page,
which contain code examples that show how one can use the `czekitout`
library. While going through the examples, readers can consult the [czekitout
reference
guide](https://mrfitzpa.github.io/czekitout/_autosummary/czekitout.html) to
understand what each line of code is doing.