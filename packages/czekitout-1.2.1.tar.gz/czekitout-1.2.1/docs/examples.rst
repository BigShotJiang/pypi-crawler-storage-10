.. _examples_sec:

Examples
========

You can find examples of using the ``czekitout`` library in a series of
notebooks found in the directory ``<root>/examples`` of the ``czekitout``
repository, where ``<root>`` is the root of the repository. You can find the
repository `here <https://github.com/mrfitzpa/czekitout>`_.
