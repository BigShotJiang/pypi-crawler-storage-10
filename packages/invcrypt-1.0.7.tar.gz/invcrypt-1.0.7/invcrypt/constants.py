# === Globala suffixkonstanter ===
SUFFIX_ENCRYPTED = ".invx"
SUFFIX_DECRYPTED = ".decrypted"
SUFFIX_LEGACY = ".enc"
