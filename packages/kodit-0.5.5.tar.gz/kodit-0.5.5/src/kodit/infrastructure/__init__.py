"""Infrastructure layer."""
