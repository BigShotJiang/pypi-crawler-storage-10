"""Architecture enrichment package."""
