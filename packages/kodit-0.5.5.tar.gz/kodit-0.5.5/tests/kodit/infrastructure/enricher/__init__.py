"""Tests for enricher implementations."""
