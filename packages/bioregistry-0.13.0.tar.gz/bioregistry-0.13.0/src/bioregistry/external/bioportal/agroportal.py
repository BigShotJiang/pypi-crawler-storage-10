"""Align the AgroPortal with the Bioregistry."""

from .bioportal import AgroPortalAligner

if __name__ == "__main__":
    AgroPortalAligner.cli()
