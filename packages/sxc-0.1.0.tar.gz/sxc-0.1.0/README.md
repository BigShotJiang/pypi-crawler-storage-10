# sxc -- Xavier's ready Python Package

A lightweight and modular machine learning toolkit that simplifies model training, evaluation, and visualization. Designed to handle both numerical and categorical data gracefully, sxc provides ready-to-use wrappers for popular supervised and unsupervised algorithms.

> Train smarter. Deploy faster. Keep your code elegant.

---

## Features

- Automatic preprocessing support (handling categorical and numerical features)
- Classification and regression with:
  - Random Forest
  - Bagging Models
  - Decision Trees
  - K-Nearest Neighbors
  - Naive Bayes
  - Support Vector Machines
- Unsupervised learning with K-Means clustering
- Built-in evaluation metrics and plots
- Easy-to-use API with minimal configuration

---

## Installation

Once published on PyPI:

```bash
pip install sxc