import pkgutil
import inspect
import importlib
import pandas as pd
import sxc.mdts as mdts_pkg


def indexing():
    """
    Generate a DataFrame of all functions available in sxc.mdts module
    along with their short descriptions from docstrings.

    This scans each module under sxc.mdts and collects all user-defined
    functions (excluding private or imported functions).
    """

    records = []
    package_path = mdts_pkg.__path__

    for _, module_name, is_pkg in pkgutil.iter_modules(package_path):
        if is_pkg:
            continue

        module = importlib.import_module(f"sxc.mdts.{module_name}")

        for name, obj in inspect.getmembers(module, inspect.isfunction):
            if not name.startswith("_") and obj.__module__.startswith("sxc.mdts"):
                doc = inspect.getdoc(obj)
                short_desc = doc.split("\n")[0] if doc else "No description available"
                
                records.append({
                    "Function": name,
                    "Description": short_desc
                })

    df = pd.DataFrame(records).sort_values(by="Function").reset_index(drop=True)

    if df.empty:
        print("No functions found in sxc.mdts")
        return df
    return df
