===========================
Manuscript
===========================

This subdirectory contains a manuscript (`paper.md <paper.md>`_) for submitting the ``alignparse`` Python package to `The Journal of Open Source Software <https://joss.theoj.org/>`_.
References are in `paper.bib <paper.bib>`_.
The paper is formatted according to the `submission instructions here <https://joss.readthedocs.io/en/latest/submitting.html>`_.
