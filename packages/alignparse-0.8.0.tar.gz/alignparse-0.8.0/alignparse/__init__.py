"""
================================
alignparse
================================

"""

__author__ = "`the Bloom lab <https://jbloomlab.org/>`_"
__email__ = "jbloom@fredhutch.org"
__version__ = "0.8.0"
__url__ = "https://github.com/jbloomlab/alignparse"
