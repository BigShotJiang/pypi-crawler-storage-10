=================
Jupyter notebooks
=================
`Jupyter notebooks`_ demonstrating use of the package.

These are tested against their current results using nbval_.


.. _`Jupyter notebooks`: https://jupyter.org/
.. _nbval: https://nbval.readthedocs.io
