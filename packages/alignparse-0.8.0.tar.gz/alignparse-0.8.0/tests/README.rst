============
tests
============

Tests go here.
They can be run via calling ``pytest`` in the top package directory.
