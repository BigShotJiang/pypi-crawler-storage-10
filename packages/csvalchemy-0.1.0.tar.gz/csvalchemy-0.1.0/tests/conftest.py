"""Pytest fixtures for csvalchemy tests."""

import pytest
from datetime import datetime
from typing import Optional
from pydantic import BaseModel


class PersonModel(BaseModel):
    """Sample Pydantic model for testing."""

    name: str
    age: int
    email: Optional[str] = None


class ProductModel(BaseModel):
    """Sample Pydantic model with various types."""

    id: int
    name: str
    price: float
    in_stock: bool
    created_at: Optional[datetime] = None


@pytest.fixture
def person_model():
    """Fixture providing PersonModel class."""
    return PersonModel


@pytest.fixture
def product_model():
    """Fixture providing ProductModel class."""
    return ProductModel


@pytest.fixture
def sample_person_data():
    """Sample valid person data."""
    return {"name": "Alice", "age": "30", "email": "alice@example.com"}


@pytest.fixture
def sample_people_data():
    """Sample list of person data."""
    return [
        {"name": "Alice", "age": "30", "email": "alice@example.com"},
        {"name": "Bob", "age": "25", "email": "bob@example.com"},
        {"name": "Charlie", "age": "35", "email": None},
    ]


@pytest.fixture
def sample_csv_content():
    """Sample CSV content as string."""
    return "name,age,email\nAlice,30,alice@example.com\nBob,25,bob@example.com\n"


@pytest.fixture
def sample_csv_file(tmp_path, sample_csv_content):
    """Create a temporary CSV file."""
    csv_file = tmp_path / "test.csv"
    csv_file.write_text(sample_csv_content)
    return csv_file


@pytest.fixture
def empty_csv_file(tmp_path):
    """Create an empty CSV file."""
    csv_file = tmp_path / "empty.csv"
    csv_file.write_text("name,age,email\n")
    return csv_file


@pytest.fixture
def invalid_csv_content():
    """Sample CSV with invalid data."""
    return "name,age,email\nAlice,not_a_number,alice@example.com\nBob,25,\n"
