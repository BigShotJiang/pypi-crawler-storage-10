"""Integration tests for csvalchemy package."""

from io import StringIO
from datetime import datetime
from typing import Optional
from pydantic import BaseModel

from csvalchemy import read


class ProductModel(BaseModel):
    """Test model for integration tests."""

    id: int
    name: str
    price: float
    in_stock: bool
    created_at: Optional[datetime] = None


class TestFullPipeline:
    """Tests for complete read -> validate -> write pipeline."""

    def test_read_validate_write_round_trip(self):
        """Test complete round-trip: read CSV, validate, write CSV."""
        # Read phase
        input_csv = "id,name,price,in_stock,created_at\n1,Widget,19.99,True,2023-01-01\n2,Gadget,29.99,False,2023-02-01\n"
        input_file = StringIO(input_csv)

        validator = read(input_file, ProductModel)
        results = list(validator)

        # Validate results
        assert len(results) == 2
        assert all(r.error is None for r in results)
        assert results[0].result.id == 1
        assert results[0].result.name == "Widget"
        assert results[1].result.id == 2

        # Write phase
        output_file = StringIO()

        # Need to recreate validator since iterator was consumed
        input_file2 = StringIO(input_csv)
        validator2 = read(input_file2, ProductModel)
        writer2 = validator2.csv_writer(output_file)

        # Consume writer to trigger CSV writing
        written_results = list(writer2)

        assert len(written_results) == 2
        output_file.seek(0)
        output_content = output_file.read()

        # Verify output CSV structure
        assert "id" in output_content
        assert "Widget" in output_content
        assert "Gadget" in output_content

    def test_mixed_valid_invalid_rows(self):
        """Test pipeline with mix of valid and invalid rows."""
        csv_content = "id,name,price,in_stock\n1,Widget,19.99,True\n2,Invalid,not_a_number,True\n3,Gadget,29.99,False\n"
        csv_file = StringIO(csv_content)
        validator = read(csv_file, ProductModel)

        results = list(validator)

        assert len(results) == 3
        assert results[0].error is None  # Valid
        assert results[1].error is not None  # Invalid (price)
        assert results[2].error is None  # Valid

        # Test writing - should only write valid rows
        output_file = StringIO()
        csv_file2 = StringIO(csv_content)
        validator2 = read(csv_file2, ProductModel)
        writer = validator2.csv_writer(output_file)
        list(writer)

        output_file.seek(0)
        content = output_file.read()
        assert "Widget" in content
        assert "Invalid" not in content  # Invalid row should be skipped
        assert "Gadget" in content

    def test_large_csv_performance(self):
        """Test handling of larger CSV files."""
        # Generate 100 rows
        header = "id,name,price,in_stock\n"
        rows = [f"{i},Product{i},{10.0 + i},True\n" for i in range(100)]
        csv_content = header + "".join(rows)

        csv_file = StringIO(csv_content)
        validator = read(csv_file, ProductModel)

        results = list(validator)

        assert len(results) == 100
        assert all(r.error is None for r in results)

    def test_csv_with_special_characters(self):
        """Test CSV with special characters and UTF-8."""
        csv_content = "id,name,price,in_stock\n1,Café,19.99,True\n2,商品,29.99,True\n"
        csv_file = StringIO(csv_content)
        validator = read(csv_file, ProductModel)

        results = list(validator)

        assert len(results) == 2
        assert results[0].error is None
        assert results[0].result.name == "Café"
        assert results[1].error is None
        assert results[1].result.name == "商品"

        # Test writing back
        output_file = StringIO()
        csv_file2 = StringIO(csv_content)
        validator2 = read(csv_file2, ProductModel)
        writer = validator2.csv_writer(output_file)
        list(writer)

        output_file.seek(0)
        content = output_file.read()
        assert "Café" in content
        assert "商品" in content

    def test_empty_csv_file(self):
        """Test handling of completely empty CSV."""
        csv_content = ""
        csv_file = StringIO(csv_content)

        # Empty CSV should raise an error or handle gracefully
        # DictReader on empty string should just have no rows
        validator = read(csv_file, ProductModel)
        results = list(validator)

        assert len(results) == 0

    def test_csv_with_only_headers(self):
        """Test CSV with headers but no data rows."""
        csv_content = "id,name,price,in_stock\n"
        csv_file = StringIO(csv_content)
        validator = read(csv_file, ProductModel)

        results = list(validator)
        assert len(results) == 0
