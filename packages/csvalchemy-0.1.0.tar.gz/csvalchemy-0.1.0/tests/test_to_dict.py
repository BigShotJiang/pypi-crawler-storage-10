"""Tests for to_dict.py module."""

import pytest
from typing import NamedTuple
from dataclasses import dataclass
from pydantic import BaseModel

from csvalchemy.to_dict import data_to_dict


class TestPydanticModel:
    """Tests for Pydantic BaseModel conversion."""

    class PersonModel(BaseModel):
        """Test Pydantic model."""

        name: str
        age: int

    def test_pydantic_model_to_dict(self):
        """Test converting Pydantic model to dict."""
        person = self.PersonModel(name="Alice", age=30)
        result = data_to_dict(person)
        assert isinstance(result, dict)
        assert result["name"] == "Alice"
        assert result["age"] == 30

    def test_pydantic_model_with_none(self):
        """Test Pydantic model with optional None field."""

        class PersonOptional(BaseModel):
            name: str
            age: int | None = None

        person = PersonOptional(name="Alice")
        result = data_to_dict(person)
        assert result["name"] == "Alice"
        assert result["age"] is None


class TestNamedTuple:
    """Tests for NamedTuple conversion."""

    class PersonTuple(NamedTuple):
        """Test NamedTuple."""

        name: str
        age: int

    def test_named_tuple_to_dict(self):
        """Test converting NamedTuple to dict."""
        person = self.PersonTuple(name="Alice", age=30)
        result = data_to_dict(person)
        assert isinstance(result, dict)
        assert result["name"] == "Alice"
        assert result["age"] == 30

    def test_regular_tuple_raises_error(self):
        """Test that regular tuples raise TypeError."""
        regular_tuple = ("Alice", 30)
        with pytest.raises(TypeError, match="regular tuple"):
            data_to_dict(regular_tuple)


class TestDict:
    """Tests for dict/Mapping conversion."""

    def test_dict_to_dict(self):
        """Test converting dict to dict (identity)."""
        data = {"name": "Alice", "age": 30}
        result = data_to_dict(data)
        assert result == data
        assert result is not data  # Should be a copy

    def test_dict_with_nested_values(self):
        """Test dict with nested structures."""
        data = {"name": "Alice", "details": {"age": 30, "city": "NYC"}}
        result = data_to_dict(data)
        assert result["name"] == "Alice"
        assert result["details"]["age"] == 30


class TestDataclass:
    """Tests for dataclass conversion."""

    @dataclass
    class PersonDataclass:
        """Test dataclass."""

        name: str
        age: int

    def test_dataclass_to_dict(self):
        """Test converting dataclass to dict."""
        person = self.PersonDataclass(name="Alice", age=30)
        result = data_to_dict(person)
        assert isinstance(result, dict)
        assert result["name"] == "Alice"
        assert result["age"] == 30

    @dataclass
    class PersonOptionalDataclass:
        """Test dataclass with optional field."""

        name: str
        age: int | None = None

    def test_dataclass_with_none(self):
        """Test dataclass with None value."""
        person = self.PersonOptionalDataclass(name="Alice")
        result = data_to_dict(person)
        assert result["name"] == "Alice"
        assert result["age"] is None
