"""Tests for reader.py module."""

import pytest
from io import StringIO
from pydantic import BaseModel

from csvalchemy.reader import read, CSVReaderValidator


class PersonModel(BaseModel):
    """Test Pydantic model."""

    name: str
    age: int
    email: str | None = None


class TestCSVReaderValidator:
    """Tests for CSVReaderValidator class."""

    def test_read_valid_csv(self):
        """Test reading a valid CSV file."""
        csv_content = (
            "name,age,email\nAlice,30,alice@example.com\nBob,25,bob@example.com\n"
        )
        csv_file = StringIO(csv_content)
        validator = CSVReaderValidator(csv_file, PersonModel)

        results = list(validator)
        assert len(results) == 2
        assert all(r.error is None for r in results)
        assert results[0].result.name == "Alice"
        assert results[0].result.age == 30
        assert results[1].result.name == "Bob"
        assert results[1].result.age == 25

    def test_read_empty_csv(self):
        """Test reading CSV with only headers."""
        csv_content = "name,age,email\n"
        csv_file = StringIO(csv_content)
        validator = CSVReaderValidator(csv_file, PersonModel)

        results = list(validator)
        assert len(results) == 0

    def test_read_csv_with_missing_columns(self):
        """Test CSV with missing columns (handled by Pydantic)."""
        csv_content = "name,age\nAlice,30\n"
        csv_file = StringIO(csv_content)
        validator = CSVReaderValidator(csv_file, PersonModel)

        results = list(validator)
        assert len(results) == 1
        # Email is optional, so this should succeed
        assert results[0].error is None
        assert results[0].result.email is None

    def test_read_csv_with_extra_columns(self):
        """Test CSV with extra columns not in model."""
        csv_content = (
            "name,age,email,extra_column\nAlice,30,alice@example.com,extra_value\n"
        )
        csv_file = StringIO(csv_content)
        validator = CSVReaderValidator(csv_file, PersonModel)

        results = list(validator)
        # Pydantic should ignore extra fields by default
        assert len(results) == 1
        assert results[0].error is None

    def test_read_csv_with_invalid_data(self):
        """Test CSV with invalid data types."""
        csv_content = "name,age,email\nAlice,not_a_number,alice@example.com\n"
        csv_file = StringIO(csv_content)
        validator = CSVReaderValidator(csv_file, PersonModel)

        results = list(validator)
        assert len(results) == 1
        assert results[0].error is not None

    def test_read_csv_with_invalid_file_object(self):
        """Test validation of file handle."""
        with pytest.raises(TypeError, match="file-like object"):
            CSVReaderValidator("not_a_file", PersonModel)


class TestReadFunction:
    """Tests for read() convenience function."""

    def test_read_function(self):
        """Test read() convenience function."""
        csv_content = "name,age,email\nAlice,30,alice@example.com\n"
        csv_file = StringIO(csv_content)
        validator = read(csv_file, PersonModel)

        assert isinstance(validator, CSVReaderValidator)
        results = list(validator)
        assert len(results) == 1
        assert results[0].error is None

    def test_read_function_with_empty_csv(self):
        """Test read() with empty CSV."""
        csv_content = "name,age,email\n"
        csv_file = StringIO(csv_content)
        validator = read(csv_file, PersonModel)

        results = list(validator)
        assert len(results) == 0

    def test_read_function_multiple_rows(self):
        """Test read() with multiple rows."""
        csv_content = "name,age,email\nAlice,30,alice@example.com\nBob,25,bob@example.com\nCharlie,35,charlie@example.com\n"
        csv_file = StringIO(csv_content)
        validator = read(csv_file, PersonModel)

        results = list(validator)
        assert len(results) == 3
        assert all(r.error is None for r in results)
