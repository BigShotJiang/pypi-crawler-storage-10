"""Tests for result.py module."""

import pytest
from pydantic import BaseModel

from csvalchemy.result import Result


class PersonModel(BaseModel):
    """Test model."""

    name: str
    age: int


class TestResult:
    """Tests for Result NamedTuple."""

    def test_result_creation_with_error(self):
        """Test creating Result with an error."""
        error = ValueError("Invalid data")
        result = Result(error=error, result=None, value={"name": "Alice"})
        assert result.error == error
        assert result.result is None
        assert result.value == {"name": "Alice"}

    def test_result_creation_with_success(self):
        """Test creating Result with successful validation."""
        person = PersonModel(name="Alice", age=30)
        result = Result(error=None, result=person, value={"name": "Alice", "age": "30"})
        assert result.error is None
        assert result.result == person
        assert isinstance(result.result, PersonModel)
        assert result.value == {"name": "Alice", "age": "30"}

    def test_result_unpacking(self):
        """Test that Result can be unpacked."""
        error = ValueError("Invalid")
        result = Result(error=error, result=None, value={})
        error_val, result_val, value_val = result
        assert error_val == error
        assert result_val is None
        assert value_val == {}

    def test_result_immutability(self):
        """Test that Result is immutable."""
        result = Result(error=None, result=None, value={})
        with pytest.raises(AttributeError):
            result.error = ValueError("New error")

    def test_result_with_none_values(self):
        """Test Result with various None combinations."""
        result1 = Result(error=None, result=None, value=None)
        assert result1.error is None
        assert result1.result is None
        assert result1.value is None

    def test_result_truthiness(self):
        """Test Result behavior in boolean context."""
        # Result itself is always truthy (it's a tuple)
        error_result = Result(error=ValueError("error"), result=None, value={})
        success_result = Result(
            error=None, result=PersonModel(name="A", age=1), value={}
        )

        assert error_result is not None
        assert success_result is not None
        # Check error field truthiness
        assert error_result.error is not None
        assert success_result.error is None
