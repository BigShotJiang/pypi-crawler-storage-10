"""Tests for validator.py module."""

from pydantic import BaseModel
import dydactic.options  # type: ignore[import-untyped]

from csvalchemy.validator import Validator, ValidatorIterator
from csvalchemy.result import Result


class PersonModel(BaseModel):
    """Test Pydantic model."""

    name: str
    age: int
    email: str | None = None


class TestValidatorIterator:
    """Tests for ValidatorIterator."""

    def test_iterator_validates_valid_data(self):
        """Test iterator with valid data."""
        data = [
            {"name": "Alice", "age": "30", "email": "alice@example.com"},
            {"name": "Bob", "age": "25", "email": "bob@example.com"},
        ]
        iterator = ValidatorIterator(iter(data), PersonModel)
        results = list(iterator)

        assert len(results) == 2
        assert all(isinstance(r, Result) for r in results)
        assert all(r.error is None for r in results)
        assert all(r.result is not None for r in results)
        assert results[0].result.name == "Alice"
        assert results[0].result.age == 30  # Should be cast to int
        assert results[1].result.name == "Bob"

    def test_iterator_handles_invalid_data(self):
        """Test iterator with invalid data."""
        data = [
            {"name": "Alice", "age": "not_a_number", "email": "alice@example.com"},
            {"name": "Bob", "age": "25", "email": "bob@example.com"},
        ]
        iterator = ValidatorIterator(iter(data), PersonModel)
        results = list(iterator)

        assert len(results) == 2
        assert results[0].error is not None  # First row has error
        assert results[0].result is None
        assert results[1].error is None  # Second row is valid
        assert results[1].result is not None

    def test_iterator_with_empty_data(self):
        """Test iterator with empty data."""
        data = []
        iterator = ValidatorIterator(iter(data), PersonModel)
        results = list(iterator)
        assert len(results) == 0

    def test_iterator_is_consumable_once(self):
        """Test that iterator can only be consumed once."""
        data = [{"name": "Alice", "age": "30"}]
        iterator = ValidatorIterator(iter(data), PersonModel)

        # Consume once
        results1 = list(iterator)
        assert len(results1) == 1

        # Trying to consume again should be empty
        results2 = list(iterator)
        assert len(results2) == 0


class TestValidator:
    """Tests for Validator class."""

    def test_validator_iteration(self):
        """Test iterating over Validator."""
        data = [
            {"name": "Alice", "age": "30"},
            {"name": "Bob", "age": "25"},
        ]
        validator = Validator(iter(data), PersonModel)
        results = list(validator)

        assert len(results) == 2
        assert all(r.error is None for r in results)

    def test_validator_multiple_iterations(self):
        """Test that Validator creates new iterator each time."""
        data = [
            {"name": "Alice", "age": "30"},
            {"name": "Bob", "age": "25"},
        ]
        validator = Validator(iter(data), PersonModel)

        # First iteration
        results1 = list(validator)
        assert len(results1) == 2

        # Note: Since data is already consumed, second iteration may be empty
        # unless validator creates a new iterator from fresh data
        # This depends on implementation - testing current behavior

    def test_validator_csv_writer_method(self):
        """Test csv_writer method returns ResultsCSVWriter."""
        from csvalchemy.writer import ResultsCSVWriter
        from io import StringIO

        data = [{"name": "Alice", "age": "30"}]
        validator = Validator(iter(data), PersonModel)
        csv_file = StringIO()

        writer = validator.csv_writer(csv_file)
        assert isinstance(writer, ResultsCSVWriter)

    def test_validator_mixed_valid_invalid(self):
        """Test validator with mix of valid and invalid rows."""
        data = [
            {"name": "Alice", "age": "30"},  # Valid
            {"name": "Bob", "age": "not_a_number"},  # Invalid
            {"name": "Charlie", "age": "35"},  # Valid
        ]
        validator = Validator(iter(data), PersonModel)
        results = list(validator)

        assert len(results) == 3
        assert results[0].error is None
        assert results[1].error is not None
        assert results[2].error is None

    def test_validator_missing_required_fields(self):
        """Test validator with missing required fields."""
        data = [
            {"name": "Alice"},  # Missing age
        ]
        validator = Validator(iter(data), PersonModel)
        results = list(validator)

        assert len(results) == 1
        assert results[0].error is not None

    def test_validator_error_option_skip(self):
        """Test validator with SKIP error option."""
        data = [
            {"name": "Alice", "age": "30"},  # Valid
            {"name": "Bob", "age": "not_a_number"},  # Invalid - should be skipped
            {"name": "Charlie", "age": "35"},  # Valid
        ]
        validator = Validator(
            iter(data), PersonModel, error_option=dydactic.options.ErrorOption.SKIP
        )
        results = list(validator)

        # Should only have 2 results (invalid one skipped)
        assert len(results) == 2
        assert all(r.error is None for r in results)
        assert results[0].result.name == "Alice"
        assert results[1].result.name == "Charlie"

    def test_validator_error_option_return(self):
        """Test validator with RETURN error option (default)."""
        data = [
            {"name": "Alice", "age": "30"},  # Valid
            {"name": "Bob", "age": "not_a_number"},  # Invalid
        ]
        validator = Validator(
            iter(data), PersonModel, error_option=dydactic.options.ErrorOption.RETURN
        )
        results = list(validator)

        assert len(results) == 2
        assert results[0].error is None
        assert results[1].error is not None

    def test_validator_strict_mode(self):
        """Test validator with strict validation."""
        data = [
            {"name": "Alice", "age": 30},  # Valid (int already)
            {"name": "Bob", "age": "25"},  # String - strict might reject
        ]
        validator = Validator(iter(data), PersonModel, strict=False)
        results = list(validator)

        # Strict=False should allow type coercion
        assert len(results) == 2
        assert all(r.error is None for r in results)

    def test_validator_passes_config_to_iterator(self):
        """Test that Validator passes configuration to ValidatorIterator."""
        data = [{"name": "Alice", "age": "30"}]
        validator = Validator(
            iter(data),
            PersonModel,
            error_option=dydactic.options.ErrorOption.SKIP,
            strict=True,
            from_attributes=False,
        )

        iterator = iter(validator)
        # Verify iterator has the correct configuration
        assert iterator.error_option == dydactic.options.ErrorOption.SKIP
        assert iterator.strict is True
        assert iterator.from_attributes is False

    def test_validator_iterator_configuration(self):
        """Test ValidatorIterator with different configurations."""
        data = [
            {"name": "Alice", "age": "30"},
            {"name": "Bob", "age": "not_a_number"},
        ]

        # Test SKIP option
        iterator_skip = ValidatorIterator(
            iter(data), PersonModel, error_option=dydactic.options.ErrorOption.SKIP
        )
        results_skip = list(iterator_skip)
        assert len(results_skip) == 1  # Invalid one skipped

        # Test RETURN option
        iterator_return = ValidatorIterator(
            iter(data), PersonModel, error_option=dydactic.options.ErrorOption.RETURN
        )
        results_return = list(iterator_return)
        assert len(results_return) == 2  # Both returned
        assert results_return[1].error is not None
