"""Tests for cast.py module."""

import pytest
from datetime import datetime
from typing import Union

from csvalchemy.cast import (
    cast_as,
    cast_as_union,
    cast_as_annotation,
    cls_annotations,
    cast_to_annotated_class,
    ValidationError,
)


class TestCastAs:
    """Tests for cast_as function."""

    def test_cast_string_to_int(self):
        """Test casting string to int."""
        assert cast_as("42", int) == 42

    def test_cast_string_to_float(self):
        """Test casting string to float."""
        assert cast_as("3.14", float) == 3.14

    def test_cast_string_to_bool(self):
        """Test casting string to bool."""
        assert cast_as("True", bool) is True
        assert cast_as("False", bool) is False

    def test_cast_already_correct_type(self):
        """Test that already correct types are returned as-is."""
        assert cast_as(42, int) == 42
        assert cast_as("hello", str) == "hello"

    def test_cast_string_to_datetime(self):
        """Test casting string to datetime."""
        dt = cast_as("2023-01-01", datetime)
        assert isinstance(dt, datetime)
        assert dt.year == 2023
        assert dt.month == 1
        assert dt.day == 1

    def test_cast_datetime_string_various_formats(self):
        """Test datetime parsing with various formats."""
        formats = [
            "2023-01-01",
            "2023-01-01T12:00:00",
            "2023-01-01 12:00:00",
            "01/01/2023",
        ]
        for fmt in formats:
            dt = cast_as(fmt, datetime)
            assert isinstance(dt, datetime)

    def test_cast_datetime_none_value(self):
        """Test handling None for datetime."""
        assert cast_as(None, datetime) is None

    def test_cast_datetime_empty_string(self):
        """Test handling empty string for datetime."""
        assert cast_as("", datetime) is None

    def test_cast_invalid_type_raises_error(self):
        """Test that invalid casts raise errors."""
        with pytest.raises(ValueError):
            cast_as("not_a_number", int)


class TestCastAsUnion:
    """Tests for cast_as_union function."""

    def test_cast_union_int_or_str_with_int(self):
        """Test Union[int, str] with integer value."""
        union_type = Union[int, str]
        result = cast_as_union("42", union_type)
        assert result == 42
        assert isinstance(result, int)

    def test_cast_union_int_or_str_with_str(self):
        """Test Union[int, str] with string value."""
        union_type = Union[int, str]
        result = cast_as_union("hello", union_type)
        assert result == "hello"
        assert isinstance(result, str)

    def test_cast_union_type_order_matters(self):
        """Test that Union type order affects casting."""
        union_type1 = Union[int, str]
        union_type2 = Union[str, int]
        # Both should work, but order may affect which is tried first
        assert cast_as_union("42", union_type1) == 42
        assert cast_as_union("42", union_type2) == 42

    def test_cast_union_no_match_raises_error(self):
        """Test that Union with no matching type raises TypeError."""
        union_type = Union[float, bool]
        with pytest.raises(TypeError, match="Failed to cast value"):
            cast_as_union("hello", union_type)

    def test_cast_union_with_datetime(self):
        """Test Union with datetime."""
        union_type = Union[datetime, str]
        result = cast_as_union("2023-01-01", union_type)
        assert isinstance(result, datetime)


class TestCastAsAnnotation:
    """Tests for cast_as_annotation function."""

    def test_cast_regular_type(self):
        """Test casting with regular type annotation."""
        assert cast_as_annotation("42", int) == 42

    def test_cast_union_type(self):
        """Test casting with Union type annotation."""
        union_type = Union[int, str]
        assert cast_as_annotation("42", union_type) == 42
        assert cast_as_annotation("hello", union_type) == "hello"

    def test_cast_datetime_annotation(self):
        """Test casting with datetime annotation."""
        dt = cast_as_annotation("2023-01-01", datetime)
        assert isinstance(dt, datetime)


class TestClsAnnotations:
    """Tests for cls_annotations function."""

    class TestClass:
        """Test class with annotations."""

        name: str
        age: int

    class TestClassNoAnnotations:
        """Test class without annotations."""

        pass

    def test_get_annotations_from_class(self):
        """Test getting annotations from a class."""
        annotations = cls_annotations(self.TestClass)
        assert "name" in annotations
        assert "age" in annotations
        assert annotations["name"] is str
        assert annotations["age"] is int

    def test_class_without_annotations(self):
        """Test class without annotations returns empty dict."""
        annotations = cls_annotations(self.TestClassNoAnnotations)
        assert annotations == {}


class TestCastToAnnotatedClass:
    """Tests for cast_to_annotated_class function."""

    class Person:
        """Test class for casting."""

        name: str
        age: int

        def __init__(self, name: str, age: int):
            self.name = name
            self.age = age

    def test_cast_valid_data(self):
        """Test casting valid data to annotated class."""
        data = {"name": "Alice", "age": "30"}
        person = cast_to_annotated_class(data, self.Person)
        assert person.name == "Alice"
        assert person.age == 30
        assert isinstance(person.age, int)

    def test_cast_invalid_type_raises_error(self):
        """Test that invalid types raise ValidationError."""
        data = {"name": "Alice", "age": "not_a_number"}
        with pytest.raises(ValidationError) as exc_info:
            cast_to_annotated_class(data, self.Person)
        errors = exc_info.value.args[0]
        assert "age" in errors
        assert errors["age"]["type"] is int

    def test_cast_missing_key_in_annotations_ignored(self):
        """Test that extra keys not in annotations are ignored."""
        data = {"name": "Alice", "age": "30", "extra": "ignored"}
        person = cast_to_annotated_class(data, self.Person)
        assert person.name == "Alice"
        assert person.age == 30

    def test_cast_missing_required_field(self):
        """Test casting with missing required field."""
        data = {"name": "Alice"}  # Missing age
        with pytest.raises(TypeError):
            # This will fail at instantiation because age is missing
            cast_to_annotated_class(data, self.Person)
