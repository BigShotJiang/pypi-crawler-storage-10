"""Tests for writer.py module."""

from io import StringIO
from pydantic import BaseModel

from csvalchemy.writer import ResultsCSVWriter, ResultsCSVWriterIterator
from csvalchemy.result import Result


class PersonModel(BaseModel):
    """Test Pydantic model."""

    name: str
    age: int
    email: str | None = None


class TestResultsCSVWriterIterator:
    """Tests for ResultsCSVWriterIterator."""

    def test_write_valid_results(self):
        """Test writing valid results to CSV."""
        csv_file = StringIO()
        results = [
            Result(error=None, result=PersonModel(name="Alice", age=30), value={}),
            Result(error=None, result=PersonModel(name="Bob", age=25), value={}),
        ]
        writer_iter = ResultsCSVWriterIterator(iter(results), csv_file)

        # Consume iterator
        written_results = list(writer_iter)

        assert len(written_results) == 2
        csv_file.seek(0)
        content = csv_file.read()

        # Check headers are written
        assert "name" in content
        assert "age" in content
        assert "email" in content
        # Check data rows
        assert "Alice" in content
        assert "30" in content
        assert "Bob" in content
        assert "25" in content

    def test_skip_results_with_errors(self):
        """Test that results with errors are skipped."""
        csv_file = StringIO()
        results = [
            Result(error=ValueError("Invalid"), result=None, value={}),
            Result(error=None, result=PersonModel(name="Alice", age=30), value={}),
        ]
        writer_iter = ResultsCSVWriterIterator(iter(results), csv_file)

        written_results = list(writer_iter)

        assert len(written_results) == 2
        csv_file.seek(0)
        content = csv_file.read()

        # Should only have Alice, not the error row
        assert "Alice" in content
        assert "30" in content

    def test_header_written_on_first_valid_row(self):
        """Test that headers are written on first valid result."""
        csv_file = StringIO()
        results = [
            Result(error=ValueError("Invalid"), result=None, value={}),
            Result(error=None, result=PersonModel(name="Alice", age=30), value={}),
        ]
        writer_iter = ResultsCSVWriterIterator(iter(results), csv_file)
        list(writer_iter)

        csv_file.seek(0)
        lines = csv_file.readlines()

        # First line should be headers
        assert "name" in lines[0]
        assert "age" in lines[0]

    def test_empty_results_iterator(self):
        """Test with empty results iterator."""
        csv_file = StringIO()
        results = []
        writer_iter = ResultsCSVWriterIterator(iter(results), csv_file)

        written_results = list(writer_iter)
        assert len(written_results) == 0
        assert csv_file.getvalue() == ""

    def test_results_with_none_result_values(self):
        """Test handling results with None result values."""
        csv_file = StringIO()
        results = [
            Result(error=None, result=None, value={}),
        ]
        writer_iter = ResultsCSVWriterIterator(iter(results), csv_file)

        written_results = list(writer_iter)
        assert len(written_results) == 1
        # Headers should not be written if all results have None result values
        assert csv_file.getvalue() == ""


class TestResultsCSVWriter:
    """Tests for ResultsCSVWriter class."""

    def test_writer_iteration(self):
        """Test iterating over ResultsCSVWriter."""
        csv_file = StringIO()
        results = [
            Result(error=None, result=PersonModel(name="Alice", age=30), value={}),
            Result(error=None, result=PersonModel(name="Bob", age=25), value={}),
        ]
        writer = ResultsCSVWriter(iter(results), csv_file)

        # Iterate over writer
        written_results = list(writer)

        assert len(written_results) == 2
        csv_file.seek(0)
        content = csv_file.read()
        assert "Alice" in content
        assert "Bob" in content

    def test_writer_creates_iterator(self):
        """Test that __iter__ returns ResultsCSVWriterIterator."""
        csv_file = StringIO()
        results = [
            Result(error=None, result=PersonModel(name="Alice", age=30), value={})
        ]
        writer = ResultsCSVWriter(iter(results), csv_file)

        iterator = iter(writer)
        assert isinstance(iterator, ResultsCSVWriterIterator)
