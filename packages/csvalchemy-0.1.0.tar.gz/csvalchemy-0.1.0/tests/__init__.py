"""Test suite for csvalchemy package."""
