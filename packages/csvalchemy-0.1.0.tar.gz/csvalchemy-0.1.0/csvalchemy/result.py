"""Result type for validation outcomes."""

import typing

import pydantic


class Result(typing.NamedTuple):
    """Result of a validation operation.

    Attributes:
        error: Exception if validation failed, None if successful.
        result: Validated Pydantic model if successful, None if validation failed.
        value: The original raw value that was validated.
    """

    error: Exception | None
    result: pydantic.BaseModel | None
    value: typing.Any
