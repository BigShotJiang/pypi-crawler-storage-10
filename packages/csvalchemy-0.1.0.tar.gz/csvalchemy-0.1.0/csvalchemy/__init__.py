"""CSV ORM: Read, Validate, Update, and Write CSV files using Pydantic models.

This package provides utilities for reading CSV files and validating each row
against a Pydantic model, handling errors gracefully, and writing validated
results back to CSV files.
"""

__version__ = "0.1.0"

from .reader import read
from .validator import Validator
from .result import Result
from .writer import ResultsCSVWriter

__all__ = [
    "read",
    "Validator",
    "Result",
    "ResultsCSVWriter",
    "__version__",
]
