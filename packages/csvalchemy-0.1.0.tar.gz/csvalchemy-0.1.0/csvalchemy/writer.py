"""CSV writing utilities for validated results."""

from collections.abc import Iterator, Iterable
from dataclasses import dataclass
import typing
import csv

from . import result as _result
from . import to_dict as _to_dict


@dataclass
class ResultsCSVWriterIterator(Iterator):
    """Iterator that writes validated results to a CSV file.

    Skips results with errors and writes valid results as CSV rows.
    Automatically writes headers on the first valid result.
    """

    results: typing.Iterator[_result.Result]
    csv_file: typing.IO

    def __post_init__(self) -> None:
        """Initialize the iterator state."""
        self.headers: bool = False
        self.writer: csv.DictWriter | None = None

    def __next__(self) -> _result.Result:
        """Get the next result and write it to CSV if valid.

        Returns:
            The next result from the results iterator.

        Raises:
            StopIteration: When the results iterator is exhausted.
        """
        result: _result.Result = next(self.results)
        return self.write_result(result)

    def write_result(self, result: _result.Result) -> _result.Result:
        """Write a result to the CSV file if it's valid.

        Args:
            result: The result to potentially write.

        Returns:
            The result (unchanged).
        """
        if result.error:
            return result
        if result.result:
            row: dict[str, typing.Any] = _to_dict.data_to_dict(result.result)
        else:
            return result
        if not self.headers:
            self.writer = csv.DictWriter(self.csv_file, fieldnames=row)
            try:
                self.writer.writeheader()
            except (IOError, csv.Error) as e:
                return _result.Result(e, None, result.value)
            self.headers = True
        if self.writer is None:
            return _result.Result(
                RuntimeError("CSV writer not initialized"), None, result.value
            )
        try:
            self.writer.writerow(row)
        except (IOError, csv.Error) as e:
            return _result.Result(e, None, result.value)
        return result


@dataclass
class ResultsCSVWriter(Iterable):
    """Iterable that writes validated results to a CSV file.

    Usage:
        writer = ResultsCSVWriter(results, csv_file)
        for result in writer:
            # Results are automatically written to CSV
            pass
    """

    results: typing.Iterator[_result.Result]
    csv_file: typing.IO

    def __iter__(self) -> ResultsCSVWriterIterator:
        """Create an iterator for writing results to CSV.

        Returns:
            A ResultsCSVWriterIterator instance.
        """
        return ResultsCSVWriterIterator(self.results, self.csv_file)
