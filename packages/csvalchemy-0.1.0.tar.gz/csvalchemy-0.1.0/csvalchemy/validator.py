"""Validation utilities for iterating and validating data records.

This module provides validation functionality by integrating with the dydactic
package (https://github.com/eddiethedean/dydactic). The Validator and
ValidatorIterator classes wrap dydactic.validate() to provide a consistent
API for CSV data validation.

Dependencies:
    - dydactic: Core validation engine (requires Python 3.10+)
    - pydantic: Data validation using Python type annotations
"""

import typing
from collections.abc import Iterator, Iterable
from dataclasses import dataclass, field

import dydactic  # type: ignore[import-untyped]
import dydactic.options  # type: ignore[import-untyped]
import dydactic.result  # type: ignore[import-untyped]
import pydantic

from . import result as _result
from . import writer as _writer


Record = dict[str, typing.Any]


class DydacticIntegrationError(Exception):
    """Raised when dydactic integration encounters unexpected errors."""

    pass


@dataclass
class ValidatorIterator(Iterator):
    """Iterator that validates records against a Pydantic model.

    Wraps dydactic.validate() to provide Result objects for each record.
    Handles errors from dydactic and maps them to csvalchemy's Result type.

    Args:
        data: Iterator of record dictionaries to validate.
        model: Pydantic BaseModel class to validate against.
        error_option: How dydactic handles errors (RETURN, RAISE, or SKIP).
        strict: Whether to use strict Pydantic validation.
        from_attributes: Whether to validate from object attributes.

    Raises:
        DydacticIntegrationError: If dydactic.validate() fails to initialize.
    """

    data: typing.Iterator[Record]
    model: type[pydantic.BaseModel]
    error_option: dydactic.options.ErrorOption = dydactic.options.ErrorOption.RETURN
    strict: bool | None = None
    from_attributes: bool | None = None
    _iterator: typing.Iterator[dydactic.result.RecordValidationResult] | None = field(
        default=None, init=False
    )

    def __post_init__(self) -> None:
        """Initialize the validation iterator.

        Raises:
            DydacticIntegrationError: If dydactic.validate() raises an exception.
        """
        try:
            self._iterator = dydactic.validate(
                self.data,
                self.model,
                error_option=self.error_option,
                strict=self.strict,
                from_attributes=self.from_attributes,
            )
        except Exception as e:
            raise DydacticIntegrationError(
                f"Failed to initialize dydactic validator: {e}. "
                f"This may indicate incompatible dydactic version or invalid model/data."
            ) from e

    def __next__(self) -> _result.Result:
        """Get the next validation result.

        Returns:
            A Result containing the validation outcome with error, result, and value.

        Raises:
            StopIteration: When all records have been processed.
            DydacticIntegrationError: If dydactic iterator raises an unexpected error.
        """
        if self._iterator is None:
            raise DydacticIntegrationError(
                "Iterator not initialized. Call __post_init__ first."
            )

        try:
            dydactic_result = next(self._iterator)
        except StopIteration:
            raise
        except Exception as e:
            raise DydacticIntegrationError(
                f"Unexpected error from dydactic validation iterator: {e}"
            ) from e

        # Map dydactic's RecordValidationResult to csvalchemy's Result
        # RecordValidationResult has .error, .result, and .value attributes
        return _result.Result(
            error=dydactic_result.error,
            result=dydactic_result.result,
            value=dydactic_result.value,
        )

    def __iter__(self) -> typing.Self:
        """Return self as an iterator."""
        return self


@dataclass
class Validator(Iterable):
    """Validates an iterable of records against a Pydantic model.

    This class provides a convenient interface for validating data records
    using dydactic's validation engine. It integrates with Pydantic models
    to provide type-safe, validated data processing.

    The validation is performed by dydactic, which handles Pydantic model
    validation and error collection. Each record is validated independently,
    allowing processing to continue even when individual records fail.

    Args:
        data: Iterator of record dictionaries to validate.
        model: Pydantic BaseModel class to validate against.
        error_option: How dydactic handles errors:
            - RETURN (default): Return errors in Result.error
            - RAISE: Raise exceptions on validation errors
            - SKIP: Skip records with errors entirely
        strict: Whether to use strict Pydantic validation (None uses model default).
        from_attributes: Whether to validate from object attributes (None uses model default).

    Example:
        records = [{'name': 'Alice', 'age': 30}, {'name': 'Bob', 'age': 25}]
        validator = Validator(iter(records), PersonModel)
        for result in validator:
            if result.error:
                print(f"Error: {result.error}")
            else:
                print(f"Valid: {result.result}")

    Note:
        This class uses dydactic (https://github.com/eddiethedean/dydactic)
        for validation. Ensure dydactic>=0.2.0 is installed and compatible
        with your Python version (requires Python 3.10+).
    """

    data: typing.Iterator[Record]
    model: type[pydantic.BaseModel]
    error_option: dydactic.options.ErrorOption = dydactic.options.ErrorOption.RETURN
    strict: bool | None = None
    from_attributes: bool | None = None

    def __iter__(self) -> ValidatorIterator:
        """Create an iterator for validation results.

        Returns:
            A ValidatorIterator instance that wraps dydactic.validate().

        Raises:
            DydacticIntegrationError: If dydactic validation fails to initialize.
        """
        return ValidatorIterator(
            self.data,
            self.model,
            error_option=self.error_option,
            strict=self.strict,
            from_attributes=self.from_attributes,
        )

    def csv_writer(self, csv_file: typing.IO) -> _writer.ResultsCSVWriter:
        """Create a CSV writer for validation results.

        This method creates a CSV writer that automatically writes valid
        results to the specified file, skipping records with validation errors.

        Args:
            csv_file: File handle to write CSV output to (text mode, writable).

        Returns:
            A ResultsCSVWriter instance that writes valid results to CSV.

        Example:
            validator = Validator(iter(records), PersonModel)
            with open('output.csv', 'w') as f:
                writer = validator.csv_writer(f)
                for result in writer:
                    # Results are automatically written to CSV
                    if result.error:
                        print(f"Skipped invalid record: {result.error}")
        """
        return _writer.ResultsCSVWriter(iter(self), csv_file)
