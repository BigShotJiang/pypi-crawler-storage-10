"""CSV file reading utilities."""

import typing
import csv

import pydantic

from . import validator as _validator


class CSVReaderValidator(_validator.Validator):
    """Validator for CSV file data against a Pydantic model.

    Reads CSV rows and validates each against the provided Pydantic model.

    Args:
        csv_file: File handle to the CSV file to read (text mode).
        model: Pydantic BaseModel class to validate rows against.

    Example:
        with open('data.csv') as f:
            validator = CSVReaderValidator(f, MyModel)
            for result in validator:
                if result.error:
                    print(f"Error: {result.error}")
                else:
                    print(f"Valid: {result.result}")
    """

    def __init__(self, csv_file: typing.IO, model: type[pydantic.BaseModel]) -> None:
        """Initialize CSV reader validator.

        Args:
            csv_file: File handle opened in text mode.
            model: Pydantic BaseModel class (not instance).
        """
        if not hasattr(csv_file, "read"):
            raise TypeError(f"Expected file-like object, got {type(csv_file)}")
        data = csv.DictReader(csv_file)
        super().__init__(data, model)


def read(csv_file: typing.IO, model: type[pydantic.BaseModel]) -> CSVReaderValidator:
    """Read and validate a CSV file against a Pydantic model.

    Convenience function to create a CSVReaderValidator.

    Args:
        csv_file: File handle to the CSV file (text mode, readable).
        model: Pydantic BaseModel class to validate against.

    Returns:
        A CSVReaderValidator instance that can be iterated.

    Example:
        with open('data.csv') as f:
            for result in read(f, MyModel):
                if result.error:
                    print(f"Validation error: {result.error}")
    """
    return CSVReaderValidator(csv_file, model)
