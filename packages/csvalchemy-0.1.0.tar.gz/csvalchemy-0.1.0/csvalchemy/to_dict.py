"""Utilities for converting data models to dictionaries."""

import typing

from pydantic import BaseModel
from typing import NamedTuple, Mapping
from dataclasses import asdict

DataModel = typing.Union[BaseModel, Mapping, NamedTuple]


def data_to_dict(model: DataModel) -> dict:
    """Convert a data model to a dictionary.

    Supports Pydantic BaseModel, NamedTuple, Mapping, and dataclasses.

    Args:
        model: The data model to convert. Can be:
            - Pydantic BaseModel
            - NamedTuple
            - Mapping (dict, etc.)
            - Dataclass instance

    Returns:
        A dictionary representation of the model.

    Raises:
        TypeError: If the model type is not supported or is a regular tuple.
    """
    if isinstance(model, BaseModel):
        return model.model_dump()
    if isinstance(model, tuple):
        # Check if it's a NamedTuple (has _asdict method)
        if hasattr(model, "_asdict") and hasattr(model, "_fields"):
            return model._asdict()
        raise TypeError(
            f"Cannot convert regular tuple to dict. "
            f"Expected NamedTuple, got {type(model)}"
        )
    if isinstance(model, Mapping):
        return dict(model)
    # Also works on dataclasses
    return asdict(model)
