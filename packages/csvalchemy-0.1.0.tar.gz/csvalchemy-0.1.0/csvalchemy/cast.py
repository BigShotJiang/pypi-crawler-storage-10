"""Type casting utilities for CSV validation.

Note: This module provides casting functionality that is similar to dydactic.cast.
The main validation flow in csvalchemy uses dydactic.validate(), which handles
casting internally via dydactic.cast. This module is kept for:

1. Standalone use cases that don't require full dydactic validation
2. Testing and validation of casting logic
3. Direct class instantiation without Pydantic models

For typical CSV validation workflows, use the Validator class which leverages
dydactic's casting capabilities through dydactic.validate().
"""

import typing
from datetime import datetime
import types

import dateutil.parser


def cast_as(value: typing.Any, annotation: type) -> typing.Any:
    """Cast a value to the specified annotation type.

    Args:
        value: The value to cast.
        annotation: The target type to cast to.

    Returns:
        The value cast to the annotation type.

    Raises:
        ValueError: If the value cannot be cast to the annotation type.
        TypeError: If the annotation type is not supported.
    """
    if isinstance(value, annotation):
        return value
    if annotation is datetime:
        if value is None or value == "":
            return None
        return dateutil.parser.parse(value)
    if annotation is bool:
        # Special handling for bool: Python's bool() treats any non-empty string as True
        if isinstance(value, str):
            normalized = value.lower().strip()
            if normalized in ("true", "1", "yes", "on"):
                return True
            elif normalized in ("false", "0", "no", "off", ""):
                return False
            else:
                raise ValueError(f"Cannot convert string '{value}' to bool")
        return bool(value)
    return annotation(value)


def cast_as_union(
    value: typing.Any,
    ut: typing.Any,  # Union type: typing._UnionGenericAlias | types.UnionType
) -> typing.Any:
    """Cast a value to one of the types in a Union.

    Args:
        value: The value to cast.
        ut: The Union type annotation.

    Returns:
        The value cast to one of the Union types.

    Raises:
        TypeError: If the value cannot be cast to any of the Union types.
    """
    # For string values, prioritize numeric types if available
    # This handles cases like "42" in Union[str, int] -> int (not str)
    union_args = getattr(ut, "__args__", ())
    types_list = list(union_args)

    if isinstance(value, str):
        numeric_types = (int, float, complex)
        # Reorder: numeric types first, then others
        numeric_in_union = [t for t in types_list if t in numeric_types]
        other_types = [t for t in types_list if t not in numeric_types]
        reordered_types: list[type] = numeric_in_union + other_types
    else:
        reordered_types = types_list

    errors = []
    for _type in reordered_types:
        try:
            return cast_as(value, _type)
        except (ValueError, TypeError, AttributeError) as e:
            errors.append(str(e))
            continue
    raise TypeError("Failed to cast value")


def cls_annotations(cls: type) -> dict[str, type]:
    """Get annotations dictionary from a class.

    Args:
        cls: The class to get annotations from.

    Returns:
        A dictionary mapping field names to their type annotations.
    """
    return getattr(cls, "__annotations__", {})


def cast_as_annotation(value: typing.Any, annotation: type) -> typing.Any:
    """Cast a value according to its annotation type.

    Handles both regular types and Union types.

    Args:
        value: The value to cast.
        annotation: The annotation type (can be a Union).

    Returns:
        The value cast to the appropriate type.

    Raises:
        TypeError: If the value cannot be cast to the annotation type.
    """
    # Check if annotation is a Union type
    origin = getattr(annotation, "__origin__", None)
    if origin is typing.Union or isinstance(annotation, types.UnionType):
        return cast_as_union(value, annotation)
    return cast_as(value, annotation)


class ValidationError(ValueError):
    """Raised when a value cannot be validated against its annotation type."""

    pass


Class = typing.TypeVar("Class", bound=type)


def cast_to_annotated_class(d: dict[str, typing.Any], cls: Class) -> Class:
    """Cast a dictionary to an annotated class instance.

    Args:
        d: Dictionary of field values.
        cls: The class to instantiate.

    Returns:
        An instance of cls with cast values.

    Raises:
        ValidationError: If any field fails validation.
    """
    annotations: dict[str, type] = cls_annotations(cls)
    new_data: dict[str, typing.Any] = {}
    errors: dict[str, dict] = {}

    # Only process keys that are in annotations
    for key in annotations.keys():
        if key in d:
            value = d[key]
            annotation: type = annotations[key]
            try:
                new_data[key] = cast_as_annotation(value, annotation)
            except (ValueError, TypeError, AttributeError) as e:
                errors[key] = {
                    "type": annotation,
                    "input_value": value,
                    "input_type": type(value),
                    "error": str(e),
                }

    if errors:
        raise ValidationError(errors)
    return cls(**new_data)
