"""Error handling example for csvalchemy."""
from io import StringIO

from pydantic import BaseModel

from csvalchemy import read


class Person(BaseModel):
    name: str
    age: int
    email: str | None = None


# CSV with some invalid rows
csv_content = """name,age,email
Alice,30,alice@example.com
Bob,not_a_number,bob@example.com
Charlie,35,charlie@example.com
Diana,not_a_number,diana@example.com
"""

with StringIO(csv_content) as f:
    print("=== Handling validation errors ===")
    valid_count = 0
    error_count = 0

    for result in read(f, Person):
        if result.error:
            error_count += 1
            print(f"Error on row {error_count}: {result.error}")
        else:
            valid_count += 1
            print(f"Valid: {result.result.name}")

    print(f"\nSummary: {valid_count} valid, {error_count} errors")
