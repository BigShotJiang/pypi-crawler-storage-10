"""Direct Validator usage example for csvalchemy."""

from pydantic import BaseModel
from csvalchemy import Validator
import dydactic.options


class Person(BaseModel):
    name: str
    age: int
    email: str | None = None


# Data not from CSV
records = [
    {"name": "Alice", "age": "30", "email": "alice@example.com"},
    {"name": "Bob", "age": "not_a_number", "email": "bob@example.com"},
    {"name": "Charlie", "age": "35"},
]

print("=== Using Validator directly ===")
validator = Validator(iter(records), Person)

for result in validator:
    if result.error:
        print(f"Error: {result.error}")
    else:
        print(f"Valid: {result.result.name}, age {result.result.age}")

print("\n=== Using SKIP error option ===")
validator_skip = Validator(
    iter(records), Person, error_option=dydactic.options.ErrorOption.SKIP
)

valid_results = list(validator_skip)
print(f"Got {len(valid_results)} valid results (invalid ones skipped)")
