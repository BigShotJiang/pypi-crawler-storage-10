"""Basic usage example for csvalchemy."""
from io import StringIO

from pydantic import BaseModel

from csvalchemy import read


# Define your model
class Person(BaseModel):
    name: str
    age: int
    email: str | None = None


# Sample CSV content
csv_content = """name,age,email
Alice,30,alice@example.com
Bob,25,bob@example.com
Charlie,35,charlie@example.com
"""

# Read and validate CSV

with StringIO(csv_content) as f:
    print("=== Reading and validating CSV ===")
    for result in read(f, Person):
        if result.error:
            print(f"Validation error: {result.error}")
        else:
            print(f"Valid person: {result.result.name}, age {result.result.age}")
