"""Write validated CSV example for csvalchemy."""

from pydantic import BaseModel
from csvalchemy import read
from io import StringIO


class Product(BaseModel):
    id: int
    name: str
    price: float
    in_stock: bool


# Input CSV
input_csv = """id,name,price,in_stock
1,Widget,19.99,True
2,Gadget,29.99,False
3,Invalid,not_a_number,True
4,Thing,39.99,True
"""

# Read and validate
print("=== Reading CSV ===")
input_file = StringIO(input_csv)
validator = read(input_file, Product)

# Write validated results to new CSV
print("\n=== Writing validated CSV ===")
output_file = StringIO()

# Recreate validator since iterator was consumed
input_file2 = StringIO(input_csv)
validator2 = read(input_file2, Product)
writer = validator2.csv_writer(output_file)

# Consume writer to trigger CSV writing
for result in writer:
    if result.error:
        print(f"Skipped invalid row: {result.error}")
    else:
        print(f"Wrote: {result.result.name}")

# Show output CSV
output_file.seek(0)
print("\n=== Output CSV ===")
print(output_file.read())
