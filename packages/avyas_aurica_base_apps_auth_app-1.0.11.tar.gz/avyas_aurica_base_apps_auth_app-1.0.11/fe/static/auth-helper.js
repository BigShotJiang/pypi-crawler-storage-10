/**
 * Aurica Authentication Helper
 * Include this script in any page that requires authentication
 */

(function() {
    'use strict';

    // Configuration
    const AUTH_CHECK_URL = '/auth-app/api/authenticate/current-user';
    const LOGIN_PAGE = '/auth-app/';

    /**
     * Check if the user is authenticated
     * @returns {Promise<object|null>} User data if authenticated, null otherwise
     */
    async function checkAuth() {
        try {
            const response = await fetch(AUTH_CHECK_URL, {
                credentials: 'include', // Include cookies
                headers: {
                    'Authorization': 'Bearer ' + (localStorage.getItem('auth_token') || '')
                }
            });

            if (response.ok) {
                const userData = await response.json();
                return userData;
            } else {
                return null;
            }
        } catch (error) {
            console.error('Authentication check failed:', error);
            return null;
        }
    }

    /**
     * Redirect to login page with return URL
     */
    function redirectToLogin() {
        const returnUrl = encodeURIComponent(window.location.pathname + window.location.search);
        window.location.href = `${LOGIN_PAGE}?return_url=${returnUrl}`;
    }

    /**
     * Initialize authentication check
     * Call this function to require authentication on page load
     */
    async function requireAuth() {
        const userData = await checkAuth();
        
        if (!userData) {
            redirectToLogin();
            return null;
        }

        return userData;
    }

    /**
     * Logout function
     */
    async function logout() {
        try {
            await fetch('/auth-app/api/authenticate/logout', {
                method: 'POST',
                credentials: 'include'
            });
        } catch (error) {
            console.error('Logout error:', error);
        }

        // Clear local storage
        localStorage.removeItem('auth_token');
        localStorage.removeItem('username');
        localStorage.removeItem('user_id');

        // Redirect to login
        window.location.href = LOGIN_PAGE;
    }

    /**
     * Get current user data
     * @returns {Promise<object|null>}
     */
    async function getCurrentUser() {
        return await checkAuth();
    }

    /**
     * Make an authenticated API request
     * @param {string} url - API endpoint URL
     * @param {object} options - Fetch options
     * @returns {Promise<Response>}
     */
    async function authenticatedFetch(url, options = {}) {
        const token = localStorage.getItem('auth_token');
        
        const defaultOptions = {
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json',
                ...(token ? { 'Authorization': `Bearer ${token}` } : {})
            }
        };

        const mergedOptions = {
            ...defaultOptions,
            ...options,
            headers: {
                ...defaultOptions.headers,
                ...(options.headers || {})
            }
        };

        const response = await fetch(url, mergedOptions);

        // If unauthorized, redirect to login
        if (response.status === 401) {
            redirectToLogin();
            throw new Error('Authentication required');
        }

        return response;
    }

    // Expose API
    window.AuricaAuth = {
        checkAuth,
        requireAuth,
        logout,
        getCurrentUser,
        authenticatedFetch,
        redirectToLogin
    };

    // Auto-check authentication if configured
    if (window.AuricaAuthConfig && window.AuricaAuthConfig.autoCheck) {
        document.addEventListener('DOMContentLoaded', async () => {
            await requireAuth();
        });
    }
})();
