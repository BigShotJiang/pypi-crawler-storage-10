"""Tests for unified runtime facade."""

