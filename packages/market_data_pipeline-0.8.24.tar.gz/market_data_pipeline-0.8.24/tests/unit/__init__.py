"""Unit tests for market data pipeline."""
