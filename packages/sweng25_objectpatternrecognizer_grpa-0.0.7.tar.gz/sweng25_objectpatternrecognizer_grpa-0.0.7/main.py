def add(x, y):
    return x + y


def main_func():
    print("Hello from main.py")
    print(add(6, 5))


if __name__ == "__main__":
    main_func()
