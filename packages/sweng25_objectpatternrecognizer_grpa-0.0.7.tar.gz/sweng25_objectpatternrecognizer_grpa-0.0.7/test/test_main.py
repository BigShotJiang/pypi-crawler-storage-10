import unittest
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from main import add


class TestAdd(unittest.TestCase):
    def test_add_positive_numbers(self):
        self.assertEqual(add(1, 2), 3)
        self.assertEqual(add(5, 5), 10)

    def test_add_negative_numbers(self):
        self.assertEqual(add(-1, -2), -3)
        self.assertEqual(add(-5, -5), -10)

    def test_add_zero(self):
        self.assertEqual(add(0, 5), 5)
        self.assertEqual(add(5, 0), 5)
        self.assertEqual(add(0, 0), 0)

    def test_add_positive_negative(self):
        self.assertEqual(add(1, -2), -1)
        self.assertEqual(add(-5, 10), 5)
