# SWENG25_ObjectPatternRecognizer_GrpA
Small Python application that uses the livestream of a camera and performs real-time object pattern recognition and color detection.
