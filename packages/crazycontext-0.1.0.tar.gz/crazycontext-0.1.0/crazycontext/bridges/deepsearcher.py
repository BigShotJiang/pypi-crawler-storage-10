"""
Deep-Searcher Bridge for CrazyContext.

Integrates CrazyContext with Deep-Searcher for semantic search.
"""

import os
import logging
from typing import List, Dict, Optional

logger = logging.getLogger(__name__)

# Check if deepsearcher is available
try:
    from deepsearcher.configuration import Configuration, init_config
    from deepsearcher.offline_loading import load_from_local_files
    from deepsearcher.online_query import query as ds_query
    DEEPSEARCHER_AVAILABLE = True
except ImportError:
    DEEPSEARCHER_AVAILABLE = False
    logger.warning("Deep-Searcher not installed. Install with: pip install crazycontext[deepsearcher]")


class CrazyContextLoader:
    """
    Bridge between CrazyContext and Deep-Searcher.
    
    Uses CrazyContext for data gathering and Deep-Searcher for semantic search.
    
    Features:
    - Load CrazyContext cache into Deep-Searcher
    - Semantic search with vector embeddings
    - FREE Gemini embeddings (default)
    - Hybrid search (keyword + semantic)
    
    Example:
        ```python
        from crazycontext.bridges import CrazyContextLoader
        from crazycontext import CrazyContext
        
        # Gather data with CrazyContext
        cc = CrazyContext()
        cc.from_urls(["https://docs.python.org/3/"])
        
        # Load into Deep-Searcher
        loader = CrazyContextLoader()
        loader.load_from_cache(cc.cache_dir)
        
        # Semantic query (FREE with Gemini!)
        answer = loader.query("What is a decorator?")
        print(answer['answer'])
        ```
    """
    
    def __init__(
        self,
        milvus_uri: str = "./milvus_crazycontext.db",
        llm_provider: str = "Gemini",
        llm_model: str = "gemini-2.0-flash-exp",
        embedding_provider: str = "GeminiEmbedding",
        embedding_model: str = "text-embedding-004"
    ):
        """
        Initialize Deep-Searcher bridge.
        
        Args:
            milvus_uri: Path to Milvus database
            llm_provider: LLM provider (default: Gemini - free/cheap)
            llm_model: LLM model name
            embedding_provider: Embedding provider (default: GeminiEmbedding - FREE!)
            embedding_model: Embedding model name
        
        Raises:
            ImportError: If Deep-Searcher not installed
        """
        if not DEEPSEARCHER_AVAILABLE:
            raise ImportError(
                "Deep-Searcher not installed. "
                "Install with: pip install crazycontext[deepsearcher]"
            )
        
        self.milvus_uri = milvus_uri
        self.llm_provider = llm_provider
        self.llm_model = llm_model
        self.embedding_provider = embedding_provider
        self.embedding_model = embedding_model
        self.collections = []
        
        # Initialize Deep-Searcher config
        self._init_deepsearcher()
        
        logger.info(
            f"CrazyContextLoader initialized "
            f"(LLM: {llm_provider}/{llm_model}, "
            f"Embeddings: {embedding_provider}/{embedding_model})"
        )
    
    def _init_deepsearcher(self):
        """Initialize Deep-Searcher configuration."""
        config = Configuration()
        
        # Configure vector database
        config.set_provider_config("vector_db", "Milvus", {"uri": self.milvus_uri})
        
        # Configure LLM
        config.set_provider_config("llm", self.llm_provider, {"model": self.llm_model})
        
        # Configure embeddings
        config.set_provider_config(
            "embedding",
            self.embedding_provider,
            {"model": self.embedding_model}
        )
        
        # Initialize
        init_config(config)
        
        logger.info("Deep-Searcher configured")
    
    def load_from_cache(
        self,
        cache_dir: str,
        collection_name: Optional[str] = None,
        file_extensions: Optional[List[str]] = None
    ) -> int:
        """
        Load files from CrazyContext cache into Deep-Searcher.
        
        Args:
            cache_dir: CrazyContext cache directory
            collection_name: Collection name (default: from dir name)
            file_extensions: File extensions to load (default: [".md", ".txt"])
        
        Returns:
            Number of files loaded
        
        Example:
            ```python
            loader = CrazyContextLoader()
            
            # Load all markdown and text files
            count = loader.load_from_cache("./cache/web")
            print(f"Loaded {count} files")
            ```
        """
        if not os.path.exists(cache_dir):
            raise ValueError(f"Cache directory not found: {cache_dir}")
        
        if collection_name is None:
            collection_name = os.path.basename(cache_dir) or "default"
        
        if file_extensions is None:
            file_extensions = [".md", ".txt", ".html"]
        
        # Load files into Deep-Searcher
        try:
            load_from_local_files(
                paths_or_directory=cache_dir,
                collection_name=collection_name,
                file_extensions=file_extensions
            )
            
            self.collections.append(collection_name)
            
            # Count files (approximate)
            from ..utils import file_utils
            files = file_utils.get_files_by_extension(
                cache_dir,
                file_extensions,
                recursive=True
            )
            
            logger.info(
                f"Loaded {len(files)} files from {cache_dir} "
                f"into collection '{collection_name}'"
            )
            
            return len(files)
        
        except Exception as e:
            logger.error(f"Error loading cache: {e}")
            raise
    
    def query(
        self,
        question: str,
        collection_name: Optional[str] = None,
        top_k: int = 5
    ) -> Dict:
        """
        Semantic query using Deep-Searcher.
        
        Args:
            question: Question to ask
            collection_name: Collection to search (default: all)
            top_k: Number of results to return
        
        Returns:
            Dictionary with answer, sources, and token count
        
        Example:
            ```python
            # Semantic search with FREE Gemini embeddings!
            answer = loader.query(
                "How do Python decorators work?",
                top_k=5
            )
            
            print(f"Answer: {answer['answer']}")
            print(f"Sources: {len(answer['sources'])} documents")
            print(f"Tokens used: {answer['tokens']}")
            ```
        """
        try:
            answer, sources, tokens = ds_query(
                question,
                collection_name=collection_name,
                top_k=top_k
            )
            
            return {
                'answer': answer,
                'sources': sources,
                'tokens': tokens,
                'question': question
            }
        
        except Exception as e:
            logger.error(f"Query error: {e}")
            raise
    
    def get_collections(self) -> Dict:
        """
        Get information about loaded collections.
        
        Returns:
            Dictionary with collection info
        
        Example:
            ```python
            info = loader.get_collections()
            print(f"Collections: {info['collections']}")
            ```
        """
        return {
            'total_collections': len(self.collections),
            'collections': {name: {} for name in self.collections},
            'milvus_uri': self.milvus_uri
        }


def quick_setup(cache_dir: str, question: str) -> Dict:
    """
    Quick setup and query helper.
    
    Args:
        cache_dir: CrazyContext cache directory
        question: Question to ask
    
    Returns:
        Answer dictionary
    
    Example:
        ```python
        from crazycontext.bridges import quick_setup
        
        # One-liner semantic search!
        answer = quick_setup(
            "./cache/web",
            "What is machine learning?"
        )
        print(answer['answer'])
        ```
    """
    loader = CrazyContextLoader()
    loader.load_from_cache(cache_dir)
    return loader.query(question)
