"""Integration bridges for CrazyContext."""

try:
    from .deepsearcher import CrazyContextLoader, quick_setup
    __all__ = ["CrazyContextLoader", "quick_setup"]
except ImportError:
    # Deep-Searcher not installed
    __all__ = []
