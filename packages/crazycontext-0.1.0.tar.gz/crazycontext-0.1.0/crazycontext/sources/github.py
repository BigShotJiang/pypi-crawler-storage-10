"""
GitHub Source Handler for CrazyContext.

Search repositories and extract code context.
"""

import os
import logging
import requests
from typing import List, Dict, Optional
from urllib.parse import urlparse

from ..utils import file_utils
from ..search import keyword

logger = logging.getLogger(__name__)


class GitHubSource:
    """
    Handle GitHub repositories as a context source.
    
    Search repositories, download files, and extract code context.
    
    Example:
        ```python
        from crazycontext.sources import GitHubSource
        
        github = GitHubSource()
        
        # Search repositories
        repos = github.search_repositories("neural networks python", max_results=5)
        
        # Download repository files
        files = github.download_repo_files(
            "pytorch/examples",
            patterns=["*.py"]
        )
        ```
    """
    
    BASE_URL = "https://api.github.com"
    
    def __init__(
        self,
        cache_dir: str = "./cache/github",
        github_token: Optional[str] = None
    ):
        """
        Initialize GitHub source handler.
        
        Args:
            cache_dir: Directory to cache repository files
            github_token: Optional GitHub token for higher rate limits
        """
        self.cache_dir = file_utils.ensure_dir(cache_dir)
        self.github_token = github_token
        self.headers = {
            'Accept': 'application/vnd.github.v3+json'
        }
        
        if github_token:
            self.headers['Authorization'] = f'token {github_token}'
        
        logger.info(f"GitHubSource initialized (cache: {self.cache_dir})")
    
    def search_repositories(
        self,
        query: str,
        language: Optional[str] = None,
        min_stars: int = 0,
        max_results: int = 10,
        sort: str = "stars"
    ) -> List[Dict]:
        """
        Search GitHub repositories.
        
        Args:
            query: Search query
            language: Filter by programming language
            min_stars: Minimum star count
            max_results: Maximum results
            sort: Sort by ("stars", "forks", "updated")
        
        Returns:
            List of repository dictionaries
        
        Example:
            ```python
            github = GitHubSource()
            
            repos = github.search_repositories(
                "machine learning",
                language="python",
                min_stars=100,
                max_results=5
            )
            
            for repo in repos:
                print(f"{repo['full_name']}: {repo['stars']} stars")
            ```
        """
        # Build search query
        search_query = query
        if language:
            search_query += f" language:{language}"
        if min_stars > 0:
            search_query += f" stars:>={min_stars}"
        
        params = {
            'q': search_query,
            'sort': sort,
            'order': 'desc',
            'per_page': min(max_results, 100)
        }
        
        try:
            url = f"{self.BASE_URL}/search/repositories"
            response = requests.get(
                url,
                headers=self.headers,
                params=params,
                timeout=30
            )
            response.raise_for_status()
            
            data = response.json()
            repos = []
            
            for item in data.get('items', [])[:max_results]:
                repo = {
                    'id': item.get('id'),
                    'name': item.get('name', ''),
                    'full_name': item.get('full_name', ''),
                    'description': item.get('description', ''),
                    'stars': item.get('stargazers_count', 0),
                    'forks': item.get('forks_count', 0),
                    'language': item.get('language', ''),
                    'url': item.get('html_url', ''),
                    'clone_url': item.get('clone_url', ''),
                    'default_branch': item.get('default_branch', 'main')
                }
                repos.append(repo)
            
            logger.info(f"Found {len(repos)} repositories for '{query}'")
            return repos
        
        except Exception as e:
            logger.error(f"GitHub search error: {e}")
            return []
    
    def get_repo_files(
        self,
        repo_full_name: str,
        path: str = "",
        patterns: Optional[List[str]] = None
    ) -> List[Dict]:
        """
        Get list of files from a repository.
        
        Args:
            repo_full_name: Repository name (owner/repo)
            path: Directory path in repo
            patterns: File patterns to include (e.g., ["*.py", "*.md"])
        
        Returns:
            List of file dictionaries
        
        Example:
            ```python
            files = github.get_repo_files(
                "pytorch/examples",
                path="mnist",
                patterns=["*.py"]
            )
            ```
        """
        try:
            url = f"{self.BASE_URL}/repos/{repo_full_name}/contents/{path}"
            response = requests.get(
                url,
                headers=self.headers,
                timeout=30
            )
            response.raise_for_status()
            
            contents = response.json()
            files = []
            
            # Handle single file vs directory
            if isinstance(contents, dict):
                contents = [contents]
            
            for item in contents:
                if item.get('type') == 'file':
                    file_name = item.get('name', '')
                    
                    # Check patterns
                    if patterns:
                        import fnmatch
                        if not any(fnmatch.fnmatch(file_name, p) for p in patterns):
                            continue
                    
                    files.append({
                        'name': file_name,
                        'path': item.get('path', ''),
                        'size': item.get('size', 0),
                        'download_url': item.get('download_url', ''),
                        'sha': item.get('sha', '')
                    })
                
                elif item.get('type') == 'dir':
                    # Recursively get files from subdirectory
                    subdir_files = self.get_repo_files(
                        repo_full_name,
                        item.get('path', ''),
                        patterns
                    )
                    files.extend(subdir_files)
            
            return files
        
        except Exception as e:
            logger.error(f"Error getting repo files: {e}")
            return []
    
    def download_file(
        self,
        download_url: str,
        repo_name: str,
        file_path: str
    ) -> Optional[str]:
        """
        Download a single file from GitHub.
        
        Args:
            download_url: URL to download from
            repo_name: Repository name for caching
            file_path: File path in repo
        
        Returns:
            Local file path or None
        """
        try:
            # Create cache directory for repo
            repo_cache = os.path.join(self.cache_dir, repo_name.replace('/', '_'))
            os.makedirs(repo_cache, exist_ok=True)
            
            # Create local path maintaining structure
            local_path = os.path.join(repo_cache, file_path)
            os.makedirs(os.path.dirname(local_path), exist_ok=True)
            
            # Download file
            response = requests.get(download_url, timeout=30)
            response.raise_for_status()
            
            # Save file
            with open(local_path, 'wb') as f:
                f.write(response.content)
            
            logger.debug(f"Downloaded: {file_path}")
            return local_path
        
        except Exception as e:
            logger.error(f"Error downloading {file_path}: {e}")
            return None
    
    def download_repo_files(
        self,
        repo_full_name: str,
        patterns: Optional[List[str]] = None,
        max_files: int = 50
    ) -> List[str]:
        """
        Download multiple files from a repository.
        
        Args:
            repo_full_name: Repository name (owner/repo)
            patterns: File patterns to download
            max_files: Maximum files to download
        
        Returns:
            List of local file paths
        
        Example:
            ```python
            files = github.download_repo_files(
                "pytorch/examples",
                patterns=["*.py"],
                max_files=20
            )
            
            print(f"Downloaded {len(files)} Python files")
            ```
        """
        files = self.get_repo_files(repo_full_name, patterns=patterns)
        downloaded = []
        
        for file_info in files[:max_files]:
            local_path = self.download_file(
                file_info['download_url'],
                repo_full_name,
                file_info['path']
            )
            
            if local_path:
                downloaded.append(local_path)
        
        logger.info(f"Downloaded {len(downloaded)} files from {repo_full_name}")
        return downloaded
    
    def search_code(
        self,
        query: str,
        language: Optional[str] = None,
        max_results: int = 10
    ) -> List[Dict]:
        """
        Search code on GitHub.
        
        Args:
            query: Search query
            language: Filter by language
            max_results: Maximum results
        
        Returns:
            List of code search results
        
        Example:
            ```python
            results = github.search_code(
                "neural network",
                language="python",
                max_results=5
            )
            ```
        """
        search_query = query
        if language:
            search_query += f" language:{language}"
        
        params = {
            'q': search_query,
            'per_page': min(max_results, 100)
        }
        
        try:
            url = f"{self.BASE_URL}/search/code"
            response = requests.get(
                url,
                headers=self.headers,
                params=params,
                timeout=30
            )
            response.raise_for_status()
            
            data = response.json()
            results = []
            
            for item in data.get('items', [])[:max_results]:
                result = {
                    'name': item.get('name', ''),
                    'path': item.get('path', ''),
                    'repository': item.get('repository', {}).get('full_name', ''),
                    'url': item.get('html_url', '')
                }
                results.append(result)
            
            return results
        
        except Exception as e:
            logger.error(f"GitHub code search error: {e}")
            return []
    
    def get_cached_files(
        self,
        repo_name: Optional[str] = None,
        patterns: Optional[List[str]] = None
    ) -> List[str]:
        """
        Get cached files.
        
        Args:
            repo_name: Filter by repository name
            patterns: File patterns to match
        
        Returns:
            List of cached file paths
        """
        search_dir = self.cache_dir
        
        if repo_name:
            search_dir = os.path.join(
                self.cache_dir,
                repo_name.replace('/', '_')
            )
            
            if not os.path.exists(search_dir):
                return []
        
        if patterns is None:
            patterns = ['*']
        
        files = []
        for pattern in patterns:
            if pattern.startswith('*.'):
                ext = pattern[1:]
                files.extend(
                    file_utils.get_files_by_extension(
                        search_dir,
                        [ext],
                        recursive=True
                    )
                )
            else:
                import glob
                search_pattern = os.path.join(search_dir, '**', pattern)
                files.extend(glob.glob(search_pattern, recursive=True))
        
        return files
    
    def search_cached(
        self,
        query: str,
        repo_name: Optional[str] = None
    ) -> List[Dict]:
        """
        Search cached files.
        
        Args:
            query: Search query
            repo_name: Filter by repository
        
        Returns:
            Search results
        """
        cached_files = self.get_cached_files(repo_name=repo_name)
        
        results = []
        for file_path in cached_files:
            result = keyword.search_in_file(file_path, query)
            if result:
                results.append(result)
        
        results.sort(key=lambda x: x['match_count'], reverse=True)
        return results
    
    def get_stats(self) -> Dict:
        """
        Get GitHub cache statistics.
        
        Returns:
            Statistics dictionary
        """
        all_files = self.get_cached_files()
        
        by_extension = {}
        total_size = 0
        
        for file_path in all_files:
            ext = file_utils.get_file_extension(file_path)
            by_extension[ext] = by_extension.get(ext, 0) + 1
            total_size += file_utils.get_file_size(file_path)
        
        return {
            'total_files': len(all_files),
            'by_extension': by_extension,
            'cache_size': total_size,
            'cache_size_mb': total_size / (1024 * 1024)
        }
    
    def clear_cache(
        self,
        repo_name: Optional[str] = None
    ) -> int:
        """
        Clear cached files.
        
        Args:
            repo_name: Clear specific repo (None = all)
        
        Returns:
            Number of files deleted
        """
        if repo_name:
            repo_dir = os.path.join(
                self.cache_dir,
                repo_name.replace('/', '_')
            )
            if os.path.exists(repo_dir):
                import shutil
                shutil.rmtree(repo_dir)
                return 1
        else:
            deleted = file_utils.clean_directory(self.cache_dir)
            return deleted
        
        return 0
