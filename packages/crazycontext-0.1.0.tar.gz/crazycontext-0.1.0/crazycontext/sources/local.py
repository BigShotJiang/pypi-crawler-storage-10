"""
Local File Source Handler for CrazyContext.

Manages local files and directories as context sources.
"""

import os
import logging
from typing import List, Dict, Optional
from pathlib import Path

from ..utils import file_utils
from ..search import keyword, fuzzy

logger = logging.getLogger(__name__)


class LocalSource:
    """
    Handle local files as a context source.
    
    Indexes and searches local files for context building.
    
    Example:
        ```python
        from crazycontext.sources import LocalSource
        
        local = LocalSource()
        
        # Add files or directories
        local.add_directory("./my_notes")
        local.add_files(["document.txt", "notes.md"])
        
        # Search
        results = local.search("important topic")
        ```
    """
    
    def __init__(self):
        """Initialize local source handler."""
        self.indexed_paths = []
        self.indexed_files = []
        
        logger.info("LocalSource initialized")
    
    def add_file(self, file_path: str) -> bool:
        """
        Add a single file to index.
        
        Args:
            file_path: Path to file
        
        Returns:
            True if added successfully
        
        Example:
            ```python
            local.add_file("research_notes.md")
            ```
        """
        if not os.path.exists(file_path):
            logger.error(f"File not found: {file_path}")
            return False
        
        if not os.path.isfile(file_path):
            logger.error(f"Not a file: {file_path}")
            return False
        
        abs_path = os.path.abspath(file_path)
        
        if abs_path not in self.indexed_files:
            self.indexed_files.append(abs_path)
            logger.info(f"Added file: {abs_path}")
        
        return True
    
    def add_files(self, file_paths: List[str]) -> int:
        """
        Add multiple files to index.
        
        Args:
            file_paths: List of file paths
        
        Returns:
            Number of files successfully added
        
        Example:
            ```python
            files = ["notes1.md", "notes2.md", "research.txt"]
            count = local.add_files(files)
            print(f"Added {count} files")
            ```
        """
        added = 0
        for file_path in file_paths:
            if self.add_file(file_path):
                added += 1
        
        logger.info(f"Added {added}/{len(file_paths)} files")
        return added
    
    def add_directory(
        self,
        directory: str,
        extensions: Optional[List[str]] = None,
        recursive: bool = True
    ) -> int:
        """
        Add all files from a directory to index.
        
        Args:
            directory: Directory path
            extensions: File extensions to include (default: all text files)
            recursive: Search subdirectories
        
        Returns:
            Number of files added
        
        Example:
            ```python
            # Add all markdown files from a directory
            count = local.add_directory(
                "./research",
                extensions=[".md", ".txt"],
                recursive=True
            )
            print(f"Indexed {count} files")
            ```
        """
        if not os.path.exists(directory):
            logger.error(f"Directory not found: {directory}")
            return 0
        
        if extensions is None:
            extensions = ['.txt', '.md', '.rst', '.html']
        
        files = file_utils.get_files_by_extension(
            directory,
            extensions,
            recursive=recursive
        )
        
        abs_directory = os.path.abspath(directory)
        if abs_directory not in self.indexed_paths:
            self.indexed_paths.append(abs_directory)
        
        added = self.add_files(files)
        logger.info(f"Indexed {added} files from {directory}")
        
        return added
    
    def search(
        self,
        query: str,
        search_type: str = "keyword",
        **kwargs
    ) -> List[Dict]:
        """
        Search indexed files.
        
        Args:
            query: Search query
            search_type: "keyword" or "fuzzy"
            **kwargs: Additional search arguments
        
        Returns:
            List of search results
        
        Example:
            ```python
            # Keyword search
            results = local.search("machine learning")
            
            # Fuzzy search (typo-tolerant)
            results = local.search(
                "machne lerning",
                search_type="fuzzy",
                threshold=70
            )
            ```
        """
        if not self.indexed_files:
            logger.warning("No files indexed yet")
            return []
        
        if search_type == "fuzzy":
            return fuzzy.fuzzy_search_in_files(
                self.indexed_files,
                query,
                **kwargs
            )
        else:
            # Search each indexed file
            results = []
            for file_path in self.indexed_files:
                result = keyword.search_in_file(
                    file_path,
                    query,
                    **kwargs
                )
                if result:
                    results.append(result)
            
            # Sort by match count
            results.sort(key=lambda x: x['match_count'], reverse=True)
            
            return results
    
    def get_file_content(self, file_path: str) -> Optional[str]:
        """
        Get content of an indexed file.
        
        Args:
            file_path: Path to file
        
        Returns:
            File content or None
        
        Example:
            ```python
            content = local.get_file_content("notes.md")
            if content:
                print(content)
            ```
        """
        if file_path not in self.indexed_files:
            logger.warning(f"File not indexed: {file_path}")
        
        return file_utils.read_file_safe(file_path)
    
    def get_indexed_files(
        self,
        extensions: Optional[List[str]] = None
    ) -> List[str]:
        """
        Get list of indexed files.
        
        Args:
            extensions: Filter by extensions
        
        Returns:
            List of file paths
        
        Example:
            ```python
            # Get all indexed markdown files
            md_files = local.get_indexed_files([".md"])
            
            # Get all indexed files
            all_files = local.get_indexed_files()
            ```
        """
        if extensions is None:
            return self.indexed_files.copy()
        
        filtered = []
        for file_path in self.indexed_files:
            ext = file_utils.get_file_extension(file_path)
            if ext in extensions:
                filtered.append(file_path)
        
        return filtered
    
    def get_stats(self) -> Dict:
        """
        Get statistics about indexed content.
        
        Returns:
            Dictionary with stats
        
        Example:
            ```python
            stats = local.get_stats()
            print(f"Indexed files: {stats['file_count']}")
            print(f"Total size: {stats['total_size_mb']:.2f} MB")
            ```
        """
        total_size = sum(
            file_utils.get_file_size(f)
            for f in self.indexed_files
        )
        
        # Count by extension
        extensions = {}
        for file_path in self.indexed_files:
            ext = file_utils.get_file_extension(file_path)
            extensions[ext] = extensions.get(ext, 0) + 1
        
        return {
            "file_count": len(self.indexed_files),
            "directory_count": len(self.indexed_paths),
            "total_size": total_size,
            "total_size_mb": total_size / (1024 * 1024),
            "extensions": extensions
        }
    
    def clear_index(self):
        """
        Clear the file index.
        
        Example:
            ```python
            local.clear_index()
            ```
        """
        self.indexed_paths = []
        self.indexed_files = []
        logger.info("Index cleared")
    
    def remove_file(self, file_path: str) -> bool:
        """
        Remove a file from index.
        
        Args:
            file_path: Path to file
        
        Returns:
            True if removed
        
        Example:
            ```python
            local.remove_file("old_notes.md")
            ```
        """
        abs_path = os.path.abspath(file_path)
        
        if abs_path in self.indexed_files:
            self.indexed_files.remove(abs_path)
            logger.info(f"Removed file from index: {abs_path}")
            return True
        
        return False
    
    def refresh_index(self) -> int:
        """
        Refresh index by re-scanning directories.
        
        Returns:
            Number of files indexed
        
        Example:
            ```python
            # Re-index directories (picks up new files)
            count = local.refresh_index()
            print(f"Re-indexed {count} files")
            ```
        """
        old_count = len(self.indexed_files)
        
        # Clear current index
        self.indexed_files = []
        
        # Re-index all paths
        for directory in self.indexed_paths:
            self.add_directory(directory)
        
        new_count = len(self.indexed_files)
        
        logger.info(
            f"Refreshed index: {old_count} -> {new_count} files "
            f"({new_count - old_count:+d})"
        )
        
        return new_count
