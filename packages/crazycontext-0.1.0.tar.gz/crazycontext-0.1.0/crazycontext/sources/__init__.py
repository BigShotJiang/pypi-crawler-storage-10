"""Data source handlers for CrazyContext."""

from .web import WebSource
from .local import LocalSource
from .papers import PapersSource
from .github import GitHubSource

__all__ = ["WebSource", "LocalSource", "PapersSource", "GitHubSource"]
