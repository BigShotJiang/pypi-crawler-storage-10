"""
API wrapper utilities for CrazyContext.

Provides consistent interfaces for external APIs.
"""

import requests
import logging
from typing import Dict, List, Optional
from urllib.parse import urlencode

logger = logging.getLogger(__name__)


class APIError(Exception):
    """Base exception for API errors."""
    pass


class ArxivAPI:
    """
    Wrapper for arXiv API.
    
    Free API, no authentication required.
    """
    
    BASE_URL = "http://export.arxiv.org/api/query"
    
    @staticmethod
    def search(
        query: str,
        max_results: int = 10,
        start: int = 0,
        sort_by: str = "relevance"
    ) -> List[Dict]:
        """
        Search arXiv papers.
        
        Args:
            query: Search query
            max_results: Maximum results to return
            start: Starting index
            sort_by: Sort order ("relevance", "lastUpdatedDate", "submittedDate")
        
        Returns:
            List of paper dictionaries
        
        Example:
            ```python
            from crazycontext.sources.apis import ArxivAPI
            
            papers = ArxivAPI.search("neural networks", max_results=5)
            for paper in papers:
                print(f"{paper['title']} by {paper['authors']}")
            ```
        """
        params = {
            "search_query": f"all:{query}",
            "start": start,
            "max_results": max_results,
            "sortBy": sort_by,
            "sortOrder": "descending"
        }
        
        try:
            response = requests.get(ArxivAPI.BASE_URL, params=params, timeout=30)
            response.raise_for_status()
            
            # Parse XML response
            import xml.etree.ElementTree as ET
            root = ET.fromstring(response.content)
            
            papers = []
            ns = {'atom': 'http://www.w3.org/2005/Atom'}
            
            for entry in root.findall('atom:entry', ns):
                paper = {
                    'id': entry.find('atom:id', ns).text if entry.find('atom:id', ns) is not None else '',
                    'title': entry.find('atom:title', ns).text.strip() if entry.find('atom:title', ns) is not None else '',
                    'summary': entry.find('atom:summary', ns).text.strip() if entry.find('atom:summary', ns) is not None else '',
                    'published': entry.find('atom:published', ns).text if entry.find('atom:published', ns) is not None else '',
                    'authors': [author.find('atom:name', ns).text for author in entry.findall('atom:author', ns) if author.find('atom:name', ns) is not None],
                    'pdf_url': None,
                    'source': 'arxiv'
                }
                
                # Get PDF URL
                for link in entry.findall('atom:link', ns):
                    if link.get('title') == 'pdf':
                        paper['pdf_url'] = link.get('href')
                        break
                
                papers.append(paper)
            
            logger.info(f"arXiv: Found {len(papers)} papers for '{query}'")
            return papers
        
        except Exception as e:
            logger.error(f"arXiv API error: {e}")
            raise APIError(f"arXiv search failed: {e}")


class SemanticScholarAPI:
    """
    Wrapper for Semantic Scholar API.
    
    Free API with optional authentication for higher limits.
    """
    
    BASE_URL = "https://api.semanticscholar.org/graph/v1"
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize Semantic Scholar API.
        
        Args:
            api_key: Optional API key for higher rate limits
        """
        self.api_key = api_key
        self.headers = {}
        if api_key:
            self.headers['x-api-key'] = api_key
    
    def search(
        self,
        query: str,
        max_results: int = 10,
        fields: Optional[List[str]] = None
    ) -> List[Dict]:
        """
        Search papers in Semantic Scholar.
        
        Args:
            query: Search query
            max_results: Maximum results
            fields: Fields to return
        
        Returns:
            List of paper dictionaries
        
        Example:
            ```python
            from crazycontext.sources.apis import SemanticScholarAPI
            
            api = SemanticScholarAPI()
            papers = api.search("machine learning", max_results=5)
            ```
        """
        if fields is None:
            fields = ['paperId', 'title', 'abstract', 'year', 'authors', 'url']
        
        params = {
            'query': query,
            'limit': max_results,
            'fields': ','.join(fields)
        }
        
        try:
            url = f"{self.BASE_URL}/paper/search"
            response = requests.get(
                url,
                params=params,
                headers=self.headers,
                timeout=30
            )
            response.raise_for_status()
            
            data = response.json()
            papers = []
            
            for item in data.get('data', []):
                paper = {
                    'id': item.get('paperId', ''),
                    'title': item.get('title', ''),
                    'summary': item.get('abstract', ''),
                    'year': item.get('year', ''),
                    'authors': [a.get('name', '') for a in item.get('authors', [])],
                    'url': item.get('url', ''),
                    'pdf_url': None,
                    'source': 'semantic_scholar'
                }
                papers.append(paper)
            
            logger.info(f"Semantic Scholar: Found {len(papers)} papers for '{query}'")
            return papers
        
        except Exception as e:
            logger.error(f"Semantic Scholar API error: {e}")
            raise APIError(f"Semantic Scholar search failed: {e}")


def normalize_paper(paper: Dict) -> Dict:
    """
    Normalize paper data from different sources to consistent format.
    
    Args:
        paper: Paper dictionary from any source
    
    Returns:
        Normalized paper dictionary
    
    Example:
        ```python
        from crazycontext.sources.apis import normalize_paper
        
        arxiv_paper = {...}  # From arXiv
        normalized = normalize_paper(arxiv_paper)
        ```
    """
    return {
        'id': paper.get('id', ''),
        'title': paper.get('title', '').strip(),
        'summary': paper.get('summary', paper.get('abstract', '')).strip(),
        'authors': paper.get('authors', []),
        'year': paper.get('year', paper.get('published', ''))[:4] if paper.get('year') or paper.get('published') else '',
        'url': paper.get('url', ''),
        'pdf_url': paper.get('pdf_url'),
        'source': paper.get('source', 'unknown')
    }
