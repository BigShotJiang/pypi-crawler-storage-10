"""
Web Source Handler for CrazyContext.

Downloads and manages web content for context building.
"""

import os
import logging
from typing import List, Dict, Optional
from pathlib import Path

from ..core import downloader, converter
from ..utils import file_utils

logger = logging.getLogger(__name__)


class WebSource:
    """
    Handle web content as a context source.
    
    Downloads websites, converts to Markdown, and provides search interface.
    
    Example:
        ```python
        from crazycontext.sources import WebSource
        
        web = WebSource(cache_dir="./web_cache")
        
        # Download documentation
        web.download_urls([
            "https://docs.python.org/3/tutorial/",
            "https://pytorch.org/tutorials/"
        ])
        
        # Search downloaded content
        results = web.search("neural networks")
        ```
    """
    
    def __init__(
        self,
        cache_dir: str = "./cache/web",
        auto_convert: bool = True
    ):
        """
        Initialize web source handler.
        
        Args:
            cache_dir: Directory to cache downloaded content
            auto_convert: Automatically convert HTML to Markdown
        """
        self.cache_dir = file_utils.ensure_dir(cache_dir)
        self.auto_convert = auto_convert
        self.downloads_log = []
        
        logger.info(f"WebSource initialized (cache: {self.cache_dir})")
    
    def download_url(
        self,
        url: str,
        **kwargs
    ) -> Dict:
        """
        Download a single URL.
        
        Args:
            url: URL to download
            **kwargs: Additional arguments for downloader
        
        Returns:
            Download result dictionary
        
        Example:
            ```python
            result = web.download_url("https://example.com")
            print(f"Status: {result['status']}")
            ```
        """
        logger.info(f"Downloading: {url}")
        
        result = downloader.download_url(
            url,
            output_dir=self.cache_dir,
            **kwargs
        )
        
        self.downloads_log.append(result)
        
        # Auto-convert if enabled and successful
        if self.auto_convert and result['status'] == 'success':
            self._convert_file(result['file'])
        
        return result
    
    def download_urls(
        self,
        urls: List[str],
        **kwargs
    ) -> List[Dict]:
        """
        Download multiple URLs.
        
        Args:
            urls: List of URLs to download
            **kwargs: Additional arguments for downloader
        
        Returns:
            List of download results
        
        Example:
            ```python
            results = web.download_urls([
                "https://docs.python.org/",
                "https://pytorch.org/"
            ])
            
            success_count = sum(1 for r in results if r['status'] == 'success')
            print(f"Downloaded {success_count}/{len(urls)} sites")
            ```
        """
        logger.info(f"Downloading {len(urls)} URLs")
        
        results = downloader.download_sites(
            urls,
            output_dir=self.cache_dir,
            **kwargs
        )
        
        self.downloads_log.extend(results)
        
        # Auto-convert successful downloads
        if self.auto_convert:
            for result in results:
                if result['status'] == 'success':
                    self._convert_file(result['file'])
        
        return results
    
    def _convert_file(self, file_path: str) -> Optional[str]:
        """Convert HTML file to Markdown."""
        if not file_path or file_path == "-":
            return None
        
        try:
            conv = converter.MarkdownConverter()
            md_path = conv.convert_file(file_path)
            logger.debug(f"Converted: {file_path} -> {md_path}")
            return md_path
        except Exception as e:
            logger.error(f"Error converting {file_path}: {e}")
            return None
    
    def convert_all(self, overwrite: bool = False) -> int:
        """
        Convert all HTML files in cache to Markdown.
        
        Args:
            overwrite: Overwrite existing .md files
        
        Returns:
            Number of files converted
        
        Example:
            ```python
            # Convert any HTML files that haven't been converted yet
            count = web.convert_all(overwrite=False)
            print(f"Converted {count} files")
            ```
        """
        conv = converter.MarkdownConverter()
        results = conv.convert_directory(
            self.cache_dir,
            recursive=True,
            overwrite=overwrite
        )
        
        logger.info(f"Converted {len(results)} files")
        return len(results)
    
    def search(
        self,
        query: str,
        search_type: str = "keyword",
        **kwargs
    ) -> List[Dict]:
        """
        Search downloaded content.
        
        Args:
            query: Search query
            search_type: "keyword" or "fuzzy"
            **kwargs: Additional search arguments
        
        Returns:
            List of search results
        
        Example:
            ```python
            # Keyword search
            results = web.search("machine learning")
            
            # Fuzzy search (typo-tolerant)
            results = web.search(
                "machne lerning",  # Typos OK!
                search_type="fuzzy",
                threshold=70
            )
            
            for result in results:
                print(f"{result['file']}: {result['match_count']} matches")
            ```
        """
        from ..search import keyword, fuzzy
        
        if search_type == "fuzzy":
            return fuzzy.fuzzy_search_in_directory(
                self.cache_dir,
                query,
                **kwargs
            )
        else:
            return keyword.search_in_directory(
                self.cache_dir,
                query,
                **kwargs
            )
    
    def get_cached_files(
        self,
        extensions: Optional[List[str]] = None
    ) -> List[str]:
        """
        Get list of cached files.
        
        Args:
            extensions: Filter by extensions (default: all text files)
        
        Returns:
            List of file paths
        
        Example:
            ```python
            # Get all markdown files
            md_files = web.get_cached_files([".md"])
            
            # Get all cached files
            all_files = web.get_cached_files()
            ```
        """
        if extensions is None:
            extensions = ['.html', '.htm', '.md', '.txt']
        
        return file_utils.get_files_by_extension(
            self.cache_dir,
            extensions,
            recursive=True
        )
    
    def get_cache_size(self) -> int:
        """
        Get total size of cached content in bytes.
        
        Returns:
            Cache size in bytes
        
        Example:
            ```python
            size_bytes = web.get_cache_size()
            size_mb = size_bytes / (1024 * 1024)
            print(f"Cache size: {size_mb:.2f} MB")
            ```
        """
        return file_utils.get_directory_size(self.cache_dir)
    
    def clear_cache(
        self,
        older_than_days: Optional[int] = None
    ) -> int:
        """
        Clear cached files.
        
        Args:
            older_than_days: Only delete files older than N days (None = all)
        
        Returns:
            Number of files deleted
        
        Example:
            ```python
            # Delete files older than 7 days
            deleted = web.clear_cache(older_than_days=7)
            print(f"Deleted {deleted} old files")
            ```
        """
        deleted = file_utils.clean_directory(
            self.cache_dir,
            older_than_days=older_than_days
        )
        
        logger.info(f"Cleared {deleted} cached files")
        return deleted
    
    def get_download_stats(self) -> Dict:
        """
        Get download statistics.
        
        Returns:
            Dictionary with download stats
        
        Example:
            ```python
            stats = web.get_download_stats()
            print(f"Total downloads: {stats['total']}")
            print(f"Successful: {stats['success']}")
            print(f"Failed: {stats['failed']}")
            ```
        """
        total = len(self.downloads_log)
        success = sum(1 for d in self.downloads_log if d['status'] == 'success')
        failed = sum(1 for d in self.downloads_log if d['status'] == 'failed')
        
        return {
            "total": total,
            "success": success,
            "failed": failed,
            "cache_size": self.get_cache_size(),
            "cache_files": len(self.get_cached_files())
        }
