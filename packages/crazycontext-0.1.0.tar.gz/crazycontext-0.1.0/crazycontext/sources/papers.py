"""
Academic Papers Source Handler for CrazyContext.

Fetches papers from arXiv, Semantic Scholar, and other sources.
"""

import os
import logging
from typing import List, Dict, Optional

from .apis import ArxivAPI, SemanticScholarAPI, APIError, normalize_paper
from ..utils import file_utils
from ..search import keyword

logger = logging.getLogger(__name__)


class PapersSource:
    """
    Handle academic papers as a context source.
    
    Searches and caches papers from multiple academic databases.
    
    Example:
        ```python
        from crazycontext.sources import PapersSource
        
        papers = PapersSource(cache_dir="./papers_cache")
        
        # Search papers
        results = papers.search("neural networks", max_results=10)
        
        # Get paper details
        for paper in results:
            print(f"{paper['title']} ({paper['year']})")
        ```
    """
    
    def __init__(
        self,
        cache_dir: str = "./cache/papers",
        semantic_scholar_key: Optional[str] = None
    ):
        """
        Initialize papers source handler.
        
        Args:
            cache_dir: Directory to cache paper metadata
            semantic_scholar_key: Optional Semantic Scholar API key
        """
        self.cache_dir = file_utils.ensure_dir(cache_dir)
        self.s2_api = SemanticScholarAPI(api_key=semantic_scholar_key)
        self.cached_papers = []
        
        logger.info(f"PapersSource initialized (cache: {self.cache_dir})")
    
    def search(
        self,
        query: str,
        sources: Optional[List[str]] = None,
        max_results: int = 10
    ) -> List[Dict]:
        """
        Search for papers across multiple sources.
        
        Args:
            query: Search query
            sources: Sources to search (default: ["arxiv", "semantic_scholar"])
            max_results: Maximum results per source
        
        Returns:
            List of paper dictionaries
        
        Example:
            ```python
            papers_source = PapersSource()
            
            # Search all sources
            results = papers_source.search("deep learning", max_results=5)
            
            # Search specific source
            results = papers_source.search(
                "transformers",
                sources=["arxiv"],
                max_results=10
            )
            
            for paper in results:
                print(f"Title: {paper['title']}")
                print(f"Authors: {', '.join(paper['authors'])}")
                print(f"Source: {paper['source']}")
            ```
        """
        if sources is None:
            sources = ["arxiv", "semantic_scholar"]
        
        all_papers = []
        
        # Search arXiv
        if "arxiv" in sources:
            try:
                arxiv_papers = ArxivAPI.search(query, max_results=max_results)
                all_papers.extend([normalize_paper(p) for p in arxiv_papers])
                logger.info(f"Found {len(arxiv_papers)} papers from arXiv")
            except APIError as e:
                logger.error(f"arXiv search failed: {e}")
        
        # Search Semantic Scholar
        if "semantic_scholar" in sources:
            try:
                s2_papers = self.s2_api.search(query, max_results=max_results)
                all_papers.extend([normalize_paper(p) for p in s2_papers])
                logger.info(f"Found {len(s2_papers)} papers from Semantic Scholar")
            except APIError as e:
                logger.error(f"Semantic Scholar search failed: {e}")
        
        # Cache results
        self.cached_papers.extend(all_papers)
        self._save_to_cache(all_papers)
        
        logger.info(f"Total papers found: {len(all_papers)}")
        
        return all_papers
    
    def _save_to_cache(self, papers: List[Dict]):
        """Save paper metadata to cache."""
        import json
        
        for paper in papers:
            # Create safe filename
            paper_id = paper.get('id', '').replace('/', '_').replace(':', '_')
            if not paper_id:
                continue
            
            cache_file = os.path.join(self.cache_dir, f"{paper_id}.json")
            
            try:
                with open(cache_file, 'w', encoding='utf-8') as f:
                    json.dump(paper, f, indent=2, ensure_ascii=False)
                logger.debug(f"Cached paper: {cache_file}")
            except Exception as e:
                logger.error(f"Error caching paper {paper_id}: {e}")
    
    def get_cached_papers(self) -> List[Dict]:
        """
        Get all cached papers.
        
        Returns:
            List of cached paper dictionaries
        
        Example:
            ```python
            cached = papers_source.get_cached_papers()
            print(f"Found {len(cached)} cached papers")
            ```
        """
        import json
        
        papers = []
        cache_files = file_utils.get_files_by_extension(
            self.cache_dir,
            ['.json'],
            recursive=False
        )
        
        for cache_file in cache_files:
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    paper = json.load(f)
                    papers.append(paper)
            except Exception as e:
                logger.error(f"Error loading cached paper {cache_file}: {e}")
        
        return papers
    
    def search_cached(
        self,
        query: str,
        max_results: int = 10
    ) -> List[Dict]:
        """
        Search cached papers by keyword.
        
        Args:
            query: Search query
            max_results: Maximum results
        
        Returns:
            List of matching papers
        
        Example:
            ```python
            # Search locally cached papers
            results = papers_source.search_cached("attention mechanism")
            ```
        """
        cached = self.get_cached_papers()
        
        matches = []
        query_lower = query.lower()
        
        for paper in cached:
            # Search in title and summary
            text = f"{paper.get('title', '')} {paper.get('summary', '')}".lower()
            
            if query_lower in text:
                # Count matches
                match_count = text.count(query_lower)
                paper['_match_count'] = match_count
                matches.append(paper)
        
        # Sort by match count
        matches.sort(key=lambda x: x.get('_match_count', 0), reverse=True)
        
        return matches[:max_results]
    
    def filter_by_year(
        self,
        papers: List[Dict],
        min_year: Optional[int] = None,
        max_year: Optional[int] = None
    ) -> List[Dict]:
        """
        Filter papers by publication year.
        
        Args:
            papers: List of papers
            min_year: Minimum year (inclusive)
            max_year: Maximum year (inclusive)
        
        Returns:
            Filtered papers
        
        Example:
            ```python
            papers = papers_source.search("AI")
            recent = papers_source.filter_by_year(papers, min_year=2020)
            ```
        """
        filtered = []
        
        for paper in papers:
            year_str = str(paper.get('year', ''))
            if not year_str:
                continue
            
            try:
                year = int(year_str[:4])
                
                if min_year and year < min_year:
                    continue
                if max_year and year > max_year:
                    continue
                
                filtered.append(paper)
            except (ValueError, TypeError):
                continue
        
        return filtered
    
    def get_stats(self) -> Dict:
        """
        Get statistics about cached papers.
        
        Returns:
            Dictionary with statistics
        
        Example:
            ```python
            stats = papers_source.get_stats()
            print(f"Cached papers: {stats['total_papers']}")
            print(f"Sources: {stats['by_source']}")
            ```
        """
        cached = self.get_cached_papers()
        
        by_source = {}
        by_year = {}
        
        for paper in cached:
            # Count by source
            source = paper.get('source', 'unknown')
            by_source[source] = by_source.get(source, 0) + 1
            
            # Count by year
            year = str(paper.get('year', ''))[:4]
            if year:
                by_year[year] = by_year.get(year, 0) + 1
        
        return {
            'total_papers': len(cached),
            'by_source': by_source,
            'by_year': by_year,
            'cache_size': file_utils.get_directory_size(self.cache_dir)
        }
    
    def clear_cache(self) -> int:
        """
        Clear cached papers.
        
        Returns:
            Number of files deleted
        
        Example:
            ```python
            deleted = papers_source.clear_cache()
            print(f"Cleared {deleted} cached papers")
            ```
        """
        deleted = file_utils.clean_directory(self.cache_dir, extensions=['.json'])
        self.cached_papers = []
        logger.info(f"Cleared {deleted} cached papers")
        return deleted
