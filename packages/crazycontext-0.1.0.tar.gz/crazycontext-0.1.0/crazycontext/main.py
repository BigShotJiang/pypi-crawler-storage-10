"""
Main CrazyContext API

The ultimate context builder for LLM applications.
"""

import logging
from typing import List, Dict, Optional, Union

from .sources import WebSource, LocalSource
from .search import keyword, fuzzy
from .utils import file_utils, logging_utils

logger = logging.getLogger(__name__)


class CrazyContext:
    """
    The ultimate context builder for LLM applications.
    
    Unifies web scraping, local files, and search into a simple API.
    
    Features:
    - Multi-source context (web, local files)
    - Intelligent search (keyword + fuzzy)
    - Smart caching
    - LLM-ready output
    
    Example:
        ```python
        from crazycontext import CrazyContext
        
        cc = CrazyContext()
        
        # Download documentation
        cc.from_urls(["https://docs.python.org/3/tutorial/"])
        
        # Search content
        results = cc.search("list comprehension")
        
        # Get context for LLM
        context = cc.build_context(results, max_length=5000)
        ```
    """
    
    def __init__(
        self,
        cache_dir: str = "./cache",
        auto_convert: bool = True,
        log_level: str = "INFO"
    ):
        """
        Initialize CrazyContext.
        
        Args:
            cache_dir: Directory for cached content
            auto_convert: Auto-convert HTML to Markdown
            log_level: Logging level (DEBUG, INFO, WARNING, ERROR)
        
        Example:
            ```python
            cc = CrazyContext(
                cache_dir="./my_cache",
                auto_convert=True,
                log_level="INFO"
            )
            ```
        """
        # Setup logging
        logging_utils.setup_logging(level=log_level)
        
        # Initialize sources
        web_cache = file_utils.ensure_dir(f"{cache_dir}/web")
        self.web = WebSource(cache_dir=web_cache, auto_convert=auto_convert)
        self.local = LocalSource()
        
        self.cache_dir = cache_dir
        self.auto_convert = auto_convert
        
        logger.info(f"CrazyContext initialized (cache: {cache_dir})")
    
    def from_url(self, url: str, **kwargs) -> Dict:
        """
        Download and cache a single URL.
        
        Args:
            url: URL to download
            **kwargs: Additional download options
        
        Returns:
            Download result
        
        Example:
            ```python
            result = cc.from_url("https://example.com")
            print(f"Status: {result['status']}")
            ```
        """
        return self.web.download_url(url, **kwargs)
    
    def from_urls(self, urls: List[str], **kwargs) -> List[Dict]:
        """
        Download and cache multiple URLs.
        
        Args:
            urls: List of URLs
            **kwargs: Additional download options
        
        Returns:
            List of download results
        
        Example:
            ```python
            results = cc.from_urls([
                "https://docs.python.org/3/",
                "https://pytorch.org/tutorials/"
            ])
            
            success = sum(1 for r in results if r['status'] == 'success')
            print(f"Downloaded {success}/{len(urls)} sites")
            ```
        """
        return self.web.download_urls(urls, **kwargs)
    
    def add_local_file(self, file_path: str) -> bool:
        """
        Add a local file to the index.
        
        Args:
            file_path: Path to file
        
        Returns:
            True if added successfully
        
        Example:
            ```python
            cc.add_local_file("my_notes.md")
            ```
        """
        return self.local.add_file(file_path)
    
    def add_local_directory(
        self,
        directory: str,
        extensions: Optional[List[str]] = None,
        recursive: bool = True
    ) -> int:
        """
        Add all files from a directory to the index.
        
        Args:
            directory: Directory path
            extensions: File extensions to include
            recursive: Search subdirectories
        
        Returns:
            Number of files added
        
        Example:
            ```python
            count = cc.add_local_directory(
                "./research",
                extensions=[".md", ".txt"],
                recursive=True
            )
            print(f"Indexed {count} files")
            ```
        """
        return self.local.add_directory(directory, extensions, recursive)
    
    def search(
        self,
        query: str,
        sources: Optional[List[str]] = None,
        search_type: str = "keyword",
        **kwargs
    ) -> List[Dict]:
        """
        Search across all sources.
        
        Args:
            query: Search query
            sources: Sources to search (default: all) - ["web", "local"]
            search_type: "keyword" or "fuzzy"
            **kwargs: Additional search options
        
        Returns:
            Combined search results
        
        Example:
            ```python
            # Search everything
            results = cc.search("machine learning")
            
            # Search only web
            results = cc.search(
                "neural networks",
                sources=["web"]
            )
            
            # Fuzzy search (typo-tolerant)
            results = cc.search(
                "machne lerning",
                search_type="fuzzy",
                threshold=70
            )
            ```
        """
        if sources is None:
            sources = ["web", "local"]
        
        all_results = []
        
        # Search web cache
        if "web" in sources:
            web_results = self.web.search(query, search_type, **kwargs)
            for result in web_results:
                result["source"] = "web"
            all_results.extend(web_results)
        
        # Search local files
        if "local" in sources:
            local_results = self.local.search(query, search_type, **kwargs)
            for result in local_results:
                result["source"] = "local"
            all_results.extend(local_results)
        
        # Sort by relevance
        all_results.sort(key=lambda x: x.get('match_count', 0), reverse=True)
        
        logger.info(f"Search '{query}' found {len(all_results)} results")
        
        return all_results
    
    def build_context(
        self,
        results: List[Dict],
        max_length: Optional[int] = None,
        include_sources: bool = True
    ) -> str:
        """
        Build LLM-ready context from search results.
        
        Args:
            results: Search results from search()
            max_length: Maximum context length in characters
            include_sources: Include source file information
        
        Returns:
            Formatted context string
        
        Example:
            ```python
            results = cc.search("python tutorials")
            context = cc.build_context(results, max_length=5000)
            
            # Use with LLM
            prompt = f"{context}\n\nQuestion: How do I use list comprehensions?"
            ```
        """
        context_parts = []
        current_length = 0
        
        for result in results:
            # Add source header
            if include_sources:
                source_header = f"\n## Source: {result.get('file', 'Unknown')}\n"
                if max_length and current_length + len(source_header) > max_length:
                    break
                context_parts.append(source_header)
                current_length += len(source_header)
            
            # Add matches
            for match in result.get('matches', [])[:3]:  # Top 3 matches per file
                context_text = match.get('context', '')
                
                if max_length and current_length + len(context_text) > max_length:
                    break
                
                context_parts.append(context_text + "\n")
                current_length += len(context_text) + 1
        
        context = "\n".join(context_parts)
        
        logger.info(f"Built context: {current_length} characters from {len(results)} sources")
        
        return context
    
    def get_stats(self) -> Dict:
        """
        Get statistics about cached content.
        
        Returns:
            Dictionary with statistics
        
        Example:
            ```python
            stats = cc.get_stats()
            print(f"Web cache: {stats['web']['cache_size_mb']:.2f} MB")
            print(f"Local files: {stats['local']['file_count']}")
            ```
        """
        web_stats = self.web.get_download_stats()
        local_stats = self.local.get_stats()
        
        return {
            "web": {
                "downloads": web_stats['total'],
                "success": web_stats['success'],
                "failed": web_stats['failed'],
                "cache_files": web_stats['cache_files'],
                "cache_size": web_stats['cache_size'],
                "cache_size_mb": web_stats['cache_size'] / (1024 * 1024)
            },
            "local": {
                "file_count": local_stats['file_count'],
                "directory_count": local_stats['directory_count'],
                "total_size": local_stats['total_size'],
                "total_size_mb": local_stats['total_size_mb'],
                "extensions": local_stats['extensions']
            }
        }
    
    def clear_cache(
        self,
        source: str = "web",
        older_than_days: Optional[int] = None
    ) -> int:
        """
        Clear cached content.
        
        Args:
            source: "web" or "local"
            older_than_days: Only delete files older than N days
        
        Returns:
            Number of files deleted
        
        Example:
            ```python
            # Clear old web cache
            deleted = cc.clear_cache("web", older_than_days=7)
            print(f"Deleted {deleted} old files")
            ```
        """
        if source == "web":
            return self.web.clear_cache(older_than_days)
        elif source == "local":
            self.local.clear_index()
            return 0
        else:
            raise ValueError(f"Unknown source: {source}")
    
    def refresh_local_index(self) -> int:
        """
        Refresh the local file index.
        
        Returns:
            Number of files indexed
        
        Example:
            ```python
            count = cc.refresh_local_index()
            print(f"Re-indexed {count} files")
            ```
        """
        return self.local.refresh_index()
