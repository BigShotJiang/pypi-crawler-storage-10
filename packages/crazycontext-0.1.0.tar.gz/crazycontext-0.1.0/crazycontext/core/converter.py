"""
HTML to Markdown Converter for CrazyContext.

Converts HTML files to clean Markdown format for better LLM processing.
"""

import os
import logging
from typing import Optional, List, Dict
import html2text
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)


class MarkdownConverter:
    """
    Convert HTML content to Markdown format.
    
    Uses html2text for conversion with optimized settings for LLM consumption.
    
    Example:
        ```python
        from crazycontext.core.converter import MarkdownConverter
        
        converter = MarkdownConverter()
        markdown = converter.convert_html("<h1>Title</h1><p>Content</p>")
        print(markdown)
        ```
    """
    
    def __init__(
        self,
        body_width: int = 0,
        ignore_links: bool = False,
        ignore_images: bool = False,
        ignore_emphasis: bool = False
    ):
        """
        Initialize the converter.
        
        Args:
            body_width: Maximum line width (0 = no wrapping)
            ignore_links: Skip links in output
            ignore_images: Skip images in output
            ignore_emphasis: Skip bold/italic formatting
        """
        self.h2t = html2text.HTML2Text()
        self.h2t.body_width = body_width
        self.h2t.ignore_links = ignore_links
        self.h2t.ignore_images = ignore_images
        self.h2t.ignore_emphasis = ignore_emphasis
        self.h2t.unicode_snob = True  # Use unicode instead of ASCII
        self.h2t.decode_errors = 'ignore'
    
    def convert_html(self, html_content: str) -> str:
        """
        Convert HTML string to Markdown.
        
        Args:
            html_content: HTML string
        
        Returns:
            Markdown string
        
        Example:
            ```python
            html = "<h1>Hello</h1><p>World</p>"
            markdown = converter.convert_html(html)
            # Returns: "# Hello\n\nWorld"
            ```
        """
        try:
            markdown = self.h2t.handle(html_content)
            return markdown.strip()
        except Exception as e:
            logger.error(f"Error converting HTML to markdown: {e}")
            return ""
    
    def convert_file(
        self,
        input_path: str,
        output_path: Optional[str] = None,
        encoding: str = 'utf-8'
    ) -> Optional[str]:
        """
        Convert HTML file to Markdown file.
        
        Args:
            input_path: Path to HTML file
            output_path: Path for output Markdown file (default: input_path + .md)
            encoding: File encoding (default: utf-8)
        
        Returns:
            Path to output file if successful, None otherwise
        
        Example:
            ```python
            output = converter.convert_file(
                "page.html",
                "page.md"
            )
            ```
        """
        if not os.path.exists(input_path):
            logger.error(f"Input file not found: {input_path}")
            return None
        
        try:
            # Read HTML
            with open(input_path, 'r', encoding=encoding, errors='ignore') as f:
                html_content = f.read()
            
            # Convert to markdown
            markdown = self.convert_html(html_content)
            
            # Determine output path
            if output_path is None:
                output_path = input_path + '.md'
            
            # Write markdown
            os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(markdown)
            
            logger.info(f"Converted {input_path} -> {output_path}")
            return output_path
        
        except Exception as e:
            logger.error(f"Error converting file {input_path}: {e}")
            return None
    
    def convert_directory(
        self,
        directory: str,
        extensions: List[str] = None,
        recursive: bool = True,
        overwrite: bool = False
    ) -> Dict[str, str]:
        """
        Convert all HTML files in a directory to Markdown.
        
        Args:
            directory: Directory to process
            extensions: HTML extensions to process (default: [".html", ".htm"])
            recursive: Process subdirectories
            overwrite: Overwrite existing .md files
        
        Returns:
            Dictionary mapping input files to output files
        
        Example:
            ```python
            results = converter.convert_directory(
                "./downloads",
                recursive=True
            )
            print(f"Converted {len(results)} files")
            ```
        """
        if extensions is None:
            extensions = [".html", ".htm"]
        
        if not os.path.exists(directory):
            logger.error(f"Directory not found: {directory}")
            return {}
        
        results = {}
        pattern = '**/*' if recursive else '*'
        
        for ext in extensions:
            import glob
            search_pattern = os.path.join(directory, pattern + ext)
            html_files = glob.glob(search_pattern, recursive=recursive)
            
            for html_file in html_files:
                md_file = html_file + '.md'
                
                # Skip if output exists and overwrite is False
                if os.path.exists(md_file) and not overwrite:
                    logger.debug(f"Skipping {html_file} (output exists)")
                    continue
                
                output = self.convert_file(html_file, md_file)
                if output:
                    results[html_file] = output
        
        logger.info(f"Converted {len(results)} files in {directory}")
        return results


def html_to_text(html_content: str) -> str:
    """
    Convert HTML to plain text (no markdown formatting).
    
    Args:
        html_content: HTML string
    
    Returns:
        Plain text string
    
    Example:
        ```python
        from crazycontext.core.converter import html_to_text
        
        text = html_to_text("<p>Hello <b>World</b></p>")
        # Returns: "Hello World"
        ```
    """
    try:
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # Remove script and style elements
        for script in soup(["script", "style"]):
            script.decompose()
        
        # Get text
        text = soup.get_text()
        
        # Clean up whitespace
        lines = (line.strip() for line in text.splitlines())
        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
        text = ' '.join(chunk for chunk in chunks if chunk)
        
        return text
    
    except Exception as e:
        logger.error(f"Error converting HTML to text: {e}")
        return ""


def extract_title(html_content: str) -> str:
    """
    Extract title from HTML content.
    
    Args:
        html_content: HTML string
    
    Returns:
        Page title or empty string
    
    Example:
        ```python
        from crazycontext.core.converter import extract_title
        
        title = extract_title("<title>My Page</title>")
        # Returns: "My Page"
        ```
    """
    try:
        soup = BeautifulSoup(html_content, 'html.parser')
        title = soup.find('title')
        return title.string.strip() if title and title.string else ""
    except Exception:
        return ""


def extract_metadata(html_content: str) -> Dict[str, str]:
    """
    Extract metadata from HTML head section.
    
    Args:
        html_content: HTML string
    
    Returns:
        Dictionary of metadata (title, description, keywords, etc.)
    
    Example:
        ```python
        from crazycontext.core.converter import extract_metadata
        
        metadata = extract_metadata(html_content)
        print(metadata['title'])
        print(metadata['description'])
        ```
    """
    metadata = {}
    
    try:
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # Extract title
        title = soup.find('title')
        if title and title.string:
            metadata['title'] = title.string.strip()
        
        # Extract meta tags
        meta_tags = soup.find_all('meta')
        for tag in meta_tags:
            name = tag.get('name', '').lower()
            property_name = tag.get('property', '').lower()
            content = tag.get('content', '')
            
            if name and content:
                metadata[name] = content
            elif property_name and content:
                metadata[property_name] = content
        
        return metadata
    
    except Exception as e:
        logger.error(f"Error extracting metadata: {e}")
        return metadata
