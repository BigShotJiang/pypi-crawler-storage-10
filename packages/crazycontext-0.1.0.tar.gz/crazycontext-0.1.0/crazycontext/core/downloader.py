"""
Website Downloader Module for CrazyContext

Wget-based site mirroring with Python fallback for maximum compatibility.
Returns structured data for LLM pipeline integration.
"""

import os
import json
import subprocess
import shutil
import platform
import logging
from datetime import datetime
from typing import List, Dict, Optional
from urllib.parse import urlparse

import requests

logger = logging.getLogger(__name__)


def format_size(bytes_num) -> str:
    """
    Convert bytes to human-readable format.
    
    Args:
        bytes_num: Number of bytes
        
    Returns:
        Formatted string (e.g., "1.5 MB")
    """
    try:
        bytes_num = int(bytes_num)
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if bytes_num < 1024:
                return f"{bytes_num:.2f} {unit}"
            bytes_num /= 1024
        return f"{bytes_num:.2f} PB"
    except Exception:
        return "-"


def _get_wget_executable() -> Optional[str]:
    """
    Find or install wget executable.
    
    Searches for:
    1. Bundled wget binaries (in wget/ folder)
    2. System wget
    3. Auto-install on Linux (if possible)
    
    Returns:
        Path to wget executable or None if not available
    """
    arch = platform.machine().lower()
    system_raw = platform.system().lower()
    
    # Map architecture names
    arch_map = {
        "x86_64": "x64",
        "amd64": "x64",
        "i386": "x86",
        "i686": "x86",
        "arm64": "arm64",
        "aarch64": "arm64"
    }
    
    # Map system names
    sys_map = {
        "windows": "windows",
        "win32": "windows",
        "cygwin": "windows",
        "linux": "linux",
        "darwin": "macos",
        "macos": "macos"
    }
    
    folder_arch = arch_map.get(arch)
    sys_dir = sys_map.get(system_raw, system_raw)
    is_windows = sys_dir == "windows"
    wget_filename = "wget.exe" if is_windows else "wget"
    
    # Look for bundled wget in package
    package_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    candidates = []
    if folder_arch:
        candidates += [
            os.path.join(package_dir, "wget", sys_dir, folder_arch, wget_filename),
            os.path.join(package_dir, "wget", folder_arch, wget_filename),
        ]
    candidates += [
        os.path.join(package_dir, "wget", sys_dir, wget_filename),
        os.path.join(package_dir, "wget", wget_filename),
    ]
    
    # Check bundled wget
    for p in candidates:
        if os.path.isfile(p):
            logger.debug(f"Using bundled wget: {p}")
            return p
    
    # Check system wget
    system_wget = shutil.which("wget")
    if system_wget:
        logger.debug(f"Using system wget: {system_wget}")
        return system_wget
    
    # Try auto-install on Linux (best effort)
    if sys_dir == "linux":
        logger.info("Wget not found. Attempting to install...")
        try:
            subprocess.run(["apt", "update"], check=True, capture_output=True)
            subprocess.run(["apt", "install", "-y", "wget"], check=True, capture_output=True)
            logger.info("Wget installed successfully")
            return shutil.which("wget")
        except subprocess.CalledProcessError:
            logger.warning("Failed to install wget. Requires sudo access.")
        except FileNotFoundError:
            logger.debug("apt-get not available")
    
    logger.warning("Wget not found. Will use Python fallback.")
    return None


def _path_for_url(url: str, output_dir: str) -> str:
    """
    Map a URL to a local file path under output_dir.
    
    Args:
        url: URL to map
        output_dir: Base output directory
        
    Returns:
        Local file path
    """
    parsed = urlparse(url)
    host = parsed.netloc.replace(":", "_")
    path = parsed.path
    
    if not path or path.endswith('/'):
        path = path + 'index.html'
    
    # Ensure no directory traversal
    safe_parts = [p for p in path.split('/') if p and p not in ('.', '..')]
    local_path = os.path.join(output_dir, host, *safe_parts)
    os.makedirs(os.path.dirname(local_path), exist_ok=True)
    
    return local_path


def _download_sites_python(
    urls: List[str],
    output_dir: str = "downloads",
    timeout: int = 15,
    tries: int = 3
) -> List[Dict]:
    """
    Lightweight Python fallback: fetch HTML and store to disk.
    Single-page fetch per URL (no resource mirroring).
    
    Args:
        urls: List of URLs to download
        output_dir: Output directory
        timeout: Request timeout in seconds
        tries: Number of retry attempts
        
    Returns:
        List of result dictionaries
    """
    os.makedirs(output_dir, exist_ok=True)
    results: List[Dict] = []
    
    for url in urls:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            last_err = None
            resp = None
            
            # Retry logic
            for _ in range(max(1, tries)):
                try:
                    resp = requests.get(
                        url,
                        timeout=timeout,
                        headers={"User-Agent": "Mozilla/5.0 (CrazyContext/0.1.0)"}
                    )
                    break
                except Exception as e:
                    last_err = e
            
            if resp is None:
                raise last_err or RuntimeError("Request failed")
            
            # Handle 404
            if resp.status_code == 404:
                results.append({
                    "timestamp": now,
                    "url": url,
                    "file": "-",
                    "status": "404 not found",
                    "size": "-"
                })
                logger.warning(f"404 Not Found: {url}")
                continue
            
            resp.raise_for_status()
            
            # Save to disk
            local_path = _path_for_url(url, output_dir)
            with open(local_path, "wb") as f:
                f.write(resp.content)
            
            size = format_size(len(resp.content))
            results.append({
                "timestamp": now,
                "url": url,
                "file": local_path,
                "status": "success",
                "size": size
            })
            logger.info(f"Downloaded: {local_path} ({size})")
            
        except Exception as e:
            results.append({
                "timestamp": now,
                "url": url,
                "file": "-",
                "status": "failed",
                "size": "-",
                "error": str(e)
            })
            logger.error(f"Failed to download {url}: {e}")
    
    return results


def download_url(
    url: str,
    output_dir: str = "downloads",
    **kwargs
) -> Dict:
    """
    Download a single URL.
    
    Args:
        url: URL to download
        output_dir: Output directory
        **kwargs: Additional arguments for download_sites()
        
    Returns:
        Download result dictionary
    """
    results = download_sites([url], output_dir=output_dir, **kwargs)
    return results[0] if results else {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "url": url,
        "file": "-",
        "status": "failed",
        "size": "-"
    }


def download_sites(
    urls: List[str],
    output_dir: str = "downloads",
    rate_limit: str = "100k",
    wait_time: int = 1,
    timeout: int = 15,
    tries: int = 3,
    use_wget: bool = True
) -> List[Dict]:
    """
    Download and mirror multiple websites.
    
    Uses wget for full site mirroring with resources, or Python fallback
    for simple page fetching.
    
    Args:
        urls: List of URLs to download
        output_dir: Directory to save downloaded content (default: "downloads")
        rate_limit: wget rate limit (default: "100k")
        wait_time: Wait time between requests in seconds (default: 1)
        timeout: Request timeout in seconds (default: 15)
        tries: Number of retry attempts (default: 3)
        use_wget: Try to use wget if available (default: True)
    
    Returns:
        List of dictionaries with download results:
        ```python
        [
            {
                "timestamp": "2025-10-18 23:30:00",
                "url": "https://example.com",
                "file": "./downloads/example.com/index.html",
                "status": "success",  # or "failed", "404 not found", etc.
                "size": "15.2 KB"
            },
            ...
        ]
        ```
    
    Example:
        ```python
        from crazycontext.core import downloader
        
        results = downloader.download_sites([
            "https://docs.python.org/3/tutorial/",
            "https://pytorch.org/tutorials/"
        ])
        
        for r in results:
            print(f"{r['url']}: {r['status']}")
        ```
    """
    if not urls:
        logger.warning("No URLs provided to download")
        return []
    
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    logger.info(f"Starting download of {len(urls)} URL(s)")
    
    # Try wget if requested
    wget_exec = _get_wget_executable() if use_wget else None
    
    # Use Python fallback if wget not available
    if not wget_exec:
        logger.info("Using Python fallback downloader (single-page fetch)")
        results = _download_sites_python(
            urls=urls,
            output_dir=output_dir,
            timeout=timeout,
            tries=tries
        )
        _log_summary(results)
        return results
    
    # Use wget for full site mirroring
    logger.info(f"Using wget: {wget_exec}")
    results = []
    
    for url in urls:
        logger.info(f"Processing: {url}")
        url_has_result = False
        
        try:
            process = subprocess.Popen([
                wget_exec,
                "-r", "-m", "-c",  # Recursive, mirror, continue
                "--no-parent",  # Don't ascend to parent directory
                "--convert-links",  # Convert links for offline viewing
                "--adjust-extension",  # Add .html extension if needed
                "--page-requisites",  # Download CSS, JS, images
                f"--limit-rate={rate_limit}",
                "--random-wait",
                f"--wait={wait_time}",
                f"--timeout={timeout}",
                f"--tries={tries}",
                "--no-clobber",  # Don't overwrite existing files
                "--no-check-certificate",
                "--retry-connrefused",
                "-e", "robots=off",
                "--user-agent=Mozilla/5.0 (CrazyContext/0.1.0)",
                f"--directory-prefix={output_dir}",
                url
            ], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            
            # Parse wget output
            for line in process.stdout:
                now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                line = line.strip()
                
                # Check for errors
                if "ERROR 404" in line or "404 Not Found" in line:
                    results.append({
                        "timestamp": now,
                        "url": url,
                        "file": "-",
                        "status": "404 not found",
                        "size": "-"
                    })
                    logger.warning(f"404 Not Found: {url}")
                    continue
                
                elif "403 Forbidden" in line:
                    results.append({
                        "timestamp": now,
                        "url": url,
                        "file": "-",
                        "status": "403 forbidden",
                        "size": "-"
                    })
                    logger.warning(f"403 Forbidden: {url}")
                    continue
                
                # Parse successful downloads
                elif "saved [" in line and "'" in line:
                    try:
                        path = line.split("'")[1]
                        raw_size = line.split("saved [")[-1].split("]")[0]
                        byte_size = raw_size.split("/")[-1]
                        size = format_size(byte_size)
                        
                        results.append({
                            "timestamp": now,
                            "url": url,
                            "file": path,
                            "status": "success",
                            "size": size
                        })
                        logger.debug(f"Downloaded: {path} ({size})")
                        url_has_result = True
                    except Exception as e:
                        logger.debug(f"Error parsing download line: {e}")
                
                # Parse skipped files
                elif "not modified" in line and "'" in line:
                    try:
                        path = line.split("'")[1]
                        results.append({
                            "timestamp": now,
                            "url": url,
                            "file": path,
                            "status": "not modified",
                            "size": "-"
                        })
                        logger.debug(f"Skipped (not modified): {path}")
                        url_has_result = True
                    except Exception as e:
                        logger.debug(f"Error parsing skip line: {e}")
            
            process.wait()
            
            # If no result found, mark as failed
            if not url_has_result:
                now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                results.append({
                    "timestamp": now,
                    "url": url,
                    "file": "-",
                    "status": "failed",
                    "size": "-"
                })
                logger.error(f"Failed to download: {url}")
        
        except Exception as e:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            results.append({
                "timestamp": now,
                "url": url,
                "file": "-",
                "status": "failed",
                "size": "-",
                "error": str(e)
            })
            logger.error(f"Error downloading {url}: {e}")
    
    _log_summary(results)
    return results


def _log_summary(results: List[Dict]) -> None:
    """Log download summary statistics."""
    success = sum(r['status'] == 'success' for r in results)
    skipped = sum(r['status'] == 'not modified' for r in results)
    failed = sum(r['status'] in ['failed', '404 not found', '403 forbidden'] for r in results)
    
    logger.info(
        f"Download complete: {success} success, {skipped} skipped, {failed} failed"
    )


def save_results_to_log(results: List[Dict], log_path: str = "download_log.txt") -> None:
    """
    Append download results to a log file.
    
    Args:
        results: List of result dictionaries from download_sites()
        log_path: Path to log file (default: "download_log.txt")
    
    Example:
        ```python
        results = download_sites(["https://example.com"])
        save_results_to_log(results, "my_downloads.log")
        ```
    """
    if not results:
        return
    
    with open(log_path, "a", encoding="utf-8") as log_file:
        for result in results:
            log_file.write(
                f"[{result['timestamp']}] {result['url']} | "
                f"{result['file']} | {result['status']} | {result['size']}\n"
            )
    
    logger.info(f"Results saved to {log_path}")
