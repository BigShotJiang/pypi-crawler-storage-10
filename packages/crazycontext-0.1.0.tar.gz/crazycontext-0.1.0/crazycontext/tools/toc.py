"""
Table of Contents (TOC) Tool for CrazyContext.

Extract TOC from documents and provide structured context.
"""

import os
import re
import logging
from typing import List, Dict, Optional, Tuple
from pathlib import Path

logger = logging.getLogger(__name__)


class TOCExtractor:
    """
    Extract table of contents from documents.
    
    Features:
    - Extract from HTML headers
    - Extract from Markdown headers
    - Build hierarchical structure
    - Get context for each section
    - Return complete context with TOC
    
    Example:
        ```python
        from crazycontext.tools import TOCExtractor
        
        extractor = TOCExtractor()
        
        # Extract TOC from file
        toc = extractor.extract_from_file("document.md")
        
        # Get context for all sections
        context = extractor.get_all_context("document.md")
        print(context)
        ```
    """
    
    def __init__(self):
        """Initialize TOC extractor."""
        logger.info("TOCExtractor initialized")
    
    def extract_from_markdown(self, content: str) -> List[Dict]:
        """
        Extract TOC from Markdown content.
        
        Args:
            content: Markdown content
        
        Returns:
            List of TOC entries with hierarchy
        
        Example:
            ```python
            content = "# Title\\n## Section 1\\n### Subsection"
            toc = extractor.extract_from_markdown(content)
            # Returns: [
            #   {'level': 1, 'title': 'Title', 'line': 0},
            #   {'level': 2, 'title': 'Section 1', 'line': 1},
            #   ...
            # ]
            ```
        """
        toc = []
        lines = content.split('\n')
        
        for idx, line in enumerate(lines):
            # Match markdown headers (# Header)
            match = re.match(r'^(#{1,6})\s+(.+)$', line.strip())
            if match:
                level = len(match.group(1))
                title = match.group(2).strip()
                
                toc.append({
                    'level': level,
                    'title': title,
                    'line': idx,
                    'type': 'markdown'
                })
        
        logger.debug(f"Extracted {len(toc)} markdown headers")
        return toc
    
    def extract_from_html(self, content: str) -> List[Dict]:
        """
        Extract TOC from HTML content.
        
        Args:
            content: HTML content
        
        Returns:
            List of TOC entries
        
        Example:
            ```python
            html = "<h1>Title</h1><h2>Section</h2>"
            toc = extractor.extract_from_html(html)
            ```
        """
        try:
            from bs4 import BeautifulSoup
        except ImportError:
            logger.warning("BeautifulSoup not available, using regex")
            return self._extract_html_regex(content)
        
        toc = []
        soup = BeautifulSoup(content, 'html.parser')
        
        # Find all headers (h1-h6)
        headers = soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
        
        for idx, header in enumerate(headers):
            level = int(header.name[1])  # Extract number from h1, h2, etc.
            title = header.get_text().strip()
            
            toc.append({
                'level': level,
                'title': title,
                'line': idx,
                'type': 'html'
            })
        
        logger.debug(f"Extracted {len(toc)} HTML headers")
        return toc
    
    def _extract_html_regex(self, content: str) -> List[Dict]:
        """Extract headers from HTML using regex (fallback)."""
        toc = []
        
        # Match <h1>...</h1> through <h6>...</h6>
        pattern = r'<h([1-6])[^>]*>(.*?)</h\1>'
        matches = re.finditer(pattern, content, re.IGNORECASE | re.DOTALL)
        
        for idx, match in enumerate(matches):
            level = int(match.group(1))
            title = re.sub(r'<[^>]+>', '', match.group(2)).strip()
            
            toc.append({
                'level': level,
                'title': title,
                'line': idx,
                'type': 'html'
            })
        
        return toc
    
    def extract_from_file(self, file_path: str) -> List[Dict]:
        """
        Extract TOC from a file.
        
        Args:
            file_path: Path to file
        
        Returns:
            List of TOC entries
        
        Example:
            ```python
            toc = extractor.extract_from_file("docs/guide.md")
            for entry in toc:
                print(f"{'  ' * (entry['level']-1)}{entry['title']}")
            ```
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        # Read file
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
        except Exception as e:
            logger.error(f"Error reading {file_path}: {e}")
            return []
        
        # Determine file type and extract
        ext = Path(file_path).suffix.lower()
        
        if ext in ['.md', '.markdown']:
            return self.extract_from_markdown(content)
        elif ext in ['.html', '.htm']:
            return self.extract_from_html(content)
        else:
            # Try markdown first, then HTML
            toc = self.extract_from_markdown(content)
            if not toc:
                toc = self.extract_from_html(content)
            return toc
    
    def get_section_content(
        self,
        content: str,
        toc_entry: Dict,
        next_entry: Optional[Dict] = None
    ) -> str:
        """
        Get content for a specific section.
        
        Args:
            content: Full document content
            toc_entry: TOC entry for section
            next_entry: Next TOC entry (to know where section ends)
        
        Returns:
            Section content
        
        Example:
            ```python
            toc = extractor.extract_from_markdown(content)
            section_content = extractor.get_section_content(
                content,
                toc[0],
                toc[1]
            )
            ```
        """
        lines = content.split('\n')
        start_line = toc_entry['line']
        
        # Determine end line
        if next_entry:
            end_line = next_entry['line']
        else:
            end_line = len(lines)
        
        # Extract section content
        section_lines = lines[start_line:end_line]
        section_content = '\n'.join(section_lines)
        
        return section_content.strip()
    
    def get_all_context(
        self,
        file_path: str,
        include_toc: bool = True
    ) -> str:
        """
        Get complete context with TOC structure.
        
        Args:
            file_path: Path to file
            include_toc: Include TOC at the beginning
        
        Returns:
            Complete context with TOC structure
        
        Example:
            ```python
            # Get full document context with TOC
            context = extractor.get_all_context("guide.md")
            
            # Use with LLM
            prompt = f"Based on this documentation:\\n{context}\\n\\nQuestion: ..."
            ```
        """
        # Extract TOC
        toc = self.extract_from_file(file_path)
        
        if not toc:
            # No TOC found, return raw content
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    return f.read()
            except Exception as e:
                logger.error(f"Error reading {file_path}: {e}")
                return ""
        
        # Read full content
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # Build context with TOC
        parts = []
        
        # Add TOC listing
        if include_toc:
            parts.append("# Table of Contents\n")
            for entry in toc:
                indent = "  " * (entry['level'] - 1)
                parts.append(f"{indent}- {entry['title']}\n")
            parts.append("\n---\n\n")
        
        # Add sections with context
        for idx, entry in enumerate(toc):
            # Section header
            parts.append(f"{'#' * entry['level']} {entry['title']}\n\n")
            
            # Section content
            next_entry = toc[idx + 1] if idx + 1 < len(toc) else None
            section_content = self.get_section_content(content, entry, next_entry)
            
            # Remove the header line from content (it's already added)
            section_lines = section_content.split('\n')[1:]
            section_text = '\n'.join(section_lines).strip()
            
            if section_text:
                parts.append(section_text + "\n\n")
        
        full_context = "".join(parts)
        
        logger.info(
            f"Built context from {file_path}: "
            f"{len(toc)} sections, {len(full_context)} chars"
        )
        
        return full_context
    
    def get_context_by_sections(
        self,
        file_path: str,
        max_chars: Optional[int] = None
    ) -> List[Dict]:
        """
        Get context organized by sections.
        
        Args:
            file_path: Path to file
            max_chars: Maximum characters per section
        
        Returns:
            List of sections with content
        
        Example:
            ```python
            sections = extractor.get_context_by_sections("guide.md")
            
            for section in sections:
                print(f"Section: {section['title']}")
                print(f"Content: {section['content'][:100]}...")
            ```
        """
        toc = self.extract_from_file(file_path)
        
        if not toc:
            return []
        
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        sections = []
        
        for idx, entry in enumerate(toc):
            next_entry = toc[idx + 1] if idx + 1 < len(toc) else None
            section_content = self.get_section_content(content, entry, next_entry)
            
            # Truncate if needed
            if max_chars and len(section_content) > max_chars:
                section_content = section_content[:max_chars] + "..."
            
            sections.append({
                'level': entry['level'],
                'title': entry['title'],
                'content': section_content,
                'char_count': len(section_content)
            })
        
        return sections
    
    def build_hierarchy(self, toc: List[Dict]) -> Dict:
        """
        Build hierarchical structure from flat TOC.
        
        Args:
            toc: Flat TOC list
        
        Returns:
            Nested dictionary structure
        
        Example:
            ```python
            toc = extractor.extract_from_file("guide.md")
            hierarchy = extractor.build_hierarchy(toc)
            # Returns nested structure showing document hierarchy
            ```
        """
        root = {
            'title': 'root',
            'level': 0,
            'children': []
        }
        
        stack = [root]
        
        for entry in toc:
            node = {
                'title': entry['title'],
                'level': entry['level'],
                'line': entry.get('line'),
                'children': []
            }
            
            # Find parent
            while stack and stack[-1]['level'] >= entry['level']:
                stack.pop()
            
            # Add to parent's children
            if stack:
                stack[-1]['children'].append(node)
            
            stack.append(node)
        
        return root


def extract_toc_from_directory(
    directory: str,
    extensions: Optional[List[str]] = None,
    recursive: bool = True
) -> Dict[str, List[Dict]]:
    """
    Extract TOC from all files in directory.
    
    Args:
        directory: Directory path
        extensions: File extensions to process
        recursive: Search subdirectories
    
    Returns:
        Dictionary mapping file paths to TOC entries
    
    Example:
        ```python
        from crazycontext.tools.toc import extract_toc_from_directory
        
        all_tocs = extract_toc_from_directory("./docs")
        
        for file_path, toc in all_tocs.items():
            print(f"{file_path}: {len(toc)} sections")
        ```
    """
    from ..utils import file_utils
    
    if extensions is None:
        extensions = ['.md', '.html', '.htm']
    
    files = file_utils.get_files_by_extension(
        directory,
        extensions,
        recursive=recursive
    )
    
    extractor = TOCExtractor()
    results = {}
    
    for file_path in files:
        try:
            toc = extractor.extract_from_file(file_path)
            if toc:
                results[file_path] = toc
        except Exception as e:
            logger.error(f"Error extracting TOC from {file_path}: {e}")
    
    logger.info(f"Extracted TOC from {len(results)} files")
    
    return results
