"""
Logging utilities for CrazyContext.

Provides consistent logging configuration across the package.
"""

import logging
import sys
from typing import Optional


def setup_logging(
    level: str = "INFO",
    format_string: Optional[str] = None,
    log_file: Optional[str] = None
) -> logging.Logger:
    """
    Setup logging configuration for CrazyContext.
    
    Args:
        level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        format_string: Custom format string for log messages
        log_file: Optional file path to write logs to
    
    Returns:
        Configured logger instance
    
    Example:
        ```python
        from crazycontext.utils import logging_utils
        
        logger = logging_utils.setup_logging(level="DEBUG")
        logger.info("Starting CrazyContext")
        ```
    """
    if format_string is None:
        format_string = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    # Get root logger
    logger = logging.getLogger("crazycontext")
    logger.setLevel(getattr(logging, level.upper()))
    
    # Remove existing handlers
    logger.handlers.clear()
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(getattr(logging, level.upper()))
    console_formatter = logging.Formatter(format_string)
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    # File handler if specified
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(getattr(logging, level.upper()))
        file_formatter = logging.Formatter(format_string)
        file_handler.setFormatter(file_formatter)
        logger.addHandler(file_handler)
    
    return logger


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance for a specific module.
    
    Args:
        name: Logger name (typically __name__ of the module)
    
    Returns:
        Logger instance
    
    Example:
        ```python
        from crazycontext.utils import logging_utils
        
        logger = logging_utils.get_logger(__name__)
        logger.info("Module initialized")
        ```
    """
    return logging.getLogger(f"crazycontext.{name}")


def set_level(level: str) -> None:
    """
    Set logging level for all CrazyContext loggers.
    
    Args:
        level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    
    Example:
        ```python
        from crazycontext.utils import logging_utils
        
        # Enable debug logging
        logging_utils.set_level("DEBUG")
        ```
    """
    logger = logging.getLogger("crazycontext")
    logger.setLevel(getattr(logging, level.upper()))
    
    for handler in logger.handlers:
        handler.setLevel(getattr(logging, level.upper()))
