"""
File utility functions for CrazyContext.

Handles file operations, path management, and file type detection.
"""

import os
import glob
import shutil
from typing import List, Optional
from pathlib import Path


def ensure_dir(directory: str) -> str:
    """
    Ensure a directory exists, create if it doesn't.
    
    Args:
        directory: Directory path to ensure
    
    Returns:
        Absolute path to the directory
    
    Example:
        ```python
        from crazycontext.utils import file_utils
        
        cache_dir = file_utils.ensure_dir("./cache")
        ```
    """
    os.makedirs(directory, exist_ok=True)
    return os.path.abspath(directory)


def get_files_by_extension(
    directory: str,
    extensions: List[str],
    recursive: bool = True
) -> List[str]:
    """
    Get all files with specific extensions from a directory.
    
    Args:
        directory: Directory to search
        extensions: List of extensions to match (e.g., [".md", ".txt"])
        recursive: Search recursively in subdirectories
    
    Returns:
        List of file paths
    
    Example:
        ```python
        from crazycontext.utils import file_utils
        
        # Find all markdown files
        md_files = file_utils.get_files_by_extension(
            "./cache",
            [".md", ".txt"]
        )
        ```
    """
    files = []
    
    if not os.path.exists(directory):
        return files
    
    for ext in extensions:
        if not ext.startswith('.'):
            ext = f'.{ext}'
        
        if recursive:
            pattern = os.path.join(directory, '**', f'*{ext}')
            files.extend(glob.glob(pattern, recursive=True))
        else:
            pattern = os.path.join(directory, f'*{ext}')
            files.extend(glob.glob(pattern))
    
    return sorted(files)


def get_file_size(file_path: str) -> int:
    """
    Get file size in bytes.
    
    Args:
        file_path: Path to file
    
    Returns:
        File size in bytes, or 0 if file doesn't exist
    
    Example:
        ```python
        size = file_utils.get_file_size("document.pdf")
        print(f"Size: {size} bytes")
        ```
    """
    try:
        return os.path.getsize(file_path)
    except OSError:
        return 0


def get_directory_size(directory: str) -> int:
    """
    Get total size of all files in a directory.
    
    Args:
        directory: Directory path
    
    Returns:
        Total size in bytes
    
    Example:
        ```python
        cache_size = file_utils.get_directory_size("./cache")
        print(f"Cache size: {cache_size / 1024 / 1024:.2f} MB")
        ```
    """
    total_size = 0
    
    if not os.path.exists(directory):
        return 0
    
    for dirpath, dirnames, filenames in os.walk(directory):
        for filename in filenames:
            filepath = os.path.join(dirpath, filename)
            try:
                total_size += os.path.getsize(filepath)
            except OSError:
                continue
    
    return total_size


def clean_directory(
    directory: str,
    extensions: Optional[List[str]] = None,
    older_than_days: Optional[int] = None
) -> int:
    """
    Clean files from a directory based on criteria.
    
    Args:
        directory: Directory to clean
        extensions: Only delete files with these extensions (None = all files)
        older_than_days: Only delete files older than N days (None = all files)
    
    Returns:
        Number of files deleted
    
    Example:
        ```python
        # Delete old cache files
        deleted = file_utils.clean_directory(
            "./cache",
            extensions=[".tmp", ".log"],
            older_than_days=7
        )
        print(f"Deleted {deleted} files")
        ```
    """
    import time
    
    if not os.path.exists(directory):
        return 0
    
    deleted_count = 0
    current_time = time.time()
    cutoff_time = current_time - (older_than_days * 86400) if older_than_days else 0
    
    for dirpath, dirnames, filenames in os.walk(directory):
        for filename in filenames:
            filepath = os.path.join(dirpath, filename)
            
            # Check extension
            if extensions:
                if not any(filename.endswith(ext) for ext in extensions):
                    continue
            
            # Check age
            if older_than_days:
                try:
                    file_age = os.path.getmtime(filepath)
                    if file_age > cutoff_time:
                        continue
                except OSError:
                    continue
            
            # Delete file
            try:
                os.remove(filepath)
                deleted_count += 1
            except OSError:
                continue
    
    return deleted_count


def copy_file(source: str, destination: str, overwrite: bool = False) -> bool:
    """
    Copy a file from source to destination.
    
    Args:
        source: Source file path
        destination: Destination file path
        overwrite: Overwrite if destination exists
    
    Returns:
        True if successful, False otherwise
    
    Example:
        ```python
        success = file_utils.copy_file(
            "original.txt",
            "backup.txt",
            overwrite=True
        )
        ```
    """
    if not os.path.exists(source):
        return False
    
    if os.path.exists(destination) and not overwrite:
        return False
    
    try:
        # Ensure destination directory exists
        dest_dir = os.path.dirname(destination)
        if dest_dir:
            os.makedirs(dest_dir, exist_ok=True)
        
        shutil.copy2(source, destination)
        return True
    except Exception:
        return False


def get_file_extension(file_path: str) -> str:
    """
    Get file extension from path.
    
    Args:
        file_path: File path
    
    Returns:
        File extension including the dot (e.g., ".txt")
    
    Example:
        ```python
        ext = file_utils.get_file_extension("document.pdf")
        # Returns: ".pdf"
        ```
    """
    return os.path.splitext(file_path)[1].lower()


def is_text_file(file_path: str) -> bool:
    """
    Check if a file is likely a text file based on extension.
    
    Args:
        file_path: File path to check
    
    Returns:
        True if text file, False otherwise
    
    Example:
        ```python
        if file_utils.is_text_file("document.txt"):
            # Process as text
            pass
        ```
    """
    text_extensions = {
        '.txt', '.md', '.markdown', '.rst', '.json', '.xml',
        '.html', '.htm', '.css', '.js', '.py', '.java',
        '.c', '.cpp', '.h', '.cs', '.rb', '.go', '.rs'
    }
    
    ext = get_file_extension(file_path)
    return ext in text_extensions


def read_file_safe(file_path: str, encoding: str = 'utf-8') -> Optional[str]:
    """
    Safely read a text file with error handling.
    
    Args:
        file_path: Path to file
        encoding: File encoding (default: utf-8)
    
    Returns:
        File contents as string, or None if error
    
    Example:
        ```python
        content = file_utils.read_file_safe("document.txt")
        if content:
            print(content)
        ```
    """
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            return f.read()
    except Exception:
        # Try with different encoding
        try:
            with open(file_path, 'r', encoding='latin-1') as f:
                return f.read()
        except Exception:
            return None


def write_file_safe(
    file_path: str,
    content: str,
    encoding: str = 'utf-8'
) -> bool:
    """
    Safely write content to a file with error handling.
    
    Args:
        file_path: Path to file
        content: Content to write
        encoding: File encoding (default: utf-8)
    
    Returns:
        True if successful, False otherwise
    
    Example:
        ```python
        success = file_utils.write_file_safe(
            "output.txt",
            "Hello, World!"
        )
        ```
    """
    try:
        # Ensure directory exists
        directory = os.path.dirname(file_path)
        if directory:
            os.makedirs(directory, exist_ok=True)
        
        with open(file_path, 'w', encoding=encoding) as f:
            f.write(content)
        return True
    except Exception:
        return False


def get_relative_path(file_path: str, base_path: str) -> str:
    """
    Get relative path from base path.
    
    Args:
        file_path: Full file path
        base_path: Base directory path
    
    Returns:
        Relative path
    
    Example:
        ```python
        rel_path = file_utils.get_relative_path(
            "/home/user/project/file.txt",
            "/home/user/project"
        )
        # Returns: "file.txt"
        ```
    """
    try:
        return os.path.relpath(file_path, base_path)
    except ValueError:
        # Paths on different drives on Windows
        return file_path
