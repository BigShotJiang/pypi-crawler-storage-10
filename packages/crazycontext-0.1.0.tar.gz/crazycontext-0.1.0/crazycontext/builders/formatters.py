"""
Output Formatters for CrazyContext.

Format context for different LLM frameworks and use cases.
"""

import logging
from typing import List, Dict, Optional

logger = logging.getLogger(__name__)


class Formatter:
    """
    Base formatter class.
    """
    
    def format(self, context: str, question: Optional[str] = None) -> str:
        """
        Format context for LLM.
        
        Args:
            context: Context text
            question: Optional question
        
        Returns:
            Formatted output
        """
        raise NotImplementedError


class PlainFormatter(Formatter):
    """
    Plain text formatter.
    
    Simple format with no special markup.
    
    Example:
        ```python
        from crazycontext.builders import PlainFormatter
        
        formatter = PlainFormatter()
        output = formatter.format(context, question="What is AI?")
        ```
    """
    
    def format(self, context: str, question: Optional[str] = None) -> str:
        """Format as plain text."""
        parts = [context]
        
        if question:
            parts.append(f"\n\nQuestion: {question}\n\nAnswer:")
        
        return "".join(parts)


class MarkdownFormatter(Formatter):
    """
    Markdown formatter.
    
    Formats with markdown headers and sections.
    
    Example:
        ```python
        from crazycontext.builders import MarkdownFormatter
        
        formatter = MarkdownFormatter()
        output = formatter.format(context, question="Explain this")
        ```
    """
    
    def format(self, context: str, question: Optional[str] = None) -> str:
        """Format with markdown."""
        parts = ["# Context\n\n", context]
        
        if question:
            parts.append(f"\n\n## Question\n\n{question}\n\n## Answer\n\n")
        
        return "".join(parts)


class ChatMLFormatter(Formatter):
    """
    ChatML format for chat models.
    
    Uses <|im_start|> and <|im_end|> tags.
    
    Example:
        ```python
        from crazycontext.builders import ChatMLFormatter
        
        formatter = ChatMLFormatter()
        output = formatter.format(context, question="What is this?")
        ```
    """
    
    def format(self, context: str, question: Optional[str] = None) -> str:
        """Format as ChatML."""
        parts = [
            "<|im_start|>system\n",
            "You are a helpful assistant. Use the following context to answer questions.\n",
            f"\nContext:\n{context}\n",
            "<|im_end|>\n"
        ]
        
        if question:
            parts.append(f"<|im_start|>user\n{question}<|im_end|>\n")
            parts.append("<|im_start|>assistant\n")
        
        return "".join(parts)


class AlpacaFormatter(Formatter):
    """
    Alpaca instruction format.
    
    Uses ### Instruction / ### Response format.
    
    Example:
        ```python
        from crazycontext.builders import AlpacaFormatter
        
        formatter = AlpacaFormatter()
        output = formatter.format(context, question="Explain")
        ```
    """
    
    def format(self, context: str, question: Optional[str] = None) -> str:
        """Format as Alpaca."""
        parts = ["### Context\n\n", context]
        
        if question:
            parts.append(f"\n\n### Instruction\n\n{question}\n\n### Response\n\n")
        
        return "".join(parts)


class LlamaFormatter(Formatter):
    """
    Llama format with special tokens.
    
    Uses [INST] and [/INST] tokens.
    
    Example:
        ```python
        from crazycontext.builders import LlamaFormatter
        
        formatter = LlamaFormatter()
        output = formatter.format(context, question="What?")
        ```
    """
    
    def format(self, context: str, question: Optional[str] = None) -> str:
        """Format for Llama models."""
        if question:
            return f"[INST]\n\nContext:\n{context}\n\nQuestion: {question}\n\n[/INST]"
        else:
            return f"[INST]\n\n{context}\n\n[/INST]"


class JSONFormatter(Formatter):
    """
    JSON format for structured output.
    
    Example:
        ```python
        from crazycontext.builders import JSONFormatter
        
        formatter = JSONFormatter()
        output = formatter.format(context, question="Query?")
        ```
    """
    
    def format(self, context: str, question: Optional[str] = None) -> str:
        """Format as JSON."""
        import json
        
        data = {
            "context": context
        }
        
        if question:
            data["question"] = question
        
        return json.dumps(data, indent=2, ensure_ascii=False)


# Formatter registry
FORMATTERS = {
    'plain': PlainFormatter,
    'markdown': MarkdownFormatter,
    'chatml': ChatMLFormatter,
    'alpaca': AlpacaFormatter,
    'llama': LlamaFormatter,
    'json': JSONFormatter
}


def get_formatter(name: str) -> Formatter:
    """
    Get formatter by name.
    
    Args:
        name: Formatter name
    
    Returns:
        Formatter instance
    
    Raises:
        ValueError: If formatter not found
    
    Example:
        ```python
        from crazycontext.builders.formatters import get_formatter
        
        formatter = get_formatter("chatml")
        output = formatter.format(context, question)
        ```
    """
    if name not in FORMATTERS:
        raise ValueError(f"Unknown formatter: {name}. Available: {list(FORMATTERS.keys())}")
    
    return FORMATTERS[name]()


def list_formatters() -> List[str]:
    """
    List available formatter names.
    
    Returns:
        List of formatter names
    
    Example:
        ```python
        from crazycontext.builders.formatters import list_formatters
        
        formatters = list_formatters()
        print(f"Available: {formatters}")
        ```
    """
    return list(FORMATTERS.keys())
