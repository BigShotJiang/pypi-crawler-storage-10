"""
Pre-configured Profiles for CrazyContext.

Profiles optimize context building for specific use cases.
"""

import logging
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


class Profile:
    """
    Base profile class.
    
    Defines settings for context building.
    """
    
    def __init__(
        self,
        name: str,
        max_tokens: int = 4000,
        format: str = "markdown",
        include_sources: bool = True,
        max_results: int = 10
    ):
        """
        Initialize profile.
        
        Args:
            name: Profile name
            max_tokens: Maximum tokens
            format: Output format
            include_sources: Include source attribution
            max_results: Maximum results
        """
        self.name = name
        self.max_tokens = max_tokens
        self.format = format
        self.include_sources = include_sources
        self.max_results = max_results
    
    def to_dict(self) -> Dict:
        """Convert profile to dictionary."""
        return {
            'name': self.name,
            'max_tokens': self.max_tokens,
            'format': self.format,
            'include_sources': self.include_sources,
            'max_results': self.max_results
        }


class ResearchProfile(Profile):
    """
    Profile optimized for research tasks.
    
    Features:
    - Large context window
    - Source attribution required
    - Markdown format
    - Many results
    
    Example:
        ```python
        from crazycontext.builders import ResearchProfile
        
        profile = ResearchProfile()
        print(f"Max tokens: {profile.max_tokens}")
        ```
    """
    
    def __init__(self):
        super().__init__(
            name="research",
            max_tokens=8000,
            format="markdown",
            include_sources=True,
            max_results=20
        )


class CodingProfile(Profile):
    """
    Profile optimized for coding tasks.
    
    Features:
    - Medium context window
    - Plain text format
    - Focus on code snippets
    
    Example:
        ```python
        from crazycontext.builders import CodingProfile
        
        profile = CodingProfile()
        ```
    """
    
    def __init__(self):
        super().__init__(
            name="coding",
            max_tokens=6000,
            format="plain",
            include_sources=True,
            max_results=15
        )


class DocumentationProfile(Profile):
    """
    Profile optimized for documentation.
    
    Features:
    - Large context window
    - Markdown format
    - Many results
    - Source attribution
    
    Example:
        ```python
        from crazycontext.builders import DocumentationProfile
        
        profile = DocumentationProfile()
        ```
    """
    
    def __init__(self):
        super().__init__(
            name="documentation",
            max_tokens=10000,
            format="markdown",
            include_sources=True,
            max_results=25
        )


class QuickProfile(Profile):
    """
    Profile for quick queries.
    
    Features:
    - Small context window
    - Plain text
    - Few results
    - Fast
    
    Example:
        ```python
        from crazycontext.builders import QuickProfile
        
        profile = QuickProfile()
        ```
    """
    
    def __init__(self):
        super().__init__(
            name="quick",
            max_tokens=2000,
            format="plain",
            include_sources=False,
            max_results=5
        )


class GeneralProfile(Profile):
    """
    General purpose profile.
    
    Balanced settings for most tasks.
    
    Example:
        ```python
        from crazycontext.builders import GeneralProfile
        
        profile = GeneralProfile()  # Default profile
        ```
    """
    
    def __init__(self):
        super().__init__(
            name="general",
            max_tokens=4000,
            format="markdown",
            include_sources=True,
            max_results=10
        )


# Profile registry
PROFILES = {
    'research': ResearchProfile,
    'coding': CodingProfile,
    'documentation': DocumentationProfile,
    'quick': QuickProfile,
    'general': GeneralProfile
}


def get_profile(name: str) -> Profile:
    """
    Get profile by name.
    
    Args:
        name: Profile name
    
    Returns:
        Profile instance
    
    Raises:
        ValueError: If profile not found
    
    Example:
        ```python
        from crazycontext.builders.profiles import get_profile
        
        profile = get_profile("research")
        print(f"Max tokens: {profile.max_tokens}")
        ```
    """
    if name not in PROFILES:
        raise ValueError(f"Unknown profile: {name}. Available: {list(PROFILES.keys())}")
    
    return PROFILES[name]()


def list_profiles() -> List[str]:
    """
    List available profile names.
    
    Returns:
        List of profile names
    
    Example:
        ```python
        from crazycontext.builders.profiles import list_profiles
        
        profiles = list_profiles()
        print(f"Available profiles: {profiles}")
        ```
    """
    return list(PROFILES.keys())
