"""
Context Builder for CrazyContext.

Build LLM-ready context from search results.
"""

import logging
from typing import List, Dict, Optional, Union

logger = logging.getLogger(__name__)


class ContextBuilder:
    """
    Build LLM-ready context from search results.
    
    Features:
    - Multiple output formats
    - Smart chunking
    - Token counting
    - Source attribution
    
    Example:
        ```python
        from crazycontext.builders import ContextBuilder
        
        builder = ContextBuilder(max_tokens=4000)
        
        # Build context from search results
        context = builder.build(
            search_results,
            format="markdown"
        )
        ```
    """
    
    def __init__(
        self,
        max_tokens: int = 4000,
        chars_per_token: float = 4.0
    ):
        """
        Initialize context builder.
        
        Args:
            max_tokens: Maximum tokens in output
            chars_per_token: Average characters per token
        """
        self.max_tokens = max_tokens
        self.chars_per_token = chars_per_token
        self.max_chars = int(max_tokens * chars_per_token)
        
        logger.info(f"ContextBuilder initialized (max_tokens: {max_tokens})")
    
    def estimate_tokens(self, text: str) -> int:
        """
        Estimate token count for text.
        
        Args:
            text: Text to estimate
        
        Returns:
            Estimated token count
        
        Example:
            ```python
            builder = ContextBuilder()
            tokens = builder.estimate_tokens("Hello, world!")
            print(f"Estimated tokens: {tokens}")
            ```
        """
        return int(len(text) / self.chars_per_token)
    
    def build(
        self,
        results: List[Dict],
        format: str = "markdown",
        include_sources: bool = True,
        max_results: Optional[int] = None
    ) -> str:
        """
        Build context from search results.
        
        Args:
            results: Search results
            format: Output format ("markdown", "plain", "json")
            include_sources: Include source attribution
            max_results: Maximum results to include
        
        Returns:
            Formatted context string
        
        Example:
            ```python
            results = cc.search("machine learning")
            
            context = builder.build(
                results,
                format="markdown",
                include_sources=True
            )
            ```
        """
        if format == "markdown":
            return self._build_markdown(results, include_sources, max_results)
        elif format == "plain":
            return self._build_plain(results, include_sources, max_results)
        elif format == "json":
            return self._build_json(results, max_results)
        else:
            raise ValueError(f"Unknown format: {format}")
    
    def _build_markdown(
        self,
        results: List[Dict],
        include_sources: bool,
        max_results: Optional[int]
    ) -> str:
        """Build markdown format context."""
        parts = []
        current_chars = 0
        results_used = 0
        
        if max_results:
            results = results[:max_results]
        
        for result in results:
            if current_chars >= self.max_chars:
                break
            
            # Add source header
            if include_sources:
                source = result.get('file', result.get('source', 'Unknown'))
                header = f"\n## Source: {source}\n\n"
                
                if current_chars + len(header) > self.max_chars:
                    break
                
                parts.append(header)
                current_chars += len(header)
            
            # Add matches
            for match in result.get('matches', [])[:3]:
                context_text = match.get('context', '')
                
                if current_chars + len(context_text) > self.max_chars:
                    break
                
                parts.append(context_text + "\n\n")
                current_chars += len(context_text) + 2
            
            results_used += 1
        
        context = "".join(parts)
        
        logger.info(
            f"Built markdown context: {current_chars} chars, "
            f"{self.estimate_tokens(context)} tokens, "
            f"{results_used} sources"
        )
        
        return context
    
    def _build_plain(
        self,
        results: List[Dict],
        include_sources: bool,
        max_results: Optional[int]
    ) -> str:
        """Build plain text format context."""
        parts = []
        current_chars = 0
        
        if max_results:
            results = results[:max_results]
        
        for result in results:
            if current_chars >= self.max_chars:
                break
            
            # Add source
            if include_sources:
                source = result.get('file', result.get('source', 'Unknown'))
                header = f"\n--- {source} ---\n\n"
                
                if current_chars + len(header) > self.max_chars:
                    break
                
                parts.append(header)
                current_chars += len(header)
            
            # Add matches
            for match in result.get('matches', [])[:3]:
                context_text = match.get('context', '')
                
                if current_chars + len(context_text) > self.max_chars:
                    break
                
                parts.append(context_text + "\n\n")
                current_chars += len(context_text) + 2
        
        return "".join(parts)
    
    def _build_json(
        self,
        results: List[Dict],
        max_results: Optional[int]
    ) -> str:
        """Build JSON format context."""
        import json
        
        if max_results:
            results = results[:max_results]
        
        # Truncate to fit in token limit
        output = []
        current_chars = 0
        
        for result in results:
            result_json = json.dumps(result)
            
            if current_chars + len(result_json) > self.max_chars:
                break
            
            output.append(result)
            current_chars += len(result_json)
        
        return json.dumps(output, indent=2, ensure_ascii=False)
    
    def build_prompt(
        self,
        results: List[Dict],
        question: str,
        system_prompt: Optional[str] = None
    ) -> str:
        """
        Build a complete LLM prompt with context.
        
        Args:
            results: Search results
            question: User's question
            system_prompt: Optional system prompt
        
        Returns:
            Complete prompt string
        
        Example:
            ```python
            results = cc.search("neural networks")
            
            prompt = builder.build_prompt(
                results,
                question="What is a neural network?",
                system_prompt="You are a helpful AI assistant."
            )
            ```
        """
        parts = []
        
        # Add system prompt
        if system_prompt:
            parts.append(f"{system_prompt}\n\n")
        
        # Add context
        parts.append("Context:\n")
        context = self.build(results, format="markdown", include_sources=True)
        parts.append(context)
        
        # Add question
        parts.append(f"\n\nQuestion: {question}\n\nAnswer:")
        
        prompt = "".join(parts)
        
        logger.info(
            f"Built prompt: {len(prompt)} chars, "
            f"{self.estimate_tokens(prompt)} tokens"
        )
        
        return prompt
    
    def chunk_text(
        self,
        text: str,
        chunk_size: int = 1000,
        overlap: int = 100
    ) -> List[str]:
        """
        Split text into overlapping chunks.
        
        Args:
            text: Text to chunk
            chunk_size: Maximum chunk size in characters
            overlap: Overlap between chunks
        
        Returns:
            List of text chunks
        
        Example:
            ```python
            text = "Very long text..."
            chunks = builder.chunk_text(text, chunk_size=500, overlap=50)
            print(f"Created {len(chunks)} chunks")
            ```
        """
        if len(text) <= chunk_size:
            return [text]
        
        chunks = []
        start = 0
        
        while start < len(text):
            end = start + chunk_size
            chunk = text[start:end]
            chunks.append(chunk)
            
            start = end - overlap
        
        logger.debug(f"Chunked text into {len(chunks)} chunks")
        
        return chunks
    
    def summarize_results(self, results: List[Dict]) -> Dict:
        """
        Summarize search results statistics.
        
        Args:
            results: Search results
        
        Returns:
            Summary dictionary
        
        Example:
            ```python
            summary = builder.summarize_results(results)
            print(f"Total matches: {summary['total_matches']}")
            print(f"Sources: {summary['source_count']}")
            ```
        """
        total_matches = sum(r.get('match_count', 0) for r in results)
        
        sources = set()
        for result in results:
            source = result.get('file') or result.get('source') or 'unknown'
            sources.add(source)
        
        return {
            'result_count': len(results),
            'source_count': len(sources),
            'total_matches': total_matches,
            'sources': list(sources)
        }
