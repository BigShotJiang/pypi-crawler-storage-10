"""Command-line interface for CrazyContext."""

from .main import main

__all__ = ["main"]
