"""
Command-Line Interface for CrazyContext.

Terminal commands for downloading, searching, and managing context.
"""

import sys
import os
import logging
from typing import Optional

# Setup basic logging
logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger(__name__)


def download_command(args):
    """Handle download command."""
    from ..main import CrazyContext
    
    cc = CrazyContext(cache_dir=args.cache_dir)
    
    if args.urls:
        # Download URLs from command line
        urls = args.urls.split(',')
        results = cc.from_urls(urls)
        
        success = sum(1 for r in results if r['status'] == 'success')
        print(f"✅ Downloaded {success}/{len(results)} URLs")
    
    elif args.file:
        # Download URLs from file
        with open(args.file, 'r') as f:
            urls = [line.strip() for line in f if line.strip()]
        
        results = cc.from_urls(urls)
        success = sum(1 for r in results if r['status'] == 'success')
        print(f"✅ Downloaded {success}/{len(results)} URLs from {args.file}")
    
    else:
        print("❌ Error: Provide --urls or --file")
        sys.exit(1)


def search_command(args):
    """Handle search command."""
    from ..main import CrazyContext
    
    cc = CrazyContext(cache_dir=args.cache_dir)
    
    # Add local files if specified
    if args.local:
        count = cc.add_local_directory(args.local)
        print(f"📁 Indexed {count} local files")
    
    # Search
    search_type = "fuzzy" if args.fuzzy else "keyword"
    results = cc.search(
        args.query,
        search_type=search_type,
        sources=args.sources.split(',') if args.sources else None
    )
    
    print(f"\n🔍 Found {len(results)} results for '{args.query}'")
    print("="*60)
    
    # Display results
    max_results = args.max_results or 10
    for i, result in enumerate(results[:max_results], 1):
        print(f"\n{i}. {result.get('file', 'Unknown')}")
        print(f"   Matches: {result.get('match_count', 0)}")
        
        if args.verbose:
            for match in result.get('matches', [])[:2]:
                print(f"   → {match.get('context', '')[:100]}...")


def stats_command(args):
    """Handle stats command."""
    from ..main import CrazyContext
    
    cc = CrazyContext(cache_dir=args.cache_dir)
    stats = cc.get_stats()
    
    print("\n📊 CrazyContext Statistics")
    print("="*60)
    
    print(f"\n📁 Web Cache:")
    print(f"   Files: {stats['web']['cache_files']}")
    print(f"   Size: {stats['web']['cache_size_mb']:.2f} MB")
    print(f"   Downloads: {stats['web']['downloads']} total")
    print(f"   Success: {stats['web']['success']}")
    print(f"   Failed: {stats['web']['failed']}")
    
    print(f"\n📝 Local Files:")
    print(f"   Indexed: {stats['local']['file_count']}")
    print(f"   Size: {stats['local']['total_size_mb']:.2f} MB")


def papers_command(args):
    """Handle papers command."""
    from ..sources import PapersSource
    
    papers = PapersSource(cache_dir=args.cache_dir)
    
    # Search papers
    sources = args.sources.split(',') if args.sources else ["arxiv", "semantic_scholar"]
    results = papers.search(
        args.query,
        sources=sources,
        max_results=args.max_results or 10
    )
    
    print(f"\n📚 Found {len(results)} papers for '{args.query}'")
    print("="*60)
    
    for i, paper in enumerate(results, 1):
        print(f"\n{i}. {paper['title']}")
        print(f"   Authors: {', '.join(paper['authors'][:3])}")
        if len(paper['authors']) > 3:
            print(f"   ... and {len(paper['authors']) - 3} more")
        print(f"   Year: {paper['year']}")
        print(f"   Source: {paper['source']}")
        
        if args.verbose and paper['summary']:
            print(f"   Abstract: {paper['summary'][:200]}...")


def github_command(args):
    """Handle GitHub command."""
    from ..sources import GitHubSource
    
    github = GitHubSource(cache_dir=args.cache_dir)
    
    if args.download:
        # Download repository files
        files = github.download_repo_files(
            args.download,
            patterns=args.patterns.split(',') if args.patterns else None,
            max_files=args.max_files or 50
        )
        print(f"✅ Downloaded {len(files)} files from {args.download}")
    
    else:
        # Search repositories
        repos = github.search_repositories(
            args.query,
            language=args.language,
            min_stars=args.min_stars or 0,
            max_results=args.max_results or 10
        )
        
        print(f"\n🐙 Found {len(repos)} repositories for '{args.query}'")
        print("="*60)
        
        for i, repo in enumerate(repos, 1):
            print(f"\n{i}. {repo['full_name']}")
            print(f"   ⭐ {repo['stars']} stars | 🍴 {repo['forks']} forks")
            print(f"   Language: {repo['language']}")
            if args.verbose and repo['description']:
                print(f"   {repo['description']}")


def main():
    """Main CLI entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='CrazyContext - The ultimate context builder for LLMs',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        '--cache-dir',
        default='./cache',
        help='Cache directory (default: ./cache)'
    )
    
    parser.add_argument(
        '--version',
        action='store_true',
        help='Show version'
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Commands')
    
    # Download command
    download_parser = subparsers.add_parser('download', help='Download websites')
    download_parser.add_argument('--urls', help='Comma-separated URLs')
    download_parser.add_argument('--file', help='File with URLs (one per line)')
    
    # Search command
    search_parser = subparsers.add_parser('search', help='Search content')
    search_parser.add_argument('query', help='Search query')
    search_parser.add_argument('--fuzzy', action='store_true', help='Use fuzzy search')
    search_parser.add_argument('--sources', help='Sources to search (web,local)')
    search_parser.add_argument('--local', help='Add local directory to search')
    search_parser.add_argument('--max-results', type=int, help='Max results')
    search_parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
    
    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')
    
    # Papers command
    papers_parser = subparsers.add_parser('papers', help='Search academic papers')
    papers_parser.add_argument('query', help='Search query')
    papers_parser.add_argument('--sources', help='Sources (arxiv,semantic_scholar)')
    papers_parser.add_argument('--max-results', type=int, help='Max results')
    papers_parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
    
    # GitHub command
    github_parser = subparsers.add_parser('github', help='Search GitHub repositories')
    github_parser.add_argument('query', nargs='?', help='Search query')
    github_parser.add_argument('--download', help='Download repository (owner/repo)')
    github_parser.add_argument('--language', help='Filter by language')
    github_parser.add_argument('--min-stars', type=int, help='Minimum stars')
    github_parser.add_argument('--patterns', help='File patterns (*.py,*.md)')
    github_parser.add_argument('--max-files', type=int, help='Max files to download')
    github_parser.add_argument('--max-results', type=int, help='Max results')
    github_parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
    
    args = parser.parse_args()
    
    # Show version
    if args.version:
        from ..__version__ import __version__
        print(f"CrazyContext v{__version__}")
        sys.exit(0)
    
    # Show help if no command
    if not args.command:
        parser.print_help()
        sys.exit(0)
    
    # Execute command
    try:
        if args.command == 'download':
            download_command(args)
        elif args.command == 'search':
            search_command(args)
        elif args.command == 'stats':
            stats_command(args)
        elif args.command == 'papers':
            papers_command(args)
        elif args.command == 'github':
            github_command(args)
        else:
            parser.print_help()
            sys.exit(1)
    
    except KeyboardInterrupt:
        print("\n\n⚠️  Interrupted by user")
        sys.exit(130)
    except Exception as e:
        print(f"\n❌ Error: {e}")
        logger.exception("Command failed")
        sys.exit(1)


if __name__ == '__main__':
    main()
