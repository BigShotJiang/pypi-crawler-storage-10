"""
Keyword Search Engine for CrazyContext.

Search through downloaded content using keyword matching.
"""

import os
import re
import logging
from typing import List, Dict, Optional
from pathlib import Path

logger = logging.getLogger(__name__)

# Supported text file extensions
TEXT_EXTENSIONS = {
    '.html', '.htm', '.txt', '.md', '.markdown', '.rst',
    '.css', '.js', '.json', '.xml', '.csv',
    '.py', '.java', '.c', '.cpp', '.php', '.rb', '.go', '.rs'
}

# Binary extensions to skip
BINARY_EXTENSIONS = {
    '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg',
    '.pdf', '.zip', '.tar', '.gz', '.7z', '.rar',
    '.exe', '.dll', '.so', '.bin',
    '.mp3', '.mp4', '.avi', '.mov', '.wmv',
    '.woff', '.woff2', '.ttf', '.eot', '.otf'
}


def is_text_file(file_path: str) -> bool:
    """
    Check if a file is likely a text file based on extension.
    
    Args:
        file_path: Path to file
    
    Returns:
        True if text file, False otherwise
    """
    ext = Path(file_path).suffix.lower()
    
    if ext in TEXT_EXTENSIONS:
        return True
    if ext in BINARY_EXTENSIONS:
        return False
    
    # Unknown extension - try to read
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            f.read(512)  # Try first 512 bytes
        return True
    except Exception:
        return False


def read_file_safe(file_path: str, max_size_mb: int = 10) -> Optional[str]:
    """
    Safely read text file content with size limit.
    
    Args:
        file_path: Path to file
        max_size_mb: Maximum file size in MB
    
    Returns:
        File content or None if too large/unreadable
    """
    try:
        file_size = os.path.getsize(file_path)
        max_bytes = max_size_mb * 1024 * 1024
        
        if file_size > max_bytes:
            logger.warning(
                f"Skipping {file_path} - too large ({file_size / (1024*1024):.2f} MB)"
            )
            return None
        
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read()
    
    except Exception as e:
        logger.debug(f"Could not read {file_path}: {e}")
        return None


def get_context_snippet(
    text: str,
    match_pos: int,
    context_chars: int = 250
) -> str:
    """
    Extract a snippet of text around a match position.
    
    Args:
        text: Full text content
        match_pos: Position of the match
        context_chars: Total characters to include
    
    Returns:
        Snippet with surrounding context
    
    Example:
        ```python
        text = "The quick brown fox jumps over the lazy dog"
        snippet = get_context_snippet(text, 10, 20)
        # Returns portion around position 10
        ```
    """
    half_context = context_chars // 2
    start = max(0, match_pos - half_context)
    end = min(len(text), match_pos + half_context)
    
    snippet = text[start:end].strip()
    
    # Add ellipsis if truncated
    if start > 0:
        snippet = "..." + snippet
    if end < len(text):
        snippet = snippet + "..."
    
    return snippet


def search_in_text(
    text: str,
    query: str,
    case_sensitive: bool = False,
    max_matches: int = 10
) -> List[Dict]:
    """
    Search for query in text and return matches with context.
    
    Args:
        text: Text to search in
        query: Search query
        case_sensitive: Case sensitive search
        max_matches: Maximum matches to return
    
    Returns:
        List of match dictionaries with position and context
    
    Example:
        ```python
        text = "Python is great. Python is awesome."
        matches = search_in_text(text, "python", case_sensitive=False)
        # Returns 2 matches with context snippets
        ```
    """
    if not query or not text:
        return []
    
    matches = []
    search_text = text if case_sensitive else text.lower()
    search_query = query if case_sensitive else query.lower()
    
    # Find all occurrences
    start_pos = 0
    while len(matches) < max_matches:
        pos = search_text.find(search_query, start_pos)
        if pos == -1:
            break
        
        matches.append({
            "position": pos,
            "context": get_context_snippet(text, pos, 250),
            "match_text": text[pos:pos + len(query)]
        })
        
        start_pos = pos + 1
    
    return matches


def search_in_file(
    file_path: str,
    query: str,
    case_sensitive: bool = False,
    max_matches: int = 10
) -> Optional[Dict]:
    """
    Search for query in a single file.
    
    Args:
        file_path: Path to file
        query: Search query
        case_sensitive: Case sensitive search
        max_matches: Maximum matches per file
    
    Returns:
        Dictionary with file info and matches, or None if no matches
    
    Example:
        ```python
        result = search_in_file("document.txt", "python")
        if result:
            print(f"Found {result['match_count']} matches")
            for match in result['matches']:
                print(match['context'])
        ```
    """
    if not is_text_file(file_path):
        return None
    
    content = read_file_safe(file_path)
    if not content:
        return None
    
    matches = search_in_text(content, query, case_sensitive, max_matches)
    
    if not matches:
        return None
    
    return {
        "file": file_path,
        "match_count": len(matches),
        "matches": matches,
        "file_size": os.path.getsize(file_path)
    }


def search_in_directory(
    directory: str,
    query: str,
    case_sensitive: bool = False,
    max_matches_per_file: int = 10,
    max_files: int = 100,
    recursive: bool = True,
    file_extensions: Optional[List[str]] = None
) -> List[Dict]:
    """
    Search for query in all files in a directory.
    
    Args:
        directory: Directory to search
        query: Search query
        case_sensitive: Case sensitive search
        max_matches_per_file: Max matches per file
        max_files: Maximum files to return
        recursive: Search subdirectories
        file_extensions: Filter by extensions (e.g., [".txt", ".md"])
    
    Returns:
        List of file results with matches
    
    Example:
        ```python
        from crazycontext.search import keyword
        
        results = keyword.search_in_directory(
            "./cache",
            "neural networks",
            max_files=20
        )
        
        for result in results:
            print(f"{result['file']}: {result['match_count']} matches")
        ```
    """
    if not os.path.exists(directory):
        logger.error(f"Directory not found: {directory}")
        return []
    
    results = []
    
    # Walk directory
    for root, dirs, files in os.walk(directory):
        for filename in files:
            if len(results) >= max_files:
                break
            
            file_path = os.path.join(root, filename)
            
            # Filter by extension if specified
            if file_extensions:
                ext = Path(file_path).suffix.lower()
                if ext not in file_extensions:
                    continue
            
            # Search in file
            result = search_in_file(
                file_path,
                query,
                case_sensitive,
                max_matches_per_file
            )
            
            if result:
                results.append(result)
        
        # Stop recursion if not recursive
        if not recursive:
            break
    
    # Sort by match count (most matches first)
    results.sort(key=lambda x: x['match_count'], reverse=True)
    
    logger.info(f"Found {len(results)} files with matches for '{query}'")
    
    return results


def search_with_multiple_keywords(
    directory: str,
    keywords: List[str],
    match_all: bool = False,
    **kwargs
) -> List[Dict]:
    """
    Search for multiple keywords in directory.
    
    Args:
        directory: Directory to search
        keywords: List of keywords
        match_all: If True, file must contain ALL keywords (AND logic)
                   If False, file can contain ANY keyword (OR logic)
        **kwargs: Additional arguments for search_in_directory
    
    Returns:
        List of file results
    
    Example:
        ```python
        # Find files with "python" OR "javascript"
        results = search_with_multiple_keywords(
            "./docs",
            ["python", "javascript"],
            match_all=False
        )
        
        # Find files with "neural" AND "network"
        results = search_with_multiple_keywords(
            "./papers",
            ["neural", "network"],
            match_all=True
        )
        ```
    """
    if match_all:
        # Must match ALL keywords
        # Start with first keyword results
        results = search_in_directory(directory, keywords[0], **kwargs)
        
        # Filter to only files that contain all other keywords
        for keyword in keywords[1:]:
            keyword_files = set()
            for result in search_in_directory(directory, keyword, **kwargs):
                keyword_files.add(result['file'])
            
            results = [r for r in results if r['file'] in keyword_files]
        
        return results
    
    else:
        # Match ANY keyword (OR logic)
        all_results = {}
        
        for keyword in keywords:
            keyword_results = search_in_directory(directory, keyword, **kwargs)
            
            for result in keyword_results:
                file_path = result['file']
                if file_path not in all_results:
                    all_results[file_path] = result
                else:
                    # Combine match counts
                    all_results[file_path]['match_count'] += result['match_count']
        
        results = list(all_results.values())
        results.sort(key=lambda x: x['match_count'], reverse=True)
        
        return results
