"""
Fuzzy Search Engine for CrazyContext.

Search with typo tolerance using fuzzy string matching.
"""

import logging
from typing import List, Dict, Optional
from difflib import SequenceMatcher

logger = logging.getLogger(__name__)

# Try to import rapidfuzz for better performance
try:
    from rapidfuzz import fuzz
    RAPIDFUZZ_AVAILABLE = True
except ImportError:
    RAPIDFUZZ_AVAILABLE = False
    logger.debug("rapidfuzz not available, using difflib fallback")


def fuzzy_match_score(text: str, query: str) -> float:
    """
    Calculate fuzzy match score between text and query.
    
    Uses rapidfuzz if available, otherwise falls back to difflib.
    
    Args:
        text: Text to match against
        query: Query string
    
    Returns:
        Score between 0 and 100 (higher = better match)
    
    Example:
        ```python
        from crazycontext.search import fuzzy
        
        score = fuzzy.fuzzy_match_score("machine learning", "machne lerning")
        # Returns: ~85 (high score despite typos)
        ```
    """
    text_lower = text.lower()
    query_lower = query.lower()
    
    if RAPIDFUZZ_AVAILABLE:
        return fuzz.partial_ratio(query_lower, text_lower)
    else:
        # Fallback to difflib
        matcher = SequenceMatcher(None, query_lower, text_lower)
        return matcher.ratio() * 100


def fuzzy_search_in_text(
    text: str,
    query: str,
    threshold: float = 70.0,
    max_matches: int = 10
) -> List[Dict]:
    """
    Find fuzzy matches in text.
    
    Searches for query with typo tolerance by scoring text chunks.
    
    Args:
        text: Text to search in
        query: Search query (can have typos)
        threshold: Minimum score to consider a match (0-100)
        max_matches: Maximum matches to return
    
    Returns:
        List of match dictionaries with score and context
    
    Example:
        ```python
        text = "Deep learning and machine learning are popular"
        matches = fuzzy_search_in_text(text, "machne lerning", threshold=70)
        # Finds "machine learning" despite typo
        ```
    """
    if not text or not query:
        return []
    
    matches = []
    query_len = len(query)
    text_lower = text.lower()
    
    # Slide window through text
    for i in range(len(text) - query_len + 1):
        window = text[i:i + query_len * 2]  # Check slightly larger window
        score = fuzzy_match_score(window, query)
        
        if score >= threshold:
            # Get context around match
            context_start = max(0, i - 50)
            context_end = min(len(text), i + query_len + 50)
            context = text[context_start:context_end].strip()
            
            if context_start > 0:
                context = "..." + context
            if context_end < len(text):
                context = context + "..."
            
            matches.append({
                "position": i,
                "score": score,
                "match_text": window[:query_len],
                "context": context
            })
            
            if len(matches) >= max_matches:
                break
            
            # Skip ahead to avoid overlapping matches
            i += query_len // 2
    
    # Sort by score
    matches.sort(key=lambda x: x['score'], reverse=True)
    
    return matches[:max_matches]


def fuzzy_search_in_files(
    file_paths: List[str],
    query: str,
    threshold: float = 70.0,
    max_matches_per_file: int = 5,
    max_files: int = 20
) -> List[Dict]:
    """
    Fuzzy search across multiple files.
    
    Args:
        file_paths: List of file paths to search
        query: Search query (typo-tolerant)
        threshold: Minimum fuzzy match score (0-100)
        max_matches_per_file: Max matches per file
        max_files: Maximum files to return
    
    Returns:
        List of file results with fuzzy matches
    
    Example:
        ```python
        from crazycontext.search import fuzzy
        from crazycontext.utils import file_utils
        
        # Get all markdown files
        files = file_utils.get_files_by_extension("./cache", [".md"])
        
        # Fuzzy search with typo
        results = fuzzy.fuzzy_search_in_files(
            files,
            "neural netwerk",  # Typo in "network"
            threshold=75
        )
        
        for result in results:
            print(f"{result['file']}: {result['avg_score']:.1f}%")
        ```
    """
    from .keyword import read_file_safe, is_text_file
    
    results = []
    
    for file_path in file_paths:
        if len(results) >= max_files:
            break
        
        if not is_text_file(file_path):
            continue
        
        content = read_file_safe(file_path)
        if not content:
            continue
        
        matches = fuzzy_search_in_text(
            content,
            query,
            threshold,
            max_matches_per_file
        )
        
        if matches:
            avg_score = sum(m['score'] for m in matches) / len(matches)
            
            results.append({
                "file": file_path,
                "match_count": len(matches),
                "avg_score": avg_score,
                "best_score": matches[0]['score'],
                "matches": matches
            })
    
    # Sort by best score
    results.sort(key=lambda x: x['best_score'], reverse=True)
    
    logger.info(
        f"Fuzzy search found {len(results)} files matching '{query}' "
        f"(threshold: {threshold})"
    )
    
    return results[:max_files]


def fuzzy_search_in_directory(
    directory: str,
    query: str,
    threshold: float = 70.0,
    max_matches_per_file: int = 5,
    max_files: int = 20,
    recursive: bool = True,
    file_extensions: Optional[List[str]] = None
) -> List[Dict]:
    """
    Fuzzy search in directory with typo tolerance.
    
    Args:
        directory: Directory to search
        query: Search query (can have typos)
        threshold: Minimum fuzzy match score (0-100)
        max_matches_per_file: Max matches per file
        max_files: Maximum files to return
        recursive: Search subdirectories
        file_extensions: Filter by extensions
    
    Returns:
        List of file results with fuzzy matches
    
    Example:
        ```python
        from crazycontext.search import fuzzy
        
        # Search with typos - still finds results!
        results = fuzzy.fuzzy_search_in_directory(
            "./papers",
            "machne lerning algorthm",  # Multiple typos
            threshold=70
        )
        
        print(f"Found {len(results)} files despite typos")
        ```
    """
    from crazycontext.utils import file_utils
    
    # Get all files
    if file_extensions is None:
        file_extensions = ['.txt', '.md', '.html', '.htm']
    
    file_paths = file_utils.get_files_by_extension(
        directory,
        file_extensions,
        recursive=recursive
    )
    
    return fuzzy_search_in_files(
        file_paths,
        query,
        threshold,
        max_matches_per_file,
        max_files
    )


def suggest_corrections(
    query: str,
    known_terms: List[str],
    threshold: float = 80.0,
    max_suggestions: int = 5
) -> List[Dict]:
    """
    Suggest corrections for a potentially misspelled query.
    
    Args:
        query: Query to check
        known_terms: List of correct terms
        threshold: Minimum similarity score
        max_suggestions: Maximum suggestions to return
    
    Returns:
        List of suggestions with scores
    
    Example:
        ```python
        known_terms = ["machine learning", "deep learning", "neural network"]
        
        suggestions = suggest_corrections(
            "machne lerning",
            known_terms,
            threshold=75
        )
        
        for suggestion in suggestions:
            print(f"Did you mean: {suggestion['term']} ({suggestion['score']:.0f}%)?")
        ```
    """
    suggestions = []
    
    for term in known_terms:
        score = fuzzy_match_score(term, query)
        
        if score >= threshold:
            suggestions.append({
                "term": term,
                "score": score
            })
    
    # Sort by score
    suggestions.sort(key=lambda x: x['score'], reverse=True)
    
    return suggestions[:max_suggestions]


def find_similar_terms(
    term: str,
    term_list: List[str],
    threshold: float = 75.0,
    max_results: int = 10
) -> List[Dict]:
    """
    Find similar terms from a list.
    
    Useful for finding related topics or alternate spellings.
    
    Args:
        term: Term to find similar matches for
        term_list: List of terms to search
        threshold: Minimum similarity score
        max_results: Maximum results to return
    
    Returns:
        List of similar terms with scores
    
    Example:
        ```python
        topics = ["neural networks", "deep learning", "machine learning",
                  "artificial intelligence", "data science"]
        
        similar = find_similar_terms(
            "neural nets",
            topics,
            threshold=70
        )
        # Returns: "neural networks" with high score
        ```
    """
    similar = []
    
    for candidate in term_list:
        score = fuzzy_match_score(candidate, term)
        
        if score >= threshold:
            similar.append({
                "term": candidate,
                "score": score
            })
    
    similar.sort(key=lambda x: x['score'], reverse=True)
    
    return similar[:max_results]
