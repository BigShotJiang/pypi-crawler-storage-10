"""
CrazyContext - The Ultimate Context Builder for LLM Applications

Multi-source context gathering (web, papers, GitHub) with optional semantic search.
"""

from .__version__ import __version__, __author__, __license__
from .main import CrazyContext

__all__ = [
    "__version__",
    "__author__",
    "__license__",
    "CrazyContext",
]
