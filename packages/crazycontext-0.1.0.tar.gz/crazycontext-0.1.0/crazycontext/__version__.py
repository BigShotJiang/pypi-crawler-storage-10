"""Version information for CrazyContext."""

__version__ = "0.1.0"
__author__ = "CrazyContext Team"
__license__ = "Apache-2.0"
