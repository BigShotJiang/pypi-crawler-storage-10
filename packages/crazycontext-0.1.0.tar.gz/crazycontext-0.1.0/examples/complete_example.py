"""
Complete CrazyContext Example

Demonstrates the full API in action.
"""

from crazycontext import CrazyContext

# Initialize
print("Initializing CrazyContext...")
cc = CrazyContext(cache_dir="./demo_cache")

# Example 1: Download web content
print("\n=== Example 1: Download Documentation ===")
results = cc.from_urls([
    "http://example.com",
])

for result in results:
    print(f"  {result['url']}: {result['status']}")

# Example 2: Add local files
print("\n=== Example 2: Index Local Files ===")
# Uncomment to index your own files:
# count = cc.add_local_directory("./my_notes", extensions=[".md", ".txt"])
# print(f"  Indexed {count} files")

# Example 3: Search with keywords
print("\n=== Example 3: Keyword Search ===")
results = cc.search("example", sources=["web"])
print(f"  Found {len(results)} results")

for result in results[:3]:  # Show top 3
    print(f"  - {result['file']}: {result['match_count']} matches")

# Example 4: Fuzzy search (typo-tolerant)
print("\n=== Example 4: Fuzzy Search (Typos OK!) ===")
results = cc.search(
    "exmple",  # Typo!
    search_type="fuzzy",
    threshold=70,
    sources=["web"]
)
print(f"  Found {len(results)} results despite typo!")

# Example 5: Build context for LLM
print("\n=== Example 5: Build LLM Context ===")
results = cc.search("example domain", sources=["web"])
context = cc.build_context(results, max_length=500)
print(f"  Built context: {len(context)} characters")
print(f"\nContext preview:\n{context[:200]}...")

# Example 6: Get statistics
print("\n=== Example 6: Statistics ===")
stats = cc.get_stats()
print(f"  Web cache: {stats['web']['cache_files']} files ({stats['web']['cache_size_mb']:.2f} MB)")
print(f"  Local files: {stats['local']['file_count']} indexed")
print(f"  Downloads: {stats['web']['success']}/{stats['web']['downloads']} successful")

print("\n✅ Complete! CrazyContext is working perfectly!")
