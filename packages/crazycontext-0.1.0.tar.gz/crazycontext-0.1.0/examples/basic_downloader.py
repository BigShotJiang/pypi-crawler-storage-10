"""
Basic example of using CrazyContext downloader.
"""

from crazycontext.core import downloader

# Download a single URL
print("Downloading example.com...")
result = downloader.download_url(
    "http://example.com",
    output_dir="./downloads"
)

print(f"\nStatus: {result['status']}")
print(f"File: {result['file']}")
print(f"Size: {result['size']}")

# Download multiple URLs
print("\n" + "="*50)
print("Downloading multiple sites...")

urls = [
    "http://example.com",
    "http://example.org",
]

results = downloader.download_sites(
    urls,
    output_dir="./downloads",
    timeout=10
)

print(f"\nDownloaded {len(results)} URLs:")
for r in results:
    print(f"  {r['url']}: {r['status']} ({r['size']})")
