"""
Example: Using TOC Tool to Extract Context

Demonstrates how to use the TOC (Table of Contents) tool to:
- Extract document structure
- Get context with TOC
- Organize content by sections
"""

from crazycontext.tools import TOCExtractor, extract_toc_from_directory
import tempfile
import os

# Sample markdown document
SAMPLE_DOC = """# Python Tutorial

Learn Python programming from scratch.

## Getting Started

Python is a high-level programming language.

### Installation

Download Python from python.org.

### First Program

Create a file called hello.py:

```python
print("Hello, World!")
```

## Data Types

Python has several built-in data types.

### Numbers

Integers and floats.

### Strings

Text data enclosed in quotes.

## Functions

Functions are reusable blocks of code.

### Defining Functions

Use the def keyword.

### Calling Functions

Use the function name with parentheses.
"""

print("="*60)
print("TOC TOOL EXAMPLE")
print("="*60)

# Create a temporary document
with tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False) as f:
    f.write(SAMPLE_DOC)
    doc_path = f.name

try:
    # Initialize TOC extractor
    extractor = TOCExtractor()
    
    # Example 1: Extract TOC
    print("\n📋 Example 1: Extract Table of Contents")
    print("-" * 60)
    toc = extractor.extract_from_file(doc_path)
    
    print(f"Found {len(toc)} sections:")
    for entry in toc:
        indent = "  " * (entry['level'] - 1)
        print(f"{indent}{'#' * entry['level']} {entry['title']}")
    
    # Example 2: Get complete context with TOC
    print("\n📄 Example 2: Get Complete Context with TOC")
    print("-" * 60)
    context = extractor.get_all_context(doc_path, include_toc=True)
    
    print(f"Context length: {len(context)} characters")
    print(f"\nFirst 300 characters:")
    print(context[:300] + "...")
    
    # Example 3: Get context by sections
    print("\n📑 Example 3: Get Context Organized by Sections")
    print("-" * 60)
    sections = extractor.get_context_by_sections(doc_path, max_chars=100)
    
    for i, section in enumerate(sections[:3], 1):
        print(f"\nSection {i}: {section['title']} (Level {section['level']})")
        print(f"Content: {section['content'][:80]}...")
        print(f"Char count: {section['char_count']}")
    
    # Example 4: Build hierarchy
    print("\n🌳 Example 4: Build Hierarchical Structure")
    print("-" * 60)
    hierarchy = extractor.build_hierarchy(toc)
    
    def print_hierarchy(node, level=0):
        if node['title'] != 'root':
            print("  " * level + f"- {node['title']}")
        for child in node.get('children', []):
            print_hierarchy(child, level + 1)
    
    print_hierarchy(hierarchy)
    
    # Example 5: Use with LLM context building
    print("\n🤖 Example 5: Build LLM Context")
    print("-" * 60)
    
    # Get context for specific sections
    sections = extractor.get_context_by_sections(doc_path)
    
    # Build focused context (e.g., only "Functions" section)
    functions_sections = [s for s in sections if 'Function' in s['title']]
    
    print(f"Found {len(functions_sections)} sections about functions:")
    for section in functions_sections:
        print(f"  - {section['title']}")
    
    # Build complete context for LLM
    llm_context = extractor.get_all_context(doc_path)
    
    # Example prompt
    print("\n💬 Example LLM Prompt:")
    print("-" * 60)
    prompt = f"""Based on this documentation:

{llm_context}

Question: How do I define and call a function in Python?

Answer:"""
    
    print(f"Prompt length: {len(prompt)} characters")
    print(f"First 200 chars: {prompt[:200]}...")
    
    # Example 6: Process multiple files
    print("\n📚 Example 6: Process Multiple Files")
    print("-" * 60)
    
    # Create a directory with multiple docs
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create multiple markdown files
        for i in range(3):
            doc_file = os.path.join(tmpdir, f"guide{i}.md")
            with open(doc_file, 'w') as f:
                f.write(f"# Guide {i}\n\n## Section A\n\nContent A\n\n## Section B\n\nContent B")
        
        # Extract TOC from all files
        all_tocs = extract_toc_from_directory(tmpdir)
        
        print(f"Processed {len(all_tocs)} files:")
        for file_path, toc in all_tocs.items():
            filename = os.path.basename(file_path)
            print(f"  {filename}: {len(toc)} sections")
    
    print("\n" + "="*60)
    print("✅ TOC Tool Examples Complete!")
    print("="*60)
    
finally:
    # Clean up
    os.unlink(doc_path)

# Real-world usage example
print("\n\n🌟 Real-World Usage Example:")
print("="*60)
print("""
# Use Case: Build Context from Documentation

from crazycontext import CrazyContext
from crazycontext.tools import TOCExtractor

# Step 1: Download documentation
cc = CrazyContext()
cc.from_urls(["https://docs.python.org/3/tutorial/"])

# Step 2: Get all markdown files
from crazycontext.utils import file_utils
docs = file_utils.get_files_by_extension(cc.cache_dir, [".md"])

# Step 3: Extract context with TOC
extractor = TOCExtractor()
all_context = []

for doc in docs:
    context = extractor.get_all_context(doc, include_toc=True)
    all_context.append(context)

# Step 4: Combine and use with LLM
full_context = "\\n\\n---\\n\\n".join(all_context)

# Step 5: Build prompt
prompt = f\"""
Documentation:
{full_context}

Question: How do I use list comprehensions in Python?

Answer:
\"""

# Use with any LLM
response = your_llm(prompt)
print(response)
""")
