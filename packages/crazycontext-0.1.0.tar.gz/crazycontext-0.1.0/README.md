# 🚀 CrazyContext

**The ultimate context builder for LLM applications**

Multi-source context gathering (web, papers, GitHub) with optional semantic search integration.

[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Python](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)

---

## ✨ Features

- 🌐 **Multi-Source Gathering** - Web, academic papers, GitHub repos, local files
- 🔍 **Flexible Search** - Keyword, fuzzy, or semantic (with Deep-Searcher)
- 📚 **GitHub Integration** - Search repos, download code, extract context
- 📄 **Format Flexibility** - HTML, Markdown, PDF, plain text
- 💾 **Smart Caching** - Download once, query forever
- 🎯 **Profile System** - Pre-optimized for research, coding, legal, etc.
- 🤖 **LLM-Ready** - Direct output for any LLM (no framework lock-in)
- 🔌 **Optional Semantic Search** - Integrate with Deep-Searcher when needed

---

## 🚀 Quick Start

### Installation

```bash
# Core installation
pip install crazycontext

# With optional features
pip install crazycontext[fuzzy]           # Fuzzy search
pip install crazycontext[pdf]             # PDF support
pip install crazycontext[github]          # GitHub integration
pip install crazycontext[deepsearcher]    # Semantic search
pip install crazycontext[all]             # Everything
```

### Basic Usage

```python
from crazycontext import CrazyContext

# Initialize
cc = CrazyContext()

# Gather context from multiple sources
context = cc.from_topic(
    "machine learning",
    sources=["web", "papers", "github"],
    max_results=20
)

# Format for LLM
prompt = context.build(format="llm_prompt")
print(prompt)
```

---

## 📖 Examples

### Download Documentation

```python
# Download and convert to Markdown
cc.from_urls([
    "https://docs.python.org/3/tutorial/",
    "https://pytorch.org/tutorials/"
])

# Search downloaded content
results = cc.search("neural networks", search_type="keyword")
```

### Academic Papers

```python
# Fetch papers from arXiv, Semantic Scholar
context = cc.from_topic(
    "transformer attention mechanisms",
    sources=["papers"],
    max_results=10
)
```

### GitHub Repositories

```python
# Search and download GitHub repos
context = cc.from_topic(
    "pytorch neural networks",
    sources=["github"],
    github_options={
        "language": "python",
        "min_stars": 500
    }
)
```

### Semantic Search (Optional)

```python
from crazycontext.bridges import CrazyContextLoader

# Initialize with Deep-Searcher integration
loader = CrazyContextLoader()

# Gather with CrazyContext, search with Deep-Searcher
loader.load_from_crazycontext(
    topic="AI",
    sources=["web", "papers", "github"]
)

# Semantic query (uses FREE Gemini embeddings!)
answer = loader.query("What is deep learning?")
print(answer['answer'])
```

---

## 🎯 Use Cases

- **Research** - Gather papers, web articles, and code examples
- **Documentation** - Download and search technical docs
- **Coding Assistants** - GitHub code examples + documentation
- **Knowledge Bases** - Multi-source context for RAG systems
- **Content Creation** - Research and fact-checking

---

## 📚 Documentation

### 🎯 Start Here
- **[Getting Started Guide](./docs/GETTING_STARTED.md)** - Installation, quick start, basic concepts
- **[Examples](./docs/EXAMPLES.md)** - Real-world use cases
- **[CLI Guide](./docs/CLI_GUIDE.md)** - Command-line interface

### 📖 Reference
- **[API Reference](./docs/API_REFERENCE.md)** - Complete API documentation
- **[Best Practices](./docs/BEST_PRACTICES.md)** - Guidelines and recommendations
- **[llm.txt](./llm.txt)** - LLM-optimized reference for AI assistants

### 📋 Full Documentation
- **[Documentation Index](./docs/README.md)** - Complete documentation overview

### 🗺️ Architecture & Design
- [Unification Plan](../CRAZYCONTEXT_UNIFICATION_PLAN.md) - Architecture & design
- [Quick Reference](../CRAZYCONTEXT_QUICK_REFERENCE.md) - API cheatsheet
- [GitHub Integration](../CRAZYCONTEXT_GITHUB_SOURCE.md) - GitHub features
- [Deep-Searcher Bridge](../CRAZYCONTEXT_AS_DEEPSEARCHER_LOADER.md) - Semantic search

---

## 🔧 Development

```bash
# Clone repository
git clone https://github.com/crazycontext/crazycontext.git
cd crazycontext

# Install in development mode
pip install -e .[dev]

# Run tests
pytest

# Format code
black crazycontext/
```

---

## 🤝 Contributing

Contributions are welcome! Please read our [Contributing Guide](CONTRIBUTING.md) first.

---

## 📄 License

Apache 2.0 - see [LICENSE](LICENSE) file for details.

---

## 🌟 Features Comparison

| Feature | CrazyContext Alone | + Deep-Searcher Bridge |
|---------|-------------------|----------------------|
| Multi-source gather | ✅ | ✅ |
| Keyword search | ✅ | ✅ |
| Fuzzy search | ✅ | ✅ |
| Semantic search | ❌ | ✅ |
| GitHub integration | ✅ | ✅ |
| Cost | Free | ~$0.001-0.01/query |
| Setup | Simple | Moderate |

---

## 💡 Why CrazyContext?

- **Simple** - Works out of the box, no complex setup
- **Flexible** - Use standalone or with semantic search
- **Cost-effective** - Free core, optional paid features
- **No lock-in** - Works with any LLM framework
- **Production-ready** - Battle-tested, well-documented

---

**Built with ❤️ for the LLM community**

*Making context building crazy simple!* 🎯
