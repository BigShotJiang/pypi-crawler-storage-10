"""Tests for Deep-Searcher bridge."""

import pytest
import tempfile
import os

# Check if deepsearcher is available
try:
    from crazycontext.bridges import CrazyContextLoader, quick_setup
    DEEPSEARCHER_AVAILABLE = True
except ImportError:
    DEEPSEARCHER_AVAILABLE = False


@pytest.mark.skipif(not DEEPSEARCHER_AVAILABLE, reason="Deep-Searcher not installed")
def test_bridge_import():
    """Test importing bridge components."""
    from crazycontext.bridges import CrazyContextLoader, quick_setup
    
    assert CrazyContextLoader is not None
    assert quick_setup is not None


@pytest.mark.skipif(not DEEPSEARCHER_AVAILABLE, reason="Deep-Searcher not installed")
def test_crazy_context_loader_init():
    """Test CrazyContextLoader initialization."""
    if not DEEPSEARCHER_AVAILABLE:
        pytest.skip("Deep-Searcher not installed")
    
    from crazycontext.bridges import CrazyContextLoader
    
    with tempfile.TemporaryDirectory() as tmpdir:
        milvus_path = os.path.join(tmpdir, "test.db")
        
        try:
            loader = CrazyContextLoader(milvus_uri=milvus_path)
            
            assert loader.milvus_uri == milvus_path
            assert loader.llm_provider == "Gemini"
            assert loader.embedding_provider == "GeminiEmbedding"
        except Exception as e:
            # If Deep-Searcher has dependency issues, skip
            pytest.skip(f"Deep-Searcher dependency issue: {e}")


@pytest.mark.skipif(not DEEPSEARCHER_AVAILABLE, reason="Deep-Searcher not installed")
def test_load_from_cache():
    """Test loading from cache."""
    if not DEEPSEARCHER_AVAILABLE:
        pytest.skip("Deep-Searcher not installed")
    
    from crazycontext.bridges import CrazyContextLoader
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create test cache with files
        cache_dir = os.path.join(tmpdir, "cache")
        os.makedirs(cache_dir)
        
        # Create test file
        test_file = os.path.join(cache_dir, "test.md")
        with open(test_file, 'w') as f:
            f.write("# Test\n\nThis is a test document.")
        
        milvus_path = os.path.join(tmpdir, "test.db")
        
        try:
            loader = CrazyContextLoader(milvus_uri=milvus_path)
            
            # This would actually load if Deep-Searcher is properly configured
            # For now, just test the interface exists
            assert hasattr(loader, 'load_from_cache')
        except Exception as e:
            pytest.skip(f"Deep-Searcher dependency issue: {e}")


@pytest.mark.skipif(not DEEPSEARCHER_AVAILABLE, reason="Deep-Searcher not installed")
def test_get_collections():
    """Test getting collections info."""
    if not DEEPSEARCHER_AVAILABLE:
        pytest.skip("Deep-Searcher not installed")
    
    from crazycontext.bridges import CrazyContextLoader
    
    with tempfile.TemporaryDirectory() as tmpdir:
        milvus_path = os.path.join(tmpdir, "test.db")
        
        try:
            loader = CrazyContextLoader(milvus_uri=milvus_path)
            
            collections = loader.get_collections()
            
            assert 'total_collections' in collections
            assert 'collections' in collections
            assert 'milvus_uri' in collections
        except Exception as e:
            pytest.skip(f"Deep-Searcher dependency issue: {e}")


def test_bridge_not_available():
    """Test graceful handling when Deep-Searcher not installed."""
    if DEEPSEARCHER_AVAILABLE:
        pytest.skip("Deep-Searcher is installed")
    
    # Bridge should not be in __all__ when not installed
    from crazycontext import bridges
    assert hasattr(bridges, '__all__')


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
