"""Tests for search modules."""

import pytest
import tempfile
import os
from crazycontext.search import keyword, fuzzy


def test_keyword_search_in_text():
    """Test keyword search in text."""
    text = "Python is great. Python is awesome. Python rocks."
    matches = keyword.search_in_text(text, "python", case_sensitive=False)
    
    assert len(matches) == 3
    assert all("Python" in m['match_text'] for m in matches)


def test_keyword_search_case_sensitive():
    """Test case sensitive search."""
    text = "Python python PYTHON"
    
    # Case insensitive
    matches = keyword.search_in_text(text, "python", case_sensitive=False)
    assert len(matches) == 3
    
    # Case sensitive
    matches = keyword.search_in_text(text, "python", case_sensitive=True)
    assert len(matches) == 1


def test_keyword_search_in_file():
    """Test searching in a file."""
    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = os.path.join(tmpdir, "test.txt")
        with open(test_file, 'w') as f:
            f.write("machine learning and deep learning are important")
        
        result = keyword.search_in_file(test_file, "learning")
        
        assert result is not None
        assert result['match_count'] == 2
        assert result['file'] == test_file


def test_keyword_search_in_directory():
    """Test searching in directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create test files
        for i in range(3):
            with open(os.path.join(tmpdir, f"file{i}.txt"), 'w') as f:
                f.write(f"Content with keyword here in file {i}")
        
        results = keyword.search_in_directory(tmpdir, "keyword", recursive=False)
        
        assert len(results) == 3
        assert all(r['match_count'] >= 1 for r in results)


def test_keyword_multi_keyword_or():
    """Test OR logic for multiple keywords."""
    with tempfile.TemporaryDirectory() as tmpdir:
        with open(os.path.join(tmpdir, "file1.txt"), 'w') as f:
            f.write("Python programming")
        with open(os.path.join(tmpdir, "file2.txt"), 'w') as f:
            f.write("JavaScript programming")
        
        results = keyword.search_with_multiple_keywords(
            tmpdir,
            ["Python", "JavaScript"],
            match_all=False
        )
        
        assert len(results) == 2


def test_fuzzy_match_score():
    """Test fuzzy matching scores."""
    # Exact match
    score = fuzzy.fuzzy_match_score("machine learning", "machine learning")
    assert score >= 95
    
    # With typo
    score = fuzzy.fuzzy_match_score("machine learning", "machne lerning")
    assert score >= 70
    
    # Very different
    score = fuzzy.fuzzy_match_score("machine learning", "completely different")
    assert score < 50


def test_fuzzy_search_in_text():
    """Test fuzzy search with typos."""
    text = "Deep learning and machine learning are popular fields"
    
    # Search with typo
    matches = fuzzy.fuzzy_search_in_text(
        text,
        "machne lerning",
        threshold=70
    )
    
    assert len(matches) > 0
    assert matches[0]['score'] >= 70


def test_suggest_corrections():
    """Test spelling correction suggestions."""
    known_terms = ["machine learning", "deep learning", "neural network"]
    
    suggestions = fuzzy.suggest_corrections(
        "machne lerning",
        known_terms,
        threshold=70
    )
    
    assert len(suggestions) > 0
    assert "machine learning" in [s['term'] for s in suggestions]


def test_find_similar_terms():
    """Test finding similar terms."""
    terms = ["neural networks", "deep learning", "machine learning"]
    
    similar = fuzzy.find_similar_terms(
        "neural nets",
        terms,
        threshold=60
    )
    
    assert len(similar) > 0
    # "neural networks" should be most similar
    assert "neural" in similar[0]['term'].lower()


def test_context_snippet():
    """Test context snippet extraction."""
    text = "This is some text before the match and some text after the match."
    snippet = keyword.get_context_snippet(text, 30, 40)
    
    assert len(snippet) <= 46  # 40 + ellipsis
    assert "match" in snippet.lower()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
