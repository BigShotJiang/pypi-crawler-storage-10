"""Tests for converter module."""

import pytest
import tempfile
import os
from crazycontext.core.converter import (
    MarkdownConverter,
    html_to_text,
    extract_title,
    extract_metadata
)


def test_markdown_converter_basic():
    """Test basic HTML to Markdown conversion."""
    converter = MarkdownConverter()
    
    html = "<h1>Title</h1><p>This is a paragraph.</p>"
    markdown = converter.convert_html(html)
    
    assert "# Title" in markdown
    assert "This is a paragraph" in markdown


def test_markdown_converter_links():
    """Test link handling."""
    converter = MarkdownConverter(ignore_links=False)
    
    html = '<a href="https://example.com">Link</a>'
    markdown = converter.convert_html(html)
    
    assert "Link" in markdown
    assert "example.com" in markdown or "[Link]" in markdown


def test_markdown_converter_ignore_links():
    """Test ignoring links."""
    converter = MarkdownConverter(ignore_links=True)
    
    html = '<a href="https://example.com">Link Text</a>'
    markdown = converter.convert_html(html)
    
    assert "Link Text" in markdown
    assert "https://" not in markdown


def test_html_to_text():
    """Test HTML to plain text conversion."""
    html = "<p>Hello <b>World</b></p><script>alert('test')</script>"
    text = html_to_text(html)
    
    assert "Hello World" in text
    assert "script" not in text
    assert "alert" not in text


def test_extract_title():
    """Test title extraction."""
    html = "<html><head><title>My Page Title</title></head><body></body></html>"
    title = extract_title(html)
    
    assert title == "My Page Title"


def test_extract_title_missing():
    """Test title extraction with no title tag."""
    html = "<html><body><h1>Heading</h1></body></html>"
    title = extract_title(html)
    
    assert title == ""


def test_extract_metadata():
    """Test metadata extraction."""
    html = """
    <html>
    <head>
        <title>Test Page</title>
        <meta name="description" content="Page description">
        <meta name="keywords" content="test, page">
        <meta property="og:title" content="OG Title">
    </head>
    </html>
    """
    
    metadata = extract_metadata(html)
    
    assert metadata['title'] == "Test Page"
    assert metadata['description'] == "Page description"
    assert metadata['keywords'] == "test, page"
    assert metadata['og:title'] == "OG Title"


def test_convert_file():
    """Test file conversion."""
    converter = MarkdownConverter()
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create test HTML file
        html_file = os.path.join(tmpdir, "test.html")
        with open(html_file, 'w') as f:
            f.write("<h1>Test</h1><p>Content</p>")
        
        # Convert
        md_file = converter.convert_file(html_file)
        
        assert md_file is not None
        assert os.path.exists(md_file)
        
        # Check content
        with open(md_file, 'r') as f:
            content = f.read()
            assert "# Test" in content
            assert "Content" in content


def test_convert_directory():
    """Test directory conversion."""
    converter = MarkdownConverter()
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create test HTML files
        for i in range(3):
            html_file = os.path.join(tmpdir, f"page{i}.html")
            with open(html_file, 'w') as f:
                f.write(f"<h1>Page {i}</h1>")
        
        # Convert directory
        results = converter.convert_directory(tmpdir, recursive=False)
        
        assert len(results) == 3
        for html_path, md_path in results.items():
            assert os.path.exists(md_path)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
