"""Tests for context builders, profiles, and formatters."""

import pytest
from crazycontext.builders import (
    ContextBuilder,
    ResearchProfile,
    CodingProfile,
    DocumentationProfile,
    QuickProfile,
    GeneralProfile,
    get_profile,
    list_profiles,
    PlainFormatter,
    MarkdownFormatter,
    ChatMLFormatter,
    AlpacaFormatter,
    LlamaFormatter,
    JSONFormatter,
    get_formatter,
    list_formatters
)


# Mock search results for testing
MOCK_RESULTS = [
    {
        'file': 'test1.txt',
        'match_count': 2,
        'matches': [
            {'context': 'Machine learning is a subset of AI.', 'position': 0},
            {'context': 'Neural networks are powerful.', 'position': 50}
        ]
    },
    {
        'file': 'test2.txt',
        'match_count': 1,
        'matches': [
            {'context': 'Deep learning uses multiple layers.', 'position': 0}
        ]
    }
]


# ===== Context Builder Tests =====

def test_context_builder_init():
    """Test ContextBuilder initialization."""
    builder = ContextBuilder(max_tokens=1000)
    
    assert builder.max_tokens == 1000
    assert builder.chars_per_token == 4.0


def test_estimate_tokens():
    """Test token estimation."""
    builder = ContextBuilder()
    
    text = "Hello, world!" * 100  # ~1300 chars
    tokens = builder.estimate_tokens(text)
    
    assert tokens > 0
    assert tokens == len(text) / 4.0


def test_build_markdown():
    """Test building markdown context."""
    builder = ContextBuilder(max_tokens=1000)
    
    context = builder.build(MOCK_RESULTS, format="markdown")
    
    assert isinstance(context, str)
    assert "## Source:" in context
    assert "Machine learning" in context


def test_build_plain():
    """Test building plain text context."""
    builder = ContextBuilder()
    
    context = builder.build(MOCK_RESULTS, format="plain")
    
    assert isinstance(context, str)
    assert "Machine learning" in context


def test_build_json():
    """Test building JSON context."""
    builder = ContextBuilder()
    
    context = builder.build(MOCK_RESULTS, format="json")
    
    assert isinstance(context, str)
    assert "{" in context
    import json
    data = json.loads(context)
    assert isinstance(data, list)


def test_build_max_results():
    """Test max_results limit."""
    builder = ContextBuilder()
    
    context = builder.build(MOCK_RESULTS, max_results=1)
    
    # Should only include one result
    assert context.count("## Source:") <= 1


def test_build_no_sources():
    """Test building without source attribution."""
    builder = ContextBuilder()
    
    context = builder.build(MOCK_RESULTS, include_sources=False)
    
    assert "## Source:" not in context
    assert "Machine learning" in context


def test_build_prompt():
    """Test building complete prompt."""
    builder = ContextBuilder()
    
    prompt = builder.build_prompt(
        MOCK_RESULTS,
        question="What is machine learning?",
        system_prompt="You are a helpful assistant."
    )
    
    assert "You are a helpful assistant" in prompt
    assert "Context:" in prompt
    assert "Question: What is machine learning?" in prompt
    assert "Answer:" in prompt


def test_chunk_text():
    """Test text chunking."""
    builder = ContextBuilder()
    
    text = "A" * 1500
    chunks = builder.chunk_text(text, chunk_size=500, overlap=50)
    
    assert len(chunks) > 1
    assert all(len(chunk) <= 550 for chunk in chunks)  # 500 + overlap tolerance


def test_summarize_results():
    """Test result summarization."""
    builder = ContextBuilder()
    
    summary = builder.summarize_results(MOCK_RESULTS)
    
    assert summary['result_count'] == 2
    assert summary['source_count'] == 2
    assert summary['total_matches'] == 3
    assert 'test1.txt' in summary['sources']


def test_invalid_format():
    """Test invalid format handling."""
    builder = ContextBuilder()
    
    with pytest.raises(ValueError):
        builder.build(MOCK_RESULTS, format="invalid")


# ===== Profile Tests =====

def test_research_profile():
    """Test research profile."""
    profile = ResearchProfile()
    
    assert profile.name == "research"
    assert profile.max_tokens == 8000
    assert profile.format == "markdown"
    assert profile.include_sources == True
    assert profile.max_results == 20


def test_coding_profile():
    """Test coding profile."""
    profile = CodingProfile()
    
    assert profile.name == "coding"
    assert profile.max_tokens == 6000
    assert profile.format == "plain"


def test_documentation_profile():
    """Test documentation profile."""
    profile = DocumentationProfile()
    
    assert profile.name == "documentation"
    assert profile.max_tokens == 10000
    assert profile.max_results == 25


def test_quick_profile():
    """Test quick profile."""
    profile = QuickProfile()
    
    assert profile.name == "quick"
    assert profile.max_tokens == 2000
    assert profile.include_sources == False


def test_general_profile():
    """Test general profile."""
    profile = GeneralProfile()
    
    assert profile.name == "general"
    assert profile.max_tokens == 4000


def test_get_profile():
    """Test getting profile by name."""
    profile = get_profile("research")
    
    assert isinstance(profile, ResearchProfile)
    assert profile.name == "research"


def test_get_profile_invalid():
    """Test getting invalid profile."""
    with pytest.raises(ValueError):
        get_profile("nonexistent")


def test_list_profiles():
    """Test listing available profiles."""
    profiles = list_profiles()
    
    assert isinstance(profiles, list)
    assert "research" in profiles
    assert "coding" in profiles
    assert "general" in profiles


def test_profile_to_dict():
    """Test converting profile to dictionary."""
    profile = GeneralProfile()
    data = profile.to_dict()
    
    assert data['name'] == "general"
    assert data['max_tokens'] == 4000
    assert isinstance(data, dict)


# ===== Formatter Tests =====

def test_plain_formatter():
    """Test plain text formatter."""
    formatter = PlainFormatter()
    
    output = formatter.format("Context text", question="What is this?")
    
    assert "Context text" in output
    assert "Question: What is this?" in output
    assert "Answer:" in output


def test_markdown_formatter():
    """Test markdown formatter."""
    formatter = MarkdownFormatter()
    
    output = formatter.format("Context text", question="Question?")
    
    assert "# Context" in output
    assert "## Question" in output
    assert "## Answer" in output


def test_chatml_formatter():
    """Test ChatML formatter."""
    formatter = ChatMLFormatter()
    
    output = formatter.format("Context text", question="Query?")
    
    assert "<|im_start|>system" in output
    assert "<|im_start|>user" in output
    assert "<|im_start|>assistant" in output
    assert "<|im_end|>" in output


def test_alpaca_formatter():
    """Test Alpaca formatter."""
    formatter = AlpacaFormatter()
    
    output = formatter.format("Context text", question="Question?")
    
    assert "### Context" in output
    assert "### Instruction" in output
    assert "### Response" in output


def test_llama_formatter():
    """Test Llama formatter."""
    formatter = LlamaFormatter()
    
    output = formatter.format("Context text", question="Question?")
    
    assert "[INST]" in output
    assert "[/INST]" in output
    assert "Context text" in output


def test_json_formatter():
    """Test JSON formatter."""
    formatter = JSONFormatter()
    
    output = formatter.format("Context text", question="Question?")
    
    import json
    data = json.loads(output)
    
    assert data['context'] == "Context text"
    assert data['question'] == "Question?"


def test_formatter_without_question():
    """Test formatters without question."""
    formatter = PlainFormatter()
    
    output = formatter.format("Just context")
    
    assert "Just context" in output
    assert "Question:" not in output


def test_get_formatter():
    """Test getting formatter by name."""
    formatter = get_formatter("markdown")
    
    assert isinstance(formatter, MarkdownFormatter)


def test_get_formatter_invalid():
    """Test getting invalid formatter."""
    with pytest.raises(ValueError):
        get_formatter("nonexistent")


def test_list_formatters():
    """Test listing available formatters."""
    formatters = list_formatters()
    
    assert isinstance(formatters, list)
    assert "plain" in formatters
    assert "markdown" in formatters
    assert "chatml" in formatters
    assert "json" in formatters


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
