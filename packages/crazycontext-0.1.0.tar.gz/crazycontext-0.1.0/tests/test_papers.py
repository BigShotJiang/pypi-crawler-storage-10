"""Tests for papers source and APIs."""

import pytest
import tempfile
import os
from unittest.mock import Mock, patch
from crazycontext.sources import PapersSource
from crazycontext.sources.apis import ArxivAPI, SemanticScholarAPI, normalize_paper, APIError


# Mock paper data
MOCK_ARXIV_RESPONSE = """<?xml version="1.0" encoding="UTF-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <entry>
    <id>http://arxiv.org/abs/1234.5678v1</id>
    <title>Test Paper Title</title>
    <summary>This is a test abstract about neural networks.</summary>
    <published>2023-01-15T00:00:00Z</published>
    <author><name>John Doe</name></author>
    <author><name>Jane Smith</name></author>
    <link href="http://arxiv.org/pdf/1234.5678v1" title="pdf"/>
  </entry>
</feed>"""

MOCK_S2_RESPONSE = {
    "data": [
        {
            "paperId": "test123",
            "title": "Machine Learning Paper",
            "abstract": "Abstract about machine learning algorithms.",
            "year": 2023,
            "authors": [{"name": "Alice"}],
            "url": "https://example.com/paper"
        }
    ]
}


def test_arxiv_api_search():
    """Test arXiv API search."""
    with patch('requests.get') as mock_get:
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.content = MOCK_ARXIV_RESPONSE.encode('utf-8')
        mock_get.return_value = mock_response
        
        papers = ArxivAPI.search("neural networks", max_results=1)
        
        assert len(papers) == 1
        assert papers[0]['title'] == "Test Paper Title"
        assert papers[0]['source'] == 'arxiv'
        assert len(papers[0]['authors']) == 2


def test_arxiv_api_error():
    """Test arXiv API error handling."""
    with patch('requests.get') as mock_get:
        mock_get.side_effect = Exception("Network error")
        
        with pytest.raises(APIError):
            ArxivAPI.search("test")


def test_semantic_scholar_api_search():
    """Test Semantic Scholar API search."""
    api = SemanticScholarAPI()
    
    with patch('requests.get') as mock_get:
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = MOCK_S2_RESPONSE
        mock_get.return_value = mock_response
        
        papers = api.search("machine learning", max_results=1)
        
        assert len(papers) == 1
        assert papers[0]['title'] == "Machine Learning Paper"
        assert papers[0]['source'] == 'semantic_scholar'


def test_semantic_scholar_with_api_key():
    """Test Semantic Scholar API with key."""
    api = SemanticScholarAPI(api_key="test_key")
    
    assert api.api_key == "test_key"
    assert 'x-api-key' in api.headers


def test_normalize_paper():
    """Test paper normalization."""
    arxiv_paper = {
        'id': 'test123',
        'title': ' Test Paper ',
        'summary': ' Test abstract ',
        'authors': ['Author 1'],
        'published': '2023-01-15',
        'source': 'arxiv'
    }
    
    normalized = normalize_paper(arxiv_paper)
    
    assert normalized['title'] == 'Test Paper'
    assert normalized['summary'] == 'Test abstract'
    assert normalized['year'] == '2023'


def test_papers_source_init():
    """Test PapersSource initialization."""
    with tempfile.TemporaryDirectory() as tmpdir:
        papers = PapersSource(cache_dir=tmpdir)
        
        assert papers.cache_dir == tmpdir
        assert papers.s2_api is not None


def test_papers_source_search():
    """Test searching papers."""
    with tempfile.TemporaryDirectory() as tmpdir:
        papers = PapersSource(cache_dir=tmpdir)
        
        with patch.object(ArxivAPI, 'search') as mock_arxiv:
            mock_arxiv.return_value = [{
                'id': 'test1',
                'title': 'Test Paper',
                'summary': 'Test abstract',
                'authors': ['Author'],
                'published': '2023',
                'source': 'arxiv'
            }]
            
            results = papers.search("test", sources=["arxiv"], max_results=1)
            
            assert len(results) >= 1
            assert results[0]['title'] == 'Test Paper'


def test_papers_source_search_multiple_sources():
    """Test searching multiple sources."""
    with tempfile.TemporaryDirectory() as tmpdir:
        papers = PapersSource(cache_dir=tmpdir)
        
        with patch.object(ArxivAPI, 'search') as mock_arxiv, \
             patch.object(papers.s2_api, 'search') as mock_s2:
            
            mock_arxiv.return_value = [{'id': '1', 'title': 'Paper 1', 'source': 'arxiv'}]
            mock_s2.return_value = [{'id': '2', 'title': 'Paper 2', 'source': 'semantic_scholar'}]
            
            results = papers.search("test", max_results=1)
            
            # Should get results from both sources
            assert len(results) >= 2


def test_papers_source_caching():
    """Test paper caching."""
    with tempfile.TemporaryDirectory() as tmpdir:
        papers = PapersSource(cache_dir=tmpdir)
        
        # Save a mock paper
        mock_paper = {
            'id': 'test123',
            'title': 'Cached Paper',
            'summary': 'Abstract',
            'authors': ['Author'],
            'year': '2023',
            'source': 'arxiv'
        }
        
        papers._save_to_cache([mock_paper])
        
        # Check cache file exists
        cache_files = os.listdir(tmpdir)
        assert len(cache_files) >= 1


def test_papers_source_get_cached():
    """Test getting cached papers."""
    with tempfile.TemporaryDirectory() as tmpdir:
        papers = PapersSource(cache_dir=tmpdir)
        
        # Cache a paper
        mock_paper = {
            'id': 'test456',
            'title': 'Test Paper',
            'summary': 'Abstract',
            'authors': [],
            'year': '2023',
            'source': 'arxiv'
        }
        papers._save_to_cache([mock_paper])
        
        # Get cached papers
        cached = papers.get_cached_papers()
        
        assert len(cached) >= 1
        assert any(p['id'] == 'test456' for p in cached)


def test_papers_source_search_cached():
    """Test searching cached papers."""
    with tempfile.TemporaryDirectory() as tmpdir:
        papers = PapersSource(cache_dir=tmpdir)
        
        # Cache papers
        papers._save_to_cache([
            {
                'id': 'test1',
                'title': 'Machine Learning Paper',
                'summary': 'About neural networks',
                'authors': [],
                'year': '2023',
                'source': 'arxiv'
            }
        ])
        
        # Search cached
        results = papers.search_cached("neural networks")
        
        assert len(results) >= 1


def test_papers_source_filter_by_year():
    """Test filtering papers by year."""
    papers_list = [
        {'id': '1', 'title': 'Old Paper', 'year': '2010'},
        {'id': '2', 'title': 'New Paper', 'year': '2023'},
        {'id': '3', 'title': 'Recent Paper', 'year': '2024'}
    ]
    
    with tempfile.TemporaryDirectory() as tmpdir:
        papers = PapersSource(cache_dir=tmpdir)
        
        # Filter recent papers
        recent = papers.filter_by_year(papers_list, min_year=2020)
        
        assert len(recent) == 2
        assert all(int(p['year']) >= 2020 for p in recent)


def test_papers_source_get_stats():
    """Test getting statistics."""
    with tempfile.TemporaryDirectory() as tmpdir:
        papers = PapersSource(cache_dir=tmpdir)
        
        # Cache some papers
        papers._save_to_cache([
            {'id': 'test1', 'title': 'Paper 1', 'year': '2023', 'source': 'arxiv'},
            {'id': 'test2', 'title': 'Paper 2', 'year': '2023', 'source': 'semantic_scholar'}
        ])
        
        stats = papers.get_stats()
        
        assert 'total_papers' in stats
        assert 'by_source' in stats
        assert 'by_year' in stats
        assert stats['total_papers'] >= 2


def test_papers_source_clear_cache():
    """Test clearing cache."""
    with tempfile.TemporaryDirectory() as tmpdir:
        papers = PapersSource(cache_dir=tmpdir)
        
        # Cache papers
        papers._save_to_cache([
            {'id': 'test1', 'title': 'Paper'},
            {'id': 'test2', 'title': 'Paper 2'}
        ])
        
        # Clear cache
        deleted = papers.clear_cache()
        
        assert deleted >= 2
        assert len(papers.get_cached_papers()) == 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
