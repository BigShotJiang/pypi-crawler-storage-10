"""Tests for file utilities."""

import pytest
import tempfile
import os
from crazycontext.utils import file_utils


def test_ensure_dir():
    """Test directory creation."""
    with tempfile.TemporaryDirectory() as tmpdir:
        test_dir = os.path.join(tmpdir, "test", "nested")
        result = file_utils.ensure_dir(test_dir)
        
        assert os.path.exists(test_dir)
        assert os.path.isabs(result)


def test_get_files_by_extension():
    """Test file search by extension."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create test files
        open(os.path.join(tmpdir, "file1.txt"), 'w').close()
        open(os.path.join(tmpdir, "file2.md"), 'w').close()
        open(os.path.join(tmpdir, "file3.html"), 'w').close()
        
        # Search for specific extensions
        txt_files = file_utils.get_files_by_extension(tmpdir, [".txt", ".md"])
        
        assert len(txt_files) == 2
        assert any("file1.txt" in f for f in txt_files)
        assert any("file2.md" in f for f in txt_files)


def test_get_file_size():
    """Test file size retrieval."""
    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = os.path.join(tmpdir, "test.txt")
        content = "Hello, World!"
        
        with open(test_file, 'w') as f:
            f.write(content)
        
        size = file_utils.get_file_size(test_file)
        assert size == len(content)


def test_get_directory_size():
    """Test directory size calculation."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create files
        for i in range(3):
            with open(os.path.join(tmpdir, f"file{i}.txt"), 'w') as f:
                f.write("x" * 100)
        
        size = file_utils.get_directory_size(tmpdir)
        assert size == 300  # 3 files * 100 bytes


def test_get_file_extension():
    """Test file extension extraction."""
    assert file_utils.get_file_extension("file.txt") == ".txt"
    assert file_utils.get_file_extension("file.HTML") == ".html"
    assert file_utils.get_file_extension("noext") == ""


def test_is_text_file():
    """Test text file detection."""
    assert file_utils.is_text_file("document.txt") == True
    assert file_utils.is_text_file("script.py") == True
    assert file_utils.is_text_file("page.html") == True
    assert file_utils.is_text_file("image.png") == False
    assert file_utils.is_text_file("video.mp4") == False


def test_read_write_file_safe():
    """Test safe file read/write."""
    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = os.path.join(tmpdir, "test.txt")
        content = "Test content"
        
        # Write
        success = file_utils.write_file_safe(test_file, content)
        assert success == True
        assert os.path.exists(test_file)
        
        # Read
        read_content = file_utils.read_file_safe(test_file)
        assert read_content == content


def test_copy_file():
    """Test file copying."""
    with tempfile.TemporaryDirectory() as tmpdir:
        source = os.path.join(tmpdir, "source.txt")
        dest = os.path.join(tmpdir, "dest.txt")
        
        with open(source, 'w') as f:
            f.write("content")
        
        success = file_utils.copy_file(source, dest)
        assert success == True
        assert os.path.exists(dest)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
