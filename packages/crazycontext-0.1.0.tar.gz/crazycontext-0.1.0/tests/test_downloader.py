"""Tests for downloader module."""

import pytest
import tempfile
import os
from crazycontext.core import downloader


def test_format_size():
    """Test format_size function."""
    assert downloader.format_size(0) == "0.00 B"
    assert downloader.format_size(1024) == "1.00 KB"
    assert downloader.format_size(1024 * 1024) == "1.00 MB"
    assert downloader.format_size(1024 * 1024 * 1024) == "1.00 GB"
    assert downloader.format_size("invalid") == "-"


def test_get_wget_executable():
    """Test wget executable discovery."""
    wget = downloader._get_wget_executable()
    # Should find either bundled or system wget, or return None
    assert wget is None or isinstance(wget, str)


def test_download_url_http():
    """Test downloading a single URL."""
    with tempfile.TemporaryDirectory() as tmpdir:
        result = downloader.download_url(
            "http://example.com",
            output_dir=tmpdir,
            use_wget=False  # Force Python fallback for consistency
        )
        
        assert isinstance(result, dict)
        assert "url" in result
        assert "status" in result
        assert result["url"] == "http://example.com"


def test_download_sites_empty():
    """Test download_sites with empty list."""
    results = downloader.download_sites([])
    assert results == []


def test_download_sites_python_fallback():
    """Test Python fallback downloader."""
    with tempfile.TemporaryDirectory() as tmpdir:
        results = downloader.download_sites(
            ["http://example.com"],
            output_dir=tmpdir,
            use_wget=False  # Force Python fallback
        )
        
        assert len(results) == 1
        assert results[0]["url"] == "http://example.com"
        assert results[0]["status"] in ["success", "failed", "404 not found"]


def test_save_results_to_log():
    """Test saving results to log file."""
    with tempfile.TemporaryDirectory() as tmpdir:
        log_path = os.path.join(tmpdir, "test.log")
        results = [{
            "timestamp": "2025-10-18 23:30:00",
            "url": "http://example.com",
            "file": "example.html",
            "status": "success",
            "size": "1.5 KB"
        }]
        
        downloader.save_results_to_log(results, log_path)
        
        assert os.path.exists(log_path)
        with open(log_path, "r") as f:
            content = f.read()
            assert "example.com" in content
            assert "success" in content


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
