"""Tests for CLI functionality."""

import pytest
import tempfile
import os
import sys
from io import StringIO
from unittest.mock import patch, MagicMock


def test_cli_import():
    """Test importing CLI module."""
    from crazycontext.cli import main
    
    assert main is not None
    assert callable(main)


def test_cli_version():
    """Test --version flag."""
    from crazycontext.cli.main import main
    
    with patch('sys.argv', ['crazycontext', '--version']):
        with pytest.raises(SystemExit) as exc_info:
            main()
        
        assert exc_info.value.code == 0


def test_cli_no_command():
    """Test CLI with no command."""
    from crazycontext.cli.main import main
    
    with patch('sys.argv', ['crazycontext']):
        with pytest.raises(SystemExit) as exc_info:
            main()
        
        assert exc_info.value.code == 0


def test_download_command_interface():
    """Test download command interface."""
    from crazycontext.cli.main import download_command
    
    # Test that function exists and has correct signature
    assert callable(download_command)


def test_search_command_interface():
    """Test search command interface."""
    from crazycontext.cli.main import search_command
    
    assert callable(search_command)


def test_stats_command_interface():
    """Test stats command interface."""
    from crazycontext.cli.main import stats_command
    
    assert callable(stats_command)


def test_papers_command_interface():
    """Test papers command interface."""
    from crazycontext.cli.main import papers_command
    
    assert callable(papers_command)


def test_github_command_interface():
    """Test GitHub command interface."""
    from crazycontext.cli.main import github_command
    
    assert callable(github_command)


def test_stats_command_execution():
    """Test stats command execution."""
    from crazycontext.cli.main import stats_command
    
    # Create mock args
    args = MagicMock()
    args.cache_dir = tempfile.mkdtemp()
    
    try:
        # Should not raise exception
        stats_command(args)
    except Exception as e:
        # Some exceptions are OK if cache is empty
        assert isinstance(e, (FileNotFoundError, KeyError)) or True


def test_search_command_with_local():
    """Test search command with local directory."""
    from crazycontext.cli.main import search_command
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create test file
        test_file = os.path.join(tmpdir, "test.txt")
        with open(test_file, 'w') as f:
            f.write("machine learning test content")
        
        args = MagicMock()
        args.cache_dir = tmpdir
        args.query = "machine"
        args.fuzzy = False
        args.sources = None
        args.local = tmpdir
        args.max_results = 5
        args.verbose = False
        
        # Should execute without error
        try:
            search_command(args)
        except SystemExit:
            pass  # OK if exits


def test_cli_keyboard_interrupt():
    """Test CLI handles keyboard interrupt."""
    from crazycontext.cli.main import main, stats_command
    
    with patch('sys.argv', ['crazycontext', 'stats']):
        with patch('crazycontext.main.CrazyContext') as mock_cc:
            mock_cc.return_value.get_stats.side_effect = KeyboardInterrupt
            
            with pytest.raises(SystemExit) as exc_info:
                main()
            
            assert exc_info.value.code == 130


def test_cli_error_handling():
    """Test CLI error handling."""
    from crazycontext.cli.main import main
    
    with patch('sys.argv', ['crazycontext', 'stats']):
        with patch('crazycontext.main.CrazyContext') as mock_cc:
            mock_cc.return_value.get_stats.side_effect = Exception("Test error")
            
            with pytest.raises(SystemExit) as exc_info:
                main()
            
            assert exc_info.value.code == 1


def test_download_command_no_args():
    """Test download command with no URLs or file."""
    from crazycontext.cli.main import download_command
    
    args = MagicMock()
    args.cache_dir = tempfile.mkdtemp()
    args.urls = None
    args.file = None
    
    with pytest.raises(SystemExit):
        download_command(args)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
