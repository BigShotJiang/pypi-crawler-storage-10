"""Tests for TOC extractor."""

import pytest
import tempfile
import os
from crazycontext.tools import TOCExtractor, extract_toc_from_directory


# Sample markdown content
SAMPLE_MARKDOWN = """# Main Title

Introduction paragraph.

## Section 1

Content for section 1.

### Subsection 1.1

Details about subsection.

## Section 2

Content for section 2.

### Subsection 2.1

More details.

#### Subsection 2.1.1

Even more details.
"""

# Sample HTML content
SAMPLE_HTML = """
<html>
<body>
<h1>Main Title</h1>
<p>Introduction</p>
<h2>Section 1</h2>
<p>Content</p>
<h3>Subsection</h3>
</body>
</html>
"""


def test_toc_extractor_init():
    """Test TOC extractor initialization."""
    extractor = TOCExtractor()
    assert extractor is not None


def test_extract_from_markdown():
    """Test extracting TOC from markdown."""
    extractor = TOCExtractor()
    
    toc = extractor.extract_from_markdown(SAMPLE_MARKDOWN)
    
    assert len(toc) > 0
    assert toc[0]['level'] == 1
    assert toc[0]['title'] == 'Main Title'
    assert toc[0]['type'] == 'markdown'


def test_extract_markdown_hierarchy():
    """Test markdown hierarchy extraction."""
    extractor = TOCExtractor()
    
    toc = extractor.extract_from_markdown(SAMPLE_MARKDOWN)
    
    # Check levels
    levels = [entry['level'] for entry in toc]
    assert 1 in levels  # h1
    assert 2 in levels  # h2
    assert 3 in levels  # h3
    assert 4 in levels  # h4


def test_extract_from_html():
    """Test extracting TOC from HTML."""
    extractor = TOCExtractor()
    
    toc = extractor.extract_from_html(SAMPLE_HTML)
    
    assert len(toc) > 0
    assert toc[0]['level'] == 1
    assert 'Main Title' in toc[0]['title']
    assert toc[0]['type'] == 'html'


def test_extract_from_markdown_file():
    """Test extracting TOC from markdown file."""
    extractor = TOCExtractor()
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create test markdown file
        test_file = os.path.join(tmpdir, "test.md")
        with open(test_file, 'w') as f:
            f.write(SAMPLE_MARKDOWN)
        
        toc = extractor.extract_from_file(test_file)
        
        assert len(toc) > 0
        assert toc[0]['title'] == 'Main Title'


def test_extract_from_html_file():
    """Test extracting TOC from HTML file."""
    extractor = TOCExtractor()
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create test HTML file
        test_file = os.path.join(tmpdir, "test.html")
        with open(test_file, 'w') as f:
            f.write(SAMPLE_HTML)
        
        toc = extractor.extract_from_file(test_file)
        
        assert len(toc) > 0


def test_get_section_content():
    """Test getting section content."""
    extractor = TOCExtractor()
    
    toc = extractor.extract_from_markdown(SAMPLE_MARKDOWN)
    
    # Get first section content
    section = extractor.get_section_content(
        SAMPLE_MARKDOWN,
        toc[0],
        toc[1] if len(toc) > 1 else None
    )
    
    assert isinstance(section, str)
    assert len(section) > 0


def test_get_all_context():
    """Test getting complete context."""
    extractor = TOCExtractor()
    
    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = os.path.join(tmpdir, "test.md")
        with open(test_file, 'w') as f:
            f.write(SAMPLE_MARKDOWN)
        
        context = extractor.get_all_context(test_file)
        
        assert isinstance(context, str)
        assert len(context) > 0
        assert "Table of Contents" in context
        assert "Main Title" in context


def test_get_all_context_without_toc():
    """Test getting context without TOC listing."""
    extractor = TOCExtractor()
    
    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = os.path.join(tmpdir, "test.md")
        with open(test_file, 'w') as f:
            f.write(SAMPLE_MARKDOWN)
        
        context = extractor.get_all_context(test_file, include_toc=False)
        
        assert isinstance(context, str)
        assert "Table of Contents" not in context
        assert "Main Title" in context


def test_get_context_by_sections():
    """Test getting context organized by sections."""
    extractor = TOCExtractor()
    
    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = os.path.join(tmpdir, "test.md")
        with open(test_file, 'w') as f:
            f.write(SAMPLE_MARKDOWN)
        
        sections = extractor.get_context_by_sections(test_file)
        
        assert isinstance(sections, list)
        assert len(sections) > 0
        assert 'title' in sections[0]
        assert 'content' in sections[0]
        assert 'level' in sections[0]


def test_get_context_with_max_chars():
    """Test getting context with character limit."""
    extractor = TOCExtractor()
    
    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = os.path.join(tmpdir, "test.md")
        with open(test_file, 'w') as f:
            f.write(SAMPLE_MARKDOWN)
        
        sections = extractor.get_context_by_sections(test_file, max_chars=50)
        
        assert all(len(s['content']) <= 53 for s in sections)  # 50 + "..."


def test_build_hierarchy():
    """Test building hierarchical structure."""
    extractor = TOCExtractor()
    
    toc = extractor.extract_from_markdown(SAMPLE_MARKDOWN)
    hierarchy = extractor.build_hierarchy(toc)
    
    assert 'children' in hierarchy
    assert len(hierarchy['children']) > 0


def test_extract_from_nonexistent_file():
    """Test error handling for nonexistent file."""
    extractor = TOCExtractor()
    
    with pytest.raises(FileNotFoundError):
        extractor.extract_from_file("/nonexistent/file.md")


def test_extract_toc_from_directory():
    """Test extracting TOC from directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create test files
        for i in range(3):
            test_file = os.path.join(tmpdir, f"test{i}.md")
            with open(test_file, 'w') as f:
                f.write(f"# Title {i}\n\n## Section {i}")
        
        results = extract_toc_from_directory(tmpdir)
        
        assert isinstance(results, dict)
        assert len(results) >= 3


def test_extract_toc_from_directory_with_filter():
    """Test extracting TOC with file extension filter."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create markdown file
        md_file = os.path.join(tmpdir, "test.md")
        with open(md_file, 'w') as f:
            f.write("# Markdown Title")
        
        # Create HTML file
        html_file = os.path.join(tmpdir, "test.html")
        with open(html_file, 'w') as f:
            f.write("<h1>HTML Title</h1>")
        
        # Extract only markdown
        results = extract_toc_from_directory(tmpdir, extensions=['.md'])
        
        assert len(results) == 1
        assert any('test.md' in path for path in results.keys())


def test_empty_content():
    """Test handling empty content."""
    extractor = TOCExtractor()
    
    toc = extractor.extract_from_markdown("")
    
    assert toc == []


def test_no_headers():
    """Test content with no headers."""
    extractor = TOCExtractor()
    
    content = "Just plain text without any headers."
    toc = extractor.extract_from_markdown(content)
    
    assert toc == []


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
