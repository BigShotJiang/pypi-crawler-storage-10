"""Tests for main CrazyContext API."""

import pytest
import tempfile
import os
from crazycontext import CrazyContext


def test_crazycontext_init():
    """Test CrazyContext initialization."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cc = CrazyContext(cache_dir=tmpdir)
        
        assert cc.cache_dir == tmpdir
        assert cc.web is not None
        assert cc.local is not None


def test_from_url():
    """Test downloading single URL."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cc = CrazyContext(cache_dir=tmpdir)
        
        result = cc.from_url("http://example.com", use_wget=False)
        
        assert result is not None
        assert 'status' in result


def test_from_urls():
    """Test downloading multiple URLs."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cc = CrazyContext(cache_dir=tmpdir)
        
        results = cc.from_urls(
            ["http://example.com"],
            use_wget=False
        )
        
        assert len(results) >= 1


def test_add_local_file():
    """Test adding local file."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cc = CrazyContext(cache_dir=tmpdir)
        
        # Create test file
        test_file = os.path.join(tmpdir, "test.txt")
        with open(test_file, 'w') as f:
            f.write("test content")
        
        success = cc.add_local_file(test_file)
        
        assert success == True


def test_add_local_directory():
    """Test adding local directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cc = CrazyContext(cache_dir=tmpdir)
        
        # Create test files
        test_dir = os.path.join(tmpdir, "docs")
        os.makedirs(test_dir)
        for i in range(3):
            with open(os.path.join(test_dir, f"file{i}.txt"), 'w') as f:
                f.write(f"content {i}")
        
        count = cc.add_local_directory(test_dir)
        
        assert count == 3


def test_search_local():
    """Test searching local content."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cc = CrazyContext(cache_dir=tmpdir)
        
        # Add test file
        test_file = os.path.join(tmpdir, "test.txt")
        with open(test_file, 'w') as f:
            f.write("machine learning and deep learning are important")
        
        cc.add_local_file(test_file)
        
        # Search
        results = cc.search("learning", sources=["local"])
        
        assert len(results) >= 1
        assert results[0]['match_count'] >= 2


def test_search_web():
    """Test searching web content."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cc = CrazyContext(cache_dir=tmpdir)
        
        # Create test file in web cache (directory already exists)
        web_cache = os.path.join(tmpdir, "web")
        test_file = os.path.join(web_cache, "page.txt")
        with open(test_file, 'w') as f:
            f.write("python tutorial for beginners")
        
        # Search
        results = cc.search("python", sources=["web"])
        
        assert isinstance(results, list)


def test_build_context():
    """Test building context from results."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cc = CrazyContext(cache_dir=tmpdir)
        
        # Add test file
        test_file = os.path.join(tmpdir, "test.txt")
        with open(test_file, 'w') as f:
            f.write("machine learning is a subset of artificial intelligence")
        
        cc.add_local_file(test_file)
        
        # Search and build context
        results = cc.search("machine learning", sources=["local"])
        context = cc.build_context(results, max_length=500)
        
        assert isinstance(context, str)
        assert len(context) > 0


def test_get_stats():
    """Test getting statistics."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cc = CrazyContext(cache_dir=tmpdir)
        
        stats = cc.get_stats()
        
        assert 'web' in stats
        assert 'local' in stats
        assert 'cache_size_mb' in stats['web']
        assert 'file_count' in stats['local']


def test_fuzzy_search():
    """Test fuzzy search with typos."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cc = CrazyContext(cache_dir=tmpdir)
        
        # Add test file
        test_file = os.path.join(tmpdir, "test.txt")
        with open(test_file, 'w') as f:
            f.write("machine learning algorithms are powerful")
        
        cc.add_local_file(test_file)
        
        # Search with typo
        results = cc.search(
            "machne lerning",  # Typo!
            sources=["local"],
            search_type="fuzzy",
            threshold=70
        )
        
        assert isinstance(results, list)


def test_refresh_local_index():
    """Test refreshing local index."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cc = CrazyContext(cache_dir=tmpdir)
        
        # Add directory
        test_dir = os.path.join(tmpdir, "docs")
        os.makedirs(test_dir)
        
        test_file = os.path.join(test_dir, "file1.txt")
        with open(test_file, 'w') as f:
            f.write("content")
        
        cc.add_local_directory(test_dir)
        
        # Add new file
        test_file2 = os.path.join(test_dir, "file2.txt")
        with open(test_file2, 'w') as f:
            f.write("more content")
        
        # Refresh
        count = cc.refresh_local_index()
        
        assert count == 2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
