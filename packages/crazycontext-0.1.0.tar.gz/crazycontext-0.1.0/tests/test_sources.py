"""Tests for source handlers."""

import pytest
import tempfile
import os
from crazycontext.sources import WebSource, LocalSource


def test_web_source_init():
    """Test WebSource initialization."""
    with tempfile.TemporaryDirectory() as tmpdir:
        web = WebSource(cache_dir=tmpdir)
        
        assert web.cache_dir == tmpdir
        assert web.auto_convert == True
        assert len(web.downloads_log) == 0


def test_web_source_download_url():
    """Test downloading single URL."""
    with tempfile.TemporaryDirectory() as tmpdir:
        web = WebSource(cache_dir=tmpdir, auto_convert=False)
        
        result = web.download_url("http://example.com", use_wget=False)
        
        assert result is not None
        assert 'url' in result
        assert 'status' in result


def test_web_source_get_stats():
    """Test getting download statistics."""
    with tempfile.TemporaryDirectory() as tmpdir:
        web = WebSource(cache_dir=tmpdir)
        
        # Download something
        web.download_url("http://example.com", use_wget=False)
        
        stats = web.get_download_stats()
        
        assert 'total' in stats
        assert 'success' in stats
        assert 'cache_size' in stats
        assert stats['total'] >= 1


def test_web_source_search():
    """Test searching web content."""
    with tempfile.TemporaryDirectory() as tmpdir:
        web = WebSource(cache_dir=tmpdir)
        
        # Create test file
        test_file = os.path.join(tmpdir, "test.txt")
        with open(test_file, 'w') as f:
            f.write("machine learning is awesome")
        
        # Search
        results = web.search("machine learning")
        
        assert isinstance(results, list)


def test_local_source_init():
    """Test LocalSource initialization."""
    local = LocalSource()
    
    assert len(local.indexed_files) == 0
    assert len(local.indexed_paths) == 0


def test_local_source_add_file():
    """Test adding single file."""
    with tempfile.TemporaryDirectory() as tmpdir:
        local = LocalSource()
        
        # Create test file
        test_file = os.path.join(tmpdir, "test.txt")
        with open(test_file, 'w') as f:
            f.write("test content")
        
        # Add file
        success = local.add_file(test_file)
        
        assert success == True
        assert len(local.indexed_files) == 1


def test_local_source_add_directory():
    """Test adding directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        local = LocalSource()
        
        # Create test files
        for i in range(3):
            with open(os.path.join(tmpdir, f"file{i}.txt"), 'w') as f:
                f.write(f"content {i}")
        
        # Add directory
        count = local.add_directory(tmpdir, recursive=False)
        
        assert count == 3
        assert len(local.indexed_files) == 3


def test_local_source_search():
    """Test searching local files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        local = LocalSource()
        
        # Create test files
        test_file = os.path.join(tmpdir, "test.txt")
        with open(test_file, 'w') as f:
            f.write("machine learning and deep learning")
        
        local.add_file(test_file)
        
        # Search
        results = local.search("learning")
        
        assert len(results) >= 1
        assert results[0]['match_count'] >= 2


def test_local_source_get_stats():
    """Test getting statistics."""
    with tempfile.TemporaryDirectory() as tmpdir:
        local = LocalSource()
        
        # Create test files
        for i in range(3):
            test_file = os.path.join(tmpdir, f"file{i}.txt")
            with open(test_file, 'w') as f:
                f.write("content " * 100)
            local.add_file(test_file)
        
        stats = local.get_stats()
        
        assert stats['file_count'] == 3
        assert stats['total_size'] > 0


def test_local_source_clear_index():
    """Test clearing index."""
    with tempfile.TemporaryDirectory() as tmpdir:
        local = LocalSource()
        
        # Add some files
        test_file = os.path.join(tmpdir, "test.txt")
        with open(test_file, 'w') as f:
            f.write("content")
        local.add_file(test_file)
        
        assert len(local.indexed_files) == 1
        
        # Clear
        local.clear_index()
        
        assert len(local.indexed_files) == 0


def test_local_source_refresh_index():
    """Test refreshing index."""
    with tempfile.TemporaryDirectory() as tmpdir:
        local = LocalSource()
        
        # Create initial file
        test_file1 = os.path.join(tmpdir, "file1.txt")
        with open(test_file1, 'w') as f:
            f.write("content")
        
        # Add directory
        local.add_directory(tmpdir)
        assert len(local.indexed_files) == 1
        
        # Create new file
        test_file2 = os.path.join(tmpdir, "file2.txt")
        with open(test_file2, 'w') as f:
            f.write("more content")
        
        # Refresh
        count = local.refresh_index()
        
        assert count == 2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
