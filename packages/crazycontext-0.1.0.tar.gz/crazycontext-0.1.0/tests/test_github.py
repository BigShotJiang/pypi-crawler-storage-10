"""Tests for GitHub source handler."""

import pytest
import tempfile
import os
from unittest.mock import Mock, patch, MagicMock
from crazycontext.sources import GitHubSource


# Mock GitHub API responses
MOCK_REPO_SEARCH = {
    "items": [
        {
            "id": 123,
            "name": "test-repo",
            "full_name": "user/test-repo",
            "description": "Test repository",
            "stargazers_count": 100,
            "forks_count": 20,
            "language": "Python",
            "html_url": "https://github.com/user/test-repo",
            "clone_url": "https://github.com/user/test-repo.git",
            "default_branch": "main"
        }
    ]
}

MOCK_REPO_CONTENTS = [
    {
        "name": "test.py",
        "path": "test.py",
        "type": "file",
        "size": 1024,
        "download_url": "https://raw.githubusercontent.com/user/repo/main/test.py",
        "sha": "abc123"
    },
    {
        "name": "README.md",
        "path": "README.md",
        "type": "file",
        "size": 512,
        "download_url": "https://raw.githubusercontent.com/user/repo/main/README.md",
        "sha": "def456"
    }
]

MOCK_CODE_SEARCH = {
    "items": [
        {
            "name": "example.py",
            "path": "examples/example.py",
            "repository": {"full_name": "user/repo"},
            "html_url": "https://github.com/user/repo/blob/main/examples/example.py"
        }
    ]
}


def test_github_source_init():
    """Test GitHubSource initialization."""
    with tempfile.TemporaryDirectory() as tmpdir:
        github = GitHubSource(cache_dir=tmpdir)
        
        assert github.cache_dir == tmpdir
        assert github.github_token is None


def test_github_source_with_token():
    """Test initialization with GitHub token."""
    with tempfile.TemporaryDirectory() as tmpdir:
        github = GitHubSource(cache_dir=tmpdir, github_token="test_token")
        
        assert github.github_token == "test_token"
        assert 'Authorization' in github.headers


def test_search_repositories():
    """Test searching repositories."""
    with tempfile.TemporaryDirectory() as tmpdir:
        github = GitHubSource(cache_dir=tmpdir)
        
        with patch('requests.get') as mock_get:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = MOCK_REPO_SEARCH
            mock_get.return_value = mock_response
            
            repos = github.search_repositories("test", max_results=1)
            
            assert len(repos) == 1
            assert repos[0]['name'] == 'test-repo'
            assert repos[0]['stars'] == 100


def test_search_repositories_with_language():
    """Test repository search with language filter."""
    with tempfile.TemporaryDirectory() as tmpdir:
        github = GitHubSource(cache_dir=tmpdir)
        
        with patch('requests.get') as mock_get:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = MOCK_REPO_SEARCH
            mock_get.return_value = mock_response
            
            repos = github.search_repositories(
                "test",
                language="python",
                min_stars=50
            )
            
            assert len(repos) >= 1


def test_search_repositories_error():
    """Test repository search error handling."""
    with tempfile.TemporaryDirectory() as tmpdir:
        github = GitHubSource(cache_dir=tmpdir)
        
        with patch('requests.get') as mock_get:
            mock_get.side_effect = Exception("API error")
            
            repos = github.search_repositories("test")
            
            assert repos == []


def test_get_repo_files():
    """Test getting repository files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        github = GitHubSource(cache_dir=tmpdir)
        
        with patch('requests.get') as mock_get:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = MOCK_REPO_CONTENTS
            mock_get.return_value = mock_response
            
            files = github.get_repo_files("user/repo")
            
            assert len(files) == 2
            assert any(f['name'] == 'test.py' for f in files)


def test_get_repo_files_with_patterns():
    """Test getting files with pattern filtering."""
    with tempfile.TemporaryDirectory() as tmpdir:
        github = GitHubSource(cache_dir=tmpdir)
        
        with patch('requests.get') as mock_get:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = MOCK_REPO_CONTENTS
            mock_get.return_value = mock_response
            
            files = github.get_repo_files("user/repo", patterns=["*.py"])
            
            assert len(files) == 1
            assert files[0]['name'] == 'test.py'


def test_download_file():
    """Test downloading a single file."""
    with tempfile.TemporaryDirectory() as tmpdir:
        github = GitHubSource(cache_dir=tmpdir)
        
        with patch('requests.get') as mock_get:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.content = b"print('Hello, World!')"
            mock_get.return_value = mock_response
            
            local_path = github.download_file(
                "https://example.com/file.py",
                "user/repo",
                "test.py"
            )
            
            assert local_path is not None
            assert os.path.exists(local_path)


def test_download_repo_files():
    """Test downloading multiple files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        github = GitHubSource(cache_dir=tmpdir)
        
        with patch.object(github, 'get_repo_files') as mock_get_files, \
             patch.object(github, 'download_file') as mock_download:
            
            mock_get_files.return_value = [
                {'download_url': 'url1', 'path': 'file1.py'},
                {'download_url': 'url2', 'path': 'file2.py'}
            ]
            mock_download.return_value = "/tmp/file.py"
            
            downloaded = github.download_repo_files("user/repo", max_files=5)
            
            assert len(downloaded) == 2


def test_search_code():
    """Test code search."""
    with tempfile.TemporaryDirectory() as tmpdir:
        github = GitHubSource(cache_dir=tmpdir)
        
        with patch('requests.get') as mock_get:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = MOCK_CODE_SEARCH
            mock_get.return_value = mock_response
            
            results = github.search_code("neural network", language="python")
            
            assert len(results) == 1
            assert results[0]['name'] == 'example.py'


def test_get_cached_files():
    """Test getting cached files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        github = GitHubSource(cache_dir=tmpdir)
        
        # Create test cached files
        repo_dir = os.path.join(tmpdir, "user_repo")
        os.makedirs(repo_dir)
        
        test_file = os.path.join(repo_dir, "test.py")
        with open(test_file, 'w') as f:
            f.write("print('test')")
        
        cached = github.get_cached_files()
        
        assert len(cached) >= 1


def test_get_cached_files_by_repo():
    """Test getting cached files for specific repo."""
    with tempfile.TemporaryDirectory() as tmpdir:
        github = GitHubSource(cache_dir=tmpdir)
        
        # Create repo cache
        repo_dir = os.path.join(tmpdir, "user_repo")
        os.makedirs(repo_dir)
        
        test_file = os.path.join(repo_dir, "test.py")
        with open(test_file, 'w') as f:
            f.write("code")
        
        cached = github.get_cached_files(repo_name="user/repo")
        
        assert len(cached) >= 1


def test_search_cached():
    """Test searching cached files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        github = GitHubSource(cache_dir=tmpdir)
        
        # Create cached file
        repo_dir = os.path.join(tmpdir, "user_repo")
        os.makedirs(repo_dir)
        
        test_file = os.path.join(repo_dir, "test.py")
        with open(test_file, 'w') as f:
            f.write("def neural_network():\n    pass")
        
        results = github.search_cached("neural")
        
        assert isinstance(results, list)


def test_get_stats():
    """Test getting statistics."""
    with tempfile.TemporaryDirectory() as tmpdir:
        github = GitHubSource(cache_dir=tmpdir)
        
        # Create test files
        repo_dir = os.path.join(tmpdir, "user_repo")
        os.makedirs(repo_dir)
        
        for i in range(3):
            with open(os.path.join(repo_dir, f"file{i}.py"), 'w') as f:
                f.write("code " * 100)
        
        stats = github.get_stats()
        
        assert 'total_files' in stats
        assert 'by_extension' in stats
        assert 'cache_size' in stats
        assert stats['total_files'] >= 3


def test_clear_cache():
    """Test clearing cache."""
    with tempfile.TemporaryDirectory() as tmpdir:
        github = GitHubSource(cache_dir=tmpdir)
        
        # Create cached files
        repo_dir = os.path.join(tmpdir, "user_repo")
        os.makedirs(repo_dir)
        
        for i in range(2):
            with open(os.path.join(repo_dir, f"file{i}.py"), 'w') as f:
                f.write("code")
        
        deleted = github.clear_cache()
        
        assert deleted >= 2


def test_clear_cache_specific_repo():
    """Test clearing cache for specific repo."""
    with tempfile.TemporaryDirectory() as tmpdir:
        github = GitHubSource(cache_dir=tmpdir)
        
        # Create repo cache
        repo_dir = os.path.join(tmpdir, "user_repo")
        os.makedirs(repo_dir)
        
        test_file = os.path.join(repo_dir, "test.py")
        with open(test_file, 'w') as f:
            f.write("code")
        
        deleted = github.clear_cache(repo_name="user/repo")
        
        assert deleted >= 1


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
