# 📚 API Reference

**Complete reference for all CrazyContext classes and methods**

---

## Table of Contents

- [Main API](#main-api)
  - [CrazyContext](#crazycontext)
- [Sources](#sources)
  - [WebSource](#websource)
  - [LocalSource](#localsource)
  - [PapersSource](#paperssource)
  - [GitHubSource](#githubsource)
- [Builders](#builders)
  - [ContextBuilder](#contextbuilder)
  - [Profiles](#profiles)
  - [Formatters](#formatters)
- [Search](#search)
  - [Keyword](#keyword)
  - [Fuzzy](#fuzzy)
- [Tools](#tools)
  - [TOCExtractor](#tocextractor)
- [Bridges](#bridges)
  - [CrazyContextLoader](#crazycontextloader)

---

## Main API

### CrazyContext

Main interface for CrazyContext functionality.

#### Constructor

```python
CrazyContext(
    cache_dir: str = "./cache",
    auto_convert: bool = True,
    log_level: str = "INFO"
)
```

**Parameters:**
- `cache_dir` - Directory for cached content
- `auto_convert` - Auto-convert HTML to Markdown
- `log_level` - Logging level (DEBUG, INFO, WARNING, ERROR)

**Example:**
```python
from crazycontext import CrazyContext

cc = CrazyContext(
    cache_dir="./my_cache",
    auto_convert=True,
    log_level="INFO"
)
```

#### Methods

##### `from_url(url, **kwargs) → Dict`

Download a single URL.

**Parameters:**
- `url` (str) - URL to download
- `**kwargs` - Additional downloader options

**Returns:** Dict with keys:
- `status` (str) - "success" or "failed"
- `url` (str) - The URL
- `file` (str) - Downloaded file path
- `error` (str) - Error message if failed

**Example:**
```python
result = cc.from_url("https://docs.python.org/3/")
if result['status'] == 'success':
    print(f"Downloaded to: {result['file']}")
```

##### `from_urls(urls, **kwargs) → List[Dict]`

Download multiple URLs.

**Parameters:**
- `urls` (List[str]) - List of URLs
- `**kwargs` - Additional downloader options

**Returns:** List[Dict] - Download results

**Example:**
```python
results = cc.from_urls([
    "https://docs.python.org/3/",
    "https://pytorch.org/tutorials/"
])

success = sum(1 for r in results if r['status'] == 'success')
print(f"Downloaded {success}/{len(urls)} successfully")
```

##### `add_local_file(file_path) → bool`

Add a local file to the index.

**Parameters:**
- `file_path` (str) - Path to file

**Returns:** bool - True if added successfully

**Example:**
```python
cc.add_local_file("my_notes.md")
```

##### `add_local_directory(directory, extensions=None, recursive=True) → int`

Add all files from a directory.

**Parameters:**
- `directory` (str) - Directory path
- `extensions` (List[str], optional) - File extensions to include
- `recursive` (bool) - Search subdirectories

**Returns:** int - Number of files added

**Example:**
```python
count = cc.add_local_directory(
    "./research",
    extensions=[".md", ".txt"],
    recursive=True
)
print(f"Indexed {count} files")
```

##### `search(query, sources=None, search_type="keyword", **kwargs) → List[Dict]`

Search across all sources.

**Parameters:**
- `query` (str) - Search query
- `sources` (List[str], optional) - Sources to search (["web", "local"])
- `search_type` (str) - "keyword" or "fuzzy"
- `**kwargs` - Additional search options

**Returns:** List[Dict] with keys:
- `file` (str) - File path
- `match_count` (int) - Number of matches
- `matches` (List[Dict]) - Match details with context
- `source` (str) - "web" or "local"

**Example:**
```python
# Keyword search
results = cc.search("machine learning")

# Fuzzy search
results = cc.search(
    "machne lerning",
    search_type="fuzzy",
    threshold=70
)

# Search specific sources
results = cc.search("python", sources=["web"])
```

##### `build_context(results, max_length=None, include_sources=True) → str`

Build LLM-ready context from search results.

**Parameters:**
- `results` (List[Dict]) - Search results
- `max_length` (int, optional) - Maximum context length
- `include_sources` (bool) - Include source attribution

**Returns:** str - Formatted context

**Example:**
```python
results = cc.search("decorators")
context = cc.build_context(results, max_length=5000)
```

##### `get_stats() → Dict`

Get statistics about cached content.

**Returns:** Dict with keys:
- `web` (Dict) - Web cache statistics
- `local` (Dict) - Local index statistics

**Example:**
```python
stats = cc.get_stats()
print(f"Web cache: {stats['web']['cache_size_mb']:.2f} MB")
print(f"Local files: {stats['local']['file_count']}")
```

##### `clear_cache(source="web", older_than_days=None) → int`

Clear cached content.

**Parameters:**
- `source` (str) - "web" or "local"
- `older_than_days` (int, optional) - Only delete older files

**Returns:** int - Number of files deleted

**Example:**
```python
deleted = cc.clear_cache("web", older_than_days=7)
print(f"Deleted {deleted} old files")
```

---

## Sources

### WebSource

Handle web content as a context source.

#### Constructor

```python
WebSource(
    cache_dir: str = "./cache/web",
    auto_convert: bool = True
)
```

#### Methods

##### `download_url(url, **kwargs) → Dict`
##### `download_urls(urls, **kwargs) → List[Dict]`
##### `search(query, search_type="keyword", **kwargs) → List[Dict]`
##### `get_cached_files(extensions=None) → List[str]`
##### `get_cache_size() → int`
##### `clear_cache(older_than_days=None) → int`
##### `get_download_stats() → Dict`

---

### LocalSource

Handle local files as a context source.

#### Constructor

```python
LocalSource()
```

#### Methods

##### `add_file(file_path) → bool`
##### `add_files(file_paths) → int`
##### `add_directory(directory, extensions=None, recursive=True) → int`
##### `search(query, search_type="keyword", **kwargs) → List[Dict]`
##### `get_file_content(file_path) → Optional[str]`
##### `get_indexed_files(extensions=None) → List[str]`
##### `get_stats() → Dict`
##### `clear_index()`
##### `remove_file(file_path) → bool`
##### `refresh_index() → int`

---

### PapersSource

Search and cache academic papers.

#### Constructor

```python
PapersSource(
    cache_dir: str = "./cache/papers",
    semantic_scholar_key: Optional[str] = None
)
```

#### Methods

##### `search(query, sources=None, max_results=10) → List[Dict]`

Search for papers.

**Parameters:**
- `query` (str) - Search query
- `sources` (List[str], optional) - ["arxiv", "semantic_scholar"]
- `max_results` (int) - Maximum results per source

**Returns:** List[Dict] with paper details

**Example:**
```python
from crazycontext.sources import PapersSource

papers = PapersSource()
results = papers.search(
    "neural networks",
    sources=["arxiv", "semantic_scholar"],
    max_results=10
)

for paper in results:
    print(f"{paper['title']} ({paper['year']})")
    print(f"Authors: {', '.join(paper['authors'])}")
```

##### `filter_by_year(papers, min_year=None, max_year=None) → List[Dict]`
##### `get_cached_papers() → List[Dict]`
##### `search_cached(query, max_results=10) → List[Dict]`
##### `get_stats() → Dict`
##### `clear_cache() → int`

---

### GitHubSource

Search and download GitHub repositories.

#### Constructor

```python
GitHubSource(
    cache_dir: str = "./cache/github",
    github_token: Optional[str] = None
)
```

#### Methods

##### `search_repositories(query, language=None, min_stars=0, max_results=10, sort="stars") → List[Dict]`

Search GitHub repositories.

**Example:**
```python
from crazycontext.sources import GitHubSource

github = GitHubSource()
repos = github.search_repositories(
    "deep learning",
    language="python",
    min_stars=100,
    max_results=10
)

for repo in repos:
    print(f"{repo['full_name']}: {repo['stars']} ⭐")
```

##### `get_repo_files(repo_full_name, path="", patterns=None) → List[Dict]`
##### `download_file(download_url, repo_name, file_path) → Optional[str]`
##### `download_repo_files(repo_full_name, patterns=None, max_files=50) → List[str]`
##### `search_code(query, language=None, max_results=10) → List[Dict]`
##### `get_cached_files(repo_name=None, patterns=None) → List[str]`
##### `search_cached(query, repo_name=None) → List[Dict]`
##### `get_stats() → Dict`
##### `clear_cache(repo_name=None) → int`

---

## Builders

### ContextBuilder

Build LLM-ready context from search results.

#### Constructor

```python
ContextBuilder(
    max_tokens: int = 4000,
    chars_per_token: float = 4.0
)
```

#### Methods

##### `estimate_tokens(text) → int`

Estimate token count.

**Example:**
```python
from crazycontext.builders import ContextBuilder

builder = ContextBuilder()
tokens = builder.estimate_tokens("Hello, world!")
print(f"Estimated: {tokens} tokens")
```

##### `build(results, format="markdown", include_sources=True, max_results=None) → str`

Build context from results.

**Parameters:**
- `results` (List[Dict]) - Search results
- `format` (str) - "markdown", "plain", or "json"
- `include_sources` (bool) - Include source attribution
- `max_results` (int, optional) - Limit number of results

**Example:**
```python
context = builder.build(
    results,
    format="markdown",
    include_sources=True
)
```

##### `build_prompt(results, question, system_prompt=None) → str`

Build complete LLM prompt.

**Example:**
```python
prompt = builder.build_prompt(
    results,
    question="What is machine learning?",
    system_prompt="You are a helpful assistant."
)
```

##### `chunk_text(text, chunk_size=1000, overlap=100) → List[str]`

Split text into overlapping chunks.

**Example:**
```python
chunks = builder.chunk_text(
    long_text,
    chunk_size=500,
    overlap=50
)
```

##### `summarize_results(results) → Dict`

Get statistics about search results.

---

### Profiles

Pre-configured settings for different use cases.

#### Available Profiles

```python
from crazycontext.builders import (
    ResearchProfile,      # 8K tokens, markdown
    CodingProfile,        # 6K tokens, plain
    DocumentationProfile, # 10K tokens, markdown
    QuickProfile,         # 2K tokens, plain, no sources
    GeneralProfile        # 4K tokens, markdown (default)
)
```

#### Usage

```python
# Direct instantiation
profile = ResearchProfile()
print(f"Max tokens: {profile.max_tokens}")
print(f"Format: {profile.format}")

# Get by name
from crazycontext.builders import get_profile
profile = get_profile("research")

# List available
from crazycontext.builders import list_profiles
profiles = list_profiles()
print(f"Available: {profiles}")
```

---

### Formatters

Format context for different LLM frameworks.

#### Available Formatters

```python
from crazycontext.builders import (
    PlainFormatter,     # Plain text
    MarkdownFormatter,  # Markdown with headers
    ChatMLFormatter,    # ChatML format (<|im_start|>)
    AlpacaFormatter,    # Alpaca (###)
    LlamaFormatter,     # Llama ([INST])
    JSONFormatter       # JSON structure
)
```

#### Usage

```python
# Direct instantiation
formatter = ChatMLFormatter()
output = formatter.format(
    context,
    question="How does this work?"
)

# Get by name
from crazycontext.builders import get_formatter
formatter = get_formatter("chatml")

# List available
from crazycontext.builders import list_formatters
formatters = list_formatters()
```

---

## Search

### Keyword

Exact string matching search.

```python
from crazycontext.search import keyword

# Search in text
results = keyword.search_in_text(
    "The quick brown fox",
    "fox",
    case_sensitive=False
)

# Search in file
result = keyword.search_in_file(
    "document.txt",
    "search term",
    case_sensitive=False,
    context_lines=2
)

# Search directory
results = keyword.search_in_directory(
    "./docs",
    "query",
    extensions=[".md", ".txt"],
    recursive=True
)
```

### Fuzzy

Typo-tolerant fuzzy matching.

```python
from crazycontext.search import fuzzy

# Calculate similarity
score = fuzzy.fuzzy_match_score(
    "machine learning",
    "machne lerning"
)
print(f"Similarity: {score}%")

# Fuzzy search
results = fuzzy.fuzzy_search_in_text(
    text,
    "machne lerning",
    threshold=70
)

# Suggest corrections
suggestions = fuzzy.suggest_corrections(
    "machne lerning",
    ["machine learning", "deep learning", "reinforcement learning"],
    n=3
)
```

---

## Tools

### TOCExtractor

Extract table of contents from documents.

#### Constructor

```python
from crazycontext.tools import TOCExtractor

extractor = TOCExtractor()
```

#### Methods

##### `extract_from_markdown(content) → List[Dict]`
##### `extract_from_html(content) → List[Dict]`
##### `extract_from_file(file_path) → List[Dict]`

Extract TOC from file.

**Returns:** List[Dict] with keys:
- `level` (int) - Header level (1-6)
- `title` (str) - Section title
- `line` (int) - Line number
- `type` (str) - "markdown" or "html"

**Example:**
```python
toc = extractor.extract_from_file("guide.md")

for entry in toc:
    indent = "  " * (entry['level'] - 1)
    print(f"{indent}- {entry['title']}")
```

##### `get_all_context(file_path, include_toc=True) → str`

Get complete context with TOC structure.

**Example:**
```python
context = extractor.get_all_context(
    "guide.md",
    include_toc=True
)

# Use with LLM
prompt = f"{context}\n\nQuestion: ..."
```

##### `get_context_by_sections(file_path, max_chars=None) → List[Dict]`

Get context organized by sections.

**Example:**
```python
sections = extractor.get_context_by_sections(
    "guide.md",
    max_chars=500
)

for section in sections:
    print(f"{section['title']}: {len(section['content'])} chars")
```

##### `build_hierarchy(toc) → Dict`

Build hierarchical structure from flat TOC.

---

## Bridges

### CrazyContextLoader

Bridge to Deep-Searcher for semantic search.

**Requires:** `pip install crazycontext[deepsearcher]`

#### Constructor

```python
from crazycontext.bridges import CrazyContextLoader

loader = CrazyContextLoader(
    milvus_uri="./milvus.db",
    llm_provider="Gemini",              # FREE/cheap
    llm_model="gemini-2.0-flash-exp",
    embedding_provider="GeminiEmbedding",  # FREE!
    embedding_model="text-embedding-004"
)
```

#### Methods

##### `load_from_cache(cache_dir, collection_name=None, file_extensions=None) → int`

Load CrazyContext cache into Deep-Searcher.

**Example:**
```python
count = loader.load_from_cache("./cache/web")
print(f"Loaded {count} files")
```

##### `query(question, collection_name=None, top_k=5) → Dict`

Semantic query using Deep-Searcher.

**Returns:** Dict with keys:
- `answer` (str) - Generated answer
- `sources` (List) - Source documents
- `tokens` (int) - Tokens used
- `question` (str) - Original question

**Example:**
```python
answer = loader.query(
    "What is machine learning?",
    top_k=5
)

print(f"Answer: {answer['answer']}")
print(f"Sources: {len(answer['sources'])}")
print(f"Tokens: {answer['tokens']}")
```

##### `get_collections() → Dict`

Get information about loaded collections.

#### Quick Setup

```python
from crazycontext.bridges import quick_setup

# One-liner semantic search
answer = quick_setup(
    "./cache/web",
    "What is machine learning?"
)
print(answer['answer'])
```

---

## Type Reference

### Common Return Types

**Download Result:**
```python
{
    'status': 'success' | 'failed',
    'url': str,
    'file': str,
    'error': str  # if failed
}
```

**Search Result:**
```python
{
    'file': str,
    'match_count': int,
    'matches': [
        {
            'context': str,
            'position': int
        }
    ],
    'source': 'web' | 'local'
}
```

**Paper Result:**
```python
{
    'id': str,
    'title': str,
    'summary': str,
    'authors': List[str],
    'year': str,
    'url': str,
    'pdf_url': str,
    'source': 'arxiv' | 'semantic_scholar'
}
```

**Repository Result:**
```python
{
    'id': int,
    'name': str,
    'full_name': str,
    'description': str,
    'stars': int,
    'forks': int,
    'language': str,
    'url': str,
    'clone_url': str
}
```

**TOC Entry:**
```python
{
    'level': int,  # 1-6
    'title': str,
    'line': int,
    'type': 'markdown' | 'html'
}
```

---

**For more examples, see [EXAMPLES.md](./EXAMPLES.md)**

**For best practices, see [BEST_PRACTICES.md](./BEST_PRACTICES.md)**
