# 💡 Examples

**Real-world use cases and code examples**

---

## Table of Contents

- [Basic Examples](#basic-examples)
- [Research Assistant](#research-assistant)
- [Code Documentation Q&A](#code-documentation-qa)
- [Academic Research Tool](#academic-research-tool)
- [GitHub Code Finder](#github-code-finder)
- [Multi-Source Knowledge Base](#multi-source-knowledge-base)
- [Document Analysis](#document-analysis)
- [Semantic Search System](#semantic-search-system)

---

## Basic Examples

### Example 1: Simple Documentation Q&A

```python
from crazycontext import CrazyContext

# Initialize
cc = CrazyContext()

# Download Python documentation
cc.from_urls(["https://docs.python.org/3/tutorial/"])

# Search and answer
question = "How do I use list comprehensions?"
results = cc.search(question)
context = cc.build_context(results, max_length=3000)

# Build prompt
prompt = f"""
Based on this documentation:
{context}

Question: {question}

Provide a clear answer with examples.

Answer:
"""

# Use with any LLM
response = your_llm_api(prompt)
print(response)
```

### Example 2: Quick Paper Search

```python
from crazycontext.sources import PapersSource

papers = PapersSource()

# Search recent papers
results = papers.search("transformer neural networks", max_results=5)

# Filter for recent papers
recent = papers.filter_by_year(results, min_year=2020)

# Display
for paper in recent:
    print(f"\n📄 {paper['title']}")
    print(f"   Authors: {', '.join(paper['authors'][:3])}")
    print(f"   Year: {paper['year']}")
    print(f"   {paper['url']}")
```

### Example 3: GitHub Code Search

```python
from crazycontext.sources import GitHubSource

github = GitHubSource()

# Find popular repositories
repos = github.search_repositories(
    "neural network pytorch",
    language="python",
    min_stars=100,
    max_results=5
)

# Download examples from top repo
files = github.download_repo_files(
    repos[0]['full_name'],
    patterns=["*.py"],
    max_files=20
)

print(f"Downloaded {len(files)} Python files")

# Search downloaded code
results = github.search_cached("training loop")
for result in results[:3]:
    print(f"Found in: {result['file']}")
```

---

## Research Assistant

Build a research assistant that gathers academic papers and provides answers.

```python
from crazycontext import CrazyContext
from crazycontext.sources import PapersSource
from crazycontext.builders import ResearchProfile, ContextBuilder

class ResearchAssistant:
    def __init__(self, cache_dir="./research_cache"):
        self.cc = CrazyContext(cache_dir=cache_dir)
        self.papers = PapersSource(cache_dir=f"{cache_dir}/papers")
        self.profile = ResearchProfile()
        self.builder = ContextBuilder(max_tokens=self.profile.max_tokens)
    
    def gather_research(self, topic, max_papers=10):
        """Gather research on a topic."""
        # Search papers
        results = self.papers.search(
            topic,
            sources=["arxiv", "semantic_scholar"],
            max_results=max_papers
        )
        
        # Filter recent papers (last 3 years)
        from datetime import datetime
        current_year = datetime.now().year
        recent = self.papers.filter_by_year(
            results,
            min_year=current_year - 3
        )
        
        print(f"Found {len(recent)} recent papers on '{topic}'")
        return recent
    
    def answer_question(self, question, papers):
        """Answer question based on papers."""
        # Build context from paper summaries
        context_parts = []
        for paper in papers[:10]:  # Top 10 papers
            context_parts.append(f"""
Paper: {paper['title']} ({paper['year']})
Authors: {', '.join(paper['authors'][:5])}
Abstract: {paper['summary']}
---
""")
        
        context = "\n".join(context_parts)
        
        # Build prompt
        prompt = f"""
You are a research assistant. Based on these recent research papers:

{context}

Question: {question}

Provide a comprehensive answer citing relevant papers.

Answer:
"""
        
        return prompt
    
    def research(self, topic, question):
        """Complete research workflow."""
        papers = self.gather_research(topic)
        prompt = self.answer_question(question, papers)
        
        # Use with LLM
        response = your_llm_api(prompt)
        return response

# Usage
assistant = ResearchAssistant()

# Research a topic
answer = assistant.research(
    topic="transformer neural networks",
    question="What are the key innovations in transformer architectures?"
)

print(answer)
```

---

## Code Documentation Q&A

Build an interactive code documentation assistant.

```python
from crazycontext import CrazyContext
from crazycontext.sources import GitHubSource
from crazycontext.builders import CodingProfile, ContextBuilder

class CodeAssistant:
    def __init__(self):
        self.cc = CrazyContext(cache_dir="./code_cache")
        self.github = GitHubSource(cache_dir="./code_cache/github")
        self.profile = CodingProfile()
        self.builder = ContextBuilder(max_tokens=self.profile.max_tokens)
    
    def load_documentation(self, doc_urls):
        """Load documentation from URLs."""
        results = self.cc.from_urls(doc_urls)
        success = sum(1 for r in results if r['status'] == 'success')
        print(f"Loaded {success} documentation sites")
    
    def load_examples(self, repo_name, patterns=["*.py"]):
        """Load code examples from GitHub."""
        files = self.github.download_repo_files(
            repo_name,
            patterns=patterns,
            max_files=50
        )
        print(f"Downloaded {len(files)} example files")
    
    def ask(self, question):
        """Ask a coding question."""
        # Search documentation
        doc_results = self.cc.search(question, sources=["web"])
        
        # Search code examples
        code_results = self.github.search_cached(question)
        
        # Combine results
        all_results = doc_results + code_results
        
        # Build context
        context = self.builder.build(
            all_results[:10],
            format="plain",
            include_sources=True
        )
        
        # Build prompt
        prompt = f"""
You are a coding assistant with access to documentation and examples.

Context:
{context}

Question: {question}

Provide code examples and clear explanations.

Answer:
"""
        
        return prompt

# Usage
assistant = CodeAssistant()

# Load PyTorch documentation
assistant.load_documentation([
    "https://pytorch.org/docs/stable/index.html",
    "https://pytorch.org/tutorials/"
])

# Load examples from official repo
assistant.load_examples("pytorch/examples", patterns=["*.py"])

# Ask questions
prompt = assistant.ask("How do I create a simple CNN in PyTorch?")
response = your_llm_api(prompt)
print(response)
```

---

## Academic Research Tool

Comprehensive academic research tool with paper management.

```python
from crazycontext.sources import PapersSource
from crazycontext.tools import TOCExtractor
import json

class AcademicResearchTool:
    def __init__(self, research_dir="./research"):
        self.papers = PapersSource(cache_dir=f"{research_dir}/papers")
        self.research_dir = research_dir
        self.library = []
    
    def search_papers(self, query, sources=None, max_results=20):
        """Search for papers."""
        if sources is None:
            sources = ["arxiv", "semantic_scholar"]
        
        results = self.papers.search(
            query,
            sources=sources,
            max_results=max_results
        )
        
        # Add to library
        self.library.extend(results)
        
        return results
    
    def filter_papers(self, min_year=None, keywords=None):
        """Filter papers in library."""
        filtered = self.library
        
        # Filter by year
        if min_year:
            filtered = self.papers.filter_by_year(filtered, min_year=min_year)
        
        # Filter by keywords
        if keywords:
            filtered = [
                p for p in filtered
                if any(kw.lower() in p['title'].lower() or 
                       kw.lower() in p['summary'].lower()
                       for kw in keywords)
            ]
        
        return filtered
    
    def create_bibliography(self, papers):
        """Create bibliography from papers."""
        bib = []
        for paper in papers:
            authors = ", ".join(paper['authors'][:3])
            if len(paper['authors']) > 3:
                authors += " et al."
            
            entry = f"{authors}. ({paper['year']}). {paper['title']}. {paper['url']}"
            bib.append(entry)
        
        return "\n".join(bib)
    
    def export_library(self, filename):
        """Export library to JSON."""
        with open(filename, 'w') as f:
            json.dump(self.library, f, indent=2)
    
    def generate_literature_review(self, topic, keywords):
        """Generate context for literature review."""
        # Search papers
        papers = self.search_papers(topic, max_results=30)
        
        # Filter by keywords
        relevant = self.filter_papers(keywords=keywords)
        
        # Sort by year (newest first)
        relevant.sort(key=lambda x: x.get('year', ''), reverse=True)
        
        # Build review context
        context_parts = []
        context_parts.append(f"# Literature Review: {topic}\n\n")
        
        for paper in relevant[:15]:  # Top 15
            context_parts.append(f"""
## {paper['title']} ({paper['year']})

**Authors:** {', '.join(paper['authors'][:5])}

**Abstract:** {paper['summary']}

**Source:** {paper['source']} | {paper['url']}

---
""")
        
        context = "".join(context_parts)
        
        # Add bibliography
        context += "\n\n# Bibliography\n\n"
        context += self.create_bibliography(relevant)
        
        return context

# Usage
tool = AcademicResearchTool()

# Research topic
context = tool.generate_literature_review(
    topic="attention mechanisms neural networks",
    keywords=["attention", "transformer", "self-attention"]
)

# Use for literature review
prompt = f"""
Based on this literature:

{context}

Write a comprehensive literature review section covering:
1. Evolution of attention mechanisms
2. Key innovations
3. Current state of the art

Literature Review:
"""

review = your_llm_api(prompt)
print(review)

# Export library
tool.export_library("research_library.json")
```

---

## GitHub Code Finder

Find and analyze code patterns across repositories.

```python
from crazycontext.sources import GitHubSource
from crazycontext.builders import ContextBuilder

class CodeFinder:
    def __init__(self):
        self.github = GitHubSource()
        self.builder = ContextBuilder(max_tokens=6000)
    
    def find_implementations(self, pattern, language="python", min_stars=50):
        """Find code implementing a pattern."""
        # Search repositories
        repos = self.github.search_repositories(
            pattern,
            language=language,
            min_stars=min_stars,
            max_results=10
        )
        
        print(f"Found {len(repos)} repositories")
        
        implementations = []
        
        for repo in repos:
            # Download relevant files
            ext = f".{language[:2]}" if language else "*"
            files = self.github.download_repo_files(
                repo['full_name'],
                patterns=[ext],
                max_files=30
            )
            
            if files:
                implementations.append({
                    'repo': repo,
                    'files': files
                })
        
        return implementations
    
    def analyze_implementations(self, implementations, specific_query):
        """Analyze implementations for specific patterns."""
        # Search downloaded code
        results = []
        for impl in implementations:
            repo_results = self.github.search_cached(
                specific_query,
                repo_name=impl['repo']['full_name']
            )
            results.extend(repo_results)
        
        # Build context
        context = self.builder.build(
            results[:20],
            format="plain",
            include_sources=True
        )
        
        return context
    
    def learn_pattern(self, pattern, specific_aspect, language="python"):
        """Learn about a coding pattern from real implementations."""
        # Find implementations
        implementations = self.find_implementations(
            pattern,
            language=language,
            min_stars=100
        )
        
        # Analyze specific aspect
        context = self.analyze_implementations(
            implementations,
            specific_aspect
        )
        
        # Build learning prompt
        prompt = f"""
You are a coding expert. Analyze these real-world implementations:

{context}

Explain: {specific_aspect}

Provide:
1. Common patterns found
2. Best practices
3. Code examples
4. Potential pitfalls

Analysis:
"""
        
        return prompt

# Usage
finder = CodeFinder()

# Learn about a pattern
prompt = finder.learn_pattern(
    pattern="neural network training loop pytorch",
    specific_aspect="How to properly implement early stopping?",
    language="python"
)

explanation = your_llm_api(prompt)
print(explanation)
```

---

## Multi-Source Knowledge Base

Combine multiple sources for comprehensive knowledge base.

```python
from crazycontext import CrazyContext
from crazycontext.sources import PapersSource, GitHubSource, LocalSource
from crazycontext.builders import DocumentationProfile, ContextBuilder

class KnowledgeBase:
    def __init__(self, kb_dir="./knowledge_base"):
        self.cc = CrazyContext(cache_dir=kb_dir)
        self.papers = PapersSource(cache_dir=f"{kb_dir}/papers")
        self.github = GitHubSource(cache_dir=f"{kb_dir}/github")
        self.local = LocalSource()
        
        self.profile = DocumentationProfile()
        self.builder = ContextBuilder(max_tokens=self.profile.max_tokens)
    
    def add_web_docs(self, urls):
        """Add web documentation."""
        results = self.cc.from_urls(urls)
        return sum(1 for r in results if r['status'] == 'success')
    
    def add_papers(self, topic, max_results=20):
        """Add academic papers on topic."""
        results = self.papers.search(topic, max_results=max_results)
        return len(results)
    
    def add_github_examples(self, repo, patterns=["*.md", "*.py"]):
        """Add GitHub repository examples."""
        files = self.github.download_repo_files(
            repo,
            patterns=patterns,
            max_files=100
        )
        return len(files)
    
    def add_local_docs(self, directory):
        """Add local documentation."""
        return self.local.add_directory(directory, recursive=True)
    
    def query(self, question, sources="all"):
        """Query knowledge base."""
        results = []
        
        if sources == "all" or "web" in sources:
            results.extend(self.cc.search(question, sources=["web"]))
        
        if sources == "all" or "papers" in sources:
            paper_results = self.papers.search_cached(question)
            results.extend(paper_results)
        
        if sources == "all" or "github" in sources:
            github_results = self.github.search_cached(question)
            results.extend(github_results)
        
        if sources == "all" or "local" in sources:
            local_results = self.local.search(question)
            results.extend(local_results)
        
        # Build context
        context = self.builder.build(
            results[:25],
            format="markdown",
            include_sources=True
        )
        
        return context, results
    
    def stats(self):
        """Get knowledge base statistics."""
        return {
            'web': self.cc.get_stats()['web'],
            'papers': self.papers.get_stats(),
            'github': self.github.get_stats(),
            'local': self.local.get_stats()
        }

# Usage
kb = KnowledgeBase()

# Build knowledge base
print("Building knowledge base...")

# Add official documentation
kb.add_web_docs([
    "https://pytorch.org/docs/",
    "https://pytorch.org/tutorials/"
])

# Add research papers
kb.add_papers("deep learning pytorch", max_results=15)

# Add GitHub examples
kb.add_github_examples("pytorch/examples", patterns=["*.py", "*.md"])

# Add local notes
kb.add_local_docs("./my_notes")

# Query knowledge base
context, results = kb.query("How to implement a CNN?")

print(f"\nFound {len(results)} relevant sources")

# Build prompt
prompt = f"""
Knowledge Base Context:
{context}

Question: How do I implement a Convolutional Neural Network in PyTorch?

Provide a comprehensive answer with code examples.

Answer:
"""

response = your_llm_api(prompt)
print(response)

# Check stats
stats = kb.stats()
print(f"\nKnowledge Base Stats:")
print(f"Web docs: {stats['web']['cache_files']} files")
print(f"Papers: {stats['papers']['total_papers']} papers")
print(f"GitHub files: {stats['github']['total_files']}")
print(f"Local files: {stats['local']['file_count']}")
```

---

## Document Analysis

Analyze documents with TOC extraction.

```python
from crazycontext import CrazyContext
from crazycontext.tools import TOCExtractor
from crazycontext.builders import ContextBuilder

class DocumentAnalyzer:
    def __init__(self):
        self.cc = CrazyContext()
        self.toc = TOCExtractor()
        self.builder = ContextBuilder()
    
    def analyze_document(self, file_path):
        """Analyze document structure and content."""
        # Extract TOC
        toc = self.toc.extract_from_file(file_path)
        
        # Get sections
        sections = self.toc.get_context_by_sections(file_path)
        
        # Build hierarchy
        hierarchy = self.toc.build_hierarchy(toc)
        
        analysis = {
            'total_sections': len(toc),
            'levels': len(set(e['level'] for e in toc)),
            'sections': sections,
            'hierarchy': hierarchy
        }
        
        return analysis
    
    def summarize_section(self, file_path, section_title):
        """Get context for specific section."""
        sections = self.toc.get_context_by_sections(file_path)
        
        # Find matching section
        for section in sections:
            if section_title.lower() in section['title'].lower():
                return section['content']
        
        return None
    
    def build_document_context(self, file_path):
        """Build complete document context."""
        return self.toc.get_all_context(file_path, include_toc=True)

# Usage
analyzer = DocumentAnalyzer()

# Analyze documentation
analysis = analyzer.analyze_document("python_guide.md")

print(f"Document has {analysis['total_sections']} sections")
print(f"Hierarchy depth: {analysis['levels']}")

# Get specific section
section_content = analyzer.summarize_section(
    "python_guide.md",
    "Functions"
)

# Build complete context
context = analyzer.build_document_context("python_guide.md")

# Use for Q&A
prompt = f"""
Document:
{context}

Question: How are functions defined and used?

Answer:
"""
```

---

## Semantic Search System

Build semantic search with Deep-Searcher bridge.

**Requires:** `pip install crazycontext[deepsearcher]`

```python
from crazycontext import CrazyContext
from crazycontext.bridges import CrazyContextLoader

class SemanticSearchSystem:
    def __init__(self, cache_dir="./semantic_cache"):
        self.cc = CrazyContext(cache_dir=cache_dir)
        self.loader = None
        self.loaded = False
    
    def index_documents(self, urls):
        """Download and index documents."""
        # Download
        results = self.cc.from_urls(urls)
        
        # Load into Deep-Searcher
        self.loader = CrazyContextLoader(
            milvus_uri=f"{self.cc.cache_dir}/milvus.db"
        )
        
        count = self.loader.load_from_cache(
            f"{self.cc.cache_dir}/web",
            collection_name="docs"
        )
        
        self.loaded = True
        print(f"Indexed {count} documents")
    
    def semantic_query(self, question, top_k=5):
        """Semantic search query."""
        if not self.loaded:
            raise ValueError("No documents indexed yet")
        
        answer = self.loader.query(
            question,
            collection_name="docs",
            top_k=top_k
        )
        
        return answer
    
    def hybrid_search(self, query, top_k=5):
        """Combine keyword and semantic search."""
        # Keyword search
        keyword_results = self.cc.search(query)
        
        # Semantic search
        semantic_answer = self.semantic_query(query, top_k=top_k)
        
        return {
            'keyword_results': keyword_results,
            'semantic_answer': semantic_answer
        }

# Usage
system = SemanticSearchSystem()

# Index documentation
system.index_documents([
    "https://docs.python.org/3/tutorial/",
    "https://pytorch.org/tutorials/"
])

# Semantic query
answer = system.semantic_query(
    "How do neural networks learn?",
    top_k=5
)

print(f"Answer: {answer['answer']}")
print(f"Sources: {len(answer['sources'])}")
print(f"Tokens used: {answer['tokens']}")

# Hybrid search
results = system.hybrid_search("list comprehensions")
print(f"Keyword matches: {len(results['keyword_results'])}")
print(f"Semantic answer: {results['semantic_answer']['answer']}")
```

---

## More Examples

For more examples, check:
- `examples/` folder in the repository
- [Getting Started Guide](./GETTING_STARTED.md)
- [API Reference](./API_REFERENCE.md)
- [Best Practices](./BEST_PRACTICES.md)

---

**Have a use case not covered here? Open an issue on GitHub!**
