# 📚 CrazyContext Documentation

**Complete documentation for the ultimate context builder**

---

## 🎯 Documentation Index

### Getting Started
- **[Getting Started Guide](./GETTING_STARTED.md)** - Start here! Installation, quick start, and basic concepts
- **[Examples](./EXAMPLES.md)** - Real-world use cases and code examples
- **[CLI Guide](./CLI_GUIDE.md)** - Command-line interface reference

### Reference
- **[API Reference](./API_REFERENCE.md)** - Complete API documentation for all classes and methods
- **[Best Practices](./BEST_PRACTICES.md)** - Guidelines and recommendations
- **[llm.txt](../llm.txt)** - LLM-optimized reference for AI assistants and coding agents

---

## 📖 Quick Navigation

### By User Type

**🆕 New Users**
1. [Getting Started Guide](./GETTING_STARTED.md) - Learn the basics
2. [Examples](./EXAMPLES.md) - See real examples
3. [CLI Guide](./CLI_GUIDE.md) - Use from terminal

**👨‍💻 Developers**
1. [API Reference](./API_REFERENCE.md) - Full API docs
2. [Best Practices](./BEST_PRACTICES.md) - Write better code
3. [Examples](./EXAMPLES.md) - Integration patterns

**🤖 AI Assistants**
1. [llm.txt](../llm.txt) - Optimized reference for LLMs
2. [API Reference](./API_REFERENCE.md) - Complete function signatures
3. [Examples](./EXAMPLES.md) - Code patterns

---

## 🚀 Quick Links

### Installation
```bash
pip install crazycontext
```

### Basic Usage
```python
from crazycontext import CrazyContext

cc = CrazyContext()
cc.from_urls(["https://docs.python.org/3/"])
results = cc.search("decorators")
context = cc.build_context(results)
```

### CLI Usage
```bash
crazycontext download --urls "https://example.com"
crazycontext search "query"
```

---

## 📋 Documentation Overview

### 1. Getting Started Guide
**Start here if you're new to CrazyContext**

- What is CrazyContext?
- Installation options
- Your first project
- Basic concepts (sources, search, context building)
- Quick start examples

### 2. API Reference
**Complete technical reference**

- Main API (CrazyContext class)
- Sources (Web, Local, Papers, GitHub)
- Builders (ContextBuilder, Profiles, Formatters)
- Search (Keyword, Fuzzy)
- Tools (TOC extraction)
- Bridges (Deep-Searcher integration)
- Return types and signatures

### 3. Examples
**Real-world use cases**

- Research Assistant
- Code Documentation Q&A
- Academic Research Tool
- GitHub Code Finder
- Multi-Source Knowledge Base
- Document Analysis
- Semantic Search System

### 4. Best Practices
**Guidelines for optimal use**

- General principles
- Cache management
- Search strategies
- Token management
- Performance optimization
- Error handling
- Production deployment
- Security best practices

### 5. CLI Guide
**Command-line interface**

- Installation and setup
- Download command
- Search command
- Papers command
- GitHub command
- Stats command
- Tips and tricks
- Automation examples

### 6. llm.txt
**For AI assistants and coding agents**

- Concise API reference
- Common patterns
- Return types
- Error handling
- Quick reference cheat sheet

---

## 🎓 Learning Path

### Beginner Path
1. Read [Getting Started Guide](./GETTING_STARTED.md) - Sections 1-4
2. Try [Quick Start](./GETTING_STARTED.md#quick-start) example
3. Explore [Basic Examples](./EXAMPLES.md#basic-examples)
4. Check [Best Practices](./BEST_PRACTICES.md#general-principles)

### Intermediate Path
1. Complete Beginner Path
2. Read full [API Reference](./API_REFERENCE.md)
3. Study [Complete Examples](./EXAMPLES.md)
4. Learn [CLI Guide](./CLI_GUIDE.md)
5. Apply [Best Practices](./BEST_PRACTICES.md)

### Advanced Path
1. Complete Intermediate Path
2. Build complex applications from [Examples](./EXAMPLES.md)
3. Implement [Production Deployment](./BEST_PRACTICES.md#production-deployment)
4. Use [Deep-Searcher Bridge](./API_REFERENCE.md#crazycontextloader)
5. Contribute to the project!

---

## 🔍 Find What You Need

### By Feature

**Downloading Content**
- [Web Downloads](./API_REFERENCE.md#websource)
- [CLI Download](./CLI_GUIDE.md#download-command)
- [Examples](./EXAMPLES.md#example-1-simple-documentation-qa)

**Searching**
- [Search API](./API_REFERENCE.md#search)
- [CLI Search](./CLI_GUIDE.md#search-command)
- [Search Strategies](./BEST_PRACTICES.md#search-strategy)

**Academic Papers**
- [Papers API](./API_REFERENCE.md#paperssource)
- [CLI Papers](./CLI_GUIDE.md#papers-command)
- [Research Examples](./EXAMPLES.md#research-assistant)

**GitHub Integration**
- [GitHub API](./API_REFERENCE.md#githubsource)
- [CLI GitHub](./CLI_GUIDE.md#github-command)
- [Code Examples](./EXAMPLES.md#github-code-finder)

**Context Building**
- [Context Builder](./API_REFERENCE.md#contextbuilder)
- [Profiles](./API_REFERENCE.md#profiles)
- [Formatters](./API_REFERENCE.md#formatters)
- [Token Management](./BEST_PRACTICES.md#token-management)

**Semantic Search**
- [Bridge API](./API_REFERENCE.md#crazycontextloader)
- [Semantic Examples](./EXAMPLES.md#semantic-search-system)

---

## 💡 Common Tasks

### How do I...?

**Download a website?**
```python
cc = CrazyContext()
cc.from_url("https://example.com")
```
[More details](./API_REFERENCE.md#from_url)

**Search for content?**
```python
results = cc.search("query")
```
[More details](./API_REFERENCE.md#search)

**Build context for LLM?**
```python
context = cc.build_context(results, max_length=5000)
```
[More details](./API_REFERENCE.md#build_context)

**Search academic papers?**
```python
from crazycontext.sources import PapersSource
papers = PapersSource()
results = papers.search("neural networks")
```
[More details](./API_REFERENCE.md#paperssource)

**Search GitHub?**
```python
from crazycontext.sources import GitHubSource
github = GitHubSource()
repos = github.search_repositories("pytorch")
```
[More details](./API_REFERENCE.md#githubsource)

**Use from command line?**
```bash
crazycontext download --urls "https://example.com"
crazycontext search "query"
```
[More details](./CLI_GUIDE.md)

---

## 🤝 For AI Assistants

If you're an AI assistant or LLM helping a user with CrazyContext:

1. **Start with [llm.txt](../llm.txt)** - Concise, optimized reference
2. **Check [API Reference](./API_REFERENCE.md)** - For detailed signatures
3. **Use [Examples](./EXAMPLES.md)** - For code patterns
4. **Reference [Best Practices](./BEST_PRACTICES.md)** - For recommendations

The `llm.txt` file is specifically formatted for AI consumption with:
- Concise API overview
- Function signatures
- Return types
- Common patterns
- Error handling
- Quick reference cheat sheet

---

## 📦 Package Info

- **Version:** 0.1.0
- **Python:** ≥3.7
- **Tests:** 146 passing
- **Coverage:** 100%
- **Status:** Production-Ready

---

## 🔗 External Resources

### GitHub
- Repository: (link to repo)
- Issues: (link to issues)
- Discussions: (link to discussions)

### Community
- Discord: (if available)
- Stack Overflow: Tag `crazycontext`

---

## 📝 Contributing to Documentation

Found an error or want to improve the docs?

1. Fork the repository
2. Edit the documentation files
3. Submit a pull request

Documentation files are in:
- `docs/*.md` - Documentation guides
- `llm.txt` - LLM reference
- `examples/*.py` - Code examples

---

## 🎯 Next Steps

**Choose your path:**

- 🆕 **New to CrazyContext?** → [Getting Started Guide](./GETTING_STARTED.md)
- 💻 **Want to code?** → [Examples](./EXAMPLES.md)
- 📖 **Need reference?** → [API Reference](./API_REFERENCE.md)
- 🖥️ **Use CLI?** → [CLI Guide](./CLI_GUIDE.md)
- 🤖 **AI Assistant?** → [llm.txt](../llm.txt)

---

**Happy Context Building! 🚀**
