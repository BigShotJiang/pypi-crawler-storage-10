# 🖥️ Command-Line Interface Guide

**Using CrazyContext from the terminal**

---

## Installation

The CLI is included when you install CrazyContext:

```bash
pip install crazycontext

# Verify installation
crazycontext --version
```

---

## Quick Reference

```bash
# Available commands
crazycontext download  # Download websites
crazycontext search    # Search content
crazycontext papers    # Search academic papers
crazycontext github    # Search GitHub repositories
crazycontext stats     # Show statistics

# Get help
crazycontext --help
crazycontext download --help
```

---

## Download Command

Download and cache websites.

### Basic Usage

```bash
# Single URL
crazycontext download --urls "https://docs.python.org/3/"

# Multiple URLs (comma-separated)
crazycontext download --urls "https://example.com,https://example.org"
```

### From File

```bash
# Create urls.txt with one URL per line
echo "https://docs.python.org/3/" > urls.txt
echo "https://pytorch.org/tutorials/" >> urls.txt

# Download from file
crazycontext download --file urls.txt
```

### Examples

```bash
# Download Python docs
crazycontext download --urls "https://docs.python.org/3/tutorial/"

# Download multiple sites
crazycontext download --urls "https://pytorch.org/,https://tensorflow.org/"

# From file
crazycontext download --file documentation_urls.txt
```

---

## Search Command

Search downloaded and local content.

### Basic Search

```bash
# Simple keyword search
crazycontext search "machine learning"

# With quotes for exact phrases
crazycontext search "neural network training"
```

### Fuzzy Search

```bash
# Typo-tolerant search
crazycontext search "machne lerning" --fuzzy

# With verbose output
crazycontext search "decorators" --fuzzy --verbose
```

### Search Options

```bash
# Limit results
crazycontext search "python" --max-results 5

# Search specific sources
crazycontext search "tutorial" --sources web

# Add local directory
crazycontext search "functions" --local ./my_notes

# Verbose output with context
crazycontext search "classes" --verbose
```

### Examples

```bash
# Find Python decorators
crazycontext search "decorators" --max-results 10 --verbose

# Search with typos
crazycontext search "nueral netwrk" --fuzzy

# Search local notes
crazycontext search "project ideas" --local ~/Documents/notes

# Combined search
crazycontext search "pytorch tutorial" --local ./examples --fuzzy -v
```

---

## Papers Command

Search academic papers from arXiv and Semantic Scholar.

### Basic Usage

```bash
# Search papers
crazycontext papers "neural networks"

# Limit results
crazycontext papers "deep learning" --max-results 5
```

### Options

```bash
# Specific sources
crazycontext papers "transformers" --sources arxiv

# Both sources (default)
crazycontext papers "attention mechanisms" --sources arxiv,semantic_scholar

# Verbose output
crazycontext papers "machine learning" --verbose
```

### Examples

```bash
# Find recent papers on transformers
crazycontext papers "transformer neural networks" --max-results 10

# arXiv only
crazycontext papers "computer vision" --sources arxiv -v

# Detailed output
crazycontext papers "reinforcement learning" --max-results 5 --verbose
```

---

## GitHub Command

Search and download GitHub repositories.

### Repository Search

```bash
# Search repositories
crazycontext github "pytorch examples"

# Filter by language
crazycontext github "neural networks" --language python

# Minimum stars
crazycontext github "deep learning" --language python --min-stars 100

# Limit results
crazycontext github "machine learning" --max-results 5
```

### Download Repository

```bash
# Download repository files
crazycontext github --download "pytorch/examples"

# With file patterns
crazycontext github --download "pytorch/examples" --patterns "*.py"

# Multiple patterns
crazycontext github --download "user/repo" --patterns "*.py,*.md"

# Limit files
crazycontext github --download "user/repo" --patterns "*.py" --max-files 20
```

### Examples

```bash
# Find PyTorch repos
crazycontext github "pytorch" --language python --min-stars 500

# Download examples
crazycontext github --download "pytorch/examples" --patterns "*.py" --max-files 30

# Search with details
crazycontext github "transformer implementation" --language python -v
```

---

## Stats Command

Show cache statistics.

```bash
# Show all statistics
crazycontext stats

# Example output:
# 📊 CrazyContext Statistics
# ==========================================================
# 
# 📁 Web Cache:
#    Files: 45
#    Size: 23.45 MB
#    Downloads: 50 total
#    Success: 45
#    Failed: 5
# 
# 📝 Local Files:
#    Indexed: 123
#    Size: 5.67 MB
```

---

## Global Options

These work with all commands:

```bash
# Custom cache directory
crazycontext --cache-dir ./my_cache search "query"

# Version
crazycontext --version
```

---

## Complete Examples

### Example 1: Python Documentation Assistant

```bash
# Download Python docs
crazycontext download --urls "https://docs.python.org/3/tutorial/"

# Search for decorators
crazycontext search "decorators" --max-results 5 --verbose

# Check cache
crazycontext stats
```

### Example 2: Research Papers

```bash
# Search papers
crazycontext papers "attention mechanisms neural networks" --max-results 10

# Search with verbose output
crazycontext papers "transformers" --sources arxiv --verbose
```

### Example 3: GitHub Code Explorer

```bash
# Find repositories
crazycontext github "pytorch neural network" --language python --min-stars 100

# Download top repo
crazycontext github --download "pytorch/examples" --patterns "*.py" --max-files 50

# Search downloaded code
crazycontext search "training loop" --verbose
```

### Example 4: Documentation Project

```bash
# Download multiple documentation sites
cat > docs.txt << EOF
https://docs.python.org/3/
https://pytorch.org/tutorials/
https://numpy.org/doc/
EOF

crazycontext download --file docs.txt

# Search across all
crazycontext search "numpy arrays" --max-results 10

# Add local examples
crazycontext search "examples" --local ./my_examples --fuzzy

# Check what we have
crazycontext stats
```

---

## Tips and Tricks

### 1. Use Shell Aliases

```bash
# Add to ~/.bashrc or ~/.zshrc
alias ccx='crazycontext'
alias ccs='crazycontext search'
alias ccd='crazycontext download'
alias ccp='crazycontext papers'
alias ccg='crazycontext github'

# Now use shortcuts
ccs "decorators" -v
ccp "neural networks" --max-results 5
```

### 2. Combine with Other Tools

```bash
# Search and count matches
crazycontext search "function" | grep "Found" | wc -l

# Save results to file
crazycontext papers "ML" --max-results 20 > papers.txt

# Use with jq for JSON processing
crazycontext github "pytorch" --language python | jq '.repositories'
```

### 3. Batch Operations

```bash
# Download from multiple sources
for topic in python pytorch numpy; do
    crazycontext download --urls "https://docs.${topic}.org/"
done

# Search multiple terms
for term in "classes" "functions" "decorators"; do
    echo "=== Searching: $term ==="
    crazycontext search "$term" --max-results 3
done
```

### 4. Integration with Scripts

```bash
#!/bin/bash
# research.sh - Automated research script

TOPIC=$1
CACHE_DIR="./research_${TOPIC}"

# Search papers
echo "Searching papers on: $TOPIC"
crazycontext --cache-dir "$CACHE_DIR" papers "$TOPIC" --max-results 10

# Find GitHub repos
echo "Finding repositories..."
crazycontext github "$TOPIC" --language python --min-stars 50

# Show statistics
crazycontext --cache-dir "$CACHE_DIR" stats

# Usage: ./research.sh "neural networks"
```

---

## Environment Variables

```bash
# Set default cache directory
export CRAZYCONTEXT_CACHE_DIR="$HOME/.crazycontext_cache"

# Set GitHub token
export GITHUB_TOKEN="your_token_here"

# Set Semantic Scholar API key
export S2_API_KEY="your_key_here"

# Use in commands
crazycontext download --urls "https://example.com"
```

---

## Troubleshooting

### Command Not Found

```bash
# If 'crazycontext' not found, try:
python -m crazycontext.cli.main --version

# Or reinstall
pip install --upgrade crazycontext
```

### Permission Errors

```bash
# Use custom cache directory
crazycontext --cache-dir ~/my_cache search "query"

# Or fix permissions
chmod -R u+w ./cache
```

### Network Issues

```bash
# Check if URLs are accessible
curl -I https://example.com

# Try download with verbose output
crazycontext download --urls "https://example.com" --verbose
```

### Cache Issues

```bash
# Check cache location
crazycontext stats

# Clear and rebuild cache
rm -rf ./cache
crazycontext download --file urls.txt
```

---

## Advanced Usage

### Custom Cache Directory

```bash
# Use project-specific cache
crazycontext --cache-dir ./project_cache download --urls "https://example.com"
crazycontext --cache-dir ./project_cache search "query"
```

### Piping and Output

```bash
# Count search results
crazycontext search "python" | grep "matches" | wc -l

# Extract paper titles
crazycontext papers "ML" | grep "Title"

# Save repository list
crazycontext github "pytorch" --language python > repos.txt
```

### Automation

```bash
# Cron job to update cache daily
0 2 * * * /usr/local/bin/crazycontext download --file ~/docs_urls.txt

# Update multiple caches
#!/bin/bash
for project in python pytorch numpy; do
    crazycontext --cache-dir "./cache_${project}" \
        download --urls "https://docs.${project}.org/"
done
```

---

## Python API from CLI

You can also use the Python API for more control:

```python
# Instead of CLI
import subprocess

result = subprocess.run(
    ['crazycontext', 'search', 'query', '--max-results', '5'],
    capture_output=True,
    text=True
)

print(result.stdout)
```

Or directly:

```python
from crazycontext import CrazyContext

cc = CrazyContext()
results = cc.search("query")
# Much more flexible!
```

---

## Summary

### Common Commands

```bash
# Download
crazycontext download --urls "URL"
crazycontext download --file urls.txt

# Search
crazycontext search "query"
crazycontext search "query" --fuzzy --verbose

# Papers
crazycontext papers "topic" --max-results 10

# GitHub
crazycontext github "query" --language python
crazycontext github --download "user/repo" --patterns "*.py"

# Stats
crazycontext stats
```

### Best Practices

1. Use `--verbose` for debugging
2. Limit results with `--max-results`
3. Use `--cache-dir` for project isolation
4. Set environment variables for API keys
5. Use shell aliases for convenience

---

**For more details, see [API Reference](./API_REFERENCE.md) and [Examples](./EXAMPLES.md)**
