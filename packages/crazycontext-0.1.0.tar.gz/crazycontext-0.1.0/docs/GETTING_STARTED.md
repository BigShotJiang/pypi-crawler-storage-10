# 🚀 Getting Started with CrazyContext

**The ultimate context builder for LLM applications**

---

## 📖 Table of Contents

- [What is CrazyContext?](#what-is-crazycontext)
- [Installation](#installation)
- [Quick Start](#quick-start)
- [Basic Concepts](#basic-concepts)
- [Your First Project](#your-first-project)
- [Next Steps](#next-steps)

---

## 🤔 What is CrazyContext?

CrazyContext is a powerful Python library that gathers, organizes, and prepares context from multiple sources for Large Language Models (LLMs). Think of it as a smart data loader that:

- **Gathers** - Downloads from websites, academic papers, GitHub, and local files
- **Converts** - Transforms HTML to clean Markdown
- **Searches** - Finds relevant content with keyword and fuzzy search
- **Builds** - Creates LLM-ready context with optimal formatting

### Why CrazyContext?

- ✅ **Multi-Source** - Web, papers, GitHub, local files
- ✅ **Smart Search** - Keyword + fuzzy + optional semantic
- ✅ **LLM-Ready** - 6 formats, 5 profiles, token-aware
- ✅ **Production Ready** - 146 tests, 100% coverage
- ✅ **Easy to Use** - Simple API, powerful features

---

## 📦 Installation

### Basic Installation

```bash
pip install crazycontext
```

### With Optional Features

```bash
# Fuzzy search support
pip install crazycontext[fuzzy]

# PDF support
pip install crazycontext[pdf]

# GitHub integration
pip install crazycontext[github]

# Deep-Searcher semantic search
pip install crazycontext[deepsearcher]

# Everything
pip install crazycontext[all]
```

### Verify Installation

```python
import crazycontext
print(crazycontext.__version__)  # Should print: 0.1.0
```

---

## ⚡ Quick Start

### 1. Download a Website

```python
from crazycontext import CrazyContext

# Initialize
cc = CrazyContext()

# Download documentation
cc.from_urls(["https://docs.python.org/3/tutorial/"])

print("✅ Downloaded successfully!")
```

### 2. Search Content

```python
# Search for specific content
results = cc.search("list comprehension")

print(f"Found {len(results)} results")
for result in results[:3]:
    print(f"- {result['file']}: {result['match_count']} matches")
```

### 3. Build Context for LLM

```python
# Build context
context = cc.build_context(results, max_length=5000)

# Use with any LLM
prompt = f"""
Context:
{context}

Question: How do Python list comprehensions work?

Answer:
"""

# Send to your LLM
response = your_llm(prompt)
print(response)
```

That's it! You've just:
1. ✅ Downloaded documentation
2. ✅ Searched for relevant content
3. ✅ Built LLM-ready context

---

## 🧠 Basic Concepts

### 1. Sources

CrazyContext gathers data from multiple sources:

```python
from crazycontext.sources import WebSource, LocalSource, PapersSource, GitHubSource

# Web content
web = WebSource()
web.download_urls(["https://example.com"])

# Local files
local = LocalSource()
local.add_directory("./my_notes")

# Academic papers
papers = PapersSource()
papers.search("neural networks")

# GitHub repositories
github = GitHubSource()
github.search_repositories("pytorch")
```

### 2. Search

Find content with multiple search methods:

```python
# Keyword search (exact matching)
results = cc.search("machine learning")

# Fuzzy search (typo-tolerant)
results = cc.search("machne lerning", search_type="fuzzy")

# Search specific sources
results = cc.search("python", sources=["web", "local"])
```

### 3. Context Building

Build LLM-ready context with smart formatting:

```python
from crazycontext.builders import ContextBuilder

builder = ContextBuilder(max_tokens=4000)

# Build context
context = builder.build(results, format="markdown")

# Build complete prompt
prompt = builder.build_prompt(
    results,
    question="What is machine learning?",
    system_prompt="You are a helpful assistant."
)
```

### 4. Profiles

Use pre-configured profiles for different tasks:

```python
from crazycontext.builders import ResearchProfile, CodingProfile

# Research task (8K tokens, markdown)
research = ResearchProfile()

# Coding task (6K tokens, plain text)
coding = CodingProfile()
```

---

## 🎯 Your First Project

Let's build a complete example: **Python Tutorial Assistant**

### Step 1: Gather Data

```python
from crazycontext import CrazyContext

cc = CrazyContext(cache_dir="./python_docs")

# Download Python documentation
urls = [
    "https://docs.python.org/3/tutorial/",
    "https://docs.python.org/3/library/",
]

cc.from_urls(urls)
```

### Step 2: Search and Build Context

```python
# Search for decorators
results = cc.search("decorators")

# Build context
context = cc.build_context(results, max_length=3000)
```

### Step 3: Create Interactive Assistant

```python
def ask_python_question(question):
    # Search for relevant content
    results = cc.search(question)
    
    # Build context
    context = cc.build_context(results, max_length=4000)
    
    # Create prompt
    prompt = f"""
You are a Python expert. Use the following documentation:

{context}

Question: {question}

Provide a clear, helpful answer with examples.

Answer:
"""
    
    return prompt

# Use it
question = "How do I use list comprehensions?"
prompt = ask_python_question(question)

# Send to LLM
response = your_llm_api(prompt)
print(response)
```

### Step 4: Add More Features

```python
# Add local examples
cc.add_local_directory("./python_examples")

# Search GitHub for examples
from crazycontext.sources import GitHubSource

github = GitHubSource()
repos = github.search_repositories("python examples", language="python")

# Download repository files
github.download_repo_files(
    "username/python-examples",
    patterns=["*.py"],
    max_files=20
)
```

---

## 📚 Next Steps

### Learn More

1. **[Complete Guide](./COMPLETE_GUIDE.md)** - Full feature documentation
2. **[API Reference](./API_REFERENCE.md)** - All classes and methods
3. **[Examples](./EXAMPLES.md)** - Real-world use cases
4. **[Advanced Usage](./ADVANCED_USAGE.md)** - Power user features

### Try These Features

- **Papers** - Search academic papers from arXiv and Semantic Scholar
- **GitHub** - Download and search code repositories
- **CLI** - Use from command line
- **Semantic Search** - Add Deep-Searcher bridge for vector search
- **TOC Tool** - Extract table of contents from documents

### Get Help

- **GitHub Issues** - Report bugs or request features
- **Documentation** - Check the docs/ folder
- **Examples** - See examples/ folder for more

---

## 💡 Tips for Success

### 1. Cache Everything

```python
# CrazyContext caches downloads automatically
cc = CrazyContext(cache_dir="./my_cache")

# Downloads are cached - runs fast the second time!
cc.from_urls(["https://example.com"])
```

### 2. Use Profiles

```python
from crazycontext.builders import get_profile

# Different tasks need different settings
research = get_profile("research")  # 8K tokens
quick = get_profile("quick")        # 2K tokens
```

### 3. Search Smart

```python
# Try fuzzy search for better results
results = cc.search(
    "neural netowrk",  # Typo? No problem!
    search_type="fuzzy",
    threshold=70
)
```

### 4. Monitor Usage

```python
# Check statistics
stats = cc.get_stats()

print(f"Cache size: {stats['web']['cache_size_mb']:.2f} MB")
print(f"Files indexed: {stats['local']['file_count']}")
```

---

## 🎉 You're Ready!

You now know how to:
- ✅ Install CrazyContext
- ✅ Download and cache content
- ✅ Search across sources
- ✅ Build LLM-ready context
- ✅ Create complete applications

**Next:** Check out the [Complete Guide](./COMPLETE_GUIDE.md) for all features!

---

## 🔗 Quick Links

- [Complete Guide](./COMPLETE_GUIDE.md)
- [API Reference](./API_REFERENCE.md)
- [Examples](./EXAMPLES.md)
- [Advanced Usage](./ADVANCED_USAGE.md)
- [CLI Guide](./CLI_GUIDE.md)
- [Best Practices](./BEST_PRACTICES.md)

---

**Happy Context Building! 🚀**
