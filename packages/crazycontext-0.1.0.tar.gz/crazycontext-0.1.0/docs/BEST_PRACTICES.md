# ✅ Best Practices

**Guidelines for optimal use of CrazyContext**

---

## Table of Contents

- [General Principles](#general-principles)
- [Cache Management](#cache-management)
- [Search Strategy](#search-strategy)
- [Token Management](#token-management)
- [Performance Optimization](#performance-optimization)
- [Error Handling](#error-handling)
- [Production Deployment](#production-deployment)

---

## General Principles

### 1. Start Simple, Scale Gradually

```python
# ❌ Bad: Trying everything at once
cc = CrazyContext()
cc.from_urls(100_urls)  # Too many!
papers.search("topic", max_results=1000)  # Too many!
```

```python
# ✅ Good: Start small, test, then scale
cc = CrazyContext()

# Start with a few URLs
cc.from_urls(["https://docs.python.org/3/tutorial/"])

# Test search
results = cc.search("decorators")
print(f"Found {len(results)} results")

# Scale up once it works
```

### 2. Cache Everything

```python
# ✅ Always specify a meaningful cache directory
cc = CrazyContext(cache_dir="./my_project_cache")

# Downloads are cached automatically - runs fast next time!
cc.from_urls(["https://example.com"])
```

### 3. Use Profiles for Consistency

```python
# ✅ Use profiles for consistent settings
from crazycontext.builders import get_profile

research_profile = get_profile("research")
coding_profile = get_profile("coding")

# Your whole team uses same settings
builder = ContextBuilder(max_tokens=research_profile.max_tokens)
```

---

## Cache Management

### Monitor Cache Size

```python
def check_cache_health(cc):
    """Monitor cache statistics."""
    stats = cc.get_stats()
    
    cache_mb = stats['web']['cache_size_mb']
    success_rate = stats['web']['success'] / max(stats['web']['total'], 1)
    
    print(f"Cache size: {cache_mb:.2f} MB")
    print(f"Success rate: {success_rate:.1%}")
    
    # Alert if cache too large
    if cache_mb > 1000:  # 1GB
        print("⚠️  Cache is large, consider cleaning")
    
    return cache_mb, success_rate

# Check regularly
check_cache_health(cc)
```

### Clean Old Content

```python
# Clean files older than 30 days
deleted = cc.clear_cache("web", older_than_days=30)
print(f"Cleaned {deleted} old files")

# Or clean everything
cc.clear_cache("web")
```

### Organize by Project

```python
# ❌ Bad: One cache for everything
cc = CrazyContext(cache_dir="./cache")

# ✅ Good: Separate cache per project
cc_python = CrazyContext(cache_dir="./caches/python_docs")
cc_pytorch = CrazyContext(cache_dir="./caches/pytorch_docs")
cc_research = CrazyContext(cache_dir="./caches/research")
```

---

## Search Strategy

### Use the Right Search Type

```python
# Exact matches → Keyword
results = cc.search("def __init__", search_type="keyword")

# Natural language → Fuzzy
results = cc.search(
    "neural network training",
    search_type="fuzzy",
    threshold=70
)

# Understanding meaning → Semantic (requires bridge)
from crazycontext.bridges import CrazyContextLoader
loader = CrazyContextLoader()
answer = loader.query("What is the purpose of attention mechanisms?")
```

### Search Specific Sources

```python
# ❌ Bad: Search everything when you know where to look
results = cc.search("python syntax")

# ✅ Good: Target specific sources
results = cc.search("python syntax", sources=["web"])
results_local = cc.search("my notes", sources=["local"])
```

### Limit Results

```python
# ❌ Bad: Processing all results
results = cc.search("common term")  # Could be thousands
context = cc.build_context(results)  # Too much!

# ✅ Good: Limit what you process
from crazycontext.builders import ContextBuilder

builder = ContextBuilder(max_tokens=4000)
context = builder.build(
    results,
    max_results=10  # Only top 10
)
```

### Progressive Search

```python
def smart_search(cc, query, min_results=5):
    """Search with fallbacks."""
    # Try keyword first (fast)
    results = cc.search(query, search_type="keyword")
    
    if len(results) >= min_results:
        return results
    
    # Try fuzzy if not enough results (slower)
    print("Trying fuzzy search...")
    results = cc.search(query, search_type="fuzzy", threshold=60)
    
    return results
```

---

## Token Management

### Always Check Token Limits

```python
from crazycontext.builders import ContextBuilder

builder = ContextBuilder(max_tokens=4000)

# Estimate before sending
context = builder.build(results)
tokens = builder.estimate_tokens(context)

print(f"Context uses ~{tokens} tokens")

if tokens > 3500:  # Leave room for response
    print("⚠️  Context too large, reducing...")
    context = builder.build(results, max_results=5)
```

### Use Chunking for Long Content

```python
# For very long documents
long_text = read_large_document()

chunks = builder.chunk_text(
    long_text,
    chunk_size=1000,  # ~250 tokens
    overlap=100       # Context continuity
)

# Process each chunk
for i, chunk in enumerate(chunks):
    print(f"Chunk {i+1}/{len(chunks)}")
    prompt = f"{chunk}\n\nSummarize this section:"
    summary = your_llm(prompt)
```

### Profile-Based Limits

```python
# ✅ Use profiles to manage different LLM limits
from crazycontext.builders import get_profile

# GPT-3.5 (4K context)
quick_profile = get_profile("quick")  # 2K tokens

# GPT-4 (8K context)
research_profile = get_profile("research")  # 8K tokens

# Claude (100K context)
documentation_profile = get_profile("documentation")  # 10K tokens

# Adjust for your LLM
builder = ContextBuilder(max_tokens=quick_profile.max_tokens)
```

---

## Performance Optimization

### Batch Operations

```python
# ❌ Bad: One at a time
for url in urls:
    cc.from_url(url)  # Slow!

# ✅ Good: Batch download
cc.from_urls(urls)  # Much faster!
```

### Index Once, Search Many

```python
# ✅ Index all local files once
cc.add_local_directory("./docs", recursive=True)

# Then search many times (fast!)
results1 = cc.search("topic A")
results2 = cc.search("topic B")
results3 = cc.search("topic C")
```

### Lazy Loading

```python
class LazyKnowledgeBase:
    def __init__(self):
        self.cc = None
        self.papers = None
    
    def _ensure_loaded(self):
        """Load only when needed."""
        if self.cc is None:
            self.cc = CrazyContext()
            # Load data...
    
    def search(self, query):
        self._ensure_loaded()  # Load on first use
        return self.cc.search(query)
```

### Parallel Downloads

```python
from concurrent.futures import ThreadPoolExecutor

def download_parallel(cc, urls, max_workers=5):
    """Download multiple URLs in parallel."""
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        results = list(executor.map(cc.from_url, urls))
    return results

# Use for many URLs
urls = [...]  # 100 URLs
results = download_parallel(cc, urls)
```

---

## Error Handling

### Check Download Status

```python
# ✅ Always check status
result = cc.from_url("https://example.com")

if result['status'] == 'failed':
    print(f"❌ Download failed: {result.get('error')}")
    # Handle error appropriately
else:
    print(f"✅ Downloaded to: {result['file']}")
```

### Graceful Degradation

```python
def safe_search(cc, query):
    """Search with error handling."""
    try:
        results = cc.search(query)
        
        if not results:
            print("No results found, trying fuzzy search...")
            results = cc.search(query, search_type="fuzzy")
        
        return results
    
    except Exception as e:
        print(f"Search error: {e}")
        return []

# Use safe wrapper
results = safe_search(cc, "my query")
```

### Retry Logic

```python
from time import sleep

def download_with_retry(cc, url, max_retries=3):
    """Download with retries."""
    for attempt in range(max_retries):
        result = cc.from_url(url)
        
        if result['status'] == 'success':
            return result
        
        if attempt < max_retries - 1:
            wait_time = 2 ** attempt  # Exponential backoff
            print(f"Retry {attempt+1}/{max_retries} in {wait_time}s...")
            sleep(wait_time)
    
    return result  # Return last result even if failed
```

### Validate Input

```python
def validate_url(url):
    """Validate URL before downloading."""
    if not url.startswith(('http://', 'https://')):
        raise ValueError(f"Invalid URL: {url}")
    
    # Check if reasonable
    if len(url) > 2000:
        raise ValueError("URL too long")
    
    return True

# Use validation
try:
    validate_url(user_provided_url)
    cc.from_url(user_provided_url)
except ValueError as e:
    print(f"Invalid URL: {e}")
```

---

## Production Deployment

### Configuration Management

```python
# config.py
from dataclasses import dataclass

@dataclass
class Config:
    cache_dir: str = "./production_cache"
    max_tokens: int = 4000
    log_level: str = "WARNING"  # Less verbose in prod
    rate_limit: int = 100  # requests per hour
    
    # API keys (use environment variables!)
    github_token: str = os.getenv("GITHUB_TOKEN")
    semantic_scholar_key: str = os.getenv("S2_API_KEY")

# Use config
config = Config()
cc = CrazyContext(
    cache_dir=config.cache_dir,
    log_level=config.log_level
)
```

### Logging

```python
import logging

# Configure logging properly
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('crazycontext.log'),
        logging.StreamHandler()
    ]
)

# Use throughout your code
logger = logging.getLogger(__name__)

def my_function():
    logger.info("Starting operation")
    try:
        result = cc.search("query")
        logger.info(f"Found {len(result)} results")
    except Exception as e:
        logger.error(f"Search failed: {e}", exc_info=True)
```

### Rate Limiting

```python
from time import time, sleep

class RateLimiter:
    def __init__(self, max_calls, period):
        self.max_calls = max_calls
        self.period = period
        self.calls = []
    
    def __call__(self, func):
        def wrapper(*args, **kwargs):
            now = time()
            # Remove old calls
            self.calls = [c for c in self.calls if now - c < self.period]
            
            if len(self.calls) >= self.max_calls:
                sleep_time = self.period - (now - self.calls[0])
                print(f"Rate limit reached, waiting {sleep_time:.1f}s...")
                sleep(sleep_time)
            
            self.calls.append(now)
            return func(*args, **kwargs)
        return wrapper

# Use rate limiter
@RateLimiter(max_calls=100, period=3600)  # 100 per hour
def download_with_limit(url):
    return cc.from_url(url)
```

### Health Checks

```python
def health_check(cc):
    """Check system health."""
    try:
        # Check cache
        stats = cc.get_stats()
        cache_ok = stats['web']['cache_size_mb'] < 5000  # < 5GB
        
        # Check search
        test_results = cc.search("test")
        search_ok = test_results is not None
        
        # Check disk space
        import shutil
        disk = shutil.disk_usage(cc.cache_dir)
        disk_ok = disk.free > 1_000_000_000  # > 1GB free
        
        health = {
            'cache': 'ok' if cache_ok else 'warning',
            'search': 'ok' if search_ok else 'error',
            'disk': 'ok' if disk_ok else 'warning',
            'overall': 'ok' if all([cache_ok, search_ok, disk_ok]) else 'degraded'
        }
        
        return health
    
    except Exception as e:
        return {'overall': 'error', 'message': str(e)}

# Check regularly
health = health_check(cc)
print(f"System health: {health['overall']}")
```

### Metrics and Monitoring

```python
from dataclasses import dataclass
from datetime import datetime

@dataclass
class Metrics:
    downloads: int = 0
    searches: int = 0
    errors: int = 0
    cache_size_mb: float = 0.0
    last_updated: datetime = None

class MonitoredCrazyContext:
    def __init__(self, *args, **kwargs):
        self.cc = CrazyContext(*args, **kwargs)
        self.metrics = Metrics()
    
    def from_url(self, url):
        result = self.cc.from_url(url)
        self.metrics.downloads += 1
        if result['status'] == 'failed':
            self.metrics.errors += 1
        self._update_metrics()
        return result
    
    def search(self, query, **kwargs):
        results = self.cc.search(query, **kwargs)
        self.metrics.searches += 1
        self._update_metrics()
        return results
    
    def _update_metrics(self):
        stats = self.cc.get_stats()
        self.metrics.cache_size_mb = stats['web']['cache_size_mb']
        self.metrics.last_updated = datetime.now()
    
    def get_metrics(self):
        return self.metrics

# Use monitored version
cc = MonitoredCrazyContext(cache_dir="./cache")

# ... use normally ...

# Check metrics
metrics = cc.get_metrics()
print(f"Downloads: {metrics.downloads}")
print(f"Searches: {metrics.searches}")
print(f"Errors: {metrics.errors}")
```

---

## Security Best Practices

### Never Hardcode Secrets

```python
import os

# ❌ Bad: Hardcoded tokens
github = GitHubSource(github_token="ghp_123456789...")

# ✅ Good: Use environment variables
github = GitHubSource(
    github_token=os.getenv("GITHUB_TOKEN")
)
```

### Validate User Input

```python
def safe_query(user_query):
    """Sanitize user input."""
    # Limit length
    if len(user_query) > 1000:
        raise ValueError("Query too long")
    
    # Remove dangerous characters
    dangerous = ['<', '>', '&', ';', '|']
    if any(char in user_query for char in dangerous):
        raise ValueError("Query contains invalid characters")
    
    return user_query.strip()

# Use validation
try:
    query = safe_query(user_input)
    results = cc.search(query)
except ValueError as e:
    print(f"Invalid query: {e}")
```

### Limit Resource Usage

```python
# Set limits
MAX_DOWNLOADS = 1000
MAX_CACHE_SIZE_MB = 5000
MAX_RESULTS = 100

def safe_download(cc, urls):
    """Download with limits."""
    if len(urls) > MAX_DOWNLOADS:
        raise ValueError(f"Too many URLs (max: {MAX_DOWNLOADS})")
    
    # Check cache size before downloading
    stats = cc.get_stats()
    if stats['web']['cache_size_mb'] > MAX_CACHE_SIZE_MB:
        raise RuntimeError("Cache too large, clean first")
    
    return cc.from_urls(urls)
```

---

## Testing Best Practices

### Unit Test Your Integration

```python
import pytest
from crazycontext import CrazyContext

def test_document_qa():
    """Test document Q&A workflow."""
    cc = CrazyContext(cache_dir="./test_cache")
    
    # Small test data
    cc.from_urls(["http://example.com"])
    
    # Test search
    results = cc.search("test")
    assert isinstance(results, list)
    
    # Test context building
    context = cc.build_context(results, max_length=500)
    assert len(context) > 0

# Run tests
pytest.main([__file__])
```

### Mock External APIs

```python
from unittest.mock import Mock, patch

def test_papers_search():
    """Test with mocked API."""
    with patch('crazycontext.sources.apis.requests.get') as mock_get:
        # Mock response
        mock_response = Mock()
        mock_response.json.return_value = {"data": []}
        mock_get.return_value = mock_response
        
        # Test
        from crazycontext.sources import PapersSource
        papers = PapersSource()
        results = papers.search("test")
        
        assert isinstance(results, list)
```

---

## Summary

### Key Takeaways

1. **Cache Everything** - Set meaningful cache directories
2. **Start Small** - Test with small datasets first
3. **Monitor Resources** - Check cache size and disk space
4. **Handle Errors** - Always check status and use try-except
5. **Limit Tokens** - Use ContextBuilder with max_tokens
6. **Use Profiles** - Consistent settings across team
7. **Batch Operations** - Download and search in batches
8. **Log Everything** - Use proper logging in production
9. **Secure Secrets** - Never hardcode API keys
10. **Test Thoroughly** - Unit test your integrations

---

**Follow these practices for reliable, efficient CrazyContext applications!**
