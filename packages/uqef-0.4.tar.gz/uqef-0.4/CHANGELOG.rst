Main Branch
=============

Version 0.4.1 (2025-10-24)
===========================

CHANGED:
  * Make UQEF available to the public