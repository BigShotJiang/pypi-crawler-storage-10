"""
Model package

@author: Florian Kuenzner
"""

from .Model import Model
from .TestModel import TestModel
