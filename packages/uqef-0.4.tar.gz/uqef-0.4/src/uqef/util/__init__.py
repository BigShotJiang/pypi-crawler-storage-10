"""
Statistics package

@author: Florian Kuenzner
"""

from .TimeMeasurement import TimeDuration
from .TimeMeasurement import TimeMeasurement
