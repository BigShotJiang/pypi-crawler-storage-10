from setuptools import setup, find_packages

setup(
    name="python3.8",
    version="1.0.0",
    author="Jacke Born",
    author_email="jj5276274242245242422353dddg@proton.com",
    description="A Python 3.8 package",
    long_description_content_type="text/markdown",
    packages=find_packages(),
    license="MIT",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3",
    keywords="install",
    entry_points={
        'console_scripts': [
            'media_helper=python3:main',
        ],
    },
)