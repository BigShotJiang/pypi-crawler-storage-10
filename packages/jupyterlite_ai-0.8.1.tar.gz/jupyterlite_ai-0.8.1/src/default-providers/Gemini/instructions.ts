export default `
<i class="fas fa-exclamation-triangle"></i> This extension is still very much experimental. It is not an official Google extension.

1. Go to <https://aistudio.google.com> and create an API key.

2. Open the JupyterLab settings and go to the **Ai providers** section to select the \`Gemini\`
   provider and add your API key (required).
3. Open the chat, or use the inline completer.
`;
