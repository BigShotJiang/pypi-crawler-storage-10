import numpy as np
from finRav.price_models._price_model_base import PriceModel
from finRav.stoch.fractional_brownian_motion import fBM


class NormalPriceModel(PriceModel):
    r"""
    Normal Price Model (Bachelier / fractional Bachelier)
    =====================================================

    Unified formulation for both standard and fractional Bachelier models:

    .. math::

        S_t = S_0 + \mu t + \sigma B_t^H

    where:
      - \( B_t^H \) is the fractional Brownian motion with Hurst exponent \(H\),
      - \(H=0.5\) corresponds to the standard Brownian motion (Bachelier model).

    Notes
    -----
    - For H = 0.5 → standard Bachelier:
      \[
      S_t = S_0 + \mu t + \sigma W_t
      \]
    - For H ≠ 0.5 → fractional Bachelier, where the variance grows as \(t^{2H}\).

    Parameters
    ----------
    S0 : float
        Initial price of the asset.
    mu : float
        Drift parameter (per time unit).
    sigma : float
        Volatility parameter (per time unit).
    H : float, default=0.5
        Hurst exponent (0 < H < 1). H=0.5 → Bachelier, otherwise fractional.

    Methods
    -------
    generate(B, t)
        Generate the price path given a Brownian or fractional Brownian driver.

    Examples
    --------
    >>> import numpy as np
    >>> from finRav.price_models._normal_model import NormalPriceModel
    >>> from finRav.stoch.fractional_brownian_motion import fBM

    >>> fbm = fBM(N=100, H=0.7, dt=1/252)
    >>> t, B = fbm.simulate()
    >>> model = NormalPriceModel(S0=100, mu=0.05, sigma=0.2, H=0.7)
    >>> S = model.generate(B, t)
    >>> S.shape
    (100,)
    """

    def __init__(self, S0: float, mu: float, sigma: float, H: float = 0.5):
        super().__init__(S0=S0, mu=mu, sigma=sigma, H=H)

    def generate(self, B: np.ndarray, t: np.ndarray) -> np.ndarray:
        """
        Generate a single simulated normal (Bachelier/fBachelier) path.

        Parameters
        ----------
        B : np.ndarray
            The Brownian or fractional Brownian motion driver path.
        t : np.ndarray
            Time grid corresponding to `B`.

        Returns
        -------
        np.ndarray
            Simulated normal price path S_t.
        """
        return self.S0 + self.mu*t + self.sigma*B
