"""
Utility subpackage for time conversions and shared helpers.
"""

from ._timebase import TimeScaler

__all__ = ["TimeScaler"]