from plugins import PluginManager,PortManager,PluginConfig

__version__ = "1.0.0"  # 定义包版本