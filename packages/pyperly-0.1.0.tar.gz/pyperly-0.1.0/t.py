import asyncio

from pyperly import bind, let


async def test(it) -> int:
    return it * 3


def mult(it: int) -> int:
    return it + 8


def sub(first: int, second: int) -> int:
    return first - second


async def main():
    v = await let(5).bind(lambda x: x * 5).arun()
    print(v)
    v = (
        await let(5)
        .abind(test)
        .bind(lambda it: it + 10)
        .bind(test, is_async=True)
        .bind(str)
        .run(True)
    )
    v = (
        await let(test, 5, is_async=True)
        .abind(test)
        .bind(lambda it: it + 10)
        .bind(test, is_async=True)
        .bind(str)
        .bind(list)
        .arun()
    )
    print(v)
    v = let(5).bind(lambda it: it + 10).bind(str).result()
    v = let(lambda x: x + 77, x=66).bind(lambda it: it + 10).run()
    v = let().bind(lambda it: it or 33 + 10).run()
    v = (let(lambda x: x + 77, x=66) & bind(lambda it: it + 10)).bind(mult, default="a").run()
    v = let(12).bind(sub, first=33, result_kw="second").run()
    v = let(12).bind(sub, 33, result_kw="second").run()
    v = let(12).bind(sub, second=5).run()


v = asyncio.run(main())
