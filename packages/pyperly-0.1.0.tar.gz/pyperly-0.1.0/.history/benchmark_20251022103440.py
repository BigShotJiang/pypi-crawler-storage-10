"""Benchmark pyperly library against vanilla Python code.

This script compares the performance of pyperly pipeline operations
with equivalent vanilla Python implementations across various scenarios.
"""

import asyncio
import time

from pyperly.pipeline import let, alet


def benchmark(func, iterations: int = 100000, name: str = "") -> float:
    """Run a benchmark for a synchronous function.

    Args:
        func: The function to benchmark.
        iterations: Number of iterations to run.
        name: Name of the benchmark.

    Returns:
        Average execution time in microseconds.
    """
    start = time.perf_counter()
    for _ in range(iterations):
        func()
    end = time.perf_counter()
    avg_time = ((end - start) / iterations) * 1_000_000  # Convert to microseconds
    print(f"{name:50} {avg_time:8.2f} μs")
    return avg_time


async def async_benchmark(func, iterations: int = 10000, name: str = "") -> float:
    """Run a benchmark for an asynchronous function.

    Args:
        func: The async function to benchmark.
        iterations: Number of iterations to run.
        name: Name of the benchmark.

    Returns:
        Average execution time in microseconds.
    """
    start = time.perf_counter()
    for _ in range(iterations):
        await func()
    end = time.perf_counter()
    avg_time = ((end - start) / iterations) * 1_000_000  # Convert to microseconds
    print(f"{name:50} {avg_time:8.2f} μs")
    return avg_time


# =============================================================================
# Benchmark 1: Simple value transformation
# =============================================================================


def bench_simple_transform_vanilla():
    """Simple transformation: multiply by 2."""
    x = 5
    x = x * 2
    return x


def bench_simple_transform_pyperly():
    """Simple transformation using pyperly."""
    return let(5).bind(lambda x: x * 2).run()


# =============================================================================
# Benchmark 2: Chain of transformations
# =============================================================================


def bench_chain_vanilla():
    """Chain of transformations."""
    x = 10
    x = x * 2
    x = x + 5
    x = x / 3
    return x


def bench_chain_pyperly():
    """Chain of transformations using pyperly."""
    return (
        let(10)
        .bind(lambda x: x * 2)
        .bind(lambda x: x + 5)
        .bind(lambda x: x / 3)
        .run()
    )


def bench_chain_pyperly_operator():
    """Chain of transformations using pyperly with / operator."""
    return (let(10) / (lambda x: x * 2) / (lambda x: x + 5) / (lambda x: x / 3)).run()


# =============================================================================
# Benchmark 3: With side effects (apply)
# =============================================================================


def bench_side_effects_vanilla():
    """Transformation with side effects."""
    results = []
    x = 5
    x = x * 2
    results.append(x)
    x = x + 3
    results.append(x)
    return x


def bench_side_effects_pyperly():
    """Transformation with side effects using pyperly."""
    results = []
    return (
        let(5)
        .bind(lambda x: x * 2)
        .apply(results.append)
        .bind(lambda x: x + 3)
        .apply(results.append)
        .run()
    )


# =============================================================================
# Benchmark 4: With validation (ensure)
# =============================================================================


def bench_validation_vanilla():
    """Transformation with validation."""
    x = 10
    x = x * 2
    if x <= 0:
        return None
    x = x - 5
    if x <= 0:
        return None
    return x


def bench_validation_pyperly():
    """Transformation with validation using pyperly."""
    return (
        let(10)
        .bind(lambda x: x * 2)
        .ensure(lambda x: x > 0)
        .bind(lambda x: x - 5)
        .ensure(lambda x: x > 0)
        .run()
    )


# =============================================================================
# Benchmark 5: Complex data processing
# =============================================================================


def bench_complex_vanilla():
    """Complex data processing with dict."""
    data = {"value": 100, "multiplier": 2}
    value = data["value"] * data["multiplier"]
    if value < 0:
        return None
    value = value + 50
    result = {"result": value, "processed": True}
    return result


def bench_complex_pyperly():
    """Complex data processing using pyperly."""
    return (
        let({"value": 100, "multiplier": 2})
        .bind(lambda d: d["value"] * d["multiplier"])
        .ensure(lambda x: x >= 0)
        .bind(lambda x: x + 50)
        .bind(lambda x: {"result": x, "processed": True})
        .run()
    )


# =============================================================================
# Benchmark 6: List processing
# =============================================================================


def bench_list_processing_vanilla():
    """Process a list of numbers."""
    nums = list(range(10))
    nums = [x * 2 for x in nums]
    nums = [x for x in nums if x > 5]
    total = sum(nums)
    return total


def bench_list_processing_pyperly():
    """Process a list using pyperly."""
    return (
        let(list(range(10)))
        .bind(lambda nums: [x * 2 for x in nums])
        .bind(lambda nums: [x for x in nums if x > 5])
        .bind(sum)
        .run()
    )


# =============================================================================
# Benchmark 7: Async simple transformation
# =============================================================================


async def bench_async_simple_vanilla():
    """Simple async transformation."""

    async def multiply(x):
        return x * 2

    x = 5
    x = await multiply(x)
    return x


async def bench_async_simple_pyperly():
    """Simple async transformation using pyperly."""

    async def multiply(x):
        return x * 2

    return await let(5).abind(multiply).arun()


# =============================================================================
# Benchmark 8: Async chain
# =============================================================================


async def bench_async_chain_vanilla():
    """Async chain of transformations."""

    async def multiply(x):
        return x * 2

    async def add(x):
        return x + 5

    async def divide(x):
        return x / 3

    x = 10
    x = await multiply(x)
    x = await add(x)
    x = await divide(x)
    return x


async def bench_async_chain_pyperly():
    """Async chain using pyperly."""

    async def multiply(x):
        return x * 2

    async def add(x):
        return x + 5

    async def divide(x):
        return x / 3

    return await alet(10).abind(multiply).abind(add).abind(divide).arun()


async def bench_async_chain_pyperly_operator():
    """Async chain using pyperly with // operator."""

    async def multiply(x):
        return x * 2

    async def add(x):
        return x + 5

    async def divide(x):
        return x / 3

    return await (alet(10) // multiply // add // divide).arun()


# =============================================================================
# Benchmark 9: Mixed sync/async
# =============================================================================


async def bench_async_mixed_vanilla():
    """Mixed sync/async operations."""

    async def async_multiply(x):
        return x * 2

    def sync_add(x):
        return x + 5

    x = 10
    x = await async_multiply(x)
    x = sync_add(x)
    return x


async def bench_async_mixed_pyperly():
    """Mixed sync/async using pyperly."""

    async def async_multiply(x):
        return x * 2

    def sync_add(x):
        return x + 5

    return await alet(10).abind(async_multiply).bind(sync_add).arun()


# =============================================================================
# Main benchmark runner
# =============================================================================


def print_header(title: str):
    """Print a benchmark section header."""
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70)


def print_comparison(vanilla_time: float, pyperly_time: float):
    """Print performance comparison."""
    overhead = ((pyperly_time - vanilla_time) / vanilla_time) * 100
    print(f"{'Overhead:':50} {overhead:8.2f}%\n")


async def run_async_benchmarks():
    """Run all async benchmarks."""
    print_header("Async Benchmarks (10,000 iterations)")

    print("\n7. Simple Async Transformation:")
    vanilla = await async_benchmark(
        bench_async_simple_vanilla, name="  Vanilla Python"
    )
    pyperly = await async_benchmark(
        bench_async_simple_pyperly, name="  pyperly"
    )
    print_comparison(vanilla, pyperly)

    print("8. Async Chain (3 operations):")
    vanilla = await async_benchmark(bench_async_chain_vanilla, name="  Vanilla Python")
    pyperly = await async_benchmark(bench_async_chain_pyperly, name="  pyperly")
    operator = await async_benchmark(
        bench_async_chain_pyperly_operator, name="  pyperly (// operator)"
    )
    print_comparison(vanilla, pyperly)

    print("9. Mixed Sync/Async:")
    vanilla = await async_benchmark(bench_async_mixed_vanilla, name="  Vanilla Python")
    pyperly = await async_benchmark(bench_async_mixed_pyperly, name="  pyperly")
    print_comparison(vanilla, pyperly)


def main():
    """Run all benchmarks."""
    print("\n" + "=" * 70)
    print("  pyperly Performance Benchmark")
    print("=" * 70)
    print("\nComparing pyperly pipeline operations with vanilla Python")
    print("Times are in microseconds (μs). Lower is better.\n")

    print_header("Synchronous Benchmarks (100,000 iterations)")

    print("\n1. Simple Transformation (multiply by 2):")
    vanilla = benchmark(bench_simple_transform_vanilla, name="  Vanilla Python")
    pyperly = benchmark(bench_simple_transform_pyperly, name="  pyperly")
    print_comparison(vanilla, pyperly)

    print("2. Chain of Transformations (3 operations):")
    vanilla = benchmark(bench_chain_vanilla, name="  Vanilla Python")
    pyperly = benchmark(bench_chain_pyperly, name="  pyperly")
    operator = benchmark(bench_chain_pyperly_operator, name="  pyperly (/ operator)")
    print_comparison(vanilla, pyperly)

    print("3. With Side Effects (apply):")
    vanilla = benchmark(bench_side_effects_vanilla, name="  Vanilla Python")
    pyperly = benchmark(bench_side_effects_pyperly, name="  pyperly")
    print_comparison(vanilla, pyperly)

    print("4. With Validation (ensure):")
    vanilla = benchmark(bench_validation_vanilla, name="  Vanilla Python")
    pyperly = benchmark(bench_validation_pyperly, name="  pyperly")
    print_comparison(vanilla, pyperly)

    print("5. Complex Data Processing:")
    vanilla = benchmark(bench_complex_vanilla, name="  Vanilla Python")
    pyperly = benchmark(bench_complex_pyperly, name="  pyperly")
    print_comparison(vanilla, pyperly)

    print("6. List Processing:")
    vanilla = benchmark(bench_list_processing_vanilla, name="  Vanilla Python")
    pyperly = benchmark(bench_list_processing_pyperly, name="  pyperly")
    print_comparison(vanilla, pyperly)

    # Run async benchmarks
    asyncio.run(run_async_benchmarks())

    print("\n" + "=" * 70)
    print("  Benchmark Complete")
    print("=" * 70)
    print("\nNotes:")
    print("- pyperly adds overhead for abstraction and flexibility")
    print("- The overhead is typically acceptable for improved readability")
    print("- Use pyperly when code clarity is more important than raw speed")
    print("- For performance-critical hot paths, consider vanilla Python")
    print("=" * 70 + "\n")


if __name__ == "__main__":
    main()
