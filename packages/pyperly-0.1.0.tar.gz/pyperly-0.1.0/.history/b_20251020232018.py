import time


def pipe():
    pass


def 
