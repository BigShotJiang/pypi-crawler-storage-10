from datetime import datetime

from pyperly import let


def pipe(n: int):
    x = n ** n
    
    pass


def regular(n: int):
    let(n).bind(lambda it: it**it).aapply(lambda it: it > 1000).apply(datetime.now).bind(
        lambda x, y: x * y, n * n
    ).run()
