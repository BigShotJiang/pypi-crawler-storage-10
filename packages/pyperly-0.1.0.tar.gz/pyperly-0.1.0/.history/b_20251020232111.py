import time
from pyperly import let


def pipe():
    for _ in 
    pass


def regular():
    pass
