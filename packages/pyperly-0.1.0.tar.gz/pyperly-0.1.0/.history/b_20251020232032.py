import time



def pipe():
    pass


def regular():
    pass
