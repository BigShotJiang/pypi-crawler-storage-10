import time
from pyperly import let


def pipe():
    pass

def regular():
    let(5).bind(lambda it: )
    pass
