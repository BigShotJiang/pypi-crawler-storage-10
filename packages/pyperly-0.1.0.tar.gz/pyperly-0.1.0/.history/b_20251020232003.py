import time

def pipe()
