# pyright: strict

import typing as t
from dataclasses import dataclass
from enum import Enum, auto

from pyperly.typedefs import AnyDict, AnyTuple, AsyncCallable, OptionalBool, OptionalStr, T_Callback


class CallbackType(Enum):
    """Types of callbacks in the pipeline.

    Attributes:
        APPLY: Apply function for side effects without changing pipeline value.
        BIND: Bind function that transforms the pipeline value.
        ENSURE: Ensure predicate that validates the pipeline value.
    """

    APPLY = auto()
    BIND = auto()
    ENSURE = auto()


@dataclass(slots=True, frozen=True)
class CallbackResult(t.Generic[T_Callback]):
    """Result of executing a callback in the pipeline.

    Attributes:
        success: Whether the callback execution was successful.
        result: The result produced by the callback.
    """

    fn_type: t.Final[CallbackType]
    result: T_Callback
    allow_none: t.Final[OptionalBool] = None
    default: t.Final[T_Callback | None] = None

    def unwrap(self) -> T_Callback | None:
        """Unwrap the result, returning default if result is None.

        Returns:
            The unwrapped result.
        """
        if self.result is None and self.default is not None:
            return self.default
        return self.result

    @property
    def has_default(self) -> bool:
        """Check if a default value is set.

        Returns:
            True if a default value is set, False otherwise.
        """
        return self.default is not None

    @property

    def __repr__(self) -> str:
        return (
            f"CallbackResult("
            f"type={self.fn_type}, "
            f"result={self.result}, "
            f"allow_none={self.allow_none}, "
            f"default={self.default})"
        )

    def __bool__(self) -> bool:
        return bool(self.result)


@t.runtime_checkable
class Callback(t.Protocol[T_Callback]):
    """Protocol for pipeline callbacks.

    This protocol defines the interface that all callback types must implement,
    whether synchronous or asynchronous.

    Attributes:
        fn_type: Type of callback (APPLY, BIND, or ENSURE).
        fn: The callable function to execute.
        args: Positional arguments to pass to the function.
        kwargs: Keyword arguments to pass to the function.
        allow_none: Whether to allow None values.
        default: Default value when result is None.
        result_kw: Keyword argument name for passing result.
    """

    fn_type: t.Final[CallbackType]
    fn: t.Final[t.Callable[..., T_Callback | None]]
    args: AnyTuple
    kwargs: AnyDict
    result_kw: t.Final[OptionalStr]
    allow_none: t.Final[OptionalBool]
    default: t.Final[T_Callback | None]
    ensure_default: t.Final[T_Callback | None]

    @property
    def is_async(self) -> bool:
        """Check if this callback is asynchronous."""
        ...

    def update_args_with_result(self, result: t.Any) -> None:
        """Update callback arguments with pipeline result."""
        ...

    def __call__(self) -> CallbackResult[T_Callback | t.Awaitable[T_Callback] | None]:
        """Execute the callback."""
        ...


@dataclass(slots=True)
class SyncCallback(t.Generic[T_Callback]):
    """Synchronous callback implementation.

    Wraps a synchronous function for use in a pipeline.

    Attributes:
        fn_type: Type of callback (APPLY, BIND, or ENSURE).
        fn: The synchronous callable to execute.
        args: Positional arguments for the function.
        kwargs: Keyword arguments for the function.
        allow_none: Whether None values are allowed.
        default: Default value when result is None.
        result_kw: Keyword argument name for passing result.
    """

    fn_type: t.Final[CallbackType]
    fn: t.Final[t.Callable[..., T_Callback]]
    args: AnyTuple
    kwargs: AnyDict
    result_kw: t.Final[OptionalStr] = None
    allow_none: t.Final[OptionalBool] = None
    default: t.Final[T_Callback | None] = None
    ensure_default: t.Final[T_Callback | None] = None

    @property
    def is_async(self) -> t.Literal[False]:
        """Return False as this is a synchronous callback."""
        return False

    def update_args_with_result(self, result: T_Callback | None) -> None:
        """Update function arguments with the pipeline result.

        Args:
            result: The result from the previous pipeline stage.
        """
        if self.result_kw:
            self.kwargs[self.result_kw] = result
        else:
            self.args = (result, *self.args)

    def __call__(self) -> CallbackResult[T_Callback | None]:
        """Execute the synchronous callback.

        Returns:
            The result of the function call, or default if result is None.
        """
        return CallbackResult(
            fn_type=self.fn_type,
            result=self.fn(*self.args, **self.kwargs),
            allow_none=self.allow_none,
            default=self.default,
        )

    def __repr__(self) -> str:
        return (
            f"SyncCallback("
            f"fn={self.fn.__name__}, "
            f"args={self.args}, "
            f"kwargs={self.kwargs}, "
            f"type={self.fn_type}, "
            f"allow_none={self.allow_none}, "
            f"default={self.default}, "
            f"result_kw={self.result_kw})"
        )


@dataclass(slots=True)
class AsyncCallback(t.Generic[T_Callback]):
    """Asynchronous callback implementation.

    Wraps an asynchronous function for use in a pipeline.

    Attributes:
        fn_type: Type of callback (APPLY, BIND, or ENSURE).
        fn: The asynchronous callable to execute.
        args: Positional arguments for the function.
        kwargs: Keyword arguments for the function.
        allow_none: Whether None values are allowed.
        default: Default value when result is None.
        result_kw: Keyword argument name for passing result.
    """

    fn_type: t.Final[CallbackType]
    fn: t.Final[AsyncCallable[T_Callback]]
    args: AnyTuple
    kwargs: AnyDict
    result_kw: t.Final[OptionalStr] = None
    allow_none: t.Final[OptionalBool] = None
    default: t.Final[T_Callback | None] = None
    ensure_default: t.Final[T_Callback | None] = None

    @property
    def is_async(self) -> t.Literal[True]:
        """Return True as this is an asynchronous callback."""
        return True

    def update_args_with_result(self, result: T_Callback | None) -> None:
        """Update function arguments with the pipeline result.

        Args:
            result: The result from the previous pipeline stage.
        """
        if self.result_kw:
            self.kwargs[self.result_kw] = result
        else:
            self.args = (result, *self.args)

    async def __call__(self) -> CallbackResult[T_Callback | None]:
        """Execute the asynchronous callback.

        Returns:
            The result of the async function call, or default if result is None.
        """
        return CallbackResult(
            fn_type=self.fn_type,
            result=await self.fn(*self.args, **self.kwargs),
            allow_none=self.allow_none,
            default=self.default,
        )

    def __repr__(self) -> str:
        return (
            f"AsyncCallback("
            f"fn={self.fn.__name__}, "
            f"args={self.args}, "
            f"kwargs={self.kwargs}, "
            f"type={self.fn_type}, "
            f"allow_none={self.allow_none}, "
            f"default={self.default}, "
            f"result_kw={self.result_kw})"
        )
