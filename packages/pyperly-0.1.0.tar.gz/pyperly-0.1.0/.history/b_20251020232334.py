import time
from pyperly import let


def pipe():
    pass


def regular(n: int):
    let(n).bind(lambda it: it ** it).aapply(lambda it: it > 1000).aapply(time.time.))
    pass
