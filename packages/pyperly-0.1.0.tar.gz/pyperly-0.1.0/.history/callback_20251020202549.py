import typing as t
from dataclasses import dataclass
from enum import Enum, StrEnum, auto

from pyperly.typedefs import AnyTuple, T_Callback


class CallbackParam(StrEnum):
    """Parameter names used for callback configuration.

    Attributes:
        ALLOW_NONE: Allow None values to pass through the pipeline.
        DEFAULT: Default value to use when result is None.
        IS_ASYNC: Flag indicating if callback is async.
        RESULT_KW: Keyword argument name for passing result.
    """

    ALLOW_NONE = auto()
    DEFAULT = auto()
    IS_ASYNC = auto()
    RESULT_KW = auto()


class CallbackType(Enum):
    """Types of callbacks in the pipeline.

    Attributes:
        APPLY: Apply function for side effects without changing pipeline value.
        BIND: Bind function that transforms the pipeline value.
        ENSURE: Ensure predicate that validates the pipeline value.
    """

    APPLY = auto()
    BIND = auto()
    ENSURE = auto()


@t.runtime_checkable
class Callback(t.Protocol[T_Callback]):
    """Protocol for pipeline callbacks.

    This protocol defines the interface that all callback types must implement,
    whether synchronous or asynchronous.

    Attributes:
        fn_type: Type of callback (APPLY, BIND, or ENSURE).
        fn: The callable function to execute.
        args: Positional arguments to pass to the function.
        kwargs: Keyword arguments to pass to the function.
        allow_none: Whether to allow None values.
        default: Default value when result is None.
        result_kw: Keyword argument name for passing result.
    """

    fn_type: t.Final[CallbackType]
    fn: t.Final[t.Callable[..., T_Callback | None]]
    args: AnyTuple
    kwargs: AnyDict
    allow_none: t.Final[OptionalBool]
    default: t.Final[T_Callback | None]
    result_kw: t.Final[OptionalStr]

    @property
    def is_async(self) -> bool:
        """Check if this callback is asynchronous."""
        ...

    def update_args_with_result(self, result: t.Any) -> None:
        """Update callback arguments with pipeline result."""
        ...

    def __call__(self) -> T_Callback | t.Awaitable[T_Callback] | None:
        """Execute the callback."""
        ...


@dataclass(slots=True)
class SyncCallback(t.Generic[T_Callback]):
    """Synchronous callback implementation.

    Wraps a synchronous function for use in a pipeline.

    Attributes:
        fn_type: Type of callback (APPLY, BIND, or ENSURE).
        fn: The synchronous callable to execute.
        args: Positional arguments for the function.
        kwargs: Keyword arguments for the function.
        allow_none: Whether None values are allowed.
        default: Default value when result is None.
        result_kw: Keyword argument name for passing result.
    """

    fn_type: t.Final[CallbackType]
    fn: t.Final[t.Callable[..., T_Callback]]
    args: AnyTuple
    kwargs: AnyDict
    allow_none: t.Final[OptionalBool] = None
    default: t.Final[T_Callback | None] = None
    result_kw: t.Final[OptionalStr] = None

    @property
    def is_async(self) -> t.Literal[False]:
        """Return False as this is a synchronous callback."""
        return False

    def update_args_with_result(self, result: T_Callback | None) -> None:
        """Update function arguments with the pipeline result.

        Args:
            result: The result from the previous pipeline stage.
        """
        if self.result_kw:
            self.kwargs[self.result_kw] = result
        else:
            self.args = (result, *self.args)

    def __call__(self) -> T_Callback | None:
        """Execute the synchronous callback.

        Returns:
            The result of the function call, or default if result is None.
        """
        r = self.fn(*self.args, **self.kwargs)
        return self.default if r is None else r

    def __repr__(self) -> str:
        return (
            f"SyncCallback("
            f"fn={self.fn.__name__}, "
            f"args={self.args}, "
            f"kwargs={self.kwargs}, "
            f"type={self.fn_type}, "
            f"allow_none={self.allow_none}, "
            f"default={self.default}, "
            f"result_kw={self.result_kw})"
        )


@dataclass(slots=True)
class AsyncCallback(t.Generic[T_Callback]):
    """Asynchronous callback implementation.

    Wraps an asynchronous function for use in a pipeline.

    Attributes:
        fn_type: Type of callback (APPLY, BIND, or ENSURE).
        fn: The asynchronous callable to execute.
        args: Positional arguments for the function.
        kwargs: Keyword arguments for the function.
        allow_none: Whether None values are allowed.
        default: Default value when result is None.
        result_kw: Keyword argument name for passing result.
    """

    fn_type: t.Final[CallbackType]
    fn: t.Final[AsyncCallable[T_Callback]]
    args: AnyTuple
    kwargs: AnyDict
    allow_none: t.Final[OptionalBool] = None
    default: t.Final[T_Callback | None] = None
    result_kw: t.Final[OptionalStr] = None

    @property
    def is_async(self) -> t.Literal[True]:
        """Return True as this is an asynchronous callback."""
        return True

    def update_args_with_result(self, result: T_Callback | None) -> None:
        """Update function arguments with the pipeline result.

        Args:
            result: The result from the previous pipeline stage.
        """
        if self.result_kw:
            self.kwargs[self.result_kw] = result
        else:
            self.args = (result, *self.args)

    async def __call__(self) -> T_Callback | None:
        """Execute the asynchronous callback.

        Returns:
            The result of the async function call, or default if result is None.
        """
        r = await self.fn(*self.args, **self.kwargs)
        return self.default if r is None else r

    def __repr__(self) -> str:
        return (
            f"AsyncCallback("
            f"fn={self.fn.__name__}, "
            f"args={self.args}, "
            f"kwargs={self.kwargs}, "
            f"type={self.fn_type}, "
            f"allow_none={self.allow_none}, "
            f"default={self.default}, "
            f"result_kw={self.result_kw})"
        )
