from pyperly import let
from datetime import datetime


def pipe():
    pass


def regular(n: int):
    let(n).bind(lambda it: it**it).aapply(lambda it: it > 1000).apply(datetime).bind(
        lambda x, y: x * y, n * n
    ).run()
