def main():
    print("Hello from pyperly!")


if __name__ == "__main__":
    main()
