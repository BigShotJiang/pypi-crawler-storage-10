import time
from datetime import datetime

from pyperly import let


def regular(n: int):
    x = n**n
    if x <= 1000:
        return

    datetime.now()
    _ = n * n * x


def pipe(n: int):
    let(n).bind(lambda it: it**it).ensure(lambda it: it > 1000).apply(datetime.now).bind(
        lambda x, y: x * y, n * n
    ).run()


def test():
    count = 1000
    for i in range(count):
        regular(i)
    for i in range(count):
        pipe(i)

    for 
    start = time.perf_counter()
    for i in range(count):
        regular(i)
    duration = time.perf_counter() - start
    print("regular", round(duration / count, 3))
