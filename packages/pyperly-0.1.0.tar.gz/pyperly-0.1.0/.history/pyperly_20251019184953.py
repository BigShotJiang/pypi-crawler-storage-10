# pyright: reportInconsistentOverload=false

import typing as t
from dataclasses import dataclass
from enum import Enum, StrEnum, auto

T = t.TypeVar("T")
T_Covariant = t.TypeVar("T_Covariant", covariant=True)
U = t.TypeVar("U")


class CallbackParam(StrEnum):
    ALLOW_NONE = auto()
    DEFAULT = auto()
    IS_ASYNC = auto()
    RESULT_KW = auto()


class CallbackType(Enum):
    APPLY = auto()
    BIND = auto()
    ENSURE = auto()


@t.runtime_checkable
class Callback(t.Protocol[T_Covariant]):
    fn_type: t.Final[CallbackType]
    fn: t.Final[t.Callable[..., T_Covariant | None]]
    args: tuple[t.Any, ...]
    kwargs: dict[str, t.Any]
    allow_none: bool | None
    default: t.Any
    result_kw: str | None

    @property
    def is_async(self) -> bool: ...
    def update_args_with_result(self, result: t.Any, args: tuple[t.Any, ...]): ...
    def __call__(self) -> T_Covariant | None: ...


@dataclass(slots=True)
class SyncCallback(t.Generic[T]):
    fn_type: t.Final[CallbackType]
    fn: t.Final[t.Callable[..., T]]
    args: tuple[t.Any, ...]
    kwargs: dict[str, t.Any]
    allow_none: bool | None = None
    default: T | None = None
    result_kw: str | None = None

    @property
    def is_async(self) -> t.Literal[False]:
        return False

    def update_args_with_result(self, result: T | None, args: tuple[t.Any, ...]):
        if self.result_kw:
            self.kwargs[self.result_kw] = result
        else:
            self.args = (result, *args)

    def __call__(self) -> T | None:
        r = self.fn(*self.args, **self.kwargs)
        return self.default if r is None else r


@dataclass(slots=True)
class AsyncCallback(t.Generic[T]):
    fn_type: t.Final[CallbackType]
    fn: t.Final[t.Callable[..., t.Awaitable[T]]]
    args: tuple[t.Any, ...]
    kwargs: dict[str, t.Any]
    allow_none: bool | None = None
    default: T | None = None
    result_kw: str | None = None

    @property
    def is_async(self) -> t.Literal[True]:
        return True

    def update_args_with_result(self, result: T | None, args: tuple[t.Any, ...]):
        if self.result_kw:
            self.kwargs[self.result_kw] = result
        else:
            self.args = (result, *args)

    async def __call__(self) -> T | None:
        r = await self.fn(*self.args, **self.kwargs)
        return self.default if r is None else r


@dataclass(slots=True, frozen=True)
class Result(t.Generic[U]):
    ok: bool
    value: U | None = None
    error: Exception | None = None

    @classmethod
    def new_ok(cls, value: U) -> "Result[U]":
        return cls(True, value)

    @classmethod
    def new_error(cls, error: Exception) -> "Result[U]":
        return cls(False, None, error)


class Pipeline(t.Generic[T]):
    def __init__(self, value: T | None = None):
        self._callbacks: list[Callback[t.Any]] = []
        self._result = value
        self._allow_none = False
        self._is_async = False

    @property
    def is_async(self) -> bool:
        return self._is_async

    def bind_callback(self, callback: Callback[U]) -> "Pipeline[U]":
        self._callbacks.append(callback)
        if not self._is_async and callback.is_async:
            self._is_async = True
        return self  # type: ignore

    @t.overload
    def bind(
        self, fn: t.Callable[..., U], is_async: bool, allow_none: bool, default: U, *args, **kwargs
    ) -> "Pipeline[U]": ...

    @t.overload
    def bind(
        self,
        coro: t.Callable[..., t.Awaitable[U]],
        is_async: t.Literal[True],
        allow_none: bool,
        default: U,
        *args,
        **kwargs,
    ) -> "Pipeline[U]": ...

    @t.overload
    def bind(self, fn: t.Callable[..., U], *args, **kwargs) -> "Pipeline[U]": ...

    def bind(self, fn: t.Any, *args, **kwargs) -> "Pipeline[t.Any]":
        self.bind_callback(bind(fn, *args, **kwargs))
        return self

    def abind(self, coro: t.Callable[..., t.Awaitable[U]], *args, **kwargs) -> "Pipeline[U]":
        self.bind_callback(abind(coro, *args, **kwargs))
        return self  # type: ignore

    def apply(self, fn: t.Any, *args, **kwargs) -> "Pipeline[t.Any]":
        self.bind_callback(apply(fn, *args, **kwargs))
        return self  # type: ignore

    def aapply(self, coro: t.Callable[..., t.Awaitable[U]], *args, **kwargs) -> "Pipeline[U]":
        self.bind_callback(aapply(coro, *args, **kwargs))
        return self  # type: ignore

    @t.overload
    def ensure(self, value: bool) -> "Pipeline[T]": ...

    @t.overload
    def ensure(self, predicate: t.Callable[..., bool], *args, **kwargs) -> "Pipeline[T]": ...

    def ensure(self, value: t.Any, *args, **kwargs) -> "Pipeline[T]":
        self.bind_callback(ensure(value, *args, **kwargs))
        return self

    def aensure(self, coro: t.Callable[..., t.Awaitable[U]], *args, **kwargs) -> "Pipeline[T]":
        self.bind_callback(aensure(coro, *args, **kwargs))
        return self

    @t.overload
    def run(self, is_async: t.Literal[False] = False, allow_none: bool = False) -> T: ...
    @t.overload
    def run(self, is_async: t.Literal[True], allow_none: bool = False) -> t.Awaitable[T]: ...

    def run(self, is_async: bool = False, allow_none: bool = False) -> t.Awaitable[T] | T | None:
        return self.arun(allow_none) if self._is_async or is_async else self._sync_run(allow_none)

    def _sync_run(self, allow_none: bool = False) -> T:
        self._allow_none = allow_none
        for callback in self._callbacks:
            callback.update_args_with_result(self._result, callback.args)
            if not self._handle_callback_result(callback.fn_type, callback(), callback.allow_none):
                return  # type: ignore
        return self._result  # type: ignore

    async def arun(self, allow_none: bool = False) -> T:
        self._allow_none = allow_none
        for callback in self._callbacks:
            callback.update_args_with_result(self._result, callback.args)
            result = await callback() if callback.is_async else callback()

            if not self._handle_callback_result(callback.fn_type, result, callback.allow_none):
                return  # type: ignore
        return self._result  # type: ignore

    def _handle_callback_result(
        self, fn_type: CallbackType, result: T | None, allow_none: bool | None
    ) -> bool:
        _allow_none = self._allow_none if allow_none is None else allow_none
        if fn_type == CallbackType.BIND and result is None and not _allow_none:
            return False
        elif fn_type == CallbackType.ENSURE:
            if not result:
                return False
        elif fn_type == CallbackType.APPLY:
            pass
        else:
            self._result = result
        return True

    @t.overload
    def result(self, is_async: t.Literal[False] = False) -> Result[T]: ...
    @t.overload
    def result(self, is_async: t.Literal[True]) -> t.Awaitable[Result[T]]: ...

    def result(
        self, is_async: bool = False, allow_none: bool = False
    ) -> t.Awaitable[Result[T]] | Result[T]:
        return (
            self.aresult(allow_none)
            if self._is_async or is_async
            else self._sync_result(allow_none)
        )  # type: ignore

    def _sync_result(self, allow_none: bool = False) -> Result[T]:
        try:
            result = self._sync_run(allow_none)
            return Result.new_ok(result)
        except Exception as e:
            return Result.new_error(e)

    async def aresult(self, allow_none: bool = False) -> Result[T]:
        try:
            result = await self.arun(allow_none)
            return Result.new_ok(result)
        except Exception as e:
            return Result.new_error(e)

    @t.overload
    def __and__(self, fn: Callback[T]) -> "Pipeline[T]": ...
    @t.overload
    def __and__(self, fn: t.Callable[..., U]) -> "Pipeline[U]": ...
    @t.overload
    def __and__(self, coro: t.Callable[..., t.Awaitable[U]]) -> "Pipeline[U]": ...
    @t.overload
    def __and__(
        self, args: tuple[t.Callable[..., U] | t.Callable[..., t.Awaitable[U]], ...]
    ) -> "Pipeline[U]": ...

    def __and__(self, value) -> "Pipeline[t.Any]":
        return self._handle_operator(value)

    @t.overload
    def __truediv__(self, fn: Callback[T]) -> "Pipeline[T]": ...
    @t.overload
    def __truediv__(self, fn: t.Callable[..., U]) -> "Pipeline[U]": ...
    @t.overload
    def __truediv__(self, coro: t.Callable[..., t.Awaitable[U]]) -> "Pipeline[U]": ...
    @t.overload
    def __truediv__(
        self, args: tuple[t.Callable[..., U] | t.Callable[..., t.Awaitable[U]], ...]
    ) -> "Pipeline[U]": ...

    def __truediv__(self, value: t.Any) -> "Pipeline[t.Any]":
        return self._handle_operator(value)

    @t.overload
    def __floordiv__(self, fn: Callback[T]) -> "Pipeline[T]": ...
    @t.overload
    def __floordiv__(self, coro: t.Callable[..., t.Awaitable[U]]) -> "Pipeline[U]": ...
    @t.overload
    def __floordiv__(self, args: tuple[t.Callable[..., t.Awaitable[U]], ...]) -> "Pipeline[U]": ...

    def __floordiv__(self, value: t.Any) -> "Pipeline[t.Any]":
        return self._handle_async_operator(value)

    def _handle_operator(self, value: t.Any) -> "Pipeline[t.Any]":
        if isinstance(value, Callback):
            self.bind_callback(value)
        elif isinstance(value, tuple):
            if isinstance(value[0], bool):
                if value[0]:
                    self.abind(value[1], *value[2:])
                else:
                    self.bind(value[1], *value[2:])
            else:
                self.bind(value[0], *value[1:])
        else:
            self.bind(value)
        return self

    def _handle_async_operator(self, value: t.Any) -> "Pipeline[t.Any]":
        if isinstance(value, Callback):
            self.bind_callback(value)
        elif isinstance(value, tuple):
            self.abind(value[0], *value[1:])
        else:
            self.abind(value)
        return self


def let(value: t.Any = None, *args, **kwargs) -> Pipeline[t.Any]:
    if not isinstance(value, t.Callable):
        return Pipeline(value)
    callback = _build_callback(
        CallbackType.BIND, lambda _result, *_args, **_kwargs: value(*_args, **_kwargs), args, kwargs
    )
    return Pipeline().bind_callback(callback)


def alet(
    coro: t.Callable[..., t.Awaitable[U]],
    *args,
    **kwargs,
) -> Pipeline[U]:
    callback = _build_async_callback(
        CallbackType.BIND, lambda _result, *_args, **_kwargs: coro(*_args, **_kwargs), args, kwargs
    )
    return Pipeline().bind_callback(callback)


@t.overload
def bind(
    fn: t.Callable[..., T],
    is_async: bool,
    allow_none: bool,
    default: T,
    *args,
    **kwargs,
) -> Callback[T]: ...


@t.overload
def bind(  #
    fn: t.Callable[..., T], *args, **kwargs
) -> Callback[T]: ...


def bind(value: t.Any, *args, **kwargs) -> Callback[t.Any]:
    return _build_callback(CallbackType.BIND, value, args, kwargs)


def abind(
    coro: t.Callable[..., t.Awaitable[T]],
    *args,
    **kwargs,
) -> Callback[T]:
    return _build_async_callback(CallbackType.BIND, coro, args, kwargs)


def apply(value: t.Any, *args, **kwargs) -> Callback[t.Any]:
    return _create_callback(CallbackType.APPLY, value, args, kwargs)


def aapply(
    coro: t.Callable[..., t.Awaitable[T]],
    *args,
    **kwargs,
) -> Callback[T]:
    return _create_async_callback(CallbackType.APPLY, coro, args, kwargs)


def ensure(value: t.Any, *args, **kwargs) -> Callback[t.Any]:
    f = value if isinstance(value, t.Callable) else lambda _, *args, **kwargs: value
    return _create_callback(CallbackType.ENSURE, f, args, kwargs)


def aensure(coro: t.Callable[..., t.Awaitable[T]], *args, **kwargs) -> Callback:
    return _create_async_callback(CallbackType.ENSURE, coro, args, kwargs)


def _extract_callback_parameters(kwargs: dict[str, t.Any]) -> tuple[bool | None, t.Any, str | None]:
    allow_none = (
        kwargs.pop(CallbackParam.ALLOW_NONE) if CallbackParam.ALLOW_NONE in kwargs else None
    )
    default = kwargs.pop(CallbackParam.DEFAULT) if CallbackParam.DEFAULT in kwargs else None
    result_kw = kwargs.pop(CallbackParam.RESULT_KW) if CallbackParam.RESULT_KW in kwargs else None
    return allow_none, default, result_kw


def _create_callback(
    fn_type: CallbackType,
    fn: t.Any,
    args: tuple[t.Any, ...],
    kwargs: dict[str, t.Any],
    allow_none: bool | None = None,
    default: t.Any = None,
    result_kw: str | None = None,
) -> Callback[t.Any]:
    if CallbackParam.IS_ASYNC in kwargs and (kwargs.pop(CallbackParam.IS_ASYNC)):
        return _create_async_callback(fn_type, fn, args, kwargs, allow_none, default, result_kw)
    return SyncCallback(fn_type, fn, args, kwargs, allow_none, default, result_kw)


def _build_callback(
    fn_type: CallbackType,
    fn: t.Any,
    args: tuple[t.Any, ...],
    kwargs: dict[str, t.Any],
) -> Callback[t.Any]:
    allow_none, default, result_kw = _extract_callback_parameters(kwargs)
    return _create_callback(fn_type, fn, args, kwargs, allow_none, default, result_kw)


def _create_async_callback(
    fn_type: CallbackType,
    coro: t.Callable[..., t.Awaitable[U]],
    args: tuple[t.Any, ...],
    kwargs: dict[str, t.Any],
    allow_none: bool | None = None,
    default: t.Any = None,
    result_kw: str | None = None,
) -> Callback[t.Any]:
    return AsyncCallback(fn_type, coro, args, kwargs, allow_none, default, result_kw)


def _build_async_callback(
    fn_type: CallbackType,
    coro: t.Callable[..., t.Awaitable[U]],
    args: tuple[t.Any, ...],
    kwargs: dict[str, t.Any],
) -> Callback[U]:
    allow_none, default, result_kw = _extract_callback_parameters(kwargs)
    return _create_async_callback(fn_type, coro, args, kwargs, allow_none, default, result_kw)


__all__ = [
    "let",
    "alet",
    "bind",
    "abind",
    "ensure",
    "aensure",
    "apply",
    "aapply",
]
