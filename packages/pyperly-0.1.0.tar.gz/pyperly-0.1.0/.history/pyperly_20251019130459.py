# pyright: reportInconsistentOverload=false

import typing as t
from dataclasses import dataclass
from enum import Enum, StrEnum, auto

T = t.TypeVar("T")
T_co = t.TypeVar("T_co", covariant=True)
U = t.TypeVar("U")


class FnParam(StrEnum):
    ALLOW_NONE = auto()
    DEFAULT = auto()
    IS_ASYNC = auto()
    RESULT_KW = auto()


class FnType(Enum):
    APPLY = auto()
    BIND = auto()
    ENSURE = auto()


@t.runtime_checkable
class Callback(t.Protocol[T_co]):
    fn_type: t.Final[FnType]
    fn: t.Final[t.Callable[..., T_co | None]]
    args: tuple[t.Any, ...]
    kwargs: dict[str, t.Any]
    allow_none: bool | None
    default: t.Any
    result_kw: str | None

    @property
    def is_async(self) -> bool: ...
    def update_args_with_result(self, result: t.Any, args: tuple[t.Any, ...]): ...
    def __call__(self) -> T_co | None: ...


@dataclass(slots=True)
class SyncCallback(t.Generic[T]):
    fn_type: t.Final[FnType]
    fn: t.Final[t.Callable[..., T]]
    args: tuple[t.Any, ...]
    kwargs: dict[str, t.Any]
    allow_none: bool | None = None
    default: T | None = None
    result_kw: str | None = None

    @property
    def is_async(self) -> t.Literal[False]:
        return False

    def update_args_with_result(self, result: T | None, args: tuple[t.Any, ...]):
        if self.result_kw:
            self.kwargs[self.result_kw] = result
        else:
            self.args = (result, *args)

    def __call__(self) -> T | None:
        r = self.fn(*self.args, **self.kwargs)
        return self.default if r is None else r


@dataclass(slots=True)
class AsyncCallback(t.Generic[T]):
    fn_type: t.Final[FnType]
    fn: t.Final[t.Callable[..., t.Awaitable[T]]]
    args: tuple[t.Any, ...]
    kwargs: dict[str, t.Any]
    allow_none: bool | None = None
    default: T | None = None
    result_kw: str | None = None

    @property
    def is_async(self) -> t.Literal[True]:
        return True

    def update_args_with_result(self, result: T | None, args: tuple[t.Any, ...]):
        if self.result_kw:
            self.kwargs[self.result_kw] = result
        else:
            self.args = (result, *args)

    async def __call__(self) -> T | None:
        r = await self.fn(*self.args, **self.kwargs)
        return self.default if r is None else r


@dataclass(slots=True, frozen=True)
class Result(t.Generic[U]):
    ok: bool
    value: U | None = None
    error: Exception | None = None

    @classmethod
    def new_ok(cls, value: U) -> "Result[U]":
        return cls(True, value)

    @classmethod
    def new_error(cls, error: Exception) -> "Result[U]":
        return cls(False, None, error)


class Pipeline(t.Generic[T]):
    def __init__(self, value: T | None = None):
        self._callbacks: list[Callback[t.Any]] = []
        self._result = value
        self._allow_none = False
        self._is_async = False

    @property
    def is_async(self) -> bool:
        return self._is_async

    @t.overload
    def __and__(self, fn: Callback[T]) -> "Pipeline[T]": ...
    @t.overload
    def __and__(self, fn: t.Callable[..., U]) -> "Pipeline[U]": ...
    @t.overload
    def __and__(self, coro: t.Callable[..., t.Awaitable[U]]) -> "Pipeline[U]": ...
    @t.overload
    def __and__(
        self, t: tuple[t.Callable[..., U] | t.Callable[..., t.Awaitable[U]], ...]
    ) -> "Pipeline[U]": ...

    def __and__(self, value) -> "Pipeline[t.Any]":
        return self._resolve_operator(value)

    @t.overload
    def __truediv__(self, fn: Callback[T]) -> "Pipeline[T]": ...
    @t.overload
    def __truediv__(self, fn: t.Callable[..., U]) -> "Pipeline[U]": ...
    @t.overload
    def __truediv__(self, coro: t.Callable[..., t.Awaitable[U]]) -> "Pipeline[U]": ...
    @t.overload
    def __truediv__(
        self, t: tuple[t.Callable[..., U] | t.Callable[..., t.Awaitable[U]], ...]
    ) -> "Pipeline[U]": ...

    def __truediv__(self, value: t.Any) -> "Pipeline[t.Any]":
        return self._resolve_operator(value)

    @t.overload
    def __floordiv__(self, fn: Callback[T]) -> "Pipeline[T]": ...
    @t.overload
    def __floordiv__(self, coro: t.Callable[..., t.Awaitable[U]]) -> "Pipeline[U]": ...
    @t.overload
    def __floordiv__(self, t: tuple[t.Callable[..., t.Awaitable[U]], ...]) -> "Pipeline[U]": ...

    def __floordiv__(self, value: t.Any) -> "Pipeline[t.Any]":
        return self._resolve_async_operator(value)

    def _resolve_operator(self, value: t.Any) -> "Pipeline[t.Any]":
        if isinstance(value, Callback):
            self.bind_callback(value)
        elif isinstance(value, tuple):
            if isinstance(value[0], bool):
                if value[0]:
                    self.abind(value[1], *value[2:])
                else:
                    self.bind(value[1], *value[2:])
            else:
                self.bind(value[0], *value[1:])
        else:
            self.bind(value)
        return self

    def _resolve_async_operator(self, value: t.Any) -> "Pipeline[t.Any]":
        if isinstance(value, Callback):
            self.bind_callback(value)
        elif isinstance(value, tuple):
            self.abind(value[0], *value[1:])
        else:
            self.abind(value)
        return self

    def bind_callback(self, callback: Callback[U]) -> "Pipeline[U]":
        self._callbacks.append(callback)
        if not self._is_async and callback.is_async:
            self._is_async = True
        return self  # type: ignore

    @t.overload
    def bind(
        self, fn: t.Callable[..., U], is_async: bool, allow_none: bool, default: U, *args, **kwargs
    ) -> "Pipeline[U]": ...

    @t.overload
    def bind(self, fn: t.Callable[..., U], *args, **kwargs) -> "Pipeline[U]": ...

    def bind(self, fn: t.Any, *args, **kwargs) -> "Pipeline[t.Any]":
        self.bind_callback(bind(fn, *args, **kwargs))
        return self

    def abind(self, coro: t.Callable[..., t.Awaitable[U]], *args, **kwargs) -> "Pipeline[U]":
        self.bind_callback(abind(coro, *args, **kwargs))
        return self  # type: ignore

    def apply(self, fn: t.Any, *args, **kwargs) -> "Pipeline[t.Any]":
        self.bind_callback(apply(fn, *args, **kwargs))
        return self  # type: ignore

    def aapply(self, coro: t.Callable[..., t.Awaitable[U]], *args, **kwargs) -> "Pipeline[U]":
        self.bind_callback(aapply(coro, *args, **kwargs))
        return self  # type: ignore

    @t.overload
    def ensure(self, value: bool) -> "Pipeline[T]": ...

    @t.overload
    def ensure(self, predicate: t.Callable[..., bool], *args, **kwargs) -> "Pipeline[T]": ...

    def ensure(self, value: t.Any, *args, **kwargs) -> "Pipeline[T]":
        self.bind_callback(ensure(value, *args, **kwargs))
        return self

    def aensure(self, coro: t.Callable[..., t.Awaitable[U]], *args, **kwargs) -> "Pipeline[T]":
        self.bind_callback(aensure(coro, *args, **kwargs))
        return self

    @t.overload
    def run(self, is_async: t.Literal[False] = False, allow_none: bool = False) -> T: ...
    @t.overload
    def run(self, is_async: t.Literal[True], allow_none: bool = False) -> t.Awaitable[T]: ...

    def run(self, is_async: bool = False, allow_none: bool = False) -> t.Awaitable[T] | T | None:
        return self.arun(allow_none) if self._is_async or is_async else self._srun(allow_none)

    def _srun(self, allow_none: bool = False) -> T:
        self._allow_none = allow_none
        for callback in self._callbacks:
            callback.update_args_with_result(self._result, callback.args)
            if not self._resolve_result(callback.fn_type, callback(), callback.allow_none):
                return  # type: ignore
        return self._result  # type: ignore

    async def arun(self, allow_none: bool = False) -> T:
        self._allow_none = allow_none
        for callback in self._callbacks:
            callback.update_args_with_result(self._result, callback.args)
            result = await callback() if callback.is_async else callback()

            if not self._resolve_result(callback.fn_type, result, callback.allow_none):
                return  # type: ignore
        return self._result  # type: ignore

    def _resolve_result(self, fn_type: FnType, result: T | None, allow_none: bool | None) -> bool:
        _allow_none = self._allow_none if allow_none is None else allow_none
        if fn_type == FnType.BIND and result is None and not _allow_none:
            return False
        elif fn_type == FnType.ENSURE:
            if not result:
                return False
        elif fn_type == FnType.APPLY:
            pass
        else:
            self._result = result
        return True

    @t.overload
    def result(self, is_async: t.Literal[False] = False) -> Result[T]: ...
    @t.overload
    def result(self, is_async: t.Literal[True]) -> t.Awaitable[Result[T]]: ...

    def result(
        self, is_async: bool = False, allow_none: bool = False
    ) -> t.Awaitable[Result[T]] | Result[T]:
        return self.aresult(allow_none) if self._is_async or is_async else self._sresult(allow_none)  # type: ignore

    def _sresult(self, allow_none: bool = False) -> Result[T]:
        try:
            result = self._srun(allow_none)
            return Result.new_ok(result)
        except Exception as e:
            return Result.new_error(e)

    async def aresult(self, allow_none: bool = False) -> Result[T]:
        try:
            result = await self.arun(allow_none)
            return Result.new_ok(result)
        except Exception as e:
            return Result.new_error(e)


def let(value: t.Any = None, *args, **kwargs) -> Pipeline[t.Any]:
    if not isinstance(value, t.Callable):
        return Pipeline(value)
    callback = _setup_callback(
        FnType.BIND, lambda _, *_args, **_kwargs: value(*_args, **_kwargs), args, kwargs
    )
    return Pipeline().bind_callback(callback)


def alet(
    coro: t.Callable[..., t.Awaitable[U]],
    *args,
    **kwargs,
) -> Pipeline[U]:
    callback = _setup_async_callback(
        FnType.BIND, lambda _, *_args, **_kwargs: coro(*_args, **_kwargs), args, kwargs
    )
    return Pipeline().bind_callback(callback)


@t.overload
def bind(
    fn: t.Callable[..., T],
    is_async: bool,
    allow_nine: bool,
    default: T,
    *args,
    **kwargs,
) -> Callback[T]: ...


@t.overload
def bind(  #
    fn: t.Callable[..., T], *args, **kwargs
) -> Callback[T]: ...


def bind(value: t.Any, *args, **kwargs) -> Callback[t.Any]:
    return _setup_callback(FnType.BIND, value, args, kwargs)


def abind(
    coro: t.Callable[..., t.Awaitable[T]],
    *args,
    **kwargs,
) -> Callback[T]:
    return _setup_async_callback(FnType.BIND, coro, args, kwargs)


def apply(value: t.Any, *args, **kwargs) -> Callback[t.Any]:
    return _create_callback(FnType.APPLY, value, args, kwargs)


def aapply(
    coro: t.Callable[..., t.Awaitable[T]],
    *args,
    **kwargs,
) -> Callback[T]:
    return _create_async_callback(FnType.APPLY, coro, args, kwargs)


def ensure(value: t.Any, *args, **kwargs) -> Callback[t.Any]:
    f = value if isinstance(value, t.Callable) else lambda _, *args, **kwargs: value
    return _create_callback(FnType.ENSURE, f, args, kwargs)


def aensure(coro: t.Callable[..., t.Awaitable[T]], *args, **kwargs) -> Callback:
    return _create_async_callback(FnType.ENSURE, coro, args, kwargs)


def _resolve_parameters(kwargs: dict[str, t.Any]) -> tuple[bool | None, t.Any, str | None]:
    allow_none = kwargs.pop(FnParam.ALLOW_NONE) if FnParam.ALLOW_NONE in kwargs else None
    default = kwargs.pop(FnParam.DEFAULT) if FnParam.DEFAULT in kwargs else None
    result_kw = kwargs.pop(FnParam.RESULT_KW) if FnParam.RESULT_KW in kwargs else None
    return allow_none, default, result_kw


def _create_callback(
    fn_type: FnType,
    fn: t.Any,
    args: tuple[t.Any, ...],
    kwargs: dict[str, t.Any],
    allow_none: bool | None = None,
    default: t.Any = None,
    result_kw: str | None = None,
) -> Callback[t.Any]:
    if FnParam.IS_ASYNC in kwargs and (kwargs.pop(FnParam.IS_ASYNC)):
        return _create_async_callback(fn_type, fn, args, kwargs, allow_none, default, result_kw)
    return SyncCallback(fn_type, fn, args, kwargs, allow_none, default, result_kw)


def _setup_callback(
    fn_type: FnType,
    fn: t.Any,
    args: tuple[t.Any, ...],
    kwargs: dict[str, t.Any],
) -> Callback[t.Any]:
    allow_none, default, result_kw = _resolve_parameters(kwargs)
    return _create_callback(fn_type, fn, args, kwargs, allow_none, default, result_kw)


def _create_async_callback(
    fn_type: FnType,
    coro: t.Callable[..., t.Awaitable[U]],
    args: tuple[t.Any, ...],
    kwargs: dict[str, t.Any],
    allow_none: bool | None = None,
    default: t.Any = None,
    result_kw: str | None = None,
) -> Callback[t.Any]:
    return AsyncCallback(fn_type, coro, args, kwargs, allow_none, default, result_kw)


def _setup_async_callback(
    fn_type: FnType,
    coro: t.Callable[..., t.Awaitable[U]],
    args: tuple[t.Any, ...],
    kwargs: dict[str, t.Any],
) -> Callback[U]:
    allow_none, default, result_kw = _resolve_parameters(kwargs)
    return _create_async_callback(fn_type, coro, args, kwargs, allow_none, default, result_kw)


__all__ = [
    "let",
    "alet",
    "bind",
    "abind",
    "ensure",
    "aensure",
    "apply",
    "aapply",
]
