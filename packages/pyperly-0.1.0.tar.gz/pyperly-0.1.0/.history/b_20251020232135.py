import time
from pyperly import let


def pipe():
    pass

def regular():
    let()
    pass
