"""
Примеры использования abind с лямбдами
"""
import asyncio
from pyperly.pipeline import Pipeline


async def main():
    # Пример 1: Лямбда с одним параметром
    result1 = await (
        Pipeline(5)
        .abind(lambda x: asyncio.sleep(0) or x * 2)
        .run(is_async=True)
    )
    print(f"Пример 1 - умножение на 2: {result1}")  # 10

    # Пример 2: Лямбда без параметров
    result2 = await (
        Pipeline()
        .abind(lambda: asyncio.sleep(0) or "Hello, World!")
        .run(is_async=True)
    )
    print(f"Пример 2 - константа: {result2}")  # Hello, World!

    # Пример 3: Лямбда с несколькими параметрами
    result3 = await (
        Pipeline(10)
        .abind(lambda x, y: asyncio.sleep(0) or x + y, 5)
        .run(is_async=True)
    )
    print(f"Пример 3 - сложение: {result3}")  # 15

    # Пример 4: Цепочка лямбд
    result4 = await (
        Pipeline("hello")
        .abind(lambda s: asyncio.sleep(0) or s.upper())
        .abind(lambda s: asyncio.sleep(0) or s + "!")
        .run(is_async=True)
    )
    print(f"Пример 4 - цепочка: {result4}")  # HELLO!


if __name__ == "__main__":
    asyncio.run(main())
