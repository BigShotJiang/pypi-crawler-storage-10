import time
from pyperly import l


def pipe():
    pass


def regular():
    pass
