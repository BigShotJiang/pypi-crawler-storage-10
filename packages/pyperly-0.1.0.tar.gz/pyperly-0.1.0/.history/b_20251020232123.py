import time
from pyperly import let


def pipe():
    for _ in range(1000):
        
    pass


def regular():
    pass
