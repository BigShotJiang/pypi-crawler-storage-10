# pyright: strict
# pyright: reportInconsistentOverload=false

import typing as t

from pyperly.callback import (
    AsyncCallback,
    Callback,
    CallbackType,
    SyncCallback,
)
from pyperly.result import Result
from pyperly.typedefs import (
    AnyDict,
    AnyTuple,
    AsyncBoundCallable,
    AsyncCallable,
    BoundCallable,
    ComplexTuple,
    OptionalBool,
    OptionalStr,
    P,
    SyncCallable,
    T,
    U,
)

PipelineOperand: t.TypeAlias = (
    "Callback[U]" | SyncCallable[U] | tuple[SyncCallable[U], ...] | ComplexTuple[U]
)


class Pipeline(t.Generic[T]):
    """Main pipeline class for composing data transformations.

    A Pipeline wraps a value and allows chaining transformations using
    operators `&` or methods (bind, apply, ensure).

    Supports both synchronous and asynchronous operations.

    Type Parameters:
        T: The type of value held in the pipeline.

    Example:
        >>> pipeline = let(5).bind(lambda x: x * 2).bind(lambda x: x + 10)
        >>> result = pipeline.run()
        >>> print(result)  # 20
    """

    @t.overload
    def __init__(self: "Pipeline[None]") -> None: ...

    @t.overload
    def __init__(self, value: T) -> None: ...

    def __init__(self, value: T | None = None):
        """Initialize a Pipeline with an optional starting value.

        Args:
            value: The initial value for the pipeline. Defaults to None.
        """
        self._callbacks: list[Callback[t.Any]] = []
        self._result = value
        self._allow_none = False
        self._is_async = False

    @property
    def is_async(self) -> bool:
        """Check if this pipeline contains any asynchronous operations.

        Returns:
            True if any callback in the pipeline is async, False otherwise.
        """
        return self._is_async

    def bind_callback(self, callback: Callback[U]) -> "Pipeline[U]":
        """Add a callback to the pipeline.

        Args:
            callback: The callback to add to the pipeline.

        Returns:
            Self for method chaining.
        """
        self._callbacks.append(callback)
        if not self._is_async and callback.is_async:
            self._is_async = True
        return t.cast("Pipeline[U]", self)

    @t.overload
    def bind(
        self,
        fn: BoundCallable[T, P, U],
        is_async: t.Literal[True],
        result_kw: OptionalStr = None,
        allow_none: OptionalBool = None,
        default: U | None = None,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> "Pipeline[U]": ...

    @t.overload
    def bind(
        self,
        coro: AsyncBoundCallable[T, P, U],
        is_async: t.Literal[True],
        result_kw: OptionalStr = None,
        allow_none: OptionalBool = None,
        default: U | None = None,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> "Pipeline[U]": ...

    @t.overload
    def bind(
        self,
        fn: SyncCallable[U],
        *args: t.Any,
        is_async: bool = False,
        result_kw: OptionalStr = None,
        allow_none: OptionalBool = None,
        default: U | None = None,
        **kwargs: t.Any,
    ) -> "Pipeline[U]": ...

    def bind(
        self,
        fn: t.Any,
        *args: t.Any,
        is_async: bool = False,
        result_kw: OptionalStr = None,
        allow_none: OptionalBool = None,
        default: t.Any | None = None,
        **kwargs: t.Any,
    ) -> "Pipeline[t.Any]":
        """Bind a transformation function to the pipeline.

        The function receives the current pipeline value as its first argument,
        and its return value becomes the new pipeline value.

        Args:
            fn: The transformation function.
            *args: Additional positional arguments for the function.
            is_async: If True, treat fn as async (default: False).
            result_kw: Pass pipeline result as this keyword argument (default: None).
            allow_none: If None, use pipeline's setting; if True/False,
                override whether None stops pipeline (default: None).
            default: Default value when result is None (default: None).
            **kwargs: Additional keyword arguments for the function.

        Returns:
            Self for method chaining.

        Example:
            >>> let(5).bind(lambda x: x * 2).run()
            10
        """
        self.bind_callback(
            bind(
                fn,
                *args,
                is_async=is_async,
                result_kw=result_kw,
                allow_none=allow_none,
                default=default,
                **kwargs,
            )
        )
        return self

    @t.overload
    def abind(
        self,
        coro: AsyncCallable[U],
        *args: t.Any,
        result_kw: OptionalStr = None,
        allow_none: OptionalBool = None,
        default: U | None = None,
        **kwargs: t.Any,
    ) -> "Pipeline[U]": ...

    @t.overload
    def abind(
        self,
        coro: AsyncBoundCallable[T, P, U],
        result_kw: OptionalStr = None,
        allow_none: OptionalBool = None,
        default: U | None = None,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> "Pipeline[U]": ...

    def abind(
        self,
        coro: AsyncCallable[U],
        *args: t.Any,
        result_kw: OptionalStr = None,
        allow_none: OptionalBool = None,
        default: U | None = None,
        **kwargs: t.Any,
    ) -> "Pipeline[T]":
        """Bind an asynchronous transformation function to the pipeline.

        Similar to bind() but for async functions.

        Args:
            coro: The async transformation function.
            *args: Additional positional arguments.
            result_kw: Pass pipeline result as this keyword argument (default: None).
            allow_none: If None, use pipeline's setting; if True/False,
                override whether None stops pipeline (default: None).
            default: Default value when result is None (default: None).
            **kwargs: Additional keyword arguments for the function.

        Returns:
            Self for method chaining.

        Example:
            >>> async def double(x):
            ...     return x * 2
            >>> await let(5).abind(double).arun()
            10
        """
        self.bind_callback(
            abind(
                coro,
                *args,
                result_kw=result_kw,
                allow_none=allow_none,
                default=default,
                **kwargs,
            )
        )
        return self

    @t.overload
    def apply(
        self,
        fn: BoundCallable[T, P, t.Any],
        is_async: bool = False,
        result_kw: OptionalStr = None,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> "Pipeline[T]": ...

    @t.overload
    def apply(
        self,
        coro: AsyncBoundCallable[T, P, t.Any],
        is_async: t.Literal[True],
        result_kw: OptionalStr = None,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> "Pipeline[T]": ...

    @t.overload
    def apply(
        self,
        fn: SyncCallable[U],
        *args: t.Any,
        is_async: bool = False,
        result_kw: OptionalStr = None,
        **kwargs: t.Any,
    ) -> "Pipeline[T]": ...

    def apply(
        self,
        fn: t.Any,
        *args: t.Any,
        is_async: bool = False,
        result_kw: OptionalStr = None,
        **kwargs: t.Any,
    ) -> "Pipeline[T]":
        """Apply a function for side effects without changing the pipeline value.

        The function is called with the current pipeline value, but its return
        value is discarded. The original pipeline value is preserved.

        Args:
            fn: The function to apply (for side effects).
            *args: Additional positional arguments.
            is_async: If True, treat fn as async (default: False).
            result_kw: Pass pipeline result as this keyword argument (default: None).
            **kwargs: Additional keyword arguments for the function.

        Returns:
            Self for method chaining.

        Example:
            >>> let(5).apply(print).bind(lambda x: x * 2).run()
            5
            10
        """
        self.bind_callback(apply(fn, *args, is_async=is_async, result_kw=result_kw, **kwargs))
        return self

    @t.overload
    def aapply(
        self,
        coro: AsyncCallable[U],
        *args: t.Any,
        result_kw: OptionalStr = None,
        **kwargs: t.Any,
    ) -> "Pipeline[T]": ...

    @t.overload
    def aapply(
        self,
        coro: AsyncBoundCallable[T, P, t.Any],
        result_kw: OptionalStr = None,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> "Pipeline[T]": ...

    def aapply(
        self, coro: AsyncCallable[U], *args: t.Any, result_kw: OptionalStr = None, **kwargs: t.Any
    ) -> "Pipeline[T]":
        """Apply an async function for side effects without changing the pipeline value.

        Similar to apply() but for async functions.

        Args:
            coro: The async function to apply.
            *args: Additional positional arguments.
            result_kw: Pass pipeline result as this keyword argument (default: None).
            **kwargs: Additional keyword arguments for the function.

        Returns:
            Self for method chaining.
        """
        self.bind_callback(aapply(coro, *args, result_kw=result_kw, **kwargs))
        return self

    @t.overload
    def ensure(self, value: bool, default: t.Any | None = None) -> "Pipeline[T]": ...

    @t.overload
    def ensure(
        self,
        predicate: t.Callable[..., bool],
        is_async: bool = False,
        result_kw: OptionalStr = None,
        default: t.Any | None = None,
        *args: t.Any,
        **kwargs: t.Any,
    ) -> "Pipeline[T]": ...

    @t.overload
    def ensure(
        self,
        predicate: AsyncCallable[U],
        *args: t.Any,
        is_async: t.Literal[True],
        result_kw: OptionalStr = None,
        default: U | None = None,
        **kwargs: t.Any,
    ) -> "Pipeline[T]": ...

    @t.overload
    def ensure(
        self,
        predicate: t.Callable[..., bool] | AsyncCallable[U],
        *args: t.Any,
        is_async: bool = False,
        result_kw: OptionalStr = None,
        default: U | None = None,
        **kwargs: t.Any,
    ) -> "Pipeline[T]": ...

    def ensure(
        self,
        value: t.Any,
        *args: t.Any,
        is_async: bool = False,
        result_kw: OptionalStr = None,
        default: t.Any | None = None,
        **kwargs: t.Any,
    ) -> "Pipeline[T]":
        """Ensure a condition is met, stopping the pipeline if not.

        If the predicate returns False, the pipeline stops and returns None.

        Args:
            value: Either a boolean value or a predicate function.
            *args: Additional positional arguments for the predicate.
            is_async: If True, treat as async function (default: False).
            result_kw: Pass pipeline result as this keyword argument (default: None).
            **kwargs: Additional keyword arguments for the predicate.

        Returns:
            Self for method chaining.

        Example:
            >>> let(10).ensure(lambda x: x > 5).run()
            10
            >>> let(3).ensure(lambda x: x > 5).run()
            None
        """
        self.bind_callback(
            ensure(value, *args, is_async=is_async, result_kw=result_kw, default=default, **kwargs)
        )
        return self

    @t.overload
    def aensure(
        self,
        coro: AsyncCallable[U],
        *args: t.Any,
        result_kw: OptionalStr = None,
        default: U | None = None,
        **kwargs: t.Any,
    ) -> "Pipeline[T]": ...

    @t.overload
    def aensure(
        self,
        coro: AsyncBoundCallable[T, P, t.Any],
        result_kw: OptionalStr = None,
        default: t.Any | None = None,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> "Pipeline[T]": ...

    def aensure(
        self,
        coro: AsyncCallable[U],
        *args: t.Any,
        result_kw: OptionalStr = None,
        default: U | None = None,
        **kwargs: t.Any,
    ) -> "Pipeline[T]":
        """Ensure a condition is met using an async predicate.

        Similar to ensure() but for async predicates.

        Args:
            coro: The async predicate function.
            *args: Additional positional arguments.
            result_kw: Pass pipeline result as this keyword argument (default: None).
            **kwargs: Additional keyword arguments for the predicate.

        Returns:
            Self for method chaining.
        """
        self.bind_callback(aensure(coro, *args, result_kw=result_kw, default=default, **kwargs))
        return self

    @t.overload
    def run(self, is_async: t.Literal[False] = False, allow_none: bool = False) -> T | None: ...
    @t.overload
    def run(self, is_async: t.Literal[True], allow_none: bool = False) -> t.Awaitable[T | None]: ...

    def run(
        self, is_async: bool = False, allow_none: bool = False
    ) -> t.Awaitable[T | None] | T | None:
        """Execute the pipeline.

        Runs all callbacks in sequence and returns the final result.

        Args:
            is_async: If True, force async execution. Defaults to False.
            allow_none: If True, allow None values to pass through. Defaults to False.

        Returns:
            The final pipeline value, or None if pipeline was stopped.

        Example:
            >>> let(5).bind(lambda x: x * 2).run()
            10
        """
        return self.arun(allow_none) if self._is_async or is_async else self._sync_run(allow_none)

    def _sync_run(self, allow_none: bool = False) -> T | None:
        """Internal synchronous execution."""
        self._allow_none = allow_none
        for callback in self._callbacks:
            callback.update_args_with_result(self._result)
            if not self._handle_callback_result(callback()):
                return None
        return self._result

    async def arun(self, allow_none: bool = False) -> T | None:
        """Execute the pipeline asynchronously.

        Runs all callbacks in sequence, awaiting async operations.

        Args:
            allow_none: If True, allow None values to pass through. Defaults to False.

        Returns:
            The final pipeline value, or None if pipeline was stopped.

        Example:
            >>> async def double(x):
            ...     return x * 2
            >>> await let(5).abind(double).arun()
            10
        """
        self._allow_none = allow_none
        for callback in self._callbacks:
            callback.update_args_with_result(self._result)
            if callback.is_async:
                result = await t.Awaitable[T | None], callback()
            else:
                result = callback()

            if not self._handle_callback_result(result):
                return None
        return self._result

    def _handle_callback_result(
        self, fn_type: CallbackType, result: t.Any, allow_none: OptionalBool
    ) -> bool:
        """Handle the result of a callback execution.

        Args:
            fn_type: The type of callback (BIND, APPLY, or ENSURE).
            result: The result returned by the callback.
            allow_none: Whether to allow None values.

        Returns:
            True to continue pipeline execution, False to stop.
        """
        _allow_none = self._allow_none if allow_none is None else allow_none

        if fn_type == CallbackType.BIND:
            if result is None and not _allow_none:
                return False

        elif fn_type == CallbackType.ENSURE:
            if not (r := bool(result)) and "default is not None":
                # self._result = "default"
                # return True
                pass
            return r

        elif fn_type == CallbackType.APPLY:
            return True

        else:
            raise ValueError(f"Unhandled CallbackType: {fn_type}")

        self._result = result
        return True

    @t.overload
    def result(
        self, is_async: t.Literal[False] = False, allow_none: bool = False
    ) -> Result[T | None]: ...
    @t.overload
    def result(
        self, is_async: t.Literal[True], allow_none: bool = False
    ) -> t.Awaitable[Result[T | None]]: ...

    def result(
        self, is_async: bool = False, allow_none: bool = False
    ) -> t.Awaitable[Result[T | None]] | Result[T | None]:
        """Execute the pipeline and return a Result object.

        Catches exceptions and wraps the result in a Result container.

        Args:
            is_async: If True, force async execution. Defaults to False.
            allow_none: If True, allow None values to pass through. Defaults to False.

        Returns:
            Result object containing either the value or an error.

        Example:
            >>> r = let(5).bind(lambda x: x * 2).result()
            >>> print(r.ok, r.value)
            True 10
        """
        return (
            self.aresult(allow_none)
            if self._is_async or is_async
            else self._sync_result(allow_none)
        )

    def _sync_result(self, allow_none: bool = False) -> Result[T | None]:
        """Internal synchronous result execution."""
        try:
            result = self._sync_run(allow_none)
            return Result[T | None].new_ok(result)
        except Exception as e:
            return Result[T | None].new_error(e)

    async def aresult(self, allow_none: bool = False) -> Result[T | None]:
        """Execute the pipeline asynchronously and return a Result object.

        Catches exceptions and wraps the result in a Result container.

        Args:
            allow_none: If True, allow None values to pass through.

        Returns:
            Result object containing either the value or an error.
        """
        try:
            result = await self.arun(allow_none)
            return Result[T | None].new_ok(result)
        except Exception as e:
            return Result[T | None].new_error(e)

    @t.overload
    def __and__(self, callback: Callback[T]) -> "Pipeline[T]": ...
    @t.overload
    def __and__(self, fn: SyncCallable[U]) -> "Pipeline[U]": ...
    @t.overload
    def __and__(self, args: tuple[SyncCallable[U], ...]) -> "Pipeline[U]": ...
    @t.overload
    def __and__(
        self,
        t: ComplexTuple[U],
    ) -> "Pipeline[U]": ...
    @t.overload
    def __and__(
        self,
        args: tuple[t.Literal[True], AsyncCallable[U], AnyTuple],
    ) -> "Pipeline[U]": ...

    def __and__(self, value: PipelineOperand[U]) -> "Pipeline[t.Any]":
        """Apply operator & for binding transformations to the pipeline.

        The & operator allows binding functions to the pipeline. It supports
        callbacks, functions, and tuples with arguments.

        Args:
            value: Can be one of:
                - A Callback object created with bind(), apply(), or ensure()
                - A synchronous callable function
                - A tuple (fn, *args) where fn is a function and args are arguments
                - A tuple (is_async, fn, args) where is_async is a boolean flag

        Returns:
            Self for method chaining with the transformation applied.

        Examples:
            >>> # Using with a simple function
            >>> (let(5) & (lambda x: x * 2)).run()
            10

            >>> # Using with function and arguments
            >>> (let(10) & (lambda x, y: x + y, 5)).run()
            15

            >>> # Using with a Callback object
            >>> callback = bind(lambda x: x ** 2)
            >>> let(3) & callback
            Pipeline[9]

            >>> # Using with async function (explicit flag)
            >>> import asyncio
            >>> async def multiply(x):
            ...     await asyncio.sleep(0.1)
            ...     return x * 3
            >>> asyncio.run((alet(4) & (True, multiply, ())).arun())
            12

            >>> # Chaining multiple operations
            >>> let(2) & (lambda x: x + 1) & (lambda x: x * 2) & (lambda x: x - 1)
            Pipeline[5]

        See Also:
            bind(): Method for explicit function binding
            apply(): Create callbacks for side effects
            ensure(): Create callbacks for validation
        """
        return self._handle_operator(value)

    @t.overload
    def __truediv__(self, callback: Callback[T]) -> "Pipeline[T]": ...
    @t.overload
    def __truediv__(self, fn: SyncCallable[U]) -> "Pipeline[U]": ...
    @t.overload
    def __truediv__(self, args: tuple[SyncCallable[U], ...]) -> "Pipeline[U]": ...
    @t.overload
    def __truediv__(
        self,
        args: ComplexTuple[U],
    ) -> "Pipeline[U]": ...
    @t.overload
    def __truediv__(  # pyright: ignore[reportOverlappingOverload]
        self,
        args: tuple[t.Literal[True], AsyncCallable[U], AnyTuple],
    ) -> "Pipeline[U]": ...

    def __truediv__(self, value: PipelineOperand[U]) -> "Pipeline[t.Any]":
        return self._handle_operator(value)

    @t.overload
    def __floordiv__(self, callback: Callback[U]) -> "Pipeline[U]": ...
    @t.overload
    def __floordiv__(self, coro: AsyncCallable[U]) -> "Pipeline[U]": ...
    @t.overload
    def __floordiv__(self, args: tuple[AsyncCallable[U], ...]) -> "Pipeline[U]": ...

    def __floordiv__(self, value: t.Any) -> "Pipeline[t.Any]":
        return self._handle_async_operator(value)

    def _handle_operator(self, value: PipelineOperand[U]) -> "Pipeline[U]":
        if isinstance(value, Callback):
            self.bind_callback(t.cast(Callback[U], value))
        elif isinstance(value, tuple):
            if isinstance(value[0], bool):
                if value[0]:
                    self.abind(t.cast(AsyncCallable[U], value[1]), *value[2:])
                else:
                    self.bind(t.cast(SyncCallable[U], value[1]), *value[2:])
            else:
                self.bind(t.cast(SyncCallable[U], value[0]), *value[1:])
        else:
            self.bind(value)
        return t.cast("Pipeline[U]", self)

    def _handle_async_operator(
        self, value: AsyncCallable[U] | AnyTuple | Callback[U]
    ) -> "Pipeline[U]":
        if isinstance(value, Callback):
            self.bind_callback(value)
        elif isinstance(value, tuple):
            coro = t.cast(AsyncCallable[U], value[0])
            args = t.cast(AnyTuple, value[1:])
            self.abind(coro, *args)
        else:
            self.abind(value)
        return t.cast("Pipeline[U]", self)

    def __repr__(self) -> str:
        return (
            f"Pipeline("
            f"result={self._result!r}, "
            f"callbacks={len(self._callbacks)}, "
            f"is_async={self._is_async}, "
            f"allow_none={self._allow_none})"
        )


@t.overload
def let(value: U | None = None) -> Pipeline[U]: ...


@t.overload
def let(
    fn: t.Callable[P, U],
    is_async: bool = False,
    result_kw: OptionalStr = None,
    allow_none: OptionalBool = None,
    default: U | None = None,
    *args: P.args,
    **kwargs: P.kwargs,
) -> Pipeline[U]: ...


@t.overload
def let(
    coro: t.Callable[P, t.Awaitable[U]],
    is_async: t.Literal[True],
    result_kw: OptionalStr = None,
    allow_none: OptionalBool = None,
    default: U | None = None,
    *args: P.args,
    **kwargs: P.kwargs,
) -> Pipeline[U]: ...


@t.overload
def let(
    fn: SyncCallable[U],
    *args: t.Any,
    is_async: bool = False,
    result_kw: OptionalStr = None,
    allow_none: OptionalBool = None,
    default: U | None = None,
    **kwargs: t.Any,
) -> Pipeline[U]: ...


def let(
    value: T | t.Callable[..., T] | None = None,
    *args: t.Any,
    is_async: bool = False,
    result_kw: OptionalStr = None,
    allow_none: OptionalBool = None,
    default: t.Any | None = None,
    **kwargs: t.Any,
) -> Pipeline[t.Any]:
    """Create a new pipeline with an initial value or function.

    This is the primary entry point for creating pipelines.

    Args:
        value: Either a value to wrap in a pipeline, or a function to call.
        *args: If value is a function, these are its positional arguments.
        is_async: If True, treat value as async function (default: False).
        result_kw: Pass pipeline result as this keyword argument (default: None).
        allow_none: If None, use default; if True/False, control
            whether None stops pipeline execution (default: None).
        default: Default value when result is None (default: None).
        **kwargs: If value is a function, these are its keyword arguments.

    Returns:
        A new Pipeline instance.

    Examples:
        >>> let(42).run()
        42
        >>> let(lambda: 10).run()
        10
        >>> let(lambda x, y: x + y, 5, 3).run()
        8
    """
    if not isinstance(value, t.Callable):
        return Pipeline(value)

    def wrapper(_: None, *a: t.Any, **kw: t.Any) -> T:
        return t.cast(T, value(*a, **kw))

    callback = _create_callback(
        fn_type=CallbackType.BIND,
        fn=wrapper,
        args=args,
        kwargs=kwargs,
        is_async=is_async,
        result_kw=result_kw,
        allow_none=allow_none,
        default=default,
    )
    return Pipeline().bind_callback(callback)


@t.overload
def alet(
    coro: t.Callable[P, t.Awaitable[U]],
    result_kw: OptionalStr = None,
    allow_none: OptionalBool = None,
    default: U | None = None,
    *args: P.args,
    **kwargs: P.kwargs,
) -> Pipeline[U]: ...


@t.overload
def alet(
    coro: AsyncCallable[U],
    *args: t.Any,
    result_kw: OptionalStr = None,
    allow_none: OptionalBool = None,
    default: U | None = None,
    **kwargs: t.Any,
) -> Pipeline[U]: ...


def alet(
    coro: AsyncCallable[U],
    *args: t.Any,
    result_kw: OptionalStr = None,
    allow_none: OptionalBool = None,
    default: U | None = None,
    **kwargs: t.Any,
) -> Pipeline[U]:
    """Create a new async pipeline with an initial async function.

    Similar to let() but for async functions.

    Args:
        coro: An async function to call.
        *args: Positional arguments for the function.
        result_kw: Pass pipeline result as this keyword argument (default: None).
        allow_none: If None, use default; if True/False, control
            whether None stops pipeline execution (default: None).
        default: Default value when result is None (default: None).
        **kwargs: Keyword arguments for the function.

    Returns:
        A new Pipeline instance marked as async.

    Example:
        >>> async def get_value():
        ...     return 42
        >>> await alet(get_value).arun()
        42
    """

    def wrapper(_: None, *a: t.Any, **kw: t.Any) -> t.Awaitable[U]:
        return coro(*a, **kw)

    callback = _create_async_callback(
        fn_type=CallbackType.BIND,
        coro=wrapper,
        args=args,
        kwargs=kwargs,
        result_kw=result_kw,
        allow_none=allow_none,
        default=default,
    )
    return Pipeline().bind_callback(callback)


@t.overload
def bind(
    fn: t.Callable[P, U],
    is_async: bool = False,
    result_kw: OptionalStr = None,
    allow_none: OptionalBool = None,
    default: U | None = None,
    *args: P.args,
    **kwargs: P.kwargs,
) -> Callback[U]: ...


@t.overload
def bind(
    coro: t.Callable[P, t.Awaitable[U]],
    is_async: t.Literal[True],
    result_kw: OptionalStr = None,
    allow_none: OptionalBool = None,
    default: U | None = None,
    *args: P.args,
    **kwargs: P.kwargs,
) -> Callback[U]: ...


@t.overload
def bind(
    fn: SyncCallable[U],
    *args: t.Any,
    is_async: bool = False,
    result_kw: OptionalStr = None,
    allow_none: OptionalBool = None,
    default: U | None = None,
    **kwargs: t.Any,
) -> Callback[U]: ...


def bind(
    value: t.Any,
    *args: t.Any,
    is_async: bool = False,
    result_kw: OptionalStr = None,
    allow_none: OptionalBool = None,
    default: t.Any | None = None,
    **kwargs: t.Any,
) -> Callback[t.Any]:
    """Create a bind callback for transforming pipeline values.

    Args:
        value: The transformation function.
        *args: Additional positional arguments.
        is_async: If True, treat as async function (default: False).
        result_kw: Pass pipeline result as this keyword argument (default: None).
        allow_none: If None, use pipeline's setting; if True/False,
            override whether None stops pipeline (default: None).
        default: Default value when result is None (default: None).
        **kwargs: Additional keyword arguments for the function.

    Returns:
        A Callback object that can be used with Pipeline.

    Examples:
        >>> # Basic transformation
        >>> let(5) & bind(lambda x: x * 2)
        Pipeline[10]

        >>> # With additional arguments
        >>> (let(10) & bind(lambda x, y: x + y, 5)).run()
        15

        >>> # Using result_kw for named parameter
        >>> pl = let(100) & bind(lambda base, value: base + value, result_kw="value", base=50)
        >>> pl.run()
        150
    """
    return _create_callback(
        fn_type=CallbackType.BIND,
        fn=value,
        args=args,
        kwargs=kwargs,
        is_async=is_async,
        result_kw=result_kw,
        allow_none=allow_none,
        default=default,
    )


@t.overload
def abind(
    coro: AsyncCallable[U],
    *args: t.Any,
    result_kw: OptionalStr = None,
    allow_none: OptionalBool = None,
    default: U | None = None,
    **kwargs: t.Any,
) -> Callback[U]: ...


@t.overload
def abind(
    coro: t.Callable[P, t.Awaitable[U]],
    result_kw: OptionalStr = None,
    allow_none: OptionalBool = None,
    default: U | None = None,
    *args: P.args,
    **kwargs: P.kwargs,
) -> Callback[U]: ...


def abind(
    coro: AsyncCallable[U],
    *args: t.Any,
    result_kw: OptionalStr = None,
    allow_none: OptionalBool = None,
    default: U | None = None,
    **kwargs: t.Any,
) -> Callback[U]:
    """Create an async bind callback for transforming pipeline values.

    Similar to bind() but for async functions.

    Args:
        coro: The async transformation function.
        *args: Additional positional arguments.
        result_kw: Pass pipeline result as this keyword argument (default: None).
        allow_none: If None, use pipeline's setting; if True/False,
            override whether None stops pipeline (default: None).
        default: Default value when result is None (default: None).
        **kwargs: Additional keyword arguments for the function.

    Returns:
        An async Callback object that can be used with Pipeline.

    Example:
        >>> async def double(x):
        ...     return x * 2
        >>> callback = abind(double)
        >>> await let(5).bind_callback(callback).arun()
        10
    """
    return _create_async_callback(
        fn_type=CallbackType.BIND,
        coro=coro,
        args=args,
        kwargs=kwargs,
        result_kw=result_kw,
        allow_none=allow_none,
        default=default,
    )


@t.overload
def apply(
    fn: t.Callable[P, U],
    is_async: bool = False,
    result_kw: OptionalStr = None,
    *args: P.args,
    **kwargs: P.kwargs,
) -> Callback[U]: ...


@t.overload
def apply(
    coro: t.Callable[P, t.Awaitable[U]],
    is_async: t.Literal[True],
    result_kw: OptionalStr = None,
    *args: P.args,
    **kwargs: P.kwargs,
) -> Callback[U]: ...


@t.overload
def apply(
    fn: SyncCallable[U],
    *args: t.Any,
    is_async: bool = False,
    result_kw: OptionalStr,
    **kwargs: t.Any,
) -> Callback[U]: ...


def apply(
    value: t.Any,
    *args: t.Any,
    is_async: bool = False,
    result_kw: OptionalStr = None,
    **kwargs: t.Any,
) -> Callback[t.Any]:
    """Create a apply callback for side effects without changing the pipeline
    value

    The function is called with the current pipeline value, but its return
    value is discarded. The original pipeline value is preserved.

    Args:
        fn: The function to apply (for side effects).
        *args: Additional positional arguments.
        is_async: If True, treat fn as async (default: False).
        result_kw: Pass pipeline result as this keyword argument (default: None).
        **kwargs: Additional keyword arguments for the function.

    Returns:
        Self for method chaining.

    Examples:
        >>> # Simple side effect - logging
        >>> (let(5) & apply(print) & bind(lambda x: x * 2)).run()
        5
        10

        >>> # Side effect with additional arguments
        >>> pl = let(42) & apply(print, "Value is:") & bind(lambda x: x + 1)
        >>> pl.run()
        Value is: 42
        43

        >>> # Using result_kw
        >>> def save_to_db(table, value):
        ...     print(f"Saving {value} to {table}")
        >>> let(100) & apply(save_to_db, result_kw="value", table="users")
        Saving 100 to users
        Pipeline[100]
    """

    return _create_callback(
        fn_type=CallbackType.APPLY,
        fn=value,
        args=args,
        kwargs=kwargs,
        is_async=is_async,
        result_kw=result_kw,
    )


@t.overload
def aapply(
    coro: AsyncCallable[U],
    *args: t.Any,
    result_kw: OptionalStr = None,
    **kwargs: t.Any,
) -> Callback[U]: ...


@t.overload
def aapply(
    coro: t.Callable[P, t.Awaitable[U]],
    result_kw: OptionalStr = None,
    *args: P.args,
    **kwargs: P.kwargs,
) -> Callback[U]: ...


def aapply(
    coro: AsyncCallable[U], *args: t.Any, result_kw: OptionalStr = None, **kwargs: t.Any
) -> Callback[U]:
    """Create an async apply callback for side effects.

    Similar to apply() but for async functions.

    Args:
        coro: The async function to execute for side effects.
        *args: Additional positional arguments.
        result_kw: Pass pipeline result as this keyword argument (default: None).
        **kwargs: Additional keyword arguments for the function.

    Returns:
        An async Callback object for side effects.
    """
    return _create_async_callback(
        fn_type=CallbackType.APPLY, coro=coro, args=args, kwargs=kwargs, result_kw=result_kw
    )


@t.overload
def ensure(value: bool, default: t.Any | None = None) -> Callback[t.Any]: ...


@t.overload
def ensure(
    predicate: t.Callable[P, bool],
    is_async: bool = False,
    result_kw: OptionalStr = None,
    default: t.Any | None = None,
    *args: P.args,
    **kwargs: P.kwargs,
) -> Callback[t.Any]: ...


@t.overload
def ensure(
    predicate: AsyncCallable[U],
    *args: t.Any,
    is_async: t.Literal[True],
    result_kw: OptionalStr,
    default: U | None = None,
    **kwargs: t.Any,
) -> Callback[U]: ...


@t.overload
def ensure(
    predicate: t.Callable[..., bool] | AsyncCallable[U],
    *args: t.Any,
    is_async: bool = False,
    result_kw: OptionalStr,
    default: U | None = None,
    **kwargs: t.Any,
) -> Callback[U]: ...


def ensure(
    value: t.Any,
    *args: t.Any,
    is_async: bool = False,
    result_kw: OptionalStr = None,
    default: t.Any | None = None,
    **kwargs: t.Any,
) -> Callback[t.Any]:
    """Create an ensure callback for validation.

    Ensure callbacks check if a condition is met. If False, the pipeline stops.

    Args:
        value: Either a boolean value or a predicate function.
        *args: Additional positional arguments for the predicate.
        is_async: If True, treat as async function (default: False).
        result_kw: Pass pipeline result as this keyword argument (default: None).
        **kwargs: Additional keyword arguments for the predicate.

    Returns:
        A Callback object for validation.

    Examples:
        >>> # Validation with predicate
        >>> (let(10) & ensure(lambda x: x > 5)).run()
        10

        >>> pl = let(3) & ensure(lambda x: x > 5)
        >>> pl.run()  # Stops pipeline, returns None
        None

        >>> # With additional arguments
        >>> let(15) & ensure(lambda x, min_val: x >= min_val, 10)
        Pipeline[15]

        >>> # Direct boolean value
        >>> let(42) & ensure(True)
        Pipeline[42]
    """
    if isinstance(value, t.Callable):
        f = t.cast(t.Callable[..., t.Any], value)
    else:

        def f(_: t.Any, *a: t.Any, **kw: t.Any) -> t.Any:
            return value

    return _create_callback(
        fn_type=CallbackType.ENSURE,
        fn=f,
        args=args,
        kwargs=kwargs,
        is_async=is_async,
        result_kw=result_kw,
        ensure_default=default,
    )


@t.overload
def aensure(
    coro: AsyncCallable[U],
    *args: t.Any,
    result_kw: OptionalStr = None,
    default: U | None = None,
    **kwargs: t.Any,
) -> Callback[U]: ...


@t.overload
def aensure(
    coro: t.Callable[P, t.Awaitable[U]],
    result_kw: OptionalStr = None,
    default: U | None = None,
    *args: P.args,
    **kwargs: P.kwargs,
) -> Callback[U]: ...


def aensure(
    coro: AsyncCallable[U],
    *args: t.Any,
    result_kw: OptionalStr = None,
    default: U | None = None,
    **kwargs: t.Any,
) -> Callback[U]:
    """Create an async ensure callback for validation.

    Similar to ensure() but for async predicates.

    Args:
        coro: The async predicate function.
        *args: Additional positional arguments.
        result_kw: Pass pipeline result as this keyword argument (default: None).
        **kwargs: Additional keyword arguments for the predicate.

    Returns:
        An async Callback object for validation.
    """
    return _create_async_callback(
        fn_type=CallbackType.ENSURE,
        coro=coro,
        args=args,
        kwargs=kwargs,
        result_kw=result_kw,
        ensure_default=default,
    )


def _create_callback(
    fn_type: CallbackType,
    fn: SyncCallable[U],
    args: AnyTuple,
    kwargs: AnyDict,
    is_async: bool = False,
    result_kw: OptionalStr = None,
    allow_none: OptionalBool = None,
    default: t.Any = None,
    ensure_default: t.Any = None,
) -> Callback[U]:
    if is_async:
        return _create_async_callback(
            fn_type=fn_type,
            coro=t.cast(AsyncCallable[U], fn),
            args=args,
            kwargs=kwargs,
            allow_none=allow_none,
            default=default,
            result_kw=result_kw,
            ensure_default=ensure_default,
        )
    return SyncCallback(
        fn_type=fn_type,
        fn=fn,
        args=args,
        kwargs=kwargs,
        allow_none=allow_none,
        default=default,
        result_kw=result_kw,
        ensure_default=ensure_default,
    )


def _create_async_callback(
    fn_type: CallbackType,
    coro: AsyncCallable[U],
    args: AnyTuple,
    kwargs: AnyDict,
    result_kw: OptionalStr = None,
    allow_none: OptionalBool = None,
    default: U | None = None,
    ensure_default: U | None = None,
) -> Callback[U]:
    return t.cast(
        Callback[U],
        AsyncCallback(
            fn_type=fn_type,
            fn=coro,
            args=args,
            kwargs=kwargs,
            allow_none=allow_none,
            default=default,
            result_kw=result_kw,
            ensure_default=ensure_default,
        ),
    )


__all__ = [
    "let",
    "alet",
    "bind",
    "abind",
    "ensure",
    "aensure",
    "apply",
    "aapply",
]
