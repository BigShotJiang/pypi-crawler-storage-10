import time
from datetime import datetime

from pyperly import let


def regular(n: int):
    x = n**n
    if x <= 1000:
        return

    datetime.now()
    _ = n * n * x


def pipe(n: int):
    let(n).bind(lambda it: it**it).ensure(lambda it: it > 1000).apply(lambda _: datetime.now()).bind(
        lambda x, y: x * y, n * n
    ).run()


def test():
    count = 5000
    for i in range(5000):
        regular(i)

    for _ in range(10):
        start = time.perf_counter()
        for i in range(count):
            regular(i)
        duration = time.perf_counter() - start
        print("regular", duration, round(duration * 1000 / count, 3))

    print("=" * 100)
    for i in range(5000):
        pipe(i)

    for _ in range(10):
        start = time.perf_counter()
        for i in range(count):
            pipe(i)
        duration = time.perf_counter() - start
        print("pipe", duration, round(duration * 1000 / count, 3))


if __name__ == "__main__":
    test()
