import time
from pyperly import let


def pipe():
    pass

def regular(n: int):
    let(n).bind(lambda it: it ** it).aapply()
    pass
