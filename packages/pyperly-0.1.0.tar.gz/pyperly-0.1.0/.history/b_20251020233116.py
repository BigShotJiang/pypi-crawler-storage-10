from datetime import datetime
import time

from pyperly import let


def regular(n: int):
    x = n**n
    if x <= 1000:
        return

    datetime.now()
    _ = n * n * x


def pipe(n: int):
    let(n).bind(lambda it: it**it).ensure(lambda it: it > 1000).apply(datetime.now).bind(
        lambda x, y: x * y, n * n
    ).run()


def test():
    for i in range(1000):
        pipe(i)
    for i in range(1000):
        regular(i)
    start = time.perf_counter()
