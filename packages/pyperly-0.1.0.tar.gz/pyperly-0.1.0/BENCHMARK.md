# pyperly Performance Benchmark

This document describes the performance benchmarks for the pyperly library and how to interpret the results.

## Running the Benchmark

```bash
python benchmark.py
```

## Benchmark Categories

### 1. Simple Transformation

Tests the overhead of a single operation (multiply by 2).

- **Vanilla**: Direct variable assignment
- **pyperly**: Using `let().bind()`

### 2. Chain of Transformations

Tests chained operations (3 operations: multiply, add, divide).

- **Vanilla**: Sequential variable assignments
- **pyperly**: Using `.bind()` chain
- **pyperly (/ operator)**: Using `/` operator for chaining

### 3. With Side Effects

Tests `apply()` for side effects without changing the pipeline value.

- **Vanilla**: Manual tracking of side effects
- **pyperly**: Using `.apply()` method

### 4. With Validation

Tests `ensure()` for validation predicates.

- **Vanilla**: Manual if-checks
- **pyperly**: Using `.ensure()` method

### 5. Complex Data Processing

Tests realistic data processing with dictionaries.

- **Vanilla**: Manual dict manipulation
- **pyperly**: Pipeline-based dict processing

### 6. List Processing

Tests processing lists of data.

- **Vanilla**: List comprehensions
- **pyperly**: Pipeline-based list processing

### 7. Simple Async Transformation

Tests async operations with a single transformation.

- **Vanilla**: Direct await
- **pyperly**: Using `.abind()`

### 8. Async Chain

Tests async chain of operations.

- **Vanilla**: Sequential awaits
- **pyperly**: Using `.abind()` chain
- **pyperly (// operator)**: Using `//` operator for async chaining

### 9. Mixed Sync/Async

Tests mixing synchronous and asynchronous operations.

- **Vanilla**: Mixed await and direct calls
- **pyperly**: Using both `.bind()` and `.abind()`

## Understanding the Results

### Overhead

The benchmark reports **overhead percentage**, which shows how much slower pyperly is compared to vanilla Python:

- **< 50%**: Excellent - minimal overhead
- **50-100%**: Good - acceptable for most use cases
- **100-200%**: Fair - noticeable but acceptable for readability benefits
- **> 200%**: High - consider vanilla Python for hot paths

### When to Use pyperly

Use pyperly when:

- ✅ Code readability is important
- ✅ Working with complex data transformations
- ✅ Need validation and error handling
- ✅ Building data pipelines
- ✅ Mixing sync/async operations

Use vanilla Python when:

- ❌ In performance-critical hot paths
- ❌ Simple, one-off transformations
- ❌ Every microsecond counts

### Performance Tips

1. **Operator chaining** (`/` and `//`) is generally as fast as method chaining
2. **Async operations** have similar overhead to sync operations
3. **Mixed sync/async** pipelines work efficiently without manual checking
4. The overhead is **constant per operation**, not proportional to data size

## Example Results

```
======================================================================
  pyperly Performance Benchmark
======================================================================

Comparing pyperly pipeline operations with vanilla Python
Times are in microseconds (μs). Lower is better.

======================================================================
  Synchronous Benchmarks (100,000 iterations)
======================================================================

1. Simple Transformation (multiply by 2):
  Vanilla Python                                           0.15 μs
  pyperly                                                  0.85 μs
  Overhead:                                              466.67%

2. Chain of Transformations (3 operations):
  Vanilla Python                                           0.25 μs
  pyperly                                                  1.75 μs
  pyperly (/ operator)                                     1.72 μs
  Overhead:                                              600.00%

...
```

## Notes

- Times are in **microseconds** (μs): 1 μs = 0.001 ms = 0.000001 s
- Lower times are better
- Overhead is calculated as: `((pyperly_time - vanilla_time) / vanilla_time) * 100`
- Results may vary based on hardware and Python version
- The benchmark uses 100,000 iterations for sync and 10,000 for async operations
