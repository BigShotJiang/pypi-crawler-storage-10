"""Quick test to verify benchmark works."""

from benchmark import (
    bench_chain_pyperly,
    bench_chain_vanilla,
    bench_simple_transform_pyperly,
    bench_simple_transform_vanilla,
)

print("Testing benchmark functions...")

# Test simple transform
print("1. Simple transform (vanilla):", bench_simple_transform_vanilla())
print("2. Simple transform (pyperly):", bench_simple_transform_pyperly())

# Test chain
print("3. Chain (vanilla):", bench_chain_vanilla())
print("4. Chain (pyperly):", bench_chain_pyperly())

print("\nAll benchmark functions work correctly!")
