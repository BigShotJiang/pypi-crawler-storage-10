# Tasks

## Backlog

[ ] tests
[ ] github rules
[ ] let: remove wrapper???

## Done

[x] ci test hook
[x] ci branch protect, need?
[x] readme
[-] pyi stubs
[x] fix mypy errors
[x] fix pre-commit errors
