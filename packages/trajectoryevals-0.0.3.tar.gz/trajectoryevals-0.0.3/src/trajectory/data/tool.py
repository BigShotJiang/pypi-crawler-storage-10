from trajectory.data.judgment_types import ToolJudgmentType


class Tool(ToolJudgmentType):
    pass
