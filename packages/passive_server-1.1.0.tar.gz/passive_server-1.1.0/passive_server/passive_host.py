# pylint: skip-file
"""这个类是 host 端 secs passive 服务的实现, 继承了 PassiveServer 类."""
import threading

from secsgem import secs
from secsgem.hsms import HsmsMessage

from passive_server import factory, passive_server, common_func


class HostPassive(passive_server.PassiveServer):
    """HostPassive class."""

    def __init__(self):
        """HostPassive 构造函数."""
        super().__init__()

        self.active_host = factory.get_active_host_instance(self.mysql_secs)
        self.active_host.logger.addHandler(self.file_handler)
        self._host_thread()

    def _host_thread(self):
        """Host 电脑的线程."""
        self.set_host_callback()
        threading.Thread(target=self.active_host.enable_host_handler, daemon=True).start()

    def set_host_callback(self):
        """设置监控到设备上报数据触发的回调函数."""
        for ip_port in self.active_host.passive_ips:
            for attribute_name in dir(self):
                if attribute_name.startswith("host_callback_"):
                    func_name = attribute_name.split("host_callback_")[-1]
                    self.active_host.set_call_back(ip_port, func_name, getattr(self, attribute_name))
                    self.active_host.set_receive_event_callback(ip_port, self.collection_event_received)

    def collection_event_received(self, data: dict):
        """接收到设备 secs 服务端上报的事件.

        Args:
            data: 事件信息
        """
        variables_value = []
        report_id = data["rptid"]
        ce_id = data["ceid"]
        ce_id_int = ce_id.get()
        equipment_info = data["peer"].settings
        self.logger.info("收到设备 %s:%s 上报的 %s 事件", equipment_info.address, equipment_info.port, ce_id_int)
        variable_values = data["values"]
        self.logger.info("报告 id: %s, 关联变量: %s", report_id, variable_values)
        for variable_info in variable_values:
            value = variable_info["value"]
            if isinstance(value, list):
                value = common_func.get_secs_array_value(value)
            variables_value.append(value)
        reports = [{"RPTID": report_id, "V": variables_value}]
        if event_received_callback := getattr(self, f"_on_event_{self.collection_events[ce_id_int].name}", None):
            event_received_callback(ce_id_int, reports)
        else:
            self.send_and_waitfor_response(
                self.stream_function(6, 11)({"DATAID": 1, "CEID": ce_id, "RPT": reports})
            )

    def host_callback_alarm_received(self, _, alarm_id, alarm_code, alarm_text):
        """接收到设备服务端的报警发给工厂.

        Args:
            _: handler.
            alarm_id: 报警 id.
            alarm_code: 报警 code.
            alarm_text: 报警内容.
        """
        del _
        self.send_and_waitfor_response(
            self.stream_function(5, 1)({"ALCD": alarm_code, "ALID": alarm_id, "ALTX": alarm_text})
        )
        return secs.data_items.ACKC5.ACCEPTED

    def s02f41_callback(self, message: HsmsMessage):
        """Host passive 收到工厂下发的 S2F41 回复 S2F42 后执行给设备 secs 服务下发 S2F41 的操作.

        Args:
            message: HsmsMessage 消息数据实例.
        """
        self._sf_callback(message)

    def s02f49_callback(self, message: HsmsMessage):
        """Host passive 收到工厂下发的 S2F49 回复 S2F50 后执行给设备 secs 服务下发 S2F49 的操作.

        Args:
            message: HsmsMessage 消息数据实例.
        """
        self._sf_callback(message)

    def s03f17_callback(self, message: HsmsMessage):
        """Host passive 收到工厂下发的 S3F17 回复 S3F18 后执行给设备 secs 服务下发 S3F17 的操作.

        Args:
            message: HsmsMessage 消息数据实例.
        """
        self._sf_callback(message)

    def _sf_callback(self, message: HsmsMessage):
        """Host passive 收到工厂下发的 S2F49 回复 S2F50 后执行给设备 secs 服务下发 S2F49 的操作.

        Args:
            message: HsmsMessage 消息数据实例.
        """
        sf_instance = self.settings.streams_functions.decode(message)
        data_dict = sf_instance.get()
        stream_num = message.header.stream
        function_num = message.header.function
        sf_name = f"s{stream_num}f{function_num}"
        self.logger.info("要下发给设备的流函数是: %s", sf_name)
        self.logger.info("要下发给设备的流函数数据是: %s", data_dict)
        if send_func := getattr(self.active_host, f"send_sf"):
            send_func(stream_num, function_num, data_dict)
