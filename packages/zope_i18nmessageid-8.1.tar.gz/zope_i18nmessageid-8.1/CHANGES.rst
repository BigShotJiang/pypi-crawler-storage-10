=========
 Changes
=========

8.1 (2025-10-29)
================

- Drop support for Python 3.9.

- Add support for Python 3.14.

- Remove run-time dependency on ``setuptools``.


8.0 (2025-09-12)
================

- Replace ``pkg_resources`` namespace with PEP 420 native namespace.

- Add preliminary support for Python 3.14 as of 3.14a4.

- Drop support for Python 3.8.

- Fix imports in ``setup.py``.
  (`#61 <https://github.com/zopefoundation/zope.i18nmessageid/issues/61>`_)

7.0 (2024-09-17)
================

- Drop support for Python 3.7.

- Build Windows wheels on GHA.

- Add support for Python 3.13.

- Enable multi-phase module initialization (PEP 489) for all supported
  Python versions.  See this "how-to" doc for rationale and steps:
  https://docs.python.org/3.13/howto/isolating-extensions.html

- Make the ``hookable`` extension type heap-allocated for Python >= 3.9.
  Likewise, see the doc above for rationale and steps.  For Python < 3.9,
  the ``hookable`` extension type continues to be allocated statically,
  even though the module itself is allocated dynamically.


6.1.0 (2023-10-05)
==================

- Add support for Python 3.12.


6.0.1 (2023-03-24)
==================

- Drop dependency on ``six``.


6.0.0 (2023-03-23)
==================

- Drop support for Python 2.7, 3.5, 3.6.

- Add preliminary support for Python 3.12a5.


5.1.1 (2022-11-17)
==================

- Add support for building arm64 wheels on macOS.


5.1.0 (2022-11-06)
==================

- Added support for Python 3.9, 3.10 and 3.11.


5.0.1 (2020-03-10)
==================

- Remove deprecated use of setuptools features.  See `issue 22
  <https://github.com/zopefoundation/zope.i18nmessageid/issues/22>`_.


5.0.0 (2019-11-12)
==================

- Drop support for Python 3.4.

- Add support for Python 3.8.


4.3.1 (2018-10-19)
==================

- Fix a regression copying Message objects in the Python
  implementation. See `issue 14
  <https://github.com/zopefoundation/zope.i18nmessageid/issues/14>`_.


4.3.0 (2018-10-18)
==================

- Add attributes to support pluralization on a Message and update the
  MessageFactory accordingly.


4.2.0 (2018-10-05)
==================

- Fix the possibility of a rare crash in the C extension when
  deallocating items. See `issue 7
  <https://github.com/zopefoundation/zope.i18nmessageid/issues/7>`_.

- Drop support for Python 3.3.

- Add support for Python 3.7.


4.1.0 (2017-05-02)
==================

- Drop support for Python 2.6 and 3.2.

- Add support for Python 3.5 and 3.6.

- Fix the C extension not being used in Python 3. See `issue 4
  <https://github.com/zopefoundation/zope.i18nmessageid/issues/4>`_.

- Make the Python implementation of Message accept any object for the
  ``default`` argument, just as the C extension does. This should be a
  unicode or byte string. See `issue 5
  <https://github.com/zopefoundation/zope.i18nmessageid/issues/5>`_.

4.0.3 (2014-03-19)
==================

- Add support for Python 3.4.

- Update ``boostrap.py`` to version 2.2.

4.0.2 (2012-12-31)
==================

- Flesh out PyPI Trove classifiers.

4.0.1 (2012-11-21)
==================

- Add support for Python 3.3.

4.0.0 (2012-05-16)
==================

- Automate generation of Sphinx HTML docs and running doctest snippets via tox.

- Remove use of '2to3' and associated fixers when installing under Py3k.
  The code is now in a "compatible subset" which supports Python 2.6, 2.7,
  and 3.2, including PyPy 1.8 (the version compatible with the 2.7 language
  spec).

- Bring unit test coverage to 100%.

- Move doctest examples into Sphinx documentation.

- Drop explicit support for Python 2.4 / 2.5 / 3.1.

- Add explicit support for PyPy.

- Add 'setup.py dev' alias (runs ``setup.py develop`` plus installs
  ``nose`` and ``coverage``).

- Add 'setup.py docs' alias (installs ``Sphinx`` and dependencies).


3.6.1 (2011-07-20)
==================

- Correct metadata in this file for release date.

3.6.0 (2011-07-20)
==================

- Python 3 support.

- Suppress compiling C extensions on PyPy or Jython.

- Add a tox.ini (see http://tox.readthedocs.org/en/latest/) for easier
  automated testing.

3.5.3 (2010-08-10)
==================

- Make compilation of C extension optional again; 3.5.1 broke this
  inasmuch as this package become unusable on non-CPython platforms.
  Making the compilation of the C extension optional again implied
  removing ``setup.py`` code added in 3.5.1 which made the C extension
  a setuptools "Feature" and readding code from 3.5.0 which overrides
  the distutils ``build_ext`` command.

- Move pickle equality tests into a unittest.TestCase test to make it
  easier to condition the tests on whether the C extension has been
  compiled.  This also makes the tests pass on Jython.

3.5.2 (2010-04-30)
==================

- Remove use of 'zope.testing.doctestunit' in favor of stdlib's 'doctest.

3.5.1 (2010-04-10)
==================

- LP #257657 / 489529:  Fix memory leak in C extension.

- Fix the compilation of the C extension with python 2.6: refactored it as a
  setuptools Feature.

3.5.0 (2009-06-27)
==================

- Make compilation of C extension optional.

- Add support to bootstrap on Jython.

- Change package's mailing list address from zope3-dev at zope.org to
  zope-dev at zope.org, because zope3-dev is now retired.

- Reformat change log to common formatting style.

- Update package description and docs a little.

- Remove old .cfg files for zpkg.

3.4.3 (2007-09-26)
==================

- Make PyPI the home URL.

3.4.2 (2007-09-25)
==================

- Move the ``ZopeMessageFactory`` from ``zope.app.i18n`` to this package.

3.4.0 (2007-07-19)
==================

- Remove incorrect dependency.

- Create final release to reflect package status.

3.2.0 (2006-01-05)
==================

- Corresponds to the verison of the zope.i18nmessageid package shipped as
  part of the Zope 3.2.0 release.

- Implement 'zope.i18nmessageid.message' as a C extension.

- Deprecate 'zope.i18nmessageid.messageid' APIs ('MessageID',
  'MessageIDFactory') in favor of replacements in 'zope.i18nmessageid.message'
  ('Message', 'MessageFactory').  Deprecated items are scheduled for removal
  in Zope 3.3.

3.0.0 (2004-11-07)
==================

- Corresponds to the verison of the zope.i18nmessageid package shipped as
  part of the Zope X3.0.0 release.
