⚠️ THIS PROJECT 'nvidia-cuda-cupti-cu13' IS DEPRECATED.
Please use 'nvidia-cuda-cupti' instead.

To install the correct package, use:

    pip install nvidia-cuda-cupti

For more information, visit: https://pypi.org/project/nvidia-cuda-cupti/
