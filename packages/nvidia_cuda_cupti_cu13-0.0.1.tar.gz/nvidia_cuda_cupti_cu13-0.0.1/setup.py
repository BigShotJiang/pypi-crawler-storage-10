import sys
from setuptools import setup

ERROR_MESSAGE = '''⚠️ THIS PROJECT 'nvidia-cuda-cupti-cu13' IS DEPRECATED.
Please use 'nvidia-cuda-cupti' instead.

To install the correct package, use:

    pip install nvidia-cuda-cupti

For more information, visit: https://pypi.org/project/nvidia-cuda-cupti/

'''

if any(arg in sys.argv for arg in ('bdist_wheel', 'bdist', 'wheel')):
    print(ERROR_MESSAGE, file=sys.stderr)
    sys.exit(1)

setup()
