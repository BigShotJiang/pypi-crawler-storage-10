import argparse as ap
import os
import sys
import time
import subprocess
import shutil 
from subprocess import PIPE
from tqdm import tqdm

# Main function
def main():
    # Parse command line arguments
    parser = ap.ArgumentParser(description="Automate COBOL documentation generation using Copilot.")
    parser.add_argument("-p","--Prompt",type=str,help="Prompt directory for Copilot to generate documentation.")
    parser.add_argument("-c","--Cobol",type=str,help="COBOL source code directory OR File to be documented.")
    parser.add_argument("-o","--Output",type=str,help="Output directory for generated documentation.")
    args = parser.parse_args()

    # Create variables for paths and validate them
    prompt_path = args.Prompt
    cobol_path = args.Cobol
    output_path = args.Output

    if not os.path.exists(prompt_path):
        print(f"Error: Prompt path '{prompt_path}' does not exist.")
        sys.exit(1)
    
    if not os.path.exists(cobol_path):
        print(f"Error: COBOL path '{cobol_path}' does not exist.")
        sys.exit(1)
    
    if output_path is None:
        output_path = os.path.join(os.getcwd(), "Cobol_Documentation_Output")
        print(f"No output path provided. Using default: '{output_path}'")
    
    if not os.path.exists(output_path):
        os.makedirs(output_path)
        print(f"Created output directory at '{output_path}'.")
    
    # Finally check if we can find the copilot command and run it
    if shutil.which("copilot") is None:
        print("Error: 'copilot' command not found. Please ensure Copilot is installed and in your PATH.")
        sys.exit(1)
    
    print("Validation steps completed successfully. Moving to documentation generation...")

    # PROCESS SINGLE FILE ELSE DIRECTORY
    if os.path.isfile(cobol_path):
        print("Processing single COBOL file...")
        process_cobol_file(cobol_path, prompt_path, output_path)
    else:
        # First, collect all COBOL files to get total count
        cobol_files = []
        for root, _, files in os.walk(cobol_path):
            for file in files:
                if file.lower().endswith(".cbl") or file.lower().endswith(".cob"):
                    cobol_file_path = os.path.join(root, file)
                    cobol_files.append(cobol_file_path)
        
        if not cobol_files:
            print(f"No COBOL files found in '{cobol_path}'.")
            return
        
        print(f"Found {len(cobol_files)} COBOL file(s) to process...")
        
        # Process files with progress bar
        for cobol_file_path in tqdm(cobol_files, desc="Processing COBOL files", unit="file"):
            process_cobol_file(cobol_file_path, prompt_path, output_path)
    print("Documentation generation completed.")


def process_cobol_file(cobol_file_path, prompt_path, output_path):
    # Get base filename for cleaner progress display
    file_name = os.path.basename(cobol_file_path)
    
    # Grab our prompts
    prompt_files = [file for file in os.listdir(prompt_path) if file.endswith(".txt")]
    
    if not prompt_files:
        print(f"No prompt files found in '{prompt_path}'. Skipping file.")
        return
    
    # Process each prompt file with progress bar
    for prompt_file in tqdm(prompt_files, desc=f"Processing {file_name}", unit="prompt", leave=False):
        prompt_file_path = os.path.join(prompt_path, prompt_file)
        with open(prompt_file_path, 'r') as pf:
            prompt_content = pf.read()
        
        final_prompt = f"{prompt_content}. Please generate documentation for the following COBOL code:{cobol_file_path}"
        # Construct the copilot command
        command = shutil.which("copilot")
        print(command)
        cmd = [command, "-p", final_prompt, "--allow-all-tools"]
        
        # Execute the command
        process = subprocess.Popen(cmd, stdout=PIPE, stderr=PIPE)
        stdout, stderr = process.communicate()

        # write the output to the output file
        output_file_name = f"{os.path.basename(cobol_file_path)}_{os.path.splitext(prompt_file)[0]}_documentation.txt"
        output_file_path = os.path.join(output_path, output_file_name)
        with open(output_file_path, 'wb') as out_file:
            out_file.write(stdout)
        
        if process.returncode != 0:
            tqdm.write(f"Error generating documentation for '{cobol_file_path}' with prompt '{prompt_file}': {stderr.decode()}")
        else:
            tqdm.write(f"Successfully generated documentation for '{file_name}' with prompt '{prompt_file}'.")

if __name__ == "__main__":
    main()