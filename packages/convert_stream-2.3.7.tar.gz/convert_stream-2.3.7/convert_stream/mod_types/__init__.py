#!/usr/bin/env python3
#
from __future__ import annotations
from hashlib import md5 as md5_hash
from io import BytesIO
from soup_files import File
from .enums import (
    RotationAngle, ColumnsTable, LibImage, LibPdfToImage, LibPDF, LibImageToPdf, LibDate
)

from .table_types import (
    TextTable, ListString, ArrayString, HeadCell, HeadValues,
    ColumnBody, create_void_dict_map, create_dict_map_values, create_void_df_map,
    create_dict_map_from_file, concat_maps, contains, get_text_from_file
)


def get_hash_from_bytes(bt: BytesIO | bytes) -> str:
    if isinstance(bt, BytesIO):
        return md5_hash(bt.getvalue()).hexdigest().upper()
    elif isinstance(bt, bytes):
        return md5_hash(bt).hexdigest().upper()
    else:
        raise TypeError(f"Unsupported type {type(bt)}")


class MetaDataItem(str):

    def __init__(self, text: str = 'nan'):
        super().__init__()
        self.text: str = text

    @property
    def is_empty(self) -> bool:
        return self.text == 'nan'


class MetaDataFile(object):

    def __init__(
                self, *,
                file_path: MetaDataItem = MetaDataItem(),
                dir_path: MetaDataItem = MetaDataItem(),
                name: MetaDataItem = MetaDataItem(),
                md5: MetaDataItem = MetaDataItem(),
                size: MetaDataItem = MetaDataItem(),
                extension: MetaDataItem = MetaDataItem(),
                origin_src: MetaDataItem = MetaDataItem(),
            ):
        self.file_path: MetaDataItem = file_path
        self.dir_path: MetaDataItem = dir_path
        self.name: MetaDataItem = name
        self.md5: MetaDataItem = md5
        self.size: MetaDataItem = size
        self.extension: MetaDataItem = extension
        self.origin_src: MetaDataItem = origin_src

    def to_dict(self) -> dict[str, str | None]:
        return {
            'file_path': self.file_path if not self.file_path.is_empty else None,
            'dir_path': self.dir_path if not self.dir_path.is_empty else None,
            'name': self.name if not self.name.is_empty else None,
            'md5': self.md5 if not self.md5.is_empty else None,
            'size': self.size if not self.size.is_empty else None,
            'extension': self.extension if not self.extension.is_empty else None,
            'origin_src': self.origin_src if not self.origin_src.is_empty else None,
        }


def get_void_metadata() -> dict[str, str | None]:
    """
        Salvar os metadados básico de documentos/imagens lidas em disco.
    """
    return MetaDataFile().to_dict()


def create_metadata(file: str | File) -> MetaDataFile:
    if isinstance(file, str):
        file = File(file)
    mt = MetaDataFile(
        file_path=MetaDataItem(file.absolute()),
        dir_path=MetaDataItem(file.dirname()),
        extension=MetaDataItem(file.extension()),
        origin_src=MetaDataItem('file'),
        name=MetaDataItem(file.name()),
    )
    if file.exists():
        mt.size = MetaDataItem(file.size())
        mt.md5 = MetaDataItem(file.md5())
    return mt


__all__ = [
    'get_hash_from_bytes', 'get_void_metadata', 'get_void_metadata', 'contains',
    'concat_maps', 'create_dict_map_from_file', 'create_dict_map_values',
    'create_void_df_map', 'create_void_dict_map', 'ColumnBody', 'ColumnsTable',
    'ListString', 'HeadCell', 'HeadValues', 'TextTable', 'RotationAngle', 'LibPDF',
    'LibImageToPdf', 'LibPdfToImage', 'LibImage', 'LibDate', 'ArrayString',
    'MetaDataFile', 'MetaDataItem', 'create_metadata',
]
