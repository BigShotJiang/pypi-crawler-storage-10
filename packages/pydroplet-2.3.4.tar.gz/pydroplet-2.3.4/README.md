# pydroplet

This is a package to interface with the [Droplet](https://shop.hydrificwater.com/pages/buy-droplet) device.

## Getting Started
Install the package from [PyPI](https://pypi.org/project/pydroplet/).
```
pip install pydroplet
```
See the `examples` directory to get started.