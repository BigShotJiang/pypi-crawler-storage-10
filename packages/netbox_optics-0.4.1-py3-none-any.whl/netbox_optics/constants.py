NAMESPACE = "netbox_optics"
MUX_ROLE_SLUG = "mux"
