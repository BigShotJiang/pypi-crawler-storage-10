from setuptools import setup, find_packages

setup(
    name="protein_network",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        "networkx",
        "matplotlib",
        "pandas",
    ],
    author="Sarah Ali",
    description="A library to analyze and visualize protein networks",
)
