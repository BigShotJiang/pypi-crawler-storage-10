"""Package for result backends."""
