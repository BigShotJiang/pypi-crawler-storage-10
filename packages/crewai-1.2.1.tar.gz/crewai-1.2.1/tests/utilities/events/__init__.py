"""Tests for events."""
