"""Tests for memory."""
