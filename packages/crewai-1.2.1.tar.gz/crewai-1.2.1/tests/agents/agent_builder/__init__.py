"""Tests for agent builder."""
