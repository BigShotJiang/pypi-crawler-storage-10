# perfnexus

[![PyPI - Version](https://img.shields.io/pypi/v/perfnexus.svg)](https://pypi.org/project/perfnexus)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/perfnexus.svg)](https://pypi.org/project/perfnexus)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install perfnexus
```

## License

`perfnexus` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
