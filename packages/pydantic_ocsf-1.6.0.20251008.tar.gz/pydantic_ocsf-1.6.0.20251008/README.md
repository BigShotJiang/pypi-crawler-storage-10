# Pydantic OCSF

## Description

A collection of [Pydantic](https://docs.pydantic.dev/latest/) models for [OCSF](https://schema.ocsf.io/) events and objects.

## License

This project is licensed under the MIT license. See the license file for details.