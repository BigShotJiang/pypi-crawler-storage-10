import argparse
import asyncio
import json
import logging
import re
from urllib.parse import urljoin

import requests
import websockets
import websockets.typing
from bs4 import BeautifulSoup, Tag
from websockets.extensions import permessage_deflate

from ibuk_dl_uam.yeast import yeast


class BookMetadata:
    def __init__(self, data) -> None:
        self._data = data
        self.author: str = data["author"]
        self.index: int = data["index"]
        self.isbn: str = data["isbn"]
        self.pages: str = data["pages"]
        self.publisher: str = data["redaction"]
        self.slugged_title: str = data["slugged_title"]
        self.title: str = data["title"]
        self.description: str = data["review"]


class IbukConstants:
    BASE_URL = "https://libra.ibuk.pl/"
    BASE_AUTH_URL = "https://login.han.amu.edu.pl/hhauth/login"
    BASE_HAN_URL = "https://han.amu.edu.pl/han/ibuk-libra/https/libra.ibuk.pl/"
    BASE_WS_URL = "libra23.ibuk.pl"


class IbukWebSession(requests.Session):
    def __init__(self, api_key=None) -> None:
        super().__init__()

        self._api_key = api_key

    def api_key(self) -> str:
        if self._api_key is not None:
            return self._api_key

        r = self.get(IbukConstants.BASE_URL)
        assert r.status_code == 200

        self._api_key = self.cookies["ilApiKey"]
        return self._api_key

    def login_uam(self, username, password):
        logging.info("Logging in with UAM")
        data = {
            "plainuser": username,
            "password": password,
            "auth": "auto",
            "Service": "",
            "user": username
        }
        # Disable SSL verification for the authentication endpoint
        # This is necessary because institutional authentication systems
        # often have certificate chain issues

        auth_request = self.post(
            IbukConstants.BASE_AUTH_URL,
            data=data,
            verify=False,
            allow_redirects=False
        )

        logging.info(f"Auth request status: {auth_request.status_code}")

        # Follow the redirect chain manually to capture all cookies
        if auth_request.status_code in (301, 302, 303, 307, 308):
            redirect_url = auth_request.headers.get("Location")
            if redirect_url:
                # Convert relative URLs to absolute URLs
                absolute_redirect_url = urljoin(IbukConstants.BASE_AUTH_URL, redirect_url)
                logging.info(f"Following redirect to: {absolute_redirect_url}")
                redirect_response = self.get(
                    absolute_redirect_url,
                    allow_redirects=True,  # Allow redirects on this step
                    verify=False,
                )
                logging.info(f"Redirect response status: {redirect_response.status_code}")

        # Access the HAN URL to complete authentication and get the API key
        han_request = self.get(IbukConstants.BASE_HAN_URL, verify=False, allow_redirects=True)
        logging.info(f"HAN request status: {han_request.status_code}")
        assert han_request.status_code == 200

        # Debug: Print all cookies
        logging.debug(f"Available cookies: {list(self.cookies.keys())}")

        # Extract the API key from cookies after successful authentication
        # Check multiple possible cookie name formats
        if "ilApiKey" in self.cookies:
            self._api_key = self.cookies["ilApiKey"]
            logging.debug("API key extracted from 'ilApiKey' cookie")
        elif "libra.ibuk.pl/@ilApiKey" in self.cookies:
            self._api_key = self.cookies["libra.ibuk.pl/@ilApiKey"]
            logging.info("API key extracted from 'libra.ibuk.pl/@ilApiKey' cookie")
        else:
            # Try to find any cookie with 'ApiKey' in the name
            api_key_cookies = [k for k in self.cookies.keys() if 'apikey' in k.lower()]
            if api_key_cookies:
                self._api_key = self.cookies[api_key_cookies[0]]
                logging.debug(f"API key extracted from '{api_key_cookies[0]}' cookie")
            else:
                logging.error(f"Available cookies: {dict(self.cookies)}")
                raise RuntimeError(
                    "Failed to extract API key from cookies after authentication. "
                    f"Available cookies: {list(self.cookies.keys())}"
                )

        logging.info("Successfully authenticated and obtained API key")

    def get_book_metadata(self, url):
        r = self.get(url, verify=False, allow_redirects=True)
        assert r.status_code == 200

        soup = BeautifulSoup(r.text, "html.parser")
        page_state = soup.find("script", {"id": "app-libra-2-state"})
        assert type(page_state) is Tag

        # clean up encoding
        page_state = json.loads(str(page_state.contents[0]).replace("&q;", '"'))
        return BookMetadata(page_state["DETAILS_CACHE_KEY"])


class IbukWebSocketSession:
    def __init__(
            self, api_key: str, cookies: dict = None, socket_io_base_url=None
    ) -> None:
        self._api_key = api_key
        self._cookies = cookies or {}
        if socket_io_base_url is None:
            socket_io_base_url = f"{IbukConstants.BASE_WS_URL}/socket.io"
        self._socket_io_base_url = socket_io_base_url

    async def _connect(self):
        self.sid = self._create_session()
        logging.debug(f"Session ID: {self.sid}")

        # Prepare cookie header if cookies are available
        extra_headers = {
            "Pragma": "no-cache",
            "Cache-Control": "no-cache",
            "Accept-Language": "en-GB,en;q=0.9",
        }

        if self._cookies:
            cookie_str = "; ".join([f"{k}={v}" for k, v in self._cookies.items()])
            extra_headers["Cookie"] = cookie_str

        # noinspection PyTypeChecker
        self.ws = await websockets.connect(
            f"wss://{self._socket_io_base_url}/?apiKey={self._api_key}&isServer=0&EIO=4&transport=websocket&sid={self.sid}",
            max_size=None,
            additional_headers=extra_headers,
            extensions=[permessage_deflate.ClientPerMessageDeflateFactory(client_max_window_bits=True)],
            origin="https://han.amu.edu.pl",
            user_agent_header="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        )
        print(f"WebSocket connected: {self.ws}")

        await self._hello()

    async def __aenter__(self):
        await self._connect()
        return self

    async def __aexit__(self, *_):
        await self.close()

    def _create_session(self) -> str:
        # Create a request session with cookies if available
        import requests
        session = requests.Session()
        if self._cookies:
            session.cookies.update(self._cookies)

        r = session.get(
            f"https://{self._socket_io_base_url}/",
            params={
                "apiKey": self._api_key,
                "isServer": "0",
                "EIO": "4",
                "transport": "polling",
                "t": yeast(),
            },
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                "Referer": "https://libra.ibuk.pl/",
                "Origin": "https://han.amu.edu.pl",
                "Accept": "*/*",
                "Accept-Language": "en-GB,en;q=0.9",
                "Cache-Control": "no-cache",
                "Pragma": "no-cache",
            }
        )

        if r.status_code != 200:
            logging.error(f"Failed to create Socket.IO session: HTTP {r.status_code}")
            logging.error(f"Response: {r.text}")
            raise RuntimeError(f"Failed to create Socket.IO session: HTTP {r.status_code}\nResponse: {r.text}")

        return json.loads(r.text[1:])["sid"]

    async def close(self):
        await self.ws.close()

    async def _hello(self):
        await self.ws.send("2probe")
        assert await self.ws.recv() == "3probe"

        await self.ws.send("5")

        await self.ws.send("40/books,")
        assert "40/books," in str(await self.ws.recv())

        # Consume the "ready" message that comes after connecting to the namespace
        ready_msg = await self.ws.recv()
        if '42/books,["ready"' not in str(ready_msg):
            logging.warning(f"Expected ready message, got: {ready_msg}")

    async def _handle_recv(self):
        while True:
            msg = str(await self.ws.recv())
            if msg == "2":
                await self.ws.send("3")
            else:
                return msg

    async def get_page(self, book_id, page: int) -> str:
        await self.ws.send(
            f"""42/books,["page","{{\\"bookId\\":{book_id},\\"compressed\\":10,\\"format\\":\\"html\\",\\"pagenumber\\":{page},\\"fontSize\\":12,\\"pageNumber\\":{page},\\"compression\\":10,\\"type\\":\\"standard\\",\\"width\\":716}}"]"""
        )
        r = await self._handle_recv()

        data = json.loads(json.loads(r.split("42/books,")[1])[1])
        if data.get("error", False):
            logging.error(f"encountered while fetching page {page}: {data.get('message', '')}")
            raise PermissionError("Error while fetching page")
        return data["html"]

    async def get_css(self, book_id):
        await self.ws.send(
            f"""42/books,["css","{{\\"bookId\\":{book_id},\\"width\\":839,\\"fontSize\\":15.04}}"]"""
        )
        r = await self._handle_recv()

        return json.loads(json.loads(r.split("42/books,")[1])[1])["html"]

    async def get_fonts(self, book_id):
        await self.ws.send(f"""42/books,["font","{{\\"bookId\\":{book_id}}}"]""")
        r = await self._handle_recv()
        print(r)
        fonts = json.loads(json.loads(r.split("42/books,")[1])[1])["html"]

        # According to the spec[1], url is followed by format WITHOUT a semicolon,
        # so we patch it
        # [1]: https://developer.mozilla.org/en-US/docs/Web/CSS/@font-face/src
        fonts = re.sub("; format", " format", fonts)
        return fonts

    async def get_book_html(self, book_id, page_n: int) -> str:
        fonts = await self.get_fonts(book_id)
        style = await self.get_css(book_id)
        pages = []
        for i in range(1, page_n + 1):
            logging.info(f"Getting page {i}")
            try:
                page = await self.get_page(book_id, i)
            except PermissionError:
                break
            pages.append(page)

        pages = "\n".join(pages)
        html = f"""
                <!DOCTYPE html>
                <html lang="en">
                    <head>
                        <title></title>
                        <meta charset="UTF-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1">
                        <style>{style}</style>
                        <style id='font-style'>{fonts}</style>
                    </head>
                    <body>
                    {pages}
                    </body>
                </html>"""

        return html


async def download_action(
        url: str, page_count: int | None, ibs: IbukWebSession, output):
    import os

    logging.info(f"Fetching book from URL: {url}")
    book_metadata = ibs.get_book_metadata(url)

    if not page_count:
        page_count = int(book_metadata.pages)

    logging.info(f"Downloading {book_metadata.author} - {book_metadata.title}")

    # Pass the session cookies to the WebSocket session
    cookies_dict = {cookie.name: cookie.value for cookie in ibs.cookies}
    logging.debug(f"Passing cookies to WebSocket: {list(cookies_dict.keys())}")

    async with IbukWebSocketSession(ibs.api_key(), cookies=cookies_dict) as ibws:
        # Get fonts and CSS once for all pages
        fonts = await ibws.get_fonts(book_metadata.index)
        style = await ibws.get_css(book_metadata.index)

        # Create folder name from book title (sanitize for filesystem)
        folder_name = re.sub(r'[<>:"/\\|?*]', '_', f"{book_metadata.author} - {book_metadata.title}")

        # Original HTML output mode
        # If output is specified, use it as the base directory
        if output:
            base_dir = output
        else:
            base_dir = folder_name

        os.makedirs(base_dir, exist_ok=True)

        # Download each page separately
        for i in range(1, page_count + 1):
            logging.info(f"Getting page {i}/{page_count}")
            try:
                page_content = await ibws.get_page(book_metadata.index, i)
            except PermissionError:
                logging.warning(f"Permission denied for page {i}, stopping download")
                break

            # Create HTML for this page
            html = f"""<!DOCTYPE html>
<html lang="en">
    <head>
        <title>{book_metadata.title} - Page {i}</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>{style}</style>
        <style id='font-style'>{fonts}</style>
    </head>
    <body>
    {page_content}
    </body>
</html>"""

            # Write page to file
            page_filename = os.path.join(base_dir, f"page_{i:04d}.html")
            with open(page_filename, "w", encoding="utf-8") as f:
                f.write(html)

            logging.debug(f"Saved page {i} to {page_filename}")

        logging.info(
            f"Downloaded {page_count} pages of {book_metadata.author} - {book_metadata.title} to folder: {base_dir}")


async def query_action(url: str, ibs: IbukWebSession):
    logging.info(f"Querying book info for URL: {url}")

    book_metadata = ibs.get_book_metadata(url)

    print(f"Author: {book_metadata.author}")
    print(f"Title: {book_metadata.title}")
    print(f"Description: {book_metadata.description}")
    print(f"Publisher: {book_metadata.publisher}")
    print(f"Isbn: {book_metadata.isbn}")
    print(f"Pages: {book_metadata.pages}")
    print(f"Index: {book_metadata.index}")


async def main():
    parser = argparse.ArgumentParser(
        prog="ibuk-dl",
        description="Download a book or query book info from a given libra.ibuk.pl URL",
    )

    visibility_group = parser.add_mutually_exclusive_group()
    visibility_group.add_argument(
        "-v", "--verbose", action="store_true", help="Enable verbose mode"
    )
    visibility_group.add_argument(
        "-q", "--quiet", action="store_true", help="Enable quiet mode"
    )

    subparsers = parser.add_subparsers(dest="action")

    download_parser = subparsers.add_parser("download", help="Download a book")

    download_parser.add_argument("--page-count", type=int, help="Page count (optional)")
    download_parser.add_argument(
        "-o",
        "--output",
        help="Output destination",
    )

    uam_auth_group = download_parser.add_argument_group(
        title="uam authentication",
        description="Authenticate yourself through an han.amu.edu.pl account (optional)",
    )
    uam_auth_group.add_argument("-u", "--username")
    uam_auth_group.add_argument("-p", "--password")

    subparsers.add_parser("query", help="Query book info")

    parser.add_argument("url", help="libra.ibuk.pl URL")

    args = parser.parse_args()

    logging_level = logging.INFO
    if args.verbose:
        logging_level = logging.DEBUG
    elif args.quiet:
        logging_level = logging.CRITICAL

    logging.basicConfig(level=logging_level)

    ibs = IbukWebSession()

    if args.action == "download":
        if bool(args.username) ^ bool(args.password):
            parser.error("If username is provided, password must also be provided.")

        if args.username:
            ibs.login_uam(args.username, args.password)

        await download_action(args.url, args.page_count, ibs, args.output)
    elif args.action == "query":
        await query_action(args.url, ibs)


def run_main():
    asyncio.run(main())


if __name__ == "__main__":
    run_main()
