# Copyright (c) 2021 Philip May, Deutsche Telekom AG
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""For documentation visit https://github.com/bachorp/lazy-imports/."""

from .lazy_module import LazyModule, ShadowingWarning, Statement
from .try_import import try_import
from .util import as_package, load, module_source
from .v0.lazy_imports import LazyImporter


# Versioning follows the Semantic Versioning Specification https://semver.org/ and
# PEP 440 -- Version Identification and Dependency Specification: https://www.python.org/dev/peps/pep-0440/  # noqa: E501
__version__ = "1.1.0"

__all__ = [
    # .lazy_module
    "LazyModule",
    "ShadowingWarning",
    "Statement",
    # .util
    "as_package",
    "load",
    "module_source",
    # .try_import
    "try_import",
    # .v0.lazy_imports
    "LazyImporter",
    # local
    "__version__",
]
