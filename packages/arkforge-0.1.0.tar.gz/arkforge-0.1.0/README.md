# ArkForge Python SDK

Official Python SDK for ArkForge DeFi portfolio management service.

[![CI](https://img.shields.io/github/actions/workflow/status/arkonix-project/arkforge-sdk-py/ci.yml?branch=main)](https://github.com/arkonix-project/arkforge-sdk-py/actions)
[![Python Version](https://img.shields.io/badge/python-3.8%2B-blue)](https://www.python.org/downloads/)
[![Code Coverage](https://img.shields.io/codecov/c/github/arkonix-project/arkforge-sdk-py)](https://codecov.io/gh/arkonix-project/arkforge-sdk-py)

## Features

- 🎯 **Type-Safe**: Full type hints with Pydantic v2 validation
- 🔄 **Resilient**: Automatic retry with exponential backoff
- ⚡ **Fast**: Built on httpx with async support
- 🛡️ **Secure**: API key validation and secure credential management
- 📊 **Complete**: Portfolio optimization, risk analysis, and key management
- 🧪 **Tested**: Comprehensive test suite with CI/CD

## Installation

### Install from GitHub (Recommended)

**For private repositories with authentication**:

```bash
# Using SSH (recommended for private repos)
pip install git+ssh://git@github.com/arkonix-project/arkforge-sdk-py.git

# Using HTTPS with token
pip install git+https://<YOUR_GITHUB_TOKEN>@github.com/arkonix-project/arkforge-sdk-py.git

# Install specific version/tag
pip install git+ssh://git@github.com/arkonix-project/arkforge-sdk-py.git@v0.1.0

# Install specific branch
pip install git+ssh://git@github.com/arkonix-project/arkforge-sdk-py.git@develop
```

**For local development**:

```bash
# Clone repository
git clone git@github.com:arkonix-project/arkforge-sdk-py.git
cd arkforge-sdk-py

# Install in development mode
pip install -e ".[dev]"
```

### requirements.txt

Add to your `requirements.txt`:

```
# Install from GitHub (SSH)
arkforge @ git+ssh://git@github.com/arkonix-project/arkforge-sdk-py.git

# Or install specific version
arkforge @ git+ssh://git@github.com/arkonix-project/arkforge-sdk-py.git@v0.1.0
```

### pyproject.toml / setup.py

Add to your dependencies:

```toml
# pyproject.toml
dependencies = [
    "arkforge @ git+ssh://git@github.com/arkonix-project/arkforge-sdk-py.git",
]
```

## Quick Start

```python
from arkforge import ArkForgeClient

# Initialize client
client = ArkForgeClient(api_key="sk-arkforge-your-key-here")

# Optimize portfolio
from arkforge.models import OptimizePortfolioRequest

result = client.optimize_portfolio(
    OptimizePortfolioRequest(
        assets=["BTC", "ETH", "SOL"],
        risk_profile="moderate"
    )
)

# View recommendations
print(f"Allocation: {result.allocation}")
print(f"Expected Return: {result.expected_return * 100:.2f}%")
print(f"Sharpe Ratio: {result.sharpe_ratio:.2f}")
```

## Usage Examples

### Portfolio Optimization

```python
from arkforge import ArkForgeClient
from arkforge.models import OptimizePortfolioRequest, Constraints, OptimizationConfig

client = ArkForgeClient(api_key="sk-arkforge-...")

# Basic optimization
request = OptimizePortfolioRequest(
    assets=["BTC", "ETH", "SOL", "AVAX"],
    risk_profile="moderate",
    horizon_days=30
)

result = client.optimize_portfolio(request)

# Print allocation
for symbol, percentage in result.allocation.items():
    print(f"{symbol}: {percentage:.1f}%")

# Advanced optimization with constraints
request = OptimizePortfolioRequest(
    assets=["BTC", "ETH", "SOL", "AVAX", "MATIC"],
    risk_profile="aggressive",
    current_portfolio={"BTC": 50, "ETH": 30, "SOL": 20},
    constraints=Constraints(
        max_position_size=35,
        min_diversification=4
    ),
    optimization=OptimizationConfig(
        target_sharpe_ratio=1.5,
        max_volatility=0.3,
        goal="sharpe"
    )
)

result = client.optimize_portfolio(request)

# View rebalancing actions
for action in result.actions:
    print(f"{action.action.upper()} {action.symbol}: {action.change:+.1f}%")
```

### API Key Management

```python
from arkforge import KeyManagementClient
from arkforge.models import CreateKeyRequest

client = KeyManagementClient(api_key="sk-arkforge-admin-key")

# Create new API key
new_key = client.create_key(
    CreateKeyRequest(
        name="Production Key",
        expires_in_days=90,
        scopes=["read", "write"]
    )
)

print(f"API Key: {new_key.api_key}")  # Save this!
print(f"Key ID: {new_key.key_id}")

# List all keys
keys = client.list_keys()
for key in keys:
    print(f"[{key.id}] {key.name} - {key.prefix}")

# Get key details with usage stats
details = client.get_key_details(key.id)
print(f"Total Requests: {details.usage.total_requests}")
print(f"Success Rate: {details.usage.successful_requests / details.usage.total_requests * 100:.1f}%")

# Rotate key
new_key = client.rotate_key(key.id, name="Rotated Production Key")
# Old key is automatically revoked
```

### Async Usage

```python
import asyncio
from arkforge import ArkForgeClient
from arkforge.models import OptimizePortfolioRequest

async def main():
    client = ArkForgeClient(api_key="sk-arkforge-...")

    # Async optimization
    result = await client.optimize_portfolio_async(
        OptimizePortfolioRequest(
            assets=["BTC", "ETH", "SOL"],
            risk_profile="moderate"
        )
    )

    print(result.allocation)

asyncio.run(main())
```

### Error Handling

```python
from arkforge import ArkForgeClient, RateLimitError, ValidationError, ServiceError
import time

client = ArkForgeClient(api_key="sk-arkforge-...")

try:
    result = client.optimize_portfolio(request)
except ValidationError as e:
    print(f"Invalid request: {e.message}")
    if e.details:
        print(f"Details: {e.details}")
except RateLimitError as e:
    print(f"Rate limited. Retry after {e.retry_after}s")
    time.sleep(e.retry_after)
    # Retry logic here
except ServiceError as e:
    print(f"Server error: {e.message}")
    print(f"Request ID: {e.request_id}")
except Exception as e:
    print(f"Unexpected error: {e}")
```

### Context Manager

```python
from arkforge import ArkForgeClient

# Automatic resource cleanup
with ArkForgeClient(api_key="sk-arkforge-...") as client:
    result = client.optimize_portfolio(request)
    print(result.allocation)
# Client automatically closed
```

### Environment Variables

```python
import os
from arkforge import ArkForgeConfig, ArkForgeClient

# Set environment variable
os.environ["ARKFORGE_API_KEY"] = "sk-arkforge-your-key"

# Load from environment
config = ArkForgeConfig.from_env()
client = ArkForgeClient(api_key=config.api_key)

# Or use directly
client = ArkForgeClient(api_key=os.getenv("ARKFORGE_API_KEY"))
```

## Configuration

### Client Configuration

```python
from arkforge import ArkForgeClient

client = ArkForgeClient(
    api_key="sk-arkforge-...",
    base_url="https://api.arkforge.io",  # Production URL
    timeout=120,  # Request timeout in seconds
    retry_attempts=5,  # Max retry attempts
    retry_delay=2.0,  # Base retry delay in seconds
    debug=True  # Enable debug logging
)
```

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `ARKFORGE_API_KEY` | API key | Required |
| `ARKFORGE_BASE_URL` | API base URL | http://localhost:3001 |

## API Reference

### ArkForgeClient

**Methods**:
- `optimize_portfolio(request)` - Optimize portfolio allocation
- `optimize_portfolio_async(request)` - Async portfolio optimization
- `get_risk_profiles()` - Get available risk profiles
- `health()` - Check service health

### KeyManagementClient

**Methods**:
- `create_key(request)` - Create new API key
- `list_keys()` - List all API keys
- `get_key_details(key_id)` - Get key details with usage stats
- `revoke_key(key_id, reason)` - Revoke API key
- `rotate_key(key_id, name)` - Rotate API key
- `update_scopes(key_id, scopes)` - Update key scopes

### Models

**Request Models**:
- `OptimizePortfolioRequest` - Portfolio optimization request
- `CreateKeyRequest` - API key creation request
- `OptimizationConfig` - Optimization configuration
- `Constraints` - Portfolio constraints

**Response Models**:
- `PortfolioRecommendation` - Optimization result
- `RiskProfile` - Risk profile description
- `CreateKeyResponse` - Key creation response
- `ApiKeyInfo` - Key information
- `ApiKeyDetails` - Detailed key information with stats

### Exceptions

All SDK exceptions inherit from `ArkForgeError`:

- `ValidationError` - Invalid request parameters (not retryable)
- `AuthenticationError` - Authentication failed (not retryable)
- `RateLimitError` - Rate limit exceeded (retryable)
- `ServiceError` - Server error (retryable)
- `TimeoutError` - Request timeout (retryable)
- `NetworkError` - Network communication error (retryable)

## Development

### Setup

```bash
# Clone repository
git clone https://github.com/yourusername/arkforge-sdk-py.git
cd arkforge-sdk-py

# Install in development mode
pip install -e ".[dev]"
```

### Testing

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=arkforge --cov-report=html --cov-report=term

# Run only unit tests
pytest tests/unit

# Run only integration tests (requires API)
pytest tests/integration -m integration
```

### Code Quality

```bash
# Type checking
mypy arkforge

# Linting
ruff check arkforge

# Formatting
black arkforge tests

# All checks
pytest --cov=arkforge && mypy arkforge && ruff check arkforge
```

## Requirements

- Python 3.7+
- httpx >= 0.25.0
- pydantic >= 2.0.0

## License

MIT License - see [LICENSE](LICENSE) file for details.

## Support

- 📧 Email: support@arkforge.io
- 📝 Documentation: https://docs.arkforge.io
- 🐛 Issues: https://github.com/yourusername/arkforge-sdk-py/issues

## Contributing

Contributions are welcome! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for version history.
