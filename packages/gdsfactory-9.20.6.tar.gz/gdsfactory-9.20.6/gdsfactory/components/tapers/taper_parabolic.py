from __future__ import annotations

import numpy as np

import gdsfactory as gf
from gdsfactory.path import transition_exponential
from gdsfactory.typings import LayerSpec


@gf.cell_with_module_name
def taper_parabolic(
    length: float = 20,
    width1: float = 0.5,
    width2: float = 5.0,
    exp: float = 0.5,
    npoints: int = 100,
    layer: LayerSpec = "WG",
) -> gf.Component:
    """Returns a parabolic_taper.

    Args:
        length: in um.
        width1: in um.
        width2: in um.
        exp: exponent.
        npoints: number of points.
        layer: layer spec.
    """
    x = np.linspace(0, 1, npoints)
    y = transition_exponential(y1=width1, y2=width2, exp=exp)(x) / 2

    x = length * x
    points1 = np.array([x, y]).T
    points2 = np.flipud(np.array([x, -y]).T)
    points = np.concatenate([points1, points2])

    c = gf.Component()
    c.add_polygon(points, layer=layer)
    c.add_port(name="o1", center=(0, 0), width=width1, orientation=180, layer=layer)
    c.add_port(name="o2", center=(length, 0), width=width2, orientation=0, layer=layer)
    return c
