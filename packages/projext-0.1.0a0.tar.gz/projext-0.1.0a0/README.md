
# projext

A CLI tool to generate a project map from a directory.

## Installation

```bash
pip install projext
```

## Quick Start

```bash
projext map ./src --out project_map.md
```

## License

This project is licensed under the MIT License.
