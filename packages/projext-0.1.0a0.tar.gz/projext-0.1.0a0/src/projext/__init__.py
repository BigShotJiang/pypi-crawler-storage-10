
"""projext - A tool for generating project maps."""

__version__ = "0.1.0"
