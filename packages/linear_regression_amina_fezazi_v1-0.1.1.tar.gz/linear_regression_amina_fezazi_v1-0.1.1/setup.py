from setuptools import setup, find_packages

setup(
    name="linear_regression_amina_fezazi_V1",
    version="0.1.1",
    packages=find_packages(),
    install_requires=[],
    license="MIT",
    description="Simple Linear Regression from scratch",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    python_requires='>=3.6',
)
