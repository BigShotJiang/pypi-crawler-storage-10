# Rocket Project

A simple Python project that models rockets and their behavior.  
It includes different types of rockets such as:
- **Rocket** — the base class representing a rocket in 2D space  
- **Shuttle** — a reusable rocket with a number of completed flights  
- **CircleRocket** — a rocket modeled as a circle with a given radius  

##  Features

- Move rockets in a 2D coordinate system
- Calculate distances between rockets
- Compute area and circumference for circular rockets
- Demonstrate inheritance and method overriding in Python

##  Classes Overview

### `Rocket`
Represents a basic rocket with coordinates `(x, y)`.

### `Shuttle`
Inherits from `Rocket` and adds a `flights_completed` attribute.

### `CircleRocket`
Inherits from `Rocket` and adds:
- `r` → the radius of the rocket
- `get_area()` → returns π * r²  
- `get_circumference()` → returns 2 * π * r

## 🧩 Installation

Make sure you have Python installed.  
You can clone this repository and run the examples in Jupyter Notebook or any IDE.

```bash
git clone https://github.com/Amina212004/rocket.git
cd rocket-project
