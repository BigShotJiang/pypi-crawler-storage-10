class SimpleLinearRegression:
    def __init__(self):
        self.coeff_ = None
        self.intercept_ = None

    def fit(self, X, y):
        n = len(X)
        x_mean = sum(X)/n
        y_mean = sum(y)/n
        num = sum((X[i]-x_mean)*(y[i]-y_mean) for i in range(n))
        den = sum((X[i]-x_mean)**2 for i in range(n))
        self.coeff_ = num / den
        self.intercept_ = y_mean - self.coeff_ * x_mean

    def predict(self, X):
        return [self.coeff_*x + self.intercept_ for x in X]
