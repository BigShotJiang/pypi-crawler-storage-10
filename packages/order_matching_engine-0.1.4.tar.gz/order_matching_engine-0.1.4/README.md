# Order-Matching-Engine
High-performance order matching engine for backtesting and real-time simulation workloads.

### Features
- Limit and market orders
- Order cancelling
- Price → Size → Time priority
- GTC, IOC, FOK options for limit orders
- Midpoint-pegged orders with automatic repricing on quote updates

### Installation
Ensure [uv](https://github.com/astral-sh/uv) is installed, then install project dependencies:

```bash
uv sync
```

### Single orderbook on one thread:
On average, the engine takes 2.5μs to process an order. This means that the engine can ingest and process 400k orders per second (on 3 GHz Intel Core i7, 16 GB 1600 MHz DDR3) using the pypy interpreter. More benchmarks to come.

### Multiple orderbooks, one thread per orderbook:
On average, the engine takes 1.18μs to process an order. This means that the engine can ingest and process 850k orders per second (on 3 GHz Intel Core i7, 16 GB 1600 MHz DDR3) using the pypy interpreter. More benchmarks to come.

### Testing
Install dev dependencies and execute the unit/performance suites through uv:

```bash
uv sync --group dev
uv run pytest -s
```
