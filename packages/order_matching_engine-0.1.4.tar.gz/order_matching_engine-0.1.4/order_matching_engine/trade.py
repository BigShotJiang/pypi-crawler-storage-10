from time import time

from order_matching_engine.order import Side


class Trade(object):
    """
    Represents an executed trade.
    """

    def __init__(
        self,
        incoming_side: Side,
        price: float,
        trade_size: int,
        incoming_order_id: int,
        book_order_id: int,
        timestamp: int | None = None,
    ):
        self.timestamp = timestamp or int(1e6 * time())
        self.side = incoming_side
        self.price = price
        self.size = trade_size
        self.incoming_order_id = incoming_order_id
        self.book_order_id = book_order_id
