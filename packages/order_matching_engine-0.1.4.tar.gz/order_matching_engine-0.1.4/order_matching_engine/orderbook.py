from __future__ import annotations

from typing import TYPE_CHECKING

from sortedcontainers import SortedList

if TYPE_CHECKING:
    from order_matching_engine.order import Order


class Orderbook(object):
    """
    Represents the orderbook with bids and asks.
    """

    def __init__(self):
        self.bids: SortedList["Order"] = SortedList()
        self.asks: SortedList["Order"] = SortedList()

    def get_bid(self) -> int | None:
        return self.bids[0].price if len(self.bids) > 0 else None

    def get_ask(self) -> int | None:
        return self.asks[0].price if len(self.asks) > 0 else None

    def __len__(self):
        return len(self.asks) + len(self.bids)
