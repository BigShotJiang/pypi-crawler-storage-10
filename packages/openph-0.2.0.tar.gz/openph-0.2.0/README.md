# OpenPH

**Core PHPP data models and table view generation**

Part of the `openph` UV workspace - a Python implementation of Passive House Planning Package (PHPP) calculations with exact numerical fidelity to Excel PHPP.

## Purpose

OpenPH provides:
- **Data Models**: Python classes representing PHPP building components (areas, constructions, rooms, climate, HVAC systems)
- **Table Rendering**: Generate formatted output tables (.txt, .html) matching PHPP worksheet layouts for validation
- **Plugin Architecture**: Extensible table system with auto-discovery via entry points
- **HBJSON Import**: Convert Honeybee-PH JSON models to OpenPH data structures

## Structure

```
openph/
├── src/
│   └── openph/         # Main package module
│       ├── model/      # PHPP data classes
│       ├── to_table/   # Table rendering system (plugin-based)
│       ├── from_HBJSON/# Honeybee-PH JSON import
│       └── phpp.py     # Main PHPP container class
├── tests/
└── pyproject.toml
```

## Usage

### Basic Model Creation

```python
from openph.phpp import OpPhPHPP

# Create PHPP model
phpp = OpPhPHPP()

# Access model components
phpp.climate
phpp.areas
phpp.rooms
phpp.hvac
```

### Table Rendering (Single Tables)

```python
from openph.to_table import TableDisplayManager, TableNames

# Initialize table display manager
display = TableDisplayManager(phpp)

# Render individual tables
climate_table = display.get_table(TableNames.CLIMATE_ANNUAL)
climate_table.render(format="console")
climate_table.render(format="html", output_path="climate.html")
```

### Table Grouping (Recommended)

Group related tables and render to a single file:

```python
from openph.to_table import TableDisplayManager, TableNames

display = TableDisplayManager(phpp)

# Create logical groups
climate_group = display.create_group([
    TableNames.CLIMATE_ANNUAL,
    TableNames.CLIMATE_PEAK_LOAD,
    TableNames.CLIMATE_RADIATION_FACTORS,
])

# Render entire group to one file
climate_group.render(format="html", output_path="./climate_report.html")
climate_group.render(format="txt", output_path="./climate_report.txt")
```

### Available Core Tables

Climate: `CLIMATE_ANNUAL`, `CLIMATE_PEAK_LOAD`, `CLIMATE_RADIATION_FACTORS`  
Areas: `AREAS_SUMMARY`, `AREAS_OPAQUE_SURFACE_*`, `AREAS_APERTURE_*`, `AREAS_SOLAR_REDUCTION_*`  
Rooms: `ROOMS_VENTILATION_PROPERTIES`, `ROOMS_VENTILATION_SCHEDULE`  
Ventilation: `VENTILATION_DUCT_INPUTS`, `VENTILATION_DUCT_RESULTS`, `VENTILATION_DUCT_*`

See `TableNames` class for complete list.

## Development

Part of UV workspace - see root `context/ENVIRONMENT.md`:
```bash
uv sync                      # Install all workspace packages
uv run pytest openph/tests/  # Run tests
```
