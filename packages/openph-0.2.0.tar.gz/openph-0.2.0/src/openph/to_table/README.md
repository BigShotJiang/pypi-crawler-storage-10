# OpenPH Table Views Architecture

## Overview

The `to_table` module provides a plugin-based architecture for rendering PHPP calculation results as formatted tables. The architecture uses **DataFrame-first design** for maximum flexibility and ease of use.

**Supported Output Formats:**
- 📊 **Console** - Rich terminal output with colors and formatting
- 📄 **Text** - Plain text files for reports
- 🌐 **HTML** - Styled HTML files for web viewing
- 📈 **CSV** - Comma-separated values for data analysis
- 📑 **Excel** - Excel workbooks (.xlsx) for spreadsheet analysis

**Key Features:**
- ✅ DataFrame-first architecture (pandas at the core)
- ✅ Plugin-based extensibility via entry points
- ✅ Type-safe table name constants
- ✅ Auto-injection of PHPP components
- ✅ Table grouping for batch export
- ✅ CSV and Excel export for data analysis

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│ TableDisplayManager (to_table module)                   │
│  - Discovers tables (core + plugins)                    │
│  - Auto-injects PHPP components                         │
│  - Provides unified get_table() API                     │
│  - Creates TableGroup for batch rendering               │
└─────────────────────────────────────────────────────────┘
                          │
          ┌───────────────┴───────────────┐
          ▼                               ▼
    ┌──────────┐                   ┌──────────────┐
    │   Core   │                   │   Plugins    │
    │  Tables  │                   │   (via entry │
    │  (25+)   │                   │    points)   │
    └──────────┘                   └──────────────┘
          │                               │
          └───────────────┬───────────────┘
                          ▼
                ┌──────────────────┐
                │ TableViewProtocol│
                │  - build_dataframe()     │
                │  - get_column_formats()  │
                │  - render()              │
                └──────────────────┘
                          │
                          ▼
                  ┌──────────────┐
                  │  DataFrame   │
                  │  (pandas)    │
                  └──────────────┘
                          │
                          ▼
          ┌───────────────────────────────────────┐
          │  to_dataframe module (independent)    │
          │  • ColumnFormat, format_cell_value()  │
          │  • apply_column_formats()             │
          │  • dataframe_to_rich_table()          │
          └───────────────────────────────────────┘
                          │
          ┌───────────────┴─────────────────────┐
          ▼               ▼          ▼          ▼
    ┌─────────┐   ┌────────┐  ┌────────┐  ┌────────┐
    │ Console │   │  HTML  │  │  CSV   │  │ Excel  │
    │  (rich) │   │        │  │        │  │ (.xlsx)│
    └─────────┘   └────────┘  └────────┘  └────────┘
```

**DataFrame-First Flow:**
1. Table builds pandas DataFrame with raw data
2. Column formats specified separately (via `ColumnFormat` from `to_dataframe`)
3. Formatting utilities from `to_dataframe` module apply formatting
4. Renderers convert formatted data to output format
5. Same DataFrame can be exported to any format (console, HTML, CSV, Excel)

**Module Separation:**
- `openph.to_dataframe` - Core DataFrame utilities (formatting, conversion) - **rendering-agnostic**
- `openph.to_table` - Table views and rendering system - **builds on to_dataframe**

## Creating a Plugin Table

### 1. Implement the Protocol (DataFrame-First)

```python
from dataclasses import dataclass
import pandas as pd
from openph.phpp import OpPhPHPP
from openph.to_table.table_protocol import OutputFormat, TableViewProtocol
from openph.to_dataframe import ColumnFormat  # DataFrame utilities module
from openph.to_table.renderers import (
    render_dataframe_to_console,
    render_dataframe_to_txt,
    render_dataframe_to_html,
    render_dataframe_to_csv,
)

@dataclass
class MyCustomTable(TableViewProtocol):
    """My custom calculation table."""
    
    phpp: OpPhPHPP
    
    @property
    def title(self) -> str:
        return "My Custom Calculation"
    
    @property
    def phpp_reference(self) -> str:
        return "PHPP-10 | Custom | A1:Z100"
    
    def build_dataframe(self) -> pd.DataFrame:
        """Build DataFrame with calculation data.
        
        Returns:
            pandas DataFrame with raw data (no formatting)
        """
        # Build data dictionary
        data = {
            "Parameter": ["Floor Area", "Volume", "Envelope Area"],
            "Value": [120.5, 350.0, 245.8],
            "Unit": ["m²", "m³", "m²"],
        }
        
        return pd.DataFrame(data)
    
    def get_column_formats(self) -> dict[str, ColumnFormat]:
        """Specify formatting for numeric columns.
        
        Returns:
            Dictionary mapping column names to ColumnFormat specs
        """
        return {
            "Value": ColumnFormat(decimal_places=1, thousands_separator=True),
        }
    
    def render(
        self,
        format: OutputFormat = "console",
        output_path: str | None = None,
        width: int | None = None,
    ) -> str:
        """Render the table in the specified format."""
        df = self.build_dataframe()
        formats = self.get_column_formats()
        
        if format == "console":
            return render_dataframe_to_console(df, self.title, None, formats, width)
        elif format == "txt":
            return render_dataframe_to_txt(df, self.title, None, formats, output_path, width or 200)
        elif format == "html":
            return render_dataframe_to_html(df, self.title, None, formats, output_path, width or 200)
        elif format == "csv":
            return render_dataframe_to_csv(df, output_path)
        else:
            raise ValueError(f"Unknown format: {format}")
```

**Key Architecture Principles:**
- ✅ `build_dataframe()` returns pandas DataFrame with raw data (no formatting)
- ✅ `get_column_formats()` specifies decimal places, thousands separators separately
- ✅ Formatting applied at render time (not during data building)
- ✅ Same DataFrame can be rendered to any format
- ✅ CSV/Excel get raw data without terminal-specific formatting
- ✅ All 5 renderers handle file I/O, HTML wrapping, etc.

### 2. Register via Entry Points

In your plugin's `pyproject.toml`:

```toml
[project.entry-points."openph.table_views"]
my_custom_table = "my_plugin.to_table.custom:MyCustomTable"
```

### 3. Add Table Name Constants (Optional but Recommended)

```python
# my_plugin/to_table/table_names.py
class MyPluginTableNames:
    MY_CUSTOM_TABLE = "my_custom_table"
    
    @classmethod
    def all_tables(cls) -> list[str]:
        return [getattr(cls, attr) for attr in dir(cls) 
                if not attr.startswith("_") and isinstance(getattr(cls, attr), str)]
```

## Usage

### Single Table Rendering

```python
from openph.to_table import TableDisplayManager, TableNames

# Initialize with PHPP model
display = TableDisplayManager(phpp)

# Core tables (type-safe)
climate = display.get_table(TableNames.CLIMATE_ANNUAL)
climate.render(format="console")

# Save to file
climate.render(format="html", output_path="climate.html")

# String lookup also works (case-insensitive)
table = display.get_table("climate_annual")
```

### Table Grouping (Recommended)

Group related tables together and render once to a single file:

```python
from openph.to_table import TableDisplayManager, TableNames
from pathlib import Path

display = TableDisplayManager(phpp)

# Create a group of related tables
climate_group = display.create_group([
    TableNames.CLIMATE_ANNUAL,
    TableNames.CLIMATE_PEAK_LOAD,
])

# Render all tables in group to single file
climate_group.render(format="html", output_path="./climate_report.html")
climate_group.render(format="txt", output_path="./climate_report.txt")
climate_group.render(format="csv", output_path="./climate.csv")

# Multiple groups for different categories
demand_group = display.create_group([
    DemandTableNames.HEATING_DEMAND,
    DemandTableNames.COOLING_DEMAND,
])
demand_group.render(format="html", output_path="./demand_report.html")
```

**Benefits of grouping:**
- ✅ Eliminates repetitive `.render()` calls
- ✅ Logical organization of related tables
- ✅ Single file per category (easier to share/review)
- ✅ Consistent formatting across table group
- ✅ Cleaner, more maintainable code

### CSV and Excel Export

Export tables for data analysis in Excel, pandas, or other tools:

```python
# Single table to CSV
climate = display.get_table(TableNames.CLIMATE_ANNUAL)
climate.render(format="csv", output_path="./climate.csv")

# Group to Excel (multiple sheets in one workbook)
all_climate = display.create_group([
    TableNames.CLIMATE_ANNUAL,
    TableNames.CLIMATE_PEAK_LOAD,
])

# Or export all to separate CSV files
display.save_all(format="csv", output_dir="./csv_exports")
# Creates: ./csv_exports/climate_annual.csv, climate_peak_load.csv, etc.
```

**CSV vs Excel:**
- **CSV**: Simple, universal format. One table per file.
- **Excel**: Rich format with multiple sheets. Better for related tables.
- Both contain raw data (no terminal colors/formatting)

### Plugin Tables

```python
from my_plugin.to_table import MyPluginTableNames

# Plugin tables work the same way
custom = display.get_table(MyPluginTableNames.MY_CUSTOM_TABLE)
custom.render(format="html", output_path="output.html")

# Or in groups
plugin_group = display.create_group([
    MyPluginTableNames.MY_CUSTOM_TABLE,
    MyPluginTableNames.ANOTHER_TABLE,
])
plugin_group.render(format="html", output_path="./plugin_report.html")
```

## Key Components

### Core Modules

- **`TableViewProtocol`**: Interface all tables must implement
  - `title: str` - Display title for the table
  - `phpp_reference: str` - PHPP worksheet reference (e.g., "PHPP-10 | Climate | A1:Z100")
  - `build_dataframe() -> pd.DataFrame` - Build pandas DataFrame with raw data
  - `get_column_formats() -> dict[str, ColumnFormat]` - Specify numeric formatting
  - `render(format, output_path, width) -> str` - Render to console/txt/html/csv

- **`TableDisplayManager`**: Discovers and instantiates tables
  - Auto-discovers core tables + plugin tables via entry points
  - Auto-injects PHPP components based on table name
  - Provides unified `get_table()` API
  - Creates `TableGroup` for batch rendering
  - `save_all()` exports all tables at once

- **`TableGroup`**: Collects multiple tables for batch rendering
  - Render multiple related tables to single file
  - Supports all output formats (console, txt, html, csv)
  - CSV: Creates numbered files (table_001.csv, table_002.csv, etc.)
  - Excel: Creates single workbook with multiple sheets
  - Maintains consistent formatting across group

- **`renderers`**: Format-specific output functions
  - `render_dataframe_to_console(df, title, summary, formats, width)` - Rich terminal output
  - `render_dataframe_to_txt(df, title, summary, formats, path, width)` - Plain text file
  - `render_dataframe_to_html(df, title, summary, formats, path, width)` - Styled HTML file
  - `render_dataframe_to_csv(df, path)` - CSV file for data analysis
  - All handle file I/O, formatting, and HTML wrapping automatically

### DataFrame Utilities (`openph.to_dataframe` module)

**Note:** DataFrame utilities have been separated into their own independent module for maximum reusability.

- **`ColumnFormat`** - Dataclass for decimal places, thousands separators, prefix/suffix
- **`format_cell_value()`** - Apply formatting to individual values
- **`apply_column_formats()`** - Apply formats to entire DataFrame
- **`dataframe_to_rich_table()`** - Convert DataFrame to Rich Table for console

These utilities are **rendering-agnostic** and can be used for:
- Data analysis workflows
- Custom visualizations
- Export pipelines
- Any DataFrame-based processing

See `openph/src/openph/to_dataframe/README.md` for detailed documentation.

- **`TableNames`**: Type-safe constants for core tables
  - Prevents typos with IDE autocomplete
  - Case-insensitive string lookup also supported
  - Plugin packages can provide their own TableNames classes

### Architecture Benefits

**DataFrame-First Design**
- pandas DataFrame at the core (industry standard)
- Raw data separate from formatting
- Same data can be rendered to any format
- CSV/Excel export with full data fidelity

**Module Separation**
- `to_dataframe` - Core DataFrame utilities (formatting, conversion) - **independent**
- `to_table` - Table views and rendering - **builds on to_dataframe**
- DataFrame utilities can be used for non-table purposes (analysis, plotting, etc.)
- Clean dependency hierarchy with no circular imports

**Separation of Concerns**
- Tables build data (`build_dataframe()`)
- Formatting specified separately (`get_column_formats()`)
- `to_dataframe` utilities apply formatting
- Renderers handle output format conversion
- File I/O centralized in renderer functions

**Extensibility**
- Add new output formats by creating new renderer functions
- Plugin tables work identically to core tables
- No code changes needed in existing tables
- DataFrame compatibility with entire pandas ecosystem
- DataFrame utilities reusable across projects

**Code Quality**
- ~50% less code per table (no Rich Table building)
- Zero duplication of formatting logic
- Centralized HTML/file I/O handling
- Type-safe with pandas and dataclasses
- Clear module boundaries

## Component Auto-Injection

The manager auto-injects PHPP components based on table name prefix:
- `climate_*` → `climate: phpp.climate`
- `areas_*` → `areas: phpp.areas`
- `rooms_*` → `rooms: phpp.rooms`
- `ventilation_*` → `hvac: phpp.hvac`
- Others → `phpp: phpp` (full model)

## What's New in DataFrame-First Architecture

### For Users
✅ **CSV Export** - Export any table to CSV for data analysis  
✅ **Excel Export** - Export tables to Excel workbooks (.xlsx)  
✅ **Multi-Sheet Excel** - Combine multiple tables into one workbook  
✅ **Batch Export** - Export all tables at once with `save_all()`  
✅ **Same Interface** - All existing code still works  

### For Plugin Developers
✅ **Simpler Code** - Build DataFrames instead of Rich Tables (~50% less code)  
✅ **Better Separation** - Data building separate from formatting  
✅ **More Formats** - CSV and Excel support automatically included  
✅ **pandas Ecosystem** - Full pandas functionality available  
✅ **Type Safety** - ColumnFormat dataclass for compile-time checks  
✅ **Reusable Utilities** - `to_dataframe` module can be used independently  
✅ **Clear Imports** - `from openph.to_dataframe import ColumnFormat`  

### Migration Guide

**Old Pattern (Rich Table):**
```python
def build_table(self) -> Table:
    table = Table(title=self.title)
    table.add_column("Name", justify="left")
    table.add_column("Value", justify="right")
    
    for item in self.data:
        table.add_row(item.name, f"{item.value:.2f}")
    
    return table
```

**New Pattern (DataFrame-First):**
```python
def build_dataframe(self) -> pd.DataFrame:
    data = {
        "Name": [item.name for item in self.data],
        "Value": [item.value for item in self.data],
    }
    return pd.DataFrame(data)

def get_column_formats(self) -> dict[str, ColumnFormat]:
    return {
        "Value": ColumnFormat(decimal_places=2, thousands_separator=False),
    }
```

**Benefits:**
- Formatting separated from data (can access raw values)
- CSV/Excel export works automatically
- Can use pandas operations on DataFrame
- Less code, clearer intent

If you have existing tables using the old `TableRenderer` API:

**Old Pattern:**
```python
from openph.to_table.renderers import TableRenderer

def render(self, format, output_path, width):
    table = self._build_table()  # Private method
    
    if format == "console":
        TableRenderer.to_console(table, width=width)
        return ""
    elif format == "txt":
        result = TableRenderer.to_txt(table, width=width or 200)
        if output_path:
            Path(output_path).write_text(result)
            return ""
        return result
```

**New Pattern:**
```python
from openph.to_table.render_strategies import to_console, to_txt, to_html

def render(self, format, output_path, width):
    table = self.build_table()  # Public method
    
    if format == "console":
        to_console(table, width=width)
        return ""
    elif format == "txt":
        return to_txt(table, output_path, width or 200)
    elif format == "html":
        return to_html(table, output_path, width or 200)
```

**Changes:**
1. `_build_table()` → `build_table()` (public method)
2. `TableRenderer.to_xxx()` → `to_xxx()` (direct function calls)
3. Import from `render_strategies` instead of `renderers`
4. No manual file I/O - strategies handle it
5. Cleaner, more Pythonic code

## Module Organization

The table rendering system is now split across two independent modules:

### `openph.to_dataframe` - Core DataFrame Utilities

**Purpose:** Rendering-agnostic DataFrame formatting and conversion utilities.

**Location:** `openph/src/openph/to_dataframe/`

**Exports:**
- `ColumnFormat` - Formatting specification dataclass
- `format_cell_value()` - Format single values
- `apply_column_formats()` - Format entire DataFrames
- `dataframe_to_rich_table()` - Convert to Rich Table

**Usage:**
```python
from openph.to_dataframe import ColumnFormat, apply_column_formats

# Can be used for any DataFrame workflow
fmt = ColumnFormat(decimal_places=1, thousands_separator=True, suffix="kWh")
df_formatted = apply_column_formats(df, {"Energy": fmt})
```

**Independent Uses:**
- Data analysis and pandas workflows
- Custom visualizations and plotting
- Export pipelines
- Any structured data transformation

See `openph/src/openph/to_dataframe/README.md` for full documentation.

### `openph.to_table` - Table Rendering System

**Purpose:** Table views, rendering, and display management.

**Location:** `openph/src/openph/to_table/`

**Exports:**
- `TableViewProtocol` - Protocol for table implementations
- `TableDisplayManager` - Table discovery and instantiation
- `TableGroup` - Batch rendering multiple tables
- `OutputFormat` - Type for output formats
- `render_dataframe_to_*()` - Rendering functions
- Core table views (climate, areas, rooms, ventilation)
- `TableNames` - Type-safe table name constants

**Re-exports (for convenience):**
- `ColumnFormat` - From `to_dataframe`
- `format_cell_value()` - From `to_dataframe`
- `dataframe_to_rich_table()` - From `to_dataframe`

**Usage:**
```python
# Import from to_table for table rendering
from openph.to_table import TableDisplayManager, TableNames

# Or use to_dataframe directly for data work
from openph.to_dataframe import ColumnFormat
```

**Dependency Flow:**
```
to_dataframe (independent, no dependencies on to_table)
    ↑
    │ imports
    │
to_table (builds on to_dataframe utilities)
```

This separation ensures DataFrame utilities can be used independently for any data transformation task, not just table rendering.
