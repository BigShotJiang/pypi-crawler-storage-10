# -*- coding: utf-8 -*-
# -*- Python Version: 3.10 -*-

"""Table display manager for discovering and rendering table view plugins."""

import importlib.metadata as metadata
from pathlib import Path
from typing import Any

from openph.phpp import OpPhPHPP
from openph.to_table.table_protocol import OutputFormat, TableViewProtocol
from openph.to_table.table_views.table_names import TableNames


class TableGroup:
    """Group of tables to be rendered together to a single output.

    Example:
        >>> from openph.to_table import TableDisplayManager, TableNames
        >>>
        >>> display = TableDisplayManager(phpp)
        >>> group = display.create_group([
        ...     TableNames.CLIMATE_ANNUAL,
        ...     TableNames.CLIMATE_PEAK_LOAD,
        ... ])
        >>> group.render(format="html", output_path="./climate_report.html")
    """

    def __init__(self, tables: list[TableViewProtocol]):
        """Initialize table group.

        Args:
            tables: List of table view instances to render together
        """
        self.tables = tables

    def render(
        self, format: OutputFormat = "console", output_path: str | Path | None = None, width: int | None = None
    ) -> None:
        """Render all tables in group to specified format.

        Args:
            format: Output format (console, txt, html, csv)
            output_path: Optional file path for txt/html/csv output
            width: Optional width in characters (default: auto for console, 200 for files)

        Note:
            - For CSV format: Creates separate CSV files with numeric suffix
              (e.g., output.csv → output_001.csv, output_002.csv, etc.)
            - For Excel format: Creates single workbook with multiple sheets
              (one sheet per table, using table title as sheet name)
        """
        if format == "console":
            for table in self.tables:
                table.render(format="console", width=width)
                print()  # Add spacing between tables

        elif format in ("txt", "html"):
            if not output_path:
                raise ValueError(f"output_path required for {format} format")

            # Collect all table outputs by rendering each to string
            outputs = []
            for table in self.tables:
                output = table.render(format=format, output_path=None, width=width)
                outputs.append(output)

            # Combine outputs
            if format == "html":
                # Wrap in HTML document structure
                combined = "<!DOCTYPE html>\n<html>\n<head>\n<meta charset='utf-8'>\n"
                combined += "<title>PHPP Table Report</title>\n</head>\n<body>\n"
                combined += "\n<hr>\n".join(outputs)
                combined += "\n</body>\n</html>"
            else:  # txt
                # Use the width for separator line if provided
                separator_width = width or 200
                separator = "\n\n" + ("=" * separator_width) + "\n\n"
                combined = separator.join(outputs)

            # Write to file
            Path(output_path).write_text(combined, encoding="utf-8")
            print(f"Saved group to: {output_path}")

        elif format == "csv":
            if not output_path:
                raise ValueError("output_path required for csv format")

            # Create separate CSV files for each table with numeric suffix
            output_file = Path(output_path)
            stem = output_file.stem
            parent = output_file.parent

            for i, table in enumerate(self.tables, start=1):
                csv_path = parent / f"{stem}_{i:03d}.csv"
                table.render(format="csv", output_path=str(csv_path))
                print(f"Saved: {csv_path}")

        else:
            raise ValueError(f"Unknown format: {format}")


class TableDisplayManager:
    """Discover and manage table view plugins.

    Provides a unified API for rendering PHPP calculation results as tables.
    Auto-discovers plugin tables via entry points and auto-injects PHPP
    components based on table name prefix.

    Example:
        >>> from openph.phpp import OpPhPHPP
        >>> from openph.to_table import TableDisplayManager, TableNames
        >>>
        >>> phpp = OpPhPHPP()
        >>> display = TableDisplayManager(phpp)
        >>>
        >>> # Render single table (type-safe with constants)
        >>> climate_table = display.get_table(TableNames.CLIMATE_ANNUAL)
        >>> climate_table.render(format="console")
        >>>
        >>> # Or use strings (case-insensitive, whitespace-trimmed)
        >>> table = display.get_table("climate_annual")
        >>>
        >>> # Save all tables to HTML
        >>> display.save_all(format="html", output_dir="./reports")
    """

    def __init__(self, phpp: OpPhPHPP):
        """Initialize table display manager with PHPP instance.

        Args:
            phpp: OpPhPHPP instance containing all model data
        """
        self.phpp = phpp
        self._table_view_classes: dict[str, type] = {}
        self._load_core_table_views()
        self._load_table_view_plugins()

    def _load_core_table_views(self) -> None:
        """Register core table views from openph package."""
        from openph.to_table.table_views.areas import (
            ApertureSurfaceHeatGainTable,
            ApertureSurfacesTable,
            AreaSummaryTable,
            OpaqueSurfaceAttributesTable,
            OpaqueSurfaceHeatGainTable,
            SummerSolarReductionTable,
            WinterSolarReductionTable,
        )
        from openph.to_table.table_views.climate import (
            AnnualClimateDataTable,
            PeakLoadClimateDataTable,
        )
        from openph.to_table.table_views.rooms import (
            RoomVentilationPropertiesTable,
            RoomVentilationScheduleTable,
        )
        from openph.to_table.table_views.ventilation import (
            VentilationDuctInputsTable,
            VentilationDuctIterativeSolverTable,
            VentilationDuctNusseltNumberTable,
            VentilationDuctResultsTable,
        )

        # Register areas tables
        self._table_view_classes[TableNames.AREAS_OPAQUE_SURFACE_ATTRIBUTES] = OpaqueSurfaceAttributesTable
        self._table_view_classes[TableNames.AREAS_OPAQUE_SURFACE_HEAT_GAIN] = OpaqueSurfaceHeatGainTable
        self._table_view_classes[TableNames.AREAS_SUMMARY] = AreaSummaryTable
        self._table_view_classes[TableNames.AREAS_APERTURE_SURFACES] = ApertureSurfacesTable
        self._table_view_classes[TableNames.AREAS_APERTURE_HEAT_GAIN] = ApertureSurfaceHeatGainTable
        self._table_view_classes[TableNames.AREAS_SOLAR_REDUCTION_WINTER] = WinterSolarReductionTable
        self._table_view_classes[TableNames.AREAS_SOLAR_REDUCTION_SUMMER] = SummerSolarReductionTable

        # Register climate tables
        self._table_view_classes[TableNames.CLIMATE_ANNUAL] = AnnualClimateDataTable
        self._table_view_classes[TableNames.CLIMATE_PEAK_LOAD] = PeakLoadClimateDataTable
        # Note: CLIMATE_RADIATION_FACTORS not yet implemented (data not in model)

        # Register room tables
        self._table_view_classes[TableNames.ROOMS_VENTILATION_PROPERTIES] = RoomVentilationPropertiesTable
        self._table_view_classes[TableNames.ROOMS_VENTILATION_SCHEDULE] = RoomVentilationScheduleTable

        # Register ventilation tables
        self._table_view_classes[TableNames.VENTILATION_DUCT_INPUTS] = VentilationDuctInputsTable
        self._table_view_classes[TableNames.VENTILATION_DUCT_RESULTS] = VentilationDuctResultsTable
        self._table_view_classes[TableNames.VENTILATION_DUCT_ITERATIVE_SOLVER] = VentilationDuctIterativeSolverTable
        self._table_view_classes[TableNames.VENTILATION_DUCT_NUSSELT_NUMBER] = VentilationDuctNusseltNumberTable

    def _load_table_view_plugins(self) -> None:
        """Discover table view plugins via entry points."""
        entry_points = metadata.entry_points()

        # Handle both Python 3.10+ and 3.12+ APIs
        if hasattr(entry_points, "select"):
            table_eps = entry_points.select(group="openph.table_views")
        else:
            table_eps = entry_points.get("openph.table_views", [])

        for entry_point in table_eps:
            print(f"Loading table view plugin: '{entry_point.name}'")
            self._table_view_classes[entry_point.name] = entry_point.load()

    @property
    def available_tables(self) -> list[str]:
        """Get list of available table view names."""
        return list(self._table_view_classes.keys())

    def get_table(self, name: str, **kwargs: Any) -> TableViewProtocol:
        """Get a table view instance by name.

        Auto-injects appropriate PHPP components based on table name prefix.
        For type safety and IDE autocomplete, use TableNames constants.

        Example:
            >>> from openph.to_table.table_names import TableNames
            >>> table = display.get_table(TableNames.CLIMATE_ANNUAL)
            >>> table = display.get_table("climate_annual")  # Also works

        Args:
            name: Table view name (use TableNames constants for type safety).
                  Lookup is case-insensitive and strips whitespace.
            **kwargs: Additional arguments passed to table constructor.
                      If not provided, appropriate PHPP components are auto-injected
                      based on name prefix (climate_, areas_, rooms_, ventilation_).

        Returns:
            Table view instance implementing TableViewProtocol

        Raises:
            ValueError: If table view name not found
        """
        # Normalize the name: lowercase and strip whitespace
        normalized_name = name.strip().lower()

        if normalized_name not in self._table_view_classes:
            raise ValueError(
                f"Table view '{name}' not found. "
                f"Available tables: {self.available_tables}\n"
                f"Tip: Import TableNames from openph.to_table.table_names for type-safe lookups"
            )

        # Auto-inject PHPP components if not provided
        if not kwargs:
            kwargs = self._get_default_kwargs(normalized_name)

        return self._table_view_classes[normalized_name](**kwargs)

    def create_group(self, table_names: list[str]) -> TableGroup:
        """Create a group of tables to render together.

        Example:
            >>> from openph.to_table import TableNames
            >>> group = display.create_group([
            ...     TableNames.CLIMATE_ANNUAL,
            ...     TableNames.CLIMATE_PEAK_LOAD,
            ... ])
            >>> group.render(format="html", output_path="./climate.html")

        Args:
            table_names: List of table names to group

        Returns:
            TableGroup instance ready to render
        """
        tables = [self.get_table(name) for name in table_names]
        return TableGroup(tables)

    def _get_default_kwargs(self, table_name: str) -> dict[str, Any]:
        """Get default constructor arguments based on table name prefix.

        Auto-injects appropriate PHPP components:
        - climate_* → {"climate": phpp.climate}
        - areas_* → {"areas": phpp.areas}
        - rooms_* → {"rooms": phpp.rooms}
        - ventilation_* → {"hvac": phpp.hvac}
        - others → {"phpp": phpp} (full model for plugins)

        Args:
            table_name: Normalized table view name (lowercase)

        Returns:
            Dictionary of constructor arguments
        """
        # Climate tables need climate component
        if table_name.startswith("climate_"):
            return {"climate": self.phpp.climate}

        # Areas tables need areas component
        if table_name.startswith("areas_"):
            return {"areas": self.phpp.areas}

        # Rooms tables need rooms component
        if table_name.startswith("rooms_"):
            return {"rooms": self.phpp.rooms}

        # Ventilation tables need hvac component
        if table_name.startswith("ventilation_"):
            return {"hvac": self.phpp.hvac}

        # Plugin tables (demand, solar, etc.) need full PHPP
        return {"phpp": self.phpp}

    def save_all(
        self,
        format: OutputFormat = "html",
        output_dir: str | Path = "./output",
        table_names: list[str] | None = None,
    ) -> None:
        """Save all (or specified) table views to files.

        Args:
            format: Output format (txt, html, csv)
            output_dir: Directory to save files
            table_names: Optional list of specific tables to save (saves all if None)

        Note:
            - For txt/html/csv: Creates separate files for each table
            - For Excel: Creates single workbook with all tables as separate sheets
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        tables_to_save = table_names or self.available_tables

        if format == "html":
            extension = "html"
        elif format == "csv":
            extension = "csv"
        else:  # txt
            extension = "txt"

        for table_name in tables_to_save:
            try:
                table = self.get_table(table_name)
                file_path = output_path / f"{table_name}.{extension}"
                table.render(format=format, output_path=str(file_path))
                print(f"Saved: {file_path}")
            except Exception as e:
                print(f"Error saving {table_name}: {e}")

    def render_all(
        self,
        format: OutputFormat = "console",
        table_names: list[str] | None = None,
    ) -> None:
        """Render all (or specified) table views to console.

        Args:
            format: Output format (should be 'console' for this method)
            table_names: Optional list of specific tables to render
        """
        tables_to_render = table_names or self.available_tables

        for table_name in tables_to_render:
            try:
                table = self.get_table(table_name)
                table.render(format=format)
                print()  # Add spacing between tables
            except Exception as e:
                print(f"Error rendering {table_name}: {e}")


# Export for convenience
__all__ = ["TableDisplayManager", "TableNames"]
