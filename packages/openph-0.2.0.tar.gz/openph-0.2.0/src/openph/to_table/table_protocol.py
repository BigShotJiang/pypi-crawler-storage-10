# -*- coding: utf-8 -*-
# -*- Python Version: 3.10 -*-

"""Protocol definition for table view plugins.

DataFrame-First Architecture:
    All table views follow a clean data-to-presentation flow:
    1. build_dataframe() returns raw data (numbers, not strings)
    2. get_column_formats() specifies display formatting (optional)
    3. render() delegates to format-specific converters

    Benefits:
    - Raw data accessible for analysis
    - Formatting applied at render time
    - Easy to add new output formats (CSV, Excel, etc.)
    - Simpler code for plugin authors
"""

from typing import Literal, Protocol

import pandas as pd

from openph.to_dataframe import ColumnFormat

OutputFormat = Literal["console", "txt", "html", "csv"]


class TableViewProtocol(Protocol):
    """Protocol that all table view plugins must implement.

    DataFrame-First Pattern:
        Table classes build pandas DataFrames with raw data, then delegate
        to built-in converters for rendering to different formats.

    Example:
        >>> from dataclasses import dataclass
        >>> import pandas as pd
        >>> from openph.to_table.table_protocol import TableViewProtocol
        >>> from openph.to_dataframe import ColumnFormat, dataframe_to_rich_table
        >>> from openph.to_table.renderers import (
        ...     to_console, render_dataframe_to_html, render_dataframe_to_csv
        ... )
        >>>
        >>> @dataclass
        >>> class MyTable(TableViewProtocol):
        ...     phpp: OpPhPHPP
        ...
        ...     @property
        ...     def title(self) -> str:
        ...         return "Monthly Energy Results"
        ...
        ...     @property
        ...     def phpp_reference(self) -> str:
        ...         return "PHPP-10 | Energy | A1:M50"
        ...
        ...     def build_dataframe(self) -> pd.DataFrame:
        ...         '''Build DataFrame with raw numeric data.'''
        ...         return pd.DataFrame({
        ...             'Month': ['Jan', 'Feb', 'Mar'],
        ...             'Heating (kWh)': [120.5, 110.3, 95.8],  # Raw numbers!
        ...             'Cooling (kWh)': [0.0, 0.0, 5.2],
        ...         })
        ...
        ...     def get_column_formats(self) -> dict[str, ColumnFormat]:
        ...         '''Specify formatting per column.'''
        ...         return {
        ...             'Heating (kWh)': ColumnFormat(decimal_places=1, thousands_separator=True),
        ...             'Cooling (kWh)': ColumnFormat(decimal_places=1, thousands_separator=True),
        ...         }
        ...
        ...     def build_summary(self) -> str | None:
        ...         '''Optional summary text.'''
        ...         return f"Total Annual: {self.phpp.total_energy:,.0f} kWh"
        ...
        ...     def render(self, format="console", output_path=None, width=None):
        ...         '''Render using DataFrame converters.'''
        ...         df = self.build_dataframe()
        ...         formats = self.get_column_formats()
        ...         summary = self.build_summary()
        ...
        ...         if format == "console":
        ...             table = dataframe_to_rich_table(df, self.title, formats)
        ...             to_console(table, summary, width)
        ...             return ""
        ...         elif format == "html":
        ...             return render_dataframe_to_html(df, self.title, summary, formats, output_path, width)
        ...         elif format == "csv":
        ...             return render_dataframe_to_csv(df, output_path)
    """

    @property
    def title(self) -> str:
        """Table title for display (e.g., 'Monthly Heating Demand')."""
        ...

    @property
    def phpp_reference(self) -> str:
        """PHPP worksheet reference (e.g., 'PHPP-10 | Heating | T90:AG118')."""
        ...

    def build_dataframe(self) -> pd.DataFrame:
        """Build and return DataFrame with raw data.

        This is the PRIMARY method - all rendering flows through this.
        Return raw numeric data without formatting (e.g., 123.456 not "123.5").
        Formatting is applied at render time based on get_column_formats().

        Best Practices:
        - Use meaningful column names (include units: "Heating (kWh)")
        - Return raw numeric values (float/int, not formatted strings)
        - Use proper pandas dtypes
        - Keep data "tidy" (one observation per row)

        Returns:
            DataFrame with raw data, proper dtypes, meaningful column names

        Example:
            >>> def build_dataframe(self) -> pd.DataFrame:
            ...     return pd.DataFrame({
            ...         'Month': ['Jan', 'Feb', 'Mar'],
            ...         'Temperature (°C)': [20.5, 21.3, 22.1],  # float, not "20.5"
            ...         'Degree Hours': [100, 95, 85],  # int, not "100.0"
            ...     })
        """
        ...

    def get_column_formats(self) -> dict[str, ColumnFormat]:
        """Specify formatting rules per column (optional).

        Return a dictionary mapping column names to ColumnFormat specifications.
        Columns not in the dictionary will use default formatting.

        Returns:
            Dict mapping column names to formatting specs

        Example:
            >>> def get_column_formats(self) -> dict[str, ColumnFormat]:
            ...     return {
            ...         'Temperature (°C)': ColumnFormat(decimal_places=1),
            ...         'Energy (kWh)': ColumnFormat(decimal_places=0, thousands_separator=True),
            ...         'Cost ($)': ColumnFormat(decimal_places=2, prefix='$'),
            ...         'Efficiency (%)': ColumnFormat(decimal_places=1, suffix='%'),
            ...     }
        """
        ...

    def build_summary(self) -> str | None:
        """Build optional summary text that appears below the table.

        Override this method if your table needs additional context
        or summary information displayed below the main table.

        Returns:
            Summary text or None if no summary needed
        """
        ...

    def render(
        self,
        format: OutputFormat = "console",
        output_path: str | None = None,
        width: int | None = None,
    ) -> str:
        """Render table in specified format.

        Table classes should implement this by getting the DataFrame and
        delegating to format-specific converters.

        Args:
            format: Output format (console, txt, html, csv)
            output_path: If provided, save to file instead of returning string
            width: Optional width override in characters.
                   Default: auto-detect for console, 200 for txt/html

        Returns:
            Rendered table string (empty if saved to file)
        """
        ...
