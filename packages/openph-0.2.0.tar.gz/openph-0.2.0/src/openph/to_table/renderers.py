# -*- coding: utf-8 -*-
# -*- Python Version: 3.10 -*-

"""Rendering strategies for DataFrame-based table views.

This module provides rendering functions that convert DataFrames to various
output formats: console (via Rich), HTML, CSV, and Excel.

DataFrame-First Philosophy:
    - Tables build DataFrames with raw data
    - Formatting applied at render time
    - Each format has optimized rendering path
    - No unnecessary conversions
"""

import io
from pathlib import Path

import pandas as pd
from rich.console import Console

from openph.to_dataframe import (
    ColumnFormat,
    apply_column_formats,
    dataframe_to_rich_table,
)


def render_dataframe_to_console(
    df: pd.DataFrame,
    title: str,
    summary: str | None = None,
    formats: dict[str, ColumnFormat] | None = None,
    width: int | None = None,
) -> str:
    """Render DataFrame to console via Rich Table."""
    table = dataframe_to_rich_table(df, title, formats)
    console = Console(width=width)
    console.print(table)
    if summary:
        console.print(f"\n{summary}")
    return ""


def render_dataframe_to_txt(
    df: pd.DataFrame,
    title: str,
    summary: str | None = None,
    formats: dict[str, ColumnFormat] | None = None,
    output_path: str | Path | None = None,
    width: int = 200,
) -> str:
    """Render DataFrame to plain text via Rich Table (no ANSI codes)."""
    table = dataframe_to_rich_table(df, title, formats)
    string_buffer = io.StringIO()
    console = Console(
        file=string_buffer,
        width=width,
        legacy_windows=False,
        force_terminal=False,
        force_interactive=False,
        no_color=True,
    )
    console.print(table)
    if summary:
        console.print(f"\n{summary}")
    text_output = string_buffer.getvalue()
    if output_path:
        Path(output_path).write_text(text_output, encoding="utf-8")
        return ""
    return text_output


def render_dataframe_to_html(
    df: pd.DataFrame,
    title: str,
    summary: str | None = None,
    formats: dict[str, ColumnFormat] | None = None,
    output_path: str | Path | None = None,
    width: int = 200,
) -> str:
    """Render DataFrame directly to HTML (no Rich intermediate)."""
    df_formatted = apply_column_formats(df, formats)
    records = df_formatted.to_dict("records")
    columns = [{"name": col, "id": col} for col in df_formatted.columns]

    header_cells = "".join(
        f'<th style="background-color: #2c3e50; color: white; font-weight: bold; '
        f'text-align: center; padding: 8px; border: 1px solid #1a252f;">{col["name"]}</th>'
        for col in columns
    )

    body_rows = ""
    for i, row in enumerate(records):
        bg_color = "#f8f9fa" if i % 2 else "white"
        cells = "".join(
            f'<td style="padding: 8px; border: 1px solid #ddd; '
            f'color: #2c3e50; font-size: 14px;">{row.get(col["id"], "")}</td>'
            for col in columns
        )
        body_rows += f'<tr style="background-color: {bg_color};">{cells}</tr>'

    max_width_px = width * 8
    table_html = f"""
        <div style="padding: 20px; max-width: {max_width_px}px; margin: 0 auto;
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
            <h2 style="text-align: center; color: #2c3e50; margin-bottom: 20px;">{title}</h2>
            <table style="width: 100%; border-collapse: collapse; overflow-x: auto;">
                <thead>
                    <tr>{header_cells}</tr>
                </thead>
                <tbody>
                    {body_rows}
                </tbody>
            </table>
        </div>
    """

    if summary:
        newline = chr(10)  # Workaround for \n in f-string on Python 3.10
        summary_with_breaks = summary.replace(newline, "<br>")
        summary_html = f"""
        <div style="font-family: monospace; margin: 20px auto; padding: 10px;
                    background-color: #f8f9fa; border: 1px solid #ddd;
                    max-width: {max_width_px}px; white-space: pre-wrap;">
            {summary_with_breaks}
        </div>
        """
        table_html += summary_html

    html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
</head>
<body>
    {table_html}
</body>
</html>"""

    if output_path:
        Path(output_path).write_text(html_content, encoding="utf-8")
        return ""
    return html_content


def render_dataframe_to_csv(
    df: pd.DataFrame,
    output_path: str | Path | None = None,
    include_index: bool = False,
) -> str:
    """Export DataFrame to CSV format."""
    csv_output = df.to_csv(index=include_index)
    if output_path:
        Path(output_path).write_text(csv_output, encoding="utf-8")
        return ""
    return csv_output
