# -*- coding: utf-8 -*-
# -*- Python Version: 3.10 -*-

"""Table views for PHPP | Addl Vent | Duct Calculations."""

from dataclasses import dataclass

import pandas as pd
from openph.model.hvac.hvac import OpPhHVAC
from openph.to_table.renderers import (
    render_dataframe_to_console,
    render_dataframe_to_csv,
    render_dataframe_to_html,
    render_dataframe_to_txt,
)
from openph.to_table.table_protocol import ColumnFormat, OutputFormat, TableViewProtocol


@dataclass
class VentilationDuctInputsTable(TableViewProtocol):
    """Ventilation duct input properties from PHPP."""

    hvac: OpPhHVAC

    @property
    def title(self) -> str:
        return "Duct Input Properties"

    @property
    def phpp_reference(self) -> str:
        return "PHPP-10 | Addl Vent | E127:L146"

    def build_dataframe(self) -> pd.DataFrame:
        """Build DataFrame with duct input properties."""
        data = {
            "Unit": [],
            "Duct Direction": [],
            "Type": [],
            "Diameter [MM]": [],
            "Width [MM]": [],
            "Height [MM]": [],
            "Insulation Thickness [MM]": [],
            "Insulation Conductivity [Wmk]": [],
            "Insulation Reflective?": [],
            "Duct Conductance [W/mk]?": [],
            "Length [M]": [],
        }

        for device in self.hvac.ventilation_system.device_collection.devices:
            # Supply duct row
            data["Unit"].append(device.display_name)
            data["Duct Direction"].append("Supply")
            data["Type"].append(device.ducting.supply_ducting.duct_type.name)
            data["Diameter [MM]"].append(device.ducting.supply_ducting.diameter_mm)
            data["Width [MM]"].append(device.ducting.supply_ducting.width_mm)
            data["Height [MM]"].append(device.ducting.supply_ducting.height_mm)
            data["Insulation Thickness [MM]"].append(device.ducting.supply_ducting.insulation_thickness_mm)
            data["Insulation Conductivity [Wmk]"].append(device.ducting.supply_ducting.insulation_conductivity_w_mk)
            data["Insulation Reflective?"].append(str(device.ducting.supply_ducting.insulation_reflective))
            data["Duct Conductance [W/mk]?"].append(device.ducting.supply_ducting.conductance_w_m_k)
            data["Length [M]"].append(device.ducting.supply_ducting.length_m)

            # Exhaust duct row
            data["Unit"].append(device.display_name)
            data["Duct Direction"].append("Exhaust")
            data["Type"].append(device.ducting.exhaust_ducting.duct_type.name)
            data["Diameter [MM]"].append(device.ducting.exhaust_ducting.diameter_mm)
            data["Width [MM]"].append(device.ducting.exhaust_ducting.width_mm)
            data["Height [MM]"].append(device.ducting.exhaust_ducting.height_mm)
            data["Insulation Thickness [MM]"].append(device.ducting.exhaust_ducting.insulation_thickness_mm)
            data["Insulation Conductivity [Wmk]"].append(device.ducting.exhaust_ducting.insulation_conductivity_w_mk)
            data["Insulation Reflective?"].append(str(device.ducting.exhaust_ducting.insulation_reflective))
            data["Duct Conductance [W/mk]?"].append(device.ducting.exhaust_ducting.conductance_w_m_k)
            data["Length [M]"].append(device.ducting.exhaust_ducting.length_m)

        return pd.DataFrame(data)

    def get_column_formats(self) -> dict[str, ColumnFormat]:
        """Specify formatting for numeric columns."""
        return {
            "Diameter [MM]": ColumnFormat(decimal_places=1, thousands_separator=False),
            "Width [MM]": ColumnFormat(decimal_places=1, thousands_separator=False),
            "Height [MM]": ColumnFormat(decimal_places=1, thousands_separator=False),
            "Insulation Thickness [MM]": ColumnFormat(decimal_places=1, thousands_separator=False),
            "Insulation Conductivity [Wmk]": ColumnFormat(decimal_places=1, thousands_separator=False),
            "Duct Conductance [W/mk]?": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Length [M]": ColumnFormat(decimal_places=1, thousands_separator=False),
        }

    def render(
        self,
        format: OutputFormat = "console",
        output_path: str | None = None,
        width: int | None = None,
    ) -> str:
        """Render the table in the specified format."""
        df = self.build_dataframe()
        formats = self.get_column_formats()

        if format == "console":
            return render_dataframe_to_console(df, self.title, None, formats, width)
        elif format == "txt":
            return render_dataframe_to_txt(df, self.title, None, formats, output_path, width or 200)
        elif format == "html":
            return render_dataframe_to_html(df, self.title, None, formats, output_path, width or 200)
        elif format == "csv":
            return render_dataframe_to_csv(df, output_path)
        else:
            raise ValueError(f"Unknown format: {format}")


@dataclass
class VentilationDuctResultsTable(TableViewProtocol):
    """Ventilation duct calculated properties from PHPP."""

    hvac: OpPhHVAC

    @property
    def title(self) -> str:
        return "Duct Calculated Properties"

    @property
    def phpp_reference(self) -> str:
        return "PHPP-10 | Addl Vent | AM127:BE146"

    def build_dataframe(self) -> pd.DataFrame:
        """Build DataFrame with duct calculated properties."""
        data = {
            "Unit": [],
            "Duct Direction": [],
            "Type": [],
            "Heat Loss Coeff. (W/K)": [],
            "Duct Coeff.": [],
            "Avg. Airflow (m3/h)": [],
            "Duct Type": [],
            "Approx. Diameter (MM)": [],
            "Equiv. Diameter (MM)": [],
            "Outer Diam without Insul. (MM)": [],
            "Nusselt Number": [],
            "Temp. Diff. DJ": [],
            "Outer Diam without Insul. (M)": [],
            "Outer Diam with Insul. (M)": [],
            "Alpha Inside": [],
            "Alpha Surface": [],
        }

        for device in self.hvac.ventilation_system.device_collection.devices:
            # Supply duct row
            data["Unit"].append(device.display_name)
            data["Duct Direction"].append("Supply")
            data["Type"].append(device.ducting.supply_ducting.duct_type.name)
            data["Heat Loss Coeff. (W/K)"].append(device.ducting.supply_ducting.heat_loss_coefficient_W_K)
            data["Duct Coeff."].append(device.ducting.supply_ducting.duct_coefficient)
            data["Avg. Airflow (m3/h)"].append(device.ducting.supply_ducting.average_annual_airflow_rate_m3_h)
            data["Duct Type"].append(device.ducting.supply_ducting.duct_type_number)
            data["Approx. Diameter (MM)"].append(device.ducting.supply_ducting.hydraulic_diameter_mm)
            data["Equiv. Diameter (MM)"].append(device.ducting.supply_ducting.equivalent_diameter_mm)
            data["Outer Diam without Insul. (MM)"].append(
                device.ducting.supply_ducting.outer_diameter_without_insulation_mm
            )
            data["Nusselt Number"].append(device.ducting.supply_ducting.nusselt_number_takeover)
            data["Temp. Diff. DJ"].append(device.ducting.supply_ducting.temperature_difference_DJ)
            data["Outer Diam without Insul. (M)"].append(
                device.ducting.supply_ducting.outer_diameter_without_insulation_m
            )
            data["Outer Diam with Insul. (M)"].append(device.ducting.supply_ducting.outer_diameter_with_insulation_m)
            data["Alpha Inside"].append(device.ducting.supply_ducting.alpha_inside)
            data["Alpha Surface"].append(device.ducting.supply_ducting.alpha_surface)

            # Exhaust duct row
            data["Unit"].append(device.display_name)
            data["Duct Direction"].append("Exhaust")
            data["Type"].append(device.ducting.exhaust_ducting.duct_type.name)
            data["Heat Loss Coeff. (W/K)"].append(device.ducting.exhaust_ducting.heat_loss_coefficient_W_K)
            data["Duct Coeff."].append(device.ducting.exhaust_ducting.duct_coefficient)
            data["Avg. Airflow (m3/h)"].append(device.ducting.exhaust_ducting.average_annual_airflow_rate_m3_h)
            data["Duct Type"].append(device.ducting.exhaust_ducting.duct_type_number)
            data["Approx. Diameter (MM)"].append(device.ducting.exhaust_ducting.hydraulic_diameter_mm)
            data["Equiv. Diameter (MM)"].append(device.ducting.exhaust_ducting.equivalent_diameter_mm)
            data["Outer Diam without Insul. (MM)"].append(
                device.ducting.exhaust_ducting.outer_diameter_without_insulation_mm
            )
            data["Nusselt Number"].append(device.ducting.exhaust_ducting.nusselt_number_takeover)
            data["Temp. Diff. DJ"].append(device.ducting.exhaust_ducting.temperature_difference_DJ)
            data["Outer Diam without Insul. (M)"].append(
                device.ducting.exhaust_ducting.outer_diameter_without_insulation_m
            )
            data["Outer Diam with Insul. (M)"].append(device.ducting.exhaust_ducting.outer_diameter_with_insulation_m)
            data["Alpha Inside"].append(device.ducting.exhaust_ducting.alpha_inside)
            data["Alpha Surface"].append(device.ducting.exhaust_ducting.alpha_surface)

        return pd.DataFrame(data)

    def get_column_formats(self) -> dict[str, ColumnFormat]:
        """Specify formatting for numeric columns."""
        return {
            "Heat Loss Coeff. (W/K)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Duct Coeff.": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Avg. Airflow (m3/h)": ColumnFormat(decimal_places=1, thousands_separator=False),
            "Approx. Diameter (MM)": ColumnFormat(decimal_places=1, thousands_separator=False),
            "Equiv. Diameter (MM)": ColumnFormat(decimal_places=1, thousands_separator=False),
            "Outer Diam without Insul. (MM)": ColumnFormat(decimal_places=1, thousands_separator=False),
            "Nusselt Number": ColumnFormat(decimal_places=1, thousands_separator=False),
            "Temp. Diff. DJ": ColumnFormat(decimal_places=1, thousands_separator=False),
            "Outer Diam without Insul. (M)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Outer Diam with Insul. (M)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Alpha Inside": ColumnFormat(decimal_places=2, thousands_separator=False),
            "Alpha Surface": ColumnFormat(decimal_places=2, thousands_separator=False),
        }

    def render(
        self,
        format: OutputFormat = "console",
        output_path: str | None = None,
        width: int | None = None,
    ) -> str:
        """Render the table in the specified format."""
        df = self.build_dataframe()
        formats = self.get_column_formats()

        if format == "console":
            return render_dataframe_to_console(df, self.title, None, formats, width)
        elif format == "txt":
            return render_dataframe_to_txt(df, self.title, None, formats, output_path, width or 200)
        elif format == "html":
            return render_dataframe_to_html(df, self.title, None, formats, output_path, width or 200)
        elif format == "csv":
            return render_dataframe_to_csv(df, output_path)
        else:
            raise ValueError(f"Unknown format: {format}")


@dataclass
class VentilationDuctIterativeSolverTable(TableViewProtocol):
    """Ventilation duct iterative solver results from PHPP."""

    hvac: OpPhHVAC

    @property
    def title(self) -> str:
        return "Duct Iterative Solver Results"

    @property
    def phpp_reference(self) -> str:
        return "PHPP-10 | Addl Vent | BI127:BT146"

    def build_dataframe(self) -> pd.DataFrame:
        """Build DataFrame with duct iterative solver results."""
        data = {
            "Unit": [],
            "Duct Direction": [],
            "Type": [],
            "(1) a-Approx. (W/K)": [],
            "(1) k-Approx. (W/mk)": [],
            "(1) Temp-Difference (K)": [],
            "(2) a-Approx. (W/K)": [],
            "(2) k-Approx. (W/mk)": [],
            "(2) Temp-Difference (K)": [],
            "(3) a-Approx. (W/K)": [],
            "(3) k-Approx. (W/mk)": [],
            "(3) Temp-Difference (K)": [],
            "(4) a-Approx. (W/K)": [],
            "(4) k-Approx. (W/mk)": [],
            "(4) Temp-Difference (K)": [],
            "(5) a-Approx. (W/K)": [],
            "(5) k-Approx. (W/mk)": [],
            "(5) Temp-Difference (K)": [],
        }

        for device in self.hvac.ventilation_system.device_collection.devices:
            # Supply duct row
            data["Unit"].append(device.display_name)
            data["Duct Direction"].append("Supply")
            data["Type"].append(device.ducting.supply_ducting.duct_type.name)
            data["(1) a-Approx. (W/K)"].append(device.ducting.supply_ducting.alpha_approximation_iteration_1)
            data["(1) k-Approx. (W/mk)"].append(
                device.ducting.supply_ducting.thermal_transmittance_approximation_iteration_1
            )
            data["(1) Temp-Difference (K)"].append(
                device.ducting.supply_ducting.surface_temperature_difference_iteration_1
            )
            data["(2) a-Approx. (W/K)"].append(device.ducting.supply_ducting.alpha_approximation_iteration_2)
            data["(2) k-Approx. (W/mk)"].append(
                device.ducting.supply_ducting.thermal_transmittance_approximation_iteration_2
            )
            data["(2) Temp-Difference (K)"].append(
                device.ducting.supply_ducting.surface_temperature_difference_iteration_2
            )
            data["(3) a-Approx. (W/K)"].append(device.ducting.supply_ducting.alpha_approximation_iteration_3)
            data["(3) k-Approx. (W/mk)"].append(
                device.ducting.supply_ducting.thermal_transmittance_approximation_iteration_3
            )
            data["(3) Temp-Difference (K)"].append(
                device.ducting.supply_ducting.surface_temperature_difference_iteration_3
            )
            data["(4) a-Approx. (W/K)"].append(device.ducting.supply_ducting.alpha_approximation_iteration_4)
            data["(4) k-Approx. (W/mk)"].append(
                device.ducting.supply_ducting.thermal_transmittance_approximation_iteration_4
            )
            data["(4) Temp-Difference (K)"].append(
                device.ducting.supply_ducting.surface_temperature_difference_iteration_4
            )
            data["(5) a-Approx. (W/K)"].append(device.ducting.supply_ducting.alpha_approximation_iteration_5)
            data["(5) k-Approx. (W/mk)"].append(
                device.ducting.supply_ducting.thermal_transmittance_approximation_iteration_5
            )
            data["(5) Temp-Difference (K)"].append(
                device.ducting.supply_ducting.surface_temperature_difference_iteration_5
            )

            # Exhaust duct row
            data["Unit"].append(device.display_name)
            data["Duct Direction"].append("Exhaust")
            data["Type"].append(device.ducting.exhaust_ducting.duct_type.name)
            data["(1) a-Approx. (W/K)"].append(device.ducting.exhaust_ducting.alpha_approximation_iteration_1)
            data["(1) k-Approx. (W/mk)"].append(
                device.ducting.exhaust_ducting.thermal_transmittance_approximation_iteration_1
            )
            data["(1) Temp-Difference (K)"].append(
                device.ducting.exhaust_ducting.surface_temperature_difference_iteration_1
            )
            data["(2) a-Approx. (W/K)"].append(device.ducting.exhaust_ducting.alpha_approximation_iteration_2)
            data["(2) k-Approx. (W/mk)"].append(
                device.ducting.exhaust_ducting.thermal_transmittance_approximation_iteration_2
            )
            data["(2) Temp-Difference (K)"].append(
                device.ducting.exhaust_ducting.surface_temperature_difference_iteration_2
            )
            data["(3) a-Approx. (W/K)"].append(device.ducting.exhaust_ducting.alpha_approximation_iteration_3)
            data["(3) k-Approx. (W/mk)"].append(
                device.ducting.exhaust_ducting.thermal_transmittance_approximation_iteration_3
            )
            data["(3) Temp-Difference (K)"].append(
                device.ducting.exhaust_ducting.surface_temperature_difference_iteration_3
            )
            data["(4) a-Approx. (W/K)"].append(device.ducting.exhaust_ducting.alpha_approximation_iteration_4)
            data["(4) k-Approx. (W/mk)"].append(
                device.ducting.exhaust_ducting.thermal_transmittance_approximation_iteration_4
            )
            data["(4) Temp-Difference (K)"].append(
                device.ducting.exhaust_ducting.surface_temperature_difference_iteration_4
            )
            data["(5) a-Approx. (W/K)"].append(device.ducting.exhaust_ducting.alpha_approximation_iteration_5)
            data["(5) k-Approx. (W/mk)"].append(
                device.ducting.exhaust_ducting.thermal_transmittance_approximation_iteration_5
            )
            data["(5) Temp-Difference (K)"].append(
                device.ducting.exhaust_ducting.surface_temperature_difference_iteration_5
            )

        return pd.DataFrame(data)

    def get_column_formats(self) -> dict[str, ColumnFormat]:
        """Specify formatting for numeric columns."""
        return {
            "(1) a-Approx. (W/K)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "(1) k-Approx. (W/mk)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "(1) Temp-Difference (K)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "(2) a-Approx. (W/K)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "(2) k-Approx. (W/mk)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "(2) Temp-Difference (K)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "(3) a-Approx. (W/K)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "(3) k-Approx. (W/mk)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "(3) Temp-Difference (K)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "(4) a-Approx. (W/K)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "(4) k-Approx. (W/mk)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "(4) Temp-Difference (K)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "(5) a-Approx. (W/K)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "(5) k-Approx. (W/mk)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "(5) Temp-Difference (K)": ColumnFormat(decimal_places=3, thousands_separator=False),
        }

    def render(
        self,
        format: OutputFormat = "console",
        output_path: str | None = None,
        width: int | None = None,
    ) -> str:
        """Render the table in the specified format."""
        df = self.build_dataframe()
        formats = self.get_column_formats()

        if format == "console":
            return render_dataframe_to_console(df, self.title, None, formats, width)
        elif format == "txt":
            return render_dataframe_to_txt(df, self.title, None, formats, output_path, width or 200)
        elif format == "html":
            return render_dataframe_to_html(df, self.title, None, formats, output_path, width or 200)
        elif format == "csv":
            return render_dataframe_to_csv(df, output_path)
        else:
            raise ValueError(f"Unknown format: {format}")


@dataclass
class VentilationDuctNusseltNumberTable(TableViewProtocol):
    """Ventilation duct Nusselt number calculations from PHPP."""

    hvac: OpPhHVAC

    @property
    def title(self) -> str:
        return "Duct Nusselt Number Results"

    @property
    def phpp_reference(self) -> str:
        return "PHPP-10 | Addl Vent | BU127:CA146"

    def build_dataframe(self) -> pd.DataFrame:
        """Build DataFrame with duct Nusselt number calculations."""
        data = {
            "Unit": [],
            "Duct Direction": [],
            "Type": [],
            "Airflow Velocity [Rect Ducts]": [],
            "Reynolds Number [Rect Ducts]": [],
            "Nusselt Number [Rect Ducts]": [],
            "Airflow Velocity [Round Ducts]": [],
            "Reynolds Number [Round Ducts]": [],
            "Nusselt Number [Round Ducts]": [],
            "Duct R-Value (mk/W)": [],
        }

        for device in self.hvac.ventilation_system.device_collection.devices:
            # Supply duct row
            data["Unit"].append(device.display_name)
            data["Duct Direction"].append("Supply")
            data["Type"].append(device.ducting.supply_ducting.duct_type.name)
            data["Airflow Velocity [Rect Ducts]"].append(device.ducting.supply_ducting.air_velocity_rectangular_m_s)
            data["Reynolds Number [Rect Ducts]"].append(device.ducting.supply_ducting.reynolds_number_rectangular)
            data["Nusselt Number [Rect Ducts]"].append(device.ducting.supply_ducting.nusselt_number_rectangular)
            data["Airflow Velocity [Round Ducts]"].append(device.ducting.supply_ducting.air_velocity_round_m_s)
            data["Reynolds Number [Round Ducts]"].append(device.ducting.supply_ducting.reynolds_number_round)
            data["Nusselt Number [Round Ducts]"].append(device.ducting.supply_ducting.nusselt_number_round)
            data["Duct R-Value (mk/W)"].append(device.ducting.supply_ducting.insulation_thermal_resistance_per_m)

            # Exhaust duct row
            data["Unit"].append(device.display_name)
            data["Duct Direction"].append("Exhaust")
            data["Type"].append(device.ducting.exhaust_ducting.duct_type.name)
            data["Airflow Velocity [Rect Ducts]"].append(device.ducting.exhaust_ducting.air_velocity_rectangular_m_s)
            data["Reynolds Number [Rect Ducts]"].append(device.ducting.exhaust_ducting.reynolds_number_rectangular)
            data["Nusselt Number [Rect Ducts]"].append(device.ducting.exhaust_ducting.nusselt_number_rectangular)
            data["Airflow Velocity [Round Ducts]"].append(device.ducting.exhaust_ducting.air_velocity_round_m_s)
            data["Reynolds Number [Round Ducts]"].append(device.ducting.exhaust_ducting.reynolds_number_round)
            data["Nusselt Number [Round Ducts]"].append(device.ducting.exhaust_ducting.nusselt_number_round)
            data["Duct R-Value (mk/W)"].append(device.ducting.exhaust_ducting.insulation_thermal_resistance_per_m)

        return pd.DataFrame(data)

    def get_column_formats(self) -> dict[str, ColumnFormat]:
        """Specify formatting for numeric columns."""
        return {
            "Airflow Velocity [Rect Ducts]": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Reynolds Number [Rect Ducts]": ColumnFormat(decimal_places=3, thousands_separator=True),
            "Nusselt Number [Rect Ducts]": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Airflow Velocity [Round Ducts]": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Reynolds Number [Round Ducts]": ColumnFormat(decimal_places=3, thousands_separator=True),
            "Nusselt Number [Round Ducts]": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Duct R-Value (mk/W)": ColumnFormat(decimal_places=3, thousands_separator=False),
        }

    def render(
        self,
        format: OutputFormat = "console",
        output_path: str | None = None,
        width: int | None = None,
    ) -> str:
        """Render the table in the specified format."""
        df = self.build_dataframe()
        formats = self.get_column_formats()

        if format == "console":
            return render_dataframe_to_console(df, self.title, None, formats, width)
        elif format == "txt":
            return render_dataframe_to_txt(df, self.title, None, formats, output_path, width or 200)
        elif format == "html":
            return render_dataframe_to_html(df, self.title, None, formats, output_path, width or 200)
        elif format == "csv":
            return render_dataframe_to_csv(df, output_path)
        else:
            raise ValueError(f"Unknown format: {format}")
