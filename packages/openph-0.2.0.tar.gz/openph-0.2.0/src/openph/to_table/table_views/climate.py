# -*- coding: utf-8 -*-
# -*- Python Version: 3.10 -*-

"""Table views for PHPP | Climate | Calculation-Step Tables."""

import pandas as pd
from openph.model.climate import (
    OpPhClimate,
    OpPhClimatePeakCoolingLoad,
    OpPhClimatePeakHeatingLoad,
)
from openph.to_table.renderers import (
    render_dataframe_to_console,
    render_dataframe_to_csv,
    render_dataframe_to_html,
    render_dataframe_to_txt,
)
from openph.to_table.table_protocol import ColumnFormat, OutputFormat, TableViewProtocol


class AnnualClimateDataTable(TableViewProtocol):
    """Annual climate data from PHPP."""

    def __init__(self, climate: OpPhClimate):
        self._climate = climate

    @property
    def title(self) -> str:
        return "Climate Data (PHPP-10 | Climate | E26:P33)"

    @property
    def phpp_reference(self) -> str:
        return "Climate | E26:P33"

    def build_dataframe(self) -> pd.DataFrame:
        """Build DataFrame with raw annual climate data."""
        period_names = [p.display_name for p in self._climate.periods]

        data: dict[str, list[str | int | float]] = {
            "Type": [
                "24 | Period Days",
                "26 | Exterior Temperature",
                "27 | Radiation - North",
                "28 | Radiation - East",
                "29 | Radiation - South",
                "30 | Radiation - West",
                "31 | Radiation - Hori",
                "32 | Dew-point Temperature",
                "33 | Sky Temperature",
                "42 | Share of Max Loss to Cover",
                "42 | HT-Factor",
            ]
        }

        for i, period_name in enumerate(period_names):
            data[period_name] = [
                self._climate.period_days[i],
                self._climate.temperature_air_c[i],
                self._climate.radiation_north_kwh_m2[i],
                self._climate.radiation_east_kwh_m2[i],
                self._climate.radiation_south_kwh_m2[i],
                self._climate.radiation_west_kwh_m2[i],
                self._climate.radiation_global_kwh_m2[i],
                self._climate.temperature_dewpoint_C[i],
                self._climate.temperature_sky_c[i],
                self._climate.share_of_maximum_losses_to_be_covered[i],
                self._climate.h_t_factor[i],
            ]

        return pd.DataFrame(data)

    def get_column_formats(self) -> dict[str, ColumnFormat]:
        """Specify formatting for numeric columns."""
        formats = {}
        for period in self._climate.periods:
            formats[period.display_name] = ColumnFormat(decimal_places=1, thousands_separator=True)
        return formats

    def build_summary(self) -> str | None:
        """Build summary with additional climate info."""
        lines = []
        lines.append(f"K9  | Heating Period Days: {self._climate.heating_period_days:,.1f}")
        lines.append(f"K10 | Heating Gt: {self._climate.heating_degree_hours:,.1f}")
        return "\n".join(lines)

    def render(self, format: OutputFormat = "console", output_path: str | None = None, width: int | None = None) -> str:
        """Render annual climate data table."""
        df = self.build_dataframe()
        formats = self.get_column_formats()
        summary = self.build_summary()

        if format == "console":
            return render_dataframe_to_console(df, self.title, summary, formats, width)
        elif format == "txt":
            return render_dataframe_to_txt(df, self.title, summary, formats, output_path, width or 200)
        elif format == "html":
            return render_dataframe_to_html(df, self.title, summary, formats, output_path, width or 200)
        elif format == "csv":
            return render_dataframe_to_csv(df, output_path)
        else:
            raise ValueError(f"Unknown format: {format}")


class PeakLoadClimateDataTable(TableViewProtocol):
    """Peak load climate data from PHPP."""

    def __init__(self, climate: OpPhClimate):
        self._climate = climate

    @property
    def title(self) -> str:
        return "Peak Load Climate Data (PHPP-10 | Climate | Q23:T36)"

    @property
    def phpp_reference(self) -> str:
        return "Climate | Q23:T36"

    def build_dataframe(self) -> pd.DataFrame:
        """Build DataFrame with peak load climate data."""
        periods: list[OpPhClimatePeakCoolingLoad | OpPhClimatePeakHeatingLoad] = [
            self._climate.peak_heating_1,
            self._climate.peak_heating_2,
            self._climate.peak_cooling_1,
            self._climate.peak_cooling_2,
        ]

        data: dict[str, list[str | int | float]] = {
            "Type": [
                "26 | Exterior Temperature",
                "27 | Radiation - North",
                "28 | Radiation - East",
                "29 | Radiation - South",
                "30 | Radiation - West",
                "31 | Radiation - Hori",
                "32 | Dew-point Temperature",
                "33 | Sky Temperature",
                "35 | Ground Temperature",
            ],
            "Unit": ["C", "kwh/m2", "kwh/m2", "kwh/m2", "kwh/m2", "kwh/m2", "C", "C", "C"],
            "Heating - 1": [
                periods[0].temperature_air_c,
                periods[0].radiation_north_kwh_m2,
                periods[0].radiation_east_kwh_m2,
                periods[0].radiation_south_kwh_m2,
                periods[0].radiation_west_kwh_m2,
                periods[0].radiation_horizontal_kwh_m2,
                periods[0].temperature_dewpoint_c,
                periods[0].temperature_sky_c,
                periods[0].temperature_ground_c,
            ],
            "Heating - 2": [
                periods[1].temperature_air_c,
                periods[1].radiation_north_kwh_m2,
                periods[1].radiation_east_kwh_m2,
                periods[1].radiation_south_kwh_m2,
                periods[1].radiation_west_kwh_m2,
                periods[1].radiation_horizontal_kwh_m2,
                periods[1].temperature_dewpoint_c,
                periods[1].temperature_sky_c,
                periods[1].temperature_ground_c,
            ],
            "Cooling - 1": [
                periods[2].temperature_air_c,
                periods[2].radiation_north_kwh_m2,
                periods[2].radiation_east_kwh_m2,
                periods[2].radiation_south_kwh_m2,
                periods[2].radiation_west_kwh_m2,
                periods[2].radiation_horizontal_kwh_m2,
                periods[2].temperature_dewpoint_c,
                periods[2].temperature_sky_c,
                periods[2].temperature_ground_c,
            ],
            "Cooling - 2": [
                periods[3].temperature_air_c,
                periods[3].radiation_north_kwh_m2,
                periods[3].radiation_east_kwh_m2,
                periods[3].radiation_south_kwh_m2,
                periods[3].radiation_west_kwh_m2,
                periods[3].radiation_horizontal_kwh_m2,
                periods[3].temperature_dewpoint_c,
                periods[3].temperature_sky_c,
                periods[3].temperature_ground_c,
            ],
        }

        return pd.DataFrame(data)

    def get_column_formats(self) -> dict[str, ColumnFormat]:
        """Specify formatting for numeric columns."""
        return {
            "Heating - 1": ColumnFormat(decimal_places=2, thousands_separator=True),
            "Heating - 2": ColumnFormat(decimal_places=2, thousands_separator=True),
            "Cooling - 1": ColumnFormat(decimal_places=2, thousands_separator=True),
            "Cooling - 2": ColumnFormat(decimal_places=2, thousands_separator=True),
        }

    def build_summary(self) -> str | None:
        """No summary for this table."""
        return None

    def render(self, format: OutputFormat = "console", output_path: str | None = None, width: int | None = None) -> str:
        """Render peak load climate data table."""
        df = self.build_dataframe()
        formats = self.get_column_formats()
        summary = self.build_summary()

        if format == "console":
            return render_dataframe_to_console(df, self.title, summary, formats, width)
        elif format == "txt":
            return render_dataframe_to_txt(df, self.title, summary, formats, output_path, width or 200)
        elif format == "html":
            return render_dataframe_to_html(df, self.title, summary, formats, output_path, width or 200)
        elif format == "csv":
            return render_dataframe_to_csv(df, output_path)
        else:
            raise ValueError(f"Unknown format: {format}")
