# -*- coding: utf-8 -*-
# -*- Python Version: 3.10 -*-

"""Table views for PHPP | Addl Vent | Rooms."""

import pandas as pd
from openph.model.rooms import OpPhRooms
from openph.to_table.renderers import (
    render_dataframe_to_console,
    render_dataframe_to_csv,
    render_dataframe_to_html,
    render_dataframe_to_txt,
)
from openph.to_table.table_protocol import ColumnFormat, OutputFormat, TableViewProtocol


class RoomVentilationPropertiesTable(TableViewProtocol):
    """Room ventilation properties from PHPP."""

    def __init__(self, rooms: OpPhRooms):
        self._rooms = rooms

    @property
    def title(self) -> str:
        return "Room Ventilation Properties (PHPP-10 | Addl Vent | C56:M85)"

    @property
    def phpp_reference(self) -> str:
        return "Addl Vent | C56:M85"

    def build_dataframe(self) -> pd.DataFrame:
        """Build DataFrame with room ventilation properties."""
        data: dict[str, list] = {
            "Name": [],
            "Gross Floor Area (M2)": [],
            "TFA Factor": [],
            "TFA (M2)": [],
            "Height (M)": [],
            "Vn50 (M3)": [],
            "Vv (M3)": [],
            "V_sup (m3/h)": [],
            "V_eta (m3/h)": [],
            "V_trans (m3/h)": [],
            "Room ACH": [],
        }

        for rooms in self._rooms.rooms_by_ventilation_device.values():
            for room in rooms:
                data["Name"].append(room.display_name)
                data["Gross Floor Area (M2)"].append(room.floor_area_m2)
                data["TFA Factor"].append(room.weighting_factor)
                data["TFA (M2)"].append(room.weighted_floor_area_m2)
                data["Height (M)"].append(room.clear_height_m)
                data["Vn50 (M3)"].append(room.net_volume_m3)
                data["Vv (M3)"].append(room.ventilated_volume_m3)
                data["V_sup (m3/h)"].append(room.ventilation.load.supply_airflow_m3_h)
                data["V_eta (m3/h)"].append(room.ventilation.load.exhaust_airflow_m3_h)
                data["V_trans (m3/h)"].append(room.ventilation.load.transfer_airflow_m3_h)
                data["Room ACH"].append(room.ventilation_design_ach)

        return pd.DataFrame(data)

    def get_column_formats(self) -> dict[str, ColumnFormat]:
        """Specify formatting for numeric columns."""
        return {
            "Gross Floor Area (M2)": ColumnFormat(decimal_places=1, thousands_separator=True),
            "TFA Factor": ColumnFormat(decimal_places=1, thousands_separator=False),
            "TFA (M2)": ColumnFormat(decimal_places=1, thousands_separator=False),
            "Height (M)": ColumnFormat(decimal_places=1, thousands_separator=False),
            "Vn50 (M3)": ColumnFormat(decimal_places=1, thousands_separator=True),
            "Vv (M3)": ColumnFormat(decimal_places=1, thousands_separator=True),
            "V_sup (m3/h)": ColumnFormat(decimal_places=1, thousands_separator=True),
            "V_eta (m3/h)": ColumnFormat(decimal_places=1, thousands_separator=True),
            "V_trans (m3/h)": ColumnFormat(decimal_places=1, thousands_separator=True),
            "Room ACH": ColumnFormat(decimal_places=2, thousands_separator=True),
        }

    def build_summary(self) -> str | None:
        """No summary for this table."""
        return None

    def render(self, format: OutputFormat = "console", output_path: str | None = None, width: int | None = None) -> str:
        """Render room ventilation properties table."""
        df = self.build_dataframe()
        formats = self.get_column_formats()
        summary = self.build_summary()

        if format == "console":
            return render_dataframe_to_console(df, self.title, summary, formats, width)
        elif format == "txt":
            return render_dataframe_to_txt(df, self.title, summary, formats, output_path, width or 200)
        elif format == "html":
            return render_dataframe_to_html(df, self.title, summary, formats, output_path, width or 200)
        elif format == "csv":
            return render_dataframe_to_csv(df, output_path)
        else:
            raise ValueError(f"Unknown format: {format}")


class RoomVentilationScheduleTable(TableViewProtocol):
    """Room ventilation schedule from PHPP."""

    def __init__(self, rooms: OpPhRooms):
        self._rooms = rooms

    @property
    def title(self) -> str:
        return "Room Ventilation Schedule (PHPP-10 | Addl Vent | N56:Z85)"

    @property
    def phpp_reference(self) -> str:
        return "Addl Vent | N56:Z85"

    def build_dataframe(self) -> pd.DataFrame:
        """Build DataFrame with room ventilation schedule."""
        data: dict[str, list] = {
            "Name": [],
            "H/d": [],
            "d/week": [],
            "holidays/year": [],
            "Reduction Factor 1": [],
            "Operation Factor 1": [],
            "Reduction Factor 2": [],
            "Operation Factor 2": [],
            "Reduction Factor 3": [],
            "Operation Factor 3": [],
            "Reduction Factor 4": [],
            "Operation Factor 4": [],
            "Annual Avg. V_Sup (m3/h)": [],
            "Annual Avg. V_Eta (m3/h)": [],
            "Annual Avg. V_Trans (m3/h)": [],
            "Room ACH": [],
        }

        for rooms in self._rooms.rooms_by_ventilation_device.values():
            for room in rooms:
                data["Name"].append(room.display_name)
                data["H/d"].append(room.ventilation.schedule.operating_hours)
                data["d/week"].append(room.ventilation.schedule.operating_days)
                data["holidays/year"].append(room.ventilation.schedule.holiday_days)
                data["Reduction Factor 1"].append(
                    room.ventilation.schedule.operating_periods.high.period_operation_speed
                )
                data["Operation Factor 1"].append(
                    room.ventilation.schedule.operating_periods.high.period_operating_percentage
                )
                data["Reduction Factor 2"].append(
                    room.ventilation.schedule.operating_periods.standard.period_operation_speed
                )
                data["Operation Factor 2"].append(
                    room.ventilation.schedule.operating_periods.standard.period_operating_percentage
                )
                data["Reduction Factor 3"].append(
                    room.ventilation.schedule.operating_periods.basic.period_operation_speed
                )
                data["Operation Factor 3"].append(
                    room.ventilation.schedule.operating_periods.basic.period_operating_percentage
                )
                data["Reduction Factor 4"].append(
                    room.ventilation.schedule.operating_periods.minimum.period_operation_speed
                )
                data["Operation Factor 4"].append(
                    room.ventilation.schedule.operating_periods.minimum.period_operating_percentage
                )
                data["Annual Avg. V_Sup (m3/h)"].append(room.average_annual_supply_airflow_rate_m3_h)
                data["Annual Avg. V_Eta (m3/h)"].append(room.average_annual_exhaust_airflow_rate_m3_h)
                data["Annual Avg. V_Trans (m3/h)"].append(room.average_annual_transfer_airflow_rate_m3_h)
                data["Room ACH"].append(room.average_annual_ach)

        return pd.DataFrame(data)

    def get_column_formats(self) -> dict[str, ColumnFormat]:
        """Specify formatting for numeric columns."""
        return {
            "Reduction Factor 1": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Operation Factor 1": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Reduction Factor 2": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Operation Factor 2": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Reduction Factor 3": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Operation Factor 3": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Reduction Factor 4": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Operation Factor 4": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Annual Avg. V_Sup (m3/h)": ColumnFormat(decimal_places=1, thousands_separator=True),
            "Annual Avg. V_Eta (m3/h)": ColumnFormat(decimal_places=1, thousands_separator=True),
            "Annual Avg. V_Trans (m3/h)": ColumnFormat(decimal_places=1, thousands_separator=True),
            "Room ACH": ColumnFormat(decimal_places=2, thousands_separator=True),
        }

    def build_summary(self) -> str | None:
        """No summary for this table."""
        return None

    def render(self, format: OutputFormat = "console", output_path: str | None = None, width: int | None = None) -> str:
        """Render room ventilation schedule table."""
        df = self.build_dataframe()
        formats = self.get_column_formats()
        summary = self.build_summary()

        if format == "console":
            return render_dataframe_to_console(df, self.title, summary, formats, width)
        elif format == "txt":
            return render_dataframe_to_txt(df, self.title, summary, formats, output_path, width or 200)
        elif format == "html":
            return render_dataframe_to_html(df, self.title, summary, formats, output_path, width or 200)
        elif format == "csv":
            return render_dataframe_to_csv(df, output_path)

        else:
            raise ValueError(f"Unknown format: {format}")
