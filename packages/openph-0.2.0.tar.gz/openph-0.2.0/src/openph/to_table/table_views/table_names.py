# -*- coding: utf-8 -*-
# -*- Python Version: 3.10 -*-

"""Table name constants for type-safe table lookups.

Provides constants for all core table names, enabling:
- IDE autocomplete
- Type safety
- Avoiding typos
- Easy discoverability

Example:
    >>> from openph.to_table import TableDisplayManager, TableNames
    >>>
    >>> display = TableDisplayManager(phpp)
    >>> table = display.get_table(TableNames.CLIMATE_ANNUAL)  # Type-safe!
    >>> table.render(format="console")
"""


class TableNames:
    """Constants for core table view names.

    Use these constants instead of string literals for type-safe table lookups.
    Plugin packages can extend this class or define their own constants.
    """

    # Climate tables
    CLIMATE_ANNUAL = "climate_annual"
    CLIMATE_PEAK_LOAD = "climate_peak_load"
    CLIMATE_RADIATION_FACTORS = "climate_radiation_factors"

    # Room tables
    ROOMS_VENTILATION_PROPERTIES = "rooms_ventilation_properties"
    ROOMS_VENTILATION_SCHEDULE = "rooms_ventilation_schedule"

    # Ventilation tables
    VENTILATION_DUCT_INPUTS = "ventilation_duct_inputs"
    VENTILATION_DUCT_RESULTS = "ventilation_duct_results"
    VENTILATION_DUCT_ITERATIVE_SOLVER = "ventilation_duct_iterative_solver"
    VENTILATION_DUCT_NUSSELT_NUMBER = "ventilation_duct_nusselt_number"

    # Areas tables
    AREAS_SUMMARY = "areas_summary"
    AREAS_OPAQUE_SURFACE_ATTRIBUTES = "areas_opaque_surface_attributes"
    AREAS_OPAQUE_SURFACE_HEAT_GAIN = "areas_opaque_surface_heat_gain"
    AREAS_APERTURE_SURFACES = "areas_aperture_surfaces"
    AREAS_APERTURE_HEAT_GAIN = "areas_aperture_heat_gain"
    AREAS_SOLAR_REDUCTION_WINTER = "areas_solar_reduction_winter"
    AREAS_SOLAR_REDUCTION_SUMMER = "areas_solar_reduction_summer"

    @classmethod
    def all_core_tables(cls) -> list[str]:
        """Get all core table names as a list."""
        return [
            getattr(cls, attr)
            for attr in dir(cls)
            if not attr.startswith("_") and isinstance(getattr(cls, attr), str) and attr.isupper()
        ]
