# -*- coding: utf-8 -*-
# -*- Python Version: 3.10 -*-

"""Table views for PHPP | Areas | Calculation-Step Tables."""

from typing import Any

import pandas as pd
from openph.model.areas import (
    OpPhApertureSurface,
    OpPhAreas,
    OpPhOpaqueSurface,
)
from openph.model.enums import Season
from openph.to_table.renderers import (
    render_dataframe_to_console,
    render_dataframe_to_csv,
    render_dataframe_to_html,
    render_dataframe_to_txt,
)
from openph.to_table.table_protocol import ColumnFormat, OutputFormat, TableViewProtocol


def _get_nested_attr(s: OpPhOpaqueSurface | OpPhApertureSurface, a: str) -> Any:
    """Return nested attribute from an object.

    ie: "heat_gain.summer.non_perpendicular_radiation" -> s.heat_gain.summer.non_perpendicular_radiation
    """
    attrs = a.split(".")
    for attr in attrs:
        s = getattr(s, attr)
    return s


class OpaqueSurfaceAttributesTable(TableViewProtocol):
    """Opaque surface attributes from PHPP."""

    def __init__(self, areas: OpPhAreas):
        self._areas = areas

    @property
    def title(self) -> str:
        return "Opaque Surface Attributes (PHPP-10 | Areas | L41:AJ140)"

    @property
    def phpp_reference(self) -> str:
        return "Areas | L41:AJ140"

    def build_dataframe(self) -> pd.DataFrame:
        """Build DataFrame with opaque surface attributes."""
        data: dict[str, list] = {
            "ID.": [],
            "Name": [],
            "Quan.": [],
            "Exposure": [],
            "Type": [],
            "Gross Area (m2)": [],
            "Net Area (m2)": [],
            "Construction Type": [],
            "U-Value (W/m2K)": [],
            "Deg. from North": [],
            "Deg. from Horiz.": [],
            "Orientation": [],
        }

        for s in self._areas._opaque_surface_list:
            data["ID."].append(s.id_num)
            data["Name"].append(s.display_name)
            data["Quan."].append(s.quantity)
            data["Exposure"].append(s.exposure_exterior.name)
            data["Type"].append(s.face_type.name)
            data["Gross Area (m2)"].append(s.area_m2)
            data["Net Area (m2)"].append(s.net_area_m2)
            data["Construction Type"].append(s.construction.display_name)
            data["U-Value (W/m2K)"].append(s.u_value_W_m2_k)
            data["Deg. from North"].append(s.cardinal_orientation_angle)
            data["Deg. from Horiz."].append(s.angle_from_horizontal)
            data["Orientation"].append(s.cardinal_orientation_name)

        return pd.DataFrame(data)

    def get_column_formats(self) -> dict[str, ColumnFormat]:
        """Specify formatting for numeric columns."""
        return {
            "ID.": ColumnFormat(decimal_places=0, thousands_separator=False),
            "Gross Area (m2)": ColumnFormat(decimal_places=1, thousands_separator=True),
            "Net Area (m2)": ColumnFormat(decimal_places=1, thousands_separator=True),
            "U-Value (W/m2K)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Deg. from North": ColumnFormat(decimal_places=1, thousands_separator=False),
            "Deg. from Horiz.": ColumnFormat(decimal_places=1, thousands_separator=False),
        }

    def build_summary(self) -> str | None:
        """No summary for this table."""
        return None

    def render(self, format: OutputFormat = "console", output_path: str | None = None, width: int | None = None) -> str:
        """Render opaque surface attributes table."""
        df = self.build_dataframe()
        formats = self.get_column_formats()
        summary = self.build_summary()

        if format == "console":
            return render_dataframe_to_console(df, self.title, summary, formats, width)
        elif format == "txt":
            return render_dataframe_to_txt(df, self.title, summary, formats, output_path, width or 200)
        elif format == "html":
            return render_dataframe_to_html(df, self.title, summary, formats, output_path, width or 200)
        elif format == "csv":
            return render_dataframe_to_csv(df, output_path)
        else:
            raise ValueError(f"Unknown format: {format}")


class OpaqueSurfaceHeatGainTable(TableViewProtocol):
    """Opaque surface heat gain from PHPP."""

    def __init__(self, areas: OpPhAreas):
        self._areas = areas

    @property
    def title(self) -> str:
        return "Opaque Surface Heat Gain (PHPP-10 | Areas | L41:BU140)"

    @property
    def phpp_reference(self) -> str:
        return "Areas | L41:BU140"

    def build_dataframe(self) -> pd.DataFrame:
        """Build DataFrame with opaque surface heat gain."""
        data: dict[str, list] = {
            "ID.": [],
            "Name": [],
            "Shading Factor": [],
            "Ext. Absorptance": [],
            "Ext. Emissivity": [],
            "Conductance Fac. (W/K)": [],
            "BR | α-Sky": [],
            "BS | α-Air": [],
            "BT | Radiative Fac. (W/K)": [],
            "BU | Convective Fac. (W/K)": [],
        }

        for s in self._areas._opaque_surface_list:
            data["ID."].append(s.id_num)
            data["Name"].append(s.display_name)
            data["Shading Factor"].append(s.heat_gain.winter.shading_factor)
            data["Ext. Absorptance"].append(s.absorptance)
            data["Ext. Emissivity"].append(s.emissivity)
            data["Conductance Fac. (W/K)"].append(s.heat_loss_factor_W_K)
            data["BR | α-Sky"].append(s.heat_gain.winter.alpha_sky)
            data["BS | α-Air"].append(s.heat_gain.winter.alpha_air)
            data["BT | Radiative Fac. (W/K)"].append(s.heat_gain.winter.radiative_factor_W_K)
            data["BU | Convective Fac. (W/K)"].append(s.heat_gain.winter.convective_factor_W_K)

        return pd.DataFrame(data)

    def get_column_formats(self) -> dict[str, ColumnFormat]:
        """Specify formatting for numeric columns."""
        return {
            "ID.": ColumnFormat(decimal_places=0, thousands_separator=False),
            "Shading Factor": ColumnFormat(decimal_places=2, thousands_separator=False),
            "Ext. Absorptance": ColumnFormat(decimal_places=2, thousands_separator=False),
            "Ext. Emissivity": ColumnFormat(decimal_places=2, thousands_separator=False),
            "Conductance Fac. (W/K)": ColumnFormat(decimal_places=2, thousands_separator=False),
            "BR | α-Sky": ColumnFormat(decimal_places=2, thousands_separator=False),
            "BS | α-Air": ColumnFormat(decimal_places=2, thousands_separator=False),
            "BT | Radiative Fac. (W/K)": ColumnFormat(decimal_places=2, thousands_separator=False),
            "BU | Convective Fac. (W/K)": ColumnFormat(decimal_places=2, thousands_separator=False),
        }

    def build_summary(self) -> str | None:
        """No summary for this table."""
        return None

    def render(self, format: OutputFormat = "console", output_path: str | None = None, width: int | None = None) -> str:
        """Render opaque surface heat gain table."""
        df = self.build_dataframe()
        formats = self.get_column_formats()
        summary = self.build_summary()

        if format == "console":
            return render_dataframe_to_console(df, self.title, summary, formats, width)
        elif format == "txt":
            return render_dataframe_to_txt(df, self.title, summary, formats, output_path, width or 200)
        elif format == "html":
            return render_dataframe_to_html(df, self.title, summary, formats, output_path, width or 200)
        elif format == "csv":
            return render_dataframe_to_csv(df, output_path)
        else:
            raise ValueError(f"Unknown format: {format}")


class AreaSummaryTable(TableViewProtocol):
    """Area summary from PHPP."""

    def __init__(self, areas: OpPhAreas):
        self._areas = areas

    @property
    def title(self) -> str:
        return "Areas Summary (PHPP-10 | Areas | K6:P29)"

    @property
    def phpp_reference(self) -> str:
        return "Areas | K6:P29"

    def build_dataframe(self) -> pd.DataFrame:
        """Build DataFrame with area summary."""
        data = {
            "Group Type": [
                "Windows - North",
                "Windows - East",
                "Windows - South",
                "Windows - West",
                "Windows - Horizontal",
                "Ext Wall - Ambient",
                "Ext Wall - Ground",
                "Roof / Ceiling - Ambient",
                "Floor Slab / Basement Ceiling",
            ],
            "Area (m2)": [
                self._areas.windows.north.area_m2,
                self._areas.windows.east.area_m2,
                self._areas.windows.south.area_m2,
                self._areas.windows.west.area_m2,
                self._areas.windows.horizontal.area_m2,
                self._areas.all_walls.above_grade.area_m2,
                self._areas.all_walls.below_grade.area_m2,
                self._areas.all_roofs.above_grade.area_m2,
                self._areas.all_floors.below_grade.area_m2,
            ],
            "Avg. U-Value (W/m2K)": [
                self._areas.windows.north.average_u_value,
                self._areas.windows.east.average_u_value,
                self._areas.windows.south.average_u_value,
                self._areas.windows.west.average_u_value,
                self._areas.windows.horizontal.average_u_value,
                self._areas.all_walls.above_grade.average_u_value,
                self._areas.all_walls.below_grade.average_u_value,
                self._areas.all_roofs.above_grade.average_u_value,
                self._areas.all_floors.below_grade.average_u_value,
            ],
        }

        return pd.DataFrame(data)

    def get_column_formats(self) -> dict[str, ColumnFormat]:
        """Specify formatting for numeric columns."""
        return {
            "Area (m2)": ColumnFormat(decimal_places=1, thousands_separator=True),
            "Avg. U-Value (W/m2K)": ColumnFormat(decimal_places=3, thousands_separator=False),
        }

    def build_summary(self) -> str | None:
        """No summary for this table."""
        return None

    def render(self, format: OutputFormat = "console", output_path: str | None = None, width: int | None = None) -> str:
        """Render area summary table."""
        df = self.build_dataframe()
        formats = self.get_column_formats()
        summary = self.build_summary()

        if format == "console":
            return render_dataframe_to_console(df, self.title, summary, formats, width)
        elif format == "txt":
            return render_dataframe_to_txt(df, self.title, summary, formats, output_path, width or 200)
        elif format == "html":
            return render_dataframe_to_html(df, self.title, summary, formats, output_path, width or 200)
        elif format == "csv":
            return render_dataframe_to_csv(df, output_path)
        else:
            raise ValueError(f"Unknown format: {format}")


class ApertureSurfacesTable(TableViewProtocol):
    """Aperture surface attributes from PHPP."""

    def __init__(self, areas: OpPhAreas):
        self._areas = areas

    @property
    def title(self) -> str:
        return "Window Surface Attributes (PHPP-10 | Windows | L23:BA174)"

    @property
    def phpp_reference(self) -> str:
        return "Windows | L23:BA174"

    def build_dataframe(self) -> pd.DataFrame:
        """Build DataFrame with aperture surface attributes."""
        data: dict[str, list] = {
            "ID.": [],
            "Quan.": [],
            "Name": [],
            "Deg. from North": [],
            "Deg. from Horiz.": [],
            "Orientation": [],
            "Width (m)": [],
            "Height (m)": [],
            "Glass Type": [],
            "Frame Type": [],
            "Win. Area (m2)": [],
            "Glazing Area (m2)": [],
            "Frame Area (m2)": [],
            "U-W-Installed (W/m2K)": [],
        }

        for s in self._areas.windows:
            data["ID."].append(s.id_num)
            data["Quan."].append(s.quantity)
            data["Name"].append(s.display_name)
            data["Deg. from North"].append(s.cardinal_orientation_angle)
            data["Deg. from Horiz."].append(s.angle_from_horizontal)
            data["Orientation"].append(s.cardinal_orientation_name)
            data["Width (m)"].append(s.width_m)
            data["Height (m)"].append(s.height_m)
            data["Glass Type"].append(s.construction.glazing_type_display_name)
            data["Frame Type"].append(s.construction.frame_type_display_name)
            data["Win. Area (m2)"].append(s.area_m2)
            data["Glazing Area (m2)"].append(s.glazing_area_m2)
            data["Frame Area (m2)"].append(s.frame_area_m2)
            data["U-W-Installed (W/m2K)"].append(s.u_value_wm2k)

        return pd.DataFrame(data)

    def get_column_formats(self) -> dict[str, ColumnFormat]:
        """Specify formatting for numeric columns."""
        return {
            "ID.": ColumnFormat(decimal_places=0, thousands_separator=False),
            "Deg. from North": ColumnFormat(decimal_places=1, thousands_separator=False),
            "Deg. from Horiz.": ColumnFormat(decimal_places=1, thousands_separator=False),
            "Width (m)": ColumnFormat(decimal_places=1, thousands_separator=False),
            "Height (m)": ColumnFormat(decimal_places=1, thousands_separator=False),
            "Win. Area (m2)": ColumnFormat(decimal_places=1, thousands_separator=True),
            "Glazing Area (m2)": ColumnFormat(decimal_places=2, thousands_separator=False),
            "Frame Area (m2)": ColumnFormat(decimal_places=2, thousands_separator=False),
            "U-W-Installed (W/m2K)": ColumnFormat(decimal_places=3, thousands_separator=False),
        }

    def build_summary(self) -> str | None:
        """No summary for this table."""
        return None

    def render(self, format: OutputFormat = "console", output_path: str | None = None, width: int | None = None) -> str:
        """Render aperture surfaces table."""
        df = self.build_dataframe()
        formats = self.get_column_formats()
        summary = self.build_summary()

        if format == "console":
            return render_dataframe_to_console(df, self.title, summary, formats, width)
        elif format == "txt":
            return render_dataframe_to_txt(df, self.title, summary, formats, output_path, width or 200)
        elif format == "html":
            return render_dataframe_to_html(df, self.title, summary, formats, output_path, width or 200)
        elif format == "csv":
            return render_dataframe_to_csv(df, output_path)
        else:
            raise ValueError(f"Unknown format: {format}")


class ApertureSurfaceHeatGainTable(TableViewProtocol):
    """Aperture surface heat gain attributes from PHPP."""

    def __init__(self, areas: OpPhAreas):
        self._areas = areas

    @property
    def title(self) -> str:
        return "Window Heat Gain Attributes (PHPP-10 | Windows | JR23:JX174)"

    @property
    def phpp_reference(self) -> str:
        return "Windows | JR23:JX174"

    def build_dataframe(self) -> pd.DataFrame:
        """Build DataFrame with aperture surface heat gain."""
        data: dict[str, list] = {
            "ID.": [],
            "Name": [],
            "U-Value (W/m2K)": [],
            "Frame Eff. Heating Area (m2)": [],
            "Sky-View Fac. (-)": [],
            "α-Sky (W/m2K)": [],
            "α-Air (W/m2K)": [],
            "Radiative Fac. (W/K)": [],
            "Convective Fac. (W/K)": [],
        }

        for s in self._areas.windows:
            data["ID."].append(s.id_num)
            data["Name"].append(s.display_name)
            data["U-Value (W/m2K)"].append(s.u_value_wm2k)
            data["Frame Eff. Heating Area (m2)"].append(s.heat_gain.winter.eff_heat_gain_area_m2)
            data["Sky-View Fac. (-)"].append(s.heat_gain.winter.sky_view)
            data["α-Sky (W/m2K)"].append(s.heat_gain.winter.alpha_sky)
            data["α-Air (W/m2K)"].append(s.heat_gain.winter.alpha_air)
            data["Radiative Fac. (W/K)"].append(s.heat_gain.winter.radiative_factor_W_K)
            data["Convective Fac. (W/K)"].append(s.heat_gain.winter.convective_factor_W_K)

        return pd.DataFrame(data)

    def get_column_formats(self) -> dict[str, ColumnFormat]:
        """Specify formatting for numeric columns."""
        return {
            "ID.": ColumnFormat(decimal_places=0, thousands_separator=False),
            "U-Value (W/m2K)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Frame Eff. Heating Area (m2)": ColumnFormat(decimal_places=4, thousands_separator=False),
            "Sky-View Fac. (-)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "α-Sky (W/m2K)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "α-Air (W/m2K)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Radiative Fac. (W/K)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Convective Fac. (W/K)": ColumnFormat(decimal_places=3, thousands_separator=False),
        }

    def build_summary(self) -> str | None:
        """No summary for this table."""
        return None

    def render(self, format: OutputFormat = "console", output_path: str | None = None, width: int | None = None) -> str:
        """Render aperture surface heat gain table."""
        df = self.build_dataframe()
        formats = self.get_column_formats()
        summary = self.build_summary()

        if format == "console":
            return render_dataframe_to_console(df, self.title, summary, formats, width)
        elif format == "txt":
            return render_dataframe_to_txt(df, self.title, summary, formats, output_path, width or 200)
        elif format == "html":
            return render_dataframe_to_html(df, self.title, summary, formats, output_path, width or 200)
        elif format == "csv":
            return render_dataframe_to_csv(df, output_path)
        else:
            raise ValueError(f"Unknown format: {format}")


class ApertureSeasonalSolarReductionTable(TableViewProtocol):
    """Base class for aperture seasonal solar reduction factors from PHPP.

    This can be instantiated directly with a Season parameter for custom use,
    or use the WinterSolarReductionTable/SummerSolarReductionTable subclasses
    for the unified DisplayManager API.
    """

    def __init__(self, areas: OpPhAreas, season: Season):
        self._areas = areas
        self._season = season

    @property
    def title(self) -> str:
        return f"Window {self._season.name.capitalize()} Solar Reduction Factors (PHPP-10 | Windows | L___:BA____)"

    @property
    def phpp_reference(self) -> str:
        return "Windows | L___:BA____"

    def build_dataframe(self) -> pd.DataFrame:
        """Build DataFrame with seasonal solar reduction factors."""
        data: dict[str, list] = {
            "ID.": [],
            "Quan.": [],
            "Name": [],
            "g-Value (%)": [],
            "Dirt (%)": [],
            "Non-Perpendicular Radiation (%)": [],
            "Shading (%)": [],
            f"{self._season.name.capitalize()} Reduction Fac. (%)": [],
        }

        for s in self._areas.windows:
            season_heat_gain = getattr(s.heat_gain, self._season.name.lower())
            data["ID."].append(s.id_num)
            data["Quan."].append(s.quantity)
            data["Name"].append(s.display_name)
            data["g-Value (%)"].append(s.g_value)
            data["Dirt (%)"].append(season_heat_gain.dirt)
            data["Non-Perpendicular Radiation (%)"].append(season_heat_gain.non_perpendicular_radiation)
            data["Shading (%)"].append(season_heat_gain.shading_factor)
            data[f"{self._season.name.capitalize()} Reduction Fac. (%)"].append(season_heat_gain.total_reduction_factor)

        return pd.DataFrame(data)

    def get_column_formats(self) -> dict[str, ColumnFormat]:
        """Specify formatting for numeric columns."""
        return {
            "ID.": ColumnFormat(decimal_places=0, thousands_separator=False),
            "g-Value (%)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Dirt (%)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Non-Perpendicular Radiation (%)": ColumnFormat(decimal_places=3, thousands_separator=False),
            "Shading (%)": ColumnFormat(decimal_places=3, thousands_separator=False),
            f"{self._season.name.capitalize()} Reduction Fac. (%)": ColumnFormat(
                decimal_places=3, thousands_separator=False
            ),
        }

    def build_summary(self) -> str | None:
        """No summary for this table."""
        return None

    def render(self, format: OutputFormat = "console", output_path: str | None = None, width: int | None = None) -> str:
        """Render seasonal solar reduction table."""
        df = self.build_dataframe()
        formats = self.get_column_formats()
        summary = self.build_summary()

        if format == "console":
            return render_dataframe_to_console(df, self.title, summary, formats, width)
        elif format == "txt":
            return render_dataframe_to_txt(df, self.title, summary, formats, output_path, width or 200)
        elif format == "html":
            return render_dataframe_to_html(df, self.title, summary, formats, output_path, width or 200)
        elif format == "csv":
            return render_dataframe_to_csv(df, output_path)
        else:
            raise ValueError(f"Unknown format: {format}")


class WinterSolarReductionTable(ApertureSeasonalSolarReductionTable):
    """Winter solar reduction factors for DisplayManager API."""

    def __init__(self, areas: OpPhAreas):
        super().__init__(areas, Season.WINTER)


class SummerSolarReductionTable(ApertureSeasonalSolarReductionTable):
    """Summer solar reduction factors for DisplayManager API."""

    def __init__(self, areas: OpPhAreas):
        super().__init__(areas, Season.SUMMER)
