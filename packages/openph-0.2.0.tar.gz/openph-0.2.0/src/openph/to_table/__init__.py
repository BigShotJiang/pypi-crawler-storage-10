# -*- coding: utf-8 -*-
# -*- Python Version: 3.10 -*-

"""Table rendering for PHPP calculation results.

Provides a plugin-based architecture for converting PHPP models to formatted
tables (console, text, HTML, CSV, Excel). Core tables are built-in; plugins
can register additional tables via entry points.

DataFrame-First Architecture:
    All tables build pandas DataFrames with raw data, then render to various
    formats. This provides clean separation between data and presentation.

Example:
    >>> from openph.to_table import TableDisplayManager, TableNames
    >>> from openph.to_table.renderers import render_dataframe_to_csv
    >>>
    >>> display = TableDisplayManager(phpp)
    >>>
    >>> # Type-safe table lookup
    >>> climate = display.get_table(TableNames.CLIMATE_ANNUAL)
    >>> climate.render(format="console")
    >>>
    >>> # Save to file
    >>> climate.render(format="html", output_path="climate.html")
    >>>
    >>> # Access raw data
    >>> df = climate.build_dataframe()
    >>> csv = render_dataframe_to_csv(df, "climate.csv")
"""

# Core infrastructure
# DataFrame utilities (now from separate module)
from openph.to_dataframe import ColumnFormat as ColumnFormat
from openph.to_dataframe import dataframe_to_rich_table as dataframe_to_rich_table
from openph.to_dataframe import format_cell_value as format_cell_value

from .manager import TableDisplayManager as TableDisplayManager
from .manager import TableGroup as TableGroup

# Rendering functions
from .renderers import render_dataframe_to_console as render_dataframe_to_console
from .renderers import render_dataframe_to_csv as render_dataframe_to_csv
from .renderers import render_dataframe_to_html as render_dataframe_to_html
from .renderers import render_dataframe_to_txt as render_dataframe_to_txt

# Protocol and types (re-exported for backward compatibility)
from .table_protocol import OutputFormat as OutputFormat
from .table_protocol import TableViewProtocol as TableViewProtocol

# Core table views
from .table_views.areas import *
from .table_views.climate import *
from .table_views.rooms import *

# Table names
from .table_views.table_names import TableNames as TableNames
from .table_views.ventilation import *
