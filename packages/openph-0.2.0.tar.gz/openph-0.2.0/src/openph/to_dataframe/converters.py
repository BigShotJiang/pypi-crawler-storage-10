# -*- coding: utf-8 -*-
# -*- Python Version: 3.10 -*-

"""DataFrame conversion utilities for different output formats.

This module provides converters from DataFrames to various structured formats.
While some converters are rendering-specific (like Rich tables), they're grouped
here as they all perform DataFrame → Format conversions.
"""

import pandas as pd
from rich.table import Table as RichTable

from openph.to_dataframe.utils import ColumnFormat, format_cell_value


def dataframe_to_rich_table(
    df: pd.DataFrame,
    title: str,
    column_formats: dict[str, ColumnFormat] | None = None,
) -> RichTable:
    """Convert DataFrame to Rich Table with formatting applied.

    This is the primary converter used for console output. It applies
    formatting rules from column_formats and builds a styled Rich table.

    Args:
        df: Raw data DataFrame
        title: Table title
        column_formats: Optional formatting rules per column

    Returns:
        Styled Rich Table ready for console rendering

    Example:
        >>> df = pd.DataFrame({
        ...     'Month': ['Jan', 'Feb'],
        ...     'Energy': [123.456, 234.567]
        ... })
        >>> formats = {'Energy': ColumnFormat(decimal_places=1)}
        >>> table = dataframe_to_rich_table(df, "Monthly Energy", formats)
        >>> # table is ready for Console().print(table)
    """
    table = RichTable(title=title)

    # Add columns
    for col in df.columns:
        # First column (usually labels) left-aligned, others right-aligned
        justify = "left" if col == df.columns[0] else "right"
        table.add_column(col, justify=justify)

    # Add rows with formatting
    for _, row in df.iterrows():
        formatted_row = []
        for col in df.columns:
            value = row[col]
            fmt = column_formats.get(col) if column_formats else None
            formatted_row.append(format_cell_value(value, fmt))
        table.add_row(*formatted_row)

    return table
