# -*- coding: utf-8 -*-
# -*- Python Version: 3.10 -*-

"""Core DataFrame formatting utilities.

This module provides tools for formatting DataFrame cells and columns according
to specified rules. These utilities are rendering-agnostic and work with any
DataFrame-based workflow.
"""

from dataclasses import dataclass
from typing import Any

import pandas as pd


@dataclass
class ColumnFormat:
    """Formatting specification for a DataFrame column.

    Attributes:
        decimal_places: Number of decimal places for numeric values (default: 2)
        thousands_separator: Add commas for thousands (default: False)
        prefix: Optional prefix string (e.g., '$')
        suffix: Optional suffix string (e.g., 'kWh', '%')

    Example:
        >>> fmt = ColumnFormat(decimal_places=1, thousands_separator=True, suffix='kWh')
        >>> # Will format 1234.567 as "1,234.6 kWh"
    """

    decimal_places: int = 2
    thousands_separator: bool = False
    prefix: str = ""
    suffix: str = ""


def format_cell_value(value: Any, fmt: ColumnFormat | None = None) -> str:
    """Format a single cell value according to formatting rules.

    Args:
        value: Raw cell value (numeric, string, etc.)
        fmt: Optional formatting specification

    Returns:
        Formatted string representation

    Example:
        >>> format_cell_value(1234.5678, ColumnFormat(decimal_places=2, thousands_separator=True))
        '1,234.57'
        >>> format_cell_value(50.5, ColumnFormat(decimal_places=1, suffix='%'))
        '50.5%'
    """
    # Handle NaN/None
    if pd.isna(value):
        return ""

    # No formatting specified - simple string conversion
    if fmt is None:
        if isinstance(value, float):
            return f"{value:.2f}"  # Default 2 decimal places for floats
        return str(value)

    # String values - return as-is
    if isinstance(value, str):
        return value

    # Boolean values
    if isinstance(value, bool):
        return str(value)

    # Numeric formatting
    if isinstance(value, (int, float)):
        # Build format string
        if fmt.thousands_separator:
            formatted = f"{value:,.{fmt.decimal_places}f}"
        else:
            formatted = f"{value:.{fmt.decimal_places}f}"

        # Add prefix/suffix
        if fmt.prefix:
            formatted = f"{fmt.prefix}{formatted}"
        if fmt.suffix:
            formatted = f"{formatted} {fmt.suffix}"

        return formatted

    # Fallback
    return str(value)


def apply_column_formats(
    df: pd.DataFrame,
    column_formats: dict[str, ColumnFormat] | None = None,
) -> pd.DataFrame:
    """Apply formatting to DataFrame columns, returning a formatted copy.

    Args:
        df: Input DataFrame with raw data
        column_formats: Optional formatting specs per column

    Returns:
        New DataFrame with formatted string values

    Example:
        >>> df = pd.DataFrame({'A': [1234.567, 8901.234]})
        >>> formats = {'A': ColumnFormat(decimal_places=1, thousands_separator=True)}
        >>> apply_column_formats(df, formats)
             A
        0  1,234.6
        1  8,901.2
    """
    if column_formats is None:
        column_formats = {}

    # Create a copy to avoid modifying original
    df_formatted = df.copy()

    # Apply formatting to each column
    for col in df.columns:
        fmt = column_formats.get(col)
        df_formatted[col] = df[col].apply(lambda x: format_cell_value(x, fmt))

    return df_formatted
