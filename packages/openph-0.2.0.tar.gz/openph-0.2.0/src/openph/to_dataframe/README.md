# DataFrame Utilities (`openph.to_dataframe`)

Core DataFrame transformation utilities for OpenPH. This module is **rendering-agnostic** and provides foundational tools for working with structured data.

## 🎯 Purpose

The `to_dataframe` module handles:
- **Data formatting** (numbers, currencies, percentages)
- **DataFrame transformations** (column formatting, type conversion)
- **Format conversion** (DataFrame → Rich Table, etc.)

This module is independent of `to_table` and can be used for:
- Data analysis workflows
- Custom visualizations
- Export pipelines
- Any DataFrame-based processing

## 📦 Module Structure

```
to_dataframe/
├── __init__.py          # Public API exports
├── utils.py             # Core formatting utilities
├── converters.py        # DataFrame → Format converters
└── README.md            # This file
```

## 🔧 Core Components

### `ColumnFormat` (dataclass)

Declarative formatting specification for DataFrame columns:

```python
from openph.to_dataframe import ColumnFormat

# Currency formatting
price_fmt = ColumnFormat(
    decimal_places=2,
    thousands_separator=True,
    prefix="$"
)

# Energy units
energy_fmt = ColumnFormat(
    decimal_places=1,
    suffix="kWh"
)

# Percentages
percent_fmt = ColumnFormat(
    decimal_places=1,
    suffix="%"
)
```

### `format_cell_value(value, fmt)`

Format a single cell according to rules:

```python
from openph.to_dataframe import format_cell_value, ColumnFormat

# Basic formatting
format_cell_value(1234.567, ColumnFormat(decimal_places=2))
# → "1234.57"

# With thousand separators
format_cell_value(1234.567, ColumnFormat(
    decimal_places=2, 
    thousands_separator=True
))
# → "1,234.57"

# With prefix/suffix
format_cell_value(50.5, ColumnFormat(decimal_places=1, suffix="%"))
# → "50.5 %"
```

### `apply_column_formats(df, column_formats)`

Apply formatting to entire DataFrame:

```python
from openph.to_dataframe import apply_column_formats, ColumnFormat
import pandas as pd

# Raw data
df = pd.DataFrame({
    'Month': ['Jan', 'Feb'],
    'Energy': [1234.567, 2345.678],
    'Cost': [123.45, 234.56]
})

# Define formats
formats = {
    'Energy': ColumnFormat(decimal_places=1, suffix="kWh"),
    'Cost': ColumnFormat(decimal_places=2, prefix="$")
}

# Apply formatting
df_formatted = apply_column_formats(df, formats)
# Energy column: "1234.6 kWh", "2345.7 kWh"
# Cost column: "$123.45", "$234.56"
```

### `dataframe_to_rich_table(df, title, column_formats)`

Convert DataFrame to Rich Table for console display:

```python
from openph.to_dataframe import dataframe_to_rich_table, ColumnFormat
from rich.console import Console

df = pd.DataFrame({
    'Month': ['Jan', 'Feb'],
    'Energy': [123.456, 234.567]
})

formats = {'Energy': ColumnFormat(decimal_places=1, suffix="kWh")}
rich_table = dataframe_to_rich_table(df, "Monthly Energy", formats)

Console().print(rich_table)
```

## 🔄 Separation of Concerns

```
┌─────────────────────────────────────────┐
│  to_dataframe (This Module)            │
│  • Data formatting                      │
│  • DataFrame transformations            │
│  • Format-agnostic utilities            │
└─────────────────────────────────────────┘
                   ▲
                   │ uses
                   │
┌─────────────────────────────────────────┐
│  to_table                               │
│  • Table views (TableViewProtocol)      │
│  • Rendering strategies (console/html)  │
│  • Display management                   │
└─────────────────────────────────────────┘
```

## 💡 Use Cases

### 1. Data Analysis
```python
from openph.to_dataframe import apply_column_formats, ColumnFormat
import pandas as pd

# Build DataFrame from model
df = phpp.climate.build_dataframe()

# Format for readability
formats = phpp.climate.get_column_formats()
df_formatted = apply_column_formats(df, formats)

# Analyze with pandas
monthly_avg = df_formatted.groupby('Month').mean()
```

### 2. Custom Export
```python
from openph.to_dataframe import format_cell_value, ColumnFormat

# Custom CSV writer with specific formatting
for row in dataframe.itertuples():
    formatted_row = [
        format_cell_value(val, formats.get(col))
        for col, val in zip(dataframe.columns, row)
    ]
    csv_writer.writerow(formatted_row)
```

### 3. Plotting Preparation
```python
import matplotlib.pyplot as plt
from openph.to_dataframe import ColumnFormat

# Get raw numeric data (not formatted strings)
df = heating_demand_table.build_dataframe()

# Plot needs raw numbers
plt.plot(df['Month'], df['Heating (kWh)'])

# Format only axis labels
fmt = ColumnFormat(decimal_places=0, thousands_separator=True)
plt.ylabel(format_cell_value(df['Heating (kWh)'].max(), fmt))
```

## ⚠️ Important Notes

1. **Raw vs Formatted Data**
   - `build_dataframe()` returns **raw numbers** (floats/ints)
   - Use `apply_column_formats()` only when you need **string representations**
   - Keep data numeric as long as possible for analysis

2. **Immutability**
   - `apply_column_formats()` returns a **new DataFrame** (copy)
   - Original data is never modified
   - Safe for multiple format applications

3. **Type Conversions**
   - Formatted values become **strings**
   - Cannot perform math on formatted data
   - Format as the last step in your pipeline

## 🔗 Related Modules

- **`to_table`**: Table rendering system (builds on this module)
- **`model`**: Data models that feed into DataFrames
- **`phpp`**: PHPP calculation engine

## 📚 Examples

See `sandbox.py` in the workspace root for complete working examples of:
- Building DataFrames
- Applying formats
- Rendering to multiple formats
- Saving to files
