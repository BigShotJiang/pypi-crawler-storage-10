import os
# --- WARNING SUPPRESSION START ---
# This must be at the VERY top of the file
os.environ["PYGAME_HIDE_SUPPORT_PROMPT"] = "1"
import warnings
# Per user suggestion, use a blanket filter to suppress all warnings
warnings.filterwarnings("ignore")
# --- WARNING SUPPRESSION END ---

import sys
import shutil
import argparse
import subprocess
import contextlib # Import for silencing output
import random

# We no longer import PyInstaller.__main__ at the top

OUTPUT_FOLDER = "Completed Build"
TEMP_MAIN = "main_build.py"
CONFIG_FILE = ".nvlibconfig"
BUILD_LOG = "build-verbose.log"

def save_main_script(filename):
    """Saves the absolute path to the main script."""
    abs_path = os.path.abspath(filename)
    # Store config in the same dir as the cli script for reliability
    # __file__ is the path to this cli.py script
    try:
        cli_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        # Fallback if __file__ isn't defined (e.g., in some interactive sessions)
        cli_dir = os.path.abspath(".")
        
    config_path = os.path.join(cli_dir, CONFIG_FILE)
    
    try:
        with open(config_path, "w", encoding="utf-8") as f:
            f.write(abs_path)
        print(f"[NVLib] Main script set to: {abs_path}")
    except Exception as e:
        print(f"[Error] Could not write config file to {config_path}: {e}")

def load_main_script():
    """Loads the absolute path to the main script."""
    try:
        cli_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        cli_dir = os.path.abspath(".")
        
    config_path = os.path.join(cli_dir, CONFIG_FILE)
    
    if not os.path.exists(config_path):
        print("[Error] Main script not set. Use `nvlib set <file>` first.")
        print(f"(Looking for config at: {config_path})")
        return None
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            return f.read().strip()
    except Exception as e:
        print(f"[Error] Could not read config file from {config_path}: {e}")
        return None

def create_main_copy(main_script_abs, temp_main_abs):
    """Creates the temporary main script with the resource_path injector."""
    try:
        with open(main_script_abs, 'r', encoding='utf-8') as f:
            original_code = f.read()

        patched_code = f"""
import sys, os, builtins

def resource_path(path):
    try:
        base_path = sys._MEIPASS
    except AttributeError:
        # Fallback for when not running as a PyInstaller bundle
        # Use the directory of the main script (sys.argv[0])
        try:
            base_path = os.path.dirname(os.path.abspath(sys.argv[0]))
        except Exception:
            base_path = os.path.abspath(".")
    return os.path.join(base_path, path)

builtins.resource_path = resource_path

{original_code}
"""
        with open(temp_main_abs, 'w', encoding='utf-8') as f:
            f.write(patched_code)
        return True
    except Exception as e:
        print(f"[Error] Failed to create temporary main script: {e}")
        return False

def collect_data_files(project_root):
    """Collects all resource files relative to the project root."""
    data_files = []
    include_exts = (".json", ".ttf", ".jpg", ".jpeg", ".png", ".ico")
    exclude_folders = {"__pycache__", ".git", ".idea", ".venv", "venv", "dist", "build", OUTPUT_FOLDER}
    exclude_files = {TEMP_MAIN, "build.py", os.path.basename(CONFIG_FILE)}

    for root, dirs, files in os.walk(project_root):
        dirs[:] = [d for d in dirs if d not in exclude_folders]
        for file in files:
            if file in exclude_files:
                continue
            if file.lower().endswith(include_exts):
                full_path = os.path.join(root, file)
                # The destination path inside the bundle is relative to the project root
                rel_dir = os.path.relpath(os.path.dirname(full_path), project_root)
                arg = f"{full_path}{os.pathsep}{rel_dir}"
                print(f"[NVLib] Adding resource: {file}")
                data_files.append("--add-data")
                data_files.append(arg)
    return data_files

def build_project(main_script_abs, exe_name):
    """Main build function."""
    if not os.path.exists(main_script_abs):
        print(f"[Error] Main script '{main_script_abs}' does not exist.")
        return

    # Find the NVLib module path
    try:
        cli_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        cli_dir = os.path.abspath(".")
        
    nvlib_project_dir = os.path.dirname(cli_dir) # Should be .../NVLib
    
    # --- Path Setup ---
    # We build *from* the project_root, so paths are stable
    project_root = os.path.dirname(main_script_abs)
    output_dir_abs = os.path.join(project_root, OUTPUT_FOLDER)
    
    # *** FIX ***
    # Create the temp main script *inside* the NVLib project dir
    # This allows PyInstaller to find the NVLib module relative to it
    temp_main_abs = os.path.join(nvlib_project_dir, TEMP_MAIN) 
    
    spec_file_abs = os.path.join(project_root, f"{exe_name}.spec")
    build_dir_abs = os.path.join(project_root, "build") # PyInstaller's build folder

    # The import path is the folder *containing* the NVLib package
    nvlib_module_dir = os.path.dirname(nvlib_project_dir) # Should be .../NVLib_module
    nvlib_import_path = nvlib_module_dir 
    
    print(f"[NVLib] Project root: {project_root}")
    print(f"[NVLib] Library path: {nvlib_import_path}")
    print(f"[NVLib] Output folder: {output_dir_abs}")
    print(f"[NVLib] Temp script: {temp_main_abs}")
    
    os.makedirs(output_dir_abs, exist_ok=True)

    # --- Step 1 ---
    print("[NVLib] Step 1/3 – Creating temporary main_build.py ...")
    if not create_main_copy(main_script_abs, temp_main_abs):
        return

    # --- Step 2 ---
    print("[NVLib] Step 2/3 – Collecting project files ...")
    data_files = collect_data_files(project_root)

    # --- Step 3 ---
    print("[NVLib] Step 3/3 – Building executable ...")
    
    pyinstaller_args = [
        temp_main_abs, # Use the new temp main path
        "--onefile",
        "--windowed",
        "--name", exe_name,
        "--distpath", output_dir_abs,
        "--workpath", build_dir_abs,
        "--specpath", project_root,
        "--paths", nvlib_import_path, # *** THE CRUCIAL FIX ***
        "--noconfirm",
        "--clean",
        "--log-level=WARN" # Changed from DEBUG to WARN
    ] + data_files

    funny_messages = [
        "[NVLib] Cooking your beer...",
        "[NVLib] Polishing the pixels...",
        "[NVLib] Feeding the code gremlins...",
        "[NVLib] Summoning the compiler spirits...",
        "[NVLib] Negotiating with the bugs...",
        "[NVLib] Brewing binary soup...",
        "[NVLib] Convincing electrons to behave...",
        "[NVLib] Aligning the bits just right...",
        "[NVLib] Asking nicely for success...",
        "[NVLib] Duct-taping the logic together...",
        "[NVLib] Whispering sweet nothings to PyInstaller...",
        "[NVLib] Warming up the flux capacitor...",
        "[NVLib] Teaching AI to love...",
        "[NVLib] Pretending to work really hard...",
        "[NVLib] Turning caffeine into code...",
        "[NVLib] Debugging the debugger...",
        "[NVLib] Rewiring the matrix...",
        "[NVLib] Compiling with extra love ❤️...",
        "[NVLib] Distracting the bugs with cat videos...",
        "[NVLib] Asking ChatGPT for help... again."
    ]
    print(random.choice(funny_messages))

    # --- IMPORT & RUN PYINSTALLER ---
    # Now we import and run INSIDE the suppression block
    # This ensures it's silent and only happens during a build.
    try:
        with open(os.devnull, 'w') as f, contextlib.redirect_stdout(f), contextlib.redirect_stderr(f):
            # 1. Import PyInstaller here
            import PyInstaller.__main__
            
            # 2. Run PyInstaller here
            PyInstaller.__main__.run(pyinstaller_args)
            
    except ImportError:
        # This catch is for if `pip install pyinstaller` was missed
        print("\n[Error] PyInstaller not found. Please install it with `pip install pyinstaller`")
        return
    except Exception as e:
        # Catch any other build errors
        print(f"\n[Error] PyInstaller build failed: {e}")
        print("Build unsuccessful.")
        return
    # --- END IMPORT & RUN ---

    # After build check
    exe_path = os.path.join(output_dir_abs, exe_name + ".exe")
    print(f"[NVLib] Looking for executable at: {exe_path}")
    if os.path.exists(exe_path):
        print(f"[NVLib] ✅ Executable created: {exe_path}")
    else:
        print(f"[NVLib] ❌ Executable **NOT** found.")
        print("[NVLib] Please check for errors.")

    # List output directory content
    print("\n[NVLib] Contents of output folder:")
    try:
        for item in os.listdir(output_dir_abs):
            print("  -", item)
    except Exception as e:
        print(f"[NVLib] Could not list contents: {e}")

    # Clean up
    print("[NVLib] Cleaning up temporary files...")
    # Add the new temp_main_abs path to the cleanup list
    for item_path in [temp_main_abs, os.path.join(project_root, f"{exe_name}.spec"), build_dir_abs]:
        if os.path.exists(item_path):
            try:
                if os.path.isdir(item_path):
                    shutil.rmtree(item_path)
                else:
                    os.remove(item_path)
            except Exception as e:
                print(f"[NVLib] Warning: cleanup failed for {item_path}: {e}")

def main():
    parser = argparse.ArgumentParser(description="NVLib - Easy tools for everyone!")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    set_parser = subparsers.add_parser("set", help="Set the main entry point")
    set_parser.add_argument("file", help="Main Python file to set (e.g., test.py)")

    run_parser = subparsers.add_parser("run", help="Run the project")
    # run_parser.add_argument("-exe", action="store_true", help="Run as executable") # This seems redundant

    build_parser = subparsers.add_parser("build", help="Build the project")
    build_parser.add_argument("-exe", action="store_true", help="Build as executable")

    args = parser.parse_args()

    if args.command == "set":
        save_main_script(args.file)

    elif args.command == "run":
        print("[NVLib] Running project ...")
        script_path = load_main_script()
        if script_path is None:
            sys.exit(1)

        main_script = os.path.abspath(script_path)
        if not os.path.exists(main_script):
            print(f"[Error] File not found: {main_script}")
            sys.exit(1)
        
        # Change to the script's directory so it can find its own files
        script_dir = os.path.dirname(main_script)
        print(f"[NVLib] Changing directory to: {script_dir}")
        os.chdir(script_dir)

        print(f"[NVLib] Executing: {main_script}")
        try:
            # Run the script using the current Python executable
            subprocess.run([sys.executable, os.path.basename(main_script)], check=True)
        except subprocess.CalledProcessError as e:
            print(f"[Error] Script failed with exit code {e.returncode}")
        except Exception as e:
            print(f"[Error] Failed to run script: {e}")

    elif args.command == "build":
        if args.exe:
            script_path = load_main_script()
            if script_path is None:
                sys.exit(1)
            main_script = os.path.abspath(script_path)

            exe_name = input("[NVLib] Name for your .exe file?  ").strip()
            if not exe_name:
                print("[Error] Executable name cannot be empty.")
                sys.exit(1)

            build_project(main_script, exe_name)
        else:
            print("[ALERT] Build command currently supports only the `-exe` flag.")

    else:
        # No command given
        if len(sys.argv) == 1:
            parser.print_help()
        else:
            # This handles invalid commands like "nvlib foo"
            print(f"Unknown command: '{sys.argv[1]}'")
            parser.print_help()
        sys.exit(1)

if __name__ == "__main__":
    main()

