"""
Setup configuration for Auric - A modern Discord API wrapper for Python.
"""

from setuptools import setup, find_packages
import re
from pathlib import Path

# Read version from __init__.py
init_file = Path(__file__).parent / 'auric' / '__init__.py'
with open(init_file, 'r', encoding='utf-8') as f:
    version_match = re.search(r'^__version__\s*=\s*[\'"]([^\'"]*)[\'"]', f.read(), re.MULTILINE)
    if version_match:
        version = version_match.group(1)
    else:
        version = '0.0.1'

# Read long description from README
readme_file = Path(__file__).parent / 'README.md'
with open(readme_file, 'r', encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='auric',
    version=version,
    author='Auric Team',
    author_email='auricxofficial@gmail.com',
    description='A modern, feature-rich Discord API wrapper for Python with full type safety',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/Auric-Team/auric',
    license='MIT',
    packages=find_packages(exclude=['tests', 'tests.*', 'docs', 'examples']),
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Natural Language :: English',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3 :: Only',
        'Topic :: Communications :: Chat',
        'Topic :: Internet',
        'Topic :: Software Development :: Libraries',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Typing :: Typed',
    ],
    python_requires='>=3.11',
    install_requires=[
        'aiohttp>=3.8.0,<4.0.0',
        'python-dotenv>=0.19.0',
    ],
    extras_require={
        'voice': [
            'PyNaCl>=1.5.0,<2.0.0',
            'opus-python>=1.0.0',
        ],
        'speed': [
            'orjson>=3.8.0',
            'aiodns>=3.0.0',
            'Brotli>=1.0.0',
        ],
        'docs': [
            'mkdocs>=1.5.0',
            'mkdocs-material>=9.0.0',
            'mkdocstrings[python]>=0.20.0',
        ],
        'dev': [
            'pytest>=7.4.0',
            'pytest-asyncio>=0.21.0',
            'pytest-cov>=4.1.0',
            'black>=23.0.0',
            'isort>=5.12.0',
            'mypy>=1.5.0',
            'flake8>=6.1.0',
        ],
    },
    keywords=[
        'discord',
        'discord-api',
        'discord-bot',
        'bot',
        'api',
        'wrapper',
        'async',
        'asyncio',
        'discord.py',
        'slash-commands',
        'interactions',
    ],
    project_urls={
        'Documentation': 'https://github.com/Auric-Team/auric/blob/main/docs/INDEX.md',
        'Source': 'https://github.com/Auric-Team/auric',
        'Tracker': 'https://github.com/Auric-Team/auric/issues',
        'Changelog': 'https://github.com/Auric-Team/auric/blob/main/CHANGELOG.md',
    },
    include_package_data=True,
    zip_safe=False,
)
