# Slash Commands Guide

Slash commands are the modern way to interact with Discord bots. They provide a better user experience with built-in argument validation, auto-completion, and discoverability.

## Why Slash Commands?

- **Discoverable**: Users can see all available commands by typing `/`
- **Type-safe**: Discord validates arguments before sending them to your bot
- **Auto-complete**: Suggest options as users type
- **Better UX**: Clean interface with descriptions and parameter names
- **Mobile-friendly**: Easy to use on mobile devices

## Basic Slash Command

Create a simple slash command:

```python
from auric import Client, Intents
from auric.builders import SlashCommandBuilder

client = Client(intents=Intents.default())

# Register a slash command
@client.slash_command
async def ping(interaction):
    """Respond with pong"""
    await interaction.reply('Pong!')

# Or use the builder
ping_command = (SlashCommandBuilder()
    .set_name('ping')
    .set_description('Respond with pong')
    .build())

client.run('YOUR_TOKEN')
```

## Commands with Parameters

Add parameters to your commands:

```python
@client.slash_command
async def greet(interaction, name: str, age: int = None):
    """
    Greet a user
    
    Args:
        name: The person's name
        age: Optional age
    """
    message = f'Hello, {name}!'
    if age:
        message += f' You are {age} years old.'
    
    await interaction.reply(message)
```

### Parameter Types

Auric supports all Discord parameter types:

```python
from auric.models import User, Role, Channel

@client.slash_command
async def info(
    interaction,
    user: User,              # User parameter
    role: Role = None,       # Optional role
    channel: Channel = None, # Optional channel
    count: int = 1,          # Integer (min/max can be specified)
    enabled: bool = True,    # Boolean
    reason: str = None       # String
):
    """Get information about something"""
    await interaction.reply(f'User: {user.mention}')
```

### Parameter Validation

Add validation with type hints:

```python
from auric.builders import SlashCommandBuilder, OptionBuilder

command = (SlashCommandBuilder()
    .set_name('ban')
    .set_description('Ban a user')
    .add_option(OptionBuilder()
        .set_name('user')
        .set_description('User to ban')
        .set_type(6)  # USER type
        .set_required(True))
    .add_option(OptionBuilder()
        .set_name('days')
        .set_description('Days of messages to delete')
        .set_type(4)  # INTEGER type
        .set_min_value(0)
        .set_max_value(7)
        .set_required(False))
    .build())
```

## Choice Parameters

Provide predefined choices:

```python
from auric.builders import SlashCommandBuilder, OptionBuilder, ChoiceBuilder

command = (SlashCommandBuilder()
    .set_name('color')
    .set_description('Choose a color')
    .add_option(OptionBuilder()
        .set_name('color')
        .set_description('Pick your favorite color')
        .set_type(3)  # STRING type
        .add_choice(ChoiceBuilder()
            .set_name('Red')
            .set_value('red'))
        .add_choice(ChoiceBuilder()
            .set_name('Blue')
            .set_value('blue'))
        .add_choice(ChoiceBuilder()
            .set_name('Green')
            .set_value('green')))
    .build())

@client.slash_command(command)
async def color(interaction, color: str):
    await interaction.reply(f'You chose {color}!')
```

## Auto-completion

Add dynamic auto-completion:

```python
@client.slash_command
async def search(interaction, query: str):
    """Search for something"""
    # Command handler
    await interaction.reply(f'Searching for: {query}')

@search.autocomplete('query')
async def search_autocomplete(interaction, current: str):
    """Provide autocomplete suggestions"""
    # Return a list of suggestions based on current input
    suggestions = [
        'apple', 'banana', 'cherry', 'date', 'elderberry'
    ]
    
    # Filter suggestions based on what user typed
    filtered = [s for s in suggestions if current.lower() in s.lower()]
    
    # Return up to 25 suggestions
    return filtered[:25]
```

## Subcommands

Group related commands:

```python
from auric.builders import SlashCommandBuilder, SubcommandBuilder

# Create a command group
command = (SlashCommandBuilder()
    .set_name('user')
    .set_description('User management commands')
    .add_subcommand(SubcommandBuilder()
        .set_name('info')
        .set_description('Get user information')
        .add_option(OptionBuilder()
            .set_name('user')
            .set_description('Target user')
            .set_type(6)
            .set_required(True)))
    .add_subcommand(SubcommandBuilder()
        .set_name('avatar')
        .set_description('Get user avatar')
        .add_option(OptionBuilder()
            .set_name('user')
            .set_description('Target user')
            .set_type(6)
            .set_required(True)))
    .build())

# Handle subcommands
@client.slash_command(command)
async def user(interaction, subcommand: str, user: User):
    if subcommand == 'info':
        await interaction.reply(f'User: {user.name}#{user.discriminator}')
    elif subcommand == 'avatar':
        await interaction.reply(user.avatar_url)
```

## Permissions

Restrict commands to specific roles or permissions:

```python
from auric.builders import SlashCommandBuilder
from auric.models import Permissions

command = (SlashCommandBuilder()
    .set_name('ban')
    .set_description('Ban a user')
    .set_default_member_permissions(Permissions.BAN_MEMBERS)  # Only for users with ban permission
    .set_dm_permission(False)  # Cannot be used in DMs
    .build())

@client.slash_command(command)
async def ban(interaction, user: User, reason: str = None):
    # Check if user has permission
    if not interaction.member.has_permission(Permissions.BAN_MEMBERS):
        await interaction.reply('You do not have permission!', ephemeral=True)
        return
    
    # Ban the user
    await interaction.guild.ban(user, reason=reason)
    await interaction.reply(f'Banned {user.mention}')
```

## Responding to Commands

### Basic Response

```python
@client.slash_command
async def hello(interaction):
    await interaction.reply('Hello!')
```

### Ephemeral Responses

Only visible to the command user:

```python
@client.slash_command
async def secret(interaction):
    await interaction.reply('This is secret!', ephemeral=True)
```

### Deferred Responses

For commands that take time:

```python
@client.slash_command
async def process(interaction):
    # Defer the response (shows "thinking...")
    await interaction.defer()
    
    # Do some long processing
    await asyncio.sleep(5)
    
    # Send the actual response
    await interaction.followup('Processing complete!')
```

### Responses with Embeds

```python
from auric import Embed

@client.slash_command
async def info(interaction):
    embed = Embed(
        title='Information',
        description='Here is some info',
        color=0x5865F2
    )
    embed.add_field(name='Field 1', value='Value 1')
    
    await interaction.reply(embed=embed)
```

### Responses with Components

```python
from auric.builders import ActionRowBuilder, ButtonBuilder, ButtonStyle

@client.slash_command
async def choose(interaction):
    row = (ActionRowBuilder()
        .add_button(ButtonBuilder()
            .set_label('Option 1')
            .set_style(ButtonStyle.PRIMARY)
            .set_custom_id('option_1'))
        .add_button(ButtonBuilder()
            .set_label('Option 2')
            .set_style(ButtonStyle.PRIMARY)
            .set_custom_id('option_2'))
        .build())
    
    await interaction.reply('Choose an option:', components=[row])
```

## Error Handling

Handle errors gracefully:

```python
from auric.exceptions import CommandError, Forbidden

@client.slash_command
async def risky(interaction):
    try:
        # Do something that might fail
        await interaction.reply('Success!')
    except Forbidden:
        await interaction.reply('I don\'t have permission!', ephemeral=True)
    except CommandError as e:
        await interaction.reply(f'Error: {e}', ephemeral=True)
```

## Global vs Guild Commands

### Global Commands

Available in all servers (takes up to 1 hour to update):

```python
@client.slash_command
async def global_command(interaction):
    await interaction.reply('This works everywhere!')
```

### Guild Commands

Only available in specific servers (updates instantly):

```python
@client.slash_command(guild_ids=[123456789])  # Your test server ID
async def test_command(interaction):
    await interaction.reply('Testing!')
```

## Registering Commands

Commands are registered automatically when your bot starts. To manually register:

```python
from auric.builders import SlashCommandBuilder

# Create your commands
commands = [
    SlashCommandBuilder()
        .set_name('ping')
        .set_description('Pong!')
        .build(),
    SlashCommandBuilder()
        .set_name('help')
        .set_description('Show help')
        .build(),
]

# Register globally
await client.register_global_commands(commands)

# Or register to a specific guild
await client.register_guild_commands(guild_id, commands)
```

## Best Practices

1. **Use descriptive names**: `/user info` is better than `/uinfo`
2. **Write clear descriptions**: Help users understand what each command does
3. **Provide default values**: Make optional parameters truly optional
4. **Use ephemeral for errors**: Keep error messages private
5. **Defer long operations**: Show "thinking..." for operations over 3 seconds
6. **Test in guilds first**: Use guild commands for testing before going global
7. **Handle errors**: Always have error handling for user-facing commands

## Examples

Check out complete examples:
- [Moderation Bot](../examples/moderation.md) - Ban, kick, timeout commands
- [Info Bot](../examples/info-bot.md) - Server and user information
- [Interactive Quiz](../examples/quiz.md) - Quiz with slash commands

## Next Steps

- [Learn about components](components.md) - Add buttons and menus to commands
- [Context menus](context-menus.md) - Right-click commands
- [Advanced patterns](advanced-commands.md) - Command cooldowns, checks, and more
