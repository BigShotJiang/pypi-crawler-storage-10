# Getting Started with Auric

This guide will help you build your first Discord bot with Auric.

## Prerequisites

Before starting, make sure you have:

- Python 3.11 or higher installed
- A Discord account
- Basic knowledge of Python and async/await

## Installation

Install Auric using pip:

```bash
pip install auric
```

For voice support, install the voice extras:

```bash
pip install auric[voice]
```

## Creating a Bot Account

1. Go to the [Discord Developer Portal](https://discord.com/developers/applications)
2. Click "New Application" and give it a name
3. Navigate to the "Bot" tab
4. Click "Add Bot"
5. Under the bot's username, click "Reset Token" to get your bot token
6. **Keep this token secret!** Never commit it to version control

### Setting Permissions

In the "Bot" tab, enable these Privileged Gateway Intents if needed:
- Presence Intent (for user status)
- Server Members Intent (for member events)
- Message Content Intent (for reading message content)

### Inviting Your Bot

1. Go to the "OAuth2" → "URL Generator" tab
2. Select these scopes:
   - `bot`
   - `applications.commands` (for slash commands)
3. Select the permissions your bot needs
4. Use the generated URL to invite your bot to a server

## Your First Bot

Create a file called `bot.py`:

```python
from auric import Client, Intents

# Create a client with default intents
client = Client(intents=Intents.default())

# Event that fires when the bot is ready
@client.event
async def on_ready():
    print(f'Logged in as {client.user.username}')
    print(f'Bot ID: {client.user.id}')
    print('Ready to go!')

# Event that fires when a message is sent
@client.event
async def on_message(message):
    # Ignore messages from bots (including ourselves)
    if message.author.bot:
        return
    
    # Respond to !ping
    if message.content == '!ping':
        await message.channel.send('Pong!')
    
    # Respond to !hello
    elif message.content == '!hello':
        await message.channel.send(f'Hello, {message.author.mention}!')

# Run the bot with your token
client.run('YOUR_BOT_TOKEN_HERE')
```

### Running Your Bot

```bash
python bot.py
```

You should see your bot come online in Discord!

## Using Environment Variables

**Never hardcode your token!** Use environment variables instead.

Create a `.env` file:

```env
DISCORD_TOKEN=your_bot_token_here
```

Update your bot code:

```python
import os
from dotenv import load_dotenv
from auric import Client, Intents

# Load environment variables
load_dotenv()

client = Client(intents=Intents.default())

@client.event
async def on_ready():
    print(f'Logged in as {client.user.username}')

# Use the token from environment
client.run(os.getenv('DISCORD_TOKEN'))
```

Add `.env` to your `.gitignore`:

```gitignore
.env
__pycache__/
*.pyc
```

## Understanding Intents

Intents control what events your bot receives. Use only what you need:

```python
from auric import Intents

# Default intents (most common needs)
intents = Intents.default()

# Or create custom intents
intents = Intents(
    guilds=True,           # Guild/server events
    guild_messages=True,   # Message events
    message_content=True,  # Access to message content
    guild_members=True,    # Member join/leave events
)

client = Client(intents=intents)
```

Common intent combinations:

```python
# For a bot that only responds to commands
intents = Intents(guilds=True, guild_messages=True, message_content=True)

# For a moderation bot
intents = Intents.default()
intents.guild_members = True
intents.guild_moderation = True

# For everything (not recommended for large bots)
intents = Intents.all()
```

## Adding More Features

### Embeds

Make your messages look professional with embeds:

```python
from auric import Embed

@client.event
async def on_message(message):
    if message.content == '!info':
        embed = Embed(
            title='Bot Information',
            description='This is a cool bot!',
            color=0x5865F2  # Blurple color
        )
        embed.add_field(name='Version', value='1.0.0')
        embed.add_field(name='Author', value='You!')
        embed.set_footer(text='Made with Auric')
        
        await message.channel.send(embed=embed)
```

### Reactions

React to messages:

```python
@client.event
async def on_message(message):
    if message.content == '!react':
        await message.add_reaction('👍')
        await message.add_reaction('👎')
```

### Multiple Events

Handle different events:

```python
@client.event
async def on_member_join(member):
    channel = member.guild.system_channel
    if channel:
        await channel.send(f'Welcome {member.mention}!')

@client.event
async def on_message_delete(message):
    print(f'Message deleted: {message.content}')
```

## Error Handling

Add error handling to make your bot robust:

```python
from auric.exceptions import HTTPException, Forbidden

@client.event
async def on_message(message):
    if message.content == '!dm':
        try:
            await message.author.send('Hello in DM!')
        except Forbidden:
            await message.channel.send('I cannot DM you!')
        except HTTPException as e:
            await message.channel.send(f'An error occurred: {e}')
```

## Logging

Enable logging to debug issues:

```python
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)

# Or more detailed logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s:%(levelname)s:%(name)s: %(message)s'
)

from auric import Client, Intents

client = Client(intents=Intents.default())
# ... rest of your code
```

## Next Steps

Now that you have a basic bot running:

1. **[Learn about slash commands](slash-commands.md)** - Modern command interface
2. **[Add interactive components](components.md)** - Buttons and select menus
3. **[Use collectors](collectors.md)** - Wait for user input
4. **[Explore examples](../examples/)** - See complete bot examples

## Common Issues

### Bot doesn't respond to messages

Make sure you have:
- `message_content` intent enabled
- The intent enabled in the Discord Developer Portal
- Not blocking the bot (checking `if message.author.bot`)

### Permission errors

Check that your bot has the necessary permissions in the server:
- Read Messages
- Send Messages
- Embed Links (for embeds)
- Add Reactions (for reactions)

### Rate limiting

Discord has rate limits. Auric handles them automatically, but:
- Don't spam API calls in loops
- Use bulk operations when possible
- Respect the rate limits shown in error messages

## Getting Help

Need help?

- Check the [API documentation](../api/)
- Look at [example bots](../examples/)
- Ask in our [Discord server](https://discord.gg/auric)
- Search [GitHub issues](https://github.com/yourusername/auric/issues)

Happy bot building! 🚀
