# Documentation Index

Welcome to Auric's documentation! This page will help you navigate to what you need.

## Quick Links

- **[Getting Started](guides/getting-started.md)** - Your first Auric bot in 5 minutes
- **[API Reference](api/)** - Complete API documentation
- **[Example Bot](examples/simple-bot.md)** - Working bot example

## For Beginners

New to Discord bot development? Start here:

1. **[Getting Started](guides/getting-started.md)** - Install Auric and create your first bot
2. **[Slash Commands](guides/slash-commands.md)** - Build modern slash commands
3. **[Simple Bot Example](examples/simple-bot.md)** - A complete working bot

## Guides

### Essentials
- **[Getting Started](guides/getting-started.md)** - Installation and first bot
- **[Slash Commands](guides/slash-commands.md)** - Modern command interface

### Available Guides
Other guides are in development. Check back soon or contribute!

## API Reference

Complete documentation of all classes, methods, and functions:

### Core
- **[Client](api/client.md)** - The main bot class
- **[Intents](api/intents.md)** - Gateway intents

### Other API Documentation
Additional API reference documentation is in development.

## Examples

Learn by example:

### Basic Bot
- **[Simple Bot](examples/simple-bot.md)** - Complete working bot example

More examples coming soon!

## Migration Guides

Switching from another library?

- Documentation for migration guides coming soon!

## Contributing

Want to help improve Auric?

- **[Contributing Guide](../CONTRIBUTING.md)** - How to contribute

## Resources

### External Resources
- **[Discord Developer Portal](https://discord.com/developers/docs)** - Official Discord API docs
- **[Discord API Server](https://discord.gg/discord-api)** - Get help from the community

### Auric Resources
- **[GitHub Repository](https://github.com/yourusername/auric)** - Source code
- **[Issue Tracker](https://github.com/yourusername/auric/issues)** - Report bugs
- **[Discussions](https://github.com/yourusername/auric/discussions)** - Ask questions
- **[Discord Server](https://discord.gg/auric)** - Join our community

## Version History

- **[Changelog](../CHANGELOG.md)** - All changes by version

## Getting Help

Stuck? Here's how to get help:

1. **Check the docs** - The answer might already be here
2. **Search issues** - Someone may have had the same problem
3. **Ask in Discord** - Get help from the community
4. **Open an issue** - Report bugs or request features

## Feedback

Help us improve! If you find:
- Typos or errors in documentation
- Missing or unclear explanations
- Broken links or examples

Please [open an issue](https://github.com/yourusername/auric/issues) or submit a pull request.

---

**Happy bot building with Auric!** 🚀
