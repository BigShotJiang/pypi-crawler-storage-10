# Simple Bot Example

A complete working bot that demonstrates basic Auric features.

## The Bot

This bot responds to messages and demonstrates:
- Message events
- Embeds
- Commands with parameters
- Error handling
- Reactions

## Code

```python
import os
import logging
from dotenv import load_dotenv
from auric import Client, Intents, Embed
from auric.exceptions import HTTPException, Forbidden

# Load environment variables
load_dotenv()

# Set up logging
logging.basicConfig(level=logging.INFO)

# Create client with necessary intents
intents = Intents.default()
intents.message_content = True  # Required to read message content

client = Client(intents=intents)

@client.event
async def on_ready():
    """Called when the bot is ready"""
    print(f'Logged in as {client.user.username}')
    print(f'Bot ID: {client.user.id}')
    print('Bot is ready!')

@client.event
async def on_message(message):
    """Handle incoming messages"""
    # Ignore messages from bots
    if message.author.bot:
        return
    
    # Ping command
    if message.content == '!ping':
        await message.channel.send('Pong! 🏓')
    
    # Hello command
    elif message.content == '!hello':
        await message.channel.send(f'Hello, {message.author.mention}! 👋')
    
    # Info command with embed
    elif message.content == '!info':
        embed = Embed(
            title='Bot Information',
            description='A simple bot made with Auric',
            color=0x5865F2  # Discord blurple
        )
        embed.add_field(name='Library', value='Auric')
        embed.add_field(name='Language', value='Python 3.11+')
        embed.add_field(name='Commands', value='!ping, !hello, !info, !serverinfo')
        embed.set_footer(text='Made with ❤️')
        
        await message.channel.send(embed=embed)
    
    # Server info command
    elif message.content == '!serverinfo':
        if not message.guild:
            await message.channel.send('This command only works in servers!')
            return
        
        guild = message.guild
        embed = Embed(
            title=f'{guild.name} Information',
            color=0x5865F2
        )
        embed.add_field(name='Server ID', value=str(guild.id))
        embed.add_field(name='Owner', value=f'<@{guild.owner_id}>')
        embed.add_field(name='Members', value=str(guild.member_count))
        embed.add_field(name='Created', value=guild.created_at.strftime('%Y-%m-%d'))
        
        if guild.icon_url:
            embed.set_thumbnail(url=guild.icon_url)
        
        await message.channel.send(embed=embed)
    
    # Echo command (repeats what user says)
    elif message.content.startswith('!echo '):
        text = message.content[6:]  # Remove '!echo '
        if text:
            await message.channel.send(text)
        else:
            await message.channel.send('Please provide text to echo!')
    
    # React command
    elif message.content == '!react':
        try:
            await message.add_reaction('👍')
            await message.add_reaction('👎')
            await message.add_reaction('❤️')
        except HTTPException as e:
            await message.channel.send(f'Failed to add reaction: {e}')
    
    # DM command
    elif message.content == '!dm':
        try:
            await message.author.send('Hello in DM! 📬')
            await message.channel.send('Check your DMs!')
        except Forbidden:
            await message.channel.send('I cannot send you a DM. Please check your privacy settings.')
    
    # Help command
    elif message.content == '!help':
        embed = Embed(
            title='Available Commands',
            description='Here are all the commands you can use:',
            color=0x5865F2
        )
        embed.add_field(
            name='Basic Commands',
            value=(
                '**!ping** - Check if the bot is alive\n'
                '**!hello** - Get a greeting\n'
                '**!info** - Show bot information\n'
                '**!help** - Show this message'
            ),
            inline=False
        )
        embed.add_field(
            name='Server Commands',
            value=(
                '**!serverinfo** - Show server information\n'
            ),
            inline=False
        )
        embed.add_field(
            name='Fun Commands',
            value=(
                '**!echo <text>** - Repeat your message\n'
                '**!react** - React to your message\n'
                '**!dm** - Send you a DM'
            ),
            inline=False
        )
        embed.set_footer(text='Use these commands to interact with the bot!')
        
        await message.channel.send(embed=embed)

@client.event
async def on_member_join(member):
    """Welcome new members"""
    # Send welcome message to system channel
    if member.guild.system_channel:
        embed = Embed(
            title='Welcome!',
            description=f'Welcome to {member.guild.name}, {member.mention}!',
            color=0x00FF00
        )
        embed.set_thumbnail(url=member.avatar_url)
        
        try:
            await member.guild.system_channel.send(embed=embed)
        except Forbidden:
            pass  # No permission to send in system channel

@client.event
async def on_message_delete(message):
    """Log deleted messages"""
    if message.author.bot:
        return
    
    print(f'Message deleted in #{message.channel.name}: {message.content}')

@client.event
async def on_error(event, *args, **kwargs):
    """Handle errors"""
    logging.exception(f'Error in {event}')

# Run the bot
if __name__ == '__main__':
    token = os.getenv('DISCORD_TOKEN')
    if not token:
        print('Error: DISCORD_TOKEN not found in environment variables')
        print('Please create a .env file with your token:')
        print('DISCORD_TOKEN=your_token_here')
    else:
        client.run(token)
```

## Setup

1. **Create a `.env` file**:
```env
DISCORD_TOKEN=your_bot_token_here
```

2. **Install dependencies**:
```bash
pip install auric python-dotenv
```

3. **Run the bot**:
```bash
python simple_bot.py
```

## Testing the Bot

Try these commands in Discord:

- `!ping` - Bot responds with "Pong!"
- `!hello` - Bot greets you
- `!info` - Shows bot information
- `!serverinfo` - Shows server details
- `!echo Hello` - Bot repeats "Hello"
- `!react` - Bot adds reactions
- `!dm` - Bot sends you a DM
- `!help` - Shows all commands

## Features Demonstrated

### Events
- `on_ready` - Bot initialization
- `on_message` - Message handling
- `on_member_join` - Welcome new members
- `on_message_delete` - Log deletions
- `on_error` - Error handling

### Message Operations
- Reading message content
- Sending messages
- Sending embeds
- Adding reactions
- Sending DMs

### Error Handling
- Try/except blocks
- Handling `Forbidden` errors
- Handling `HTTPException`
- Graceful error messages

### Best Practices
- Environment variables for tokens
- Ignoring bot messages
- Checking permissions before operations
- Logging important events
- Clear command help

## Extending the Bot

Add more features:

### Add a counter command
```python
message_count = 0

@client.event
async def on_message(message):
    global message_count
    if not message.author.bot:
        message_count += 1
    
    if message.content == '!count':
        await message.channel.send(f'I have seen {message_count} messages!')
```

### Add a role command
```python
if message.content == '!role Member':
    role = discord.utils.get(message.guild.roles, name='Member')
    if role:
        await message.author.add_roles(role)
        await message.channel.send(f'Gave you the {role.name} role!')
```

### Add a poll command
```python
if message.content.startswith('!poll '):
    question = message.content[6:]
    poll_message = await message.channel.send(f'📊 Poll: {question}')
    await poll_message.add_reaction('👍')
    await poll_message.add_reaction('👎')
```

## Next Steps

- **[Slash Commands](slash-commands.md)** - Modern command interface
- **[Interactive Components](interactive-menu.md)** - Buttons and menus
- **[Moderation Bot](moderation.md)** - Ban, kick, and timeout users
- **[Music Bot](music-bot.md)** - Play audio in voice channels

## Troubleshooting

### Bot doesn't respond

1. Check that `message_content` intent is enabled
2. Verify the intent is enabled in Discord Developer Portal
3. Make sure the bot isn't blocking itself with `if message.author.bot`

### Permission errors

Give your bot these permissions:
- Read Messages
- Send Messages
- Embed Links
- Add Reactions

### Rate limiting

If you get rate limited:
- Don't spam commands
- Wait a few seconds between operations
- Auric handles rate limits automatically

## Complete Code

The complete bot is available at [examples/simple_bot.py](https://github.com/yourusername/auric/blob/main/examples/simple_bot.py)
