# Intents

Gateway intents control what events your bot receives from Discord.

## What are Intents?

Intents are flags that tell Discord which events you want to receive. They help:
- Reduce bandwidth and processing
- Protect user privacy
- Comply with Discord's policies

## Quick Start

```python
from auric import Intents

# Default intents (most common use cases)
intents = Intents.default()

# Enable message content (required to read message.content)
intents.message_content = True

client = Client(intents=intents)
```

## Available Intents

### `Intents.default()`
Returns default intents suitable for most bots.

**Includes:**
- guilds
- guild_messages
- guild_reactions
- direct_messages
- direct_message_reactions

### `Intents.all()`
Returns all intents (use with caution).

### `Intents.none()`
Returns no intents.

## Intent Flags

### Standard Intents

```python
intents = Intents.none()

intents.guilds = True                    # Guild create/update/delete
intents.guild_members = True             # Member join/leave/update
intents.guild_moderation = True          # Ban/unban events
intents.guild_emojis = True              # Emoji updates
intents.guild_integrations = True        # Integration updates
intents.guild_webhooks = True            # Webhook updates
intents.guild_invites = True             # Invite create/delete
intents.guild_voice_states = True        # Voice state changes
intents.guild_messages = True            # Message create/delete/update
intents.guild_message_reactions = True   # Reaction add/remove
intents.guild_message_typing = True      # Typing indicators
intents.direct_messages = True           # DM create/delete/update
intents.direct_message_reactions = True  # DM reaction add/remove
intents.direct_message_typing = True     # DM typing indicators
intents.guild_scheduled_events = True    # Scheduled event updates
```

### Privileged Intents

These require approval in Discord Developer Portal:

```python
intents.guild_presences = True    # User status/activity (privileged)
intents.guild_members = True      # Member events (privileged)
intents.message_content = True    # Message content (privileged)
```

## Enabling Privileged Intents

1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Select your application
3. Go to "Bot" tab
4. Scroll to "Privileged Gateway Intents"
5. Enable the intents you need
6. Save changes

### When do you need privileged intents?

**Message Content Intent**
- Reading `message.content`
- Reading embeds, attachments, components
- Text commands (prefix commands)

**Server Members Intent**
- `on_member_join` / `on_member_remove`
- Member cache
- Accurate member count

**Presence Intent**
- User status (online, idle, dnd, offline)
- User activities (playing, streaming)

## Common Configurations

### Basic Bot (no privileged intents)
```python
intents = Intents.default()
# Only slash commands, no message content
```

### Message Commands Bot
```python
intents = Intents.default()
intents.message_content = True  # Enable in Developer Portal!
```

### Member Tracking Bot
```python
intents = Intents.default()
intents.guild_members = True    # Enable in Developer Portal!
```

### Full Featured Bot
```python
intents = Intents.all()
# Enable all privileged intents in Developer Portal!
```

### Voice Bot
```python
intents = Intents.default()
intents.guild_voice_states = True
intents.message_content = True  # If using text commands
```

## Examples

### Minimal Bot (Slash Commands Only)
```python
from auric import Client, Intents

# No privileged intents needed for slash commands
intents = Intents.default()

client = Client(intents=intents)

@client.slash_command
async def ping(interaction):
    await interaction.reply('Pong!')

client.run('TOKEN')
```

### Text Commands Bot
```python
from auric import Client, Intents

# Need message content for text commands
intents = Intents.default()
intents.message_content = True  # Must enable in portal!

client = Client(intents=intents)

@client.event
async def on_message(message):
    if message.content == '!ping':
        await message.reply('Pong!')

client.run('TOKEN')
```

### Welcome Bot
```python
from auric import Client, Intents

# Need member events
intents = Intents.default()
intents.guild_members = True  # Must enable in portal!

client = Client(intents=intents)

@client.event
async def on_member_join(member):
    channel = member.guild.system_channel
    if channel:
        await channel.send(f'Welcome {member.mention}!')

client.run('TOKEN')
```

## Troubleshooting

### "Disallowed intent(s)"
- Enable the intent in Developer Portal
- Wait a few seconds after enabling
- Restart your bot

### "Missing Access"
- Your bot needs to be verified for privileged intents if in 100+ servers
- Apply for verification in Developer Portal

### Events not firing
- Check you have the right intent enabled
- Check privileged intents are enabled in portal
- Verify your code is correct

## See Also

- [Client](client.md)
- [Events Guide](../guides/events.md)
- [Discord Intents Documentation](https://discord.com/developers/docs/topics/gateway#gateway-intents)
