# API Reference

Welcome to the Auric API reference. This documentation covers all classes, methods, and functions in Auric.

## Core Classes

### [Client](client.md)
The main bot client class.

```python
from auric import Client, Intents

client = Client(intents=Intents.default())
```

### [Intents](intents.md)
Gateway intents configuration.

```python
from auric import Intents

intents = Intents.default()
intents.message_content = True
```

## Models

### [Guild](models/guild.md)
Represents a Discord server.

### [Channel](models/channel.md)
Text, voice, and thread channels.

### [Message](models/message.md)
Messages in channels.

### [User](models/user.md)
Users and server members.

### [Interaction](models/interaction.md)
Slash commands, buttons, and other interactions.

## Builders

### [EmbedBuilder](builders/embed.md)
Create rich embeds.

```python
from auric import EmbedBuilder

embed = (EmbedBuilder()
    .set_title("Hello")
    .set_description("World")
    .set_color(0x00FF00)
    .build())
```

### [SlashCommandBuilder](builders/slash-command.md)
Build slash commands.

### [ButtonBuilder](builders/button.md)
Create buttons.

### [SelectMenuBuilder](builders/select-menu.md)
Create select menus.

### [ModalBuilder](builders/modal.md)
Create modal forms.

## Utilities

### [Permissions](utils/permissions.md)
Permission handling.

### [Formatters](utils/formatters.md)
Text formatting helpers.

## Quick Links

- [Getting Started Guide](../guides/getting-started.md)
- [Examples](../examples/)
- [GitHub Repository](https://github.com/yourusername/auric)

---

**Note:** This is a work in progress. More detailed API documentation is being added.
For now, refer to the code docstrings and examples.
