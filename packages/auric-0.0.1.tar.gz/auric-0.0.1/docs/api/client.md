# Client

The main bot client class that connects to Discord.

## Constructor

```python
Client(intents: Intents, **options)
```

### Parameters

- **intents** (`Intents`): Gateway intents for the bot
- **options** (optional):
  - `shard_id` (int): Shard ID for this client
  - `shard_count` (int): Total number of shards
  - `max_messages` (int): Maximum messages to cache (default: 1000)

### Example

```python
from auric import Client, Intents

intents = Intents.default()
intents.message_content = True

client = Client(intents=intents)
```

## Properties

### `client.user`
The bot's user object. Available after `on_ready` event.

**Type:** `User`

### `client.guilds`
List of guilds (servers) the bot is in.

**Type:** `list[Guild]`

### `client.latency`
WebSocket latency in milliseconds.

**Type:** `float`

## Methods

### `run(token: str)`
Start the bot and connect to Discord.

```python
client.run('YOUR_BOT_TOKEN')
```

### `@client.event`
Decorator to register event handlers.

```python
@client.event
async def on_ready():
    print(f'Logged in as {client.user}')
```

### `@client.slash_command`
Decorator to register slash commands.

```python
@client.slash_command
async def ping(interaction):
    """Respond with pong"""
    await interaction.reply('Pong!')
```

### `get_guild(guild_id: int)`
Get a guild by ID.

**Returns:** `Guild | None`

```python
guild = client.get_guild(123456789)
```

### `get_channel(channel_id: int)`
Get a channel by ID.

**Returns:** `Channel | None`

```python
channel = client.get_channel(123456789)
```

### `get_user(user_id: int)`
Get a user by ID.

**Returns:** `User | None`

```python
user = client.get_user(123456789)
```

### `close()`
Close the bot connection.

```python
await client.close()
```

## Events

### `on_ready()`
Called when the bot successfully connects.

```python
@client.event
async def on_ready():
    print('Bot is ready!')
```

### `on_message(message: Message)`
Called when a message is created.

```python
@client.event
async def on_message(message):
    if message.author.bot:
        return
    print(f'Message from {message.author}: {message.content}')
```

### `on_interaction(interaction: Interaction)`
Called when any interaction is created.

```python
@client.event
async def on_interaction(interaction):
    print(f'Interaction: {interaction.type}')
```

### `on_guild_join(guild: Guild)`
Called when bot joins a guild.

```python
@client.event
async def on_guild_join(guild):
    print(f'Joined {guild.name}')
```

### `on_guild_remove(guild: Guild)`
Called when bot leaves a guild.

### `on_member_join(member: Member)`
Called when a member joins a guild.

### `on_member_remove(member: Member)`
Called when a member leaves a guild.

## Example Usage

```python
from auric import Client, Intents

intents = Intents.default()
intents.message_content = True
intents.guilds = True
intents.guild_messages = True

client = Client(intents=intents)

@client.event
async def on_ready():
    print(f'Logged in as {client.user.username}')
    print(f'In {len(client.guilds)} guilds')
    print(f'Latency: {client.latency}ms')

@client.event
async def on_message(message):
    if message.author.bot:
        return
    
    if message.content == '!ping':
        await message.reply(f'Pong! {client.latency}ms')

@client.slash_command
async def info(interaction):
    """Get bot info"""
    await interaction.reply(f'''
Bot: {client.user}
Guilds: {len(client.guilds)}
Latency: {client.latency}ms
    ''')

client.run('YOUR_TOKEN')
```

## See Also

- [Intents](intents.md)
- [Events Guide](../guides/events.md)
- [Getting Started](../guides/getting-started.md)
