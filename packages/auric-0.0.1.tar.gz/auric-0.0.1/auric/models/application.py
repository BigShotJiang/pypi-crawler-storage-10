"""
Application models for Discord API.

Applications are containers for developer platform features.
"""

from dataclasses import dataclass
from enum import IntEnum, IntFlag
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from ..http import HTTPClient
    from .guild import Guild
    from .user import User


class ApplicationIntegrationType(IntEnum):
    """Where an app can be installed."""

    GUILD_INSTALL = 0  # Installable to servers
    USER_INSTALL = 1  # Installable to users


class ApplicationEventWebhookStatus(IntEnum):
    """Status of event webhooks for an application."""

    DISABLED = 1  # Disabled by developer
    ENABLED = 2  # Enabled by developer
    DISABLED_BY_DISCORD = 3  # Disabled by Discord (inactivity)


class ApplicationFlags(IntFlag):
    """Application feature flags."""

    NONE = 0
    APPLICATION_AUTO_MODERATION_RULE_CREATE_BADGE = 1 << 6  # Uses Auto Mod API
    GATEWAY_PRESENCE = 1 << 12  # Has presence intent (100+ servers)
    GATEWAY_PRESENCE_LIMITED = 1 << 13  # Has presence intent (<100 servers)
    GATEWAY_GUILD_MEMBERS = 1 << 14  # Has members intent (100+ servers)
    GATEWAY_GUILD_MEMBERS_LIMITED = 1 << 15  # Has members intent (<100 servers)
    VERIFICATION_PENDING_GUILD_LIMIT = 1 << 16  # Unusual growth prevents verification
    EMBEDDED = 1 << 17  # Embedded in Discord client
    GATEWAY_MESSAGE_CONTENT = 1 << 18  # Has message content intent (100+)
    GATEWAY_MESSAGE_CONTENT_LIMITED = 1 << 19  # Has message content intent (<100)
    APPLICATION_COMMAND_BADGE = 1 << 23  # Has registered global commands


@dataclass
class InstallParams:
    """OAuth2 install parameters.

    Attributes:
        scopes: OAuth2 scopes to add the app with
        permissions: Permissions to request for bot role
    """

    scopes: List[str]
    permissions: str

    @classmethod
    def from_dict(cls, data: dict) -> "InstallParams":
        """Create InstallParams from API data."""
        return cls(scopes=data["scopes"], permissions=data["permissions"])

    def to_dict(self) -> dict:
        """Convert to API format."""
        return {"scopes": self.scopes, "permissions": self.permissions}


@dataclass
class ApplicationIntegrationTypeConfig:
    """Configuration for an integration type.

    Attributes:
        oauth2_install_params: Install params for this context
    """

    oauth2_install_params: Optional[InstallParams] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ApplicationIntegrationTypeConfig":
        """Create config from API data."""
        return cls(
            oauth2_install_params=(
                InstallParams.from_dict(data["oauth2_install_params"])
                if data.get("oauth2_install_params")
                else None
            )
        )

    def to_dict(self) -> dict:
        """Convert to API format."""
        data = {}
        if self.oauth2_install_params:
            data["oauth2_install_params"] = self.oauth2_install_params.to_dict()
        return data


@dataclass
class Application:
    """Represents a Discord application.

    Attributes:
        id: Application ID
        name: Application name
        icon: Icon hash
        description: Application description
        bot_public: Whether bot can be added by anyone
        bot_require_code_grant: Whether bot requires OAuth2 code grant
        verify_key: Hex encoded verification key
        flags: Public application flags
        rpc_origins: RPC origin URLs (if RPC enabled)
        bot: Partial user object for bot
        terms_of_service_url: Terms of Service URL
        privacy_policy_url: Privacy Policy URL
        owner: Partial user object for owner
        team: Team object if app belongs to a team
        guild_id: Associated guild ID
        guild: Partial guild object
        primary_sku_id: Primary SKU ID (if game)
        slug: URL slug (if game)
        cover_image: Cover image hash
        approximate_guild_count: Approximate server count
        approximate_user_install_count: Approximate user install count
        approximate_user_authorization_count: Approximate OAuth2 authorization count
        redirect_uris: Redirect URIs for OAuth2
        interactions_endpoint_url: Interactions endpoint URL
        role_connections_verification_url: Role connections verification URL
        event_webhooks_url: Event webhooks URL
        event_webhooks_status: Event webhooks status
        event_webhooks_types: Subscribed webhook event types
        tags: Content and functionality tags
        install_params: Default install params
        integration_types_config: Config for each integration type
        custom_install_url: Custom authorization URL
    """

    id: int
    name: str
    icon: Optional[str]
    description: str
    bot_public: bool
    bot_require_code_grant: bool
    verify_key: str
    flags: int = 0
    rpc_origins: Optional[List[str]] = None
    bot: Optional["User"] = None
    terms_of_service_url: Optional[str] = None
    privacy_policy_url: Optional[str] = None
    owner: Optional["User"] = None
    team: Optional[dict] = None  # Team object
    guild_id: Optional[int] = None
    guild: Optional["Guild"] = None
    primary_sku_id: Optional[int] = None
    slug: Optional[str] = None
    cover_image: Optional[str] = None
    approximate_guild_count: Optional[int] = None
    approximate_user_install_count: Optional[int] = None
    approximate_user_authorization_count: Optional[int] = None
    redirect_uris: Optional[List[str]] = None
    interactions_endpoint_url: Optional[str] = None
    role_connections_verification_url: Optional[str] = None
    event_webhooks_url: Optional[str] = None
    event_webhooks_status: int = 1
    event_webhooks_types: Optional[List[str]] = None
    tags: Optional[List[str]] = None
    install_params: Optional[InstallParams] = None
    integration_types_config: Optional[dict] = None
    custom_install_url: Optional[str] = None

    _http: Optional["HTTPClient"] = None

    @classmethod
    def from_dict(cls, data: dict, http: "HTTPClient" = None) -> "Application":
        """Create an Application from API data."""
        from .guild import Guild
        from .user import User

        # Parse integration types config
        integration_config = None
        if data.get("integration_types_config"):
            integration_config = {
                int(k): ApplicationIntegrationTypeConfig.from_dict(v)
                for k, v in data["integration_types_config"].items()
            }

        return cls(
            id=int(data["id"]),
            name=data["name"],
            icon=data.get("icon"),
            description=data["description"],
            bot_public=data["bot_public"],
            bot_require_code_grant=data["bot_require_code_grant"],
            verify_key=data["verify_key"],
            flags=data.get("flags", 0),
            rpc_origins=data.get("rpc_origins"),
            bot=User.from_dict(data["bot"], http) if data.get("bot") else None,
            terms_of_service_url=data.get("terms_of_service_url"),
            privacy_policy_url=data.get("privacy_policy_url"),
            owner=User.from_dict(data["owner"], http) if data.get("owner") else None,
            team=data.get("team"),
            guild_id=int(data["guild_id"]) if data.get("guild_id") else None,
            guild=Guild.from_dict(data["guild"], http) if data.get("guild") else None,
            primary_sku_id=int(data["primary_sku_id"]) if data.get("primary_sku_id") else None,
            slug=data.get("slug"),
            cover_image=data.get("cover_image"),
            approximate_guild_count=data.get("approximate_guild_count"),
            approximate_user_install_count=data.get("approximate_user_install_count"),
            approximate_user_authorization_count=data.get("approximate_user_authorization_count"),
            redirect_uris=data.get("redirect_uris"),
            interactions_endpoint_url=data.get("interactions_endpoint_url"),
            role_connections_verification_url=data.get("role_connections_verification_url"),
            event_webhooks_url=data.get("event_webhooks_url"),
            event_webhooks_status=data.get("event_webhooks_status", 1),
            event_webhooks_types=data.get("event_webhooks_types"),
            tags=data.get("tags"),
            install_params=(
                InstallParams.from_dict(data["install_params"])
                if data.get("install_params")
                else None
            ),
            integration_types_config=integration_config,
            custom_install_url=data.get("custom_install_url"),
            _http=http,
        )

    def to_dict(self) -> dict:
        """Convert to API format."""
        data = {
            "id": str(self.id),
            "name": self.name,
            "icon": self.icon,
            "description": self.description,
            "bot_public": self.bot_public,
            "bot_require_code_grant": self.bot_require_code_grant,
            "verify_key": self.verify_key,
            "flags": self.flags,
            "event_webhooks_status": self.event_webhooks_status,
        }

        # Add optional fields
        if self.rpc_origins:
            data["rpc_origins"] = self.rpc_origins
        if self.bot:
            data["bot"] = self.bot.to_dict()
        if self.terms_of_service_url:
            data["terms_of_service_url"] = self.terms_of_service_url
        if self.privacy_policy_url:
            data["privacy_policy_url"] = self.privacy_policy_url
        if self.owner:
            data["owner"] = self.owner.to_dict()
        if self.team:
            data["team"] = self.team
        if self.guild_id:
            data["guild_id"] = str(self.guild_id)
        if self.guild:
            data["guild"] = self.guild.to_dict()
        if self.primary_sku_id:
            data["primary_sku_id"] = str(self.primary_sku_id)
        if self.slug:
            data["slug"] = self.slug
        if self.cover_image:
            data["cover_image"] = self.cover_image
        if self.redirect_uris:
            data["redirect_uris"] = self.redirect_uris
        if self.interactions_endpoint_url:
            data["interactions_endpoint_url"] = self.interactions_endpoint_url
        if self.role_connections_verification_url:
            data["role_connections_verification_url"] = self.role_connections_verification_url
        if self.event_webhooks_url:
            data["event_webhooks_url"] = self.event_webhooks_url
        if self.event_webhooks_types:
            data["event_webhooks_types"] = self.event_webhooks_types
        if self.tags:
            data["tags"] = self.tags
        if self.install_params:
            data["install_params"] = self.install_params.to_dict()
        if self.integration_types_config:
            data["integration_types_config"] = {
                str(k): v.to_dict() for k, v in self.integration_types_config.items()
            }
        if self.custom_install_url:
            data["custom_install_url"] = self.custom_install_url

        return data

    @property
    def icon_url(self) -> Optional[str]:
        """Get the app icon URL."""
        if not self.icon:
            return None
        return f"https://cdn.discordapp.com/app-icons/{self.id}/{self.icon}.png"

    @property
    def cover_image_url(self) -> Optional[str]:
        """Get the cover image URL."""
        if not self.cover_image:
            return None
        return f"https://cdn.discordapp.com/app-assets/{self.id}/{self.cover_image}.png"

    @property
    def store_url(self) -> Optional[str]:
        """Get the store page URL (if game)."""
        if not self.slug:
            return None
        return f"https://discord.com/store/{self.slug}"

    @property
    def has_bot(self) -> bool:
        """Check if app has a bot user."""
        return self.bot is not None

    @property
    def is_public(self) -> bool:
        """Check if bot can be added by anyone."""
        return self.bot_public

    @property
    def requires_code_grant(self) -> bool:
        """Check if bot requires OAuth2 code grant."""
        return self.bot_require_code_grant

    @property
    def webhooks_enabled(self) -> bool:
        """Check if event webhooks are enabled."""
        return self.event_webhooks_status == ApplicationEventWebhookStatus.ENABLED

    @property
    def is_verified(self) -> bool:
        """Check if app is verified (estimated)."""
        return self.approximate_guild_count and self.approximate_guild_count >= 75

    @property
    def supports_guild_install(self) -> bool:
        """Check if app can be installed to guilds."""
        return self.integration_types_config and 0 in self.integration_types_config

    @property
    def supports_user_install(self) -> bool:
        """Check if app can be installed to users."""
        return self.integration_types_config and 1 in self.integration_types_config

    def has_flag(self, flag: ApplicationFlags) -> bool:
        """Check if app has a specific flag."""
        return bool(self.flags & flag)

    def __str__(self) -> str:
        """String representation."""
        return self.name

    def __repr__(self) -> str:
        """Developer representation."""
        return f"<Application id={self.id} name={self.name!r}>"


# HTTP Client Methods (to be added to HTTPClient)
"""
async def get_current_application(self) -> dict:
    '''Get the current application info.'''
    return await self.request('GET', '/applications/@me')

async def get_application(self, application_id: int) -> dict:
    '''Get an application by ID.'''
    return await self.request('GET', f'/applications/{application_id}')

async def edit_current_application(self, *, json: dict) -> dict:
    '''Edit the current application.
    
    JSON params:
        - custom_install_url (str): Custom install URL
        - description (str): Description
        - role_connections_verification_url (str): Role connections URL
        - install_params (object): Install params
        - integration_types_config (dict): Integration type configs
        - flags (int): Application flags
        - icon (str): Base64 icon
        - cover_image (str): Base64 cover image
        - interactions_endpoint_url (str): Interactions endpoint
        - tags (array): Content tags
    '''
    return await self.request('PATCH', '/applications/@me', json=json)
"""
