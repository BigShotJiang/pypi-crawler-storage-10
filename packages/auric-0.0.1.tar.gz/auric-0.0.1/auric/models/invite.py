"""
Invite Model

Represents Discord invite codes.
"""

from __future__ import annotations

from datetime import datetime
from enum import IntEnum
from typing import TYPE_CHECKING, Optional

from ..types.snowflake import Snowflake
from ..utils.flags import BaseFlags

if TYPE_CHECKING:
    from ..client import Client
    from ..http import HTTPClient
    from .application import PartialApplication
    from .channel import Channel, PartialChannel
    from .guild import Guild, PartialGuild
    from .guild_scheduled_event import GuildScheduledEvent
    from .user import User


__all__ = (
    "Invite",
    "InviteMetadata",
    "InviteType",
    "InviteTargetType",
    "InviteFlags",
)


class InviteType(IntEnum):
    """Type of invite."""

    GUILD = 0
    GROUP_DM = 1
    FRIEND = 2


class InviteTargetType(IntEnum):
    """Target type for voice channel invites."""

    STREAM = 1
    EMBEDDED_APPLICATION = 2


class InviteFlags(BaseFlags):
    """Flags for guild invites."""

    @property
    def is_guest_invite(self) -> bool:
        """Whether this invite is a guest invite for a voice channel."""
        return self._has_flag(1 << 0)


class Invite:
    """
    Represents a Discord invite.

    Attributes
    ----------
    type : InviteType
        The type of invite.
    code : str
        The invite code (unique ID).
    guild : PartialGuild | None
        The guild this invite is for.
    channel : PartialChannel | None
        The channel this invite is for.
    inviter : User | None
        The user who created the invite.
    target_type : InviteTargetType | None
        The type of target for this voice channel invite.
    target_user : User | None
        The user whose stream to display.
    target_application : PartialApplication | None
        The embedded application to open.
    approximate_presence_count : int | None
        Approximate count of online members.
    approximate_member_count : int | None
        Approximate count of total members.
    expires_at : datetime | None
        When this invite expires.
    guild_scheduled_event : GuildScheduledEvent | None
        Guild scheduled event data.
    flags : InviteFlags
        Guild invite flags.
    """

    __slots__ = (
        "_client",
        "_http",
        "type",
        "code",
        "guild",
        "channel",
        "inviter",
        "target_type",
        "target_user",
        "target_application",
        "approximate_presence_count",
        "approximate_member_count",
        "expires_at",
        "guild_scheduled_event",
        "flags",
    )

    def __init__(self, *, data: dict, client: Client = None) -> None:
        self._client = client
        self._http: HTTPClient = client._http if client else None
        self._update(data)

    def _update(self, data: dict) -> None:
        """Update the invite with new data."""
        from .channel import PartialChannel
        from .guild import PartialGuild
        from .user import User

        self.type: InviteType = InviteType(data.get("type", 0))
        self.code: str = data["code"]

        self.guild: Optional[PartialGuild] = None
        if guild_data := data.get("guild"):
            self.guild = PartialGuild(data=guild_data, client=self._client)

        self.channel: Optional[PartialChannel] = None
        if channel_data := data.get("channel"):
            self.channel = PartialChannel(data=channel_data, client=self._client)

        self.inviter: Optional[User] = None
        if inviter_data := data.get("inviter"):
            self.inviter = User(data=inviter_data, client=self._client)

        self.target_type: Optional[InviteTargetType] = None
        if target_type := data.get("target_type"):
            self.target_type = InviteTargetType(target_type)

        self.target_user: Optional[User] = None
        if target_user_data := data.get("target_user"):
            self.target_user = User(data=target_user_data, client=self._client)

        self.target_application: Optional[dict] = data.get("target_application")

        self.approximate_presence_count: Optional[int] = data.get("approximate_presence_count")
        self.approximate_member_count: Optional[int] = data.get("approximate_member_count")

        self.expires_at: Optional[datetime] = None
        if expires_at := data.get("expires_at"):
            from ..utils.time import parse_timestamp

            self.expires_at = parse_timestamp(expires_at)

        self.guild_scheduled_event: Optional[dict] = data.get("guild_scheduled_event")
        self.flags: InviteFlags = InviteFlags(data.get("flags", 0))

    def __repr__(self) -> str:
        return f"<Invite code={self.code!r} guild={self.guild}>"

    def __str__(self) -> str:
        return self.code

    @property
    def url(self) -> str:
        """The invite URL."""
        return f"https://discord.gg/{self.code}"

    @property
    def is_expired(self) -> bool:
        """Whether this invite has expired."""
        if self.expires_at is None:
            return False
        from datetime import datetime, timezone

        return datetime.now(timezone.utc) > self.expires_at

    @property
    def guild_id(self) -> Snowflake | None:
        """The ID of the guild this invite is for."""
        return self.guild.id if self.guild else None

    @property
    def channel_id(self) -> Snowflake | None:
        """The ID of the channel this invite is for."""
        return self.channel.id if self.channel else None

    async def delete(self, *, reason: str = None) -> None:
        """
        Delete this invite.

        Parameters
        ----------
        reason : str, optional
            Reason for deleting the invite.

        Raises
        ------
        HTTPException
            Deleting the invite failed.
        Forbidden
            You do not have permissions to delete this invite.
        NotFound
            The invite does not exist.
        """
        if not self._http:
            raise RuntimeError("Cannot delete invite without a client")

        await self._http.delete_invite(self.code, reason=reason)

    async def fetch(
        self,
        *,
        with_counts: bool = True,
        with_expiration: bool = True,
        guild_scheduled_event_id: Snowflake = None,
    ) -> Invite:
        """
        Fetch updated invite data.

        Parameters
        ----------
        with_counts : bool, default: True
            Whether to include approximate member counts.
        with_expiration : bool, default: True
            Whether to include the expiration date.
        guild_scheduled_event_id : Snowflake, optional
            The guild scheduled event to include.

        Returns
        -------
        Invite
            The updated invite.

        Raises
        ------
        HTTPException
            Fetching the invite failed.
        NotFound
            The invite does not exist.
        """
        if not self._http:
            raise RuntimeError("Cannot fetch invite without a client")

        params = {}
        if with_counts:
            params["with_counts"] = "true"
        if with_expiration:
            params["with_expiration"] = "true"
        if guild_scheduled_event_id:
            params["guild_scheduled_event_id"] = str(guild_scheduled_event_id)

        data = await self._http.get_invite(self.code, params=params)
        return Invite(data=data, client=self._client)


class InviteMetadata:
    """
    Extra metadata about an invite.

    Extends the Invite object with additional information.

    Attributes
    ----------
    uses : int
        Number of times this invite has been used.
    max_uses : int
        Max number of times this invite can be used.
    max_age : int
        Duration (in seconds) after which the invite expires.
    temporary : bool
        Whether this invite only grants temporary membership.
    created_at : datetime
        When this invite was created.
    """

    __slots__ = (
        "uses",
        "max_uses",
        "max_age",
        "temporary",
        "created_at",
    )

    def __init__(self, *, data: dict) -> None:
        self._update(data)

    def _update(self, data: dict) -> None:
        """Update the metadata with new data."""
        self.uses: int = data["uses"]
        self.max_uses: int = data["max_uses"]
        self.max_age: int = data["max_age"]
        self.temporary: bool = data["temporary"]

        from ..utils.time import parse_timestamp

        self.created_at: datetime = parse_timestamp(data["created_at"])

    def __repr__(self) -> str:
        return f"<InviteMetadata uses={self.uses}/{self.max_uses}>"

    @property
    def is_unlimited(self) -> bool:
        """Whether this invite has unlimited uses."""
        return self.max_uses == 0

    @property
    def is_permanent(self) -> bool:
        """Whether this invite never expires."""
        return self.max_age == 0

    @property
    def remaining_uses(self) -> int | None:
        """How many uses remain, or None if unlimited."""
        if self.is_unlimited:
            return None
        return max(0, self.max_uses - self.uses)
