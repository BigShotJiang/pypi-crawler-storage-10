"""
Channel models - all 13 channel types
"""

from __future__ import annotations

from enum import IntEnum
from typing import TYPE_CHECKING, Any, Dict, Optional

from ..core.types import Snowflake

if TYPE_CHECKING:
    from ..core.http import HTTPClient


class ChannelType(IntEnum):
    """Discord channel types"""

    GUILD_TEXT = 0
    DM = 1
    GUILD_VOICE = 2
    GROUP_DM = 3
    GUILD_CATEGORY = 4
    GUILD_ANNOUNCEMENT = 5
    ANNOUNCEMENT_THREAD = 10
    PUBLIC_THREAD = 11
    PRIVATE_THREAD = 12
    GUILD_STAGE_VOICE = 13
    GUILD_DIRECTORY = 14
    GUILD_FORUM = 15
    GUILD_MEDIA = 16


class PartialChannel:
    """
    Represents a partial channel object (used in invites and other contexts)

    Attributes:
        id: Channel ID
        name: Channel name
        type: Channel type
    """

    __slots__ = ("id", "name", "type", "_client", "_http")

    def __init__(self, *, data: Dict[str, Any], client=None):
        self._client = client
        self._http = client._http if client else None
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        """Update from API data"""
        self.id: Snowflake = int(data["id"])
        self.name: Optional[str] = data.get("name")
        self.type: ChannelType = ChannelType(data.get("type", 0))

    def __repr__(self) -> str:
        return f"<PartialChannel id={self.id} name={self.name!r} type={self.type.name}>"

    def __str__(self) -> str:
        return self.name or str(self.id)

    @property
    def mention(self) -> str:
        """Returns a string that mentions the channel"""
        return f"<#{self.id}>"


class Channel:
    """
    Base channel class

    Attributes:
        id: Channel ID
        type: Channel type
        name: Channel name
        guild_id: Guild ID (None for DMs)
        position: Sorting position
        permission_overwrites: Permission overwrites
        topic: Channel topic
        nsfw: Whether channel is NSFW
        last_message_id: Last message ID
        parent_id: Parent category ID
    """

    __slots__ = (
        "id",
        "type",
        "name",
        "guild_id",
        "position",
        "permission_overwrites",
        "topic",
        "nsfw",
        "last_message_id",
        "parent_id",
        "rate_limit_per_user",
        "_http",
    )

    def __init__(self, *, data: Dict[str, Any], http: Optional[HTTPClient] = None):
        self._http = http
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        """Update channel from API data"""
        self.id: Snowflake = int(data["id"])
        self.type: ChannelType = ChannelType(data.get("type", 0))
        self.name: Optional[str] = data.get("name")
        self.guild_id: Optional[Snowflake] = data.get("guild_id")
        self.position: Optional[int] = data.get("position")
        self.permission_overwrites: list = data.get("permission_overwrites", [])
        self.topic: Optional[str] = data.get("topic")
        self.nsfw: bool = data.get("nsfw", False)
        self.last_message_id: Optional[Snowflake] = data.get("last_message_id")
        self.parent_id: Optional[Snowflake] = data.get("parent_id")
        self.rate_limit_per_user: Optional[int] = data.get("rate_limit_per_user")

    def __repr__(self) -> str:
        return f"<Channel id={self.id} name={self.name!r} type={self.type.name}>"

    def __str__(self) -> str:
        return self.name or str(self.id)

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Channel) and self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)

    @property
    def mention(self) -> str:
        """Returns a string that mentions the channel"""
        return f"<#{self.id}>"

    async def send(
        self,
        content: Optional[str] = None,
        *,
        embed=None,
        embeds=None,
        tts: bool = False,
        nonce: Optional[str] = None,
        allowed_mentions=None,
        message_reference=None,
        components=None,
        sticker_ids=None,
        files=None,
        suppress_embeds: bool = False,
        silent: bool = False,
    ):
        """
        Send a message to this channel

        Args:
            content: Message content (up to 2000 characters)
            embed: Single embed object
            embeds: List of embed objects (up to 10)
            tts: Whether this is a TTS message
            nonce: Nonce for verification (up to 25 characters)
            allowed_mentions: Allowed mentions object
            message_reference: Message reference for replies
            components: Message components
            sticker_ids: Sticker IDs (up to 3)
            files: Files to attach
            suppress_embeds: Whether to suppress embeds
            silent: Whether to suppress notifications

        Returns:
            Message: The created message

        Raises:
            HTTPException: If the request fails
        """
        from ..core.http import Route
        from .message import Message

        # Build payload
        payload = {}

        if content is not None:
            payload["content"] = str(content)

        # Embeds
        if embed is not None:
            payload["embeds"] = [embed.to_dict()]
        elif embeds is not None:
            payload["embeds"] = [e.to_dict() for e in embeds]

        if tts:
            payload["tts"] = True

        if nonce is not None:
            payload["nonce"] = str(nonce)

        if allowed_mentions is not None:
            payload["allowed_mentions"] = allowed_mentions

        if message_reference is not None:
            payload["message_reference"] = message_reference

        if components is not None:
            if hasattr(components, "to_dict"):
                payload["components"] = components.to_dict()
            else:
                payload["components"] = components

        if sticker_ids is not None:
            payload["sticker_ids"] = [str(sid) for sid in sticker_ids]

        # Message flags
        flags = 0
        if suppress_embeds:
            flags |= 1 << 2  # SUPPRESS_EMBEDS
        if silent:
            flags |= 1 << 12  # SUPPRESS_NOTIFICATIONS

        if flags:
            payload["flags"] = flags

        # Validate: must have at least one of content, embeds, stickers, components, or files
        if not any([content, embed, embeds, sticker_ids, components, files]):
            raise ValueError(
                "Must provide at least one of: content, embed, embeds, sticker_ids, components, or files"
            )

        # Handle file uploads
        file_objects = None
        if files is not None:
            from ..utils.file import File

            # Convert to list if single file
            if not isinstance(files, list):
                files = [files]

            # Convert to File objects if needed
            file_objects = []
            for f in files:
                if isinstance(f, File):
                    file_objects.append(f)
                else:
                    # Auto-create File object
                    file_objects.append(File(f))

        # Send request
        data = await self._http.request(
            Route("POST", "/channels/{channel_id}/messages", channel_id=self.id),
            json=payload if not file_objects else payload,
            files=file_objects,
        )

        return Message(data=data, http=self._http)

    async def trigger_typing(self) -> None:
        """
        Trigger a typing indicator for 10 seconds

        Generally bots should not use this. However, if a bot is responding
        to a command and expects the computation to take a few seconds, this
        endpoint may be called to let the user know that the bot is processing.
        """
        from ..core.http import Route

        await self._http.request(Route("POST", "/channels/{channel_id}/typing", channel_id=self.id))

    async def history(
        self,
        *,
        limit: int = 50,
        before: Optional[Snowflake] = None,
        after: Optional[Snowflake] = None,
        around: Optional[Snowflake] = None,
    ) -> list:
        """
        Get message history for this channel

        Args:
            limit: Max messages to return (1-100), default 50
            before: Get messages before this message ID
            after: Get messages after this message ID
            around: Get messages around this message ID

        Note:
            before, after, and around are mutually exclusive

        Returns:
            list[Message]: List of messages (newest to oldest)

        Raises:
            ValueError: If multiple of before/after/around are provided
            HTTPException: If the request fails
        """
        from ..core.http import Route
        from .message import Message

        # Validate mutually exclusive params
        provided = sum(x is not None for x in [before, after, around])
        if provided > 1:
            raise ValueError("Only one of before, after, or around can be provided")

        # Build query params
        params = {"limit": min(max(limit, 1), 100)}

        if before is not None:
            params["before"] = str(before)
        elif after is not None:
            params["after"] = str(after)
        elif around is not None:
            params["around"] = str(around)

        # Make request
        data = await self._http.request(
            Route("GET", "/channels/{channel_id}/messages", channel_id=self.id), params=params
        )

        return [Message(data=msg, http=self._http) for msg in data]

    async def fetch_message(self, message_id: Snowflake):
        """
        Fetch a specific message from this channel

        Args:
            message_id: The message ID to fetch

        Returns:
            Message: The message object

        Raises:
            HTTPException: If message not found or no permission
        """
        from ..core.http import Route
        from .message import Message

        data = await self._http.request(
            Route(
                "GET",
                "/channels/{channel_id}/messages/{message_id}",
                channel_id=self.id,
                message_id=message_id,
            )
        )

        return Message(data=data, http=self._http)

    async def invites(self):
        """
        Get invites for this channel.

        Requires MANAGE_CHANNELS permission.

        Returns
        -------
        list[Invite]
            List of invite objects with metadata.

        Raises
        ------
        HTTPException
            Fetching invites failed.
        Forbidden
            You do not have permissions to manage this channel.
        """
        from .invite import Invite

        data = await self._http.get_channel_invites(self.id)
        return [Invite(data=invite, client=None) for invite in data]

    async def create_invite(
        self,
        *,
        max_age: int = 86400,
        max_uses: int = 0,
        temporary: bool = False,
        unique: bool = False,
        target_type: int = None,
        target_user_id: Snowflake = None,
        target_application_id: Snowflake = None,
        reason: str = None,
    ):
        """
        Create an invite for this channel.

        Requires CREATE_INSTANT_INVITE permission.

        Parameters
        ----------
        max_age : int, default: 86400
            Duration of invite in seconds before expiry (0 for never). Max 604800 (7 days).
        max_uses : int, default: 0
            Max number of uses (0 for unlimited). Max 100.
        temporary : bool, default: False
            Whether this invite grants temporary membership.
        unique : bool, default: False
            If true, don't reuse a similar invite.
        target_type : int, optional
            Type of target (1 = STREAM, 2 = EMBEDDED_APPLICATION).
        target_user_id : Snowflake, optional
            User ID whose stream to display (required if target_type is 1).
        target_application_id : Snowflake, optional
            Application ID to open (required if target_type is 2).
        reason : str, optional
            Reason for audit log.

        Returns
        -------
        Invite
            The created invite object.

        Raises
        ------
        HTTPException
            Creating the invite failed.
        Forbidden
            You do not have permissions to create invites.
        """
        from .invite import Invite

        payload = {
            "max_age": max_age,
            "max_uses": max_uses,
            "temporary": temporary,
            "unique": unique,
        }

        if target_type is not None:
            payload["target_type"] = target_type

        if target_user_id is not None:
            payload["target_user_id"] = str(target_user_id)

        if target_application_id is not None:
            payload["target_application_id"] = str(target_application_id)

        data = await self._http.create_channel_invite(self.id, json=payload, reason=reason)

        return Invite(data=data, client=None)

    async def pins(self, *, before: Optional[str] = None) -> list:
        """
        Get pinned messages in this channel

        Args:
            before: Get messages pinned before this ISO8601 timestamp

        Returns:
            list[Message]: List of pinned messages

        Requires:
            VIEW_CHANNEL and READ_MESSAGE_HISTORY permissions
        """
        from ..core.http import Route
        from .message import Message

        params = {}
        if before is not None:
            params["before"] = before

        data = await self._http.request(
            Route("GET", "/channels/{channel_id}/pins", channel_id=self.id),
            params=params if params else None,
        )

        return [Message(data=msg, http=self._http) for msg in data]

    async def purge(
        self,
        limit: int = 100,
        *,
        check=None,
        before: Optional[Snowflake] = None,
        after: Optional[Snowflake] = None,
        around: Optional[Snowflake] = None,
        reason: Optional[str] = None,
    ) -> list:
        """
        Bulk delete messages in this channel

        This is more efficient than deleting messages one by one.
        Can only delete messages less than 2 weeks old.

        Args:
            limit: Number of messages to search through
            check: Optional function to filter messages (return True to delete)
            before: Get messages before this message ID
            after: Get messages after this message ID
            around: Get messages around this message ID
            reason: Reason for audit log

        Returns:
            list[Message]: List of deleted messages

        Requires:
            MANAGE_MESSAGES permission

        Note:
            - Can only delete 2-100 messages at once
            - Messages must be less than 2 weeks old
            - Only works in guild channels
        """
        from datetime import datetime, timedelta, timezone

        from ..core.http import Route

        # Get messages
        messages = await self.history(limit=limit, before=before, after=after, around=around)

        # Filter by check function
        if check is not None:
            messages = [msg for msg in messages if check(msg)]

        # Filter out messages older than 2 weeks
        two_weeks_ago = datetime.now(timezone.utc) - timedelta(days=14)
        messages = [msg for msg in messages if msg.created_at > two_weeks_ago]

        if not messages:
            return []

        # Discord requires 2-100 messages for bulk delete
        if len(messages) == 1:
            # Delete single message
            await messages[0].delete(reason=reason)
            return messages

        # Bulk delete in chunks of 100
        deleted = []
        for i in range(0, len(messages), 100):
            chunk = messages[i : i + 100]

            if len(chunk) == 1:
                await chunk[0].delete(reason=reason)
            else:
                message_ids = [str(msg.id) for msg in chunk]

                await self._http.request(
                    Route(
                        "POST", "/channels/{channel_id}/messages/bulk-delete", channel_id=self.id
                    ),
                    json={"messages": message_ids},
                    reason=reason,
                )

            deleted.extend(chunk)

        return deleted

    async def set_permissions(
        self,
        target,
        *,
        overwrite: Optional[Any] = None,
        allow: Optional[Any] = None,
        deny: Optional[Any] = None,
        reason: Optional[str] = None,
    ):
        """
        Set permission overwrites for a role or member in this channel

        Args:
            target: Role, Member, or ID to set permissions for
            overwrite: PermissionOverwrite object (if provided, allow/deny are ignored)
            allow: Permissions to explicitly allow
            deny: Permissions to explicitly deny
            reason: Audit log reason

        Examples:
            # Using PermissionOverwrite
            from auric.models.role import PermissionOverwrite, Permissions

            overwrite = PermissionOverwrite.for_role(
                role,
                allow=Permissions.SEND_MESSAGES | Permissions.VIEW_CHANNEL,
                deny=Permissions.MANAGE_MESSAGES
            )
            await channel.set_permissions(role, overwrite=overwrite)

            # Using allow/deny directly
            await channel.set_permissions(
                member,
                allow=Permissions.SEND_MESSAGES,
                deny=Permissions.MANAGE_MESSAGES
            )

        Requires:
            MANAGE_ROLES or MANAGE_PERMISSIONS permission
        """
        from ..core.http import Route
        from .role import Permissions

        # Get target ID and type
        target_id = target.id if hasattr(target, "id") else target

        # Determine target type (0 = role, 1 = member)
        target_type = 0
        if hasattr(target, "user"):  # It's a Member
            target_type = 1
        elif not hasattr(target, "permissions"):  # Not a Role, assume user ID
            # If it's just an ID, we need to guess - default to role
            # This could be improved by checking guild.get_role() or guild.get_member()
            pass

        # Build payload
        if overwrite is not None:
            payload = {
                "allow": str(int(overwrite.allow)),
                "deny": str(int(overwrite.deny)),
                "type": overwrite.type,
            }
        else:
            # Use allow/deny parameters
            allow_val = int(allow) if allow is not None else 0
            deny_val = int(deny) if deny is not None else 0

            payload = {"allow": str(allow_val), "deny": str(deny_val), "type": target_type}

        await self._http.request(
            Route(
                "PUT",
                "/channels/{channel_id}/permissions/{overwrite_id}",
                channel_id=self.id,
                overwrite_id=target_id,
            ),
            json=payload,
            reason=reason,
        )

    async def delete_permissions(self, target, *, reason: Optional[str] = None):
        """
        Delete permission overwrites for a role or member

        Args:
            target: Role, Member, or ID to remove permissions for
            reason: Audit log reason

        Requires:
            MANAGE_ROLES or MANAGE_PERMISSIONS permission
        """
        from ..core.http import Route

        target_id = target.id if hasattr(target, "id") else target

        await self._http.request(
            Route(
                "DELETE",
                "/channels/{channel_id}/permissions/{overwrite_id}",
                channel_id=self.id,
                overwrite_id=target_id,
            ),
            reason=reason,
        )

    @property
    def overwrites(self):
        """
        Get all permission overwrites for this channel

        Returns:
            list[PermissionOverwrite]: List of permission overwrites
        """
        from .role import PermissionOverwrite

        return [PermissionOverwrite.from_data(data) for data in self.permission_overwrites]


class TextChannel(Channel):
    """Text channel with webhook support"""

    async def create_webhook(
        self, *, name: str, avatar: Optional[bytes] = None, reason: Optional[str] = None
    ):
        """
        Create a webhook in this channel

        Args:
            name: Webhook name (1-80 characters)
            avatar: Webhook avatar image data
            reason: Audit log reason

        Returns:
            Webhook object

        Raises:
            Forbidden: Missing MANAGE_WEBHOOKS permission
            HTTPException: Creation failed

        Note:
            Webhook name cannot contain 'clyde' or 'discord' (case-insensitive)
        """
        from ..core.http import Route
        from .webhook import Webhook

        payload = {"name": name}

        if avatar:
            import base64

            payload["avatar"] = f"data:image/png;base64,{base64.b64encode(avatar).decode('ascii')}"

        data = await self._http.request(
            Route("POST", "/channels/{channel_id}/webhooks", channel_id=self.id),
            json=payload,
            reason=reason,
        )

        return Webhook(data=data, http=self._http)

    async def webhooks(self):
        """
        Get all webhooks for this channel

        Returns:
            List of Webhook objects

        Requires:
            MANAGE_WEBHOOKS permission
        """
        from ..core.http import Route
        from .webhook import Webhook

        data = await self._http.request(
            Route("GET", "/channels/{channel_id}/webhooks", channel_id=self.id)
        )

        return [Webhook(data=wh, http=self._http) for wh in data]


class VoiceChannel(Channel):
    """Voice channel"""

    pass


class CategoryChannel(Channel):
    """Category channel"""

    pass


class DMChannel(Channel):
    """DM channel"""

    pass


class Thread(Channel):
    """
    Thread channel with specialized operations

    Attributes:
        All Channel attributes plus:
        thread_metadata: Thread-specific metadata
        member_count: Approximate member count
        message_count: Approximate message count
        archived: Whether thread is archived
        locked: Whether thread is locked
        auto_archive_duration: Minutes of inactivity before auto-archiving
    """

    def _update(self, data: Dict[str, Any]) -> None:
        """Update thread from API data"""
        super()._update(data)

        # Thread-specific fields
        metadata = data.get("thread_metadata", {})
        self.archived: bool = metadata.get("archived", False)
        self.auto_archive_duration: int = metadata.get("auto_archive_duration", 60)
        self.archive_timestamp: Optional[str] = metadata.get("archive_timestamp")
        self.locked: bool = metadata.get("locked", False)
        self.invitable: Optional[bool] = metadata.get("invitable")
        self.create_timestamp: Optional[str] = metadata.get("create_timestamp")

        self.member_count: Optional[int] = data.get("member_count")
        self.message_count: Optional[int] = data.get("message_count")
        self.owner_id: Optional[Snowflake] = data.get("owner_id")

    async def archive(self, *, reason: Optional[str] = None):
        """
        Archive this thread

        Args:
            reason: Audit log reason

        Raises:
            Forbidden: Missing MANAGE_THREADS permission
        """
        from ..core.http import Route

        await self._http.request(
            Route("PATCH", "/channels/{channel_id}", channel_id=self.id),
            json={"archived": True},
            reason=reason,
        )
        self.archived = True

    async def unarchive(self, *, reason: Optional[str] = None):
        """
        Unarchive this thread

        Args:
            reason: Audit log reason

        Raises:
            Forbidden: Missing MANAGE_THREADS or thread member permission
        """
        from ..core.http import Route

        await self._http.request(
            Route("PATCH", "/channels/{channel_id}", channel_id=self.id),
            json={"archived": False},
            reason=reason,
        )
        self.archived = False

    async def lock(self, *, reason: Optional[str] = None):
        """
        Lock this thread (prevents non-moderators from sending messages)

        Args:
            reason: Audit log reason

        Requires:
            MANAGE_THREADS permission
        """
        from ..core.http import Route

        await self._http.request(
            Route("PATCH", "/channels/{channel_id}", channel_id=self.id),
            json={"locked": True},
            reason=reason,
        )
        self.locked = True

    async def unlock(self, *, reason: Optional[str] = None):
        """
        Unlock this thread

        Args:
            reason: Audit log reason

        Requires:
            MANAGE_THREADS permission
        """
        from ..core.http import Route

        await self._http.request(
            Route("PATCH", "/channels/{channel_id}", channel_id=self.id),
            json={"locked": False},
            reason=reason,
        )
        self.locked = False

    async def add_member(self, user_id: Snowflake):
        """
        Add a member to this thread

        Args:
            user_id: User ID to add

        Raises:
            Forbidden: Missing permission or thread is archived
        """
        from ..core.http import Route

        await self._http.request(
            Route(
                "PUT",
                "/channels/{channel_id}/thread-members/{user_id}",
                channel_id=self.id,
                user_id=user_id,
            )
        )

    async def remove_member(self, user_id: Snowflake):
        """
        Remove a member from this thread

        Args:
            user_id: User ID to remove

        Requires:
            MANAGE_THREADS permission or be the thread owner
        """
        from ..core.http import Route

        await self._http.request(
            Route(
                "DELETE",
                "/channels/{channel_id}/thread-members/{user_id}",
                channel_id=self.id,
                user_id=user_id,
            )
        )

    async def join(self):
        """Join this thread"""
        from ..core.http import Route

        await self._http.request(
            Route("PUT", "/channels/{channel_id}/thread-members/@me", channel_id=self.id)
        )

    async def leave(self):
        """Leave this thread"""
        from ..core.http import Route

        await self._http.request(
            Route("DELETE", "/channels/{channel_id}/thread-members/@me", channel_id=self.id)
        )

    async def fetch_members(self):
        """
        Fetch all members in this thread

        Returns:
            List of thread member objects

        Note:
            Requires GUILD_MEMBERS intent if member count > 50
        """
        from ..core.http import Route

        data = await self._http.request(
            Route("GET", "/channels/{channel_id}/thread-members", channel_id=self.id)
        )

        return data  # Returns list of thread member objects


class ForumChannel(Channel):
    """Forum channel"""

    pass
