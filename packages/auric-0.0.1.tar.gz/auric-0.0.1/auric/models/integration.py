"""
Integration model for guild integrations
"""

from __future__ import annotations

from datetime import datetime
from enum import IntEnum
from typing import TYPE_CHECKING, Any, Dict, Optional

from ..core.types import Snowflake

if TYPE_CHECKING:
    from ..core.http import HTTPClient
    from .guild import Guild
    from .user import User


class IntegrationExpireBehavior(IntEnum):
    """Integration expire behavior"""

    REMOVE_ROLE = 0
    KICK = 1


class Integration:
    """
    Represents a guild integration

    Attributes:
        id: Integration ID
        name: Integration name
        type: Integration type (twitch, youtube, discord, guild_subscription)
        enabled: Whether integration is enabled
        syncing: Whether integration is syncing
        role_id: Role ID for subscribers
        enable_emoticons: Whether emoticons should be synced
        expire_behavior: Expiration behavior
        expire_grace_period: Grace period (in days)
        user: User for this integration
        account: Integration account information
        synced_at: When integration was last synced
        subscriber_count: Subscriber count
        revoked: Whether integration was revoked
        application: Application for integrations
        scopes: OAuth2 scopes
    """

    __slots__ = (
        "id",
        "name",
        "type",
        "enabled",
        "syncing",
        "role_id",
        "enable_emoticons",
        "expire_behavior",
        "expire_grace_period",
        "user",
        "account",
        "synced_at",
        "subscriber_count",
        "revoked",
        "application",
        "scopes",
        "guild_id",
        "_http",
    )

    def __init__(self, *, data: Dict[str, Any], http: Optional[HTTPClient] = None):
        self._http = http
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        """Update integration from API data"""
        self.id: Snowflake = int(data["id"])
        self.name: str = data["name"]
        self.type: str = data["type"]
        self.enabled: bool = data.get("enabled", False)
        self.syncing: Optional[bool] = data.get("syncing")
        self.role_id: Optional[Snowflake] = data.get("role_id")
        self.enable_emoticons: Optional[bool] = data.get("enable_emoticons")

        expire_behavior = data.get("expire_behavior")
        self.expire_behavior: Optional[IntegrationExpireBehavior] = (
            IntegrationExpireBehavior(expire_behavior) if expire_behavior is not None else None
        )

        self.expire_grace_period: Optional[int] = data.get("expire_grace_period")
        self.user: Optional[Dict[str, Any]] = data.get("user")
        self.account: Dict[str, Any] = data.get("account", {})

        synced_at = data.get("synced_at")
        self.synced_at: Optional[datetime] = (
            datetime.fromisoformat(synced_at.replace("Z", "+00:00")) if synced_at else None
        )

        self.subscriber_count: Optional[int] = data.get("subscriber_count")
        self.revoked: Optional[bool] = data.get("revoked")
        self.application: Optional[Dict[str, Any]] = data.get("application")
        self.scopes: Optional[list] = data.get("scopes")
        self.guild_id: Optional[Snowflake] = data.get("guild_id")

    def __repr__(self) -> str:
        return f"<Integration id={self.id} name={self.name!r} type={self.type}>"

    def __str__(self) -> str:
        return self.name

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Integration) and self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)

    async def delete(self, *, reason: Optional[str] = None) -> None:
        """
        Delete this integration

        Args:
            reason: Reason for audit log
        """
        if not self._http or not self.guild_id:
            raise ValueError("Integration requires HTTP client and guild_id to delete")

        await self._http.delete_guild_integration(
            guild_id=self.guild_id, integration_id=self.id, reason=reason
        )
