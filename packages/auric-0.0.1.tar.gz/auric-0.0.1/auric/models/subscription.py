"""
Subscription Model - Discord Monetization
Represents a subscription to a premium app.
"""

from datetime import datetime
from enum import IntEnum
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from .entitlement import Entitlement
    from .sku import SKU
    from .user import User


class SubscriptionStatus(IntEnum):
    """Subscription status values."""

    ACTIVE = 0  # Subscription is active
    ENDING = 1  # Subscription will not renew
    INACTIVE = 2  # Subscription is inactive


class Subscription:
    """
    Represents a premium app subscription.

    Subscriptions allow users to access premium features through recurring payments.

    Attributes:
        id: Unique subscription ID
        user_id: ID of the subscribing user
        sku_ids: List of SKU IDs included in subscription
        entitlement_ids: List of entitlement IDs granted by subscription
        current_period_start: Start of current billing period
        current_period_end: End of current billing period
        status: Current subscription status
        canceled_at: When subscription was canceled (if applicable)
        country_code: Country code for billing
    """

    def __init__(self, data: Dict[str, Any], http_client=None):
        """
        Initialize a Subscription from API data.

        Args:
            data: Raw subscription data from Discord API
            http_client: Optional HTTP client for API operations
        """
        self._http = http_client
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        """Update subscription with new data."""
        self.id: str = data.get("id", "")
        self.user_id: str = data.get("user_id", "")
        self.sku_ids: List[str] = data.get("sku_ids", [])
        self.entitlement_ids: List[str] = data.get("entitlement_ids", [])

        # Timestamps
        self.current_period_start: Optional[datetime] = None
        if start := data.get("current_period_start"):
            self.current_period_start = datetime.fromisoformat(start.replace("Z", "+00:00"))

        self.current_period_end: Optional[datetime] = None
        if end := data.get("current_period_end"):
            self.current_period_end = datetime.fromisoformat(end.replace("Z", "+00:00"))

        self.canceled_at: Optional[datetime] = None
        if canceled := data.get("canceled_at"):
            self.canceled_at = datetime.fromisoformat(canceled.replace("Z", "+00:00"))

        # Status
        self.status: SubscriptionStatus = SubscriptionStatus(data.get("status", 0))

        # Optional fields
        self.country_code: Optional[str] = data.get("country_code")

        # Store raw data
        self._raw_data = data

    @property
    def is_active(self) -> bool:
        """Check if subscription is currently active."""
        return self.status == SubscriptionStatus.ACTIVE

    @property
    def is_ending(self) -> bool:
        """Check if subscription is set to end (will not renew)."""
        return self.status == SubscriptionStatus.ENDING

    @property
    def is_inactive(self) -> bool:
        """Check if subscription is inactive."""
        return self.status == SubscriptionStatus.INACTIVE

    @property
    def is_canceled(self) -> bool:
        """Check if subscription has been canceled."""
        return self.canceled_at is not None

    @property
    def days_until_renewal(self) -> Optional[int]:
        """
        Get days until next renewal.

        Returns:
            Number of days until renewal, or None if no end date
        """
        if not self.current_period_end:
            return None

        delta = self.current_period_end - datetime.now(self.current_period_end.tzinfo)
        return max(0, delta.days)

    def __repr__(self) -> str:
        return f"<Subscription id={self.id} user_id={self.user_id} status={self.status.name}>"

    def __str__(self) -> str:
        return f"Subscription {self.id}"

    def __eq__(self, other) -> bool:
        return isinstance(other, Subscription) and other.id == self.id

    def __hash__(self) -> int:
        return hash(self.id)

    def to_dict(self) -> Dict[str, Any]:
        """Convert subscription to dictionary representation."""
        result = {
            "id": self.id,
            "user_id": self.user_id,
            "sku_ids": self.sku_ids,
            "entitlement_ids": self.entitlement_ids,
            "status": self.status,
        }

        if self.current_period_start:
            result["current_period_start"] = self.current_period_start.isoformat()

        if self.current_period_end:
            result["current_period_end"] = self.current_period_end.isoformat()

        if self.canceled_at:
            result["canceled_at"] = self.canceled_at.isoformat()

        if self.country_code:
            result["country_code"] = self.country_code

        return result


__all__ = [
    "Subscription",
    "SubscriptionStatus",
]
