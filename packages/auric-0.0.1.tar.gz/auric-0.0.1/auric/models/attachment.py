"""
Attachment Model

Represents files attached to Discord messages.
"""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Optional

from ..types.snowflake import Snowflake
from ..utils.flags import BaseFlags

if TYPE_CHECKING:
    from ..client import Client
    from ..http import HTTPClient


__all__ = (
    "Attachment",
    "AttachmentFlags",
)


class AttachmentFlags(BaseFlags):
    """Flags for an attachment."""

    @property
    def is_clip(self) -> bool:
        """Whether this attachment has been edited using the remix feature on mobile."""
        return self._has_flag(1 << 0)

    @property
    def is_thumbnail(self) -> bool:
        """Whether this attachment is a thumbnail."""
        return self._has_flag(1 << 1)

    @property
    def is_remix(self) -> bool:
        """Whether this attachment has been edited using the remix feature on mobile."""
        return self._has_flag(1 << 2)


class Attachment:
    """
    Represents a file attached to a message.

    Attributes
    ----------
    id : Snowflake
        Attachment ID.
    filename : str
        Name of file attached.
    title : str | None
        The title of the file.
    description : str | None
        Description for the file (max 1024 characters).
    content_type : str | None
        The attachment's media type.
    size : int
        Size of file in bytes.
    url : str
        Source URL of file.
    proxy_url : str
        Proxied URL of file.
    height : int | None
        Height of file (if image).
    width : int | None
        Width of file (if image).
    ephemeral : bool
        Whether this attachment is ephemeral.
    duration_secs : float | None
        Duration of audio file (for voice messages).
    waveform : str | None
        Base64 encoded waveform (for voice messages).
    flags : AttachmentFlags
        Attachment flags.
    """

    __slots__ = (
        "_client",
        "_http",
        "id",
        "filename",
        "title",
        "description",
        "content_type",
        "size",
        "url",
        "proxy_url",
        "height",
        "width",
        "ephemeral",
        "duration_secs",
        "waveform",
        "flags",
    )

    def __init__(self, *, data: dict, client: Client = None) -> None:
        self._client = client
        self._http: HTTPClient = client._http if client else None
        self._update(data)

    def _update(self, data: dict) -> None:
        """Update the attachment with new data."""
        self.id: Snowflake = Snowflake(data["id"])
        self.filename: str = data["filename"]
        self.title: Optional[str] = data.get("title")
        self.description: Optional[str] = data.get("description")
        self.content_type: Optional[str] = data.get("content_type")
        self.size: int = data["size"]
        self.url: str = data["url"]
        self.proxy_url: str = data["proxy_url"]
        self.height: Optional[int] = data.get("height")
        self.width: Optional[int] = data.get("width")
        self.ephemeral: bool = data.get("ephemeral", False)
        self.duration_secs: Optional[float] = data.get("duration_secs")
        self.waveform: Optional[str] = data.get("waveform")
        self.flags: AttachmentFlags = AttachmentFlags(data.get("flags", 0))

    def __repr__(self) -> str:
        return f"<Attachment id={self.id} filename={self.filename!r} size={self.size}>"

    def __str__(self) -> str:
        return self.filename

    @property
    def created_at(self) -> datetime:
        """When the attachment was created."""
        return self.id.created_at

    @property
    def is_image(self) -> bool:
        """Whether this attachment is an image."""
        if self.content_type:
            return self.content_type.startswith("image/")
        # Fallback to extension check
        return self.filename.lower().endswith((".png", ".jpg", ".jpeg", ".gif", ".webp"))

    @property
    def is_video(self) -> bool:
        """Whether this attachment is a video."""
        if self.content_type:
            return self.content_type.startswith("video/")
        return self.filename.lower().endswith((".mp4", ".mov", ".avi", ".webm"))

    @property
    def is_audio(self) -> bool:
        """Whether this attachment is audio."""
        if self.content_type:
            return self.content_type.startswith("audio/")
        return self.filename.lower().endswith((".mp3", ".wav", ".ogg", ".flac"))

    @property
    def is_voice_message(self) -> bool:
        """Whether this attachment is a voice message."""
        return self.is_audio and self.duration_secs is not None and self.waveform is not None

    @property
    def is_spoiler(self) -> bool:
        """Whether this attachment is a spoiler."""
        return self.filename.startswith("SPOILER_")

    @property
    def dimensions(self) -> tuple[int, int] | None:
        """Get the dimensions of the attachment (width, height) if available."""
        if self.width is not None and self.height is not None:
            return (self.width, self.height)
        return None

    def to_dict(self) -> dict:
        """
        Convert the attachment to a dictionary for API requests.

        For message edits, only id, filename, title, and description are needed.
        """
        result = {
            "id": str(self.id),
            "filename": self.filename,
        }

        if self.title is not None:
            result["title"] = self.title

        if self.description is not None:
            result["description"] = self.description

        return result

    async def read(self) -> bytes:
        """
        Download and read the attachment content.

        Returns
        -------
        bytes
            The attachment's content.

        Raises
        ------
        HTTPException
            Downloading the attachment failed.
        """
        if not self._http:
            raise RuntimeError("Cannot download attachment without a client")

        import aiohttp

        async with aiohttp.ClientSession() as session:
            async with session.get(self.url) as response:
                if response.status == 200:
                    return await response.read()
                else:
                    raise RuntimeError(f"Failed to download attachment: {response.status}")

    async def save(self, fp: str) -> int:
        """
        Save the attachment to a file.

        Parameters
        ----------
        fp : str
            The file path to save to.

        Returns
        -------
        int
            The number of bytes written.

        Raises
        ------
        HTTPException
            Downloading the attachment failed.
        """
        data = await self.read()

        with open(fp, "wb") as f:
            return f.write(data)
