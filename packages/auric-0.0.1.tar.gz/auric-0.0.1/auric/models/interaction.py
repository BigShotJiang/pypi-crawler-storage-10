"""
Interaction model - for slash commands and components
"""

from __future__ import annotations

from enum import IntEnum
from typing import TYPE_CHECKING, Any, Dict, Optional

from ..core.types import Snowflake

if TYPE_CHECKING:
    from ..core.http import HTTPClient
    from .member import Member
    from .user import User


class InteractionType(IntEnum):
    """Interaction types"""

    PING = 1
    APPLICATION_COMMAND = 2
    MESSAGE_COMPONENT = 3
    APPLICATION_COMMAND_AUTOCOMPLETE = 4
    MODAL_SUBMIT = 5


class InteractionResponseType(IntEnum):
    """Interaction response types"""

    PONG = 1
    CHANNEL_MESSAGE_WITH_SOURCE = 4
    DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE = 5
    DEFERRED_UPDATE_MESSAGE = 6
    UPDATE_MESSAGE = 7
    APPLICATION_COMMAND_AUTOCOMPLETE_RESULT = 8
    MODAL = 9
    PREMIUM_REQUIRED = 10
    LAUNCH_ACTIVITY = 12


class Interaction:
    """
    Represents a Discord interaction

    Attributes:
        id: Interaction ID
        application_id: Application ID
        type: Interaction type
        data: Interaction data
        guild_id: Guild ID
        channel_id: Channel ID
        member: Guild member (if in guild)
        user: User (if in DM)
        token: Interaction token
        version: Interaction version
    """

    __slots__ = (
        "id",
        "application_id",
        "type",
        "data",
        "guild_id",
        "channel_id",
        "member",
        "user",
        "token",
        "version",
        "message",
        "locale",
        "guild_locale",
        "_http",
        "_responded",
    )

    def __init__(self, *, data: Dict[str, Any], http: Optional[HTTPClient] = None):
        self._http = http
        self._responded = False
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        """Update interaction from API data"""
        from .member import Member
        from .user import User

        self.id: Snowflake = int(data["id"])
        self.application_id: Snowflake = int(data["application_id"])
        self.type: InteractionType = InteractionType(data["type"])
        self.data: Dict[str, Any] = data.get("data", {})
        self.guild_id: Optional[Snowflake] = data.get("guild_id")
        self.channel_id: Optional[Snowflake] = data.get("channel_id")

        # Member or user
        member_data = data.get("member")
        if member_data:
            self.member = Member(data=member_data, guild_id=self.guild_id, http=self._http)
            self.user = self.member.user
        else:
            user_data = data.get("user")
            self.user = User(data=user_data, http=self._http) if user_data else None
            self.member = None

        self.token: str = data["token"]
        self.version: int = data.get("version", 1)
        self.message = data.get("message")
        self.locale: Optional[str] = data.get("locale")
        self.guild_locale: Optional[str] = data.get("guild_locale")

    def __repr__(self) -> str:
        return f"<Interaction id={self.id} type={self.type.name}>"

    @property
    def author(self):
        """Alias for user"""
        return self.user

    # Response methods

    async def respond(
        self,
        content: Optional[str] = None,
        *,
        embed: Optional[Any] = None,
        embeds: Optional[list] = None,
        tts: bool = False,
        ephemeral: bool = False,
        allowed_mentions: Optional[Dict[str, Any]] = None,
        components: Optional[list] = None,
        attachments: Optional[list] = None,
    ) -> None:
        """
        Respond to this interaction

        Args:
            content: Message content
            embed: Single embed
            embeds: List of embeds
            tts: Whether to use text-to-speech
            ephemeral: Whether message is ephemeral (only visible to user)
            allowed_mentions: Allowed mentions object
            components: Message components
            attachments: Attachments

        Raises:
            HTTPException: Response failed
        """
        from ..core.http import Route

        if self._responded:
            raise RuntimeError("Already responded to this interaction")

        payload = {"type": InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE}

        data = {}

        if content:
            data["content"] = content

        if embed:
            data["embeds"] = [embed.to_dict() if hasattr(embed, "to_dict") else embed]
        elif embeds:
            data["embeds"] = [e.to_dict() if hasattr(e, "to_dict") else e for e in embeds]

        if tts:
            data["tts"] = True

        if ephemeral:
            data["flags"] = 64  # EPHEMERAL flag

        if allowed_mentions:
            data["allowed_mentions"] = allowed_mentions

        if components:
            data["components"] = components

        if attachments:
            data["attachments"] = attachments

        payload["data"] = data

        route = Route(
            "POST",
            "/interactions/{interaction_id}/{token}/callback",
            interaction_id=self.id,
            token=self.token,
        )
        await self._http.request(route, json=payload)
        self._responded = True

    async def defer(self, *, ephemeral: bool = False) -> None:
        """
        Defer the interaction response (shows loading state)

        Args:
            ephemeral: Whether the deferred response should be ephemeral

        Raises:
            HTTPException: Defer failed
        """
        from ..core.http import Route

        if self._responded:
            raise RuntimeError("Already responded to this interaction")

        payload = {"type": InteractionResponseType.DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE}

        if ephemeral:
            payload["data"] = {"flags": 64}  # EPHEMERAL flag

        route = Route(
            "POST",
            "/interactions/{interaction_id}/{token}/callback",
            interaction_id=self.id,
            token=self.token,
        )
        await self._http.request(route, json=payload)
        self._responded = True

    async def edit_response(
        self,
        content: Optional[str] = None,
        *,
        embed: Optional[Any] = None,
        embeds: Optional[list] = None,
        allowed_mentions: Optional[Dict[str, Any]] = None,
        components: Optional[list] = None,
        attachments: Optional[list] = None,
    ):
        """
        Edit the original interaction response

        Args:
            content: New message content
            embed: Single embed
            embeds: List of embeds
            allowed_mentions: Allowed mentions object
            components: Message components
            attachments: Attachments

        Returns:
            Message object

        Raises:
            HTTPException: Edit failed
        """
        from ..core.http import Route
        from .message import Message

        payload = {}

        if content is not None:
            payload["content"] = content

        if embed:
            payload["embeds"] = [embed.to_dict() if hasattr(embed, "to_dict") else embed]
        elif embeds is not None:
            payload["embeds"] = [e.to_dict() if hasattr(e, "to_dict") else e for e in embeds]

        if allowed_mentions:
            payload["allowed_mentions"] = allowed_mentions

        if components is not None:
            payload["components"] = components

        if attachments is not None:
            payload["attachments"] = attachments

        route = Route(
            "PATCH",
            "/webhooks/{app_id}/{token}/messages/@original",
            app_id=self.application_id,
            token=self.token,
        )
        data = await self._http.request(route, json=payload)
        return Message(data=data, http=self._http)

    async def delete_response(self) -> None:
        """
        Delete the original interaction response

        Raises:
            HTTPException: Delete failed
        """
        from ..core.http import Route

        route = Route(
            "DELETE",
            "/webhooks/{app_id}/{token}/messages/@original",
            app_id=self.application_id,
            token=self.token,
        )
        await self._http.request(route)

    async def followup(
        self,
        content: Optional[str] = None,
        *,
        embed: Optional[Any] = None,
        embeds: Optional[list] = None,
        tts: bool = False,
        ephemeral: bool = False,
        allowed_mentions: Optional[Dict[str, Any]] = None,
        components: Optional[list] = None,
        attachments: Optional[list] = None,
    ):
        """
        Send a followup message

        Args:
            content: Message content
            embed: Single embed
            embeds: List of embeds
            tts: Whether to use text-to-speech
            ephemeral: Whether message is ephemeral
            allowed_mentions: Allowed mentions object
            components: Message components
            attachments: Attachments

        Returns:
            Message object

        Raises:
            HTTPException: Followup failed
        """
        from ..core.http import Route
        from .message import Message

        payload = {}

        if content:
            payload["content"] = content

        if embed:
            payload["embeds"] = [embed.to_dict() if hasattr(embed, "to_dict") else embed]
        elif embeds:
            payload["embeds"] = [e.to_dict() if hasattr(e, "to_dict") else e for e in embeds]

        if tts:
            payload["tts"] = True

        if ephemeral:
            payload["flags"] = 64  # EPHEMERAL flag

        if allowed_mentions:
            payload["allowed_mentions"] = allowed_mentions

        if components:
            payload["components"] = components

        if attachments:
            payload["attachments"] = attachments

        route = Route(
            "POST", "/webhooks/{app_id}/{token}", app_id=self.application_id, token=self.token
        )
        data = await self._http.request(route, json=payload)
        return Message(data=data, http=self._http)

    async def send_modal(
        self,
        modal,
        custom_id: Optional[str] = None,
        title: Optional[str] = None,
        components: Optional[list] = None,
    ) -> None:
        """
        Respond with a modal dialog

        Args:
            modal: Modal object or dict, or pass custom_id/title/components separately
            custom_id: Custom ID for the modal (max 100 chars) - if not using Modal object
            title: Modal title (max 45 chars) - if not using Modal object
            components: Modal components (1-5) - if not using Modal object

        Example:
            ```python
            # Using Modal object (recommended)
            from auric.models import Modal, Label, TextInput, TextInputStyle

            modal = Modal(
                custom_id="feedback",
                title="Feedback",
                components=[
                    Label(
                        label="Your Feedback",
                        component=TextInput(
                            custom_id="feedback_text",
                            style=TextInputStyle.PARAGRAPH,
                            label="Feedback"
                        )
                    )
                ]
            )
            await interaction.send_modal(modal)

            # Using dict or separate args (legacy)
            await interaction.send_modal(
                custom_id="feedback",
                title="Feedback",
                components=[...]
            )
            ```

        Raises:
            HTTPException: Modal failed
        """
        from ..core.http import Route

        if self._responded:
            raise RuntimeError("Already responded to this interaction")

        # Handle Modal object
        if hasattr(modal, "to_dict"):
            modal_data = modal.to_dict()
        elif isinstance(modal, dict):
            modal_data = modal
        elif custom_id and title and components:
            # Legacy: separate parameters
            modal_data = {"custom_id": custom_id, "title": title, "components": components}
        else:
            raise ValueError("Must provide Modal object, dict, or custom_id/title/components")

        payload = {"type": InteractionResponseType.MODAL, "data": modal_data}

        route = Route(
            "POST",
            "/interactions/{interaction_id}/{token}/callback",
            interaction_id=self.id,
            token=self.token,
        )
        await self._http.request(route, json=payload)
        self._responded = True

    async def send_autocomplete(self, choices: list) -> None:
        """
        Respond to autocomplete interaction

        Args:
            choices: List of choice dicts (max 25)

        Raises:
            HTTPException: Autocomplete response failed
        """
        from ..core.http import Route

        if self._responded:
            raise RuntimeError("Already responded to this interaction")

        payload = {
            "type": InteractionResponseType.APPLICATION_COMMAND_AUTOCOMPLETE_RESULT,
            "data": {"choices": choices[:25]},  # Max 25 choices
        }

        route = Route(
            "POST",
            "/interactions/{interaction_id}/{token}/callback",
            interaction_id=self.id,
            token=self.token,
        )
        await self._http.request(route, json=payload)
        self._responded = True

    # Component interaction responses

    async def update_message(
        self,
        content: Optional[str] = None,
        *,
        embed: Optional[Any] = None,
        embeds: Optional[list] = None,
        allowed_mentions: Optional[Dict[str, Any]] = None,
        components: Optional[list] = None,
        attachments: Optional[list] = None,
    ) -> None:
        """
        Update the message (for component interactions)

        Args:
            content: New message content
            embed: Single embed
            embeds: List of embeds
            allowed_mentions: Allowed mentions object
            components: New message components
            attachments: Attachments

        Raises:
            HTTPException: Update failed
        """
        from ..core.http import Route

        if self._responded:
            raise RuntimeError("Already responded to this interaction")

        payload = {"type": InteractionResponseType.UPDATE_MESSAGE}

        data = {}

        if content is not None:
            data["content"] = content

        if embed:
            data["embeds"] = [embed.to_dict() if hasattr(embed, "to_dict") else embed]
        elif embeds is not None:
            data["embeds"] = [e.to_dict() if hasattr(e, "to_dict") else e for e in embeds]

        if allowed_mentions:
            data["allowed_mentions"] = allowed_mentions

        if components is not None:
            data["components"] = components

        if attachments is not None:
            data["attachments"] = attachments

        if data:
            payload["data"] = data

        route = Route(
            "POST",
            "/interactions/{interaction_id}/{token}/callback",
            interaction_id=self.id,
            token=self.token,
        )
        await self._http.request(route, json=payload)
        self._responded = True

    async def defer_update(self) -> None:
        """
        Defer message update (for component interactions, no loading state)

        Raises:
            HTTPException: Defer failed
        """
        from ..core.http import Route

        if self._responded:
            raise RuntimeError("Already responded to this interaction")

        payload = {"type": InteractionResponseType.DEFERRED_UPDATE_MESSAGE}

        route = Route(
            "POST",
            "/interactions/{interaction_id}/{token}/callback",
            interaction_id=self.id,
            token=self.token,
        )
        await self._http.request(route, json=payload)
        self._responded = True

    @property
    def is_command(self) -> bool:
        """Whether this is an application command"""
        return self.type == InteractionType.APPLICATION_COMMAND

    @property
    def is_component(self) -> bool:
        """Whether this is a message component"""
        return self.type == InteractionType.MESSAGE_COMPONENT

    @property
    def is_autocomplete(self) -> bool:
        """Whether this is autocomplete"""
        return self.type == InteractionType.APPLICATION_COMMAND_AUTOCOMPLETE

    @property
    def is_modal(self) -> bool:
        """Whether this is a modal submit"""
        return self.type == InteractionType.MODAL_SUBMIT

    async def respond(
        self,
        content: Optional[str] = None,
        *,
        embed=None,
        embeds=None,
        ephemeral: bool = False,
        tts: bool = False,
    ) -> None:
        """
        Respond to the interaction

        Args:
            content: Message content
            embed: Single embed
            embeds: List of embeds
            ephemeral: Whether response is ephemeral
            tts: Whether to use TTS
        """
        from ..core.http import Route

        if self._responded:
            raise RuntimeError("Interaction already responded to")

        payload = {"type": InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE, "data": {}}

        if content:
            payload["data"]["content"] = content

        if embed:
            payload["data"]["embeds"] = [embed.to_dict()]
        elif embeds:
            payload["data"]["embeds"] = [e.to_dict() for e in embeds]

        if ephemeral:
            payload["data"]["flags"] = 64  # EPHEMERAL flag

        if tts:
            payload["data"]["tts"] = tts

        await self._http.request(
            Route(
                "POST",
                "/interactions/{interaction_id}/{token}/callback",
                interaction_id=self.id,
                token=self.token,
            ),
            json=payload,
        )

        self._responded = True

    async def defer(self, *, ephemeral: bool = False) -> None:
        """
        Defer the interaction response

        Args:
            ephemeral: Whether the deferred response will be ephemeral
        """
        from ..core.http import Route

        if self._responded:
            raise RuntimeError("Interaction already responded to")

        payload = {
            "type": InteractionResponseType.DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE,
        }

        if ephemeral:
            payload["data"] = {"flags": 64}

        await self._http.request(
            Route(
                "POST",
                "/interactions/{interaction_id}/{token}/callback",
                interaction_id=self.id,
                token=self.token,
            ),
            json=payload,
        )

        self._responded = True

    async def edit_original(
        self,
        content: Optional[str] = None,
        *,
        embed=None,
        embeds=None,
    ):
        """
        Edit the original interaction response

        Args:
            content: New message content
            embed: New embed
            embeds: New embeds
        """
        from ..core.http import Route

        payload = {}

        if content is not None:
            payload["content"] = content

        if embed:
            payload["embeds"] = [embed.to_dict()]
        elif embeds:
            payload["embeds"] = [e.to_dict() for e in embeds]

        await self._http.request(
            Route(
                "PATCH",
                "/webhooks/{application_id}/{token}/messages/@original",
                application_id=self.application_id,
                token=self.token,
            ),
            json=payload,
        )

    async def delete_original(self) -> None:
        """Delete the original interaction response"""
        from ..core.http import Route

        await self._http.request(
            Route(
                "DELETE",
                "/webhooks/{application_id}/{token}/messages/@original",
                application_id=self.application_id,
                token=self.token,
            )
        )

    async def followup(
        self,
        content: Optional[str] = None,
        *,
        embed=None,
        embeds=None,
        ephemeral: bool = False,
    ):
        """
        Send a followup message

        Args:
            content: Message content
            embed: Single embed
            embeds: List of embeds
            ephemeral: Whether message is ephemeral
        """
        from ..core.http import Route

        payload = {}

        if content:
            payload["content"] = content

        if embed:
            payload["embeds"] = [embed.to_dict()]
        elif embeds:
            payload["embeds"] = [e.to_dict() for e in embeds]

        if ephemeral:
            payload["flags"] = 64

        await self._http.request(
            Route(
                "POST",
                "/webhooks/{application_id}/{token}",
                application_id=self.application_id,
                token=self.token,
            ),
            json=payload,
        )
