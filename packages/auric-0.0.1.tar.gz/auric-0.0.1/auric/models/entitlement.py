"""
Monetization Resources Implementation
Entitlements, SKUs, and Subscriptions for Discord monetization
"""

from dataclasses import dataclass
from datetime import datetime
from enum import IntEnum
from typing import Any, Dict, List, Optional


class EntitlementType(IntEnum):
    """Types of entitlements"""

    PURCHASE = 1
    PREMIUM_SUBSCRIPTION = 2
    DEVELOPER_GIFT = 3
    TEST_MODE_PURCHASE = 4
    FREE_PURCHASE = 5
    USER_GIFT = 6
    PREMIUM_PURCHASE = 7
    APPLICATION_SUBSCRIPTION = 8


class SKUType(IntEnum):
    """Types of SKUs"""

    DURABLE = 2
    CONSUMABLE = 3
    SUBSCRIPTION = 5
    SUBSCRIPTION_GROUP = 6


class SKUFlags(IntEnum):
    """SKU flags"""

    AVAILABLE = 1 << 2
    GUILD_SUBSCRIPTION = 1 << 7
    USER_SUBSCRIPTION = 1 << 8


class SubscriptionStatus(IntEnum):
    """Subscription statuses"""

    ACTIVE = 0
    ENDING = 1
    INACTIVE = 2


@dataclass
class Entitlement:
    """Represents an entitlement in Discord"""

    def __init__(self, data: Dict[str, Any], client=None):
        self._client = client
        self.id: str = data.get("id")
        self.sku_id: str = data.get("sku_id")
        self.application_id: str = data.get("application_id")
        self.user_id: Optional[str] = data.get("user_id")
        self.type: EntitlementType = EntitlementType(data.get("type", 1))
        self.deleted: bool = data.get("deleted", False)
        self.starts_at: Optional[datetime] = None
        if data.get("starts_at"):
            self.starts_at = datetime.fromisoformat(data["starts_at"].replace("Z", "+00:00"))
        self.ends_at: Optional[datetime] = None
        if data.get("ends_at"):
            self.ends_at = datetime.fromisoformat(data["ends_at"].replace("Z", "+00:00"))
        self.guild_id: Optional[str] = data.get("guild_id")
        self.consumed: Optional[bool] = data.get("consumed")

    async def consume(self) -> None:
        """Consume this entitlement (for consumable SKUs only)"""
        if not self._client:
            raise ValueError("Client not available")

        await self._client.http.consume_entitlement(self.application_id, self.id)
        self.consumed = True

    async def delete(self) -> None:
        """Delete this test entitlement"""
        if not self._client:
            raise ValueError("Client not available")

        if self.type != EntitlementType.TEST_MODE_PURCHASE:
            raise ValueError("Can only delete test entitlements")

        await self._client.http.delete_entitlement(self.application_id, self.id)
        self.deleted = True

    def is_active(self) -> bool:
        """Check if entitlement is currently active"""
        if self.deleted:
            return False

        now = datetime.now(datetime.timezone.utc)

        if self.starts_at and now < self.starts_at:
            return False

        if self.ends_at and now > self.ends_at:
            return False

        return True

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        result = {
            "id": self.id,
            "sku_id": self.sku_id,
            "application_id": self.application_id,
            "type": self.type.value,
            "deleted": self.deleted,
        }

        if self.user_id:
            result["user_id"] = self.user_id
        if self.guild_id:
            result["guild_id"] = self.guild_id
        if self.starts_at:
            result["starts_at"] = self.starts_at.isoformat()
        if self.ends_at:
            result["ends_at"] = self.ends_at.isoformat()
        if self.consumed is not None:
            result["consumed"] = self.consumed

        return result

    def __repr__(self) -> str:
        return f"<Entitlement id={self.id} sku_id={self.sku_id} type={self.type.name}>"


@dataclass
class SKU:
    """Represents a SKU (Stock-Keeping Unit) in Discord"""

    def __init__(self, data: Dict[str, Any], client=None):
        self._client = client
        self.id: str = data.get("id")
        self.type: SKUType = SKUType(data.get("type", 2))
        self.application_id: str = data.get("application_id")
        self.name: str = data.get("name", "")
        self.slug: str = data.get("slug", "")
        self.flags: int = data.get("flags", 0)

    def is_available(self) -> bool:
        """Check if SKU is available for purchase"""
        return bool(self.flags & SKUFlags.AVAILABLE)

    def is_guild_subscription(self) -> bool:
        """Check if SKU is a guild subscription"""
        return bool(self.flags & SKUFlags.GUILD_SUBSCRIPTION)

    def is_user_subscription(self) -> bool:
        """Check if SKU is a user subscription"""
        return bool(self.flags & SKUFlags.USER_SUBSCRIPTION)

    async def list_subscriptions(
        self,
        user_id: Optional[str] = None,
        before: Optional[str] = None,
        after: Optional[str] = None,
        limit: int = 50,
    ) -> List["Subscription"]:
        """List subscriptions for this SKU"""
        if not self._client:
            raise ValueError("Client not available")

        from .subscription import Subscription

        data = await self._client.http.list_sku_subscriptions(
            self.id, user_id=user_id, before=before, after=after, limit=limit
        )

        return [Subscription(sub, self._client) for sub in data]

    async def get_subscription(self, subscription_id: str) -> "Subscription":
        """Get a specific subscription by ID"""
        if not self._client:
            raise ValueError("Client not available")

        from .subscription import Subscription

        data = await self._client.http.get_sku_subscription(self.id, subscription_id)
        return Subscription(data, self._client)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "id": self.id,
            "type": self.type.value,
            "application_id": self.application_id,
            "name": self.name,
            "slug": self.slug,
            "flags": self.flags,
        }

    def __repr__(self) -> str:
        return f"<SKU id={self.id} name={self.name} type={self.type.name}>"


@dataclass
class Subscription:
    """Represents a subscription in Discord"""

    def __init__(self, data: Dict[str, Any], client=None):
        self._client = client
        self.id: str = data.get("id")
        self.user_id: str = data.get("user_id")
        self.sku_ids: List[str] = data.get("sku_ids", [])
        self.entitlement_ids: List[str] = data.get("entitlement_ids", [])
        self.renewal_sku_ids: Optional[List[str]] = data.get("renewal_sku_ids")
        self.current_period_start: datetime = datetime.fromisoformat(
            data.get("current_period_start", "").replace("Z", "+00:00")
        )
        self.current_period_end: datetime = datetime.fromisoformat(
            data.get("current_period_end", "").replace("Z", "+00:00")
        )
        self.status: SubscriptionStatus = SubscriptionStatus(data.get("status", 0))
        self.canceled_at: Optional[datetime] = None
        if data.get("canceled_at"):
            self.canceled_at = datetime.fromisoformat(data["canceled_at"].replace("Z", "+00:00"))
        self.country: Optional[str] = data.get("country")

    def is_active(self) -> bool:
        """Check if subscription is active"""
        return self.status == SubscriptionStatus.ACTIVE

    def is_ending(self) -> bool:
        """Check if subscription is ending (canceled but not yet expired)"""
        return self.status == SubscriptionStatus.ENDING

    def is_inactive(self) -> bool:
        """Check if subscription is inactive"""
        return self.status == SubscriptionStatus.INACTIVE

    def is_in_current_period(self) -> bool:
        """Check if currently in subscription period"""
        now = datetime.now(datetime.timezone.utc)
        return self.current_period_start <= now <= self.current_period_end

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        result = {
            "id": self.id,
            "user_id": self.user_id,
            "sku_ids": self.sku_ids,
            "entitlement_ids": self.entitlement_ids,
            "current_period_start": self.current_period_start.isoformat(),
            "current_period_end": self.current_period_end.isoformat(),
            "status": self.status.value,
        }

        if self.renewal_sku_ids:
            result["renewal_sku_ids"] = self.renewal_sku_ids
        if self.canceled_at:
            result["canceled_at"] = self.canceled_at.isoformat()
        if self.country:
            result["country"] = self.country

        return result

    def __repr__(self) -> str:
        return f"<Subscription id={self.id} user_id={self.user_id} status={self.status.name}>"
