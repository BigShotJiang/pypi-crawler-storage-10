"""
Slash command model and builders
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..types.interaction import ApplicationCommandOptionType, ApplicationCommandType


@dataclass
class CommandOption:
    """Represents a command option"""

    name: str
    description: str
    type: ApplicationCommandOptionType
    required: bool = False
    choices: Optional[List[Dict[str, Any]]] = None
    options: Optional[List["CommandOption"]] = None
    channel_types: Optional[List[int]] = None
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    min_length: Optional[int] = None
    max_length: Optional[int] = None
    autocomplete: bool = False
    name_localizations: Optional[Dict[str, str]] = None
    description_localizations: Optional[Dict[str, str]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format"""
        data = {
            "name": self.name,
            "description": self.description,
            "type": int(self.type),
            "required": self.required,
        }

        if self.choices:
            data["choices"] = self.choices
        if self.options:
            data["options"] = [opt.to_dict() for opt in self.options]
        if self.channel_types:
            data["channel_types"] = self.channel_types
        if self.min_value is not None:
            data["min_value"] = self.min_value
        if self.max_value is not None:
            data["max_value"] = self.max_value
        if self.min_length is not None:
            data["min_length"] = self.min_length
        if self.max_length is not None:
            data["max_length"] = self.max_length
        if self.autocomplete:
            data["autocomplete"] = True
        if self.name_localizations:
            data["name_localizations"] = self.name_localizations
        if self.description_localizations:
            data["description_localizations"] = self.description_localizations

        return data


@dataclass
class SlashCommand:
    """Represents a slash command"""

    name: str
    description: str
    type: ApplicationCommandType = ApplicationCommandType.CHAT_INPUT
    options: List[CommandOption] = field(default_factory=list)
    default_member_permissions: Optional[str] = None
    dm_permission: bool = True
    default_permission: bool = True
    nsfw: bool = False
    name_localizations: Optional[Dict[str, str]] = None
    description_localizations: Optional[Dict[str, str]] = None

    # Internal
    id: Optional[str] = None
    application_id: Optional[str] = None
    guild_id: Optional[str] = None
    version: Optional[str] = None
    callback: Optional[Any] = field(default=None, repr=False)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format"""
        data = {
            "name": self.name,
            "description": self.description,
            "type": int(self.type),
            "options": [opt.to_dict() for opt in self.options],
            "dm_permission": self.dm_permission,
            "default_permission": self.default_permission,
            "nsfw": self.nsfw,
        }

        if self.default_member_permissions:
            data["default_member_permissions"] = self.default_member_permissions
        if self.name_localizations:
            data["name_localizations"] = self.name_localizations
        if self.description_localizations:
            data["description_localizations"] = self.description_localizations

        return data


@dataclass
class UserCommand:
    """Represents a user context menu command"""

    name: str
    type: ApplicationCommandType = ApplicationCommandType.USER
    default_member_permissions: Optional[str] = None
    dm_permission: bool = True
    default_permission: bool = True
    nsfw: bool = False
    name_localizations: Optional[Dict[str, str]] = None

    # Internal
    id: Optional[str] = None
    application_id: Optional[str] = None
    guild_id: Optional[str] = None
    version: Optional[str] = None
    callback: Optional[Any] = field(default=None, repr=False)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format"""
        data = {
            "name": self.name,
            "type": int(self.type),
            "dm_permission": self.dm_permission,
            "default_permission": self.default_permission,
            "nsfw": self.nsfw,
        }

        if self.default_member_permissions:
            data["default_member_permissions"] = self.default_member_permissions
        if self.name_localizations:
            data["name_localizations"] = self.name_localizations

        return data


@dataclass
class MessageCommand:
    """Represents a message context menu command"""

    name: str
    type: ApplicationCommandType = ApplicationCommandType.MESSAGE
    default_member_permissions: Optional[str] = None
    dm_permission: bool = True
    default_permission: bool = True
    nsfw: bool = False
    name_localizations: Optional[Dict[str, str]] = None

    # Internal
    id: Optional[str] = None
    application_id: Optional[str] = None
    guild_id: Optional[str] = None
    version: Optional[str] = None
    callback: Optional[Any] = field(default=None, repr=False)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format"""
        data = {
            "name": self.name,
            "type": int(self.type),
            "dm_permission": self.dm_permission,
            "default_permission": self.default_permission,
            "nsfw": self.nsfw,
        }

        if self.default_member_permissions:
            data["default_member_permissions"] = self.default_member_permissions
        if self.name_localizations:
            data["name_localizations"] = self.name_localizations

        return data
