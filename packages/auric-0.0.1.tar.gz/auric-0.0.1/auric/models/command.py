"""
Application Command models - Slash commands and context menus
"""

from __future__ import annotations

from enum import IntEnum
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

from ..core.types import MISSING, Snowflake

if TYPE_CHECKING:
    from ..core.http import HTTPClient


class CommandType(IntEnum):
    """Application command types"""

    CHAT_INPUT = 1  # Slash commands
    USER = 2  # User context menu
    MESSAGE = 3  # Message context menu
    PRIMARY_ENTRY_POINT = 4  # Activity entry point


class CommandOptionType(IntEnum):
    """Application command option types"""

    SUB_COMMAND = 1
    SUB_COMMAND_GROUP = 2
    STRING = 3
    INTEGER = 4
    BOOLEAN = 5
    USER = 6
    CHANNEL = 7
    ROLE = 8
    MENTIONABLE = 9
    NUMBER = 10
    ATTACHMENT = 11


class CommandPermissionType(IntEnum):
    """Application command permission types"""

    ROLE = 1
    USER = 2
    CHANNEL = 3


class CommandHandlerType(IntEnum):
    """Entry point command handler types"""

    APP_HANDLER = 1
    DISCORD_LAUNCH_ACTIVITY = 2


class CommandOptionChoice:
    """
    Application command option choice

    Attributes:
        name: Choice name (1-100 characters)
        name_localizations: Localization dictionary for name
        value: Choice value (string, int, or float)
    """

    __slots__ = ("name", "name_localizations", "value")

    def __init__(
        self,
        name: str,
        value: Union[str, int, float],
        *,
        name_localizations: Optional[Dict[str, str]] = None,
    ):
        self.name = name
        self.value = value
        self.name_localizations = name_localizations

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API dict format"""
        data = {"name": self.name, "value": self.value}

        if self.name_localizations:
            data["name_localizations"] = self.name_localizations

        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> CommandOptionChoice:
        """Create from API dict"""
        return cls(
            name=data["name"],
            value=data["value"],
            name_localizations=data.get("name_localizations"),
        )


class CommandOption:
    """
    Application command option

    Attributes:
        type: Option type
        name: Option name (1-32 characters)
        name_localizations: Localization dictionary for name
        description: Option description (1-100 characters)
        description_localizations: Localization dictionary for description
        required: Whether option is required
        choices: Predefined choices for the option
        options: Nested options for subcommands
        channel_types: Allowed channel types
        min_value: Minimum value (INTEGER/NUMBER)
        max_value: Maximum value (INTEGER/NUMBER)
        min_length: Minimum length (STRING)
        max_length: Maximum length (STRING)
        autocomplete: Whether autocomplete is enabled
    """

    __slots__ = (
        "type",
        "name",
        "name_localizations",
        "description",
        "description_localizations",
        "required",
        "choices",
        "options",
        "channel_types",
        "min_value",
        "max_value",
        "min_length",
        "max_length",
        "autocomplete",
    )

    def __init__(
        self,
        type: CommandOptionType,
        name: str,
        description: str,
        *,
        name_localizations: Optional[Dict[str, str]] = None,
        description_localizations: Optional[Dict[str, str]] = None,
        required: bool = False,
        choices: Optional[List[CommandOptionChoice]] = None,
        options: Optional[List[CommandOption]] = None,
        channel_types: Optional[List[int]] = None,
        min_value: Optional[Union[int, float]] = None,
        max_value: Optional[Union[int, float]] = None,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
        autocomplete: bool = False,
    ):
        self.type = type
        self.name = name
        self.description = description
        self.name_localizations = name_localizations
        self.description_localizations = description_localizations
        self.required = required
        self.choices = choices or []
        self.options = options or []
        self.channel_types = channel_types
        self.min_value = min_value
        self.max_value = max_value
        self.min_length = min_length
        self.max_length = max_length
        self.autocomplete = autocomplete

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API dict format"""
        data = {"type": int(self.type), "name": self.name, "description": self.description}

        if self.name_localizations:
            data["name_localizations"] = self.name_localizations

        if self.description_localizations:
            data["description_localizations"] = self.description_localizations

        if self.required:
            data["required"] = True

        if self.choices:
            data["choices"] = [c.to_dict() for c in self.choices]

        if self.options:
            data["options"] = [o.to_dict() for o in self.options]

        if self.channel_types:
            data["channel_types"] = self.channel_types

        if self.min_value is not None:
            data["min_value"] = self.min_value

        if self.max_value is not None:
            data["max_value"] = self.max_value

        if self.min_length is not None:
            data["min_length"] = self.min_length

        if self.max_length is not None:
            data["max_length"] = self.max_length

        if self.autocomplete:
            data["autocomplete"] = True

        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> CommandOption:
        """Create from API dict"""
        choices = None
        if "choices" in data:
            choices = [CommandOptionChoice.from_dict(c) for c in data["choices"]]

        options = None
        if "options" in data:
            options = [cls.from_dict(o) for o in data["options"]]

        return cls(
            type=CommandOptionType(data["type"]),
            name=data["name"],
            description=data["description"],
            name_localizations=data.get("name_localizations"),
            description_localizations=data.get("description_localizations"),
            required=data.get("required", False),
            choices=choices,
            options=options,
            channel_types=data.get("channel_types"),
            min_value=data.get("min_value"),
            max_value=data.get("max_value"),
            min_length=data.get("min_length"),
            max_length=data.get("max_length"),
            autocomplete=data.get("autocomplete", False),
        )


class ApplicationCommand:
    """
    Application command (slash command or context menu)

    Attributes:
        id: Command ID
        type: Command type
        application_id: Parent application ID
        guild_id: Guild ID (None if global)
        name: Command name (1-32 characters)
        name_localizations: Localization dictionary for name
        description: Command description (1-100 characters for CHAT_INPUT)
        description_localizations: Localization dictionary for description
        options: Command options (CHAT_INPUT only)
        default_member_permissions: Required permissions as bit set
        dm_permission: Whether available in DMs (deprecated)
        default_permission: Whether enabled by default (deprecated)
        nsfw: Whether age-restricted
        integration_types: Installation contexts
        contexts: Interaction contexts
        version: Auto-incrementing version
        handler: Entry point handler type
    """

    __slots__ = (
        "id",
        "type",
        "application_id",
        "guild_id",
        "name",
        "name_localizations",
        "description",
        "description_localizations",
        "options",
        "default_member_permissions",
        "dm_permission",
        "default_permission",
        "nsfw",
        "integration_types",
        "contexts",
        "version",
        "handler",
        "_http",
    )

    def __init__(self, *, data: Dict[str, Any], http: Optional[HTTPClient] = None):
        self._http = http
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        """Update command from API data"""
        self.id: Snowflake = int(data["id"])
        self.type: CommandType = CommandType(data.get("type", 1))
        self.application_id: Snowflake = int(data["application_id"])
        self.guild_id: Optional[Snowflake] = int(data["guild_id"]) if "guild_id" in data else None
        self.name: str = data["name"]
        self.name_localizations: Optional[Dict[str, str]] = data.get("name_localizations")
        self.description: str = data["description"]
        self.description_localizations: Optional[Dict[str, str]] = data.get(
            "description_localizations"
        )

        # Parse options
        self.options: List[CommandOption] = []
        if "options" in data:
            self.options = [CommandOption.from_dict(o) for o in data["options"]]

        self.default_member_permissions: Optional[str] = data.get("default_member_permissions")
        self.dm_permission: Optional[bool] = data.get("dm_permission")
        self.default_permission: Optional[bool] = data.get("default_permission")
        self.nsfw: bool = data.get("nsfw", False)
        self.integration_types: Optional[List[int]] = data.get("integration_types")
        self.contexts: Optional[List[int]] = data.get("contexts")
        self.version: Snowflake = int(data["version"])
        self.handler: Optional[CommandHandlerType] = None
        if "handler" in data:
            self.handler = CommandHandlerType(data["handler"])

    def __repr__(self) -> str:
        return f"<ApplicationCommand id={self.id} name={self.name!r} type={self.type.name}>"

    def __str__(self) -> str:
        return self.name

    @property
    def is_global(self) -> bool:
        """Whether this is a global command"""
        return self.guild_id is None

    @property
    def is_guild(self) -> bool:
        """Whether this is a guild command"""
        return self.guild_id is not None

    @property
    def is_chat_input(self) -> bool:
        """Whether this is a slash command"""
        return self.type == CommandType.CHAT_INPUT

    @property
    def is_user_command(self) -> bool:
        """Whether this is a user context menu"""
        return self.type == CommandType.USER

    @property
    def is_message_command(self) -> bool:
        """Whether this is a message context menu"""
        return self.type == CommandType.MESSAGE

    async def edit(
        self,
        *,
        name: Optional[str] = MISSING,
        name_localizations: Optional[Dict[str, str]] = MISSING,
        description: Optional[str] = MISSING,
        description_localizations: Optional[Dict[str, str]] = MISSING,
        options: Optional[List[CommandOption]] = MISSING,
        default_member_permissions: Optional[str] = MISSING,
        dm_permission: Optional[bool] = MISSING,
        nsfw: Optional[bool] = MISSING,
        integration_types: Optional[List[int]] = MISSING,
        contexts: Optional[List[int]] = MISSING,
    ) -> ApplicationCommand:
        """
        Edit this command

        Args:
            name: New command name
            name_localizations: New name localizations
            description: New description
            description_localizations: New description localizations
            options: New options
            default_member_permissions: New default permissions
            dm_permission: New DM permission
            nsfw: New NSFW flag
            integration_types: New integration types
            contexts: New contexts

        Returns:
            Updated ApplicationCommand

        Raises:
            HTTPException: Edit failed
        """
        from ..core.http import Route

        payload = {}

        if name is not MISSING:
            payload["name"] = name

        if name_localizations is not MISSING:
            payload["name_localizations"] = name_localizations

        if description is not MISSING:
            payload["description"] = description

        if description_localizations is not MISSING:
            payload["description_localizations"] = description_localizations

        if options is not MISSING:
            payload["options"] = [o.to_dict() for o in options] if options else []

        if default_member_permissions is not MISSING:
            payload["default_member_permissions"] = default_member_permissions

        if dm_permission is not MISSING:
            payload["dm_permission"] = dm_permission

        if nsfw is not MISSING:
            payload["nsfw"] = nsfw

        if integration_types is not MISSING:
            payload["integration_types"] = integration_types

        if contexts is not MISSING:
            payload["contexts"] = contexts

        # Choose endpoint based on scope
        if self.guild_id:
            route = Route(
                "PATCH",
                "/applications/{app_id}/guilds/{guild_id}/commands/{cmd_id}",
                app_id=self.application_id,
                guild_id=self.guild_id,
                cmd_id=self.id,
            )
        else:
            route = Route(
                "PATCH",
                "/applications/{app_id}/commands/{cmd_id}",
                app_id=self.application_id,
                cmd_id=self.id,
            )

        data = await self._http.request(route, json=payload)
        self._update(data)
        return self

    async def delete(self) -> None:
        """
        Delete this command

        Raises:
            HTTPException: Delete failed
        """
        from ..core.http import Route

        # Choose endpoint based on scope
        if self.guild_id:
            route = Route(
                "DELETE",
                "/applications/{app_id}/guilds/{guild_id}/commands/{cmd_id}",
                app_id=self.application_id,
                guild_id=self.guild_id,
                cmd_id=self.id,
            )
        else:
            route = Route(
                "DELETE",
                "/applications/{app_id}/commands/{cmd_id}",
                app_id=self.application_id,
                cmd_id=self.id,
            )

        await self._http.request(route)
