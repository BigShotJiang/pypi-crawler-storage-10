"""
Application Role Connection Metadata
For Discord's Linked Roles feature
"""

from dataclasses import dataclass
from enum import IntEnum
from typing import Any, Dict, List, Optional


class ApplicationRoleConnectionMetadataType(IntEnum):
    """Types of role connection metadata"""

    INTEGER_LESS_THAN_OR_EQUAL = 1
    INTEGER_GREATER_THAN_OR_EQUAL = 2
    INTEGER_EQUAL = 3
    INTEGER_NOT_EQUAL = 4
    DATETIME_LESS_THAN_OR_EQUAL = 5
    DATETIME_GREATER_THAN_OR_EQUAL = 6
    BOOLEAN_EQUAL = 7
    BOOLEAN_NOT_EQUAL = 8


@dataclass
class ApplicationRoleConnectionMetadata:
    """Represents role connection metadata for an application"""

    def __init__(self, data: Dict[str, Any]):
        self.type: ApplicationRoleConnectionMetadataType = ApplicationRoleConnectionMetadataType(
            data.get("type", 1)
        )
        self.key: str = data.get("key", "")
        self.name: str = data.get("name", "")
        self.name_localizations: Optional[Dict[str, str]] = data.get("name_localizations")
        self.description: str = data.get("description", "")
        self.description_localizations: Optional[Dict[str, str]] = data.get(
            "description_localizations"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for API requests"""
        result = {
            "type": self.type.value,
            "key": self.key,
            "name": self.name,
            "description": self.description,
        }

        if self.name_localizations:
            result["name_localizations"] = self.name_localizations
        if self.description_localizations:
            result["description_localizations"] = self.description_localizations

        return result

    def __repr__(self) -> str:
        return f"<ApplicationRoleConnectionMetadata key={self.key} type={self.type.name}>"


@dataclass
class UserApplicationRoleConnection:
    """Represents a user's role connection for an application"""

    def __init__(self, data: Dict[str, Any]):
        self.platform_name: Optional[str] = data.get("platform_name")
        self.platform_username: Optional[str] = data.get("platform_username")
        self.metadata: Dict[str, Any] = data.get("metadata", {})

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        result = {"metadata": self.metadata}

        if self.platform_name:
            result["platform_name"] = self.platform_name
        if self.platform_username:
            result["platform_username"] = self.platform_username

        return result

    def __repr__(self) -> str:
        return f"<UserApplicationRoleConnection platform={self.platform_name}>"
