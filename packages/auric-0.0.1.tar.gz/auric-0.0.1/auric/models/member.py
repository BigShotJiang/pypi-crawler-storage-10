"""
Member model - represents guild members
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..core.types import Snowflake

if TYPE_CHECKING:
    from .guild import Guild
    from .role import Role
    from .user import User


class Member:
    """
    Represents a guild member (user in a guild context)

    Attributes:
        user: The user this member represents
        nick: Member's nickname
        avatar: Guild-specific avatar
        roles: List of role IDs
        joined_at: When member joined
        premium_since: When member started boosting
        deaf: Whether member is deafened
        mute: Whether member is muted
        pending: Whether member hasn't passed screening
        communication_disabled_until: When timeout expires
    """

    __slots__ = (
        "user",
        "guild_id",
        "nick",
        "avatar",
        "roles",
        "joined_at",
        "premium_since",
        "deaf",
        "mute",
        "pending",
        "permissions",
        "communication_disabled_until",
        "_http",
    )

    def __init__(self, *, data: Dict[str, Any], guild_id: Snowflake, http=None):
        self.guild_id = guild_id
        self._http = http
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        """Update member from API data"""
        from .user import User

        # User object
        if "user" in data:
            self.user = User(data=data["user"], http=self._http)

        self.nick: Optional[str] = data.get("nick")
        self.avatar: Optional[str] = data.get("avatar")
        self.roles: List[Snowflake] = [int(r) for r in data.get("roles", [])]
        self.joined_at: str = data.get("joined_at")
        self.premium_since: Optional[str] = data.get("premium_since")
        self.deaf: bool = data.get("deaf", False)
        self.mute: bool = data.get("mute", False)
        self.pending: bool = data.get("pending", False)
        self.permissions: Optional[str] = data.get("permissions")
        self.communication_disabled_until: Optional[str] = data.get("communication_disabled_until")

    def __repr__(self) -> str:
        return f"<Member user={self.user!r} guild_id={self.guild_id}>"

    def __str__(self) -> str:
        return str(self.user)

    @property
    def id(self) -> Snowflake:
        """Member's user ID"""
        return self.user.id

    @property
    def mention(self) -> str:
        """Returns a string that mentions the member"""
        return self.user.mention

    @property
    def display_name(self) -> str:
        """Returns the member's display name"""
        return self.nick or self.user.display_name

    @property
    def is_timed_out(self) -> bool:
        """Whether the member is currently timed out"""
        if not self.communication_disabled_until:
            return False

        from datetime import datetime

        timeout = datetime.fromisoformat(self.communication_disabled_until.rstrip("Z"))
        return datetime.utcnow() < timeout

    @property
    def is_pending(self) -> bool:
        """Whether member hasn't passed membership screening"""
        return self.pending

    async def kick(self, *, reason: Optional[str] = None) -> None:
        """
        Kick this member from the guild

        Args:
            reason: Reason for audit log

        Requires:
            KICK_MEMBERS permission
        """
        from ..core.http import Route

        await self._http.request(
            Route(
                "DELETE",
                "/guilds/{guild_id}/members/{user_id}",
                guild_id=self.guild_id,
                user_id=self.id,
            ),
            reason=reason,
        )

    async def ban(self, *, delete_message_seconds: int = 0, reason: Optional[str] = None) -> None:
        """
        Ban this member from the guild

        Args:
            delete_message_seconds: Delete messages from last X seconds (0-604800)
            reason: Reason for audit log

        Requires:
            BAN_MEMBERS permission
        """
        from ..core.http import Route

        payload = {}
        if delete_message_seconds:
            payload["delete_message_seconds"] = delete_message_seconds

        await self._http.request(
            Route(
                "PUT", "/guilds/{guild_id}/bans/{user_id}", guild_id=self.guild_id, user_id=self.id
            ),
            json=payload if payload else None,
            reason=reason,
        )

    async def unban(self, *, reason: Optional[str] = None) -> None:
        """
        Unban this member

        Args:
            reason: Reason for audit log

        Requires:
            BAN_MEMBERS permission
        """
        from ..core.http import Route

        await self._http.request(
            Route(
                "DELETE",
                "/guilds/{guild_id}/bans/{user_id}",
                guild_id=self.guild_id,
                user_id=self.id,
            ),
            reason=reason,
        )

    async def add_role(self, role_id: Snowflake, *, reason: Optional[str] = None) -> None:
        """
        Add a role to this member

        Args:
            role_id: ID of role to add
            reason: Reason for audit log

        Requires:
            MANAGE_ROLES permission
        """
        from ..core.http import Route

        await self._http.request(
            Route(
                "PUT",
                "/guilds/{guild_id}/members/{user_id}/roles/{role_id}",
                guild_id=self.guild_id,
                user_id=self.id,
                role_id=role_id,
            ),
            reason=reason,
        )

    async def remove_role(self, role_id: Snowflake, *, reason: Optional[str] = None) -> None:
        """
        Remove a role from this member

        Args:
            role_id: ID of role to remove
            reason: Reason for audit log

        Requires:
            MANAGE_ROLES permission
        """
        from ..core.http import Route

        await self._http.request(
            Route(
                "DELETE",
                "/guilds/{guild_id}/members/{user_id}/roles/{role_id}",
                guild_id=self.guild_id,
                user_id=self.id,
                role_id=role_id,
            ),
            reason=reason,
        )

    async def edit(
        self,
        *,
        nick: Optional[str] = None,
        roles: Optional[List[Snowflake]] = None,
        mute: Optional[bool] = None,
        deaf: Optional[bool] = None,
        channel_id: Optional[Snowflake] = None,
        communication_disabled_until: Optional[str] = None,
        reason: Optional[str] = None,
    ):
        """
        Edit guild member

        Args:
            nick: New nickname (None to remove)
            roles: List of role IDs
            mute: Whether to mute
            deaf: Whether to deafen
            channel_id: Voice channel to move to
            communication_disabled_until: Timeout until (ISO8601 or None)
            reason: Reason for audit log

        Returns:
            Member: Updated member object

        Requires:
            Various permissions based on what's being modified
        """
        from ..core.http import Route

        payload = {}

        if nick is not None:
            payload["nick"] = nick

        if roles is not None:
            payload["roles"] = [str(r) for r in roles]

        if mute is not None:
            payload["mute"] = mute

        if deaf is not None:
            payload["deaf"] = deaf

        if channel_id is not None:
            payload["channel_id"] = str(channel_id)

        if communication_disabled_until is not None:
            payload["communication_disabled_until"] = communication_disabled_until

        data = await self._http.request(
            Route(
                "PATCH",
                "/guilds/{guild_id}/members/{user_id}",
                guild_id=self.guild_id,
                user_id=self.id,
            ),
            json=payload,
            reason=reason,
        )

        self._update(data)
        return self
