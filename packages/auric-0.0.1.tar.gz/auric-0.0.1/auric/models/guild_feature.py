"""
Guild Widget, Welcome Screen, and Onboarding models
"""

from __future__ import annotations

from enum import IntEnum
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..core.types import Snowflake

if TYPE_CHECKING:
    from ..core.http import HTTPClient


class WidgetStyle(IntEnum):
    """Widget style"""

    SHIELD = 0
    BANNER1 = 1
    BANNER2 = 2
    BANNER3 = 3
    BANNER4 = 4


class GuildWidget:
    """
    Represents a guild widget

    Attributes:
        enabled: Whether widget is enabled
        channel_id: Widget channel ID
    """

    __slots__ = ("enabled", "channel_id", "guild_id", "_http")

    def __init__(
        self, *, data: Dict[str, Any], guild_id: Snowflake, http: Optional[HTTPClient] = None
    ):
        self._http = http
        self.guild_id = guild_id
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        """Update widget from API data"""
        self.enabled: bool = data.get("enabled", False)
        self.channel_id: Optional[Snowflake] = data.get("channel_id")

    def __repr__(self) -> str:
        return f"<GuildWidget enabled={self.enabled} channel_id={self.channel_id}>"

    def get_url(self, style: WidgetStyle = WidgetStyle.SHIELD) -> str:
        """Get widget image URL"""
        return f"https://discord.com/api/guilds/{self.guild_id}/widget.png?style={style}"

    def get_json_url(self) -> str:
        """Get widget JSON URL"""
        return f"https://discord.com/api/guilds/{self.guild_id}/widget.json"


class WelcomeScreenChannel:
    """Welcome screen channel"""

    __slots__ = ("channel_id", "description", "emoji_id", "emoji_name")

    def __init__(self, *, data: Dict[str, Any]):
        self.channel_id: Snowflake = int(data["channel_id"])
        self.description: str = data["description"]
        self.emoji_id: Optional[Snowflake] = data.get("emoji_id")
        self.emoji_name: Optional[str] = data.get("emoji_name")

    def __repr__(self) -> str:
        return f"<WelcomeScreenChannel channel_id={self.channel_id}>"


class WelcomeScreen:
    """
    Represents a guild welcome screen

    Attributes:
        description: Server description
        welcome_channels: Featured channels
    """

    __slots__ = ("description", "welcome_channels", "guild_id", "_http")

    def __init__(
        self, *, data: Dict[str, Any], guild_id: Snowflake, http: Optional[HTTPClient] = None
    ):
        self._http = http
        self.guild_id = guild_id
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        """Update welcome screen from API data"""
        self.description: Optional[str] = data.get("description")
        self.welcome_channels: List[WelcomeScreenChannel] = [
            WelcomeScreenChannel(data=channel) for channel in data.get("welcome_channels", [])
        ]

    def __repr__(self) -> str:
        return f"<WelcomeScreen channels={len(self.welcome_channels)}>"


class OnboardingPromptType(IntEnum):
    """Onboarding prompt type"""

    MULTIPLE_CHOICE = 0
    DROPDOWN = 1


class OnboardingPromptOption:
    """Onboarding prompt option"""

    __slots__ = (
        "id",
        "channel_ids",
        "role_ids",
        "emoji",
        "emoji_id",
        "emoji_name",
        "emoji_animated",
        "title",
        "description",
    )

    def __init__(self, *, data: Dict[str, Any]):
        self.id: Snowflake = int(data["id"])
        self.channel_ids: List[Snowflake] = [int(cid) for cid in data.get("channel_ids", [])]
        self.role_ids: List[Snowflake] = [int(rid) for rid in data.get("role_ids", [])]
        self.emoji: Optional[Dict[str, Any]] = data.get("emoji")
        self.emoji_id: Optional[Snowflake] = data.get("emoji_id")
        self.emoji_name: Optional[str] = data.get("emoji_name")
        self.emoji_animated: Optional[bool] = data.get("emoji_animated")
        self.title: str = data["title"]
        self.description: Optional[str] = data.get("description")

    def __repr__(self) -> str:
        return f"<OnboardingPromptOption id={self.id} title={self.title!r}>"


class OnboardingPrompt:
    """Onboarding prompt"""

    __slots__ = ("id", "type", "options", "title", "single_select", "required", "in_onboarding")

    def __init__(self, *, data: Dict[str, Any]):
        self.id: Snowflake = int(data["id"])
        self.type: OnboardingPromptType = OnboardingPromptType(data["type"])
        self.options: List[OnboardingPromptOption] = [
            OnboardingPromptOption(data=opt) for opt in data.get("options", [])
        ]
        self.title: str = data["title"]
        self.single_select: bool = data.get("single_select", False)
        self.required: bool = data.get("required", False)
        self.in_onboarding: bool = data.get("in_onboarding", False)

    def __repr__(self) -> str:
        return f"<OnboardingPrompt id={self.id} title={self.title!r}>"


class OnboardingMode(IntEnum):
    """Onboarding mode"""

    DEFAULT = 0
    ADVANCED = 1


class Onboarding:
    """
    Represents guild onboarding

    Attributes:
        guild_id: Guild ID
        prompts: Onboarding prompts
        default_channel_ids: Default channel IDs
        enabled: Whether onboarding is enabled
        mode: Onboarding mode
    """

    __slots__ = ("guild_id", "prompts", "default_channel_ids", "enabled", "mode", "_http")

    def __init__(self, *, data: Dict[str, Any], http: Optional[HTTPClient] = None):
        self._http = http
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        """Update onboarding from API data"""
        self.guild_id: Snowflake = int(data["guild_id"])
        self.prompts: List[OnboardingPrompt] = [
            OnboardingPrompt(data=prompt) for prompt in data.get("prompts", [])
        ]
        self.default_channel_ids: List[Snowflake] = [
            int(cid) for cid in data.get("default_channel_ids", [])
        ]
        self.enabled: bool = data.get("enabled", False)
        self.mode: OnboardingMode = OnboardingMode(data.get("mode", 0))

    def __repr__(self) -> str:
        return f"<Onboarding guild_id={self.guild_id} enabled={self.enabled}>"


class VanityURL:
    """Guild vanity URL"""

    __slots__ = ("code", "uses")

    def __init__(self, *, data: Dict[str, Any]):
        self.code: Optional[str] = data.get("code")
        self.uses: int = data.get("uses", 0)

    def __repr__(self) -> str:
        return f"<VanityURL code={self.code!r} uses={self.uses}>"

    @property
    def url(self) -> Optional[str]:
        """Full vanity URL"""
        if self.code:
            return f"https://discord.gg/{self.code}"
        return None
