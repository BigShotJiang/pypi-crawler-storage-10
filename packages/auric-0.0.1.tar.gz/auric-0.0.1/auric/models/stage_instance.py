"""
Stage Instance - Discord stage channel instances

Stage instances represent active stages in stage channels.
"""

from __future__ import annotations

from enum import IntEnum
from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from ..core.http import HTTPClient


class StagePrivacyLevel(IntEnum):
    """Privacy level for stage instances"""

    PUBLIC = 1  # Deprecated, use GUILD_ONLY
    GUILD_ONLY = 2  # Only guild members can see/join


class StageInstance:
    """
    Represents an active stage in a stage channel.

    Attributes:
        id: Stage instance ID
        guild_id: Guild ID
        channel_id: Stage channel ID
        topic: Stage topic (1-120 chars)
        privacy_level: Privacy level
        discoverable_disabled: Whether stage is discoverable
        guild_scheduled_event_id: Associated scheduled event ID

    Example:
        ```python
        # Create a stage
        stage = await stage_channel.create_instance(
            topic="Community Q&A Session",
            privacy_level=StagePrivacyLevel.GUILD_ONLY
        )

        # Modify stage
        await stage.edit(topic="Updated Topic")

        # End stage
        await stage.delete()
        ```
    """

    __slots__ = (
        "id",
        "guild_id",
        "channel_id",
        "topic",
        "privacy_level",
        "discoverable_disabled",
        "guild_scheduled_event_id",
        "_http",
    )

    def __init__(self, data: Dict[str, Any], http: Optional[HTTPClient] = None):
        self.id: int = int(data.get("id", 0))
        self.guild_id: int = int(data.get("guild_id", 0))
        self.channel_id: int = int(data.get("channel_id", 0))
        self.topic: str = data.get("topic", "")

        self.privacy_level: StagePrivacyLevel = StagePrivacyLevel(data.get("privacy_level", 2))

        self.discoverable_disabled: bool = data.get("discoverable_disabled", False)

        event_id = data.get("guild_scheduled_event_id")
        self.guild_scheduled_event_id: Optional[int] = int(event_id) if event_id else None

        self._http = http

    @property
    def is_public(self) -> bool:
        """Whether stage is public (deprecated, always False)"""
        return self.privacy_level == StagePrivacyLevel.PUBLIC

    @property
    def is_guild_only(self) -> bool:
        """Whether stage is guild-only"""
        return self.privacy_level == StagePrivacyLevel.GUILD_ONLY

    @property
    def is_discoverable(self) -> bool:
        """Whether stage is discoverable"""
        return not self.discoverable_disabled

    async def edit(
        self,
        *,
        topic: Optional[str] = None,
        privacy_level: Optional[StagePrivacyLevel] = None,
        reason: Optional[str] = None,
    ) -> StageInstance:
        """
        Edit the stage instance.

        Args:
            topic: New topic (1-120 chars)
            privacy_level: New privacy level
            reason: Audit log reason

        Returns:
            Updated stage instance
        """
        if not self._http:
            raise ValueError("Cannot edit stage without HTTP client")

        payload = {}

        if topic is not None:
            if not 1 <= len(topic) <= 120:
                raise ValueError("Topic must be 1-120 characters")
            payload["topic"] = topic

        if privacy_level is not None:
            payload["privacy_level"] = int(privacy_level)

        data = await self._http.request(
            "PATCH", f"/stage-instances/{self.channel_id}", json=payload, reason=reason
        )

        return StageInstance(data, self._http)

    async def delete(self, *, reason: Optional[str] = None) -> None:
        """
        Delete/end the stage instance.

        Args:
            reason: Audit log reason
        """
        if not self._http:
            raise ValueError("Cannot delete stage without HTTP client")

        await self._http.request("DELETE", f"/stage-instances/{self.channel_id}", reason=reason)

    def __repr__(self) -> str:
        return f"<StageInstance id={self.id} channel_id={self.channel_id} topic={self.topic!r}>"
