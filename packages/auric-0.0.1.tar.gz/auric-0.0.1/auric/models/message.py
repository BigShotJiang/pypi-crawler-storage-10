"""
Message model - represents Discord messages
"""

from __future__ import annotations

from enum import IntEnum, IntFlag
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..core.types import Snowflake

if TYPE_CHECKING:
    from ..core.http import HTTPClient
    from .embed import Embed
    from .user import User


class MessageType(IntEnum):
    """Message types"""

    DEFAULT = 0
    RECIPIENT_ADD = 1
    RECIPIENT_REMOVE = 2
    CALL = 3
    CHANNEL_NAME_CHANGE = 4
    CHANNEL_ICON_CHANGE = 5
    CHANNEL_PINNED_MESSAGE = 6
    USER_JOIN = 7
    GUILD_BOOST = 8
    GUILD_BOOST_TIER_1 = 9
    GUILD_BOOST_TIER_2 = 10
    GUILD_BOOST_TIER_3 = 11
    CHANNEL_FOLLOW_ADD = 12
    GUILD_DISCOVERY_DISQUALIFIED = 14
    GUILD_DISCOVERY_REQUALIFIED = 15
    GUILD_DISCOVERY_GRACE_PERIOD_INITIAL_WARNING = 16
    GUILD_DISCOVERY_GRACE_PERIOD_FINAL_WARNING = 17
    THREAD_CREATED = 18
    REPLY = 19
    CHAT_INPUT_COMMAND = 20
    THREAD_STARTER_MESSAGE = 21
    GUILD_INVITE_REMINDER = 22
    CONTEXT_MENU_COMMAND = 23
    AUTO_MODERATION_ACTION = 24
    ROLE_SUBSCRIPTION_PURCHASE = 25
    INTERACTION_PREMIUM_UPSELL = 26
    STAGE_START = 27
    STAGE_END = 28
    STAGE_SPEAKER = 29
    STAGE_TOPIC = 31
    GUILD_APPLICATION_PREMIUM_SUBSCRIPTION = 32
    POLL_RESULT = 46


class MessageFlags(IntFlag):
    """Message flags"""

    NONE = 0
    CROSSPOSTED = 1 << 0
    IS_CROSSPOST = 1 << 1
    SUPPRESS_EMBEDS = 1 << 2
    SOURCE_MESSAGE_DELETED = 1 << 3
    URGENT = 1 << 4
    HAS_THREAD = 1 << 5
    EPHEMERAL = 1 << 6
    LOADING = 1 << 7
    FAILED_TO_MENTION_SOME_ROLES_IN_THREAD = 1 << 8
    SUPPRESS_NOTIFICATIONS = 1 << 12
    IS_VOICE_MESSAGE = 1 << 13


class Message:
    """
    Represents a Discord message

    Attributes:
        id: Message ID
        channel_id: Channel ID
        author: Message author
        content: Message content
        timestamp: When message was sent
        edited_timestamp: When message was edited
        tts: Whether TTS
        mention_everyone: Whether @everyone
        mentions: Mentioned users
        embeds: Message embeds
        attachments: File attachments
        reactions: Message reactions
    """

    __slots__ = (
        "id",
        "channel_id",
        "guild_id",
        "author",
        "content",
        "timestamp",
        "edited_timestamp",
        "tts",
        "mention_everyone",
        "mentions",
        "mention_roles",
        "embeds",
        "attachments",
        "reactions",
        "nonce",
        "pinned",
        "webhook_id",
        "type",
        "flags",
        "referenced_message",
        "sticker_items",
        "_http",
    )

    def __init__(self, *, data: Dict[str, Any], http: Optional[HTTPClient] = None):
        self._http = http
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        """Update message from API data"""
        from .attachment import Attachment
        from .embed import Embed
        from .sticker import StickerItem
        from .user import User

        self.id: Snowflake = int(data["id"])
        self.channel_id: Snowflake = int(data["channel_id"])
        self.guild_id: Optional[Snowflake] = data.get("guild_id")

        # Author
        author_data = data.get("author")
        self.author: Optional[User] = (
            User(data=author_data, http=self._http) if author_data else None
        )

        self.content: str = data.get("content", "")
        self.timestamp: str = data.get("timestamp")
        self.edited_timestamp: Optional[str] = data.get("edited_timestamp")
        self.tts: bool = data.get("tts", False)
        self.mention_everyone: bool = data.get("mention_everyone", False)

        # Mentions
        self.mentions: List[User] = [
            User(data=u, http=self._http) for u in data.get("mentions", [])
        ]
        self.mention_roles: List[Snowflake] = [int(r) for r in data.get("mention_roles", [])]

        # Embeds
        self.embeds: List[Embed] = [Embed.from_dict(e) for e in data.get("embeds", [])]

        # Stickers
        self.sticker_items: List[StickerItem] = [
            StickerItem(data=s) for s in data.get("sticker_items", [])
        ]

        # Attachments
        self.attachments: List[Attachment] = [
            Attachment(data=a, client=None) for a in data.get("attachments", [])
        ]

        # Reactions (raw for now)
        self.reactions = data.get("reactions", [])

        self.nonce: Optional[str] = data.get("nonce")
        self.pinned: bool = data.get("pinned", False)
        self.webhook_id: Optional[Snowflake] = data.get("webhook_id")
        self.type: MessageType = MessageType(data.get("type", 0))
        self.flags: MessageFlags = MessageFlags(data.get("flags", 0))
        self.referenced_message = data.get("referenced_message")

    def __repr__(self) -> str:
        return f"<Message id={self.id} author={self.author}>"

    @property
    def jump_url(self) -> str:
        """Returns a URL to jump to this message"""
        guild_id = self.guild_id or "@me"
        return f"https://discord.com/channels/{guild_id}/{self.channel_id}/{self.id}"

    @property
    def created_at(self):
        """Get the message creation timestamp from the snowflake ID"""
        from datetime import datetime, timezone

        # Discord epoch: 2015-01-01T00:00:00.000Z
        DISCORD_EPOCH = 1420070400000
        timestamp_ms = (self.id >> 22) + DISCORD_EPOCH
        return datetime.fromtimestamp(timestamp_ms / 1000, tz=timezone.utc)

    async def reply(self, content: Optional[str] = None, **kwargs):
        """
        Reply to this message

        Args:
            content: Message content
            **kwargs: Additional arguments passed to Channel.send()

        Returns:
            Message: The sent message
        """
        # Build message reference
        message_reference = {
            "message_id": str(self.id),
            "channel_id": str(self.channel_id),
        }

        if self.guild_id:
            message_reference["guild_id"] = str(self.guild_id)

        # Get channel and send
        from ..core.http import Route

        # Build payload
        payload = {}

        if content is not None:
            payload["content"] = str(content)

        # Add embeds
        if "embed" in kwargs:
            payload["embeds"] = [kwargs.pop("embed").to_dict()]
        elif "embeds" in kwargs:
            payload["embeds"] = [e.to_dict() for e in kwargs.pop("embeds")]

        # Add message reference
        payload["message_reference"] = message_reference

        # Add other kwargs
        for key in ["tts", "allowed_mentions", "components", "sticker_ids"]:
            if key in kwargs:
                payload[key] = kwargs.pop(key)

        # Message flags
        flags = 0
        if kwargs.get("suppress_embeds"):
            flags |= 1 << 2
        if kwargs.get("silent"):
            flags |= 1 << 12

        if flags:
            payload["flags"] = flags

        # Send request
        data = await self._http.request(
            Route("POST", "/channels/{channel_id}/messages", channel_id=self.channel_id),
            json=payload,
        )

        self._update(data)
        return Message(data=data, http=self._http)

    async def edit(self, content: Optional[str] = None, **kwargs) -> Message:
        """
        Edit this message

        Args:
            content: New message content
            embed: Single embed to replace existing embeds
            embeds: List of embeds to replace existing embeds
            components: Message components
            attachments: List of existing attachments to keep (by ID) or new File objects
            files: New files to attach
            allowed_mentions: Allowed mentions object
            suppress_embeds: Whether to suppress embeds

        Note:
            When editing attachments, only attachments listed in `attachments` parameter
            will be kept. Any existing attachments not listed will be removed.
            Use `files` parameter to add new attachments.
        """
        from ..core.http import Route

        payload = {}

        if content is not None:
            payload["content"] = str(content)

        # Embeds
        if "embed" in kwargs:
            payload["embeds"] = [kwargs["embed"].to_dict()]
        elif "embeds" in kwargs:
            payload["embeds"] = [e.to_dict() for e in kwargs["embeds"]]

        # Components
        if "components" in kwargs:
            comps = kwargs["components"]
            if hasattr(comps, "to_dict"):
                payload["components"] = comps.to_dict()
            else:
                payload["components"] = comps

        # Attachments editing
        if "attachments" in kwargs:
            # List of attachment IDs to keep, or Attachment objects
            attachments = kwargs["attachments"]
            payload["attachments"] = []

            for att in attachments:
                if isinstance(att, dict):
                    payload["attachments"].append(att)
                elif hasattr(att, "id"):
                    # Attachment object - keep it
                    payload["attachments"].append({"id": str(att.id)})
                else:
                    # Assume it's an ID
                    payload["attachments"].append({"id": str(att)})

        # Allowed mentions
        if "allowed_mentions" in kwargs:
            payload["allowed_mentions"] = kwargs["allowed_mentions"]

        # Flags
        flags = 0
        if kwargs.get("suppress_embeds"):
            flags |= 1 << 2  # SUPPRESS_EMBEDS
        if flags:
            payload["flags"] = flags

        # Handle new file uploads
        file_objects = None
        if "files" in kwargs and kwargs["files"] is not None:
            from ..utils.file import File

            files = kwargs["files"]
            # Convert to list if single file
            if not isinstance(files, list):
                files = [files]

            # Convert to File objects if needed
            file_objects = []
            for f in files:
                if isinstance(f, File):
                    file_objects.append(f)
                else:
                    file_objects.append(File(f))

        data = await self._http.request(
            Route(
                "PATCH",
                "/channels/{channel_id}/messages/{message_id}",
                channel_id=self.channel_id,
                message_id=self.id,
            ),
            json=payload,
            files=file_objects,
        )

        self._update(data)
        return self

    async def delete(self, *, reason: Optional[str] = None) -> None:
        """
        Delete this message

        Args:
            reason: Reason for audit log
        """
        from ..core.http import Route

        await self._http.request(
            Route(
                "DELETE",
                "/channels/{channel_id}/messages/{message_id}",
                channel_id=self.channel_id,
                message_id=self.id,
            ),
            reason=reason,
        )

    async def add_reaction(self, emoji) -> None:
        """
        Add a reaction to this message

        Args:
            emoji: Unicode emoji, custom emoji string ('name:id'), or Emoji object

        Example:
            ```python
            # Unicode emoji
            await message.add_reaction("🔥")

            # Custom emoji
            await message.add_reaction("<:python:123456789>")

            # Emoji object
            emoji = guild.get_emoji(123456789)
            await message.add_reaction(emoji)
            ```
        """
        import urllib.parse

        from ..core.http import Route
        from .emoji import Emoji, PartialEmoji, parse_emoji

        # Convert to emoji string
        if isinstance(emoji, (Emoji, PartialEmoji)):
            if emoji.id:
                emoji_str = f"{emoji.name}:{emoji.id}"
            else:
                emoji_str = emoji.name
        elif isinstance(emoji, str):
            # Parse if it's in <:name:id> format
            if emoji.startswith("<") and emoji.endswith(">"):
                # Extract name:id from <:name:id> or <a:name:id>
                emoji = emoji[1:-1]  # Remove < and >
                if emoji.startswith("a:"):
                    emoji = emoji[2:]  # Remove a:
                elif emoji.startswith(":"):
                    emoji = emoji[1:]  # Remove :
            emoji_str = emoji
        else:
            emoji_str = str(emoji)

        # URL encode the emoji
        emoji_encoded = urllib.parse.quote(emoji_str)

        await self._http.request(
            Route(
                "PUT",
                "/channels/{channel_id}/messages/{message_id}/reactions/{emoji}/@me",
                channel_id=self.channel_id,
                message_id=self.id,
                emoji=emoji_encoded,
            )
        )

    async def remove_reaction(self, emoji, user_id: Optional[Snowflake] = None) -> None:
        """
        Remove a reaction from this message

        Args:
            emoji: Unicode emoji, custom emoji string, or Emoji object
            user_id: User ID to remove reaction from (requires MANAGE_MESSAGES)
                    If None, removes own reaction

        Example:
            ```python
            # Remove own reaction
            await message.remove_reaction("🔥")

            # Remove another user's reaction
            await message.remove_reaction("🔥", user_id=123456789)
            ```
        """
        import urllib.parse

        from ..core.http import Route
        from .emoji import Emoji, PartialEmoji

        # Convert to emoji string
        if isinstance(emoji, (Emoji, PartialEmoji)):
            if emoji.id:
                emoji_str = f"{emoji.name}:{emoji.id}"
            else:
                emoji_str = emoji.name
        elif isinstance(emoji, str):
            if emoji.startswith("<") and emoji.endswith(">"):
                emoji = emoji[1:-1]
                if emoji.startswith("a:"):
                    emoji = emoji[2:]
                elif emoji.startswith(":"):
                    emoji = emoji[1:]
            emoji_str = emoji
        else:
            emoji_str = str(emoji)

        # URL encode the emoji
        emoji_encoded = urllib.parse.quote(emoji_str)

        if user_id is None:
            # Remove own reaction
            await self._http.request(
                Route(
                    "DELETE",
                    "/channels/{channel_id}/messages/{message_id}/reactions/{emoji}/@me",
                    channel_id=self.channel_id,
                    message_id=self.id,
                    emoji=emoji_encoded,
                )
            )
        else:
            # Remove another user's reaction
            await self._http.request(
                Route(
                    "DELETE",
                    "/channels/{channel_id}/messages/{message_id}/reactions/{emoji}/{user_id}",
                    channel_id=self.channel_id,
                    message_id=self.id,
                    emoji=emoji_encoded,
                    user_id=user_id,
                )
            )

    async def clear_reactions(self, emoji=None) -> None:
        """
        Clear all reactions from this message

        Args:
            emoji: If provided, only clear reactions for this emoji

        Example:
            ```python
            # Clear all reactions
            await message.clear_reactions()

            # Clear specific emoji reactions
            await message.clear_reactions("🔥")
            ```
        """
        import urllib.parse

        from ..core.http import Route
        from .emoji import Emoji, PartialEmoji

        if emoji is None:
            # Clear all reactions
            await self._http.request(
                Route(
                    "DELETE",
                    "/channels/{channel_id}/messages/{message_id}/reactions",
                    channel_id=self.channel_id,
                    message_id=self.id,
                )
            )
        else:
            # Clear specific emoji - convert to string
            if isinstance(emoji, (Emoji, PartialEmoji)):
                if emoji.id:
                    emoji_str = f"{emoji.name}:{emoji.id}"
                else:
                    emoji_str = emoji.name
            elif isinstance(emoji, str):
                if emoji.startswith("<") and emoji.endswith(">"):
                    emoji = emoji[1:-1]
                    if emoji.startswith("a:"):
                        emoji = emoji[2:]
                    elif emoji.startswith(":"):
                        emoji = emoji[1:]
                emoji_str = emoji
            else:
                emoji_str = str(emoji)

            emoji_encoded = urllib.parse.quote(emoji_str)
            await self._http.request(
                Route(
                    "DELETE",
                    "/channels/{channel_id}/messages/{message_id}/reactions/{emoji}",
                    channel_id=self.channel_id,
                    message_id=self.id,
                    emoji=emoji_encoded,
                )
            )

    async def pin(self, *, reason: Optional[str] = None) -> None:
        """
        Pin this message

        Args:
            reason: Reason for audit log
        """
        from ..core.http import Route

        await self._http.request(
            Route(
                "PUT",
                "/channels/{channel_id}/pins/{message_id}",
                channel_id=self.channel_id,
                message_id=self.id,
            ),
            reason=reason,
        )

    async def unpin(self, *, reason: Optional[str] = None) -> None:
        """
        Unpin this message

        Args:
            reason: Reason for audit log
        """
        from ..core.http import Route

        await self._http.request(
            Route(
                "DELETE",
                "/channels/{channel_id}/pins/{message_id}",
                channel_id=self.channel_id,
                message_id=self.id,
            ),
            reason=reason,
        )

    async def publish(self) -> Message:
        """
        Crosspost/publish this message to announcement channel followers

        Requires the message to be in an announcement channel.
        Requires SEND_MESSAGES permission, or MANAGE_MESSAGES if not the author.

        Returns:
            Message: The updated message
        """
        from ..core.http import Route

        data = await self._http.request(
            Route(
                "POST",
                "/channels/{channel_id}/messages/{message_id}/crosspost",
                channel_id=self.channel_id,
                message_id=self.id,
            )
        )

        self._update(data)
        return self

    async def create_thread(
        self,
        *,
        name: str,
        auto_archive_duration: Optional[int] = None,
        rate_limit_per_user: Optional[int] = None,
        reason: Optional[str] = None,
    ):
        """
        Create a thread from this message

        Creates a PUBLIC_THREAD in text channels or ANNOUNCEMENT_THREAD in
        announcement channels. The thread ID will be the same as this message ID.

        Args:
            name: Thread name (1-100 characters)
            auto_archive_duration: Auto-archive after X minutes (60, 1440, 4320, 10080)
            rate_limit_per_user: Slowmode seconds (0-21600)
            reason: Reason for audit log

        Returns:
            Channel: The created thread channel

        Raises:
            HTTPException: If thread creation fails
        """
        from ..core.http import Route
        from .channel import Channel

        payload = {"name": name}

        if auto_archive_duration is not None:
            payload["auto_archive_duration"] = auto_archive_duration

        if rate_limit_per_user is not None:
            payload["rate_limit_per_user"] = rate_limit_per_user

        data = await self._http.request(
            Route(
                "POST",
                "/channels/{channel_id}/messages/{message_id}/threads",
                channel_id=self.channel_id,
                message_id=self.id,
            ),
            json=payload,
            reason=reason,
        )

        return Channel(data=data, http=self._http)
