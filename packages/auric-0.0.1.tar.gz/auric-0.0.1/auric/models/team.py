"""
Team model for application teams
"""

from __future__ import annotations

from enum import IntEnum
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..core.types import Snowflake

if TYPE_CHECKING:
    from ..core.http import HTTPClient


class MembershipState(IntEnum):
    """Team membership state"""

    INVITED = 1
    ACCEPTED = 2


class TeamMemberRole(IntEnum):
    """Team member role"""

    OWNER = 0
    ADMIN = 1
    DEVELOPER = 2
    READ_ONLY = 3


class TeamMember:
    """
    Represents a team member

    Attributes:
        membership_state: Membership state
        team_id: Team ID
        user: Partial user object
        role: Team member role
    """

    __slots__ = ("membership_state", "team_id", "user", "role")

    def __init__(self, *, data: Dict[str, Any]):
        self.membership_state: MembershipState = MembershipState(data["membership_state"])
        self.team_id: Snowflake = int(data["team_id"])
        self.user: Dict[str, Any] = data["user"]
        self.role: TeamMemberRole = TeamMemberRole(data.get("role", 2))

    def __repr__(self) -> str:
        return f'<TeamMember user_id={self.user.get("id")} role={self.role.name}>'

    @property
    def is_owner(self) -> bool:
        """Whether this member is the team owner"""
        return self.role == TeamMemberRole.OWNER

    @property
    def is_admin(self) -> bool:
        """Whether this member is an admin"""
        return self.role == TeamMemberRole.ADMIN

    @property
    def is_developer(self) -> bool:
        """Whether this member is a developer"""
        return self.role == TeamMemberRole.DEVELOPER

    @property
    def is_read_only(self) -> bool:
        """Whether this member has read-only access"""
        return self.role == TeamMemberRole.READ_ONLY

    @property
    def has_accepted(self) -> bool:
        """Whether this member has accepted the invitation"""
        return self.membership_state == MembershipState.ACCEPTED


class Team:
    """
    Represents a Discord team

    Attributes:
        id: Team ID
        icon: Team icon hash
        members: List of team members
        name: Team name
        owner_user_id: Team owner's user ID
    """

    __slots__ = ("id", "icon", "members", "name", "owner_user_id", "_http")

    def __init__(self, *, data: Dict[str, Any], http: Optional[HTTPClient] = None):
        self._http = http
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        """Update team from API data"""
        self.id: Snowflake = int(data["id"])
        self.icon: Optional[str] = data.get("icon")
        self.members: List[TeamMember] = [
            TeamMember(data=member_data) for member_data in data.get("members", [])
        ]
        self.name: str = data["name"]
        self.owner_user_id: Snowflake = int(data["owner_user_id"])

    def __repr__(self) -> str:
        return f"<Team id={self.id} name={self.name!r}>"

    def __str__(self) -> str:
        return self.name

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Team) and self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)

    @property
    def icon_url(self) -> Optional[str]:
        """Returns the team's icon URL if available"""
        if self.icon:
            return f"https://cdn.discordapp.com/team-icons/{self.id}/{self.icon}.png"
        return None

    def get_owner(self) -> Optional[TeamMember]:
        """Get the team owner"""
        for member in self.members:
            if member.is_owner:
                return member
        return None

    def get_admins(self) -> List[TeamMember]:
        """Get all admin members"""
        return [m for m in self.members if m.is_admin]

    def get_developers(self) -> List[TeamMember]:
        """Get all developer members"""
        return [m for m in self.members if m.is_developer]
