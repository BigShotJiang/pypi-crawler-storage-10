"""
Autocomplete interaction
"""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from ...types.interaction import InteractionCallbackType
from .base import BaseInteraction


@dataclass
class AutocompleteChoice:
    """Autocomplete choice"""

    name: str
    value: Any
    name_localizations: Optional[Dict[str, str]] = None


@dataclass
class AutocompleteInteraction(BaseInteraction):
    """Represents an autocomplete interaction"""

    command_name: Optional[str] = None
    command_id: Optional[str] = None
    focused_option: Optional[str] = None
    focused_value: Optional[str] = None

    def __post_init__(self):
        """Parse autocomplete data"""
        if self.data:
            self.command_name = self.data.get("name")
            self.command_id = self.data.get("id")

            # Find focused option
            for option in self.data.get("options", []):
                if option.get("focused"):
                    self.focused_option = option["name"]
                    self.focused_value = option.get("value", "")
                    break

    async def send_choices(self, choices: List[AutocompleteChoice]) -> None:
        """
        Send autocomplete choices

        Args:
            choices: List of choices (max 25)
        """
        if self._responded:
            raise ValueError("Already responded to this interaction")

        if len(choices) > 25:
            raise ValueError("Cannot send more than 25 choices")

        data = {
            "type": InteractionCallbackType.APPLICATION_COMMAND_AUTOCOMPLETE_RESULT,
            "data": {
                "choices": [
                    {
                        "name": choice.name,
                        "value": choice.value,
                        **(
                            {"name_localizations": choice.name_localizations}
                            if choice.name_localizations
                            else {}
                        ),
                    }
                    for choice in choices
                ]
            },
        }

        await self._client.http.create_interaction_response(self.id, self.token, data)
        self._responded = True

    async def respond(self, choices: List[Dict[str, Any]]) -> None:
        """
        Respond with autocomplete choices (simplified version)

        Args:
            choices: List of dicts with 'name' and 'value' keys
        """
        autocomplete_choices = [
            AutocompleteChoice(name=c["name"], value=c["value"]) for c in choices
        ]
        await self.send_choices(autocomplete_choices)
