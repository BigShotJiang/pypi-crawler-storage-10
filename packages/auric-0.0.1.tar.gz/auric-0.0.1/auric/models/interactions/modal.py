"""
Modal submit interaction
"""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from .base import BaseInteraction


@dataclass
class ModalInteraction(BaseInteraction):
    """Represents a modal submit interaction"""

    custom_id: Optional[str] = None
    components: Optional[List[Dict[str, Any]]] = None

    def __post_init__(self):
        """Parse modal data"""
        if self.data:
            self.custom_id = self.data.get("custom_id")
            self.components = self.data.get("components", [])

    def get_value(self, custom_id: str) -> Optional[str]:
        """
        Get the value of a text input by its custom_id

        Args:
            custom_id: The custom ID of the text input

        Returns:
            The text input value or None
        """
        for action_row in self.components:
            for component in action_row.get("components", []):
                if component.get("custom_id") == custom_id:
                    return component.get("value")
        return None

    def get_all_values(self) -> Dict[str, str]:
        """
        Get all text input values as a dictionary

        Returns:
            Dictionary mapping custom_id to value
        """
        values = {}
        for action_row in self.components:
            for component in action_row.get("components", []):
                custom_id = component.get("custom_id")
                value = component.get("value")
                if custom_id and value is not None:
                    values[custom_id] = value
        return values


# Alias for consistency
ModalSubmitInteraction = ModalInteraction
