"""
Base interaction class
"""

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, Optional

from ...types.interaction import InteractionCallbackType, InteractionType

if TYPE_CHECKING:
    from ...core.client import Client
    from ..channel import Channel
    from ..guild import Guild
    from ..member import Member
    from ..message import Message
    from ..user import User


@dataclass
class BaseInteraction:
    """Base interaction class"""

    id: str
    application_id: str
    type: InteractionType
    token: str
    version: int
    data: Optional[Dict[str, Any]] = None
    guild_id: Optional[str] = None
    channel_id: Optional[str] = None
    member: Optional["Member"] = None
    user: Optional["User"] = None
    message: Optional["Message"] = None
    locale: Optional[str] = None
    guild_locale: Optional[str] = None
    _client: Optional["Client"] = field(default=None, repr=False)
    _responded: bool = field(default=False, repr=False)
    _deferred: bool = field(default=False, repr=False)

    @property
    def guild(self) -> Optional["Guild"]:
        """Get the guild this interaction was sent in"""
        if self._client and self.guild_id:
            return self._client.get_guild(self.guild_id)
        return None

    @property
    def channel(self) -> Optional["Channel"]:
        """Get the channel this interaction was sent in"""
        if self._client and self.channel_id:
            return self._client.get_channel(self.channel_id)
        return None

    @property
    def author(self) -> Optional["User"]:
        """Get the user who triggered the interaction"""
        return self.member.user if self.member else self.user

    @property
    def is_guild_interaction(self) -> bool:
        """Check if this interaction is in a guild"""
        return self.guild_id is not None

    async def respond(
        self,
        content: Optional[str] = None,
        *,
        embed: Optional[Dict[str, Any]] = None,
        embeds: Optional[list] = None,
        components: Optional[list] = None,
        ephemeral: bool = False,
        tts: bool = False,
        allowed_mentions: Optional[Dict[str, Any]] = None,
        flags: int = 0,
    ) -> None:
        """
        Respond to the interaction

        Args:
            content: Message content
            embed: Single embed
            embeds: List of embeds
            components: Message components
            ephemeral: Whether the message is ephemeral (only visible to user)
            tts: Whether to use text-to-speech
            allowed_mentions: Allowed mentions
            flags: Message flags
        """
        if self._responded:
            raise ValueError("Already responded to this interaction")

        if ephemeral:
            flags |= 64  # EPHEMERAL flag

        data = {
            "type": InteractionCallbackType.CHANNEL_MESSAGE_WITH_SOURCE,
            "data": {
                "content": content,
                "tts": tts,
                "flags": flags,
            },
        }

        if embed:
            data["data"]["embeds"] = [embed]
        elif embeds:
            data["data"]["embeds"] = embeds

        if components:
            data["data"]["components"] = components

        if allowed_mentions:
            data["data"]["allowed_mentions"] = allowed_mentions

        await self._client.http.create_interaction_response(self.id, self.token, data)
        self._responded = True

    async def reply(self, *args, **kwargs) -> None:
        """Alias for respond()"""
        return await self.respond(*args, **kwargs)

    async def defer(self, *, ephemeral: bool = False) -> None:
        """
        Defer the interaction response
        Gives you 15 minutes to respond instead of 3 seconds

        Args:
            ephemeral: Whether the deferred message is ephemeral
        """
        if self._responded or self._deferred:
            raise ValueError("Already responded/deferred to this interaction")

        flags = 64 if ephemeral else 0

        data = {
            "type": InteractionCallbackType.DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE,
            "data": {"flags": flags},
        }

        await self._client.http.create_interaction_response(self.id, self.token, data)
        self._deferred = True

    async def followup(
        self,
        content: Optional[str] = None,
        *,
        embed: Optional[Dict[str, Any]] = None,
        embeds: Optional[list] = None,
        components: Optional[list] = None,
        ephemeral: bool = False,
        tts: bool = False,
    ) -> Dict[str, Any]:
        """
        Send a followup message

        Returns:
            The created message data
        """
        if not (self._responded or self._deferred):
            raise ValueError("Must respond or defer before sending followup")

        flags = 64 if ephemeral else 0

        data = {
            "content": content,
            "tts": tts,
            "flags": flags,
        }

        if embed:
            data["embeds"] = [embed]
        elif embeds:
            data["embeds"] = embeds

        if components:
            data["components"] = components

        return await self._client.http.create_followup_message(
            self.application_id, self.token, data
        )

    async def edit_response(
        self,
        content: Optional[str] = None,
        *,
        embed: Optional[Dict[str, Any]] = None,
        embeds: Optional[list] = None,
        components: Optional[list] = None,
    ) -> Dict[str, Any]:
        """
        Edit the original interaction response

        Returns:
            The edited message data
        """
        if not (self._responded or self._deferred):
            raise ValueError("No response to edit")

        data = {}
        if content is not None:
            data["content"] = content
        if embed:
            data["embeds"] = [embed]
        elif embeds:
            data["embeds"] = embeds
        if components is not None:
            data["components"] = components

        return await self._client.http.edit_interaction_response(
            self.application_id, self.token, data
        )

    async def delete_response(self) -> None:
        """Delete the original interaction response"""
        if not (self._responded or self._deferred):
            raise ValueError("No response to delete")

        await self._client.http.delete_interaction_response(self.application_id, self.token)
