"""
Scheduled Event - Discord guild scheduled events

Scheduled events allow guilds to schedule community events.
"""

from __future__ import annotations

from datetime import datetime
from enum import IntEnum
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from ..core.http import HTTPClient
    from .user import User


class ScheduledEventPrivacyLevel(IntEnum):
    """Privacy level for scheduled events"""

    GUILD_ONLY = 2  # Only guild members can see/join


class ScheduledEventStatus(IntEnum):
    """Status of a scheduled event"""

    SCHEDULED = 1  # Event is scheduled
    ACTIVE = 2  # Event is active/happening now
    COMPLETED = 3  # Event has completed
    CANCELED = 4  # Event was canceled


class ScheduledEventEntityType(IntEnum):
    """Type of entity for the event"""

    STAGE_INSTANCE = 1  # Event in a stage channel
    VOICE = 2  # Event in a voice channel
    EXTERNAL = 3  # Event is external (outside Discord)


class ScheduledEventEntityMetadata:
    """
    Metadata for event entity.

    Attributes:
        location: Location for external events
    """

    __slots__ = ("location",)

    def __init__(self, data: Dict[str, Any]):
        self.location: Optional[str] = data.get("location")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format"""
        data = {}
        if self.location:
            data["location"] = self.location
        return data


class ScheduledEvent:
    """
    A guild scheduled event.

    Attributes:
        id: Event ID
        guild_id: Guild ID
        channel_id: Channel ID (for voice/stage events)
        creator_id: User who created the event
        name: Event name
        description: Event description
        scheduled_start_time: When event starts
        scheduled_end_time: When event ends
        privacy_level: Privacy level
        status: Event status
        entity_type: Type of event
        entity_id: Entity ID
        entity_metadata: Additional entity info
        creator: User who created event (if available)
        user_count: Number of users interested
        image: Event cover image hash

    Example:
        ```python
        # Create a voice event
        event = await guild.create_scheduled_event(
            name="Community Gaming Night",
            description="Join us for some fun games!",
            start_time=datetime(2024, 12, 25, 20, 0),
            end_time=datetime(2024, 12, 25, 23, 0),
            channel_id=voice_channel_id,
            entity_type=ScheduledEventEntityType.VOICE
        )

        # Create external event
        event = await guild.create_scheduled_event(
            name="Community Meetup",
            description="Let's meet in person!",
            start_time=datetime(2024, 12, 25, 18, 0),
            end_time=datetime(2024, 12, 25, 22, 0),
            entity_type=ScheduledEventEntityType.EXTERNAL,
            location="Central Park, NYC"
        )
        ```
    """

    __slots__ = (
        "id",
        "guild_id",
        "channel_id",
        "creator_id",
        "name",
        "description",
        "scheduled_start_time",
        "scheduled_end_time",
        "privacy_level",
        "status",
        "entity_type",
        "entity_id",
        "entity_metadata",
        "creator",
        "user_count",
        "image",
        "_http",
    )

    def __init__(self, data: Dict[str, Any], http: Optional[HTTPClient] = None):
        self.id: int = int(data.get("id", 0))
        self.guild_id: int = int(data.get("guild_id", 0))

        channel_id = data.get("channel_id")
        self.channel_id: Optional[int] = int(channel_id) if channel_id else None

        creator_id = data.get("creator_id")
        self.creator_id: Optional[int] = int(creator_id) if creator_id else None

        self.name: str = data.get("name", "")
        self.description: Optional[str] = data.get("description")

        # Parse times
        start_str = data.get("scheduled_start_time")
        self.scheduled_start_time: Optional[datetime] = None
        if start_str:
            try:
                self.scheduled_start_time = datetime.fromisoformat(start_str.replace("Z", "+00:00"))
            except (ValueError, AttributeError):
                pass

        end_str = data.get("scheduled_end_time")
        self.scheduled_end_time: Optional[datetime] = None
        if end_str:
            try:
                self.scheduled_end_time = datetime.fromisoformat(end_str.replace("Z", "+00:00"))
            except (ValueError, AttributeError):
                pass

        self.privacy_level: ScheduledEventPrivacyLevel = ScheduledEventPrivacyLevel(
            data.get("privacy_level", 2)
        )

        self.status: ScheduledEventStatus = ScheduledEventStatus(data.get("status", 1))

        self.entity_type: ScheduledEventEntityType = ScheduledEventEntityType(
            data.get("entity_type", 1)
        )

        entity_id = data.get("entity_id")
        self.entity_id: Optional[int] = int(entity_id) if entity_id else None

        metadata_data = data.get("entity_metadata", {})
        self.entity_metadata: ScheduledEventEntityMetadata = ScheduledEventEntityMetadata(
            metadata_data
        )

        # Creator user object (optional)
        creator_data = data.get("creator")
        self.creator: Optional[User] = None
        if creator_data:
            from .user import User

            self.creator = User(creator_data, http)

        self.user_count: Optional[int] = data.get("user_count")
        self.image: Optional[str] = data.get("image")

        self._http = http

    @property
    def is_scheduled(self) -> bool:
        """Whether event is scheduled"""
        return self.status == ScheduledEventStatus.SCHEDULED

    @property
    def is_active(self) -> bool:
        """Whether event is currently active"""
        return self.status == ScheduledEventStatus.ACTIVE

    @property
    def is_completed(self) -> bool:
        """Whether event is completed"""
        return self.status == ScheduledEventStatus.COMPLETED

    @property
    def is_canceled(self) -> bool:
        """Whether event was canceled"""
        return self.status == ScheduledEventStatus.CANCELED

    @property
    def is_external(self) -> bool:
        """Whether event is external"""
        return self.entity_type == ScheduledEventEntityType.EXTERNAL

    @property
    def location(self) -> Optional[str]:
        """Event location (for external events)"""
        return self.entity_metadata.location

    @property
    def url(self) -> str:
        """URL to the event"""
        return f"https://discord.com/events/{self.guild_id}/{self.id}"

    async def edit(
        self,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        channel_id: Optional[int] = None,
        scheduled_start_time: Optional[datetime] = None,
        scheduled_end_time: Optional[datetime] = None,
        privacy_level: Optional[ScheduledEventPrivacyLevel] = None,
        entity_type: Optional[ScheduledEventEntityType] = None,
        status: Optional[ScheduledEventStatus] = None,
        location: Optional[str] = None,
        image: Optional[bytes] = None,
        reason: Optional[str] = None,
    ) -> ScheduledEvent:
        """
        Edit the scheduled event.

        Args:
            name: New name
            description: New description
            channel_id: New channel ID
            scheduled_start_time: New start time
            scheduled_end_time: New end time
            privacy_level: New privacy level
            entity_type: New entity type
            status: New status
            location: New location (for external events)
            image: New cover image
            reason: Audit log reason

        Returns:
            Updated event
        """
        if not self._http:
            raise ValueError("Cannot edit event without HTTP client")

        payload = {}

        if name is not None:
            payload["name"] = name

        if description is not None:
            payload["description"] = description

        if channel_id is not None:
            payload["channel_id"] = str(channel_id) if channel_id else None

        if scheduled_start_time is not None:
            payload["scheduled_start_time"] = scheduled_start_time.isoformat()

        if scheduled_end_time is not None:
            payload["scheduled_end_time"] = scheduled_end_time.isoformat()

        if privacy_level is not None:
            payload["privacy_level"] = int(privacy_level)

        if entity_type is not None:
            payload["entity_type"] = int(entity_type)

        if status is not None:
            payload["status"] = int(status)

        if location is not None:
            payload["entity_metadata"] = {"location": location}

        if image is not None:
            import base64

            payload["image"] = f"data:image/png;base64,{base64.b64encode(image).decode('ascii')}"

        data = await self._http.request(
            "PATCH",
            f"/guilds/{self.guild_id}/scheduled-events/{self.id}",
            json=payload,
            reason=reason,
        )

        return ScheduledEvent(data, self._http)

    async def delete(self, *, reason: Optional[str] = None) -> None:
        """
        Delete the scheduled event.

        Args:
            reason: Audit log reason
        """
        if not self._http:
            raise ValueError("Cannot delete event without HTTP client")

        await self._http.request(
            "DELETE", f"/guilds/{self.guild_id}/scheduled-events/{self.id}", reason=reason
        )

    async def start(self, *, reason: Optional[str] = None) -> ScheduledEvent:
        """
        Start the event.

        Args:
            reason: Audit log reason

        Returns:
            Updated event
        """
        return await self.edit(status=ScheduledEventStatus.ACTIVE, reason=reason)

    async def complete(self, *, reason: Optional[str] = None) -> ScheduledEvent:
        """
        Mark event as completed.

        Args:
            reason: Audit log reason

        Returns:
            Updated event
        """
        return await self.edit(status=ScheduledEventStatus.COMPLETED, reason=reason)

    async def cancel(self, *, reason: Optional[str] = None) -> ScheduledEvent:
        """
        Cancel the event.

        Args:
            reason: Audit log reason

        Returns:
            Updated event
        """
        return await self.edit(status=ScheduledEventStatus.CANCELED, reason=reason)

    async def get_users(
        self,
        *,
        limit: int = 100,
        with_member: bool = False,
        before: Optional[int] = None,
        after: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """
        Get users interested in the event.

        Args:
            limit: Max users to return (1-100)
            with_member: Include guild member data
            before: Get users before this user ID
            after: Get users after this user ID

        Returns:
            List of user objects with optional member data
        """
        if not self._http:
            raise ValueError("Cannot get users without HTTP client")

        params = {"limit": min(max(limit, 1), 100)}

        if with_member:
            params["with_member"] = "true"

        if before:
            params["before"] = str(before)

        if after:
            params["after"] = str(after)

        data = await self._http.request(
            "GET", f"/guilds/{self.guild_id}/scheduled-events/{self.id}/users", params=params
        )

        return data

    def __repr__(self) -> str:
        return f"<ScheduledEvent id={self.id} name={self.name!r} status={self.status.name}>"
