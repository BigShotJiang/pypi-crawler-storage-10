"""
Guild Template - Discord guild templates

Guild templates allow cloning of guild configurations.
"""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from ..core.http import HTTPClient
    from .guild import Guild
    from .user import User


class GuildTemplate:
    """
    Represents a guild template.

    Attributes:
        code: Template code
        name: Template name
        description: Template description
        usage_count: Number of times used
        creator_id: User who created template
        creator: User object of creator
        created_at: When template was created
        updated_at: When template was last updated
        source_guild_id: Source guild ID
        source_guild: Partial guild object
        is_dirty: Whether template needs syncing

    Example:
        ```python
        # Create template from guild
        template = await guild.create_template(
            name="My Server Template",
            description="A great community server template"
        )

        # Create guild from template
        new_guild = await template.create_guild(
            name="New Server",
            icon=icon_bytes
        )

        # Sync template
        await template.sync()
        ```
    """

    __slots__ = (
        "code",
        "name",
        "description",
        "usage_count",
        "creator_id",
        "creator",
        "created_at",
        "updated_at",
        "source_guild_id",
        "source_guild",
        "is_dirty",
        "_http",
    )

    def __init__(self, data: Dict[str, Any], http: Optional[HTTPClient] = None):
        self.code: str = data.get("code", "")
        self.name: str = data.get("name", "")
        self.description: Optional[str] = data.get("description")
        self.usage_count: int = data.get("usage_count", 0)

        self.creator_id: int = int(data.get("creator_id", 0))

        creator_data = data.get("creator")
        self.creator: Optional[User] = None
        if creator_data:
            from .user import User

            self.creator = User(creator_data, http)

        created_str = data.get("created_at")
        self.created_at: Optional[datetime] = None
        if created_str:
            try:
                self.created_at = datetime.fromisoformat(created_str.replace("Z", "+00:00"))
            except (ValueError, AttributeError):
                pass

        updated_str = data.get("updated_at")
        self.updated_at: Optional[datetime] = None
        if updated_str:
            try:
                self.updated_at = datetime.fromisoformat(updated_str.replace("Z", "+00:00"))
            except (ValueError, AttributeError):
                pass

        self.source_guild_id: int = int(data.get("source_guild_id", 0))

        # Partial guild data
        self.source_guild: Optional[Dict[str, Any]] = data.get("serialized_source_guild")

        self.is_dirty: Optional[bool] = data.get("is_dirty")

        self._http = http

    @property
    def url(self) -> str:
        """Template URL"""
        return f"https://discord.new/{self.code}"

    async def edit(
        self, *, name: Optional[str] = None, description: Optional[str] = None
    ) -> GuildTemplate:
        """
        Edit the template.

        Args:
            name: New name (1-100 chars)
            description: New description (max 120 chars)

        Returns:
            Updated template
        """
        if not self._http:
            raise ValueError("Cannot edit template without HTTP client")

        payload = {}

        if name is not None:
            if not 1 <= len(name) <= 100:
                raise ValueError("Name must be 1-100 characters")
            payload["name"] = name

        if description is not None:
            if len(description) > 120:
                raise ValueError("Description must be max 120 characters")
            payload["description"] = description

        data = await self._http.request(
            "PATCH", f"/guilds/{self.source_guild_id}/templates/{self.code}", json=payload
        )

        return GuildTemplate(data, self._http)

    async def delete(self) -> None:
        """Delete the template"""
        if not self._http:
            raise ValueError("Cannot delete template without HTTP client")

        await self._http.request("DELETE", f"/guilds/{self.source_guild_id}/templates/{self.code}")

    async def sync(self) -> GuildTemplate:
        """
        Sync the template with the source guild.

        Returns:
            Updated template
        """
        if not self._http:
            raise ValueError("Cannot sync template without HTTP client")

        data = await self._http.request(
            "PUT", f"/guilds/{self.source_guild_id}/templates/{self.code}"
        )

        return GuildTemplate(data, self._http)

    async def create_guild(self, name: str, *, icon: Optional[bytes] = None) -> Guild:
        """
        Create a guild from this template.

        Args:
            name: New guild name (2-100 chars)
            icon: Optional guild icon

        Returns:
            Created guild
        """
        if not self._http:
            raise ValueError("Cannot create guild without HTTP client")

        if not 2 <= len(name) <= 100:
            raise ValueError("Name must be 2-100 characters")

        payload = {"name": name}

        if icon:
            import base64

            payload["icon"] = f"data:image/png;base64,{base64.b64encode(icon).decode('ascii')}"

        data = await self._http.request("POST", f"/guilds/templates/{self.code}", json=payload)

        from .guild import Guild

        return Guild(data, self._http)

    def __repr__(self) -> str:
        return f"<GuildTemplate code={self.code!r} name={self.name!r} uses={self.usage_count}>"
