"""
Message Components - Buttons, Select Menus, Action Rows
"""

from __future__ import annotations

from enum import IntEnum
from typing import Any, Dict, List, Optional, Union

from ..core.types import Snowflake


class ComponentType(IntEnum):
    """Component types"""

    ACTION_ROW = 1
    BUTTON = 2
    STRING_SELECT = 3
    TEXT_INPUT = 4
    USER_SELECT = 5
    ROLE_SELECT = 6
    MENTIONABLE_SELECT = 7
    CHANNEL_SELECT = 8
    SECTION = 9
    TEXT_DISPLAY = 10
    THUMBNAIL = 11
    MEDIA_GALLERY = 12
    FILE = 13
    SEPARATOR = 14
    CONTAINER = 17
    LABEL = 18
    FILE_UPLOAD = 19


class ButtonStyle(IntEnum):
    """Button styles"""

    PRIMARY = 1  # Blurple button
    SECONDARY = 2  # Grey button
    SUCCESS = 3  # Green button
    DANGER = 4  # Red button
    LINK = 5  # Grey button with link
    PREMIUM = 6  # Premium button


class TextInputStyle(IntEnum):
    """Text input styles"""

    SHORT = 1  # Single line
    PARAGRAPH = 2  # Multi-line


class Button:
    """
    A clickable button component

    Buttons can be:
    - Interactive (PRIMARY, SECONDARY, SUCCESS, DANGER) - Send interaction
    - Links (LINK) - Navigate to URL
    - Premium (PREMIUM) - Purchase SKU

    Attributes:
        style: Button style
        label: Button text (max 80 chars)
        custom_id: Developer-defined ID (max 100 chars)
        emoji: Button emoji
        url: URL for link buttons
        sku_id: SKU ID for premium buttons
        disabled: Whether button is disabled

    Example:
        ```python
        # Interactive button
        button = Button(
            style=ButtonStyle.PRIMARY,
            label="Click me!",
            custom_id="my_button"
        )

        # Link button
        link = Button(
            style=ButtonStyle.LINK,
            label="Documentation",
            url="https://example.com"
        )
        ```
    """

    __slots__ = ("style", "label", "custom_id", "emoji", "url", "sku_id", "disabled", "id")

    def __init__(
        self,
        *,
        style: ButtonStyle,
        label: Optional[str] = None,
        custom_id: Optional[str] = None,
        emoji: Optional[Dict[str, Any]] = None,
        url: Optional[str] = None,
        sku_id: Optional[Snowflake] = None,
        disabled: bool = False,
        id: Optional[int] = None,
    ):
        self.style = style
        self.label = label
        self.custom_id = custom_id
        self.emoji = emoji
        self.url = url
        self.sku_id = sku_id
        self.disabled = disabled
        self.id = id

        # Validation
        if style in (
            ButtonStyle.PRIMARY,
            ButtonStyle.SECONDARY,
            ButtonStyle.SUCCESS,
            ButtonStyle.DANGER,
        ):
            if not custom_id:
                raise ValueError("Interactive buttons must have a custom_id")
            if url or sku_id:
                raise ValueError("Interactive buttons cannot have url or sku_id")

        elif style == ButtonStyle.LINK:
            if not url:
                raise ValueError("Link buttons must have a url")
            if custom_id or sku_id:
                raise ValueError("Link buttons cannot have custom_id or sku_id")

        elif style == ButtonStyle.PREMIUM:
            if not sku_id:
                raise ValueError("Premium buttons must have a sku_id")
            if custom_id or label or url or emoji:
                raise ValueError("Premium buttons cannot have custom_id, label, url, or emoji")

        if label and len(label) > 80:
            raise ValueError("Button label must be 80 characters or less")

        if custom_id and len(custom_id) > 100:
            raise ValueError("Button custom_id must be 100 characters or less")

        if url and len(url) > 512:
            raise ValueError("Button url must be 512 characters or less")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API dict"""
        data = {"type": ComponentType.BUTTON, "style": self.style}

        if self.id is not None:
            data["id"] = self.id

        if self.label:
            data["label"] = self.label

        if self.custom_id:
            data["custom_id"] = self.custom_id

        if self.emoji:
            data["emoji"] = self.emoji

        if self.url:
            data["url"] = self.url

        if self.sku_id:
            data["sku_id"] = str(self.sku_id)

        if self.disabled:
            data["disabled"] = True

        return data

    def __repr__(self) -> str:
        return f"<Button style={self.style.name} label={self.label!r}>"


class SelectOption:
    """
    An option in a select menu

    Attributes:
        label: User-facing name (max 100 chars)
        value: Developer-defined value (max 100 chars)
        description: Additional description (max 100 chars)
        emoji: Option emoji
        default: Whether this is the default option

    Example:
        ```python
        option = SelectOption(
            label="Option 1",
            value="opt1",
            description="First option",
            emoji={"name": "🎉"}
        )
        ```
    """

    __slots__ = ("label", "value", "description", "emoji", "default")

    def __init__(
        self,
        *,
        label: str,
        value: str,
        description: Optional[str] = None,
        emoji: Optional[Dict[str, Any]] = None,
        default: bool = False,
    ):
        if len(label) > 100:
            raise ValueError("Option label must be 100 characters or less")
        if len(value) > 100:
            raise ValueError("Option value must be 100 characters or less")
        if description and len(description) > 100:
            raise ValueError("Option description must be 100 characters or less")

        self.label = label
        self.value = value
        self.description = description
        self.emoji = emoji
        self.default = default

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API dict"""
        data = {"label": self.label, "value": self.value}

        if self.description:
            data["description"] = self.description

        if self.emoji:
            data["emoji"] = self.emoji

        if self.default:
            data["default"] = True

        return data

    def __repr__(self) -> str:
        return f"<SelectOption label={self.label!r} value={self.value!r}>"


class StringSelect:
    """
    A string select menu component

    Allows users to select from predefined text options.
    Can be single-select or multi-select.

    Attributes:
        custom_id: Developer-defined ID (max 100 chars)
        options: List of select options (max 25)
        placeholder: Placeholder text (max 150 chars)
        min_values: Minimum selections (0-25)
        max_values: Maximum selections (1-25)
        disabled: Whether disabled
        required: Whether required (modal only)

    Example:
        ```python
        select = StringSelect(
            custom_id="color_select",
            placeholder="Choose a color",
            options=[
                SelectOption(label="Red", value="red"),
                SelectOption(label="Blue", value="blue"),
                SelectOption(label="Green", value="green")
            ],
            min_values=1,
            max_values=1
        )
        ```
    """

    __slots__ = (
        "custom_id",
        "options",
        "placeholder",
        "min_values",
        "max_values",
        "disabled",
        "required",
        "id",
    )

    def __init__(
        self,
        *,
        custom_id: str,
        options: List[SelectOption],
        placeholder: Optional[str] = None,
        min_values: int = 1,
        max_values: int = 1,
        disabled: bool = False,
        required: bool = True,
        id: Optional[int] = None,
    ):
        if len(custom_id) > 100:
            raise ValueError("custom_id must be 100 characters or less")
        if not options or len(options) > 25:
            raise ValueError("Must have 1-25 options")
        if placeholder and len(placeholder) > 150:
            raise ValueError("Placeholder must be 150 characters or less")
        if not 0 <= min_values <= 25:
            raise ValueError("min_values must be 0-25")
        if not 1 <= max_values <= 25:
            raise ValueError("max_values must be 1-25")
        if min_values > max_values:
            raise ValueError("min_values cannot be greater than max_values")

        self.custom_id = custom_id
        self.options = options
        self.placeholder = placeholder
        self.min_values = min_values
        self.max_values = max_values
        self.disabled = disabled
        self.required = required
        self.id = id

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API dict"""
        data = {
            "type": ComponentType.STRING_SELECT,
            "custom_id": self.custom_id,
            "options": [
                opt.to_dict() if isinstance(opt, SelectOption) else opt for opt in self.options
            ],
        }

        if self.id is not None:
            data["id"] = self.id

        if self.placeholder:
            data["placeholder"] = self.placeholder

        if self.min_values != 1:
            data["min_values"] = self.min_values

        if self.max_values != 1:
            data["max_values"] = self.max_values

        if self.disabled:
            data["disabled"] = True

        if not self.required:
            data["required"] = False

        return data

    def __repr__(self) -> str:
        return f"<StringSelect custom_id={self.custom_id!r} options={len(self.options)}>"


class UserSelect:
    """User select menu - allows selecting users"""

    __slots__ = (
        "custom_id",
        "placeholder",
        "min_values",
        "max_values",
        "disabled",
        "required",
        "id",
    )

    def __init__(
        self,
        *,
        custom_id: str,
        placeholder: Optional[str] = None,
        min_values: int = 1,
        max_values: int = 1,
        disabled: bool = False,
        required: bool = True,
        id: Optional[int] = None,
    ):
        self.custom_id = custom_id
        self.placeholder = placeholder
        self.min_values = min_values
        self.max_values = max_values
        self.disabled = disabled
        self.required = required
        self.id = id

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API dict"""
        data = {"type": ComponentType.USER_SELECT, "custom_id": self.custom_id}

        if self.id is not None:
            data["id"] = self.id
        if self.placeholder:
            data["placeholder"] = self.placeholder
        if self.min_values != 1:
            data["min_values"] = self.min_values
        if self.max_values != 1:
            data["max_values"] = self.max_values
        if self.disabled:
            data["disabled"] = True
        if not self.required:
            data["required"] = False

        return data


class RoleSelect:
    """Role select menu - allows selecting roles"""

    __slots__ = (
        "custom_id",
        "placeholder",
        "min_values",
        "max_values",
        "disabled",
        "required",
        "id",
    )

    def __init__(
        self,
        *,
        custom_id: str,
        placeholder: Optional[str] = None,
        min_values: int = 1,
        max_values: int = 1,
        disabled: bool = False,
        required: bool = True,
        id: Optional[int] = None,
    ):
        self.custom_id = custom_id
        self.placeholder = placeholder
        self.min_values = min_values
        self.max_values = max_values
        self.disabled = disabled
        self.required = required
        self.id = id

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API dict"""
        data = {"type": ComponentType.ROLE_SELECT, "custom_id": self.custom_id}

        if self.id is not None:
            data["id"] = self.id
        if self.placeholder:
            data["placeholder"] = self.placeholder
        if self.min_values != 1:
            data["min_values"] = self.min_values
        if self.max_values != 1:
            data["max_values"] = self.max_values
        if self.disabled:
            data["disabled"] = True
        if not self.required:
            data["required"] = False

        return data


class MentionableSelect:
    """Mentionable select menu - allows selecting users and roles"""

    __slots__ = (
        "custom_id",
        "placeholder",
        "min_values",
        "max_values",
        "disabled",
        "required",
        "id",
    )

    def __init__(
        self,
        *,
        custom_id: str,
        placeholder: Optional[str] = None,
        min_values: int = 1,
        max_values: int = 1,
        disabled: bool = False,
        required: bool = True,
        id: Optional[int] = None,
    ):
        self.custom_id = custom_id
        self.placeholder = placeholder
        self.min_values = min_values
        self.max_values = max_values
        self.disabled = disabled
        self.required = required
        self.id = id

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API dict"""
        data = {"type": ComponentType.MENTIONABLE_SELECT, "custom_id": self.custom_id}

        if self.id is not None:
            data["id"] = self.id
        if self.placeholder:
            data["placeholder"] = self.placeholder
        if self.min_values != 1:
            data["min_values"] = self.min_values
        if self.max_values != 1:
            data["max_values"] = self.max_values
        if self.disabled:
            data["disabled"] = True
        if not self.required:
            data["required"] = False

        return data


class ChannelSelect:
    """Channel select menu - allows selecting channels"""

    __slots__ = (
        "custom_id",
        "placeholder",
        "min_values",
        "max_values",
        "channel_types",
        "disabled",
        "required",
        "id",
    )

    def __init__(
        self,
        *,
        custom_id: str,
        placeholder: Optional[str] = None,
        min_values: int = 1,
        max_values: int = 1,
        channel_types: Optional[List[int]] = None,
        disabled: bool = False,
        required: bool = True,
        id: Optional[int] = None,
    ):
        self.custom_id = custom_id
        self.placeholder = placeholder
        self.min_values = min_values
        self.max_values = max_values
        self.channel_types = channel_types
        self.disabled = disabled
        self.required = required
        self.id = id

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API dict"""
        data = {"type": ComponentType.CHANNEL_SELECT, "custom_id": self.custom_id}

        if self.id is not None:
            data["id"] = self.id
        if self.placeholder:
            data["placeholder"] = self.placeholder
        if self.min_values != 1:
            data["min_values"] = self.min_values
        if self.max_values != 1:
            data["max_values"] = self.max_values
        if self.channel_types:
            data["channel_types"] = self.channel_types
        if self.disabled:
            data["disabled"] = True
        if not self.required:
            data["required"] = False

        return data


class TextInput:
    """
    A text input component for modals

    Attributes:
        custom_id: Developer-defined ID
        style: Input style (SHORT or PARAGRAPH)
        label: Label text
        min_length: Minimum length
        max_length: Maximum length
        required: Whether required
        value: Pre-filled value
        placeholder: Placeholder text

    Example:
        ```python
        text_input = TextInput(
            custom_id="feedback",
            style=TextInputStyle.PARAGRAPH,
            label="Your Feedback",
            placeholder="Tell us what you think...",
            min_length=10,
            max_length=1000,
            required=True
        )
        ```
    """

    __slots__ = (
        "custom_id",
        "style",
        "label",
        "min_length",
        "max_length",
        "required",
        "value",
        "placeholder",
        "id",
    )

    def __init__(
        self,
        *,
        custom_id: str,
        style: TextInputStyle,
        label: str,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
        required: bool = True,
        value: Optional[str] = None,
        placeholder: Optional[str] = None,
        id: Optional[int] = None,
    ):
        self.custom_id = custom_id
        self.style = style
        self.label = label
        self.min_length = min_length
        self.max_length = max_length
        self.required = required
        self.value = value
        self.placeholder = placeholder
        self.id = id

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API dict"""
        data = {
            "type": ComponentType.TEXT_INPUT,
            "custom_id": self.custom_id,
            "style": self.style,
            "label": self.label,
        }

        if self.id is not None:
            data["id"] = self.id
        if self.min_length is not None:
            data["min_length"] = self.min_length
        if self.max_length is not None:
            data["max_length"] = self.max_length
        if not self.required:
            data["required"] = False
        if self.value:
            data["value"] = self.value
        if self.placeholder:
            data["placeholder"] = self.placeholder

        return data


Component = Union[
    Button, StringSelect, UserSelect, RoleSelect, MentionableSelect, ChannelSelect, TextInput
]


class ActionRow:
    """
    A row of components

    Can contain:
    - Up to 5 buttons
    - A single select menu

    Example:
        ```python
        # Row with buttons
        row = ActionRow(
            Button(style=ButtonStyle.PRIMARY, label="Yes", custom_id="yes"),
            Button(style=ButtonStyle.DANGER, label="No", custom_id="no")
        )

        # Row with select menu
        row = ActionRow(
            StringSelect(
                custom_id="options",
                options=[...]
            )
        )
        ```
    """

    __slots__ = ("components", "id")

    def __init__(self, *components: Component, id: Optional[int] = None):
        if not components:
            raise ValueError("ActionRow must have at least one component")

        if len(components) > 5:
            raise ValueError("ActionRow can have at most 5 components")

        # Check for mixed component types
        if any(
            isinstance(
                c,
                (StringSelect, UserSelect, RoleSelect, MentionableSelect, ChannelSelect, TextInput),
            )
            for c in components
        ):
            if len(components) > 1:
                raise ValueError("ActionRow can only have one select menu or text input")

        self.components = list(components)
        self.id = id

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API dict"""
        data = {
            "type": ComponentType.ACTION_ROW,
            "components": [c.to_dict() if hasattr(c, "to_dict") else c for c in self.components],
        }

        if self.id is not None:
            data["id"] = self.id

        return data

    def __repr__(self) -> str:
        return f"<ActionRow components={len(self.components)}>"
