"""
Audit Log - Discord audit log support

Audit logs track moderation and administrative actions in guilds.
"""

from __future__ import annotations

from datetime import datetime
from enum import IntEnum
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from .guild import Guild
    from .user import User


class AuditLogEvent(IntEnum):
    """Audit log event types"""

    GUILD_UPDATE = 1
    CHANNEL_CREATE = 10
    CHANNEL_UPDATE = 11
    CHANNEL_DELETE = 12
    CHANNEL_OVERWRITE_CREATE = 13
    CHANNEL_OVERWRITE_UPDATE = 14
    CHANNEL_OVERWRITE_DELETE = 15
    MEMBER_KICK = 20
    MEMBER_PRUNE = 21
    MEMBER_BAN_ADD = 22
    MEMBER_BAN_REMOVE = 23
    MEMBER_UPDATE = 24
    MEMBER_ROLE_UPDATE = 25
    MEMBER_MOVE = 26
    MEMBER_DISCONNECT = 27
    BOT_ADD = 28
    ROLE_CREATE = 30
    ROLE_UPDATE = 31
    ROLE_DELETE = 32
    INVITE_CREATE = 40
    INVITE_UPDATE = 41
    INVITE_DELETE = 42
    WEBHOOK_CREATE = 50
    WEBHOOK_UPDATE = 51
    WEBHOOK_DELETE = 52
    EMOJI_CREATE = 60
    EMOJI_UPDATE = 61
    EMOJI_DELETE = 62
    MESSAGE_DELETE = 72
    MESSAGE_BULK_DELETE = 73
    MESSAGE_PIN = 74
    MESSAGE_UNPIN = 75
    INTEGRATION_CREATE = 80
    INTEGRATION_UPDATE = 81
    INTEGRATION_DELETE = 82
    STAGE_INSTANCE_CREATE = 83
    STAGE_INSTANCE_UPDATE = 84
    STAGE_INSTANCE_DELETE = 85
    STICKER_CREATE = 90
    STICKER_UPDATE = 91
    STICKER_DELETE = 92
    GUILD_SCHEDULED_EVENT_CREATE = 100
    GUILD_SCHEDULED_EVENT_UPDATE = 101
    GUILD_SCHEDULED_EVENT_DELETE = 102
    THREAD_CREATE = 110
    THREAD_UPDATE = 111
    THREAD_DELETE = 112
    AUTO_MODERATION_RULE_CREATE = 140
    AUTO_MODERATION_RULE_UPDATE = 141
    AUTO_MODERATION_RULE_DELETE = 142
    AUTO_MODERATION_BLOCK_MESSAGE = 143
    AUTO_MODERATION_FLAG_TO_CHANNEL = 144
    AUTO_MODERATION_USER_COMMUNICATION_DISABLED = 145


class AuditLogChange:
    """
    Represents a change in an audit log entry.

    Attributes:
        key: Name of the changed property
        old_value: Old value
        new_value: New value
    """

    __slots__ = ("key", "old_value", "new_value")

    def __init__(self, data: Dict[str, Any]):
        self.key: str = data.get("key", "")
        self.old_value: Any = data.get("old_value")
        self.new_value: Any = data.get("new_value")

    def __repr__(self) -> str:
        return f"<AuditLogChange key={self.key!r} old={self.old_value!r} new={self.new_value!r}>"


class AuditLogEntry:
    """
    Represents an entry in the audit log.

    Attributes:
        id: ID of the entry
        target_id: ID of the affected entity
        changes: List of changes made
        user_id: ID of user who made changes
        action_type: Type of action
        options: Additional info for certain actions
        reason: Reason for the action
    """

    __slots__ = (
        "id",
        "target_id",
        "changes",
        "user_id",
        "action_type",
        "options",
        "reason",
        "_http",
        "_guild_id",
    )

    def __init__(self, data: Dict[str, Any], http: Any = None, guild_id: Optional[int] = None):
        self.id: int = int(data.get("id", 0))

        target_id = data.get("target_id")
        self.target_id: Optional[int] = int(target_id) if target_id else None

        changes_data = data.get("changes", [])
        self.changes: List[AuditLogChange] = [AuditLogChange(change) for change in changes_data]

        user_id = data.get("user_id")
        self.user_id: Optional[int] = int(user_id) if user_id else None

        self.action_type: AuditLogEvent = AuditLogEvent(data.get("action_type", 0))
        self.options: Dict[str, Any] = data.get("options", {})
        self.reason: Optional[str] = data.get("reason")

        self._http = http
        self._guild_id = guild_id

    @property
    def created_at(self) -> datetime:
        """When this entry was created"""
        timestamp = ((self.id >> 22) + 1420070400000) / 1000
        return datetime.fromtimestamp(timestamp)

    def get_change(self, key: str) -> Optional[AuditLogChange]:
        """Get a specific change by key"""
        for change in self.changes:
            if change.key == key:
                return change
        return None

    def before(self, key: str) -> Any:
        """Get the old value of a change"""
        change = self.get_change(key)
        return change.old_value if change else None

    def after(self, key: str) -> Any:
        """Get the new value of a change"""
        change = self.get_change(key)
        return change.new_value if change else None

    @property
    def is_ban(self) -> bool:
        """Whether this is a ban action"""
        return self.action_type in (AuditLogEvent.MEMBER_BAN_ADD, AuditLogEvent.MEMBER_BAN_REMOVE)

    @property
    def is_kick(self) -> bool:
        """Whether this is a kick action"""
        return self.action_type == AuditLogEvent.MEMBER_KICK

    @property
    def is_prune(self) -> bool:
        """Whether this is a prune action"""
        return self.action_type == AuditLogEvent.MEMBER_PRUNE

    @property
    def is_moderation(self) -> bool:
        """Whether this is a moderation action"""
        return self.action_type in (
            AuditLogEvent.MEMBER_KICK,
            AuditLogEvent.MEMBER_BAN_ADD,
            AuditLogEvent.MEMBER_BAN_REMOVE,
            AuditLogEvent.MEMBER_PRUNE,
            AuditLogEvent.AUTO_MODERATION_BLOCK_MESSAGE,
            AuditLogEvent.AUTO_MODERATION_FLAG_TO_CHANNEL,
            AuditLogEvent.AUTO_MODERATION_USER_COMMUNICATION_DISABLED,
        )

    def __repr__(self) -> str:
        return f"<AuditLogEntry id={self.id} action={self.action_type.name} user_id={self.user_id}>"


class AuditLog:
    """
    Represents a guild's audit log.

    Attributes:
        entries: List of audit log entries
        users: Dictionary of users mentioned in the log
        webhooks: Dictionary of webhooks mentioned in the log
    """

    __slots__ = ("entries", "users", "webhooks", "_http", "_guild_id")

    def __init__(self, data: Dict[str, Any], http: Any = None, guild_id: Optional[int] = None):
        self._http = http
        self._guild_id = guild_id

        # Parse entries
        entries_data = data.get("audit_log_entries", [])
        self.entries: List[AuditLogEntry] = [
            AuditLogEntry(entry, http, guild_id) for entry in entries_data
        ]

        # Parse users
        users_data = data.get("users", [])
        from .user import User

        self.users: Dict[int, User] = {int(user["id"]): User(user, http) for user in users_data}

        # Parse webhooks
        webhooks_data = data.get("webhooks", [])
        from .webhook import Webhook

        self.webhooks: Dict[int, Webhook] = {
            int(webhook["id"]): Webhook(webhook, http) for webhook in webhooks_data
        }

    def filter(
        self,
        *,
        action: Optional[AuditLogEvent] = None,
        user_id: Optional[int] = None,
        target_id: Optional[int] = None,
    ) -> List[AuditLogEntry]:
        """
        Filter audit log entries.

        Args:
            action: Filter by action type
            user_id: Filter by user who performed action
            target_id: Filter by target of action

        Returns:
            Filtered list of entries
        """
        filtered = self.entries

        if action is not None:
            filtered = [e for e in filtered if e.action_type == action]

        if user_id is not None:
            filtered = [e for e in filtered if e.user_id == user_id]

        if target_id is not None:
            filtered = [e for e in filtered if e.target_id == target_id]

        return filtered

    def get_user(self, user_id: int) -> Optional[User]:
        """Get a user from the log"""
        return self.users.get(user_id)

    def get_webhook(self, webhook_id: int) -> Optional[Any]:
        """Get a webhook from the log"""
        return self.webhooks.get(webhook_id)

    @property
    def moderation_entries(self) -> List[AuditLogEntry]:
        """Get all moderation entries"""
        return [e for e in self.entries if e.is_moderation]

    @property
    def ban_entries(self) -> List[AuditLogEntry]:
        """Get all ban-related entries"""
        return [e for e in self.entries if e.is_ban]

    @property
    def kick_entries(self) -> List[AuditLogEntry]:
        """Get all kick entries"""
        return [e for e in self.entries if e.is_kick]

    def __len__(self) -> int:
        return len(self.entries)

    def __iter__(self):
        return iter(self.entries)

    def __repr__(self) -> str:
        return f"<AuditLog entries={len(self.entries)} users={len(self.users)}>"
