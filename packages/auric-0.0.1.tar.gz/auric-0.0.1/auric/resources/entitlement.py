# Entitlement API - Complete Implementation

from enum import IntEnum
from typing import List, Optional

from ..http import HTTPClient
from ..types import Snowflake


class EntitlementType(IntEnum):
    PURCHASE = 1
    PREMIUM_SUBSCRIPTION = 2
    DEVELOPER_GIFT = 3
    TEST_MODE_PURCHASE = 4
    FREE_PURCHASE = 5
    USER_GIFT = 6
    PREMIUM_PURCHASE = 7
    APPLICATION_SUBSCRIPTION = 8


class Entitlement:
    def __init__(self, data: dict):
        self.id: Snowflake = data["id"]
        self.sku_id: Snowflake = data["sku_id"]
        self.application_id: Snowflake = data["application_id"]
        self.user_id: Optional[Snowflake] = data.get("user_id")
        self.type: EntitlementType = EntitlementType(data["type"])
        self.deleted: bool = data["deleted"]
        self.starts_at: Optional[str] = data.get("starts_at")
        self.ends_at: Optional[str] = data.get("ends_at")
        self.guild_id: Optional[Snowflake] = data.get("guild_id")
        self.consumed: Optional[bool] = data.get("consumed")


class EntitlementAPI:
    def __init__(self, http: HTTPClient):
        self.http = http

    async def list_entitlements(
        self,
        application_id: Snowflake,
        user_id: Optional[Snowflake] = None,
        sku_ids: Optional[List[Snowflake]] = None,
        before: Optional[Snowflake] = None,
        after: Optional[Snowflake] = None,
        limit: int = 100,
        guild_id: Optional[Snowflake] = None,
        exclude_ended: bool = False,
    ) -> List[Entitlement]:
        params = {"limit": limit, "exclude_ended": exclude_ended}
        if user_id:
            params["user_id"] = user_id
        if sku_ids:
            params["sku_ids"] = ",".join(sku_ids)
        if before:
            params["before"] = before
        if after:
            params["after"] = after
        if guild_id:
            params["guild_id"] = guild_id

        data = await self.http.request(
            "GET", f"/applications/{application_id}/entitlements", params=params
        )
        return [Entitlement(e) for e in data]

    async def create_test_entitlement(
        self, application_id: Snowflake, sku_id: Snowflake, owner_id: Snowflake, owner_type: int
    ) -> Entitlement:
        payload = {"sku_id": sku_id, "owner_id": owner_id, "owner_type": owner_type}
        data = await self.http.request(
            "POST", f"/applications/{application_id}/entitlements", json=payload
        )
        return Entitlement(data)

    async def delete_test_entitlement(
        self, application_id: Snowflake, entitlement_id: Snowflake
    ) -> None:
        await self.http.request(
            "DELETE", f"/applications/{application_id}/entitlements/{entitlement_id}"
        )
