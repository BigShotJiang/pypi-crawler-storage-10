"""
Poll Resource Implementation
Implements Discord Poll API with all structures and endpoints.
"""

from datetime import datetime
from typing import List, Optional

from ..http import HTTPClient
from ..types import Snowflake


class PollLayoutType:
    """Poll layout types."""

    DEFAULT = 1


class PollMedia:
    """Represents poll media (question or answer)."""

    def __init__(self, data: dict):
        self.text: Optional[str] = data.get("text")
        self.emoji: Optional[dict] = data.get("emoji")

    def to_dict(self) -> dict:
        """Convert to dictionary for API requests."""
        result = {}
        if self.text is not None:
            result["text"] = self.text
        if self.emoji is not None:
            result["emoji"] = self.emoji
        return result

    @classmethod
    def create_text(cls, text: str) -> "PollMedia":
        """Create poll media with text only."""
        return cls({"text": text})

    @classmethod
    def create_with_emoji(
        cls, text: str, emoji_id: Optional[Snowflake] = None, emoji_name: Optional[str] = None
    ) -> "PollMedia":
        """Create poll media with text and emoji."""
        emoji = {}
        if emoji_id:
            emoji["id"] = emoji_id
        if emoji_name:
            emoji["name"] = emoji_name
        return cls({"text": text, "emoji": emoji})


class PollAnswer:
    """Represents a poll answer."""

    def __init__(self, data: dict):
        self.answer_id: Optional[int] = data.get("answer_id")
        self.poll_media: PollMedia = PollMedia(data.get("poll_media", {}))

    def to_dict(self) -> dict:
        """Convert to dictionary for API requests."""
        result = {"poll_media": self.poll_media.to_dict()}
        if self.answer_id is not None:
            result["answer_id"] = self.answer_id
        return result


class PollAnswerCount:
    """Represents vote count for a poll answer."""

    def __init__(self, data: dict):
        self.id: int = data["id"]
        self.count: int = data["count"]
        self.me_voted: bool = data["me_voted"]


class PollResults:
    """Represents poll results."""

    def __init__(self, data: dict):
        self.is_finalized: bool = data["is_finalized"]
        self.answer_counts: List[PollAnswerCount] = [
            PollAnswerCount(count) for count in data.get("answer_counts", [])
        ]

    def get_count(self, answer_id: int) -> int:
        """Get vote count for specific answer."""
        for count in self.answer_counts:
            if count.id == answer_id:
                return count.count
        return 0

    def did_i_vote(self, answer_id: int) -> bool:
        """Check if current user voted for specific answer."""
        for count in self.answer_counts:
            if count.id == answer_id:
                return count.me_voted
        return False


class Poll:
    """Represents a Discord poll."""

    def __init__(self, data: dict):
        self.question: PollMedia = PollMedia(data["question"])
        self.answers: List[PollAnswer] = [PollAnswer(answer) for answer in data.get("answers", [])]
        self.expiry: Optional[datetime] = None
        if data.get("expiry"):
            self.expiry = datetime.fromisoformat(data["expiry"].replace("Z", "+00:00"))

        self.allow_multiselect: bool = data.get("allow_multiselect", False)
        self.layout_type: int = data.get("layout_type", PollLayoutType.DEFAULT)
        self.results: Optional[PollResults] = None
        if "results" in data:
            self.results = PollResults(data["results"])

    @property
    def is_expired(self) -> bool:
        """Check if poll has expired."""
        if not self.expiry:
            return False
        return datetime.now(self.expiry.tzinfo) >= self.expiry

    @property
    def is_finalized(self) -> bool:
        """Check if poll results are finalized."""
        return self.results is not None and self.results.is_finalized


class PollCreateRequest:
    """Request object for creating a poll."""

    def __init__(
        self,
        question: PollMedia,
        answers: List[PollAnswer],
        duration: Optional[int] = 24,
        allow_multiselect: bool = False,
        layout_type: int = PollLayoutType.DEFAULT,
    ):
        """
        Create a poll request.

        Args:
            question: The poll question (text only)
            answers: List of answers (up to 10)
            duration: Hours poll should be open (up to 768 = 32 days)
            allow_multiselect: Whether users can select multiple answers
            layout_type: Layout type (currently only DEFAULT supported)
        """
        if len(answers) > 10:
            raise ValueError("Maximum 10 answers allowed")
        if len(answers) < 1:
            raise ValueError("Minimum 1 answer required")
        if duration and (duration < 1 or duration > 768):
            raise ValueError("Duration must be between 1 and 768 hours")

        self.question = question
        self.answers = answers
        self.duration = duration
        self.allow_multiselect = allow_multiselect
        self.layout_type = layout_type

    def to_dict(self) -> dict:
        """Convert to dictionary for API requests."""
        result = {
            "question": self.question.to_dict(),
            "answers": [answer.to_dict() for answer in self.answers],
            "allow_multiselect": self.allow_multiselect,
            "layout_type": self.layout_type,
        }
        if self.duration is not None:
            result["duration"] = self.duration
        return result


class PollAPI:
    """API methods for Poll operations."""

    def __init__(self, http: HTTPClient):
        self.http = http

    async def get_answer_voters(
        self,
        channel_id: Snowflake,
        message_id: Snowflake,
        answer_id: int,
        after: Optional[Snowflake] = None,
        limit: int = 25,
    ) -> List[dict]:
        """
        Get list of users that voted for a specific answer.

        Args:
            channel_id: Channel containing the poll
            message_id: Message containing the poll
            answer_id: The answer ID to get voters for
            after: Get users after this user ID
            limit: Max number of users to return (1-100)

        Returns:
            List of user objects
        """
        if limit < 1 or limit > 100:
            raise ValueError("Limit must be between 1 and 100")

        params = {"limit": limit}
        if after:
            params["after"] = after

        response = await self.http.request(
            "GET", f"/channels/{channel_id}/polls/{message_id}/answers/{answer_id}", params=params
        )
        return response.get("users", [])

    async def end_poll(self, channel_id: Snowflake, message_id: Snowflake) -> dict:
        """
        Immediately end a poll.

        Note: You can only end polls created by the current user.

        Args:
            channel_id: Channel containing the poll
            message_id: Message containing the poll

        Returns:
            Updated message object with ended poll
        """
        return await self.http.request("POST", f"/channels/{channel_id}/polls/{message_id}/expire")
