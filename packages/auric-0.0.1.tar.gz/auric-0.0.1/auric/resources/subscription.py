# Subscription API - Complete Implementation

from enum import IntEnum
from typing import List, Optional

from ..http import HTTPClient
from ..types import Snowflake


class SubscriptionStatus(IntEnum):
    ACTIVE = 0
    ENDING = 1
    INACTIVE = 2


class Subscription:
    def __init__(self, data: dict):
        self.id: Snowflake = data["id"]
        self.user_id: Snowflake = data["user_id"]
        self.sku_ids: List[Snowflake] = data["sku_ids"]
        self.entitlement_ids: List[Snowflake] = data["entitlement_ids"]
        self.current_period_start: str = data["current_period_start"]
        self.current_period_end: str = data["current_period_end"]
        self.status: SubscriptionStatus = SubscriptionStatus(data["status"])
        self.canceled_at: Optional[str] = data.get("canceled_at")


class SubscriptionAPI:
    def __init__(self, http: HTTPClient):
        self.http = http

    async def list_sku_subscriptions(
        self,
        sku_id: Snowflake,
        before: Optional[Snowflake] = None,
        after: Optional[Snowflake] = None,
        limit: int = 50,
        user_id: Optional[Snowflake] = None,
    ) -> List[Subscription]:
        params = {"limit": limit}
        if before:
            params["before"] = before
        if after:
            params["after"] = after
        if user_id:
            params["user_id"] = user_id

        data = await self.http.request("GET", f"/skus/{sku_id}/subscriptions", params=params)
        return [Subscription(s) for s in data]

    async def get_sku_subscription(
        self, sku_id: Snowflake, subscription_id: Snowflake
    ) -> Subscription:
        data = await self.http.request("GET", f"/skus/{sku_id}/subscriptions/{subscription_id}")
        return Subscription(data)
