# SKU API - Complete Implementation

from enum import IntEnum
from typing import List

from ..http import HTTPClient
from ..types import Snowflake


class SKUType(IntEnum):
    DURABLE = 2
    CONSUMABLE = 3
    SUBSCRIPTION = 5
    SUBSCRIPTION_GROUP = 6


class SKUFlags(IntEnum):
    AVAILABLE = 1 << 2
    GUILD_SUBSCRIPTION = 1 << 7
    USER_SUBSCRIPTION = 1 << 8


class SKU:
    def __init__(self, data: dict):
        self.id: Snowflake = data["id"]
        self.type: SKUType = SKUType(data["type"])
        self.application_id: Snowflake = data["application_id"]
        self.name: str = data["name"]
        self.slug: str = data["slug"]
        self.flags: int = data["flags"]


class SKUAPI:
    def __init__(self, http: HTTPClient):
        self.http = http

    async def list_skus(self, application_id: Snowflake) -> List[SKU]:
        data = await self.http.request("GET", f"/applications/{application_id}/skus")
        return [SKU(sku) for sku in data]
