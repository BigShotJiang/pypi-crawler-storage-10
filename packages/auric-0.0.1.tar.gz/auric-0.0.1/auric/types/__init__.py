"""
Auric Types - Type definitions and utilities
"""

from .snowflake import Snowflake

__all__ = ("Snowflake",)
