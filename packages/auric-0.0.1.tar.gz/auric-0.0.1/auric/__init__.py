"""
Auric - The Ultimate Discord API Wrapper

A modern, fast, and feature-complete Discord API wrapper for Python 3.11+
"""

__version__ = "0.0.1"
__author__ = "Auric Team"
__license__ = "MIT"

# Phase 5: Advanced Builders for better developer experience
from .builders import (
    ActionRowBuilder,
    ButtonBuilder,
    EmbedBuilder,
    FeedbackModalBuilder,
    ModalBuilder,
    ReportModalBuilder,
    SelectMenuBuilder,
    SuggestionModalBuilder,
)
from .builders.slash_command import MessageCommandBuilder, SlashCommandBuilder, UserCommandBuilder

# Phase 3: Collectors
from .collectors import (
    AwaitInteractionCollector,
    AwaitMessageCollector,
    AwaitReactionCollector,
    CollectorEndReason,
    ComponentCollector,
    InteractionCollector,
    MessageCollector,
    ReactionCollector,
)
from .collectors import filters as collector_filters
from .commands.context import Context
from .commands.decorators import command, cooldown, option, permission
from .components.button import Button, ButtonStyle
from .components.select import SelectOption, StringSelect
from .components.view import View
from .core.autoshard import AutoShardedClient, ShardManager
from .core.client import Client
from .core.intents import Intents
from .core.shard import Shard, ShardStatus

# Managers for resource management
from .managers import (
    ApplicationCommandManager,
    ChannelManager,
    MessageManager,
)
from .managers.guild_manager import GuildManager
from .managers.member_manager import MemberManager, RoleManager
from .models.attachment import Attachment
from .models.channel import Channel
from .models.color import Color
from .models.embed import Embed, EmbedAuthor, EmbedField, EmbedFooter
from .models.emoji import Emoji, PartialEmoji
from .models.guild import Guild
from .models.interaction import Interaction, InteractionType
from .models.interactions import (
    AutocompleteInteraction,
    BaseInteraction,
    CommandInteraction,
    ComponentInteraction,
    ModalSubmitInteraction,
)
from .models.invite import Invite
from .models.member import Member
from .models.message import Message
from .models.role import Role

# Phase 2: Slash Commands & Interactions
from .models.slash_command import CommandOption, MessageCommand, SlashCommand, UserCommand
from .models.sticker import Sticker, StickerItem
from .models.user import User
from .models.voice import VoiceRegion, VoiceState
from .types.interaction import (
    ApplicationCommandOptionType,
    ApplicationCommandType,
    InteractionCallbackType,
    TextInputStyle,
)
from .utils import format as fmt
from .utils import time

# Collection utility
from .utils.collection import Collection
from .utils.color import Color
from .utils.file import File
from .utils.health import HealthMonitor, HealthStatus, Metrics
from .utils.permissions import (
    PermissionCalculator,
    PermissionOverwrite,
    Permissions,
    check_permissions,
)

# Phase 3.5: Utilities
from .utils.snowflake import Snowflake

# Phase 4: Voice Support
from .voice import (
    AudioBuffer,
    BassBoostFilter,
    FFmpegAudio,
    FFmpegOpusAudio,
    FFmpegPCMAudio,
    PCMAudio,
    Playlist,
    VoiceClient,
    VolumeFilter,
    create_audio_source,
    create_playlist,
    is_ffmpeg_available,
)

__all__ = [
    # Core
    "Client",
    "Intents",
    "Shard",
    "ShardStatus",
    "AutoShardedClient",
    "ShardManager",
    # Models
    "Guild",
    "Channel",
    "User",
    "Message",
    "Embed",
    "EmbedField",
    "EmbedAuthor",
    "EmbedFooter",
    "Member",
    "Role",
    "Interaction",
    "InteractionType",
    "Color",
    "Emoji",
    "PartialEmoji",
    "Sticker",
    "StickerItem",
    "Attachment",
    "Invite",
    # Commands
    "Context",
    "command",
    "option",
    "permission",
    "cooldown",
    # Components
    "View",
    "Button",
    "ButtonStyle",
    "StringSelect",
    "SelectOption",
    # Phase 2: Slash Commands & Interactions
    "SlashCommand",
    "CommandOption",
    "UserCommand",
    "MessageCommand",
    "BaseInteraction",
    "CommandInteraction",
    "ComponentInteraction",
    "AutocompleteInteraction",
    "ModalSubmitInteraction",
    "ApplicationCommandType",
    "ApplicationCommandOptionType",
    "InteractionCallbackType",
    "TextInputStyle",
    # Builders
    "EmbedBuilder",
    "ButtonBuilder",
    "SelectMenuBuilder",
    "ActionRowBuilder",
    "ModalBuilder",
    "FeedbackModalBuilder",
    "ReportModalBuilder",
    "SuggestionModalBuilder",
    "SlashCommandBuilder",
    "UserCommandBuilder",
    "MessageCommandBuilder",
    # Managers
    "MessageManager",
    "ChannelManager",
    "ApplicationCommandManager",
    "GuildManager",
    "MemberManager",
    "RoleManager",
    # Utils
    "Collection",
    "File",
    # Phase 3: Collectors
    "MessageCollector",
    "ReactionCollector",
    "InteractionCollector",
    "ComponentCollector",
    "AwaitMessageCollector",
    "AwaitReactionCollector",
    "AwaitInteractionCollector",
    "CollectorEndReason",
    "collector_filters",
    # Phase 3.5: Utilities
    "Snowflake",
    "Color",
    "fmt",  # format module
    "time",  # time module
    "Permissions",
    "PermissionOverwrite",
    "PermissionCalculator",
    "check_permissions",
    "HealthMonitor",
    "HealthStatus",
    "Metrics",
    # Phase 4: Voice Support
    "VoiceClient",
    "VoiceState",
    "VoiceRegion",
    "PCMAudio",
    "FFmpegAudio",
    "FFmpegPCMAudio",
    "FFmpegOpusAudio",
    "AudioBuffer",
    "create_audio_source",
    "VolumeFilter",
    "BassBoostFilter",
    "Playlist",
    "create_playlist",
    "is_ffmpeg_available",
]
