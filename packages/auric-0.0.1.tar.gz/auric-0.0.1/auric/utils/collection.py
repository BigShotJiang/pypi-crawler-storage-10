"""
Collection - Enhanced dictionary for Discord data structures
Similar to discord.js Collection (extends JavaScript Map)
"""

from collections import OrderedDict
from typing import Any, Callable, Dict, Generic, Iterator, List, Optional, Tuple, TypeVar

K = TypeVar("K")
V = TypeVar("V")


class Collection(Generic[K, V]):
    """
    A powerful utility class that extends Python's dict with methods
    similar to JavaScript's Map and Array combined.

    This is the Python equivalent of discord.js Collection class.

    Example:
        ```python
        # Create a collection
        members = Collection()

        # Add items
        members.set(user_id, member)

        # Find items
        admin = members.find(lambda m: m.is_admin)

        # Filter items
        online = members.filter(lambda m: m.status == 'online')

        # Map items
        names = members.map(lambda m: m.name)
        ```
    """

    def __init__(self, data: Optional[Dict[K, V]] = None):
        self._data: OrderedDict[K, V] = OrderedDict(data or {})

    # Basic dict operations

    def set(self, key: K, value: V) -> "Collection[K, V]":
        """Set a key-value pair"""
        self._data[key] = value
        return self

    def get(self, key: K, default: Optional[V] = None) -> Optional[V]:
        """Get a value by key"""
        return self._data.get(key, default)

    def has(self, key: K) -> bool:
        """Check if key exists"""
        return key in self._data

    def delete(self, key: K) -> bool:
        """Delete a key and return True if it existed"""
        if key in self._data:
            del self._data[key]
            return True
        return False

    def clear(self) -> None:
        """Remove all items"""
        self._data.clear()

    @property
    def size(self) -> int:
        """Get collection size"""
        return len(self._data)

    # Array-like methods

    def first(self, count: Optional[int] = None) -> Optional[V | List[V]]:
        """Get first item(s)"""
        if not self._data:
            return None if count is None else []

        if count is None:
            return next(iter(self._data.values()))

        return list(self._data.values())[:count]

    def last(self, count: Optional[int] = None) -> Optional[V | List[V]]:
        """Get last item(s)"""
        if not self._data:
            return None if count is None else []

        values = list(self._data.values())
        if count is None:
            return values[-1]

        return values[-count:] if count > 0 else []

    def random(self, count: Optional[int] = None) -> Optional[V | List[V]]:
        """Get random item(s)"""
        import random as rand

        if not self._data:
            return None if count is None else []

        values = list(self._data.values())
        if count is None:
            return rand.choice(values)

        return rand.sample(values, min(count, len(values)))

    def at(self, index: int) -> Optional[V]:
        """Get item at index (supports negative indexing)"""
        try:
            return list(self._data.values())[index]
        except IndexError:
            return None

    # Functional methods

    def find(self, fn: Callable[[V, K], bool]) -> Optional[V]:
        """Find first item matching predicate"""
        for key, value in self._data.items():
            if fn(value, key):
                return value
        return None

    def filter(self, fn: Callable[[V, K], bool]) -> "Collection[K, V]":
        """Filter items matching predicate"""
        return Collection({k: v for k, v in self._data.items() if fn(v, k)})

    def map(self, fn: Callable[[V, K], Any]) -> List[Any]:
        """Map items to new list"""
        return [fn(value, key) for key, value in self._data.items()]

    def some(self, fn: Callable[[V, K], bool]) -> bool:
        """Check if at least one item matches predicate"""
        return any(fn(value, key) for key, value in self._data.items())

    def every(self, fn: Callable[[V, K], bool]) -> bool:
        """Check if all items match predicate"""
        return all(fn(value, key) for key, value in self._data.items())

    def reduce(self, fn: Callable[[Any, V, K], Any], initial: Any = None) -> Any:
        """Reduce collection to single value"""
        accumulator = initial
        for key, value in self._data.items():
            accumulator = fn(accumulator, value, key)
        return accumulator

    def each(self, fn: Callable[[V, K], None]) -> "Collection[K, V]":
        """Execute function for each item"""
        for key, value in self._data.items():
            fn(value, key)
        return self

    # Aggregation methods

    def concat(self, *others: "Collection[K, V]") -> "Collection[K, V]":
        """Concatenate with other collections"""
        result = Collection(self._data.copy())
        for other in others:
            result._data.update(other._data)
        return result

    def difference(self, other: "Collection[K, V]") -> "Collection[K, V]":
        """Get items not in other collection"""
        return Collection({k: v for k, v in self._data.items() if k not in other._data})

    def intersect(self, other: "Collection[K, V]") -> "Collection[K, V]":
        """Get items present in both collections"""
        return Collection({k: v for k, v in self._data.items() if k in other._data})

    def partition(
        self, fn: Callable[[V, K], bool]
    ) -> Tuple["Collection[K, V]", "Collection[K, V]"]:
        """Partition into two collections based on predicate"""
        passed = Collection()
        failed = Collection()

        for key, value in self._data.items():
            if fn(value, key):
                passed.set(key, value)
            else:
                failed.set(key, value)

        return passed, failed

    def sweep(self, fn: Callable[[V, K], bool]) -> int:
        """Remove items matching predicate, return count removed"""
        to_remove = [k for k, v in self._data.items() if fn(v, k)]
        for key in to_remove:
            del self._data[key]
        return len(to_remove)

    def tap(self, fn: Callable[["Collection[K, V]"], None]) -> "Collection[K, V]":
        """Execute function with collection, return collection"""
        fn(self)
        return self

    def clone(self) -> "Collection[K, V]":
        """Create shallow copy"""
        return Collection(self._data.copy())

    def sort(self, fn: Optional[Callable[[V, V], int]] = None) -> "Collection[K, V]":
        """Sort collection"""
        from functools import cmp_to_key

        if fn:
            sorted_items = sorted(self._data.items(), key=cmp_to_key(lambda a, b: fn(a[1], b[1])))
        else:
            sorted_items = sorted(self._data.items())

        self._data = OrderedDict(sorted_items)
        return self

    def sorted(self, fn: Optional[Callable[[V, V], int]] = None) -> "Collection[K, V]":
        """Return sorted copy"""
        return self.clone().sort(fn)

    # Python magic methods

    def __len__(self) -> int:
        return len(self._data)

    def __getitem__(self, key: K) -> V:
        return self._data[key]

    def __setitem__(self, key: K, value: V) -> None:
        self._data[key] = value

    def __delitem__(self, key: K) -> None:
        del self._data[key]

    def __contains__(self, key: K) -> bool:
        return key in self._data

    def __iter__(self) -> Iterator[K]:
        return iter(self._data)

    def __repr__(self) -> str:
        return f"Collection({dict(self._data)})"

    def __bool__(self) -> bool:
        return bool(self._data)

    # Dict-like methods for compatibility

    def keys(self) -> List[K]:
        """Get all keys"""
        return list(self._data.keys())

    def values(self) -> List[V]:
        """Get all values"""
        return list(self._data.values())

    def items(self) -> List[Tuple[K, V]]:
        """Get all items"""
        return list(self._data.items())

    def to_dict(self) -> Dict[K, V]:
        """Convert to regular dict"""
        return dict(self._data)

    @classmethod
    def from_dict(cls, data: Dict[K, V]) -> "Collection[K, V]":
        """Create from dict"""
        return cls(data)
