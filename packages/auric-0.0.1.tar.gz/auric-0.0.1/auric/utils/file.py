"""
File upload utilities for Discord API
"""

from __future__ import annotations

import mimetypes
import os
from pathlib import Path
from typing import Any, BinaryIO, Dict, List, Optional, Union


class File:
    """
    Represents a file to be uploaded to Discord

    Attributes:
        fp: File-like object or bytes
        filename: Name of the file
        description: Optional description
        spoiler: Whether file is a spoiler
    """

    def __init__(
        self,
        fp: Union[str, bytes, Path, BinaryIO],
        filename: Optional[str] = None,
        *,
        description: Optional[str] = None,
        spoiler: bool = False,
    ):
        """
        Initialize a file for upload

        Args:
            fp: File path, bytes, or file-like object
            filename: Name for the file (auto-detected if not provided)
            description: Optional description (max 1024 chars)
            spoiler: Whether to mark as spoiler
        """
        if isinstance(fp, (str, Path)):
            # File path
            self._path = Path(fp)
            self._fp: Optional[BinaryIO] = None
            self._data: Optional[bytes] = None
            self._close = True

            if filename is None:
                filename = self._path.name
        elif isinstance(fp, bytes):
            # Raw bytes
            self._path = None
            self._fp = None
            self._data = fp
            self._close = False

            if filename is None:
                filename = "unknown.bin"
        else:
            # File-like object
            self._path = None
            self._fp = fp
            self._data = None
            self._close = False

            if filename is None:
                # Try to get name from file object
                filename = getattr(fp, "name", "unknown.bin")
                if isinstance(filename, (str, Path)):
                    filename = Path(filename).name

        # Apply spoiler prefix if needed
        if spoiler and not filename.startswith("SPOILER_"):
            filename = f"SPOILER_{filename}"

        self.filename = filename
        self.description = description
        self.spoiler = spoiler
        self._closed = False

    @property
    def content_type(self) -> str:
        """Get MIME type for the file"""
        mime_type, _ = mimetypes.guess_type(self.filename)
        return mime_type or "application/octet-stream"

    def read(self) -> bytes:
        """Read file data"""
        if self._closed:
            raise ValueError("File is closed")

        if self._data is not None:
            return self._data

        if self._path is not None:
            with open(self._path, "rb") as f:
                return f.read()

        if self._fp is not None:
            # Remember position
            pos = self._fp.tell() if hasattr(self._fp, "tell") else None

            # Read data
            data = self._fp.read()

            # Reset position if possible
            if pos is not None and hasattr(self._fp, "seek"):
                self._fp.seek(pos)

            return data

        raise ValueError("No file data available")

    def reset(self) -> None:
        """Reset file pointer to beginning"""
        if self._fp is not None and hasattr(self._fp, "seek"):
            self._fp.seek(0)

    def close(self) -> None:
        """Close file if we opened it"""
        if not self._closed:
            if self._close and self._fp is not None:
                self._fp.close()
            self._closed = True

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def __del__(self):
        try:
            self.close()
        except:
            pass

    def to_dict(self, index: int) -> Dict[str, Any]:
        """
        Convert to attachment dict for payload_json

        Args:
            index: File index (snowflake placeholder)

        Returns:
            Attachment dictionary
        """
        data: Dict[str, Any] = {"id": index, "filename": self.filename}

        if self.description:
            data["description"] = self.description

        return data


def create_multipart_data(
    files: List[File], payload: Optional[Dict[str, Any]] = None
) -> tuple[Dict[str, Any], aiohttp.FormData]:
    """
    Create multipart/form-data for file upload

    Args:
        files: List of File objects
        payload: Optional JSON payload

    Returns:
        Tuple of (headers, form_data)
    """
    import aiohttp

    form_data = aiohttp.FormData()

    # Add JSON payload if provided
    if payload:
        # Build attachments array
        attachments = [file.to_dict(i) for i, file in enumerate(files)]
        payload["attachments"] = attachments

        # Add as payload_json
        form_data.add_field(
            "payload_json", orjson.dumps(payload).decode("utf-8"), content_type="application/json"
        )

    # Add files
    for i, file in enumerate(files):
        file_data = file.read()
        form_data.add_field(
            f"files[{i}]", file_data, filename=file.filename, content_type=file.content_type
        )

    return ({}, form_data)


# File size limits (in bytes)
FILE_SIZE_LIMIT_FREE = 10 * 1024 * 1024  # 10 MB
FILE_SIZE_LIMIT_NITRO_BASIC = 50 * 1024 * 1024  # 50 MB
FILE_SIZE_LIMIT_NITRO = 500 * 1024 * 1024  # 500 MB
FILE_SIZE_LIMIT_SERVER_BOOST_2 = 50 * 1024 * 1024  # 50 MB (Boost Level 2)
FILE_SIZE_LIMIT_SERVER_BOOST_3 = 100 * 1024 * 1024  # 100 MB (Boost Level 3)

# Request size limit
REQUEST_SIZE_LIMIT = 25 * 1024 * 1024  # 25 MB

# Allowed image extensions for embeds
EMBED_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".gif"}


def validate_file_size(file: File, max_size: int = FILE_SIZE_LIMIT_FREE) -> None:
    """
    Validate file size

    Args:
        file: File to validate
        max_size: Maximum file size in bytes

    Raises:
        ValueError: If file exceeds size limit
    """
    data = file.read()
    size = len(data)

    if size > max_size:
        max_mb = max_size / (1024 * 1024)
        actual_mb = size / (1024 * 1024)
        raise ValueError(
            f"File {file.filename} is {actual_mb:.2f}MB, " f"which exceeds the {max_mb:.2f}MB limit"
        )


def validate_total_size(files: List[File], max_size: int = REQUEST_SIZE_LIMIT) -> None:
    """
    Validate total request size

    Args:
        files: List of files
        max_size: Maximum total size in bytes

    Raises:
        ValueError: If total exceeds size limit
    """
    total = sum(len(file.read()) for file in files)

    if total > max_size:
        max_mb = max_size / (1024 * 1024)
        actual_mb = total / (1024 * 1024)
        raise ValueError(
            f"Total file size is {actual_mb:.2f}MB, "
            f"which exceeds the {max_mb:.2f}MB request limit"
        )


def is_image_for_embed(filename: str) -> bool:
    """
    Check if file is a valid image for embed

    Args:
        filename: File name

    Returns:
        True if valid embed image
    """
    ext = Path(filename).suffix.lower()
    return ext in EMBED_IMAGE_EXTENSIONS


import orjson
