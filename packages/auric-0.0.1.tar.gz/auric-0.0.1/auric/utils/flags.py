"""
Flags - Base class for Discord flag types

Provides a base implementation for Discord's flag/bitfield system.
"""

from __future__ import annotations

from typing import Any, Iterator


class BaseFlags:
    """
    Base class for Discord flags.

    Discord uses bitfields (flags) for various features like permissions,
    user flags, message flags, etc.
    """

    __slots__ = ("value",)

    def __init__(self, value: int = 0) -> None:
        """
        Initialize flags with a value.

        Parameters
        ----------
        value : int
            The integer value of the flags.
        """
        self.value = int(value)

    def __int__(self) -> int:
        return self.value

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} value={self.value}>"

    def __str__(self) -> str:
        return str(self.value)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, BaseFlags):
            return self.value == other.value
        if isinstance(other, int):
            return self.value == other
        return NotImplemented

    def __ne__(self, other: object) -> bool:
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    def __hash__(self) -> int:
        return hash(self.value)

    def __or__(self, other: BaseFlags) -> BaseFlags:
        """Bitwise OR operation."""
        if isinstance(other, BaseFlags):
            return self.__class__(self.value | other.value)
        return NotImplemented

    def __and__(self, other: BaseFlags) -> BaseFlags:
        """Bitwise AND operation."""
        if isinstance(other, BaseFlags):
            return self.__class__(self.value & other.value)
        return NotImplemented

    def __xor__(self, other: BaseFlags) -> BaseFlags:
        """Bitwise XOR operation."""
        if isinstance(other, BaseFlags):
            return self.__class__(self.value ^ other.value)
        return NotImplemented

    def __invert__(self) -> BaseFlags:
        """Bitwise NOT operation."""
        # Get all possible flags for this type
        max_value = (1 << self._get_max_bit()) - 1
        return self.__class__(max_value ^ self.value)

    def _get_max_bit(self) -> int:
        """Get the maximum bit position. Override in subclasses."""
        return 64

    def _has_flag(self, flag: int) -> bool:
        """Check if a specific flag is set."""
        return (self.value & flag) == flag

    def _set_flag(self, flag: int, value: bool) -> None:
        """Set or unset a specific flag."""
        if value:
            self.value |= flag
        else:
            self.value &= ~flag

    @classmethod
    def all(cls) -> BaseFlags:
        """Get all flags set."""
        max_value = (1 << 64) - 1
        return cls(max_value)

    @classmethod
    def none(cls) -> BaseFlags:
        """Get no flags set."""
        return cls(0)


class flag:
    """
    Decorator for flag properties.

    This is used to define flag properties on flag classes in a clean way.
    """

    def __init__(self, func):
        self.flag_value = None
        self.func = func
        self.__doc__ = func.__doc__

    def __set_name__(self, owner, name):
        # Automatically determine flag value from method name if not set
        pass

    def __get__(self, instance, owner):
        if instance is None:
            return self
        return instance._has_flag(self.flag_value or (1 << 0))

    def __set__(self, instance, value):
        instance._set_flag(self.flag_value or (1 << 0), bool(value))


__all__ = (
    "BaseFlags",
    "flag",
)
