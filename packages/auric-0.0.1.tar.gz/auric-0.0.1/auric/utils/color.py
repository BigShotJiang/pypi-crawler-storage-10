"""
Color utilities - Discord color conversion and management
"""

import re
from typing import Optional, Tuple, Union


class Color:
    """
    Color utility class for Discord embeds and roles

    Discord uses 24-bit RGB colors as integers.
    This class provides easy conversion and common colors.

    Example:
        ```python
        from auric.utils import Color

        # Create from RGB
        color = Color.from_rgb(255, 0, 0)

        # Create from hex
        color = Color.from_hex("#FF0000")

        # Use preset
        color = Color.red()

        # Get as int for Discord
        embed.color = color.value

        # Get as hex string
        print(color.to_hex())
        ```
    """

    def __init__(self, value: int):
        """
        Initialize a Color

        Args:
            value: Color as 24-bit integer (0x000000 to 0xFFFFFF)
        """
        if not 0 <= value <= 0xFFFFFF:
            raise ValueError(f"Color value must be 0-16777215, got {value}")
        self.value = value

    @classmethod
    def from_rgb(cls, r: int, g: int, b: int) -> "Color":
        """
        Create color from RGB values

        Args:
            r: Red (0-255)
            g: Green (0-255)
            b: Blue (0-255)

        Returns:
            Color instance
        """
        if not all(0 <= c <= 255 for c in (r, g, b)):
            raise ValueError("RGB values must be 0-255")
        return cls((r << 16) + (g << 8) + b)

    @classmethod
    def from_hex(cls, hex_str: str) -> "Color":
        """
        Create color from hex string

        Args:
            hex_str: Hex color (#RRGGBB or RRGGBB)

        Returns:
            Color instance
        """
        # Remove # if present
        hex_str = hex_str.lstrip("#")

        # Validate hex format
        if not re.match(r"^[0-9A-Fa-f]{6}$", hex_str):
            raise ValueError(f"Invalid hex color: {hex_str}")

        return cls(int(hex_str, 16))

    @classmethod
    def from_hsv(cls, h: float, s: float, v: float) -> "Color":
        """
        Create color from HSV values

        Args:
            h: Hue (0-360)
            s: Saturation (0-1)
            v: Value (0-1)

        Returns:
            Color instance
        """
        if not (0 <= h <= 360 and 0 <= s <= 1 and 0 <= v <= 1):
            raise ValueError("Invalid HSV values")

        c = v * s
        x = c * (1 - abs((h / 60) % 2 - 1))
        m = v - c

        if 0 <= h < 60:
            r, g, b = c, x, 0
        elif 60 <= h < 120:
            r, g, b = x, c, 0
        elif 120 <= h < 180:
            r, g, b = 0, c, x
        elif 180 <= h < 240:
            r, g, b = 0, x, c
        elif 240 <= h < 300:
            r, g, b = x, 0, c
        else:
            r, g, b = c, 0, x

        r = int((r + m) * 255)
        g = int((g + m) * 255)
        b = int((b + m) * 255)

        return cls.from_rgb(r, g, b)

    @property
    def r(self) -> int:
        """Get red component (0-255)"""
        return (self.value >> 16) & 0xFF

    @property
    def g(self) -> int:
        """Get green component (0-255)"""
        return (self.value >> 8) & 0xFF

    @property
    def b(self) -> int:
        """Get blue component (0-255)"""
        return self.value & 0xFF

    @property
    def rgb(self) -> Tuple[int, int, int]:
        """Get as RGB tuple"""
        return (self.r, self.g, self.b)

    def to_hex(self, with_hash: bool = True) -> str:
        """
        Convert to hex string

        Args:
            with_hash: Include # prefix

        Returns:
            Hex color string
        """
        hex_str = f"{self.value:06X}"
        return f"#{hex_str}" if with_hash else hex_str

    def to_rgb(self) -> Tuple[int, int, int]:
        """Get as RGB tuple"""
        return self.rgb

    def to_hsv(self) -> Tuple[float, float, float]:
        """Get as HSV tuple"""
        r, g, b = self.r / 255, self.g / 255, self.b / 255

        max_c = max(r, g, b)
        min_c = min(r, g, b)
        diff = max_c - min_c

        # Hue
        if diff == 0:
            h = 0
        elif max_c == r:
            h = (60 * ((g - b) / diff) + 360) % 360
        elif max_c == g:
            h = (60 * ((b - r) / diff) + 120) % 360
        else:
            h = (60 * ((r - g) / diff) + 240) % 360

        # Saturation
        s = 0 if max_c == 0 else diff / max_c

        # Value
        v = max_c

        return (h, s, v)

    def lighten(self, amount: float) -> "Color":
        """
        Lighten the color

        Args:
            amount: Amount to lighten (0-1)

        Returns:
            New lighter color
        """
        h, s, v = self.to_hsv()
        v = min(1.0, v + amount)
        return Color.from_hsv(h, s, v)

    def darken(self, amount: float) -> "Color":
        """
        Darken the color

        Args:
            amount: Amount to darken (0-1)

        Returns:
            New darker color
        """
        h, s, v = self.to_hsv()
        v = max(0.0, v - amount)
        return Color.from_hsv(h, s, v)

    def saturate(self, amount: float) -> "Color":
        """Increase saturation"""
        h, s, v = self.to_hsv()
        s = min(1.0, s + amount)
        return Color.from_hsv(h, s, v)

    def desaturate(self, amount: float) -> "Color":
        """Decrease saturation"""
        h, s, v = self.to_hsv()
        s = max(0.0, s - amount)
        return Color.from_hsv(h, s, v)

    def __str__(self) -> str:
        return self.to_hex()

    def __repr__(self) -> str:
        return f"<Color {self.to_hex()} rgb{self.rgb}>"

    def __int__(self) -> int:
        return self.value

    def __eq__(self, other) -> bool:
        if isinstance(other, Color):
            return self.value == other.value
        return self.value == other

    def __hash__(self) -> int:
        return hash(self.value)

    # Common Discord colors as class methods

    @classmethod
    def default(cls) -> "Color":
        """Discord default (blurple)"""
        return cls(0x5865F2)

    @classmethod
    def blurple(cls) -> "Color":
        """Discord blurple"""
        return cls(0x5865F2)

    @classmethod
    def green(cls) -> "Color":
        """Discord green"""
        return cls(0x57F287)

    @classmethod
    def yellow(cls) -> "Color":
        """Discord yellow"""
        return cls(0xFEE75C)

    @classmethod
    def fuchsia(cls) -> "Color":
        """Discord fuchsia/pink"""
        return cls(0xEB459E)

    @classmethod
    def red(cls) -> "Color":
        """Discord red"""
        return cls(0xED4245)

    @classmethod
    def white(cls) -> "Color":
        """White"""
        return cls(0xFFFFFF)

    @classmethod
    def black(cls) -> "Color":
        """Black"""
        return cls(0x000000)

    @classmethod
    def grey(cls) -> "Color":
        """Grey"""
        return cls(0x99AAB5)

    @classmethod
    def dark_grey(cls) -> "Color":
        """Dark grey"""
        return cls(0x2C2F33)

    @classmethod
    def darker_grey(cls) -> "Color":
        """Darker grey"""
        return cls(0x23272A)

    @classmethod
    def blue(cls) -> "Color":
        """Blue"""
        return cls(0x3498DB)

    @classmethod
    def dark_blue(cls) -> "Color":
        """Dark blue"""
        return cls(0x206694)

    @classmethod
    def purple(cls) -> "Color":
        """Purple"""
        return cls(0x9B59B6)

    @classmethod
    def magenta(cls) -> "Color":
        """Magenta"""
        return cls(0xE91E63)

    @classmethod
    def orange(cls) -> "Color":
        """Orange"""
        return cls(0xE67E22)

    @classmethod
    def gold(cls) -> "Color":
        """Gold"""
        return cls(0xF1C40F)

    @classmethod
    def teal(cls) -> "Color":
        """Teal"""
        return cls(0x1ABC9C)

    @classmethod
    def dark_teal(cls) -> "Color":
        """Dark teal"""
        return cls(0x11806A)

    @classmethod
    def random(cls) -> "Color":
        """Random color"""
        import random

        return cls(random.randint(0, 0xFFFFFF))


# Export commonly used names
default = Color.default
blurple = Color.blurple
green = Color.green
yellow = Color.yellow
red = Color.red
blue = Color.blue
purple = Color.purple
orange = Color.orange
