"""
Snowflake utilities - Parse Discord IDs and extract information

Discord uses Twitter Snowflakes for IDs - they encode timestamps!
"""

from datetime import datetime, timezone
from typing import Optional, Union

# Discord epoch (first second of 2015)
DISCORD_EPOCH = 1420070400000


class Snowflake:
    """
    Discord Snowflake utility class

    Discord uses Twitter Snowflakes for all IDs. They're 64-bit integers that
    encode the creation timestamp, worker ID, process ID, and increment.

    Structure (64 bits):
    - Bits 63-22: Milliseconds since Discord epoch (42 bits)
    - Bits 21-17: Internal worker ID (5 bits)
    - Bits 16-12: Internal process ID (5 bits)
    - Bits 11-0:  Increment (12 bits)

    Example:
        ```python
        from auric.utils import Snowflake

        # Parse a snowflake
        snowflake = Snowflake("1234567890123456789")
        print(snowflake.timestamp)
        print(snowflake.created_at)
        print(snowflake.worker_id)

        # Extract timestamp from ID
        timestamp = Snowflake.timestamp_from_id("1234567890123456789")

        # Check if valid
        if Snowflake.is_valid("1234567890123456789"):
            print("Valid snowflake!")
        ```
    """

    def __init__(self, snowflake: Union[str, int]):
        """
        Initialize a Snowflake

        Args:
            snowflake: Discord ID as string or int
        """
        self.id = int(snowflake)

        # Extract components
        self._timestamp = (self.id >> 22) + DISCORD_EPOCH
        self._worker_id = (self.id & 0x3E0000) >> 17
        self._process_id = (self.id & 0x1F000) >> 12
        self._increment = self.id & 0xFFF

    @property
    def timestamp(self) -> int:
        """Get the Unix timestamp in milliseconds"""
        return self._timestamp

    @property
    def created_at(self) -> datetime:
        """Get the creation datetime (UTC)"""
        return datetime.fromtimestamp(self._timestamp / 1000, tz=timezone.utc)

    @property
    def worker_id(self) -> int:
        """Get the internal worker ID"""
        return self._worker_id

    @property
    def process_id(self) -> int:
        """Get the internal process ID"""
        return self._process_id

    @property
    def increment(self) -> int:
        """Get the increment"""
        return self._increment

    def age(self) -> float:
        """Get age in seconds"""
        now = datetime.now(timezone.utc)
        return (now - self.created_at).total_seconds()

    def __str__(self) -> str:
        return str(self.id)

    def __repr__(self) -> str:
        return f"<Snowflake id={self.id} created={self.created_at.isoformat()}>"

    def __int__(self) -> int:
        return self.id

    def __eq__(self, other) -> bool:
        if isinstance(other, Snowflake):
            return self.id == other.id
        return self.id == int(other)

    def __hash__(self) -> int:
        return hash(self.id)

    # Static helper methods

    @staticmethod
    def is_valid(snowflake: Union[str, int]) -> bool:
        """
        Check if a snowflake is valid

        Args:
            snowflake: ID to check

        Returns:
            True if valid snowflake format
        """
        try:
            id_int = int(snowflake)
            # Must be positive and fit in 64 bits
            if id_int < 0 or id_int >= (1 << 63):
                return False

            # Extract timestamp and check if reasonable
            timestamp = (id_int >> 22) + DISCORD_EPOCH

            # Must be after Discord epoch and before now + 1 day
            now_ms = datetime.now(timezone.utc).timestamp() * 1000
            if timestamp < DISCORD_EPOCH or timestamp > (now_ms + 86400000):
                return False

            return True
        except (ValueError, TypeError):
            return False

    @staticmethod
    def timestamp_from_id(snowflake: Union[str, int]) -> int:
        """
        Extract Unix timestamp (ms) from snowflake

        Args:
            snowflake: Discord ID

        Returns:
            Unix timestamp in milliseconds
        """
        id_int = int(snowflake)
        return (id_int >> 22) + DISCORD_EPOCH

    @staticmethod
    def created_at_from_id(snowflake: Union[str, int]) -> datetime:
        """
        Extract creation datetime from snowflake

        Args:
            snowflake: Discord ID

        Returns:
            Creation datetime (UTC)
        """
        timestamp = Snowflake.timestamp_from_id(snowflake)
        return datetime.fromtimestamp(timestamp / 1000, tz=timezone.utc)

    @staticmethod
    def compare(a: Union[str, int], b: Union[str, int]) -> int:
        """
        Compare two snowflakes by age

        Args:
            a: First snowflake
            b: Second snowflake

        Returns:
            -1 if a is older, 0 if same age, 1 if b is older
        """
        a_int = int(a)
        b_int = int(b)

        if a_int < b_int:
            return -1
        elif a_int > b_int:
            return 1
        return 0

    @staticmethod
    def generate(timestamp: Optional[datetime] = None) -> int:
        """
        Generate a snowflake-like ID (for testing)

        Note: This doesn't include worker/process/increment, just timestamp!

        Args:
            timestamp: Optional timestamp (default: now)

        Returns:
            Snowflake ID
        """
        if timestamp is None:
            timestamp = datetime.now(timezone.utc)

        ms = int(timestamp.timestamp() * 1000)
        return (ms - DISCORD_EPOCH) << 22


def snowflake_time(snowflake: Union[str, int]) -> datetime:
    """
    Quick helper to get creation time from snowflake

    Example:
        ```python
        from auric.utils.snowflake import snowflake_time

        created = snowflake_time("1234567890123456789")
        print(f"Created at: {created}")
        ```
    """
    return Snowflake.created_at_from_id(snowflake)


def snowflake_age(snowflake: Union[str, int]) -> float:
    """
    Get age of a snowflake in seconds

    Example:
        ```python
        from auric.utils.snowflake import snowflake_age

        age = snowflake_age("1234567890123456789")
        print(f"Age: {age} seconds")
        ```
    """
    created = Snowflake.created_at_from_id(snowflake)
    now = datetime.now(timezone.utc)
    return (now - created).total_seconds()


def is_snowflake(value: Union[str, int]) -> bool:
    """
    Check if a value is a valid snowflake

    Example:
        ```python
        from auric.utils.snowflake import is_snowflake

        if is_snowflake("1234567890123456789"):
            print("Valid!")
        ```
    """
    return Snowflake.is_valid(value)
