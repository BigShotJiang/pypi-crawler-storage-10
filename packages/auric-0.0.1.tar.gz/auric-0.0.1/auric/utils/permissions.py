"""
Permission system for Discord

Handles permission calculations, overwrites, and role hierarchy.
"""

from enum import IntFlag
from typing import Any, Dict, List, Optional, Union


class Permissions(IntFlag):
    """
    Discord permission flags.

    Based on Discord's permission system:
    https://discord.com/developers/docs/topics/permissions
    """

    # General permissions
    CREATE_INSTANT_INVITE = 1 << 0
    KICK_MEMBERS = 1 << 1
    BAN_MEMBERS = 1 << 2
    ADMINISTRATOR = 1 << 3
    MANAGE_CHANNELS = 1 << 4
    MANAGE_GUILD = 1 << 5
    ADD_REACTIONS = 1 << 6
    VIEW_AUDIT_LOG = 1 << 7
    PRIORITY_SPEAKER = 1 << 8
    STREAM = 1 << 9
    VIEW_CHANNEL = 1 << 10
    SEND_MESSAGES = 1 << 11
    SEND_TTS_MESSAGES = 1 << 12
    MANAGE_MESSAGES = 1 << 13
    EMBED_LINKS = 1 << 14
    ATTACH_FILES = 1 << 15
    READ_MESSAGE_HISTORY = 1 << 16
    MENTION_EVERYONE = 1 << 17
    USE_EXTERNAL_EMOJIS = 1 << 18
    VIEW_GUILD_INSIGHTS = 1 << 19
    CONNECT = 1 << 20
    SPEAK = 1 << 21
    MUTE_MEMBERS = 1 << 22
    DEAFEN_MEMBERS = 1 << 23
    MOVE_MEMBERS = 1 << 24
    USE_VAD = 1 << 25
    CHANGE_NICKNAME = 1 << 26
    MANAGE_NICKNAMES = 1 << 27
    MANAGE_ROLES = 1 << 28
    MANAGE_WEBHOOKS = 1 << 29
    MANAGE_GUILD_EXPRESSIONS = 1 << 30  # Emojis & Stickers
    USE_APPLICATION_COMMANDS = 1 << 31
    REQUEST_TO_SPEAK = 1 << 32
    MANAGE_EVENTS = 1 << 33
    MANAGE_THREADS = 1 << 34
    CREATE_PUBLIC_THREADS = 1 << 35
    CREATE_PRIVATE_THREADS = 1 << 36
    USE_EXTERNAL_STICKERS = 1 << 37
    SEND_MESSAGES_IN_THREADS = 1 << 38
    USE_EMBEDDED_ACTIVITIES = 1 << 39
    MODERATE_MEMBERS = 1 << 40
    VIEW_CREATOR_MONETIZATION_ANALYTICS = 1 << 41
    USE_SOUNDBOARD = 1 << 42
    CREATE_GUILD_EXPRESSIONS = 1 << 43
    CREATE_EVENTS = 1 << 44
    USE_EXTERNAL_SOUNDS = 1 << 45
    SEND_VOICE_MESSAGES = 1 << 46
    SEND_POLLS = 1 << 49
    USE_EXTERNAL_APPS = 1 << 50

    @classmethod
    def none(cls) -> "Permissions":
        """No permissions"""
        return cls(0)

    @classmethod
    def all(cls) -> "Permissions":
        """All permissions"""
        return cls(sum(cls))

    @classmethod
    def all_channel(cls) -> "Permissions":
        """All channel-specific permissions"""
        return cls(
            cls.VIEW_CHANNEL
            | cls.MANAGE_CHANNELS
            | cls.ADD_REACTIONS
            | cls.SEND_MESSAGES
            | cls.SEND_TTS_MESSAGES
            | cls.MANAGE_MESSAGES
            | cls.EMBED_LINKS
            | cls.ATTACH_FILES
            | cls.READ_MESSAGE_HISTORY
            | cls.MENTION_EVERYONE
            | cls.USE_EXTERNAL_EMOJIS
            | cls.USE_EXTERNAL_STICKERS
            | cls.MANAGE_THREADS
            | cls.CREATE_PUBLIC_THREADS
            | cls.CREATE_PRIVATE_THREADS
            | cls.SEND_MESSAGES_IN_THREADS
            | cls.SEND_VOICE_MESSAGES
            | cls.SEND_POLLS
        )

    @classmethod
    def general(cls) -> "Permissions":
        """General server permissions"""
        return cls(
            cls.VIEW_CHANNEL
            | cls.SEND_MESSAGES
            | cls.EMBED_LINKS
            | cls.ATTACH_FILES
            | cls.ADD_REACTIONS
            | cls.USE_EXTERNAL_EMOJIS
            | cls.READ_MESSAGE_HISTORY
            | cls.CONNECT
            | cls.SPEAK
            | cls.USE_VAD
            | cls.CHANGE_NICKNAME
        )

    @classmethod
    def text(cls) -> "Permissions":
        """Text channel permissions"""
        return cls(
            cls.VIEW_CHANNEL
            | cls.SEND_MESSAGES
            | cls.EMBED_LINKS
            | cls.ATTACH_FILES
            | cls.ADD_REACTIONS
            | cls.USE_EXTERNAL_EMOJIS
            | cls.MENTION_EVERYONE
            | cls.READ_MESSAGE_HISTORY
            | cls.USE_APPLICATION_COMMANDS
            | cls.SEND_VOICE_MESSAGES
            | cls.SEND_POLLS
        )

    @classmethod
    def voice(cls) -> "Permissions":
        """Voice channel permissions"""
        return cls(
            cls.VIEW_CHANNEL
            | cls.CONNECT
            | cls.SPEAK
            | cls.STREAM
            | cls.USE_VAD
            | cls.USE_SOUNDBOARD
            | cls.USE_EXTERNAL_SOUNDS
            | cls.USE_EMBEDDED_ACTIVITIES
        )

    @classmethod
    def stage(cls) -> "Permissions":
        """Stage channel permissions"""
        return cls(cls.VIEW_CHANNEL | cls.CONNECT | cls.REQUEST_TO_SPEAK | cls.MANAGE_CHANNELS)

    def is_subset(self, other: "Permissions") -> bool:
        """Check if these permissions are a subset of another"""
        return (self.value & other.value) == self.value

    def is_superset(self, other: "Permissions") -> bool:
        """Check if these permissions are a superset of another"""
        return (self.value & other.value) == other.value

    def is_strict_subset(self, other: "Permissions") -> bool:
        """Check if strictly a subset"""
        return self.is_subset(other) and self != other

    def is_strict_superset(self, other: "Permissions") -> bool:
        """Check if strictly a superset"""
        return self.is_superset(other) and self != other

    def __contains__(self, permission: "Permissions") -> bool:
        """Check if permission is included"""
        return (self.value & permission.value) == permission.value


class PermissionOverwrite:
    """
    Permission overwrites for channels.

    Allows/denies specific permissions for roles or members in a channel.
    """

    def __init__(
        self, *, id: int, type: int, allow: int = 0, deny: int = 0  # 0 = role, 1 = member
    ):
        """
        Initialize a permission overwrite.

        Args:
            id: Role or member ID
            type: 0 for role, 1 for member
            allow: Allowed permissions bitfield
            deny: Denied permissions bitfield
        """
        self.id = id
        self.type = type
        self.allow = Permissions(allow)
        self.deny = Permissions(deny)

    @property
    def is_role(self) -> bool:
        """Check if overwrite is for a role"""
        return self.type == 0

    @property
    def is_member(self) -> bool:
        """Check if overwrite is for a member"""
        return self.type == 1

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format"""
        return {
            "id": str(self.id),
            "type": self.type,
            "allow": str(self.allow.value),
            "deny": str(self.deny.value),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PermissionOverwrite":
        """Create from API data"""
        return cls(
            id=int(data["id"]),
            type=data["type"],
            allow=int(data.get("allow", 0)),
            deny=int(data.get("deny", 0)),
        )

    def __repr__(self) -> str:
        type_name = "role" if self.is_role else "member"
        return f"<PermissionOverwrite id={self.id} type={type_name}>"


class PermissionCalculator:
    """
    Calculates effective permissions for a member in a channel.

    Implements Discord's permission resolution algorithm:
    https://discord.com/developers/docs/topics/permissions#permission-overwrites
    """

    @staticmethod
    def compute_base_permissions(member, guild) -> Permissions:
        """
        Compute base permissions from roles.

        Args:
            member: Member object
            guild: Guild object

        Returns:
            Base permissions
        """
        # Owner has all permissions
        if guild.owner_id == member.id:
            return Permissions.all()

        # Get @everyone role permissions
        everyone_role = next((r for r in guild.roles if r.id == guild.id), None)
        permissions = Permissions(everyone_role.permissions if everyone_role else 0)

        # Apply role permissions
        for role in member.roles:
            permissions |= Permissions(role.permissions)

        # Administrator grants all permissions
        if Permissions.ADMINISTRATOR in permissions:
            return Permissions.all()

        return permissions

    @staticmethod
    def compute_overwrites(base_permissions: Permissions, member, channel, guild) -> Permissions:
        """
        Apply channel permission overwrites.

        Args:
            base_permissions: Base permissions from roles
            member: Member object
            channel: Channel object
            guild: Guild object

        Returns:
            Final permissions with overwrites applied
        """
        # Administrator bypass
        if Permissions.ADMINISTRATOR in base_permissions:
            return Permissions.all()

        permissions = base_permissions
        overwrites = getattr(channel, "permission_overwrites", [])

        # Apply @everyone overrides
        everyone_overwrite = next((ow for ow in overwrites if ow.id == guild.id), None)
        if everyone_overwrite:
            permissions &= ~everyone_overwrite.deny
            permissions |= everyone_overwrite.allow

        # Apply role overrides
        allow = Permissions.none()
        deny = Permissions.none()

        for role in member.roles:
            role_overwrite = next(
                (ow for ow in overwrites if ow.id == role.id and ow.is_role), None
            )
            if role_overwrite:
                allow |= role_overwrite.allow
                deny |= role_overwrite.deny

        permissions &= ~deny
        permissions |= allow

        # Apply member-specific overrides
        member_overwrite = next(
            (ow for ow in overwrites if ow.id == member.id and ow.is_member), None
        )
        if member_overwrite:
            permissions &= ~member_overwrite.deny
            permissions |= member_overwrite.allow

        return permissions

    @classmethod
    def compute_permissions(cls, member, channel, guild) -> Permissions:
        """
        Compute final permissions for a member in a channel.

        Args:
            member: Member object
            channel: Channel object
            guild: Guild object

        Returns:
            Effective permissions
        """
        base = cls.compute_base_permissions(member, guild)
        return cls.compute_overwrites(base, member, channel, guild)

    @staticmethod
    def can_send_messages(permissions: Permissions, channel) -> bool:
        """Check if can send messages"""
        if Permissions.ADMINISTRATOR in permissions:
            return True

        if Permissions.VIEW_CHANNEL not in permissions:
            return False

        return Permissions.SEND_MESSAGES in permissions

    @staticmethod
    def can_manage_messages(permissions: Permissions) -> bool:
        """Check if can manage messages"""
        return (
            Permissions.ADMINISTRATOR in permissions or Permissions.MANAGE_MESSAGES in permissions
        )

    @staticmethod
    def can_manage_channels(permissions: Permissions) -> bool:
        """Check if can manage channels"""
        return (
            Permissions.ADMINISTRATOR in permissions or Permissions.MANAGE_CHANNELS in permissions
        )

    @staticmethod
    def can_kick_members(permissions: Permissions) -> bool:
        """Check if can kick members"""
        return Permissions.ADMINISTRATOR in permissions or Permissions.KICK_MEMBERS in permissions

    @staticmethod
    def can_ban_members(permissions: Permissions) -> bool:
        """Check if can ban members"""
        return Permissions.ADMINISTRATOR in permissions or Permissions.BAN_MEMBERS in permissions


def check_permissions(required: Permissions, actual: Permissions) -> bool:
    """
    Check if actual permissions satisfy required permissions.

    Args:
        required: Required permission flags
        actual: Actual permission flags

    Returns:
        True if all required permissions are present
    """
    if Permissions.ADMINISTRATOR in actual:
        return True

    return required in actual


def handle_implicit_permissions(permissions: Permissions) -> Permissions:
    """
    Add implicit permissions based on granted permissions.

    For example, SEND_MESSAGES implicitly requires VIEW_CHANNEL.

    Args:
        permissions: Current permissions

    Returns:
        Permissions with implicit permissions added
    """
    result = permissions

    # Sending messages requires viewing channel
    if Permissions.SEND_MESSAGES in permissions:
        result |= Permissions.VIEW_CHANNEL

    # Managing messages requires viewing channel
    if Permissions.MANAGE_MESSAGES in permissions:
        result |= Permissions.VIEW_CHANNEL

    # Speaking requires connecting
    if Permissions.SPEAK in permissions:
        result |= Permissions.CONNECT

    # Stage speaking requires connecting
    if Permissions.REQUEST_TO_SPEAK in permissions:
        result |= Permissions.CONNECT

    return result


__all__ = [
    "Permissions",
    "PermissionOverwrite",
    "PermissionCalculator",
    "check_permissions",
    "handle_implicit_permissions",
]
