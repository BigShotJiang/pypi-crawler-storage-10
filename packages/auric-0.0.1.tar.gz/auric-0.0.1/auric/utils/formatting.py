"""
Discord Utility Functions

Similar to discord.js util functions for formatting, escaping, etc.
"""

import re
from typing import Any, List, Optional, Union

# Markdown escaping functions


def escape_markdown(text: str, *, as_code_block: bool = False, as_code: bool = False) -> str:
    """
    Escape markdown formatting characters

    Args:
        text: Text to escape
        as_code_block: Escape for code block
        as_code: Escape for inline code

    Example:
        ```python
        escaped = escape_markdown("**bold** text")
        # Returns: "\\*\\*bold\\*\\* text"
        ```
    """
    if as_code_block:
        return text.replace("```", "\\`\\`\\`")
    if as_code:
        return text.replace("`", "\\`")

    # Escape all markdown characters
    return re.sub(r"([*_`~\\|>])", r"\\\1", text)


def escape_bold(text: str) -> str:
    """Escape bold markdown (* and **)"""
    return re.sub(r"\*", r"\\*", text)


def escape_italic(text: str) -> str:
    """Escape italic markdown (_ and *)"""
    return re.sub(r"([_*])", r"\\\1", text)


def escape_underline(text: str) -> str:
    """Escape underline markdown (__)"""
    return text.replace("__", "\\_\\_")


def escape_strikethrough(text: str) -> str:
    """Escape strikethrough markdown (~~)"""
    return text.replace("~~", "\\~\\~")


def escape_spoiler(text: str) -> str:
    """Escape spoiler markdown (||)"""
    return text.replace("||", "\\|\\|")


def escape_code_block(text: str) -> str:
    """Escape code block markdown (```)"""
    return text.replace("```", "\\`\\`\\`")


def escape_inline_code(text: str) -> str:
    """Escape inline code markdown (`)"""
    return text.replace("`", "\\`")


# Formatting functions


def bold(text: str) -> str:
    """Make text bold"""
    return f"**{text}**"


def italic(text: str) -> str:
    """Make text italic"""
    return f"*{text}*"


def underline(text: str) -> str:
    """Make text underlined"""
    return f"__{text}__"


def strikethrough(text: str) -> str:
    """Make text strikethrough"""
    return f"~~{text}~~"


def code(text: str) -> str:
    """Make text inline code"""
    return f"`{text}`"


def code_block(text: str, language: str = "") -> str:
    """Make text code block"""
    return f"```{language}\n{text}\n```"


def quote(text: str) -> str:
    """Make text quoted"""
    return "\n".join(f"> {line}" for line in text.split("\n"))


def block_quote(text: str) -> str:
    """Make text block quoted"""
    return f">>> {text}"


def spoiler(text: str) -> str:
    """Make text spoiler"""
    return f"||{text}||"


# Mention formatting


def user_mention(user_id: Union[int, str]) -> str:
    """Format user mention"""
    return f"<@{user_id}>"


def channel_mention(channel_id: Union[int, str]) -> str:
    """Format channel mention"""
    return f"<#{channel_id}>"


def role_mention(role_id: Union[int, str]) -> str:
    """Format role mention"""
    return f"<@&{role_id}>"


# Timestamp formatting


def timestamp(time: Union[int, float], style: str = "f") -> str:
    """
    Format Discord timestamp

    Args:
        time: Unix timestamp
        style: Format style
               t = Short time (16:20)
               T = Long time (16:20:30)
               d = Short date (20/04/2021)
               D = Long date (20 April 2021)
               f = Short date/time (default)
               F = Long date/time
               R = Relative time (2 months ago)
    """
    return f"<t:{int(time)}:{style}>"


# Emoji functions


def parse_emoji(text: str) -> Optional[dict]:
    """
    Parse emoji from text

    Returns dict with 'name', 'id', 'animated' or None

    Example:
        ```python
        # Custom emoji
        parse_emoji("<:name:123456>")
        # {'name': 'name', 'id': '123456', 'animated': False}

        # Unicode emoji
        parse_emoji("👍")
        # {'name': '👍', 'id': None, 'animated': False}
        ```
    """
    # Custom emoji pattern
    custom_pattern = r"<(a?):(\w+):(\d+)>"
    match = re.match(custom_pattern, text)

    if match:
        animated = match.group(1) == "a"
        name = match.group(2)
        emoji_id = match.group(3)
        return {"name": name, "id": emoji_id, "animated": animated}

    # Unicode emoji
    if text:
        return {"name": text, "id": None, "animated": False}

    return None


def format_emoji(name: str, id: Optional[Union[int, str]] = None, animated: bool = False) -> str:
    """
    Format emoji for Discord

    Example:
        ```python
        # Custom emoji
        format_emoji("name", 123456)
        # Returns: "<:name:123456>"

        # Animated emoji
        format_emoji("name", 123456, animated=True)
        # Returns: "<a:name:123456>"

        # Unicode emoji
        format_emoji("👍")
        # Returns: "👍"
        ```
    """
    if id is None:
        return name

    prefix = "a" if animated else ""
    return f"<{prefix}:{name}:{id}>"


# Color functions


def resolve_color(color: Union[int, str, tuple]) -> int:
    """
    Resolve color to integer

    Args:
        color: Color as int, hex string, or RGB tuple

    Example:
        ```python
        resolve_color(0xFF0000)  # 16711680
        resolve_color("#FF0000")  # 16711680
        resolve_color((255, 0, 0))  # 16711680
        ```
    """
    if isinstance(color, int):
        return color

    if isinstance(color, str):
        # Remove # if present
        color = color.lstrip("#")
        return int(color, 16)

    if isinstance(color, tuple) and len(color) == 3:
        r, g, b = color
        return (r << 16) + (g << 8) + b

    raise ValueError(f"Invalid color: {color}")


# URL functions


def format_user_avatar_url(
    user_id: Union[int, str], avatar_hash: str, *, format: str = "png", size: int = 1024
) -> str:
    """Format user avatar URL"""
    if avatar_hash.startswith("a_"):
        format = "gif"
    return f"https://cdn.discordapp.com/avatars/{user_id}/{avatar_hash}.{format}?size={size}"


def format_guild_icon_url(
    guild_id: Union[int, str], icon_hash: str, *, format: str = "png", size: int = 1024
) -> str:
    """Format guild icon URL"""
    if icon_hash.startswith("a_"):
        format = "gif"
    return f"https://cdn.discordapp.com/icons/{guild_id}/{icon_hash}.{format}?size={size}"


def format_emoji_url(emoji_id: Union[int, str], *, animated: bool = False, size: int = 128) -> str:
    """Format emoji URL"""
    format = "gif" if animated else "png"
    return f"https://cdn.discordapp.com/emojis/{emoji_id}.{format}?size={size}"


# Validation functions


def verify_string(
    data: Any,
    error: Optional[str] = None,
    *,
    allow_empty: bool = False,
    max_length: Optional[int] = None,
) -> str:
    """
    Verify and return string

    Args:
        data: Data to verify
        error: Custom error message
        allow_empty: Allow empty strings
        max_length: Maximum length
    """
    if not isinstance(data, str):
        raise TypeError(error or f"Expected string, got {type(data).__name__}")

    if not allow_empty and not data:
        raise ValueError(error or "String cannot be empty")

    if max_length and len(data) > max_length:
        raise ValueError(error or f"String too long (max {max_length})")

    return data


# Permission functions


def permissions_to_array(permissions: int) -> List[str]:
    """Convert permissions bitfield to array of permission names"""
    from ..core.permissions import Permissions

    perm_obj = Permissions(permissions)
    return [
        name
        for name, value in Permissions.__dict__.items()
        if isinstance(value, int) and perm_obj.has(value)
    ]


def array_to_permissions(permissions: List[str]) -> int:
    """Convert array of permission names to bitfield"""
    from ..core.permissions import Permissions

    result = 0
    for name in permissions:
        value = getattr(Permissions, name.upper(), None)
        if value:
            result |= value
    return result


__all__ = [
    # Escaping
    "escape_markdown",
    "escape_bold",
    "escape_italic",
    "escape_underline",
    "escape_strikethrough",
    "escape_spoiler",
    "escape_code_block",
    "escape_inline_code",
    # Formatting
    "bold",
    "italic",
    "underline",
    "strikethrough",
    "code",
    "code_block",
    "quote",
    "block_quote",
    "spoiler",
    # Mentions
    "user_mention",
    "channel_mention",
    "role_mention",
    # Timestamps
    "timestamp",
    # Emoji
    "parse_emoji",
    "format_emoji",
    # Colors
    "resolve_color",
    # URLs
    "format_user_avatar_url",
    "format_guild_icon_url",
    "format_emoji_url",
    # Validation
    "verify_string",
    # Permissions
    "permissions_to_array",
    "array_to_permissions",
]
