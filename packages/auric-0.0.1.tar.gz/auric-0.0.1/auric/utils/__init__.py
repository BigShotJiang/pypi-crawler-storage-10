"""Utilities for Auric"""

from . import format as fmt
from .collection import Collection
from .color import Color
from .converters import *
from .exceptions import *
from .file import *
from .formatters import *
from .helpers import *
from .pagination import *
from .snowflake import Snowflake, is_snowflake, snowflake_age
from .snowflake import snowflake_time as sf_time
from .time import *
from .validators import *

__all__ = [
    # Exceptions
    "AuricException",
    "HTTPException",
    "Forbidden",
    "NotFound",
    "RateLimited",
    "GatewayException",
    "InvalidToken",
    "ConnectionClosed",
    # File
    "File",
    # Helpers
    "snowflake_time",
    "time_snowflake",
    "parse_mention",
    "parse_emoji",
    "escape_markdown",
    "escape_mentions",
    "chunk_list",
    "get_user_avatar_url",
    "get_guild_icon_url",
    "resolve_invite",
    # Time
    "TimestampStyle",
    "format_timestamp",
    "parse_iso_timestamp",
    # Formatters
    "format_user_mention",
    "format_channel_mention",
    "format_role_mention",
    "format_emoji",
    "format_timestamp_mention",
    "format_slash_command",
    "codeblock",
    "inline_code",
    "bold",
    "italic",
    "underline",
    "strikethrough",
    "spoiler",
    "quote",
    "quote_block",
    # Validators
    "validate_token",
    "validate_snowflake",
    "validate_color",
    "validate_username",
    "validate_discriminator",
    "validate_invite_code",
    "validate_webhook_url",
    "is_valid_url",
    "is_valid_image_url",
    # Converters
    "to_snowflake",
    "to_bool",
    "to_color",
    "MemberConverter",
    "UserConverter",
    "ChannelConverter",
    "RoleConverter",
    "EmojiConverter",
    "ColorConverter",
    # Pagination
    "Paginator",
    "PaginatorView",
    "EmbedPaginator",
    "ListPaginator",
    # Phase 3.5: New Utilities
    "Snowflake",
    "snowflake_age",
    "is_snowflake",
    "Color",
    "fmt",  # format module
    "Collection",
]
