"""
Format utilities - Discord markdown and mention helpers
"""

from datetime import datetime
from typing import Union


def bold(text: str) -> str:
    """
    Make text bold

    Example:
        >>> bold("Hello")
        '**Hello**'
    """
    return f"**{text}**"


def italic(text: str) -> str:
    """
    Make text italic

    Example:
        >>> italic("Hello")
        '*Hello*'
    """
    return f"*{text}*"


def underline(text: str) -> str:
    """
    Underline text

    Example:
        >>> underline("Hello")
        '__Hello__'
    """
    return f"__{text}__"


def strikethrough(text: str) -> str:
    """
    Strike through text

    Example:
        >>> strikethrough("Hello")
        '~~Hello~~'
    """
    return f"~~{text}~~"


def code(text: str) -> str:
    """
    Format as inline code

    Example:
        >>> code("print('hello')")
        "`print('hello')`"
    """
    return f"`{text}`"


def codeblock(text: str, language: str = "") -> str:
    """
    Format as code block

    Args:
        text: Code to format
        language: Optional language for syntax highlighting

    Example:
        >>> codeblock("print('hello')", "python")
        "```python\\nprint('hello')\\n```"
    """
    return f"```{language}\n{text}\n```"


def quote(text: str) -> str:
    """
    Format as quote

    Example:
        >>> quote("Hello")
        '> Hello'
    """
    return f"> {text}"


def block_quote(text: str) -> str:
    """
    Format as block quote

    Example:
        >>> block_quote("Hello\\nWorld")
        '>>> Hello\\nWorld'
    """
    return f">>> {text}"


def spoiler(text: str) -> str:
    """
    Format as spoiler

    Example:
        >>> spoiler("Snape kills Dumbledore")
        '||Snape kills Dumbledore||'
    """
    return f"||{text}||"


def hyperlink(text: str, url: str) -> str:
    """
    Create a hyperlink

    Example:
        >>> hyperlink("Google", "https://google.com")
        '[Google](https://google.com)'
    """
    return f"[{text}]({url})"


def masked_link(text: str, url: str) -> str:
    """
    Create a masked link (hides embed)

    Example:
        >>> masked_link("Click here", "https://example.com")
        '[Click here](<https://example.com>)'
    """
    return f"[{text}](<{url}>)"


# Mention formatting


def mention_user(user_id: Union[str, int]) -> str:
    """
    Format user mention

    Example:
        >>> mention_user("123456789")
        '<@123456789>'
    """
    return f"<@{user_id}>"


def mention_channel(channel_id: Union[str, int]) -> str:
    """
    Format channel mention

    Example:
        >>> mention_channel("123456789")
        '<#123456789>'
    """
    return f"<#{channel_id}>"


def mention_role(role_id: Union[str, int]) -> str:
    """
    Format role mention

    Example:
        >>> mention_role("123456789")
        '<@&123456789>'
    """
    return f"<@&{role_id}>"


def mention_emoji(name: str, emoji_id: Union[str, int], animated: bool = False) -> str:
    """
    Format custom emoji

    Example:
        >>> mention_emoji("smile", "123456789")
        '<:smile:123456789>'
        >>> mention_emoji("smile", "123456789", animated=True)
        '<a:smile:123456789>'
    """
    prefix = "a" if animated else ""
    return f"<{prefix}:{name}:{emoji_id}>"


def slash_command(name: str, command_id: Union[str, int]) -> str:
    """
    Format slash command mention

    Example:
        >>> slash_command("help", "123456789")
        '</help:123456789>'
    """
    return f"</{name}:{command_id}>"


# Timestamp formatting


def timestamp(dt: Union[datetime, int], style: str = "f") -> str:
    """
    Format Discord timestamp

    Args:
        dt: datetime object or Unix timestamp
        style: Format style:
            - 't': Short time (e.g., 16:20)
            - 'T': Long time (e.g., 16:20:30)
            - 'd': Short date (e.g., 20/04/2021)
            - 'D': Long date (e.g., 20 April 2021)
            - 'f': Short date/time (default)
            - 'F': Long date/time
            - 'R': Relative time (e.g., 2 hours ago)

    Example:
        >>> timestamp(datetime.now())
        '<t:1234567890:f>'
        >>> timestamp(datetime.now(), 'R')
        '<t:1234567890:R>'
    """
    if isinstance(dt, datetime):
        unix_time = int(dt.timestamp())
    else:
        unix_time = int(dt)

    return f"<t:{unix_time}:{style}>"


def timestamp_short_time(dt: Union[datetime, int]) -> str:
    """Short time format (16:20)"""
    return timestamp(dt, "t")


def timestamp_long_time(dt: Union[datetime, int]) -> str:
    """Long time format (16:20:30)"""
    return timestamp(dt, "T")


def timestamp_short_date(dt: Union[datetime, int]) -> str:
    """Short date format (20/04/2021)"""
    return timestamp(dt, "d")


def timestamp_long_date(dt: Union[datetime, int]) -> str:
    """Long date format (20 April 2021)"""
    return timestamp(dt, "D")


def timestamp_short_datetime(dt: Union[datetime, int]) -> str:
    """Short date/time format"""
    return timestamp(dt, "f")


def timestamp_long_datetime(dt: Union[datetime, int]) -> str:
    """Long date/time format"""
    return timestamp(dt, "F")


def timestamp_relative(dt: Union[datetime, int]) -> str:
    """Relative time format (2 hours ago)"""
    return timestamp(dt, "R")


# Utility functions


def escape_markdown(text: str) -> str:
    """
    Escape markdown characters

    Example:
        >>> escape_markdown("**bold**")
        '\\\\*\\\\*bold\\\\*\\\\*'
    """
    chars = ["\\", "*", "_", "~", "|", ">", "`"]
    for char in chars:
        text = text.replace(char, f"\\{char}")
    return text


def escape_mentions(text: str) -> str:
    """
    Escape mentions (prevent pinging)

    Example:
        >>> escape_mentions("<@123456789>")
        '<@123456789>'  # Won't ping
    """
    return text.replace("@", "@\u200b")


def progress_bar(
    current: int, total: int, length: int = 10, filled: str = "█", empty: str = "░"
) -> str:
    """
    Create a progress bar

    Args:
        current: Current progress
        total: Total amount
        length: Bar length in characters
        filled: Character for filled portion
        empty: Character for empty portion

    Example:
        >>> progress_bar(7, 10)
        '███████░░░ 70%'
    """
    if total == 0:
        percent = 0
    else:
        percent = (current / total) * 100

    filled_length = int(length * current / total) if total > 0 else 0
    bar = filled * filled_length + empty * (length - filled_length)

    return f"{bar} {percent:.0f}%"


def table(headers: list[str], rows: list[list[str]]) -> str:
    """
    Create a simple text table

    Example:
        >>> table(['Name', 'Age'], [['Alice', '25'], ['Bob', '30']])
        'Name  | Age\\n------|----\\nAlice | 25\\nBob   | 30'
    """
    # Calculate column widths
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(str(cell)))

    # Build table
    lines = []

    # Header
    header = " | ".join(h.ljust(w) for h, w in zip(headers, widths))
    lines.append(header)

    # Separator
    separator = "-|-".join("-" * w for w in widths)
    lines.append(separator)

    # Rows
    for row in rows:
        line = " | ".join(str(cell).ljust(w) for cell, w in zip(row, widths))
        lines.append(line)

    return "\n".join(lines)


def truncate(text: str, max_length: int, suffix: str = "...") -> str:
    """
    Truncate text to max length

    Example:
        >>> truncate("Hello World", 8)
        'Hello...'
    """
    if len(text) <= max_length:
        return text
    return text[: max_length - len(suffix)] + suffix


def pluralize(count: int, singular: str, plural: str = None) -> str:
    """
    Pluralize a word based on count

    Example:
        >>> pluralize(1, "apple")
        '1 apple'
        >>> pluralize(5, "apple")
        '5 apples'
        >>> pluralize(2, "box", "boxes")
        '2 boxes'
    """
    if plural is None:
        plural = singular + "s"

    word = singular if count == 1 else plural
    return f"{count} {word}"


# List formatting


def list_items(items: list[str], numbered: bool = False) -> str:
    """
    Format a list

    Example:
        >>> list_items(['Apple', 'Banana'])
        '• Apple\\n• Banana'
        >>> list_items(['Apple', 'Banana'], numbered=True)
        '1. Apple\\n2. Banana'
    """
    if numbered:
        return "\n".join(f"{i+1}. {item}" for i, item in enumerate(items))
    else:
        return "\n".join(f"• {item}" for item in items)


def columns(items: list[str], columns: int = 2) -> str:
    """
    Format items in columns

    Example:
        >>> columns(['A', 'B', 'C', 'D'], 2)
        'A  |  C\\nB  |  D'
    """
    rows = (len(items) + columns - 1) // columns
    result = []

    for row in range(rows):
        row_items = []
        for col in range(columns):
            idx = row + col * rows
            if idx < len(items):
                row_items.append(items[idx])
        result.append("  |  ".join(row_items))

    return "\n".join(result)
