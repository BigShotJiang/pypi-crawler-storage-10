"""Formatters for Discord objects and data"""

from typing import List, Optional, Union

from ..models.channel import Channel
from ..models.guild import Guild
from ..models.role import Role
from ..models.user import User

__all__ = [
    "format_user_mention",
    "format_channel_mention",
    "format_role_mention",
    "format_emoji",
    "format_timestamp_mention",
    "format_slash_command",
    "codeblock",
    "inline_code",
    "bold",
    "italic",
    "underline",
    "strikethrough",
    "spoiler",
    "quote",
    "quote_block",
]


def format_user_mention(user: Union[User, int]) -> str:
    """
    Format a user mention.

    Args:
        user: User object or user ID

    Returns:
        str: Formatted mention string
    """
    user_id = user.id if hasattr(user, "id") else user
    return f"<@{user_id}>"


def format_channel_mention(channel: Union[Channel, int]) -> str:
    """
    Format a channel mention.

    Args:
        channel: Channel object or channel ID

    Returns:
        str: Formatted mention string
    """
    channel_id = channel.id if hasattr(channel, "id") else channel
    return f"<#{channel_id}>"


def format_role_mention(role: Union[Role, int]) -> str:
    """
    Format a role mention.

    Args:
        role: Role object or role ID

    Returns:
        str: Formatted mention string
    """
    role_id = role.id if hasattr(role, "id") else role
    return f"<@&{role_id}>"


def format_emoji(name: str, emoji_id: int, animated: bool = False) -> str:
    """
    Format a custom emoji.

    Args:
        name: Emoji name
        emoji_id: Emoji ID
        animated: Whether the emoji is animated

    Returns:
        str: Formatted emoji string
    """
    prefix = "a" if animated else ""
    return f"<{prefix}:{name}:{emoji_id}>"


def format_timestamp_mention(timestamp: int, style: str = "f") -> str:
    """
    Format a timestamp mention.

    Args:
        timestamp: Unix timestamp
        style: Display style (t, T, d, D, f, F, R)

    Returns:
        str: Formatted timestamp string
    """
    return f"<t:{timestamp}:{style}>"


def format_slash_command(
    name: str,
    command_id: int,
    subcommand: Optional[str] = None,
    subcommand_group: Optional[str] = None,
) -> str:
    """
    Format a slash command mention.

    Args:
        name: Command name
        command_id: Command ID
        subcommand: Optional subcommand name
        subcommand_group: Optional subcommand group name

    Returns:
        str: Formatted command mention
    """
    parts = [name]
    if subcommand_group:
        parts.append(subcommand_group)
    if subcommand:
        parts.append(subcommand)

    cmd_name = " ".join(parts)
    return f"</{cmd_name}:{command_id}>"


def codeblock(content: str, language: str = "") -> str:
    """
    Format text as a code block.

    Args:
        content: The content to format
        language: Optional language for syntax highlighting

    Returns:
        str: Formatted code block
    """
    return f"```{language}\n{content}\n```"


def inline_code(content: str) -> str:
    """Format text as inline code"""
    return f"`{content}`"


def bold(content: str) -> str:
    """Format text as bold"""
    return f"**{content}**"


def italic(content: str) -> str:
    """Format text as italic"""
    return f"*{content}*"


def underline(content: str) -> str:
    """Format text as underlined"""
    return f"__{content}__"


def strikethrough(content: str) -> str:
    """Format text as strikethrough"""
    return f"~~{content}~~"


def spoiler(content: str) -> str:
    """Format text as spoiler"""
    return f"||{content}||"


def quote(content: str) -> str:
    """Format text as quote"""
    return f"> {content}"


def quote_block(content: str) -> str:
    """Format text as quote block"""
    lines = content.split("\n")
    return "\n".join(f"> {line}" for line in lines)


def create_progress_bar(
    current: int, total: int, length: int = 10, filled: str = "█", empty: str = "░"
) -> str:
    """
    Create a progress bar.

    Args:
        current: Current value
        total: Total value
        length: Length of the bar
        filled: Character for filled portion
        empty: Character for empty portion

    Returns:
        str: Progress bar string
    """
    if total == 0:
        percentage = 0
    else:
        percentage = min(current / total, 1.0)

    filled_length = int(length * percentage)
    bar = filled * filled_length + empty * (length - filled_length)
    return f"{bar} {int(percentage * 100)}%"


def truncate(text: str, max_length: int, suffix: str = "...") -> str:
    """
    Truncate text to maximum length.

    Args:
        text: The text to truncate
        max_length: Maximum length
        suffix: Suffix to add if truncated

    Returns:
        str: Truncated text
    """
    if len(text) <= max_length:
        return text

    return text[: max_length - len(suffix)] + suffix


def format_list(items: List[str], conjunction: str = "and") -> str:
    """
    Format a list of items as a string.

    Args:
        items: List of items
        conjunction: Word to use before last item

    Returns:
        str: Formatted list

    Examples:
        >>> format_list(['apple', 'banana', 'orange'])
        'apple, banana, and orange'
    """
    if not items:
        return ""
    if len(items) == 1:
        return items[0]
    if len(items) == 2:
        return f"{items[0]} {conjunction} {items[1]}"

    return f'{", ".join(items[:-1])}, {conjunction} {items[-1]}'
