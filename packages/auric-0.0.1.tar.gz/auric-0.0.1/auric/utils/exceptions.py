"""
Exception classes for Auric
"""

from typing import Any, Dict, Optional, Union

import aiohttp


class AuricException(Exception):
    """Base exception for all Auric errors"""

    pass


class HTTPException(AuricException):
    """Exception raised when an HTTP request fails"""

    def __init__(self, response: Optional[aiohttp.ClientResponse], data: Any):
        self.response = response
        self.status = response.status if response else None
        self.code = data.get("code", 0) if isinstance(data, dict) else 0
        self.text = data.get("message", str(data)) if data else "Unknown error"

        super().__init__(f"{self.status} {self.text} (error code: {self.code})")


class Forbidden(HTTPException):
    """Exception raised for 403 Forbidden errors"""

    pass


class NotFound(HTTPException):
    """Exception raised for 404 Not Found errors"""

    pass


class DiscordServerError(HTTPException):
    """Exception raised for 5xx server errors"""

    pass


class RateLimited(AuricException):
    """Exception raised when rate limited"""

    def __init__(self, retry_after: float):
        self.retry_after = retry_after
        super().__init__(f"Rate limited. Retry after {retry_after:.2f} seconds")


class GatewayException(AuricException):
    """Exception raised for gateway errors"""

    pass


class ConnectionClosed(GatewayException):
    """Exception raised when gateway connection is closed"""

    def __init__(self, code: int, reason: str):
        self.code = code
        self.reason = reason
        super().__init__(f"Gateway connection closed with code {code}: {reason}")


class PrivilegedIntentsRequired(GatewayException):
    """Exception raised when privileged intents are not enabled"""

    pass


class InvalidToken(AuricException):
    """Exception raised when token is invalid"""

    pass


class LoginFailure(AuricException):
    """Exception raised when login fails"""

    pass


class ShardConnectionError(GatewayException):
    """Exception raised when shard connection fails"""

    pass
