"""
Health monitoring and metrics for production deployments
"""

import asyncio
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional


class HealthStatus(Enum):
    """Health check status"""

    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


@dataclass
class HealthCheck:
    """Individual health check result"""

    name: str
    status: HealthStatus
    message: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.utcnow)
    latency_ms: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Metrics:
    """Bot performance metrics"""

    # Gateway metrics
    gateway_latency_ms: float = 0.0
    gateway_reconnects: int = 0
    gateway_resumes: int = 0
    gateway_events_received: int = 0

    # HTTP metrics
    http_requests: int = 0
    http_errors: int = 0
    http_rate_limits: int = 0
    http_avg_latency_ms: float = 0.0

    # Bot metrics
    guilds: int = 0
    users: int = 0
    channels: int = 0
    commands_executed: int = 0
    errors: int = 0

    # System metrics
    uptime_seconds: float = 0.0
    memory_usage_mb: float = 0.0
    cpu_percent: float = 0.0

    # Cache metrics
    cached_messages: int = 0
    cached_guilds: int = 0
    cached_users: int = 0
    cached_channels: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "gateway": {
                "latency_ms": self.gateway_latency_ms,
                "reconnects": self.gateway_reconnects,
                "resumes": self.gateway_resumes,
                "events_received": self.gateway_events_received,
            },
            "http": {
                "requests": self.http_requests,
                "errors": self.http_errors,
                "rate_limits": self.http_rate_limits,
                "avg_latency_ms": self.http_avg_latency_ms,
            },
            "bot": {
                "guilds": self.guilds,
                "users": self.users,
                "channels": self.channels,
                "commands_executed": self.commands_executed,
                "errors": self.errors,
            },
            "system": {
                "uptime_seconds": self.uptime_seconds,
                "memory_usage_mb": self.memory_usage_mb,
                "cpu_percent": self.cpu_percent,
            },
            "cache": {
                "messages": self.cached_messages,
                "guilds": self.cached_guilds,
                "users": self.cached_users,
                "channels": self.cached_channels,
            },
        }


class HealthMonitor:
    """
    Production health monitoring system.

    Tracks bot health, performance metrics, and provides
    monitoring endpoints for deployment infrastructure.

    Example:
        ```python
        bot = Client(intents=intents)
        monitor = HealthMonitor(bot)

        # Check health
        health = await monitor.check_health()
        print(health['status'])  # healthy/degraded/unhealthy

        # Get metrics
        metrics = monitor.get_metrics()
        print(f"Latency: {metrics.gateway_latency_ms}ms")

        # Start monitoring
        await monitor.start()
        ```
    """

    def __init__(
        self,
        client,
        *,
        check_interval: int = 60,
        max_history: int = 100,
        unhealthy_latency: float = 1000.0,
        degraded_latency: float = 500.0,
    ):
        """
        Initialize health monitor.

        Args:
            client: Bot client instance
            check_interval: Seconds between health checks
            max_history: Max health check history to keep
            unhealthy_latency: Latency threshold for unhealthy (ms)
            degraded_latency: Latency threshold for degraded (ms)
        """
        self.client = client
        self.check_interval = check_interval
        self.max_history = max_history
        self.unhealthy_latency = unhealthy_latency
        self.degraded_latency = degraded_latency

        # State
        self.start_time = time.time()
        self.health_history: deque = deque(maxlen=max_history)
        self.metrics = Metrics()
        self.is_running = False
        self._monitor_task: Optional[asyncio.Task] = None

        # Latency tracking
        self._latency_samples: deque = deque(maxlen=100)

    def record_gateway_event(self) -> None:
        """Record a gateway event received"""
        self.metrics.gateway_events_received += 1

    def record_gateway_latency(self, latency_ms: float) -> None:
        """Record gateway latency sample"""
        self.metrics.gateway_latency_ms = latency_ms
        self._latency_samples.append(latency_ms)

    def record_gateway_reconnect(self) -> None:
        """Record gateway reconnection"""
        self.metrics.gateway_reconnects += 1

    def record_gateway_resume(self) -> None:
        """Record gateway resume"""
        self.metrics.gateway_resumes += 1

    def record_http_request(self, latency_ms: float, is_error: bool = False) -> None:
        """Record HTTP request"""
        self.metrics.http_requests += 1
        if is_error:
            self.metrics.http_errors += 1

        # Update average latency
        total = self.metrics.http_avg_latency_ms * (self.metrics.http_requests - 1)
        self.metrics.http_avg_latency_ms = (total + latency_ms) / self.metrics.http_requests

    def record_rate_limit(self) -> None:
        """Record rate limit hit"""
        self.metrics.http_rate_limits += 1

    def record_command(self) -> None:
        """Record command execution"""
        self.metrics.commands_executed += 1

    def record_error(self) -> None:
        """Record error"""
        self.metrics.errors += 1

    def update_counts(self) -> None:
        """Update cached entity counts"""
        if hasattr(self.client, "guilds"):
            self.metrics.guilds = len(self.client.guilds)

        if hasattr(self.client, "users"):
            self.metrics.users = len(self.client.users)

        if hasattr(self.client, "channels"):
            self.metrics.channels = len(self.client.channels)

        if hasattr(self.client, "cached_messages"):
            self.metrics.cached_messages = len(self.client.cached_messages)

    def update_system_metrics(self) -> None:
        """Update system resource metrics"""
        import os

        import psutil

        self.metrics.uptime_seconds = time.time() - self.start_time

        try:
            process = psutil.Process(os.getpid())
            self.metrics.memory_usage_mb = process.memory_info().rss / 1024 / 1024
            self.metrics.cpu_percent = process.cpu_percent()
        except:
            pass

    async def check_gateway_health(self) -> HealthCheck:
        """Check gateway connection health"""
        if not self.client.is_ready:
            return HealthCheck(
                name="gateway", status=HealthStatus.UNHEALTHY, message="Gateway not connected"
            )

        latency = self.metrics.gateway_latency_ms

        if latency > self.unhealthy_latency:
            status = HealthStatus.UNHEALTHY
            message = f"High latency: {latency:.0f}ms"
        elif latency > self.degraded_latency:
            status = HealthStatus.DEGRADED
            message = f"Elevated latency: {latency:.0f}ms"
        else:
            status = HealthStatus.HEALTHY
            message = f"Latency: {latency:.0f}ms"

        return HealthCheck(name="gateway", status=status, message=message, latency_ms=latency)

    async def check_http_health(self) -> HealthCheck:
        """Check HTTP client health"""
        if not self.client._http:
            return HealthCheck(
                name="http", status=HealthStatus.UNHEALTHY, message="HTTP client not initialized"
            )

        # Check error rate
        total_requests = self.metrics.http_requests
        if total_requests > 0:
            error_rate = self.metrics.http_errors / total_requests

            if error_rate > 0.1:  # >10% errors
                return HealthCheck(
                    name="http",
                    status=HealthStatus.UNHEALTHY,
                    message=f"High error rate: {error_rate:.1%}",
                )
            elif error_rate > 0.05:  # >5% errors
                return HealthCheck(
                    name="http",
                    status=HealthStatus.DEGRADED,
                    message=f"Elevated error rate: {error_rate:.1%}",
                )

        return HealthCheck(
            name="http",
            status=HealthStatus.HEALTHY,
            message=f"{total_requests} requests, {self.metrics.http_errors} errors",
        )

    async def check_memory_health(self) -> HealthCheck:
        """Check memory usage"""
        memory_mb = self.metrics.memory_usage_mb

        if memory_mb > 1000:  # >1GB
            status = HealthStatus.UNHEALTHY
            message = f"High memory usage: {memory_mb:.0f}MB"
        elif memory_mb > 500:  # >500MB
            status = HealthStatus.DEGRADED
            message = f"Elevated memory usage: {memory_mb:.0f}MB"
        else:
            status = HealthStatus.HEALTHY
            message = f"Memory usage: {memory_mb:.0f}MB"

        return HealthCheck(
            name="memory", status=status, message=message, metadata={"memory_mb": memory_mb}
        )

    async def check_health(self) -> Dict[str, Any]:
        """
        Perform comprehensive health check.

        Returns:
            Health check results with overall status
        """
        # Update metrics
        self.update_counts()
        self.update_system_metrics()

        # Run checks
        checks = [
            await self.check_gateway_health(),
            await self.check_http_health(),
            await self.check_memory_health(),
        ]

        # Determine overall status
        statuses = [c.status for c in checks]
        if HealthStatus.UNHEALTHY in statuses:
            overall_status = HealthStatus.UNHEALTHY
        elif HealthStatus.DEGRADED in statuses:
            overall_status = HealthStatus.DEGRADED
        elif HealthStatus.UNKNOWN in statuses:
            overall_status = HealthStatus.UNKNOWN
        else:
            overall_status = HealthStatus.HEALTHY

        result = {
            "status": overall_status.value,
            "timestamp": datetime.utcnow().isoformat(),
            "checks": [
                {
                    "name": c.name,
                    "status": c.status.value,
                    "message": c.message,
                    "latency_ms": c.latency_ms,
                    "metadata": c.metadata,
                }
                for c in checks
            ],
        }

        # Add to history
        self.health_history.append(result)

        return result

    def get_metrics(self) -> Metrics:
        """Get current metrics"""
        self.update_counts()
        self.update_system_metrics()
        return self.metrics

    def get_metrics_dict(self) -> Dict[str, Any]:
        """Get metrics as dictionary"""
        return self.get_metrics().to_dict()

    async def start(self) -> None:
        """Start health monitoring loop"""
        if self.is_running:
            return

        self.is_running = True
        self._monitor_task = asyncio.create_task(self._monitor_loop())

    async def stop(self) -> None:
        """Stop health monitoring"""
        self.is_running = False
        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass

    async def _monitor_loop(self) -> None:
        """Internal monitoring loop"""
        while self.is_running:
            try:
                await self.check_health()
                await asyncio.sleep(self.check_interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Health monitor error: {e}")
                await asyncio.sleep(self.check_interval)

    def get_uptime(self) -> timedelta:
        """Get bot uptime"""
        return timedelta(seconds=time.time() - self.start_time)

    def get_health_history(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Get health check history.

        Args:
            limit: Max results to return

        Returns:
            List of health check results
        """
        history = list(self.health_history)
        if limit:
            history = history[-limit:]
        return history

    def __repr__(self) -> str:
        return f"<HealthMonitor status={self.is_running}>"


__all__ = ["HealthMonitor", "HealthStatus", "HealthCheck", "Metrics"]
