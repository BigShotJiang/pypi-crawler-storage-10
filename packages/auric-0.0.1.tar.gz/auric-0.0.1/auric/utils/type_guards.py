"""
Type Guards for Interactions - Check interaction types

Discord.js has interaction.isButton(), interaction.isCommand(), etc.
"""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..models.interaction import Interaction


class InteractionTypeGuards:
    """
    Mixin class to add type guard methods to Interaction.

    Similar to discord.js interaction type guards.
    """

    def is_command(self) -> bool:
        """Check if interaction is an application command"""
        return self.type == 2

    def is_button(self) -> bool:
        """Check if interaction is a button"""
        return self.type == 3 and self.data.get("component_type") == 2

    def is_select_menu(self) -> bool:
        """Check if interaction is any select menu"""
        if self.type != 3:
            return False
        component_type = self.data.get("component_type")
        return component_type in (3, 5, 6, 7, 8)

    def is_string_select(self) -> bool:
        """Check if interaction is a string select menu"""
        return self.type == 3 and self.data.get("component_type") == 3

    def is_user_select(self) -> bool:
        """Check if interaction is a user select menu"""
        return self.type == 3 and self.data.get("component_type") == 5

    def is_role_select(self) -> bool:
        """Check if interaction is a role select menu"""
        return self.type == 3 and self.data.get("component_type") == 6

    def is_mentionable_select(self) -> bool:
        """Check if interaction is a mentionable select menu"""
        return self.type == 3 and self.data.get("component_type") == 7

    def is_channel_select(self) -> bool:
        """Check if interaction is a channel select menu"""
        return self.type == 3 and self.data.get("component_type") == 8

    def is_message_component(self) -> bool:
        """Check if interaction is any message component"""
        return self.type == 3

    def is_autocomplete(self) -> bool:
        """Check if interaction is autocomplete"""
        return self.type == 4

    def is_modal_submit(self) -> bool:
        """Check if interaction is modal submit"""
        return self.type == 5

    def is_context_menu(self) -> bool:
        """Check if interaction is a context menu command"""
        if self.type != 2:
            return False
        return self.data.get("type") in (2, 3)

    def is_user_context_menu(self) -> bool:
        """Check if interaction is a user context menu"""
        return self.type == 2 and self.data.get("type") == 2

    def is_message_context_menu(self) -> bool:
        """Check if interaction is a message context menu"""
        return self.type == 2 and self.data.get("type") == 3

    def is_chat_input_command(self) -> bool:
        """Check if interaction is a chat input (slash) command"""
        return self.type == 2 and self.data.get("type") == 1

    def is_repliable(self) -> bool:
        """Check if interaction can be replied to"""
        return self.type in (2, 3, 4, 5)

    def is_from_guild(self) -> bool:
        """Check if interaction is from a guild"""
        return self.guild_id is not None


__all__ = ["InteractionTypeGuards"]
