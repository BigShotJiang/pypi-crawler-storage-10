"""
Application Command Manager - Manages slash commands and context menus
"""

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..models.slash_command import MessageCommand, SlashCommand, UserCommand
from ..utils.collection import Collection

if TYPE_CHECKING:
    from ..core.client import Client


class ApplicationCommandManager:
    """
    Manages application commands (slash commands and context menus)

    This manager handles:
    - Registering slash commands
    - Registering context menu commands
    - Updating commands
    - Deleting commands
    - Fetching commands
    - Bulk overwriting commands
    """

    def __init__(self, client: "Client"):
        self.client = client
        self._global_commands: Collection[str, Any] = Collection()
        self._guild_commands: Dict[str, Collection[str, Any]] = {}

    async def fetch_global_commands(self) -> List[Dict[str, Any]]:
        """
        Fetch all global application commands

        Returns:
            List of command data
        """
        commands = await self.client.http.get_global_application_commands(
            self.client.application_id
        )

        # Update cache
        self._global_commands.clear()
        for cmd in commands:
            self._global_commands.set(cmd["id"], cmd)

        return commands

    async def fetch_guild_commands(self, guild_id: str) -> List[Dict[str, Any]]:
        """
        Fetch all guild application commands

        Args:
            guild_id: The guild ID

        Returns:
            List of command data
        """
        commands = await self.client.http.get_guild_application_commands(
            self.client.application_id, guild_id
        )

        # Update cache
        if guild_id not in self._guild_commands:
            self._guild_commands[guild_id] = Collection()

        self._guild_commands[guild_id].clear()
        for cmd in commands:
            self._guild_commands[guild_id].set(cmd["id"], cmd)

        return commands

    async def create_global_command(
        self, command: SlashCommand | UserCommand | MessageCommand
    ) -> Dict[str, Any]:
        """
        Create a global application command

        Args:
            command: The command to create

        Returns:
            The created command data
        """
        data = command.to_dict()
        result = await self.client.http.create_global_application_command(
            self.client.application_id, data
        )

        # Update cache
        self._global_commands.set(result["id"], result)

        return result

    async def create_guild_command(
        self, guild_id: str, command: SlashCommand | UserCommand | MessageCommand
    ) -> Dict[str, Any]:
        """
        Create a guild application command

        Args:
            guild_id: The guild ID
            command: The command to create

        Returns:
            The created command data
        """
        data = command.to_dict()
        result = await self.client.http.create_guild_application_command(
            self.client.application_id, guild_id, data
        )

        # Update cache
        if guild_id not in self._guild_commands:
            self._guild_commands[guild_id] = Collection()
        self._guild_commands[guild_id].set(result["id"], result)

        return result

    async def edit_global_command(
        self, command_id: str, command: SlashCommand | UserCommand | MessageCommand
    ) -> Dict[str, Any]:
        """
        Edit a global application command

        Args:
            command_id: The command ID to edit
            command: The updated command data

        Returns:
            The updated command data
        """
        data = command.to_dict()
        result = await self.client.http.edit_global_application_command(
            self.client.application_id, command_id, data
        )

        # Update cache
        self._global_commands.set(result["id"], result)

        return result

    async def edit_guild_command(
        self, guild_id: str, command_id: str, command: SlashCommand | UserCommand | MessageCommand
    ) -> Dict[str, Any]:
        """
        Edit a guild application command

        Args:
            guild_id: The guild ID
            command_id: The command ID to edit
            command: The updated command data

        Returns:
            The updated command data
        """
        data = command.to_dict()
        result = await self.client.http.edit_guild_application_command(
            self.client.application_id, guild_id, command_id, data
        )

        # Update cache
        if guild_id not in self._guild_commands:
            self._guild_commands[guild_id] = Collection()
        self._guild_commands[guild_id].set(result["id"], result)

        return result

    async def delete_global_command(self, command_id: str) -> None:
        """
        Delete a global application command

        Args:
            command_id: The command ID to delete
        """
        await self.client.http.delete_global_application_command(
            self.client.application_id, command_id
        )

        # Update cache
        self._global_commands.delete(command_id)

    async def delete_guild_command(self, guild_id: str, command_id: str) -> None:
        """
        Delete a guild application command

        Args:
            guild_id: The guild ID
            command_id: The command ID to delete
        """
        await self.client.http.delete_guild_application_command(
            self.client.application_id, guild_id, command_id
        )

        # Update cache
        if guild_id in self._guild_commands:
            self._guild_commands[guild_id].delete(command_id)

    async def bulk_overwrite_global_commands(
        self, commands: List[SlashCommand | UserCommand | MessageCommand]
    ) -> List[Dict[str, Any]]:
        """
        Bulk overwrite all global application commands

        This will replace ALL existing global commands with the provided ones.
        Use with caution!

        Args:
            commands: List of commands to set

        Returns:
            List of command data
        """
        data = [cmd.to_dict() for cmd in commands]
        results = await self.client.http.bulk_overwrite_global_application_commands(
            self.client.application_id, data
        )

        # Update cache
        self._global_commands.clear()
        for cmd in results:
            self._global_commands.set(cmd["id"], cmd)

        return results

    async def bulk_overwrite_guild_commands(
        self, guild_id: str, commands: List[SlashCommand | UserCommand | MessageCommand]
    ) -> List[Dict[str, Any]]:
        """
        Bulk overwrite all guild application commands

        This will replace ALL existing guild commands with the provided ones.
        Use with caution!

        Args:
            guild_id: The guild ID
            commands: List of commands to set

        Returns:
            List of command data
        """
        data = [cmd.to_dict() for cmd in commands]
        results = await self.client.http.bulk_overwrite_guild_application_commands(
            self.client.application_id, guild_id, data
        )

        # Update cache
        if guild_id not in self._guild_commands:
            self._guild_commands[guild_id] = Collection()

        self._guild_commands[guild_id].clear()
        for cmd in results:
            self._guild_commands[guild_id].set(cmd["id"], cmd)

        return results

    def get_global_command(self, command_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a cached global command by ID

        Args:
            command_id: The command ID

        Returns:
            The command data or None
        """
        return self._global_commands.get(command_id)

    def get_guild_command(self, guild_id: str, command_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a cached guild command by ID

        Args:
            guild_id: The guild ID
            command_id: The command ID

        Returns:
            The command data or None
        """
        if guild_id in self._guild_commands:
            return self._guild_commands[guild_id].get(command_id)
        return None
