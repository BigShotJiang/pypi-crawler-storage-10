"""
Thread Manager - Manage threads in a channel

Discord.js equivalent: ThreadManager
"""

from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

from ..core.types import Snowflake
from ..utils.collection import Collection

if TYPE_CHECKING:
    from ..core.client import Client
    from ..models.channel import Channel


class ThreadManager:
    """
    Manages threads for a channel.

    Similar to discord.js ThreadManager.

    Example:
        ```python
        # Create a thread
        thread = await channel.threads.create(
            name="Discussion",
            message=message_id
        )

        # Fetch active threads
        threads = await channel.threads.fetch_active()

        # Fetch archived threads
        archived = await channel.threads.fetch_archived()
        ```
    """

    def __init__(self, channel_id: Snowflake, client: "Client"):
        self.channel_id = channel_id
        self.client = client
        self.cache: Collection[int, "Channel"] = Collection()

    async def fetch(self, thread_id: Optional[Snowflake] = None, *, force: bool = False) -> Any:
        """Fetch thread(s)"""
        from ..models.channel import Channel

        if thread_id:
            if not force and self.cache.has(thread_id):
                return self.cache.get(thread_id)

            data = await self.client._http.get_channel(thread_id)
            thread = Channel(data, self.client)
            self.cache.set(thread.id, thread)
            return thread
        else:
            return await self.fetch_active()

    async def fetch_active(self) -> Collection[int, "Channel"]:
        """Fetch all active threads"""
        from ..models.channel import Channel

        # Get guild from channel
        channel_data = await self.client._http.get_channel(self.channel_id)
        guild_id = channel_data.get("guild_id")

        if not guild_id:
            return Collection()

        data = await self.client._http.list_active_threads(guild_id)

        threads = Collection()
        for thread_data in data.get("threads", []):
            if thread_data.get("parent_id") == str(self.channel_id):
                thread = Channel(thread_data, self.client)
                self.cache.set(thread.id, thread)
                threads.set(thread.id, thread)

        return threads

    async def fetch_archived(
        self, *, type: str = "public", before: Optional[str] = None, limit: int = 50
    ) -> Dict[str, Any]:
        """
        Fetch archived threads

        Args:
            type: 'public', 'private', or 'joined'
            before: ISO8601 timestamp
            limit: Number of threads
        """
        from ..models.channel import Channel

        if type == "public":
            data = await self.client._http.list_public_archived_threads(
                self.channel_id, before=before, limit=limit
            )
        elif type == "private":
            data = await self.client._http.list_private_archived_threads(
                self.channel_id, before=before, limit=limit
            )
        elif type == "joined":
            data = await self.client._http.list_joined_private_archived_threads(
                self.channel_id, before=before, limit=limit
            )
        else:
            raise ValueError(f"Invalid type: {type}")

        threads = Collection()
        for thread_data in data.get("threads", []):
            thread = Channel(thread_data, self.client)
            self.cache.set(thread.id, thread)
            threads.set(thread.id, thread)

        return {"threads": threads, "has_more": data.get("has_more", False)}

    async def create(
        self,
        *,
        name: str,
        message: Optional[Snowflake] = None,
        auto_archive_duration: int = 1440,
        type: int = 11,
        invitable: Optional[bool] = None,
        rate_limit_per_user: Optional[int] = None,
        reason: Optional[str] = None,
    ) -> "Channel":
        """
        Create a thread

        Args:
            name: Thread name
            message: Message ID to start from (for public threads)
            auto_archive_duration: Minutes until auto-archive (60, 1440, 4320, 10080)
            type: Thread type (11=public, 12=private, 10=announcement)
            invitable: Whether non-moderators can add members (private threads)
            rate_limit_per_user: Slowmode in seconds
            reason: Audit log reason
        """
        from ..models.channel import Channel

        if message:
            # Start thread from message
            json = {"name": name, "auto_archive_duration": auto_archive_duration}
            data = await self.client._http.start_thread_from_message(
                self.channel_id, message, json=json, reason=reason
            )
        else:
            # Create thread without message
            json = {"name": name, "auto_archive_duration": auto_archive_duration, "type": type}
            if invitable is not None:
                json["invitable"] = invitable
            if rate_limit_per_user is not None:
                json["rate_limit_per_user"] = rate_limit_per_user

            data = await self.client._http.start_thread_without_message(
                self.channel_id, json=json, reason=reason
            )

        thread = Channel(data, self.client)
        self.cache.set(thread.id, thread)
        return thread
