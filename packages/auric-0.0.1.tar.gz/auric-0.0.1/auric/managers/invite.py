"""
Invite Manager - Manage guild invites

Discord.js equivalent: GuildInviteManager
"""

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..core.types import Snowflake
from ..utils.collection import Collection

if TYPE_CHECKING:
    from ..core.client import Client


class GuildInviteManager:
    """
    Manages invites for a guild.

    Similar to discord.js GuildInviteManager.

    Example:
        ```python
        # Fetch all invites
        invites = await guild.invites.fetch()

        # Create an invite
        invite = await guild.invites.create(
            channel_id,
            max_age=3600,
            max_uses=10
        )

        # Delete an invite
        await guild.invites.delete(invite_code)
        ```
    """

    def __init__(self, guild_id: Snowflake, client: "Client"):
        self.guild_id = guild_id
        self.client = client
        self.cache: Collection[str, Dict[str, Any]] = Collection()

    async def fetch(self, code: Optional[str] = None, *, force: bool = False) -> Any:
        """Fetch invite(s) for the guild"""
        if code:
            if not force and self.cache.has(code):
                return self.cache.get(code)

            data = await self.client._http.get_invite(code, params={"with_counts": True})
            self.cache.set(code, data)
            return data
        else:
            data = await self.client._http.get_guild_invites(self.guild_id)
            self.cache.clear()
            for invite in data:
                self.cache.set(invite["code"], invite)
            return self.cache

    async def create(
        self,
        channel_id: Snowflake,
        *,
        max_age: int = 86400,
        max_uses: int = 0,
        temporary: bool = False,
        unique: bool = False,
        target_type: Optional[int] = None,
        target_user_id: Optional[Snowflake] = None,
        target_application_id: Optional[Snowflake] = None,
        reason: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a channel invite"""
        data = await self.client._http.create_channel_invite(
            channel_id,
            max_age=max_age,
            max_uses=max_uses,
            temporary=temporary,
            unique=unique,
            target_type=target_type,
            target_user_id=target_user_id,
            target_application_id=target_application_id,
            reason=reason,
        )
        self.cache.set(data["code"], data)
        return data

    async def delete(self, code: str, *, reason: Optional[str] = None) -> None:
        """Delete an invite"""
        await self.client._http.delete_invite(code, reason=reason)
        self.cache.delete(code)


class GuildScheduledEventManager:
    """
    Manages scheduled events for a guild.

    Similar to discord.js GuildScheduledEventManager.
    """

    def __init__(self, guild_id: Snowflake, client: "Client"):
        self.guild_id = guild_id
        self.client = client
        self.cache: Collection[int, Dict[str, Any]] = Collection()

    async def fetch(
        self,
        event_id: Optional[Snowflake] = None,
        *,
        force: bool = False,
        with_user_count: bool = False,
    ) -> Any:
        """Fetch scheduled event(s)"""
        if event_id:
            if not force and self.cache.has(event_id):
                return self.cache.get(event_id)

            data = await self.client._http.get_scheduled_event(
                self.guild_id, event_id, with_user_count=with_user_count
            )
            self.cache.set(int(data["id"]), data)
            return data
        else:
            data = await self.client._http.get_scheduled_events(
                self.guild_id, with_user_count=with_user_count
            )
            self.cache.clear()
            for event in data:
                self.cache.set(int(event["id"]), event)
            return self.cache

    async def create(
        self,
        *,
        name: str,
        scheduled_start_time: str,
        privacy_level: int = 2,
        entity_type: int,
        channel_id: Optional[Snowflake] = None,
        entity_metadata: Optional[Dict[str, Any]] = None,
        scheduled_end_time: Optional[str] = None,
        description: Optional[str] = None,
        image: Optional[str] = None,
        reason: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a scheduled event"""
        data = await self.client._http.create_scheduled_event(
            self.guild_id,
            name=name,
            privacy_level=privacy_level,
            scheduled_start_time=scheduled_start_time,
            entity_type=entity_type,
            channel_id=channel_id,
            entity_metadata=entity_metadata,
            scheduled_end_time=scheduled_end_time,
            description=description,
            image=image,
            reason=reason,
        )
        self.cache.set(int(data["id"]), data)
        return data

    async def edit(
        self,
        event_id: Snowflake,
        *,
        name: Optional[str] = None,
        channel_id: Optional[Snowflake] = None,
        scheduled_start_time: Optional[str] = None,
        scheduled_end_time: Optional[str] = None,
        description: Optional[str] = None,
        entity_type: Optional[int] = None,
        entity_metadata: Optional[Dict[str, Any]] = None,
        privacy_level: Optional[int] = None,
        status: Optional[int] = None,
        image: Optional[str] = None,
        reason: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Edit a scheduled event"""
        json = {}
        if name is not None:
            json["name"] = name
        if channel_id is not None:
            json["channel_id"] = str(channel_id)
        if scheduled_start_time is not None:
            json["scheduled_start_time"] = scheduled_start_time
        if scheduled_end_time is not None:
            json["scheduled_end_time"] = scheduled_end_time
        if description is not None:
            json["description"] = description
        if entity_type is not None:
            json["entity_type"] = entity_type
        if entity_metadata is not None:
            json["entity_metadata"] = entity_metadata
        if privacy_level is not None:
            json["privacy_level"] = privacy_level
        if status is not None:
            json["status"] = status
        if image is not None:
            json["image"] = image

        data = await self.client._http.modify_scheduled_event(
            self.guild_id, event_id, json=json, reason=reason
        )
        self.cache.set(event_id, data)
        return data

    async def delete(self, event_id: Snowflake) -> None:
        """Delete a scheduled event"""
        await self.client._http.delete_scheduled_event(self.guild_id, event_id)
        self.cache.delete(event_id)

    async def fetch_users(
        self,
        event_id: Snowflake,
        *,
        limit: int = 100,
        with_member: bool = False,
        before: Optional[Snowflake] = None,
        after: Optional[Snowflake] = None,
    ) -> List[Dict[str, Any]]:
        """Fetch users interested in an event"""
        return await self.client._http.get_scheduled_event_users(
            self.guild_id,
            event_id,
            limit=limit,
            with_member=with_member,
            before=before,
            after=after,
        )


__all__ = ["GuildInviteManager", "GuildScheduledEventManager"]
