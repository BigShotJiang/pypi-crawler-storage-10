"""
Channel Manager - Handles channel caching and operations
"""

from typing import List, Optional

from ..core.types import Snowflake
from ..models.channel import Channel
from .base import BaseManager


class ChannelManager(BaseManager[Channel]):
    """
    Manages channels for a client or guild

    Example:
        ```python
        # Fetch a channel
        channel = await client.channels.fetch(channel_id)

        # Get from cache
        channel = client.channels.cache.get(channel_id)
        ```
    """

    def __init__(self, client, http, guild_id: Optional[Snowflake] = None):
        super().__init__(client, http, cache=True, max_size=1000)
        self.guild_id = guild_id

    async def fetch(self, channel_id: Snowflake) -> Channel:
        """
        Fetch a channel from API

        Args:
            channel_id: Channel ID

        Returns:
            The fetched channel
        """
        data = await self._http.get_channel(channel_id)
        channel = Channel(data=data, http=self._http)
        return self._add(channel_id, channel)

    async def create(
        self,
        name: str,
        *,
        type: int = 0,
        topic: Optional[str] = None,
        bitrate: Optional[int] = None,
        user_limit: Optional[int] = None,
        rate_limit_per_user: Optional[int] = None,
        position: Optional[int] = None,
        permission_overwrites: Optional[List] = None,
        parent_id: Optional[Snowflake] = None,
        nsfw: Optional[bool] = None,
        reason: Optional[str] = None,
    ) -> Channel:
        """
        Create a new channel in the guild

        Args:
            name: Channel name
            type: Channel type
            topic: Channel topic
            bitrate: Voice channel bitrate
            user_limit: Voice channel user limit
            rate_limit_per_user: Slowmode seconds
            position: Channel position
            permission_overwrites: Permission overwrites
            parent_id: Parent category ID
            nsfw: Whether channel is NSFW
            reason: Audit log reason

        Returns:
            The created channel
        """
        if not self.guild_id:
            raise ValueError("Cannot create channel without guild_id")

        json_data = {
            "name": name,
            "type": type,
        }

        if topic is not None:
            json_data["topic"] = topic
        if bitrate is not None:
            json_data["bitrate"] = bitrate
        if user_limit is not None:
            json_data["user_limit"] = user_limit
        if rate_limit_per_user is not None:
            json_data["rate_limit_per_user"] = rate_limit_per_user
        if position is not None:
            json_data["position"] = position
        if permission_overwrites is not None:
            json_data["permission_overwrites"] = permission_overwrites
        if parent_id is not None:
            json_data["parent_id"] = str(parent_id)
        if nsfw is not None:
            json_data["nsfw"] = nsfw

        data = await self._http.create_guild_channel(self.guild_id, json=json_data, reason=reason)

        channel = Channel(data=data, http=self._http)
        return self._add(int(data["id"]), channel)

    async def edit(
        self,
        channel_id: Snowflake,
        *,
        name: Optional[str] = None,
        topic: Optional[str] = None,
        nsfw: Optional[bool] = None,
        rate_limit_per_user: Optional[int] = None,
        bitrate: Optional[int] = None,
        user_limit: Optional[int] = None,
        permission_overwrites: Optional[List] = None,
        parent_id: Optional[Snowflake] = None,
        reason: Optional[str] = None,
    ) -> Channel:
        """
        Edit a channel

        Args:
            channel_id: Channel ID
            name: New name
            topic: New topic
            nsfw: New NSFW status
            rate_limit_per_user: New slowmode
            bitrate: New bitrate
            user_limit: New user limit
            permission_overwrites: New permission overwrites
            parent_id: New parent category
            reason: Audit log reason

        Returns:
            The edited channel
        """
        data = await self._http.modify_channel(
            channel_id,
            name=name,
            topic=topic,
            nsfw=nsfw,
            rate_limit_per_user=rate_limit_per_user,
            bitrate=bitrate,
            user_limit=user_limit,
            permission_overwrites=permission_overwrites,
            parent_id=parent_id,
            reason=reason,
        )

        channel = Channel(data=data, http=self._http)
        return self._add(channel_id, channel)

    async def delete(self, channel_id: Snowflake, *, reason: Optional[str] = None) -> bool:
        """
        Delete a channel

        Args:
            channel_id: Channel ID
            reason: Audit log reason

        Returns:
            True if deleted
        """
        await self._http.delete_channel(channel_id, reason=reason)
        self._remove(channel_id)
        return True


class GuildChannelManager(ChannelManager):
    """
    Specialized channel manager for guilds
    """

    async def fetch_all(self) -> List[Channel]:
        """
        Fetch all channels in the guild

        Returns:
            List of channels
        """
        if not self.guild_id:
            raise ValueError("Cannot fetch channels without guild_id")

        data = await self._http.get_guild_channels(self.guild_id)
        channels = []

        for channel_data in data:
            channel = Channel(data=channel_data, http=self._http)
            self._add(int(channel_data["id"]), channel)
            channels.append(channel)

        return channels
