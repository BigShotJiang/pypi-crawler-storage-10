"""
Member Manager for advanced member operations
"""

from datetime import datetime
from typing import Any, Callable, Dict, List, Optional

from ..models.member import Member
from ..utils.collection import Collection
from ..utils.exceptions import Forbidden, NotFound
from .base import BaseManager


class MemberManager(BaseManager):
    """
    Manages guild members with caching and search.

    Example:
        ```python
        # Fetch member
        member = await guild.members.fetch(user_id)

        # Search members
        admins = guild.members.filter(lambda m: m.has_permission('administrator'))

        # Get by name
        member = guild.members.find(lambda m: m.name == 'Alice')
        ```
    """

    def __init__(self, client, guild_id: int):
        super().__init__(client)
        self.guild_id = guild_id
        self.cache: Collection[int, Member] = Collection()

    def add(self, member: Member) -> Member:
        """Add member to cache"""
        self.cache.set(member.id, member)
        return member

    def remove(self, user_id: int) -> Optional[Member]:
        """Remove member from cache"""
        return self.cache.delete(user_id)

    def get(self, user_id: int) -> Optional[Member]:
        """Get cached member"""
        return self.cache.get(user_id)

    async def fetch(self, user_id: int) -> Member:
        """
        Fetch member from API.

        Args:
            user_id: User ID

        Returns:
            Member object
        """
        data = await self._http.get_guild_member(self.guild_id, user_id)
        member = Member(data, self._client, self.guild_id)
        return self.add(member)

    async def fetch_many(self, *, limit: int = 1000, after: Optional[int] = None) -> List[Member]:
        """
        Fetch multiple members (list endpoint).

        Args:
            limit: Max members to fetch (1-1000)
            after: Get members after this user ID

        Returns:
            List of members
        """
        params = {"limit": min(limit, 1000)}
        if after:
            params["after"] = after

        data = await self._http.list_guild_members(self.guild_id, params=params)
        members = [Member(m, self._client, self.guild_id) for m in data]

        for member in members:
            self.add(member)

        return members

    async def chunk(self, *, query: str = "", limit: int = 0) -> List[Member]:
        """
        Request guild members via Gateway (chunking).

        Requires GUILD_MEMBERS intent.

        Args:
            query: Username prefix to match
            limit: Max members (0 = all)

        Returns:
            List of members
        """
        # This would use Gateway REQUEST_GUILD_MEMBERS opcode
        # Implementation depends on Gateway integration
        raise NotImplementedError("Member chunking requires Gateway integration")

    async def search(self, query: str, *, limit: int = 1000) -> List[Member]:
        """
        Search members by username or nickname.

        Args:
            query: Search query
            limit: Max results (1-1000)

        Returns:
            Matching members
        """
        params = {"query": query, "limit": min(limit, 1000)}

        data = await self._http.search_guild_members(self.guild_id, params=params)
        members = [Member(m, self._client, self.guild_id) for m in data]

        for member in members:
            self.add(member)

        return members

    async def add_member(
        self,
        user_id: int,
        access_token: str,
        *,
        nick: Optional[str] = None,
        roles: Optional[List[int]] = None,
        mute: bool = False,
        deaf: bool = False,
    ) -> Member:
        """
        Add user to guild (requires OAuth2).

        Args:
            user_id: User ID
            access_token: OAuth2 access token
            nick: Initial nickname
            roles: Initial role IDs
            mute: Mute in voice
            deaf: Deafen in voice

        Returns:
            Added member
        """
        payload = {"access_token": access_token}

        if nick:
            payload["nick"] = nick
        if roles:
            payload["roles"] = [str(r) for r in roles]
        if mute:
            payload["mute"] = mute
        if deaf:
            payload["deaf"] = deaf

        data = await self._http.add_guild_member(self.guild_id, user_id, json=payload)

        if data:  # Returns 201 with member object or 204 if already in guild
            member = Member(data, self._client, self.guild_id)
            return self.add(member)

    async def modify(self, user_id: int, **kwargs) -> Member:
        """
        Modify guild member.

        Args:
            user_id: User ID
            **kwargs: Fields to modify (nick, roles, mute, deaf, channel_id, etc.)

        Returns:
            Modified member
        """
        data = await self._http.modify_guild_member(self.guild_id, user_id, json=kwargs)
        member = Member(data, self._client, self.guild_id)
        return self.add(member)

    async def kick(self, user_id: int, *, reason: Optional[str] = None) -> None:
        """
        Kick member from guild.

        Args:
            user_id: User ID to kick
            reason: Audit log reason
        """
        headers = {}
        if reason:
            headers["X-Audit-Log-Reason"] = reason

        await self._http.remove_guild_member(self.guild_id, user_id, headers=headers)
        self.remove(user_id)

    async def ban(
        self,
        user_id: int,
        *,
        delete_message_days: int = 0,
        delete_message_seconds: int = 0,
        reason: Optional[str] = None,
    ) -> None:
        """
        Ban member from guild.

        Args:
            user_id: User ID to ban
            delete_message_days: Delete messages (deprecated, use seconds)
            delete_message_seconds: Delete messages from last N seconds (0-604800)
            reason: Audit log reason
        """
        headers = {}
        if reason:
            headers["X-Audit-Log-Reason"] = reason

        payload = {}
        if delete_message_seconds:
            payload["delete_message_seconds"] = delete_message_seconds
        elif delete_message_days:
            payload["delete_message_days"] = delete_message_days

        await self._http.create_guild_ban(self.guild_id, user_id, json=payload, headers=headers)
        self.remove(user_id)

    async def unban(self, user_id: int, *, reason: Optional[str] = None) -> None:
        """
        Unban user from guild.

        Args:
            user_id: User ID to unban
            reason: Audit log reason
        """
        headers = {}
        if reason:
            headers["X-Audit-Log-Reason"] = reason

        await self._http.remove_guild_ban(self.guild_id, user_id, headers=headers)

    async def timeout(
        self, user_id: int, until: datetime, *, reason: Optional[str] = None
    ) -> Member:
        """
        Timeout member (restrict communication).

        Args:
            user_id: User ID
            until: Timeout expiration (max 28 days)
            reason: Audit log reason

        Returns:
            Modified member
        """
        return await self.modify(
            user_id, communication_disabled_until=until.isoformat(), reason=reason
        )

    async def remove_timeout(self, user_id: int, *, reason: Optional[str] = None) -> Member:
        """
        Remove member timeout.

        Args:
            user_id: User ID
            reason: Audit log reason

        Returns:
            Modified member
        """
        return await self.modify(user_id, communication_disabled_until=None, reason=reason)

    def filter(self, predicate: Callable[[Member], bool]) -> List[Member]:
        """Filter cached members"""
        return [m for m in self.cache.values() if predicate(m)]

    def find(self, predicate: Callable[[Member], bool]) -> Optional[Member]:
        """Find first matching member"""
        return next((m for m in self.cache.values() if predicate(m)), None)

    def get_by_name(self, name: str, *, case_sensitive: bool = False) -> Optional[Member]:
        """Get member by username"""
        if case_sensitive:
            return self.find(lambda m: m.user.username == name)
        else:
            name_lower = name.lower()
            return self.find(lambda m: m.user.username.lower() == name_lower)

    def get_by_nick(self, nick: str, *, case_sensitive: bool = False) -> Optional[Member]:
        """Get member by nickname"""
        if case_sensitive:
            return self.find(lambda m: m.nick == nick)
        else:
            nick_lower = nick.lower()
            return self.find(lambda m: m.nick and m.nick.lower() == nick_lower)

    def get_with_role(self, role_id: int) -> List[Member]:
        """Get members with specific role"""
        return self.filter(lambda m: role_id in m.roles)

    @property
    def count(self) -> int:
        """Cached member count"""
        return len(self.cache)

    def clear_cache(self) -> None:
        """Clear member cache"""
        self.cache.clear()

    def __len__(self) -> int:
        return self.count

    def __iter__(self):
        return iter(self.cache.values())

    def __repr__(self) -> str:
        return f"<MemberManager guild={self.guild_id} members={self.count}>"


class RoleManager(BaseManager):
    """
    Manages guild roles.

    Example:
        ```python
        # Create role
        role = await guild.roles.create(name='Moderator', color=0x00ff00)

        # Get role
        role = guild.roles.get(role_id)

        # Modify role
        await guild.roles.modify(role_id, name='Admin')
        ```
    """

    def __init__(self, client, guild_id: int):
        super().__init__(client)
        self.guild_id = guild_id
        self.cache: Collection[int, Any] = Collection()  # Role model

    async def fetch(self, role_id: int):
        """Fetch role (via guild roles)"""
        roles = await self._http.get_guild_roles(self.guild_id)
        role_data = next((r for r in roles if int(r["id"]) == role_id), None)
        if not role_data:
            raise NotFound(f"Role {role_id} not found")
        return role_data

    async def fetch_all(self) -> List[Any]:
        """Fetch all guild roles"""
        data = await self._http.get_guild_roles(self.guild_id)
        return data

    async def create(
        self,
        *,
        name: str = "new role",
        permissions: int = 0,
        color: int = 0,
        hoist: bool = False,
        icon: Optional[str] = None,
        unicode_emoji: Optional[str] = None,
        mentionable: bool = False,
        reason: Optional[str] = None,
    ):
        """
        Create guild role.

        Args:
            name: Role name
            permissions: Permission bitfield
            color: RGB color value
            hoist: Show separately in sidebar
            icon: Role icon (base64)
            unicode_emoji: Unicode emoji for role
            mentionable: Can be mentioned
            reason: Audit log reason

        Returns:
            Created role
        """
        payload = {
            "name": name,
            "permissions": str(permissions),
            "color": color,
            "hoist": hoist,
            "mentionable": mentionable,
        }

        if icon:
            payload["icon"] = icon
        if unicode_emoji:
            payload["unicode_emoji"] = unicode_emoji

        headers = {}
        if reason:
            headers["X-Audit-Log-Reason"] = reason

        data = await self._http.create_guild_role(self.guild_id, json=payload, headers=headers)
        return data

    async def modify(self, role_id: int, **kwargs):
        """
        Modify guild role.

        Args:
            role_id: Role ID
            **kwargs: Fields to modify

        Returns:
            Modified role
        """
        reason = kwargs.pop("reason", None)
        headers = {}
        if reason:
            headers["X-Audit-Log-Reason"] = reason

        data = await self._http.modify_guild_role(
            self.guild_id, role_id, json=kwargs, headers=headers
        )
        return data

    async def delete(self, role_id: int, *, reason: Optional[str] = None) -> None:
        """
        Delete guild role.

        Args:
            role_id: Role ID
            reason: Audit log reason
        """
        headers = {}
        if reason:
            headers["X-Audit-Log-Reason"] = reason

        await self._http.delete_guild_role(self.guild_id, role_id, headers=headers)

    async def modify_positions(
        self, positions: List[Dict[str, int]], *, reason: Optional[str] = None
    ) -> List[Any]:
        """
        Modify role positions.

        Args:
            positions: List of {id, position} dicts
            reason: Audit log reason

        Returns:
            Updated roles
        """
        headers = {}
        if reason:
            headers["X-Audit-Log-Reason"] = reason

        data = await self._http.modify_guild_role_positions(
            self.guild_id, json=positions, headers=headers
        )
        return data

    def __repr__(self) -> str:
        return f"<RoleManager guild={self.guild_id}>"


__all__ = ["MemberManager", "RoleManager"]
