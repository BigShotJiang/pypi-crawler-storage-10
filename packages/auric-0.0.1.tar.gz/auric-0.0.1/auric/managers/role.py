"""
Role Manager - Manage roles in a guild

Discord.js equivalent: RoleManager
"""

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..core.types import Snowflake
from ..utils.collection import Collection

if TYPE_CHECKING:
    from ..core.client import Client
    from ..models.role import Role


class RoleManager:
    """
    Manages roles for a guild.

    Similar to discord.js RoleManager.

    Example:
        ```python
        # Get guild roles
        guild = await client.fetch_guild(guild_id)
        roles = guild.roles

        # Create a role
        role = await guild.roles.create(name="Admin", color=0xFF0000)

        # Delete a role
        await guild.roles.delete(role_id)

        # Get highest role
        highest = guild.roles.highest
        ```
    """

    def __init__(self, guild_id: Snowflake, client: "Client"):
        self.guild_id = guild_id
        self.client = client
        self.cache: Collection[int, "Role"] = Collection()

    async def fetch(self, role_id: Optional[Snowflake] = None, *, force: bool = False) -> Any:
        """Fetch role(s) from the guild"""
        from ..models.role import Role

        if role_id:
            if not force and self.cache.has(role_id):
                return self.cache.get(role_id)

            # Discord doesn't have fetch single role, so fetch all
            await self.fetch(force=True)
            return self.cache.get(role_id)
        else:
            data = await self.client._http.get_guild_roles(self.guild_id)
            self.cache.clear()
            for role_data in data:
                role = Role(role_data, self.client, self.guild_id)
                self.cache.set(role.id, role)
            return self.cache

    async def create(
        self,
        *,
        name: str = "new role",
        permissions: Optional[int] = None,
        color: int = 0,
        hoist: bool = False,
        icon: Optional[str] = None,
        unicode_emoji: Optional[str] = None,
        mentionable: bool = False,
        reason: Optional[str] = None,
    ) -> "Role":
        """
        Create a new role

        Args:
            name: Role name
            permissions: Permissions bitfield
            color: Role color (integer)
            hoist: Show separately in sidebar
            icon: Role icon image data
            unicode_emoji: Role unicode emoji
            mentionable: Whether role is mentionable
            reason: Audit log reason
        """
        from ..models.role import Role

        json = {"name": name, "color": color, "hoist": hoist, "mentionable": mentionable}

        if permissions is not None:
            json["permissions"] = str(permissions)
        if icon:
            json["icon"] = icon
        if unicode_emoji:
            json["unicode_emoji"] = unicode_emoji

        data = await self.client._http.create_guild_role(self.guild_id, json=json, reason=reason)
        role = Role(data, self.client, self.guild_id)
        self.cache.set(role.id, role)
        return role

    async def edit(
        self,
        role_id: Snowflake,
        *,
        name: Optional[str] = None,
        permissions: Optional[int] = None,
        color: Optional[int] = None,
        hoist: Optional[bool] = None,
        icon: Optional[str] = None,
        unicode_emoji: Optional[str] = None,
        mentionable: Optional[bool] = None,
        reason: Optional[str] = None,
    ) -> "Role":
        """Edit a role"""
        from ..models.role import Role

        json = {}
        if name is not None:
            json["name"] = name
        if permissions is not None:
            json["permissions"] = str(permissions)
        if color is not None:
            json["color"] = color
        if hoist is not None:
            json["hoist"] = hoist
        if icon is not None:
            json["icon"] = icon
        if unicode_emoji is not None:
            json["unicode_emoji"] = unicode_emoji
        if mentionable is not None:
            json["mentionable"] = mentionable

        data = await self.client._http.modify_guild_role(
            self.guild_id, role_id, json=json, reason=reason
        )
        role = Role(data, self.client, self.guild_id)
        self.cache.set(role.id, role)
        return role

    async def delete(self, role_id: Snowflake, *, reason: Optional[str] = None) -> None:
        """Delete a role"""
        await self.client._http.delete_guild_role(self.guild_id, role_id, reason=reason)
        self.cache.delete(role_id)

    async def set_positions(
        self, positions: List[Dict[str, Any]], *, reason: Optional[str] = None
    ) -> List["Role"]:
        """
        Modify role positions

        Args:
            positions: List of {id: role_id, position: int}
            reason: Audit log reason
        """
        from ..models.role import Role

        data = await self.client._http.modify_guild_role_positions(
            self.guild_id, positions, reason=reason
        )

        roles = []
        for role_data in data:
            role = Role(role_data, self.client, self.guild_id)
            self.cache.set(role.id, role)
            roles.append(role)

        return roles

    @property
    def everyone(self) -> Optional["Role"]:
        """Get the @everyone role"""
        return self.cache.find(lambda r: r.id == self.guild_id)

    @property
    def highest(self) -> Optional["Role"]:
        """Get the highest role (by position)"""
        if not self.cache.size:
            return None
        return max(self.cache.array(), key=lambda r: r.position)

    @property
    def premium_subscriber(self) -> Optional["Role"]:
        """Get the boost role"""
        return self.cache.find(lambda r: getattr(r, "tags", {}).get("premium_subscriber"))

    def compare(self, role1_id: Snowflake, role2_id: Snowflake) -> int:
        """
        Compare two roles by position

        Returns:
            Positive if role1 > role2, negative if role1 < role2, 0 if equal
        """
        role1 = self.cache.get(role1_id)
        role2 = self.cache.get(role2_id)

        if not role1 or not role2:
            return 0

        return role1.position - role2.position
