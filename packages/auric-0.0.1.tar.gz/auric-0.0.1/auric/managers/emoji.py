"""
Emoji Manager - Manage guild emojis

Discord.js equivalent: GuildEmojiManager
"""

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..core.types import Snowflake
from ..utils.collection import Collection

if TYPE_CHECKING:
    from ..core.client import Client
    from ..models.emoji import Emoji


class GuildEmojiManager:
    """
    Manages emojis for a guild.

    Similar to discord.js GuildEmojiManager.

    Example:
        ```python
        # Create an emoji
        emoji = await guild.emojis.create(
            name="custom",
            image="data:image/png;base64,..."
        )

        # Edit an emoji
        await guild.emojis.edit(emoji_id, name="new_name")

        # Delete an emoji
        await guild.emojis.delete(emoji_id)
        ```
    """

    def __init__(self, guild_id: Snowflake, client: "Client"):
        self.guild_id = guild_id
        self.client = client
        self.cache: Collection[int, "Emoji"] = Collection()

    async def fetch(self, emoji_id: Optional[Snowflake] = None, *, force: bool = False) -> Any:
        """Fetch emoji(s) from the guild"""
        from ..models.emoji import Emoji

        if emoji_id:
            if not force and self.cache.has(emoji_id):
                return self.cache.get(emoji_id)

            data = await self.client._http.get_guild_emoji(self.guild_id, emoji_id)
            emoji = Emoji(data, self.client, self.guild_id)
            self.cache.set(emoji.id, emoji)
            return emoji
        else:
            data = await self.client._http.list_guild_emojis(self.guild_id)
            self.cache.clear()
            for emoji_data in data:
                emoji = Emoji(emoji_data, self.client, self.guild_id)
                self.cache.set(emoji.id, emoji)
            return self.cache

    async def create(
        self,
        *,
        name: str,
        image: str,
        roles: Optional[List[Snowflake]] = None,
        reason: Optional[str] = None,
    ) -> "Emoji":
        """
        Create a guild emoji

        Args:
            name: Emoji name
            image: Image data (data URI or base64)
            roles: Roles allowed to use emoji
            reason: Audit log reason
        """
        from ..models.emoji import Emoji

        json = {"name": name, "image": image}
        if roles:
            json["roles"] = [str(r) for r in roles]

        data = await self.client._http.create_guild_emoji(self.guild_id, json=json, reason=reason)
        emoji = Emoji(data, self.client, self.guild_id)
        self.cache.set(emoji.id, emoji)
        return emoji

    async def edit(
        self,
        emoji_id: Snowflake,
        *,
        name: Optional[str] = None,
        roles: Optional[List[Snowflake]] = None,
        reason: Optional[str] = None,
    ) -> "Emoji":
        """Edit a guild emoji"""
        from ..models.emoji import Emoji

        json = {}
        if name is not None:
            json["name"] = name
        if roles is not None:
            json["roles"] = [str(r) for r in roles]

        data = await self.client._http.modify_guild_emoji(
            self.guild_id, emoji_id, json=json, reason=reason
        )
        emoji = Emoji(data, self.client, self.guild_id)
        self.cache.set(emoji.id, emoji)
        return emoji

    async def delete(self, emoji_id: Snowflake, *, reason: Optional[str] = None) -> None:
        """Delete a guild emoji"""
        await self.client._http.delete_guild_emoji(self.guild_id, emoji_id, reason=reason)
        self.cache.delete(emoji_id)

    def resolve(self, emoji) -> Optional["Emoji"]:
        """Resolve emoji from ID or Emoji object"""
        if isinstance(emoji, int):
            return self.cache.get(emoji)
        return emoji

    def resolve_id(self, emoji) -> Optional[Snowflake]:
        """Resolve emoji ID"""
        if isinstance(emoji, int):
            return emoji
        return getattr(emoji, "id", None)

    def resolve_identifier(self, emoji) -> Optional[str]:
        """Resolve emoji identifier for reactions"""
        if isinstance(emoji, str):
            return emoji  # Unicode emoji

        if isinstance(emoji, int):
            emoji = self.cache.get(emoji)

        if emoji:
            if hasattr(emoji, "id"):
                # Custom emoji
                animated = "a" if getattr(emoji, "animated", False) else ""
                return f"{emoji.name}:{emoji.id}"

        return None


class GuildStickerManager:
    """
    Manages stickers for a guild.

    Similar to discord.js GuildStickerManager.
    """

    def __init__(self, guild_id: Snowflake, client: "Client"):
        self.guild_id = guild_id
        self.client = client
        self.cache: Collection[int, Any] = Collection()

    async def fetch(self, sticker_id: Optional[Snowflake] = None, *, force: bool = False) -> Any:
        """Fetch sticker(s) from the guild"""
        if sticker_id:
            if not force and self.cache.has(sticker_id):
                return self.cache.get(sticker_id)

            data = await self.client._http.get_guild_sticker(self.guild_id, sticker_id)
            self.cache.set(int(data["id"]), data)
            return data
        else:
            data = await self.client._http.list_guild_stickers(self.guild_id)
            self.cache.clear()
            for sticker in data:
                self.cache.set(int(sticker["id"]), sticker)
            return self.cache

    async def create(
        self, *, name: str, description: str, tags: str, file: bytes, reason: Optional[str] = None
    ) -> Any:
        """Create a guild sticker"""
        data = await self.client._http.create_guild_sticker(
            self.guild_id, name=name, description=description, tags=tags, file=file, reason=reason
        )
        self.cache.set(int(data["id"]), data)
        return data

    async def edit(
        self,
        sticker_id: Snowflake,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        tags: Optional[str] = None,
        reason: Optional[str] = None,
    ) -> Any:
        """Edit a guild sticker"""
        json = {}
        if name is not None:
            json["name"] = name
        if description is not None:
            json["description"] = description
        if tags is not None:
            json["tags"] = tags

        data = await self.client._http.modify_guild_sticker(
            self.guild_id, sticker_id, json=json, reason=reason
        )
        self.cache.set(sticker_id, data)
        return data

    async def delete(self, sticker_id: Snowflake, *, reason: Optional[str] = None) -> None:
        """Delete a guild sticker"""
        await self.client._http.delete_guild_sticker(self.guild_id, sticker_id, reason=reason)
        self.cache.delete(sticker_id)


__all__ = ["GuildEmojiManager", "GuildStickerManager"]
