"""
Audio player and sources for voice
"""

from __future__ import annotations

import asyncio
import logging
import threading
import time
from typing import Callable, Optional, Protocol

logger = logging.getLogger(__name__)


class AudioSource(Protocol):
    """
    Protocol for audio sources

    Audio sources must provide 20ms Opus frames (960 samples at 48kHz).
    """

    def read(self) -> Optional[bytes]:
        """
        Read next audio frame

        Returns:
            20ms Opus-encoded frame, or None if done
        """
        ...

    def is_opus(self) -> bool:
        """Whether source provides Opus-encoded audio"""
        return True

    def cleanup(self) -> None:
        """Cleanup resources"""
        pass


class AudioPlayer:
    """
    Audio player for voice connections

    Plays audio from a source at the correct timing (20ms frames).
    """

    FRAME_LENGTH = 0.02  # 20ms
    DELAY = FRAME_LENGTH

    def __init__(
        self,
        protocol,
        source: AudioSource,
        after: Optional[Callable[[Optional[Exception]], None]] = None,
    ):
        self.protocol = protocol
        self.source = source
        self.after = after

        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._pause_event = threading.Event()
        self._pause_event.set()  # Not paused by default

        self._current_error: Optional[Exception] = None
        self._lock = threading.Lock()

    def start(self) -> None:
        """Start audio playback"""
        if self._thread and self._thread.is_alive():
            raise RuntimeError("Already playing")

        self._thread = threading.Thread(target=self._play_audio, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """Stop audio playback"""
        self._stop_event.set()

        if self._thread:
            self._thread.join()

    def pause(self) -> None:
        """Pause audio playback"""
        self._pause_event.clear()

    def resume(self) -> None:
        """Resume audio playback"""
        self._pause_event.set()

    @property
    def is_playing(self) -> bool:
        """Whether audio is playing"""
        return self._thread is not None and self._thread.is_alive()

    @property
    def is_paused(self) -> bool:
        """Whether audio is paused"""
        return not self._pause_event.is_set()

    def _play_audio(self) -> None:
        """Audio playback loop (runs in thread)"""
        try:
            asyncio.run(self._do_play())
        except Exception as e:
            self._current_error = e
            logger.error(f"Audio playback error: {e}")
        finally:
            self.source.cleanup()

            # Call after callback
            if self.after:
                try:
                    self.after(self._current_error)
                except Exception as e:
                    logger.error(f"After callback error: {e}")

    async def _do_play(self) -> None:
        """Play audio frames"""
        await self.protocol.set_speaking(True)

        start_time = time.perf_counter()
        loops = 0

        try:
            while not self._stop_event.is_set():
                # Wait if paused
                self._pause_event.wait()

                if self._stop_event.is_set():
                    break

                # Read next frame
                data = self.source.read()

                if data is None:
                    # End of audio
                    break

                # Send audio packet
                self.protocol.send_audio(data)

                # Calculate next frame time
                loops += 1
                next_time = start_time + (loops * self.DELAY)

                # Sleep until next frame
                delay = next_time - time.perf_counter()
                if delay > 0:
                    await asyncio.sleep(delay)

        finally:
            await self.protocol.set_speaking(False)


class PCMAudio(AudioSource):
    """
    Audio source from PCM data

    PCM format: 16-bit signed little-endian, 48kHz, stereo (2 channels).
    """

    def __init__(self, stream):
        self.stream = stream

    def read(self) -> Optional[bytes]:
        """Read 20ms of PCM audio (3840 bytes)"""
        data = self.stream.read(3840)  # 48000 * 2 channels * 2 bytes * 0.02s

        if len(data) != 3840:
            return None

        return data

    def is_opus(self) -> bool:
        return False

    def cleanup(self) -> None:
        if hasattr(self.stream, "close"):
            self.stream.close()


class FFmpegPCMAudio(PCMAudio):
    """
    Audio source from FFmpeg process

    Requires FFmpeg to be installed and available in PATH.
    """

    def __init__(
        self,
        source: str,
        *,
        executable: str = "ffmpeg",
        options: Optional[str] = None,
        before_options: Optional[str] = None,
    ):
        import subprocess

        args = [executable]

        if before_options:
            args.extend(before_options.split())

        args.extend(["-i", source])

        if options:
            args.extend(options.split())

        # Output format: PCM 16-bit LE, 48kHz, stereo
        args.extend(["-f", "s16le", "-ar", "48000", "-ac", "2", "-loglevel", "warning", "pipe:1"])

        self._process = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        super().__init__(self._process.stdout)

    def cleanup(self) -> None:
        if hasattr(self, "_process"):
            self._process.kill()
            self._process.wait()


class FFmpegOpusAudio(AudioSource):
    """
    Opus audio source from FFmpeg

    More efficient than PCM as it provides pre-encoded Opus frames.
    """

    def __init__(self, source: str, *, executable: str = "ffmpeg", bitrate: int = 128):
        import subprocess

        args = [
            executable,
            "-i",
            source,
            "-f",
            "opus",
            "-c:a",
            "libopus",
            "-b:a",
            f"{bitrate}k",
            "-vn",
            "-loglevel",
            "warning",
            "pipe:1",
        ]

        self._process = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        self.stream = self._process.stdout

    def read(self) -> Optional[bytes]:
        # Read Opus frame (variable size, but typically ~100-200 bytes)
        # This is a simplified implementation
        data = self.stream.read(4096)

        if not data:
            return None

        return data

    def is_opus(self) -> bool:
        return True

    def cleanup(self) -> None:
        if hasattr(self, "_process"):
            self._process.kill()
            self._process.wait()
