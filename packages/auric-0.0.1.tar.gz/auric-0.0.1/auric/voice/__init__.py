"""
Voice support for Auric Discord wrapper

Provides voice connection, audio streaming, and voice state management.

This module includes:
- Voice client for connections
- Audio sources (PCM, FFmpeg, custom)
- Audio filters and effects
- Playlist management
- Voice utilities
"""

# Audio filters
from .filters import (
    AudioFilter,
    BassBoostFilter,
    ChannelMixFilter,
    FadeInFilter,
    FadeOutFilter,
    NormalizeFilter,
    SpeedFilter,
    TremoloFilter,
    VolumeFilter,
    apply_filters,
)
from .opus import OpusDecoder, OpusEncoder
from .player import AudioPlayer, AudioSource

# Playlist
from .playlist import Playlist
from .protocol import VoiceProtocol
from .region import VoiceRegion

# Audio sources
from .sources import (
    AudioBuffer,
    FFmpegAudio,
    FFmpegOpusAudio,
    FFmpegPCMAudio,
    PCMAudio,
    PCMVolumeTransformer,
    SilenceSource,
    create_audio_source,
)

# Core voice
from .voice_client import VoiceClient
from .voice_gateway import VoiceGatewayClient

# Utilities
from .voice_utils import (
    SUPPORTED_FORMATS,
    calculate_bitrate,
    create_playlist,
    download_audio,
    format_duration,
    get_audio_info,
    get_ffmpeg_version,
    get_format_name,
    is_connected,
    is_ffmpeg_available,
    is_paused,
    is_playing,
    is_supported_format,
)

__all__ = [
    # Core
    "VoiceClient",
    "VoiceGatewayClient",
    "VoiceProtocol",
    "AudioPlayer",
    "AudioSource",
    "OpusEncoder",
    "OpusDecoder",
    "VoiceRegion",
    # Audio sources
    "PCMAudio",
    "FFmpegAudio",
    "FFmpegPCMAudio",
    "FFmpegOpusAudio",
    "PCMVolumeTransformer",
    "AudioBuffer",
    "SilenceSource",
    "create_audio_source",
    # Filters
    "AudioFilter",
    "VolumeFilter",
    "BassBoostFilter",
    "SpeedFilter",
    "NormalizeFilter",
    "FadeInFilter",
    "FadeOutFilter",
    "ChannelMixFilter",
    "TremoloFilter",
    "apply_filters",
    # Playlist
    "Playlist",
    # Utilities
    "is_ffmpeg_available",
    "get_ffmpeg_version",
    "calculate_bitrate",
    "format_duration",
    "get_audio_info",
    "download_audio",
    "create_playlist",
    "is_connected",
    "is_playing",
    "is_paused",
    "is_supported_format",
    "get_format_name",
    "SUPPORTED_FORMATS",
]
