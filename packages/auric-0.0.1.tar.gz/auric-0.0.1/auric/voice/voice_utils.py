"""
Voice utilities and helper functions

Provides convenient functions for voice operations.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Optional, Union

if TYPE_CHECKING:
    from .sources import AudioSource
    from .voice_client import VoiceClient


def is_ffmpeg_available() -> bool:
    """
    Check if FFmpeg is available on the system

    Returns:
        True if FFmpeg is installed and accessible

    Example:
        if not is_ffmpeg_available():
            print("Please install FFmpeg to play audio")
    """
    import subprocess

    try:
        subprocess.run(
            ["ffmpeg", "-version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True
        )
        return True
    except (FileNotFoundError, subprocess.CalledProcessError):
        return False


def get_ffmpeg_version() -> Optional[str]:
    """
    Get installed FFmpeg version

    Returns:
        Version string, or None if not available

    Example:
        version = get_ffmpeg_version()
        print(f"FFmpeg version: {version}")
    """
    import subprocess

    try:
        result = subprocess.run(
            ["ffmpeg", "-version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            check=True,
            text=True,
        )
        # Parse first line: "ffmpeg version X.X.X ..."
        first_line = result.stdout.split("\n")[0]
        if "version" in first_line:
            parts = first_line.split()
            if len(parts) >= 3:
                return parts[2]
        return None
    except:
        return None


def calculate_bitrate(file_size: int, duration: float) -> int:
    """
    Calculate audio bitrate from file size and duration

    Args:
        file_size: File size in bytes
        duration: Duration in seconds

    Returns:
        Bitrate in kbps

    Example:
        bitrate = calculate_bitrate(5_000_000, 180.0)  # 5MB, 3 minutes
        print(f"Bitrate: {bitrate} kbps")
    """
    if duration <= 0:
        return 0

    # (bytes * 8 bits) / (seconds * 1000) = kbps
    return int((file_size * 8) / (duration * 1000))


def format_duration(seconds: float) -> str:
    """
    Format duration as HH:MM:SS or MM:SS

    Args:
        seconds: Duration in seconds

    Returns:
        Formatted duration string

    Example:
        print(format_duration(3665))  # "1:01:05"
        print(format_duration(125))   # "2:05"
    """
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)

    if hours > 0:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    return f"{minutes}:{secs:02d}"


def get_audio_info(file_path: Union[str, Path]) -> Optional[dict]:
    """
    Get audio file information using FFprobe

    Args:
        file_path: Path to audio file

    Returns:
        Dictionary with audio info (duration, bitrate, codec, etc.)
        or None if FFprobe not available

    Example:
        info = get_audio_info('song.mp3')
        if info:
            print(f"Duration: {info['duration']} seconds")
            print(f"Bitrate: {info['bitrate']} kbps")
    """
    import json
    import subprocess

    try:
        result = subprocess.run(
            [
                "ffprobe",
                "-v",
                "quiet",
                "-print_format",
                "json",
                "-show_format",
                "-show_streams",
                str(file_path),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            check=True,
            text=True,
        )

        data = json.loads(result.stdout)

        # Extract relevant info
        format_info = data.get("format", {})
        streams = data.get("streams", [])
        audio_stream = next((s for s in streams if s.get("codec_type") == "audio"), None)

        if not audio_stream:
            return None

        info = {
            "duration": float(format_info.get("duration", 0)),
            "bitrate": int(format_info.get("bit_rate", 0)) // 1000,  # Convert to kbps
            "size": int(format_info.get("size", 0)),
            "codec": audio_stream.get("codec_name"),
            "sample_rate": int(audio_stream.get("sample_rate", 0)),
            "channels": int(audio_stream.get("channels", 0)),
            "title": format_info.get("tags", {}).get("title"),
            "artist": format_info.get("tags", {}).get("artist"),
            "album": format_info.get("tags", {}).get("album"),
        }

        return info

    except:
        return None


def download_audio(
    url: str, output_path: Optional[Union[str, Path]] = None, quality: str = "bestaudio"
) -> Optional[Path]:
    """
    Download audio from URL using yt-dlp/youtube-dl

    Args:
        url: URL to download from
        output_path: Output file path (default: temp file)
        quality: Quality preset ('bestaudio', 'worstaudio', or format code)

    Returns:
        Path to downloaded file, or None if failed

    Example:
        # Download YouTube video audio
        file_path = download_audio('https://youtube.com/watch?v=...')
        if file_path:
            source = FFmpegAudio(file_path)
            await voice_client.play(source)

    Note:
        Requires yt-dlp or youtube-dl to be installed
    """
    import subprocess
    import tempfile

    if output_path is None:
        # Create temp file
        fd, output_path = tempfile.mkstemp(suffix=".m4a")
        import os

        os.close(fd)

    output_path = Path(output_path)

    # Try yt-dlp first, then youtube-dl
    for command in ["yt-dlp", "youtube-dl"]:
        try:
            subprocess.run(
                [command, "-f", quality, "-o", str(output_path), "--no-playlist", "--quiet", url],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return output_path
        except (FileNotFoundError, subprocess.CalledProcessError):
            continue

    return None


def create_playlist(
    *sources: Union[str, Path, AudioSource], shuffle: bool = False, loop: bool = False
) -> "Playlist":
    """
    Create a playlist from multiple sources

    Args:
        *sources: Audio sources (file paths or AudioSource objects)
        shuffle: Shuffle playlist order
        loop: Loop playlist when finished

    Returns:
        Playlist object

    Example:
        playlist = create_playlist(
            'song1.mp3',
            'song2.mp3',
            'song3.mp3',
            shuffle=True,
            loop=True
        )

        await voice_client.play_playlist(playlist)
    """
    from .playlist import Playlist

    return Playlist(list(sources), shuffle=shuffle, loop=loop)


# Voice state helpers


def is_connected(voice_client: Optional["VoiceClient"]) -> bool:
    """
    Check if voice client is connected

    Args:
        voice_client: Voice client to check

    Returns:
        True if connected to voice channel
    """
    return voice_client is not None and voice_client.is_connected()


def is_playing(voice_client: Optional["VoiceClient"]) -> bool:
    """
    Check if voice client is playing audio

    Args:
        voice_client: Voice client to check

    Returns:
        True if currently playing audio
    """
    return voice_client is not None and voice_client.is_playing()


def is_paused(voice_client: Optional["VoiceClient"]) -> bool:
    """
    Check if voice client is paused

    Args:
        voice_client: Voice client to check

    Returns:
        True if paused
    """
    return voice_client is not None and voice_client.is_paused()


# Audio format helpers

SUPPORTED_FORMATS = {
    ".mp3": "MP3",
    ".wav": "WAV",
    ".ogg": "OGG Vorbis",
    ".opus": "Opus",
    ".m4a": "M4A/AAC",
    ".flac": "FLAC",
    ".aac": "AAC",
    ".wma": "WMA",
    ".webm": "WebM",
}


def is_supported_format(file_path: Union[str, Path]) -> bool:
    """
    Check if audio format is supported

    Args:
        file_path: Path to audio file

    Returns:
        True if format is supported

    Example:
        if is_supported_format('song.mp3'):
            source = FFmpegAudio('song.mp3')
    """
    path = Path(file_path)
    return path.suffix.lower() in SUPPORTED_FORMATS


def get_format_name(file_path: Union[str, Path]) -> Optional[str]:
    """
    Get human-readable format name

    Args:
        file_path: Path to audio file

    Returns:
        Format name, or None if unknown

    Example:
        print(get_format_name('song.mp3'))  # "MP3"
    """
    path = Path(file_path)
    return SUPPORTED_FORMATS.get(path.suffix.lower())


__all__ = [
    "is_ffmpeg_available",
    "get_ffmpeg_version",
    "calculate_bitrate",
    "format_duration",
    "get_audio_info",
    "download_audio",
    "create_playlist",
    "is_connected",
    "is_playing",
    "is_paused",
    "is_supported_format",
    "get_format_name",
    "SUPPORTED_FORMATS",
]
