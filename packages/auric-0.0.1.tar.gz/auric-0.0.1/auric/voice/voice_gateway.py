"""
Voice gateway WebSocket client
"""

from __future__ import annotations

import asyncio
import logging
import struct
from typing import Any, Dict, Optional

import aiohttp
import orjson

logger = logging.getLogger(__name__)


class VoiceGatewayClient:
    """
    WebSocket client for Discord Voice Gateway

    Handles voice gateway protocol including heartbeats, identification,
    and speaking state management.
    """

    # Voice opcodes
    IDENTIFY = 0
    SELECT_PROTOCOL = 1
    READY = 2
    HEARTBEAT = 3
    SESSION_DESCRIPTION = 4
    SPEAKING = 5
    HEARTBEAT_ACK = 6
    RESUME = 7
    HELLO = 8
    RESUMED = 9
    CLIENT_DISCONNECT = 13

    def __init__(self, guild_id: int, user_id: int, session_id: str, token: str, endpoint: str):
        self.guild_id = guild_id
        self.user_id = user_id
        self.session_id = session_id
        self.token = token
        self.endpoint = endpoint

        self.ws: Optional[aiohttp.ClientWebSocketResponse] = None
        self.session: Optional[aiohttp.ClientSession] = None

        self._heartbeat_interval: Optional[float] = None
        self._heartbeat_task: Optional[asyncio.Task] = None
        self._receive_task: Optional[asyncio.Task] = None

        self.connected = False
        self.ssrc: Optional[int] = None
        self.ip: Optional[str] = None
        self.port: Optional[int] = None
        self.secret_key: Optional[bytes] = None

    async def connect(self) -> None:
        """Connect to voice gateway"""
        url = f"wss://{self.endpoint}/?v=4"

        self.session = aiohttp.ClientSession()
        self.ws = await self.session.ws_connect(url)
        self.connected = True

        # Start receive loop
        self._receive_task = asyncio.create_task(self._receive_loop())

    async def close(self) -> None:
        """Close voice gateway connection"""
        self.connected = False

        if self._heartbeat_task:
            self._heartbeat_task.cancel()

        if self._receive_task:
            self._receive_task.cancel()

        if self.ws:
            await self.ws.close()

        if self.session:
            await self.session.close()

    async def send(self, data: Dict[str, Any]) -> None:
        """Send JSON data to voice gateway"""
        if self.ws:
            await self.ws.send_str(orjson.dumps(data).decode("utf-8"))

    async def _receive_loop(self) -> None:
        """Receive and process voice gateway messages"""
        try:
            async for msg in self.ws:
                if msg.type == aiohttp.WSMsgType.TEXT:
                    data = orjson.loads(msg.data)
                    await self._handle_message(data)
                elif msg.type == aiohttp.WSMsgType.CLOSED:
                    break
        except Exception as e:
            logger.error(f"Voice gateway receive error: {e}")

    async def _handle_message(self, data: Dict[str, Any]) -> None:
        """Handle voice gateway message"""
        op = data["op"]
        d = data.get("d")

        if op == self.HELLO:
            # Start heartbeat
            self._heartbeat_interval = d["heartbeat_interval"] / 1000.0
            self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())

            # Send identify
            await self.identify()

        elif op == self.READY:
            # Voice connection ready
            self.ssrc = d["ssrc"]
            self.ip = d["ip"]
            self.port = d["port"]

            logger.info(f"Voice gateway ready: {self.ip}:{self.port} (SSRC: {self.ssrc})")

            # Perform IP discovery
            await self.select_protocol()

        elif op == self.SESSION_DESCRIPTION:
            # Encryption key received
            self.secret_key = bytes(d["secret_key"])
            logger.info("Voice encryption enabled")

        elif op == self.SPEAKING:
            # Someone started/stopped speaking
            pass

        elif op == self.HEARTBEAT_ACK:
            # Heartbeat acknowledged
            pass

        elif op == self.RESUMED:
            logger.info("Voice gateway resumed")

        elif op == self.CLIENT_DISCONNECT:
            # Client disconnected
            pass

    async def identify(self) -> None:
        """Send identify payload"""
        await self.send(
            {
                "op": self.IDENTIFY,
                "d": {
                    "server_id": str(self.guild_id),
                    "user_id": str(self.user_id),
                    "session_id": self.session_id,
                    "token": self.token,
                },
            }
        )

    async def select_protocol(self) -> None:
        """Select voice protocol"""
        await self.send(
            {
                "op": self.SELECT_PROTOCOL,
                "d": {
                    "protocol": "udp",
                    "data": {
                        "address": self.ip,
                        "port": self.port,
                        "mode": "xsalsa20_poly1305",
                    },
                },
            }
        )

    async def speak(self, speaking: bool, delay: int = 0) -> None:
        """
        Set speaking state

        Args:
            speaking: Whether bot is speaking
            delay: Delay in milliseconds
        """
        await self.send(
            {
                "op": self.SPEAKING,
                "d": {
                    "speaking": 1 if speaking else 0,
                    "delay": delay,
                    "ssrc": self.ssrc,
                },
            }
        )

    async def _heartbeat_loop(self) -> None:
        """Send heartbeats to voice gateway"""
        try:
            while self.connected:
                await self.send(
                    {"op": self.HEARTBEAT, "d": int(asyncio.get_event_loop().time() * 1000)}
                )

                await asyncio.sleep(self._heartbeat_interval)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(f"Voice heartbeat error: {e}")
