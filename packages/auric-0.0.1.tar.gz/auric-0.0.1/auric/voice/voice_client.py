"""
Voice client for Discord voice channels
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Callable, Optional

from .player import AudioPlayer
from .protocol import VoiceProtocol
from .voice_gateway import VoiceGatewayClient

if TYPE_CHECKING:
    from ..core.client import Client
    from ..models.channel import VoiceChannel
    from ..models.guild import Guild

logger = logging.getLogger(__name__)


class VoiceClient:
    """
    Represents a Discord voice connection

    This client handles the voice WebSocket connection and UDP audio streaming.

    Attributes:
        guild: The guild this voice client is connected to
        channel: The voice channel connected to
        user_id: The user ID of the bot
        session_id: Voice session ID
        token: Voice connection token
        endpoint: Voice server endpoint
    """

    def __init__(self, client: Client, guild: Guild, channel: VoiceChannel):
        self.client = client
        self.guild = guild
        self.channel = channel

        self.user_id: Optional[int] = None
        self.session_id: Optional[str] = None
        self.token: Optional[str] = None
        self.endpoint: Optional[str] = None

        self._gateway: Optional[VoiceGatewayClient] = None
        self._protocol: Optional[VoiceProtocol] = None
        self._player: Optional[AudioPlayer] = None

        self._connected = asyncio.Event()
        self._ready = asyncio.Event()

    @property
    def is_connected(self) -> bool:
        """Whether voice client is connected"""
        return self._gateway is not None and self._gateway.connected

    @property
    def is_playing(self) -> bool:
        """Whether audio is currently playing"""
        return self._player is not None and self._player.is_playing

    @property
    def is_paused(self) -> bool:
        """Whether audio is paused"""
        return self._player is not None and self._player.is_paused

    async def connect(
        self,
        *,
        timeout: float = 60.0,
        reconnect: bool = True,
        self_deaf: bool = False,
        self_mute: bool = False,
    ) -> None:
        """
        Connect to voice channel

        Args:
            timeout: Connection timeout in seconds
            reconnect: Whether to automatically reconnect
            self_deaf: Whether to self-deafen
            self_mute: Whether to self-mute

        Raises:
            asyncio.TimeoutError: If connection times out
            VoiceException: If connection fails
        """
        logger.info(f"Connecting to voice channel {self.channel.id}")

        # Send voice state update to gateway
        await self.client.gateway.send(
            {
                "op": 4,  # Voice State Update
                "d": {
                    "guild_id": str(self.guild.id),
                    "channel_id": str(self.channel.id),
                    "self_mute": self_mute,
                    "self_deaf": self_deaf,
                },
            }
        )

        # Wait for voice server and session info
        try:
            await asyncio.wait_for(self._connected.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            await self.disconnect()
            raise asyncio.TimeoutError("Voice connection timed out")

        # Connect to voice gateway
        self._gateway = VoiceGatewayClient(
            self.guild.id, self.user_id, self.session_id, self.token, self.endpoint
        )

        await self._gateway.connect()

        # Wait for ready
        try:
            await asyncio.wait_for(self._ready.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            await self.disconnect()
            raise asyncio.TimeoutError("Voice gateway ready timed out")

        logger.info(f"Connected to voice channel {self.channel.id}")

    async def disconnect(self, *, force: bool = False) -> None:
        """
        Disconnect from voice channel

        Args:
            force: Whether to force disconnect without cleanup
        """
        logger.info(f"Disconnecting from voice channel {self.channel.id}")

        # Stop player
        if self._player is not None:
            self._player.stop()
            self._player = None

        # Close protocol
        if self._protocol is not None:
            self._protocol.close()
            self._protocol = None

        # Close gateway
        if self._gateway is not None:
            await self._gateway.close()
            self._gateway = None

        # Send voice state update (disconnect)
        if not force:
            try:
                await self.client.gateway.send(
                    {
                        "op": 4,  # Voice State Update
                        "d": {
                            "guild_id": str(self.guild.id),
                            "channel_id": None,
                            "self_mute": False,
                            "self_deaf": False,
                        },
                    }
                )
            except Exception as e:
                logger.error(f"Error sending disconnect: {e}")

        self._connected.clear()
        self._ready.clear()

    async def move_to(self, channel: VoiceChannel) -> None:
        """
        Move to a different voice channel

        Args:
            channel: Channel to move to
        """
        await self.client.gateway.send(
            {
                "op": 4,  # Voice State Update
                "d": {
                    "guild_id": str(self.guild.id),
                    "channel_id": str(channel.id),
                    "self_mute": False,
                    "self_deaf": False,
                },
            }
        )

        self.channel = channel

    def play(
        self, source: AudioSource, *, after: Optional[Callable[[Optional[Exception]], None]] = None
    ) -> None:
        """
        Play audio from a source

        Args:
            source: Audio source to play
            after: Callback when audio finishes (with optional exception)
        """
        if not self.is_connected:
            raise RuntimeError("Not connected to voice")

        if self.is_playing:
            raise RuntimeError("Already playing audio")

        self._player = AudioPlayer(self._protocol, source, after)
        self._player.start()

    def pause(self) -> None:
        """Pause audio playback"""
        if self._player:
            self._player.pause()

    def resume(self) -> None:
        """Resume audio playback"""
        if self._player:
            self._player.resume()

    def stop(self) -> None:
        """Stop audio playback"""
        if self._player:
            self._player.stop()
            self._player = None

    @property
    def source(self) -> Optional[AudioSource]:
        """Current audio source"""
        return self._player.source if self._player else None

    def is_speaking(self) -> bool:
        """Whether bot is currently speaking"""
        return self._protocol.is_speaking() if self._protocol else False

    async def set_speaking(self, speaking: bool) -> None:
        """
        Set speaking state

        Args:
            speaking: Whether bot is speaking
        """
        if self._gateway:
            await self._gateway.speak(speaking)

    # Event handlers called by main gateway

    def _voice_server_update(self, token: str, endpoint: str) -> None:
        """Handle VOICE_SERVER_UPDATE event"""
        self.token = token
        self.endpoint = endpoint.replace(":80", "")  # Remove port
        self._connected.set()

    def _voice_state_update(self, session_id: str, user_id: int) -> None:
        """Handle VOICE_STATE_UPDATE event"""
        self.session_id = session_id
        self.user_id = user_id

    def _voice_ready(self, ssrc: int, ip: str, port: int) -> None:
        """Handle voice ready from gateway"""
        self._protocol = VoiceProtocol(self._gateway, ssrc, ip, port)
        self._ready.set()
