"""
Audio effects and filters for voice

Provides audio transformation effects like bass boost, speed change, etc.
"""

from __future__ import annotations

import array
import audioop
from typing import Optional

from .sources import AudioSource, PCMAudio


class AudioFilter(AudioSource):
    """
    Base class for audio filters

    Filters wrap an AudioSource and transform the audio.
    """

    def __init__(self, source: AudioSource):
        if source.is_opus():
            raise ValueError("Cannot apply filters to Opus audio")

        self.source = source

    def cleanup(self) -> None:
        self.source.cleanup()


class VolumeFilter(AudioFilter):
    """
    Volume adjustment filter

    Args:
        source: Audio source to filter
        volume: Volume level (0.0 to 2.0)

    Example:
        source = FFmpegAudio('song.mp3')
        source = VolumeFilter(source, volume=0.5)
    """

    def __init__(self, source: AudioSource, volume: float = 1.0):
        super().__init__(source)
        self._volume = max(0.0, min(volume, 2.0))

    @property
    def volume(self) -> float:
        return self._volume

    @volume.setter
    def volume(self, value: float):
        self._volume = max(0.0, min(value, 2.0))

    def read(self) -> Optional[bytes]:
        data = self.source.read()
        if data is None:
            return None

        if self._volume != 1.0:
            factor = int(self._volume * 256)
            data = audioop.mul(data, 2, factor)

        return data


class BassBoostFilter(AudioFilter):
    """
    Bass boost filter

    Enhances low frequencies.

    Args:
        source: Audio source to filter
        boost: Boost amount (0.0 to 2.0, default 1.5)

    Example:
        source = FFmpegAudio('song.mp3')
        source = BassBoostFilter(source, boost=1.8)
    """

    def __init__(self, source: AudioSource, boost: float = 1.5):
        super().__init__(source)
        self.boost = max(1.0, min(boost, 2.0))
        self._buffer = bytearray()

    def read(self) -> Optional[bytes]:
        data = self.source.read()
        if data is None:
            return None

        # Simple bass boost: amplify low-frequency components
        # In a real implementation, we'd use FFT or IIR filter
        # This is a simplified version

        # Convert to samples
        samples = array.array("h", data)  # 'h' = signed short (16-bit)

        # Apply simple amplification to simulate bass boost
        # Real bass boost would require frequency domain processing
        for i in range(len(samples)):
            sample = samples[i]
            # Amplify while avoiding clipping
            boosted = int(sample * self.boost)
            samples[i] = max(-32768, min(32767, boosted))

        return samples.tobytes()


class SpeedFilter(AudioFilter):
    """
    Speed/tempo adjustment filter

    Changes playback speed without affecting pitch.
    Note: This is a basic implementation. For better quality,
    use FFmpeg options with time stretching.

    Args:
        source: Audio source to filter
        speed: Speed multiplier (0.5 = half speed, 2.0 = double speed)

    Example:
        source = FFmpegAudio('song.mp3')
        source = SpeedFilter(source, speed=1.25)  # 25% faster
    """

    def __init__(self, source: AudioSource, speed: float = 1.0):
        super().__init__(source)
        self.speed = max(0.25, min(speed, 4.0))
        self._buffer = bytearray()
        self._position = 0.0

    def read(self) -> Optional[bytes]:
        # For speed changes, we need to resample
        # This is a very basic implementation

        # Calculate how many frames we need
        target_size = PCMAudio.FRAME_SIZE

        while len(self._buffer) < target_size:
            data = self.source.read()
            if data is None:
                if self._buffer:
                    # Pad remaining buffer
                    self._buffer.extend(b"\x00" * (target_size - len(self._buffer)))
                    break
                return None

            self._buffer.extend(data)

        # Extract frame
        if len(self._buffer) < target_size:
            return None

        # Simple resampling (linear interpolation)
        # In production, use ratecv from audioop
        frame = bytes(self._buffer[:target_size])

        # Remove consumed samples based on speed
        consume_size = int(target_size * self.speed)
        self._buffer = self._buffer[consume_size:]

        return frame


class NormalizeFilter(AudioFilter):
    """
    Audio normalization filter

    Normalizes audio levels to prevent clipping and maintain consistent volume.

    Args:
        source: Audio source to filter
        target_level: Target RMS level (default: 0.5)

    Example:
        source = FFmpegAudio('song.mp3')
        source = NormalizeFilter(source)
    """

    def __init__(self, source: AudioSource, target_level: float = 0.5):
        super().__init__(source)
        self.target_level = max(0.1, min(target_level, 1.0))

    def read(self) -> Optional[bytes]:
        data = self.source.read()
        if data is None:
            return None

        # Calculate RMS (root mean square) level
        rms = audioop.rms(data, 2)  # 2 = 16-bit samples

        if rms == 0:
            return data

        # Calculate normalization factor
        target_rms = int(32767 * self.target_level)
        factor = min(2.0, target_rms / rms)

        # Apply normalization
        normalized = audioop.mul(data, 2, int(factor * 256))
        return normalized


class FadeInFilter(AudioFilter):
    """
    Fade-in effect filter

    Gradually increases volume from 0 to 1 over duration.

    Args:
        source: Audio source to filter
        duration: Fade duration in seconds

    Example:
        source = FFmpegAudio('song.mp3')
        source = FadeInFilter(source, duration=3.0)  # 3 second fade-in
    """

    def __init__(self, source: AudioSource, duration: float):
        super().__init__(source)
        self.duration = duration
        self.frames_total = int(duration * 50)  # 50 frames per second
        self.frames_read = 0

    def read(self) -> Optional[bytes]:
        data = self.source.read()
        if data is None:
            return None

        # Calculate fade volume
        if self.frames_read < self.frames_total:
            volume = self.frames_read / self.frames_total
            factor = int(volume * 256)
            data = audioop.mul(data, 2, factor)

        self.frames_read += 1
        return data


class FadeOutFilter(AudioFilter):
    """
    Fade-out effect filter

    Gradually decreases volume from 1 to 0 over duration.
    Note: Requires knowing audio length in advance.

    Args:
        source: Audio source to filter
        duration: Fade duration in seconds
        total_duration: Total audio duration in seconds

    Example:
        source = FFmpegAudio('song.mp3')
        source = FadeOutFilter(source, duration=3.0, total_duration=180.0)
    """

    def __init__(self, source: AudioSource, duration: float, total_duration: float):
        super().__init__(source)
        self.duration = duration
        self.fade_start_frame = int((total_duration - duration) * 50)
        self.fade_total_frames = int(duration * 50)
        self.frames_read = 0

    def read(self) -> Optional[bytes]:
        data = self.source.read()
        if data is None:
            return None

        # Calculate fade volume
        if self.frames_read >= self.fade_start_frame:
            fade_progress = (self.frames_read - self.fade_start_frame) / self.fade_total_frames
            fade_progress = min(1.0, fade_progress)
            volume = 1.0 - fade_progress
            factor = int(volume * 256)
            data = audioop.mul(data, 2, factor)

        self.frames_read += 1
        return data


class ChannelMixFilter(AudioFilter):
    """
    Channel mixing filter

    Mixes stereo channels or converts mono to stereo.

    Args:
        source: Audio source to filter
        left_to_right: Mix left channel into right (0.0 to 1.0)
        right_to_left: Mix right channel into left (0.0 to 1.0)

    Example:
        # Create pseudo-mono by mixing channels
        source = FFmpegAudio('song.mp3')
        source = ChannelMixFilter(source, left_to_right=0.5, right_to_left=0.5)
    """

    def __init__(self, source: AudioSource, left_to_right: float = 0.0, right_to_left: float = 0.0):
        super().__init__(source)
        self.left_to_right = max(0.0, min(left_to_right, 1.0))
        self.right_to_left = max(0.0, min(right_to_left, 1.0))

    def read(self) -> Optional[bytes]:
        data = self.source.read()
        if data is None:
            return None

        # Convert to samples (stereo = 2 channels)
        samples = array.array("h", data)

        # Mix channels
        for i in range(0, len(samples), 2):
            left = samples[i]
            right = samples[i + 1]

            # Mix
            new_left = left + int(right * self.right_to_left)
            new_right = right + int(left * self.left_to_right)

            # Prevent clipping
            samples[i] = max(-32768, min(32767, new_left))
            samples[i + 1] = max(-32768, min(32767, new_right))

        return samples.tobytes()


class TremoloFilter(AudioFilter):
    """
    Tremolo effect filter

    Varies volume at a specific frequency (amplitude modulation).

    Args:
        source: Audio source to filter
        frequency: Tremolo frequency in Hz (default: 5.0)
        depth: Effect depth (0.0 to 1.0, default: 0.5)

    Example:
        source = FFmpegAudio('song.mp3')
        source = TremoloFilter(source, frequency=6.0, depth=0.7)
    """

    def __init__(self, source: AudioSource, frequency: float = 5.0, depth: float = 0.5):
        super().__init__(source)
        self.frequency = max(0.1, min(frequency, 20.0))
        self.depth = max(0.0, min(depth, 1.0))
        self.frames_read = 0

    def read(self) -> Optional[bytes]:
        import math

        data = self.source.read()
        if data is None:
            return None

        # Calculate tremolo volume for this frame
        # 50 frames per second
        time = self.frames_read / 50.0
        tremolo = 1.0 - (self.depth * (1.0 + math.sin(2 * math.pi * self.frequency * time)) / 2.0)

        # Apply volume
        factor = int(tremolo * 256)
        data = audioop.mul(data, 2, factor)

        self.frames_read += 1
        return data


# Helper functions


def apply_filters(source: AudioSource, *filters) -> AudioSource:
    """
    Apply multiple filters to a source

    Args:
        source: Original audio source
        *filters: Filter classes to apply (innermost first)

    Returns:
        Filtered audio source

    Example:
        source = FFmpegAudio('song.mp3')
        source = apply_filters(
            source,
            lambda s: BassBoostFilter(s, boost=1.8),
            lambda s: VolumeFilter(s, volume=0.8),
            lambda s: FadeInFilter(s, duration=2.0)
        )
    """
    result = source
    for filter_func in filters:
        result = filter_func(result)
    return result


__all__ = [
    "AudioFilter",
    "VolumeFilter",
    "BassBoostFilter",
    "SpeedFilter",
    "NormalizeFilter",
    "FadeInFilter",
    "FadeOutFilter",
    "ChannelMixFilter",
    "TremoloFilter",
    "apply_filters",
]
