"""
Playlist management for voice

Provides playlist functionality for managing multiple audio sources.
"""

from __future__ import annotations

import random
from pathlib import Path
from typing import Iterator, List, Optional, Union

from .sources import AudioSource, create_audio_source


class Playlist:
    """
    Playlist manager for audio sources

    Manages a queue of audio sources with shuffle and loop support.

    Args:
        sources: List of audio sources or file paths
        shuffle: Shuffle playlist order
        loop: Loop playlist when finished

    Example:
        playlist = Playlist([
            'song1.mp3',
            'song2.mp3',
            'song3.mp3'
        ], shuffle=True, loop=True)

        # Play next song
        while playlist.has_next():
            source = playlist.next()
            await voice_client.play(source)
    """

    def __init__(
        self,
        sources: List[Union[str, Path, AudioSource]],
        *,
        shuffle: bool = False,
        loop: bool = False,
    ):
        self.sources = list(sources)
        self._original_order = list(sources)
        self.shuffle_enabled = shuffle
        self.loop_enabled = loop
        self.current_index = 0

        if shuffle:
            self.shuffle()

    def __len__(self) -> int:
        """Number of sources in playlist"""
        return len(self.sources)

    def __iter__(self) -> Iterator[AudioSource]:
        """Iterate through playlist"""
        while self.has_next():
            yield self.next()

    def __getitem__(self, index: int) -> Union[str, Path, AudioSource]:
        """Get source at index"""
        return self.sources[index]

    @property
    def current(self) -> Optional[Union[str, Path, AudioSource]]:
        """Current source"""
        if 0 <= self.current_index < len(self.sources):
            return self.sources[self.current_index]
        return None

    @property
    def progress(self) -> tuple[int, int]:
        """Current progress as (current, total)"""
        return (self.current_index + 1, len(self.sources))

    @property
    def progress_percent(self) -> float:
        """Progress as percentage (0.0 to 1.0)"""
        if not self.sources:
            return 0.0
        return (self.current_index + 1) / len(self.sources)

    @property
    def remaining(self) -> int:
        """Number of sources remaining"""
        return max(0, len(self.sources) - self.current_index - 1)

    def has_next(self) -> bool:
        """Check if there's a next source"""
        if self.loop_enabled:
            return len(self.sources) > 0
        return self.current_index < len(self.sources)

    def has_previous(self) -> bool:
        """Check if there's a previous source"""
        return self.current_index > 0

    def next(self) -> Optional[AudioSource]:
        """
        Get next audio source

        Returns:
            Next AudioSource, or None if playlist is finished
        """
        if not self.has_next():
            return None

        if self.current_index >= len(self.sources):
            if self.loop_enabled:
                self.current_index = 0
            else:
                return None

        source = self.sources[self.current_index]
        self.current_index += 1

        # Convert to AudioSource if needed
        if isinstance(source, (str, Path)):
            return create_audio_source(source)

        return source

    def previous(self) -> Optional[AudioSource]:
        """
        Go back to previous source

        Returns:
            Previous AudioSource, or None if at beginning
        """
        if not self.has_previous():
            return None

        self.current_index -= 1
        source = self.sources[self.current_index]

        # Convert to AudioSource if needed
        if isinstance(source, (str, Path)):
            return create_audio_source(source)

        return source

    def skip(self, count: int = 1) -> None:
        """
        Skip forward by count sources

        Args:
            count: Number of sources to skip
        """
        self.current_index = min(len(self.sources), self.current_index + count)

    def back(self, count: int = 1) -> None:
        """
        Go back by count sources

        Args:
            count: Number of sources to go back
        """
        self.current_index = max(0, self.current_index - count)

    def reset(self) -> None:
        """Reset to beginning of playlist"""
        self.current_index = 0

    def shuffle(self) -> None:
        """Shuffle playlist order"""
        if self.sources:
            # Save current source
            current = None
            if 0 <= self.current_index < len(self.sources):
                current = self.sources[self.current_index]

            # Shuffle
            random.shuffle(self.sources)

            # Restore current index
            if current:
                try:
                    self.current_index = self.sources.index(current)
                except ValueError:
                    self.current_index = 0
            else:
                self.current_index = 0

    def unshuffle(self) -> None:
        """Restore original order"""
        self.sources = list(self._original_order)
        self.current_index = 0

    def add(self, source: Union[str, Path, AudioSource]) -> None:
        """
        Add source to end of playlist

        Args:
            source: Audio source or file path
        """
        self.sources.append(source)
        self._original_order.append(source)

    def insert(self, index: int, source: Union[str, Path, AudioSource]) -> None:
        """
        Insert source at index

        Args:
            index: Position to insert
            source: Audio source or file path
        """
        self.sources.insert(index, source)
        self._original_order.insert(index, source)

    def remove(self, index: int) -> Union[str, Path, AudioSource]:
        """
        Remove source at index

        Args:
            index: Index to remove

        Returns:
            Removed source
        """
        removed = self.sources.pop(index)

        # Update current index if needed
        if index < self.current_index:
            self.current_index -= 1
        elif index == self.current_index:
            self.current_index = min(self.current_index, len(self.sources) - 1)

        # Remove from original order too
        try:
            self._original_order.remove(removed)
        except ValueError:
            pass

        return removed

    def clear(self) -> None:
        """Clear all sources from playlist"""
        self.sources.clear()
        self._original_order.clear()
        self.current_index = 0

    def peek(self, offset: int = 1) -> Optional[Union[str, Path, AudioSource]]:
        """
        Peek at upcoming source without advancing

        Args:
            offset: How many sources ahead to peek (default: next source)

        Returns:
            Source at offset, or None
        """
        index = self.current_index + offset

        if self.loop_enabled:
            index = index % len(self.sources) if self.sources else 0

        if 0 <= index < len(self.sources):
            return self.sources[index]

        return None

    def jump_to(self, index: int) -> None:
        """
        Jump to specific index

        Args:
            index: Target index (0-based)
        """
        self.current_index = max(0, min(index, len(self.sources)))

    def find(self, predicate) -> Optional[int]:
        """
        Find source by predicate

        Args:
            predicate: Function that takes source and returns bool

        Returns:
            Index of found source, or None

        Example:
            # Find song by name
            index = playlist.find(lambda s: 'song.mp3' in str(s))
            if index is not None:
                playlist.jump_to(index)
        """
        for i, source in enumerate(self.sources):
            if predicate(source):
                return i
        return None

    def filter(self, predicate) -> Playlist:
        """
        Create new playlist with filtered sources

        Args:
            predicate: Function that takes source and returns bool

        Returns:
            New Playlist with filtered sources

        Example:
            # Only MP3 files
            mp3_playlist = playlist.filter(lambda s: str(s).endswith('.mp3'))
        """
        filtered = [s for s in self.sources if predicate(s)]
        return Playlist(filtered, shuffle=self.shuffle_enabled, loop=self.loop_enabled)

    def sort(self, key=None, reverse: bool = False) -> None:
        """
        Sort playlist

        Args:
            key: Sort key function (default: convert to string)
            reverse: Sort in reverse order

        Example:
            # Sort by filename
            playlist.sort(key=lambda s: str(s))
        """
        if key is None:
            key = str

        self.sources.sort(key=key, reverse=reverse)
        self._original_order = list(self.sources)

    def __str__(self) -> str:
        """String representation"""
        status = []
        if self.shuffle_enabled:
            status.append("shuffled")
        if self.loop_enabled:
            status.append("looping")

        status_str = f' ({", ".join(status)})' if status else ""
        return f"Playlist({len(self.sources)} sources{status_str}, {self.current_index + 1}/{len(self.sources)})"

    def __repr__(self) -> str:
        """Developer representation"""
        return f"<Playlist sources={len(self.sources)} current={self.current_index}>"


__all__ = ["Playlist"]
