"""
Opus codec for voice encoding/decoding
"""

from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


class OpusEncoder:
    """
    Opus audio encoder

    Encodes PCM audio to Opus format for Discord voice.
    Requires opuslib or similar library.
    """

    SAMPLE_RATE = 48000
    FRAME_SIZE = 960  # 20ms at 48kHz
    CHANNELS = 2

    def __init__(self, bitrate: int = 128000):
        """
        Initialize Opus encoder

        Args:
            bitrate: Target bitrate in bits per second
        """
        self.bitrate = bitrate
        self._encoder = None

        try:
            import opuslib

            self._encoder = opuslib.Encoder(
                self.SAMPLE_RATE, self.CHANNELS, opuslib.APPLICATION_AUDIO
            )
            self._encoder.bitrate = bitrate

        except ImportError:
            logger.warning("opuslib not installed. Opus encoding unavailable.")
        except Exception as e:
            logger.error(f"Failed to initialize Opus encoder: {e}")

    def encode(self, pcm: bytes) -> Optional[bytes]:
        """
        Encode PCM audio to Opus

        Args:
            pcm: PCM audio data (3840 bytes for 20ms stereo at 48kHz)

        Returns:
            Opus-encoded data, or None if encoding fails
        """
        if not self._encoder:
            return None

        try:
            return self._encoder.encode(pcm, self.FRAME_SIZE)
        except Exception as e:
            logger.error(f"Opus encoding error: {e}")
            return None

    def set_bitrate(self, bitrate: int) -> None:
        """
        Set encoder bitrate

        Args:
            bitrate: Bitrate in bits per second
        """
        self.bitrate = bitrate
        if self._encoder:
            self._encoder.bitrate = bitrate

    def set_fec(self, enabled: bool) -> None:
        """
        Enable/disable Forward Error Correction

        Args:
            enabled: Whether to enable FEC
        """
        if self._encoder:
            try:
                self._encoder.fec = enabled
            except AttributeError:
                pass

    def set_packet_loss(self, percentage: int) -> None:
        """
        Set expected packet loss percentage

        Args:
            percentage: Expected packet loss (0-100)
        """
        if self._encoder:
            try:
                self._encoder.packet_loss_perc = percentage
            except AttributeError:
                pass


class OpusDecoder:
    """
    Opus audio decoder

    Decodes Opus audio to PCM format.
    """

    SAMPLE_RATE = 48000
    FRAME_SIZE = 960  # 20ms at 48kHz
    CHANNELS = 2

    def __init__(self):
        """Initialize Opus decoder"""
        self._decoder = None

        try:
            import opuslib

            self._decoder = opuslib.Decoder(self.SAMPLE_RATE, self.CHANNELS)

        except ImportError:
            logger.warning("opuslib not installed. Opus decoding unavailable.")
        except Exception as e:
            logger.error(f"Failed to initialize Opus decoder: {e}")

    def decode(self, opus: bytes, *, fec: bool = False) -> Optional[bytes]:
        """
        Decode Opus audio to PCM

        Args:
            opus: Opus-encoded data
            fec: Use Forward Error Correction for packet loss

        Returns:
            PCM audio data, or None if decoding fails
        """
        if not self._decoder:
            return None

        try:
            return self._decoder.decode(opus, self.FRAME_SIZE, fec)
        except Exception as e:
            logger.error(f"Opus decoding error: {e}")
            return None

    def decode_lost_packet(self) -> Optional[bytes]:
        """
        Decode a lost packet using FEC

        Returns:
            PCM audio data for lost packet, or None
        """
        if not self._decoder:
            return None

        try:
            # Decode with FEC to reconstruct lost packet
            return self._decoder.decode(b"", self.FRAME_SIZE, True)
        except Exception as e:
            logger.error(f"Opus FEC error: {e}")
            return None
