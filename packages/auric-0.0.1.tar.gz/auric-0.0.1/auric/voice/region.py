"""
Voice regions for Discord
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional


@dataclass
class VoiceRegion:
    """
    Represents a Discord voice region

    Attributes:
        id: Unique region identifier
        name: Human-readable region name
        optimal: Whether this is optimal region for user
        deprecated: Whether region is deprecated
        custom: Whether this is a custom region
    """

    id: str
    name: str
    optimal: bool = False
    deprecated: bool = False
    custom: bool = False

    @classmethod
    def from_dict(cls, data: dict) -> VoiceRegion:
        """Create from API response"""
        return cls(
            id=data["id"],
            name=data["name"],
            optimal=data.get("optimal", False),
            deprecated=data.get("deprecated", False),
            custom=data.get("custom", False),
        )

    def __str__(self) -> str:
        return self.name

    def __repr__(self) -> str:
        return f"<VoiceRegion id={self.id!r} name={self.name!r}>"


# Known voice regions
VOICE_REGIONS = {
    "us-west": "US West",
    "us-east": "US East",
    "us-central": "US Central",
    "us-south": "US South",
    "singapore": "Singapore",
    "southafrica": "South Africa",
    "sydney": "Sydney",
    "europe": "Europe",
    "brazil": "Brazil",
    "hongkong": "Hong Kong",
    "russia": "Russia",
    "japan": "Japan",
    "india": "India",
    "atlanta": "Atlanta",
    "miami": "Miami",
    "st-pete": "St. Petersburg",
}
