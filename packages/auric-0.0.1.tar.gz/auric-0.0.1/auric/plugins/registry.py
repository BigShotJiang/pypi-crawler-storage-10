"""Plugin registry for Auric"""

from typing import Dict, List, Optional, Type

from .base import Plugin, PluginMeta

__all__ = ["PluginRegistry", "register_plugin"]


class PluginRegistry:
    """
    Global registry for plugins.

    Allows plugins to be registered and discovered.
    """

    _plugins: Dict[str, Type[Plugin]] = {}

    @classmethod
    def register(cls, plugin_class: Type[Plugin]) -> None:
        """
        Register a plugin class.

        Args:
            plugin_class: The plugin class to register
        """
        # Create temporary instance to get metadata
        temp_instance = object.__new__(plugin_class)
        temp_instance.bot = None
        temp_instance._listeners = {}
        temp_instance._commands = []
        temp_instance._enabled = False

        meta = plugin_class.meta.fget(temp_instance)
        name = meta.name

        if name in cls._plugins:
            raise ValueError(f"Plugin {name} is already registered")

        cls._plugins[name] = plugin_class

    @classmethod
    def unregister(cls, name: str) -> None:
        """
        Unregister a plugin.

        Args:
            name: Plugin name
        """
        if name in cls._plugins:
            del cls._plugins[name]

    @classmethod
    def get(cls, name: str) -> Optional[Type[Plugin]]:
        """
        Get a registered plugin class.

        Args:
            name: Plugin name

        Returns:
            Type[Plugin]: The plugin class or None
        """
        return cls._plugins.get(name)

    @classmethod
    def list(cls) -> List[str]:
        """
        List all registered plugins.

        Returns:
            list: List of plugin names
        """
        return list(cls._plugins.keys())

    @classmethod
    def clear(cls) -> None:
        """Clear all registered plugins"""
        cls._plugins.clear()

    @classmethod
    def contains(cls, name: str) -> bool:
        """
        Check if plugin is registered.

        Args:
            name: Plugin name

        Returns:
            bool: True if registered
        """
        return name in cls._plugins


def register_plugin(plugin_class: Type[Plugin]) -> Type[Plugin]:
    """
    Decorator to register a plugin class.

    Args:
        plugin_class: The plugin class

    Returns:
        Type[Plugin]: The same plugin class

    Example:
        @register_plugin
        class MyPlugin(Plugin):
            @property
            def meta(self):
                return PluginMeta('my_plugin', '1.0.0', 'Author')
    """
    PluginRegistry.register(plugin_class)
    return plugin_class
