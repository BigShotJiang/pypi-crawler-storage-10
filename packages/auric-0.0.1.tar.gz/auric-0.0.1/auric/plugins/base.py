"""Base plugin system for Auric"""

import inspect
from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, List, Optional

__all__ = ["Plugin", "PluginMeta"]


class PluginMeta:
    """Metadata for a plugin"""

    def __init__(self, name: str, version: str, author: str, description: str = ""):
        """
        Initialize plugin metadata.

        Args:
            name: Plugin name
            version: Plugin version
            author: Plugin author
            description: Plugin description
        """
        self.name = name
        self.version = version
        self.author = author
        self.description = description

    def __repr__(self) -> str:
        return f"<PluginMeta name={self.name} version={self.version}>"


class Plugin(ABC):
    """
    Base class for Auric plugins.

    Plugins extend bot functionality without modifying core code.
    """

    def __init__(self, bot):
        """
        Initialize plugin.

        Args:
            bot: The bot instance
        """
        self.bot = bot
        self._listeners: Dict[str, List[Callable]] = {}
        self._commands: List[str] = []
        self._enabled = False

    @property
    @abstractmethod
    def meta(self) -> PluginMeta:
        """Get plugin metadata"""
        pass

    async def on_load(self) -> None:
        """
        Called when plugin is loaded.

        Override to perform setup tasks.
        """
        pass

    async def on_unload(self) -> None:
        """
        Called when plugin is unloaded.

        Override to perform cleanup tasks.
        """
        pass

    async def on_enable(self) -> None:
        """
        Called when plugin is enabled.

        Override to start plugin functionality.
        """
        pass

    async def on_disable(self) -> None:
        """
        Called when plugin is disabled.

        Override to stop plugin functionality.
        """
        pass

    def add_listener(self, event: str, callback: Callable) -> None:
        """
        Add an event listener.

        Args:
            event: Event name
            callback: Callback function
        """
        if event not in self._listeners:
            self._listeners[event] = []
        self._listeners[event].append(callback)

    def remove_listener(self, event: str, callback: Callable) -> None:
        """
        Remove an event listener.

        Args:
            event: Event name
            callback: Callback function
        """
        if event in self._listeners:
            self._listeners[event].remove(callback)

    def get_listeners(self, event: str) -> List[Callable]:
        """
        Get all listeners for an event.

        Args:
            event: Event name

        Returns:
            list: List of callback functions
        """
        return self._listeners.get(event, [])

    async def enable(self) -> None:
        """Enable the plugin"""
        if self._enabled:
            return

        await self.on_enable()
        self._enabled = True

    async def disable(self) -> None:
        """Disable the plugin"""
        if not self._enabled:
            return

        await self.on_disable()
        self._enabled = False

    @property
    def enabled(self) -> bool:
        """Check if plugin is enabled"""
        return self._enabled

    def get_config(self, key: str, default: Any = None) -> Any:
        """
        Get plugin configuration value.

        Args:
            key: Config key
            default: Default value

        Returns:
            any: Config value
        """
        config = getattr(self.bot, "_plugin_config", {})
        plugin_config = config.get(self.meta.name, {})
        return plugin_config.get(key, default)

    def set_config(self, key: str, value: Any) -> None:
        """
        Set plugin configuration value.

        Args:
            key: Config key
            value: Config value
        """
        if not hasattr(self.bot, "_plugin_config"):
            self.bot._plugin_config = {}

        if self.meta.name not in self.bot._plugin_config:
            self.bot._plugin_config[self.meta.name] = {}

        self.bot._plugin_config[self.meta.name][key] = value

    def __repr__(self) -> str:
        return f"<Plugin {self.meta.name} enabled={self._enabled}>"


class PluginHook:
    """Decorator for plugin hooks"""

    def __init__(self, event: str):
        """
        Initialize hook.

        Args:
            event: Event name to hook into
        """
        self.event = event

    def __call__(self, func: Callable) -> Callable:
        """
        Decorate function as event hook.

        Args:
            func: Function to decorate

        Returns:
            callable: Decorated function
        """
        func._plugin_hook = self.event
        return func


def plugin_command(name: Optional[str] = None, **attrs):
    """
    Decorator to mark function as plugin command.

    Args:
        name: Command name (defaults to function name)
        **attrs: Additional command attributes

    Returns:
        callable: Decorator function
    """

    def decorator(func: Callable) -> Callable:
        func._plugin_command = True
        func._command_name = name or func.__name__
        func._command_attrs = attrs
        return func

    return decorator


def plugin_listener(event: str):
    """
    Decorator to mark function as event listener.

    Args:
        event: Event name to listen to

    Returns:
        callable: Decorator function
    """

    def decorator(func: Callable) -> Callable:
        func._plugin_listener = event
        return func

    return decorator
