"""Plugin loader for Auric"""

import importlib
import importlib.util
import sys
from pathlib import Path
from typing import Dict, List, Optional, Type

from .base import Plugin

__all__ = ["PluginLoader"]


class PluginLoader:
    """
    Plugin loader and manager.

    Handles loading, unloading, and managing plugins.
    """

    def __init__(self, bot):
        """
        Initialize plugin loader.

        Args:
            bot: The bot instance
        """
        self.bot = bot
        self._plugins: Dict[str, Plugin] = {}
        self._plugin_paths: Dict[str, str] = {}

    def load_plugin(self, plugin_class: Type[Plugin]) -> Plugin:
        """
        Load a plugin from a class.

        Args:
            plugin_class: The plugin class to load

        Returns:
            Plugin: The loaded plugin instance
        """
        # Create plugin instance
        plugin = plugin_class(self.bot)
        name = plugin.meta.name

        # Check if already loaded
        if name in self._plugins:
            raise ValueError(f"Plugin {name} is already loaded")

        # Store plugin
        self._plugins[name] = plugin

        # Call load hook
        self.bot.loop.create_task(plugin.on_load())

        return plugin

    def load_from_file(self, file_path: str) -> Plugin:
        """
        Load a plugin from a Python file.

        Args:
            file_path: Path to the plugin file

        Returns:
            Plugin: The loaded plugin instance
        """
        path = Path(file_path)

        if not path.exists():
            raise FileNotFoundError(f"Plugin file not found: {file_path}")

        # Load module
        spec = importlib.util.spec_from_file_location(path.stem, path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load plugin from {file_path}")

        module = importlib.util.module_from_spec(spec)
        sys.modules[path.stem] = module
        spec.loader.exec_module(module)

        # Find plugin class
        plugin_class = None
        for item in dir(module):
            obj = getattr(module, item)
            if isinstance(obj, type) and issubclass(obj, Plugin) and obj != Plugin:
                plugin_class = obj
                break

        if plugin_class is None:
            raise ValueError(f"No plugin class found in {file_path}")

        # Load plugin
        plugin = self.load_plugin(plugin_class)
        self._plugin_paths[plugin.meta.name] = str(path)

        return plugin

    def load_from_module(self, module_name: str) -> Plugin:
        """
        Load a plugin from a module name.

        Args:
            module_name: Fully qualified module name

        Returns:
            Plugin: The loaded plugin instance
        """
        # Import module
        try:
            module = importlib.import_module(module_name)
        except ImportError as e:
            raise ImportError(f"Could not import plugin module {module_name}: {e}")

        # Find plugin class
        plugin_class = None
        for item in dir(module):
            obj = getattr(module, item)
            if isinstance(obj, type) and issubclass(obj, Plugin) and obj != Plugin:
                plugin_class = obj
                break

        if plugin_class is None:
            raise ValueError(f"No plugin class found in {module_name}")

        return self.load_plugin(plugin_class)

    async def unload_plugin(self, name: str) -> None:
        """
        Unload a plugin by name.

        Args:
            name: Plugin name
        """
        if name not in self._plugins:
            raise ValueError(f"Plugin {name} is not loaded")

        plugin = self._plugins[name]

        # Disable if enabled
        if plugin.enabled:
            await plugin.disable()

        # Call unload hook
        await plugin.on_unload()

        # Remove plugin
        del self._plugins[name]

        if name in self._plugin_paths:
            del self._plugin_paths[name]

    async def reload_plugin(self, name: str) -> Plugin:
        """
        Reload a plugin.

        Args:
            name: Plugin name

        Returns:
            Plugin: The reloaded plugin instance
        """
        if name not in self._plugins:
            raise ValueError(f"Plugin {name} is not loaded")

        # Get path if loaded from file
        path = self._plugin_paths.get(name)

        # Unload
        await self.unload_plugin(name)

        # Reload
        if path:
            return self.load_from_file(path)
        else:
            raise ValueError("Can only reload plugins loaded from file")

    def get_plugin(self, name: str) -> Optional[Plugin]:
        """
        Get a loaded plugin by name.

        Args:
            name: Plugin name

        Returns:
            Plugin: The plugin instance or None
        """
        return self._plugins.get(name)

    def list_plugins(self) -> List[str]:
        """
        List all loaded plugins.

        Returns:
            list: List of plugin names
        """
        return list(self._plugins.keys())

    def is_loaded(self, name: str) -> bool:
        """
        Check if a plugin is loaded.

        Args:
            name: Plugin name

        Returns:
            bool: True if loaded
        """
        return name in self._plugins

    async def enable_all(self) -> None:
        """Enable all loaded plugins"""
        for plugin in self._plugins.values():
            if not plugin.enabled:
                await plugin.enable()

    async def disable_all(self) -> None:
        """Disable all loaded plugins"""
        for plugin in self._plugins.values():
            if plugin.enabled:
                await plugin.disable()

    async def unload_all(self) -> None:
        """Unload all plugins"""
        for name in list(self._plugins.keys()):
            await self.unload_plugin(name)

    def __getitem__(self, name: str) -> Plugin:
        """Get plugin by name"""
        return self._plugins[name]

    def __contains__(self, name: str) -> bool:
        """Check if plugin is loaded"""
        return name in self._plugins

    def __len__(self) -> int:
        """Get number of loaded plugins"""
        return len(self._plugins)

    def __repr__(self) -> str:
        return f"<PluginLoader plugins={len(self._plugins)}>"
