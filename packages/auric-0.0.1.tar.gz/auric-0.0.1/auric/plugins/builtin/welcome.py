"""Built-in welcome plugin"""

from typing import Optional

from ..base import Plugin, PluginMeta, plugin_listener

__all__ = ["WelcomePlugin"]


class WelcomePlugin(Plugin):
    """
    Welcome message plugin.

    Sends welcome messages when members join.
    """

    @property
    def meta(self) -> PluginMeta:
        return PluginMeta(
            name="welcome", version="1.0.0", author="Auric", description="Welcome message plugin"
        )

    async def on_enable(self) -> None:
        """Start welcome messages"""
        self.add_listener("member_join", self.on_member_join)

    async def on_member_join(self, member) -> None:
        """Send welcome message"""
        channel_id = self.get_config("welcome_channel")
        if not channel_id:
            return

        message = self.get_config("welcome_message", "Welcome {mention} to {guild}!")

        # Format message
        formatted = message.format(
            mention=f"<@{member.id}>",
            user=member.user.username if hasattr(member, "user") else "New Member",
            guild=member.guild_id,
        )

        try:
            await self.bot.http.create_message(channel_id, {"content": formatted})
        except Exception as e:
            print(f"Failed to send welcome message: {e}")

    def set_welcome_channel(self, channel_id: int) -> None:
        """
        Set the welcome channel.

        Args:
            channel_id: Channel ID for welcome messages
        """
        self.set_config("welcome_channel", channel_id)

    def set_welcome_message(self, message: str) -> None:
        """
        Set the welcome message.

        Args:
            message: Welcome message template
                    {mention} - User mention
                    {user} - Username
                    {guild} - Guild name
        """
        self.set_config("welcome_message", message)
