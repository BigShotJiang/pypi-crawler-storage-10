"""Built-in moderation plugin"""

import asyncio
from typing import Dict, Set

from ...models.member import Member
from ..base import Plugin, PluginMeta, plugin_listener

__all__ = ["ModerationPlugin"]


class ModerationPlugin(Plugin):
    """
    Basic moderation features.

    Features:
    - Auto-mod spam detection
    - Bad word filtering
    - Raid protection
    - Message logging
    """

    def __init__(self, bot):
        super().__init__(bot)
        self._spam_tracker: Dict[int, list] = {}
        self._bad_words: Set[str] = set()
        self._muted_users: Set[int] = set()

    @property
    def meta(self) -> PluginMeta:
        return PluginMeta(
            name="moderation",
            version="1.0.0",
            author="Auric",
            description="Basic moderation features",
        )

    async def on_load(self) -> None:
        """Initialize moderation plugin"""
        # Load bad words from config
        bad_words = self.get_config("bad_words", [])
        self._bad_words = set(word.lower() for word in bad_words)

        # Load muted users
        muted = self.get_config("muted_users", [])
        self._muted_users = set(muted)

    async def on_enable(self) -> None:
        """Start moderation"""
        # Register event listeners
        self.add_listener("message_create", self.on_message)
        self.add_listener("member_join", self.on_member_join)

    async def on_disable(self) -> None:
        """Stop moderation"""
        # Unregister listeners
        self.remove_listener("message_create", self.on_message)
        self.remove_listener("member_join", self.on_member_join)

        # Save muted users
        self.set_config("muted_users", list(self._muted_users))

    async def on_message(self, message) -> None:
        """Handle message for moderation"""
        if message.author.bot:
            return

        # Check if user is muted
        if message.author.id in self._muted_users:
            await message.delete()
            return

        # Check for bad words
        if await self._check_bad_words(message):
            await message.delete()
            await message.channel.send(
                f"{message.author.mention}, please watch your language!", delete_after=5
            )
            return

        # Check for spam
        if await self._check_spam(message):
            await message.delete()
            await message.channel.send(
                f"{message.author.mention}, please don't spam!", delete_after=5
            )

    async def on_member_join(self, member: Member) -> None:
        """Handle member join for raid protection"""
        # Simple raid detection
        guild_id = member.guild_id

        if guild_id not in self._spam_tracker:
            self._spam_tracker[guild_id] = []

        import time

        now = time.time()

        # Remove old entries
        self._spam_tracker[guild_id] = [
            t for t in self._spam_tracker[guild_id] if now - t < 60  # Last minute
        ]

        # Add current join
        self._spam_tracker[guild_id].append(now)

        # Check for raid (10+ joins in 1 minute)
        if len(self._spam_tracker[guild_id]) >= 10:
            # Alert (in real implementation, notify admins)
            print(f"⚠️ Possible raid detected in guild {guild_id}")

    async def _check_bad_words(self, message) -> bool:
        """Check message for bad words"""
        if not self._bad_words:
            return False

        content = message.content.lower()
        return any(word in content for word in self._bad_words)

    async def _check_spam(self, message) -> bool:
        """Check for spam"""
        user_id = message.author.id

        if user_id not in self._spam_tracker:
            self._spam_tracker[user_id] = []

        import time

        now = time.time()

        # Remove old messages (older than 5 seconds)
        self._spam_tracker[user_id] = [t for t in self._spam_tracker[user_id] if now - t < 5]

        # Add current message
        self._spam_tracker[user_id].append(now)

        # Check if spam (5+ messages in 5 seconds)
        if len(self._spam_tracker[user_id]) >= 5:
            return True

        return False

    def mute_user(self, user_id: int) -> None:
        """
        Mute a user.

        Args:
            user_id: User ID to mute
        """
        self._muted_users.add(user_id)

    def unmute_user(self, user_id: int) -> None:
        """
        Unmute a user.

        Args:
            user_id: User ID to unmute
        """
        self._muted_users.discard(user_id)

    def is_muted(self, user_id: int) -> bool:
        """
        Check if user is muted.

        Args:
            user_id: User ID

        Returns:
            bool: True if muted
        """
        return user_id in self._muted_users

    def add_bad_word(self, word: str) -> None:
        """
        Add a bad word to filter.

        Args:
            word: Word to filter
        """
        self._bad_words.add(word.lower())
        self.set_config("bad_words", list(self._bad_words))

    def remove_bad_word(self, word: str) -> None:
        """
        Remove a bad word from filter.

        Args:
            word: Word to remove
        """
        self._bad_words.discard(word.lower())
        self.set_config("bad_words", list(self._bad_words))
