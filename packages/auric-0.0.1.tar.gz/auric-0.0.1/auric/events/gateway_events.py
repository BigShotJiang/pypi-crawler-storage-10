"""
Gateway events for Discord WebSocket
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .base import BaseEvent, ChannelEvent, GuildEvent, MessageEvent, UserEvent


# Ready Event
class ReadyEvent(BaseEvent):
    """Dispatched when the client has completed initial handshake"""

    __slots__ = ("version", "user", "guilds", "session_id", "resume_gateway_url", "application")

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.version: int = data.get("v", 0)
        self.user: Dict[str, Any] = data.get("user", {})
        self.guilds: List[Dict[str, Any]] = data.get("guilds", [])
        self.session_id: str = data.get("session_id", "")
        self.resume_gateway_url: Optional[str] = data.get("resume_gateway_url")
        self.application: Dict[str, Any] = data.get("application", {})


# Channel Events
class ChannelCreateEvent(ChannelEvent):
    """Channel was created"""

    pass


class ChannelUpdateEvent(ChannelEvent):
    """Channel was updated"""

    pass


class ChannelDeleteEvent(ChannelEvent):
    """Channel was deleted"""

    pass


class ChannelPinsUpdateEvent(ChannelEvent):
    """Channel pins were updated"""

    __slots__ = ("last_pin_timestamp",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.last_pin_timestamp: Optional[str] = data.get("last_pin_timestamp")


class ThreadCreateEvent(ChannelEvent):
    """Thread was created"""

    pass


class ThreadUpdateEvent(ChannelEvent):
    """Thread was updated"""

    pass


class ThreadDeleteEvent(ChannelEvent):
    """Thread was deleted"""

    pass


class ThreadListSyncEvent(GuildEvent):
    """Thread list sync"""

    __slots__ = ("channel_ids", "threads", "members")

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.channel_ids: List[int] = [int(cid) for cid in data.get("channel_ids", [])]
        self.threads: List[Dict[str, Any]] = data.get("threads", [])
        self.members: List[Dict[str, Any]] = data.get("members", [])


class ThreadMemberUpdateEvent(BaseEvent):
    """Thread member was updated"""

    pass


class ThreadMembersUpdateEvent(ChannelEvent):
    """Thread members were updated"""

    __slots__ = ("member_count", "added_members", "removed_member_ids")

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.member_count: int = data.get("member_count", 0)
        self.added_members: List[Dict[str, Any]] = data.get("added_members", [])
        self.removed_member_ids: List[int] = [
            int(mid) for mid in data.get("removed_member_ids", [])
        ]


# Guild Events
class GuildCreateEvent(GuildEvent):
    """Guild became available or user joined"""

    pass


class GuildUpdateEvent(GuildEvent):
    """Guild was updated"""

    pass


class GuildDeleteEvent(GuildEvent):
    """Guild became unavailable or user left"""

    __slots__ = ("unavailable",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.unavailable: bool = data.get("unavailable", False)


class GuildBanAddEvent(GuildEvent):
    """User was banned from guild"""

    __slots__ = ("user",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.user: Dict[str, Any] = data.get("user", {})


class GuildBanRemoveEvent(GuildEvent):
    """User was unbanned from guild"""

    __slots__ = ("user",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.user: Dict[str, Any] = data.get("user", {})


class GuildEmojisUpdateEvent(GuildEvent):
    """Guild emojis were updated"""

    __slots__ = ("emojis",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.emojis: List[Dict[str, Any]] = data.get("emojis", [])


class GuildStickersUpdateEvent(GuildEvent):
    """Guild stickers were updated"""

    __slots__ = ("stickers",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.stickers: List[Dict[str, Any]] = data.get("stickers", [])


class GuildIntegrationsUpdateEvent(GuildEvent):
    """Guild integrations were updated"""

    pass


class GuildMemberAddEvent(GuildEvent):
    """User joined guild"""

    pass


class GuildMemberRemoveEvent(GuildEvent):
    """User left guild"""

    __slots__ = ("user",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.user: Dict[str, Any] = data.get("user", {})


class GuildMemberUpdateEvent(GuildEvent):
    """Guild member was updated"""

    pass


class GuildMembersChunkEvent(GuildEvent):
    """Response to Request Guild Members"""

    __slots__ = ("chunk_index", "chunk_count", "members", "not_found", "presences", "nonce")

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.chunk_index: int = data.get("chunk_index", 0)
        self.chunk_count: int = data.get("chunk_count", 0)
        self.members: List[Dict[str, Any]] = data.get("members", [])
        self.not_found: List[int] = [int(uid) for uid in data.get("not_found", [])]
        self.presences: List[Dict[str, Any]] = data.get("presences", [])
        self.nonce: Optional[str] = data.get("nonce")


class GuildRoleCreateEvent(GuildEvent):
    """Guild role was created"""

    __slots__ = ("role",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.role: Dict[str, Any] = data.get("role", {})


class GuildRoleUpdateEvent(GuildEvent):
    """Guild role was updated"""

    __slots__ = ("role",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.role: Dict[str, Any] = data.get("role", {})


class GuildRoleDeleteEvent(GuildEvent):
    """Guild role was deleted"""

    __slots__ = ("role_id",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.role_id: int = int(data.get("role_id", 0))


class GuildScheduledEventCreateEvent(GuildEvent):
    """Scheduled event was created"""

    pass


class GuildScheduledEventUpdateEvent(GuildEvent):
    """Scheduled event was updated"""

    pass


class GuildScheduledEventDeleteEvent(GuildEvent):
    """Scheduled event was deleted"""

    pass


class GuildScheduledEventUserAddEvent(GuildEvent):
    """User subscribed to scheduled event"""

    __slots__ = ("scheduled_event_id", "user_id")

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.scheduled_event_id: int = int(data.get("guild_scheduled_event_id", 0))
        self.user_id: int = int(data.get("user_id", 0))


class GuildScheduledEventUserRemoveEvent(GuildEvent):
    """User unsubscribed from scheduled event"""

    __slots__ = ("scheduled_event_id", "user_id")

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.scheduled_event_id: int = int(data.get("guild_scheduled_event_id", 0))
        self.user_id: int = int(data.get("user_id", 0))


# Integration Events
class IntegrationCreateEvent(GuildEvent):
    """Guild integration was created"""

    pass


class IntegrationUpdateEvent(GuildEvent):
    """Guild integration was updated"""

    pass


class IntegrationDeleteEvent(GuildEvent):
    """Guild integration was deleted"""

    __slots__ = ("id", "application_id")

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.id: int = int(data.get("id", 0))
        self.application_id: Optional[int] = (
            int(data["application_id"]) if "application_id" in data else None
        )


# Interaction Events
class InteractionCreateEvent(BaseEvent):
    """User used an interaction"""

    pass


# Invite Events
class InviteCreateEvent(ChannelEvent):
    """Invite was created"""

    pass


class InviteDeleteEvent(ChannelEvent):
    """Invite was deleted"""

    __slots__ = ("code",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.code: str = data.get("code", "")


# Message Events
class MessageCreateEvent(MessageEvent):
    """Message was created"""

    pass


class MessageUpdateEvent(MessageEvent):
    """Message was updated"""

    pass


class MessageDeleteEvent(MessageEvent):
    """Message was deleted"""

    pass


class MessageDeleteBulkEvent(ChannelEvent):
    """Multiple messages were deleted"""

    __slots__ = ("ids",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.ids: List[int] = [int(mid) for mid in data.get("ids", [])]


class MessageReactionAddEvent(MessageEvent):
    """Reaction was added to message"""

    __slots__ = ("user_id", "emoji", "member")

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.user_id: int = int(data.get("user_id", 0))
        self.emoji: Dict[str, Any] = data.get("emoji", {})
        self.member: Optional[Dict[str, Any]] = data.get("member")


class MessageReactionRemoveEvent(MessageEvent):
    """Reaction was removed from message"""

    __slots__ = ("user_id", "emoji")

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.user_id: int = int(data.get("user_id", 0))
        self.emoji: Dict[str, Any] = data.get("emoji", {})


class MessageReactionRemoveAllEvent(MessageEvent):
    """All reactions were removed from message"""

    pass


class MessageReactionRemoveEmojiEvent(MessageEvent):
    """All instances of emoji were removed from message"""

    __slots__ = ("emoji",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.emoji: Dict[str, Any] = data.get("emoji", {})


# Presence Events
class PresenceUpdateEvent(GuildEvent):
    """User's presence was updated"""

    __slots__ = ("user", "status", "activities", "client_status")

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.user: Dict[str, Any] = data.get("user", {})
        self.status: str = data.get("status", "offline")
        self.activities: List[Dict[str, Any]] = data.get("activities", [])
        self.client_status: Dict[str, str] = data.get("client_status", {})


class TypingStartEvent(ChannelEvent):
    """User started typing"""

    __slots__ = ("user_id", "timestamp", "member")

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.user_id: int = int(data.get("user_id", 0))
        self.timestamp: int = data.get("timestamp", 0)
        self.member: Optional[Dict[str, Any]] = data.get("member")


class UserUpdateEvent(UserEvent):
    """Current user was updated"""

    pass


# Voice Events
class VoiceStateUpdateEvent(GuildEvent):
    """User's voice state was updated"""

    pass


class VoiceServerUpdateEvent(GuildEvent):
    """Guild's voice server was updated"""

    __slots__ = ("token", "endpoint")

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.token: str = data.get("token", "")
        self.endpoint: Optional[str] = data.get("endpoint")


class VoiceChannelEffectSendEvent(ChannelEvent):
    """Soundboard sound was played in voice channel"""

    __slots__ = ("user_id", "emoji", "animation_type", "animation_id", "sound_id", "sound_volume")

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.user_id: int = int(data.get("user_id", 0))
        self.emoji: Optional[Dict[str, Any]] = data.get("emoji")
        self.animation_type: Optional[int] = data.get("animation_type")
        self.animation_id: Optional[int] = data.get("animation_id")
        self.sound_id: Optional[int] = int(data["sound_id"]) if "sound_id" in data else None
        self.sound_volume: Optional[float] = data.get("sound_volume")


# Webhook Events
class WebhooksUpdateEvent(ChannelEvent):
    """Channel webhooks were updated"""

    pass


# Auto Moderation Events
class AutoModerationRuleCreateEvent(GuildEvent):
    """Auto moderation rule was created"""

    pass


class AutoModerationRuleUpdateEvent(GuildEvent):
    """Auto moderation rule was updated"""

    pass


class AutoModerationRuleDeleteEvent(GuildEvent):
    """Auto moderation rule was deleted"""

    pass


class AutoModerationActionExecutionEvent(GuildEvent):
    """Auto moderation action was executed"""

    __slots__ = (
        "action",
        "rule_id",
        "rule_trigger_type",
        "user_id",
        "content",
        "matched_keyword",
        "matched_content",
    )

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.action: Dict[str, Any] = data.get("action", {})
        self.rule_id: int = int(data.get("rule_id", 0))
        self.rule_trigger_type: int = data.get("rule_trigger_type", 0)
        self.user_id: int = int(data.get("user_id", 0))
        self.content: str = data.get("content", "")
        self.matched_keyword: Optional[str] = data.get("matched_keyword")
        self.matched_content: Optional[str] = data.get("matched_content")


# Entitlement Events
class EntitlementCreateEvent(BaseEvent):
    """Entitlement was created"""

    pass


class EntitlementUpdateEvent(BaseEvent):
    """Entitlement was updated"""

    pass


class EntitlementDeleteEvent(BaseEvent):
    """Entitlement was deleted"""

    pass


# Message Poll Events
class MessagePollVoteAddEvent(MessageEvent):
    """User voted on a poll"""

    __slots__ = ("user_id", "answer_id")

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.user_id: int = int(data.get("user_id", 0))
        self.answer_id: int = data.get("answer_id", 0)


class MessagePollVoteRemoveEvent(MessageEvent):
    """User removed vote from poll"""

    __slots__ = ("user_id", "answer_id")

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.user_id: int = int(data.get("user_id", 0))
        self.answer_id: int = data.get("answer_id", 0)


# Soundboard Events
class GuildSoundboardSoundCreateEvent(GuildEvent):
    """Soundboard sound was created"""

    __slots__ = ("sound",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.sound: Dict[str, Any] = data


class GuildSoundboardSoundUpdateEvent(GuildEvent):
    """Soundboard sound was updated"""

    __slots__ = ("sound",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.sound: Dict[str, Any] = data


class GuildSoundboardSoundDeleteEvent(GuildEvent):
    """Soundboard sound was deleted"""

    __slots__ = ("sound_id",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.sound_id: int = int(data.get("sound_id", 0))


class GuildSoundboardSoundsUpdateEvent(GuildEvent):
    """Guild soundboard sounds were updated"""

    __slots__ = ("soundboard_sounds",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.soundboard_sounds: List[Dict[str, Any]] = data.get("soundboard_sounds", [])


# Stage Instance Events
class StageInstanceCreateEvent(BaseEvent):
    """Stage instance was created"""

    pass


class StageInstanceUpdateEvent(BaseEvent):
    """Stage instance was updated"""

    pass


class StageInstanceDeleteEvent(BaseEvent):
    """Stage instance was deleted"""

    pass


# Subscription Events
class SubscriptionCreateEvent(GuildEvent):
    """Subscription was created"""

    pass


class SubscriptionUpdateEvent(GuildEvent):
    """Subscription was updated"""

    pass


class SubscriptionDeleteEvent(GuildEvent):
    """Subscription was deleted"""

    pass


# Voice Channel Status Events (NEW in API v10)
class VoiceChannelStatusUpdateEvent(ChannelEvent):
    """Voice channel status was updated"""

    __slots__ = ("status",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.status: Optional[str] = data.get("status")


# Guild Join Request Events (Membership Screening)
class GuildJoinRequestCreateEvent(GuildEvent):
    """Guild join request was created"""

    __slots__ = ("request", "user_id")

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.request: Dict[str, Any] = data.get("request", {})
        self.user_id: int = int(data.get("user_id", 0))


class GuildJoinRequestUpdateEvent(GuildEvent):
    """Guild join request was updated"""

    __slots__ = ("request", "user_id")

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.request: Dict[str, Any] = data.get("request", {})
        self.user_id: int = int(data.get("user_id", 0))


class GuildJoinRequestDeleteEvent(GuildEvent):
    """Guild join request was deleted"""

    __slots__ = ("user_id",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.user_id: int = int(data.get("user_id", 0))


# Bulk Reaction Event (NEW in API v10)
class MessageReactionAddManyEvent(MessageEvent):
    """Multiple reactions were added at once"""

    __slots__ = ("user_ids", "emoji", "count")

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.user_ids: List[int] = [int(uid) for uid in data.get("user_ids", [])]
        self.emoji: Dict[str, Any] = data.get("emoji", {})
        self.count: int = data.get("count", 0)


# Voice Channel Effect Event (NEW)
class VoiceChannelEffectSendEvent(ChannelEvent):
    """Voice channel effect was sent"""

    __slots__ = ("user_id", "emoji", "animation_type", "animation_id")

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.user_id: int = int(data.get("user_id", 0))
        self.emoji: Optional[Dict[str, Any]] = data.get("emoji")
        self.animation_type: Optional[int] = data.get("animation_type")
        self.animation_id: Optional[int] = data.get("animation_id")


# Event type mapping
EVENT_TYPE_MAP = {
    "READY": ReadyEvent,
    "RESUMED": BaseEvent,
    # Channels
    "CHANNEL_CREATE": ChannelCreateEvent,
    "CHANNEL_UPDATE": ChannelUpdateEvent,
    "CHANNEL_DELETE": ChannelDeleteEvent,
    "CHANNEL_PINS_UPDATE": ChannelPinsUpdateEvent,
    "VOICE_CHANNEL_STATUS_UPDATE": VoiceChannelStatusUpdateEvent,  # NEW
    # Threads
    "THREAD_CREATE": ThreadCreateEvent,
    "THREAD_UPDATE": ThreadUpdateEvent,
    "THREAD_DELETE": ThreadDeleteEvent,
    "THREAD_LIST_SYNC": ThreadListSyncEvent,
    "THREAD_MEMBER_UPDATE": ThreadMemberUpdateEvent,
    "THREAD_MEMBERS_UPDATE": ThreadMembersUpdateEvent,
    # Guilds
    "GUILD_CREATE": GuildCreateEvent,
    "GUILD_UPDATE": GuildUpdateEvent,
    "GUILD_DELETE": GuildDeleteEvent,
    "GUILD_BAN_ADD": GuildBanAddEvent,
    "GUILD_BAN_REMOVE": GuildBanRemoveEvent,
    "GUILD_EMOJIS_UPDATE": GuildEmojisUpdateEvent,
    "GUILD_STICKERS_UPDATE": GuildStickersUpdateEvent,
    "GUILD_INTEGRATIONS_UPDATE": GuildIntegrationsUpdateEvent,
    "GUILD_MEMBER_ADD": GuildMemberAddEvent,
    "GUILD_MEMBER_REMOVE": GuildMemberRemoveEvent,
    "GUILD_MEMBER_UPDATE": GuildMemberUpdateEvent,
    "GUILD_MEMBERS_CHUNK": GuildMembersChunkEvent,
    "GUILD_ROLE_CREATE": GuildRoleCreateEvent,
    "GUILD_ROLE_UPDATE": GuildRoleUpdateEvent,
    "GUILD_ROLE_DELETE": GuildRoleDeleteEvent,
    "GUILD_SCHEDULED_EVENT_CREATE": GuildScheduledEventCreateEvent,
    "GUILD_SCHEDULED_EVENT_UPDATE": GuildScheduledEventUpdateEvent,
    "GUILD_SCHEDULED_EVENT_DELETE": GuildScheduledEventDeleteEvent,
    "GUILD_SCHEDULED_EVENT_USER_ADD": GuildScheduledEventUserAddEvent,
    "GUILD_SCHEDULED_EVENT_USER_REMOVE": GuildScheduledEventUserRemoveEvent,
    "GUILD_JOIN_REQUEST_CREATE": GuildJoinRequestCreateEvent,  # NEW
    "GUILD_JOIN_REQUEST_UPDATE": GuildJoinRequestUpdateEvent,  # NEW
    "GUILD_JOIN_REQUEST_DELETE": GuildJoinRequestDeleteEvent,  # NEW
    # Integrations
    "INTEGRATION_CREATE": IntegrationCreateEvent,
    "INTEGRATION_UPDATE": IntegrationUpdateEvent,
    "INTEGRATION_DELETE": IntegrationDeleteEvent,
    # Interactions
    "INTERACTION_CREATE": InteractionCreateEvent,
    # Invites
    "INVITE_CREATE": InviteCreateEvent,
    "INVITE_DELETE": InviteDeleteEvent,
    # Messages
    "MESSAGE_CREATE": MessageCreateEvent,
    "MESSAGE_UPDATE": MessageUpdateEvent,
    "MESSAGE_DELETE": MessageDeleteEvent,
    "MESSAGE_DELETE_BULK": MessageDeleteBulkEvent,
    "MESSAGE_REACTION_ADD": MessageReactionAddEvent,
    "MESSAGE_REACTION_REMOVE": MessageReactionRemoveEvent,
    "MESSAGE_REACTION_REMOVE_ALL": MessageReactionRemoveAllEvent,
    "MESSAGE_REACTION_REMOVE_EMOJI": MessageReactionRemoveEmojiEvent,
    "MESSAGE_REACTION_ADD_MANY": MessageReactionAddManyEvent,  # NEW
    # Presence & Typing
    "PRESENCE_UPDATE": PresenceUpdateEvent,
    "TYPING_START": TypingStartEvent,
    "USER_UPDATE": UserUpdateEvent,
    # Voice
    "VOICE_STATE_UPDATE": VoiceStateUpdateEvent,
    "VOICE_SERVER_UPDATE": VoiceServerUpdateEvent,
    "VOICE_CHANNEL_EFFECT_SEND": VoiceChannelEffectSendEvent,
    # Webhooks
    "WEBHOOKS_UPDATE": WebhooksUpdateEvent,
    # Auto Moderation
    "AUTO_MODERATION_RULE_CREATE": AutoModerationRuleCreateEvent,
    "AUTO_MODERATION_RULE_UPDATE": AutoModerationRuleUpdateEvent,
    "AUTO_MODERATION_RULE_DELETE": AutoModerationRuleDeleteEvent,
    "AUTO_MODERATION_ACTION_EXECUTION": AutoModerationActionExecutionEvent,
    # Entitlements
    "ENTITLEMENT_CREATE": EntitlementCreateEvent,
    "ENTITLEMENT_UPDATE": EntitlementUpdateEvent,
    "ENTITLEMENT_DELETE": EntitlementDeleteEvent,
    # Polls
    "MESSAGE_POLL_VOTE_ADD": MessagePollVoteAddEvent,
    "MESSAGE_POLL_VOTE_REMOVE": MessagePollVoteRemoveEvent,
    # Stage Instances
    "STAGE_INSTANCE_CREATE": StageInstanceCreateEvent,
    "STAGE_INSTANCE_UPDATE": StageInstanceUpdateEvent,
    "STAGE_INSTANCE_DELETE": StageInstanceDeleteEvent,
    # Subscriptions
    "SUBSCRIPTION_CREATE": SubscriptionCreateEvent,
    "SUBSCRIPTION_UPDATE": SubscriptionUpdateEvent,
    "SUBSCRIPTION_DELETE": SubscriptionDeleteEvent,
}


def create_event(event_type: str, data: Dict[str, Any]) -> BaseEvent:
    """
    Create an event object from gateway data

    Args:
        event_type: The event type name (e.g., 'MESSAGE_CREATE')
        data: The event data

    Returns:
        Event object instance
    """
    event_class = EVENT_TYPE_MAP.get(event_type, BaseEvent)
    return event_class(data)
