"""
Text Input component - Input fields for modals

Text inputs allow users to enter text in modals (forms).
"""

from __future__ import annotations

from enum import IntEnum
from typing import TYPE_CHECKING, Any, Awaitable, Callable, Optional

if TYPE_CHECKING:
    from ..models.interaction import Interaction


class TextInputStyle(IntEnum):
    """Text input styles"""

    SHORT = 1  # Single-line input
    PARAGRAPH = 2  # Multi-line input

    # Aliases
    short = 1
    paragraph = 2
    single_line = 1
    multi_line = 2


class TextInput:
    """
    Text input component for modals.

    Text inputs allow users to enter text in modal forms.

    Attributes:
        custom_id: Custom ID for callback routing (max 100 chars)
        style: Input style (short or paragraph)
        label: Label displayed above input (max 45 chars)
        min_length: Minimum input length (0-4000)
        max_length: Maximum input length (1-4000)
        required: Whether input is required
        value: Pre-filled value (max 4000 chars)
        placeholder: Placeholder text (max 100 chars)

    Example:
        ```python
        text_input = TextInput(
            label="Username",
            custom_id="username",
            style=TextInputStyle.SHORT,
            placeholder="Enter your username",
            min_length=3,
            max_length=20,
            required=True
        )

        modal.add_item(text_input)
        ```
    """

    __slots__ = (
        "custom_id",
        "style",
        "label",
        "min_length",
        "max_length",
        "required",
        "value",
        "placeholder",
        "_row",
    )

    def __init__(
        self,
        *,
        label: str,
        custom_id: str,
        style: TextInputStyle = TextInputStyle.SHORT,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
        required: bool = True,
        value: Optional[str] = None,
        placeholder: Optional[str] = None,
    ):
        self.label = label
        self.custom_id = custom_id
        self.style = style
        self.min_length = min_length
        self.max_length = max_length
        self.required = required
        self.value = value
        self.placeholder = placeholder
        self._row: Optional[int] = None

        # Validation
        if len(label) > 45:
            raise ValueError("Label must be 45 characters or less")

        if len(custom_id) > 100:
            raise ValueError("custom_id must be 100 characters or less")

        if min_length is not None:
            if not (0 <= min_length <= 4000):
                raise ValueError("min_length must be between 0 and 4000")

        if max_length is not None:
            if not (1 <= max_length <= 4000):
                raise ValueError("max_length must be between 1 and 4000")

        if min_length and max_length and min_length > max_length:
            raise ValueError("min_length cannot be greater than max_length")

        if value and len(value) > 4000:
            raise ValueError("value must be 4000 characters or less")

        if placeholder and len(placeholder) > 100:
            raise ValueError("placeholder must be 100 characters or less")

    def to_dict(self) -> dict:
        """Convert text input to API format"""
        data = {
            "type": 4,  # Text input type
            "custom_id": self.custom_id,
            "style": int(self.style),
            "label": self.label,
            "required": self.required,
        }

        if self.min_length is not None:
            data["min_length"] = self.min_length

        if self.max_length is not None:
            data["max_length"] = self.max_length

        if self.value is not None:
            data["value"] = self.value

        if self.placeholder is not None:
            data["placeholder"] = self.placeholder

        return data

    @classmethod
    def short(
        cls,
        *,
        label: str,
        custom_id: str,
        placeholder: Optional[str] = None,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
        required: bool = True,
        value: Optional[str] = None,
    ) -> TextInput:
        """
        Create a short (single-line) text input.

        Example:
            ```python
            username = TextInput.short(
                label="Username",
                custom_id="username",
                placeholder="Enter username",
                min_length=3,
                max_length=20
            )
            ```
        """
        return cls(
            label=label,
            custom_id=custom_id,
            style=TextInputStyle.SHORT,
            placeholder=placeholder,
            min_length=min_length,
            max_length=max_length,
            required=required,
            value=value,
        )

    @classmethod
    def paragraph(
        cls,
        *,
        label: str,
        custom_id: str,
        placeholder: Optional[str] = None,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
        required: bool = True,
        value: Optional[str] = None,
    ) -> TextInput:
        """
        Create a paragraph (multi-line) text input.

        Example:
            ```python
            bio = TextInput.paragraph(
                label="About You",
                custom_id="bio",
                placeholder="Tell us about yourself",
                max_length=1000
            )
            ```
        """
        return cls(
            label=label,
            custom_id=custom_id,
            style=TextInputStyle.PARAGRAPH,
            placeholder=placeholder,
            min_length=min_length,
            max_length=max_length,
            required=required,
            value=value,
        )

    def __repr__(self) -> str:
        return (
            f"<TextInput label={self.label!r} custom_id={self.custom_id!r} style={self.style.name}>"
        )
