"""
Button component - Interactive buttons for Discord messages
"""

from __future__ import annotations

from enum import IntEnum
from typing import TYPE_CHECKING, Any, Awaitable, Callable, Optional

if TYPE_CHECKING:
    from ..models.interaction import Interaction


class ButtonStyle(IntEnum):
    """Button styles"""

    PRIMARY = 1  # Blurple
    SECONDARY = 2  # Grey
    SUCCESS = 3  # Green
    DANGER = 4  # Red
    LINK = 5  # Grey with link
    PREMIUM = 6  # Purple (premium)

    # Aliases
    primary = 1
    secondary = 2
    success = 3
    danger = 4
    link = 5
    premium = 6
    blurple = 1
    grey = 2
    gray = 2
    green = 3
    red = 4


class Button:
    """
    Represents a button component.

    Buttons can be added to messages to create interactive interfaces.

    Attributes:
        label: Button text (max 80 chars)
        custom_id: Custom ID for callback routing (max 100 chars)
        style: Button style (color)
        emoji: Emoji to display
        url: URL for link buttons
        disabled: Whether button is disabled
        callback: Async function to call on click

    Example:
        ```python
        button = Button(
            label="Click me!",
            custom_id="my_button",
            style=ButtonStyle.PRIMARY
        )

        # With callback
        async def on_click(interaction):
            await interaction.response.send_message("Clicked!")

        button = Button(
            label="Click",
            custom_id="btn",
            callback=on_click
        )
        ```
    """

    __slots__ = ("label", "custom_id", "style", "emoji", "url", "disabled", "callback", "_row")

    def __init__(
        self,
        *,
        label: Optional[str] = None,
        custom_id: Optional[str] = None,
        style: ButtonStyle = ButtonStyle.PRIMARY,
        emoji: Optional[str] = None,
        url: Optional[str] = None,
        disabled: bool = False,
        callback: Optional[Callable[[Interaction], Awaitable[Any]]] = None,
    ):
        self.label = label
        self.custom_id = custom_id
        self.style = style
        self.emoji = emoji
        self.url = url
        self.disabled = disabled
        self.callback = callback
        self._row: Optional[int] = None

        # Validation
        if style == ButtonStyle.LINK:
            if not url:
                raise ValueError("Link buttons must have a URL")
            if custom_id:
                raise ValueError("Link buttons cannot have custom_id")
        else:
            if not custom_id:
                raise ValueError("Non-link buttons must have custom_id")
            if url:
                raise ValueError("Only link buttons can have URLs")

        if not label and not emoji:
            raise ValueError("Button must have label or emoji")

    def to_dict(self) -> dict:
        """Convert button to API format"""
        data = {
            "type": 2,  # Button type
            "style": int(self.style),
            "disabled": self.disabled,
        }

        if self.label:
            data["label"] = self.label

        if self.custom_id:
            data["custom_id"] = self.custom_id

        if self.url:
            data["url"] = self.url

        if self.emoji:
            # Parse emoji (can be string like "👍" or dict)
            if isinstance(self.emoji, str):
                # Check if custom emoji format <:name:id> or <a:name:id>
                if self.emoji.startswith("<") and self.emoji.endswith(">"):
                    # Custom emoji
                    parts = self.emoji[1:-1].split(":")
                    if len(parts) == 3:
                        animated = parts[0] == "a"
                        name = parts[1]
                        emoji_id = parts[2]
                        data["emoji"] = {"name": name, "id": emoji_id, "animated": animated}
                    else:
                        data["emoji"] = {"name": self.emoji}
                else:
                    # Unicode emoji
                    data["emoji"] = {"name": self.emoji}
            else:
                data["emoji"] = self.emoji

        return data

    async def invoke(self, interaction: Interaction) -> Any:
        """Invoke the button's callback"""
        if self.callback:
            return await self.callback(interaction)

    def __repr__(self) -> str:
        return f"<Button label={self.label!r} custom_id={self.custom_id!r} style={self.style.name}>"
