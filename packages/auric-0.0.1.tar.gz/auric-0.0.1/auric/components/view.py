"""
View system for message components - Container for interactive components
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Union

if TYPE_CHECKING:
    from ..models.interaction import Interaction
    from ..models.message import Message
    from .button import Button
    from .select import Select

logger = logging.getLogger(__name__)


class View:
    """
    Container for message components (buttons and selects).

    Views manage component layout, callbacks, and timeouts.

    Attributes:
        timeout: Timeout in seconds (None = no timeout)
        message: Message this view is attached to

    Example:
        ```python
        class MyView(View):
            def __init__(self):
                super().__init__(timeout=180)

            @auric.ui.button(label="Click me!", style=ButtonStyle.PRIMARY)
            async def button_callback(self, interaction, button):
                await interaction.response.send_message("Clicked!")

        view = MyView()
        await channel.send("Click a button!", view=view)
        ```

    Simple usage:
        ```python
        view = View()

        async def on_click(interaction):
            await interaction.response.send_message("Clicked!")

        button = Button(label="Click", custom_id="btn", callback=on_click)
        view.add_item(button)

        await channel.send("Click!", view=view)
        ```
    """

    def __init__(self, *, timeout: Optional[float] = 180.0):
        self.timeout = timeout
        self.message: Optional[Message] = None
        self._children: List[Union[Button, Select]] = []
        self._timeout_task: Optional[asyncio.Task] = None
        self._stopped = False

    def add_item(self, item: Union[Button, Select]) -> View:
        """
        Add a component to the view.

        Args:
            item: Button or Select to add

        Returns:
            Self for chaining

        Raises:
            ValueError: If view is full or item is invalid
        """
        if len(self._children) >= 25:
            raise ValueError("View cannot have more than 25 components")

        self._children.append(item)
        return self

    def remove_item(self, item: Union[Button, Select]) -> View:
        """
        Remove a component from the view.

        Args:
            item: Button or Select to remove

        Returns:
            Self for chaining
        """
        try:
            self._children.remove(item)
        except ValueError:
            logger.debug(f"Item not found in view: {item}")
        return self

    def clear_items(self) -> View:
        """
        Remove all components from the view.

        Returns:
            Self for chaining
        """
        self._children.clear()
        return self

    @property
    def children(self) -> List[Union[Button, Select]]:
        """List of all components in this view"""
        return self._children.copy()

    def to_dict(self) -> List[Dict[str, Any]]:
        """
        Convert view to API format (action rows).

        Returns:
            List of action row dicts
        """
        if not self._children:
            return []

        # Group components into action rows
        # Each row can have up to 5 buttons or 1 select
        rows: List[List[Union[Button, Select]]] = []
        current_row: List[Union[Button, Select]] = []

        for item in self._children:
            from .button import Button
            from .select import Select

            # Selects take entire row
            if isinstance(item, Select):
                if current_row:
                    rows.append(current_row)
                    current_row = []
                rows.append([item])
            # Buttons can be grouped (max 5 per row)
            elif isinstance(item, Button):
                if len(current_row) >= 5:
                    rows.append(current_row)
                    current_row = []
                current_row.append(item)

        # Add remaining buttons
        if current_row:
            rows.append(current_row)

        # Convert to API format
        return [
            {"type": 1, "components": [item.to_dict() for item in row]}  # Action row
            for row in rows
        ]

    async def _dispatch(self, custom_id: str, interaction: Interaction) -> None:
        """
        Dispatch interaction to appropriate callback.

        Args:
            custom_id: Custom ID of clicked component
            interaction: Interaction object
        """
        # Find component with matching custom_id
        for item in self._children:
            if hasattr(item, "custom_id") and item.custom_id == custom_id:
                try:
                    await item.invoke(interaction)
                except Exception as e:
                    # Call on_error if defined
                    if hasattr(self, "on_error"):
                        await self.on_error(interaction, e, item)
                    else:
                        raise
                return

    async def on_timeout(self) -> None:
        """
        Called when the view times out.

        Override this to add custom timeout behavior.
        """
        logger.info(f"View timeout triggered for {self.__class__.__name__}")

    async def on_error(self, interaction: Interaction, error: Exception, item: Any) -> None:
        """
        Called when an error occurs in a callback.

        Override this to add custom error handling.

        Args:
            interaction: The interaction
            error: The exception that occurred
            item: The component that errored
        """
        raise error

    def stop(self) -> None:
        """
        Stop the view and cancel timeout.

        This prevents any further interactions from being processed.
        """
        self._stopped = True
        if self._timeout_task:
            self._timeout_task.cancel()
            self._timeout_task = None

    def is_finished(self) -> bool:
        """Check if view is finished (stopped or timed out)"""
        return self._stopped

    async def wait(self) -> None:
        """
        Wait for the view to finish (stop or timeout).

        Example:
            ```python
            view = MyView()
            await message.edit(view=view)
            await view.wait()  # Wait until view is done
            ```
        """
        if self.timeout:
            self._timeout_task = asyncio.create_task(asyncio.sleep(self.timeout))
            try:
                await self._timeout_task
                if not self._stopped:
                    await self.on_timeout()
            except asyncio.CancelledError:
                logger.debug(f"View timeout cancelled for {self.__class__.__name__}")
            except Exception as e:
                logger.error(f"Error in view timeout: {e}", exc_info=True)
        else:
            # No timeout - wait indefinitely
            while not self._stopped:
                await asyncio.sleep(1)

    def __repr__(self) -> str:
        return f"<View timeout={self.timeout} children={len(self._children)}>"


# Helper for simple view creation
def create_view(*items: Union[Button, Select], timeout: Optional[float] = 180.0) -> View:
    """
    Create a view with components.

    Args:
        *items: Buttons or Selects to add
        timeout: View timeout in seconds

    Returns:
        View with components

    Example:
        ```python
        view = create_view(
            Button(label="Yes", custom_id="yes", style=ButtonStyle.SUCCESS),
            Button(label="No", custom_id="no", style=ButtonStyle.DANGER),
            timeout=60.0
        )
        ```
    """
    view = View(timeout=timeout)
    for item in items:
        view.add_item(item)
    return view
