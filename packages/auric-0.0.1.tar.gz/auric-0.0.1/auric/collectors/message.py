"""
Message Collector - Collect messages with filters
"""

from typing import TYPE_CHECKING, Callable, Optional

from .base import BaseCollector, CollectorEndReason

if TYPE_CHECKING:
    from ..core.client import Client
    from ..models.channel import Channel
    from ..models.message import Message


class MessageCollector(BaseCollector):
    """
    Collect messages in a channel with optional filters

    This is one of the most useful collectors - collect messages based on
    author, content, attachments, or any custom criteria!

    Args:
        channel: Channel to collect messages from
        client: Bot client instance
        filter: Function to filter messages (return True to collect)
        time: Time in seconds before collector ends
        max: Maximum number of messages to collect
        idle: Time of inactivity before ending

    Example:
        ```python
        # Collect messages from specific user for 60 seconds
        collector = MessageCollector(
            channel=channel,
            client=bot,
            filter=lambda m: m.author.id == user.id,
            time=60,
            max=5
        )

        @collector.event
        async def on_collect(message):
            print(f"Got: {message.content}")

        @collector.event
        async def on_end(collected, reason):
            print(f"Collected {len(collected)} messages!")

        messages = await collector.start()
        ```

        ```python
        # Collect messages with attachments
        collector = MessageCollector(
            channel=channel,
            client=bot,
            filter=lambda m: len(m.attachments) > 0,
            max=3
        )

        images = await collector.start()
        ```

        ```python
        # Quiz question collector
        async def ask_question(channel, question, correct_answer):
            await channel.send(question)

            collector = MessageCollector(
                channel=channel,
                client=bot,
                max=1,
                time=30,
                filter=lambda m: m.author.id == user_id
            )

            @collector.event
            async def on_collect(msg):
                if msg.content.lower() == correct_answer.lower():
                    await channel.send("✅ Correct!")
                else:
                    await channel.send("❌ Wrong!")

            @collector.event
            async def on_end(collected, reason):
                if reason == CollectorEndReason.TIME:
                    await channel.send("⏰ Time's up!")

            await collector.start()
        ```
    """

    def __init__(
        self,
        channel: "Channel",
        client: "Client",
        filter: Optional[Callable[["Message"], bool]] = None,
        *,
        time: Optional[float] = None,
        max: Optional[int] = None,
        idle: Optional[float] = None,
        dispose: bool = False,
    ):
        super().__init__(filter=filter, time=time, max=max, idle=idle, dispose=dispose)
        self.channel = channel
        self.client = client
        self._listener_id: Optional[str] = None

    async def _setup_listeners(self) -> None:
        """Setup message event listener"""

        # Register a listener for message events
        async def on_message(message: "Message"):
            # Only collect messages from our channel
            if message.channel_id == self.channel.id:
                await self.collect(message)

        # Store reference to our listener
        self._listener_id = id(on_message)

        # Add listener to client
        self.client.add_listener("on_message", on_message)

    async def _cleanup_listeners(self) -> None:
        """Cleanup message event listener"""
        # Remove our listener from client
        if self._listener_id:
            self.client.remove_listener("on_message", self._listener_id)


class AwaitMessageCollector(MessageCollector):
    """
    Simplified message collector that waits for a single message

    This is a convenience wrapper around MessageCollector for the common
    use case of waiting for one message.

    Example:
        ```python
        await ctx.send("What's your name?")

        message = await AwaitMessageCollector(
            channel=ctx.channel,
            client=bot,
            filter=lambda m: m.author == ctx.author,
            time=30
        ).get()

        await ctx.send(f"Hello {message.content}!")
        ```
    """

    def __init__(
        self,
        channel: "Channel",
        client: "Client",
        filter: Optional[Callable[["Message"], bool]] = None,
        *,
        time: Optional[float] = 30,
    ):
        super().__init__(
            channel=channel,
            client=client,
            filter=filter,
            time=time,
            max=1,
        )

    async def get(self) -> Optional["Message"]:
        """
        Wait for and return the first matching message

        Returns:
            The collected message, or None if timed out
        """
        collected = await self.start()
        return collected[0] if collected else None
