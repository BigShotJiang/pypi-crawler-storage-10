"""
Common filter functions for collectors
"""

from typing import Any, Callable, List, Union


def author_filter(author_id: str) -> Callable:
    """
    Filter messages by author

    Example:
        collector = MessageCollector(
            channel=channel,
            client=bot,
            filter=filters.author_filter(user.id)
        )
    """
    return lambda m: m.author.id == author_id


def content_filter(content: str, case_sensitive: bool = False) -> Callable:
    """
    Filter messages by exact content

    Example:
        collector = MessageCollector(
            channel=channel,
            client=bot,
            filter=filters.content_filter("yes")
        )
    """
    if case_sensitive:
        return lambda m: m.content == content
    else:
        return lambda m: m.content.lower() == content.lower()


def contains_filter(text: str, case_sensitive: bool = False) -> Callable:
    """
    Filter messages that contain specific text

    Example:
        collector = MessageCollector(
            channel=channel,
            client=bot,
            filter=filters.contains_filter("hello")
        )
    """
    if case_sensitive:
        return lambda m: text in m.content
    else:
        return lambda m: text.lower() in m.content.lower()


def attachment_filter(min_attachments: int = 1) -> Callable:
    """
    Filter messages with attachments

    Example:
        # Collect messages with at least 1 image
        collector = MessageCollector(
            channel=channel,
            client=bot,
            filter=filters.attachment_filter()
        )
    """
    return lambda m: len(m.attachments) >= min_attachments


def emoji_filter(*emojis: str) -> Callable:
    """
    Filter reactions by emoji

    Example:
        collector = ReactionCollector(
            message=message,
            client=bot,
            filter=filters.emoji_filter("👍", "👎")
        )
    """
    emoji_set = set(emojis)

    def check(reaction):
        emoji = reaction.get("emoji", {})
        emoji_str = emoji.get("name") or str(emoji.get("id"))
        return emoji_str in emoji_set

    return check


def user_filter(*user_ids: str) -> Callable:
    """
    Filter by specific users

    Example:
        collector = MessageCollector(
            channel=channel,
            client=bot,
            filter=filters.user_filter(user1.id, user2.id)
        )
    """
    user_set = set(user_ids)
    return lambda item: getattr(item, "author", item).id in user_set


def custom_id_filter(*custom_ids: str) -> Callable:
    """
    Filter interactions by custom_id

    Example:
        collector = InteractionCollector(
            message=message,
            client=bot,
            filter=filters.custom_id_filter("button1", "button2")
        )
    """
    id_set = set(custom_ids)
    return lambda i: i.data.get("custom_id") in id_set


def and_filter(*filters: Callable) -> Callable:
    """
    Combine multiple filters with AND logic

    Example:
        collector = MessageCollector(
            channel=channel,
            client=bot,
            filter=filters.and_filter(
                filters.author_filter(user.id),
                filters.contains_filter("yes")
            )
        )
    """

    def check(item):
        return all(f(item) for f in filters)

    return check


def or_filter(*filters: Callable) -> Callable:
    """
    Combine multiple filters with OR logic

    Example:
        collector = MessageCollector(
            channel=channel,
            client=bot,
            filter=filters.or_filter(
                filters.content_filter("yes"),
                filters.content_filter("y")
            )
        )
    """

    def check(item):
        return any(f(item) for f in filters)

    return check


def not_filter(filter: Callable) -> Callable:
    """
    Negate a filter

    Example:
        # Collect messages NOT from bots
        collector = MessageCollector(
            channel=channel,
            client=bot,
            filter=filters.not_filter(lambda m: m.author.bot)
        )
    """
    return lambda item: not filter(item)


def bot_filter(is_bot: bool = False) -> Callable:
    """
    Filter messages by bot status

    Example:
        # Exclude bot messages
        collector = MessageCollector(
            channel=channel,
            client=bot,
            filter=filters.bot_filter(False)
        )
    """
    return lambda m: m.author.bot == is_bot


def length_filter(min_length: int = 0, max_length: int = float("inf")) -> Callable:
    """
    Filter messages by content length

    Example:
        # Collect messages between 10-100 characters
        collector = MessageCollector(
            channel=channel,
            client=bot,
            filter=filters.length_filter(10, 100)
        )
    """
    return lambda m: min_length <= len(m.content) <= max_length


# Pre-made common filters
not_bot = bot_filter(False)
only_bot = bot_filter(True)
has_attachment = attachment_filter(1)
