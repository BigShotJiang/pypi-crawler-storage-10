"""
Interaction Collector - Collect interactions (buttons, selects, etc.)
"""

from typing import TYPE_CHECKING, Callable, Optional

from .base import BaseCollector

if TYPE_CHECKING:
    from ..core.client import Client
    from ..models.message import Message


class InteractionCollector(BaseCollector):
    """
    Collect interactions on a message (buttons, select menus, etc.)

    This is essential for interactive bots with buttons and select menus!

    Args:
        message: Message to collect interactions from
        client: Bot client instance
        filter: Function to filter interactions
        time: Time in seconds before collector ends
        max: Maximum number of interactions to collect
        idle: Time of inactivity before ending

    Example:
        ```python
        # Button menu
        view = View()
        view.add_item(Button(label="Option 1", custom_id="opt1"))
        view.add_item(Button(label="Option 2", custom_id="opt2"))

        message = await channel.send("Choose an option:", view=view)

        collector = InteractionCollector(
            message=message,
            client=bot,
            filter=lambda i: i.user.id == user.id,
            max=1,
            time=30
        )

        @collector.event
        async def on_collect(interaction):
            await interaction.respond(f"You chose {interaction.custom_id}!")

        await collector.start()
        ```

        ```python
        # Paginated menu
        collector = InteractionCollector(
            message=message,
            client=bot,
            filter=lambda i: i.custom_id in ["prev", "next"],
            time=300  # 5 minutes
        )

        @collector.event
        async def on_collect(interaction):
            if interaction.custom_id == "next":
                current_page += 1
            else:
                current_page -= 1

            await interaction.update(embed=pages[current_page])

        await collector.start()
        ```
    """

    def __init__(
        self,
        message: Optional["Message"] = None,
        client: "Client" = None,
        filter: Optional[Callable] = None,
        *,
        time: Optional[float] = None,
        max: Optional[int] = None,
        idle: Optional[float] = None,
        dispose: bool = False,
        custom_id: Optional[str] = None,
    ):
        super().__init__(filter=filter, time=time, max=max, idle=idle, dispose=dispose)
        self.message = message
        self.client = client
        self.custom_id = custom_id
        self._listener_id: Optional[str] = None

    async def _setup_listeners(self) -> None:
        """Setup interaction event listener"""

        async def on_interaction(interaction):
            # Filter by message if specified
            if self.message and interaction.message.id != self.message.id:
                return

            # Filter by custom_id if specified
            if self.custom_id and interaction.data.get("custom_id") != self.custom_id:
                return

            # Filter by interaction type (component interactions only)
            from ..types.interaction import InteractionType

            if interaction.type != InteractionType.MESSAGE_COMPONENT:
                return

            await self.collect(interaction)

        self._listener_id = id(on_interaction)
        self.client.add_listener("on_interaction", on_interaction)

    async def _cleanup_listeners(self) -> None:
        """Cleanup interaction event listener"""
        if self._listener_id:
            self.client.remove_listener("on_interaction", self._listener_id)

    def _get_item_id(self, item):
        """Get unique ID for interaction"""
        return item.id


# Alias for convenience
ComponentCollector = InteractionCollector


class AwaitInteractionCollector(InteractionCollector):
    """
    Simplified interaction collector that waits for a single interaction

    Example:
        ```python
        view = View()
        view.add_item(Button(label="Click me!", custom_id="click"))

        message = await ctx.send("Click the button!", view=view)

        interaction = await AwaitInteractionCollector(
            message=message,
            client=bot,
            filter=lambda i: i.user == ctx.author,
            time=60
        ).get()

        if interaction:
            await interaction.respond("Button clicked!")
        ```
    """

    def __init__(
        self,
        message: Optional["Message"] = None,
        client: "Client" = None,
        filter: Optional[Callable] = None,
        *,
        time: Optional[float] = 60,
        custom_id: Optional[str] = None,
    ):
        super().__init__(
            message=message,
            client=client,
            filter=filter,
            time=time,
            max=1,
            custom_id=custom_id,
        )

    async def get(self):
        """
        Wait for and return the first matching interaction

        Returns:
            The interaction, or None if timed out
        """
        collected = await self.start()
        return collected[0] if collected else None
