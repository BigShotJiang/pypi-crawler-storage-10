"""
Reaction Collector - Collect reactions on a message
"""

from typing import TYPE_CHECKING, Callable, Optional

from .base import BaseCollector

if TYPE_CHECKING:
    from ..core.client import Client
    from ..models.message import Message


class ReactionCollector(BaseCollector):
    """
    Collect reactions on a specific message

    Perfect for polls, quizzes, confirmation prompts, and any interaction
    that uses reactions!

    Args:
        message: Message to collect reactions from
        client: Bot client instance
        filter: Function to filter reactions (return True to collect)
        time: Time in seconds before collector ends
        max: Maximum number of reactions to collect
        idle: Time of inactivity before ending

    Example:
        ```python
        # Simple poll
        message = await channel.send("React to vote!")
        await message.add_reaction("👍")
        await message.add_reaction("👎")

        collector = ReactionCollector(
            message=message,
            client=bot,
            time=60
        )

        @collector.event
        async def on_end(reactions, reason):
            thumbs_up = len([r for r in reactions if r.emoji == "👍"])
            thumbs_down = len([r for r in reactions if r.emoji == "👎"])
            await channel.send(f"Results: 👍 {thumbs_up} | 👎 {thumbs_down}")

        await collector.start()
        ```

        ```python
        # Collect reactions from specific user
        collector = ReactionCollector(
            message=message,
            client=bot,
            filter=lambda r: r.user_id == user.id,
            max=1,
            time=30
        )

        @collector.event
        async def on_collect(reaction):
            await channel.send(f"You reacted with {reaction.emoji}")

        await collector.start()
        ```

        ```python
        # Confirmation prompt
        async def confirm(channel, user, prompt):
            message = await channel.send(f"{prompt}\nReact with ✅ or ❌")
            await message.add_reaction("✅")
            await message.add_reaction("❌")

            collector = ReactionCollector(
                message=message,
                client=bot,
                filter=lambda r: r.user_id == user.id and r.emoji in ["✅", "❌"],
                max=1,
                time=30
            )

            reactions = await collector.start()
            if reactions and reactions[0].emoji == "✅":
                return True
            return False

        if await confirm(channel, user, "Delete all messages?"):
            await channel.purge()
        ```
    """

    def __init__(
        self,
        message: "Message",
        client: "Client",
        filter: Optional[Callable] = None,
        *,
        time: Optional[float] = None,
        max: Optional[int] = None,
        idle: Optional[float] = None,
        dispose: bool = False,
    ):
        super().__init__(filter=filter, time=time, max=max, idle=idle, dispose=dispose)
        self.message = message
        self.client = client
        self._listener_id: Optional[str] = None

    async def _setup_listeners(self) -> None:
        """Setup reaction event listener"""

        async def on_reaction_add(payload):
            # Only collect reactions on our message
            if payload.get("message_id") == self.message.id:
                await self.collect(payload)

        self._listener_id = id(on_reaction_add)
        self.client.add_listener("on_reaction_add", on_reaction_add)

    async def _cleanup_listeners(self) -> None:
        """Cleanup reaction event listener"""
        if self._listener_id:
            self.client.remove_listener("on_reaction_add", self._listener_id)

    def _get_item_id(self, item):
        """Get unique ID for reaction (user_id + emoji)"""
        user_id = item.get("user_id")
        emoji = item.get("emoji", {})
        emoji_id = emoji.get("id") or emoji.get("name")
        return f"{user_id}:{emoji_id}"


class AwaitReactionCollector(ReactionCollector):
    """
    Simplified reaction collector that waits for a single reaction

    Example:
        ```python
        message = await ctx.send("React with ✅ to confirm")
        await message.add_reaction("✅")

        reaction = await AwaitReactionCollector(
            message=message,
            client=bot,
            filter=lambda r: r.user_id == ctx.author.id and r.emoji == "✅",
            time=30
        ).get()

        if reaction:
            await ctx.send("Confirmed!")
        ```
    """

    def __init__(
        self,
        message: "Message",
        client: "Client",
        filter: Optional[Callable] = None,
        *,
        time: Optional[float] = 30,
    ):
        super().__init__(
            message=message,
            client=client,
            filter=filter,
            time=time,
            max=1,
        )

    async def get(self) -> Optional[dict]:
        """
        Wait for and return the first matching reaction

        Returns:
            The reaction payload, or None if timed out
        """
        collected = await self.start()
        return collected[0] if collected else None
