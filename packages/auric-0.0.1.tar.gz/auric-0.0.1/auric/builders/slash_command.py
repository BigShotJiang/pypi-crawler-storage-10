"""
Slash command builder - Fluent API for building slash commands
"""

from typing import Any, Callable, Dict, List, Optional

from ..models.slash_command import CommandOption, MessageCommand, SlashCommand, UserCommand
from ..types.interaction import ApplicationCommandOptionType, ApplicationCommandType


class SlashCommandBuilder:
    """
    Fluent builder for slash commands

    Example:
        ```python
        command = (SlashCommandBuilder()
            .set_name("hello")
            .set_description("Say hello!")
            .add_string_option("name", "Your name", required=True)
            .add_integer_option("age", "Your age")
            .build())
        ```
    """

    def __init__(self):
        self._name: Optional[str] = None
        self._description: Optional[str] = None
        self._options: List[CommandOption] = []
        self._dm_permission: bool = True
        self._default_member_permissions: Optional[str] = None
        self._nsfw: bool = False
        self._callback: Optional[Callable] = None

    def set_name(self, name: str) -> "SlashCommandBuilder":
        """Set the command name"""
        if not name or len(name) > 32:
            raise ValueError("Name must be 1-32 characters")
        self._name = name.lower()
        return self

    def set_description(self, description: str) -> "SlashCommandBuilder":
        """Set the command description"""
        if not description or len(description) > 100:
            raise ValueError("Description must be 1-100 characters")
        self._description = description
        return self

    def add_option(self, option: CommandOption) -> "SlashCommandBuilder":
        """Add a command option"""
        if len(self._options) >= 25:
            raise ValueError("Cannot have more than 25 options")
        self._options.append(option)
        return self

    def add_string_option(
        self,
        name: str,
        description: str,
        *,
        required: bool = False,
        choices: Optional[List[Dict[str, Any]]] = None,
        autocomplete: bool = False,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
    ) -> "SlashCommandBuilder":
        """Add a string option"""
        option = CommandOption(
            name=name.lower(),
            description=description,
            type=ApplicationCommandOptionType.STRING,
            required=required,
            choices=choices,
            autocomplete=autocomplete,
            min_length=min_length,
            max_length=max_length,
        )
        return self.add_option(option)

    def add_integer_option(
        self,
        name: str,
        description: str,
        *,
        required: bool = False,
        choices: Optional[List[Dict[str, Any]]] = None,
        min_value: Optional[int] = None,
        max_value: Optional[int] = None,
    ) -> "SlashCommandBuilder":
        """Add an integer option"""
        option = CommandOption(
            name=name.lower(),
            description=description,
            type=ApplicationCommandOptionType.INTEGER,
            required=required,
            choices=choices,
            min_value=min_value,
            max_value=max_value,
        )
        return self.add_option(option)

    def add_boolean_option(
        self,
        name: str,
        description: str,
        *,
        required: bool = False,
    ) -> "SlashCommandBuilder":
        """Add a boolean option"""
        option = CommandOption(
            name=name.lower(),
            description=description,
            type=ApplicationCommandOptionType.BOOLEAN,
            required=required,
        )
        return self.add_option(option)

    def add_user_option(
        self,
        name: str,
        description: str,
        *,
        required: bool = False,
    ) -> "SlashCommandBuilder":
        """Add a user option"""
        option = CommandOption(
            name=name.lower(),
            description=description,
            type=ApplicationCommandOptionType.USER,
            required=required,
        )
        return self.add_option(option)

    def add_channel_option(
        self,
        name: str,
        description: str,
        *,
        required: bool = False,
        channel_types: Optional[List[int]] = None,
    ) -> "SlashCommandBuilder":
        """Add a channel option"""
        option = CommandOption(
            name=name.lower(),
            description=description,
            type=ApplicationCommandOptionType.CHANNEL,
            required=required,
            channel_types=channel_types,
        )
        return self.add_option(option)

    def add_role_option(
        self,
        name: str,
        description: str,
        *,
        required: bool = False,
    ) -> "SlashCommandBuilder":
        """Add a role option"""
        option = CommandOption(
            name=name.lower(),
            description=description,
            type=ApplicationCommandOptionType.ROLE,
            required=required,
        )
        return self.add_option(option)

    def add_mentionable_option(
        self,
        name: str,
        description: str,
        *,
        required: bool = False,
    ) -> "SlashCommandBuilder":
        """Add a mentionable option (user or role)"""
        option = CommandOption(
            name=name.lower(),
            description=description,
            type=ApplicationCommandOptionType.MENTIONABLE,
            required=required,
        )
        return self.add_option(option)

    def add_number_option(
        self,
        name: str,
        description: str,
        *,
        required: bool = False,
        choices: Optional[List[Dict[str, Any]]] = None,
        min_value: Optional[float] = None,
        max_value: Optional[float] = None,
    ) -> "SlashCommandBuilder":
        """Add a number (float) option"""
        option = CommandOption(
            name=name.lower(),
            description=description,
            type=ApplicationCommandOptionType.NUMBER,
            required=required,
            choices=choices,
            min_value=min_value,
            max_value=max_value,
        )
        return self.add_option(option)

    def add_attachment_option(
        self,
        name: str,
        description: str,
        *,
        required: bool = False,
    ) -> "SlashCommandBuilder":
        """Add an attachment option"""
        option = CommandOption(
            name=name.lower(),
            description=description,
            type=ApplicationCommandOptionType.ATTACHMENT,
            required=required,
        )
        return self.add_option(option)

    def set_dm_permission(self, enabled: bool) -> "SlashCommandBuilder":
        """Set whether the command can be used in DMs"""
        self._dm_permission = enabled
        return self

    def set_default_member_permissions(self, permissions: str) -> "SlashCommandBuilder":
        """Set default member permissions required"""
        self._default_member_permissions = permissions
        return self

    def set_nsfw(self, nsfw: bool) -> "SlashCommandBuilder":
        """Set whether the command is age-restricted"""
        self._nsfw = nsfw
        return self

    def set_callback(self, callback: Callable) -> "SlashCommandBuilder":
        """Set the callback function"""
        self._callback = callback
        return self

    def build(self) -> SlashCommand:
        """Build the slash command"""
        if not self._name:
            raise ValueError("Command name is required")
        if not self._description:
            raise ValueError("Command description is required")

        return SlashCommand(
            name=self._name,
            description=self._description,
            options=self._options,
            dm_permission=self._dm_permission,
            default_member_permissions=self._default_member_permissions,
            nsfw=self._nsfw,
            callback=self._callback,
        )


class UserCommandBuilder:
    """Builder for user context menu commands"""

    def __init__(self):
        self._name: Optional[str] = None
        self._dm_permission: bool = True
        self._default_member_permissions: Optional[str] = None
        self._nsfw: bool = False
        self._callback: Optional[Callable] = None

    def set_name(self, name: str) -> "UserCommandBuilder":
        """Set the command name"""
        if not name or len(name) > 32:
            raise ValueError("Name must be 1-32 characters")
        self._name = name
        return self

    def set_dm_permission(self, enabled: bool) -> "UserCommandBuilder":
        """Set whether the command can be used in DMs"""
        self._dm_permission = enabled
        return self

    def set_default_member_permissions(self, permissions: str) -> "UserCommandBuilder":
        """Set default member permissions required"""
        self._default_member_permissions = permissions
        return self

    def set_nsfw(self, nsfw: bool) -> "UserCommandBuilder":
        """Set whether the command is age-restricted"""
        self._nsfw = nsfw
        return self

    def set_callback(self, callback: Callable) -> "UserCommandBuilder":
        """Set the callback function"""
        self._callback = callback
        return self

    def build(self) -> UserCommand:
        """Build the user command"""
        if not self._name:
            raise ValueError("Command name is required")

        return UserCommand(
            name=self._name,
            dm_permission=self._dm_permission,
            default_member_permissions=self._default_member_permissions,
            nsfw=self._nsfw,
            callback=self._callback,
        )


class MessageCommandBuilder:
    """Builder for message context menu commands"""

    def __init__(self):
        self._name: Optional[str] = None
        self._dm_permission: bool = True
        self._default_member_permissions: Optional[str] = None
        self._nsfw: bool = False
        self._callback: Optional[Callable] = None

    def set_name(self, name: str) -> "MessageCommandBuilder":
        """Set the command name"""
        if not name or len(name) > 32:
            raise ValueError("Name must be 1-32 characters")
        self._name = name
        return self

    def set_dm_permission(self, enabled: bool) -> "MessageCommandBuilder":
        """Set whether the command can be used in DMs"""
        self._dm_permission = enabled
        return self

    def set_default_member_permissions(self, permissions: str) -> "MessageCommandBuilder":
        """Set default member permissions required"""
        self._default_member_permissions = permissions
        return self

    def set_nsfw(self, nsfw: bool) -> "MessageCommandBuilder":
        """Set whether the command is age-restricted"""
        self._nsfw = nsfw
        return self

    def set_callback(self, callback: Callable) -> "MessageCommandBuilder":
        """Set the callback function"""
        self._callback = callback
        return self

    def build(self) -> MessageCommand:
        """Build the message command"""
        if not self._name:
            raise ValueError("Command name is required")

        return MessageCommand(
            name=self._name,
            dm_permission=self._dm_permission,
            default_member_permissions=self._default_member_permissions,
            nsfw=self._nsfw,
            callback=self._callback,
        )
