"""
Fluent builder for creating modals
"""

from __future__ import annotations

from typing import Any, Optional

from ..components.text_input import TextInput, TextInputStyle


class ModalBuilder:
    """
    Fluent builder for creating Discord modals.

    Modals are popup forms that can collect text input from users.

    Example:
        modal = (ModalBuilder()
            .set_custom_id("feedback_modal")
            .set_title("Feedback Form")
            .add_text_input(
                custom_id="feedback_text",
                label="Your Feedback",
                style=TextInputStyle.PARAGRAPH,
                placeholder="Tell us what you think...",
                required=True
            )
            .build())

        await interaction.send_modal(modal)
    """

    def __init__(self):
        self._custom_id: Optional[str] = None
        self._title: Optional[str] = None
        self._components: list[dict[str, Any]] = []

    def set_custom_id(self, custom_id: str) -> ModalBuilder:
        """
        Set the modal's custom ID (max 100 characters).
        This ID is used to identify the modal when it's submitted.
        """
        if len(custom_id) > 100:
            raise ValueError("Custom ID must be 100 characters or less")
        self._custom_id = custom_id
        return self

    def set_title(self, title: str) -> ModalBuilder:
        """Set the modal title (max 45 characters)"""
        if len(title) > 45:
            raise ValueError("Title must be 45 characters or less")
        self._title = title
        return self

    def add_text_input(
        self,
        *,
        custom_id: str,
        label: str,
        style: TextInputStyle = TextInputStyle.SHORT,
        placeholder: Optional[str] = None,
        value: Optional[str] = None,
        required: bool = True,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
    ) -> ModalBuilder:
        """
        Add a text input component to the modal (max 5 components).

        Args:
            custom_id: Component identifier (max 100 chars)
            label: Input label (max 45 chars)
            style: Input style (SHORT or PARAGRAPH)
            placeholder: Placeholder text (max 100 chars)
            value: Pre-filled value (max 4000 chars)
            required: Whether input is required
            min_length: Minimum input length
            max_length: Maximum input length
        """
        if len(self._components) >= 5:
            raise ValueError("Modals can have a maximum of 5 components")

        if len(custom_id) > 100:
            raise ValueError("Custom ID must be 100 characters or less")
        if len(label) > 45:
            raise ValueError("Label must be 45 characters or less")
        if placeholder and len(placeholder) > 100:
            raise ValueError("Placeholder must be 100 characters or less")
        if value and len(value) > 4000:
            raise ValueError("Value must be 4000 characters or less")

        text_input = TextInput(
            custom_id=custom_id,
            label=label,
            style=style,
            placeholder=placeholder,
            value=value,
            required=required,
            min_length=min_length,
            max_length=max_length,
        )

        # Wrap in action row
        self._components.append({"type": 1, "components": [text_input.to_dict()]})  # ACTION_ROW
        return self

    def add_short_text(
        self,
        custom_id: str,
        label: str,
        *,
        placeholder: Optional[str] = None,
        required: bool = True,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
    ) -> ModalBuilder:
        """Add a short text input (single line)"""
        return self.add_text_input(
            custom_id=custom_id,
            label=label,
            style=TextInputStyle.SHORT,
            placeholder=placeholder,
            required=required,
            min_length=min_length,
            max_length=max_length,
        )

    def add_paragraph(
        self,
        custom_id: str,
        label: str,
        *,
        placeholder: Optional[str] = None,
        required: bool = True,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
    ) -> ModalBuilder:
        """Add a paragraph text input (multi-line)"""
        return self.add_text_input(
            custom_id=custom_id,
            label=label,
            style=TextInputStyle.PARAGRAPH,
            placeholder=placeholder,
            required=required,
            min_length=min_length,
            max_length=max_length,
        )

    def clear_components(self) -> ModalBuilder:
        """Remove all components"""
        self._components.clear()
        return self

    def build(self) -> dict[str, Any]:
        """
        Build and return the final modal data.

        Returns:
            dict: The modal data ready to send to Discord

        Raises:
            ValueError: If required fields are missing
        """
        if not self._custom_id:
            raise ValueError("Modal must have a custom_id")
        if not self._title:
            raise ValueError("Modal must have a title")
        if not self._components:
            raise ValueError("Modal must have at least one component")

        return {"custom_id": self._custom_id, "title": self._title, "components": self._components}

    def to_dict(self) -> dict[str, Any]:
        """Alias for build()"""
        return self.build()

    def __repr__(self) -> str:
        return f"ModalBuilder(custom_id={self._custom_id!r}, components={len(self._components)})"


# Example helper for common patterns
class FeedbackModalBuilder(ModalBuilder):
    """Pre-configured modal for collecting feedback"""

    def __init__(self, custom_id: str = "feedback_modal"):
        super().__init__()
        self.set_custom_id(custom_id)
        self.set_title("Feedback")
        self.add_paragraph(
            custom_id="feedback_text",
            label="Your Feedback",
            placeholder="Tell us what you think...",
            required=True,
            max_length=1000,
        )


class ReportModalBuilder(ModalBuilder):
    """Pre-configured modal for reporting issues"""

    def __init__(self, custom_id: str = "report_modal"):
        super().__init__()
        self.set_custom_id(custom_id)
        self.set_title("Report Issue")
        self.add_short_text(
            custom_id="report_reason",
            label="Reason",
            placeholder="Why are you reporting this?",
            required=True,
            max_length=100,
        )
        self.add_paragraph(
            custom_id="report_details",
            label="Details",
            placeholder="Provide additional details...",
            required=False,
            max_length=1000,
        )


class SuggestionModalBuilder(ModalBuilder):
    """Pre-configured modal for suggestions"""

    def __init__(self, custom_id: str = "suggestion_modal"):
        super().__init__()
        self.set_custom_id(custom_id)
        self.set_title("Make a Suggestion")
        self.add_short_text(
            custom_id="suggestion_title",
            label="Title",
            placeholder="Brief title for your suggestion",
            required=True,
            max_length=100,
        )
        self.add_paragraph(
            custom_id="suggestion_description",
            label="Description",
            placeholder="Describe your suggestion in detail...",
            required=True,
            max_length=1000,
        )
