"""
Component Builders - Fluent builders for message components
"""

from abc import ABC, abstractmethod
from enum import IntEnum
from typing import Any, Dict, List, Optional


class ButtonStyle(IntEnum):
    """Button styles"""

    PRIMARY = 1  # Blurple
    SECONDARY = 2  # Grey
    SUCCESS = 3  # Green
    DANGER = 4  # Red
    LINK = 5  # Grey with link


class TextInputStyle(IntEnum):
    """Text input styles"""

    SHORT = 1  # Single line
    PARAGRAPH = 2  # Multi-line


class ComponentBuilder(ABC):
    """Base component builder - abstract base class"""

    @abstractmethod
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary - must be implemented by subclasses"""
        pass


class ButtonBuilder(ComponentBuilder):
    """
    Fluent builder for buttons

    Example:
        ```python
        button = (ButtonBuilder()
            .set_style(ButtonStyle.PRIMARY)
            .set_label("Click Me!")
            .set_custom_id("my_button")
            .set_emoji("👍")
            .build())
        ```
    """

    def __init__(self):
        self._type = 2  # Button type
        self._style: Optional[int] = None
        self._label: Optional[str] = None
        self._custom_id: Optional[str] = None
        self._url: Optional[str] = None
        self._disabled: bool = False
        self._emoji: Optional[Dict[str, Any]] = None

    def set_style(self, style: ButtonStyle) -> "ButtonBuilder":
        """Set button style"""
        self._style = style.value if isinstance(style, ButtonStyle) else style
        return self

    def set_label(self, label: str) -> "ButtonBuilder":
        """Set button label"""
        self._label = label
        return self

    def set_custom_id(self, custom_id: str) -> "ButtonBuilder":
        """Set custom ID (for non-link buttons)"""
        self._custom_id = custom_id
        return self

    def set_url(self, url: str) -> "ButtonBuilder":
        """Set URL (for link buttons)"""
        self._url = url
        self._style = ButtonStyle.LINK
        return self

    def set_disabled(self, disabled: bool = True) -> "ButtonBuilder":
        """Set disabled state"""
        self._disabled = disabled
        return self

    def set_emoji(self, emoji: str) -> "ButtonBuilder":
        """Set emoji"""
        # Simple emoji parsing
        if emoji.startswith("<:") and emoji.endswith(">"):
            # Custom emoji <:name:id>
            parts = emoji[2:-1].split(":")
            self._emoji = {"name": parts[0], "id": parts[1], "animated": False}
        elif emoji.startswith("<a:") and emoji.endswith(">"):
            # Animated custom emoji <a:name:id>
            parts = emoji[3:-1].split(":")
            self._emoji = {"name": parts[0], "id": parts[1], "animated": True}
        else:
            # Unicode emoji
            self._emoji = {"name": emoji}
        return self

    def build(self) -> Dict[str, Any]:
        """Build the button"""
        data = {
            "type": self._type,
            "style": self._style or ButtonStyle.PRIMARY,
        }

        if self._label:
            data["label"] = self._label
        if self._custom_id:
            data["custom_id"] = self._custom_id
        if self._url:
            data["url"] = self._url
        if self._disabled:
            data["disabled"] = self._disabled
        if self._emoji:
            data["emoji"] = self._emoji

        return data

    def to_dict(self) -> Dict[str, Any]:
        """Alias for build()"""
        return self.build()

    # Convenience methods

    @classmethod
    def primary(cls, label: str, custom_id: str) -> "ButtonBuilder":
        """Create primary button"""
        return cls().set_style(ButtonStyle.PRIMARY).set_label(label).set_custom_id(custom_id)

    @classmethod
    def secondary(cls, label: str, custom_id: str) -> "ButtonBuilder":
        """Create secondary button"""
        return cls().set_style(ButtonStyle.SECONDARY).set_label(label).set_custom_id(custom_id)

    @classmethod
    def success(cls, label: str, custom_id: str) -> "ButtonBuilder":
        """Create success button"""
        return cls().set_style(ButtonStyle.SUCCESS).set_label(label).set_custom_id(custom_id)

    @classmethod
    def danger(cls, label: str, custom_id: str) -> "ButtonBuilder":
        """Create danger button"""
        return cls().set_style(ButtonStyle.DANGER).set_label(label).set_custom_id(custom_id)

    @classmethod
    def link(cls, label: str, url: str) -> "ButtonBuilder":
        """Create link button"""
        return cls().set_label(label).set_url(url)


class SelectMenuBuilder(ComponentBuilder):
    """
    Fluent builder for select menus

    Example:
        ```python
        select = (SelectMenuBuilder()
            .set_custom_id("my_select")
            .set_placeholder("Choose an option")
            .add_option("Option 1", "opt1", description="First option")
            .add_option("Option 2", "opt2", description="Second option")
            .set_min_values(1)
            .set_max_values(1)
            .build())
        ```
    """

    def __init__(self, select_type: int = 3):
        self._type = select_type  # 3 = string select
        self._custom_id: Optional[str] = None
        self._placeholder: Optional[str] = None
        self._min_values: int = 1
        self._max_values: int = 1
        self._disabled: bool = False
        self._options: List[Dict[str, Any]] = []

    def set_custom_id(self, custom_id: str) -> "SelectMenuBuilder":
        """Set custom ID"""
        self._custom_id = custom_id
        return self

    def set_placeholder(self, placeholder: str) -> "SelectMenuBuilder":
        """Set placeholder text"""
        self._placeholder = placeholder
        return self

    def set_min_values(self, min_values: int) -> "SelectMenuBuilder":
        """Set minimum number of selections"""
        self._min_values = min_values
        return self

    def set_max_values(self, max_values: int) -> "SelectMenuBuilder":
        """Set maximum number of selections"""
        self._max_values = max_values
        return self

    def set_disabled(self, disabled: bool = True) -> "SelectMenuBuilder":
        """Set disabled state"""
        self._disabled = disabled
        return self

    def add_option(
        self,
        label: str,
        value: str,
        *,
        description: Optional[str] = None,
        emoji: Optional[str] = None,
        default: bool = False,
    ) -> "SelectMenuBuilder":
        """Add an option to the select menu"""
        option = {
            "label": label,
            "value": value,
        }

        if description:
            option["description"] = description
        if emoji:
            # Parse emoji (simplified)
            if emoji.startswith("<") and emoji.endswith(">"):
                # Custom emoji
                parts = emoji[2:-1].split(":")
                option["emoji"] = {"name": parts[0], "id": parts[1]}
            else:
                option["emoji"] = {"name": emoji}
        if default:
            option["default"] = default

        self._options.append(option)
        return self

    def build(self) -> Dict[str, Any]:
        """Build the select menu"""
        data = {
            "type": self._type,
            "custom_id": self._custom_id or "select_menu",
            "options": self._options,
            "min_values": self._min_values,
            "max_values": self._max_values,
        }

        if self._placeholder:
            data["placeholder"] = self._placeholder
        if self._disabled:
            data["disabled"] = self._disabled

        return data

    def to_dict(self) -> Dict[str, Any]:
        """Alias for build()"""
        return self.build()


class TextInputBuilder(ComponentBuilder):
    """
    Fluent builder for text inputs (for modals)

    Example:
        ```python
        text_input = (TextInputBuilder()
            .set_custom_id("username")
            .set_label("Username")
            .set_style(TextInputStyle.SHORT)
            .set_placeholder("Enter your username")
            .set_required(True)
            .set_min_length(3)
            .set_max_length(20)
            .build())
        ```
    """

    def __init__(self):
        self._type = 4  # Text input type
        self._custom_id: Optional[str] = None
        self._label: Optional[str] = None
        self._style: int = TextInputStyle.SHORT
        self._placeholder: Optional[str] = None
        self._value: Optional[str] = None
        self._required: bool = True
        self._min_length: Optional[int] = None
        self._max_length: Optional[int] = None

    def set_custom_id(self, custom_id: str) -> "TextInputBuilder":
        """Set custom ID"""
        self._custom_id = custom_id
        return self

    def set_label(self, label: str) -> "TextInputBuilder":
        """Set label"""
        self._label = label
        return self

    def set_style(self, style: TextInputStyle) -> "TextInputBuilder":
        """Set style (SHORT or PARAGRAPH)"""
        self._style = style.value if isinstance(style, TextInputStyle) else style
        return self

    def set_placeholder(self, placeholder: str) -> "TextInputBuilder":
        """Set placeholder text"""
        self._placeholder = placeholder
        return self

    def set_value(self, value: str) -> "TextInputBuilder":
        """Set default value"""
        self._value = value
        return self

    def set_required(self, required: bool = True) -> "TextInputBuilder":
        """Set required state"""
        self._required = required
        return self

    def set_min_length(self, min_length: int) -> "TextInputBuilder":
        """Set minimum length"""
        self._min_length = min_length
        return self

    def set_max_length(self, max_length: int) -> "TextInputBuilder":
        """Set maximum length"""
        self._max_length = max_length
        return self

    def build(self) -> Dict[str, Any]:
        """Build the text input"""
        data = {
            "type": self._type,
            "custom_id": self._custom_id or "text_input",
            "label": self._label or "Text Input",
            "style": self._style,
            "required": self._required,
        }

        if self._placeholder:
            data["placeholder"] = self._placeholder
        if self._value:
            data["value"] = self._value
        if self._min_length is not None:
            data["min_length"] = self._min_length
        if self._max_length is not None:
            data["max_length"] = self._max_length

        return data

    def to_dict(self) -> Dict[str, Any]:
        """Alias for build()"""
        return self.build()


class ActionRowBuilder(ComponentBuilder):
    """
    Action row builder - Contains other components

    Example:
        ```python
        row = (ActionRowBuilder()
            .add_component(button1)
            .add_component(button2)
            .build())
        ```
    """

    def __init__(self):
        self._type = 1  # Action row type
        self._components: List[Dict[str, Any]] = []

    def add_component(self, component: ComponentBuilder | Dict[str, Any]) -> "ActionRowBuilder":
        """Add a component to the row"""
        if isinstance(component, ComponentBuilder):
            self._components.append(component.to_dict())
        else:
            self._components.append(component)
        return self

    def add_components(self, *components) -> "ActionRowBuilder":
        """Add multiple components"""
        for component in components:
            self.add_component(component)
        return self

    def build(self) -> Dict[str, Any]:
        """Build the action row"""
        return {"type": self._type, "components": self._components}

    def to_dict(self) -> Dict[str, Any]:
        """Alias for build()"""
        return self.build()
