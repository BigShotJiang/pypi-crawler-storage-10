"""
Embed Builder - Fluent interface for creating embeds
Much more Pythonic than discord.js!
"""

from datetime import datetime
from typing import Any, Dict, List, Optional, Union

from ..models.color import Color
from ..models.embed import Embed, EmbedAuthor, EmbedField, EmbedFooter


class EmbedBuilder:
    """
    Fluent builder for creating embeds

    Example:
        ```python
        embed = (EmbedBuilder()
            .set_title("Hello World")
            .set_description("This is an embed")
            .set_color(Color.blue())
            .add_field("Field 1", "Value 1")
            .add_field("Field 2", "Value 2", inline=True)
            .set_footer("Footer text")
            .set_timestamp()
            .build())

        await channel.send(embed=embed)
        ```
    """

    def __init__(self):
        self._title: Optional[str] = None
        self._description: Optional[str] = None
        self._url: Optional[str] = None
        self._timestamp: Optional[str] = None
        self._color: Optional[int] = None
        self._footer: Optional[Dict[str, Any]] = None
        self._image: Optional[Dict[str, str]] = None
        self._thumbnail: Optional[Dict[str, str]] = None
        self._author: Optional[Dict[str, Any]] = None
        self._fields: List[Dict[str, Any]] = []

    def set_title(self, title: str) -> "EmbedBuilder":
        """Set embed title"""
        self._title = title
        return self

    def set_description(self, description: str) -> "EmbedBuilder":
        """Set embed description"""
        self._description = description
        return self

    def set_url(self, url: str) -> "EmbedBuilder":
        """Set embed URL (makes title clickable)"""
        self._url = url
        return self

    def set_timestamp(self, timestamp: Optional[Union[datetime, str]] = None) -> "EmbedBuilder":
        """
        Set embed timestamp

        Args:
            timestamp: Datetime or ISO 8601 string. If None, uses current time.
        """
        if timestamp is None:
            timestamp = datetime.utcnow()

        if isinstance(timestamp, datetime):
            timestamp = timestamp.isoformat()

        self._timestamp = timestamp
        return self

    def set_color(self, color: Union[int, Color, str, tuple]) -> "EmbedBuilder":
        """
        Set embed color

        Args:
            color: Color as int, Color object, hex string, or RGB tuple
        """
        if isinstance(color, Color):
            self._color = color.value
        elif isinstance(color, str):
            # Parse hex color
            color = color.lstrip("#")
            self._color = int(color, 16)
        elif isinstance(color, tuple):
            # RGB tuple
            r, g, b = color
            self._color = (r << 16) + (g << 8) + b
        else:
            self._color = color

        return self

    def set_footer(
        self, text: str, *, icon_url: Optional[str] = None, proxy_icon_url: Optional[str] = None
    ) -> "EmbedBuilder":
        """Set embed footer"""
        self._footer = {"text": text}
        if icon_url:
            self._footer["icon_url"] = icon_url
        if proxy_icon_url:
            self._footer["proxy_icon_url"] = proxy_icon_url
        return self

    def set_image(self, url: str) -> "EmbedBuilder":
        """Set embed image"""
        self._image = {"url": url}
        return self

    def set_thumbnail(self, url: str) -> "EmbedBuilder":
        """Set embed thumbnail"""
        self._thumbnail = {"url": url}
        return self

    def set_author(
        self,
        name: str,
        *,
        url: Optional[str] = None,
        icon_url: Optional[str] = None,
        proxy_icon_url: Optional[str] = None,
    ) -> "EmbedBuilder":
        """Set embed author"""
        self._author = {"name": name}
        if url:
            self._author["url"] = url
        if icon_url:
            self._author["icon_url"] = icon_url
        if proxy_icon_url:
            self._author["proxy_icon_url"] = proxy_icon_url
        return self

    def add_field(self, name: str, value: str, *, inline: bool = False) -> "EmbedBuilder":
        """Add a field to the embed"""
        self._fields.append({"name": name, "value": value, "inline": inline})
        return self

    def add_fields(self, *fields: Dict[str, Any]) -> "EmbedBuilder":
        """Add multiple fields at once"""
        for field in fields:
            self._fields.append(field)
        return self

    def insert_field_at(
        self, index: int, name: str, value: str, *, inline: bool = False
    ) -> "EmbedBuilder":
        """Insert field at specific index"""
        self._fields.insert(index, {"name": name, "value": value, "inline": inline})
        return self

    def remove_field(self, index: int) -> "EmbedBuilder":
        """Remove field at index"""
        if 0 <= index < len(self._fields):
            del self._fields[index]
        return self

    def clear_fields(self) -> "EmbedBuilder":
        """Remove all fields"""
        self._fields.clear()
        return self

    def build(self) -> Embed:
        """
        Build the Embed object

        Returns:
            The constructed Embed
        """
        # Create embed with basic properties
        embed = Embed(
            title=self._title, description=self._description, url=self._url, color=self._color
        )

        # Set timestamp
        if self._timestamp:
            if isinstance(self._timestamp, str):
                from datetime import datetime

                embed.timestamp = datetime.fromisoformat(self._timestamp.replace("Z", "+00:00"))
            else:
                embed.timestamp = self._timestamp

        # Set footer
        if self._footer:
            embed.set_footer(text=self._footer["text"], icon_url=self._footer.get("icon_url"))

        # Set image
        if self._image:
            embed.set_image(url=self._image["url"])

        # Set thumbnail
        if self._thumbnail:
            embed.set_thumbnail(url=self._thumbnail["url"])

        # Set author
        if self._author:
            embed.set_author(
                name=self._author["name"],
                url=self._author.get("url"),
                icon_url=self._author.get("icon_url"),
            )

        # Add fields
        for field in self._fields:
            embed.add_field(
                name=field["name"], value=field["value"], inline=field.get("inline", False)
            )

        return embed

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return self.build().to_dict()

    @classmethod
    def from_embed(cls, embed: Embed) -> "EmbedBuilder":
        """
        Create builder from existing embed

        Args:
            embed: Existing embed

        Returns:
            New builder with embed data
        """
        builder = cls()

        if embed.title:
            builder.set_title(embed.title)
        if embed.description:
            builder.set_description(embed.description)
        if embed.url:
            builder.set_url(embed.url)
        if embed.timestamp:
            builder.set_timestamp(embed.timestamp)
        if embed.color:
            builder.set_color(embed.color.value if hasattr(embed.color, "value") else embed.color)
        if embed.footer:
            builder.set_footer(embed.footer.text, icon_url=embed.footer.icon_url)
        if embed.image:
            builder.set_image(embed.image.url)
        if embed.thumbnail:
            builder.set_thumbnail(embed.thumbnail.url)
        if embed.author:
            builder.set_author(
                embed.author.name, url=embed.author.url, icon_url=embed.author.icon_url
            )
        for field in embed.fields:
            builder.add_field(field.name, field.value, inline=field.inline)

        return builder

    # Convenience methods for common patterns

    @classmethod
    def success(cls, title: str, description: str) -> "EmbedBuilder":
        """Create a success embed (green)"""
        return cls().set_title(f"✅ {title}").set_description(description).set_color(Color.green())

    @classmethod
    def error(cls, title: str, description: str) -> "EmbedBuilder":
        """Create an error embed (red)"""
        return cls().set_title(f"❌ {title}").set_description(description).set_color(Color.red())

    @classmethod
    def warning(cls, title: str, description: str) -> "EmbedBuilder":
        """Create a warning embed (yellow)"""
        return cls().set_title(f"⚠️ {title}").set_description(description).set_color(Color.yellow())

    @classmethod
    def info(cls, title: str, description: str) -> "EmbedBuilder":
        """Create an info embed (blue)"""
        return cls().set_title(f"ℹ️ {title}").set_description(description).set_color(Color.blue())
