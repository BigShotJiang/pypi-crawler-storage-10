"""
Fluent builder for creating rich embeds
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional, Union

from ..models.color import Color
from ..models.embed import Embed, EmbedAuthor, EmbedField, EmbedFooter, EmbedImage, EmbedThumbnail


class EmbedBuilder:
    """
    Fluent builder for creating Discord embeds.

    This provides a chainable API for building embeds, similar to discord.js.

    Example:
        embed = (EmbedBuilder()
            .set_title("Hello World")
            .set_description("This is a test embed")
            .set_color(0x00ff00)
            .add_field("Field 1", "Value 1", inline=True)
            .add_field("Field 2", "Value 2", inline=True)
            .set_footer("Footer text")
            .set_timestamp()
            .build())
    """

    def __init__(self):
        self._title: Optional[str] = None
        self._description: Optional[str] = None
        self._url: Optional[str] = None
        self._timestamp: Optional[datetime] = None
        self._color: Optional[int] = None
        self._footer: Optional[EmbedFooter] = None
        self._image: Optional[EmbedImage] = None
        self._thumbnail: Optional[EmbedThumbnail] = None
        self._author: Optional[EmbedAuthor] = None
        self._fields: list[EmbedField] = []

    def set_title(self, title: str) -> EmbedBuilder:
        """Set the embed title (max 256 characters)"""
        if len(title) > 256:
            raise ValueError("Title must be 256 characters or less")
        self._title = title
        return self

    def set_description(self, description: str) -> EmbedBuilder:
        """Set the embed description (max 4096 characters)"""
        if len(description) > 4096:
            raise ValueError("Description must be 4096 characters or less")
        self._description = description
        return self

    def set_url(self, url: str) -> EmbedBuilder:
        """Set the embed URL (makes title clickable)"""
        self._url = url
        return self

    def set_timestamp(self, timestamp: Optional[datetime] = None) -> EmbedBuilder:
        """
        Set the embed timestamp.
        If no timestamp is provided, uses current UTC time.
        """
        self._timestamp = timestamp or datetime.utcnow()
        return self

    def set_color(self, color: Union[int, Color, tuple[int, int, int]]) -> EmbedBuilder:
        """
        Set the embed color.

        Args:
            color: Can be an integer (0x00ff00), Color object, or RGB tuple (255, 0, 0)
        """
        if isinstance(color, tuple):
            r, g, b = color
            self._color = (r << 16) + (g << 8) + b
        elif isinstance(color, Color):
            self._color = color.value
        else:
            self._color = color
        return self

    def set_colour(self, colour: Union[int, Color, tuple[int, int, int]]) -> EmbedBuilder:
        """Alias for set_color (British spelling)"""
        return self.set_color(colour)

    def set_footer(self, text: str, *, icon_url: Optional[str] = None) -> EmbedBuilder:
        """
        Set the embed footer (max 2048 characters)

        Args:
            text: Footer text
            icon_url: Optional footer icon URL
        """
        if len(text) > 2048:
            raise ValueError("Footer text must be 2048 characters or less")
        self._footer = EmbedFooter(text=text, icon_url=icon_url)
        return self

    def set_image(self, url: str) -> EmbedBuilder:
        """Set the embed image (large image at bottom)"""
        self._image = EmbedImage(url=url)
        return self

    def set_thumbnail(self, url: str) -> EmbedBuilder:
        """Set the embed thumbnail (small image at top right)"""
        self._thumbnail = EmbedThumbnail(url=url)
        return self

    def set_author(
        self, name: str, *, url: Optional[str] = None, icon_url: Optional[str] = None
    ) -> EmbedBuilder:
        """
        Set the embed author (max 256 characters)

        Args:
            name: Author name
            url: Optional author URL (makes name clickable)
            icon_url: Optional author icon URL
        """
        if len(name) > 256:
            raise ValueError("Author name must be 256 characters or less")
        self._author = EmbedAuthor(name=name, url=url, icon_url=icon_url)
        return self

    def add_field(self, name: str, value: str, *, inline: bool = False) -> EmbedBuilder:
        """
        Add a field to the embed (max 25 fields)

        Args:
            name: Field name (max 256 characters)
            value: Field value (max 1024 characters)
            inline: Whether field should be displayed inline
        """
        if len(self._fields) >= 25:
            raise ValueError("Embeds can have a maximum of 25 fields")
        if len(name) > 256:
            raise ValueError("Field name must be 256 characters or less")
        if len(value) > 1024:
            raise ValueError("Field value must be 1024 characters or less")

        self._fields.append(EmbedField(name=name, value=value, inline=inline))
        return self

    def add_fields(self, *fields: tuple[str, str, bool]) -> EmbedBuilder:
        """
        Add multiple fields at once.

        Args:
            fields: Tuples of (name, value, inline)

        Example:
            builder.add_fields(
                ("Field 1", "Value 1", True),
                ("Field 2", "Value 2", True),
                ("Field 3", "Value 3", False)
            )
        """
        for name, value, inline in fields:
            self.add_field(name, value, inline=inline)
        return self

    def insert_field_at(
        self, index: int, name: str, value: str, *, inline: bool = False
    ) -> EmbedBuilder:
        """Insert a field at a specific index"""
        if index < 0 or index > len(self._fields):
            raise ValueError(f"Index {index} is out of range")
        if len(name) > 256:
            raise ValueError("Field name must be 256 characters or less")
        if len(value) > 1024:
            raise ValueError("Field value must be 1024 characters or less")

        self._fields.insert(index, EmbedField(name=name, value=value, inline=inline))
        return self

    def set_field_at(
        self, index: int, name: str, value: str, *, inline: bool = False
    ) -> EmbedBuilder:
        """Replace a field at a specific index"""
        if index < 0 or index >= len(self._fields):
            raise ValueError(f"Index {index} is out of range")
        if len(name) > 256:
            raise ValueError("Field name must be 256 characters or less")
        if len(value) > 1024:
            raise ValueError("Field value must be 1024 characters or less")

        self._fields[index] = EmbedField(name=name, value=value, inline=inline)
        return self

    def remove_field_at(self, index: int) -> EmbedBuilder:
        """Remove a field at a specific index"""
        if index < 0 or index >= len(self._fields):
            raise ValueError(f"Index {index} is out of range")
        self._fields.pop(index)
        return self

    def clear_fields(self) -> EmbedBuilder:
        """Remove all fields"""
        self._fields.clear()
        return self

    def build(self) -> Embed:
        """
        Build and return the final Embed object.

        Returns:
            Embed: The constructed embed

        Raises:
            ValueError: If the embed exceeds Discord's limits
        """
        # Validate total character count
        total_chars = 0
        if self._title:
            total_chars += len(self._title)
        if self._description:
            total_chars += len(self._description)
        if self._footer:
            total_chars += len(self._footer.text)
        if self._author:
            total_chars += len(self._author.name)
        for field in self._fields:
            total_chars += len(field.name) + len(field.value)

        if total_chars > 6000:
            raise ValueError("Total embed characters must be 6000 or less")

        # Create embed
        embed = Embed(
            title=self._title,
            description=self._description,
            url=self._url,
            timestamp=self._timestamp,
            color=self._color,
        )

        # Set components
        embed.footer = self._footer
        embed.image = self._image
        embed.thumbnail = self._thumbnail
        embed.author = self._author
        embed.fields = self._fields

        return embed

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary (same as build().to_dict())"""
        return self.build().to_dict()

    @classmethod
    def from_embed(cls, embed: Embed) -> EmbedBuilder:
        """
        Create a builder from an existing embed.

        Useful for modifying existing embeds.
        """
        builder = cls()
        builder._title = embed.title
        builder._description = embed.description
        builder._url = embed.url
        builder._timestamp = embed.timestamp
        builder._color = embed.color
        builder._footer = embed.footer
        builder._image = embed.image
        builder._thumbnail = embed.thumbnail
        builder._author = embed.author
        builder._fields = list(embed.fields or [])
        return builder

    def __repr__(self) -> str:
        return f"EmbedBuilder(title={self._title!r}, fields={len(self._fields)})"


# Convenience alias
Builder = EmbedBuilder
