"""
Builders - Fluent interfaces for building Discord objects
"""

from ..components.button import ButtonStyle
from ..components.text_input import TextInputStyle
from .component_builders import (
    ActionRowBuilder,
    ButtonBuilder,
    SelectMenuBuilder,
)
from .embed_builder import EmbedBuilder
from .modal_builder import (
    FeedbackModalBuilder,
    ModalBuilder,
    ReportModalBuilder,
    SuggestionModalBuilder,
)

# Legacy compatibility
from .slash_command import SlashCommandBuilder

try:
    from .slash_command import SlashCommandOptionBuilder
except ImportError:
    SlashCommandOptionBuilder = None  # Not available in current version

# Alias for convenience
CommandBuilder = SlashCommandBuilder

__all__ = [
    # Embed builders
    "EmbedBuilder",
    # Modal builders
    "ModalBuilder",
    "FeedbackModalBuilder",
    "ReportModalBuilder",
    "SuggestionModalBuilder",
    # Component builders
    "ButtonBuilder",
    "SelectMenuBuilder",
    "ActionRowBuilder",
    # Command builders
    "SlashCommandBuilder",
    "CommandBuilder",
    # Enums
    "ButtonStyle",
    "TextInputStyle",
]
