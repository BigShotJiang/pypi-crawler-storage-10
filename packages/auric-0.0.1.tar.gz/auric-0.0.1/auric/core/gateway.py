"""
Gateway WebSocket client
"""

from __future__ import annotations

import asyncio
import logging
import sys
import time
import zlib
from typing import Any, Callable, Dict, Optional

import aiohttp
import orjson

from ..utils.exceptions import (
    ConnectionClosed,
    GatewayException,
    InvalidToken,
    PrivilegedIntentsRequired,
)
from .intents import Intents
from .opcodes import GatewayCloseCode, GatewayOpcode
from .types import GATEWAY_URL

logger = logging.getLogger(__name__)


class GatewayClient:
    """
    WebSocket client for Discord Gateway

    Handles connection, heartbeating, reconnection, and event dispatching
    """

    def __init__(
        self,
        *,
        token: str,
        intents: Intents,
        shard_id: int = 0,
        shard_count: int = 1,
        session: Optional[aiohttp.ClientSession] = None,
        dispatch: Optional[Callable[[str, Dict[str, Any]], None]] = None,
    ):
        self.token = token
        self.intents = intents
        self.shard_id = shard_id
        self.shard_count = shard_count
        self._session = session
        self._dispatch = dispatch

        # Connection state
        self._ws: Optional[aiohttp.ClientWebSocketResponse] = None
        self._zlib = zlib.decompressobj()
        self._buffer = bytearray()

        # Gateway state
        self.session_id: Optional[str] = None
        self.sequence: Optional[int] = None
        self.resume_url: Optional[str] = None

        # Heartbeat
        self._heartbeat_interval: Optional[float] = None
        self._heartbeat_task: Optional[asyncio.Task] = None
        self._receive_task: Optional[asyncio.Task] = None
        self._last_heartbeat: float = 0.0
        self._last_ack: float = 0.0

        # Connection management
        self._connected = asyncio.Event()
        self._close_code: Optional[int] = None

    @property
    def latency(self) -> float:
        """Get gateway latency in seconds"""
        if self._last_ack and self._last_heartbeat:
            return self._last_ack - self._last_heartbeat
        return float("inf")

    async def connect(self, *, resume: bool = False) -> None:
        """
        Connect to Discord Gateway

        Args:
            resume: Whether to resume existing session
        """
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()

        url = self.resume_url or GATEWAY_URL
        gateway_url = f"{url}/?v=10&encoding=json&compress=zlib-stream"

        logger.info(f"Connecting to gateway: {gateway_url}")

        try:
            self._ws = await self._session.ws_connect(
                gateway_url,
                timeout=60.0,
                max_msg_size=0,
                autoclose=False,
            )
        except Exception as e:
            logger.error(f"Failed to connect to gateway: {e}")
            raise GatewayException(f"Connection failed: {e}")

        # Start receiving messages
        if self._receive_task and not self._receive_task.done():
            self._receive_task.cancel()
        self._receive_task = asyncio.create_task(self._receive_loop())

        # Wait for HELLO
        hello = await self._wait_for(GatewayOpcode.HELLO)
        self._heartbeat_interval = hello["d"]["heartbeat_interval"] / 1000.0

        # Start heartbeat
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())

        # Identify or Resume
        if resume and self.session_id:
            await self._resume()
        else:
            await self._identify()

        self._connected.set()

    async def close(self, code: int = 1000) -> None:
        """Close the gateway connection"""
        logger.info(f"Closing gateway connection with code {code}")

        # Cancel tasks first
        if self._heartbeat_task and not self._heartbeat_task.done():
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                logger.debug("Heartbeat task cancelled")
            except Exception as e:
                logger.error(f"Error cancelling heartbeat task: {e}", exc_info=True)

        if self._receive_task and not self._receive_task.done():
            self._receive_task.cancel()
            try:
                await self._receive_task
            except asyncio.CancelledError:
                logger.debug("Receive task cancelled")
            except Exception as e:
                logger.error(f"Error cancelling receive task: {e}", exc_info=True)

        # Then close websocket
        if self._ws and not self._ws.closed:
            await self._ws.close(code=code)

        self._connected.clear()

    async def _identify(self) -> None:
        """Send IDENTIFY payload"""
        payload = {
            "op": GatewayOpcode.IDENTIFY,
            "d": {
                "token": self.token,
                "intents": int(self.intents),
                "properties": {
                    "os": sys.platform,
                    "browser": "auric",
                    "device": "auric",
                },
                "compress": True,
                "large_threshold": 250,
            },
        }

        if self.shard_count > 1:
            payload["d"]["shard"] = [self.shard_id, self.shard_count]

        await self._send(payload)
        logger.info("Sent IDENTIFY")

    async def _resume(self) -> None:
        """Send RESUME payload"""
        payload = {
            "op": GatewayOpcode.RESUME,
            "d": {
                "token": self.token,
                "session_id": self.session_id,
                "seq": self.sequence or 0,
            },
        }

        await self._send(payload)
        logger.info("Sent RESUME")

    async def _heartbeat_loop(self) -> None:
        """Heartbeat loop"""
        while not self._ws.closed:
            try:
                # Send heartbeat
                await self._send(
                    {
                        "op": GatewayOpcode.HEARTBEAT,
                        "d": self.sequence,
                    }
                )
                self._last_heartbeat = time.time()

                # Wait for ACK
                await asyncio.sleep(self._heartbeat_interval)

                # Check if we received ACK
                if self._last_ack < self._last_heartbeat:
                    logger.warning("Heartbeat ACK not received, reconnecting...")
                    await self.close(code=1000)
                    return

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Heartbeat error: {e}")

    async def _receive_loop(self) -> None:
        """Receive messages from gateway"""
        while not self._ws.closed:
            try:
                msg = await self._ws.receive()

                if msg.type == aiohttp.WSMsgType.BINARY:
                    # Decompress zlib data
                    self._buffer.extend(msg.data)

                    if len(msg.data) < 4 or msg.data[-4:] != b"\x00\x00\xff\xff":
                        continue

                    data = self._zlib.decompress(self._buffer)
                    self._buffer = bytearray()

                    payload = orjson.loads(data)
                    await self._handle_payload(payload)

                elif msg.type == aiohttp.WSMsgType.TEXT:
                    payload = orjson.loads(msg.data)
                    await self._handle_payload(payload)

                elif msg.type == aiohttp.WSMsgType.CLOSE:
                    self._close_code = msg.data
                    logger.warning(f"Gateway closed: {msg.data}")
                    break

                elif msg.type == aiohttp.WSMsgType.ERROR:
                    logger.error(f"Gateway error: {self._ws.exception()}")
                    break

            except asyncio.CancelledError:
                # Task was cancelled, exit gracefully
                break
            except RuntimeError as e:
                if "Concurrent call to receive()" in str(e):
                    # Websocket is being used elsewhere (shutdown), exit gracefully
                    logger.debug("Receive loop detected concurrent call, exiting")
                    break
                logger.error(f"Receive loop runtime error: {e}")
                break
            except Exception as e:
                logger.error(f"Receive loop error: {e}")
                # Don't break on other exceptions, try to continue
                await asyncio.sleep(0.1)

    async def _handle_payload(self, payload: Dict[str, Any]) -> None:
        """Handle gateway payload"""
        op = payload["op"]
        data = payload.get("d")
        seq = payload.get("s")
        event = payload.get("t")

        # Update sequence
        if seq:
            self.sequence = seq

        # Handle opcode
        if op == GatewayOpcode.DISPATCH:
            logger.debug(f"Received event: {event}")

            # Handle special events
            if event == "READY":
                self.session_id = data["session_id"]
                self.resume_url = data.get("resume_gateway_url")
                logger.info(f"Gateway ready! Session: {self.session_id}")

            elif event == "RESUMED":
                logger.info("Session resumed")

            # Dispatch event
            if self._dispatch:
                self._dispatch(event, data)

        elif op == GatewayOpcode.HEARTBEAT:
            # Server requesting heartbeat
            await self._send({"op": GatewayOpcode.HEARTBEAT, "d": self.sequence})

        elif op == GatewayOpcode.RECONNECT:
            logger.info("Server requesting reconnect")
            await self.close(code=1000)

        elif op == GatewayOpcode.INVALID_SESSION:
            logger.warning("Invalid session")
            can_resume = data
            if not can_resume:
                self.session_id = None
                await asyncio.sleep(5)
            await self.close(code=1000)

        elif op == GatewayOpcode.HEARTBEAT_ACK:
            self._last_ack = time.time()
            logger.debug(f"Heartbeat ACK (latency: {self.latency * 1000:.0f}ms)")

    async def _send(self, payload: Dict[str, Any]) -> None:
        """Send payload to gateway"""
        if not self._ws or self._ws.closed:
            raise GatewayException("Gateway not connected")

        data = orjson.dumps(payload)
        await self._ws.send_bytes(data)

    async def send(self, payload: Dict[str, Any]) -> None:
        """Public method to send payload to gateway (for voice state updates)"""
        await self._send(payload)

    async def _wait_for(self, opcode: GatewayOpcode, timeout: float = 60.0) -> Dict[str, Any]:
        """Wait for specific opcode"""
        start = time.time()

        while time.time() - start < timeout:
            if not self._ws:
                await asyncio.sleep(0.1)
                continue

            msg = await self._ws.receive()

            if msg.type == aiohttp.WSMsgType.BINARY:
                self._buffer.extend(msg.data)
                if len(msg.data) < 4 or msg.data[-4:] != b"\x00\x00\xff\xff":
                    continue

                data = self._zlib.decompress(self._buffer)
                self._buffer = bytearray()
                payload = orjson.loads(data)
            else:
                payload = orjson.loads(msg.data)

            if payload["op"] == opcode:
                return payload

        raise asyncio.TimeoutError(f"Timeout waiting for opcode {opcode}")

    async def update_presence(
        self,
        *,
        status: str = "online",
        activities: Optional[list] = None,
        afk: bool = False,
    ) -> None:
        """Update bot presence"""
        payload = {
            "op": GatewayOpcode.PRESENCE_UPDATE,
            "d": {
                "since": None,
                "activities": activities or [],
                "status": status,
                "afk": afk,
            },
        }

        await self._send(payload)

    async def request_guild_members(
        self,
        guild_id: int,
        *,
        query: str = "",
        limit: int = 0,
        user_ids: Optional[list] = None,
    ) -> None:
        """Request guild members"""
        payload = {
            "op": GatewayOpcode.REQUEST_GUILD_MEMBERS,
            "d": {
                "guild_id": str(guild_id),
                "query": query,
                "limit": limit,
            },
        }

        if user_ids:
            payload["d"]["user_ids"] = [str(uid) for uid in user_ids]

        await self._send(payload)
