"""
Main Client class - the heart of Auric
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable, Coroutine, Dict, List, Optional

from ..models.channel import Channel
from ..models.guild import Guild
from ..models.message import Message
from ..models.user import ClientUser, User
from .gateway import GatewayClient
from .http import HTTPClient, Route
from .intents import Intents

logger = logging.getLogger(__name__)


class Client:
    """
    The main Discord client

    This is the core of your bot. It handles the connection to Discord,
    manages the cache, and dispatches events.

    Example:
        ```python
        import auric

        bot = auric.Client(intents=auric.Intents.default())

        @bot.event
        async def on_ready():
            print(f"Logged in as {bot.user}")

        bot.run("YOUR_TOKEN")
        ```

    Args:
        intents: Gateway intents to use
        shard_id: Shard ID (for manual sharding)
        shard_count: Total shard count
        max_messages: Maximum messages to cache
    """

    def __init__(
        self,
        *,
        intents: Intents,
        shard_id: int = 0,
        shard_count: int = 1,
        max_messages: int = 1000,
        command_prefix: str = "!",
    ):
        # Core components
        self.intents = intents
        self.shard_id = shard_id
        self.shard_count = shard_count

        # HTTP client (initialized on login)
        self._http: Optional[HTTPClient] = None

        # Gateway client (initialized on connect)
        self._gateway: Optional[GatewayClient] = None

        # Bot user
        self.user: Optional[ClientUser] = None
        self.application_id: Optional[int] = None

        # Event system
        self._events: Dict[str, List[Callable]] = {}
        self._ready = False

        # Cache
        self._guilds: Dict[int, Guild] = {}
        self._users: Dict[int, User] = {}
        self._channels: Dict[int, Channel] = {}

        # Voice connections
        self._voice_clients: Dict[int, Any] = {}  # guild_id -> VoiceClient

        # Command system
        self.command_prefix = command_prefix
        self._commands: Dict[str, Any] = {}

        # Loop
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._closed = False

    # Properties

    @property
    def latency(self) -> float:
        """Gateway latency in seconds"""
        if self._gateway:
            return self._gateway.latency
        return float("inf")

    @property
    def guilds(self) -> List[Guild]:
        """List of cached guilds"""
        return list(self._guilds.values())

    @property
    def users(self) -> List[User]:
        """List of cached users"""
        return list(self._users.values())

    @property
    def is_ready(self) -> bool:
        """Whether the bot is ready"""
        return self._ready

    @property
    def is_closed(self) -> bool:
        """Whether the bot is closed"""
        return self._closed

    @property
    def gateway(self):
        """Gateway client instance"""
        return self._gateway

    # Event registration

    def event(self, coro: Callable) -> Callable:
        """
        Register an event handler

        Example:
            ```python
            @bot.event
            async def on_message(message):
                print(f"Message: {message.content}")
            ```
        """
        if not asyncio.iscoroutinefunction(coro):
            raise TypeError("Event handler must be a coroutine function")

        name = coro.__name__
        if not name.startswith("on_"):
            raise ValueError("Event handler must start with 'on_'")

        event_name = name[3:]  # Remove 'on_' prefix

        if event_name not in self._events:
            self._events[event_name] = []

        self._events[event_name].append(coro)
        return coro

    def listen(self, name: Optional[str] = None):
        """
        Decorator to register an event listener

        Example:
            ```python
            @bot.listen('message_create')
            async def my_message_handler(message):
                print(f"Got message: {message.content}")
            ```
        """

        def decorator(coro: Callable) -> Callable:
            event_name = name or coro.__name__
            if event_name.startswith("on_"):
                event_name = event_name[3:]

            if event_name not in self._events:
                self._events[event_name] = []

            self._events[event_name].append(coro)
            return coro

        return decorator

    def add_listener(self, event_name: str, handler: Callable) -> None:
        """
        Add a listener for an event (used by collectors)

        Args:
            event_name: Event name (with or without 'on_' prefix)
            handler: Async function to call
        """
        if event_name.startswith("on_"):
            event_name = event_name[3:]

        if event_name not in self._events:
            self._events[event_name] = []

        self._events[event_name].append(handler)

    def remove_listener(self, event_name: str, listener_id: Any) -> None:
        """
        Remove a listener for an event (used by collectors)

        Args:
            event_name: Event name (with or without 'on_' prefix)
            listener_id: ID of the listener (id(handler))
        """
        if event_name.startswith("on_"):
            event_name = event_name[3:]

        if event_name in self._events:
            self._events[event_name] = [h for h in self._events[event_name] if id(h) != listener_id]

    def dispatch(self, event: str, *args, **kwargs) -> None:
        """
        Dispatch an event to all registered handlers

        Args:
            event: Event name (without 'on_' prefix)
            *args: Arguments to pass to handlers
            **kwargs: Keyword arguments to pass to handlers
        """
        logger.debug(f"Dispatching event: {event}")

        # Get handlers
        handlers = self._events.get(event, [])

        # Schedule all handlers
        for handler in handlers:
            try:
                asyncio.create_task(handler(*args, **kwargs))
            except Exception as e:
                logger.error(f"Error in event handler for {event}: {e}", exc_info=True)

    # Gateway event handlers

    def _handle_gateway_event(self, event: str, data: Dict[str, Any]) -> None:
        """Handle gateway events"""
        method = f"_handle_{event.lower()}"

        try:
            handler = getattr(self, method, None)
            if handler:
                asyncio.create_task(handler(data))
            else:
                logger.debug(f"No handler for event: {event}")
        except Exception as e:
            logger.error(f"Error handling {event}: {e}", exc_info=True)

    async def _handle_ready(self, data: Dict[str, Any]) -> None:
        """Handle READY event"""
        logger.info("Received READY event")

        # Set user
        from ..models.user import ClientUser

        self.user = ClientUser(data=data["user"], http=self._http)
        self.application_id = int(data["application"]["id"])

        # Cache guilds (basic info)
        for guild_data in data.get("guilds", []):
            guild = Guild(data=guild_data, http=self._http)
            self._guilds[guild.id] = guild

            # Cache channels from guild
            for channel_data in guild_data.get("channels", []):
                channel = Channel(data=channel_data, http=self._http)
                self._channels[channel.id] = channel

        # Mark as ready
        self._ready = True

        # Dispatch ready event
        self.dispatch("ready")

    async def _handle_message_create(self, data: Dict[str, Any]) -> None:
        """Handle MESSAGE_CREATE event"""
        message = Message(data=data, http=self._http)

        # Cache author
        if message.author and message.author.id not in self._users:
            self._users[message.author.id] = message.author

        # Cache channel if not already cached
        if message.channel_id not in self._channels:
            # We don't have full channel data, but we can create a basic channel object
            channel_data = {
                "id": str(message.channel_id),
                "type": 0,  # Assume text channel for now
            }
            if message.guild_id:
                channel_data["guild_id"] = str(message.guild_id)

            channel = Channel(data=channel_data, http=self._http)
            self._channels[channel.id] = channel

        # Dispatch event
        self.dispatch("message", message)
        self.dispatch("message_create", message)

        # Process text commands
        await self._process_commands(message)

    async def _handle_message_update(self, data: Dict[str, Any]) -> None:
        """Handle MESSAGE_UPDATE event"""
        # Discord.js style: on_message_update(old, new)
        # We don't cache messages yet, so old is None
        message = Message(data=data, http=self._http)
        self.dispatch("message_update", None, message)

    async def _handle_message_delete(self, data: Dict[str, Any]) -> None:
        """Handle MESSAGE_DELETE event"""
        # Create a partial message object with the data we have
        message = Message(data=data, http=self._http)
        self.dispatch("message_delete", message)

    async def _handle_message_delete_bulk(self, data: Dict[str, Any]) -> None:
        """Handle MESSAGE_DELETE_BULK event"""
        self.dispatch("message_delete_bulk", data)

    async def _handle_message_reaction_add(self, data: Dict[str, Any]) -> None:
        """Handle MESSAGE_REACTION_ADD event"""
        # Discord.js style: on_reaction_add(reaction, user)
        # Create a simple reaction object
        from ..models.reaction import Reaction
        from ..models.user import User

        reaction = Reaction(data=data, http=self._http)
        user_data = (
            data.get("member", {}).get("user", {})
            if "member" in data
            else {"id": data.get("user_id")}
        )
        user = User(data=user_data, http=self._http) if user_data.get("id") else None
        self.dispatch("reaction_add", reaction, user)

    async def _handle_message_reaction_remove(self, data: Dict[str, Any]) -> None:
        """Handle MESSAGE_REACTION_REMOVE event"""
        # Discord.js style: on_reaction_remove(reaction, user)
        from ..models.reaction import Reaction
        from ..models.user import User

        reaction = Reaction(data=data, http=self._http)
        user_data = {"id": data.get("user_id")}
        user = User(data=user_data, http=self._http) if user_data.get("id") else None
        self.dispatch("reaction_remove", reaction, user)

    async def _handle_message_reaction_remove_all(self, data: Dict[str, Any]) -> None:
        """Handle MESSAGE_REACTION_REMOVE_ALL event"""
        self.dispatch("reaction_remove_all", data)

    async def _handle_message_reaction_remove_emoji(self, data: Dict[str, Any]) -> None:
        """Handle MESSAGE_REACTION_REMOVE_EMOJI event"""
        self.dispatch("reaction_remove_emoji", data)

    async def _handle_guild_create(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_CREATE event"""
        guild = Guild(data=data, http=self._http)
        self._guilds[guild.id] = guild

        self.dispatch("guild_join", guild)
        self.dispatch("guild_create", guild)

    async def _handle_guild_update(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_UPDATE event"""
        guild = Guild(data=data, http=self._http)
        self._guilds[guild.id] = guild
        self.dispatch("guild_update", guild)

    async def _handle_guild_delete(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_DELETE event"""
        guild_id = int(data.get("id", 0))
        if guild_id in self._guilds:
            guild = self._guilds.pop(guild_id)
            self.dispatch("guild_remove", guild)
        self.dispatch("guild_delete", data)

    async def _handle_guild_ban_add(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_BAN_ADD event"""
        self.dispatch("member_ban", data)

    async def _handle_guild_ban_remove(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_BAN_REMOVE event"""
        self.dispatch("member_unban", data)

    async def _handle_guild_emojis_update(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_EMOJIS_UPDATE event"""
        self.dispatch("guild_emojis_update", data)

    async def _handle_guild_stickers_update(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_STICKERS_UPDATE event"""
        self.dispatch("guild_stickers_update", data)

    async def _handle_guild_integrations_update(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_INTEGRATIONS_UPDATE event"""
        self.dispatch("guild_integrations_update", data)

    async def _handle_guild_member_add(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_MEMBER_ADD event"""
        from ..models.member import Member

        member = Member(data=data, http=self._http)
        self.dispatch("member_join", member)

    async def _handle_guild_member_update(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_MEMBER_UPDATE event"""
        from ..models.member import Member

        member = Member(data=data, http=self._http)
        self.dispatch("member_update", member)

    async def _handle_guild_member_remove(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_MEMBER_REMOVE event"""
        self.dispatch("member_remove", data)

    async def _handle_guild_members_chunk(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_MEMBERS_CHUNK event"""
        self.dispatch("guild_members_chunk", data)

    async def _handle_guild_role_create(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_ROLE_CREATE event"""
        from ..models.role import Role

        guild_id = int(data["guild_id"])
        role = Role(data=data.get("role", {}), guild_id=guild_id, http=self._http)
        self.dispatch("guild_role_create", role)

    async def _handle_guild_role_update(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_ROLE_UPDATE event"""
        from ..models.role import Role

        guild_id = int(data["guild_id"])
        role = Role(data=data.get("role", {}), guild_id=guild_id, http=self._http)
        self.dispatch("guild_role_update", role)

    async def _handle_guild_role_delete(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_ROLE_DELETE event"""
        # Create a partial role object with the data we have
        from ..models.role import Role

        guild_id = int(data["guild_id"])
        role_id = int(data["role_id"])
        # Create minimal role data
        role_data = {"id": role_id, "name": "Deleted Role"}
        role = Role(data=role_data, guild_id=guild_id, http=self._http)
        self.dispatch("guild_role_delete", role)

    async def _handle_channel_create(self, data: Dict[str, Any]) -> None:
        """Handle CHANNEL_CREATE event"""
        channel = Channel(data=data, http=self._http)
        self._channels[channel.id] = channel
        self.dispatch("channel_create", channel)

    async def _handle_channel_update(self, data: Dict[str, Any]) -> None:
        """Handle CHANNEL_UPDATE event"""
        channel = Channel(data=data, http=self._http)
        self._channels[channel.id] = channel
        self.dispatch("channel_update", channel)

    async def _handle_channel_delete(self, data: Dict[str, Any]) -> None:
        """Handle CHANNEL_DELETE event"""
        channel_id = int(data.get("id", 0))
        if channel_id in self._channels:
            channel = self._channels.pop(channel_id)
            self.dispatch("channel_delete", channel)

    async def _handle_channel_pins_update(self, data: Dict[str, Any]) -> None:
        """Handle CHANNEL_PINS_UPDATE event"""
        self.dispatch("channel_pins_update", data)

    async def _handle_thread_create(self, data: Dict[str, Any]) -> None:
        """Handle THREAD_CREATE event"""
        from ..models.channel import Thread

        thread = Thread(data=data, http=self._http)
        self.dispatch("thread_create", thread)

    async def _handle_thread_update(self, data: Dict[str, Any]) -> None:
        """Handle THREAD_UPDATE event"""
        from ..models.channel import Thread

        thread = Thread(data=data, http=self._http)
        self.dispatch("thread_update", thread)

    async def _handle_thread_delete(self, data: Dict[str, Any]) -> None:
        """Handle THREAD_DELETE event"""
        self.dispatch("thread_delete", data)

    async def _handle_thread_list_sync(self, data: Dict[str, Any]) -> None:
        """Handle THREAD_LIST_SYNC event"""
        self.dispatch("thread_list_sync", data)

    async def _handle_thread_member_update(self, data: Dict[str, Any]) -> None:
        """Handle THREAD_MEMBER_UPDATE event"""
        self.dispatch("thread_member_update", data)

    async def _handle_thread_members_update(self, data: Dict[str, Any]) -> None:
        """Handle THREAD_MEMBERS_UPDATE event"""
        self.dispatch("thread_members_update", data)

    async def _handle_guild_scheduled_event_create(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_SCHEDULED_EVENT_CREATE event"""
        from ..models.scheduled_event import ScheduledEvent

        event = ScheduledEvent(data=data, http=self._http)
        self.dispatch("scheduled_event_create", event)

    async def _handle_guild_scheduled_event_update(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_SCHEDULED_EVENT_UPDATE event"""
        from ..models.scheduled_event import ScheduledEvent

        event = ScheduledEvent(data=data, http=self._http)
        self.dispatch("scheduled_event_update", event)

    async def _handle_guild_scheduled_event_delete(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_SCHEDULED_EVENT_DELETE event"""
        self.dispatch("scheduled_event_delete", data)

    async def _handle_guild_scheduled_event_user_add(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_SCHEDULED_EVENT_USER_ADD event"""
        self.dispatch("scheduled_event_user_add", data)

    async def _handle_guild_scheduled_event_user_remove(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_SCHEDULED_EVENT_USER_REMOVE event"""
        self.dispatch("scheduled_event_user_remove", data)

    async def _handle_stage_instance_create(self, data: Dict[str, Any]) -> None:
        """Handle STAGE_INSTANCE_CREATE event"""
        from ..models.stage_instance import StageInstance

        stage = StageInstance(data=data, http=self._http)
        self.dispatch("stage_instance_create", stage)

    async def _handle_stage_instance_update(self, data: Dict[str, Any]) -> None:
        """Handle STAGE_INSTANCE_UPDATE event"""
        from ..models.stage_instance import StageInstance

        stage = StageInstance(data=data, http=self._http)
        self.dispatch("stage_instance_update", stage)

    async def _handle_stage_instance_delete(self, data: Dict[str, Any]) -> None:
        """Handle STAGE_INSTANCE_DELETE event"""
        self.dispatch("stage_instance_delete", data)

    async def _handle_voice_state_update(self, data: Dict[str, Any]) -> None:
        """Handle VOICE_STATE_UPDATE event"""
        # Update voice client with session info
        user_id = int(data.get("user_id", 0))
        if user_id == self.user.id:
            guild_id = int(data.get("guild_id", 0))
            if guild_id in self._voice_clients:
                voice_client = self._voice_clients[guild_id]
                voice_client.session_id = data.get("session_id")

        # Create VoiceState from data
        from ..models.voice import VoiceState

        voice_state = VoiceState(
            user_id=int(data.get("user_id", 0)),
            session_id=data.get("session_id", ""),
            deaf=data.get("deaf", False),
            mute=data.get("mute", False),
            self_deaf=data.get("self_deaf", False),
            self_mute=data.get("self_mute", False),
            self_video=data.get("self_video", False),
            suppress=data.get("suppress", False),
            channel_id=int(data["channel_id"]) if data.get("channel_id") else None,
            guild_id=int(data["guild_id"]) if data.get("guild_id") else None,
        )
        self.dispatch("voice_state_update", voice_state)

    async def _handle_voice_server_update(self, data: Dict[str, Any]) -> None:
        """Handle VOICE_SERVER_UPDATE event"""
        # Update voice client with server info
        guild_id = int(data.get("guild_id", 0))
        if guild_id in self._voice_clients:
            voice_client = self._voice_clients[guild_id]
            voice_client.token = data.get("token")
            voice_client.endpoint = data.get("endpoint")
            if hasattr(voice_client, "_connected"):
                voice_client._connected.set()

        self.dispatch("voice_server_update", data)

    async def _handle_voice_channel_effect_send(self, data: Dict[str, Any]) -> None:
        """Handle VOICE_CHANNEL_EFFECT_SEND event"""
        self.dispatch("voice_channel_effect_send", data)

    async def _handle_message_poll_vote_add(self, data: Dict[str, Any]) -> None:
        """Handle MESSAGE_POLL_VOTE_ADD event"""
        self.dispatch("poll_vote_add", data)

    async def _handle_message_poll_vote_remove(self, data: Dict[str, Any]) -> None:
        """Handle MESSAGE_POLL_VOTE_REMOVE event"""
        self.dispatch("poll_vote_remove", data)

    async def _handle_guild_audit_log_entry_create(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_AUDIT_LOG_ENTRY_CREATE event"""
        from ..models.audit_log import AuditLogEntry

        entry = AuditLogEntry(data=data, http=self._http)
        self.dispatch("audit_log_entry_create", entry)

    async def _handle_auto_moderation_rule_create(self, data: Dict[str, Any]) -> None:
        """Handle AUTO_MODERATION_RULE_CREATE event"""
        from ..models.auto_moderation import AutoModRule

        rule = AutoModRule(data=data, http=self._http)
        self.dispatch("auto_moderation_rule_create", rule)

    async def _handle_auto_moderation_rule_update(self, data: Dict[str, Any]) -> None:
        """Handle AUTO_MODERATION_RULE_UPDATE event"""
        from ..models.auto_moderation import AutoModRule

        rule = AutoModRule(data=data, http=self._http)
        self.dispatch("auto_moderation_rule_update", rule)

    async def _handle_auto_moderation_rule_delete(self, data: Dict[str, Any]) -> None:
        """Handle AUTO_MODERATION_RULE_DELETE event"""
        self.dispatch("auto_moderation_rule_delete", data)

    async def _handle_auto_moderation_action_execution(self, data: Dict[str, Any]) -> None:
        """Handle AUTO_MODERATION_ACTION_EXECUTION event"""
        self.dispatch("auto_moderation_action_execution", data)

    async def _handle_invite_create(self, data: Dict[str, Any]) -> None:
        """Handle INVITE_CREATE event"""
        from ..models.invite import Invite

        invite = Invite(data=data, client=self)
        self.dispatch("invite_create", invite)

    async def _handle_invite_delete(self, data: Dict[str, Any]) -> None:
        """Handle INVITE_DELETE event"""
        self.dispatch("invite_delete", data)

    async def _handle_presence_update(self, data: Dict[str, Any]) -> None:
        """Handle PRESENCE_UPDATE event"""
        from ..models.presence import Presence

        presence = Presence(data=data, http=self._http)
        self.dispatch("presence_update", presence)

    async def _handle_typing_start(self, data: Dict[str, Any]) -> None:
        """Handle TYPING_START event"""
        self.dispatch("typing_start", data)

    async def _handle_user_update(self, data: Dict[str, Any]) -> None:
        """Handle USER_UPDATE event"""
        from ..models.user import User

        user = User(data=data, http=self._http)
        if user.id in self._users:
            self._users[user.id] = user
        self.dispatch("user_update", user)

    async def _handle_webhooks_update(self, data: Dict[str, Any]) -> None:
        """Handle WEBHOOKS_UPDATE event"""
        # Create a partial channel object
        from ..models.channel import Channel

        channel_id = int(data["channel_id"])
        guild_id = int(data["guild_id"])
        channel_data = {"id": channel_id, "guild_id": guild_id, "type": 0}
        channel = Channel(data=channel_data, http=self._http)
        self.dispatch("webhooks_update", channel)

    async def _handle_guild_soundboard_sound_create(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_SOUNDBOARD_SOUND_CREATE event"""
        from ..models.soundboard import SoundboardSound

        sound = SoundboardSound(data=data, http=self._http)
        self.dispatch("soundboard_sound_create", sound)

    async def _handle_guild_soundboard_sound_update(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_SOUNDBOARD_SOUND_UPDATE event"""
        from ..models.soundboard import SoundboardSound

        sound = SoundboardSound(data=data, http=self._http)
        self.dispatch("soundboard_sound_update", sound)

    async def _handle_guild_soundboard_sound_delete(self, data: Dict[str, Any]) -> None:
        """Handle GUILD_SOUNDBOARD_SOUND_DELETE event"""
        self.dispatch("soundboard_sound_delete", data)

    async def _handle_soundboard_sounds(self, data: Dict[str, Any]) -> None:
        """Handle SOUNDBOARD_SOUNDS event"""
        self.dispatch("soundboard_sounds", data)

    async def _handle_entitlement_create(self, data: Dict[str, Any]) -> None:
        """Handle ENTITLEMENT_CREATE event"""
        from ..models.entitlement import Entitlement

        entitlement = Entitlement(data=data, client=self)
        self.dispatch("entitlement_create", entitlement)

    async def _handle_entitlement_update(self, data: Dict[str, Any]) -> None:
        """Handle ENTITLEMENT_UPDATE event"""
        from ..models.entitlement import Entitlement

        entitlement = Entitlement(data=data, client=self)
        self.dispatch("entitlement_update", entitlement)

    async def _handle_entitlement_delete(self, data: Dict[str, Any]) -> None:
        """Handle ENTITLEMENT_DELETE event"""
        self.dispatch("entitlement_delete", data)

    async def _handle_subscription_create(self, data: Dict[str, Any]) -> None:
        """Handle SUBSCRIPTION_CREATE event"""
        from ..models.entitlement import Subscription

        subscription = Subscription(data=data, client=self)
        self.dispatch("subscription_create", subscription)

    async def _handle_subscription_update(self, data: Dict[str, Any]) -> None:
        """Handle SUBSCRIPTION_UPDATE event"""
        from ..models.entitlement import Subscription

        subscription = Subscription(data=data, client=self)
        self.dispatch("subscription_update", subscription)

    async def _handle_subscription_delete(self, data: Dict[str, Any]) -> None:
        """Handle SUBSCRIPTION_DELETE event"""
        self.dispatch("subscription_delete", data)

    async def _handle_integration_create(self, data: Dict[str, Any]) -> None:
        """Handle INTEGRATION_CREATE event"""
        from ..models.integration import Integration

        integration = Integration(data=data, http=self._http)
        self.dispatch("integration_create", integration)

    async def _handle_integration_update(self, data: Dict[str, Any]) -> None:
        """Handle INTEGRATION_UPDATE event"""
        from ..models.integration import Integration

        integration = Integration(data=data, http=self._http)
        self.dispatch("integration_update", integration)

    async def _handle_integration_delete(self, data: Dict[str, Any]) -> None:
        """Handle INTEGRATION_DELETE event"""
        self.dispatch("integration_delete", data)

    async def _handle_interaction_create(self, data: Dict[str, Any]) -> None:
        """Handle INTERACTION_CREATE event"""
        from ..models.interaction import Interaction

        interaction = Interaction(data=data, http=self._http)

        # Dispatch event
        self.dispatch("interaction", interaction)
        self.dispatch("interaction_create", interaction)

    # Connection management

    async def login(self, token: str) -> None:
        """
        Login to Discord

        Args:
            token: Bot token
        """
        logger.info("Logging in...")

        # Create HTTP client
        self._http = HTTPClient(token)

        # Get bot user info
        data = await self._http.request(Route("GET", "/users/@me"))
        from ..models.user import ClientUser

        self.user = ClientUser(data=data, http=self._http)

        # Get application info
        app_data = await self._http.request(Route("GET", "/oauth2/applications/@me"))
        self.application_id = int(app_data["id"])

        logger.info(f"Logged in as {self.user.username}")

    async def connect(self) -> None:
        """Connect to Discord gateway"""
        logger.info("Connecting to gateway...")

        # Create gateway client
        self._gateway = GatewayClient(
            token=self._http.token,
            intents=self.intents,
            shard_id=self.shard_id,
            shard_count=self.shard_count,
            dispatch=self._handle_gateway_event,
        )

        # Connect
        await self._gateway.connect()

        logger.info("Connected to gateway")

    async def close(self) -> None:
        """Close the bot"""
        if self._closed:
            return

        logger.info("Closing...")

        self._closed = True
        self._ready = False

        # Close gateway
        if self._gateway:
            await self._gateway.close()

        # Close HTTP
        if self._http:
            await self._http.close()

        logger.info("Closed")

    async def start(self, token: str) -> None:
        """
        Start the bot

        Args:
            token: Bot token
        """
        await self.login(token)
        await self.connect()

    def run(self, token: str) -> None:
        """
        Run the bot (blocking)

        This is a convenience method that handles the event loop.

        Args:
            token: Bot token
        """

        async def runner():
            try:
                await self.start(token)

                # Keep running until closed
                while not self._closed:
                    await asyncio.sleep(1)

            except KeyboardInterrupt:
                logger.info("Received keyboard interrupt")
            finally:
                await self.close()

        # Get or create event loop
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        self._loop = loop

        # Run
        try:
            loop.run_until_complete(runner())
        except KeyboardInterrupt:
            logger.info("Keyboard interrupt")
        finally:
            logger.info("Cleaning up...")
            loop.close()

    # Utility methods

    def get_guild(self, guild_id: int) -> Optional[Guild]:
        """Get a guild from cache"""
        return self._guilds.get(guild_id)

    def get_user(self, user_id: int) -> Optional[User]:
        """Get a user from cache"""
        return self._users.get(user_id)

    def get_channel(self, channel_id: int) -> Optional[Channel]:
        """Get a channel from cache"""
        return self._channels.get(channel_id)

    # Text Commands

    def command(self, **kwargs):
        """
        Decorator to register a text command.

        Example:
            ```python
            @bot.command()
            async def hello(ctx):
                await ctx.send("Hello!")
            ```
        """
        from ..commands import command as create_command

        def decorator(func):
            cmd = create_command(**kwargs)(func)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, **kwargs):
        """
        Decorator to register a command group.

        Example:
            ```python
            @bot.group()
            async def config(ctx):
                pass

            @config.command()
            async def set(ctx, key, value):
                await ctx.send(f"Set {key} = {value}")
            ```
        """
        from ..commands import group as create_group

        def decorator(func):
            grp = create_group(**kwargs)(func)
            self.add_command(grp)
            return grp

        return decorator

    def add_command(self, command) -> None:
        """
        Add a command to the bot.

        Args:
            command: Command or Group to add
        """
        self._commands[command.name] = command
        for alias in command.aliases:
            self._commands[alias] = command

    def remove_command(self, name: str):
        """
        Remove a command from the bot.

        Args:
            name: Command name or alias

        Returns:
            The removed command, or None
        """
        command = self._commands.pop(name, None)
        if command:
            # Remove all aliases
            for alias in command.aliases:
                self._commands.pop(alias, None)
        return command

    def get_command(self, name: str):
        """
        Get a command by name or alias.

        Args:
            name: Command name or alias

        Returns:
            The command, or None
        """
        return self._commands.get(name)

    async def _process_commands(self, message: Message) -> None:
        """Internal handler for processing commands from messages"""
        # Ignore bot messages
        if message.author.bot:
            return

        # Check if message starts with prefix
        content = message.content
        if not content.startswith(self.command_prefix):
            return

        # Remove prefix
        content = content[len(self.command_prefix) :]

        # Split into command and args
        parts = content.split()
        if not parts:
            return

        command_name = parts[0]
        args = parts[1:]

        # Get command
        command = self.get_command(command_name)
        if not command:
            return

        # Create context
        from ..commands import Context

        ctx = Context(
            bot=self,
            message=message,
            command=command,
            prefix=self.command_prefix,
            invoked_with=command_name,
            args=tuple(args),
        )

        # Invoke command
        try:
            await command.invoke(ctx)
        except Exception as e:
            logger.error(f"Error in command {command_name}: {e}", exc_info=True)
            # Dispatch command_error event
            self.dispatch("command_error", ctx, e)

    # Application Commands

    async def create_global_command(
        self,
        name: str,
        description: str,
        *,
        type: int = 1,
        options: Optional[List] = None,
        name_localizations: Optional[Dict[str, str]] = None,
        description_localizations: Optional[Dict[str, str]] = None,
        default_member_permissions: Optional[str] = None,
        dm_permission: Optional[bool] = None,
        nsfw: bool = False,
        integration_types: Optional[List[int]] = None,
        contexts: Optional[List[int]] = None,
    ):
        """
        Create a global application command

        Args:
            name: Command name (1-32 characters)
            description: Command description (1-100 characters for CHAT_INPUT)
            type: Command type (1=CHAT_INPUT, 2=USER, 3=MESSAGE)
            options: Command options (CHAT_INPUT only)
            name_localizations: Localization dictionary for name
            description_localizations: Localization dictionary for description
            default_member_permissions: Required permissions as bit set
            dm_permission: Whether available in DMs
            nsfw: Whether age-restricted
            integration_types: Installation contexts
            contexts: Interaction contexts

        Returns:
            ApplicationCommand

        Raises:
            HTTPException: Creation failed

        Note:
            Global commands can take up to 1 hour to propagate
        """
        from ..models.command import ApplicationCommand, CommandOption

        payload = {"name": name, "description": description, "type": type}

        if options:
            payload["options"] = [
                o.to_dict() if isinstance(o, CommandOption) else o for o in options
            ]

        if name_localizations:
            payload["name_localizations"] = name_localizations

        if description_localizations:
            payload["description_localizations"] = description_localizations

        if default_member_permissions is not None:
            payload["default_member_permissions"] = default_member_permissions

        if dm_permission is not None:
            payload["dm_permission"] = dm_permission

        if nsfw:
            payload["nsfw"] = nsfw

        if integration_types:
            payload["integration_types"] = integration_types

        if contexts:
            payload["contexts"] = contexts

        data = await self._http.request(
            Route("POST", "/applications/{app_id}/commands", app_id=self.application_id),
            json=payload,
        )

        return ApplicationCommand(data=data, http=self._http)

    async def create_guild_command(
        self,
        guild_id: int,
        name: str,
        description: str,
        *,
        type: int = 1,
        options: Optional[List] = None,
        name_localizations: Optional[Dict[str, str]] = None,
        description_localizations: Optional[Dict[str, str]] = None,
        default_member_permissions: Optional[str] = None,
        nsfw: bool = False,
    ):
        """
        Create a guild application command

        Args:
            guild_id: Guild ID
            name: Command name (1-32 characters)
            description: Command description (1-100 characters for CHAT_INPUT)
            type: Command type (1=CHAT_INPUT, 2=USER, 3=MESSAGE)
            options: Command options (CHAT_INPUT only)
            name_localizations: Localization dictionary for name
            description_localizations: Localization dictionary for description
            default_member_permissions: Required permissions as bit set
            nsfw: Whether age-restricted

        Returns:
            ApplicationCommand

        Raises:
            HTTPException: Creation failed

        Note:
            Guild commands update instantly
        """
        from ..models.command import ApplicationCommand, CommandOption

        payload = {"name": name, "description": description, "type": type}

        if options:
            payload["options"] = [
                o.to_dict() if isinstance(o, CommandOption) else o for o in options
            ]

        if name_localizations:
            payload["name_localizations"] = name_localizations

        if description_localizations:
            payload["description_localizations"] = description_localizations

        if default_member_permissions is not None:
            payload["default_member_permissions"] = default_member_permissions

        if nsfw:
            payload["nsfw"] = nsfw

        data = await self._http.request(
            Route(
                "POST",
                "/applications/{app_id}/guilds/{guild_id}/commands",
                app_id=self.application_id,
                guild_id=guild_id,
            ),
            json=payload,
        )

        return ApplicationCommand(data=data, http=self._http)

    async def get_global_commands(self):
        """
        Get all global application commands

        Returns:
            List of ApplicationCommand
        """
        from ..models.command import ApplicationCommand

        data = await self._http.request(
            Route("GET", "/applications/{app_id}/commands", app_id=self.application_id)
        )

        return [ApplicationCommand(data=cmd, http=self._http) for cmd in data]

    async def get_guild_commands(self, guild_id: int):
        """
        Get all guild application commands

        Args:
            guild_id: Guild ID

        Returns:
            List of ApplicationCommand
        """
        from ..models.command import ApplicationCommand

        data = await self._http.request(
            Route(
                "GET",
                "/applications/{app_id}/guilds/{guild_id}/commands",
                app_id=self.application_id,
                guild_id=guild_id,
            )
        )

        return [ApplicationCommand(data=cmd, http=self._http) for cmd in data]

    async def bulk_overwrite_global_commands(self, commands: List[Dict[str, Any]]):
        """
        Bulk overwrite all global commands

        This will replace ALL global commands with the provided list.
        Commands not in the list will be deleted.

        Args:
            commands: List of command dicts

        Returns:
            List of ApplicationCommand

        Note:
            Takes effect after up to 1 hour
        """
        from ..models.command import ApplicationCommand

        data = await self._http.request(
            Route("PUT", "/applications/{app_id}/commands", app_id=self.application_id),
            json=commands,
        )

        return [ApplicationCommand(data=cmd, http=self._http) for cmd in data]

    async def bulk_overwrite_guild_commands(self, guild_id: int, commands: List[Dict[str, Any]]):
        """
        Bulk overwrite all guild commands

        This will replace ALL guild commands with the provided list.
        Commands not in the list will be deleted.

        Args:
            guild_id: Guild ID
            commands: List of command dicts

        Returns:
            List of ApplicationCommand

        Note:
            Takes effect instantly
        """
        from ..models.command import ApplicationCommand

        data = await self._http.request(
            Route(
                "PUT",
                "/applications/{app_id}/guilds/{guild_id}/commands",
                app_id=self.application_id,
                guild_id=guild_id,
            ),
            json=commands,
        )

        return [ApplicationCommand(data=cmd, http=self._http) for cmd in data]

    # Context manager support

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()
