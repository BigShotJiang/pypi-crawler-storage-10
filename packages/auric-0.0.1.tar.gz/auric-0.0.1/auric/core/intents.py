"""
Gateway Intents - Control which events your bot receives
"""

from __future__ import annotations

from enum import IntFlag
from typing import ClassVar


class Intents(IntFlag):
    """
    Discord Gateway Intents

    Intents are used to subscribe to specific events from Discord.
    Some intents are privileged and require approval from Discord.
    """

    # Standard Intents
    GUILDS = 1 << 0
    GUILD_MEMBERS = 1 << 1  # Privileged
    GUILD_MODERATION = 1 << 2
    GUILD_EMOJIS_AND_STICKERS = 1 << 3
    GUILD_INTEGRATIONS = 1 << 4
    GUILD_WEBHOOKS = 1 << 5
    GUILD_INVITES = 1 << 6
    GUILD_VOICE_STATES = 1 << 7
    GUILD_PRESENCES = 1 << 8  # Privileged
    GUILD_MESSAGES = 1 << 9
    GUILD_MESSAGE_REACTIONS = 1 << 10
    GUILD_MESSAGE_TYPING = 1 << 11
    DIRECT_MESSAGES = 1 << 12
    DIRECT_MESSAGE_REACTIONS = 1 << 13
    DIRECT_MESSAGE_TYPING = 1 << 14
    MESSAGE_CONTENT = 1 << 15  # Privileged
    GUILD_SCHEDULED_EVENTS = 1 << 16
    AUTO_MODERATION_CONFIGURATION = 1 << 20
    AUTO_MODERATION_EXECUTION = 1 << 21
    GUILD_MESSAGE_POLLS = 1 << 24
    DIRECT_MESSAGE_POLLS = 1 << 25

    @classmethod
    def none(cls) -> Intents:
        """No intents enabled"""
        return cls(0)

    @classmethod
    def all(cls) -> Intents:
        """All intents enabled (including privileged)"""
        return cls(
            cls.GUILDS
            | cls.GUILD_MEMBERS
            | cls.GUILD_MODERATION
            | cls.GUILD_EMOJIS_AND_STICKERS
            | cls.GUILD_INTEGRATIONS
            | cls.GUILD_WEBHOOKS
            | cls.GUILD_INVITES
            | cls.GUILD_VOICE_STATES
            | cls.GUILD_PRESENCES
            | cls.GUILD_MESSAGES
            | cls.GUILD_MESSAGE_REACTIONS
            | cls.GUILD_MESSAGE_TYPING
            | cls.DIRECT_MESSAGES
            | cls.DIRECT_MESSAGE_REACTIONS
            | cls.DIRECT_MESSAGE_TYPING
            | cls.MESSAGE_CONTENT
            | cls.GUILD_SCHEDULED_EVENTS
            | cls.AUTO_MODERATION_CONFIGURATION
            | cls.AUTO_MODERATION_EXECUTION
            | cls.GUILD_MESSAGE_POLLS
            | cls.DIRECT_MESSAGE_POLLS
        )

    @classmethod
    def default(cls) -> Intents:
        """Default intents (non-privileged)"""
        return cls(
            cls.GUILDS
            | cls.GUILD_MODERATION
            | cls.GUILD_EMOJIS_AND_STICKERS
            | cls.GUILD_INTEGRATIONS
            | cls.GUILD_WEBHOOKS
            | cls.GUILD_INVITES
            | cls.GUILD_VOICE_STATES
            | cls.GUILD_MESSAGES
            | cls.GUILD_MESSAGE_REACTIONS
            | cls.GUILD_MESSAGE_TYPING
            | cls.DIRECT_MESSAGES
            | cls.DIRECT_MESSAGE_REACTIONS
            | cls.DIRECT_MESSAGE_TYPING
            | cls.GUILD_SCHEDULED_EVENTS
            | cls.AUTO_MODERATION_CONFIGURATION
            | cls.AUTO_MODERATION_EXECUTION
            | cls.GUILD_MESSAGE_POLLS
            | cls.DIRECT_MESSAGE_POLLS
        )

    @classmethod
    def unprivileged(cls) -> Intents:
        """Alias for default()"""
        return cls.default()

    @property
    def is_privileged(self) -> bool:
        """Check if any privileged intents are enabled"""
        privileged = self.GUILD_MEMBERS | self.GUILD_PRESENCES | self.MESSAGE_CONTENT
        return bool(self & privileged)

    @property
    def guilds(self) -> bool:
        return bool(self & self.GUILDS)

    @property
    def members(self) -> bool:
        return bool(self & self.GUILD_MEMBERS)

    @property
    def moderation(self) -> bool:
        return bool(self & self.GUILD_MODERATION)

    @property
    def emojis_and_stickers(self) -> bool:
        return bool(self & self.GUILD_EMOJIS_AND_STICKERS)

    @property
    def integrations(self) -> bool:
        return bool(self & self.GUILD_INTEGRATIONS)

    @property
    def webhooks(self) -> bool:
        return bool(self & self.GUILD_WEBHOOKS)

    @property
    def invites(self) -> bool:
        return bool(self & self.GUILD_INVITES)

    @property
    def voice_states(self) -> bool:
        return bool(self & self.GUILD_VOICE_STATES)

    @property
    def presences(self) -> bool:
        return bool(self & self.GUILD_PRESENCES)

    @property
    def guild_messages(self) -> bool:
        return bool(self & self.GUILD_MESSAGES)

    @property
    def guild_reactions(self) -> bool:
        return bool(self & self.GUILD_MESSAGE_REACTIONS)

    @property
    def guild_typing(self) -> bool:
        return bool(self & self.GUILD_MESSAGE_TYPING)

    @property
    def dm_messages(self) -> bool:
        return bool(self & self.DIRECT_MESSAGES)

    @property
    def dm_reactions(self) -> bool:
        return bool(self & self.DIRECT_MESSAGE_REACTIONS)

    @property
    def dm_typing(self) -> bool:
        return bool(self & self.DIRECT_MESSAGE_TYPING)

    @property
    def message_content(self) -> bool:
        return bool(self & self.MESSAGE_CONTENT)

    @property
    def guild_scheduled_events(self) -> bool:
        return bool(self & self.GUILD_SCHEDULED_EVENTS)

    @property
    def auto_moderation_configuration(self) -> bool:
        return bool(self & self.AUTO_MODERATION_CONFIGURATION)

    @property
    def auto_moderation_execution(self) -> bool:
        return bool(self & self.AUTO_MODERATION_EXECUTION)

    @property
    def guild_polls(self) -> bool:
        return bool(self & self.GUILD_MESSAGE_POLLS)

    @property
    def dm_polls(self) -> bool:
        return bool(self & self.DIRECT_MESSAGE_POLLS)
