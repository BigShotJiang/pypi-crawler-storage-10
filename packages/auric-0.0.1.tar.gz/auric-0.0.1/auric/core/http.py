"""
HTTP Client with advanced rate limiting and connection pooling
"""

from __future__ import annotations

import asyncio
import sys
import time
from typing import Any, Dict, List, Literal, Optional
from urllib.parse import quote

import aiohttp
import orjson

from ..utils.exceptions import (
    DiscordServerError,
    Forbidden,
    HTTPException,
    NotFound,
    RateLimited,
)
from .types import BASE_URL, MISSING, Snowflake


class Route:
    """Represents an HTTP route for rate limiting"""

    def __init__(self, method: str, path: str, **parameters: Any):
        self.method = method
        self.path = path
        self.parameters = parameters

        # Replace parameters in path
        url = self.path
        if parameters:
            url = url.format_map(
                {k: quote(str(v)) if isinstance(v, str) else v for k, v in parameters.items()}
            )

        self.url = BASE_URL + url

        # Create bucket key for rate limiting
        # Major parameters are guild_id, channel_id, webhook_id
        major_params = []
        if "guild_id" in parameters:
            major_params.append(str(parameters["guild_id"]))
        if "channel_id" in parameters:
            major_params.append(str(parameters["channel_id"]))
        if "webhook_id" in parameters:
            major_params.append(str(parameters["webhook_id"]))

        self.bucket = f"{method}:{path}:{':'.join(major_params)}"

    def __repr__(self) -> str:
        return f"<Route {self.method} {self.path}>"


class RateLimitBucket:
    """Rate limit bucket for a specific route"""

    def __init__(self):
        self.remaining: int = 1
        self.limit: int = 1
        self.reset_after: float = 0.0
        self.reset: float = 0.0
        self.lock = asyncio.Lock()

    async def acquire(self) -> None:
        """Acquire rate limit bucket, waiting if necessary"""
        async with self.lock:
            # Check if we need to wait
            now = time.time()

            if self.remaining == 0:
                # Calculate sleep time
                sleep_time = self.reset - now
                if sleep_time > 0:
                    await asyncio.sleep(sleep_time)

            self.remaining = max(0, self.remaining - 1)

    def update(self, headers: Dict[str, str]) -> None:
        """Update rate limit information from response headers"""
        self.remaining = int(headers.get("X-RateLimit-Remaining", 1))
        self.limit = int(headers.get("X-RateLimit-Limit", 1))

        reset_after = headers.get("X-RateLimit-Reset-After")
        if reset_after:
            self.reset_after = float(reset_after)
            self.reset = time.time() + self.reset_after

        reset = headers.get("X-RateLimit-Reset")
        if reset:
            self.reset = float(reset)


class HTTPClient:
    """
    HTTP client for Discord API with rate limiting and retries
    """

    def __init__(
        self,
        token: str,
        *,
        session: Optional[aiohttp.ClientSession] = None,
        max_retries: int = 5,
        timeout: float = 30.0,
    ):
        self.token = token
        self._session = session
        self.max_retries = max_retries
        self.timeout = aiohttp.ClientTimeout(total=timeout)

        # Rate limiting
        self._buckets: Dict[str, RateLimitBucket] = {}
        self._global_lock = asyncio.Lock()
        self._global_over: float = 0.0

        # User agent
        self.user_agent = f"DiscordBot (Auric, 0.1.0) Python/{sys.version_info[0]}.{sys.version_info[1]} aiohttp/{aiohttp.__version__}"

    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create aiohttp session"""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=self.timeout,
                json_serialize=lambda obj: orjson.dumps(obj).decode("utf-8"),
            )
        return self._session

    async def close(self) -> None:
        """Close the HTTP client"""
        if self._session and not self._session.closed:
            await self._session.close()

    def _get_bucket(self, route: Route) -> RateLimitBucket:
        """Get or create rate limit bucket for route"""
        if route.bucket not in self._buckets:
            self._buckets[route.bucket] = RateLimitBucket()
        return self._buckets[route.bucket]

    async def request(
        self,
        route: Route,
        *,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[aiohttp.FormData] = None,
        files: Optional[List[Any]] = None,
        reason: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """
        Make an HTTP request to Discord API

        Args:
            route: API route to request
            json: JSON body
            data: Form data (for multipart)
            files: List of File objects to upload
            reason: Audit log reason
            params: Query parameters

        Returns:
            Parsed JSON response

        Raises:
            HTTPException: Request failed
            RateLimited: Hit rate limit
        """
        bucket = self._get_bucket(route)

        # Handle global rate limit
        now = time.time()
        if self._global_over > now:
            await asyncio.sleep(self._global_over - now)

        # Acquire bucket rate limit
        await bucket.acquire()

        # Prepare headers
        headers = {
            "Authorization": f"Bot {self.token}",
            "User-Agent": self.user_agent,
        }

        if reason:
            headers["X-Audit-Log-Reason"] = quote(reason)

        # Handle file uploads (File objects from utils.file)
        if files:
            from ..utils.file import File

            data = aiohttp.FormData()

            # Add attachments to JSON payload
            if json:
                attachments = [f.to_dict(i) for i, f in enumerate(files)]
                json["attachments"] = attachments

                # Add payload_json
                data.add_field(
                    "payload_json",
                    orjson.dumps(json).decode("utf-8"),
                    content_type="application/json",
                )

            # Add each file
            for i, file in enumerate(files):
                if not isinstance(file, File):
                    raise TypeError(f"Expected File object, got {type(file).__name__}")

                file_data = file.read()
                data.add_field(
                    f"files[{i}]", file_data, filename=file.filename, content_type=file.content_type
                )
        elif json:
            headers["Content-Type"] = "application/json"

        # Retry loop
        for attempt in range(self.max_retries):
            try:
                session = await self._get_session()

                async with session.request(
                    route.method,
                    route.url,
                    headers=headers,
                    json=json if not files else None,
                    data=data,
                    params=params,
                ) as response:
                    # Update rate limit info
                    bucket.update(dict(response.headers))

                    # Handle rate limiting
                    if response.status == 429:
                        retry_after = float(response.headers.get("Retry-After", 1.0))
                        is_global = response.headers.get("X-RateLimit-Global", False)

                        if is_global:
                            async with self._global_lock:
                                self._global_over = time.time() + retry_after

                        await asyncio.sleep(retry_after)
                        continue

                    # Parse response
                    if response.headers.get("Content-Type", "").startswith("application/json"):
                        text = await response.text()
                        data = orjson.loads(text) if text else None
                    else:
                        data = await response.read()

                    # Handle errors
                    if 300 > response.status >= 200:
                        return data

                    # Error responses
                    if response.status == 403:
                        raise Forbidden(response, data)
                    elif response.status == 404:
                        raise NotFound(response, data)
                    elif response.status >= 500:
                        raise DiscordServerError(response, data)
                    else:
                        raise HTTPException(response, data)

            except asyncio.TimeoutError:
                if attempt >= self.max_retries - 1:
                    raise
                await asyncio.sleep(1 + attempt * 2)
            except aiohttp.ClientError:
                if attempt >= self.max_retries - 1:
                    raise
                await asyncio.sleep(1 + attempt * 2)

        raise HTTPException(None, "Max retries exceeded")

    # Convenience methods
    async def get(self, route: Route, **kwargs: Any) -> Any:
        return await self.request(Route("GET", route.path, **route.parameters), **kwargs)

    async def post(self, route: Route, **kwargs: Any) -> Any:
        return await self.request(Route("POST", route.path, **route.parameters), **kwargs)

    async def put(self, route: Route, **kwargs: Any) -> Any:
        return await self.request(Route("PUT", route.path, **route.parameters), **kwargs)

    async def patch(self, route: Route, **kwargs: Any) -> Any:
        return await self.request(Route("PATCH", route.path, **route.parameters), **kwargs)

    async def delete(self, route: Route, **kwargs: Any) -> Any:
        return await self.request(Route("DELETE", route.path, **route.parameters), **kwargs)

    # Invite methods
    async def get_invite(self, code: str, *, params: dict = None):
        """Get invite by code."""
        route = Route("GET", f"/invites/{code}")
        return await self.request(route, params=params)

    async def delete_invite(self, code: str, *, reason: Optional[str] = None):
        """Delete an invite."""
        route = Route("DELETE", f"/invites/{code}")
        return await self.request(route, reason=reason)

    async def get_channel_invites(self, channel_id: Snowflake):
        """Get invites for a channel."""
        route = Route("GET", f"/channels/{channel_id}/invites")
        return await self.request(route)

    async def create_channel_invite(
        self,
        channel_id: Snowflake,
        *,
        max_age: int = None,
        max_uses: int = None,
        temporary: bool = None,
        unique: bool = None,
        json: dict = None,
        reason: Optional[str] = None,
        **kwargs,
    ):
        """Create a channel invite."""
        route = Route("POST", f"/channels/{channel_id}/invites")

        if json is None:
            json = {}
            if max_age is not None:
                json["max_age"] = max_age
            if max_uses is not None:
                json["max_uses"] = max_uses
            if temporary is not None:
                json["temporary"] = temporary
            if unique is not None:
                json["unique"] = unique
            json.update(kwargs)

        return await self.request(route, json=json, reason=reason)

    async def get_guild_invites(self, guild_id: Snowflake):
        """Get invites for a guild."""
        route = Route("GET", f"/guilds/{guild_id}/invites")
        return await self.request(route)

    # Webhook methods
    async def fetch_webhook(self, webhook_id: Snowflake, *, token: Optional[str] = None):
        """
        Fetch a webhook by ID

        Args:
            webhook_id: Webhook ID
            token: Optional webhook token (if provided, no auth required)

        Returns:
            Webhook data
        """
        if token:
            route = Route("GET", f"/webhooks/{webhook_id}/{token}")
        else:
            route = Route("GET", f"/webhooks/{webhook_id}")
        return await self.request(route)

    # Audit Log methods
    async def get_audit_logs(
        self,
        guild_id: Snowflake,
        *,
        user_id: Optional[Snowflake] = None,
        action_type: Optional[int] = None,
        before: Optional[Snowflake] = None,
        after: Optional[Snowflake] = None,
        limit: int = 50,
    ):
        """Get guild audit logs"""
        route = Route("GET", f"/guilds/{guild_id}/audit-logs")
        params = {"limit": limit}

        if user_id:
            params["user_id"] = user_id
        if action_type is not None:
            params["action_type"] = action_type
        if before:
            params["before"] = before
        if after:
            params["after"] = after

        return await self.request(route, params=params)

    # Auto Moderation methods
    async def get_auto_mod_rules(self, guild_id: Snowflake):
        """Get all auto-mod rules for a guild"""
        route = Route("GET", f"/guilds/{guild_id}/auto-moderation/rules")
        return await self.request(route)

    async def get_auto_mod_rule(self, guild_id: Snowflake, rule_id: Snowflake):
        """Get a specific auto-mod rule"""
        route = Route("GET", f"/guilds/{guild_id}/auto-moderation/rules/{rule_id}")
        return await self.request(route)

    async def create_auto_mod_rule(
        self, guild_id: Snowflake, *, json: dict, reason: Optional[str] = None
    ):
        """Create an auto-mod rule"""
        route = Route("POST", f"/guilds/{guild_id}/auto-moderation/rules")
        return await self.request(route, json=json, reason=reason)

    async def modify_auto_mod_rule(
        self, guild_id: Snowflake, rule_id: Snowflake, *, json: dict, reason: Optional[str] = None
    ):
        """Modify an auto-mod rule"""
        route = Route("PATCH", f"/guilds/{guild_id}/auto-moderation/rules/{rule_id}")
        return await self.request(route, json=json, reason=reason)

    async def delete_auto_mod_rule(
        self, guild_id: Snowflake, rule_id: Snowflake, *, reason: Optional[str] = None
    ):
        """Delete an auto-mod rule"""
        route = Route("DELETE", f"/guilds/{guild_id}/auto-moderation/rules/{rule_id}")
        return await self.request(route, reason=reason)

    # Scheduled Event methods
    async def get_scheduled_events(self, guild_id: Snowflake, *, with_user_count: bool = False):
        """Get all scheduled events for a guild"""
        route = Route("GET", f"/guilds/{guild_id}/scheduled-events")
        params = {}
        if with_user_count:
            params["with_user_count"] = "true"
        return await self.request(route, params=params)

    async def get_scheduled_event(
        self, guild_id: Snowflake, event_id: Snowflake, *, with_user_count: bool = False
    ):
        """Get a specific scheduled event"""
        route = Route("GET", f"/guilds/{guild_id}/scheduled-events/{event_id}")
        params = {}
        if with_user_count:
            params["with_user_count"] = "true"
        return await self.request(route, params=params)

    async def create_scheduled_event(
        self,
        guild_id: Snowflake,
        *,
        name: str = None,
        entity_type: int = None,
        scheduled_start_time: str = None,
        json: dict = None,
        reason: Optional[str] = None,
        **kwargs,
    ):
        """Create a scheduled event"""
        route = Route("POST", f"/guilds/{guild_id}/scheduled-events")

        if json is None:
            json = {}
            if name:
                json["name"] = name
            if entity_type is not None:
                json["entity_type"] = entity_type
            if scheduled_start_time:
                json["scheduled_start_time"] = scheduled_start_time
            json.update(kwargs)

        return await self.request(route, json=json, reason=reason)

    async def modify_scheduled_event(
        self, guild_id: Snowflake, event_id: Snowflake, *, json: dict, reason: Optional[str] = None
    ):
        """Modify a scheduled event"""
        route = Route("PATCH", f"/guilds/{guild_id}/scheduled-events/{event_id}")
        return await self.request(route, json=json, reason=reason)

    async def delete_scheduled_event(
        self, guild_id: Snowflake, event_id: Snowflake, *, reason: Optional[str] = None
    ):
        """Delete a scheduled event"""
        route = Route("DELETE", f"/guilds/{guild_id}/scheduled-events/{event_id}")
        return await self.request(route, reason=reason)

    async def get_scheduled_event_users(
        self,
        guild_id: Snowflake,
        event_id: Snowflake,
        *,
        limit: int = 100,
        with_member: bool = False,
        before: Optional[Snowflake] = None,
        after: Optional[Snowflake] = None,
    ):
        """Get users interested in a scheduled event"""
        route = Route("GET", f"/guilds/{guild_id}/scheduled-events/{event_id}/users")
        params = {"limit": limit}

        if with_member:
            params["with_member"] = "true"
        if before:
            params["before"] = before
        if after:
            params["after"] = after

        return await self.request(route, params=params)

    # Stage Instance methods
    async def get_stage_instance(self, channel_id: Snowflake):
        """Get stage instance for a stage channel"""
        route = Route("GET", f"/stage-instances/{channel_id}")
        return await self.request(route)

    async def create_stage_instance(
        self, channel_id: Snowflake, *, json: dict, reason: Optional[str] = None
    ):
        """Create a stage instance"""
        route = Route("POST", "/stage-instances")
        return await self.request(route, json=json, reason=reason)

    async def modify_stage_instance(
        self, channel_id: Snowflake, *, json: dict, reason: Optional[str] = None
    ):
        """Modify a stage instance"""
        route = Route("PATCH", f"/stage-instances/{channel_id}")
        return await self.request(route, json=json, reason=reason)

    async def delete_stage_instance(self, channel_id: Snowflake, *, reason: Optional[str] = None):
        """Delete a stage instance"""
        route = Route("DELETE", f"/stage-instances/{channel_id}")
        return await self.request(route, reason=reason)

    # Guild Template methods
    async def get_template(self, code: str):
        """Get a guild template"""
        route = Route("GET", f"/guilds/templates/{code}")
        return await self.request(route)

    async def get_guild_templates(self, guild_id: Snowflake):
        """Get all templates for a guild"""
        route = Route("GET", f"/guilds/{guild_id}/templates")
        return await self.request(route)

    async def create_guild_template(self, guild_id: Snowflake, *, json: dict):
        """Create a guild template"""
        route = Route("POST", f"/guilds/{guild_id}/templates")
        return await self.request(route, json=json)

    async def sync_guild_template(self, guild_id: Snowflake, code: str):
        """Sync a guild template"""
        route = Route("PUT", f"/guilds/{guild_id}/templates/{code}")
        return await self.request(route)

    async def modify_guild_template(self, guild_id: Snowflake, code: str, *, json: dict):
        """Modify a guild template"""
        route = Route("PATCH", f"/guilds/{guild_id}/templates/{code}")
        return await self.request(route, json=json)

    async def delete_guild_template(self, guild_id: Snowflake, code: str):
        """Delete a guild template"""
        route = Route("DELETE", f"/guilds/{guild_id}/templates/{code}")
        return await self.request(route)

    async def create_guild_from_template(self, code: str, *, json: dict):
        """Create a guild from a template"""
        route = Route("POST", f"/guilds/templates/{code}")
        return await self.request(route, json=json)

    # ==================== LOBBY ENDPOINTS ====================

    async def create_lobby(self, *, json: dict):
        """Create a new lobby"""
        route = Route("POST", "/lobbies")
        return await self.request(route, json=json)

    async def get_lobby(self, lobby_id: Snowflake):
        """Get a lobby by ID"""
        route = Route("GET", f"/lobbies/{lobby_id}")
        return await self.request(route)

    async def modify_lobby(
        self,
        lobby_id: Snowflake,
        *,
        metadata: Optional[Dict[str, str]] = None,
        members: Optional[List[Dict[str, Any]]] = None,
        idle_timeout_seconds: Optional[int] = None,
    ):
        """Modify a lobby"""
        json = {}
        if metadata is not None:
            json["metadata"] = metadata
        if members is not None:
            json["members"] = members
        if idle_timeout_seconds is not None:
            json["idle_timeout_seconds"] = idle_timeout_seconds

        route = Route("PATCH", f"/lobbies/{lobby_id}")
        return await self.request(route, json=json)

    async def delete_lobby(self, lobby_id: Snowflake):
        """Delete a lobby"""
        route = Route("DELETE", f"/lobbies/{lobby_id}")
        return await self.request(route)

    async def add_lobby_member(
        self,
        lobby_id: Snowflake,
        user_id: Snowflake,
        metadata: Optional[Dict[str, str]] = None,
        flags: int = 0,
    ):
        """Add a member to a lobby"""
        json = {}
        if metadata is not None:
            json["metadata"] = metadata
        if flags:
            json["flags"] = flags

        route = Route("PUT", f"/lobbies/{lobby_id}/members/{user_id}")
        return await self.request(route, json=json)

    async def remove_lobby_member(self, lobby_id: Snowflake, user_id: Snowflake):
        """Remove a member from a lobby"""
        route = Route("DELETE", f"/lobbies/{lobby_id}/members/{user_id}")
        return await self.request(route)

    async def leave_lobby(self, lobby_id: Snowflake):
        """Leave a lobby (requires Bearer token)"""
        route = Route("DELETE", f"/lobbies/{lobby_id}/members/@me")
        return await self.request(route)

    async def link_lobby_channel(self, lobby_id: Snowflake, channel_id: Optional[Snowflake] = None):
        """Link or unlink a channel to/from a lobby"""
        json = {}
        if channel_id is not None:
            json["channel_id"] = str(channel_id)

        route = Route("PATCH", f"/lobbies/{lobby_id}/channel-linking")
        return await self.request(route, json=json)

    # ==================== MONETIZATION ENDPOINTS ====================

    async def list_entitlements(
        self,
        application_id: Snowflake,
        *,
        user_id: Optional[Snowflake] = None,
        sku_ids: Optional[List[Snowflake]] = None,
        before: Optional[Snowflake] = None,
        after: Optional[Snowflake] = None,
        limit: int = 100,
        guild_id: Optional[Snowflake] = None,
        exclude_ended: bool = False,
        exclude_deleted: bool = True,
    ):
        """List entitlements for an application"""
        params = {"limit": limit}
        if user_id:
            params["user_id"] = str(user_id)
        if sku_ids:
            params["sku_ids"] = ",".join(str(s) for s in sku_ids)
        if before:
            params["before"] = str(before)
        if after:
            params["after"] = str(after)
        if guild_id:
            params["guild_id"] = str(guild_id)
        if exclude_ended:
            params["exclude_ended"] = "true"
        if not exclude_deleted:
            params["exclude_deleted"] = "false"

        route = Route("GET", f"/applications/{application_id}/entitlements")
        return await self.request(route, params=params)

    async def get_entitlement(self, application_id: Snowflake, entitlement_id: Snowflake):
        """Get an entitlement"""
        route = Route("GET", f"/applications/{application_id}/entitlements/{entitlement_id}")
        return await self.request(route)

    async def create_test_entitlement(
        self, application_id: Snowflake, *, sku_id: Snowflake, owner_id: Snowflake, owner_type: int
    ):
        """Create a test entitlement"""
        json = {"sku_id": str(sku_id), "owner_id": str(owner_id), "owner_type": owner_type}
        route = Route("POST", f"/applications/{application_id}/entitlements")
        return await self.request(route, json=json)

    async def delete_entitlement(self, application_id: Snowflake, entitlement_id: Snowflake):
        """Delete a test entitlement"""
        route = Route("DELETE", f"/applications/{application_id}/entitlements/{entitlement_id}")
        return await self.request(route)

    async def consume_entitlement(self, application_id: Snowflake, entitlement_id: Snowflake):
        """Consume an entitlement"""
        route = Route(
            "POST", f"/applications/{application_id}/entitlements/{entitlement_id}/consume"
        )
        return await self.request(route)

    async def list_skus(self, application_id: Snowflake):
        """List SKUs for an application"""
        route = Route("GET", f"/applications/{application_id}/skus")
        return await self.request(route)

    async def list_sku_subscriptions(
        self,
        sku_id: Snowflake,
        *,
        user_id: Optional[Snowflake] = None,
        before: Optional[Snowflake] = None,
        after: Optional[Snowflake] = None,
        limit: int = 50,
    ):
        """List subscriptions for a SKU"""
        params = {"limit": limit}
        if user_id:
            params["user_id"] = str(user_id)
        if before:
            params["before"] = str(before)
        if after:
            params["after"] = str(after)

        route = Route("GET", f"/skus/{sku_id}/subscriptions")
        return await self.request(route, params=params)

    async def get_sku_subscription(self, sku_id: Snowflake, subscription_id: Snowflake):
        """Get a subscription by ID"""
        route = Route("GET", f"/skus/{sku_id}/subscriptions/{subscription_id}")
        return await self.request(route)

    # ==================== APPLICATION ROLE CONNECTIONS ====================

    async def get_application_role_connection_metadata(self, application_id: Snowflake):
        """Get application role connection metadata records"""
        route = Route("GET", f"/applications/{application_id}/role-connections/metadata")
        return await self.request(route)

    async def update_application_role_connection_metadata(
        self, application_id: Snowflake, *, metadata: List[Dict[str, Any]]
    ):
        """Update application role connection metadata records"""
        route = Route("PUT", f"/applications/{application_id}/role-connections/metadata")
        return await self.request(route, json=metadata)

    async def get_user_application_role_connection(self, application_id: Snowflake):
        """Get the current user's role connection for an application"""
        route = Route("GET", f"/users/@me/applications/{application_id}/role-connection")
        return await self.request(route)

    async def update_user_application_role_connection(
        self,
        application_id: Snowflake,
        *,
        platform_name: Optional[str] = None,
        platform_username: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        """Update the current user's role connection for an application"""
        json = {}
        if platform_name is not None:
            json["platform_name"] = platform_name
        if platform_username is not None:
            json["platform_username"] = platform_username
        if metadata is not None:
            json["metadata"] = metadata

        route = Route("PUT", f"/users/@me/applications/{application_id}/role-connection")
        return await self.request(route, json=json)

    # ==================== APPLICATION EMOJIS ====================

    async def list_application_emojis(self, application_id: Snowflake):
        """List application emojis"""
        route = Route("GET", f"/applications/{application_id}/emojis")
        return await self.request(route)

    async def get_application_emoji(self, application_id: Snowflake, emoji_id: Snowflake):
        """Get an application emoji"""
        route = Route("GET", f"/applications/{application_id}/emojis/{emoji_id}")
        return await self.request(route)

    async def create_application_emoji(self, application_id: Snowflake, *, json: dict):
        """Create an application emoji"""
        route = Route("POST", f"/applications/{application_id}/emojis")
        return await self.request(route, json=json)

    async def modify_application_emoji(
        self, application_id: Snowflake, emoji_id: Snowflake, *, json: dict
    ):
        """Modify an application emoji"""
        route = Route("PATCH", f"/applications/{application_id}/emojis/{emoji_id}")
        return await self.request(route, json=json)

    async def delete_application_emoji(self, application_id: Snowflake, emoji_id: Snowflake):
        """Delete an application emoji"""
        route = Route("DELETE", f"/applications/{application_id}/emojis/{emoji_id}")
        return await self.request(route)

    # ==================== GUILD ONBOARDING ====================

    async def get_guild_onboarding(self, guild_id: Snowflake):
        """Get guild onboarding"""
        route = Route("GET", f"/guilds/{guild_id}/onboarding")
        return await self.request(route)

    async def modify_guild_onboarding(
        self, guild_id: Snowflake, *, json: dict, reason: Optional[str] = None
    ):
        """Modify guild onboarding"""
        route = Route("PUT", f"/guilds/{guild_id}/onboarding")
        return await self.request(route, json=json, reason=reason)

    # ==================== VOICE STATE ====================

    async def get_user_voice_state(self, guild_id: Snowflake, user_id: Snowflake):
        """Get a user's voice state"""
        route = Route("GET", f"/guilds/{guild_id}/voice-states/{user_id}")
        return await self.request(route)

    async def get_current_user_voice_state(self, guild_id: Snowflake):
        """Get current user's voice state"""
        route = Route("GET", f"/guilds/{guild_id}/voice-states/@me")
        return await self.request(route)

    async def modify_user_voice_state(self, guild_id: Snowflake, user_id: Snowflake, *, json: dict):
        """Modify a user's voice state"""
        route = Route("PATCH", f"/guilds/{guild_id}/voice-states/{user_id}")
        return await self.request(route, json=json)

    async def modify_current_user_voice_state(self, guild_id: Snowflake, *, json: dict):
        """Modify current user's voice state"""
        route = Route("PATCH", f"/guilds/{guild_id}/voice-states/@me")
        return await self.request(route, json=json)

    async def update_voice_channel_status(self, channel_id: Snowflake, *, status: str):
        """
        Update voice channel status (NEW in API v10)

        Args:
            channel_id: Voice channel ID
            status: Status text (max 500 characters)
        """
        route = Route("PUT", f"/channels/{channel_id}/voice-status")
        return await self.request(route, json={"status": status})

    async def delete_voice_channel_status(self, channel_id: Snowflake):
        """
        Delete voice channel status (NEW in API v10)

        Args:
            channel_id: Voice channel ID
        """
        route = Route("DELETE", f"/channels/{channel_id}/voice-status")
        return await self.request(route)

    # ==================== STICKER PACKS ====================

    async def list_sticker_packs(self):
        """List available sticker packs"""
        route = Route("GET", "/sticker-packs")
        return await self.request(route)

    async def get_sticker_pack(self, pack_id: Snowflake):
        """Get a sticker pack"""
        route = Route("GET", f"/sticker-packs/{pack_id}")
        return await self.request(route)

    # ==================== USER CONNECTIONS ====================

    async def get_user_connections(self):
        """Get current user's connections"""
        route = Route("GET", "/users/@me/connections")
        return await self.request(route)

    # ==================== THREAD ARCHIVES ====================

    async def list_private_archived_threads(
        self, channel_id: Snowflake, *, before: Optional[str] = None, limit: int = 50
    ):
        """List private archived threads"""
        params = {"limit": limit}
        if before:
            params["before"] = before

        route = Route("GET", f"/channels/{channel_id}/threads/archived/private")
        return await self.request(route, params=params)

    async def list_public_archived_threads(
        self, channel_id: Snowflake, *, before: Optional[str] = None, limit: int = 50
    ):
        """List public archived threads"""
        params = {"limit": limit}
        if before:
            params["before"] = before

        route = Route("GET", f"/channels/{channel_id}/threads/archived/public")
        return await self.request(route, params=params)

    async def list_joined_private_archived_threads(
        self, channel_id: Snowflake, *, before: Optional[str] = None, limit: int = 50
    ):
        """List joined private archived threads"""
        params = {"limit": limit}
        if before:
            params["before"] = before

        route = Route("GET", f"/channels/{channel_id}/users/@me/threads/archived/private")
        return await self.request(route, params=params)

    # ==================== GUILD INCIDENT ACTIONS ====================

    async def modify_guild_incident_actions(self, guild_id: Snowflake, *, json: dict):
        """Modify guild incident actions (raid protection)"""
        route = Route("PUT", f"/guilds/{guild_id}/incident-actions")
        return await self.request(route, json=json)

    # ==================== APPLICATION ACTIVITY INSTANCES ====================

    async def get_application_activity_instance(self, application_id: Snowflake, instance_id: str):
        """Get an application activity instance"""
        route = Route("GET", f"/applications/{application_id}/activity-instances/{instance_id}")
        return await self.request(route)

    # ==================== GUILD WIDGET ====================

    async def get_guild_widget_settings(self, guild_id: Snowflake):
        """Get guild widget settings"""
        route = Route("GET", f"/guilds/{guild_id}/widget")
        return await self.request(route)

    async def modify_guild_widget(
        self, guild_id: Snowflake, *, json: dict, reason: Optional[str] = None
    ):
        """Modify guild widget"""
        route = Route("PATCH", f"/guilds/{guild_id}/widget")
        return await self.request(route, json=json, reason=reason)

    async def get_guild_widget(self, guild_id: Snowflake):
        """Get guild widget JSON"""
        route = Route("GET", f"/guilds/{guild_id}/widget.json")
        return await self.request(route)

    async def get_guild_widget_image(self, guild_id: Snowflake, *, style: str = "shield"):
        """Get guild widget image"""
        route = Route("GET", f"/guilds/{guild_id}/widget.png")
        params = {"style": style}
        return await self.request(route, params=params)

    # ==================== CHANNEL FOLLOWERS ====================

    async def follow_news_channel(self, channel_id: Snowflake, *, webhook_channel_id: Snowflake):
        """Follow a news channel"""
        json = {"webhook_channel_id": str(webhook_channel_id)}
        route = Route("POST", f"/channels/{channel_id}/followers")
        return await self.request(route, json=json)

    # ==================== DM GROUP RECIPIENTS ====================

    async def add_group_dm_recipient(
        self,
        channel_id: Snowflake,
        user_id: Snowflake,
        *,
        access_token: str,
        nick: Optional[str] = None,
    ):
        """Add a recipient to a group DM"""
        json = {"access_token": access_token}
        if nick:
            json["nick"] = nick

        route = Route("PUT", f"/channels/{channel_id}/recipients/{user_id}")
        return await self.request(route, json=json)

    async def remove_group_dm_recipient(self, channel_id: Snowflake, user_id: Snowflake):
        """Remove a recipient from a group DM"""
        route = Route("DELETE", f"/channels/{channel_id}/recipients/{user_id}")
        return await self.request(route)

    # ==================== MESSAGE OPERATIONS ====================

    async def crosspost_message(self, channel_id: Snowflake, message_id: Snowflake):
        """Crosspost a message in a news channel"""
        route = Route("POST", f"/channels/{channel_id}/messages/{message_id}/crosspost")
        return await self.request(route)

    async def bulk_delete_messages(
        self, channel_id: Snowflake, *, message_ids: List[Snowflake], reason: Optional[str] = None
    ):
        """Bulk delete messages (2-100 messages, not older than 2 weeks)"""
        json = {"messages": [str(mid) for mid in message_ids]}
        route = Route("POST", f"/channels/{channel_id}/messages/bulk-delete")
        return await self.request(route, json=json, reason=reason)

    # ==================== GUILD OPERATIONS ====================

    async def get_guild_preview(self, guild_id: Snowflake):
        """Get guild preview"""
        route = Route("GET", f"/guilds/{guild_id}/preview")
        return await self.request(route)

    async def get_guild_prune_count(
        self, guild_id: Snowflake, *, days: int = 7, include_roles: Optional[List[Snowflake]] = None
    ):
        """Get count of members that would be pruned"""
        params = {"days": days}
        if include_roles:
            params["include_roles"] = ",".join(str(r) for r in include_roles)

        route = Route("GET", f"/guilds/{guild_id}/prune")
        return await self.request(route, params=params)

    async def begin_guild_prune(
        self,
        guild_id: Snowflake,
        *,
        days: int = 7,
        compute_prune_count: bool = True,
        include_roles: Optional[List[Snowflake]] = None,
        reason: Optional[str] = None,
    ):
        """Begin guild prune operation"""
        json = {"days": days, "compute_prune_count": compute_prune_count}
        if include_roles:
            json["include_roles"] = [str(r) for r in include_roles]

        route = Route("POST", f"/guilds/{guild_id}/prune")
        return await self.request(route, json=json, reason=reason)

    async def get_guild_vanity_url(self, guild_id: Snowflake):
        """Get guild vanity URL"""
        route = Route("GET", f"/guilds/{guild_id}/vanity-url")
        return await self.request(route)

    async def get_guild_welcome_screen(self, guild_id: Snowflake):
        """Get guild welcome screen"""
        route = Route("GET", f"/guilds/{guild_id}/welcome-screen")
        return await self.request(route)

    async def modify_guild_welcome_screen(
        self, guild_id: Snowflake, *, json: dict, reason: Optional[str] = None
    ):
        """Modify guild welcome screen"""
        route = Route("PATCH", f"/guilds/{guild_id}/welcome-screen")
        return await self.request(route, json=json, reason=reason)

    async def update_guild_incident_actions(
        self,
        guild_id: Snowflake,
        *,
        invites_disabled_until: Optional[str] = None,
        dms_disabled_until: Optional[str] = None,
    ):
        """
        Update guild incident actions (raid protection) (NEW in API v10)

        Args:
            guild_id: Guild ID
            invites_disabled_until: ISO8601 timestamp when invites will be re-enabled
            dms_disabled_until: ISO8601 timestamp when DMs will be re-enabled
        """
        json = {}
        if invites_disabled_until is not None:
            json["invites_disabled_until"] = invites_disabled_until
        if dms_disabled_until is not None:
            json["dms_disabled_until"] = dms_disabled_until

        route = Route("PUT", f"/guilds/{guild_id}/incident-actions")
        return await self.request(route, json=json)

    async def get_guild_voice_regions(self, guild_id: Snowflake):
        """Get guild voice regions (deprecated)"""
        route = Route("GET", f"/guilds/{guild_id}/regions")
        return await self.request(route)

    async def get_guild_integrations(self, guild_id: Snowflake):
        """Get guild integrations"""
        route = Route("GET", f"/guilds/{guild_id}/integrations")
        return await self.request(route)

    async def delete_guild_integration(
        self, guild_id: Snowflake, integration_id: Snowflake, *, reason: Optional[str] = None
    ):
        """Delete guild integration"""
        route = Route("DELETE", f"/guilds/{guild_id}/integrations/{integration_id}")
        return await self.request(route, reason=reason)

    async def list_active_guild_threads(self, guild_id: Snowflake):
        """List all active threads in guild"""
        route = Route("GET", f"/guilds/{guild_id}/threads/active")
        return await self.request(route)

    # ==================== VOICE REGIONS ====================

    async def list_voice_regions(self):
        """List available voice regions"""
        route = Route("GET", "/voice/regions")
        return await self.request(route)

    # ==================== POLL ENDPOINTS ====================

    async def get_poll_answer_voters(
        self,
        channel_id: Snowflake,
        message_id: Snowflake,
        answer_id: int,
        *,
        after: Optional[Snowflake] = None,
        limit: int = 25,
    ):
        """Get users who voted for a specific poll answer"""
        params = {"limit": min(limit, 100)}
        if after:
            params["after"] = str(after)

        route = Route("GET", f"/channels/{channel_id}/polls/{message_id}/answers/{answer_id}")
        return await self.request(route, params=params)

    async def end_poll(self, channel_id: Snowflake, message_id: Snowflake):
        """Immediately end a poll"""
        route = Route("POST", f"/channels/{channel_id}/polls/{message_id}/expire")
        return await self.request(route)

    # ==================== SOUNDBOARD ENDPOINTS ====================

    async def send_soundboard_sound(
        self,
        channel_id: Snowflake,
        *,
        sound_id: Snowflake,
        source_guild_id: Optional[Snowflake] = None,
    ):
        """Send a soundboard sound to a voice channel"""
        json = {"sound_id": str(sound_id)}
        if source_guild_id:
            json["source_guild_id"] = str(source_guild_id)

        route = Route("POST", f"/channels/{channel_id}/send-soundboard-sound")
        return await self.request(route, json=json)

    async def list_default_soundboard_sounds(self):
        """List default soundboard sounds available to all users"""
        route = Route("GET", "/soundboard-default-sounds")
        return await self.request(route)

    async def list_guild_soundboard_sounds(self, guild_id: Snowflake):
        """List guild soundboard sounds"""
        route = Route("GET", f"/guilds/{guild_id}/soundboard-sounds")
        return await self.request(route)

    async def get_guild_soundboard_sound(self, guild_id: Snowflake, sound_id: Snowflake):
        """Get a specific guild soundboard sound"""
        route = Route("GET", f"/guilds/{guild_id}/soundboard-sounds/{sound_id}")
        return await self.request(route)

    async def create_guild_soundboard_sound(
        self,
        guild_id: Snowflake,
        *,
        name: str,
        sound: str,
        volume: Optional[float] = None,
        emoji_id: Optional[Snowflake] = None,
        emoji_name: Optional[str] = None,
        reason: Optional[str] = None,
    ):
        """Create a guild soundboard sound"""
        json = {"name": name, "sound": sound}
        if volume is not None:
            json["volume"] = volume
        if emoji_id is not None:
            json["emoji_id"] = str(emoji_id)
        if emoji_name is not None:
            json["emoji_name"] = emoji_name

        route = Route("POST", f"/guilds/{guild_id}/soundboard-sounds")
        return await self.request(route, json=json, reason=reason)

    async def modify_guild_soundboard_sound(
        self,
        guild_id: Snowflake,
        sound_id: Snowflake,
        *,
        name: Optional[str] = None,
        volume: Optional[float] = None,
        emoji_id: Optional[Snowflake] = None,
        emoji_name: Optional[str] = None,
        reason: Optional[str] = None,
    ):
        """Modify a guild soundboard sound"""
        json = {}
        if name is not None:
            json["name"] = name
        if volume is not None:
            json["volume"] = volume
        if emoji_id is not None:
            json["emoji_id"] = str(emoji_id)
        if emoji_name is not None:
            json["emoji_name"] = emoji_name

        route = Route("PATCH", f"/guilds/{guild_id}/soundboard-sounds/{sound_id}")
        return await self.request(route, json=json, reason=reason)

    async def delete_guild_soundboard_sound(
        self, guild_id: Snowflake, sound_id: Snowflake, *, reason: Optional[str] = None
    ):
        """Delete a guild soundboard sound"""
        route = Route("DELETE", f"/guilds/{guild_id}/soundboard-sounds/{sound_id}")
        return await self.request(route, reason=reason)

    # ==================== GUILD WELCOME SCREEN ====================

    async def get_guild_welcome_screen(self, guild_id: Snowflake):
        """Get the guild's welcome screen"""
        route = Route("GET", f"/guilds/{guild_id}/welcome-screen")
        return await self.request(route)

    async def modify_guild_welcome_screen(
        self, guild_id: Snowflake, *, json: dict, reason: Optional[str] = None
    ):
        """Modify the guild's welcome screen"""
        route = Route("PATCH", f"/guilds/{guild_id}/welcome-screen")
        return await self.request(route, json=json, reason=reason)

    # ==================== GUILD ONBOARDING ====================

    async def get_guild_onboarding(self, guild_id: Snowflake):
        """Get the guild's onboarding configuration"""
        route = Route("GET", f"/guilds/{guild_id}/onboarding")
        return await self.request(route)

    async def modify_guild_onboarding(
        self, guild_id: Snowflake, *, json: dict, reason: Optional[str] = None
    ):
        """Modify the guild's onboarding configuration"""
        route = Route("PUT", f"/guilds/{guild_id}/onboarding")
        return await self.request(route, json=json, reason=reason)

    # ==================== GUILD VANITY URL ====================

    async def get_guild_vanity_url(self, guild_id: Snowflake):
        """Get the guild's vanity URL"""
        route = Route("GET", f"/guilds/{guild_id}/vanity-url")
        return await self.request(route)

    # ==================== VOICE REGIONS ====================

    async def list_voice_regions(self):
        """List available voice regions"""
        route = Route("GET", "/voice/regions")
        return await self.request(route)

    async def list_guild_voice_regions(self, guild_id: Snowflake):
        """List available voice regions for a guild"""
        route = Route("GET", f"/guilds/{guild_id}/regions")
        return await self.request(route)

    # ==================== MISSING MESSAGE METHODS ====================

    async def create_message(
        self,
        channel_id: Snowflake,
        *,
        content: str = None,
        embeds=None,
        embed=None,
        poll=None,
        components=None,
        files=None,
        json: dict = None,
        reason: Optional[str] = None,
        **kwargs,
    ):
        """Create a message in a channel"""
        route = Route("POST", f"/channels/{channel_id}/messages")

        # Build JSON payload if not provided
        if json is None:
            json = {}
            if content:
                json["content"] = content
            if embed:
                json["embeds"] = [embed] if isinstance(embed, dict) else [embed.to_dict()]
            if embeds:
                json["embeds"] = [e if isinstance(e, dict) else e.to_dict() for e in embeds]
            if poll:
                json["poll"] = poll if isinstance(poll, dict) else poll.to_dict()
            if components:
                json["components"] = components
            # Add any other kwargs to json
            json.update(kwargs)

        return await self.request(route, json=json, files=files, reason=reason)

    async def get_channel_messages(
        self,
        channel_id: Snowflake,
        *,
        limit: int = None,
        before: Snowflake = None,
        after: Snowflake = None,
        around: Snowflake = None,
        params: dict = None,
    ):
        """Get messages from a channel"""
        route = Route("GET", f"/channels/{channel_id}/messages")

        if params is None:
            params = {}
            if limit is not None:
                params["limit"] = limit
            if before is not None:
                params["before"] = before
            if after is not None:
                params["after"] = after
            if around is not None:
                params["around"] = around

        return await self.request(route, params=params)

    async def get_message(self, channel_id: Snowflake, message_id: Snowflake):
        """Get a specific message"""
        route = Route("GET", f"/channels/{channel_id}/messages/{message_id}")
        return await self.request(route)

    async def edit_message(
        self,
        channel_id: Snowflake,
        message_id: Snowflake,
        *,
        content: str = None,
        embeds=None,
        components=None,
        json: dict = None,
        reason: Optional[str] = None,
        **kwargs,
    ):
        """Edit a message"""
        route = Route("PATCH", f"/channels/{channel_id}/messages/{message_id}")

        if json is None:
            json = {}
            if content is not None:
                json["content"] = content
            if embeds is not None:
                json["embeds"] = [e if isinstance(e, dict) else e.to_dict() for e in embeds]
            if components is not None:
                json["components"] = components
            json.update(kwargs)

        return await self.request(route, json=json, reason=reason)

    async def delete_message(
        self, channel_id: Snowflake, message_id: Snowflake, *, reason: Optional[str] = None
    ):
        """Delete a message"""
        route = Route("DELETE", f"/channels/{channel_id}/messages/{message_id}")
        return await self.request(route, reason=reason)

    # ==================== MISSING CHANNEL METHODS ====================

    async def get_channel(self, channel_id: Snowflake):
        """Get a channel by ID"""
        route = Route("GET", f"/channels/{channel_id}")
        return await self.request(route)

    async def modify_channel(
        self,
        channel_id: Snowflake,
        *,
        name: str = None,
        json: dict = None,
        reason: Optional[str] = None,
        **kwargs,
    ):
        """Modify a channel"""
        route = Route("PATCH", f"/channels/{channel_id}")

        if json is None:
            json = {}
            if name:
                json["name"] = name
            json.update(kwargs)

        return await self.request(route, json=json, reason=reason)

    async def delete_channel(self, channel_id: Snowflake, *, reason: Optional[str] = None):
        """Delete a channel"""
        route = Route("DELETE", f"/channels/{channel_id}")
        return await self.request(route, reason=reason)

    # ==================== MISSING GUILD METHODS ====================

    async def get_guild(self, guild_id: Snowflake, *, params: dict = None):
        """Get a guild by ID"""
        route = Route("GET", f"/guilds/{guild_id}")
        return await self.request(route, params=params)

    async def get_guild_channels(self, guild_id: Snowflake):
        """Get channels in a guild"""
        route = Route("GET", f"/guilds/{guild_id}/channels")
        return await self.request(route)

    async def list_guild_members(
        self,
        guild_id: Snowflake,
        *,
        limit: int = None,
        after: Snowflake = None,
        params: dict = None,
    ):
        """List members in a guild"""
        route = Route("GET", f"/guilds/{guild_id}/members")

        if params is None:
            params = {}
            if limit is not None:
                params["limit"] = limit
            if after is not None:
                params["after"] = after

        return await self.request(route, params=params)

    async def get_guild_roles(self, guild_id: Snowflake):
        """Get roles in a guild"""
        route = Route("GET", f"/guilds/{guild_id}/roles")
        return await self.request(route)

    async def create_guild_role(
        self,
        guild_id: Snowflake,
        *,
        name: str = None,
        json: dict = None,
        reason: Optional[str] = None,
        **kwargs,
    ):
        """Create a role in a guild"""
        route = Route("POST", f"/guilds/{guild_id}/roles")

        if json is None:
            json = {}
            if name:
                json["name"] = name
            json.update(kwargs)

        return await self.request(route, json=json, reason=reason)

    async def delete_guild_role(
        self, guild_id: Snowflake, role_id: Snowflake, *, reason: Optional[str] = None
    ):
        """Delete a role from a guild"""
        route = Route("DELETE", f"/guilds/{guild_id}/roles/{role_id}")
        return await self.request(route, reason=reason)

    # ==================== MISSING EMOJI METHODS ====================

    async def list_guild_emojis(self, guild_id: Snowflake):
        """List emojis in a guild"""
        route = Route("GET", f"/guilds/{guild_id}/emojis")
        return await self.request(route)

    # ==================== MISSING WEBHOOK METHODS ====================

    async def create_webhook(
        self,
        channel_id: Snowflake,
        *,
        name: str = None,
        json: dict = None,
        reason: Optional[str] = None,
        **kwargs,
    ):
        """Create a webhook"""
        route = Route("POST", f"/channels/{channel_id}/webhooks")

        if json is None:
            json = {}
            if name:
                json["name"] = name
            json.update(kwargs)

        return await self.request(route, json=json, reason=reason)

    async def get_webhook(self, webhook_id: Snowflake):
        """Get a webhook"""
        route = Route("GET", f"/webhooks/{webhook_id}")
        return await self.request(route)

    async def delete_webhook(self, webhook_id: Snowflake, *, reason: Optional[str] = None):
        """Delete a webhook"""
        route = Route("DELETE", f"/webhooks/{webhook_id}")
        return await self.request(route, reason=reason)

    async def execute_webhook(
        self,
        webhook_id: Snowflake,
        webhook_token: str,
        *,
        content: str = None,
        embeds=None,
        json: dict = None,
        params: dict = None,
        files=None,
        **kwargs,
    ):
        """Execute a webhook"""
        route = Route("POST", f"/webhooks/{webhook_id}/{webhook_token}")

        if json is None:
            json = {}
            if content:
                json["content"] = content
            if embeds:
                json["embeds"] = [e if isinstance(e, dict) else e.to_dict() for e in embeds]
            json.update(kwargs)

        return await self.request(route, json=json, params=params, files=files)

    # ==================== MISSING THREAD METHODS ====================

    async def start_thread_with_message(
        self,
        channel_id: Snowflake,
        message_id: Snowflake,
        *,
        json: dict = None,
        reason: Optional[str] = None,
    ):
        """Start a thread from a message"""
        route = Route("POST", f"/channels/{channel_id}/messages/{message_id}/threads")
        return await self.request(route, json=json or {}, reason=reason)

    async def start_thread_from_message(
        self,
        channel_id: Snowflake,
        message_id: Snowflake,
        *,
        name: str = None,
        auto_archive_duration: int = None,
        json: dict = None,
        reason: Optional[str] = None,
        **kwargs,
    ):
        """Start a thread from a message (alias)"""
        route = Route("POST", f"/channels/{channel_id}/messages/{message_id}/threads")

        if json is None:
            json = {}
            if name:
                json["name"] = name
            if auto_archive_duration:
                json["auto_archive_duration"] = auto_archive_duration
            json.update(kwargs)

        return await self.request(route, json=json, reason=reason)

    async def start_thread_without_message(
        self,
        channel_id: Snowflake,
        *,
        name: str = None,
        json: dict = None,
        reason: Optional[str] = None,
        **kwargs,
    ):
        """Start a thread without a message"""
        route = Route("POST", f"/channels/{channel_id}/threads")

        if json is None:
            json = {}
            if name:
                json["name"] = name
            json.update(kwargs)

        return await self.request(route, json=json, reason=reason)

    async def join_thread(self, channel_id: Snowflake):
        """Join a thread"""
        route = Route("PUT", f"/channels/{channel_id}/thread-members/@me")
        return await self.request(route)

    async def leave_thread(self, channel_id: Snowflake):
        """Leave a thread"""
        route = Route("DELETE", f"/channels/{channel_id}/thread-members/@me")
        return await self.request(route)

    async def add_thread_member(self, channel_id: Snowflake, user_id: Snowflake):
        """Add a member to a thread"""
        route = Route("PUT", f"/channels/{channel_id}/thread-members/{user_id}")
        return await self.request(route)

    async def remove_thread_member(self, channel_id: Snowflake, user_id: Snowflake):
        """Remove a member from a thread"""
        route = Route("DELETE", f"/channels/{channel_id}/thread-members/{user_id}")
        return await self.request(route)

    async def get_thread_member(
        self, channel_id: Snowflake, user_id: Snowflake, *, with_member: bool = False
    ):
        """Get a thread member"""
        params = {}
        if with_member:
            params["with_member"] = "true"
        route = Route("GET", f"/channels/{channel_id}/thread-members/{user_id}")
        return await self.request(route, params=params if params else None)

    async def list_thread_members(
        self,
        channel_id: Snowflake,
        *,
        with_member: bool = False,
        after: Optional[Snowflake] = None,
        limit: int = 100,
    ):
        """List thread members"""
        params = {}
        if with_member:
            params["with_member"] = "true"
        if after:
            params["after"] = str(after)
        if limit != 100:
            params["limit"] = limit
        route = Route("GET", f"/channels/{channel_id}/thread-members")
        return await self.request(route, params=params if params else None)

    # ==================== MISSING REACTION METHODS ====================

    async def create_reaction(self, channel_id: Snowflake, message_id: Snowflake, emoji: str):
        """Add a reaction to a message"""
        route = Route("PUT", f"/channels/{channel_id}/messages/{message_id}/reactions/{emoji}/@me")
        return await self.request(route)

    async def delete_own_reaction(self, channel_id: Snowflake, message_id: Snowflake, emoji: str):
        """Remove own reaction from a message"""
        route = Route(
            "DELETE", f"/channels/{channel_id}/messages/{message_id}/reactions/{emoji}/@me"
        )
        return await self.request(route)

    async def delete_user_reaction(
        self, channel_id: Snowflake, message_id: Snowflake, emoji: str, user_id: Snowflake
    ):
        """Remove a user's reaction from a message"""
        route = Route(
            "DELETE", f"/channels/{channel_id}/messages/{message_id}/reactions/{emoji}/{user_id}"
        )
        return await self.request(route)

    async def get_reactions(
        self, channel_id: Snowflake, message_id: Snowflake, emoji: str, *, params: dict = None
    ):
        """Get users who reacted with an emoji"""
        route = Route("GET", f"/channels/{channel_id}/messages/{message_id}/reactions/{emoji}")
        return await self.request(route, params=params)

    async def delete_all_reactions(self, channel_id: Snowflake, message_id: Snowflake):
        """Remove all reactions from a message"""
        route = Route("DELETE", f"/channels/{channel_id}/messages/{message_id}/reactions")
        return await self.request(route)

    async def delete_all_reactions_for_emoji(
        self, channel_id: Snowflake, message_id: Snowflake, emoji: str
    ):
        """Remove all reactions for a specific emoji from a message"""
        route = Route("DELETE", f"/channels/{channel_id}/messages/{message_id}/reactions/{emoji}")
        return await self.request(route)

    # ==================== MISSING PIN METHODS ====================

    async def pin_message(
        self, channel_id: Snowflake, message_id: Snowflake, *, reason: Optional[str] = None
    ):
        """Pin a message"""
        route = Route("PUT", f"/channels/{channel_id}/pins/{message_id}")
        return await self.request(route, reason=reason)

    async def unpin_message(
        self, channel_id: Snowflake, message_id: Snowflake, *, reason: Optional[str] = None
    ):
        """Unpin a message"""
        route = Route("DELETE", f"/channels/{channel_id}/pins/{message_id}")
        return await self.request(route, reason=reason)

    # ==================== FIX WEBHOOK EXECUTE ====================

    async def execute_webhook_fixed(
        self,
        webhook_id: Snowflake,
        webhook_token: str,
        *,
        content: str = None,
        embeds=None,
        json: dict = None,
        params: dict = None,
        files=None,
        **kwargs,
    ):
        """Execute a webhook"""
        route = Route("POST", f"/webhooks/{webhook_id}/{webhook_token}")

        if json is None:
            json = {}
            if content:
                json["content"] = content
            if embeds:
                json["embeds"] = [e if isinstance(e, dict) else e.to_dict() for e in embeds]
            json.update(kwargs)

        return await self.request(route, json=json, params=params, files=files)

    # ==================== INTERACTION ENDPOINTS ====================

    async def create_interaction_response(
        self, interaction_id: Snowflake, interaction_token: str, data: dict
    ):
        """Create an interaction response"""
        route = Route("POST", f"/interactions/{interaction_id}/{interaction_token}/callback")
        return await self.request(route, json=data)

    async def get_interaction_response(self, application_id: Snowflake, interaction_token: str):
        """Get the original interaction response"""
        route = Route("GET", f"/webhooks/{application_id}/{interaction_token}/messages/@original")
        return await self.request(route)

    async def edit_interaction_response(
        self, application_id: Snowflake, interaction_token: str, data: dict
    ):
        """Edit the original interaction response"""
        route = Route("PATCH", f"/webhooks/{application_id}/{interaction_token}/messages/@original")
        return await self.request(route, json=data)

    async def delete_interaction_response(self, application_id: Snowflake, interaction_token: str):
        """Delete the original interaction response"""
        route = Route(
            "DELETE", f"/webhooks/{application_id}/{interaction_token}/messages/@original"
        )
        return await self.request(route)

    async def create_followup_message(
        self, application_id: Snowflake, interaction_token: str, data: dict
    ):
        """Create a followup message"""
        route = Route("POST", f"/webhooks/{application_id}/{interaction_token}")
        return await self.request(route, json=data)

    async def get_followup_message(
        self, application_id: Snowflake, interaction_token: str, message_id: Snowflake
    ):
        """Get a followup message"""
        route = Route(
            "GET", f"/webhooks/{application_id}/{interaction_token}/messages/{message_id}"
        )
        return await self.request(route)

    async def edit_followup_message(
        self, application_id: Snowflake, interaction_token: str, message_id: Snowflake, data: dict
    ):
        """Edit a followup message"""
        route = Route(
            "PATCH", f"/webhooks/{application_id}/{interaction_token}/messages/{message_id}"
        )
        return await self.request(route, json=data)

    async def delete_followup_message(
        self, application_id: Snowflake, interaction_token: str, message_id: Snowflake
    ):
        """Delete a followup message"""
        route = Route(
            "DELETE", f"/webhooks/{application_id}/{interaction_token}/messages/{message_id}"
        )
        return await self.request(route)

    # ==================== APPLICATION COMMAND ENDPOINTS ====================

    async def get_global_application_commands(self, application_id: Snowflake):
        """Get all global application commands"""
        route = Route("GET", f"/applications/{application_id}/commands")
        return await self.request(route)

    async def create_global_application_command(self, application_id: Snowflake, data: dict):
        """Create a global application command"""
        route = Route("POST", f"/applications/{application_id}/commands")
        return await self.request(route, json=data)

    async def get_global_application_command(
        self, application_id: Snowflake, command_id: Snowflake
    ):
        """Get a global application command"""
        route = Route("GET", f"/applications/{application_id}/commands/{command_id}")
        return await self.request(route)

    async def edit_global_application_command(
        self, application_id: Snowflake, command_id: Snowflake, data: dict
    ):
        """Edit a global application command"""
        route = Route("PATCH", f"/applications/{application_id}/commands/{command_id}")
        return await self.request(route, json=data)

    async def delete_global_application_command(
        self, application_id: Snowflake, command_id: Snowflake
    ):
        """Delete a global application command"""
        route = Route("DELETE", f"/applications/{application_id}/commands/{command_id}")
        return await self.request(route)

    async def bulk_overwrite_global_application_commands(
        self, application_id: Snowflake, data: list
    ):
        """Bulk overwrite all global application commands"""
        route = Route("PUT", f"/applications/{application_id}/commands")
        return await self.request(route, json=data)

    async def get_guild_application_commands(self, application_id: Snowflake, guild_id: Snowflake):
        """Get all guild application commands"""
        route = Route("GET", f"/applications/{application_id}/guilds/{guild_id}/commands")
        return await self.request(route)

    async def create_guild_application_command(
        self, application_id: Snowflake, guild_id: Snowflake, data: dict
    ):
        """Create a guild application command"""
        route = Route("POST", f"/applications/{application_id}/guilds/{guild_id}/commands")
        return await self.request(route, json=data)

    async def get_guild_application_command(
        self, application_id: Snowflake, guild_id: Snowflake, command_id: Snowflake
    ):
        """Get a guild application command"""
        route = Route(
            "GET", f"/applications/{application_id}/guilds/{guild_id}/commands/{command_id}"
        )
        return await self.request(route)

    async def edit_guild_application_command(
        self, application_id: Snowflake, guild_id: Snowflake, command_id: Snowflake, data: dict
    ):
        """Edit a guild application command"""
        route = Route(
            "PATCH", f"/applications/{application_id}/guilds/{guild_id}/commands/{command_id}"
        )
        return await self.request(route, json=data)

    async def delete_guild_application_command(
        self, application_id: Snowflake, guild_id: Snowflake, command_id: Snowflake
    ):
        """Delete a guild application command"""
        route = Route(
            "DELETE", f"/applications/{application_id}/guilds/{guild_id}/commands/{command_id}"
        )
        return await self.request(route)

    async def bulk_overwrite_guild_application_commands(
        self, application_id: Snowflake, guild_id: Snowflake, data: list
    ):
        """Bulk overwrite all guild application commands"""
        route = Route("PUT", f"/applications/{application_id}/guilds/{guild_id}/commands")
        return await self.request(route, json=data)
