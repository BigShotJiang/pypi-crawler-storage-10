"""
AutoShardedClient for automatically managing multiple shards

Handles automatic shard creation, connection, and load balancing for large bots.
"""

import asyncio
import logging
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional

from ..utils.exceptions import ShardConnectionError
from .client import Client
from .intents import Intents
from .shard import Shard, ShardStatus


class ShardManager:
    """Manages multiple shards for an AutoShardedClient"""

    def __init__(self, client):
        self.client = client
        self.shards: Dict[int, Shard] = {}
        self.logger = logging.getLogger("auric.sharding")

    def add_shard(self, shard: Shard) -> None:
        """Add a shard to management"""
        self.shards[shard.shard_id] = shard
        self.logger.debug(f"Added shard {shard.shard_id} to manager")

    def get_shard(self, shard_id: int) -> Optional[Shard]:
        """Get a shard by ID"""
        return self.shards.get(shard_id)

    def get_shard_for_guild(self, guild_id: int) -> Optional[Shard]:
        """Get the shard responsible for a guild"""
        for shard in self.shards.values():
            if shard.handles_guild(guild_id):
                return shard
        return None

    @property
    def shard_count(self) -> int:
        """Total number of shards"""
        return len(self.shards)

    @property
    def connected_shards(self) -> int:
        """Number of connected shards"""
        return sum(1 for s in self.shards.values() if s.is_connected)

    @property
    def ready_shards(self) -> int:
        """Number of ready shards"""
        return sum(1 for s in self.shards.values() if s.is_ready)

    @property
    def average_latency(self) -> float:
        """Average latency across all shards"""
        latencies = [s.latency for s in self.shards.values() if s.latency != float("inf")]
        return sum(latencies) / len(latencies) if latencies else float("inf")

    @property
    def total_guild_count(self) -> int:
        """Total guilds across all shards"""
        return sum(s.guild_count for s in self.shards.values())

    def get_stats(self) -> Dict[str, Any]:
        """Get overall sharding statistics"""
        return {
            "shard_count": self.shard_count,
            "connected_shards": self.connected_shards,
            "ready_shards": self.ready_shards,
            "total_guilds": self.total_guild_count,
            "average_latency": self.average_latency,
            "shards": [shard.get_stats() for shard in self.shards.values()],
        }


class AutoShardedClient(Client):
    """
    Automatically-sharded Discord bot client.

    Handles creating and managing multiple shard connections for large bots
    (2500+ servers). Automatically determines optimal shard count and manages
    shard lifecycle, reconnection, and load balancing.

    Example:
        ```python
        bot = AutoShardedClient(intents=Intents.default())

        @bot.event
        async def on_ready():
            print(f"Bot ready with {bot.shard_count} shards!")
            print(f"Total guilds: {len(bot.guilds)}")

        @bot.event
        async def on_shard_ready(shard_id):
            print(f"Shard {shard_id} is ready!")

        bot.run(token)
        ```

    Attributes:
        shard_count: Total number of shards (auto-determined or manual)
        shard_manager: Manages all shard instances
        shards: Dictionary of shard_id -> Shard
    """

    def __init__(
        self,
        *,
        intents: Intents,
        shard_count: Optional[int] = None,
        shard_ids: Optional[List[int]] = None,
        command_prefix: str = "!",
        max_messages: int = 1000,
        large_threshold: int = 50,
        guild_subscriptions: bool = True,
        chunk_guilds_at_startup: bool = True,
        auto_reconnect: bool = True,
    ):
        """
        Initialize an auto-sharded client.

        Args:
            intents: Gateway intents
            shard_count: Number of shards (None = auto-determine)
            shard_ids: Specific shard IDs to spawn (None = all)
            command_prefix: Prefix for text commands
            max_messages: Maximum cached messages
            large_threshold: Offline member threshold
            guild_subscriptions: Subscribe to guild events
            chunk_guilds_at_startup: Request all members on startup
            auto_reconnect: Automatically reconnect on disconnect
        """
        super().__init__(intents=intents, command_prefix=command_prefix, max_messages=max_messages)

        # Sharding configuration
        self._shard_count = shard_count
        self._shard_ids = shard_ids
        self.large_threshold = large_threshold
        self.guild_subscriptions = guild_subscriptions
        self.chunk_guilds_at_startup = chunk_guilds_at_startup
        self.auto_reconnect = auto_reconnect

        # Shard management
        self.shard_manager = ShardManager(self)
        self._shards_ready = asyncio.Event()

        self.logger = logging.getLogger("auric.autoshard")

    @property
    def shards(self) -> Dict[int, Shard]:
        """Get all shards"""
        return self.shard_manager.shards

    @property
    def shard_count(self) -> int:
        """Get total shard count"""
        return self.shard_manager.shard_count

    @property
    def latency(self) -> float:
        """Get average latency across shards"""
        return self.shard_manager.average_latency

    def get_shard(self, shard_id: int) -> Optional[Shard]:
        """
        Get a specific shard by ID.

        Args:
            shard_id: Shard ID to retrieve

        Returns:
            Shard instance or None
        """
        return self.shard_manager.get_shard(shard_id)

    def get_shard_for_guild(self, guild_id: int) -> Optional[Shard]:
        """
        Get the shard responsible for a guild.

        Args:
            guild_id: Guild ID

        Returns:
            Shard that handles this guild
        """
        return self.shard_manager.get_shard_for_guild(guild_id)

    async def _determine_shard_count(self) -> int:
        """
        Determine optimal shard count from Discord API.

        Returns:
            Recommended shard count
        """
        if self._shard_count:
            return self._shard_count

        try:
            # Get recommended shard count from Discord
            gateway_info = await self._http.get_gateway_bot()
            recommended = gateway_info.get("shards", 1)

            self.logger.info(f"Discord recommends {recommended} shards")
            return recommended

        except Exception as e:
            self.logger.warning(f"Failed to get recommended shard count: {e}")
            return 1

    async def _create_shards(self) -> None:
        """Create all shard instances"""
        shard_count = await self._determine_shard_count()
        shard_ids = self._shard_ids or list(range(shard_count))

        self.logger.info(f"Creating {len(shard_ids)} shards (total: {shard_count})")

        for shard_id in shard_ids:
            if shard_id >= shard_count:
                raise ValueError(f"Shard ID {shard_id} exceeds shard count {shard_count}")

            shard = Shard(
                shard_id=shard_id,
                shard_count=shard_count,
                client=self,
                intents=self.intents,
                large_threshold=self.large_threshold,
                guild_subscriptions=self.guild_subscriptions,
            )

            # Set dispatch callback
            shard._dispatch = self._dispatch_shard_event

            self.shard_manager.add_shard(shard)

    async def _connect_shards(self, token: str) -> None:
        """
        Connect all shards sequentially with rate limiting.

        Discord allows 1 IDENTIFY per 5 seconds, so we stagger connections.
        """
        self.logger.info(f"Connecting {self.shard_count} shards...")

        for i, shard in enumerate(self.shards.values()):
            try:
                # Connect shard
                await shard.connect(token)

                # Dispatch shard_connect event
                await self._dispatch("shard_connect", shard.shard_id)

                # Rate limit: Wait 5 seconds between IDENTIFY
                if i < self.shard_count - 1:
                    self.logger.debug(f"Waiting 5s before next shard connection...")
                    await asyncio.sleep(5.5)  # Add buffer

            except Exception as e:
                self.logger.error(f"Failed to connect shard {shard.shard_id}: {e}")
                if not self.auto_reconnect:
                    raise

        self.logger.info(f"All {self.shard_count} shards connected!")
        self._shards_ready.set()

    async def _dispatch_shard_event(self, event_name: str, *args, **kwargs) -> None:
        """
        Dispatch events from shards, adding shard context.

        Args:
            event_name: Name of the event
            *args: Event arguments
            **kwargs: Event keyword arguments
        """
        # Get shard ID from context if available
        shard_id = kwargs.pop("shard_id", None)

        # Handle shard-specific events
        if event_name == "READY":
            if shard_id is not None:
                shard = self.get_shard(shard_id)
                if shard:
                    shard.status = ShardStatus.READY
                await self._dispatch("shard_ready", shard_id)

        elif event_name == "RESUMED":
            if shard_id is not None:
                await self._dispatch("shard_resumed", shard_id)

        elif event_name == "GUILD_CREATE":
            # Track guild in appropriate shard
            if args and "id" in args[0]:
                guild_id = int(args[0]["id"])
                shard = self.get_shard_for_guild(guild_id)
                if shard:
                    shard.add_guild(guild_id)

        elif event_name == "GUILD_DELETE":
            # Remove guild from shard
            if args and "id" in args[0]:
                guild_id = int(args[0]["id"])
                shard = self.get_shard_for_guild(guild_id)
                if shard:
                    shard.remove_guild(guild_id)

        # Dispatch to normal event handlers
        await super()._dispatch(event_name, *args, **kwargs)

    async def connect(self, token: str) -> None:
        """
        Connect all shards to Discord.

        Args:
            token: Bot authentication token
        """
        self.token = token

        # Initialize HTTP client
        await self._setup_http(token)

        # Create and connect shards
        await self._create_shards()
        await self._connect_shards(token)

        # Wait for all shards to be ready
        await self._shards_ready.wait()

        # Dispatch on_ready when all shards are ready
        ready_count = self.shard_manager.ready_shards
        if ready_count == self.shard_count:
            await self._dispatch("ready")

    async def close(self) -> None:
        """Close all shard connections"""
        self.logger.info("Closing all shards...")

        tasks = [shard.close() for shard in self.shards.values()]
        await asyncio.gather(*tasks, return_exceptions=True)

        await super().close()

        self.logger.info("All shards closed")

    async def reconnect_shard(self, shard_id: int, *, resume: bool = True) -> None:
        """
        Reconnect a specific shard.

        Args:
            shard_id: Shard ID to reconnect
            resume: Whether to resume session
        """
        shard = self.get_shard(shard_id)
        if not shard:
            raise ValueError(f"Shard {shard_id} not found")

        await shard.reconnect(resume=resume)

    def get_shard_stats(self) -> Dict[str, Any]:
        """
        Get statistics for all shards.

        Returns:
            Dictionary of shard statistics
        """
        return self.shard_manager.get_stats()

    def __repr__(self) -> str:
        return (
            f"<AutoShardedClient "
            f"shards={self.shard_count} "
            f"ready={self.shard_manager.ready_shards} "
            f"guilds={self.shard_manager.total_guild_count}>"
        )
