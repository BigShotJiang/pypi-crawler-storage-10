"""
Shard implementation for Auric

Handles individual shard connections to Discord's Gateway.
Required for bots in 2500+ servers.
"""

import asyncio
import logging
from datetime import datetime
from enum import IntEnum
from typing import Any, Callable, Dict, Optional

from ..utils.exceptions import ShardConnectionError
from .gateway import GatewayClient
from .intents import Intents


class ShardStatus(IntEnum):
    """Shard connection status"""

    DISCONNECTED = 0
    CONNECTING = 1
    CONNECTED = 2
    RECONNECTING = 3
    IDENTIFYING = 4
    RESUMING = 5
    READY = 6
    CLOSING = 7
    CLOSED = 8


class Shard:
    """
    Represents a single shard connection to Discord's Gateway.

    A shard handles a subset of guilds, allowing bots to scale beyond
    the 2500 server limit by distributing load across multiple WebSocket
    connections.

    Attributes:
        shard_id: The ID of this shard (0-indexed)
        shard_count: Total number of shards
        status: Current connection status
        guilds: Set of guild IDs this shard is responsible for
        latency: Current WebSocket latency in milliseconds
        session_id: Discord session ID for resuming
    """

    def __init__(
        self,
        shard_id: int,
        shard_count: int,
        client,
        intents: Intents,
        *,
        large_threshold: int = 50,
        guild_subscriptions: bool = True,
    ):
        """
        Initialize a shard.

        Args:
            shard_id: The shard ID (0 to shard_count-1)
            shard_count: Total number of shards
            client: Parent AutoShardedClient instance
            intents: Gateway intents for this shard
            large_threshold: Threshold for offline members
            guild_subscriptions: Whether to subscribe to guild events
        """
        self.shard_id = shard_id
        self.shard_count = shard_count
        self.client = client
        self.intents = intents
        self.large_threshold = large_threshold
        self.guild_subscriptions = guild_subscriptions

        # Connection state
        self.status = ShardStatus.DISCONNECTED
        self.gateway: Optional[GatewayClient] = None
        self.session_id: Optional[str] = None
        self.sequence: Optional[int] = None

        # Guild tracking
        self.guilds: set[int] = set()
        self.guild_count = 0

        # Metrics
        self.latency = float("inf")
        self.connected_at: Optional[datetime] = None
        self.disconnect_count = 0
        self.reconnect_count = 0

        # Callbacks
        self._dispatch: Optional[Callable] = None

        # Logger
        self.logger = logging.getLogger(f"auric.shard.{shard_id}")

    @property
    def is_connected(self) -> bool:
        """Check if shard is connected"""
        return self.status in (ShardStatus.CONNECTED, ShardStatus.READY)

    @property
    def is_ready(self) -> bool:
        """Check if shard is ready"""
        return self.status == ShardStatus.READY

    @property
    def is_closed(self) -> bool:
        """Check if shard is closed"""
        return self.status in (ShardStatus.CLOSING, ShardStatus.CLOSED)

    @property
    def uptime(self) -> Optional[float]:
        """Get shard uptime in seconds"""
        if not self.connected_at:
            return None
        return (datetime.utcnow() - self.connected_at).total_seconds()

    def handles_guild(self, guild_id: int) -> bool:
        """
        Check if this shard handles a specific guild.

        Discord uses: (guild_id >> 22) % shard_count == shard_id

        Args:
            guild_id: The guild ID to check

        Returns:
            True if this shard handles the guild
        """
        return (guild_id >> 22) % self.shard_count == self.shard_id

    async def connect(self, token: str) -> None:
        """
        Connect this shard to Discord's Gateway.

        Args:
            token: Bot token for authentication

        Raises:
            ShardConnectionError: If connection fails
        """
        if self.is_connected:
            self.logger.warning(f"Shard {self.shard_id} already connected")
            return

        self.logger.info(f"Shard {self.shard_id}/{self.shard_count-1} connecting...")
        self.status = ShardStatus.CONNECTING

        try:
            # Create gateway connection
            self.gateway = GatewayClient(
                token=token,
                intents=self.intents,
                shard_id=self.shard_id,
                shard_count=self.shard_count,
            )

            # Set dispatch callback
            if self._dispatch:
                self.gateway._dispatch = self._dispatch

            # Connect to Discord (this would need to be implemented in GatewayClient)
            # await self.gateway.connect()

            self.status = ShardStatus.CONNECTED
            self.connected_at = datetime.utcnow()

            self.logger.info(f"Shard {self.shard_id} connected successfully")

        except Exception as e:
            self.status = ShardStatus.DISCONNECTED
            self.disconnect_count += 1
            self.logger.error(f"Shard {self.shard_id} connection failed: {e}")
            raise ShardConnectionError(f"Failed to connect shard {self.shard_id}") from e

    async def reconnect(self, *, resume: bool = True) -> None:
        """
        Reconnect this shard.

        Args:
            resume: Whether to attempt session resume
        """
        self.logger.info(f"Shard {self.shard_id} reconnecting (resume={resume})...")
        self.status = ShardStatus.RECONNECTING if resume else ShardStatus.CONNECTING
        self.reconnect_count += 1

        try:
            if self.gateway and resume and self.session_id:
                # Attempt to resume
                await self.gateway.resume()
                self.status = ShardStatus.READY
            else:
                # Full reconnect
                await self.close()
                await self.connect(self.client.token)

        except Exception as e:
            self.logger.error(f"Shard {self.shard_id} reconnect failed: {e}")
            raise

    async def close(self, *, code: int = 1000) -> None:
        """
        Close this shard's connection.

        Args:
            code: WebSocket close code
        """
        if self.is_closed:
            return

        self.logger.info(f"Shard {self.shard_id} closing...")
        self.status = ShardStatus.CLOSING

        if self.gateway:
            await self.gateway.close(code=code)
            self.gateway = None

        self.status = ShardStatus.CLOSED
        self.disconnect_count += 1
        self.logger.info(f"Shard {self.shard_id} closed")

    def add_guild(self, guild_id: int) -> None:
        """
        Track a guild for this shard.

        Args:
            guild_id: Guild ID to track
        """
        if guild_id not in self.guilds:
            self.guilds.add(guild_id)
            self.guild_count = len(self.guilds)

    def remove_guild(self, guild_id: int) -> None:
        """
        Remove a guild from this shard.

        Args:
            guild_id: Guild ID to remove
        """
        if guild_id in self.guilds:
            self.guilds.discard(guild_id)
            self.guild_count = len(self.guilds)

    def update_latency(self, latency: float) -> None:
        """
        Update shard latency.

        Args:
            latency: New latency in milliseconds
        """
        self.latency = latency

    def get_stats(self) -> Dict[str, Any]:
        """
        Get shard statistics.

        Returns:
            Dictionary of shard statistics
        """
        return {
            "shard_id": self.shard_id,
            "shard_count": self.shard_count,
            "status": self.status.name,
            "is_connected": self.is_connected,
            "is_ready": self.is_ready,
            "guild_count": self.guild_count,
            "latency": self.latency if self.latency != float("inf") else None,
            "uptime": self.uptime,
            "disconnect_count": self.disconnect_count,
            "reconnect_count": self.reconnect_count,
            "session_id": self.session_id is not None,
        }

    def __repr__(self) -> str:
        return (
            f"<Shard id={self.shard_id} "
            f"status={self.status.name} "
            f"guilds={self.guild_count} "
            f"latency={self.latency:.2f}ms>"
        )
