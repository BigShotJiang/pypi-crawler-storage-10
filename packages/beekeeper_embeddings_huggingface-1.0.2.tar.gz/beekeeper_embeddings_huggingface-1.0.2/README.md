# Beekeeper embeddings extension - huggingface

## Installation 

```bash
pip install beekeeper-embeddings-huggingface
```
