# license_generator.py
from cryptography.fernet import Fernet
from .master_key_manager import load_master_key

def generate_license(user_id: str) -> str:
    f = Fernet(load_master_key())
    token = f.encrypt(user_id.encode())
    return token.decode()

if __name__ == "__main__":
    user_id = input("Enter buyer ID/email: ")
    print("License key:", generate_license(user_id))
