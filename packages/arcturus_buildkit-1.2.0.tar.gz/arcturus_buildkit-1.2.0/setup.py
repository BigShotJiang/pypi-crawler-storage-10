from setuptools import setup, find_packages

setup(
    name="arcturus-buildkit",
    version="1.2.0",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
    author="FlameZI0",
    description="A powerful, modular NLP toolkit for Python.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://pypi.org/project/arcturus-buildkit/",
)
