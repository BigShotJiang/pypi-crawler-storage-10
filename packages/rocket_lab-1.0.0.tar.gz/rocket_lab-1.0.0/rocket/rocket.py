# Save as rocket.py
from math import sqrt, pi

class Rocket:
    """Rocket simulates a rocket ship for a game or a physics simulation."""
    
    def __init__(self, x=0, y=0):
        # Each rocket has an (x,y) position.
        self.x = x
        self.y = y
        
    def move_rocket(self, x_increment=0, y_increment=1):
        """Move the rocket according to the parameters given."""
        self.x += x_increment
        self.y += y_increment
        
    def get_distance(self, other_rocket):
        """Calculate the distance from this rocket to another rocket."""
        distance = sqrt((self.x - other_rocket.x)**2 + (self.y - other_rocket.y)**2)
        return distance
    
    def __eq__(self, other):
        """Check if two rockets are at the same position."""
        if not isinstance(other, Rocket):
            return NotImplemented
        return self.x == other.x and self.y == other.y
    
    def __str__(self):
        return f"A Rocket positioned at ({self.x}, {self.y})"

    def __repr__(self):
        return f"Rocket({self.x},{self.y})"


class Shuttle(Rocket):
    """Shuttle simulates a space shuttle, a reusable rocket."""
    
    def __init__(self, x=0, y=0, flights_completed=0):
        super().__init__(x, y)
        self.flights_completed = flights_completed

    def __str__(self):
        return f"A Shuttle positioned at ({self.x}, {self.y}) - Flights completed: {self.flights_completed}"

    def __repr__(self):
        return f"Shuttle({self.x},{self.y},{self.flights_completed})"


class CircleRocket(Rocket):
    """A special rocket shaped as a circle, with additional geometry methods."""
    
    def __init__(self, x=0, y=0, r=1):
        super().__init__(x, y)
        self.r = r

    def get_area(self):
        """Return the area of the circular rocket."""
        return pi * (self.r ** 2)
    
    def get_circumference(self):
        """Return the circumference of the circular rocket."""
        return 2 * pi * self.r

    def __str__(self):
        return f"A CircleRocket at ({self.x},{self.y}) with radius {self.r}"

    def __repr__(self):
        return f"CircleRocket({self.x},{self.y},{self.r})"
