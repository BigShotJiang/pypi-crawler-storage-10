.. _latex_spirale:

Spirale logarithmique
=====================

La mosaïque au bouclier est exposée au `musée archéologique de Saint-Romain-en-Gal <https://musee-site.rhone.fr/>`_. Un esprit mathématique y reconnaîtra des spirales logarithmiques. J'ai voulu les reproduire en :math:`\LaTeX`.

.. figure:: spirale/bouclier.jpg

   Photo de la « Mosaïque au Bouclier », au musée de Saint-Romain-en-Gal.

Le résultat est là :

.. image:: spirale/bouclier.svg

Quelques explications
---------------------

Remarquons tout d'abord que la « spirale » est en fait constituée de segments de droite. Cela rend la figure plus facile à tracer, puisqu'il n'y a alors que des segments et des arcs de cercle.

Rappelons qu'une spirale logarithmique est caractérisée par l'équation :math:`r = a\times b^{\theta}`, où :math:`(r; \theta)` sont les coordonnées polaires des points de la spirale. Pour simplifier, nous prenons ici `a=1` et `b=1,02` (les deux valeurs sont arbitraires, fixées en tatonnant pour simplifier les calculs, et pour donner à notre figure les mêmes « proportions » que la mosaïque).

1. Commençons par tracer un « triangle », composé d'un arc de cercle et de deux segments. Les coordonnées polaires des trois points sont les suivantes, où :

   - :math:`\theta` est « l'angle de départ » du triangle ;
   - :math:`\delta` est la « largeur » (en degrés) du triangle (faire varier cette valeur change le nombre de répétitions du triangle par cercle).

   .. image:: spirale/bouclier-explications-01.svg

2. Puis nous répétons ce motif tout autour du cercle. Cela se fait en ajoutant :math:`delta` autant de fois que nécessaire, à *l'angle* des coordonnées, mais pas à l'argument du rayon.

   .. image:: spirale/bouclier-explications-02.svg

   Cela donne un cercle complet de « triangles ».

3. Pour faire le cercle suivant, on répète le processus, en prenant comme angle de départ :math:`\theta+\frac{\delta}{2}`, et ainsi de suite, autant de fois que de cercles souhaités.

Code source
-----------

Tout cela a été placé dans une macro qui dessine *un seul triangle*, qui est appelée plusieurs fois avec deux boucles, l'une qui répète *un* triangle sur un cercle, et l'autre qui répète un cercle avec un rayon plus grand.

.. literalinclude:: ../../latex/spirale/bouclier.tex
   :language: latex
