* Version 0.2.0 (unreleased)

    Ajout d'une spirale logarithmique.

    -- Louis Paternault <spalax@gresille.org>

* Version 0.1.0 (2023-10-07)

    Première version publiée.

    -- Louis Paternault <spalax@gresille.org>
