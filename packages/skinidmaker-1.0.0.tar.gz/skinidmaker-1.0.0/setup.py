from setuptools import setup, find_packages

# Read README for PyPI long description
with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="skinidmaker",
    version="1.0.0",
    author="Pixelated Studios",
    author_email="support@pixelatedstudios.dev",
    description="A tool to create and compile SkinID files for Cube Run: Halloween Edition.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Chayce22315/SkinIDMaker",
    project_urls={
        "Bug Tracker": "https://github.com/Chayce22315/SkinIDMaker/issues",
        "Source Code": "https://github.com/Chayce22315/SkinIDMaker",
    },
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License",
        "Topic :: Games/Entertainment",
        "Intended Audience :: Developers"
    ],
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "skinidmaker=skinidmaker.cli:main",  # CLI command
        ],
    },
    install_requires=[
        "Pillow>=10.0.0",  # For image creation/editing
        "tk>=0.1.0"        # For optional GUI
    ],
)