# skinidmaker/cli.py
# This module provides a command-line interface for compiling user data into a skin ID file.
# Skin ID Maker for Cube Run: Halloween Edition
import json
import os
import random
import argparse
from pathlib import Path

def compile_skin(author, name, color, effects, output_dir):
    """
    Compiles user data into a .skinID fike (a compact encoded file)
    """
    # encode data as numbers
    compiled_data = {
        "id": random.randint(100000, 999999),
        "author": author,
        "name": name,
        "color": color,
        "effects": effects or "None"
    }
    # turn into a simple encoded numeric sequence
    encoded = "=".join(str(ord(c)) for c in json.dumps(compiled_data))

    output_path = Path(output_dir) / f"{name}.skinID"
    with open(output_path, "w") as f:
        f.write(encoded)

    print(f"Skin ID file created at: {output_path}")
    return output_path
def main():
    parser = argparse.ArgumentParser(
        description="Compile user data into a .skinID file for Cube Run: Halloween Edition"
    )
    parser.add_argument("--author", required=False, help="Author of the skin")
    parser.add_argument("--name", required=False, help="Name of the skin")
    parser.add_argument("--color", required=False, help="Color of the skin")
    parser.add_argument("--effects", help="Special effects for the skin")
    parser.add_argument("--output", default=".", help="Output directory for the .skinID file")
    args = parser.parse_args()

    # if no args passed, enter interactive mode
    if not any([args.author, args.name, args.color, args.effects]):
        print("Welcome to Skin ID Maker!, This software is only for the upcoming game: Cube Run: Halloween Edition")
        author = input("Enter author name: ")
        name = input("Enter skin name: ")
        color = input("Base Color (hex): ")
        effects = input("Special Effects (optional): ")
        output_ = input("Output directory (default is current directory): ") or "."
    else:
        author = args.author
        name = args.name
        color = args.color
        effects = args.effects
        output_ = args.output

    # ensure directory exists
    os.makedirs(output_, exist_ok=True)

    # compile
    compile_skin(author, name, color, effects, output_)

if __name__ == "__main__":
    main()
        