# SkinIDMaker

**SkinIDMaker** is a tool for creating, compiling, and managing custom skins for **Cube Run: Halloween Edition**. It allows players to create their own skins with custom images, colors, and effects, then compile them into `.skinID` files for use in the game.

---

## Features

- Create skins using JSON or custom images.
- Compile skins into `.skinID` files.
- Automatically save compiled skins to the game folder.
- Supports custom author and skin name metadata.
- GUI and CLI versions bundled.
- Works cross-platform (macOS, Windows, Linux).
- Optional installation via Homebrew for GUI.

---

## Installation

### GUI (macOS)

```bash
brew install --cask skinidmaker