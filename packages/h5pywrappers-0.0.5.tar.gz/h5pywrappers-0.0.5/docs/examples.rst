.. _examples_sec:

Examples
========

You can find examples of using the ``h5pywrappers`` library in the notebook
located at ``<root>/examples/basic_usage.ipynb``, where ``<root>`` is the root
of the ``h5pywrappers`` repository. You can find the repository `here
<https://github.com/mrfitzpa/h5pywrappers>`_.
