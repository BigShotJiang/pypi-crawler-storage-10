.. _reference_guide_sec:

h5pywrappers reference guide
============================

.. autosummary::
   :toctree: _autosummary
   :template: custom_module_template.rst
   :recursive:

   h5pywrappers
