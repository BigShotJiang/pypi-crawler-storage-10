
"""Unit tests for vulnerability checks"""

import unittest
from unittest.mock import Mock, MagicMock
from web_pentest_cli.http_client import HTTPClient
from web_pentest_cli.vuln_checks import (
    SecurityHeadersCheck,
    CookieSecurityCheck,
    VulnerabilityResult
)


class TestVulnerabilityResult(unittest.TestCase):
    """Test VulnerabilityResult class."""

    def test_to_dict(self):
        """Test conversion to dictionary."""
        result = VulnerabilityResult(
            vuln_id='TEST-001',
            name='Test Vulnerability',
            severity='high',
            confidence='medium',
            description='Test description',
            evidence='Test evidence',
            remediation='Test remediation',
            url='https://example.com'
        )

        d = result.to_dict()
        self.assertEqual(d['vuln_id'], 'TEST-001')
        self.assertEqual(d['name'], 'Test Vulnerability')
        self.assertEqual(d['severity'], 'high')


class TestSecurityHeadersCheck(unittest.TestCase):
    """Test security headers check."""

    def setUp(self):
        """Set up test environment."""
        self.client = Mock(spec=HTTPClient)
        self.check = SecurityHeadersCheck(self.client, mode='passive')

    def test_missing_headers(self):
        """Test detection of missing security headers."""
        mock_response = Mock()
        mock_response.headers = {}  # No security headers
        mock_response.status_code = 200

        self.client.get.return_value = mock_response

        results = self.check.check('https://example.com', {})

        # Should find multiple missing headers
        self.assertGreater(len(results), 0)

        # Check that CSP is flagged as missing
        csp_found = any('content-security-policy' in r.vuln_id.lower() 
                       for r in results)
        self.assertTrue(csp_found)

    def test_present_headers(self):
        """Test with security headers present."""
        mock_response = Mock()
        mock_response.headers = {
            'Content-Security-Policy': "default-src 'self'",
            'X-Frame-Options': 'DENY',
            'X-Content-Type-Options': 'nosniff',
            'Strict-Transport-Security': 'max-age=31536000',
            'Referrer-Policy': 'no-referrer',
            'Permissions-Policy': 'geolocation=()'
        }
        mock_response.status_code = 200

        self.client.get.return_value = mock_response

        results = self.check.check('https://example.com', {})

        # Should find no missing headers
        self.assertEqual(len(results), 0)


class TestCookieSecurityCheck(unittest.TestCase):
    """Test cookie security check."""

    def setUp(self):
        """Set up test environment."""
        self.client = Mock(spec=HTTPClient)
        self.check = CookieSecurityCheck(self.client, mode='passive')

    def test_insecure_cookie(self):
        """Test detection of insecure cookies."""
        mock_response = Mock()
        mock_cookie = Mock()
        mock_cookie.name = 'session'
        mock_cookie.secure = False
        mock_cookie.has_nonstandard_attr = Mock(return_value=False)
        mock_cookie.get_nonstandard_attr = Mock(return_value=None)

        mock_response.cookies = [mock_cookie]
        mock_response.status_code = 200

        self.client.get.return_value = mock_response

        results = self.check.check('https://example.com', {})

        # Should find insecure cookie issues
        self.assertGreater(len(results), 0)


if __name__ == '__main__':
    unittest.main()

