
"""Unit tests for HTTP client"""

import unittest
from unittest.mock import Mock, patch
import requests
from web_pentest_cli.http_client import HTTPClient


class TestHTTPClient(unittest.TestCase):
    """Test HTTP client functionality."""

    def setUp(self):
        """Set up test client."""
        self.client = HTTPClient(rate_limit=10.0, timeout=5)

    def tearDown(self):
        """Clean up."""
        self.client.close()

    def test_initialization(self):
        """Test client initialization."""
        self.assertEqual(self.client.timeout, 5)
        self.assertEqual(self.client.rate_limiter.requests_per_second, 10.0)
        self.assertIsNotNone(self.client.session)

    @patch('requests.Session.request')
    def test_successful_request(self, mock_request):
        """Test successful HTTP request."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.content = b'Test content'
        mock_response.headers = {}
        mock_request.return_value = mock_response

        response = self.client.get('https://example.com')

        self.assertIsNotNone(response)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.client.stats['successful_requests'], 1)

    @patch('requests.Session.request')
    def test_failed_request(self, mock_request):
        """Test failed HTTP request."""
        mock_request.side_effect = requests.exceptions.Timeout()

        response = self.client.get('https://example.com')

        self.assertIsNone(response)
        self.assertEqual(self.client.stats['failed_requests'], 1)

    def test_custom_headers(self):
        """Test custom headers."""
        headers = self.client._get_headers({'X-Custom': 'value'})
        self.assertIn('User-Agent', headers)
        self.assertEqual(headers['X-Custom'], 'value')

    def test_get_stats(self):
        """Test statistics retrieval."""
        stats = self.client.get_stats()
        self.assertIn('total_requests', stats)
        self.assertIn('successful_requests', stats)
        self.assertIn('failed_requests', stats)


if __name__ == '__main__':
    unittest.main()

