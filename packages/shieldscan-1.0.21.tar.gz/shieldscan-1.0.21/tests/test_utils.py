
"""Unit tests for utility functions"""

import unittest
from web_pentest_cli.utils import (
    is_valid_url,
    normalize_url,
    sanitize_for_logging,
    extract_domain,
    is_same_domain,
    RateLimiter
)


class TestURLValidation(unittest.TestCase):
    """Test URL validation functions."""

    def test_valid_urls(self):
        """Test valid URL detection."""
        valid_urls = [
            'https://example.com',
            'http://example.com',
            'https://example.com/path',
            'https://sub.example.com',
        ]
        for url in valid_urls:
            self.assertTrue(is_valid_url(url), f"Should be valid: {url}")

    def test_invalid_urls(self):
        """Test invalid URL detection."""
        invalid_urls = [
            'not-a-url',
            'ftp://example.com',
            '',
            'javascript:alert(1)',
        ]
        for url in invalid_urls:
            self.assertFalse(is_valid_url(url), f"Should be invalid: {url}")

    def test_normalize_url(self):
        """Test URL normalization."""
        self.assertEqual(
            normalize_url('example.com'),
            'https://example.com'
        )
        self.assertEqual(
            normalize_url('http://example.com/path#fragment'),
            'http://example.com/path'
        )


class TestSanitization(unittest.TestCase):
    """Test data sanitization functions."""

    def test_sanitize_authorization(self):
        """Test Authorization header sanitization."""
        text = "Authorization: Bearer secret_token_123"
        sanitized = sanitize_for_logging(text)
        self.assertIn('[REDACTED]', sanitized)
        self.assertNotIn('secret_token_123', sanitized)

    def test_sanitize_cookie(self):
        """Test Cookie header sanitization."""
        text = "Cookie: session=abc123; user=john"
        sanitized = sanitize_for_logging(text)
        self.assertIn('[REDACTED]', sanitized)
        self.assertNotIn('abc123', sanitized)


class TestDomainExtraction(unittest.TestCase):
    """Test domain extraction functions."""

    def test_extract_domain(self):
        """Test domain extraction."""
        self.assertEqual(
            extract_domain('https://example.com/path'),
            'example.com'
        )
        self.assertEqual(
            extract_domain('https://sub.example.com:8080/path'),
            'sub.example.com:8080'
        )

    def test_same_domain(self):
        """Test same domain check."""
        self.assertTrue(
            is_same_domain('https://example.com/a', 'https://example.com/b')
        )
        self.assertFalse(
            is_same_domain('https://example.com', 'https://other.com')
        )


class TestRateLimiter(unittest.TestCase):
    """Test rate limiter."""

    def test_rate_limiter_initialization(self):
        """Test rate limiter initialization."""
        limiter = RateLimiter(requests_per_second=2.0)
        self.assertEqual(limiter.requests_per_second, 2.0)
        self.assertEqual(limiter.min_interval, 0.5)

    def test_rate_limiter_wait(self):
        """Test rate limiter wait functionality."""
        import time
        limiter = RateLimiter(requests_per_second=10.0)

        start = time.time()
        limiter.wait_if_needed()
        limiter.wait_if_needed()
        elapsed = time.time() - start

        # Should wait at least the minimum interval
        self.assertGreaterEqual(elapsed, 0.1)


if __name__ == '__main__':
    unittest.main()
