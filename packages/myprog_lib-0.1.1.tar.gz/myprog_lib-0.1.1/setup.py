from setuptools import setup, find_packages

setup(
    name='myprog_lib',               # Your library name (this is what pip install uses)
    version='0.1.1',                 # Increment version if updating
    packages=find_packages(),
    install_requires=[],             # Add dependencies if any
    description='A sample Python library by Deepak',
    author='Deepak M',
    author_email='deepakm9743@gmail.com',
    url='https://pypi.org/project/myprog-lib/',
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
