def get_prog(value):
    if value == 1:
        print("Value is one")
    elif value == 2:
        print("Value is two")
    elif value == 3:
        print("Value is three")
    else:
        print("Value is something else")

