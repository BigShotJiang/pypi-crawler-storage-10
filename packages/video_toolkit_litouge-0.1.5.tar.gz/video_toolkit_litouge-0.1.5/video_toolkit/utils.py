# video_toolkit/utils.py

import subprocess
import json
from pathlib import Path

from pathlib import Path

def find_large_videos(root: Path, size_threshold_mb: int, exts: list[str] = None):
    """
    遍历目录，查找超过指定大小的视频文件
    支持用户自定义扩展名列表（如 .mov .mp4 .avi）
    自动排除 compressed 子目录，避免重复处理
    """
    if exts is None:
        exts = [".mov", ".mp4", ".avi", ".mkv", ".webm", ".flv"]

    for path in root.rglob("*"):
        # ✅ 排除 compressed 子目录
        if "compressed" in path.parts:
            continue

        if path.suffix.lower() in exts and path.is_file():
            size_mb = path.stat().st_size / (1024 * 1024)
            if size_mb >= size_threshold_mb:
                yield path


def get_video_resolution(path: Path):
    cmd = [
        "ffprobe", "-v", "error",
        "-select_streams", "v:0",
        "-show_entries", "stream=width,height",
        "-of", "json",
        str(path)
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    info = json.loads(result.stdout)
    stream = info.get("streams", [{}])[0]
    return int(stream.get("width", 0)), int(stream.get("height", 0))

def parse_resolution(res_str: str):
    if not res_str:
        return None
    try:
        w, h = map(int, res_str.lower().split("x"))
        return (w, h)
    except:
        print("分辨率格式错误，应为 WIDTHxHEIGHT，例如 1920x1080")
        return None
