from .serializers import BaseModelSerializer

__all__ = ["BaseModelSerializer"]
