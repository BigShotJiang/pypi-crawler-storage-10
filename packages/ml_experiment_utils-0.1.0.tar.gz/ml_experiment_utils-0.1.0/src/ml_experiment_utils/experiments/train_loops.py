import wandb
from torch.optim import Adam
from tqdm.auto import tqdm
from torch.nn import CrossEntropyLoss
from torch.optim.lr_scheduler import CosineAnnealingLR
import torch


class ApproximateSlidingAverage:
    def __init__(self, window_size):
        self.alpha = 2 / (window_size + 1)
        self.average = None

    def update(self, new_value):
        if self.average is None:
            self.average = new_value
        else:
            self.average = self.alpha * new_value + (1 - self.alpha) * self.average
        return self.average

    @property
    def value(self):
        return self.average


def eval_on(dataloader, model, device):
    count = 0
    acc_a = 0
    model.to(device)
    model.eval()
    with torch.no_grad():
        for x_batch, y_batch in tqdm(dataloader):
            x_batch = x_batch.to(device)
            y_batch = y_batch.to(device)
            out = model(x_batch)
            y_preds = torch.argmax(out, dim=-1)
            acc = (y_batch == y_preds).float().sum()
            acc_a += acc
            count += len(y_batch)
    return acc_a / count


def simple_cls_train_v1(model, epochs, eval_steps, train_loader, test_loader, lr=5e-4, name="simple-training"):
    """
    Trains a classification model using a simple training loop with evaluation and logging.

    This function trains a PyTorch model for a specified number of epochs, evaluates it
    periodically on a test dataset, and logs training metrics to Weights & Biases (wandb).

    Args:
        model (torch.nn.Module): The PyTorch model to be trained.
        epochs (int): The number of training epochs.
        eval_steps (int): The number of steps between evaluations on the test dataset.
        train_loader (torch.utils.data.DataLoader): DataLoader for the training dataset.
        test_loader (torch.utils.data.DataLoader): DataLoader for the test dataset.
        lr (float, optional): Learning rate for the optimizer. Defaults to 5e-4.
        name (str, optional): Name of the wandb project defaults to "simple-training".

    Returns:
        None
    """
    # Initialize wandb
    wandb.init(project=name, config={
        "learning_rate": lr,
        "epochs": epochs,
        "eval_steps": eval_steps,
        "batch_size": train_loader.batch_size if hasattr(train_loader, 'batch_size') else None
    })

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)

    # Watch the model to track gradients and parameters
    wandb.watch(model, log="all", log_freq=eval_steps)

    mean_loss = ApproximateSlidingAverage(eval_steps)
    mean_acc = ApproximateSlidingAverage(eval_steps)

    optim = Adam(params=model.parameters(), lr=lr)
    criterion = CrossEntropyLoss()
    scheduler = CosineAnnealingLR(optim, T_max=epochs * len(train_loader))

    pbar = tqdm(total=epochs * len(train_loader))
    step_count = 0

    for epoch in range(epochs):
        model.train()
        for x_batch, y_batch in train_loader:
            x_batch = x_batch.to(device)
            y_batch = y_batch.to(device)
            optim.zero_grad()
            out = model(x_batch)
            loss = criterion(out, y_batch)

            loss.backward()
            optim.step()
            scheduler.step()
            pbar.update(1)

            mean_loss.update(loss.cpu().item())
            y_preds = torch.argmax(out, dim=-1)
            acc = (y_batch == y_preds).float().mean().cpu().item()
            mean_acc.update(acc)

            step_count += 1

            # Log to wandb every eval_steps
            if step_count % eval_steps == 0:
                test_acc = eval_on(test_loader, model, device).cpu().item()
                wandb.log({
                    "train_loss": mean_loss.value,
                    "test_accuracy": test_acc,
                    "train_accuracy": mean_acc.value,
                    "learning_rate": scheduler.get_last_lr()[0],
                    "epoch": epoch + step_count / (epochs * len(train_loader))
                }, step=step_count)

                pbar.set_postfix_str(f"Loss: {mean_loss.value:.2f}, Acc: {mean_acc.value:.2f}")

    pbar.close()
    wandb.finish()
