NAME = "mlscat"
VERSION = '0.1.6'
