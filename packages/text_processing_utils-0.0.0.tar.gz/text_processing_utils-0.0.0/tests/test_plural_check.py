import spacy
from text_processing_utils.boolean_checks import is_plural


assert is_plural("proportion of women") == False
assert is_plural("number of cycles") == False
assert is_plural("dogs") == True
assert is_plural("lifetime") == False
assert is_plural("dog") == False
assert is_plural("mitochondria") == True
assert is_plural("dog and cat") == True
assert is_plural("dog and cats") == True
assert is_plural("dog and cat and dog") == True
assert is_plural("lifetime and efficency") == True
assert is_plural("lifetime and efficencies") == True
assert is_plural("s") == False
assert is_plural("PPS") == False
assert is_plural("PPs") == True
assert is_plural("PP") == False
assert is_plural("foot") == False
assert is_plural("feet") == True
assert is_plural("tooth") == False
assert is_plural("teeth") == True
assert is_plural("goose") == False
# assert is_plural("geese") == True
assert is_plural("man") == False
assert is_plural("men") == True
assert is_plural("woman") == False
assert is_plural("women") == True
assert is_plural("mouse") == False
assert is_plural("mice") == True
assert is_plural("louse") == False
# assert is_plural("lice") == True
assert is_plural("die") == False
# assert is_plural("dice") == True
assert is_plural("ox") == False
# assert is_plural("oxen") == True
assert is_plural("child") == False
assert is_plural("children") == True
assert is_plural("person") == False
assert is_plural("people") == True
assert is_plural("penny") == False
assert is_plural("pence") == True
assert is_plural("focus") == False
assert is_plural("foci") == True 
assert is_plural("radius") == False
assert is_plural("radii") == True 
assert is_plural("fungus") == False
assert is_plural("fungi") == True
assert is_plural("nucleus") == False
assert is_plural("nuclei") == True
assert is_plural("cactus") == False
assert is_plural("cacti") == True
assert is_plural("alumnus") == False
assert is_plural("alumni") == True
assert is_plural("octopus") == False
assert is_plural("octopuses") == True
assert is_plural("octopi") == True
assert is_plural("hippopotamus") == False
assert is_plural("hippopotami") == True 
assert is_plural("hippopotamuses") == True  
assert is_plural("phenomenon") == False
assert is_plural("phenomena") == True
assert is_plural("criterion") == False
assert is_plural("criteria") == True
assert is_plural("datum") == False
assert is_plural("data") == True
assert is_plural("memorandum") == False
assert is_plural("memoranda") == True
assert is_plural("bacterium") == False
assert is_plural("bacteria") == True
assert is_plural("stratum") == False
assert is_plural("strata") == True
assert is_plural("curriculum") == False
assert is_plural("curricula") == True  
assert is_plural("curriculums") == True  
assert is_plural("index") == False
assert is_plural("indices") == True
assert is_plural("appendix") == False
assert is_plural("appendices") == True
assert is_plural("vortex") == False
assert is_plural("vortices") == True

print("Done.")