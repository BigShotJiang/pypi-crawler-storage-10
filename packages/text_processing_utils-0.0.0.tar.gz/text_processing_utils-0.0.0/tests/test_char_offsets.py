
from text_processing_utils.char_offsets import get_span_distance_sorted, get_span_distance


def test_char_dist():
    """Test batching functions."""

    # Consecutive spans.
    a = (5, 10)
    b = (15, 20)    
    assert get_span_distance_sorted(a, b) == 5    
    assert get_span_distance_sorted(b, a) == -15    
    assert get_span_distance(a, b) == 5
    assert get_span_distance(b, a) == -5
    assert get_span_distance(a, b, return_abs=True) == 5
    assert get_span_distance(b, a, return_abs=True) == 5


    # Overlapping spans.
    a = (5, 15)
    b = (10, 20)
    assert get_span_distance_sorted(a, b) == -5    
    assert get_span_distance_sorted(b, a) == -15
    assert get_span_distance(a, b) == -5
    assert get_span_distance(b, a) == -5
    assert get_span_distance(a, b, return_abs=True) == 5
    assert get_span_distance(b, a, return_abs=True) == 5


if __name__ == "__main__":
    test_char_dist()
    print("All tests passed.")