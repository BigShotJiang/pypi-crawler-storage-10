
from text_processing_utils.batches import get_batches_of_strict_size_with_remainder, get_n_batches, get_batches_of_roughly_equal_size


def test_batching():
    """Test batching functions."""
    samples = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25]

    # Create equally sized batches of size 4 with remainder in last batch.
    batches_of_four_with_rest = get_batches_of_strict_size_with_remainder(samples, 4)
    assert batches_of_four_with_rest == [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16], [17, 18, 19, 20], [21, 22, 23, 24], [25]]

    # Create batches of max size 4, but more equally sized.
    batches_of_max_four = get_batches_of_roughly_equal_size(samples, 4)
    assert batches_of_max_four == [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16], [17, 18, 19], [20, 21, 22], [23, 24, 25]]

    # Create 4 roughly equally sized batches.
    four_batches = get_n_batches(samples, 4)
    assert four_batches == [[1, 2, 3, 4, 5, 6, 7], [8, 9, 10, 11, 12, 13], [14, 15, 16, 17, 18, 19], [20, 21, 22, 23, 24, 25]]


if __name__ == "__main__":
    test_batching()
    print("All tests passed.")