def _adapt_offsets(annotations, special_symbols, enclosed_span_offsets):
    # Get new offsets including special symbols
    for annotation in annotations:
        if type(annotation) == dict:
            for bound in ["start", "end"]:
                if annotation[bound] > enclosed_span_offsets[1]:
                    # If entity matches end move behind special symbols.
                    annotation[bound] += len(
                        special_symbols[0] + special_symbols[1]
                    )
                elif annotation[bound] > enclosed_span_offsets[0]:
                    # If entity matches start stay before special symbols.
                    annotation[bound] += len(special_symbols[0])

    return annotations


def enclose_with_special_symbol(
    text,
    target_char_offsets,
    start_symbol="🍏",
    end_symbol="🍐",
    adapt_annotations=[],
):
    """
    Enclose an annotation span in special symbols. Optionally, annotations can be given as lists of char offsets and will be adapted accordingly.
    """
    target_start, target_end = target_char_offsets

    if target_start == target_end:
        # Do nothing for zero width annotation.
        return text, adapt_annotations

    text_ann = (
        text[:target_start]
        + start_symbol
        + text[target_start:target_end]
        + end_symbol
        + text[target_end:]
    )

    # Adapt offsets of remaining annotations to added special symbol.
    adapt_annotations = _adapt_offsets(
        adapt_annotations,
        [start_symbol, end_symbol],
        [target_start, target_end],
    )

    return text_ann, adapt_annotations


def adapt_offsets_to_special_symbol_enclosings(new_annotation, previous_annotations, previous_enclosings):
    """Adapt annotation according to previously inserted special symbols. 

    Args:
        new_annotation: Char offset (int, int) relative to text without special symbols inserted.
        previous_annotations: List of char offsets [(int, int), ...] relative to text without special symbols inserted.
        previous_enclosings: List of previous enclosings [(str, str), ...] that were inserted before.

    Returns:
        Char offset (int, int) of new annotation relative to text with all special symbols inserted.
    """
    
    # Get len of all start special symobls until the new annotation start and end.
    start_offset = 0
    end_offset = 0
    for ann, encl in zip(previous_annotations, previous_enclosings):
        if ann == (0, 0):
            # We ignore annotations with offset (0, 0) as they are implicit.
            continue
        elif ann[1] < new_annotation[0]:
            # Completely before the new annotation.
            start_offset += len(encl[0]) + len(encl[1])
        elif ann[0] < new_annotation[0]:
            start_offset += len(encl[0])
            if ann[1] < new_annotation[1]:
                # Overlaps from left into the new annotation.
                end_offset += len(encl[0]) + len(encl[1])
        elif ann[1] < new_annotation[1]:
            # Completely inside the new annotation.
            end_offset += len(encl[0]) + len(encl[1])
        elif ann[0] < new_annotation[1]:
            # Overlaps from right into the new annotation.
            end_offset += len(encl[1])
        else:
            # After the new annotation.
            continue
    
    end_offset += start_offset

    return start_offset, end_offset