
import re
from typing import Union
from bisect import bisect_left
from spacy.tokens.span import Span

try:
    from semchunk import get_semantic_bounderies
except ImportError:
    print("Warning: Optional dependency semchunk could not be imported. Make sure to install it from ... to use locate_span_in_context() without providing semantic boundaries.")

from text_processing_utils.char_offsets import is_inside, get_span_distance



def get_sent_idx(span: dict, sents: list[Span]) -> Union[int, None]:
    """
    Get sentence index based on text span.
    
    Args:
        span (dict): "start" and "end" char offsets of the span
        sents (list[Span]): List of spaCy doc.sents, that is, sents = list(doc.sents)

    Returns:
        Union[int, None]: Sentence index or None if not found.
    """
    for i, sent in enumerate(sents):
        if (sent.start_char <= span["start"] and span["end"] <= sent.end_char):
            return i

    return None


def locate_span_in_context(surface, context, text_span, context_char_offset=0, text=None, semantic_boundaries=None, char_offsets_if_implicit=(0, 0)):
    """
    Locate the a text span based on its surface form in a text snippet.
    """
    
    if context_char_offset == 0 and text == None:
        text = context
    elif context != text[context_char_offset:context_char_offset+len(context)]:
        raise ValueError("Context and text do not match when aligning both at position context_char_offset.")
   
    # Get exact matches of prediction in the context.
    surface_matches = [(m.start() + context_char_offset, m.end() + context_char_offset) for m in re.finditer(re.escape(surface), context)]
    if len(surface_matches) == 0:
        # Try again after swapping case of the first letter.
        surface_case_changed = surface[0].swapcase() + surface[1:]
        surface_matches = [(m.start() + context_char_offset, m.end() + context_char_offset) for m in re.finditer(re.escape(surface_case_changed), context)]
        if len(surface_matches) > 0:
            surface = surface_case_changed

    if len(surface_matches) == 0:
        # Answer is implicit in the context.
        char_offsets = char_offsets_if_implicit
        is_implicit = True
    elif len(surface_matches) == 1:
        # Answer is explicit and unique in the context.
        is_implicit = False
        char_offsets = surface_matches[0]                            
    else:
        # Answer is explicit but not unambiguously locatable.
        is_implicit = False
        
        # If not given, get semantic boundaries.
        if semantic_boundaries == None:
            semantic_boundaries = get_semantic_bounderies(text)
        
        # Sort matches by distance to the quantity span.        
        surface_matches = sorted(surface_matches, key=lambda x: get_span_distance(x, (text_span["start"], text_span["end"]), return_abs=True))

        # Get all exact matches that are in the smallest
        # same semantic meaningful chunk as the quantity.
        for d in range(len(semantic_boundaries)-1, 0-1, -1):
            semantic_chunk_idx = max(0, bisect_left(semantic_boundaries[d], text_span["start"]) - 1)
            semantic_chunk_start_char = semantic_boundaries[d][semantic_chunk_idx]
            semantic_chunk_end_char = semantic_boundaries[d][semantic_chunk_idx + 1] if semantic_chunk_idx + 1 < len(semantic_boundaries[d]) else len(text)                                
            filted_matches = [m for m in surface_matches if is_inside(m, (semantic_chunk_start_char, semantic_chunk_end_char))]
            if any(filted_matches):
                break
                
        if len(filted_matches) == 0:
            # No matches found in the same semantic chunk.
            # Take the closest match appearing before the quantity span.
            # If all matches are after the quantity span, take the closest one.
            char_offsets = max(surface_matches, key=lambda x: x[1] if x[1] < text_span["start"] else text_span["start"]-x[0])

        else:
            # One or multiple matches in the same semantic chunk.
            # Take first or match that closest to the quantity span which happens 
            # to be also the first span, because we sorted them by distance.
            char_offsets = filted_matches[0]

    return is_implicit, char_offsets