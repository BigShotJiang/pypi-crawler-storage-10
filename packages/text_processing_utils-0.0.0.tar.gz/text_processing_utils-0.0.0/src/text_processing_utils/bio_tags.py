from collections import defaultdict


def bio_tags_to_spans(tag_sequence: list[int, str]) -> list[tuple[str, tuple[int, int]]]:
    """
    Convert a list of BIO tags for sequence labeling to spans.

    Args:
        tag_sequence: list of tuples (token_idx, tag), where tag is a BIO tag, e.g., B-PERSON, I-PERSON, O, etc.

    """ 

    for tag in set(t[1] for t in tag_sequence):
        if tag[0] not in ["B", "I", "O"]:
            raise ValueError(f"Invalid BIO tag {tag} in tag sequence.")
       
    spans = []
    span_start_tag_idx = 0    
    last_token_idx = 0
    last_tag_idx = 0
    active_label = None
    for tag_idx, (token_idx, string_tag) in enumerate(tag_sequence):

        bio_tag = string_tag[0] # B, I or O
        label = string_tag[2:] # PERSON, LOCATION, etc.     
        token_is_consecutive = token_idx == last_token_idx + 1
        span_is_ill_formed = (bio_tag == "I" and label != active_label) or not token_is_consecutive

        # If B or O or wrong I or the token is not consecutive to the last token, then end previous span.
        if active_label != None and (bio_tag == "B" or bio_tag == "O" or span_is_ill_formed):
            spans.append((active_label, (span_start_tag_idx, last_tag_idx)))

        # Reset span start and end indices.
        if bio_tag == "O":
            active_label = None
        elif bio_tag == "B" or span_is_ill_formed:
            # If B, start a new span.
            # Also, if ill-formed span, assume "B" tag is correct and start a new span.
            active_label = label
            span_start_tag_idx = tag_idx            
        else:
            # I, inside span, do nothing.
            pass

        last_token_idx = token_idx
        last_tag_idx = tag_idx

    # Add last token.
    if active_label is not None:
        spans.append((active_label, (span_start_tag_idx, tag_idx)))

    return spans


def remove_overlapping_bio_tags(bio_tags, verbose=False):
    """Remove overlapping BIO tags. Note that we only check for same start character 
    as this was case in the examples of overlapping tokens we observed.

    Not sure if overlapping BIO tags are a feature or a bug, happens with RoBERTa Tokenizer (fast) on
    "Ca = À18.4 kJ mol À1 ) and would not happen spontaneously at ambient coditions.", which yields
    [
        {'entity': 'B-Quantity', 'score': 0.9373843, 'index': 3, 'word': 'ĠÃ', 'start': 5, 'end': 6}, 
        {'entity': 'B-Quantity', 'score': 0.959601, 'index': 4, 'word': 'Ģ', 'start': 5, 'end': 6},
        ...
    ]
    """
    if len(bio_tags) < 2:
        return bio_tags
    else:
        bio_tags_no_overlap = []
        for i, token_pred in enumerate(bio_tags[:-1]):
            if token_pred["start"] != bio_tags[i+1]["start"]:
                # Keep token if it does not start with same offset as next token.
                bio_tags_no_overlap.append(token_pred)
                assert token_pred["end"] <= bio_tags[i+1]["end"] # check if assumption that second token is always equal or larger is correct.
            elif verbose:
                print(f"Warning: Overlapping BIO tags found for token {token_pred} and token {bio_tags[i+1]}.")
        
        # Add last token.
        bio_tags_no_overlap.append(bio_tags[-1])

        return bio_tags_no_overlap 
    

def transform_into_char_offsets_and_readable_tag(matches, nlp, doc, sent_offset=0):
    annotations = defaultdict(list)
    for match_id, token_start, token_end in matches:
        tag = nlp.vocab.strings[match_id]
        char_start = sent_offset + doc[token_start].idx
        char_end = sent_offset + doc[token_end - 1].idx + len(doc[token_end - 1])
        annotations[tag].append((char_start, char_end))

    return annotations


def token_spans_to_char_annotations(token_spans: list[tuple], quantity_bio_tags: list[dict], text: str) -> list[dict]:
    """Convert token spans to character spans."""
    char_level_annotations = []
    for tag, (start_token, end_token) in token_spans:
        start_char = quantity_bio_tags[start_token]["start"] 
        end_char = quantity_bio_tags[end_token]["end"]
        surface = text[start_char:end_char]
        annotation = {
            "start": start_char,
            "end": end_char,
            "text": surface
        }
        if start_char == end_char:
            print(f"Warning: Start and end character of {tag} span are the same. Skipping it.")
            print(f"{tag} span:", annotation)
            continue
        
        char_level_annotations.append(annotation)
            
    return char_level_annotations