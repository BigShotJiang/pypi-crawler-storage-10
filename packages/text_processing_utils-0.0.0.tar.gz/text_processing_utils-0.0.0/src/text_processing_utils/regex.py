
def make_named_group_unique(regex_string, group_name="thousands_seperator"):    
    """Make named groups in regular expression string unique by appending an index to the group name.
    Assumes backreferences refer to the respective previous definition of the group name.

    Args:
        regex_string (str): Regular expression string.
        group_name (str, optional): Name of the group to make unique. Defaults to "thousands_seperator".

    Returns:
        regex_string (str): Regular expression string with unique named groups.
    """    

    group_name_idx = 0
    while True:
        
        # Find the first definition and the following backreference of the group name.
        regex_string_before = regex_string
        for string in [f"<{group_name}>",f"={group_name})"]:
            char_idx = regex_string.find(string)
            if char_idx == -1:
                break    
            char_idx += len(string) - 1
            
            regex_string = regex_string[:char_idx] + "_" + f'{group_name_idx:03d}' + regex_string[char_idx:]
        
        if regex_string == regex_string_before:
            # If no more changes were made, we are done.
            break
        else:            
            group_name_idx += 1

    return regex_string