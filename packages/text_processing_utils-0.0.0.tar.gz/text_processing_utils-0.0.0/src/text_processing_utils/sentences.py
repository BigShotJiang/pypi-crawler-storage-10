from spacy.tokens.doc import Doc



def lower_first_letter_if_sent_start(annotation, text, sentence_ends = [". ", "! ", "? ", ": ", "; ", "\n\n"]):
    """
    Lower the first letter of the annotation surface, if at beginning of sentence 
    to not create example like this "Which property of Initial scans is 0.02°?".
    """
    if text[annotation["start"]].islower() or len(annotation['text']) == 1 or text[annotation["start"] + 1].isupper(): 
        # Annotation is already lower case, only a single char long, or second letter is upper case.
        annotation_surface_in_question = annotation["text"]
    elif annotation["start"] == 0 or (annotation["start"] >= 2 and text[annotation["start"]-2:annotation["start"]] in sentence_ends):
        # Lower first letter if at beginning of sentence.
        annotation_surface_in_question = annotation["text"][0].lower() + annotation["text"][1:]
    else:
        annotation_surface_in_question = annotation["text"]

    return annotation_surface_in_question


def correct_sentence_boundary_detection(doc: Doc, not_sent_ends: list=["etc.,", "figs.", "fig.", "et al.", "ref.", "eq.", "e.g.", "i.e.", "nos.", "no.", "spp."]):
    """
    The sentence boundary detection components of spaCy often split sentences at scientific abbreviations. 
    Correct those mistakes.
    """
    approved_sentences = []
    sent_start = 0
    for token in doc:
        if token.is_sent_start == True and token.i > 0:
            # Since split_into_sentences is activated, a new sentence is a new example.
            # But don't be too hasty -- the sentence tokenizer might have made a mistake here.
            # Therfore, we ensure that the text is not split at common (scientific) abbreviations.
            text_before_token = doc[0 : token.i].text
            if any(
                [text_before_token.lower().endswith(item) for item in not_sent_ends]
            ):
                # The sentence tokenizer prrobably made a mistake. Refuse to split here.
                print(
                    f'Attention: Prevented sentence segmentation at \
                    "{doc[token.i-5:token.i].text}" | "{doc[token.i:token.i+5].text}"'
                )
            else:
                # The sentence tokenizer was prrobably right. Split here!
                sent_end = token.i
                approved_sentences.append(doc[sent_start:sent_end])
                sent_start = sent_end

    return approved_sentences