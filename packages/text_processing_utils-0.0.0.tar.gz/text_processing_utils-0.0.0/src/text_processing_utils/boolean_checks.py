import spacy


nlp_for_is_plural = spacy.load("en_core_web_md", exclude=[
    # We only need "tok2vec", "tagger", "parser", "morphologizer", and "attribute_ruler",
    "ner",
    "entity_linker",
    "entity_ruler",
    "textcat",
    "textcat_multilabe",
    "lemmatizer",
    "trainable_lemmatizer",
    "senter",
    "sentencizer",
    "transformer",
])


def is_gibberish(text):
    """
    Classifies text as gibberish or not. 
    
    Note: 
        This function is based on a very particular problem 
        observed and does not generalize well.
    """
    # TODO: Make this function more general.
    if text.count(" the ") < text.count("7KH") or text.count(" a ") < text.count(" DQG "):
        return True
    else:
        return False


def is_plural(noun_phrase: str, plural_exceptions: list=['phenomena', 'memoranda', 'testes', 'lemmata', 'pupas', 'encyclopediae', 'stadia', 'succubi', 'dogmata', 'theses', 'data', 'media', 'curricula', 'radii', 'vertices', 'pupae', 'automata', 'lice', 'women', 'antennae', 'larvae', 'termini', 'alumnae', 'strata', 'geneses', 'uteri', 'indices', 'matrices', 'axes', 'spectra', 'series', 'fora', 'criteria', 'men', 'dormice', 'polyhedra', 'ova', 'anathemata', 'cacti', 'species', 'addenda', 'feet', 'geese', 'crises', 'mitochondria', 'corrigenda', 'alumni', 'corpora', 'stigmata', 'magmata', 'hippopotami', 'aurorae', 'parentheses', 'genera', 'mice', 'people', 'stomata', 'octopi', 'clitorides', 'styli', 'viscera', 'nuclei', 'formulae', 'clitorises', 'nemeses', 'teeth', 'enemata', 'millennia', 'children', 'referendums', 'syllabi', 'schemata', 'foci', 'acropoleis', 'fungi']) -> bool:
    """Check whether the given noun phrase is plural. 
    Note that there are many exceptions to plural rules in English (see https://en.wikipedia.org/wiki/English_plurals). Some exceptions are handled here by hardcoding.
    """    
    if " and " in noun_phrase or " plus " in noun_phrase or " as well as " in noun_phrase:
        # Combination of multiple entities is deemed plural.
        return True
    else:
        doc = nlp_for_is_plural(noun_phrase.strip())
        
        # Get root of the noun phrase.
        root_idx = -1 # default to last token
        for i, token in enumerate(doc):
            if token.dep_ == "ROOT":
                root_idx = i
                break        

        if "Plur" in doc[root_idx].morph.get("Number"): 
            # Last word is plural.
            return True
        elif doc[root_idx].text in plural_exceptions:
            # Last word is plural.
            return True
        else:
            # Phrase is considered singular.
            return False


def an_vs_a(
    word_following: str,
    negative_exceptions: list = ["uni", "one", "used" , "U.S." , "USA", "useless"],
    positive_exceptions: list = ["hour", "hertz", "hectare", "hectopascal", "hectoliter", "hectogram", "hecto", "honorable", "honest", "s.", "f.", "m.", "n.", "r."],
    ) -> bool:
    """
    Whether to use "a" or "an" before the given word.

    Args:
        word_following (str): The word that follows "a" or "an".
        negative_exceptions (list): List of words that should not be preceded by "an" even if they start with a vowel.
        positive_exceptions (list): List of words that should be preceded by "an" even if they do not start with a vowel.
    
    Returns:
        bool: True if "an" should be used, False if "a" should be used.

    """
    if (word_following[0] in "aeiou" and not any(word_following.startswith(e) for e in negative_exceptions)):
        # If the first letter is a vowel and not in negative exceptions, use "an".
        return True
    elif any(word_following.startswith(e) for e in positive_exceptions):
        # If the word starts with a positive exception, use "an".
        return True
    elif word_following in ["s", "f", "m", "n", "r"]:
        # If the word is one of these letters, use "an".
        return True
    else:
        # Otherwise, use "a".
        return False