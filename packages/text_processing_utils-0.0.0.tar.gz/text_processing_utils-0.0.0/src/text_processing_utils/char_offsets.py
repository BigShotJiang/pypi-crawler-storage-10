from collections import defaultdict
from typing import Union
from text_processing_utils.types import Offset



is_inside = lambda a, b: a[0] >= b[0] and a[1] <= b[1]  # Answers if a is inside b

get_span_distance_sorted = lambda before, behind: behind[0] - before[1]


def get_span_distance(a: Offset, b: Offset, return_abs=False) -> int:
    """
    Get distance between two spans.
    If spans overlap, distance is negative.
    Args:
        a (Offset): First span as (start, end).
        b (Offset): Second span as (start, end).
    """    
    span_dist = [-1, 1][a[0] - b[1] < 0] * max(a[0] - b[1], b[0] - a[1])    
    return abs(span_dist) if return_abs else span_dist


def remove_whitespace_from_annotation(surface: str, start: int, end: int):
    """Get char offsets without leading or trailing whitespace."""
    surface_length = len(surface)
    leading_whitespace_offset = surface_length - len(surface.lstrip(" "))
    trailing_whitespace_offset = surface_length - len(surface.rstrip(" "))
    start = start + leading_whitespace_offset
    end = end - trailing_whitespace_offset

    return start, end


def merge_annotation_offsets(
    annotations: Union[list[Offset], list[list[int, int]]],
    adjecent_dist_threshold=2,    
    condition = lambda x,y: True
) -> Union[list[Offset], list[list[int, int]]]:
    """Merge overlapping annotation offsets.

    Offsets can be given as an list of lists or tuples
    (e.g., [[14, 25], [17, 26], [30, 40], ... ]
     or    [(14, 25), (17, 26), (30, 40), ... ])

    The code for merging overlapping offsets was
    adapted from https://stackoverflow.com/a/43600953.
    """
    merged_annotations = defaultdict(list)
    for key, offsets in annotations.items():
        if len(offsets) == 0:
            # Handle empty input.
            merged_offsets = offsets
        else:
            # If list items are tuples, convert them to lists.
            tuple_list = type(offsets[0]) == tuple
            if tuple_list:
                offsets = [list(t) for t in offsets]

            # Merge overlapping offsets
            offsets.sort(key=lambda offset: offset[0])
            merged_offsets = [offsets[0]]
            for current_offs in offsets:
                previous_offs = merged_offsets[-1]
                
                is_overlapping = current_offs[0] <= previous_offs[1]
                is_adjecent = (current_offs[0] - previous_offs[1]) < adjecent_dist_threshold                

                if is_overlapping or is_adjecent and condition(current_offs[0], previous_offs[1]):
                    # Some magic: Changing previous_offs also changes
                    # merged_offsets, since in Python assignment statements
                    # do not copy objects but create bindings.
                    previous_offs[1] = max(previous_offs[1], current_offs[1])
                else:
                    merged_offsets.append(current_offs)

            # Convert back to list of tuples if tuples were given.
            if tuple_list:
                merged_offsets = [tuple(l) for l in merged_offsets]

        merged_annotations[key] = merged_offsets

    return merged_annotations