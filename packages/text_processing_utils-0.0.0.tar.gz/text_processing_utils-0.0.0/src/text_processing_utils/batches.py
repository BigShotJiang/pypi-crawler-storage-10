import math


def get_batches_of_strict_size_with_remainder(dataset: list, batch_size: int) -> list[list]:
    """
    Split list into batches of size batch_size. 
    The last batch may be smaller if the length of dataset
    is not a multiple of batch_size.

    Example: 
        dataset = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        batch_size = 4
        create_chunks(dataset, batch_size)
        >> [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10]]

    """
    chunks = [dataset[i : i + batch_size] for i in range(0, len(dataset), batch_size)]
    assert sum(len(c) for c in chunks) == len(dataset)
    return chunks


def get_n_batches(dataset: list, n: int) -> list[list]:
    """
    Split list into n roughly equally sized batches.

    Example:
        dataset = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        n = 3
        get_n_batches(dataset, n)
        >> [[1, 2, 3, 4], [5, 6, 7], [8, 9, 10]]
    """    
    n_regular_batches, remainder = divmod(len(dataset), n)
    batches = [dataset[i*n_regular_batches+min(i, remainder):(i+1)*n_regular_batches+min(i+1, remainder)] for i in range(n)]
    assert len(dataset) == sum(len(batch) for batch in batches)
    return batches


def get_batches_of_roughly_equal_size(dataset: list, max_batch_size: int) -> list[list]:
    """
    Split list into batches of size max_batch_size.    
    If the last batch would be much smaller, then all batches
    are made smaller to roughly have the same size.

    Example:
        dataset = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        max_batch_size = 4
        get_batches(dataset, max_batch_size)
        >> [[1, 2, 3, 4], [5, 6, 7], [8, 9, 10]]

    """
    n_batches = math.ceil(len(dataset) / max_batch_size)    
    batches = get_n_batches(dataset, n_batches)    
    assert len(dataset) == sum(len(batch) for batch in batches)
    return batches




