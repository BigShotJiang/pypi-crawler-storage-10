"""
Infosourceful Kernel - Shared models, JSON Schemas, and CLI validator.

This package provides the core domain models, JSON schemas, and validation
utilities for the Infosourceful ecosystem.
"""

__version__ = "1.0.0"
