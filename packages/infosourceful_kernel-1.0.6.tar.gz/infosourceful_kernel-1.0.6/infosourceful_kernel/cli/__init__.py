"""
CLI module for Infosourceful Kernel.
"""
