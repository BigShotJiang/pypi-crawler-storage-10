"""Contain widgets used in the notebook app."""
