"""An interactive jupyter console with rich output."""
