"""Module providing integration between Benchmax environment and SkyRL Gym via Ray actors."""

from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Type, TypeVar, Union, cast
import uuid
from omegaconf import DictConfig
import ray
from skyrl_gym import Env
from skyrl_gym.envs.base_text_env import (
    BaseTextEnv,
    BaseTextEnvStepOutput,
    ConversationType,
)
from ray.actor import ActorProxy

from benchmax.adapters.benchmax_wrapper import BenchmaxEnv, BenchmaxEnvActor, BenchmaxEnvWrapper
from benchmax.envs.base_env import BaseEnv
from benchmax.prompts.tools import parse_hermes_tool_call

# Main entrypoint to load benchmax in SkyRL Gym
def load_benchmax_env_skyrl(actor: ActorProxy[BenchmaxEnv], **kwargs) -> Env[str, str]:
    """
    Factory function to create a SkyRL Gym environment that wraps a Benchmax task via a Ray actor.

    Parameters:
        actor (ActorProxy[BenchmaxEnv]): Ray actor proxy for the Benchmax environment
        **kwargs: Additional keyword arguments passed to BenchmaxSkyRLEnv, including:
            - env_config (DictConfig): Configuration passed by SkyRL Gym
            - extras (Dict[str, Any]): Additional parameters such as:
                - max_turns (int): Maximum dialogue turns before forcing termination (default: 4)
                - init_rollout_args (dict): Arguments to initialize the rollout in the remote actor
                - task (str): Name/identifier of the Benchmax task
                - ground_truth (Any): Ground truth data for reward computation

    Returns:
        BenchmaxSkyRLEnv: A BaseTextEnv-compatible environment.
    """
    return BenchmaxSkyRLEnv(actor=actor, **kwargs)


class BenchmaxSkyRLEnv(BaseTextEnv):
    """
    Text-based RL environment integrating Benchmax via a remote Ray actor.
    Inherits from BaseTextEnv and operates on string-based observations/actions.
    """

    def __init__(
        self,
        actor: ActorProxy[BenchmaxEnv],
        env_config: DictConfig,
        extras: Dict[str, Any] = {},
    ):
        """
        Initialize the BenchmaxSkyRLEnv.

        Args:
            actor (ActorProxy[BenchmaxEnv]): Ray actor proxy for Benchmax environment
            env_config (DictConfig): Configuration passed by SkyRL Gym.
            extras (Dict[str, Any]): Additional parameters, including:
                - max_turns (int): Maximum dialogue turns before forcing termination (default: 4).
                - init_rollout_args (dict): Arguments to initialize the rollout in the remote actor.
                - task (str): Name/identifier of the Benchmax task.
                - ground_truth (Any): Ground truth data for reward computation.
        """
        self.turns = 0
        self.max_turns = extras.get("max_turns", 4)
        self.extras = extras
        self.chat_history: ConversationType = []
        self.rollout_id = uuid.uuid4().hex
        self.benchmax_env = BenchmaxEnvWrapper(actor)
        # Init rollout
        init_rollout_args = extras.get("init_rollout_args") or {}
        self.benchmax_env.init_rollout_sync(**init_rollout_args)

    def _get_reward(self, action: str) -> float:
        """
        Compute total reward by summing the values returned from the remote Benchmax actor.

        Args:
            action (str): The final text action or answer.

        Returns:
            float: Sum of reward components.
        """
        reward_dict = self.benchmax_env.compute_reward_sync(
            self.extras["task"], action, self.extras["ground_truth"]
        )
        return sum(reward_dict.values())

    def _call_tool(self, tool_call: dict, max_chars: int = 10000) -> str:
        """
        Execute a parsed tool call via the remote Benchmax actor and return its string output.

        Args:
            tool_call (dict): Dictionary with 'name' and 'arguments' keys.
            max_chars (int): Maximum length of the returned string (truncated if exceeded).

        Returns:
            str: The tool output or an error message.
        """
        try:
            if not isinstance(tool_call, dict):
                return "Error: Tool command must be a JSON object."

            tool_name = tool_call.get("name")
            if not tool_name:
                return "Error: Missing 'name' field in tool command."

            args = tool_call.get("arguments", {})
            if not isinstance(args, dict):
                return f"Error: 'arguments' for {tool_name} must be a JSON object."

            result = self.benchmax_env.run_tool_sync(tool_name, **args)
            result_str = str(result)
            if 0 < max_chars < len(result_str):
                result_str = result_str[:max_chars] + "..."
            return result_str
        except Exception as exc:
            return f"Error: {exc}"

    def step(self, action: str) -> BaseTextEnvStepOutput:
        """
        Process one step of the RL environment: parse tool calls or finalize with reward.

        Args:
            action (str): The assistant's text output.

        Returns:
            BaseTextEnvStepOutput: Contains new observations, reward, done flag, and metadata.
        """
        self.turns += 1
        self.chat_history.append({"role": "assistant", "content": action})
        tool_calls = parse_hermes_tool_call(action)
        error = None
        done = not tool_calls
        reward = 0.0

        if done:
            reward = self._get_reward(action)
            return BaseTextEnvStepOutput(
                observations=[],
                reward=reward,
                done=done,
                metadata={},
                postprocessed_action=action,
            )

        # Only first tool call is executed
        try:
            tool_call = tool_calls[0]
            observation = self._call_tool(tool_call)
        except Exception as e:
            error = str(e)
            observation = None

        # Wrap the observation as a user message or error
        if observation:
            new_obs = {"role": "user", "content": observation}
        elif error:
            new_obs = {"role": "user", "content": error}
        else:
            new_obs = None

        if new_obs:
            self.chat_history.append(new_obs)

        return BaseTextEnvStepOutput(
            observations=[new_obs] if new_obs else [],
            reward=reward,
            done=done,
            metadata={},
            postprocessed_action=action,
        )


T = TypeVar('T', bound=BaseEnv)

def get_or_create_benchmax_env_actor(
    env_cls: Type[T],
    env_kwargs: Optional[Dict[str, Any]] = None,
    actor_name: str = "BenchmaxEnvService",
    num_cpus: int = 3
) -> ActorProxy[BenchmaxEnv]:
    """
    Create the benchmax BaseEnv actor if not already running, or return the existing one.

    Args:
        env_cls: The benchmax BaseEnv subclass to wrap (e.g., MathEnv).
        env_kwargs: Keyword args to pass to the env constructor.
        actor_name: Name of the actor in the Ray namespace.
        num_cpus: Number of CPUs to allocate to the actor.

    Returns:
        A handle to the BaseEnv actor.
    """
    try:
        return ray.get_actor(actor_name)
    except ValueError:
        # Create a new detached actor
        return cast(
            ActorProxy[BenchmaxEnv],
            BenchmaxEnvActor.options(
                name=actor_name,
                lifetime="detached",
                get_if_exists=True,
                num_cpus=num_cpus
            ).remote(env_cls, env_kwargs or {})
        )

def cleanup_actor(actor: Optional[ActorProxy[BenchmaxEnv]]) -> None:
    """Shutdown and kill a benchmax actor."""
    if actor is None:
        return
    
    try:
        obj_ref: ray.ObjectRef[Any] = actor.shutdown.remote()
        ray.get(obj_ref, timeout=20)
    except Exception as e:
        print(f'Actor shutdown failed: {e}')
    
    try:
        ray.kill(actor)
    except Exception as e:
        print(f'Actor kill failed: {e}')