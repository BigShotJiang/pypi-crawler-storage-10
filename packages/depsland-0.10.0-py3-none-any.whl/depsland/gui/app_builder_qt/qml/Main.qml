import QtQuick
import LKWidgets

LKWindow {
    width: 860
    height: 1200

    Item {
        anchors {
            fill: parent
            margins: 12
        }

        LKColumn {
            anchors.fill: parent

            component FolderNode: LKRectangle {
                ...
            }
        }
    }
}
