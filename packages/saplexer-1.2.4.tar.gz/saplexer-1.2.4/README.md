# saplexer

A simple and efficient Python package that displays the contents of text files stored in internal folders `a` and `b`.

## Installation

```bash
pip install saplexer

