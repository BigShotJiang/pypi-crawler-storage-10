# libpq

A useful Python package with utility functions.

## Installation

```bash
pip install libpq
```

## Usage

```python
import libpq

print(libpq.hello_world())
result = libpq.add_numbers(5, 3)
print(result)
```
