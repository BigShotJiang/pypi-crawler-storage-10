# SPDX-FileCopyrightText: 2025 led-inc.eu
# SPDX-FileContributor: Michael Meinel <led02@me.com>
#
# SPDX-License-Identifier: Apache-2.0

class SignatureVerificationError(ValueError):
    """ Raised when the signature could not be verified. """
    pass


class ModuleFormatException(Exception):
    """ Raised when parsing an encrypted module failed. """
    pass


class DecryptionError(Exception):
    """ Raised when decryption of encrypted module data failed. """
    pass

__signature__ = "MGYCMQCiHT2azqHRgjbs9BlagBhnQM8M1hdVc/lxfWE5Eqj7lLlxv0eIp8HeIFn8UcplMT8CMQCOOYzhMwbwZukAI/L/lj2MalaRrNWTrpLNAm6K8F9F9aFLaAhUkdxl8sedgJNJLhk="
