# SPDX-FileCopyrightText: 2025 led-inc.eu
# SPDX-FileContributor: Michael Meinel <led02@me.com>
#
# SPDX-License-Identifier: Apache-2.0

import base64
import secrets
import typing


class SymmetricKey:
    def __init__(self, key: bytes, *, tag: str | None = None, derived_from: typing.Any = None):
        self._key = key
        self.tag = tag
        self.derived_from = derived_from

    def __eq__(self, other: typing.Self) -> bool:
        return self._key == other._key

    @property
    def key(self) -> bytes:
        return self._key

    @property
    def b64bytes(self) -> bytes:
        return base64.b64encode(self.key)

    @property
    def hexstr(self) -> str:
        return self.key.hex('-', 4)


class Nonce(SymmetricKey):
    def __init__(self, *, tag: str | None = None, length: int = 12):
        super().__init__(secrets.token_bytes(length), tag=tag)

__signature__ = "MGYCMQDVgx5og/7xiVhcCa12Qbi4obwMbUre8hr3S0rwlBe4Jso/Kfv9HafN33LF/A1DA54CMQCIOlRfUK09TR8wZZkLNuq4R2PkzH3QWUPFPzB1nli9fbXS/iH6QSIaI7RPLuePCjA="
