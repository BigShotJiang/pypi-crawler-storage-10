# SPDX-FileCopyrightText: 2025 led-inc.eu
# SPDX-FileContributor: Michael Meinel <led02@me.com>
#
# SPDX-License-Identifier: Apache-2.0

from dongle.lib.primitives import SymmetricKey


def get_cipher(secret: SymmetricKey):
    from cryptography.hazmat.primitives.ciphers import aead

    return aead.AESGCM(secret.key)


def decrypt_data(secret: SymmetricKey, nonce: SymmetricKey, encrypted_data: bytes, tag: SymmetricKey) -> bytes:
    return get_cipher(secret).decrypt(nonce.key, encrypted_data, tag.key)

__signature__ = "MGYCMQDYPGmF+2NfnaiUdRimHEO3eaQWtYJHqrohG2oouiZzIXU8JlQmDlKMkq1yNokleG8CMQDr6oxudg0MpAJ0abT9jlNk2BNk3LOax3vPehTqPESqQoA9PJJo7ADpK994yBrOQ5U="
