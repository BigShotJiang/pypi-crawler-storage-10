# SPDX-FileCopyrightText: 2025 led-inc.eu
# SPDX-FileContributor: Michael Meinel <led02@me.com>
#
# SPDX-License-Identifier: Apache-2.0

__signature__ = "MGYCMQDKEbe9sZbfuHz+1hSuiainQjaAaJDLheD/Dz7pAsqYOyWgIN4Lwf62vDw6ylocQs4CMQDhCH5gcDunLVP5fTxmEMBJciAHZT/8EjuiBOmXXQkPfKO3dxPRlqqsBXD3g/oPR/Q="
