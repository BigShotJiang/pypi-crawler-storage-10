# SPDX-FileCopyrightText: 2025 led-inc.eu
# SPDX-FileContributor: Michael Meinel <led02@me.com>
#
# SPDX-License-Identifier: Apache-2.0

import sys


def main():
    from dongle.util.commands import cli

    cli()



if __name__ == '__main__':
    import dongle

    try:
        module = dongle.init_from(__name__)

    except dongle.DongleReady as e:
        module = e.reload()

    finally:
        module.main()

__signature__ = "MGUCMHesfRQu1Q5gcHy3lPm7Bc5hrEtCYpb/E6RFfd9dtnVqHzg0KQut6GMAkXBQ0bvPDAIxANcFo1jDCuKZHBeMk+E7HCvhuneLl232BqW2z5ak5YIthdIbU3cM9QH+605jqhMLoQ=="
