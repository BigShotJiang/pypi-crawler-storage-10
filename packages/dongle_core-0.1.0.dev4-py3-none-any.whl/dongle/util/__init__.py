# SPDX-FileCopyrightText: 2025 led-inc.eu
# SPDX-FileContributor: Michael Meinel <led02@me.com>
#
# SPDX-License-Identifier: Apache-2.0

__signature__ = "MGUCMBfSbAdXGlCX4q/zPHl5AV1UDcPY6rsd2p+uDMTEbdoETaxyPyFfMswRbSTZCDwgEQIxANJP4Ur65CAuqN135D2dopVUtiOQqN56dOTsnnv8jd+K3Rlylq1JzI3/Vd6dt/9EhA=="
