# SPDX-FileCopyrightText: 2025 led-inc.eu
# SPDX-FileContributor: Michael Meinel <led02@me.com>
#
# SPDX-License-Identifier: Apache-2.0

from dongle.runtime import init_from
from dongle.runtime.machinery import DongleReady

__signature__ = "MGYCMQClqnxXdqrWOdB8r/4VUPka+iosUcSsE+X5pg6UQGB6qdSpyhbMYXju+Lg7F6cfQ0oCMQCTSeD1Im1WCO3PUJnhEMbapaGqSlR+YBLF4uE4Qi8lQGP7WKh7mt4iSSggmSb11Y8="
