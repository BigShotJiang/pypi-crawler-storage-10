# SPDX-FileCopyrightText: 2025 led-inc.eu
# SPDX-FileContributor: Michael Meinel <led02@me.com>
#
# SPDX-License-Identifier: Apache-2.0

class DongleReady(ImportError):
    """ Raised by dongle.init_from when the runtime was initialized. """
    pass


class MissingDongle(RuntimeError):
    """ Raised when a module is checked but has no dongle. """
    pass


class NoLicenseError(RuntimeError):
    """ Raised when a module is loaded without a valid license. """
    pass


class InvalidProof(Exception):
    """ Raised when the proof for a given module could not be verified. """
    pass

__signature__ = "MGYCMQDr6Hp2Jc0+W2R18xq+fcsJbHbGG/ABOm9OY5GYg4qPNQXVNbkfYK1tXSFKKg4ZbwUCMQCKKa0Nbmk2aE4Z+xZY1QT0/5wjBXCX82LeniQy7AQr4IFhEpgUHwGhhipZRt64CfQ="
