# This package is controlled by dongle license manager.

vendor_name = "led-inc.eu"
build_name = "dongle-core-dev"
app_name = "dongle-core"
app_key = b"""
-----BEGIN PUBLIC KEY-----
MHYwEAYHKoZIzj0CAQYFK4EEACIDYgAE8NF3Cy8rYKwyiNFFVXG9VUKN+IroRvLz
4UGMEzKxX5YA+xtk1gqHluSYpdO8BQCf1G6Bk+g1aGR/9Rgs/gVczojJIIq9JRBh
f3yPw2LdyqGQpG4rPoWc1InNt8N6uolU
-----END PUBLIC KEY-----

"""

hooks = [
    {'scope': 'dongle', 'use': 'dongle.runtime'},
]

__signature__ = "MGQCMF1P4BHHDmYe7smZa6Osww6o3pDsTGC8Nd9L/VMvcxWKYMBaJ0EVuWmbHWc+g5HXIQIwQjwnHoFwiJuAgo10oFQhtxnta+yqe9h2KRWve5NeuuCFYKV+VxYZX+qKwTr4nyaz"
