from ua_datasets.text_classification.news_classification import NewsClassificationDataset

__all__ = ["NewsClassificationDataset"]
