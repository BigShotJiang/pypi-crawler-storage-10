from ua_datasets.token_classification.part_of_speech import MovaInstitutePOSDataset

__all__ = ["MovaInstitutePOSDataset"]
