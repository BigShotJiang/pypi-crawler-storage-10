from ua_datasets.question_answering import UaSquadDataset
from ua_datasets.text_classification import NewsClassificationDataset
from ua_datasets.token_classification import MovaInstitutePOSDataset

__all__ = [
    "MovaInstitutePOSDataset",
    "NewsClassificationDataset",
    "UaSquadDataset",
]
