import irc.client
import irc.connection
import ssl

class Bot:
    def __init__(self, server, nick):
        self.server, self.port = server.split(":")
        self.port = int(self.port)
        self.nick = nick
        self.commands = {}
        self.cmd_prefix = "&"
        self.last_target = None
        self.channel = "#test"

    def add_command(self, name, func):
        self.commands[name] = func

    def send(self, msg, target=None):
        if target is None:
            target = self.last_target
        self.conn.privmsg(target, msg)

    def _on_connect(self, connection, event):
        connection.join(self.channel)

    def _on_msg(self, connection, event):
        self.last_target = event.target
        msg = event.arguments[0]
        if msg.startswith(self.cmd_prefix):
            parts = msg[len(self.cmd_prefix):].split()
            if not parts:
                return
            cmd, *args = parts
            if cmd in self.commands:
                try:
                    self.commands[cmd](*args)
                except Exception as e:
                    self.send(f"Error: {e}", self.last_target)

    def start(self, channel="#test", use_ssl=False):
        self.channel = channel
        if use_ssl:
            context = ssl.create_default_context()
            factory = irc.connection.Factory(wrapper=irc.connection.ssl.wrap_socket, ssl_context=context)
        else:
            factory = irc.connection.Factory()
        self.reactor = irc.client.Reactor()
        self.conn = self.reactor.server().connect(
            self.server, self.port, self.nick, connect_factory=factory
        )
        self.conn.add_global_handler("welcome", self._on_connect)
        self.conn.add_global_handler("pubmsg", self._on_msg)
        self.conn.add_global_handler("privmsg", self._on_msg)
        print(f"Bot {self.nick} connecting to {self.server}:{self.port}...")
        self.reactor.process_forever()
