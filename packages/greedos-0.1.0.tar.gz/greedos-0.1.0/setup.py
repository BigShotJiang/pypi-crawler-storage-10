import shutil
from setuptools import setup, find_packages
if not shutil.which("tcpreplay"):
    print(
        "\n[WARNING] 'tcpreplay' is not installed! "
        "If using Linux then Install it with: sudo apt install tcpreplay\n"
        "If using Windows then Install it manually\n"
    )
setup(
    name="greedos",
    version="0.1.0",
    description="Advanced Cybersecurity Red Team Tool",
    author="MrEchoFi_EbwerBrothers",
    packages=find_packages(),
    install_requires=[
        "requests",
        "rich",
        "scapy",
    ],
    entry_points={
        "console_scripts": [
            "greedos=greedos.GreeDoS_ii:main_menu"
        ]
    },
    python_requires=">=3.7",
)
