from duck_domain.django_tools.soft_delete.soft_delete_django_repository import (
    SoftDeleteDjangoRepository,
)
from duck_domain.django_tools.soft_delete.soft_delete_model import SoftDeleteModel

__all__ = ["SoftDeleteDjangoRepository", "SoftDeleteModel"]
