from enum import Enum


class InputWrapper(Enum):
    INPUT_DOC = "input_doc"
    INPUT_DF = "input_df"
    INPUT_TRUE = "input_true"
