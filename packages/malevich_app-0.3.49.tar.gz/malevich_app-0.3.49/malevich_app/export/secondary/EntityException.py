class EntityException(Exception):
    pass


LOAD_COLLECTION_FAIL_MSG = "load collection"
