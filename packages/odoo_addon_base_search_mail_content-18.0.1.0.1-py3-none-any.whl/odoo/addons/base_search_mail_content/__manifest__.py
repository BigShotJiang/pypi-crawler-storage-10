# Copyright 2016 ForgeFlow S.L.
#   (http://www.forgeflow.com)
# Copyright 2016 Serpent Consulting Services Pvt. Ltd.
#   (<http://www.serpentcs.com>)
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).

{
    "name": "Base Search Mail Content",
    "version": "18.0.1.0.1",
    "author": "ForgeFlow, SerpentCS, Tecnativa, Odoo Community Association (OCA)",
    "website": "https://github.com/OCA/mail",
    "category": "Social",
    "depends": ["mail", "base_search_fuzzy"],
    "license": "AGPL-3",
    "installable": True,
}
