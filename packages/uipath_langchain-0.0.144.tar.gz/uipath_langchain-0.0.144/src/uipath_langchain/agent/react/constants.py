# Agent routing configuration
MAX_SUCCESSIVE_COMPLETIONS = 1
