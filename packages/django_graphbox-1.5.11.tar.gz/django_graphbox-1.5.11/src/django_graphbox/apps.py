from django.apps import AppConfig

class DjangoGraphboxConfig(AppConfig):
    name = 'django_graphbox'
    default_auto_field = 'django.db.models.AutoField'