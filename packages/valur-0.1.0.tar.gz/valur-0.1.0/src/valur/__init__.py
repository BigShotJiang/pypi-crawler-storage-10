def main() -> None:
    print("Hello from valur!")
