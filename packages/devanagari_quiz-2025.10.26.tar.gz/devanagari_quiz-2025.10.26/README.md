# Devanagari Quiz

A simple command line Devanagari quiz game for Sanskrit students

# Installation

-Install Python if you don't have it yet, see www.python.org/downloads

-Install devanagari_quiz with pip or from pypi.org/devanagari_quiz

# Usage

Run it by typing devanagari

# License

This project is licensed under the [GNU AGPLv3 License](LICENSE)

# Changelog

calver YYYY.MM.DD

v2025.10.26 A simple command line Devanagari to Latin quiz
