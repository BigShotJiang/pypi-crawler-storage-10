# src/devanagari_quiz/utils.py
#def start_quiz():

#print("Hello from utils.py")



quiz_data = {

    # Vowels (स्वराः)
    "अ": "a",
    "आ": "ā",
    "इ": "i",
    "ई": "ī",
    "उ": "u",
    "ऊ": "ū",
    "ऋ": "ṛ",
    "ॠ": "ṝ",
    "ऌ": "ḷ",
    "ॡ": "ḹ",
    "ए": "e",
    "ऐ": "ai",
    "ओ": "o",
    "औ": "au",
    "अं": "aṁ",  # Anusvāra
    "अः": "aḥ",  # Visarga

    # Gutturals (कण्ठ्य)
    "क": "ka",
    "ख": "kha",
    "ग": "ga",
    "घ": "gha",
    "ङ": "ṅa",

    # Palatals (तालव्य)
    "च": "ca",
    "छ": "cha",
    "ज": "ja",
    "झ": "jha",
    "ञ": "ña",

    # Retroflexes (मूर्धन्य)
    "ट": "ṭa",
    "ठ": "ṭha",
    "ड": "ḍa",
    "ढ": "ḍha",
    "ण": "ṇa",

    # Dentals (दन्त्य)
    "त": "ta",
    "थ": "tha",
    "द": "da",
    "ध": "dha",
    "न": "na",

    # Labials (ओष्ठ्य)
    "प": "pa",
    "फ": "pha",
    "ब": "ba",
    "भ": "bha",
    "म": "ma",

    # Semivowels (अन्तःस्थ)
    "य": "ya",
    "र": "ra",
    "ल": "la",
    "व": "va",

    # Sibilants and Aspirate (उष्म)
    "श": "śa",
    "ष": "ṣa",
    "स": "sa",
    "ह": "ha",
}
