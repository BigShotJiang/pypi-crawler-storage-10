"""AutoCron version information."""

__version__ = "1.0.1"
__author__ = "MD Shoaib Uddin Chanda"
__email__ = "mdshoaibuddinchanda@gmail.com"
__license__ = "MIT"
__description__ = "Automate scripts with zero setup. Run Python tasks anytime, anywhere."
