"""
AutoCron - Automate scripts with zero setup.
Legacy setup.py for backward compatibility.
Modern configuration is in pyproject.toml.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
