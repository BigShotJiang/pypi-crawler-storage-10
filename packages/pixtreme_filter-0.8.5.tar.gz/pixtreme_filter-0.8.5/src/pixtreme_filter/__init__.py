"""pixtreme-filter: GPU-accelerated image filtering operations"""

__version__ = "0.8.5"

from .bilateral import bilateral_filter
from .box import box_blur
from .gaussian import GaussianBlur, gaussian_blur, get_gaussian_kernel
from .median import median_blur
from .morphology import (
    create_dilate_kernel,
    create_erode_kernel,
    dilate,
    erode,
    morphology_close,
    morphology_gradient,
    morphology_open,
)
from .sobel import sobel
from .unsharp import unsharp_mask

__all__ = [
    "bilateral_filter",
    "box_blur",
    "GaussianBlur",
    "gaussian_blur",
    "get_gaussian_kernel",
    "erode",
    "create_erode_kernel",
    "dilate",
    "create_dilate_kernel",
    "median_blur",
    "morphology_open",
    "morphology_close",
    "morphology_gradient",
    "sobel",
    "unsharp_mask",
]
