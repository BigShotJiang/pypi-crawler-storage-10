import pandas as pd

class Block:
    def __init__(self, name: str, data: dict[str, pd.DataFrame]):
        self.name = name
        self.registries = data

    def get_registry(self, registry: str) -> pd.DataFrame:
        return self.registries[registry]

    def __getitem__(self, registry: str) -> pd.DataFrame:
        """ Allow for dictionary stryle access. """
        return self.registries[registry]

    def __repr__(self) -> str:
        return f"Block(name={self.name}, registries={list(self.registries.keys())})"

class Sped:
    def __init__(self):
        self.blocks: dict[str, Block] = {}

    def add_block(self, block: Block) -> None:
        self.blocks[block.name] = block

    def get_block(self, name: str):
        return self.blocks[name]

    def is_valid(self):
        # TODO Check documentation for comprehensive list of mandatory columns.
        mandatory_columns = {"reg", "cnpj", "ind_oper", "ind_emit", "cod_part",
                            "cod_mod", "cod_sit", "num_doc", "dt_doc", "vl_doc", "ind_pgto", "ind_frt",
                            "num_item", "cod_item", "vl_item", "cfop", "cst_pis", "cst_cofins", "vl_opr",
                            "cst_pis", "vl_pis", "vl_cofins", "cod_inf", "num_proc", "ind_proc", "cod_doc_imp",
                            "num_doc_imp", "cod_mod", "dt_doc_ini", "dt_doc_fin", "cod_item", "vl_tot_item",
                            "num_proc", "ind_proc", "dt_ref_ini", "dt_ref_fin", "cst_pis", "vl_doc_canc"}
        for block in self.blocks:
            for registry in self.blocks[block].registries:
                # This provides an intersection between the dataframe columns and the mandatory columns.
                columns_to_verify = set(self.blocks[block].registries[registry].columns) & mandatory_columns
                for column in columns_to_verify:
                    if '' in self.blocks[block].registries[registry][column]:
                        return False
        return True

    def __getitem__(self, name: str) -> Block:
        return self.blocks[name]

    def __repr__(self) -> str:
        return f"Sped(blocks={list(self.blocks.keys())})"
