print('i am saimon islam tarek')

from .first_module import addition
from .second_variable import variable2
from .third_module import tarek






