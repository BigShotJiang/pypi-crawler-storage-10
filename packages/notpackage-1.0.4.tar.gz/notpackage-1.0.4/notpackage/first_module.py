def addition():
    x=12
    y=13
    return x+y


variable='hello i am variable'
