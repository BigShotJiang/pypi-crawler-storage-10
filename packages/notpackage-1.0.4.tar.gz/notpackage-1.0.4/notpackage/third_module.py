def tarek():
    a=34
    b=25
    return a+b+10


