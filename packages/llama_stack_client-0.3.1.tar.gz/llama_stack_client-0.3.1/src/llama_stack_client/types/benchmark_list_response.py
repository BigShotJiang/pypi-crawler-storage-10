# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the terms described in the LICENSE file in
# the root directory of this source tree.

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import TypeAlias

from .benchmark import Benchmark

__all__ = ["BenchmarkListResponse"]

BenchmarkListResponse: TypeAlias = List[Benchmark]
