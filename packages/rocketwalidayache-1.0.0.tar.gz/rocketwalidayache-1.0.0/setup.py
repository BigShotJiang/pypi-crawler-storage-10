from setuptools import setup

setup(
   name='rocketwalidayache',
   version='1.0.0',
   author='Abdelkrim Zitouni',
   author_email='wayache9@gmail;com',
   packages=['rocketwalid'],
   url='http://pypi.python.org/pypi/<your_package_name>/',
   license='LICENSE.txt',
   description='An awesome package that creates a rocket',
   long_description=open('README.md').read(),
   long_description_content_type="text/markdown",
   install_requires=['rocketwalid']
)