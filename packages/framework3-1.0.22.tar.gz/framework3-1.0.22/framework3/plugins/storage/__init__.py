from framework3.plugins.storage.local_storage import LocalStorage
from framework3.plugins.storage.s3_storage import S3Storage

__all__ = ["LocalStorage", "S3Storage"]
