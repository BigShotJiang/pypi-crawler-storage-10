#!/usr/bin/env python3
"""
Operator Registry Example - Demonstrates how to use the Operator Registry from nexstem-registry-stack
This example shows how to manage operators in the registry
"""

import asyncio

# Import strictly from the installed PyPI package
from nexstem_registry_stack import (
    OperatorRegistry,
    OperatorListOptions,
    OperatorInstallOptions,
    OperatorInfoOptions,
)

print("📦 Operator Registry Example - nexstem-registry-stack")
print("=" * 55)

async def operator_registry_example():
    """Test Operator Registry methods like in Node.js SDK"""
    print("🧪 Testing Operator Registry Methods - nexstem-registry-stack")
    print("=" * 60)
    
    try:
        # Initialize Operator Registry (like Node.js SDK)
        print("\n1️⃣ Initializing Operator Registry...")
        operator_registry = OperatorRegistry({})
        print("✅ Operator Registry created successfully")
        
        # Initialize bridge
        print("\n2️⃣ Initializing native bridge...")
        await operator_registry.initialize()
        print("✅ Operator Registry initialized successfully")
        
        # List remote operators
        print("\n3️⃣ Listing remote operators...")
        list_result = await operator_registry.list(OperatorListOptions(remote=True))
        print(f"✅ Remote operators listed. Count: {getattr(getattr(list_result, 'data', None), 'count', 0)}")
        
        # List versions for selected operators
        operator_names = ["signalgenerator", "websocket", "fft", "firfilter"]
        versions_by_operator: dict[str, list[str]] = {}
        for name in operator_names:
            print(f"\n4️⃣ Listing versions for operator '{name}'...")
        try:
                res = await operator_registry.list(OperatorListOptions(remote=True, operator=name, versions=True))
                versions = getattr(getattr(res, 'data', None), 'versions', []) or []
                versions_by_operator[name] = versions
                print(f"✅ Versions for {name}: {', '.join(versions) if versions else '(none)'}")
        except Exception as e:
                versions_by_operator[name] = []
                print(f"⚠️  Failed to list versions for {name}: {e}")
        
        # Install latest version for each
        print("\n5️⃣ Installing latest versions for selected operators...")
        def choose_latest(vs: list[str]) -> str | None:
            return vs[0] if vs else None
        to_install = [(name, choose_latest(versions_by_operator.get(name, []))) for name in operator_names]
        for name, version in to_install:
            if not version:
                print(f"⚠️  Skipping {name}: no versions available")
                continue
            print(f"➡️  Installing {name}@{version} ...")
        try:
                install_result = await operator_registry.install(name, version, OperatorInstallOptions(force=True))
                print(f"✅ Installed {name}@{version}: {install_result}")
        except Exception as e:
                print(f"❌ Failed to install {name}@{version}: {e}")
        
        # Fetch info for installed operators
        print("\n6️⃣ Fetching info for installed operators...")
        for name, version in to_install:
            if not version:
                continue
            try:
                info_result = await operator_registry.info(name, version, OperatorInfoOptions())
                print(f"ℹ️  Info for {name}@{version}: {info_result}")
            except Exception as e:
                print(f"❌ Failed to get info for {name}@{version}: {e}")
        
        print("\n🎉 Operator Registry methods are working correctly!")
        
    except Exception as error:
        print(f"❌ Operator Registry example failed: {error}")
        print("   This is expected if native bridge libraries are not available")
        print("   In a real environment, ensure the bridge libraries are properly installed")

# Run the example
if __name__ == "__main__":
    asyncio.run(operator_registry_example())
    print("\n🎉 Operator Registry example completed!")
    print("\n📚 Next steps:")
    print("   1. Install the actual bridge libraries")
    print("   2. Provide correct paths to bridge libraries")
    print("   3. Create real operator files")
    print("   4. Run with actual hardware/device")