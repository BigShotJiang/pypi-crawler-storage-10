"""
CLI module tests for HBAT.

Tests for command-line interface functionality including argument parsing,
preset support, and output formats.
"""