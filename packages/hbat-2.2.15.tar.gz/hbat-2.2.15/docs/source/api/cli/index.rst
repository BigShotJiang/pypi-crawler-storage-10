Main CLI Module
---------------

.. automodule:: hbat.cli.main
   :members:
   :undoc-members:
   :show-inheritance: