# DEDS Cumulus
Basic functions for Cumulus