import json

from cve_driller.driller import CVEDriller


if __name__ == "__main__":
    driller = CVEDriller(verbose=True)
    cve_id = "CVE-2018-7187"

    input_path = f"data/inputs/CWE-78/comp_config_condition/{cve_id}.txt"
    #description = open(input_path, 'r').read()
    description = "College Management System Php 1.0 suffers from SQL injection vulnerabilities in the index.php page from POST parameters 'unametxt' and 'pwdtxt', which are not filtered before passing a SQL query."
    detail_type, details = driller(description)
    # CVE-2020-26051

    if details:
        print(json.dumps(details, indent=4))

    #if details:
    #    output_path = f"data/outputs/{detail_type.value}/{cve_id}.json"

    #    with open(output_path, 'w') as f:
    #        json.dump(details, f, indent=4)
