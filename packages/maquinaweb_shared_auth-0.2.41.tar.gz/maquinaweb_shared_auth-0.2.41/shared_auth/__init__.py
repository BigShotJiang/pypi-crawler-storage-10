"""
Biblioteca compartilhada para acesso aos models de autenticação
"""

__version__ = '1.0.0'
default_app_config = "shared_auth.app.SharedAuthConfig"