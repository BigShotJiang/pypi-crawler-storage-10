from lecrapaud.api import *

# Export default parameters for easy access
from lecrapaud.api import ExperimentEngine
DEFAULT_EXPERIMENT_PARAMS = ExperimentEngine.DEFAULT_PARAMS
