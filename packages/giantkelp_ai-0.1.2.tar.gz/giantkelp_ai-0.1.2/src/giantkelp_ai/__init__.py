"""GiantKelp AI - Universal AI Agent for multiple LLM providers."""

from giantkelp_ai.ai import AIAgent
from giantkelp_ai.config import Config

__version__ = "0.1.0"
__all__ = ["AIAgent", "Config"]