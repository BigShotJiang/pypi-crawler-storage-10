from check_pfda_admin.gui import main

if __name__ == "__main__":
    main()
