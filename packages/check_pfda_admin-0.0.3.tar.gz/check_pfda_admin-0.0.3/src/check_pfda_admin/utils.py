import subprocess
import csv
from pathlib import Path
from datetime import datetime
import configparser
import re
import requests
from git import Repo
GITHUB_AUTOGRADER_TESTS_REPO = "https://raw.githubusercontent.com/nelsonlimco-pfda/autograder-tests/main"


def extract_student_from_repo(repo_name: str, roster_usernames: list[str]) -> str | None:
    """
    Extact the student username from a repo name of the form:
    pfda-c<chapter>-lab-<lab-name>-<student-username>

    Handles usernames that may contain dashes by matching against the roster.
    """
    parts = repo_name.split("-")
    try:
        lab_index = parts.index("lab")
    except ValueError:
        return None

    # Everything after "lab" could be lab-name + username
    candidate_suffix = "-".join(parts[lab_index + 1 :])

    # Try to match against roster usernames
    for username in sorted(roster_usernames, key=len, reverse=True):
        if candidate_suffix.endswith(username):
            return username

    return None

def get_github_usernames(ta_roster_path: str, main_roster_csv: str) -> list[str]:
    """
    Reads a TA's student roster file and returns a list of GitHub usernames
    for those student identifiers based on the main roster CSV.

    Args:
        ta_roster_path (str): Path to the TA's text file containing identifiers (one per line).
        main_roster_csv (str): Path to the roster CSV file with columns:
            'identifier', 'github_username', 'github_id', 'name'.

    Returns:
        list[str]: GitHub usernames corresponding to the identifiers found in the TA's roster.
    """
    ta_roster_path = Path(ta_roster_path)
    main_roster_csv = Path(main_roster_csv)

    with open(ta_roster_path, "r", encoding="utf-8") as f:
        ta_identifiers = {line.strip() for line in f if line.strip()}

    github_usernames = []

    with open(main_roster_csv, "r", encoding="utf-8") as f:
        sample = f.read(2048)
        delimiter = "\t" if "\t" in sample else ","
        f.seek(0)
        reader = csv.DictReader(f, delimiter=delimiter)

        # Match on identifier
        for row in reader:
            if row["identifier"] in ta_identifiers:
                github_usernames.append(row["github_username"])

    return github_usernames


def load_roster_usernames(roster_path: str | Path) -> list[str]:
    """Load GitHub usernames from a roster CSV with 'github_username' column."""
    usernames = []
    with open(roster_path, newline="", encoding="utf-8") as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            if "github_username" in row and row["github_username"]:
                usernames.append(row["github_username"].strip())
    return usernames


def get_identifier_from_roster(roster: str | Path, github_username: str) -> str | None:
    """
    Given a roster CSV with headers 'identifier' and 'github_username',
    return the identifier associated with the given github_username.
    """
    roster = Path(roster)

    with roster.open(newline="", encoding="utf-8") as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            if row.get("github_username") == github_username:
                return row.get("identifier")


def get_latest_commit_date(repo_path: str) -> datetime:
    """Get the date of the most recent commit in the given Git repository."""
    try:
        result = subprocess.run(
            ["git", "log", "-1", "--format=%cd", "--date=iso-strict"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True,
        )
        latest_commit_date = result.stdout.strip()
        return datetime.fromisoformat(latest_commit_date)
    except Exception as e:
        raise RuntimeError(f"Failed to get latest commit date: {e}")


def get_semester_from_latest_commit(date: datetime) -> str:
    """Return the semester (YYs, YYf, or YYu) based on the date of the most recent commit."""
    try:
        year_short = str(date.year % 100).zfill(2)

        if 1 <= date.month <= 5:
            semester = "s"  # Spring
        elif 8 <= date.month <= 12:
            semester = "f"  # Fall
        else:
            semester = "u"  # Summer

        return f"{year_short}{semester}"

    except Exception as e:
        raise RuntimeError(f"Failed to determine semester: {e}")

def is_user_maintainer(author: str, email: str):
    disallowed_emails = ["ben@utdallas.edu", "66690702+github-classroom[bot]@users.noreply.github.com", "me@nelsonlim.com", "kieuvyk8@gmail.com", "69740001+zan-074@users.noreply.github.com", "zenith.score101@gmail.com"]
    disallowed_authors = ["ben cressman", "vylam0912", "nelson lim", "314re", "zan-074", "github-classroom[bot]", "Zarah Najmi"]
    if author.lower() in disallowed_authors or email.lower() in disallowed_emails:
        return True
    return False

def count_user_commits(repo_path: Path) -> int:
    """
    Count the number of commits in a local Git repository made by a given GitHub username.

    Args:
        repo_path (str): Path to the local Git repository.

    Returns:
        int: Number of commits made by the given username.
    """
    repo = Repo(repo_path)

    if repo.bare:
        raise ValueError(f"Repository at {repo_path} appears to be empty or invalid")

    # Normalize for case-insensitive matching and possible name/email matches
    count = 0

    for commit in repo.iter_commits():
        author_name = (commit.author.name or "")
        author_email = (commit.author.email or "")
        if is_user_maintainer(author_name, author_email):
            continue
        count += 1
    return count





def get_repo_remote_url(repo_path: Path) -> str:
    """
    Returns the remote URL a local git repo was cloned from, by reading its .git/config file.

    Args:
        repo_path (str): Path to the root of the local git repository.

    Returns:
        str: The remote 'origin' URL for the repository.

    Raises:
        FileNotFoundError: If the .git directory or its config file cannot be found.
        KeyError: If the remote origin is not defined in the config.
    """
    git_config_path = repo_path / ".git" / "config"

    if not git_config_path.exists():
        raise FileNotFoundError(f"Could not find git config file: {git_config_path}")

    config = configparser.ConfigParser()
    config.read(git_config_path)

    # Git configparser sections like: [remote "origin"]
    for section in config.sections():
        if section.startswith('remote "') and "url" in config[section]:
            return config[section]["url"]

    raise KeyError(f"No remote URL found in {git_config_path}")

def match_test_file(input_path: Path) -> str:
    """
    Given a submission path, returns the raw URL to the matching test file in the
    online GitHub autograder-tests repository.

    Args:
        input_path (Path): Path to the submission directory
            (e.g. '.../pfda-c04-lab-pattern-quilt-generator-submissions')

    Returns:
        str: URL of the matching test file in the GitHub repo
    """
    # Extract chapter (like 'c04')
    chapter_match = re.search(r'^[^-]+-(c\d{2})-', input_path.name)
    if not chapter_match:
        raise ValueError(f"Could not determine chapter from: {input_path.name}")
    chapter = chapter_match.group(1)

    # Extract assignment name (between 'lab-' and '-submissions')
    # Use greedy match (.+) instead of non-greedy (.+?) so multi-word names work
    assignment_match = re.search(r'lab-(.+)-submissions$', input_path.name)
    if not assignment_match:
        raise ValueError(f"Could not determine assignment name from: {input_path.name}")
    assignment_name = assignment_match.group(1)

    # Build GitHub raw URL
    test_filename = f"test_{assignment_name}.py".replace("-", "_")
    test_file_url = f"{GITHUB_AUTOGRADER_TESTS_REPO}/{chapter}/{test_filename}"

    # Optionally verify that it exists remotely
    resp = requests.head(test_file_url)
    if resp.status_code != 200:
        raise FileNotFoundError(f"Test file not found at {test_file_url}")

    return test_file_url


def copy_test_file(input_path: str) -> Path:
    """
    Downloads the corresponding test file from the GitHub repo and saves it
    into the given submission directory.

    Args:
        input_path (str): Path to the submission directory

    Returns:
        Path: The path of the downloaded test file inside the input directory
    """
    input_dir = Path(input_path)
    test_file_url = match_test_file(input_dir)

    # File name is just the last segment of the URL
    test_filename = test_file_url.split("/")[-1]
    dest_path = input_dir / test_filename

    # Download and write the file
    resp = requests.get(test_file_url)
    resp.raise_for_status()

    with open(dest_path, "wb") as f:
        f.write(resp.content)

    return dest_path
