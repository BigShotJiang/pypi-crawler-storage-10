import os
import sys
import subprocess
import json
import csv
from datetime import datetime
from pathlib import Path
from typing import List, Optional
import platform

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QPushButton,
    QLabel,
    QLineEdit,
    QTextEdit,
    QFileDialog,
    QMessageBox,
    QProgressBar,
    QCheckBox, QSizePolicy
)
from git import Repo

from check_pfda_admin.utils import (
    copy_test_file,
    is_user_maintainer,
    load_roster_usernames,
    get_github_usernames,
    extract_student_from_repo,
    get_identifier_from_roster,
    get_latest_commit_date,
    get_repo_remote_url,
)


class TesterThread(QThread):
    log_signal = Signal(str)
    progress_signal = Signal(int, int)
    finished_signal = Signal(str)

    def __init__(self, roster_path: str, repo_dir: str, team_students_txt: str = None, extract_team: bool = True, open_results_immediately: bool = False):
        super().__init__()
        self.roster_path = roster_path
        self.repo_dir = Path(repo_dir)
        self.team_students_txt = team_students_txt
        self.extract_team = extract_team
        self.open = open_results_immediately

    def run(self):
        self.log_signal.emit("INFO: Setting up tests...")
        if self.extract_team:
            self.pytest_subdirs(self.roster_path, str(self.repo_dir), self.team_students_txt)
        else:
            self.pytest_subdirs(self.roster_path, str(self.repo_dir), extract_team=False)
        self.log_signal.emit("INFO: Done testing!")

    def pytest_subdirs(self, roster_csv: str, assignment_dir: str, team_students_txt: str = None, extract_team: bool = True):
        """
        Run pytest on all subdirs of the cwd.

        Results are collected in a series of json files which are finally aggregated
        in a csv.
        """

        test_file = copy_test_file(assignment_dir)
        student_usernames = load_roster_usernames(roster_csv)

        all_results = []
        current_ta_students = []
        if extract_team:
            current_ta_students = get_github_usernames(team_students_txt, roster_csv)
            dirs = [d for d in Path(assignment_dir).iterdir() if d.is_dir() and (
                        d.name.startswith("pfda") or d.name.startswith("pdfa")) and extract_student_from_repo(str(d),
                                                                                                              student_usernames) in current_ta_students]
            print(f"Testing {len(dirs)} repos")
        else:
            dirs = [d for d in Path(assignment_dir).iterdir() if d.is_dir() and d.name.startswith("pfda") or d.name.startswith("pdfa")]
        usernames = load_roster_usernames(roster_csv)
        count = 0
        for subdir in dirs:
            # print(f"Testing {subdir}")
            init_time = datetime.now()
            student = extract_student_from_repo(str(subdir), usernames)
            commits = self.collect_commit_messages(subdir)
            amount_of_commits = len(commits)
            commit_messages = "\n\n".join(commits)
            date_of_latest_commit = get_latest_commit_date(str(subdir))
            result_data = {
                "github_username": student,
                "net_id": get_identifier_from_roster(roster_csv, student),
                # generate link by semester of latest commit and subdir name
                # NOTE that this could break if the naming convention of the classrooms ever changes
                # https://github.com/utd-angm2305-25f/pfda-c07-lab-texture-lod-generator-ZackAttack198
                "url": get_repo_remote_url(subdir)[:-4] + "/commits/main",
                "path": str(subdir),
                # "test_file": test_file,
            }
            src_path = subdir / "src"
            env = os.environ.copy()
            env["PYTHONPATH"] = str(src_path)

            try:
                # Run pytest in subprocess
                proc = subprocess.run(
                    ["pytest", test_file],
                    cwd=subdir,
                    env=env,
                    capture_output=True,
                    text=True,
                    timeout=60,
                )

                result_data["result"] = "pass" if proc.returncode == 0 else "FAIL"
                result_data["return_code"] = str(proc.returncode)
                result_data["process_duration"] = str(datetime.now() - init_time)
                result_data["stdout"] = proc.stdout
                result_data["stderr"] = proc.stderr
                result_data["latest_commit"] = date_of_latest_commit.strftime("%b-%d %Hh-%Mm-%Ss")
                result_data["amount_of_commits"] = str(amount_of_commits)
                result_data["commit_messages"] = commit_messages
                count += 1
                self.progress_signal.emit(count, len(dirs))
                self.log_signal.emit(f"INFO: Finished testing {student} at {subdir}")

            except Exception as e:
                result_data["error"] = str(e)

            # Write individual JSON file for each pytest output
            json_path = subdir / f"{subdir.name}_result.json"
            with open(json_path, "w", encoding="utf-8") as f:
                json.dump(result_data, f, indent=2)

            all_results.append(result_data)

        # Write aggregated CSV
        csv_path = Path(assignment_dir) / "results.csv"
        with open(csv_path, "w", newline="", encoding="utf-8") as csvfile:
            fieldnames = [
                "net_id",
                "url",
                # "test_file",
                "result",
                "latest_commit",
                "amount_of_commits",
                "commit_messages",
                "stdout",
                "github_username",
                "path",
                "process_duration",
                "return_code",
                "stderr",
                "error",
            ]
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for row in sorted(all_results, key=lambda r: (r.get("net_id") or "")):
                writer.writerow(row)

        print(f"Results written to {csv_path}")
        if self.open:
            if platform.system() == "Windows":
                os.startfile(csv_path)
            if platform.system() == "Darwin":
                try:
                    subprocess.run(['open', csv_path], check=True)
                except subprocess.CalledProcessError as e:
                    print(f"Error opening file: {e}")
                except FileNotFoundError:
                    print("Error: 'open' command not found. This script is intended for macOS.")
        self.finished_signal.emit(f"INFO: Finished testing {len(all_results)} repos.")

    def collect_commit_messages(self, repo_path: Path) -> list[str]:
        """
        Iterates through all commits in a local Git repository and concatenates their
        commit messages into a single string, separated by two newlines.

        Args:
            repo_path (Path): Path to the local Git repository.

        Returns:
            str: All commit messages, separated by two newlines.
        """
        repo = Repo(repo_path)

        if repo.bare:
            raise ValueError(f"Repository at {repo_path} appears to be empty or invalid")

        messages = []
        authors = []
        emails = []
        for commit in repo.iter_commits():
            author = commit.author.name
            email = commit.author.email
            if is_user_maintainer(author, email):
                continue
            if author not in authors:
                authors.append(author)
            if email not in emails:
                emails.append(email)

            messages.append(f"{commit.message.strip()}\n - {author} <{email}>")

        if len(authors) > 1 or len(emails) > 1:
            self.log_signal.emit(f"WARNING: multiple authors or emails found in {repo_path}: {authors} / {emails}")

        return messages


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PFDA Repository Tester")
        self.setMinimumSize(800, 400)

        self.central = QWidget()
        self.setCentralWidget(self.central)

        self.layout = QVBoxLayout(self.central)

        # Roster input
        self.roster_edit = QLineEdit()
        btn_roster = QPushButton("Browse Roster CSV")
        btn_roster.clicked.connect(self.select_roster)

        # Team list
        self.team_list_cb = QCheckBox("Only include team members?")
        self.team_list_cb.setChecked(True)
        self.team_list_cb.stateChanged.connect(self.handle_team_list_checked)
        self.team_label = QLabel("Team Students TXT:")
        self.team_txt_path = QLineEdit()
        self.team_txt_btn = QPushButton("Browse Team TXT")
        self.team_txt_btn.clicked.connect(self.select_team_txt)
        self.team_layout = QHBoxLayout()
        self.team_layout.addWidget(self.team_list_cb)
        self.team_layout.addWidget(self.team_label)
        self.team_layout.addWidget(self.team_txt_path)
        self.team_layout.addWidget(self.team_txt_btn)

        # Repos directory input
        self.repo_edit = QLineEdit()
        btn_repo = QPushButton("Browse Repos Directory")
        btn_repo.clicked.connect(self.select_repo_dir)

        # Layout rows
        hl1 = QHBoxLayout()
        hl1.addWidget(QLabel("Roster CSV:"))
        hl1.addWidget(self.roster_edit)
        hl1.addWidget(btn_roster)

        hl2 = QHBoxLayout()
        hl2.addWidget(QLabel("Repos Directory:"))
        hl2.addWidget(self.repo_edit)
        hl2.addWidget(btn_repo)

        # Run button + progress
        self.run_layout = QHBoxLayout()
        self.open_immediately_cb = QCheckBox("Open results immediately?")
        self.open_immediately_cb.setChecked(False)
        self.run_button = QPushButton("Run Tests")
        self.run_button.clicked.connect(self.run_tests)
        self.run_button.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.run_layout.addWidget(self.open_immediately_cb)
        self.run_layout.addWidget(self.run_button)
        self.progress_label = QLabel("Progress:")
        self.progress = QProgressBar()
        self.interrupt_btn = QPushButton("Interrupt")
        self.interrupt_btn.clicked.connect(self.interrupt_tests)
        self.interrupt_btn.setEnabled(False)
        progress_layout = QHBoxLayout()
        progress_layout.addWidget(self.progress_label)
        progress_layout.addWidget(self.progress)
        progress_layout.addWidget(self.interrupt_btn)

        # Log box
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)

        self.layout.addLayout(hl1)
        self.layout.addLayout(hl2)
        self.layout.addLayout(self.team_layout)
        self.layout.addLayout(self.run_layout)
        self.layout.addLayout(progress_layout)
        self.layout.addWidget(QLabel("Log Output:"))
        self.layout.addWidget(self.log_box)

        self.thread: Optional[TesterThread] = None


    def select_roster(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select roster CSV", "", "CSV Files (*.csv)"
        )
        if path:
            self.roster_edit.setText(path)

    def select_repo_dir(self):
        path = QFileDialog.getExistingDirectory(
            self, "Select directory containing repositories"
        )
        if path:
            self.repo_edit.setText(path)

    def select_team_txt(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select team students TXT", "", "TXT Files (*.txt)"
        )
        if path:
            self.team_txt_path.setText(path)

    def handle_team_list_checked(self):
        if self.team_list_cb.isChecked():
            self.team_label.setEnabled(True)
            self.team_txt_path.setEnabled(True)
            self.team_txt_btn.setEnabled(True)
        else:
            self.team_label.setEnabled(False)
            self.team_txt_path.setEnabled(False)
            self.team_txt_btn.setEnabled(False)

    def run_tests(self):
        roster = self.roster_edit.text().strip()
        repo_dir = self.repo_edit.text().strip()

        if not Path(roster).is_file():
            QMessageBox.warning(self, "Error", "Please select a valid roster CSV.")
            return
        if not Path(repo_dir).is_dir():
            QMessageBox.warning(self, "Error", "Please select a valid repository directory.")
            return

        self.log_box.clear()
        self.run_button.setEnabled(False)
        self.interrupt_btn.setEnabled(True)
        self.progress.setValue(0)
        if self.team_list_cb.isChecked():
            team_students_txt = self.team_txt_path.text().strip()
            if not Path(team_students_txt).is_file():
                QMessageBox.warning(self, "Error", "Please select a valid team students TXT.")
            self.thread = TesterThread(roster, repo_dir, team_students_txt, open_results_immediately=self.open_immediately_cb.isChecked())
        else:
            self.thread = TesterThread(roster, repo_dir, extract_team=False, open_results_immediately=self.open_immediately_cb.isChecked())
        self.thread.log_signal.connect(self.append_log)
        self.thread.progress_signal.connect(self.update_progress)
        self.thread.finished_signal.connect(self.tests_finished)
        self.thread.start()
        self.append_log("INFO: Starting tests...\n")

    def append_log(self, message: str):
        self.log_box.append(message)
        self.log_box.ensureCursorVisible()

    def update_progress(self, value: int, total: int):
        self.progress.setMaximum(total)
        self.progress.setValue(value)

    def tests_finished(self, message: str):
        self.run_button.setEnabled(True)
        self.append_log(message)

    def interrupt_tests(self):
        if self.thread:
            self.thread.terminate()
            self.thread.wait()
            self.tests_finished("INFO: Tests interrupted.")
        self.interrupt_btn.setEnabled(False)

def main():
    app = QApplication(sys.argv)
    window = Window()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
