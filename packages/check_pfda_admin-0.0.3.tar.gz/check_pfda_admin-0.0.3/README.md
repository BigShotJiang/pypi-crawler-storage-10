# check-pfda-admin

> Compatibility goes here

check-pfda-admin is a Python package with administrative tools for PFDA.

## Installation
1. Download the repo as a zip file.
2. Unzip it.
3. On your preferred interpreter, `pip install path/to/the/repo`
4. On the same interpreter, `pip install check-pfda`.

### Usage
1. Use the GitHub Classroom CLI to download all of the assignment's student repo's.
2. Download the student roster as a CSV from GitHub Classroom, name it 'roster.csv', and place it in the same directory as the directory that holds the student repo's. Sample structure:
    - grading
      - roster.csv
      - assignment_1_grades
        - student1repo
        - student2repo
        - student3repo
      - assignment_2_grades
        - student1repo
        - student2repo
        - student3repo
3. Open the parent directory of the student repo's in VS Code (or your preferred editor); this is the directory containing the assignments you want to grade.
    - grading/assignment_1_grades
4. Activate the interpreter with `check-pfda-admin` installed.
5. Run `nelson-says run`

A `results.csv` file will be output in that directory and individual student results json files will be output in each student repo.

## Documentation
> Read The Docs page goes here
