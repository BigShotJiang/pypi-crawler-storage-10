# TODO (Prompt Schema v2 rollout and tooling)

## 🎉 Recently Completed

### プロットマッチング機能改善 - 完了 (2025-10-27)
- ✅ **LLMベースプロット検証機能実装** (SPEC-PLOT-ADHERENCE-001改善版)
  - 問題: 従来の単語マッチングによる偽陽性・偽陰性（「ギルド」という単語のみで判定）
  - 解決: LLMによる意味的検証に移行（同義語対応、文脈理解、エビデンス取得）
  - 新規作成:
    - `src/noveler/domain/value_objects/element_verification_result.py` (208行、検証結果VO)
    - `src/noveler/domain/services/llm_plot_verifier.py` (310行、LLM検証サービス)
  - 修正: `src/noveler/application/validators/plot_adherence_validator.py` (452行、LLM統合)
  - ドキュメント: `docs/b20_outputs/plot_matching_improvement_codemap.yaml` (11KB)

- ✅ **テスト実装完了** (41ケース、835行)
  - ElementVerificationResult: 17テスト（正常系、異常系、境界値、判定メソッド）
  - LLMPlotVerifier: 24テスト（正常/異常/フォールバック/統合）
  - 推定カバレッジ: 90%+（テスト/実装比率 86%）
  - B20成果物: SOLID準拠98.3%、品質ゲートPASS

- ✅ **コードレビュー修正完了** (Commits e046e43, 629aeaf)
  - マジックナンバー除去: `DEFAULT_MAX_MANUSCRIPT_LENGTH=3000`, `DEFAULT_VERIFICATION_TIMEOUT=30`
  - エラーハンドリング改善: 例外種別分離（PlotVerificationError, JSONDecodeError等）
  - PlotAdherenceValidator完全LLM統合: 信頼度0.5以上フィルタリング

- ✅ **ドキュメント更新完了** (Commit 7653e79)
  - CHANGELOG.md: リファクタリング内容3件追加

**成果:**
- 実装: 970行（3ファイル）
- テスト: 835行（2ファイル、41ケース）
- SOLID: 98.3%準拠
- コミット: 5個（dc8c9f9, 4f3280c, e046e43, 629aeaf, 7653e79）
- ブランチ: `claude/improve-plot-matching-011CUYRjyifzEuceeAP3rbrJ`（プッシュ済み）

### DDD修復フェーズ1 - ステップ3-4完了 (2025-10-26)
- ✅ **handlers.py完全修復** (コミット 90221de)
  - 問題: コミット fbc29c9 で関数呼び出し箇所の更新が漏れていた
  - 修正: `capture_domain_logs()` → `_CAPTURE_DOMAIN_LOGS()`、`create_artifact_store()` → `_CREATE_ARTIFACT_STORE()` (2箇所)
  - 追加修正: `CliAdapterFactory.create_artifact_store()` に `storage_dir` 引数を追加
  - テスト結果: 3つの失敗テスト → 全てPASS、8953 PASSED達成

- ✅ **io.py DDD違反修復** (コミット 7e9d253)
  - Infrastructure層 `path_service_factory` → Application層 `CliAdapterFactory.create_path_service()`
  - DDD違反 1個完全削除
  - テスト結果: 8953 PASSED維持

**累計成果（フェーズ1進捗）:**
- 完了: 4/9ファイル (44%)
- DDD違反削減: 15→1 (93%削減)
- テスト維持: 8953 PASSED (100%維持)
- コミット数: 5個

---

### P1: YAML Repository Test Isolation - 解決済み (2025-10-27)
- ✅ **検証結果**: 全テストスイート 8953 PASSED, 0 ERRORS
- ✅ **個別実行**: test_yaml_episode_repository.py (13 passed), test_yaml_project_info_repository.py (22 passed), test_step_output_manager.py (9 passed)
- ✅ **repositories/全体**: 184 passed, 2 skipped
- **結論**: レポート作成（2025-10-23）から現在までの間に自然解決。DDD修復等の副次効果と推測。

---

### P2: Domain Plot Workflow Failures - 完了 (2025-10-27)
- ✅ **検証結果**: 17 SKIPPEDテストを有効化 → 25 tests PASSED
- ✅ **修正内容**:
  - TestPrerequisiteRule/TestWorkflowStage: 期待値修正 `"chapter01.yaml"` → `"第01章.yaml"` (日本語形式)
  - TestPlotCreationTask: Path型比較に修正（OS非依存）
  - TestPlotCreationService: mock条件分岐で出力ファイル/前提ファイルを区別
  - TestPlotWorkflowIntegration: パス正規化処理でパス区切り文字不一致を解決
- **結論**: 実装は正しく、テスト期待値とmock設定の問題だった

---

### P3: Configuration Services - 解決済み (2025-10-27)
- ✅ **検証結果**: 2 tests PASSED (test_configuration_dependency_repair_services.py)
  - test_configuration_repair_collects_logs_when_global_config_missing
  - test_dependency_repair_collects_logs_for_missing_packages_dry_run
- **結論**: レポート作成（2025-10-23）から現在までの間に自然解決。

---

### Lint Remediation (Non-test Source Tree) - 完了 (2025-10-27)
- ✅ **検証結果**: ruff check bin scripts src → All checks passed! ✅
- ✅ **修正内容**:
  - F821 (undefined-name) 4件: cli_adapter.pyに必要なimport追加
  - D411/D410 (docstring formatting) 15件: セクション間空行の自動修正
- ✅ **テスト**: CLI tests 23 passed (リグレッションなし)
- **結論**: 非テストソースツリーのlintエラー 19 → 0

---

### CI: Artifact Validation Integration - 完了 (2025-10-27)
- ✅ **実装内容**:
  - `scripts/validate_artifacts.py` は既に完全実装済み
  - PRチェックワークフローに artifact-validation job追加
  - validation_manifest.yaml のパス修正
  - JSON + Markdown レポート出力 (reports/artifact_validation.*)
  - 失敗時はexit 1でCI失敗
- ✅ **検証結果**: 2テンプレート検証成功 (step06, step16)
- **結論**: PR毎の自動検証が有効化されました ✅

---

### DDD修復フェーズ1 - 完了 (2025-10-27)

**完了項目:**
- ✅ **ステップ5**: ten_stage_adapter.py (コミット d92ba81)
- ✅ **ステップ6**: command_executor.py (統合コミット)
- ✅ **ステップ7**: entrypoints.py (統合コミット)
- ✅ **ステップ8**: generic_command_handler.py (統合コミット)
- ✅ **ステップ9**: repository_factories.py (統合コミット)

**最終成果:**
- Console統一: CliAdapterFactory経由に統一（32ファイル修正）
- Repository委譲: CliAdapterFactoryに集約
- DDD違反削減: 完了
- テスト維持: 8953 PASSED (100%)

---

### CI完全成功達成 (2025-10-27)

**コミット履歴:**
1. ✅ **09eb72c**: b20-workflow DI anti-pattern文書化 + Git squash example追加
2. ✅ **0b01d39**: Domain Plot Workflow 17テスト有効化 (25 tests passed)
3. ✅ **6f55ce1**: P3 Configuration Services解決マーク
4. ✅ **4bec33c**: F821 lint errors修正 (cli_adapter.py import追加)
5. ✅ **762576a**: D411/D410 docstring formatting自動修正
6. ✅ **c8bd108**: PR workflow artifact-validation job統合
7. ✅ **490acbe**: validation_manifest.yaml パス修正
8. ✅ **bb4585e**: pytest marker 'run' 登録 (Infrastructure layer修正)
9. ✅ **508c882**: Python 3.13統一 (全ワークフロー)
10. ✅ **a44aaf0**: Foreshadowing test mock修正 (最終失敗テスト修正)

**達成成果:**
- ✅ **CI全ジョブ成功**: Lint, Test (3レイヤー), Artifact Validation, Quality Gate
- ✅ **Python 3.13統一**: ローカル環境とCI環境の完全一致
- ✅ **テスト健全性**: 8953 PASSED維持
- ✅ **ドキュメント整備**: Session_2025_10_27_Complete_CI_Success.md作成

---

## 🔄 Active Tasks

---

### High Priority Tasks

**Phase 4 Testing Status**: P1, P2, P3全て解決済み ✅
**Lint Remediation Status**: 非テストソースツリー完了 ✅
**CI Artifact Validation Status**: PR自動検証統合完了 ✅
**CI Status**: ✅ **ALL JOBS PASSING** (2025-10-27 完全成功)
  - Lint: ✅ ruff + importlinter + quality check templates
  - Test (Domain): ✅ 並列実行
  - Test (Application): ✅ 並列実行 (Python 3.13統一)
  - Test (Infrastructure): ✅ 順次実行 (pytest marker修正完了)
  - Artifact Validation: ✅ テンプレート検証統合
  - Quality Gate: ✅ 全チェック成功

### Active Tasks

- Markdown steps (12–15): add minimal meta channel for by_task
  - Decide format: front‑matter (`--- yaml ---`) or HTML comment meta (`<!-- yaml: {...} -->`).
  - Extend validator to parse meta from Markdown when present.
  - Optionally add `by_task` mappings for 12–15 once meta format is finalized.
- CLI: use v2 structured sections for prompt synthesis
  - Prefer `inputs/constraints/tasks/artifacts/acceptance_criteria` over long main_instruction.
  - Enforce "YAML only in fenced code" at output; add retry on validation fail.

## Medium Priority

- **MCP Import Refactor & Retire Namespace Shim** (future phase)
  - Context: `./mcp_servers/__init__.py` is a namespace shim for `from mcp_servers.noveler.*` imports.
    Currently required because `src/mcp_servers/` contains dozens of modules using absolute imports.
    See [mcp_servers/__init__.py:1](mcp_servers/__init__.py) and [src/mcp_servers/noveler/core/async_subprocess_adapter.py:9](src/mcp_servers/noveler/core/async_subprocess_adapter.py).
  - **Keep shim for now** (still anchors import resolution; removal would break all imports until sweeping refactor).
  - **Future steps** (when ready to retire):
    1. [ ] Decide on new import style:
       - Option A: Relative imports (`from .core.async_subprocess_adapter import ...`)
       - Option B: src-explicit layout (`from src.mcp_servers.noveler.core...`)
    2. [ ] Update all `from mcp_servers.*` imports in `src/mcp_servers/**/*.py` and `scripts/`.
    3. [ ] Ensure packaging/test harness exports same dotted path (install package or set PYTHONPATH deterministically).
    4. [ ] Remove `./mcp_servers/__init__.py`.
    5. [ ] Run `/test` to confirm parity.
  - **Tracker**: Track in CI/refactor backlog for next major release.

- STEP1 optional explicit `handover_to_next` key
  - Add to `story_structure` example + `by_task` mapping if we want stricter checks.
- Examples parity
  - Ensure `artifacts.example` contains sample fields referenced by `by_task` (spot check each step).
- Docs
  - templates/README.md: add brief on `id`/`by_task` and validator workflow.
  - A38 docs: note variable convention `{project_root}` (from `{PROJECT_ROOT}`) and code‑fence YAML guidance.
- Arrays addressing in validator (v2.1)
  - Add dotted path with wildcard (e.g., `sections[*].hook`) support.
  - Add numeric aggregations (min/max/avg) for metrics on arrays.

## Nice to Have
- Generator retry policy
  - On `by_task` failures, auto‑compose a delta prompt listing failed IDs and expected rules.
- Rich metrics
  - STEP10 non‑visual sense ratio estimator for raw text (heuristic).
  - STEP15 dialogue ratio estimator on Markdown.
- Telemetry
  - Summarize pass/fail rates per ID across episodes to prioritize template improvements.

- Progressive Check refactor (LangGraph alignment)
  - [ ] Update docs/README to remove `progressive_check.start_session` references and document `get_tasks` flow.
  - [ ] Refactor ProgressiveCheckManager to expose explicit session init helper and include `session_id` in `get_check_tasks` response; verify client compatibility.
  - [ ] Add unit tests ensuring `.noveler/checks/<session_id>/` files and LangGraph workflow logs are created using temp dirs.
  - [ ] Improve CLI error for unsupported progressive_check commands to guide users toward `get_tasks`.
  - [ ] Document LangGraph requirement and workflow logging in guides/CHANGELOG.
  - [ ] Integrate new tests into CI to catch logging regressions.

## Operational Checklist

### Template & Validation System
- [ ] Implement validator script (by_task + checklist + metrics)
- [ ] Wire CI job (`make validate-templates` + `make validate-artifacts`)
- [ ] Decide Markdown meta format for 12–15 and update templates
- [ ] Add by_task mappings for 12–15 after meta support
- [ ] Update templates/README.md with v2 + validator docs
- [ ] (Optional) Add `handover_to_next` key to STEP1 `story_structure`
- [ ] Update A38 excerpts to `{project_root}` examples where applicable

### LLM Ops & Docs Consolidation (2025-10-28)
- [ ] README に「LLM運用クイックリンク」を追加（AGENTS.md の「Claude/MCP 契約（統合）」、チェックリスト、`/test`/`/test-changed`/`/test-failed`/`/scan-encoding` への導線）。
- [ ] `/test-changed` を実行し、死蔵関数削除後の差分テスト結果をレポート（`reports/llm_summary.*` の要約をPRに添付）。
- [ ] `dev` ブランチを push し、PR 作成（ベース `main` か `dev` を確定）。PR本文に DoD/ガードレール/統合の要点を記載。
- [ ] AGENTS.md の Motto 行を ASCII 記号へサニタイズ（端末依存の表示乱れ対策、機能影響なし）。
- [ ] （任意）`scripts/install-hooks.sh` を再実行して、メッセージ更新版の出力を確認（フック自体の機能は既に有効）。
- [ ] CLAUDE.md 参照の残存スキャン（`rg -n "CLAUDE.md"`）。現状 0 件だが、今後の追加分も定期確認。
