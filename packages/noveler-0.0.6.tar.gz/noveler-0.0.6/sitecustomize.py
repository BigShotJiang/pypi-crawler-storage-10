"""Project-level site customisations for path handling.

Python imports this module automatically (via the built-in ``site`` module) if
the project root is on ``sys.path``. We leverage that to guarantee the primary
``src/`` tree—and the generated ``dist/mcp_servers`` wrappers—remain available
without requiring ad-hoc path fiddling or legacy namespace shims.

File: sitecustomize.py
Purpose: Automatically expose the project's source packages for default Python entrypoints.
Context: Ensures `src/` (and generated `dist/mcp_servers`) are importable when only the repo root is on PYTHONPATH.
"""
from __future__ import annotations

import sys
from importlib import import_module
from pathlib import Path


def _ensure_project_paths() -> None:
    """Add essential project directories to ``sys.path`` if missing."""
    project_root = Path(__file__).resolve().parent
    candidates = [
        project_root / "src",
        project_root / "dist" / "mcp_servers",
    ]

    for candidate in candidates:
        if not candidate.exists():
            continue
        candidate_str = str(candidate)
        if candidate_str not in sys.path:
            sys.path.insert(0, candidate_str)


_ensure_project_paths()

def _load_extended_customizations() -> None:
    """Load the extended site customisations located under ``src/``."""
    try:
        import_module("sitecustomize_impl")
    except ModuleNotFoundError:
        # Fail silently if the extended module is not present; keeps shim minimal.
        pass


_load_extended_customizations()
