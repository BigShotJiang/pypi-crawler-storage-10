# Task Prompt Template (Variables)

目的: 固定プロンプト（CLAUDE.md）に「タスク固有の変数」を差し込むための最小雛形。

## Context
- リポジトリ位置/関連モジュール:
- 背景/目的（なぜ今やるか）:
- 既存の類似機能・文書（参照ファイル）:

## Constraints
- 非機能（性能/可読性/依存制約 など）:
- 変更範囲（含む/含まない）:
- 入出力の契約（型/例）:

## Task
- 要求（1つの仮説/1つの変更に限定）:
- 受け入れ条件（ビジネス/技術）:

## Steps (Suggested)
- Plan → Read → Verify → Implement → Test & Docs → Reflect

## Checks
- 実装/ドキュメント整合: `scripts/comment_header_audit.py --tiered`
- 影響度とDDD/TDD整合: `python scripts/check_tdd_ddd_compliance.py`
- 文字化け検出（warn-only）: `/scan-encoding`

## Definition of Done
- テストがグリーン（`/test` または `/test-changed`）
- 変更内容の3行サマリを提示
- 実装とドキュメントの整合を確認

## Reporting
- コマンド実行例/結果（短く）
- 変更点サマリ（3行）
- 次の一歩（任意）

