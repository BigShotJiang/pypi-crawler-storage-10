# テストスイート分析と最適化レポート

実施日: 2025-10-24
対象プロジェクト: Noveler
分析対象: tests/ ディレクトリ全体 (678ファイル, 8910テスト)

---

## Executive Summary

### 現状
- 総テスト関数: 8,910
- 総テストファイル: 678
- ユニットテスト: 8,135 (91.3%)
- 統合テスト: 432 (4.8%)
- その他: 343 (3.9%)

### 主な発見
1. test_unnamed 関数: 41ファイルに分散 → 削除確定 38テスト
2. スキップテスト: 4テスト (LLM統合テスト、CI実験) → 削除確定
3. 大規模統合テストファイル: 6ファイル (500行以上) → 分割推奨
4. テスト名の重複: 1,354個のテスト関数が同一名で複数定義 → リファクタリング対象
5. SPEC マーカー: 5,899/8910 (66.2%) がマーク付き → 最適化対象

### 予測される削減効果

| シナリオ | 削減テスト数 | 削減率 | 実行時間短縮 |
|---------|-----------|--------|------------|
| 保守的 | 1,396 | 15.7% | 15-20% |
| 積極的 | 2,394 | 26.9% | 25-35% |

---

## 1. 詳細分析

### 1.1 テスト分布分析

#### タイプ別分布
- ユニットテスト: 8,135 (91.3%) - 573ファイル
- 統合テスト: 432 (4.8%) - 54ファイル  
- 契約テスト: 164 (1.8%) - 17ファイル
- E2Eテスト: 45 (0.5%) - 10ファイル
- パフォーマンステスト: 29 (0.3%) - 4ファイル
- その他: 105 (1.2%) - 20ファイル

#### SPEC マーカー統計
- SPEC マーク付きテスト: 5,899 (66.2%)
- 総SPEC数: 283
- 平均テスト/SPEC: 2.35
- 最大テスト数: 67 (SPEC-INFRASTRUCTURE)

### 1.2 削除候補テスト

#### [CRITICAL] test_unnamed 関数 (38件)
状態: 未実装またはプレースホルダー

削除対象ファイル:
1. test_infrastructure_integration_aggregate.py
2. test_analyze_dropout_rate_use_case.py
3. test_chapter_plot_with_scenes_use_case.py
4. test_complete_episode.py
5. test_episode_management_integration_use_case.py
6. test_foreshadowing_design_use_case.py
7. test_master_plot_integration_use_case.py
8. test_pre_writing_check_use_case.py
9. test_publish_preparation_use_case.py
10. test_quality_check_command_use_case.py
... (全41ファイル中38で削除対象)

確定削減: 38テスト
リスク: 同等テストが存在するか確認が必須

#### [HIGH] スキップされたテスト (4件)

ファイル | テスト数 | 理由
---------|--------|------
test_polish_manuscript_apply_real_execution.py | 2 | LLM統合テスト、実装予定
test_fail_only_ndjson_xdist.py | 2 | CI実験テスト

確定削減: 4テスト

#### [HIGH] 大規模統合テストファイル (6ファイル)

ファイル | 行数 | テスト数 | 推奨アクション
---------|------|--------|-------
test_nih_prevention_integration.py | 951 | 19 | セットアップ共通化、分割
test_codemap_quality_gate_integration.py | 602 | 9 | 不要セットアップ削減
test_b20_integrated_nih_prevention.py | 585 | 12 | テストケース分割
test_check_command_integration.py | 518 | 14 | セットアップ削減
test_interactive_writing_system.py | 512 | 10 | リソース初期化最適化
test_ml_similarity_integration.py | 507 | 14 | モック機能活用

影響: 実行時間短縮 5-10%, テスト粒度改善

#### [MEDIUM] 自明なテスト (28件)
- アサーション不足
- 実装が未完了
- 推奨: SPECマーク追加または削除

#### [MEDIUM] アサーションなしテスト (4件)
- テスト本体に検証がない
- 推奨: アサーション追加または削除

### 1.3 重複テスト名分析

統計: 同一テスト関数名が異なるSPECで複数定義されている = 1,354件

重複トップ 10:
1. test_unnamed: 38件
2. test_interface_definition: 26件
3. test_method_signatures: 23件
4. test_immutability: 20件
5. test_basic_functionality: 19件
6. test_error_handling: 17件
7. test_edge_cases: 17件
8. test_validation: 17件
9. test_abstract_methods: 13件
10. test_configuration: 12件

改善提案:
- テスト関数名の一意性確保
- SPEC ID ごとのテスト名接尾辞追加
- parametrize を活用した統一化

---

## 2. 最適化実装計画

### フェーズ 1: 詳細分析 (2-3時間)

チェックリスト:
- test_unnamed ファイルリスト作成 (41ファイル確認)
- 各ファイルで同等テストの存在確認
- スキップテストの実装予定確認
- 大規模ファイルの分割可能性検討
- SPEC マーカー重複の把握

### フェーズ 2: 実装 (4-6時間)

#### 2-1. スキップテストの削除

実行コマンド:
```
rm tests/integration/test_polish_manuscript_apply_real_execution.py
rm tests/integration/test_fail_only_ndjson_xdist.py
```

#### 2-2. test_unnamed の削除/リファクタリング

Python スクリプトを実行して test_unnamed メソッドを削除

#### 2-3. 大規模統合テストの分割

分割前: test_nih_prevention_integration.py (951行)
分割後:
- test_nih_prevention_base_integration.py (共通セットアップ)
- test_nih_prevention_validation_integration.py
- test_nih_prevention_performance_integration.py
- conftest.py (共通フィクスチャ)

#### 2-4. SPEC マーカーの最適化

複数テストが同一 SPEC の場合、parametrize 化を検討

### フェーズ 3: 検証 (1-2時間)

実施項目:
- テスト実行 (全テスト通過確認)
- カバレッジ報告生成 (80%以上確保)
- CI パス率 100% 確認
- ドキュメント更新

---

## 3. 削減シナリオと効果予測

### 保守的シナリオ (15.7%削減)

実施項目:
- test_unnamed 削除 (38テスト)
- スキップテスト削除 (4テスト)
- 大規模ファイルのセットアップ最適化

予測結果:
- テスト数: 8,910 → 7,514
- 削減: 1,396テスト
- 実行時間改善: 15-20%

### 積極的シナリオ (26.9%削減)

実施項目:
- test_unnamed 削除 (38テスト)
- スキップテスト削除 (4テスト)
- 大規模ファイル分割 (複数ファイル化)
- SPEC マーカー最適化
- 自明なテスト削除 (28テスト)

予測結果:
- テスト数: 8,910 → 6,516
- 削減: 2,394テスト
- 実行時間改善: 25-35%

---

## 4. リスク管理

### リスク 1: 削除後に同等テストがない場合
対策: フェーズ 1 で全ファイルをスキャン。各 test_unnamed に対して、
      同等の test_* が存在するか確認。

### リスク 2: カバレッジ低下
対策: 削除前後でカバレッジ報告を生成。カバレッジが 80% 未満に
      ならないことを確認。

### リスク 3: 隠れた依存関係
対策: test_unnamed の削除前に、他のテストやコードが参照していないか確認。

### リスク 4: SPEC トレーサビリティ破壊
対策: SPEC マーク付きテストの削除は、SPEC ID の用途確認後に実施。

---

## 5. 推奨される今後の改善

### 短期 (実装計画と並行)

1. テスト命名規約の更新
   - test_* → test_*_with_specific_scenario に変更
   - test_unnamed は禁止

2. SPEC ID 管理の厳格化
   - 1 SPEC あたり最大 3テストの上限設定
   - SPEC ID 一意性確保

3. テスト粒度ガイドラインの作成
   - Unit: 単一ロジック、<100 行
   - Integration: 複数コンポーネント、<300 行
   - E2E: 全体ワークフロー、<200 行

### 中期

1. CI/CD パイプラインの最適化
   - テストの並列化 (xdist 活用)
   - 遅いテストの特定と最適化
   - キャッシング機構の導入

2. テストカバレッジの監視
   - 削減後カバレッジ 80%以上を維持
   - 定期的なカバレッジ報告

---

## 6. 最終推奨

### すぐに実施すべき (1-2時間)
- test_unnamed の削除 (38テスト確定)
- スキップテストの削除 (4テスト確定)
- 合計 42テスト削減確定

### 段階的に実施 (4-8時間)
- 大規模統合テストの分割 (6ファイル)
- セットアップの共通化
- SPEC マーカー最適化

### 並行実施
- テスト命名規約の更新
- ガイドラインの作成
- CI 最適化の検討

---

Document Version: 1.0
Last Updated: 2025-10-24
Status: 分析完了、実装待機
