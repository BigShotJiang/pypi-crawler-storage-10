# MCPサーバーnoveler - バージョン管理 クイックスタート

**対象**: 開発者・プロジェクト管理者
**所要時間**: 5分

---

## 🚀 よく使うコマンド

### 1. 現在のバージョンを確認

```bash
cd C:\Users\bamboocity\Dropbox\noveler
./scripts/manage-versions.sh status
```

**出力例**:
```
📋 現在のバージョン情報

  pyproject.toml version: v0.0.3
  最新 git tag:           v0.0.3
  現在のブランチ:         dev
  タグ以降のコミット数:   21

00_ガイド配布ハブの状態:
  codex.mcp.json version: v0.0.3
```

---

### 2. バージョンが一致しているか確認

```bash
./scripts/manage-versions.sh check
```

**期待される出力**:
```
✅ バージョンは一致しています
   Version: v0.0.3
```

---

### 3. 新しいバージョンをリリース

```bash
./scripts/manage-versions.sh release 0.0.4
```

**実施内容**:
1. pyproject.toml のバージョンを更新
2. git commit & tag を実行
3. GitHub にプッシュ

**その後**:
```bash
# 00_ガイドでビルド
cd ../OneDrive/Documents/9_小説/00_ガイド
bin/build

# メタデータを全プロジェクトで同期
python ../Dropbox/noveler/scripts/update_version_metadata.py --sync
```

---

### 4. メタデータを自動同期

```bash
cd C:\Users\bamboocity\Dropbox\noveler
python scripts/update_version_metadata.py --check     # 確認
python scripts/update_version_metadata.py --sync      # 同期
```

---

## 📋 運用シナリオ別ガイド

### シナリオA: 新機能を追加したい

**手順** (5分):
```bash
# 1. noveler で開発
cd C:\Users\bamboocity\Dropbox\noveler
git checkout dev
# ... コード編集 ...
git commit -m "feat: 新機能追加"
git push origin dev

# 2. 00_ガイドで再ビルド
cd ../OneDrive/Documents/9_小説/00_ガイド
bin/build

# 3. 夢遊病で確認
# VSCode で "Developer: Reload Window" を実行
# (Ctrl+Shift+P) 新しいMCPサーバーが起動
```

---

### シナリオB: 安定版をリリースしたい

**手順** (10分):
```bash
# 1. リリース準備
cd C:\Users\bamboocity\Dropbox\noveler
./scripts/manage-versions.sh release 0.0.4
# → バージョン確認をして yes を入力

# 2. 00_ガイドでビルド
cd ../OneDrive/Documents/9_小説/00_ガイド
bin/build

# 3. メタデータ同期
cd ../Dropbox/noveler
python scripts/update_version_metadata.py --sync

# 4. 夢遊病（必要に応じて）
# codex.mcp.json の "_metadata": { "noveler_pinned_version": "0.0.4" }
# に更新
```

---

### シナリオC: トラブルシューティング

#### 問題: 夢遊病が古いバージョンを使っている

**解決**:
```bash
# 1. ビルドを再実行
cd C:\Users\bamboocity\OneDrive\Documents\9_小説\00_ガイド
bin/build

# 2. VSCode を再起動
# Ctrl+Shift+P → "Developer: Reload Window"

# 3. 確認
noveler --version
```

---

#### 問題: バージョンが一致していない

**確認・修正**:
```bash
# 確認
cd C:\Users\bamboocity\Dropbox\noveler
./scripts/manage-versions.sh check

# 修正（タグが無い場合）
git tag v0.0.3
git push origin --tags

# 再確認
./scripts/manage-versions.sh check
```

---

## 📚 詳細情報

- **完全ガイド**: [docs/mcp-version-management.md](./docs/mcp-version-management.md)
- **実装レポート**: [IMPLEMENTATION_REPORT.md](./IMPLEMENTATION_REPORT.md)
- **MCP設定**: [codex.mcp.json](../OneDrive/Documents/9_小説/00_ガイド/codex.mcp.json)

---

## ✅ チェックリスト（初回セットアップ後）

- [ ] `./scripts/manage-versions.sh status` が正常に実行される
- [ ] `./scripts/manage-versions.sh check` で整合性が確認される
- [ ] `python scripts/update_version_metadata.py --check` で OK が返される
- [ ] VS Code で 夢遊病 プロジェクトを開いて MCP が正常に起動する
- [ ] `noveler --version` で v0.0.3 が返される

---

## 🎯 まとめ

| タスク | コマンド | 所要時間 |
|-------|--------|--------|
| バージョン確認 | `./scripts/manage-versions.sh status` | 1秒 |
| 整合性確認 | `./scripts/manage-versions.sh check` | 1秒 |
| 新機能追加 | dev で開発 → bin/build | 5分 |
| 新バージョンリリース | `./scripts/manage-versions.sh release X.Y.Z` | 2分 |
| メタデータ同期 | `python scripts/update_version_metadata.py --sync` | 1秒 |

---

**最後に**: 不明な点があれば、[docs/mcp-version-management.md](./docs/mcp-version-management.md) の FAQ を参照してください。
