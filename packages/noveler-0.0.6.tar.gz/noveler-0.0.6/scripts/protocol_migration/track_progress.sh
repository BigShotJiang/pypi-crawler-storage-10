#!/bin/bash
# Protocol移行進捗追跡スクリプト
#
# File: scripts/protocol_migration/track_progress.sh
# Purpose: Protocol移行の進捗を自動追跡し、KPIを計算
# Usage: ./track_progress.sh [output_file]

set -e

OUTPUT_FILE="${1:-reports/protocol_migration_progress_snapshot.txt}"
TIMESTAMP=$(date "+%Y-%m-%d %H:%M:%S")

echo "=========================================="
echo "Protocol移行 進捗追跡レポート"
echo "実行時刻: $TIMESTAMP"
echo "=========================================="

# 1. ABC使用ファイル数のカウント
echo ""
echo "📊 ABC使用ファイル数"
ABC_COUNT=$(find src/noveler/domain -name "*.py" -exec grep -l "from abc import ABC" {} \; 2>/dev/null | wc -l)
echo "  現在: $ABC_COUNT ファイル"
echo "  目標: 30 ファイル以下"
ABC_REDUCTION=$((104 - ABC_COUNT))
if [ $ABC_REDUCTION -gt 0 ]; then
    PERCENT=$((ABC_REDUCTION * 100 / 104))
    echo "  削減: $ABC_REDUCTION ファイル ($PERCENT%)"
fi

# 2. Protocol使用ファイル数のカウント
echo ""
echo "🔵 Protocol使用ファイル数"
PROTOCOL_COUNT=$(find src/noveler/domain -name "*.py" -exec grep -l "from typing import Protocol" {} \; 2>/dev/null | wc -l)
echo "  現在: $PROTOCOL_COUNT ファイル"
echo "  目標: 90+ ファイル"
PROTOCOL_GROWTH=$((PROTOCOL_COUNT - 18))
if [ $PROTOCOL_GROWTH -gt 0 ]; then
    echo "  増加: +$PROTOCOL_GROWTH ファイル"
fi

# 3. インターフェース重複検出
echo ""
echo "⚠️  インターフェース重複検出"
DUPLICATE_PATTERNS="ILogger ILoggerService PathService ConfigService"
DUPLICATE_COUNT=0
for pattern in $DUPLICATE_PATTERNS; do
    FOUND=$(find src/noveler/domain -name "*.py" -exec grep -l "class.*$pattern" {} \; 2>/dev/null | wc -l)
    if [ $FOUND -gt 1 ]; then
        DUPLICATE_COUNT=$((DUPLICATE_COUNT + 1))
        echo "  - $pattern: $FOUND箇所で定義"
    fi
done
echo "  重複定義: $DUPLICATE_COUNT件"

# 4. テスト成功率の確認
echo ""
echo "✅ テスト成功率"
if command -v pytest &> /dev/null; then
    # pytest実行（簡易版）
    TOTAL_TESTS=$(find tests -name "test_*.py" | wc -l)
    echo "  テストファイル: $TOTAL_TESTS"
    echo "  ※ 詳細: pytest -q を実行してください"
else
    echo "  pytest: インストールされていません"
fi

# 5. mypy strict mode検証
echo ""
echo "🔒 mypy strict mode検証"
if command -v mypy &> /dev/null; then
    # Domain層の簡易検証
    PROTOCOL_FILES=$(find src/noveler/domain/protocols -name "*.py" 2>/dev/null | wc -l)
    echo "  Protocol定義ファイル: $PROTOCOL_FILES"
    echo "  ※ 詳細: mypy --strict src/noveler/domain/ を実行してください"
else
    echo "  mypy: インストールされていません"
fi

# 6. importlinter契約検証
echo ""
echo "📋 importlinter契約"
if command -v import-linter &> /dev/null; then
    echo "  状態: import-linter check で検証可能"
else
    echo "  ※ import-linter がインストールされていません"
fi

# 7. サマリー
echo ""
echo "=========================================="
echo "📈 進捗サマリー"
echo "=========================================="

ABC_PERCENT=$((ABC_COUNT * 100 / 104))
echo "  ABC削減度: $ABC_PERCENT% → $(( 100 - ABC_PERCENT ))%"

if [ $PROTOCOL_COUNT -gt 18 ]; then
    PROTOCOL_PERCENT=$(( (PROTOCOL_COUNT - 18) * 100 / 72 ))
    echo "  Protocol増加度: ${PROTOCOL_PERCENT}%"
fi

echo "  インターフェース重複: $DUPLICATE_COUNT件（目標: 0件）"
echo "  推定進捗: Phase $(( ABC_REDUCTION / 15 + 1 ))/5"

# 8. 出力をファイルに保存（指定されている場合）
if [ ! -z "$OUTPUT_FILE" ]; then
    {
        echo "===== Protocol移行 進捗スナップショット ====="
        echo "生成日時: $TIMESTAMP"
        echo ""
        echo "ABC使用ファイル数: $ABC_COUNT / 104（目標: 30）"
        echo "Protocol使用ファイル数: $PROTOCOL_COUNT / 18+（目標: 90+）"
        echo "インターフェース重複: $DUPLICATE_COUNT件（目標: 0）"
        echo ""
        echo "推定進捗: $(( ABC_REDUCTION * 100 / 74 ))%"
    } > "$OUTPUT_FILE"
    echo ""
    echo "📁 スナップショット保存: $OUTPUT_FILE"
fi

echo ""
echo "ℹ️  次のステップ:"
echo "  1. pytest -q でテスト成功率確認"
echo "  2. mypy --strict src/noveler/domain/ で型安全性確認"
echo "  3. import-linter check で依存性確認"
