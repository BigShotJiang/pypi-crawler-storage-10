#!/bin/bash
# File: scripts/manage-versions.sh
# Purpose: MCPサーバーnovelerのバージョン管理スクリプト
# Context: noveler開発ハブでのバージョン管理・リリース自動化

set -e  # エラーで停止

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VERSION_FILE="$REPO_ROOT/pyproject.toml"
GUIDE_REPO="C:/Users/bamboocity/OneDrive/Documents/9_小説/00_ガイド"

# 色付け出力
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'  # No Color

echo -e "${BLUE}=================================================="
echo "🏷️  Noveler MCPサーバー - バージョン管理スクリプト"
echo "==================================================${NC}\n"

# ヘルプメッセージ
show_help() {
    cat << EOF
使用方法: $0 <command> [options]

コマンド:
  status              現在のバージョン情報を表示
  release <version>   新しいバージョンをリリース（例: 0.0.4）
  check               バージョンの整合性をチェック
  sync                00_ガイドのcodex.mcp.jsonを更新
  help                このメッセージを表示

例:
  $0 status
  $0 release 0.0.4
  $0 check
  $0 sync

EOF
}

# 現在のバージョンを取得
get_current_version() {
    grep '^version = ' "$VERSION_FILE" | sed 's/version = "\(.*\)"/\1/'
}

# git タグを取得
get_current_tag() {
    git -C "$REPO_ROOT" describe --tags --abbrev=0 2>/dev/null || echo "no-tag"
}

# status コマンド
cmd_status() {
    echo -e "${YELLOW}📋 現在のバージョン情報${NC}\n"

    CURRENT_VERSION=$(get_current_version)
    CURRENT_TAG=$(get_current_tag)
    CURRENT_BRANCH=$(git -C "$REPO_ROOT" rev-parse --abbrev-ref HEAD)
    COMMITS_SINCE_TAG=$(git -C "$REPO_ROOT" rev-list --count "${CURRENT_TAG}..HEAD" 2>/dev/null || echo "0")

    echo "  pyproject.toml version: ${GREEN}v${CURRENT_VERSION}${NC}"
    echo "  最新 git tag:           ${GREEN}${CURRENT_TAG}${NC}"
    echo "  現在のブランチ:         ${BLUE}${CURRENT_BRANCH}${NC}"
    echo "  タグ以降のコミット数:   ${YELLOW}${COMMITS_SINCE_TAG}${NC}"

    echo ""
    echo -e "${BLUE}00_ガイド配布ハブの状態:${NC}"
    if [ -f "$GUIDE_REPO/codex.mcp.json" ]; then
        GUIDE_VERSION=$(grep -o '"noveler_version": "[^"]*"' "$GUIDE_REPO/codex.mcp.json" | head -1 | cut -d'"' -f4)
        echo "  codex.mcp.json version: ${GREEN}v${GUIDE_VERSION}${NC}"
    else
        echo "  codex.mcp.json:         ${RED}見つかりません${NC}"
    fi
}

# check コマンド
cmd_check() {
    echo -e "${YELLOW}🔍 バージョン整合性チェック${NC}\n"

    PYPROJECT_VERSION=$(get_current_version)
    GIT_TAG=$(get_current_tag)

    if [ "$GIT_TAG" == "no-tag" ]; then
        echo -e "${RED}❌ git タグが存在しません${NC}"
        echo "   実行: git tag v${PYPROJECT_VERSION} && git push origin --tags"
        return 1
    fi

    # タグからバージョンを抽出
    TAG_VERSION=${GIT_TAG#v}

    if [ "$TAG_VERSION" != "$PYPROJECT_VERSION" ]; then
        echo -e "${RED}❌ バージョン不一致${NC}"
        echo "   pyproject.toml: v${PYPROJECT_VERSION}"
        echo "   git tag:        ${GIT_TAG}"
        return 1
    fi

    echo -e "${GREEN}✅ バージョンは一致しています${NC}"
    echo "   Version: v${PYPROJECT_VERSION}"
}

# release コマンド
cmd_release() {
    if [ -z "$1" ]; then
        echo -e "${RED}エラー: バージョンを指定してください${NC}"
        echo "使用例: $0 release 0.0.4"
        return 1
    fi

    NEW_VERSION="$1"
    NEW_TAG="v${NEW_VERSION}"

    echo -e "${YELLOW}🚀 新しいバージョンをリリース${NC}\n"
    echo "  対象バージョン: ${GREEN}${NEW_TAG}${NC}"
    echo "  対象ブランチ:   ${BLUE}main${NC}"

    # 確認
    read -p "本当に進めますか？ (y/N): " -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "キャンセルしました。"
        return 0
    fi

    # main にチェックアウト
    echo -e "${YELLOW}1. main ブランチに切り替え...${NC}"
    git -C "$REPO_ROOT" checkout main

    # pyproject.toml を更新
    echo -e "${YELLOW}2. pyproject.toml を更新...${NC}"
    sed -i "s/^version = \"[^\"]*\"/version = \"${NEW_VERSION}\"/" "$VERSION_FILE"
    git -C "$REPO_ROOT" add "$VERSION_FILE"
    git -C "$REPO_ROOT" commit -m "chore: bump version to ${NEW_TAG}"

    # タグ付け
    echo -e "${YELLOW}3. git タグを付与...${NC}"
    git -C "$REPO_ROOT" tag "${NEW_TAG}"

    # プッシュ
    echo -e "${YELLOW}4. リモートにプッシュ...${NC}"
    git -C "$REPO_ROOT" push origin main --tags

    echo ""
    echo -e "${GREEN}✅ リリース完了！${NC}"
    echo ""
    echo -e "${BLUE}次のステップ:${NC}"
    echo "  1. 00_ガイドでビルド:"
    echo "     cd ${GUIDE_REPO} && bin/build"
    echo ""
    echo "  2. 00_ガイドの codex.mcp.json を更新:"
    echo "     $0 sync"
}

# sync コマンド
cmd_sync() {
    echo -e "${YELLOW}🔄 00_ガイド codex.mcp.json を同期${NC}\n"

    CURRENT_VERSION=$(get_current_version)
    CURRENT_DATE=$(date +%Y-%m-%d)

    if [ ! -f "$GUIDE_REPO/codex.mcp.json" ]; then
        echo -e "${RED}❌ 00_ガイド/codex.mcp.json が見つかりません${NC}"
        return 1
    fi

    # バージョン情報を更新（簡易版）
    echo "  更新内容:"
    echo "    noveler_version: v${CURRENT_VERSION}"
    echo "    pinned_date:     ${CURRENT_DATE}"
    echo ""

    echo -e "${YELLOW}00_ガイド/codex.mcp.json を手動で更新してください:${NC}"
    echo "  \"_metadata\": {"
    echo "    \"noveler_version\": \"${CURRENT_VERSION}\","
    echo "    \"pinned_date\": \"${CURRENT_DATE}\""
    echo "  }"
}

# メインロジック
case "${1:-help}" in
    status)
        cmd_status
        ;;
    check)
        cmd_check
        ;;
    release)
        cmd_release "$2"
        ;;
    sync)
        cmd_sync
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        echo -e "${RED}未知のコマンド: $1${NC}"
        echo ""
        show_help
        exit 1
        ;;
esac
