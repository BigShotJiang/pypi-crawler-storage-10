#!/usr/bin/env python3
# File: scripts/analyze_test_baseline.py
# Purpose: テストベースライン結果の統計分析とレポート生成
# Context: 並列実行無効化後の初回テスト結果を分析し、改善基準を設定

import re
import sys
from pathlib import Path
from typing import Any


def parse_pytest_output(log_file: Path) -> dict[str, Any]:
    """pytestログから統計情報を抽出"""
    content = log_file.read_text(encoding="utf-8")

    # 最後の summary line を抽出
    summary_pattern = r"(\d+) (passed|failed|error|skipped)"
    matches = re.findall(summary_pattern, content, re.IGNORECASE)

    stats = {
        "passed": 0,
        "failed": 0,
        "error": 0,
        "skipped": 0,
        "total": 0,
        "success_rate": 0.0,
    }

    for count_str, status in matches:
        count = int(count_str)
        status_lower = status.lower()
        if status_lower in stats:
            stats[status_lower] = count

    total = stats["passed"] + stats["failed"] + stats["error"]
    if total > 0:
        stats["total"] = total
        stats["success_rate"] = (stats["passed"] / total) * 100

    return stats


def print_report(stats: dict[str, Any]) -> None:
    """テスト統計レポートを表示"""
    print("\n" + "=" * 70)
    print("テストベースライン統計レポート")
    print("=" * 70)
    print(f"\n✅ 成功:     {stats['passed']:>6} テスト")
    print(f"❌ 失敗:     {stats['failed']:>6} テスト")
    print(f"⚠️  エラー:    {stats['error']:>6} テスト")
    print(f"⊘ スキップ: {stats['skipped']:>6} テスト")
    print(f"\n総数:        {stats['total']:>6} テスト")
    print(f"成功率:      {stats['success_rate']:>6.2f}%")
    print("\n" + "=" * 70)

    # 目標との比較
    target_rate = 99.0
    if stats["success_rate"] >= target_rate:
        print(f"🎉 目標達成！ ({target_rate}% 以上)")
    else:
        gap = target_rate - stats["success_rate"]
        additional_passed = stats["failed"] + stats["error"]
        print(f"📊 改善必要: {gap:.2f}% (あと {additional_passed} テストの修正が必要)")
    print("=" * 70 + "\n")


def main() -> int:
    """メイン処理"""
    log_file = Path("test_baseline.log")

    if not log_file.exists():
        print(f"❌ ログファイルが見つかりません: {log_file}")
        return 1

    stats = parse_pytest_output(log_file)
    print_report(stats)

    # 環境変数で成功率をエクスポート
    print(f"TEST_SUCCESS_RATE={stats['success_rate']:.2f}")
    print(f"TEST_TOTAL={stats['total']}")
    print(f"TEST_PASSED={stats['passed']}")
    print(f"TEST_FAILED={stats['failed']}")
    print(f"TEST_ERROR={stats['error']}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
