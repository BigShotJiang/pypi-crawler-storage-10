#!/bin/bash
# File: scripts/install-hooks.sh
# Purpose: Install Git hooks from hooks/ directory into .git/hooks/
# Context: Automatically sets up safety mechanisms for device coordination.

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
HOOKS_DIR="$REPO_ROOT/hooks"
GIT_HOOKS_DIR="$REPO_ROOT/.git/hooks"

echo ""
echo "=================================================="
echo "🔧 Installing Git Hooks"
echo "=================================================="
echo ""

# Ensure hooks directory exists
if [ ! -d "$GIT_HOOKS_DIR" ]; then
  mkdir -p "$GIT_HOOKS_DIR"
  echo "✅ Created .git/hooks directory"
fi

# List of hooks to install
hooks=("post-checkout" "pre-commit")

for hook in "${hooks[@]}"; do
  src="$HOOKS_DIR/$hook"
  dst="$GIT_HOOKS_DIR/$hook"

  if [ -f "$src" ]; then
    cp "$src" "$dst"
    chmod +x "$dst"
    echo "✅ Installed: $hook"
  else
    echo "⚠️  Not found: $src (skipping)"
  fi
done

echo ""
echo "=================================================="
echo "✅ Hook installation complete!"
echo "=================================================="
echo ""
echo "Installed hooks:"
echo "  • post-checkout: Auto-sync main when switching to dev"
echo "  • pre-commit: Warn about device lock conflicts"
echo ""
echo "These hooks ensure safe multi-device development"
echo ""
