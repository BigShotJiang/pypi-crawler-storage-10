#!/usr/bin/env python3
# File: scripts/remove_unnamed_tests.py
# Purpose: test_unnamed 関数を全テストファイルから削除
# Context: テストスイートの最適化 - 未実装のプレースホルダーテスト削除

import re
from pathlib import Path


def remove_test_unnamed(file_path: Path) -> tuple[bool, str]:
    """test_unnamed 関数を削除する"""
    content = file_path.read_text(encoding="utf-8")
    original_content = content

    # test_unnamed の定義パターンを検出して削除
    # パターン: @...def test_unnamed(...): ... (次の関数or EOF まで)
    pattern = r"(?:@[^\n]*\n)*\s*def test_unnamed\([^)]*\)[^:]*:.*?(?=\n(?:def |class |@|$))"

    modified_content = re.sub(pattern, "", content, flags=re.DOTALL)

    # 空行の重複を削除
    modified_content = re.sub(r"\n\n\n+", "\n\n", modified_content)

    if modified_content != original_content:
        file_path.write_text(modified_content, encoding="utf-8")
        return True, "test_unnamed を削除しました"
    return False, "test_unnamed が見つかりません"


def main() -> None:
    """メイン処理"""
    tests_dir = Path("tests")
    removed_count = 0
    skipped_count = 0

    print("🔍 test_unnamed テストを削除中...\n")

    # すべての .py テストファイルを対象
    for py_file in tests_dir.rglob("test_*.py"):
        success, message = remove_test_unnamed(py_file)
        if success:
            removed_count += 1
            print(f"✅ {py_file.relative_to('.')}: {message}")
        else:
            skipped_count += 1

    print("\n📊 結果:")
    print(f"  削除: {removed_count} ファイル")
    print(f"  スキップ: {skipped_count} ファイル")
    print(f"  合計: {removed_count + skipped_count} ファイル")


if __name__ == "__main__":
    main()
