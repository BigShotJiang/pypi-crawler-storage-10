# dev ブランチ向け PR のデフォルトレビュアー設定手順

2025-10-25 時点では、GitHub には「特定ブランチに対して特定ユーザーを自動でレビューアサインする」単独機能はありません。  
したがって、以下の 2 ステップを組み合わせて `dev` ブランチ向け PR に Codex のレビューを必須化します。

## 1. CODEOWNERS で Codex をコードオーナーに指定する

1. リポジトリの `.github/` ディレクトリ（存在しない場合は作成）に `CODEOWNERS` ファイルを置きます。
2. 全ファイルを対象に Codex を所有者として登録する場合は、次のように記述します。

   ```text
   * @codex
   ```

   - Codex の GitHub ユーザー名（またはチーム名）が `@codex` でない場合は適切なハンドルに置き換えてください。
   - 特定ディレクトリだけに限定したい場合は、パターン（例：`/src/noveler/ @codex`）を用いてください。

これにより、該当ファイルを変更する PR を作成すると GitHub が自動で Codex にレビューを依頼します。

## 2. dev ブランチの保護ルールで「コードオーナーのレビュー必須」を設定する

1. GitHub リポジトリの **Settings → Branches → Branch protection rules** へ移動します。
2. `dev` ブランチに対するルールを追加（または編集）し、以下を有効化します。
   - **Require a pull request before merging**
   - **Require review from Code Owners**
3. 必要であれば「Dismiss stale pull request approvals when new commits are pushed」など追加オプションも有効にします。

この設定により、`dev` ブランチへマージする前に Codex（CODEOWNERS で指定したユーザー/チーム）の承認が必須になります。

## 補足

- ブランチ保護の設定変更には管理者権限が必要です。設定後は、新しいルールが既存の PR にも適用されることを確認してください。
- CODEOWNERS は GitHub の仕様に従い、最も具体的なパターンが優先されます。複数の所有者を指定したい場合は、行末に半角スペース区切りで追加します（例：`* @codex @other-reviewer`）。
