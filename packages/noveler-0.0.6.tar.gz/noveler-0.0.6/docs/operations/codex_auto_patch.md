# Codex レビューコメント自動反映ワークフロー（GitHub Actions 構想）

目的: Codex (BOT) が出したレビューコメントを GitHub Actions だけで取得し、指摘内容を適用するための検討メモです。

注意: 現状API呼び出しを使わない制約から、Claude Codeなど外部LLMの完全自律修正は難しいです。あくまで「コメント収集」「状況整理」「半自動対応」までをGitHub Actionsで支援する設計になります。

その上で考えられるステップや構成案を以下にまとめます。

1. トリガー
   - `pull_request_review` もしくは `issue_comment` イベント（Codexがコメントを残すタイミング）を受け取るワークフローを作成。
   - 具体例: `.github/workflows/codex-review.yml` に以下を指定:
     ```yaml
     on:
       pull_request_review:
         types: [submitted]
       issue_comment:
         types: [created]
     ```
   - Codexユーザー（例: `codex-bot`）のコメントに限定する場合は、ジョブ内でコメント投稿者をチェックしてフィルタします。

2. コメント取得
   - `gh` CLI や `curl` (GitHub REST API) を使って、対象のレビューコメントを取得。
     例: `gh api repos/{owner}/{repo}/pulls/{number}/reviews` や `/pulls/{number}/comments`。
   - フィルター条件:
     * コメント投稿者 (`user.login`) が Codex か
     * コメント本文が特定フォーマット (`CODE_FIX: file:line:description` など) に従うか

3. コメント解析とタスク化
   - コメントをMarkdownファイルやJSONにまとめ、どのファイルのどの行にどのような指摘があるかを整理。
   - 自動修正までは行わず、「TODO リストとして PR に付ける」「issue に起票する」などの半自動対応でもワークロードは減らせる。
   - 自動修正を目指す場合は、コメントフォーマットに従ってscriptで `git apply` や `sed` を使って修正案を適用する必要がある。ただしGitHub Actionsのみでの信頼性は低く、複雑な修正は困難。

4. コード修正の自動化（制限付き）
   - 複雑な修正はむずかしいため、次のように範囲を限定するのが現実的:
     * Lint 修正や単純な文字列置換など、機械的に適用可能なケースのみ対応。
     * コメントに「Replace `<old>` with `<new>`」のような明確指示がある場合にScriptで置換。
   - 指定ファイルを`gh api`でダウンロード/編集するのではなく、Actionsランナー上で`git` を使って動的に修正し、`git commit` & `git push` するフローも可能。
   - この際CI (pytest, lint) を実行し、成功したら `git push`、失敗したらその内容をPRコメントに記録して終了。

5. Actions例
   ```yaml
   jobs:
     codex-review:
       runs-on: ubuntu-latest
       permissions:
         contents: write
         pull-requests: write
       steps:
         - uses: actions/checkout@v4
           with:
             fetch-depth: 0
         - name: Collect Codex comments
           run: |
             gh api repos/${{ github.repository }}/pulls/${{ github.event.pull_request.number }}/reviews \ 
               --jq '.[] | select(.user.login=="codex-bot")' > codex_reviews.json
         - name: Parse and list TODOs
           run: |
             python scripts/tools/list_codex_comments.py codex_reviews.json > CODex_TODO.md
         - name: Attempt autofix (optional)
           run: |
             python scripts/tools/autofix_codex_comments.py codex_reviews.json
         - name: Run tests
           run: |
             make test
         - name: Commit changes (if any)
           if: success() && steps.autofix.outputs.changed == 'true'
           run: |
             git config user.name "github-actions"
             git config user.email "actions@github.com"
             git commit -am "chore: apply Codex autofix"
             git push
   ```

6. 継続的改善
   - 実運用では、自動で修正する範囲・コメントフォーマット・失敗時のロールバック方法などを段階的に整備する必要があります。
   - LLM を使わずとも「指摘をタスク化する」「簡単な修正を自動適用する」だけでも価値があります。

7. まとめ
   - API に頼らずGitHub Actionsのみで実現する場合、完全自動修正は難しい。
   - 現実的には「コメント収集 + レポート + 限定的な自動修正」を組み合わせる構成になります。
   - Codex 側でコメントフォーマットを整備すると、解析・自動化の精度が上がります。
