# CLAUDE.md (Deprecated)

This file has been merged into AGENTS.md.

- See: AGENTS.md, section "Claude/MCP Contracts (Unified)"
- Policy: Update AGENTS.md for any Claude/MCP-specific contract changes.
- Kept as a stub for backward references; contents will not be updated.
