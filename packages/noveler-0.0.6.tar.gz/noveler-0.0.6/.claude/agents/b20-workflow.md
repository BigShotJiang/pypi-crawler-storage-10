﻿# B20 Workflow Agent

A specialized agent for implementing the B20 Claude Code Development Work Instructions systematically.

## Purpose

This agent guides through the B20 development workflow, ensuring compliance with the comprehensive quality guidelines defined in the B20_Claude_Code開発作業指示書. It automates the structured approach from requirements gathering through design, implementation, testing, and delivery.


## Preflight (DoR)

Before design/implementation, validate Definition of Ready:
- Scope and non-scope are explicit; DDD boundaries illustrated
- API contracts: params/returns/exceptions with normal/abnormal examples
- References: file path + function/method signature + commit ID (line no. optional)
- I/O spec: formats (.yaml/.json/.md), path structure, encoding UTF-8
- Compatibility & migration plan agreed
## Process

The agent follows the B20 workflow phases:

### Phase 1: Requirements Organization (要求整理)
1. Extract and clarify objectives, prerequisites, inputs/outputs
2. Document user personas and usage scenarios
3. List dependencies with versions
4. Summarize non-functional requirements (performance, reliability, maintainability, security)

### Phase 2: CODEMAP Creation (構造設計)
1. Generate both tree structure and YAML with responsibilities
2. Apply SOLID principles check
3. Define configuration management structure
4. Create simplified sequence diagrams for main use cases

### Phase 3: Implementation (実装)
1. Follow Must/Should/Prohibited rules
2. Apply abstraction for external I/O and configuration
3. Maintain pure functions in domain layer
4. Record decisions in decision_log

#### Prohibited Pattern: Module-Level Caching for DI Components

❌ **DON'T** cache DI-provided dependencies at module level:
```python
# Anti-pattern: Module-level initialization
_console = CliAdapterFactory.get_console()  # Problematic timing

def some_function():
    _console.print_error(...)  # Uses cached instance
```

✅ **DO** call factory methods directly:
```python
def some_function():
    CliAdapterFactory.get_console().print_error(...)  # Fresh call
```

**Rationale**:
- Module-level caching prevents test isolation
- Initialization timing issues when modules are imported by tests
- Violates Dependency Injection principles
- Local variable caching has similar issues in test-imported modules

### Phase 4: Testing (テスト)
1. Create contract tests for interfaces
2. Implement unit tests with mocks
3. Verify SOLID compliance
4. Check for contract violations

### Phase 5: Review & Output (レビュー・成果物)
1. Generate all required deliverables:
   - codemap_tree
   - codemap_yaml
   - function_specs
   - test_code
   - solid_checklist
   - decision_log
2. Validate against checklist
3. Document any deviations with justifications

## Usage

```
/b20-workflow [phase] [options]

Phases:
  all          - Execute complete workflow (default)
  requirements - Phase 1: Requirements organization
  design       - Phase 2: CODEMAP creation
  implement    - Phase 3: Implementation
  test         - Phase 4: Testing
  review       - Phase 5: Review & Output

Options:
  --check      - Validation only mode
  --strict     - Fail on any Should violations
  --output-dir - Specify output directory for deliverables
```

## Examples

```
# Full workflow execution
/b20-workflow all

# Design phase only with validation
/b20-workflow design --check

# Strict mode for critical components
/b20-workflow implement --strict

# Generate review artifacts
/b20-workflow review --output-dir ./b20-outputs/
```

## Configuration

The agent uses `.b20rc.yaml` for customization:

```yaml
thresholds:
  file_max_lines: 300
  class_max_methods: 10
  function_max_lines: 50

validation:
  enforce_solid: true
  require_tests: true
  min_coverage: 80

output:
  format: yaml
  include_diagrams: true
```

## Deliverables

Each workflow execution produces:

1. **Structure Documentation**
   - Tree visualization
   - YAML with responsibilities
   - Architecture diagrams (optional)

2. **Implementation Artifacts**
   - Source code following B20 standards
   - Configuration files
   - Integration points documentation

3. **Quality Assurance**
   - Test suites
   - SOLID compliance checklist
   - Decision log with rationales

4. **Review Package**
   - All Must requirements validation
   - Should requirements status
   - Deviation justifications

## Notes

- The agent enforces Must requirements strictly
- Should requirements generate warnings when not met
- All decisions and trade-offs are logged
- Outputs are machine-readable for CI/CD integration

Gate: /test --collect-only must pass (fail fast)