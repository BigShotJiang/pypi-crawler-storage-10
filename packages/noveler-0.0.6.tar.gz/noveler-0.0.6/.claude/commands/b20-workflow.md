﻿---
description: B20 Claude Code開発作業指示書に基づく体系的な開発ワークフロー実行
argument-hint: [phase] [options]
---

You are executing the B20 development workflow as defined in `.b20rc.yaml` and `.claude/agents/b20-workflow.md`.

## Arguments Received

Phase: `$1` (default: all)
Options: `$2 $3 $4 $5`

## Context

**Configuration File:** `.b20rc.yaml`
**Agent Specification:** `.claude/agents/b20-workflow.md`
**Guide Reference:** `docs/B20_CL~1.MD` (B20 Claude Code開発ガイド統合版; lessons 2025-10-04)

## Phase Selection

Requested phase: `$1`
- `all` → Execute complete workflow (default)
- `requirements` → Phase 1: 要求整理
- `design` → Phase 2: CODEMAP作成
- `implement` → Phase 3: 実装
- `test` → Phase 4: テスト
- `review` → Phase 5: レビュー・成果物

## Workflow Execution Instructions

First, load and validate configuration from `.b20rc.yaml`:
- Read all thresholds (file_max_lines, class_max_methods, etc.)
- Read SOLID validation settings
- Read testing requirements (min_coverage, contract_tests)
- Read output contract (must_keys, optional_keys)
- Read operation_mode (strict, dry_run, verbose)

Then execute the requested phase(s):
### Gates (minimal, mandatory)

- Test Collect Gate: Run `/test --collect-only` and stop if it fails.
  - Purpose: ensure tests import/collect before heavy runs.
  - Timing: automatically between Implementation and Testing; or when phase is `test` or `all`.

#### Encoding Scan (warn-only)

- Purpose: detect replacement character "�" (U+FFFD) to catch mojibake early; warn-only (does not stop workflow).
- PowerShell example:
  Select-String -Path docs\\**\\*.md,src\\**\\*.py -SimpleMatch -Pattern "�" | ForEach-Object { $_.Path }
### Phase 1: Requirements Organization (要求整理)

**Tasks:**
1. Extract and clarify objectives, prerequisites, inputs/outputs
2. Document user personas and usage scenarios
3. List dependencies with versions
4. Summarize non-functional requirements:
   - Performance targets
   - Reliability requirements
   - Maintainability criteria
   - Security considerations

**Output Format:** Markdown
**Deliverables:**
- requirements.md with structured sections
- dependency_list.yaml
- nfr_summary.md

### Phase 2: CODEMAP Creation (構造設計)

**Tasks:**
1. Generate tree structure showing all components
2. Create YAML with component responsibilities
3. Apply SOLID principles validation:
   - SRP: Single Responsibility (max_responsibilities from config)
   - OCP: Open/Closed (check extension points)
   - LSP: Liskov Substitution (check contracts)
   - ISP: Interface Segregation (max_interface_methods from config)
   - DIP: Dependency Inversion (check abstractions)
4. Define configuration management structure
5. Create simplified sequence diagrams for main use cases

**Output Format:** YAML + Markdown
**Deliverables:**
- codemap_tree.txt (tree visualization)
- codemap_yaml.yaml (structured responsibilities)
- solid_validation.md (compliance report)
- sequence_diagrams.md (optional)

### Phase 3: Implementation (実装)

**Tasks:**
1. Follow Must/Should/Prohibited rules from guide
2. Apply abstraction for:
   - External I/O operations
   - Configuration access
   - Third-party integrations
3. Maintain pure functions in domain layer
4. Record ALL decisions in decision_log.yaml with:
   - timestamp
   - decision_type
   - rationale
   - alternatives_considered
   - impact_assessment

**Threshold Enforcement:**
- file_max_lines: {threshold from config}
- class_max_methods: {threshold from config}
- function_max_lines: {threshold from config}
- method_complexity: {threshold from config}
- nesting_depth: {threshold from config}

**Output Format:** Source code + YAML
**Deliverables:**
- Implemented source files
- Configuration files
- decision_log.yaml

### Phase 4: Testing 

0. Gate: /test --collect-only must pass (mandatory)
0. Gate: /test --collect-only must pass (mandatory)(テスト)

**Tasks:**
1. Create contract tests for all public interfaces
2. Implement unit tests with proper mocks
3. Verify SOLID compliance using checklist
4. Check for contract violations:
   - return_type_change
   - parameter_removal
   - exception_type_change
   - precondition_strengthening
   - postcondition_weakening
5. Ensure minimum coverage: {required_coverage from config}%

**Test Types Required:**
- unit
- integration
- contract

**Output Format:** Python + YAML
**Deliverables:**
- test_*.py files
- solid_checklist.yaml
- contract_violations_report.md (if any)
- coverage_report.txt

### Phase 5: Review & Output (レビュー・成果物)

**Tasks:**
1. Generate ALL required deliverables (must_keys from config):
   - codemap_tree
   - codemap_yaml
   - function_specs
   - test_code
   - solid_checklist
   - decision_log
2. Generate optional deliverables (optional_keys from config):
   - architecture_diagram
   - sequence_diagram
   - performance_report
3. Validate against output contract
4. Document any deviations with justifications
5. Save to output directory: {workflow.phases.review.output_dir from config}
6. **Update project management artifacts**:
   - **TODO.md**: Mark completed tasks, add new tasks if needed
   - **CHANGELOG.md**: Add project completion entry under `## [Unreleased]` with:
     - Project name and overall score
     - Purpose and implementation summary
     - Quality metrics (SOLID, test coverage, risk level)
     - Commit hashes
     - Deliverables list with links
   - **README.md**: Add completion record (if applicable)
7. **Create Git commits and tag**:
   - Create 2-3 separate commits:
     - Implementation commit (source code changes)
     - Deliverables commit (B20 artifacts)
     - Documentation commit (README/CHANGELOG/TODO updates)
   - Create Git tag: `b20-<project-name>-v<version>` (e.g., `b20-settings-path-v1.0.0`)
   - Push to remote if `--push` option specified

**Output Format:** Complete package
**Deliverables:**
- All must_keys artifacts
- Optional artifacts (if applicable)
- deviation_justifications.md (if any)
- final_summary.md
- Updated TODO.md (with completion status)
- Updated CHANGELOG.md (with project entry)
- Updated README.md (if applicable)
- Git commits (2-3 commits)
- Git tag for version tracking

## Quality Validation (All Phases)

After each phase:
1. Run applicable CI hooks from `.b20rc.yaml`
2. Verify Must requirements (strict enforcement)
3. Report Should requirements status
4. Generate phase-specific metrics

## Options Handling

Parse options from `$2 $3 $4 $5`:
- `--check`: Validation only mode (no file modifications)
- `--strict`: Fail on ANY Should violations (not just Must)
- `--output-dir <path>`: Override default output directory
- `--verbose`: Enable detailed logging
- `--dry-run`: Show what would be done without executing (including Git operations)
- `--push`: Push Git commits and tags to remote (Phase 5 only)
- `--contract-baseline`: Verify minimal contract tests (warn-only if missing)
  - SessionGenerator baseline: tests/contracts/test_session_generator_contract.py（collect-onlyで検知）
- `--scan-encoding`: Warn-only scan for replacement character (�) in docs/src

## Execution Flow

1. **Validate Arguments**
   - Check phase is valid (all/requirements/design/implement/test/review)
   - Parse and validate options

2. **Load Configuration**
   - Read `.b20rc.yaml`
   - Validate all required sections exist
   - Apply operation_mode settings

3. **Execute Phase(s)**
   - If phase == "all", execute all 5 phases in sequence
   - Otherwise, execute only the specified phase
   - Apply validation at each step
   - Enforce Test Collect Gate before running tests (fail fast)

4. **Generate Report**
   - Summarize completed tasks
   - List all generated artifacts with file paths
   - Report any Must requirement violations
   - Report Should requirement status
   - Provide recommendations

## Output Requirements (Japanese)

すべての出力は日本語で報告してください：

1. **進捗報告**
   - 現在のフェーズとタスク
   - 検証結果（合格/不合格と詳細）
   - 生成されたアーティファクト（ファイルパス）

2. **警告と逸脱**
   - Must要件違反（即座に報告）
   - Should要件未達成（警告として報告）
   - 正当化理由の記録

3. **次のアクション**
   - 推奨される次のステップ
   - 未解決の問題
   - フォローアップタスク

## Success Criteria

- ✅ All Must requirements validated
- ✅ Should requirements met or justified
- ✅ Minimum test coverage achieved
- ✅ SOLID principles verified
- ✅ All required deliverables generated
- ✅ Decision log complete with rationales

---

**Now execute the B20 workflow with the provided arguments.**

Report clearly in Japanese showing progress, validations, artifacts, and recommendations.
