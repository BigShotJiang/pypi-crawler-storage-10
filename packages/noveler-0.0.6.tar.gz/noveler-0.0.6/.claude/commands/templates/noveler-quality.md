---
allowed-tools: [
  "mcp__noveler__run_quality_checks",
  "mcp__noveler__fix_quality_issues",
  "mcp__noveler__improve_quality_until"
]
description: "Noveler quality checking and auto-fix"
---

# /noveler-quality - 品質チェック

第{episode}話の品質チェックを実行します。

使用方法: /noveler-quality {episode_number}

例:
- /noveler-quality 1  → 第1話の品質チェック
- /noveler-quality 3  → 第3話の品質チェック

## 自動実行フロー

1. run_quality_checks で問題を検出
2. fix_quality_issues で自動修正可能な問題を修正
3. improve_quality_until で目標スコアまで反復改善

全プロジェクトで利用可能なグローバルコマンドです。
