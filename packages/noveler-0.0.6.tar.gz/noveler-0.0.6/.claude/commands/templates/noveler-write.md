---
allowed-tools: [
  "mcp__noveler__enhanced_get_writing_tasks",
  "mcp__noveler__enhanced_execute_writing_step",
  "mcp__noveler__polish_manuscript",
  "mcp__noveler__polish_manuscript_apply"
]
description: "Noveler writing workflow - 18-step system with A28 templates"
---

# /noveler-write - 統合執筆ワークフロー

第{episode}話の執筆を開始します。

使用方法: /noveler-write {episode_number}

例:
- /noveler-write 1  → 第1話の執筆タスクを取得して実行
- /noveler-write 3  → 第3話の執筆タスクを取得して実行

## 自動実行フロー

1. enhanced_get_writing_tasks でタスクリストを取得
2. 次に実行すべきステップを確認
3. enhanced_execute_writing_step で実行
4. 完了後、品質チェックを推奨

全プロジェクトで利用可能なグローバルコマンドです。
