---
allowed-tools: [
  "backup_management",
  "restore_manuscript_from_artifact",
  "list_artifacts",
  "fetch_artifact",
  "get_file_by_hash",
  "list_files_with_hashes",
  "get_file_reference_info"
]
argument-hint: "<op> episode=<episode_number> [--artifact-id ID] [--file-path PATH]"
description: "Backup, list, fetch, and restore operations (no editing beyond restore)"
---

# Noveler Backup / Restore

Last Updated: 2025-10-10

## Quick Reference
- `/noveler_backup create episode=1 --pattern 40_原稿/**/*.md` → backup_management(op=create)
- `/noveler_backup list` → list_artifacts
- `/noveler_backup restore episode=1 --artifact-id ART-20251010-001 --file-path 40_原稿/ep001_scene1.md` → restore_manuscript_from_artifact

## Argument-Driven Execution

- Syntax: `/noveler_backup <alias> [episode=<episode_number>] [options]`
- Ops aliases:
  - `create` / `delete` / `restore` → backup_management（`op` 指定）
  - `list` → list_artifacts
  - `fetch` → fetch_artifact
  - `hash` → get_file_by_hash / list_files_with_hashes / get_file_reference_info
- ルーティング: エイリアスから対象ツールと `op` を解決 → 必要な引数を JSON に整形 → MCP ツール呼び出し。
- 共通オプション:
  - `--artifact-id` : 対象アーティファクト ID
  - `--file-path` : 復元対象ファイル（スコープ指定）
  - `--destination` : 取得先ディレクトリ
  - `--pattern` : バックアップ対象グロブ

Examples:
- `/noveler_backup create episode=3 --pattern docs/drafts/**/*.md`
- `/noveler_backup fetch --artifact-id ART-20251010-001 --destination temp/restores`
- `/noveler_backup hash --artifact-id ART-20251010-001`

## Workflow Templates
- **Create & Verify**: backup_management(op=create) → list_artifacts で登録確認。
- **Temp Restore Drill**: restore_manuscript_from_artifact（destination=temp path）→ diff で内容確認 → 必要なら本番に反映。
- **Targeted Restore**: restore_manuscript_from_artifact（file_path 指定）→ run_quality_checks → git diff を確認。

## Tool Map
- backup_management: create/list/delete/restore の統合入口
- list_artifacts: アーティファクト一覧
- fetch_artifact: 外部保存用にアーティファクトを取得
- restore_manuscript_from_artifact: ファイル単位または全体を復元
- get_file_by_hash / list_files_with_hashes / get_file_reference_info: ハッシュベースの整合性チェック

## Output / Artifacts
- アーティファクト ID は `ART-<date>-<counter>` 形式。復元ログとともに issue/commit に記録。
- `fetch_artifact` は base64/zip 等のメタデータを返すため、検証時は temp ディレクトリに展開。

## Operations & Options
- `backup_management`:
  - `op=create|list|restore|delete`
  - `pattern` : バックアップ対象のグロブ
  - `destination` : `restore` 時の書き込み先（未指定時はカタログ既定）
- `list_artifacts`:
  - `pattern` / `limit`
- `fetch_artifact`:
  - `artifact_id`, `destination`
- `restore_manuscript_from_artifact`:
  - `artifact_id`, `file_path`, `destination`
- ハッシュ系ツール:
  - `hash` / `file_paths`

## Safety Guidelines
- 直接本番ファイルに復元せず、まずテンポラリに展開して差分を確認。
- 復元後は `run_quality_checks` と git diff を実施し、予期せぬ変更を検出。
- バックアップ作成時はコミットメッセージや TODO にアーティファクト ID を残す。

## Troubleshooting
- アーティファクトが見つからない: `pattern` / `episode` 指定を確認。
- 復元先に書き込めない: `destination` の権限と存在を確認。
- ハッシュ不一致: `list_files_with_hashes` で最新ハッシュを再取得し、対象ファイルを手動で確認。

## Changelog
- 2025-10-07: Added templates/tool map/output modes; temp-restore drill clarified.
- 2025-10-10: MCP ツール名を正規化し、エイリアス/オプション説明を追記。
