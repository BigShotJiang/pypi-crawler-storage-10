---
allowed-tools: [
  "mcp__noveler__polish_manuscript",
  "mcp__noveler__polish_manuscript_apply",
  "mcp__noveler__polish"
]
description: "Noveler manuscript polishing - A40 integrated workflow"
---

# /noveler-polish - 原稿推敲

第{episode}話をA40統合ワークフロー（Stage2/3）で推敲します。

使用方法: /noveler-polish {episode_number}

例:
- /noveler-polish 1  → 第1話の推敲（プレビュー → 適用）
- /noveler-polish 3  → 第3話の推敲

## 自動実行フロー

1. polish_manuscript でプレビュー（dry_run=true）
2. 結果を確認
3. polish_manuscript_apply で適用（ユーザー承認後）

全プロジェクトで利用可能なグローバルコマンドです。
