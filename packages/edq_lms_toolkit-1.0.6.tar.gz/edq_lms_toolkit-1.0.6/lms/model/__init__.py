"""
The `lms.model` package provides the base types used throughout this project.
Most of these types are written to be general,
and may be extended by specific backends to include information specific to their LMS.
"""
