# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0-alpha.5](https://github.com/lox-space/lox/compare/lox-derive-v0.1.0-alpha.4...lox-derive-v0.1.0-alpha.5) - 2025-10-29

### Added

- *(lox-test-utils)* add ApproxEq derive macro
- *(lox-derive)* implement OffsetProvider derive macro

### Other

- update SPDX headers and add helper script
- make Lox REUSE-compliant
- get rid of float_eq and lox_math::is_close
- *(lox-units)* make Angle value private

## [0.1.0-alpha.4](https://github.com/lox-space/lox/compare/lox-derive-v0.1.0-alpha.3...lox-derive-v0.1.0-alpha.4) - 2025-07-01

### Other

- fix clippy lints

## [0.1.0-alpha.3](https://github.com/lox-space/lox/compare/lox-derive-v0.1.0-alpha.2...lox-derive-v0.1.0-alpha.3) - 2025-06-19

### Other

- fix clippy lints

## [0.1.0-alpha.2](https://github.com/lox-space/lox/compare/lox-derive-v0.1.0-alpha.1...lox-derive-v0.1.0-alpha.2) - 2025-03-04

### Other

- update formatting

## [0.1.0-alpha.1](https://github.com/lox-space/lox/compare/lox-derive-v0.1.0-alpha.0...lox-derive-v0.1.0-alpha.1) - 2025-01-24

### Other

- Use type segments instead for spans

## [0.1.0-alpha.0](https://github.com/lox-space/lox/releases/tag/lox-derive-v0.1.0-alpha.0) - 2024-07-19

### Other
- Add crate descriptions ([#145](https://github.com/lox-space/lox/pull/145))
- Align versions ([#143](https://github.com/lox-space/lox/pull/143))
- Release preparation ([#140](https://github.com/lox-space/lox/pull/140))
- Add support for empty lines
- Get clippy happy
- Change vec reference to slice
- Implement field prefix and postfix checking
- Give better names than blalla
- Programmatic deser OemCovarianceMatrixType
- Break out the parser from struct construction
- Improve variable name
- Implement support for META_START and META_STOP
- Add deserializers for OEM subtypes
- Add retries for support for nested Vecs
- Clean-up variable name
- Use original type ident for vec type
- Add support for multi-segment types
- Clean-up vec type generator
- Get rid of the second _new usage
- Get rid of one _new usage
- First step in unifying the parser chains
- Remove duplicate call chain
- Remove _new suffix from parsers
- Drop _new suffix for type argument getter
- Remove nom types
- Encapsulate kvn string split
- Make the check more idiomatic
- Make error payload an owned string
- Fix usage of date time parser
- Simplify unamed fields handling
- Simplify  version field handling by reodering
- Remove special case the EpochType
- Make list order match the nested match
- Reexport the KVN deserializer types
- Make clippy happy
- Remove unused variable
- Remove leftover trailing whitespace
- Fix formatting
- Fix crate name case
