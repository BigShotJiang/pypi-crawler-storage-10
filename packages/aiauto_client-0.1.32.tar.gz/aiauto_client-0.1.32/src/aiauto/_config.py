# For Connect RPC over HTTP
AIAUTO_API_TARGET = "api.common.aiauto.pangyo.ainode.ai:443"
