#!/usr/bin/env python3
"""
测试白名单模式（无鉴权）

这个脚本测试 SDK 在白名单环境下是否能正常工作（不提供 api_key 或 jwt_token）
"""

from gateway_sdk import GatewayClient

def test_whitelist_mode():
    """测试白名单模式创建客户端"""
    
    print("🧪 测试 1: 无参数创建客户端")
    try:
        # ✅ 在白名单环境下，可以直接创建客户端
        client = GatewayClient()
        print("   ✅ 客户端创建成功（无鉴权模式）")
        print(f"   - Gateway URL: {client.base_url}")
        print(f"   - 超时设置: {client.timeout}秒")
        print(f"   - 鉴权状态: {'已配置' if client.auth.is_authenticated() else '未配置（白名单模式）'}")
    except Exception as e:
        print(f"   ❌ 失败: {e}")
        return False
    
    print("\n🧪 测试 2: 调用预制件（需要白名单环境）")
    print("   ⚠️  注意: 这个测试只有在白名单环境下才能成功")
    print("   如果不在白名单环境下，会返回 401 认证错误，这是正常的")
    
    try:
        result = client.run(
            prefab_id="video-processing-prefab",
            version="0.3.1",
            function_name="video_to_audio",
            parameters={},
            files={"input": ["s3://test-bucket/sample.mp4"]}
        )
        
        if result.is_success():
            print("   ✅ 预制件调用成功（白名单环境确认）")
            function_result = result.get_function_result()
            print(f"   - 返回状态: {function_result}")
        else:
            print(f"   ⚠️  预制件调用返回失败: {result.error}")
            print("   这可能是业务逻辑错误，不是鉴权问题")
            
    except Exception as e:
        error_msg = str(e)
        if "401" in error_msg or "认证" in error_msg or "Unauthorized" in error_msg:
            print(f"   ⚠️  认证失败（预期行为，不在白名单环境下）")
            print(f"   错误信息: {error_msg}")
        else:
            print(f"   ❌ 其他错误: {error_msg}")
    
    print("\n" + "="*60)
    print("✅ SDK 无参数创建功能测试完成")
    print("="*60)
    print("\n📝 使用说明:")
    print("   在白名单环境（如 OpenHands）中，可以这样使用:")
    print("   ```python")
    print("   from gateway_sdk import GatewayClient")
    print("   client = GatewayClient()  # 无需提供 token")
    print("   result = client.run(...)")
    print("   ```")
    
    return True

if __name__ == "__main__":
    test_whitelist_mode()

