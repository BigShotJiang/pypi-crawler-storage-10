# Proseka
[![Athena Award Badge](https://img.shields.io/endpoint?url=https%3A%2F%2Faward.athena.hackclub.com%2Fapi%2Fbadge)](https://award.athena.hackclub.com?utm_source=readme)  
A WIP API wrapper for the game Hatsune Miku: Colorful Stage (Global Server). Currently has very limited functionality outside of general account creation and maintenance. 

## Installation
~~`python -m pip install proseka`~~ (soon)
## Installation from source
1. Clone the repository  
`git clone https://github.com/tailhaver/proseka`
2. Navigate to the created folder  
`cd proseka`
3. Install the plugin  
`pip install .`
## Building from source
### Prerequisites
 - [uv](https://docs.astral.sh/uv/getting-started/installation/)  
### Install Instructions
1. Clone the repository  
`git clone https://github.com/tailhaver/proseka`
2. Navigate to the created folder  
`cd proseka`
3. Install the plugin  
`uv build`

## Features
### Functional
- [x] Account creation and login
- [x] Transfer ID creation and validation
- [x] Account name, description, and title updates
- [x] Area conversation and story reading
- [x] Account lookup by ID and friend requests
- [x] Login bonus claims
- [x] Present opening
### Partially Implemented
- [ ] Card training and mastery (no skill up, no validation)
- [x] Event information (self only)
- [ ] Event shop purchases (no validation)
- [ ] Green room claims (no validation or easy usage)
- [ ] Stamp and costume purchases (no validation)
### Planned Features
- [ ] (!!) Sekai Client to wrap API requests (!!)
- [ ] (!!) Better API method documentation (!!)
- [ ] Area item purchases
- [ ] Energy restore (items and crystals)
- [ ] Event leaderboards
- [ ] Friend request listing and accepting
- [ ] Gacha listing and pulling
- [ ] Live show playback
- [ ] Song and cover purchases
- [ ] Team construction and modification
- [ ] Virtual live attendance

## why?
i am so fucking autistic. is that good enough, athena reviewer?  
in all seriousness, this has been something ive wanted to make (or been trying to make!) for over 3 years now. back in 2023-2024, i tried to manually extract the encryption keys from the game apk. lets just say im very bad at that. worlds best compsci major here!  
[when the global server api keys were finally leaked in late 2024](https://github.com/mos9527/sssekai/issues/8), i immediately begun chipping away at reverse engineering the api. after over a year, four entire codebase rewrites, multiple bans, and tens of hours banging my head against a wall, we're finally here. there is a _heavy_ emphasis on this being a WIP, since i wanted to publish this before the [hack club athena](https://award.athena.hackclub.com/) deadline. 

## how?
[http toolkit](https://httptoolkit.com/), wsa, and a dream. two dreams actually the first dream is to look like saki tenma in real life.  
ive had so many sleepless nights making this stupid taptap game wrapper. i have no clue how im alive. i did get to learn how to make my own api wrapper though! ive experimented with it a bit before (hyperion, an abandoned hypixel api), but never to this extent.