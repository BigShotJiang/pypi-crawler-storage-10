import logging
import coloredlogs
import sys

coloredlogs.install(
    level=logging.INFO,
    fmt="%(asctime)s %(name)s [%(levelname).4s] %(message)s",
    isatty=True,
    stream=sys.stdout,
)

logging.basicConfig(
    level=logging.INFO,
    format="[%(levelname).4s] %(name)s %(message)s",
    stream=sys.stdout,
)

logging.getLogger("httpx").setLevel(logging.WARNING)

from .api import API