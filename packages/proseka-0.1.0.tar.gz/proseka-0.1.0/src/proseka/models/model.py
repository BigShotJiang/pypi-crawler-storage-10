import re

class Model:
    @staticmethod
    def update(data: dict, cls: type):
        # filter out all non-variables from cls.__dict__
        pairs = dict(filter(lambda x: not x[0].startswith("__") and not callable(x[1]), vars(cls).items()))
        for item in data:
            # replace all instances of an uppercase letter (A) with an underscore followed by the character in lowercase (_a)
            key = re.sub(r'(?<!^)(?=[A-Z])', '_', item).lower()
            if key in pairs:
                setattr(cls, key, data[item])