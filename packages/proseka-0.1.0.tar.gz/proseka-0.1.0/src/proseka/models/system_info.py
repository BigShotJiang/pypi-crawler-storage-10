from .model import Model

class SystemInfo(Model):
    system_profile = None
    app_version = None
    multi_play_version = None
    data_version = None
    asset_version = None
    app_hash = None
    asset_hash = None
    app_version_status = None

    @staticmethod
    def update(data: dict) -> None:
        appVersions = data.get("appVersions")
        super(__class__, __class__).update(appVersions[-1], __class__) # what the fuck?
    
    @staticmethod
    def direct_update(data: dict) -> None:
        super(__class__, __class__).update(data, __class__)