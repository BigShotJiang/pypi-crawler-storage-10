from .model import Model
from uuid import uuid4

class DeviceInfo(Model):
    platform = "Android"
    device_model = "LGE Nexus 5"
    operating_system = "Android OS 13 / API-33 (TQ3A.230901.001/2407.40000.4.0)"
    install_id = uuid4()