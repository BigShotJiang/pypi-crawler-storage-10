
# SEJUNK Validator

Sistema de validación de licencias con algoritmo de codificación SEJUNK.

## Instalación

```bash
pip install sejunk-validator
```

## Uso

### Desde línea de comandos:
```bash
sejunk-validator
```

### Desde Python:
```python
from sejunk_validator import generar_licencia_software, validar_licencia_software

# Generar licencia
licencia = generar_licencia_software("cliente@email.com", "30d")

# Validar licencia
valido, mensaje = validar_licencia_software(licencia)
```

## Características

- Codificación/decodificación de texto
- Generación y validación de licencias
- Soporte para múltiples duraciones (días, meses, años)
- Mantenimiento de mayúsculas/minúsculas


### LICENSE (MIT License)

```text
MIT License

Copyright (c) 2024 Rodrigo Quintanar

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```



