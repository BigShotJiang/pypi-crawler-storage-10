from .sejunk import (
    quitar_acentos,
    crear_diccionarios,
    codificar_caracter,
    extraer_secuencia_codificada,
    decodificar_caracter,
    codificar_texto,
    decodificar_texto
)

__version__ = "1.3.0"
__author__ = "Rodrigo Quintanar"
__email__ = "quintanar.rodrigo@outlook.com"
