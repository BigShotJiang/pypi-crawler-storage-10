import unicodedata

def quitar_acentos(texto):
    """Elimina acentos de un texto pero mantiene mayúsculas/minúsculas"""
    texto_normalizado = unicodedata.normalize('NFD', texto)
    texto_sin_acentos = ''.join(
        c for c in texto_normalizado
        if unicodedata.category(c) != 'Mn'
    )
    return texto_sin_acentos

def crear_diccionarios():
    """Crea los diccionarios para letras, números y símbolos"""
    letras_minusculas = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 
                        'n', 'ñ', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
    
    letras_mayusculas = [letra.upper() for letra in letras_minusculas]
    
    todas_letras = letras_minusculas + letras_mayusculas
    
    numero_a_letra_minuscula = {
        '0': 'z', '1': 'y', '2': 'x', '3': 'w', '4': 'v',
        '5': 'u', '6': 't', '7': 's', '8': 'r', '9': 'q'
    }
    
    numero_a_letra_mayuscula = {
        '0': 'Z', '1': 'Y', '2': 'X', '3': 'W', '4': 'V',
        '5': 'U', '6': 'T', '7': 'S', '8': 'R', '9': 'Q'
    }
    
    letra_a_numero_minuscula = {v: k for k, v in numero_a_letra_minuscula.items()}
    letra_a_numero_mayuscula = {v: k for k, v in numero_a_letra_mayuscula.items()}
    letra_a_numero = {**letra_a_numero_minuscula, **letra_a_numero_mayuscula}
    
    letra_a_pos = {}
    for idx, letra in enumerate(letras_minusculas, 1):
        letra_a_pos[letra] = idx
    for idx, letra in enumerate(letras_mayusculas, 1):
        letra_a_pos[letra] = idx
    
    pos_a_letra_minuscula = {}
    for idx, letra in enumerate(letras_minusculas, 1):
        pos_a_letra_minuscula[idx] = letra
    
    pos_a_letra_mayuscula = {}
    for idx, letra in enumerate(letras_mayusculas, 1):
        pos_a_letra_mayuscula[idx] = letra
    
    simbolos = {
        10: '!',
        15: '*',
        20: '_',
        25: '$'
    }
    
    simbolo_a_num = {v: k for k, v in simbolos.items()}
    
    return (letra_a_pos, pos_a_letra_minuscula, pos_a_letra_mayuscula, 
            simbolos, simbolo_a_num, numero_a_letra_minuscula, 
            numero_a_letra_mayuscula, letra_a_numero)

def codificar_caracter(caracter, contador):
    """
    Codifica un solo carácter (letra o número) según el algoritmo
    """
    (letra_a_pos, pos_a_letra_minuscula, pos_a_letra_mayuscula, 
     simbolos, _, numero_a_letra_minuscula, numero_a_letra_mayuscula, _) = crear_diccionarios()
    
    if caracter == ' ':
        return "&6"
    
    elif caracter.isdigit():
        es_mayuscula = False
        
        if es_mayuscula:
            letra_base = numero_a_letra_mayuscula[caracter]
            pos_a_letra = pos_a_letra_mayuscula
        else:
            letra_base = numero_a_letra_minuscula[caracter]
            pos_a_letra = pos_a_letra_minuscula
        
        pos_base = letra_a_pos[letra_base]
        
        nueva_pos = (pos_base + contador - 1) % 27 + 1
        
        nueva_letra = pos_a_letra[nueva_pos]
        
        if nueva_pos in simbolos:
            return f"{nueva_letra}%{simbolos[nueva_pos]}"
        else:
            return f"{nueva_letra}%{nueva_pos:02d}"
    
    elif caracter in letra_a_pos:
        es_mayuscula = caracter.isupper()
        
        if es_mayuscula:
            pos_a_letra = pos_a_letra_mayuscula
        else:
            pos_a_letra = pos_a_letra_minuscula
        
        pos_actual = letra_a_pos[caracter]
        
        nueva_pos = (pos_actual + contador - 1) % 27 + 1
        
        nueva_letra = pos_a_letra[nueva_pos]
        
        if nueva_pos in simbolos:
            return f"{nueva_letra}{simbolos[nueva_pos]}"
        else:
            return f"{nueva_letra}{nueva_pos:02d}"
    
    else:
        return caracter

def extraer_secuencia_codificada(codificado, i):
    """
    Extrae una secuencia codificada completa desde la posición i
    """
    if i >= len(codificado):
        return "", i
    
    if i + 1 < len(codificado) and codificado[i:i+2] == "&6":
        return "&6", i + 2
    
    if codificado[i].isalpha():
        j = i + 1
        
        while j < len(codificado):
            if (j + 1 < len(codificado) and codificado[j:j+2] == "&6") or codificado[j].isalpha():
                break
            
            if codificado[j] in ['!', '*', '_', '$', '%']:
                j += 1
                while j < len(codificado) and codificado[j].isdigit():
                    j += 1
                break
            
            if codificado[j].isdigit():
                j += 1
            else:
                break
        
        return codificado[i:j], j
    
    return codificado[i], i + 1

def decodificar_caracter(secuencia, contador):
    """
    Decodifica una secuencia codificada
    """
    (letra_a_pos, pos_a_letra_minuscula, pos_a_letra_mayuscula, 
     _, simbolo_a_num, _, _, letra_a_numero) = crear_diccionarios()
    
    if secuencia == "&6":
        return ' ', False
    
    if '%' in secuencia:
        partes = secuencia.split('%', 1)
        if len(partes) == 2:
            letra_cod = partes[0]
            codigo = partes[1]
            
            if letra_cod not in letra_a_pos:
                return secuencia, False
            
            es_mayuscula = letra_cod.isupper()
            
            if es_mayuscula:
                pos_a_letra = pos_a_letra_mayuscula
            else:
                pos_a_letra = pos_a_letra_minuscula
            
            if codigo in simbolo_a_num:
                nueva_pos = simbolo_a_num[codigo]
            else:
                try:
                    nueva_pos = int(codigo)
                except ValueError:
                    return secuencia, False
            
            pos_original = (nueva_pos - contador - 1) % 27 + 1
            
            if pos_original in pos_a_letra:
                letra_original = pos_a_letra[pos_original]
                
                if letra_original in letra_a_numero:
                    return letra_a_numero[letra_original], True
    
    if len(secuencia) >= 2 and secuencia[0].isalpha():
        letra_cod = secuencia[0]
        codigo = secuencia[1:]
        
        if letra_cod not in letra_a_pos:
            return secuencia, False
        
        es_mayuscula = letra_cod.isupper()
        
        if es_mayuscula:
            pos_a_letra = pos_a_letra_mayuscula
        else:
            pos_a_letra = pos_a_letra_minuscula
        
        if codigo in simbolo_a_num:
            nueva_pos = simbolo_a_num[codigo]
        else:
            try:
                nueva_pos = int(codigo)
            except ValueError:
                return secuencia, False
        
        pos_original = (nueva_pos - contador - 1) % 27 + 1
        
        if pos_original in pos_a_letra:
            return pos_a_letra[pos_original], True
    
    return secuencia, False

def codificar_texto(texto, numero_inicio):
    """
    Codifica un texto completo manteniendo mayúsculas/minúsculas
    """
    texto_limpio = quitar_acentos(texto)
    resultado = ""
    contador = numero_inicio
    
    for caracter in texto_limpio:
        if caracter.isalnum() or caracter == ' ':
            codificado = codificar_caracter(caracter, contador)
            resultado += codificado
            
            if caracter != ' ':
                contador += 1
        else:
            resultado += caracter
    
    return resultado

def decodificar_texto(codificado, numero_inicio):
    """
    Decodifica un texto codificado manteniendo mayúsculas/minúsculas
    """
    resultado = ""
    contador = numero_inicio
    i = 0
    
    while i < len(codificado):
        secuencia, next_i = extraer_secuencia_codificada(codificado, i)
        
        if secuencia:
            decodificado, incrementar = decodificar_caracter(secuencia, contador)
            resultado += decodificado
            if incrementar:
                contador += 1
            i = next_i
        else:
            i += 1
    
    return resultado

# def main():
    while True:
        print("\nOpciones:")
        print("1. Codificar palabra/texto")
        print("2. Decodificar palabra/texto")
        print("3. Salir")
        
        opcion = input("Selecciona una opción (1-3): ").strip()
        
        if opcion == "1":
            texto = input("Ingresa la palabra o texto a codificar: ").strip()
            try:
                numero_inicio = int(input("Ingresa el número de inicio (1-26): ").strip())
                resultado = codificar_texto(texto, numero_inicio)
                print(f"\nTexto original: '{texto}'")
                print(f"Número de inicio: {numero_inicio}")
                print(f"Resultado codificado: {resultado}")
            except ValueError:
                print("Error: El número de inicio debe ser un entero válido")
                
        elif opcion == "2":
            codificado = input("Ingresa la cadena codificada: ").strip()
            try:
                numero_inicio = int(input("Ingresa el número de inicio (1-26): ").strip())
                resultado = decodificar_texto(codificado, numero_inicio)
                print(f"\nCadena codificada: {codificado}")
                print(f"Número de inicio: {numero_inicio}")
                print(f"Texto decodificado: '{resultado}'")
            except ValueError:
                print("Error: El número de inicio debe ser un entero válido")
                
        elif opcion == "3":
            print("¡Hasta luego!")
            break
            
        else:
            print("Opción no válida. Por favor selecciona 1, 2 o 3.")

if __name__ == "__main__":
    main()
