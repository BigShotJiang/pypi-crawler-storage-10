"""Configuration for Foundry DevTools."""
