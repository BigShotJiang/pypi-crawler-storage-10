"""Merck KGaA, Darmstadt, Germany 2023."""
