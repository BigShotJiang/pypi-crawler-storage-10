---
hide-toc: true
---

# EYConf

EyConf is a Python package that allows you to quickly create yaml based configuration files for your Python projects.

## Features

```{include} ../README.md
:start-after: <!-- start features -->
:end-before: <!-- end features -->
```


## Documentation

```{toctree}    
---
maxdepth: 1
---

getting-started
cli
contribution
faq
references
```

