_mask64 = (1 << 64) - 1

def _rotl(x,k):
    """rotate left 64 bit value x by k bits"""
    return ((x << k) & _mask64) | (x >> (64 - k))


class _splitmix64:
    """splitmix64 used for seeding other generators simple deterministic"""
    def __init__(self,seed):
        self.state = seed & _mask64

    def next_uint64(self):
        self.state = (self.state + 0x9e3779b97f4a7c15) & _mask64
        z = self.state
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9 & _mask64
        z = (z ^ (z >> 27)) * 0x94d049bb133111eb & _mask64
        return z ^ (z >> 31)


class _xoroshiro128plus:
    """xoroshiro128+ main prng fast good stats not crypto"""
    def __init__(self,s0,s1):
        self.s0 = s0 & _mask64
        self.s1 = s1 & _mask64
        if self.s0 ==0 and self.s1==0:
            self.s0 = 0xdeadbeefcafebabe
            self.s1 = 0x8badf00dfacefeed

    def next_uint64(self):
        s0 = self.s0
        s1 = self.s1
        result = (s0 + s1) & _mask64

        s1 ^= s0
        self.s0 = (_rotl(s0,55) ^ s1 ^ ((s1<<14)&_mask64)) & _mask64
        self.s1 = _rotl(s1,36) & _mask64
        return result


_global_prng = None
_gauss_cached = None

def seed(a=None):
    """seed global generator accepts int like or none"""
    global _global_prng,_gauss_cached
    _gauss_cached=None
    if a is None:
        s = (id(object()) ^ id(_global_prng) ^ 0x243f6a8885a308d3)&_mask64
    else:
        try:
            s=int(a)&_mask64
        except Exception:
            s=hash(a)&_mask64
    sm=_splitmix64(s)
    s0=sm.next_uint64()
    s1=sm.next_uint64()
    _global_prng=_xoroshiro128plus(s0,s1)

seed(0x123456789abcdef)

def getstate():
    """return internal state tuple useful for reproducibility"""
    return (_global_prng.s0,_global_prng.s1,_gauss_cached)

def setstate(state):
    """restore previously saved state"""
    global _global_prng,_gauss_cached
    s0,s1,gcache=state
    _gauss_cached=gcache
    _global_prng=_xoroshiro128plus(s0,s1)

def randuint64():
    """return 64 bit unsigned integer"""
    return _global_prng.next_uint64()

def randbits(k):
    if k<=0:
        return 0
    out=0
    bits=0
    while bits<k:
        take=min(64,k-bits)
        block=randuint64() & ((1<<take)-1)
        out|= (block<<bits)
        bits+=take
    return out

getrandbits=randbits

def randbelow(n):
    if n<=0:
        raise ValueError("n must be >0")
    limit=((1<<64)//n)*n
    while True:
        r=randuint64()
        if r<limit:
            return r%n

def random():
    return randbits(53)/float(1<<53)

def uniform(a,b):
    return a+(b-a)*random()

def randint(a,b):
    if a>b:
        raise ValueError("a must <= b")
    return a+randbelow(b-a+1)

def randrange(start,stop=None,step=1):
    if stop is None:
        stop=start
        start=0
    if step==0:
        raise ValueError("step must not zero")
    if (step>0 and start>=stop) or (step<0 and start<=stop):
        raise ValueError("empty range")
    if step>0:
        n=(stop-start+step-1)//step
    else:
        n=(start-stop-step-1)//(-step)
    return start+step*randbelow(n)

def choice(seq):
    if len(seq)==0:
        raise IndexError("cannot choose from empty")
    return seq[randbelow(len(seq))]

def shuffle(x):
    n=len(x)
    for i in range(n-1,0,-1):
        j=randbelow(i+1)
        x[i],x[j]=x[j],x[i]

def sample(pop,k):
    n=len(pop)
    if not 0<=k<=n:
        raise ValueError("sample too large or negative")
    pool=list(pop)
    for i in range(k):
        j=i+randbelow(n-i)
        pool[i],pool[j]=pool[j],pool[i]
    return pool[:k]

def choices(population,k=1,weights=None,cum_weights=None,*,replacement=True):
    n=len(population)
    if n==0:
        raise IndexError("empty population")
    if weights is not None and cum_weights is not None:
        raise TypeError("cannot supply both weights cum")
    if cum_weights is not None:
        cum=list(cum_weights)
        total=cum[-1]
    elif weights is not None:
        cum=[]
        s=0.0
        for w in weights:
            if w<0:
                raise ValueError("weights must be >=0")
            s+=w
            cum.append(s)
        total=s
    else:
        if replacement:
            return [population[randbelow(n)] for _ in range(k)]
        else:
            return sample(population,k)
    if total<=0:
        raise ValueError("total weights must >0")
    result=[]
    if replacement:
        for _ in range(k):
            r=random()*total
            idx=0
            while idx<n and r>=cum[idx]:
                idx+=1
            if idx>=n:
                idx=n-1
            result.append(population[idx])
    else:
        pop=list(population)
        weights_actual=[cum[0]]+[cum[i]-cum[i-1] for i in range(1,n)]
        for _ in range(k):
            total=sum(weights_actual)
            if total<=0:
                raise ValueError("not enough weights")
            r=random()*total
            acc=0.0
            idx=0
            while idx<len(weights_actual) and r>=acc+weights_actual[idx]:
                acc+=weights_actual[idx]
                idx+=1
            if idx>=len(pop):
                idx=len(pop)-1
            result.append(pop.pop(idx))
            weights_actual.pop(idx)
    return result

# ------------------------
# math approximations
# ------------------------


_pi  = 3.1415926535897932384626433832795028841971693993751
_two_pi = _pi * 2.0
_ln2 = 0.69314718055994530941723212145817656807550013436026

# ------------------ sqrt (Newton) ------------------
def _sqrt(x, iterations=20):
    """Newton-Raphson sqrt ohne Imports.
    - Für x <= 0 -> 0.0 (wie du vorher wolltest).
    - Skaliert x in einen günstigen Bereich, dann NR-Iterationen.
    """
    if x <= 0.0:
        return 0.0

    # Skalierung: bringe x in [0.25, 4) durch Multiplikation/Division mit 4
    # (4 = 2**2, so bleibt Wurzel-Verschiebung durch Faktor 2 einfach)
    exp = 0
    y = x
    while y >= 4.0:
        y *= 0.25  # y /= 4
        exp += 1
    while y < 0.25:
        y *= 4.0
        exp -= 1

    # gute Anfangsnäherung: eine einfache polynomial-Approximation für y in [0.25,4)
    # heuristisch: approx sqrt(y) ~ a + b*y + c/(y)  (kleine, stabile Approx.)
    # benutze eine robuste Startapprox:
    guess = 0.5901639448 + 0.5 * (y - 1.0)  # 0.590... ist ~sqrt(0.35) als Baseline
    # Falls y nahe 1 ist, setze besseres guess
    if 0.9 <= y <= 1.1:
        guess = 1.0
    # Newton-Raphson Iterationen
    for _ in range(iterations):
        # guess = 0.5*(guess + y/guess)
        guess = (guess + y/guess) * 0.5

    # Rückskalieren: sqrt(x) = sqrt(y) * 2**exp
    # exp entspricht Verschiebung um Faktor 2**exp
    # (weil wir skaliert haben mit 4**k => sqrt multipliziert mit 2**k)
    return guess * (2.0 ** exp)

# ------------------ ln (Mercator/atanh-ähnlich) ------------------
def _ln(x, terms=80):
    """Natürlicher Logarithmus ohne Imports.
    - DomainError für x <= 0 (ValueError).
    - Reduktion auf Bereich ~ [0.5, 2) durch Faktoren 2: ln(x) = ln(m) + k*ln2.
    - ln(m) wird über 2*sum_{n} ((y^(2n+1))/(2n+1)), y=(m-1)/(m+1) berechnet.
    """
    if x <= 0.0:
        raise ValueError("ln domain error")

    # Reduziere x in Bereich [0.5, 2)
    k = 0
    m = x
    while m >= 2.0:
        m *= 0.5
        k += 1
    while m < 0.5:
        m *= 2.0
        k -= 1

    # Mercator / atanh-form: ln(m) = 2 * ( y + y^3/3 + y^5/5 + ... ), y=(m-1)/(m+1)
    y = (m - 1.0) / (m + 1.0)
    y2 = y * y
    term = y
    s = 0.0
    n = 1
    # Summiere odd terms using recurrence term *= y2
    for _ in range(terms):
        s += term / n
        term *= y2
        n += 2
    ln_m = 2.0 * s

    return ln_m + k * _ln2

# ------------------ cos / sin (Range reduction + Taylor / Horner) ------------------
def _reduce_angle(x):
    """Reduziert Winkel auf [-pi, pi] ohne modulo-Operator mit floats, robust genug."""
    # bringe x in [-2pi, 2pi] schnell
    # nutze while-Schleifen (kein modulo), zieht oder addiert 2pi
    y = x
    # erste grobe Reduktion (schnellere Scalierung für große Werte)
    # falls sehr groß, nutze divison in integer-Schritten:
    if y > 0:
        k = int(y / _two_pi)
        y -= k * _two_pi
    else:
        k = int((-y) / _two_pi)
        y += k * _two_pi
    # noch sicherstellen in [-2pi, 2pi]
    while y > _pi:
        y -= _two_pi
    while y < -_pi:
        y += _two_pi
    return y

def _cos(x, terms=12):
    """Cos-Approximation:
    - Bereichsreduktion auf [-pi, pi]
    - Taylor mit Horner-artiger Auswertung (nur gerade Terme).
    - terms: Anzahl der benutzten Paare (je größer, desto genauer).
    """
    a = _reduce_angle(x)
    # Verwende Taylor: cos(a) = 1 - a^2/2! + a^4/4! - ...
    # Horner für gerade Potenzen:
    z = a * a
    # Baue Koeffizienten als 1/(2n)! in Horner-Form iterativ
    # Wir evaluieren von höchsten Term nach unten:
    # T_N(z) = 1 + z*(-1/2 + z*(1/24 + z*(-1/720 + ... )))
    # Erzeuge faktoriellen Koeffizienten via iterative Berechnung
    # Wir compute numerator sign and denom factorial progressively.
    # Einfacher: direkte rekursive Horner-Bildung:
    res = 0.0
    # Start von höchsten Term: for m = terms-1 downto 0
    # each term index t corresponds to power 2*t
    # coefficient = (-1)^t / (2*t)!
    # Build denom progressively
    denom = 1.0
    # compute (2*terms)! progressively to start value
    # We will compute coefficients on the fly inside loop for stability
    for t in range(terms - 1, -1, -1):
        # compute coefficient for t
        # compute factorial (2*t)! by iterative multiplication (cheap for small terms)
        fact = 1.0
        m = 2 * t
        for i in range(2, m + 1):
            fact *= i
        coeff = ( -1.0 if (t % 2 == 1) else 1.0 ) / fact
        res = res * z + coeff
    return res

def _sin(x, terms=12):
    """Sinus über Taylor (gerade Horner nicht direkt möglich für Sin)"""
    a = _reduce_angle(x)
    # sin(a) = a - a^3/3! + a^5/5! - ...
    z = a * a
    res = 0.0
    # Evaluate from highest term down: sum_{t=0..T-1} (-1)^t * a^(2t+1)/(2t+1)!
    for t in range(terms - 1, -1, -1):
        fact = 1.0
        m = 2 * t + 1
        for i in range(2, m + 1):
            fact *= i
        coeff = ( -1.0 if (t % 2 == 1) else 1.0 ) / fact
        res = res * z + coeff
    return res * a


def normalvariate(mu=0.0,sigma=1.0):
    """normal approx using box muller with approximated sqrt cos sin"""
    global _gauss_cached
    if _gauss_cached is not None:
        z=_gauss_cached
        _gauss_cached=None
        return mu+z*sigma
    while True:
        u1=random()
        u2=random()
        if u1>0.0:
            break
    r=_sqrt(-2.0*_ln(u1))
    z0=r*_cos(2.0*_pi*u2)
    z1=r*_sin(2.0*_pi*u2)
    _gauss_cached=z1
    return mu+z0*sigma

def gauss(mu=0.0,sigma=1.0):
    return normalvariate(mu,sigma)

def expovariate(lambd):
    """exponential using -ln(u)/lambda with approx ln"""
    if lambd<=0:
        raise ValueError("lambda must>0")
    u=random()
    while u<=0.0:
        u=random()
    return -_ln(u)/lambd

_digits="0123456789"
_lower="abcdefghijklmnopqrstuvwxyz"
_upper="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
_symbols="!\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~"

def randsymbol():
    return _symbols[randbelow(len(_symbols))]

def randchar_from_charset(cs):
    if not cs:
        raise ValueError("empty charset")
    return cs[randbelow(len(cs))]

def randstr(length,charset=None):
    if length<0:
        raise ValueError("length must >=0")
    if charset is None:
        charset=_lower
    return ''.join(randchar_from_charset(charset) for _ in range(length))

def random_from_spec(spec):
    if not spec:
        raise ValueError("spec must not empty")
    parts=[]
    for ch in spec:
        if ch=='1':
            parts.append(_digits)
        elif ch=='s':
            parts.append(_lower)
        elif ch=='S':
            parts.append(_upper)
        elif ch=='9':
            parts.append(_digits+_lower)
        elif ch=='e':
            parts.append(_digits+"abcdef")
        elif ch=='%':
            parts.append(_symbols)
        else:
            parts.append(ch)
    charset=''.join(parts)
    return randchar_from_charset(charset)

def randbytes(n):
    if n<0:
        raise ValueError("n must >=0")
    b=bytearray(n)
    for i in range(n):
        b[i]=randbelow(256)
    return bytes(b)

