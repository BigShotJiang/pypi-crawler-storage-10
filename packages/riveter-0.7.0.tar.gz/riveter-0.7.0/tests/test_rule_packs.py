"""Tests for rule pack management system."""

import os
import tempfile
from pathlib import Path

import pytest
import yaml

from riveter.rule_packs import RulePack, RulePackManager, RulePackMetadata
from riveter.rules import Rule, Severity


class TestRulePackMetadata:
    """Test RulePackMetadata class."""

    def test_metadata_creation(self) -> None:
        """Test creating rule pack metadata."""
        metadata = RulePackMetadata(
            name="test-pack",
            version="1.0.0",
            description="Test pack",
            author="Test Author",
            created="2024-01-01",
            updated="2024-01-01",
            dependencies=[],
            tags=["test"],
            min_riveter_version="0.1.0",
        )

        assert metadata.name == "test-pack"
        assert metadata.version == "1.0.0"
        assert metadata.description == "Test pack"
        assert metadata.author == "Test Author"
        assert metadata.dependencies == []
        assert metadata.tags == ["test"]


class TestRulePack:
    """Test RulePack class."""

    def test_rule_pack_creation(self) -> None:
        """Test creating a rule pack."""
        metadata = RulePackMetadata(
            name="test-pack",
            version="1.0.0",
            description="Test pack",
            author="Test Author",
            created="2024-01-01",
            updated="2024-01-01",
            dependencies=[],
            tags=["test"],
            min_riveter_version="0.1.0",
        )

        rule_dict = {
            "id": "test_rule",
            "resource_type": "aws_instance",
            "description": "Test rule",
            "severity": "error",
            "assert": {"instance_type": "t3.large"},
        }
        rule = Rule(rule_dict)

        pack = RulePack(metadata=metadata, rules=[rule])

        assert pack.metadata.name == "test-pack"
        assert len(pack.rules) == 1
        assert pack.rules[0].id == "test_rule"

    def test_rule_pack_duplicate_rule_ids(self) -> None:
        """Test that rule pack validation catches duplicate rule IDs."""
        metadata = RulePackMetadata(
            name="test-pack",
            version="1.0.0",
            description="Test pack",
            author="Test Author",
            created="2024-01-01",
            updated="2024-01-01",
            dependencies=[],
            tags=["test"],
            min_riveter_version="0.1.0",
        )

        rule1_dict = {
            "id": "duplicate_rule",
            "resource_type": "aws_instance",
            "description": "First rule",
            "severity": "error",
            "assert": {"instance_type": "t3.large"},
        }
        rule2_dict = {
            "id": "duplicate_rule",
            "resource_type": "aws_s3_bucket",
            "description": "Second rule",
            "severity": "warning",
            "assert": {"versioning.enabled": True},
        }

        rule1 = Rule(rule1_dict)
        rule2 = Rule(rule2_dict)

        with pytest.raises(ValueError, match="Duplicate rule ID"):
            RulePack(metadata=metadata, rules=[rule1, rule2])

    def test_filter_by_severity(self) -> None:
        """Test filtering rules by severity."""
        metadata = RulePackMetadata(
            name="test-pack",
            version="1.0.0",
            description="Test pack",
            author="Test Author",
            created="2024-01-01",
            updated="2024-01-01",
            dependencies=[],
            tags=["test"],
            min_riveter_version="0.1.0",
        )

        error_rule = Rule(
            {
                "id": "error_rule",
                "resource_type": "aws_instance",
                "description": "Error rule",
                "severity": "error",
                "assert": {"instance_type": "t3.large"},
            }
        )

        warning_rule = Rule(
            {
                "id": "warning_rule",
                "resource_type": "aws_s3_bucket",
                "description": "Warning rule",
                "severity": "warning",
                "assert": {"versioning.enabled": True},
            }
        )

        info_rule = Rule(
            {
                "id": "info_rule",
                "resource_type": "aws_vpc",
                "description": "Info rule",
                "severity": "info",
                "assert": {"enable_dns_hostnames": True},
            }
        )

        pack = RulePack(metadata=metadata, rules=[error_rule, warning_rule, info_rule])

        # Filter by error severity (should include only error rules)
        error_pack = pack.filter_by_severity(Severity.ERROR)
        assert len(error_pack.rules) == 1
        assert error_pack.rules[0].id == "error_rule"

        # Filter by warning severity (should include warning and error rules)
        warning_pack = pack.filter_by_severity(Severity.WARNING)
        assert len(warning_pack.rules) == 2
        rule_ids = {rule.id for rule in warning_pack.rules}
        assert rule_ids == {"error_rule", "warning_rule"}

        # Filter by info severity (should include all rules)
        info_pack = pack.filter_by_severity(Severity.INFO)
        assert len(info_pack.rules) == 3

    def test_filter_by_resource_type(self) -> None:
        """Test filtering rules by resource type."""
        metadata = RulePackMetadata(
            name="test-pack",
            version="1.0.0",
            description="Test pack",
            author="Test Author",
            created="2024-01-01",
            updated="2024-01-01",
            dependencies=[],
            tags=["test"],
            min_riveter_version="0.1.0",
        )

        ec2_rule = Rule(
            {
                "id": "ec2_rule",
                "resource_type": "aws_instance",
                "description": "EC2 rule",
                "severity": "error",
                "assert": {"instance_type": "t3.large"},
            }
        )

        s3_rule = Rule(
            {
                "id": "s3_rule",
                "resource_type": "aws_s3_bucket",
                "description": "S3 rule",
                "severity": "warning",
                "assert": {"versioning.enabled": True},
            }
        )

        pack = RulePack(metadata=metadata, rules=[ec2_rule, s3_rule])

        # Filter by EC2 resource type
        ec2_pack = pack.filter_by_resource_type(["aws_instance"])
        assert len(ec2_pack.rules) == 1
        assert ec2_pack.rules[0].id == "ec2_rule"

        # Filter by multiple resource types
        multi_pack = pack.filter_by_resource_type(["aws_instance", "aws_s3_bucket"])
        assert len(multi_pack.rules) == 2

    def test_merge_rule_packs(self) -> None:
        """Test merging two rule packs."""
        metadata1 = RulePackMetadata(
            name="pack1",
            version="1.0.0",
            description="First pack",
            author="Author 1",
            created="2024-01-01",
            updated="2024-01-01",
            dependencies=[],
            tags=["test1"],
            min_riveter_version="0.1.0",
        )

        metadata2 = RulePackMetadata(
            name="pack2",
            version="2.0.0",
            description="Second pack",
            author="Author 2",
            created="2024-02-01",
            updated="2024-02-01",
            dependencies=["pack1"],
            tags=["test2"],
            min_riveter_version="0.2.0",
        )

        rule1 = Rule(
            {
                "id": "rule1",
                "resource_type": "aws_instance",
                "description": "Rule 1",
                "severity": "error",
                "assert": {"instance_type": "t3.large"},
            }
        )

        rule2 = Rule(
            {
                "id": "rule2",
                "resource_type": "aws_s3_bucket",
                "description": "Rule 2",
                "severity": "warning",
                "assert": {"versioning.enabled": True},
            }
        )

        pack1 = RulePack(metadata=metadata1, rules=[rule1])
        pack2 = RulePack(metadata=metadata2, rules=[rule2])

        merged_pack = pack1.merge_with(pack2)

        assert len(merged_pack.rules) == 2
        assert merged_pack.metadata.name == "pack1+pack2"
        assert merged_pack.metadata.version == "merged"
        assert "Author 1" in merged_pack.metadata.author
        assert "Author 2" in merged_pack.metadata.author
        assert set(merged_pack.metadata.tags) == {"test1", "test2"}
        assert merged_pack.metadata.min_riveter_version == "0.2.0"

    def test_merge_conflicting_rule_ids(self) -> None:
        """Test that merging packs with conflicting rule IDs raises an error."""
        metadata1 = RulePackMetadata(
            name="pack1",
            version="1.0.0",
            description="First pack",
            author="Author 1",
            created="2024-01-01",
            updated="2024-01-01",
            dependencies=[],
            tags=["test1"],
            min_riveter_version="0.1.0",
        )

        metadata2 = RulePackMetadata(
            name="pack2",
            version="2.0.0",
            description="Second pack",
            author="Author 2",
            created="2024-02-01",
            updated="2024-02-01",
            dependencies=[],
            tags=["test2"],
            min_riveter_version="0.1.0",
        )

        rule1 = Rule(
            {
                "id": "conflicting_rule",
                "resource_type": "aws_instance",
                "description": "Rule 1",
                "severity": "error",
                "assert": {"instance_type": "t3.large"},
            }
        )

        rule2 = Rule(
            {
                "id": "conflicting_rule",
                "resource_type": "aws_s3_bucket",
                "description": "Rule 2",
                "severity": "warning",
                "assert": {"versioning.enabled": True},
            }
        )

        pack1 = RulePack(metadata=metadata1, rules=[rule1])
        pack2 = RulePack(metadata=metadata2, rules=[rule2])

        with pytest.raises(ValueError, match="conflicting rule IDs"):
            pack1.merge_with(pack2)

    def test_to_dict(self) -> None:
        """Test converting rule pack to dictionary."""
        metadata = RulePackMetadata(
            name="test-pack",
            version="1.0.0",
            description="Test pack",
            author="Test Author",
            created="2024-01-01",
            updated="2024-01-01",
            dependencies=[],
            tags=["test"],
            min_riveter_version="0.1.0",
        )

        rule = Rule(
            {
                "id": "test_rule",
                "resource_type": "aws_instance",
                "description": "Test rule",
                "severity": "error",
                "assert": {"instance_type": "t3.large"},
                "metadata": {"tags": ["test"]},
            }
        )

        pack = RulePack(metadata=metadata, rules=[rule])
        pack_dict = pack.to_dict()

        assert pack_dict["metadata"]["name"] == "test-pack"
        assert pack_dict["metadata"]["version"] == "1.0.0"
        assert len(pack_dict["rules"]) == 1
        assert pack_dict["rules"][0]["id"] == "test_rule"
        assert pack_dict["rules"][0]["resource_type"] == "aws_instance"


class TestRulePackManager:
    """Test RulePackManager class."""

    def test_manager_initialization(self) -> None:
        """Test rule pack manager initialization."""
        manager = RulePackManager()
        assert isinstance(manager.rule_pack_dirs, list)

    def test_manager_with_custom_dirs(self) -> None:
        """Test rule pack manager with custom directories."""
        custom_dirs = ["/custom/path1", "/custom/path2"]
        manager = RulePackManager(rule_pack_dirs=custom_dirs)

        # Custom dirs should be included
        for custom_dir in custom_dirs:
            assert custom_dir in manager.rule_pack_dirs

    def test_load_rule_pack_from_file(self, fixtures_dir: Path) -> None:
        """Test loading a rule pack from file."""
        manager = RulePackManager()
        pack_file = fixtures_dir / "rule_packs" / "test-pack.yml"

        pack = manager.load_rule_pack_from_file(str(pack_file))

        assert pack.metadata.name == "test-pack"
        assert pack.metadata.version == "1.0.0"
        assert len(pack.rules) == 2
        assert pack.rules[0].id == "test_rule_1"
        assert pack.rules[1].id == "test_rule_2"

    def test_load_invalid_rule_pack(self, fixtures_dir: Path) -> None:
        """Test loading an invalid rule pack."""
        manager = RulePackManager()
        pack_file = fixtures_dir / "rule_packs" / "invalid-pack.yml"

        with pytest.raises(ValueError, match="Missing required metadata field"):
            manager.load_rule_pack_from_file(str(pack_file))

    def test_load_rule_pack_with_duplicate_ids(self, fixtures_dir: Path) -> None:
        """Test loading a rule pack with duplicate rule IDs."""
        manager = RulePackManager()
        pack_file = fixtures_dir / "rule_packs" / "duplicate-rules.yml"

        with pytest.raises(ValueError, match="Duplicate rule ID"):
            manager.load_rule_pack_from_file(str(pack_file))

    def test_load_rule_pack_by_name(self, fixtures_dir: Path) -> None:
        """Test loading a rule pack by name."""
        # Create a temporary manager with the fixtures directory
        manager = RulePackManager(rule_pack_dirs=[str(fixtures_dir / "rule_packs")])

        pack = manager.load_rule_pack("test-pack")

        assert pack.metadata.name == "test-pack"
        assert len(pack.rules) == 2

    def test_load_nonexistent_rule_pack(self) -> None:
        """Test loading a nonexistent rule pack."""
        manager = RulePackManager(rule_pack_dirs=[])

        with pytest.raises(
            FileNotFoundError, match="Rule pack 'nonexistent' version 'latest' not found"
        ):
            manager.load_rule_pack("nonexistent")

    def test_list_available_packs(self, fixtures_dir: Path) -> None:
        """Test listing available rule packs."""
        manager = RulePackManager(rule_pack_dirs=[str(fixtures_dir / "rule_packs")])

        packs = manager.list_available_packs()

        # Should find at least the test packs
        pack_names = {pack["name"] for pack in packs}
        assert "test-pack" in pack_names
        assert "second-pack" in pack_names

        # Check that pack info is populated
        test_pack = next(pack for pack in packs if pack["name"] == "test-pack")
        assert test_pack["version"] == "1.0.0"
        assert test_pack["rule_count"] == 2
        assert test_pack["author"] == "Test Author"

    def test_validate_rule_pack_valid(self, fixtures_dir: Path) -> None:
        """Test validating a valid rule pack."""
        manager = RulePackManager()
        pack_file = str(fixtures_dir / "rule_packs" / "test-pack.yml")

        result = manager.validate_rule_pack(pack_file)

        assert result["valid"] is True
        assert result["rule_count"] == 2
        assert result["metadata"]["name"] == "test-pack"
        assert len(result["errors"]) == 0

    def test_validate_rule_pack_invalid(self, fixtures_dir: Path) -> None:
        """Test validating an invalid rule pack."""
        manager = RulePackManager()
        pack_file = str(fixtures_dir / "rule_packs" / "invalid-pack.yml")

        result = manager.validate_rule_pack(pack_file)

        assert result["valid"] is False
        assert len(result["errors"]) > 0

    def test_validate_nonexistent_file(self) -> None:
        """Test validating a nonexistent file."""
        manager = RulePackManager()

        result = manager.validate_rule_pack("/nonexistent/file.yml")

        assert result["valid"] is False
        assert "File does not exist" in result["errors"][0]

    def test_merge_rule_packs(self, fixtures_dir: Path) -> None:
        """Test merging multiple rule packs."""
        manager = RulePackManager(rule_pack_dirs=[str(fixtures_dir / "rule_packs")])

        merged_pack = manager.merge_rule_packs(["test-pack", "second-pack"])

        assert len(merged_pack.rules) == 4  # 2 from test-pack + 2 from second-pack
        assert merged_pack.metadata.name == "test-pack+second-pack"

        # Check that all rules are present
        rule_ids = {rule.id for rule in merged_pack.rules}
        expected_ids = {"test_rule_1", "test_rule_2", "second_pack_rule_1", "second_pack_rule_2"}
        assert rule_ids == expected_ids

    def test_merge_empty_pack_list(self) -> None:
        """Test merging with empty pack list."""
        manager = RulePackManager()

        with pytest.raises(ValueError, match="At least one rule pack name must be provided"):
            manager.merge_rule_packs([])

    def test_create_rule_pack_template(self) -> None:
        """Test creating a rule pack template."""
        manager = RulePackManager()

        with tempfile.NamedTemporaryFile(mode="w", suffix=".yml", delete=False) as f:
            template_file = f.name

        try:
            manager.create_rule_pack_template("my-pack", template_file)

            # Verify the template was created
            assert os.path.exists(template_file)

            # Verify the template content
            with open(template_file, "r") as f:
                template_data = yaml.safe_load(f)

            assert template_data["metadata"]["name"] == "my-pack"
            assert template_data["metadata"]["version"] == "1.0.0"
            assert len(template_data["rules"]) == 1
            assert template_data["rules"][0]["id"] == "my_pack_example_rule"

        finally:
            if os.path.exists(template_file):
                os.unlink(template_file)


@pytest.fixture
def fixtures_dir() -> Path:
    """Provide path to test fixtures directory."""
    return Path(__file__).parent / "fixtures"


class TestGCPSecurityRulePack:
    """Integration tests for GCP Security Best Practices rule pack."""

    def test_gcp_security_pack_loads(self) -> None:
        """Test that the GCP security rule pack loads successfully."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-security")

        assert pack.metadata.name == "gcp-security"
        assert pack.metadata.version == "1.0.0"
        assert pack.metadata.description == "GCP Security Best Practices Rule Pack"
        assert "gcp" in pack.metadata.tags
        assert "security" in pack.metadata.tags
        assert len(pack.rules) == 29

    def test_gcp_security_pack_metadata(self) -> None:
        """Test GCP security rule pack metadata."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-security")

        # Verify metadata fields
        assert pack.metadata.author == "Riveter Team"
        assert pack.metadata.min_riveter_version == "0.1.0"
        assert pack.metadata.dependencies == []

    def test_gcp_security_pack_rule_categories(self) -> None:
        """Test that GCP security pack covers all expected categories."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-security")

        # Get all resource types covered
        resource_types = {rule.resource_type for rule in pack.rules}

        # Verify coverage of major GCP resource types
        expected_types = {
            "google_compute_instance",
            "google_compute_project_metadata",
            "google_compute_disk",
            "google_storage_bucket",
            "google_sql_database_instance",
            "google_compute_subnetwork",
            "google_compute_firewall",
            "google_compute_router_nat",
            "google_project_iam_binding",
            "google_service_account",
            "google_container_cluster",
            "google_kms_crypto_key",
        }

        assert expected_types.issubset(resource_types)

    def test_gcp_security_pack_rule_ids_unique(self) -> None:
        """Test that all rule IDs in GCP security pack are unique."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-security")

        rule_ids = [rule.id for rule in pack.rules]
        assert len(rule_ids) == len(set(rule_ids))

    def test_gcp_security_pack_all_rules_have_metadata(self) -> None:
        """Test that all rules have proper metadata."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-security")

        for rule in pack.rules:
            # Each rule should have an ID and description
            assert rule.id is not None
            assert rule.description is not None
            assert len(rule.description) > 10

            # Each rule should have metadata with tags and references
            assert hasattr(rule, "metadata")
            assert "tags" in rule.metadata
            assert "references" in rule.metadata
            assert len(rule.metadata["tags"]) > 0
            assert len(rule.metadata["references"]) > 0

    def test_gcp_security_pack_severity_levels(self) -> None:
        """Test that GCP security pack has appropriate severity levels."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-security")

        severities = [rule.severity for rule in pack.rules]

        # Should have a mix of error, warning, and info rules
        assert Severity.ERROR in severities
        assert Severity.WARNING in severities

        # Most rules should be error or warning
        error_warning_count = sum(1 for s in severities if s in [Severity.ERROR, Severity.WARNING])
        assert error_warning_count >= len(pack.rules) * 0.7  # At least 70%

    def test_gcp_security_pack_filter_by_compute(self) -> None:
        """Test filtering GCP security pack by compute resources."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-security")

        compute_pack = pack.filter_by_resource_type(
            ["google_compute_instance", "google_compute_project_metadata", "google_compute_disk"]
        )

        # Should have at least 6 compute-related rules
        assert len(compute_pack.rules) >= 6

        # All rules should be compute-related
        for rule in compute_pack.rules:
            assert rule.resource_type.startswith("google_compute")

    def test_gcp_security_pack_filter_by_storage(self) -> None:
        """Test filtering GCP security pack by storage resources."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-security")

        storage_pack = pack.filter_by_resource_type(["google_storage_bucket"])

        # Should have at least 6 storage-related rules
        assert len(storage_pack.rules) >= 6

        # All rules should be storage-related
        for rule in storage_pack.rules:
            assert rule.resource_type == "google_storage_bucket"

    def test_gcp_security_pack_filter_by_sql(self) -> None:
        """Test filtering GCP security pack by Cloud SQL resources."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-security")

        sql_pack = pack.filter_by_resource_type(["google_sql_database_instance"])

        # Should have at least 5 SQL-related rules
        assert len(sql_pack.rules) >= 5

        # All rules should be SQL-related
        for rule in sql_pack.rules:
            assert rule.resource_type == "google_sql_database_instance"

    def test_gcp_security_pack_merge_with_aws(self) -> None:
        """Test merging GCP security pack with AWS security pack."""
        manager = RulePackManager()

        merged_pack = manager.merge_rule_packs(["gcp-security", "aws-security"])

        # Should have rules from both packs
        assert len(merged_pack.rules) > 29  # More than just GCP rules

        # Should have both GCP and AWS resource types
        resource_types = {rule.resource_type for rule in merged_pack.rules}
        assert any(rt.startswith("google_") for rt in resource_types)
        assert any(rt.startswith("aws_") for rt in resource_types)

        # Metadata should reflect merge
        assert "gcp-security" in merged_pack.metadata.name
        assert "aws-security" in merged_pack.metadata.name


class TestCISGCPRulePack:
    """Integration tests for CIS GCP Benchmark rule pack."""

    def test_cis_gcp_pack_loads(self) -> None:
        """Test that the CIS GCP rule pack loads successfully."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("cis-gcp")

        assert pack.metadata.name == "cis-gcp"
        assert pack.metadata.version == "1.0.0"
        assert (
            pack.metadata.description
            == "CIS Google Cloud Platform Foundation Benchmark v1.3.0 Rule Pack"
        )
        assert "cis" in pack.metadata.tags
        assert "gcp" in pack.metadata.tags
        assert len(pack.rules) == 43

    def test_cis_gcp_pack_metadata(self) -> None:
        """Test CIS GCP rule pack metadata."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("cis-gcp")

        # Verify metadata fields
        assert pack.metadata.author == "Riveter Team"
        assert pack.metadata.min_riveter_version == "0.1.0"
        assert pack.metadata.dependencies == []

    def test_cis_gcp_pack_rule_categories(self) -> None:
        """Test that CIS GCP pack covers all expected sections."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("cis-gcp")

        # Get all CIS control numbers
        cis_controls = set()
        for rule in pack.rules:
            if "cis_control" in rule.metadata:
                control = rule.metadata["cis_control"]
                section = control.split(".")[0]
                cis_controls.add(section)

        # Verify coverage of major CIS sections
        expected_sections = {"1", "2", "3", "4", "5", "6"}
        assert expected_sections.issubset(cis_controls)

    def test_cis_gcp_pack_rule_ids_unique(self) -> None:
        """Test that all rule IDs in CIS GCP pack are unique."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("cis-gcp")

        rule_ids = [rule.id for rule in pack.rules]
        assert len(rule_ids) == len(set(rule_ids))

    def test_cis_gcp_pack_all_rules_have_cis_control(self) -> None:
        """Test that all rules have CIS control references."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("cis-gcp")

        for rule in pack.rules:
            # Each rule should have CIS control metadata
            assert "cis_control" in rule.metadata
            assert rule.metadata["cis_control"] is not None
            assert len(rule.metadata["cis_control"]) > 0

            # CIS control should be in format "X.Y"
            control = rule.metadata["cis_control"]
            parts = control.split(".")
            assert len(parts) == 2
            assert parts[0].isdigit()
            assert parts[1].isdigit()

    def test_cis_gcp_pack_severity_levels(self) -> None:
        """Test that CIS GCP pack has appropriate severity levels."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("cis-gcp")

        severities = [rule.severity for rule in pack.rules]

        # Should have a mix of error and warning rules
        assert Severity.ERROR in severities

        # Most rules should be error (CIS benchmarks are strict)
        error_count = sum(1 for s in severities if s == Severity.ERROR)
        assert error_count >= len(pack.rules) * 0.7  # At least 70% error

    def test_cis_gcp_pack_filter_by_iam(self) -> None:
        """Test filtering CIS GCP pack by IAM resources."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("cis-gcp")

        iam_pack = pack.filter_by_resource_type(
            [
                "google_project_iam_binding",
                "google_service_account_key",
                "google_organization_iam_binding",
                "google_kms_crypto_key_iam_binding",
            ]
        )

        # Should have at least 8 IAM-related rules (Section 1)
        assert len(iam_pack.rules) >= 8

    def test_cis_gcp_pack_filter_by_logging(self) -> None:
        """Test filtering CIS GCP pack by logging resources."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("cis-gcp")

        logging_pack = pack.filter_by_resource_type(
            [
                "google_logging_metric",
                "google_logging_project_bucket_config",
                "google_logging_project_sink",
            ]
        )

        # Should have at least 8 logging-related rules (Section 2)
        assert len(logging_pack.rules) >= 8

    def test_cis_gcp_pack_filter_by_networking(self) -> None:
        """Test filtering CIS GCP pack by networking resources."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("cis-gcp")

        network_pack = pack.filter_by_resource_type(
            [
                "google_compute_network",
                "google_dns_managed_zone",
                "google_compute_firewall",
                "google_compute_subnetwork",
            ]
        )

        # Should have at least 6 networking-related rules (Section 3)
        assert len(network_pack.rules) >= 6

    def test_cis_gcp_pack_merge_with_gcp_security(self) -> None:
        """Test merging CIS GCP pack with GCP security pack."""
        manager = RulePackManager()

        merged_pack = manager.merge_rule_packs(["cis-gcp", "gcp-security"])

        # Should have rules from both packs
        assert len(merged_pack.rules) > 43  # More than just CIS rules

        # Should have both CIS and security rules
        rule_ids = {rule.id for rule in merged_pack.rules}
        assert any(rid.startswith("cis_gcp_") for rid in rule_ids)
        assert any(rid.startswith("gcp_") for rid in rule_ids)

        # Metadata should reflect merge
        assert "cis-gcp" in merged_pack.metadata.name
        assert "gcp-security" in merged_pack.metadata.name


class TestAzureSecurityRulePack:
    """Integration tests for Azure Security Best Practices rule pack."""

    def test_azure_security_pack_loads(self) -> None:
        """Test that the Azure security rule pack loads successfully."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-security")

        assert pack.metadata.name == "azure-security"
        assert pack.metadata.version == "1.0.0"
        assert pack.metadata.description == "Azure Security Best Practices Rule Pack"
        assert "azure" in pack.metadata.tags
        assert "security" in pack.metadata.tags
        assert len(pack.rules) == 28

    def test_azure_security_pack_metadata(self) -> None:
        """Test Azure security rule pack metadata."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-security")

        # Verify metadata fields
        assert pack.metadata.author == "Riveter Team"
        assert pack.metadata.min_riveter_version == "0.1.0"
        assert pack.metadata.dependencies == []

    def test_azure_security_pack_rule_categories(self) -> None:
        """Test that Azure security pack covers all expected categories."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-security")

        # Get all resource types covered
        resource_types = {rule.resource_type for rule in pack.rules}

        # Verify coverage of major Azure resource types
        expected_types = {
            "azurerm_linux_virtual_machine",
            "azurerm_network_interface",
            "azurerm_managed_disk",
            "azurerm_storage_account",
            "azurerm_mssql_server",
            "azurerm_mssql_database",
            "azurerm_network_security_rule",
            "azurerm_network_security_group",
            "azurerm_key_vault",
            "azurerm_role_assignment",
        }

        assert expected_types.issubset(resource_types)

    def test_azure_security_pack_rule_ids_unique(self) -> None:
        """Test that all rule IDs in Azure security pack are unique."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-security")

        rule_ids = [rule.id for rule in pack.rules]
        assert len(rule_ids) == len(set(rule_ids))

    def test_azure_security_pack_all_rules_have_metadata(self) -> None:
        """Test that all rules have proper metadata."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-security")

        for rule in pack.rules:
            # Each rule should have an ID and description
            assert rule.id is not None
            assert rule.description is not None
            assert len(rule.description) > 10

            # Each rule should have metadata with tags and references
            assert hasattr(rule, "metadata")
            assert "tags" in rule.metadata
            assert "references" in rule.metadata
            assert len(rule.metadata["tags"]) > 0
            assert len(rule.metadata["references"]) > 0

    def test_azure_security_pack_severity_levels(self) -> None:
        """Test that Azure security pack has appropriate severity levels."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-security")

        severities = [rule.severity for rule in pack.rules]

        # Should have a mix of error, warning, and info rules
        assert Severity.ERROR in severities
        assert Severity.WARNING in severities

        # Most rules should be error or warning
        error_warning_count = sum(1 for s in severities if s in [Severity.ERROR, Severity.WARNING])
        assert error_warning_count >= len(pack.rules) * 0.7  # At least 70%

    def test_azure_security_pack_filter_by_vm(self) -> None:
        """Test filtering Azure security pack by VM resources."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-security")

        vm_pack = pack.filter_by_resource_type(
            [
                "azurerm_virtual_machine",
                "azurerm_linux_virtual_machine",
                "azurerm_network_interface",
                "azurerm_managed_disk",
            ]
        )

        # Should have at least 6 VM-related rules
        assert len(vm_pack.rules) >= 6

    def test_azure_security_pack_filter_by_storage(self) -> None:
        """Test filtering Azure security pack by storage resources."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-security")

        storage_pack = pack.filter_by_resource_type(["azurerm_storage_account"])

        # Should have at least 6 storage-related rules
        assert len(storage_pack.rules) >= 6

        # All rules should be storage-related
        for rule in storage_pack.rules:
            assert rule.resource_type == "azurerm_storage_account"

    def test_azure_security_pack_filter_by_sql(self) -> None:
        """Test filtering Azure security pack by SQL resources."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-security")

        sql_pack = pack.filter_by_resource_type(
            [
                "azurerm_mssql_server",
                "azurerm_mssql_database",
                "azurerm_mssql_server_security_alert_policy",
            ]
        )

        # Should have at least 5 SQL-related rules
        assert len(sql_pack.rules) >= 5

    def test_azure_security_pack_merge_with_aws(self) -> None:
        """Test merging Azure security pack with AWS security pack."""
        manager = RulePackManager()

        merged_pack = manager.merge_rule_packs(["azure-security", "aws-security"])

        # Should have rules from both packs
        assert len(merged_pack.rules) > 28  # More than just Azure rules

        # Should have both Azure and AWS resource types
        resource_types = {rule.resource_type for rule in merged_pack.rules}
        assert any(rt.startswith("azurerm_") for rt in resource_types)
        assert any(rt.startswith("aws_") for rt in resource_types)

        # Metadata should reflect merge
        assert "azure-security" in merged_pack.metadata.name
        assert "aws-security" in merged_pack.metadata.name


class TestAWSWellArchitectedRulePack:
    """Integration tests for AWS Well-Architected Framework rule pack."""

    def test_aws_wa_pack_loads(self) -> None:
        """Test that the AWS Well-Architected rule pack loads successfully."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("aws-well-architected")

        assert pack.metadata.name == "aws-well-architected"
        assert pack.metadata.version == "1.0.0"
        assert (
            pack.metadata.description
            == "AWS Well-Architected Framework Rule Pack covering all 6 pillars"
        )
        assert "well-architected" in pack.metadata.tags
        assert "aws" in pack.metadata.tags
        assert len(pack.rules) == 34

    def test_aws_wa_pack_metadata(self) -> None:
        """Test AWS Well-Architected rule pack metadata."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("aws-well-architected")

        # Verify metadata fields
        assert pack.metadata.author == "Riveter Team"
        assert pack.metadata.min_riveter_version == "0.1.0"
        assert pack.metadata.dependencies == []

    def test_aws_wa_pack_pillar_coverage(self) -> None:
        """Test that AWS Well-Architected pack covers all 6 pillars."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("aws-well-architected")

        # Get all pillars covered
        pillars = set()
        for rule in pack.rules:
            if "pillar" in rule.metadata:
                pillars.add(rule.metadata["pillar"])

        # Verify coverage of all 6 pillars
        expected_pillars = {
            "Operational Excellence",
            "Security",
            "Reliability",
            "Performance Efficiency",
            "Cost Optimization",
            "Sustainability",
        }
        assert expected_pillars == pillars

    def test_aws_wa_pack_rule_ids_unique(self) -> None:
        """Test that all rule IDs in AWS Well-Architected pack are unique."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("aws-well-architected")

        rule_ids = [rule.id for rule in pack.rules]
        assert len(rule_ids) == len(set(rule_ids))

    def test_aws_wa_pack_all_rules_have_pillar(self) -> None:
        """Test that all rules have pillar references."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("aws-well-architected")

        for rule in pack.rules:
            # Each rule should have pillar metadata
            assert "pillar" in rule.metadata
            assert rule.metadata["pillar"] is not None
            assert len(rule.metadata["pillar"]) > 0

    def test_aws_wa_pack_severity_levels(self) -> None:
        """Test that AWS Well-Architected pack has appropriate severity levels."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("aws-well-architected")

        severities = [rule.severity for rule in pack.rules]

        # Should have a mix of error, warning, and info rules
        assert Severity.ERROR in severities
        assert Severity.WARNING in severities
        assert Severity.INFO in severities

    def test_aws_wa_pack_operational_excellence_pillar(self) -> None:
        """Test filtering AWS Well-Architected pack by Operational Excellence pillar."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("aws-well-architected")

        opex_rules = [
            rule for rule in pack.rules if rule.metadata.get("pillar") == "Operational Excellence"
        ]

        # Should have 6-8 Operational Excellence rules
        assert 6 <= len(opex_rules) <= 8

        # Verify resource types are appropriate for operational excellence
        resource_types = {rule.resource_type for rule in opex_rules}
        expected_types = {"aws_cloudwatch_metric_alarm", "aws_autoscaling_policy", "aws_instance"}
        assert expected_types.issubset(resource_types)

    def test_aws_wa_pack_security_pillar(self) -> None:
        """Test filtering AWS Well-Architected pack by Security pillar."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("aws-well-architected")

        security_rules = [rule for rule in pack.rules if rule.metadata.get("pillar") == "Security"]

        # Should have 6-8 Security rules
        assert 6 <= len(security_rules) <= 8

    def test_aws_wa_pack_reliability_pillar(self) -> None:
        """Test filtering AWS Well-Architected pack by Reliability pillar."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("aws-well-architected")

        reliability_rules = [
            rule for rule in pack.rules if rule.metadata.get("pillar") == "Reliability"
        ]

        # Should have 6-8 Reliability rules
        assert 6 <= len(reliability_rules) <= 8

        # Verify resource types are appropriate for reliability
        resource_types = {rule.resource_type for rule in reliability_rules}
        expected_types = {"aws_db_instance", "aws_autoscaling_group", "aws_lb_target_group"}
        assert expected_types.issubset(resource_types)

    def test_aws_wa_pack_performance_pillar(self) -> None:
        """Test filtering AWS Well-Architected pack by Performance Efficiency pillar."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("aws-well-architected")

        performance_rules = [
            rule for rule in pack.rules if rule.metadata.get("pillar") == "Performance Efficiency"
        ]

        # Should have 4-6 Performance Efficiency rules
        assert 4 <= len(performance_rules) <= 6

    def test_aws_wa_pack_cost_optimization_pillar(self) -> None:
        """Test filtering AWS Well-Architected pack by Cost Optimization pillar."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("aws-well-architected")

        cost_rules = [
            rule for rule in pack.rules if rule.metadata.get("pillar") == "Cost Optimization"
        ]

        # Should have 4-6 Cost Optimization rules
        assert 4 <= len(cost_rules) <= 6

    def test_aws_wa_pack_sustainability_pillar(self) -> None:
        """Test filtering AWS Well-Architected pack by Sustainability pillar."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("aws-well-architected")

        sustainability_rules = [
            rule for rule in pack.rules if rule.metadata.get("pillar") == "Sustainability"
        ]

        # Should have 2-4 Sustainability rules
        assert 2 <= len(sustainability_rules) <= 4

    def test_aws_wa_pack_merge_with_aws_security(self) -> None:
        """Test merging AWS Well-Architected pack with AWS security pack."""
        manager = RulePackManager()

        merged_pack = manager.merge_rule_packs(["aws-well-architected", "aws-security"])

        # Should have rules from both packs
        assert len(merged_pack.rules) > 34  # More than just Well-Architected rules

        # Should have both Well-Architected and security rules
        rule_ids = {rule.id for rule in merged_pack.rules}
        assert any(rid.startswith("aws_wa_") for rid in rule_ids)
        assert any(not rid.startswith("aws_wa_") for rid in rule_ids)

        # Metadata should reflect merge
        assert "aws-well-architected" in merged_pack.metadata.name
        assert "aws-security" in merged_pack.metadata.name


class TestAzureWellArchitectedRulePack:
    """Integration tests for Azure Well-Architected Framework rule pack."""

    def test_azure_wa_pack_loads(self) -> None:
        """Test that the Azure Well-Architected rule pack loads successfully."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-well-architected")

        assert pack.metadata.name == "azure-well-architected"
        assert pack.metadata.version == "1.0.0"
        assert (
            pack.metadata.description
            == "Azure Well-Architected Framework Rule Pack covering all 5 pillars"
        )
        assert "well-architected" in pack.metadata.tags
        assert "azure" in pack.metadata.tags
        assert len(pack.rules) == 35

    def test_azure_wa_pack_metadata(self) -> None:
        """Test Azure Well-Architected rule pack metadata."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-well-architected")

        # Verify metadata fields
        assert pack.metadata.author == "Riveter Team"
        assert pack.metadata.min_riveter_version == "0.1.0"
        assert pack.metadata.dependencies == []

    def test_azure_wa_pack_pillar_coverage(self) -> None:
        """Test that Azure Well-Architected pack covers all 5 pillars."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-well-architected")

        # Get all pillars covered
        pillars = set()
        for rule in pack.rules:
            if "pillar" in rule.metadata:
                pillars.add(rule.metadata["pillar"])

        # Verify coverage of all 5 pillars
        expected_pillars = {
            "Cost Optimization",
            "Operational Excellence",
            "Performance Efficiency",
            "Reliability",
            "Security",
        }
        assert expected_pillars == pillars

    def test_azure_wa_pack_rule_ids_unique(self) -> None:
        """Test that all rule IDs in Azure Well-Architected pack are unique."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-well-architected")

        rule_ids = [rule.id for rule in pack.rules]
        assert len(rule_ids) == len(set(rule_ids))

    def test_azure_wa_pack_all_rules_have_pillar(self) -> None:
        """Test that all rules have pillar references."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-well-architected")

        for rule in pack.rules:
            # Each rule should have pillar metadata
            assert "pillar" in rule.metadata
            assert rule.metadata["pillar"] is not None
            assert len(rule.metadata["pillar"]) > 0

    def test_azure_wa_pack_severity_levels(self) -> None:
        """Test that Azure Well-Architected pack has appropriate severity levels."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-well-architected")

        severities = [rule.severity for rule in pack.rules]

        # Should have a mix of error, warning, and info rules
        assert Severity.ERROR in severities
        assert Severity.WARNING in severities
        assert Severity.INFO in severities

    def test_azure_wa_pack_cost_optimization_pillar(self) -> None:
        """Test filtering Azure Well-Architected pack by Cost Optimization pillar."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-well-architected")

        cost_rules = [
            rule for rule in pack.rules if rule.metadata.get("pillar") == "Cost Optimization"
        ]

        # Should have 6-8 Cost Optimization rules
        assert 6 <= len(cost_rules) <= 8

    def test_azure_wa_pack_operational_excellence_pillar(self) -> None:
        """Test filtering Azure Well-Architected pack by Operational Excellence pillar."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-well-architected")

        opex_rules = [
            rule for rule in pack.rules if rule.metadata.get("pillar") == "Operational Excellence"
        ]

        # Should have 6-8 Operational Excellence rules
        assert 6 <= len(opex_rules) <= 8

    def test_azure_wa_pack_performance_pillar(self) -> None:
        """Test filtering Azure Well-Architected pack by Performance Efficiency pillar."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-well-architected")

        performance_rules = [
            rule for rule in pack.rules if rule.metadata.get("pillar") == "Performance Efficiency"
        ]

        # Should have 6-8 Performance Efficiency rules
        assert 6 <= len(performance_rules) <= 8

    def test_azure_wa_pack_reliability_pillar(self) -> None:
        """Test filtering Azure Well-Architected pack by Reliability pillar."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-well-architected")

        reliability_rules = [
            rule for rule in pack.rules if rule.metadata.get("pillar") == "Reliability"
        ]

        # Should have 6-8 Reliability rules
        assert 6 <= len(reliability_rules) <= 8

    def test_azure_wa_pack_security_pillar(self) -> None:
        """Test filtering Azure Well-Architected pack by Security pillar."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("azure-well-architected")

        security_rules = [rule for rule in pack.rules if rule.metadata.get("pillar") == "Security"]

        # Should have 6-8 Security rules
        assert 6 <= len(security_rules) <= 8

    def test_azure_wa_pack_merge_with_azure_security(self) -> None:
        """Test merging Azure Well-Architected pack with Azure security pack."""
        manager = RulePackManager()

        merged_pack = manager.merge_rule_packs(["azure-well-architected", "azure-security"])

        # Should have rules from both packs
        assert len(merged_pack.rules) > 35  # More than just Well-Architected rules

        # Should have both Well-Architected and security rules
        rule_ids = {rule.id for rule in merged_pack.rules}
        assert any(rid.startswith("azure_wa_") for rid in rule_ids)
        assert any(rid.startswith("azure_") and not rid.startswith("azure_wa_") for rid in rule_ids)

        # Metadata should reflect merge
        assert "azure-well-architected" in merged_pack.metadata.name
        assert "azure-security" in merged_pack.metadata.name


class TestGCPWellArchitectedRulePack:
    """Integration tests for GCP Well-Architected Framework rule pack."""

    def test_gcp_wa_pack_loads(self) -> None:
        """Test that the GCP Well-Architected rule pack loads successfully."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-well-architected")

        assert pack.metadata.name == "gcp-well-architected"
        assert pack.metadata.version == "1.0.0"
        assert (
            pack.metadata.description
            == "GCP Well-Architected Framework Rule Pack covering all 5 pillars"
        )
        assert "well-architected" in pack.metadata.tags
        assert "gcp" in pack.metadata.tags
        assert len(pack.rules) == 30

    def test_gcp_wa_pack_metadata(self) -> None:
        """Test GCP Well-Architected rule pack metadata."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-well-architected")

        # Verify metadata fields
        assert pack.metadata.author == "Riveter Team"
        assert pack.metadata.min_riveter_version == "0.1.0"
        assert pack.metadata.dependencies == []

    def test_gcp_wa_pack_pillar_coverage(self) -> None:
        """Test that GCP Well-Architected pack covers all 5 pillars."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-well-architected")

        # Get all pillars covered
        pillars = set()
        for rule in pack.rules:
            if "pillar" in rule.metadata:
                pillars.add(rule.metadata["pillar"])

        # Verify coverage of all 5 pillars
        expected_pillars = {
            "Operational Excellence",
            "Security",
            "Reliability",
            "Performance",
            "Cost Optimization",
        }
        assert expected_pillars == pillars

    def test_gcp_wa_pack_rule_ids_unique(self) -> None:
        """Test that all rule IDs in GCP Well-Architected pack are unique."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-well-architected")

        rule_ids = [rule.id for rule in pack.rules]
        assert len(rule_ids) == len(set(rule_ids))

    def test_gcp_wa_pack_all_rules_have_pillar(self) -> None:
        """Test that all rules have pillar references."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-well-architected")

        for rule in pack.rules:
            # Each rule should have pillar metadata
            assert "pillar" in rule.metadata
            assert rule.metadata["pillar"] is not None
            assert len(rule.metadata["pillar"]) > 0

    def test_gcp_wa_pack_severity_levels(self) -> None:
        """Test that GCP Well-Architected pack has appropriate severity levels."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-well-architected")

        severities = [rule.severity for rule in pack.rules]

        # Should have a mix of error, warning, and info rules
        assert Severity.ERROR in severities
        assert Severity.WARNING in severities
        assert Severity.INFO in severities

    def test_gcp_wa_pack_operational_excellence_pillar(self) -> None:
        """Test filtering GCP Well-Architected pack by Operational Excellence pillar."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-well-architected")

        opex_rules = [
            rule for rule in pack.rules if rule.metadata.get("pillar") == "Operational Excellence"
        ]

        # Should have 5-7 Operational Excellence rules
        assert 5 <= len(opex_rules) <= 7

    def test_gcp_wa_pack_security_pillar(self) -> None:
        """Test filtering GCP Well-Architected pack by Security pillar."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-well-architected")

        security_rules = [rule for rule in pack.rules if rule.metadata.get("pillar") == "Security"]

        # Should have 5-7 Security rules
        assert 5 <= len(security_rules) <= 7

    def test_gcp_wa_pack_reliability_pillar(self) -> None:
        """Test filtering GCP Well-Architected pack by Reliability pillar."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-well-architected")

        reliability_rules = [
            rule for rule in pack.rules if rule.metadata.get("pillar") == "Reliability"
        ]

        # Should have 5-7 Reliability rules
        assert 5 <= len(reliability_rules) <= 7

    def test_gcp_wa_pack_performance_pillar(self) -> None:
        """Test filtering GCP Well-Architected pack by Performance pillar."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-well-architected")

        performance_rules = [
            rule for rule in pack.rules if rule.metadata.get("pillar") == "Performance"
        ]

        # Should have 5-7 Performance rules
        assert 5 <= len(performance_rules) <= 7

    def test_gcp_wa_pack_cost_optimization_pillar(self) -> None:
        """Test filtering GCP Well-Architected pack by Cost Optimization pillar."""
        manager = RulePackManager()
        pack = manager.load_rule_pack("gcp-well-architected")

        cost_rules = [
            rule for rule in pack.rules if rule.metadata.get("pillar") == "Cost Optimization"
        ]

        # Should have 5-7 Cost Optimization rules
        assert 5 <= len(cost_rules) <= 7

    def test_gcp_wa_pack_merge_with_gcp_security(self) -> None:
        """Test merging GCP Well-Architected pack with GCP security pack."""
        manager = RulePackManager()

        merged_pack = manager.merge_rule_packs(["gcp-well-architected", "gcp-security"])

        # Should have rules from both packs
        assert len(merged_pack.rules) > 30  # More than just Well-Architected rules

        # Should have both Well-Architected and security rules
        rule_ids = {rule.id for rule in merged_pack.rules}
        assert any(rid.startswith("gcp_wa_") for rid in rule_ids)
        assert any(rid.startswith("gcp_") and not rid.startswith("gcp_wa_") for rid in rule_ids)

        # Metadata should reflect merge
        assert "gcp-well-architected" in merged_pack.metadata.name
        assert "gcp-security" in merged_pack.metadata.name
