# Kubernetes Security Test Fixtures
# This file contains both passing and failing examples for kubernetes-security rule pack
# Covers EKS (AWS), AKS (Azure), and GKE (GCP)

# ============================================================================
# EKS (AWS) RESOURCES
# ============================================================================

# PASS: EKS cluster with security best practices
resource "aws_eks_cluster" "secure_eks" {
  name     = "secure-eks-cluster"
  role_arn = aws_iam_role.eks_cluster_role.arn
  version  = "1.27"

  vpc_config {
    subnet_ids              = ["subnet-12345", "subnet-67890"]
    endpoint_private_access = true
    endpoint_public_access  = false
    security_group_ids      = ["sg-12345"]
  }

  encryption_config {
    provider {
      key_arn = "arn:aws:kms:us-east-1:123456789012:key/12345678-1234-1234-1234-123456789012"
    }
    resources = ["secrets"]
  }

  enabled_cluster_log_types = ["api", "audit", "authenticator", "controllerManager", "scheduler"]

  tags = {
    Environment = "production"
    Owner       = "platform-team"
  }
}

# FAIL: EKS cluster with public endpoint
resource "aws_eks_cluster" "public_endpoint_eks" {
  name     = "public-endpoint-eks"
  role_arn = aws_iam_role.eks_cluster_role.arn

  vpc_config {
    subnet_ids              = ["subnet-12345", "subnet-67890"]
    endpoint_private_access = true
    endpoint_public_access  = true
  }
}

# FAIL: EKS cluster without secrets encryption
resource "aws_eks_cluster" "no_encryption_eks" {
  name     = "no-encryption-eks"
  role_arn = aws_iam_role.eks_cluster_role.arn

  vpc_config {
    subnet_ids = ["subnet-12345", "subnet-67890"]
  }
}

# FAIL: EKS cluster without logging enabled
resource "aws_eks_cluster" "no_logging_eks" {
  name     = "no-logging-eks"
  role_arn = aws_iam_role.eks_cluster_role.arn

  vpc_config {
    subnet_ids = ["subnet-12345", "subnet-67890"]
  }

  enabled_cluster_log_types = []
}

# PASS: EKS node group with security best practices
resource "aws_eks_node_group" "secure_node_group" {
  cluster_name    = aws_eks_cluster.secure_eks.name
  node_group_name = "secure-node-group"
  node_role_arn   = aws_iam_role.eks_node_role.arn
  subnet_ids      = ["subnet-12345", "subnet-67890"]

  scaling_config {
    desired_size = 2
    max_size     = 4
    min_size     = 2
  }

  launch_template {
    id      = aws_launch_template.eks_nodes.id
    version = "$Latest"
  }

  tags = {
    Environment = "production"
  }
}

# ============================================================================
# AKS (AZURE) RESOURCES
# ============================================================================

# PASS: AKS cluster with security best practices
resource "azurerm_kubernetes_cluster" "secure_aks" {
  name                = "secure-aks-cluster"
  location            = "East US"
  resource_group_name = "test-resources"
  dns_prefix          = "secure-aks"
  kubernetes_version  = "1.27"

  default_node_pool {
    name                = "default"
    node_count          = 2
    vm_size             = "Standard_D2s_v3"
    enable_auto_scaling = true
    min_count           = 2
    max_count           = 4
    vnet_subnet_id      = "subnet-id"
  }

  identity {
    type = "SystemAssigned"
  }

  network_profile {
    network_plugin    = "azure"
    network_policy    = "calico"
    load_balancer_sku = "standard"
  }

  azure_policy_enabled = true

  oms_agent {
    log_analytics_workspace_id = "workspace-id"
  }

  role_based_access_control_enabled = true

  azure_active_directory_role_based_access_control {
    managed                = true
    azure_rbac_enabled     = true
    admin_group_object_ids = ["00000000-0000-0000-0000-000000000000"]
  }

  private_cluster_enabled = true

  tags = {
    Environment = "production"
    Owner       = "platform-team"
  }
}

# FAIL: AKS cluster without network policy
resource "azurerm_kubernetes_cluster" "no_network_policy_aks" {
  name                = "no-network-policy-aks"
  location            = "East US"
  resource_group_name = "test-resources"
  dns_prefix          = "no-network-policy"

  default_node_pool {
    name       = "default"
    node_count = 2
    vm_size    = "Standard_D2s_v3"
  }

  identity {
    type = "SystemAssigned"
  }

  network_profile {
    network_plugin    = "azure"
    load_balancer_sku = "standard"
  }
}

# FAIL: AKS cluster without RBAC enabled
resource "azurerm_kubernetes_cluster" "no_rbac_aks" {
  name                = "no-rbac-aks"
  location            = "East US"
  resource_group_name = "test-resources"
  dns_prefix          = "no-rbac"

  default_node_pool {
    name       = "default"
    node_count = 2
    vm_size    = "Standard_D2s_v3"
  }

  identity {
    type = "SystemAssigned"
  }

  role_based_access_control_enabled = false
}

# FAIL: AKS cluster without private cluster enabled
resource "azurerm_kubernetes_cluster" "public_aks" {
  name                = "public-aks"
  location            = "East US"
  resource_group_name = "test-resources"
  dns_prefix          = "public"

  default_node_pool {
    name       = "default"
    node_count = 2
    vm_size    = "Standard_D2s_v3"
  }

  identity {
    type = "SystemAssigned"
  }

  private_cluster_enabled = false
}

# ============================================================================
# GKE (GCP) RESOURCES
# ============================================================================

# PASS: GKE cluster with security best practices
resource "google_container_cluster" "secure_gke" {
  name     = "secure-gke-cluster"
  location = "us-central1"

  remove_default_node_pool = true
  initial_node_count       = 1

  network    = "default"
  subnetwork = "default"

  private_cluster_config {
    enable_private_nodes    = true
    enable_private_endpoint = false
    master_ipv4_cidr_block  = "172.16.0.0/28"
  }

  ip_allocation_policy {
    cluster_ipv4_cidr_block  = "10.0.0.0/16"
    services_ipv4_cidr_block = "10.1.0.0/16"
  }

  network_policy {
    enabled  = true
    provider = "CALICO"
  }

  addons_config {
    network_policy_config {
      disabled = false
    }
  }

  master_auth {
    client_certificate_config {
      issue_client_certificate = false
    }
  }

  workload_identity_config {
    workload_pool = "project-id.svc.id.goog"
  }

  database_encryption {
    state    = "ENCRYPTED"
    key_name = "projects/project-id/locations/us-central1/keyRings/gke/cryptoKeys/gke-key"
  }

  binary_authorization {
    evaluation_mode = "PROJECT_SINGLETON_POLICY_ENFORCE"
  }

  enable_shielded_nodes = true
  enable_legacy_abac    = false

  resource_labels = {
    environment = "production"
    owner       = "platform-team"
  }
}

# FAIL: GKE cluster without private nodes
resource "google_container_cluster" "public_gke" {
  name     = "public-gke-cluster"
  location = "us-central1"

  remove_default_node_pool = true
  initial_node_count       = 1

  network_policy {
    enabled = true
  }
}

# FAIL: GKE cluster without network policy
resource "google_container_cluster" "no_network_policy_gke" {
  name     = "no-network-policy-gke"
  location = "us-central1"

  remove_default_node_pool = true
  initial_node_count       = 1

  private_cluster_config {
    enable_private_nodes = true
  }

  network_policy {
    enabled = false
  }
}

# FAIL: GKE cluster with legacy ABAC enabled
resource "google_container_cluster" "legacy_abac_gke" {
  name     = "legacy-abac-gke"
  location = "us-central1"

  remove_default_node_pool = true
  initial_node_count       = 1

  enable_legacy_abac = true
}

# FAIL: GKE cluster without workload identity
resource "google_container_cluster" "no_workload_identity_gke" {
  name     = "no-workload-identity-gke"
  location = "us-central1"

  remove_default_node_pool = true
  initial_node_count       = 1

  private_cluster_config {
    enable_private_nodes = true
  }
}

# PASS: GKE node pool with security best practices
resource "google_container_node_pool" "secure_node_pool" {
  name       = "secure-node-pool"
  location   = "us-central1"
  cluster    = google_container_cluster.secure_gke.name
  node_count = 2

  node_config {
    machine_type = "e2-medium"
    disk_size_gb = 100
    disk_type    = "pd-standard"

    oauth_scopes = [
      "https://www.googleapis.com/auth/cloud-platform"
    ]

    service_account = "gke-nodes@project-id.iam.gserviceaccount.com"

    shielded_instance_config {
      enable_secure_boot          = true
      enable_integrity_monitoring = true
    }

    workload_metadata_config {
      mode = "GKE_METADATA"
    }

    metadata = {
      disable-legacy-endpoints = "true"
    }

    labels = {
      environment = "production"
    }
  }

  management {
    auto_repair  = true
    auto_upgrade = true
  }
}

# ============================================================================
# KUBERNETES RESOURCES (PROVIDER-AGNOSTIC)
# ============================================================================

# PASS: Pod with security best practices
resource "kubernetes_pod" "secure_pod" {
  metadata {
    name      = "secure-pod"
    namespace = "production"

    labels = {
      app = "secure-app"
    }
  }

  spec {
    service_account_name = "app-service-account"

    security_context {
      run_as_non_root = true
      run_as_user     = 1000
      fs_group        = 2000
      seccomp_profile {
        type = "RuntimeDefault"
      }
    }

    container {
      name  = "app"
      image = "myregistry.io/myapp:v1.0.0"

      security_context {
        allow_privilege_escalation = false
        privileged                 = false
        read_only_root_filesystem  = true
        run_as_non_root            = true
        run_as_user                = 1000

        capabilities {
          drop = ["ALL"]
        }
      }

      resources {
        limits = {
          cpu    = "500m"
          memory = "512Mi"
        }
        requests = {
          cpu    = "250m"
          memory = "256Mi"
        }
      }

      volume_mount {
        name       = "tmp"
        mount_path = "/tmp"
      }
    }

    volume {
      name = "tmp"
      empty_dir {}
    }
  }
}

# FAIL: Pod with privileged container
resource "kubernetes_pod" "privileged_pod" {
  metadata {
    name      = "privileged-pod"
    namespace = "production"
  }

  spec {
    container {
      name  = "app"
      image = "myapp:latest"

      security_context {
        privileged = true
      }
    }
  }
}

# FAIL: Pod running as root
resource "kubernetes_pod" "root_pod" {
  metadata {
    name      = "root-pod"
    namespace = "production"
  }

  spec {
    container {
      name  = "app"
      image = "myapp:latest"

      security_context {
        run_as_user = 0
      }
    }
  }
}

# FAIL: Pod without resource limits
resource "kubernetes_pod" "no_limits_pod" {
  metadata {
    name      = "no-limits-pod"
    namespace = "production"
  }

  spec {
    container {
      name  = "app"
      image = "myapp:latest"
    }
  }
}

# FAIL: Pod with writable root filesystem
resource "kubernetes_pod" "writable_root_pod" {
  metadata {
    name      = "writable-root-pod"
    namespace = "production"
  }

  spec {
    container {
      name  = "app"
      image = "myapp:latest"

      security_context {
        read_only_root_filesystem = false
      }
    }
  }
}

# PASS: Deployment with security best practices
resource "kubernetes_deployment" "secure_deployment" {
  metadata {
    name      = "secure-deployment"
    namespace = "production"

    labels = {
      app = "secure-app"
    }
  }

  spec {
    replicas = 3

    selector {
      match_labels = {
        app = "secure-app"
      }
    }

    template {
      metadata {
        labels = {
          app = "secure-app"
        }
      }

      spec {
        service_account_name = "app-service-account"

        security_context {
          run_as_non_root = true
          run_as_user     = 1000
          fs_group        = 2000
        }

        container {
          name  = "app"
          image = "myregistry.io/myapp:v1.0.0"

          security_context {
            allow_privilege_escalation = false
            privileged                 = false
            read_only_root_filesystem  = true
            run_as_non_root            = true

            capabilities {
              drop = ["ALL"]
            }
          }

          resources {
            limits = {
              cpu    = "500m"
              memory = "512Mi"
            }
            requests = {
              cpu    = "250m"
              memory = "256Mi"
            }
          }
        }
      }
    }
  }
}

# PASS: Network Policy with default deny
resource "kubernetes_network_policy" "default_deny_ingress" {
  metadata {
    name      = "default-deny-ingress"
    namespace = "production"
  }

  spec {
    pod_selector {}

    policy_types = ["Ingress"]
  }
}

# PASS: Network Policy allowing specific traffic
resource "kubernetes_network_policy" "allow_app_traffic" {
  metadata {
    name      = "allow-app-traffic"
    namespace = "production"
  }

  spec {
    pod_selector {
      match_labels = {
        app = "secure-app"
      }
    }

    policy_types = ["Ingress", "Egress"]

    ingress {
      from {
        pod_selector {
          match_labels = {
            app = "frontend"
          }
        }
      }

      ports {
        protocol = "TCP"
        port     = "8080"
      }
    }

    egress {
      to {
        pod_selector {
          match_labels = {
            app = "database"
          }
        }
      }

      ports {
        protocol = "TCP"
        port     = "5432"
      }
    }
  }
}

# PASS: Service Account with limited permissions
resource "kubernetes_service_account" "app_sa" {
  metadata {
    name      = "app-service-account"
    namespace = "production"
  }

  automount_service_account_token = false
}

# PASS: Role with limited permissions
resource "kubernetes_role" "app_role" {
  metadata {
    name      = "app-role"
    namespace = "production"
  }

  rule {
    api_groups = [""]
    resources  = ["configmaps"]
    verbs      = ["get", "list"]
  }
}

# PASS: RoleBinding
resource "kubernetes_role_binding" "app_role_binding" {
  metadata {
    name      = "app-role-binding"
    namespace = "production"
  }

  role_ref {
    api_group = "rbac.authorization.k8s.io"
    kind      = "Role"
    name      = kubernetes_role.app_role.metadata[0].name
  }

  subject {
    kind      = "ServiceAccount"
    name      = kubernetes_service_account.app_sa.metadata[0].name
    namespace = "production"
  }
}

# FAIL: ClusterRole with wildcard permissions
resource "kubernetes_cluster_role" "wildcard_cluster_role" {
  metadata {
    name = "wildcard-cluster-role"
  }

  rule {
    api_groups = ["*"]
    resources  = ["*"]
    verbs      = ["*"]
  }
}

# PASS: Secret (external secrets preferred)
resource "kubernetes_secret" "app_secret" {
  metadata {
    name      = "app-secret"
    namespace = "production"
  }

  type = "Opaque"

  data = {
    # In production, use external secrets management
    api_key = "base64encodedvalue"
  }
}

# ============================================================================
# SUPPORTING RESOURCES
# ============================================================================

resource "aws_iam_role" "eks_cluster_role" {
  name = "eks-cluster-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action = "sts:AssumeRole"
      Effect = "Allow"
      Principal = {
        Service = "eks.amazonaws.com"
      }
    }]
  })
}

resource "aws_iam_role" "eks_node_role" {
  name = "eks-node-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action = "sts:AssumeRole"
      Effect = "Allow"
      Principal = {
        Service = "ec2.amazonaws.com"
      }
    }]
  })
}

resource "aws_launch_template" "eks_nodes" {
  name_prefix = "eks-nodes-"
  image_id    = "ami-12345678"

  block_device_mappings {
    device_name = "/dev/xvda"

    ebs {
      volume_size = 20
      volume_type = "gp3"
      encrypted   = true
    }
  }

  metadata_options {
    http_endpoint               = "enabled"
    http_tokens                 = "required"
    http_put_response_hop_limit = 1
  }
}
