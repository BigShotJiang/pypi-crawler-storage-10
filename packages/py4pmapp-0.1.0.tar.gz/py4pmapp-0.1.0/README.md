# py4pmapp

Paquete para limpiar y preparar datos para PMApp (herramienta de Process Mining).

## Instalación

```bash
pip install py4pmapp
