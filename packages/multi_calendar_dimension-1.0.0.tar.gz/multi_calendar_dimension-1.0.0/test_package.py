"""
Test package for PyPI upload
"""

def hello():
    return "Hello from test package!"

if __name__ == "__main__":
    print(hello())
