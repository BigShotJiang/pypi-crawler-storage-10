from setuptools import setup

setup(
    name="test-pypi-upload-pouya",
    version="0.1.0",
    author="Pouya Kia",
    author_email="kiaa.pouya@gmail.com",
    description="Test package for PyPI upload",
    py_modules=["test_package"],
    python_requires=">=3.8",
)
