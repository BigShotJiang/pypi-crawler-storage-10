"""
Test suite for multi-calendar-dimension library
تست‌های کتابخانه چند تقویمی
"""

__version__ = "1.0.0"
