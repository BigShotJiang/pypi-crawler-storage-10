"""
Current date information package
"""

from .now import CurrentDate

__all__ = [
    'CurrentDate'
]
