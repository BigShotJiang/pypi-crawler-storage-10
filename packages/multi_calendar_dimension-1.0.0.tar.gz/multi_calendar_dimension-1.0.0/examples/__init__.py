"""
Examples for multi-calendar-dimension library
مثال‌های کتابخانه چند تقویمی
"""

__version__ = "1.0.0"
