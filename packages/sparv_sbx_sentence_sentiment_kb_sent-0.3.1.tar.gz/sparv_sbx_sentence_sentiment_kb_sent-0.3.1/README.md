# sparv-sbx-sentence-sentiment-kb-sent is now sparv-sbx-sentiment-kb-sent

This project has changed name to [`sparv-sbx-sentiment-kb-sent`](https://github.com/spraakbanken/sparv-sbx-sentiment-kb-sent).

## To use the new project:

- Uninstall this plugin: `sparv plugins uninstall sparv-sbx-sentence-sentiment-kb-sent`
- Install new plugin: `sparv plugins install sparv-sbx-sentiment-kb-sent`
