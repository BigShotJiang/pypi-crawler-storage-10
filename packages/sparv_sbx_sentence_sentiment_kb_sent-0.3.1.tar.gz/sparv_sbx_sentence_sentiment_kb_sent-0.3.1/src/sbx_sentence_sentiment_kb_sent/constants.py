"""Constants used in this project."""

PROJECT_NAME: str = "sbx_sentence_sentiment_kb_sent"
