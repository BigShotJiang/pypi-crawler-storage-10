"""Configuration management for benchmarks."""
