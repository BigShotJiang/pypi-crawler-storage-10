#!/bin/bash

####################################################################################################
# Recreates the virtual environment with frozen dependencies.
####################################################################################################

set -e -o pipefail

rm -rf .venv
uv sync --all-extras
