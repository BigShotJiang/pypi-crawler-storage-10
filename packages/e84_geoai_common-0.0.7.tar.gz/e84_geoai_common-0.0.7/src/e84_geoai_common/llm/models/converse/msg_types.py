from collections.abc import Sequence
from typing import Literal

from pydantic import BaseModel, ConfigDict

from e84_geoai_common.llm.models.converse.data_content_types import (
    ConverseCachePoint,
    ConverseImageContent,
    ConverseTextContent,
)
from e84_geoai_common.llm.models.converse.tool_use_types import (
    ConverseToolResultContent,
    ConverseToolUseContent,
)

ConverseMessageContentType = (
    ConverseTextContent
    | ConverseImageContent
    | ConverseToolUseContent
    | ConverseToolResultContent
    | ConverseCachePoint
)


class ConverseMessage(BaseModel):
    """Converse base model."""

    model_config = ConfigDict(strict=True, extra="forbid")

    role: Literal["assistant", "user"]
    content: Sequence[ConverseMessageContentType]


class ConverseUserMessage(BaseModel):
    """Converse user message model."""

    model_config = ConfigDict(strict=True, extra="forbid")

    role: Literal["user"] = "user"
    content: list[ConverseTextContent | ConverseToolResultContent]


class ConverseAssistantMessage(BaseModel):
    """Converse assistant message model."""

    model_config = ConfigDict(strict=True, extra="forbid")

    role: Literal["assistant"] = "assistant"
    content: list[ConverseTextContent | ConverseToolUseContent]
