.. py:currentmodule:: rubin_scheduler.data

.. _data-api:

========
Data API
========

.. automodule:: rubin_scheduler.data
    :imported-members:
    :members:
    :show-inheritance:
