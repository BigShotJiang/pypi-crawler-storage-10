.. py:currentmodule:: rubin_scheduler.scheduler

.. _fbs-api-details:

Detailers
^^^^^^^^^

.. automodule:: rubin_scheduler.scheduler.detailers
    :imported-members:
    :members:
    :show-inheritance:
