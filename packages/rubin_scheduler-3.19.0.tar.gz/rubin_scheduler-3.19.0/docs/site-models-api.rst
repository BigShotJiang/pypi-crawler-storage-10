.. py:currentmodule:: rubin_scheduler.site_models

.. _site-models-api:

===============
Site Models API
===============

.. automodule:: rubin_scheduler.site_models
    :imported-members:
    :members:
    :show-inheritance:
