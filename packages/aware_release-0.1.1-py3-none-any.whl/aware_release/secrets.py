"""Secret resolution helpers shared by aware-cli and release pipeline."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Protocol


@dataclass(frozen=True)
class SecretSpec:
    name: str
    description: str = ""
    scopes: tuple[str, ...] = ()


class SecretResolver(Protocol):
    def resolve(self, spec: SecretSpec) -> Optional[str]:  # pragma: no cover - interface
        ...


_secret_specs: dict[str, SecretSpec] = {}
_resolvers: list[tuple[int, SecretResolver]] = []


def register_secret(spec: SecretSpec) -> None:
    _secret_specs.setdefault(spec.name, spec)


def register_resolver(resolver: SecretResolver, priority: int = 0) -> None:
    _resolvers.append((priority, resolver))
    _resolvers.sort(key=lambda item: item[0], reverse=True)


class EnvResolver:
    def resolve(self, spec: SecretSpec) -> Optional[str]:
        return os.getenv(spec.name)


register_resolver(EnvResolver(), priority=0)


class _DotEnvResolver:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._loaded = False

    def resolve(self, spec: SecretSpec) -> Optional[str]:
        if not self._loaded:
            if self.path.exists():
                try:
                    from dotenv import load_dotenv
                except ImportError:  # pragma: no cover - optional dependency
                    self._fallback_load()
                else:  # pragma: no cover - exercised when module installed
                    load_dotenv(self.path, override=False)
            self._loaded = True
        return os.getenv(spec.name)

    def _fallback_load(self) -> None:
        try:
            content = self.path.read_text(encoding="utf-8")
        except OSError:  # pragma: no cover - IO errors bubble up silently
            return

        for line in content.splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            if "=" not in stripped:
                continue
            key, value = stripped.split("=", 1)
            key = key.strip()
            if not key:
                continue
            if key in os.environ:
                continue
            value = value.strip().strip('"').strip("'")
            os.environ[key] = value


def use_dotenv(path: str | Path, *, priority: int = -10) -> None:
    resolver = _DotEnvResolver(Path(path))
    register_resolver(resolver, priority=priority)


def resolve_secret(name: str) -> Optional[str]:
    spec = _secret_specs.get(name, SecretSpec(name=name))
    for _, resolver in _resolvers:
        value = resolver.resolve(spec)
        if value:
            return value
    return None


def list_secrets() -> List[SecretSpec]:
    return list(_secret_specs.values())


def describe_secret(name: str) -> dict[str, object]:
    spec = _secret_specs.get(name, SecretSpec(name=name))
    value = resolve_secret(name)
    return {
        "name": spec.name,
        "description": spec.description,
        "scopes": list(spec.scopes),
        "present": value is not None,
    }
