import json
from triclick_doc_toolset.service import run_review

# UV_INDEX_URL=https://pypi.org/simple/ uv sync --extra dev
# UV_INDEX_URL=https://pypi.org/simple/ PYTHONPATH=src uv run python tests/test_run_review.py

if __name__ == "__main__":
    result = run_review(
        document_path="/Users/zk/code@hill/triclick-doc-toolset/tests/data.input/test",
        output_dir="/Users/zk/code@hill/triclick-doc-toolset/tests/data.output",
    )
    print("测试开始执行！")
    # print(json.dumps(result, ensure_ascii=False, indent=2))
