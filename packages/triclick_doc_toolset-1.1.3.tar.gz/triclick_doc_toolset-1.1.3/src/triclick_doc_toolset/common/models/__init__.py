"""Common data models for the triclick document toolset."""

from .table_item import TableItem

__all__ = ['TableItem']