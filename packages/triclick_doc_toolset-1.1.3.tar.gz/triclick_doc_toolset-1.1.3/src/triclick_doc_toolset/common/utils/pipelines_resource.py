from __future__ import annotations

from pathlib import Path
from typing import Optional

# 优先使用 importlib.resources 访问打包资源
try:
    from importlib.resources import files as _pkg_files
except Exception:
    _pkg_files = None


def resolve_pipelines_yaml(name: str) -> str:
    """解析包内 pipelines 目录下 YAML 的本地文件路径。

    - 优先使用 `importlib.resources.files("triclick_doc_toolset").joinpath("pipelines", name)`；
    - 若资源不可直接作为文件（例如 zip 包），则抽取到临时目录后返回；
    - 开发模式（未打包）回退到仓库根的 `pipelines/` 目录。
    """
    if not name:
        raise ValueError("name is required")

    # 1) 打包场景：通过 importlib.resources 定位
    if _pkg_files is not None:
        try:
            res = _pkg_files("triclick_doc_toolset").joinpath("pipelines", name)
            p_str = str(res)
            if Path(p_str).exists():
                return p_str
            # 资源不可直接映射为本地路径，抽取到临时目录
            import tempfile
            import shutil
            tmp_dir = Path(tempfile.gettempdir()) / "triclick-doc-toolset-pipelines"
            tmp_dir.mkdir(parents=True, exist_ok=True)
            tmp_file = tmp_dir / name
            with res.open("rb") as fp_in, open(tmp_file, "wb") as fp_out:
                shutil.copyfileobj(fp_in, fp_out)
            return str(tmp_file)
        except Exception:
            # 回退到开发模式
            pass

    # 2) 开发场景：从源码路径回退（当前文件位于 src/triclick_doc_toolset/common/utils/...）
    repo_root = Path(__file__).resolve().parents[4]
    return str(repo_root / "pipelines" / name)