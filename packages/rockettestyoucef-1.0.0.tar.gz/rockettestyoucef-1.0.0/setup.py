from setuptools import setup

setup(
   name='rocketTestYoucef',
   version='1.0.0',
   author='khedim youcef',
   author_email='khedimyoucefdz@gmail.com',
   packages=['rocketTestYoucef'],
   url='http://pypi.python.org/pypi/rocketTestYoucef/',
   license='LICENSE.txt',
   description='An awesome package that does something',
   long_description=open('README.md').read(),
   long_description_content_type="text/markdown",
   install_requires=[]
)