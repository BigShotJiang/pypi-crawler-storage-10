from typing import List, Optional, Dict, Any
from pydantic import BaseModel
from datetime import datetime


class OrchestrationJobResponse(BaseModel):
    """Response model for orchestration job (deprecated)."""
    job_id: str
    status: str
    message: str
    started_at: str
    stats: Optional[Dict[str, Any]] = None


class OrchestrationJobStatus(BaseModel):
    """Status model for orchestration job (deprecated)."""
    job_id: str
    status: str  # "running", "completed", "failed"
    started_at: str
    completed_at: Optional[str] = None
    stats: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    analytics_run_id: Optional[int] = None
    analytics_run_ids: Optional[List[int]] = None


class EnrichmentResult(BaseModel):
    """Result model for individual listing enrichment."""
    original_listing_id: int
    enriched_listing_id: str
    status: str  # "success", "failed", "timeout"
    enriched_data: Optional[Dict[str, Any]] = None
    error_message: Optional[str] = None
    processing_time_seconds: float
    image_count: int
    timestamp: datetime


class BatchEnrichmentResult(BaseModel):
    """Result model for batch listing enrichment."""
    results: List[EnrichmentResult]
    total_processed: int
    total_failed: int
    total_successful: int
    processing_time_seconds: float


class DescriptionAnalysisResult(BaseModel):
    """Result model for individual description analysis."""
    original_listing_id: int
    enriched_listing_id: Optional[int] = None
    status: str  # "success", "failed", "timeout"
    analytics_run_id: Optional[int] = None
    error_message: Optional[str] = None
    processing_time_seconds: float
    timestamp: datetime
    
    # Additional fields from DescriptionAnalyticsRun
    description_output: Optional[str] = None
    description: Optional[str] = None
    model: Optional[str] = None
    temperature: Optional[str] = None
    prompt_id: Optional[int] = None
    enrichment_orchestration_run_id: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class ImageAnalysisResult(BaseModel):
    """Result model for individual image analysis."""
    original_image_id: int
    enriched_image_id: Optional[int] = None
    original_listing_id: Optional[int] = None
    enriched_listing_id: Optional[int] = None
    status: str  # "success", "failed", "timeout"
    analytics_run_id: Optional[int] = None
    error_message: Optional[str] = None
    processing_time_seconds: float
    timestamp: Optional[datetime] = None
    
    image_data: Optional[str] = None
    image_analytics_output: Optional[str] = None
    model: Optional[str] = None
    temperature: Optional[str] = None
    settings_json: Optional[str] = None
    prompt_id: Optional[int] = None
    enrichment_orchestration_run_id: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class BatchImageAnalysisResult(BaseModel):
    """Result model for batch image analysis of a listing."""
    listing_id: str
    status: str  # "success", "failed", "timeout"
    analytics_run_ids: Optional[List[int]] = None
    error_message: Optional[str] = None
    processing_time_seconds: float
    image_count: int
    timestamp: datetime
    results: List[ImageAnalysisResult] = []


class FloorplanAnalysisResult(BaseModel):
    """Result model for individual floorplan analysis."""
    original_floorplan_id: int
    enriched_floorplan_id: Optional[int] = None
    original_listing_id: Optional[int] = None
    enriched_listing_id: Optional[int] = None
    status: str  # "success", "failed", "timeout"
    analytics_run_id: Optional[int] = None
    error_message: Optional[str] = None
    processing_time_seconds: float
    timestamp: Optional[datetime] = None
    
    floorplan_data: Optional[str] = None
    floorplan_analytics_output: Optional[str] = None
    model: Optional[str] = None
    temperature: Optional[str] = None
    settings_json: Optional[str] = None
    prompt_id: Optional[int] = None
    enrichment_orchestration_run_id: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class BatchFloorplanAnalysisResult(BaseModel):
    """Result model for batch floorplan analysis of a listing."""
    listing_id: str
    status: str  # "success", "failed", "timeout"
    analytics_run_ids: Optional[List[int]] = None
    error_message: Optional[str] = None
    processing_time_seconds: float
    floorplan_count: int
    timestamp: datetime
    results: List[FloorplanAnalysisResult] = []

