

::: dranspose.distributed