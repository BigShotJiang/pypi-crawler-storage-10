"""Utility functions for par_scrape."""
