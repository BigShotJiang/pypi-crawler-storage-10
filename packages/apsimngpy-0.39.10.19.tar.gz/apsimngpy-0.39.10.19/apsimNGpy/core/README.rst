All modules defined in this directory need pythonnet to start and are linked to the interaction or integration with C#

Importing modules in this dir will not succeed if APSIM bin path is not properly configured in the env variables