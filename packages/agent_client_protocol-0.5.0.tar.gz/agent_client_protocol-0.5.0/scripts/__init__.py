"""Utility scripts for generating ACP bindings."""
