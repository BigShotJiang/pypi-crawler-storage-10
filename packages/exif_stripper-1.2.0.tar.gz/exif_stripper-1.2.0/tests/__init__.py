"""Test suite for exif_stripper."""
