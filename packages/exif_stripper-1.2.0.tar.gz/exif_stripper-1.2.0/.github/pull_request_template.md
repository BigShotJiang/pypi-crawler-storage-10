<!-- Which issue does this address? -->
Fixes #

**Describe your changes**

<!-- TODO -->

**Checklist**

<!-- Place an X between the [ ] for completed tasks -->

- [ ] Test cases have been modified/added to cover any code changes.
- [ ] Docstrings have been modified/created for any code changes.
- [ ] All linting and formatting checks pass (see the [contributing guidelines](https://github.com/stefmolin/exif-stripper/blob/main/CONTRIBUTING.md) for more information).
