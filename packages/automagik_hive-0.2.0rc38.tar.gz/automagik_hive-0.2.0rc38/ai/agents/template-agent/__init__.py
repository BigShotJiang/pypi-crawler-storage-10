"""Template Agent - Foundational agent template for specialized agent development"""

from .agent import get_template_agent

__all__ = ["get_template_agent"]
