"""Authentication integration tests."""
