Contributors
------------

- Laurent Lasudry, laurent.lasudry@affinitic.be
- Olivier Delaere, olivier.delaere@imio.be
- Gauthier Bastien, gauthier.bastien@imio.be
- Antoine Duchêne, antoine.duchene@imio.be
