def main() -> None:
    print("audioscope installed.")
