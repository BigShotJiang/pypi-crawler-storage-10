# audioscope
A Forensic &amp; Diagnostic Benchmark for Speech AI tasks
