# textglue

### Text Glue
### An extremely simple text based static templating system

textglue supports only two tags:

    {{file:_body.html}} {{template:_body.html}}

The "file" tag includes the raw source of the file, while
the template tag recursively evaluates the file as another
template. By default, the maximum recurse depth for
templates is 8.

Files with an
underscore prefix are ignored unless used in a template.
Files with a ".html" extension are rendered as a template,
and files without an underscore prefix or ".html" extension,
are directly copied to the output folder.

The default input and output folders are "tg\_src" and
"tg\_out". Be careful, as the output folder is
deleted every build.
