class GrabitError(Exception):
    pass
