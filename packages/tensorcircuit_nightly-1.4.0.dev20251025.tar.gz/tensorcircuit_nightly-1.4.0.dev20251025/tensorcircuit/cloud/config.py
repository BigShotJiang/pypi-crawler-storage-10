tencent_base_url = "https://quantum.tencent.com/cloud/quk/"
