"""Tests for the LSBible MCP server."""
