"""LSBible MCP Server module."""

from lsbible.mcp.server import mcp

__all__ = ["mcp"]
