"""
Documentation for `doccmd`.
"""
