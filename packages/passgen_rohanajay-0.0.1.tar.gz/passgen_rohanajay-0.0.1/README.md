# passgen 🔐

A simple and customizable Python package to generate random passwords.

## Installation
```bash
pip install passgen
