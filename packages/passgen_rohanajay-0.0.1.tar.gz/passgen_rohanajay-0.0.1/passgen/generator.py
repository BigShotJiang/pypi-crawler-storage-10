import random
import string

def generate(length=12, use_digits=True, use_symbols=True):
    """
    Generate a random password with customizable length and character sets.

    Parameters:
        length (int): Length of the password (default 12)
        use_digits (bool): Include digits (0-9)
        use_symbols (bool): Include special characters (!@# etc.)

    Returns:
        str: Randomly generated password
    """
    letters = string.ascii_letters
    digits = string.digits if use_digits else ''
    symbols = "!@#$%^&*()-_=+[]{};:,<.>?" if use_symbols else ''

    all_chars = letters + digits + symbols

    if not all_chars:
        raise ValueError("No character sets selected!")

    return ''.join(random.choice(all_chars) for _ in range(length))
