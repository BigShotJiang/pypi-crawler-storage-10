from passgen import generate

def test_default_password():
    password = generate()
    assert len(password) == 12
    assert any(c.islower() for c in password)
    assert any(c.isupper() for c in password)

def test_no_symbols():
    password = generate(use_symbols=False)
    for c in password:
        assert c not in "!@#$%^&*()-_=+[]{};:,<.>?"
