#! /usr/bin/env python3

# Irfansha Shaik, Aarhus, 2 February 2024.
import argparse, os
from qiskit import QuantumCircuit
from qiskit.quantum_info import Clifford
import swapple_z3 as sz

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Solve a cnot instance with swapple and z3"
    )
    parser.add_argument(
        "-v", "--verbose", help="show relavant information", action="store_true"
    )
    parser.add_argument(
        "--circuit_in",
        help="circuit in QASM format",
        default="../CnotSynthesis/benchmarks/random_cnot_circuits/rand_n5_g20/rand_5_20-0.qasm",
    )
    parser.add_argument(
        "--plan_length",
        type=int,
        help="Number of time steps in the sat encoding (also makespan), default=4",
        default=4,
    )

    args = parser.parse_args()
    circuit = QuantumCircuit.from_qasm_file(args.circuit_in)
    circuit_clifford = Clifford(circuit)
    matrix_str = ""
    for row in circuit_clifford.destab_x:
        cur_cells = []
        for cell in row:
            if cell == True:
                cur_cells.append("1")
            else:
                cur_cells.append("0")
        matrix_str += " ".join(x for x in cur_cells) + "\n"

    swapple_source_location = os.path.dirname(sz.__file__)
    aux_files = os.path.join(swapple_source_location, "intermediate_files")
    input_text_path = os.path.join(aux_files, "input.txt")

    # write text file to intermediate files:
    f = open(input_text_path, "w")
    f.write(matrix_str)
    f.close()

    command = (
        "./swapple_z3.py --start "
        + str(args.plan_length)
        + " -d "
        + str(args.plan_length)
        + " -f "
        + input_text_path
    )
    print(command)
    os.system(command)
