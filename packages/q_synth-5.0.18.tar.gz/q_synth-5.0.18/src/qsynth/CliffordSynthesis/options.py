# Irfansha Shaik, 15 January 2024, Aarhus.

"""
Aurgument options for various clifford synthesis calls:
"""


class Options:
    def __init__(self):
        self.verbose = False
