# harlequin-odbc CHANGELOG

All notable changes to this project will be documented in this file.

## [Unreleased]

## [0.4.0] - 2025-10-29

- Drops support for Python 3.9; adds support for Python 3.14
- This project is now built using uv.

## [0.3.1] - 2025-03-17

- Fixes a crash caused by ODBC drivers that return non-standard data from a call to `cursor.tables()` ([tconbeer/harlequin#780](https://github.com/tconbeer/harlequin/issues/780) - thank you [@khalid-talakshi](https://github.com/khalid-talakshi)!).

## [0.3.0] - 2025-02-25

- The Data Catalog now displays all databases on the connected server, not just the currently-connected database ([tconbeer/harlequin#415](https://github.com/tconbeer/harlequin/discussions/415)).
- Columns in the Data Catalog are now fetched lazily ([#12](https://github.com/tconbeer/harlequin-odbc/issues/12), [#13](https://github.com/tconbeer/harlequin-odbc/issues/13)).
- Data Catalog items now support basic interactions ([#14](https://github.com/tconbeer/harlequin-odbc/issues/14)).

## [0.2.0] - 2025-01-08

- Drops support for Python 3.8
- Adds support for Python 3.13
- Adds support for Harlequin 2.X

## [0.1.1] - 2024-01-09

### Bug Fixes

- Renames package to use hyphen.

## [0.1.0] - 2024-01-09

### Features

- Adds a basic ODBC adapter.

[unreleased]: https://github.com/tconbeer/harlequin-odbc/compare/0.4.0...HEAD
[0.4.0]: https://github.com/tconbeer/harlequin-odbc/compare/0.3.1...0.4.0
[0.3.1]: https://github.com/tconbeer/harlequin-odbc/compare/0.3.0...0.3.1
[0.3.0]: https://github.com/tconbeer/harlequin-odbc/compare/0.2.0...0.3.0
[0.2.0]: https://github.com/tconbeer/harlequin-odbc/compare/0.1.1...0.2.0
[0.1.1]: https://github.com/tconbeer/harlequin-odbc/compare/0.1.0...0.1.1
[0.1.0]: https://github.com/tconbeer/harlequin-odbc/compare/dbe2dbd1da1930117c1572ca751d9cd9d43928b6...0.1.0
