from .lt_remote import LtRemote
from .generic import Generic

usb_types = {
        "LtRemote": LtRemote,
        "Generic": Generic
        }
