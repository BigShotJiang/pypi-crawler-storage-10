def run(action, music=None, **kwargs):
    for music in action.music_list(music):
        if music.is_unloadable():
            music.unload()

def description(action, music=None, **kwargs):
    if music is not None:
        return _("unload music « {music_name} » from memory").format(music_name=music.name)
    else:
        return _("unload all music from memory")
