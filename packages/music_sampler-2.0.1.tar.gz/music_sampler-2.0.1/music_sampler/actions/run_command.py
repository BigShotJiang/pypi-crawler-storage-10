import shlex, subprocess

def run(action, command="", wait=False, **kwargs):
    action.process = subprocess.Popen(command, shell=True)
    if wait:
        action.process.wait()

def description(action, command="", wait=False, **kwargs):
    if wait:
        message = _("running command {command} (waiting for its execution to finish)")
    else:
        message = _("running command {command}")

    return message.format(command=command)
