def run(action, music=None, **kwargs):
    for music in action.music_list(music):
        if music.is_loaded_playing():
            music.pause()

def description(action, music=None, **kwargs):
    if music is not None:
        return _("pausing « {music_name} »").format(music_name=music.name)
    else:
        return _("pausing all musics")
