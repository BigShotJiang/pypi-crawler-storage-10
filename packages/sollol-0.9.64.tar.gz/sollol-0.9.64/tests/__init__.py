"""SOLLOL test suite."""
