.. _spkg_dsdp:

dsdp: Semidefinite programming solver
=====================================

Description
-----------

Implementation of an interior-point method for semidefinite
programming. It provides primal and dual solutions, exploits low-rank
structure and sparsity in the data, and has relatively low memory
requirements for an interior-point method. It allows feasible and
infeasible starting points and provides approximate certificates of
infeasibility when no feasible solution exists. The dual-scaling
algorithm implemented in this package has a convergence proof and
worst-case polynomial complexity under mild assumptions on the data.


License
-------

Permissive open source license
https://www.mcs.anl.gov/hs/software/DSDP/Copyright.txt


Upstream Contact
----------------

https://www.mcs.anl.gov/hs/software/DSDP/


Type
----

optional


Dependencies
------------

- $(BLAS)
- :ref:`spkg_cmake`
- :ref:`spkg_ninja_build`

Version Information
-------------------

package-version.txt::

    5.8

See https://repology.org/project/dsdp/versions

Installation commands
---------------------

.. tab:: Sage distribution:

   .. CODE-BLOCK:: bash

       $ sage -i dsdp

.. tab:: Arch Linux:

   .. CODE-BLOCK:: bash

       $ sudo pacman -S dsdp

.. tab:: conda-forge:

   .. CODE-BLOCK:: bash

       $ conda install dsdp

.. tab:: Debian/Ubuntu:

   .. CODE-BLOCK:: bash

       $ sudo apt-get install libdsdp-dev

.. tab:: Fedora/Redhat/CentOS:

   .. CODE-BLOCK:: bash

       $ sudo dnf install DSDP-devel

.. tab:: FreeBSD:

   .. CODE-BLOCK:: bash

       $ sudo pkg install math/dsdp

.. tab:: Gentoo Linux:

   .. CODE-BLOCK:: bash

       $ sudo emerge sci-libs/dsdp

.. tab:: MacPorts:

   .. CODE-BLOCK:: bash

       $ sudo port install DSDP


However, these system packages will not be used for building Sage
because ``spkg-configure.m4`` has not been written for this package;
see :issue:`27330` for more information.
