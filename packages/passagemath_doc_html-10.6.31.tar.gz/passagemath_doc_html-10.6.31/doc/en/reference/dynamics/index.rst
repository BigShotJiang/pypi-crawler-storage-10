.. _sage.dynamics:

Discrete dynamics
=================

.. toctree::
   :maxdepth: 1

   cellular_automata
   complex_dynamics
   sage/dynamics/finite_dynamical_system
   sage/sandpiles/sandpile

.. SEEALSO::

    - :mod:`sage.combinat.e_one_star`
    - :mod:`sage.combinat.constellation`


Arithmetic Dynamical Systems
----------------------------

.. toctree::
   :maxdepth: 1

   sage/dynamics/arithmetic_dynamics/generic_ds
   sage/dynamics/arithmetic_dynamics/affine_ds
   sage/dynamics/arithmetic_dynamics/projective_ds
   sage/dynamics/arithmetic_dynamics/product_projective_ds
   sage/dynamics/arithmetic_dynamics/wehlerK3
   sage/dynamics/arithmetic_dynamics/berkovich_ds
   sage/dynamics/arithmetic_dynamics/dynamical_semigroup


.. SEEALSO::

    - :mod:`sage.schemes.affine.affine_morphism`
    - :mod:`sage.schemes.projective.projective_morphism`
    - :mod:`sage.schemes.product_projective.morphism`

.. include:: ../footer.txt
