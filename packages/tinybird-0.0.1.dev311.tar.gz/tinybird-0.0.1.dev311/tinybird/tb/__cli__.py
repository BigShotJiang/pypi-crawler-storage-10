
__name__ = 'tinybird'
__description__ = 'Tinybird Command Line Tool'
__url__ = 'https://www.tinybird.co/docs/forward/commands'
__author__ = 'Tinybird'
__author_email__ = 'support@tinybird.co'
__version__ = '0.0.1.dev311'
__revision__ = 'd56057f'
