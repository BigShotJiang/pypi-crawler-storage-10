e = 2.7182818284590
pi = 3.1415926535
def sqrt(n):
    guess = n / 2
    for _ in range(100):
        guess = (guess + n / guess) / 2
    return guess
def add(*n):
    answer = 0
    for i in n:
        answer += i
    return answer
def remove(w,l=0.0, *n):
    for i in n:
        l -= i
    return w - l  
def pow(n,l=0.0,*r):
    guess = sum([l ** i for i in r]) if r else l
    return n ** guess
def divide(n, l=0.0, *r):
    guess = sum([l / i for i in r]) if r else l
    return n / guess
def multiply(n, l=0.0 , *r):
    guess = sum(l * i for i in r) if r else l
    return n * guess
class noaMathError(Exception):
    #this is the base class for all noaMath Errors
    pass
class noaMathVectorError(noaMathError):
    #raised when vector oparations dont match
    def __init__(self,shape_a,shape_b):
        message = f"vectors shapes {shape_a} and {shape_b} are not aligned for the dot pruoduct or they are not vectors"
        super().__init__(message)
def dot(o,t):
    try:
        if len(o) != len(t):
            raise ValueError('The vectors have to have the same value')
        return sum(x * y for x, y in zip(o,t))
    except TypeError:
        raise noaMathVectorError(o,t)

