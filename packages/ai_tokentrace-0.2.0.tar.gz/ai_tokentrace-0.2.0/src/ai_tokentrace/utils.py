# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Any, List, Optional

from .data_model import ModalityUsage, TokenUsageRecord


def extract_usage_metadata(response: Any) -> Optional[Any]:
    """Extracts usage_metadata from a response object."""
    usage = getattr(response, "usage_metadata", None)
    if not usage and hasattr(response, "raw_response"):
        usage = getattr(response.raw_response, "usage_metadata", None)
    return usage


def convert_modality_details(details: Optional[list]) -> Optional[List[ModalityUsage]]:
    """Converts google.genai modality details to ModalityUsage list."""
    if not details:
        return None
    return [
        ModalityUsage(modality=str(d.modality), token_count=d.token_count)
        for d in details
        if d.modality and d.token_count is not None
    ]


def create_token_usage_record(
    response: Any,
    agent_name: Optional[str],
    model_name: str,
    method_name: str,
    authentication_method: str,
    project_id: Optional[str] = None,
    location: Optional[str] = None,
    session_id: Optional[str] = None,
    user_id: Optional[str] = None,
    images_generated: int = 0,
    videos_generated: int = 0,
) -> Optional[TokenUsageRecord]:
    """Creates a TokenUsageRecord from a response and context."""
    try:
        usage = extract_usage_metadata(response)

        input_tokens = 0
        output_tokens = 0
        total_tokens = None
        thinking_tokens = None
        cached_content_tokens = None
        tool_use_prompt_tokens = None
        input_modality_details = None
        output_modality_details = None
        cache_modality_details = None
        tool_use_modality_details = None

        if usage:
            input_tokens = usage.prompt_token_count or 0
            output_tokens = usage.candidates_token_count or 0
            total_tokens = usage.total_token_count
            thinking_tokens = usage.thoughts_token_count
            cached_content_tokens = usage.cached_content_token_count
            tool_use_prompt_tokens = usage.tool_use_prompt_token_count

            input_modality_details = convert_modality_details(
                usage.prompt_tokens_details
            )
            output_modality_details = convert_modality_details(
                usage.candidates_tokens_details
            )
            cache_modality_details = convert_modality_details(
                usage.cache_tokens_details
            )
            tool_use_modality_details = convert_modality_details(
                usage.tool_use_prompt_tokens_details
            )

        if (
            input_tokens == 0
            and output_tokens == 0
            and images_generated == 0
            and videos_generated == 0
        ):
            return None

        return TokenUsageRecord(
            agent_name=agent_name,
            model_name=model_name,
            method_name=method_name,
            authentication_method=authentication_method,
            project_id=project_id,
            location=location,
            session_id=session_id,
            user_id=user_id,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=total_tokens,
            thinking_tokens=thinking_tokens,
            cached_content_tokens=cached_content_tokens,
            tool_use_prompt_tokens=tool_use_prompt_tokens,
            input_modality_details=input_modality_details,
            output_modality_details=output_modality_details,
            cache_modality_details=cache_modality_details,
            tool_use_modality_details=tool_use_modality_details,
            images_generated=images_generated,
            videos_generated=videos_generated,
        )
    except (AttributeError, ValueError):
        return None
