# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""Core service definitions for exporting token usage data.

This module defines the concrete implementations for the token usage export
services. It provides both synchronous and asynchronous classes for each backend
(e.g., Logging, Firestore).

The synchronous classes are lightweight, non-blocking wrappers that instantiate
and manage their asynchronous counterparts in a background thread, providing a
user-friendly API for all application types.
"""

import json
import logging
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Protocol, runtime_checkable

import aiofiles

from .async_utils import run_async_in_background
from .data_model import TokenUsageRecord

_logger = logging.getLogger(__name__)


@runtime_checkable
class TokenUsageService(Protocol):
    """Protocol defining the interface for a synchronous token usage service."""

    def export(self, record: TokenUsageRecord) -> None:
        """Exports a token usage record."""
        ...  # pragma: no cover

    def get_inspection_tool(self) -> Optional[Callable[..., Any]]:
        """Returns a tool for inspecting token usage, if available."""
        return None


# --- Global Service Management ---

_global_service: TokenUsageService | None = None


def get_global_service() -> TokenUsageService:
    """Returns the global TokenUsageService, creating a default one if necessary."""
    global _global_service
    if _global_service is None:
        _global_service = LoggingTokenUsageService()
    return _global_service


def set_global_service(service: TokenUsageService) -> None:
    """Sets the global TokenUsageService."""
    global _global_service
    _global_service = service


# --- Logging Services ---


class _BaseLoggingService:
    """Base class for logging services, holding shared configuration."""

    def __init__(self, logger_name: str = "ai_tokentrace"):
        self._logger_name = logger_name


class AsyncLoggingTokenUsageService(_BaseLoggingService):
    """Asynchronously logs token usage records to the standard logger.

    This service provides an async `export` method for non-blocking logging
    in asynchronous applications.
    """

    def __init__(self, logger_name: str = "ai_tokentrace"):
        """Initializes the async logging service.

        Args:
            logger_name: The name of the logger to use (defaults to "ai_tokentrace").
        """
        super().__init__(logger_name)
        self._logger = logging.getLogger(self._logger_name)

    async def export(self, record: TokenUsageRecord) -> None:
        """Asynchronously logs the token usage record as a JSON string.

        Args:
            record: The `TokenUsageRecord` to export.
        """
        self._logger.info(record.model_dump_json())


class LoggingTokenUsageService(_BaseLoggingService):
    """Synchronously logs token usage records in a non-blocking manner.

    This service provides a standard synchronous `export` method that is safe
    to call from any application without blocking the main thread.
    """

    def __init__(self, logger_name: str = "ai_tokentrace"):
        """Initializes the sync logging service.

        Args:
            logger_name: The name of the logger to use (defaults to "ai_tokentrace").
        """
        super().__init__(logger_name)
        self._async_service = AsyncLoggingTokenUsageService(self._logger_name)

    def export(self, record: TokenUsageRecord) -> None:
        """Synchronously logs a record in a non-blocking, fire-and-forget manner.

        Args:
            record: The `TokenUsageRecord` to export.
        """
        run_async_in_background(self._async_service.export(record))


# --- JSONL File Services ---


class _BaseJsonlFileService:
    """Base class for JSONL file services, holding shared configuration."""

    def __init__(self, file_path: Path | str):
        self._file_path = Path(file_path)


class AsyncJsonlFileTokenUsageService(_BaseJsonlFileService):
    """Asynchronously appends token usage records to a JSON Lines file."""

    def __init__(self, file_path: Path | str):
        """Initializes the async JSONL file service.

        Args:
            file_path: The path to the JSONL file.
        """
        super().__init__(file_path)

    async def export(self, record: TokenUsageRecord) -> None:
        """Asynchronously appends the record as a new line in the JSONL file.

        Args:
            record: The `TokenUsageRecord` to export.
        """
        try:
            async with aiofiles.open(self._file_path, "a", encoding="utf-8") as f:
                await f.write(record.model_dump_json() + "\n")
        except Exception:
            _logger.exception("Failed to export token usage record to JSONL file.")

    def get_inspection_tool(self) -> Callable[[int], List[Dict[str, Any]]]:
        """Returns a tool to inspect the JSONL log file."""

        def inspect_token_usage_logs(limit: int = 5) -> List[Dict[str, Any]]:
            """
            Reads the most recent token usage records from the log file.
            Args:
                limit: The maximum number of recent records to return. Defaults to 5.
            """
            records = []
            if not self._file_path.exists():
                return []
            try:
                with open(self._file_path, "r", encoding="utf-8") as f:
                    for line in f:
                        if line.strip():
                            try:
                                records.append(json.loads(line))
                            except json.JSONDecodeError:
                                continue
                return records[-limit:]
            except Exception as e:
                _logger.error(f"Error reading token usage log: {e}")
                return [{"error": str(e)}]

        return inspect_token_usage_logs


class JsonlFileTokenUsageService(_BaseJsonlFileService):
    """Synchronously appends token usage records to a JSON Lines file."""

    def __init__(self, file_path: Path | str):
        """Initializes the sync JSONL file service.

        Args:
            file_path: The path to the JSONL file.
        """
        super().__init__(file_path)
        self._async_service = AsyncJsonlFileTokenUsageService(self._file_path)

    def export(self, record: TokenUsageRecord) -> None:
        """Synchronously appends a record in a non-blocking, fire-and-forget manner.

        Args:
            record: The `TokenUsageRecord` to export.
        """
        run_async_in_background(self._async_service.export(record))

    def get_inspection_tool(self) -> Callable[[int], List[Dict[str, Any]]]:
        """Returns a tool to inspect the JSONL log file."""
        return self._async_service.get_inspection_tool()


# --- Firestore Services ---


class _BaseFirestoreService:
    """Base class for Firestore services, holding shared configuration."""

    def __init__(self, collection_name: str = "token_usage_records"):
        self._collection_name = collection_name


class AsyncFirestoreTokenUsageService(_BaseFirestoreService):
    """Asynchronously exports token usage records to Google Cloud Firestore."""

    def __init__(self, collection_name: str = "token_usage_records"):
        """Initializes the async Firestore service.

        Args:
            collection_name: The name of the Firestore collection to use.
        """
        super().__init__(collection_name)
        try:
            from google.cloud.firestore import AsyncClient
        except ImportError:
            raise ImportError(
                "The 'google-cloud-firestore' library is required to use this service. "
                "Please install it with: pip install 'ai-tokentrace[firestore]' "
                "(or uv pip install 'ai-tokentrace[firestore]')"
            )
        self._client = AsyncClient()
        self._collection = self._client.collection(self._collection_name)

    async def export(self, record: TokenUsageRecord) -> None:
        """Asynchronously exports the record to a new document in the Firestore collection.

        Args:
            record: The `TokenUsageRecord` to export.
        """
        try:
            await self._collection.add(record.model_dump())
        except Exception:
            _logger.exception("Failed to export token usage record to Firestore.")

    def get_inspection_tool(self) -> Callable[..., Any]:
        """Returns an async tool to inspect Firestore logs."""

        async def inspect_token_usage_logs(limit: int = 5) -> List[Dict[str, Any]]:
            """
            Reads the most recent token usage records from Firestore.
            Args:
                limit: The maximum number of recent records to return. Defaults to 5.
            """
            try:
                # Import here to avoid top-level dependency if not using this tool
                from google.cloud import firestore

                query = self._collection.order_by(
                    "timestamp", direction=firestore.Query.DESCENDING
                ).limit(limit)
                results = []
                async for doc in query.stream():
                    results.append(doc.to_dict())
                return results
            except Exception as e:
                _logger.error(f"Error reading Firestore: {e}")
                return [{"error": str(e)}]

        return inspect_token_usage_logs


class FirestoreTokenUsageService(_BaseFirestoreService):
    """Synchronously exports token usage records to Google Cloud Firestore."""

    def __init__(self, collection_name: str = "token_usage_records"):
        """Initializes the sync Firestore service.

        Args:
            collection_name: The name of the Firestore collection to use.
        """
        super().__init__(collection_name)
        self._async_service = AsyncFirestoreTokenUsageService(self._collection_name)

    def export(self, record: TokenUsageRecord) -> None:
        """Synchronously exports a record in a non-blocking, fire-and-forget manner.

        Args:
            record: The `TokenUsageRecord` to export.
        """
        run_async_in_background(self._async_service.export(record))

    def get_inspection_tool(self) -> Callable[..., Any]:
        """Returns an async tool to inspect Firestore logs."""
        return self._async_service.get_inspection_tool()


# --- Pub/Sub Services ---


class _BasePubSubService:
    """Base class for Pub/Sub services, holding shared configuration."""

    def __init__(
        self, topic_id: str, project_id: str, subscription_id: Optional[str] = None
    ):
        self._topic_id = topic_id
        self._project_id = project_id
        self._subscription_id = subscription_id


class AsyncPubSubTokenUsageService(_BasePubSubService):
    """Asynchronously publishes token usage records to a Google Cloud Pub/Sub topic."""

    def __init__(
        self,
        topic_id: str,
        project_id: str,
        subscription_id: Optional[str] = None,
    ):
        """Initializes the async Pub/Sub service.

        Args:
            topic_id: The ID of the Pub/Sub topic to publish to.
            project_id: The Google Cloud project ID.
            subscription_id: Optional ID of a subscription to use for inspection.
        """
        super().__init__(topic_id, project_id, subscription_id)
        try:
            from google.cloud.pubsub_v1 import PublisherClient
        except ImportError:
            raise ImportError(
                "The 'google-cloud-pubsub' library is required to use this service. "
                "Please install it with: pip install 'ai-tokentrace[pubsub]' "
                "(or uv pip install 'ai-tokentrace[pubsub]')"
            )

        self._publisher = PublisherClient()
        self._topic_path = self._publisher.topic_path(self._project_id, self._topic_id)

    async def export(self, record: TokenUsageRecord) -> None:
        """Asynchronously publishes the record as a message to the Pub/Sub topic.

        Args:
            record: The `TokenUsageRecord` to export.
        """
        try:
            future = self._publisher.publish(
                self._topic_path, data=record.model_dump_json().encode("utf-8")
            )
            future.result()
        except Exception:
            _logger.exception("Failed to publish token usage record to Pub/Sub.")

    def get_inspection_tool(self) -> Optional[Callable[..., Any]]:
        """Returns a tool to inspect Pub/Sub messages if subscription_id is configured."""
        if not self._subscription_id:
            return None

        def inspect_token_usage_logs(limit: int = 5) -> List[str]:
            """
            Pulls recent messages from the Pub/Sub subscription.
            WARNING: This consumes messages from the subscription.
            Args:
                limit: The maximum number of messages to pull. Defaults to 5.
            """
            try:
                from google.cloud import pubsub_v1

                subscriber = pubsub_v1.SubscriberClient()
                subscription_path = subscriber.subscription_path(
                    self._project_id, self._subscription_id
                )

                # Use a short timeout so we don't block too long if no messages
                response = subscriber.pull(
                    request={"subscription": subscription_path, "max_messages": limit},
                    timeout=2.0,
                )

                messages = []
                ack_ids = []
                for msg in response.received_messages:
                    messages.append(msg.message.data.decode("utf-8"))
                    ack_ids.append(msg.ack_id)

                if ack_ids:
                    subscriber.acknowledge(
                        request={"subscription": subscription_path, "ack_ids": ack_ids}
                    )

                subscriber.close()
                return messages if messages else ["No new messages available."]
            except Exception as e:
                # Handle timeout (DeadlineExceeded) gracefully
                if "DeadlineExceeded" in str(type(e).__name__):
                    return ["No new messages available (timeout)."]
                _logger.error(f"Error pulling from Pub/Sub: {e}")
                return [f"Error reading Pub/Sub: {e}"]

        return inspect_token_usage_logs


class PubSubTokenUsageService(_BasePubSubService):
    """Synchronously publishes token usage records to a Google Cloud Pub/Sub topic."""

    def __init__(
        self,
        topic_id: str,
        project_id: str,
        subscription_id: Optional[str] = None,
    ):
        """Initializes the sync Pub/Sub service.

        Args:
            topic_id: The ID of the Pub/Sub topic to publish to.
            project_id: The Google Cloud project ID.
            subscription_id: Optional ID of a subscription to use for inspection.
        """
        super().__init__(topic_id, project_id, subscription_id)
        self._async_service = AsyncPubSubTokenUsageService(
            self._topic_id, self._project_id, self._subscription_id
        )

    def export(self, record: TokenUsageRecord) -> None:
        """Synchronously publishes a record in a non-blocking, fire-and-forget manner.

        Args:
            record: The `TokenUsageRecord` to export.
        """
        run_async_in_background(self._async_service.export(record))

    def get_inspection_tool(self) -> Optional[Callable[..., Any]]:
        """Returns a tool to inspect Pub/Sub messages if subscription_id is configured."""
        return self._async_service.get_inspection_tool()


# --- In-Memory Services ---


class InMemoryTokenUsageService:
    """Synchronously stores token usage records in memory. Useful for testing."""

    def __init__(self):
        self.records: list[TokenUsageRecord] = []

    def export(self, record: TokenUsageRecord) -> None:
        """Synchronously stores the record in memory."""
        self.records.append(record)

    def clear(self) -> None:
        """Clears all stored records."""
        self.records.clear()

    def get_inspection_tool(self) -> Callable[[int], List[Dict[str, Any]]]:
        """Returns a tool to inspect in-memory records."""

        def inspect_token_usage_logs(limit: int = 5) -> List[Dict[str, Any]]:
            """Reads the most recent token usage records from memory."""
            return [r.model_dump() for r in self.records[-limit:]]

        return inspect_token_usage_logs
