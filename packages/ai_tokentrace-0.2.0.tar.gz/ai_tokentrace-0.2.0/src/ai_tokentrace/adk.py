# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
ADK integration for ai-tokentrace.

This module provides a plugin for the Google Agent Development Kit (ADK)
to automatically track token usage.
"""

import contextvars
import inspect
import logging
from typing import Any, Optional, Sequence

from .services import TokenUsageService, get_global_service
from .utils import create_token_usage_record

logger = logging.getLogger(__name__)

try:
    from google.adk.agents.callback_context import CallbackContext
    from google.adk.models.llm_request import LlmRequest
    from google.adk.models.llm_response import LlmResponse
    from google.adk.plugins import BasePlugin

    ADK_AVAILABLE = True
except ImportError:
    ADK_AVAILABLE = False
    BasePlugin = object  # type: ignore
    CallbackContext = Any  # type: ignore
    LlmRequest = Any  # type: ignore
    LlmResponse = Any  # type: ignore

# Context variable to store the model name for the current task.
_current_model_name = contextvars.ContextVar(
    "current_model_name", default="unknown-adk-model"
)


class TokenTrackingPlugin(BasePlugin):
    """
    ADK plugin to track token usage from model calls.
    """

    def __init__(
        self,
        service: Optional[TokenUsageService] = None,
        agent_name: Optional[str] = None,
        tracked_agents: Optional[Sequence[str]] = None,
        name: str = "token_tracking_plugin",
    ):
        """
        Initialize the plugin.

        Args:
            service: The TokenUsageService to use for exporting data.
                     If None, uses the global default service.
            agent_name: Optional name override for the agent. If provided, ALL
                        tracked usage will be attributed to this name, regardless
                        of the actual agent name.
            tracked_agents: Optional list of agent names to track. If provided,
                            only agents with names in this list will be tracked.
                            If None or empty, all agents are tracked.
            name: Unique identifier for this plugin instance.
        """
        if ADK_AVAILABLE:
            super().__init__(name=name)
        else:
            logger.warning(
                "google-adk is not installed. TokenTrackingPlugin will be inactive."
            )

        self.service = service
        self._explicit_agent_name = agent_name
        self._tracked_agents = set(tracked_agents) if tracked_agents else None

    def _get_service(self) -> TokenUsageService:
        """Returns the configured service or the global default."""
        return self.service or get_global_service()

    async def before_model_callback(
        self,
        *,
        callback_context: CallbackContext,
        llm_request: LlmRequest,
    ) -> None:
        """
        Hook called before a model call. Captures the model name.
        """
        if not ADK_AVAILABLE:
            return None

        if llm_request.model:
            _current_model_name.set(llm_request.model)

        return None

    async def after_model_callback(
        self,
        *,
        callback_context: CallbackContext,
        llm_response: LlmResponse,
    ) -> None:
        """
        Hook called after a model call. Extracts usage and exports record.
        """
        if not ADK_AVAILABLE:
            return None

        # If streaming, only log when turn is complete.
        if llm_response.turn_complete is False:
            return None
        if llm_response.partial is True:
            return None

        # Determine actual agent name from callback_context
        actual_agent_name = callback_context.agent_name

        # Check if we should track this agent
        if (
            self._tracked_agents
            and actual_agent_name
            and actual_agent_name not in self._tracked_agents
        ):
            return None

        # Determine final agent name to record
        final_agent_name = self._explicit_agent_name or actual_agent_name or "adk-agent"

        # Retrieve model name from context variable
        model_name = _current_model_name.get()

        # Determine session and user IDs
        session_id = None
        user_id = None
        if callback_context.session:
            session_id = callback_context.session.id
            user_id = callback_context.session.user_id

        record = create_token_usage_record(
            response=llm_response,
            agent_name=final_agent_name,
            model_name=model_name,
            method_name="adk.generate_content",
            authentication_method="api_key",
            session_id=session_id,
            user_id=user_id,
        )

        if record:
            try:
                service = self._get_service()
                if inspect.iscoroutinefunction(service.export):
                    await service.export(record)
                else:
                    service.export(record)
            except Exception as e:
                logger.error(f"Failed to export token usage in ADK plugin: {e}")

        return None
