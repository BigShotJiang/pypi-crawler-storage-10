from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="occam-lite",
    version="1.0.0",
    author="Josh O'Brien",
    description="A lightweight complexity classifier for code functions",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/jobrien874/occam-lite",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Quality Assurance",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "scikit-learn>=1.0.0",
        "numpy>=1.21.0",
        "radon>=6.0.0",
    ],
    package_data={
        "occam_lite": ["models/*.pkl"],
    },
    include_package_data=True,
)
