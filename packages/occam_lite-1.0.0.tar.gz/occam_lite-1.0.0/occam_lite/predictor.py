# Copyright 2025 Josh O'Brien
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Occam Lite
===========================
Predicts algorithmic complexity from code using an 8-feature ML model.
"""

import pickle
from pathlib import Path
import radon.complexity as radon_complexity
import radon.raw as radon_raw


class BigOPredictor:
    """
    Uses an 8-feature Random Forest model for complexity prediction.

    Features:
        1. Lines of Code (LOC)
        2. Cyclomatic Complexity
        3. Nesting Depth
        4. Loop Count
        5. Conditional Count
        6. Complexity Density (cyclomatic / LOC)
        7. Total Branches (loops + conditionals)
        8. Complexity * Depth

    Example:
        >>> predictor = BigOPredictor()
        >>> result = predictor.predict("def test(): return 1")
        >>> print(result['complexity'])  # 'simple'
    """

    def __init__(self):
        """Initialize predictor and load models."""
        import sys

        base_path = Path(__file__).parent
        model_path = base_path / 'models' / 'model.pkl'
        extractor_path = base_path / 'models' / 'feature_extractor.pkl'

        if not model_path.exists():
            raise FileNotFoundError(f"Model not found at: {model_path}")
        if not extractor_path.exists():
            raise FileNotFoundError(f"Feature extractor not found at: {extractor_path}")

        # Add package path to sys.path for pickle to find simple_feature_extractor
        if str(base_path) not in sys.path:
            sys.path.insert(0, str(base_path))

        # Load model and feature extractor
        with open(model_path, 'rb') as f:
            self.model = pickle.load(f)

        with open(extractor_path, 'rb') as f:
            self.extractor = pickle.load(f)

    def extract_metrics(self, code):
        """
        Extract code metrics from raw code.

        Args:
            code (str): Source code to analyze

        Returns:
            dict: Metrics dictionary with keys:
                - loc: Lines of code
                - cyclomatic: Cyclomatic complexity
                - nesting: Nesting depth
                - loops: Number of loops
                - conditionals: Number of conditionals
        """
        try:
            # Get cyclomatic complexity using radon
            cc_results = radon_complexity.cc_visit(code)

            if not cc_results:
                # No functions found, analyze as single block
                raw_metrics = radon_raw.analyze(code)
                return {
                    'loc': raw_metrics.loc,
                    'cyclomatic': 1,
                    'nesting': 0,
                    'loops': code.count('for') + code.count('while'),
                    'conditionals': code.count('if') + code.count('else')
                }

            # Use first function found
            func = cc_results[0]

            # Count loops and conditionals
            loops = code.count('for') + code.count('while')
            conditionals = code.count('if') + code.count('else') + code.count('elif')

            return {
                'loc': func.endline - func.lineno + 1,
                'cyclomatic': func.complexity,
                'nesting': func.complexity // 2,  # Approximation
                'loops': loops,
                'conditionals': conditionals
            }

        except Exception:
            # Fallback: basic analysis
            lines = code.strip().split('\n')
            return {
                'loc': len(lines),
                'cyclomatic': 1,
                'nesting': 0,
                'loops': code.count('for') + code.count('while'),
                'conditionals': code.count('if') + code.count('else')
            }

    def predict(self, code):
        """
        complexity of code.

        Args:
            code (str): Function code to analyze

        Returns:
            dict: Prediction result containing:
                - complexity (str): 'simple', 'moderate', or 'complex'
                - confidence (float): Probability of prediction (0-1)
                - metrics (dict): Extracted code metrics
                - probabilities (dict): Probabilities for each class

        Example:
            >>> result = predictor.predict("def add(a, b): return a + b")
            >>> result['complexity']
            'simple'
            >>> result['confidence']
            0.98
        """
        # Extract metrics
        metrics = self.extract_metrics(code)

        # Extract features using the loaded extractor
        features = self.extractor.extract_features(metrics)

        # Scale features
        features_scaled = self.extractor.scaler.transform([features])

        # Predict
        prediction = self.model.predict(features_scaled)[0]
        probabilities = self.model.predict_proba(features_scaled)[0]

        # Convert prediction to label
        label = self.extractor.label_encoder.inverse_transform([prediction])[0]

        # Get confidence (probability of predicted class)
        confidence = probabilities[prediction]

        return {
            'complexity': label,
            'confidence': float(confidence),
            'metrics': metrics,
            'probabilities': {
                self.extractor.label_encoder.inverse_transform([i])[0]: float(prob)
                for i, prob in enumerate(probabilities)
            }
        }

    def predict_batch(self, code_samples):
        """
        Predict complexity for multiple code samples.

        Args:
            code_samples (list): List of code strings

        Returns:
            list: List of prediction dictionaries

        Example:
            >>> codes = ["def add(a, b): return a + b", "def sort(arr): ..."]
            >>> results = predictor.predict_batch(codes)
        """
        return [self.predict(code) for code in code_samples]


def predict_complexity(code):
    """
    Convenience function for single predictions.

    Args:
        code (str): Function code to analyze

    Returns:
        dict: Prediction result (see BigOPredictor.predict for format)

    Example:
        >>> from occam_lite import predict_complexity
        >>> result = predict_complexity("def test(): return 1")
        >>> print(result['complexity'])
        'simple'
    """
    predictor = BigOPredictor()
    return predictor.predict(code)
