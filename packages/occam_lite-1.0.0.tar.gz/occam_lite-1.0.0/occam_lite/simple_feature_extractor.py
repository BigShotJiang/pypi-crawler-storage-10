# Copyright 2025 Josh O'Brien
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Simple Feature Extractor (8 Features Only)
==========================================
Used for models that don't have full function code.
"""

import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder


class SimpleFeatureExtractor:
    """Extract only the original 8 features (no advanced features needed)."""

    def __init__(self):
        self.scaler = StandardScaler()
        self.label_encoder = LabelEncoder()
        self.feature_names = [
            'loc', 'cyclomatic', 'nesting', 'loops', 'conditionals',
            'complexity_density', 'total_branches', 'complexity_depth'
        ]

    def extract_features(self, metrics):
        """Extract 8 features from metrics dict."""
        features = []

        # Direct features (5)
        features.append(metrics['loc'])
        features.append(metrics['cyclomatic'])
        features.append(metrics['nesting'])
        features.append(metrics['loops'])
        features.append(metrics['conditionals'])

        # Derived features (3)
        features.append(metrics['cyclomatic'] / max(metrics['loc'], 1))  # Complexity density
        features.append(metrics['loops'] + metrics['conditionals'])  # Total branches
        features.append(metrics['nesting'] * metrics['cyclomatic'])  # Complexity * depth

        return np.array(features)

    def fit_transform(self, dataset):
        """Fit and transform training data."""
        X = []
        y = []

        for item in dataset:
            features = self.extract_features(item['features'])
            X.append(features)
            y.append(item['label'])

        X = np.array(X)
        y = np.array(y)

        # Fit and transform
        X_scaled = self.scaler.fit_transform(X)
        y_encoded = self.label_encoder.fit_transform(y)

        return X_scaled, y_encoded

    def transform(self, dataset):
        """Transform test data using fitted scaler."""
        X = []
        y = []

        for item in dataset:
            features = self.extract_features(item['features'])
            X.append(features)
            y.append(item['label'])

        X = np.array(X)
        y = np.array(y)

        X_scaled = self.scaler.transform(X)
        y_encoded = self.label_encoder.transform(y)

        return X_scaled, y_encoded
