# Copyright 2025 Josh O'Brien
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Occam Lite - Complexity Classifier
=========================================

A lightweight machine learning model for predicting algorithmic complexity
of code functions.

Basic usage:
    >>> from occam_lite import predict_complexity
    >>>
    >>> code = '''
    ... def bubble_sort(arr):
    ...     for i in range(len(arr)):
    ...         for j in range(len(arr) - i - 1):
    ...             if arr[j] > arr[j + 1]:
    ...                 arr[j], arr[j + 1] = arr[j + 1], arr[j]
    ... '''
    >>>
    >>> result = predict_complexity(code)
    >>> print(result['complexity'])  # 'complex'
    >>> print(result['confidence'])  # 0.95

Features:
- 8-feature model (LOC, cyclomatic complexity, nesting, etc.)
- Random Forest classifier (98.33% accuracy)
- Fast predictions (~100ms)
- No external API required
"""

__version__ = '1.0.0'
__author__ = 'Josh O\'Brien'
__license__ = 'Apache-2.0'

from .predictor import BigOPredictor, predict_complexity

__all__ = ['BigOPredictor', 'predict_complexity']
