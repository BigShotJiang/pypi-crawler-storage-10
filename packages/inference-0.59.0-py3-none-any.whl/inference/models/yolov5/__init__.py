from inference.models.yolov5.yolov5_instance_segmentation import (
    YOLOv5InstanceSegmentation,
)
from inference.models.yolov5.yolov5_object_detection import YOLOv5ObjectDetection
