# TimeLabel

Never needed to set time duration in your projects? Like when setting cache in django and want to save it for a specific time (like 10 Minutes).

Well, this package provides some simple labels like WEEK, MONTH (30 days), ...

It's not a very complicated package (actually it's super simple), but someone might find it handy. At least I have implemented it in lots of my projects, and finally I decided to turn it into a package.

Simple usage:

```python
from django.core.cache import cache

from time_label import TimeLabel

...
cache.set(key, value, 5 * TimeLabel.MINUTE)
...

```