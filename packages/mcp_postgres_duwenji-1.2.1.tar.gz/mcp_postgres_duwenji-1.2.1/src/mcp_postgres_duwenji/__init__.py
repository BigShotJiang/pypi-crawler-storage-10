"""
PostgreSQL MCP Server

A Model Context Protocol server for PostgreSQL database operations.
Provides CRUD operations and database management tools for AI assistants.
"""

__version__ = "0.1.0"
__author__ = "mcp-postgres"
