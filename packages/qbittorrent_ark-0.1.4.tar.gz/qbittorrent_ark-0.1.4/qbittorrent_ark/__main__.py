# coding: utf-8

from qbittorrent_ark.main import main


if __name__ == "__main__":
    main()
