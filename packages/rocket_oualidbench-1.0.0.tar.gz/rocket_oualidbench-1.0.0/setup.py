import setuptools

setuptools.setup(
   name='rocket-oualidbench',
   version='1.0.0',
   author='oualid',
   author_email='bencheikhlehocineoualidmouatez@gmail.com',
   packages=['rocket'],
   license='LICENSE.txt',
   description='An awesome package that does something',
   long_description=open('README.md').read(),
   long_description_content_type="text/markdown",
   install_requires=setuptools.find_packages()
)