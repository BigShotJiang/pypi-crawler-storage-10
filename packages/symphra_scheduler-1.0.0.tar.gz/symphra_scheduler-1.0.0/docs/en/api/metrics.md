# Metrics API {#en-metrics-api}

Performance metrics collection module for monitoring and analyzing task execution.

## MetricsCollector {#en-metrics-metricscollector}

::: symphra_scheduler.metrics.MetricsCollector
    options:
      show_root_heading: false
      heading_level: 3
