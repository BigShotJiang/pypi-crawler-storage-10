# Scheduler API {#en-scheduler-api}

## Scheduler {#en-scheduler-class}

::: symphra_scheduler.scheduler.Scheduler
    options:
      show_root_heading: false
      show_source: false
      heading_level: 2
      merge_init_into_class: true
      docstring_style: google
