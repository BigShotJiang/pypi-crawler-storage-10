# Config API {#en-config-api}

## SchedulerConfig {#en-config-schedulerconfig}

::: symphra_scheduler.config.SchedulerConfig
    options:
      show_root_heading: false
      show_source: false
      heading_level: 3
      merge_init_into_class: true
      docstring_style: google

## TaskMetrics {#en-config-taskmetrics}

::: symphra_scheduler.config.TaskMetrics
    options:
      show_root_heading: false
      show_source: false
      heading_level: 3
      merge_init_into_class: true
      docstring_style: google