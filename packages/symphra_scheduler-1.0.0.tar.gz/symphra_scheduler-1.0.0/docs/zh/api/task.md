# Task API {#zh-task-api}

## Task {#zh-task-task}

::: symphra_scheduler.task.Task
    options:
      show_root_heading: false
      show_source: false
      heading_level: 3
      merge_init_into_class: true
      docstring_style: google

## TaskConfig {#zh-task-taskconfig}

::: symphra_scheduler.task.TaskConfig
    options:
      show_root_heading: false
      show_source: false
      heading_level: 3
      merge_init_into_class: true
      docstring_style: google

## TaskStatus {#zh-task-taskstatus}

::: symphra_scheduler.task.TaskStatus
    options:
      show_root_heading: false
      show_source: false
      heading_level: 3
      docstring_style: google

## ScheduleType {#zh-task-scheduletype}

::: symphra_scheduler.task.ScheduleType
    options:
      show_root_heading: false
      show_source: false
      heading_level: 3
      docstring_style: google