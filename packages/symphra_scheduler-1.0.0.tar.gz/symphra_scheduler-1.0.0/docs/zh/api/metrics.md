# Metrics API {#zh-metrics-api}

性能指标收集模块,用于监控和分析任务执行情况。

## MetricsCollector {#zh-metrics-metricscollector}

::: symphra_scheduler.metrics.MetricsCollector
    options:
      show_root_heading: false
      heading_level: 3
