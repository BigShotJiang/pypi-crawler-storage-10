"""Autonomy examples demonstrating control protocol usage."""
