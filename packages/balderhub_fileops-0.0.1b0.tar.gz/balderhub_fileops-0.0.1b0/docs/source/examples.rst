Examples
********

.. todo provide some examples