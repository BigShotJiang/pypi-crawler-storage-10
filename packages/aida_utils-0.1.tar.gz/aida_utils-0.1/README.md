= AIDA utils
Functions often used at the AIDA-lab http://aida-lab.be
