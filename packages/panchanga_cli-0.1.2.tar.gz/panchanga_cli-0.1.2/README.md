# Panchanga CLI

Command-line interface for Vedic calendar (Panchanga) calculations.

## Installation

```bash
pip install panchanga-cli
```

This will automatically install the `panchanga` library.

## Usage

```bash
# Detailed pancanga for a date
panchanga verbose "2025 3 14"

# List 10 consecutive days
panchanga list "2024 1 1"

# Convert Vedic date to Gregorian
panchanga try 1946 0 1 --paksa sukla --year-system saka

# Custom location
panchanga --place mumbai verbose "2025 3 14"
panchanga --latitude 28.6 --longitude 77.2 verbose "2025 3 14"
```

## Commands

### `panchanga verbose [DATE]`

Display detailed panchanga information for a specific date.

**Example:**
```bash
$ panchanga verbose "2025 3 14"
```

### `panchanga list [DATE] [DAYS]`

List panchanga information for consecutive days.

**Example:**
```bash
$ panchanga list "2024 1 1" 10  # Show 10 days starting from 2024-01-01
```

### `panchanga try YEAR MONTH DAY`

Convert an Vedic calendar date to Gregorian.

**Options:**
- `--paksa`: Specify paksha (sukla/krsna)
- `--year-system`: Specify year system (saka/vikrama/kali)

**Example:**
```bash
$ panchanga try 1946 0 1 --paksa sukla --year-system saka
```

### `panchanga horoscope [DATE] [TIME]`

Calculate horoscope/birth chart for a specific date and time.

**Example:**
```bash
$ panchanga horoscope "1990 5 15" "14:30"
```

## Location Options

You can specify location using predefined places or custom coordinates:

**Predefined Places:**
```bash
panchanga --place mumbai verbose "2025 3 14"
panchanga --place delhi verbose "2025 3 14"
panchanga --place bangalore verbose "2025 3 14"
```

**Custom Coordinates:**
```bash
panchanga --latitude 28.6 --longitude 77.2 verbose "2025 3 14"
```

## Date Format

Dates should be provided as "YEAR MONTH DAY" (space-separated):
- `"2025 3 14"` for March 14, 2025
- `"2024 1 1"` for January 1, 2024

## Features

- Calculate tithi (lunar day)
- Calculate naksatra (lunar mansion)
- Calculate yoga and karana
- Calculate sunrise time
- Convert between different Vedic calendar eras (Kali, Saka, Vikrama)
- Find samkranti (sun transit) dates
- Generate horoscopes/birth charts
- Support for custom locations

## Library Usage

This CLI tool uses the `panchanga` library. You can use the library directly in your Python code:

```python
import panchanga

# Convert date
jd = panchanga.modern_date_to_julian_day(2025, 3, 14)
ahargana = panchanga.julian_day_to_ahargana(jd)

# Get calendar information
kali_year = panchanga.ahargana_to_kali(ahargana)
saka_year = panchanga.kali_to_saka(kali_year)

# Calculate astronomical positions
tslong = panchanga.get_true_solar_longitude(ahargana)
tllong = panchanga.get_true_lunar_longitude(ahargana)
```

See the [panchanga library documentation](https://git.sr.ht/~ayys/panchanga) for more details.

## Credits

Based on the Perl implementation by M. YANO and M. FUSHIMI (v3.14, 2014).
Python port by Ayush Jha.

