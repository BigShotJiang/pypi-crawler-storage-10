# airfoilplotter

A Python library for generating and plotting NACA airfoils (4, 5, 6, and 7 series).

## ✈️ Features
- Generate NACA 4, 5, 6, and 7 series airfoil coordinates
- Plot airfoil shape with Matplotlib
- Lightweight and easy to use

## 📦 Installation

# How to Use 

from airfoilplotter import naca4, plot_airfoil
# Example 1: NACA 4-series
xu, yu, xl, yl = naca4(0.02, 0.4, 0.12)
plot_airfoil(xu, yu, xl, yl, "NACA 2412 Airfoil")

from airfoilplotter import naca5, plot_airfoil
# Example 2: NACA 5-series
xu, yu, xl, yl = naca5(0.3, 0.4, 0.12)
plot_airfoil(xu, yu, xl, yl, "NACA 5-Series Airfoil")

from airfoilplotter import naca6, plot_airfoil
# Example 3: NACA 6-series
xu, yu, xl, yl = naca6(0.3, 0.12)
plot_airfoil(xu, yu, xl, yl, "NACA 6-Series Airfoil")

from airfoilplotter import naca7, plot_airfoil
# Example 4: NACA 7-series
xu, yu, xl, yl = naca7(0.3, 0.12)
plot_airfoil(xu, yu, xl, yl, "NACA 7-Series Airfoil")