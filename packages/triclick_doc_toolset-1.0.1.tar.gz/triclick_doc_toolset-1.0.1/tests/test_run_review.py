import json
from src.service import run_review

# UV_INDEX_URL=https://pypi.org/simple/ uv sync --extra dev
# UV_INDEX_URL=https://pypi.org/simple/ uv run pytest -q -rs tests/test_run_review.py

def test_review_dir():
    result = run_review(
        document_path="/Users/zk/code@hill/triclick-doc-toolset/tests/data.input/test",
        output_dir="/Users/zk/code@hill/triclick-doc-toolset/tests/data.output",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
