# 确保命令模块被导入，从而完成注册到 CommandRegistry
from .docx_file_parse_cmd import DocxFileParseCommand  # noqa: F401
from .docx_file_partition_cmd import DocxFilePartitionCommand  # noqa: F401
from .file_type_identification_cmd import FileTypeIdentificationCommand  # noqa: F401
from .rtf_file_parse_cmd import RTFFileParseCommand  # noqa: F401