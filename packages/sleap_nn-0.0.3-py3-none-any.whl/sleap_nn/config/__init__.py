"""Configuration modules for sleap-nn."""
