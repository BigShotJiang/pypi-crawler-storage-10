"""Modules related to model architectures."""
