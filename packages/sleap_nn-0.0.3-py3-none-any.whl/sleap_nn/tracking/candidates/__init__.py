"""Candidate generation modules for tracking."""
