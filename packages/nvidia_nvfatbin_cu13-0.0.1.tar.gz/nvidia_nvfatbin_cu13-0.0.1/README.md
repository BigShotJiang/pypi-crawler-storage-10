⚠️ THIS PROJECT 'nvidia-nvfatbin-cu13' IS DEPRECATED.
Please use 'nvidia-nvfatbin' instead.

To install the correct package, use:

    pip install nvidia-nvfatbin

For more information, visit: https://pypi.org/project/nvidia-nvfatbin/
