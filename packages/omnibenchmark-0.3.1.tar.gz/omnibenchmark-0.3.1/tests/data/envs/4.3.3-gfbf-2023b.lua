-- 4.3.3-gfbf-2023b.lua

help([[
    This is a dummy module for demonstration purposes.
]])

whatis("Name: 4.3.3-gfbf-2023b")
whatis("Version: 1.0")
whatis("Category: Testing")
whatis("Description: A dummy module for testing purposes.")
