"""Tap for PlanetScaleAPI."""
