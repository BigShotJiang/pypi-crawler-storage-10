# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "phoebe_bird"
__version__ = "0.1.0-alpha.9"  # x-release-please-version
