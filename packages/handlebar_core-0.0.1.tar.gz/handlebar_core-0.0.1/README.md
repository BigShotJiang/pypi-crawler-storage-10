# handlebar-core

**Handlebar, the governance layer for agents**. coming soon.

https://gethandlebar.com
