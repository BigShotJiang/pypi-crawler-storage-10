import secrets
import string
# import sys
from cachetools import FIFOCache
from datetime import datetime
from flask import Flask, Response, redirect, request, jsonify
from logging import Logger
from pypomes_core import (
    APP_PREFIX, TZ_LOCAL, env_get_int, env_get_str
)
from typing import Any, Final

from .common_pomes import (
    _get_login_timeout, _get_public_key, _get_user_data, _user_logout, _log_init
)

KEYCLOAK_CLIENT_ID: Final[str] = env_get_str(key=f"{APP_PREFIX}_KEYCLOAK_CLIENT_ID")
KEYCLOAK_CLIENT_SECRET: Final[str] = env_get_str(key=f"{APP_PREFIX}_KEYCLOAK_CLIENT_SECRET")
KEYCLOAK_CLIENT_TIMEOUT: Final[int] = env_get_int(key=f"{APP_PREFIX}_KEYCLOAK_CLIENT_TIMEOUT")

KEYCLOAK_ENDPOINT_CALLBACK: Final[str] = env_get_str(key=f"{APP_PREFIX}_KEYCLOAK_ENDPOINT_CALLBACK",
                                                     def_value="/iam/keycloak:callback")
KEYCLOAK_ENDPOINT_LOGIN: Final[str] = env_get_str(key=f"{APP_PREFIX}_KEYCLOAK_ENDPOINT_LOGIN",
                                                  def_value="/iam/keycloak:login")
KEYCLOAK_ENDPOINT_LOGOUT: Final[str] = env_get_str(key=f"{APP_PREFIX}_KEYCLOAK_ENDPOINT_LOGOUT",
                                                   def_value="/iam/keycloak:logout")
KEYCLOAK_ENDPOINT_TOKEN: Final[str] = env_get_str(key=f"{APP_PREFIX}_KEYCLOAK_ENDPOINT_TOKEN",
                                                  def_value="/iam/keycloak:get-token")

KEYCLOAK_PUBLIC_KEY_LIFETIME: Final[int] = env_get_int(key=f"{APP_PREFIX}_KEYCLOAK_PUBLIC_KEY_LIFETIME",
                                                       def_value=86400)  # 24 hours
KEYCLOAK_REALM: Final[str] = env_get_str(key=f"{APP_PREFIX}_KEYCLOAK_REALM")
KEYCLOAK_URL_AUTH_BASE: Final[str] = env_get_str(key=f"{APP_PREFIX}_KEYCLOAK_URL_AUTH_BASE")
KEYCLOAK_URL_AUTH_CALLBACK: Final[str] = env_get_str(key=f"{APP_PREFIX}_KEYCLOAK_URL_AUTH_CALLBACK")

# registry structure:
# {
#    "client-id": <str>,
#    "client-secret": <str>,
#    "client-timeout": <int>,
#    "public_key": <str>,
#    "key-lifetime": <int>,
#    "key-expiration": <int>,
#    "base-url": <str>,
#    "callback-url": <str>,
#    "users": {
#       "<user-id>": {
#         "cache-obj": <FIFOCache>,
#         "access-expiration": <timestamp>,
#         "login-expiration": <int>,  <-- transient
#         "login-id": <str>,          <-- transient
#         data in <FIFOCache>:
#           "access-token": <str>
#           "refresh-token": <str>
#       }
#    }
# }
_keycloak_registry: dict[str, Any] = {}

# dafault logger
_logger: Logger | None = None


def keycloak_setup(flask_app: Flask,
                   client_id: str = KEYCLOAK_CLIENT_ID,
                   client_secret: str = KEYCLOAK_CLIENT_SECRET,
                   client_timeout: int = KEYCLOAK_CLIENT_TIMEOUT,
                   public_key_lifetime: int = KEYCLOAK_PUBLIC_KEY_LIFETIME,
                   realm: str = KEYCLOAK_REALM,
                   callback_endpoint: str = KEYCLOAK_ENDPOINT_CALLBACK,
                   token_endpoint: str = KEYCLOAK_ENDPOINT_TOKEN,
                   login_endpoint: str = KEYCLOAK_ENDPOINT_LOGIN,
                   logout_endpoint: str = KEYCLOAK_ENDPOINT_LOGOUT,
                   base_url: str = KEYCLOAK_URL_AUTH_BASE,
                   callback_url: str = KEYCLOAK_URL_AUTH_CALLBACK,
                   logger: Logger = None) -> None:
    """
    Configure the Keycloak IAM.

    This should be invoked only once, before the first access to a Keycloak service.

    :param flask_app: the Flask application
    :param client_id: the client's identification with JusBR
    :param client_secret: the client's password with JusBR
    :param client_timeout: timeout for login authentication (in seconds,defaults to no timeout)
    :param public_key_lifetime: how long to use Keycloak's public key, before refreshing it (in seconds)
    :param realm: the Keycloak realm
    :param callback_endpoint: endpoint for the callback from JusBR
    :param token_endpoint: endpoint for retrieving the JusBR authentication token
    :param login_endpoint: endpoint for redirecting user to JusBR login page
    :param logout_endpoint: endpoint for terminating user access to JusBR
    :param base_url: base URL to request the JusBR services
    :param callback_url: URL for Keycloak to callback on login
    :param logger: optional logger
    """
    global _keycloak_registry

    # establish the logger
    global _logger
    _logger = logger

    # configure the JusBR registry
    _keycloak_registry = {
        "client-id": client_id,
        "client-secret": client_secret,
        "client-timeout": client_timeout,
        "base-url": f"{base_url}/realms/{realm}",
        "callback-url": callback_url,
        "key-expiration": int(datetime.now(tz=TZ_LOCAL).timestamp()),
        "key-lifetime": public_key_lifetime,
        "users": []
    }

    # establish the endpoints
    if token_endpoint:
        flask_app.add_url_rule(rule=token_endpoint,
                               endpoint="keycloak-token",
                               view_func=service_token,
                               methods=["GET"])
    if login_endpoint:
        flask_app.add_url_rule(rule=login_endpoint,
                               endpoint="keycloak-login",
                               view_func=service_login,
                               methods=["GET"])
    if logout_endpoint:
        flask_app.add_url_rule(rule=logout_endpoint,
                               endpoint="keycloak-logout",
                               view_func=service_logout,
                               methods=["GET"])
    if callback_endpoint:
        flask_app.add_url_rule(rule=callback_endpoint,
                               endpoint="keycloak-callback",
                               view_func=service_callback,
                               methods=["POST"])


# @flask_app.route(rule=<login_endpoint>,  # KEYCLOAK_LOGIN_ENDPOINT: /iam/keycloak:login
#                  methods=["GET"])
def service_login() -> Response:
    """
    Entry point for the Keycloak login service.

    Redirect the request to the Keycloak authentication page, with the appropriate parameters.

    :return: the response from the redirect operation
    """
    global _keycloak_registry

    # log the request
    if _logger:
        msg: str = _log_init(request=request)
        _logger.debug(msg=msg)

    # build the OAuth2 state, and temporarily use it as 'user_id'
    oauth_state: str = "".join(secrets.choice(string.ascii_letters + string.digits) for _ in range(16))
    # obtain the user data
    user_data: dict[str, Any] = _get_user_data(registry=_keycloak_registry,
                                               user_id=oauth_state,
                                               logger=_logger)
    # build the redirect url
    timeout: int = _get_login_timeout(registry=_keycloak_registry)
    safe_cache: FIFOCache
    if timeout:
        safe_cache = FIFOCache(maxsize=16)
    else:
        safe_cache = FIFOCache(maxsize=16)
    safe_cache["valid"] = True
    user_data["cache-obj"] = safe_cache
    auth_url: str = (
        f"{_keycloak_registry["base-url"]}/protocol/openid-connect/auth"
        f"?client_id={_keycloak_registry["client-id"]}"
        f"&response_type=code"
        f"&scope=openid"
        f"&redirect_uri={_keycloak_registry["callback-url"]}"
    )

    # redirect the request
    result: Response = redirect(location=auth_url)

    # log the response
    if _logger:
        _logger.debug(msg=f"Response {result}")

    return result


# @flask_app.route(rule=<login_endpoint>,  # KEYCLOAK_LOGIN_ENDPOINT: /iam/keycloak:logout
#                  methods=["GET"])
def service_logout() -> Response:
    """
    Entry point for the Keycloak logout service.

    Remove all data associating the user with Keycloak from the registry.

    :return: response *OK*
    """
    global _keycloak_registry

    # log the request
    if _logger:
        msg: str = _log_init(request=request)
        _logger.debug(msg=msg)

    # retrieve the user id
    input_params: dict[str, Any] = request.args
    user_id: str = input_params.get("user-id") or input_params.get("login")

    # logout the user
    _user_logout(registry=_keycloak_registry,
                 user_id=user_id,
                 logger=_logger)

    result: Response = Response(status=200)

    # log the response
    if _logger:
        _logger.debug(msg=f"Response {result}")

    return result


# @flask_app.route(rule=<callback_endpoint>,  # KEYCLOAK_CALLBACK_ENDPOINT: /iam/keycloak:callback
#                  methods=["POST"])
def service_callback() -> Response:
    """
    Entry point for the callback from Keycloak on authentication operation.

    :return: the response containing the token, or *NOT AUTHORIZED*
    """
    global _keycloak_registry
    from .token_pomes import token_validate

    # log the request
    if _logger:
        msg: str = _log_init(request=request)
        _logger.debug(msg=msg)

    # validate the OAuth2 state
    oauth_state: str = request.args.get("state")
    user_id: str | None = None
    user_data: dict[str, Any] | None = None
    if oauth_state:
        for user, data in _keycloak_registry.get("users").items():
            safe_cache: FIFOCache = data.get("cache-obj")
            if user == oauth_state:
                if data.get("valid"):
                    user_id = user
                    user_data = data
                else:
                    msg = "Operation timeout"
                break

    # exchange 'code' for the token
    token: str | None = None
    errors: list[str] = []
    if user_data:
        code: str = request.args.get("code")
        body_data: dict[str, Any] = {
            "grant_type": "authorization_code",
            "code": code,
            "redirec_url": _keycloak_registry.get("callback-url"),
        }
        # token = __post_jusbr(user_data=user_data,
        #                      body_data=body_data,
        #                      errors=errors,
        #                      logger=_logger)
        # retrieve the token's claims
        if not errors:
            public_key: bytes = _get_public_key(registry=_keycloak_registry,
                                                url=_keycloak_registry["base-url"],
                                                logger=_logger)
            token_claims: dict[str, dict[str, Any]] = token_validate(token=token,
                                                                     issuer=_keycloak_registry["base-url"],
                                                                     public_key=public_key,
                                                                     errors=errors,
                                                                     logger=_logger)
            if not errors:
                token_user: str = token_claims["payload"].get("preferred_username")
                if user_id == oauth_state:
                    user_id = token_user
                    _keycloak_registry["users"][user_id] = _keycloak_registry["users"].pop(oauth_state)
                elif token_user != user_id:
                    errors.append(f"Token was issued to user '{token_user}'")
    else:
        msg: str = "Unknown OAuth2 code received"
        if _get_login_timeout(registry=_keycloak_registry):
            msg += " - possible operation timeout"
        errors.append(msg)

    result: Response
    if errors:
        result = jsonify({"errors": "; ".join(errors)})
        result.status_code = 400
    else:
        result = jsonify({
            "user_id": user_id,
            "access_token": token})

    # log the response
    if _logger:
        _logger.debug(msg=f"Response {result}")

    return result


# @flask_app.route(rule=<token_endpoint>,  # JUSBR_TOKEN_ENDPOINT: /iam/jusbr:get-token
#                  methods=["GET"])
def service_token() -> Response:
    """
    Entry point for retrieving the Keycloak token.

    :return: the response containing the token, or *UNAUTHORIZED*
    """
    # log the request
    if _logger:
        msg: str = _log_init(request=request)
        _logger.debug(msg=msg)

    # retrieve the user id
    input_params: dict[str, Any] = request.args
    _user_id: str = input_params.get("user-id") or input_params.get("login")
    return Response()


def keycloak_get_token(user_id: str,
                       errors: list[str] = None,
                       logger: Logger = None) -> str:
    """
    Retrieve the authentication token for user *user_id*.

    :param user_id: the user's identification
    :param errors: incidental error messages
    :param logger: optional logger
    :return: the token for *user_id*, or *None* if error
    """
    global _keycloak_registry

    # initialize the return variable
    result: str | None = None
    return result
