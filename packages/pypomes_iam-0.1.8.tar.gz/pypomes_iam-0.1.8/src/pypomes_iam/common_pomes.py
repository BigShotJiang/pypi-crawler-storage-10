import json
import requests
from datetime import datetime
from flask import Request
from logging import Logger
from pypomes_core import TZ_LOCAL
from typing import Any


def _get_public_key(registry: dict[str, Any],
                    url: str,
                    logger: Logger | None) -> bytes:
    """
    Obtain the public key used by the *IAM* to sign the authentication tokens.

    The public key is saved in *registry*.

    :param url: the base URL to request the public key
    :return: the public key, in *DER* format
    """
    from pypomes_crypto import crypto_jwk_convert

    # initialize the return variable
    result: bytes | None = None

    now: int = int(datetime.now(tz=TZ_LOCAL).timestamp())
    if now > registry.get("key-expiration"):
        # obtain a new public key
        url: str = f"{url}/protocol/openid-connect/certs"
        if logger:
            logger.debug(msg=f"GET '{url}'")
        response: requests.Response = requests.get(url=url)
        if response.status_code == 200:
            # request succeeded
            if logger:
                logger.debug(msg=f"GET success, status {response.status_code}")
            reply: dict[str, Any] = response.json()
            result = crypto_jwk_convert(jwk=reply["keys"][0],
                                        fmt="DER")
            registry["public-key"] = result
            duration: int = registry.get("key-lifetime") or 0
            registry["key-expiration"] = now + duration
        elif logger:
            msg: str = f"GET failure, status {response.status_code}, reason '{response.reason}'"
            if hasattr(response, "content") and response.content:
                msg += f", content '{response.content}'"
            logger.error(msg=msg)
    else:
        result = registry.get("public-key")

    return result


def _get_login_timeout(registry: dict[str, Any]) -> int | None:
    """
    Retrieve from *registry* the timeout currently applicable for the login operation.

    :return: the current login timeout, or *None* if none has been set.
    """
    timeout: int = registry.get("client-timeout")
    return timeout if isinstance(timeout, int) and timeout > 0 else None


def _get_user_data(registry: dict[str, Any],
                   user_id: str,
                   logger: Logger | None) -> dict[str, Any]:
    """
    Retrieve the data for *user_id* from *registry*.

    If an entry is not found for *user_id* in the registry, it is created.
    It will remain there until the user is logged out.

    :param user_id:
    :return: the data for *user_id* in the registry
    """
    result: dict[str, Any] = registry["users"].get(user_id)
    if not result:
        result = {"access-expiration": int(datetime.now(tz=TZ_LOCAL).timestamp())}
        registry["users"][user_id] = result
        if logger:
            logger.debug(msg=f"Entry for user '{user_id}' added to the registry")
    elif logger:
        logger.debug(msg=f"Entry for user '{user_id}' obtained from the registry")

    return result


def _user_logout(registry: dict[str, Any],
                 user_id: str,
                 logger: Logger | None) -> None:
    """
    Remove all data associating *user_id* from *registry*.
    """
    # remove the user data
    if user_id and user_id in registry.get("users"):
        registry["users"].pop(user_id)
        if logger:
            logger.debug(msg=f"User '{user_id}' removed from the registry")


def _log_init(request: Request) -> str:
    """
    Build the messages for logging the request entry.

    :param request: the Request object
    :return: the log message
    """

    params: str = json.dumps(obj=request.args,
                             ensure_ascii=False)
    return f"Request {request.method}:{request.path}, params {params}"
