# tiferet-monday
A Tiferet extension for building monday.com apps with Python.
