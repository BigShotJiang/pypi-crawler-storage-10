import pandas as pd
import chardet
from .contextpipeline import * 
from tqdm import tqdm
from .filehelper import * 



def detect_encoding(filepath, nbytes=10000):
    with open(filepath, "rb") as f:
        rawdata = f.read(nbytes)
    return chardet.detect(rawdata)['encoding']

def LoadCSV(filepath: str, sep =",") -> pd.DataFrame:
    """Carga un archivo CSV en un DataFrame de pandas."""
    enc = detect_encoding(filepath)   
    print(f"Detected encoding: {enc}")
    return pd.read_csv(filepath, encoding=enc, sep=sep, low_memory=False) 

def RejectRepeatedRows(df: pd.DataFrame) -> pd.DataFrame:
    """Elimina filas duplicadas de un DataFrame."""
    return df.drop_duplicates()

def RejectAllExceptValues(df: pd.DataFrame, column: str, values: list) -> pd.DataFrame:
    """Mantiene solo las filas donde la columna especificada tiene ciertos valores."""
    return df[df[column].isin(values)]

def MergeCSVs(df1: pd.DataFrame, df2: pd.DataFrame, on: str, how: str ="left") -> pd.DataFrame:
    """Fusiona dos DataFrames en función de una columna común."""
    """how: inner (solo los que estan en los dos), outer (todos poniendo NaN donde no se Sabe), left (todas las de df1), right(todas las de df2)"""
    return pd.merge(df1, df2, on=on, how=how)


def ConcatCSVs(dfs: list[pd.DataFrame], axis: int = 0, ignore_index: bool = True) -> pd.DataFrame:
    """
    Concatena varios DataFrames en uno solo.

    Args:
        dfs: lista de DataFrames a concatenar
        axis: 0 para filas (default), 1 para columnas
        ignore_index: True para resetear el índice
6
    Returns:
        DataFrame concatenado
    """
    return pd.concat(dfs, axis=axis, ignore_index=ignore_index)

def RejectRowsbyNulls(df: pd.DataFrame, column: str) -> pd.DataFrame:
    """Elimina filas donde la columna especificada tiene valores nulos."""
    return df[df[column].notna()]

def RejectRowsbyValues(df: pd.DataFrame, column: str, values: list) -> pd.DataFrame:
    """Elimina filas donde la columna especificada tiene ciertos valores."""
    return df[~df[column].isin(values)]

def RejectRowsbyCondition(df: pd.DataFrame, condition) -> pd.DataFrame:
    """Elimina filas que cumplen una condición dada."""
    return df[~condition(df)]


def RejectRowsbyRegex(df: pd.DataFrame, column: str, pattern: str) -> pd.DataFrame:
    """Elimina filas donde la columna especificada coincide con un patrón regex."""
    return df[~df[column].str.contains(pattern, regex=True, na=False)]

def TrimSpaces(df: pd.DataFrame, column: str) -> pd.DataFrame:
    """Elimina espacios en blanco al inicio y al final de los valores en una columna."""
    df[column] = df[column].str.strip()
    return df

def TrimAllSpaces(df: pd.DataFrame) -> pd.DataFrame:
    """Elimina espacios en blanco al inicio y al final de los valores en todas las columnas de tipo string."""
    for col in df.select_dtypes(include=['object']).columns:
        df[col] = df[col].str.strip()
    return df

def PrintVariablePosibilities(df: pd.DataFrame, column: str):
    """Imprime las posibles valores únicos de una columna y su frecuencia."""
    print(df[column].value_counts(dropna=False))

def CastColumnToType(df: pd.DataFrame, column: str, dtype) -> pd.DataFrame:
    """Convierte una columna a un tipo de dato especificado."""
    if dtype == "datetime" or dtype == pd.Timestamp:
        df[column] = pd.to_datetime(df[column], errors="coerce")
    else:
        df[column] = df[column].astype(dtype,errors="ignore")
    return df

def CastColumntoDateTime(df: pd.DataFrame, column: str) -> pd.DataFrame:
    """Convierte una columna a tipo datetime."""
    df[column] = pd.to_datetime(df[column], errors="coerce")
    return df

def CastColumntoInt(df: pd.DataFrame, column: str, allow_na: bool = True) -> pd.DataFrame:
    """Convierte una columna a tipo entero (maneja NaN si allow_na=True)."""
    df[column] = pd.to_numeric(df[column], errors="coerce")
    if allow_na:
        df[column] = df[column].astype("Int64")
    else:
        df[column] = df[column].fillna(0).astype(int)
    return df

def CastColumntoNumeric(df: pd.DataFrame, column: str) -> pd.DataFrame:
    """Convierte una columna a tipo numérico."""
    df[column] = pd.to_numeric(df[column], errors="coerce")
    return df

def FilterDataFramebyCondition(df: pd.DataFrame, condition) -> pd.DataFrame:
    """Filtra un DataFrame según una condición dada."""
    return df[condition(df)]


def IterateRows(df: pd.DataFrame, desc: str ="Iterando filas" ):
    """Generador que itera sobre las filas de un DataFrame."""
    for index, row in df.iterrows():
        yield index, row



def add_events_from_dataframe(log, df:pd.DataFrame, 
                                      trace_id_col,
                                      trace_attr_map=None,
                                      activity_name_col=None,
                                      start_col=None,
                                      end_col=None,
                                      event_attr_map=None,
                                      event_name_fixed=None,
                                      tolerance=None,
                                      show_progress=True)-> pd.DataFrame:
    """
    Añade trazas y eventos desde un DataFrame de manera generalizable.

    Parámetros:
    -----------
    log : LogDict
        Instancia de tu log.
    df : pd.DataFrame
        DataFrame de origen.
    trace_id_col : str
        Columna que contiene el ID de la traza.
    trace_attr_map : dict, opcional
        Map de columnas del df a nombres de atributos de la traza.
        Ej: {"Medico/Equipo": "medico", "triaje_nivel": "triaje", "ano": "year"}
    activity_name_col : str, opcional
        Columna del df que contiene ActivityName del evento. Si None, se usa event_name_fixed.
    event_name_fixed : str, opcional
        Nombre fijo del evento si no se usa activity_name_col.
    start_col : str
        Columna de fecha de inicio del evento.
    end_col : str, opcional
        Columna de fecha de fin del evento.
    event_attr_cols : list[str], opcional
        Columnas que se guardan como atributos del evento.
    tolerance : str, opcional
        Tolerancia para add_event.
    show_progress : bool
        Si True, muestra barra de progreso.
    """
    iterator = tqdm(df.iterrows(), total=len(df), desc="Añadiendo eventos") if show_progress else df.iterrows()

    for _, row in iterator:
        trace_id = row[trace_id_col]

        # Mapear atributos de la traza
        trace_attrs = {}
        if trace_attr_map:
            for col, attr_name in trace_attr_map.items():
                if col in df.columns and pd.notna(row[col]):
                    trace_attrs[attr_name] = row[col]
        log.add_trace(trace_id, **trace_attrs)

        # Determinar nombre del evento
        activity_name = event_name_fixed or (row[activity_name_col] if activity_name_col else None)
        if not activity_name:
            raise ValueError("No se pudo determinar el nombre del evento")

        # Mapear atributos del evento
        ev_attrs = {}
        if event_attr_map:
            for col, attr_name in event_attr_map.items():
                if col in df.columns and pd.notna(row[col]):
                    ev_attrs[attr_name] = row[col]

        log.add_event(trace_id, activity_name,
                                     start=row[start_col],
                                     end=row[end_col] if end_col else None,
                                     _tolerance=tolerance,
                                     **ev_attrs)
    return df

def add_csv_to_zip(zip_path, internal_path, df):
    """
    Añade o reemplaza un CSV dentro de un ZIP existente (normal),
    sin borrar ni empaquetar el contenido anterior.
    """
    # Serializar el DataFrame a memoria
    csv_buffer = io.StringIO()
    df.to_csv(csv_buffer, index=False,sep=";")
    data = csv_buffer.getvalue().encode("utf-8")
    zip_writeallbytes(zip_path, internal_path, data)

