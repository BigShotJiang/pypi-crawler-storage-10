aind\_behavior\_curriculum.curriculum.StageTransition
=====================================================

.. currentmodule:: aind_behavior_curriculum.curriculum

.. autoclass:: StageTransition
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~StageTransition.__init__
      ~StageTransition.invoke
      ~StageTransition.normalize_rule_or_callable
      ~StageTransition.serialize_rule
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~StageTransition.callable
      ~StageTransition.name
   
   