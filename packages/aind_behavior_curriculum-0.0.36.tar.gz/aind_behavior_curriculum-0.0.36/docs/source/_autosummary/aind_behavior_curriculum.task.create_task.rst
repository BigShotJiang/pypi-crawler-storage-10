aind\_behavior\_curriculum.task.create\_task
============================================

.. currentmodule:: aind_behavior_curriculum.task

.. autofunction:: create_task