aind\_behavior\_curriculum.curriculum.PolicyTransition
======================================================

.. currentmodule:: aind_behavior_curriculum.curriculum

.. autoclass:: PolicyTransition
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~PolicyTransition.__init__
      ~PolicyTransition.invoke
      ~PolicyTransition.normalize_rule_or_callable
      ~PolicyTransition.serialize_rule
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~PolicyTransition.callable
      ~PolicyTransition.name
   
   