aind\_behavior\_curriculum.curriculum\_utils.Graduated
======================================================

.. currentmodule:: aind_behavior_curriculum.curriculum_utils

.. autoclass:: Graduated
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Graduated.__init__
      ~Graduated.construct
      ~Graduated.copy
      ~Graduated.dict
      ~Graduated.from_orm
      ~Graduated.json
      ~Graduated.model_construct
      ~Graduated.model_copy
      ~Graduated.model_dump
      ~Graduated.model_dump_json
      ~Graduated.model_json_schema
      ~Graduated.model_parametrized_name
      ~Graduated.model_post_init
      ~Graduated.model_rebuild
      ~Graduated.model_validate
      ~Graduated.model_validate_json
      ~Graduated.model_validate_strings
      ~Graduated.parse_file
      ~Graduated.parse_obj
      ~Graduated.parse_raw
      ~Graduated.schema
      ~Graduated.schema_json
      ~Graduated.update_forward_refs
      ~Graduated.validate
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Graduated.model_computed_fields
      ~Graduated.model_config
      ~Graduated.model_extra
      ~Graduated.model_fields
      ~Graduated.model_fields_set
      ~Graduated.name
      ~Graduated.task_parameters
      ~Graduated.description
      ~Graduated.version
      ~Graduated.stage_name
   
   