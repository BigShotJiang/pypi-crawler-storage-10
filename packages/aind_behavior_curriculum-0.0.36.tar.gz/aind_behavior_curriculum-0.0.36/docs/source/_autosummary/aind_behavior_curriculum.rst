﻿aind\_behavior\_curriculum
==========================

.. automodule:: aind_behavior_curriculum
  
   
   
   

   
   
   

   
   
   

   
   
   



.. rubric:: Modules

.. autosummary::
   :toctree:
   :template: custom-module-template.rst                 
   :recursive:

   base
   curriculum
   curriculum_utils
   task
   trainer

