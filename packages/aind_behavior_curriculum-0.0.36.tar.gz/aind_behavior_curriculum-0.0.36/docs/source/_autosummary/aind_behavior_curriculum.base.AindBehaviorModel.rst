aind\_behavior\_curriculum.base.AindBehaviorModel
=================================================

.. currentmodule:: aind_behavior_curriculum.base

.. autoclass:: AindBehaviorModel
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~AindBehaviorModel.__init__
      ~AindBehaviorModel.construct
      ~AindBehaviorModel.copy
      ~AindBehaviorModel.dict
      ~AindBehaviorModel.from_orm
      ~AindBehaviorModel.json
      ~AindBehaviorModel.model_construct
      ~AindBehaviorModel.model_copy
      ~AindBehaviorModel.model_dump
      ~AindBehaviorModel.model_dump_json
      ~AindBehaviorModel.model_json_schema
      ~AindBehaviorModel.model_parametrized_name
      ~AindBehaviorModel.model_post_init
      ~AindBehaviorModel.model_rebuild
      ~AindBehaviorModel.model_validate
      ~AindBehaviorModel.model_validate_json
      ~AindBehaviorModel.model_validate_strings
      ~AindBehaviorModel.parse_file
      ~AindBehaviorModel.parse_obj
      ~AindBehaviorModel.parse_raw
      ~AindBehaviorModel.schema
      ~AindBehaviorModel.schema_json
      ~AindBehaviorModel.update_forward_refs
      ~AindBehaviorModel.validate
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~AindBehaviorModel.model_computed_fields
      ~AindBehaviorModel.model_config
      ~AindBehaviorModel.model_extra
      ~AindBehaviorModel.model_fields
      ~AindBehaviorModel.model_fields_set
   
   