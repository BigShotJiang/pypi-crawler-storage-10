aind\_behavior\_curriculum.curriculum.make\_task\_discriminator
===============================================================

.. currentmodule:: aind_behavior_curriculum.curriculum

.. autofunction:: make_task_discriminator