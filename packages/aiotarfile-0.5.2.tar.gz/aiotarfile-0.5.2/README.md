aiotarfile
==========

[![PyPI version](https://badge.fury.io/py/aiotarfile.svg)](https://badge.fury.io/py/aiotarfile)

Stream-based tarball processing, but like, async.
A thin set of wrappers over the rust crate [async-tar](https://github.com/dignifiedquire/async-tar).

Install with `pip isntall aiotarfile`.

Consult docstrings, type annotations, and tab-completion for usage.
