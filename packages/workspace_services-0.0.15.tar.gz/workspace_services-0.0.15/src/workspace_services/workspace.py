import json
import logging
from enum import Enum
from pathlib import Path
from typing import Any

import json5
from pydantic import BaseModel, Field
from util_common.decorator import deprecated
from util_common.path import sort_paths

from batch_store import BatchStore
from workspace_services.batch import Batch, batch_service
from workspace_services.settings import workspace_settings
from workspace_services.tag_models.classification_tag import ClassificationTag
from workspace_services.task import ScopeLevel, TaskType, task_service


class WorkspaceStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    ARCHIVED = "archived"


def update_abandon_status(page_filter: str | None, page_dir: Path, tag_data: dict) -> dict:
    if not page_filter:
        return tag_data
    page_filter_tag_path = page_dir / f'tag-{page_filter}.json'
    if page_filter_tag_path.is_file():
        try:
            page_filter_tag = ClassificationTag(
                **json.loads(page_filter_tag_path.read_text(encoding="utf-8"))
            )
            tag_data['abandon'] = page_filter_tag.classification == 0
        except Exception as e:
            logging.warning(f"Invalid page filter tag data: {e}")
    return tag_data


class Workspace(BaseModel):
    id: str
    description: str = Field(default="")
    task_description: str = Field(default="")
    task_id: str = Field(default="page_classification")
    task_type: TaskType
    scope_level: ScopeLevel
    page_filter: str = Field(default="")
    tag_config: dict[str, Any] = Field(default_factory=dict)
    batches: list[str] = Field(default_factory=list)
    status: WorkspaceStatus = Field(default=WorkspaceStatus.ACTIVE)


class WorkspaceService:
    def __init__(self):
        self.workspace_root = workspace_settings.workspace_root
        self.task_root = workspace_settings.task_root
        self.batch_root = workspace_settings.batch_root
        self._workspaces: dict[str, Workspace] = dict()

    @property
    def workspaces(self) -> dict[str, Workspace]:
        if not self._workspaces:
            self._load_workspaces()
        return self._workspaces

    def _read_workspace_settings(self, workspace_id: str) -> dict[str, Any]:
        # TODO: 优化读取 workspace 配置
        workspace_settings_path = self.workspace_root / f"{workspace_id}.jsonc"
        if not workspace_settings_path.exists():
            raise ValueError(f"Workspace config {workspace_settings_path} not found")
        try:
            workspace_settings = json5.loads(workspace_settings_path.read_text(encoding="utf-8"))
        except Exception as e:
            raise ValueError(f"Failed to load workspace settings {workspace_settings_path}: {e}")
        if not isinstance(workspace_settings, dict):
            raise ValueError(f"Invalid workspace settings: {workspace_settings_path}")
        return workspace_settings

    def _get_workspace(self, workspace_id: str) -> Workspace:
        workspace_settings = self._read_workspace_settings(workspace_id)

        # 处理 task_id 字段：如果 task_id 不存在，则使用默认值 'page_classification'
        task_id = workspace_settings.get('task_id') or 'page_classification'
        task = task_service.get_task(task_id)

        return Workspace(
            id=workspace_id,
            description=workspace_settings.get('description', ''),
            task_description=task.description,
            task_id=task_id,
            task_type=task.task_type,
            scope_level=task.scope_level,
            page_filter=workspace_settings.get('page_filter', ''),
            tag_config=task.tag_config,
            batches=workspace_settings.get('batches', []),
            status=WorkspaceStatus.ACTIVE,
        )

    def _load_workspaces(self) -> dict[str, Workspace]:
        """
        加载所有 workspace 配置, 并缓存到 self.workspaces 中。
        用户刷新 /ui/workspaces 页面时, 重新加载所有 workspace 配置。
        """
        workspaces: dict[str, Workspace] = dict()
        for settings_path in sort_paths(self.workspace_root.glob('*.jsonc')):
            workspace_id = settings_path.stem
            try:
                workspaces[workspace_id] = self._get_workspace(workspace_id)
            except Exception as e:
                logging.warning(f"Failed to load workspace {workspace_id}: {e}")
        self._workspaces = workspaces
        return workspaces

    def get_workspace(self, workspace_id: str) -> Workspace:
        workspace = self.workspaces.get(workspace_id)
        if not workspace:
            raise ValueError(f"Workspace {workspace_id} not found")
        return workspace

    def get_workspace_batches(self, workspace_id: str) -> list[Batch]:
        if workspace_id not in self.workspaces:
            raise ValueError(f"Workspace {workspace_id} not found")
        workspace = self.get_workspace(workspace_id)
        batches: list[Batch] = []
        for batch_id in sort_paths(workspace.batches):
            batches.append(batch_service.get_batch(str(batch_id)))
        return batches

    def get_workspace_reviewed_batches(self, workspace_id: str) -> list[str]:
        if workspace_id not in self.workspaces:
            raise ValueError(f"Workspace {workspace_id} not found")
        workspace = self.get_workspace(workspace_id)
        reviewed_batches: list[str] = []
        for batch_id in workspace.batches:
            tagging_status_path = BatchStore(batch_id).batch_dir / 'tagging_status.json'
            if not tagging_status_path.exists():
                print(f"Warning: Tagging status file not found for {batch_id}")
                continue
            tagging_status = json.loads(tagging_status_path.read_text())
            tagging_status = [
                x
                for x in tagging_status['tagging_status']
                if x['workspace_id'] == workspace.id and x['task_id'] == workspace.task_id
            ]
            if len(tagging_status) == 1 and tagging_status[0]['human_reviewed'] is True:
                reviewed_batches.append(batch_id)
        return reviewed_batches

    @staticmethod
    def get_page_tag_file_name(workspace: Workspace) -> str:
        if workspace and workspace.tag_config and workspace.tag_config.get("tag_name"):
            tag_name = workspace.tag_config["tag_name"]
        else:
            raise ValueError(f"Tag name not found for workspace {workspace.id}")
        return f"tag-{tag_name}.json"

    @staticmethod
    def get_page_tag_path(workspace: Workspace, page_dir: Path) -> Path:
        """
        tag 文件路径: 对应的 page 目录下, 文件名: tag-<tag_name>.json
        """
        if not page_dir.exists():
            raise ValueError(f"Page directory {page_dir} not found")
        return page_dir / WorkspaceService.get_page_tag_file_name(workspace)

    def page_tag_exists(self, workspace_id: str, page_dir: Path) -> bool:
        workspace = self.get_workspace(workspace_id)
        tag_path = WorkspaceService.get_page_tag_path(workspace, page_dir)
        return tag_path.is_file()

    @deprecated(replacement='page_tag_exists')
    def tag_exists(self, workspace_id: str, page_dir: Path) -> bool:
        return self.page_tag_exists(workspace_id, page_dir)

    def get_page_tag(self, workspace_id: str, page_dir: Path) -> dict:
        workspace = self.get_workspace(workspace_id)
        task_type = workspace.task_type
        tag_path = WorkspaceService.get_page_tag_path(workspace, page_dir)
        if not tag_path.exists():
            _tag_data = {}
        else:
            _tag_data = json.loads(tag_path.read_text(encoding="utf-8"))
        tag = task_service.tag_data2model(task_type, _tag_data)
        tag_data = tag.model_dump() if tag else {}
        if tag_data and not tag_data.get('abandon'):
            tag_data = update_abandon_status(workspace.page_filter, page_dir, tag_data)
        return tag_data

    def save_page_tag(self, workspace_id: str, page_dir: Path, tag_data: dict) -> bool:
        workspace = self.get_workspace(workspace_id)
        task_type = workspace.task_type
        tag = task_service.tag_data2model(task_type, tag_data)
        if not tag:
            raise ValueError(f"Invalid tag data: {tag_data}")
        tag_path = WorkspaceService.get_page_tag_path(workspace, page_dir)
        tag_path.write_text(
            json.dumps(tag.model_dump(), ensure_ascii=False, indent=2), encoding="utf-8"
        )
        return True

    @staticmethod
    def get_sample_tag_path(workspace: Workspace, batch_dir: Path, sample_name: str) -> Path:
        tag_name = workspace.tag_config.get('tag_name')
        if not tag_name:
            raise ValueError(f"Tag name not found for workspace {workspace.id}")
        return batch_dir / 'tag' / tag_name / f'{sample_name}.json'

    def get_sample_tag(self, workspace_id: str, batch_dir: Path, sample_name: str) -> dict:
        workspace = self.get_workspace(workspace_id)
        tag_path = WorkspaceService.get_sample_tag_path(workspace, batch_dir, sample_name)
        if not tag_path.exists():
            _tag_data = {}
        else:
            _tag_data = json.loads(tag_path.read_text(encoding="utf-8"))
        tag = task_service.tag_data2model(workspace.task_type, _tag_data)
        return tag.model_dump() if tag else {}

    def save_sample_tag(
        self, workspace_id: str, batch_dir: Path, sample_name: str, tag_data: dict
    ) -> bool:
        workspace = self.get_workspace(workspace_id)
        tag = task_service.tag_data2model(workspace.task_type, tag_data)
        if not tag:
            raise ValueError(f"Invalid tag data: {tag_data}")
        tag_path = WorkspaceService.get_sample_tag_path(workspace, batch_dir, sample_name)
        tag_path.parent.mkdir(parents=True, exist_ok=True)
        tag_path.write_text(
            json.dumps(tag.model_dump(), ensure_ascii=False, indent=2), encoding="utf-8"
        )
        return True

    @deprecated(replacement='get_page_tag_path')
    @staticmethod
    def get_tag_path(workspace: Workspace, page_dir: Path) -> Path:
        return WorkspaceService.get_page_tag_path(workspace, page_dir)

    @deprecated(replacement='get_page_tag_file_name')
    @staticmethod
    def get_tag_file_name(workspace: Workspace) -> str:
        return WorkspaceService.get_page_tag_file_name(workspace)

    @deprecated(replacement='get_page_tag')
    def get_tag(self, workspace_id: str, page_dir: Path) -> dict:
        return self.get_page_tag(workspace_id, page_dir)

    @deprecated(replacement='save_page_tag')
    def save_tag(self, workspace_id: str, page_dir: Path, tag_data: dict) -> bool:
        return self.save_page_tag(workspace_id, page_dir, tag_data)


workspace_service = WorkspaceService()
