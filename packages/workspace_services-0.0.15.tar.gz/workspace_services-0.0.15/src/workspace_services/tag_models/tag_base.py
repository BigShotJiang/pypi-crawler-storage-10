from pydantic import BaseModel, ConfigDict


class TagBase(BaseModel):
    model_config = ConfigDict(extra="ignore")

    tagging_difficulty: int = 0
    abandon: bool = False
