from pydantic import BaseModel, Field

from workspace_services.tag_models.tag_base import TagBase


class ExtractionResult(BaseModel):
    header: dict[str, str] = {}
    bodies: list[dict[str, dict[str, str]]] = []  # 允许多种body类型, 每种body类型名称自定义


class ExtractionTag(TagBase):
    result: ExtractionResult = Field(default_factory=ExtractionResult)
