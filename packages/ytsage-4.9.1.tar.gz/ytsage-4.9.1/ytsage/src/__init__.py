"""
YTSage - YouTube Video Downloader

A modern, user-friendly YouTube video downloader built with PySide6.
"""

__version__ = "4.9.1"
__author__ = "oop7"
