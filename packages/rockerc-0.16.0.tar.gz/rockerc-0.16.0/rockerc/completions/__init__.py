"""Embedded shell completion scripts for rockerc tools."""
