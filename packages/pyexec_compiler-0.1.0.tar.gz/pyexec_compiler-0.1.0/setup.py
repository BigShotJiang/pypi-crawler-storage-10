"""
PyExec - Python JIT/AOT Compiler
Educational project for learning compilation techniques.
"""

from setuptools import setup, find_packages

# Fallback setup.py for compatibility
# Primary configuration is in pyproject.toml
setup(
    packages=find_packages(exclude=["tests", "tests.*"]),
    include_package_data=True,
)
