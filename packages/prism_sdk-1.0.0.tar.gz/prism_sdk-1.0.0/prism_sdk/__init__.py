# Prism SDK for Python
"""
Official Python SDK for Prism Labs - AI-Powered Trust Verification API

The Prism SDK provides a simple interface to interact with the Prism Labs API
for trust verification, fact-checking, and knowledge graph generation.

Example:
    from prism_sdk import PrismClient
    
    client = PrismClient(api_key="your-api-key")
    result = client.query("What is quantum computing?")
    print(result.summary)
"""

__version__ = "1.0.0"
__author__ = "Prism Labs"
__email__ = "support@prismlabs.ai"

from .client import PrismClient
from .models import (
    QueryResult,
    TrustScore,
    VerificationResult,
    KnowledgeGraph,
    UsageInfo,
    SourceInfo,
    ReasoningStep,
    PrismError
)

__all__ = [
    "PrismClient",
    "QueryResult", 
    "TrustScore",
    "VerificationResult",
    "KnowledgeGraph",
    "UsageInfo",
    "SourceInfo",
    "ReasoningStep",
    "PrismError"
]