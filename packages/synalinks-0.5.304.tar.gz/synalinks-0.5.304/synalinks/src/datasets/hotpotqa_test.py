# # License Apache 2.0: (c) 2025 Yoan Sallami (Synalinks Team)

# from synalinks.src import testing
# from synalinks.src.datasets.hotpotqa import load_data
# from synalinks.src.datasets.hotpotqa import load_knowledge


# class HotPotQATest(testing.TestCase):
#     def test_load_knowledge(self):
#         knowledge = load_knowledge()
#         self.assertTrue(len(knowledge) > 0)

#     def test_load_data(self):
#         (x_train, y_train), (x_test, y_test) = load_data()
#         self.assertTrue(len(x_train) > 0)
#         self.assertTrue(len(y_train) > 0)
#         self.assertTrue(len(x_test) > 0)
#         self.assertTrue(len(y_test) > 0)
