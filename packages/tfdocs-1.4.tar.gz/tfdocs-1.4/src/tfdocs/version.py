"""tf-docs version information."""
__version__ = "1.4"
