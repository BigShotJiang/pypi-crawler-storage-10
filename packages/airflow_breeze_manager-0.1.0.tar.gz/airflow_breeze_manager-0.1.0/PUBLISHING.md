# Publishing to PyPI

This guide explains how to publish `airflow-breeze-manager` to PyPI.

## Prerequisites

1. **Configure PyPI Trusted Publishing** (Recommended - No tokens needed!)
   - Go to https://pypi.org/manage/account/publishing/
   - Add a new pending publisher:
     - PyPI Project Name: `airflow-breeze-manager`
     - Owner: `kaxil`
     - Repository name: `abm`
     - Workflow name: `publish.yml`
     - Environment name: `pypi`

2. **Optional: TestPyPI for testing**
   - Go to https://test.pypi.org/manage/account/publishing/
   - Configure the same settings for testing releases

## GitHub Actions Workflows

Two workflows are configured:

### 1. CI Workflow (`.github/workflows/ci.yml`)
Runs on every push and PR:
- Tests on Python 3.10, 3.11, 3.12, 3.13
- Runs linting (ruff)
- Runs type checking (mypy)
- Runs prek hooks
- Uploads coverage to Codecov (optional)

### 2. Publish Workflow (`.github/workflows/publish.yml`)
Runs on:
- **Release publication**: Automatically publishes to PyPI
- **Manual trigger**: Can publish to TestPyPI for testing

## Release Process

### Step 1: Update Version

Update the version in `pyproject.toml`:

```toml
[project]
name = "airflow-breeze-manager"
version = "0.1.1"  # Increment version
```

### Step 2: Update Documentation

Update any version-specific documentation:
- README.md
- CHANGELOG.md (create one if needed)

### Step 3: Commit and Push

```bash
git add pyproject.toml
git commit -m "Bump version to 0.1.1"
git push origin main
```

### Step 4: Create a Git Tag

```bash
git tag v0.1.1
git push origin v0.1.1
```

### Step 5: Create GitHub Release

1. Go to https://github.com/kaxil/abm/releases/new
2. Choose the tag you just created (`v0.1.1`)
3. Release title: `v0.1.1`
4. Add release notes describing changes
5. Click "Publish release"

**The GitHub Action will automatically build and publish to PyPI!**

## Testing with TestPyPI (Optional)

Before publishing to production PyPI, you can test with TestPyPI:

1. Go to https://github.com/kaxil/abm/actions/workflows/publish.yml
2. Click "Run workflow"
3. This will publish to TestPyPI
4. Test installation:
   ```bash
   uv pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ airflow-breeze-manager
   ```

## Manual Publishing (Not Recommended)

If you need to publish manually without GitHub Actions:

```bash
# Install build tools
uv pip install build twine

# Build the package
uv build

# Upload to TestPyPI (test first!)
uv run twine upload --repository testpypi dist/*

# Upload to PyPI
uv run twine upload dist/*
```

You'll need API tokens for manual publishing:
- PyPI token: https://pypi.org/manage/account/token/
- TestPyPI token: https://test.pypi.org/manage/account/token/

## Verification

After publishing, verify the package:

1. Check PyPI page: https://pypi.org/project/airflow-breeze-manager/
2. Install from PyPI:
   ```bash
   uv tool install airflow-breeze-manager
   abm --version
   ```
3. Verify all metadata is correct (description, links, classifiers)

## Version Numbering

Follow [Semantic Versioning](https://semver.org/):
- **MAJOR** version (1.0.0): Incompatible API changes
- **MINOR** version (0.1.0): New functionality, backwards compatible
- **PATCH** version (0.1.1): Bug fixes, backwards compatible

For pre-releases, use:
- Alpha: `0.1.0a1`
- Beta: `0.1.0b1`
- Release candidate: `0.1.0rc1`

## Troubleshooting

### "Project name already exists"
- The project name `airflow-breeze-manager` must be available on PyPI
- If taken, you'll need to choose a different name

### "Trusted publishing not configured"
- Follow the Prerequisites section to set up trusted publishing
- Or use API tokens as a fallback

### "Build failed"
- Check the GitHub Actions logs
- Ensure all tests pass locally first: `uv run pytest`
- Verify the build works: `uv build`

### "Permission denied"
- Ensure the GitHub repository environment is configured correctly
- Check that the workflow has `id-token: write` permission

## Post-Release Checklist

- [ ] Version bumped in `pyproject.toml`
- [ ] Git tag created and pushed
- [ ] GitHub release created with notes
- [ ] Package appears on PyPI
- [ ] Installation tested: `uv tool install airflow-breeze-manager`
- [ ] Documentation updated
- [ ] Announcement made (optional)

## Resources

- [PyPI Trusted Publishing](https://docs.pypi.org/trusted-publishers/)
- [Python Packaging Guide](https://packaging.python.org/)
- [Semantic Versioning](https://semver.org/)
- [GitHub Actions for Python](https://docs.github.com/en/actions/automating-builds-and-tests/building-and-testing-python)
