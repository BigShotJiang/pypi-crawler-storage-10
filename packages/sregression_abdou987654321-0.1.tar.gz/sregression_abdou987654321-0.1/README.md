# sregression

Simple Linear Regression implemented from scratch using gradient descent.

## install

pip install sregression-yourname-0.1

## usage

```python
from sregression import LinearRegression
model = LinearRegression()
model.fit(epochs=1000, lr=0.01, x=[1,2,3], y=[2,4,5])
print(model.predict([4,5]))
