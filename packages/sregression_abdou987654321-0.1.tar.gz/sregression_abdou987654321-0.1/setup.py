from setuptools import setup, find_packages

setup(
    name='sregression_abdou987654321',
    version='0.1',
    packages=find_packages(),
    license='MIT',
    description='A simple linear regression implementation from scratch',
    author='Abdallah Yettou',
    author_email='a.yettou@esi-sba.dz',
    url='https://github.com/AbdallahYettou/sregression_abdou12345',
    keywords=['regression', 'linear', 'machine-learning'],
    install_requires=['numpy'],
)
