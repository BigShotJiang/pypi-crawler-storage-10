create table indexers (
        url varchar(255) primary key not null,
        block integer default null
);
