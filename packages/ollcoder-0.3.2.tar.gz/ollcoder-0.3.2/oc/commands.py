from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, Iterable, Optional


class CommandNotFound(Exception):
    pass


@dataclass
class Command:
    name: str
    func: Callable[..., Any]
    help: Optional[str] = None


class CommandRegistry:
    """In-process command registry for wiring keyboard shortcuts to actions.

    Usage:
        reg = CommandRegistry.global_registry()
        reg.register('save_file', handler)
        reg.execute('save_file', path='foo.py')
    """

    _global: "CommandRegistry" | None = None

    def __init__(self) -> None:
        self._cmds: Dict[str, Command] = {}

    # ---- Global singleton ---- #
    @classmethod
    def global_registry(cls) -> "CommandRegistry":
        if cls._global is None:
            cls._global = CommandRegistry()
        return cls._global

    # ---- Registration ---- #
    def register(self, name: str, func: Callable[..., Any], help: Optional[str] = None) -> None:
        self._cmds[name] = Command(name=name, func=func, help=help)

    def unregister(self, name: str) -> None:
        self._cmds.pop(name, None)

    def is_registered(self, name: str) -> bool:
        return name in self._cmds

    def list(self) -> Iterable[Command]:
        return list(self._cmds.values())

    # ---- Execution ---- #
    def execute(self, name: str, /, **kwargs: Any) -> Any:
        cmd = self._cmds.get(name)
        if not cmd:
            raise CommandNotFound(name)
        return cmd.func(**kwargs)


def command(name: str, help: Optional[str] = None):
    """Decorator to register a function as a command on the global registry."""
    def deco(fn: Callable[..., Any]):
        CommandRegistry.global_registry().register(name, fn, help=help)
        return fn
    return deco
