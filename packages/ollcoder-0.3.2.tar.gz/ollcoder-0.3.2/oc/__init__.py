# Makes oc a package
from .adaptive_builder import AdaptiveConfig, build_adaptive_context, estimate_capacity
from .commands import CommandNotFound, CommandRegistry, command
from .context_cache import ContextCache, provider_fingerprint
from .context_compression import CompressedResult, CompressionLevel, compress_content
from .context_strategy import (
    ContextFile,
    ContextStrategy,
    Priority,
    build_context,
    format_context_summary,
)
from .memory import (
    AgentSession,
    MemoryStore,
    TaskMemory,
    global_memory,
)
from .sandbox import Mount, SandboxConfig, SandboxError, SandboxRunner
from .shortcuts import KeyBindingManager
from .trusted_folders import (
    Policy,
    TrustedFoldersManager,
    TrustLevel,
    global_trust,
    guarded_open,
    guarded_read_text,
    guarded_write_text,
)
from .wiring import (
    build_context_cmd,
    command_palette_cmd,
    rebuild_index_cmd,
    trust_set_cmd,
    trust_status_cmd,
)

__all__ = [
    # adaptive_builder
    "AdaptiveConfig",
    "build_adaptive_context",
    "estimate_capacity",
    # commands
    "CommandNotFound",
    "CommandRegistry",
    "command",
    # context_cache
    "ContextCache",
    "provider_fingerprint",
    # context_compression
    "CompressedResult",
    "CompressionLevel",
    "compress_content",
    # context_strategy
    "ContextFile",
    "ContextStrategy",
    "Priority",
    "build_context",
    "format_context_summary",
    # sandbox
    "Mount",
    "SandboxConfig",
    "SandboxError",
    "SandboxRunner",
    # shortcuts
    "KeyBindingManager",
    # trusted_folders
    "Policy",
    "TrustLevel",
    "TrustedFoldersManager",
    "guarded_open",
    "guarded_read_text",
    "guarded_write_text",
    "global_trust",
    # memory
    "AgentSession",
    "MemoryStore",
    "TaskMemory",
    "global_memory",
    # wiring
    "build_context_cmd",
    "command_palette_cmd",
    "rebuild_index_cmd",
    "trust_set_cmd",
    "trust_status_cmd",
]
