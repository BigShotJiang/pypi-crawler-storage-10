from __future__ import annotations

import time
from contextlib import AbstractContextManager
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

try:
    from radon.complexity import cc_visit  # type: ignore
except Exception:  # pragma: no cover - optional
    cc_visit = None  # type: ignore

try:
    from codecarbon import EmissionsTracker  # type: ignore
except Exception:  # pragma: no cover - optional
    EmissionsTracker = None  # type: ignore


@dataclass(frozen=True)
class EcoIssue:
    path: str
    line: int
    kind: str
    message: str
    score: float


def analyze(root: str) -> List[EcoIssue]:
    out: List[EcoIssue] = []
    for p in Path(root).rglob("*.py"):
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if cc_visit:
            try:
                for block in cc_visit(text):  # type: ignore[misc]
                    if getattr(block, "complexity", 0) >= 10:
                        out.append(
                            EcoIssue(
                                str(p), getattr(block, "lineno", 1), "complexity", f"High complexity in {block.name}", float(block.complexity)
                            )
                        )
            except Exception:
                pass
        # Heuristics
        if "for " in text and "for " in text.split("for ", 1)[1]:
            out.append(EcoIssue(str(p), 1, "loops", "Nested loops may be energy intensive", 1.0))
    return out

class EmissionSession(AbstractContextManager["EmissionSession"]):
    """Context manager to measure emissions using CodeCarbon if available.

    Attributes after exit:
    - emissions_kg: float | None
    - duration_s: float
    """

    def __init__(self, project_name: str = "ollcoder-session") -> None:
        self.project_name = project_name
        self._tracker = None
        self._t0 = 0.0
        self.emissions_kg: Optional[float] = None
        self.duration_s: float = 0.0

    def __enter__(self) -> "EmissionSession":
        self._t0 = time.perf_counter()
        if EmissionsTracker is not None:
            try:  # type: ignore[truthy-function]
                self._tracker = EmissionsTracker(project_name=self.project_name, measure_power_secs=1)
                self._tracker.start()
            except Exception:
                self._tracker = None
        return self

    def __exit__(self, exc_type, exc, tb) -> Optional[bool]:
        self.duration_s = max(0.0, time.perf_counter() - self._t0)
        if self._tracker is not None:
            try:
                self.emissions_kg = float(self._tracker.stop() or 0.0)
            except Exception:
                self.emissions_kg = None
        return None


def track_emissions(project_name: str = "ollcoder-session") -> EmissionSession:
    """Return a context manager that measures emissions if CodeCarbon is installed.

    Usage:
      with track_emissions():
          ...
    """

    return EmissionSession(project_name)


def run_with_emissions(fn, *args, **kwargs) -> Tuple[Optional[float], float, object]:
    """Run a function while tracking emissions (if possible).

    Returns (emissions_kg, duration_seconds, result).
    """
    with track_emissions() as sess:
        result = fn(*args, **kwargs)
    return sess.emissions_kg, sess.duration_s, result


def estimate_carbon(num_tokens: int) -> float:
    """Rough estimate (kg CO2e) when live tracking is unavailable.

    Calibrated placeholder: 5e-7 kg CO2 per token.
    """
    return num_tokens * 5e-7
