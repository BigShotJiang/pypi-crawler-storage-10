from __future__ import annotations

from pathlib import Path
from typing import Dict

try:
    from PIL import Image  # type: ignore
except Exception:  # pragma: no cover - optional
    Image = None  # type: ignore


def describe_image(path: str) -> Dict[str, str]:
    p = Path(path)
    info: Dict[str, str] = {"path": str(p), "exists": str(p.exists())}
    if Image is None or not p.exists():
        return info
    try:
        with Image.open(p) as im:
            info.update(
                {
                    "format": im.format or "",
                    "mode": im.mode,
                    "size": f"{im.width}x{im.height}",
                }
            )
    except Exception:
        pass
    return info