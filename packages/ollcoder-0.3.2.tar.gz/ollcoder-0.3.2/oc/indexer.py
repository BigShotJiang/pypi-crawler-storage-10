import os
from pathlib import Path
from typing import Any, Dict, List, Tuple

from .trusted_folders import global_trust

EXCLUDES = {".git", "node_modules", ".venv", "venv", "dist", "build", "__pycache__"}
TEXT_EXTS = {".py", ".ts", ".tsx", ".js", ".mjs", ".cjs", ".json", ".md", ".txt", ".yml", ".yaml", ".toml", ".sh", ".go", ".rs", ".java", ".kt", ".swift", ".c", ".h", ".cpp", ".hpp"}


def iter_files(root: str, max_files: int = 5000, max_size: int = 2_000_000) -> List[Path]:
    root_p = Path(root)
    out: List[Path] = []
    for dirpath, dirnames, filenames in os.walk(root_p):
        # Prune excluded directories
        dirnames[:] = [d for d in dirnames if d not in EXCLUDES and not d.startswith(".")]
        for fn in filenames:
            p = Path(dirpath) / fn
            if p.suffix.lower() in TEXT_EXTS or p.suffix == "":
                try:
                    if p.stat().st_size <= max_size:
                        out.append(p)
                        if len(out) >= max_files:
                            return out
                except FileNotFoundError:
                    continue
    return out


def project_tree(root: str, max_entries: int = 300) -> str:
    """Return a simple tree string for the project (limited)."""
    root_p = Path(root)
    lines: List[str] = []
    count = 0
    for p in sorted(iter_files(root)):
        rel = p.relative_to(root_p)
        lines.append(str(rel))
        count += 1
        if count >= max_entries:
            lines.append("... (truncated)")
            break
    return "\n".join(lines)


def read_file_safe(path: Path, max_bytes: int = 200_000) -> Tuple[bool, str]:
    try:
        # Enforce trust policy for read
        if not global_trust().ensure_allowed(str(path), "read"):
            return False, "Access denied by trust policy"
        data = path.read_text(errors="replace")
        if len(data) > max_bytes:
            data = data[:max_bytes] + "\n... (truncated)"
        return True, data
    except Exception as e:
        return False, str(e)


def build_context(root: str, query: str, limit_files: int = 10) -> List[Dict[str, Any]]:
    """Very simple keyword-based retrieval over the project."""
    root_p = Path(root)
    files = iter_files(root)
    scored: List[Tuple[int, Path]] = []
    q = query.lower()
    for p in files:
        ok, txt = read_file_safe(p)
        if not ok:
            continue
        score = 0
        if p.suffix.lower() in {".py", ".ts", ".tsx", ".js"}:
            score += 1
        score += txt.lower().count(q)
        if score > 0:
            scored.append((score, p))
    scored.sort(key=lambda x: x[0], reverse=True)
    out: List[Dict[str, Any]] = []
    for _, p in scored[:limit_files]:
        ok, txt = read_file_safe(p, max_bytes=40_000)
        if ok:
            out.append({"path": str(p.relative_to(root_p)), "content": txt})
    return out
