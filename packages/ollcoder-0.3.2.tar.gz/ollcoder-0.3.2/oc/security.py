from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

from .adaptive_builder import AdaptiveConfig, build_adaptive_context
from .context_cache import ContextCache


@dataclass(frozen=True)
class Issue:
    path: str
    line: int | None
    severity: str
    rule: str
    message: str


# ---- SARIF export ---- #

_SEVERITY_TO_LEVEL = {
    "CRITICAL": "error",
    "HIGH": "error",
    "MEDIUM": "warning",
    "LOW": "note",
    "INFO": "note",
}


def _fingerprint(issue: Issue) -> str:
    blob = f"{issue.path}:{issue.rule}:{issue.line or 0}:{issue.message}".encode("utf-8")
    return hashlib.sha1(blob).hexdigest()


def to_sarif(issues: Iterable[Issue], *, tool_name: str = "oc-security") -> Dict[str, Any]:
    rules: Dict[str, Dict[str, Any]] = {}
    results: List[Dict[str, Any]] = []

    for it in issues:
        rid = it.rule or "unknown"
        if rid not in rules:
            rules[rid] = {
                "id": rid,
                "name": rid,
                "shortDescription": {"text": rid},
                "fullDescription": {"text": rid},
                "defaultConfiguration": {"level": _SEVERITY_TO_LEVEL.get(str(it.severity).upper(), "warning")},
                "properties": {"precision": "medium"},
                "help": {"text": ""},
            }
        level = _SEVERITY_TO_LEVEL.get(str(it.severity).upper(), "warning")
        loc = {
            "physicalLocation": {
                "artifactLocation": {"uri": it.path},
                "region": {"startLine": int(it.line or 1), "startColumn": 1},
            }
        }
        results.append(
            {
                "ruleId": rid,
                "level": level,
                "message": {"text": it.message, "markdown": it.message},
                "locations": [loc],
                "partialFingerprints": {"primaryLocationLineHash": _fingerprint(it)},
                "properties": {"severity": str(it.severity).upper()},
            }
        )

    sarif = {
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": tool_name,
                        "rules": list(rules.values()),
                    }
                },
                "results": results,
            }
        ],
    }
    return sarif


def _run_bandit(root: str) -> List[Issue]:
    if shutil.which("bandit") is None:
        return []
    try:
        p = subprocess.run(
            ["bandit", "-r", root, "-f", "json"], capture_output=True, text=True, timeout=60
        )
        if p.returncode not in (0, 1):
            return []
        data = json.loads(p.stdout or "{}")
        out: List[Issue] = []
        for r in data.get("results", []):
            out.append(
                Issue(
                    path=str(Path(root) / r.get("filename", "")),
                    line=int(r.get("line_number") or 0) or None,
                    severity=str(r.get("issue_severity") or "LOW"),
                    rule=str(r.get("test_id") or "B???"),
                    message=str(r.get("issue_text") or ""),
                )
            )
        return out
    except Exception:
        return []


def _run_semgrep(root: str) -> List[Issue]:
    if shutil.which("semgrep") is None:
        return []
    try:
        p = subprocess.run(
            ["semgrep", "--config", "auto", "--json"], cwd=root, capture_output=True, text=True, timeout=120
        )
        if p.returncode not in (0, 1):
            return []
        data = json.loads(p.stdout or "{}")
        out: List[Issue] = []
        for r in data.get("results", []):
            loc = r.get("extra", {}).get("lines", "")
            line = None
            if isinstance(loc, str):
                try:
                    line = int(loc.split(":", 1)[0])
                except Exception:
                    line = None
            out.append(
                Issue(
                    path=str(Path(root) / r.get("path", "")),
                    line=line,
                    severity=(r.get("extra", {}).get("severity") or "INFO").upper(),
                    rule=str(r.get("check_id") or "semgrep"),
                    message=str(r.get("extra", {}).get("message") or ""),
                )
            )
        return out
    except Exception:
        return []


def _heuristics(root: str) -> List[Issue]:
    out: List[Issue] = []
    for p in Path(root).rglob("*.py"):
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if "eval(" in text or "exec(" in text:
            out.append(Issue(str(p), None, "MEDIUM", "PY-EVAL", "Use of eval/exec is dangerous"))
        if "subprocess.Popen(" in text and "shell=True" in text:
            out.append(Issue(str(p), None, "HIGH", "PY-SHELL", "shell=True can be unsafe"))
    return out


def scan(root: str) -> List[Issue]:
    issues = _run_bandit(root) + _run_semgrep(root)
    if not issues:
        issues = _heuristics(root)
    return issues


def suggest_fixes(
    root: str,
    query: str = "security fix suggestions",
    *,
    provider: Any | None = None,
) -> Tuple[List[str], dict]:
    # Build context and craft suggestions based on scan issues and high-priority files
    issues = scan(root)
    cache = ContextCache(root)
    files, stats = build_adaptive_context(
        AdaptiveConfig(root_dir=root, query=query), cache=cache, provider=provider
    )

    # Rank files by presence in issues and priority
    issue_paths = {i.path for i in issues}
    ranked = sorted(
        files,
        key=lambda f: (
            0 if f.path in issue_paths else 1,
            0 if f.priority.name in {"CRITICAL", "HIGH"} else 1,
            -len(f.content),
        ),
    )

    # Compose richer suggestion strings while keeping return type stable
    sev_order = ["INFO", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
    sev_by_path: Dict[str, str] = {}
    rules_by_path: Dict[str, List[str]] = {}
    for it in issues:
        cur = sev_by_path.get(it.path, "INFO")
        cand = (it.severity or "INFO").upper()
        if cand not in sev_order:
            cand = "INFO"
        if sev_order.index(cand) > sev_order.index(cur):
            sev_by_path[it.path] = cand
        rules_by_path.setdefault(it.path, [])
        if it.rule not in rules_by_path[it.path]:
            rules_by_path[it.path].append(it.rule)

    suggestions: List[str] = []
    for f in ranked[:10]:
        tag = "HAS_ISSUES" if f.path in issue_paths else "RELATED"
        sev = sev_by_path.get(f.path, "INFO")
        level = (f.meta or {}).get("level")
        suggestions.append(f"[{tag}][{sev}] {f.path}: {f.reason} ({level})")
    return suggestions, stats


def suggest_fixes_structured(
    root: str,
    query: str = "security fix suggestions",
    *,
    provider: Any | None = None,
) -> Tuple[List[Dict[str, Any]], dict]:
    """Structured suggestions for machine consumption.

    Returns (suggestions, stats) where suggestions are dicts:
      {path, tag, severity, reason, level, priority, issue_count, rules}
    """
    issues = scan(root)
    cache = ContextCache(root)
    files, stats = build_adaptive_context(
        AdaptiveConfig(root_dir=root, query=query), cache=cache, provider=provider
    )

    issue_paths = {i.path for i in issues}
    sev_order = ["INFO", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
    sev_by_path: Dict[str, str] = {}
    rules_by_path: Dict[str, List[str]] = {}
    count_by_path: Dict[str, int] = {}
    for it in issues:
        cur = sev_by_path.get(it.path, "INFO")
        cand = (it.severity or "INFO").upper()
        if cand not in sev_order:
            cand = "INFO"
        if sev_order.index(cand) > sev_order.index(cur):
            sev_by_path[it.path] = cand
        rules_by_path.setdefault(it.path, [])
        if it.rule not in rules_by_path[it.path]:
            rules_by_path[it.path].append(it.rule)
        count_by_path[it.path] = count_by_path.get(it.path, 0) + 1

    ranked = sorted(
        files,
        key=lambda f: (
            0 if f.path in issue_paths else 1,
            0 if f.priority.name in {"CRITICAL", "HIGH"} else 1,
            -len(f.content),
        ),
    )

    out: List[Dict[str, Any]] = []
    for f in ranked[:10]:
        tag = "HAS_ISSUES" if f.path in issue_paths else "RELATED"
        out.append(
            {
                "path": f.path,
                "tag": tag,
                "severity": sev_by_path.get(f.path, "INFO"),
                "reason": f.reason,
                "level": (f.meta or {}).get("level"),
                "priority": f.priority.name,
                "issue_count": count_by_path.get(f.path, 0),
                "rules": (rules_by_path.get(f.path) or [])[:5],
            }
        )
    return out, stats
