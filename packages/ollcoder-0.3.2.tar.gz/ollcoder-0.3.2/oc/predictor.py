from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List


@dataclass(frozen=True)
class Prediction:
    path: str
    reason: str


def analyze_git(root: str) -> List[Prediction]:
    preds: List[Prediction] = []
    try:
        p = subprocess.run(
            ["git", "--no-pager", "log", "--name-only", "--pretty=format:"],
            cwd=root,
            capture_output=True,
            text=True,
            timeout=10,
        )
        counts: Dict[str, int] = {}
        for ln in p.stdout.splitlines():
            fp = ln.strip()
            if not fp:
                continue
            counts[fp] = counts.get(fp, 0) + 1
        for fp, n in sorted(counts.items(), key=lambda kv: kv[1], reverse=True)[:20]:
            preds.append(Prediction(path=str(Path(root) / fp), reason=f"High churn ({n} changes)"))
    except Exception:
        pass
    return preds