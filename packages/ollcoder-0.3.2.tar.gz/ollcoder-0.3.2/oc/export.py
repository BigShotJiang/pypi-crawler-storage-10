from __future__ import annotations

from pathlib import Path
from typing import Iterable, List

from .context_strategy import ContextFile

_DEF_LANG_BY_EXT = {
    ".py": "python",
    ".ts": "ts",
    ".tsx": "ts",
    ".js": "js",
    ".mjs": "js",
    ".cjs": "js",
    ".go": "go",
    ".rs": "rust",
    ".java": "java",
    ".kt": "kotlin",
    ".swift": "swift",
    ".c": "c",
    ".h": "c",
    ".cpp": "cpp",
    ".hpp": "cpp",
    ".cs": "csharp",
    ".rb": "ruby",
    ".php": "php",
    ".sh": "bash",
    ".lua": "lua",
}


def _infer_lang(path: str, meta_lang: str | None) -> str:
    if meta_lang:
        # Map a few common meta values to fence languages
        m = meta_lang.lower()
        if m in {"python", "go", "rust", "java", "kotlin", "swift"}:
            return m
        if m in {"js/ts", "javascript", "typescript"}:
            return "ts"
        if m in {"jvm"}:
            return "java"
    ext = Path(path).suffix.lower()
    return _DEF_LANG_BY_EXT.get(ext, "text")


def format_for_web(context_files: Iterable[ContextFile]) -> str:
    parts: List[str] = []
    for cf in context_files:
        lang = _infer_lang(cf.path, (cf.meta or {}).get("language"))
        # Absolute path required by some UIs for better context; fall back to original
        p = str(Path(cf.path).resolve())
        parts.append(f"```{lang} path={p} start=1\n{cf.content}\n```")
    return "\n\n".join(parts) + "\n"