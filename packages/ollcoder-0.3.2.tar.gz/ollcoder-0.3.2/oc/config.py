from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

try:  # Python 3.11+
    import tomllib  # type: ignore[attr-defined]
except Exception:  # pragma: no cover - tomllib always exists on 3.11+
    tomllib = None  # type: ignore


@dataclass(frozen=True)
class AppConfig:
    log_level: str = "INFO"
    log_json: bool = False
    log_file: Optional[str] = None

    cache_ttl_seconds: int = 24 * 60 * 60
    trust_config_path: Optional[str] = None

    sandbox_engine: Optional[str] = None  # "docker" | "podman"

    # Provider defaults (optional)
    provider: Optional[str] = None  # "ollama" | "gemini"
    model: Optional[str] = None


def _get_tool_section() -> Dict[str, Any]:
    """Read [tool.ollcoder] from pyproject.toml if present."""
    try:
        proj = Path.cwd() / "pyproject.toml"
        if proj.is_file() and tomllib is not None:
            data = tomllib.loads(proj.read_text(encoding="utf-8"))
            return data.get("tool", {}).get("ollcoder", {}) or {}
    except Exception:
        return {}
    return {}


def _env_bool(name: str, default: bool) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return str(v).strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int) -> int:
    v = os.environ.get(name)
    try:
        return int(v) if v is not None else default
    except Exception:
        return default


def load_config() -> AppConfig:
    tool = _get_tool_section()

    log_level = str(os.environ.get("OLLCODER_LOG_LEVEL") or tool.get("log_level") or "INFO").upper()
    log_json = _env_bool("OLLCODER_LOG_JSON", bool(tool.get("log_json", False)))
    log_file = os.environ.get("OLLCODER_LOG_FILE") or tool.get("log_file")

    cache_ttl = _env_int("OLLCODER_CACHE_TTL", int(tool.get("cache_ttl_seconds", 24 * 60 * 60)))
    trust_cfg = os.environ.get("OLLCODER_TRUST_CONFIG") or tool.get("trust_config_path")

    sandbox_engine = os.environ.get("OLLCODER_SANDBOX_ENGINE") or tool.get("sandbox_engine")
    provider = os.environ.get("OC_PROVIDER") or tool.get("provider")
    model = os.environ.get("OC_MODEL") or tool.get("model")

    return AppConfig(
        log_level=log_level,
        log_json=bool(log_json),
        log_file=str(log_file) if log_file else None,
        cache_ttl_seconds=int(cache_ttl),
        trust_config_path=str(trust_cfg) if trust_cfg else None,
        sandbox_engine=str(sandbox_engine) if sandbox_engine else None,
        provider=str(provider) if provider else None,
        model=str(model) if model else None,
    )
