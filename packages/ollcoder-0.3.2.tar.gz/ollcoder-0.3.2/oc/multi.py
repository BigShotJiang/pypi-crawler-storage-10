from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Iterable, List, Tuple

from .adaptive_builder import AdaptiveConfig, build_adaptive_context


@dataclass(frozen=True)
class MultiContextResult:
    files: List[Tuple[str, str]]  # (root, path)


def build_multi_context(
    roots: Iterable[str],
    query: str = "",
    model_max_tokens: int | None = None,
    *,
    provider: Any | None = None,
) -> List[Tuple[str, str]]:
    out: List[Tuple[str, str]] = []
    for root in roots:
        files, _ = build_adaptive_context(
            AdaptiveConfig(root_dir=os.path.abspath(root), query=query, model_max_tokens=model_max_tokens),
            cache=None,
            provider=provider,
        )
        for f in files:
            out.append((root, f.path))
    return out
