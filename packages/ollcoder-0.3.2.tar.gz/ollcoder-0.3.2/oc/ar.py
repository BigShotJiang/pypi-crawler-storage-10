from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Iterable, List

from .context_strategy import ContextFile


def export_annotations(context_files: Iterable[ContextFile], out_path: str) -> str:
    ann: List[Dict[str, Any]] = []
    for cf in context_files:
        ann.append(
            {
                "path": str(Path(cf.path).resolve()),
                "priority": cf.priority.name,
                "level": (cf.meta or {}).get("level"),
                "suggestion": cf.reason,
            }
        )
    payload = {"version": 1, "annotations": ann}
    Path(out_path).write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return out_path