from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List


@dataclass(frozen=True)
class EthicsIssue:
    path: str
    line: int
    kind: str
    message: str


_SENSITIVE = [
    "race",
    "gender",
    "religion",
    "ethnicity",
    "blacklist",
    "whitelist",
]


def scan(root: str) -> List[EthicsIssue]:
    out: List[EthicsIssue] = []
    for p in Path(root).rglob("*.py"):
        try:
            for idx, ln in enumerate(p.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
                low = ln.lower()
                for k in _SENSITIVE:
                    if k in low:
                        out.append(EthicsIssue(str(p), idx, "bias_term", f"Term '{k}' found; review wording"))
        except Exception:
            continue
    return out