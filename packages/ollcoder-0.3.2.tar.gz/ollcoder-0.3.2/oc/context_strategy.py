from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from .context_compression import CompressionLevel, compress_content
from .indexer import iter_files, read_file_safe


class Priority(Enum):
    """Four-tier priority system for context building."""
    
    CRITICAL = 1  # 50% of budget - current file, explicitly mentioned files
    HIGH = 2      # 25% of budget - recent changes, related files
    MEDIUM = 3    # 15% of budget - dependencies, config files
    LOW = 4       # 10% of budget - background, docs


@dataclass(frozen=True)
class ContextFile:
    path: str
    priority: Priority
    reason: str
    content: str
    meta: Dict[str, Any]
    
    @property
    def relative_path(self) -> str:
        p = Path(self.path)
        try:
            return str(p.relative_to(Path.cwd()))
        except Exception:
            return p.name


@dataclass(frozen=True)
class ContextStrategy:
    """Configuration for multi-tier context building."""
    
    root_dir: str
    current_file: Optional[str] = None
    mentioned_files: Optional[List[str]] = None
    query: str = ""
    max_files: int = 50
    token_budget: int = 32000
    
    # Priority allocation percentages
    critical_pct: float = 0.50
    high_pct: float = 0.25
    medium_pct: float = 0.15
    low_pct: float = 0.10


def build_context(strategy: ContextStrategy, provider: Any = None) -> List[ContextFile]:
    """Build prioritized context using multi-tier strategy."""
    
    # Calculate token budgets per tier
    budgets = {
        Priority.CRITICAL: int(strategy.token_budget * strategy.critical_pct),
        Priority.HIGH: int(strategy.token_budget * strategy.high_pct),
        Priority.MEDIUM: int(strategy.token_budget * strategy.medium_pct),
        Priority.LOW: int(strategy.token_budget * strategy.low_pct),
    }
    
    # Collect files by priority
    files_by_priority: Dict[Priority, List[Tuple[str, str]]] = {
        Priority.CRITICAL: [],
        Priority.HIGH: [],
        Priority.MEDIUM: [],
        Priority.LOW: [],
    }
    
    # CRITICAL: Current file + mentioned files
    if strategy.current_file and Path(strategy.current_file).exists():
        files_by_priority[Priority.CRITICAL].append((
            strategy.current_file, 
            "current file"
        ))
    
    if strategy.mentioned_files:
        for f in strategy.mentioned_files:
            if Path(f).exists():
                files_by_priority[Priority.CRITICAL].append((f, "mentioned in query"))
    
    # HIGH: Recent changes, related files
    recent_files = _find_recent_changes(strategy.root_dir)
    for f in recent_files[:10]:  # Limit recent files
        files_by_priority[Priority.HIGH].append((f, "recent git changes"))
    
    if strategy.query:
        related = _find_related_files(strategy.root_dir, strategy.query, limit=10)
        for f in related:
            files_by_priority[Priority.HIGH].append((f, "query-related"))
    
    # MEDIUM: Dependencies, config
    deps = _find_dependencies(strategy.root_dir)
    for f in deps:
        files_by_priority[Priority.MEDIUM].append((f, "dependency/config"))
    
    # LOW: Documentation, background
    docs = _find_documentation(strategy.root_dir)
    for f in docs[:5]:  # Limit docs
        files_by_priority[Priority.LOW].append((f, "documentation"))
    
    # Build final context with compression
    context_files: List[ContextFile] = []
    
    for priority in [Priority.CRITICAL, Priority.HIGH, Priority.MEDIUM, Priority.LOW]:
        budget = budgets[priority]
        files = files_by_priority[priority]
        
        # Remove duplicates while preserving order
        seen: Set[str] = set()
        unique_files: List[Tuple[str, str]] = []
        for path, reason in files:
            abs_path = str(Path(path).resolve())
            if abs_path not in seen:
                seen.add(abs_path)
                unique_files.append((abs_path, reason))
        
        # Add files until budget exhausted
        used_budget = 0
        for file_path, reason in unique_files:
            if used_budget >= budget:
                break
            
            # Determine compression level based on priority
            compression = _select_compression_level(priority, used_budget, budget)
            
            # Read and compress file
            ok, content = read_file_safe(Path(file_path))
            if not ok:
                continue
            
            result = compress_content(
                file_path, 
                content, 
                compression,
                provider=provider
            )

            # Attach level into meta for downstream consumers
            meta = dict(result.meta)
            meta["level"] = result.level.name
            
            # Estimate tokens (rough approximation: 1 token ≈ 4 chars)
            estimated_tokens = len(result.content) // 4
            
            if used_budget + estimated_tokens <= budget * 1.2:  # 20% overage allowed
                context_files.append(ContextFile(
                    path=file_path,
                    priority=priority,
                    reason=reason,
                    content=result.content,
                    meta=meta
                ))
                used_budget += estimated_tokens
    
    return context_files


def _select_compression_level(priority: Priority, used_budget: int, total_budget: int) -> CompressionLevel:
    """Select compression level based on priority and budget usage."""
    usage_pct = used_budget / max(total_budget, 1)
    
    if priority == Priority.CRITICAL:
        return CompressionLevel.NONE if usage_pct < 0.8 else CompressionLevel.LITE
    elif priority == Priority.HIGH:
        if usage_pct < 0.3:
            return CompressionLevel.LITE
        elif usage_pct < 0.7:
            return CompressionLevel.NO_COMMENTS
        else:
            return CompressionLevel.SIGNATURES
    elif priority == Priority.MEDIUM:
        if usage_pct < 0.5:
            return CompressionLevel.NO_COMMENTS
        else:
            return CompressionLevel.SIGNATURES
    else:  # LOW
        return CompressionLevel.SUMMARY


def _find_recent_changes(root_dir: str, max_files: int = 20) -> List[str]:
    """Find recently changed files using git."""
    try:
        # Get files changed in last 10 commits
        result = subprocess.run([
            "git", "diff", "--name-only", "HEAD~10", "HEAD"
        ], cwd=root_dir, capture_output=True, text=True, timeout=5)
        
        if result.returncode == 0:
            files = []
            for line in result.stdout.strip().split('\n'):
                if line:
                    full_path = os.path.join(root_dir, line)
                    if os.path.isfile(full_path):
                        files.append(full_path)
            return files[:max_files]
    except Exception:
        pass
    
    # Fallback: recently modified files by mtime
    try:
        all_files = iter_files(root_dir, max_files=1000)
        sorted_files = sorted(all_files, key=lambda p: p.stat().st_mtime, reverse=True)
        return [str(p) for p in sorted_files[:max_files]]
    except Exception:
        return []


def _find_related_files(root_dir: str, query: str, limit: int = 15) -> List[str]:
    """Find files related to query using simple keyword matching."""
    if not query:
        return []
    
    try:
        all_files = iter_files(root_dir, max_files=2000)
        scored: List[Tuple[int, str]] = []
        query_lower = query.lower()
        
        for file_path in all_files:
            ok, content = read_file_safe(file_path, max_bytes=100_000)
            if not ok:
                continue
            
            score = 0
            content_lower = content.lower()
            
            # Boost for filename matches
            if query_lower in file_path.name.lower():
                score += 10
            
            # Content keyword matches
            score += content_lower.count(query_lower)
            
            # Boost for code files
            if file_path.suffix in {'.py', '.js', '.ts', '.go', '.rs', '.java'}:
                score += 2
            
            if score > 0:
                scored.append((score, str(file_path)))
        
        scored.sort(key=lambda x: x[0], reverse=True)
        return [path for _, path in scored[:limit]]
    except Exception:
        return []


def _find_dependencies(root_dir: str) -> List[str]:
    """Find dependency and configuration files."""
    candidates = [
        'pyproject.toml', 'requirements.txt', 'setup.py', 'Pipfile',
        'package.json', 'yarn.lock', 'package-lock.json',
        'go.mod', 'go.sum',
        'Cargo.toml', 'Cargo.lock',
        'pom.xml', 'build.gradle',
        'Dockerfile', 'docker-compose.yml',
        'Makefile', 'CMakeLists.txt',
        '.gitignore', 'README.md', 'README.rst',
        'tox.ini', 'pytest.ini', '.pre-commit-config.yaml',
        'tsconfig.json', '.eslintrc.json',
    ]
    
    found = []
    for candidate in candidates:
        path = Path(root_dir) / candidate
        if path.is_file():
            found.append(str(path))
    
    return found


def _find_documentation(root_dir: str) -> List[str]:
    """Find documentation files."""
    doc_patterns = {'README', 'CHANGELOG', 'CONTRIBUTING', 'LICENSE', 'DOCS'}
    doc_extensions = {'.md', '.rst', '.txt', '.adoc'}
    
    found = []
    try:
        for file_path in iter_files(root_dir, max_files=500):
            name_upper = file_path.name.upper()
            name_lower = file_path.name.lower()
            stem_upper = file_path.stem.upper()
            
            # Check if it's a documentation file
            is_doc = (
                stem_upper in doc_patterns or
                any(pattern in name_upper for pattern in doc_patterns) or
                (file_path.suffix.lower() in doc_extensions and 
                 'doc' in name_lower)
            )
            
            if is_doc:
                found.append(str(file_path))
            
            if len(found) >= 10:
                break
    except Exception:
        pass
    
    return found


def format_context_summary(context_files: List[ContextFile]) -> str:
    """Format a summary of the context for debugging/logging."""
    if not context_files:
        return "No context files"
    
    lines = [f"Context: {len(context_files)} files"]
    
    by_priority: Dict[Priority, List[ContextFile]] = {}
    for cf in context_files:
        by_priority.setdefault(cf.priority, []).append(cf)
    
    for priority in [Priority.CRITICAL, Priority.HIGH, Priority.MEDIUM, Priority.LOW]:
        files = by_priority.get(priority, [])
        if files:
            names = [Path(cf.path).name for cf in files]
            lines.append(f"  {priority.name}: {', '.join(names)}")
    
    return '\n'.join(lines)