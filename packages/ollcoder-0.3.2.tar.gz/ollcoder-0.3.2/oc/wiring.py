from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional

from .adaptive_builder import AdaptiveConfig, build_adaptive_context
from .commands import CommandRegistry, command
from .config import load_config
from .context_cache import ContextCache
from .indexer import project_tree
from .trusted_folders import TrustedFoldersManager, TrustLevel


def _to_int(x: Optional[Any]) -> Optional[int]:
    try:
        return int(x) if x is not None else None
    except Exception:
        return None


@command("build_context", help="Build adaptive context for the current project")
def build_context_cmd(event: Any = None, query: str = "", current_file: Optional[str] = None, mentioned_files: Optional[List[str]] = None, model_max_tokens: Optional[int] = None, json_out: bool = False) -> Dict[str, Any]:
    root = os.getcwd()
    cache = ContextCache(root, ttl_seconds=load_config().cache_ttl_seconds)
    cfg = AdaptiveConfig(
        root_dir=root,
        current_file=current_file,
        mentioned_files=mentioned_files or [],
        query=query or "",
        model_max_tokens=_to_int(model_max_tokens),
    )
    files, stats = build_adaptive_context(cfg, cache=cache, provider=None)
    payload: Dict[str, Any] = {
        "stats": stats,
        "files": [
            {
                "path": f.path,
                "priority": f.priority.name,
                "reason": f.reason,
                "level": (f.meta or {}).get("level"),
                "size_tokens": max(1, len(f.content) // 4),
            }
            for f in files
        ],
    }
    if json_out:
        print(json.dumps(payload, indent=2))
    else:
        s = payload.get("stats", {})
        print(f"Context used {s.get('used_tokens')}/{s.get('budget_tokens')} tokens (adapted={s.get('adapted')}).")
        for f in payload["files"]:
            print(f"- [{f['priority']}] {f['path']} ({f['level']}, ~{f['size_tokens']}t) — {f['reason']}")
    return payload


@command("rebuild_index", help="Show a limited project tree")
def rebuild_index_cmd(event: Any = None, max_entries: int = 300) -> str:
    root = os.getcwd()
    tree = project_tree(root, max_entries=int(max_entries))
    print(tree)
    return tree


@command("command_palette", help="List available commands")
def command_palette_cmd(event: Any = None) -> List[Dict[str, str]]:
    reg = CommandRegistry.global_registry()
    rows = [{"name": c.name, "help": c.help or ""} for c in reg.list()]
    for r in rows:
        print(f"{r['name']}: {r['help']}")
    return rows


# Safe no-ops for editor-oriented commands (to avoid missing bindings)
@command("save_file", help="Not available in CLI mode")
@command("open_file", help="Not available in CLI mode")
@command("find", help="Not available in CLI mode")
@command("find_next", help="Not available in CLI mode")
@command("find_prev", help="Not available in CLI mode")
@command("clear_screen", help="Not available in CLI mode")
@command("submit_input", help="Not available in CLI mode")
@command("run_tests", help="Not available in CLI mode")
@command("debug_tests", help="Not available in CLI mode")
@command("next_issue", help="Not available in CLI mode")
@command("prev_issue", help="Not available in CLI mode")
@command("rename_symbol", help="Not available in CLI mode")
@command("go_to_definition", help="Not available in CLI mode")
@command("find_references", help="Not available in CLI mode")
@command("prev_file", help="Not available in CLI mode")
@command("next_file", help="Not available in CLI mode")
@command("prev_section", help="Not available in CLI mode")
@command("next_section", help="Not available in CLI mode")
@command("repeat_last_command", help="Not available in CLI mode")
@command("toggle_sidebar", help="Not available in CLI mode")
@command("copy_selection", help="Not available in CLI mode")
@command("paste_clipboard", help="Not available in CLI mode")
def _noop(event: Any = None, **_: Any) -> None:
    print("[oc] Command not available in CLI mode.")


# Trusted folders helpers
@command("trust_status", help="Show trust level for a path")
def trust_status_cmd(path: str = ".") -> str:
    mgr = TrustedFoldersManager()
    lvl = mgr.get_level(path)
    print(lvl.name)
    return lvl.name


@command("trust_set", help="Set trust level for a folder")
def trust_set_cmd(path: str, level: str, persist: bool = True) -> str:
    lvl = TrustLevel[level.upper()]
    TrustedFoldersManager().set_level(path, lvl, persist=bool(persist))
    print(f"Set {path} -> {lvl.name} (persist={persist})")
    return lvl.name
