from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any, Optional

try:
    from rich.console import Console
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.prompt import Prompt
    from rich.live import Live
    from rich.spinner import Spinner
    from rich.text import Text
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False

from .adaptive_builder import AdaptiveConfig, build_adaptive_context
from .context_cache import ContextCache
from .context_strategy import ContextFile


def format_context_simple(files: list[ContextFile], max_files: int = 5) -> str:
    """Format a small selection of context files for chat."""
    parts = []
    for f in files[:max_files]:
        parts.append(f"## {f.path}")
        content = f.content[:2000] if len(f.content) > 2000 else f.content
        parts.append(f"```\n{content}\n```\n")
    return "\n".join(parts)


def _load_relevant_context(root: str, query: str, cache: ContextCache) -> str:
    """Load relevant code context based on user query."""
    query_lower = query.strip().lower()
    
    # Skip loading context for simple greetings or short messages
    if len(query.strip()) < 10 or query_lower in ("hi", "hello", "hey", "thanks", "thank you", "ok", "okay"):
        return ""
    
    # Skip loading context for non-coding questions
    non_coding_keywords = ["weather", "time", "date", "news", "recipe", "joke", "story", "movie", "music", "sports", "politics"]
    if any(keyword in query_lower for keyword in non_coding_keywords):
        return ""
    
    # Check if user mentions specific files
    import re
    file_pattern = r'\b\w+\.(py|js|ts|go|rs|java|cpp|c|h|md|txt|yml|yaml|json|toml)\b'
    mentioned_files = re.findall(file_pattern, query, re.IGNORECASE)
    
    try:
        cfg = AdaptiveConfig(
            root_dir=root,
            query=query,
            mentioned_files=[f[0] + "." + f[1] for f in mentioned_files] if mentioned_files else None,
            model_max_tokens=4000,  # Smaller context for chat
        )
        files, _ = build_adaptive_context(cfg, cache=cache, provider=None)
        return format_context_simple(files, max_files=3) if files else ""
    except Exception:
        return ""


def run_chat(root: str, provider: Any, model: str) -> int:
    """Run interactive chat session with the AI about the codebase."""
    if provider is None:
        print("Error: Provider required. Use --provider ollama or --provider gemini")
        return 1

    # Suppress verbose logging from httpx and other libraries
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)

    if RICH_AVAILABLE:
        return _run_chat_rich(root, provider, model)
    else:
        return _run_chat_plain(root, provider, model)


def _run_chat_rich(root: str, provider: Any, model: str) -> int:
    """Run chat with rich TUI."""
    console = Console()
    
    # Welcome screen
    console.clear()
    welcome = Panel(
        f"[bold cyan]🤖 Ollcoder Chat[/bold cyan]\n\n"
        f"[dim]Model:[/dim] {model}\n"
        f"[dim]Project:[/dim] {root}\n\n"
        f"[yellow]Commands:[/yellow] [bold]exit[/bold], [bold]quit[/bold], or [bold]Ctrl+C[/bold] to quit",
        title="👋 Welcome",
        border_style="cyan",
    )
    console.print(welcome)
    console.print()

    cache = ContextCache(root)
    messages = [
        {"role": "system", "content": (
            "You are a helpful coding assistant. Be conversational and concise.\n"
            "When the user asks about specific files or features, I will provide relevant code context.\n"
            "Only explain code details when asked."
        )},
    ]

    while True:
        try:
            user_input = Prompt.ask("\n[bold green]You[/bold green]", console=console).strip()
        except (EOFError, KeyboardInterrupt):
            console.print("\n[yellow]👋 Goodbye![/yellow]")
            return 0

        if not user_input:
            continue
            
        if user_input.lower() in ("exit", "quit", "q"):
            console.print("\n[yellow]👋 Goodbye![/yellow]")
            return 0

        # Dynamically load context based on user query
        with console.status("[cyan]Loading context...", spinner="dots"):
            relevant_context = _load_relevant_context(root, user_input, cache)
        
        # Add context and user message
        user_message = user_input
        if relevant_context:
            user_message = f"{user_input}\n\n# Relevant Code Context:\n{relevant_context}"
        
        messages.append({"role": "user", "content": user_message})

        try:
            console.print("\n[bold cyan]🤖 Assistant[/bold cyan]", end="")
            console.print()
            
            # Non-streaming response
            with console.status("[cyan]Thinking...", spinner="dots"):
                response = provider.chat(messages, stream=False)
                response_text = _extract_response_text(response)
            
            # Render as markdown for better formatting
            md = Markdown(response_text)
            console.print(md)
            console.print()

            messages.append({"role": "assistant", "content": response_text})

        except Exception as e:
            console.print(f"\n[bold red]❌ Error:[/bold red] {e}\n")
            # Remove the last user message if we failed
            if messages[-1]["role"] == "user":
                messages.pop()

    return 0


def _run_chat_plain(root: str, provider: Any, model: str) -> int:
    """Run chat with plain terminal (fallback when rich not available)."""
    print(f"🤖 Ollcoder Chat (model: {model})")
    print(f"📁 Project: {root}")
    print("💬 Type your message (or 'exit' to quit)\n")

    cache = ContextCache(root)
    messages = [
        {"role": "system", "content": (
            "You are a helpful coding assistant. Be conversational and concise.\n"
            "When the user asks about specific files or features, I will provide relevant code context.\n"
            "Only explain code details when asked."
        )},
    ]

    while True:
        try:
            user_input = input("\nYou: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n👋 Goodbye!")
            return 0

        if not user_input:
            continue
            
        if user_input.lower() in ("exit", "quit", "q"):
            print("\n👋 Goodbye!")
            return 0

        # Dynamically load context
        relevant_context = _load_relevant_context(root, user_input, cache)
        
        user_message = user_input
        if relevant_context:
            user_message = f"{user_input}\n\n# Relevant Code Context:\n{relevant_context}"
        
        messages.append({"role": "user", "content": user_message})

        try:
            print("\n🤖 Assistant:", end=" ")
            response = provider.chat(messages, stream=False)
            response_text = _extract_response_text(response)
            print(response_text + "\n")

            messages.append({"role": "assistant", "content": response_text})

        except Exception as e:
            print(f"\n❌ Error: {e}\n")
            if messages[-1]["role"] == "user":
                messages.pop()

    return 0


def _extract_response_text(resp: Any) -> str:
    """Extract text from provider response."""
    if resp is None:
        return ""
    
    # Ollama returns objects with .message.content attribute
    if hasattr(resp, "message"):
        msg = getattr(resp, "message")
        if msg and hasattr(msg, "content"):
            content = getattr(msg, "content")
            if isinstance(content, str) and content.strip():
                return content
    
    # Gemini style
    txt = getattr(resp, "text", None)
    if isinstance(txt, str) and txt.strip():
        return txt
    
    # Dict style fallback
    if isinstance(resp, dict):
        msg = resp.get("message")
        if isinstance(msg, dict):
            c = msg.get("content")
            if isinstance(c, str) and c.strip():
                return c
        c = resp.get("content")
        if isinstance(c, str) and c.strip():
            return c
    
    return ""


def _extract_chunk_text(chunk: Any) -> str:
    """Extract text from streaming chunk."""
    if isinstance(chunk, dict):
        msg = chunk.get("message", {})
        if isinstance(msg, dict):
            return msg.get("content", "")
        return chunk.get("content", "")
    
    # Gemini streaming chunks
    txt = getattr(chunk, "text", None)
    if isinstance(txt, str):
        return txt
    
    return ""
