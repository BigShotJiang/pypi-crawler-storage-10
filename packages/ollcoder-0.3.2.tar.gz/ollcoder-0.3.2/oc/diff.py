import difflib
from pathlib import Path
from typing import Tuple

from .trusted_folders import global_trust

EXCLUDES = {".git", "node_modules", ".venv", "venv", "dist", "build", "__pycache__"}


def compute_unified_diff(path: str, old_text: str, new_text: str) -> str:
    """Return a unified diff string for display/approval."""
    a_lines = old_text.splitlines(keepends=True)
    b_lines = new_text.splitlines(keepends=True)
    rel = str(Path(path))
    diff = difflib.unified_diff(
        a_lines,
        b_lines,
        fromfile=f"a/{rel}",
        tofile=f"b/{rel}",
        lineterm="",
        n=3,
    )
    return "\n".join(diff)


def apply_new_content(path: str, expected_old: str, new_text: str) -> Tuple[bool, str]:
    """Safely write new_text to path if file still matches expected_old.
    Returns (success, message).
    """
    p = Path(path)
    # Enforce trust policy for write
    if not global_trust().ensure_allowed(str(p), "write"):
        return False, "Access denied by trust policy"

    p.parent.mkdir(parents=True, exist_ok=True)

    current = ""
    if p.exists():
        current = p.read_text()
    # If file changed since we computed the diff, abort to avoid clobbering
    if current != expected_old:
        return False, "File changed on disk since diff was computed; aborting."

    p.write_text(new_text)
    return True, "Applied new content."
