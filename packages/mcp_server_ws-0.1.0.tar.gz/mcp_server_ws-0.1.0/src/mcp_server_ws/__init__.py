from .server import serve


def main():
    """MCP WS Server - WS for MCP"""
    import asyncio

    asyncio.run(serve())


if __name__ == "__main__":
    main()