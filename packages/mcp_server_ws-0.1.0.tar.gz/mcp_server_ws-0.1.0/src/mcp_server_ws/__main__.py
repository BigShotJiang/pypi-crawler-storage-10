from mcp_server_ws import main

main()