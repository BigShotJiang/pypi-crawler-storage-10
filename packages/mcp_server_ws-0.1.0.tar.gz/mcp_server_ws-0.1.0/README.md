version = 1
requires-python = ">=3.10"

將 config.json 添加以下內容：
```bash
        "ws": {
            "command": "uvx",
            "args": [
                "mcp-server-ws"
            ]
        },
```

接著使用llm時
只要"有請求查詢ws卡牌的意圖" 即會自動觸發本爬蟲功能