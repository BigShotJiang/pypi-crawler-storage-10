#!/bin/bash

set -e

git --version
echo "git is installed and working"
