# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import Literal, Required, TypedDict

from .._types import SequenceNotStr

__all__ = ["DBRecommendParams"]


class DBRecommendParams(TypedDict, total=False):
    table: Required[str]
    """Table to generate recommendations from"""

    environment: Literal["development", "staging", "production"]
    """Environment to search in (development, staging, production)"""

    exclude_ids: SequenceNotStr[str]
    """Record IDs to exclude from recommendations"""

    limit: float
    """Maximum number of recommendations to return"""

    record_id: Union[str, float]
    """Source item ID for item-to-item recommendations"""

    strategy: Literal["similar", "diverse", "popular"]
    """Recommendation strategy to use"""

    user_history: SequenceNotStr[str]
    """Array of record IDs the user has interacted with"""
