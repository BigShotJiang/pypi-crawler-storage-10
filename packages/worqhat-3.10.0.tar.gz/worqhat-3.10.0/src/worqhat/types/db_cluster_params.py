# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

__all__ = ["DBClusterParams"]


class DBClusterParams(TypedDict, total=False):
    table: Required[str]
    """Table to cluster"""

    environment: Literal["development", "staging", "production"]
    """Environment to cluster (development, staging, production)"""

    generate_labels: bool
    """Whether to generate AI labels for clusters"""

    max_clusters: float
    """Maximum clusters for auto-detection"""

    min_clusters: float
    """Minimum clusters for auto-detection"""

    num_clusters: float
    """Number of clusters (auto-detected if not provided)"""
