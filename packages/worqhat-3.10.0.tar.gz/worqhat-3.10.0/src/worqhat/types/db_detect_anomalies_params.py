# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

__all__ = ["DBDetectAnomaliesParams"]


class DBDetectAnomaliesParams(TypedDict, total=False):
    table: Required[str]
    """Table to analyze for anomalies"""

    environment: Literal["development", "staging", "production"]
    """Environment to analyze (development, staging, production)"""

    k: float
    """Number of nearest neighbors to consider"""

    limit: float
    """Maximum number of anomalies to return"""

    threshold: float
    """Minimum anomaly score threshold"""
