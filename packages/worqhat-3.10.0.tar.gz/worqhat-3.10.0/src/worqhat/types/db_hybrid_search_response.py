# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["DBHybridSearchResponse", "Result", "Result_Meta", "Result_MetaWeights"]


class Result_MetaWeights(BaseModel):
    keyword: Optional[float] = None

    semantic: Optional[float] = None


class Result_Meta(BaseModel):
    search_type: Optional[str] = None

    weights: Optional[Result_MetaWeights] = None


class Result(BaseModel):
    api_meta: Optional[Result_Meta] = FieldInfo(alias="_meta", default=None)

    combined_score: Optional[float] = None
    """Combined semantic + keyword score"""

    keyword_score: Optional[float] = None
    """Keyword matching score"""

    record: Optional[Dict[str, object]] = None

    semantic_score: Optional[float] = None
    """Semantic similarity score"""


class DBHybridSearchResponse(BaseModel):
    execution_time: Optional[float] = FieldInfo(alias="executionTime", default=None)
    """Search execution time in milliseconds"""

    query_embedding_preview: Optional[List[float]] = None
    """First 5 dimensions of the query embedding"""

    results: Optional[List[Result]] = None

    success: Optional[bool] = None
