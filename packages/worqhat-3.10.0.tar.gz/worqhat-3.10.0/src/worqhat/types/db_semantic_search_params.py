# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Literal, Required, TypedDict

from .._types import SequenceNotStr

__all__ = ["DBSemanticSearchParams"]


class DBSemanticSearchParams(TypedDict, total=False):
    query: Required[str]
    """Natural language search query"""

    environment: Literal["development", "staging", "production"]
    """Environment to search in (development, staging, production)"""

    filters: Dict[str, object]
    """Additional WHERE conditions to apply"""

    limit: float
    """Maximum number of results to return"""

    table: str
    """Single table to search in (optional if tables is provided)"""

    tables: SequenceNotStr[str]
    """Multiple tables to search across (optional if table is provided)"""

    threshold: float
    """Minimum similarity score threshold"""
