# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import Literal, Required, TypedDict

__all__ = ["DBFindSimilarParams"]


class DBFindSimilarParams(TypedDict, total=False):
    record_id: Required[Union[str, float]]
    """ID of the source record"""

    table: Required[str]
    """Table containing the source record"""

    environment: Literal["development", "staging", "production"]
    """Environment to search in (development, staging, production)"""

    exclude_self: bool
    """Whether to exclude the source record from results"""

    limit: float
    """Maximum number of similar records to return"""

    target_table: str
    """Different table to search in (optional)"""

    threshold: float
    """Minimum similarity score threshold"""
