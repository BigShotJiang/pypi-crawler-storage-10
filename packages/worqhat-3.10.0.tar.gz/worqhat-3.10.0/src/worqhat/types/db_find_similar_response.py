# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["DBFindSimilarResponse", "SimilarRecord"]


class SimilarRecord(BaseModel):
    record: Optional[Dict[str, object]] = None

    similarity: Optional[float] = None
    """Similarity score (0-1)"""

    table: Optional[str] = None


class DBFindSimilarResponse(BaseModel):
    execution_time: Optional[float] = FieldInfo(alias="executionTime", default=None)
    """Search execution time in milliseconds"""

    similar_records: Optional[List[SimilarRecord]] = None

    source_record: Optional[Dict[str, object]] = None
    """The original record used for similarity search"""

    success: Optional[bool] = None
