# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["DBClusterResponse", "Cluster"]


class Cluster(BaseModel):
    id: Optional[float] = None
    """Cluster ID"""

    centroid: Optional[List[float]] = None
    """Cluster center embedding (first 10 dimensions)"""

    label: Optional[str] = None
    """AI-generated cluster description"""

    sample_records: Optional[List[Dict[str, object]]] = None
    """3-5 representative records from cluster"""

    size: Optional[float] = None
    """Number of records in cluster"""


class DBClusterResponse(BaseModel):
    clusters: Optional[List[Cluster]] = None

    execution_time: Optional[float] = FieldInfo(alias="executionTime", default=None)
    """Clustering execution time in milliseconds"""

    iterations: Optional[float] = None
    """Number of K-means iterations performed"""

    optimal_k: Optional[float] = None
    """Determined optimal cluster count"""

    silhouette_score: Optional[float] = None
    """Clustering quality metric (0-1)"""

    success: Optional[bool] = None
