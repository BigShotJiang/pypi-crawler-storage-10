# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["DBSemanticSearchResponse", "Result", "Result_Meta"]


class Result_Meta(BaseModel):
    matched_fields: Optional[List[str]] = None


class Result(BaseModel):
    api_meta: Optional[Result_Meta] = FieldInfo(alias="_meta", default=None)

    record: Optional[Dict[str, object]] = None

    similarity: Optional[float] = None
    """Similarity score (0-1)"""

    table: Optional[str] = None


class DBSemanticSearchResponse(BaseModel):
    execution_time: Optional[float] = FieldInfo(alias="executionTime", default=None)
    """Search execution time in milliseconds"""

    query_embedding_preview: Optional[List[float]] = None
    """First 5 dimensions of the query embedding"""

    results: Optional[List[Result]] = None

    success: Optional[bool] = None
