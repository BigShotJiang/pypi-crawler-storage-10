# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["DBDetectAnomaliesResponse", "Anomaly", "AnomalyNearestNeighbor", "Parameters"]


class AnomalyNearestNeighbor(BaseModel):
    distance: Optional[float] = None

    record: Optional[Dict[str, object]] = None


class Anomaly(BaseModel):
    anomaly_score: Optional[float] = None
    """Anomaly score (0-1, higher = more unusual)"""

    avg_distance: Optional[float] = None
    """Average distance to K nearest neighbors"""

    nearest_neighbors: Optional[List[AnomalyNearestNeighbor]] = None

    record: Optional[Dict[str, object]] = None


class Parameters(BaseModel):
    k: Optional[float] = None

    threshold: Optional[float] = None


class DBDetectAnomaliesResponse(BaseModel):
    anomalies: Optional[List[Anomaly]] = None

    anomaly_count: Optional[float] = None
    """Number of anomalies detected"""

    execution_time: Optional[float] = FieldInfo(alias="executionTime", default=None)
    """Analysis execution time in milliseconds"""

    parameters: Optional[Parameters] = None

    success: Optional[bool] = None

    total_records: Optional[float] = None
    """Total number of records analyzed"""
