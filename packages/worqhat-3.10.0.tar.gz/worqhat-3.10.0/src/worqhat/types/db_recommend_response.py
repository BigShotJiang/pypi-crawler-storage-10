# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["DBRecommendResponse", "Recommendation", "Recommendation_Meta"]


class Recommendation_Meta(BaseModel):
    source: Optional[str] = None

    strategy: Optional[str] = None


class Recommendation(BaseModel):
    api_meta: Optional[Recommendation_Meta] = FieldInfo(alias="_meta", default=None)

    record: Optional[Dict[str, object]] = None

    similarity: Optional[float] = None
    """Similarity score (0-1)"""


class DBRecommendResponse(BaseModel):
    execution_time: Optional[float] = FieldInfo(alias="executionTime", default=None)
    """Recommendation generation time in milliseconds"""

    recommendations: Optional[List[Recommendation]] = None

    strategy: Optional[str] = None
    """Strategy used for recommendations"""

    success: Optional[bool] = None
