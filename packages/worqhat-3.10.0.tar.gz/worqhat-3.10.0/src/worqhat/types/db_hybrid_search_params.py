# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

from .._types import SequenceNotStr

__all__ = ["DBHybridSearchParams"]


class DBHybridSearchParams(TypedDict, total=False):
    query: Required[str]
    """Search query combining natural language and keywords"""

    table: Required[str]
    """Table to search in"""

    environment: Literal["development", "staging", "production"]
    """Environment to search in (development, staging, production)"""

    keyword_weight: float
    """Weight for keyword matching score"""

    limit: float
    """Maximum number of results to return"""

    semantic_weight: float
    """Weight for semantic similarity score"""

    text_columns: SequenceNotStr[str]
    """Columns to include in keyword search"""
