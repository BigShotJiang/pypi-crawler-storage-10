"""Test helpers shipped with the SpiralTorch Python package."""
