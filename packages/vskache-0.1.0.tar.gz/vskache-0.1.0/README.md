# VSKache

Personal disk-cache package for my research projects

## Installation

You can install VSKache using pip:

```bash
pip install vskache
```
