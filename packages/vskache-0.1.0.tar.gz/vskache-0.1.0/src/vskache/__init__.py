from vskache.cache import Cache

__all__ = ["Cache"]

def main() -> None:
    print("Hello from vskache!")
