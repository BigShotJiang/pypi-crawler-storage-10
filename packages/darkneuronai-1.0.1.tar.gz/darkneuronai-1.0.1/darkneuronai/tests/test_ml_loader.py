"""
===========================================================
 Test - ML Loader
===========================================================
"""

# ---------------- IMPORTS ----------------
from darkneuronai.core.ml_loader import DarkNeuronML

def test_ml_model_loading():
    try:
        model = DarkNeuronML("darkneuron-spamdex-v1")  # auto adds .pkl
        model.load_model()
        print("✅ ML model loaded successfully")
    except FileNotFoundError:
        print("⚠️ Test skipped - model file not found (expected for first run)")

test_ml_model_loading()