"""
===========================================================
 Test - LLM Loader
===========================================================
"""

# ---------------- IMPORTS ----------------
from core.llm_loader import DarkNeuronLLM

def test_llm_init():
    model = DarkNeuronLLM("DarkNeuronAI/darkneuron-chat-v1.1")
    print("✅ LLM class initialized successfully")

test_llm_init