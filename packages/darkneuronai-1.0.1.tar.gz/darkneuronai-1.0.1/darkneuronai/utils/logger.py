"""
===========================================================
 Simple Colored Logger
===========================================================
"""

# ---------------- IMPORTS ----------------
from datetime import datetime

# ---------------- LOGGER CLASS ----------------
class Logger:
    COLORS = {
        "INFO": "\033[94m",
        "WARN": "\033[93m",
        "ERROR": "\033[91m",
        "END": "\033[0m"
    }

    @staticmethod
    def log(level, message):
        color = Logger.COLORS.get(level, "")
        end = Logger.COLORS["END"]
        print(f"{color}[{level}] {datetime.now().strftime('%H:%M:%S')} → {message}{end}")

    @staticmethod
    def info(msg): Logger.log("INFO", msg)
    @staticmethod
    def warn(msg): Logger.log("WARN", msg)
    @staticmethod
    def error(msg): Logger.log("ERROR", msg)