"""
===========================================================
 Device Detection Utility
===========================================================
"""

# ---------------- IMPORTS ----------------
import torch

# ---------------- FUNCTION ----------------
def get_device():
    if torch.cuda.is_available():
        return "cuda"
    elif torch.backends.mps.is_available():
        return "mps"
    return "cpu"