"""
===========================================================
 Base Abstract Model Class
===========================================================
"""

# ---------------- IMPORTS ----------------
from abc import ABC, abstractmethod

# ---------------- BASE MODEL ----------------
class BaseModel(ABC):
    """Defines the base structure for all models."""

    @abstractmethod
    def load_model(self):
        """Load the model."""
        pass

    @abstractmethod
    def predict(self, input_data):
        """Run inference."""
        pass