# Codding Assistants

The modules in here were designed in order to automatically generate boiler plate code. They are an absolute dogs and birds implementation (rough rough, cheap cheap) and probably a nightmare to understand or maintain for other people than the author.

You are probably best advised to kick them out (just delete the folder and all calls in the cmake lists) and edit the generated code by hand, like you would have to in any other C++ project. 