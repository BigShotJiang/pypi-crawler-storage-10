
#pragma once

#include "common.h"

string wrapHtml(const string& json);