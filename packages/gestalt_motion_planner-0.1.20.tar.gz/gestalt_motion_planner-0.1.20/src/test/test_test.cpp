
#include "test_main.h"

TEST(test_test, addition){
	EXPECT_EQ(1 + 2, 3);
}

TEST_MAIN
