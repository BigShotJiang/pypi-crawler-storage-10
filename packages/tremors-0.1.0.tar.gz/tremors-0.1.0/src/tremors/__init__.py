"""The main package."""

__authors__ = ["Narvin Singh"]
__project__ = "Tremors"
__version__ = "0.1.0"
