"""The main module."""

import functools
import itertools
import logging
import sys
from typing import TYPE_CHECKING, Any, NamedTuple, Self

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable, Mapping
    from types import TracebackType


class Collector[TState](NamedTuple):
    """A metrics collector specification."""

    name: str
    level: int
    state: TState
    collect: Callable[[TState], TState]


def _collectors_reducer[T](
    acc: tuple[Mapping[str, Collector[T]], Mapping[str, T]],
    curr: tuple[int, tuple[str, Collector[T]]],
) -> tuple[Mapping[str, Collector[T]], Mapping[str, T]]:
    acc_x, acc_extra = acc
    level, (name, curr_c) = curr
    if level >= curr_c.level:
        state = curr_c.collect(curr_c.state)
        new_extra = {**acc_extra, name: state} if level >= curr_c.level else {}
    return {**acc_x, name: Collector(curr_c.name, curr_c.level, state, curr_c.collect)}, new_extra


_EXTRA_KEY = "tremors"


class Logger(logging.LoggerAdapter[logging.Logger]):
    """A logger context manager."""

    def __init__(
        self, name: str, *, collectors: Iterable[Collector[Any]], ctx_level: int = logging.INFO
    ) -> None:
        """Initialize the context"""
        super().__init__(logging.getLogger(__name__))
        self._name = name
        self._collectors: Mapping[str, Collector[Any]] = {c.name: c for c in collectors}
        self._ctx_level = ctx_level

    def log(  # noqa: PLR0913
        self,
        level: int,
        msg: object,
        *args: object,
        exc_info: bool
        | tuple[type[BaseException], BaseException, TracebackType | None]
        | tuple[None, None, None]
        | BaseException
        | None = None,
        stack_info: bool = False,
        stacklevel: int = 1,
        extra: Mapping[str, object] | None = None,
        **kwargs: object,
    ) -> None:
        """Log a message at the given level."""
        initial_x: Mapping[str, Collector[Any]] = {}
        initial_extra: Mapping[str, Any] = {}
        self._collectors, own_extra = functools.reduce(
            _collectors_reducer,
            zip(itertools.repeat(level), self._collectors.items(), strict=False),
            (initial_x, initial_extra),
        )
        return self.logger.log(
            level,
            msg,
            *args,
            exc_info=exc_info,
            stack_info=stack_info,
            stacklevel=stacklevel,
            extra={**extra, _EXTRA_KEY: own_extra}
            if extra is not None
            else {_EXTRA_KEY: own_extra},
            **kwargs,
        )

    def __enter__(self) -> Self:
        """Enter the context."""
        self.log(self._ctx_level, "entered: %s", self._name)
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit the context."""
        exc_info = (exc_type, exc_val, exc_tb) if exc_type and exc_val else None
        self.log(self._ctx_level, "exited: %s", self._name, exc_info=exc_info)


class SimpleFormatter(logging.Formatter):
    """A simple tremors formatter."""

    def format(self, record: logging.LogRecord) -> str:
        """Format the message with tremors extras."""
        s = []

        extra = getattr(record, _EXTRA_KEY, None)
        if extra:
            counter = extra.get("counter")
            if counter is not None:
                s.append(f"counter={counter}")
            elapsed = extra.get("elapsed")
            if elapsed:
                t0, t = elapsed.get("t0"), elapsed.get("t")
                if t0 is not None and t is not None:
                    s.append(f"elapsed={(t - t0) / 1e9:.4f}")

        return f"{super().format(record)} {{{', '.join(s)}}}" if s else super().format(record)


class SimpleHandler(logging.Handler):
    """A simple tremors handler."""

    def __init__(self, level: int = logging.NOTSET) -> None:
        """Initialize the handler."""
        super().__init__(level)

    def emit(self, record: logging.LogRecord) -> None:
        """Emit the record."""
        s = self.format(record)
        sys.stdout.write(f"{s}\n")


if __name__ == "__main__":
    import time

    def _collect_elapsed(state: dict[str, int]) -> dict[str, int]:
        t = time.perf_counter_ns()
        return {"t0": state.get("t0", t), "t": t}

    handler = SimpleHandler()
    handler.setFormatter(SimpleFormatter("> %(message)s"))
    logging.basicConfig(level=logging.DEBUG, handlers=(handler,))
    counter_collector = Collector(
        name="counter", level=logging.INFO, state=0, collect=lambda s: s + 1
    )
    elapsed_collector: Collector[dict[str, int]] = Collector(
        name="elapsed", level=logging.INFO, state={}, collect=_collect_elapsed
    )
    with Logger("main", collectors=(counter_collector, elapsed_collector)) as logger:
        logger.info("hello")
        time.sleep(1)
