from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktf as _cdktf_9a9027ec
import constructs as _constructs_77d1e7e8


class AssertionReturn(
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.testing.AssertionReturn",
):
    def __init__(self, message: builtins.str, success: builtins.bool) -> None:
        '''Create an AssertionReturn.

        :param message: - String message containing information about the result of the assertion.
        :param success: - Boolean success denoting the success of the assertion.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e4424adf816304584e5b49191f3cf234782616e3cc6563fc4d46eab3dc232f7d)
            check_type(argname="argument message", value=message, expected_type=type_hints["message"])
            check_type(argname="argument success", value=success, expected_type=type_hints["success"])
        jsii.create(self.__class__, self, [message, success])

    @builtins.property
    @jsii.member(jsii_name="message")
    def message(self) -> builtins.str:
        '''- String message containing information about the result of the assertion.'''
        return typing.cast(builtins.str, jsii.get(self, "message"))

    @builtins.property
    @jsii.member(jsii_name="success")
    def success(self) -> builtins.bool:
        '''- Boolean success denoting the success of the assertion.'''
        return typing.cast(builtins.bool, jsii.get(self, "success"))


class BaseTestStack(
    _cdktf_9a9027ec.TerraformStack,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.testing.BaseTestStack",
):
    def __init__(self, scope: _constructs_77d1e7e8.Construct, id: builtins.str) -> None:
        '''
        :param scope: -
        :param id: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e5dbe190b3ce570f12d2c3aef73e3a9e9fbe5270f5747b04f53197ce21f2cd43)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        jsii.create(self.__class__, self, [scope, id])

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))


__all__ = [
    "AssertionReturn",
    "BaseTestStack",
]

publication.publish()

def _typecheckingstub__e4424adf816304584e5b49191f3cf234782616e3cc6563fc4d46eab3dc232f7d(
    message: builtins.str,
    success: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e5dbe190b3ce570f12d2c3aef73e3a9e9fbe5270f5747b04f53197ce21f2cd43(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
) -> None:
    """Type checking stubs"""
    pass
