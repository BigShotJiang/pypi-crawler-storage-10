r'''
# Azure Terraform CDK Constructs

Welcome to the Azure Terraform CDK Constructs project! This library offers Azure L2 Constructs using the AZAPI provider for direct Azure REST API access, providing immediate access to new Azure features and API versions.

## 🚀 Version 1.0.0 - AZAPI Provider Migration

**Breaking Change Notice:** Version 1.0.0 represents a major architectural shift from AzureRM provider to AZAPI provider. This migration provides:

* **Direct Azure REST API Access**: No dependency on AzureRM provider
* **Immediate Feature Access**: Get new Azure features as soon as they're available in Azure APIs
* **Version-Specific Implementations**: Multiple API versions supported for each service
* **Enhanced Type Safety**: Improved IDE support and compile-time validation
* **Included Provider Bindings**: AZAPI provider classes are included - no need to generate bindings

## Benefits of Using AZAPI L2 Constructs

With AZAPI L2 Constructs, you get the following benefits:

* **Direct API Access**: Bypass provider limitations and access Azure REST APIs directly
* **Version Flexibility**: Choose specific API versions for your resources
* **Rapid Feature Adoption**: Access new Azure features immediately without waiting for provider updates
* **Enhanced Abstraction**: Higher-level abstractions over Azure resources with type safety
* **Reusability**: Encapsulate common patterns and best practices in your infrastructure code
* **Direct IDE Integration**: Access detailed documentation directly within your IDE
* **Zero Provider Setup**: AZAPI provider bindings included in the package

## Currently Supported Services

| Service | API Versions | Status |
|---------|-------------|--------|
| Resource Groups | 2024-11-01, 2025-01-01, 2025-03-01 | ✅ Available |
| Storage Accounts | 2023-01-01, 2023-05-01, 2024-01-01 | ✅ Available |

*More services will be added in future releases using the same AZAPI architecture.*

## Quick Example

Create Azure resources using AZAPI provider:

```python
import * as azcdk from "@microsoft/terraform-cdk-constructs";
import { Construct } from 'constructs';
import { App, TerraformStack } from 'cdktf';

class AzureAppInfra extends TerraformStack {
  constructor(scope: Construct, name: string) {
    super(scope, name);

    // Create a new Azure Resource Group using AZAPI
    const rg = new azcdk.azure_resourcegroup.ResourceGroup(this, "resourcegroup", {
      name: "rg-myapp-prod",
      location: "eastus",
      tags: {
        environment: "production",
        project: "myapp"
      }
    });

    // Create a Storage Account
    new azcdk.azure_storageaccount.StorageAccount(this, "storage", {
      name: "mystorageaccount",
      location: "eastus",
      resourceGroupId: rg.id,
      sku: { name: "Standard_LRS" }
    });
  }
}

const app = new App();
new AzureAppInfra(app, 'cdk');
app.synth();
```

## Getting Started

### Prerequisites

* Node.js and npm installed (for TypeScript/JavaScript)
* Azure CLI configured with appropriate permissions

### Installation

Install the CDK for Terraform CLI globally:

```sh
npm install -g cdktf-cli
```

Initialize a new CDK for Terraform project:

```sh
cdktf init --template="TypeScript" --local
```

Install the Microsoft Terraform CDK constructs (includes AZAPI provider bindings):

```sh
npm install @microsoft/terraform-cdk-constructs
```

That's it! The AZAPI provider classes are included in the package, so you don't need to configure additional providers or generate bindings.

### Basic Usage Example

```python
import * as azcdk from "@microsoft/terraform-cdk-constructs";
import { Construct } from 'constructs';
import { App, TerraformStack } from 'cdktf';

class MyAzureInfra extends TerraformStack {
  constructor(scope: Construct, name: string) {
    super(scope, name);

    // Create a resource group
    const rg = new azcdk.azure_resourcegroup.ResourceGroup(this, "main-rg", {
      name: "rg-myproject-prod",
      location: "eastus",
      tags: {
        environment: "production",
        project: "myproject"
      }
    });

    // Create a storage account
    const storage = new azcdk.azure_storageaccount.StorageAccount(this, "storage", {
      name: "mystorageaccount",
      location: "eastus",
      resourceGroupId: rg.id,
      sku: { name: "Standard_LRS" },
      tags: {
        environment: "production",
        project: "myproject"
      }
    });
  }
}

const app = new App();
new MyAzureInfra(app, 'azure-infra');
app.synth();
```

## Version-Specific Usage

You can use specific API versions for fine-grained control:

```python
// Use latest version (recommended) - automatically resolves to newest API version
import { ResourceGroup } from "@microsoft/terraform-cdk-constructs/azure-resourcegroup";
import { StorageAccount } from "@microsoft/terraform-cdk-constructs/azure-storageaccount";

// Or specify explicit API version for version pinning
const rg = new ResourceGroup(this, "rg", {
  name: "my-resource-group",
  location: "eastus",
  apiVersion: "2025-03-01"  // Pin to specific version
});

const storage = new StorageAccount(this, "storage", {
  name: "mystorageaccount",
  location: "eastus",
  resourceGroupId: rg.id,
  sku: { name: "Standard_LRS" },
  apiVersion: "2024-01-01"  // Pin to specific version
});
```

## Migration from v0.x

If you're migrating from version 0.x (AzureRM-based), please see our [Versioning and Migrations User Guide](./docs/versioning-and-migrations-user-guide.md) for detailed instructions.

## Deployment

Generate Terraform configuration:

```sh
cdktf synth
```

Deploy your infrastructure:

```sh
cdktf deploy
```

## Supported Languages

Thanks to JSII, this library is available in multiple programming languages:

| Language   | Package | Status |
|------------|---------|--------|
| TypeScript/JavaScript | [`@microsoft/terraform-cdk-constructs`](https://www.npmjs.com/package/@microsoft/terraform-cdk-constructs) | ✅ Available |
| Python     | [`microsoft-cdktfconstructs`](https://pypi.org/project/microsoft-cdktfconstructs/) | ✅ Available |
| Java       | [`com.microsoft.terraformcdkconstructs`](https://search.maven.org/artifact/com.microsoft.terraformcdkconstructs/cdktf-azure-constructs) | ✅ Available |
| C#/.NET    | [`Microsoft.Cdktf.Azure.TFConstructs`](https://www.nuget.org/packages/Microsoft.Cdktf.Azure.TFConstructs) | ✅ Available |

## Contributing

This project welcomes contributions and suggestions. Most contributions require you to agree to a
Contributor License Agreement (CLA) declaring that you have the right to, and actually do, grant us
the rights to use your contribution. For details, visit https://cla.opensource.microsoft.com.

When you submit a pull request, a CLA bot will automatically determine whether you need to provide
a CLA and decorate the PR appropriately (e.g., status check, comment). Simply follow the instructions
provided by the bot. You will only need to do this once across all repos using our CLA.

This project has adopted the [Microsoft Open Source Code of Conduct](https://opensource.microsoft.com/codeofconduct/).
For more information see the [Code of Conduct FAQ](https://opensource.microsoft.com/codeofconduct/faq/) or
contact [opencode@microsoft.com](mailto:opencode@microsoft.com) with any additional questions or comments.

We welcome contributions to this project! See our documentation on [how to get started contributing](./CONTRIBUTING.md).

## Documentation

* [Architecture Documentation](./docs/ARCHITECTURE.md) - High-level architecture and design patterns
* [Versioning and Migrations User Guide](./docs/versioning-and-migrations-user-guide.md) - API version management and migration guidance
* [Testing Guide](./docs/testing.md) - Testing practices and utilities
* [Design Guide](./docs/design_guide.md) - Module design guidelines
* [API Documentation](./API.md) - Complete API reference

## Code Spaces

[![Open in GitHub Codespaces](https://img.shields.io/badge/Open%20in%20GitHub%20Codespaces-blue?logo=github)](https://github.com/Azure/terraform-cdk-constructs/codespaces)

## Trademarks

This project may contain trademarks or logos for projects, products, or services. Authorized use of Microsoft
trademarks or logos is subject to and must follow
[Microsoft's Trademark & Brand Guidelines](https://www.microsoft.com/en-us/legal/intellectualproperty/trademarks/usage/general).
Use of Microsoft trademarks or logos in modified versions of this project must not cause confusion or imply Microsoft sponsorship.
Any use of third-party trademarks or logos are subject to those third-party's policies.
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ._jsii import *

import cdktf as _cdktf_9a9027ec
import constructs as _constructs_77d1e7e8
from .azure_storageaccount import (
    StorageAccountBodyProperties as _StorageAccountBodyProperties_4d550b33,
    StorageAccountEncryption as _StorageAccountEncryption_77d27837,
    StorageAccountEncryptionService as _StorageAccountEncryptionService_aaadb7be,
    StorageAccountEncryptionServices as _StorageAccountEncryptionServices_8a1bf271,
    StorageAccountIdentity as _StorageAccountIdentity_d6b6a344,
    StorageAccountIpRule as _StorageAccountIpRule_83a6da4e,
    StorageAccountNetworkAcls as _StorageAccountNetworkAcls_768fda36,
    StorageAccountProps as _StorageAccountProps_0b7b5bac,
    StorageAccountSku as _StorageAccountSku_fa953b33,
    StorageAccountVirtualNetworkRule as _StorageAccountVirtualNetworkRule_825a3860,
)
from .core_azure import (
    ApiSchema as _ApiSchema_5ce0490e,
    ApiVersionManager as _ApiVersionManager_76b80279,
    AzapiDiagnosticSettings as _AzapiDiagnosticSettings_4f8e56d3,
    AzapiDiagnosticSettingsProps as _AzapiDiagnosticSettingsProps_b5c36ed5,
    AzapiResource as _AzapiResource_7e7f5b39,
    AzapiResourceProps as _AzapiResourceProps_141a2340,
    AzapiRoleAssignmentProps as _AzapiRoleAssignmentProps_d153e00c,
    BreakingChange as _BreakingChange_5dc94c31,
    DiagnosticLogConfig as _DiagnosticLogConfig_990fcbff,
    DiagnosticMetricConfig as _DiagnosticMetricConfig_29c0add1,
    MigrationAnalysis as _MigrationAnalysis_aa719f40,
    PropertyDefinition as _PropertyDefinition_2a5c46ac,
    PropertyTransformer as _PropertyTransformer_9b876b7f,
    PropertyValidation as _PropertyValidation_bb241cd7,
    RetentionPolicyConfig as _RetentionPolicyConfig_13c42ec6,
    SchemaMapper as _SchemaMapper_cf4ebcd7,
    ValidationResult as _ValidationResult_87269226,
    ValidationRule as _ValidationRule_f1913ed6,
    VersionChangeLog as _VersionChangeLog_3bfd366b,
    VersionConfig as _VersionConfig_ddf991d0,
    VersionLifecycle as _VersionLifecycle_d648b2ea,
)


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.ApiSchema",
    jsii_struct_bases=[],
    name_mapping={
        "properties": "properties",
        "required": "required",
        "resource_type": "resourceType",
        "version": "version",
        "deprecated": "deprecated",
        "optional": "optional",
        "transformation_rules": "transformationRules",
        "validation_rules": "validationRules",
    },
)
class ApiSchema:
    def __init__(
        self,
        *,
        properties: typing.Mapping[builtins.str, typing.Union[_PropertyDefinition_2a5c46ac, typing.Dict[builtins.str, typing.Any]]],
        required: typing.Sequence[builtins.str],
        resource_type: builtins.str,
        version: builtins.str,
        deprecated: typing.Optional[typing.Sequence[builtins.str]] = None,
        optional: typing.Optional[typing.Sequence[builtins.str]] = None,
        transformation_rules: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        validation_rules: typing.Optional[typing.Sequence[typing.Union[_PropertyValidation_bb241cd7, typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> None:
        '''API Schema definition using TypeScript objects.

        Defines the complete schema for an API version including all properties,
        validation rules, and transformation mappings. This schema-driven approach
        enables automatic validation, transformation, and multi-language support.

        :param properties: Dictionary of property definitions keyed by property name Each property defines its type, validation, and metadata.
        :param required: Array of property names that are required Properties listed here must be provided by the user.
        :param resource_type: The Azure resource type this schema applies to.
        :param version: The API version this schema represents.
        :param deprecated: Array of property names that are deprecated Usage of these properties will generate warnings.
        :param optional: Array of property names that are optional Used for documentation and validation optimization.
        :param transformation_rules: Property transformation rules for schema mapping Maps input property names to target property names.
        :param validation_rules: Property-specific validation rules Applied in addition to individual property validation.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__12fabbb87f64a0ee51c6e5006ff938a67747ed83b3a25fa560ecafd1b8899108)
            check_type(argname="argument properties", value=properties, expected_type=type_hints["properties"])
            check_type(argname="argument required", value=required, expected_type=type_hints["required"])
            check_type(argname="argument resource_type", value=resource_type, expected_type=type_hints["resource_type"])
            check_type(argname="argument version", value=version, expected_type=type_hints["version"])
            check_type(argname="argument deprecated", value=deprecated, expected_type=type_hints["deprecated"])
            check_type(argname="argument optional", value=optional, expected_type=type_hints["optional"])
            check_type(argname="argument transformation_rules", value=transformation_rules, expected_type=type_hints["transformation_rules"])
            check_type(argname="argument validation_rules", value=validation_rules, expected_type=type_hints["validation_rules"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "properties": properties,
            "required": required,
            "resource_type": resource_type,
            "version": version,
        }
        if deprecated is not None:
            self._values["deprecated"] = deprecated
        if optional is not None:
            self._values["optional"] = optional
        if transformation_rules is not None:
            self._values["transformation_rules"] = transformation_rules
        if validation_rules is not None:
            self._values["validation_rules"] = validation_rules

    @builtins.property
    def properties(self) -> typing.Mapping[builtins.str, _PropertyDefinition_2a5c46ac]:
        '''Dictionary of property definitions keyed by property name Each property defines its type, validation, and metadata.

        Example::

            { "location": { type: "string", required: true } }
        '''
        result = self._values.get("properties")
        assert result is not None, "Required property 'properties' is missing"
        return typing.cast(typing.Mapping[builtins.str, _PropertyDefinition_2a5c46ac], result)

    @builtins.property
    def required(self) -> typing.List[builtins.str]:
        '''Array of property names that are required Properties listed here must be provided by the user.'''
        result = self._values.get("required")
        assert result is not None, "Required property 'required' is missing"
        return typing.cast(typing.List[builtins.str], result)

    @builtins.property
    def resource_type(self) -> builtins.str:
        '''The Azure resource type this schema applies to.

        Example::

            "Microsoft.Resources/resourceGroups"
        '''
        result = self._values.get("resource_type")
        assert result is not None, "Required property 'resource_type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def version(self) -> builtins.str:
        '''The API version this schema represents.

        Example::

            "2024-11-01"
        '''
        result = self._values.get("version")
        assert result is not None, "Required property 'version' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def deprecated(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Array of property names that are deprecated Usage of these properties will generate warnings.'''
        result = self._values.get("deprecated")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def optional(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Array of property names that are optional Used for documentation and validation optimization.'''
        result = self._values.get("optional")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def transformation_rules(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Property transformation rules for schema mapping Maps input property names to target property names.

        Example::

            { "oldName": "newName" }
        '''
        result = self._values.get("transformation_rules")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def validation_rules(
        self,
    ) -> typing.Optional[typing.List[_PropertyValidation_bb241cd7]]:
        '''Property-specific validation rules Applied in addition to individual property validation.'''
        result = self._values.get("validation_rules")
        return typing.cast(typing.Optional[typing.List[_PropertyValidation_bb241cd7]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ApiSchema(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ApiVersionManager(
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.ApiVersionManager",
):
    '''ApiVersionManager singleton class for centralized version management.

    This class manages API versions for Azure resources, providing version resolution,
    compatibility analysis, and migration guidance. It implements a JSII-compliant
    singleton pattern for thread-safe operations across multiple language bindings.

    Key Features:

    - Thread-safe singleton implementation
    - Version registry management with full lifecycle support
    - Advanced version resolution with constraint-based selection
    - Comprehensive migration analysis with effort estimation
    - Extensive validation and error handling

    Example::

        const manager = ApiVersionManager.getInstance();
        manager.registerResourceType('Microsoft.Resources/resourceGroups', versions);
        const latest = manager.getLatestVersion('Microsoft.Resources/resourceGroups');
        const analysis = manager.analyzeMigration('Microsoft.Resources/resourceGroups', '2024-01-01', '2024-11-01');
    '''

    @jsii.member(jsii_name="instance")
    @builtins.classmethod
    def instance(cls) -> _ApiVersionManager_76b80279:
        '''Gets the singleton instance of ApiVersionManager.

        This method implements a thread-safe singleton pattern that's compatible
        with JSII multi-language bindings. The instance is lazily created on
        first access and reused for all subsequent calls.

        :return: The singleton ApiVersionManager instance

        Example::

            const manager = ApiVersionManager.instance();
        '''
        return typing.cast(_ApiVersionManager_76b80279, jsii.sinvoke(cls, "instance", []))

    @jsii.member(jsii_name="analyzeMigration")
    def analyze_migration(
        self,
        resource_type: builtins.str,
        from_version: builtins.str,
        to_version: builtins.str,
    ) -> _MigrationAnalysis_aa719f40:
        '''Analyzes migration requirements between two versions.

        Performs comprehensive analysis of the migration path between source and
        target versions, including compatibility assessment, breaking changes
        identification, effort estimation, and upgrade feasibility.

        :param resource_type: - The Azure resource type.
        :param from_version: - The source version to migrate from.
        :param to_version: - The target version to migrate to.

        :return: Detailed migration analysis results

        :throws: Error if resourceType is not registered

        Example::

            const analysis = manager.analyzeMigration(
              'Microsoft.Resources/resourceGroups',
              '2024-01-01',
              '2024-11-01'
            );
            
            console.log(`Compatible: ${analysis.compatible}`);
            console.log(`Effort: ${analysis.estimatedEffort}`);
            console.log(`Breaking changes: ${analysis.breakingChanges.length}`);
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eae53c766f9143385cfa30da80231b50dafd818f3080b18188f5f0c916ecfc50)
            check_type(argname="argument resource_type", value=resource_type, expected_type=type_hints["resource_type"])
            check_type(argname="argument from_version", value=from_version, expected_type=type_hints["from_version"])
            check_type(argname="argument to_version", value=to_version, expected_type=type_hints["to_version"])
        return typing.cast(_MigrationAnalysis_aa719f40, jsii.invoke(self, "analyzeMigration", [resource_type, from_version, to_version]))

    @jsii.member(jsii_name="latestVersion")
    def latest_version(
        self,
        resource_type: builtins.str,
    ) -> typing.Optional[builtins.str]:
        '''Gets the latest active version for a resource type.

        Returns the most recent version with ACTIVE support level. If no active
        versions are found, returns the most recent version regardless of support level.

        :param resource_type: - The Azure resource type to get the latest version for.

        :return: The latest version string, or undefined if the resource type is not registered

        Example::

            const latest = manager.latestVersion('Microsoft.Resources/resourceGroups');
            // Returns: "2024-11-01"
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__636a56ca751ba2dbf19051f851f23072e2784c7160fa0cf0bc98210f88b6c1b8)
            check_type(argname="argument resource_type", value=resource_type, expected_type=type_hints["resource_type"])
        return typing.cast(typing.Optional[builtins.str], jsii.invoke(self, "latestVersion", [resource_type]))

    @jsii.member(jsii_name="registeredResourceTypes")
    def registered_resource_types(self) -> typing.List[builtins.str]:
        '''Gets all registered resource types.

        Returns an array of all Azure resource types that have been registered
        with the version manager.

        :return: Array of registered resource type strings

        Example::

            const resourceTypes = manager.registeredResourceTypes();
            // Returns: ["Microsoft.Resources/resourceGroups", "Microsoft.Storage/storageAccounts", ...]
        '''
        return typing.cast(typing.List[builtins.str], jsii.invoke(self, "registeredResourceTypes", []))

    @jsii.member(jsii_name="registerResourceType")
    def register_resource_type(
        self,
        resource_type: builtins.str,
        versions: typing.Sequence[typing.Union[_VersionConfig_ddf991d0, typing.Dict[builtins.str, typing.Any]]],
    ) -> None:
        '''Registers a resource type with its version configurations.

        This method stores version metadata for a specific Azure resource type,
        including schemas, lifecycle information, and migration data. It validates
        the input and maintains internal indexes for efficient lookups.

        :param resource_type: - The Azure resource type (e.g., 'Microsoft.Resources/resourceGroups').
        :param versions: - Array of version configurations for the resource type.

        :throws: Error if version configurations are invalid

        Example::

            manager.registerResourceType('Microsoft.Resources/resourceGroups', [
              {
                version: '2024-01-01',
                schema: { resourceType: 'Microsoft.Resources/resourceGroups', version: '2024-01-01', properties: {}, required: [] },
                supportLevel: VersionSupportLevel.ACTIVE,
                releaseDate: '2024-01-01'
              }
            ]);
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5b2e2a21286a265793ba7669b609f098592d5d32196c0618854904f1287e1a21)
            check_type(argname="argument resource_type", value=resource_type, expected_type=type_hints["resource_type"])
            check_type(argname="argument versions", value=versions, expected_type=type_hints["versions"])
        return typing.cast(None, jsii.invoke(self, "registerResourceType", [resource_type, versions]))

    @jsii.member(jsii_name="supportedVersions")
    def supported_versions(
        self,
        resource_type: builtins.str,
    ) -> typing.List[builtins.str]:
        '''Gets all supported versions for a resource type.

        Returns an array of all registered version strings for the specified
        resource type, sorted by release date (newest first).

        :param resource_type: - The Azure resource type.

        :return: Array of supported version strings, empty if resource type not registered

        Example::

            const versions = manager.supportedVersions('Microsoft.Resources/resourceGroups');
            // Returns: ["2024-11-01", "2024-01-01", "2023-07-01"]
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__66ce75bb791d3e413bf8c7023c3badc4380fc73c590dc3961bfe4124188fd11f)
            check_type(argname="argument resource_type", value=resource_type, expected_type=type_hints["resource_type"])
        return typing.cast(typing.List[builtins.str], jsii.invoke(self, "supportedVersions", [resource_type]))

    @jsii.member(jsii_name="validateVersionSupport")
    def validate_version_support(
        self,
        resource_type: builtins.str,
        version: builtins.str,
    ) -> builtins.bool:
        '''Validates whether a version is supported for a resource type.

        Checks if the specified version is registered and available for use
        with the given resource type.

        :param resource_type: - The Azure resource type.
        :param version: - The version to validate.

        :return: True if the version is supported, false otherwise

        Example::

            if (manager.validateVersionSupport('Microsoft.Resources/resourceGroups', '2024-01-01')) {
              // Version is supported, proceed with resource creation
            } else {
              // Handle unsupported version
            }
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c443670bc20deea13ae38f8902750eec74d9107e2b48beda38016054c3dd3672)
            check_type(argname="argument resource_type", value=resource_type, expected_type=type_hints["resource_type"])
            check_type(argname="argument version", value=version, expected_type=type_hints["version"])
        return typing.cast(builtins.bool, jsii.invoke(self, "validateVersionSupport", [resource_type, version]))

    @jsii.member(jsii_name="versionConfig")
    def version_config(
        self,
        resource_type: builtins.str,
        version: builtins.str,
    ) -> typing.Optional[_VersionConfig_ddf991d0]:
        '''Gets the configuration for a specific version of a resource type.

        Retrieves the complete version configuration including schema, lifecycle
        information, breaking changes, and migration metadata.

        :param resource_type: - The Azure resource type.
        :param version: - The specific version to retrieve.

        :return: The version configuration, or undefined if not found

        Example::

            const config = manager.versionConfig('Microsoft.Resources/resourceGroups', '2024-01-01');
            if (config) {
              console.log(`Support level: ${config.supportLevel}`);
              console.log(`Release date: ${config.releaseDate}`);
            }
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__adb294d786c98dfa983d0e38016c245d2dfd857f5389f013bd207654e42e710e)
            check_type(argname="argument resource_type", value=resource_type, expected_type=type_hints["resource_type"])
            check_type(argname="argument version", value=version, expected_type=type_hints["version"])
        return typing.cast(typing.Optional[_VersionConfig_ddf991d0], jsii.invoke(self, "versionConfig", [resource_type, version]))

    @jsii.member(jsii_name="versionLifecycle")
    def version_lifecycle(
        self,
        resource_type: builtins.str,
        version: builtins.str,
    ) -> typing.Optional[_VersionLifecycle_d648b2ea]:
        '''Gets version lifecycle information for a specific version.

        Provides lifecycle metadata including current phase, transition dates,
        and projected sunset timeline.

        :param resource_type: - The Azure resource type.
        :param version: - The version to get lifecycle information for.

        :return: Version lifecycle information, or undefined if not found

        Example::

            const lifecycle = manager.versionLifecycle('Microsoft.Resources/resourceGroups', '2024-01-01');
            if (lifecycle) {
              console.log(`Current phase: ${lifecycle.phase}`);
              console.log(`Sunset date: ${lifecycle.estimatedSunsetDate}`);
            }
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__01628a4957865cbca6342955dff8dba00e1fbcdfa7802c315b2771e4966560df)
            check_type(argname="argument resource_type", value=resource_type, expected_type=type_hints["resource_type"])
            check_type(argname="argument version", value=version, expected_type=type_hints["version"])
        return typing.cast(typing.Optional[_VersionLifecycle_d648b2ea], jsii.invoke(self, "versionLifecycle", [resource_type, version]))


class AzapiDiagnosticSettings(
    _constructs_77d1e7e8.Construct,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.AzapiDiagnosticSettings",
):
    '''AZAPI-based diagnostic settings construct.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id: builtins.str,
        *,
        eventhub_authorization_rule_id: typing.Optional[builtins.str] = None,
        eventhub_name: typing.Optional[builtins.str] = None,
        log_analytics_workspace_id: typing.Optional[builtins.str] = None,
        logs: typing.Optional[typing.Sequence[typing.Union[_DiagnosticLogConfig_990fcbff, typing.Dict[builtins.str, typing.Any]]]] = None,
        metrics: typing.Optional[typing.Sequence[typing.Union[_DiagnosticMetricConfig_29c0add1, typing.Dict[builtins.str, typing.Any]]]] = None,
        name: typing.Optional[builtins.str] = None,
        storage_account_id: typing.Optional[builtins.str] = None,
        target_resource_id: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param eventhub_authorization_rule_id: 
        :param eventhub_name: 
        :param log_analytics_workspace_id: 
        :param logs: 
        :param metrics: 
        :param name: 
        :param storage_account_id: 
        :param target_resource_id: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6a033756641af00746ff216b48d9c17f85dcbeb08ad235af1f0d99d4ac129124)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = _AzapiDiagnosticSettingsProps_b5c36ed5(
            eventhub_authorization_rule_id=eventhub_authorization_rule_id,
            eventhub_name=eventhub_name,
            log_analytics_workspace_id=log_analytics_workspace_id,
            logs=logs,
            metrics=metrics,
            name=name,
            storage_account_id=storage_account_id,
            target_resource_id=target_resource_id,
        )

        jsii.create(self.__class__, self, [scope, id, props])


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.AzapiDiagnosticSettingsProps",
    jsii_struct_bases=[],
    name_mapping={
        "eventhub_authorization_rule_id": "eventhubAuthorizationRuleId",
        "eventhub_name": "eventhubName",
        "log_analytics_workspace_id": "logAnalyticsWorkspaceId",
        "logs": "logs",
        "metrics": "metrics",
        "name": "name",
        "storage_account_id": "storageAccountId",
        "target_resource_id": "targetResourceId",
    },
)
class AzapiDiagnosticSettingsProps:
    def __init__(
        self,
        *,
        eventhub_authorization_rule_id: typing.Optional[builtins.str] = None,
        eventhub_name: typing.Optional[builtins.str] = None,
        log_analytics_workspace_id: typing.Optional[builtins.str] = None,
        logs: typing.Optional[typing.Sequence[typing.Union[_DiagnosticLogConfig_990fcbff, typing.Dict[builtins.str, typing.Any]]]] = None,
        metrics: typing.Optional[typing.Sequence[typing.Union[_DiagnosticMetricConfig_29c0add1, typing.Dict[builtins.str, typing.Any]]]] = None,
        name: typing.Optional[builtins.str] = None,
        storage_account_id: typing.Optional[builtins.str] = None,
        target_resource_id: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Properties for AZAPI diagnostic settings.

        :param eventhub_authorization_rule_id: 
        :param eventhub_name: 
        :param log_analytics_workspace_id: 
        :param logs: 
        :param metrics: 
        :param name: 
        :param storage_account_id: 
        :param target_resource_id: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__51749f4546a92ef267ad44e27da601035e35f7c9f772c21c942314708f7646a4)
            check_type(argname="argument eventhub_authorization_rule_id", value=eventhub_authorization_rule_id, expected_type=type_hints["eventhub_authorization_rule_id"])
            check_type(argname="argument eventhub_name", value=eventhub_name, expected_type=type_hints["eventhub_name"])
            check_type(argname="argument log_analytics_workspace_id", value=log_analytics_workspace_id, expected_type=type_hints["log_analytics_workspace_id"])
            check_type(argname="argument logs", value=logs, expected_type=type_hints["logs"])
            check_type(argname="argument metrics", value=metrics, expected_type=type_hints["metrics"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument storage_account_id", value=storage_account_id, expected_type=type_hints["storage_account_id"])
            check_type(argname="argument target_resource_id", value=target_resource_id, expected_type=type_hints["target_resource_id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if eventhub_authorization_rule_id is not None:
            self._values["eventhub_authorization_rule_id"] = eventhub_authorization_rule_id
        if eventhub_name is not None:
            self._values["eventhub_name"] = eventhub_name
        if log_analytics_workspace_id is not None:
            self._values["log_analytics_workspace_id"] = log_analytics_workspace_id
        if logs is not None:
            self._values["logs"] = logs
        if metrics is not None:
            self._values["metrics"] = metrics
        if name is not None:
            self._values["name"] = name
        if storage_account_id is not None:
            self._values["storage_account_id"] = storage_account_id
        if target_resource_id is not None:
            self._values["target_resource_id"] = target_resource_id

    @builtins.property
    def eventhub_authorization_rule_id(self) -> typing.Optional[builtins.str]:
        result = self._values.get("eventhub_authorization_rule_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def eventhub_name(self) -> typing.Optional[builtins.str]:
        result = self._values.get("eventhub_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def log_analytics_workspace_id(self) -> typing.Optional[builtins.str]:
        result = self._values.get("log_analytics_workspace_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def logs(self) -> typing.Optional[typing.List[_DiagnosticLogConfig_990fcbff]]:
        result = self._values.get("logs")
        return typing.cast(typing.Optional[typing.List[_DiagnosticLogConfig_990fcbff]], result)

    @builtins.property
    def metrics(self) -> typing.Optional[typing.List[_DiagnosticMetricConfig_29c0add1]]:
        result = self._values.get("metrics")
        return typing.cast(typing.Optional[typing.List[_DiagnosticMetricConfig_29c0add1]], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def storage_account_id(self) -> typing.Optional[builtins.str]:
        result = self._values.get("storage_account_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def target_resource_id(self) -> typing.Optional[builtins.str]:
        result = self._values.get("target_resource_id")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AzapiDiagnosticSettingsProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class AzapiResource(
    _constructs_77d1e7e8.Construct,
    metaclass=jsii.JSIIAbstractClass,
    jsii_type="@microsoft/terraform-cdk-constructs.AzapiResource",
):
    '''Abstract base class for version-aware Azure resource management.

    AzapiResource provides a unified framework for creating Azure resources
    with automatic version management, schema validation, property transformation,
    and migration analysis. It extends the existing AzapiResource class while
    maintaining full backward compatibility.

    This class implements the core framework that enables:

    - Automatic resolution of the latest API version when none is specified
    - Explicit version pinning for environments requiring stability
    - Schema-driven property validation and transformation
    - Migration analysis with breaking change detection
    - Deprecation warnings and upgrade recommendations

    Subclasses must implement the abstract methods to provide resource-specific
    configuration while the framework handles all version management complexity.

    Example::

        Usage with explicit version pinning:
        new MyResource(this, "resource", {
        name: "my-resource",
        location: "eastus",
        apiVersion: "2024-01-01" // Pin to specific version
        });
    '''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id: builtins.str,
        *,
        api_version: typing.Optional[builtins.str] = None,
        enable_migration_analysis: typing.Optional[builtins.bool] = None,
        enable_transformation: typing.Optional[builtins.bool] = None,
        enable_validation: typing.Optional[builtins.bool] = None,
        location: typing.Optional[builtins.str] = None,
        name: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> None:
        '''Creates a new AzapiResource instance.

        The constructor handles all framework initialization including version resolution,
        schema loading, property validation, transformation, and migration analysis.
        It maintains full backward compatibility with the AzapiResource constructor.

        :param scope: - The scope in which to define this construct.
        :param id: - The unique identifier for this instance.
        :param api_version: Explicit API version to use for this resource. If not specified, the latest active version will be automatically resolved. Use this for version pinning when stability is required over latest features. Default: Latest active version from ApiVersionManager
        :param enable_migration_analysis: Whether to enable migration analysis warnings. When true, the framework will analyze the current version for deprecation status and provide migration recommendations in the deployment output. Default: true
        :param enable_transformation: Whether to apply property transformations automatically. When true, properties will be automatically transformed according to the target schema's transformation rules. This enables backward compatibility. Default: true
        :param enable_validation: Whether to validate properties against the schema. When true, all properties will be validated against the API schema before resource creation. Validation errors will cause deployment failures. Default: true
        :param location: The location where the resource should be created.
        :param name: The name of the resource.
        :param tags: Tags to apply to the resource.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a3d3c58c42b41b398803c4efbf0772e4a0c8784d47b74c87dd9ebf23d9d738a1)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = _AzapiResourceProps_141a2340(
            api_version=api_version,
            enable_migration_analysis=enable_migration_analysis,
            enable_transformation=enable_transformation,
            enable_validation=enable_validation,
            location=location,
            name=name,
            tags=tags,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="addAccess")
    def add_access(
        self,
        object_id: builtins.str,
        role_definition_name: builtins.str,
    ) -> None:
        '''Adds an access role assignment for a specified Azure AD object.

        Note: This method creates role assignments using AZAPI instead of AzureRM provider.

        :param object_id: - The unique identifier of the Azure AD object.
        :param role_definition_name: - The name of the Azure RBAC role to be assigned.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f4ceb970ba75ee62b0297d00ddb7ae9f80bbe8dfed04665ca5ac0918f20f697f)
            check_type(argname="argument object_id", value=object_id, expected_type=type_hints["object_id"])
            check_type(argname="argument role_definition_name", value=role_definition_name, expected_type=type_hints["role_definition_name"])
        return typing.cast(None, jsii.invoke(self, "addAccess", [object_id, role_definition_name]))

    @jsii.member(jsii_name="addDiagnosticSettings")
    def add_diagnostic_settings(
        self,
        *,
        eventhub_authorization_rule_id: typing.Optional[builtins.str] = None,
        eventhub_name: typing.Optional[builtins.str] = None,
        log_analytics_workspace_id: typing.Optional[builtins.str] = None,
        logs: typing.Optional[typing.Sequence[typing.Union[_DiagnosticLogConfig_990fcbff, typing.Dict[builtins.str, typing.Any]]]] = None,
        metrics: typing.Optional[typing.Sequence[typing.Union[_DiagnosticMetricConfig_29c0add1, typing.Dict[builtins.str, typing.Any]]]] = None,
        name: typing.Optional[builtins.str] = None,
        storage_account_id: typing.Optional[builtins.str] = None,
        target_resource_id: typing.Optional[builtins.str] = None,
    ) -> _AzapiDiagnosticSettings_4f8e56d3:
        '''Adds diagnostic settings to this resource using AZAPI.

        :param eventhub_authorization_rule_id: 
        :param eventhub_name: 
        :param log_analytics_workspace_id: 
        :param logs: 
        :param metrics: 
        :param name: 
        :param storage_account_id: 
        :param target_resource_id: 
        '''
        props = _AzapiDiagnosticSettingsProps_b5c36ed5(
            eventhub_authorization_rule_id=eventhub_authorization_rule_id,
            eventhub_name=eventhub_name,
            log_analytics_workspace_id=log_analytics_workspace_id,
            logs=logs,
            metrics=metrics,
            name=name,
            storage_account_id=storage_account_id,
            target_resource_id=target_resource_id,
        )

        return typing.cast(_AzapiDiagnosticSettings_4f8e56d3, jsii.invoke(self, "addDiagnosticSettings", [props]))

    @jsii.member(jsii_name="analyzeMigrationTo")
    def analyze_migration_to(
        self,
        target_version: builtins.str,
    ) -> _MigrationAnalysis_aa719f40:
        '''Analyzes migration from current version to a target version.

        This method enables external tools to analyze migration requirements
        between versions for planning and automation purposes.

        :param target_version: - The target version to analyze migration to.

        :return: Detailed migration analysis results
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__238050e80b865d80a0d7c8e5a26741c84d5a802fc7496802ec85f097ef48ad07)
            check_type(argname="argument target_version", value=target_version, expected_type=type_hints["target_version"])
        return typing.cast(_MigrationAnalysis_aa719f40, jsii.invoke(self, "analyzeMigrationTo", [target_version]))

    @jsii.member(jsii_name="apiSchema")
    @abc.abstractmethod
    def _api_schema(self) -> _ApiSchema_5ce0490e:
        '''Gets the API schema for the resolved version.

        This method should return the complete API schema for the resolved version,
        including all property definitions, validation rules, and transformation
        mappings. Use the resolveSchema() helper method for standard schema resolution.

        :return: The API schema for the resolved version
        '''
        ...

    @jsii.member(jsii_name="createAzapiDataSource")
    def _create_azapi_data_source(
        self,
        resource_id: builtins.str,
    ) -> _cdktf_9a9027ec.TerraformDataSource:
        '''Creates an AZAPI data source for reading existing resources.

        :param resource_id: - The full resource ID.

        :return: The created Terraform data source
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__83e5393f73b29a9c8e15e27771f790289e23467d98ec01c6de05e6c376dc7035)
            check_type(argname="argument resource_id", value=resource_id, expected_type=type_hints["resource_id"])
        return typing.cast(_cdktf_9a9027ec.TerraformDataSource, jsii.invoke(self, "createAzapiDataSource", [resource_id]))

    @jsii.member(jsii_name="createAzapiResource")
    def _create_azapi_resource(
        self,
        properties: typing.Mapping[builtins.str, typing.Any],
        parent_id: builtins.str,
        name: builtins.str,
        location: typing.Optional[builtins.str] = None,
    ) -> _cdktf_9a9027ec.TerraformResource:
        '''Creates the underlying AZAPI Terraform resource using the generated provider classes.

        :param properties: - The properties object to send to the Azure API.
        :param parent_id: - The parent resource ID (e.g., subscription or resource group).
        :param name: - The name of the resource.
        :param location: - The location of the resource (optional, can be in properties).

        :return: The created AZAPI resource
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a404c6dee43160589c1a592d4c91470f8bc17a406da1d37b670f3f4d7fe00f53)
            check_type(argname="argument properties", value=properties, expected_type=type_hints["properties"])
            check_type(argname="argument parent_id", value=parent_id, expected_type=type_hints["parent_id"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument location", value=location, expected_type=type_hints["location"])
        return typing.cast(_cdktf_9a9027ec.TerraformResource, jsii.invoke(self, "createAzapiResource", [properties, parent_id, name, location]))

    @jsii.member(jsii_name="createResourceBody")
    @abc.abstractmethod
    def _create_resource_body(self, props: typing.Any) -> typing.Any:
        '''Creates the resource body for the Azure API call.

        This method should transform the input properties into the JSON body format
        expected by the Azure REST API for the resolved version. The framework will
        have already applied any necessary property transformations and validation.

        :param props: - The processed and validated properties for the resource.

        :return: The resource body object to send to Azure API
        '''
        ...

    @jsii.member(jsii_name="defaultVersion")
    @abc.abstractmethod
    def _default_version(self) -> builtins.str:
        '''Gets the default API version to use when no explicit version is specified.

        This method should return a sensible default version that can be used
        as a fallback if the ApiVersionManager doesn't have any versions registered
        for this resource type.

        :return: The default API version string (e.g., "2024-11-01")
        '''
        ...

    @jsii.member(jsii_name="latestVersion")
    def latest_version(self) -> typing.Optional[builtins.str]:
        '''Gets the latest available version for this resource type.

        This method provides access to the latest version resolution logic
        for use in subclasses or external tooling.

        :return: The latest available version, or undefined if none found
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.invoke(self, "latestVersion", []))

    @jsii.member(jsii_name="resolveSchema")
    def _resolve_schema(self) -> _ApiSchema_5ce0490e:
        '''Helper method for standard schema resolution.

        Subclasses can use this method to resolve the schema for the current version
        from the ApiVersionManager. This provides a standard implementation that
        most resources can use without custom logic.

        :return: The API schema for the resolved version

        :throws: Error if the schema cannot be resolved
        '''
        return typing.cast(_ApiSchema_5ce0490e, jsii.invoke(self, "resolveSchema", []))

    @jsii.member(jsii_name="resourceType")
    @abc.abstractmethod
    def _resource_type(self) -> builtins.str:
        '''Gets the Azure resource type for this resource.

        This method should return the full Azure resource type identifier that
        will be used for API calls and version management.

        :return: The Azure resource type (e.g., "Microsoft.Resources/resourceGroups")
        '''
        ...

    @jsii.member(jsii_name="supportedVersions")
    def supported_versions(self) -> typing.List[builtins.str]:
        '''Gets all supported versions for this resource type.

        This method provides access to the version registry for use in
        subclasses or external tooling.

        :return: Array of supported version strings, sorted by release date
        '''
        return typing.cast(typing.List[builtins.str], jsii.invoke(self, "supportedVersions", []))

    @jsii.member(jsii_name="updateAzapiResource")
    def _update_azapi_resource(
        self,
        properties: typing.Mapping[builtins.str, typing.Any],
    ) -> None:
        '''Updates the resource with new properties.

        :param properties: - The new properties to apply.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3049a84daed50c8ec29f4ae37b33f5f4495e2a3b712158dcc6f0c7b6bf15dd71)
            check_type(argname="argument properties", value=properties, expected_type=type_hints["properties"])
        return typing.cast(None, jsii.invoke(self, "updateAzapiResource", [properties]))

    @builtins.property
    @jsii.member(jsii_name="apiVersion")
    def _api_version(self) -> builtins.str:
        '''The API version to use for this resource.'''
        return typing.cast(builtins.str, jsii.get(self, "apiVersion"))

    @builtins.property
    @jsii.member(jsii_name="id")
    @abc.abstractmethod
    def id(self) -> builtins.str:
        '''The resource ID (abstract - must be implemented by subclasses).'''
        ...

    @builtins.property
    @jsii.member(jsii_name="location")
    def location(self) -> builtins.str:
        '''The location of the resource.'''
        return typing.cast(builtins.str, jsii.get(self, "location"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        '''The name of the resource.'''
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @builtins.property
    @jsii.member(jsii_name="output")
    def output(self) -> _cdktf_9a9027ec.TerraformOutput:
        '''Gets the resource as a Terraform output value.'''
        return typing.cast(_cdktf_9a9027ec.TerraformOutput, jsii.get(self, "output"))

    @builtins.property
    @jsii.member(jsii_name="resolvedApiVersion")
    def resolved_api_version(self) -> builtins.str:
        '''The resolved API version being used for this resource instance.

        This is the actual version that will be used for the Azure API call,
        either explicitly specified in props or automatically resolved to
        the latest active version.
        '''
        return typing.cast(builtins.str, jsii.get(self, "resolvedApiVersion"))

    @builtins.property
    @jsii.member(jsii_name="resourceId")
    def resource_id(self) -> builtins.str:
        '''Gets the full resource ID.'''
        return typing.cast(builtins.str, jsii.get(self, "resourceId"))

    @builtins.property
    @jsii.member(jsii_name="schema")
    def schema(self) -> _ApiSchema_5ce0490e:
        '''The API schema for the resolved version.

        Contains the complete schema definition including properties, validation
        rules, and transformation mappings for the resolved API version.
        '''
        return typing.cast(_ApiSchema_5ce0490e, jsii.get(self, "schema"))

    @builtins.property
    @jsii.member(jsii_name="versionConfig")
    def version_config(self) -> _VersionConfig_ddf991d0:
        '''The version configuration for the resolved version.

        Contains lifecycle information, breaking changes, and migration metadata
        for the resolved API version.
        '''
        return typing.cast(_VersionConfig_ddf991d0, jsii.get(self, "versionConfig"))

    @builtins.property
    @jsii.member(jsii_name="migrationAnalysis")
    def migration_analysis(self) -> typing.Optional[_MigrationAnalysis_aa719f40]:
        '''Migration analysis results.

        Available after construction if migration analysis is enabled and a
        previous version can be determined for comparison.
        '''
        return typing.cast(typing.Optional[_MigrationAnalysis_aa719f40], jsii.get(self, "migrationAnalysis"))

    @builtins.property
    @jsii.member(jsii_name="validationResult")
    def validation_result(self) -> typing.Optional[_ValidationResult_87269226]:
        '''Validation results for the resource properties.

        Available after construction if validation is enabled. Contains detailed
        information about any validation errors or warnings.
        '''
        return typing.cast(typing.Optional[_ValidationResult_87269226], jsii.get(self, "validationResult"))

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktf_9a9027ec.TerraformResource:
        '''The underlying AZAPI Terraform resource.'''
        return typing.cast(_cdktf_9a9027ec.TerraformResource, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktf_9a9027ec.TerraformResource) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1fec2795df9e0c4f2b5fa75ff33324d735773ce6d94e46bea101a8717a85e2f2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]


class _AzapiResourceProxy(AzapiResource):
    @jsii.member(jsii_name="apiSchema")
    def _api_schema(self) -> _ApiSchema_5ce0490e:
        '''Gets the API schema for the resolved version.

        This method should return the complete API schema for the resolved version,
        including all property definitions, validation rules, and transformation
        mappings. Use the resolveSchema() helper method for standard schema resolution.

        :return: The API schema for the resolved version
        '''
        return typing.cast(_ApiSchema_5ce0490e, jsii.invoke(self, "apiSchema", []))

    @jsii.member(jsii_name="createResourceBody")
    def _create_resource_body(self, props: typing.Any) -> typing.Any:
        '''Creates the resource body for the Azure API call.

        This method should transform the input properties into the JSON body format
        expected by the Azure REST API for the resolved version. The framework will
        have already applied any necessary property transformations and validation.

        :param props: - The processed and validated properties for the resource.

        :return: The resource body object to send to Azure API
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8b528c66806e6c4d819f260a5384e8b851df8221b890e5cb4ff575de78472b1c)
            check_type(argname="argument props", value=props, expected_type=type_hints["props"])
        return typing.cast(typing.Any, jsii.invoke(self, "createResourceBody", [props]))

    @jsii.member(jsii_name="defaultVersion")
    def _default_version(self) -> builtins.str:
        '''Gets the default API version to use when no explicit version is specified.

        This method should return a sensible default version that can be used
        as a fallback if the ApiVersionManager doesn't have any versions registered
        for this resource type.

        :return: The default API version string (e.g., "2024-11-01")
        '''
        return typing.cast(builtins.str, jsii.invoke(self, "defaultVersion", []))

    @jsii.member(jsii_name="resourceType")
    def _resource_type(self) -> builtins.str:
        '''Gets the Azure resource type for this resource.

        This method should return the full Azure resource type identifier that
        will be used for API calls and version management.

        :return: The Azure resource type (e.g., "Microsoft.Resources/resourceGroups")
        '''
        return typing.cast(builtins.str, jsii.invoke(self, "resourceType", []))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        '''The resource ID (abstract - must be implemented by subclasses).'''
        return typing.cast(builtins.str, jsii.get(self, "id"))

# Adding a "__jsii_proxy_class__(): typing.Type" function to the abstract class
typing.cast(typing.Any, AzapiResource).__jsii_proxy_class__ = lambda : _AzapiResourceProxy


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.AzapiResourceProps",
    jsii_struct_bases=[],
    name_mapping={
        "api_version": "apiVersion",
        "enable_migration_analysis": "enableMigrationAnalysis",
        "enable_transformation": "enableTransformation",
        "enable_validation": "enableValidation",
        "location": "location",
        "name": "name",
        "tags": "tags",
    },
)
class AzapiResourceProps:
    def __init__(
        self,
        *,
        api_version: typing.Optional[builtins.str] = None,
        enable_migration_analysis: typing.Optional[builtins.bool] = None,
        enable_transformation: typing.Optional[builtins.bool] = None,
        enable_validation: typing.Optional[builtins.bool] = None,
        location: typing.Optional[builtins.str] = None,
        name: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> None:
        '''Properties for versioned Azure resources.

        Combines base resource properties with version management capabilities
        and advanced configuration options for the unified framework.

        :param api_version: Explicit API version to use for this resource. If not specified, the latest active version will be automatically resolved. Use this for version pinning when stability is required over latest features. Default: Latest active version from ApiVersionManager
        :param enable_migration_analysis: Whether to enable migration analysis warnings. When true, the framework will analyze the current version for deprecation status and provide migration recommendations in the deployment output. Default: true
        :param enable_transformation: Whether to apply property transformations automatically. When true, properties will be automatically transformed according to the target schema's transformation rules. This enables backward compatibility. Default: true
        :param enable_validation: Whether to validate properties against the schema. When true, all properties will be validated against the API schema before resource creation. Validation errors will cause deployment failures. Default: true
        :param location: The location where the resource should be created.
        :param name: The name of the resource.
        :param tags: Tags to apply to the resource.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3d93af01845ca8c4fccb8df898596d1e45bcb9c1695be8e9787e78e62e393dfa)
            check_type(argname="argument api_version", value=api_version, expected_type=type_hints["api_version"])
            check_type(argname="argument enable_migration_analysis", value=enable_migration_analysis, expected_type=type_hints["enable_migration_analysis"])
            check_type(argname="argument enable_transformation", value=enable_transformation, expected_type=type_hints["enable_transformation"])
            check_type(argname="argument enable_validation", value=enable_validation, expected_type=type_hints["enable_validation"])
            check_type(argname="argument location", value=location, expected_type=type_hints["location"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if api_version is not None:
            self._values["api_version"] = api_version
        if enable_migration_analysis is not None:
            self._values["enable_migration_analysis"] = enable_migration_analysis
        if enable_transformation is not None:
            self._values["enable_transformation"] = enable_transformation
        if enable_validation is not None:
            self._values["enable_validation"] = enable_validation
        if location is not None:
            self._values["location"] = location
        if name is not None:
            self._values["name"] = name
        if tags is not None:
            self._values["tags"] = tags

    @builtins.property
    def api_version(self) -> typing.Optional[builtins.str]:
        '''Explicit API version to use for this resource.

        If not specified, the latest active version will be automatically resolved.
        Use this for version pinning when stability is required over latest features.

        :default: Latest active version from ApiVersionManager

        Example::

            "2024-11-01"
        '''
        result = self._values.get("api_version")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def enable_migration_analysis(self) -> typing.Optional[builtins.bool]:
        '''Whether to enable migration analysis warnings.

        When true, the framework will analyze the current version for deprecation
        status and provide migration recommendations in the deployment output.

        :default: true
        '''
        result = self._values.get("enable_migration_analysis")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_transformation(self) -> typing.Optional[builtins.bool]:
        '''Whether to apply property transformations automatically.

        When true, properties will be automatically transformed according to the
        target schema's transformation rules. This enables backward compatibility.

        :default: true
        '''
        result = self._values.get("enable_transformation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_validation(self) -> typing.Optional[builtins.bool]:
        '''Whether to validate properties against the schema.

        When true, all properties will be validated against the API schema before
        resource creation. Validation errors will cause deployment failures.

        :default: true
        '''
        result = self._values.get("enable_validation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def location(self) -> typing.Optional[builtins.str]:
        '''The location where the resource should be created.'''
        result = self._values.get("location")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''The name of the resource.'''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Tags to apply to the resource.'''
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AzapiResourceProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class AzapiRoleAssignment(
    _constructs_77d1e7e8.Construct,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.AzapiRoleAssignment",
):
    '''AZAPI-based role assignment construct.'''

    def __init__(
        self,
        scope_: _constructs_77d1e7e8.Construct,
        id: builtins.str,
        *,
        object_id: builtins.str,
        role_definition_name: builtins.str,
        scope: builtins.str,
    ) -> None:
        '''
        :param scope_: -
        :param id: -
        :param object_id: 
        :param role_definition_name: 
        :param scope: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__89a5f56067301c27b4a88c97c0bd8eb62b4ad952688cae6c4f4430ff1375d4ad)
            check_type(argname="argument scope_", value=scope_, expected_type=type_hints["scope_"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = _AzapiRoleAssignmentProps_d153e00c(
            object_id=object_id, role_definition_name=role_definition_name, scope=scope
        )

        jsii.create(self.__class__, self, [scope_, id, props])


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.AzapiRoleAssignmentProps",
    jsii_struct_bases=[],
    name_mapping={
        "object_id": "objectId",
        "role_definition_name": "roleDefinitionName",
        "scope": "scope",
    },
)
class AzapiRoleAssignmentProps:
    def __init__(
        self,
        *,
        object_id: builtins.str,
        role_definition_name: builtins.str,
        scope: builtins.str,
    ) -> None:
        '''Properties for AZAPI role assignment.

        :param object_id: 
        :param role_definition_name: 
        :param scope: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__333820b506b51590b5eebe73fd9c0f718a72a7642876a758352f5ef516c7e6ba)
            check_type(argname="argument object_id", value=object_id, expected_type=type_hints["object_id"])
            check_type(argname="argument role_definition_name", value=role_definition_name, expected_type=type_hints["role_definition_name"])
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "object_id": object_id,
            "role_definition_name": role_definition_name,
            "scope": scope,
        }

    @builtins.property
    def object_id(self) -> builtins.str:
        result = self._values.get("object_id")
        assert result is not None, "Required property 'object_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def role_definition_name(self) -> builtins.str:
        result = self._values.get("role_definition_name")
        assert result is not None, "Required property 'role_definition_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def scope(self) -> builtins.str:
        result = self._values.get("scope")
        assert result is not None, "Required property 'scope' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AzapiRoleAssignmentProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.BreakingChange",
    jsii_struct_bases=[],
    name_mapping={
        "change_type": "changeType",
        "description": "description",
        "migration_path": "migrationPath",
        "new_value": "newValue",
        "old_value": "oldValue",
        "property": "property",
    },
)
class BreakingChange:
    def __init__(
        self,
        *,
        change_type: builtins.str,
        description: builtins.str,
        migration_path: typing.Optional[builtins.str] = None,
        new_value: typing.Optional[builtins.str] = None,
        old_value: typing.Optional[builtins.str] = None,
        property: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Breaking change documentation.

        Documents a breaking change between API versions to enable automated
        migration analysis and provide guidance to developers.

        :param change_type: The type of breaking change Must be one of the BreakingChangeType constants.
        :param description: Human-readable description of the breaking change Explains the impact and reasoning behind the change.
        :param migration_path: Guidance on how to migrate from old to new format Should include code examples where applicable.
        :param new_value: The new value or format Shows developers what to change to.
        :param old_value: The old value or format (for reference) Helps developers understand what changed.
        :param property: The property name affected by the breaking change Omit for schema-level changes.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d8294b7173ae32b733a72e6bd891a22906cfb0103b787259df438fea598a74df)
            check_type(argname="argument change_type", value=change_type, expected_type=type_hints["change_type"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument migration_path", value=migration_path, expected_type=type_hints["migration_path"])
            check_type(argname="argument new_value", value=new_value, expected_type=type_hints["new_value"])
            check_type(argname="argument old_value", value=old_value, expected_type=type_hints["old_value"])
            check_type(argname="argument property", value=property, expected_type=type_hints["property"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "change_type": change_type,
            "description": description,
        }
        if migration_path is not None:
            self._values["migration_path"] = migration_path
        if new_value is not None:
            self._values["new_value"] = new_value
        if old_value is not None:
            self._values["old_value"] = old_value
        if property is not None:
            self._values["property"] = property

    @builtins.property
    def change_type(self) -> builtins.str:
        '''The type of breaking change Must be one of the BreakingChangeType constants.'''
        result = self._values.get("change_type")
        assert result is not None, "Required property 'change_type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def description(self) -> builtins.str:
        '''Human-readable description of the breaking change Explains the impact and reasoning behind the change.'''
        result = self._values.get("description")
        assert result is not None, "Required property 'description' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def migration_path(self) -> typing.Optional[builtins.str]:
        '''Guidance on how to migrate from old to new format Should include code examples where applicable.'''
        result = self._values.get("migration_path")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def new_value(self) -> typing.Optional[builtins.str]:
        '''The new value or format Shows developers what to change to.'''
        result = self._values.get("new_value")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def old_value(self) -> typing.Optional[builtins.str]:
        '''The old value or format (for reference) Helps developers understand what changed.'''
        result = self._values.get("old_value")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def property(self) -> typing.Optional[builtins.str]:
        '''The property name affected by the breaking change Omit for schema-level changes.'''
        result = self._values.get("property")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "BreakingChange(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class BreakingChangeType(
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.BreakingChangeType",
):
    '''Breaking change types for migration analysis.

    Categorizes the types of breaking changes that can occur between API versions
    to enable automated migration analysis and tooling.
    '''

    def __init__(self) -> None:
        jsii.create(self.__class__, self, [])

    @jsii.python.classproperty
    @jsii.member(jsii_name="PROPERTY_REMOVED")
    def PROPERTY_REMOVED(cls) -> builtins.str:
        '''Property has been removed from the API.'''
        return typing.cast(builtins.str, jsii.sget(cls, "PROPERTY_REMOVED"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="PROPERTY_RENAMED")
    def PROPERTY_RENAMED(cls) -> builtins.str:
        '''Property has been renamed.'''
        return typing.cast(builtins.str, jsii.sget(cls, "PROPERTY_RENAMED"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="PROPERTY_REQUIRED")
    def PROPERTY_REQUIRED(cls) -> builtins.str:
        '''Previously optional property is now required.'''
        return typing.cast(builtins.str, jsii.sget(cls, "PROPERTY_REQUIRED"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="PROPERTY_TYPE_CHANGED")
    def PROPERTY_TYPE_CHANGED(cls) -> builtins.str:
        '''Property data type has changed.'''
        return typing.cast(builtins.str, jsii.sget(cls, "PROPERTY_TYPE_CHANGED"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="SCHEMA_RESTRUCTURED")
    def SCHEMA_RESTRUCTURED(cls) -> builtins.str:
        '''Overall schema structure has been reorganized.'''
        return typing.cast(builtins.str, jsii.sget(cls, "SCHEMA_RESTRUCTURED"))


class DataAzapiClientConfig(
    _cdktf_9a9027ec.TerraformDataSource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.DataAzapiClientConfig",
):
    '''Represents a {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/client_config azapi_client_config}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id: builtins.str,
        *,
        timeouts: typing.Optional[typing.Union["DataAzapiClientConfigTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/client_config azapi_client_config} Data Source.

        :param scope: The scope in which to define this construct.
        :param id: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/client_config#timeouts DataAzapiClientConfig#timeouts}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__34f4021e722333d7f25f2e4702396e5276828ffb21525238dd3c45563e02b6a3)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        config = DataAzapiClientConfigConfig(
            timeouts=timeouts,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id, config])

    @jsii.member(jsii_name="putTimeouts")
    def put_timeouts(self, *, read: typing.Optional[builtins.str] = None) -> None:
        '''
        :param read: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/client_config#read DataAzapiClientConfig#read}
        '''
        value = DataAzapiClientConfigTimeouts(read=read)

        return typing.cast(None, jsii.invoke(self, "putTimeouts", [value]))

    @jsii.member(jsii_name="resetTimeouts")
    def reset_timeouts(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeouts", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @builtins.property
    @jsii.member(jsii_name="objectId")
    def object_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "objectId"))

    @builtins.property
    @jsii.member(jsii_name="subscriptionId")
    def subscription_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "subscriptionId"))

    @builtins.property
    @jsii.member(jsii_name="subscriptionResourceId")
    def subscription_resource_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "subscriptionResourceId"))

    @builtins.property
    @jsii.member(jsii_name="tenantId")
    def tenant_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tenantId"))

    @builtins.property
    @jsii.member(jsii_name="timeouts")
    def timeouts(self) -> "DataAzapiClientConfigTimeoutsOutputReference":
        return typing.cast("DataAzapiClientConfigTimeoutsOutputReference", jsii.get(self, "timeouts"))

    @builtins.property
    @jsii.member(jsii_name="timeoutsInput")
    def timeouts_input(
        self,
    ) -> typing.Optional[typing.Union["DataAzapiClientConfigTimeouts", _cdktf_9a9027ec.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union["DataAzapiClientConfigTimeouts", _cdktf_9a9027ec.IResolvable]], jsii.get(self, "timeoutsInput"))


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.DataAzapiClientConfigConfig",
    jsii_struct_bases=[_cdktf_9a9027ec.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "timeouts": "timeouts",
    },
)
class DataAzapiClientConfigConfig(_cdktf_9a9027ec.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        timeouts: typing.Optional[typing.Union["DataAzapiClientConfigTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/client_config#timeouts DataAzapiClientConfig#timeouts}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktf_9a9027ec.TerraformResourceLifecycle(**lifecycle)
        if isinstance(timeouts, dict):
            timeouts = DataAzapiClientConfigTimeouts(**timeouts)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3c9f620c2016730f9330066fb5a51d70a38250d6e21a8b8f1ce23836d805be79)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument timeouts", value=timeouts, expected_type=type_hints["timeouts"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if timeouts is not None:
            self._values["timeouts"] = timeouts

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, _cdktf_9a9027ec.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, _cdktf_9a9027ec.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktf_9a9027ec.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktf_9a9027ec.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktf_9a9027ec.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktf_9a9027ec.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktf_9a9027ec.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktf_9a9027ec.FileProvisioner, _cdktf_9a9027ec.LocalExecProvisioner, _cdktf_9a9027ec.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktf_9a9027ec.FileProvisioner, _cdktf_9a9027ec.LocalExecProvisioner, _cdktf_9a9027ec.RemoteExecProvisioner]]], result)

    @builtins.property
    def timeouts(self) -> typing.Optional["DataAzapiClientConfigTimeouts"]:
        '''timeouts block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/client_config#timeouts DataAzapiClientConfig#timeouts}
        '''
        result = self._values.get("timeouts")
        return typing.cast(typing.Optional["DataAzapiClientConfigTimeouts"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DataAzapiClientConfigConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.DataAzapiClientConfigTimeouts",
    jsii_struct_bases=[],
    name_mapping={"read": "read"},
)
class DataAzapiClientConfigTimeouts:
    def __init__(self, *, read: typing.Optional[builtins.str] = None) -> None:
        '''
        :param read: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/client_config#read DataAzapiClientConfig#read}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__559899a120c7542a83bac439c0c3f3d9e28ae76e687898d3d992b6f5b929a74d)
            check_type(argname="argument read", value=read, expected_type=type_hints["read"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if read is not None:
            self._values["read"] = read

    @builtins.property
    def read(self) -> typing.Optional[builtins.str]:
        '''A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/client_config#read DataAzapiClientConfig#read}
        '''
        result = self._values.get("read")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DataAzapiClientConfigTimeouts(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class DataAzapiClientConfigTimeoutsOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.DataAzapiClientConfigTimeoutsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__74702f390141f764fdf6ec8eb155f7eb2c824e59e3b141fa3196ed4a5350f0c7)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetRead")
    def reset_read(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRead", []))

    @builtins.property
    @jsii.member(jsii_name="readInput")
    def read_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "readInput"))

    @builtins.property
    @jsii.member(jsii_name="read")
    def read(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "read"))

    @read.setter
    def read(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__63da91f92c12e34f842a43a27ea2bc2c2c3df1463eb79efb44c1003d8e44ce93)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "read", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[DataAzapiClientConfigTimeouts, _cdktf_9a9027ec.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[DataAzapiClientConfigTimeouts, _cdktf_9a9027ec.IResolvable]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[DataAzapiClientConfigTimeouts, _cdktf_9a9027ec.IResolvable]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__58c110e2e7a2d356e44dd596702a266c4aaf9a93226e8ed3699bf16cf421ad08)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class DataAzapiResource(
    _cdktf_9a9027ec.TerraformDataSource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.DataAzapiResource",
):
    '''Represents a {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource azapi_resource}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id: builtins.str,
        *,
        type: builtins.str,
        headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        ignore_not_found: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
        name: typing.Optional[builtins.str] = None,
        parent_id: typing.Optional[builtins.str] = None,
        query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
        resource_id: typing.Optional[builtins.str] = None,
        response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        retry: typing.Optional[typing.Union["DataAzapiResourceRetry", typing.Dict[builtins.str, typing.Any]]] = None,
        timeouts: typing.Optional[typing.Union["DataAzapiResourceTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource azapi_resource} Data Source.

        :param scope: The scope in which to define this construct.
        :param id: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param type: In a format like ``<resource-type>@<api-version>``. ``<resource-type>`` is the Azure resource type, for example, ``Microsoft.Storage/storageAccounts``. ``<api-version>`` is version of the API used to manage this azure resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#type DataAzapiResource#type}
        :param headers: A map of headers to include in the request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#headers DataAzapiResource#headers}
        :param ignore_not_found: If set to ``true``, the data source will not fail when the specified resource is not found (HTTP 404). Identifier attributes (``id``, ``name``, ``parent_id``, ``resource_id``) will still be populated based on inputs; other computed attributes (``output``, ``location``, ``identity``, ``tags``) will be null/empty. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#ignore_not_found DataAzapiResource#ignore_not_found}
        :param name: Specifies the name of the Azure resource. Exactly one of the arguments ``name`` or ``resource_id`` must be set. It could be omitted if the ``type`` is ``Microsoft.Resources/subscriptions``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#name DataAzapiResource#name}
        :param parent_id: The ID of the azure resource in which this resource is created. It supports different kinds of deployment scope for **top level** resources: - resource group scope: ``parent_id`` should be the ID of a resource group, it's recommended to manage a resource group by azurerm_resource_group. - management group scope: ``parent_id`` should be the ID of a management group, it's recommended to manage a management group by azurerm_management_group. - extension scope: ``parent_id`` should be the ID of the resource you're adding the extension to. - subscription scope: ``parent_id`` should be like \\x60/subscriptions/00000000-0000-0000-0000-000000000000\\x60 - tenant scope: ``parent_id`` should be / For child level resources, the ``parent_id`` should be the ID of its parent resource, for example, subnet resource's ``parent_id`` is the ID of the vnet. For type ``Microsoft.Resources/resourceGroups``, the ``parent_id`` could be omitted, it defaults to subscription ID specified in provider or the default subscription (You could check the default subscription by azure cli command: ``az account show``). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#parent_id DataAzapiResource#parent_id}
        :param query_parameters: A map of query parameters to include in the request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#query_parameters DataAzapiResource#query_parameters}
        :param resource_id: The ID of the Azure resource to retrieve. Exactly one of the arguments ``name`` or ``resource_id`` must be set. It could be omitted if the ``type`` is ``Microsoft.Resources/subscriptions``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#resource_id DataAzapiResource#resource_id}
        :param response_export_values: The attribute can accept either a list or a map. - **List**: A list of paths that need to be exported from the response body. Setting it to ``["*"]`` will export the full response body. Here's an example. If it sets to ``["properties.loginServer", "properties.policies.quarantinePolicy.status"]``, it will set the following HCL object to the computed property output. Example:: { properties = { loginServer = "registry1.azurecr.io" policies = { quarantinePolicy = { status = "disabled" } } } } - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to ``{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}``, it will set the following HCL object to the computed property output. Example:: { "login_server" = "registry1.azurecr.io" "quarantine_status" = "disabled" } To learn more about JMESPath, visit `JMESPath <https://jmespath.org/>`_. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#response_export_values DataAzapiResource#response_export_values}
        :param retry: The retry object supports the following attributes:. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#retry DataAzapiResource#retry}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#timeouts DataAzapiResource#timeouts}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c7adc2f8d37c7c562f56758085ff1ec8beb6d7c11a4cfcb4d36e46f4146dda82)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        config = DataAzapiResourceConfig(
            type=type,
            headers=headers,
            ignore_not_found=ignore_not_found,
            name=name,
            parent_id=parent_id,
            query_parameters=query_parameters,
            resource_id=resource_id,
            response_export_values=response_export_values,
            retry=retry,
            timeouts=timeouts,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id, config])

    @jsii.member(jsii_name="putRetry")
    def put_retry(
        self,
        *,
        error_message_regex: typing.Sequence[builtins.str],
        interval_seconds: typing.Optional[jsii.Number] = None,
        max_interval_seconds: typing.Optional[jsii.Number] = None,
        multiplier: typing.Optional[jsii.Number] = None,
        randomization_factor: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param error_message_regex: A list of regular expressions to match against error messages. If any of the regular expressions match, the request will be retried. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#error_message_regex DataAzapiResource#error_message_regex}
        :param interval_seconds: The base number of seconds to wait between retries. Default is ``10``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#interval_seconds DataAzapiResource#interval_seconds}
        :param max_interval_seconds: The maximum number of seconds to wait between retries. Default is ``180``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#max_interval_seconds DataAzapiResource#max_interval_seconds}
        :param multiplier: The multiplier to apply to the interval between retries. Default is ``1.5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#multiplier DataAzapiResource#multiplier}
        :param randomization_factor: The randomization factor to apply to the interval between retries. The formula for the randomized interval is: ``RetryInterval * (random value in range [1 - RandomizationFactor, 1 + RandomizationFactor])``. Therefore set to zero ``0.0`` for no randomization. Default is ``0.5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#randomization_factor DataAzapiResource#randomization_factor}
        '''
        value = DataAzapiResourceRetry(
            error_message_regex=error_message_regex,
            interval_seconds=interval_seconds,
            max_interval_seconds=max_interval_seconds,
            multiplier=multiplier,
            randomization_factor=randomization_factor,
        )

        return typing.cast(None, jsii.invoke(self, "putRetry", [value]))

    @jsii.member(jsii_name="putTimeouts")
    def put_timeouts(self, *, read: typing.Optional[builtins.str] = None) -> None:
        '''
        :param read: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#read DataAzapiResource#read}
        '''
        value = DataAzapiResourceTimeouts(read=read)

        return typing.cast(None, jsii.invoke(self, "putTimeouts", [value]))

    @jsii.member(jsii_name="resetHeaders")
    def reset_headers(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetHeaders", []))

    @jsii.member(jsii_name="resetIgnoreNotFound")
    def reset_ignore_not_found(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIgnoreNotFound", []))

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @jsii.member(jsii_name="resetParentId")
    def reset_parent_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetParentId", []))

    @jsii.member(jsii_name="resetQueryParameters")
    def reset_query_parameters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetQueryParameters", []))

    @jsii.member(jsii_name="resetResourceId")
    def reset_resource_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceId", []))

    @jsii.member(jsii_name="resetResponseExportValues")
    def reset_response_export_values(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResponseExportValues", []))

    @jsii.member(jsii_name="resetRetry")
    def reset_retry(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRetry", []))

    @jsii.member(jsii_name="resetTimeouts")
    def reset_timeouts(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeouts", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="exists")
    def exists(self) -> _cdktf_9a9027ec.IResolvable:
        return typing.cast(_cdktf_9a9027ec.IResolvable, jsii.get(self, "exists"))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @builtins.property
    @jsii.member(jsii_name="identity")
    def identity(self) -> "DataAzapiResourceIdentityList":
        return typing.cast("DataAzapiResourceIdentityList", jsii.get(self, "identity"))

    @builtins.property
    @jsii.member(jsii_name="location")
    def location(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "location"))

    @builtins.property
    @jsii.member(jsii_name="output")
    def output(self) -> _cdktf_9a9027ec.AnyMap:
        return typing.cast(_cdktf_9a9027ec.AnyMap, jsii.get(self, "output"))

    @builtins.property
    @jsii.member(jsii_name="retry")
    def retry(self) -> "DataAzapiResourceRetryOutputReference":
        return typing.cast("DataAzapiResourceRetryOutputReference", jsii.get(self, "retry"))

    @builtins.property
    @jsii.member(jsii_name="tags")
    def tags(self) -> _cdktf_9a9027ec.StringMap:
        return typing.cast(_cdktf_9a9027ec.StringMap, jsii.get(self, "tags"))

    @builtins.property
    @jsii.member(jsii_name="timeouts")
    def timeouts(self) -> "DataAzapiResourceTimeoutsOutputReference":
        return typing.cast("DataAzapiResourceTimeoutsOutputReference", jsii.get(self, "timeouts"))

    @builtins.property
    @jsii.member(jsii_name="headersInput")
    def headers_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], jsii.get(self, "headersInput"))

    @builtins.property
    @jsii.member(jsii_name="ignoreNotFoundInput")
    def ignore_not_found_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]], jsii.get(self, "ignoreNotFoundInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="parentIdInput")
    def parent_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "parentIdInput"))

    @builtins.property
    @jsii.member(jsii_name="queryParametersInput")
    def query_parameters_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]], jsii.get(self, "queryParametersInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceIdInput")
    def resource_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "resourceIdInput"))

    @builtins.property
    @jsii.member(jsii_name="responseExportValuesInput")
    def response_export_values_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], jsii.get(self, "responseExportValuesInput"))

    @builtins.property
    @jsii.member(jsii_name="retryInput")
    def retry_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "DataAzapiResourceRetry"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "DataAzapiResourceRetry"]], jsii.get(self, "retryInput"))

    @builtins.property
    @jsii.member(jsii_name="timeoutsInput")
    def timeouts_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "DataAzapiResourceTimeouts"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "DataAzapiResourceTimeouts"]], jsii.get(self, "timeoutsInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="headers")
    def headers(self) -> typing.Mapping[builtins.str, builtins.str]:
        return typing.cast(typing.Mapping[builtins.str, builtins.str], jsii.get(self, "headers"))

    @headers.setter
    def headers(self, value: typing.Mapping[builtins.str, builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__532d97aa870529660c4bb38e18637d27a329afd791f69324d29e8c23918feacc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "headers", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="ignoreNotFound")
    def ignore_not_found(
        self,
    ) -> typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable], jsii.get(self, "ignoreNotFound"))

    @ignore_not_found.setter
    def ignore_not_found(
        self,
        value: typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7c7b6ba90e6525a0888421f65f18cd2160c9ab5bffd8b8ae5840becb3d9c3e33)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ignoreNotFound", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a49f04a156217b464936ec6285683f722fe2e88d24de4855728301de3368faf2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="parentId")
    def parent_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "parentId"))

    @parent_id.setter
    def parent_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__33be1f50f28912350c4a22da8b162035af549991b54c487195c8fdb4960586f5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "parentId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="queryParameters")
    def query_parameters(
        self,
    ) -> typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]:
        return typing.cast(typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]], jsii.get(self, "queryParameters"))

    @query_parameters.setter
    def query_parameters(
        self,
        value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0b491d5f9a457e87acb9042e9b853667cbeb9fb2cd21cecef5065a2fb4e71ea7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "queryParameters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceId")
    def resource_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "resourceId"))

    @resource_id.setter
    def resource_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__356cd5f181512a85cfff66fa3db791df26401c7b2d626de6392f2519ff9c557a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="responseExportValues")
    def response_export_values(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.get(self, "responseExportValues"))

    @response_export_values.setter
    def response_export_values(
        self,
        value: typing.Mapping[builtins.str, typing.Any],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f9c01a34e566c6937403b0fafb4a100e3abbcc1db069dd1caf8e855db42bdef5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "responseExportValues", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__47046806ff469369bcac6d1865435c667e47641d7c3204ae81407a1285900fdd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.DataAzapiResourceConfig",
    jsii_struct_bases=[_cdktf_9a9027ec.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "type": "type",
        "headers": "headers",
        "ignore_not_found": "ignoreNotFound",
        "name": "name",
        "parent_id": "parentId",
        "query_parameters": "queryParameters",
        "resource_id": "resourceId",
        "response_export_values": "responseExportValues",
        "retry": "retry",
        "timeouts": "timeouts",
    },
)
class DataAzapiResourceConfig(_cdktf_9a9027ec.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        type: builtins.str,
        headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        ignore_not_found: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
        name: typing.Optional[builtins.str] = None,
        parent_id: typing.Optional[builtins.str] = None,
        query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
        resource_id: typing.Optional[builtins.str] = None,
        response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        retry: typing.Optional[typing.Union["DataAzapiResourceRetry", typing.Dict[builtins.str, typing.Any]]] = None,
        timeouts: typing.Optional[typing.Union["DataAzapiResourceTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param type: In a format like ``<resource-type>@<api-version>``. ``<resource-type>`` is the Azure resource type, for example, ``Microsoft.Storage/storageAccounts``. ``<api-version>`` is version of the API used to manage this azure resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#type DataAzapiResource#type}
        :param headers: A map of headers to include in the request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#headers DataAzapiResource#headers}
        :param ignore_not_found: If set to ``true``, the data source will not fail when the specified resource is not found (HTTP 404). Identifier attributes (``id``, ``name``, ``parent_id``, ``resource_id``) will still be populated based on inputs; other computed attributes (``output``, ``location``, ``identity``, ``tags``) will be null/empty. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#ignore_not_found DataAzapiResource#ignore_not_found}
        :param name: Specifies the name of the Azure resource. Exactly one of the arguments ``name`` or ``resource_id`` must be set. It could be omitted if the ``type`` is ``Microsoft.Resources/subscriptions``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#name DataAzapiResource#name}
        :param parent_id: The ID of the azure resource in which this resource is created. It supports different kinds of deployment scope for **top level** resources: - resource group scope: ``parent_id`` should be the ID of a resource group, it's recommended to manage a resource group by azurerm_resource_group. - management group scope: ``parent_id`` should be the ID of a management group, it's recommended to manage a management group by azurerm_management_group. - extension scope: ``parent_id`` should be the ID of the resource you're adding the extension to. - subscription scope: ``parent_id`` should be like \\x60/subscriptions/00000000-0000-0000-0000-000000000000\\x60 - tenant scope: ``parent_id`` should be / For child level resources, the ``parent_id`` should be the ID of its parent resource, for example, subnet resource's ``parent_id`` is the ID of the vnet. For type ``Microsoft.Resources/resourceGroups``, the ``parent_id`` could be omitted, it defaults to subscription ID specified in provider or the default subscription (You could check the default subscription by azure cli command: ``az account show``). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#parent_id DataAzapiResource#parent_id}
        :param query_parameters: A map of query parameters to include in the request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#query_parameters DataAzapiResource#query_parameters}
        :param resource_id: The ID of the Azure resource to retrieve. Exactly one of the arguments ``name`` or ``resource_id`` must be set. It could be omitted if the ``type`` is ``Microsoft.Resources/subscriptions``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#resource_id DataAzapiResource#resource_id}
        :param response_export_values: The attribute can accept either a list or a map. - **List**: A list of paths that need to be exported from the response body. Setting it to ``["*"]`` will export the full response body. Here's an example. If it sets to ``["properties.loginServer", "properties.policies.quarantinePolicy.status"]``, it will set the following HCL object to the computed property output. Example:: { properties = { loginServer = "registry1.azurecr.io" policies = { quarantinePolicy = { status = "disabled" } } } } - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to ``{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}``, it will set the following HCL object to the computed property output. Example:: { "login_server" = "registry1.azurecr.io" "quarantine_status" = "disabled" } To learn more about JMESPath, visit `JMESPath <https://jmespath.org/>`_. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#response_export_values DataAzapiResource#response_export_values}
        :param retry: The retry object supports the following attributes:. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#retry DataAzapiResource#retry}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#timeouts DataAzapiResource#timeouts}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktf_9a9027ec.TerraformResourceLifecycle(**lifecycle)
        if isinstance(retry, dict):
            retry = DataAzapiResourceRetry(**retry)
        if isinstance(timeouts, dict):
            timeouts = DataAzapiResourceTimeouts(**timeouts)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c81d39048b6d0968fcf6fbef1d7ef5bb78330c8ca8858fed7fc798fcffac245b)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            check_type(argname="argument headers", value=headers, expected_type=type_hints["headers"])
            check_type(argname="argument ignore_not_found", value=ignore_not_found, expected_type=type_hints["ignore_not_found"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument parent_id", value=parent_id, expected_type=type_hints["parent_id"])
            check_type(argname="argument query_parameters", value=query_parameters, expected_type=type_hints["query_parameters"])
            check_type(argname="argument resource_id", value=resource_id, expected_type=type_hints["resource_id"])
            check_type(argname="argument response_export_values", value=response_export_values, expected_type=type_hints["response_export_values"])
            check_type(argname="argument retry", value=retry, expected_type=type_hints["retry"])
            check_type(argname="argument timeouts", value=timeouts, expected_type=type_hints["timeouts"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "type": type,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if headers is not None:
            self._values["headers"] = headers
        if ignore_not_found is not None:
            self._values["ignore_not_found"] = ignore_not_found
        if name is not None:
            self._values["name"] = name
        if parent_id is not None:
            self._values["parent_id"] = parent_id
        if query_parameters is not None:
            self._values["query_parameters"] = query_parameters
        if resource_id is not None:
            self._values["resource_id"] = resource_id
        if response_export_values is not None:
            self._values["response_export_values"] = response_export_values
        if retry is not None:
            self._values["retry"] = retry
        if timeouts is not None:
            self._values["timeouts"] = timeouts

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, _cdktf_9a9027ec.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, _cdktf_9a9027ec.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktf_9a9027ec.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktf_9a9027ec.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktf_9a9027ec.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktf_9a9027ec.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktf_9a9027ec.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktf_9a9027ec.FileProvisioner, _cdktf_9a9027ec.LocalExecProvisioner, _cdktf_9a9027ec.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktf_9a9027ec.FileProvisioner, _cdktf_9a9027ec.LocalExecProvisioner, _cdktf_9a9027ec.RemoteExecProvisioner]]], result)

    @builtins.property
    def type(self) -> builtins.str:
        '''In a format like ``<resource-type>@<api-version>``.

        ``<resource-type>`` is the Azure resource type, for example, ``Microsoft.Storage/storageAccounts``. ``<api-version>`` is version of the API used to manage this azure resource.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#type DataAzapiResource#type}
        '''
        result = self._values.get("type")
        assert result is not None, "Required property 'type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def headers(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''A map of headers to include in the request.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#headers DataAzapiResource#headers}
        '''
        result = self._values.get("headers")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def ignore_not_found(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]]:
        '''If set to ``true``, the data source will not fail when the specified resource is not found (HTTP 404).

        Identifier attributes (``id``, ``name``, ``parent_id``, ``resource_id``) will still be populated based on inputs; other computed attributes (``output``, ``location``, ``identity``, ``tags``) will be null/empty. Defaults to ``false``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#ignore_not_found DataAzapiResource#ignore_not_found}
        '''
        result = self._values.get("ignore_not_found")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''Specifies the name of the Azure resource.

        Exactly one of the arguments ``name`` or ``resource_id`` must be set. It could be omitted if the ``type`` is ``Microsoft.Resources/subscriptions``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#name DataAzapiResource#name}
        '''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def parent_id(self) -> typing.Optional[builtins.str]:
        '''The ID of the azure resource in which this resource is created.

        It supports different kinds of deployment scope for **top level** resources:

        - resource group scope: ``parent_id`` should be the ID of a resource group, it's recommended to manage a resource group by azurerm_resource_group.
        - management group scope: ``parent_id`` should be the ID of a management group, it's recommended to manage a management group by azurerm_management_group.
        - extension scope: ``parent_id`` should be the ID of the resource you're adding the extension to.
        - subscription scope: ``parent_id`` should be like \\x60/subscriptions/00000000-0000-0000-0000-000000000000\\x60
        - tenant scope: ``parent_id`` should be /

        For child level resources, the ``parent_id`` should be the ID of its parent resource, for example, subnet resource's ``parent_id`` is the ID of the vnet.

        For type ``Microsoft.Resources/resourceGroups``, the ``parent_id`` could be omitted, it defaults to subscription ID specified in provider or the default subscription (You could check the default subscription by azure cli command: ``az account show``).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#parent_id DataAzapiResource#parent_id}
        '''
        result = self._values.get("parent_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def query_parameters(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]]:
        '''A map of query parameters to include in the request.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#query_parameters DataAzapiResource#query_parameters}
        '''
        result = self._values.get("query_parameters")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]], result)

    @builtins.property
    def resource_id(self) -> typing.Optional[builtins.str]:
        '''The ID of the Azure resource to retrieve.

        Exactly one of the arguments ``name`` or ``resource_id`` must be set. It could be omitted if the ``type`` is ``Microsoft.Resources/subscriptions``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#resource_id DataAzapiResource#resource_id}
        '''
        result = self._values.get("resource_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def response_export_values(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        '''The attribute can accept either a list or a map.

        - **List**: A list of paths that need to be exported from the response body. Setting it to ``["*"]`` will export the full response body. Here's an example. If it sets to ``["properties.loginServer", "properties.policies.quarantinePolicy.status"]``, it will set the following HCL object to the computed property output.

        Example::

           {
           properties = {
           loginServer = "registry1.azurecr.io"
           policies = {
           quarantinePolicy = {
           	status = "disabled"
           }
           }
           }
           }

        - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to ``{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}``, it will set the following HCL object to the computed property output.

        Example::

           {
           "login_server" = "registry1.azurecr.io"
           "quarantine_status" = "disabled"
           }

        To learn more about JMESPath, visit `JMESPath <https://jmespath.org/>`_.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#response_export_values DataAzapiResource#response_export_values}
        '''
        result = self._values.get("response_export_values")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], result)

    @builtins.property
    def retry(self) -> typing.Optional["DataAzapiResourceRetry"]:
        '''The retry object supports the following attributes:.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#retry DataAzapiResource#retry}
        '''
        result = self._values.get("retry")
        return typing.cast(typing.Optional["DataAzapiResourceRetry"], result)

    @builtins.property
    def timeouts(self) -> typing.Optional["DataAzapiResourceTimeouts"]:
        '''timeouts block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#timeouts DataAzapiResource#timeouts}
        '''
        result = self._values.get("timeouts")
        return typing.cast(typing.Optional["DataAzapiResourceTimeouts"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DataAzapiResourceConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.DataAzapiResourceIdentity",
    jsii_struct_bases=[],
    name_mapping={},
)
class DataAzapiResourceIdentity:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DataAzapiResourceIdentity(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class DataAzapiResourceIdentityList(
    _cdktf_9a9027ec.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.DataAzapiResourceIdentityList",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1af1f16ee49f8f1eb006892654b067335c5615e2119218c5b463d4cd44423f71)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "DataAzapiResourceIdentityOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d73de6bb31eacadea85076048396d22000065823db94ddd1398c0ebc6196b7ae)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("DataAzapiResourceIdentityOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c7755a917cdb6be8ff581071fa397721555e704f38079240354d4f1cc8cf58cd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktf_9a9027ec.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktf_9a9027ec.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktf_9a9027ec.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e59e0c1efdfe9e360a8b160c99e164413d90aa08c76354ad57231e66646bf5e9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ce708e452384cc56e89d6a8aa944455b4c1097e39e75cafaefe7183c36be1830)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class DataAzapiResourceIdentityOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.DataAzapiResourceIdentityOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ea14b6293e41393e2fd23f7e4a73431cd1e1137ffb7c53758a4cf2a2fd74affb)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="identityIds")
    def identity_ids(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "identityIds"))

    @builtins.property
    @jsii.member(jsii_name="principalId")
    def principal_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "principalId"))

    @builtins.property
    @jsii.member(jsii_name="tenantId")
    def tenant_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tenantId"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[DataAzapiResourceIdentity]:
        return typing.cast(typing.Optional[DataAzapiResourceIdentity], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional[DataAzapiResourceIdentity]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ce9040397215b4f9cc31e4481741d637cc116b2b4aa4a6bedbce6a1f3336c142)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.DataAzapiResourceRetry",
    jsii_struct_bases=[],
    name_mapping={
        "error_message_regex": "errorMessageRegex",
        "interval_seconds": "intervalSeconds",
        "max_interval_seconds": "maxIntervalSeconds",
        "multiplier": "multiplier",
        "randomization_factor": "randomizationFactor",
    },
)
class DataAzapiResourceRetry:
    def __init__(
        self,
        *,
        error_message_regex: typing.Sequence[builtins.str],
        interval_seconds: typing.Optional[jsii.Number] = None,
        max_interval_seconds: typing.Optional[jsii.Number] = None,
        multiplier: typing.Optional[jsii.Number] = None,
        randomization_factor: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param error_message_regex: A list of regular expressions to match against error messages. If any of the regular expressions match, the request will be retried. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#error_message_regex DataAzapiResource#error_message_regex}
        :param interval_seconds: The base number of seconds to wait between retries. Default is ``10``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#interval_seconds DataAzapiResource#interval_seconds}
        :param max_interval_seconds: The maximum number of seconds to wait between retries. Default is ``180``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#max_interval_seconds DataAzapiResource#max_interval_seconds}
        :param multiplier: The multiplier to apply to the interval between retries. Default is ``1.5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#multiplier DataAzapiResource#multiplier}
        :param randomization_factor: The randomization factor to apply to the interval between retries. The formula for the randomized interval is: ``RetryInterval * (random value in range [1 - RandomizationFactor, 1 + RandomizationFactor])``. Therefore set to zero ``0.0`` for no randomization. Default is ``0.5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#randomization_factor DataAzapiResource#randomization_factor}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7df04d06c2cc51fbca413d1c00ad46d2a1231995725232a29cf8c42c404b954e)
            check_type(argname="argument error_message_regex", value=error_message_regex, expected_type=type_hints["error_message_regex"])
            check_type(argname="argument interval_seconds", value=interval_seconds, expected_type=type_hints["interval_seconds"])
            check_type(argname="argument max_interval_seconds", value=max_interval_seconds, expected_type=type_hints["max_interval_seconds"])
            check_type(argname="argument multiplier", value=multiplier, expected_type=type_hints["multiplier"])
            check_type(argname="argument randomization_factor", value=randomization_factor, expected_type=type_hints["randomization_factor"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "error_message_regex": error_message_regex,
        }
        if interval_seconds is not None:
            self._values["interval_seconds"] = interval_seconds
        if max_interval_seconds is not None:
            self._values["max_interval_seconds"] = max_interval_seconds
        if multiplier is not None:
            self._values["multiplier"] = multiplier
        if randomization_factor is not None:
            self._values["randomization_factor"] = randomization_factor

    @builtins.property
    def error_message_regex(self) -> typing.List[builtins.str]:
        '''A list of regular expressions to match against error messages.

        If any of the regular expressions match, the request will be retried.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#error_message_regex DataAzapiResource#error_message_regex}
        '''
        result = self._values.get("error_message_regex")
        assert result is not None, "Required property 'error_message_regex' is missing"
        return typing.cast(typing.List[builtins.str], result)

    @builtins.property
    def interval_seconds(self) -> typing.Optional[jsii.Number]:
        '''The base number of seconds to wait between retries. Default is ``10``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#interval_seconds DataAzapiResource#interval_seconds}
        '''
        result = self._values.get("interval_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def max_interval_seconds(self) -> typing.Optional[jsii.Number]:
        '''The maximum number of seconds to wait between retries. Default is ``180``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#max_interval_seconds DataAzapiResource#max_interval_seconds}
        '''
        result = self._values.get("max_interval_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def multiplier(self) -> typing.Optional[jsii.Number]:
        '''The multiplier to apply to the interval between retries. Default is ``1.5``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#multiplier DataAzapiResource#multiplier}
        '''
        result = self._values.get("multiplier")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def randomization_factor(self) -> typing.Optional[jsii.Number]:
        '''The randomization factor to apply to the interval between retries.

        The formula for the randomized interval is: ``RetryInterval * (random value in range [1 - RandomizationFactor, 1 + RandomizationFactor])``. Therefore set to zero ``0.0`` for no randomization. Default is ``0.5``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#randomization_factor DataAzapiResource#randomization_factor}
        '''
        result = self._values.get("randomization_factor")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DataAzapiResourceRetry(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class DataAzapiResourceRetryOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.DataAzapiResourceRetryOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2093914b52815f6c9f8f992df1e490405d2fb0eb3ed92c9d12ecd78f76c683d0)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetIntervalSeconds")
    def reset_interval_seconds(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIntervalSeconds", []))

    @jsii.member(jsii_name="resetMaxIntervalSeconds")
    def reset_max_interval_seconds(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMaxIntervalSeconds", []))

    @jsii.member(jsii_name="resetMultiplier")
    def reset_multiplier(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMultiplier", []))

    @jsii.member(jsii_name="resetRandomizationFactor")
    def reset_randomization_factor(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRandomizationFactor", []))

    @builtins.property
    @jsii.member(jsii_name="errorMessageRegexInput")
    def error_message_regex_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "errorMessageRegexInput"))

    @builtins.property
    @jsii.member(jsii_name="intervalSecondsInput")
    def interval_seconds_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "intervalSecondsInput"))

    @builtins.property
    @jsii.member(jsii_name="maxIntervalSecondsInput")
    def max_interval_seconds_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "maxIntervalSecondsInput"))

    @builtins.property
    @jsii.member(jsii_name="multiplierInput")
    def multiplier_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "multiplierInput"))

    @builtins.property
    @jsii.member(jsii_name="randomizationFactorInput")
    def randomization_factor_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "randomizationFactorInput"))

    @builtins.property
    @jsii.member(jsii_name="errorMessageRegex")
    def error_message_regex(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "errorMessageRegex"))

    @error_message_regex.setter
    def error_message_regex(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7a08560fae648b3b5587da5a173b5f7b330ee74ec71188926d8006dd1bc43e84)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "errorMessageRegex", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="intervalSeconds")
    def interval_seconds(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "intervalSeconds"))

    @interval_seconds.setter
    def interval_seconds(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a2813ac3834b9d62cab14b97312422f75191219f69e06ef89e97110a04930650)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "intervalSeconds", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="maxIntervalSeconds")
    def max_interval_seconds(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "maxIntervalSeconds"))

    @max_interval_seconds.setter
    def max_interval_seconds(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5f61a85e616e3222353b76f2e6ba60eb38b06dac1f282e0175f8b23a6ae69827)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "maxIntervalSeconds", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="multiplier")
    def multiplier(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "multiplier"))

    @multiplier.setter
    def multiplier(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1ef580c9234e481bb8cb64902ced476c99a940aa92a2e32553f1b1eb4b7fdd9d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "multiplier", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="randomizationFactor")
    def randomization_factor(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "randomizationFactor"))

    @randomization_factor.setter
    def randomization_factor(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__db016357007f9e31917cffe65e419e26e724e9164b120cb8f4825e4cbc07df46)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "randomizationFactor", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, DataAzapiResourceRetry]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, DataAzapiResourceRetry]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, DataAzapiResourceRetry]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e4f27b8b9a04ee51a1b03e59d5efdc7997eb9cc45d244898d6cc9af1d08e2587)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.DataAzapiResourceTimeouts",
    jsii_struct_bases=[],
    name_mapping={"read": "read"},
)
class DataAzapiResourceTimeouts:
    def __init__(self, *, read: typing.Optional[builtins.str] = None) -> None:
        '''
        :param read: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#read DataAzapiResource#read}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b14e05c954c1083e933078931799aaca03614921080ec3501a0a4da372188b05)
            check_type(argname="argument read", value=read, expected_type=type_hints["read"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if read is not None:
            self._values["read"] = read

    @builtins.property
    def read(self) -> typing.Optional[builtins.str]:
        '''A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/data-sources/resource#read DataAzapiResource#read}
        '''
        result = self._values.get("read")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DataAzapiResourceTimeouts(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class DataAzapiResourceTimeoutsOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.DataAzapiResourceTimeoutsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__183f068e9cac6c72ba2e3837cc9bcc89ba93501fd5abf5143b74944927e66735)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetRead")
    def reset_read(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRead", []))

    @builtins.property
    @jsii.member(jsii_name="readInput")
    def read_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "readInput"))

    @builtins.property
    @jsii.member(jsii_name="read")
    def read(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "read"))

    @read.setter
    def read(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__396e5079c2a95967f0c3551f59fb096a3ea2e0a28556d951c2e7f9bf9e3f67e9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "read", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, DataAzapiResourceTimeouts]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, DataAzapiResourceTimeouts]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, DataAzapiResourceTimeouts]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9843de41b9274baf366d7a3297247ff082f08ded71e4a69545bf5833e132cd45)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.DiagnosticLogConfig",
    jsii_struct_bases=[],
    name_mapping={
        "enabled": "enabled",
        "category": "category",
        "category_group": "categoryGroup",
        "retention_policy": "retentionPolicy",
    },
)
class DiagnosticLogConfig:
    def __init__(
        self,
        *,
        enabled: builtins.bool,
        category: typing.Optional[builtins.str] = None,
        category_group: typing.Optional[builtins.str] = None,
        retention_policy: typing.Optional[typing.Union[_RetentionPolicyConfig_13c42ec6, typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''Log configuration for diagnostic settings.

        :param enabled: 
        :param category: 
        :param category_group: 
        :param retention_policy: 
        '''
        if isinstance(retention_policy, dict):
            retention_policy = _RetentionPolicyConfig_13c42ec6(**retention_policy)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__96fea199b663d9dbe1256ea8303c743d790a1bb46e0ef9a6183d574a3bd2f34b)
            check_type(argname="argument enabled", value=enabled, expected_type=type_hints["enabled"])
            check_type(argname="argument category", value=category, expected_type=type_hints["category"])
            check_type(argname="argument category_group", value=category_group, expected_type=type_hints["category_group"])
            check_type(argname="argument retention_policy", value=retention_policy, expected_type=type_hints["retention_policy"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "enabled": enabled,
        }
        if category is not None:
            self._values["category"] = category
        if category_group is not None:
            self._values["category_group"] = category_group
        if retention_policy is not None:
            self._values["retention_policy"] = retention_policy

    @builtins.property
    def enabled(self) -> builtins.bool:
        result = self._values.get("enabled")
        assert result is not None, "Required property 'enabled' is missing"
        return typing.cast(builtins.bool, result)

    @builtins.property
    def category(self) -> typing.Optional[builtins.str]:
        result = self._values.get("category")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def category_group(self) -> typing.Optional[builtins.str]:
        result = self._values.get("category_group")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def retention_policy(self) -> typing.Optional[_RetentionPolicyConfig_13c42ec6]:
        result = self._values.get("retention_policy")
        return typing.cast(typing.Optional[_RetentionPolicyConfig_13c42ec6], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DiagnosticLogConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.DiagnosticMetricConfig",
    jsii_struct_bases=[],
    name_mapping={
        "category": "category",
        "enabled": "enabled",
        "retention_policy": "retentionPolicy",
    },
)
class DiagnosticMetricConfig:
    def __init__(
        self,
        *,
        category: builtins.str,
        enabled: builtins.bool,
        retention_policy: typing.Optional[typing.Union[_RetentionPolicyConfig_13c42ec6, typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''Metric configuration for diagnostic settings.

        :param category: 
        :param enabled: 
        :param retention_policy: 
        '''
        if isinstance(retention_policy, dict):
            retention_policy = _RetentionPolicyConfig_13c42ec6(**retention_policy)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ad20bcfb2d477281861ea968578dce4848dbca7c10255e4d7a1f910c686b0785)
            check_type(argname="argument category", value=category, expected_type=type_hints["category"])
            check_type(argname="argument enabled", value=enabled, expected_type=type_hints["enabled"])
            check_type(argname="argument retention_policy", value=retention_policy, expected_type=type_hints["retention_policy"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "category": category,
            "enabled": enabled,
        }
        if retention_policy is not None:
            self._values["retention_policy"] = retention_policy

    @builtins.property
    def category(self) -> builtins.str:
        result = self._values.get("category")
        assert result is not None, "Required property 'category' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def enabled(self) -> builtins.bool:
        result = self._values.get("enabled")
        assert result is not None, "Required property 'enabled' is missing"
        return typing.cast(builtins.bool, result)

    @builtins.property
    def retention_policy(self) -> typing.Optional[_RetentionPolicyConfig_13c42ec6]:
        result = self._values.get("retention_policy")
        return typing.cast(typing.Optional[_RetentionPolicyConfig_13c42ec6], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DiagnosticMetricConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.MigrationAnalysis",
    jsii_struct_bases=[],
    name_mapping={
        "automatic_upgrade_possible": "automaticUpgradePossible",
        "breaking_changes": "breakingChanges",
        "compatible": "compatible",
        "estimated_effort": "estimatedEffort",
        "from_version": "fromVersion",
        "to_version": "toVersion",
        "warnings": "warnings",
    },
)
class MigrationAnalysis:
    def __init__(
        self,
        *,
        automatic_upgrade_possible: builtins.bool,
        breaking_changes: typing.Sequence[typing.Union[_BreakingChange_5dc94c31, typing.Dict[builtins.str, typing.Any]]],
        compatible: builtins.bool,
        estimated_effort: builtins.str,
        from_version: builtins.str,
        to_version: builtins.str,
        warnings: typing.Sequence[builtins.str],
    ) -> None:
        '''Migration analysis result.

        Results of analyzing the migration path between two API versions.
        Provides compatibility assessment, effort estimation, and detailed
        guidance for version transitions.

        :param automatic_upgrade_possible: Whether automatic upgrade tooling can handle this migration If true, migration can be largely automated.
        :param breaking_changes: Array of breaking changes that affect the migration Each change includes guidance on how to handle it.
        :param compatible: Whether the migration is backward compatible If true, migration should be straightforward.
        :param estimated_effort: Estimated effort required for the migration Must be one of the MigrationEffort constants.
        :param from_version: Source API version being migrated from.
        :param to_version: Target API version being migrated to.
        :param warnings: Array of non-breaking warnings about the migration May include deprecation notices or recommendations.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6f99329161317c6ea230489d13d3b312b6a9a38e9284fb0793d516aea95891c7)
            check_type(argname="argument automatic_upgrade_possible", value=automatic_upgrade_possible, expected_type=type_hints["automatic_upgrade_possible"])
            check_type(argname="argument breaking_changes", value=breaking_changes, expected_type=type_hints["breaking_changes"])
            check_type(argname="argument compatible", value=compatible, expected_type=type_hints["compatible"])
            check_type(argname="argument estimated_effort", value=estimated_effort, expected_type=type_hints["estimated_effort"])
            check_type(argname="argument from_version", value=from_version, expected_type=type_hints["from_version"])
            check_type(argname="argument to_version", value=to_version, expected_type=type_hints["to_version"])
            check_type(argname="argument warnings", value=warnings, expected_type=type_hints["warnings"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "automatic_upgrade_possible": automatic_upgrade_possible,
            "breaking_changes": breaking_changes,
            "compatible": compatible,
            "estimated_effort": estimated_effort,
            "from_version": from_version,
            "to_version": to_version,
            "warnings": warnings,
        }

    @builtins.property
    def automatic_upgrade_possible(self) -> builtins.bool:
        '''Whether automatic upgrade tooling can handle this migration If true, migration can be largely automated.'''
        result = self._values.get("automatic_upgrade_possible")
        assert result is not None, "Required property 'automatic_upgrade_possible' is missing"
        return typing.cast(builtins.bool, result)

    @builtins.property
    def breaking_changes(self) -> typing.List[_BreakingChange_5dc94c31]:
        '''Array of breaking changes that affect the migration Each change includes guidance on how to handle it.'''
        result = self._values.get("breaking_changes")
        assert result is not None, "Required property 'breaking_changes' is missing"
        return typing.cast(typing.List[_BreakingChange_5dc94c31], result)

    @builtins.property
    def compatible(self) -> builtins.bool:
        '''Whether the migration is backward compatible If true, migration should be straightforward.'''
        result = self._values.get("compatible")
        assert result is not None, "Required property 'compatible' is missing"
        return typing.cast(builtins.bool, result)

    @builtins.property
    def estimated_effort(self) -> builtins.str:
        '''Estimated effort required for the migration Must be one of the MigrationEffort constants.'''
        result = self._values.get("estimated_effort")
        assert result is not None, "Required property 'estimated_effort' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def from_version(self) -> builtins.str:
        '''Source API version being migrated from.

        Example::

            "2024-01-01"
        '''
        result = self._values.get("from_version")
        assert result is not None, "Required property 'from_version' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def to_version(self) -> builtins.str:
        '''Target API version being migrated to.

        Example::

            "2024-11-01"
        '''
        result = self._values.get("to_version")
        assert result is not None, "Required property 'to_version' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def warnings(self) -> typing.List[builtins.str]:
        '''Array of non-breaking warnings about the migration May include deprecation notices or recommendations.'''
        result = self._values.get("warnings")
        assert result is not None, "Required property 'warnings' is missing"
        return typing.cast(typing.List[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "MigrationAnalysis(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class MigrationEffort(
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.MigrationEffort",
):
    '''Migration effort estimation for version transitions.

    Helps developers understand the complexity of migrating between versions
    and plan development resources accordingly.
    '''

    def __init__(self) -> None:
        jsii.create(self.__class__, self, [])

    @jsii.python.classproperty
    @jsii.member(jsii_name="BREAKING")
    def BREAKING(cls) -> builtins.str:
        '''Breaking changes - major refactoring required Estimated time: > 3 days.'''
        return typing.cast(builtins.str, jsii.sget(cls, "BREAKING"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="HIGH")
    def HIGH(cls) -> builtins.str:
        '''High effort - significant manual changes required Estimated time: 1-3 days.'''
        return typing.cast(builtins.str, jsii.sget(cls, "HIGH"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="LOW")
    def LOW(cls) -> builtins.str:
        '''Low effort - mostly automatic with minimal manual changes Estimated time: < 1 hour.'''
        return typing.cast(builtins.str, jsii.sget(cls, "LOW"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="MEDIUM")
    def MEDIUM(cls) -> builtins.str:
        '''Medium effort - some manual changes required Estimated time: 1-8 hours.'''
        return typing.cast(builtins.str, jsii.sget(cls, "MEDIUM"))


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.PropertyDefinition",
    jsii_struct_bases=[],
    name_mapping={
        "data_type": "dataType",
        "added_in_version": "addedInVersion",
        "default_value": "defaultValue",
        "deprecated": "deprecated",
        "description": "description",
        "removed_in_version": "removedInVersion",
        "required": "required",
        "validation": "validation",
    },
)
class PropertyDefinition:
    def __init__(
        self,
        *,
        data_type: builtins.str,
        added_in_version: typing.Optional[builtins.str] = None,
        default_value: typing.Any = None,
        deprecated: typing.Optional[builtins.bool] = None,
        description: typing.Optional[builtins.str] = None,
        removed_in_version: typing.Optional[builtins.str] = None,
        required: typing.Optional[builtins.bool] = None,
        validation: typing.Optional[typing.Sequence[typing.Union[_ValidationRule_f1913ed6, typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> None:
        '''Property definition for API schema.

        Defines the characteristics, validation rules, and metadata for a single
        property in an API schema. This enables type validation, transformation,
        and documentation generation.

        :param data_type: The data type of the property Must be one of the PropertyType constants.
        :param added_in_version: The API version in which this property was added Used for compatibility analysis and migration planning.
        :param default_value: Default value to use if property is not provided Type must match the property type.
        :param deprecated: Whether this property is deprecated If true, usage warnings will be generated. Default: false
        :param description: Human-readable description of the property Used for documentation generation and IDE support.
        :param removed_in_version: The API version in which this property was removed Used for compatibility analysis and migration planning.
        :param required: Whether this property is required If true, the property must be provided by the user. Default: false
        :param validation: Array of validation rules to apply to this property Rules are evaluated in order and all must pass.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__873687013997a56dc83a159d5ec3b08ecea6e26cf9d0e9412bfe53c038a3f8ee)
            check_type(argname="argument data_type", value=data_type, expected_type=type_hints["data_type"])
            check_type(argname="argument added_in_version", value=added_in_version, expected_type=type_hints["added_in_version"])
            check_type(argname="argument default_value", value=default_value, expected_type=type_hints["default_value"])
            check_type(argname="argument deprecated", value=deprecated, expected_type=type_hints["deprecated"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument removed_in_version", value=removed_in_version, expected_type=type_hints["removed_in_version"])
            check_type(argname="argument required", value=required, expected_type=type_hints["required"])
            check_type(argname="argument validation", value=validation, expected_type=type_hints["validation"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "data_type": data_type,
        }
        if added_in_version is not None:
            self._values["added_in_version"] = added_in_version
        if default_value is not None:
            self._values["default_value"] = default_value
        if deprecated is not None:
            self._values["deprecated"] = deprecated
        if description is not None:
            self._values["description"] = description
        if removed_in_version is not None:
            self._values["removed_in_version"] = removed_in_version
        if required is not None:
            self._values["required"] = required
        if validation is not None:
            self._values["validation"] = validation

    @builtins.property
    def data_type(self) -> builtins.str:
        '''The data type of the property Must be one of the PropertyType constants.'''
        result = self._values.get("data_type")
        assert result is not None, "Required property 'data_type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def added_in_version(self) -> typing.Optional[builtins.str]:
        '''The API version in which this property was added Used for compatibility analysis and migration planning.

        Example::

            "2024-01-01"
        '''
        result = self._values.get("added_in_version")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def default_value(self) -> typing.Any:
        '''Default value to use if property is not provided Type must match the property type.'''
        result = self._values.get("default_value")
        return typing.cast(typing.Any, result)

    @builtins.property
    def deprecated(self) -> typing.Optional[builtins.bool]:
        '''Whether this property is deprecated If true, usage warnings will be generated.

        :default: false
        '''
        result = self._values.get("deprecated")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''Human-readable description of the property Used for documentation generation and IDE support.'''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def removed_in_version(self) -> typing.Optional[builtins.str]:
        '''The API version in which this property was removed Used for compatibility analysis and migration planning.

        Example::

            "2025-01-01"
        '''
        result = self._values.get("removed_in_version")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def required(self) -> typing.Optional[builtins.bool]:
        '''Whether this property is required If true, the property must be provided by the user.

        :default: false
        '''
        result = self._values.get("required")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def validation(self) -> typing.Optional[typing.List[_ValidationRule_f1913ed6]]:
        '''Array of validation rules to apply to this property Rules are evaluated in order and all must pass.'''
        result = self._values.get("validation")
        return typing.cast(typing.Optional[typing.List[_ValidationRule_f1913ed6]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PropertyDefinition(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.PropertyMapping",
    jsii_struct_bases=[],
    name_mapping={
        "source_property": "sourceProperty",
        "target_property": "targetProperty",
        "default_value": "defaultValue",
        "required": "required",
        "transformer": "transformer",
    },
)
class PropertyMapping:
    def __init__(
        self,
        *,
        source_property: builtins.str,
        target_property: builtins.str,
        default_value: typing.Any = None,
        required: typing.Optional[builtins.bool] = None,
        transformer: typing.Optional[typing.Union[_PropertyTransformer_9b876b7f, typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''Property mapping definition.

        Defines how a property should be mapped from source to target schema,
        including any transformations or default values to apply.

        :param source_property: The name of the source property.
        :param target_property: The name of the target property.
        :param default_value: Default value to use if source property is not provided.
        :param required: Whether this property is required in the target schema. Default: false
        :param transformer: Optional transformer to apply during mapping.
        '''
        if isinstance(transformer, dict):
            transformer = _PropertyTransformer_9b876b7f(**transformer)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e646261d26230a31efdf6cc86475e2770b333f18140390e5aec8538d4780530b)
            check_type(argname="argument source_property", value=source_property, expected_type=type_hints["source_property"])
            check_type(argname="argument target_property", value=target_property, expected_type=type_hints["target_property"])
            check_type(argname="argument default_value", value=default_value, expected_type=type_hints["default_value"])
            check_type(argname="argument required", value=required, expected_type=type_hints["required"])
            check_type(argname="argument transformer", value=transformer, expected_type=type_hints["transformer"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "source_property": source_property,
            "target_property": target_property,
        }
        if default_value is not None:
            self._values["default_value"] = default_value
        if required is not None:
            self._values["required"] = required
        if transformer is not None:
            self._values["transformer"] = transformer

    @builtins.property
    def source_property(self) -> builtins.str:
        '''The name of the source property.'''
        result = self._values.get("source_property")
        assert result is not None, "Required property 'source_property' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def target_property(self) -> builtins.str:
        '''The name of the target property.'''
        result = self._values.get("target_property")
        assert result is not None, "Required property 'target_property' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def default_value(self) -> typing.Any:
        '''Default value to use if source property is not provided.'''
        result = self._values.get("default_value")
        return typing.cast(typing.Any, result)

    @builtins.property
    def required(self) -> typing.Optional[builtins.bool]:
        '''Whether this property is required in the target schema.

        :default: false
        '''
        result = self._values.get("required")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def transformer(self) -> typing.Optional[_PropertyTransformer_9b876b7f]:
        '''Optional transformer to apply during mapping.'''
        result = self._values.get("transformer")
        return typing.cast(typing.Optional[_PropertyTransformer_9b876b7f], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PropertyMapping(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class PropertyTransformationType(
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.PropertyTransformationType",
):
    '''Property transformation types for schema mapping.

    Defines the types of transformations that can be applied when mapping
    properties between different schema versions.
    '''

    def __init__(self) -> None:
        jsii.create(self.__class__, self, [])

    @jsii.python.classproperty
    @jsii.member(jsii_name="CUSTOM_FUNCTION")
    def CUSTOM_FUNCTION(cls) -> builtins.str:
        '''Apply custom transformation function.'''
        return typing.cast(builtins.str, jsii.sget(cls, "CUSTOM_FUNCTION"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="DIRECT_COPY")
    def DIRECT_COPY(cls) -> builtins.str:
        '''Direct copy with no transformation.'''
        return typing.cast(builtins.str, jsii.sget(cls, "DIRECT_COPY"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="STRUCTURE_TRANSFORMATION")
    def STRUCTURE_TRANSFORMATION(cls) -> builtins.str:
        '''Transform object structure.'''
        return typing.cast(builtins.str, jsii.sget(cls, "STRUCTURE_TRANSFORMATION"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="VALUE_MAPPING")
    def VALUE_MAPPING(cls) -> builtins.str:
        '''Map values using a lookup table.'''
        return typing.cast(builtins.str, jsii.sget(cls, "VALUE_MAPPING"))


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.PropertyTransformer",
    jsii_struct_bases=[],
    name_mapping={"transformation_type": "transformationType", "config": "config"},
)
class PropertyTransformer:
    def __init__(
        self,
        *,
        transformation_type: builtins.str,
        config: typing.Any = None,
    ) -> None:
        '''Property transformation interface for schema mapping.

        Defines how properties should be transformed when mapping between
        different schema versions or formats.

        :param transformation_type: The type of transformation to apply Must be one of the PropertyTransformationType constants.
        :param config: Configuration object for the transformation Structure depends on the transformation type.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9eb55571415bfbdd70d0e9d0a78c13122ab931b54ab8c79380c0fe0044d09e27)
            check_type(argname="argument transformation_type", value=transformation_type, expected_type=type_hints["transformation_type"])
            check_type(argname="argument config", value=config, expected_type=type_hints["config"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "transformation_type": transformation_type,
        }
        if config is not None:
            self._values["config"] = config

    @builtins.property
    def transformation_type(self) -> builtins.str:
        '''The type of transformation to apply Must be one of the PropertyTransformationType constants.'''
        result = self._values.get("transformation_type")
        assert result is not None, "Required property 'transformation_type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def config(self) -> typing.Any:
        '''Configuration object for the transformation Structure depends on the transformation type.'''
        result = self._values.get("config")
        return typing.cast(typing.Any, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PropertyTransformer(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class PropertyType(
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.PropertyType",
):
    '''Property type enumeration for schema definitions.

    Defines the basic data types supported in API schemas for validation
    and transformation purposes.
    '''

    def __init__(self) -> None:
        jsii.create(self.__class__, self, [])

    @jsii.python.classproperty
    @jsii.member(jsii_name="ANY")
    def ANY(cls) -> builtins.str:
        '''Any data type (no validation).'''
        return typing.cast(builtins.str, jsii.sget(cls, "ANY"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="ARRAY")
    def ARRAY(cls) -> builtins.str:
        '''Array data type (ordered collection).'''
        return typing.cast(builtins.str, jsii.sget(cls, "ARRAY"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="BOOLEAN")
    def BOOLEAN(cls) -> builtins.str:
        '''Boolean data type (true/false).'''
        return typing.cast(builtins.str, jsii.sget(cls, "BOOLEAN"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="NUMBER")
    def NUMBER(cls) -> builtins.str:
        '''Numeric data type (integer or float).'''
        return typing.cast(builtins.str, jsii.sget(cls, "NUMBER"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="OBJECT")
    def OBJECT(cls) -> builtins.str:
        '''Object data type (key-value pairs).'''
        return typing.cast(builtins.str, jsii.sget(cls, "OBJECT"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="STRING")
    def STRING(cls) -> builtins.str:
        '''String data type.'''
        return typing.cast(builtins.str, jsii.sget(cls, "STRING"))


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.PropertyValidation",
    jsii_struct_bases=[],
    name_mapping={"property": "property", "rules": "rules"},
)
class PropertyValidation:
    def __init__(
        self,
        *,
        property: builtins.str,
        rules: typing.Sequence[typing.Union[_ValidationRule_f1913ed6, typing.Dict[builtins.str, typing.Any]]],
    ) -> None:
        '''Property validation configuration.

        Defines validation rules that apply to specific properties,
        enabling complex validation scenarios and cross-property validation.

        :param property: The name of the property this validation applies to.
        :param rules: Array of validation rules to apply to this property Rules are evaluated in order and all must pass.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__84adfcff60680f878147cacc881873aa8c2fe2987cde811b86790842bf32bba9)
            check_type(argname="argument property", value=property, expected_type=type_hints["property"])
            check_type(argname="argument rules", value=rules, expected_type=type_hints["rules"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "property": property,
            "rules": rules,
        }

    @builtins.property
    def property(self) -> builtins.str:
        '''The name of the property this validation applies to.'''
        result = self._values.get("property")
        assert result is not None, "Required property 'property' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def rules(self) -> typing.List[_ValidationRule_f1913ed6]:
        '''Array of validation rules to apply to this property Rules are evaluated in order and all must pass.'''
        result = self._values.get("rules")
        assert result is not None, "Required property 'rules' is missing"
        return typing.cast(typing.List[_ValidationRule_f1913ed6], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PropertyValidation(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class Resource(
    _cdktf_9a9027ec.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.Resource",
):
    '''Represents a {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource azapi_resource}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id: builtins.str,
        *,
        type: builtins.str,
        body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        create_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        create_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
        delete_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        delete_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
        identity: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["ResourceIdentity", typing.Dict[builtins.str, typing.Any]]]]] = None,
        ignore_casing: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
        ignore_missing_property: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
        ignore_null_property: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
        location: typing.Optional[builtins.str] = None,
        locks: typing.Optional[typing.Sequence[builtins.str]] = None,
        name: typing.Optional[builtins.str] = None,
        parent_id: typing.Optional[builtins.str] = None,
        read_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        read_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
        replace_triggers_external_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        replace_triggers_refs: typing.Optional[typing.Sequence[builtins.str]] = None,
        response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        retry: typing.Optional[typing.Union["ResourceRetry", typing.Dict[builtins.str, typing.Any]]] = None,
        schema_validation_enabled: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
        sensitive_body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        sensitive_body_version: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        timeouts: typing.Optional[typing.Union["ResourceTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        update_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        update_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource azapi_resource} Resource.

        :param scope: The scope in which to define this construct.
        :param id: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param type: In a format like ``<resource-type>@<api-version>``. ``<resource-type>`` is the Azure resource type, for example, ``Microsoft.Storage/storageAccounts``. ``<api-version>`` is version of the API used to manage this azure resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#type Resource#type}
        :param body: A dynamic attribute that contains the request body. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#body Resource#body}
        :param create_headers: A mapping of headers to be sent with the create request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#create_headers Resource#create_headers}
        :param create_query_parameters: A mapping of query parameters to be sent with the create request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#create_query_parameters Resource#create_query_parameters}
        :param delete_headers: A mapping of headers to be sent with the delete request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#delete_headers Resource#delete_headers}
        :param delete_query_parameters: A mapping of query parameters to be sent with the delete request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#delete_query_parameters Resource#delete_query_parameters}
        :param identity: identity block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#identity Resource#identity}
        :param ignore_casing: Whether ignore the casing of the property names in the response body. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#ignore_casing Resource#ignore_casing}
        :param ignore_missing_property: Whether ignore not returned properties like credentials in ``body`` to suppress plan-diff. Defaults to ``true``. It's recommend to enable this option when some sensitive properties are not returned in response body, instead of setting them in ``lifecycle.ignore_changes`` because it will make the sensitive fields unable to update. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#ignore_missing_property Resource#ignore_missing_property}
        :param ignore_null_property: When set to ``true``, the provider will ignore properties whose values are ``null`` in the ``body``. These properties will not be included in the request body sent to the API, and the difference will not be shown in the plan output. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#ignore_null_property Resource#ignore_null_property}
        :param location: The location of the Azure resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#location Resource#location}
        :param locks: A list of ARM resource IDs which are used to avoid create/modify/delete azapi resources at the same time. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#locks Resource#locks}
        :param name: Specifies the name of the azure resource. Changing this forces a new resource to be created. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#name Resource#name}
        :param parent_id: The ID of the azure resource in which this resource is created. It supports different kinds of deployment scope for **top level** resources: - resource group scope: ``parent_id`` should be the ID of a resource group, it's recommended to manage a resource group by azurerm_resource_group. - management group scope: ``parent_id`` should be the ID of a management group, it's recommended to manage a management group by azurerm_management_group. - extension scope: ``parent_id`` should be the ID of the resource you're adding the extension to. - subscription scope: ``parent_id`` should be like \\x60/subscriptions/00000000-0000-0000-0000-000000000000\\x60 - tenant scope: ``parent_id`` should be / For child level resources, the ``parent_id`` should be the ID of its parent resource, for example, subnet resource's ``parent_id`` is the ID of the vnet. For type ``Microsoft.Resources/resourceGroups``, the ``parent_id`` could be omitted, it defaults to subscription ID specified in provider or the default subscription (You could check the default subscription by azure cli command: ``az account show``). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#parent_id Resource#parent_id}
        :param read_headers: A mapping of headers to be sent with the read request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#read_headers Resource#read_headers}
        :param read_query_parameters: A mapping of query parameters to be sent with the read request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#read_query_parameters Resource#read_query_parameters}
        :param replace_triggers_external_values: Will trigger a replace of the resource when the value changes and is not ``null``. This can be used by practitioners to force a replace of the resource when certain values change, e.g. changing the SKU of a virtual machine based on the value of variables or locals. The value is a ``dynamic``, so practitioners can compose the input however they wish. For a "break glass" set the value to ``null`` to prevent the plan modifier taking effect. If you have ``null`` values that you do want to be tracked as affecting the resource replacement, include these inside an object. Advanced use cases are possible and resource replacement can be triggered by values external to the resource, for example when a dependent resource changes. e.g. to replace a resource when either the SKU or os_type attributes change:: resource "azapi_resource" "example" { name = var.name type = "Microsoft.Network/publicIPAddresses@2023-11-01" parent_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/example" body = { properties = { sku = var.sku zones = var.zones } } replace_triggers_external_values = [ var.sku, var.zones, ] } Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#replace_triggers_external_values Resource#replace_triggers_external_values}
        :param replace_triggers_refs: A list of paths in the current Terraform configuration. When the values at these paths change, the resource will be replaced. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#replace_triggers_refs Resource#replace_triggers_refs}
        :param response_export_values: The attribute can accept either a list or a map. - **List**: A list of paths that need to be exported from the response body. Setting it to ``["*"]`` will export the full response body. Here's an example. If it sets to ``["properties.loginServer", "properties.policies.quarantinePolicy.status"]``, it will set the following HCL object to the computed property output. Example:: { properties = { loginServer = "registry1.azurecr.io" policies = { quarantinePolicy = { status = "disabled" } } } } - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to ``{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}``, it will set the following HCL object to the computed property output. Example:: { "login_server" = "registry1.azurecr.io" "quarantine_status" = "disabled" } To learn more about JMESPath, visit `JMESPath <https://jmespath.org/>`_. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#response_export_values Resource#response_export_values}
        :param retry: The retry object supports the following attributes:. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#retry Resource#retry}
        :param schema_validation_enabled: Whether enabled the validation on ``type`` and ``body`` with embedded schema. Defaults to ``true``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#schema_validation_enabled Resource#schema_validation_enabled}
        :param sensitive_body: A dynamic attribute that contains the write-only properties of the request body. This will be merge-patched to the body to construct the actual request body. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#sensitive_body Resource#sensitive_body}
        :param sensitive_body_version: A map where the key is the path to the property in ``sensitive_body`` and the value is the version of the property. The key is a string in the format of ``path.to.property[index].subproperty``, where ``index`` is the index of the item in an array. When the version is changed, the property will be included in the request body, otherwise it will be omitted from the request body. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#sensitive_body_version Resource#sensitive_body_version}
        :param tags: A mapping of tags which should be assigned to the Azure resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#tags Resource#tags}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#timeouts Resource#timeouts}
        :param update_headers: A mapping of headers to be sent with the update request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#update_headers Resource#update_headers}
        :param update_query_parameters: A mapping of query parameters to be sent with the update request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#update_query_parameters Resource#update_query_parameters}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__360cf756a18f01faf6eea402730f531aef83cf5f1f419da649a2e9b5928d74ad)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        config = ResourceConfig(
            type=type,
            body=body,
            create_headers=create_headers,
            create_query_parameters=create_query_parameters,
            delete_headers=delete_headers,
            delete_query_parameters=delete_query_parameters,
            identity=identity,
            ignore_casing=ignore_casing,
            ignore_missing_property=ignore_missing_property,
            ignore_null_property=ignore_null_property,
            location=location,
            locks=locks,
            name=name,
            parent_id=parent_id,
            read_headers=read_headers,
            read_query_parameters=read_query_parameters,
            replace_triggers_external_values=replace_triggers_external_values,
            replace_triggers_refs=replace_triggers_refs,
            response_export_values=response_export_values,
            retry=retry,
            schema_validation_enabled=schema_validation_enabled,
            sensitive_body=sensitive_body,
            sensitive_body_version=sensitive_body_version,
            tags=tags,
            timeouts=timeouts,
            update_headers=update_headers,
            update_query_parameters=update_query_parameters,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id, config])

    @jsii.member(jsii_name="putIdentity")
    def put_identity(
        self,
        value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["ResourceIdentity", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6f150919e21a56a085faf5046991755e5048d66d84d4b475e7fe138f81dbc7be)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putIdentity", [value]))

    @jsii.member(jsii_name="putRetry")
    def put_retry(
        self,
        *,
        error_message_regex: typing.Sequence[builtins.str],
        interval_seconds: typing.Optional[jsii.Number] = None,
        max_interval_seconds: typing.Optional[jsii.Number] = None,
        multiplier: typing.Optional[jsii.Number] = None,
        randomization_factor: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param error_message_regex: A list of regular expressions to match against error messages. If any of the regular expressions match, the request will be retried. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#error_message_regex Resource#error_message_regex}
        :param interval_seconds: The base number of seconds to wait between retries. Default is ``10``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#interval_seconds Resource#interval_seconds}
        :param max_interval_seconds: The maximum number of seconds to wait between retries. Default is ``180``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#max_interval_seconds Resource#max_interval_seconds}
        :param multiplier: The multiplier to apply to the interval between retries. Default is ``1.5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#multiplier Resource#multiplier}
        :param randomization_factor: The randomization factor to apply to the interval between retries. The formula for the randomized interval is: ``RetryInterval * (random value in range [1 - RandomizationFactor, 1 + RandomizationFactor])``. Therefore set to zero ``0.0`` for no randomization. Default is ``0.5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#randomization_factor Resource#randomization_factor}
        '''
        value = ResourceRetry(
            error_message_regex=error_message_regex,
            interval_seconds=interval_seconds,
            max_interval_seconds=max_interval_seconds,
            multiplier=multiplier,
            randomization_factor=randomization_factor,
        )

        return typing.cast(None, jsii.invoke(self, "putRetry", [value]))

    @jsii.member(jsii_name="putTimeouts")
    def put_timeouts(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#create Resource#create}
        :param delete: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#delete Resource#delete}
        :param read: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#read Resource#read}
        :param update: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#update Resource#update}
        '''
        value = ResourceTimeouts(
            create=create, delete=delete, read=read, update=update
        )

        return typing.cast(None, jsii.invoke(self, "putTimeouts", [value]))

    @jsii.member(jsii_name="resetBody")
    def reset_body(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBody", []))

    @jsii.member(jsii_name="resetCreateHeaders")
    def reset_create_headers(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCreateHeaders", []))

    @jsii.member(jsii_name="resetCreateQueryParameters")
    def reset_create_query_parameters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCreateQueryParameters", []))

    @jsii.member(jsii_name="resetDeleteHeaders")
    def reset_delete_headers(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDeleteHeaders", []))

    @jsii.member(jsii_name="resetDeleteQueryParameters")
    def reset_delete_query_parameters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDeleteQueryParameters", []))

    @jsii.member(jsii_name="resetIdentity")
    def reset_identity(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIdentity", []))

    @jsii.member(jsii_name="resetIgnoreCasing")
    def reset_ignore_casing(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIgnoreCasing", []))

    @jsii.member(jsii_name="resetIgnoreMissingProperty")
    def reset_ignore_missing_property(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIgnoreMissingProperty", []))

    @jsii.member(jsii_name="resetIgnoreNullProperty")
    def reset_ignore_null_property(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIgnoreNullProperty", []))

    @jsii.member(jsii_name="resetLocation")
    def reset_location(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetLocation", []))

    @jsii.member(jsii_name="resetLocks")
    def reset_locks(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetLocks", []))

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @jsii.member(jsii_name="resetParentId")
    def reset_parent_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetParentId", []))

    @jsii.member(jsii_name="resetReadHeaders")
    def reset_read_headers(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReadHeaders", []))

    @jsii.member(jsii_name="resetReadQueryParameters")
    def reset_read_query_parameters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReadQueryParameters", []))

    @jsii.member(jsii_name="resetReplaceTriggersExternalValues")
    def reset_replace_triggers_external_values(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceTriggersExternalValues", []))

    @jsii.member(jsii_name="resetReplaceTriggersRefs")
    def reset_replace_triggers_refs(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceTriggersRefs", []))

    @jsii.member(jsii_name="resetResponseExportValues")
    def reset_response_export_values(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResponseExportValues", []))

    @jsii.member(jsii_name="resetRetry")
    def reset_retry(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRetry", []))

    @jsii.member(jsii_name="resetSchemaValidationEnabled")
    def reset_schema_validation_enabled(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSchemaValidationEnabled", []))

    @jsii.member(jsii_name="resetSensitiveBody")
    def reset_sensitive_body(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSensitiveBody", []))

    @jsii.member(jsii_name="resetSensitiveBodyVersion")
    def reset_sensitive_body_version(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSensitiveBodyVersion", []))

    @jsii.member(jsii_name="resetTags")
    def reset_tags(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTags", []))

    @jsii.member(jsii_name="resetTimeouts")
    def reset_timeouts(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeouts", []))

    @jsii.member(jsii_name="resetUpdateHeaders")
    def reset_update_headers(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUpdateHeaders", []))

    @jsii.member(jsii_name="resetUpdateQueryParameters")
    def reset_update_query_parameters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUpdateQueryParameters", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @builtins.property
    @jsii.member(jsii_name="identity")
    def identity(self) -> "ResourceIdentityList":
        return typing.cast("ResourceIdentityList", jsii.get(self, "identity"))

    @builtins.property
    @jsii.member(jsii_name="output")
    def output(self) -> _cdktf_9a9027ec.AnyMap:
        return typing.cast(_cdktf_9a9027ec.AnyMap, jsii.get(self, "output"))

    @builtins.property
    @jsii.member(jsii_name="retry")
    def retry(self) -> "ResourceRetryOutputReference":
        return typing.cast("ResourceRetryOutputReference", jsii.get(self, "retry"))

    @builtins.property
    @jsii.member(jsii_name="timeouts")
    def timeouts(self) -> "ResourceTimeoutsOutputReference":
        return typing.cast("ResourceTimeoutsOutputReference", jsii.get(self, "timeouts"))

    @builtins.property
    @jsii.member(jsii_name="bodyInput")
    def body_input(self) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], jsii.get(self, "bodyInput"))

    @builtins.property
    @jsii.member(jsii_name="createHeadersInput")
    def create_headers_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], jsii.get(self, "createHeadersInput"))

    @builtins.property
    @jsii.member(jsii_name="createQueryParametersInput")
    def create_query_parameters_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]], jsii.get(self, "createQueryParametersInput"))

    @builtins.property
    @jsii.member(jsii_name="deleteHeadersInput")
    def delete_headers_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], jsii.get(self, "deleteHeadersInput"))

    @builtins.property
    @jsii.member(jsii_name="deleteQueryParametersInput")
    def delete_query_parameters_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]], jsii.get(self, "deleteQueryParametersInput"))

    @builtins.property
    @jsii.member(jsii_name="identityInput")
    def identity_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["ResourceIdentity"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["ResourceIdentity"]]], jsii.get(self, "identityInput"))

    @builtins.property
    @jsii.member(jsii_name="ignoreCasingInput")
    def ignore_casing_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]], jsii.get(self, "ignoreCasingInput"))

    @builtins.property
    @jsii.member(jsii_name="ignoreMissingPropertyInput")
    def ignore_missing_property_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]], jsii.get(self, "ignoreMissingPropertyInput"))

    @builtins.property
    @jsii.member(jsii_name="ignoreNullPropertyInput")
    def ignore_null_property_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]], jsii.get(self, "ignoreNullPropertyInput"))

    @builtins.property
    @jsii.member(jsii_name="locationInput")
    def location_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "locationInput"))

    @builtins.property
    @jsii.member(jsii_name="locksInput")
    def locks_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "locksInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="parentIdInput")
    def parent_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "parentIdInput"))

    @builtins.property
    @jsii.member(jsii_name="readHeadersInput")
    def read_headers_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], jsii.get(self, "readHeadersInput"))

    @builtins.property
    @jsii.member(jsii_name="readQueryParametersInput")
    def read_query_parameters_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]], jsii.get(self, "readQueryParametersInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceTriggersExternalValuesInput")
    def replace_triggers_external_values_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], jsii.get(self, "replaceTriggersExternalValuesInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceTriggersRefsInput")
    def replace_triggers_refs_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "replaceTriggersRefsInput"))

    @builtins.property
    @jsii.member(jsii_name="responseExportValuesInput")
    def response_export_values_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], jsii.get(self, "responseExportValuesInput"))

    @builtins.property
    @jsii.member(jsii_name="retryInput")
    def retry_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "ResourceRetry"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "ResourceRetry"]], jsii.get(self, "retryInput"))

    @builtins.property
    @jsii.member(jsii_name="schemaValidationEnabledInput")
    def schema_validation_enabled_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]], jsii.get(self, "schemaValidationEnabledInput"))

    @builtins.property
    @jsii.member(jsii_name="sensitiveBodyInput")
    def sensitive_body_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], jsii.get(self, "sensitiveBodyInput"))

    @builtins.property
    @jsii.member(jsii_name="sensitiveBodyVersionInput")
    def sensitive_body_version_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], jsii.get(self, "sensitiveBodyVersionInput"))

    @builtins.property
    @jsii.member(jsii_name="tagsInput")
    def tags_input(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], jsii.get(self, "tagsInput"))

    @builtins.property
    @jsii.member(jsii_name="timeoutsInput")
    def timeouts_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "ResourceTimeouts"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "ResourceTimeouts"]], jsii.get(self, "timeoutsInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="updateHeadersInput")
    def update_headers_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], jsii.get(self, "updateHeadersInput"))

    @builtins.property
    @jsii.member(jsii_name="updateQueryParametersInput")
    def update_query_parameters_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]], jsii.get(self, "updateQueryParametersInput"))

    @builtins.property
    @jsii.member(jsii_name="body")
    def body(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.get(self, "body"))

    @body.setter
    def body(self, value: typing.Mapping[builtins.str, typing.Any]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__98edd861ded07fa7bbcb64cbb23535c57c7912b9ea044420e57e4ab49aa2f676)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "body", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="createHeaders")
    def create_headers(self) -> typing.Mapping[builtins.str, builtins.str]:
        return typing.cast(typing.Mapping[builtins.str, builtins.str], jsii.get(self, "createHeaders"))

    @create_headers.setter
    def create_headers(self, value: typing.Mapping[builtins.str, builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e5bc5a1a4b0c645ec8f5b08757f4da96be098885bb6fcc8a04471cf13ccd1974)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "createHeaders", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="createQueryParameters")
    def create_query_parameters(
        self,
    ) -> typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]:
        return typing.cast(typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]], jsii.get(self, "createQueryParameters"))

    @create_query_parameters.setter
    def create_query_parameters(
        self,
        value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1b0cb7f0c1c1b9b4eafd1bb02195514e3a9b02c438cdf43b145ba46350d14af9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "createQueryParameters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="deleteHeaders")
    def delete_headers(self) -> typing.Mapping[builtins.str, builtins.str]:
        return typing.cast(typing.Mapping[builtins.str, builtins.str], jsii.get(self, "deleteHeaders"))

    @delete_headers.setter
    def delete_headers(self, value: typing.Mapping[builtins.str, builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0b854cd284c7651abfa4dca18251d596d0ac808fa1daeb955602022f1d36881f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "deleteHeaders", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="deleteQueryParameters")
    def delete_query_parameters(
        self,
    ) -> typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]:
        return typing.cast(typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]], jsii.get(self, "deleteQueryParameters"))

    @delete_query_parameters.setter
    def delete_query_parameters(
        self,
        value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__af650baa6c89b699d2aaeb9dae047a1ab73f14735ea5566040864cc31b9a10de)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "deleteQueryParameters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="ignoreCasing")
    def ignore_casing(self) -> typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable], jsii.get(self, "ignoreCasing"))

    @ignore_casing.setter
    def ignore_casing(
        self,
        value: typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7c330a3da38779fdfde9ce7876aee87039a107dd1abf1ad4a70965d7f6ac24c6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ignoreCasing", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="ignoreMissingProperty")
    def ignore_missing_property(
        self,
    ) -> typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable], jsii.get(self, "ignoreMissingProperty"))

    @ignore_missing_property.setter
    def ignore_missing_property(
        self,
        value: typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__45eb6abb157ab6d63e1946c17ac812308f7b4d3d395a192022c6b5672892d0c7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ignoreMissingProperty", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="ignoreNullProperty")
    def ignore_null_property(
        self,
    ) -> typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable], jsii.get(self, "ignoreNullProperty"))

    @ignore_null_property.setter
    def ignore_null_property(
        self,
        value: typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4f29ee916ad478f0f1c3d6eec138b84bc516b8bbf1688f25c659ac0a959395ec)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ignoreNullProperty", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="location")
    def location(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "location"))

    @location.setter
    def location(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__40de70c0c8f1eff71f3465ca96a211867eda879e736c0cdd0dd8721bf2d5eae8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "location", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="locks")
    def locks(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "locks"))

    @locks.setter
    def locks(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__41946711b488d86ee4066511bd326ba8fae0292a07da47b826ea818e435cc601)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "locks", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9e8c2a738ac0a7e986617e7c476e73a630939a10ea67d5631700063935a529e3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="parentId")
    def parent_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "parentId"))

    @parent_id.setter
    def parent_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4702438dc870ea43d45f3b2e9b7d7e15df9b998e7e4eb78bd0ab2f3165f95998)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "parentId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="readHeaders")
    def read_headers(self) -> typing.Mapping[builtins.str, builtins.str]:
        return typing.cast(typing.Mapping[builtins.str, builtins.str], jsii.get(self, "readHeaders"))

    @read_headers.setter
    def read_headers(self, value: typing.Mapping[builtins.str, builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__38d805fbcbb389aafed2b0a7e878ea19eaa04ace49cc995fbe48daad165cf782)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "readHeaders", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="readQueryParameters")
    def read_query_parameters(
        self,
    ) -> typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]:
        return typing.cast(typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]], jsii.get(self, "readQueryParameters"))

    @read_query_parameters.setter
    def read_query_parameters(
        self,
        value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f8604726bdf155a156d6c5024a7ec71e5a60cd842b7b9edf9ef6891e8bde8be5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "readQueryParameters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceTriggersExternalValues")
    def replace_triggers_external_values(
        self,
    ) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.get(self, "replaceTriggersExternalValues"))

    @replace_triggers_external_values.setter
    def replace_triggers_external_values(
        self,
        value: typing.Mapping[builtins.str, typing.Any],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3d60c8fdfa7bcf46fee2e9e31f278fe66ee35ff6a452d2cd492b936672bf08df)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceTriggersExternalValues", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceTriggersRefs")
    def replace_triggers_refs(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "replaceTriggersRefs"))

    @replace_triggers_refs.setter
    def replace_triggers_refs(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c3ba278ec6bc25bc8f200ac1f3aad8f7e7278ebb9ed40968b75dc5924cc2f86a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceTriggersRefs", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="responseExportValues")
    def response_export_values(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.get(self, "responseExportValues"))

    @response_export_values.setter
    def response_export_values(
        self,
        value: typing.Mapping[builtins.str, typing.Any],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b141e7bfa993c4527bb95583fb32e65e1c81ec037a0f4c87ba003e74231a0335)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "responseExportValues", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="schemaValidationEnabled")
    def schema_validation_enabled(
        self,
    ) -> typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable], jsii.get(self, "schemaValidationEnabled"))

    @schema_validation_enabled.setter
    def schema_validation_enabled(
        self,
        value: typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3988d4dcdc80fe58d6bfe5b0833246562b217d8f9103298f3c08cf563ac4e6ab)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "schemaValidationEnabled", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="sensitiveBody")
    def sensitive_body(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.get(self, "sensitiveBody"))

    @sensitive_body.setter
    def sensitive_body(self, value: typing.Mapping[builtins.str, typing.Any]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a823ed51d1ce9ba6c69a4c8b3a7c22a9c794ed9aaf9df9b3d97fb6b3ea0a36d5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "sensitiveBody", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="sensitiveBodyVersion")
    def sensitive_body_version(self) -> typing.Mapping[builtins.str, builtins.str]:
        return typing.cast(typing.Mapping[builtins.str, builtins.str], jsii.get(self, "sensitiveBodyVersion"))

    @sensitive_body_version.setter
    def sensitive_body_version(
        self,
        value: typing.Mapping[builtins.str, builtins.str],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__837e68941d7639aceeb0dcd7db90ae3688b8ce5c6711934421026b3538e55f54)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "sensitiveBodyVersion", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tags")
    def tags(self) -> typing.Mapping[builtins.str, builtins.str]:
        return typing.cast(typing.Mapping[builtins.str, builtins.str], jsii.get(self, "tags"))

    @tags.setter
    def tags(self, value: typing.Mapping[builtins.str, builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a6889b4d7b37bf070255471d414ce1869f19c41af6a3132e05b7ae71ae022133)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tags", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__22aad63a3939465809abf1ce8416c25ba8fe259012c462900fcccb00d1b613fa)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="updateHeaders")
    def update_headers(self) -> typing.Mapping[builtins.str, builtins.str]:
        return typing.cast(typing.Mapping[builtins.str, builtins.str], jsii.get(self, "updateHeaders"))

    @update_headers.setter
    def update_headers(self, value: typing.Mapping[builtins.str, builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ca3eb787ce2c0134489014db653c496820e374931e9387e965898d0a3d74292f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "updateHeaders", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="updateQueryParameters")
    def update_query_parameters(
        self,
    ) -> typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]:
        return typing.cast(typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]], jsii.get(self, "updateQueryParameters"))

    @update_query_parameters.setter
    def update_query_parameters(
        self,
        value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__665b7816c8fb83eb81099827eba36497d576d48a89b25694c45b88f3faff00ea)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "updateQueryParameters", value) # pyright: ignore[reportArgumentType]


class ResourceAction(
    _cdktf_9a9027ec.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.ResourceAction",
):
    '''Represents a {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action azapi_resource_action}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id: builtins.str,
        *,
        resource_id: builtins.str,
        type: builtins.str,
        action: typing.Optional[builtins.str] = None,
        body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        locks: typing.Optional[typing.Sequence[builtins.str]] = None,
        method: typing.Optional[builtins.str] = None,
        query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
        response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        retry: typing.Optional[typing.Union["ResourceActionRetry", typing.Dict[builtins.str, typing.Any]]] = None,
        sensitive_response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        timeouts: typing.Optional[typing.Union["ResourceActionTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        when: typing.Optional[builtins.str] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action azapi_resource_action} Resource.

        :param scope: The scope in which to define this construct.
        :param id: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param resource_id: The ID of an existing Azure source. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#resource_id ResourceAction#resource_id}
        :param type: In a format like ``<resource-type>@<api-version>``. ``<resource-type>`` is the Azure resource type, for example, ``Microsoft.Storage/storageAccounts``. ``<api-version>`` is version of the API used to manage this azure resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#type ResourceAction#type}
        :param action: The name of the resource action. It's also possible to make HTTP requests towards the resource ID if leave this field empty. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#action ResourceAction#action}
        :param body: A dynamic attribute that contains the request body. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#body ResourceAction#body}
        :param headers: A map of headers to include in the request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#headers ResourceAction#headers}
        :param locks: A list of ARM resource IDs which are used to avoid create/modify/delete azapi resources at the same time. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#locks ResourceAction#locks}
        :param method: Specifies the HTTP method of the azure resource action. Allowed values are ``POST``, ``PATCH``, ``PUT`` and ``DELETE``. Defaults to ``POST``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#method ResourceAction#method}
        :param query_parameters: A map of query parameters to include in the request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#query_parameters ResourceAction#query_parameters}
        :param response_export_values: The attribute can accept either a list or a map. - **List**: A list of paths that need to be exported from the response body. Setting it to ``["*"]`` will export the full response body. Here's an example. If it sets to ``["properties.loginServer", "properties.policies.quarantinePolicy.status"]``, it will set the following HCL object to the computed property output. Example:: { properties = { loginServer = "registry1.azurecr.io" policies = { quarantinePolicy = { status = "disabled" } } } } - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to ``{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}``, it will set the following HCL object to the computed property output. Example:: { "login_server" = "registry1.azurecr.io" "quarantine_status" = "disabled" } To learn more about JMESPath, visit `JMESPath <https://jmespath.org/>`_. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#response_export_values ResourceAction#response_export_values}
        :param retry: The retry object supports the following attributes:. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#retry ResourceAction#retry}
        :param sensitive_response_export_values: The attribute can accept either a list or a map. - **List**: A list of paths that need to be exported from the response body. Setting it to ``["*"]`` will export the full response body. Here's an example. If it sets to ``["properties.loginServer", "properties.policies.quarantinePolicy.status"]``, it will set the following HCL object to the computed property output. Example:: { properties = { loginServer = "registry1.azurecr.io" policies = { quarantinePolicy = { status = "disabled" } } } } - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to ``{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}``, it will set the following HCL object to the computed property output. Example:: { "login_server" = "registry1.azurecr.io" "quarantine_status" = "disabled" } To learn more about JMESPath, visit `JMESPath <https://jmespath.org/>`_. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#sensitive_response_export_values ResourceAction#sensitive_response_export_values}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#timeouts ResourceAction#timeouts}
        :param when: When to perform the action, value must be one of: ``apply``, ``destroy``. Default is ``apply``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#when ResourceAction#when}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__da027795a53c827c06f63ae41ff835cffcd5a4ec2fddea4d23dd77566dcdced2)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        config = ResourceActionConfig(
            resource_id=resource_id,
            type=type,
            action=action,
            body=body,
            headers=headers,
            locks=locks,
            method=method,
            query_parameters=query_parameters,
            response_export_values=response_export_values,
            retry=retry,
            sensitive_response_export_values=sensitive_response_export_values,
            timeouts=timeouts,
            when=when,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id, config])

    @jsii.member(jsii_name="putRetry")
    def put_retry(
        self,
        *,
        error_message_regex: typing.Sequence[builtins.str],
        interval_seconds: typing.Optional[jsii.Number] = None,
        max_interval_seconds: typing.Optional[jsii.Number] = None,
        multiplier: typing.Optional[jsii.Number] = None,
        randomization_factor: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param error_message_regex: A list of regular expressions to match against error messages. If any of the regular expressions match, the request will be retried. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#error_message_regex ResourceAction#error_message_regex}
        :param interval_seconds: The base number of seconds to wait between retries. Default is ``10``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#interval_seconds ResourceAction#interval_seconds}
        :param max_interval_seconds: The maximum number of seconds to wait between retries. Default is ``180``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#max_interval_seconds ResourceAction#max_interval_seconds}
        :param multiplier: The multiplier to apply to the interval between retries. Default is ``1.5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#multiplier ResourceAction#multiplier}
        :param randomization_factor: The randomization factor to apply to the interval between retries. The formula for the randomized interval is: ``RetryInterval * (random value in range [1 - RandomizationFactor, 1 + RandomizationFactor])``. Therefore set to zero ``0.0`` for no randomization. Default is ``0.5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#randomization_factor ResourceAction#randomization_factor}
        '''
        value = ResourceActionRetry(
            error_message_regex=error_message_regex,
            interval_seconds=interval_seconds,
            max_interval_seconds=max_interval_seconds,
            multiplier=multiplier,
            randomization_factor=randomization_factor,
        )

        return typing.cast(None, jsii.invoke(self, "putRetry", [value]))

    @jsii.member(jsii_name="putTimeouts")
    def put_timeouts(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#create ResourceAction#create}
        :param delete: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#delete ResourceAction#delete}
        :param read: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#read ResourceAction#read}
        :param update: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#update ResourceAction#update}
        '''
        value = ResourceActionTimeouts(
            create=create, delete=delete, read=read, update=update
        )

        return typing.cast(None, jsii.invoke(self, "putTimeouts", [value]))

    @jsii.member(jsii_name="resetAction")
    def reset_action(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAction", []))

    @jsii.member(jsii_name="resetBody")
    def reset_body(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBody", []))

    @jsii.member(jsii_name="resetHeaders")
    def reset_headers(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetHeaders", []))

    @jsii.member(jsii_name="resetLocks")
    def reset_locks(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetLocks", []))

    @jsii.member(jsii_name="resetMethod")
    def reset_method(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMethod", []))

    @jsii.member(jsii_name="resetQueryParameters")
    def reset_query_parameters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetQueryParameters", []))

    @jsii.member(jsii_name="resetResponseExportValues")
    def reset_response_export_values(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResponseExportValues", []))

    @jsii.member(jsii_name="resetRetry")
    def reset_retry(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRetry", []))

    @jsii.member(jsii_name="resetSensitiveResponseExportValues")
    def reset_sensitive_response_export_values(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSensitiveResponseExportValues", []))

    @jsii.member(jsii_name="resetTimeouts")
    def reset_timeouts(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeouts", []))

    @jsii.member(jsii_name="resetWhen")
    def reset_when(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetWhen", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @builtins.property
    @jsii.member(jsii_name="output")
    def output(self) -> _cdktf_9a9027ec.AnyMap:
        return typing.cast(_cdktf_9a9027ec.AnyMap, jsii.get(self, "output"))

    @builtins.property
    @jsii.member(jsii_name="retry")
    def retry(self) -> "ResourceActionRetryOutputReference":
        return typing.cast("ResourceActionRetryOutputReference", jsii.get(self, "retry"))

    @builtins.property
    @jsii.member(jsii_name="sensitiveOutput")
    def sensitive_output(self) -> _cdktf_9a9027ec.AnyMap:
        return typing.cast(_cdktf_9a9027ec.AnyMap, jsii.get(self, "sensitiveOutput"))

    @builtins.property
    @jsii.member(jsii_name="timeouts")
    def timeouts(self) -> "ResourceActionTimeoutsOutputReference":
        return typing.cast("ResourceActionTimeoutsOutputReference", jsii.get(self, "timeouts"))

    @builtins.property
    @jsii.member(jsii_name="actionInput")
    def action_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "actionInput"))

    @builtins.property
    @jsii.member(jsii_name="bodyInput")
    def body_input(self) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], jsii.get(self, "bodyInput"))

    @builtins.property
    @jsii.member(jsii_name="headersInput")
    def headers_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], jsii.get(self, "headersInput"))

    @builtins.property
    @jsii.member(jsii_name="locksInput")
    def locks_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "locksInput"))

    @builtins.property
    @jsii.member(jsii_name="methodInput")
    def method_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "methodInput"))

    @builtins.property
    @jsii.member(jsii_name="queryParametersInput")
    def query_parameters_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]], jsii.get(self, "queryParametersInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceIdInput")
    def resource_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "resourceIdInput"))

    @builtins.property
    @jsii.member(jsii_name="responseExportValuesInput")
    def response_export_values_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], jsii.get(self, "responseExportValuesInput"))

    @builtins.property
    @jsii.member(jsii_name="retryInput")
    def retry_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "ResourceActionRetry"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "ResourceActionRetry"]], jsii.get(self, "retryInput"))

    @builtins.property
    @jsii.member(jsii_name="sensitiveResponseExportValuesInput")
    def sensitive_response_export_values_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], jsii.get(self, "sensitiveResponseExportValuesInput"))

    @builtins.property
    @jsii.member(jsii_name="timeoutsInput")
    def timeouts_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "ResourceActionTimeouts"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "ResourceActionTimeouts"]], jsii.get(self, "timeoutsInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="whenInput")
    def when_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "whenInput"))

    @builtins.property
    @jsii.member(jsii_name="action")
    def action(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "action"))

    @action.setter
    def action(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e6cf10e33b1f20cd2e69e1c8e976bd035ef6b55b4ce733d91ee6d726e849ecd3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "action", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="body")
    def body(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.get(self, "body"))

    @body.setter
    def body(self, value: typing.Mapping[builtins.str, typing.Any]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__29829d45a45a8dab2ef641af59ea0c16d8cba8b01a5760d0aba179f21f37b581)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "body", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="headers")
    def headers(self) -> typing.Mapping[builtins.str, builtins.str]:
        return typing.cast(typing.Mapping[builtins.str, builtins.str], jsii.get(self, "headers"))

    @headers.setter
    def headers(self, value: typing.Mapping[builtins.str, builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9c649c2389d6150c86086659a272921793bdac1d01a17818729a718634d5f78c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "headers", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="locks")
    def locks(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "locks"))

    @locks.setter
    def locks(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ecface4d64f727299378773d22d6aad179566c3b318ab8fb886bf08c1109be0a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "locks", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="method")
    def method(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "method"))

    @method.setter
    def method(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a004d1d6767d31a29dfc6842432afb2b2c56123d78ad2d4dffe7443d09510de1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "method", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="queryParameters")
    def query_parameters(
        self,
    ) -> typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]:
        return typing.cast(typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]], jsii.get(self, "queryParameters"))

    @query_parameters.setter
    def query_parameters(
        self,
        value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__75003ceeeba04467530caba827b8e3acf689d4f714b06fced16ecc43b42f4dba)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "queryParameters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceId")
    def resource_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "resourceId"))

    @resource_id.setter
    def resource_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__618428c81e64ca9dc3b28ddbd0a2caa3b488ba4899431c70afde207e779a49ae)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="responseExportValues")
    def response_export_values(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.get(self, "responseExportValues"))

    @response_export_values.setter
    def response_export_values(
        self,
        value: typing.Mapping[builtins.str, typing.Any],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__357b0007148e00bdf7bd48788e9dd50264c0b7decb944dd954983ed045d16fe0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "responseExportValues", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="sensitiveResponseExportValues")
    def sensitive_response_export_values(
        self,
    ) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.get(self, "sensitiveResponseExportValues"))

    @sensitive_response_export_values.setter
    def sensitive_response_export_values(
        self,
        value: typing.Mapping[builtins.str, typing.Any],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0319798eb06f4e230b99dd90a3a0392620aff4947336e180d07cd99eb67ef2a5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "sensitiveResponseExportValues", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__595b452dc41ac6e1e18f9f594cf05df16be57566288f18e8c538b35de247eff3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="when")
    def when(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "when"))

    @when.setter
    def when(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7e4e242bce02e6a930efa9bfc9ebdf4c1dda6e62bbae50d41d9dd940c2dfdac7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "when", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.ResourceActionConfig",
    jsii_struct_bases=[_cdktf_9a9027ec.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "resource_id": "resourceId",
        "type": "type",
        "action": "action",
        "body": "body",
        "headers": "headers",
        "locks": "locks",
        "method": "method",
        "query_parameters": "queryParameters",
        "response_export_values": "responseExportValues",
        "retry": "retry",
        "sensitive_response_export_values": "sensitiveResponseExportValues",
        "timeouts": "timeouts",
        "when": "when",
    },
)
class ResourceActionConfig(_cdktf_9a9027ec.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        resource_id: builtins.str,
        type: builtins.str,
        action: typing.Optional[builtins.str] = None,
        body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        locks: typing.Optional[typing.Sequence[builtins.str]] = None,
        method: typing.Optional[builtins.str] = None,
        query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
        response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        retry: typing.Optional[typing.Union["ResourceActionRetry", typing.Dict[builtins.str, typing.Any]]] = None,
        sensitive_response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        timeouts: typing.Optional[typing.Union["ResourceActionTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        when: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param resource_id: The ID of an existing Azure source. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#resource_id ResourceAction#resource_id}
        :param type: In a format like ``<resource-type>@<api-version>``. ``<resource-type>`` is the Azure resource type, for example, ``Microsoft.Storage/storageAccounts``. ``<api-version>`` is version of the API used to manage this azure resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#type ResourceAction#type}
        :param action: The name of the resource action. It's also possible to make HTTP requests towards the resource ID if leave this field empty. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#action ResourceAction#action}
        :param body: A dynamic attribute that contains the request body. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#body ResourceAction#body}
        :param headers: A map of headers to include in the request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#headers ResourceAction#headers}
        :param locks: A list of ARM resource IDs which are used to avoid create/modify/delete azapi resources at the same time. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#locks ResourceAction#locks}
        :param method: Specifies the HTTP method of the azure resource action. Allowed values are ``POST``, ``PATCH``, ``PUT`` and ``DELETE``. Defaults to ``POST``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#method ResourceAction#method}
        :param query_parameters: A map of query parameters to include in the request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#query_parameters ResourceAction#query_parameters}
        :param response_export_values: The attribute can accept either a list or a map. - **List**: A list of paths that need to be exported from the response body. Setting it to ``["*"]`` will export the full response body. Here's an example. If it sets to ``["properties.loginServer", "properties.policies.quarantinePolicy.status"]``, it will set the following HCL object to the computed property output. Example:: { properties = { loginServer = "registry1.azurecr.io" policies = { quarantinePolicy = { status = "disabled" } } } } - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to ``{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}``, it will set the following HCL object to the computed property output. Example:: { "login_server" = "registry1.azurecr.io" "quarantine_status" = "disabled" } To learn more about JMESPath, visit `JMESPath <https://jmespath.org/>`_. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#response_export_values ResourceAction#response_export_values}
        :param retry: The retry object supports the following attributes:. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#retry ResourceAction#retry}
        :param sensitive_response_export_values: The attribute can accept either a list or a map. - **List**: A list of paths that need to be exported from the response body. Setting it to ``["*"]`` will export the full response body. Here's an example. If it sets to ``["properties.loginServer", "properties.policies.quarantinePolicy.status"]``, it will set the following HCL object to the computed property output. Example:: { properties = { loginServer = "registry1.azurecr.io" policies = { quarantinePolicy = { status = "disabled" } } } } - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to ``{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}``, it will set the following HCL object to the computed property output. Example:: { "login_server" = "registry1.azurecr.io" "quarantine_status" = "disabled" } To learn more about JMESPath, visit `JMESPath <https://jmespath.org/>`_. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#sensitive_response_export_values ResourceAction#sensitive_response_export_values}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#timeouts ResourceAction#timeouts}
        :param when: When to perform the action, value must be one of: ``apply``, ``destroy``. Default is ``apply``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#when ResourceAction#when}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktf_9a9027ec.TerraformResourceLifecycle(**lifecycle)
        if isinstance(retry, dict):
            retry = ResourceActionRetry(**retry)
        if isinstance(timeouts, dict):
            timeouts = ResourceActionTimeouts(**timeouts)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f8e2bb85c6fbed66627658d3e8222936052424f03b9388708ba0e28309d48ca7)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument resource_id", value=resource_id, expected_type=type_hints["resource_id"])
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            check_type(argname="argument action", value=action, expected_type=type_hints["action"])
            check_type(argname="argument body", value=body, expected_type=type_hints["body"])
            check_type(argname="argument headers", value=headers, expected_type=type_hints["headers"])
            check_type(argname="argument locks", value=locks, expected_type=type_hints["locks"])
            check_type(argname="argument method", value=method, expected_type=type_hints["method"])
            check_type(argname="argument query_parameters", value=query_parameters, expected_type=type_hints["query_parameters"])
            check_type(argname="argument response_export_values", value=response_export_values, expected_type=type_hints["response_export_values"])
            check_type(argname="argument retry", value=retry, expected_type=type_hints["retry"])
            check_type(argname="argument sensitive_response_export_values", value=sensitive_response_export_values, expected_type=type_hints["sensitive_response_export_values"])
            check_type(argname="argument timeouts", value=timeouts, expected_type=type_hints["timeouts"])
            check_type(argname="argument when", value=when, expected_type=type_hints["when"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "resource_id": resource_id,
            "type": type,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if action is not None:
            self._values["action"] = action
        if body is not None:
            self._values["body"] = body
        if headers is not None:
            self._values["headers"] = headers
        if locks is not None:
            self._values["locks"] = locks
        if method is not None:
            self._values["method"] = method
        if query_parameters is not None:
            self._values["query_parameters"] = query_parameters
        if response_export_values is not None:
            self._values["response_export_values"] = response_export_values
        if retry is not None:
            self._values["retry"] = retry
        if sensitive_response_export_values is not None:
            self._values["sensitive_response_export_values"] = sensitive_response_export_values
        if timeouts is not None:
            self._values["timeouts"] = timeouts
        if when is not None:
            self._values["when"] = when

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, _cdktf_9a9027ec.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, _cdktf_9a9027ec.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktf_9a9027ec.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktf_9a9027ec.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktf_9a9027ec.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktf_9a9027ec.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktf_9a9027ec.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktf_9a9027ec.FileProvisioner, _cdktf_9a9027ec.LocalExecProvisioner, _cdktf_9a9027ec.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktf_9a9027ec.FileProvisioner, _cdktf_9a9027ec.LocalExecProvisioner, _cdktf_9a9027ec.RemoteExecProvisioner]]], result)

    @builtins.property
    def resource_id(self) -> builtins.str:
        '''The ID of an existing Azure source.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#resource_id ResourceAction#resource_id}
        '''
        result = self._values.get("resource_id")
        assert result is not None, "Required property 'resource_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def type(self) -> builtins.str:
        '''In a format like ``<resource-type>@<api-version>``.

        ``<resource-type>`` is the Azure resource type, for example, ``Microsoft.Storage/storageAccounts``. ``<api-version>`` is version of the API used to manage this azure resource.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#type ResourceAction#type}
        '''
        result = self._values.get("type")
        assert result is not None, "Required property 'type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def action(self) -> typing.Optional[builtins.str]:
        '''The name of the resource action.

        It's also possible to make HTTP requests towards the resource ID if leave this field empty.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#action ResourceAction#action}
        '''
        result = self._values.get("action")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def body(self) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        '''A dynamic attribute that contains the request body.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#body ResourceAction#body}
        '''
        result = self._values.get("body")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], result)

    @builtins.property
    def headers(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''A map of headers to include in the request.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#headers ResourceAction#headers}
        '''
        result = self._values.get("headers")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def locks(self) -> typing.Optional[typing.List[builtins.str]]:
        '''A list of ARM resource IDs which are used to avoid create/modify/delete azapi resources at the same time.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#locks ResourceAction#locks}
        '''
        result = self._values.get("locks")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def method(self) -> typing.Optional[builtins.str]:
        '''Specifies the HTTP method of the azure resource action.

        Allowed values are ``POST``, ``PATCH``, ``PUT`` and ``DELETE``. Defaults to ``POST``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#method ResourceAction#method}
        '''
        result = self._values.get("method")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def query_parameters(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]]:
        '''A map of query parameters to include in the request.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#query_parameters ResourceAction#query_parameters}
        '''
        result = self._values.get("query_parameters")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]], result)

    @builtins.property
    def response_export_values(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        '''The attribute can accept either a list or a map.

        - **List**: A list of paths that need to be exported from the response body. Setting it to ``["*"]`` will export the full response body. Here's an example. If it sets to ``["properties.loginServer", "properties.policies.quarantinePolicy.status"]``, it will set the following HCL object to the computed property output.

        Example::

           {
           properties = {
           loginServer = "registry1.azurecr.io"
           policies = {
           quarantinePolicy = {
           	status = "disabled"
           }
           }
           }
           }

        - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to ``{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}``, it will set the following HCL object to the computed property output.

        Example::

           {
           "login_server" = "registry1.azurecr.io"
           "quarantine_status" = "disabled"
           }

        To learn more about JMESPath, visit `JMESPath <https://jmespath.org/>`_.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#response_export_values ResourceAction#response_export_values}
        '''
        result = self._values.get("response_export_values")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], result)

    @builtins.property
    def retry(self) -> typing.Optional["ResourceActionRetry"]:
        '''The retry object supports the following attributes:.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#retry ResourceAction#retry}
        '''
        result = self._values.get("retry")
        return typing.cast(typing.Optional["ResourceActionRetry"], result)

    @builtins.property
    def sensitive_response_export_values(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        '''The attribute can accept either a list or a map.

        - **List**: A list of paths that need to be exported from the response body. Setting it to ``["*"]`` will export the full response body. Here's an example. If it sets to ``["properties.loginServer", "properties.policies.quarantinePolicy.status"]``, it will set the following HCL object to the computed property output.

        Example::

           {
           properties = {
           loginServer = "registry1.azurecr.io"
           policies = {
           quarantinePolicy = {
           	status = "disabled"
           }
           }
           }
           }

        - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to ``{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}``, it will set the following HCL object to the computed property output.

        Example::

           {
           "login_server" = "registry1.azurecr.io"
           "quarantine_status" = "disabled"
           }

        To learn more about JMESPath, visit `JMESPath <https://jmespath.org/>`_.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#sensitive_response_export_values ResourceAction#sensitive_response_export_values}
        '''
        result = self._values.get("sensitive_response_export_values")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], result)

    @builtins.property
    def timeouts(self) -> typing.Optional["ResourceActionTimeouts"]:
        '''timeouts block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#timeouts ResourceAction#timeouts}
        '''
        result = self._values.get("timeouts")
        return typing.cast(typing.Optional["ResourceActionTimeouts"], result)

    @builtins.property
    def when(self) -> typing.Optional[builtins.str]:
        '''When to perform the action, value must be one of: ``apply``, ``destroy``. Default is ``apply``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#when ResourceAction#when}
        '''
        result = self._values.get("when")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ResourceActionConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.ResourceActionRetry",
    jsii_struct_bases=[],
    name_mapping={
        "error_message_regex": "errorMessageRegex",
        "interval_seconds": "intervalSeconds",
        "max_interval_seconds": "maxIntervalSeconds",
        "multiplier": "multiplier",
        "randomization_factor": "randomizationFactor",
    },
)
class ResourceActionRetry:
    def __init__(
        self,
        *,
        error_message_regex: typing.Sequence[builtins.str],
        interval_seconds: typing.Optional[jsii.Number] = None,
        max_interval_seconds: typing.Optional[jsii.Number] = None,
        multiplier: typing.Optional[jsii.Number] = None,
        randomization_factor: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param error_message_regex: A list of regular expressions to match against error messages. If any of the regular expressions match, the request will be retried. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#error_message_regex ResourceAction#error_message_regex}
        :param interval_seconds: The base number of seconds to wait between retries. Default is ``10``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#interval_seconds ResourceAction#interval_seconds}
        :param max_interval_seconds: The maximum number of seconds to wait between retries. Default is ``180``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#max_interval_seconds ResourceAction#max_interval_seconds}
        :param multiplier: The multiplier to apply to the interval between retries. Default is ``1.5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#multiplier ResourceAction#multiplier}
        :param randomization_factor: The randomization factor to apply to the interval between retries. The formula for the randomized interval is: ``RetryInterval * (random value in range [1 - RandomizationFactor, 1 + RandomizationFactor])``. Therefore set to zero ``0.0`` for no randomization. Default is ``0.5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#randomization_factor ResourceAction#randomization_factor}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__28e46efabfe16eb872f9211500b5dd2f673943819499d88429251542fb87d608)
            check_type(argname="argument error_message_regex", value=error_message_regex, expected_type=type_hints["error_message_regex"])
            check_type(argname="argument interval_seconds", value=interval_seconds, expected_type=type_hints["interval_seconds"])
            check_type(argname="argument max_interval_seconds", value=max_interval_seconds, expected_type=type_hints["max_interval_seconds"])
            check_type(argname="argument multiplier", value=multiplier, expected_type=type_hints["multiplier"])
            check_type(argname="argument randomization_factor", value=randomization_factor, expected_type=type_hints["randomization_factor"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "error_message_regex": error_message_regex,
        }
        if interval_seconds is not None:
            self._values["interval_seconds"] = interval_seconds
        if max_interval_seconds is not None:
            self._values["max_interval_seconds"] = max_interval_seconds
        if multiplier is not None:
            self._values["multiplier"] = multiplier
        if randomization_factor is not None:
            self._values["randomization_factor"] = randomization_factor

    @builtins.property
    def error_message_regex(self) -> typing.List[builtins.str]:
        '''A list of regular expressions to match against error messages.

        If any of the regular expressions match, the request will be retried.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#error_message_regex ResourceAction#error_message_regex}
        '''
        result = self._values.get("error_message_regex")
        assert result is not None, "Required property 'error_message_regex' is missing"
        return typing.cast(typing.List[builtins.str], result)

    @builtins.property
    def interval_seconds(self) -> typing.Optional[jsii.Number]:
        '''The base number of seconds to wait between retries. Default is ``10``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#interval_seconds ResourceAction#interval_seconds}
        '''
        result = self._values.get("interval_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def max_interval_seconds(self) -> typing.Optional[jsii.Number]:
        '''The maximum number of seconds to wait between retries. Default is ``180``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#max_interval_seconds ResourceAction#max_interval_seconds}
        '''
        result = self._values.get("max_interval_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def multiplier(self) -> typing.Optional[jsii.Number]:
        '''The multiplier to apply to the interval between retries. Default is ``1.5``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#multiplier ResourceAction#multiplier}
        '''
        result = self._values.get("multiplier")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def randomization_factor(self) -> typing.Optional[jsii.Number]:
        '''The randomization factor to apply to the interval between retries.

        The formula for the randomized interval is: ``RetryInterval * (random value in range [1 - RandomizationFactor, 1 + RandomizationFactor])``. Therefore set to zero ``0.0`` for no randomization. Default is ``0.5``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#randomization_factor ResourceAction#randomization_factor}
        '''
        result = self._values.get("randomization_factor")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ResourceActionRetry(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ResourceActionRetryOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.ResourceActionRetryOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__00c2b505e65ddc5b0eab80b8e3925e063da0ba2a162cf555ff1da5fa728f859b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetIntervalSeconds")
    def reset_interval_seconds(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIntervalSeconds", []))

    @jsii.member(jsii_name="resetMaxIntervalSeconds")
    def reset_max_interval_seconds(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMaxIntervalSeconds", []))

    @jsii.member(jsii_name="resetMultiplier")
    def reset_multiplier(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMultiplier", []))

    @jsii.member(jsii_name="resetRandomizationFactor")
    def reset_randomization_factor(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRandomizationFactor", []))

    @builtins.property
    @jsii.member(jsii_name="errorMessageRegexInput")
    def error_message_regex_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "errorMessageRegexInput"))

    @builtins.property
    @jsii.member(jsii_name="intervalSecondsInput")
    def interval_seconds_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "intervalSecondsInput"))

    @builtins.property
    @jsii.member(jsii_name="maxIntervalSecondsInput")
    def max_interval_seconds_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "maxIntervalSecondsInput"))

    @builtins.property
    @jsii.member(jsii_name="multiplierInput")
    def multiplier_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "multiplierInput"))

    @builtins.property
    @jsii.member(jsii_name="randomizationFactorInput")
    def randomization_factor_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "randomizationFactorInput"))

    @builtins.property
    @jsii.member(jsii_name="errorMessageRegex")
    def error_message_regex(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "errorMessageRegex"))

    @error_message_regex.setter
    def error_message_regex(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__baae077936ab43a7958119c062b9fad9e223deb4cc1a0c05b8edbdeae1418a7c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "errorMessageRegex", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="intervalSeconds")
    def interval_seconds(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "intervalSeconds"))

    @interval_seconds.setter
    def interval_seconds(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9f364015da412ddbcdf7e825f3063adc0b3de3bf9363d68e147722bc2411f8aa)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "intervalSeconds", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="maxIntervalSeconds")
    def max_interval_seconds(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "maxIntervalSeconds"))

    @max_interval_seconds.setter
    def max_interval_seconds(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d40beb561bc4af16cab276bed7ab791d6d3478f692640f472415e88be5ea03dd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "maxIntervalSeconds", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="multiplier")
    def multiplier(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "multiplier"))

    @multiplier.setter
    def multiplier(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e2262c316736506a51d44f860c32ba79aa990b17c43b3c3479e47992738912a4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "multiplier", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="randomizationFactor")
    def randomization_factor(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "randomizationFactor"))

    @randomization_factor.setter
    def randomization_factor(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bd6be8daf53287e67ad06aa69e56938d7f91719ed089167a362e1cbe5d2391c2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "randomizationFactor", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceActionRetry]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceActionRetry]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceActionRetry]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__026803ddbdf7b5454fdd2d1dac7f26b97cdd33f24166845a5f1bbb406c6ca40e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.ResourceActionTimeouts",
    jsii_struct_bases=[],
    name_mapping={
        "create": "create",
        "delete": "delete",
        "read": "read",
        "update": "update",
    },
)
class ResourceActionTimeouts:
    def __init__(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#create ResourceAction#create}
        :param delete: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#delete ResourceAction#delete}
        :param read: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#read ResourceAction#read}
        :param update: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#update ResourceAction#update}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3ee5eacfd46440ebfb5470174494f3da3d2ea98c95731344f7e0794305cdb15e)
            check_type(argname="argument create", value=create, expected_type=type_hints["create"])
            check_type(argname="argument delete", value=delete, expected_type=type_hints["delete"])
            check_type(argname="argument read", value=read, expected_type=type_hints["read"])
            check_type(argname="argument update", value=update, expected_type=type_hints["update"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if create is not None:
            self._values["create"] = create
        if delete is not None:
            self._values["delete"] = delete
        if read is not None:
            self._values["read"] = read
        if update is not None:
            self._values["update"] = update

    @builtins.property
    def create(self) -> typing.Optional[builtins.str]:
        '''A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#create ResourceAction#create}
        '''
        result = self._values.get("create")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def delete(self) -> typing.Optional[builtins.str]:
        '''A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#delete ResourceAction#delete}
        '''
        result = self._values.get("delete")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def read(self) -> typing.Optional[builtins.str]:
        '''A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#read ResourceAction#read}
        '''
        result = self._values.get("read")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def update(self) -> typing.Optional[builtins.str]:
        '''A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource_action#update ResourceAction#update}
        '''
        result = self._values.get("update")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ResourceActionTimeouts(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ResourceActionTimeoutsOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.ResourceActionTimeoutsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f0d0cb9794de2331a0700fc234c67c1c997de1bccf68794aff848a45872aab72)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetCreate")
    def reset_create(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCreate", []))

    @jsii.member(jsii_name="resetDelete")
    def reset_delete(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDelete", []))

    @jsii.member(jsii_name="resetRead")
    def reset_read(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRead", []))

    @jsii.member(jsii_name="resetUpdate")
    def reset_update(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUpdate", []))

    @builtins.property
    @jsii.member(jsii_name="createInput")
    def create_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "createInput"))

    @builtins.property
    @jsii.member(jsii_name="deleteInput")
    def delete_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "deleteInput"))

    @builtins.property
    @jsii.member(jsii_name="readInput")
    def read_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "readInput"))

    @builtins.property
    @jsii.member(jsii_name="updateInput")
    def update_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "updateInput"))

    @builtins.property
    @jsii.member(jsii_name="create")
    def create(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "create"))

    @create.setter
    def create(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a656c1a2a49619464df067705a34ecc7311594a109ac428f21d5180142e5262e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "create", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="delete")
    def delete(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "delete"))

    @delete.setter
    def delete(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__06a44b9c7e024ce8ba9a65de2a1d2e3b83c16e2175cf074a964fe2ea8df03783)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "delete", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="read")
    def read(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "read"))

    @read.setter
    def read(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__31257aab74109d3af4698313da9c73e0d185636e06e2c9bee106bf22de94e89f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "read", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="update")
    def update(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "update"))

    @update.setter
    def update(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__35e531b763c8e10f3decbaf7a5738cf248e9ea7b21a2bc3001de3b1fe735d065)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "update", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceActionTimeouts]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceActionTimeouts]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceActionTimeouts]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eb8f61d9dfa427401bb0a23cb0dc1488c437e857a759fbe4368ce74f670b549d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.ResourceConfig",
    jsii_struct_bases=[_cdktf_9a9027ec.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "type": "type",
        "body": "body",
        "create_headers": "createHeaders",
        "create_query_parameters": "createQueryParameters",
        "delete_headers": "deleteHeaders",
        "delete_query_parameters": "deleteQueryParameters",
        "identity": "identity",
        "ignore_casing": "ignoreCasing",
        "ignore_missing_property": "ignoreMissingProperty",
        "ignore_null_property": "ignoreNullProperty",
        "location": "location",
        "locks": "locks",
        "name": "name",
        "parent_id": "parentId",
        "read_headers": "readHeaders",
        "read_query_parameters": "readQueryParameters",
        "replace_triggers_external_values": "replaceTriggersExternalValues",
        "replace_triggers_refs": "replaceTriggersRefs",
        "response_export_values": "responseExportValues",
        "retry": "retry",
        "schema_validation_enabled": "schemaValidationEnabled",
        "sensitive_body": "sensitiveBody",
        "sensitive_body_version": "sensitiveBodyVersion",
        "tags": "tags",
        "timeouts": "timeouts",
        "update_headers": "updateHeaders",
        "update_query_parameters": "updateQueryParameters",
    },
)
class ResourceConfig(_cdktf_9a9027ec.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        type: builtins.str,
        body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        create_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        create_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
        delete_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        delete_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
        identity: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["ResourceIdentity", typing.Dict[builtins.str, typing.Any]]]]] = None,
        ignore_casing: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
        ignore_missing_property: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
        ignore_null_property: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
        location: typing.Optional[builtins.str] = None,
        locks: typing.Optional[typing.Sequence[builtins.str]] = None,
        name: typing.Optional[builtins.str] = None,
        parent_id: typing.Optional[builtins.str] = None,
        read_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        read_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
        replace_triggers_external_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        replace_triggers_refs: typing.Optional[typing.Sequence[builtins.str]] = None,
        response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        retry: typing.Optional[typing.Union["ResourceRetry", typing.Dict[builtins.str, typing.Any]]] = None,
        schema_validation_enabled: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
        sensitive_body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        sensitive_body_version: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        timeouts: typing.Optional[typing.Union["ResourceTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        update_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        update_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param type: In a format like ``<resource-type>@<api-version>``. ``<resource-type>`` is the Azure resource type, for example, ``Microsoft.Storage/storageAccounts``. ``<api-version>`` is version of the API used to manage this azure resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#type Resource#type}
        :param body: A dynamic attribute that contains the request body. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#body Resource#body}
        :param create_headers: A mapping of headers to be sent with the create request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#create_headers Resource#create_headers}
        :param create_query_parameters: A mapping of query parameters to be sent with the create request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#create_query_parameters Resource#create_query_parameters}
        :param delete_headers: A mapping of headers to be sent with the delete request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#delete_headers Resource#delete_headers}
        :param delete_query_parameters: A mapping of query parameters to be sent with the delete request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#delete_query_parameters Resource#delete_query_parameters}
        :param identity: identity block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#identity Resource#identity}
        :param ignore_casing: Whether ignore the casing of the property names in the response body. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#ignore_casing Resource#ignore_casing}
        :param ignore_missing_property: Whether ignore not returned properties like credentials in ``body`` to suppress plan-diff. Defaults to ``true``. It's recommend to enable this option when some sensitive properties are not returned in response body, instead of setting them in ``lifecycle.ignore_changes`` because it will make the sensitive fields unable to update. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#ignore_missing_property Resource#ignore_missing_property}
        :param ignore_null_property: When set to ``true``, the provider will ignore properties whose values are ``null`` in the ``body``. These properties will not be included in the request body sent to the API, and the difference will not be shown in the plan output. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#ignore_null_property Resource#ignore_null_property}
        :param location: The location of the Azure resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#location Resource#location}
        :param locks: A list of ARM resource IDs which are used to avoid create/modify/delete azapi resources at the same time. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#locks Resource#locks}
        :param name: Specifies the name of the azure resource. Changing this forces a new resource to be created. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#name Resource#name}
        :param parent_id: The ID of the azure resource in which this resource is created. It supports different kinds of deployment scope for **top level** resources: - resource group scope: ``parent_id`` should be the ID of a resource group, it's recommended to manage a resource group by azurerm_resource_group. - management group scope: ``parent_id`` should be the ID of a management group, it's recommended to manage a management group by azurerm_management_group. - extension scope: ``parent_id`` should be the ID of the resource you're adding the extension to. - subscription scope: ``parent_id`` should be like \\x60/subscriptions/00000000-0000-0000-0000-000000000000\\x60 - tenant scope: ``parent_id`` should be / For child level resources, the ``parent_id`` should be the ID of its parent resource, for example, subnet resource's ``parent_id`` is the ID of the vnet. For type ``Microsoft.Resources/resourceGroups``, the ``parent_id`` could be omitted, it defaults to subscription ID specified in provider or the default subscription (You could check the default subscription by azure cli command: ``az account show``). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#parent_id Resource#parent_id}
        :param read_headers: A mapping of headers to be sent with the read request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#read_headers Resource#read_headers}
        :param read_query_parameters: A mapping of query parameters to be sent with the read request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#read_query_parameters Resource#read_query_parameters}
        :param replace_triggers_external_values: Will trigger a replace of the resource when the value changes and is not ``null``. This can be used by practitioners to force a replace of the resource when certain values change, e.g. changing the SKU of a virtual machine based on the value of variables or locals. The value is a ``dynamic``, so practitioners can compose the input however they wish. For a "break glass" set the value to ``null`` to prevent the plan modifier taking effect. If you have ``null`` values that you do want to be tracked as affecting the resource replacement, include these inside an object. Advanced use cases are possible and resource replacement can be triggered by values external to the resource, for example when a dependent resource changes. e.g. to replace a resource when either the SKU or os_type attributes change:: resource "azapi_resource" "example" { name = var.name type = "Microsoft.Network/publicIPAddresses@2023-11-01" parent_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/example" body = { properties = { sku = var.sku zones = var.zones } } replace_triggers_external_values = [ var.sku, var.zones, ] } Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#replace_triggers_external_values Resource#replace_triggers_external_values}
        :param replace_triggers_refs: A list of paths in the current Terraform configuration. When the values at these paths change, the resource will be replaced. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#replace_triggers_refs Resource#replace_triggers_refs}
        :param response_export_values: The attribute can accept either a list or a map. - **List**: A list of paths that need to be exported from the response body. Setting it to ``["*"]`` will export the full response body. Here's an example. If it sets to ``["properties.loginServer", "properties.policies.quarantinePolicy.status"]``, it will set the following HCL object to the computed property output. Example:: { properties = { loginServer = "registry1.azurecr.io" policies = { quarantinePolicy = { status = "disabled" } } } } - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to ``{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}``, it will set the following HCL object to the computed property output. Example:: { "login_server" = "registry1.azurecr.io" "quarantine_status" = "disabled" } To learn more about JMESPath, visit `JMESPath <https://jmespath.org/>`_. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#response_export_values Resource#response_export_values}
        :param retry: The retry object supports the following attributes:. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#retry Resource#retry}
        :param schema_validation_enabled: Whether enabled the validation on ``type`` and ``body`` with embedded schema. Defaults to ``true``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#schema_validation_enabled Resource#schema_validation_enabled}
        :param sensitive_body: A dynamic attribute that contains the write-only properties of the request body. This will be merge-patched to the body to construct the actual request body. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#sensitive_body Resource#sensitive_body}
        :param sensitive_body_version: A map where the key is the path to the property in ``sensitive_body`` and the value is the version of the property. The key is a string in the format of ``path.to.property[index].subproperty``, where ``index`` is the index of the item in an array. When the version is changed, the property will be included in the request body, otherwise it will be omitted from the request body. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#sensitive_body_version Resource#sensitive_body_version}
        :param tags: A mapping of tags which should be assigned to the Azure resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#tags Resource#tags}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#timeouts Resource#timeouts}
        :param update_headers: A mapping of headers to be sent with the update request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#update_headers Resource#update_headers}
        :param update_query_parameters: A mapping of query parameters to be sent with the update request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#update_query_parameters Resource#update_query_parameters}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktf_9a9027ec.TerraformResourceLifecycle(**lifecycle)
        if isinstance(retry, dict):
            retry = ResourceRetry(**retry)
        if isinstance(timeouts, dict):
            timeouts = ResourceTimeouts(**timeouts)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0dba8b11025af1cd1bb936835c3223213bf9904b11157b2cd5518ae03dd90289)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            check_type(argname="argument body", value=body, expected_type=type_hints["body"])
            check_type(argname="argument create_headers", value=create_headers, expected_type=type_hints["create_headers"])
            check_type(argname="argument create_query_parameters", value=create_query_parameters, expected_type=type_hints["create_query_parameters"])
            check_type(argname="argument delete_headers", value=delete_headers, expected_type=type_hints["delete_headers"])
            check_type(argname="argument delete_query_parameters", value=delete_query_parameters, expected_type=type_hints["delete_query_parameters"])
            check_type(argname="argument identity", value=identity, expected_type=type_hints["identity"])
            check_type(argname="argument ignore_casing", value=ignore_casing, expected_type=type_hints["ignore_casing"])
            check_type(argname="argument ignore_missing_property", value=ignore_missing_property, expected_type=type_hints["ignore_missing_property"])
            check_type(argname="argument ignore_null_property", value=ignore_null_property, expected_type=type_hints["ignore_null_property"])
            check_type(argname="argument location", value=location, expected_type=type_hints["location"])
            check_type(argname="argument locks", value=locks, expected_type=type_hints["locks"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument parent_id", value=parent_id, expected_type=type_hints["parent_id"])
            check_type(argname="argument read_headers", value=read_headers, expected_type=type_hints["read_headers"])
            check_type(argname="argument read_query_parameters", value=read_query_parameters, expected_type=type_hints["read_query_parameters"])
            check_type(argname="argument replace_triggers_external_values", value=replace_triggers_external_values, expected_type=type_hints["replace_triggers_external_values"])
            check_type(argname="argument replace_triggers_refs", value=replace_triggers_refs, expected_type=type_hints["replace_triggers_refs"])
            check_type(argname="argument response_export_values", value=response_export_values, expected_type=type_hints["response_export_values"])
            check_type(argname="argument retry", value=retry, expected_type=type_hints["retry"])
            check_type(argname="argument schema_validation_enabled", value=schema_validation_enabled, expected_type=type_hints["schema_validation_enabled"])
            check_type(argname="argument sensitive_body", value=sensitive_body, expected_type=type_hints["sensitive_body"])
            check_type(argname="argument sensitive_body_version", value=sensitive_body_version, expected_type=type_hints["sensitive_body_version"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            check_type(argname="argument timeouts", value=timeouts, expected_type=type_hints["timeouts"])
            check_type(argname="argument update_headers", value=update_headers, expected_type=type_hints["update_headers"])
            check_type(argname="argument update_query_parameters", value=update_query_parameters, expected_type=type_hints["update_query_parameters"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "type": type,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if body is not None:
            self._values["body"] = body
        if create_headers is not None:
            self._values["create_headers"] = create_headers
        if create_query_parameters is not None:
            self._values["create_query_parameters"] = create_query_parameters
        if delete_headers is not None:
            self._values["delete_headers"] = delete_headers
        if delete_query_parameters is not None:
            self._values["delete_query_parameters"] = delete_query_parameters
        if identity is not None:
            self._values["identity"] = identity
        if ignore_casing is not None:
            self._values["ignore_casing"] = ignore_casing
        if ignore_missing_property is not None:
            self._values["ignore_missing_property"] = ignore_missing_property
        if ignore_null_property is not None:
            self._values["ignore_null_property"] = ignore_null_property
        if location is not None:
            self._values["location"] = location
        if locks is not None:
            self._values["locks"] = locks
        if name is not None:
            self._values["name"] = name
        if parent_id is not None:
            self._values["parent_id"] = parent_id
        if read_headers is not None:
            self._values["read_headers"] = read_headers
        if read_query_parameters is not None:
            self._values["read_query_parameters"] = read_query_parameters
        if replace_triggers_external_values is not None:
            self._values["replace_triggers_external_values"] = replace_triggers_external_values
        if replace_triggers_refs is not None:
            self._values["replace_triggers_refs"] = replace_triggers_refs
        if response_export_values is not None:
            self._values["response_export_values"] = response_export_values
        if retry is not None:
            self._values["retry"] = retry
        if schema_validation_enabled is not None:
            self._values["schema_validation_enabled"] = schema_validation_enabled
        if sensitive_body is not None:
            self._values["sensitive_body"] = sensitive_body
        if sensitive_body_version is not None:
            self._values["sensitive_body_version"] = sensitive_body_version
        if tags is not None:
            self._values["tags"] = tags
        if timeouts is not None:
            self._values["timeouts"] = timeouts
        if update_headers is not None:
            self._values["update_headers"] = update_headers
        if update_query_parameters is not None:
            self._values["update_query_parameters"] = update_query_parameters

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, _cdktf_9a9027ec.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, _cdktf_9a9027ec.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktf_9a9027ec.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktf_9a9027ec.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktf_9a9027ec.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktf_9a9027ec.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktf_9a9027ec.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktf_9a9027ec.FileProvisioner, _cdktf_9a9027ec.LocalExecProvisioner, _cdktf_9a9027ec.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktf_9a9027ec.FileProvisioner, _cdktf_9a9027ec.LocalExecProvisioner, _cdktf_9a9027ec.RemoteExecProvisioner]]], result)

    @builtins.property
    def type(self) -> builtins.str:
        '''In a format like ``<resource-type>@<api-version>``.

        ``<resource-type>`` is the Azure resource type, for example, ``Microsoft.Storage/storageAccounts``. ``<api-version>`` is version of the API used to manage this azure resource.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#type Resource#type}
        '''
        result = self._values.get("type")
        assert result is not None, "Required property 'type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def body(self) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        '''A dynamic attribute that contains the request body.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#body Resource#body}
        '''
        result = self._values.get("body")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], result)

    @builtins.property
    def create_headers(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''A mapping of headers to be sent with the create request.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#create_headers Resource#create_headers}
        '''
        result = self._values.get("create_headers")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def create_query_parameters(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]]:
        '''A mapping of query parameters to be sent with the create request.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#create_query_parameters Resource#create_query_parameters}
        '''
        result = self._values.get("create_query_parameters")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]], result)

    @builtins.property
    def delete_headers(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''A mapping of headers to be sent with the delete request.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#delete_headers Resource#delete_headers}
        '''
        result = self._values.get("delete_headers")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def delete_query_parameters(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]]:
        '''A mapping of query parameters to be sent with the delete request.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#delete_query_parameters Resource#delete_query_parameters}
        '''
        result = self._values.get("delete_query_parameters")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]], result)

    @builtins.property
    def identity(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["ResourceIdentity"]]]:
        '''identity block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#identity Resource#identity}
        '''
        result = self._values.get("identity")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["ResourceIdentity"]]], result)

    @builtins.property
    def ignore_casing(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]]:
        '''Whether ignore the casing of the property names in the response body. Defaults to ``false``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#ignore_casing Resource#ignore_casing}
        '''
        result = self._values.get("ignore_casing")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]], result)

    @builtins.property
    def ignore_missing_property(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]]:
        '''Whether ignore not returned properties like credentials in ``body`` to suppress plan-diff.

        Defaults to ``true``. It's recommend to enable this option when some sensitive properties are not returned in response body, instead of setting them in ``lifecycle.ignore_changes`` because it will make the sensitive fields unable to update.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#ignore_missing_property Resource#ignore_missing_property}
        '''
        result = self._values.get("ignore_missing_property")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]], result)

    @builtins.property
    def ignore_null_property(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]]:
        '''When set to ``true``, the provider will ignore properties whose values are ``null`` in the ``body``.

        These properties will not be included in the request body sent to the API, and the difference will not be shown in the plan output. Defaults to ``false``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#ignore_null_property Resource#ignore_null_property}
        '''
        result = self._values.get("ignore_null_property")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]], result)

    @builtins.property
    def location(self) -> typing.Optional[builtins.str]:
        '''The location of the Azure resource.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#location Resource#location}
        '''
        result = self._values.get("location")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def locks(self) -> typing.Optional[typing.List[builtins.str]]:
        '''A list of ARM resource IDs which are used to avoid create/modify/delete azapi resources at the same time.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#locks Resource#locks}
        '''
        result = self._values.get("locks")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''Specifies the name of the azure resource. Changing this forces a new resource to be created.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#name Resource#name}
        '''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def parent_id(self) -> typing.Optional[builtins.str]:
        '''The ID of the azure resource in which this resource is created.

        It supports different kinds of deployment scope for **top level** resources:

        - resource group scope: ``parent_id`` should be the ID of a resource group, it's recommended to manage a resource group by azurerm_resource_group.
        - management group scope: ``parent_id`` should be the ID of a management group, it's recommended to manage a management group by azurerm_management_group.
        - extension scope: ``parent_id`` should be the ID of the resource you're adding the extension to.
        - subscription scope: ``parent_id`` should be like \\x60/subscriptions/00000000-0000-0000-0000-000000000000\\x60
        - tenant scope: ``parent_id`` should be /

        For child level resources, the ``parent_id`` should be the ID of its parent resource, for example, subnet resource's ``parent_id`` is the ID of the vnet.

        For type ``Microsoft.Resources/resourceGroups``, the ``parent_id`` could be omitted, it defaults to subscription ID specified in provider or the default subscription (You could check the default subscription by azure cli command: ``az account show``).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#parent_id Resource#parent_id}
        '''
        result = self._values.get("parent_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def read_headers(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''A mapping of headers to be sent with the read request.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#read_headers Resource#read_headers}
        '''
        result = self._values.get("read_headers")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def read_query_parameters(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]]:
        '''A mapping of query parameters to be sent with the read request.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#read_query_parameters Resource#read_query_parameters}
        '''
        result = self._values.get("read_query_parameters")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]], result)

    @builtins.property
    def replace_triggers_external_values(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        '''Will trigger a replace of the resource when the value changes and is not ``null``.

        This can be used by practitioners to force a replace of the resource when certain values change, e.g. changing the SKU of a virtual machine based on the value of variables or locals. The value is a ``dynamic``, so practitioners can compose the input however they wish. For a "break glass" set the value to ``null`` to prevent the plan modifier taking effect.
        If you have ``null`` values that you do want to be tracked as affecting the resource replacement, include these inside an object.
        Advanced use cases are possible and resource replacement can be triggered by values external to the resource, for example when a dependent resource changes.

        e.g. to replace a resource when either the SKU or os_type attributes change::

           resource "azapi_resource" "example" {
           name      = var.name
           type      = "Microsoft.Network/publicIPAddresses@2023-11-01"
           parent_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/example"
           body = {
           properties = {
             sku   = var.sku
             zones = var.zones
           }
           }

           replace_triggers_external_values = [
           var.sku,
           var.zones,
           ]
           }

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#replace_triggers_external_values Resource#replace_triggers_external_values}
        '''
        result = self._values.get("replace_triggers_external_values")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], result)

    @builtins.property
    def replace_triggers_refs(self) -> typing.Optional[typing.List[builtins.str]]:
        '''A list of paths in the current Terraform configuration.

        When the values at these paths change, the resource will be replaced.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#replace_triggers_refs Resource#replace_triggers_refs}
        '''
        result = self._values.get("replace_triggers_refs")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def response_export_values(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        '''The attribute can accept either a list or a map.

        - **List**: A list of paths that need to be exported from the response body. Setting it to ``["*"]`` will export the full response body. Here's an example. If it sets to ``["properties.loginServer", "properties.policies.quarantinePolicy.status"]``, it will set the following HCL object to the computed property output.

        Example::

           {
           properties = {
           loginServer = "registry1.azurecr.io"
           policies = {
           quarantinePolicy = {
           	status = "disabled"
           }
           }
           }
           }

        - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to ``{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}``, it will set the following HCL object to the computed property output.

        Example::

           {
           "login_server" = "registry1.azurecr.io"
           "quarantine_status" = "disabled"
           }

        To learn more about JMESPath, visit `JMESPath <https://jmespath.org/>`_.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#response_export_values Resource#response_export_values}
        '''
        result = self._values.get("response_export_values")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], result)

    @builtins.property
    def retry(self) -> typing.Optional["ResourceRetry"]:
        '''The retry object supports the following attributes:.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#retry Resource#retry}
        '''
        result = self._values.get("retry")
        return typing.cast(typing.Optional["ResourceRetry"], result)

    @builtins.property
    def schema_validation_enabled(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]]:
        '''Whether enabled the validation on ``type`` and ``body`` with embedded schema. Defaults to ``true``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#schema_validation_enabled Resource#schema_validation_enabled}
        '''
        result = self._values.get("schema_validation_enabled")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]], result)

    @builtins.property
    def sensitive_body(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        '''A dynamic attribute that contains the write-only properties of the request body.

        This will be merge-patched to the body to construct the actual request body.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#sensitive_body Resource#sensitive_body}
        '''
        result = self._values.get("sensitive_body")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], result)

    @builtins.property
    def sensitive_body_version(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''A map where the key is the path to the property in ``sensitive_body`` and the value is the version of the property.

        The key is a string in the format of ``path.to.property[index].subproperty``, where ``index`` is the index of the item in an array. When the version is changed, the property will be included in the request body, otherwise it will be omitted from the request body.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#sensitive_body_version Resource#sensitive_body_version}
        '''
        result = self._values.get("sensitive_body_version")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''A mapping of tags which should be assigned to the Azure resource.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#tags Resource#tags}
        '''
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def timeouts(self) -> typing.Optional["ResourceTimeouts"]:
        '''timeouts block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#timeouts Resource#timeouts}
        '''
        result = self._values.get("timeouts")
        return typing.cast(typing.Optional["ResourceTimeouts"], result)

    @builtins.property
    def update_headers(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''A mapping of headers to be sent with the update request.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#update_headers Resource#update_headers}
        '''
        result = self._values.get("update_headers")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def update_query_parameters(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]]:
        '''A mapping of query parameters to be sent with the update request.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#update_query_parameters Resource#update_query_parameters}
        '''
        result = self._values.get("update_query_parameters")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ResourceConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ResourceGroup(
    _AzapiResource_7e7f5b39,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.ResourceGroup",
):
    '''Unified Azure Resource Group implementation.

    This class provides a single, version-aware implementation that replaces all
    version-specific Resource Group classes. It automatically handles version
    resolution, schema validation, and property transformation while maintaining
    full backward compatibility.

    The class uses the VersionedAzapiResource framework to provide:

    - Automatic latest version resolution (2025-03-01 as of this implementation)
    - Support for explicit version pinning when stability is required
    - Schema-driven property validation and transformation
    - Migration analysis and deprecation warnings
    - Full JSII compliance for multi-language support

    Example::

        // Usage with explicit version pinning:
        const resourceGroup = new ResourceGroup(this, "rg", {
          name: "my-resource-group",
          location: "eastus",
          apiVersion: "2024-11-01", // Pin to specific version
          tags: { environment: "production" }
        });
    '''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id: builtins.str,
        *,
        ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
        managed_by: typing.Optional[builtins.str] = None,
        api_version: typing.Optional[builtins.str] = None,
        enable_migration_analysis: typing.Optional[builtins.bool] = None,
        enable_transformation: typing.Optional[builtins.bool] = None,
        enable_validation: typing.Optional[builtins.bool] = None,
        location: typing.Optional[builtins.str] = None,
        name: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> None:
        '''Creates a new Azure Resource Group using the VersionedAzapiResource framework.

        The constructor automatically handles version resolution, schema registration,
        validation, and resource creation. It maintains full backward compatibility
        with existing Resource Group implementations.

        :param scope: - The scope in which to define this construct.
        :param id: - The unique identifier for this instance.
        :param ignore_changes: The lifecycle rules to ignore changes. Useful for properties that are externally managed or should not trigger updates.
        :param managed_by: Managed by information for the resource group. Indicates what service or tool is managing this resource group.
        :param api_version: Explicit API version to use for this resource. If not specified, the latest active version will be automatically resolved. Use this for version pinning when stability is required over latest features. Default: Latest active version from ApiVersionManager
        :param enable_migration_analysis: Whether to enable migration analysis warnings. When true, the framework will analyze the current version for deprecation status and provide migration recommendations in the deployment output. Default: true
        :param enable_transformation: Whether to apply property transformations automatically. When true, properties will be automatically transformed according to the target schema's transformation rules. This enables backward compatibility. Default: true
        :param enable_validation: Whether to validate properties against the schema. When true, all properties will be validated against the API schema before resource creation. Validation errors will cause deployment failures. Default: true
        :param location: The location where the resource should be created.
        :param name: The name of the resource.
        :param tags: Tags to apply to the resource.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__29b0473f748c77e8cf5a499a8a1cb9dbd38d71e9f891bc8febb8ed132057b1ce)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = ResourceGroupProps(
            ignore_changes=ignore_changes,
            managed_by=managed_by,
            api_version=api_version,
            enable_migration_analysis=enable_migration_analysis,
            enable_transformation=enable_transformation,
            enable_validation=enable_validation,
            location=location,
            name=name,
            tags=tags,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="addTag")
    def add_tag(self, key: builtins.str, value: builtins.str) -> None:
        '''Add a tag to the Resource Group Note: This modifies the construct props but requires a new deployment to take effect.

        :param key: -
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9d0bd2aa8c367d05c112de956c05b3cac70fb756df9f741c93e072adb1999441)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "addTag", [key, value]))

    @jsii.member(jsii_name="apiSchema")
    def _api_schema(self) -> _ApiSchema_5ce0490e:
        '''Gets the API schema for the resolved version Uses the framework's schema resolution to get the appropriate schema.'''
        return typing.cast(_ApiSchema_5ce0490e, jsii.invoke(self, "apiSchema", []))

    @jsii.member(jsii_name="createResourceBody")
    def _create_resource_body(self, props: typing.Any) -> typing.Any:
        '''Creates the resource body for the Azure API call Transforms the input properties into the JSON format expected by Azure REST API.

        :param props: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3fc32ce7cf0743f4d9783f3fb0755941fbe96b318c5653c79f3bc1f3f8af25ec)
            check_type(argname="argument props", value=props, expected_type=type_hints["props"])
        return typing.cast(typing.Any, jsii.invoke(self, "createResourceBody", [props]))

    @jsii.member(jsii_name="defaultVersion")
    def _default_version(self) -> builtins.str:
        '''Gets the default API version to use when no explicit version is specified Returns the most recent stable version as the default.'''
        return typing.cast(builtins.str, jsii.invoke(self, "defaultVersion", []))

    @jsii.member(jsii_name="removeTag")
    def remove_tag(self, key: builtins.str) -> None:
        '''Remove a tag from the Resource Group Note: This modifies the construct props but requires a new deployment to take effect.

        :param key: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3db8fd46010c87b10ea96e6f0c568b0de43fddb6044a500c41b8a2bb905961ed)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
        return typing.cast(None, jsii.invoke(self, "removeTag", [key]))

    @jsii.member(jsii_name="resourceType")
    def _resource_type(self) -> builtins.str:
        '''Gets the Azure resource type for Resource Groups.'''
        return typing.cast(builtins.str, jsii.invoke(self, "resourceType", []))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        '''The resource ID (abstract - must be implemented by subclasses).'''
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @builtins.property
    @jsii.member(jsii_name="idOutput")
    def id_output(self) -> _cdktf_9a9027ec.TerraformOutput:
        return typing.cast(_cdktf_9a9027ec.TerraformOutput, jsii.get(self, "idOutput"))

    @builtins.property
    @jsii.member(jsii_name="locationOutput")
    def location_output(self) -> _cdktf_9a9027ec.TerraformOutput:
        return typing.cast(_cdktf_9a9027ec.TerraformOutput, jsii.get(self, "locationOutput"))

    @builtins.property
    @jsii.member(jsii_name="nameOutput")
    def name_output(self) -> _cdktf_9a9027ec.TerraformOutput:
        return typing.cast(_cdktf_9a9027ec.TerraformOutput, jsii.get(self, "nameOutput"))

    @builtins.property
    @jsii.member(jsii_name="props")
    def props(self) -> "ResourceGroupProps":
        '''The input properties for this Resource Group instance.'''
        return typing.cast("ResourceGroupProps", jsii.get(self, "props"))

    @builtins.property
    @jsii.member(jsii_name="resourceId")
    def resource_id(self) -> builtins.str:
        '''Get the full resource identifier for use in other Azure resources Alias for the id property to match original interface.'''
        return typing.cast(builtins.str, jsii.get(self, "resourceId"))

    @builtins.property
    @jsii.member(jsii_name="subscriptionId")
    def subscription_id(self) -> builtins.str:
        '''Get the subscription ID from the Resource Group ID Extracts the subscription ID from the Azure resource ID format.'''
        return typing.cast(builtins.str, jsii.get(self, "subscriptionId"))

    @builtins.property
    @jsii.member(jsii_name="tags")
    def tags(self) -> typing.Mapping[builtins.str, builtins.str]:
        return typing.cast(typing.Mapping[builtins.str, builtins.str], jsii.get(self, "tags"))

    @builtins.property
    @jsii.member(jsii_name="tagsOutput")
    def tags_output(self) -> _cdktf_9a9027ec.TerraformOutput:
        return typing.cast(_cdktf_9a9027ec.TerraformOutput, jsii.get(self, "tagsOutput"))


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.ResourceGroupBody",
    jsii_struct_bases=[],
    name_mapping={"location": "location", "managed_by": "managedBy", "tags": "tags"},
)
class ResourceGroupBody:
    def __init__(
        self,
        *,
        location: builtins.str,
        managed_by: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> None:
        '''The resource body interface for Azure Resource Group API calls This matches the Azure REST API schema for resource groups.

        :param location: The location of the resource group. Cannot be changed after creation.
        :param managed_by: The ID of the resource that manages this resource group.
        :param tags: The tags attached to the resource group.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1323ac136a1170344d1118d9c54f81085344d6968ef0d2d115e69fc0fa8254d0)
            check_type(argname="argument location", value=location, expected_type=type_hints["location"])
            check_type(argname="argument managed_by", value=managed_by, expected_type=type_hints["managed_by"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "location": location,
        }
        if managed_by is not None:
            self._values["managed_by"] = managed_by
        if tags is not None:
            self._values["tags"] = tags

    @builtins.property
    def location(self) -> builtins.str:
        '''The location of the resource group.

        Cannot be changed after creation.
        '''
        result = self._values.get("location")
        assert result is not None, "Required property 'location' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def managed_by(self) -> typing.Optional[builtins.str]:
        '''The ID of the resource that manages this resource group.'''
        result = self._values.get("managed_by")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''The tags attached to the resource group.'''
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ResourceGroupBody(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.ResourceGroupProps",
    jsii_struct_bases=[_AzapiResourceProps_141a2340],
    name_mapping={
        "api_version": "apiVersion",
        "enable_migration_analysis": "enableMigrationAnalysis",
        "enable_transformation": "enableTransformation",
        "enable_validation": "enableValidation",
        "location": "location",
        "name": "name",
        "tags": "tags",
        "ignore_changes": "ignoreChanges",
        "managed_by": "managedBy",
    },
)
class ResourceGroupProps(_AzapiResourceProps_141a2340):
    def __init__(
        self,
        *,
        api_version: typing.Optional[builtins.str] = None,
        enable_migration_analysis: typing.Optional[builtins.bool] = None,
        enable_transformation: typing.Optional[builtins.bool] = None,
        enable_validation: typing.Optional[builtins.bool] = None,
        location: typing.Optional[builtins.str] = None,
        name: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
        managed_by: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Properties for the unified Azure Resource Group.

        Extends VersionedAzapiResourceProps with Resource Group specific properties
        while maintaining full compatibility with the original GroupProps interface.

        :param api_version: Explicit API version to use for this resource. If not specified, the latest active version will be automatically resolved. Use this for version pinning when stability is required over latest features. Default: Latest active version from ApiVersionManager
        :param enable_migration_analysis: Whether to enable migration analysis warnings. When true, the framework will analyze the current version for deprecation status and provide migration recommendations in the deployment output. Default: true
        :param enable_transformation: Whether to apply property transformations automatically. When true, properties will be automatically transformed according to the target schema's transformation rules. This enables backward compatibility. Default: true
        :param enable_validation: Whether to validate properties against the schema. When true, all properties will be validated against the API schema before resource creation. Validation errors will cause deployment failures. Default: true
        :param location: The location where the resource should be created.
        :param name: The name of the resource.
        :param tags: Tags to apply to the resource.
        :param ignore_changes: The lifecycle rules to ignore changes. Useful for properties that are externally managed or should not trigger updates.
        :param managed_by: Managed by information for the resource group. Indicates what service or tool is managing this resource group.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__00f9d149205e57c257371a1ebedf9fed7fb1e90db72bae0538c3d2fec74c45be)
            check_type(argname="argument api_version", value=api_version, expected_type=type_hints["api_version"])
            check_type(argname="argument enable_migration_analysis", value=enable_migration_analysis, expected_type=type_hints["enable_migration_analysis"])
            check_type(argname="argument enable_transformation", value=enable_transformation, expected_type=type_hints["enable_transformation"])
            check_type(argname="argument enable_validation", value=enable_validation, expected_type=type_hints["enable_validation"])
            check_type(argname="argument location", value=location, expected_type=type_hints["location"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            check_type(argname="argument ignore_changes", value=ignore_changes, expected_type=type_hints["ignore_changes"])
            check_type(argname="argument managed_by", value=managed_by, expected_type=type_hints["managed_by"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if api_version is not None:
            self._values["api_version"] = api_version
        if enable_migration_analysis is not None:
            self._values["enable_migration_analysis"] = enable_migration_analysis
        if enable_transformation is not None:
            self._values["enable_transformation"] = enable_transformation
        if enable_validation is not None:
            self._values["enable_validation"] = enable_validation
        if location is not None:
            self._values["location"] = location
        if name is not None:
            self._values["name"] = name
        if tags is not None:
            self._values["tags"] = tags
        if ignore_changes is not None:
            self._values["ignore_changes"] = ignore_changes
        if managed_by is not None:
            self._values["managed_by"] = managed_by

    @builtins.property
    def api_version(self) -> typing.Optional[builtins.str]:
        '''Explicit API version to use for this resource.

        If not specified, the latest active version will be automatically resolved.
        Use this for version pinning when stability is required over latest features.

        :default: Latest active version from ApiVersionManager

        Example::

            "2024-11-01"
        '''
        result = self._values.get("api_version")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def enable_migration_analysis(self) -> typing.Optional[builtins.bool]:
        '''Whether to enable migration analysis warnings.

        When true, the framework will analyze the current version for deprecation
        status and provide migration recommendations in the deployment output.

        :default: true
        '''
        result = self._values.get("enable_migration_analysis")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_transformation(self) -> typing.Optional[builtins.bool]:
        '''Whether to apply property transformations automatically.

        When true, properties will be automatically transformed according to the
        target schema's transformation rules. This enables backward compatibility.

        :default: true
        '''
        result = self._values.get("enable_transformation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_validation(self) -> typing.Optional[builtins.bool]:
        '''Whether to validate properties against the schema.

        When true, all properties will be validated against the API schema before
        resource creation. Validation errors will cause deployment failures.

        :default: true
        '''
        result = self._values.get("enable_validation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def location(self) -> typing.Optional[builtins.str]:
        '''The location where the resource should be created.'''
        result = self._values.get("location")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''The name of the resource.'''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Tags to apply to the resource.'''
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def ignore_changes(self) -> typing.Optional[typing.List[builtins.str]]:
        '''The lifecycle rules to ignore changes.

        Useful for properties that are externally managed or should not trigger updates.

        Example::

            ["tags", "managedBy"]
        '''
        result = self._values.get("ignore_changes")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def managed_by(self) -> typing.Optional[builtins.str]:
        '''Managed by information for the resource group.

        Indicates what service or tool is managing this resource group.
        '''
        result = self._values.get("managed_by")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ResourceGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.ResourceIdentity",
    jsii_struct_bases=[],
    name_mapping={"type": "type", "identity_ids": "identityIds"},
)
class ResourceIdentity:
    def __init__(
        self,
        *,
        type: builtins.str,
        identity_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param type: The Type of Identity which should be used for this azure resource. Possible values are ``SystemAssigned``, ``UserAssigned`` and ``SystemAssigned,UserAssigned``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#type Resource#type}
        :param identity_ids: A list of User Managed Identity ID's which should be assigned to the azure resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#identity_ids Resource#identity_ids}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__52c12ff10ae1f91ea81406a63ac44465db1733866e3b4e573c96fbd491e8396a)
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            check_type(argname="argument identity_ids", value=identity_ids, expected_type=type_hints["identity_ids"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "type": type,
        }
        if identity_ids is not None:
            self._values["identity_ids"] = identity_ids

    @builtins.property
    def type(self) -> builtins.str:
        '''The Type of Identity which should be used for this azure resource. Possible values are ``SystemAssigned``, ``UserAssigned`` and ``SystemAssigned,UserAssigned``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#type Resource#type}
        '''
        result = self._values.get("type")
        assert result is not None, "Required property 'type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def identity_ids(self) -> typing.Optional[typing.List[builtins.str]]:
        '''A list of User Managed Identity ID's which should be assigned to the azure resource.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#identity_ids Resource#identity_ids}
        '''
        result = self._values.get("identity_ids")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ResourceIdentity(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ResourceIdentityList(
    _cdktf_9a9027ec.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.ResourceIdentityList",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ad8d5bcf536a2bf97e7c786ae80ebde8ed0263faaa0da60aafb6a9c34bbfbd28)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "ResourceIdentityOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e2853f8e17a0492754c88e8f76e6da89db331a4e7d3b433ba9398c406c8945d5)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("ResourceIdentityOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7d91140734b86f4427853447aab47a37a2eb5d7e0f178adec228df8c4e915a5d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktf_9a9027ec.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktf_9a9027ec.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktf_9a9027ec.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__41f84f167da33ddaf69687ffe06bbe94c7ea1b052b6d03296eb6452ee6349386)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1eb795e3b089bdae4f19ca0c05ca50f165c61d0240fbcc4f7eabf33bcca4e631)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[ResourceIdentity]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[ResourceIdentity]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[ResourceIdentity]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e52ebd7e8bcbdea5dc89cc5b9b0867832aa098d2fa4dffe77bf6bbd0a9e7cb42)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class ResourceIdentityOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.ResourceIdentityOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f19617e93a12cd6b0421753d1b24a2c4b49d02f4b495c1e5e300d0d8792480db)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetIdentityIds")
    def reset_identity_ids(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIdentityIds", []))

    @builtins.property
    @jsii.member(jsii_name="principalId")
    def principal_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "principalId"))

    @builtins.property
    @jsii.member(jsii_name="tenantId")
    def tenant_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tenantId"))

    @builtins.property
    @jsii.member(jsii_name="identityIdsInput")
    def identity_ids_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "identityIdsInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="identityIds")
    def identity_ids(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "identityIds"))

    @identity_ids.setter
    def identity_ids(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8ac80f65161d5f9550a7fd12ec9c6e719abfd6ba606e52b7eb5ff5b7dcc057da)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "identityIds", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6426f4c03ae3bdae7cab4d741f9740345086ca56b44437ac0a6798b395a95f5d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceIdentity]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceIdentity]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceIdentity]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a86e85302b9b79b20851effe0af9250a8f5a2e902618a3df8ae46e57f8d38a18)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.ResourceRetry",
    jsii_struct_bases=[],
    name_mapping={
        "error_message_regex": "errorMessageRegex",
        "interval_seconds": "intervalSeconds",
        "max_interval_seconds": "maxIntervalSeconds",
        "multiplier": "multiplier",
        "randomization_factor": "randomizationFactor",
    },
)
class ResourceRetry:
    def __init__(
        self,
        *,
        error_message_regex: typing.Sequence[builtins.str],
        interval_seconds: typing.Optional[jsii.Number] = None,
        max_interval_seconds: typing.Optional[jsii.Number] = None,
        multiplier: typing.Optional[jsii.Number] = None,
        randomization_factor: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param error_message_regex: A list of regular expressions to match against error messages. If any of the regular expressions match, the request will be retried. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#error_message_regex Resource#error_message_regex}
        :param interval_seconds: The base number of seconds to wait between retries. Default is ``10``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#interval_seconds Resource#interval_seconds}
        :param max_interval_seconds: The maximum number of seconds to wait between retries. Default is ``180``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#max_interval_seconds Resource#max_interval_seconds}
        :param multiplier: The multiplier to apply to the interval between retries. Default is ``1.5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#multiplier Resource#multiplier}
        :param randomization_factor: The randomization factor to apply to the interval between retries. The formula for the randomized interval is: ``RetryInterval * (random value in range [1 - RandomizationFactor, 1 + RandomizationFactor])``. Therefore set to zero ``0.0`` for no randomization. Default is ``0.5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#randomization_factor Resource#randomization_factor}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__024e91c8b12ce75919dbcc4b5e0b1db9094d70c07451c163b0e308801852c9c3)
            check_type(argname="argument error_message_regex", value=error_message_regex, expected_type=type_hints["error_message_regex"])
            check_type(argname="argument interval_seconds", value=interval_seconds, expected_type=type_hints["interval_seconds"])
            check_type(argname="argument max_interval_seconds", value=max_interval_seconds, expected_type=type_hints["max_interval_seconds"])
            check_type(argname="argument multiplier", value=multiplier, expected_type=type_hints["multiplier"])
            check_type(argname="argument randomization_factor", value=randomization_factor, expected_type=type_hints["randomization_factor"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "error_message_regex": error_message_regex,
        }
        if interval_seconds is not None:
            self._values["interval_seconds"] = interval_seconds
        if max_interval_seconds is not None:
            self._values["max_interval_seconds"] = max_interval_seconds
        if multiplier is not None:
            self._values["multiplier"] = multiplier
        if randomization_factor is not None:
            self._values["randomization_factor"] = randomization_factor

    @builtins.property
    def error_message_regex(self) -> typing.List[builtins.str]:
        '''A list of regular expressions to match against error messages.

        If any of the regular expressions match, the request will be retried.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#error_message_regex Resource#error_message_regex}
        '''
        result = self._values.get("error_message_regex")
        assert result is not None, "Required property 'error_message_regex' is missing"
        return typing.cast(typing.List[builtins.str], result)

    @builtins.property
    def interval_seconds(self) -> typing.Optional[jsii.Number]:
        '''The base number of seconds to wait between retries. Default is ``10``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#interval_seconds Resource#interval_seconds}
        '''
        result = self._values.get("interval_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def max_interval_seconds(self) -> typing.Optional[jsii.Number]:
        '''The maximum number of seconds to wait between retries. Default is ``180``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#max_interval_seconds Resource#max_interval_seconds}
        '''
        result = self._values.get("max_interval_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def multiplier(self) -> typing.Optional[jsii.Number]:
        '''The multiplier to apply to the interval between retries. Default is ``1.5``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#multiplier Resource#multiplier}
        '''
        result = self._values.get("multiplier")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def randomization_factor(self) -> typing.Optional[jsii.Number]:
        '''The randomization factor to apply to the interval between retries.

        The formula for the randomized interval is: ``RetryInterval * (random value in range [1 - RandomizationFactor, 1 + RandomizationFactor])``. Therefore set to zero ``0.0`` for no randomization. Default is ``0.5``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#randomization_factor Resource#randomization_factor}
        '''
        result = self._values.get("randomization_factor")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ResourceRetry(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ResourceRetryOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.ResourceRetryOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6bb64d0a72a186c4863d2a4a71b30ac970083c75f978e112917a733263aebb1c)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetIntervalSeconds")
    def reset_interval_seconds(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIntervalSeconds", []))

    @jsii.member(jsii_name="resetMaxIntervalSeconds")
    def reset_max_interval_seconds(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMaxIntervalSeconds", []))

    @jsii.member(jsii_name="resetMultiplier")
    def reset_multiplier(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMultiplier", []))

    @jsii.member(jsii_name="resetRandomizationFactor")
    def reset_randomization_factor(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRandomizationFactor", []))

    @builtins.property
    @jsii.member(jsii_name="errorMessageRegexInput")
    def error_message_regex_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "errorMessageRegexInput"))

    @builtins.property
    @jsii.member(jsii_name="intervalSecondsInput")
    def interval_seconds_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "intervalSecondsInput"))

    @builtins.property
    @jsii.member(jsii_name="maxIntervalSecondsInput")
    def max_interval_seconds_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "maxIntervalSecondsInput"))

    @builtins.property
    @jsii.member(jsii_name="multiplierInput")
    def multiplier_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "multiplierInput"))

    @builtins.property
    @jsii.member(jsii_name="randomizationFactorInput")
    def randomization_factor_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "randomizationFactorInput"))

    @builtins.property
    @jsii.member(jsii_name="errorMessageRegex")
    def error_message_regex(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "errorMessageRegex"))

    @error_message_regex.setter
    def error_message_regex(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__25b8230f793ecd56b881e62949fd842e67d99df864648976c2e13bed7a938654)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "errorMessageRegex", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="intervalSeconds")
    def interval_seconds(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "intervalSeconds"))

    @interval_seconds.setter
    def interval_seconds(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7ed0e0aa54dc53eabceb33268d39eafa992b77b554a143f773ffea7445730a1f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "intervalSeconds", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="maxIntervalSeconds")
    def max_interval_seconds(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "maxIntervalSeconds"))

    @max_interval_seconds.setter
    def max_interval_seconds(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7acfe1be0d5b1089b93b5281bbe4ddfa35b311b3dd4e77b9c22294f4bfacd6c8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "maxIntervalSeconds", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="multiplier")
    def multiplier(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "multiplier"))

    @multiplier.setter
    def multiplier(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7f98bbdc89b58f2d423b303e43458dfb5fe88d3fe28fc532cf16cb892d747907)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "multiplier", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="randomizationFactor")
    def randomization_factor(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "randomizationFactor"))

    @randomization_factor.setter
    def randomization_factor(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0282de5cab879cf45313e14134319b2259b2e50de1343cdf51a84c04e2e9677d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "randomizationFactor", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceRetry]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceRetry]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceRetry]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e3c2a4029bce73af4eecab3710e0bbcab30af3631ca57e4d7221bc1c2931134f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.ResourceTimeouts",
    jsii_struct_bases=[],
    name_mapping={
        "create": "create",
        "delete": "delete",
        "read": "read",
        "update": "update",
    },
)
class ResourceTimeouts:
    def __init__(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#create Resource#create}
        :param delete: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#delete Resource#delete}
        :param read: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#read Resource#read}
        :param update: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#update Resource#update}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d5eda75602061bb145f3d35070438044c4bbb7ca7feb7df8adf7b438026f3d9b)
            check_type(argname="argument create", value=create, expected_type=type_hints["create"])
            check_type(argname="argument delete", value=delete, expected_type=type_hints["delete"])
            check_type(argname="argument read", value=read, expected_type=type_hints["read"])
            check_type(argname="argument update", value=update, expected_type=type_hints["update"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if create is not None:
            self._values["create"] = create
        if delete is not None:
            self._values["delete"] = delete
        if read is not None:
            self._values["read"] = read
        if update is not None:
            self._values["update"] = update

    @builtins.property
    def create(self) -> typing.Optional[builtins.str]:
        '''A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#create Resource#create}
        '''
        result = self._values.get("create")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def delete(self) -> typing.Optional[builtins.str]:
        '''A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#delete Resource#delete}
        '''
        result = self._values.get("delete")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def read(self) -> typing.Optional[builtins.str]:
        '''A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#read Resource#read}
        '''
        result = self._values.get("read")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def update(self) -> typing.Optional[builtins.str]:
        '''A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/resource#update Resource#update}
        '''
        result = self._values.get("update")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ResourceTimeouts(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ResourceTimeoutsOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.ResourceTimeoutsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e9dd0b4cb6319942940e117e4eb08f8fe2c13aa394c52a85206e8600f9dace0b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetCreate")
    def reset_create(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCreate", []))

    @jsii.member(jsii_name="resetDelete")
    def reset_delete(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDelete", []))

    @jsii.member(jsii_name="resetRead")
    def reset_read(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRead", []))

    @jsii.member(jsii_name="resetUpdate")
    def reset_update(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUpdate", []))

    @builtins.property
    @jsii.member(jsii_name="createInput")
    def create_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "createInput"))

    @builtins.property
    @jsii.member(jsii_name="deleteInput")
    def delete_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "deleteInput"))

    @builtins.property
    @jsii.member(jsii_name="readInput")
    def read_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "readInput"))

    @builtins.property
    @jsii.member(jsii_name="updateInput")
    def update_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "updateInput"))

    @builtins.property
    @jsii.member(jsii_name="create")
    def create(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "create"))

    @create.setter
    def create(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fd8df8efdf1749681e653a7efce9f5db55b5e525f066e2754f6c287f9ae3d92c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "create", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="delete")
    def delete(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "delete"))

    @delete.setter
    def delete(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5ad77ecbaeba8f59286342f048f3683cfdbd1115ab10ee2a355bc41584fa0b03)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "delete", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="read")
    def read(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "read"))

    @read.setter
    def read(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d1275a9ef5ffb9ab2fcb7563a67feee38f587d99ba4cae8e65b7493c9d4786d1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "read", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="update")
    def update(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "update"))

    @update.setter
    def update(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5281d50a62ebece318860e00e21dbae13c791abdb339dc50b4c46bac442c7019)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "update", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceTimeouts]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceTimeouts]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceTimeouts]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5fb549b00fd4a8c6de83658597b657b96b3d7c272740e27a65c20ccc7187d868)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.RetentionPolicyConfig",
    jsii_struct_bases=[],
    name_mapping={"days": "days", "enabled": "enabled"},
)
class RetentionPolicyConfig:
    def __init__(self, *, days: jsii.Number, enabled: builtins.bool) -> None:
        '''Retention policy configuration.

        :param days: 
        :param enabled: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7638bfc6d836a3bc87e0b0222bc338bd510d5d7a354220a29559904376c0a1a1)
            check_type(argname="argument days", value=days, expected_type=type_hints["days"])
            check_type(argname="argument enabled", value=enabled, expected_type=type_hints["enabled"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "days": days,
            "enabled": enabled,
        }

    @builtins.property
    def days(self) -> jsii.Number:
        result = self._values.get("days")
        assert result is not None, "Required property 'days' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def enabled(self) -> builtins.bool:
        result = self._values.get("enabled")
        assert result is not None, "Required property 'enabled' is missing"
        return typing.cast(builtins.bool, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RetentionPolicyConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SchemaMapper(
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.SchemaMapper",
):
    '''SchemaMapper class for property transformation and validation.

    This class provides a comprehensive property transformation engine that enables
    mapping between different API schema versions with full validation support.
    It implements JSII-compliant patterns for multi-language code generation.

    The SchemaMapper handles:

    - Property transformation between schema versions
    - Validation against API schema definitions
    - Default value injection for new properties
    - Nested object and array processing
    - Detailed error reporting with property paths

    Example::

        const schema: ApiSchema = {
          resourceType: 'Microsoft.Resources/resourceGroups',
          version: '2024-11-01',
          properties: {
            name: { dataType: PropertyType.STRING, required: true },
            location: { dataType: PropertyType.STRING, required: true }
          },
          required: ['name', 'location']
        };
        
        const mapper = SchemaMapper.create(schema);
        const result = mapper.validateProperties({ name: 'myRG', location: 'eastus' });
    '''

    @jsii.member(jsii_name="create")
    @builtins.classmethod
    def create(
        cls,
        *,
        properties: typing.Mapping[builtins.str, typing.Union[_PropertyDefinition_2a5c46ac, typing.Dict[builtins.str, typing.Any]]],
        required: typing.Sequence[builtins.str],
        resource_type: builtins.str,
        version: builtins.str,
        deprecated: typing.Optional[typing.Sequence[builtins.str]] = None,
        optional: typing.Optional[typing.Sequence[builtins.str]] = None,
        transformation_rules: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        validation_rules: typing.Optional[typing.Sequence[typing.Union[_PropertyValidation_bb241cd7, typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> _SchemaMapper_cf4ebcd7:
        '''Creates a new SchemaMapper instance for the specified schema.

        This factory method creates a SchemaMapper configured for a specific API schema.
        The schema defines the structure, validation rules, and transformation mappings
        that will be used for property operations.

        :param properties: Dictionary of property definitions keyed by property name Each property defines its type, validation, and metadata.
        :param required: Array of property names that are required Properties listed here must be provided by the user.
        :param resource_type: The Azure resource type this schema applies to.
        :param version: The API version this schema represents.
        :param deprecated: Array of property names that are deprecated Usage of these properties will generate warnings.
        :param optional: Array of property names that are optional Used for documentation and validation optimization.
        :param transformation_rules: Property transformation rules for schema mapping Maps input property names to target property names.
        :param validation_rules: Property-specific validation rules Applied in addition to individual property validation.

        :return: A new SchemaMapper instance configured with the provided schema

        :throws: Error if the schema is invalid or missing required properties

        Example::

            const schema: ApiSchema = {
              resourceType: 'Microsoft.Resources/resourceGroups',
              version: '2024-11-01',
              properties: { name: { dataType: PropertyType.STRING, required: true } },
              required: ['name']
            };
            const mapper = SchemaMapper.create(schema);
        '''
        schema = _ApiSchema_5ce0490e(
            properties=properties,
            required=required,
            resource_type=resource_type,
            version=version,
            deprecated=deprecated,
            optional=optional,
            transformation_rules=transformation_rules,
            validation_rules=validation_rules,
        )

        return typing.cast(_SchemaMapper_cf4ebcd7, jsii.sinvoke(cls, "create", [schema]))

    @jsii.member(jsii_name="applyDefaults")
    def apply_defaults(self, properties: typing.Any) -> typing.Any:
        '''Applies default values to properties based on schema definitions.

        This method injects default values for properties that are not provided
        but have default values defined in the schema. It preserves existing
        property values and only adds defaults for missing properties.

        :param properties: - The properties to apply defaults to.

        :return: New properties object with default values applied

        Example::

            const props = { name: 'myRG' };
            const withDefaults = mapper.applyDefaults(props);
            // If schema defines location default as 'eastus':
            // Result: { name: 'myRG', location: 'eastus' }
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9bc74f355d7d1fbc5878fd5086f6a928f240de6ff73782a583c218a10d828715)
            check_type(argname="argument properties", value=properties, expected_type=type_hints["properties"])
        return typing.cast(typing.Any, jsii.invoke(self, "applyDefaults", [properties]))

    @jsii.member(jsii_name="mapProperty")
    def map_property(
        self,
        property_name: builtins.str,
        value: typing.Any,
        *,
        data_type: builtins.str,
        added_in_version: typing.Optional[builtins.str] = None,
        default_value: typing.Any = None,
        deprecated: typing.Optional[builtins.bool] = None,
        description: typing.Optional[builtins.str] = None,
        removed_in_version: typing.Optional[builtins.str] = None,
        required: typing.Optional[builtins.bool] = None,
        validation: typing.Optional[typing.Sequence[typing.Union[_ValidationRule_f1913ed6, typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> typing.Any:
        '''Maps a single property value using transformation rules.

        This method applies transformation logic to a single property value based on
        the target property definition. It handles type conversion, value mapping,
        and custom transformations.

        :param property_name: - The name of the property being mapped.
        :param value: - The source value to transform.
        :param data_type: The data type of the property Must be one of the PropertyType constants.
        :param added_in_version: The API version in which this property was added Used for compatibility analysis and migration planning.
        :param default_value: Default value to use if property is not provided Type must match the property type.
        :param deprecated: Whether this property is deprecated If true, usage warnings will be generated. Default: false
        :param description: Human-readable description of the property Used for documentation generation and IDE support.
        :param removed_in_version: The API version in which this property was removed Used for compatibility analysis and migration planning.
        :param required: Whether this property is required If true, the property must be provided by the user. Default: false
        :param validation: Array of validation rules to apply to this property Rules are evaluated in order and all must pass.

        :return: The transformed property value

        :throws: Error if the transformation fails or types are incompatible

        Example::

            const targetProp = { dataType: PropertyType.STRING, required: true };
            const mapped = mapper.mapProperty('name', 'myResourceGroup', targetProp);
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__43d584f170c18d0a1f9ce4ebea063952f341a4fd5428b535de04954db03508bc)
            check_type(argname="argument property_name", value=property_name, expected_type=type_hints["property_name"])
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        target_property = _PropertyDefinition_2a5c46ac(
            data_type=data_type,
            added_in_version=added_in_version,
            default_value=default_value,
            deprecated=deprecated,
            description=description,
            removed_in_version=removed_in_version,
            required=required,
            validation=validation,
        )

        return typing.cast(typing.Any, jsii.invoke(self, "mapProperty", [property_name, value, target_property]))

    @jsii.member(jsii_name="transformProperties")
    def transform_properties(
        self,
        source_props: typing.Any,
        *,
        properties: typing.Mapping[builtins.str, typing.Union[_PropertyDefinition_2a5c46ac, typing.Dict[builtins.str, typing.Any]]],
        required: typing.Sequence[builtins.str],
        resource_type: builtins.str,
        version: builtins.str,
        deprecated: typing.Optional[typing.Sequence[builtins.str]] = None,
        optional: typing.Optional[typing.Sequence[builtins.str]] = None,
        transformation_rules: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        validation_rules: typing.Optional[typing.Sequence[typing.Union[_PropertyValidation_bb241cd7, typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> typing.Any:
        '''Transforms properties from source format to target schema format.

        This method applies transformation rules to convert properties from one schema
        format to another. It handles property renaming, restructuring, type conversion,
        and nested object/array transformations based on the target schema definition.

        :param source_props: - The source properties to transform.
        :param properties: Dictionary of property definitions keyed by property name Each property defines its type, validation, and metadata.
        :param required: Array of property names that are required Properties listed here must be provided by the user.
        :param resource_type: The Azure resource type this schema applies to.
        :param version: The API version this schema represents.
        :param deprecated: Array of property names that are deprecated Usage of these properties will generate warnings.
        :param optional: Array of property names that are optional Used for documentation and validation optimization.
        :param transformation_rules: Property transformation rules for schema mapping Maps input property names to target property names.
        :param validation_rules: Property-specific validation rules Applied in addition to individual property validation.

        :return: The transformed properties matching the target schema format

        :throws: Error if transformation fails due to incompatible types or missing mappings

        Example::

            const sourceProps = { oldName: 'value', location: 'eastus' };
            const targetSchema = {
              transformationRules: { oldName: 'newName' },
              properties: { newName: { dataType: PropertyType.STRING } }
            };
            const transformed = mapper.transformProperties(sourceProps, targetSchema);
            // Result: { newName: 'value', location: 'eastus' }
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ed7a2ae22d9d62578b80294cb5e2742132463bddece8df681e869f07c4734680)
            check_type(argname="argument source_props", value=source_props, expected_type=type_hints["source_props"])
        target_schema = _ApiSchema_5ce0490e(
            properties=properties,
            required=required,
            resource_type=resource_type,
            version=version,
            deprecated=deprecated,
            optional=optional,
            transformation_rules=transformation_rules,
            validation_rules=validation_rules,
        )

        return typing.cast(typing.Any, jsii.invoke(self, "transformProperties", [source_props, target_schema]))

    @jsii.member(jsii_name="validateProperties")
    def validate_properties(self, properties: typing.Any) -> _ValidationResult_87269226:
        '''Validates properties against the schema definition.

        This method performs comprehensive validation of properties against the
        configured schema. It checks required properties, data types, validation rules,
        and provides detailed error reporting with property path information.

        :param properties: - The properties to validate.

        :return: Detailed validation results including errors and warnings

        Example::

            const properties = { name: 'myRG', location: 'eastus', tags: { env: 'dev' } };
            const result = mapper.validateProperties(properties);
            
            if (!result.valid) {
              console.log('Validation errors:', result.errors);
              console.log('Property errors:', result.propertyErrors);
            }
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bfa13727f782f0851343415e4c43c40889fbd50653114d5f10bee312362db43d)
            check_type(argname="argument properties", value=properties, expected_type=type_hints["properties"])
        return typing.cast(_ValidationResult_87269226, jsii.invoke(self, "validateProperties", [properties]))


class StorageAccount(
    _AzapiResource_7e7f5b39,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.StorageAccount",
):
    '''Unified Azure Storage Account implementation.

    This class provides a single, version-aware implementation that replaces all
    version-specific Storage Account classes. It automatically handles version
    resolution, schema validation, and property transformation while maintaining
    full backward compatibility.

    Example::

        // Usage with explicit version pinning:
        const storageAccount = new StorageAccount(this, "storage", {
          name: "mystorageaccount",
          location: "eastus",
          resourceGroupId: resourceGroup.id,
          sku: { name: "Standard_LRS" },
          apiVersion: "2023-05-01",
        });
    '''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id: builtins.str,
        *,
        sku: typing.Union[_StorageAccountSku_fa953b33, typing.Dict[builtins.str, typing.Any]],
        access_tier: typing.Optional[builtins.str] = None,
        allow_blob_public_access: typing.Optional[builtins.bool] = None,
        enable_https_traffic_only: typing.Optional[builtins.bool] = None,
        encryption: typing.Optional[typing.Union[_StorageAccountEncryption_77d27837, typing.Dict[builtins.str, typing.Any]]] = None,
        identity: typing.Optional[typing.Union[_StorageAccountIdentity_d6b6a344, typing.Dict[builtins.str, typing.Any]]] = None,
        ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
        kind: typing.Optional[builtins.str] = None,
        minimum_tls_version: typing.Optional[builtins.str] = None,
        network_acls: typing.Optional[typing.Union[_StorageAccountNetworkAcls_768fda36, typing.Dict[builtins.str, typing.Any]]] = None,
        resource_group_id: typing.Optional[builtins.str] = None,
        api_version: typing.Optional[builtins.str] = None,
        enable_migration_analysis: typing.Optional[builtins.bool] = None,
        enable_transformation: typing.Optional[builtins.bool] = None,
        enable_validation: typing.Optional[builtins.bool] = None,
        location: typing.Optional[builtins.str] = None,
        name: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> None:
        '''Creates a new Azure Storage Account using the VersionedAzapiResource framework.

        :param scope: - The scope in which to define this construct.
        :param id: - The unique identifier for this instance.
        :param sku: The SKU (pricing tier) for the Storage Account.
        :param access_tier: The access tier for blob storage. Default: "Hot"
        :param allow_blob_public_access: Whether to allow public access to blobs. Default: false
        :param enable_https_traffic_only: Whether to allow only HTTPS traffic. Default: true
        :param encryption: Encryption settings.
        :param identity: Managed identity configuration.
        :param ignore_changes: The lifecycle rules to ignore changes.
        :param kind: The kind of Storage Account. Default: "StorageV2"
        :param minimum_tls_version: The minimum TLS version required. Default: "TLS1_2"
        :param network_acls: Network ACL rules for the storage account.
        :param resource_group_id: Resource group ID where the storage account will be created.
        :param api_version: Explicit API version to use for this resource. If not specified, the latest active version will be automatically resolved. Use this for version pinning when stability is required over latest features. Default: Latest active version from ApiVersionManager
        :param enable_migration_analysis: Whether to enable migration analysis warnings. When true, the framework will analyze the current version for deprecation status and provide migration recommendations in the deployment output. Default: true
        :param enable_transformation: Whether to apply property transformations automatically. When true, properties will be automatically transformed according to the target schema's transformation rules. This enables backward compatibility. Default: true
        :param enable_validation: Whether to validate properties against the schema. When true, all properties will be validated against the API schema before resource creation. Validation errors will cause deployment failures. Default: true
        :param location: The location where the resource should be created.
        :param name: The name of the resource.
        :param tags: Tags to apply to the resource.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b723ffd4e5207ba4fcafe0e1ca19c61dbe7d2cfea410be368c89585a651db31c)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = _StorageAccountProps_0b7b5bac(
            sku=sku,
            access_tier=access_tier,
            allow_blob_public_access=allow_blob_public_access,
            enable_https_traffic_only=enable_https_traffic_only,
            encryption=encryption,
            identity=identity,
            ignore_changes=ignore_changes,
            kind=kind,
            minimum_tls_version=minimum_tls_version,
            network_acls=network_acls,
            resource_group_id=resource_group_id,
            api_version=api_version,
            enable_migration_analysis=enable_migration_analysis,
            enable_transformation=enable_transformation,
            enable_validation=enable_validation,
            location=location,
            name=name,
            tags=tags,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="addTag")
    def add_tag(self, key: builtins.str, value: builtins.str) -> None:
        '''Add a tag to the Storage Account.

        :param key: -
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6d4e890b88be1047ae9d17f768064bd1e8113534b01c70eadffeedde9929441b)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "addTag", [key, value]))

    @jsii.member(jsii_name="apiSchema")
    def _api_schema(self) -> _ApiSchema_5ce0490e:
        '''Gets the API schema for the resolved version.'''
        return typing.cast(_ApiSchema_5ce0490e, jsii.invoke(self, "apiSchema", []))

    @jsii.member(jsii_name="createResourceBody")
    def _create_resource_body(self, props: typing.Any) -> typing.Any:
        '''Creates the resource body for the Azure API call.

        :param props: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ba54a1f3260d1a10e0e0845ba8ad70caf3468f8b4c2ef774f8198d9f228b1e11)
            check_type(argname="argument props", value=props, expected_type=type_hints["props"])
        return typing.cast(typing.Any, jsii.invoke(self, "createResourceBody", [props]))

    @jsii.member(jsii_name="defaultVersion")
    def _default_version(self) -> builtins.str:
        '''Gets the default API version to use when no explicit version is specified.'''
        return typing.cast(builtins.str, jsii.invoke(self, "defaultVersion", []))

    @jsii.member(jsii_name="removeTag")
    def remove_tag(self, key: builtins.str) -> None:
        '''Remove a tag from the Storage Account.

        :param key: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__900410703cbb9d837c440ac28e508c62fba57a49e5ebfcc50111c14f14238d7b)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
        return typing.cast(None, jsii.invoke(self, "removeTag", [key]))

    @jsii.member(jsii_name="resourceType")
    def _resource_type(self) -> builtins.str:
        '''Gets the Azure resource type for Storage Accounts.'''
        return typing.cast(builtins.str, jsii.invoke(self, "resourceType", []))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        '''The resource ID (abstract - must be implemented by subclasses).'''
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @builtins.property
    @jsii.member(jsii_name="idOutput")
    def id_output(self) -> _cdktf_9a9027ec.TerraformOutput:
        return typing.cast(_cdktf_9a9027ec.TerraformOutput, jsii.get(self, "idOutput"))

    @builtins.property
    @jsii.member(jsii_name="locationOutput")
    def location_output(self) -> _cdktf_9a9027ec.TerraformOutput:
        return typing.cast(_cdktf_9a9027ec.TerraformOutput, jsii.get(self, "locationOutput"))

    @builtins.property
    @jsii.member(jsii_name="nameOutput")
    def name_output(self) -> _cdktf_9a9027ec.TerraformOutput:
        return typing.cast(_cdktf_9a9027ec.TerraformOutput, jsii.get(self, "nameOutput"))

    @builtins.property
    @jsii.member(jsii_name="primaryBlobEndpoint")
    def primary_blob_endpoint(self) -> builtins.str:
        '''Get the primary blob endpoint.'''
        return typing.cast(builtins.str, jsii.get(self, "primaryBlobEndpoint"))

    @builtins.property
    @jsii.member(jsii_name="primaryEndpointsOutput")
    def primary_endpoints_output(self) -> _cdktf_9a9027ec.TerraformOutput:
        return typing.cast(_cdktf_9a9027ec.TerraformOutput, jsii.get(self, "primaryEndpointsOutput"))

    @builtins.property
    @jsii.member(jsii_name="primaryFileEndpoint")
    def primary_file_endpoint(self) -> builtins.str:
        '''Get the primary file endpoint.'''
        return typing.cast(builtins.str, jsii.get(self, "primaryFileEndpoint"))

    @builtins.property
    @jsii.member(jsii_name="primaryQueueEndpoint")
    def primary_queue_endpoint(self) -> builtins.str:
        '''Get the primary queue endpoint.'''
        return typing.cast(builtins.str, jsii.get(self, "primaryQueueEndpoint"))

    @builtins.property
    @jsii.member(jsii_name="primaryTableEndpoint")
    def primary_table_endpoint(self) -> builtins.str:
        '''Get the primary table endpoint.'''
        return typing.cast(builtins.str, jsii.get(self, "primaryTableEndpoint"))

    @builtins.property
    @jsii.member(jsii_name="props")
    def props(self) -> _StorageAccountProps_0b7b5bac:
        return typing.cast(_StorageAccountProps_0b7b5bac, jsii.get(self, "props"))

    @builtins.property
    @jsii.member(jsii_name="tags")
    def tags(self) -> typing.Mapping[builtins.str, builtins.str]:
        return typing.cast(typing.Mapping[builtins.str, builtins.str], jsii.get(self, "tags"))

    @builtins.property
    @jsii.member(jsii_name="tagsOutput")
    def tags_output(self) -> _cdktf_9a9027ec.TerraformOutput:
        return typing.cast(_cdktf_9a9027ec.TerraformOutput, jsii.get(self, "tagsOutput"))


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.StorageAccountBody",
    jsii_struct_bases=[],
    name_mapping={
        "kind": "kind",
        "location": "location",
        "sku": "sku",
        "identity": "identity",
        "properties": "properties",
        "tags": "tags",
    },
)
class StorageAccountBody:
    def __init__(
        self,
        *,
        kind: builtins.str,
        location: builtins.str,
        sku: typing.Union[_StorageAccountSku_fa953b33, typing.Dict[builtins.str, typing.Any]],
        identity: typing.Optional[typing.Union[_StorageAccountIdentity_d6b6a344, typing.Dict[builtins.str, typing.Any]]] = None,
        properties: typing.Optional[typing.Union[_StorageAccountBodyProperties_4d550b33, typing.Dict[builtins.str, typing.Any]]] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> None:
        '''The resource body interface for Azure Storage Account API calls.

        :param kind: 
        :param location: 
        :param sku: 
        :param identity: 
        :param properties: 
        :param tags: 
        '''
        if isinstance(sku, dict):
            sku = _StorageAccountSku_fa953b33(**sku)
        if isinstance(identity, dict):
            identity = _StorageAccountIdentity_d6b6a344(**identity)
        if isinstance(properties, dict):
            properties = _StorageAccountBodyProperties_4d550b33(**properties)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b57d5b316754bbd430424592c26503e0ccd012f480d21900f4dad4d48b1398b2)
            check_type(argname="argument kind", value=kind, expected_type=type_hints["kind"])
            check_type(argname="argument location", value=location, expected_type=type_hints["location"])
            check_type(argname="argument sku", value=sku, expected_type=type_hints["sku"])
            check_type(argname="argument identity", value=identity, expected_type=type_hints["identity"])
            check_type(argname="argument properties", value=properties, expected_type=type_hints["properties"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "kind": kind,
            "location": location,
            "sku": sku,
        }
        if identity is not None:
            self._values["identity"] = identity
        if properties is not None:
            self._values["properties"] = properties
        if tags is not None:
            self._values["tags"] = tags

    @builtins.property
    def kind(self) -> builtins.str:
        result = self._values.get("kind")
        assert result is not None, "Required property 'kind' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def location(self) -> builtins.str:
        result = self._values.get("location")
        assert result is not None, "Required property 'location' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def sku(self) -> _StorageAccountSku_fa953b33:
        result = self._values.get("sku")
        assert result is not None, "Required property 'sku' is missing"
        return typing.cast(_StorageAccountSku_fa953b33, result)

    @builtins.property
    def identity(self) -> typing.Optional[_StorageAccountIdentity_d6b6a344]:
        result = self._values.get("identity")
        return typing.cast(typing.Optional[_StorageAccountIdentity_d6b6a344], result)

    @builtins.property
    def properties(self) -> typing.Optional[_StorageAccountBodyProperties_4d550b33]:
        result = self._values.get("properties")
        return typing.cast(typing.Optional[_StorageAccountBodyProperties_4d550b33], result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StorageAccountBody(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.StorageAccountBodyProperties",
    jsii_struct_bases=[],
    name_mapping={
        "access_tier": "accessTier",
        "allow_blob_public_access": "allowBlobPublicAccess",
        "encryption": "encryption",
        "minimum_tls_version": "minimumTlsVersion",
        "network_acls": "networkAcls",
        "supports_https_traffic_only": "supportsHttpsTrafficOnly",
    },
)
class StorageAccountBodyProperties:
    def __init__(
        self,
        *,
        access_tier: typing.Optional[builtins.str] = None,
        allow_blob_public_access: typing.Optional[builtins.bool] = None,
        encryption: typing.Optional[typing.Union[_StorageAccountEncryption_77d27837, typing.Dict[builtins.str, typing.Any]]] = None,
        minimum_tls_version: typing.Optional[builtins.str] = None,
        network_acls: typing.Optional[typing.Union[_StorageAccountNetworkAcls_768fda36, typing.Dict[builtins.str, typing.Any]]] = None,
        supports_https_traffic_only: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''Storage Account properties for the request body.

        :param access_tier: 
        :param allow_blob_public_access: 
        :param encryption: 
        :param minimum_tls_version: 
        :param network_acls: 
        :param supports_https_traffic_only: 
        '''
        if isinstance(encryption, dict):
            encryption = _StorageAccountEncryption_77d27837(**encryption)
        if isinstance(network_acls, dict):
            network_acls = _StorageAccountNetworkAcls_768fda36(**network_acls)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__40f569c3e3a12c7436014caf94387a09bff2f9c6f171ccb9d8f510fc2f60ec1b)
            check_type(argname="argument access_tier", value=access_tier, expected_type=type_hints["access_tier"])
            check_type(argname="argument allow_blob_public_access", value=allow_blob_public_access, expected_type=type_hints["allow_blob_public_access"])
            check_type(argname="argument encryption", value=encryption, expected_type=type_hints["encryption"])
            check_type(argname="argument minimum_tls_version", value=minimum_tls_version, expected_type=type_hints["minimum_tls_version"])
            check_type(argname="argument network_acls", value=network_acls, expected_type=type_hints["network_acls"])
            check_type(argname="argument supports_https_traffic_only", value=supports_https_traffic_only, expected_type=type_hints["supports_https_traffic_only"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if access_tier is not None:
            self._values["access_tier"] = access_tier
        if allow_blob_public_access is not None:
            self._values["allow_blob_public_access"] = allow_blob_public_access
        if encryption is not None:
            self._values["encryption"] = encryption
        if minimum_tls_version is not None:
            self._values["minimum_tls_version"] = minimum_tls_version
        if network_acls is not None:
            self._values["network_acls"] = network_acls
        if supports_https_traffic_only is not None:
            self._values["supports_https_traffic_only"] = supports_https_traffic_only

    @builtins.property
    def access_tier(self) -> typing.Optional[builtins.str]:
        result = self._values.get("access_tier")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def allow_blob_public_access(self) -> typing.Optional[builtins.bool]:
        result = self._values.get("allow_blob_public_access")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def encryption(self) -> typing.Optional[_StorageAccountEncryption_77d27837]:
        result = self._values.get("encryption")
        return typing.cast(typing.Optional[_StorageAccountEncryption_77d27837], result)

    @builtins.property
    def minimum_tls_version(self) -> typing.Optional[builtins.str]:
        result = self._values.get("minimum_tls_version")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def network_acls(self) -> typing.Optional[_StorageAccountNetworkAcls_768fda36]:
        result = self._values.get("network_acls")
        return typing.cast(typing.Optional[_StorageAccountNetworkAcls_768fda36], result)

    @builtins.property
    def supports_https_traffic_only(self) -> typing.Optional[builtins.bool]:
        result = self._values.get("supports_https_traffic_only")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StorageAccountBodyProperties(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.StorageAccountEncryption",
    jsii_struct_bases=[],
    name_mapping={"key_source": "keySource", "services": "services"},
)
class StorageAccountEncryption:
    def __init__(
        self,
        *,
        key_source: typing.Optional[builtins.str] = None,
        services: typing.Optional[typing.Union[_StorageAccountEncryptionServices_8a1bf271, typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''Encryption configuration for Storage Account.

        :param key_source: Key source (Microsoft.Storage or Microsoft.Keyvault).
        :param services: Encryption services (blob, file, table, queue).
        '''
        if isinstance(services, dict):
            services = _StorageAccountEncryptionServices_8a1bf271(**services)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8ed14d2e557eb2340e8a610a56556e2f85a87f10993561aa732e622fda9d4dce)
            check_type(argname="argument key_source", value=key_source, expected_type=type_hints["key_source"])
            check_type(argname="argument services", value=services, expected_type=type_hints["services"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if key_source is not None:
            self._values["key_source"] = key_source
        if services is not None:
            self._values["services"] = services

    @builtins.property
    def key_source(self) -> typing.Optional[builtins.str]:
        '''Key source (Microsoft.Storage or Microsoft.Keyvault).'''
        result = self._values.get("key_source")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def services(self) -> typing.Optional[_StorageAccountEncryptionServices_8a1bf271]:
        '''Encryption services (blob, file, table, queue).'''
        result = self._values.get("services")
        return typing.cast(typing.Optional[_StorageAccountEncryptionServices_8a1bf271], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StorageAccountEncryption(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.StorageAccountEncryptionService",
    jsii_struct_bases=[],
    name_mapping={"enabled": "enabled"},
)
class StorageAccountEncryptionService:
    def __init__(self, *, enabled: typing.Optional[builtins.bool] = None) -> None:
        '''Encryption service configuration.

        :param enabled: Whether encryption is enabled.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a6d0ec7498167d2e53cc6b520284093055f4a44fab1eb71da6132dfb50211bb6)
            check_type(argname="argument enabled", value=enabled, expected_type=type_hints["enabled"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if enabled is not None:
            self._values["enabled"] = enabled

    @builtins.property
    def enabled(self) -> typing.Optional[builtins.bool]:
        '''Whether encryption is enabled.'''
        result = self._values.get("enabled")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StorageAccountEncryptionService(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.StorageAccountEncryptionServices",
    jsii_struct_bases=[],
    name_mapping={"blob": "blob", "file": "file", "queue": "queue", "table": "table"},
)
class StorageAccountEncryptionServices:
    def __init__(
        self,
        *,
        blob: typing.Optional[typing.Union[_StorageAccountEncryptionService_aaadb7be, typing.Dict[builtins.str, typing.Any]]] = None,
        file: typing.Optional[typing.Union[_StorageAccountEncryptionService_aaadb7be, typing.Dict[builtins.str, typing.Any]]] = None,
        queue: typing.Optional[typing.Union[_StorageAccountEncryptionService_aaadb7be, typing.Dict[builtins.str, typing.Any]]] = None,
        table: typing.Optional[typing.Union[_StorageAccountEncryptionService_aaadb7be, typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''Encryption services configuration.

        :param blob: Blob service encryption.
        :param file: File service encryption.
        :param queue: Queue service encryption.
        :param table: Table service encryption.
        '''
        if isinstance(blob, dict):
            blob = _StorageAccountEncryptionService_aaadb7be(**blob)
        if isinstance(file, dict):
            file = _StorageAccountEncryptionService_aaadb7be(**file)
        if isinstance(queue, dict):
            queue = _StorageAccountEncryptionService_aaadb7be(**queue)
        if isinstance(table, dict):
            table = _StorageAccountEncryptionService_aaadb7be(**table)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b7563a9805c7ad8fed6c30d58d9736388e5ad53e0f156ba7c14a77e9561b0a38)
            check_type(argname="argument blob", value=blob, expected_type=type_hints["blob"])
            check_type(argname="argument file", value=file, expected_type=type_hints["file"])
            check_type(argname="argument queue", value=queue, expected_type=type_hints["queue"])
            check_type(argname="argument table", value=table, expected_type=type_hints["table"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if blob is not None:
            self._values["blob"] = blob
        if file is not None:
            self._values["file"] = file
        if queue is not None:
            self._values["queue"] = queue
        if table is not None:
            self._values["table"] = table

    @builtins.property
    def blob(self) -> typing.Optional[_StorageAccountEncryptionService_aaadb7be]:
        '''Blob service encryption.'''
        result = self._values.get("blob")
        return typing.cast(typing.Optional[_StorageAccountEncryptionService_aaadb7be], result)

    @builtins.property
    def file(self) -> typing.Optional[_StorageAccountEncryptionService_aaadb7be]:
        '''File service encryption.'''
        result = self._values.get("file")
        return typing.cast(typing.Optional[_StorageAccountEncryptionService_aaadb7be], result)

    @builtins.property
    def queue(self) -> typing.Optional[_StorageAccountEncryptionService_aaadb7be]:
        '''Queue service encryption.'''
        result = self._values.get("queue")
        return typing.cast(typing.Optional[_StorageAccountEncryptionService_aaadb7be], result)

    @builtins.property
    def table(self) -> typing.Optional[_StorageAccountEncryptionService_aaadb7be]:
        '''Table service encryption.'''
        result = self._values.get("table")
        return typing.cast(typing.Optional[_StorageAccountEncryptionService_aaadb7be], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StorageAccountEncryptionServices(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.StorageAccountIdentity",
    jsii_struct_bases=[],
    name_mapping={
        "type": "type",
        "user_assigned_identities": "userAssignedIdentities",
    },
)
class StorageAccountIdentity:
    def __init__(
        self,
        *,
        type: builtins.str,
        user_assigned_identities: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    ) -> None:
        '''Identity configuration for Storage Account.

        :param type: The type of identity (SystemAssigned, UserAssigned, SystemAssigned,UserAssigned).
        :param user_assigned_identities: User assigned identity IDs.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__502fa19b120d6e7109eec152cd494ff2ee5ddbe633cca88345174662345345f4)
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            check_type(argname="argument user_assigned_identities", value=user_assigned_identities, expected_type=type_hints["user_assigned_identities"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "type": type,
        }
        if user_assigned_identities is not None:
            self._values["user_assigned_identities"] = user_assigned_identities

    @builtins.property
    def type(self) -> builtins.str:
        '''The type of identity (SystemAssigned, UserAssigned, SystemAssigned,UserAssigned).'''
        result = self._values.get("type")
        assert result is not None, "Required property 'type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def user_assigned_identities(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        '''User assigned identity IDs.'''
        result = self._values.get("user_assigned_identities")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StorageAccountIdentity(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.StorageAccountIpRule",
    jsii_struct_bases=[],
    name_mapping={"value": "value"},
)
class StorageAccountIpRule:
    def __init__(self, *, value: builtins.str) -> None:
        '''IP rule for network ACLs.

        :param value: IP address or CIDR range.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4b79a21076dc9f14021e21bf25e1dc488ee8035373bd2369979335116b3cfabb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "value": value,
        }

    @builtins.property
    def value(self) -> builtins.str:
        '''IP address or CIDR range.'''
        result = self._values.get("value")
        assert result is not None, "Required property 'value' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StorageAccountIpRule(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.StorageAccountNetworkAcls",
    jsii_struct_bases=[],
    name_mapping={
        "bypass": "bypass",
        "default_action": "defaultAction",
        "ip_rules": "ipRules",
        "virtual_network_rules": "virtualNetworkRules",
    },
)
class StorageAccountNetworkAcls:
    def __init__(
        self,
        *,
        bypass: typing.Optional[builtins.str] = None,
        default_action: typing.Optional[builtins.str] = None,
        ip_rules: typing.Optional[typing.Sequence[typing.Union[_StorageAccountIpRule_83a6da4e, typing.Dict[builtins.str, typing.Any]]]] = None,
        virtual_network_rules: typing.Optional[typing.Sequence[typing.Union[_StorageAccountVirtualNetworkRule_825a3860, typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> None:
        '''Network ACL configuration for Storage Account.

        :param bypass: Whether to bypass network rules for Azure services.
        :param default_action: Default action when no rule matches (Allow or Deny).
        :param ip_rules: IP rules for the storage account.
        :param virtual_network_rules: Virtual network rules for the storage account.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1f28dba6ea2cd128a19e73772f7563bbbde15eba3f292a0b0bf9b031557ae004)
            check_type(argname="argument bypass", value=bypass, expected_type=type_hints["bypass"])
            check_type(argname="argument default_action", value=default_action, expected_type=type_hints["default_action"])
            check_type(argname="argument ip_rules", value=ip_rules, expected_type=type_hints["ip_rules"])
            check_type(argname="argument virtual_network_rules", value=virtual_network_rules, expected_type=type_hints["virtual_network_rules"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if bypass is not None:
            self._values["bypass"] = bypass
        if default_action is not None:
            self._values["default_action"] = default_action
        if ip_rules is not None:
            self._values["ip_rules"] = ip_rules
        if virtual_network_rules is not None:
            self._values["virtual_network_rules"] = virtual_network_rules

    @builtins.property
    def bypass(self) -> typing.Optional[builtins.str]:
        '''Whether to bypass network rules for Azure services.'''
        result = self._values.get("bypass")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def default_action(self) -> typing.Optional[builtins.str]:
        '''Default action when no rule matches (Allow or Deny).'''
        result = self._values.get("default_action")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def ip_rules(self) -> typing.Optional[typing.List[_StorageAccountIpRule_83a6da4e]]:
        '''IP rules for the storage account.'''
        result = self._values.get("ip_rules")
        return typing.cast(typing.Optional[typing.List[_StorageAccountIpRule_83a6da4e]], result)

    @builtins.property
    def virtual_network_rules(
        self,
    ) -> typing.Optional[typing.List[_StorageAccountVirtualNetworkRule_825a3860]]:
        '''Virtual network rules for the storage account.'''
        result = self._values.get("virtual_network_rules")
        return typing.cast(typing.Optional[typing.List[_StorageAccountVirtualNetworkRule_825a3860]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StorageAccountNetworkAcls(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.StorageAccountProps",
    jsii_struct_bases=[_AzapiResourceProps_141a2340],
    name_mapping={
        "api_version": "apiVersion",
        "enable_migration_analysis": "enableMigrationAnalysis",
        "enable_transformation": "enableTransformation",
        "enable_validation": "enableValidation",
        "location": "location",
        "name": "name",
        "tags": "tags",
        "sku": "sku",
        "access_tier": "accessTier",
        "allow_blob_public_access": "allowBlobPublicAccess",
        "enable_https_traffic_only": "enableHttpsTrafficOnly",
        "encryption": "encryption",
        "identity": "identity",
        "ignore_changes": "ignoreChanges",
        "kind": "kind",
        "minimum_tls_version": "minimumTlsVersion",
        "network_acls": "networkAcls",
        "resource_group_id": "resourceGroupId",
    },
)
class StorageAccountProps(_AzapiResourceProps_141a2340):
    def __init__(
        self,
        *,
        api_version: typing.Optional[builtins.str] = None,
        enable_migration_analysis: typing.Optional[builtins.bool] = None,
        enable_transformation: typing.Optional[builtins.bool] = None,
        enable_validation: typing.Optional[builtins.bool] = None,
        location: typing.Optional[builtins.str] = None,
        name: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        sku: typing.Union[_StorageAccountSku_fa953b33, typing.Dict[builtins.str, typing.Any]],
        access_tier: typing.Optional[builtins.str] = None,
        allow_blob_public_access: typing.Optional[builtins.bool] = None,
        enable_https_traffic_only: typing.Optional[builtins.bool] = None,
        encryption: typing.Optional[typing.Union[_StorageAccountEncryption_77d27837, typing.Dict[builtins.str, typing.Any]]] = None,
        identity: typing.Optional[typing.Union[_StorageAccountIdentity_d6b6a344, typing.Dict[builtins.str, typing.Any]]] = None,
        ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
        kind: typing.Optional[builtins.str] = None,
        minimum_tls_version: typing.Optional[builtins.str] = None,
        network_acls: typing.Optional[typing.Union[_StorageAccountNetworkAcls_768fda36, typing.Dict[builtins.str, typing.Any]]] = None,
        resource_group_id: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Properties for the unified Azure Storage Account.

        Extends VersionedAzapiResourceProps with Storage Account specific properties

        :param api_version: Explicit API version to use for this resource. If not specified, the latest active version will be automatically resolved. Use this for version pinning when stability is required over latest features. Default: Latest active version from ApiVersionManager
        :param enable_migration_analysis: Whether to enable migration analysis warnings. When true, the framework will analyze the current version for deprecation status and provide migration recommendations in the deployment output. Default: true
        :param enable_transformation: Whether to apply property transformations automatically. When true, properties will be automatically transformed according to the target schema's transformation rules. This enables backward compatibility. Default: true
        :param enable_validation: Whether to validate properties against the schema. When true, all properties will be validated against the API schema before resource creation. Validation errors will cause deployment failures. Default: true
        :param location: The location where the resource should be created.
        :param name: The name of the resource.
        :param tags: Tags to apply to the resource.
        :param sku: The SKU (pricing tier) for the Storage Account.
        :param access_tier: The access tier for blob storage. Default: "Hot"
        :param allow_blob_public_access: Whether to allow public access to blobs. Default: false
        :param enable_https_traffic_only: Whether to allow only HTTPS traffic. Default: true
        :param encryption: Encryption settings.
        :param identity: Managed identity configuration.
        :param ignore_changes: The lifecycle rules to ignore changes.
        :param kind: The kind of Storage Account. Default: "StorageV2"
        :param minimum_tls_version: The minimum TLS version required. Default: "TLS1_2"
        :param network_acls: Network ACL rules for the storage account.
        :param resource_group_id: Resource group ID where the storage account will be created.
        '''
        if isinstance(sku, dict):
            sku = _StorageAccountSku_fa953b33(**sku)
        if isinstance(encryption, dict):
            encryption = _StorageAccountEncryption_77d27837(**encryption)
        if isinstance(identity, dict):
            identity = _StorageAccountIdentity_d6b6a344(**identity)
        if isinstance(network_acls, dict):
            network_acls = _StorageAccountNetworkAcls_768fda36(**network_acls)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__50747e225fb92dcb75801bf29a578ecfd07d5458a3f1b792b469a0235e8c5a49)
            check_type(argname="argument api_version", value=api_version, expected_type=type_hints["api_version"])
            check_type(argname="argument enable_migration_analysis", value=enable_migration_analysis, expected_type=type_hints["enable_migration_analysis"])
            check_type(argname="argument enable_transformation", value=enable_transformation, expected_type=type_hints["enable_transformation"])
            check_type(argname="argument enable_validation", value=enable_validation, expected_type=type_hints["enable_validation"])
            check_type(argname="argument location", value=location, expected_type=type_hints["location"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            check_type(argname="argument sku", value=sku, expected_type=type_hints["sku"])
            check_type(argname="argument access_tier", value=access_tier, expected_type=type_hints["access_tier"])
            check_type(argname="argument allow_blob_public_access", value=allow_blob_public_access, expected_type=type_hints["allow_blob_public_access"])
            check_type(argname="argument enable_https_traffic_only", value=enable_https_traffic_only, expected_type=type_hints["enable_https_traffic_only"])
            check_type(argname="argument encryption", value=encryption, expected_type=type_hints["encryption"])
            check_type(argname="argument identity", value=identity, expected_type=type_hints["identity"])
            check_type(argname="argument ignore_changes", value=ignore_changes, expected_type=type_hints["ignore_changes"])
            check_type(argname="argument kind", value=kind, expected_type=type_hints["kind"])
            check_type(argname="argument minimum_tls_version", value=minimum_tls_version, expected_type=type_hints["minimum_tls_version"])
            check_type(argname="argument network_acls", value=network_acls, expected_type=type_hints["network_acls"])
            check_type(argname="argument resource_group_id", value=resource_group_id, expected_type=type_hints["resource_group_id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "sku": sku,
        }
        if api_version is not None:
            self._values["api_version"] = api_version
        if enable_migration_analysis is not None:
            self._values["enable_migration_analysis"] = enable_migration_analysis
        if enable_transformation is not None:
            self._values["enable_transformation"] = enable_transformation
        if enable_validation is not None:
            self._values["enable_validation"] = enable_validation
        if location is not None:
            self._values["location"] = location
        if name is not None:
            self._values["name"] = name
        if tags is not None:
            self._values["tags"] = tags
        if access_tier is not None:
            self._values["access_tier"] = access_tier
        if allow_blob_public_access is not None:
            self._values["allow_blob_public_access"] = allow_blob_public_access
        if enable_https_traffic_only is not None:
            self._values["enable_https_traffic_only"] = enable_https_traffic_only
        if encryption is not None:
            self._values["encryption"] = encryption
        if identity is not None:
            self._values["identity"] = identity
        if ignore_changes is not None:
            self._values["ignore_changes"] = ignore_changes
        if kind is not None:
            self._values["kind"] = kind
        if minimum_tls_version is not None:
            self._values["minimum_tls_version"] = minimum_tls_version
        if network_acls is not None:
            self._values["network_acls"] = network_acls
        if resource_group_id is not None:
            self._values["resource_group_id"] = resource_group_id

    @builtins.property
    def api_version(self) -> typing.Optional[builtins.str]:
        '''Explicit API version to use for this resource.

        If not specified, the latest active version will be automatically resolved.
        Use this for version pinning when stability is required over latest features.

        :default: Latest active version from ApiVersionManager

        Example::

            "2024-11-01"
        '''
        result = self._values.get("api_version")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def enable_migration_analysis(self) -> typing.Optional[builtins.bool]:
        '''Whether to enable migration analysis warnings.

        When true, the framework will analyze the current version for deprecation
        status and provide migration recommendations in the deployment output.

        :default: true
        '''
        result = self._values.get("enable_migration_analysis")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_transformation(self) -> typing.Optional[builtins.bool]:
        '''Whether to apply property transformations automatically.

        When true, properties will be automatically transformed according to the
        target schema's transformation rules. This enables backward compatibility.

        :default: true
        '''
        result = self._values.get("enable_transformation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_validation(self) -> typing.Optional[builtins.bool]:
        '''Whether to validate properties against the schema.

        When true, all properties will be validated against the API schema before
        resource creation. Validation errors will cause deployment failures.

        :default: true
        '''
        result = self._values.get("enable_validation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def location(self) -> typing.Optional[builtins.str]:
        '''The location where the resource should be created.'''
        result = self._values.get("location")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''The name of the resource.'''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Tags to apply to the resource.'''
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def sku(self) -> _StorageAccountSku_fa953b33:
        '''The SKU (pricing tier) for the Storage Account.

        Example::

            { name: "Standard_LRS" }
        '''
        result = self._values.get("sku")
        assert result is not None, "Required property 'sku' is missing"
        return typing.cast(_StorageAccountSku_fa953b33, result)

    @builtins.property
    def access_tier(self) -> typing.Optional[builtins.str]:
        '''The access tier for blob storage.

        :default: "Hot"

        Example::

            "Hot", "Cool"
        '''
        result = self._values.get("access_tier")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def allow_blob_public_access(self) -> typing.Optional[builtins.bool]:
        '''Whether to allow public access to blobs.

        :default: false
        '''
        result = self._values.get("allow_blob_public_access")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_https_traffic_only(self) -> typing.Optional[builtins.bool]:
        '''Whether to allow only HTTPS traffic.

        :default: true
        '''
        result = self._values.get("enable_https_traffic_only")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def encryption(self) -> typing.Optional[_StorageAccountEncryption_77d27837]:
        '''Encryption settings.'''
        result = self._values.get("encryption")
        return typing.cast(typing.Optional[_StorageAccountEncryption_77d27837], result)

    @builtins.property
    def identity(self) -> typing.Optional[_StorageAccountIdentity_d6b6a344]:
        '''Managed identity configuration.'''
        result = self._values.get("identity")
        return typing.cast(typing.Optional[_StorageAccountIdentity_d6b6a344], result)

    @builtins.property
    def ignore_changes(self) -> typing.Optional[typing.List[builtins.str]]:
        '''The lifecycle rules to ignore changes.

        Example::

            ["tags"]
        '''
        result = self._values.get("ignore_changes")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def kind(self) -> typing.Optional[builtins.str]:
        '''The kind of Storage Account.

        :default: "StorageV2"

        Example::

            "StorageV2", "BlobStorage", "BlockBlobStorage", "FileStorage"
        '''
        result = self._values.get("kind")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def minimum_tls_version(self) -> typing.Optional[builtins.str]:
        '''The minimum TLS version required.

        :default: "TLS1_2"
        '''
        result = self._values.get("minimum_tls_version")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def network_acls(self) -> typing.Optional[_StorageAccountNetworkAcls_768fda36]:
        '''Network ACL rules for the storage account.'''
        result = self._values.get("network_acls")
        return typing.cast(typing.Optional[_StorageAccountNetworkAcls_768fda36], result)

    @builtins.property
    def resource_group_id(self) -> typing.Optional[builtins.str]:
        '''Resource group ID where the storage account will be created.'''
        result = self._values.get("resource_group_id")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StorageAccountProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.StorageAccountSku",
    jsii_struct_bases=[],
    name_mapping={"name": "name"},
)
class StorageAccountSku:
    def __init__(self, *, name: builtins.str) -> None:
        '''SKU configuration for Storage Account.

        :param name: The SKU name (Standard_LRS, Standard_GRS, Standard_RAGRS, Standard_ZRS, Premium_LRS, Premium_ZRS).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f170c62cdf8fb6a8a124b20e1b48a309ba2dc3cbbdf6ddc5798be9e101de4ba1)
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "name": name,
        }

    @builtins.property
    def name(self) -> builtins.str:
        '''The SKU name (Standard_LRS, Standard_GRS, Standard_RAGRS, Standard_ZRS, Premium_LRS, Premium_ZRS).'''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StorageAccountSku(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.StorageAccountVirtualNetworkRule",
    jsii_struct_bases=[],
    name_mapping={"id": "id"},
)
class StorageAccountVirtualNetworkRule:
    def __init__(self, *, id: builtins.str) -> None:
        '''Virtual network rule for network ACLs.

        :param id: Virtual network resource ID.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3073662893bd85c109decc801fdb5b5d9ef7d2f526570fb1f6dcf9bc82edbd9a)
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "id": id,
        }

    @builtins.property
    def id(self) -> builtins.str:
        '''Virtual network resource ID.'''
        result = self._values.get("id")
        assert result is not None, "Required property 'id' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StorageAccountVirtualNetworkRule(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class UpdateResource(
    _cdktf_9a9027ec.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.UpdateResource",
):
    '''Represents a {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource azapi_update_resource}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id: builtins.str,
        *,
        type: builtins.str,
        body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        ignore_casing: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
        ignore_missing_property: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
        locks: typing.Optional[typing.Sequence[builtins.str]] = None,
        name: typing.Optional[builtins.str] = None,
        parent_id: typing.Optional[builtins.str] = None,
        read_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        read_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
        resource_id: typing.Optional[builtins.str] = None,
        response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        retry: typing.Optional[typing.Union["UpdateResourceRetry", typing.Dict[builtins.str, typing.Any]]] = None,
        sensitive_body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        sensitive_body_version: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        timeouts: typing.Optional[typing.Union["UpdateResourceTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        update_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        update_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource azapi_update_resource} Resource.

        :param scope: The scope in which to define this construct.
        :param id: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param type: In a format like ``<resource-type>@<api-version>``. ``<resource-type>`` is the Azure resource type, for example, ``Microsoft.Storage/storageAccounts``. ``<api-version>`` is version of the API used to manage this azure resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#type UpdateResource#type}
        :param body: A dynamic attribute that contains the request body. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#body UpdateResource#body}
        :param ignore_casing: Whether ignore the casing of the property names in the response body. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#ignore_casing UpdateResource#ignore_casing}
        :param ignore_missing_property: Whether ignore not returned properties like credentials in ``body`` to suppress plan-diff. Defaults to ``true``. It's recommend to enable this option when some sensitive properties are not returned in response body, instead of setting them in ``lifecycle.ignore_changes`` because it will make the sensitive fields unable to update. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#ignore_missing_property UpdateResource#ignore_missing_property}
        :param locks: A list of ARM resource IDs which are used to avoid create/modify/delete azapi resources at the same time. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#locks UpdateResource#locks}
        :param name: Specifies the name of the Azure resource. Changing this forces a new resource to be created. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#name UpdateResource#name}
        :param parent_id: The ID of the azure resource in which this resource is created. It supports different kinds of deployment scope for **top level** resources: - resource group scope: ``parent_id`` should be the ID of a resource group, it's recommended to manage a resource group by azurerm_resource_group. - management group scope: ``parent_id`` should be the ID of a management group, it's recommended to manage a management group by azurerm_management_group. - extension scope: ``parent_id`` should be the ID of the resource you're adding the extension to. - subscription scope: ``parent_id`` should be like \\x60/subscriptions/00000000-0000-0000-0000-000000000000\\x60 - tenant scope: ``parent_id`` should be / For child level resources, the ``parent_id`` should be the ID of its parent resource, for example, subnet resource's ``parent_id`` is the ID of the vnet. For type ``Microsoft.Resources/resourceGroups``, the ``parent_id`` could be omitted, it defaults to subscription ID specified in provider or the default subscription (You could check the default subscription by azure cli command: ``az account show``). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#parent_id UpdateResource#parent_id}
        :param read_headers: A mapping of headers to be sent with the read request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#read_headers UpdateResource#read_headers}
        :param read_query_parameters: A mapping of query parameters to be sent with the read request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#read_query_parameters UpdateResource#read_query_parameters}
        :param resource_id: The ID of an existing Azure source. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#resource_id UpdateResource#resource_id}
        :param response_export_values: The attribute can accept either a list or a map. - **List**: A list of paths that need to be exported from the response body. Setting it to ``["*"]`` will export the full response body. Here's an example. If it sets to ``["properties.loginServer", "properties.policies.quarantinePolicy.status"]``, it will set the following HCL object to the computed property output. Example:: { properties = { loginServer = "registry1.azurecr.io" policies = { quarantinePolicy = { status = "disabled" } } } } - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to ``{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}``, it will set the following HCL object to the computed property output. Example:: { "login_server" = "registry1.azurecr.io" "quarantine_status" = "disabled" } To learn more about JMESPath, visit `JMESPath <https://jmespath.org/>`_. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#response_export_values UpdateResource#response_export_values}
        :param retry: The retry object supports the following attributes:. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#retry UpdateResource#retry}
        :param sensitive_body: A dynamic attribute that contains the write-only properties of the request body. This will be merge-patched to the body to construct the actual request body. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#sensitive_body UpdateResource#sensitive_body}
        :param sensitive_body_version: A map where the key is the path to the property in ``sensitive_body`` and the value is the version of the property. The key is a string in the format of ``path.to.property[index].subproperty``, where ``index`` is the index of the item in an array. When the version is changed, the property will be included in the request body, otherwise it will be omitted from the request body. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#sensitive_body_version UpdateResource#sensitive_body_version}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#timeouts UpdateResource#timeouts}
        :param update_headers: A mapping of headers to be sent with the update request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#update_headers UpdateResource#update_headers}
        :param update_query_parameters: A mapping of query parameters to be sent with the update request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#update_query_parameters UpdateResource#update_query_parameters}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__281208bd5979459b2fb9c40473b7e56ff3827a001dfdab3f367e6d9fa584f1ad)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        config = UpdateResourceConfig(
            type=type,
            body=body,
            ignore_casing=ignore_casing,
            ignore_missing_property=ignore_missing_property,
            locks=locks,
            name=name,
            parent_id=parent_id,
            read_headers=read_headers,
            read_query_parameters=read_query_parameters,
            resource_id=resource_id,
            response_export_values=response_export_values,
            retry=retry,
            sensitive_body=sensitive_body,
            sensitive_body_version=sensitive_body_version,
            timeouts=timeouts,
            update_headers=update_headers,
            update_query_parameters=update_query_parameters,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id, config])

    @jsii.member(jsii_name="putRetry")
    def put_retry(
        self,
        *,
        error_message_regex: typing.Sequence[builtins.str],
        interval_seconds: typing.Optional[jsii.Number] = None,
        max_interval_seconds: typing.Optional[jsii.Number] = None,
        multiplier: typing.Optional[jsii.Number] = None,
        randomization_factor: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param error_message_regex: A list of regular expressions to match against error messages. If any of the regular expressions match, the request will be retried. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#error_message_regex UpdateResource#error_message_regex}
        :param interval_seconds: The base number of seconds to wait between retries. Default is ``10``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#interval_seconds UpdateResource#interval_seconds}
        :param max_interval_seconds: The maximum number of seconds to wait between retries. Default is ``180``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#max_interval_seconds UpdateResource#max_interval_seconds}
        :param multiplier: The multiplier to apply to the interval between retries. Default is ``1.5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#multiplier UpdateResource#multiplier}
        :param randomization_factor: The randomization factor to apply to the interval between retries. The formula for the randomized interval is: ``RetryInterval * (random value in range [1 - RandomizationFactor, 1 + RandomizationFactor])``. Therefore set to zero ``0.0`` for no randomization. Default is ``0.5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#randomization_factor UpdateResource#randomization_factor}
        '''
        value = UpdateResourceRetry(
            error_message_regex=error_message_regex,
            interval_seconds=interval_seconds,
            max_interval_seconds=max_interval_seconds,
            multiplier=multiplier,
            randomization_factor=randomization_factor,
        )

        return typing.cast(None, jsii.invoke(self, "putRetry", [value]))

    @jsii.member(jsii_name="putTimeouts")
    def put_timeouts(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#create UpdateResource#create}
        :param delete: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#delete UpdateResource#delete}
        :param read: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#read UpdateResource#read}
        :param update: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#update UpdateResource#update}
        '''
        value = UpdateResourceTimeouts(
            create=create, delete=delete, read=read, update=update
        )

        return typing.cast(None, jsii.invoke(self, "putTimeouts", [value]))

    @jsii.member(jsii_name="resetBody")
    def reset_body(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBody", []))

    @jsii.member(jsii_name="resetIgnoreCasing")
    def reset_ignore_casing(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIgnoreCasing", []))

    @jsii.member(jsii_name="resetIgnoreMissingProperty")
    def reset_ignore_missing_property(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIgnoreMissingProperty", []))

    @jsii.member(jsii_name="resetLocks")
    def reset_locks(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetLocks", []))

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @jsii.member(jsii_name="resetParentId")
    def reset_parent_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetParentId", []))

    @jsii.member(jsii_name="resetReadHeaders")
    def reset_read_headers(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReadHeaders", []))

    @jsii.member(jsii_name="resetReadQueryParameters")
    def reset_read_query_parameters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReadQueryParameters", []))

    @jsii.member(jsii_name="resetResourceId")
    def reset_resource_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceId", []))

    @jsii.member(jsii_name="resetResponseExportValues")
    def reset_response_export_values(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResponseExportValues", []))

    @jsii.member(jsii_name="resetRetry")
    def reset_retry(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRetry", []))

    @jsii.member(jsii_name="resetSensitiveBody")
    def reset_sensitive_body(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSensitiveBody", []))

    @jsii.member(jsii_name="resetSensitiveBodyVersion")
    def reset_sensitive_body_version(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSensitiveBodyVersion", []))

    @jsii.member(jsii_name="resetTimeouts")
    def reset_timeouts(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeouts", []))

    @jsii.member(jsii_name="resetUpdateHeaders")
    def reset_update_headers(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUpdateHeaders", []))

    @jsii.member(jsii_name="resetUpdateQueryParameters")
    def reset_update_query_parameters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUpdateQueryParameters", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @builtins.property
    @jsii.member(jsii_name="output")
    def output(self) -> _cdktf_9a9027ec.AnyMap:
        return typing.cast(_cdktf_9a9027ec.AnyMap, jsii.get(self, "output"))

    @builtins.property
    @jsii.member(jsii_name="retry")
    def retry(self) -> "UpdateResourceRetryOutputReference":
        return typing.cast("UpdateResourceRetryOutputReference", jsii.get(self, "retry"))

    @builtins.property
    @jsii.member(jsii_name="timeouts")
    def timeouts(self) -> "UpdateResourceTimeoutsOutputReference":
        return typing.cast("UpdateResourceTimeoutsOutputReference", jsii.get(self, "timeouts"))

    @builtins.property
    @jsii.member(jsii_name="bodyInput")
    def body_input(self) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], jsii.get(self, "bodyInput"))

    @builtins.property
    @jsii.member(jsii_name="ignoreCasingInput")
    def ignore_casing_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]], jsii.get(self, "ignoreCasingInput"))

    @builtins.property
    @jsii.member(jsii_name="ignoreMissingPropertyInput")
    def ignore_missing_property_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]], jsii.get(self, "ignoreMissingPropertyInput"))

    @builtins.property
    @jsii.member(jsii_name="locksInput")
    def locks_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "locksInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="parentIdInput")
    def parent_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "parentIdInput"))

    @builtins.property
    @jsii.member(jsii_name="readHeadersInput")
    def read_headers_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], jsii.get(self, "readHeadersInput"))

    @builtins.property
    @jsii.member(jsii_name="readQueryParametersInput")
    def read_query_parameters_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]], jsii.get(self, "readQueryParametersInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceIdInput")
    def resource_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "resourceIdInput"))

    @builtins.property
    @jsii.member(jsii_name="responseExportValuesInput")
    def response_export_values_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], jsii.get(self, "responseExportValuesInput"))

    @builtins.property
    @jsii.member(jsii_name="retryInput")
    def retry_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "UpdateResourceRetry"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "UpdateResourceRetry"]], jsii.get(self, "retryInput"))

    @builtins.property
    @jsii.member(jsii_name="sensitiveBodyInput")
    def sensitive_body_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], jsii.get(self, "sensitiveBodyInput"))

    @builtins.property
    @jsii.member(jsii_name="sensitiveBodyVersionInput")
    def sensitive_body_version_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], jsii.get(self, "sensitiveBodyVersionInput"))

    @builtins.property
    @jsii.member(jsii_name="timeoutsInput")
    def timeouts_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "UpdateResourceTimeouts"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "UpdateResourceTimeouts"]], jsii.get(self, "timeoutsInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="updateHeadersInput")
    def update_headers_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], jsii.get(self, "updateHeadersInput"))

    @builtins.property
    @jsii.member(jsii_name="updateQueryParametersInput")
    def update_query_parameters_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]], jsii.get(self, "updateQueryParametersInput"))

    @builtins.property
    @jsii.member(jsii_name="body")
    def body(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.get(self, "body"))

    @body.setter
    def body(self, value: typing.Mapping[builtins.str, typing.Any]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__24bd794bbb1c46f8402e96bc858c8b28a4df0590b2d7ec745bbffb768c3d3470)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "body", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="ignoreCasing")
    def ignore_casing(self) -> typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable], jsii.get(self, "ignoreCasing"))

    @ignore_casing.setter
    def ignore_casing(
        self,
        value: typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4cb8639f9a6c82b24ae25e590163132a7c1792f25db19e5af27ec1b7260c0c2a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ignoreCasing", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="ignoreMissingProperty")
    def ignore_missing_property(
        self,
    ) -> typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable], jsii.get(self, "ignoreMissingProperty"))

    @ignore_missing_property.setter
    def ignore_missing_property(
        self,
        value: typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c927810abfe7b4a93a2fbe970cda9edc52458cfc55d325dd0bef1eb10166d266)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ignoreMissingProperty", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="locks")
    def locks(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "locks"))

    @locks.setter
    def locks(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c66cc57c5c940069dfa83f81f2b057d8eeb97eb23f6e8f5e612a20d1ca2bfbe0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "locks", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e5509c8c583dfd37eb7060c7ea283c0d48a6db05c143e44b8d74f03a717ab06c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="parentId")
    def parent_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "parentId"))

    @parent_id.setter
    def parent_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0ee27014ec34d7df609c5d4d737f963f47a932978b48529be68eeaf583b3b30d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "parentId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="readHeaders")
    def read_headers(self) -> typing.Mapping[builtins.str, builtins.str]:
        return typing.cast(typing.Mapping[builtins.str, builtins.str], jsii.get(self, "readHeaders"))

    @read_headers.setter
    def read_headers(self, value: typing.Mapping[builtins.str, builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2f5f4a4fbb1be9992450563aa07816a421096eead03aff37e8c856bd42467c48)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "readHeaders", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="readQueryParameters")
    def read_query_parameters(
        self,
    ) -> typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]:
        return typing.cast(typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]], jsii.get(self, "readQueryParameters"))

    @read_query_parameters.setter
    def read_query_parameters(
        self,
        value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8382baf5d98d087a6f342e3de120650f84a781f601d9d3e0c0a8e9436658ccb1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "readQueryParameters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceId")
    def resource_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "resourceId"))

    @resource_id.setter
    def resource_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__724528297e435ecd5d272c296a481cf0035199c8fa6e59f6e8d50de64b1be84d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="responseExportValues")
    def response_export_values(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.get(self, "responseExportValues"))

    @response_export_values.setter
    def response_export_values(
        self,
        value: typing.Mapping[builtins.str, typing.Any],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bc2704da0c80b3eff015e9306a550af5fb677bdca419c256e384ef41c206f576)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "responseExportValues", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="sensitiveBody")
    def sensitive_body(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.get(self, "sensitiveBody"))

    @sensitive_body.setter
    def sensitive_body(self, value: typing.Mapping[builtins.str, typing.Any]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4a601f943176f52cfd86bece65a02257c652ca356e0a5d03633156ccf00c8ca1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "sensitiveBody", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="sensitiveBodyVersion")
    def sensitive_body_version(self) -> typing.Mapping[builtins.str, builtins.str]:
        return typing.cast(typing.Mapping[builtins.str, builtins.str], jsii.get(self, "sensitiveBodyVersion"))

    @sensitive_body_version.setter
    def sensitive_body_version(
        self,
        value: typing.Mapping[builtins.str, builtins.str],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d1e5a9bd6f57eefda1dc9ffe8f8e3220c35d087ac5d6fc3a2a7fd0fb1e01b432)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "sensitiveBodyVersion", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6faff092d7698d576ca2125b85d264d346e87923aa86938a05cc59b365f562bc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="updateHeaders")
    def update_headers(self) -> typing.Mapping[builtins.str, builtins.str]:
        return typing.cast(typing.Mapping[builtins.str, builtins.str], jsii.get(self, "updateHeaders"))

    @update_headers.setter
    def update_headers(self, value: typing.Mapping[builtins.str, builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1df2ecf47fdda34769a609afd2ff064f7dba437a340acaa5c572ac5ee66ae164)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "updateHeaders", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="updateQueryParameters")
    def update_query_parameters(
        self,
    ) -> typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]:
        return typing.cast(typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]], jsii.get(self, "updateQueryParameters"))

    @update_query_parameters.setter
    def update_query_parameters(
        self,
        value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__997323a4824c206e270959d8c13005833d29789e2c841658d98259d3e2ee0fe0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "updateQueryParameters", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.UpdateResourceConfig",
    jsii_struct_bases=[_cdktf_9a9027ec.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "type": "type",
        "body": "body",
        "ignore_casing": "ignoreCasing",
        "ignore_missing_property": "ignoreMissingProperty",
        "locks": "locks",
        "name": "name",
        "parent_id": "parentId",
        "read_headers": "readHeaders",
        "read_query_parameters": "readQueryParameters",
        "resource_id": "resourceId",
        "response_export_values": "responseExportValues",
        "retry": "retry",
        "sensitive_body": "sensitiveBody",
        "sensitive_body_version": "sensitiveBodyVersion",
        "timeouts": "timeouts",
        "update_headers": "updateHeaders",
        "update_query_parameters": "updateQueryParameters",
    },
)
class UpdateResourceConfig(_cdktf_9a9027ec.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        type: builtins.str,
        body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        ignore_casing: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
        ignore_missing_property: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
        locks: typing.Optional[typing.Sequence[builtins.str]] = None,
        name: typing.Optional[builtins.str] = None,
        parent_id: typing.Optional[builtins.str] = None,
        read_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        read_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
        resource_id: typing.Optional[builtins.str] = None,
        response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        retry: typing.Optional[typing.Union["UpdateResourceRetry", typing.Dict[builtins.str, typing.Any]]] = None,
        sensitive_body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
        sensitive_body_version: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        timeouts: typing.Optional[typing.Union["UpdateResourceTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        update_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        update_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param type: In a format like ``<resource-type>@<api-version>``. ``<resource-type>`` is the Azure resource type, for example, ``Microsoft.Storage/storageAccounts``. ``<api-version>`` is version of the API used to manage this azure resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#type UpdateResource#type}
        :param body: A dynamic attribute that contains the request body. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#body UpdateResource#body}
        :param ignore_casing: Whether ignore the casing of the property names in the response body. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#ignore_casing UpdateResource#ignore_casing}
        :param ignore_missing_property: Whether ignore not returned properties like credentials in ``body`` to suppress plan-diff. Defaults to ``true``. It's recommend to enable this option when some sensitive properties are not returned in response body, instead of setting them in ``lifecycle.ignore_changes`` because it will make the sensitive fields unable to update. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#ignore_missing_property UpdateResource#ignore_missing_property}
        :param locks: A list of ARM resource IDs which are used to avoid create/modify/delete azapi resources at the same time. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#locks UpdateResource#locks}
        :param name: Specifies the name of the Azure resource. Changing this forces a new resource to be created. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#name UpdateResource#name}
        :param parent_id: The ID of the azure resource in which this resource is created. It supports different kinds of deployment scope for **top level** resources: - resource group scope: ``parent_id`` should be the ID of a resource group, it's recommended to manage a resource group by azurerm_resource_group. - management group scope: ``parent_id`` should be the ID of a management group, it's recommended to manage a management group by azurerm_management_group. - extension scope: ``parent_id`` should be the ID of the resource you're adding the extension to. - subscription scope: ``parent_id`` should be like \\x60/subscriptions/00000000-0000-0000-0000-000000000000\\x60 - tenant scope: ``parent_id`` should be / For child level resources, the ``parent_id`` should be the ID of its parent resource, for example, subnet resource's ``parent_id`` is the ID of the vnet. For type ``Microsoft.Resources/resourceGroups``, the ``parent_id`` could be omitted, it defaults to subscription ID specified in provider or the default subscription (You could check the default subscription by azure cli command: ``az account show``). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#parent_id UpdateResource#parent_id}
        :param read_headers: A mapping of headers to be sent with the read request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#read_headers UpdateResource#read_headers}
        :param read_query_parameters: A mapping of query parameters to be sent with the read request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#read_query_parameters UpdateResource#read_query_parameters}
        :param resource_id: The ID of an existing Azure source. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#resource_id UpdateResource#resource_id}
        :param response_export_values: The attribute can accept either a list or a map. - **List**: A list of paths that need to be exported from the response body. Setting it to ``["*"]`` will export the full response body. Here's an example. If it sets to ``["properties.loginServer", "properties.policies.quarantinePolicy.status"]``, it will set the following HCL object to the computed property output. Example:: { properties = { loginServer = "registry1.azurecr.io" policies = { quarantinePolicy = { status = "disabled" } } } } - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to ``{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}``, it will set the following HCL object to the computed property output. Example:: { "login_server" = "registry1.azurecr.io" "quarantine_status" = "disabled" } To learn more about JMESPath, visit `JMESPath <https://jmespath.org/>`_. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#response_export_values UpdateResource#response_export_values}
        :param retry: The retry object supports the following attributes:. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#retry UpdateResource#retry}
        :param sensitive_body: A dynamic attribute that contains the write-only properties of the request body. This will be merge-patched to the body to construct the actual request body. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#sensitive_body UpdateResource#sensitive_body}
        :param sensitive_body_version: A map where the key is the path to the property in ``sensitive_body`` and the value is the version of the property. The key is a string in the format of ``path.to.property[index].subproperty``, where ``index`` is the index of the item in an array. When the version is changed, the property will be included in the request body, otherwise it will be omitted from the request body. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#sensitive_body_version UpdateResource#sensitive_body_version}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#timeouts UpdateResource#timeouts}
        :param update_headers: A mapping of headers to be sent with the update request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#update_headers UpdateResource#update_headers}
        :param update_query_parameters: A mapping of query parameters to be sent with the update request. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#update_query_parameters UpdateResource#update_query_parameters}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktf_9a9027ec.TerraformResourceLifecycle(**lifecycle)
        if isinstance(retry, dict):
            retry = UpdateResourceRetry(**retry)
        if isinstance(timeouts, dict):
            timeouts = UpdateResourceTimeouts(**timeouts)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7b47a964a364d29e6295c7e65c99c8a54cd1962f0bd798c23d32ee91f00e4a13)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            check_type(argname="argument body", value=body, expected_type=type_hints["body"])
            check_type(argname="argument ignore_casing", value=ignore_casing, expected_type=type_hints["ignore_casing"])
            check_type(argname="argument ignore_missing_property", value=ignore_missing_property, expected_type=type_hints["ignore_missing_property"])
            check_type(argname="argument locks", value=locks, expected_type=type_hints["locks"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument parent_id", value=parent_id, expected_type=type_hints["parent_id"])
            check_type(argname="argument read_headers", value=read_headers, expected_type=type_hints["read_headers"])
            check_type(argname="argument read_query_parameters", value=read_query_parameters, expected_type=type_hints["read_query_parameters"])
            check_type(argname="argument resource_id", value=resource_id, expected_type=type_hints["resource_id"])
            check_type(argname="argument response_export_values", value=response_export_values, expected_type=type_hints["response_export_values"])
            check_type(argname="argument retry", value=retry, expected_type=type_hints["retry"])
            check_type(argname="argument sensitive_body", value=sensitive_body, expected_type=type_hints["sensitive_body"])
            check_type(argname="argument sensitive_body_version", value=sensitive_body_version, expected_type=type_hints["sensitive_body_version"])
            check_type(argname="argument timeouts", value=timeouts, expected_type=type_hints["timeouts"])
            check_type(argname="argument update_headers", value=update_headers, expected_type=type_hints["update_headers"])
            check_type(argname="argument update_query_parameters", value=update_query_parameters, expected_type=type_hints["update_query_parameters"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "type": type,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if body is not None:
            self._values["body"] = body
        if ignore_casing is not None:
            self._values["ignore_casing"] = ignore_casing
        if ignore_missing_property is not None:
            self._values["ignore_missing_property"] = ignore_missing_property
        if locks is not None:
            self._values["locks"] = locks
        if name is not None:
            self._values["name"] = name
        if parent_id is not None:
            self._values["parent_id"] = parent_id
        if read_headers is not None:
            self._values["read_headers"] = read_headers
        if read_query_parameters is not None:
            self._values["read_query_parameters"] = read_query_parameters
        if resource_id is not None:
            self._values["resource_id"] = resource_id
        if response_export_values is not None:
            self._values["response_export_values"] = response_export_values
        if retry is not None:
            self._values["retry"] = retry
        if sensitive_body is not None:
            self._values["sensitive_body"] = sensitive_body
        if sensitive_body_version is not None:
            self._values["sensitive_body_version"] = sensitive_body_version
        if timeouts is not None:
            self._values["timeouts"] = timeouts
        if update_headers is not None:
            self._values["update_headers"] = update_headers
        if update_query_parameters is not None:
            self._values["update_query_parameters"] = update_query_parameters

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, _cdktf_9a9027ec.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, _cdktf_9a9027ec.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktf_9a9027ec.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktf_9a9027ec.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktf_9a9027ec.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktf_9a9027ec.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktf_9a9027ec.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktf_9a9027ec.FileProvisioner, _cdktf_9a9027ec.LocalExecProvisioner, _cdktf_9a9027ec.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktf_9a9027ec.FileProvisioner, _cdktf_9a9027ec.LocalExecProvisioner, _cdktf_9a9027ec.RemoteExecProvisioner]]], result)

    @builtins.property
    def type(self) -> builtins.str:
        '''In a format like ``<resource-type>@<api-version>``.

        ``<resource-type>`` is the Azure resource type, for example, ``Microsoft.Storage/storageAccounts``. ``<api-version>`` is version of the API used to manage this azure resource.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#type UpdateResource#type}
        '''
        result = self._values.get("type")
        assert result is not None, "Required property 'type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def body(self) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        '''A dynamic attribute that contains the request body.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#body UpdateResource#body}
        '''
        result = self._values.get("body")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], result)

    @builtins.property
    def ignore_casing(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]]:
        '''Whether ignore the casing of the property names in the response body. Defaults to ``false``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#ignore_casing UpdateResource#ignore_casing}
        '''
        result = self._values.get("ignore_casing")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]], result)

    @builtins.property
    def ignore_missing_property(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]]:
        '''Whether ignore not returned properties like credentials in ``body`` to suppress plan-diff.

        Defaults to ``true``. It's recommend to enable this option when some sensitive properties are not returned in response body, instead of setting them in ``lifecycle.ignore_changes`` because it will make the sensitive fields unable to update.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#ignore_missing_property UpdateResource#ignore_missing_property}
        '''
        result = self._values.get("ignore_missing_property")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]], result)

    @builtins.property
    def locks(self) -> typing.Optional[typing.List[builtins.str]]:
        '''A list of ARM resource IDs which are used to avoid create/modify/delete azapi resources at the same time.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#locks UpdateResource#locks}
        '''
        result = self._values.get("locks")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''Specifies the name of the Azure resource. Changing this forces a new resource to be created.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#name UpdateResource#name}
        '''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def parent_id(self) -> typing.Optional[builtins.str]:
        '''The ID of the azure resource in which this resource is created.

        It supports different kinds of deployment scope for **top level** resources:

        - resource group scope: ``parent_id`` should be the ID of a resource group, it's recommended to manage a resource group by azurerm_resource_group.
        - management group scope: ``parent_id`` should be the ID of a management group, it's recommended to manage a management group by azurerm_management_group.
        - extension scope: ``parent_id`` should be the ID of the resource you're adding the extension to.
        - subscription scope: ``parent_id`` should be like \\x60/subscriptions/00000000-0000-0000-0000-000000000000\\x60
        - tenant scope: ``parent_id`` should be /

        For child level resources, the ``parent_id`` should be the ID of its parent resource, for example, subnet resource's ``parent_id`` is the ID of the vnet.

        For type ``Microsoft.Resources/resourceGroups``, the ``parent_id`` could be omitted, it defaults to subscription ID specified in provider or the default subscription (You could check the default subscription by azure cli command: ``az account show``).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#parent_id UpdateResource#parent_id}
        '''
        result = self._values.get("parent_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def read_headers(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''A mapping of headers to be sent with the read request.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#read_headers UpdateResource#read_headers}
        '''
        result = self._values.get("read_headers")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def read_query_parameters(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]]:
        '''A mapping of query parameters to be sent with the read request.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#read_query_parameters UpdateResource#read_query_parameters}
        '''
        result = self._values.get("read_query_parameters")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]], result)

    @builtins.property
    def resource_id(self) -> typing.Optional[builtins.str]:
        '''The ID of an existing Azure source.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#resource_id UpdateResource#resource_id}
        '''
        result = self._values.get("resource_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def response_export_values(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        '''The attribute can accept either a list or a map.

        - **List**: A list of paths that need to be exported from the response body. Setting it to ``["*"]`` will export the full response body. Here's an example. If it sets to ``["properties.loginServer", "properties.policies.quarantinePolicy.status"]``, it will set the following HCL object to the computed property output.

        Example::

           {
           properties = {
           loginServer = "registry1.azurecr.io"
           policies = {
           quarantinePolicy = {
           	status = "disabled"
           }
           }
           }
           }

        - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to ``{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}``, it will set the following HCL object to the computed property output.

        Example::

           {
           "login_server" = "registry1.azurecr.io"
           "quarantine_status" = "disabled"
           }

        To learn more about JMESPath, visit `JMESPath <https://jmespath.org/>`_.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#response_export_values UpdateResource#response_export_values}
        '''
        result = self._values.get("response_export_values")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], result)

    @builtins.property
    def retry(self) -> typing.Optional["UpdateResourceRetry"]:
        '''The retry object supports the following attributes:.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#retry UpdateResource#retry}
        '''
        result = self._values.get("retry")
        return typing.cast(typing.Optional["UpdateResourceRetry"], result)

    @builtins.property
    def sensitive_body(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        '''A dynamic attribute that contains the write-only properties of the request body.

        This will be merge-patched to the body to construct the actual request body.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#sensitive_body UpdateResource#sensitive_body}
        '''
        result = self._values.get("sensitive_body")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], result)

    @builtins.property
    def sensitive_body_version(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''A map where the key is the path to the property in ``sensitive_body`` and the value is the version of the property.

        The key is a string in the format of ``path.to.property[index].subproperty``, where ``index`` is the index of the item in an array. When the version is changed, the property will be included in the request body, otherwise it will be omitted from the request body.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#sensitive_body_version UpdateResource#sensitive_body_version}
        '''
        result = self._values.get("sensitive_body_version")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def timeouts(self) -> typing.Optional["UpdateResourceTimeouts"]:
        '''timeouts block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#timeouts UpdateResource#timeouts}
        '''
        result = self._values.get("timeouts")
        return typing.cast(typing.Optional["UpdateResourceTimeouts"], result)

    @builtins.property
    def update_headers(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''A mapping of headers to be sent with the update request.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#update_headers UpdateResource#update_headers}
        '''
        result = self._values.get("update_headers")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def update_query_parameters(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]]:
        '''A mapping of query parameters to be sent with the update request.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#update_query_parameters UpdateResource#update_query_parameters}
        '''
        result = self._values.get("update_query_parameters")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "UpdateResourceConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.UpdateResourceRetry",
    jsii_struct_bases=[],
    name_mapping={
        "error_message_regex": "errorMessageRegex",
        "interval_seconds": "intervalSeconds",
        "max_interval_seconds": "maxIntervalSeconds",
        "multiplier": "multiplier",
        "randomization_factor": "randomizationFactor",
    },
)
class UpdateResourceRetry:
    def __init__(
        self,
        *,
        error_message_regex: typing.Sequence[builtins.str],
        interval_seconds: typing.Optional[jsii.Number] = None,
        max_interval_seconds: typing.Optional[jsii.Number] = None,
        multiplier: typing.Optional[jsii.Number] = None,
        randomization_factor: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param error_message_regex: A list of regular expressions to match against error messages. If any of the regular expressions match, the request will be retried. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#error_message_regex UpdateResource#error_message_regex}
        :param interval_seconds: The base number of seconds to wait between retries. Default is ``10``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#interval_seconds UpdateResource#interval_seconds}
        :param max_interval_seconds: The maximum number of seconds to wait between retries. Default is ``180``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#max_interval_seconds UpdateResource#max_interval_seconds}
        :param multiplier: The multiplier to apply to the interval between retries. Default is ``1.5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#multiplier UpdateResource#multiplier}
        :param randomization_factor: The randomization factor to apply to the interval between retries. The formula for the randomized interval is: ``RetryInterval * (random value in range [1 - RandomizationFactor, 1 + RandomizationFactor])``. Therefore set to zero ``0.0`` for no randomization. Default is ``0.5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#randomization_factor UpdateResource#randomization_factor}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__87d45f83b2ad1d82c585e1dba7904d689304a9d3f8e8b83aaafd685ddc575771)
            check_type(argname="argument error_message_regex", value=error_message_regex, expected_type=type_hints["error_message_regex"])
            check_type(argname="argument interval_seconds", value=interval_seconds, expected_type=type_hints["interval_seconds"])
            check_type(argname="argument max_interval_seconds", value=max_interval_seconds, expected_type=type_hints["max_interval_seconds"])
            check_type(argname="argument multiplier", value=multiplier, expected_type=type_hints["multiplier"])
            check_type(argname="argument randomization_factor", value=randomization_factor, expected_type=type_hints["randomization_factor"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "error_message_regex": error_message_regex,
        }
        if interval_seconds is not None:
            self._values["interval_seconds"] = interval_seconds
        if max_interval_seconds is not None:
            self._values["max_interval_seconds"] = max_interval_seconds
        if multiplier is not None:
            self._values["multiplier"] = multiplier
        if randomization_factor is not None:
            self._values["randomization_factor"] = randomization_factor

    @builtins.property
    def error_message_regex(self) -> typing.List[builtins.str]:
        '''A list of regular expressions to match against error messages.

        If any of the regular expressions match, the request will be retried.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#error_message_regex UpdateResource#error_message_regex}
        '''
        result = self._values.get("error_message_regex")
        assert result is not None, "Required property 'error_message_regex' is missing"
        return typing.cast(typing.List[builtins.str], result)

    @builtins.property
    def interval_seconds(self) -> typing.Optional[jsii.Number]:
        '''The base number of seconds to wait between retries. Default is ``10``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#interval_seconds UpdateResource#interval_seconds}
        '''
        result = self._values.get("interval_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def max_interval_seconds(self) -> typing.Optional[jsii.Number]:
        '''The maximum number of seconds to wait between retries. Default is ``180``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#max_interval_seconds UpdateResource#max_interval_seconds}
        '''
        result = self._values.get("max_interval_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def multiplier(self) -> typing.Optional[jsii.Number]:
        '''The multiplier to apply to the interval between retries. Default is ``1.5``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#multiplier UpdateResource#multiplier}
        '''
        result = self._values.get("multiplier")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def randomization_factor(self) -> typing.Optional[jsii.Number]:
        '''The randomization factor to apply to the interval between retries.

        The formula for the randomized interval is: ``RetryInterval * (random value in range [1 - RandomizationFactor, 1 + RandomizationFactor])``. Therefore set to zero ``0.0`` for no randomization. Default is ``0.5``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#randomization_factor UpdateResource#randomization_factor}
        '''
        result = self._values.get("randomization_factor")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "UpdateResourceRetry(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class UpdateResourceRetryOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.UpdateResourceRetryOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c41206770fa357fa9709c92d018356f71b2e869135d9fe2861d8157847223556)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetIntervalSeconds")
    def reset_interval_seconds(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIntervalSeconds", []))

    @jsii.member(jsii_name="resetMaxIntervalSeconds")
    def reset_max_interval_seconds(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMaxIntervalSeconds", []))

    @jsii.member(jsii_name="resetMultiplier")
    def reset_multiplier(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMultiplier", []))

    @jsii.member(jsii_name="resetRandomizationFactor")
    def reset_randomization_factor(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRandomizationFactor", []))

    @builtins.property
    @jsii.member(jsii_name="errorMessageRegexInput")
    def error_message_regex_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "errorMessageRegexInput"))

    @builtins.property
    @jsii.member(jsii_name="intervalSecondsInput")
    def interval_seconds_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "intervalSecondsInput"))

    @builtins.property
    @jsii.member(jsii_name="maxIntervalSecondsInput")
    def max_interval_seconds_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "maxIntervalSecondsInput"))

    @builtins.property
    @jsii.member(jsii_name="multiplierInput")
    def multiplier_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "multiplierInput"))

    @builtins.property
    @jsii.member(jsii_name="randomizationFactorInput")
    def randomization_factor_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "randomizationFactorInput"))

    @builtins.property
    @jsii.member(jsii_name="errorMessageRegex")
    def error_message_regex(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "errorMessageRegex"))

    @error_message_regex.setter
    def error_message_regex(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__da62c45d5fbf12579507780b8c2183bd172b80225c48b831e041bd16e9303cb2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "errorMessageRegex", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="intervalSeconds")
    def interval_seconds(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "intervalSeconds"))

    @interval_seconds.setter
    def interval_seconds(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__edb395a935210b210773fbc5a92da77cafde2ae6c7bca0e8af9442c17428f48e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "intervalSeconds", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="maxIntervalSeconds")
    def max_interval_seconds(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "maxIntervalSeconds"))

    @max_interval_seconds.setter
    def max_interval_seconds(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f47cf8c7b3f381923d0a2daadd5b1874533029c21befa0ec4128fcb287e1fca1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "maxIntervalSeconds", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="multiplier")
    def multiplier(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "multiplier"))

    @multiplier.setter
    def multiplier(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dc6aeca07ac69489c9dfeac49dd53309a5fe591b3332385ff32f64d17c8296dc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "multiplier", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="randomizationFactor")
    def randomization_factor(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "randomizationFactor"))

    @randomization_factor.setter
    def randomization_factor(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0e34b85505a5ed45c25bc4b00f058a7820d2104f28f306ab039fcd3e9b1c1131)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "randomizationFactor", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, UpdateResourceRetry]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, UpdateResourceRetry]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, UpdateResourceRetry]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a1858a84871a0495501923f0e43383c66682ba256e531363d48c31ef7505b6aa)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.UpdateResourceTimeouts",
    jsii_struct_bases=[],
    name_mapping={
        "create": "create",
        "delete": "delete",
        "read": "read",
        "update": "update",
    },
)
class UpdateResourceTimeouts:
    def __init__(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#create UpdateResource#create}
        :param delete: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#delete UpdateResource#delete}
        :param read: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#read UpdateResource#read}
        :param update: A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#update UpdateResource#update}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7beb3d1c9cf97f822976fb8d91dde2779b79c5b2568e7e5917e16c666376c6c7)
            check_type(argname="argument create", value=create, expected_type=type_hints["create"])
            check_type(argname="argument delete", value=delete, expected_type=type_hints["delete"])
            check_type(argname="argument read", value=read, expected_type=type_hints["read"])
            check_type(argname="argument update", value=update, expected_type=type_hints["update"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if create is not None:
            self._values["create"] = create
        if delete is not None:
            self._values["delete"] = delete
        if read is not None:
            self._values["read"] = read
        if update is not None:
            self._values["update"] = update

    @builtins.property
    def create(self) -> typing.Optional[builtins.str]:
        '''A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#create UpdateResource#create}
        '''
        result = self._values.get("create")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def delete(self) -> typing.Optional[builtins.str]:
        '''A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#delete UpdateResource#delete}
        '''
        result = self._values.get("delete")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def read(self) -> typing.Optional[builtins.str]:
        '''A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#read UpdateResource#read}
        '''
        result = self._values.get("read")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def update(self) -> typing.Optional[builtins.str]:
        '''A string that can be `parsed as a duration <https://pkg.go.dev/time#ParseDuration>`_ consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.7.0/docs/resources/update_resource#update UpdateResource#update}
        '''
        result = self._values.get("update")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "UpdateResourceTimeouts(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class UpdateResourceTimeoutsOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.UpdateResourceTimeoutsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4cdb2be43cdb81266407e287f64c0f7ead06e2cc7b0af479133afe8a3f8e5441)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetCreate")
    def reset_create(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCreate", []))

    @jsii.member(jsii_name="resetDelete")
    def reset_delete(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDelete", []))

    @jsii.member(jsii_name="resetRead")
    def reset_read(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRead", []))

    @jsii.member(jsii_name="resetUpdate")
    def reset_update(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUpdate", []))

    @builtins.property
    @jsii.member(jsii_name="createInput")
    def create_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "createInput"))

    @builtins.property
    @jsii.member(jsii_name="deleteInput")
    def delete_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "deleteInput"))

    @builtins.property
    @jsii.member(jsii_name="readInput")
    def read_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "readInput"))

    @builtins.property
    @jsii.member(jsii_name="updateInput")
    def update_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "updateInput"))

    @builtins.property
    @jsii.member(jsii_name="create")
    def create(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "create"))

    @create.setter
    def create(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2ea0c0435ad4f0bbc6334e33680c82d307017baf1d3faa288e184f9b6012b7cb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "create", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="delete")
    def delete(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "delete"))

    @delete.setter
    def delete(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__97fa4065ed423e575c7441b8d3cd5824905feeaf4af1151d6c8335a357aa6572)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "delete", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="read")
    def read(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "read"))

    @read.setter
    def read(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__62808aa669eed1a514c445c8d9b9dcdc6910194f865509913e8cfc403a1071ed)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "read", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="update")
    def update(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "update"))

    @update.setter
    def update(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__500c9941017ee642f6d6664026835932d4644c05cfe9f19f28f00529e6bf3f8b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "update", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, UpdateResourceTimeouts]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, UpdateResourceTimeouts]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, UpdateResourceTimeouts]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2ce912d4ee4c6f42dd550125ccdf206b15eb5503da49fd7c4e1709b5283de27a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.ValidationResult",
    jsii_struct_bases=[],
    name_mapping={
        "errors": "errors",
        "valid": "valid",
        "warnings": "warnings",
        "property_errors": "propertyErrors",
    },
)
class ValidationResult:
    def __init__(
        self,
        *,
        errors: typing.Sequence[builtins.str],
        valid: builtins.bool,
        warnings: typing.Sequence[builtins.str],
        property_errors: typing.Optional[typing.Mapping[builtins.str, typing.Sequence[builtins.str]]] = None,
    ) -> None:
        '''Validation result interface.

        Results of validating properties against a schema.
        Provides detailed error and warning information for debugging
        and user feedback.

        :param errors: Array of validation error messages Empty if validation passed.
        :param valid: Whether validation passed If false, the errors array will contain details.
        :param warnings: Array of validation warning messages Non-blocking issues that should be addressed.
        :param property_errors: Property-specific error messages Maps property names to arrays of error messages.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e65d20f8430765c4156f0a11302091f5baf85b0f70db34bdcaf4ed8dc8365404)
            check_type(argname="argument errors", value=errors, expected_type=type_hints["errors"])
            check_type(argname="argument valid", value=valid, expected_type=type_hints["valid"])
            check_type(argname="argument warnings", value=warnings, expected_type=type_hints["warnings"])
            check_type(argname="argument property_errors", value=property_errors, expected_type=type_hints["property_errors"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "errors": errors,
            "valid": valid,
            "warnings": warnings,
        }
        if property_errors is not None:
            self._values["property_errors"] = property_errors

    @builtins.property
    def errors(self) -> typing.List[builtins.str]:
        '''Array of validation error messages Empty if validation passed.'''
        result = self._values.get("errors")
        assert result is not None, "Required property 'errors' is missing"
        return typing.cast(typing.List[builtins.str], result)

    @builtins.property
    def valid(self) -> builtins.bool:
        '''Whether validation passed If false, the errors array will contain details.'''
        result = self._values.get("valid")
        assert result is not None, "Required property 'valid' is missing"
        return typing.cast(builtins.bool, result)

    @builtins.property
    def warnings(self) -> typing.List[builtins.str]:
        '''Array of validation warning messages Non-blocking issues that should be addressed.'''
        result = self._values.get("warnings")
        assert result is not None, "Required property 'warnings' is missing"
        return typing.cast(typing.List[builtins.str], result)

    @builtins.property
    def property_errors(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.List[builtins.str]]]:
        '''Property-specific error messages Maps property names to arrays of error messages.'''
        result = self._values.get("property_errors")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.List[builtins.str]]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ValidationResult(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.ValidationRule",
    jsii_struct_bases=[],
    name_mapping={"rule_type": "ruleType", "message": "message", "value": "value"},
)
class ValidationRule:
    def __init__(
        self,
        *,
        rule_type: builtins.str,
        message: typing.Optional[builtins.str] = None,
        value: typing.Any = None,
    ) -> None:
        '''Validation rule definition for property validation.

        Defines a single validation rule that can be applied to a property
        to ensure data integrity and provide user feedback.

        :param rule_type: The type of validation rule to apply Must be one of the ValidationRuleType constants.
        :param message: Custom error message to display when validation fails If not provided, a default message will be generated.
        :param value: The value or parameter for the validation rule Type depends on the validation rule type.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__74fd92c71ed2c1615886631f31c8b508b206e72f93a2b7fd1c30a52a199f0892)
            check_type(argname="argument rule_type", value=rule_type, expected_type=type_hints["rule_type"])
            check_type(argname="argument message", value=message, expected_type=type_hints["message"])
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "rule_type": rule_type,
        }
        if message is not None:
            self._values["message"] = message
        if value is not None:
            self._values["value"] = value

    @builtins.property
    def rule_type(self) -> builtins.str:
        '''The type of validation rule to apply Must be one of the ValidationRuleType constants.'''
        result = self._values.get("rule_type")
        assert result is not None, "Required property 'rule_type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def message(self) -> typing.Optional[builtins.str]:
        '''Custom error message to display when validation fails If not provided, a default message will be generated.'''
        result = self._values.get("message")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def value(self) -> typing.Any:
        '''The value or parameter for the validation rule Type depends on the validation rule type.

        Example::

            For VALUE_RANGE: { min: 0, max: 100 }
        '''
        result = self._values.get("value")
        return typing.cast(typing.Any, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ValidationRule(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ValidationRuleType(
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.ValidationRuleType",
):
    '''Validation rule types for property validation.

    Defines the types of validation rules that can be applied to properties
    for input validation and data integrity.
    '''

    def __init__(self) -> None:
        jsii.create(self.__class__, self, [])

    @jsii.python.classproperty
    @jsii.member(jsii_name="CUSTOM_VALIDATION")
    def CUSTOM_VALIDATION(cls) -> builtins.str:
        '''Custom validation function.'''
        return typing.cast(builtins.str, jsii.sget(cls, "CUSTOM_VALIDATION"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="PATTERN_MATCH")
    def PATTERN_MATCH(cls) -> builtins.str:
        '''Validate property value matches regex pattern.'''
        return typing.cast(builtins.str, jsii.sget(cls, "PATTERN_MATCH"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="REQUIRED")
    def REQUIRED(cls) -> builtins.str:
        '''Property is required and cannot be undefined.'''
        return typing.cast(builtins.str, jsii.sget(cls, "REQUIRED"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="TYPE_CHECK")
    def TYPE_CHECK(cls) -> builtins.str:
        '''Validate property type matches expected type.'''
        return typing.cast(builtins.str, jsii.sget(cls, "TYPE_CHECK"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="VALUE_RANGE")
    def VALUE_RANGE(cls) -> builtins.str:
        '''Validate property value is within specified range.'''
        return typing.cast(builtins.str, jsii.sget(cls, "VALUE_RANGE"))


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.VersionChangeLog",
    jsii_struct_bases=[],
    name_mapping={
        "change_type": "changeType",
        "description": "description",
        "affected_property": "affectedProperty",
        "breaking": "breaking",
    },
)
class VersionChangeLog:
    def __init__(
        self,
        *,
        change_type: builtins.str,
        description: builtins.str,
        affected_property: typing.Optional[builtins.str] = None,
        breaking: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''Version changelog entry.

        Documents changes made in a specific version for transparency
        and to help developers understand version evolution.

        :param change_type: The type of change (added, changed, deprecated, removed, fixed).
        :param description: Brief description of the change.
        :param affected_property: Property or feature affected by the change.
        :param breaking: Whether this change is breaking. Default: false
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b56a9bd32e04dbce9a4e8ec5d6350fb902c7dd6cdab1c292b8f0a593c3227531)
            check_type(argname="argument change_type", value=change_type, expected_type=type_hints["change_type"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument affected_property", value=affected_property, expected_type=type_hints["affected_property"])
            check_type(argname="argument breaking", value=breaking, expected_type=type_hints["breaking"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "change_type": change_type,
            "description": description,
        }
        if affected_property is not None:
            self._values["affected_property"] = affected_property
        if breaking is not None:
            self._values["breaking"] = breaking

    @builtins.property
    def change_type(self) -> builtins.str:
        '''The type of change (added, changed, deprecated, removed, fixed).'''
        result = self._values.get("change_type")
        assert result is not None, "Required property 'change_type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def description(self) -> builtins.str:
        '''Brief description of the change.'''
        result = self._values.get("description")
        assert result is not None, "Required property 'description' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def affected_property(self) -> typing.Optional[builtins.str]:
        '''Property or feature affected by the change.'''
        result = self._values.get("affected_property")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def breaking(self) -> typing.Optional[builtins.bool]:
        '''Whether this change is breaking.

        :default: false
        '''
        result = self._values.get("breaking")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "VersionChangeLog(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.VersionConfig",
    jsii_struct_bases=[],
    name_mapping={
        "release_date": "releaseDate",
        "schema": "schema",
        "support_level": "supportLevel",
        "version": "version",
        "breaking_changes": "breakingChanges",
        "change_log": "changeLog",
        "deprecation_date": "deprecationDate",
        "migration_guide": "migrationGuide",
        "sunset_date": "sunsetDate",
    },
)
class VersionConfig:
    def __init__(
        self,
        *,
        release_date: builtins.str,
        schema: typing.Union[_ApiSchema_5ce0490e, typing.Dict[builtins.str, typing.Any]],
        support_level: builtins.str,
        version: builtins.str,
        breaking_changes: typing.Optional[typing.Sequence[typing.Union[_BreakingChange_5dc94c31, typing.Dict[builtins.str, typing.Any]]]] = None,
        change_log: typing.Optional[typing.Sequence[typing.Union[_VersionChangeLog_3bfd366b, typing.Dict[builtins.str, typing.Any]]]] = None,
        deprecation_date: typing.Optional[builtins.str] = None,
        migration_guide: typing.Optional[builtins.str] = None,
        sunset_date: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Version configuration interface.

        Complete configuration for an API version including schema, lifecycle
        information, and migration metadata. This is the primary interface
        for version management and automated tooling.

        :param release_date: Date when this version was released Used for lifecycle management and compatibility analysis.
        :param schema: The complete API schema for this version Defines all properties, validation, and transformation rules.
        :param support_level: Current support level for this version Must be one of the VersionSupportLevel constants.
        :param version: The API version string.
        :param breaking_changes: Array of breaking changes introduced in this version Used for migration analysis and automated tooling.
        :param change_log: Array of changes made in this version Provides transparency and helps with troubleshooting.
        :param deprecation_date: Date when this version was deprecated (if applicable) Indicates when migration planning should begin.
        :param migration_guide: URL or path to detailed migration guide Provides comprehensive migration instructions.
        :param sunset_date: Date when this version will be sunset (if known) Indicates deadline for migration completion.
        '''
        if isinstance(schema, dict):
            schema = _ApiSchema_5ce0490e(**schema)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__189788820aa0902240f9afa632bd5e213fdd9ff8bd2341f60745e78e53a0c91d)
            check_type(argname="argument release_date", value=release_date, expected_type=type_hints["release_date"])
            check_type(argname="argument schema", value=schema, expected_type=type_hints["schema"])
            check_type(argname="argument support_level", value=support_level, expected_type=type_hints["support_level"])
            check_type(argname="argument version", value=version, expected_type=type_hints["version"])
            check_type(argname="argument breaking_changes", value=breaking_changes, expected_type=type_hints["breaking_changes"])
            check_type(argname="argument change_log", value=change_log, expected_type=type_hints["change_log"])
            check_type(argname="argument deprecation_date", value=deprecation_date, expected_type=type_hints["deprecation_date"])
            check_type(argname="argument migration_guide", value=migration_guide, expected_type=type_hints["migration_guide"])
            check_type(argname="argument sunset_date", value=sunset_date, expected_type=type_hints["sunset_date"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "release_date": release_date,
            "schema": schema,
            "support_level": support_level,
            "version": version,
        }
        if breaking_changes is not None:
            self._values["breaking_changes"] = breaking_changes
        if change_log is not None:
            self._values["change_log"] = change_log
        if deprecation_date is not None:
            self._values["deprecation_date"] = deprecation_date
        if migration_guide is not None:
            self._values["migration_guide"] = migration_guide
        if sunset_date is not None:
            self._values["sunset_date"] = sunset_date

    @builtins.property
    def release_date(self) -> builtins.str:
        '''Date when this version was released Used for lifecycle management and compatibility analysis.

        Example::

            "2024-11-01"
        '''
        result = self._values.get("release_date")
        assert result is not None, "Required property 'release_date' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def schema(self) -> _ApiSchema_5ce0490e:
        '''The complete API schema for this version Defines all properties, validation, and transformation rules.'''
        result = self._values.get("schema")
        assert result is not None, "Required property 'schema' is missing"
        return typing.cast(_ApiSchema_5ce0490e, result)

    @builtins.property
    def support_level(self) -> builtins.str:
        '''Current support level for this version Must be one of the VersionSupportLevel constants.'''
        result = self._values.get("support_level")
        assert result is not None, "Required property 'support_level' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def version(self) -> builtins.str:
        '''The API version string.

        Example::

            "2024-11-01"
        '''
        result = self._values.get("version")
        assert result is not None, "Required property 'version' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def breaking_changes(
        self,
    ) -> typing.Optional[typing.List[_BreakingChange_5dc94c31]]:
        '''Array of breaking changes introduced in this version Used for migration analysis and automated tooling.'''
        result = self._values.get("breaking_changes")
        return typing.cast(typing.Optional[typing.List[_BreakingChange_5dc94c31]], result)

    @builtins.property
    def change_log(self) -> typing.Optional[typing.List[_VersionChangeLog_3bfd366b]]:
        '''Array of changes made in this version Provides transparency and helps with troubleshooting.'''
        result = self._values.get("change_log")
        return typing.cast(typing.Optional[typing.List[_VersionChangeLog_3bfd366b]], result)

    @builtins.property
    def deprecation_date(self) -> typing.Optional[builtins.str]:
        '''Date when this version was deprecated (if applicable) Indicates when migration planning should begin.

        Example::

            "2025-11-01"
        '''
        result = self._values.get("deprecation_date")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def migration_guide(self) -> typing.Optional[builtins.str]:
        '''URL or path to detailed migration guide Provides comprehensive migration instructions.

        Example::

            "/docs/migration-guides/v2024-11-01"
        '''
        result = self._values.get("migration_guide")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def sunset_date(self) -> typing.Optional[builtins.str]:
        '''Date when this version will be sunset (if known) Indicates deadline for migration completion.

        Example::

            "2026-11-01"
        '''
        result = self._values.get("sunset_date")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "VersionConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.VersionConstraints",
    jsii_struct_bases=[],
    name_mapping={
        "exclude_deprecated": "excludeDeprecated",
        "not_older_than": "notOlderThan",
        "required_features": "requiredFeatures",
        "support_level": "supportLevel",
    },
)
class VersionConstraints:
    def __init__(
        self,
        *,
        exclude_deprecated: typing.Optional[builtins.bool] = None,
        not_older_than: typing.Optional[datetime.datetime] = None,
        required_features: typing.Optional[typing.Sequence[builtins.str]] = None,
        support_level: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Version selection constraints.

        Defines constraints for automatic version selection to help
        choose the most appropriate version based on requirements.

        :param exclude_deprecated: Whether to exclude deprecated versions. Default: true
        :param not_older_than: Minimum release date for version selection Versions older than this date will be excluded.
        :param required_features: Array of required features that the version must support.
        :param support_level: Required support level Must be one of the VersionSupportLevel constants.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2bcebf3be9934a89eabf09669afb151e0510d3510b90c22489549fe756ea9dec)
            check_type(argname="argument exclude_deprecated", value=exclude_deprecated, expected_type=type_hints["exclude_deprecated"])
            check_type(argname="argument not_older_than", value=not_older_than, expected_type=type_hints["not_older_than"])
            check_type(argname="argument required_features", value=required_features, expected_type=type_hints["required_features"])
            check_type(argname="argument support_level", value=support_level, expected_type=type_hints["support_level"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if exclude_deprecated is not None:
            self._values["exclude_deprecated"] = exclude_deprecated
        if not_older_than is not None:
            self._values["not_older_than"] = not_older_than
        if required_features is not None:
            self._values["required_features"] = required_features
        if support_level is not None:
            self._values["support_level"] = support_level

    @builtins.property
    def exclude_deprecated(self) -> typing.Optional[builtins.bool]:
        '''Whether to exclude deprecated versions.

        :default: true
        '''
        result = self._values.get("exclude_deprecated")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def not_older_than(self) -> typing.Optional[datetime.datetime]:
        '''Minimum release date for version selection Versions older than this date will be excluded.'''
        result = self._values.get("not_older_than")
        return typing.cast(typing.Optional[datetime.datetime], result)

    @builtins.property
    def required_features(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Array of required features that the version must support.'''
        result = self._values.get("required_features")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def support_level(self) -> typing.Optional[builtins.str]:
        '''Required support level Must be one of the VersionSupportLevel constants.'''
        result = self._values.get("support_level")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "VersionConstraints(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.VersionLifecycle",
    jsii_struct_bases=[],
    name_mapping={
        "phase": "phase",
        "version": "version",
        "estimated_sunset_date": "estimatedSunsetDate",
        "next_phase": "nextPhase",
        "transition_date": "transitionDate",
    },
)
class VersionLifecycle:
    def __init__(
        self,
        *,
        phase: builtins.str,
        version: builtins.str,
        estimated_sunset_date: typing.Optional[builtins.str] = None,
        next_phase: typing.Optional[builtins.str] = None,
        transition_date: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Version lifecycle management.

        Tracks the current phase and transition timeline for an API version
        to enable proactive lifecycle management.

        :param phase: Current lifecycle phase Must be one of the VersionPhase constants.
        :param version: The API version string.
        :param estimated_sunset_date: Estimated date when version will be sunset Used for long-term planning.
        :param next_phase: Next planned phase in the lifecycle Must be one of the VersionPhase constants.
        :param transition_date: Date when the current phase was entered.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c362404295e2dc7aaf0aa2e4f14ad45e2149d98426448c16ef6d42342d88ef0d)
            check_type(argname="argument phase", value=phase, expected_type=type_hints["phase"])
            check_type(argname="argument version", value=version, expected_type=type_hints["version"])
            check_type(argname="argument estimated_sunset_date", value=estimated_sunset_date, expected_type=type_hints["estimated_sunset_date"])
            check_type(argname="argument next_phase", value=next_phase, expected_type=type_hints["next_phase"])
            check_type(argname="argument transition_date", value=transition_date, expected_type=type_hints["transition_date"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "phase": phase,
            "version": version,
        }
        if estimated_sunset_date is not None:
            self._values["estimated_sunset_date"] = estimated_sunset_date
        if next_phase is not None:
            self._values["next_phase"] = next_phase
        if transition_date is not None:
            self._values["transition_date"] = transition_date

    @builtins.property
    def phase(self) -> builtins.str:
        '''Current lifecycle phase Must be one of the VersionPhase constants.'''
        result = self._values.get("phase")
        assert result is not None, "Required property 'phase' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def version(self) -> builtins.str:
        '''The API version string.'''
        result = self._values.get("version")
        assert result is not None, "Required property 'version' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def estimated_sunset_date(self) -> typing.Optional[builtins.str]:
        '''Estimated date when version will be sunset Used for long-term planning.

        Example::

            "2026-11-01"
        '''
        result = self._values.get("estimated_sunset_date")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def next_phase(self) -> typing.Optional[builtins.str]:
        '''Next planned phase in the lifecycle Must be one of the VersionPhase constants.'''
        result = self._values.get("next_phase")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def transition_date(self) -> typing.Optional[builtins.str]:
        '''Date when the current phase was entered.

        Example::

            "2024-11-01"
        '''
        result = self._values.get("transition_date")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "VersionLifecycle(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class VersionPhase(
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.VersionPhase",
):
    '''Version lifecycle phases.

    Defines the phases in an API version's lifecycle from initial
    development through sunset.
    '''

    def __init__(self) -> None:
        jsii.create(self.__class__, self, [])

    @jsii.python.classproperty
    @jsii.member(jsii_name="ACTIVE")
    def ACTIVE(cls) -> builtins.str:
        '''Active phase - fully supported and recommended.'''
        return typing.cast(builtins.str, jsii.sget(cls, "ACTIVE"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="DEPRECATED")
    def DEPRECATED(cls) -> builtins.str:
        '''Deprecated phase - migration recommended.'''
        return typing.cast(builtins.str, jsii.sget(cls, "DEPRECATED"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="MAINTENANCE")
    def MAINTENANCE(cls) -> builtins.str:
        '''Maintenance phase - bug fixes only.'''
        return typing.cast(builtins.str, jsii.sget(cls, "MAINTENANCE"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="PREVIEW")
    def PREVIEW(cls) -> builtins.str:
        '''Preview/beta phase - not recommended for production.'''
        return typing.cast(builtins.str, jsii.sget(cls, "PREVIEW"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="SUNSET")
    def SUNSET(cls) -> builtins.str:
        '''Sunset phase - no longer supported.'''
        return typing.cast(builtins.str, jsii.sget(cls, "SUNSET"))


class VersionSupportLevel(
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.VersionSupportLevel",
):
    '''Version support level enumeration for API lifecycle management.

    Defines the current support status of an API version to help developers
    understand maintenance commitments and migration planning.
    '''

    def __init__(self) -> None:
        jsii.create(self.__class__, self, [])

    @jsii.python.classproperty
    @jsii.member(jsii_name="ACTIVE")
    def ACTIVE(cls) -> builtins.str:
        '''Active support - full feature development and bug fixes Recommended for new development.'''
        return typing.cast(builtins.str, jsii.sget(cls, "ACTIVE"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="DEPRECATED")
    def DEPRECATED(cls) -> builtins.str:
        '''Deprecated - security fixes only, migration recommended Should not be used for new development.'''
        return typing.cast(builtins.str, jsii.sget(cls, "DEPRECATED"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="MAINTENANCE")
    def MAINTENANCE(cls) -> builtins.str:
        '''Maintenance support - critical bug fixes only, no new features Stable for production use but consider migration planning.'''
        return typing.cast(builtins.str, jsii.sget(cls, "MAINTENANCE"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="SUNSET")
    def SUNSET(cls) -> builtins.str:
        '''Sunset - no longer supported, immediate migration required May be removed in future releases.'''
        return typing.cast(builtins.str, jsii.sget(cls, "SUNSET"))


__all__ = [
    "ApiSchema",
    "ApiVersionManager",
    "AzapiDiagnosticSettings",
    "AzapiDiagnosticSettingsProps",
    "AzapiResource",
    "AzapiResourceProps",
    "AzapiRoleAssignment",
    "AzapiRoleAssignmentProps",
    "BreakingChange",
    "BreakingChangeType",
    "DataAzapiClientConfig",
    "DataAzapiClientConfigConfig",
    "DataAzapiClientConfigTimeouts",
    "DataAzapiClientConfigTimeoutsOutputReference",
    "DataAzapiResource",
    "DataAzapiResourceConfig",
    "DataAzapiResourceIdentity",
    "DataAzapiResourceIdentityList",
    "DataAzapiResourceIdentityOutputReference",
    "DataAzapiResourceRetry",
    "DataAzapiResourceRetryOutputReference",
    "DataAzapiResourceTimeouts",
    "DataAzapiResourceTimeoutsOutputReference",
    "DiagnosticLogConfig",
    "DiagnosticMetricConfig",
    "MigrationAnalysis",
    "MigrationEffort",
    "PropertyDefinition",
    "PropertyMapping",
    "PropertyTransformationType",
    "PropertyTransformer",
    "PropertyType",
    "PropertyValidation",
    "Resource",
    "ResourceAction",
    "ResourceActionConfig",
    "ResourceActionRetry",
    "ResourceActionRetryOutputReference",
    "ResourceActionTimeouts",
    "ResourceActionTimeoutsOutputReference",
    "ResourceConfig",
    "ResourceGroup",
    "ResourceGroupBody",
    "ResourceGroupProps",
    "ResourceIdentity",
    "ResourceIdentityList",
    "ResourceIdentityOutputReference",
    "ResourceRetry",
    "ResourceRetryOutputReference",
    "ResourceTimeouts",
    "ResourceTimeoutsOutputReference",
    "RetentionPolicyConfig",
    "SchemaMapper",
    "StorageAccount",
    "StorageAccountBody",
    "StorageAccountBodyProperties",
    "StorageAccountEncryption",
    "StorageAccountEncryptionService",
    "StorageAccountEncryptionServices",
    "StorageAccountIdentity",
    "StorageAccountIpRule",
    "StorageAccountNetworkAcls",
    "StorageAccountProps",
    "StorageAccountSku",
    "StorageAccountVirtualNetworkRule",
    "UpdateResource",
    "UpdateResourceConfig",
    "UpdateResourceRetry",
    "UpdateResourceRetryOutputReference",
    "UpdateResourceTimeouts",
    "UpdateResourceTimeoutsOutputReference",
    "ValidationResult",
    "ValidationRule",
    "ValidationRuleType",
    "VersionChangeLog",
    "VersionConfig",
    "VersionConstraints",
    "VersionLifecycle",
    "VersionPhase",
    "VersionSupportLevel",
    "azure_resourcegroup",
    "azure_storageaccount",
    "core_azure",
    "testing",
]

publication.publish()

# Loading modules to ensure their types are registered with the jsii runtime library
from . import azure_resourcegroup
from . import azure_storageaccount
from . import core_azure
from . import testing

def _typecheckingstub__12fabbb87f64a0ee51c6e5006ff938a67747ed83b3a25fa560ecafd1b8899108(
    *,
    properties: typing.Mapping[builtins.str, typing.Union[_PropertyDefinition_2a5c46ac, typing.Dict[builtins.str, typing.Any]]],
    required: typing.Sequence[builtins.str],
    resource_type: builtins.str,
    version: builtins.str,
    deprecated: typing.Optional[typing.Sequence[builtins.str]] = None,
    optional: typing.Optional[typing.Sequence[builtins.str]] = None,
    transformation_rules: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    validation_rules: typing.Optional[typing.Sequence[typing.Union[_PropertyValidation_bb241cd7, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eae53c766f9143385cfa30da80231b50dafd818f3080b18188f5f0c916ecfc50(
    resource_type: builtins.str,
    from_version: builtins.str,
    to_version: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__636a56ca751ba2dbf19051f851f23072e2784c7160fa0cf0bc98210f88b6c1b8(
    resource_type: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5b2e2a21286a265793ba7669b609f098592d5d32196c0618854904f1287e1a21(
    resource_type: builtins.str,
    versions: typing.Sequence[typing.Union[_VersionConfig_ddf991d0, typing.Dict[builtins.str, typing.Any]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__66ce75bb791d3e413bf8c7023c3badc4380fc73c590dc3961bfe4124188fd11f(
    resource_type: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c443670bc20deea13ae38f8902750eec74d9107e2b48beda38016054c3dd3672(
    resource_type: builtins.str,
    version: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__adb294d786c98dfa983d0e38016c245d2dfd857f5389f013bd207654e42e710e(
    resource_type: builtins.str,
    version: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__01628a4957865cbca6342955dff8dba00e1fbcdfa7802c315b2771e4966560df(
    resource_type: builtins.str,
    version: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6a033756641af00746ff216b48d9c17f85dcbeb08ad235af1f0d99d4ac129124(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    eventhub_authorization_rule_id: typing.Optional[builtins.str] = None,
    eventhub_name: typing.Optional[builtins.str] = None,
    log_analytics_workspace_id: typing.Optional[builtins.str] = None,
    logs: typing.Optional[typing.Sequence[typing.Union[_DiagnosticLogConfig_990fcbff, typing.Dict[builtins.str, typing.Any]]]] = None,
    metrics: typing.Optional[typing.Sequence[typing.Union[_DiagnosticMetricConfig_29c0add1, typing.Dict[builtins.str, typing.Any]]]] = None,
    name: typing.Optional[builtins.str] = None,
    storage_account_id: typing.Optional[builtins.str] = None,
    target_resource_id: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__51749f4546a92ef267ad44e27da601035e35f7c9f772c21c942314708f7646a4(
    *,
    eventhub_authorization_rule_id: typing.Optional[builtins.str] = None,
    eventhub_name: typing.Optional[builtins.str] = None,
    log_analytics_workspace_id: typing.Optional[builtins.str] = None,
    logs: typing.Optional[typing.Sequence[typing.Union[_DiagnosticLogConfig_990fcbff, typing.Dict[builtins.str, typing.Any]]]] = None,
    metrics: typing.Optional[typing.Sequence[typing.Union[_DiagnosticMetricConfig_29c0add1, typing.Dict[builtins.str, typing.Any]]]] = None,
    name: typing.Optional[builtins.str] = None,
    storage_account_id: typing.Optional[builtins.str] = None,
    target_resource_id: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a3d3c58c42b41b398803c4efbf0772e4a0c8784d47b74c87dd9ebf23d9d738a1(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    api_version: typing.Optional[builtins.str] = None,
    enable_migration_analysis: typing.Optional[builtins.bool] = None,
    enable_transformation: typing.Optional[builtins.bool] = None,
    enable_validation: typing.Optional[builtins.bool] = None,
    location: typing.Optional[builtins.str] = None,
    name: typing.Optional[builtins.str] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f4ceb970ba75ee62b0297d00ddb7ae9f80bbe8dfed04665ca5ac0918f20f697f(
    object_id: builtins.str,
    role_definition_name: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__238050e80b865d80a0d7c8e5a26741c84d5a802fc7496802ec85f097ef48ad07(
    target_version: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__83e5393f73b29a9c8e15e27771f790289e23467d98ec01c6de05e6c376dc7035(
    resource_id: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a404c6dee43160589c1a592d4c91470f8bc17a406da1d37b670f3f4d7fe00f53(
    properties: typing.Mapping[builtins.str, typing.Any],
    parent_id: builtins.str,
    name: builtins.str,
    location: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3049a84daed50c8ec29f4ae37b33f5f4495e2a3b712158dcc6f0c7b6bf15dd71(
    properties: typing.Mapping[builtins.str, typing.Any],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1fec2795df9e0c4f2b5fa75ff33324d735773ce6d94e46bea101a8717a85e2f2(
    value: _cdktf_9a9027ec.TerraformResource,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8b528c66806e6c4d819f260a5384e8b851df8221b890e5cb4ff575de78472b1c(
    props: typing.Any,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3d93af01845ca8c4fccb8df898596d1e45bcb9c1695be8e9787e78e62e393dfa(
    *,
    api_version: typing.Optional[builtins.str] = None,
    enable_migration_analysis: typing.Optional[builtins.bool] = None,
    enable_transformation: typing.Optional[builtins.bool] = None,
    enable_validation: typing.Optional[builtins.bool] = None,
    location: typing.Optional[builtins.str] = None,
    name: typing.Optional[builtins.str] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__89a5f56067301c27b4a88c97c0bd8eb62b4ad952688cae6c4f4430ff1375d4ad(
    scope_: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    object_id: builtins.str,
    role_definition_name: builtins.str,
    scope: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__333820b506b51590b5eebe73fd9c0f718a72a7642876a758352f5ef516c7e6ba(
    *,
    object_id: builtins.str,
    role_definition_name: builtins.str,
    scope: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d8294b7173ae32b733a72e6bd891a22906cfb0103b787259df438fea598a74df(
    *,
    change_type: builtins.str,
    description: builtins.str,
    migration_path: typing.Optional[builtins.str] = None,
    new_value: typing.Optional[builtins.str] = None,
    old_value: typing.Optional[builtins.str] = None,
    property: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__34f4021e722333d7f25f2e4702396e5276828ffb21525238dd3c45563e02b6a3(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    timeouts: typing.Optional[typing.Union[DataAzapiClientConfigTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3c9f620c2016730f9330066fb5a51d70a38250d6e21a8b8f1ce23836d805be79(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    timeouts: typing.Optional[typing.Union[DataAzapiClientConfigTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__559899a120c7542a83bac439c0c3f3d9e28ae76e687898d3d992b6f5b929a74d(
    *,
    read: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__74702f390141f764fdf6ec8eb155f7eb2c824e59e3b141fa3196ed4a5350f0c7(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__63da91f92c12e34f842a43a27ea2bc2c2c3df1463eb79efb44c1003d8e44ce93(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__58c110e2e7a2d356e44dd596702a266c4aaf9a93226e8ed3699bf16cf421ad08(
    value: typing.Optional[typing.Union[DataAzapiClientConfigTimeouts, _cdktf_9a9027ec.IResolvable]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c7adc2f8d37c7c562f56758085ff1ec8beb6d7c11a4cfcb4d36e46f4146dda82(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    type: builtins.str,
    headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ignore_not_found: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
    name: typing.Optional[builtins.str] = None,
    parent_id: typing.Optional[builtins.str] = None,
    query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
    resource_id: typing.Optional[builtins.str] = None,
    response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    retry: typing.Optional[typing.Union[DataAzapiResourceRetry, typing.Dict[builtins.str, typing.Any]]] = None,
    timeouts: typing.Optional[typing.Union[DataAzapiResourceTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__532d97aa870529660c4bb38e18637d27a329afd791f69324d29e8c23918feacc(
    value: typing.Mapping[builtins.str, builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7c7b6ba90e6525a0888421f65f18cd2160c9ab5bffd8b8ae5840becb3d9c3e33(
    value: typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a49f04a156217b464936ec6285683f722fe2e88d24de4855728301de3368faf2(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__33be1f50f28912350c4a22da8b162035af549991b54c487195c8fdb4960586f5(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0b491d5f9a457e87acb9042e9b853667cbeb9fb2cd21cecef5065a2fb4e71ea7(
    value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__356cd5f181512a85cfff66fa3db791df26401c7b2d626de6392f2519ff9c557a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f9c01a34e566c6937403b0fafb4a100e3abbcc1db069dd1caf8e855db42bdef5(
    value: typing.Mapping[builtins.str, typing.Any],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__47046806ff469369bcac6d1865435c667e47641d7c3204ae81407a1285900fdd(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c81d39048b6d0968fcf6fbef1d7ef5bb78330c8ca8858fed7fc798fcffac245b(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    type: builtins.str,
    headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ignore_not_found: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
    name: typing.Optional[builtins.str] = None,
    parent_id: typing.Optional[builtins.str] = None,
    query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
    resource_id: typing.Optional[builtins.str] = None,
    response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    retry: typing.Optional[typing.Union[DataAzapiResourceRetry, typing.Dict[builtins.str, typing.Any]]] = None,
    timeouts: typing.Optional[typing.Union[DataAzapiResourceTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1af1f16ee49f8f1eb006892654b067335c5615e2119218c5b463d4cd44423f71(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d73de6bb31eacadea85076048396d22000065823db94ddd1398c0ebc6196b7ae(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c7755a917cdb6be8ff581071fa397721555e704f38079240354d4f1cc8cf58cd(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e59e0c1efdfe9e360a8b160c99e164413d90aa08c76354ad57231e66646bf5e9(
    value: _cdktf_9a9027ec.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ce708e452384cc56e89d6a8aa944455b4c1097e39e75cafaefe7183c36be1830(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ea14b6293e41393e2fd23f7e4a73431cd1e1137ffb7c53758a4cf2a2fd74affb(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ce9040397215b4f9cc31e4481741d637cc116b2b4aa4a6bedbce6a1f3336c142(
    value: typing.Optional[DataAzapiResourceIdentity],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7df04d06c2cc51fbca413d1c00ad46d2a1231995725232a29cf8c42c404b954e(
    *,
    error_message_regex: typing.Sequence[builtins.str],
    interval_seconds: typing.Optional[jsii.Number] = None,
    max_interval_seconds: typing.Optional[jsii.Number] = None,
    multiplier: typing.Optional[jsii.Number] = None,
    randomization_factor: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2093914b52815f6c9f8f992df1e490405d2fb0eb3ed92c9d12ecd78f76c683d0(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7a08560fae648b3b5587da5a173b5f7b330ee74ec71188926d8006dd1bc43e84(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a2813ac3834b9d62cab14b97312422f75191219f69e06ef89e97110a04930650(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5f61a85e616e3222353b76f2e6ba60eb38b06dac1f282e0175f8b23a6ae69827(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1ef580c9234e481bb8cb64902ced476c99a940aa92a2e32553f1b1eb4b7fdd9d(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__db016357007f9e31917cffe65e419e26e724e9164b120cb8f4825e4cbc07df46(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e4f27b8b9a04ee51a1b03e59d5efdc7997eb9cc45d244898d6cc9af1d08e2587(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, DataAzapiResourceRetry]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b14e05c954c1083e933078931799aaca03614921080ec3501a0a4da372188b05(
    *,
    read: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__183f068e9cac6c72ba2e3837cc9bcc89ba93501fd5abf5143b74944927e66735(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__396e5079c2a95967f0c3551f59fb096a3ea2e0a28556d951c2e7f9bf9e3f67e9(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9843de41b9274baf366d7a3297247ff082f08ded71e4a69545bf5833e132cd45(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, DataAzapiResourceTimeouts]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__96fea199b663d9dbe1256ea8303c743d790a1bb46e0ef9a6183d574a3bd2f34b(
    *,
    enabled: builtins.bool,
    category: typing.Optional[builtins.str] = None,
    category_group: typing.Optional[builtins.str] = None,
    retention_policy: typing.Optional[typing.Union[_RetentionPolicyConfig_13c42ec6, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ad20bcfb2d477281861ea968578dce4848dbca7c10255e4d7a1f910c686b0785(
    *,
    category: builtins.str,
    enabled: builtins.bool,
    retention_policy: typing.Optional[typing.Union[_RetentionPolicyConfig_13c42ec6, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6f99329161317c6ea230489d13d3b312b6a9a38e9284fb0793d516aea95891c7(
    *,
    automatic_upgrade_possible: builtins.bool,
    breaking_changes: typing.Sequence[typing.Union[_BreakingChange_5dc94c31, typing.Dict[builtins.str, typing.Any]]],
    compatible: builtins.bool,
    estimated_effort: builtins.str,
    from_version: builtins.str,
    to_version: builtins.str,
    warnings: typing.Sequence[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__873687013997a56dc83a159d5ec3b08ecea6e26cf9d0e9412bfe53c038a3f8ee(
    *,
    data_type: builtins.str,
    added_in_version: typing.Optional[builtins.str] = None,
    default_value: typing.Any = None,
    deprecated: typing.Optional[builtins.bool] = None,
    description: typing.Optional[builtins.str] = None,
    removed_in_version: typing.Optional[builtins.str] = None,
    required: typing.Optional[builtins.bool] = None,
    validation: typing.Optional[typing.Sequence[typing.Union[_ValidationRule_f1913ed6, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e646261d26230a31efdf6cc86475e2770b333f18140390e5aec8538d4780530b(
    *,
    source_property: builtins.str,
    target_property: builtins.str,
    default_value: typing.Any = None,
    required: typing.Optional[builtins.bool] = None,
    transformer: typing.Optional[typing.Union[_PropertyTransformer_9b876b7f, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9eb55571415bfbdd70d0e9d0a78c13122ab931b54ab8c79380c0fe0044d09e27(
    *,
    transformation_type: builtins.str,
    config: typing.Any = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__84adfcff60680f878147cacc881873aa8c2fe2987cde811b86790842bf32bba9(
    *,
    property: builtins.str,
    rules: typing.Sequence[typing.Union[_ValidationRule_f1913ed6, typing.Dict[builtins.str, typing.Any]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__360cf756a18f01faf6eea402730f531aef83cf5f1f419da649a2e9b5928d74ad(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    type: builtins.str,
    body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    create_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    create_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
    delete_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    delete_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
    identity: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[ResourceIdentity, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ignore_casing: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
    ignore_missing_property: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
    ignore_null_property: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
    location: typing.Optional[builtins.str] = None,
    locks: typing.Optional[typing.Sequence[builtins.str]] = None,
    name: typing.Optional[builtins.str] = None,
    parent_id: typing.Optional[builtins.str] = None,
    read_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    read_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
    replace_triggers_external_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    replace_triggers_refs: typing.Optional[typing.Sequence[builtins.str]] = None,
    response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    retry: typing.Optional[typing.Union[ResourceRetry, typing.Dict[builtins.str, typing.Any]]] = None,
    schema_validation_enabled: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
    sensitive_body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    sensitive_body_version: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    timeouts: typing.Optional[typing.Union[ResourceTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    update_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    update_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6f150919e21a56a085faf5046991755e5048d66d84d4b475e7fe138f81dbc7be(
    value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[ResourceIdentity, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__98edd861ded07fa7bbcb64cbb23535c57c7912b9ea044420e57e4ab49aa2f676(
    value: typing.Mapping[builtins.str, typing.Any],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e5bc5a1a4b0c645ec8f5b08757f4da96be098885bb6fcc8a04471cf13ccd1974(
    value: typing.Mapping[builtins.str, builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1b0cb7f0c1c1b9b4eafd1bb02195514e3a9b02c438cdf43b145ba46350d14af9(
    value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0b854cd284c7651abfa4dca18251d596d0ac808fa1daeb955602022f1d36881f(
    value: typing.Mapping[builtins.str, builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__af650baa6c89b699d2aaeb9dae047a1ab73f14735ea5566040864cc31b9a10de(
    value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7c330a3da38779fdfde9ce7876aee87039a107dd1abf1ad4a70965d7f6ac24c6(
    value: typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__45eb6abb157ab6d63e1946c17ac812308f7b4d3d395a192022c6b5672892d0c7(
    value: typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4f29ee916ad478f0f1c3d6eec138b84bc516b8bbf1688f25c659ac0a959395ec(
    value: typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__40de70c0c8f1eff71f3465ca96a211867eda879e736c0cdd0dd8721bf2d5eae8(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__41946711b488d86ee4066511bd326ba8fae0292a07da47b826ea818e435cc601(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9e8c2a738ac0a7e986617e7c476e73a630939a10ea67d5631700063935a529e3(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4702438dc870ea43d45f3b2e9b7d7e15df9b998e7e4eb78bd0ab2f3165f95998(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__38d805fbcbb389aafed2b0a7e878ea19eaa04ace49cc995fbe48daad165cf782(
    value: typing.Mapping[builtins.str, builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f8604726bdf155a156d6c5024a7ec71e5a60cd842b7b9edf9ef6891e8bde8be5(
    value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3d60c8fdfa7bcf46fee2e9e31f278fe66ee35ff6a452d2cd492b936672bf08df(
    value: typing.Mapping[builtins.str, typing.Any],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c3ba278ec6bc25bc8f200ac1f3aad8f7e7278ebb9ed40968b75dc5924cc2f86a(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b141e7bfa993c4527bb95583fb32e65e1c81ec037a0f4c87ba003e74231a0335(
    value: typing.Mapping[builtins.str, typing.Any],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3988d4dcdc80fe58d6bfe5b0833246562b217d8f9103298f3c08cf563ac4e6ab(
    value: typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a823ed51d1ce9ba6c69a4c8b3a7c22a9c794ed9aaf9df9b3d97fb6b3ea0a36d5(
    value: typing.Mapping[builtins.str, typing.Any],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__837e68941d7639aceeb0dcd7db90ae3688b8ce5c6711934421026b3538e55f54(
    value: typing.Mapping[builtins.str, builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a6889b4d7b37bf070255471d414ce1869f19c41af6a3132e05b7ae71ae022133(
    value: typing.Mapping[builtins.str, builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__22aad63a3939465809abf1ce8416c25ba8fe259012c462900fcccb00d1b613fa(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ca3eb787ce2c0134489014db653c496820e374931e9387e965898d0a3d74292f(
    value: typing.Mapping[builtins.str, builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__665b7816c8fb83eb81099827eba36497d576d48a89b25694c45b88f3faff00ea(
    value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__da027795a53c827c06f63ae41ff835cffcd5a4ec2fddea4d23dd77566dcdced2(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    resource_id: builtins.str,
    type: builtins.str,
    action: typing.Optional[builtins.str] = None,
    body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    locks: typing.Optional[typing.Sequence[builtins.str]] = None,
    method: typing.Optional[builtins.str] = None,
    query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
    response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    retry: typing.Optional[typing.Union[ResourceActionRetry, typing.Dict[builtins.str, typing.Any]]] = None,
    sensitive_response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    timeouts: typing.Optional[typing.Union[ResourceActionTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    when: typing.Optional[builtins.str] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e6cf10e33b1f20cd2e69e1c8e976bd035ef6b55b4ce733d91ee6d726e849ecd3(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__29829d45a45a8dab2ef641af59ea0c16d8cba8b01a5760d0aba179f21f37b581(
    value: typing.Mapping[builtins.str, typing.Any],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9c649c2389d6150c86086659a272921793bdac1d01a17818729a718634d5f78c(
    value: typing.Mapping[builtins.str, builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ecface4d64f727299378773d22d6aad179566c3b318ab8fb886bf08c1109be0a(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a004d1d6767d31a29dfc6842432afb2b2c56123d78ad2d4dffe7443d09510de1(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__75003ceeeba04467530caba827b8e3acf689d4f714b06fced16ecc43b42f4dba(
    value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__618428c81e64ca9dc3b28ddbd0a2caa3b488ba4899431c70afde207e779a49ae(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__357b0007148e00bdf7bd48788e9dd50264c0b7decb944dd954983ed045d16fe0(
    value: typing.Mapping[builtins.str, typing.Any],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0319798eb06f4e230b99dd90a3a0392620aff4947336e180d07cd99eb67ef2a5(
    value: typing.Mapping[builtins.str, typing.Any],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__595b452dc41ac6e1e18f9f594cf05df16be57566288f18e8c538b35de247eff3(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7e4e242bce02e6a930efa9bfc9ebdf4c1dda6e62bbae50d41d9dd940c2dfdac7(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f8e2bb85c6fbed66627658d3e8222936052424f03b9388708ba0e28309d48ca7(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    resource_id: builtins.str,
    type: builtins.str,
    action: typing.Optional[builtins.str] = None,
    body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    locks: typing.Optional[typing.Sequence[builtins.str]] = None,
    method: typing.Optional[builtins.str] = None,
    query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
    response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    retry: typing.Optional[typing.Union[ResourceActionRetry, typing.Dict[builtins.str, typing.Any]]] = None,
    sensitive_response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    timeouts: typing.Optional[typing.Union[ResourceActionTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    when: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__28e46efabfe16eb872f9211500b5dd2f673943819499d88429251542fb87d608(
    *,
    error_message_regex: typing.Sequence[builtins.str],
    interval_seconds: typing.Optional[jsii.Number] = None,
    max_interval_seconds: typing.Optional[jsii.Number] = None,
    multiplier: typing.Optional[jsii.Number] = None,
    randomization_factor: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__00c2b505e65ddc5b0eab80b8e3925e063da0ba2a162cf555ff1da5fa728f859b(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__baae077936ab43a7958119c062b9fad9e223deb4cc1a0c05b8edbdeae1418a7c(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9f364015da412ddbcdf7e825f3063adc0b3de3bf9363d68e147722bc2411f8aa(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d40beb561bc4af16cab276bed7ab791d6d3478f692640f472415e88be5ea03dd(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e2262c316736506a51d44f860c32ba79aa990b17c43b3c3479e47992738912a4(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bd6be8daf53287e67ad06aa69e56938d7f91719ed089167a362e1cbe5d2391c2(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__026803ddbdf7b5454fdd2d1dac7f26b97cdd33f24166845a5f1bbb406c6ca40e(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceActionRetry]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3ee5eacfd46440ebfb5470174494f3da3d2ea98c95731344f7e0794305cdb15e(
    *,
    create: typing.Optional[builtins.str] = None,
    delete: typing.Optional[builtins.str] = None,
    read: typing.Optional[builtins.str] = None,
    update: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f0d0cb9794de2331a0700fc234c67c1c997de1bccf68794aff848a45872aab72(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a656c1a2a49619464df067705a34ecc7311594a109ac428f21d5180142e5262e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__06a44b9c7e024ce8ba9a65de2a1d2e3b83c16e2175cf074a964fe2ea8df03783(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__31257aab74109d3af4698313da9c73e0d185636e06e2c9bee106bf22de94e89f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__35e531b763c8e10f3decbaf7a5738cf248e9ea7b21a2bc3001de3b1fe735d065(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eb8f61d9dfa427401bb0a23cb0dc1488c437e857a759fbe4368ce74f670b549d(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceActionTimeouts]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0dba8b11025af1cd1bb936835c3223213bf9904b11157b2cd5518ae03dd90289(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    type: builtins.str,
    body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    create_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    create_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
    delete_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    delete_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
    identity: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[ResourceIdentity, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ignore_casing: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
    ignore_missing_property: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
    ignore_null_property: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
    location: typing.Optional[builtins.str] = None,
    locks: typing.Optional[typing.Sequence[builtins.str]] = None,
    name: typing.Optional[builtins.str] = None,
    parent_id: typing.Optional[builtins.str] = None,
    read_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    read_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
    replace_triggers_external_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    replace_triggers_refs: typing.Optional[typing.Sequence[builtins.str]] = None,
    response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    retry: typing.Optional[typing.Union[ResourceRetry, typing.Dict[builtins.str, typing.Any]]] = None,
    schema_validation_enabled: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
    sensitive_body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    sensitive_body_version: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    timeouts: typing.Optional[typing.Union[ResourceTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    update_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    update_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__29b0473f748c77e8cf5a499a8a1cb9dbd38d71e9f891bc8febb8ed132057b1ce(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
    managed_by: typing.Optional[builtins.str] = None,
    api_version: typing.Optional[builtins.str] = None,
    enable_migration_analysis: typing.Optional[builtins.bool] = None,
    enable_transformation: typing.Optional[builtins.bool] = None,
    enable_validation: typing.Optional[builtins.bool] = None,
    location: typing.Optional[builtins.str] = None,
    name: typing.Optional[builtins.str] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9d0bd2aa8c367d05c112de956c05b3cac70fb756df9f741c93e072adb1999441(
    key: builtins.str,
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3fc32ce7cf0743f4d9783f3fb0755941fbe96b318c5653c79f3bc1f3f8af25ec(
    props: typing.Any,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3db8fd46010c87b10ea96e6f0c568b0de43fddb6044a500c41b8a2bb905961ed(
    key: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1323ac136a1170344d1118d9c54f81085344d6968ef0d2d115e69fc0fa8254d0(
    *,
    location: builtins.str,
    managed_by: typing.Optional[builtins.str] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__00f9d149205e57c257371a1ebedf9fed7fb1e90db72bae0538c3d2fec74c45be(
    *,
    api_version: typing.Optional[builtins.str] = None,
    enable_migration_analysis: typing.Optional[builtins.bool] = None,
    enable_transformation: typing.Optional[builtins.bool] = None,
    enable_validation: typing.Optional[builtins.bool] = None,
    location: typing.Optional[builtins.str] = None,
    name: typing.Optional[builtins.str] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
    managed_by: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__52c12ff10ae1f91ea81406a63ac44465db1733866e3b4e573c96fbd491e8396a(
    *,
    type: builtins.str,
    identity_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ad8d5bcf536a2bf97e7c786ae80ebde8ed0263faaa0da60aafb6a9c34bbfbd28(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e2853f8e17a0492754c88e8f76e6da89db331a4e7d3b433ba9398c406c8945d5(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7d91140734b86f4427853447aab47a37a2eb5d7e0f178adec228df8c4e915a5d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__41f84f167da33ddaf69687ffe06bbe94c7ea1b052b6d03296eb6452ee6349386(
    value: _cdktf_9a9027ec.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1eb795e3b089bdae4f19ca0c05ca50f165c61d0240fbcc4f7eabf33bcca4e631(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e52ebd7e8bcbdea5dc89cc5b9b0867832aa098d2fa4dffe77bf6bbd0a9e7cb42(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[ResourceIdentity]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f19617e93a12cd6b0421753d1b24a2c4b49d02f4b495c1e5e300d0d8792480db(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8ac80f65161d5f9550a7fd12ec9c6e719abfd6ba606e52b7eb5ff5b7dcc057da(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6426f4c03ae3bdae7cab4d741f9740345086ca56b44437ac0a6798b395a95f5d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a86e85302b9b79b20851effe0af9250a8f5a2e902618a3df8ae46e57f8d38a18(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceIdentity]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__024e91c8b12ce75919dbcc4b5e0b1db9094d70c07451c163b0e308801852c9c3(
    *,
    error_message_regex: typing.Sequence[builtins.str],
    interval_seconds: typing.Optional[jsii.Number] = None,
    max_interval_seconds: typing.Optional[jsii.Number] = None,
    multiplier: typing.Optional[jsii.Number] = None,
    randomization_factor: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6bb64d0a72a186c4863d2a4a71b30ac970083c75f978e112917a733263aebb1c(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__25b8230f793ecd56b881e62949fd842e67d99df864648976c2e13bed7a938654(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7ed0e0aa54dc53eabceb33268d39eafa992b77b554a143f773ffea7445730a1f(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7acfe1be0d5b1089b93b5281bbe4ddfa35b311b3dd4e77b9c22294f4bfacd6c8(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7f98bbdc89b58f2d423b303e43458dfb5fe88d3fe28fc532cf16cb892d747907(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0282de5cab879cf45313e14134319b2259b2e50de1343cdf51a84c04e2e9677d(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e3c2a4029bce73af4eecab3710e0bbcab30af3631ca57e4d7221bc1c2931134f(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceRetry]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d5eda75602061bb145f3d35070438044c4bbb7ca7feb7df8adf7b438026f3d9b(
    *,
    create: typing.Optional[builtins.str] = None,
    delete: typing.Optional[builtins.str] = None,
    read: typing.Optional[builtins.str] = None,
    update: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e9dd0b4cb6319942940e117e4eb08f8fe2c13aa394c52a85206e8600f9dace0b(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fd8df8efdf1749681e653a7efce9f5db55b5e525f066e2754f6c287f9ae3d92c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5ad77ecbaeba8f59286342f048f3683cfdbd1115ab10ee2a355bc41584fa0b03(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d1275a9ef5ffb9ab2fcb7563a67feee38f587d99ba4cae8e65b7493c9d4786d1(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5281d50a62ebece318860e00e21dbae13c791abdb339dc50b4c46bac442c7019(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5fb549b00fd4a8c6de83658597b657b96b3d7c272740e27a65c20ccc7187d868(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, ResourceTimeouts]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7638bfc6d836a3bc87e0b0222bc338bd510d5d7a354220a29559904376c0a1a1(
    *,
    days: jsii.Number,
    enabled: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9bc74f355d7d1fbc5878fd5086f6a928f240de6ff73782a583c218a10d828715(
    properties: typing.Any,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__43d584f170c18d0a1f9ce4ebea063952f341a4fd5428b535de04954db03508bc(
    property_name: builtins.str,
    value: typing.Any,
    *,
    data_type: builtins.str,
    added_in_version: typing.Optional[builtins.str] = None,
    default_value: typing.Any = None,
    deprecated: typing.Optional[builtins.bool] = None,
    description: typing.Optional[builtins.str] = None,
    removed_in_version: typing.Optional[builtins.str] = None,
    required: typing.Optional[builtins.bool] = None,
    validation: typing.Optional[typing.Sequence[typing.Union[_ValidationRule_f1913ed6, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ed7a2ae22d9d62578b80294cb5e2742132463bddece8df681e869f07c4734680(
    source_props: typing.Any,
    *,
    properties: typing.Mapping[builtins.str, typing.Union[_PropertyDefinition_2a5c46ac, typing.Dict[builtins.str, typing.Any]]],
    required: typing.Sequence[builtins.str],
    resource_type: builtins.str,
    version: builtins.str,
    deprecated: typing.Optional[typing.Sequence[builtins.str]] = None,
    optional: typing.Optional[typing.Sequence[builtins.str]] = None,
    transformation_rules: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    validation_rules: typing.Optional[typing.Sequence[typing.Union[_PropertyValidation_bb241cd7, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bfa13727f782f0851343415e4c43c40889fbd50653114d5f10bee312362db43d(
    properties: typing.Any,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b723ffd4e5207ba4fcafe0e1ca19c61dbe7d2cfea410be368c89585a651db31c(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    sku: typing.Union[_StorageAccountSku_fa953b33, typing.Dict[builtins.str, typing.Any]],
    access_tier: typing.Optional[builtins.str] = None,
    allow_blob_public_access: typing.Optional[builtins.bool] = None,
    enable_https_traffic_only: typing.Optional[builtins.bool] = None,
    encryption: typing.Optional[typing.Union[_StorageAccountEncryption_77d27837, typing.Dict[builtins.str, typing.Any]]] = None,
    identity: typing.Optional[typing.Union[_StorageAccountIdentity_d6b6a344, typing.Dict[builtins.str, typing.Any]]] = None,
    ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
    kind: typing.Optional[builtins.str] = None,
    minimum_tls_version: typing.Optional[builtins.str] = None,
    network_acls: typing.Optional[typing.Union[_StorageAccountNetworkAcls_768fda36, typing.Dict[builtins.str, typing.Any]]] = None,
    resource_group_id: typing.Optional[builtins.str] = None,
    api_version: typing.Optional[builtins.str] = None,
    enable_migration_analysis: typing.Optional[builtins.bool] = None,
    enable_transformation: typing.Optional[builtins.bool] = None,
    enable_validation: typing.Optional[builtins.bool] = None,
    location: typing.Optional[builtins.str] = None,
    name: typing.Optional[builtins.str] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6d4e890b88be1047ae9d17f768064bd1e8113534b01c70eadffeedde9929441b(
    key: builtins.str,
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ba54a1f3260d1a10e0e0845ba8ad70caf3468f8b4c2ef774f8198d9f228b1e11(
    props: typing.Any,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__900410703cbb9d837c440ac28e508c62fba57a49e5ebfcc50111c14f14238d7b(
    key: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b57d5b316754bbd430424592c26503e0ccd012f480d21900f4dad4d48b1398b2(
    *,
    kind: builtins.str,
    location: builtins.str,
    sku: typing.Union[_StorageAccountSku_fa953b33, typing.Dict[builtins.str, typing.Any]],
    identity: typing.Optional[typing.Union[_StorageAccountIdentity_d6b6a344, typing.Dict[builtins.str, typing.Any]]] = None,
    properties: typing.Optional[typing.Union[_StorageAccountBodyProperties_4d550b33, typing.Dict[builtins.str, typing.Any]]] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__40f569c3e3a12c7436014caf94387a09bff2f9c6f171ccb9d8f510fc2f60ec1b(
    *,
    access_tier: typing.Optional[builtins.str] = None,
    allow_blob_public_access: typing.Optional[builtins.bool] = None,
    encryption: typing.Optional[typing.Union[_StorageAccountEncryption_77d27837, typing.Dict[builtins.str, typing.Any]]] = None,
    minimum_tls_version: typing.Optional[builtins.str] = None,
    network_acls: typing.Optional[typing.Union[_StorageAccountNetworkAcls_768fda36, typing.Dict[builtins.str, typing.Any]]] = None,
    supports_https_traffic_only: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8ed14d2e557eb2340e8a610a56556e2f85a87f10993561aa732e622fda9d4dce(
    *,
    key_source: typing.Optional[builtins.str] = None,
    services: typing.Optional[typing.Union[_StorageAccountEncryptionServices_8a1bf271, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a6d0ec7498167d2e53cc6b520284093055f4a44fab1eb71da6132dfb50211bb6(
    *,
    enabled: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b7563a9805c7ad8fed6c30d58d9736388e5ad53e0f156ba7c14a77e9561b0a38(
    *,
    blob: typing.Optional[typing.Union[_StorageAccountEncryptionService_aaadb7be, typing.Dict[builtins.str, typing.Any]]] = None,
    file: typing.Optional[typing.Union[_StorageAccountEncryptionService_aaadb7be, typing.Dict[builtins.str, typing.Any]]] = None,
    queue: typing.Optional[typing.Union[_StorageAccountEncryptionService_aaadb7be, typing.Dict[builtins.str, typing.Any]]] = None,
    table: typing.Optional[typing.Union[_StorageAccountEncryptionService_aaadb7be, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__502fa19b120d6e7109eec152cd494ff2ee5ddbe633cca88345174662345345f4(
    *,
    type: builtins.str,
    user_assigned_identities: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4b79a21076dc9f14021e21bf25e1dc488ee8035373bd2369979335116b3cfabb(
    *,
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1f28dba6ea2cd128a19e73772f7563bbbde15eba3f292a0b0bf9b031557ae004(
    *,
    bypass: typing.Optional[builtins.str] = None,
    default_action: typing.Optional[builtins.str] = None,
    ip_rules: typing.Optional[typing.Sequence[typing.Union[_StorageAccountIpRule_83a6da4e, typing.Dict[builtins.str, typing.Any]]]] = None,
    virtual_network_rules: typing.Optional[typing.Sequence[typing.Union[_StorageAccountVirtualNetworkRule_825a3860, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__50747e225fb92dcb75801bf29a578ecfd07d5458a3f1b792b469a0235e8c5a49(
    *,
    api_version: typing.Optional[builtins.str] = None,
    enable_migration_analysis: typing.Optional[builtins.bool] = None,
    enable_transformation: typing.Optional[builtins.bool] = None,
    enable_validation: typing.Optional[builtins.bool] = None,
    location: typing.Optional[builtins.str] = None,
    name: typing.Optional[builtins.str] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    sku: typing.Union[_StorageAccountSku_fa953b33, typing.Dict[builtins.str, typing.Any]],
    access_tier: typing.Optional[builtins.str] = None,
    allow_blob_public_access: typing.Optional[builtins.bool] = None,
    enable_https_traffic_only: typing.Optional[builtins.bool] = None,
    encryption: typing.Optional[typing.Union[_StorageAccountEncryption_77d27837, typing.Dict[builtins.str, typing.Any]]] = None,
    identity: typing.Optional[typing.Union[_StorageAccountIdentity_d6b6a344, typing.Dict[builtins.str, typing.Any]]] = None,
    ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
    kind: typing.Optional[builtins.str] = None,
    minimum_tls_version: typing.Optional[builtins.str] = None,
    network_acls: typing.Optional[typing.Union[_StorageAccountNetworkAcls_768fda36, typing.Dict[builtins.str, typing.Any]]] = None,
    resource_group_id: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f170c62cdf8fb6a8a124b20e1b48a309ba2dc3cbbdf6ddc5798be9e101de4ba1(
    *,
    name: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3073662893bd85c109decc801fdb5b5d9ef7d2f526570fb1f6dcf9bc82edbd9a(
    *,
    id: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__281208bd5979459b2fb9c40473b7e56ff3827a001dfdab3f367e6d9fa584f1ad(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    type: builtins.str,
    body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    ignore_casing: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
    ignore_missing_property: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
    locks: typing.Optional[typing.Sequence[builtins.str]] = None,
    name: typing.Optional[builtins.str] = None,
    parent_id: typing.Optional[builtins.str] = None,
    read_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    read_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
    resource_id: typing.Optional[builtins.str] = None,
    response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    retry: typing.Optional[typing.Union[UpdateResourceRetry, typing.Dict[builtins.str, typing.Any]]] = None,
    sensitive_body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    sensitive_body_version: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    timeouts: typing.Optional[typing.Union[UpdateResourceTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    update_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    update_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__24bd794bbb1c46f8402e96bc858c8b28a4df0590b2d7ec745bbffb768c3d3470(
    value: typing.Mapping[builtins.str, typing.Any],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4cb8639f9a6c82b24ae25e590163132a7c1792f25db19e5af27ec1b7260c0c2a(
    value: typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c927810abfe7b4a93a2fbe970cda9edc52458cfc55d325dd0bef1eb10166d266(
    value: typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c66cc57c5c940069dfa83f81f2b057d8eeb97eb23f6e8f5e612a20d1ca2bfbe0(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e5509c8c583dfd37eb7060c7ea283c0d48a6db05c143e44b8d74f03a717ab06c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0ee27014ec34d7df609c5d4d737f963f47a932978b48529be68eeaf583b3b30d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2f5f4a4fbb1be9992450563aa07816a421096eead03aff37e8c856bd42467c48(
    value: typing.Mapping[builtins.str, builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8382baf5d98d087a6f342e3de120650f84a781f601d9d3e0c0a8e9436658ccb1(
    value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__724528297e435ecd5d272c296a481cf0035199c8fa6e59f6e8d50de64b1be84d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bc2704da0c80b3eff015e9306a550af5fb677bdca419c256e384ef41c206f576(
    value: typing.Mapping[builtins.str, typing.Any],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4a601f943176f52cfd86bece65a02257c652ca356e0a5d03633156ccf00c8ca1(
    value: typing.Mapping[builtins.str, typing.Any],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d1e5a9bd6f57eefda1dc9ffe8f8e3220c35d087ac5d6fc3a2a7fd0fb1e01b432(
    value: typing.Mapping[builtins.str, builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6faff092d7698d576ca2125b85d264d346e87923aa86938a05cc59b365f562bc(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1df2ecf47fdda34769a609afd2ff064f7dba437a340acaa5c572ac5ee66ae164(
    value: typing.Mapping[builtins.str, builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__997323a4824c206e270959d8c13005833d29789e2c841658d98259d3e2ee0fe0(
    value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.List[builtins.str]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7b47a964a364d29e6295c7e65c99c8a54cd1962f0bd798c23d32ee91f00e4a13(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    type: builtins.str,
    body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    ignore_casing: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
    ignore_missing_property: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
    locks: typing.Optional[typing.Sequence[builtins.str]] = None,
    name: typing.Optional[builtins.str] = None,
    parent_id: typing.Optional[builtins.str] = None,
    read_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    read_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
    resource_id: typing.Optional[builtins.str] = None,
    response_export_values: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    retry: typing.Optional[typing.Union[UpdateResourceRetry, typing.Dict[builtins.str, typing.Any]]] = None,
    sensitive_body: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    sensitive_body_version: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    timeouts: typing.Optional[typing.Union[UpdateResourceTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    update_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    update_query_parameters: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Mapping[builtins.str, typing.Sequence[builtins.str]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__87d45f83b2ad1d82c585e1dba7904d689304a9d3f8e8b83aaafd685ddc575771(
    *,
    error_message_regex: typing.Sequence[builtins.str],
    interval_seconds: typing.Optional[jsii.Number] = None,
    max_interval_seconds: typing.Optional[jsii.Number] = None,
    multiplier: typing.Optional[jsii.Number] = None,
    randomization_factor: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c41206770fa357fa9709c92d018356f71b2e869135d9fe2861d8157847223556(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__da62c45d5fbf12579507780b8c2183bd172b80225c48b831e041bd16e9303cb2(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__edb395a935210b210773fbc5a92da77cafde2ae6c7bca0e8af9442c17428f48e(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f47cf8c7b3f381923d0a2daadd5b1874533029c21befa0ec4128fcb287e1fca1(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dc6aeca07ac69489c9dfeac49dd53309a5fe591b3332385ff32f64d17c8296dc(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0e34b85505a5ed45c25bc4b00f058a7820d2104f28f306ab039fcd3e9b1c1131(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a1858a84871a0495501923f0e43383c66682ba256e531363d48c31ef7505b6aa(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, UpdateResourceRetry]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7beb3d1c9cf97f822976fb8d91dde2779b79c5b2568e7e5917e16c666376c6c7(
    *,
    create: typing.Optional[builtins.str] = None,
    delete: typing.Optional[builtins.str] = None,
    read: typing.Optional[builtins.str] = None,
    update: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4cdb2be43cdb81266407e287f64c0f7ead06e2cc7b0af479133afe8a3f8e5441(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2ea0c0435ad4f0bbc6334e33680c82d307017baf1d3faa288e184f9b6012b7cb(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__97fa4065ed423e575c7441b8d3cd5824905feeaf4af1151d6c8335a357aa6572(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__62808aa669eed1a514c445c8d9b9dcdc6910194f865509913e8cfc403a1071ed(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__500c9941017ee642f6d6664026835932d4644c05cfe9f19f28f00529e6bf3f8b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2ce912d4ee4c6f42dd550125ccdf206b15eb5503da49fd7c4e1709b5283de27a(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, UpdateResourceTimeouts]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e65d20f8430765c4156f0a11302091f5baf85b0f70db34bdcaf4ed8dc8365404(
    *,
    errors: typing.Sequence[builtins.str],
    valid: builtins.bool,
    warnings: typing.Sequence[builtins.str],
    property_errors: typing.Optional[typing.Mapping[builtins.str, typing.Sequence[builtins.str]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__74fd92c71ed2c1615886631f31c8b508b206e72f93a2b7fd1c30a52a199f0892(
    *,
    rule_type: builtins.str,
    message: typing.Optional[builtins.str] = None,
    value: typing.Any = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b56a9bd32e04dbce9a4e8ec5d6350fb902c7dd6cdab1c292b8f0a593c3227531(
    *,
    change_type: builtins.str,
    description: builtins.str,
    affected_property: typing.Optional[builtins.str] = None,
    breaking: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__189788820aa0902240f9afa632bd5e213fdd9ff8bd2341f60745e78e53a0c91d(
    *,
    release_date: builtins.str,
    schema: typing.Union[_ApiSchema_5ce0490e, typing.Dict[builtins.str, typing.Any]],
    support_level: builtins.str,
    version: builtins.str,
    breaking_changes: typing.Optional[typing.Sequence[typing.Union[_BreakingChange_5dc94c31, typing.Dict[builtins.str, typing.Any]]]] = None,
    change_log: typing.Optional[typing.Sequence[typing.Union[_VersionChangeLog_3bfd366b, typing.Dict[builtins.str, typing.Any]]]] = None,
    deprecation_date: typing.Optional[builtins.str] = None,
    migration_guide: typing.Optional[builtins.str] = None,
    sunset_date: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2bcebf3be9934a89eabf09669afb151e0510d3510b90c22489549fe756ea9dec(
    *,
    exclude_deprecated: typing.Optional[builtins.bool] = None,
    not_older_than: typing.Optional[datetime.datetime] = None,
    required_features: typing.Optional[typing.Sequence[builtins.str]] = None,
    support_level: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c362404295e2dc7aaf0aa2e4f14ad45e2149d98426448c16ef6d42342d88ef0d(
    *,
    phase: builtins.str,
    version: builtins.str,
    estimated_sunset_date: typing.Optional[builtins.str] = None,
    next_phase: typing.Optional[builtins.str] = None,
    transition_date: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass
