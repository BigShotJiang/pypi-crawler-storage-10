#include <stdio.h>

int a[10][10], visited[10], n;

void bfs(int s) {
    int q[10], f = 0, r = 0;
    q[r++] = s;
    visited[s] = 1;
    while (f < r) {
        int u = q[f++];
        printf("%d ", u);
        for (int v = 1; v <= n; v++)
            if (a[u][v] == 1 && !visited[v]) {
                q[r++] = v;
                visited[v] = 1;
            }
    }
}

int main() {
    int s;
    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
            scanf("%d", &a[i][j]);
    scanf("%d", &s);
    bfs(s);
}
