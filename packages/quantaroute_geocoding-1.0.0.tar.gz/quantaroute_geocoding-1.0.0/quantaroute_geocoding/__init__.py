"""
QuantaRoute Geocoding Python SDK

A Python library for geocoding addresses to DigiPin codes with both online API
and offline processing capabilities.
"""

__version__ = "1.0.0"
__author__ = "QuantaRoute"
__email__ = "support@quantaroute.com"

from .client import QuantaRouteClient
from .offline import OfflineProcessor
from .csv_processor import CSVProcessor
from .exceptions import (
    QuantaRouteError,
    APIError,
    RateLimitError,
    AuthenticationError,
    ValidationError
)

__all__ = [
    "QuantaRouteClient",
    "OfflineProcessor", 
    "CSVProcessor",
    "QuantaRouteError",
    "APIError",
    "RateLimitError",
    "AuthenticationError",
    "ValidationError"
]
