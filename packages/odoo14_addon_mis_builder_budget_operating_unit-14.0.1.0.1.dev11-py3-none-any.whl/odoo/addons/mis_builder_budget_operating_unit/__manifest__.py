# Copyright (C) 2018 by Camptocamp
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).
{
    "name": "MIS Builder Budget with Operating Unit",
    "version": "14.0.1.0.0",
    "category": "Reporting",
    "author": "Camptocamp,Odoo Community Association (OCA)",
    "license": "AGPL-3",
    "website": "https://github.com/OCA/operating-unit",
    "depends": ["mis_builder_budget", "operating_unit"],
    "data": ["views/mis_builder_budget.xml"],
    "auto_install": True,
}
