import typing
from underautomation.fanuc.ftp.variables.generic_variable_type import GenericVariableType
import clr
import os
clr.AddReference(os.path.realpath(os.path.join(os.path.dirname(__file__), "..", "..",  'lib', 'UnderAutomation.Fanuc.dll')))
from UnderAutomation.Fanuc.Ftp.Variables import LogScrnFlVariableType as log_scrn_fl_variable_type

class LogScrnFlVariableType(GenericVariableType):
	def __init__(self, _internal = 0):
		if(_internal == 0):
			self._instance = log_scrn_fl_variable_type()
		else:
			self._instance = _internal
	@property
	def sp_id(self) -> int:
		return self._instance.SpId
	@property
	def scrn_id(self) -> int:
		return self._instance.ScrnId
	@property
	def fanuc_internal_type_name(self) -> str:
		return self._instance.FanucInternalTypeName
