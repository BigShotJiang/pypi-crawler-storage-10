# Eozilla Cuiman

The Cuiman package provides a client Python API, GUI, and CLI 
for servers compliant with the [OGC API - Processes, Part 1](https://github.com/opengeospatial/ogcapi-processes).
