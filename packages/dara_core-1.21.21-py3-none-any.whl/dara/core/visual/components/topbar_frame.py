"""
Copyright 2023 Impulse Innovations Limited


Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

from pydantic import ConfigDict

from dara.core.definitions import ComponentInstance, JsComponentDef

TopBarFrameDef = JsComponentDef(name='TopBarFrame', js_module='@darajs/core', py_module='dara.core')


class TopBarFrame(ComponentInstance):
    content: ComponentInstance
    hide_logo: bool | None = False
    logo_width: str | None = '10rem'
    logo_path: str | None = None
    logo_position: str | None = None
    top_bar: ComponentInstance | None = None
    top_bar_padding: str | None = None
    top_bar_position: str | None = None
    top_bar_height: str | None = None
    model_config = ConfigDict(extra='forbid')
