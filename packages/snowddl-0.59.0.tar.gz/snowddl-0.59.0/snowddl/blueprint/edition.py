from enum import IntEnum


class Edition(IntEnum):
    STANDARD = 1
    ENTERPRISE = 2
    BUSINESS_CRITICAL = 3
