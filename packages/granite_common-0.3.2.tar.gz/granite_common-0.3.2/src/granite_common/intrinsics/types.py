# SPDX-License-Identifier: Apache-2.0

__doc__ = """
Dataclasses used by the IO code for rag-agent-lib.
"""
