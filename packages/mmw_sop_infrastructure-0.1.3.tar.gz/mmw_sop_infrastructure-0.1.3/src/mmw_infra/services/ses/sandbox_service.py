import asyncio
import functools
import os
import shutil
import tempfile
import traceback
from datetime import datetime
from typing import Any, Dict, Optional, List, Tuple

try:
    from docker.models.containers import Container
except ImportError:  # pragma: no cover - optional dependency may be absent
    Container = Any  # type: ignore[misc, assignment]

from mmw_infra.common.dependencies import (
    DOCKER_AVAILABLE,
    logging,
    docker,
    APIError,
    ImageNotFound,
    NotFound,
    DockerTimeoutError,
)
from .sandbox_models import (
    SESEnvironmentConfig,
    SESExecutionResult,
    SESExecutionStatus,
)


class SecureExecutionService:
    """
    Provides an isolated, secure environment for executing untrusted code using Docker.
    Implements asynchronous wrappers for blocking Docker SDK calls.
    """

    def __init__(self, default_config: SESEnvironmentConfig):
        self.default_config = default_config
        self.logger = logging.getLogger("SecureExecutionService")
        self.client = None
        self.is_initialized = False

        if not DOCKER_AVAILABLE:
            self.logger.error(
                "SecureExecutionService initialized but Docker SDK is unavailable."
            )
            return

        self._initialize_docker_client()

    def _initialize_docker_client(self) -> None:
        try:
            self.client = docker.from_env()
            self.client.ping()
            self.is_initialized = True
            self.logger.info("Successfully connected to Docker daemon.")
        except Exception as exc:
            self.logger.error(
                "Failed to connect to Docker daemon. SES disabled. [%s] %s",
                type(exc).__name__,
                exc,
            )
            self.is_initialized = False

    async def _run_in_executor(self, func, *args):
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, functools.partial(func, *args))

    async def ensure_image_available(self, image_name: str) -> None:
        if not self.is_initialized:
            return

        def sync_pull():
            try:
                self.client.images.get(image_name)
            except ImageNotFound:
                self.logger.info("Image %s not found locally. Pulling...", image_name)
                try:
                    self.client.images.pull(image_name)
                    self.logger.info("Image %s pulled successfully.", image_name)
                except APIError as exc:
                    self.logger.error(
                        "Failed to pull Docker image %s: %s", image_name, exc
                    )
                    raise RuntimeError(
                        f"Failed to pull required image: {image_name}"
                    ) from exc

        await self._run_in_executor(sync_pull)

    async def execute_code(
        self,
        code: str,
        input_files: Optional[Dict[str, str]] = None,
        output_filenames: Optional[List[str]] = None,
        config: Optional[SESEnvironmentConfig] = None,
    ) -> SESExecutionResult:
        if not self.is_initialized:
            return SESExecutionResult(
                status=SESExecutionStatus.ERROR,
                error_message="Secure Execution Sandbox not initialized.",
            )

        exec_config = config or self.default_config
        start_time = datetime.now()
        temp_dir = None
        container = None

        try:
            temp_dir = await self._run_in_executor(
                self._prepare_workspace_sync, code, input_files
            )

            container, status, exit_code = await self._run_in_executor(
                self._execute_container_sync, temp_dir, exec_config
            )

            return await self._run_in_executor(
                self._collect_outputs_sync,
                container,
                temp_dir,
                start_time,
                status,
                output_filenames,
                exit_code,
            )
        except ImageNotFound:
            return SESExecutionResult(
                status=SESExecutionStatus.ERROR,
                error_message=f"Docker image not found: {exec_config.image_name}",
            )
        except (APIError, ValueError) as exc:
            self.logger.error("Execution setup error: %s", exc)
            return SESExecutionResult(
                status=SESExecutionStatus.ERROR,
                error_message=f"Execution setup error: {exc}",
            )
        except Exception as exc:
            self.logger.error(
                "Unexpected error during SES execution: %s\n%s",
                exc,
                traceback.format_exc(),
            )
            return SESExecutionResult(
                status=SESExecutionStatus.ERROR,
                error_message=f"Internal SES error: {exc}",
            )
        finally:
            await self._run_in_executor(self._cleanup_sync, container, temp_dir)

    def _prepare_workspace_sync(
        self, code: str, input_files: Optional[Dict[str, str]]
    ) -> str:
        temp_dir = tempfile.mkdtemp(prefix="mmw_ses_")
        try:
            script_path = os.path.join(temp_dir, "script.py")
            with open(script_path, "w", encoding="utf-8") as handle:
                handle.write(code)

            if input_files:
                for filename, content in input_files.items():
                    if ".." in filename or filename.startswith("/"):
                        raise ValueError(f"Unsafe filename detected: {filename}")
                    file_path = os.path.join(temp_dir, filename)
                    os.makedirs(os.path.dirname(file_path), exist_ok=True)
                    with open(file_path, "w", encoding="utf-8") as handle:
                        handle.write(content)
            return temp_dir
        except Exception:
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
            raise

    def _execute_container_sync(
        self, temp_dir: str, config: SESEnvironmentConfig
    ) -> Tuple[Container, SESExecutionStatus, Optional[int]]:
        mount_mode = "ro" if config.security.read_only_workdir else "rw"
        volumes = {temp_dir: {"bind": config.workdir, "mode": mount_mode}}
        nano_cpus = int(config.resources.cpu_limit * 1e9)
        security_opt = ["no-new-privileges"] if config.security.no_new_privileges else None
        cap_drop = ["ALL"] if config.security.drop_capabilities else None
        network_mode = "none" if config.security.network_disabled else "bridge"

        container = self.client.containers.create(
            image=config.image_name,
            command=["python3", os.path.join(config.workdir, "script.py")],
            working_dir=config.workdir,
            volumes=volumes,
            user=config.container_user,
            mem_limit=config.resources.memory_limit,
            nano_cpus=nano_cpus,
            network_mode=network_mode,
            security_opt=security_opt,
            cap_drop=cap_drop,
            detach=True,
        )

        try:
            container.start()
            result = container.wait(timeout=config.resources.timeout_seconds)
            exit_code = result.get("StatusCode", -1)
            status = (
                SESExecutionStatus.SUCCESS
                if exit_code == 0
                else SESExecutionStatus.FAILED
            )
            return container, status, exit_code
        except DockerTimeoutError:
            self.logger.warning(
                "Execution timed out after %ss.", config.resources.timeout_seconds
            )
            try:
                container.stop(timeout=5)
            except APIError as stop_exc:
                self.logger.error("Failed to stop container after timeout: %s", stop_exc)
            return container, SESExecutionStatus.TIMEOUT, None

    def _collect_outputs_sync(
        self,
        container: Container,
        temp_dir: str,
        start_time: datetime,
        status: SESExecutionStatus,
        output_filenames: Optional[List[str]],
        exit_code: Optional[int],
    ) -> SESExecutionResult:
        duration = (datetime.now() - start_time).total_seconds()

        try:
            stdout = container.logs(stdout=True, stderr=False).decode(
                "utf-8", errors="replace"
            )
            stderr = container.logs(stdout=False, stderr=True).decode(
                "utf-8", errors="replace"
            )
        except Exception as exc:
            self.logger.error("Failed to retrieve container logs: %s", exc)
            stdout = "[Error retrieving stdout]"
            stderr = f"[Error retrieving stderr: {exc}]"
            if status == SESExecutionStatus.SUCCESS:
                status = SESExecutionStatus.ERROR

        output_files: Dict[str, str] = {}
        if output_filenames:
            for filename in output_filenames:
                if ".." in filename or filename.startswith("/"):
                    continue
                file_path = os.path.join(temp_dir, filename)
                if os.path.exists(file_path):
                    try:
                        with open(file_path, "r", encoding="utf-8") as handle:
                            output_files[filename] = handle.read()
                    except Exception as exc:
                        output_files[filename] = f"[Error reading output file: {exc}]"
                else:
                    if status in (
                        SESExecutionStatus.SUCCESS,
                        SESExecutionStatus.FAILED,
                    ):
                        output_files[filename] = "[File Not Found]"

        return SESExecutionResult(
            status=status,
            exit_code=exit_code,
            stdout=stdout,
            stderr=stderr,
            output_files=output_files,
            duration_seconds=duration,
        )

    def _cleanup_sync(
        self, container: Optional[Container], temp_dir: Optional[str]
    ) -> None:
        if container:
            try:
                container.remove(force=True)
            except NotFound:
                pass
            except Exception as exc:
                self.logger.error(
                    "Failed to remove container %s: %s",
                    getattr(container, "id", "N/A"),
                    exc,
                )

        if temp_dir and os.path.exists(temp_dir):
            try:
                shutil.rmtree(temp_dir)
            except Exception as exc:
                self.logger.error(
                    "Failed to clean up temporary directory %s: %s", temp_dir, exc
                )
