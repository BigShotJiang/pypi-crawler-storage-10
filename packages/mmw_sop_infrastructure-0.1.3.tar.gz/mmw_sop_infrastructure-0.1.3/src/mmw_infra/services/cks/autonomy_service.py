from typing import Dict, Optional, Tuple
from uuid import UUID, uuid4

from mmw_infra.common.dependencies import (
    logging,
    PYDANTIC_AVAILABLE,
    PYYAML_AVAILABLE,
    yaml,
)
from mmw_infra.models.execution_state import (
    AutonomyProfile,
    InteractionControlMode,
    ConditionalBypassConfig,
)


class AutonomyProfileService:
    """
    Configuration & Knowledge Service (CKS) component for managing autonomy profiles.
    """

    def __init__(self):
        self._profile_registry: Dict[UUID, AutonomyProfile] = {}
        self._active_profiles_per_run: Dict[UUID, UUID] = {}
        self._system_default_profile_id: Optional[UUID] = None

        logging.info("AutonomyProfileService initialized.")
        self._register_default_profiles()

    def _register_default_profiles(self) -> None:
        standard = AutonomyProfile(
            profile_id=uuid4(),
            profile_name="Standard Oversight (Default)",
            default_mode=InteractionControlMode.MANDATORY,
        )
        self.register_profile(standard, set_as_system_default=True)

        high_autonomy = AutonomyProfile(
            profile_id=uuid4(),
            profile_name="High Autonomy (Conditional)",
            default_mode=InteractionControlMode.CONDITIONAL_BYPASS,
            conditional_config=ConditionalBypassConfig(confidence_threshold="Medium"),
            mode_overrides={
                "GAC": InteractionControlMode.MANDATORY,
                "AVL": InteractionControlMode.MANDATORY,
            },
        )
        self.register_profile(high_autonomy)

    def register_profile(
        self, profile: AutonomyProfile, set_as_system_default: bool = False
    ) -> None:
        self._profile_registry[profile.profile_id] = profile
        if set_as_system_default:
            self._system_default_profile_id = profile.profile_id
            logging.info(
                "Registered profile %s as system default.", profile.profile_name
            )

    def load_profiles_from_yaml(self, file_path: str) -> None:
        if not PYYAML_AVAILABLE:
            logging.error("PyYAML dependency is not available; cannot load profiles.")
            raise ImportError("PyYAML is not installed.")

        try:
            with open(file_path, "r", encoding="utf-8") as handle:
                data = yaml.safe_load(handle)
        except Exception as exc:
            logging.error("Failed to read autonomy profile file %s: %s", file_path, exc)
            raise

        if not isinstance(data, list):
            raise ValueError("Autonomy profile configuration must be a list.")

        for profile_data in data:
            if not isinstance(profile_data, dict):
                logging.warning("Skipping malformed profile entry: %s", profile_data)
                continue

            profile_data = profile_data.copy()
            profile_id = profile_data.get("profile_id")
            if profile_id:
                try:
                    profile_data["profile_id"] = UUID(str(profile_id))
                except ValueError:
                    logging.warning(
                        "Invalid profile_id '%s' encountered; generating new UUID.", profile_id
                    )
                    profile_data["profile_id"] = uuid4()
            else:
                profile_data["profile_id"] = uuid4()

            def convert_mode(value, context):
                try:
                    return (
                        value
                        if isinstance(value, InteractionControlMode)
                        else InteractionControlMode(value)
                    )
                except ValueError:
                    logging.warning("Unknown interaction mode '%s' in %s.", value, context)
                    return None

            default_mode = profile_data.get("default_mode")
            if default_mode is not None:
                mode = convert_mode(default_mode, "default_mode")
                if mode is None:
                    continue
                profile_data["default_mode"] = mode

            conditional = profile_data.get("conditional_config")
            if conditional and "confidence_threshold" in conditional:
                conditional["confidence_threshold"] = str(conditional["confidence_threshold"])

            for override_field in ("mode_overrides", "interaction_overrides"):
                overrides = profile_data.get(override_field, {})
                if isinstance(overrides, dict):
                    for key, value in list(overrides.items()):
                        mode = convert_mode(value, f"{override_field}[{key}]")
                        if mode:
                            overrides[key] = mode
                        else:
                            del overrides[key]

            try:
                if PYDANTIC_AVAILABLE:
                    profile = AutonomyProfile.model_validate(profile_data)
                else:
                    profile = AutonomyProfile(**profile_data)
                self.register_profile(profile)
            except Exception as exc:
                logging.error(
                    "Failed to register autonomy profile '%s': %s",
                    profile_data.get("profile_name"),
                    exc,
                )
                raise

    def set_system_default_profile(self, profile_id: UUID) -> None:
        if profile_id not in self._profile_registry:
            raise ValueError(f"Profile ID {profile_id} not found in registry.")
        self._system_default_profile_id = profile_id
        logging.info("System default profile set to ID: %s", profile_id)

    def activate_profile_for_run(
        self, run_id: UUID, profile_id: Optional[UUID] = None
    ) -> None:
        if profile_id is None:
            if self._system_default_profile_id is None:
                raise RuntimeError(
                    "No profile_id provided and system default profile is not set."
                )
            profile_id = self._system_default_profile_id

        if profile_id not in self._profile_registry:
            raise ValueError(f"Profile ID {profile_id} not found in registry.")

        self._active_profiles_per_run[run_id] = profile_id
        logging.info("Activated Profile %s for Run %s.", profile_id, run_id)

    def get_active_profile(self, run_id: UUID) -> AutonomyProfile:
        profile_id = self._active_profiles_per_run.get(run_id, self._system_default_profile_id)
        if profile_id is None:
            raise RuntimeError(
                f"Could not determine active autonomy profile for Run {run_id}."
            )
        profile = self._profile_registry.get(profile_id)
        if not profile:
            raise RuntimeError(f"Profile ID {profile_id} not found in registry.")
        return profile

    def get_control_mode_for_run(
        self, run_id: UUID, interaction_id: Optional[str], hitl_mode: str
    ) -> Tuple[InteractionControlMode, AutonomyProfile]:
        profile = self.get_active_profile(run_id)
        mode = self.get_control_mode(profile, interaction_id, hitl_mode)
        return mode, profile

    def get_control_mode(
        self, profile: AutonomyProfile, interaction_id: Optional[str], hitl_mode: str
    ) -> InteractionControlMode:
        interaction_overrides = getattr(profile, "interaction_overrides", {}) or {}
        if interaction_id and interaction_id in interaction_overrides:
            return interaction_overrides[interaction_id]

        mode_overrides = getattr(profile, "mode_overrides", {}) or {}
        if hitl_mode in mode_overrides:
            return mode_overrides[hitl_mode]

        return getattr(profile, "default_mode", InteractionControlMode.MANDATORY)

    def get_profile(self, profile_id: UUID) -> Optional[AutonomyProfile]:
        return self._profile_registry.get(profile_id)

