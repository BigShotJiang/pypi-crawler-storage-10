from sqlalchemy import Column, String, DateTime, Text, JSON
from sqlalchemy.orm import declarative_base

from mmw_infra.common.utils import GUID

Base = declarative_base()


class InteractionDB(Base):
    __tablename__ = "hbs_interactions"

    interaction_id = Column(GUID, primary_key=True)
    run_id = Column(GUID, nullable=False, index=True)
    thread_id = Column(String(100), nullable=False)
    mode = Column(String(50), nullable=False)
    status = Column(String(50), nullable=False, index=True)

    ai_presentation_json = Column(Text, nullable=False)
    human_input_json = Column(Text, nullable=True)

    workflow_config_json = Column(Text, nullable=True)

    timestamp_start = Column(DateTime(timezone=True), nullable=False)
    timestamp_end = Column(DateTime(timezone=True), nullable=True)
