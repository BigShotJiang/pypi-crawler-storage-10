import json
import logging
from typing import Any, Dict, List, Literal, Optional
from uuid import uuid4
from datetime import datetime, timezone

# Core Infrastructure Imports
from mmw_infra.execution.ble import AbstractBLE, BLEExecutionError
from mmw_infra.execution.execution_states import ReasoningGraphState
from mmw_infra.models.execution_state import ExecutionStatus
from mmw_infra.models.hitl_schema import (
    HITL_InteractionRecord, SCA_Input, EKI_Input, VARL_Input,
    OptionAnalysis, TradeoffDimension, ContentBlock, ConfidenceScore,
    StructuredQuery, KnowledgeQueryType, VARL_Decision, 
    # Import Output types for validation within helpers
    VARL_Output, EKI_Output, SCA_Output, HITL_Output, VARL_Item_Output
)
from mmw_infra.common.dependencies import (
    BaseModel, Field, PromptTemplate, PydanticOutputParser, StrOutputParser, PYDANTIC_AVAILABLE
)


# ================================================================================
# 1. Pydantic Models for Structured LLM Outputs
# These models define the data contracts between the LLM and the BLE handlers.
# ================================================================================

# --- RP1: Semantic Deconstruction ---
class CoreElement(BaseModel):
    element_type: Literal["Entity", "Process", "Interaction"] = Field(description="Classification of the element.")
    name: str = Field(description="Name or brief description of the element.")
    description: str = Field(description="Detailed explanation and role in the system.")

class SemanticDeconstruction(BaseModel):
    background_description: str = Field(description="Summary of the contextual background.")
    rigid_requirements: List[str] = Field(description="List of explicit constraints and requirements.")
    core_elements: List[CoreElement] = Field(description="Identified entities, processes, and interactions.")
    inferred_intent: Literal["Optimization", "Prediction", "Evaluation", "Mechanism Exploration", "Policy Design"] = Field(description="The core intent of the problem.")
    intent_justification: str = Field(description="Reasoning behind the intent classification.")

# --- RP6: Meta-Analysis ---
class MetaAnalysis(BaseModel):
    problem_type_classification: str = Field(description="Classification based on historical context.")
    review_preferences: List[str] = Field(description="Common expectations of reviewers.")
    common_pitfalls: List[str] = Field(description="Typical mistakes or weaknesses.")

# --- RP2/HITL-A: Domain Paradigm ---
class ParadigmOption(BaseModel):
    paradigm_id: str = Field(description="Unique identifier (e.g., 'sys_dyn').")
    name: str = Field(description="Name of the modeling paradigm.")
    description: str = Field(description="Brief overview.")
    fundamental_principles: List[str] = Field(description="Core laws or principles.")
    standard_model_types: List[str] = Field(description="Common model architectures.")

class DomainIdentification(BaseModel):
    primary_domain: str = Field(description="The primary modeling domain identified.")
    candidate_paradigms: List[ParadigmOption] = Field(description="List of potential modeling paradigms.")

class SCATradeoffAnalysis(BaseModel):
    # Used specifically for generating the structured content of the SCA payload
    options_analysis: List[OptionAnalysis]
    ai_recommendation_id: str

# --- RP3/HITL-B: Mechanism Exploration ---
class CausalLink(BaseModel):
    source: str
    target: str
    relationship_type: Literal["Reinforcing", "Balancing", "Inhibiting", "Promoting", "Complex"]
    certainty: ConfidenceScore

class MechanismExploration(BaseModel):
    governing_principles: List[str]
    causal_diagram_description: str
    causal_links: List[CausalLink]
    feedback_loops: List[str]
    uncertainty_sources: List[str]

# --- RP4/HITL-C: Stakeholder Analysis ---
class Stakeholder(BaseModel):
    stakeholder_id: str
    name: str
    explicit_goals: List[str]
    implicit_goals: List[str]
    potential_conflicts: List[str]
    ai_confidence_implicit_goals: ConfidenceScore

class StakeholderMap(BaseModel):
    stakeholders: List[Stakeholder]

# --- RP5: Information Gap ---
class InformationGap(BaseModel):
    area: str
    description: str
    importance: Literal["Critical", "High", "Medium", "Low"]
    proposed_action: Literal["Assume", "Research", "Sensitivity Analysis"]

class InformationGapAnalysisReport(BaseModel):
    gaps: List[InformationGap]

# --- Synthesis/HITL-D: Final Brief (Output 1) ---
class BackgroundMechanismAnalysisBrief(BaseModel):
    executive_summary: str
    core_phenomena: str
    dominant_mechanisms: str
    standardized_terminology: Dict[str, str]
    system_boundary: str

# ================================================================================
# 2. The BLE Class Definition
# ================================================================================

class BLE_Step_1_1(AbstractBLE):
    """
    Business Logic Executor for SOP Step 1.1: Deep Contextual Deconstruction & Paradigm Identification.
    """

    def _register_nodes(self) -> None:
        """
        Registers handlers, implementing the parallelized structure and HITL integration points defined in the SOP.
        """
        # Parallel Start (1 & 6)
        self.register_node("1.1-RP1", self.handle_semantic_deconstruction)
        self.register_node("1.1-RP6", self.handle_meta_analysis)

        # Track A: Domain and Mechanism (Depends on RP1)
        self.register_node("1.1-RP2", self.handle_domain_identification)
        self.register_node("1.1-HITL-A-Request", self.handle_request_paradigm_choice)
        self.register_node("1.1-HITL-A-Process", self.handle_process_paradigm_choice)
        self.register_node("1.1-RP3", self.handle_mechanism_exploration)
        self.register_node("1.1-HITL-B-Request", self.handle_request_mechanism_validation)
        self.register_node("1.1-HITL-B-Process", self.handle_process_mechanism_validation)

        # Track B: Stakeholders (Depends on RP1, RP6)
        self.register_node("1.1-RP4", self.handle_stakeholder_analysis)
        self.register_node("1.1-HITL-C-Request", self.handle_request_stakeholder_validation)
        self.register_node("1.1-HITL-C-Process", self.handle_process_stakeholder_validation)

        # Convergence and Finalization (Depends on Tracks A and B completion)
        self.register_node("1.1-RP5", self.handle_information_gap_analysis)
        self.register_node("1.1-Synthesis", self.handle_synthesis)
        self.register_node("1.1-HITL-D-Request", self.handle_request_brief_approval)
        self.register_node("1.1-HITL-D-Process", self.handle_process_brief_approval)

    # ================================================================================
    # 3. Handler Methods
    # ================================================================================

    # --- RP1 & RP6 (Parallel Start) ---

    async def handle_semantic_deconstruction(self, state: ReasoningGraphState) -> Dict[str, Any]:
        self.logger.info("Executing Node 1.1-RP1: Semantic Deconstruction & Intent Identification.")

        # Access Input (Pattern 1)
        # Check for both English and Chinese names as specified in the SOP Input section
        problem_statement = state["chassis_context"]["inputs"].get("Problem Statement")
        if not problem_statement:
            problem_statement = state["chassis_context"]["inputs"].get("原始赛题文本 (Problem Statement)")
        
        if not problem_statement:
            raise BLEExecutionError("Missing required input: 'Problem Statement'.")

        # LLM Invocation (Pattern 2)
        parser = PydanticOutputParser(pydantic_object=SemanticDeconstruction)
        prompt = PromptTemplate(
            template="""
Analyze the following problem statement in depth (语义解构与意图识别). 
1. Distinguish background context (背景描述) from rigid requirements (刚性要求).
2. Identify core Entities, Processes, and Interactions (核心实体、过程、交互关系).
3. Infer the primary intent (Optimization, Prediction, Evaluation, Mechanism Exploration, or Policy Design) and justify the classification (推断命题人的核心意图).

{OPTIMIZATION_HINT}

Problem Statement:
{problem_statement}

{format_instructions}
""",
            input_variables=["problem_statement"],
            partial_variables={"format_instructions": parser.get_format_instructions()},
        )

        chain_inputs = await self.prepare_prompt(prompt, state)
        chain_inputs["problem_statement"] = problem_statement

        chain = prompt | self.default_llm | parser
        result: SemanticDeconstruction = await self.invoke_chain(chain, chain_inputs)

        return {"semantic_deconstruction": result.model_dump()}

    async def handle_meta_analysis(self, state: ReasoningGraphState) -> Dict[str, Any]:
        self.logger.info("Executing Node 1.1-RP6: Meta-Analysis (Review Perspective).")

        problem_type = state["chassis_context"].get("problem_type", "Unknown")

        # LLM Invocation (Pattern 2)
        parser = PydanticOutputParser(pydantic_object=MetaAnalysis)
        prompt = PromptTemplate(
            template="""
Perform a meta-analysis (元分析) for a mathematical modeling competition problem of type: {problem_type}.
Based on historical trends (O奖论文库), reviewer feedback (评审意见), and modeling best practices (建模教材), identify:
1. The precise classification of this problem type.
2. Common review preferences and expectations (评审偏好).
3. Common pitfalls and weaknesses (常见陷阱).

{OPTIMIZATION_HINT}

{format_instructions}
""",
            input_variables=["problem_type"],
            partial_variables={"format_instructions": parser.get_format_instructions()},
        )

        chain_inputs = await self.prepare_prompt(prompt, state)
        chain_inputs["problem_type"] = problem_type
        
        chain = prompt | self.default_llm | parser
        result: MetaAnalysis = await self.invoke_chain(chain, chain_inputs)

        return {"meta_analysis": result.model_dump()}

    # --- Track A: Domain and Mechanism ---

    async def handle_domain_identification(self, state: ReasoningGraphState) -> Dict[str, Any]:
        self.logger.info("Executing Node 1.1-RP2: Domain Identification & Paradigm Matching.")

        # Access previous node results (Pattern 1)
        deconstruction_raw = state["node_results"]["1.1-RP1"]["semantic_deconstruction"]

        # LLM Invocation (Pattern 2)
        parser = PydanticOutputParser(pydantic_object=DomainIdentification)
        prompt = PromptTemplate(
            template="""
Perform Domain Identification & Paradigm Matching (领域定位与范式匹配).
Based on the semantic deconstruction, classify the problem into core modeling domains (如动态系统、网络科学、运筹优化等).
Then, list 2-4 candidate modeling paradigms. For each, detail its fundamental principles (基本定律) and standard model types (标准模型类别).

{OPTIMIZATION_HINT}

Semantic Deconstruction Summary (JSON):
{deconstruction_summary}

{format_instructions}
""",
            input_variables=["deconstruction_summary"],
            partial_variables={"format_instructions": parser.get_format_instructions()},
        )

        chain_inputs = await self.prepare_prompt(prompt, state)
        # Serialize the dictionary for the prompt
        chain_inputs["deconstruction_summary"] = json.dumps(deconstruction_raw, indent=2)

        chain = prompt | self.default_llm | parser
        result: DomainIdentification = await self.invoke_chain(chain, chain_inputs)

        return {"domain_identification": result.model_dump()}

    async def handle_request_paradigm_choice(self, state: ReasoningGraphState) -> Dict[str, Any]:
        self.logger.info("Executing Node 1.1-HITL-A-Request: Domain Paradigm Strategic Choice (SCA).")

        # Access inputs
        domain_info_raw = state["node_results"]["1.1-RP2"]["domain_identification"]
        domain_info = DomainIdentification.model_validate(domain_info_raw)
        deconstruction_raw = state["node_results"]["1.1-RP1"]["semantic_deconstruction"]
        deconstruction = SemanticDeconstruction.model_validate(deconstruction_raw)

        # Use LLM to generate the Trade-off Matrix analysis (权衡矩阵) for the SCA payload
        parser = PydanticOutputParser(pydantic_object=SCATradeoffAnalysis)
        prompt = PromptTemplate(
            template="""
You are preparing a Strategic Choice Architecture (SCA) presentation for a human expert (Selector). Generate a "权衡矩阵 (Trade-off Matrix)" to facilitate the selection of the optimal modeling paradigm.

Problem Context (Inferred Intent): {problem_intent}

Candidate Paradigms (JSON):
{candidate_paradigms}

For each candidate paradigm, perform a rigorous trade-off analysis across these dimensions:
1. 核心机制解释力 (Explanatory Power).
2. 与问题本质的契合度 (Fit to Problem Essence).
3. 数据需求与可得性的匹配度 (Data Requirements Match).
4. 计算可行性与复杂度 (Computational Feasibility/Complexity).

Structure the output as a list of OptionAnalysis objects (using the schema defined in mmw_infra.models.hitl_schema). Finally, provide your recommendation ID (ai_recommendation_id).

{format_instructions}
""",
            input_variables=["problem_intent", "candidate_paradigms"],
            partial_variables={"format_instructions": parser.get_format_instructions()},
        )

        chain_inputs = {
            "problem_intent": deconstruction.inferred_intent,
            "candidate_paradigms": json.dumps([p.model_dump() for p in domain_info.candidate_paradigms], indent=2)
        }

        chain = prompt | self.default_llm | parser
        tradeoff_result: SCATradeoffAnalysis = await self.invoke_chain(chain, chain_inputs)

        # Construct the HITL Interaction Record (Pattern 3)
        sca_payload = SCA_Input(
            strategic_context="确定基础范式是高杠杆的战略决策 (Determining the foundational paradigm is a high-leverage strategic decision). Please review the trade-off analysis and select the optimal paradigm.",
            options=tradeoff_result.options_analysis,
            ai_recommendation_id=tradeoff_result.ai_recommendation_id
        )

        interaction_record = HITL_InteractionRecord(
            interaction_id=str(uuid4()),
            interaction_specific_id="1.1-A",
            mode="SCA",
            workflow_step_id=self.step_definition.id,
            timestamp_start=datetime.now(timezone.utc),
            ai_presentation=sca_payload,
            autonomy_profile_active=state["chassis_context"]["autonomy_profile"].profile_name,
        )

        return {"pending_interactions": [interaction_record]}

    async def handle_process_paradigm_choice(self, state: ReasoningGraphState) -> Dict[str, Any]:
        self.logger.info("Executing Node 1.1-HITL-A-Process: Processing Paradigm Choice.")

        # Process HITL Feedback (Pattern 4)
        interaction = self._find_interaction(state, "1.1-A")
        
        selected_id, rationale = self._process_sca_decision(interaction)

        self.logger.info(f"Selected Paradigm ID: {selected_id}. Rationale: {rationale}")

        # Retrieve the details of the selected paradigm
        domain_info_raw = state["node_results"]["1.1-RP2"]["domain_identification"]
        domain_info = DomainIdentification.model_validate(domain_info_raw)

        selected_paradigm = next((p for p in domain_info.candidate_paradigms if p.paradigm_id == selected_id), None)

        if not selected_paradigm:
            # Fallback logic: If the ID isn't found in the original list (e.g., if LLM regenerated IDs during SCA analysis),
            # try to reconstruct it from the interaction presentation options.
             self.logger.warning(f"Selected ID {selected_id} not found in original RP2 output. Attempting fallback reconstruction.")
             
             # Access options from ai_presentation (robustly handling dict/object)
             ai_presentation = interaction.ai_presentation
             options = []
             if hasattr(ai_presentation, 'options'):
                 options = ai_presentation.options
             elif isinstance(ai_presentation, dict):
                 options = ai_presentation.get('options', [])

             selected_option = next((o for o in options if (o.option_id if hasattr(o, 'option_id') else o.get('option_id')) == selected_id), None)
             
             if selected_option:
                 # Reconstruct a minimal ParadigmOption
                 opt_name = selected_option.option_name if hasattr(selected_option, 'option_name') else selected_option.get('option_name')
                 opt_desc = selected_option.description if hasattr(selected_option, 'description') else selected_option.get('description')
                 
                 selected_paradigm = ParadigmOption(
                     paradigm_id=selected_id,
                     name=opt_name or "Unknown",
                     description=opt_desc or "",
                     fundamental_principles=["(Reconstructed from SCA)"],
                     standard_model_types=["(Reconstructed from SCA)"]
                 )
             else:
                raise BLEExecutionError(f"Selected paradigm ID '{selected_id}' could not be found or reconstructed.")


        return {
            "selected_paradigm": selected_paradigm.model_dump(),
            "Domain Paradigm Reference List": domain_info_raw # Output 3 of the SOP
        }

    async def handle_mechanism_exploration(self, state: ReasoningGraphState) -> Dict[str, Any]:
        self.logger.info("Executing Node 1.1-RP3: Mechanism Exploration.")

        # Access inputs
        deconstruction_raw = state["node_results"]["1.1-RP1"]["semantic_deconstruction"]
        selected_paradigm_raw = state["node_results"]["1.1-HITL-A-Process"]["selected_paradigm"]
        selected_paradigm = ParadigmOption.model_validate(selected_paradigm_raw)

        # LLM Invocation (Pattern 2)
        parser = PydanticOutputParser(pydantic_object=MechanismExploration)
        prompt = PromptTemplate(
            template="""
Perform Core Mechanism Exploration (核心机制探索). Use the principles of the selected modeling paradigm ({paradigm_name}) to analyze the system.

Selected Paradigm Principles: {paradigm_principles}

Problem Context (Core Elements JSON):
{core_elements}

Tasks:
1. Identify the Governing Principles (底层原理).
2. Develop a conceptual Causal Diagram (因果关系图) (structured CausalLinks and textual description).
3. Identify key feedback loops (反馈回路) and sources of uncertainty (不确定性来源).
4. Assign confidence scores (certainty) to the causal links.

{format_instructions}
""",
            input_variables=["paradigm_name", "paradigm_principles", "core_elements"],
            partial_variables={"format_instructions": parser.get_format_instructions()},
        )

        chain_inputs = {
            "paradigm_name": selected_paradigm.name,
            "paradigm_principles": json.dumps(selected_paradigm.fundamental_principles, indent=2),
            "core_elements": json.dumps(deconstruction_raw.get("core_elements", []), indent=2)
        }

        chain = prompt | self.default_llm | parser
        result: MechanismExploration = await self.invoke_chain(chain, chain_inputs)

        return {"mechanism_exploration": result.model_dump()}

    async def handle_request_mechanism_validation(self, state: ReasoningGraphState) -> Dict[str, Any]:
        self.logger.info("Executing Node 1.1-HITL-B-Request: Core Mechanism Validation & Knowledge Injection (EKI).")

        # Access inputs
        mechanism_raw = state["node_results"]["1.1-RP3"]["mechanism_exploration"]
        mechanism = MechanismExploration.model_validate(mechanism_raw)

        # Identify areas of uncertainty and generate structured queries
        queries = []

        # Query 1: Validate Governing Principles
        queries.append(StructuredQuery(
            query_id=f"EKI-B-GP-{uuid4().hex[:6]}",
            query_type=KnowledgeQueryType.LOGIC_CORRECTION,
            context="Validating the fundamental governing principles identified for the system.",
            question=f"请确认或修正这些底层原理 (Please confirm or correct these governing principles): {mechanism.governing_principles}."
        ))

        # Query 2: Validate Low/Medium Confidence Causal Links
        low_confidence_links = [link for link in mechanism.causal_links if link.certainty in [ConfidenceScore.LOW, ConfidenceScore.MEDIUM]]
        for link in low_confidence_links:
             queries.append(StructuredQuery(
                    query_id=f"EKI-B-CL-{uuid4().hex[:6]}",
                    query_type=KnowledgeQueryType.LOGIC_CORRECTION,
                    context=f"Validating causal link: {link.source} -> {link.target}. Current type: {link.relationship_type}. Confidence: {link.certainty}.",
                    question=f"请确认交互关系是抑制性还是促进性？ (Please confirm or correct the relationship type between {link.source} and {link.target})."
                ))

        # Query 3: Address Uncertainty Sources (e.g., Parameter Ranges)
        for source in mechanism.uncertainty_sources:
             queries.append(StructuredQuery(
                    query_id=f"EKI-B-US-{uuid4().hex[:6]}",
                    query_type=KnowledgeQueryType.PARAMETER_RANGE,
                    context=f"Addressing uncertainty source: {source}",
                    question=f"变量在此环境下的合理数值范围是多少？ (What is the reasonable numerical range for the variable/factor '{source}' in this context?)"
                ))

        if not queries:
            self.logger.info("No significant mechanism uncertainties identified. Skipping EKI interaction.")
            return {"eki_skipped": True}

        # Construct the EKI Payload (Pattern 3)
        eki_payload = EKI_Input(
            knowledge_gap_summary="LLM可能存在知识盲区 (LLM may have knowledge gaps). Expert validation is required to ensure the underlying mechanisms are accurate and to inject specific domain knowledge.",
            queries=queries
        )

        interaction_record = HITL_InteractionRecord(
            interaction_id=str(uuid4()),
            interaction_specific_id="1.1-B",
            mode="EKI",
            workflow_step_id=self.step_definition.id,
            timestamp_start=datetime.now(timezone.utc),
            ai_presentation=eki_payload,
            autonomy_profile_active=state["chassis_context"]["autonomy_profile"].profile_name,
        )

        return {"pending_interactions": [interaction_record], "eki_skipped": False}

    async def handle_process_mechanism_validation(self, state: ReasoningGraphState) -> Dict[str, Any]:
        self.logger.info("Executing Node 1.1-HITL-B-Process: Processing Mechanism Validation (Refiner Pattern).")

        # Access original mechanism
        mechanism_raw = state["node_results"]["1.1-RP3"]["mechanism_exploration"]
        mechanism = MechanismExploration.model_validate(mechanism_raw)

        # Check if EKI was skipped
        if state["node_results"]["1.1-HITL-B-Request"].get("eki_skipped", False):
            self.logger.info("EKI interaction was skipped. Proceeding with original mechanism.")
            return {"refined_mechanism": mechanism.model_dump()}

        # Process HITL Feedback (Pattern 4)
        interaction = self._find_interaction(state, "1.1-B")
        
        responses = self._process_eki_decision(interaction)

        if not responses:
             # Bypassed or no responses provided
             return {"refined_mechanism": mechanism.model_dump()}

        # Use LLM (Refiner Pattern) to integrate the expert knowledge
        prompt = PromptTemplate(
            template="""
Integrate expert feedback (EKI Responses) into the Original Mechanism Exploration. This is the EKI integration step (注入、修正或确认精确的领域知识).

Original Mechanism Exploration (JSON):
{original_mechanism}

Expert Feedback (EKI Responses JSON):
{expert_feedback}

Instructions:
1. Update Causal Links, Governing Principles, and Descriptions based on the expert's input.
2. Increase the certainty score for elements validated or corrected by the expert to 'High'.
3. Update or remove uncertainty sources that have been clarified.
4. Output the refined MechanismExploration object.

{format_instructions}
""",
            input_variables=["original_mechanism", "expert_feedback"],
            partial_variables={"format_instructions": PydanticOutputParser(pydantic_object=MechanismExploration).get_format_instructions()},
        )

        chain_inputs = {
            "original_mechanism": json.dumps(mechanism_raw, indent=2),
            "expert_feedback": json.dumps(responses, indent=2)
        }

        chain = prompt | self.default_llm | PydanticOutputParser(pydantic_object=MechanismExploration)
        refined_mechanism: MechanismExploration = await self.invoke_chain(chain, chain_inputs)

        return {"refined_mechanism": refined_mechanism.model_dump()}

    # --- Track B: Stakeholders ---

    async def handle_stakeholder_analysis(self, state: ReasoningGraphState) -> Dict[str, Any]:
        self.logger.info("Executing Node 1.1-RP4: Stakeholder Analysis.")

        # Access inputs
        deconstruction_raw = state["node_results"]["1.1-RP1"]["semantic_deconstruction"]
        # Meta-analysis is an optional input from the parallel track
        meta_analysis_raw = state["node_results"]["1.1-RP6"].get("meta_analysis", {})

        # LLM Invocation (Pattern 2)
        parser = PydanticOutputParser(pydantic_object=StakeholderMap)
        prompt = PromptTemplate(
            template="""
Perform a comprehensive Stakeholder Analysis (利益相关者分析). This is critical for ICM and policy problems.

Problem Context (Deconstruction JSON):
{context_summary}

Meta-Analysis Insights (Review Preferences/Pitfalls JSON):
{meta_insights}

Tasks:
1. Identify all relevant stakeholders (识别所有相关方).
2. Analyze their explicit goals (显性目标).
3. Infer their implicit goals (隐性目标 - potential needs, motivations).
4. Identify potential conflicts (利益冲突).
5. Assign a confidence score (High/Medium/Low) to the inferred implicit goals.

{format_instructions}
""",
            input_variables=["context_summary", "meta_insights"],
            partial_variables={"format_instructions": parser.get_format_instructions()},
        )

        chain_inputs = {
            "context_summary": json.dumps(deconstruction_raw, indent=2),
            "meta_insights": json.dumps(meta_analysis_raw, indent=2)
        }

        chain = prompt | self.default_llm | parser
        result: StakeholderMap = await self.invoke_chain(chain, chain_inputs)

        return {"stakeholder_map": result.model_dump()}

    async def handle_request_stakeholder_validation(self, state: ReasoningGraphState) -> Dict[str, Any]:
        self.logger.info("Executing Node 1.1-HITL-C-Request: Stakeholder Implicit Goal Validation (VARL).")

        # Access inputs
        stakeholder_map_raw = state["node_results"]["1.1-RP4"]["stakeholder_map"]
        stakeholder_map = StakeholderMap.model_validate(stakeholder_map_raw)

        # Prepare VARL items (focusing on implicit goals)
        items_to_review = []
        for stakeholder in stakeholder_map.stakeholders:
            if stakeholder.implicit_goals: # Only review stakeholders where implicit goals were inferred
                content_data = f"**Stakeholder:** {stakeholder.name}\n\n"
                content_data += "**Inferred Implicit Goals (隐性目标):**\n" + "\n".join(f"- {g}" for g in stakeholder.implicit_goals) + "\n\n"
                content_data += "**Potential Conflicts (利益冲突):**\n" + "\n".join(f"- {c}" for c in stakeholder.potential_conflicts)

                items_to_review.append(ContentBlock(
                    content_id=stakeholder.stakeholder_id,
                    content_type="text/markdown",
                    data=content_data,
                    ai_confidence=stakeholder.ai_confidence_implicit_goals
                ))

        if not items_to_review:
            self.logger.info("No implicit stakeholder goals identified. Skipping VARL interaction.")
            return {"varl_skipped": True}

        # Construct VARL Payload (Pattern 3)
        varl_payload = VARL_Input(
            instruction="理解复杂的隐性目标需要高度的社会政治敏感度 (Understanding complex implicit goals requires high socio-political sensitivity). Please review the inferred implicit goals. Approve or Reject and provide feedback if the analysis seems unrealistic or misses key nuances.",
            items_to_review=items_to_review
        )

        interaction_record = HITL_InteractionRecord(
            interaction_id=str(uuid4()),
            interaction_specific_id="1.1-C",
            mode="VARL",
            workflow_step_id=self.step_definition.id,
            timestamp_start=datetime.now(timezone.utc),
            ai_presentation=varl_payload,
            autonomy_profile_active=state["chassis_context"]["autonomy_profile"].profile_name,
        )

        return {"pending_interactions": [interaction_record], "varl_skipped": False}

    async def handle_process_stakeholder_validation(self, state: ReasoningGraphState) -> Dict[str, Any]:
        self.logger.info("Executing Node 1.1-HITL-C-Process: Processing Stakeholder Validation (Refiner Pattern).")

        # Access original map
        stakeholder_map_raw = state["node_results"]["1.1-RP4"]["stakeholder_map"]
        stakeholder_map = StakeholderMap.model_validate(stakeholder_map_raw)

        # Check if VARL was skipped
        if state["node_results"]["1.1-HITL-C-Request"].get("varl_skipped", False):
            self.logger.info("VARL interaction was skipped. Proceeding with original map.")
            # Return both the internal refined map and the SOP Output 2
            return {"refined_stakeholder_map": stakeholder_map.model_dump(), "Stakeholder Map": stakeholder_map.model_dump()}

        # Process HITL Feedback (Pattern 4)
        interaction = self._find_interaction(state, "1.1-C")
        
        rejections = self._process_varl_decision(interaction)

        if not rejections:
            # Approved or Bypassed
            return {"refined_stakeholder_map": stakeholder_map.model_dump(), "Stakeholder Map": stakeholder_map.model_dump()}

        # If there are rejections, use LLM (Refiner Pattern) to refine the stakeholder map
        self.logger.info(f"Refining {len(rejections)} stakeholder analyses based on feedback.")

        prompt = PromptTemplate(
            template="""
Refine the Stakeholder Map based on expert feedback (Rejections).

Original Stakeholder Map (JSON):
{original_map}

Rejected Items and Feedback (JSON):
{feedback}

Instructions:
1. Revise the stakeholders corresponding to the rejected items using the feedback provided (e.g., addressing reasons like "不符合常识" or "遗漏关键因素").
2. Maintain the structure of the StakeholderMap, updating only the relevant stakeholders.

{format_instructions}
""",
            input_variables=["original_map", "feedback"],
            partial_variables={"format_instructions": PydanticOutputParser(pydantic_object=StakeholderMap).get_format_instructions()},
        )
        
        # Ensure feedback is serialized correctly
        serialized_feedback = [item.model_dump() if hasattr(item, 'model_dump') else item for item in rejections]

        chain_inputs = {
            "original_map": json.dumps(stakeholder_map_raw, indent=2),
            "feedback": json.dumps(serialized_feedback, indent=2)
        }

        chain = prompt | self.default_llm | PydanticOutputParser(pydantic_object=StakeholderMap)
        refined_map: StakeholderMap = await self.invoke_chain(chain, chain_inputs)

        return {"refined_stakeholder_map": refined_map.model_dump(), "Stakeholder Map": refined_map.model_dump()}

    # --- Convergence and Finalization ---

    async def handle_information_gap_analysis(self, state: ReasoningGraphState) -> Dict[str, Any]:
        self.logger.info("Executing Node 1.1-RP5: Information Gap Analysis.")

        # Access refined inputs from both tracks (A and B)
        deconstruction_raw = state["node_results"]["1.1-RP1"]["semantic_deconstruction"]
        refined_mechanism_raw = state["node_results"]["1.1-HITL-B-Process"]["refined_mechanism"]
        refined_stakeholders_raw = state["node_results"]["1.1-HITL-C-Process"]["refined_stakeholder_map"]

        # LLM Invocation (Pattern 2)
        parser = PydanticOutputParser(pydantic_object=InformationGapAnalysisReport)
        prompt = PromptTemplate(
            template="""
Perform an Information Gap Analysis (信息差识别与知识缺口定位). Compare the information REQUIRED to build a robust model against the information PROVIDED.

Information REQUIRED (Refined Mechanisms JSON):
{required_mechanisms}
Information REQUIRED (Refined Stakeholders JSON):
{required_stakeholders}

Information PROVIDED (Deconstruction JSON):
{provided_information}

Tasks:
1. Identify specific knowledge gaps (missing parameters, unclear details).
2. Assess the importance (Critical/High/Medium/Low).
3. Propose an action (Assume, Research, or Sensitivity Analysis).

{format_instructions}
""",
            input_variables=["required_mechanisms", "required_stakeholders", "provided_information"],
            partial_variables={"format_instructions": parser.get_format_instructions()},
        )

        chain_inputs = {
            "required_mechanisms": json.dumps(refined_mechanism_raw, indent=2),
            "required_stakeholders": json.dumps(refined_stakeholders_raw, indent=2),
            "provided_information": json.dumps(deconstruction_raw, indent=2)
        }

        chain = prompt | self.default_llm | parser
        result: InformationGapAnalysisReport = await self.invoke_chain(chain, chain_inputs)

        # Output 4 of the SOP
        return {"Information Gap Analysis Report": result.model_dump()}

    async def handle_synthesis(self, state: ReasoningGraphState) -> Dict[str, Any]:
        self.logger.info("Executing Node 1.1-Synthesis: Synthesizing Background & Mechanism Analysis Brief.")

        # Access all key results from the step
        deconstruction_raw = state["node_results"]["1.1-RP1"]["semantic_deconstruction"]
        refined_mechanism_raw = state["node_results"]["1.1-HITL-B-Process"]["refined_mechanism"]
        meta_analysis_raw = state["node_results"]["1.1-RP6"]["meta_analysis"]
        selected_paradigm_raw = state["node_results"]["1.1-HITL-A-Process"]["selected_paradigm"]

        # LLM Invocation for Synthesis (Pattern 2)
        parser = PydanticOutputParser(pydantic_object=BackgroundMechanismAnalysisBrief)
        prompt = PromptTemplate(
            template="""
Synthesize a comprehensive Background & Mechanism Analysis Brief (背景与机制分析简报). This document is the foundational understanding of the problem. It must be precise, coherent, and integrate all validated insights.

Source Materials (JSON):
1. Semantic Deconstruction (Context, Intent): {deconstruction}
2. Validated Core Mechanisms (主导机制): {mechanism}
3. Selected Modeling Paradigm: {paradigm}
4. Meta-Analysis (Reviewer Expectations): {meta_analysis}

Structure the Brief:
- Executive Summary
- Core Phenomena (核心现象)
- Dominant Mechanisms (主导机制 - incorporating expert feedback)
- Standardized Terminology (标准化术语)
- System Boundary

{format_instructions}
""",
            input_variables=["deconstruction", "mechanism", "paradigm", "meta_analysis"],
            partial_variables={"format_instructions": parser.get_format_instructions()},
        )

        chain_inputs = {
            "deconstruction": json.dumps(deconstruction_raw, indent=2),
            "mechanism": json.dumps(refined_mechanism_raw, indent=2),
            "paradigm": json.dumps(selected_paradigm_raw, indent=2),
            "meta_analysis": json.dumps(meta_analysis_raw, indent=2),
        }

        chain = prompt | self.default_llm | parser
        result: BackgroundMechanismAnalysisBrief = await self.invoke_chain(chain, chain_inputs)

        return {"analysis_brief": result.model_dump()}

    async def handle_request_brief_approval(self, state: ReasoningGraphState) -> Dict[str, Any]:
        self.logger.info("Executing Node 1.1-HITL-D-Request: Background Analysis Brief Approval (VARL Milestone).")

        # Access synthesized brief
        brief_raw = state["node_results"]["1.1-Synthesis"]["analysis_brief"]
        brief = BackgroundMechanismAnalysisBrief.model_validate(brief_raw)

        # Format the brief for presentation (Markdown)
        brief_content = f"# 背景与机制分析简报 (Background & Mechanism Analysis Brief)\n\n"
        brief_content += f"## Executive Summary\n{brief.executive_summary}\n\n"
        brief_content += f"## Core Phenomena (核心现象)\n{brief.core_phenomena}\n\n"
        brief_content += f"## Dominant Mechanisms (主导机制)\n{brief.dominant_mechanisms}\n\n"
        brief_content += f"## System Boundary\n{brief.system_boundary}\n\n"
        brief_content += f"## Standardized Terminology (标准化术语)\n"
        for term, definition in brief.standardized_terminology.items():
            brief_content += f"- **{term}**: {definition}\n"

        # Construct VARL Payload (Pattern 3)
        item_to_review = ContentBlock(
            content_id="analysis_brief_v1",
            content_type="text/markdown",
            data=brief_content,
            ai_confidence=ConfidenceScore.HIGH # High confidence as it integrates previous human feedback
        )

        varl_payload = VARL_Input(
            instruction="关键结果流转审核 (Milestone Approval - Go/No-Go): Please review the final Brief. This is the foundation for the project. Approve (Go) to proceed to Step 1.2, or Reject (No-Go) if fundamental revisions are required.",
            items_to_review=[item_to_review]
        )

        interaction_record = HITL_InteractionRecord(
            interaction_id=str(uuid4()),
            interaction_specific_id="1.1-D",
            mode="VARL",
            workflow_step_id=self.step_definition.id,
            timestamp_start=datetime.now(timezone.utc),
            ai_presentation=varl_payload,
            autonomy_profile_active=state["chassis_context"]["autonomy_profile"].profile_name,
        )

        return {"pending_interactions": [interaction_record]}

    async def handle_process_brief_approval(self, state: ReasoningGraphState) -> Dict[str, Any]:
        self.logger.info("Executing Node 1.1-HITL-D-Process: Processing Brief Approval and Finalizing Outputs.")

        # Process HITL Feedback (Pattern 4)
        interaction = self._find_interaction(state, "1.1-D")
        
        rejections = self._process_varl_decision(interaction)

        if rejections:
            # Handle Rejection (No-Go)
            # Assuming only one item was reviewed
            feedback = rejections[0].reason_text or rejections[0].reason_tag or "No detailed feedback provided."
            self.logger.error(f"Milestone 1.1 rejected by human expert. Feedback: {feedback}")
            # Fail the step if rejected.
            return {
                "status": ExecutionStatus.FAILED,
                "error_message": f"Step 1.1 Milestone rejected by human expert (No-Go). Feedback: {feedback}"
            }

        # If Approved (Go decision) or Bypassed
        self.logger.info("Milestone 1.1 Approved. Finalizing step outputs.")

        # Gather all final outputs required by the SOP from previous nodes
        # Output 1: Background & Mechanism Analysis Brief
        brief = state["node_results"]["1.1-Synthesis"]["analysis_brief"]
        
        # Output 2: Stakeholder Map (already finalized in 1.1-HITL-C-Process)
        # We access the specific "Stakeholder Map" key generated by that node.
        stakeholder_map = state["node_results"]["1.1-HITL-C-Process"]["Stakeholder Map"]
        
        # Output 3: Domain Paradigm Reference List (already finalized in 1.1-HITL-A-Process)
        paradigm_list = state["node_results"]["1.1-HITL-A-Process"]["Domain Paradigm Reference List"]
        
        # Output 4: Information Gap Analysis Report (already finalized in 1.1-RP5)
        info_gap_report = state["node_results"]["1.1-RP5"]["Information Gap Analysis Report"]

        # Return keys MUST match the SOP Output ports exactly
        return {
            "Background & Mechanism Analysis Brief": brief,
            "Stakeholder Map": stakeholder_map,
            "Domain Paradigm Reference List": paradigm_list,
            "Information Gap Analysis Report": info_gap_report
        }

    # ================================================================================
    # 4. Utility Methods for HITL Processing
    # These helpers ensure robust processing of HITL interactions, handling bypasses
    # and different data representations (dict vs object).
    # ================================================================================

    def _find_interaction(self, state: ReasoningGraphState, interaction_specific_id: str) -> HITL_InteractionRecord:
        """Helper to find a resolved interaction in the history and return it as a validated HITL_InteractionRecord."""
        resolved_interaction = None
        for i in state.get("interaction_history", []):
            # Handle both dictionary (serialized) and object representations
            specific_id = None
            if isinstance(i, dict):
                specific_id = i.get("interaction_specific_id")
            elif hasattr(i, "interaction_specific_id"):
                specific_id = i.interaction_specific_id

            if specific_id == interaction_specific_id:
                # Ensure we return a validated Pydantic object
                if isinstance(i, HITL_InteractionRecord):
                    resolved_interaction = i
                else:
                    resolved_interaction = HITL_InteractionRecord.model_validate(i)
                break

        if not resolved_interaction:
            raise BLEExecutionError(f"Critical HITL interaction '{interaction_specific_id}' not found in history.")
        return resolved_interaction

    def _process_sca_decision(self, interaction: HITL_InteractionRecord) -> tuple[str, str]:
        """Helper to process SCA decisions, handling human input and bypass."""
        decision = interaction.human_input
        selected_id = None
        rationale = ""

        is_valid_sca_decision = False
        if decision:
            # Validate decision type (handles Pydantic/Mock compatibility)
            if (PYDANTIC_AVAILABLE and isinstance(decision, SCA_Output)) or (hasattr(decision, 'mode') and decision.mode == "SCA"):
                 is_valid_sca_decision = True

        if is_valid_sca_decision:
             selected_id = decision.selected_option_id
             rationale = decision.strategic_rationale or "Human expert selection."
        elif interaction.was_bypassed:
            self.logger.info(f"Interaction {interaction.interaction_specific_id} was bypassed. Using AI recommendation.")
            ai_presentation = interaction.ai_presentation
            # Robust access to recommendation ID
            if ai_presentation and hasattr(ai_presentation, 'ai_recommendation_id'):
                selected_id = ai_presentation.ai_recommendation_id
                rationale = f"Bypassed: {interaction.bypass_reason or 'N/A'}"
            else:
                raise BLEExecutionError(f"HITL interaction {interaction.interaction_specific_id} bypassed but AI recommendation is missing or inaccessible.")
        else:
            raise BLEExecutionError(f"HITL interaction {interaction.interaction_specific_id} did not resolve with valid SCA output or bypass.")

        if not selected_id:
             raise BLEExecutionError(f"Could not determine the selected option ID from HITL {interaction.interaction_specific_id}.")

        return selected_id, rationale

    def _process_eki_decision(self, interaction: HITL_InteractionRecord) -> List[dict]:
        """Helper to process EKI decisions. Returns list of responses (as dicts) or empty list if bypassed."""
        decision = interaction.human_input
        responses = []
        is_valid_eki_decision = False
        if decision:
            if (PYDANTIC_AVAILABLE and isinstance(decision, EKI_Output)) or (hasattr(decision, 'mode') and decision.mode == "EKI"):
                 is_valid_eki_decision = True

        if is_valid_eki_decision:
            if hasattr(decision, 'responses'):
                # Ensure responses are serializable (dicts) for the upcoming LLM input
                responses = [r.model_dump() if hasattr(r, 'model_dump') else r for r in decision.responses]
        elif interaction.was_bypassed:
             self.logger.info(f"Interaction {interaction.interaction_specific_id} (EKI) was bypassed.")
             return []
        else:
             raise BLEExecutionError(f"HITL interaction {interaction.interaction_specific_id} did not resolve with valid EKI output or bypass.")

        return responses

    def _process_varl_decision(self, interaction: HITL_InteractionRecord) -> List[VARL_Item_Output]:
        """Helper to process VARL decisions. Returns the list of rejected items or empty list if bypassed/approved."""
        decision = interaction.human_input
        is_valid_varl_decision = False
        if decision:
            if (PYDANTIC_AVAILABLE and isinstance(decision, VARL_Output)) or (hasattr(decision, 'mode') and decision.mode == "VARL"):
                 is_valid_varl_decision = True

        if is_valid_varl_decision:
            # Ensure we are working with a validated object
            if isinstance(decision, dict):
                varl_output = VARL_Output.model_validate(decision)
            else:
                varl_output = decision
                
            rejections = [item for item in varl_output.decisions if item.decision == VARL_Decision.REJECT]
            return rejections
        elif interaction.was_bypassed:
             self.logger.info(f"Interaction {interaction.interaction_specific_id} (VARL) was bypassed.")
             return []
        else:
             raise BLEExecutionError(f"HITL interaction {interaction.interaction_specific_id} did not resolve with valid VARL output or bypass.")