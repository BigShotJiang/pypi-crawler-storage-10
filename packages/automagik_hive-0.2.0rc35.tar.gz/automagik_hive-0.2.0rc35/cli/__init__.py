"""Automagik Hive CLI - Simple 8-command interface."""

__version__ = "0.1.0a61"

from .main import main

__all__ = ["main"]
