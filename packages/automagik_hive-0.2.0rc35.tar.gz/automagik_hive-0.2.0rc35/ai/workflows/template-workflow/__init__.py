"""Template workflow for multi-step processing."""

__version__ = 1
