import os
import serial
import webbrowser

port = None  
com_base = 'COM1'
commands = ["connect", "disconnect", "clean", "send", "help", "github", "close"]
commands_help = [
    "",
    "connect [port]     - Connect your device to the specified port",
    "disconnect         - Disconnect your device from the active port",
    "clean              - Clear the terminal screen",
    "send [command]     - Send a command to your device",
    "github             - Open Sugar's GitHub page",
    "help               - Show this list of commands",
    "close              - Exit the Sugar interface",
    "",
]

def clean():
    os.system('cls' if os.name == 'nt' else 'clear')

def connect(com=com_base):
    global port
    print("Sugar is waking up...")
    try:
        port = serial.Serial(com, baudrate=9600, timeout=1)
        print("Connection established. Let's get cozy!")
    except serial.SerialException as e:
        print("Oh no, something went wrong while connecting:", e)

def disconnect():
    global port
    print("Sugar is going to sleep now...")
    if port and port.is_open:
        port.close()
        print("Disconnected gently.")
    else:
        print("There's no active connection to close.")

def send(command):
    if port and port.is_open:
        port.write(command.encode())  
        print("Command sent with care:", command)
    else:
        print("No active connection. Sugar can't send anything yet.")

def cli():
    print("Welcome to Sugar your sweet serial companion.")
    print("Type 'help' if you ever feel lost.")
    while True:
        line = input("Sugar > ").strip()
        
        if line.startswith("connect"):
            parts = line.split()
            if len(parts) > 1:
                connect(parts[1])
            else:
                connect()

        elif line.startswith("disconnect"):
            disconnect()

        elif line.startswith("clean"):
            clean()

        elif line.startswith("send"):
            if port and port.is_open:
                command = line[len("send "):]
                send(command)
            else:
                print("No active connection. Sugar is waiting patiently.")

        elif line.startswith("help"):
            for help_commands in commands_help:
                print(help_commands)

        elif line.startswith("github"):
            print("Opening Sugar's GitHub page in your browser...")
            webbrowser.open("https://github.com/renpyuser/sugar")

        elif line.startswith("close"):
            disconnect()
            print("Sugar is closing now. Take care!")
            break

        else:
            print("Hmm... I didn't understand that. Try 'help' if you're unsure.")


