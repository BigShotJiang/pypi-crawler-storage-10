import os
from contextlib import contextmanager
from contextvars import ContextVar
import torch
import torch.distributed as dist
from typing import Callable

# Assume availability of torch CP and DTensor
from torch.distributed.tensor.experimental import context_parallel as _torch_context_parallel  # type: ignore
from torch.distributed._tensor import DTensor, Shard  # type: ignore


_cp_ctx: ContextVar = ContextVar("discumsum_cp_ctx", default=None)

class CPDiscumsum(torch.autograd.Function):
    @staticmethod
    def forward(ctx, X: torch.Tensor, log_G: torch.Tensor, pg, base_discumsum_fn: Callable[[torch.Tensor, torch.Tensor], torch.Tensor]):
        """Ring-style forward with intra-group communication; saves tensors for backward."""
        # Group size/rank from the provided process group (cp dimension only)
        group_world_size = dist.get_world_size(pg) if pg is not None else dist.get_world_size()
        group_rank = dist.get_rank(pg) if pg is not None else dist.get_rank()
        ctx.pg = pg
        # Save base function for recompute-based backward
        ctx.base_discumsum_fn = base_discumsum_fn
        # Assume multi-process ring (no single-rank fastpath)
        time_dim = 1

        def get_last(A: torch.Tensor) -> torch.Tensor:
            return A.narrow(time_dim, A.shape[time_dim] - 1, 1)

        if group_rank == 0:
            Y = base_discumsum_fn(X, log_G)
            ctx.X, ctx.log_G = X, log_G
        else:
            src_rank = group_rank - 1
            first_X = torch.empty([X.shape[0], 1] + list(X.shape[2:]), dtype=X.dtype, device=X.device)
            first_X.requires_grad_(True)
            dist.recv(first_X, src=src_rank, group=pg)
            _X = torch.cat([first_X, X], dim=time_dim)
            _log_G = torch.cat([torch.zeros_like(get_last(log_G)), log_G], dim=time_dim)
            _Y = base_discumsum_fn(_X, _log_G)
            Y = _Y.narrow(time_dim, 1, _Y.shape[time_dim] - 1)
            ctx.X, ctx.log_G = _X, _log_G

        if group_rank < group_world_size - 1:
            dst_rank = group_rank + 1
            last_y = get_last(Y).detach().contiguous()
            dist.send(last_y, dst=dst_rank, group=pg)

        return Y

    @staticmethod
    def backward(ctx, dY: torch.Tensor):
        pg = ctx.pg
        # Determine CP rank and world size in the provided process group
        group_world_size = dist.get_world_size(pg) if pg is not None else dist.get_world_size()
        group_rank = dist.get_rank(pg) if pg is not None else dist.get_rank()

        X, log_G = ctx.X, ctx.log_G
        time_dim = 1

        # Receive gradient seed from next rank (reverse ring)
        if group_rank < group_world_size - 1:
            last_dY = torch.empty_like(dY.narrow(time_dim, 0, 1))
            dist.recv(last_dY, src=group_rank + 1, group=pg)
            dY = dY.clone()
            dY[:,-1:] += last_dY

        if group_rank > 0:
            dY = torch.cat([torch.zeros_like(dY.narrow(time_dim, 0, 1)), dY], dim=time_dim)

        base_fn = ctx.base_discumsum_fn

        X_b = X.detach().requires_grad_(True)
        log_G_b = log_G.detach().requires_grad_(True)

        Y_b = base_fn(X_b, log_G_b)

        # Avoid re-entrant backward; use autograd.grad on the recomputed local graph
        from retention._discumsum.triton import discumsum_bwd_triton
        dX, dlog_G = discumsum_bwd_triton(dY, Y_b, log_G_b)

        get_first = lambda A: A.narrow(time_dim, 0, 1)
        remove_first = lambda A: A.narrow(time_dim, 1, A.shape[time_dim] - 1)

        if group_rank > 0:
            first_dX = get_first(dX).detach() * torch.exp(get_first(log_G_b)).detach()[...,None]
            first_dX = first_dX.contiguous()
            dist.send(first_dX, dst=group_rank - 1, group=pg)
            dX, dlog_G = remove_first(dX), remove_first(dlog_G)

        return dX, dlog_G, None, None

@contextmanager
def context_parallel(device_mesh, buffers=(), buffer_seq_dims=()):
    """
    Context manager that mirrors torch's context_parallel interface and, when active,
    enables the `maybe_context_parallel` decorator to switch to the distributed
    implementation using the process group from `device_mesh`.
    """
    # Enter torch context_parallel to shard buffers and activate the distributed ring attention
    torch_cp_cm = _torch_context_parallel(device_mesh, buffers=buffers, buffer_seq_dims=buffer_seq_dims)
    pg = device_mesh.get_group() if hasattr(device_mesh, "get_group") else None
    token = _cp_ctx.set({"device_mesh": device_mesh, "pg": pg})
    try:
        with torch_cp_cm:
            yield
    finally:
        _cp_ctx.reset(token)


def maybe_context_parallel(base_discumsum_fn):
    """
    Decorator for discumsum implementations. When a context_parallel
    is active, route the call to the distributed implementation along the
    context's process group; otherwise call the base function.
    """
    def _wrapped(X: torch.Tensor, log_G: torch.Tensor):
        ctx = _cp_ctx.get()
        if not ctx:
            return base_discumsum_fn(X, log_G)
        pg = ctx.get("pg")

        # Allow DTensor inputs by unwrapping to locals and rewrapping output
        x_is_dtensor = isinstance(X, DTensor)
        if x_is_dtensor:
            Y_local = CPDiscumsum.apply(X.to_local(), log_G.to_local(), pg, base_discumsum_fn)
            return DTensor.from_local(Y_local, X.device_mesh, placements=[Shard(1)])
        return CPDiscumsum.apply(X, log_G, pg, base_discumsum_fn)

    return _wrapped
