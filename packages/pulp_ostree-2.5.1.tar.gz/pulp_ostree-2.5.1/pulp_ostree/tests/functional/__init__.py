"""Tests for ostree plugin."""
