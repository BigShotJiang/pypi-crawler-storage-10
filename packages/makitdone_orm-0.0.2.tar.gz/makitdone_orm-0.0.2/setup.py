from setuptools import setup

setup(
    name='makitdone-orm',
    version='0.0.2',
    packages=[
        'makit.orm',
        'makit.orm.db',
        'makit.orm.samples',
        'makit.orm.tests'
    ],
    namespace_package=['makit', 'makit.orm'],
    install_requires=[
        'aiomysql~=0.2.0',
        'PyMySQL~=1.1.1',
        'logzero~=1.7.0',
        'makitdone-lib~=2.0.1'
    ],
    python_requires='>=3.11',
    url='https://gitee.com/makitdone/makitdone-orm',
    license='MIT',
    author='liangchao',
    author_email='liang20201101@163.com',
    description='python orm框架，目前仅支持MySql'
)
