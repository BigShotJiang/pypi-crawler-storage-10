from setuptools import setup, find_packages

setup(
    name="csml",                     # Package name
    version="0.1.0",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "csml": ["best.csv"],        # Include CSV in package
    },
    install_requires=[
        "pandas",
    ],
    description="ML package with a CSV file",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Your Name",
    url="https://github.com/yourusername/ml",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.8',
)
