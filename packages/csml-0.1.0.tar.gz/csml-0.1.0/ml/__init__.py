import pkgutil
import io
import pandas as pd

def get_data():
    data_bytes = pkgutil.get_data(__name__, "best.csv")
    if data_bytes is None:
        raise FileNotFoundError("best.csv not found in package")
    return pd.read_csv(io.BytesIO(data_bytes))
