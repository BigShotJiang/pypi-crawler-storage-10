"""
Math Bridge - Biblioteka matematyczna
Wersja: 1.0.0
"""

from .core import MathBridge

__version__ = "1.0.0"
__author__ = "bartosz radomski"
__email__ = "twoj@email.com"
__all__ = ["MathBridge"]