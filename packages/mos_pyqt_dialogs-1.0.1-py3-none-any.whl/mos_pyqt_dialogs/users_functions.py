import logging
import subprocess


def get_current_user_on_x() -> str:
    """
    Получение текущего пользователя с графической сессией
    @return: строка с именем пользователя. Если ни у одного пользователя не запущена X-сессия, возвращает root
    """
    try:
        loginctl_lines = subprocess.run(['loginctl'], capture_output=True).stdout.decode().split('\n')
        tty_session_ids = dict()
        headers = loginctl_lines[0].strip().split()
        uid_index = headers.index('UID')
        tty_index = headers.index('TTY')
        user_index = headers.index('USER')
        for line in loginctl_lines[1:]:
            if len(line.strip().split()) != len(headers):
                continue
            if len(line.strip().split()) > 0 and 'tty' in line.strip().split()[tty_index] and \
                    int(line.strip().split()[uid_index]) >= 500:
                tty_session_ids[line.strip().split()[0]] = line.strip().split()[user_index]
        for session_id in tty_session_ids.keys():
            session_status = subprocess.run(f'loginctl show-session --property Active --value {session_id}',
                                            shell=True, capture_output=True).stdout.decode().strip()
            if session_status == 'yes':
                return tty_session_ids[session_id]
    except Exception as e:
        logging.info(f'Не удалось определить текущего пользователя. Исключение: {e}. Установлен root.')
        return 'root'
    loginctl_lines = "\n".join(loginctl_lines)
    logging.info(f'Активные сессии не найдены. Вывод loginctl: {loginctl_lines}. Установлен root.')
    return 'root'
