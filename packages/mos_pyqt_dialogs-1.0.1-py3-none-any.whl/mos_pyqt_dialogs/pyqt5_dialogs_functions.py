from PyQt5.QtWidgets import QMessageBox


def alert(message='', title='Внимание!', console_mode=False):
    """
    Вывод предупреждающего диалогового окна
    :param message: сообщение для вывода
    :param title: заголовок окна
    :param console_mode: если True, сообщение выводится в консоль
    """
    if console_mode:
        print(message)
    else:
        dlg = QMessageBox()
        dlg.setWindowTitle(title)
        dlg.setText(message)
        dlg.exec()


def question(message='', title='Внимание!', console_mode=False):
    """
    Возвращает True, если нажали на Ok, иначе False
    :param console_mode: если True, вопрос выводится в консоль и функция возвращает True при нажатии y/д
    :param message: текст вопроса
    :param title: заголовок окна
    :return: True если нажали Ok, иначе False
    """
    if not console_mode:
        dlg = QMessageBox()
        dlg.setWindowTitle(title)
        dlg.setText(message)

        dlg.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
        dlg.button(QMessageBox.Ok).setText('Ок')
        dlg.button(QMessageBox.Cancel).setText('Отмена')
        return dlg.exec() == QMessageBox.Ok
    else:
        return input(message + '\n').strip().lower() in ('y', 'д')
