import logging
from datetime import datetime, timedelta


def reset_log_to_last_n_days(log_file: str, n: int = 7) -> None:
    """
    Удаляет все записи лога, кроме последних n дней
    @rtype: None
    :param log_file: имя лог-файла
    :param n: количество дней, за которые нужно оставить записи лога (7 по умолчанию)
    """

    if n < 1:
        logging.warning(f'Функция очистки лога должна оставить хотя бы 1 день, передан параметр {n}')
        return
    try:
        with open(log_file) as inp:
            lines = inp.readlines()
    except Exception as e:
        logging.warning(f'Возникла ошибка при очистке лог-файла: {e}')
        return
    first_date_to_keep_log = datetime.today() - timedelta(n)
    first_line = -1
    for i in range(len(lines)):
        lines[i] = lines[i].strip()

    for i in range(len(lines)):
        try:
            date = datetime.strptime(lines[i].split()[0], "%Y-%m-%d")
        except Exception:
            continue

        if date.date() >= first_date_to_keep_log.date():
            first_line = i
            break
    if first_line == -1:
        first_line = len(lines)

    lines = lines[first_line:]
    while '' in lines:
        lines.remove('')
    while '\n' in lines:
        lines.remove('\n')
    with open(log_file, 'w') as out:
        print(*lines, file=out, sep='\n')
