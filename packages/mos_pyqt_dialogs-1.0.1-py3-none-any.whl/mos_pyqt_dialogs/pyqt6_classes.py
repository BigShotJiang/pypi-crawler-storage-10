import subprocess

from PyQt6.QtCore import QThread, pyqtSignal, QObject
from PyQt6.QtWidgets import QMessageBox

from python3_mos_pyqt_dialogs.pyqt6_dialogs_functions import alert


class ThreadWorkerWithShellCommand(QObject):
    error_signal = pyqtSignal(str)
    start_signal = pyqtSignal()
    success_signal = pyqtSignal()
    finished = pyqtSignal()

    def __init__(self, command=''):
        """
        Класс для работы команды shell в отдельном потоке QThread
        :param command: команда в формате shell. Если не передаётся, то после вызова назначается как атрибут класса
        """
        super().__init__()
        if command:
            self.command = command

    def run(self):
        self.start_signal.emit()
        command = subprocess.run(self.command, shell=True, capture_output=True)
        retcode = command.returncode
        if retcode != 0:
            self.error_signal.emit(command.stdout.decode())
        else:
            self.success_signal.emit()
        self.finished.emit()


def wait_alert_box(
        command: str,
        self=None,
        process_message: str = 'Подождите, идёт установка...',
        success_message: str = 'Успешно',
        console_mode=False,
        additional_function_on_success=None
):
    """
    Установка программы без замораживания интерфейса (в новом потоке) с выводом информации в диалоговое окно
    :param additional_function_on_success: дополнительная функция, которую нужно вызвать при успешном завершении потока
    :param console_mode: если True, сообщения выводятся в консоль
    :param process_message: сообщение при работе
    :param success_message: сообщение при успешном выполнении
    :param self: объект, для которого вызывается окно
    :param command: команда для выполнения в режиме shell
    """
    try:
        self.thread = QThread()
        self.worker = ThreadWorkerWithShellCommand()

        if not console_mode:
            self.wait_alert_box = QMessageBox()
            self.wait_alert_box.setWindowTitle('Внимание!')
            self.wait_alert_box.setText(process_message)
            self.wait_alert_box.setStandardButtons(QMessageBox.StandardButton.Ok)
            self.wait_alert_box.buttons()[0].setEnabled(False)
            self.worker.start_signal.connect(lambda: self.wait_alert_box.exec())
            self.thread.finished.connect(lambda: self.wait_alert_box.close())

        self.worker.command = command
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.finished.connect(self.worker.deleteLater)
        self.worker.finished.connect(self.thread.quit)
        self.thread.finished.connect(self.thread.deleteLater)
        self.worker.error_signal.connect(
            lambda message: alert(message=f'Возникла ошибка: {message}', console_mode=console_mode))
        self.worker.success_signal.connect(
            lambda: alert(message=success_message, console_mode=console_mode))
        if additional_function_on_success:
            self.worker.success_signal.connect(additional_function_on_success)
        self.thread.start()

    except Exception as e:
        alert(message=f'Возникла ошибка: {e}', console_mode=console_mode)
