# Copyright 2025 Cotality
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from __future__ import annotations

import panel as pn

from ....core.locales import keys
from ...base.base_app import BaseApp


def display(app: BaseApp):
    """Select the input table for the Clip Lookup Panel app.
    Args:
        platform (Platform): The platform instance.
    """

    main_title = pn.pane.Markdown(
        f"# {app._(keys.TEXT_ADD_INPUT_TABLE_DIALOG)}", sizing_mode="stretch_width"
    )

    table_name = pn.widgets.TextInput(
        name=app._(keys.TEXT_SECRET_USERNAME), sizing_mode="stretch_width"
    )

    create_button = pn.widgets.Button(
        name=app._(keys.BUTTON_CREATE_TABLE_DIALOG),
        button_type="primary",
        sizing_mode="stretch_width",
    )

    def create(event):
        validation = validate_input_table_name(app, table_name.value)
        if not validation:
            save_output.object = "bla bla"
            return

        secret_client = app.platform.secret_client
        response = secret_client.save_digital_gateway_credential(
            username.value, password.value
        )

    create_button.on_click(create)


def validate_input_table_name(app: StreamlitBaseApp, table_name: str) -> bool:
    """Validate the input table name.

    Args:
        table_name (str): The name of the input table.

    Returns:
        bool: True if valid, False otherwise.
    """
    # table_name = table_name.strip().lower()
    # if len(table_name.strip()) == 0:
    #     st_utils.error(
    #         level=st_utils.MessageLevel.USER_ERROR,
    #         message=app._(keys.ERROR_INPUT_TABLE_REQUIRED),
    #         inplace=True,
    #     )
    #     return False
    # if len(table_name.split(" ")) > 1:
    #     st_utils.error(
    #         level=st_utils.MessageLevel.USER_ERROR,
    #         message=app._(keys.ERROR_INPUT_TABLE_HAS_SPACES),
    #         inplace=True,
    #     )
    #     return False
    #
    # if not re.match("^[a-zA-Z]$", table_name[0]):
    #     st_utils.error(
    #         level=st_utils.MessageLevel.USER_ERROR,
    #         message=app._(keys.ERROR_INPUT_TABLE_FIRST_CHAR),
    #         inplace=True,
    #     )
    #     return False
    #
    # if len(table_name) < 4:
    #     st_utils.error(
    #         level=st_utils.MessageLevel.USER_ERROR,
    #         message=app._(keys.ERROR_INPUT_TABLE_MIN_LENGHT),
    #         inplace=True,
    #     )
    #     return False
    #
    # if not re.match(r"^[a-zA-Z][\w_]{3,}$", table_name):
    #     st_utils.error(
    #         level=st_utils.MessageLevel.USER_ERROR,
    #         message=app._(keys.ERROR_INPUT_TABLE_INVALID_CHARS),
    #         inplace=True,
    #     )
    #     return False
    #
    return True

    return pn.Column(
        main_title,
        subtitle,
        # username ,
        # password ,
        # save_button,
        # save_output,
        # sizing_mode="stretch_width",
        # css_classes=['secrets-wrapper']
    )

    # with st.container(key="input-container"):
    #     st.subheader(app._(keys.TEXT_NO_INPUT_TABLES_CREATED))
    #     st.write(app._(keys.TEXT_ADD_INPUT_TABLE_INTRO))
    #
    #     if st.button(label=app._(keys.BUTTON_CREATE_TABLE), key=keys.BUTTON_CREATE_TABLE):
    #         display_dialog_create_table(app)
