## cdf 

### Changed

- [alpha] The command `cdf data purge instances` now expects the view to
be specified as a single string with the format
`space:externalId/version` instead of the list format `space externalId
version`. This is to be consistent with how views are specified in the
`cdf migrate commands`.

## templates

No changes.