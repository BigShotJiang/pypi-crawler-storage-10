"""
Project website: https://bitbucket.org/yymao/helpers
Copyright (c) 2015-2025 Yao-Yuan Mao (yymao)
"""

from setuptools import setup

setup(
    name='yymao-helpers',
    version='1.0.0',
    description='A collection of some useful, but not necessarily related, Python scripts that carry out or accelerate various tasks, most of which involve dark matter simulations.',
    url='https://bitbucket.org/yymao/helpers',
    author='Yao-Yuan Mao',
    author_email='yymao.astro@gmail.com',
    license='MIT',
    classifiers=[
        'Intended Audience :: End Users/Desktop',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 3.11',
        'Topic :: Scientific/Engineering :: Astronomy',
    ],
    packages=["helpers"],
    install_requires=['future', 'requests >= 2', 'numpy >= 1.26', 'scipy >= 1.10', 'fast3tree >= 0.4.1', 'astropy >= 5', 'pandas >= 2'],
    entry_points={
        'console_scripts': [
            'helpers-readGadgetSnapshot=helpers.readGadgetSnapshot:main',
            'helpers-getMUSICregion=helpers.getMUSICregion:main',
            'helpers-getSDSSId=helpers.getSDSSId:main',
            'helpers-distributeMUSICBndryPart=helpers.distributeMUSICBndryPart:main',
        ],
    },
)
