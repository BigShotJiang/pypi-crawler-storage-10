"""Unit tests for TaskManager with integer task IDs."""

import tempfile
from collections.abc import AsyncGenerator
from pathlib import Path
from unittest.mock import patch

import orjson
import pandas as pd
import pytest

from ss_utils_aiosqlite import TaskManager


class TestTaskManagerInt:
    """Test TaskManager with integer task IDs."""

    @pytest.fixture
    async def task_manager(self) -> AsyncGenerator[TaskManager[int], None]:
        """Create a TaskManager instance with int task IDs for testing."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as tmp:
            db_path = Path(tmp.name)

        manager = await TaskManager.async_init(db_path, column_type="int")
        yield manager

        # Cleanup
        if db_path.exists():
            db_path.unlink()

    @pytest.mark.asyncio
    async def test_async_init_int(self):
        """Test TaskManager initialization with int column type."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as tmp:
            db_path = Path(tmp.name)

        try:
            manager = await TaskManager.async_init(db_path, column_type="int")
            assert manager.pth_tasks_db == db_path
            assert manager.column_type == "int"
            assert manager.default_timeout == 5
        finally:
            if db_path.exists():
                db_path.unlink()

    @pytest.mark.asyncio
    async def test_async_init_invalid_column_type(self):
        """Test TaskManager initialization with invalid column type."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as tmp:
            db_path = Path(tmp.name)

        try:
            with pytest.raises(ValueError, match="column_type must be either 'int' or 'str'"):
                await TaskManager.async_init(db_path, column_type="invalid")
        finally:
            if db_path.exists():
                db_path.unlink()

    @pytest.mark.asyncio
    async def test_setup_tasks_int(self, task_manager: TaskManager[int]):
        """Test setting up tasks with integer IDs."""
        task_ids = [(1,), (2,), (3,)]
        await task_manager.setup_tasks(task_ids)

        all_tasks = await task_manager.get_all_tasks()
        assert sorted(all_tasks) == [1, 2, 3]

    @pytest.mark.asyncio
    async def test_setup_tasks_empty_list(self, task_manager: TaskManager[int]):
        """Test setup_tasks with empty list raises ValueError."""
        with pytest.raises(ValueError, match="task_id_tpls cannot be empty"):
            await task_manager.setup_tasks([])

    @pytest.mark.asyncio
    async def test_update_outputs_int(self, task_manager: TaskManager[int]):
        """Test updating outputs with integer task IDs."""
        await task_manager.setup_tasks([(1,), (2,)])

        outputs = [{"result": "success", "value": 42}, {"result": "error", "message": "failed"}]
        await task_manager.update_outputs([1, 2], outputs)

        output_1 = await task_manager.get_output(1)
        output_2 = await task_manager.get_output(2)

        assert output_1 == {"result": "success", "value": 42}
        assert output_2 == {"result": "error", "message": "failed"}

    @pytest.mark.asyncio
    async def test_update_outputs_n_metadatas_int(self, task_manager: TaskManager[int]):
        """Test updating outputs and metadata with integer task IDs."""
        await task_manager.setup_tasks([(1,), (2,)])

        outputs = [{"result": "success"}, {"result": "error"}]
        metadatas = [{"duration": 1.5}, {"error_code": 500}]

        await task_manager.update_outputs_n_metadatas([1, 2], outputs, metadatas)

        output_1 = await task_manager.get_output(1)
        metadata_1 = await task_manager.get_metadata(1)
        output_2 = await task_manager.get_output(2)
        metadata_2 = await task_manager.get_metadata(2)

        assert output_1 == {"result": "success"}
        assert metadata_1 == {"duration": 1.5}
        assert output_2 == {"result": "error"}
        assert metadata_2 == {"error_code": 500}

    @pytest.mark.asyncio
    async def test_get_output_nonexistent_int(self, task_manager: TaskManager[int]):
        """Test getting output for non-existent integer task ID."""
        result = await task_manager.get_output(999)
        assert result is None

    @pytest.mark.asyncio
    async def test_get_metadata_nonexistent_int(self, task_manager: TaskManager[int]):
        """Test getting metadata for non-existent integer task ID."""
        result = await task_manager.get_metadata(999)
        assert result is None

    @pytest.mark.asyncio
    async def test_get_all_output_int(self, task_manager: TaskManager[int]):
        """Test getting all outputs with integer task IDs."""
        await task_manager.setup_tasks([(1,), (2,)])
        outputs = [{"result": "success"}, {"result": "error"}]
        await task_manager.update_outputs([1, 2], outputs)

        df = await task_manager.get_all_output()
        assert len(df) == 2
        assert set(df["task_id"]) == {1, 2}
        assert df[df["task_id"] == 1]["output"].iloc[0] == {"result": "success"}
        assert df[df["task_id"] == 2]["output"].iloc[0] == {"result": "error"}

    @pytest.mark.asyncio
    async def test_get_all_output_flatten_int(self, task_manager: TaskManager[int]):
        """Test getting all outputs with flattening enabled."""
        await task_manager.setup_tasks([(1,), (2,)])
        outputs = [{"result": "success", "count": 5}, {"result": "error", "count": 0}]
        await task_manager.update_outputs([1, 2], outputs)

        df = await task_manager.get_all_output(flatten=True)
        assert len(df) == 2
        assert "result" in df.columns
        assert "count" in df.columns
        assert set(df["task_id"]) == {1, 2}

    @pytest.mark.asyncio
    async def test_get_all_metadata_int(self, task_manager: TaskManager[int]):
        """Test getting all metadata with integer task IDs."""
        await task_manager.setup_tasks([(1,), (2,)])
        outputs = [{"result": "success"}, {"result": "error"}]
        metadatas = [{"duration": 1.5}, {"error_code": 500}]
        await task_manager.update_outputs_n_metadatas([1, 2], outputs, metadatas)

        df = await task_manager.get_all_metadata()
        assert len(df) == 2
        assert set(df["task_id"]) == {1, 2}
        assert df[df["task_id"] == 1]["metadata"].iloc[0] == {"duration": 1.5}
        assert df[df["task_id"] == 2]["metadata"].iloc[0] == {"error_code": 500}

    @pytest.mark.asyncio
    async def test_get_pending_tasks_int(self, task_manager: TaskManager[int]):
        """Test getting pending tasks with integer IDs."""
        await task_manager.setup_tasks([(1,), (2,), (3,)])
        await task_manager.update_outputs([1], [{"result": "success"}])

        pending = await task_manager.get_pending_tasks()
        assert sorted(pending) == [2, 3]

    @pytest.mark.asyncio
    async def test_get_noresult_tasks_int(self, task_manager: TaskManager[int]):
        """Test getting no-result tasks with integer IDs."""
        await task_manager.setup_tasks([(1,), (2,), (3,)])
        await task_manager.update_outputs([1, 2], [{"result": "success"}, {}])

        noresult = await task_manager.get_noresult_tasks()
        assert noresult == [2]

    @pytest.mark.asyncio
    async def test_mark_noresult_tasks_as_pending_int(self, task_manager: TaskManager[int]):
        """Test marking no-result tasks as pending."""
        await task_manager.setup_tasks([(1,), (2,)])
        await task_manager.update_outputs_n_metadatas(
            [1, 2], [{"result": "success"}, {}], [{"meta": "data"}, {"meta": "data2"}]
        )

        # Verify task 2 has empty output but metadata
        output_2 = await task_manager.get_output(2)
        metadata_2 = await task_manager.get_metadata(2)
        assert output_2 == {}
        assert metadata_2 == {"meta": "data2"}

        await task_manager.mark_noresult_tasks_as_pending()

        # After marking as pending, both output and metadata should be None
        output_2_after = await task_manager.get_output(2)
        metadata_2_after = await task_manager.get_metadata(2)
        assert output_2_after is None
        assert metadata_2_after is None

        pending = await task_manager.get_pending_tasks()
        assert 2 in pending

    @pytest.mark.asyncio
    async def test_query_int(self, task_manager: TaskManager[int]):
        """Test custom query execution."""
        await task_manager.setup_tasks([(1,), (2,), (3,)])

        df = await task_manager.query("SELECT COUNT(*) as count FROM tasks")
        assert len(df) == 1
        assert df["count"].iloc[0] == 3

    @pytest.mark.asyncio
    async def test_static_methods(self):
        """Test static JSON serialization methods."""
        test_dict = {"key": "value", "number": 42}

        # Test _dumps
        blob = TaskManager._dumps(test_dict)
        assert isinstance(blob, bytes)

        # Test _loads
        result = TaskManager._loads(blob)
        assert result == test_dict

        # Test _loads with invalid data
        invalid_result = TaskManager._loads(b"invalid json")
        assert invalid_result is None

        # Test _dumps with unserializable data (should return None)
        class UnserializableClass:
            pass

        unserializable = {"obj": UnserializableClass()}
        result = TaskManager._dumps(unserializable)
        assert result is None

    @pytest.mark.asyncio
    async def test_executemany_int(self, task_manager: TaskManager[int]):
        """Test executemany method."""
        # Create some initial tasks
        await task_manager.setup_tasks([(1,), (2,), (3,)])

        # Use executemany to update multiple tasks at once
        data = [(orjson.dumps({"result": f"batch_{i}"}), i) for i in [1, 2, 3]]
        await task_manager.executemany("UPDATE tasks SET output = ? WHERE task_id = ?", data)

        # Verify updates
        for i in [1, 2, 3]:
            output = await task_manager.get_output(i)
            assert output == {"result": f"batch_{i}"}
