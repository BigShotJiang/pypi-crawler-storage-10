"""Unit tests for utils_aiosqlite."""
