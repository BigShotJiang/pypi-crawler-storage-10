"""Unit tests for MyAioSQLite class."""

import tempfile
from collections.abc import AsyncGenerator
from pathlib import Path
from unittest.mock import AsyncMock, patch

import aiosqlite
import pandas as pd
import pytest

from ss_utils_aiosqlite import MyAioSQLite


class TestMyAioSQLite:
    """Test MyAioSQLite class functionality."""

    @pytest.fixture
    async def db_instance(self) -> AsyncGenerator[MyAioSQLite, None]:
        """Create a MyAioSQLite instance for testing."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as tmp:
            db_path = Path(tmp.name)

        instance = await MyAioSQLite.async_init(
            pth_db=db_path, timeout=10, auto_commit=False, readonly=False, prefetch=500
        )
        yield instance

        # Cleanup
        if db_path.exists():
            db_path.unlink()

    @pytest.mark.asyncio
    async def test_async_init(self):
        """Test MyAioSQLite initialization."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as tmp:
            db_path = Path(tmp.name)

        try:
            instance = await MyAioSQLite.async_init(
                pth_db=db_path, timeout=15, auto_commit=True, readonly=True, prefetch=2000
            )

            assert instance.pth_db == db_path
            assert instance.default_timeout == 15
            assert instance.auto_commit is True
            assert instance.readonly is True
            assert instance.prefetch == 2000
        finally:
            if db_path.exists():
                db_path.unlink()

    @pytest.mark.asyncio
    async def test_async_init_defaults(self):
        """Test MyAioSQLite initialization with default values."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as tmp:
            db_path = Path(tmp.name)

        try:
            instance = await MyAioSQLite.async_init(pth_db=db_path)

            assert instance.pth_db == db_path
            assert instance.default_timeout == 5
            assert instance.auto_commit is False
            assert instance.readonly is False
            assert instance.prefetch == 1000
        finally:
            if db_path.exists():
                db_path.unlink()

    @pytest.mark.asyncio
    async def test_call_select_query(self, db_instance: MyAioSQLite):
        """Test __call__ method with SELECT queries."""
        # Create a test table and insert data
        await db_instance.execute("CREATE TABLE test_table (id INTEGER, name TEXT)")
        await db_instance.execute("INSERT INTO test_table VALUES (1, 'Alice'), (2, 'Bob')")

        # Test SELECT query
        df = await db_instance("SELECT * FROM test_table ORDER BY id")

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2
        assert list(df.columns) == ["id", "name"]
        assert df.iloc[0]["id"] == 1
        assert df.iloc[0]["name"] == "Alice"
        assert df.iloc[1]["id"] == 2
        assert df.iloc[1]["name"] == "Bob"

    @pytest.mark.asyncio
    async def test_call_select_with_params(self, db_instance: MyAioSQLite):
        """Test __call__ method with parameterized SELECT queries."""
        await db_instance.execute("CREATE TABLE test_table (id INTEGER, name TEXT)")
        await db_instance.execute("INSERT INTO test_table VALUES (1, 'Alice'), (2, 'Bob')")

        df = await db_instance("SELECT * FROM test_table WHERE id = ?", 1)

        assert len(df) == 1
        assert df.iloc[0]["name"] == "Alice"

    @pytest.mark.asyncio
    async def test_call_select_no_results(self, db_instance: MyAioSQLite):
        """Test __call__ method with SELECT query returning no results."""
        await db_instance.execute("CREATE TABLE test_table (id INTEGER, name TEXT)")

        df = await db_instance("SELECT * FROM test_table")

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 0

    @pytest.mark.asyncio
    async def test_call_non_select_query_raises_error(self, db_instance: MyAioSQLite):
        """Test __call__ method raises error for non-SELECT queries."""
        with pytest.raises(ValueError, match="Only SELECT queries are allowed"):
            await db_instance("INSERT INTO test_table VALUES (1, 'Alice')")

        with pytest.raises(ValueError, match="Only SELECT queries are allowed"):
            await db_instance("UPDATE test_table SET name = 'Charlie' WHERE id = 1")

        with pytest.raises(ValueError, match="Only SELECT queries are allowed"):
            await db_instance("DELETE FROM test_table WHERE id = 1")

    @pytest.mark.asyncio
    async def test_execute_create_table(self, db_instance: MyAioSQLite):
        """Test execute method with CREATE TABLE."""
        await db_instance.execute("CREATE TABLE test_table (id INTEGER PRIMARY KEY, name TEXT)")

        # Verify table was created
        df = await db_instance("SELECT name FROM sqlite_master WHERE type='table' AND name='test_table'")
        assert len(df) == 1

    @pytest.mark.asyncio
    async def test_execute_insert_update_delete(self, db_instance: MyAioSQLite):
        """Test execute method with INSERT, UPDATE, DELETE operations."""
        await db_instance.execute("CREATE TABLE test_table (id INTEGER, name TEXT)")

        # Test INSERT
        await db_instance.execute("INSERT INTO test_table VALUES (?, ?)", 1, "Alice")
        await db_instance.execute("INSERT INTO test_table VALUES (?, ?)", 2, "Bob")

        # Verify INSERT
        df = await db_instance("SELECT COUNT(*) as count FROM test_table")
        assert df.iloc[0]["count"] == 2

        # Test UPDATE
        await db_instance.execute("UPDATE test_table SET name = ? WHERE id = ?", "Charlie", 1)

        # Verify UPDATE
        df = await db_instance("SELECT name FROM test_table WHERE id = 1")
        assert df.iloc[0]["name"] == "Charlie"

        # Test DELETE
        await db_instance.execute("DELETE FROM test_table WHERE id = ?", 2)

        # Verify DELETE
        df = await db_instance("SELECT COUNT(*) as count FROM test_table")
        assert df.iloc[0]["count"] == 1

    @pytest.mark.asyncio
    async def test_execute_readonly_mode(self, db_instance: MyAioSQLite):
        """Test execute method in readonly mode."""
        await db_instance.execute("CREATE TABLE test_table (id INTEGER, name TEXT)")
        await db_instance.execute("INSERT INTO test_table VALUES (1, 'Alice')")

        # Test that modification queries raise error in readonly mode
        with pytest.raises(ValueError, match="Cannot execute modification query in readonly mode"):
            await db_instance.execute("INSERT INTO test_table VALUES (2, 'Bob')", readonly=True)

        with pytest.raises(ValueError, match="Cannot execute modification query in readonly mode"):
            await db_instance.execute("UPDATE test_table SET name = 'Charlie'", readonly=True)

        with pytest.raises(ValueError, match="Cannot execute modification query in readonly mode"):
            await db_instance.execute("DELETE FROM test_table", readonly=True)

    @pytest.mark.asyncio
    async def test_executemany(self, db_instance: MyAioSQLite):
        """Test executemany method."""
        await db_instance.execute("CREATE TABLE test_table (id INTEGER, name TEXT)")

        data = [(1, "Alice"), (2, "Bob"), (3, "Charlie")]
        await db_instance.executemany("INSERT INTO test_table VALUES (?, ?)", data)

        df = await db_instance("SELECT COUNT(*) as count FROM test_table")
        assert df.iloc[0]["count"] == 3

    @pytest.mark.asyncio
    async def test_iterate(self, db_instance: MyAioSQLite):
        """Test iterate method."""
        await db_instance.execute("CREATE TABLE test_table (id INTEGER, name TEXT)")
        await db_instance.executemany("INSERT INTO test_table VALUES (?, ?)", [(i, f"Name{i}") for i in range(1, 6)])

        results = []
        async for row in db_instance.iterate("SELECT * FROM test_table ORDER BY id"):
            results.append(row)

        assert len(results) == 5
        assert results[0] == {"id": 1, "name": "Name1"}
        assert results[4] == {"id": 5, "name": "Name5"}

    @pytest.mark.asyncio
    async def test_iterate_with_prefetch(self, db_instance: MyAioSQLite):
        """Test iterate method with custom prefetch size."""
        await db_instance.execute("CREATE TABLE test_table (id INTEGER)")
        await db_instance.executemany("INSERT INTO test_table VALUES (?)", [(i,) for i in range(1, 11)])

        results = []
        async for row in db_instance.iterate("SELECT * FROM test_table ORDER BY id", prefetch=3):
            results.append(row)

        assert len(results) == 10
        assert all("id" in row for row in results)

    @pytest.mark.asyncio
    async def test_create_function(self, db_instance: MyAioSQLite):
        """Test create_function method."""

        def double_value(x):
            return x * 2

        await db_instance.create_function("double", 1, double_value)
        await db_instance.execute("CREATE TABLE test_table (value INTEGER)")
        await db_instance.execute("INSERT INTO test_table VALUES (5)")

        # Test the function within the same connection context
        async with aiosqlite.connect(db_instance.pth_db) as conn:
            await conn.create_function("double", 1, double_value)
            cursor = await conn.execute("SELECT double(value) as doubled FROM test_table")
            row = await cursor.fetchone()
            assert row[0] == 10

    @pytest.mark.asyncio
    async def test_create_table_if_not_exists(self, db_instance: MyAioSQLite):
        """Test create_table_if_not_exists method."""
        await db_instance.create_table_if_not_exists("test_table", "id INTEGER PRIMARY KEY, name TEXT NOT NULL")

        # Verify table was created
        df = await db_instance("SELECT name FROM sqlite_master WHERE type='table' AND name='test_table'")
        assert len(df) == 1

        # Test that calling again doesn't raise error
        await db_instance.create_table_if_not_exists("test_table", "id INTEGER PRIMARY KEY, name TEXT NOT NULL")

    @pytest.mark.asyncio
    async def test_table_exists(self, db_instance: MyAioSQLite):
        """Test table_exists method."""
        # Test non-existent table
        exists = await db_instance.table_exists("nonexistent_table")
        assert exists is False

        # Create table and test again
        await db_instance.execute("CREATE TABLE test_table (id INTEGER)")
        exists = await db_instance.table_exists("test_table")
        assert exists is True

    @pytest.mark.asyncio
    async def test_vacuum(self, db_instance: MyAioSQLite):
        """Test vacuum method."""
        await db_instance.execute("CREATE TABLE test_table (id INTEGER)")
        await db_instance.executemany("INSERT INTO test_table VALUES (?)", [(i,) for i in range(100)])
        await db_instance.execute("DELETE FROM test_table WHERE id < 50")

        # VACUUM should not raise any errors
        await db_instance.vacuum()

    @pytest.mark.asyncio
    async def test_get_table_info(self, db_instance: MyAioSQLite):
        """Test get_table_info method."""
        await db_instance.execute("""
            CREATE TABLE test_table (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                age INTEGER DEFAULT 0
            )
        """)

        info_df = await db_instance.get_table_info("test_table")

        assert len(info_df) == 3
        assert "name" in info_df.columns
        assert "type" in info_df.columns

        # Check column names
        column_names = info_df["name"].tolist()
        assert "id" in column_names
        assert "name" in column_names
        assert "age" in column_names

    def test_dict_to_blob(self):
        """Test dict_to_blob static method."""
        test_dict = {"key": "value", "number": 42, "list": [1, 2, 3]}
        blob = MyAioSQLite.dict_to_blob(test_dict)

        assert isinstance(blob, bytes)
        assert len(blob) > 0

    def test_dict_to_blob_invalid_data(self):
        """Test dict_to_blob with unserializable data."""

        class UnserializableClass:
            pass

        invalid_dict = {"obj": UnserializableClass()}
        blob = MyAioSQLite.dict_to_blob(invalid_dict)

        # Should return empty JSON object as bytes
        assert blob == b"{}"

    def test_blob_to_dict(self):
        """Test blob_to_dict static method."""
        test_dict = {"key": "value", "number": 42, "list": [1, 2, 3]}
        blob = MyAioSQLite.dict_to_blob(test_dict)
        result_dict = MyAioSQLite.blob_to_dict(blob)

        assert result_dict == test_dict

    def test_blob_to_dict_invalid_blob(self):
        """Test blob_to_dict with invalid blob data."""
        invalid_blob = b"not valid json"
        result = MyAioSQLite.blob_to_dict(invalid_blob)

        # Should return empty dict
        assert result == {}

    @pytest.mark.asyncio
    async def test_error_handling_in_call(self, db_instance: MyAioSQLite):
        """Test error handling in __call__ method."""
        with pytest.raises(Exception):  # noqa: B017 Should raise some database error
            await db_instance("SELECT * FROM nonexistent_table")

    @pytest.mark.asyncio
    async def test_error_handling_in_execute(self, db_instance: MyAioSQLite):
        """Test error handling in execute method."""
        with pytest.raises(Exception):  # noqa: B017 Should raise some database error
            await db_instance.execute("INVALID SQL SYNTAX")

    @pytest.mark.asyncio
    async def test_auto_commit_mode(self):
        """Test auto_commit mode."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as tmp:
            db_path = Path(tmp.name)

        try:
            instance = await MyAioSQLite.async_init(pth_db=db_path, auto_commit=True)

            await instance.execute("CREATE TABLE test_table (id INTEGER)")
            await instance.execute("INSERT INTO test_table VALUES (1)", auto_commit=True)

            # Verify data was committed
            df = await instance("SELECT COUNT(*) as count FROM test_table")
            assert df.iloc[0]["count"] == 1
        finally:
            if db_path.exists():
                db_path.unlink()
