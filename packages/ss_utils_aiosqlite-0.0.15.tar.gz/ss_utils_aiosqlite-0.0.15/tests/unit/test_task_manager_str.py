"""Unit tests for TaskManager with string task IDs."""

import tempfile
from collections.abc import AsyncGenerator
from pathlib import Path
from unittest.mock import patch

import orjson
import pandas as pd
import pytest

from ss_utils_aiosqlite import TaskManager


class TestTaskManagerStr:
    """Test TaskManager with string task IDs."""

    @pytest.fixture
    async def task_manager(self) -> AsyncGenerator[TaskManager[str], None]:
        """Create a TaskManager instance with str task IDs for testing."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as tmp:
            db_path = Path(tmp.name)

        manager = await TaskManager.async_init(db_path, column_type="str")
        yield manager

        # Cleanup
        if db_path.exists():
            db_path.unlink()

    @pytest.mark.asyncio
    async def test_async_init_str_default(self):
        """Test TaskManager initialization with default str column type."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as tmp:
            db_path = Path(tmp.name)

        try:
            # Default should be "str"
            manager = await TaskManager.async_init(db_path)
            assert manager.pth_tasks_db == db_path
            assert manager.column_type == "str"
            assert manager.default_timeout == 5
        finally:
            if db_path.exists():
                db_path.unlink()

    @pytest.mark.asyncio
    async def test_async_init_str_explicit(self):
        """Test TaskManager initialization with explicit str column type."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as tmp:
            db_path = Path(tmp.name)

        try:
            manager = await TaskManager.async_init(db_path, column_type="str")
            assert manager.pth_tasks_db == db_path
            assert manager.column_type == "str"
            assert manager.default_timeout == 5
        finally:
            if db_path.exists():
                db_path.unlink()

    @pytest.mark.asyncio
    async def test_setup_tasks_str(self, task_manager: TaskManager[str]):
        """Test setting up tasks with string IDs."""
        task_ids = [("task1",), ("task2",), ("task3",)]
        await task_manager.setup_tasks(task_ids)

        all_tasks = await task_manager.get_all_tasks()
        assert sorted(all_tasks) == ["task1", "task2", "task3"]

    @pytest.mark.asyncio
    async def test_setup_tasks_with_special_chars(self, task_manager: TaskManager[str]):
        """Test setting up tasks with string IDs containing special characters."""
        task_ids = [("task-1",), ("task_2",), ("task.3",), ("task@4",)]
        await task_manager.setup_tasks(task_ids)

        all_tasks = await task_manager.get_all_tasks()
        assert sorted(all_tasks) == ["task-1", "task.3", "task@4", "task_2"]

    @pytest.mark.asyncio
    async def test_update_outputs_str(self, task_manager: TaskManager[str]):
        """Test updating outputs with string task IDs."""
        await task_manager.setup_tasks([("task1",), ("task2",)])

        outputs = [{"result": "success", "value": 42}, {"result": "error", "message": "failed"}]
        await task_manager.update_outputs(["task1", "task2"], outputs)

        output_1 = await task_manager.get_output("task1")
        output_2 = await task_manager.get_output("task2")

        assert output_1 == {"result": "success", "value": 42}
        assert output_2 == {"result": "error", "message": "failed"}

    @pytest.mark.asyncio
    async def test_update_outputs_n_metadatas_str(self, task_manager: TaskManager[str]):
        """Test updating outputs and metadata with string task IDs."""
        await task_manager.setup_tasks([("task1",), ("task2",)])

        outputs = [{"result": "success"}, {"result": "error"}]
        metadatas = [{"duration": 1.5}, {"error_code": 500}]

        await task_manager.update_outputs_n_metadatas(["task1", "task2"], outputs, metadatas)

        output_1 = await task_manager.get_output("task1")
        metadata_1 = await task_manager.get_metadata("task1")
        output_2 = await task_manager.get_output("task2")
        metadata_2 = await task_manager.get_metadata("task2")

        assert output_1 == {"result": "success"}
        assert metadata_1 == {"duration": 1.5}
        assert output_2 == {"result": "error"}
        assert metadata_2 == {"error_code": 500}

    @pytest.mark.asyncio
    async def test_get_output_nonexistent_str(self, task_manager: TaskManager[str]):
        """Test getting output for non-existent string task ID."""
        result = await task_manager.get_output("nonexistent")
        assert result is None

    @pytest.mark.asyncio
    async def test_get_metadata_nonexistent_str(self, task_manager: TaskManager[str]):
        """Test getting metadata for non-existent string task ID."""
        result = await task_manager.get_metadata("nonexistent")
        assert result is None

    @pytest.mark.asyncio
    async def test_get_all_output_str(self, task_manager: TaskManager[str]):
        """Test getting all outputs with string task IDs."""
        await task_manager.setup_tasks([("task1",), ("task2",)])
        outputs = [{"result": "success"}, {"result": "error"}]
        await task_manager.update_outputs(["task1", "task2"], outputs)

        df = await task_manager.get_all_output()
        assert len(df) == 2
        assert set(df["task_id"]) == {"task1", "task2"}
        assert df[df["task_id"] == "task1"]["output"].iloc[0] == {"result": "success"}
        assert df[df["task_id"] == "task2"]["output"].iloc[0] == {"result": "error"}

    @pytest.mark.asyncio
    async def test_get_all_output_flatten_str(self, task_manager: TaskManager[str]):
        """Test getting all outputs with flattening enabled."""
        await task_manager.setup_tasks([("task1",), ("task2",)])
        outputs = [{"result": "success", "count": 5}, {"result": "error", "count": 0}]
        await task_manager.update_outputs(["task1", "task2"], outputs)

        df = await task_manager.get_all_output(flatten=True)
        assert len(df) == 2
        assert "result" in df.columns
        assert "count" in df.columns
        assert set(df["task_id"]) == {"task1", "task2"}

    @pytest.mark.asyncio
    async def test_get_all_metadata_str(self, task_manager: TaskManager[str]):
        """Test getting all metadata with string task IDs."""
        await task_manager.setup_tasks([("task1",), ("task2",)])
        outputs = [{"result": "success"}, {"result": "error"}]
        metadatas = [{"duration": 1.5}, {"error_code": 500}]
        await task_manager.update_outputs_n_metadatas(["task1", "task2"], outputs, metadatas)

        df = await task_manager.get_all_metadata()
        assert len(df) == 2
        assert set(df["task_id"]) == {"task1", "task2"}
        assert df[df["task_id"] == "task1"]["metadata"].iloc[0] == {"duration": 1.5}
        assert df[df["task_id"] == "task2"]["metadata"].iloc[0] == {"error_code": 500}

    @pytest.mark.asyncio
    async def test_get_pending_tasks_str(self, task_manager: TaskManager[str]):
        """Test getting pending tasks with string IDs."""
        await task_manager.setup_tasks([("task1",), ("task2",), ("task3",)])
        await task_manager.update_outputs(["task1"], [{"result": "success"}])

        pending = await task_manager.get_pending_tasks()
        assert sorted(pending) == ["task2", "task3"]

    @pytest.mark.asyncio
    async def test_get_noresult_tasks_str(self, task_manager: TaskManager[str]):
        """Test getting no-result tasks with string IDs."""
        await task_manager.setup_tasks([("task1",), ("task2",), ("task3",)])
        await task_manager.update_outputs(["task1", "task2"], [{"result": "success"}, {}])

        noresult = await task_manager.get_noresult_tasks()
        assert noresult == ["task2"]

    @pytest.mark.asyncio
    async def test_mark_noresult_tasks_as_pending_str(self, task_manager: TaskManager[str]):
        """Test marking no-result tasks as pending."""
        await task_manager.setup_tasks([("task1",), ("task2",)])
        await task_manager.update_outputs_n_metadatas(
            ["task1", "task2"], [{"result": "success"}, {}], [{"meta": "data"}, {"meta": "data2"}]
        )

        # Verify task2 has empty output but metadata
        output_2 = await task_manager.get_output("task2")
        metadata_2 = await task_manager.get_metadata("task2")
        assert output_2 == {}
        assert metadata_2 == {"meta": "data2"}

        await task_manager.mark_noresult_tasks_as_pending()

        # After marking as pending, both output and metadata should be None
        output_2_after = await task_manager.get_output("task2")
        metadata_2_after = await task_manager.get_metadata("task2")
        assert output_2_after is None
        assert metadata_2_after is None

        pending = await task_manager.get_pending_tasks()
        assert "task2" in pending

    @pytest.mark.asyncio
    async def test_query_str(self, task_manager: TaskManager[str]):
        """Test custom query execution with string task IDs."""
        await task_manager.setup_tasks([("task1",), ("task2",), ("task3",)])

        df = await task_manager.query("SELECT COUNT(*) as count FROM tasks")
        assert len(df) == 1
        assert df["count"].iloc[0] == 3

        # Test query with WHERE clause on string task_id
        df = await task_manager.query("SELECT task_id FROM tasks WHERE task_id LIKE 'task%'")
        assert len(df) == 3
        assert set(df["task_id"]) == {"task1", "task2", "task3"}

    @pytest.mark.asyncio
    async def test_executemany_str(self, task_manager: TaskManager[str]):
        """Test executemany method with string task IDs."""
        # Create some initial tasks
        await task_manager.setup_tasks([("task1",), ("task2",), ("task3",)])

        # Use executemany to update multiple tasks at once
        data = [(orjson.dumps({"result": f"batch_{task_id}"}), task_id) for task_id in ["task1", "task2", "task3"]]
        await task_manager.executemany("UPDATE tasks SET output = ? WHERE task_id = ?", data)

        # Verify updates
        for task_id in ["task1", "task2", "task3"]:
            output = await task_manager.get_output(task_id)
            assert output == {"result": f"batch_{task_id}"}

    @pytest.mark.asyncio
    async def test_mixed_string_formats(self, task_manager: TaskManager[str]):
        """Test TaskManager with various string formats."""
        # Test with different string formats
        task_ids = [
            ("uuid-123-456",),
            ("task_with_underscores",),
            ("task-with-dashes",),
            ("task.with.dots",),
            ("UPPERCASE_TASK",),
            ("MixedCase_Task",),
            ("123_numeric_prefix",),
            ("task_with_numbers_123",),
        ]

        await task_manager.setup_tasks(task_ids)

        all_tasks = await task_manager.get_all_tasks()
        expected_tasks = [tid[0] for tid in task_ids]
        assert sorted(all_tasks) == sorted(expected_tasks)

        # Test updating some of these tasks
        test_outputs = [{"status": "completed", "type": "uuid"}, {"status": "failed", "type": "underscore"}]

        await task_manager.update_outputs(["uuid-123-456", "task_with_underscores"], test_outputs)

        # Verify the updates
        output_uuid = await task_manager.get_output("uuid-123-456")
        output_underscore = await task_manager.get_output("task_with_underscores")

        assert output_uuid == {"status": "completed", "type": "uuid"}
        assert output_underscore == {"status": "failed", "type": "underscore"}

    @pytest.mark.asyncio
    async def test_long_string_task_ids(self, task_manager: TaskManager[str]):
        """Test TaskManager with very long string task IDs."""
        long_task_id = "very_long_task_id_" + "x" * 200  # 218 characters total

        await task_manager.setup_tasks([(long_task_id,)])

        # Test that we can work with long task IDs
        await task_manager.update_outputs([long_task_id], [{"result": "success_with_long_id"}])

        output = await task_manager.get_output(long_task_id)
        assert output == {"result": "success_with_long_id"}

        all_tasks = await task_manager.get_all_tasks()
        assert long_task_id in all_tasks
