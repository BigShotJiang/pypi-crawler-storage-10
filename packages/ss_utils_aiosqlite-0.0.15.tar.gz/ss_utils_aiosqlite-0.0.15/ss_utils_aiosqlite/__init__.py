"""
Helper functions for working with aiosqlite.
"""

import logging
from collections.abc import AsyncGenerator, Callable
from pathlib import Path
from typing import Any, Generic, Literal, TypeVar

import aiosqlite
import orjson
import pandas as pd

logger = logging.getLogger(__name__)

# Type variable for task IDs - can be int or str
TaskIdType = TypeVar("TaskIdType", int, str)


class MyAioSQLite:
    """SQLite DB helper functions (based on `aiosqlite`)"""

    def __init__(self):
        """Refer to async_init()"""
        self.pth_db: Path
        self.db = None
        self.default_timeout: int
        self.auto_commit: bool
        self.readonly: bool
        self.prefetch: int

    @classmethod
    async def async_init(
        cls,
        pth_db: str | Path,
        timeout: int = 5,
        auto_commit: bool = False,
        readonly: bool = False,
        prefetch: int = 1000,
    ) -> "MyAioSQLite":
        """Initialize the SQLite database asynchronously

        Args:
            pth_db: Path to the SQLite database file
            timeout: Default timeout for database operations in seconds. Default is 5.
            auto_commit: Whether to automatically commit after each query. Default is False.
            readonly: If True, all transactions are read-only. Default is False.
            prefetch: The default number of rows to fetch at a time. Default is 1000.
        """
        logging.info("[MyAioSQLite] Not fully tested as of 25/04/2025")
        self = cls()
        self.pth_db = Path(pth_db)
        self.default_timeout = timeout
        self.auto_commit = auto_commit
        self.readonly = readonly
        self.prefetch = prefetch
        return self

    async def __call__(self, query: str, *params: Any) -> None | pd.DataFrame:
        """Execute a query and return the result as a DataFrame

        Args:
            query: The SQL query to execute
            params: The parameters to pass to the query.

        Returns:
            If the query returns data, a DataFrame containing the query results. Otherwise, None.
        """
        if query[:30].lstrip()[:6].upper() != "SELECT":
            raise ValueError(
                "[MyAioSQLite] Only SELECT queries are allowed. Please use `execute()` for queries that do not return data."
            )

        async with aiosqlite.connect(self.pth_db, timeout=self.default_timeout) as conn:
            try:
                conn.row_factory = aiosqlite.Row
                cursor = await conn.execute(query, params)
                rows = await cursor.fetchall()
                if rows:
                    # Convert rows to a list of dicts
                    columns = [description[0] for description in cursor.description]
                    result = [dict(zip(columns, row, strict=True)) for row in rows]
                    return pd.DataFrame(result)
                else:
                    return pd.DataFrame()
            except Exception as e:
                logger.error(f"[MyAioSQLite] Error executing query: {str(e)}")
                raise

    async def execute(self, query: str, *params: Any, auto_commit: bool | None = None, readonly: bool | None = None):
        """Execute a query, without expecting any results.

        Args:
            query: The SQL query to execute
            params: The parameters to pass to the query
            auto_commit: If True, executes without a transaction. If None, uses the instance default.
            readonly: If True, uses a read-only transaction.
        """
        # Check if query is a modification operation when readonly is explicitly True
        readonly_final = readonly or self.readonly
        if readonly_final and any(
            query.lstrip()[: len(op)].upper() == op for op in ["UPDATE", "INSERT", "DELETE", "CREATE", "DROP", "ALTER"]
        ):
            raise ValueError(f"[MyAioSQLite] Cannot execute modification query in readonly mode: {query[:50]}...")

        async with aiosqlite.connect(self.pth_db, timeout=self.default_timeout) as conn:
            try:
                auto_commit_final = auto_commit or self.auto_commit
                if auto_commit_final:
                    await conn.execute(query, params)
                    await conn.commit()
                else:
                    if readonly_final:
                        # For SQLite, read-only mode requires setting the connection to read-only
                        await conn.execute("PRAGMA query_only = ON")
                    await conn.execute(query, params)
                    if not readonly_final:
                        await conn.commit()
            except Exception as e:
                logger.error(f"[MyAioSQLite] Error executing query: {str(e)}")
                raise

    async def executemany(self, query: str, params_list: list[tuple]):
        """Execute a query with multiple sets of parameters

        Args:
            query: The SQL query to execute
            params_list: List of parameter tuples
        """
        async with aiosqlite.connect(self.pth_db, timeout=self.default_timeout) as conn:
            try:
                await conn.executemany(query, params_list)
                await conn.commit()
            except Exception as e:
                logger.error(f"[MyAioSQLite] Error executing batch query: {str(e)}")
                raise

    async def iterate(
        self, query: str, *params: Any, prefetch: int | None = None, readonly: bool = True
    ) -> AsyncGenerator[dict, None]:
        """Iterate over the results of a query.

        Args:
            query: The SQL query to execute
            params: The parameters to pass to the query
            prefetch: The number of rows to fetch at a time
            readonly: If True, the transaction is read-only

        Yields:
            Each row as a dictionary
        """
        prefetch_final = prefetch or self.prefetch
        readonly_final = readonly or self.readonly

        async with aiosqlite.connect(self.pth_db, timeout=self.default_timeout) as conn:
            try:
                if readonly_final:
                    await conn.execute("PRAGMA query_only = ON")

                conn.row_factory = aiosqlite.Row
                cursor = await conn.execute(query, params)

                # SQLite doesn't have a built-in prefetch, but we can manually implement it
                while True:
                    rows = await cursor.fetchmany(prefetch_final)
                    if not rows:
                        break

                    columns = [description[0] for description in cursor.description]
                    for row in rows:
                        yield dict(zip(columns, row, strict=True))

            except Exception as e:
                logger.error(f"[MyAioSQLite] Error iterating query: {str(e)}")
                raise

    async def create_function(self, name: str, num_params: int, func: Callable):
        """Register a Python function with SQLite

        Args:
            name: Name of the function in SQL queries
            num_params: Number of parameters the function accepts
            func: Python function to register
        """
        async with aiosqlite.connect(self.pth_db, timeout=self.default_timeout) as conn:
            await conn.create_function(name, num_params, func)

    async def create_table_if_not_exists(self, table_name: str, column_defs: str):
        """Create a table if it doesn't exist

        Args:
            table_name: Name of the table to create
            column_defs: Column definitions including constraints
        """
        query = f"CREATE TABLE IF NOT EXISTS {table_name} ({column_defs})"
        await self.execute(query)

    async def table_exists(self, table_name: str) -> bool:
        """Check if a table exists in the database

        Args:
            table_name: Name of the table to check

        Returns:
            True if the table exists, False otherwise
        """
        query = "SELECT name FROM sqlite_master WHERE type='table' AND name=?"
        df = await self(query, table_name)
        return not df.empty

    async def vacuum(self):
        """Run VACUUM to optimize the database file size"""
        await self.execute("VACUUM")

    async def get_table_info(self, table_name: str) -> pd.DataFrame:
        """Get information about a table's structure

        Args:
            table_name: Name of the table

        Returns:
            DataFrame containing table information
        """
        # Use the SELECT form of PRAGMA to make it compatible with __call__
        return await self(f"SELECT * FROM pragma_table_info('{table_name}')")

    @staticmethod
    def dict_to_blob(data: dict) -> bytes:
        """Convert a dictionary to a BLOB using orjson

        Args:
            data: Dictionary to convert

        Returns:
            BLOB representation of the dictionary
        """
        try:
            return orjson.dumps(data)
        except orjson.JSONEncodeError:
            logger.error("[MyAioSQLite] Error encoding dictionary to JSON")
            return b"{}"

    @staticmethod
    def blob_to_dict(blob: bytes) -> dict:
        """Convert a BLOB to a dictionary using orjson

        Args:
            blob: BLOB to convert

        Returns:
            Dictionary representation of the BLOB
        """
        try:
            return orjson.loads(blob)
        except orjson.JSONDecodeError:
            logger.error("[MyAioSQLite] Error decoding BLOB to dictionary")
            return {}


class TaskManager(Generic[TaskIdType]):
    """aiosqlite-based task manager for tracking tasks and storing task outputs as BJSON data.

    Generic class that supports both int and str task IDs.

    Underlying table has 3 columns:
    - task_id (INTEGER or TEXT PRIMARY KEY) - unique task ID, column type specified in `async_init()`
    - output (BLOB) - task output stored as BJSON
    - metadata (BLOB) - task metadata stored as BJSON

    Refer to async_init() for initialization.

    Usage:
        # For integer task IDs (explicit column_type="int")
        task_manager: TaskManager[int] = await TaskManager.async_init(path_to_db, column_type="int")
        await task_manager.setup_tasks([(1,), (2,), (3,)])
        await task_manager.update_outputs([1], [{"result": "success"}])

        # For string task IDs (default column_type="str")
        task_manager: TaskManager[str] = await TaskManager.async_init(path_to_db)
        await task_manager.setup_tasks([("task1",), ("task2",), ("task3",)])
        await task_manager.update_outputs(["task1"], [{"result": "success"}])

        await task_manager.get_all_output()

        # SQL query
        async with task_manager:
            df = await task_manager.query("SELECT COUNT(*) FROM tasks")
    """

    def __init__(self):
        self.pth_tasks_db: Path
        self.db = None
        self.default_timeout = 5
        self.column_type: Literal["int", "str"]

    @classmethod
    async def async_init(
        cls, pth_tasks_db: Path, column_type: Literal["int", "str"] = "str"
    ) -> "TaskManager[TaskIdType]":
        """Initialize the database asynchronously. Table creation is deferred to setup_tasks().

        Args:
            pth_tasks_db: Path to the SQLite database file
            column_type: Column type for task_id - either "int" or "str" (default: "str")
        """
        if column_type not in ("int", "str"):
            raise ValueError("column_type must be either 'int' or 'str'")

        self = cls()
        self.pth_tasks_db = pth_tasks_db
        self.column_type = column_type
        sql_column_type = "INTEGER" if self.column_type == "int" else "TEXT"

        # Create the table only during initialization
        async with aiosqlite.connect(pth_tasks_db) as db:
            await db.execute(f"""
            CREATE TABLE IF NOT EXISTS tasks (
                task_id {sql_column_type} PRIMARY KEY,
                output BLOB,
                metadata BLOB
            )
            """)
            await db.commit()

        return self

    def _check_connection(self):
        """Check if database connection exists"""
        if self.db is None:
            raise RuntimeError(
                "Database connection not established. Use 'async with task_manager:' to establish a connection."
            )

    async def setup_tasks(self, task_id_tpls: list[tuple[TaskIdType]]):
        """
        Create entries in the tasks table for each task ID.
        task_ids must NOT exist in the table already.

        Args:
            task_id_tpls: List of task ID tuples to create entries for.
                e.g. `[(1,), (2,), (3,)]` for int or `[("task1",), ("task2",)]` for str
        """
        if not task_id_tpls:
            raise ValueError("task_id_tpls cannot be empty")

        # Insert the task entries
        await self.executemany("INSERT OR IGNORE INTO tasks (task_id) VALUES (?)", task_id_tpls)

    async def update_outputs(self, task_ids: list[TaskIdType], outputs: list[dict]):
        """Update a task's output data

        Args:
            task_ids: List of task IDs
            outputs: List of output data
        """
        await self.executemany(
            """INSERT INTO tasks (task_id, output) VALUES (?, ?)
            ON CONFLICT(task_id) DO UPDATE SET output = excluded.output
            """,
            [(task_id, self._dumps(output)) for task_id, output in zip(task_ids, outputs, strict=True)],
        )

    async def update_outputs_n_metadatas(self, task_ids: list[TaskIdType], outputs: list[dict], metadatas: list[dict]):
        """Update a task's output and metadata

        Args:
            task_ids: List of task IDs
            outputs: List of output data
            metadatas: List of metadata
        """
        await self.executemany(
            """INSERT INTO tasks (task_id, output, metadata) VALUES (?, ?, ?)
            ON CONFLICT(task_id) DO UPDATE SET output = excluded.output, metadata = excluded.metadata
            """,
            [
                (task_id, self._dumps(output), self._dumps(metadata))
                for task_id, output, metadata in zip(task_ids, outputs, metadatas, strict=True)
            ],
        )

    async def get_output(self, task_id: TaskIdType) -> dict | None:
        """Get a task's output data"""
        async with aiosqlite.connect(self.pth_tasks_db, timeout=self.default_timeout) as db:
            async with db.execute("SELECT output FROM tasks WHERE task_id = ?", (task_id,)) as cursor:
                row = await cursor.fetchone()
                if row:
                    return self._loads(row[0])
                return None

    async def get_metadata(self, task_id: TaskIdType) -> dict | None:
        """Get a task's metadata"""
        async with aiosqlite.connect(self.pth_tasks_db, timeout=self.default_timeout) as db:
            async with db.execute("SELECT metadata FROM tasks WHERE task_id = ?", (task_id,)) as cursor:
                row = await cursor.fetchone()
                if row:
                    return self._loads(row[0])
                return None

    async def _get_all_1col(self, col_name: str, flatten: bool = False) -> pd.DataFrame:
        """Get all values for a specific column"""
        async with aiosqlite.connect(self.pth_tasks_db, timeout=self.default_timeout) as db:
            async with db.execute(f"SELECT task_id, {col_name} FROM tasks") as cursor:
                rows = await cursor.fetchall()

        # Convert to pandas DataFrame
        data = [(row[0], self._loads(row[1])) for row in rows]
        df = pd.DataFrame(data, columns=["task_id", col_name])

        if flatten and not df.empty:
            return pd.json_normalize(df[col_name]).set_index(df["task_id"]).reset_index()
        return df

    async def get_all_output(self, flatten: bool = False) -> pd.DataFrame:
        """Get all tasks's output from the database

        Args:
            flatten: If True, will flatten the JSON output into columns.
                Note: May be memory-intensive for large datasets.
        """
        return await self._get_all_1col("output", flatten)

    async def get_all_metadata(self, flatten: bool = False) -> pd.DataFrame:
        """Get all tasks's metadata from the database

        Args:
            flatten: If True, will flatten the JSON metadata into columns.
                Note: May be memory-intensive for large datasets.
        """
        return await self._get_all_1col("metadata", flatten)

    async def get_pending_tasks(self) -> list[TaskIdType]:
        """Get task IDs that have not been completed yet (i.e. `output` column is null)."""
        task_ids = []
        async with aiosqlite.connect(self.pth_tasks_db, timeout=self.default_timeout) as db:
            async with db.execute("SELECT task_id FROM tasks WHERE output IS NULL") as cursor:
                async for row in cursor:
                    task_ids.append(row[0])
        return task_ids

    async def get_noresult_tasks(self) -> list[TaskIdType]:
        """Get task IDs that completed but have no meaningful output (i.e. output is a '{}' blob)."""
        task_ids = []
        async with aiosqlite.connect(self.pth_tasks_db, timeout=self.default_timeout) as db:
            async with db.execute("SELECT task_id FROM tasks WHERE output = CAST('{}' AS BLOB)") as cursor:
                async for row in cursor:
                    task_ids.append(row[0])
        return task_ids

    async def mark_noresult_tasks_as_pending(self):
        """Mark tasks with no meaningful output as pending."""
        async with aiosqlite.connect(self.pth_tasks_db, timeout=self.default_timeout) as db:
            await db.execute("""UPDATE tasks SET
            output = NULL,
            metadata = NULL
            WHERE output = CAST('{}' AS BLOB)""")
            await db.commit()

    async def get_all_tasks(self) -> list[TaskIdType]:
        """Get all task IDs in the database."""
        task_ids = []
        async with aiosqlite.connect(self.pth_tasks_db, timeout=self.default_timeout) as db:
            async with db.execute("SELECT task_id FROM tasks") as cursor:
                async for row in cursor:
                    task_ids.append(row[0])
        return task_ids

    async def query(self, query: str) -> pd.DataFrame:
        """Execute a query and return the result as a pandas DataFrame"""
        async with aiosqlite.connect(self.pth_tasks_db, timeout=self.default_timeout) as db:
            async with db.execute(query) as cursor:
                rows = await cursor.fetchall()
                columns = [description[0] for description in cursor.description]

        return pd.DataFrame(rows, columns=columns)

    async def executemany(self, query: str, data: list[tuple]):
        """Execute a query with multiple data entries"""
        async with aiosqlite.connect(self.pth_tasks_db, timeout=self.default_timeout) as db:
            await db.executemany(query, data)
            await db.commit()

    @staticmethod
    def _loads(output: bytes) -> dict | None:
        try:
            return orjson.loads(output)
        except orjson.JSONDecodeError:
            return None

    @staticmethod
    def _dumps(dic: dict) -> bytes:
        try:
            return orjson.dumps(dic)
        except orjson.JSONEncodeError:
            return None
