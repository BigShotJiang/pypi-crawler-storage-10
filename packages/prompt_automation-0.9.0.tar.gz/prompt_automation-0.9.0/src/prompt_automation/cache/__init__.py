"""Cache module for prompt-automation."""

from prompt_automation.cache.l1_memory import L1Cache
from prompt_automation.cache.l2_disk import L2Cache
from prompt_automation.cache.l3_gpu import L3Cache
from prompt_automation.cache.semantic_hash import (
    SemanticHasher,
    semantic_hash,
    semantic_similarity,
)
from prompt_automation.cache.manager import CacheManager
from prompt_automation.cache.stats import CacheStats
from prompt_automation.cache.config_integration import create_cache_from_config
from prompt_automation.cache.llm_integration import CachedLLMClient
from prompt_automation.cache.mcp_integration import CachedMCPClient
from prompt_automation.cache.template_integration import CachedTemplateRenderer

__all__ = [
    "L1Cache",
    "L2Cache",
    "L3Cache",
    "SemanticHasher",
    "semantic_hash",
    "semantic_similarity",
    "CacheManager",
    "CacheStats",
    "create_cache_from_config",
    "CachedLLMClient",
    "CachedMCPClient",
    "CachedTemplateRenderer",
]
