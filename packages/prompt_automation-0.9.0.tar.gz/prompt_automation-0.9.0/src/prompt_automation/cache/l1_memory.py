"""L1 in-memory LRU cache with TTL support."""

import sys
import time
from collections import OrderedDict
from typing import Any, Optional


class L1Cache:
    """In-memory LRU cache with TTL support and memory budget enforcement."""
    
    def __init__(self, max_size_mb: int = 256):
        """Initialize L1 cache with memory budget.
        
        Args:
            max_size_mb: Maximum cache size in megabytes
        """
        self.max_size_bytes = max_size_mb * 1024 * 1024
        self._cache = OrderedDict()  # Maintains insertion order for LRU
        self._ttls = {}  # key -> expiry timestamp
        self._current_size = 0
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache, return None if expired or missing.
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None if not found/expired
        """
        if key not in self._cache:
            return None
        
        # Check TTL
        if key in self._ttls:
            if time.time() > self._ttls[key]:
                # Expired - delete and return None
                self.delete(key)
                return None
        
        # Move to end (mark as recently used for LRU)
        self._cache.move_to_end(key)
        return self._cache[key]
    
    def set(self, key: str, value: Any, ttl: Optional[int] = None):
        """Set value in cache with optional TTL.
        
        Args:
            key: Cache key
            value: Value to cache
            ttl: Time-to-live in seconds (None = no expiry)
        """
        value_size = self._get_size(value)
        
        # If updating existing key, free old memory
        if key in self._cache:
            old_size = self._get_size(self._cache[key])
            self._current_size -= old_size
        
        # Add new value
        self._cache[key] = value
        self._current_size += value_size
        
        # Set TTL
        if ttl is not None:
            self._ttls[key] = time.time() + ttl
        elif key in self._ttls:
            # Remove TTL if key existed with TTL before
            del self._ttls[key]
        
        # Move to end (most recently used)
        self._cache.move_to_end(key)
        
        # Evict if over budget
        self._evict_if_needed()
    
    def delete(self, key: str):
        """Remove key from cache and free memory.
        
        Args:
            key: Cache key to delete
        """
        if key in self._cache:
            value_size = self._get_size(self._cache[key])
            self._current_size -= value_size
            del self._cache[key]
            
            if key in self._ttls:
                del self._ttls[key]
    
    def clear(self):
        """Clear entire cache and reset memory tracking."""
        self._cache.clear()
        self._ttls.clear()
        self._current_size = 0
    
    def size_mb(self) -> float:
        """Get current cache size in megabytes.
        
        Returns:
            Current memory usage in MB
        """
        return self._current_size / (1024 * 1024)
    
    def _evict_if_needed(self):
        """Evict oldest entries (LRU) if over memory budget."""
        while self._current_size > self.max_size_bytes:
            if not self._cache:
                # Cache is empty, nothing to evict
                break
            
            # Evict oldest (first in OrderedDict)
            oldest_key = next(iter(self._cache))
            self.delete(oldest_key)
    
    def _get_size(self, value: Any) -> int:
        """Get size of value in bytes.
        
        For strings, use length-based estimation (more accurate than sys.getsizeof).
        For other types, use sys.getsizeof.
        
        Args:
            value: Value to measure
            
        Returns:
            Size in bytes
        """
        if isinstance(value, str):
            # String size = length in bytes (UTF-8) + overhead
            return len(value.encode('utf-8')) + sys.getsizeof("")
        else:
            return sys.getsizeof(value)
