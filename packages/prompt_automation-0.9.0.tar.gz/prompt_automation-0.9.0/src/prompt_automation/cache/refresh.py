"""Background cache refresh service for offline functionality.

This module provides automatic cache refreshing when network is available,
ensuring fresh data without user intervention.
"""

import logging
import socket
import threading
import time
from typing import Optional

logger = logging.getLogger(__name__)


class BackgroundRefreshService:
    """Background service for periodic cache refresh.
    
    Monitors network connectivity and automatically refreshes cache
    when online. Uses daemon thread for clean application exit.
    
    Args:
        cache_manager: CacheManager instance to refresh
        refresh_interval: Seconds between refresh attempts (default: 300 = 5 minutes)
    
    Example:
        >>> from prompt_automation.cache import CacheManager
        >>> cache = CacheManager(l1, l2)
        >>> service = BackgroundRefreshService(cache, refresh_interval=300)
        >>> service.start()
        >>> # ... cache refreshes automatically every 5 minutes when online
        >>> service.stop()
    """
    
    def __init__(self, cache_manager, refresh_interval: int = 300):
        """Initialize background refresh service.
        
        Args:
            cache_manager: CacheManager instance with prune_expired() method
            refresh_interval: Seconds between refresh attempts
        """
        self.cache_manager = cache_manager
        self.refresh_interval = refresh_interval
        self._stop_event: Optional[threading.Event] = None
        self._thread: Optional[threading.Thread] = None
        self._online_status = None  # Track online/offline transitions
    
    def start(self):
        """Start background refresh thread.
        
        Thread runs as daemon so it won't prevent application exit.
        """
        if self._thread and self._thread.is_alive():
            logger.warning("Background refresh service already running")
            return
        
        self._stop_event = threading.Event()
        self._thread = threading.Thread(target=self._refresh_loop, daemon=True)
        self._thread.start()
        
        logger.info(f"Background refresh service started (interval: {self.refresh_interval}s)")
    
    def stop(self):
        """Stop background refresh thread.
        
        Signals thread to stop and waits up to 2 seconds for clean shutdown.
        """
        if not self._thread:
            return
        
        logger.info("Stopping background refresh service...")
        self._stop_event.set()
        self._thread.join(timeout=2)
        
        if self._thread.is_alive():
            logger.warning("Background refresh thread did not stop cleanly")
        else:
            logger.info("Background refresh service stopped")
        
        self._thread = None
        self._stop_event = None
    
    def _is_online(self) -> bool:
        """Check if internet connection is available.
        
        Uses socket test to Google DNS (8.8.8.8:53) with 3-second timeout.
        
        Returns:
            True if online, False if offline
        """
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            return True
        except OSError:
            return False
    
    def _refresh_loop(self):
        """Main refresh loop (runs in background thread).
        
        Periodically checks network connectivity and refreshes cache when online.
        Continues running until stop() is called.
        """
        logger.debug("Background refresh loop started")
        
        while not self._stop_event.wait(self.refresh_interval):
            try:
                # Check network connectivity
                is_online = self._is_online()
                
                # Log online/offline transitions
                if is_online != self._online_status:
                    if is_online:
                        logger.info("Network connection restored (online)")
                    else:
                        logger.info("Network connection lost (offline)")
                    self._online_status = is_online
                
                # Skip refresh if offline
                if not is_online:
                    logger.debug("Skipping cache refresh (offline)")
                    continue
                
                # Refresh cache
                self._refresh_cache()
                
            except Exception as e:
                logger.error(f"Error in refresh loop: {e}", exc_info=True)
                # Continue loop despite error
        
        logger.debug("Background refresh loop exited")
    
    def _refresh_cache(self):
        """Refresh cache by pruning expired entries.
        
        In future, this could also prefetch popular templates,
        but for now just prunes expired entries.
        """
        try:
            logger.debug("Starting cache refresh...")
            
            # Prune expired entries
            if hasattr(self.cache_manager, 'l2') and hasattr(self.cache_manager.l2, 'prune_expired'):
                self.cache_manager.l2.prune_expired()
                logger.debug("Cache refresh complete (pruned expired entries)")
            else:
                logger.warning("Cache manager does not support prune_expired()")
        
        except Exception as e:
            logger.error(f"Cache refresh failed: {e}")
            # Don't raise - let loop continue
    
    def __del__(self):
        """Cleanup on deletion."""
        if self._thread and self._thread.is_alive():
            self.stop()
