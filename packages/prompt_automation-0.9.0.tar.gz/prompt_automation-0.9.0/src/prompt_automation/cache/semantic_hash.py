"""Semantic hashing for prompt deduplication using fuzzy matching."""

import hashlib
import re
from typing import Optional


try:
    from sentence_transformers import SentenceTransformer
    EMBEDDINGS_AVAILABLE = True
except ImportError:
    EMBEDDINGS_AVAILABLE = False


class SemanticHasher:
    """Generate semantic hashes for prompt deduplication.
    
    Supports two modes:
    1. Fuzzy hash (default): Text normalization + Levenshtein distance
    2. Embeddings (optional): Sentence transformers for semantic similarity
    """
    
    def __init__(self, use_embeddings: bool = False):
        """Initialize semantic hasher.
        
        Args:
            use_embeddings: Use sentence embeddings if available (requires sentence-transformers)
        """
        self.use_embeddings = use_embeddings and EMBEDDINGS_AVAILABLE
        
        if self.use_embeddings:
            # Load lightweight model for embeddings (~80MB)
            self.model = SentenceTransformer('all-MiniLM-L6-v2')
        else:
            self.model = None
    
    def hash(self, text: str) -> str:
        """Generate semantic hash for text.
        
        Args:
            text: Input text to hash
            
        Returns:
            16-character hash string
        """
        if self.use_embeddings:
            return self._embedding_hash(text)
        else:
            return self._fuzzy_hash(text)
    
    def similarity(self, text1: str, text2: str) -> float:
        """Calculate similarity between two texts.
        
        Args:
            text1: First text
            text2: Second text
            
        Returns:
            Similarity score from 0.0 (different) to 1.0 (identical)
        """
        if self.use_embeddings:
            return self._embedding_similarity(text1, text2)
        else:
            return self._fuzzy_similarity(text1, text2)
    
    def _fuzzy_hash(self, text: str) -> str:
        """Generate fuzzy hash via normalization.
        
        Args:
            text: Input text
            
        Returns:
            16-character hash
        """
        normalized = self._normalize(text)
        return hashlib.sha256(normalized.encode()).hexdigest()[:16]
    
    def _fuzzy_similarity(self, text1: str, text2: str) -> float:
        """Calculate similarity via token-level Jaccard + normalized Levenshtein.
        
        Args:
            text1: First text
            text2: Second text
            
        Returns:
            Similarity score (0.0-1.0)
        """
        norm1 = self._normalize(text1)
        norm2 = self._normalize(text2)
        
        # Handle empty strings
        if not norm1 and not norm2:
            return 1.0
        if not norm1 or not norm2:
            return 0.0
        
        # Token-level Jaccard similarity (word overlap)
        tokens1 = set(norm1.split())
        tokens2 = set(norm2.split())
        
        if tokens1 or tokens2:
            jaccard = len(tokens1 & tokens2) / len(tokens1 | tokens2)
        else:
            jaccard = 0.0
        
        # Character-level Levenshtein similarity
        distance = self._levenshtein(norm1, norm2)
        max_len = max(len(norm1), len(norm2))
        levenshtein_sim = 1.0 - (distance / max_len)
        
        # Weighted average: 70% Jaccard (semantic), 30% Levenshtein (typos)
        return 0.7 * jaccard + 0.3 * levenshtein_sim
    
    def _normalize(self, text: str) -> str:
        """Normalize text for fuzzy matching.
        
        Normalization steps:
        1. Convert to lowercase
        2. Remove punctuation
        3. Collapse whitespace
        
        Args:
            text: Input text
            
        Returns:
            Normalized text
        """
        # Lowercase
        text = text.lower()
        
        # Remove punctuation (keep alphanumeric and spaces)
        text = re.sub(r'[^\w\s]', '', text)
        
        # Collapse whitespace
        text = ' '.join(text.split())
        
        return text
    
    def _levenshtein(self, s1: str, s2: str) -> int:
        """Calculate Levenshtein distance (edit distance) between two strings.
        
        Uses dynamic programming approach.
        
        Args:
            s1: First string
            s2: Second string
            
        Returns:
            Edit distance (number of edits to transform s1 into s2)
        """
        # Ensure s1 is the longer string
        if len(s1) < len(s2):
            return self._levenshtein(s2, s1)
        
        # Handle empty string
        if len(s2) == 0:
            return len(s1)
        
        # Initialize previous row
        previous_row = range(len(s2) + 1)
        
        # Calculate each row
        for i, c1 in enumerate(s1):
            current_row = [i + 1]
            for j, c2 in enumerate(s2):
                # Cost of insertions, deletions, or substitutions
                insertions = previous_row[j + 1] + 1
                deletions = current_row[j] + 1
                substitutions = previous_row[j] + (c1 != c2)
                current_row.append(min(insertions, deletions, substitutions))
            previous_row = current_row
        
        return previous_row[-1]
    
    def _embedding_hash(self, text: str) -> str:
        """Generate hash using sentence embeddings.
        
        Args:
            text: Input text
            
        Returns:
            16-character hash
        """
        # Encode text to embedding vector
        embedding = self.model.encode(text, convert_to_numpy=True)
        
        # Quantize embedding to reduce size
        quantized = (embedding * 100).astype(int).tobytes()
        
        return hashlib.sha256(quantized).hexdigest()[:16]
    
    def _embedding_similarity(self, text1: str, text2: str) -> float:
        """Calculate cosine similarity of embeddings.
        
        Args:
            text1: First text
            text2: Second text
            
        Returns:
            Cosine similarity (0.0-1.0)
        """
        # Encode texts
        emb1 = self.model.encode(text1, convert_to_numpy=True)
        emb2 = self.model.encode(text2, convert_to_numpy=True)
        
        # Calculate cosine similarity
        dot_product = (emb1 * emb2).sum()
        norm1 = (emb1 ** 2).sum() ** 0.5
        norm2 = (emb2 ** 2).sum() ** 0.5
        
        return float(dot_product / (norm1 * norm2))


# Global singleton instance
_hasher: Optional[SemanticHasher] = None


def semantic_hash(text: str, use_embeddings: bool = False) -> str:
    """Generate semantic hash for text (convenience function).
    
    Args:
        text: Input text to hash
        use_embeddings: Use embeddings if available
        
    Returns:
        16-character hash string
    """
    global _hasher
    if _hasher is None:
        _hasher = SemanticHasher(use_embeddings=use_embeddings)
    return _hasher.hash(text)


def semantic_similarity(text1: str, text2: str, use_embeddings: bool = False) -> float:
    """Calculate semantic similarity between texts (convenience function).
    
    Args:
        text1: First text
        text2: Second text
        use_embeddings: Use embeddings if available
        
    Returns:
        Similarity score (0.0-1.0)
    """
    global _hasher
    if _hasher is None:
        _hasher = SemanticHasher(use_embeddings=use_embeddings)
    return _hasher.similarity(text1, text2)
