"""CacheManager orchestrates multi-tier cache lookups and promotions.

Responsibilities:
- Try L1, then L2, then L3 (if provided) on get()
- Promote from lower tiers to L1 on successful read
- set() writes to both L1 and L2 (and optionally L3 via stub)
- invalidate() removes keys from all tiers
- clear_all() clears all tiers
"""

from typing import Any, Optional, Dict
from prompt_automation.cache.stats import CacheStats


class CacheManager:
    """Orchestrates multi-tier caching.

    Simple behavior:
    - get: try l1, then l2, then l3. If found in l2/l3, promote to l1.
    - set: write to l1 and l2 (and l3.set if present).
    - invalidate: delete from all tiers.
    - clear_all: clear all tiers.
    """

    def __init__(self, l1, l2, l3: Optional[Any] = None):
        """Initialize CacheManager with cache tiers.
        
        Args:
            l1: L1 memory cache instance
            l2: L2 disk cache instance
            l3: Optional L3 GPU cache instance
        """
        self.l1 = l1
        self.l2 = l2
        self.l3 = l3
        self.stats = CacheStats()

    def get(self, key: str) -> Optional[Any]:
        """Get value from cache with L1 -> L2 -> L3 fallback.
        
        Promotes values from L2/L3 to L1 on successful read.
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None if not found
        """
        # Try L1
        v = self.l1.get(key)
        if v is not None:
            self.stats.record_l1_hit()
            return v

        # Try L2
        v = self.l2.get(key)
        if v is not None:
            self.stats.record_l2_hit()
            try:
                # Promote to L1 without changing TTL
                self.l1.set(key, v)
            except Exception:
                # Ignore promotion failures
                pass
            return v

        # Try L3 if present
        if self.l3 is not None:
            try:
                v = self.l3.get(key)
            except Exception:
                v = None

            if v is not None:
                self.stats.record_l3_hit()
                try:
                    self.l1.set(key, v)
                    self.l2.set(key, v)
                except Exception:
                    pass
                return v

        # Miss in all tiers
        self.stats.record_miss()
        return None

    def set(self, key: str, value: Any, ttl: Optional[int] = None):
        """Set value in all cache tiers.
        
        Args:
            key: Cache key
            value: Value to cache
            ttl: Optional time-to-live in seconds
        """
        # Write to L1 and L2. Ignore exceptions to be robust.
        try:
            self.l1.set(key, value, ttl=ttl)
        except Exception:
            pass

        try:
            self.l2.set(key, value, ttl=ttl)
        except Exception:
            pass

        if self.l3 is not None:
            try:
                # L3 may be a stub; call set if available
                set_fn = getattr(self.l3, "set", None)
                if callable(set_fn):
                    set_fn(key, value)
            except Exception:
                pass

    def invalidate(self, key: str):
        """Remove key from all cache tiers.
        
        Args:
            key: Cache key to delete
        """
        try:
            self.l1.delete(key)
        except Exception:
            pass

        try:
            self.l2.delete(key)
        except Exception:
            pass

        if self.l3 is not None:
            try:
                delete_fn = getattr(self.l3, "delete", None)
                if callable(delete_fn):
                    delete_fn(key)
            except Exception:
                pass

    def clear_all(self):
        """Clear all cache tiers."""
        try:
            self.l1.clear()
        except Exception:
            pass

        try:
            self.l2.clear()
        except Exception:
            pass

        if self.l3 is not None:
            try:
                clear_fn = getattr(self.l3, "clear", None)
                if callable(clear_fn):
                    clear_fn()
            except Exception:
                pass
    
    def is_ready(self) -> bool:
        """Check if all cache tiers are ready (useful for async warming).
        
        Returns:
            True if all tiers initialized, False if any still warming
        """
        # L1 is always ready (in-memory)
        # Check L2 if it has is_ready method
        if hasattr(self.l2, 'is_ready') and callable(self.l2.is_ready):
            if not self.l2.is_ready():
                return False
        
        # L3 check if present
        if self.l3 is not None:
            if hasattr(self.l3, 'is_ready') and callable(self.l3.is_ready):
                if not self.l3.is_ready():
                    return False
        
        return True
    
    def get_stats(self) -> Dict[str, Any]:
        """Get comprehensive cache statistics.
        
        Returns:
            Dictionary with all cache metrics including:
            - Hit/miss counts and rates
            - Cache usage (MB used / MB budget)
            - Performance metrics
            - Cost savings estimates
        """
        # Get size info for each tier
        l1_size_mb = self.l1.size_mb() if hasattr(self.l1, 'size_mb') else 0.0
        l1_max_mb = getattr(self.l1, 'max_size_bytes', 0) / (1024 * 1024)
        
        l2_size_mb = self.l2.size_mb() if hasattr(self.l2, 'size_mb') else 0.0
        l2_max_mb = getattr(self.l2, 'max_size_mb', 0)
        
        l3_size_mb = 0.0
        l3_max_mb = 0.0
        if self.l3 is not None:
            l3_size_mb = self.l3.vram_mb() if hasattr(self.l3, 'vram_mb') else 0.0
            l3_max_mb = getattr(self.l3, 'max_vram_mb', 0)
        
        # Calculate total operations
        total_ops = (self.stats.l1_hits + self.stats.l2_hits + 
                    self.stats.l3_hits + self.stats.misses)
        
        # Calculate hit rates
        overall_hit_rate = self.stats.hit_rate()
        l1_rate = (self.stats.l1_hits / total_ops) if total_ops > 0 else 0.0
        l2_rate = (self.stats.l2_hits / total_ops) if total_ops > 0 else 0.0
        l3_rate = (self.stats.l3_hits / total_ops) if total_ops > 0 else 0.0
        miss_rate = (self.stats.misses / total_ops) if total_ops > 0 else 0.0
        
        # Estimate cost savings (assume $0.05 per LLM call avoided)
        total_hits = self.stats.l1_hits + self.stats.l2_hits + self.stats.l3_hits
        estimated_savings = total_hits * 0.05
        
        return {
            # Hit/miss statistics
            "l1_hits": self.stats.l1_hits,
            "l2_hits": self.stats.l2_hits,
            "l3_hits": self.stats.l3_hits,
            "misses": self.stats.misses,
            "total_operations": total_ops,
            "overall_hit_rate": overall_hit_rate,
            "l1_hit_rate": l1_rate,
            "l2_hit_rate": l2_rate,
            "l3_hit_rate": l3_rate,
            "miss_rate": miss_rate,
            
            # Cache usage
            "l1_size_mb": l1_size_mb,
            "l1_max_mb": l1_max_mb,
            "l1_usage_percent": (l1_size_mb / l1_max_mb * 100) if l1_max_mb > 0 else 0,
            "l2_size_mb": l2_size_mb,
            "l2_max_mb": l2_max_mb,
            "l2_usage_percent": (l2_size_mb / l2_max_mb * 100) if l2_max_mb > 0 else 0,
            "l3_size_mb": l3_size_mb,
            "l3_max_mb": l3_max_mb,
            "l3_usage_percent": (l3_size_mb / l3_max_mb * 100) if l3_max_mb > 0 else 0,
            
            # Evictions
            "l1_evictions": self.stats.l1_evictions,
            "l2_evictions": self.stats.l2_evictions,
            
            # Cost savings
            "llm_calls_avoided": total_hits,
            "estimated_savings_usd": estimated_savings,
        }


