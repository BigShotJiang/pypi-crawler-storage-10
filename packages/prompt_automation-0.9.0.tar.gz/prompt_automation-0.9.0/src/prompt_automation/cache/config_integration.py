"""Cache configuration integration and factory functions."""

from pathlib import Path
from typing import Optional

from prompt_automation.cache.l1_memory import L1Cache
from prompt_automation.cache.l2_disk import L2Cache
from prompt_automation.cache.l3_gpu import L3Cache
from prompt_automation.cache.manager import CacheManager


def create_cache_from_config(config, cache_dir: Optional[Path] = None, warm_async: bool = True) -> Optional[CacheManager]:
    """Create CacheManager from configuration object.
    
    Args:
        config: Config object with cache settings
        cache_dir: Optional cache directory (default: ~/.prompt-automation/cache)
        warm_async: If True, warm L2 cache in background (faster startup)
        
    Returns:
        CacheManager instance or None if caching is disabled
        
    Example:
        from prompt_automation.settings import ConfigManager
        from prompt_automation.cache import create_cache_from_config
        
        cm = ConfigManager()
        cache = create_cache_from_config(cm.config)
        if cache:
            cache.set("key", "value")
    """
    # Extract cache config
    try:
        cache_config = config.cache
        enabled = cache_config.enabled
        memory_mb = cache_config.memory_mb
        disk_mb = cache_config.disk_mb
        compression_level = getattr(cache_config, 'compression_level', 6)  # Default to 6 if not set
    except AttributeError:
        # Fallback if config doesn't have cache attribute
        return None
    
    if not enabled:
        return None
    
    # Determine cache directory
    if cache_dir is None:
        from prompt_automation.config import HOME_DIR
        cache_dir = HOME_DIR / "cache"
    
    cache_dir = Path(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)
    
    # Create cache tiers
    l1 = L1Cache(max_size_mb=memory_mb)
    l2 = L2Cache(cache_dir=cache_dir, max_size_mb=disk_mb, 
                 compression_level=compression_level, warm_async=warm_async)
    l3 = L3Cache()  # Stub for now
    
    return CacheManager(l1, l2, l3)
