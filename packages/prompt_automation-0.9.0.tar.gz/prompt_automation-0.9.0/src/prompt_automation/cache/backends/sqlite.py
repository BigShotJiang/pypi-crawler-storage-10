"""SQLite-based cache backend for offline persistence.

This backend provides persistent caching using SQLite with:
- WAL mode for atomic writes and crash resistance
- Automatic compression with gzip
- TTL-based expiration
- LRU eviction at size limit
- Corruption detection and recovery
"""

import gzip
import logging
import pickle
import sqlite3
import time
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)


class SQLiteCacheBackend:
    """SQLite-based persistent cache backend.
    
    Uses WAL mode for atomic writes, gzip compression for storage efficiency,
    and automatic corruption recovery.
    
    Args:
        db_path: Path to SQLite database file
        max_size_mb: Maximum cache size in megabytes (default: 100MB)
    
    Example:
        >>> backend = SQLiteCacheBackend(Path("cache.db"))
        >>> backend.set("key", {"data": "value"}, ttl=3600)
        >>> backend.get("key")
        {'data': 'value'}
    """
    
    def __init__(self, db_path: Path, max_size_mb: int = 100):
        """Initialize SQLite cache backend.
        
        Args:
            db_path: Path to SQLite database file
            max_size_mb: Maximum cache size in megabytes
        """
        self.db_path = Path(db_path)
        self.max_size_mb = max_size_mb
        self.conn = None
        
        # Initialize database
        self._initialize_db()
    
    def _initialize_db(self):
        """Initialize database with schema and WAL mode."""
        try:
            # Ensure parent directory exists
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Connect to database
            self.conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
            
            # Enable WAL mode for atomic writes
            self.conn.execute("PRAGMA journal_mode=WAL")
            
            # Check for corruption
            cursor = self.conn.execute("PRAGMA integrity_check")
            result = cursor.fetchone()[0]
            
            if result != "ok":
                logger.error(f"SQLite cache corrupted: {result}")
                self._recover_from_corruption()
                return
            
            # Create schema if not exists
            self.conn.execute("""
                CREATE TABLE IF NOT EXISTS cache (
                    key TEXT PRIMARY KEY,
                    value BLOB NOT NULL,
                    expires_at INTEGER,
                    last_accessed INTEGER NOT NULL,
                    size_bytes INTEGER NOT NULL
                )
            """)
            
            # Create indexes for performance
            self.conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_expires_at 
                ON cache(expires_at)
            """)
            
            self.conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_last_accessed 
                ON cache(last_accessed)
            """)
            
            self.conn.commit()
            
            logger.debug(f"SQLite cache initialized at {self.db_path}")
            
        except sqlite3.DatabaseError as e:
            logger.error(f"SQLite database error: {e}")
            self._recover_from_corruption()
    
    def _recover_from_corruption(self):
        """Recover from corrupted database by deleting and recreating."""
        logger.warning(f"Recovering from corruption: deleting {self.db_path}")
        
        # Close connection if open
        if self.conn:
            try:
                self.conn.close()
            except Exception:
                pass
        
        # Delete corrupted file
        try:
            if self.db_path.exists():
                self.db_path.unlink()
        except Exception as e:
            logger.error(f"Failed to delete corrupted DB: {e}")
        
        # Reinitialize
        try:
            self.conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
            self.conn.execute("PRAGMA journal_mode=WAL")
            
            # Create schema
            self.conn.execute("""
                CREATE TABLE cache (
                    key TEXT PRIMARY KEY,
                    value BLOB NOT NULL,
                    expires_at INTEGER,
                    last_accessed INTEGER NOT NULL,
                    size_bytes INTEGER NOT NULL
                )
            """)
            
            self.conn.execute("CREATE INDEX idx_expires_at ON cache(expires_at)")
            self.conn.execute("CREATE INDEX idx_last_accessed ON cache(last_accessed)")
            self.conn.commit()
            
            logger.info("SQLite cache recovered successfully")
        except Exception as e:
            logger.error(f"Failed to recover cache: {e}")
    
    def _serialize_value(self, value: Any) -> bytes:
        """Serialize and compress value for storage.
        
        Args:
            value: Python object to serialize
            
        Returns:
            Compressed bytes
        """
        # Pickle the value
        pickled = pickle.dumps(value)
        
        # Compress with gzip
        compressed = gzip.compress(pickled, compresslevel=6)
        
        return compressed
    
    def _deserialize_value(self, blob: bytes) -> Any:
        """Decompress and deserialize value from storage.
        
        Args:
            blob: Compressed bytes from database
            
        Returns:
            Deserialized Python object
        """
        # Decompress
        decompressed = gzip.decompress(blob)
        
        # Unpickle
        value = pickle.loads(decompressed)
        
        return value
    
    def _calculate_expires_at(self, ttl: Optional[int]) -> Optional[int]:
        """Calculate expiration timestamp from TTL.
        
        Args:
            ttl: Time-to-live in seconds, or None for no expiration
            
        Returns:
            Unix timestamp when entry expires, or None
        """
        if ttl is None:
            return None
        
        return int(time.time()) + ttl
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache.
        
        Automatically prunes expired entries and updates last_accessed timestamp.
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None if not found or expired
        """
        try:
            # Prune expired entries first
            self.prune_expired()
            
            # Query for value
            cursor = self.conn.execute("""
                SELECT value, expires_at FROM cache WHERE key = ?
            """, (key,))
            
            row = cursor.fetchone()
            
            if row is None:
                return None
            
            value_blob, expires_at = row
            
            # Check if expired
            if expires_at is not None and expires_at < int(time.time()):
                # Delete expired entry
                self.conn.execute("DELETE FROM cache WHERE key = ?", (key,))
                self.conn.commit()
                return None
            
            # Update last_accessed timestamp
            self.conn.execute("""
                UPDATE cache SET last_accessed = ? WHERE key = ?
            """, (int(time.time()), key))
            self.conn.commit()
            
            # Deserialize and return
            return self._deserialize_value(value_blob)
            
        except Exception as e:
            logger.error(f"Error reading from cache: {e}")
            return None
    
    def set(self, key: str, value: Any, ttl: Optional[int] = None):
        """Set value in cache.
        
        Args:
            key: Cache key
            value: Value to cache
            ttl: Time-to-live in seconds, or None for no expiration
        """
        try:
            # Serialize value
            value_blob = self._serialize_value(value)
            size_bytes = len(value_blob)
            
            # Calculate expiration
            expires_at = self._calculate_expires_at(ttl)
            
            # Insert or replace
            self.conn.execute("""
                INSERT OR REPLACE INTO cache (key, value, expires_at, last_accessed, size_bytes)
                VALUES (?, ?, ?, ?, ?)
            """, (key, value_blob, expires_at, int(time.time()), size_bytes))
            
            self.conn.commit()
            
            # Enforce size limit
            self._enforce_size_limit()
            
        except Exception as e:
            logger.error(f"Error writing to cache: {e}")
    
    def delete(self, key: str):
        """Delete key from cache.
        
        Args:
            key: Cache key to delete
        """
        try:
            self.conn.execute("DELETE FROM cache WHERE key = ?", (key,))
            self.conn.commit()
        except Exception as e:
            logger.error(f"Error deleting from cache: {e}")
    
    def get_stale(self, key: str) -> Optional[Any]:
        """Get value from cache ignoring expiration (for offline fallback).
        
        This method serves stale data when network is unavailable. It ignores
        the expires_at timestamp and returns the value regardless of age.
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None if key doesn't exist
        """
        try:
            cursor = self.conn.execute("""
                SELECT value FROM cache WHERE key = ?
            """, (key,))
            
            row = cursor.fetchone()
            
            if row is None:
                return None
            
            value_blob = row[0]
            
            # Deserialize and return (ignore expiration)
            logger.debug(f"Serving stale cache for key: {key}")
            return self._deserialize_value(value_blob)
            
        except Exception as e:
            logger.error(f"Error reading stale cache: {e}")
            return None
    
    def prune_expired(self):
        """Delete expired entries from cache."""
        try:
            now = int(time.time())
            cursor = self.conn.execute("""
                DELETE FROM cache WHERE expires_at IS NOT NULL AND expires_at < ?
            """, (now,))
            
            deleted_count = cursor.rowcount
            
            if deleted_count > 0:
                logger.debug(f"Pruned {deleted_count} expired cache entries")
            
            self.conn.commit()
            
        except Exception as e:
            logger.error(f"Error pruning expired entries: {e}")
    
    def _enforce_size_limit(self):
        """Enforce cache size limit by deleting oldest entries (LRU).
        
        This is called after each set() to ensure cache stays under max_size_mb.
        Evicts entries until cache is at 90% of limit to avoid constant eviction.
        """
        try:
            # Calculate total size
            cursor = self.conn.execute("SELECT SUM(size_bytes) FROM cache")
            total_size = cursor.fetchone()[0] or 0
            
            max_bytes = self.max_size_mb * 1024 * 1024
            
            # Only evict if we exceed the limit
            if total_size <= max_bytes:
                return
            
            # Calculate how much to delete (aim for 90% of limit to reduce churn)
            target_bytes = int(0.9 * max_bytes)
            bytes_to_delete = total_size - target_bytes
            
            # Get entries sorted by LRU (oldest first)
            cursor = self.conn.execute("""
                SELECT key, size_bytes FROM cache 
                ORDER BY last_accessed ASC
            """)
            
            deleted_bytes = 0
            deleted_keys = []
            
            # Collect keys to delete until we've freed enough space
            for key, size_bytes in cursor:
                deleted_keys.append(key)
                deleted_bytes += size_bytes
                
                if deleted_bytes >= bytes_to_delete:
                    break
            
            # Delete the keys in a single transaction
            if deleted_keys:
                placeholders = ",".join("?" * len(deleted_keys))
                self.conn.execute(f"DELETE FROM cache WHERE key IN ({placeholders})", deleted_keys)
                self.conn.commit()
                
                logger.info(
                    f"Evicted {len(deleted_keys)} entries "
                    f"({deleted_bytes / 1024 / 1024:.1f}MB) due to size limit. "
                    f"New size: {(total_size - deleted_bytes) / 1024 / 1024:.1f}MB"
                )
        
        except Exception as e:
            logger.error(f"Error enforcing size limit: {e}")
    
    def close(self):
        """Close database connection."""
        if self.conn:
            self.conn.close()
            self.conn = None
    
    def __del__(self):
        """Cleanup on deletion."""
        self.close()
