"""MCP integration with caching layer.

Provides CachedMCPClient that wraps MCP call_tool() with multi-tier caching.
"""
import hashlib
import json
import logging
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Optional

from ..mcp.client import call_tool
from .manager import CacheManager
from .stats import CacheStats
from .l1_memory import L1Cache
from .l2_disk import L2Cache
from .l3_gpu import L3Cache

logger = logging.getLogger(__name__)


class CachedMCPClient:
    """MCP client with multi-tier caching for tool results.
    
    Caches tool invocation results to reduce redundant calls to MCP providers.
    Cache keys are generated from provider_id + tool_name + arguments.
    
    Example:
        >>> client = CachedMCPClient(memory_mb=10, disk_path=Path("cache"))
        >>> result = client.call_tool(
        ...     provider_id="obsidian",
        ...     tool_name="search_notes",
        ...     arguments={"query": "test"}
        ... )
    """
    
    def __init__(
        self,
        memory_mb: int = 10,
        disk_path: Optional[Path] = None,
        ttl_seconds: int = 300,
        similarity_threshold: float = 0.5
    ):
        """Initialize cached MCP client.
        
        Args:
            memory_mb: L1 cache size in MB
            disk_path: L2 cache directory (None disables disk cache)
            ttl_seconds: Time-to-live for cached results
            similarity_threshold: Threshold for semantic search (0.0-1.0)
        """
        self.ttl_seconds = ttl_seconds
        self.similarity_threshold = similarity_threshold
        
        # Initialize cache layers
        l1 = L1Cache(max_size_mb=memory_mb)
        l2 = L2Cache(cache_dir=disk_path) if disk_path else None
        l3 = L3Cache()  # Stub for now
        
        self.cache_manager = CacheManager(l1=l1, l2=l2, l3=l3)
        self.stats = CacheStats()
    
    def _generate_cache_key(
        self,
        provider_id: str,
        tool_name: str,
        arguments: Optional[Dict[str, Any]]
    ) -> str:
        """Generate cache key from tool call parameters.
        
        Args:
            provider_id: MCP provider identifier
            tool_name: Tool name to invoke
            arguments: Tool arguments
            
        Returns:
            SHA256 hash of canonicalized parameters
        """
        # Canonicalize arguments (sort keys for consistency)
        args_str = json.dumps(arguments or {}, sort_keys=True)
        
        # Create unique key from provider + tool + args
        key_data = f"{provider_id}:{tool_name}:{args_str}"
        return hashlib.sha256(key_data.encode()).hexdigest()[:16]
    
    def call_tool(
        self,
        provider_id: str,
        tool_name: str,
        arguments: Optional[Dict[str, Any]] = None,
        *,
        registry_path: Path,
        credentials_path: Optional[Path] = None,
        accepted: Optional[Iterable[str]] = None,
        env: Optional[Mapping[str, str]] = None,
    ) -> Dict[str, Any]:
        """Invoke MCP tool with caching.
        
        Args:
            provider_id: MCP provider identifier
            tool_name: Tool name to invoke
            arguments: Tool arguments
            registry_path: Path to MCP registry
            credentials_path: Path to credentials file
            accepted: Accepted consent identifiers
            env: Environment variables
            
        Returns:
            Tool result (from cache or fresh call)
        """
        cache_key = self._generate_cache_key(provider_id, tool_name, arguments)
        
        # Try cache first
        cached = self.cache_manager.get(cache_key)
        if cached is not None:
            logger.debug(f"Cache hit for {provider_id}.{tool_name}")
            self.stats.l1_hits += 1  # Simplified (manager handles tier tracking)
            return cached
        
        # Cache miss - call real MCP client
        logger.debug(f"Cache miss for {provider_id}.{tool_name}")
        self.stats.misses += 1
        
        result = call_tool(
            provider_id=provider_id,
            tool_name=tool_name,
            arguments=arguments,
            registry_path=registry_path,
            credentials_path=credentials_path,
            accepted=accepted,
            env=env
        )
        
        # Store in cache with TTL
        self.cache_manager.set(cache_key, result, ttl=self.ttl_seconds)
        
        return result
    
    def invalidate_provider(self, provider_id: str) -> None:
        """Invalidate all cached results for a provider.
        
        Args:
            provider_id: Provider identifier to invalidate
        """
        # Note: This is a simplified implementation that clears all cache
        # A production implementation would track provider-specific keys
        logger.info(f"Invalidating cache for provider: {provider_id}")
        self.cache_manager.clear_all()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics.
        
        Returns:
            Dictionary with hit/miss rates and other metrics
        """
        return self.stats.to_dict()
