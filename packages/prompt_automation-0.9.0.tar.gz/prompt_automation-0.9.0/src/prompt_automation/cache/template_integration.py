"""Template rendering integration with caching layer.

Provides CachedTemplateRenderer that wraps render_template() with multi-tier caching.
"""
import hashlib
import json
import logging
from pathlib import Path
from typing import Any, Dict, Optional

from ..menus import render_template
from .manager import CacheManager
from .stats import CacheStats
from .l1_memory import L1Cache
from .l2_disk import L2Cache
from .l3_gpu import L3Cache

logger = logging.getLogger(__name__)


class CachedTemplateRenderer:
    """Template renderer with multi-tier caching.
    
    Caches rendered template output to reduce redundant rendering operations.
    Cache keys are generated from template ID + variable values + file mtime.
    
    Example:
        >>> renderer = CachedTemplateRenderer(memory_mb=10, disk_path=Path("cache"))
        >>> result = renderer.render(template, {"name": "World"})
    """
    
    def __init__(
        self,
        memory_mb: int = 10,
        disk_path: Optional[Path] = None,
        ttl_seconds: int = 300,
        check_file_mtime: bool = False
    ):
        """Initialize cached template renderer.
        
        Args:
            memory_mb: L1 cache size in MB
            disk_path: L2 cache directory (None disables disk cache)
            ttl_seconds: Time-to-live for cached results
            check_file_mtime: Check template file modification time for invalidation
        """
        self.ttl_seconds = ttl_seconds
        self.check_file_mtime = check_file_mtime
        
        # Initialize cache layers
        l1 = L1Cache(max_size_mb=memory_mb)
        l2 = L2Cache(cache_dir=disk_path) if disk_path else None
        l3 = L3Cache()  # Stub for now
        
        self.cache_manager = CacheManager(l1=l1, l2=l2, l3=l3)
        self.stats = CacheStats()
        
        # Track template file mtimes for invalidation
        self._file_mtimes: Dict[int, float] = {}
    
    def _get_template_mtime(self, tmpl: Dict[str, Any]) -> Optional[float]:
        """Get modification time of template file if available.
        
        Args:
            tmpl: Template dictionary
            
        Returns:
            File modification time or None if not available
        """
        if not self.check_file_mtime:
            return None
        
        metadata = tmpl.get("metadata")
        if not isinstance(metadata, dict):
            return None
        
        file_path = metadata.get("path")
        if not file_path:
            return None
        
        try:
            return Path(file_path).stat().st_mtime
        except (OSError, ValueError):
            return None
    
    def _generate_cache_key(
        self,
        tmpl: Dict[str, Any],
        values: Optional[Dict[str, Any]]
    ) -> str:
        """Generate cache key from template and values.
        
        Args:
            tmpl: Template dictionary
            values: Variable values
            
        Returns:
            SHA256 hash of canonicalized template + values
        """
        # Use template ID as primary key component
        template_id = tmpl.get("id", 0)
        
        # Canonicalize values (sort keys for consistency)
        values_str = json.dumps(values or {}, sort_keys=True)
        
        # Include file mtime in cache key if checking enabled
        mtime = self._get_template_mtime(tmpl)
        mtime_str = f":{mtime}" if mtime is not None else ""
        
        # Create unique key from template ID + values + mtime
        key_data = f"{template_id}:{values_str}{mtime_str}"
        return hashlib.sha256(key_data.encode()).hexdigest()[:16]
    
    def render(
        self,
        tmpl: Dict[str, Any],
        values: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> str:
        """Render template with caching.
        
        Args:
            tmpl: Template dictionary
            values: Variable values for placeholders
            **kwargs: Additional arguments passed to render_template
            
        Returns:
            Rendered template string (from cache or fresh render)
        """
        cache_key = self._generate_cache_key(tmpl, values)
        
        # Try cache first
        cached = self.cache_manager.get(cache_key)
        if cached is not None:
            template_id = tmpl.get("id", "unknown")
            logger.debug(f"Cache hit for template {template_id}")
            self.stats.l1_hits += 1  # Simplified (manager handles tier tracking)
            return cached
        
        # Cache miss - render template
        template_id = tmpl.get("id", "unknown")
        logger.debug(f"Cache miss for template {template_id}")
        self.stats.misses += 1
        
        result = render_template(tmpl, values, **kwargs)
        
        # Handle tuple return (when return_vars=True)
        if isinstance(result, tuple):
            rendered_str = result[0]
        else:
            rendered_str = result
        
        # Store in cache with TTL
        self.cache_manager.set(cache_key, rendered_str, ttl=self.ttl_seconds)
        
        # Track file mtime for this template
        template_id_int = tmpl.get("id")
        if isinstance(template_id_int, int):
            mtime = self._get_template_mtime(tmpl)
            if mtime is not None:
                self._file_mtimes[template_id_int] = mtime
        
        return rendered_str
    
    def invalidate_template(self, template_id: int) -> None:
        """Invalidate all cached results for a specific template.
        
        Args:
            template_id: Template ID to invalidate
        """
        # Note: This is a simplified implementation that clears all cache
        # A production implementation would track template-specific keys
        logger.info(f"Invalidating cache for template: {template_id}")
        self.cache_manager.clear_all()
        
        # Clear mtime tracking
        self._file_mtimes.pop(template_id, None)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics.
        
        Returns:
            Dictionary with hit/miss rates and other metrics
        """
        return self.stats.to_dict()
