"""L2 persistent disk cache with compression and LRU eviction."""

import gzip
import json
import time
import logging
import threading
from pathlib import Path
from diskcache import Cache
from typing import Any, Optional

logger = logging.getLogger(__name__)


class L2Cache:
    """Persistent disk cache with compression using diskcache library."""
    
    def __init__(self, cache_dir: Path, max_size_mb: int = 100,
                 circuit_breaker_enabled: bool = True,
                 circuit_breaker_threshold: int = 5,
                 circuit_breaker_timeout: int = 60,
                 compression_level: int = 6,
                 warm_async: bool = False):
        """Initialize L2 cache with disk persistence.
        
        Args:
            cache_dir: Directory for cache storage
            max_size_mb: Maximum cache size in megabytes
            circuit_breaker_enabled: Enable circuit breaker pattern
            circuit_breaker_threshold: Failures before opening circuit
            circuit_breaker_timeout: Seconds before attempting recovery
            compression_level: Gzip compression level (1=fast, 9=max compression)
            warm_async: If True, initialize cache in background thread (faster startup)
        """
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # Compression settings
        self.compression_level = max(1, min(9, compression_level))  # Clamp 1-9
        
        # Async warming state
        self.warm_async = warm_async
        self._cache_ready = threading.Event()
        self._cache = None
        self._cache_lock = threading.Lock()
        self.max_size_mb = max_size_mb
        
        # Circuit breaker state
        self.circuit_breaker_enabled = circuit_breaker_enabled
        self.circuit_breaker_threshold = circuit_breaker_threshold
        self.circuit_breaker_timeout = circuit_breaker_timeout
        self.failure_count = 0
        self.circuit_open = False
        self.last_failure_time = None
        self._circuit_open_logged = False
        
        # Initialize cache (sync or async)
        if warm_async:
            # Start warming in background
            thread = threading.Thread(target=self._warm_cache, daemon=True)
            thread.start()
        else:
            # Initialize synchronously (original behavior)
            self._initialize_cache()
            self._cache_ready.set()
    
    def _initialize_cache(self):
        """Initialize the diskcache Cache object."""
        with self._cache_lock:
            if self._cache is None:
                self._cache = Cache(
                    directory=str(self.cache_dir),
                    size_limit=self.max_size_mb * 1024 * 1024,
                    eviction_policy='least-recently-used'
                )
    
    def _warm_cache(self):
        """Background task to warm the cache (async initialization)."""
        try:
            logger.info("L2 cache warming started (async)")
            self._initialize_cache()
            self._cache_ready.set()
            logger.info("L2 cache warming complete")
        except Exception as e:
            logger.error(f"L2 cache warming failed: {e}")
            self._cache_ready.set()  # Set anyway to unblock operations
    
    @property
    def cache(self):
        """Get the cache object, waiting if needed during async warming."""
        if self._cache is None:
            # If async warming is in progress, wait for it
            if self.warm_async:
                self._cache_ready.wait(timeout=5)  # Wait up to 5s
            # If still None, initialize synchronously as fallback
            if self._cache is None:
                self._initialize_cache()
        return self._cache
    
    def is_ready(self) -> bool:
        """Check if cache is ready (useful for async warming).
        
        Returns:
            True if cache fully initialized, False if still warming
        """
        return self._cache_ready.is_set()
    
    def _check_circuit(self) -> bool:
        """Check if circuit breaker allows operation.
        
        Returns:
            True if operation allowed, False if circuit open
        """
        if not self.circuit_breaker_enabled:
            return True
        
        if not self.circuit_open:
            return True
        
        # Circuit open - check if timeout elapsed (attempt recovery)
        if time.time() - self.last_failure_time > self.circuit_breaker_timeout:
            logger.info("Circuit breaker: Attempting recovery (HALF-OPEN state)")
            return True  # Try one operation (half-open state)
        
        return False  # Circuit still open, fail fast
    
    def _record_success(self):
        """Record successful operation (close circuit if open)."""
        if self.circuit_open:
            logger.info("Circuit breaker: Recovery successful (CLOSED state)")
            self.circuit_open = False
            self._circuit_open_logged = False
        self.failure_count = 0
    
    def _record_failure(self, operation: str, error: Exception):
        """Record failed operation (potentially open circuit).
        
        Args:
            operation: Name of operation that failed
            error: Exception that occurred
        """
        if not self.circuit_breaker_enabled:
            return
        
        self.failure_count += 1
        self.last_failure_time = time.time()
        
        if self.failure_count >= self.circuit_breaker_threshold:
            if not self.circuit_open:
                self.circuit_open = True
                logger.error(
                    f"Circuit breaker: OPEN after {self.failure_count} failures. "
                    f"L2 cache disabled for {self.circuit_breaker_timeout}s. "
                    f"Last error: {error}"
                )
                self._circuit_open_logged = True
            elif not self._circuit_open_logged:
                # Recovery attempt failed
                logger.warning(
                    f"Circuit breaker: Recovery failed, staying OPEN for "
                    f"{self.circuit_breaker_timeout}s"
                )
                self._circuit_open_logged = True
    
    def circuit_state(self) -> str:
        """Get current circuit breaker state.
        
        Returns:
            "CLOSED" (normal), "OPEN" (failing), or "HALF-OPEN" (recovering)
        """
        if not self.circuit_breaker_enabled:
            return "DISABLED"
        
        if not self.circuit_open:
            return "CLOSED"
        
        if time.time() - self.last_failure_time > self.circuit_breaker_timeout:
            return "HALF-OPEN"
        
        return "OPEN"
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from disk cache.
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None if not found/expired/corrupted
        """
        if not self._check_circuit():
            return None  # Circuit open, fail fast
        
        try:
            compressed_value = self.cache.get(key)
            if compressed_value is None:
                self._record_success()
                return None
            
            # Decompress and deserialize
            try:
                json_bytes = gzip.decompress(compressed_value)
                value = json.loads(json_bytes)
                self._record_success()
                return value
            except (gzip.BadGzipFile, json.JSONDecodeError, TypeError) as e:
                # Corrupted entry - delete and return None (not a circuit failure)
                self.delete(key)
                return None
        except Exception as e:
            self._record_failure("get", e)
            return None
    
    def set(self, key: str, value: Any, ttl: Optional[int] = None):
        """Set value in disk cache with optional TTL.
        
        Args:
            key: Cache key
            value: Value to cache (must be JSON-serializable)
            ttl: Time-to-live in seconds (None = no expiry)
        """
        if not self._check_circuit():
            return  # Circuit open, fail fast
        
        try:
            # Serialize and compress
            json_bytes = json.dumps(value).encode('utf-8')
            compressed_value = gzip.compress(json_bytes, compresslevel=self.compression_level)
            
            # Store with optional TTL
            if ttl:
                self.cache.set(key, compressed_value, expire=ttl)
            else:
                self.cache.set(key, compressed_value)
            
            self._record_success()
        except Exception as e:
            self._record_failure("set", e)
    
    def delete(self, key: str):
        """Remove key from cache.
        
        Args:
            key: Cache key to delete
        """
        self.cache.delete(key)
    
    def clear(self):
        """Clear entire cache."""
        self.cache.clear()
    
    def size_mb(self) -> float:
        """Get current cache size in megabytes.
        
        Returns:
            Current disk usage in MB
        """
        return self.cache.volume() / (1024 * 1024)
