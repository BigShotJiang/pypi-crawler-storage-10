"""LLM caching integration with semantic deduplication."""

import hashlib
from typing import Optional

from prompt_automation.cache.semantic_hash import semantic_similarity


class CachedLLMClient:
    """Wrapper around LLMClient that caches responses with semantic deduplication.
    
    Features:
    - Caches LLM responses to avoid redundant API calls
    - Semantic deduplication: similar prompts share cached responses
    - TTL support: cached responses expire after configured time
    - Stats tracking: records cache hits/misses for monitoring
    
    Example:
        from prompt_automation.commands.llm_client import LLMClient
        from prompt_automation.cache import CacheManager, create_cache_from_config
        from prompt_automation.cache.llm_integration import CachedLLMClient
        
        cache = create_cache_from_config(config)
        client = LLMClient()
        cached_client = CachedLLMClient(client, cache)
        
        # First call - cache miss, calls LLM
        result1 = cached_client.suggest_location("AI Project", "ML notes")
        
        # Second call - cache hit, returns cached response
        result2 = cached_client.suggest_location("AI Project", "ML notes")
    """
    
    def __init__(
        self,
        client,
        cache,
        similarity_threshold: float = 0.50,
        ttl_seconds: Optional[int] = 3600,
        stats=None
    ):
        """Initialize cached LLM client.
        
        Args:
            client: LLMClient instance to wrap
            cache: CacheManager instance
            similarity_threshold: Threshold for semantic similarity (0.0-1.0)
            ttl_seconds: Time-to-live for cached responses (None = no expiry)
            stats: Optional CacheStats instance for tracking
        """
        self.client = client
        self.cache = cache
        self.similarity_threshold = similarity_threshold
        self.ttl_seconds = ttl_seconds
        self.stats = stats
    
    def suggest_location(self, title: str, content: str) -> str:
        """Suggest folder location with caching.
        
        Args:
            title: Note title
            content: Note content
            
        Returns:
            Suggested folder path
        """
        # Create cache key
        prompt = f"suggest_location:{title}:{content}"
        cache_key = self._generate_cache_key(prompt)
        
        # Try cache first (with semantic deduplication)
        cached_result = self._get_with_semantic_search(prompt)
        if cached_result is not None:
            if self.stats:
                self.stats.record_l1_hit()  # Assume L1 for simplicity
            return cached_result
        
        # Cache miss - call actual LLM
        if self.stats:
            self.stats.record_miss()
        
        result = self.client.suggest_location(title, content)
        
        # Store in cache
        self.cache.set(cache_key, result, ttl=self.ttl_seconds)
        
        return result
    
    def interpret_natural_language(self, user_input: str) -> str:
        """Convert natural language to slash command with caching.
        
        Args:
            user_input: Natural language query
            
        Returns:
            Slash command string
        """
        # Create cache key
        prompt = f"interpret_nl:{user_input}"
        cache_key = self._generate_cache_key(prompt)
        
        # Try cache first
        cached_result = self._get_with_semantic_search(prompt)
        if cached_result is not None:
            if self.stats:
                self.stats.record_l1_hit()
            return cached_result
        
        # Cache miss - call actual LLM
        if self.stats:
            self.stats.record_miss()
        
        result = self.client.interpret_natural_language(user_input)
        
        # Store in cache
        self.cache.set(cache_key, result, ttl=self.ttl_seconds)
        
        return result
    
    def _generate_cache_key(self, prompt: str) -> str:
        """Generate cache key from prompt.
        
        Args:
            prompt: Input prompt text
            
        Returns:
            Cache key (SHA256 hash)
        """
        return hashlib.sha256(prompt.encode()).hexdigest()[:16]
    
    def _get_with_semantic_search(self, prompt: str) -> Optional[str]:
        """Try to get cached response with semantic deduplication.
        
        Searches cache for similar prompts (above similarity threshold)
        and returns cached response if found.
        
        Args:
            prompt: Input prompt text
            
        Returns:
            Cached response or None if not found
        """
        # First try exact match
        cache_key = self._generate_cache_key(prompt)
        result = self.cache.get(cache_key)
        if result is not None:
            return result
        
        # TODO: Implement semantic search across cached prompts
        # For now, just return None (exact match only)
        # Full implementation would:
        # 1. Get all cached keys
        # 2. Compare prompt to each cached prompt using semantic_similarity()
        # 3. Return cached response if similarity > threshold
        
        return None
