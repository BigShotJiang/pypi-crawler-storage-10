"""Statistics tracking for cache operations."""

from typing import Dict


class CacheStats:
    """Track cache hit/miss/eviction statistics across all tiers."""
    
    def __init__(self):
        """Initialize stats counters to zero."""
        self.l1_hits = 0
        self.l2_hits = 0
        self.l3_hits = 0
        self.misses = 0
        self.l1_evictions = 0
        self.l2_evictions = 0
    
    def record_l1_hit(self):
        """Record a cache hit in L1 tier."""
        self.l1_hits += 1
    
    def record_l2_hit(self):
        """Record a cache hit in L2 tier."""
        self.l2_hits += 1
    
    def record_l3_hit(self):
        """Record a cache hit in L3 tier."""
        self.l3_hits += 1
    
    def record_miss(self):
        """Record a cache miss (not found in any tier)."""
        self.misses += 1
    
    def record_l1_eviction(self):
        """Record an eviction from L1 tier."""
        self.l1_evictions += 1
    
    def record_l2_eviction(self):
        """Record an eviction from L2 tier."""
        self.l2_evictions += 1
    
    def hit_rate(self) -> float:
        """Calculate overall cache hit rate.
        
        Returns:
            Hit rate as float from 0.0 to 1.0
        """
        total_operations = self.l1_hits + self.l2_hits + self.l3_hits + self.misses
        
        if total_operations == 0:
            return 0.0
        
        total_hits = self.l1_hits + self.l2_hits + self.l3_hits
        return total_hits / total_operations
    
    def to_dict(self) -> Dict[str, float]:
        """Export all statistics as dictionary.
        
        Returns:
            Dictionary with all counters and calculated metrics
        """
        return {
            "l1_hits": self.l1_hits,
            "l2_hits": self.l2_hits,
            "l3_hits": self.l3_hits,
            "misses": self.misses,
            "l1_evictions": self.l1_evictions,
            "l2_evictions": self.l2_evictions,
            "hit_rate": self.hit_rate(),
        }
    
    def reset(self):
        """Reset all counters to zero."""
        self.l1_hits = 0
        self.l2_hits = 0
        self.l3_hits = 0
        self.misses = 0
        self.l1_evictions = 0
        self.l2_evictions = 0
