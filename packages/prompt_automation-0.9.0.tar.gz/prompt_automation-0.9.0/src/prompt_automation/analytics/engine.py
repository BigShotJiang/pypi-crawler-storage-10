"""Analytics Engine - Core event logging and storage (Feature 21.1).

This module provides the core analytics engine with SQLite storage,
event logging, and privacy controls.

Key Features:
- **Event Logging**: Templates, LLM calls, errors
- **Privacy**: Prompt hashing (SHA256), no PII
- **Auto-Rotation**: 100MB limit with archive
- **Async**: Non-blocking writes
- **Opt-Out**: Disable via config

Example:
    >>> from prompt_automation.analytics.engine import AnalyticsEngine
    >>>
    >>> engine = AnalyticsEngine()
    >>> await engine.initialize()
    >>>
    >>> # Log template render
    >>> await engine.log_template_render(
    ...     template_id=13008,
    ...     template_title="Project Creator",
    ...     duration_ms=125,
    ...     cache_hit=False
    ... )
    >>>
    >>> await engine.close()
"""

import aiosqlite
import json
import hashlib
import time
import asyncio
from pathlib import Path
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class AnalyticsEngine:
    """Core analytics engine with SQLite storage.
    
    Handles event logging, database management, and privacy controls.
    
    Thread Safety:
        Async-safe (single event loop), uses aiosqlite for concurrent access.
    """
    
    def __init__(
        self,
        db_path: Optional[Path] = None,
        max_size_mb: float = 100.0,
        enabled: bool = True
    ):
        """Initialize analytics engine.
        
        Args:
            db_path: Path to SQLite database. Defaults to ~/.prompt-automation/analytics.db
            max_size_mb: Maximum database size before rotation (default: 100 MB)
            enabled: Enable analytics tracking (default: True, set False to opt-out)
        """
        if db_path is None:
            from prompt_automation.platform_utils import get_app_home
            db_path = get_app_home() / "analytics.db"
        
        self.db_path = Path(db_path)
        self.max_size_mb = max_size_mb
        self.enabled = enabled
        self.db = None
        
        logger.info(
            f"AnalyticsEngine initialized: path={self.db_path}, "
            f"max_size={max_size_mb}MB, enabled={enabled}"
        )
    
    async def initialize(self):
        """Initialize database and create tables."""
        if not self.enabled:
            logger.info("Analytics disabled, skipping initialization")
            return
        
        # Create parent directory if needed
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Connect to database
        self.db = await aiosqlite.connect(str(self.db_path))
        
        # Enable WAL mode for better concurrency
        await self.db.execute("PRAGMA journal_mode=WAL")
        
        # Create tables
        await self._create_tables()
        
        logger.info(f"Analytics database initialized: {self.db_path}")
    
    async def close(self):
        """Close database connection."""
        if self.db:
            await self.db.close()
            logger.info("Analytics database closed")
    
    async def _create_tables(self):
        """Create database tables if they don't exist."""
        # Events table
        await self.db.execute("""
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_type TEXT NOT NULL,
                timestamp INTEGER NOT NULL,
                data TEXT NOT NULL
            )
        """)
        
        # Indexes for performance
        await self.db.execute("""
            CREATE INDEX IF NOT EXISTS idx_events_timestamp 
            ON events(timestamp)
        """)
        
        await self.db.execute("""
            CREATE INDEX IF NOT EXISTS idx_events_type 
            ON events(event_type)
        """)
        
        # Metadata table
        await self.db.execute("""
            CREATE TABLE IF NOT EXISTS metadata (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        
        await self.db.commit()
    
    async def log_template_render(
        self,
        template_id: int,
        template_title: str,
        duration_ms: float,
        cache_hit: bool,
        variables: Optional[Dict[str, str]] = None
    ):
        """Log template render event.
        
        Args:
            template_id: Template ID
            template_title: Template title
            duration_ms: Render duration in milliseconds
            cache_hit: Whether cache was hit
            variables: Template variables (values will be hashed)
        """
        if not self.enabled:
            return
        
        # Hash variable values for privacy
        hashed_vars = {}
        if variables:
            for key, value in variables.items():
                hashed_vars[key] = hashlib.sha256(str(value).encode()).hexdigest()
        
        event_data = {
            "template_id": template_id,
            "template_title": template_title,
            "timestamp": int(time.time()),
            "duration_ms": duration_ms,
            "cache_hit": cache_hit,
            "variables": hashed_vars
        }
        
        await self._log_event("template_render", event_data)
    
    async def log_llm_call(
        self,
        prompt: str,
        duration_ms: float,
        tokens_input: int,
        tokens_output: int,
        model: str,
        device: str,
        cache_hit: bool
    ):
        """Log LLM call event.
        
        Args:
            prompt: LLM prompt (will be hashed for privacy)
            duration_ms: Call duration in milliseconds
            tokens_input: Input tokens
            tokens_output: Output tokens
            model: Model name
            device: Device used (e.g., "cuda:0", "cpu")
            cache_hit: Whether cache was hit
        """
        if not self.enabled:
            return
        
        # Hash prompt for privacy
        prompt_hash = hashlib.sha256(prompt.encode()).hexdigest()
        prompt_preview = prompt[:50]  # First 50 chars for debugging
        
        event_data = {
            "prompt_hash": prompt_hash,
            "prompt_preview": prompt_preview,
            "timestamp": int(time.time()),
            "duration_ms": duration_ms,
            "tokens_input": tokens_input,
            "tokens_output": tokens_output,
            "model": model,
            "device": device,
            "cache_hit": cache_hit
        }
        
        await self._log_event("llm_call", event_data)
    
    async def log_error(
        self,
        error_type: str,
        error_message: str,
        stack_trace: str,
        context: Optional[Dict[str, Any]] = None
    ):
        """Log error event.
        
        Args:
            error_type: Error type (e.g., "TimeoutError")
            error_message: Error message
            stack_trace: Stack trace
            context: Additional context (template_id, etc.)
        """
        if not self.enabled:
            return
        
        event_data = {
            "error_type": error_type,
            "error_message": error_message,
            "stack_trace": stack_trace,
            "context": context or {},
            "timestamp": int(time.time())
        }
        
        await self._log_event("error", event_data)
    
    async def _log_event(self, event_type: str, data: Dict[str, Any]):
        """Internal method to log event to database.
        
        Args:
            event_type: Event type
            data: Event data (will be JSON encoded)
        """
        if not self.db:
            logger.warning("Database not initialized, skipping event log")
            return
        
        timestamp = int(time.time())
        data_json = json.dumps(data)
        
        await self.db.execute(
            "INSERT INTO events (event_type, timestamp, data) VALUES (?, ?, ?)",
            (event_type, timestamp, data_json)
        )
        await self.db.commit()
        
        # Check size and rotate if needed
        await self._check_and_rotate()
    
    async def _check_and_rotate(self):
        """Check database size and rotate if exceeds limit."""
        # Check file size
        if not self.db_path.exists():
            return
        
        size_mb = self.db_path.stat().st_size / (1024 * 1024)
        
        if size_mb > self.max_size_mb:
            logger.warning(f"Database size {size_mb:.1f}MB exceeds limit {self.max_size_mb}MB, rotating")
            await self._rotate_database()
    
    async def _rotate_database(self):
        """Rotate database: archive old data, clean current DB."""
        # Create archive filename with timestamp
        timestamp = datetime.now().strftime("%Y-%m-%d-%H%M%S")
        archive_path = self.db_path.parent / f"analytics-{timestamp}.db"
        
        # Copy current DB to archive
        import shutil
        shutil.copy2(self.db_path, archive_path)
        logger.info(f"Archived database to {archive_path}")
        
        # Delete old events (keep last 30 days)
        cutoff = int(time.time()) - (30 * 24 * 60 * 60)  # 30 days ago
        await self.db.execute("DELETE FROM events WHERE timestamp < ?", (cutoff,))
        await self.db.commit()
        
        # Vacuum to reclaim space
        await self.db.execute("VACUUM")
        
        # Update metadata
        await self.set_metadata("last_rotation", timestamp)
        
        logger.info("Database rotated successfully")
    
    async def _get_events(
        self,
        event_type: Optional[str] = None,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """Get events from database (for testing/querying).
        
        Args:
            event_type: Filter by event type (optional)
            limit: Maximum events to return
        
        Returns:
            List of event dicts
        """
        if not self.db:
            return []
        
        if event_type:
            cursor = await self.db.execute(
                "SELECT data FROM events WHERE event_type = ? ORDER BY timestamp DESC LIMIT ?",
                (event_type, limit)
            )
        else:
            cursor = await self.db.execute(
                "SELECT data FROM events ORDER BY timestamp DESC LIMIT ?",
                (limit,)
            )
        
        rows = await cursor.fetchall()
        events = [json.loads(row[0]) for row in rows]
        
        return events
    
    async def _get_tables(self) -> List[str]:
        """Get list of tables in database (for testing).
        
        Returns:
            List of table names
        """
        if not self.db:
            return []
        
        cursor = await self.db.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
        rows = await cursor.fetchall()
        return [row[0] for row in rows]
    
    async def set_metadata(self, key: str, value: str):
        """Store metadata key-value pair.
        
        Args:
            key: Metadata key
            value: Metadata value
        """
        if not self.db:
            return
        
        await self.db.execute(
            "INSERT OR REPLACE INTO metadata (key, value) VALUES (?, ?)",
            (key, value)
        )
        await self.db.commit()
    
    async def get_metadata(self, key: str) -> Optional[str]:
        """Retrieve metadata value.
        
        Args:
            key: Metadata key
        
        Returns:
            Metadata value or None if not found
        """
        if not self.db:
            return None
        
        cursor = await self.db.execute(
            "SELECT value FROM metadata WHERE key = ?",
            (key,)
        )
        row = await cursor.fetchone()
        
        return row[0] if row else None
