"""Background resource sampler for analytics.

Automatically samples resource metrics (CPU, RAM, GPU) at 1 Hz
and logs to analytics database.
"""

import time
import threading
import logging
from typing import Optional

logger = logging.getLogger(__name__)


class ResourceSampler:
    """Background thread that samples resources at 1 Hz."""
    
    def __init__(
        self,
        resource_monitor=None,
        analytics=None,
        sample_interval: float = 1.0
    ):
        """Initialize resource sampler.
        
        Args:
            resource_monitor: ResourceMonitor instance (Feature 20.2)
            analytics: Analytics instance (Feature 21)
            sample_interval: Sampling interval in seconds (default: 1.0)
        """
        self.resource_monitor = resource_monitor
        self.analytics = analytics
        self.sample_interval = sample_interval
        
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._running = False
    
    def start(self):
        """Start background sampling."""
        if self._running:
            logger.warning("ResourceSampler already running")
            return
        
        # Lazy import to avoid circular dependencies
        if self.resource_monitor is None:
            from prompt_automation.performance import ResourceMonitor
            self.resource_monitor = ResourceMonitor()
        
        if self.analytics is None:
            from prompt_automation.analytics import Analytics
            self.analytics = Analytics()
        
        self._stop_event.clear()
        self._running = True
        
        self._thread = threading.Thread(
            target=self._sample_loop,
            daemon=True,
            name="ResourceSampler"
        )
        self._thread.start()
        
        logger.info(f"ResourceSampler started (interval={self.sample_interval}s)")
    
    def stop(self):
        """Stop background sampling."""
        if not self._running:
            return
        
        self._stop_event.set()
        
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)
        
        self._running = False
        logger.info("ResourceSampler stopped")
    
    def is_running(self) -> bool:
        """Check if sampler is running."""
        return self._running
    
    def _sample_loop(self):
        """Main sampling loop (runs in background thread)."""
        while not self._stop_event.is_set():
            try:
                self._sample_once()
            except Exception as e:
                logger.error(f"Error sampling resources: {e}")
            
            # Sleep with interruptible wait
            self._stop_event.wait(self.sample_interval)
    
    def _sample_once(self):
        """Sample resources once and log to analytics."""
        try:
            metrics = self.resource_monitor.get_metrics()
            
            # Log to analytics
            self.analytics.log_resource_usage(
                cpu=metrics.get("cpu_percent", 0.0),
                ram_mb=metrics.get("ram_mb", 0),
                gpu_util=metrics.get("gpu_util", 0.0)
            )
        except Exception as e:
            logger.debug(f"Failed to sample resources: {e}")
    
    def __enter__(self):
        """Context manager entry."""
        self.start()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.stop()
