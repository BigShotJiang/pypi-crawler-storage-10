"""Pydantic models for configuration management.

This module defines type-safe configuration models using Pydantic.
All configuration values are validated at load time, catching errors
before they reach runtime.
"""

from pydantic import BaseModel, Field, field_validator, ConfigDict
from typing import Optional, Tuple


class LLMConfig(BaseModel):
    """LLM (Language Model) configuration."""
    
    enabled: bool = Field(True, description="Enable LLM server integration for AI-powered features")
    host: str = Field("127.0.0.1", description="LLM server hostname or IP address")
    port: int = Field(8080, ge=1024, le=65535, description="LLM server port (1024-65535)")
    timeout_s: int = Field(30, gt=0, description="Request timeout in seconds (min: 1)")
    max_tokens: int = Field(8192, gt=0, description="Maximum tokens for LLM responses (min: 1)")
    gpu_layers: int = Field(0, ge=0, le=100, description="Number of model layers to offload to GPU (0=CPU only, 35=full GPU, max: 100)")
    
    @field_validator('host')
    @classmethod
    def validate_host(cls, v: str) -> str:
        """Validate host is not empty."""
        if not v or v.isspace():
            raise ValueError("Host cannot be empty. Use 'localhost' or '127.0.0.1' for local server")
        return v
    
    @field_validator('gpu_layers')
    @classmethod
    def validate_gpu_layers(cls, v: int) -> int:
        """Validate GPU layers with helpful feedback."""
        if v > 35:
            import logging
            logging.getLogger(__name__).warning(
                f"GPU layers set to {v}. Most models have 32-35 layers. "
                f"Values above 35 may have no effect."
            )
        return v


class MCPConfig(BaseModel):
    """MCP (Model Context Protocol) configuration."""
    
    enabled: bool = Field(True, description="Enable MCP server integration (Obsidian vault access)")
    vault_path: Optional[str] = Field(None, description="Path to Obsidian vault (auto-detected if empty)")
    server_path: str = Field("/usr/local/bin/mcp-obsidian", description="Path to MCP server executable")


class CacheConfig(BaseModel):
    """Cache configuration."""
    
    enabled: bool = Field(False, description="Enable multi-tier caching (L1 memory, L2 disk)")
    memory_mb: int = Field(256, gt=0, le=4096, description="L1 memory cache budget in MB (1-4096)")
    disk_mb: int = Field(100, gt=0, le=10240, description="L2 disk cache budget in MB (1-10240)")
    ttl_seconds: int = Field(3600, gt=0, description="Cache entry time-to-live in seconds (min: 1, typical: 3600=1h)")
    compression_level: int = Field(6, ge=1, le=9, description="Gzip compression level (1=fast/SSD, 6=balanced, 9=max/HDD)")
    
    @field_validator('memory_mb')
    @classmethod
    def validate_memory_mb(cls, v: int) -> int:
        """Validate memory budget with helpful feedback."""
        if v > 2048:
            import logging
            logging.getLogger(__name__).warning(
                f"L1 memory cache set to {v}MB. Consider disk cache for larger budgets to avoid RAM pressure."
            )
        return v


class PerformanceConfig(BaseModel):
    """Performance and resource management configuration."""
    
    profile: str = Field("standard", description="Performance profile: lightweight, standard, or performance")
    async_llm: bool = Field(True, description="Enable async LLM calls for faster response times")
    max_workers: int = Field(2, gt=0, le=32, description="Maximum parallel worker threads (1-32, default: 2)")
    batch_size: int = Field(1, gt=0, le=1000, description="Batch size for bulk operations (1-1000)")
    
    @field_validator('profile')
    @classmethod
    def validate_profile(cls, v: str) -> str:
        """Validate profile is one of allowed values."""
        allowed = ['lightweight', 'standard', 'performance']
        if v not in allowed:
            raise ValueError(
                f"Profile must be one of {allowed}. Got: '{v}'. "
                f"Use 'lightweight' for minimal resources, 'performance' for max speed."
            )
        return v


class AnalyticsConfig(BaseModel):
    """Usage analytics and telemetry configuration."""
    
    enabled: bool = Field(False, description="Enable usage analytics tracking")
    retention_days: int = Field(90, gt=0, le=3650, description="How many days to retain analytics data (1-3650, default: 90)")
    export_to_cloud: bool = Field(False, description="Export analytics to cloud storage")
    
    @field_validator('retention_days')
    @classmethod
    def validate_retention(cls, v: int) -> int:
        """Validate retention with helpful feedback."""
        if v > 365:
            import logging
            logging.getLogger(__name__).warning(
                f"Analytics retention set to {v} days (> 1 year). "
                f"This may consume significant disk space."
            )
        return v


class GUIConfig(BaseModel):
    """GUI settings configuration."""
    
    theme: str = Field("system", description="UI theme: system, light, or dark")
    window_size: Tuple[int, int] = Field((1000, 700), description="Default window size (width, height) in pixels")
    last_folder: Optional[str] = Field(None, description="Last used template folder path")
    
    @field_validator('theme')
    @classmethod
    def validate_theme(cls, v: str) -> str:
        """Validate theme is one of allowed values."""
        allowed = ['system', 'light', 'dark']
        if v not in allowed:
            raise ValueError(
                f"Theme must be one of {allowed}. Got: '{v}'"
            )
        return v
    
    @field_validator('window_size')
    @classmethod
    def validate_window_size(cls, v: Tuple[int, int]) -> Tuple[int, int]:
        """Validate window size is reasonable."""
        width, height = v
        if width < 400 or height < 300:
            raise ValueError(
                f"Window size too small: {width}x{height}. Minimum: 400x300 pixels"
            )
        if width > 7680 or height > 4320:
            import logging
            logging.getLogger(__name__).warning(
                f"Window size very large: {width}x{height}. May exceed screen resolution."
            )
        return v


class TemplatesConfig(BaseModel):
    """Template management configuration."""
    
    search_paths: list[str] = Field(default_factory=lambda: ["~/.prompt-automation/prompts"], description="Directories to search for templates")
    auto_reload: bool = Field(True, description="Automatically reload templates when files change")


class EspansoConfig(BaseModel):
    """Espanso integration configuration."""
    
    package_dir: str = Field("~/.config/espanso/match", description="Path to Espanso package directory")
    auto_sync: bool = Field(False, description="Automatically sync templates to Espanso on changes")


class FeaturesConfig(BaseModel):
    """Feature flags configuration."""
    
    mcp_integration: bool = Field(True, description="Enable MCP (Model Context Protocol) integration")
    llm_generation: bool = Field(True, description="Enable LLM-powered template generation")
    espanso_sync: bool = Field(False, description="Enable Espanso text expansion sync")
    template_management: bool = Field(True, description="Enable template creation/editing")
    command_palette: bool = Field(True, description="Enable command palette (Ctrl+Shift+P)")


class Config(BaseModel):
    """Root configuration model.
    
    This is the top-level configuration that contains all subsections.
    All fields have sensible defaults, making the config optional.
    """
    
    version: int = 3
    profile: str = "standard"
    
    llm: LLMConfig = Field(default_factory=LLMConfig)
    mcp: MCPConfig = Field(default_factory=MCPConfig)
    cache: CacheConfig = Field(default_factory=CacheConfig)
    performance: PerformanceConfig = Field(default_factory=PerformanceConfig)
    analytics: AnalyticsConfig = Field(default_factory=AnalyticsConfig)
    gui: GUIConfig = Field(default_factory=GUIConfig)
    templates: TemplatesConfig = Field(default_factory=TemplatesConfig)
    espanso: EspansoConfig = Field(default_factory=EspansoConfig)
    features: FeaturesConfig = Field(default_factory=FeaturesConfig)
    
    model_config = ConfigDict(validate_assignment=True)
