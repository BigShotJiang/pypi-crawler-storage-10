"""Data models for MCP Router."""

from enum import Enum
from typing import Dict, List, Optional, Any
from pydantic import BaseModel, Field, field_validator, model_validator


class ServerTransport(str, Enum):
    """Supported transport protocols for MCP servers."""
    
    HTTP = "http"
    STDIO = "stdio"
    GRPC = "grpc"


class ServerConfig(BaseModel):
    """Configuration for a single MCP server.
    
    Attributes:
        id: Unique server identifier
        name: Human-readable server name
        transport: Transport protocol (http, stdio, grpc)
        endpoint: HTTP endpoint URL (for HTTP transport)
        command: Command to execute (for stdio transport)
        args: Command arguments (for stdio transport)
        env: Environment variables for subprocess
        namespace: Tool namespace (defaults to server id)
        enabled: Whether server is enabled
        priority: Routing priority (higher = preferred)
        capabilities: Server capabilities metadata
    """
    
    id: str = Field(..., description="Unique server identifier")
    name: str = Field(..., description="Human-readable name")
    transport: ServerTransport = Field(..., description="Transport protocol")
    endpoint: Optional[str] = Field(None, description="HTTP endpoint URL")
    command: Optional[str] = Field(None, description="Command to execute (stdio)")
    args: List[str] = Field(default_factory=list, description="Command arguments")
    env: Dict[str, str] = Field(default_factory=dict, description="Environment variables")
    namespace: Optional[str] = Field(None, description="Tool namespace")
    enabled: bool = Field(True, description="Server enabled flag")
    priority: int = Field(5, description="Routing priority (0-10)")
    capabilities: Dict[str, Any] = Field(default_factory=dict, description="Server capabilities")
    
    @field_validator("priority")
    @classmethod
    def validate_priority_range(cls, v):
        """Validate priority is in valid range."""
        if not 0 <= v <= 10:
            raise ValueError("Priority must be between 0 and 10")
        return v
    
    @model_validator(mode='after')
    def validate_transport_requirements(self):
        """Validate transport-specific requirements."""
        # HTTP transport requires endpoint
        if self.transport == ServerTransport.HTTP and not self.endpoint:
            raise ValueError("HTTP transport requires endpoint URL")
        
        # stdio transport requires command
        if self.transport == ServerTransport.STDIO and not self.command:
            raise ValueError("stdio transport requires command")
        
        return self
    
    @property
    def effective_namespace(self) -> str:
        """Get effective namespace (configured or fallback to id)."""
        return self.namespace or self.id


class RegistrySchema(BaseModel):
    """Schema for the server registry file.
    
    Attributes:
        version: Registry format version
        servers: List of server configurations
    """
    
    version: str = Field("1.0", description="Registry format version")
    servers: List[ServerConfig] = Field(default_factory=list, description="Server configurations")
