"""Adapter factory for creating transport adapters."""

import logging
from typing import Dict, Any

from .models import ServerConfig, ServerTransport
from .adapters import BaseAdapter, HTTPAdapter, StdioAdapter

logger = logging.getLogger(__name__)


class AdapterFactory:
    """Factory for creating MCP transport adapters.
    
    Creates appropriate adapter instances (HTTP, Stdio) based on
    server transport configuration.
    
    Example:
        >>> factory = AdapterFactory()
        >>> config = ServerConfig(
        ...     id="obsidian",
        ...     transport=ServerTransport.STDIO,
        ...     command=["npx", "mcp-server-obsidian"]
        ... )
        >>> adapter = factory.create_adapter(config)
        >>> isinstance(adapter, StdioAdapter)
        True
    """
    
    def create_adapter(self, server_config: ServerConfig) -> BaseAdapter:
        """Create adapter for server configuration.
        
        Args:
            server_config: Server configuration
        
        Returns:
            Appropriate adapter instance (HTTPAdapter or StdioAdapter)
        
        Raises:
            ValueError: If transport type not supported
        """
        if server_config.transport == ServerTransport.HTTP:
            return self._create_http_adapter(server_config)
        elif server_config.transport == ServerTransport.STDIO:
            return self._create_stdio_adapter(server_config)
        else:
            raise ValueError(f"Unsupported transport: {server_config.transport}")
    
    def _create_http_adapter(self, config: ServerConfig) -> HTTPAdapter:
        """Create HTTP adapter from server config.
        
        Args:
            config: Server configuration with HTTP transport
        
        Returns:
            Configured HTTPAdapter instance
        
        Raises:
            ValueError: If endpoint not specified
        """
        if not config.endpoint:
            raise ValueError(f"HTTP server '{config.id}' missing endpoint")
        
        adapter_config: Dict[str, Any] = {
            "endpoint": config.endpoint,
            "timeout": config.capabilities.get("timeout", 30),
            "max_retries": 3,
        }
        
        # Add headers from capabilities if specified
        if "headers" in config.capabilities:
            adapter_config["headers"] = config.capabilities["headers"]
        
        logger.debug(f"Creating HTTP adapter for {config.id}: {config.endpoint}")
        return HTTPAdapter(adapter_config)
    
    def _create_stdio_adapter(self, config: ServerConfig) -> StdioAdapter:
        """Create Stdio adapter from server config.
        
        Args:
            config: Server configuration with Stdio transport
        
        Returns:
            Configured StdioAdapter instance
        
        Raises:
            ValueError: If command not specified
        """
        if not config.command:
            raise ValueError(f"Stdio server '{config.id}' missing command")
        
        adapter_config: Dict[str, Any] = {
            "command": config.command,
            "args": config.args or [],
            "timeout": config.capabilities.get("timeout", 30),
            "max_retries": 3,
        }
        
        # Add environment variables if specified
        if config.env:
            adapter_config["env"] = config.env
        
        logger.debug(f"Creating Stdio adapter for {config.id}: {config.command}")
        return StdioAdapter(adapter_config)
        
        # Add env vars if specified
        if config.env:
            adapter_config["env"] = config.env
        
        logger.debug(f"Creating Stdio adapter for {config.id}: {' '.join(config.command)}")
        return StdioAdapter(adapter_config)
