"""Server registry for MCP Router."""

import json
import logging
from pathlib import Path
from typing import List, Optional, Dict, Any

from .models import ServerConfig, RegistrySchema

logger = logging.getLogger(__name__)


class ServerRegistry:
    """Manage MCP server registry with hot-reload support.
    
    The registry loads server configurations from a JSON file and provides
    methods to query and filter servers. Supports caching and hot-reload
    when the file changes.
    
    Example:
        >>> registry = ServerRegistry("~/.prompt-automation/mcp-servers.json")
        >>> servers = registry.load_servers()
        >>> enabled_servers = [s for s in servers if s.enabled]
    """
    
    def __init__(self, registry_path: str):
        """Initialize server registry.
        
        Args:
            registry_path: Path to registry JSON file (supports ~ expansion)
        """
        self.registry_path = Path(registry_path).expanduser().resolve()
        self._cache: Optional[RegistrySchema] = None
        self._cache_mtime: Optional[float] = None
        self._cached_enabled_servers: Optional[List[ServerConfig]] = None
    
    def load_servers(self, force_reload: bool = False) -> List[ServerConfig]:
        """Load all enabled servers from registry.
        
        Args:
            force_reload: Force reload from disk (bypass cache)
        
        Returns:
            List of enabled server configurations
        
        Raises:
            FileNotFoundError: If registry file doesn't exist
            ValueError: If registry JSON is invalid
        """
        # Check if file exists
        if not self.registry_path.exists():
            logger.warning(f"Registry file not found: {self.registry_path}")
            return []
        
        # Check cache validity
        current_mtime = self.registry_path.stat().st_mtime
        if (
            not force_reload
            and self._cache is not None
            and self._cache_mtime == current_mtime
            and self._cached_enabled_servers is not None
        ):
            logger.debug("Using cached registry")
            return self._cached_enabled_servers
        
        # Load from disk
        try:
            with open(self.registry_path) as f:
                data = json.load(f)
            
            # Validate schema
            registry = RegistrySchema(**data)
            
            # Update cache
            self._cache = registry
            self._cache_mtime = current_mtime
            
            # Cache enabled servers list
            enabled_servers = [s for s in registry.servers if s.enabled]
            self._cached_enabled_servers = enabled_servers
            
            enabled_count = len(enabled_servers)
            logger.info(
                f"Loaded {len(registry.servers)} servers "
                f"({enabled_count} enabled) from {self.registry_path}"
            )
            
            # Return cached list
            return self._cached_enabled_servers
        
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in registry: {e}")
            raise ValueError(f"Invalid registry JSON: {e}") from e
        
        except Exception as e:
            logger.error(f"Failed to load registry: {e}")
            raise
    
    def get_server(self, server_id: str) -> Optional[ServerConfig]:
        """Get server configuration by ID.
        
        Args:
            server_id: Server identifier
        
        Returns:
            Server configuration if found and enabled, None otherwise
        """
        servers = self.load_servers()
        return next((s for s in servers if s.id == server_id), None)
    
    def get_servers_by_namespace(self, namespace: str) -> List[ServerConfig]:
        """Get all servers for a given namespace.
        
        Args:
            namespace: Tool namespace
        
        Returns:
            List of servers providing tools in this namespace
        """
        servers = self.load_servers()
        return [s for s in servers if s.effective_namespace == namespace]
    
    def get_servers_by_transport(self, transport: str) -> List[ServerConfig]:
        """Get all servers using a specific transport.
        
        Args:
            transport: Transport protocol (http, stdio, grpc)
        
        Returns:
            List of servers using this transport
        """
        servers = self.load_servers()
        return [s for s in servers if s.transport.value == transport]
    
    def reload(self) -> List[ServerConfig]:
        """Force reload registry from disk.
        
        Returns:
            List of enabled server configurations
        """
        logger.info("Force reloading registry")
        return self.load_servers(force_reload=True)
    
    def is_stale(self) -> bool:
        """Check if cached registry is stale.
        
        Returns:
            True if file has changed since last load
        """
        if not self.registry_path.exists():
            return False
        
        if self._cache_mtime is None:
            return True
        
        current_mtime = self.registry_path.stat().st_mtime
        return current_mtime != self._cache_mtime
