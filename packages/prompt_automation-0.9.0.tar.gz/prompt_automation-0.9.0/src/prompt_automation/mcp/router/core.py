"""MCP Router core orchestration."""

import asyncio
import logging
import time
from typing import Dict, Any, List, Optional
from pathlib import Path

from .models import ServerConfig
from .registry import ServerRegistry
from .discovery import DiscoveryEngine
from .tool_descriptor import ToolDescriptor
from .adapter_factory import AdapterFactory
from .adapters import BaseAdapter

logger = logging.getLogger(__name__)


class MCPRouter:
    """MCP Router for multi-server orchestration.
    
    Provides unified interface for discovering and calling tools across
    multiple MCP servers with different transports (HTTP, Stdio).
    
    Features:
    - Automatic adapter selection based on server transport
    - Namespace-based routing (namespace.tool_name → server)
    - Priority-based fallback for namespace collisions
    - Retry with exponential backoff
    - Connection pooling and health tracking
    
    Example:
        >>> router = MCPRouter(registry_path=Path("mcp-registry.json"))
        >>> await router.initialize()
        >>> 
        >>> # Discover all tools
        >>> tools = await router.discover_all()
        >>> 
        >>> # Call tool with qualified name
        >>> result = await router.call_tool(
        ...     "obsidian.search_note",
        ...     {"query": "test"}
        ... )
        >>> 
        >>> await router.close()
    """
    
    def __init__(
        self,
        registry_path: Optional[Path] = None,
        registry: Optional[ServerRegistry] = None,
        discovery: Optional[DiscoveryEngine] = None,
        adapter_factory: Optional[AdapterFactory] = None
    ):
        """Initialize MCP Router.
        
        Args:
            registry_path: Path to server registry JSON (optional if registry provided)
            registry: ServerRegistry instance (optional, creates from path if not provided)
            discovery: DiscoveryEngine instance (optional, creates if not provided)
            adapter_factory: AdapterFactory instance (optional, creates if not provided)
        """
        self.registry = registry or ServerRegistry(registry_path)
        self.discovery = discovery or DiscoveryEngine(self.registry)
        self.adapter_factory = adapter_factory or AdapterFactory()
        
        # Adapter pool: {server_id: adapter}
        self._adapter_pool: Dict[str, BaseAdapter] = {}
        
        # Health tracking: {server_id: {"last_success": timestamp, "failures": count}}
        self._health: Dict[str, Dict[str, Any]] = {}
        
        # Pool access lock
        self._pool_lock = asyncio.Lock()
        
        # Tool cache: {qualified_name: server_id}
        self._tool_routes: Dict[str, str] = {}
    
    async def initialize(self) -> None:
        """Initialize router (discover tools, build routes).
        
        This is optional - router will auto-initialize on first use.
        Explicit initialization allows catching errors early.
        """
        logger.info("Initializing MCP Router")
        
        # Discover all tools to build routing table
        tools_dict = await self.discover_all()
        
        # Build tool → server mapping from discovery results
        # tools_dict is {server_id: [ToolDescriptor, ...]}
        self._tool_routes = {}
        for server_id, tools in tools_dict.items():
            for tool in tools:
                self._tool_routes[tool.qualified_name] = tool.server_id
        
        total_tools = sum(len(tools) for tools in tools_dict.values())
        logger.info(f"Router initialized: {total_tools} tools from {len(tools_dict)} servers")
    
    async def discover_all(self, force_refresh: bool = False) -> Dict[str, List[ToolDescriptor]]:
        """Discover tools from all enabled servers.
        
        Args:
            force_refresh: Skip cache and rediscover (default: False)
        
        Returns:
            Map of server_id → list of tools
        """
        # Get adapters for all servers
        servers = self.registry.load_servers()
        
        # Create adapters on demand
        server_adapters = {}
        for server in servers:
            if not server.enabled:
                continue
            
            # Get or create adapter
            async with self._pool_lock:
                if server.id not in self._adapter_pool:
                    adapter = self.adapter_factory.create_adapter(server)
                    await adapter.connect()
                    self._adapter_pool[server.id] = adapter
                
                server_adapters[server.id] = self._adapter_pool[server.id]
        
        # Use discovery engine to find tools
        tools_by_name = await self.discovery.discover_all(server_adapters)
        
        # Group by server for return value
        tools_by_server: Dict[str, List[ToolDescriptor]] = {}
        for tool in tools_by_name.values():
            if tool.server_id not in tools_by_server:
                tools_by_server[tool.server_id] = []
            tools_by_server[tool.server_id].append(tool)
        
        return tools_by_server
    
    async def call_tool(
        self,
        qualified_name: str,
        arguments: Dict[str, Any],
        max_retries: int = 3,
        fallback: bool = True
    ) -> Dict[str, Any]:
        """Call tool by qualified name (namespace.tool_name).
        
        Args:
            qualified_name: Qualified tool name (e.g., "obsidian.search_note")
            arguments: Tool arguments
            max_retries: Max retry attempts per server (default: 3)
            fallback: Try alternative servers on failure (default: True)
        
        Returns:
            Tool execution result
        
        Raises:
            ValueError: If tool not found
            RuntimeError: If all attempts fail
        """
        # Parse qualified name
        if "." not in qualified_name:
            raise ValueError(f"Tool name must be qualified: '{qualified_name}' (expected 'namespace.tool_name')")
        
        namespace, tool_name = qualified_name.rsplit(".", 1)
        
        # Get candidate servers (primary + fallbacks)
        servers = await self._get_servers_for_tool(namespace, tool_name, fallback)
        
        if not servers:
            raise ValueError(f"No servers found for tool: {qualified_name}")
        
        # Try each server with retries
        last_error = None
        for server_config in servers:
            try:
                result = await self._call_tool_on_server(
                    server_config,
                    tool_name,
                    arguments,
                    max_retries
                )
                
                # Track success
                await self._record_success(server_config.id)
                
                return result
            
            except Exception as e:
                last_error = e
                await self._record_failure(server_config.id)
                logger.warning(f"Tool call failed on {server_config.id}: {e}")
                continue
        
        # All servers failed
        raise RuntimeError(f"Tool call failed on all servers: {last_error}")
    
    async def health_check(self, server_id: Optional[str] = None) -> Dict[str, Any]:
        """Check health of server(s).
        
        Args:
            server_id: Specific server ID (optional, checks all if None)
        
        Returns:
            Health status dict with per-server results
        """
        if server_id:
            # Check specific server
            adapter = await self._get_adapter(server_id)
            status = await adapter.health_check()
            return {server_id: status}
        else:
            # Check all enabled servers
            servers = self.registry.get_servers()
            results = {}
            
            for server_config in servers:
                try:
                    adapter = await self._get_adapter(server_config.id)
                    status = await adapter.health_check()
                    results[server_config.id] = status
                except Exception as e:
                    results[server_config.id] = {
                        "status": "error",
                        "error": str(e)
                    }
            
            return results
    
    async def close(self) -> None:
        """Close all adapter connections."""
        async with self._pool_lock:
            for server_id, adapter in self._adapter_pool.items():
                try:
                    await adapter.close()
                    logger.debug(f"Closed adapter for {server_id}")
                except Exception as e:
                    logger.error(f"Error closing adapter for {server_id}: {e}")
            
            self._adapter_pool.clear()
        
        logger.info("Router closed")
    
    async def _get_servers_for_tool(
        self,
        namespace: str,
        tool_name: str,
        include_fallbacks: bool
    ) -> List[ServerConfig]:
        """Get candidate servers for tool (primary + fallbacks).
        
        Args:
            namespace: Tool namespace
            tool_name: Tool name (without namespace)
            include_fallbacks: Include fallback servers
        
        Returns:
            List of server configs, ordered by priority
        """
        # Get servers with matching namespace
        servers = self.registry.get_servers_by_namespace(namespace)
        
        if not servers:
            return []
        
        # Sort by priority (higher priority first)
        servers.sort(key=lambda s: s.priority or 0, reverse=True)
        
        if include_fallbacks:
            return servers  # All servers with namespace
        else:
            return servers[:1]  # Only highest priority
    
    async def _call_tool_on_server(
        self,
        server_config: ServerConfig,
        tool_name: str,
        arguments: Dict[str, Any],
        max_retries: int
    ) -> Dict[str, Any]:
        """Call tool on specific server with retries.
        
        Args:
            server_config: Server configuration
            tool_name: Tool name (without namespace)
            arguments: Tool arguments
            max_retries: Max retry attempts
        
        Returns:
            Tool execution result
        
        Raises:
            RuntimeError: If all retries fail
        """
        adapter = await self._get_adapter(server_config.id)
        
        for attempt in range(max_retries):
            try:
                result = await adapter.call_tool(tool_name, arguments)
                return result
            
            except Exception as e:
                if attempt == max_retries - 1:
                    raise RuntimeError(f"Tool call failed after {max_retries} attempts: {e}") from e
                
                # Exponential backoff
                wait_time = 2 ** attempt
                logger.debug(f"Retry {attempt + 1}/{max_retries} after {wait_time}s: {e}")
                await asyncio.sleep(wait_time)
        
        raise RuntimeError("Unreachable")
    
    async def _get_adapter(self, server_id: str) -> BaseAdapter:
        """Get or create adapter for server.
        
        Args:
            server_id: Server ID
        
        Returns:
            Adapter instance (cached if already exists)
        
        Raises:
            ValueError: If server not found
        """
        async with self._pool_lock:
            # Return cached adapter if exists
            if server_id in self._adapter_pool:
                return self._adapter_pool[server_id]
            
            # Create new adapter
            server_config = self.registry.get_server(server_id)
            if not server_config:
                raise ValueError(f"Server not found: {server_id}")
            
            adapter = self.adapter_factory.create_adapter(server_config)
            await adapter.connect()
            
            # Cache adapter
            self._adapter_pool[server_id] = adapter
            
            logger.debug(f"Created adapter for {server_id}")
            return adapter
    
    async def _record_success(self, server_id: str) -> None:
        """Record successful server interaction."""
        self._health[server_id] = {
            "last_success": time.time(),
            "failures": 0
        }
    
    async def _record_failure(self, server_id: str) -> None:
        """Record failed server interaction."""
        if server_id not in self._health:
            self._health[server_id] = {"last_success": None, "failures": 0}
        
        self._health[server_id]["failures"] += 1
    
    async def __aenter__(self):
        """Async context manager entry."""
        await self.initialize()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()
