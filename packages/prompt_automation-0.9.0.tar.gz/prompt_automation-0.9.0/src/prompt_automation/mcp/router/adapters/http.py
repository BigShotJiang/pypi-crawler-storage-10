"""HTTP adapter for MCP Router."""

import asyncio
import logging
from typing import Dict, Any, Optional
from concurrent.futures import ThreadPoolExecutor
import requests

from .base import BaseAdapter

logger = logging.getLogger(__name__)


class HTTPAdapter(BaseAdapter):
    """HTTP transport adapter for MCP servers.
    
    Implements JSON-RPC over HTTP for communicating with MCP servers
    that expose an HTTP endpoint.
    
    Uses requests library with ThreadPoolExecutor for async compatibility.
    Will migrate to aiohttp when that dependency is added to the project.
    
    Example:
        >>> adapter = HTTPAdapter({
        ...     "endpoint": "http://localhost:8080/mcp",
        ...     "timeout": 30
        ... })
        >>> await adapter.connect()
        >>> tools = await adapter.discover()
        >>> result = await adapter.call_tool("search", {"query": "test"})
    """
    
    def __init__(self, config: Dict[str, Any]):
        """Initialize HTTP adapter.
        
        Args:
            config: Adapter configuration with keys:
                - endpoint (str): HTTP endpoint URL
                - timeout (int): Request timeout in seconds (default: 30)
                - max_retries (int): Max retry attempts (default: 3)
                - headers (dict): Additional HTTP headers (optional)
        """
        self.endpoint = config["endpoint"]
        self.timeout = config.get("timeout", 30)
        self.max_retries = config.get("max_retries", 3)
        self.headers = config.get("headers", {})
        
        self.session: Optional[requests.Session] = None
        self._request_id = 0
        self._executor: Optional[ThreadPoolExecutor] = None
    
    async def connect(self) -> None:
        """Establish HTTP session."""
        if self.session is None:
            self.session = requests.Session()
            self.session.headers.update(self.headers)
            self._executor = ThreadPoolExecutor(max_workers=4)
            logger.info(f"HTTP adapter connected to {self.endpoint}")
    
    async def discover(self) -> Dict[str, Any]:
        """Discover tools via HTTP JSON-RPC."""
        await self.connect()
        
        request = self._build_jsonrpc_request("mcp/discover", {})
        
        for attempt in range(self.max_retries):
            try:
                response = await self._send_request_async(request)
                return response.get("result", {})
            
            except requests.RequestException as e:
                if attempt == self.max_retries - 1:
                    logger.error(f"Discovery failed after {self.max_retries} attempts: {e}")
                    raise RuntimeError(f"Discovery failed: {e}") from e
                
                # Exponential backoff
                wait_time = 2 ** attempt
                logger.warning(f"Discovery attempt {attempt + 1} failed, retrying in {wait_time}s: {e}")
                await asyncio.sleep(wait_time)
        
        # Should not reach here
        raise RuntimeError("Discovery failed: max retries exceeded")
    
    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Call tool via HTTP JSON-RPC."""
        await self.connect()
        
        request = self._build_jsonrpc_request("mcp/tools/call", {
            "name": tool_name,
            "arguments": arguments
        })
        
        for attempt in range(self.max_retries):
            try:
                response = await self._send_request_async(request)
                
                # Check for JSON-RPC error
                if "error" in response:
                    error = response["error"]
                    raise RuntimeError(
                        f"Tool call failed: {error.get('message', 'Unknown error')} "
                        f"(code: {error.get('code')})"
                    )
                
                return response.get("result", {})
            
            except requests.RequestException as e:
                if attempt == self.max_retries - 1:
                    logger.error(f"Tool call failed after {self.max_retries} attempts: {e}")
                    raise RuntimeError(f"Tool call failed: {e}") from e
                
                # Exponential backoff
                wait_time = 2 ** attempt
                logger.warning(f"Tool call attempt {attempt + 1} failed, retrying in {wait_time}s: {e}")
                await asyncio.sleep(wait_time)
        
        raise RuntimeError("Tool call failed: max retries exceeded")
    
    async def health_check(self) -> Dict[str, Any]:
        """Check server health via HTTP."""
        await self.connect()
        
        try:
            request = self._build_jsonrpc_request("mcp/health", {})
            response = await self._send_request_async(request)
            
            return {
                "status": "healthy",
                "details": response.get("result", {})
            }
        
        except Exception as e:
            logger.warning(f"Health check failed: {e}")
            return {
                "status": "unhealthy",
                "error": str(e)
            }
    
    async def close(self) -> None:
        """Close HTTP session and executor."""
        if self.session:
            self.session.close()
            logger.info(f"HTTP adapter closed connection to {self.endpoint}")
        
        if self._executor:
            self._executor.shutdown(wait=False)
    
    def _build_jsonrpc_request(self, method: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Build JSON-RPC 2.0 request.
        
        Args:
            method: JSON-RPC method name
            params: Method parameters
        
        Returns:
            JSON-RPC request object
        """
        self._request_id += 1
        return {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
            "id": self._request_id
        }
    
    def _send_request_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Send HTTP request and parse JSON response (synchronous).
        
        Args:
            request: JSON-RPC request
        
        Returns:
            JSON-RPC response
        
        Raises:
            requests.RequestException: On network errors
            RuntimeError: On invalid response
        """
        if not self.session:
            raise RuntimeError("Session not connected")
        
        response = self.session.post(
            self.endpoint,
            json=request,
            timeout=self.timeout
        )
        response.raise_for_status()
        data = response.json()
        
        # Validate JSON-RPC response
        if "jsonrpc" not in data or data["jsonrpc"] != "2.0":
            raise RuntimeError("Invalid JSON-RPC response: missing jsonrpc field")
        
        if "id" not in data or data["id"] != request["id"]:
            raise RuntimeError("Invalid JSON-RPC response: id mismatch")
        
        return data
    
    async def _send_request_async(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Send HTTP request asynchronously using ThreadPoolExecutor.
        
        Args:
            request: JSON-RPC request
        
        Returns:
            JSON-RPC response
        """
        if not self._executor:
            raise RuntimeError("Executor not initialized")
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            self._executor,
            self._send_request_sync,
            request
        )
    
    async def __aenter__(self):
        """Async context manager entry."""
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()
