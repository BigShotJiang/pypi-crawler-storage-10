"""Stdio adapter for MCP Router."""

import asyncio
import json
import logging
from typing import Dict, Any, Optional
from asyncio.subprocess import Process

from .base import BaseAdapter

logger = logging.getLogger(__name__)


class StdioAdapter(BaseAdapter):
    """Stdio transport adapter for local MCP servers.
    
    Implements JSON-RPC over stdin/stdout for communicating with local
    MCP servers (e.g., Obsidian MCP server running as subprocess).
    
    Example:
        >>> adapter = StdioAdapter({
        ...     "command": ["npx", "-y", "@modelcontextprotocol/server-obsidian"],
        ...     "args": ["--vault", "/path/to/vault"],
        ...     "timeout": 30
        ... })
        >>> await adapter.connect()
        >>> tools = await adapter.discover()
        >>> result = await adapter.call_tool("search_note", {"query": "test"})
    """
    
    def __init__(self, config: Dict[str, Any]):
        """Initialize Stdio adapter.
        
        Args:
            config: Adapter configuration with keys:
                - command (list): Command to execute (e.g., ["node", "server.js"])
                - args (list): Command arguments (optional, default: [])
                - env (dict): Environment variables (optional, default: {})
                - cwd (str): Working directory (optional, default: None)
                - timeout (int): Request timeout in seconds (default: 30)
                - max_retries (int): Max retry attempts (default: 3)
        """
        self.command = config["command"]
        self.args = config.get("args", [])
        self.env = config.get("env", {})
        self.cwd = config.get("cwd", None)
        self.timeout = config.get("timeout", 30)
        self.max_retries = config.get("max_retries", 3)
        
        self.process: Optional[Process] = None
        self._request_id = 0
        self._pending_responses: Dict[int, asyncio.Future] = {}
        self._reader_task: Optional[asyncio.Task] = None
    
    async def connect(self) -> None:
        """Start subprocess and begin reading responses."""
        if self.process is None or self.process.returncode is not None:
            # Build full command
            full_command = self.command + self.args
            
            # Validate command for WSL2 → Windows .exe compatibility
            await self._validate_wsl2_subprocess(full_command)
            
            # Start process
            self.process = await asyncio.create_subprocess_exec(
                *full_command,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=self.env if self.env else None,
                cwd=self.cwd
            )
            
            # Start background reader
            self._reader_task = asyncio.create_task(self._read_responses())
            
            logger.info(f"Stdio adapter started: {' '.join(full_command)}")
    
    async def discover(self) -> Dict[str, Any]:
        """Discover tools via stdio JSON-RPC."""
        await self.connect()
        
        request = self._build_jsonrpc_request("mcp/discover", {})
        
        for attempt in range(self.max_retries):
            try:
                response = await self._send_request(request)
                return response.get("result", {})
            
            except Exception as e:
                if attempt == self.max_retries - 1:
                    logger.error(f"Discovery failed after {self.max_retries} attempts: {e}")
                    raise RuntimeError(f"Discovery failed: {e}") from e
                
                # Exponential backoff
                wait_time = 2 ** attempt
                logger.warning(f"Discovery attempt {attempt + 1} failed, retrying in {wait_time}s: {e}")
                await asyncio.sleep(wait_time)
        
        raise RuntimeError("Discovery failed: max retries exceeded")
    
    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Call tool via stdio JSON-RPC."""
        await self.connect()
        
        request = self._build_jsonrpc_request("mcp/tools/call", {
            "name": tool_name,
            "arguments": arguments
        })
        
        for attempt in range(self.max_retries):
            try:
                response = await self._send_request(request)
                
                # Check for JSON-RPC error
                if "error" in response:
                    error = response["error"]
                    raise RuntimeError(
                        f"Tool call failed: {error.get('message', 'Unknown error')} "
                        f"(code: {error.get('code')})"
                    )
                
                return response.get("result", {})
            
            except Exception as e:
                if attempt == self.max_retries - 1:
                    logger.error(f"Tool call failed after {self.max_retries} attempts: {e}")
                    raise RuntimeError(f"Tool call failed: {e}") from e
                
                # Exponential backoff
                wait_time = 2 ** attempt
                logger.warning(f"Tool call attempt {attempt + 1} failed, retrying in {wait_time}s: {e}")
                await asyncio.sleep(wait_time)
        
        raise RuntimeError("Tool call failed: max retries exceeded")
    
    async def health_check(self) -> Dict[str, Any]:
        """Check subprocess health."""
        await self.connect()
        
        try:
            # Check if process is still running
            if self.process and self.process.returncode is None:
                request = self._build_jsonrpc_request("mcp/health", {})
                response = await self._send_request(request)
                
                return {
                    "status": "healthy",
                    "details": response.get("result", {})
                }
            else:
                return {
                    "status": "unhealthy",
                    "error": f"Process exited with code {self.process.returncode}"
                }
        
        except Exception as e:
            logger.warning(f"Health check failed: {e}")
            return {
                "status": "unhealthy",
                "error": str(e)
            }
    
    async def close(self) -> None:
        """Terminate subprocess and cleanup."""
        # Cancel reader task
        if self._reader_task and not self._reader_task.done():
            self._reader_task.cancel()
            try:
                await self._reader_task
            except asyncio.CancelledError:
                pass
        
        # Terminate process
        if self.process and self.process.returncode is None:
            self.process.terminate()
            
            try:
                # Wait for graceful shutdown
                await asyncio.wait_for(self.process.wait(), timeout=5.0)
                logger.info("Stdio adapter: process terminated gracefully")
            except asyncio.TimeoutError:
                # Force kill if not responding
                self.process.kill()
                await self.process.wait()
                logger.warning("Stdio adapter: process force killed")
        
        # Clear pending responses
        for future in self._pending_responses.values():
            if not future.done():
                future.cancel()
        self._pending_responses.clear()
    
    def _build_jsonrpc_request(self, method: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Build JSON-RPC 2.0 request.
        
        Args:
            method: JSON-RPC method name
            params: Method parameters
        
        Returns:
            JSON-RPC request object
        """
        self._request_id += 1
        return {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
            "id": self._request_id
        }
    
    async def _send_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Send request to subprocess and wait for response.
        
        Args:
            request: JSON-RPC request
        
        Returns:
            JSON-RPC response
        
        Raises:
            RuntimeError: If process not running or timeout
        """
        if not self.process or self.process.returncode is not None:
            raise RuntimeError("Process not running")
        
        # Create future for response
        request_id = request["id"]
        future = asyncio.Future()
        self._pending_responses[request_id] = future
        
        # Send request
        request_str = json.dumps(request) + "\n"
        self.process.stdin.write(request_str.encode())
        await self.process.stdin.drain()
        
        # Wait for response with timeout
        try:
            response = await asyncio.wait_for(future, timeout=self.timeout)
            return response
        except asyncio.TimeoutError:
            self._pending_responses.pop(request_id, None)
            raise RuntimeError(f"Request timeout after {self.timeout}s")
    
    async def _read_responses(self) -> None:
        """Background task to read responses from subprocess stdout."""
        try:
            while self.process and self.process.returncode is None:
                line = await self.process.stdout.readline()
                if not line:
                    break
                
                try:
                    response = json.loads(line.decode().strip())
                    
                    # Validate JSON-RPC response
                    if "jsonrpc" not in response or response["jsonrpc"] != "2.0":
                        logger.warning(f"Invalid JSON-RPC response: {response}")
                        continue
                    
                    # Match to pending request
                    request_id = response.get("id")
                    if request_id in self._pending_responses:
                        future = self._pending_responses.pop(request_id)
                        if not future.done():
                            future.set_result(response)
                
                except json.JSONDecodeError as e:
                    logger.warning(f"Failed to parse JSON response: {line.decode()}: {e}")
                except Exception as e:
                    logger.error(f"Error processing response: {e}")
        
        except asyncio.CancelledError:
            logger.debug("Response reader cancelled")
            raise
        except Exception as e:
            logger.error(f"Response reader error: {e}")
    
    async def _validate_wsl2_subprocess(self, command: list) -> None:
        """Validate subprocess command for WSL2 → Windows .exe compatibility.
        
        Prevents 30s hangs when calling Windows .exe from WSL2 without
        proper stdio validation.
        
        Args:
            command: Command list to validate
        """
        try:
            from prompt_automation.platform_utils import validate_subprocess_stdio
            
            # Only validate if command appears to be .exe (Windows executable)
            if command and command[0].endswith(".exe"):
                validate_subprocess_stdio(command)
        except ImportError:
            # platform_utils not available, skip validation
            pass
        except Exception as e:
            logger.warning(f"WSL2 subprocess validation failed: {e}")
    
    async def __aenter__(self):
        """Async context manager entry."""
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()
