"""Base adapter interface for MCP Router."""

from abc import ABC, abstractmethod
from typing import Dict, Any


class BaseAdapter(ABC):
    """Base interface for MCP server adapters.
    
    Adapters implement protocol-specific communication with MCP servers
    (HTTP, stdio, gRPC, etc.) and provide a uniform interface for the router.
    """
    
    @abstractmethod
    async def connect(self) -> None:
        """Establish connection to the MCP server.
        
        Raises:
            ConnectionError: If connection fails
        """
        pass
    
    @abstractmethod
    async def discover(self) -> Dict[str, Any]:
        """Discover available tools from the server.
        
        Returns:
            Discovery response with tools list and metadata
        
        Raises:
            RuntimeError: If discovery fails
        """
        pass
    
    @abstractmethod
    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Call a tool on the MCP server.
        
        Args:
            tool_name: Name of the tool to call
            arguments: Tool arguments
        
        Returns:
            Tool execution result
        
        Raises:
            RuntimeError: If tool call fails
        """
        pass
    
    @abstractmethod
    async def health_check(self) -> Dict[str, Any]:
        """Check server health status.
        
        Returns:
            Health status information
        """
        pass
    
    @abstractmethod
    async def close(self) -> None:
        """Close connection to the server.
        
        Should be called when adapter is no longer needed to clean up resources.
        """
        pass
