"""Tool descriptor for MCP Router."""

from typing import Dict, Any, Optional
from pydantic import BaseModel, Field


class ToolDescriptor(BaseModel):
    """Normalized tool descriptor from MCP server.
    
    Represents a tool discovered from an MCP server with normalized
    metadata for routing and invocation.
    
    Attributes:
        name: Tool name (without namespace)
        namespace: Tool namespace (server's namespace)
        qualified_name: Fully qualified name (namespace.name)
        server_id: Server that provides this tool
        description: Human-readable description
        input_schema: JSON schema for tool arguments
        priority: Server priority (for collision resolution)
    """
    
    name: str = Field(..., description="Tool name")
    namespace: str = Field(..., description="Tool namespace")
    server_id: str = Field(..., description="Server ID")
    description: str = Field("", description="Tool description")
    input_schema: Dict[str, Any] = Field(default_factory=dict, description="Input JSON schema")
    priority: int = Field(5, description="Server priority")
    
    @property
    def qualified_name(self) -> str:
        """Get fully qualified tool name."""
        return f"{self.namespace}.{self.name}"
    
    @classmethod
    def from_discovery_response(
        cls,
        tool_data: Dict[str, Any],
        server_id: str,
        namespace: str,
        priority: int = 5
    ) -> "ToolDescriptor":
        """Create tool descriptor from server discovery response.
        
        Args:
            tool_data: Tool data from server discovery
            server_id: Server identifier
            namespace: Tool namespace
            priority: Server priority
        
        Returns:
            ToolDescriptor instance
        """
        return cls(
            name=tool_data.get("name", ""),
            namespace=namespace,
            server_id=server_id,
            description=tool_data.get("description", ""),
            input_schema=tool_data.get("inputSchema", {}),
            priority=priority
        )
