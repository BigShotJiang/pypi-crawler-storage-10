"""Discovery engine for MCP Router."""

import asyncio
import logging
from typing import Dict, List, Any, Optional, Protocol
from datetime import datetime, timedelta

from .tool_descriptor import ToolDescriptor
from .registry import ServerRegistry
from .models import ServerConfig

logger = logging.getLogger(__name__)


class ServerAdapter(Protocol):
    """Protocol for server adapters."""
    
    async def discover(self) -> Dict[str, Any]:
        """Discover tools from server.
        
        Returns:
            Discovery response with tools list
        """
        ...


class DiscoveryEngine:
    """Discover and aggregate tools from MCP servers.
    
    The discovery engine queries each registered server for available tools,
    normalizes responses, handles namespace collisions, and caches results.
    
    Example:
        >>> registry = ServerRegistry("~/.prompt-automation/mcp-servers.json")
        >>> engine = DiscoveryEngine(registry)
        >>> tools = await engine.discover_all()
        >>> print(f"Found {len(tools)} tools")
    """
    
    def __init__(
        self,
        registry: ServerRegistry,
        cache_ttl: int = 300,
        cache: Optional[Dict[str, Any]] = None
    ):
        """Initialize discovery engine.
        
        Args:
            registry: Server registry instance
            cache_ttl: Cache TTL in seconds (default 5 minutes)
            cache: Optional cache dict (for testing, uses simple dict if None)
        """
        self.registry = registry
        self.cache_ttl = cache_ttl
        # Use provided cache or create new one
        if cache is not None:
            self._cache = cache
        else:
            self._cache = {}
        self._cache_timestamps: Dict[str, datetime] = {}
    
    async def discover_server(
        self,
        server: ServerConfig,
        adapter: ServerAdapter
    ) -> List[ToolDescriptor]:
        """Discover tools from a single server.
        
        Args:
            server: Server configuration
            adapter: Server adapter instance
        
        Returns:
            List of tool descriptors
        """
        cache_key = f"discovery:{server.id}"
        
        # Check cache
        if cache_key in self._cache:
            cached_time = self._cache_timestamps.get(cache_key)
            if cached_time and (datetime.now() - cached_time).total_seconds() < self.cache_ttl:
                logger.debug(f"Discovery cache hit for {server.id}")
                cached_data = self._cache[cache_key]
                return self._parse_tools(cached_data, server)
        
        # Call adapter
        try:
            logger.info(f"Discovering tools from {server.id}")
            discovery_response = await adapter.discover()
            
            # Cache result
            self._cache[cache_key] = discovery_response
            self._cache_timestamps[cache_key] = datetime.now()
            
            # Parse tools
            tools = self._parse_tools(discovery_response, server)
            logger.info(f"Discovered {len(tools)} tools from {server.id}")
            
            return tools
        
        except Exception as e:
            logger.error(f"Discovery failed for {server.id}: {e}")
            # Return empty list on failure (graceful degradation)
            return []
    
    async def discover_all(
        self,
        adapters: Dict[str, ServerAdapter]
    ) -> Dict[str, ToolDescriptor]:
        """Discover tools from all servers.
        
        Args:
            adapters: Map of server_id -> adapter
        
        Returns:
            Map of qualified_name -> tool descriptor
        """
        servers = self.registry.load_servers()
        
        # Discover from all servers concurrently
        tasks = []
        server_list = []
        for server in servers:
            adapter = adapters.get(server.id)
            if adapter:
                tasks.append(self.discover_server(server, adapter))
                server_list.append(server)
        
        # Gather results
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Aggregate tools
        all_tools: Dict[str, ToolDescriptor] = {}
        
        for server, tools_or_error in zip(server_list, results):
            if isinstance(tools_or_error, Exception):
                logger.error(f"Discovery failed for {server.id}: {tools_or_error}")
                continue
            
            tools = tools_or_error
            for tool in tools:
                # Handle namespace collisions
                if tool.qualified_name in all_tools:
                    existing = all_tools[tool.qualified_name]
                    
                    # Prefer higher priority server
                    if tool.priority > existing.priority:
                        logger.warning(
                            f"Namespace collision for {tool.qualified_name}: "
                            f"preferring {tool.server_id} (priority {tool.priority}) "
                            f"over {existing.server_id} (priority {existing.priority})"
                        )
                        all_tools[tool.qualified_name] = tool
                    else:
                        logger.warning(
                            f"Namespace collision for {tool.qualified_name}: "
                            f"keeping {existing.server_id} (priority {existing.priority}), "
                            f"ignoring {tool.server_id} (priority {tool.priority})"
                        )
                else:
                    all_tools[tool.qualified_name] = tool
        
        return all_tools
    
    def _parse_tools(
        self,
        discovery_response: Dict[str, Any],
        server: ServerConfig
    ) -> List[ToolDescriptor]:
        """Parse tools from discovery response.
        
        Args:
            discovery_response: Server discovery response
            server: Server configuration
        
        Returns:
            List of tool descriptors
        """
        tools_data = discovery_response.get("tools", [])
        
        tools = []
        for tool_data in tools_data:
            # Use explicit namespace from tool data if available,
            # otherwise fall back to server's effective namespace
            tool_namespace = tool_data.get("namespace", server.effective_namespace)
            
            descriptor = ToolDescriptor.from_discovery_response(
                tool_data=tool_data,
                server_id=server.id,
                namespace=tool_namespace,
                priority=server.priority
            )
            tools.append(descriptor)
        
        return tools
    
    def clear_cache(self, server_id: Optional[str] = None) -> None:
        """Clear discovery cache.
        
        Args:
            server_id: Server ID to clear (all if None)
        """
        if server_id:
            cache_key = f"discovery:{server_id}"
            self._cache.pop(cache_key, None)
            self._cache_timestamps.pop(cache_key, None)
            logger.info(f"Cleared discovery cache for {server_id}")
        else:
            self._cache.clear()
            self._cache_timestamps.clear()
            logger.info("Cleared all discovery cache")
    
    def is_cache_valid(self, server_id: str) -> bool:
        """Check if cache is valid for a server.
        
        Args:
            server_id: Server identifier
        
        Returns:
            True if cache is valid
        """
        cache_key = f"discovery:{server_id}"
        if cache_key not in self._cache:
            return False
        
        cached_time = self._cache_timestamps.get(cache_key)
        if not cached_time:
            return False
        
        age = (datetime.now() - cached_time).total_seconds()
        return age < self.cache_ttl
