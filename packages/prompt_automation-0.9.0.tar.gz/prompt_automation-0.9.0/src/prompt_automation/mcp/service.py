"""MCPService facade for backward compatibility.

Provides auto-detection and routing between:
- mcp.client (legacy functional API for single-server mode)
- MCPRouter (new multi-server mode)

Usage:
    service = MCPService.from_config(config)
    tools = await service.discover()
    result = await service.call_tool("server.tool", {...})
"""

import logging
from pathlib import Path
from typing import Optional, Dict, Any, List

from prompt_automation.mcp import client as mcp_client
from prompt_automation.mcp.router.core import MCPRouter
from prompt_automation.mcp.router.registry import ServerRegistry
from prompt_automation.mcp.router.tool_descriptor import ToolDescriptor

logger = logging.getLogger(__name__)


class MCPService:
    """Facade that routes to mcp.client or MCPRouter based on configuration.
    
    Auto-detects single-server vs multi-server mode and delegates accordingly.
    Provides unified interface for backward compatibility.
    """
    
    def __init__(self, router: Optional[MCPRouter] = None, 
                 registry_path: Optional[Path] = None,
                 provider_name: Optional[str] = None):
        """Initialize with backend (functional client API or MCPRouter).
        
        Args:
            router: MCPRouter instance for multi-server mode (None for client mode)
            registry_path: Path to MCP registry (for client mode)
            provider_name: Provider name (for client mode)
        """
        self._router = router
        self._registry_path = registry_path
        self._provider_name = provider_name
        self._mode = "router" if router else "client"
        logger.info(f"MCPService initialized in {self._mode} mode")
    
    @classmethod
    def from_config(cls, config: Optional[Dict[str, Any]] = None) -> "MCPService":
        """Factory method that auto-detects backend based on configuration.
        
        Detection logic:
        - If mcp.router.enabled = true AND multiple servers → MCPRouter
        - Otherwise → functional client API (legacy single-server)
        
        Args:
            config: Configuration dict with mcp.* keys
        
        Returns:
            MCPService instance with appropriate backend
        """
        if config is None:
            config = {}
        
        # Check for router mode
        router_enabled = config.get("mcp", {}).get("router", {}).get("enabled", False)
        servers = config.get("mcp", {}).get("servers", [])
        
        if router_enabled and len(servers) > 1:
            # Multi-server mode → use MCPRouter
            logger.info("Detected multi-server config, using MCPRouter")
            
            # Create registry from config
            registry_path = config.get("mcp", {}).get("router", {}).get("registry_path")
            if registry_path:
                registry = ServerRegistry(Path(registry_path))
            else:
                # Create in-memory registry from config
                registry = ServerRegistry.from_config(servers)
            
            router = MCPRouter(registry=registry)
            return cls(router=router)
        else:
            # Single-server mode → use functional client API
            logger.info("Detected single-server config, using functional client API")
            registry_path_str = config.get("mcp", {}).get("registry_path")
            registry_path = Path(registry_path_str) if registry_path_str else None
            provider_name = config.get("mcp", {}).get("provider")
            return cls(registry_path=registry_path, provider_name=provider_name)
    
    async def discover(self) -> List[ToolDescriptor]:
        """Discover available tools across all servers.
        
        Returns:
            List of tool descriptors
        """
        if self._mode == "router":
            # Router returns dict[server_id, List[ToolDescriptor]]
            all_tools_dict = await self._router.discover_all()
            # Flatten to list
            all_tools = []
            for tools in all_tools_dict.values():
                all_tools.extend(tools)
            return all_tools
        else:
            # Client functional API: discover_provider returns ServerDiscovery
            if not self._provider_name or not self._registry_path:
                logger.warning("No provider configured for client mode")
                return []
            
            discovery = await mcp_client.discover_provider(
                registry_path=self._registry_path,
                identifier=self._provider_name
            )
            
            # Convert ServerDiscovery to List[ToolDescriptor]
            tools = []
            if discovery.tools:
                for tool in discovery.tools:
                    tools.append(ToolDescriptor(
                        name=tool.name,
                        namespace=self._provider_name,  # Use provider name as namespace
                        server_id=self._provider_name,  # Use provider name as server_id
                        description=tool.description or "",
                        input_schema=tool.inputSchema or {}
                    ))
            return tools
    
    async def call_tool(self, tool_name: str, arguments: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Call a tool by name.
        
        Args:
            tool_name: Tool name (router: "server.tool", client: "tool")
            arguments: Tool arguments
        
        Returns:
            Tool result dict
        """
        if arguments is None:
            arguments = {}
        
        if self._mode == "router":
            # Router uses qualified names: "server.tool"
            return await self._router.call_tool(tool_name, arguments)
        else:
            # Client functional API uses simple names: "tool"
            # If qualified name provided, extract tool name
            simple_name = tool_name
            if "." in tool_name:
                _, simple_name = tool_name.split(".", 1)
            
            if not self._provider_name or not self._registry_path:
                raise ValueError("No provider configured for client mode")
            
            result = await mcp_client.call_tool(
                registry_path=self._registry_path,
                identifier=self._provider_name,
                tool_name=simple_name,
                arguments=arguments
            )
            
            # Convert to dict (result is already a dict-like object)
            return dict(result)
    
    async def close(self):
        """Close backend connections."""
        if self._mode == "router" and self._router:
            await self._router.close()
        # Client mode: functional API doesn't require explicit close
    
    def __repr__(self) -> str:
        return f"MCPService(mode={self._mode})"
