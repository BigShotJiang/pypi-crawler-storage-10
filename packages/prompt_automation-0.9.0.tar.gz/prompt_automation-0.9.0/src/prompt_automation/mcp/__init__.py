"""MCP (Model Context Protocol) integration."""

from prompt_automation.mcp.service import MCPService

__all__ = ["MCPService"]
