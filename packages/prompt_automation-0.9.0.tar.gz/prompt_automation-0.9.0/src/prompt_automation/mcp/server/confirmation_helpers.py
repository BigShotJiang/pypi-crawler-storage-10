"""
Confirmation helpers for MCP note operations.

Provides reusable helper functions for showing confirmation dialogs
before destructive MCP operations. These can be integrated into existing
MCP tools without modifying their core logic.
"""

from pathlib import Path
from typing import Dict, List, Optional
import logging

from ...gui.confirmation_dialogs import FileWriteConfirmDialog, ExpensiveRAGWarningDialog

logger = logging.getLogger(__name__)

# Default threshold for "expensive" RAG searches
DEFAULT_RAG_THRESHOLD = 100


def confirm_file_write(
    file_path: Path,
    current_content: str,
    new_content: str
) -> Dict[str, bool]:
    """
    Show file write confirmation dialog.
    
    Displays side-by-side diff preview and allows user to confirm or cancel
    the write operation, with optional backup creation.
    
    Args:
        file_path: Path to file being written
        current_content: Current file content (empty string for new files)
        new_content: New content to write
        
    Returns:
        Dict with:
            - confirmed: True if user clicked Confirm, False if Cancel
            - create_backup: True if user checked backup option (only when confirmed=True)
    """
    dialog = FileWriteConfirmDialog(
        parent=None,  # No parent window (standalone)
        file_path=str(file_path),
        current=current_content,
        new=new_content
    )
    
    # Block until user responds
    dialog.wait_window()
    
    if dialog.result:
        logger.info(f"User confirmed write to {file_path} (backup={dialog.create_backup})")
        return {
            "confirmed": True,
            "create_backup": dialog.create_backup
        }
    else:
        logger.info(f"User cancelled write to {file_path}")
        return {
            "confirmed": False,
            "create_backup": False
        }


def estimate_rag_candidates(
    vault_root: Path,
    folders: Optional[List[str]] = None
) -> int:
    """
    Estimate number of files a RAG search will scan.
    
    Args:
        vault_root: Root path of vault
        folders: Optional list of folder names to filter by
        
    Returns:
        Estimated number of markdown files to be scanned
    """
    if not folders:
        # Count all markdown files
        return len(list(vault_root.rglob("*.md")))
    
    # Count files in specified folders
    count = 0
    for folder in folders:
        folder_path = vault_root / folder
        if folder_path.exists():
            count += len(list(folder_path.rglob("*.md")))
    
    return count


def check_rag_expense(
    vault_root: Path,
    folders: Optional[List[str]] = None,
    threshold: int = DEFAULT_RAG_THRESHOLD
) -> Dict[str, any]:
    """
    Check if RAG search is expensive and show warning if needed.
    
    Shows ExpensiveRAGWarningDialog when file count exceeds threshold,
    allowing user to proceed, cancel, or filter folders.
    
    Args:
        vault_root: Root path of vault
        folders: Optional list of folder names to filter by
        threshold: File count threshold for "expensive" (default: 100)
        
    Returns:
        Dict with:
            - proceed: True if search should continue, False if cancelled
            - action: "proceed", "cancel", or "filter"
            - skipped: True if warning was skipped (below threshold)
            - file_count: Number of files to be scanned
    """
    file_count = estimate_rag_candidates(vault_root, folders)
    
    # Skip warning if below threshold
    if file_count <= threshold:
        logger.debug(f"RAG search below threshold ({file_count} ≤ {threshold}), proceeding")
        return {
            "proceed": True,
            "action": "proceed",
            "skipped": True,
            "file_count": file_count
        }
    
    # Estimate time (rough: 50 files/second)
    estimated_seconds = max(1, file_count // 50)
    
    # Show warning dialog
    dialog = ExpensiveRAGWarningDialog(
        parent=None,
        file_count=file_count,
        estimated_seconds=estimated_seconds
    )
    
    # Block until user responds
    dialog.wait_window()
    
    if dialog.result == "proceed":
        logger.info(f"User proceeding with expensive RAG search ({file_count} files)")
        return {
            "proceed": True,
            "action": "proceed",
            "skipped": False,
            "file_count": file_count
        }
    elif dialog.result == "filter":
        logger.info(f"User requested folder filtering for RAG search")
        return {
            "proceed": False,
            "action": "filter",
            "skipped": False,
            "file_count": file_count
        }
    else:  # cancel or None
        logger.info(f"User cancelled expensive RAG search")
        return {
            "proceed": False,
            "action": "cancel",
            "skipped": False,
            "file_count": file_count
        }
