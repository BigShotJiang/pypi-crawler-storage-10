from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from .constants import INFO_CLOSE_SAVE
from .tooltip import create_tooltip
from ..variables import storage
from ..features import is_mcp_enabled, is_mcp_observability_enabled
from ..errorlog import get_logger

_log = get_logger(__name__)


class SectionHeader:
    """Reusable section header widget with title, description, and separator.
    
    Example:
        header = SectionHeader(
            parent=frame,
            title="Performance Settings",
            description="Configure cache, GPU, and performance profiles"
        )
        header.pack(fill="x", pady=(12, 8))
    """
    
    def __init__(
        self,
        parent: tk.Widget,
        title: str,
        description: str = ""
    ):
        """Initialize section header.
        
        Args:
            parent: Parent widget
            title: Section title (displayed in bold)
            description: Optional description text (displayed below title in gray)
        """
        self.frame = tk.Frame(parent)
        
        # Title label
        title_label = tk.Label(
            self.frame,
            text=title,
            font=("TkDefaultFont", 10, "bold"),
            anchor="w"
        )
        title_label.pack(anchor="w", fill="x")
        
        # Optional description
        if description:
            desc_label = tk.Label(
                self.frame,
                text=description,
                font=("TkDefaultFont", 9),
                fg="gray",
                anchor="w",
                wraplength=450  # Wrap long descriptions
            )
            desc_label.pack(anchor="w", fill="x", pady=(2, 0))
        
        # Separator line
        separator = tk.Frame(self.frame, height=1, bg="lightgray")
        separator.pack(fill="x", pady=(4, 0))
    
    def pack(self, **kwargs) -> None:
        """Pack the section header frame."""
        self.frame.pack(**kwargs)
    
    def grid(self, **kwargs) -> None:
        """Grid the section header frame."""
        self.frame.grid(**kwargs)
    
    def destroy(self) -> None:
        """Destroy the section header."""
        self.frame.destroy()


def _refresh_hotkey() -> None:
    """Refresh background hotkey registration best-effort."""
    try:  # pragma: no cover - relies on optional service
        from ..cli.controller import PromptCLI

        PromptCLI()._maybe_register_background_hotkey()
    except Exception as e:  # pragma: no cover - defensive
        try:
            _log.error("hotkey_refresh_failed error=%s", e)
        except Exception:
            pass


def open_settings_panel(root) -> None:  # pragma: no cover - GUI heavy
    """Open settings panel window with organized sections."""
    win = tk.Toplevel(root)
    win.title("Settings")
    win.geometry("500x650")  # Increased height for more sections
    win.resizable(True, True)
    
    # Main frame with padding
    main_frame = tk.Frame(win, padx=12, pady=8)
    main_frame.pack(fill="both", expand=True)
    
    # Create canvas and scrollbar for scrollable content
    canvas = tk.Canvas(main_frame, highlightthickness=0)
    scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
    scrollable_frame = tk.Frame(canvas)
    
    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
    )
    
    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)
    
    # Pack canvas and scrollbar
    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")
    
    # Enable mousewheel scrolling
    def _on_mousewheel(event):
        canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
    
    canvas.bind_all("<MouseWheel>", _on_mousewheel)
    
    # Store variables to prevent garbage collection
    win._variables = {}
    
    # ========== VARIABLES ==========
    # Store variables as window attributes to prevent garbage collection
    bg_var = tk.BooleanVar(value=storage.get_background_hotkey_enabled())
    esp_var = tk.BooleanVar(value=storage.get_espanso_enabled())
    use_mcp_server_var = tk.BooleanVar(value=storage.get_use_mcp_server())
    local_cache_var = tk.BooleanVar(value=storage.get_local_cache_enabled())
    
    # Keep variables alive
    win._variables['bg'] = bg_var
    win._variables['esp'] = esp_var
    win._variables['mcp'] = use_mcp_server_var
    win._variables['cache'] = local_cache_var

    # MCP Debug Mode
    debug_mode_labels = [
        ("Off", "off"),
        ("CLI only", "cli"),
        ("CLI + Observability", "observability"),
    ]
    _label_to_value = {label: value for label, value in debug_mode_labels}
    _value_to_label = {value: label for label, value in debug_mode_labels}
    persisted_mode = storage.get_mcp_debug_mode()
    if is_mcp_observability_enabled():
        effective_mode = "observability"
    elif is_mcp_enabled():
        effective_mode = "cli"
    else:
        effective_mode = persisted_mode
    debug_mode_var = tk.StringVar(value=_value_to_label.get(effective_mode, "Off"))
    win._variables['debug_mode'] = debug_mode_var
    
    # Profile switcher
    profile_var = tk.StringVar(value="standard")  # Will be detected from config
    win._variables['profile'] = profile_var
    
    # ========== CALLBACKS ==========
    def _toggle_bg() -> None:
        try:
            new_value = bg_var.get()
            _log.info("toggle_background_hotkey value=%s", new_value)
            storage.set_background_hotkey_enabled(new_value)
            _refresh_hotkey()
            _log.info("toggle_background_hotkey_success new_value=%s", new_value)
        except Exception as e:
            _log.error("toggle_background_hotkey_failed error=%s", e)

    def _toggle_esp() -> None:
        try:
            new_value = esp_var.get()
            _log.info("toggle_espanso value=%s", new_value)
            storage.set_espanso_enabled(new_value)
            _refresh_hotkey()
            _log.info("toggle_espanso_success new_value=%s", new_value)
        except Exception as e:
            _log.error("toggle_espanso_failed error=%s", e)

    def _toggle_use_mcp_server() -> None:
        try:
            new_value = use_mcp_server_var.get()
            _log.info("toggle_use_mcp_server value=%s", new_value)
            storage.set_use_mcp_server(new_value)
            _log.info("toggle_use_mcp_server_success new_value=%s", new_value)
        except Exception as e:
            _log.error("toggle_use_mcp_server_failed error=%s", e)

    def _toggle_local_cache() -> None:
        try:
            new_value = local_cache_var.get()
            _log.info("toggle_local_cache value=%s", new_value)
            storage.set_local_cache_enabled(new_value)
            _log.info("toggle_local_cache_success new_value=%s", new_value)
        except Exception as e:
            _log.error("toggle_local_cache_failed error=%s", e)

    def _set_debug_mode(selected_label: str) -> None:
        mode_value = _label_to_value.get(selected_label, "off")
        try:
            storage.set_mcp_debug_mode(mode_value)
        except Exception as e:
            _log.error("set_mcp_debug_mode_failed error=%s", e)
            debug_mode_var.set(_value_to_label.get(storage.get_mcp_debug_mode(), "Off"))
    
    def _switch_profile() -> None:
        """Switch performance profile."""
        try:
            from ..settings import ConfigManager
            from .toast import show_toast
            
            profile = profile_var.get()
            config_mgr = ConfigManager()
            config_mgr.switch_profile(profile)
            config_mgr.save()
            
            show_toast(f"✓ Switched to {profile} profile", toast_type="success")
            _log.info("profile_switched profile=%s", profile)
        except Exception as e:
            _log.error("profile_switch_failed error=%s", e)
            tk.messagebox.showerror("Error", f"Failed to switch profile:\n\n{e}")
    
    # ========== SECTION 1: GENERAL SETTINGS ==========
    SectionHeader(
        parent=scrollable_frame,
        title="General Settings",
        description="Application behavior and integrations"
    ).pack(fill="x", pady=(0, 8))
    
    bg_check = tk.Checkbutton(
        scrollable_frame,
        text="Enable background activation hotkey",
        variable=bg_var,
        command=_toggle_bg,
        anchor="w",
        justify="left",
    )
    bg_check.pack(anchor="w", padx=(20, 0))
    create_tooltip(
        bg_check,
        "Register a global hotkey to open prompt-automation without the GUI.\n"
        "Default: Ctrl+Alt+P (Windows) or Cmd+Opt+P (Mac).\n"
        "Requires keyboard library installed."
    )
    
    esp_check = tk.Checkbutton(
        scrollable_frame,
        text="Enable Espanso integration",
        variable=esp_var,
        command=_toggle_esp,
        anchor="w",
        justify="left",
    )
    esp_check.pack(anchor="w", padx=(20, 0), pady=(4, 0))
    create_tooltip(
        esp_check,
        "Sync templates with Espanso text expansion tool.\n"
        "Allows quick template insertion via :shortcuts in any app.\n"
        "Requires Espanso installed (Linux/Mac only)."
    )
    
    # Profile switcher (moved from Advanced Settings)
    tk.Label(
        scrollable_frame,
        text="Performance Profile",
        font=("TkDefaultFont", 9, "bold")
    ).pack(anchor="w", padx=(20, 0), pady=(8, 2))
    
    profile_descriptions = {
        "lightweight": "Minimal memory (32MB cache, CPU-only)",
        "standard": "Balanced performance (256MB cache, auto-detect GPU)",
        "performance": "Maximum speed (512MB+ cache, force GPU)"
    }
    
    profile_frame = tk.Frame(scrollable_frame)
    profile_frame.pack(anchor="w", padx=(30, 0), pady=(0, 4))
    
    profile_tooltips = {
        "lightweight": "Minimal resource usage. Best for older machines or when running many apps.\nCache: 32MB memory only | GPU: Disabled | LLM: CPU-based",
        "standard": "Balanced performance. Recommended for most users.\nCache: 256MB (memory + disk) | GPU: Auto-detect | LLM: GPU if available",
        "performance": "Maximum speed. Requires dedicated GPU and 2GB+ free memory.\nCache: 512MB+ (memory + disk + VRAM) | GPU: Force enabled | LLM: GPU-accelerated"
    }
    
    for profile_name, desc in profile_descriptions.items():
        rb = tk.Radiobutton(
            profile_frame,
            text=f"{profile_name.capitalize()}: {desc}",
            variable=profile_var,
            value=profile_name,
            command=_switch_profile,
            anchor="w"
        )
        rb.pack(anchor="w", pady=2)
        create_tooltip(rb, profile_tooltips[profile_name])
    
    # ========== SECTION 2: PERFORMANCE SETTINGS ==========
    SectionHeader(
        parent=scrollable_frame,
        title="Performance Settings",
        description="Cache and GPU configuration"
    ).pack(fill="x", pady=(12, 8))
    
    cache_frame = tk.Frame(scrollable_frame)
    cache_frame.pack(anchor="w", padx=(20, 0), fill="x")
    
    cache_check = tk.Checkbutton(
        cache_frame,
        text="Enable local cache for offline reads",
        variable=local_cache_var,
        command=_toggle_local_cache,
        anchor="w",
        justify="left",
    )
    cache_check.pack(side="left", anchor="w")
    create_tooltip(
        cache_check,
        "Store rendered templates and LLM responses in memory/disk cache.\n"
        "Benefits: Faster template loading, offline access, reduced LLM API calls.\n"
        "Cache size and behavior controlled by Performance Profile above."
    )
    
    # Inline cache stats button
    def _open_cache_stats():
        try:
            from .cache_stats_dialog import CacheStatsDialog
            from ..cache.config_integration import create_cache_from_config
            from ..settings import ConfigManager
            
            config_mgr = ConfigManager()
            cache_mgr = create_cache_from_config(config_mgr.config)
            
            if cache_mgr is None:
                tk.messagebox.showinfo(
                    "Cache Not Available",
                    "Cache is not enabled.\n\nEnable cache above to view statistics."
                )
                return
            
            CacheStatsDialog(win, cache_mgr)
        except Exception as exc:
            _log.error("cache_stats_dialog_failed error=%s", exc)
            tk.messagebox.showerror("Error", f"Failed to open Cache Statistics:\n\n{exc}")
    
    stats_btn = tk.Button(
        cache_frame,
        text="Stats...",
        command=_open_cache_stats,
        font=("TkDefaultFont", 8)
    )
    stats_btn.pack(side="left", padx=(8, 0))
    create_tooltip(
        stats_btn,
        "View cache performance metrics:\n"
        "• Hit rate (% of requests served from cache)\n"
        "• Memory/disk usage\n"
        "• Most frequently accessed templates"
    )
    
    # ========== SECTION 3: MCP SETTINGS ==========
    SectionHeader(
        parent=scrollable_frame,
        title="MCP Settings",
        description="Model Context Protocol server integration"
    ).pack(fill="x", pady=(12, 8))
    
    mcp_check = tk.Checkbutton(
        scrollable_frame,
        text="Use MCP server integration",
        variable=use_mcp_server_var,
        command=_toggle_use_mcp_server,
        anchor="w",
        justify="left",
    )
    mcp_check.pack(anchor="w", padx=(20, 0))
    create_tooltip(
        mcp_check,
        "Enable Model Context Protocol integration for external tools.\n"
        "Allows templates to interact with filesystem, APIs, databases via MCP servers.\n"
        "Requires MCP servers configured in mcp-registry.json."
    )

    tk.Label(
        scrollable_frame,
        text="Setup help: see docs/MCP_INTEGRATION.md",
        justify="left",
        anchor="w",
        font=("TkDefaultFont", 8),
        fg="gray"
    ).pack(anchor="w", padx=(30, 0), pady=(2, 0))
    
    debug_label = tk.Label(
        scrollable_frame,
        text="MCP Debug Mode",
        font=("TkDefaultFont", 9, "bold")
    )
    debug_label.pack(anchor="w", padx=(20, 0), pady=(8, 2))
    create_tooltip(
        debug_label,
        "Debug mode controls MCP logging and observability:\n"
        "• Off: No MCP debugging\n"
        "• CLI only: Log MCP requests/responses to console\n"
        "• CLI + Observability: Full tracing with Langfuse/Langsmith"
    )
    
    debug_menu = tk.OptionMenu(
        scrollable_frame,
        debug_mode_var,
        *[label for label, _ in debug_mode_labels],
        command=_set_debug_mode,
    )
    debug_menu.pack(anchor="w", padx=(30, 0), pady=(0, 0))
    
    # ========== SECTION 4: ANALYTICS SETTINGS (NEW) ==========
    SectionHeader(
        parent=scrollable_frame,
        title="Analytics Settings",
        description="Usage data collection and privacy"
    ).pack(fill="x", pady=(12, 8))
    
    # TODO: Wire to actual analytics storage when implemented
    analytics_var = tk.BooleanVar(value=True)  # Default ON
    win._variables['analytics'] = analytics_var
    
    analytics_check = tk.Checkbutton(
        scrollable_frame,
        text="Enable anonymous usage analytics",
        variable=analytics_var,
        anchor="w",
        justify="left",
    )
    analytics_check.pack(anchor="w", padx=(20, 0))
    create_tooltip(
        analytics_check,
        "Collect anonymous usage statistics to improve prompt-automation.\n"
        "Data collected: Template usage frequency, feature adoption, error rates.\n"
        "NOT collected: Template content, variable values, personal information.\n"
        "Stored locally in usage.db, optionally synced to privacy-respecting analytics."
    )
    
    tk.Label(
        scrollable_frame,
        text="Helps improve features. No personal data collected.",
        font=("TkDefaultFont", 8),
        fg="gray",
        anchor="w"
    ).pack(anchor="w", padx=(30, 0), pady=(2, 0))
    
    # ========== SECTION 5: OBSIDIAN SETTINGS (NEW) ==========
    SectionHeader(
        parent=scrollable_frame,
        title="Obsidian Integration",
        description="Connect to Obsidian vault for RAG features"
    ).pack(fill="x", pady=(12, 8))
    
    # TODO: Wire to actual obsidian storage when implemented
    obsidian_var = tk.BooleanVar(value=False)  # Default OFF
    win._variables['obsidian'] = obsidian_var
    
    obsidian_check = tk.Checkbutton(
        scrollable_frame,
        text="Enable Obsidian RAG integration",
        variable=obsidian_var,
        anchor="w",
        justify="left",
    )
    obsidian_check.pack(anchor="w", padx=(20, 0))
    create_tooltip(
        obsidian_check,
        "Use your Obsidian vault as a knowledge base for template generation.\n"
        "Retrieval-Augmented Generation (RAG) searches your notes to provide context.\n"
        "Requires: Obsidian installed, vault path configured below.\n"
        "Feature 23 - Currently in development."
    )
    
    obsidian_path_frame = tk.Frame(scrollable_frame)
    obsidian_path_frame.pack(anchor="w", padx=(30, 0), pady=(4, 0), fill="x")
    
    vault_label = tk.Label(
        obsidian_path_frame,
        text="Vault path:",
        font=("TkDefaultFont", 9)
    )
    vault_label.pack(side="left")
    create_tooltip(
        vault_label,
        "Absolute path to your Obsidian vault directory.\n"
        "Example: /home/user/Documents/ObsidianVault\n"
        "The vault will be indexed for RAG search."
    )
    
    obsidian_path_var = tk.StringVar(value="")  # TODO: Load from storage
    win._variables['obsidian_path'] = obsidian_path_var
    
    path_entry = tk.Entry(
        obsidian_path_frame,
        textvariable=obsidian_path_var,
        width=30
    )
    path_entry.pack(side="left", padx=(4, 4))
    create_tooltip(
        path_entry,
        "Enter the full path to your Obsidian vault,\n"
        "or click Browse to select it."
    )
    
    def _browse_vault():
        from tkinter import filedialog
        path = filedialog.askdirectory(title="Select Obsidian Vault")
        if path:
            obsidian_path_var.set(path)
    
    browse_btn = tk.Button(
        obsidian_path_frame,
        text="Browse...",
        command=_browse_vault,
        font=("TkDefaultFont", 8)
    )
    browse_btn.pack(side="left")
    create_tooltip(browse_btn, "Open file browser to select your Obsidian vault folder.")
    
    # ========== BOTTOM ACTIONS ==========
    # Separator before bottom actions
    tk.Frame(scrollable_frame, height=1, bg="gray").pack(fill="x", pady=(16, 12))
    
    tk.Label(
        scrollable_frame,
        text="Advanced Options",
        font=("TkDefaultFont", 9, "bold")
    ).pack(anchor="w")
    
    def _open_config_manager():
        try:
            from .config_manager_panel import open_config_manager_panel
            
            open_config_manager_panel(win)
        except Exception as exc:
            _log.error("config_manager_panel_failed error=%s", exc)
            tk.messagebox.showerror("Error", f"Failed to open Advanced Settings:\n\n{exc}")
    
    def _open_manual_packaging():
        try:
            from .manual_packaging_dialog import open_manual_packaging_dialog

            open_manual_packaging_dialog(win)
        except Exception as exc:
            _log.error("manual_packaging_dialog_failed error=%s", exc)
    
    advanced_btn = tk.Button(
        scrollable_frame,
        text="Advanced Settings...",
        command=_open_config_manager
    )
    advanced_btn.pack(anchor="w", pady=(4, 0))
    create_tooltip(
        advanced_btn,
        "Open Configuration Manager for advanced options:\n"
        "• Hot-reload config changes\n"
        "• Browse all configuration settings\n"
        "• Direct config.json editing\n"
        "• Feature flags and experimental settings"
    )
    
    packaging_btn = tk.Button(
        scrollable_frame,
        text="Manual packaging...",
        command=_open_manual_packaging
    )
    packaging_btn.pack(anchor="w", pady=(4, 0))
    create_tooltip(
        packaging_btn,
        "Create distributable packages (.exe, .app, .deb) manually.\n"
        "Useful for offline distribution or custom builds.\n"
        "Requires packaging tools installed (PyInstaller, etc.)."
    )
    
    # Close button at the very bottom (not in scrollable area)
    button_frame = tk.Frame(main_frame)
    button_frame.pack(side="bottom", fill="x", pady=(8, 0))
    
    tk.Button(
        button_frame,
        text=INFO_CLOSE_SAVE,
        command=win.destroy
    ).pack(side="right")


__all__ = ["open_settings_panel"]
