"""Keyboard shortcuts help dialog for GUI accessibility."""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from typing import Optional


class ShortcutHelpDialog:
    """Display keyboard shortcuts in a modal dialog.
    
    Shows context-aware shortcuts organized by frame/section.
    Triggered by ? or F1 key.
    """
    
    def __init__(self, parent: tk.Widget, current_frame: Optional[str] = None):
        """
        Initialize the shortcuts help dialog.
        
        Args:
            parent: Parent widget (typically root window)
            current_frame: Current frame name ("select", "variables", "review", None for global)
        """
        self.parent = parent
        self.current_frame = current_frame
        self.window: Optional[tk.Toplevel] = None
    
    def show(self):
        """Display the shortcuts dialog."""
        if self.window is not None:
            # Dialog already open - just raise it
            self.window.lift()
            self.window.focus_force()
            return
        
        # Create dialog window
        self.window = tk.Toplevel(self.parent)
        self.window.title("⌨️ Keyboard Shortcuts")
        self.window.geometry("600x500")
        self.window.resizable(False, False)
        
        # Make modal
        self.window.transient(self.parent)
        self.window.grab_set()
        
        # Center on parent
        self.window.update_idletasks()
        x = self.parent.winfo_x() + (self.parent.winfo_width() - 600) // 2
        y = self.parent.winfo_y() + (self.parent.winfo_height() - 500) // 2
        self.window.geometry(f"+{x}+{y}")
        
        # Build content
        self._build_content()
        
        # Keybindings
        self.window.bind("<Escape>", lambda e: self.close())
        self.window.bind("<Return>", lambda e: self.close())
        self.window.bind("?", lambda e: self.close())
        self.window.bind("<F1>", lambda e: self.close())
        
        # Handle window close
        self.window.protocol("WM_DELETE_WINDOW", self.close)
        
        # Focus the window
        self.window.focus_force()
    
    def _build_content(self):
        """Build dialog content with shortcuts organized by section."""
        # Header
        header = tk.Frame(self.window, bg="#2563eb", height=60)
        header.pack(fill="x")
        header.pack_propagate(False)
        
        tk.Label(
            header,
            text="⌨️ Keyboard Shortcuts",
            font=("Arial", 16, "bold"),
            bg="#2563eb",
            fg="white"
        ).pack(pady=15)
        
        # Scrollable content area
        canvas = tk.Canvas(self.window, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.window, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="white")
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Add shortcuts sections
        self._add_frame_shortcuts(scrollable_frame)
        self._add_global_shortcuts(scrollable_frame)
        
        # Pack scrollable area
        canvas.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        scrollbar.pack(side="right", fill="y")
        
        # Footer with close button
        footer = tk.Frame(self.window, bg="#f3f4f6", height=50)
        footer.pack(fill="x", side="bottom")
        footer.pack_propagate(False)
        
        tk.Button(
            footer,
            text="Close",
            command=self.close,
            width=12,
            bg="#2563eb",
            fg="white",
            font=("Arial", 10, "bold"),
            relief="flat",
            cursor="hand2"
        ).pack(pady=10)
    
    def _add_section(self, parent: tk.Frame, title: str, shortcuts: list[tuple[str, str]]):
        """
        Add a shortcuts section with title and shortcuts list.
        
        Args:
            parent: Parent frame
            title: Section title (e.g., "Frame 1: Template Selection")
            shortcuts: List of (key, description) tuples
        """
        # Section title
        title_label = tk.Label(
            parent,
            text=title,
            font=("Arial", 12, "bold"),
            bg="white",
            fg="#1f2937",
            anchor="w"
        )
        title_label.pack(fill="x", padx=20, pady=(15, 5))
        
        # Shortcuts list
        for key, description in shortcuts:
            shortcut_frame = tk.Frame(parent, bg="white")
            shortcut_frame.pack(fill="x", padx=30, pady=2)
            
            # Key label (styled like a keyboard key)
            key_label = tk.Label(
                shortcut_frame,
                text=key,
                font=("Courier New", 10, "bold"),
                bg="#e5e7eb",
                fg="#374151",
                padx=8,
                pady=2,
                relief="raised",
                borderwidth=1
            )
            key_label.pack(side="left")
            
            # Description
            desc_label = tk.Label(
                shortcut_frame,
                text=description,
                font=("Arial", 10),
                bg="white",
                fg="#4b5563",
                anchor="w"
            )
            desc_label.pack(side="left", padx=10)
    
    def _add_frame_shortcuts(self, parent: tk.Frame):
        """Add frame-specific shortcuts."""
        # Frame 1: Template Selection
        self._add_section(parent, "📋 Frame 1: Template Selection", [
            ("Enter", "Select highlighted template and continue"),
            ("1-9", "Quick select template by number"),
            ("↑ / ↓", "Navigate template list"),
            ("Type", "Search templates by name"),
            ("Esc", "Cancel and close application"),
        ])
        
        # Frame 2: Variable Collection
        self._add_section(parent, "📝 Frame 2: Variable Collection", [
            ("Ctrl+Enter", "Continue to review (collect all variables)"),
            ("Tab", "Move to next field"),
            ("Shift+Tab", "Move to previous field"),
            ("Ctrl+S", "Skip remaining optional fields"),
            ("Esc", "Cancel and return to template selection"),
        ])
        
        # Frame 3: Review & Output
        self._add_section(parent, "👁️ Frame 3: Review & Output", [
            ("Ctrl+Enter", "Finish and copy to clipboard (then close)"),
            ("Ctrl+Shift+C", "Copy to clipboard without closing"),
            ("Esc", "Cancel and return to variable collection"),
        ])
    
    def _add_global_shortcuts(self, parent: tk.Frame):
        """Add global shortcuts that work everywhere."""
        self._add_section(parent, "🌐 Global Shortcuts", [
            ("?", "Show this keyboard shortcuts help"),
            ("F1", "Show this keyboard shortcuts help"),
            ("Ctrl+,", "Open settings (if available)"),
        ])
    
    def close(self):
        """Close the dialog."""
        if self.window is not None:
            self.window.grab_release()
            self.window.destroy()
            self.window = None


def show_keyboard_shortcuts(parent: tk.Widget, current_frame: Optional[str] = None):
    """
    Convenience function to show keyboard shortcuts dialog.
    
    Args:
        parent: Parent widget (typically root window)
        current_frame: Current frame name for context highlighting
    
    Example:
        show_keyboard_shortcuts(root, current_frame="variables")
    """
    dialog = ShortcutHelpDialog(parent, current_frame)
    dialog.show()


__all__ = ["ShortcutHelpDialog", "show_keyboard_shortcuts"]
