"""Button styling utility for consistent visual hierarchy.

Provides standardized button styles across the application:
- Primary: Blue, bold - main actions (Save, Finish, Submit)
- Secondary: Gray, normal - supporting actions (Cancel, Close)
- Danger: Red, bold - destructive actions (Delete, Reset)

Example:
    >>> import tkinter as tk
    >>> from button_styles import apply_primary_style
    >>> 
    >>> root = tk.Tk()
    >>> btn = tk.Button(root, text="Save", command=save_action)
    >>> apply_primary_style(btn)
    >>> btn.pack()
"""

from __future__ import annotations
import tkinter as tk
from typing import Optional


# Color palette
PRIMARY_BG = "#0066cc"      # Blue
PRIMARY_FG = "white"
PRIMARY_ACTIVE_BG = "#0052a3"  # Darker blue on click

SECONDARY_BG = "#e0e0e0"    # Light gray
SECONDARY_FG = "black"
SECONDARY_ACTIVE_BG = "#c0c0c0"  # Darker gray on click

DANGER_BG = "#d32f2f"       # Red
DANGER_FG = "white"
DANGER_ACTIVE_BG = "#b71c1c"  # Darker red on click

DEFAULT_WIDTH = 12
DEFAULT_PADX = 8
DEFAULT_PADY = 4


def apply_primary_style(button: tk.Button, width: Optional[int] = None) -> None:
    """Apply primary button style (blue, bold) for main actions.
    
    Use for: Save, Finish, Submit, OK, Apply, Confirm
    
    Args:
        button: Button widget to style
        width: Button width (uses DEFAULT_WIDTH if None)
    """
    button.config(
        bg=PRIMARY_BG,
        fg=PRIMARY_FG,
        activebackground=PRIMARY_ACTIVE_BG,
        activeforeground=PRIMARY_FG,
        font=("TkDefaultFont", 9, "bold"),
        relief="raised",
        borderwidth=1,
        width=width if width is not None else DEFAULT_WIDTH,
        padx=DEFAULT_PADX,
        pady=DEFAULT_PADY,
        cursor="hand2"
    )


def apply_secondary_style(button: tk.Button, width: Optional[int] = None) -> None:
    """Apply secondary button style (gray, normal) for supporting actions.
    
    Use for: Cancel, Close, Back, View, Copy
    
    Args:
        button: Button widget to style
        width: Button width (uses DEFAULT_WIDTH if None)
    """
    button.config(
        bg=SECONDARY_BG,
        fg=SECONDARY_FG,
        activebackground=SECONDARY_ACTIVE_BG,
        activeforeground=SECONDARY_FG,
        font=("TkDefaultFont", 9),
        relief="raised",
        borderwidth=1,
        width=width if width is not None else DEFAULT_WIDTH,
        padx=DEFAULT_PADX,
        pady=DEFAULT_PADY,
        cursor="hand2"
    )


def apply_danger_style(button: tk.Button, width: Optional[int] = None) -> None:
    """Apply danger button style (red, bold) for destructive actions.
    
    Use for: Delete, Reset, Remove, Clear
    
    Args:
        button: Button widget to style
        width: Button width (uses DEFAULT_WIDTH if None)
    """
    button.config(
        bg=DANGER_BG,
        fg=DANGER_FG,
        activebackground=DANGER_ACTIVE_BG,
        activeforeground=DANGER_FG,
        font=("TkDefaultFont", 9, "bold"),
        relief="raised",
        borderwidth=1,
        width=width if width is not None else DEFAULT_WIDTH,
        padx=DEFAULT_PADX,
        pady=DEFAULT_PADY,
        cursor="hand2"
    )


def create_primary_button(parent: tk.Widget, text: str, command, width: Optional[int] = None) -> tk.Button:
    """Create a button with primary style applied.
    
    Args:
        parent: Parent widget
        text: Button text
        command: Button command callback
        width: Button width (uses DEFAULT_WIDTH if None)
    
    Returns:
        Styled button widget
    """
    button = tk.Button(parent, text=text, command=command)
    apply_primary_style(button, width=width)
    return button


def create_secondary_button(parent: tk.Widget, text: str, command, width: Optional[int] = None) -> tk.Button:
    """Create a button with secondary style applied.
    
    Args:
        parent: Parent widget
        text: Button text
        command: Button command callback
        width: Button width (uses DEFAULT_WIDTH if None)
    
    Returns:
        Styled button widget
    """
    button = tk.Button(parent, text=text, command=command)
    apply_secondary_style(button, width=width)
    return button


def create_danger_button(parent: tk.Widget, text: str, command, width: Optional[int] = None) -> tk.Button:
    """Create a button with danger style applied.
    
    Args:
        parent: Parent widget
        text: Button text
        command: Button command callback
        width: Button width (uses DEFAULT_WIDTH if None)
    
    Returns:
        Styled button widget
    """
    button = tk.Button(parent, text=text, command=command)
    apply_danger_style(button, width=width)
    return button
