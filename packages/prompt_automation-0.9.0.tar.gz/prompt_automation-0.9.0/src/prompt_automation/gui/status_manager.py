"""Status message manager with auto-clear timer.

Provides temporary status messages that automatically clear after a delay.
Useful for success confirmations, warnings, and transient notifications.

Example:
    >>> import tkinter as tk
    >>> root = tk.Tk()
    >>> label = tk.Label(root, text="")
    >>> label.pack()
    >>> 
    >>> manager = StatusManager(label, auto_clear_ms=3000)
    >>> manager.show("Saved successfully!", fg="green")
    >>> # Label shows message for 3 seconds, then clears automatically
"""

from __future__ import annotations
import tkinter as tk
from typing import Optional


class StatusManager:
    """Manages status label with auto-clear functionality.
    
    Displays temporary messages that automatically clear after a delay.
    Supports message queueing, manual clearing, and timer cancellation.
    """
    
    def __init__(
        self,
        label: tk.Label,
        auto_clear_ms: int = 3000,
        default_text: str = "",
        default_fg: str = "black"
    ):
        """Initialize status manager.
        
        Args:
            label: Tkinter label to manage
            auto_clear_ms: Milliseconds before auto-clearing (0 = disabled)
            default_text: Text to show when cleared
            default_fg: Foreground color when cleared
        """
        self.label = label
        self.auto_clear_ms = auto_clear_ms
        self.default_text = default_text
        self.default_fg = default_fg
        self._timer_id: Optional[str] = None
    
    def show(
        self,
        text: str,
        fg: Optional[str] = None,
        auto_clear: bool = True
    ) -> None:
        """Show status message with optional auto-clear.
        
        Args:
            text: Message to display
            fg: Foreground color (None = keep current)
            auto_clear: Whether to auto-clear after delay
        """
        # Cancel existing timer if any
        self.cancel_timer()
        
        # Update label
        self.label.config(text=text)
        if fg is not None:
            self.label.config(fg=fg)
        
        # Schedule auto-clear if enabled
        if auto_clear and self.auto_clear_ms > 0:
            self._timer_id = self.label.after(self.auto_clear_ms, self.clear)
    
    def clear(self) -> None:
        """Clear status message immediately and restore defaults."""
        self.cancel_timer()
        self.label.config(text=self.default_text, fg=self.default_fg)
    
    def cancel_timer(self) -> None:
        """Cancel pending auto-clear timer without clearing message."""
        if self._timer_id is not None:
            try:
                self.label.after_cancel(self._timer_id)
            except Exception:
                pass  # Timer may have already fired
            finally:
                self._timer_id = None
    
    def is_timer_active(self) -> bool:
        """Check if auto-clear timer is currently active."""
        return self._timer_id is not None
    
    def update_delay(self, auto_clear_ms: int) -> None:
        """Update auto-clear delay (does not affect active timer).
        
        Args:
            auto_clear_ms: New delay in milliseconds (0 = disabled)
        """
        self.auto_clear_ms = auto_clear_ms


def create_status_label(
    parent: tk.Widget,
    auto_clear_ms: int = 3000,
    **label_kwargs
) -> tuple[tk.Label, StatusManager]:
    """Create a label with attached StatusManager.
    
    Args:
        parent: Parent widget
        auto_clear_ms: Auto-clear delay in milliseconds
        **label_kwargs: Additional arguments for tk.Label()
    
    Returns:
        Tuple of (label, manager)
    
    Example:
        >>> label, status = create_status_label(frame, text="Ready", fg="gray")
        >>> status.show("Saved!", fg="green")
    """
    label = tk.Label(parent, **label_kwargs)
    manager = StatusManager(
        label,
        auto_clear_ms=auto_clear_ms,
        default_text=label_kwargs.get("text", ""),
        default_fg=label_kwargs.get("fg", "black")
    )
    return label, manager
