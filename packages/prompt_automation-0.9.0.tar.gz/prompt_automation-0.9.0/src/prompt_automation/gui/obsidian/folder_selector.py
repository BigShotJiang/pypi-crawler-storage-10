"""
Folder Selector Dialog for Obsidian Vault.

Provides a tree-view multi-select widget for choosing vault folders for RAG searches.
"""

import tkinter as tk
from tkinter import ttk
from pathlib import Path
from typing import List, Optional, Set


class FolderSelectorDialog(tk.Toplevel):
    """
    Dialog for selecting vault folders with checkbox tree view.
    
    Features:
    - Recursive folder scanning
    - Multi-select with checkboxes
    - Pre-selection from template metadata
    - Search filter
    - Select All/Clear All buttons
    """
    
    def __init__(
        self,
        parent,
        vault_root: Path,
        preselected: Optional[List[str]] = None
    ):
        super().__init__(parent)
        
        self.vault_root = vault_root
        self.selected_folders: Set[str] = set()
        self.folder_tree: List[str] = []
        self.result: Optional[bool] = None
        
        # Configure dialog
        self.title("Select Vault Folders")
        self.geometry("500x600")
        
        # Scan vault folders
        self._scan_folders()
        
        # Build UI
        self._build_ui()
        
        # Pre-select folders if provided
        if preselected:
            for folder in preselected:
                if folder in self.folder_tree:
                    self.selected_folders.add(folder)
                    # Update tree checkboxes
                    if hasattr(self, 'tree_widget'):
                        self._update_tree_checkboxes()
    
    def _scan_folders(self):
        """Recursively scan vault_root for folders."""
        if not self.vault_root.exists():
            self.folder_tree = []
            return
        
        folders = []
        
        def scan_recursive(path: Path, prefix: str = ""):
            """Recursively scan directories."""
            try:
                for item in sorted(path.iterdir()):
                    if item.is_dir() and not item.name.startswith('.'):
                        # Build relative path
                        if prefix:
                            rel_path = f"{prefix}/{item.name}"
                        else:
                            rel_path = item.name
                        
                        folders.append(rel_path)
                        
                        # Recurse into subdirectories
                        scan_recursive(item, rel_path)
            except PermissionError:
                pass  # Skip folders we can't access
        
        scan_recursive(self.vault_root)
        self.folder_tree = folders
    
    def _build_ui(self):
        """Build dialog UI components."""
        # Search filter
        search_frame = ttk.Frame(self)
        search_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ttk.Label(search_frame, text="Search:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.search_var = tk.StringVar()
        self.search_var.trace("w", lambda *args: self._apply_filter(self.search_var.get()))
        
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=30)
        search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # Tree view (simplified - just use Listbox with checkboxes for now)
        tree_frame = ttk.Frame(self)
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.tree_widget = tk.Listbox(
            tree_frame,
            selectmode=tk.MULTIPLE,
            yscrollcommand=scrollbar.set,
            height=20
        )
        self.tree_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.tree_widget.yview)
        
        # Populate tree
        self._populate_tree()
        
        # Bind selection
        self.tree_widget.bind('<<ListboxSelect>>', self._on_tree_select)
        
        # Button frame
        button_frame = ttk.Frame(self)
        button_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        # Select All / Clear All
        ttk.Button(button_frame, text="Select All", command=self._on_select_all).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Clear All", command=self._on_clear_all).pack(side=tk.LEFT)
        
        # OK / Cancel
        ttk.Button(button_frame, text="OK", command=self._on_ok).pack(side=tk.RIGHT, padx=5)
        ttk.Button(button_frame, text="Cancel", command=self._on_cancel).pack(side=tk.RIGHT)
    
    def _populate_tree(self, filtered_folders: Optional[List[str]] = None):
        """Populate tree widget with folders."""
        self.tree_widget.delete(0, tk.END)
        
        folders = filtered_folders if filtered_folders is not None else self.folder_tree
        
        for i, folder in enumerate(folders):
            # Add checkbox indicator
            checked = "☑" if folder in self.selected_folders else "☐"
            display_text = f"{checked} {folder}"
            
            self.tree_widget.insert(tk.END, display_text)
            
            # Pre-select if in selected_folders
            if folder in self.selected_folders:
                self.tree_widget.selection_set(i)
    
    def _on_tree_select(self, event):
        """Handle tree selection change."""
        # Get currently selected indices
        selected_indices = self.tree_widget.curselection()
        
        # Update selected_folders based on current display
        current_folders = self._get_displayed_folders()
        
        # Clear and rebuild selection
        old_selection = self.selected_folders.copy()
        self.selected_folders.clear()
        
        for idx in selected_indices:
            if idx < len(current_folders):
                folder = current_folders[idx]
                self.selected_folders.add(folder)
        
        # If selection changed, update display
        if old_selection != self.selected_folders:
            self._update_tree_checkboxes()
    
    def _get_displayed_folders(self) -> List[str]:
        """Get list of currently displayed folders (accounting for filter)."""
        folders = []
        for i in range(self.tree_widget.size()):
            text = self.tree_widget.get(i)
            # Strip checkbox
            folder = text[2:].strip()  # Remove "☑ " or "☐ "
            folders.append(folder)
        return folders
    
    def _update_tree_checkboxes(self):
        """Update checkbox display in tree widget."""
        for i in range(self.tree_widget.size()):
            text = self.tree_widget.get(i)
            folder = text[2:].strip()
            
            # Update checkbox
            checked = "☑" if folder in self.selected_folders else "☐"
            new_text = f"{checked} {folder}"
            
            self.tree_widget.delete(i)
            self.tree_widget.insert(i, new_text)
            
            # Restore selection
            if folder in self.selected_folders:
                self.tree_widget.selection_set(i)
    
    def _toggle_folder(self, folder: str):
        """Toggle folder selection (for testing)."""
        if folder in self.selected_folders:
            self.selected_folders.remove(folder)
        else:
            self.selected_folders.add(folder)
        
        self._update_tree_checkboxes()
    
    def _apply_filter(self, query: str):
        """Apply search filter to visible folders."""
        if not query:
            # Show all folders
            self._populate_tree()
        else:
            # Filter folders containing query (case-insensitive)
            filtered = [f for f in self.folder_tree if query.lower() in f.lower()]
            self._populate_tree(filtered)
    
    def _get_visible_folders(self) -> List[str]:
        """Get list of currently visible folders."""
        return self._get_displayed_folders()
    
    def _on_select_all(self):
        """Select all visible folders."""
        visible = self._get_visible_folders()
        self.selected_folders.update(visible)
        self._update_tree_checkboxes()
    
    def _on_clear_all(self):
        """Clear all selections."""
        self.selected_folders.clear()
        self._update_tree_checkboxes()
    
    def _on_ok(self):
        """User clicked OK - confirm selection."""
        self.result = True
        self.destroy()
    
    def _on_cancel(self):
        """User clicked Cancel - discard selection."""
        self.result = False
        self.selected_folders.clear()
        self.destroy()
