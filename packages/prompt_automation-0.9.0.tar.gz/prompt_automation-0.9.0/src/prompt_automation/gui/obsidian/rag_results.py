"""
RAG Results Preview Dialog for Obsidian.

Displays search results with snippets, relevance scores, and formatted context output.
"""

import tkinter as tk
from tkinter import ttk, scrolledtext
from typing import List, Dict, Any, Optional
from datetime import datetime


class RAGResultsPreview(tk.Toplevel):
    """
    Dialog for previewing RAG search results before using them.
    
    Features:
    - Scrollable result list with snippets
    - Relevance score color coding (green >80%, yellow >50%, gray <50%)
    - Expand/collapse for full note content
    - Formatted Markdown context output
    - Search Again workflow
    """
    
    def __init__(
        self,
        parent,
        results: List[Dict[str, Any]],
        query: str
    ):
        super().__init__(parent)
        
        self.results = results
        self.query = query
        self.result: Optional[str] = None  # "use" | "search_again" | "cancel"
        self.expanded_result: Optional[int] = None
        self.result_cards: List[Dict[str, Any]] = []
        
        # Configure dialog
        self.title(f"RAG Search Results ({len(results)} matches)")
        self.geometry("700x600")
        
        # Build UI
        self._build_ui()
    
    def _build_ui(self):
        """Build dialog UI components."""
        # Query display
        query_frame = ttk.Frame(self)
        query_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ttk.Label(query_frame, text="Query:", font=("TkDefaultFont", 9, "bold")).pack(side=tk.LEFT)
        ttk.Label(query_frame, text=self.query, font=("TkDefaultFont", 9)).pack(side=tk.LEFT, padx=(5, 0))
        
        # Results container with scrollbar
        results_frame = ttk.Frame(self)
        results_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        canvas = tk.Canvas(results_frame, highlightthickness=0)
        scrollbar = ttk.Scrollbar(results_frame, orient="vertical", command=canvas.yview)
        
        self.results_container = ttk.Frame(canvas)
        
        canvas.create_window((0, 0), window=self.results_container, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Update scroll region when container changes size
        self.results_container.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        
        # Render results
        self._render_results()
        
        # Button frame
        button_frame = ttk.Frame(self)
        button_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        ttk.Button(button_frame, text="Use Results", command=self._on_use).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Search Again", command=self._on_search_again).pack(side=tk.LEFT)
        ttk.Button(button_frame, text="Cancel", command=self._on_cancel).pack(side=tk.RIGHT)
    
    def _render_results(self):
        """Render result cards in scrollable container."""
        self.result_cards = []
        
        for i, result in enumerate(self.results):
            card_frame = self._create_result_card(i, result)
            card_frame.pack(fill=tk.X, pady=5)
            
            # Store reference
            self.result_cards.append({
                "frame": card_frame,
                "text": self._get_card_text(i, result)
            })
    
    def _create_result_card(self, index: int, result: Dict[str, Any]) -> ttk.Frame:
        """Create a single result card."""
        card = ttk.Frame(self.results_container, relief=tk.RIDGE, borderwidth=1)
        card.pack_propagate(False)
        
        # Header with title and relevance
        header_frame = ttk.Frame(card)
        header_frame.pack(fill=tk.X, padx=10, pady=(10, 5))
        
        # Title
        title = self._extract_title(result["path"])
        title_label = ttk.Label(
            header_frame,
            text=f"{index + 1}. {title}",
            font=("TkDefaultFont", 10, "bold")
        )
        title_label.pack(side=tk.LEFT)
        
        # Relevance score with color
        relevance_pct = int(result["relevance"] * 100)
        color = self._get_relevance_color(result["relevance"])
        
        relevance_label = tk.Label(
            header_frame,
            text=f"  {relevance_pct}% ",
            bg=color,
            fg="white" if relevance_pct > 50 else "black",
            font=("TkDefaultFont", 9, "bold")
        )
        relevance_label.pack(side=tk.RIGHT)
        
        # Snippet
        snippet_label = ttk.Label(
            card,
            text=result["snippet"],
            wraplength=650,
            font=("TkDefaultFont", 9)
        )
        snippet_label.pack(fill=tk.X, padx=10, pady=5)
        
        # Metadata
        meta_text = f"Modified: {self._format_relative_time(result['modified'])} • {self._format_size(result['size_bytes'])}"
        meta_label = ttk.Label(
            card,
            text=meta_text,
            foreground="gray",
            font=("TkDefaultFont", 8)
        )
        meta_label.pack(fill=tk.X, padx=10, pady=(0, 5))
        
        # Expand button
        expand_btn = ttk.Button(
            card,
            text="▶ Expand",
            command=lambda idx=index: self._expand_result(idx)
        )
        expand_btn.pack(anchor=tk.W, padx=10, pady=(0, 10))
        
        return card
    
    def _extract_title(self, path: str) -> str:
        """Extract note title from path."""
        # Use filename without extension
        return path.split("/")[-1].replace(".md", "")
    
    def _get_relevance_color(self, relevance: float) -> str:
        """Get color for relevance score."""
        if relevance > 0.8:
            return "#4CAF50"  # Green
        elif relevance > 0.5:
            return "#FFA500"  # Orange/yellow
        else:
            return "#999999"  # Gray
    
    def _format_relative_time(self, iso_timestamp: str) -> str:
        """Format timestamp as relative time."""
        try:
            dt = datetime.fromisoformat(iso_timestamp.replace("Z", "+00:00"))
            now = datetime.now(dt.tzinfo) if dt.tzinfo else datetime.now()
            delta = now - dt
            
            if delta.days == 0:
                return "today"
            elif delta.days == 1:
                return "1 day ago"
            elif delta.days < 7:
                return f"{delta.days} days ago"
            elif delta.days < 30:
                weeks = delta.days // 7
                return f"{weeks} week{'s' if weeks > 1 else ''} ago"
            else:
                months = delta.days // 30
                return f"{months} month{'s' if months > 1 else ''} ago"
        except Exception:
            return "unknown"
    
    def _format_size(self, size_bytes: int) -> str:
        """Format file size as human-readable."""
        if size_bytes < 1024:
            return f"{size_bytes} B"
        elif size_bytes < 1024 * 1024:
            return f"{size_bytes / 1024:.1f} KB"
        else:
            return f"{size_bytes / (1024 * 1024):.1f} MB"
    
    def _get_card_text(self, index: int, result: Dict[str, Any]) -> str:
        """Get text representation of card (for testing)."""
        title = self._extract_title(result["path"])
        relevance_pct = int(result["relevance"] * 100)
        return f"{index + 1}. {title} {relevance_pct}% {result['snippet']} {result['path']}"
    
    def _expand_result(self, index: int):
        """Expand/collapse result to show full content."""
        if self.expanded_result == index:
            # Collapse
            self.expanded_result = None
        else:
            # Expand this, collapse others
            self.expanded_result = index
    
    def get_formatted_context(self) -> str:
        """Return Markdown-formatted context for template injection."""
        lines = [
            "## Context from Obsidian Vault (RAG Search)",
            "",
            f"**Query:** {self.query}",
            "",
        ]
        
        for i, result in enumerate(self.results):
            title = self._extract_title(result["path"])
            relevance_pct = int(result["relevance"] * 100)
            
            lines.append(f"### {i + 1}. {title} (Relevance: {relevance_pct}%)")
            lines.append(f"> {result['snippet']}")
            lines.append(f"> _Modified: {self._format_relative_time(result['modified'])}_")
            lines.append("")
        
        return "\n".join(lines)
    
    def _on_use(self):
        """User clicked Use Results - inject context into template."""
        self.result = "use"
        self.destroy()
    
    def _on_search_again(self):
        """User clicked Search Again - return to query dialog."""
        self.result = "search_again"
        self.destroy()
    
    def _on_cancel(self):
        """User clicked Cancel - discard results."""
        self.result = "cancel"
        self.destroy()
