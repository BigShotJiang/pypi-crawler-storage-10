"""
Query Input Dialog for Obsidian RAG Search.

Provides a multi-line text input dialog for entering search queries.
"""

import tkinter as tk
from tkinter import ttk
from typing import Optional


class QueryInputDialog(tk.Toplevel):
    """
    Dialog for entering RAG search query.
    
    Features:
    - Multi-line text area (5 rows minimum)
    - Live character counter
    - Guidance text for optimal query length
    - Keyboard shortcut (Ctrl+Enter = Search)
    - Pre-fill with initial query
    """
    
    def __init__(
        self,
        parent,
        initial_query: str = ""
    ):
        super().__init__(parent)
        
        self.query_text: str = ""
        self.result: Optional[bool] = None  # True = Search, False = Cancel
        self.char_count: int = 0
        
        # Configure dialog
        self.title("Enter Search Query")
        self.geometry("500x300")
        
        # Build UI
        self._build_ui()
        
        # Pre-fill if provided
        if initial_query:
            self.text_area.insert("1.0", initial_query)
            self._update_char_count()
    
    def _build_ui(self):
        """Build dialog UI components."""
        # Header
        header_frame = ttk.Frame(self)
        header_frame.pack(fill=tk.X, padx=10, pady=(10, 5))
        
        ttk.Label(
            header_frame,
            text="What would you like to search for?",
            font=("TkDefaultFont", 10, "bold")
        ).pack(anchor=tk.W)
        
        # Text area
        text_frame = ttk.Frame(self)
        text_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        scrollbar = ttk.Scrollbar(text_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.text_area = tk.Text(
            text_frame,
            height=8,
            width=60,
            wrap=tk.WORD,
            yscrollcommand=scrollbar.set,
            font=("TkDefaultFont", 10)
        )
        self.text_area.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.text_area.yview)
        
        # Bind text change to update counter
        self.text_area.bind("<KeyRelease>", lambda e: self._update_char_count())
        
        # Character counter
        counter_frame = ttk.Frame(self)
        counter_frame.pack(fill=tk.X, padx=10, pady=5)
        
        self.counter_label = ttk.Label(
            counter_frame,
            text="Characters: 0 / 200 (optimal: 80-200)",
            foreground="gray",
            font=("TkDefaultFont", 9)
        )
        self.counter_label.pack(anchor=tk.W)
        
        # Guidance text
        guidance_frame = ttk.Frame(self)
        guidance_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        ttk.Label(
            guidance_frame,
            text="Tip: Use specific terms for better results",
            foreground="gray",
            font=("TkDefaultFont", 9, "italic")
        ).pack(anchor=tk.W)
        
        # Buttons
        button_frame = ttk.Frame(self)
        button_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        search_btn = ttk.Button(button_frame, text="Search", command=self._on_search)
        search_btn.pack(side=tk.LEFT, padx=5)
        
        ttk.Button(button_frame, text="Cancel", command=self._on_cancel).pack(side=tk.LEFT)
        
        # Keyboard shortcut
        self.bind("<Control-Return>", lambda e: self._on_search())
        self.bind("<Control-KP_Enter>", lambda e: self._on_search())
        
        # Focus text area
        self.text_area.focus_set()
    
    def _update_char_count(self):
        """Update character counter label."""
        text = self.text_area.get("1.0", "end-1c")
        self.char_count = len(text)
        
        # Update label with color coding
        if self.char_count < 80:
            color = "gray"
            status = "(too short)"
        elif self.char_count <= 200:
            color = "green"
            status = "(optimal)"
        else:
            color = "orange"
            status = "(too long)"
        
        self.counter_label.config(
            text=f"Characters: {self.char_count} / 200 {status}",
            foreground=color
        )
    
    def _on_search(self):
        """User clicked Search - capture query."""
        text = self.text_area.get("1.0", "end-1c").strip()
        self.query_text = text
        self.result = True
        self.destroy()
    
    def _on_cancel(self):
        """User clicked Cancel - discard query."""
        self.query_text = ""
        self.result = False
        self.destroy()
