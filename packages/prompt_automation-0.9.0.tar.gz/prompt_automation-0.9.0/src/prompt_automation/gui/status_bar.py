"""Status bar component with system indicators.

Displays system status indicators in the main window bottom bar:
- Cache status (active, hit rate, size)
- Network status (online/offline)
- GPU status (detected, CPU-only)
- Error count (recent errors)

Each indicator is clickable for detailed information and includes tooltips.
"""
from __future__ import annotations

import tkinter as tk
from typing import Optional, Callable, Dict, Any
from pathlib import Path

from ..errorlog import get_logger
from .tooltip import create_tooltip

_log = get_logger(__name__)


class StatusIndicator:
    """Single status indicator with icon, text, and click handler.
    
    Example:
        indicator = StatusIndicator(
            parent=status_bar,
            icon="🟢",
            text="Cache: 85%",
            tooltip="Cache hit rate: 85% (212 hits, 37 misses)",
            on_click=lambda: open_cache_stats()
        )
    """
    
    def __init__(
        self,
        parent: tk.Widget,
        icon: str = "",
        text: str = "",
        tooltip: str = "",
        on_click: Optional[Callable[[], None]] = None,
        fg: str = "black"
    ):
        """Initialize status indicator.
        
        Args:
            parent: Parent widget (status bar frame)
            icon: Emoji or text icon
            text: Status text
            tooltip: Tooltip text (shown on hover)
            on_click: Callback when clicked
            fg: Foreground color
        """
        self.parent = parent
        self.on_click = on_click
        
        # Create frame for indicator
        self.frame = tk.Frame(parent, cursor="hand2" if on_click else "")
        
        # Create label with icon and text
        self.label = tk.Label(
            self.frame,
            text=f"{icon} {text}".strip(),
            fg=fg,
            font=("TkDefaultFont", 9),
            cursor="hand2" if on_click else ""
        )
        self.label.pack(side="left", padx=2)
        
        # Add tooltip if provided
        if tooltip:
            create_tooltip(self.label, tooltip, delay=400)
        
        # Bind click handler
        if on_click:
            self.label.bind("<Button-1>", lambda e: on_click())
            self.frame.bind("<Button-1>", lambda e: on_click())
    
    def update(
        self,
        icon: Optional[str] = None,
        text: Optional[str] = None,
        tooltip: Optional[str] = None,
        fg: Optional[str] = None
    ) -> None:
        """Update indicator display.
        
        Args:
            icon: New icon (None = keep current)
            text: New text (None = keep current)
            tooltip: New tooltip (None = keep current)
            fg: New color (None = keep current)
        """
        # Get current values
        current_text = self.label.cget("text")
        parts = current_text.split(" ", 1)
        current_icon = parts[0] if parts else ""
        current_suffix = parts[1] if len(parts) > 1 else ""
        
        # Update values
        if icon is not None:
            current_icon = icon
        if text is not None:
            current_suffix = text
        
        # Update label
        new_text = f"{current_icon} {current_suffix}".strip()
        self.label.config(text=new_text)
        
        if fg is not None:
            self.label.config(fg=fg)
        
        # Update tooltip (destroy old, create new)
        if tooltip is not None:
            # Note: ToolTip objects are garbage collected when widget is rebound
            create_tooltip(self.label, tooltip, delay=400)
    
    def pack(self, **kwargs) -> None:
        """Pack the indicator frame."""
        self.frame.pack(**kwargs)
    
    def destroy(self) -> None:
        """Destroy the indicator."""
        self.frame.destroy()


class StatusBar:
    """Status bar with system indicators and version info.
    
    Displays indicators for:
    - Cache status (hit rate, size, enabled/disabled)
    - Network status (online, offline, connection quality)
    - GPU status (detected, CPU-only, error)
    - Error count (recent errors, warnings)
    - Application version
    
    Example:
        status_bar = StatusBar(parent=root)
        status_bar.pack(side="bottom", fill="x")
        
        # Update indicators
        status_bar.update_cache_status(enabled=True, hit_rate=85, size_mb=120, max_size_mb=256)
        status_bar.update_network_status(online=True)
        status_bar.update_gpu_status(detected=True, name="NVIDIA RTX 3080")
        status_bar.update_error_count(count=3)
    """
    
    def __init__(self, parent: tk.Widget, version: str = "1.0.0"):
        """Initialize status bar.
        
        Args:
            parent: Parent widget (main window)
            version: Application version string
        """
        self.parent = parent
        self.version = version
        
        # Create status bar frame
        self.frame = tk.Frame(parent, relief=tk.SUNKEN, borderwidth=1)
        
        # Left side: indicators
        self.left_frame = tk.Frame(self.frame)
        self.left_frame.pack(side="left", fill="x", expand=True, padx=4, pady=2)
        
        # Right side: version
        self.right_frame = tk.Frame(self.frame)
        self.right_frame.pack(side="right", padx=4, pady=2)
        
        # Version label
        version_label = tk.Label(
            self.right_frame,
            text=f"v{version}",
            fg="gray",
            font=("TkDefaultFont", 8)
        )
        version_label.pack(side="right")
        
        # Separator before version
        separator = tk.Label(self.right_frame, text="│", fg="lightgray")
        separator.pack(side="right", padx=4)
        
        # Create indicators
        self.indicators: Dict[str, StatusIndicator] = {}
        self._create_indicators()
    
    def _create_indicators(self) -> None:
        """Create status indicators."""
        # Cache indicator
        self.indicators["cache"] = StatusIndicator(
            parent=self.left_frame,
            icon="⚪",  # Default: disabled
            text="Cache: Off",
            tooltip="Cache is disabled. Enable in Settings → Performance.",
            on_click=self._on_cache_click
        )
        self.indicators["cache"].pack(side="left", padx=4)
        
        # Separator
        sep1 = tk.Label(self.left_frame, text="│", fg="lightgray")
        sep1.pack(side="left", padx=2)
        
        # Network indicator
        self.indicators["network"] = StatusIndicator(
            parent=self.left_frame,
            icon="📡",
            text="Online",
            tooltip="Network connected. Cache refreshing every 5 minutes.",
            on_click=None  # No click handler for network (read-only)
        )
        self.indicators["network"].pack(side="left", padx=4)
        
        # Separator
        sep2 = tk.Label(self.left_frame, text="│", fg="lightgray")
        sep2.pack(side="left", padx=2)
        
        # GPU indicator
        self.indicators["gpu"] = StatusIndicator(
            parent=self.left_frame,
            icon="🎯",
            text="GPU: Checking...",
            tooltip="Detecting GPU...",
            on_click=self._on_gpu_click
        )
        self.indicators["gpu"].pack(side="left", padx=4)
        
        # Separator
        sep3 = tk.Label(self.left_frame, text="│", fg="lightgray")
        sep3.pack(side="left", padx=2)
        
        # Error indicator
        self.indicators["errors"] = StatusIndicator(
            parent=self.left_frame,
            icon="⚠️",
            text="0 errors",
            tooltip="No recent errors. Click to view error log.",
            on_click=self._on_errors_click
        )
        self.indicators["errors"].pack(side="left", padx=4)
    
    def update_cache_status(
        self,
        enabled: bool = False,
        hit_rate: Optional[int] = None,
        size_mb: Optional[int] = None,
        max_size_mb: Optional[int] = None
    ) -> None:
        """Update cache status indicator.
        
        Args:
            enabled: Whether cache is enabled
            hit_rate: Cache hit rate percentage (0-100)
            size_mb: Current cache size in MB
            max_size_mb: Maximum cache size in MB
        """
        if not enabled:
            self.indicators["cache"].update(
                icon="⚪",
                text="Cache: Off",
                tooltip="Cache is disabled. Enable in Settings → Performance.",
                fg="gray"
            )
            return
        
        # Build tooltip
        tooltip_parts = []
        if hit_rate is not None:
            tooltip_parts.append(f"Cache hit rate: {hit_rate}%")
        if size_mb is not None and max_size_mb is not None:
            tooltip_parts.append(f"Size: {size_mb} MB / {max_size_mb} MB")
        else:
            tooltip_parts.append("Cache enabled and active")
        tooltip_parts.append("Click for detailed statistics")
        tooltip = "\n".join(tooltip_parts)
        
        # Choose icon based on hit rate
        if hit_rate is None:
            icon = "🟢"  # Enabled but no stats yet
            text = "Cache: On"
        elif hit_rate >= 80:
            icon = "🟢"  # Excellent
            text = f"Cache: {hit_rate}%"
        elif hit_rate >= 60:
            icon = "🟡"  # Good
            text = f"Cache: {hit_rate}%"
        else:
            icon = "🟠"  # Fair
            text = f"Cache: {hit_rate}%"
        
        self.indicators["cache"].update(
            icon=icon,
            text=text,
            tooltip=tooltip,
            fg="black"
        )
    
    def update_network_status(
        self,
        online: bool = True,
        quality: Optional[str] = None
    ) -> None:
        """Update network status indicator.
        
        Args:
            online: Whether network is online
            quality: Connection quality (excellent, good, poor, or None)
        """
        if not online:
            self.indicators["network"].update(
                icon="📴",
                text="Offline",
                tooltip="Network unavailable. Using cached data.",
                fg="orange"
            )
            return
        
        # Build tooltip
        if quality == "excellent":
            tooltip = "Network connected (excellent). Cache refreshing every 5 minutes."
        elif quality == "good":
            tooltip = "Network connected (good). Cache refreshing every 5 minutes."
        elif quality == "poor":
            tooltip = "Network connected (poor). Cache refreshing may be slow."
        else:
            tooltip = "Network connected. Cache refreshing every 5 minutes."
        
        self.indicators["network"].update(
            icon="📡",
            text="Online",
            tooltip=tooltip,
            fg="green" if quality in ("excellent", "good", None) else "orange"
        )
    
    def update_gpu_status(
        self,
        detected: bool = False,
        name: Optional[str] = None,
        error: Optional[str] = None
    ) -> None:
        """Update GPU status indicator.
        
        Args:
            detected: Whether GPU was detected
            name: GPU name (e.g., "NVIDIA RTX 3080")
            error: Error message if GPU detection failed
        """
        if error:
            self.indicators["gpu"].update(
                icon="❌",
                text="GPU: Error",
                tooltip=f"GPU detection failed: {error}\nClick for details.",
                fg="red"
            )
            return
        
        if not detected:
            self.indicators["gpu"].update(
                icon="💻",
                text="CPU-only",
                tooltip="No GPU detected. Using CPU for processing.\nClick for details.",
                fg="gray"
            )
            return
        
        # GPU detected
        tooltip = f"GPU detected: {name or 'Unknown'}\nUsing GPU acceleration.\nClick for details."
        self.indicators["gpu"].update(
            icon="🎯",
            text="GPU: Ready",
            tooltip=tooltip,
            fg="green"
        )
    
    def update_error_count(self, count: int = 0) -> None:
        """Update error count indicator.
        
        Args:
            count: Number of recent errors
        """
        if count == 0:
            self.indicators["errors"].update(
                icon="✓",
                text="0 errors",
                tooltip="No recent errors. Click to view error log.",
                fg="green"
            )
        elif count <= 5:
            self.indicators["errors"].update(
                icon="⚠️",
                text=f"{count} error{'s' if count > 1 else ''}",
                tooltip=f"{count} recent error{'s' if count > 1 else ''}. Click to view details.",
                fg="orange"
            )
        else:
            self.indicators["errors"].update(
                icon="❌",
                text=f"{count} errors",
                tooltip=f"{count} recent errors. Click to view error log.",
                fg="red"
            )
    
    def _on_cache_click(self) -> None:
        """Handle cache indicator click."""
        _log.info("Cache indicator clicked")
        try:
            # Import here to avoid circular dependency
            from .cache_stats_dialog import CacheStatsDialog
            from ..cache.config_integration import create_cache_from_config
            from ..settings import ConfigManager
            
            # Create cache from current config
            config_mgr = ConfigManager()
            cache_mgr = create_cache_from_config(config_mgr.config)
            
            if cache_mgr is None:
                from tkinter import messagebox
                messagebox.showinfo(
                    "Cache Not Available",
                    "Cache is not enabled.\n\nTo enable cache, go to Settings → Performance → Enable cache"
                )
                return
            
            CacheStatsDialog(self.parent, cache_mgr)
        except Exception as e:
            _log.error("Failed to open cache stats: %s", e, exc_info=True)
            from tkinter import messagebox
            messagebox.showerror("Error", f"Failed to open cache statistics:\n\n{e}")
    
    def _on_gpu_click(self) -> None:
        """Handle GPU indicator click."""
        _log.info("GPU indicator clicked")
        try:
            from tkinter import messagebox
            
            # Try to get GPU info
            try:
                from ..performance.device_manager import DeviceManager
                device_mgr = DeviceManager()
                gpu_info = device_mgr.get_gpu_info()
                
                if gpu_info:
                    msg = f"GPU Detected:\n\n"
                    msg += f"Name: {gpu_info.get('name', 'Unknown')}\n"
                    msg += f"Memory: {gpu_info.get('memory_mb', 0)} MB\n"
                    msg += f"Driver: {gpu_info.get('driver_version', 'Unknown')}\n"
                else:
                    msg = "No GPU detected.\n\nApplication is using CPU for all operations."
            except ImportError:
                msg = "GPU information unavailable.\n\nDevice Manager module not loaded."
            except Exception as e:
                msg = f"Failed to retrieve GPU information:\n\n{e}"
            
            messagebox.showinfo("GPU Status", msg)
        except Exception as e:
            _log.error("Failed to show GPU info: %s", e, exc_info=True)
    
    def _on_errors_click(self) -> None:
        """Handle errors indicator click."""
        _log.info("Errors indicator clicked")
        try:
            from tkinter import messagebox
            import subprocess
            import platform
            
            # Get error log path
            from ..platform_utils import get_app_home
            log_path = get_app_home() / "logs" / "error.log"
            
            if not log_path.exists():
                messagebox.showinfo("No Errors", "No error log file found.\n\nApplication is running without errors.")
                return
            
            # Open error log in default text editor
            if platform.system() == "Windows":
                subprocess.run(["notepad", str(log_path)])
            elif platform.system() == "Darwin":
                subprocess.run(["open", str(log_path)])
            else:
                subprocess.run(["xdg-open", str(log_path)])
        except Exception as e:
            _log.error("Failed to open error log: %s", e, exc_info=True)
            from tkinter import messagebox
            messagebox.showerror("Error", f"Failed to open error log:\n\n{e}")
    
    def pack(self, **kwargs) -> None:
        """Pack the status bar frame."""
        self.frame.pack(**kwargs)
    
    def destroy(self) -> None:
        """Destroy the status bar."""
        self.frame.destroy()


__all__ = ["StatusBar", "StatusIndicator"]
