"""Toast notification system for temporary messages.

Provides non-intrusive, auto-dismissing notifications for:
- Success confirmations (cache enabled, profile switched)
- Warnings (network offline, cache full)
- Info messages (first cache hit, feature tips)

Toasts appear in the bottom-right corner and auto-dismiss after 3 seconds.
Multiple toasts stack vertically.

Example:
    toast_manager = ToastManager(parent=root)
    toast_manager.show_success("Cache enabled successfully!")
    toast_manager.show_warning("Network unavailable, using cache")
    toast_manager.show_info("Tip: Enable GPU for faster processing")
"""
from __future__ import annotations

import tkinter as tk
from typing import Optional, Literal
from ..errorlog import get_logger

_log = get_logger(__name__)

ToastType = Literal["success", "warning", "info", "error"]


class Toast:
    """Single toast notification.
    
    Auto-dismissing notification that slides in from the bottom-right.
    """
    
    def __init__(
        self,
        parent: tk.Widget,
        message: str,
        toast_type: ToastType = "info",
        duration_ms: int = 3000,
        on_dismiss: Optional[callable] = None
    ):
        """Initialize toast.
        
        Args:
            parent: Parent widget (main window)
            message: Message to display
            toast_type: Toast type (success, warning, info, error)
            duration_ms: Duration in milliseconds before auto-dismiss
            on_dismiss: Callback when toast is dismissed
        """
        self.parent = parent
        self.message = message
        self.toast_type = toast_type
        self.duration_ms = duration_ms
        self.on_dismiss = on_dismiss
        self.window: Optional[tk.Toplevel] = None
        self.dismiss_timer: Optional[str] = None
        
        # Type-specific styling
        self.styles = {
            "success": {"bg": "#28a745", "fg": "white", "icon": "✓"},
            "warning": {"bg": "#ffc107", "fg": "black", "icon": "⚠"},
            "info": {"bg": "#17a2b8", "fg": "white", "icon": "ℹ"},
            "error": {"bg": "#dc3545", "fg": "white", "icon": "✗"}
        }
    
    def show(self, x: int, y: int) -> None:
        """Show toast at specified position.
        
        Args:
            x: X coordinate (pixels from left)
            y: Y coordinate (pixels from top)
        """
        if self.window is not None:
            return  # Already showing
        
        # Get style for toast type
        style = self.styles.get(self.toast_type, self.styles["info"])
        
        # Create toplevel window
        self.window = tk.Toplevel(self.parent)
        self.window.wm_overrideredirect(True)  # No window decorations
        self.window.wm_geometry(f"+{x}+{y}")
        self.window.attributes("-topmost", True)  # Always on top
        
        # Create frame with padding and border
        frame = tk.Frame(
            self.window,
            bg=style["bg"],
            padx=12,
            pady=8,
            relief=tk.RAISED,
            borderwidth=2
        )
        frame.pack(fill="both", expand=True)
        
        # Icon and message
        message_text = f"{style['icon']}  {self.message}"
        label = tk.Label(
            frame,
            text=message_text,
            bg=style["bg"],
            fg=style["fg"],
            font=("TkDefaultFont", 10),
            justify=tk.LEFT,
            wraplength=300  # Max width
        )
        label.pack()
        
        # Close button (X)
        close_btn = tk.Label(
            frame,
            text="✕",
            bg=style["bg"],
            fg=style["fg"],
            font=("TkDefaultFont", 12, "bold"),
            cursor="hand2"
        )
        close_btn.place(relx=1.0, rely=0, anchor="ne")
        close_btn.bind("<Button-1>", lambda e: self.dismiss())
        
        # Make entire toast clickable to dismiss
        label.bind("<Button-1>", lambda e: self.dismiss())
        frame.bind("<Button-1>", lambda e: self.dismiss())
        
        # Schedule auto-dismiss
        if self.duration_ms > 0:
            self.dismiss_timer = self.window.after(self.duration_ms, self.dismiss)
        
        _log.debug(f"Toast shown: {self.toast_type} - {self.message}")
    
    def dismiss(self) -> None:
        """Dismiss toast immediately."""
        if self.window is None:
            return
        
        # Cancel auto-dismiss timer
        if self.dismiss_timer is not None:
            try:
                self.window.after_cancel(self.dismiss_timer)
            except Exception:
                pass
            self.dismiss_timer = None
        
        # Destroy window
        try:
            self.window.destroy()
        except Exception:
            pass
        self.window = None
        
        # Call dismiss callback
        if self.on_dismiss:
            try:
                self.on_dismiss()
            except Exception as e:
                _log.error(f"Toast dismiss callback failed: {e}")
        
        _log.debug(f"Toast dismissed: {self.toast_type} - {self.message}")


class ToastManager:
    """Manages multiple toast notifications.
    
    Handles stacking, positioning, and lifecycle of toasts.
    Toasts appear in the bottom-right corner and stack vertically.
    """
    
    def __init__(
        self,
        parent: tk.Widget,
        margin_x: int = 20,
        margin_y: int = 20,
        spacing: int = 10
    ):
        """Initialize toast manager.
        
        Args:
            parent: Parent widget (main window)
            margin_x: Margin from right edge (pixels)
            margin_y: Margin from bottom edge (pixels)
            spacing: Vertical spacing between toasts (pixels)
        """
        self.parent = parent
        self.margin_x = margin_x
        self.margin_y = margin_y
        self.spacing = spacing
        self.toasts: list[Toast] = []
    
    def show(
        self,
        message: str,
        toast_type: ToastType = "info",
        duration_ms: int = 3000
    ) -> Toast:
        """Show a toast notification.
        
        Args:
            message: Message to display
            toast_type: Toast type (success, warning, info, error)
            duration_ms: Duration in milliseconds before auto-dismiss
        
        Returns:
            Toast instance
        """
        # Create toast
        toast = Toast(
            parent=self.parent,
            message=message,
            toast_type=toast_type,
            duration_ms=duration_ms,
            on_dismiss=lambda: self._on_toast_dismissed(toast)
        )
        
        # Calculate position
        x, y = self._calculate_position()
        
        # Show toast
        toast.show(x, y)
        
        # Add to active toasts
        self.toasts.append(toast)
        
        return toast
    
    def show_success(self, message: str, duration_ms: int = 3000) -> Toast:
        """Show success toast.
        
        Args:
            message: Success message
            duration_ms: Duration in milliseconds
        
        Returns:
            Toast instance
        """
        return self.show(message, toast_type="success", duration_ms=duration_ms)
    
    def show_warning(self, message: str, duration_ms: int = 4000) -> Toast:
        """Show warning toast (longer duration).
        
        Args:
            message: Warning message
            duration_ms: Duration in milliseconds
        
        Returns:
            Toast instance
        """
        return self.show(message, toast_type="warning", duration_ms=duration_ms)
    
    def show_info(self, message: str, duration_ms: int = 3000) -> Toast:
        """Show info toast.
        
        Args:
            message: Info message
            duration_ms: Duration in milliseconds
        
        Returns:
            Toast instance
        """
        return self.show(message, toast_type="info", duration_ms=duration_ms)
    
    def show_error(self, message: str, duration_ms: int = 5000) -> Toast:
        """Show error toast (longest duration).
        
        Args:
            message: Error message
            duration_ms: Duration in milliseconds
        
        Returns:
            Toast instance
        """
        return self.show(message, toast_type="error", duration_ms=duration_ms)
    
    def dismiss_all(self) -> None:
        """Dismiss all active toasts."""
        for toast in self.toasts[:]:  # Copy list to avoid modification during iteration
            toast.dismiss()
        self.toasts.clear()
    
    def _calculate_position(self) -> tuple[int, int]:
        """Calculate position for next toast.
        
        Returns:
            (x, y) tuple in screen coordinates
        """
        # Get parent window geometry
        try:
            parent_width = self.parent.winfo_width()
            parent_height = self.parent.winfo_height()
            parent_x = self.parent.winfo_rootx()
            parent_y = self.parent.winfo_rooty()
        except Exception:
            # Fallback if parent not fully initialized
            parent_width = 800
            parent_height = 600
            parent_x = 100
            parent_y = 100
        
        # Calculate bottom-right position
        # Note: Toast width is ~320px (300 wraplength + padding)
        toast_width = 320
        toast_height = 60  # Approximate height
        
        x = parent_x + parent_width - toast_width - self.margin_x
        
        # Stack vertically from bottom
        y_offset = self.margin_y
        for existing_toast in self.toasts:
            y_offset += toast_height + self.spacing
        
        y = parent_y + parent_height - toast_height - y_offset
        
        return (x, y)
    
    def _on_toast_dismissed(self, toast: Toast) -> None:
        """Handle toast dismissal.
        
        Args:
            toast: Dismissed toast
        """
        if toast in self.toasts:
            self.toasts.remove(toast)
        
        # Reposition remaining toasts (optional - they'll naturally stack correctly on next show)


# Singleton instance for convenience
_toast_manager: Optional[ToastManager] = None


def get_toast_manager(parent: tk.Widget) -> ToastManager:
    """Get or create global toast manager.
    
    Args:
        parent: Parent widget (main window)
    
    Returns:
        ToastManager instance
    """
    global _toast_manager
    if _toast_manager is None:
        _toast_manager = ToastManager(parent)
    return _toast_manager


def show_toast(
    parent: tk.Widget,
    message: str,
    toast_type: ToastType = "info",
    duration_ms: int = 3000
) -> Toast:
    """Convenience function to show a toast.
    
    Args:
        parent: Parent widget
        message: Message to display
        toast_type: Toast type (success, warning, info, error)
        duration_ms: Duration in milliseconds
    
    Returns:
        Toast instance
    """
    manager = get_toast_manager(parent)
    return manager.show(message, toast_type, duration_ms)


__all__ = ["Toast", "ToastManager", "get_toast_manager", "show_toast", "ToastType"]
