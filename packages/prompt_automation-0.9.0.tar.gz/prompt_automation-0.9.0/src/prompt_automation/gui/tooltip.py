"""Simple tooltip utility for Tkinter widgets."""
import tkinter as tk
from typing import Optional


class ToolTip:
    """
    Create a tooltip for a given widget.
    
    Example:
        button = tk.Button(root, text="Hover me")
        ToolTip(button, "This is a helpful tooltip!")
    """
    
    def __init__(self, widget: tk.Widget, text: str, delay: int = 500):
        """
        Initialize tooltip.
        
        Args:
            widget: Widget to attach tooltip to
            text: Tooltip text to display
            delay: Delay in milliseconds before showing tooltip
        """
        self.widget = widget
        self.text = text
        self.delay = delay
        self.tip_window: Optional[tk.Toplevel] = None
        self.after_id: Optional[str] = None
        
        # Bind events
        self.widget.bind("<Enter>", self._on_enter)
        self.widget.bind("<Leave>", self._on_leave)
        self.widget.bind("<Button>", self._on_leave)  # Hide on click
    
    def _on_enter(self, event=None):
        """Handle mouse enter event."""
        self._schedule_show()
    
    def _on_leave(self, event=None):
        """Handle mouse leave event."""
        self._unschedule_show()
        self._hide_tip()
    
    def _schedule_show(self):
        """Schedule tooltip to show after delay."""
        self._unschedule_show()
        self.after_id = self.widget.after(self.delay, self._show_tip)
    
    def _unschedule_show(self):
        """Cancel scheduled tooltip show."""
        if self.after_id:
            self.widget.after_cancel(self.after_id)
            self.after_id = None
    
    def _show_tip(self):
        """Display the tooltip."""
        if self.tip_window:
            return
        
        # Calculate position (below and slightly right of widget)
        x = self.widget.winfo_rootx() + 20
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 5
        
        # Create tooltip window
        self.tip_window = tk.Toplevel(self.widget)
        self.tip_window.wm_overrideredirect(True)  # No window decorations
        self.tip_window.wm_geometry(f"+{x}+{y}")
        
        # Style the tooltip
        label = tk.Label(
            self.tip_window,
            text=self.text,
            justify=tk.LEFT,
            background="#ffffe0",  # Light yellow
            foreground="black",
            relief=tk.SOLID,
            borderwidth=1,
            padx=8,
            pady=4,
            font=("TkDefaultFont", 9)
        )
        label.pack()
    
    def _hide_tip(self):
        """Hide the tooltip."""
        if self.tip_window:
            self.tip_window.destroy()
            self.tip_window = None


def create_tooltip(widget: tk.Widget, text: str, delay: int = 500) -> ToolTip:
    """
    Convenience function to create a tooltip.
    
    Args:
        widget: Widget to attach tooltip to
        text: Tooltip text
        delay: Delay in milliseconds before showing
    
    Returns:
        ToolTip instance
    
    Example:
        label = tk.Label(root, text="Hover me")
        create_tooltip(label, "Helpful information here")
    """
    return ToolTip(widget, text, delay)
