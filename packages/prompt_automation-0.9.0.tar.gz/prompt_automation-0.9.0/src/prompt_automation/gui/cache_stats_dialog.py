"""Cache Statistics Dashboard GUI dialog."""

import tkinter as tk
from tkinter import ttk, messagebox
from typing import Optional, Any


class CacheStatsDialog(tk.Toplevel):
    """Display real-time cache performance statistics."""
    
    def __init__(self, parent, cache_manager, messagebox_impl=None):
        """Initialize cache stats dialog.
        
        Args:
            parent: Parent tkinter window
            cache_manager: CacheManager instance to monitor
            messagebox_impl: Optional messagebox implementation for testing
        """
        super().__init__(parent)
        
        self.cache_manager = cache_manager
        self.messagebox = messagebox_impl or messagebox
        
        self.title("Cache Performance Dashboard")
        self.geometry("600x700")
        self.resizable(False, False)
        
        # Polling state
        self._update_job = None
        self._update_interval_ms = 1000  # 1 second
        
        self._create_widgets()
        self._start_updates()
        
        # Center on parent
        self.transient(parent)
        self.grab_set()
    
    def _create_widgets(self):
        """Create all GUI widgets."""
        # Main container with padding
        main_frame = ttk.Frame(self, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_label = ttk.Label(
            main_frame, 
            text="Cache Performance Dashboard",
            font=("TkDefaultFont", 12, "bold")
        )
        title_label.pack(pady=(0, 10))
        
        # Create sections
        self._create_hit_rate_section(main_frame)
        self._create_usage_section(main_frame)
        self._create_performance_section(main_frame)
        self._create_cost_section(main_frame)
        
        # Action buttons at bottom
        self._create_action_buttons(main_frame)
    
    def _create_hit_rate_section(self, parent):
        """Create hit rate statistics section."""
        frame = ttk.LabelFrame(parent, text="Hit Rates", padding="10")
        frame.pack(fill=tk.X, pady=5)
        
        # Overall hit rate
        overall_frame = ttk.Frame(frame)
        overall_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(overall_frame, text="Overall Hit Rate:", width=20).pack(side=tk.LEFT)
        self.overall_rate_label = ttk.Label(overall_frame, text="0%", font=("TkDefaultFont", 10, "bold"))
        self.overall_rate_label.pack(side=tk.LEFT, padx=5)
        self.overall_progress = ttk.Progressbar(overall_frame, length=200, mode='determinate')
        self.overall_progress.pack(side=tk.LEFT, padx=5)
        
        # L1 hits
        l1_frame = ttk.Frame(frame)
        l1_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(l1_frame, text="  L1 Hits:", width=20).pack(side=tk.LEFT)
        self.l1_hits_label = ttk.Label(l1_frame, text="0 (0%)")
        self.l1_hits_label.pack(side=tk.LEFT, padx=5)
        self.l1_progress = ttk.Progressbar(l1_frame, length=200, mode='determinate')
        self.l1_progress.pack(side=tk.LEFT, padx=5)
        
        # L2 hits
        l2_frame = ttk.Frame(frame)
        l2_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(l2_frame, text="  L2 Hits:", width=20).pack(side=tk.LEFT)
        self.l2_hits_label = ttk.Label(l2_frame, text="0 (0%)")
        self.l2_hits_label.pack(side=tk.LEFT, padx=5)
        self.l2_progress = ttk.Progressbar(l2_frame, length=200, mode='determinate')
        self.l2_progress.pack(side=tk.LEFT, padx=5)
        
        # L3 hits
        l3_frame = ttk.Frame(frame)
        l3_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(l3_frame, text="  L3 Hits:", width=20).pack(side=tk.LEFT)
        self.l3_hits_label = ttk.Label(l3_frame, text="0 (0%)")
        self.l3_hits_label.pack(side=tk.LEFT, padx=5)
        self.l3_progress = ttk.Progressbar(l3_frame, length=200, mode='determinate')
        self.l3_progress.pack(side=tk.LEFT, padx=5)
        
        # Misses
        miss_frame = ttk.Frame(frame)
        miss_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(miss_frame, text="  Misses:", width=20).pack(side=tk.LEFT)
        self.miss_label = ttk.Label(miss_frame, text="0 (0%)")
        self.miss_label.pack(side=tk.LEFT, padx=5)
        self.miss_progress = ttk.Progressbar(miss_frame, length=200, mode='determinate')
        self.miss_progress.pack(side=tk.LEFT, padx=5)
    
    def _create_usage_section(self, parent):
        """Create cache usage section."""
        frame = ttk.LabelFrame(parent, text="Cache Usage", padding="10")
        frame.pack(fill=tk.X, pady=5)
        
        # L1 usage
        l1_frame = ttk.Frame(frame)
        l1_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(l1_frame, text="L1 (Memory):", width=20).pack(side=tk.LEFT)
        self.l1_usage_label = ttk.Label(l1_frame, text="0 MB / 0 MB (0%)")
        self.l1_usage_label.pack(side=tk.LEFT, padx=5)
        self.l1_usage_progress = ttk.Progressbar(l1_frame, length=200, mode='determinate')
        self.l1_usage_progress.pack(side=tk.LEFT, padx=5)
        
        # L2 usage
        l2_frame = ttk.Frame(frame)
        l2_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(l2_frame, text="L2 (Disk):", width=20).pack(side=tk.LEFT)
        self.l2_usage_label = ttk.Label(l2_frame, text="0 MB / 0 MB (0%)")
        self.l2_usage_label.pack(side=tk.LEFT, padx=5)
        self.l2_usage_progress = ttk.Progressbar(l2_frame, length=200, mode='determinate')
        self.l2_usage_progress.pack(side=tk.LEFT, padx=5)
    
    def _create_performance_section(self, parent):
        """Create performance metrics section."""
        frame = ttk.LabelFrame(parent, text="Performance", padding="10")
        frame.pack(fill=tk.X, pady=5)
        
        # Evictions
        evict_frame = ttk.Frame(frame)
        evict_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(evict_frame, text="Evictions (L1):", width=20).pack(side=tk.LEFT)
        self.l1_evict_label = ttk.Label(evict_frame, text="0")
        self.l1_evict_label.pack(side=tk.LEFT, padx=5)
        
        ttk.Label(evict_frame, text="Evictions (L2):", width=20).pack(side=tk.LEFT)
        self.l2_evict_label = ttk.Label(evict_frame, text="0")
        self.l2_evict_label.pack(side=tk.LEFT, padx=5)
        
        # Total operations
        ops_frame = ttk.Frame(frame)
        ops_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(ops_frame, text="Total Operations:", width=20).pack(side=tk.LEFT)
        self.total_ops_label = ttk.Label(ops_frame, text="0")
        self.total_ops_label.pack(side=tk.LEFT, padx=5)
    
    def _create_cost_section(self, parent):
        """Create cost savings section."""
        frame = ttk.LabelFrame(parent, text="Cost Savings", padding="10")
        frame.pack(fill=tk.X, pady=5)
        
        # LLM calls avoided
        calls_frame = ttk.Frame(frame)
        calls_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(calls_frame, text="LLM calls avoided:", width=20).pack(side=tk.LEFT)
        self.calls_avoided_label = ttk.Label(calls_frame, text="0")
        self.calls_avoided_label.pack(side=tk.LEFT, padx=5)
        
        # Estimated savings
        savings_frame = ttk.Frame(frame)
        savings_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(savings_frame, text="Estimated savings:", width=20).pack(side=tk.LEFT)
        self.savings_label = ttk.Label(savings_frame, text="$0.00", font=("TkDefaultFont", 10, "bold"))
        self.savings_label.pack(side=tk.LEFT, padx=5)
        
        # Note
        note_label = ttk.Label(
            frame,
            text="(Based on $0.05 per LLM call)",
            font=("TkDefaultFont", 8),
            foreground="gray"
        )
        note_label.pack(pady=(5, 0))
    
    def _create_action_buttons(self, parent):
        """Create action buttons."""
        button_frame = ttk.Frame(parent)
        button_frame.pack(fill=tk.X, pady=10)
        
        # Clear L1 button
        ttk.Button(
            button_frame,
            text="Clear L1 Cache",
            command=self._clear_l1
        ).pack(side=tk.LEFT, padx=5)
        
        # Clear L2 button
        ttk.Button(
            button_frame,
            text="Clear L2 Cache",
            command=self._clear_l2
        ).pack(side=tk.LEFT, padx=5)
        
        # Reset stats button
        ttk.Button(
            button_frame,
            text="Reset Stats",
            command=self._reset_stats
        ).pack(side=tk.LEFT, padx=5)
        
        # Close button
        ttk.Button(
            button_frame,
            text="Close",
            command=self.destroy
        ).pack(side=tk.RIGHT, padx=5)
    
    def _start_updates(self):
        """Start periodic stats updates."""
        self._update_stats()
    
    def _update_stats(self):
        """Update all statistics from cache manager."""
        try:
            stats = self.cache_manager.get_stats()
            
            # Update hit rates
            overall_rate = stats['overall_hit_rate'] * 100
            self.overall_rate_label.config(text=f"{overall_rate:.1f}%")
            self.overall_progress['value'] = overall_rate
            
            l1_rate = stats['l1_hit_rate'] * 100
            self.l1_hits_label.config(text=f"{stats['l1_hits']} ({l1_rate:.1f}%)")
            self.l1_progress['value'] = l1_rate
            
            l2_rate = stats['l2_hit_rate'] * 100
            self.l2_hits_label.config(text=f"{stats['l2_hits']} ({l2_rate:.1f}%)")
            self.l2_progress['value'] = l2_rate
            
            l3_rate = stats['l3_hit_rate'] * 100
            self.l3_hits_label.config(text=f"{stats['l3_hits']} ({l3_rate:.1f}%)")
            self.l3_progress['value'] = l3_rate
            
            miss_rate = stats['miss_rate'] * 100
            self.miss_label.config(text=f"{stats['misses']} ({miss_rate:.1f}%)")
            self.miss_progress['value'] = miss_rate
            
            # Update usage
            l1_usage_pct = stats['l1_usage_percent']
            self.l1_usage_label.config(
                text=f"{stats['l1_size_mb']:.1f} MB / {stats['l1_max_mb']:.0f} MB ({l1_usage_pct:.0f}%)"
            )
            self.l1_usage_progress['value'] = l1_usage_pct
            
            l2_usage_pct = stats['l2_usage_percent']
            self.l2_usage_label.config(
                text=f"{stats['l2_size_mb']:.1f} MB / {stats['l2_max_mb']:.0f} MB ({l2_usage_pct:.0f}%)"
            )
            self.l2_usage_progress['value'] = l2_usage_pct
            
            # Update performance
            self.l1_evict_label.config(text=str(stats['l1_evictions']))
            self.l2_evict_label.config(text=str(stats['l2_evictions']))
            self.total_ops_label.config(text=str(stats['total_operations']))
            
            # Update cost savings
            self.calls_avoided_label.config(text=str(stats['llm_calls_avoided']))
            self.savings_label.config(text=f"${stats['estimated_savings_usd']:.2f}")
            
        except Exception as e:
            # Silently fail - don't interrupt user
            pass
        
        # Schedule next update
        self._update_job = self.after(self._update_interval_ms, self._update_stats)
    
    def _clear_l1(self):
        """Clear L1 cache."""
        if self.messagebox.askyesno("Confirm", "Clear L1 (memory) cache?"):
            try:
                self.cache_manager.l1.clear()
                self.messagebox.showinfo("Success", "L1 cache cleared")
            except Exception as e:
                self.messagebox.showerror("Error", f"Failed to clear L1: {e}")
    
    def _clear_l2(self):
        """Clear L2 cache."""
        if self.messagebox.askyesno("Confirm", "Clear L2 (disk) cache?"):
            try:
                self.cache_manager.l2.clear()
                self.messagebox.showinfo("Success", "L2 cache cleared")
            except Exception as e:
                self.messagebox.showerror("Error", f"Failed to clear L2: {e}")
    
    def _reset_stats(self):
        """Reset statistics counters."""
        if self.messagebox.askyesno("Confirm", "Reset all statistics counters?"):
            try:
                self.cache_manager.stats.reset()
                self.messagebox.showinfo("Success", "Statistics reset")
            except Exception as e:
                self.messagebox.showerror("Error", f"Failed to reset stats: {e}")
    
    def destroy(self):
        """Cancel updates and destroy dialog."""
        if self._update_job:
            self.after_cancel(self._update_job)
        super().destroy()
