"""
Confirmation dialog widgets for safe file operations.

Provides user-facing confirmation dialogs with diff previews and
safety features before performing destructive operations.
"""

import difflib
import tkinter as tk
from tkinter import scrolledtext, ttk
from typing import Optional
import logging

logger = logging.getLogger(__name__)


class DiffPreviewWidget(tk.Frame):
    """
    Side-by-side diff preview with color-coded changes.
    
    Shows current and new content in scrollable panes with
    additions highlighted in green and deletions in red.
    """
    
    def __init__(self, parent, current: str, new: str):
        """
        Initialize diff preview widget.
        
        Args:
            parent: Parent tkinter widget
            current: Current file content
            new: New file content
        """
        super().__init__(parent)
        
        # Configure grid layout
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=0)
        self.grid_rowconfigure(1, weight=1)
        
        # Headers
        tk.Label(self, text="Current Content", font=("TkDefaultFont", 10, "bold")).grid(
            row=0, column=0, sticky="w", padx=5, pady=5
        )
        tk.Label(self, text="New Content", font=("TkDefaultFont", 10, "bold")).grid(
            row=0, column=1, sticky="w", padx=5, pady=5
        )
        
        # Create side-by-side panes
        self.current_pane = scrolledtext.ScrolledText(
            self, width=40, height=20, wrap=tk.WORD
        )
        self.current_pane.grid(row=1, column=0, sticky="nsew", padx=(5, 2), pady=5)
        
        self.new_pane = scrolledtext.ScrolledText(
            self, width=40, height=20, wrap=tk.WORD
        )
        self.new_pane.grid(row=1, column=1, sticky="nsew", padx=(2, 5), pady=5)
        
        # Configure color tags
        self.current_pane.tag_config("deletion", background="#ffcccc", foreground="#8b0000")
        self.new_pane.tag_config("addition", background="#ccffcc", foreground="#006400")
        self.current_pane.tag_config("normal", background="white")
        self.new_pane.tag_config("normal", background="white")
        
        # Render diff
        self._render_diff(current, new)
        
        # Make read-only
        self.current_pane.config(state="disabled")
        self.new_pane.config(state="disabled")
    
    def _render_diff(self, current: str, new: str):
        """
        Render diff with color coding.
        
        Uses difflib.SequenceMatcher to find changes and highlights
        added/removed lines.
        """
        current_lines = current.split('\n')
        new_lines = new.split('\n')
        
        # Use difflib to find differences
        differ = difflib.SequenceMatcher(None, current_lines, new_lines)
        
        for tag, i1, i2, j1, j2 in differ.get_opcodes():
            if tag == 'equal':
                # Lines are the same
                for line in current_lines[i1:i2]:
                    self.current_pane.insert("end", line + "\n", "normal")
                for line in new_lines[j1:j2]:
                    self.new_pane.insert("end", line + "\n", "normal")
            
            elif tag == 'delete':
                # Lines deleted from current
                for line in current_lines[i1:i2]:
                    self.current_pane.insert("end", line + "\n", "deletion")
            
            elif tag == 'insert':
                # Lines added to new
                for line in new_lines[j1:j2]:
                    self.new_pane.insert("end", line + "\n", "addition")
            
            elif tag == 'replace':
                # Lines changed
                for line in current_lines[i1:i2]:
                    self.current_pane.insert("end", line + "\n", "deletion")
                for line in new_lines[j1:j2]:
                    self.new_pane.insert("end", line + "\n", "addition")


class FileWriteConfirmDialog(tk.Toplevel):
    """
    Confirmation dialog for file write operations.
    
    Shows diff preview and allows user to confirm or cancel the write,
    with optional backup creation.
    """
    
    def __init__(self, parent, file_path: str, current: str, new: str):
        """
        Initialize file write confirmation dialog.
        
        Args:
            parent: Parent tkinter widget
            file_path: Path to file being written
            current: Current file content
            new: New file content
        """
        super().__init__(parent)
        self.title(f"Confirm Overwrite: {file_path}")
        self.result = None
        self.create_backup = True
        
        # Configure window
        self.geometry("900x600")
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=0)
        self.grid_rowconfigure(1, weight=1)
        self.grid_rowconfigure(2, weight=0)
        
        # Info label
        info_text = f"You are about to overwrite: {file_path}\nReview the changes below."
        tk.Label(self, text=info_text, font=("TkDefaultFont", 10)).grid(
            row=0, column=0, sticky="w", padx=10, pady=10
        )
        
        # Diff preview
        self.diff_widget = DiffPreviewWidget(self, current, new)
        self.diff_widget.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)
        
        # Options frame
        options_frame = tk.Frame(self)
        options_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=5)
        options_frame.grid_columnconfigure(0, weight=1)
        
        # Backup checkbox
        self.backup_var = tk.BooleanVar(value=True)
        tk.Checkbutton(
            options_frame,
            text="Create backup (.bak) before overwriting",
            variable=self.backup_var
        ).grid(row=0, column=0, sticky="w", pady=5)
        
        # Buttons
        button_frame = tk.Frame(options_frame)
        button_frame.grid(row=1, column=0, sticky="e", pady=5)
        
        tk.Button(
            button_frame,
            text="Cancel",
            command=self._on_cancel,
            width=10
        ).pack(side="left", padx=5)
        
        tk.Button(
            button_frame,
            text="Confirm",
            command=self._on_confirm,
            width=10,
            bg="#4CAF50",
            fg="white"
        ).pack(side="left", padx=5)
        
        # Keyboard shortcuts
        self.bind('<Control-Return>', lambda e: self._on_confirm())
        self.bind('<Escape>', lambda e: self._on_cancel())
    
    def _on_confirm(self):
        """Handle confirm button click."""
        self.result = True
        self.create_backup = self.backup_var.get()
        logger.info("User confirmed file write")
        self.destroy()
    
    def _on_cancel(self):
        """Handle cancel button click."""
        self.result = False
        logger.info("User cancelled file write")
        self.destroy()


class ExpensiveRAGWarningDialog(tk.Toplevel):
    """
    Warning dialog for expensive RAG search operations.
    
    Warns user when RAG search will scan many files and provides
    options to proceed, cancel, or filter folders.
    """
    
    def __init__(self, parent, file_count: int, estimated_seconds: int):
        """
        Initialize expensive RAG warning dialog.
        
        Args:
            parent: Parent tkinter widget
            file_count: Number of files to be scanned
            estimated_seconds: Estimated time in seconds
        """
        super().__init__(parent)
        self.title("Warning: Expensive RAG Search")
        self.result = None
        
        # Configure window
        self.geometry("500x250")
        self.grid_columnconfigure(0, weight=1)
        
        # Warning icon and message
        message = (
            f"⚠️ This search will scan {file_count} files.\n\n"
            f"Estimated time: {estimated_seconds} seconds\n\n"
            f"Consider narrowing your search with folder filters\n"
            f"to improve performance."
        )
        
        self.message_label = tk.Label(
            self,
            text=message,
            font=("TkDefaultFont", 11),
            justify="left",
            wraplength=450
        )
        self.message_label.grid(row=0, column=0, padx=20, pady=20, sticky="w")
        
        # Buttons
        button_frame = tk.Frame(self)
        button_frame.grid(row=1, column=0, pady=10)
        
        tk.Button(
            button_frame,
            text="Cancel",
            command=self._on_cancel,
            width=15
        ).pack(side="left", padx=5)
        
        tk.Button(
            button_frame,
            text="Filter Folders",
            command=self._on_filter,
            width=15,
            bg="#FFA500",
            fg="white"
        ).pack(side="left", padx=5)
        
        tk.Button(
            button_frame,
            text="Proceed Anyway",
            command=self._on_proceed,
            width=15,
            bg="#4CAF50",
            fg="white"
        ).pack(side="left", padx=5)
        
        # Keyboard shortcuts
        self.bind('<Escape>', lambda e: self._on_cancel())
    
    def _on_proceed(self):
        """Handle proceed button click."""
        self.result = "proceed"
        logger.info(f"User proceeding with expensive RAG search")
        self.destroy()
    
    def _on_cancel(self):
        """Handle cancel button click."""
        self.result = "cancel"
        logger.info("User cancelled expensive RAG search")
        self.destroy()
    
    def _on_filter(self):
        """Handle filter folders button click."""
        self.result = "filter"
        logger.info("User requested folder filtering")
        self.destroy()
