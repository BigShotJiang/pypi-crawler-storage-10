"""Update manifest handling for fast version checks.

Provides schema and fetching for update-manifest.json hosted on GitHub Releases.
This replaces slow PyPI API calls with fast (<500ms) manifest queries.

Also provides automatic update checking via check_for_update().
"""

from .manifest import UpdateManifest, fetch_manifest, ManifestError
from .checker import check_for_update

__all__ = ["UpdateManifest", "fetch_manifest", "ManifestError", "check_for_update"]
