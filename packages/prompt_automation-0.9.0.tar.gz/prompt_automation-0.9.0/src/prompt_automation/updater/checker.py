"""Lightweight auto-update helper with manifest support.

Checks for newer versions using a fast manifest-based approach (GitHub Releases)
with PyPI fallback. Detects installation method and routes to appropriate
update strategy (pipx/pip/installer).

Behaviour is controlled by environment variable
``PROMPT_AUTOMATION_AUTO_UPDATE`` (default ``1`` = enabled). Set to ``0``
to disable. A state file stores the timestamp of the last check to rate‑limit
network calls to once per 24 hours.

All failures are silent; the main application should never be blocked by update
logic. The operation intentionally avoids additional third party dependencies.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
import os
import time
from pathlib import Path
from typing import Optional
from urllib import request, error
import sys
import logging

from ..config import HOME_DIR
from ..utils import safe_run
from ..installer import detect_install_method, InstallMethod
from .manifest import fetch_manifest, UpdateManifest

# Set up logging (silent by default, can be enabled for debugging)
logger = logging.getLogger(__name__)

try:  # Python >=3.8
    from importlib import metadata as importlib_metadata
except Exception:  # pragma: no cover
    import importlib_metadata  # type: ignore

PYPI_URL = "https://pypi.org/pypi/prompt-automation/json"
MANIFEST_URL = "https://github.com/josiahH-cf/prompt-automation/releases/latest/download/update-manifest.json"
STATE_PATH = HOME_DIR / "auto-update.json"
STATE_PATH.parent.mkdir(parents=True, exist_ok=True)

RATE_LIMIT_SECONDS = 60 * 60 * 24  # 24h
MANIFEST_TIMEOUT = 0.5  # 500ms for fast manifest check
PYPI_TIMEOUT = 2.0      # 2s for PyPI fallback

# Platform flag (indirectly patchable in tests)
_PLATFORM = sys.platform


@dataclass
class UpdateState:
    last_check: float = 0.0
    last_version: str = ""

    @classmethod
    def load(cls) -> "UpdateState":
        try:
            data = json.loads(STATE_PATH.read_text())
            return cls(**data)
        except Exception:
            return cls()

    def save(self) -> None:
        try:
            STATE_PATH.write_text(json.dumps(self.__dict__))
        except Exception:
            pass


def _current_version() -> str:
    try:
        return importlib_metadata.version("prompt-automation")
    except Exception:  # pragma: no cover
        return "0"


def _fetch_latest_version(timeout: float = 2.0) -> Optional[str]:
    """Fetch latest version from PyPI (fallback method).
    
    Args:
        timeout: Request timeout in seconds
        
    Returns:
        Latest version string, or None on failure
    """
    try:
        with request.urlopen(PYPI_URL, timeout=timeout) as resp:  # pragma: no cover - network
            data = json.loads(resp.read().decode("utf-8"))
            return data.get("info", {}).get("version")
    except error.URLError:
        return None
    except Exception:
        return None


def _fetch_latest_version_fast() -> Optional[str]:
    """Fetch latest version using manifest (fast path) with PyPI fallback.
    
    This function tries the fast manifest-based check first (~200ms), then
    falls back to PyPI if that fails (~2000ms). This provides 10x speedup
    for the common case while maintaining reliability.
    
    Returns:
        Latest version string, or None if both methods fail
    """
    start = time.perf_counter()
    
    # Try manifest first (fast path)
    try:
        manifest = fetch_manifest(MANIFEST_URL, timeout=MANIFEST_TIMEOUT)
        if manifest:
            elapsed = (time.perf_counter() - start) * 1000
            logger.debug(f"Manifest check succeeded in {elapsed:.0f}ms")
            return manifest.version
    except Exception as e:
        logger.debug(f"Manifest fetch failed: {e}")
    
    # Fall back to PyPI (slow but reliable)
    try:
        version = _fetch_latest_version(timeout=PYPI_TIMEOUT)
        if version:
            elapsed = (time.perf_counter() - start) * 1000
            logger.debug(f"PyPI fallback succeeded in {elapsed:.0f}ms")
            return version
    except Exception as e:
        logger.debug(f"PyPI fetch failed: {e}")
    
    return None


def _should_rate_limit(last_check: float) -> bool:
    return (time.time() - last_check) < RATE_LIMIT_SECONDS


def _is_newer(remote: str, local: str) -> bool:
    def parse(v: str):
        return [int(p) if p.isdigit() else p for p in v.replace("-", ".").split(".")]
    try:
        return parse(remote) > parse(local)
    except Exception:
        return remote != local


def _have_pipx() -> bool:
    from shutil import which
    return which("pipx") is not None


def _upgrade_via_pipx() -> None:
    """Attempt to upgrade via pipx with resilient fallbacks.

    Problem: On Windows + WSL workflows the provided install script may copy the
    project to a temporary directory (e.g. %TEMP%/prompt-automation-install) and
    run ``pipx install <that-temp-path>``. After installation the temp folder is
    deleted. ``pipx upgrade`` later attempts to resolve the *original* local
    path spec (now missing) and emits:

        "Unable to parse package spec: C:\\Users\\...\\Temp\\prompt-automation-install"

    This function detects that failure mode and transparently falls back to a
    clean forced install from PyPI (resetting the spec to the package name) so
    subsequent upgrades work normally. All failures remain silent by design.
    Set ``PROMPT_AUTOMATION_DISABLE_PIPX_FALLBACK=1`` to disable the fallback.
    """
    if os.environ.get("PROMPT_AUTOMATION_DISABLE_PIPX_FALLBACK") == "1":  # pragma: no cover - opt out
        try:
            safe_run(["pipx", "upgrade", "prompt-automation"], capture_output=True, timeout=30)
        except Exception:
            pass
        return

    try:
        res = safe_run(
            ["pipx", "upgrade", "prompt-automation"], capture_output=True, text=True, timeout=30
        )
        if res.returncode == 0:
            return
        combined = (res.stdout or "") + "\n" + (res.stderr or "")
        if "Unable to parse package spec" in combined or "parse package spec" in combined:
            # Fallback: reinstall from PyPI (forces spec to canonical name)
            try:
                safe_run(
                    ["pipx", "install", "--force", "prompt-automation"],
                    capture_output=True,
                    timeout=60,
                )
            except Exception:
                # Final fallback: user install via pip (no pipx) so they at least get newer code
                try:
                    safe_run(
                        ["python", "-m", "pip", "install", "--upgrade", "--user", "prompt-automation"],
                        capture_output=True,
                        timeout=60,
                    )
                except Exception:
                    pass
    except Exception:
        # Silent by design
        pass


def check_for_update() -> None:
    """Check for updates and attempt automatic upgrade if available.
    
    This function:
    1. Detects the installation method (pipx/pip/installer/editable)
    2. Checks for newer version using manifest (fast) with PyPI fallback
    3. Routes to appropriate update strategy based on install method
    4. All operations are silent failures by design
    """
    # Global opt-out
    if os.environ.get("PROMPT_AUTOMATION_AUTO_UPDATE", "1") == "0":
        return

    # Detect installation method first
    try:
        install_info = detect_install_method()
        logger.debug(f"Detected install method: {install_info.method}")
    except Exception as e:
        logger.debug(f"Could not detect install method: {e}")
        install_info = None

    # Safety default on Windows: skip implicit pipx upgrades unless explicitly opted in.
    # This avoids breaking pipx shims when installed from temporary/local specs
    # (a common pattern on Windows when installing from a WSL path via PowerShell).
    if _PLATFORM.startswith("win") and os.environ.get(
        "PROMPT_AUTOMATION_WINDOWS_ALLOW_PIPX_UPDATE", "0"
    ) != "1":
        return

    # Rate limiting
    state = UpdateState.load()
    if _should_rate_limit(state.last_check):
        return

    # Check for newer version (manifest-first, PyPI fallback)
    local_version = _current_version()
    latest = _fetch_latest_version_fast()
    state.last_check = time.time()
    if latest:
        state.last_version = latest
    state.save()

    if not latest or not _is_newer(latest, local_version):
        return

    # Route to appropriate update strategy based on install method
    if install_info:
        if install_info.method == InstallMethod.PIPX:
            if _have_pipx():
                try:
                    _upgrade_via_pipx()
                except Exception:
                    pass  # Silent failure - don't block application
        elif install_info.method == InstallMethod.PIP_USER:
            # User install: upgrade via pip --user
            try:
                safe_run(
                    ["python", "-m", "pip", "install", "--upgrade", "--user", "prompt-automation"],
                    capture_output=True,
                    timeout=60,
                )
            except Exception:
                pass
        elif install_info.method == InstallMethod.EDITABLE:
            # Editable install: skip auto-update (developer mode)
            logger.debug("Editable install detected, skipping auto-update")
            return
        elif install_info.method == InstallMethod.INSTALLER:
            # Installer-based: skip auto-update (managed by installer)
            logger.debug("Installer-based install detected, skipping auto-update")
            return
        else:
            # Unknown or PIP_GLOBAL: try pipx if available, else skip
            if _have_pipx():
                try:
                    _upgrade_via_pipx()
                except Exception:
                    pass  # Silent failure
    else:
        # Fallback: try pipx if available
        if _have_pipx():
            try:
                _upgrade_via_pipx()
            except Exception:
                pass  # Silent failure


__all__ = ["check_for_update"]
