"""Update manifest schema and fetching.

The update manifest is a JSON file hosted on GitHub Releases that provides:
- Latest version information
- Download URLs for all platforms
- Changelog and release notes
- Breaking changes flag
- Critical update flag

This enables fast (<500ms) update checks without PyPI API dependency.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, Dict
import json
from urllib import request, error


class ManifestError(Exception):
    """Error fetching or parsing update manifest."""
    pass


@dataclass
class UpdateManifest:
    """Update manifest schema.
    
    Hosted at: https://github.com/USER/REPO/releases/latest/download/update-manifest.json
    
    Example:
        {
          "version": "0.9.0",
          "released_at": "2025-10-26T12:00:00Z",
          "changelog_url": "https://github.com/USER/REPO/releases/tag/v0.9.0",
          "changelog_summary": "Bug fixes, performance improvements",
          "download_urls": {
            "pypi": "https://pypi.org/project/prompt-automation/0.9.0/",
            "windows": "https://github.com/USER/REPO/releases/download/v0.9.0/prompt-automation-0.9.0.exe",
            "macos": "https://github.com/USER/REPO/releases/download/v0.9.0/prompt-automation-0.9.0.dmg",
            "linux": "https://github.com/USER/REPO/releases/download/v0.9.0/prompt-automation-0.9.0.deb"
          },
          "requires_python": ">=3.11",
          "breaking_changes": false,
          "critical": false
        }
    """
    
    version: str
    released_at: str
    changelog_url: str
    changelog_summary: str
    download_urls: Dict[str, str]
    requires_python: str = ">=3.11"
    breaking_changes: bool = False
    critical: bool = False
    
    @classmethod
    def from_dict(cls, data: dict) -> "UpdateManifest":
        """Create UpdateManifest from dictionary.
        
        Args:
            data: Dictionary from parsed JSON
            
        Returns:
            UpdateManifest instance
            
        Raises:
            ManifestError: If required fields are missing or invalid
        """
        try:
            return cls(
                version=data["version"],
                released_at=data["released_at"],
                changelog_url=data["changelog_url"],
                changelog_summary=data["changelog_summary"],
                download_urls=data["download_urls"],
                requires_python=data.get("requires_python", ">=3.11"),
                breaking_changes=data.get("breaking_changes", False),
                critical=data.get("critical", False)
            )
        except KeyError as e:
            raise ManifestError(f"Missing required field: {e}")
        except (TypeError, ValueError) as e:
            raise ManifestError(f"Invalid manifest format: {e}")
    
    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "version": self.version,
            "released_at": self.released_at,
            "changelog_url": self.changelog_url,
            "changelog_summary": self.changelog_summary,
            "download_urls": self.download_urls,
            "requires_python": self.requires_python,
            "breaking_changes": self.breaking_changes,
            "critical": self.critical
        }
    
    def get_download_url(self, platform: str = "pypi") -> Optional[str]:
        """Get download URL for specific platform.
        
        Args:
            platform: Platform name (pypi, windows, macos, linux)
            
        Returns:
            Download URL or None if platform not available
        """
        return self.download_urls.get(platform)
    
    def is_compatible_python(self, current_version: str) -> bool:
        """Check if current Python version meets requirements.
        
        Args:
            current_version: Current Python version (e.g., "3.12.3")
            
        Returns:
            True if compatible, False otherwise
        """
        # Simple version comparison (e.g., ">=3.11" requires 3.11+)
        # More robust implementation would use packaging.specifiers
        if self.requires_python.startswith(">="):
            required = self.requires_python[2:].strip()
            return _compare_versions(current_version, required) >= 0
        return True  # Default to compatible if no requirement


def fetch_manifest(url: str, timeout: float = 0.5) -> Optional[UpdateManifest]:
    """Fetch and parse update manifest from URL.
    
    Args:
        url: Manifest URL (e.g., GitHub Releases download link)
        timeout: Request timeout in seconds (default: 500ms)
        
    Returns:
        UpdateManifest if successful, None on error
        
    Examples:
        >>> manifest = fetch_manifest(
        ...     "https://github.com/user/repo/releases/latest/download/update-manifest.json"
        ... )
        >>> if manifest:
        ...     print(f"Latest version: {manifest.version}")
    """
    try:
        with request.urlopen(url, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return UpdateManifest.from_dict(data)
    except (error.URLError, TimeoutError, OSError) as e:
        # Network error (timeout, DNS, connection refused, socket errors)
        return None
    except json.JSONDecodeError as e:
        # Invalid JSON
        raise ManifestError(f"Invalid JSON in manifest: {e}")
    except ManifestError:
        # Re-raise manifest errors
        raise
    except Exception as e:
        # Unexpected error
        raise ManifestError(f"Unexpected error fetching manifest: {e}")


def _compare_versions(version1: str, version2: str) -> int:
    """Compare two version strings.
    
    Args:
        version1: First version (e.g., "3.12.3")
        version2: Second version (e.g., "3.11.0")
        
    Returns:
        -1 if version1 < version2
        0 if version1 == version2
        1 if version1 > version2
    """
    def parse(v: str):
        """Parse version string into list of integers."""
        return [int(p) if p.isdigit() else p for p in v.replace("-", ".").split(".")]
    
    try:
        v1_parts = parse(version1)
        v2_parts = parse(version2)
        
        # Pad shorter version with zeros
        max_len = max(len(v1_parts), len(v2_parts))
        v1_parts += [0] * (max_len - len(v1_parts))
        v2_parts += [0] * (max_len - len(v2_parts))
        
        # Compare part by part
        for p1, p2 in zip(v1_parts, v2_parts):
            if p1 < p2:
                return -1
            elif p1 > p2:
                return 1
        
        return 0
    except Exception:
        # Fallback to string comparison
        if version1 < version2:
            return -1
        elif version1 > version2:
            return 1
        return 0
