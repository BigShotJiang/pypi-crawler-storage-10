"""Error recovery module for prompt-automation.

This module provides automatic rollback and recovery capabilities:
- MutationLogger: Append-only log of file mutations with snapshots
- MutationTransaction: Context manager for atomic operations with rollback
- ErrorCatalog: Maps error codes to actionable remedies
- CLI tools: Manual rollback commands

Example:
    >>> from prompt_automation.error_recovery import MutationTransaction
    >>> 
    >>> with MutationTransaction("edit_config", ["/path/to/config.json"], "user"):
    ...     # Your operation here
    ...     config_file.write_text(new_config)
    ... # Automatically rolls back if exception occurs
"""

from .catalog import ErrorCatalog
from .mutation_logger import MutationLogger
from .transaction import MutationTransaction

__all__ = [
    "MutationLogger",
    "MutationTransaction",
    "ErrorCatalog"
]
