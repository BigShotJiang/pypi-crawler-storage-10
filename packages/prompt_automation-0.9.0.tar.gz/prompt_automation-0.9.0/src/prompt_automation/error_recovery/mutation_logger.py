"""Mutation logger for error recovery."""

import json
import shutil
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional

from ..errorlog import get_logger
from ..platform_utils import get_app_home


_log = get_logger(__name__)


class MutationLogger:
    """Log all file mutations for rollback support.
    
    Stores mutation logs in JSON lines format with snapshots of affected files.
    Supports querying snapshots by ID and pruning old logs.
    
    Example:
        >>> logger = MutationLogger()
        >>> logger.log_mutation("edit_template", ["/path/to/template.json"], "user")
        >>> snapshot = logger.get_snapshot("20251025_120000")
        >>> logger.prune_old_logs(retention_days=30)
    """
    
    def __init__(
        self,
        log_file: Optional[Path] = None,
        backup_dir: Optional[Path] = None
    ):
        """Initialize mutation logger.
        
        Args:
            log_file: Path to mutation log file (default: ~/.prompt-automation/mutation-log.jsonl)
            backup_dir: Path to backup directory (default: ~/.prompt-automation/backups/)
        """
        app_home = get_app_home()
        self.log_file = log_file or (app_home / "mutation-log.jsonl")
        self.backup_dir = backup_dir or (app_home / "backups")
        
    def log_mutation(
        self,
        operation: str,
        files: List[str],
        user: str
    ) -> Path:
        """Log a mutation and create file snapshots.
        
        Args:
            operation: Name of operation (e.g., "edit_template", "save_config")
            files: List of file paths affected by this mutation
            user: User who performed the operation
            
        Returns:
            Path to snapshot directory
            
        Example:
            >>> logger.log_mutation("edit_template", ["/path/to/template.json"], "user")
            Path('/home/user/.prompt-automation/backups/20251025_120000')
        """
        # Generate snapshot ID from timestamp (with microseconds for uniqueness)
        timestamp = datetime.now()
        snapshot_id = timestamp.strftime("%Y%m%d_%H%M%S_%f")[:21]  # Include microseconds
        
        # Create snapshot directory
        snapshot_dir = self.backup_dir / snapshot_id
        snapshot_dir.mkdir(parents=True, exist_ok=True)
        
        # Copy each file to snapshot
        for file_path in files:
            source = Path(file_path)
            if source.exists():
                # Preserve directory structure within snapshot
                dest = snapshot_dir / source.name
                shutil.copy2(source, dest)
                _log.debug(f"Snapshot created: {file_path} -> {dest}")
        
        # Create log entry
        log_entry = {
            "timestamp": timestamp.isoformat(),
            "snapshot_id": snapshot_id,
            "operation": operation,
            "files": files,
            "user": user
        }
        
        # Append to log file (JSON lines format)
        self.log_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.log_file, 'a') as f:
            f.write(json.dumps(log_entry) + '\n')
        
        _log.info(f"Mutation logged: {operation} by {user} ({len(files)} files)")
        
        return snapshot_dir
    
    def get_snapshot(self, snapshot_id: str) -> Optional[Dict[str, Path]]:
        """Retrieve snapshot files by ID.
        
        Args:
            snapshot_id: Snapshot ID (e.g., "20251025_120000")
            
        Returns:
            Dict mapping original file paths to snapshot paths, or None if not found
            
        Example:
            >>> snapshot = logger.get_snapshot("20251025_120000")
            >>> snapshot["/path/to/template.json"]
            Path('/home/user/.prompt-automation/backups/20251025_120000/template.json')
        """
        snapshot_dir = self.backup_dir / snapshot_id
        
        if not snapshot_dir.exists():
            _log.warning(f"Snapshot not found: {snapshot_id}")
            return None
        
        # Read log to get original file paths
        if not self.log_file.exists():
            return None
        
        with open(self.log_file, 'r') as f:
            for line in f:
                if not line.strip():
                    continue
                entry = json.loads(line)
                if entry["snapshot_id"] == snapshot_id:
                    # Map original paths to snapshot paths
                    result = {}
                    for original_path in entry["files"]:
                        snapshot_file = snapshot_dir / Path(original_path).name
                        if snapshot_file.exists():
                            result[original_path] = snapshot_file
                    return result
        
        return None
    
    def prune_old_logs(self, retention_days: int = 30) -> int:
        """Delete logs and snapshots older than retention period.
        
        Args:
            retention_days: Number of days to retain logs (default: 30)
            
        Returns:
            Number of snapshots deleted
            
        Example:
            >>> deleted = logger.prune_old_logs(retention_days=30)
            >>> print(f"Deleted {deleted} old snapshots")
        """
        if not self.log_file.exists():
            return 0
        
        cutoff_date = datetime.now() - timedelta(days=retention_days)
        deleted_count = 0
        
        # Read all log entries
        with open(self.log_file, 'r') as f:
            log_entries = [json.loads(line) for line in f if line.strip()]
        
        # Filter out old entries
        recent_entries = []
        for entry in log_entries:
            entry_date = datetime.fromisoformat(entry["timestamp"])
            if entry_date >= cutoff_date:
                recent_entries.append(entry)
            else:
                # Delete snapshot directory
                snapshot_dir = self.backup_dir / entry["snapshot_id"]
                if snapshot_dir.exists():
                    shutil.rmtree(snapshot_dir)
                    deleted_count += 1
                    _log.debug(f"Deleted old snapshot: {entry['snapshot_id']}")
        
        # Rewrite log file with recent entries only
        with open(self.log_file, 'w') as f:
            for entry in recent_entries:
                f.write(json.dumps(entry) + '\n')
        
        _log.info(f"Pruned {deleted_count} old snapshots (retention: {retention_days} days)")
        
        return deleted_count
