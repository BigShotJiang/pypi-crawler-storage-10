"""Error catalog with actionable remedies."""

import re
from typing import Dict, Optional


class ErrorCatalog:
    """Maps error codes and error messages to user-friendly remedies.
    
    Provides actionable fix suggestions for common errors to help users
    recover quickly without manual intervention.
    
    Usage:
        >>> catalog = ErrorCatalog()
        >>> remedy = catalog.get_remedy("E001")
        >>> print(remedy)
        Run `prompt-automation --fix-config` to repair configuration
        
        >>> error_type = catalog.classify_error("FileNotFoundError: config.json")
        >>> print(error_type)
        file_error
    """
    
    # Error code to remedy mapping
    ERROR_REMEDIES = {
        "E001": "Run `prompt-automation --fix-config` to repair configuration file",
        "E002": "Run `prompt-automation --validate-templates` to check template syntax",
        "E003": "Check file permissions: `chmod 600 ~/.prompt-automation/config.json`",
        "E004": "Disk full - free up space or run `prompt-automation --cleanup-snapshots`",
        "E005": "API connection failed - check network connectivity or API credentials",
        "E006": "Invalid JSON syntax - use `jsonlint` or check for trailing commas",
        "E007": "Missing required field - check template schema documentation",
        "E008": "Snapshot not found - rollback target may have been pruned (>30 days old)",
        "E009": "Concurrent modification detected - retry operation or use file locks",
        "E010": "Template rendering failed - check placeholder syntax: {{variable}}",
        "E011": "MCP server connection failed - verify server is running",
        "E012": "Cache corruption detected - run `prompt-automation --rebuild-cache`",
        "E013": "Database locked - close other prompt-automation instances",
        "E014": "Invalid feature flag - check feature.py for valid flags",
        "E015": "Rollback failed - manual intervention required (see logs)",
    }
    
    # Error classification patterns
    ERROR_PATTERNS = [
        (r"FileNotFoundError|No such file", "file_error"),
        (r"PermissionError|Permission denied", "file_error"),
        (r"JSONDecodeError|Invalid JSON|json", "json_error"),
        (r"ConnectionError|Timeout|HTTPError|API", "api_error"),
        (r"ValueError|Invalid", "validation_error"),
        (r"KeyError|Missing", "validation_error"),
        (r"OSError|Disk full", "disk_error"),
        (r"sqlite3\.|Database", "database_error"),
    ]
    
    def get_remedy(self, error_code: str) -> Optional[str]:
        """Get remedy for a specific error code.
        
        Args:
            error_code: Error code (e.g., "E001", "E002")
            
        Returns:
            Remedy string if found, None otherwise
            
        Example:
            >>> catalog = ErrorCatalog()
            >>> catalog.get_remedy("E001")
            'Run `prompt-automation --fix-config` to repair configuration file'
        """
        return self.ERROR_REMEDIES.get(error_code)
    
    def classify_error(self, error_message: str) -> str:
        """Classify error message by type.
        
        Uses regex patterns to categorize errors for better handling.
        
        Args:
            error_message: Full error message text
            
        Returns:
            Error category (e.g., "file_error", "json_error", "unknown")
            
        Example:
            >>> catalog = ErrorCatalog()
            >>> catalog.classify_error("FileNotFoundError: config.json")
            'file_error'
        """
        for pattern, error_type in self.ERROR_PATTERNS:
            if re.search(pattern, error_message, re.IGNORECASE):
                return error_type
        
        return "unknown"
    
    def get_remedy_for_error(self, error_message: str) -> Optional[str]:
        """Get context-aware remedy based on error message.
        
        Analyzes the error message to provide the most relevant remedy.
        
        Args:
            error_message: Full error message text
            
        Returns:
            Remedy string if pattern matches, None otherwise
            
        Example:
            >>> catalog = ErrorCatalog()
            >>> catalog.get_remedy_for_error("JSONDecodeError: Invalid config.json")
            'Run `prompt-automation --fix-config` to repair configuration file'
        """
        error_type = self.classify_error(error_message)
        
        # Context-aware remedies based on error type and content
        if error_type == "json_error":
            if "config" in error_message.lower():
                return self.ERROR_REMEDIES["E001"]
            elif "template" in error_message.lower():
                return self.ERROR_REMEDIES["E002"]
            else:
                return self.ERROR_REMEDIES["E006"]
        
        elif error_type == "file_error":
            if "permission" in error_message.lower():
                return self.ERROR_REMEDIES["E003"]
            elif "disk" in error_message.lower():
                return self.ERROR_REMEDIES["E004"]
            else:
                return "Check file path and permissions"
        
        elif error_type == "api_error":
            return self.ERROR_REMEDIES["E005"]
        
        elif error_type == "validation_error":
            if "template" in error_message.lower():
                return self.ERROR_REMEDIES["E010"]
            elif "placeholder" in error_message.lower():
                return self.ERROR_REMEDIES["E010"]
            else:
                return self.ERROR_REMEDIES["E007"]
        
        elif error_type == "database_error":
            return self.ERROR_REMEDIES["E013"]
        
        return None
    
    def list_all_remedies(self) -> Dict[str, str]:
        """List all available error remedies.
        
        Returns:
            Dictionary mapping error codes to remedies
            
        Example:
            >>> catalog = ErrorCatalog()
            >>> remedies = catalog.list_all_remedies()
            >>> len(remedies)
            15
        """
        return self.ERROR_REMEDIES.copy()
