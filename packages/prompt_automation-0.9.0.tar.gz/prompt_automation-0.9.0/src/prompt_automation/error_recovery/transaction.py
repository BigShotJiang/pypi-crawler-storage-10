"""Transaction context manager for error recovery."""

import shutil
from pathlib import Path
from typing import Dict, List, Optional

from ..errorlog import get_logger
from .mutation_logger import MutationLogger


_log = get_logger(__name__)


class MutationTransaction:
    """Context manager for atomic file operations with automatic rollback.
    
    Usage:
        with MutationTransaction(operation="edit_template", files=[path], user="user"):
            # Perform file modifications
            # If exception occurs, changes are automatically rolled back
            pass
    
    Example:
        >>> with MutationTransaction("save_config", [config_path], "admin"):
        ...     config_path.write_text(new_config)
        ...     # If exception raised, config is restored to previous state
    """
    
    def __init__(
        self,
        operation: str,
        files: List[str],
        user: str,
        backup_dir: Optional[Path] = None
    ):
        """Initialize transaction.
        
        Args:
            operation: Name of operation
            files: List of file paths to protect
            user: User performing operation
            backup_dir: Optional backup directory (for testing)
        """
        self.operation = operation
        self.files = files
        self.user = user
        self.snapshot_dir: Optional[Path] = None
        self.logger = MutationLogger(backup_dir=backup_dir) if backup_dir else MutationLogger()
        self.snapshot_id: Optional[str] = None
    
    def __enter__(self):
        """Enter transaction context - create snapshot."""
        try:
            # Log mutation and create snapshots
            self.snapshot_dir = self.logger.log_mutation(
                operation=self.operation,
                files=self.files,
                user=self.user
            )
            
            # Extract snapshot ID from directory name
            self.snapshot_id = self.snapshot_dir.name
            
            _log.debug(f"Transaction started: {self.operation} (snapshot: {self.snapshot_id})")
            
        except Exception as e:
            _log.error(f"Failed to create snapshot for {self.operation}: {e}")
            raise
        
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit transaction context - commit or rollback."""
        if exc_type is None:
            # Success - commit changes
            _log.info(f"Transaction committed: {self.operation}")
            return False
        
        # Error occurred - rollback
        try:
            self._restore_snapshot()
            _log.info(f"Transaction rolled back: {self.operation} (error: {exc_type.__name__})")
        except Exception as rollback_error:
            _log.error(f"Rollback failed for {self.operation}: {rollback_error}")
            # Let original exception propagate
        
        # Don't suppress the original exception
        return False
    
    def _restore_snapshot(self) -> None:
        """Restore files from snapshot."""
        if not self.snapshot_id:
            raise ValueError("No snapshot ID available for rollback")
        
        # Retrieve snapshot files
        snapshot_files = self.logger.get_snapshot(self.snapshot_id)
        
        if not snapshot_files:
            raise ValueError(f"Snapshot not found: {self.snapshot_id}")
        
        # Restore each file
        restored_count = 0
        for original_path, snapshot_path in snapshot_files.items():
            try:
                # Atomic restore: copy snapshot to temp, then rename
                original = Path(original_path)
                temp_path = original.with_suffix(original.suffix + '.tmp')
                
                # Copy snapshot to temp
                shutil.copy2(snapshot_path, temp_path)
                
                # Atomic rename
                temp_path.replace(original)
                
                restored_count += 1
                _log.debug(f"Restored: {original_path}")
                
            except Exception as e:
                _log.error(f"Failed to restore {original_path}: {e}")
                raise
        
        _log.info(f"Restored {restored_count}/{len(snapshot_files)} files")

