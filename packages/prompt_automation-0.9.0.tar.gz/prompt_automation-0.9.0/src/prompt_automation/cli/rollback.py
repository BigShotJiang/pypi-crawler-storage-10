"""CLI commands for manual error recovery."""

import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional

from prompt_automation.platform_utils import get_app_home


def rollback(
    snapshot_id: str,
    log_file: Optional[Path] = None,
    backup_dir: Optional[Path] = None
) -> bool:
    """
    Rollback to a specific snapshot.
    
    Args:
        snapshot_id: Snapshot ID to restore (e.g., "20251025_120000_123456")
        log_file: Path to mutation log (defaults to ~/.prompt-automation/mutation-log.jsonl)
        backup_dir: Path to backup directory (defaults to ~/.prompt-automation/backups/)
    
    Returns:
        True if rollback successful, False otherwise
    """
    # Use defaults if not specified
    if log_file is None:
        log_file = get_app_home() / "mutation-log.jsonl"
    if backup_dir is None:
        backup_dir = get_app_home() / "backups"
    
    # Check if snapshot exists
    snapshot_path = backup_dir / snapshot_id
    if not snapshot_path.exists():
        return False
    
    # Find the log entry for this snapshot to get original file paths
    if not log_file.exists():
        return False
    
    original_files = []
    with open(log_file) as f:
        for line in f:
            entry = json.loads(line)
            if entry["snapshot_id"] == snapshot_id:
                original_files = entry.get("files", [])
                break
    
    if not original_files:
        return False
    
    # Restore files
    for original_file_path in original_files:
        original_path = Path(original_file_path)
        snapshot_file = snapshot_path / original_path.name
        
        if not snapshot_file.exists():
            continue
        
        # Copy snapshot file to original location
        try:
            original_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Atomic restore: write to temp, then rename
            temp_file = original_path.with_suffix(original_path.suffix + ".tmp")
            temp_file.write_bytes(snapshot_file.read_bytes())
            temp_file.replace(original_path)
        except Exception:
            return False
    
    return True


def list_snapshots(
    log_file: Optional[Path] = None,
    backup_dir: Optional[Path] = None
) -> List[Dict]:
    """
    List all available snapshots.
    
    Args:
        log_file: Path to mutation log (defaults to ~/.prompt-automation/mutation-log.jsonl)
        backup_dir: Path to backup directory (defaults to ~/.prompt-automation/backups/)
    
    Returns:
        List of snapshot dicts with keys: snapshot_id, operation, user, timestamp, files
    """
    # Use defaults if not specified
    if log_file is None:
        log_file = get_app_home() / "mutation-log.jsonl"
    if backup_dir is None:
        backup_dir = get_app_home() / "backups"
    
    # Read log file
    if not log_file.exists():
        return []
    
    snapshots = []
    with open(log_file) as f:
        for line in f:
            entry = json.loads(line)
            snapshots.append({
                "snapshot_id": entry["snapshot_id"],
                "operation": entry["operation"],
                "user": entry["user"],
                "timestamp": entry["timestamp"],
                "files": entry.get("files", [])
            })
    
    return snapshots


def cleanup_old_snapshots(
    retention_days: int = 30,
    log_file: Optional[Path] = None,
    backup_dir: Optional[Path] = None
) -> int:
    """
    Delete snapshots older than retention period.
    
    Args:
        retention_days: Number of days to keep snapshots (default 30)
        log_file: Path to mutation log (defaults to ~/.prompt-automation/mutation-log.jsonl)
        backup_dir: Path to backup directory (defaults to ~/.prompt-automation/backups/)
    
    Returns:
        Number of snapshots deleted
    """
    # Use defaults if not specified
    if log_file is None:
        log_file = get_app_home() / "mutation-log.jsonl"
    if backup_dir is None:
        backup_dir = get_app_home() / "backups"
    
    # Calculate cutoff date
    cutoff = datetime.now() - timedelta(days=retention_days)
    
    # Read log file
    if not log_file.exists():
        return 0
    
    deleted_count = 0
    remaining_entries = []
    
    with open(log_file) as f:
        for line in f:
            entry = json.loads(line)
            
            # Parse timestamp
            timestamp_str = entry["timestamp"]
            timestamp = datetime.fromisoformat(timestamp_str)
            
            # Check if older than cutoff
            if timestamp < cutoff:
                # Delete snapshot directory
                snapshot_id = entry["snapshot_id"]
                snapshot_path = backup_dir / snapshot_id
                
                if snapshot_path.exists():
                    import shutil
                    shutil.rmtree(snapshot_path)
                    deleted_count += 1
            else:
                # Keep this entry
                remaining_entries.append(line)
    
    # Rewrite log file without deleted entries
    with open(log_file, "w") as f:
        for line in remaining_entries:
            f.write(line)
    
    return deleted_count
