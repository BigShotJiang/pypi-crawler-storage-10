"""CLI commands for MCP Router operations."""

import json
import sys
from pathlib import Path
from typing import Any, Dict

from ..mcp.router import MCPRouter, ServerRegistry


def cmd_list_servers(registry_path: Path | None = None) -> int:
    """List all enabled MCP servers.
    
    Args:
        registry_path: Path to registry JSON (optional, uses default if None)
    
    Returns:
        Exit code (0 for success, 1 for error)
    """
    try:
        registry = ServerRegistry(registry_path)
        servers = registry.load_servers()
        
        # Filter enabled servers
        enabled_servers = [s for s in servers if s.enabled]
        
        # Format output
        output = {
            "total": len(enabled_servers),
            "servers": [
                {
                    "id": server.id,
                    "name": server.name,
                    "transport": server.transport.value,
                    "namespace": server.namespace or server.id,
                    "priority": server.priority,
                    "endpoint": server.endpoint if server.transport.value == "http" else None,
                    "command": server.command if server.transport.value == "stdio" else None,
                }
                for server in enabled_servers
            ]
        }
        
        print(json.dumps(output, indent=2))
        return 0
    
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        return 1


async def cmd_list_tools(registry_path: Path | None = None) -> int:
    """List all available tools from all servers.
    
    Args:
        registry_path: Path to registry JSON (optional, uses default if None)
    
    Returns:
        Exit code (0 for success, 1 for error)
    """
    try:
        async with MCPRouter(registry_path=registry_path) as router:
            await router.initialize()
            
            # Get all tools
            tools_by_server = await router.discover_all()
            
            # Format output
            all_tools = []
            for server_id, tools in tools_by_server.items():
                for tool in tools:
                    all_tools.append({
                        "qualified_name": tool.qualified_name,
                        "name": tool.name,
                        "namespace": tool.namespace,
                        "server_id": tool.server_id,
                        "description": tool.description,
                    })
            
            output = {
                "total": len(all_tools),
                "servers": len(tools_by_server),
                "tools": all_tools
            }
            
            print(json.dumps(output, indent=2))
            return 0
    
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        return 1


async def cmd_call_tool(
    qualified_name: str,
    arguments: Dict[str, Any],
    registry_path: Path | None = None,
    max_retries: int = 3,
    fallback: bool = True
) -> int:
    """Call a tool by qualified name.
    
    Args:
        qualified_name: Qualified tool name (e.g., "obsidian.search_note")
        arguments: Tool arguments as dict
        registry_path: Path to registry JSON (optional, uses default if None)
        max_retries: Max retry attempts (default: 3)
        fallback: Try alternative servers on failure (default: True)
    
    Returns:
        Exit code (0 for success, 1 for error)
    """
    try:
        async with MCPRouter(registry_path=registry_path) as router:
            await router.initialize()
            
            # Call tool
            result = await router.call_tool(
                qualified_name,
                arguments,
                max_retries=max_retries,
                fallback=fallback
            )
            
            # Format output
            output = {
                "tool": qualified_name,
                "result": result
            }
            
            print(json.dumps(output, indent=2))
            return 0
    
    except ValueError as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        return 1
    except Exception as e:
        print(json.dumps({"error": f"Tool call failed: {e}"}), file=sys.stderr)
        return 1


async def cmd_health_check(
    server_id: str | None = None,
    registry_path: Path | None = None
) -> int:
    """Check health of MCP server(s).
    
    Args:
        server_id: Specific server ID (optional, checks all if None)
        registry_path: Path to registry JSON (optional, uses default if None)
    
    Returns:
        Exit code (0 for success, 1 for error)
    """
    try:
        async with MCPRouter(registry_path=registry_path) as router:
            await router.initialize()
            
            # Check health
            health_status = await router.health_check(server_id)
            
            # Format output
            output = {
                "servers": health_status,
                "all_healthy": all(health_status.values())
            }
            
            print(json.dumps(output, indent=2))
            return 0 if output["all_healthy"] else 1
    
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        return 1
