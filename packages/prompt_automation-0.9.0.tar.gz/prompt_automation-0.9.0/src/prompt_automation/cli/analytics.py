"""CLI commands for analytics.

Provides command-line interface for viewing analytics data.
"""

import click
import json
from datetime import datetime
from pathlib import Path

from prompt_automation.analytics import Analytics


@click.group()
def analytics():
    """Analytics commands."""
    pass


@analytics.command()
@click.option("--hours", default=24, help="Time range in hours (default: 24)")
def summary(hours):
    """Show analytics summary."""
    analytics_obj = Analytics()
    
    click.echo(f"\n📊 Analytics Summary (Last {hours} hours)\n")
    click.echo("=" * 50)
    
    try:
        # Template renders
        top_templates = analytics_obj.get_top_templates(limit=5, hours=hours)
        total_renders = sum(t["count"] for t in top_templates)
        click.echo(f"\n📝 Template Renders: {total_renders}")
        
        # Cache hit rate
        cache_rate = analytics_obj.get_cache_hit_rate(hours=hours)
        cache_pct = cache_rate * 100 if cache_rate else 0
        click.echo(f"💾 Cache Hit Rate: {cache_pct:.1f}%")
        
        # Errors
        recent_errors = analytics_obj.get_recent_errors(limit=100, hours=hours)
        click.echo(f"❌ Errors: {len(recent_errors)}")
        
        # Latency
        latency = analytics_obj.get_latency_percentiles(hours=hours)
        if latency:
            click.echo(f"⏱️  Latency (P95): {latency.get('p95', 0):.0f}ms")
        
        click.echo("\n" + "=" * 50 + "\n")
        
    except Exception as e:
        click.echo(f"\n❌ Error fetching summary: {e}\n", err=True)


@analytics.command("top-templates")
@click.option("--limit", default=10, help="Number of templates to show (default: 10)")
@click.option("--hours", default=24, help="Time range in hours (default: 24)")
def top_templates(limit, hours):
    """Show most-used templates."""
    analytics_obj = Analytics()
    
    click.echo(f"\n🏆 Top {limit} Templates (Last {hours} hours)\n")
    click.echo("=" * 70)
    
    try:
        templates = analytics_obj.get_top_templates(limit=limit, hours=hours)
        
        if not templates:
            click.echo("\nNo template data found.\n")
            return
        
        # Header
        click.echo(f"{'Rank':<6}{'Template ID':<15}{'Uses':<10}{'Avg Duration':<15}{'Total Time'}")
        click.echo("-" * 70)
        
        # Rows
        for i, template in enumerate(templates, 1):
            template_id = template.get("template_id", "unknown")
            count = template.get("count", 0)
            avg_duration = template.get("avg_duration_ms", 0)
            total_duration = count * avg_duration
            
            click.echo(
                f"{i:<6}{template_id:<15}{count:<10}"
                f"{avg_duration:>8.0f}ms     {total_duration/1000:>6.1f}s"
            )
        
        click.echo("=" * 70 + "\n")
        
    except Exception as e:
        click.echo(f"\n❌ Error fetching templates: {e}\n", err=True)


@analytics.command()
@click.option("--limit", default=20, help="Number of errors to show (default: 20)")
@click.option("--hours", default=24, help="Time range in hours (default: 24)")
def errors(limit, hours):
    """Show recent errors."""
    analytics_obj = Analytics()
    
    click.echo(f"\n⚠️  Recent Errors (Last {hours} hours, limit {limit})\n")
    click.echo("=" * 80)
    
    try:
        error_list = analytics_obj.get_recent_errors(limit=limit, hours=hours)
        
        if not error_list:
            click.echo("\n✅ No errors found!\n")
            return
        
        for i, error in enumerate(error_list, 1):
            timestamp = datetime.fromtimestamp(error.get("timestamp", 0))
            error_type = error.get("error_type", "unknown")
            message = error.get("message", "")
            context = error.get("context", {})
            
            click.echo(f"\n[{i}] {timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
            click.echo(f"    Type: {error_type}")
            click.echo(f"    Message: {message[:100]}")
            if context:
                click.echo(f"    Context: {context}")
        
        click.echo("\n" + "=" * 80 + "\n")
        
    except Exception as e:
        click.echo(f"\n❌ Error fetching errors: {e}\n", err=True)


@analytics.command()
@click.option("--hours", default=1, help="Time range in hours (default: 1)")
def resources(hours):
    """Show resource usage trends."""
    analytics_obj = Analytics()
    
    click.echo(f"\n💻 Resource Usage (Last {hours} hours)\n")
    click.echo("=" * 60)
    
    try:
        trends = analytics_obj.get_resource_usage_trends(hours=hours)
        
        if not trends:
            click.echo("\nNo resource data found.\n")
            return
        
        click.echo(f"\n{'Metric':<20}{'Min':<12}{'Avg':<12}{'Max':<12}")
        click.echo("-" * 60)
        
        # CPU
        click.echo(
            f"{'CPU %':<20}"
            f"{trends.get('cpu_min', 0):>8.1f}    "
            f"{trends.get('cpu_avg', 0):>8.1f}    "
            f"{trends.get('cpu_max', 0):>8.1f}"
        )
        
        # RAM
        click.echo(
            f"{'RAM (MB)':<20}"
            f"{trends.get('ram_min', 0):>8.0f}    "
            f"{trends.get('ram_avg', 0):>8.0f}    "
            f"{trends.get('ram_max', 0):>8.0f}"
        )
        
        # GPU
        if trends.get("gpu_avg", 0) > 0:
            click.echo(
                f"{'GPU %':<20}"
                f"{trends.get('gpu_min', 0):>8.1f}    "
                f"{trends.get('gpu_avg', 0):>8.1f}    "
                f"{trends.get('gpu_max', 0):>8.1f}"
            )
        
        click.echo("=" * 60 + "\n")
        
    except Exception as e:
        click.echo(f"\n❌ Error fetching resource trends: {e}\n", err=True)


@analytics.command()
@click.option("--output", required=True, help="Output file path (JSON)")
def export(output):
    """Export analytics data to JSON."""
    analytics_obj = Analytics()
    
    click.echo(f"\n📤 Exporting analytics to {output}...\n")
    
    try:
        data = analytics_obj.export_data()
        
        output_path = Path(output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_path, "w") as f:
            json.dump(data, f, indent=2)
        
        file_size = output_path.stat().st_size / 1024
        click.echo(f"✅ Exported {file_size:.1f} KB to {output}\n")
        
    except Exception as e:
        click.echo(f"\n❌ Error exporting data: {e}\n", err=True)


@analytics.command()
@click.option("--confirm", is_flag=True, help="Confirm deletion")
def clear(confirm):
    """Clear all analytics data."""
    if not confirm:
        click.echo("\n⚠️  This will delete ALL analytics data.")
        click.echo("Run with --confirm to proceed.\n")
        return
    
    analytics_obj = Analytics()
    
    click.echo("\n🗑️  Clearing all analytics data...\n")
    
    try:
        analytics_obj.clear_all_data()
        click.echo("✅ All analytics data cleared.\n")
        
    except Exception as e:
        click.echo(f"\n❌ Error clearing data: {e}\n", err=True)


if __name__ == "__main__":
    analytics()
