"""
Global variable resolvers for template rendering.

Provides dynamic resolution of template variables like:
- {{rag_vault}} - Interactive RAG search
- {{append_to_note}} - Append content to Obsidian note
"""

from .obsidian_rag import (
    resolve_rag_vault,
    resolve_append_to_note,
    format_rag_context_markdown,
    parse_rag_variable,
)

__all__ = [
    "resolve_rag_vault",
    "resolve_append_to_note",
    "format_rag_context_markdown",
    "parse_rag_variable",
]
