"""
Obsidian RAG global variable resolvers.

Provides {{rag_vault}} and {{append_to_note}} template variables
that enable interactive RAG search workflows during template rendering.
"""

import html
import logging
from typing import List, Dict, Any, Tuple, Optional
from pathlib import Path

logger = logging.getLogger(__name__)

# Constants
DEFAULT_NO_RESULTS_MESSAGE = "No results found."
RAG_SEARCH_TIMEOUT_SECONDS = 10


# ============================================================================
# Task 1.1: Markdown Formatter (GREEN phase - minimal implementation)
# ============================================================================


def format_rag_context_markdown(results: List[Dict[str, Any]]) -> str:
    """
    Convert RAG search results to clean Markdown.
    
    Args:
        results: List of search results from rag_search_notes()
                 Each result should have: title, snippet, score, modified
        
    Returns:
        Formatted Markdown string with numbered results
        
    Example:
        >>> results = [{"title": "Note", "score": 0.9, "snippet": "...", "modified": "2025-10-20"}]
        >>> print(format_rag_context_markdown(results))
        ### 1. Note (Relevance: 90%)
        > ...
        > Last modified: 2025-10-20
    """
    if not results:
        return DEFAULT_NO_RESULTS_MESSAGE
    
    lines = []
    for idx, result in enumerate(results, start=1):
        title = html.escape(result.get("title", "Untitled"))
        score = int(result.get("score", 0) * 100)
        snippet = html.escape(result.get("snippet", ""))
        modified = result.get("modified", "Unknown")
        
        lines.append(f"### {idx}. {title} (Relevance: {score}%)")
        lines.append(f"> {snippet}")
        lines.append(f"> Last modified: {modified}")
        lines.append("")  # Blank line between results
    
    return "\n".join(lines)


# ============================================================================
# Task 1.2: RAG Vault Resolver (GREEN phase - minimal implementation)
# ============================================================================


def _prompt_user_for_query() -> Optional[str]:
    """
    Prompt user for search query using GUI dialog.
    
    Returns:
        User's search query, or None if cancelled
    """
    try:
        import tkinter as tk
        from prompt_automation.gui.obsidian import QueryInputDialog
        
        # Create hidden root window
        root = tk.Tk()
        root.withdraw()
        
        # Show query dialog
        dialog = QueryInputDialog(root)
        root.wait_window(dialog)
        
        # Clean up
        query = dialog.query_text
        root.destroy()
        
        return query if query else None
    except Exception as e:
        logger.error(f"Query dialog failed: {e}")
        return None


def resolve_rag_vault(folders: Optional[List[str]] = None) -> str:
    """
    Resolve {{rag_vault}} template variable with full GUI workflow.
    
    Workflow:
    1. Show folder selector (if folders not pre-selected)
    2. Show query input dialog
    3. Execute RAG search
    4. Show results preview with "Use Results" / "Search Again" / "Cancel"
    5. If "Search Again", go back to step 2
    
    Args:
        folders: Optional folder hints for pre-filtering
        
    Returns:
        Formatted Markdown context from RAG search, or empty string if cancelled
    """
    import tkinter as tk
    from prompt_automation.gui.obsidian import (
        FolderSelectorDialog,
        QueryInputDialog,
        RAGResultsPreview
    )
    from prompt_automation.mcp.server.note_tools import rag_search_notes
    
    try:
        # Create hidden root window (reused for all dialogs)
        root = tk.Tk()
        root.withdraw()
        
        # Step 1: Folder selection (if not pre-selected)
        selected_folders = folders
        if selected_folders is None:
            # Try to detect vault root from environment or config
            vault_root = None
            
            # Option 1: From environment variable
            import os
            vault_root_env = os.environ.get("OBSIDIAN_VAULT_PATH")
            if vault_root_env:
                vault_root = Path(vault_root_env)
            
            # Option 2: From config file (if available)
            if vault_root is None:
                try:
                    from prompt_automation.platform_utils import get_app_home
                    config_file = get_app_home() / "config.json"
                    if config_file.exists():
                        import json
                        config = json.loads(config_file.read_text())
                        vault_root_str = config.get("obsidian", {}).get("vault_path")
                        if vault_root_str:
                            vault_root = Path(vault_root_str)
                except:
                    pass  # Config not available
            
            # If vault root not found, return error
            if vault_root is None or not vault_root.exists():
                logger.error(f"No Obsidian vault configured (tried: {vault_root})")
                root.destroy()
                return "Error: No Obsidian vault configured. Set OBSIDIAN_VAULT_PATH or config.json"
            
            folder_dialog = FolderSelectorDialog(root, vault_root)
            root.wait_window(folder_dialog)
            
            if folder_dialog.result is False:  # User cancelled
                root.destroy()
                return ""
            
            selected_folders = list(folder_dialog.selected_folders)
        
        # Step 2-5: Query → Search → Preview loop
        while True:
            # Step 2: Query input
            query_dialog = QueryInputDialog(root)
            root.wait_window(query_dialog)
            
            if query_dialog.result is False:  # User cancelled
                root.destroy()
                return ""
            
            query = query_dialog.query_text
            
            # Step 3: Execute RAG search
            try:
                results = rag_search_notes(query=query, folders=selected_folders)
            except TimeoutError as e:
                logger.error(f"RAG search timeout: {e}")
                root.destroy()
                return f"Error: Search timeout - {str(e)}"
            except Exception as e:
                logger.error(f"RAG search failed: {e}")
                root.destroy()
                return f"Error: RAG search failed - {str(e)}"
            
            # Step 4: Results preview
            preview_dialog = RAGResultsPreview(root, results, query)
            root.wait_window(preview_dialog)
            
            # Step 5: Handle user choice
            if preview_dialog.result == "use":
                markdown_context = preview_dialog.get_formatted_context()
                root.destroy()
                return markdown_context
            elif preview_dialog.result == "search_again":
                continue  # Loop back to step 2
            else:  # cancel
                root.destroy()
                return ""
    
    except Exception as e:
        logger.error(f"RAG vault workflow failed: {e}")
        try:
            root.destroy()
        except:
            pass
        return f"Error: Workflow failed - {str(e)}"


# ============================================================================
# Task 2.1: Append to Note Resolver (GREEN phase - minimal implementation)
# ============================================================================


def _prompt_user_for_note() -> Optional[Path]:
    """
    Prompt user to select note file (GUI or CLI).
    
    Returns:
        Path to selected note, or None if cancelled
    """
    # TODO: Implement file picker dialog (Task 4.2)
    raise NotImplementedError("File picker not yet implemented")


def _append_to_note_atomic(note_path: Path, content: str) -> None:
    """
    Atomically append content to note using tmp file pattern.
    
    Args:
        note_path: Path to note file
        content: Content to append
        
    Raises:
        PermissionError: If file is locked or not writable
    """
    # Read current content
    current = note_path.read_text()
    
    # Ensure current content ends with newline, then add blank line + new content
    if not current.endswith("\n"):
        new_content = f"{current}\n\n{content}"
    else:
        new_content = f"{current}\n{content}"
    
    # Write to temp file
    tmp_path = note_path.with_suffix(".tmp")
    tmp_path.write_text(new_content)
    
    # Atomic rename (replaces original)
    tmp_path.replace(note_path)


def resolve_append_to_note(content: str) -> str:
    """
    Resolve {{append_to_note}} template variable.
    
    Prompts user for note file, appends content atomically, returns confirmation.
    
    Args:
        content: Content to append to selected note
        
    Returns:
        Confirmation message, or empty string if cancelled
    """
    # Prompt user for note file
    try:
        note_path = _prompt_user_for_note()
    except NotImplementedError:
        # Dialog not implemented yet, mock for tests
        note_path = None
    
    if note_path is None:  # User cancelled
        return ""
    
    # Append content atomically
    try:
        _append_to_note_atomic(note_path, content)
    except PermissionError as e:
        logger.error(f"File locked: {e}")
        return f"Error: File locked - {str(e)}"
    except Exception as e:
        logger.error(f"Failed to append: {e}")
        return f"Error: Failed to append - {str(e)}"
    
    line_count = len(content.splitlines())
    return f"Appended {line_count} lines to {note_path.name}"


# ============================================================================
# Task 1.3: Variable Parsing (GREEN phase - minimal implementation)
# ============================================================================


def parse_rag_variable(variable_text: str) -> Tuple[str, List[str]]:
    """
    Extract variable name and folder hints from template variable.
    
    Args:
        variable_text: Variable text without {{ }}, e.g., "rag_vault:Projects,Docs"
        
    Returns:
        Tuple of (variable_name, folder_list)
        
    Examples:
        >>> parse_rag_variable("rag_vault")
        ("rag_vault", [])
        
        >>> parse_rag_variable("rag_vault:Projects")
        ("rag_vault", ["Projects"])
        
        >>> parse_rag_variable("rag_vault:Projects,Docs")
        ("rag_vault", ["Projects", "Docs"])
    """
    if ":" not in variable_text:
        return (variable_text, [])
    
    var_name, folders_raw = variable_text.split(":", 1)
    folders = [f.strip() for f in folders_raw.split(",")]
    return (var_name, folders)
