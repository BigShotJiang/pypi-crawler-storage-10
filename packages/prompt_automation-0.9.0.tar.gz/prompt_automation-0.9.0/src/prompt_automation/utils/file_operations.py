"""
Atomic file operations for safe writes.

Provides atomic write operations to prevent data corruption during file writes.
Uses POSIX atomic rename pattern: tmp file → backup → rename.
"""

import os
import shutil
import time
from pathlib import Path
from typing import Optional
import logging

logger = logging.getLogger(__name__)

# Constants
TMP_SUFFIX = ".tmp"
BACKUP_SUFFIX = ".bak"
BACKUP_RETENTION_HOURS = 1
DEFAULT_BACKUP_MAX_AGE_DAYS = 7


def atomic_write(target_path: Path, content: str) -> None:
    """
    Write content atomically to prevent corruption.
    
    Uses POSIX atomic rename pattern:
    1. Write to temporary file
    2. Create backup of existing file (if present)
    3. Atomic rename (replaces target)
    4. Verify content matches
    
    Args:
        target_path: Path to target file
        content: Content to write
        
    Raises:
        OSError: If write fails
        AssertionError: If content verification fails
    """
    # Ensure parent directory exists
    target_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Step 1: Write to temp file
    tmp_path = target_path.with_suffix(target_path.suffix + TMP_SUFFIX)
    tmp_path.write_text(content)
    
    # Step 2: Backup existing file if present
    if target_path.exists():
        backup_path = target_path.with_suffix(target_path.suffix + BACKUP_SUFFIX)
        shutil.copy2(target_path, backup_path)
        logger.info(f"Created backup: {backup_path}")
    
    # Step 3: Atomic rename (replaces target)
    tmp_path.replace(target_path)
    
    # Step 4: Verify content matches
    actual = target_path.read_text()
    if actual != content:
        raise AssertionError(
            f"Write verification failed: expected {len(content)} chars, got {len(actual)}"
        )
    
    logger.info(f"Atomic write complete: {target_path}")


def create_backup(file_path: Path) -> Path:
    """
    Create backup copy of file with metadata preservation.
    
    Reuses existing backup if less than BACKUP_RETENTION_HOURS old
    to avoid unnecessary I/O.
    
    Args:
        file_path: Path to file to backup
        
    Returns:
        Path to backup file
    """
    backup_path = file_path.with_suffix(file_path.suffix + BACKUP_SUFFIX)
    
    # Skip if backup is recent (< BACKUP_RETENTION_HOURS old)
    if backup_path.exists():
        age_hours = (time.time() - backup_path.stat().st_mtime) / 3600
        if age_hours < BACKUP_RETENTION_HOURS:
            logger.debug(f"Reusing recent backup: {backup_path} ({age_hours:.1f}h old)")
            return backup_path  # Reuse existing
    
    # Copy with metadata (permissions, timestamps)
    shutil.copy2(file_path, backup_path)
    logger.info(f"Created backup: {backup_path}")
    
    return backup_path


def cleanup_old_backups(directory: Path, max_age_days: int = DEFAULT_BACKUP_MAX_AGE_DAYS) -> int:
    """
    Delete backup files older than max_age_days.
    
    Recursively scans directory for .bak files and removes those
    exceeding the age threshold.
    
    Args:
        directory: Directory to scan for .bak files
        max_age_days: Maximum age in days (default: 7)
        
    Returns:
        Number of files deleted
    """
    deleted_count = 0
    max_age_seconds = max_age_days * 24 * 3600
    now = time.time()
    
    for backup_file in directory.rglob(f"**/*{BACKUP_SUFFIX}"):
        try:
            age_seconds = now - backup_file.stat().st_mtime
            
            if age_seconds > max_age_seconds:
                backup_file.unlink()
                deleted_count += 1
                logger.info(f"Deleted old backup: {backup_file} ({age_seconds / 86400:.1f} days old)")
        except (OSError, PermissionError) as e:
            logger.warning(f"Failed to delete {backup_file}: {e}")
            continue
    
    if deleted_count > 0:
        logger.info(f"Cleaned up {deleted_count} old backups from {directory}")
    
    return deleted_count
