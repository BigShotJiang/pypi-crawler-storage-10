"""RAG engine for semantic search over Obsidian notes (Feature 23.2)."""

from typing import List, Dict, Any, Optional
from pathlib import Path
from datetime import datetime
import json
import requests

from ..errorlog import get_logger

_log = get_logger(__name__)


class RAGEngine:
    """Hybrid RAG search engine: keyword filter → snippet extract → LLM rerank."""
    
    def __init__(self):
        """Initialize RAG engine."""
        pass
    
    def search(
        self,
        query: str,
        folders: Optional[List[str]] = None,
        max_results: int = 10,
        vault_reference: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Execute full 3-phase RAG search.
        
        Args:
            query: Natural language search query
            folders: Optional list of folder paths to search within
            max_results: Maximum number of results to return
            vault_reference: Vault reference file path (required for search_notes)
            
        Returns:
            List of results with path, snippet, score
        """
        # Phase 1: Keyword filtering (fast, returns ~100 candidates)
        candidates = self._keyword_filter(
            query=query,
            folders=folders,
            max_candidates=max(100, max_results * 10),
            vault_reference=vault_reference
        )
        
        if not candidates:
            _log.info("No candidates from keyword filter")
            return []
        
        # Phase 2: Extract snippets with context
        snippets = self._extract_snippets(
            candidates=candidates,
            query=query,
            snippet_size=500
        )
        
        if not snippets:
            _log.info("No snippets extracted")
            return []
        
        # Phase 3: LLM reranking for semantic relevance
        scored_results = self._llm_rerank(
            query=query,
            snippets=snippets[:max_results * 2],  # Limit LLM input
            timeout=5.0,
            max_retries=2
        )
        
        # Return top results
        return scored_results[:max_results]
    
    def _extract_keywords(self, query: str) -> List[str]:
        """Extract keywords from query (simple implementation)."""
        # Remove common stop words
        stop_words = {"the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for"}
        words = query.lower().split()
        return [w for w in words if w not in stop_words and len(w) > 2]
    
    def _keyword_filter(
        self, 
        query: str, 
        folders: Optional[List[str]], 
        max_candidates: int = 100,
        vault_reference: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Phase 1: Fast keyword filtering using existing search."""
        from ..mcp.server import note_tools
        
        keywords = self._extract_keywords(query)
        search_query = " ".join(keywords) if keywords else query
        
        _log.info(f"RAG keyword filter: query={search_query}, folders={folders}, max={max_candidates}")
        
        search_args: Dict[str, Any] = {
            "query": search_query,
            "max_results": max_candidates
        }
        
        if folders:
            search_args["folders"] = folders
        
        # Add vault context if provided (required for note_tools.search_notes)
        if vault_reference:
            search_args["vault"] = {"reference_file": vault_reference}
        
        result = note_tools.search_notes(search_args)
        candidates = result.get("matches", [])
        
        _log.debug(f"Keyword filter found {len(candidates)} candidates")
        return candidates
    
    def _format_snippet(self, content: str, match_pos: int, size: int) -> str:
        """Format snippet with ellipsis if truncated."""
        # Reserve space for ellipsis (6 chars: "..." at start + "..." at end)
        effective_size = size - 6
        start = max(0, match_pos - effective_size // 2)
        end = min(len(content), match_pos + effective_size // 2)
        
        snippet = content[start:end]
        
        # Add ellipsis if truncated
        if start > 0:
            snippet = "..." + snippet
        if end < len(content):
            snippet = snippet + "..."
        
        return snippet.strip()
    
    def _extract_snippets(
        self, 
        candidates: List[Dict[str, Any]], 
        query: str,
        snippet_size: int = 500
    ) -> List[Dict[str, Any]]:
        """Phase 2: Extract contextual snippets from candidates."""
        snippets = []
        keywords = self._extract_keywords(query)
        
        for candidate in candidates:
            path = Path(candidate["absolute_path"])
            
            try:
                content = path.read_text(encoding="utf-8")
            except Exception as e:
                _log.warning(f"Failed to read {path}: {e}")
                continue
            
            # Find first keyword match
            match_pos = 0
            for keyword in keywords:
                pos = content.lower().find(keyword.lower())
                if pos != -1:
                    match_pos = pos
                    break
            
            snippet_text = self._format_snippet(content, match_pos, snippet_size)
            
            snippets.append({
                "path": candidate["path"],
                "snippet": snippet_text,
                "title": path.stem,
                "modified": datetime.fromtimestamp(path.stat().st_mtime).isoformat()
            })
        
        _log.debug(f"Extracted {len(snippets)} snippets")
        return snippets
    
    def _build_rerank_prompt(self, query: str, snippets: List[Dict[str, Any]]) -> str:
        """Build prompt for Qwen to rerank snippets."""
        snippet_text = "\n\n".join([
            f"{i+1}. {s['title']} ({s['path']})\n{s['snippet']}"
            for i, s in enumerate(snippets)
        ])
        
        return f"""Rank these note snippets by relevance to the query: "{query}"

Return JSON array with path and score (0.0-1.0):
[{{"path": "note.md", "score": 0.95}}, ...]

Snippets:
{snippet_text}
"""
    
    def _llm_rerank(
        self, 
        query: str, 
        snippets: List[Dict[str, Any]],
        timeout: float = 5.0,
        max_retries: int = 2
    ) -> List[Dict[str, Any]]:
        """Phase 3: Use Qwen to rerank snippets by relevance."""
        prompt = self._build_rerank_prompt(query, snippets)
        
        payload = {
            "model": "qwen",
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.3
        }
        
        for attempt in range(max_retries):
            try:
                response = requests.post(
                    "http://127.0.0.1:8080/v1/chat/completions",
                    json=payload,
                    timeout=timeout
                )
                
                result = response.json()
                
                if "error" in result:
                    _log.warning(f"LLM error: {result['error']}")
                    # Mark snippets with error and return
                    for snippet in snippets:
                        snippet["llm_error"] = result["error"]
                    return snippets
                
                # Parse scores from response
                content = result["choices"][0]["message"]["content"]
                scores = json.loads(content)
                
                # Merge scores with snippets
                scored_snippets = []
                for snippet in snippets:
                    score_entry = next((s for s in scores if s["path"] == snippet["path"]), None)
                    if score_entry:
                        snippet["score"] = score_entry["score"]
                        scored_snippets.append(snippet)
                
                # Sort by score descending
                scored_snippets.sort(key=lambda x: x.get("score", 0), reverse=True)
                
                _log.info(f"LLM rerank successful: {len(scored_snippets)} results")
                return scored_snippets
                
            except (requests.Timeout, requests.ConnectionError) as e:
                _log.warning(f"LLM rerank attempt {attempt+1}/{max_retries} failed: {e}")
                if attempt == max_retries - 1:
                    # Final fallback: return original snippets with warning
                    for snippet in snippets:
                        snippet["llm_error"] = str(e)
                    return snippets
        
        return snippets
