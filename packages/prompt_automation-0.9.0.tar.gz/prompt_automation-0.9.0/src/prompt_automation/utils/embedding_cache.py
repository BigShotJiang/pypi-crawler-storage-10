"""Embedding cache for RAG search results (Feature 23.2)."""

from typing import Any, Dict, List, Optional
from pathlib import Path
import json
import hashlib
import time

from ..errorlog import get_logger

_log = get_logger(__name__)


class EmbeddingCache:
    """LRU cache for RAG search results with file modification detection."""
    
    def __init__(self, cache_file: Path, max_entries: int = 1000):
        """Initialize cache.
        
        Args:
            cache_file: Path to JSON cache file
            max_entries: Maximum cache entries before LRU eviction
        """
        self.cache_file = Path(cache_file)
        self.max_entries = max_entries
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._access_times: Dict[str, float] = {}
        self._file_dependencies: Dict[str, List[str]] = {}  # key -> list of file paths
        self._load_cache()
    
    def _load_cache(self) -> None:
        """Load cache from disk."""
        if not self.cache_file.exists():
            _log.debug(f"Cache file not found: {self.cache_file}")
            return
        
        try:
            data = json.loads(self.cache_file.read_text(encoding="utf-8"))
            self._cache = data.get("entries", {})
            self._access_times = data.get("access_times", {})
            self._file_dependencies = data.get("file_dependencies", {})
            _log.info(f"Loaded {len(self._cache)} cache entries from {self.cache_file}")
        except (json.JSONDecodeError, Exception) as e:
            _log.warning(f"Failed to load cache (starting fresh): {e}")
            self._cache = {}
            self._access_times = {}
            self._file_dependencies = {}
    
    def _save_cache(self) -> None:
        """Save cache to disk."""
        try:
            self.cache_file.parent.mkdir(parents=True, exist_ok=True)
            
            data = {
                "entries": self._cache,
                "access_times": self._access_times,
                "file_dependencies": self._file_dependencies
            }
            
            self.cache_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
            _log.debug(f"Saved {len(self._cache)} cache entries to {self.cache_file}")
        except Exception as e:
            _log.error(f"Failed to save cache: {e}")
    
    def _evict_lru(self) -> None:
        """Evict least recently used entry if cache is full."""
        if len(self._cache) < self.max_entries:
            return
        
        # Find LRU entry
        lru_key = min(self._access_times, key=self._access_times.get)
        
        _log.debug(f"Evicting LRU entry: {lru_key}")
        del self._cache[lru_key]
        del self._access_times[lru_key]
        if lru_key in self._file_dependencies:
            del self._file_dependencies[lru_key]
    
    def get(self, key: str) -> Optional[Dict[str, Any]]:
        """Get value from cache.
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None if not found
        """
        if key not in self._cache:
            _log.debug(f"Cache miss: {key[:32]}...")
            return None
        
        # Update access time
        self._access_times[key] = time.time()
        
        _log.debug(f"Cache hit: {key[:32]}...")
        return self._cache[key]
    
    def set(self, key: str, value: Dict[str, Any], files: Optional[List[Path]] = None) -> None:
        """Set value in cache.
        
        Args:
            key: Cache key
            value: Value to cache
            files: Optional list of files this entry depends on
        """
        # Evict if necessary
        self._evict_lru()
        
        self._cache[key] = value
        self._access_times[key] = time.time()
        
        # Track file dependencies
        if files:
            self._file_dependencies[key] = [str(f) for f in files]
        
        _log.debug(f"Cache set: {key[:32]}... ({len(self._cache)} entries)")
        
        # Persist to disk
        self._save_cache()
    
    def invalidate(self, key: str) -> None:
        """Invalidate cache entry.
        
        Args:
            key: Cache key to invalidate
        """
        if key in self._cache:
            del self._cache[key]
            del self._access_times[key]
            if key in self._file_dependencies:
                del self._file_dependencies[key]
            self._save_cache()
            _log.debug(f"Invalidated cache entry: {key[:32]}...")
    
    def invalidate_by_file(self, file_path: Path) -> None:
        """Invalidate all cache entries that reference a file.
        
        Args:
            file_path: Path to file that changed
        """
        file_str = str(file_path)
        keys_to_invalidate = []
        
        # Find all keys that reference this file
        for key, file_deps in self._file_dependencies.items():
            if file_str in file_deps:
                keys_to_invalidate.append(key)
        
        for key in keys_to_invalidate:
            self.invalidate(key)
        
        if keys_to_invalidate:
            _log.info(f"Invalidated {len(keys_to_invalidate)} entries for {file_path}")
    
    def generate_key(self, query: str, files: List[Path]) -> str:
        """Generate cache key from query and file list.
        
        Args:
            query: Search query
            files: List of file paths
            
        Returns:
            SHA256 hash as cache key
        """
        # Sort files for consistent ordering
        file_paths = sorted([str(f) for f in files])
        
        # Compute hash of each file's content
        file_hashes = []
        for file_path in file_paths:
            try:
                path = Path(file_path)
                content = path.read_bytes()
                file_hash = hashlib.sha256(content).hexdigest()[:16]
                file_hashes.append(f"{path.name}:{file_hash}")
            except Exception as e:
                _log.warning(f"Failed to hash {file_path}: {e}")
                # Use mtime as fallback
                try:
                    mtime = Path(file_path).stat().st_mtime
                    file_hashes.append(f"{Path(file_path).name}:{int(mtime)}")
                except Exception:
                    continue
        
        # Combine query + file hashes
        key_input = f"{query}|{'|'.join(file_hashes)}"
        cache_key = hashlib.sha256(key_input.encode()).hexdigest()
        
        return cache_key
    
    def clear(self) -> None:
        """Clear all cache entries."""
        self._cache.clear()
        self._access_times.clear()
        self._save_cache()
        _log.info("Cache cleared")
