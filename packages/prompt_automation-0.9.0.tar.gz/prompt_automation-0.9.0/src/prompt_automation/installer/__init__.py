"""Installation detection and management.

This module provides utilities for detecting how prompt-automation was installed
and routing update/uninstall operations accordingly.
"""

from .detector import InstallMethod, InstallMetadata, detect_install_method

__all__ = ["InstallMethod", "InstallMetadata", "detect_install_method"]
