"""Installation method detection for routing updates and uninstalls.

Detects how prompt-automation was installed (pipx, pip, editable, installer)
by analyzing importlib.metadata, file paths, and direct_url.json.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
import json
import sys
from typing import Optional

try:
    from importlib.metadata import distribution, PackageNotFoundError
except ImportError:  # Python < 3.8
    from importlib_metadata import distribution, PackageNotFoundError  # type: ignore


class InstallMethod(Enum):
    """Installation method for prompt-automation."""
    
    PIPX = "pipx"                # pipx install prompt-automation
    PIP_USER = "pip_user"        # pip install --user prompt-automation
    PIP_GLOBAL = "pip_global"    # pip install prompt-automation (system)
    EDITABLE = "editable"        # pip install -e . (development)
    INSTALLER = "installer"      # Manual .exe/.dmg/.deb installer
    UNKNOWN = "unknown"          # Could not determine


@dataclass
class InstallMetadata:
    """Metadata about current installation."""
    
    method: InstallMethod
    location: Path
    version: str
    is_healthy: bool
    direct_url: Optional[dict] = None
    
    def __str__(self) -> str:
        health = "healthy" if self.is_healthy else "unhealthy"
        return f"{self.method.value} v{self.version} at {self.location} ({health})"


def detect_install_method() -> InstallMetadata:
    """Detect how prompt-automation was installed.
    
    Returns:
        InstallMetadata with method, location, version, and health status
        
    Examples:
        >>> meta = detect_install_method()
        >>> if meta.method == InstallMethod.PIPX:
        ...     print("Installed via pipx, can use 'pipx upgrade'")
        >>> elif meta.method == InstallMethod.EDITABLE:
        ...     print("Development install, pull git changes")
    """
    try:
        dist = distribution("prompt-automation")
        version = dist.version
        location = Path(dist.locate_file(""))
        
        # Check for editable install via direct_url.json
        direct_url = _get_direct_url(dist)
        if direct_url and direct_url.get("dir_info"):
            return InstallMetadata(
                method=InstallMethod.EDITABLE,
                location=location,
                version=version,
                is_healthy=_check_editable_health(location),
                direct_url=direct_url
            )
        
        # Check for pipx install (location contains 'pipx')
        if "pipx" in str(location).lower():
            return InstallMetadata(
                method=InstallMethod.PIPX,
                location=location,
                version=version,
                is_healthy=_check_pipx_health(),
                direct_url=direct_url
            )
        
        # Check for manual installer (platform-specific paths)
        if _is_installer_location(location):
            return InstallMetadata(
                method=InstallMethod.INSTALLER,
                location=location,
                version=version,
                is_healthy=True,  # If we can import it, it's healthy
                direct_url=direct_url
            )
        
        # Check for user vs global pip install
        if _is_user_install(location):
            return InstallMetadata(
                method=InstallMethod.PIP_USER,
                location=location,
                version=version,
                is_healthy=True,
                direct_url=direct_url
            )
        else:
            return InstallMetadata(
                method=InstallMethod.PIP_GLOBAL,
                location=location,
                version=version,
                is_healthy=True,
                direct_url=direct_url
            )
            
    except PackageNotFoundError:
        # Package not installed (shouldn't happen if we're running from it)
        return InstallMetadata(
            method=InstallMethod.UNKNOWN,
            location=Path.cwd(),
            version="0.0.0",
            is_healthy=False
        )
    except Exception:
        # Unexpected error during detection
        return InstallMetadata(
            method=InstallMethod.UNKNOWN,
            location=Path.cwd(),
            version="0.0.0",
            is_healthy=False
        )


def _get_direct_url(dist) -> Optional[dict]:
    """Extract direct_url.json from distribution if available."""
    try:
        direct_url_text = dist.read_text("direct_url.json")
        if direct_url_text:
            return json.loads(direct_url_text)
    except Exception:
        pass
    return None


def _check_editable_health(location: Path) -> bool:
    """Check if editable install is healthy (source directory exists)."""
    # For editable installs, location points to site-packages
    # Source is in direct_url, but we can check if basic imports work
    try:
        import prompt_automation
        return True
    except ImportError:
        return False


def _check_pipx_health() -> bool:
    """Check if pipx is available and functional."""
    from shutil import which
    return which("pipx") is not None


def _is_installer_location(location: Path) -> bool:
    """Check if location suggests manual installer (platform-specific)."""
    location_str = str(location).lower()
    
    # macOS: /Applications/prompt-automation.app/...
    if sys.platform == "darwin" and ".app" in location_str:
        return True
    
    # Windows: C:\Program Files\prompt-automation\...
    if sys.platform == "win32" and "program files" in location_str:
        return True
    
    # Linux: /opt/prompt-automation/... or /usr/local/prompt-automation/...
    if sys.platform.startswith("linux"):
        if location.is_relative_to(Path("/opt")) or \
           (location.is_relative_to(Path("/usr/local")) and "prompt-automation" in location_str):
            return True
    
    return False


def _is_user_install(location: Path) -> bool:
    """Check if installation is in user site-packages."""
    try:
        # User site-packages is under home directory
        # e.g., ~/.local/lib/python3.12/site-packages
        return location.is_relative_to(Path.home())
    except (ValueError, TypeError):
        return False
