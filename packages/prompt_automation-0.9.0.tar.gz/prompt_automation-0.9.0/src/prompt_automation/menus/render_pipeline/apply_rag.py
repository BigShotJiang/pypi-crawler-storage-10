"""
RAG metadata extraction for render pipeline.

Extracts folder hints from template metadata to pre-populate
folder selection in RAG vault searches.
"""

import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


def _folder_exists(folder: str) -> bool:
    """
    Check if folder exists in Obsidian vault.
    
    Args:
        folder: Folder path relative to vault root
        
    Returns:
        True if folder exists, False otherwise
        
    Note:
        This is a placeholder implementation. In production, this should:
        1. Get vault root from MCP connection
        2. Check if vault_root / folder exists
        3. Return validation result
        
        For now, we assume all folders are valid to avoid MCP dependency.
    """
    # TODO: Implement actual folder validation via MCP
    # For now, accept all folders (tests will mock this)
    return True


def extract_rag_metadata(template: Dict[str, Any]) -> List[str]:
    """
    Extract RAG folder hints from template metadata.
    
    Reads metadata.rag_folders and validates each folder exists in vault.
    
    Args:
        template: Template dictionary with optional metadata
        
    Returns:
        List of validated folder paths
        
    Example:
        >>> template = {
        ...     "metadata": {
        ...         "rag_folders": ["Projects", "Docs"]
        ...     }
        ... }
        >>> extract_rag_metadata(template)
        ['Projects', 'Docs']
    """
    metadata = template.get("metadata", {})
    folders = metadata.get("rag_folders", [])
    
    if not folders:
        return []
    
    # Validate folders exist
    valid_folders = []
    for folder in folders:
        if _folder_exists(folder):
            valid_folders.append(folder)
        else:
            logger.warning(f"Skipping invalid folder in metadata: {folder}")
    
    return valid_folders
