"""Throttler - Resource-based throttling for performance management.

This module provides Throttler for dynamically adjusting system behavior based
on resource usage metrics from ResourceMonitor.

Key Features:
- **Dynamic Throttling**: Adjusts concurrency/batch size based on CPU/RAM/VRAM usage
- **Configurable Thresholds**: Custom thresholds for each resource type
- **Hysteresis**: Prevents rapid oscillation between throttle states
- **Action Recommendation**: Suggests specific throttle actions (reduce_concurrency, reduce_batch_size, fallback_cpu)

Example:
    >>> from prompt_automation.performance.throttler import Throttler
    >>> from prompt_automation.performance.resource_monitor import ResourceMonitor
    >>>
    >>> resource_monitor = ResourceMonitor()
    >>> resource_monitor.start()
    >>>
    >>> throttler = Throttler(
    ...     resource_monitor=resource_monitor,
    ...     thresholds={"cpu": 90.0, "ram": 90.0, "vram": 90.0},
    ...     hysteresis=5.0
    ... )
    >>>
    >>> if throttler.should_throttle():
    ...     action = throttler.get_throttle_action()
    ...     print(f"Throttling: {action}")

Throttle Actions:
    - **reduce_concurrency**: Lower max_concurrent workers (high CPU)
    - **reduce_batch_size**: Smaller batches (high RAM)
    - **fallback_cpu**: Switch from GPU to CPU (high VRAM)
    - **none**: No throttling needed
"""

from typing import Dict, Optional
import logging

logger = logging.getLogger(__name__)


class Throttler:
    """Resource-based throttler for dynamic performance management.
    
    Monitors resource usage via ResourceMonitor and recommends throttle actions
    when thresholds are exceeded. Uses hysteresis to prevent oscillation.
    
    Throttle Logic:
        - CPU > threshold → reduce_concurrency
        - RAM > threshold → reduce_batch_size
        - VRAM > threshold → fallback_cpu
    
    Hysteresis:
        Once throttling starts, resources must drop to (threshold - hysteresis)
        before throttling stops. Prevents rapid on/off toggling.
    
    Thread Safety:
        Thread-safe (uses ResourceMonitor which is thread-safe).
    """
    
    def __init__(
        self,
        resource_monitor,
        thresholds: Optional[Dict[str, float]] = None,
        hysteresis: float = 5.0
    ):
        """Initialize throttler.
        
        Args:
            resource_monitor: ResourceMonitor instance for metrics.
            thresholds: Dict with keys 'cpu', 'ram', 'vram' (percentages, 0-100).
                Default: {"cpu": 90.0, "ram": 90.0, "vram": 90.0}
            hysteresis: Percentage buffer to prevent oscillation (default: 5.0).
                Example: If threshold=90% and hysteresis=5%, throttling stops at 85%.
        
        Raises:
            ValueError: If hysteresis < 0 or > 50
        """
        if hysteresis < 0 or hysteresis > 50:
            raise ValueError("hysteresis must be between 0 and 50")
        
        self.resource_monitor = resource_monitor
        self.thresholds = thresholds or {
            "cpu": 90.0,
            "ram": 90.0,
            "vram": 90.0
        }
        self.hysteresis = hysteresis
        
        # Throttle state (for hysteresis)
        self._is_throttling = False
        
        logger.info(
            f"Throttler initialized: thresholds={self.thresholds}, "
            f"hysteresis={hysteresis}%"
        )
    
    def should_throttle(self) -> bool:
        """Check if throttling is needed based on current metrics.
        
        Uses hysteresis: Once throttling, requires resources to drop below
        (threshold - hysteresis) before stopping.
        
        Returns:
            True if throttling should be active, False otherwise
        """
        metrics = self.resource_monitor.get_metrics()
        
        # Determine effective thresholds based on current state
        if self._is_throttling:
            # Apply hysteresis: lower threshold to stop throttling
            effective_thresholds = {
                key: value - self.hysteresis
                for key, value in self.thresholds.items()
            }
        else:
            # Use normal thresholds to start throttling
            effective_thresholds = self.thresholds
        
        # Check each resource
        cpu_high = metrics.get("cpu_percent", 0.0) > effective_thresholds.get("cpu", 100.0)
        ram_high = metrics.get("ram_percent", 0.0) > effective_thresholds.get("ram", 100.0)
        vram_high = metrics.get("vram_percent", 0.0) > effective_thresholds.get("vram", 100.0)
        
        should_throttle = cpu_high or ram_high or vram_high
        
        # Update state
        if should_throttle != self._is_throttling:
            if should_throttle:
                logger.warning(
                    f"Throttling activated: CPU={metrics.get('cpu_percent', 0):.1f}%, "
                    f"RAM={metrics.get('ram_percent', 0):.1f}%, "
                    f"VRAM={metrics.get('vram_percent', 0):.1f}%"
                )
            else:
                logger.info("Throttling deactivated: Resources returned to normal")
        
        self._is_throttling = should_throttle
        return should_throttle
    
    def get_throttle_action(self) -> str:
        """Get recommended throttle action based on current metrics.
        
        Priority order (if multiple thresholds exceeded):
        1. VRAM → fallback_cpu (most critical)
        2. CPU → reduce_concurrency
        3. RAM → reduce_batch_size
        
        Returns:
            Action string: "reduce_concurrency", "reduce_batch_size", 
                          "fallback_cpu", or "none"
        """
        metrics = self.resource_monitor.get_metrics()
        
        # Check thresholds
        cpu_high = metrics.get("cpu_percent", 0.0) > self.thresholds.get("cpu", 100.0)
        ram_high = metrics.get("ram_percent", 0.0) > self.thresholds.get("ram", 100.0)
        vram_high = metrics.get("vram_percent", 0.0) > self.thresholds.get("vram", 100.0)
        
        # Priority: VRAM > CPU > RAM
        if vram_high:
            logger.warning(
                f"VRAM threshold exceeded: {metrics.get('vram_percent', 0):.1f}% "
                f"(threshold: {self.thresholds.get('vram', 90)}%)"
            )
            return "fallback_cpu"
        elif cpu_high:
            logger.warning(
                f"CPU threshold exceeded: {metrics.get('cpu_percent', 0):.1f}% "
                f"(threshold: {self.thresholds.get('cpu', 90)}%)"
            )
            return "reduce_concurrency"
        elif ram_high:
            logger.warning(
                f"RAM threshold exceeded: {metrics.get('ram_percent', 0):.1f}% "
                f"(threshold: {self.thresholds.get('ram', 90)}%)"
            )
            return "reduce_batch_size"
        else:
            return "none"
    
    def get_metrics(self) -> Dict[str, float]:
        """Get current resource metrics from ResourceMonitor.
        
        Convenience method for direct metrics access.
        
        Returns:
            Dict with keys: cpu_percent, ram_percent, gpu_percent, vram_percent
        """
        return self.resource_monitor.get_metrics()
