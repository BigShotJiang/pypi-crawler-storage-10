"""Device Manager - GPU detection and VRAM monitoring."""

from typing import Optional
import logging

logger = logging.getLogger(__name__)


class DeviceManager:
    """Detect and manage GPU/CPU devices for inference."""
    
    def __init__(self):
        """Initialize and run GPU detection."""
        self._gpu_available: bool = False
        self._gpu_type: Optional[str] = None  # "cuda", "rocm", "mps", None
        self._device_string: str = "cpu"
        self._gpu_name: Optional[str] = None
        self._pynvml_handle = None  # Cache handle for VRAM monitoring
        self._detect_gpu()
        
        # Initialize pynvml if NVIDIA GPU detected
        if self._gpu_type == "cuda":
            self._init_pynvml()
    
    def _detect_gpu(self):
        """Run GPU detection fallback chain: CUDA → ROCm → MPS → CPU."""
        # Try CUDA
        if self._detect_cuda():
            return
        
        # Try ROCm
        if self._detect_rocm():
            return
        
        # Try MPS
        if self._detect_mps():
            return
        
        # Fallback to CPU
        self._gpu_available = False
        self._gpu_type = None
        self._device_string = "cpu"
        logger.info("No GPU detected, using CPU")
    
    def _detect_cuda(self) -> bool:
        """Try CUDA detection.
        
        Returns:
            True if CUDA GPU detected, False otherwise
        """
        try:
            import torch
            if torch.cuda.is_available():
                self._gpu_available = True
                self._gpu_type = "cuda"
                self._device_string = "cuda:0"
                self._gpu_name = torch.cuda.get_device_name(0)
                logger.info(f"CUDA GPU detected: {self._gpu_name}")
                return True
        except ImportError:
            logger.debug("torch not available, cannot detect CUDA")
        except Exception as e:
            logger.warning(f"CUDA detection failed: {e}")
        return False
    
    def _detect_rocm(self) -> bool:
        """Try ROCm detection (AMD GPUs).
        
        Returns:
            True if ROCm GPU detected, False otherwise
        """
        try:
            import torch
            if hasattr(torch, 'hip') and torch.hip.is_available():
                self._gpu_available = True
                self._gpu_type = "rocm"
                self._device_string = "rocm:0"
                logger.info("ROCm GPU detected")
                return True
        except (ImportError, AttributeError):
            logger.debug("ROCm not available")
        except Exception as e:
            logger.warning(f"ROCm detection failed: {e}")
        return False
    
    def _detect_mps(self) -> bool:
        """Try MPS detection (Apple Silicon).
        
        Returns:
            True if MPS GPU detected, False otherwise
        """
        try:
            import torch
            if hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
                self._gpu_available = True
                self._gpu_type = "mps"
                self._device_string = "mps"
                logger.info("Apple MPS GPU detected")
                return True
        except (ImportError, AttributeError):
            logger.debug("MPS not available")
        except Exception as e:
            logger.warning(f"MPS detection failed: {e}")
        return False
    
    def get_best_device(self) -> str:
        """Get best available device string for torch.device()."""
        return self._device_string
    
    def gpu_available(self) -> bool:
        """Check if GPU is available."""
        return self._gpu_available
    
    def gpu_type(self) -> Optional[str]:
        """Get GPU type: 'cuda', 'rocm', 'mps', or None."""
        return self._gpu_type
    
    def gpu_name(self) -> Optional[str]:
        """Get GPU model name."""
        return self._gpu_name
    
    def _init_pynvml(self):
        """Initialize pynvml for VRAM monitoring."""
        try:
            import pynvml
            pynvml.nvmlInit()
            self._pynvml_handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            logger.debug("pynvml initialized for VRAM monitoring")
        except Exception as e:
            logger.warning(f"Failed to initialize pynvml: {e}")
            self._pynvml_handle = None
    
    def vram_usage_mb(self) -> float:
        """Get VRAM usage in MB (NVIDIA only, returns 0.0 otherwise).
        
        Returns:
            VRAM usage in megabytes
        """
        if self._gpu_type != "cuda" or self._pynvml_handle is None:
            return 0.0
        
        try:
            import pynvml
            info = pynvml.nvmlDeviceGetMemoryInfo(self._pynvml_handle)
            return info.used / (1024 * 1024)
        except Exception as e:
            logger.warning(f"Failed to get VRAM usage: {e}")
            return 0.0
    
    def vram_usage_percent(self) -> float:
        """Get VRAM usage as percentage (NVIDIA only, returns 0.0 otherwise).
        
        Returns:
            VRAM usage as percentage (0-100)
        """
        if self._gpu_type != "cuda" or self._pynvml_handle is None:
            return 0.0
        
        try:
            import pynvml
            info = pynvml.nvmlDeviceGetMemoryInfo(self._pynvml_handle)
            return (info.used / info.total) * 100.0
        except Exception as e:
            logger.warning(f"Failed to get VRAM usage: {e}")
            return 0.0
