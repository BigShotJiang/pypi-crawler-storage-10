"""Performance & Resource Management - Feature 20.

This module provides high-performance LLM inference with GPU acceleration,
resource monitoring, and connection pooling.

Sub-Features:
- 20.1: DeviceManager - GPU detection (CUDA/ROCm/MPS) and VRAM monitoring
- 20.2: ResourceMonitor - CPU/RAM/GPU monitoring with alerts
- 20.3: AsyncLLM - Async inference with request queue and timeout management
- 20.4: Optimization Layer - Batching, throttling, and hardware profiles

Example:
    >>> from prompt_automation.performance import (
    ...     AsyncLLM, DeviceManager, ConnectionPool, ResourceMonitor,
    ...     BatchManager, Throttler, ProfileManager
    ... )
    >>>
    >>> # Initialize hardware detection
    >>> device_mgr = DeviceManager()
    >>> resource_monitor = ResourceMonitor()
    >>> resource_monitor.start()
    >>>
    >>> # Auto-detect hardware profile
    >>> profile_mgr = ProfileManager(
    ...     device_manager=device_mgr,
    ...     resource_monitor=resource_monitor
    ... )
    >>> profile = profile_mgr.detect_profile()
    >>> config = profile_mgr.get_config(profile)
    >>>
    >>> # Create BatchManager with profile settings
    >>> pool = ConnectionPool(max_connections=config["max_concurrent"])
    >>> llm = AsyncLLM(
    ...     max_concurrent=config["max_concurrent"],
    ...     connection_pool=pool,
    ...     device_manager=device_mgr,
    ...     request_timeout=30.0
    ... )
    >>> batch_mgr = BatchManager(
    ...     llm=llm,
    ...     batch_size=config["batch_size"],
    ...     flush_timeout=1.0
    ... )
    >>>
    >>> # Monitor and throttle if needed
    >>> throttler = Throttler(
    ...     resource_monitor=resource_monitor,
    ...     thresholds={"cpu": 90.0, "ram": 90.0, "vram": 90.0}
    ... )
    >>>
    >>> await llm.start()
    >>> await batch_mgr.start()
    >>>
    >>> # Submit concurrent requests (automatically batched)
    >>> futures = [batch_mgr.add(f"Question {i}") for i in range(10)]
    >>> results = await asyncio.gather(*futures)
    >>>
    >>> # Check if throttling needed
    >>> if throttler.should_throttle():
    ...     action = throttler.get_throttle_action()
    ...     # Adjust settings based on action
    >>>
    >>> await batch_mgr.stop()
    >>> await llm.stop()
    >>> resource_monitor.stop()
"""

from prompt_automation.performance.device_manager import DeviceManager
from prompt_automation.performance.resource_monitor import ResourceMonitor
from prompt_automation.performance.connection_pool import ConnectionPool
from prompt_automation.performance.async_llm import AsyncLLM
from prompt_automation.performance.batch_manager import BatchManager
from prompt_automation.performance.throttler import Throttler
from prompt_automation.performance.profiles import ProfileManager

__all__ = [
    "DeviceManager",
    "ResourceMonitor",
    "ConnectionPool",
    "AsyncLLM",
    "BatchManager",
    "Throttler",
    "ProfileManager",
]
