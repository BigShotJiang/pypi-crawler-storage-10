"""Profile Manager - Hardware profile detection and configuration.

This module provides ProfileManager for detecting hardware capabilities and
applying appropriate performance settings.

Key Features:
- **Auto-Detection**: Analyzes GPU availability and RAM to select profile
- **Three Profiles**: minimal, standard, performance
- **Manual Override**: Allows explicit profile selection
- **Custom Settings**: Supports custom configuration per profile

Profiles:
    - **minimal**: No GPU, <2GB RAM → Conservative settings for low-end hardware
    - **standard**: No GPU, 2-8GB RAM → Balanced settings for typical workstations
    - **performance**: GPU + 8GB+ RAM → Aggressive settings for high-end hardware

Example:
    >>> from prompt_automation.performance.profiles import ProfileManager
    >>> from prompt_automation.performance.device_manager import DeviceManager
    >>> from prompt_automation.performance.resource_monitor import ResourceMonitor
    >>>
    >>> device_mgr = DeviceManager()
    >>> resource_monitor = ResourceMonitor()
    >>> resource_monitor.start()
    >>>
    >>> profile_mgr = ProfileManager(
    ...     device_manager=device_mgr,
    ...     resource_monitor=resource_monitor
    ... )
    >>>
    >>> profile = profile_mgr.detect_profile()
    >>> config = profile_mgr.get_config(profile)
    >>> print(f"Using {profile} profile: {config}")
"""

from typing import Dict, Optional
from enum import Enum
import logging
import copy

logger = logging.getLogger(__name__)


class Profile(Enum):
    """Hardware profile types."""
    MINIMAL = "minimal"
    STANDARD = "standard"
    PERFORMANCE = "performance"


# Default profile settings
DEFAULT_SETTINGS = {
    "minimal": {
        "batch_size": 1,
        "max_concurrent": 1,
        "memory_limit_mb": 64,
        "queue_size": 10,
        "request_timeout": 60.0
    },
    "standard": {
        "batch_size": 5,
        "max_concurrent": 5,
        "memory_limit_mb": 256,
        "queue_size": 50,
        "request_timeout": 30.0
    },
    "performance": {
        "batch_size": 10,
        "max_concurrent": 10,
        "memory_limit_mb": 512,
        "queue_size": 100,
        "request_timeout": 30.0
    }
}


class ProfileManager:
    """Manages hardware profile detection and configuration.
    
    Detects hardware capabilities (GPU, RAM) and selects appropriate profile.
    Provides configuration settings for each profile.
    
    Profile Selection Logic:
        - GPU + 8GB+ RAM → performance
        - No GPU + 2-8GB RAM → standard
        - No GPU + <2GB RAM → minimal
    
    Thread Safety:
        Thread-safe (uses thread-safe ResourceMonitor).
    """
    
    def __init__(
        self,
        device_manager,
        resource_monitor,
        manual_profile: Optional[str] = None,
        custom_settings: Optional[Dict[str, Dict]] = None
    ):
        """Initialize profile manager.
        
        Args:
            device_manager: DeviceManager for GPU detection.
            resource_monitor: ResourceMonitor for RAM metrics.
            manual_profile: Optional manual profile override ("minimal", "standard", "performance").
                If provided, auto-detection is skipped.
            custom_settings: Optional dict of custom settings per profile.
                Format: {"profile_name": {"batch_size": 5, ...}}
                Custom settings override defaults.
        
        Raises:
            ValueError: If manual_profile is invalid
        """
        if manual_profile and manual_profile not in ["minimal", "standard", "performance"]:
            raise ValueError(f"Invalid manual_profile: {manual_profile}")
        
        self.device_manager = device_manager
        self.resource_monitor = resource_monitor
        self.manual_profile = manual_profile
        
        # Merge custom settings with defaults (deep copy to avoid mutation)
        self.settings = copy.deepcopy(DEFAULT_SETTINGS)
        if custom_settings:
            for profile, config in custom_settings.items():
                if profile in self.settings:
                    self.settings[profile].update(config)
                else:
                    self.settings[profile] = config
        
        logger.info(
            f"ProfileManager initialized"
            f"{f' (manual: {manual_profile})' if manual_profile else ''}"
        )
    
    def detect_profile(self) -> str:
        """Detect hardware profile based on GPU and RAM.
        
        Detection Logic:
            1. If manual_profile set: return manual_profile
            2. Check GPU availability
            3. Check RAM size
            4. Apply profile selection rules
        
        Returns:
            Profile name: "minimal", "standard", or "performance"
        """
        # Use manual override if set
        if self.manual_profile:
            logger.info(f"Using manual profile: {self.manual_profile}")
            return self.manual_profile
        
        # Get hardware info
        device_info = self.device_manager.get_best_device()
        metrics = self.resource_monitor.get_metrics()
        
        has_gpu = device_info["type"] != "cpu"
        ram_gb = metrics.get("ram_total_gb", 0.0)
        
        # Profile selection (GPU presence prioritized)
        if has_gpu:
            # Any GPU triggers performance profile
            profile = "performance"
            logger.info(
                f"Detected performance profile: GPU={device_info['type']}, "
                f"RAM={ram_gb:.1f}GB"
            )
        elif ram_gb >= 2.0:
            profile = "standard"
            logger.info(f"Detected standard profile: RAM={ram_gb:.1f}GB, no GPU")
        else:
            profile = "minimal"
            logger.info(f"Detected minimal profile: RAM={ram_gb:.1f}GB, no GPU")
        
        return profile
    
    def get_config(self, profile: str) -> Dict[str, any]:
        """Get configuration for specified profile.
        
        Args:
            profile: Profile name ("minimal", "standard", "performance")
        
        Returns:
            Dict with keys: batch_size, max_concurrent, memory_limit_mb,
                           queue_size, request_timeout
        
        Raises:
            ValueError: If profile is invalid
        """
        if profile not in self.settings:
            raise ValueError(
                f"Invalid profile: {profile}. "
                f"Valid: {list(self.settings.keys())}"
            )
        
        return self.settings[profile].copy()
    
    def get_all_profiles(self) -> Dict[str, Dict]:
        """Get all profile configurations.
        
        Returns:
            Dict mapping profile names to their configurations
        """
        return {
            profile: config.copy()
            for profile, config in self.settings.items()
        }
    
    def apply_profile(self, profile: Optional[str] = None) -> Dict[str, any]:
        """Detect (if needed) and apply profile settings.
        
        Convenience method combining detect_profile() and get_config().
        
        Args:
            profile: Optional profile name. If None, auto-detects.
        
        Returns:
            Configuration dict for the selected profile
        """
        if profile is None:
            profile = self.detect_profile()
        
        config = self.get_config(profile)
        logger.info(f"Applied {profile} profile: {config}")
        return config
