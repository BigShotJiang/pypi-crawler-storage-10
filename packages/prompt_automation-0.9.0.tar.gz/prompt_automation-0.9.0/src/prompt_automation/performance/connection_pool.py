"""HTTP connection pool for LLM API requests."""

from typing import Any, Dict, Optional
import logging
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

logger = logging.getLogger(__name__)


class ConnectionPool:
    """HTTP connection pool for LLM API requests."""
    
    def __init__(
        self,
        max_connections: int = 10,
        timeout: float = 30.0,
        max_retries: int = 3
    ):
        """Initialize connection pool.
        
        Args:
            max_connections: Max connections per host
            timeout: Request timeout in seconds
            max_retries: Max retry attempts on failure
        """
        self.max_connections = max_connections
        self.timeout = timeout
        self.max_retries = max_retries
        
        self._session = self._create_session()
        logger.info(
            f"ConnectionPool created: {max_connections} max connections, "
            f"{timeout}s timeout"
        )
    
    def _create_session(self) -> requests.Session:
        """Create requests.Session with connection pooling."""
        session = requests.Session()
        
        # Configure retry strategy
        retry_strategy = Retry(
            total=self.max_retries,
            backoff_factor=0.5,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["POST", "GET"]
        )
        
        # Configure adapters with pooling
        adapter = HTTPAdapter(
            pool_connections=self.max_connections,
            pool_maxsize=self.max_connections,
            max_retries=retry_strategy
        )
        
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        return session
    
    def get_session(self) -> requests.Session:
        """Get the configured session."""
        return self._session
    
    def request(
        self,
        method: str,
        url: str,
        **kwargs
    ) -> requests.Response:
        """Make HTTP request using connection pool.
        
        Args:
            method: HTTP method (GET, POST, etc.)
            url: Request URL
            **kwargs: Additional arguments for requests
        
        Returns:
            Response object
        """
        # Set timeout if not provided
        if 'timeout' not in kwargs:
            kwargs['timeout'] = self.timeout
        
        try:
            response = self._session.request(method, url, **kwargs)
            logger.debug(
                f"{method} {url} -> {response.status_code} "
                f"({len(response.content)} bytes)"
            )
            return response
        
        except requests.exceptions.RequestException as e:
            logger.error(f"{method} {url} failed: {e}")
            raise
    
    def close(self):
        """Close the session and release connections."""
        self._session.close()
        logger.info("ConnectionPool closed")
