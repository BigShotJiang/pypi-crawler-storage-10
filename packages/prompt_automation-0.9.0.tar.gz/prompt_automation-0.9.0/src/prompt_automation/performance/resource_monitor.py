"""Resource monitoring for CPU, RAM, GPU, and VRAM usage."""

from typing import Dict, Any, Optional, Callable, Tuple
import logging
import threading
import time

try:
    import psutil
except ImportError:
    psutil = None  # type: ignore

logger = logging.getLogger(__name__)


class ResourceMonitor:
    """Monitor CPU, RAM, GPU, and VRAM usage in background thread."""
    
    def __init__(self, sample_rate_hz: float = 1.0, device_manager=None):
        """Initialize resource monitor.
        
        Args:
            sample_rate_hz: Sampling rate in Hz (default 1.0 = once per second)
            device_manager: Optional DeviceManager for GPU/VRAM monitoring
        """
        self.sample_rate_hz = sample_rate_hz
        self._device_manager = device_manager
        self._lock = threading.Lock()
        
        # Current metrics
        self._cpu_percent: float = 0.0
        self._ram_percent: float = 0.0
        self._ram_mb: float = 0.0
        self._vram_mb: float = 0.0
        self._vram_percent: float = 0.0
        self._samples_collected: int = 0
        
        # Alert thresholds: resource -> (threshold, callback)
        self._thresholds: Dict[str, Tuple[float, Callable]] = {}
        
        # Background thread
        self._monitor_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        
        # Start monitoring
        self._start_monitoring()
    
    def _start_monitoring(self):
        """Start background monitoring thread."""
        self._monitor_thread = threading.Thread(
            target=self._monitor_loop,
            daemon=True,
            name="ResourceMonitor"
        )
        self._monitor_thread.start()
        logger.info(f"Resource monitoring started at {self.sample_rate_hz} Hz")
    
    def _monitor_loop(self):
        """Background monitoring loop."""
        if psutil is None:
            logger.warning("psutil not available, resource monitoring disabled")
            return
        
        interval = 1.0 / self.sample_rate_hz
        
        while not self._stop_event.is_set():
            try:
                # Sample CPU
                cpu = psutil.cpu_percent(interval=None)
                
                # Sample RAM
                mem = psutil.virtual_memory()
                ram_pct = mem.percent
                ram_mb = mem.used / (1024 * 1024)
                
                # Sample GPU/VRAM (if DeviceManager provided)
                vram_mb = 0.0
                vram_pct = 0.0
                if self._device_manager:
                    vram_mb = self._device_manager.vram_usage_mb()
                    vram_pct = self._device_manager.vram_usage_percent()
                
                # Update metrics (thread-safe)
                with self._lock:
                    self._cpu_percent = cpu
                    self._ram_percent = ram_pct
                    self._ram_mb = ram_mb
                    self._vram_mb = vram_mb
                    self._vram_percent = vram_pct
                    self._samples_collected += 1
                    
                    # Get snapshot for threshold checks
                    stats_snapshot = {
                        "cpu_percent": cpu,
                        "ram_percent": ram_pct,
                        "vram_percent": vram_pct
                    }
                
                # Check thresholds (outside lock to avoid blocking)
                if self._thresholds:
                    self._check_thresholds(stats_snapshot)
                
            except Exception as e:
                logger.error(f"Resource monitoring error: {e}")
            
            # Sleep until next sample
            time.sleep(interval)
    
    def get_cpu_usage(self) -> float:
        """Get current CPU usage percent."""
        with self._lock:
            return self._cpu_percent
    
    def get_ram_usage(self) -> float:
        """Get current RAM usage percent."""
        with self._lock:
            return self._ram_percent
    
    def get_ram_usage_mb(self) -> float:
        """Get current RAM usage in MB."""
        with self._lock:
            return self._ram_mb
    
    def get_stats(self) -> Dict[str, Any]:
        """Get all current stats."""
        with self._lock:
            stats = {
                "cpu_percent": self._cpu_percent,
                "ram_percent": self._ram_percent,
                "ram_mb": self._ram_mb,
                "vram_mb": self._vram_mb,
                "vram_percent": self._vram_percent,
                "samples_collected": self._samples_collected
            }
            
            # Add GPU info if DeviceManager provided
            if self._device_manager:
                stats["gpu_available"] = self._device_manager.gpu_available()
                stats["gpu_type"] = self._device_manager.gpu_type()
            else:
                stats["gpu_available"] = False
                stats["gpu_type"] = None
            
            return stats
    
    def set_threshold(self, resource: str, threshold: float, callback: Callable):
        """Set alert threshold for a resource.
        
        Args:
            resource: "cpu", "ram", "vram" (resource name without _percent suffix)
            threshold: Percent threshold (0-100)
            callback: Function called with alert dict when threshold exceeded
        """
        self._thresholds[resource] = (threshold, callback)
        logger.info(f"Threshold set: {resource} > {threshold}%")
    
    def _check_thresholds(self, stats: Dict[str, float]):
        """Check if any thresholds exceeded and trigger callbacks."""
        for resource, (threshold, callback) in self._thresholds.items():
            metric_key = f"{resource}_percent"
            
            if metric_key in stats and stats[metric_key] > threshold:
                alert = {
                    "resource": resource,
                    "value": stats[metric_key],
                    "threshold": threshold,
                    "timestamp": time.time()
                }
                
                try:
                    callback(alert)
                except Exception as e:
                    logger.error(f"Alert callback error: {e}")
    
    def stop(self):
        """Stop background monitoring thread."""
        logger.info("Stopping resource monitor")
        self._stop_event.set()
        if self._monitor_thread:
            self._monitor_thread.join(timeout=2.0)
