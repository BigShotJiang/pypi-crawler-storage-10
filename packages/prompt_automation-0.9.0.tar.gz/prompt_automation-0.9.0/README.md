# prompt-automation

Keyboard-driven prompt launcher with AI-powered workflow automation. Press a hotkey, fill templates, and copy polished prompts—or let the AI implement features for you.

## ✨ Core Features
- **Single-window GUI** - Browse templates, fill variables, review output in one unified interface
- **Template Management** - Wizard-guided creation, hierarchical folders, snapshot-aware globals
- **Espanso Integration** - Sync snippets, validate triggers, auto-restart service
- **AI Workflow System** - Automated feature implementation from discovery to archival ([Guide](docs/agentic_feature_implementation/WORKFLOW_COMPLETE_GUIDE.md))
- **Multi-Tier Caching** - Intelligent L1/L2/L3 caching reduces LLM latency by 1000x ([Docs](docs/CACHING.md))
- **Offline Mode** - SQLite cache enables template loading without internet ([Feature 24](docs/agentic_feature_implementation/_archive/2025-10-25_feature_24/feature_spec.md))
- **Performance Manager** - GPU auto-detection, async inference, resource monitoring ([Guide](docs/agentic_feature_implementation/20_performance_resource_manager/feature_spec.md))
- **Analytics Dashboard** - Track usage, performance metrics, error telemetry ([CLI Guide](docs/agentic_feature_implementation/21_usage_analytics_telemetry/feature_spec.md))
- **Error Recovery** - Automatic rollback, audit trail, manual snapshot restoration ([Docs](docs/ERROR_RECOVERY.md))

## Installation

### Quick Install (Recommended)
```powershell
# Windows
install\install.ps1

# macOS / Linux / WSL2
bash install/install.sh
```

After installation, configure MCP integration: [MCP Integration Guide](docs/MCP_INTEGRATION.md)

### Package Managers
```bash
pipx install prompt-automation
# or
python -m pip install prompt-automation
```

### WSL2 Users
See [WSL2 Setup Guide](docs/WSL2_SETUP_GUIDE.md) for cross-platform hotkey configuration.

### Developer Setup
```bash
# Windows
install/install-dev.ps1

# macOS / Linux / WSL2
pipx install --editable .
pipx inject prompt-automation ".[tests]"
```

**Platform Notes**: Debian/Ubuntu users need `python3-tk`. Full troubleshooting: [Installation Guide](docs/INSTALLATION_TROUBLESHOOTING.md)

## Auto-Update System

**Intelligent updates with zero configuration.** The auto-update system detects your installation method and keeps prompt-automation current with minimal overhead.

### How It Works
- **Manifest-First**: Checks GitHub releases for new versions (~50ms, 10x faster than PyPI)
- **Silent Background**: Non-blocking checks with 24-hour rate limiting
- **Install-Aware**: Auto-detects PIPX, PIP_USER, EDITABLE, or installer-based installations
- **Graceful Fallback**: Falls back to PyPI if manifest unavailable

### Installation Methods

| Method | Detection | Update Behavior | Opt-In Required |
|--------|-----------|-----------------|-----------------|
| **PIPX** | `pipx list` contains prompt-automation | `pipx upgrade prompt-automation` | No (auto-enabled) |
| **PIP_USER** | Installed in `~/.local` | `pip install --user --upgrade prompt-automation` | No (auto-enabled) |
| **EDITABLE** | Developer mode (`pip install -e`) | Skipped (manual control) | N/A |
| **INSTALLER** | External package manager (apt, brew, etc.) | Skipped (externally managed) | N/A |

### Configuration

**Enable/Disable Auto-Updates**:
```bash
# Disable globally (all platforms)
export PA_AUTO_UPDATE_ENABLED=0

# Enable (default for PIPX/PIP_USER on Linux/macOS)
export PA_AUTO_UPDATE_ENABLED=1
```

**Windows Opt-In** (safety-first approach):
```bash
# Windows users must explicitly opt-in
$env:PA_AUTO_UPDATE_OPT_IN=1
```

### Troubleshooting

**Updates not working?**
1. Check install method: `prompt-automation --version` shows install type
2. Verify opt-in (Windows): `echo $env:PA_AUTO_UPDATE_OPT_IN` should be `1`
3. Manual update: `pipx upgrade prompt-automation` or `pip install --user --upgrade prompt-automation`

**Too many checks?**
- Rate limiting enforces 24-hour minimum between checks
- State file: `~/.prompt-automation/update-state.json`

**Need more control?**
- Set `PA_AUTO_UPDATE_ENABLED=0` to disable completely
- See [Update System Documentation](docs/UPDATE_SYSTEM.md) for advanced configuration

## Quick Start
1. **Launch**: Press **Ctrl+Shift+J** or run `prompt-automation`
2. **Browse**: Search templates or navigate hierarchically
3. **Fill**: Complete placeholders (blank = default/skip)
4. **Review**: Preview rendered output
5. **Copy**: Press **Ctrl+Enter** (copy & close) or **Ctrl+Shift+C** (copy only)
6. **Rebind**: Run `prompt-automation --assign-hotkey` to change hotkey

**Keyboard Shortcuts**: [Single Window KB Guide](docs/SINGLE_WINDOW_KB.md) | **CLI Options**: [Hotkeys Guide](docs/HOTKEYS.md)

## AI-Powered Feature Development

**NEW**: Automated 3-phase workflow implements features from discovery to archival using AI.

### Quick Start
```bash
# Phase 1: Discover next feature + generate plan
./scripts/feature_workflow_copilot.sh

# Phase 2: AI implements using TDD (after approval)
./scripts/feature_workflow_copilot.sh --phase 2 {feature_id}

# Phase 3: Archive and update docs (after manual testing)
./scripts/feature_workflow_copilot.sh --phase 3 {feature_id}
```

### What It Does
- **Phase 1**: Analyzes feature specs, extracts Definition of Done, assesses risks
- **Phase 2**: Implements using TDD (RED → GREEN → REFACTOR), validates coverage ≥85%
- **Phase 3**: Archives feature, updates CHANGELOG/README, suggests next feature

### Human Checkpoints
- ⏸️ **After Phase 1**: Choose implementation path (AI direct or meta-prompt)
- ⏸️ **After Phase 2**: Execute manual testing before archival

### Documentation
- 📖 **[Complete Workflow Guide](docs/agentic_feature_implementation/WORKFLOW_COMPLETE_GUIDE.md)** - Step-by-step instructions (START HERE)
- 📚 **[Feature Roadmap](docs/agentic_feature_implementation/README.md)** - All available features
- 🔧 **[Technical Reference](docs/agentic_feature_implementation/AUTOMATED_WORKFLOW_GUIDE.md)** - Phase details, troubleshooting

State files persist in `docs/agentic_feature_implementation/{NN}_{feature_name}/workflow_state_phase*.json` for cross-device portability.

## Key Integrations

### Espanso Text Expansion
Sync templates as Espanso snippets with auto-validation.

```bash
# Full sync (generate, validate, install, restart)
prompt-automation --espanso-sync

# Dry-run (no install/restart)
PA_SKIP_INSTALL=1 scripts/espanso.sh sync

# Validate YAML only
scripts/espanso.sh lint

# Clean up managed files
prompt-automation --espanso-clean
```

**Documentation**: [Espanso Package Guide](docs/ESPANSO_PACKAGE.md) | [First Run Guide](docs/ESPANSO_FIRST_RUN.md)

### Configuration Management
Unified config system with GUI, profiles, and hot-reload.

- **GUI Access**: Options → Configuration Manager...
- **Config File**: `~/.prompt-automation/config.json`
- **Profiles**: lightweight / standard / performance
- **Hot-Reload**: 300ms debounce, instant updates

**Documentation**: [Configuration Guide](docs/CONFIGURATION.md) | [Feature Spec](docs/agentic_feature_implementation/03_knowledge_base/feature_spec.md)

### Template Authoring
Create templates via New Template Wizard or JSON directly.

- **Location**: `src/prompt_automation/prompts/`
- **Features**: Multi-file placeholders, metadata flags, hierarchical folders
- **Validation**: Schema checks, variable resolution

**Documentation**: [Template Guide](docs/TEMPLATES.md) | [Variables Reference](docs/VARIABLES_REFERENCE.md) | [Variable Workflow](docs/VARIABLE_WORKFLOW.md)

### MCP Integration
Connect to Model Context Protocol servers (Obsidian, LiteLLM, custom).

- **Setup**: [MCP Integration Guide](docs/MCP_INTEGRATION.md)
- **Router**: Multi-server support with automatic fallback ([Feature 22](docs/agentic_feature_implementation/_archive/2025-10-24_feature_22_mcp_router/implementation_summary.md))
- **Commands**: Natural language → MCP tool calls ([Feature 14](docs/agentic_feature_implementation/14_command_palette/feature_spec.md))

### Obsidian RAG Integration (Feature 23) 🆕
Semantic search across your Obsidian vault with interactive GUI workflow.

**Template Variable**: `{{rag_vault}}` triggers interactive workflow:
1. **Folder Selector** - Visual tree with checkboxes, search filter
2. **Query Dialog** - Multi-line input with character counter (80-200 optimal)
3. **RAG Search** - Semantic search with LLM embeddings and ranking
4. **Results Preview** - Color-coded relevance, expandable snippets, metadata
5. **Action** - Use results (inject Markdown), Search Again (iterate), or Cancel

**Pre-filtered Search**: `{{rag_vault:Projects,Docs}}` - Skip folder selector with template hints

**Configuration**:
```bash
# Option 1: Environment variable
export OBSIDIAN_VAULT_PATH="/path/to/vault"

# Option 2: Config file (~/.prompt-automation/config.json)
{
  "obsidian": {
    "vault_path": "/path/to/vault"
  }
}
```

**Features**:
- Atomic file operations with rollback
- User confirmation for destructive operations
- Search iteration ("Search Again" workflow)
- Markdown context formatting with headers, relevance scores
- Cross-platform support (Windows/WSL2/Linux/macOS)

**Documentation**: [Archive Summary](docs/agentic_feature_implementation/_archive/2025-10-25_feature_23_obsidian_rag/implementation_summary.md) | [Context API](docs/agentic_feature_implementation/_archive/2025-10-25_feature_23_obsidian_rag/context_summary.md)

## Performance Features

### Multi-Tier Caching (Feature 19)
Intelligent L1/L2/L3 caching reduces LLM calls by 80-90%.

- **L1 (Memory)**: <1ms, 256MB default
- **L2 (Disk)**: <10ms, persistent, 3:1 compression
- **L3 (GPU)**: Optional VRAM cache

**Quick Start**:
```bash
prompt-automation cache stats       # View hit rate
prompt-automation cache clear       # Clear all tiers
prompt-automation cache warm        # Pre-load top templates
```

**Documentation**: [Caching Guide](docs/CACHING.md) | [Feature Spec](docs/agentic_feature_implementation/19_multi_tier_caching/feature_spec.md)

### Performance Manager (Feature 20)
GPU auto-detection, async inference, resource monitoring.

- **Profiles**: Auto-detect optimal hardware profile
- **Async LLM**: Non-blocking GUI during inference
- **Monitoring**: Real-time CPU/RAM/GPU tracking

**Quick Start**:
```bash
prompt-automation metrics           # View resource usage
prompt-automation gpu-info          # Check GPU status
```

**Documentation**: [Feature Spec](docs/agentic_feature_implementation/20_performance_resource_manager/feature_spec.md)

### Analytics Dashboard (Feature 21)
Privacy-first usage tracking with local SQLite storage.

```bash
prompt-automation analytics summary              # Overview
prompt-automation analytics top-templates        # Most used
prompt-automation analytics errors --limit 20    # Recent errors
prompt-automation analytics export               # Export JSON
```

**Documentation**: [Feature Spec](docs/agentic_feature_implementation/21_usage_analytics_telemetry/feature_spec.md)

## Troubleshooting

- **General**: `prompt-automation --troubleshoot` - Shows logs, config, environment
- **Installation**: [Installation Troubleshooting](docs/INSTALLATION_TROUBLESHOOTING.md)
- **Python Issues**: [Python Troubleshooting](docs/PYTHON_TROUBLESHOOTING.md)
- **Hotkeys**: [Hotkeys Guide](docs/HOTKEYS.md)
- **Uninstall**: [Uninstall Guide](docs/UNINSTALL.md)
- **Espanso**: [Espanso Remote First](docs/ESPANSO_REMOTE_FIRST.md)

## Contributing

- Review [CONTRIBUTING.md](CONTRIBUTING.md) and [Codebase Reference](docs/CODEBASE_REFERENCE.md)
- Run `pytest -q` before submitting changes
- Report issues via GitHub Issues

## License

MIT License - See [LICENSE](LICENSE) for details.

---

**Version**: 0.9.1 | **Updated**: 2025-10-24
