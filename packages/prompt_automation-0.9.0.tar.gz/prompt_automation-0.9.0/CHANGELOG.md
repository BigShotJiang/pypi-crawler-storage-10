# Changelog

## [Unreleased]

## [0.9.0] - 2025-10-26

### Added
- **Auto-Update System** - Intelligent update checker with install method detection and zero-config defaults (121 tests, ~1,500 LOC)
  - **Install Method Detection** - Auto-detect PIPX, PIP_USER, EDITABLE, or INSTALLER installs with fallback chain (21 tests, ~350 LOC)
  - **Manifest System** - GitHub release manifest with changelog extraction (10x faster than PyPI, <50ms vs 500ms) (22 tests, ~400 LOC)
  - **Update Checker** - Silent background checks with 24h rate limiting, install method routing, graceful PyPI fallback (33 tests, ~450 LOC)
  - **Manifest Generator** - CI/CD integration to auto-generate update manifests from CHANGELOG.md on release (23 tests, ~300 LOC)
  - **Integration Tests** - End-to-end validation of complete update workflows with fallback scenarios (12 tests, ~455 LOC)
  - **Feature Flags** - `PA_AUTO_UPDATE_ENABLED` (default: ON), `PA_AUTO_UPDATE_OPT_IN` (Windows-only default: ON for safety)

### Changed
- **Installation Detection** - Now auto-detects install method on first run (PIPX, PIP_USER, EDITABLE, INSTALLER) with persistent state
- **Update Behavior** - Windows users must opt-in to auto-updates via `PA_AUTO_UPDATE_OPT_IN=1` (safety-first approach)
- **PyPI Fallback** - Always available if GitHub manifest fails (timeout, network error, malformed data)

### Fixed
- **Silent Failures** - All update errors now fail silently without blocking application (3 error handling improvements in checker.py)
- **Rate Limiting** - Prevents excessive update checks (24h minimum between checks with state file persistence)

### Technical
- **Performance** - Manifest-first approach: <50ms vs PyPI's 500ms (10x faster, P95 latency)
- **CI/CD Integration** - Automatic manifest generation on release via GitHub Actions workflow
- **Cross-Platform** - Tested on Windows (PIPX), WSL2 (editable), and Linux (PIP_USER)
- **Backward Compatible** - Preserves config, variables, and state when upgrading from v0.8.0

## [0.9.3] - 2025-10-25

### Added
- **Feature 26: Error Handling & Recovery** - Automatic rollback with audit trail and manual recovery tools (26 tests, ~600 LOC)
  - **MutationLogger** - Append-only log of file mutations with snapshots (5 tests, ~155 LOC)
  - **MutationTransaction** - Context manager for atomic operations with automatic rollback (10 tests, ~125 LOC)
  - **ErrorCatalog** - 15 error codes mapped to user-friendly remedies with regex classification (4 tests, ~170 LOC)
  - **Rollback CLI** - Manual recovery commands: rollback(), list_snapshots(), cleanup_old_snapshots() (5 tests, ~150 LOC)
  - **Feature Flag** - `PA_ERROR_RECOVERY_ENABLED` env var (default: ON for safety)
  - **Documentation** - Complete user guide at docs/ERROR_RECOVERY.md

## [0.9.3] - 2025-10-25

### Added
- **Feature 24: Local Cache for Offline Reads** - SQLite-based cache backend with background refresh and offline fallback (27 tests, ~600 LOC)
  - **SQLite Cache Backend** - Persistent L2 cache with WAL mode, gzip compression, TTL expiration, LRU eviction at 100MB limit (13 tests, ~400 LOC)
  - **Background Refresh Service** - Automatic cache refresh every 5 minutes when online, network connectivity detection (7 tests, ~155 LOC)
  - **Offline Fallback** - Serve stale cache data when network unavailable, transparent degradation (2 tests, ~50 LOC)
  - **Feature Flag** - `PA_LOCAL_CACHE_ENABLED` env var and `local_cache_enabled` config (default: OFF, opt-in) (5 tests, ~40 LOC)
- **Feature 23: Obsidian RAG Integration** - Complete production-ready RAG workflow with interactive GUI for semantic vault search (129 tests, ~5,000 LOC)
  - **Sub-Feature 23.1: Folder-Scoped Search** - Vault navigation with cross-platform path normalization and security boundaries (12 tests, ~700 LOC)
  - **Sub-Feature 23.2: RAG Search Engine** - Core semantic search with LLM embeddings, hybrid ranking, and relevance scoring (34 tests, ~1,400 LOC)
  - **Sub-Feature 23.3: Template Variable Integration** - Template variables `{{rag_vault}}` and `{{append_to_note}}` with Markdown formatting (22 tests, ~900 LOC)
  - **Sub-Feature 23.4: Confirmation Gates & Atomic Operations** - User safety dialogs and atomic file writes with rollback (40 tests, ~980 LOC)
  - **Sub-Feature 23.5: GUI Enhancements** - Interactive dialogs for folder selection, query input, and results preview (21 tests, ~1,857 LOC)
- **Template Variables:**
  - `{{rag_vault}}` - Interactive RAG search workflow with folder selector, query dialog, and results preview
  - `{{rag_vault:Projects,Docs}}` - Pre-filtered RAG search with folder hints from template metadata
  - `{{append_to_note}}` - Atomic note appending with file picker and confirmation
- **GUI Components:**
  - `FolderSelectorDialog` - Tree view with checkboxes, pre-selection, search filter, Select All/Clear buttons
  - `QueryInputDialog` - Multi-line text input with live character counter (80-200 optimal), keyboard shortcuts (Ctrl+Enter)
  - `RAGResultsPreview` - Scrollable results with color-coded relevance, expandable snippets, metadata, "Search Again" workflow
- **MCP Tools:**
  - `pa.obsidian.search_notes` - Semantic search with folder filtering and relevance ranking
- **Utilities:**
  - `atomic_write()` - Tmp file → rename pattern for data safety with automatic rollback

### Changed
- **Configuration:** Added `obsidian.vault_path` to config.json (optional, can use `OBSIDIAN_VAULT_PATH` env var)
- **RAG Workflow:** Fully interactive GUI workflow replaces simple prompt-based search
- **Template Rendering:** RAG results inject formatted Markdown context with headers, relevance scores, timestamps

### Technical Details
- **Architecture Patterns:** Atomic operations, GUI dependency injection, fallback chains (env → config → error), state persistence
- **Performance:** <2s vault scan (100 folders), <5s RAG search (1,000 notes), configurable timeout (default 10s)
- **Cross-Platform:** Full Windows and WSL2 support with path normalization
- **Quality Metrics:** 100% DoD completion (30 criteria), 100% test pass rate (129/129), 0 regressions, 50% faster than estimates

## [0.9.2] - 2025-10-24

### Added
- **Feature 22: Universal MCP Router/Gateway** - Production-ready multi-server MCP orchestration system with automatic failover, retry logic, and backward compatibility (140 tests, 1,791 LOC)
  - **Sub-Feature 22.1: Server Registry** - Centralized server configuration with namespace collision detection (17 tests, 215 LOC)
  - **Sub-Feature 22.2: Discovery Engine** - Parallel tool discovery with metadata normalization and caching (22 tests, 245 LOC)
  - **Sub-Feature 22.3: HTTP Transport Adapter** - HTTP/HTTPS transport for remote MCP servers with JSON-RPC 2.0 (20 tests, 225 LOC)
  - **Sub-Feature 22.4: Stdio Transport Adapter** - Local subprocess MCP servers with graceful shutdown and WSL2 support (25 tests, 307 LOC)
  - **Sub-Feature 22.5: Router Core** - Orchestration layer with pooling, routing, exponential backoff retry, and health monitoring (27 tests, 471 LOC)
  - **Sub-Feature 22.6: CLI Integration** - Command-line interface with list-servers, list-tools, call-tool, and health commands (13 tests, 175 LOC)
  - **Sub-Feature 22.7: MCPService Facade** - Backward compatibility wrapper with auto-detection between legacy and multi-server modes (16 tests, 153 LOC)
- **CLI Commands:** 
  - `prompt-automation mcp list-servers` - Display all registered MCP servers
  - `prompt-automation mcp list-tools` - Show available tools from all servers
  - `prompt-automation mcp call-tool <qualified_name>` - Execute tool with retry/fallback options
  - `prompt-automation mcp health` - Monitor server health status

### Changed
- **MCP Integration:** Existing single-server code continues to work unchanged via MCPService facade auto-detection
- **Export Structure:** Added `MCPService` to `prompt_automation.mcp` package exports

### Technical Details
- **Architecture Patterns:** Adapter (HTTP/Stdio), Factory (adapter creation), Router (orchestration), Facade (compatibility)
- **Performance:** <500ms parallel discovery for 5 servers, <200ms tool execution with caching
- **Cross-Platform:** Full Windows and WSL2 support with subprocess validation
- **Backward Compatible:** Zero breaking changes, gradual migration path provided

## [0.9.1] - 2025-10-24

### Added
- **GUI UX Enhancement Session (6 Minor Features)** - Comprehensive polish of single-window GUI with validation, tooltips, feedback, shortcuts, auto-clear, and consistent styling.
  - **Feature #1: Enhanced Settings Validation** - Real-time validation with clear error messages (20 tests, 100 LOC, 2.5h)
    - `SettingsValidator`: Field-level validation for hotkey, config paths, auto-clear delays
    - Inline error display with red text and ⚠️ icons next to invalid fields
    - Prevents saving invalid configurations with comprehensive error messages
  - **Feature #2: Settings Field Tooltips** - Hover-over help text for all configuration fields (15 tests, 120 LOC, 2.0h)
    - `TooltipManager`: Delay-based tooltip display with position calculation
    - Covers all 8 config fields: hotkey, config_dir, cache_ttl, auto_clear_delay, etc.
    - Prevents tooltip clutter with 500ms hover delay
  - **Feature #3: Save Confirmation Feedback** - Visual confirmation on successful settings save (7 tests, 50 LOC, 1.5h)
    - Success message in green with ✅ checkmark
    - Automatic 3-second fade to prevent status bar clutter
    - Integrated with existing status_var in config panel
  - **Feature #4: Keyboard Shortcuts Legend** - Help dialog with all keyboard shortcuts (8 tests, 220 LOC, 4.0h)
    - `ShortcutsLegend`: Modal dialog with frame-aware shortcuts (Selector/Variables/Review)
    - Categorized display: Navigation, Clipboard, Window Management
    - Accessible via Help menu and Ctrl+?/F1 hotkeys
  - **Feature #5: Status Auto-Clear Timer** - Automatic status message clearing (12 tests, 127 LOC, 4.0h)
    - `StatusManager`: Timer-based auto-clear with configurable delays (3s default, 5s errors)
    - Replaces manual timer management in config panel and review frame
    - `create_status_label()`: Convenience function for label + manager creation
    - Uses `tkinter.after()` for non-blocking timer management
  - **Feature #6: Consistent Button Styling** - Unified button design across all frames (15 tests, 171 LOC, 4.0h)
    - `button_styles.py`: Three-level hierarchy (primary/secondary/danger)
    - Color palette: PRIMARY (#0066cc blue), SECONDARY (#e0e0e0 gray), DANGER (#d32f2f red)
    - Applied to 9 buttons across 3 frames (review, collect, config panel)
    - Convenience functions: `create_primary_button()`, `create_secondary_button()`, `create_danger_button()`
  - **Session Totals**: 77 tests (100% passing), 788 LOC, 18 hours, zero regressions (194/194 GUI tests passing)
  - **Synergy**: Features create cohesive UX stack (validation → tooltips → feedback → shortcuts → auto-clear → styling)
  - **Documentation**: 6 feature docs + SESSION_SUMMARY.md archived in `docs/agentic_feature_implementation/minor_features/_archive/2025-10-24_session/`

### Changed
- `src/prompt_automation/gui/single_window/frames/review.py`: StatusManager integration + button styling (Finish=primary, Copy/Cancel=secondary)
- `src/prompt_automation/gui/single_window/frames/collect.py`: Button styling (Review▶=primary, Cancel=secondary)
- `src/prompt_automation/gui/config_manager_panel.py`: StatusManager integration + button styling (Save=primary, Reset=danger, Open/Close=secondary)

### Fixed
- Manual status timer management replaced with StatusManager (prevents timer leaks)
- Inconsistent button appearance across frames (unified with button_styles)

## [0.9.0] - 2025-10-23

### Added
- **Feature 19: Multi-Tier Caching System** - Intelligent 3-tier caching (Memory/Disk/GPU) dramatically reduces redundant LLM calls, MCP requests, and template parsing. Provides semantic deduplication, automatic cache management with configurable budgets and TTLs.
- **Feature 20: Performance & Resource Manager** - Comprehensive performance optimization infrastructure with GPU detection, async LLM inference, resource monitoring, intelligent batching, and hardware-aware profiles. Achieves 9.12x throughput improvement.
  - **DeviceManager**: Auto-detect compute device (CUDA/ROCm/MPS/CPU), VRAM monitoring (165 LOC, 8 tests)
  - **ResourceMonitor**: Real-time CPU/RAM/GPU monitoring with alert thresholds, background monitoring at 1 Hz (180 LOC, 7 tests)
  - **AsyncLLM**: Async LLM wrapper with device selection, request queue, timeout management, 2.5x faster than sync (374 LOC, 11 tests)
  - **BatchManager**: Intelligent batching with 9.12x throughput improvement (912 prompts/sec vs 100 sequential), configurable batch size and timeout (256 LOC, 8 tests)
  - **Throttler**: Resource-aware throttling with hysteresis to prevent OOM, suggests adaptive delays (190 LOC, 8 tests)
  - **ProfileManager**: 3 hardware profiles (minimal/standard/performance) with auto-detection and manual override (223 LOC, 10 tests)
  - **Integration Tests**: 7 tests validating BatchManager + Throttler + ProfileManager interaction (362 LOC)
  - **Dependencies**: requests ≥2.31.0, psutil ≥5.9.0, pynvml ≥11.5.0
  - **60 tests** (95.2% pass rate, 2 GPU tests hardware-dependent)
  - **Manual Testing**: Comprehensive test guide validated across all components
  - **Implementation**: 1,388 LOC across 7 modules, 3-day effort
  - **Performance**: 9.12x throughput (BatchManager), 2.5x latency (AsyncLLM), auto GPU selection
  - **Docker Deferred**: Sub-Feature 20.5 (containerization) deferred - not needed for desktop GUI app
- **Feature 21: Usage Analytics & Telemetry** - Privacy-first usage tracking with event logging, SQLite storage, query API, auto-sampling, and CLI dashboard. Enables data-driven optimization.
  - **EventLogger**: Log templates, LLM calls, MCP requests, errors, resources with batching (267 LOC, 9 tests)
  - **PrivacyControls**: SHA256 prompt hashing, PII sanitization, opt-out support (PA_ANALYTICS_DISABLED=1) (108 LOC, 8 tests)
  - **Database**: SQLite with WAL mode, 100MB limit, auto-rotation with gzip archives, indexes on timestamp/type (230 LOC, 11 tests)
  - **Queries**: Top templates, cache hit rate, recent errors, resource trends, latency percentiles (P50/P95/P99) (233 LOC, 6 tests)
  - **ResourceSampler**: Background thread samples ResourceMonitor at 1 Hz, auto-logs to analytics (128 LOC, 9 tests)
  - **CLI Dashboard**: 6 commands (summary, top-templates, errors, resources, export, clear) (209 LOC, 12 tests)
  - **Dependencies**: aiosqlite ≥0.19.0
  - **63 tests** (100% pass rate)
  - **Implementation**: 1,502 LOC across 7 modules, discovered 90% pre-implemented, completed remaining 10%
  - **Performance**: <5ms writes, <10ms queries, <1% CPU overhead, ~1MB/day DB growth
  - **Privacy**: No PII stored, prompts hashed, stack traces sanitized, opt-out supported
- **Minor: Cache Circuit Breaker** - L2 disk cache now includes circuit breaker pattern (CLOSED/OPEN/HALF-OPEN states) to prevent cascading failures on disk errors. After 5 consecutive failures, circuit opens and operations fail fast for 60 seconds before attempting recovery. Exposed via `cache.circuit_state()` method for monitoring. (10 tests, 100 LOC, extends Feature 19)
  - **L1Cache (Memory)**: In-memory LRU cache with TTL support, byte-accurate size tracking using `len(str.encode('utf-8'))`, <1ms hit latency (134 LOC)
  - **L2Cache (Disk)**: Persistent disk cache using diskcache with gzip compression (level 6), <10ms hit latency, 3:1 compression ratio (89 LOC)
  - **L3Cache (GPU)**: VRAM cache stub (deferred to Feature 20), provides interface contract for future GPU optimization (83 LOC)
  - **CacheManager**: Multi-tier orchestration with L1→L2→L3 fallback, automatic promotion on lower-tier hits, invalidation across all tiers (150 LOC)
  - **SemanticHasher**: Fuzzy matching using 70% Jaccard + 30% Levenshtein similarity, 35-60% threshold for related prompts, no heavy model dependency (248 LOC)
  - **CacheStats**: Performance tracking (l1_hits, l2_hits, l3_hits, misses, evictions), calculates hit_rate for analytics (79 LOC)
  - **Integration Wrappers**: CachedLLMClient (~157 LOC), CachedMCPClient (155 LOC), CachedTemplateRenderer (185 LOC)
  - **Config Integration**: `create_cache_from_config()` factory for Feature 000 integration (~60 LOC)
  - **99 tests** (100% passing): 12 L1, 13 L2, 7 L3, 17 semantic, 4 manager, 6 stats, 4 config, 8 LLM, 7 MCP, 9 template, 12 integration
  - **Manual Testing**: 10/10 scenarios passing (L1/L2 promotion, persistence, TTL, LRU, stats, semantic dedup, MCP caching, template caching, compression)
  - **Implementation**: 1,366 LOC across 11 modules, ≥85% coverage, 3-day effort (matched estimate)
  - **Performance**: L1 <1ms (5x better than <5ms target), L2 <10ms (5x better than <50ms target), compression 3:1 (1.5x better than 2:1 target)
  - **Documentation**: `docs/CACHING.md` comprehensive guide (700+ lines), architecture diagrams, API reference, configuration guide, performance tuning, troubleshooting, best practices, FAQ

### Configuration
- New cache settings in `~/.prompt-automation/config.json`:
  - `cache.enabled`: Boolean toggle (default: True)
  - `cache.memory_mb`: L1 budget (default: 256)
  - `cache.disk_mb`: L2 budget (default: 100)
  - `cache.ttl_seconds`: Default TTL (default: 3600)
- New environment variables:
  - `PA_CACHE_MEMORY_MB`: Override L1 budget
  - `PA_CACHE_DISK_MB`: Override L2 budget
  - `PA_CACHE_TTL_TEMPLATES`: Template TTL (default: 0, never expire)
  - `PA_CACHE_TTL_LLM`: LLM response TTL (default: 86400, 24 hours)
  - `PA_CACHE_TTL_MCP`: MCP tool result TTL (default: 300, 5 minutes)
  - `PA_ANALYTICS_DISABLED`: Disable analytics tracking (default: 0, enabled)

### CLI Commands
- New analytics commands:
  - `prompt-automation analytics summary`: Show overview (renders, cache rate, errors, latency)
  - `prompt-automation analytics top-templates`: Most-used templates
  - `prompt-automation analytics errors`: Recent error list
  - `prompt-automation analytics resources`: Resource usage trends
  - `prompt-automation analytics export --output file.json`: Export analytics data
  - `prompt-automation analytics clear --confirm`: Delete all analytics data

### Dependencies Unblocked
- **Feature 20 (Performance Manager)**: Can now implement L3 GPU cache using existing infrastructure
- **Feature 21 (Analytics)**: Can track cache performance via CacheStats API
- **Feature 22 (MCP Router)**: Can use CachedMCPClient for multi-server caching, AsyncLLM for orchestration, Analytics for routing decisions

### Test Suite
- **Total**: 1,160 tests passing (99.8% pass rate)
- **Known**: 2 GPU tests fail on CPU-only systems (hardware-dependent, not blocking)
- **Fixed**: Renamed 6 test files to resolve pytest import conflicts


## [0.8.0] - 2025-10-20

### Added
- **Feature 16: Template Management System** - Complete template lifecycle management with visual workflows and AI assistance. Transforms template authoring from manual JSON editing to guided creation with real-time validation.
  - **TemplateManager**: CRUD operations with automatic ID assignment, folder management, atomic file writes (245 LOC)
  - **SearchEngine**: SQLite FTS5 full-text search across title/content/tags with BM25 ranking, <100ms for 1000+ templates (187 LOC)
  - **VersionManager**: Last 10 versions per template with one-click rollback and metadata tracking (156 LOC)
  - **AIValidator**: Real-time schema validation, placeholder extraction, import/export for sharing (134 LOC)
  - **TemplateBrowser GUI**: Grid view with real-time search, toolbar (New/Edit/Delete/Import/Export), context menu (423 LOC)
  - **TemplateEditor GUI**: Dual tabs (Visual forms + JSON editor) with bidirectional sync and save validation (512 LOC)
  - **ModernTemplateWizard GUI**: 4-step guided creation (What & Why → Inputs → Structure → Review) with AI-assisted placeholder extraction and structure presets (918 LOC)
  - **Hotkey integration**: Ctrl+Shift+J opens wizard (Windows + WSL2)
  - **Options menu entries**: "Browse Templates" and "New Template Wizard"
  - **79 tests** (100% passing): 7 manager, 9 search, 8 versions, 8 validator, 10 browser, 8 editor, 23 wizard, 6 integration
  - **Implementation**: 1600 LOC across 10 modules, ≥85% coverage, 5-day effort

### Fixed
- Modal wizard prevents event leakage to parent window (grab_set + transient)
- Dark theme readability with white backgrounds on all text fields
- Template editor constructor compatibility (template_id parameter)

### Known Limitations
- Style dropdown in wizard requires mouse click (keyboard shortcuts deferred to minor feature)
- See `docs/agentic_feature_implementation/minor_features/keyboard_accessible_dropdown.md` for future fix

## Unreleased
- **Feature 014 COMPLETE**: Command Palette - Universal command executor for Obsidian vault operations via slash commands or natural language. **Core capabilities**: (1) Slash commands `/rag` (search vault), `/daily` (append to daily note), `/note` (create note), `/open` (open in Obsidian), (2) Natural language interpretation via Qwen LLM (e.g., "find notes about testing" → `/rag testing`), (3) Diff generation using `difflib.unified_diff` for write operations with approval flow, (4) Approval dialogs (CLI interactive prompt, GUI modal) before executing changes, (5) LLM location suggestions for `/note` command with "Notes/" fallback, (6) Thread-safe CommandRegistry with `threading.Lock`, (7) Graceful degradation (works without LLM, MCP client placeholder for future integration). **GUI**: New CommandFrame (Frame 4) with command entry field, scrolled result display, approval modal for diffs, Cancel button. **CLI**: New `--execute <command>` flag runs commands directly (e.g., `prompt-automation --execute "/rag test"`). **Implementation**: 1,350 LOC across 12 modules (CommandExecutor 87 LOC, CommandParser 209 LOC with shlex.split, CommandRegistry 61 LOC, 4 handlers 513 LOC, LLM client 138 LOC, GUI frame 202 LOC, CLI integration 67 LOC), 89 tests (100% passing in 0.6s), zero regressions. **Architecture**: Layered design (GUI/CLI → Executor → Parser → Registry → Handlers → MCP/LLM), synchronous API (matches existing MCP client). **Patterns Applied**: Pattern 7 (Search with Fallback Chain), Pattern 8 (AST-based code analysis), Pattern 10 (Atomic State Persistence), Pattern 12 (Hybrid Strategy with Fallback Chain). **Known Limitations**: MCP client integration pending (Feature 01 dependency), handlers use `None` placeholder with TODO comments. **Documentation**: Complete implementation summary (≤500 words), context summary (≤200 words), manual test guide (17 test scenarios across 5 suites), plan/tasks breakdown in `docs/agentic_feature_implementation/14_command_palette/`. Developed using strict TDD methodology (RED → GREEN → REFACTOR) with automated 3-phase workflow. **Status**: Implementation complete 2025-10-17, ready for archival.
- **Feature 005 COMPLETE**: Validation Runner - Automated validation system that executes all quality checks (pytest, coverage, lint, file/function size limits) for feature branches. **Core capabilities**: (1) Pytest execution with 5-minute timeout and retry logic for flaky tests, (2) Coverage validation with ≥85% threshold parsing from JSON reports, (3) Lint checks using flake8 (required) and pylint (optional), (4) File size validation (≤400 LOC per file), (5) Function size validation (≤75 LOC per function using AST parsing), (6) Parallel execution using ThreadPoolExecutor for concurrent checks, (7) Structured results dict with all_passed flag and detailed messages. **CLI**: New `--validate` flag runs complete validation suite with formatted output (e.g., `prompt-automation --validate --branch feature/my-branch`). Exit code 0 (pass) or 1 (fail). **Implementation**: 469 LOC across 5 validation modules (test_executor.py 75 LOC, coverage_checker.py 62 LOC, lint_checker.py 100 LOC, size_checker.py 89 LOC, runner.py 143 LOC), 38 tests (100% passing in 0.25s), zero regressions (695/695 tests pass). CLI integration adds +75 LOC to controller.py. **Performance**: Validation tests run in <1 second. Parallel execution reduces total check time significantly. **Patterns Applied**: Pattern 8 (AST-based code analysis for accurate function LOC), Pattern 9 (ThreadPoolExecutor for parallel execution). **Bug Fixes**: Fixed critical recursive pytest execution bug causing indefinite hangs (test mocking issue), fixed 6 test regressions from background hotkey disable. **Documentation**: Complete implementation summary, manual test guide, plan/tasks breakdown in `_archive/2025-10-04_feature_05_validation_runner/`. Developed using strict TDD methodology (RED → GREEN → REFACTOR) with automated 3-phase workflow. **Status**: Production-ready, archived 2025-10-04.
- **Feature 004 REJECTED**: Feature Pattern Templates - Rejected due to low priority and uncertain ROI. Existing resources (AGENTS.md patterns, Knowledge Base, existing code examples) already provide sufficient guidance. Maintenance burden not justified by unclear benefit. Archived to `_archive/04_feature_patterns/` for potential future reconsideration if clear need emerges.
- **Feature 003 COMPLETE**: Knowledge Base - Pre-answered questions system storing default answers to common feature implementation questions. **Core capabilities**: (1) Default answers by category (architecture, testing, gui, rollout, performance, security) sourced from AGENTS.md, (2) Feature-specific overrides for per-feature customization (meta_prompt, workspace_context_gatherer, copilot_agent), (3) Graceful error handling with fallback to empty dict on missing/corrupt JSON, (4) JSON schema validation (version 1.0) with backward compatibility warnings, (5) CLI inspection via `--show-defaults <category|all>` command, (6) Python API: `get_default_answer(category, key, feature_id)` and `get_all_defaults(category, feature_id)`. **CLI**: New `--show-defaults` flag displays KB contents as JSON (e.g., `prompt-automation --show-defaults testing`). **Implementation**: 147 LOC loader module, 62 LOC JSON data file, 140 LOC tests (10 tests, 100% passing), CLI integration in controller.py. All file sizes ≤400 LOC. Zero regressions (666/671 tests pass, 5 pre-existing failures unrelated to feature). **Performance**: KB loads in <10ms, <1MB memory footprint, no external dependencies (pure stdlib). **Architecture**: Simple loader pattern with feature override precedence, quarterly review schedule for defaults alignment. **Documentation**: README.md updated with usage examples, implementation summary in `docs/agentic_feature_implementation/03_knowledge_base/implementation_summary.md`. Developed using strict TDD methodology (RED → GREEN → REFACTOR) with automated 3-phase workflow. **Integration**: Ready for meta-prompt system (Feature 16) to use in Phase 1 question pre-answering. **Status**: Implementation complete, all 10 acceptance criteria met, ready for archival.
- **Feature 001 COMPLETE**: Workspace Context Gatherer - Intelligent workspace analysis system that provides LLM-ready context for feature implementation. **Core capabilities**: (1) Keyword extraction from feature specs with stop word filtering (max 10 keywords), (2) Codebase search using fallback chain (ripgrep → git-grep → pathlib) with timeout handling, (3) AST-based workspace indexing for Python files (functions, classes, imports), JSON/Markdown parsing, (4) Optional Obsidian MCP integration (feature-flagged, default OFF via `PA_WORKSPACE_CONTEXT_OBSIDIAN_ENABLED`), (5) AGENTS.md constraint extraction with section headers, (6) Related test discovery matching feature keywords, (7) Context formatting as structured Markdown. **CLI**: New `--index-workspace` flag builds and saves workspace index to `.prompt-automation-index.json` (typical output: "✅ Indexed 245 files"). **Implementation**: 745 LOC (search.py 141 LOC, indexer.py 270 LOC, context_gatherer.py 331 LOC), 43 tests (40 workspace + 3 CLI, all passing), 1 skipped (ripgrep not installed). All file sizes ≤400 LOC. Zero regressions (656/661 tests pass, 5 pre-existing failures unrelated to feature). **Performance**: Context gathering <5 seconds validated. **Architecture**: 3-module design with Pattern 7 (Search with Fallback Chain), Pattern 8 (AST-Based Code Analysis). **Documentation**: Inline docstrings, task breakdown in `docs/agentic_feature_implementation/01_workspace_context_gatherer/tasks.md`. Developed using strict TDD methodology (RED → GREEN → REFACTOR) with automated 3-phase workflow. **Status**: Implementation complete, pending manual testing and archival.
- **Feature 000 COMPLETE**: Smart Settings & Config Management system providing unified configuration with hot-reload, profiles, and environment overrides. **Backend**: ConfigManager singleton with type-safe Pydantic validation (10 models), atomic file writes with backup, 300ms debounced hot-reload, and 3 profiles (lightweight/standard/performance). Configuration file: `~/.prompt-automation/config.json`. Environment variables: `PA_*` prefix (e.g., `PA_LLM__PORT=9090`). **GUI**: New Configuration Manager panel (Options → Configuration Manager...) provides visual settings discovery, automatic file creation, profile switching (radio buttons), hot-reload toggle, validation with error messages, env var override display (blue labels), Save/Reset/Open File actions. All settings organized by category tabs (LLM, Cache, Performance, Analytics, Features). **Implementation**: 766 LOC backend + 306 LOC GUI, 69 tests (100% passing), zero regressions (612/614 total tests pass, 2 pre-existing failures). **Documentation**: `docs/CONFIGURATION.md`, `docs/CONFIG_MIGRATION.md`. Replaces Feature 15 (Unified Settings System). Foundational infrastructure for Features 16-22. Developed using TDD with automated workflow (Phase 1 Discovery → Phase 2 TDD Implementation → Phase 3 Archival). **Status**: Production-ready, archived 2025-10-03.
- **UX improvement**: Added Python Environment Info dialog to Help menu (Help → Python Environment Info...). Displays Python executable, version, sys.path, pydantic availability, and ConfigManager status in scrollable window. User-triggered only (silent by default), preventing automatic popups and desktop glitching. Implementation: 75 LOC new dialog module, +11 LOC menu integration, removed standalone test script. Documentation: `docs/PYTHON_ENV_INFO_DIALOG.md`.
- **Bug fix**: Fixed universal GUI toggle persistence issue where checkboxes would flash checked then immediately revert to unchecked state. Root cause: tkinter BooleanVar/StringVar objects were being garbage collected, causing widgets to lose variable bindings. Solution: Store all GUI variables as window/frame attributes to maintain strong Python references. Affects all settings panels (Options → Settings, Options → Configuration Manager). Implementation: +15 LOC across settings_panel.py and config_manager_panel.py, 4 new tests for toggle persistence, 587/587 tests passing. Documentation: `docs/GUI_TOGGLE_PERSISTENCE_FIX.md`. Developed using TDD methodology.
- Added cancel button functionality to single-window GUI workflow: Users can now abort from Variables or Review stages and return to template selector. Cancel button clears all workflow state (template, variables, stage) to prevent stale data. Implementation: ~18 LOC added across controller and frame builders, 5 new tests, zero regressions (507/507 tests pass). Feature developed using Test-Driven Development with automated workflow system (Phase 1: Discovery → Phase 2: TDD Implementation → Phase 3: Archival).
- Added `obsidian_notes_tools_enabled` global placeholder (default `true`) as the kill switch for Obsidian notes tooling; set to `false` in packaged globals or overrides to pause the integrations across CLI, GUI, and MCP during rollback.
- Clarified MCP template search resolution: metadata paths now iterate `PROMPTS_SEARCH_PATHS`, documenting that packaged prompts under `src/prompt_automation/prompts/...` resolve automatically.
- Prepared hierarchical variable management for rollout: added end-to-end acceptance coverage for migration, resolver, GUI CRUD, and Espanso tagging; documented release procedures and troubleshooting in `docs/hierarchical_variable_storage.md`; recorded performance metrics confirming we remain below the 50 ms render budget with <5% P95 regression headroom.
- Added MCP integration documentation covering the fake Qwen stub, MCP server launch, JSON-RPC validation steps, and llama.cpp model placement in `docs/MCP_INTEGRATION.md`; linked the guide from installation scripts, README, settings UI, and manual validation checklists.

## 0.6.7 - 2025-09-17
- (no changes yet)

## 0.6.6 - 2025-09-17
- Added: Manual packaging wizard accessible from the GUI (Options → Packaging). The dialog runs the test suite, executes the existing packagers, tags the repo, and uploads installers to GitHub releases. Preferences for verbose logging persist to `Settings/settings.json`, and a new background service streams structured logs to `~/.prompt-automation/logs/manual-packaging-*.log`. Documentation lives in `docs/MANUAL_PACKAGING.md`.
- Added: Experimental native installer tooling under `packagers/` with Windows (PyInstaller) and macOS (py2app + `hdiutil`) builds. New CLI (`python packagers/build_all.py`) orchestrates artifact creation, enforces the 350-line helper limit, and documents manual verification steps in `docs/PACKAGING.md`. GitHub Actions now runs a dry-run on push and exposes manual jobs for platform packaging once runners are provisioned.
- Bug fix: stabilize CLI fallback for file placeholders with invalid pre‑supplied paths and no template binding; initialize labels early to prevent crashes and allow deterministic skip (None) without repeated prompts.
- Added: Placeholder-empty fast-path in single-window GUI. When a template has no effective input placeholders (placeholders missing/`null`/`[]` or only reminder/link/invalid specs), the app bypasses the variable collection stage and opens the final output view directly. Outputs render with the same pipeline as the normal review stage and auto-copy behavior remains unchanged. Observability: one debug log line (`fastpath.placeholder_empty`) emitted on activation (no template content logged). Kill-switch: set `PROMPT_AUTOMATION_DISABLE_PLACEHOLDER_FASTPATH=1` or add `"disable_placeholder_fastpath": true` to `Settings/settings.json` to disable. Backward compatible: templates with placeholders are unaffected.
- Added: Recent history for executed templates (last 5, persisted in `~/.prompt-automation/recent-history.json`). New Options → Recent history panel lists newest→oldest with preview and Copy action. Feature flag `PROMPT_AUTOMATION_HISTORY` (and `Settings/settings.json: recent_history_enabled`) controls enablement; default enabled. Redaction hook via `PROMPT_AUTOMATION_HISTORY_REDACTION_PATTERNS` or `recent_history_redaction_patterns` in settings. Purge behavior when disabled via `PROMPT_AUTOMATION_HISTORY_PURGE_ON_DISABLE` or `recent_history_purge_on_disable`. Defensive parsing, atomic writes, and corruption quarantine. No changes to existing flows besides post-success appends.
- Added: Optional hierarchical template browsing behind a feature flag. A new scanner (`TemplateHierarchyScanner`) renders physical on‑disk folders as a tree with caching and safe defaults. CRUD operations (`TemplateFSService`) provide create/rename/move/delete for folders and templates with path sandboxing and name validation. CLI gains `--tree` (and `--flat`) modifiers for `--list`. Observability: structured INFO logs for scan and CRUD events. Backward‑compatible: flat listing and public APIs unchanged by default.
- Added: CLI name filtering via `--filter <pattern>` for both flat and tree listings, allowing quick narrowing of templates and folders.
 - Added: Read‑only “reminders” support at template root and placeholder level. Inline reminder text renders beneath inputs in the single‑window GUI, with a collapsible panel presenting template/global reminders. CLI prints template/global reminders once before the first prompt and placeholder reminders before each query. Feature flag `PROMPT_AUTOMATION_REMINDERS` (and `Settings/settings.json: reminders_enabled`) controls enablement; default is enabled. Observability: single `reminders.summary` log per template summarizing counts.
- Single-window GUI: restored bullet/checklist auto-formatting for multiline placeholders via lightweight key bindings.
- Reference file picker now renders only when a `reference_file` placeholder exists and appears inline beneath it (no global toolbar clutter).
- Improved accessibility: focus changes auto-scroll to reveal the focused input; added debug logs for bullet insertion, inline ref picker instantiation, and scroll adjustments.
- Added feature flag `PA_DISABLE_SINGLE_WINDOW_FORMATTING_FIX=1` to temporarily disable the new formatting/scroll and revert to legacy global picker layout.
- Added Dark Mode & theming infrastructure:
  - New `dark` theme with accessible palette (AA contrast).
  - Runtime toggle `Ctrl+Alt+D` with persistence.
  - CLI override `--theme=<light|dark|system>` and `--persist-theme`.
  - Safe defaults: light remains unchanged; disable via `enable_theming=false`.
  - Minimal Tk-based applier (no heavy deps) + ANSI formatter for CLI headings.
  - Extension guide for registering additional themes.
- Unified single-window UI now matches legacy feature set and is the default
  experience. Set `PROMPT_AUTOMATION_FORCE_LEGACY=1` to restore the old
  multi-window dialogs.
- Removed experimental `PROMPT_AUTOMATION_SINGLE_WINDOW` toggle.
- Documented modular service layer (`template_search`, `multi_select`,
  `variable_form`, `overrides`, `exclusions`).

## 0.4.4 - 2025-08-18
Comprehensive GUI refactor + quality-of-life enhancements, consolidating prior selector modernization and adding new safety / clarity features.

### Highlights
- Unified single-window workflow (`gui/single_window.py`): persistent root window orchestrating selection → (optional combined multi-select preview) → variable collection → inline review with geometry persistence.
- Centralized Options menu (`gui/options_menu.py`) shared between embedded selector and single-window, eliminating duplicated menu construction logic.
- Inline reference file viewer for `reference_file` placeholder (markdown-ish rendering, truncation for large files, copy/reset/refresh controls & rich keybindings).
- Multi-select synthetic template preview stage: after Finish Multi, users see a read-only combined template before placeholder prompts begin (increases safety & orientation for large batch operations).
- Append targets preview: Review stage toolbar button opens read-only inspectors for each `append_file` / `*_append_file` target before commit.
- Conditional Copy Paths button: Appears in review only when any `*_path` tokens are present in the variable map (avoids UI noise).
- New recursion toggle hotkey (Ctrl+L) for fast recursive / non-recursive search switching without leaving the keyboard.
- Geometry persistence (`~/.prompt-automation/gui-settings.json`) ensures window position/size consistency across runs.

### Hotkey & Selector Improvements (carried forward into 0.4.x)
- Enhanced global hotkey system: GUI-first launch with terminal fallback across Windows (AutoHotkey), Linux (espanso / .desktop fallback), and macOS (AppleScript) with dependency validation.
- Interactive `--assign-hotkey` command + per-user hotkey mapping file.
- Added `--update` command to refresh hotkey configuration / verify dependencies.
- Numeric shortcut management & renumber dialog; digits 0–9 open mapped templates instantly.
- Preview toggle (Ctrl+P) reuses an existing preview window rather than spawning multiples.

### Selector & Navigation
- Modular selector (`gui/selector/`) replaces monolith; legacy wrapper retained for backward import stability.
- Hierarchical folder navigation with breadcrumb and Backspace up-navigation.
- Recursive full-content AND-token search (path, title, placeholder names, body) with live incremental filtering; non-recursive mode toggle + keyboard focus retention.
- Quick keyboard accelerators: `s` focus search, Enter open/select, arrow key navigation, Ctrl+P preview, Ctrl+L recursion toggle.
- Multi-select synthesis produces an id = -1 ephemeral template (original sources untouched).

### Placeholders & Overrides
- Multi-file placeholder system: independent persistence (`path` + `skip`) per (template, placeholder name) mirrored to `prompts/styles/Settings/settings.json`.
- Manage Overrides dialog for inspecting/removing persisted file paths & simple value overrides.
- Inline `reference_file` viewer supersedes legacy modal; other file placeholders still use modal flow (future extensibility path).
- Optional `append_file` / `*_append_file` targets append rendered output post-confirmation; preview added this release for transparency.
- Conditional injection of `*_path` tokens only when referenced in template body to keep variable map lean.

### Review & Output
- Single-window inline review frame: edit rendered text directly; Ctrl+Enter to finish & paste; Ctrl+Shift+C copy without closing; Esc cancel.
- Append targets preview & Copy Paths buttons enhance auditability before finalizing.
- Automatic clipboard copy & paste keystroke emission (with fallback to copy-only on failure).

### Documentation Updates
- HOTKEYS.md: Added Ctrl+L toggle, multi-select preview stage, append targets preview, conditional Copy Paths description.
- CODEBASE_REFERENCE.md: Added `options_menu.py`, expanded single-window architecture, updated feature matrix, toolbar notes.
- VARIABLES_REFERENCE.md: Documented append targets preview & conditional Copy Paths; clarified inline `reference_file` behavior.
- CHANGELOG now reflects 0.4.4 unified release (previous “Unreleased” content incorporated here).

### Internal / Architecture
- Introduced `options_menu.configure_options_menu()` for DRY menu creation & accelerator binding mapping.
- Added multi-stage orchestration within `SingleWindowApp` with explicit stage swapping helper `_swap_stage()`.
- Title wrap-length auto-adjust bound to `<Configure>` events for responsive UX.
- Centralized geometry save/load helpers with defensive IO handling.
- Guarded fallbacks to legacy multi-window path if single-window initialization fails.

### Migration / Upgrade Notes
- No breaking template schema changes. Existing templates & overrides remain compatible.
- Legacy modal `reference_file` viewer still available for non-single-window flows; inline path is automatic in single-window mode.
- If you previously scripted selector menu modifications, update integrations to use `configure_options_menu` rather than manual `tk.Menu` mutation.
- Duplicate 0.2.1 entries in historical section left untouched (will be rationalized in a future housekeeping release).

### Testing & Stability
- Existing 22 test cases pass (no regressions introduced by refactor).
- GUI code paths wrapped in defensive try/except blocks; failures fall back to legacy flows where practical.

### Future Considerations (Not Yet Implemented)
- Optional inline mode for additional file placeholders.
- Filter / transform pipeline (e.g. length, case, diff) for future placeholder post-processing.
- Lightweight plugin hook for augmenting Options menu via `extra_items` callback.

## 0.2.1 - 2025-08-01
- Enhanced cross-platform compatibility for WSL2/Windows environments
- Fixed Unicode character encoding issues in PowerShell scripts  
- Improved WSL path detection and temporary file handling
- Enhanced prompts directory resolution with multiple fallback locations
- Updated all installation scripts for better cross-platform support
- Fixed package distribution to include prompts directory in all installations
- Added comprehensive error handling for missing prompts directory
- Made Windows keyboard library optional to prevent system hook errors
- Improved error handling for keyboard library failures with PowerShell fallback

## 0.2.1 - 2024-05-01
- Documentation overhaul with install instructions, template management guide and advanced configuration.
- `PROMPT_AUTOMATION_PROMPTS` and `PROMPT_AUTOMATION_DB` environment variables allow custom locations for templates and usage log.
