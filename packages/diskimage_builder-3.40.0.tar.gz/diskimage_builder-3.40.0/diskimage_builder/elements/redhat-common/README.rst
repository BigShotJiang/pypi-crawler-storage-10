=============
redhat-common
=============
Image installation steps common to RHEL, CentOS, Fedora and openEuler.

Requirements:

If used to build an image form a cloud image compress with xz
(the default in centos), this element uses "unxz" to decompress
the image. Depending on your distro you may need to install either
the xz or xz-utils package.

Environment Variables
---------------------

DIB_LOCAL_IMAGE
  :Required: No
  :Default: None
  :Description: Use the local path of a qcow2 cloud image. This is useful in
   that you can use a customized or previously built cloud image from
   diskimage-builder as input. The cloud image does not have to have been built
   by diskimage-builder. It should be a full disk image, not just a filesystem
   image.
  :Example: ``DIB_LOCAL_IMAGE=rhel-9.4-x86_64-kvm.qcow2``

DIB_DISABLE_KERNEL_CLEANUP
  :Required: No
  :Default: 0
  :Description: Specify if kernel needs to be cleaned up or not. When set to
   true, the bits that cleanup old kernels will not be executed.
  :Example: DIB_DISABLE_KERNEL_CLEANUP=1
