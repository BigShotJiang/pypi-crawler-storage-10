def general_settings(model):
    return model.root['settings']['ugm_general']


def localmanager_settings(model):
    return model.root['settings']['ugm_localmanager']
