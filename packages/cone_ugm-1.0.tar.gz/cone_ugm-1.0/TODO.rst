TODO
====

- Improve login form field factory to hook up login extractor to related
  login name form field widget.

- complete test coverage.

- document principal form field customization.
