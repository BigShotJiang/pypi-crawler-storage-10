# Alliance Auth Wanderer Sync

This app synchronizes users from your Alliance Auth instance to a Wanderer access list.

## Installation

1.  Copy the `aa-wanderer-sync` directory to the root of your Alliance Auth installation.
2.  Add `'aa_wanderer_sync'` to the `INSTALLED_APPS` in your `myauth/settings/local.py` file.
3.  Run `python manage.py migrate` to create the necessary database tables.
4.  Restart your Alliance Auth server.

## Configuration

1.  Log in to your Alliance Auth instance as an administrator.
2.  Navigate to the "Wanderer Sync" settings page (e.g., `https://your-auth-url/wanderer_sync/settings/`).
3.  Enter your Wanderer API key and the ID of the ACL you want to sync.
4.  Enable the synchronization.

The synchronization will run automatically every hour.
