# setup.py
import os
from setuptools import setup, find_packages

with open(os.path.join(os.path.dirname(__file__), 'README.md')) as readme:
    README = readme.read()

# allow setup.py to be run from any path
os.chdir(os.path.normpath(os.path.join(os.path.abspath(__file__), os.pardir)))

setup(
    name='aa-wanderer-sync',
    version='0.1.0', # Make sure this matches your __version__ in aa-wanderer-sync/__init__.py
    packages=find_packages('aa-wanderer-sync'), # Specify the base directory for finding packages
    include_package_data=True,
    license='MIT License',  # Choose an appropriate license
    description='An Alliance Auth app that synchronizes users to a Wanderer access list.',
    long_description=README,
    url='https://www.example.com/', # Replace with your project's URL
    author='Your Name', # Replace with your name
    author_email='your.email@example.com', # Replace with your email
    classifiers=[
        'Environment :: Web Environment',
        'Framework :: Django',
        'Framework :: Django :: 3.2', # Adjust to your Django version
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License', # Adjust to your license
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3.9', # Adjust to your Python version
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Topic :: Internet :: WWW/HTTP',
        'Topic :: Internet :: WWW/HTTP :: Dynamic Content',
    ],
    install_requires=[
        # List any Python dependencies your app needs here, e.g.,
        # 'requests',
    ],
)