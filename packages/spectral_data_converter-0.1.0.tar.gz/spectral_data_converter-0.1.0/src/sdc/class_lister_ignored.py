from typing import List, Dict


# classes that we don't want to be listed
def list_classes() -> Dict[str, List[str]]:
    return {
        "seppl.io.Filter": [
            "kasperl.filter.AnnotationsFromStorage",
            "kasperl.filter.AnnotationsToStorage",
        ],
    }
