from setuptools import setup, find_packages

setup(
    name="nquencolor",
    version="0.1.0",
    packages=find_packages(),
    description="simple module to colorate your text",
    author="Nqùen Tũng",
    python_requires=">3.8",
 )