def red(text):
    return f"\033[91m{text}\033[0m"
 
def green(text):
    return f"\033[92m{text}\033[0m"
    
def blue(text):
    return f"\033[94m{text}\033[0m"