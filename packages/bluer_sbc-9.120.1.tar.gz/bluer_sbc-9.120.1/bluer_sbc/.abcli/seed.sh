#! /usr/bin/env bash

bluer_ai_source_caller_suffix_path /seed
