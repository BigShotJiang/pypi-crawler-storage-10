#! /usr/bin/env bash

function bluer_sbc_parts_cd() {
    cd $abcli_path_git/assets2/bluer-sbc/parts
}
