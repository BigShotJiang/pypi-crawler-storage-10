# DeepSeekPowSolver

A Python module for solving DeepSeek proof-of-work tasks.

## Installation

```bash
pip install DeepSeekPowSolver
