from setuptools import setup, find_packages

setup(
    name="DeepSeekPowSolver",  
    version="0.1.0",
    author="Levi",
    
    description="DeepSeek Proof-of-Work Solver",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://t.me/Q_b_h",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)
