#!/usr/bin/env python3

__import__("potodo.potodo").potodo.main()
