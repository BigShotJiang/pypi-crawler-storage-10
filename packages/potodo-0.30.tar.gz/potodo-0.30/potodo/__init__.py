#!/usr/bin/env python3

__author__ = """Jules Lasne"""
__email__ = "jules.lasne@gmail.com"
__version__ = "0.30"
