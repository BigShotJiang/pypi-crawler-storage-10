# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ModifyWatermarkRule:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'rule_name': 'str',
        'location': 'WatermarkLocation'
    }

    attribute_map = {
        'rule_name': 'rule_name',
        'location': 'location'
    }

    def __init__(self, rule_name=None, location=None):
        r"""ModifyWatermarkRule

        The model defined in huaweicloud sdk

        :param rule_name: 水印规则名称，如果不填说明不修改。
        :type rule_name: str
        :param location: 
        :type location: :class:`huaweicloudsdklive.v1.WatermarkLocation`
        """
        
        

        self._rule_name = None
        self._location = None
        self.discriminator = None

        if rule_name is not None:
            self.rule_name = rule_name
        self.location = location

    @property
    def rule_name(self):
        r"""Gets the rule_name of this ModifyWatermarkRule.

        水印规则名称，如果不填说明不修改。

        :return: The rule_name of this ModifyWatermarkRule.
        :rtype: str
        """
        return self._rule_name

    @rule_name.setter
    def rule_name(self, rule_name):
        r"""Sets the rule_name of this ModifyWatermarkRule.

        水印规则名称，如果不填说明不修改。

        :param rule_name: The rule_name of this ModifyWatermarkRule.
        :type rule_name: str
        """
        self._rule_name = rule_name

    @property
    def location(self):
        r"""Gets the location of this ModifyWatermarkRule.

        :return: The location of this ModifyWatermarkRule.
        :rtype: :class:`huaweicloudsdklive.v1.WatermarkLocation`
        """
        return self._location

    @location.setter
    def location(self, location):
        r"""Sets the location of this ModifyWatermarkRule.

        :param location: The location of this ModifyWatermarkRule.
        :type location: :class:`huaweicloudsdklive.v1.WatermarkLocation`
        """
        self._location = location

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ModifyWatermarkRule):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
