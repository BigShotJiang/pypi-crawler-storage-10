from setuptools import setup, find_packages
from pathlib import Path

# Read long description from README.md if available
this_directory = Path(__file__).parent
long_description = ""
readme_path = this_directory / "README.md"
if readme_path.exists():
    long_description = readme_path.read_text()

setup(
    name="coeaidpml",
    version="8.0.0",
    description="LLM-powered schema analyzer and ML use case discovery engine for OCI AIDP",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Nikesh Gogia",
    author_email="you@example.com",  # optional but helpful
    url="https://pypi.org/project/coe-aidp-ml-discovery/",  # or your GitHub
    packages=find_packages(),
    license="MIT",  # or "Proprietary"
    install_requires=[],
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries",
        "Intended Audience :: Developers",
    ],
    keywords="oci aidp pyspark llm schema discovery data ai ml",
)
# pypi-AgEIcHlwaS5vcmcCJGM0NWFjZTE2LTBjYmUtNDliMy04ZGQyLTgwYzY5MDg5NjdmZQACEVsxLFsiY29lYWlkcG1sIl1dAAIsWzIsWyI0YjI4YWI5OC01N2NmLTRhNWEtYThjOS05OGNmNTJiNDgxZjgiXV0AAAYgG2zsX_aWf45mpZZvu_MEl8MH2TvDWskhfmLruzpnOOw