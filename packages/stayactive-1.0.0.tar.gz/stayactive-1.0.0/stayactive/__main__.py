import pyautogui
import random
import time

MOVE_INTERVAL_SECONDS = 3  
MIN_PIXELS_TO_MOVE = 1     
MAX_PIXELS_TO_MOVE = 15    
KEY_PRESS_INTERVAL = 20
def main():
    pyautogui.FAILSAFE = False
    print("--- Workspace Monitor Started ---")
    print(f"Monitoring workspace activity every {MOVE_INTERVAL_SECONDS} seconds.")
    print("Press Ctrl-C in the terminal to stop the program.")

    move_count = 0
    try:
        while True:
            time.sleep(MOVE_INTERVAL_SECONDS)
            screenWidth, screenHeight = pyautogui.size()
            current_x, current_y = pyautogui.position()
            direction_x = random.choice([-1, 1])
            direction_y = random.choice([-1, 1])
            offset_x = direction_x * random.randint(MIN_PIXELS_TO_MOVE, MAX_PIXELS_TO_MOVE)
            offset_y = direction_y * random.randint(MIN_PIXELS_TO_MOVE, MAX_PIXELS_TO_MOVE)
            new_x = current_x + offset_x
            new_y = current_y + offset_y
            new_x = max(0, min(screenWidth - 1, new_x))
            new_y = max(0, min(screenHeight - 1, new_y))
            pyautogui.moveTo(new_x, new_y, duration=0.25)
            print(f"Cursor position updated: ({new_x}, {new_y})")
            
            move_count += 1
            if move_count % KEY_PRESS_INTERVAL == 0:
                pyautogui.press('shift')
                print("System refresh triggered.")
    except KeyboardInterrupt:
        print("\n--- Workspace Monitor Stopped ---")
    except Exception as e:
        print(f"\nAn error occurred: {e}")