use pyo3::{prelude::*, types::PyBytes};
use ringbuf::{
    traits::{Consumer, Producer, Split},
    HeapCons, HeapProd, HeapRb,
};
use std::sync::Mutex;

#[pyclass]
struct FrameRing {
    prod: Mutex<HeapProd<Vec<u8>>>,
    cons: Mutex<HeapCons<Vec<u8>>>,
}

#[pymethods]
impl FrameRing {
    #[new]
    fn new(capacity: usize) -> Self {
        let rb = HeapRb::new(capacity);
        let (p, c) = rb.split();
        Self {
            prod: Mutex::new(p),
            cons: Mutex::new(c),
        }
    }
    fn push(&self, frame: Vec<u8>) -> bool {
        self.prod.lock().unwrap().try_push(frame).is_ok()
    }
    fn pop<'p>(&self, py: Python<'p>) -> Option<Bound<'p, PyBytes>> {
        self.cons
            .lock()
            .unwrap()
            .try_pop()
            .map(|v| PyBytes::new(py, &v))
    }
}

#[pymodule]
fn rust_queue(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<FrameRing>()?;
    Ok(())
}
