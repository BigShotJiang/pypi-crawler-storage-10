import os
import sys
import time
import zipfile
import subprocess
import shutil
import requests
import psutil
import socket
import yaml
import json
import hashlib
from pathlib import Path
from typing import List, Dict, Optional, Set, Any, Callable, Tuple
from dataclasses import dataclass
from datetime import datetime
import threading


# 单例端口管理器（服务类插件端口记录）
class PortManager:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.port_map = {}  # {插件名: 端口号}
        return cls._instance

    def get_port(self, plugin_name: str) -> Optional[int]:
        return self.port_map.get(plugin_name)

    def set_port(self, plugin_name: str, port: int) -> None:
        self.port_map[plugin_name] = port

    def clear_port(self, plugin_name: str) -> None:
        if plugin_name in self.port_map:
            del self.port_map[plugin_name]

    def clear_all(self) -> None:
        self.port_map.clear()


# 版本信息数据类
@dataclass
class VersionInfo:
    version: str
    download_url: str
    release_notes: str
    release_date: str
    file_size: int
    md5_hash: str = ""


# 插件配置数据类
@dataclass
class PluginConfig:
    name: str
    url: str
    extract_folder: str
    app_relative_path: str
    is_service: bool = False  # 是否为服务类型插件
    current_version: str = "1.0.0"  # 当前版本
    version_check_url: str = ""  # 版本检查URL
    auto_update: bool = False  # 是否自动更新


class PluginManager:
    def __init__(self, config: Dict[str, Any] = None, config_path: str = "config.yaml"):
        """通过 YAML 配置文件初始化插件管理器"""
        self.config_path = Path(config_path)
        self.config = config if config is not None else self._load_yaml_config()  # 加载 YAML 配置
        self.plugin_install_dir = Path(self.config.get('plugin_install_dir', 'plugins'))
        self.remote_config_url = self.config.get('remote_config_url', '')  # 远程配置URL
        self.auto_check_updates = self.config.get('auto_check_updates', True)

        self.port_manager = PortManager()
        self.version_cache_file = self.plugin_install_dir / "version_cache.json"
        self.version_cache = self._load_version_cache()

        # 确保目录存在
        self._ensure_dir(self.plugin_install_dir)

        # 加载插件配置
        self.plugins = self._load_plugin_configs()

        # 同步远程配置（如果有）
        if self.remote_config_url:
            self.sync_remote_config()

        # 启动自动更新检查（后台线程）
        if self.auto_check_updates:
            self._start_auto_update_check()

    def _load_yaml_config(self) -> Dict:
        """加载并解析 YAML 配置文件"""
        if not self.config_path.exists():
            # 创建默认配置
            default_config = {
                'plugin_install_dir': 'plugins',
                'remote_config_url': '',
                'auto_check_updates': True
            }
            self._save_config_to_file(default_config)
            return default_config

        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f) or {}
        except yaml.YAMLError as e:
            raise ValueError(f"YAML 配置解析错误: {str(e)}")

    def _load_plugin_configs(self) -> List[PluginConfig]:
        """从插件目录加载所有插件的配置"""
        plugins = []

        # 扫描插件目录中的所有子目录
        for plugin_dir in self.plugin_install_dir.iterdir():
            if plugin_dir.is_dir():
                config_file = plugin_dir / "plugin.yaml"
                if config_file.exists():
                    try:
                        with open(config_file, 'r', encoding='utf-8') as f:
                            plugin_data = yaml.safe_load(f)

                        if plugin_data and 'name' in plugin_data:
                            plugin_config = PluginConfig(
                                name=plugin_data['name'],
                                url=plugin_data['url'],
                                extract_folder=plugin_data['extract_folder'],
                                app_relative_path=plugin_data['app_relative_path'],
                                is_service=plugin_data.get('is_service', False),
                                current_version=plugin_data.get('current_version', '1.0.0'),
                                version_check_url=plugin_data.get('version_check_url', ''),
                                auto_update=plugin_data.get('auto_update', False)
                            )
                            plugins.append(plugin_config)
                            print(f"加载插件配置: {plugin_config.name}")

                    except Exception as e:
                        print(f"加载插件配置文件 {config_file} 失败: {str(e)}")

        print(f"共加载 {len(plugins)} 个插件配置")
        return plugins

    def _save_plugin_config(self, plugin_config: PluginConfig) -> None:
        """保存单个插件的配置到其目录下的 plugin.yaml 文件"""
        plugin_dir = self.plugin_install_dir / plugin_config.extract_folder
        config_file = plugin_dir / "plugin.yaml"

        # 确保插件目录存在
        self._ensure_dir(plugin_dir)

        config_data = {
            'name': plugin_config.name,
            'url': plugin_config.url,
            'extract_folder': plugin_config.extract_folder,
            'app_relative_path': plugin_config.app_relative_path,
            'is_service': plugin_config.is_service,
            'current_version': plugin_config.current_version,
            'version_check_url': plugin_config.version_check_url,
            'auto_update': plugin_config.auto_update
        }

        try:
            with open(config_file, 'w', encoding='utf-8') as f:
                yaml.dump(config_data, f, allow_unicode=True, indent=2)
            print(f"保存插件配置: {plugin_config.name} -> {config_file}")
        except Exception as e:
            print(f"保存插件配置失败 {plugin_config.name}: {str(e)}")

    def _load_version_cache(self) -> Dict[str, Any]:
        """加载版本缓存"""
        if self.version_cache_file.exists():
            try:
                with open(self.version_cache_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    def _save_version_cache(self) -> None:
        """保存版本缓存"""
        try:
            with open(self.version_cache_file, 'w', encoding='utf-8') as f:
                json.dump(self.version_cache, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"保存版本缓存失败: {str(e)}")

    def _ensure_dir(self, dir_path: Path) -> None:
        if not dir_path.exists():
            dir_path.mkdir(parents=True, exist_ok=True)
            print(f"创建目录: {dir_path}")

    def _get_free_port(self) -> int:
        """获取随机可用端口"""
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('', 0))
            return s.getsockname()[1]

    def _start_auto_update_check(self) -> None:
        """启动自动更新检查后台线程"""

        def check_updates_background():
            while True:
                try:
                    # 每6小时检查一次更新
                    time.sleep(6 * 3600)
                    self.check_all_updates(background=True)
                except Exception as e:
                    print(f"后台更新检查失败: {str(e)}")

        thread = threading.Thread(target=check_updates_background, daemon=True)
        thread.start()

    def sync_remote_config(self) -> bool:
        """同步远程配置文件"""
        if not self.remote_config_url:
            return False

        try:
            print("正在同步远程配置...")
            response = requests.get(self.remote_config_url, timeout=10)
            response.raise_for_status()
            remote_plugins_data = response.json()

            # 检查配置是否有更新
            if self._has_config_changed(remote_plugins_data):
                print("发现远程配置更新，正在应用...")
                self._apply_remote_config(remote_plugins_data)
                print("远程配置同步完成")
                return True
            else:
                print("远程配置无更新")
                return False

        except Exception as e:
            print(f"同步远程配置失败: {str(e)}")
            return False

    def _has_config_changed(self, remote_plugins_data: Dict[str, Any]) -> bool:
        """检查远程配置是否有变化"""
        # 简单的配置变化检查：比较插件数量或版本
        local_plugins = {p.name: p for p in self.plugins}
        remote_plugins = remote_plugins_data.get('plugins', {})

        if len(local_plugins) != len(remote_plugins):
            return True

        # 检查插件版本变化
        for plugin_name, remote_plugin in remote_plugins.items():
            local_plugin = local_plugins.get(plugin_name)
            if not local_plugin:
                return True
            if local_plugin.current_version != remote_plugin.get('current_version'):
                return True

        return False

    def _apply_remote_config(self, remote_plugins_data: Dict[str, Any]) -> None:
        """应用远程配置"""
        remote_plugins = remote_plugins_data.get('plugins', {})

        updated_plugins = []
        for plugin_name, plugin_data in remote_plugins.items():
            plugin_config = PluginConfig(
                name=plugin_name,
                url=plugin_data['url'],
                extract_folder=plugin_data['extract_folder'],
                app_relative_path=plugin_data['app_relative_path'],
                is_service=plugin_data.get('is_service', False),
                current_version=plugin_data.get('current_version', '1.0.0'),
                version_check_url=plugin_data.get('version_check_url', ''),
                auto_update=plugin_data.get('auto_update', False)
            )
            updated_plugins.append(plugin_config)
            # 保存到插件目录下的配置文件
            self._save_plugin_config(plugin_config)

        # 更新内存中的插件列表
        self.plugins = updated_plugins
        print(f"已更新 {len(updated_plugins)} 个插件配置")

    def _save_config_to_file(self, config: Dict[str, Any] = None) -> None:
        """保存配置到文件"""
        if config is None:
            config = self.config

        try:
            with open(self.config_path, 'w', encoding='utf-8') as f:
                yaml.dump(config, f, allow_unicode=True, indent=2)
            print(f"配置文件已保存: {self.config_path}")
        except Exception as e:
            print(f"保存配置文件失败: {str(e)}")

    def download_with_progress(
            self,
            url: str,
            save_path: str,
            progress_callback: Optional[Callable[[int, int, float], None]] = None,
            chunk_size: int = 8192,
            timeout: int = 30
    ) -> bool:
        """
        带进度回调的文件下载函数
        """
        try:
            # 发送 HEAD 请求获取文件总大小
            head_response = requests.head(url, timeout=timeout)
            total_size = int(head_response.headers.get('Content-Length', 0))

            # 发送 GET 请求开始下载（流式传输）
            with requests.get(url, stream=True, timeout=timeout) as response:
                response.raise_for_status()

                if total_size == 0:
                    total_size = int(response.headers.get('Content-Length', 0))

                downloaded_size = 0
                start_time = time.time()
                last_time = start_time
                last_downloaded = 0

                with open(save_path, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=chunk_size):
                        if chunk:
                            f.write(chunk)
                            downloaded_size += len(chunk)

                            current_time = time.time()
                            time_diff = current_time - last_time
                            if time_diff > 0.1:
                                speed = (downloaded_size - last_downloaded) / (time_diff * 1024)
                                last_time = current_time
                                last_downloaded = downloaded_size

                                if progress_callback:
                                    progress_callback(downloaded_size, total_size, speed)

                if progress_callback:
                    total_time = time.time() - start_time
                    avg_speed = (downloaded_size / (total_time * 1024)) if total_time > 0 else 0
                    progress_callback(downloaded_size, total_size, avg_speed)

            print(f"\n下载完成：{save_path}")
            return True

        except Exception as e:
            print(f"\n下载失败：{str(e)}")
            return False

    def _extract_archive(self, archive_path: Path, extract_dir: Path) -> bool:
        try:
            if archive_path.suffix.lower() == '.zip':
                with zipfile.ZipFile(archive_path, 'r') as zip_ref:
                    zip_ref.extractall(extract_dir)
                print(f"ZIP解压完成: {extract_dir}")
                return True
            else:
                print(f"不支持的压缩格式: {archive_path.suffix}")
                return False
        except Exception as e:
            print(f"解压失败: {str(e)}")
            return False

    def _calculate_file_md5(self, file_path: Path) -> str:
        """计算文件的MD5哈希值"""
        hash_md5 = hashlib.md5()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()

    def _compare_versions(self, version1: str, version2: str) -> int:
        """比较两个版本号，返回1表示version1>version2，-1表示version1<version2，0表示相等"""
        v1_parts = list(map(int, version1.split('.')))
        v2_parts = list(map(int, version2.split('.')))

        # 补齐版本号长度
        max_len = max(len(v1_parts), len(v2_parts))
        v1_parts.extend([0] * (max_len - len(v1_parts)))
        v2_parts.extend([0] * (max_len - len(v2_parts)))

        for i in range(max_len):
            if v1_parts[i] > v2_parts[i]:
                return 1
            elif v1_parts[i] < v2_parts[i]:
                return -1
        return 0

    def is_plugin_installed(self, plugin_name: str) -> bool:
        """检查插件是否已安装"""
        plugin = next((p for p in self.plugins if p.name == plugin_name), None)
        if not plugin:
            return False

        plugin_dir = self.plugin_install_dir / plugin.extract_folder
        return plugin_dir.exists()

    def check_plugin_update(self, plugin_name: str) -> Tuple[bool, Optional[VersionInfo]]:
        """检查插件是否有更新"""
        plugin = next((p for p in self.plugins if p.name == plugin_name), None)
        if not plugin:
            print(f"插件不存在: {plugin_name}")
            return False, None

        # 如果没有版本检查URL，则无法检查更新
        if not plugin.version_check_url:
            print(f"插件 {plugin_name} 未配置版本检查URL")
            return False, None

        try:
            # 获取远程版本信息
            response = requests.get(plugin.version_check_url, timeout=10)
            response.raise_for_status()
            remote_info = response.json()

            remote_version = remote_info.get('version', '')
            remote_url = remote_info.get('download_url', '')
            release_notes = remote_info.get('release_notes', '')
            release_date = remote_info.get('release_date', '')
            file_size = remote_info.get('file_size', 0)
            md5_hash = remote_info.get('md5_hash', '')

            if not remote_version or not remote_url:
                print(f"远程版本信息不完整: {plugin_name}")
                return False, None

            # 比较版本
            current_version = plugin.current_version
            version_comparison = self._compare_versions(remote_version, current_version)

            if version_comparison > 0:
                # 有新版本
                version_info = VersionInfo(
                    version=remote_version,
                    download_url=remote_url,
                    release_notes=release_notes,
                    release_date=release_date,
                    file_size=file_size,
                    md5_hash=md5_hash
                )
                return True, version_info
            else:
                return False, None

        except Exception as e:
            print(f"检查插件 {plugin_name} 更新失败: {str(e)}")
            return False, None

    def check_all_updates(self, background: bool = False) -> Dict[str, VersionInfo]:
        """检查所有插件的更新"""
        updates = {}

        if not background:
            print("开始检查所有插件更新...")

        for plugin in self.plugins:
            has_update, version_info = self.check_plugin_update(plugin.name)
            if has_update and version_info:
                updates[plugin.name] = version_info
                if not background:
                    print(f"🔔 插件 {plugin.name} 有新版本: {plugin.current_version} -> {version_info.version}")

        # 更新缓存
        self.version_cache['last_update_check'] = datetime.now().isoformat()
        self.version_cache['available_updates'] = {
            plugin_name: {
                'version': info.version,
                'release_date': info.release_date
            } for plugin_name, info in updates.items()
        }
        self._save_version_cache()

        if not background:
            if updates:
                print(f"\n发现 {len(updates)} 个插件有更新")
            else:
                print("\n所有插件都是最新版本")

        return updates

    def update_plugin(
            self,
            plugin_name: str,
            version_info: VersionInfo,
            progress_callback: Optional[Callable[[int, int, float], None]] = None
    ) -> bool:
        """更新指定插件到新版本"""
        plugin = next((p for p in self.plugins if p.name == plugin_name), None)
        if not plugin:
            print(f"插件不存在: {plugin_name}")
            return False

        print(f"开始更新插件 {plugin_name}: {plugin.current_version} -> {version_info.version}")

        # 停止运行中的插件
        if self.is_plugin_running(plugin_name):
            print(f"停止运行中的插件: {plugin_name}")
            if not self.stop_plugin(plugin_name):
                print("停止插件失败，无法更新")
                return False

        # 备份旧版本
        plugin_dir = self.plugin_install_dir / plugin.extract_folder
        backup_dir = self.plugin_install_dir / f"{plugin.extract_folder}_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

        if plugin_dir.exists():
            try:
                shutil.copytree(plugin_dir, backup_dir)
                print(f"已创建备份: {backup_dir}")
            except Exception as e:
                print(f"备份失败: {str(e)}")

        # 下载新版本
        temp_archive = self.plugin_install_dir / f"{plugin.name}_update_temp.zip"

        if not self.download_with_progress(version_info.download_url, str(temp_archive), progress_callback):
            # 下载失败，恢复备份
            if backup_dir.exists():
                print("下载失败，恢复备份...")
                if plugin_dir.exists():
                    shutil.rmtree(plugin_dir)
                shutil.move(backup_dir, plugin_dir)
            return False

        # 验证文件完整性（如果提供了MD5）
        if version_info.md5_hash:
            downloaded_md5 = self._calculate_file_md5(temp_archive)
            if downloaded_md5 != version_info.md5_hash.lower():
                print(f"文件校验失败: MD5不匹配")
                temp_archive.unlink(missing_ok=True)
                # 恢复备份
                if backup_dir.exists():
                    if plugin_dir.exists():
                        shutil.rmtree(plugin_dir)
                    shutil.move(backup_dir, plugin_dir)
                return False

        # 解压新版本
        if plugin_dir.exists():
            shutil.rmtree(plugin_dir)

        self._ensure_dir(plugin_dir)
        if not self._extract_archive(temp_archive, plugin_dir):
            # 解压失败，恢复备份
            if backup_dir.exists():
                print("解压失败，恢复备份...")
                if plugin_dir.exists():
                    shutil.rmtree(plugin_dir)
                shutil.move(backup_dir, plugin_dir)
            temp_archive.unlink(missing_ok=True)
            return False

        # 更新插件配置中的版本号
        plugin.current_version = version_info.version
        self._save_plugin_config(plugin)

        # 清理临时文件
        temp_archive.unlink(missing_ok=True)

        # 删除备份
        if backup_dir.exists():
            shutil.rmtree(backup_dir)

        print(f"插件 {plugin_name} 更新完成: {version_info.version}")
        return True

    def auto_update_plugins(self) -> Dict[str, bool]:
        """自动更新所有有更新的插件"""
        updates = self.check_all_updates(background=True)
        results = {}

        for plugin_name, version_info in updates.items():
            plugin = next((p for p in self.plugins if p.name == plugin_name), None)
            if plugin and plugin.auto_update:
                print(f"自动更新插件: {plugin_name}")
                success = self.update_plugin(plugin_name, version_info)
                results[plugin_name] = success
            else:
                print(f"插件 {plugin_name} 有更新但未启用自动更新")
                results[plugin_name] = False

        return results

    def install_plugin(self, plugin_name: str,
                       progress_callback: Optional[Callable[[int, int, float], None]] = None) -> bool:
        """安装指定插件"""
        # 首先检查本地是否已有该插件的配置
        plugin = next((p for p in self.plugins if p.name == plugin_name), None)

        # 如果本地没有插件配置，尝试从远程获取
        if not plugin and self.remote_config_url:
            print(f"本地未找到插件 {plugin_name} 的配置，尝试从远程获取...")
            if not self._fetch_plugin_config_from_remote(plugin_name):
                print(f"无法获取插件 {plugin_name} 的配置")
                return False
            # 重新加载插件配置
            self.plugins = self._load_plugin_configs()
            plugin = next((p for p in self.plugins if p.name == plugin_name), None)

        if not plugin:
            print(f"插件不存在: {plugin_name}")
            return False

        plugin_dir = self.plugin_install_dir / plugin.extract_folder
        temp_archive = self.plugin_install_dir / f"{plugin.name}_temp.zip"

        # 检查是否已安装
        if self.is_plugin_installed(plugin_name):
            print(f"插件已安装: {plugin_name}")
            return True

        if not self.download_with_progress(plugin.url, str(temp_archive), progress_callback=progress_callback):
            return False

        self._ensure_dir(plugin_dir)
        if not self._extract_archive(temp_archive, plugin_dir):
            shutil.rmtree(plugin_dir, ignore_errors=True)
            temp_archive.unlink(missing_ok=True)
            return False

        # 确保插件配置已保存到插件目录
        self._save_plugin_config(plugin)

        temp_archive.unlink(missing_ok=True)
        print(f"插件安装完成: {plugin_name}")
        return True

    def _fetch_plugin_config_from_remote(self, plugin_name: str) -> bool:
        """从远程获取指定插件的配置"""
        try:
            print(f"从远程获取插件 {plugin_name} 的配置...")
            response = requests.get(self.remote_config_url, timeout=10)
            response.raise_for_status()
            remote_plugins_data = response.json()

            remote_plugins = remote_plugins_data.get('plugins', {})
            if plugin_name not in remote_plugins:
                print(f"远程配置中未找到插件: {plugin_name}")
                return False

            plugin_data = remote_plugins[plugin_name]
            plugin_config = PluginConfig(
                name=plugin_name,
                url=plugin_data['url'],
                extract_folder=plugin_data['extract_folder'],
                app_relative_path=plugin_data['app_relative_path'],
                is_service=plugin_data.get('is_service', False),
                current_version=plugin_data.get('current_version', '1.0.0'),
                version_check_url=plugin_data.get('version_check_url', ''),
                auto_update=plugin_data.get('auto_update', False)
            )

            # 保存插件配置到插件目录
            self._save_plugin_config(plugin_config)
            print(f"已获取并保存插件 {plugin_name} 的配置")
            return True

        except Exception as e:
            print(f"从远程获取插件配置失败: {str(e)}")
            return False

    def install_all_plugins(self,
                            progress_callback: Optional[Callable[[int, int, float], None]] = None) -> None:
        print("开始安装所有插件...")
        for plugin in self.plugins:
            self.install_plugin(plugin.name, progress_callback=progress_callback)
        print("所有插件安装操作完成")

    def start_plugin(self, plugin_name: str) -> bool:
        if self.is_plugin_running(plugin_name):
            print(f"插件已在运行: {plugin_name}")
            return True

        plugin = next((p for p in self.plugins if p.name == plugin_name), None)
        if not plugin:
            print(f"插件不存在: {plugin_name}")
            return False

        plugin_dir = self.plugin_install_dir / plugin.extract_folder
        app_path = plugin_dir / plugin.app_relative_path

        if not plugin_dir.exists():
            print(f"插件未安装: {plugin_name}，正在尝试安装...")
            if not self.install_plugin(plugin_name):
                return False

        if not app_path.exists():
            print(f"插件程序不存在: {app_path}")
            return False

        try:
            cmd = [str(app_path)]
            if plugin.is_service:
                port = self._get_free_port()
                cmd.extend([f"--port={port}"])  # 传递端口参数
                print(f"为服务插件 [{plugin_name}] 分配端口: {port}")

            print(f"启动插件: {plugin_name} ({app_path})")
            if os.name == 'nt':
                subprocess.Popen(cmd, shell=True)
            elif os.name == 'posix':
                subprocess.Popen(cmd)

            if plugin.is_service:
                self.port_manager.set_port(plugin_name, port)
            return True
        except Exception as e:
            print(f"启动插件失败: {str(e)}")
            if plugin.is_service:
                self.port_manager.clear_port(plugin_name)
            return False

    def _get_running_processes(self) -> Set[str]:
        processes = set()
        for proc in psutil.process_iter(['exe', 'cmdline']):
            try:
                if proc.info['exe']:
                    processes.add(str(Path(proc.info['exe']).resolve()))
                elif proc.info['cmdline']:
                    cmd_path = Path(proc.info['cmdline'][0]).resolve()
                    if cmd_path.exists():
                        processes.add(str(cmd_path))
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
        return processes

    def is_plugin_running(self, plugin_name: str) -> bool:
        plugin = next((p for p in self.plugins if p.name == plugin_name), None)
        if not plugin:
            print(f"插件不存在: {plugin_name}")
            return False

        plugin_dir = self.plugin_install_dir / plugin.extract_folder
        app_path = plugin_dir / plugin.app_relative_path
        if not app_path.exists():
            return False

        app_abs_path = str(app_path.resolve())
        return app_abs_path in self._get_running_processes()

    def get_service_port(self, plugin_name: str) -> Optional[int]:
        plugin = next((p for p in self.plugins if p.name == plugin_name), None)
        if not plugin or not plugin.is_service:
            print(f"不是服务类型插件: {plugin_name}")
            return None
        return self.port_manager.get_port(plugin_name)

    def stop_plugin(self, plugin_name: str) -> bool:
        if not self.is_plugin_running(plugin_name):
            print(f"插件未在运行: {plugin_name}")
            self.port_manager.clear_port(plugin_name)
            return True

        plugin = next((p for p in self.plugins if p.name == plugin_name), None)
        if not plugin:
            return False

        app_abs_path = str((self.plugin_install_dir / plugin.extract_folder / plugin.app_relative_path).resolve())

        try:
            for proc in psutil.process_iter(['exe']):
                try:
                    if proc.info['exe'] and str(Path(proc.info['exe']).resolve()) == app_abs_path:
                        proc.terminate()
                        proc.wait(timeout=5)
                        print(f"已终止插件进程: {plugin_name} (PID: {proc.pid})")
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.TimeoutExpired):
                    continue

            if plugin.is_service:
                self.port_manager.clear_port(plugin_name)
            return True
        except Exception as e:
            print(f"停止插件失败: {str(e)}")
            return False

    def uninstall_plugin(self, plugin_name: str) -> bool:
        if self.is_plugin_running(plugin_name):
            print(f"插件正在运行，先停止插件: {plugin_name}")
            if not self.stop_plugin(plugin_name):
                print("停止插件失败，无法卸载")
                return False

        plugin = next((p for p in self.plugins if p.name == plugin_name), None)
        if not plugin:
            print(f"插件不存在: {plugin_name}")
            return False

        plugin_dir = self.plugin_install_dir / plugin.extract_folder
        if not plugin_dir.exists():
            print(f"插件未安装: {plugin_name}")
            return True

        try:
            shutil.rmtree(plugin_dir)
            print(f"插件卸载完成: {plugin_name}")
            return True
        except Exception as e:
            print(f"卸载插件失败: {str(e)}")
            return False

    def list_plugins(self) -> None:
        print("\n插件列表:")
        print("-" * 120)
        print(
            f"{'名称':<15} {'版本':<10} {'类型':<8} {'安装状态':<10} {'运行状态':<10} {'自动更新':<8} {'端口':<6} {'安装路径':<40}")
        print("-" * 120)
        for plugin in self.plugins:
            plugin_dir = self.plugin_install_dir / plugin.extract_folder
            install_status = "已安装" if self.is_plugin_installed(plugin.name) else "未安装"
            run_status = "运行中" if self.is_plugin_running(plugin.name) else "未运行"
            port = self.port_manager.get_port(plugin.name) or "-"
            plugin_type = "服务" if plugin.is_service else "应用"
            auto_update = "是" if plugin.auto_update else "否"

            print(
                f"{plugin.name:<15} {plugin.current_version:<10} {plugin_type:<8} {install_status:<10} "
                f"{run_status:<10} {auto_update:<8} {str(port):<6} {str(plugin_dir):<40}"
            )
        print("-" * 120 + "\n")


def main():
    if len(sys.argv) < 2:
        print("插件管理器使用方法:")
        print("  python manager.py install <插件名>      - 安装指定插件")
        print("  python manager.py install-all           - 安装所有插件")
        print("  python manager.py start <插件名>        - 启动指定插件")
        print("  python manager.py stop <插件名>         - 停止指定插件")
        print("  python manager.py uninstall <插件名>    - 卸载指定插件")
        print("  python manager.py list                  - 列出所有插件状态")
        print("  python manager.py status <插件名>       - 查看单个插件状态")
        print("  python manager.py get-port <插件名>     - 获取服务插件端口")
        print("  python manager.py check-updates         - 检查所有插件更新")
        print("  python manager.py update <插件名>       - 更新指定插件")
        print("  python manager.py auto-update           - 自动更新所有插件")
        print("  python manager.py sync-config           - 同步远程配置")
        print("  python manager.py is-installed <插件名> - 检查插件是否已安装")
        return

    try:
        # 初始化管理器（默认加载当前目录的 config.yaml）
        manager = PluginManager()

        command = sys.argv[1].lower()
        plugin_name = sys.argv[2] if len(sys.argv) > 2 else None

        if command == "install" and plugin_name:
            manager.install_plugin(plugin_name)
        elif command == "install-all":
            manager.install_all_plugins()
        elif command == "start" and plugin_name:
            manager.start_plugin(plugin_name)
        elif command == "stop" and plugin_name:
            manager.stop_plugin(plugin_name)
        elif command == "uninstall" and plugin_name:
            manager.uninstall_plugin(plugin_name)
        elif command == "list":
            manager.list_plugins()
        elif command == "status" and plugin_name:
            status = "运行中" if manager.is_plugin_running(plugin_name) else "未运行"
            port = manager.get_service_port(plugin_name)
            port_info = f", 端口: {port}" if port else ""
            print(f"{plugin_name} 状态: {status}{port_info}")
        elif command == "get-port" and plugin_name:
            port = manager.get_service_port(plugin_name)
            if port:
                print(f"{plugin_name} 端口: {port}")
        elif command == "check-updates":
            updates = manager.check_all_updates()
            if updates:
                print("\n可用的更新:")
                for plugin_name, version_info in updates.items():
                    print(f"  {plugin_name}: {version_info.version} - {version_info.release_notes}")
        elif command == "update" and plugin_name:
            # 检查更新
            has_update, version_info = manager.check_plugin_update(plugin_name)
            if has_update and version_info:
                print(f"发现新版本: {version_info.version}")
                print(f"更新说明: {version_info.release_notes}")
                confirm = input("是否更新? (y/N): ")
                if confirm.lower() == 'y':
                    manager.update_plugin(plugin_name, version_info)
                else:
                    print("取消更新")
            else:
                print(f"插件 {plugin_name} 已是最新版本")
        elif command == "auto-update":
            print("开始自动更新...")
            results = manager.auto_update_plugins()
            if results:
                print("\n自动更新结果:")
                for plugin_name, success in results.items():
                    status = "成功" if success else "失败"
                    print(f"  {plugin_name}: {status}")
            else:
                print("没有需要更新的插件")
        elif command == "sync-config":
            if manager.remote_config_url:
                success = manager.sync_remote_config()
                if success:
                    print("配置同步完成，重新加载插件列表...")
                    # 重新加载插件列表
                    manager.plugins = manager._load_plugin_configs()
                    manager.list_plugins()
                else:
                    print("配置同步失败或无更新")
            else:
                print("未配置远程配置URL")
        elif command == "is-installed" and plugin_name:
            installed = manager.is_plugin_installed(plugin_name)
            status = "已安装" if installed else "未安装"
            print(f"插件 {plugin_name} {status}")
        else:
            print("未知命令")
    except Exception as e:
        print(f"执行失败: {str(e)}")


if __name__ == "__main__":
    # 需安装依赖：pip install psutil pyyaml requests
    main()