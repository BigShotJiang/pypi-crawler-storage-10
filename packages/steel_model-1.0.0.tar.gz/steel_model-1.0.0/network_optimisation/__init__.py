"""Network optimisation package."""
