from setuptools import setup
from setuptools import find_packages

version_py = "ScanRegion/_version.py"
exec(open(version_py).read())

setup(
    name="scanregion", # Replace with your own username
    version=__version__,
    author="Benxia Hu",
    author_email="hubenxia@gmail.com",
    description="Scan geneome for motif sequences",
    long_description="Scan geneome for motif sequences and output chr,start,end,motif",
    url="https://pypi.org/project/scanregion/",
    entry_points = {
        "console_scripts": ['ScanRegion = ScanRegion.ScanRegion:main',]
        },
    python_requires = '>=3.12',
    packages = ['ScanRegion'],
    install_requires = [
        'numpy',
        'pandas',
        'argparse',
    ],
    classifiers=(
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ),
    zip_safe = False,
  )