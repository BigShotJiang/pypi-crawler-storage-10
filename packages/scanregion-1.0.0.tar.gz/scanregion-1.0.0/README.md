# ScanRegion  
This tutorial will introduce how to run ScanRegion to scan geneome for motif sequences.

### ScanRegion can be used to scan geneome for motif sequences and output chr,start,end,motif.  
```
usage: ScanRegion [-h] -f fasta -o OUTFILE -m Motifile [-r] [-V]

options:
  -h, --help            show this help message and exit
  -f fasta, --fasta fasta
                        the fasta file of genome.
  -o outfile, --outfile outfile
                        Output file prefix.
  -m Motif_File, --motif Motif_File
                        the motif file path.
  -r reverse, --reverse reverse
                        search reverse complements (off by default; enable with -r).
  -V, --version         Print version and exit
```

### Installation 
#### requirement for installation
python>=3.8  
numpy  
pandas  
argparse  

#### pip install ScanRegion==1.0.0
https://pypi.org/project/ScanRegion/1.0.0/


