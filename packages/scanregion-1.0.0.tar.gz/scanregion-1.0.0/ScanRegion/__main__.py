from .ScanRegion import main
main()
