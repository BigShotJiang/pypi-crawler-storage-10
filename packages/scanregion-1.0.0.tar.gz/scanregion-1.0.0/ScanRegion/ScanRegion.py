#!/usr/bin/env python3
import os
import sys, getopt
import os.path
import argparse
import csv
import pysam
from typing import List, Set
import pandas as pd

dir = os.path.dirname(__file__)
version_py = os.path.join(dir, "_version.py")
exec(open(version_py).read())

def revcomp(seq):
    tbl = str.maketrans("ACGTNacgtn", "TGCANtgcan")
    return seq.translate(tbl)[::-1]

def iter_fasta_chunks(fa, chrom, chunk_size,overlap):
    chrom_len = fa.get_reference_length(chrom)
    start = 0
    while start < chrom_len:
        end = min(chrom_len, start + chunk_size)
        seq = fa.fetch(chrom, start, end).upper()
        yield start, seq
        if end == chrom_len:
            break
        # next window with overlap to catch boundary-spanning matches
        start = end - overlap

def find_all(seq, sub):
    i = seq.find(sub, 0)
    while i != -1:
        yield i
        i = seq.find(sub, i + 1)

def parse_motifs_file(path):
    motifs: List[str] = []
    seen: Set[str] = set()
    with open(path, "r") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            if "#" in line:
                line = line.split("#", 1)[0].strip()
                if not line:
                    continue
            parts = [p for token in line.replace(",", " ").split() for p in [token] if p]
            for p in parts:
                m = p.upper().replace("U", "T")
                if not m:
                    continue
                if any(ch not in "ACGT" for ch in m):
                    print(f"[warn] Skipping invalid motif (non-ACGT characters): {p}", file=sys.stderr)
                    continue
                if m not in seen:
                    motifs.append(m)
                    seen.add(m)
    return motifs

def expand_with_revcomps(motifs,include_revcomp):
    out: List[str] = []
    seen: Set[str] = set()
    for m in motifs:
        if m not in seen:
            out.append(m)
            seen.add(m)
            if include_revcomp:
                rc = revcomp(m)
                if rc not in seen:
                    out.append(rc)
                    seen.add(rc)
    return out


def ScanRegion(fasta_path, outputfile, inputfile,flagid):
    """
    Scan genome for motif sequences and output positions as chr, start, end, motif.
    Automatically reads and expands motifs from file.
    """
    # --- Load motifs from file ---
    motifs = parse_motifs_file(inputfile)
    if not motifs:
        print(f"[warn] No valid motifs found in {inputfile}", file=sys.stderr)
        return

    # --- Build search term list (include reverse complements) ---
    search_terms = expand_with_revcomps(motifs,flagid)
    max_len = max(len(s) for s in search_terms)

    # --- Open genome ---
    fa = pysam.FastaFile(fasta_path)
    chrom_list = list(fa.references)

    results = []
    total_hits = 0

    for chrom in chrom_list:
        chrom_len = fa.get_reference_length(chrom)

        for offset, chunk in iter_fasta_chunks(fa, chrom, chunk_size=5_000_000, overlap=max_len-1):
            for term in search_terms:
                L = len(term)
                for i in find_all(chunk, term):
                    start = offset + i
                    end = start + L
                    results.append([chrom, start, end, term])
                    total_hits += 1

    # --- Save results ---
    df = pd.DataFrame(results, columns=["chr", "start", "end", "motif"])
    df.to_csv(outputfile, sep="\t", index=False)

def main():
    parser = argparse.ArgumentParser(
        description="Scan geneome for motif sequences and output chr,start,end,motif.")
    parser.add_argument("--fasta", "-f", required=True, help="Path to genome FASTA (indexed with .fai).")
    parser.add_argument("--output", "-o", required=True, help="Output CSV file")
    parser.add_argument("--motif", "-m", required=True,help="Text file of motifs (DNA or RNA). One per line or comma/space-separated")
    parser.add_argument("--reverse", "-r", action="store_true", help="search reverse complements (off by default; enable with -r)")
    parser.add_argument("-V", "--version", action="version", version=f"%(prog)s {__version__}")

    args = parser.parse_args()
    print('###Parameters:')
    print(args)
    print('###Parameters')

    ScanRegion(
        fasta_path=args.fasta,
        outputfile=args.output,
        inputfile=args.motif,
        flagid=args.reverse
    )

if __name__ == "__main__":
    main()
