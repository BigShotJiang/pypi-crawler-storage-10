# ReasoningBank MCP 实现计划

## ✅ 已完成的模块

### 1. 项目基础结构
- ✅ 项目目录结构
- ✅ pyproject.toml 配置
- ✅ config.yaml 配置文件
- ✅ README.md 文档
- ✅ .env.example 环境变量示例

### 2. 配置管理
- ✅ src/config.py - 配置加载和环境变量替换

### 3. LLM Provider 抽象层
- ✅ src/llm/base.py - LLM 和 Embedding 抽象接口
- ✅ src/llm/providers/dashscope.py - DashScope Provider
- ✅ src/llm/providers/openai.py - OpenAI Provider
- ✅ src/llm/providers/anthropic.py - Anthropic Provider
- ✅ src/llm/factory.py - Provider 工厂类

### 4. 工具函数
- ✅ src/utils/similarity.py - 余弦相似度计算

### 5. 存储后端
- ✅ src/storage/base.py - 存储抽象接口
- ✅ src/storage/backends/json_backend.py - JSON 存储实现

## 🚧 待实现的模块

### 6. 检索策略（优先级：高）
- ⏳ src/retrieval/base.py - 检索策略抽象接口
- ⏳ src/retrieval/strategies/cosine_retrieval.py - 余弦相似度检索
- ⏳ src/retrieval/strategies/hybrid_retrieval.py - 混合评分检索
- ⏳ src/retrieval/factory.py - 检索策略工厂

### 7. 提示词模板（优先级：高）
- ⏳ src/prompts/templates.py - 提示词模板
  - 成功轨迹提取提示词
  - 失败轨迹提取提示词
  - 轨迹判断提示词
- ⏳ src/prompts/formatters.py - 轨迹格式化

### 8. MCP 工具（优先级：高）
- ⏳ src/tools/retrieve_memory.py - 检索记忆工具
- ⏳ src/tools/extract_memory.py - 提取记忆工具（异步）
- ⏳ src/tools/_internal.py - 内部工��（判断+保存）

### 9. MCP 服务器（优先级：高）
- ⏳ src/server.py - MCP 服务器入口
- ⏳ src/__init__.py - 包初始化

### 10. 测试（优先级：中）
- ⏳ tests/test_config.py
- ⏳ tests/test_llm_providers.py
- ⏳ tests/test_storage.py
- ⏳ tests/test_retrieval.py
- ⏳ tests/test_e2e.py

## 📋 下一步行动

### 立即完成（第一优先级）
1. 实现检索策略模块
2. 编写提示词模板
3. 实现 MCP 工具
4. 实现 MCP 服务器入口

### 后续优化（第二优先级）
1. 完善单元测试
2. 端到端集成测试
3. 性能优化和缓存
4. 错误处理和日志

## 🎯 当前进度

总进度: **60%** (6/10 模块完成)

核心功能进度:
- LLM 层: ✅ 100%
- 存储层: ✅ 100%
- 检索层: ⏳ 0%
- 工具层: ⏳ 0%
- 服务层: ⏳ 0%

## 💡 快速启动指南

一旦实现完成，启动流程将是：

```bash
# 1. 安装依赖
pip install -e .

# 2. 配置环境变量
cp .env.example .env
# 编辑 .env 填入 API Key

# 3. 启动服务器
python -m src.server

# 4. 在 Claude Desktop 中配置
# 编辑 ~/Library/Application Support/Claude/claude_desktop_config.json
```

## 📝 备注

- 所有异步操作使用 `async/await`
- 配置使用 YAML + 环境变量
- 存储初期使用 JSON，预留 SQLite/向量数据库扩展点
- 检索策略使用工厂模式，易于扩展
- LLM Provider 支持 DashScope、OpenAI、Anthropic
