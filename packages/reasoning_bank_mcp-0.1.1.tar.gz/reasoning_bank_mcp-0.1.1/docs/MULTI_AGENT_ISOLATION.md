# Multi-Agent 记忆隔离指南

本文档介绍如何�� Claude Code 中使用 SubAgent 配合 Reasoning Bank MCP 实现记忆隔离。

## 概述

Reasoning Bank MCP 现在支持**基于 Agent ID 的记忆隔离**，允许不同的 Agent 维护独立的记忆库。

### 核心特性

- ✅ **可选隔离**：不传 `agent_id` 时所有 Agent 共享记忆（默认行为）
- ✅ **Agent 级隔离**：传递 `agent_id` 时只访问该 Agent 的记忆
- ✅ **向后兼容**：旧数据自动视为全局共享记忆
- ✅ **零配置**：通过 Agent Prompt 实现，无需环境变量

---

## 使用方式

### 1. 创建隔离的 SubAgent

在 `.claude/agents/` 目录下创建 Agent 定义文件：

**示例：`.claude/agents/data-analyst.md`**

```markdown
---
name: data-analyst
description: 专门处理数据分析任务的 Agent
tools: Read, Write, Bash, Glob, Grep, mcp__reasoning-bank__*
---

# 身份标识

你是 **data-analyst** agent，专注于数据分析和统计任务。

## 重要约定：记忆隔离

在调用 reasoning-bank MCP 工具时，**必须传递你的 agent_id**：

### 检索记忆
```python
retrieve_memory(
    query="如何处理缺失值",
    agent_id="data-analyst"  # ← 必须传递
)
```

### 保存记忆
```python
extract_memory(
    trajectory=[...],
    query="数据清洗任务",
    agent_id="data-analyst"  # ← 必须传递
)
```

**这确保你只访问和存储属于你自己的记忆，与其他 Agent 完全隔离。**

---

## 你的任务

作为数据分析专家，你负责：
- 数据清洗和预处理
- 统计分析和可视化
- 数据质量评估
- 异常值检测

在开始任何任务前，先调用 `retrieve_memory` 检索相关经验。
完成任务后，调用 `extract_memory` 保存新的经验。
```

---

### 2. 创建另一个隔离的 Agent

**示例：`.claude/agents/code-reviewer.md`**

```markdown
---
name: code-reviewer
description: 专门进行代码审查的 Agent
tools: Read, Glob, Grep, mcp__reasoning-bank__*
---

# 身份标识

你是 **code-reviewer** agent，专注于代码质量审查。

## 重要约定：记忆隔离

在调用 reasoning-bank MCP 工具时，**必须传递你的 agent_id**：

```python
retrieve_memory(query="如何审查API设计", agent_id="code-reviewer")
extract_memory(trajectory=[...], query="审查结果", agent_id="code-reviewer")
```

---

## 你的任务

作为代码审查专家，你负责：
- 代码风格和最佳实践检查
- 安全漏洞检测
- 性能优化建议
- 架构设计评审

始终传递 `agent_id="code-reviewer"` 以维护独立的记忆库。
```

---

## 数据结构

### 记忆项包含 `agent_id` 字段

```json
{
  "memory_id": "mem_abc123",
  "agent_id": "data-analyst",  // ← Agent 标识
  "timestamp": "2025-10-26T10:30:00Z",
  "success": true,
  "title": "处理缺失值的最佳实践",
  "content": "在数据分析中，应该先分析缺失值的模式...",
  "query": "如何处理缺失值",
  "tags": ["data-cleaning", "pandas"],
  "metadata": {
    "extraction_model": "qwen-turbo",
    "embedding_model": "text-embedding-v3"
  }
}
```

---

## 隔离行为

### 场景 1: Agent 使用自己的记忆

```python
# data-analyst 调用
retrieve_memory(query="缺失值处理", agent_id="data-analyst")

# 只返回 agent_id="data-analyst" 的记忆
# code-reviewer 的记忆不可见
```

### 场景 2: 全局共享模式

```python
# 不传 agent_id
retrieve_memory(query="Python 最佳实践")

# 返回所有记忆（包括所有 agent 的 + 全局的）
```

### 场景 3: 混合使用

- 某些 Agent 使用隔离（传 `agent_id`）
- 某些 Agent 使用共享（不传 `agent_id`）
- 某些记忆设为全局（`agent_id=null`）

---

## 最佳实践

### ✅ 推荐做法

1. **在 Agent Prompt 中明确声明身份**
   ```markdown
   你是 **{agent-name}** agent。
   ```

2. **强制要求传递 agent_id**
   ```markdown
   在调用 MCP 工具时，**必须传递 agent_id="{agent-name}"**
   ```

3. **使用 Agent 的 name 作为 agent_id**
   - 保持一致性
   - 易于管理和调试

4. **为不同职责的 Agent 创建隔离**
   - `data-analyst`：数据分析记忆
   - `code-reviewer`：代码审查记忆
   - `devops`：运维部署记忆

### ❌ 避免的做法

1. **不要使用随机或不一致的 agent_id**
   ```python
   # ❌ 错误
   agent_id="analyst-" + random_string()
   ```

2. **不要在同一个 Agent 中使用多个 agent_id**
   ```python
   # ❌ 错误 - 会导致记忆分散
   retrieve_memory(query="...", agent_id="agent1")
   extract_memory(..., agent_id="agent2")
   ```

3. **不要手动修改 agent_id**
   - 始终使用 Agent 的 `name` 字段

---

## 向后兼容性

### 旧数据迁移

现有的记忆（没有 `agent_id` 字段）会被视为全局共享记忆：

```json
{
  "memory_id": "mem_old",
  "agent_id": null,  // ← 旧数据或全局记忆
  "title": "通用编程技巧",
  ...
}
```

### 升级路径

1. **继续使用全局共享模式**
   - 不传 `agent_id` 参数
   - 所有 Agent 共享记忆

2. **逐步迁移到隔离模式**
   - 为新 Agent 添加 `agent_id`
   - 旧 Agent 继续共享模式
   - 混合使用

3. **完全隔离模式**
   - 所有 Agent 都传递 `agent_id`
   - 只在需要时共享（`agent_id=null`）

---

## 调试和监控

### 查看记忆分布

```bash
# 查看 memories.json
cat /Users/hanw/data/memories.json | jq '.memories | group_by(.agent_id) | map({agent_id: .[0].agent_id, count: length})'
```

输出示例：
```json
[
  {"agent_id": null, "count": 5},           // 全局记忆
  {"agent_id": "data-analyst", "count": 12},
  {"agent_id": "code-reviewer", "count": 8}
]
```

### 检查隔离效果

```python
# 在 Agent Prompt 中添加日志
print(f"[DEBUG] 调用 retrieve_memory with agent_id={agent_id}")
```

---

## 常见问题

### Q: agent_id 是否必须？
**A:** 不是。不传 `agent_id` 时，会访问所有记忆（全局共享模式）。

### Q: 可以让多个 Agent 共享记忆吗？
**A:** 可以。使用相同的 `agent_id` 即可。例如：
```python
# team-a-agent1 和 team-a-agent2 共享
agent_id="team-a"
```

### Q: 如何创建全局记忆？
**A:** 传递 `agent_id=null` 或不传 `agent_id`。

### Q: 会有性能影响吗？
**A:** 几乎没有。过滤是在内存中进行的，对小规模记忆库（< 1000 条）影响可忽略。

---

## 总结

通过在 SubAgent 的 Prompt 中声明 `agent_id`，你可以：

- ✅ 实现多 Agent 记忆隔离
- ✅ 避免记忆混淆和干扰
- ✅ 保持向后兼容性
- ✅ 零配置、零依赖

这是业界通用的 **Tenant ID-Based Isolation** 模式，符合 MCP 和 Multi-Agent 系统的最佳实践。
