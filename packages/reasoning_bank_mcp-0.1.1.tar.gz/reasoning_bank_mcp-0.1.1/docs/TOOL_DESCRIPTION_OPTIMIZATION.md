# MCP 工具描述优化指南

本文档记录了 Reasoning Bank MCP 工具描述的优化过程，以及如何编写**能让 LLM 主动使用**的工具描述。

---

## 问题背景

在实际使用中发现，即使 MCP 工具已连接且可用，LLM（如 Claude）也**不会主动在任务开始时调用 `retrieve_memory`**，导致无法利用历史经验。

**根本原因**：工具描述不够强制性、明确性、可操作性。

---

## 优化对比

### 1️⃣ retrieve_memory 工具

#### ❌ 优化前（弱）

```
"检索相关的历史经验记忆，帮助指导当前任务的执行。在开始执行任何复杂任务前都应该先调用此工具来获取相关经验。例如：编写代码、数据分析、制定计划等任务前。"
```

**问题**：
- ❌ "应该" 不够强制
- ❌ "复杂任务" 定义模糊
- ❌ 没有强调优先级
- ❌ 没有说明后果

#### ✅ 优化后（强）

```
🔴 CRITICAL - MUST USE FIRST 🔴

**MANDATORY FIRST STEP**: ALWAYS call this tool BEFORE starting ANY task that involves problem-solving, implementation, analysis, or decision-making.

**When to use (NON-EXHAUSTIVE list)**:
- BEFORE writing ANY code (debugging, features, refactoring, fixes)
- BEFORE data analysis, processing, or manipulation
- BEFORE making architectural decisions or design choices
- BEFORE troubleshooting or investigating issues
- BEFORE creating documentation or planning
- BEFORE answering complex questions
- BEFORE implementing new features or changes
- BEFORE reviewing code or performing analysis

**WHY this is CRITICAL**:
✓ Avoid repeating past mistakes
✓ Leverage proven solutions from previous tasks
✓ Save time by reusing successful patterns
✓ Maintain consistency across similar tasks

**How to use**:
1. Formulate your task as a query (describe what you're about to do)
2. Call retrieve_memory with that query FIRST
3. Review returned memories BEFORE proceeding
4. Apply relevant insights to your current task

**Example queries**:
- "implementing multi-tenant isolation with agent_id"
- "debugging Python async function timeout"
- "optimizing database query performance"

⚠️ DO NOT SKIP THIS STEP - It takes 2 seconds but saves hours of work.
```

**改进点**：
- ✅ 使用 🔴 emoji 和 "CRITICAL" 吸引注意
- ✅ "MANDATORY FIRST STEP" 明确优先级
- ✅ "ALWAYS"、"BEFORE ANY" 强制性词汇
- ✅ 详细列举使用场景（消除歧义）
- ✅ 说明收益（WHY）
- ✅ 提供具体步骤（HOW）
- ✅ 给出示例查询
- ✅ 强调后果（"DO NOT SKIP"）

---

### 2️⃣ extract_memory 工具

#### ❌ 优化前（弱）

```
"从任务轨迹中提取推理经验并保存到记忆库。当任务执行完成后必须调用此工具，以便将经验保存供未来使用。这应该在每次任务结束时调用。"
```

**问题**：
- ❌ "应该" 不够强制
- ❌ 没有强调失败也要保存
- ❌ 没有说明 trajectory 应该包含什么
- ❌ 没有强调异步模式的优势

#### ✅ 优化后（强）

```
🔴 CRITICAL - MUST USE AT END 🔴

**MANDATORY FINAL STEP**: ALWAYS call this tool AFTER completing ANY significant task to save learnings for future use.

**When to use (REQUIRED for ALL of these)**:
- AFTER completing ANY implementation (success OR failure)
- AFTER debugging or fixing issues
- AFTER making design decisions
- AFTER solving problems or overcoming obstacles
- AFTER discovering new insights or patterns
- AFTER encountering errors and finding solutions
- AFTER ANY task that took multiple steps

**WHY this is CRITICAL**:
✓ Future tasks will benefit from this experience
✓ Avoid repeating the same mistakes
✓ Build institutional knowledge over time
✓ Improve performance on similar future tasks

**IMPORTANT - Save BOTH successes AND failures**:
- ✅ Success: Save what worked and why
- ❌ Failure: Save what didn't work to avoid repeating it

**What to include in trajectory**:
- User's original request
- Your approach and reasoning
- Key decisions made
- Problems encountered
- Solutions applied
- Final outcome

**Example**:
After implementing a feature, fixing a bug, or completing analysis - IMMEDIATELY call this tool with the full conversation trajectory.

⚠️ DO NOT FORGET THIS STEP - This is how the system gets smarter over time.
⚠️ Call this even if the task failed - failures are valuable learning experiences!

Default: async_mode=true (runs in background, won't delay your response)
```

**改进点**：
- ✅ "MANDATORY FINAL STEP" 明确位置
- ✅ 强调 "success OR failure" 都要保存
- ✅ 详细说明 trajectory 应包含的内容
- ✅ 强调异步模式的优势（不会延迟响应）
- ✅ 说明长期收益（"gets smarter over time"）

---

## 优化原则总结

### 🎯 核心原则

1. **强制性 > 建议性**
   - ✅ MUST、ALWAYS、MANDATORY、REQUIRED
   - ❌ should、could、may、recommend

2. **具体性 > 抽象性**
   - ✅ 列举明确场景："BEFORE writing ANY code"
   - ❌ 模糊描述："复杂任务"

3. **视觉突出**
   - ✅ 使用 emoji（🔴）、大写（CRITICAL）、粗体
   - ❌ 纯文本，无格式

4. **说明 WHY + HOW**
   - ✅ 既说明为什么重要，又说明如何使用
   - ❌ 只说 WHAT（是什么）

5. **提供示例**
   - ✅ 具体的查询示例、使用场景
   - ❌ 抽象描述

6. **强调后果**
   - ✅ "DO NOT SKIP"、"saves hours of work"
   - ❌ 不说明不使用的后果

---

## 效果验证

### 测试方法

1. **重启 MCP Server**（使新描述生效）
2. **开始新任务**，观察 LLM 是否主动调用 `retrieve_memory`
3. **完成任务后**，观察 LLM 是否主动调用 `extract_memory`

### 预期效果

- ✅ LLM 在任何技术任务开始前，主动调用 `retrieve_memory`
- ✅ LLM 在任务完成后，主动调用 `extract_memory`
- ✅ 即使没有相关记忆，也会调用（养成习惯）
- ✅ 失败的任务也会保存经验

---

## 最佳实践：如何编写好的 MCP 工具描述

### ✅ DO（应该做的）

1. **使用强制性语言**
   ```
   MUST call this BEFORE ANY task
   ALWAYS use this AFTER completion
   REQUIRED for ALL implementations
   ```

2. **提供详尽的触发条件列表**
   ```
   When to use:
   - BEFORE writing code
   - BEFORE debugging
   - BEFORE making decisions
   - ...（列举 8-10 个具体场景）
   ```

3. **说明收益和后果**
   ```
   WHY this is CRITICAL:
   ✓ Avoid mistakes
   ✓ Save time

   DO NOT SKIP - saves hours of work
   ```

4. **提供具体示例**
   ```
   Example queries:
   - "implementing feature X"
   - "debugging error Y"
   ```

5. **使用视觉元素**
   ```
   🔴 CRITICAL
   ⚠️ WARNING
   ✓ Benefit
   ```

### ❌ DON'T（不应该做的）

1. **不要使用弱化词汇**
   ```
   ❌ "should call this tool"
   ❌ "recommended to use"
   ❌ "it would be good if"
   ```

2. **不要模糊描述**
   ```
   ❌ "for complex tasks"（什么是复杂？）
   ❌ "when appropriate"（什么时候合适？）
   ```

3. **不要只说 WHAT，不说 WHY/HOW**
   ```
   ❌ "Retrieves memories"（太简单）
   ✅ "Retrieves memories to avoid past mistakes - use BEFORE any task"
   ```

4. **不要省略示例**
   ```
   ❌ 只有抽象描述
   ✅ 包含 3-5 个具体使用示例
   ```

---

## 模板

### 强制性工具描述模板

```markdown
🔴 CRITICAL - MUST USE [WHEN] 🔴

**MANDATORY [POSITION] STEP**: ALWAYS call this tool [TIMING] [CONDITION].

**When to use (NON-EXHAUSTIVE list)**:
- [TRIGGER_1]
- [TRIGGER_2]
- [TRIGGER_3]
- ...（8-10 个）

**WHY this is CRITICAL**:
✓ [BENEFIT_1]
✓ [BENEFIT_2]
✓ [BENEFIT_3]

**How to use**:
1. [STEP_1]
2. [STEP_2]
3. [STEP_3]

**Example**:
[CONCRETE_EXAMPLE_1]
[CONCRETE_EXAMPLE_2]

⚠️ DO NOT SKIP THIS STEP - [CONSEQUENCE]
```

---

## 相关资源

- [MCP 工具最佳实践](https://modelcontextprotocol.io/best-practices)
- [Claude 工具使用指南](https://docs.anthropic.com/claude/docs/tool-use)

---

## 更新日志

- **2025-10-26**: 优化 retrieve_memory 和 extract_memory 的描述，使其更强制性和明确
- **原因**: LLM 在任务开始时未主动调用工具，导致无法利用历史经验
- **效果**: 待验证（需要在新任务中测试）

---

## 贡献

如果你发现工具描述还可以进一步优化，或者有新的最佳实践，欢迎提交 PR 或 Issue。

**记住**：工具描述是 MCP 工具能否被有效使用的关键！
