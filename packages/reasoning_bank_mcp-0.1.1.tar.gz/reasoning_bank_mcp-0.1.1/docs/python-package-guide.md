# Python 包管理与导入机制完全指南

> 本文档基于 reasoning-bank-mcp 项目，全面讲解 Python 包结构、导入机制、运行方式和安装模式。

## 目录

- [1. Python 包的基础概念](#1-python-包的基础概念)
- [2. 导入机制详解](#2-导入机制详解)
- [3. 包的运行方式](#3-包的运行方式)
- [4. 包的安装模式](#4-包的安装模式)
- [5. reasoning-bank-mcp 项目实战](#5-reasoning-bank-mcp-项目实战)
- [6. 最佳实践总结](#6-最佳实践总结)

---

## 1. Python 包的基础概念

### 1.1 什么是模块和包？

#### 模块（Module）
- **定义**：一个 `.py` 文件就是一个模块
- **作用**：组织和重用代码
- **例子**：`server.py`、`config.py` 都是模块

#### 包（Package）
- **定义**：包含 `__init__.py` 文件的目录就是一个包
- **作用**：组织多个模块和子包
- **层级**：包可以嵌套（子包）

### 1.2 典型的 Python 项目结构

#### 传统布局（不推荐）
```
my_project/
├── my_package/
│   ├── __init__.py
│   └── module.py
└── tests/
```

**问题**：可能导致导入混淆，测试时容易导入源码目录而非安装的包。

#### src-layout（现代推荐）
```
my_project/
├── pyproject.toml          # 项目配置
├── README.md
├── src/                    # 源代码根目录
│   └── my_package/         # 实际的包
│       ├── __init__.py
│       ├── module1.py
│       ├── module2.py
│       └── subpackage/     # 子包
│           ├── __init__.py
│           └── module3.py
└── tests/
    └── test_module1.py
```

**优势**：
- 清晰分离源码和其他文件
- 强制使用安装后的包进行测试
- 避免导入路径混淆

### 1.3 `__init__.py` 的作用

`__init__.py` 是包的标识文件，有多重作用：

#### 作用 1：标记目录为包
```python
# 最简单的 __init__.py（可以为空）
# 只要存在，目录就是一个包
```

#### 作用 2：控制包的导入行为
```python
# my_package/__init__.py
from .module1 import important_function
from .module2 import ImportantClass

__all__ = ['important_function', 'ImportantClass']
```

这样用户可以直接：
```python
from my_package import important_function
# 而不需要：from my_package.module1 import important_function
```

#### 作用 3：包级别初始化
```python
# my_package/__init__.py
import logging

logger = logging.getLogger(__name__)
logger.info("Package initialized")

# 包的元数据
__version__ = "0.1.0"
__author__ = "Your Name"
```

---

## 2. 导入机制详解

### 2.1 绝对导入（Absolute Import）

#### 定义
从项目根包开始的完整路径导入。

#### 语法
```python
# 导入整个模块
import my_package.module1

# 导入模块中的特定对象
from my_package.module1 import some_function
from my_package.subpackage.module3 import SomeClass
```

#### 优点
- ✅ 路径清晰明确
- ✅ IDE 支持好
- ✅ 不受当前位置影响
- ✅ 更易维护大型项目

#### 缺点
- ❌ 包重命名需要修改所有导入
- ❌ 路径可能较长

#### 使用场景
- 跨包导入
- 公共 API 导入
- 明确指定导入来源

### 2.2 相对导入（Relative Import）

#### 定义
使用 `.` 表示当前目录，`..` 表示上一级目录。

#### 语法
```python
# 同级导入
from . import module1              # 导入同级模块
from .module1 import func          # 导入同级模块中的对象

# 上级导入
from .. import module1             # 导入父级的 module1
from ..module2 import func         # 导入父级 module2 中的 func

# 子包导入
from .subpackage import module3    # 导入子包中的模块
```

#### 点号规则
- `.`：当前目录（同级）
- `..`：上一级目录（父级）
- `...`：上上级目录（祖父级）

#### 示例
```
src/my_package/
├── __init__.py
├── module1.py
├── module2.py
└── subpackage/
    ├── __init__.py
    └── module3.py
```

```python
# 在 module2.py 中
from . import module1           # 导入同级的 module1
from .module1 import func       # 导入 module1 中的 func

# 在 subpackage/module3.py 中
from .. import module1          # 导入父级的 module1
from ..module2 import func      # 导入父级 module2 中的 func
from . import __init__          # 导入当前包的 __init__
```

#### 优点
- ✅ 包重命名不需要改代码
- ✅ 明确表示包内部导入
- ✅ 符合 Python 包的设计理念

#### 缺点
- ❌ 必须作为包运行（不能直接运行脚本）
- ❌ 路径关系不够直观

#### 使用场景
- 包内部模块互相导入
- 子包导入父包模块
- 同一包的紧密耦合模块

### 2.3 导入策略最佳实践

| 导入类型 | 使用场景 | 示例 |
|---------|---------|-----|
| **相对导入** | 包内部模块间 | `from .config import settings` |
| **绝对导入** | 跨包导入 | `from other_package import utility` |
| **绝对导入** | 外部库 | `import numpy as np` |

---

## 3. 包的运行方式

Python 有两种运行代码的方式，它们有本质区别。

### 3.1 作为脚本运行（Script Mode）

#### 命令格式
```bash
python path/to/file.py
```

#### 特性
- 直接执行一个 `.py` 文件
- `__name__` 被设置为 `"__main__"`
- `__package__` 被设置为 `None`
- **不能使用相对导入**
- Python 不知道这个文件属于哪个包

#### 示例
```bash
# 假设项目结构
src/
├── __init__.py
├── server.py
└── config.py

# 作为脚本运行
python src/server.py
```

```python
# src/server.py
print(f"__name__ = {__name__}")      # __main__
print(f"__package__ = {__package__}") # None

from .config import settings  # ❌ ImportError: attempted relative import with no known parent package
```

### 3.2 作为模块/包运行（Module/Package Mode）

#### 命令格式
```bash
python -m package.module
```

#### 特性
- 使用 `-m` 参数告诉 Python 这是一个模块
- `__name__` 被设置为 `"__main__"`
- `__package__` 被正确设置（如 `"src"`）
- **可以使用相对导入**
- Python 知道包的层级结构

#### 示例
```bash
# 作为模块运行
python -m src.server
```

```python
# src/server.py
print(f"__name__ = {__name__}")      # __main__
print(f"__package__ = {__package__}") # src

from .config import settings  # ✅ 成功！
```

### 3.3 `__main__.py` 的作用

当包含 `__main__.py` 时，可以直接运行包：

```python
# src/__main__.py
from .server import main

if __name__ == "__main__":
    main()
```

运行方式：
```bash
# 以下两种等价
python -m src
python -m src.__main__
```

### 3.4 运行方式对比表

| 特性 | 作为脚本运行 | 作为模块运行 |
|-----|------------|------------|
| **命令** | `python file.py` | `python -m module` |
| **`__name__`** | `"__main__"` | `"__main__"` |
| **`__package__`** | `None` | 包名（如 `"src"`） |
| **相对导入** | ❌ 不支持 | ✅ 支持 |
| **绝对导入** | ⚠️ 需要 PYTHONPATH | ✅ 支持 |
| **适用场景** | 简单脚本 | 包结构项目 |

### 3.5 为什么相对导入需要 `__package__`？

相对导入依赖 `__package__` 变量来确定当前模块在包层级中的位置：

```python
# 当 __package__ = "src"
from .config import settings
# Python 知道：当前在 src 包中，去 src.config 找 settings

# 当 __package__ = None
from .config import settings
# Python 不知道：我在哪个包？从哪里找 .config？
# 结果：ImportError
```

---

## 4. 包的安装模式

### 4.1 `pip install .` - 常规安装

#### 命令
```bash
cd /path/to/project
pip install .
```

#### 工作原理
1. 读取 `pyproject.toml` 或 `setup.py`
2. 构建 wheel 包（临时）
3. **复制**源代码到 `site-packages/`
4. 创建命令行入口点（如果配置）

#### 安装后的目录结构
```
/opt/anaconda3/lib/python3.12/site-packages/
├── src/                           # 复制的代码副本
│   ├── __init__.py
│   ├── server.py
│   ├── config.py
│   └── ...
└── reasoning_bank_mcp-0.1.0.dist-info/
    ├── METADATA
    ├── RECORD
    ├── entry_points.txt
    └── ...
```

#### 特性
- ✅ 正式安装，像第三方库一样
- ✅ 性能稍快（直接从 site-packages 加载）
- ✅ 可以移动或删除源代码目录
- ❌ **修改源代码不生效**
- ❌ 每次修改都需要重新安装

#### 实际例子
```bash
# 安装
pip install .

# 修改源代码
echo 'print("修改了代码")' >> src/server.py

# 运行
reasoning-bank-mcp
# ❌ 看不到修改！因为运行的是 site-packages 中的旧副本

# 必须重新安装
pip install .

# 现在才能看到修改
reasoning-bank-mcp
# ✅ 看到修改
```

#### 使用场景
- 🚀 生产环境部署
- 📦 分发给其他用户
- 🧪 CI/CD 测试
- 📖 安装稳定版本

### 4.2 `pip install -e .` - 可编辑安装

#### 命令
```bash
cd /path/to/project
pip install -e .
# -e = --editable（可编辑）
# 也称为 development mode（开发模式）
```

#### 工作原理
1. 读取 `pyproject.toml` 或 `setup.py`
2. **不复制代码**
3. 在 `site-packages/` 创建链接文件
4. Python 从**源代码目录**加载代码

#### 安装后的目录结构
```
/opt/anaconda3/lib/python3.12/site-packages/
├── reasoning-bank-mcp.egg-link         # 指向源代码的链接
├── easy-install.pth                    # 或 .pth 文件
└── reasoning_bank_mcp-0.1.0.dist-info/

# .egg-link 或 .pth 文件内容：
/Users/hanw/ai-code/reasoning-bank-mcp
```

#### 特性
- ✅ **修改代码立即生效**
- ✅ 无需重新安装
- ✅ 完美的开发体验
- ⚠️ 依赖源代码目录存在
- ⚠️ 删除/移动源码目录会导致导入失败

#### 实际例子
```bash
# 可编辑安装
pip install -e .

# 修改源代码
echo 'print("修改了代码")' >> src/server.py

# 立即运行
reasoning-bank-mcp
# ✅ 立即看到修改！无需重新安装

# 继续修改任何文件
vim src/llm/factory.py

# 立即生效
reasoning-bank-mcp
# ✅ 新修改已应用
```

#### 使用场景
- 🎯 本地开发（**强烈推荐**）
- 🔧 频繁修改调试
- 🧑‍💻 贡献开源项目
- 🔍 代码实验和学习

### 4.3 两种安装模式对比

| 特性 | `pip install .` | `pip install -e .` |
|-----|----------------|-------------------|
| **安装方式** | 复制代码到 site-packages | 创建链接到源代码 |
| **代码位置** | `site-packages/src/` | 项目目录 `./src/` |
| **修改代码** | ❌ 需重新安装 | ✅ 立即生效 |
| **性能** | 稍快 | 几乎相同 |
| **移动源目录** | ✅ 可以 | ❌ 会失败 |
| **删除源目录** | ✅ 仍可用 | ❌ 导入失败 |
| **适用场景** | 生产部署 | 开发调试 |
| **卸载** | `pip uninstall package` | `pip uninstall package` |

### 4.4 检查安装模式

#### 方法 1：使用 `pip show`
```bash
pip show reasoning-bank-mcp

# 输出示例：
# Name: reasoning-bank-mcp
# Version: 0.1.0
# Location: /Users/hanw/ai-code/reasoning-bank-mcp  # ← 源码路径 = -e 安装
# Location: /opt/.../site-packages                  # ← site-packages = 常规安装
```

#### 方法 2：列出可编辑安装
```bash
pip list -e
# 如果看到 reasoning-bank-mcp，说明是可编辑安装
```

#### 方法 3：检查代码实际位置
```bash
python -c "import src; print(src.__file__)"

# 可编辑安装输出：
# /Users/hanw/ai-code/reasoning-bank-mcp/src/__init__.py

# 常规安装输出：
# /opt/.../site-packages/src/__init__.py
```

### 4.5 切换安装模式

```bash
# 从任何模式切换到可编辑安装
pip uninstall reasoning-bank-mcp
pip install -e .

# 从任何模式切换到常规安装
pip uninstall reasoning-bank-mcp
pip install .
```

---

## 5. reasoning-bank-mcp 项目实战

### 5.1 项目结构分析

```
reasoning-bank-mcp/
├── pyproject.toml              # 项目配置和依赖
├── README.md
├── src/                        # src-layout 源码目录
│   ├── __init__.py            # 包初始化
│   ├── __main__.py            # python -m src 入口
│   ├── server.py              # 主服务器模块
│   ├── config.py              # 配置管理
│   │
│   ├── llm/                   # LLM 子包
│   │   ├── __init__.py
│   │   ├── base.py
│   │   ├── factory.py
│   │   └── providers/         # LLM providers 子包
│   │       ├── __init__.py
│   │       ├── dashscope.py
│   │       ├── openai.py
│   │       └── anthropic.py
│   │
│   ├── storage/               # 存储子包
│   │   ├── __init__.py
│   │   ├── base.py
│   │   └── backends/
│   │       └── json_backend.py
│   │
│   ├── retrieval/             # 检索子包
│   │   ├── __init__.py
│   │   ├── base.py
│   │   ├── factory.py
│   │   └── strategies/
│   │       ├── __init__.py
│   │       ├── cosine_retrieval.py
│   │       └── hybrid_retrieval.py
│   │
│   ├── tools/                 # MCP 工具子包
│   │   ├── __init__.py
│   │   ├── retrieve_memory.py
│   │   └── extract_memory.py
│   │
│   ├── prompts/               # 提示模板子包
│   │   ├── __init__.py
│   │   ├── templates.py
│   │   └── formatters.py
│   │
│   └── utils/                 # 工具函数子包
│       ├── __init__.py
│       └── similarity.py
│
└── tests/                      # 测试目录
```

### 5.2 导入示例分析

#### 示例 1：顶层模块导入（server.py）
```python
# src/server.py
from .config import load_config                    # 相对导入：同级模块
from .llm import LLMFactory, EmbeddingFactory      # 相对导入：同级子包
from .storage import StorageFactory                # 相对导入：同级子包
from .retrieval import RetrievalFactory            # 相对导入：同级子包
from .tools import RetrieveMemoryTool, ExtractMemoryTool  # 相对导入：同级子包
```

**分析**：
- ✅ 全部使用相对导入（`.`）
- ✅ 表示这些都是 src 包内部的模块
- ✅ 包重命名不需要修改

#### 示例 2：子包初始化（llm/__init__.py）
```python
# src/llm/__init__.py
from .base import LLMProvider, EmbeddingProvider     # 相对导入：同级模块
from .factory import LLMFactory, EmbeddingFactory    # 相对导入：同级模块

__all__ = [
    "LLMProvider",
    "EmbeddingProvider",
    "LLMFactory",
    "EmbeddingFactory",
]
```

**分析**：
- ✅ 从同级模块导入
- ✅ 使用 `__all__` 控制导出
- ✅ 简化外部导入路径

#### 示例 3：工厂模式导入（llm/factory.py）
```python
# src/llm/factory.py
from .base import LLMProvider, EmbeddingProvider     # 相对导入：同级
from .providers import (                             # 相对导入：子包
    DashScopeLLMProvider,
    DashScopeEmbeddingProvider,
    OpenAILLMProvider,
    OpenAIEmbeddingProvider,
    AnthropicLLMProvider,
)
```

**分析**：
- ✅ 导入同级模块（base.py）
- ✅ 导入子包（providers/）
- ✅ 清晰的层级关系

#### 示例 4：深层子包（llm/providers/__init__.py）
```python
# src/llm/providers/__init__.py
from .dashscope import DashScopeLLMProvider, DashScopeEmbeddingProvider
from .openai import OpenAILLMProvider, OpenAIEmbeddingProvider
from .anthropic import AnthropicLLMProvider

__all__ = [
    "DashScopeLLMProvider",
    "DashScopeEmbeddingProvider",
    "OpenAILLMProvider",
    "OpenAIEmbeddingProvider",
    "AnthropicLLMProvider",
]
```

**分析**：
- ✅ 从同级模块导入
- ✅ 使外部可以 `from src.llm.providers import OpenAILLMProvider`
- ✅ 封装内部实现细节

#### 示例 5：包入口（__init__.py）
```python
# src/__init__.py
__version__ = "0.1.0"
__author__ = "Wang Han"
__description__ = "Memory-augmented reasoning for AI agents via MCP"

from .config import load_config, get_config
from .server import run_server

__all__ = [
    "load_config",
    "get_config",
    "run_server",
]
```

**分析**：
- ✅ 定义包元数据
- ✅ 暴露核心 API
- ✅ 简化外部使用

### 5.3 运行方式

项目配置了多种运行方式：

#### 方式 1：使用 `python -m`（开发推荐）

```bash
cd /Users/hanw/ai-code/reasoning-bank-mcp

# 运行主模块（调用 __main__.py）
python -m src
```

**`__main__.py` 内容**：
```python
# src/__main__.py
import asyncio
from .server import main

if __name__ == "__main__":
    asyncio.run(main())
```

#### 方式 2：安装后使用命令行（生产推荐）

```bash
# 开发模式安装
pip install -e .

# 运行命令
reasoning-bank-mcp
```

**配置在 `pyproject.toml`**：
```toml
[project.scripts]
reasoning-bank-mcp = "src.server:run_server"
```

这会创建一个命令行入口，调用 `src.server.run_server()` 函数。

#### 方式 3：使用 uv（现代包管理）

```bash
# 使用 uv 运行
uv run python -m src

# 或安装后运行
uv pip install -e .
uv run reasoning-bank-mcp
```

#### 方式 4：直接运行（不推荐）

```bash
# ❌ 会失败（相对导入错误）
python src/server.py

# ⚠️ 需要设置 PYTHONPATH
export PYTHONPATH=/Users/hanw/ai-code/reasoning-bank-mcp
python src/server.py
```

**为什么不推荐**：
- 需要手动管理 PYTHONPATH
- 违背包设计理念
- 在不同环境可能有问题

### 5.4 推荐工作流程

#### 开发阶段

```bash
# 1. 进入项目目录
cd /Users/hanw/ai-code/reasoning-bank-mcp

# 2. 可编辑安装（包含开发依赖）
pip install -e ".[dev]"

# 3. 修改代码
vim src/server.py

# 4. 立即运行测试
reasoning-bank-mcp
# 或
python -m src

# 5. 运行测试
pytest tests/

# 6. 代码格式化
black src/
ruff check src/
```

#### 生产部署

```bash
# 1. 正式安装
pip install .

# 2. 运行服务
reasoning-bank-mcp

# 或使用 systemd/supervisor 等管理
```

### 5.5 常见问题解决

#### 问题 1：ModuleNotFoundError

```python
# 错误：ModuleNotFoundError: No module named 'src'
```

**解决方案**：
```bash
# 检查是否在正确目录
pwd  # 应该在项目根目录

# 检查 __init__.py 存在
ls src/__init__.py

# 使用 python -m 运行
python -m src

# 或安装包
pip install -e .
```

#### 问题 2：相对导入失败

```python
# 错误：ImportError: attempted relative import with no known parent package
```

**解决方案**：
```bash
# ❌ 不要直接运行文件
python src/server.py

# ✅ 使用 python -m
python -m src.server
```

#### 问题 3：修改代码不生效

```python
# 修改了代码但运行时看不到变化
```

**解决方案**：
```bash
# 检查安装模式
pip show reasoning-bank-mcp

# 如果是常规安装，切换到可编辑安装
pip uninstall reasoning-bank-mcp
pip install -e .
```

#### 问题 4：循环导入

```python
# 错误：ImportError: cannot import name 'X' from partially initialized module
```

**解决方案**：
1. 重构代码，提取共同依赖到第三方模块
2. 使用延迟导入（在函数内部导入）
3. 检查是否有不必要的导入

---

## 6. 最佳实践总结

### 6.1 项目结构

✅ **推荐：src-layout**
```
project/
├── pyproject.toml
├── src/
│   └── package/
│       ├── __init__.py
│       └── modules...
└── tests/
```

❌ **避免：平铺布局**
```
project/
├── package/
├── tests/
└── setup.py
```

### 6.2 导入策略

| 场景 | 使用方式 | 示例 |
|-----|---------|-----|
| **包内部导入** | 相对导入 | `from .module import func` |
| **跨包导入** | 绝对导入 | `from other_package import func` |
| **外部库** | 绝对导入 | `import numpy as np` |
| **同级模块** | 相对导入 | `from . import sibling` |
| **子包导入** | 相对导入 | `from .subpkg import mod` |

### 6.3 运行方式

| 场景 | 推荐方式 | 命令 |
|-----|---------|-----|
| **开发调试** | `python -m` | `python -m src` |
| **生产运行** | 安装后命令 | `reasoning-bank-mcp` |
| **CI/CD** | `python -m` | `python -m pytest` |
| **脚本** | 添加入口点 | 配置 `[project.scripts]` |

### 6.4 安装模式

| 阶段 | 使用方式 | 命令 |
|-----|---------|-----|
| **开发** | 可编辑安装 | `pip install -e ".[dev]"` |
| **测试** | 可编辑安装 | `pip install -e .` |
| **生产** | 常规安装 | `pip install .` |
| **分发** | wheel/sdist | `pip install package` |

### 6.5 代码组织

#### `__init__.py` 使用
```python
# good: 简洁的包接口
from .core import main_function
from .utils import helper

__all__ = ['main_function', 'helper']
__version__ = '0.1.0'
```

#### 相对导入
```python
# good: 包内部使用相对导入
from .config import settings
from ..utils import helper

# bad: 包内部使用绝对导入
from mypackage.config import settings
```

#### 循环依赖避免
```python
# good: 延迟导入
def function():
    from .other_module import something
    return something()

# bad: 顶层循环导入
from .other_module import something
```

### 6.6 配置文件（pyproject.toml）

```toml
[project]
name = "reasoning-bank-mcp"
version = "0.1.0"
requires-python = ">=3.10"
dependencies = [
    "mcp>=0.9.0",
    "openai>=1.0.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=7.0.0",
    "black>=23.0.0",
    "ruff>=0.1.0",
]

[project.scripts]
reasoning-bank-mcp = "src.server:run_server"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src"]
```

### 6.7 开发工作流清单

#### 新项目启动
```bash
# 1. 创建项目结构
mkdir -p src/mypackage tests docs

# 2. 创建 __init__.py
touch src/mypackage/__init__.py

# 3. 配置 pyproject.toml
# ...

# 4. 可编辑安装
pip install -e ".[dev]"

# 5. 开始开发
```

#### 日常开发
```bash
# 1. 修改代码
vim src/mypackage/module.py

# 2. 立即测试（无需重装）
python -m mypackage
pytest tests/

# 3. 代码检查
black src/
ruff check src/

# 4. 提交
git add .
git commit -m "feat: add feature"
```

#### 发布准备
```bash
# 1. 更新版本号
vim pyproject.toml

# 2. 测试完整安装
pip uninstall mypackage
pip install .

# 3. 构建分发包
python -m build

# 4. 发布到 PyPI
twine upload dist/*
```

---

## 附录

### A. 快速参考

#### 导入语法速查

```python
# 绝对导入
import package.module
from package.module import function
from package.subpackage.module import Class

# 相对导入
from . import module              # 同级
from .module import function      # 同级模块的对象
from .. import module             # 上级
from ..module import function     # 上级模块的对象
from .subpkg import module        # 子包
```

#### 运行命令速查

```bash
# 开发
python -m package                  # 运行包（需要 __main__.py）
python -m package.module          # 运行模块
pip install -e .                  # 可编辑安装

# 生产
pip install .                     # 常规安装
package-command                   # 运行命令（需配置入口点）

# 测试
python -m pytest tests/           # 运行测试
pytest                            # 简化命令
```

### B. 相关资源

- [Python Packaging User Guide](https://packaging.python.org/)
- [PEP 420 - Implicit Namespace Packages](https://www.python.org/dev/peps/pep-0420/)
- [PEP 517 - Build System Interface](https://www.python.org/dev/peps/pep-0517/)
- [Setuptools Documentation](https://setuptools.pypa.io/)
- [PyPA Sample Project](https://github.com/pypa/sampleproject)

### C. 术语表

- **模块（Module）**：单个 `.py` 文件
- **包（Package）**：包含 `__init__.py` 的目录
- **命名空间包（Namespace Package）**：没有 `__init__.py` 的包（PEP 420）
- **site-packages**：Python 第三方包的安装目录
- **PYTHONPATH**：Python 模块搜索路径
- **src-layout**：将源码放在 `src/` 目录的项目布局
- **可编辑安装（Editable Install）**：`pip install -e`，代码修改立即生效

---

**文档版本**：1.0
**最后更新**：2025-10-25
**项目**：reasoning-bank-mcp
**作者**：Wang Han
