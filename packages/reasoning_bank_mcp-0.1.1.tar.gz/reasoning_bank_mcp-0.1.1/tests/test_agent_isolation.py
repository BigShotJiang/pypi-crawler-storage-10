"""测试 Agent ID 隔离功能"""
import asyncio
import sys
import os
from pathlib import Path

# 添加项目根目录到 path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root / "src"))

from src.config import load_config
from src.storage import StorageFactory
from src.llm import LLMFactory, EmbeddingFactory
from src.retrieval import RetrievalFactory
from src.tools import RetrieveMemoryTool, ExtractMemoryTool


async def test_agent_isolation():
    """测试 Agent ID 隔离"""
    print("=" * 60)
    print("测试 Agent ID 隔离功能")
    print("=" * 60)

    # 1. 初始化组件
    print("\n[1] 初始化组件...")
    config = load_config()
    storage = StorageFactory.create(config.get_storage_config())
    llm = LLMFactory.create(config.get_llm_config())
    embedding = EmbeddingFactory.create(config.get_embedding_config())
    retrieval = RetrievalFactory.create(
        config.get("retrieval", "strategy"),
        config.get("retrieval", config.get("retrieval", "strategy"))
    )

    extract_tool = ExtractMemoryTool(config, storage, llm, embedding)
    retrieve_tool = RetrieveMemoryTool(config, storage, embedding, retrieval)

    print("✓ 组件初始化完成")

    # 2. 添加测试数据：data-analyst 的记忆
    print("\n[2] 添加 data-analyst 的记忆...")
    result1 = await extract_tool.execute(
        trajectory=[
            {"step": 1, "role": "user", "content": "如何处理缺失值？"},
            {"step": 2, "role": "assistant", "content": "使用 pandas.fillna() 或 dropna()"}
        ],
        query="数据清洗：处理缺失值",
        success_signal=True,
        async_mode=False,
        agent_id="data-analyst"  # ← Agent A
    )
    print(f"✓ data-analyst 记忆已保存: {result1['extracted_count']} 条")

    # 3. 添加测试数据：code-reviewer 的记忆
    print("\n[3] 添加 code-reviewer 的记忆...")
    result2 = await extract_tool.execute(
        trajectory=[
            {"step": 1, "role": "user", "content": "如何审查 API 设计？"},
            {"step": 2, "role": "assistant", "content": "检查 RESTful 规范和版本控制"}
        ],
        query="代码审查：API 设计",
        success_signal=True,
        async_mode=False,
        agent_id="code-reviewer"  # ← Agent B
    )
    print(f"✓ code-reviewer 记忆已保存: {result2['extracted_count']} 条")

    # 4. 添加全局记忆
    print("\n[4] 添加全局记忆...")
    result3 = await extract_tool.execute(
        trajectory=[
            {"step": 1, "role": "user", "content": "Python 最佳实践？"},
            {"step": 2, "role": "assistant", "content": "遵循 PEP 8 规范"}
        ],
        query="通用知识：Python 最佳实践",
        success_signal=True,
        async_mode=False,
        agent_id=None  # ← 全局记忆
    )
    print(f"✓ 全局记忆已保存: {result3['extracted_count']} 条")

    # 5. 测试隔离：data-analyst 只能看到自己的记忆
    print("\n[5] 测试隔离：data-analyst 检索...")
    result_a = await retrieve_tool.execute(
        query="数据处理",
        agent_id="data-analyst",
        top_k=10
    )
    print(f"✓ data-analyst 检索到 {len(result_a['memories'])} 条记忆:")
    for mem in result_a['memories']:
        print(f"  - [{mem.get('title', 'N/A')}] (agent_id={mem.get('agent_id', 'unknown')})")

    # 验证：应该只有 data-analyst 的记忆
    agent_ids = [m.get('agent_id') for m in result_a['memories']]
    assert all(aid == "data-analyst" for aid in agent_ids), "❌ 隔离失败：包含其他 agent 的记忆"
    print("✓ 隔离验证通过：只包含 data-analyst 的记忆")

    # 6. 测试隔离：code-reviewer 只能看到自己的记忆
    print("\n[6] 测试隔离：code-reviewer 检索...")
    result_b = await retrieve_tool.execute(
        query="代码审查",
        agent_id="code-reviewer",
        top_k=10
    )
    print(f"✓ code-reviewer 检索到 {len(result_b['memories'])} 条记忆:")
    for mem in result_b['memories']:
        print(f"  - [{mem.get('title', 'N/A')}] (agent_id={mem.get('agent_id', 'unknown')})")

    # 验证：应该只有 code-reviewer 的记忆
    agent_ids = [m.get('agent_id') for m in result_b['memories']]
    assert all(aid == "code-reviewer" for aid in agent_ids), "❌ 隔离失败：包含其他 agent 的记忆"
    print("✓ 隔离验证通过：只包含 code-reviewer 的记忆")

    # 7. 测试全局模式：不传 agent_id 应该看到所有记忆
    print("\n[7] 测试全局模式：不传 agent_id...")
    result_all = await retrieve_tool.execute(
        query="通用知识",
        agent_id=None,  # ← 不过滤
        top_k=10
    )
    print(f"✓ 全局检索到 {len(result_all['memories'])} 条记忆:")
    agent_count = {}
    for mem in result_all['memories']:
        aid = mem.get('agent_id', 'null')
        agent_count[aid] = agent_count.get(aid, 0) + 1

    print(f"  记忆分布: {agent_count}")
    print("✓ 全局模式验证通过：可以看到所有记忆")

    # 8. 统计信息
    print("\n[8] 统计信息...")
    all_memories = await storage.get_all_memories()
    print(f"总记忆数: {len(all_memories)}")

    by_agent = {}
    for mem in all_memories:
        aid = mem.get('agent_id', 'null')
        by_agent[aid] = by_agent.get(aid, 0) + 1

    print("按 Agent 分布:")
    for aid, count in by_agent.items():
        print(f"  - {aid}: {count} 条")

    print("\n" + "=" * 60)
    print("✓ 所有测试通过！Agent ID 隔离功能正常")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(test_agent_isolation())
