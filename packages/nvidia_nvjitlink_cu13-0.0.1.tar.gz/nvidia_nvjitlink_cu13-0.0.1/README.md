⚠️ THIS PROJECT 'nvidia-nvjitlink-cu13' IS DEPRECATED.
Please use 'nvidia-nvjitlink' instead.

To install the correct package, use:

    pip install nvidia-nvjitlink

For more information, visit: https://pypi.org/project/nvidia-nvjitlink/
