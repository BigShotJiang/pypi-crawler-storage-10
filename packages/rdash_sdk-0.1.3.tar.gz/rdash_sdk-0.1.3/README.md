# rdash-sdk

Install:

```bash
pip install rdash-sdk
```

Usage:

```python
from rdash_sdk import ChunkUploader

# Example: initialize and use the uploader
# uploader = ChunkUploader(
#     init_url="https://api.example.com/uploads/init",
#     complete_url="https://api.example.com/uploads/complete",
#     auth_token="YOUR_TOKEN",
# )
# uploader.upload_file("/path/to/file")
```