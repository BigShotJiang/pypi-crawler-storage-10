from .evaluate import evaluate_page, evaluate_pages

__all__ = [
    "evaluate_page",
    "evaluate_pages",
]
