Package for developing Nominode apps
