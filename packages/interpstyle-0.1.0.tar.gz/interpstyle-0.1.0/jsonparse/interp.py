import json
import requests

packagename = "interpstyle"
def parse(f) -> dict:    
    try:        
        style = json.load(f)
    except:
        style = {}
    try:    
        response = requests.post(url=f"https://api.{packagename}.org/"+f"parse", json=style, timeout=30)
        response.raise_for_status()  # raises exception for 4xx/5xx responses

        # Try to parse JSON response safely
        try:
            return response.json()
        except ValueError:
            return style
    except requests.RequestException as e:
        return style