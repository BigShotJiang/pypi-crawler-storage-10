from setuptools import setup, find_packages

setup(
    name="interpstyle",                # Your package name
    version="0.1.0",                     # Version number
    author="Your Name",                  # Your name
    description="A simple interpretation package example",
    packages=find_packages(),            # Automatically find packages
    python_requires=">=3.8",             # Minimum Python version
)