"""Import Graph Builder: Extends AST analysis to build a proper dependency graph.

Takes the imports extracted by ast_analysis.py and builds a graph structure:
- Nodes: Python files
- Edges: Import relationships (A imports B)
- Resolves module names to actual file paths

Used by architecture_lint to validate import rules.
"""

from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Set

from maxwell.ast.python_parser import analyze_python_file

__all__ = ["ImportGraph", "ImportEdge", "build_import_graph"]


@dataclass
class ImportEdge:
    """Represents an import relationship between files."""

    source_file: Path  # File that contains the import
    target_module: str  # Module name being imported (e.g., "maxwell.workflows.base")
    target_file: Path | None  # Resolved file path (None if external or unresolved)
    line_number: int  # Line number in source file
    import_type: str  # "import" or "from_import"


@dataclass
class ImportGraph:
    """Dependency graph of Python imports.

    Nodes: Files in the project
    Edges: Import relationships

    Provides:
    - Forward lookup: file → modules it imports
    - Reverse lookup: module → files that import it
    - Path resolution: module name → file path
    - Cycle detection
    """

    project_root: Path
    src_root: Path = field(init=False)

    # Graph structure
    nodes: Set[Path] = field(default_factory=set)
    edges: List[ImportEdge] = field(default_factory=list)

    # Forward index: file → imports
    imports: Dict[Path, List[ImportEdge]] = field(default_factory=lambda: defaultdict(list))

    # Reverse index: module → importers
    imported_by: Dict[str, Set[Path]] = field(default_factory=lambda: defaultdict(set))

    # Module resolution cache
    module_to_file: Dict[str, Path] = field(default_factory=dict)

    def __post_init__(self):
        self.src_root = self.project_root / "src" / "maxwell"

    def resolve_module_to_file(self, module_name: str) -> Path | None:
        """Resolve a module name to a file path.

        Args:
            module_name: Module like "maxwell.workflows.base"

        Returns:
            Path to the file, or None if external/unresolved

        Examples:
            "maxwell.workflows.base" → src/maxwell/workflows/base.py
            "maxwell.db" → src/maxwell/db.py
            "requests" → None (external)

        """
        # Check cache
        if module_name in self.module_to_file:
            return self.module_to_file[module_name]

        # External package (not in maxwell.*)
        if not module_name.startswith("maxwell"):
            self.module_to_file[module_name] = None
            return None

        # Strip "maxwell." prefix
        if module_name.startswith("maxwell."):
            relative_path = module_name[len("maxwell.") :]
        else:
            relative_path = module_name

        # Convert module path to file path
        # "workflows.base" → "workflows/base.py"
        parts = relative_path.split(".")
        file_path = self.src_root / "/".join(parts[:-1]) / f"{parts[-1]}.py"

        # Check if file exists
        if file_path.exists():
            self.module_to_file[module_name] = file_path
            return file_path

        # Check if it's a package (__init__.py)
        package_path = self.src_root / "/".join(parts) / "__init__.py"
        if package_path.exists():
            self.module_to_file[module_name] = package_path
            return package_path

        # Unresolved
        self.module_to_file[module_name] = None
        return None

    def add_file(self, file_path: Path):
        """Add a file node to the graph."""
        self.nodes.add(file_path)

    def add_import(
        self,
        source_file: Path,
        target_module: str,
        line_number: int = 0,
        import_type: str = "import",
    ):
        """Add an import edge to the graph.

        Args:
            source_file: File containing the import
            target_module: Module being imported
            line_number: Line number of import
            import_type: "import" or "from_import"

        """
        # Resolve target module to file
        target_file = self.resolve_module_to_file(target_module)

        # Create edge
        edge = ImportEdge(
            source_file=source_file,
            target_module=target_module,
            target_file=target_file,
            line_number=line_number,
            import_type=import_type,
        )

        # Add to graph
        self.edges.append(edge)
        self.imports[source_file].append(edge)
        self.imported_by[target_module].add(source_file)

        # Add target file as node if resolved
        if target_file:
            self.nodes.add(target_file)

    def get_imports_for_file(self, file_path: Path) -> List[ImportEdge]:
        """Get all imports from a file."""
        return self.imports[file_path]

    def get_importers_of_module(self, module_name: str) -> Set[Path]:
        """Get all files that import a module."""
        return self.imported_by[module_name]

    def find_cycles(self) -> List[List[Path]]:
        """Find circular import chains.

        Returns:
            List of cycles, each cycle is a list of file paths

        """
        cycles = []
        visited = set()

        def dfs(node: Path, path: List[Path]) -> List[Path] | None:
            """DFS to find cycles."""
            if node in path:
                # Found cycle
                cycle_start = path.index(node)
                return path[cycle_start:] + [node]

            if node in visited:
                return None

            visited.add(node)
            path.append(node)

            # Visit all imports
            for edge in self.imports[node]:
                if edge.target_file:
                    cycle = dfs(edge.target_file, path[:])
                    if cycle:
                        return cycle

            return None

        # Check each node as potential cycle start
        for node in self.nodes:
            if node not in visited:
                cycle = dfs(node, [])
                if cycle:
                    cycles.append(cycle)

        return cycles

    def get_workflow_siblings(self, file_path: Path) -> List[Path]:
        """Get sibling workflows (other top-level workflows).

        Args:
            file_path: Path to a workflow file

        Returns:
            List of sibling workflow directories

        """
        try:
            rel_path = file_path.relative_to(self.src_root / "workflows")
            workflow_name = rel_path.parts[0]

            # Get all top-level workflow directories
            workflows_dir = self.src_root / "workflows"
            siblings = []

            for item in workflows_dir.iterdir():
                if item.is_dir() and item.name != workflow_name and not item.name.startswith("_"):
                    siblings.append(item)

            return siblings

        except ValueError:
            # File not in workflows
            return []


def build_import_graph(project_root: Path, include_external: bool = False) -> ImportGraph:
    """Build import graph for a project.

    Args:
        project_root: Root directory of project
        include_external: Include external packages in graph (default: False)

    Returns:
        ImportGraph with all import relationships

    """
    graph = ImportGraph(project_root=project_root)

    print(f"Building import graph for: {project_root}")

    # Find all Python files
    src_root = project_root / "src" / "maxwell"
    py_files = list(src_root.rglob("*.py"))

    print(f"Found {len(py_files)} Python files")

    # Analyze each file
    for file_path in py_files:
        if "__pycache__" in str(file_path):
            continue

        # Add file as node
        graph.add_file(file_path)

        # Analyze imports using existing AST workflow
        analysis = analyze_python_file(file_path)
        if not analysis:
            continue

        # Add import edges
        for import_module in analysis.imports:
            # Skip external packages unless requested
            if not include_external and not import_module.startswith("maxwell"):
                continue

            graph.add_import(
                source_file=file_path,
                target_module=import_module,
                line_number=0,  # TODO: Track line numbers from AST
                import_type="import",  # TODO: Distinguish import vs from_import
            )

    print(f"Graph: {len(graph.nodes)} nodes, {len(graph.edges)} edges")

    return graph


def analyze_import_graph(graph: ImportGraph) -> dict:
    """Analyze import graph and generate statistics.

    Args:
        graph: Built import graph

    Returns:
        Dict with statistics and findings

    """
    stats = {
        "total_files": len(graph.nodes),
        "total_imports": len(graph.edges),
        "external_imports": sum(1 for e in graph.edges if e.target_file is None),
        "internal_imports": sum(1 for e in graph.edges if e.target_file is not None),
    }

    # Find most imported modules
    most_imported = sorted(graph.imported_by.items(), key=lambda x: len(x[1]), reverse=True)[:10]

    stats["most_imported"] = [
        {"module": module, "count": len(importers)} for module, importers in most_imported
    ]

    # Find cycles
    cycles = graph.find_cycles()
    stats["cycles"] = len(cycles)

    if cycles:
        stats["cycle_details"] = [
            {"files": [str(f) for f in cycle], "length": len(cycle)} for cycle in cycles
        ]

    return stats


if __name__ == "__main__":
    import sys

    project_root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    graph = build_import_graph(project_root)

    print("\n" + "=" * 80)
    print("IMPORT GRAPH ANALYSIS")
    print("=" * 80)

    stats = analyze_import_graph(graph)

    print(f"\nFiles: {stats['total_files']}")
    print(f"Imports: {stats['total_imports']}")
    print(f"  Internal: {stats['internal_imports']}")
    print(f"  External: {stats['external_imports']}")

    if stats["cycles"] > 0:
        print(f"\n⚠️  Circular imports detected: {stats['cycles']}")
        for cycle in stats.get("cycle_details", []):
            print(f"  Cycle ({cycle['length']} files):")
            for file in cycle["files"]:
                print(f"    → {file}")
    else:
        print("\n✅ No circular imports")

    print("\nMost imported modules:")
    for item in stats["most_imported"]:
        print(f"  {item['module']:50} ({item['count']} imports)")
