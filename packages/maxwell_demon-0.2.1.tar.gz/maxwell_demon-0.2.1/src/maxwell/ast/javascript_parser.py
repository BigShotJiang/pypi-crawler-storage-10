"""AST-based code analysis for JavaScript files.

Uses pyjsparser for ECMAScript parsing (JavaScript, no TypeScript).
Pure Python implementation - no Node.js required.
Extracts structural information similar to Python AST analysis.

Requires: pip install maxwell[javascript]
"""

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

__all__ = ["JavaScriptFileAnalysis", "analyze_javascript_file"]


@dataclass
class JavaScriptFileAnalysis:
    """Analysis results for a single JavaScript file."""

    path: Path
    classes: List[str]  # ES6 classes
    functions: List[str]  # Function declarations and expressions
    imports: List[str]  # Import statements (ES6 modules)
    exports: List[str]  # Export statements
    has_tests: bool
    complexity_hints: List[str]
    suggested_justification: str


def _parse_with_pyjsparser(file_path: Path) -> Optional[dict]:
    """Parse JavaScript file using pyjsparser.

    Args:
        file_path: Path to JavaScript file

    Returns:
        AST dictionary or None if parsing fails

    """
    try:
        # Lazy import - only load when actually parsing JS
        import pyjsparser
    except ImportError as e:
        raise ImportError(
            "JavaScript parsing requires pyjsparser. "
            "Install with: pip install maxwell[javascript] or pip install pyjsparser"
        ) from e

    try:
        code = file_path.read_text(encoding="utf-8")
        ast = pyjsparser.parse(code)
        return ast
    except (OSError, UnicodeDecodeError, pyjsparser.JsSyntaxError):
        return None


def _extract_from_ast(ast: dict) -> tuple[List[str], List[str], List[str], List[str], bool]:
    """Extract structural information from JavaScript AST.

    Args:
        ast: Esprima AST dictionary

    Returns:
        Tuple of (classes, functions, imports, exports, has_tests)

    """
    classes = []
    functions = []
    imports = []
    exports = []
    has_tests = False

    def traverse(node):
        nonlocal has_tests

        if not isinstance(node, dict):
            return

        node_type = node.get("type")

        # Extract class declarations
        if node_type == "ClassDeclaration":
            class_name = node.get("id", {}).get("name")
            if class_name:
                classes.append(class_name)
                # Check for test classes
                if "test" in class_name.lower() or "spec" in class_name.lower():
                    has_tests = True

        # Extract function declarations
        elif node_type == "FunctionDeclaration":
            func_name = node.get("id", {}).get("name")
            if func_name:
                functions.append(func_name)
                # Check for test functions
                if func_name.startswith("test") or "test" in func_name.lower():
                    has_tests = True

        # Extract arrow functions and function expressions (if assigned to variable)
        elif node_type == "VariableDeclarator":
            if node.get("init", {}).get("type") in [
                "FunctionExpression",
                "ArrowFunctionExpression",
            ]:
                var_name = node.get("id", {}).get("name")
                if var_name:
                    functions.append(var_name)

        # Extract imports (ES6)
        elif node_type == "ImportDeclaration":
            source = node.get("source", {}).get("value")
            if source:
                imports.append(source)

        # Extract require statements (CommonJS)
        elif node_type == "CallExpression":
            callee = node.get("callee", {})
            if callee.get("name") == "require":
                args = node.get("arguments", [])
                if args and args[0].get("type") == "Literal":
                    imports.append(args[0].get("value"))

        # Extract exports (ES6)
        elif node_type == "ExportNamedDeclaration":
            declaration = node.get("declaration")
            if declaration:
                if declaration.get("type") == "VariableDeclaration":
                    for declarator in declaration.get("declarations", []):
                        var_name = declarator.get("id", {}).get("name")
                        if var_name:
                            exports.append(var_name)
                elif declaration.get("type") == "FunctionDeclaration":
                    func_name = declaration.get("id", {}).get("name")
                    if func_name:
                        exports.append(func_name)

        elif node_type == "ExportDefaultDeclaration":
            exports.append("default")

        # Recurse into children
        for key, value in node.items():
            if isinstance(value, dict):
                traverse(value)
            elif isinstance(value, list):
                for item in value:
                    traverse(item)

    traverse(ast)
    return classes, functions, imports, exports, has_tests


def analyze_javascript_file(file_path: Path) -> Optional[JavaScriptFileAnalysis]:
    """Analyze a JavaScript file using pyjsparser.

    Args:
        file_path: Path to JavaScript file

    Returns:
        JavaScriptFileAnalysis or None if parsing fails

    Raises:
        ImportError: If pyjsparser is not installed

    Example:
        >>> from pathlib import Path
        >>> analysis = analyze_javascript_file(Path("src/App.js"))
        >>> print(f"Found {len(analysis.functions)} functions")

    """
    # Parse with pyjsparser (lazy import inside)
    ast = _parse_with_pyjsparser(file_path)
    if not ast:
        return None

    # Extract structural information
    classes, functions, imports, exports, has_tests = _extract_from_ast(ast)

    # Generate suggested justification
    if has_tests:
        suggested_justification = "Test file"
    elif len(classes) > 0:
        suggested_justification = f"Defines {len(classes)} component(s)/class(es)"
    elif len(functions) > 0:
        suggested_justification = f"Utility functions ({len(functions)} functions)"
    elif len(exports) > 0:
        suggested_justification = "Module with exports"
    else:
        suggested_justification = "JavaScript file"

    # Complexity hints
    complexity_hints = []
    if len(functions) > 20:
        complexity_hints.append(f"Many functions ({len(functions)})")
    if len(imports) > 15:
        complexity_hints.append(f"Many dependencies ({len(imports)} imports)")

    return JavaScriptFileAnalysis(
        path=file_path,
        classes=classes,
        functions=functions,
        imports=imports,
        exports=exports,
        has_tests=has_tests,
        complexity_hints=complexity_hints,
        suggested_justification=suggested_justification,
    )


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python javascript_parser.py <file.js>")
        sys.exit(1)

    file_path = Path(sys.argv[1])
    analysis = analyze_javascript_file(file_path)

    if analysis:
        print(f"Classes: {analysis.classes}")
        print(f"Functions: {analysis.functions}")
        print(f"Imports: {analysis.imports}")
        print(f"Exports: {analysis.exports}")
        print(f"Has tests: {analysis.has_tests}")
        print(f"Suggested justification: {analysis.suggested_justification}")
    else:
        print("Failed to parse JavaScript file")
        sys.exit(1)
