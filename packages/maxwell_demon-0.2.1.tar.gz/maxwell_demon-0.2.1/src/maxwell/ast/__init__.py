"""AST-based code analysis for multiple languages.

Maxwell's AST module provides specialized file reading and analysis:
- Python: Using libcst for CST-based analysis
- JavaScript: Using esprima for ECMAScript parsing
- Import graph building for dependency analysis

This is infrastructure (filesystem I/O), not business logic.
"""

from maxwell.ast.import_graph import ImportEdge, ImportGraph, build_import_graph
from maxwell.ast.javascript_parser import JavaScriptFileAnalysis, analyze_javascript_file
from maxwell.ast.python_parser import FileAnalysis, PythonASTAnalyzer, analyze_python_file

__all__ = [
    # Python AST
    "FileAnalysis",
    "PythonASTAnalyzer",
    "analyze_python_file",
    # JavaScript AST
    "JavaScriptFileAnalysis",
    "analyze_javascript_file",
    # Import Graph
    "ImportEdge",
    "ImportGraph",
    "build_import_graph",
]
