# Maxwell AST Module

**AST-based specialized file reading and analysis** for multiple languages.

This is infrastructure (Filesystem I/O), not business logic. The AST module provides structured understanding of code files.

## Supported Languages

### Python
- **Parser**: `libcst` (Concrete Syntax Tree)
- **Features**: Classes, functions, imports, docstrings, complexity hints

### JavaScript
- **Parser**: `pyjsparser` (pure Python)
- **Features**: ES6 classes, functions, imports/exports
- **Note**: JavaScript only, no TypeScript
- **Requires**: `pip install maxwell[javascript]`

## Usage

### Python AST Analysis

```python
from pathlib import Path
from maxwell.ast import analyze_python_file

# Analyze a Python file
analysis = analyze_python_file(Path("src/app.py"))

print(f"Classes: {analysis.classes}")
print(f"Functions: {analysis.functions}")
print(f"Imports: {analysis.imports}")
print(f"Suggested justification: {analysis.suggested_justification}")
```

### JavaScript AST Analysis

```python
from pathlib import Path
from maxwell.ast import analyze_javascript_file

# Analyze a JavaScript file
analysis = analyze_javascript_file(Path("src/App.js"))

print(f"Classes: {analysis.classes}")
print(f"Functions: {analysis.functions}")
print(f"Imports: {analysis.imports}")
print(f"Exports: {analysis.exports}")
```

### Import Graph Builder

```python
from pathlib import Path
from maxwell.ast import build_import_graph

# Build dependency graph for entire project
graph = build_import_graph(Path.cwd(), include_external=False)

print(f"Total files: {len(graph.nodes)}")
print(f"Total imports: {len(graph.edges)}")

# Find circular dependencies
cycles = graph.find_cycles()
if cycles:
    print(f"Found {len(cycles)} circular import chains")
```

## Architecture

```
src/maxwell/ast/
├── __init__.py              # Public API
├── python_parser.py         # Python AST analysis (libcst)
├── javascript_parser.py     # JavaScript AST analysis (esprima)
├── import_graph.py          # Dependency graph builder
└── README.md               # This file
```

## Design Decisions

### Why AST is in Core (not Workflows)

AST analysis is **specialized file reading**, which is Filesystem I/O infrastructure:

- **Read files**: Parses source code into structured data
- **No business logic**: Just extracts structural information
- **Used by workflows**: Justification, validation, architecture linting

### Why pyjsparser for JavaScript

- **Pure Python**: No Node.js required
- **Pure ECMAScript**: No TypeScript complexity
- **ES6+ support**: Modern JavaScript features
- **Lightweight**: Minimal dependencies, ~100KB

## Future Language Support

Planned:
- **TypeScript** (using pyright or ts-node)
- **Go** (using go/ast via subprocess)
- **Rust** (using syn via Rust subprocess)

## Dependencies

**Python:**
- `libcst` (already in Maxwell core)

**JavaScript (optional):**
- `pyjsparser` (install with `maxwell[javascript]` extra)

Install JavaScript support:
```bash
pip install maxwell[javascript]
# or directly:
pip install pyjsparser
```

## Example Output

### Python File Analysis

```python
FileAnalysis(
    path=Path('src/maxwell/lm_pool.py'),
    classes=['LLMSpec', 'LLMPool'],
    functions=['get_lm', '_format_messages'],
    imports=['transformers', 'openai', 'anthropic'],
    docstring='LLM pool management and routing',
    has_tests=False,
    complexity_hints=['Function __init__ has many parameters (>7)'],
    suggested_justification='LLM registry and routing infrastructure'
)
```

### JavaScript File Analysis

```python
JavaScriptFileAnalysis(
    path=Path('src/App.js'),
    classes=['UserProfile'],
    functions=['Dashboard', 'formatDate', 'calculateTotal', 'App'],
    imports=['react', 'axios', './components'],
    exports=['UserProfile', 'Dashboard', 'formatDate', 'default'],
    has_tests=False,
    complexity_hints=[],
    suggested_justification='Defines 1 component(s)/class(es)'
)
```

## CLI Usage

### Python Parser

```bash
python -m maxwell.ast.python_parser src/app.py
```

### JavaScript Parser

```bash
python -m maxwell.ast.javascript_parser src/App.js
```

### Import Graph

```bash
python -m maxwell.ast.import_graph .
```
