"""Agentic refactoring workflow for DRY optimization.

Analyzes Python and JavaScript/TypeScript codebases to find and refactor duplicate code
using graph analysis and LLM reasoning.

Architecture:
1. Extract specs from Python/JS/TS files (language-agnostic representation)
2. Build multi-graph (call graph, similarity graph, inheritance graph)
3. Find duplicate cliques using graph analysis
4. Use LLM (ReAct-like) to decide refactoring strategy per clique
5. Generate safe deletion order using topological sort
6. Export refactoring report (and optionally apply changes)
"""

import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, ClassVar, Dict, List, Optional, Type

import numpy as np

from maxwell.dependencies import requires_dependencies
from maxwell.lm_pool import get_embedding
from maxwell.registry import register_workflow
from maxwell.workflows.base import (
    BaseWorkflow,
    WorkflowConfig,
    WorkflowInputs,
    WorkflowOutputs,
    WorkflowResult,
    WorkflowStatus,
)

from .refactor.extractors import JavaScriptSpecExtractor, PythonSpecExtractor
from .refactor.graph_builder import CodeGraph
from .refactor.optimizer import DRYOptimizer
from .refactor.quality_gate import IssueSeverity, IssueStatus, QualityGateManager, WorksheetManager


def check_git_status(project_root: Path) -> tuple[bool, str]:
    """Check if there are uncommitted changes in the git repository.

    Args:
        project_root: Project root directory

    Returns:
        Tuple of (has_changes, status_output)

    """
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=project_root,
            capture_output=True,
            text=True,
            timeout=5,
        )

        if result.returncode != 0:
            return False, ""  # Not a git repo or git error

        status = result.stdout.strip()
        return len(status) > 0, status

    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False, ""


# Typed Input/Output Schemas
@dataclass(frozen=True)
class AgenticRefactoringInputs(WorkflowInputs):
    """Typed inputs for agentic refactoring workflow."""

    similarity_threshold: float = 0.75
    languages: Optional[List[str]] = None  # Defaults to ["python", "javascript", "typescript"]
    dry_run: bool = True


@dataclass(frozen=True)
class AgenticRefactoringOutputs(WorkflowOutputs):
    """Typed outputs for agentic refactoring workflow."""

    functions: int
    classes: int
    call_edges: int
    actions: int
    report: str
    quality_gate_passed: bool
    quality_issues: int
    blocking_issues: int
    worksheet: str


@requires_dependencies(["numpy", "networkx"], extras_name="refactor")
@register_workflow
class AgenticRefactoringWorkflow(BaseWorkflow):
    """Workflow for agentic code refactoring using spec-based graph optimization."""

    workflow_id: str = "agentic-refactoring"
    name: str = "Agentic Refactoring"
    description: str = "DRY optimization using graph analysis and LLM reasoning"
    version: str = "1.0"
    category: str = "refactoring"
    tags: set = {"refactoring", "dry", "graph", "llm"}

    # Typed schemas
    InputSchema: ClassVar[Optional[Type[WorkflowInputs]]] = AgenticRefactoringInputs
    OutputSchema: ClassVar[Optional[Type[WorkflowOutputs]]] = AgenticRefactoringOutputs

    def __init__(self, config: WorkflowConfig | None = None):
        """Initialize workflow.

        Args:
            config: Workflow configuration (optional)

        """
        if config is None:
            config = WorkflowConfig()
        super().__init__(config)
        self.graph: CodeGraph | None = None
        self.optimizer: DRYOptimizer | None = None

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        """Execute agentic refactoring workflow.

        Args:
            project_root: Root directory to analyze
            context: Execution context (converted to typed inputs)

        Returns:
            WorkflowResult with findings and artifacts

        """
        # Parse context into typed inputs (type-safe!)
        inputs: AgenticRefactoringInputs = self.parse_inputs(context)

        # Extract typed parameters
        similarity_threshold = inputs.similarity_threshold
        languages = inputs.languages or ["python", "javascript", "typescript"]
        dry_run = inputs.dry_run

        print(f"Agentic Refactoring: {project_root}")
        print(f"Languages: {', '.join(languages)}")
        print(f"Similarity threshold: {similarity_threshold}\n")

        # Check for uncommitted changes
        has_changes, status = check_git_status(project_root)
        if has_changes:
            print("⚠️  WARNING: You have uncommitted changes in your git repository!")
            print("   It's recommended to commit your changes before running refactoring.")
            print("   Uncommitted changes:\n")
            status_lines = status.split("\n")
            for line in status_lines[:10]:  # Show first 10 files
                print(f"   {line}")
            if len(status_lines) > 10:
                print(f"   ... and {len(status_lines) - 10} more files")
            print()

            # Ask for confirmation if not dry run
            if not dry_run:
                print("   Aborting refactoring. Please commit your changes first.")
                return self.create_result(
                    outputs=None,
                    status=WorkflowStatus.FAILED,
                    error_message=f"Uncommitted changes detected:\n{status}",
                )
            else:
                print("   Continuing with dry run (no changes will be made)...\n")

        # Step 1: Extract specs from codebase
        print("Step 1: Extracting code specs...")
        graph, source_map = self._extract_specs(project_root, languages, similarity_threshold)
        self.graph = graph

        stats = graph.stats()
        print(f"  Extracted {stats.functions} functions, {stats.classes} classes\n")

        # Step 2: Build call graph
        print("Step 2: Building call graph...")
        graph.build_call_graph(source_map)
        stats = graph.stats()  # Refresh stats after building call graph
        print(f"  Built call graph with {stats.call_edges} edges\n")

        # Step 3: Build similarity graph with embeddings
        print("Step 3: Building similarity graph with embeddings...")
        try:
            embedding_client = get_embedding()
            print(f"  Using embedding model: {embedding_client.name}")

            # Create embedding function
            def embed_fn(text: str) -> np.ndarray:
                """Embed text using Maxwell's embedding infrastructure."""
                return np.array(embedding_client.embed(text))

            # Build similarity graph
            graph.build_similarity_graph(embedding_fn=embed_fn)
            stats = graph.stats()  # Refresh stats after building similarity graph
            print(f"  Built similarity graph with {stats.similarity_edges} edges\n")

        except Exception as e:
            print(f"  Warning: Could not build similarity graph: {e}")
            print("  Continuing without similarity analysis...\n")

        # Step 4: Analyze duplicates with LLM
        print("Step 4: Analyzing duplicates with LLM...")
        optimizer = DRYOptimizer(graph)
        self.optimizer = optimizer

        actions = optimizer.analyze_duplicates()
        print(f"\n  Generated {len(actions)} refactoring actions\n")

        # Step 5: Export report
        report_path = project_root / ".maxwell" / "refactoring_report.md"
        report_path.parent.mkdir(parents=True, exist_ok=True)

        print("Step 5: Generating report...")
        optimizer.export_report(report_path)

        # Step 6: Run quality gate
        print("\nStep 6: Running quality gate...")
        quality_gate = QualityGateManager(project_root)

        # Organize files by language
        files_by_language = self._organize_files_by_language(list(source_map.keys()))

        # Run all quality checks
        issues = quality_gate.run_checks(files_by_language)

        # Create quality worksheet (dataclass)
        worksheet = quality_gate.create_worksheet(issues)

        # Save worksheet using WorksheetManager
        worksheet_path = project_root / ".maxwell" / "quality_worksheet.json"
        WorksheetManager.save(worksheet, worksheet_path)

        # Count blocking issues
        blocking_count = sum(
            1
            for issue in issues
            if issue.severity == IssueSeverity.BLOCK and issue.status == IssueStatus.PENDING
        )

        # Check if quality gate passed
        passed = quality_gate.quality_gate_passed(issues)
        if not passed:
            print(f"\n❌ Quality gate FAILED: {blocking_count} blocking issues pending")
            print(f"   See worksheet: {worksheet_path}")
            print("   All blocking issues must be fixed or justified before merge")
        else:
            print("\n✅ Quality gate PASSED")

        # Step 7: Apply changes (if not dry run)
        if not dry_run:
            print("\nStep 7: Applying refactorings...")
            deletions = optimizer.get_deletion_plan()
            print(f"  Would delete {len(deletions)} code sections")
            print("  (Code deletion not yet implemented - requires language transformers)")
        else:
            print(f"\nDry run complete. See report at {report_path}")

        # Create typed outputs
        outputs = AgenticRefactoringOutputs(
            functions=stats.functions,
            classes=stats.classes,
            call_edges=stats.call_edges,
            actions=len(actions),
            report=str(report_path),
            quality_gate_passed=passed,
            quality_issues=len(issues),
            blocking_issues=blocking_count,
            worksheet=str(worksheet_path),
        )

        # Return WorkflowResult with typed outputs
        return self.create_result(outputs=outputs, status=WorkflowStatus.COMPLETED)

    def _extract_specs(
        self, project_root: Path, languages: List[str], similarity_threshold: float = 0.75
    ) -> tuple[CodeGraph, Dict[Path, str]]:
        """Extract specs from codebase.

        Args:
            project_root: Root directory
            languages: Languages to extract
            similarity_threshold: Similarity threshold for duplicate detection

        Returns:
            Tuple of (graph, source_map)

        """
        graph = CodeGraph(similarity_threshold=similarity_threshold)
        source_map = {}

        # Find files based on languages
        extensions = []
        if "python" in languages:
            extensions.append(".py")
        if "javascript" in languages:
            extensions.append(".js")
        if "typescript" in languages:
            extensions.extend([".ts", ".tsx"])

        # Scan for files
        for ext in extensions:
            pattern = f"**/*{ext}"
            files = list(project_root.glob(pattern))

            # Filter out common exclude patterns
            files = [
                f
                for f in files
                if not any(
                    part.startswith(".") or part in {"node_modules", "__pycache__", "dist", "build"}
                    for part in f.parts
                )
            ]

            print(f"  Found {len(files)} {ext} files")

            # Extract specs
            for file_path in files:
                try:
                    if ext == ".py":
                        functions, classes = PythonSpecExtractor.extract_from_file(file_path)
                    else:
                        functions, classes = JavaScriptSpecExtractor.extract_from_file(file_path)

                    # Add to graph
                    for func in functions:
                        graph.add_function(func)

                    for cls in classes:
                        graph.add_class(cls)

                    # Store source
                    source_map[file_path] = file_path.read_text()

                except Exception as e:
                    print(f"  Error extracting {file_path}: {e}")

        return graph, source_map

    def _organize_files_by_language(self, files: List[Path]) -> Dict[str, List[Path]]:
        """Organize files by programming language.

        Args:
            files: List of file paths

        Returns:
            Dictionary mapping language to list of files

        """
        files_by_language = {"python": [], "javascript": [], "typescript": []}

        for file_path in files:
            ext = file_path.suffix
            if ext == ".py":
                files_by_language["python"].append(file_path)
            elif ext == ".js":
                files_by_language["javascript"].append(file_path)
            elif ext in {".ts", ".tsx"}:
                files_by_language["typescript"].append(file_path)

        return files_by_language


# Workflow registration
def create_workflow(config: WorkflowConfig | None = None) -> AgenticRefactoringWorkflow:
    """Create agentic refactoring workflow.

    Args:
        config: Workflow configuration (optional)

    Returns:
        Workflow instance

    """
    return AgenticRefactoringWorkflow(config)


# CLI interface
def run_agentic_refactoring(
    project_root: Path | None = None,
    similarity_threshold: float = 0.75,
    languages: List[str] | None = None,
    dry_run: bool = True,
) -> WorkflowResult:
    """Run agentic refactoring workflow.

    Args:
        project_root: Root directory to analyze
        similarity_threshold: Similarity threshold for duplicates
        languages: Languages to analyze
        dry_run: If True, only generate report

    Returns:
        Workflow results

    """
    if project_root is None:
        project_root = Path.cwd()

    config = WorkflowConfig()
    workflow = create_workflow(config)

    context = {
        "similarity_threshold": similarity_threshold,
        "languages": languages,
        "dry_run": dry_run,
    }

    return workflow.execute(project_root=project_root, context=context)
