"""Language-agnostic code specifications for refactoring.

These specs abstract Python and JavaScript/TypeScript code into a common
representation that enables cross-language duplicate detection and refactoring.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

import numpy as np


@dataclass
class ParamSpec:
    """Parameter specification (language-agnostic)."""

    name: str
    type: Optional[str] = None  # From type hints or JSDoc
    description: str = ""  # From docstring


@dataclass
class PropertySpec:
    """Property/attribute specification (language-agnostic)."""

    name: str
    type: Optional[str] = None
    description: str = ""


@dataclass
class FunctionSpec:
    """Function/method specification (language-agnostic).

    This is the core abstraction that enables comparing Python and JavaScript
    functions based on their *contracts* (what they promise to do) rather than
    their *implementation* (how they do it).
    """

    name: str
    params: List[ParamSpec]
    return_type: Optional[str] = None
    docstring: str = ""  # Extracted from docstring/JSDoc

    # Semantic summary (can be LLM-generated if docstring is poor)
    implementation_summary: str = ""

    # Position info for deletion
    file: Optional[Path] = None
    language: str = "unknown"  # "python", "javascript", "typescript"
    start_line: int = 0
    end_line: int = 0
    start_pos: int = 0
    end_pos: int = 0

    # Parent class (for methods)
    parent_class: Optional[str] = None

    # For duplicate detection
    embedding: Optional[np.ndarray] = None

    # Call information
    calls: List[str] = field(default_factory=list)  # Functions this one calls
    called_by: List[str] = field(default_factory=list)  # Functions that call this

    def signature(self) -> str:
        """Get function signature for display."""
        params_str = ", ".join(f"{p.name}: {p.type}" if p.type else p.name for p in self.params)
        ret = f" -> {self.return_type}" if self.return_type else ""
        return f"{self.name}({params_str}){ret}"

    def spec_text(self) -> str:
        """Get text representation for embedding.

        This combines signature, docstring, and implementation summary
        into a single text that can be embedded for similarity comparison.
        """
        parts = [
            f"Function: {self.signature()}",
        ]

        if self.docstring:
            parts.append(f"Description: {self.docstring}")

        if self.implementation_summary:
            parts.append(f"Implementation: {self.implementation_summary}")

        if self.params:
            params_desc = ", ".join(
                f"{p.name} ({p.type}): {p.description}" for p in self.params if p.description
            )
            if params_desc:
                parts.append(f"Parameters: {params_desc}")

        return "\n".join(parts)

    def full_id(self) -> str:
        """Get unique identifier for this function."""
        if self.parent_class:
            return f"{self.file}:{self.parent_class}.{self.name}"
        return f"{self.file}:{self.name}"


@dataclass
class ClassSpec:
    """Class specification (language-agnostic)."""

    name: str
    methods: List[FunctionSpec] = field(default_factory=list)
    properties: List[PropertySpec] = field(default_factory=list)
    inherits_from: List[str] = field(default_factory=list)
    docstring: str = ""

    # Position info
    file: Optional[Path] = None
    language: str = "unknown"
    start_line: int = 0
    end_line: int = 0
    start_pos: int = 0
    end_pos: int = 0

    # For duplicate detection
    embedding: Optional[np.ndarray] = None

    def full_id(self) -> str:
        """Get unique identifier for this class."""
        return f"{self.file}:{self.name}"

    def spec_text(self) -> str:
        """Get text representation for embedding."""
        parts = [f"Class: {self.name}"]

        if self.docstring:
            parts.append(f"Description: {self.docstring}")

        if self.inherits_from:
            parts.append(f"Inherits: {', '.join(self.inherits_from)}")

        if self.methods:
            method_names = ", ".join(m.name for m in self.methods)
            parts.append(f"Methods: {method_names}")

        if self.properties:
            prop_names = ", ".join(p.name for p in self.properties)
            parts.append(f"Properties: {prop_names}")

        return "\n".join(parts)
