"""Graph builder for code refactoring analysis.

Builds multi-graph with:
- Call graph: function A calls function B
- Similarity graph: function A is similar to function B (cosine similarity > threshold)
- Inheritance graph: class A extends class B

Enables DRY optimization via:
- Clique detection: groups of similar functions (duplicates)
- Centrality metrics: PageRank to rank importance
- Topological sort: safe deletion order
"""

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Set

import networkx as nx
import numpy as np

from .specs import ClassSpec, FunctionSpec


@dataclass
class GraphStats:
    """Statistics about the code graph."""

    functions: int
    classes: int
    call_edges: int
    similarity_edges: int
    inheritance_edges: int
    duplicate_cliques: int


class CodeGraph:
    """Multi-graph for code analysis and refactoring."""

    def __init__(self, similarity_threshold: float = 0.75):
        """Initialize code graph.

        Args:
            similarity_threshold: Cosine similarity threshold for similarity edges (0-1)

        """
        self.call_graph = nx.DiGraph()  # A -> B means A calls B
        self.similarity_graph = nx.Graph()  # A -- B means A is similar to B
        self.inheritance_graph = nx.DiGraph()  # A -> B means A extends B

        self.similarity_threshold = similarity_threshold

        # Node data storage
        self.functions: Dict[str, FunctionSpec] = {}
        self.classes: Dict[str, ClassSpec] = {}

    def add_function(self, func: FunctionSpec):
        """Add function to graph.

        Args:
            func: Function specification

        """
        func_id = func.full_id()
        self.functions[func_id] = func
        self.call_graph.add_node(func_id, spec=func)
        self.similarity_graph.add_node(func_id, spec=func)

    def add_class(self, cls: ClassSpec):
        """Add class to graph.

        Args:
            cls: Class specification

        """
        cls_id = cls.full_id()
        self.classes[cls_id] = cls
        self.inheritance_graph.add_node(cls_id, spec=cls)

        # Add inheritance edges
        if cls.inherits_from:
            for parent_name in cls.inherits_from:
                # Try to find parent class by name
                parent_id = self._find_class_by_name(parent_name)
                if parent_id:
                    self.inheritance_graph.add_edge(cls_id, parent_id)

        # Add methods to call graph
        for method in cls.methods:
            self.add_function(method)

    def _find_class_by_name(self, name: str) -> str | None:
        """Find class ID by class name.

        Args:
            name: Class name to search for

        Returns:
            Class ID or None if not found

        """
        for cls_id, cls_spec in self.classes.items():
            if cls_spec.name == name:
                return cls_id
        return None

    def build_call_graph(self, source_code_map: Dict[Path, str]):
        """Build call graph by analyzing function calls.

        This is language-agnostic pattern matching. For better accuracy,
        use language-specific AST analysis.

        Args:
            source_code_map: Map of file path to source code content

        """
        for func_id, func in self.functions.items():
            if func.file not in source_code_map:
                continue

            source = source_code_map[func.file]

            # Extract function body (simple heuristic)
            # This is simplified - in production would use AST
            lines = source.split("\n")
            if func.start_line < len(lines):
                # Get a few lines after function definition
                body_lines = lines[func.start_line : func.start_line + 50]
                body = "\n".join(body_lines)

                # Find function calls in body (simple pattern matching)
                # Matches: functionName(...) or object.functionName(...)
                call_pattern = r"\b(\w+)\s*\("

                for match in re.finditer(call_pattern, body):
                    callee_name = match.group(1)

                    # Skip language keywords
                    if callee_name in {"if", "for", "while", "return", "class", "function"}:
                        continue

                    # Try to find the called function
                    callee_id = self._find_function_by_name(callee_name, func.file)
                    if callee_id:
                        self.call_graph.add_edge(func_id, callee_id)
                        func.calls.append(callee_name)

                        # Update reverse reference
                        callee = self.functions[callee_id]
                        callee.called_by.append(func.name)

    def _find_function_by_name(self, name: str, file: Path) -> str | None:
        """Find function ID by name, preferring functions in same file.

        Args:
            name: Function name
            file: Current file path (for prioritization)

        Returns:
            Function ID or None

        """
        # First try same file
        for func_id, func in self.functions.items():
            if func.name == name and func.file == file:
                return func_id

        # Then try any file
        for func_id, func in self.functions.items():
            if func.name == name:
                return func_id

        return None

    def build_similarity_graph(self, embedding_fn=None):
        """Build similarity graph using embeddings.

        Args:
            embedding_fn: Function that takes spec_text and returns embedding.
                         If None, uses pre-computed embeddings from specs.

        """
        func_ids = list(self.functions.keys())

        # Compute embeddings if needed
        if embedding_fn:
            for func_id in func_ids:
                func = self.functions[func_id]
                if func.embedding is None:
                    spec_text = func.spec_text()
                    func.embedding = embedding_fn(spec_text)

        # Build similarity edges
        for i, func_id_a in enumerate(func_ids):
            func_a = self.functions[func_id_a]
            if func_a.embedding is None:
                continue

            for func_id_b in func_ids[i + 1 :]:
                func_b = self.functions[func_id_b]
                if func_b.embedding is None:
                    continue

                # Compute cosine similarity
                similarity = self._cosine_similarity(func_a.embedding, func_b.embedding)

                if similarity >= self.similarity_threshold:
                    self.similarity_graph.add_edge(func_id_a, func_id_b, similarity=similarity)

    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """Compute cosine similarity between two vectors.

        Args:
            a: First vector
            b: Second vector

        Returns:
            Cosine similarity (0-1)

        """
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)

        if norm_a == 0 or norm_b == 0:
            return 0.0

        return float(np.dot(a, b) / (norm_a * norm_b))

    def find_duplicate_cliques(self) -> List[Set[str]]:
        """Find cliques in similarity graph (groups of similar functions).

        Returns:
            List of cliques (sets of function IDs)

        """
        # Find all maximal cliques
        cliques = list(nx.find_cliques(self.similarity_graph))

        # Filter to cliques with at least 2 functions
        return [set(clique) for clique in cliques if len(clique) >= 2]

    def compute_pagerank(self) -> Dict[str, float]:
        """Compute PageRank centrality on call graph.

        Functions with higher PageRank are called more and are more "central"
        to the codebase, so we prefer to keep them.

        Returns:
            Map of function ID to PageRank score

        """
        if len(self.call_graph.nodes) == 0:
            return {}

        return nx.pagerank(self.call_graph)

    def get_deletion_order(self, func_ids: Set[str]) -> List[str]:
        """Get safe deletion order for functions using topological sort.

        Functions that call others should be deleted first (reverse topo order).

        Args:
            func_ids: Set of function IDs to delete

        Returns:
            List of function IDs in deletion order

        """
        # Create subgraph of functions to delete
        subgraph = self.call_graph.subgraph(func_ids)

        # Topological sort (reverse order so callers are deleted first)
        try:
            topo_order = list(nx.topological_sort(subgraph))
            return list(reversed(topo_order))
        except (nx.NetworkXError, nx.NetworkXUnfeasible):
            # If there's a cycle, just return arbitrary order
            print(f"  WARNING: Circular dependencies detected in deletion set, using arbitrary order")
            return list(func_ids)

    def get_function_dependencies(self, func_id: str) -> Set[str]:
        """Get all functions that depend on this function.

        Args:
            func_id: Function ID

        Returns:
            Set of function IDs that call this function

        """
        if func_id not in self.call_graph:
            return set()

        # Get predecessors (functions that call this one)
        return set(self.call_graph.predecessors(func_id))

    def export_graphml(self, output_path: Path):
        """Export graphs to GraphML format for visualization.

        Args:
            output_path: Output directory for GraphML files

        """
        output_path.mkdir(parents=True, exist_ok=True)

        nx.write_graphml(self.call_graph, output_path / "call_graph.graphml")
        nx.write_graphml(self.similarity_graph, output_path / "similarity_graph.graphml")
        nx.write_graphml(self.inheritance_graph, output_path / "inheritance_graph.graphml")

    def stats(self) -> GraphStats:
        """Get graph statistics.

        Returns:
            Graph statistics as dataclass

        """
        return GraphStats(
            functions=len(self.functions),
            classes=len(self.classes),
            call_edges=self.call_graph.number_of_edges(),
            similarity_edges=self.similarity_graph.number_of_edges(),
            inheritance_edges=self.inheritance_graph.number_of_edges(),
            duplicate_cliques=len(self.find_duplicate_cliques()),
        )
