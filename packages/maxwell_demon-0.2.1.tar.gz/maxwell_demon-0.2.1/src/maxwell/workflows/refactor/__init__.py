"""Refactoring workflows for code optimization."""

from .graph_builder import CodeGraph, GraphStats
from .optimizer import DRYOptimizer, RefactorAction, RefactorStrategy
from .specs import ClassSpec, FunctionSpec, ParamSpec, PropertySpec

__all__ = [
    "FunctionSpec",
    "ClassSpec",
    "ParamSpec",
    "PropertySpec",
    "CodeGraph",
    "GraphStats",
    "DRYOptimizer",
    "RefactorStrategy",
    "RefactorAction",
]
