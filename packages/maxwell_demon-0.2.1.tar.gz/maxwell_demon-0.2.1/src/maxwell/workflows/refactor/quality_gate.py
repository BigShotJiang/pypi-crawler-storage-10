"""Quality gate for multi-language code analysis.

Runs language-specific linters and type checkers:
- Python: pyright, ruff, validate
- JavaScript/TypeScript: eslint, tsc

All issues are tracked in a unified worksheet format.
"""

import json
import subprocess
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional

from maxwell.config import load_config
from maxwell.workflows.validate.validation_engine import run_plugin_validation
from maxwell.workflows.validate.validators import Severity


class IssueSeverity(Enum):
    """Issue severity levels."""

    BLOCK = "BLOCK"  # Must fix or justify
    WARN = "WARN"  # Should fix
    INFO = "INFO"  # Optional


class IssueStatus(Enum):
    """Issue resolution status."""

    PENDING = "pending"  # Not yet addressed
    FIXED = "fixed"  # Code was fixed
    JUSTIFIED = "justified"  # Explanation provided
    IGNORED = "ignored"  # Intentionally not fixing


@dataclass
class QualityIssue:
    """A single code quality issue."""

    source: str  # Tool that found it (pyright, ruff, eslint, etc.)
    rule_id: str  # Rule identifier (e.g., reportMissingImports)
    severity: IssueSeverity
    file_path: Path
    line: int
    column: int
    message: str
    suggestion: Optional[str] = None
    status: IssueStatus = IssueStatus.PENDING
    justification: Optional[str] = None  # Why this issue is acceptable

    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "source": self.source,
            "rule_id": self.rule_id,
            "severity": self.severity.value,
            "file_path": str(self.file_path),
            "line": self.line,
            "column": self.column,
            "message": self.message,
            "suggestion": self.suggestion,
            "status": self.status.value,
            "justification": self.justification,
        }

    @classmethod
    def from_dict(cls, data: Dict) -> "QualityIssue":
        """Create from dictionary."""
        return cls(
            source=data["source"],
            rule_id=data["rule_id"],
            severity=IssueSeverity(data["severity"]),
            file_path=Path(data["file_path"]),
            line=data["line"],
            column=data["column"],
            message=data["message"],
            suggestion=data.get("suggestion"),
            status=IssueStatus(data.get("status", "pending")),
            justification=data.get("justification"),
        )


@dataclass
class WorksheetBatch:
    """A batch of related issues to address together."""

    batch_id: int
    description: str
    issues: List[QualityIssue] = field(default_factory=list)

    def blocking_count(self) -> int:
        """Count blocking issues."""
        return sum(1 for issue in self.issues if issue.severity == IssueSeverity.BLOCK)

    def pending_count(self) -> int:
        """Count pending issues."""
        return sum(1 for issue in self.issues if issue.status == IssueStatus.PENDING)


@dataclass
class QualityWorksheet:
    """Complete quality worksheet for a project."""

    batches: List[WorksheetBatch] = field(default_factory=list)

    def total_issues(self) -> int:
        """Count total issues across all batches."""
        return sum(len(batch.issues) for batch in self.batches)

    def blocking_issues(self) -> int:
        """Count total blocking issues."""
        return sum(batch.blocking_count() for batch in self.batches)

    def pending_issues(self) -> int:
        """Count total pending issues."""
        return sum(batch.pending_count() for batch in self.batches)


class QualityChecker(ABC):
    """Base class for language-specific quality checkers."""

    @abstractmethod
    def check(self, files: List[Path], project_root: Path) -> List[QualityIssue]:
        """Run quality check on files.

        Args:
            files: Files to check
            project_root: Project root directory

        Returns:
            List of quality issues found

        """
        pass


class PyrightChecker(QualityChecker):
    """Python type checker using pyright."""

    def check(self, files: List[Path], project_root: Path) -> List[QualityIssue]:
        """Run pyright on Python files."""
        issues = []

        try:
            # Run pyright with JSON output
            result = subprocess.run(
                ["pyright", "--outputjson", "src/"],
                cwd=project_root,
                capture_output=True,
                text=True,
                timeout=120,
            )

            if result.stdout:
                data = json.loads(result.stdout)

                for diagnostic in data.get("generalDiagnostics", []):
                    file_path = Path(diagnostic["file"])

                    # Map pyright severity to our severity
                    severity_map = {
                        "error": IssueSeverity.BLOCK,
                        "warning": IssueSeverity.WARN,
                        "information": IssueSeverity.INFO,
                    }
                    severity = severity_map.get(
                        diagnostic.get("severity", "error"), IssueSeverity.BLOCK
                    )

                    issues.append(
                        QualityIssue(
                            source="pyright",
                            rule_id=diagnostic.get("rule", "unknown"),
                            severity=severity,
                            file_path=file_path,
                            line=diagnostic.get("range", {}).get("start", {}).get("line", 0) + 1,
                            column=diagnostic.get("range", {}).get("start", {}).get("character", 0),
                            message=diagnostic.get("message", ""),
                        )
                    )

        except (subprocess.TimeoutExpired, FileNotFoundError, json.JSONDecodeError):
            pass

        return issues


class RuffChecker(QualityChecker):
    """Python linter using ruff."""

    def check(self, files: List[Path], project_root: Path) -> List[QualityIssue]:
        """Run ruff on Python files."""
        issues = []

        try:
            # Run ruff with JSON output
            result = subprocess.run(
                ["ruff", "check", "--output-format=json", "src/", "tests/"],
                cwd=project_root,
                capture_output=True,
                text=True,
                timeout=60,
            )

            if result.stdout:
                data = json.loads(result.stdout)

                for diagnostic in data:
                    file_path = Path(diagnostic["filename"])

                    # Map ruff severity
                    severity = IssueSeverity.WARN  # Most ruff issues are warnings

                    # Handle fix suggestion safely (fix can be None)
                    fix_data = diagnostic.get("fix")
                    suggestion = fix_data.get("message") if fix_data else None

                    issues.append(
                        QualityIssue(
                            source="ruff",
                            rule_id=diagnostic.get("code", "unknown"),
                            severity=severity,
                            file_path=file_path,
                            line=diagnostic.get("location", {}).get("row", 0),
                            column=diagnostic.get("location", {}).get("column", 0),
                            message=diagnostic.get("message", ""),
                            suggestion=suggestion,
                        )
                    )

        except (subprocess.TimeoutExpired, FileNotFoundError, json.JSONDecodeError):
            pass

        return issues


class ValidateChecker(QualityChecker):
    """Maxwell's custom validation rules."""

    def check(self, files: List[Path], project_root: Path) -> List[QualityIssue]:
        """Run Maxwell's custom validators on Python files."""
        issues = []

        try:
            # Load Maxwell config
            config = load_config(project_root)

            # Run plugin validation with specific file list
            runner = run_plugin_validation(
                config=config, project_root=project_root, include_globs_override=files
            )

            # Convert findings to QualityIssue objects
            for finding in runner.findings:
                # Map validate severity to our severity
                severity_map = {
                    Severity.BLOCK: IssueSeverity.BLOCK,
                    Severity.WARN: IssueSeverity.WARN,
                    Severity.INFO: IssueSeverity.INFO,
                }
                severity = severity_map.get(finding.severity, IssueSeverity.WARN)

                issues.append(
                    QualityIssue(
                        source="validate",
                        rule_id=finding.rule_id or "unknown",
                        severity=severity,
                        file_path=project_root / finding.file_path,
                        line=finding.line or 0,
                        column=finding.column or 0,
                        message=finding.message,
                        suggestion=finding.suggestion,
                    )
                )

        except Exception:
            # If validate fails, just skip it (might not have config, etc.)
            pass

        return issues


class ESLintChecker(QualityChecker):
    """JavaScript/TypeScript linter using eslint."""

    def check(self, files: List[Path], project_root: Path) -> List[QualityIssue]:
        """Run eslint on JS/TS files."""
        issues = []

        try:
            # Check if eslint is available
            result = subprocess.run(
                ["npx", "eslint", "--version"],
                cwd=project_root,
                capture_output=True,
                timeout=5,
            )

            if result.returncode != 0:
                # eslint not available
                return issues

            # Run eslint with JSON output
            file_patterns = [str(f) for f in files if f.suffix in {".js", ".ts", ".tsx"}]

            if not file_patterns:
                return issues

            result = subprocess.run(
                ["npx", "eslint", "--format=json"] + file_patterns,
                cwd=project_root,
                capture_output=True,
                text=True,
                timeout=60,
            )

            if result.stdout:
                data = json.loads(result.stdout)

                for file_result in data:
                    file_path = Path(file_result["filePath"])

                    for message in file_result.get("messages", []):
                        # Map eslint severity
                        severity_map = {
                            2: IssueSeverity.BLOCK,  # error
                            1: IssueSeverity.WARN,  # warning
                            0: IssueSeverity.INFO,  # off
                        }
                        severity = severity_map.get(message.get("severity", 2), IssueSeverity.WARN)

                        issues.append(
                            QualityIssue(
                                source="eslint",
                                rule_id=message.get("ruleId", "unknown"),
                                severity=severity,
                                file_path=file_path,
                                line=message.get("line", 0),
                                column=message.get("column", 0),
                                message=message.get("message", ""),
                                suggestion=message.get("fix", {}).get("text"),
                            )
                        )

        except (subprocess.TimeoutExpired, FileNotFoundError, json.JSONDecodeError):
            pass

        return issues


class TSCChecker(QualityChecker):
    """TypeScript type checker using tsc."""

    def check(self, files: List[Path], project_root: Path) -> List[QualityIssue]:
        """Run tsc on TypeScript files."""
        issues = []

        try:
            # Check if tsc is available
            result = subprocess.run(
                ["npx", "tsc", "--version"],
                cwd=project_root,
                capture_output=True,
                timeout=5,
            )

            if result.returncode != 0:
                # tsc not available
                return issues

            # Run tsc with --noEmit to just check types
            result = subprocess.run(
                ["npx", "tsc", "--noEmit", "--pretty", "false"],
                cwd=project_root,
                capture_output=True,
                text=True,
                timeout=60,
            )

            if result.stdout:
                # Parse tsc output (format: file.ts(line,col): error TSxxxx: message)
                for line in result.stdout.split("\n"):
                    if ":" in line and "(" in line:
                        try:
                            parts = line.split(":")
                            file_part = parts[0]
                            error_part = ":".join(parts[1:])

                            # Extract file and position
                            if "(" in file_part:
                                file_path_str = file_part.split("(")[0]
                                pos = file_part.split("(")[1].split(")")[0]
                                line_num, col = map(int, pos.split(","))

                                file_path = Path(file_path_str)

                                # Extract error code and message
                                if "TS" in error_part:
                                    rule_id = "TS" + error_part.split("TS")[1].split(":")[0]
                                    message = ":".join(error_part.split(":")[2:]).strip()
                                else:
                                    rule_id = "tsc-error"
                                    message = error_part.strip()

                                issues.append(
                                    QualityIssue(
                                        source="tsc",
                                        rule_id=rule_id,
                                        severity=IssueSeverity.BLOCK,
                                        file_path=file_path,
                                        line=line_num,
                                        column=col,
                                        message=message,
                                    )
                                )
                        except (ValueError, IndexError):
                            continue

        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass

        return issues


class WorksheetManager:
    """Manages quality worksheets - loading, saving, and querying."""

    @staticmethod
    def load(worksheet_path: Path) -> QualityWorksheet:
        """Load worksheet from JSON file.

        Args:
            worksheet_path: Path to worksheet JSON file

        Returns:
            QualityWorksheet dataclass

        """
        if not worksheet_path.exists():
            return QualityWorksheet(batches=[])

        with open(worksheet_path) as f:
            data = json.load(f)

        batches = []
        for batch_data in data.get("batches", []):
            issues = [
                QualityIssue.from_dict(issue_data) for issue_data in batch_data.get("issues", [])
            ]
            batches.append(
                WorksheetBatch(
                    batch_id=batch_data["batch_id"],
                    description=batch_data["description"],
                    issues=issues,
                )
            )

        return QualityWorksheet(batches=batches)

    @staticmethod
    def save(worksheet: QualityWorksheet, output_path: Path) -> None:
        """Save worksheet to JSON file.

        Args:
            worksheet: QualityWorksheet dataclass
            output_path: Output file path

        """
        data = {
            "batches": [
                {
                    "batch_id": batch.batch_id,
                    "description": batch.description,
                    "issues": [issue.to_dict() for issue in batch.issues],
                }
                for batch in worksheet.batches
            ]
        }

        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w") as f:
            json.dump(data, f, indent=2)

        print(f"\n✓ Worksheet saved to {output_path}")


class QualityGateManager:
    """Manages quality checks across multiple languages."""

    def __init__(self, project_root: Path):
        """Initialize quality gate.

        Args:
            project_root: Project root directory

        """
        self.project_root = project_root
        self.checkers: Dict[str, List[QualityChecker]] = {
            "python": [PyrightChecker(), RuffChecker(), ValidateChecker()],
            "javascript": [ESLintChecker()],
            "typescript": [ESLintChecker(), TSCChecker()],
        }

    def run_checks(self, files_by_language: Dict[str, List[Path]]) -> List[QualityIssue]:
        """Run quality checks for all languages.

        Args:
            files_by_language: Map of language to list of files

        Returns:
            All quality issues found

        """
        all_issues = []

        for language, files in files_by_language.items():
            if language not in self.checkers:
                continue

            print(f"\nRunning quality checks for {language}...")
            for checker in self.checkers[language]:
                checker_name = checker.__class__.__name__
                print(f"  {checker_name}...")

                issues = checker.check(files, self.project_root)
                all_issues.extend(issues)

                print(f"    Found {len(issues)} issues")

        return all_issues

    def create_worksheet(self, issues: List[QualityIssue]) -> QualityWorksheet:
        """Create quality worksheet from issues.

        Args:
            issues: All quality issues

        Returns:
            QualityWorksheet dataclass

        """
        # Group by file and severity
        file_groups: Dict[Path, List[QualityIssue]] = {}

        for issue in issues:
            if issue.file_path not in file_groups:
                file_groups[issue.file_path] = []
            file_groups[issue.file_path].append(issue)

        # Create batches - one per file with issues (BLOCK or WARN)
        batches = []
        batch_id = 1

        for file_path, file_issues in sorted(file_groups.items()):
            blocking = [i for i in file_issues if i.severity == IssueSeverity.BLOCK]
            warnings = [i for i in file_issues if i.severity == IssueSeverity.WARN]

            # Create batch if there are blocking or warning issues
            if blocking or warnings:
                if blocking:
                    description = f"Fix {len(blocking)} blocking issue(s) in {file_path.name}"
                else:
                    description = f"Address {len(warnings)} warning(s) in {file_path.name}"

                batches.append(
                    WorksheetBatch(
                        batch_id=batch_id,
                        description=description,
                        issues=file_issues,
                    )
                )
                batch_id += 1

        return QualityWorksheet(batches=batches)

    def quality_gate_passed(self, issues: List[QualityIssue]) -> bool:
        """Check if quality gate passed.

        Args:
            issues: All quality issues

        Returns:
            True if all blocking issues are fixed or justified

        """
        for issue in issues:
            if issue.severity == IssueSeverity.BLOCK and issue.status == IssueStatus.PENDING:
                return False

        return True
