"""JavaScript/TypeScript code spec extractor using regex patterns."""

import re
from pathlib import Path
from typing import List

from ..specs import ClassSpec, FunctionSpec, ParamSpec


class JavaScriptSpecExtractor:
    """Extract function and class specs from JavaScript/TypeScript code."""

    # Regex patterns for different function declarations
    FUNCTION_PATTERNS = [
        # function name(...) or async function name(...)
        r"(?P<async>async\s+)?function\s+(?P<name>\w+)\s*\((?P<params>[^)]*)\)(?:\s*:\s*(?P<return_type>[^{]+))?",
        # const/let/var name = (...) => or async (...) =>
        r"(?P<const>const|let|var)\s+(?P<name>\w+)\s*=\s*(?P<async2>async\s*)?\((?P<params>[^)]*)\)(?:\s*:\s*(?P<return_type>[^=]+))?\s*=>",
        # name: (...) => (in object literals)
        r"(?P<name>\w+)\s*:\s*(?P<async3>async\s*)?\((?P<params>[^)]*)\)(?:\s*:\s*(?P<return_type>[^=]+))?\s*=>",
    ]

    CLASS_PATTERN = r"class\s+(?P<name>\w+)(?:\s+extends\s+(?P<parent>\w+))?\s*\{"

    def __init__(self, file_path: Path):
        """Initialize extractor.

        Args:
            file_path: Path to JS/TS file being analyzed

        """
        self.file_path = file_path
        self.functions: List[FunctionSpec] = []
        self.classes: List[ClassSpec] = []

    def extract(self) -> tuple[List[FunctionSpec], List[ClassSpec]]:
        """Extract specs from the file.

        Returns:
            Tuple of (functions, classes)

        """
        try:
            source_code = self.file_path.read_text()

            # Determine language
            language = "typescript" if self.file_path.suffix in [".ts", ".tsx"] else "javascript"

            # Extract JSDoc comments (map position to comment)
            jsdoc_map = self._extract_jsdoc(source_code)

            # Extract functions
            self._extract_functions(source_code, jsdoc_map, language)

            # Extract classes
            self._extract_classes(source_code, jsdoc_map, language)

            return self.functions, self.classes

        except Exception as e:
            print(f"Error extracting from {self.file_path}: {e}")
            return [], []

    def _extract_jsdoc(self, source: str) -> dict:
        """Extract JSDoc comments and map them to line numbers.

        Args:
            source: Source code

        Returns:
            Map of line number to JSDoc content

        """
        jsdoc_pattern = r"/\*\*(.*?)\*/"
        jsdoc_map = {}

        for match in re.finditer(jsdoc_pattern, source, re.DOTALL):
            # Get line number where JSDoc starts
            line_num = source[: match.start()].count("\n")
            jsdoc_content = match.group(1)

            # Clean up JSDoc
            lines = []
            for line in jsdoc_content.split("\n"):
                cleaned = line.strip().lstrip("*").strip()
                if cleaned:
                    lines.append(cleaned)

            jsdoc_map[line_num] = "\n".join(lines)

        return jsdoc_map

    def _extract_functions(self, source: str, jsdoc_map: dict, language: str):
        """Extract function specs from source code."""
        lines = source.split("\n")

        for line_num, line in enumerate(lines):
            for pattern in self.FUNCTION_PATTERNS:
                match = re.search(pattern, line)
                if match:
                    name = match.group("name")
                    if not name:
                        continue

                    # Extract parameters
                    params_str = match.group("params") or ""
                    params = self._parse_params(params_str, language)

                    # Extract return type
                    return_type = None
                    if "return_type" in match.groupdict():
                        return_type = match.group("return_type")
                        if return_type:
                            return_type = return_type.strip()

                    # Get JSDoc if present
                    jsdoc = jsdoc_map.get(line_num - 1, "") or jsdoc_map.get(line_num - 2, "")
                    docstring, params = self._parse_jsdoc(jsdoc, params)

                    # Extract return type from JSDoc if not in signature
                    if not return_type and "@returns" in jsdoc:
                        return_match = re.search(r"@returns?\s+\{([^}]+)\}", jsdoc)
                        if return_match:
                            return_type = return_match.group(1)

                    func_spec = FunctionSpec(
                        name=name,
                        params=params,
                        return_type=return_type,
                        docstring=docstring,
                        file=self.file_path,
                        language=language,
                        start_line=line_num + 1,
                    )

                    self.functions.append(func_spec)
                    break

    def _extract_classes(self, source: str, jsdoc_map: dict, language: str):
        """Extract class specs from source code."""
        for match in re.finditer(self.CLASS_PATTERN, source):
            name = match.group("name")
            parent = match.group("parent")

            # Get line number
            line_num = source[: match.start()].count("\n")

            # Get JSDoc
            jsdoc = jsdoc_map.get(line_num - 1, "")
            docstring, _ = self._parse_jsdoc(jsdoc, [])

            class_spec = ClassSpec(
                name=name,
                inherits_from=[parent] if parent else [],
                docstring=docstring,
                file=self.file_path,
                language=language,
                start_line=line_num + 1,
            )

            self.classes.append(class_spec)

    def _parse_params(self, params_str: str, language: str) -> List[ParamSpec]:
        """Parse parameter string into ParamSpecs.

        Args:
            params_str: Parameter string like "a: number, b: string"
            language: "javascript" or "typescript"

        Returns:
            List of parameter specs

        """
        params = []

        if not params_str.strip():
            return params

        # Split by comma (simple approach, doesn't handle nested types)
        param_parts = params_str.split(",")

        for part in param_parts:
            part = part.strip()
            if not part:
                continue

            # Handle "name: type" or just "name"
            if ":" in part:
                name, type_part = part.split(":", 1)
                name = name.strip()
                param_type = type_part.strip()
            else:
                name = part.strip()
                param_type = None

            params.append(ParamSpec(name=name, type=param_type))

        return params

    def _parse_jsdoc(self, jsdoc: str, params: List[ParamSpec]) -> tuple[str, List[ParamSpec]]:
        """Parse JSDoc comment.

        Extracts description and enriches parameters with @param annotations.

        Args:
            jsdoc: JSDoc comment text
            params: Existing parameter specs to enrich

        Returns:
            Tuple of (description, enriched_params)

        """
        if not jsdoc:
            return "", params

        # Extract description (everything before first @tag)
        desc_match = re.match(r"^(.*?)(?=@|\Z)", jsdoc, re.DOTALL)
        description = desc_match.group(1).strip() if desc_match else ""

        # Extract @param tags
        param_pattern = r"@param\s+(?:\{([^}]+)\}\s+)?(\w+)(?:\s+-\s+(.+))?"
        param_map = {}

        for match in re.finditer(param_pattern, jsdoc):
            param_type = match.group(1)
            param_name = match.group(2)
            param_desc = match.group(3) or ""

            param_map[param_name] = {
                "type": param_type,
                "description": param_desc.strip(),
            }

        # Enrich params
        for param in params:
            if param.name in param_map:
                info = param_map[param.name]
                if not param.type and info["type"]:
                    param.type = info["type"]
                param.description = info["description"]

        return description, params

    @classmethod
    def extract_from_file(cls, file_path: Path) -> tuple[List[FunctionSpec], List[ClassSpec]]:
        """Extract specs from a JavaScript/TypeScript file.

        Args:
            file_path: Path to JS/TS file

        Returns:
            Tuple of (functions, classes)

        """
        extractor = cls(file_path)
        return extractor.extract()
