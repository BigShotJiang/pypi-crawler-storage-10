"""Python code spec extractor using libcst."""

from pathlib import Path
from typing import List, Optional

import libcst as cst

from ..specs import ClassSpec, FunctionSpec, ParamSpec


class PythonSpecExtractor(cst.CSTVisitor):
    """Extract function and class specs from Python code using libcst."""

    def __init__(self, file_path: Path):
        """Initialize extractor.

        Args:
            file_path: Path to Python file being analyzed

        """
        self.file_path = file_path
        self.functions: List[FunctionSpec] = []
        self.classes: List[ClassSpec] = []
        self.current_class: Optional[str] = None
        super().__init__()

    def visit_ClassDef(self, node: cst.ClassDef) -> None:
        """Visit class definition."""
        self.current_class = node.name.value

        # Extract docstring
        docstring = self._extract_docstring(node.body)

        # Extract parent classes
        inherits_from = []
        if node.bases:
            for base in node.bases:
                if isinstance(base.value, cst.Name):
                    inherits_from.append(base.value.value)

        # Create class spec (methods will be added as we visit them)
        class_spec = ClassSpec(
            name=node.name.value,
            inherits_from=inherits_from,
            docstring=docstring,
            file=self.file_path,
            language="python",
            start_line=(
                node.body.body[0].leading_lines[0].comment.value
                if node.body.body and node.body.body[0].leading_lines
                else 0
            ),
        )

        self.classes.append(class_spec)

    def leave_ClassDef(self, node: cst.ClassDef) -> None:
        """Leave class definition."""
        self.current_class = None

    def visit_FunctionDef(self, node: cst.FunctionDef) -> None:
        """Visit function/method definition."""
        # Extract parameters
        params = []
        if node.params:
            for param in node.params.params:
                param_name = param.name.value
                param_type = None
                if param.annotation:
                    param_type = cst.Module([param.annotation.annotation]).code.strip()

                params.append(ParamSpec(name=param_name, type=param_type))

        # Extract return type
        return_type = None
        if node.returns:
            return_type = cst.Module([node.returns.annotation]).code.strip()

        # Extract docstring
        docstring = self._extract_docstring(node.body)

        # Parse docstring for parameter descriptions
        params = self._enrich_params_from_docstring(params, docstring)

        # Create function spec
        func_spec = FunctionSpec(
            name=node.name.value,
            params=params,
            return_type=return_type,
            docstring=docstring,
            file=self.file_path,
            language="python",
            parent_class=self.current_class,
        )

        self.functions.append(func_spec)

        # Add method to current class if we're inside one
        if self.current_class:
            for class_spec in self.classes:
                if class_spec.name == self.current_class:
                    class_spec.methods.append(func_spec)
                    break

    def _extract_docstring(self, body: cst.BaseSuite) -> str:
        """Extract docstring from function or class body."""
        if not isinstance(body, cst.IndentedBlock):
            return ""

        if not body.body:
            return ""

        first_stmt = body.body[0]

        # Check if first statement is a docstring
        if isinstance(first_stmt, cst.SimpleStatementLine):
            if first_stmt.body and isinstance(first_stmt.body[0], cst.Expr):
                expr = first_stmt.body[0]
                if isinstance(expr.value, (cst.SimpleString, cst.ConcatenatedString)):
                    docstring = expr.value
                    # Extract string value
                    if isinstance(docstring, cst.SimpleString):
                        value = docstring.value
                        # Remove quotes
                        if value.startswith('"""') or value.startswith("'''"):
                            value = value[3:-3]
                        elif value.startswith('"') or value.startswith("'"):
                            value = value[1:-1]
                        return value.strip()

        return ""

    def _enrich_params_from_docstring(
        self, params: List[ParamSpec], docstring: str
    ) -> List[ParamSpec]:
        """Extract parameter descriptions from docstring (Google/NumPy style).

        Args:
            params: List of parameters to enrich
            docstring: Docstring to parse

        Returns:
            Enriched parameters with descriptions

        """
        if not docstring:
            return params

        # Simple parser for "Args:" section
        lines = docstring.split("\n")
        in_args = False
        param_map = {}

        for line in lines:
            stripped = line.strip()

            if stripped.startswith("Args:") or stripped.startswith("Parameters:"):
                in_args = True
                continue

            if in_args:
                # Check if we've left the Args section
                if stripped.endswith(":") and not stripped.startswith(" "):
                    break

                # Parse "param_name: description" or "param_name (type): description"
                if ":" in stripped:
                    parts = stripped.split(":", 1)
                    param_part = parts[0].strip()

                    # Handle "(type)" annotation
                    if "(" in param_part:
                        param_name = param_part.split("(")[0].strip()
                    else:
                        param_name = param_part

                    description = parts[1].strip() if len(parts) > 1 else ""
                    param_map[param_name] = description

        # Enrich params with descriptions
        for param in params:
            if param.name in param_map:
                param.description = param_map[param.name]

        return params

    @classmethod
    def extract_from_file(cls, file_path: Path) -> tuple[List[FunctionSpec], List[ClassSpec]]:
        """Extract specs from a Python file.

        Args:
            file_path: Path to Python file

        Returns:
            Tuple of (functions, classes)

        """
        try:
            source_code = file_path.read_text()
            tree = cst.parse_module(source_code)

            extractor = cls(file_path)
            tree.visit(extractor)

            return extractor.functions, extractor.classes

        except Exception as e:
            print(f"Error extracting from {file_path}: {e}")
            return [], []
