"""Code spec extractors for different languages."""

from .javascript_extractor import JavaScriptSpecExtractor
from .python_extractor import PythonSpecExtractor

__all__ = ["PythonSpecExtractor", "JavaScriptSpecExtractor"]
