"""DRY optimization engine using graph analysis and LLM reasoning.

Uses ReAct-like workflow:
1. Analyze duplicate cliques in code graph
2. For each clique, LLM decides refactoring strategy
3. Generate safe deletion order
4. Apply transformations
"""

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Dict, List, Set

from maxwell.lm_pool import get_lm

from .graph_builder import CodeGraph
from .specs import FunctionSpec


class RefactorStrategy(Enum):
    """Refactoring strategy for duplicate code."""

    MERGE = "merge"  # Merge duplicates into single function
    PARENT = "parent"  # Extract to parent class/module
    DELETE = "delete"  # Delete duplicate, keep best one
    KEEP = "keep"  # Keep all (false positive)


@dataclass
class RefactorAction:
    """Action to refactor code."""

    strategy: RefactorStrategy
    clique: Set[str]  # Function IDs in the clique
    keep_func: str | None = None  # Which function to keep (for DELETE)
    delete_funcs: List[str] | None = None  # Functions to delete (in order)
    reasoning: str = ""  # LLM reasoning for this action


class DRYOptimizer:
    """Optimize code for DRY principle using graph analysis and LLM."""

    def __init__(self, graph: CodeGraph, llm_config: Dict | None = None):
        """Initialize optimizer.

        Args:
            graph: Code graph with call and similarity edges
            llm_config: LLM configuration (uses defaults if None)

        """
        self.graph = graph
        self.llm = get_lm(llm_config or {})
        self.actions: List[RefactorAction] = []

    def analyze_duplicates(self) -> List[RefactorAction]:
        """Analyze duplicate cliques and generate refactoring actions.

        Returns:
            List of refactoring actions

        """
        # Find duplicate cliques
        cliques = self.graph.find_duplicate_cliques()

        print(f"Found {len(cliques)} duplicate cliques to analyze...")

        # Compute PageRank for importance ranking
        pagerank = self.graph.compute_pagerank()

        # Analyze each clique
        for i, clique in enumerate(cliques, 1):
            try:
                print(f"\nAnalyzing clique {i}/{len(cliques)} ({len(clique)} functions)...")

                # Debug: Show what functions are in this clique
                func_names = [self.graph.functions[fid].name for fid in list(clique)[:3]]
                print(f"  Functions in clique: {', '.join(func_names)}...")

                action = self._analyze_clique(clique, pagerank)
                self.actions.append(action)

                print(f"  Strategy: {action.strategy.value}")
                if action.keep_func:
                    func = self.graph.functions[action.keep_func]
                    print(f"  Keep: {func.name} ({func.file.name})")

            except Exception as e:
                print(f"  ERROR analyzing clique {i}: {type(e).__name__}: {e}")
                import traceback
                traceback.print_exc()
                # Create a KEEP action as fallback
                action = RefactorAction(
                    strategy=RefactorStrategy.KEEP,
                    clique=clique,
                    reasoning=f"Failed to analyze: {e}",
                )
                self.actions.append(action)

        return self.actions

    def _analyze_clique(self, clique: Set[str], pagerank: Dict[str, float]) -> RefactorAction:
        """Analyze a single clique and decide refactoring strategy.

        Args:
            clique: Set of function IDs that are similar
            pagerank: PageRank scores for functions

        Returns:
            Refactoring action

        """
        # Get function specs
        funcs = [self.graph.functions[func_id] for func_id in clique]

        # Sort by PageRank (most important first)
        funcs_ranked = sorted(funcs, key=lambda f: pagerank.get(f.full_id(), 0.0), reverse=True)

        # Build context for LLM
        context = self._build_clique_context(funcs_ranked, pagerank)

        # Ask LLM for strategy
        strategy, reasoning = self._ask_llm_for_strategy(context)

        # Determine what to keep and what to delete
        if strategy == RefactorStrategy.DELETE:
            # Keep the most important function
            keep_func = funcs_ranked[0].full_id()
            delete_funcs = [f.full_id() for f in funcs_ranked[1:]]

            # Get safe deletion order
            delete_order = self.graph.get_deletion_order(set(delete_funcs))

            return RefactorAction(
                strategy=strategy,
                clique=clique,
                keep_func=keep_func,
                delete_funcs=delete_order,
                reasoning=reasoning,
            )

        # For MERGE, PARENT, KEEP - just record the decision
        return RefactorAction(strategy=strategy, clique=clique, reasoning=reasoning)

    def _build_clique_context(self, funcs: List[FunctionSpec], pagerank: Dict[str, float]) -> str:
        """Build context string for LLM analysis.

        Args:
            funcs: Functions in the clique (sorted by importance)
            pagerank: PageRank scores

        Returns:
            Context string

        """
        lines = ["## Duplicate Function Clique\n"]

        for i, func in enumerate(funcs, 1):
            rank = pagerank.get(func.full_id(), 0.0)
            deps = self.graph.get_function_dependencies(func.full_id())

            lines.append(f"### Function {i} (PageRank: {rank:.4f})")
            lines.append(f"**Location**: {func.file}:{func.start_line}")
            lines.append(f"**Signature**: `{func.signature()}`")
            lines.append(f"**Language**: {func.language}")

            if func.docstring:
                lines.append(f"**Docstring**: {func.docstring[:200]}")

            if func.implementation_summary:
                lines.append(f"**Implementation**: {func.implementation_summary}")

            if deps:
                lines.append(f"**Called by**: {len(deps)} functions")

            if func.calls:
                lines.append(f"**Calls**: {', '.join(func.calls[:5])}")

            lines.append("")

        return "\n".join(lines)

    def _ask_llm_for_strategy(self, context: str) -> tuple[RefactorStrategy, str]:
        """Ask LLM to decide refactoring strategy.

        Args:
            context: Context about the duplicate clique

        Returns:
            Tuple of (strategy, reasoning)

        """
        prompt = f"""You are a code refactoring expert analyzing duplicate code.

{context}

## Task
Analyze these similar functions and decide the best refactoring strategy:

1. **DELETE**: One function is clearly the best version. Delete the others and update callers.
   - Use when functions are truly duplicates with minor differences
   - Prefer keeping the one with best documentation, most calls, or clearest implementation

2. **MERGE**: Functions should be merged into a single parameterized version
   - Use when functions have similar logic but different parameters/configs
   - Creates a more general function

3. **PARENT**: Extract common logic to parent class or shared module
   - Use when functions share logic but belong in different classes
   - Good for inheritance hierarchies

4. **KEEP**: Keep all functions (false positive)
   - Use when functions look similar but serve different purposes
   - Different business logic or different contexts

## Response Format
Provide your analysis in this EXACT format:

STRATEGY: [DELETE|MERGE|PARENT|KEEP]

REASONING:
[Your detailed reasoning for this decision, considering:
- Similarity of implementation
- Quality of documentation
- Number of callers (PageRank)
- Context and purpose
- Risk of breaking changes]
"""

        response = self.llm.generate(prompt, max_tokens=500, temperature=0.3)

        # Parse response
        lines = response.strip().split("\n")

        strategy_line = next((l for l in lines if l.startswith("STRATEGY:")), None)
        if not strategy_line:
            # Default to KEEP if we can't parse
            return RefactorStrategy.KEEP, "Could not parse LLM response"

        strategy_str = strategy_line.split(":", 1)[1].strip().upper()

        try:
            strategy = RefactorStrategy[strategy_str]
        except KeyError:
            strategy = RefactorStrategy.KEEP

        # Extract reasoning
        reasoning_idx = next((i for i, l in enumerate(lines) if l.startswith("REASONING:")), None)
        if reasoning_idx is not None:
            reasoning = "\n".join(lines[reasoning_idx + 1 :]).strip()
        else:
            reasoning = ""

        return strategy, reasoning

    def get_deletion_plan(self) -> List[tuple[Path, int, int]]:
        """Get plan of files and line ranges to delete.

        Returns:
            List of (file_path, start_line, end_line) tuples

        """
        deletions = []

        for action in self.actions:
            if action.strategy != RefactorStrategy.DELETE:
                continue

            if not action.delete_funcs:
                continue

            # Get deletion ranges
            for func_id in action.delete_funcs:
                func = self.graph.functions[func_id]
                if func.file and func.start_line > 0:
                    # For now, just mark start line (end line would need AST)
                    deletions.append((func.file, func.start_line, func.start_line))

        return deletions

    def export_report(self, output_path: Path):
        """Export refactoring analysis report.

        Args:
            output_path: Path to write markdown report

        """
        lines = ["# DRY Optimization Report\n"]

        stats = self.graph.stats()
        lines.append(f"**Functions analyzed**: {stats.functions}")
        lines.append(f"**Classes analyzed**: {stats.classes}")
        lines.append(f"**Duplicate cliques found**: {len(self.actions)}\n")

        # Summary by strategy
        strategy_counts: Dict[RefactorStrategy, int] = {}
        for action in self.actions:
            strategy_counts[action.strategy] = strategy_counts.get(action.strategy, 0) + 1

        lines.append("## Refactoring Strategies\n")
        for strategy, count in strategy_counts.items():
            lines.append(f"- **{strategy.value.upper()}**: {count}")

        lines.append("\n## Detailed Analysis\n")

        for i, action in enumerate(self.actions, 1):
            lines.append(f"### Clique {i}: {action.strategy.value.upper()}\n")

            # List functions
            lines.append("**Functions:**")
            for func_id in list(action.clique)[:5]:
                func = self.graph.functions[func_id]
                lines.append(f"- `{func.name}` ({func.file.name}:{func.start_line})")

            if action.keep_func:
                func = self.graph.functions[action.keep_func]
                lines.append(f"\n**Keep**: `{func.name}` ({func.file.name})")

            if action.delete_funcs:
                lines.append(f"\n**Delete**: {len(action.delete_funcs)} functions")

            lines.append(f"\n**Reasoning**: {action.reasoning}\n")

        output_path.write_text("\n".join(lines))
        print(f"\nReport written to {output_path}")
