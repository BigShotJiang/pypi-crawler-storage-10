"""Maxwell inference workflows.

Implements FlashBack-style research-augmented generation:
- Research-augmented chain-of-thought (ResearchAugmentedGenerator)
- Pauses thinking, runs research, injects knowledge

This is business logic - model infrastructure (MaxwellModel) lives in core.
"""

# Re-export model infrastructure from core (for convenience)
from maxwell.models import MaxwellModel

# Import inference business logic from this workflow
from maxwell.workflows.inference.flashback import ResearchAugmentedGenerator

__all__ = ["MaxwellModel", "ResearchAugmentedGenerator"]
