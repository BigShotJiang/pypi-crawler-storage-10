"""FlashBack: Research-Augmented Chain-of-Thought Inference Workflow.

This workflow implements research-augmented CoT generation:
- Model generates thinking process
- Pauses at </thinking> tag
- Maxwell runs deep_research workflow to resolve doubts
- Injects knowledge back into CoT
- Model continues with enriched context

Business logic workflow that uses core infrastructure:
- Uses MaxwellModel from maxwell.models (core infrastructure)
- Uses deep_research workflow via registry (mediator pattern)
- Uses get_lm from lm_pool (core infrastructure)

Example:
    from maxwell.workflows.inference.flashback import ResearchAugmentedGenerator
    from maxwell.models import MaxwellModel
    from transformers import AutoTokenizer

    model = MaxwellModel.from_pretrained("Qwen/Qwen3-VL-4B-Thinking")
    tokenizer = AutoTokenizer.from_pretrained("Qwen/Qwen3-VL-4B-Thinking")

    generator = ResearchAugmentedGenerator(
        model=model,
        tokenizer=tokenizer,
        thinking_stop_tag="</thinking>",
        research_llm="gpt-4o"
    )

    result = generator.generate("Explain quantum entanglement")
    print(result["text"])

"""

__all__ = ["ResearchAugmentedGenerator"]

import logging
import re
from typing import Any, Dict, Optional

from transformers import AutoTokenizer

# Import local model infrastructure from core
from maxwell.models import MaxwellModel

logger = logging.getLogger(__name__)


class ResearchAugmentedGenerator:
    """Generate with research-augmented chain-of-thought.

    Pauses generation when model emits thinking stop tag, runs Maxwell research
    to resolve model's doubts/uncertainties, injects knowledge, then resumes.

    This implements externally-augmented CoT:
    - Model starts thinking → identifies gaps in knowledge
    - Pauses at </thinking>
    - Maxwell researches the gaps (deep_research workflow)
    - Network LLM synthesizes findings
    - Knowledge injected into CoT
    - Model continues with enriched context

    Example:
        from maxwell.maxwell_backend import MaxwellModel, ResearchAugmentedGenerator
        from transformers import AutoTokenizer

        model = MaxwellModel.from_pretrained("Qwen/Qwen3-VL-4B-Thinking")
        tokenizer = AutoTokenizer.from_pretrained("Qwen/Qwen3-VL-4B-Thinking")

        generator = ResearchAugmentedGenerator(
            model=model,
            tokenizer=tokenizer,
            thinking_stop_tag="</thinking>",
            research_llm="gpt-4o"
        )

        result = generator.generate(
            prompt="Explain recent quantum entanglement experiments",
            max_new_tokens=512
        )

        print(result["final_text"])
        print(f"Research pauses: {result['research_count']}")
        print(f"Knowledge injected: {result['knowledge_injected']}")

    """

    def __init__(
        self,
        model: MaxwellModel,
        tokenizer: AutoTokenizer,
        thinking_stop_tag: str = "</thinking>",
        research_llm: Optional[str] = None,
        max_research_iterations: int = 3,
    ):
        """Initialize research-augmented generator.

        Args:
            model: MaxwellModel instance
            tokenizer: Compatible tokenizer
            thinking_stop_tag: Tag that triggers research (default: "</thinking>")
            research_llm: Network LLM for research synthesis (default: fastest available)
            max_research_iterations: Max times to pause for research per generation

        """
        self.model = model
        self.tokenizer = tokenizer
        self.thinking_stop_tag = thinking_stop_tag
        self.research_llm = research_llm
        self.max_research_iterations = max_research_iterations

        logger.info(
            f"Research-augmented generator initialized "
            f"(stop_tag='{thinking_stop_tag}', llm={research_llm})"
        )

    def generate(
        self,
        prompt: str,
        max_new_tokens: int = 512,
        temperature: float = 0.7,
        **kwargs,
    ) -> Dict[str, Any]:
        """Generate with research-augmented thinking.

        Args:
            prompt: Input prompt
            max_new_tokens: Maximum new tokens to generate
            temperature: Sampling temperature
            **kwargs: Additional generation parameters

        Returns:
            Dict with:
                - final_text: Complete generated text
                - research_count: Number of research pauses
                - knowledge_injected: List of injected knowledge snippets
                - thinking_segments: List of thinking segments before each pause
                - generation_log: Detailed log of the process

        """
        logger.info(f"Starting research-augmented generation (max_tokens={max_new_tokens})")

        # Track the generation process
        generation_log = []
        knowledge_injected = []
        thinking_segments = []
        research_count = 0

        # Start generation
        current_prompt = prompt
        generated_so_far = ""
        tokens_used = 0

        for iteration in range(self.max_research_iterations):
            logger.info(f"Research iteration {iteration + 1}/{self.max_research_iterations}")

            # Generate until thinking stop tag or max tokens
            inputs = self.tokenizer(current_prompt + generated_so_far, return_tensors="pt")
            inputs = {k: v.to(self.model.model.device) for k, v in inputs.items()}

            # Stream generation token by token to detect stop tag
            partial_output = ""
            tokens_this_iteration = 0

            with torch.no_grad():
                past_key_values = None

                for step in range(max_new_tokens - tokens_used):
                    # Forward pass
                    if past_key_values is None:
                        outputs = self.model(**inputs, use_cache=True)
                    else:
                        # Only pass last token for subsequent steps
                        last_token = inputs["input_ids"][:, -1:]
                        outputs = self.model(
                            input_ids=last_token, past_key_values=past_key_values, use_cache=True
                        )

                    logits = outputs.logits[:, -1, :]
                    past_key_values = outputs.past_key_values

                    # Sample next token
                    probs = torch.softmax(logits / temperature, dim=-1)
                    next_token = torch.multinomial(probs, num_samples=1)

                    # Decode and check for stop tag
                    next_text = self.tokenizer.decode(next_token[0], skip_special_tokens=False)
                    partial_output += next_text

                    # Update inputs for next iteration
                    inputs["input_ids"] = torch.cat([inputs["input_ids"], next_token], dim=-1)

                    tokens_this_iteration += 1
                    tokens_used += 1

                    # Check if we've hit the thinking stop tag
                    if self.thinking_stop_tag in partial_output:
                        logger.info(f"Detected thinking stop tag at step {step}")
                        break

                    # Check for EOS
                    if next_token.item() == self.tokenizer.eos_token_id:
                        logger.info("EOS token detected, ending generation")
                        generated_so_far += partial_output
                        generation_log.append(
                            {
                                "iteration": iteration,
                                "type": "generation_complete",
                                "text": partial_output,
                            }
                        )
                        # No research needed, generation complete
                        return {
                            "final_text": generated_so_far,
                            "research_count": research_count,
                            "knowledge_injected": knowledge_injected,
                            "thinking_segments": thinking_segments,
                            "generation_log": generation_log,
                        }

            # We've generated text, check if we hit the stop tag
            if self.thinking_stop_tag not in partial_output:
                # Didn't hit stop tag, just continue or end
                generated_so_far += partial_output
                generation_log.append(
                    {
                        "iteration": iteration,
                        "type": "generation_no_stop_tag",
                        "text": partial_output,
                    }
                )

                if tokens_used >= max_new_tokens:
                    logger.info("Max tokens reached")
                    break
                else:
                    continue

            # Extract thinking content (before stop tag)
            thinking_match = re.search(
                r"<thinking>(.*?)" + re.escape(self.thinking_stop_tag), partial_output, re.DOTALL
            )

            if thinking_match:
                thinking_content = thinking_match.group(1).strip()
                thinking_segments.append(thinking_content)
                logger.info(f"Extracted thinking content ({len(thinking_content)} chars)")

                generation_log.append(
                    {
                        "iteration": iteration,
                        "type": "thinking_detected",
                        "thinking": thinking_content,
                    }
                )

                # Run Maxwell research to resolve doubts
                logger.info("Running Maxwell deep research to resolve doubts...")
                knowledge = self._run_research(thinking_content)

                if knowledge:
                    knowledge_injected.append(knowledge)
                    research_count += 1

                    generation_log.append(
                        {
                            "iteration": iteration,
                            "type": "research_complete",
                            "knowledge": knowledge,
                        }
                    )

                    # Inject knowledge into the CoT
                    knowledge_injection = (
                        f"\n\n<research_findings>\n{knowledge}\n</research_findings>\n\n"
                    )
                    partial_output = partial_output.replace(
                        self.thinking_stop_tag, knowledge_injection + self.thinking_stop_tag
                    )

                    logger.info(f"Injected {len(knowledge)} chars of knowledge into CoT")

            # Update generated text
            generated_so_far += partial_output

            # Check if we've used all tokens
            if tokens_used >= max_new_tokens:
                logger.info("Max tokens reached after research")
                break

        return {
            "final_text": generated_so_far,
            "research_count": research_count,
            "knowledge_injected": knowledge_injected,
            "thinking_segments": thinking_segments,
            "generation_log": generation_log,
        }

    def _run_research(self, thinking_content: str) -> str:
        """Run Maxwell deep research based on thinking content.

        Args:
            thinking_content: Model's thinking text containing doubts/questions

        Returns:
            Synthesized research findings

        """
        try:
            # Import from core infrastructure
            from maxwell.api import execute_workflow
            from maxwell.lm_pool import get_lm

            # Extract key questions/doubts from thinking
            research_query = self._extract_research_query(thinking_content)

            if not research_query:
                logger.warning("Could not extract research query from thinking")
                return ""

            logger.info(f"Research query: {research_query}")

            # Execute deep_research workflow via registry (mediator pattern)
            research_result = execute_workflow(
                workflow_id="deep_research",
                research_question=research_query,
                data_sources="chat,web",
                max_iterations=2,
                queries_per_iteration=3,
                results_per_query=5,
                synthesis_style="concise",
            )

            # Extract report from workflow result
            research_results = {"report": research_result.artifacts.get("report", "")}

            # Get network LLM for synthesis
            if self.research_llm:
                llm = get_lm(self.research_llm)
            else:
                llm = get_lm()  # Use fastest available

            # Synthesize findings
            synthesis_prompt = f"""Based on the research findings below, provide a concise summary (2-3 sentences) that directly addresses the model's uncertainty:

Model's thinking:
{thinking_content[:500]}

Research findings:
{research_results.get('report', '')[:2000]}

Concise answer:"""

            synthesis = llm.generate(synthesis_prompt, max_tokens=200, temperature=0.3)

            return synthesis

        except Exception as e:
            logger.error(f"Research failed: {e}")
            return ""

    def _extract_research_query(self, thinking_content: str) -> str:
        """Extract research query from model's thinking.

        Looks for questions, uncertainties, or gaps in knowledge.

        Args:
            thinking_content: Model's thinking text

        Returns:
            Research query string

        """
        # Look for explicit questions
        questions = re.findall(r"([^.!?]*\?)", thinking_content)

        if questions:
            # Use first question as research query
            return questions[0].strip()

        # Look for uncertainty markers
        uncertainty_patterns = [
            r"I'm not sure (about|if|whether) ([^.]+)",
            r"I don't know ([^.]+)",
            r"unclear ([^.]+)",
            r"need to verify ([^.]+)",
            r"uncertain ([^.]+)",
        ]

        for pattern in uncertainty_patterns:
            match = re.search(pattern, thinking_content, re.IGNORECASE)
            if match:
                return match.group(0).strip()

        # Fallback: use first sentence
        sentences = re.split(r"[.!?]", thinking_content)
        if sentences:
            return sentences[0].strip()

        return thinking_content[:200]  # Fallback to first 200 chars
