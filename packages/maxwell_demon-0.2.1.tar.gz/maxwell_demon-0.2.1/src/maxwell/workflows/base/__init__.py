"""Base infrastructure for Maxwell workflows.

This package contains base classes, utilities, and common code shared across
all workflows. This is the public API that all workflow plugins depend on.

Workflows (plugins) import from workflows.base to implement the BaseWorkflow interface.
"""

from maxwell.workflows.base.base import (
    BaseWorkflow,
    WorkflowConfig,
    WorkflowInputs,
    WorkflowMetrics,
    WorkflowOutputs,
    WorkflowPriority,
    WorkflowResult,
    WorkflowStatus,
)

__all__ = [
    "WorkflowStatus",
    "WorkflowPriority",
    "WorkflowConfig",
    "WorkflowMetrics",
    "WorkflowResult",
    "BaseWorkflow",
    "WorkflowInputs",
    "WorkflowOutputs",
]
