"""Docstring Enrichment Workflow - Generate rich docstrings for code.

This workflow uses AST parsing and network LLMs to add comprehensive docstrings
to Python and JavaScript code:

Python: Google/NumPy style docstrings with Args, Returns, Raises
JavaScript: JSDoc comments with @param, @returns, @throws

Benefits:
- Better code understanding
- Improved embedding quality for duplicate detection
- Enhanced code search and navigation
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List

import libcst as cst

from maxwell.registry import register_workflow
from maxwell.workflows.base import (
    BaseWorkflow,
    WorkflowInputs,
    WorkflowOutputs,
    WorkflowResult,
    WorkflowStatus,
)

__all__ = ["DocstringEnrichmentWorkflow"]


class UndocumentedExtractor(cst.CSTVisitor):
    """LibCST visitor to extract undocumented functions/classes."""

    def __init__(self):
        """Initialize extractor."""
        self.undocumented = []
        self.in_class = None
        super().__init__()

    def visit_FunctionDef(self, node: cst.FunctionDef) -> None:
        """Visit function definition."""
        if not self._has_docstring(node):
            # Get function signature
            params = []
            if node.params:
                for param in node.params.params:
                    params.append(param.name.value)

            self.undocumented.append(
                {
                    "type": "method" if self.in_class else "function",
                    "name": node.name.value,
                    "params": params,
                    "code": cst.Module([node]).code,
                    "class": self.in_class,
                }
            )

    def visit_ClassDef(self, node: cst.ClassDef) -> None:
        """Visit class definition."""
        self.in_class = node.name.value

        if not self._has_docstring_class(node):
            self.undocumented.append(
                {
                    "type": "class",
                    "name": node.name.value,
                    "code": cst.Module([node]).code[:500],  # First 500 chars
                }
            )

    def leave_ClassDef(self, node: cst.ClassDef) -> None:
        """Leave class definition."""
        self.in_class = None

    def _has_docstring(self, node: cst.FunctionDef) -> bool:
        """Check if function has docstring."""
        if not node.body.body:
            return False
        first_stmt = node.body.body[0]
        if isinstance(first_stmt, cst.SimpleStatementLine):
            if first_stmt.body and isinstance(first_stmt.body[0], cst.Expr):
                expr = first_stmt.body[0]
                if isinstance(expr.value, cst.SimpleString):
                    return True
        return False

    def _has_docstring_class(self, node: cst.ClassDef) -> bool:
        """Check if class has docstring."""
        if not node.body.body:
            return False
        first_stmt = node.body.body[0]
        if isinstance(first_stmt, cst.SimpleStatementLine):
            if first_stmt.body and isinstance(first_stmt.body[0], cst.Expr):
                expr = first_stmt.body[0]
                if isinstance(expr.value, cst.SimpleString):
                    return True
        return False


@dataclass(frozen=True)
class DocstringEnrichmentInputs(WorkflowInputs):
    """Inputs for docstring enrichment workflow."""

    dry_run: bool = True  # Preview docstrings without modifying files
    languages: str = "python,javascript"  # Comma-separated: python,javascript
    use_network_llm: bool = True  # Use network LLM (better quality but slower)
    batch_size: int = 5  # Process N items per LLM call


@dataclass(frozen=True)
class DocstringEnrichmentOutputs(WorkflowOutputs):
    """Outputs for docstring enrichment workflow."""

    files_analyzed: int
    functions_enriched: int
    classes_enriched: int
    files_modified: List[str]
    preview_report: str


class PythonDocstringAdder(cst.CSTTransformer):
    """LibCST transformer to add docstrings to Python code."""

    def __init__(self, docstrings: Dict[str, str]):
        """Initialize transformer.

        Args:
            docstrings: Map of function/class name -> docstring

        """
        self.docstrings = docstrings
        super().__init__()

    def leave_FunctionDef(
        self, original_node: cst.FunctionDef, updated_node: cst.FunctionDef
    ) -> cst.FunctionDef:
        """Add docstring to function if missing."""
        name = original_node.name.value

        # Check if already has docstring
        if self._has_docstring(original_node):
            return updated_node

        # Get generated docstring
        if name not in self.docstrings:
            return updated_node

        # Create docstring node
        docstring = self.docstrings[name]
        docstring_node = cst.SimpleStatementLine(
            body=[cst.Expr(value=cst.SimpleString(f'"""{docstring}"""'))]
        )

        # Insert at beginning of function body
        new_body = [docstring_node] + list(updated_node.body.body)
        return updated_node.with_changes(body=updated_node.body.with_changes(body=new_body))

    def leave_ClassDef(
        self, original_node: cst.ClassDef, updated_node: cst.ClassDef
    ) -> cst.ClassDef:
        """Add docstring to class if missing."""
        name = original_node.name.value

        # Check if already has docstring
        if self._has_docstring_class(original_node):
            return updated_node

        # Get generated docstring
        if name not in self.docstrings:
            return updated_node

        # Create docstring node
        docstring = self.docstrings[name]
        docstring_node = cst.SimpleStatementLine(
            body=[cst.Expr(value=cst.SimpleString(f'"""{docstring}"""'))]
        )

        # Insert at beginning of class body
        new_body = [docstring_node] + list(updated_node.body.body)
        return updated_node.with_changes(body=updated_node.body.with_changes(body=new_body))

    def _has_docstring(self, node: cst.FunctionDef) -> bool:
        """Check if function already has docstring."""
        if not node.body.body:
            return False

        first_stmt = node.body.body[0]
        if isinstance(first_stmt, cst.SimpleStatementLine):
            if first_stmt.body and isinstance(first_stmt.body[0], cst.Expr):
                expr = first_stmt.body[0]
                if isinstance(expr.value, cst.SimpleString):
                    return True
        return False

    def _has_docstring_class(self, node: cst.ClassDef) -> bool:
        """Check if class already has docstring."""
        if not node.body.body:
            return False

        first_stmt = node.body.body[0]
        if isinstance(first_stmt, cst.SimpleStatementLine):
            if first_stmt.body and isinstance(first_stmt.body[0], cst.Expr):
                expr = first_stmt.body[0]
                if isinstance(expr.value, cst.SimpleString):
                    return True
        return False


@register_workflow
class DocstringEnrichmentWorkflow(BaseWorkflow):
    """Docstring enrichment workflow for Python and JavaScript."""

    workflow_id = "docstring-enrichment"
    name = "Docstring Enrichment"
    description = "Generate rich docstrings for Python and JavaScript code"
    version = "1.0"
    category = "maintenance"
    tags = {"code-quality", "documentation", "llm-assisted"}

    InputSchema = DocstringEnrichmentInputs
    OutputSchema = DocstringEnrichmentOutputs

    def get_cli_parameters(self):
        """Get CLI parameter definitions."""
        return [
            {
                "name": "dry-run",
                "type": bool,
                "default": True,
                "help": "Preview docstrings without modifying files",
            },
            {
                "name": "languages",
                "type": str,
                "default": "python,javascript",
                "help": "Languages to process (comma-separated)",
            },
            {
                "name": "use-network-llm",
                "type": bool,
                "default": True,
                "help": "Use network LLM for better quality",
            },
            {
                "name": "batch-size",
                "type": int,
                "default": 5,
                "help": "Process N items per LLM call",
            },
        ]

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        """Execute docstring enrichment.

        Args:
            project_root: Project root directory
            context: Execution context with options

        Returns:
            WorkflowResult with enrichment results

        """
        inputs = self.parse_inputs(context)

        languages = [lang.strip() for lang in inputs.languages.split(",")]

        print("\n📝 Docstring Enrichment")
        print(f"   Languages: {', '.join(languages)}")
        print(f"   LLM: {'Network' if inputs.use_network_llm else 'Local'}")
        print(f"   Mode: {'Dry run' if inputs.dry_run else 'Live'}")

        files_modified = []
        total_functions = 0
        total_classes = 0

        # Process Python files
        if "python" in languages:
            print("\n🐍 Processing Python files...")
            py_results = self._process_python(project_root, inputs)
            files_modified.extend(py_results["files_modified"])
            total_functions += py_results["functions_enriched"]
            total_classes += py_results["classes_enriched"]

        # Process JavaScript files
        if "javascript" in languages:
            print("\n📜 Processing JavaScript files...")
            js_results = self._process_javascript(project_root, inputs)
            files_modified.extend(js_results["files_modified"])
            total_functions += js_results["functions_enriched"]

        # Generate report
        report = self._generate_report(total_functions, total_classes, files_modified)

        outputs = DocstringEnrichmentOutputs(
            files_analyzed=len(files_modified),
            functions_enriched=total_functions,
            classes_enriched=total_classes,
            files_modified=files_modified,
            preview_report=report,
        )

        print(f"\n{report}")

        return self.create_result(outputs, status=WorkflowStatus.COMPLETED)

    def _process_python(
        self, project_root: Path, inputs: DocstringEnrichmentInputs
    ) -> Dict[str, Any]:
        """Process Python files to add docstrings.

        Args:
            project_root: Project root directory
            inputs: Workflow inputs

        Returns:
            Dict with processing results

        """
        from maxwell.lm_pool import get_lm

        # Find Python files
        src_root = project_root / "src"
        if not src_root.exists():
            src_root = project_root

        py_files = list(src_root.rglob("*.py"))
        py_files = [f for f in py_files if "__pycache__" not in str(f)]

        print(f"   Found {len(py_files)} Python files")

        functions_enriched = 0
        classes_enriched = 0
        files_modified = []

        # Get LLM for docstring generation
        if inputs.use_network_llm:
            # Try to get network LLM by name (qwen-coder-30b)
            try:
                llm = get_lm(name="qwen-coder-30b")
            except:
                # Fall back to default if network LLM not available
                llm = get_lm()
        else:
            llm = get_lm()  # Gets fastest available LLM

        # Process each file
        for py_file in py_files:
            try:
                source_code = py_file.read_text()
                tree = cst.parse_module(source_code)

                # Extract undocumented functions/classes
                extractor = UndocumentedExtractor()
                tree.visit(extractor)

                if not extractor.undocumented:
                    continue

                print(
                    f"   {py_file.relative_to(project_root)}: {len(extractor.undocumented)} items"
                )

                # Generate docstrings in batches
                docstrings = {}
                for i in range(0, len(extractor.undocumented), inputs.batch_size):
                    batch = extractor.undocumented[i : i + inputs.batch_size]
                    batch_docstrings = self._generate_docstrings_batch(
                        batch, llm, language="python"
                    )
                    docstrings.update(batch_docstrings)

                # Insert docstrings
                if not inputs.dry_run:
                    transformer = PythonDocstringAdder(docstrings)
                    modified_tree = tree.visit(transformer)
                    py_file.write_text(modified_tree.code)
                    files_modified.append(str(py_file.relative_to(project_root)))

                # Count enriched items
                for item in extractor.undocumented:
                    if item["name"] in docstrings:
                        if item["type"] == "class":
                            classes_enriched += 1
                        else:
                            functions_enriched += 1

            except Exception as e:
                print(f"   Error processing {py_file.name}: {e}")
                continue

        return {
            "functions_enriched": functions_enriched,
            "classes_enriched": classes_enriched,
            "files_modified": files_modified,
        }

    def _process_javascript(
        self, project_root: Path, inputs: DocstringEnrichmentInputs
    ) -> Dict[str, Any]:
        """Process JavaScript files to add JSDoc comments.

        Args:
            project_root: Project root directory
            inputs: Workflow inputs

        Returns:
            Dict with processing results

        """
        import re

        from maxwell.lm_pool import get_lm

        # Find JavaScript files
        js_files = list(project_root.rglob("*.js"))
        js_files.extend(project_root.rglob("*.jsx"))
        js_files = [f for f in js_files if "node_modules" not in str(f)]

        print(f"   Found {len(js_files)} JavaScript files")

        functions_enriched = 0
        files_modified = []

        # Get LLM for docstring generation
        if inputs.use_network_llm:
            try:
                llm = get_lm(name="qwen-coder-30b")
            except:
                llm = get_lm()
        else:
            llm = get_lm()

        # Regex patterns for JS functions
        # Matches: function name(...), const name = (...) =>, async function name(...)
        function_pattern = re.compile(
            r"(?P<indent>[ \t]*)"
            r"(?P<jsdoc>/\*\*[\s\S]*?\*/\s*)?"  # Optional existing JSDoc
            r"(?P<async>async\s+)?"
            r"(?:(?P<export>export\s+)?(?P<default>default\s+)?function\s+(?P<name1>\w+)\s*\((?P<params1>[^)]*)\)"
            r"|(?P<const>const|let|var)\s+(?P<name2>\w+)\s*=\s*(?P<async2>async\s*)?\([^)]*\)\s*=>)",
            re.MULTILINE,
        )

        # Process each file
        for js_file in js_files:
            try:
                source_code = js_file.read_text()
                undocumented = []

                # Find all function definitions
                for match in function_pattern.finditer(source_code):
                    # Skip if already has JSDoc
                    if match.group("jsdoc"):
                        continue

                    # Extract function name and params
                    name = match.group("name1") or match.group("name2")
                    params = match.group("params1") or ""

                    # Extract function code (next 200 chars)
                    start = match.start()
                    end = min(match.end() + 200, len(source_code))
                    code = source_code[start:end]

                    undocumented.append(
                        {
                            "type": "function",
                            "name": name,
                            "params": params,
                            "code": code,
                            "match": match,
                            "indent": match.group("indent"),
                        }
                    )

                if not undocumented:
                    continue

                print(f"   {js_file.relative_to(project_root)}: {len(undocumented)} functions")

                # Generate JSDoc comments in batches
                jsdoc_comments = {}
                for i in range(0, len(undocumented), inputs.batch_size):
                    batch = undocumented[i : i + inputs.batch_size]
                    batch_jsdocs = self._generate_docstrings_batch(
                        batch, llm, language="javascript"
                    )
                    jsdoc_comments.update(batch_jsdocs)

                # Insert JSDoc comments
                if not inputs.dry_run:
                    modified_code = source_code

                    # Insert JSDoc in reverse order to preserve positions
                    for item in reversed(undocumented):
                        if item["name"] not in jsdoc_comments:
                            continue

                        jsdoc = jsdoc_comments[item["name"]]
                        indent = item["indent"]

                        # Format JSDoc with proper indentation
                        jsdoc_lines = jsdoc.split("\n")
                        formatted_jsdoc = f"{indent}/**\n"
                        for line in jsdoc_lines:
                            if line.strip():
                                formatted_jsdoc += f"{indent} * {line.strip()}\n"
                        formatted_jsdoc += f"{indent} */\n"

                        # Insert before function
                        pos = item["match"].start()
                        modified_code = modified_code[:pos] + formatted_jsdoc + modified_code[pos:]

                    js_file.write_text(modified_code)
                    files_modified.append(str(js_file.relative_to(project_root)))

                # Count enriched functions
                functions_enriched += sum(
                    1 for item in undocumented if item["name"] in jsdoc_comments
                )

            except Exception as e:
                print(f"   Error processing {js_file.name}: {e}")
                continue

        return {
            "functions_enriched": functions_enriched,
            "files_modified": files_modified,
        }

    def _generate_docstrings_batch(
        self, batch: List[Dict[str, Any]], llm: Any, language: str
    ) -> Dict[str, str]:
        """Generate docstrings for a batch of functions/classes.

        Args:
            batch: List of undocumented items
            llm: LLM instance
            language: Programming language (python or javascript)

        Returns:
            Dict mapping name -> generated docstring

        """
        # Build prompt for batch generation
        if language == "python":
            style_guide = """Google-style Python docstrings with:
- Brief description
- Args: parameter descriptions with types
- Returns: return value description with type
- Raises: exceptions that may be raised (if applicable)

Example:
def calculate_similarity(vec1, vec2):
    \"\"\"Calculate cosine similarity between two vectors.

    Args:
        vec1: First vector as numpy array
        vec2: Second vector as numpy array

    Returns:
        float: Cosine similarity score between -1 and 1

    Raises:
        ValueError: If vectors have different dimensions
    \"\"\"
"""
        else:  # javascript
            style_guide = """JSDoc comments with:
- Brief description
- @param {type} name - description for each parameter
- @returns {type} description
- @throws {ErrorType} description (if applicable)

Example:
/**
 * Calculate cosine similarity between two vectors.
 *
 * @param {Array<number>} vec1 - First vector
 * @param {Array<number>} vec2 - Second vector
 * @returns {number} Cosine similarity score between -1 and 1
 * @throws {Error} If vectors have different dimensions
 */
"""

        items_text = []
        for i, item in enumerate(batch):
            item_type = item["type"]
            name = item["name"]
            code = item["code"][:300]  # Limit code length

            items_text.append(
                f"""
Item {i + 1}: {item_type} '{name}'
```{language}
{code}
```
"""
            )

        prompt = f"""Generate {language} docstrings for the following code items.

{style_guide}

{"".join(items_text)}

For each item, respond with:
ITEM N: <item number>
DOCSTRING:
<your generated docstring here, properly formatted>

Generate concise but complete docstrings that explain what the code does, its parameters, and return values.
"""

        # Call LLM
        response = llm.generate(prompt, max_tokens=2000)

        # Parse response
        docstrings = {}
        current_item = None
        current_docstring = []

        for line in response.split("\n"):
            if line.startswith("ITEM "):
                # Save previous docstring
                if (
                    current_item is not None
                    and 0 <= current_item < len(batch)
                    and current_docstring
                ):
                    docstring = self._clean_docstring(current_docstring, language)
                    if docstring:
                        docstrings[batch[current_item]["name"]] = docstring

                # Start new item
                try:
                    current_item = int(line.split(":")[0].replace("ITEM", "").strip()) - 1
                    current_docstring = []
                except:
                    pass

            elif line.startswith("DOCSTRING:"):
                current_docstring = []
            elif current_item is not None:
                current_docstring.append(line)

        # Save last docstring
        if current_item is not None and 0 <= current_item < len(batch) and current_docstring:
            docstring = self._clean_docstring(current_docstring, language)
            if docstring:
                docstrings[batch[current_item]["name"]] = docstring

        return docstrings

    def _clean_docstring(self, lines: List[str], language: str) -> str:
        """Clean up generated docstring.

        Args:
            lines: Raw docstring lines from LLM
            language: Programming language (python or javascript)

        Returns:
            Cleaned docstring text

        """
        import re

        # Join lines
        text = "\n".join(lines).strip()

        # Remove markdown code blocks
        text = re.sub(r"```\w*\n?", "", text)

        # Remove function/class definitions that LLM might include
        text = re.sub(r"^\s*def\s+\w+\([^)]*\)\s*:\s*\n?", "", text, flags=re.MULTILINE)
        text = re.sub(r"^\s*class\s+\w+.*:\s*\n?", "", text, flags=re.MULTILINE)
        text = re.sub(r"^\s*function\s+\w+\([^)]*\)\s*\{\s*\n?", "", text, flags=re.MULTILINE)
        text = re.sub(
            r"^\s*const\s+\w+\s*=\s*\([^)]*\)\s*=>\s*\{\s*\n?", "", text, flags=re.MULTILINE
        )

        # Remove triple quotes that LLM might add
        text = text.replace('"""', "").replace("'''", "")

        # Remove leading/trailing whitespace
        text = text.strip()

        # If text starts with a docstring quote, extract content
        if language == "python":
            # Extract content between docstring quotes if present
            match = re.search(r'["\']{3}(.*?)["\']{3}', text, re.DOTALL)
            if match:
                text = match.group(1).strip()

        return text

    def _generate_report(self, functions: int, classes: int, files: List[str]) -> str:
        """Generate enrichment report.

        Args:
            functions: Number of functions enriched
            classes: Number of classes enriched
            files: List of modified files

        Returns:
            Human-readable report

        """
        lines = []
        lines.append("=" * 80)
        lines.append("DOCSTRING ENRICHMENT RESULTS")
        lines.append("=" * 80)
        lines.append(f"\nFunctions enriched: {functions}")
        lines.append(f"Classes enriched: {classes}")
        lines.append(f"Files modified: {len(files)}")

        if files:
            lines.append("\nModified files:")
            for file in sorted(files)[:10]:
                lines.append(f"  - {file}")
            if len(files) > 10:
                lines.append(f"  ... and {len(files) - 10} more")

        lines.append("\n" + "=" * 80)
        return "\n".join(lines)
