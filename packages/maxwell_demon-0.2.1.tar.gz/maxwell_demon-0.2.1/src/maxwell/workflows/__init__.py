"""Workflow implementations package.

Contains all concrete workflow implementations organized by functionality.

Responsibility: Workflow implementation organization only.
Individual workflow logic belongs in specific implementation modules.

maxwell/src/maxwell/workflow/implementations/__init__.py
"""

# Import all workflows to trigger @register_workflow decorators
# Optional dependencies are handled via try/except at import time

# Core workflows (no optional dependencies)
from . import (
    architecture_lint,
    deep_research,
    docstring_enrichment,
    snapshot,
    tag_refactor,
    utilities,
    validate,
    web_scrape,
)

__all__ = [
    "architecture_lint",
    "deep_research",
    "docstring_enrichment",
    "snapshot",
    "tag_refactor",
    "utilities",
    "validate",
    "web_scrape",
    # Helper functions for lazy imports
    "get_tag_refactor_workflow",
    "run_tag_refactor",
]

# Agentic refactoring requires numpy, networkx (refactor extras)
try:
    from . import agentic_refactoring  # noqa: F401

    __all__.insert(0, "agentic_refactoring")
except ImportError:
    pass  # Silently skip if dependencies missing

# Chat workflows require pymongo, qdrant-client (chat extras)
try:
    from . import chat  # noqa: F401

    __all__.insert(0, "chat")
except ImportError:
    pass  # Silently skip if dependencies missing


# Lazy imports to avoid circular dependencies
def get_tag_refactor_workflow():  # type: ignore[no-untyped-def]
    """Get TagRefactorWorkflow class."""
    from .tag_refactor import TagRefactorWorkflow

    return TagRefactorWorkflow


def run_tag_refactor(*args, **kwargs):  # type: ignore[no-untyped-def]
    """Run tag refactoring workflow (convenience function)."""
    from .tag_refactor import run_tag_refactor as _run

    return _run(*args, **kwargs)
