"""Temporal concept evolution using iterative discovery and ontology construction.

Based on research from:
- RIGOR (arXiv:2506.01232): Delta ontology incremental building with RAG
- Wikidata KG (arXiv:2412.20942): Vector similarity + LLM vetting for deduplication

Workflow:
1. Seed: Sample recent N turns from MongoDB
2. Extract: Concepts from seed (delta ontology #1)
3. Deduplicate: Vector similarity + LLM judge
4. Query: Generate Socratic questions about concepts
5. Expand: Query entire corpus, extract more concepts
6. Repeat: Until convergence or max iterations
7. Build: Final ontology with relationships and insights
"""

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from pydantic import BaseModel

from maxwell.db import get_mongodb, get_qdrant
from maxwell.dependencies import requires_dependencies
from maxwell.lm_pool import get_lm
from maxwell.registry import register_workflow
from maxwell.workflows.base import (
    BaseWorkflow,
    WorkflowInputs,
    WorkflowOutputs,
    WorkflowResult,
    WorkflowStatus,
)

logger = logging.getLogger(__name__)


# -------------------------------------------------------------
# JSON repair utilities
# -------------------------------------------------------------


def parse_json_with_repair(text: str) -> Any:
    """Parse JSON with fallback to partial JSON parser.

    Args:
        text: JSON text (possibly broken/incomplete)

    Returns:
        Parsed data structure

    Raises:
        ValueError: If JSON cannot be parsed or repaired

    """
    import json

    from partial_json_parser import loads as partial_loads

    # Try standard JSON first
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Try partial JSON parser
    try:
        logger.debug("Standard JSON failed, trying partial parser")
        return partial_loads(text)
    except Exception as e:
        raise ValueError(f"Could not parse JSON even with repair: {e}")


# -------------------------------------------------------------
# Pydantic models for structured LLM output
# -------------------------------------------------------------


class ExtractedConcept(BaseModel):
    """Single extracted concept from LLM."""

    name: str
    description: str
    context: str


class ConceptList(BaseModel):
    """List of extracted concepts."""

    concepts: List[ExtractedConcept]


class RelationshipEdge(BaseModel):
    """Knowledge graph edge."""

    source: str
    target: str
    relationship: str


class RelationshipList(BaseModel):
    """List of relationships."""

    edges: List[RelationshipEdge]


# -------------------------------------------------------------
# Data structures for concepts and ontology
# -------------------------------------------------------------


@dataclass
class Concept:
    """A discovered concept with embeddings and context."""

    name: str
    description: str
    first_seen: str  # ISO timestamp
    last_seen: str
    mention_count: int
    embedding: Optional[List[float]] = None
    context_examples: List[str] = field(default_factory=list)
    related_concepts: List[str] = field(default_factory=list)
    turn_ids: Set[str] = field(default_factory=set)


@dataclass
class ConceptOntology:
    """Growing ontology of concepts with relationships."""

    concepts: Dict[str, Concept] = field(default_factory=dict)
    relationships: List[Dict[str, str]] = field(default_factory=list)

    def add_concept(self, concept: Concept) -> None:
        """Add or merge a concept into the ontology."""
        if concept.name in self.concepts:
            # Merge with existing
            existing = self.concepts[concept.name]
            existing.mention_count += concept.mention_count
            existing.last_seen = concept.last_seen
            existing.context_examples.extend(concept.context_examples)
            existing.turn_ids.update(concept.turn_ids)
        else:
            self.concepts[concept.name] = concept

    def get_all_embeddings(self) -> List[tuple[str, List[float]]]:
        """Get all concept embeddings for similarity search."""
        return [
            (name, concept.embedding)
            for name, concept in self.concepts.items()
            if concept.embedding is not None
        ]


# -------------------------------------------------------------
# Workflow schemas
# -------------------------------------------------------------


@dataclass(frozen=True)
class TemporalConceptEvolutionInputs(WorkflowInputs):
    """Input schema for temporal concept evolution workflow."""

    # Seed phase
    seed_turns: int = 100  # Recent N turns to start exploration
    temporal_decay: bool = True  # Weight recent turns higher

    # Iteration control (RIGOR-style)
    max_iterations: int = 10  # Maximum expansion iterations
    convergence_threshold: int = 5  # Stop if < N new concepts found

    # Query phase (Socratic method)
    results_per_query: int = 20  # Turns to retrieve per question
    socratic_depth: int = 3  # Questions per concept

    # Deduplication (Wikidata paper)
    similarity_threshold: float = 0.85  # Cosine similarity threshold
    use_llm_vetting: bool = True  # Use LLM to verify duplicates

    # Output control
    max_concepts: int = 100  # Limit final ontology size
    build_knowledge_graph: bool = True  # Extract concept relationships


@dataclass(frozen=True)
class TemporalConceptEvolutionOutputs(WorkflowOutputs):
    """Output schema for temporal concept evolution workflow."""

    ontology: Dict[str, Any]  # Serialized ConceptOntology
    knowledge_graph: Dict[str, Any]  # Graph structure with nodes/edges
    insights: str  # LLM-generated analysis
    iterations_completed: int
    total_concepts: int
    total_turns_analyzed: int


# -------------------------------------------------------------
# Main workflow
# -------------------------------------------------------------


@requires_dependencies(["pymongo", "qdrant-client"], extras_name="chat")
@register_workflow
class TemporalConceptEvolutionWorkflow(BaseWorkflow):
    """Iterative concept discovery workflow for conversations.

    Discovers concepts from recent conversations and expands the topic space
    using Socratic questioning and deduplication.
    """

    workflow_id: str = "temporal-concept-evolution"
    name: str = "Temporal Concept Evolution"
    description: str = "Iterative concept discovery with ontology construction"

    InputSchema = TemporalConceptEvolutionInputs
    OutputSchema = TemporalConceptEvolutionOutputs

    def get_cli_parameters(self) -> List[Dict[str, Any]]:
        """Define CLI parameters."""
        return [
            {
                "name": "seed_turns",
                "type": int,
                "required": False,
                "default": 100,
                "help": "Number of recent turns to use as seed",
            },
            {
                "name": "max_iterations",
                "type": int,
                "required": False,
                "default": 10,
                "help": "Maximum expansion iterations",
            },
            {
                "name": "convergence_threshold",
                "type": int,
                "required": False,
                "default": 5,
                "help": "Stop if fewer than N new concepts found",
            },
            {
                "name": "results_per_query",
                "type": int,
                "required": False,
                "default": 20,
                "help": "Conversation turns to retrieve per Socratic question",
            },
            {
                "name": "similarity_threshold",
                "type": float,
                "required": False,
                "default": 0.85,
                "help": "Cosine similarity threshold for deduplication (0.0-1.0)",
            },
            {
                "name": "max_concepts",
                "type": int,
                "required": False,
                "default": 100,
                "help": "Maximum concepts in final ontology",
            },
        ]

    def execute(self, _project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        """Execute temporal concept evolution workflow."""
        try:
            # Parse inputs
            inputs: TemporalConceptEvolutionInputs = self.parse_inputs(context)  # type: ignore[assignment]

            logger.info(f"Starting concept evolution with {inputs.seed_turns} seed turns")

            # Get database connections
            mongodb = get_mongodb()
            qdrant = get_qdrant()

            # Use llamacpp backend for reliable structured output with GBNF grammar
            llm_client = get_lm("qwen-coder-30b")

            # Initialize core ontology (grows incrementally like RIGOR)
            core_ontology = ConceptOntology()
            explored_turn_ids: Set[str] = set()
            total_turns_analyzed = 0

            # SEED PHASE: Sample recent turns
            logger.info("Phase 1: Seed sampling")
            seed_turns = self._sample_recent_turns(
                mongodb, n=inputs.seed_turns, _temporal_decay=inputs.temporal_decay
            )
            explored_turn_ids.update(t["turn_id"] for t in seed_turns)
            total_turns_analyzed += len(seed_turns)

            logger.info(f"Sampled {len(seed_turns)} seed turns")

            # ITERATIVE EXPANSION (RIGOR-style delta ontologies)
            for iteration in range(inputs.max_iterations):
                logger.info(f"Iteration {iteration + 1}/{inputs.max_iterations}")

                # Select turns to analyze this iteration
                if iteration == 0:
                    current_turns = seed_turns
                else:
                    current_turns = query_results

                # EXTRACT: Concepts from current batch (delta ontology)
                delta_concepts = self._extract_concepts(current_turns, llm_client, core_ontology)

                logger.info(f"Extracted {len(delta_concepts)} raw concepts")

                # DEDUPLICATE: Vector similarity + LLM vetting
                deduplicated_concepts = []
                for concept in delta_concepts:
                    is_duplicate, merged = self._deduplicate_concept(
                        concept,
                        core_ontology,
                        inputs.similarity_threshold,
                        inputs.use_llm_vetting,
                        llm_client,
                    )

                    if not is_duplicate:
                        deduplicated_concepts.append(merged)

                logger.info(f"After deduplication: {len(deduplicated_concepts)} unique concepts")

                # MERGE: Delta into core ontology
                for concept in deduplicated_concepts:
                    core_ontology.add_concept(concept)

                # CONVERGENCE CHECK
                if len(deduplicated_concepts) < inputs.convergence_threshold:
                    logger.info(
                        f"Converged at iteration {iteration + 1}: "
                        f"only {len(deduplicated_concepts)} new concepts"
                    )
                    break

                # Check concept limit
                if len(core_ontology.concepts) >= inputs.max_concepts:
                    logger.info(f"Reached max concepts limit: {inputs.max_concepts}")
                    break

                # SOCRATIC QUERY: Generate questions about concepts
                questions = self._generate_socratic_questions(
                    deduplicated_concepts, core_ontology, inputs.socratic_depth
                )

                logger.info(f"Generated {len(questions)} Socratic questions")

                # QUERY: Search entire corpus for related turns
                query_results = []
                for question in questions:
                    results = self._query_corpus(
                        question,
                        mongodb,
                        qdrant,
                        limit=inputs.results_per_query,
                        exclude_turn_ids=explored_turn_ids,
                    )
                    query_results.extend(results)

                    # Track explored turns
                    explored_turn_ids.update(r["turn_id"] for r in results)

                total_turns_analyzed += len(query_results)
                logger.info(f"Retrieved {len(query_results)} new turns from queries")

                if not query_results:
                    logger.info("No new turns found, stopping exploration")
                    break

            # BUILD KNOWLEDGE GRAPH
            if inputs.build_knowledge_graph:
                logger.info("Building knowledge graph from ontology")
                knowledge_graph = self._build_knowledge_graph(core_ontology, llm_client)
            else:
                knowledge_graph = {"nodes": [], "edges": []}

            # SYNTHESIS: Analyze ontology for insights
            logger.info("Synthesizing insights from ontology")
            insights = self._synthesize_insights(core_ontology, knowledge_graph, llm_client)

            # Create outputs
            outputs = TemporalConceptEvolutionOutputs(
                ontology=self._serialize_ontology(core_ontology),
                knowledge_graph=knowledge_graph,
                insights=insights,
                iterations_completed=iteration + 1,
                total_concepts=len(core_ontology.concepts),
                total_turns_analyzed=total_turns_analyzed,
            )

            # Update metrics
            self.metrics.files_processed = total_turns_analyzed
            self.metrics.custom_metrics = {
                "concepts_discovered": len(core_ontology.concepts),
                "iterations": iteration + 1,
                "convergence_reached": len(deduplicated_concepts) < inputs.convergence_threshold,
            }

            return self.create_result(outputs, WorkflowStatus.COMPLETED)

        except Exception as e:
            logger.error(f"Temporal concept evolution failed: {e}", exc_info=True)
            return self.create_result(
                outputs=None,
                status=WorkflowStatus.FAILED,
                error_message=f"Workflow failed: {str(e)}",
            )

    # -------------------------------------------------------------
    # Helper methods
    # -------------------------------------------------------------

    def _sample_recent_turns(self, mongodb, n: int, _temporal_decay: bool) -> List[Dict[str, Any]]:
        """Sample recent N turns from MongoDB.

        Args:
            mongodb: MongoDB connection
            n: Number of turns to sample
            temporal_decay: If True, weight recent turns higher

        Returns:
            List of turn documents

        """
        turns_collection = mongodb["turns"]

        # Get recent turns sorted by timestamp descending
        cursor = turns_collection.find().sort("timestamp", -1).limit(n)

        turns = list(cursor)
        logger.debug(f"Sampled {len(turns)} recent turns")

        return turns

    def _extract_concepts(
        self, turns: List[Dict[str, Any]], llm_client, context_ontology: ConceptOntology
    ) -> List[Concept]:
        """Extract concepts from turns using LLM with chunked processing.

        Args:
            turns: List of conversation turns
            llm_client: LLM client
            context_ontology: Existing ontology for context (RAG)

        Returns:
            List of extracted concepts

        """
        # Build context from existing ontology (RAG pattern)
        existing_concepts = list(context_ontology.concepts.keys())[:20]
        context_str = ", ".join(existing_concepts) if existing_concepts else "none yet"

        # Process in small chunks (2-3 turns at a time)
        all_concepts = []
        chunk_size = 3

        for i in range(0, len(turns), chunk_size):
            chunk = turns[i : i + chunk_size]

            # Build chunk text
            turn_texts = []
            for turn in chunk:
                role = turn.get("role", "unknown")
                content = turn.get("content", "")[:300]  # More context per turn
                turn_texts.append(f"[{role.upper()}]: {content}")

            combined_text = "\n\n".join(turn_texts)

            # Markdown bullet list prompt (much simpler than JSON)
            prompt = f"""Extract key concepts from this conversation chunk.

Existing concepts: {context_str}

Conversation:
{combined_text}

List NEW concepts not in the existing list. For each concept:
- **Name**: concise 2-4 word name
- **Description**: one sentence explanation
- **Context**: brief quote showing usage

Format as markdown bullets. Example:
- **Vector Database**: A database optimized for similarity search using embeddings
  - Context: "We need to store embeddings in Qdrant for semantic search"
"""

            try:
                response = llm_client.generate(prompt, max_tokens=800, temperature=0.3)

                # Parse markdown bullets
                concepts = self._parse_concept_bullets(response, chunk)
                all_concepts.extend(concepts)

            except Exception as e:
                logger.warning(f"Concept extraction failed for chunk: {e}")
                continue

        logger.info(f"Extracted {len(all_concepts)} concepts from {len(turns)} turns")
        return all_concepts

    def _parse_concept_bullets(self, markdown: str, turns: List[Dict[str, Any]]) -> List[Concept]:
        """Parse concepts from markdown bullet list.

        Args:
            markdown: Markdown text with bullet list
            turns: Source turns for metadata

        Returns:
            List of Concept objects

        """
        import re

        concepts = []
        lines = markdown.strip().split("\n")

        current_concept = None

        for line in lines:
            # Match main concept bullet: - **Name**: description
            main_match = re.match(r"^-\s+\*\*([^*]+)\*\*:?\s*(.+)?", line.strip())
            if main_match:
                name = main_match.group(1).strip()
                description = main_match.group(2).strip() if main_match.group(2) else ""

                if current_concept:
                    concepts.append(current_concept)

                current_concept = Concept(
                    name=name,
                    description=description,
                    first_seen=turns[0].get("timestamp", "") if turns else "",
                    last_seen=turns[-1].get("timestamp", "") if turns else "",
                    mention_count=1,
                    context_examples=[],
                    turn_ids={t.get("turn_id", "") for t in turns if "turn_id" in t},
                )

            # Match context sub-bullet: - Context: "quote"
            elif current_concept:
                context_match = re.match(r"^\s*-\s+Context:?\s*(.+)", line.strip())
                if context_match:
                    current_concept.context_examples.append(context_match.group(1).strip('"'))

        # Add last concept
        if current_concept:
            concepts.append(current_concept)

        return concepts

    def _deduplicate_concept(
        self,
        new_concept: Concept,
        ontology: ConceptOntology,
        _threshold: float,
        use_llm: bool,
        llm_client,
    ) -> tuple[bool, Concept]:
        """Check if concept is duplicate using vector similarity + LLM vetting.

        Based on Wikidata paper (arXiv:2412.20942):
        - Stage 1: Vector similarity (fast)
        - Stage 2: LLM semantic vetting (accurate)

        Args:
            new_concept: Concept to check
            ontology: Existing ontology
            threshold: Cosine similarity threshold
            use_llm: Whether to use LLM vetting
            llm_client: LLM client

        Returns:
            (is_duplicate, merged_concept)

        """
        if not ontology.concepts:
            return False, new_concept

        # Stage 1: Vector similarity (using concept name as proxy)
        # TODO: Use actual embeddings when available
        candidates = []
        for existing_name, existing_concept in ontology.concepts.items():
            # Simple name similarity for now (should use embeddings)
            if existing_name.lower() == new_concept.name.lower():
                candidates.append((existing_concept, 1.0))
            elif (
                new_concept.name.lower() in existing_name.lower()
                or existing_name.lower() in new_concept.name.lower()
            ):
                candidates.append((existing_concept, 0.9))

        if not candidates:
            return False, new_concept

        # Stage 2: LLM vetting (if enabled)
        if use_llm and candidates:
            top_candidate = candidates[0][0]

            vetting_prompt = f"""Are these concepts semantically equivalent?

Concept A: {new_concept.name}
Description: {new_concept.description}
Context: {new_concept.context_examples[0] if new_concept.context_examples else 'N/A'}

Concept B: {top_candidate.name}
Description: {top_candidate.description}
Context: {top_candidate.context_examples[0] if top_candidate.context_examples else 'N/A'}

Answer ONLY 'yes' or 'no' followed by brief reasoning (one sentence).
"""

            try:
                response = llm_client.generate(vetting_prompt).strip().lower()

                if response.startswith("yes"):
                    # Merge concepts
                    merged = top_candidate
                    merged.mention_count += new_concept.mention_count
                    merged.context_examples.extend(new_concept.context_examples)
                    merged.turn_ids.update(new_concept.turn_ids)
                    merged.last_seen = new_concept.last_seen

                    return True, merged

            except Exception as e:
                logger.warning(f"LLM vetting failed: {e}")

        return False, new_concept

    def _generate_socratic_questions(
        self, concepts: List[Concept], ontology: ConceptOntology, depth: int
    ) -> List[str]:
        """Generate Socratic questions to expand topic space.

        Args:
            concepts: Recently discovered concepts
            ontology: Full ontology for context
            depth: Questions per concept

        Returns:
            List of questions

        """
        questions = []

        for concept in concepts[:10]:  # Limit to avoid too many queries
            # Question about origin/purpose
            questions.append(
                f"Why was {concept.name} discussed? What problem or context led to this topic?"
            )

            # Question about relationships
            if len(ontology.concepts) > 1:
                other_concepts = [
                    name for name in ontology.concepts.keys() if name != concept.name
                ][:3]
                for other in other_concepts:
                    questions.append(f"How does {concept.name} relate to or interact with {other}?")

            # Question about evolution
            questions.append(
                f"Has the meaning or importance of {concept.name} changed over time in our discussions?"
            )

            if len(questions) >= len(concepts) * depth:
                break

        return questions[: len(concepts) * depth]  # Limit total questions

    def _query_corpus(
        self,
        question: str,
        mongodb,
        _qdrant,
        limit: int,
        exclude_turn_ids: Set[str],
    ) -> List[Dict[str, Any]]:
        """Query MongoDB+Qdrant corpus for turns related to question.

        Args:
            question: Query question
            mongodb: MongoDB connection
            qdrant: Qdrant connection
            limit: Max results
            exclude_turn_ids: Turn IDs to skip

        Returns:
            List of turn documents

        """
        # Use chat-semantic-search workflow
        from maxwell.api import execute_workflow

        try:
            result = execute_workflow(
                "chat-semantic-search",
                Path.cwd(),
                {"query": question, "limit": limit, "format": "compact"},
            )

            if result.status == WorkflowStatus.COMPLETED:
                search_results = result.artifacts.get("results", [])

                # Filter out already explored turns
                filtered = [r for r in search_results if r.get("turn_id") not in exclude_turn_ids]

                # Get full turn documents from MongoDB
                turns_collection = mongodb["turns"]
                turn_docs = []
                for r in filtered:
                    turn_id = r.get("turn_id")
                    doc = turns_collection.find_one({"turn_id": turn_id})
                    if doc:
                        turn_docs.append(doc)

                return turn_docs

        except Exception as e:
            logger.error(f"Corpus query failed for '{question}': {e}")

        return []

    def _build_knowledge_graph(self, ontology: ConceptOntology, llm_client) -> Dict[str, Any]:
        """Build knowledge graph from ontology using LLM with incremental batching.

        Args:
            ontology: Concept ontology
            llm_client: LLM client

        Returns:
            Graph structure with nodes and edges

        """
        # Get all concept names
        all_concept_names = list(ontology.concepts.keys())

        if not all_concept_names:
            return {"nodes": [], "edges": []}

        # Process relationships in batches (like worksheet-manager)
        all_edges = []
        batch_size = 10  # Small batches to fit in context

        for i in range(0, len(all_concept_names), batch_size):
            batch = all_concept_names[i : i + batch_size]

            logger.info(
                f"Building relationships for batch {i//batch_size + 1} ({len(batch)} concepts)"
            )

            # LLM prompt using markdown bullets - only for this batch
            prompt = f"""Analyze relationships between these {len(batch)} concepts:

Concepts: {', '.join(batch)}

List meaningful relationships as markdown bullets:
- **Concept A** → **Concept B**: relationship type
- **Concept C** → **Concept D**: relationship type

Example:
- **Vector Database** → **Qdrant**: implements
- **Embedding Model** → **Vector Database**: uses

Only include direct, meaningful relationships within this list.
"""

            try:
                response = llm_client.generate(prompt, max_tokens=800, temperature=0.3)

                # Parse markdown relationships
                edges = self._parse_relationship_bullets(response)
                all_edges.extend(edges)

                logger.debug(f"Batch {i//batch_size + 1}: Found {len(edges)} relationships")

            except Exception as e:
                logger.warning(f"Relationship extraction failed for batch {i//batch_size + 1}: {e}")
                continue

        # Build graph structure
        graph = {
            "nodes": [{"id": name, "label": name} for name in all_concept_names],
            "edges": all_edges,
        }

        logger.info(
            f"Built knowledge graph with {len(graph['nodes'])} nodes and {len(graph['edges'])} edges"
        )
        return graph

    def _parse_relationship_bullets(self, markdown: str) -> List[Dict[str, str]]:
        """Parse relationships from markdown bullet list.

        Args:
            markdown: Markdown text with relationship bullets

        Returns:
            List of edge dictionaries

        """
        import re

        edges = []
        lines = markdown.strip().split("\n")

        for line in lines:
            # Match: - **Source** → **Target**: relationship
            match = re.match(
                r"^\s*-\s+\*\*([^*]+)\*\*\s*→\s*\*\*([^*]+)\*\*:?\s*(.+)?", line.strip()
            )
            if match:
                source = match.group(1).strip()
                target = match.group(2).strip()
                relationship = match.group(3).strip() if match.group(3) else "relates_to"

                edges.append({"source": source, "target": target, "relationship": relationship})

        return edges

    def _synthesize_insights(
        self, ontology: ConceptOntology, graph: Dict[str, Any], llm_client
    ) -> str:
        """Synthesize insights from ontology using LLM.

        Args:
            ontology: Concept ontology
            graph: Knowledge graph
            llm_client: LLM client

        Returns:
            Insights text

        """
        # Build summary of ontology
        top_concepts = sorted(
            ontology.concepts.values(), key=lambda c: c.mention_count, reverse=True
        )[:20]

        concept_summary = "\n".join(
            [
                f"- {c.name} (mentioned {c.mention_count} times): {c.description}"
                for c in top_concepts
            ]
        )

        # Analysis prompt
        prompt = f"""Analyze this conversation ontology to understand the user-assistant relationship:

Top Concepts Discussed:
{concept_summary}

Knowledge Graph:
{len(graph.get('nodes', []))} concepts with {len(graph.get('edges', []))} relationships

Provide analysis addressing:

1. **Dominant Topics**: What subjects dominate the discourse?
2. **Knowledge Domains**: What areas of knowledge are being built?
3. **Relationship Dynamics**: How has the user-assistant collaboration evolved?
4. **Recurring Themes**: What patterns emerge across discussions?
5. **Key Insights**: What does this reveal about the user's interests and work?

Provide a comprehensive but concise analysis (3-4 paragraphs).
"""

        try:
            insights = llm_client.generate(prompt)
            return insights

        except Exception as e:
            logger.error(f"Insight synthesis failed: {e}")
            return "Insight synthesis failed"

    def _serialize_ontology(self, ontology: ConceptOntology) -> Dict[str, Any]:
        """Serialize ontology for output.

        Args:
            ontology: Concept ontology

        Returns:
            Serialized dict

        """
        return {
            "concepts": {
                name: {
                    "description": concept.description,
                    "first_seen": concept.first_seen,
                    "last_seen": concept.last_seen,
                    "mention_count": concept.mention_count,
                    "context_examples": concept.context_examples[:3],  # Limit
                    "related_concepts": concept.related_concepts,
                    "turn_count": len(concept.turn_ids),
                }
                for name, concept in ontology.concepts.items()
            },
            "relationships": ontology.relationships,
            "total_concepts": len(ontology.concepts),
        }
