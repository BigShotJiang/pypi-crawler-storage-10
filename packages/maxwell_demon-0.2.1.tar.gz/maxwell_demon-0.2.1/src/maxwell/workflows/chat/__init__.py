"""Chat workflow package for Maxwell.

Provides workflows for chat processing:
- chat_incremental: Incremental processing with deduplication
- chat_backup: Backup and restore functionality
- chat_semantic_search: Semantic search with Qdrant
- chat_bm25_search: BM25 keyword search
- metadata_extractor: Metadata extraction and quality control

Note: Chat workflows require optional dependencies.
Install with: pip install maxwell-demon[chat]

All workflows use @requires_dependencies decorator to gracefully skip
registration if pymongo/qdrant-client are not installed.

Usage:
    from maxwell.workflows.chat import (
        RegisteredIncrementalChatWorkflow,
        RegisteredChatBackupWorkflow,
        ChatSemanticSearchWorkflow,
        ChatBM25SearchWorkflow,
        MetadataExtractor
    )
"""

# Import all chat workflows - they use @requires_dependencies to handle
# missing optional dependencies gracefully
from .backup_strategy import RegisteredChatBackupWorkflow  # noqa: F401
from .bm25_search import BM25Searcher, ChatBM25SearchWorkflow  # noqa: F401
from .incremental_processor import (  # noqa: F401
    RegisteredIncrementalChatWorkflow,
)
from .metadata_extractor import MetadataExtractor, TurnMetadata  # noqa: F401
from .parsers import ChatGPTParser, ClaudeParser, Message  # noqa: F401
from .semantic_search import ChatSemanticSearchWorkflow  # noqa: F401
from .temporal_concept_evolution import (  # noqa: F401
    TemporalConceptEvolutionWorkflow,
)

__all__ = [
    "BM25Searcher",
    "ChatBM25SearchWorkflow",
    "ChatGPTParser",
    "ChatSemanticSearchWorkflow",
    "ClaudeParser",
    "Message",
    "MetadataExtractor",
    "RegisteredChatBackupWorkflow",
    "RegisteredIncrementalChatWorkflow",
    "TemporalConceptEvolutionWorkflow",
    "TurnMetadata",
]
