"""Deep research workflow - comprehensive search across multiple data sources.

Leverages MCP tools for powerful multi-source research:
- Chat logs (semantic + BM25 search via MongoDB/Qdrant)
- Web search (via web-search-prime MCP)
- Filesystem search (via Maxwell workflows)
- LLM synthesis for insights

Features:
- Selective MCP tool access (configurable via --mcp_tools parameter)
- Multi-iteration research with LLM-generated follow-up queries
- Automatic synthesis of findings into structured reports

Usage:
    # Basic research (uses chat + web by default)
    maxwell deep-research "What are the key architectural patterns in my codebase?"

    # Chat-only semantic search (constrain to only chat MCPs)
    maxwell deep-research "How did I solve PDF parsing issues?" \\
        --data_sources chat \\
        --mcp_tools chat-semantic-search

    # Chat-only BM25 keyword search (no embeddings needed)
    maxwell deep-research "MongoDB connection" \\
        --data_sources chat \\
        --use_semantic false \\
        --mcp_tools chat-bm25-search

    # Multi-source research with explicit MCP control
    maxwell deep-research "Best practices for vector databases" \\
        --data_sources chat,web \\
        --mcp_tools chat-semantic-search,web-search

MCP Tool Guardrails:
- MCPs are auto-discovered from ~/.claude/settings.local.json
- Deterministic resolution: always returns sorted list of allowed tools
- Validation: all requested MCPs must exist in settings.local.json
- No hardcoded tool lists - respects user's approved MCPs

Default Behavior (no --mcp_tools):
    # Auto-detects tools matching "chat", "search", "web" patterns
    maxwell deep-research "Research question"
    # Uses: web-search-prime (auto-detected from settings)

Explicit Tool Selection:
    # Constrain to specific MCPs
    maxwell deep-research "Research question" --mcp_tools justification
    # Uses only: justification

List Available MCPs:
    # See what MCPs are available from your settings.local.json
    maxwell deep-research "test" --mcp_tools list
    # Outputs:
    #   - justification
    #   - web-search-prime

Adding MCPs to Claude settings:
    # Edit ~/.claude/settings.local.json
    {
      "permissions": {
        "allow": [
          "mcp__maxwell__maxwell_chat_semantic_search",
          "mcp__web-search-prime__webSearchPrime"
        ]
      }
    }

Resolution Logic (deterministic):
1. If --mcp_tools='list': show available MCPs and exit
2. If --mcp_tools specified: use only those (validated against settings)
3. If not specified: auto-detect tools with "chat"/"search"/"web" patterns
4. Always return sorted list for deterministic behavior
"""

__all__ = ["DeepResearchWorkflow"]

import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from maxwell.api import execute_workflow
from maxwell.lm_pool import get_lm
from maxwell.registry import register_workflow
from maxwell.workflows.base import (
    BaseWorkflow,
    WorkflowInputs,
    WorkflowOutputs,
    WorkflowResult,
    WorkflowStatus,
)

logger = logging.getLogger(__name__)


# Workflow-specific schemas (defined in same file as workflow)
# -------------------------------------------------------------


@dataclass(frozen=True)
class DeepResearchInputs(WorkflowInputs):
    """Input schema for deep research workflow."""

    research_question: str
    data_sources: str = "chat,web"  # chat, web, filesystem
    max_iterations: int = 3
    queries_per_iteration: int = 5
    use_semantic: bool = True  # Use semantic search for chat (vs BM25)
    mcp_tools: Optional[str] = (
        None  # Comma-separated list of allowed MCP tools (None = default set)
    )

    # Depth control parameters
    results_per_query: int = 10  # How many results each MCP tool call returns
    synthesis_max_findings: int = 50  # How many findings to include in final synthesis
    synthesis_chars_per_finding: int = 2000  # Character limit per finding in synthesis
    synthesis_style: str = "technical"  # technical, executive, detailed, concise


@dataclass(frozen=True)
class DeepResearchOutputs(WorkflowOutputs):
    """Output schema for deep research workflow."""

    report: str
    findings_summary: str
    findings: List[Dict[str, str]]
    data_sources: List[str]
    queries_executed: int
    iterations_completed: int
    react_audit_log: List[Dict[str, Any]]  # Audit trail of ReAct loop


@register_workflow
class DeepResearchWorkflow(BaseWorkflow):
    """Deep research workflow using existing Maxwell workflows."""

    workflow_id: str = "deep-research"
    name: str = "Deep Research"
    description: str = "Comprehensive research across chat and filesystem data"
    version: str = "1.0"
    category: str = "research"
    tags: set = {"research", "search", "synthesis"}

    # Typed schemas
    InputSchema = DeepResearchInputs
    OutputSchema = DeepResearchOutputs

    # MCP Tool Registry - populated dynamically from Claude's configuration
    # Maps short names to {mcp_name, params} for parameter translation
    MCP_TOOL_REGISTRY: Dict[str, Dict[str, Any]] = {}

    @classmethod
    def _resolve_allowed_mcps(
        cls, requested: Optional[str], discovered: Dict[str, Any]
    ) -> List[str]:
        """Deterministically resolve which MCPs are allowed for this research session.

        Args:
            requested: Comma-separated MCP tool names from --mcp_tools parameter (None = use defaults)
            discovered: Dict of discovered MCPs from settings.local.json

        Returns:
            Sorted list of allowed MCP tool names (deterministic ordering)

        Raises:
            ValueError: If requested contains 'list' (caller should handle and print available MCPs)

        Resolution logic:
        1. If --mcp_tools='list': raise ValueError with list of available MCPs
        2. If --mcp_tools specified: use ONLY those tools (must exist in discovered)
        3. If --mcp_tools not specified: use all discovered tools matching research patterns
        4. Always validate against discovered tools from settings.local.json
        5. Always return sorted list for deterministic behavior

        """
        discovered_names = set(discovered.keys())

        if requested:
            # Special case: user wants to see available MCPs
            if requested.strip().lower() == "list":
                available_list = "\n".join([f"  - {name}" for name in sorted(discovered_names)])
                raise ValueError(
                    f"Available MCP tools from ~/.claude/settings.local.json:\n{available_list}\n\n"
                    f"Use --mcp_tools with comma-separated tool names, or omit for auto-detect."
                )

            # User explicitly requested specific tools
            requested_list = [t.strip() for t in requested.split(",")]

            # Validate: all requested tools must be in discovered (from settings.local.json)
            invalid = [t for t in requested_list if t not in discovered_names]
            if invalid:
                available_list = "\n".join([f"  - {name}" for name in sorted(discovered_names)])
                raise ValueError(
                    f"Requested MCP tools not available: {invalid}\n\n"
                    f"Available MCPs from ~/.claude/settings.local.json:\n{available_list}"
                )

            # Return requested tools in deterministic order
            return sorted(requested_list)

        else:
            # No specific tools requested - use intelligent defaults
            # Match tools that look like research/search tools (chat, web, search keywords)
            research_patterns = ["chat", "search", "web"]

            default_tools = [
                name
                for name in discovered_names
                if any(pattern in name.lower() for pattern in research_patterns)
            ]

            # If no research-like tools found, use all discovered tools
            if not default_tools:
                logger.warning(
                    f"No research-pattern MCPs found, using all discovered: {sorted(discovered_names)}"
                )
                default_tools = list(discovered_names)

            # Return in deterministic sorted order
            return sorted(default_tools)

    @classmethod
    def _initialize_mcp_registry(cls) -> None:
        """Initialize MCP registry by dynamically discovering workflows.

        Uses the workflow registry to discover Maxwell workflows and introspect
        their CLI parameters. No hardcoded parameter mappings needed!
        """
        if cls.MCP_TOOL_REGISTRY:
            # Already initialized
            return

        from maxwell.registry import get_workflow_registry

        # Get all registered workflows
        registry = get_workflow_registry().get_all_workflows()

        # Discover MCPs from Claude configuration
        discovered_mcps = cls.discover_available_mcps()

        # Register each discovered MCP
        for short_name, mcp_name in discovered_mcps.items():
            tool_info = {"mcp_name": mcp_name}

            # For Maxwell workflows, introspect CLI parameters
            if mcp_name.startswith("mcp__maxwell__"):
                workflow_id = mcp_name.replace("mcp__maxwell__maxwell_", "").replace("_", "-")

                # Try to get workflow from registry
                if workflow_id in registry:
                    workflow_class = registry[workflow_id]

                    # Get CLI parameters from workflow
                    try:
                        instance = workflow_class()
                        cli_params = instance.get_cli_parameters()

                        # Store parameter schema for LLM to use
                        tool_info["parameters"] = cli_params
                        tool_info["description"] = getattr(workflow_class, "description", "")

                    except Exception as e:
                        logger.warning(f"Could not introspect workflow {workflow_id}: {e}")

            cls.MCP_TOOL_REGISTRY[short_name] = tool_info
            logger.debug(f"Registered MCP: {short_name} -> {mcp_name}")

        logger.info(
            f"Initialized MCP registry with {len(cls.MCP_TOOL_REGISTRY)} tools from workflow registry"
        )

    def get_cli_parameters(self) -> List[Dict[str, Any]]:
        """Define CLI parameters."""
        return [
            {
                "name": "research_question",
                "type": str,
                "required": True,
                "help": "Research question to investigate",
            },
            {
                "name": "data_sources",
                "type": str,
                "required": False,
                "default": "chat,web",
                "help": "Data sources: chat, web, filesystem (comma-separated)",
            },
            {
                "name": "use_semantic",
                "type": bool,
                "required": False,
                "default": True,
                "help": "Use semantic search for chat (vs BM25 keyword search)",
            },
            {
                "name": "max_iterations",
                "type": int,
                "required": False,
                "default": 3,
                "help": "Maximum research iterations",
            },
            {
                "name": "queries_per_iteration",
                "type": int,
                "required": False,
                "default": 5,
                "help": "Queries to generate per iteration",
            },
            {
                "name": "mcp_tools",
                "type": str,
                "required": False,
                "default": None,
                "help": "Comma-separated list of allowed MCP tools. Discovers from ~/.claude/settings.local.json. Use 'list' to see available MCPs. Default: auto-detect research tools (chat, search, web).",
            },
            # Depth control parameters
            {
                "name": "results_per_query",
                "type": int,
                "required": False,
                "default": 10,
                "help": "Number of results each MCP tool call returns (e.g., search limit)",
            },
            {
                "name": "synthesis_max_findings",
                "type": int,
                "required": False,
                "default": 50,
                "help": "Maximum findings to include in final synthesis (more = deeper but slower)",
            },
            {
                "name": "synthesis_chars_per_finding",
                "type": int,
                "required": False,
                "default": 2000,
                "help": "Character limit per finding in synthesis (more = more detail)",
            },
            {
                "name": "synthesis_style",
                "type": str,
                "required": False,
                "default": "technical",
                "help": "Report style: technical, executive, detailed, or concise",
            },
        ]

    def get_required_inputs(self) -> List[str]:
        """Get required inputs."""
        return ["research_question"]

    def get_produced_outputs(self) -> List[str]:
        """Get produced outputs."""
        return [
            "report",
            "findings_summary",
            "findings",
            "data_sources",
            "queries_executed",
            "iterations_completed",
        ]

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        """Execute deep research using ReAct (Reason + Act) pattern."""
        try:
            # Initialize MCP registry from Claude configuration
            self._initialize_mcp_registry()

            # Parse inputs with type safety
            inputs: DeepResearchInputs = self.parse_inputs(context)  # type: ignore[assignment]

            research_question = inputs.research_question
            data_sources = [ds.strip() for ds in inputs.data_sources.lower().split(",")]
            max_iterations = inputs.max_iterations

            # Extract depth control parameters
            results_per_query = inputs.results_per_query
            synthesis_max_findings = inputs.synthesis_max_findings
            synthesis_chars_per_finding = inputs.synthesis_chars_per_finding
            synthesis_style = inputs.synthesis_style

            # Deterministically resolve allowed MCPs with guardrails
            allowed_mcps = self._resolve_allowed_mcps(inputs.mcp_tools, self.MCP_TOOL_REGISTRY)

            logger.info(f"Starting ReAct research: {research_question}")
            logger.info(f"Data sources: {data_sources}")
            logger.info(f"Allowed MCP tools: {allowed_mcps}")
            logger.info(
                f"Depth config: results_per_query={results_per_query}, "
                f"synthesis_max_findings={synthesis_max_findings}, "
                f"synthesis_chars_per_finding={synthesis_chars_per_finding}, "
                f"style={synthesis_style}"
            )

            # Get LLM client
            llm_client = get_lm()

            # ReAct loop
            findings, iterations_completed, audit_log = self._react_loop(
                research_question=research_question,
                allowed_mcps=allowed_mcps,
                project_root=project_root,
                llm_client=llm_client,
                max_iterations=max_iterations,
                results_per_query=results_per_query,
            )

            # Generate final report with depth parameters
            report = self._synthesize_report(
                research_question=research_question,
                findings=findings,
                llm_client=llm_client,
                max_findings=synthesis_max_findings,
                chars_per_finding=synthesis_chars_per_finding,
                style=synthesis_style,
            )
            findings_summary = self._summarize_findings(findings)

            # Save audit log to disk
            self._save_audit_log(audit_log, project_root)

            # Create typed outputs
            outputs = DeepResearchOutputs(
                report=report,
                findings_summary=findings_summary,
                findings=findings,
                data_sources=data_sources,
                queries_executed=len(findings),
                iterations_completed=iterations_completed,
                react_audit_log=audit_log,
            )

            # Use helper to create result with metrics
            self.metrics.files_processed = len(findings)
            self.metrics.custom_metrics = {
                "queries_executed": len(findings),
                "findings_found": len(findings),
                "react_iterations": iterations_completed,
            }

            return self.create_result(outputs, WorkflowStatus.COMPLETED)

        except Exception as e:
            logger.error(f"Deep research failed: {e}", exc_info=True)
            self.metrics.errors_encountered = 1
            return self.create_result(
                outputs=None,
                status=WorkflowStatus.FAILED,
                error_message=f"Deep research failed: {str(e)}",
            )

    def _react_loop(
        self,
        research_question: str,
        allowed_mcps: List[str],
        project_root: Path,
        llm_client,
        max_iterations: int,
        results_per_query: int = 10,
    ) -> tuple[List[Dict[str, str]], int, List[Dict[str, Any]]]:
        """Execute ReAct loop: Reason + Act pattern for research.

        Args:
            research_question: The question to research
            allowed_mcps: List of MCP tools that can be used
            project_root: Project root directory
            llm_client: LLM client for reasoning
            max_iterations: Maximum number of thought-action-observation cycles
            results_per_query: Number of results to request per query

        Returns:
            Tuple of (findings, iterations_completed, audit_log)

        """
        # Build tool descriptions for LLM
        tool_descriptions = self._build_tool_descriptions(allowed_mcps)

        # ReAct conversation history
        conversation_history = []
        findings = []
        audit_log = []  # Track every step for debugging

        # Initial prompt
        initial_prompt = f"""You are a research assistant using the ReAct (Reasoning + Acting) pattern.

Research Question: {research_question}

Available Tools:
{tool_descriptions}

Instructions:
1. Think step-by-step about what information you need
2. Choose ONE tool to call and specify parameters
3. For search tools, use limit={results_per_query} to control result depth
4. Observe the results
5. Repeat until you have enough information
6. Provide a Final Answer when done

Format your response EXACTLY as:
Thought: [your reasoning about what to do next]
Action: [tool name from available tools]
Action Input: {{"param1": "value1", "param2": "value2"}}

OR if you have enough information:
Thought: [your reasoning]
Final Answer: [comprehensive answer to the research question]

Begin!"""

        conversation_history.append({"role": "user", "content": initial_prompt})

        for iteration in range(max_iterations):
            logger.info(f"ReAct iteration {iteration + 1}/{max_iterations}")

            # Get LLM response
            # Build conversation into single prompt
            conversation_prompt = "\n\n".join(
                [f"{msg['role'].upper()}: {msg['content']}" for msg in conversation_history]
            )
            response_text = llm_client.generate(conversation_prompt)

            logger.info(f"LLM Response:\n{response_text}")

            # Add to history
            conversation_history.append({"role": "assistant", "content": response_text})

            # Extract thought from response
            thought = ""
            for line in response_text.split("\n"):
                if line.startswith("Thought:"):
                    thought = line.replace("Thought:", "").strip()
                    break

            # Check if Final Answer
            if "Final Answer:" in response_text:
                logger.info("ReAct loop completed - Final Answer provided")
                final_answer = response_text.split("Final Answer:", 1)[1].strip()
                audit_log.append(
                    {
                        "iteration": iteration + 1,
                        "step": "final_answer",
                        "thought": thought,
                        "final_answer": final_answer,
                    }
                )
                return findings, iteration + 1, audit_log

            # Parse action
            action_result = self._parse_react_action(response_text)
            if not action_result:
                logger.warning("Failed to parse action from LLM response, prompting for retry")
                audit_log.append(
                    {
                        "iteration": iteration + 1,
                        "step": "parse_error",
                        "response": response_text,
                        "error": "Failed to parse action",
                    }
                )
                conversation_history.append(
                    {
                        "role": "user",
                        "content": "Please provide a valid Action and Action Input in the correct format.",
                    }
                )
                continue

            tool_name, tool_params = action_result

            # Validate tool is allowed
            if tool_name not in allowed_mcps:
                observation = f"Error: Tool '{tool_name}' is not in allowed tools: {allowed_mcps}"
                audit_log.append(
                    {
                        "iteration": iteration + 1,
                        "step": "validation_error",
                        "thought": thought,
                        "action": tool_name,
                        "params": tool_params,
                        "error": observation,
                    }
                )
                conversation_history.append(
                    {"role": "user", "content": f"Observation: {observation}"}
                )
                continue

            # Execute tool
            logger.info(f"Executing tool: {tool_name} with params: {tool_params}")
            tool_result = self._call_mcp_tool(tool_name, project_root=project_root, **tool_params)

            if tool_result:
                # Extract findings
                num_findings_before = len(findings)
                if "results" in tool_result:
                    for result in tool_result["results"]:
                        if isinstance(result, dict):
                            findings.append(
                                {
                                    "content": result.get("user_text", "")
                                    + "\n"
                                    + result.get("assistant_text", ""),
                                    "source": result.get("turn_id", "unknown"),
                                    "tool": tool_name,
                                    "data_source": "chat",
                                }
                            )
                num_new_findings = len(findings) - num_findings_before

                # Create observation
                observation = (
                    f"Tool returned {num_new_findings} findings. Sample: {str(tool_result)[:500]}"
                )
            else:
                observation = f"Tool '{tool_name}' returned no results"

            logger.info(f"Observation: {observation}")

            # Log this complete step
            audit_log.append(
                {
                    "iteration": iteration + 1,
                    "step": "action",
                    "thought": thought,
                    "action": tool_name,
                    "params": tool_params,
                    "observation": observation,
                    "tool_result": tool_result,
                    "findings_count": len(findings),
                }
            )

            # Add observation to conversation
            conversation_history.append({"role": "user", "content": f"Observation: {observation}"})

        logger.info(f"ReAct loop ended after {max_iterations} iterations (max reached)")
        return findings, max_iterations, audit_log

    def _save_audit_log(self, audit_log: List[Dict[str, Any]], project_root: Path) -> None:
        """Save audit log to .maxwell/logs/ directory."""
        import datetime
        import json

        # Create logs directory
        log_dir = project_root / ".maxwell" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)

        # Generate filename with timestamp
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = log_dir / f"deep_research_audit_{timestamp}.json"

        # Write audit log
        with open(log_file, "w") as f:
            json.dump(
                {
                    "workflow": "deep-research",
                    "timestamp": datetime.datetime.now().isoformat(),
                    "audit_log": audit_log,
                },
                f,
                indent=2,
                default=str,
            )

        logger.info(f"Saved audit log to {log_file}")

    def _build_tool_descriptions(self, allowed_mcps: List[str]) -> str:
        """Build tool descriptions for LLM prompt using introspected workflow parameters."""
        descriptions = []
        for tool_name in allowed_mcps:
            if tool_name in self.MCP_TOOL_REGISTRY:
                tool_config = self.MCP_TOOL_REGISTRY[tool_name]
                description = tool_config.get("description", "")
                cli_params = tool_config.get("parameters", [])

                # Build parameter description from CLI parameters
                param_list = []
                for param in cli_params:
                    param_name = param.get("name")
                    param_type = param.get("type", str).__name__
                    param_help = param.get("help", "")
                    required = param.get("required", False)
                    req_marker = " (required)" if required else " (optional)"
                    param_list.append(f"  - {param_name} ({param_type}){req_marker}: {param_help}")

                param_desc = "\n".join(param_list) if param_list else "  No parameters"

                descriptions.append(f"- {tool_name}: {description}\n{param_desc}")

        return "\n\n".join(descriptions)

    def _parse_react_action(self, response_text: str) -> Optional[tuple[str, Dict[str, Any]]]:
        """Parse Action and Action Input from LLM response.

        Expected format:
        Action: tool-name
        Action Input: {"param": "value"}

        Returns:
            Tuple of (tool_name, parameters_dict) or None if parsing fails

        """
        try:
            lines = response_text.split("\n")
            action_line = None
            input_line = None

            for line in lines:
                if line.startswith("Action:"):
                    action_line = line.replace("Action:", "").strip()
                elif line.startswith("Action Input:"):
                    input_line = line.replace("Action Input:", "").strip()

            if not action_line:
                return None

            # Parse parameters (JSON format)
            params = {}
            if input_line:
                # Try to parse as JSON
                params = json.loads(input_line)

            return (action_line, params)

        except Exception as e:
            logger.error(f"Failed to parse ReAct action: {e}")
            return None

    def _generate_queries(
        self, research_question: str, data_sources: List[str], llm_client, limit: int
    ) -> List[str]:
        """Generate initial search queries."""
        source_text = ", ".join(data_sources)
        prompt = f"""Generate {limit} diverse search queries to research this question:

Question: {research_question}
Data sources: {source_text}

Generate search queries that cover different aspects. Return as a JSON list:
["query 1", "query 2", "query 3", ...]
"""

        try:
            response = llm_client.generate(prompt)
            import json

            queries = json.loads(response)
            return queries[:limit] if isinstance(queries, list) else [research_question]
        except Exception as e:
            logger.error(f"Query generation failed: {e}")
            return [research_question]

    def _generate_followup_queries(
        self, research_question: str, findings: List[Dict[str, str]], llm_client, limit: int
    ) -> List[str]:
        """Generate follow-up queries based on findings."""
        findings_text = "\n".join([f.get("content", "")[:200] for f in findings[:3]])

        prompt = f"""Based on these findings, generate {limit} follow-up search queries:

Original question: {research_question}

Current findings:
{findings_text}

Generate follow-up queries to explore gaps or interesting leads. Return as JSON list:
["query 1", "query 2", ...]
"""

        try:
            response = llm_client.generate(prompt)
            import json

            queries = json.loads(response)
            return queries[:limit] if isinstance(queries, list) else []
        except Exception as e:
            logger.error(f"Follow-up query generation failed: {e}")
            return []

    @classmethod
    def discover_available_mcps(cls) -> Dict[str, str]:
        """Discover available MCP tools from Claude's configuration.

        Reads ~/.claude/settings.local.json to find MCP tools that are allowed.
        Returns a mapping of short names to full MCP names.

        Returns:
            Dict mapping short names to MCP function names
            e.g., {"chat-semantic-search": "mcp__maxwell__maxwell_chat_semantic_search"}

        """
        import json
        from pathlib import Path

        claude_settings = Path.home() / ".claude" / "settings.local.json"
        if not claude_settings.exists():
            logger.warning(f"Claude settings not found at {claude_settings}")
            return {}

        try:
            with open(claude_settings) as f:
                settings = json.load(f)

            # Extract MCP tools from permissions
            allowed_mcps = settings.get("permissions", {}).get("allow", [])

            # Filter to only MCP function calls (start with mcp__)
            mcp_tools = {}
            for perm in allowed_mcps:
                if isinstance(perm, str) and perm.startswith("mcp__"):
                    # Extract short name from full MCP name
                    # e.g., mcp__maxwell__maxwell_chat_semantic_search -> chat-semantic-search
                    if perm.startswith("mcp__maxwell__maxwell_"):
                        short_name = perm.replace("mcp__maxwell__maxwell_", "").replace("_", "-")
                    elif perm.startswith("mcp__"):
                        # Generic MCP: mcp__web-search-prime__webSearchPrime -> web-search
                        # Use the server name (part 1) as the short name
                        parts = perm.split("__")
                        if len(parts) >= 2:
                            short_name = parts[1].replace("_", "-")
                        else:
                            short_name = perm.replace("mcp__", "").replace("_", "-")
                    else:
                        continue

                    mcp_tools[short_name] = perm
                    logger.debug(f"Discovered MCP: {short_name} -> {perm}")

            logger.info(f"Discovered {len(mcp_tools)} MCP tools from Claude configuration")
            return mcp_tools

        except Exception as e:
            logger.error(f"Failed to discover MCPs from Claude config: {e}")
            return {}

    async def _call_mcp_tool_async(self, tool_name: str, **kwargs) -> Optional[Dict[str, Any]]:
        """Call an MCP tool asynchronously.

        Supports both Maxwell workflows and external MCP servers.

        Args:
            tool_name: Short name of MCP tool (e.g., "web-search-prime")
            **kwargs: Arguments to pass to the tool

        Returns:
            Tool result dict or None on failure

        """
        try:
            # Check if tool is registered
            if tool_name not in self.MCP_TOOL_REGISTRY:
                logger.warning(f"MCP tool {tool_name} not in registry")
                return None

            tool_config = self.MCP_TOOL_REGISTRY[tool_name]
            mcp_name = tool_config["mcp_name"]

            # Pass parameters directly - workflow will validate them
            # Remove project_root from params since it's passed separately to execute_workflow
            mcp_params = {k: v for k, v in kwargs.items() if k != "project_root"}

            logger.debug(f"Calling MCP tool: {mcp_name} with params: {mcp_params}")

            # For Maxwell MCPs, use workflow execution (synchronous)
            if mcp_name.startswith("mcp__maxwell__"):
                workflow_id = mcp_name.replace("mcp__maxwell__maxwell_", "").replace("_", "-")

                from maxwell.api import execute_workflow

                result = execute_workflow(
                    workflow_id, kwargs.get("project_root", Path.cwd()), mcp_params
                )

                if result.status == WorkflowStatus.COMPLETED:
                    return result.artifacts
                else:
                    logger.error(f"Workflow {workflow_id} failed: {result.error_message}")
                    return None

            # For external MCPs, use MCP client
            else:
                from mcp import ClientSession, StdioServerParameters
                from mcp.client.stdio import stdio_client

                # Parse MCP server info from mcp_name
                # Format: mcp__server-name__function_name
                parts = mcp_name.split("__")
                if len(parts) < 3:
                    logger.error(f"Invalid MCP name format: {mcp_name}")
                    return None

                server_name = parts[1]
                function_name = parts[2]

                # Get MCP server command from environment or config
                # For now, assume server is already running and accessible via stdio
                server_params = StdioServerParameters(
                    command=server_name,
                    args=[],
                    env=None,
                )

                async with stdio_client(server_params) as (read, write):
                    async with ClientSession(read, write) as session:
                        await session.initialize()

                        # Call the tool
                        result = await session.call_tool(function_name, arguments=mcp_params)

                        # Extract content from result
                        if result.content:
                            # Convert MCP result to dict format
                            content_dict = {}
                            for item in result.content:
                                if hasattr(item, "text"):
                                    content_dict["text"] = item.text
                                elif hasattr(item, "data"):
                                    content_dict.update(item.data)

                            return content_dict

                return None

        except Exception as e:
            logger.error(f"MCP tool call failed for {tool_name}: {e}", exc_info=True)
            return None

    def _call_mcp_tool(self, tool_name: str, **kwargs) -> Optional[Dict[str, Any]]:
        """Synchronous wrapper for MCP tool calls.

        Args:
            tool_name: Short name of MCP tool
            **kwargs: Arguments to pass to the tool

        Returns:
            Tool result dict or None on failure

        """
        import asyncio

        try:
            # Run async call in event loop
            return asyncio.run(self._call_mcp_tool_async(tool_name, **kwargs))
        except Exception as e:
            logger.error(f"MCP tool call failed for {tool_name}: {e}")
            return None

    @classmethod
    def register_mcp_tool(
        cls, short_name: str, mcp_name: str, param_mapping: Dict[str, str]
    ) -> None:
        """Register a new MCP tool for use in deep research.

        Args:
            short_name: Short name for the tool (e.g., "web-search")
            mcp_name: Full MCP function name (e.g., "mcp__web-search-prime__webSearchPrime")
            param_mapping: Dict mapping local param names to MCP param names
                          e.g., {"query": "search_query", "limit": "count"}

        Example:
            DeepResearchWorkflow.register_mcp_tool(
                "pdf-extract",
                "mcp__pdf-processor__extract_pdf_text",
                {"file_path": "pdf_path"}
            )

        """
        cls.MCP_TOOL_REGISTRY[short_name] = {
            "mcp_name": mcp_name,
            "params": param_mapping,
        }
        logger.info(f"Registered MCP tool: {short_name} -> {mcp_name}")

    def _search_and_extract(
        self,
        query: str,
        data_sources: List[str],
        project_root: Path,
        allowed_mcps: List[str],
        use_semantic: bool,
    ) -> List[Dict[str, str]]:
        """Execute search across data sources using MCP tools.

        Args:
            query: Search query
            data_sources: List of data sources to search (chat, web, filesystem)
            project_root: Project root directory
            allowed_mcps: List of allowed MCP tool names
            use_semantic: Use semantic search for chat (vs BM25)

        Returns:
            List of findings as dicts with content, source, query, data_source

        """
        all_results = []

        # Search each data source
        for source in data_sources:
            try:
                if source == "chat":
                    # Determine which chat search MCP to use
                    tool_name = "chat-semantic-search" if use_semantic else "chat-bm25-search"

                    if tool_name in allowed_mcps:
                        # Call MCP tool
                        mcp_result = self._call_mcp_tool(
                            tool_name,
                            query=query,
                            limit=3,
                            format="compact",
                            project_root=project_root,
                        )

                        if mcp_result and "results" in mcp_result:
                            chat_results = mcp_result["results"]
                            for chat_result in chat_results:
                                if isinstance(chat_result, dict):
                                    user_text = chat_result.get("user_text", "")
                                    assistant_text = chat_result.get("assistant_text", "")
                                    content = f"User: {user_text}\nAssistant: {assistant_text}"

                                    all_results.append(
                                        {
                                            "content": content,
                                            "source": f"chat:{chat_result.get('turn_id', 'unknown')}",
                                            "query": query,
                                            "data_source": "chat",
                                        }
                                    )

                elif source == "web":
                    # Use web search MCP
                    if "web-search" in allowed_mcps:
                        logger.info("Web search MCP integration pending")
                        # TODO: Implement web search via mcp__web-search-prime__webSearchPrime

                elif source == "filesystem":
                    # Filesystem search via workflow (not MCP-based)
                    result = execute_workflow("fs-search", project_root, {"query": query})
                    if result.status == WorkflowStatus.COMPLETED and result.artifacts:
                        fs_results = result.artifacts.get("results", [])
                        for fs_result in fs_results[:3]:
                            content = ""
                            if isinstance(fs_result, dict):
                                content = fs_result.get("content", str(fs_result))

                            if content:
                                all_results.append(
                                    {
                                        "content": content,
                                        "source": f"filesystem:{fs_result.get('path', 'unknown')}",
                                        "query": query,
                                        "data_source": "filesystem",
                                    }
                                )

            except Exception as e:
                logger.error(f"Search failed for {source}: {e}")
                continue

        return all_results

    def _synthesize_report(
        self,
        research_question: str,
        findings: List[Dict[str, str]],
        llm_client,
        max_findings: int = 50,
        chars_per_finding: int = 2000,
        style: str = "technical",
    ) -> str:
        """Generate final research report.

        Args:
            research_question: The research question
            findings: List of findings to synthesize
            llm_client: LLM client for synthesis
            max_findings: Maximum findings to include in synthesis
            chars_per_finding: Character limit per finding
            style: Report style (technical, executive, detailed, concise)

        """
        # Build findings text
        findings_text = "\n\n".join(
            [
                f"Finding #{i+1} (Source: {f['source']}):\n{f['content'][:chars_per_finding]}"
                for i, f in enumerate(findings[:max_findings])
            ]
        )

        # Style-specific prompt templates
        style_prompts = {
            "technical": """You are analyzing {total} research findings to answer a detailed technical question.

Research Question: {question}

Research Findings ({total} total, showing top {shown}):
{findings}

Create a comprehensive technical report with:

1. Executive Summary
   - Provide 2-3 paragraphs covering the key technical context

2. Key Findings
   - List ALL important technical details, architectural decisions, problems discussed, and solutions
   - Include specific quotes, configuration issues, and implementation details
   - Don't generalize - be specific about what was actually discussed

3. Detailed Analysis
   - Technical architecture and design patterns
   - Specific problems encountered and their solutions
   - Configuration and integration details
   - Development workflow and tooling
   - Any conflicts or issues mentioned

4. Conclusion
   - Synthesize the technical understanding
   - Note any unresolved issues or ongoing concerns

IMPORTANT: This is technical documentation - include specific details, code mentions, configuration issues, and actual problems discussed. Don't write generic summaries.""",
            "executive": """You are synthesizing {total} research findings into an executive summary.

Research Question: {question}

Research Findings ({total} total, showing top {shown}):
{findings}

Create a concise executive report with:

1. Executive Summary (3-4 sentences)
   - What was discussed and why it matters

2. Key Takeaways (bullet points)
   - 5-7 most important points

3. Strategic Implications
   - What this means for the project/organization

4. Recommendations
   - Next steps or decisions needed

Focus on high-level insights and business impact, not technical minutiae.""",
            "detailed": """You are conducting a deep analysis of {total} research findings.

Research Question: {question}

Research Findings ({total} total, showing top {shown}):
{findings}

Create an exhaustive detailed report with:

1. Overview
   - Comprehensive context and background

2. Complete Findings Catalog
   - Every significant detail, organized by theme
   - Include ALL quotes, code snippets, configuration details
   - Preserve technical accuracy and specificity

3. Thematic Analysis
   - Group findings by topic/theme
   - Deep dive into each area with supporting evidence

4. Cross-References and Connections
   - How different findings relate to each other
   - Patterns and contradictions

5. Comprehensive Conclusion
   - Synthesize everything
   - Unresolved questions and gaps

IMPORTANT: Be thorough and exhaustive. Include everything significant - this is for deep technical understanding.""",
            "concise": """You are summarizing {total} research findings briefly.

Research Question: {question}

Research Findings ({total} total, showing top {shown}):
{findings}

Create a brief summary:

1. Answer (2-3 sentences)
   - Direct answer to the research question

2. Supporting Evidence (3-5 bullet points)
   - Key facts supporting the answer

3. Notable Details
   - Any important specifics worth mentioning

Be succinct and focused. Only include the most essential information.""",
        }

        # Get prompt template for style
        prompt_template = style_prompts.get(style, style_prompts["technical"])

        prompt = prompt_template.format(
            total=len(findings),
            question=research_question,
            shown=max_findings,
            findings=findings_text,
        )

        try:
            response = llm_client.generate(prompt)
            return response
        except Exception as e:
            logger.error(f"Report synthesis failed: {e}")
            return f"Research completed with {len(findings)} findings. Report synthesis failed."

    def _summarize_findings(self, findings: List[Dict[str, str]]) -> str:
        """Create summary of findings."""
        if not findings:
            return "No findings found."

        source_counts = {}
        for f in findings:
            source = f["data_source"]
            source_counts[source] = source_counts.get(source, 0) + 1

        summary = (
            f"Found {len(findings)} total findings across {len(source_counts)} data sources:\n"
        )
        for source, count in source_counts.items():
            summary += f"- {source}: {count} findings\n"

        return summary
