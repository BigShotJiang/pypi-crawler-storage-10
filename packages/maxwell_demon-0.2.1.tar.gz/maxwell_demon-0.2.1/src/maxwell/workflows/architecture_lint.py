"""Architecture Linter: Validates Maxwell's plugin architecture rules.

Enforces:
1. Workflows can import from core (parent)
2. Workflows can import from same workflow (internal)
3. Workflows CANNOT import SIBLINGS (other workflows)
4. Workflows CANNOT import CHILDREN (sub-workflows)
5. Workflows execute each other via registry (not imports)
6. Core CANNOT import from workflows (except dynamic loading)

Uses ast_import_graph.py for proper graph building and module resolution.
This is itself a workflow that validates the architecture!
"""

from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Tuple

from maxwell.ast.import_graph import build_import_graph
from maxwell.registry import register_workflow
from maxwell.workflows.base import BaseWorkflow, WorkflowResult, WorkflowStatus

__all__ = ["ArchitectureLintWorkflow", "architecture_lint_workflow", "ArchitectureViolation"]


class ArchitectureViolation:
    """Represents a violation of architecture rules."""

    def __init__(
        self,
        file_path: str,
        line_number: int,
        violation_type: str,
        description: str,
        suggestion: str,
    ):
        self.file_path = file_path
        self.line_number = line_number
        self.violation_type = violation_type
        self.description = description
        self.suggestion = suggestion

    def __repr__(self):
        return f"{self.file_path}:{self.line_number} [{self.violation_type}] " f"{self.description}"


class ArchitectureLinter:
    """Builds and analyzes import graph for architecture validation."""

    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.src_root = project_root / "src" / "maxwell"

        # Use proper import graph from ast_import_graph workflow
        self.import_graph = build_import_graph(project_root, include_external=False)

        # Violations
        self.violations: List[ArchitectureViolation] = []

    def is_core_file(self, file_path: Path) -> bool:
        """Check if file is in maxwell core (not workflows)."""
        try:
            rel_path = file_path.relative_to(self.src_root)
            return not str(rel_path).startswith("workflows")
        except ValueError:
            return False

    def is_workflow_file(self, file_path: Path) -> bool:
        """Check if file is in workflows."""
        try:
            rel_path = file_path.relative_to(self.src_root)
            return str(rel_path).startswith("workflows")
        except ValueError:
            return False

    def get_workflow_name(self, file_path: Path) -> str:
        """Extract workflow name from file path."""
        try:
            rel_path = file_path.relative_to(self.src_root / "workflows")
            parts = rel_path.parts
            return parts[0] if parts else "unknown"
        except ValueError:
            return "unknown"

    def parse_imports(self, file_path: Path) -> List[Tuple[str, int]]:
        """Extract all imports from a Python file using AST."""
        imports = []

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                tree = ast.parse(f.read(), filename=str(file_path))

            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        imports.append((alias.name, node.lineno))

                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        imports.append((node.module, node.lineno))

        except Exception as e:
            print(f"Warning: Could not parse {file_path}: {e}")

        return imports

    # Graph building now handled by ast_import_graph workflow

    def check_workflow_to_workflow_imports(self):
        """Rule: Workflows CANNOT import SIBLINGS or CHILDREN (only parent and self)."""
        print("\nChecking workflow sibling/child imports...")

        for file_path in self.import_graph.nodes:
            if not self.is_workflow_file(file_path):
                continue

            source_workflow = self.get_workflow_name(file_path)
            imports = self.import_graph.get_imports_for_file(file_path)

            for edge in imports:
                module = edge.target_module

                # Check if importing from maxwell.workflows
                if module.startswith("maxwell.workflows"):
                    # Extract target workflow
                    parts = module.split(".")
                    if len(parts) >= 3:
                        target_workflow = parts[2]

                        # ✅ Allow imports from SAME workflow (internal)
                        if target_workflow == source_workflow:
                            continue

                        # ✅ Allow imports from base (public API for all workflows)
                        if target_workflow == "base":
                            continue

                        # ✅ Allow imports from _shared (private utilities)
                        if target_workflow.startswith("_"):
                            continue

                        # ❌ Violation: importing from SIBLING workflow
                        self.violations.append(
                            ArchitectureViolation(
                                file_path=str(file_path),
                                line_number=edge.line_number,
                                violation_type="SIBLING_WORKFLOW_IMPORT",
                                description=f"Workflow '{source_workflow}' imports from sibling '{target_workflow}'",
                                suggestion=f"Use execute_workflow('{target_workflow}', ...) instead of direct import",
                            )
                        )

    def check_core_to_workflow_imports(self):
        """Rule: Core CANNOT import from workflows (except dynamic loading)."""
        print("Checking core-to-workflow imports...")

        # Whitelist: files allowed to dynamically import from workflows
        whitelist = {"lm_pool.py", "registry.py", "cli.py"}

        for file_path in self.import_graph.nodes:
            if not self.is_core_file(file_path):
                continue

            # Check if whitelisted
            if file_path.name in whitelist:
                continue

            imports = self.import_graph.get_imports_for_file(file_path)

            for edge in imports:
                if edge.target_module.startswith("maxwell.workflows"):
                    # ✅ Allow imports from base (public API for workflow plugins)
                    if edge.target_module.startswith("maxwell.workflows.base"):
                        continue

                    self.violations.append(
                        ArchitectureViolation(
                            file_path=str(file_path),
                            line_number=edge.line_number,
                            violation_type="CORE_TO_WORKFLOW_IMPORT",
                            description=f"Core file imports from workflows: {edge.target_module}",
                            suggestion="Core should not import from workflows (only registry/lm_pool can dynamically load)",
                        )
                    )

    def check_circular_dependencies(self):
        """Detect circular import chains using import graph."""
        print("Checking for circular dependencies...")

        cycles = self.import_graph.find_cycles()

        for cycle in cycles:
            # Format cycle as file1 → file2 → ... → file1
            cycle_str = " → ".join([str(f.relative_to(self.project_root)) for f in cycle])

            self.violations.append(
                ArchitectureViolation(
                    file_path=cycle_str,
                    line_number=0,
                    violation_type="CIRCULAR_DEPENDENCY",
                    description=f"Circular import chain detected ({len(cycle)} files)",
                    suggestion="Refactor to break the cycle using dependency inversion",
                )
            )

    def validate(self):
        """Run all architecture validation checks."""
        # Graph already built in __init__
        self.check_workflow_to_workflow_imports()
        self.check_core_to_workflow_imports()
        self.check_circular_dependencies()

        return self.violations


def architecture_lint_workflow(project_root: str = ".") -> dict:
    """Run architecture linting workflow.

    Args:
        project_root: Root directory of maxwell project

    Returns:
        Dict with:
            - violations: List of architecture violations
            - metrics: Counts by violation type
            - status: 'pass' or 'fail'

    """
    from pathlib import Path

    root = Path(project_root).resolve()

    print(f"Running architecture lint on: {root}")

    # Build linter and validate
    linter = ArchitectureLinter(root)
    violations = linter.validate()

    # Categorize violations
    violations_by_type = defaultdict(list)
    for v in violations:
        violations_by_type[v.violation_type].append(v)

    # Print results
    print("\n" + "=" * 80)
    print("ARCHITECTURE VALIDATION RESULTS")
    print("=" * 80)

    if not violations:
        print("✅ No violations found! Architecture is clean.")
        status = "pass"
    else:
        print(f"❌ Found {len(violations)} violations:\n")

        for violation_type, v_list in violations_by_type.items():
            print(f"\n{violation_type} ({len(v_list)} violations):")
            for v in v_list:
                print(f"  {v}")
                print(f"     💡 {v.suggestion}")

        status = "fail"

    return {
        "status": status,
        "violations": [
            {
                "file": v.file_path,
                "line": v.line_number,
                "type": v.violation_type,
                "description": v.description,
                "suggestion": v.suggestion,
            }
            for v in violations
        ],
        "metrics": {
            "total_violations": len(violations),
            **{k: len(v) for k, v in violations_by_type.items()},
        },
    }


@register_workflow
class ArchitectureLintWorkflow(BaseWorkflow):
    """Architecture linter workflow for Maxwell's plugin architecture."""

    workflow_id = "architecture-lint"
    name = "Architecture Linter"
    description = "Validates Maxwell's plugin architecture rules"
    version = "1.0"
    category = "validation"
    tags = {"architecture", "code-quality", "linting"}

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        """Execute architecture linting.

        Args:
            project_root: Root directory of maxwell project
            context: Execution context (unused)

        Returns:
            WorkflowResult with violations and metrics

        """
        # Run the linter
        result = architecture_lint_workflow(str(project_root))

        # Convert to WorkflowResult
        status = WorkflowStatus.COMPLETED if result["status"] == "pass" else WorkflowStatus.FAILED

        return WorkflowResult(
            workflow_id=self.workflow_id,
            status=status,
            metrics=self.metrics,
            artifacts={
                "violations": result["violations"],
                "metrics": result["metrics"],
                "status": result["status"],
            },
        )


if __name__ == "__main__":
    import sys

    project_root = sys.argv[1] if len(sys.argv) > 1 else "."
    result = architecture_lint_workflow(project_root)
    sys.exit(0 if result["status"] == "pass" else 1)
