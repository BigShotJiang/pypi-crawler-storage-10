"""Web scraping workflow using crawl4ai.

Scrapes web pages using crawl4ai with Playwright backend.
Extracts clean markdown, structured data, and metadata.

Requires: pip install maxwell[web-scrape]
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

from maxwell.registry import register_workflow
from maxwell.workflows.base import (
    BaseWorkflow,
    WorkflowInputs,
    WorkflowOutputs,
    WorkflowResult,
    WorkflowStatus,
)

__all__ = ["WebScrapeWorkflow", "web_scrape"]


@dataclass(frozen=True)
class WebScrapeInputs(WorkflowInputs):
    """Inputs for web scraping workflow."""

    url: str  # URL to scrape
    output_format: str = "markdown"  # markdown, html, text, structured
    save_to_file: bool = False  # Save output to file
    output_path: Optional[str] = None  # Path to save output (if save_to_file=True)
    extract_links: bool = False  # Extract all links from page
    extract_images: bool = False  # Extract all image URLs
    wait_for: Optional[str] = None  # CSS selector to wait for before scraping
    timeout: int = 30000  # Timeout in milliseconds


@dataclass(frozen=True)
class WebScrapeOutputs(WorkflowOutputs):
    """Outputs for web scraping workflow."""

    url: str  # URL that was scraped
    title: str  # Page title
    content: str  # Scraped content in requested format
    links: list[str]  # Extracted links (if extract_links=True)
    images: list[str]  # Extracted images (if extract_images=True)
    metadata: dict  # Page metadata (description, keywords, etc.)
    output_file: Optional[str]  # Path to saved file (if save_to_file=True)


@register_workflow
class WebScrapeWorkflow(BaseWorkflow):
    """Web scraping workflow using crawl4ai."""

    workflow_id = "web-scrape"
    name = "Web Scraper"
    description = "Scrape web pages using crawl4ai with Playwright"
    version = "1.0"
    category = "scraping"
    tags = {"web-scraping", "crawl4ai", "playwright"}

    # Define typed schemas
    InputSchema = WebScrapeInputs
    OutputSchema = WebScrapeOutputs

    def get_cli_parameters(self):
        """Get CLI parameter definitions."""
        return [
            {"name": "url", "type": str, "required": True, "help": "URL to scrape"},
            {
                "name": "output-format",
                "type": str,
                "default": "markdown",
                "help": "Output format (markdown, html, text, structured)",
            },
            {"name": "save-to-file", "type": bool, "default": False, "help": "Save output to file"},
            {
                "name": "output-path",
                "type": str,
                "default": None,
                "help": "Path to save output (if save-to-file=True)",
            },
            {
                "name": "extract-links",
                "type": bool,
                "default": False,
                "help": "Extract all links from page",
            },
            {
                "name": "extract-images",
                "type": bool,
                "default": False,
                "help": "Extract all image URLs",
            },
            {
                "name": "wait-for",
                "type": str,
                "default": None,
                "help": "CSS selector to wait for before scraping",
            },
            {"name": "timeout", "type": int, "default": 30000, "help": "Timeout in milliseconds"},
        ]

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        """Execute web scraping.

        Args:
            project_root: Project root directory
            context: Execution context with URL and options

        Returns:
            WorkflowResult with scraped content

        """
        try:
            # Lazy import crawl4ai
            from crawl4ai import AsyncWebCrawler
        except ImportError as e:
            raise ImportError(
                "Web scraping requires crawl4ai. "
                "Install with: pip install maxwell[web-scrape] or pip install crawl4ai"
            ) from e

        # Parse typed inputs
        inputs = self.parse_inputs(context)

        # Run async scraping
        import asyncio

        try:
            result = asyncio.run(self._scrape_async(inputs, project_root))
            return result
        except Exception as e:
            return self.create_result(
                None, status=WorkflowStatus.FAILED, error_message=f"Scraping failed: {e}"
            )

    async def _scrape_async(self, inputs: WebScrapeInputs, project_root: Path) -> WorkflowResult:
        """Async scraping implementation."""
        from crawl4ai import AsyncWebCrawler

        async with AsyncWebCrawler(verbose=True) as crawler:
            # Scrape the URL
            result = await crawler.arun(url=inputs.url)

            # Extract content based on format
            if inputs.output_format == "markdown":
                content = result.markdown
            elif inputs.output_format == "html":
                content = result.html
            elif inputs.output_format == "text":
                content = result.cleaned_html  # Clean text version
            elif inputs.output_format == "structured":
                content = result.extracted_content if result.extracted_content else result.markdown
            else:
                content = result.markdown  # Default to markdown

            # Extract links if requested
            links = []
            if inputs.extract_links and result.links:
                links = list(result.links.get("internal", []))
                links.extend(result.links.get("external", []))

            # Extract images if requested
            images = []
            if inputs.extract_images and result.media:
                images = list(result.media.get("images", []))

            # Extract metadata
            metadata = {
                "description": result.metadata.get("description", "") if result.metadata else "",
                "keywords": result.metadata.get("keywords", "") if result.metadata else "",
                "author": result.metadata.get("author", "") if result.metadata else "",
                "language": result.metadata.get("language", "") if result.metadata else "",
                "success": result.success,
            }

            # Save to file if requested
            output_file = None
            if inputs.save_to_file:
                if inputs.output_path:
                    output_file_path = Path(inputs.output_path)
                else:
                    # Generate filename from URL
                    filename = self._url_to_filename(inputs.url, inputs.output_format)
                    output_file_path = project_root / "scraped" / filename

                output_file_path.parent.mkdir(parents=True, exist_ok=True)
                output_file_path.write_text(content, encoding="utf-8")
                output_file = str(output_file_path)

            # Create outputs
            outputs = WebScrapeOutputs(
                url=inputs.url,
                title=result.metadata.get("title", "") if result.metadata else "",
                content=content,
                links=links,
                images=images,
                metadata=metadata,
                output_file=output_file,
            )

            return self.create_result(outputs, status=WorkflowStatus.COMPLETED)

    def _url_to_filename(self, url: str, output_format: str) -> str:
        """Convert URL to safe filename.

        Args:
            url: URL to scrape
            output_format: Output format (markdown, html, text)

        Returns:
            Safe filename

        """
        import re
        from urllib.parse import urlparse

        parsed = urlparse(url)
        domain = parsed.netloc.replace("www.", "")
        path = parsed.path.strip("/").replace("/", "_")

        # Create safe filename
        filename = f"{domain}_{path}" if path else domain
        filename = re.sub(r"[^\w\-.]", "_", filename)

        # Add extension
        ext_map = {
            "markdown": "md",
            "html": "html",
            "text": "txt",
            "structured": "json",
        }
        ext = ext_map.get(output_format, "md")

        return f"{filename}.{ext}"


def web_scrape(
    url: str,
    output_format: str = "markdown",
    save_to_file: bool = False,
    output_path: Optional[str] = None,
    extract_links: bool = False,
    extract_images: bool = False,
) -> dict:
    """Scrape a web page using crawl4ai.

    Args:
        url: URL to scrape
        output_format: Output format (markdown, html, text, structured)
        save_to_file: Save output to file
        output_path: Path to save output (if save_to_file=True)
        extract_links: Extract all links from page
        extract_images: Extract all image URLs

    Returns:
        Dict with scraped content and metadata

    Example:
        >>> result = web_scrape("https://example.com", output_format="markdown")
        >>> print(result["content"])

    """
    from maxwell.api import execute_workflow

    result = execute_workflow(
        workflow_id="web-scrape",
        url=url,
        output_format=output_format,
        save_to_file=save_to_file,
        output_path=output_path,
        extract_links=extract_links,
        extract_images=extract_images,
    )

    return result.artifacts
