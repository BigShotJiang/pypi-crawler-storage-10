"""Logging practice validator for Maxwell.

Enforces proper logging patterns:
1. Use logging module, not print() for progress/debug messages
2. User-facing output can use print(), but only for actual results
3. Use appropriate log levels (DEBUG, INFO, WARNING, ERROR)
4. All console output should go to stderr (via logging or print(..., file=sys.stderr))

Examples of violations:
- print("Processing file...") → logger.info("Processing file...")
- print("Debug: value =", x) → logger.debug("value = %s", x)

Examples of acceptable use:
- print(json.dumps(result)) → OK (actual output)
- logger.info("Found %d issues", count) → OK
- print(f"Error: {e}", file=sys.stderr) → OK but logger.error() is better
"""

import ast
from pathlib import Path
from typing import Iterator

from maxwell.workflows.validate.validators.types import BaseValidator, Finding, Severity


class LoggingPracticeValidator(BaseValidator):
    """Validates proper logging practices in workflows."""

    rule_id = "LOGGING-POOR-PRACTICE"
    default_severity = Severity.WARN

    def validate(self, file_path: Path, content: str, config=None) -> Iterator[Finding]:  # type: ignore
        """Check for improper logging patterns.

        Args:
            file_path: Path to file being validated
            content: File content
            config: Maxwell config (optional)

        Yields:
            Finding objects for logging issues

        """
        # Skip if not a workflow file
        if "workflows/" not in str(file_path):
            return

        # Skip __init__.py and base classes
        if file_path.name in {"__init__.py", "base.py"}:
            return

        try:
            tree = ast.parse(content)
        except SyntaxError:
            return

        for node in ast.walk(tree):
            # Check for print() calls
            if isinstance(node, ast.Call):
                # Check if this is a print() call
                if isinstance(node.func, ast.Name) and node.func.id == "print":
                    # Check if it's printing to stderr explicitly
                    has_stderr = False
                    for keyword in node.keywords:
                        if keyword.arg == "file" and isinstance(keyword.value, ast.Attribute):
                            # Check if it's sys.stderr
                            if (
                                isinstance(keyword.value.value, ast.Name)
                                and keyword.value.value.id == "sys"
                                and keyword.value.attr == "stderr"
                            ):
                                has_stderr = True
                                break

                    # If not printing to stderr, check if it's a progress/debug message
                    if not has_stderr and node.args:
                        first_arg = node.args[0]

                        # Try to extract the message being printed
                        message_preview = ""
                        is_suspicious = False

                        if isinstance(first_arg, ast.Constant):
                            message_preview = str(first_arg.value)[:50]
                            # Check for common progress/debug indicators
                            lower_msg = message_preview.lower()
                            is_suspicious = any(
                                keyword in lower_msg
                                for keyword in [
                                    "processing",
                                    "loading",
                                    "running",
                                    "checking",
                                    "found",
                                    "debug",
                                    "warning",
                                    "error:",
                                    "analyzing",
                                    "validating",
                                    "scanning",
                                    "building",
                                    "starting",
                                    "finished",
                                    "completed",
                                ]
                            )

                        elif isinstance(first_arg, ast.JoinedStr):
                            # f-string
                            is_suspicious = True
                            message_preview = "f-string"

                        # Report if it looks like a progress/debug message
                        if is_suspicious:
                            yield self.create_finding(
                                message=f"Use logging instead of print() for progress/debug messages: {message_preview}",
                                file_path=file_path,
                                line=node.lineno,
                                column=node.col_offset,
                                suggestion="Replace with logger.info() or logger.debug(). Use logging_config.setup_logging() at workflow start.",
                            )

                # Check for direct sys.stdout.write()
                elif isinstance(node.func, ast.Attribute):
                    if (
                        isinstance(node.func.value, ast.Attribute)
                        and isinstance(node.func.value.value, ast.Name)
                        and node.func.value.value.id == "sys"
                        and node.func.value.attr == "stdout"
                        and node.func.attr == "write"
                    ):
                        yield self.create_finding(
                            message="Direct sys.stdout.write() found - use logging or print() to stderr",
                            file_path=file_path,
                            line=node.lineno,
                            column=node.col_offset,
                            suggestion="Use logger.info() for progress messages, or print(..., file=sys.stderr) for console output",
                        )
