"""Dependency synchronization validator.

Ensures all imported packages are declared in pyproject.toml dependencies.
Catches missing optional dependencies that would cause import errors at runtime.

maxwell/src/maxwell/workflows/validate/validators/project_wide/dependency_sync.py
"""

import ast
import logging
from pathlib import Path
from typing import Dict, Iterator, Set

try:
    import tomllib
except ImportError:
    import tomli as tomllib  # type: ignore

from maxwell.workflows.validate.validators.project_wide import ProjectWideValidator
from maxwell.workflows.validate.validators.types import Finding, Severity

logger = logging.getLogger(__name__)

# Package name mappings for cases where import name != package name
PACKAGE_IMPORT_MAPPINGS = {
    "marker": "marker-pdf",  # import marker, but package is marker-pdf
    "PIL": "pillow",  # import PIL, but package is pillow
    "cv2": "opencv-python",  # import cv2, but package is opencv-python
    "sklearn": "scikit-learn",  # import sklearn, but package is scikit-learn
}

# Standard library modules that don't need to be in dependencies
STDLIB_MODULES = {
    "__future__",  # Future imports
    "abc",
    "argparse",
    "ast",
    "asyncio",
    "base64",
    "collections",
    "concurrent",  # concurrent.futures
    "contextlib",
    "copy",
    "csv",
    "dataclasses",
    "datetime",
    "decimal",
    "email",
    "enum",
    "fnmatch",
    "functools",
    "glob",
    "hashlib",
    "heapq",
    "html",
    "http",
    "importlib",
    "inspect",
    "io",
    "itertools",
    "json",
    "logging",
    "math",
    "multiprocessing",
    "operator",
    "os",
    "pathlib",
    "pickle",
    "platform",
    "pprint",
    "queue",
    "random",
    "re",
    "secrets",
    "shutil",
    "signal",
    "socket",
    "sqlite3",
    "ssl",
    "stat",
    "string",
    "struct",
    "subprocess",
    "sys",
    "tempfile",
    "textwrap",
    "threading",
    "time",
    "traceback",
    "types",
    "typing",
    "unittest",
    "urllib",
    "uuid",
    "warnings",
    "weakref",
    "xml",
    "zipfile",
    # Python 3.11+ specific
    "tomllib",
    "tomli",
    # Common typing-only imports
    "typing_extensions",
}


class DependencySyncValidator(ProjectWideValidator):
    """Validates that all imports are declared in pyproject.toml."""

    rule_id = "DEPENDENCY-NOT-DECLARED"
    default_severity = Severity.WARN

    def __init__(self, severity: Severity | None = None, config=None):  # type: ignore
        """Initialize validator."""
        super().__init__(severity, config)

    def validate_project(self, project_files: Dict[Path, str], config=None) -> Iterator[Finding]:  # type: ignore
        """Validate that all imports are declared in pyproject.toml.

        Args:
            project_files: Dictionary mapping file paths to their content
            config: Configuration object

        Yields:
            Finding objects for undeclared dependencies

        """
        # Find pyproject.toml in the project
        pyproject_path = self._find_pyproject(project_files)
        if not pyproject_path:
            logger.debug("No pyproject.toml found, skipping dependency validation")
            return

        # Load declared dependencies
        try:
            declared_deps = self._load_dependencies(pyproject_path)
        except Exception as e:
            logger.warning(f"Failed to load dependencies from pyproject.toml: {e}")
            return

        # Collect all imports from Python files
        all_imports: Dict[str, Set[Path]] = {}  # module -> set of files that import it

        for file_path, content in project_files.items():
            if not file_path.name.endswith(".py"):
                continue

            try:
                imports = self._extract_imports(content)
                for module in imports:
                    if module not in all_imports:
                        all_imports[module] = set()
                    all_imports[module].add(file_path)
            except SyntaxError:
                # Skip files with syntax errors
                continue

        # Check for undeclared dependencies
        for module, files in sorted(all_imports.items()):
            # Skip stdlib modules
            if module in STDLIB_MODULES:
                continue

            # Skip relative imports (start with .)
            if module.startswith("."):
                continue

            # Skip project modules (start with project name)
            if config and hasattr(config, "project_name"):
                if module.startswith(config.project_name):
                    continue

            # Check common project prefixes
            if module.startswith(("maxwell", "tests", "examples", "src")):
                continue

            # Get package name (first part of module)
            package = module.split(".")[0]

            # Handle import name -> package name mappings (e.g., marker -> marker-pdf)
            actual_package = PACKAGE_IMPORT_MAPPINGS.get(package, package)

            # Normalize package name - Python packages can use hyphens or underscores
            # e.g., "qdrant_client" in code but "qdrant-client" in pyproject.toml
            normalized_package = actual_package.lower().replace("_", "-")

            # Check if declared (try exact match first, then normalized)
            if actual_package.lower() not in declared_deps and normalized_package not in declared_deps:
                # Report once per file that imports it
                for file_path in sorted(files):
                    yield self.create_finding(
                        message=f"Import '{module}' from package '{package}' is not declared in pyproject.toml",
                        file_path=file_path,
                        line=0,
                        suggestion=(
                            f"Add '{package}' to pyproject.toml dependencies or optional-dependencies. "
                            "If this is an optional dependency, ensure it's in the appropriate feature group."
                        ),
                    )

    def _find_pyproject(self, project_files: Dict[Path, str]) -> Path | None:
        """Find pyproject.toml in project files."""
        for path in project_files.keys():
            if path.name == "pyproject.toml":
                return path
        return None

    def _load_dependencies(self, pyproject_path: Path) -> Set[str]:
        """Load all dependencies from pyproject.toml.

        Args:
            pyproject_path: Path to pyproject.toml

        Returns:
            Set of normalized package names (lowercase, hyphens converted to underscores)

        """
        deps = set()

        try:
            with open(pyproject_path, "rb") as f:
                data = tomllib.load(f)

            # Get main dependencies
            project = data.get("project", {})
            for dep_str in project.get("dependencies", []):
                package = self._extract_package_name(dep_str)
                if package:
                    # Store both hyphenated and underscored versions
                    deps.add(package.lower())
                    deps.add(package.lower().replace("-", "_"))

            # Get optional dependencies
            optional_deps = project.get("optional-dependencies", {})
            for group_deps in optional_deps.values():
                for dep_str in group_deps:
                    package = self._extract_package_name(dep_str)
                    if package:
                        # Store both hyphenated and underscored versions
                        deps.add(package.lower())
                        deps.add(package.lower().replace("-", "_"))

        except Exception as e:
            logger.warning(f"Failed to parse pyproject.toml: {e}")

        return deps

    def _extract_package_name(self, dep_str: str) -> str | None:
        """Extract package name from dependency string.

        Examples:
            "requests>=2.25" -> "requests"
            "pytest-cov>=4.0" -> "pytest-cov"
            "marker-pdf>=0.2" -> "marker-pdf"

        Args:
            dep_str: Dependency string from pyproject.toml

        Returns:
            Package name or None

        """
        # Split on common version specifiers
        for sep in [">=", "<=", "==", "~=", ">", "<", "!=", "[", "@"]:
            if sep in dep_str:
                dep_str = dep_str.split(sep)[0]
                break

        return dep_str.strip() if dep_str.strip() else None

    def _extract_imports(self, content: str) -> Set[str]:
        """Extract all imported modules from Python source.

        Args:
            content: Python source code

        Returns:
            Set of top-level module names

        """
        imports = set()

        try:
            tree = ast.parse(content)

            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        # Get top-level module name
                        module = alias.name.split(".")[0]
                        imports.add(module)

                elif isinstance(node, ast.ImportFrom):
                    # Skip relative imports (level > 0 means it starts with dots)
                    if node.level > 0:
                        continue

                    if node.module:
                        # Get top-level module name
                        # e.g., "maxwell.workflows.chat" -> "maxwell"
                        module = node.module.split(".")[0]
                        imports.add(module)

        except SyntaxError:
            # Can't parse, skip this file
            pass

        return imports
