"""LLM and Embedding Pool Manager.

Flexible resource registry that allows users to declare all their LLMs and embeddings,
then intelligently selects the best one for each task based on capabilities.

Usage:
    pool = LLMPool.from_registry()

    # Select by name
    llm = pool.get_lm("qwen-coder-30b")

    # Select by capability
    fast_llm = pool.select_llm(min_speed=50, reasoning=True)
    vision_llm = pool.select_llm(vision=True)

    # Get default embedding
    embed = pool.get_embedding("default")
"""

__all__ = ["LLMPool", "LLMClient", "LLMSpec", "get_lm", "get_embedding"]

import datetime
import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# Module-level session ID cache (one per process/CLI execution)
_SESSION_ID_CACHE = None


def _get_or_create_session_id():
    """Get or create a session ID that persists for the entire CLI execution."""
    global _SESSION_ID_CACHE

    if _SESSION_ID_CACHE is not None:
        return _SESSION_ID_CACHE

    # Try environment variable first
    session_id = os.getenv("LLM_SESSION_ID")
    if session_id:
        _SESSION_ID_CACHE = session_id
        return session_id

    # Generate from calling script + timestamp (once per execution)
    import sys

    calling_script = "unknown"
    if len(sys.argv) > 0:
        script_path = Path(sys.argv[0])
        calling_script = script_path.stem

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    _SESSION_ID_CACHE = f"{calling_script}_{timestamp}"

    return _SESSION_ID_CACHE


class LLMSpec(BaseModel):
    """Specification for an LLM (OpenAI-compatible client).

    Note: speed_tokens_per_sec in capabilities is deprecated. Maxwell measures
    actual speed dynamically from request timing. All unmeasured LLMs start with
    equal priority (sys.maxsize) until benchmarked through actual usage.
    """

    name: str
    api_base: str = Field(..., description="Base URL (e.g., http://host:port)")
    model: str
    backend: str  # vllm | llamacpp | openai
    capabilities: Dict[str, Any]  # max_tokens, max_context, reasoning, vision, etc.
    default_temperature: float
    tags: List[str] = Field(default_factory=list)

    # Cost and scheduling metadata
    cost_per_1k_tokens: float = Field(default=0.0, description="Cost per 1K tokens (0 = free)")
    tier: str = Field(default="standard", description="Service tier: free | standard | premium")
    daily_budget_tokens: Optional[int] = Field(
        default=None, description="Max tokens/day (None = unlimited)"
    )

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "LLMSpec":
        """Create from dictionary with Pydantic validation."""
        return cls(**data)  # Pydantic handles validation automatically

    def matches(
        self,
        min_speed: Optional[float] = None,
        min_context: Optional[int] = None,
        reasoning: Optional[bool] = None,
        vision: Optional[bool] = None,
        code_specialized: Optional[bool] = None,
        tags: Optional[List[str]] = None,
    ) -> bool:
        """Check if this LLM matches the given requirements.

        Note: min_speed is deprecated and ignored. Use select_optimal_llm() or
        get_fastest_llm() for speed-based selection with dynamic measurements.
        """
        caps = self.capabilities

        # Speed filtering removed - use dynamic measurements instead
        if min_speed is not None:
            logger.warning(
                "min_speed parameter is deprecated. Use select_optimal_llm() or "
                "get_fastest_llm() for speed-based selection."
            )

        if min_context is not None and caps.get("max_context", 0) < min_context:
            return False

        if reasoning is not None and caps.get("reasoning", False) != reasoning:
            return False

        if vision is not None and caps.get("vision", False) != vision:
            return False

        if code_specialized is not None and caps.get("code_specialized", False) != code_specialized:
            return False

        if tags is not None:
            if not all(tag in self.tags for tag in tags):
                return False

        return True


class EmbeddingSpec(BaseModel):
    """Specification for an embedding model (OpenAI-compatible client)."""

    name: str
    api_base: str = Field(..., description="Base URL (e.g., http://host:port)")
    model: str
    dimension: int
    max_context: int = Field(..., description="Maximum context length in tokens")
    specialized_for: List[str]
    tags: List[str]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EmbeddingSpec":
        """Create from dictionary with Pydantic validation."""
        return cls(**data)  # Pydantic handles validation automatically

    def embed(self, text: str) -> List[float]:
        """Embed text using this embedding model.

        Args:
            text: Text to embed (will be truncated to max_context)

        Returns:
            Embedding vector as list of floats

        """
        import requests

        # Truncate to fit within token limit (rough estimate: 4 chars per token)
        max_chars = self.max_context * 4
        if len(text) > max_chars:
            text = text[:max_chars]
            logger.debug(f"Truncated text to {max_chars} chars for embedding")

        # Construct full endpoint URL (OpenAI-compatible)
        endpoint_url = f"{self.api_base.rstrip('/')}/v1/embeddings"
        response = requests.post(
            endpoint_url,
            json={"input": text, "model": self.model},
            timeout=30,
        )
        response.raise_for_status()
        embedding = response.json()["data"][0]["embedding"]

        # JSONL logging for embeddings (same as LLM generation)
        import json as json_module
        import os
        from pathlib import Path

        # Skip if JSONL logging disabled
        if os.getenv("NO_JSONL_LOGGING"):
            return embedding

        # Use same logging logic as LLM generation
        base_dir = Path.cwd() / ".maxwell"
        log_dir = base_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)

        # Use cached session ID (shared across all calls in this execution)
        session_id = _get_or_create_session_id()
        jsonl_file = log_dir / f"{session_id}.jsonl"

        # Create embedding log entry
        log_entry = {
            "timestamp": datetime.datetime.now().isoformat(),
            "model": self.model,
            "type": "embedding",
            "request": {"input": text, "model": self.model},
            "response": {
                "embedding": embedding,
                "dimensions": len(embedding),
                "min_value": min(embedding),
                "max_value": max(embedding),
                "mean_value": sum(embedding) / len(embedding),
                "first_10": embedding[:10],
                "last_10": embedding[-10:],
                "range": [min(embedding), max(embedding)],
            },
            "response_raw": {"data": [{"embedding": embedding}]},
            "grammar_used": False,
        }

        with open(jsonl_file, "a", encoding="utf-8") as f:
            f.write(json_module.dumps(log_entry) + "\n")

        return embedding


class LLMPool:
    """Pool manager for LLMs and embeddings with health checking."""

    def __init__(self, llms: List[LLMSpec], embeddings: List[EmbeddingSpec]):
        self.llms = {llm.name: llm for llm in llms}
        self.embeddings = {emb.name: emb for emb in embeddings}

        # Health check cache: {service_name: (is_healthy, timestamp)}
        self._health_cache: Dict[str, tuple[bool, float]] = {}
        self._health_check_ttl = 30.0  # Cache health status for 30 seconds

        # Usage tracking for budget enforcement
        self._usage_tracker: Dict[str, Dict[str, int]] = {}  # {llm_name: {date: tokens_used}}
        self._load_usage_tracker()

        # Performance tracking for dynamic speed measurement
        self._performance_cache: Dict[str, List[tuple[float, float, float]]] = (
            {}
        )  # {llm_name: [(timestamp, tokens, elapsed_sec)]}
        self._load_performance_cache()

    def _load_usage_tracker(self):
        """Load usage tracking data from cache file."""
        cache_file = Path.home() / ".maxwell" / "llm_usage.json"
        if cache_file.exists():
            try:
                with open(cache_file) as f:
                    self._usage_tracker = json.load(f)
            except Exception as e:
                logger.warning(f"Failed to load usage tracker: {e}")
                self._usage_tracker = {}
        else:
            self._usage_tracker = {}

    def _save_usage_tracker(self):
        """Save usage tracking data to cache file."""
        cache_file = Path.home() / ".maxwell" / "llm_usage.json"
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        with open(cache_file, "w") as f:
            json.dump(self._usage_tracker, f, indent=2)

    def _load_performance_cache(self):
        """Load performance tracking data from cache file."""
        cache_file = Path.home() / ".maxwell" / "llm_performance.json"
        if cache_file.exists():
            try:
                with open(cache_file) as f:
                    data = json.load(f)
                    # Convert to tuples
                    self._performance_cache = {
                        name: [tuple(entry) for entry in entries] for name, entries in data.items()
                    }
            except Exception as e:
                logger.warning(f"Failed to load performance cache: {e}")
                self._performance_cache = {}
        else:
            self._performance_cache = {}

    def _save_performance_cache(self):
        """Save performance tracking data to cache file."""
        cache_file = Path.home() / ".maxwell" / "llm_performance.json"
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        with open(cache_file, "w") as f:
            json.dump(self._performance_cache, f, indent=2)

    def _track_performance(self, llm_name: str, tokens: int, elapsed_seconds: float):
        """Track performance measurement for dynamic speed calculation.

        Args:
            llm_name: Name of LLM
            tokens: Number of tokens generated
            elapsed_seconds: Time taken in seconds

        """
        import time

        timestamp = time.time()

        if llm_name not in self._performance_cache:
            self._performance_cache[llm_name] = []

        # Add measurement
        self._performance_cache[llm_name].append((timestamp, float(tokens), elapsed_seconds))

        # Keep only last 100 measurements per LLM
        if len(self._performance_cache[llm_name]) > 100:
            self._performance_cache[llm_name] = self._performance_cache[llm_name][-100:]

        self._save_performance_cache()

    def get_dynamic_speed(self, llm_name: str, max_age_hours: float = 24.0) -> float:
        """Get dynamic speed estimate based on recent measurements.

        If no measurements exist, returns a very high value (sys.maxsize) so all
        unmeasured LLMs are treated equally and given priority until measured.

        Args:
            llm_name: Name of LLM
            max_age_hours: Only use measurements from last N hours

        Returns:
            Estimated tokens/sec based on recent measurements, or sys.maxsize if unmeasured

        """
        import sys
        import time

        if llm_name not in self._performance_cache:
            return float(sys.maxsize)

        measurements = self._performance_cache[llm_name]
        if not measurements:
            return float(sys.maxsize)

        # Filter to recent measurements only
        cutoff_time = time.time() - (max_age_hours * 3600)
        recent = [(ts, tokens, elapsed) for ts, tokens, elapsed in measurements if ts > cutoff_time]

        if not recent:
            return float(sys.maxsize)

        # Calculate weighted average (more recent = higher weight)
        total_weight = 0.0
        weighted_speed = 0.0
        current_time = time.time()

        for timestamp, tokens, elapsed in recent:
            if elapsed == 0:
                continue

            speed = tokens / elapsed

            # Exponential decay: recent measurements get more weight
            age_hours = (current_time - timestamp) / 3600
            weight = 2.0 ** (-age_hours / 6.0)  # Half-life of 6 hours

            weighted_speed += speed * weight
            total_weight += weight

        if total_weight == 0:
            return float(sys.maxsize)

        estimated_speed = weighted_speed / total_weight

        logger.debug(
            f"Dynamic speed for {llm_name}: {estimated_speed:.1f} t/s "
            f"(based on {len(recent)} recent measurements)"
        )

        return estimated_speed

    def _track_usage(self, llm_name: str, tokens: int):
        """Track token usage for budget enforcement."""
        today = datetime.date.today().isoformat()

        if llm_name not in self._usage_tracker:
            self._usage_tracker[llm_name] = {}

        self._usage_tracker[llm_name][today] = self._usage_tracker[llm_name].get(today, 0) + tokens
        self._save_usage_tracker()

    def _check_budget(self, llm: LLMSpec, estimated_tokens: int) -> bool:
        """Check if LLM has budget remaining for this request."""
        if llm.daily_budget_tokens is None:
            return True  # Unlimited

        today = datetime.date.today().isoformat()
        used_today = self._usage_tracker.get(llm.name, {}).get(today, 0)

        return (used_today + estimated_tokens) <= llm.daily_budget_tokens

    @staticmethod
    def estimate_tokens(text: str, max_completion: int = 0) -> tuple[int, int]:
        """Estimate (prompt_tokens, total_tokens) from text.

        Uses tiktoken-like heuristic: ~4 chars per token.

        Args:
            text: Input text
            max_completion: Expected completion tokens

        Returns:
            (prompt_tokens, total_tokens)

        """
        # Rough heuristic: 4 chars/token (works reasonably for English + code)
        prompt_tokens = max(1, len(text) // 4)
        total_tokens = prompt_tokens + max_completion
        return prompt_tokens, total_tokens

    def score_llm(
        self,
        llm: LLMSpec,
        estimated_tokens: int,
        time_cost_weight: float = 1.0,
    ) -> float:
        """Score an LLM for a given request (higher = better).

        Scoring considers:
        - Monetary cost (static from API pricing)
        - Time cost (dynamic from speed)
        - Context utilization (prefer ~70% utilization)
        - Budget availability

        Args:
            llm: LLM to score
            estimated_tokens: Total tokens (prompt + completion)
            time_cost_weight: Weight for time vs money (0-10, default 1.0)

        Returns:
            Score (higher = better fit), or -1 if impossible

        """
        # Check hard constraints
        max_context = llm.capabilities.get("max_context", 4096)
        if estimated_tokens > max_context:
            return -1.0  # Impossible - doesn't fit

        if not self._check_budget(llm, estimated_tokens):
            logger.debug(f"{llm.name} over budget, skipping")
            return -1.0  # Over budget

        # Calculate monetary cost (negative because lower is better)
        monetary_cost = -llm.cost_per_1k_tokens * (estimated_tokens / 1000)

        # Calculate time cost (negative because slower is worse)
        # Use dynamic speed (defaults to sys.maxsize if unmeasured)
        dynamic_speed = self.get_dynamic_speed(llm.name)
        time_seconds = estimated_tokens / dynamic_speed
        time_cost = -time_cost_weight * time_seconds

        # Calculate utilization score (prefer ~70% utilization)
        utilization = estimated_tokens / max_context
        utilization_bonus = 1.0 - abs(utilization - 0.7)  # 0-1, peaks at 70%

        # Combined score
        total_score = monetary_cost + time_cost + utilization_bonus

        logger.debug(
            f"{llm.name}: score={total_score:.2f} "
            f"(money={monetary_cost:.2f}, time={time_cost:.2f}, "
            f"util={utilization_bonus:.2f}, {utilization*100:.0f}% full)"
        )

        return total_score

    def select_optimal_llm(
        self,
        prompt: str,
        max_completion: int = 512,
        time_cost_weight: float = 1.0,
        **capability_filters,
    ) -> LLMSpec:
        """Select optimal LLM using intelligent scoring.

        Args:
            prompt: Input prompt text
            max_completion: Expected completion tokens
            time_cost_weight: How much to value speed (0-10)
                - 0.0 = only minimize monetary cost
                - 1.0 = balanced (default)
                - 10.0 = maximize speed regardless of cost
            **capability_filters: Additional filters (reasoning, vision, etc.)

        Returns:
            Best LLM spec for this request

        Example:
            # For cheap batch processing (prefer free internal LLMs)
            llm = pool.select_optimal_llm(prompt, time_cost_weight=0.1)

            # For interactive user-facing (prefer speed)
            llm = pool.select_optimal_llm(prompt, time_cost_weight=10.0)

            # For balanced workloads
            llm = pool.select_optimal_llm(prompt, time_cost_weight=1.0)

        """
        # Estimate request size
        prompt_tokens, total_tokens = self.estimate_tokens(prompt, max_completion)

        logger.debug(
            f"Request size: ~{total_tokens} tokens ({prompt_tokens} prompt + {max_completion} completion)"
        )

        # Get healthy candidates matching capability filters
        healthy = self.get_healthy_llms()
        candidates = [llm for llm in healthy if llm.matches(**capability_filters)]

        if not candidates:
            raise ValueError(f"No healthy LLMs matching filters: {capability_filters}")

        # Score each candidate
        scored = [(self.score_llm(llm, total_tokens, time_cost_weight), llm) for llm in candidates]
        scored = [
            (score, llm) for score, llm in scored if score != -1.0
        ]  # Filter impossible (keep negative scores, they're valid costs)

        if not scored:
            raise ValueError(
                f"No LLMs can handle {total_tokens} tokens "
                f"(max available: {max([llm.capabilities.get('max_context', 0) for llm in candidates])})"
            )

        # Sort by score (best first)
        scored.sort(reverse=True, key=lambda x: x[0])
        best_score, best_llm = scored[0]

        logger.info(
            f"Selected {best_llm.name} (score={best_score:.2f}, "
            f"cost=${best_llm.cost_per_1k_tokens * total_tokens / 1000:.4f}, "
            f"tier={best_llm.tier})"
        )

        return best_llm

    @classmethod
    def from_registry(cls, registry_path: Optional[Path] = None) -> "LLMPool":
        """Load pool from registry JSON file.

        Search order:
        1. Provided registry_path
        2. .maxwell/lm_registry.json in current directory
        3. ~/.maxwell/lm_registry.json (global default)
        """
        if registry_path is None:
            # Try local first
            local_registry = Path.cwd() / ".maxwell" / "lm_registry.json"
            if local_registry.exists():
                registry_path = local_registry
            else:
                # Fall back to global
                global_registry = Path.home() / ".maxwell" / "lm_registry.json"
                if global_registry.exists():
                    registry_path = global_registry
                else:
                    raise FileNotFoundError(
                        "No LLM registry found. Create .maxwell/llm_registry.json or ~/.maxwell/llm_registry.json"
                    )

        with open(registry_path) as f:
            data = json.load(f)

        llms = [LLMSpec.from_dict(llm_data) for llm_data in data.get("llms", [])]
        embeddings = [EmbeddingSpec.from_dict(emb_data) for emb_data in data.get("embeddings", [])]

        logger.info(
            f"Loaded LLM pool from {registry_path}: {len(llms)} LLMs, {len(embeddings)} embeddings"
        )

        return cls(llms, embeddings)

    def _check_service_health(self, api_base: str) -> bool:
        """Check if a service is healthy by making a test request.

        Args:
            api_base: Base API URL (e.g., http://localhost:8000)

        Returns:
            True if service is healthy and responsive

        """
        # Maxwell-managed models (api_base == "local") don't need HTTP health checks
        # They load on-demand when first used
        if api_base == "local":
            return True

        import requests

        try:
            # Try /health endpoint first (common pattern)
            health_url = f"{api_base.rstrip('/')}/health"
            response = requests.get(health_url, timeout=2)
            if response.status_code == 200:
                return True
        except Exception:
            pass

        try:
            # Fallback: try /v1/models endpoint (OpenAI-compatible)
            models_url = f"{api_base.rstrip('/')}/v1/models"
            response = requests.get(models_url, timeout=2)
            if response.status_code == 200:
                return True
        except Exception:
            pass

        # Service is unreachable
        return False

    def is_service_healthy(self, name: str, llm_spec: Optional[LLMSpec] = None) -> bool:
        """Check if a service is healthy (with caching).

        Args:
            name: Service name
            llm_spec: LLM spec (optional, will look up if not provided)

        Returns:
            True if service is healthy

        """
        import time

        # Check cache first
        if name in self._health_cache:
            is_healthy, timestamp = self._health_cache[name]
            if time.time() - timestamp < self._health_check_ttl:
                return is_healthy

        # Get spec if not provided
        if llm_spec is None:
            if name in self.llms:
                llm_spec = self.llms[name]
            elif name in self.embeddings:
                # For embeddings, just check the API base
                emb_spec = self.embeddings[name]
                is_healthy = self._check_service_health(emb_spec.api_base)
                self._health_cache[name] = (is_healthy, time.time())
                return is_healthy
            else:
                # Unknown service
                return False

        # Check health using api_base (no need to extract!)
        is_healthy = self._check_service_health(llm_spec.api_base)

        # Update cache
        self._health_cache[name] = (is_healthy, time.time())

        # Only warn for remote services (not Maxwell-managed local models)
        if not is_healthy and llm_spec.api_base != "local":
            logger.warning(f"Service {name} ({llm_spec.api_base}) is unhealthy or unreachable")

        return is_healthy

    def get_healthy_llms(self) -> List[LLMSpec]:
        """Get list of all healthy LLMs.

        Returns:
            List of LLM specs for services that are currently healthy

        """
        healthy = []
        for name, spec in self.llms.items():
            if self.is_service_healthy(name, spec):
                healthy.append(spec)
        return healthy

    def get_lm(self, name: str) -> LLMSpec:
        """Get LLM by name."""
        if name not in self.llms:
            raise KeyError(
                f"LLM '{name}' not found in registry. Available: {list(self.llms.keys())}"
            )
        return self.llms[name]

    def select_llm(
        self,
        min_speed: Optional[float] = None,
        min_context: Optional[int] = None,
        reasoning: Optional[bool] = None,
        vision: Optional[bool] = None,
        tags: Optional[List[str]] = None,
        prefer_fastest: bool = True,
        check_health: bool = True,
    ) -> LLMSpec:
        """Select best LLM matching the given criteria (only healthy services).

        Args:
            min_speed: Minimum tokens/sec speed requirement
            min_context: Minimum context length requirement
            reasoning: Must have reasoning capability
            vision: Must have vision capability
            tags: Must have all these tags
            prefer_fastest: If True, return fastest match; otherwise return first match
            check_health: If True, only return healthy services (default)

        Returns:
            LLMSpec matching the criteria

        Raises:
            ValueError: If no LLM matches the criteria

        """
        # Filter by criteria
        candidates = [
            llm
            for llm in self.llms.values()
            if llm.matches(
                min_speed, min_context, reasoning, vision, None, tags
            )  # code_specialized=None
        ]

        # Filter by health if requested
        if check_health:
            healthy_candidates = [
                llm for llm in candidates if self.is_service_healthy(llm.name, llm)
            ]

            if healthy_candidates:
                candidates = healthy_candidates
            else:
                logger.warning(
                    "No healthy LLMs found matching criteria. "
                    "Falling back to all candidates (unhealthy services may fail)."
                )

        if not candidates:
            raise ValueError(
                f"No LLM found matching criteria: min_speed={min_speed}, min_context={min_context}, "
                f"reasoning={reasoning}, vision={vision}, tags={tags}"
            )

        if prefer_fastest:
            # Sort by dynamic speed
            candidates = sorted(
                candidates, key=lambda x: self.get_dynamic_speed(x.name), reverse=True
            )
            selected = candidates[0]
        else:
            selected = candidates[0]

        logger.info(
            f"Selected LLM: {selected.name} (healthy={self.is_service_healthy(selected.name, selected)})"
        )
        return selected

    def get_fastest_llm(self, check_health: bool = True) -> LLMSpec:
        """Get the fastest available LLM (only healthy by default).

        Uses dynamic speed measurements if available, falls back to registry values.

        Args:
            check_health: If True, only return healthy services (default)

        Returns:
            Fastest LLM spec

        Raises:
            ValueError: If no healthy LLMs available

        """
        if check_health:
            healthy = self.get_healthy_llms()
            if healthy:
                # Sort by dynamic speed (unmeasured LLMs get sys.maxsize)
                fastest = sorted(
                    healthy,
                    key=lambda x: self.get_dynamic_speed(x.name),
                    reverse=True,
                )[0]
                dynamic_speed = self.get_dynamic_speed(fastest.name)

                if dynamic_speed == float("inf"):
                    logger.info(f"Selected LLM: {fastest.name} (unmeasured, will benchmark)")
                else:
                    logger.info(f"Fastest healthy LLM: {fastest.name} ({dynamic_speed:.1f} t/s)")
                return fastest
            else:
                logger.warning("No healthy LLMs found. Falling back to fastest registered LLM.")

        # Use dynamic speed for fallback too
        fastest_fallback = sorted(
            self.llms.values(),
            key=lambda x: self.get_dynamic_speed(x.name),
            reverse=True,
        )[0]
        return fastest_fallback

    def get_embedding(self, name_or_tag: str = "default") -> EmbeddingSpec:
        """Get embedding by name or tag."""
        # Try exact name match first
        if name_or_tag in self.embeddings:
            return self.embeddings[name_or_tag]

        # Try tag match
        for emb in self.embeddings.values():
            if name_or_tag in emb.tags:
                return emb

        raise KeyError(
            f"Embedding '{name_or_tag}' not found. Available: {list(self.embeddings.keys())}"
        )

    def list_llms(self) -> List[str]:
        """List all available LLM names."""
        return list(self.llms.keys())

    def list_embeddings(self) -> List[str]:
        """List all available embedding names."""
        return list(self.embeddings.keys())


class LLMClient:
    """LLM client with GBNF grammar support for structured output."""

    def __init__(self, llm_spec: LLMSpec, pool: Optional["LLMPool"] = None):
        """Initialize with an LLM spec from the pool.

        Args:
            llm_spec: LLM specification to use
            pool: Optional LLMPool reference for fallback on failure

        """
        self.spec = llm_spec
        self.pool = pool

    @property
    def max_context(self) -> int:
        """Get max context window for this LLM."""
        return self.spec.capabilities.get("max_context", 4096)

    def generate(
        self,
        prompt: str,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        system_prompt: Optional[str] = None,
        pydantic_model: Optional[Any] = None,
        grammar: Optional[str] = None,
        retry_on_failure: bool = True,
    ) -> str:
        """Generate text from a prompt with optional GBNF grammar constraints.

        Args:
            prompt: User prompt
            temperature: Sampling temperature (default: from spec)
            max_tokens: Max tokens to generate (default: from spec)
            system_prompt: Optional system prompt
            pydantic_model: Pydantic model to auto-generate GBNF grammar (mutually exclusive with grammar)
            grammar: Pre-generated GBNF grammar string (mutually exclusive with pydantic_model)
            retry_on_failure: If True, retry with fallback LLM on failure (default: True)

        Returns:
            Generated text constrained by grammar if provided

        """
        import requests

        temp = temperature if temperature is not None else self.spec.default_temperature
        max_tok = (
            max_tokens if max_tokens is not None else self.spec.capabilities.get("max_tokens", 2000)
        )

        # Check for conflicting structured output specifications
        if pydantic_model is not None and grammar is not None:
            raise ValueError("Cannot specify both pydantic_model and grammar - choose one")

        # Build messages
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        # Build request payload
        payload = {
            "model": self.spec.model,
            "messages": messages,
            "temperature": temp,
            "max_tokens": max_tok,
        }

        # Add structured output based on backend and what was provided
        if pydantic_model is not None:
            # Pydantic model provided - use appropriate format for backend
            if self.spec.backend == "llamacpp":
                # llama.cpp: Convert to GBNF grammar
                from maxwell.pydantic_gbnf import generate_gbnf_grammar_and_documentation

                grammar, _ = generate_gbnf_grammar_and_documentation([pydantic_model])
                payload["grammar"] = grammar
                logger.debug(f"Using GBNF grammar for {pydantic_model.__name__} (llama.cpp)")
            elif self.spec.backend in ["vllm", "openai"]:
                # vllm/OpenAI: Use response_format
                # Note: vllm may not support strict mode, so we omit it for compatibility
                payload["response_format"] = {
                    "type": "json_schema",
                    "json_schema": {
                        "name": pydantic_model.__name__,
                        "schema": pydantic_model.model_json_schema(),
                    },
                }
                logger.debug(
                    f"Using response_format for {pydantic_model.__name__} ({self.spec.backend})"
                )
            else:
                logger.warning(
                    f"Backend {self.spec.backend} doesn't support structured output, ignoring pydantic_model"
                )
        elif grammar is not None:
            # Raw grammar provided - only works with llama.cpp
            if self.spec.backend == "llamacpp":
                payload["grammar"] = grammar
                logger.debug("Using provided GBNF grammar (llama.cpp)")
            else:
                logger.warning(
                    f"Backend {self.spec.backend} doesn't support GBNF grammar, ignoring"
                )

        # Handle Maxwell backend (local transformers inference)
        if self.spec.backend == "maxwell":
            return self._generate_maxwell(
                messages=messages,
                temperature=temp,
                max_tokens=max_tok,
                pydantic_model=pydantic_model,
            )

        # Make request (OpenAI-compatible) with fallback retry
        endpoint_url = f"{self.spec.api_base.rstrip('/')}/v1/chat/completions"

        # Track performance for dynamic speed calculation
        import time

        start_time = time.time()

        try:
            response = requests.post(endpoint_url, json=payload, timeout=120)
            response.raise_for_status()
            data = response.json()
            elapsed_time = time.time() - start_time

            # Track performance if pool is available
            if self.pool:
                # Extract token count from response (if available)
                usage = data.get("usage", {})
                completion_tokens = usage.get("completion_tokens", 0)

                if completion_tokens > 0:
                    self.pool._track_performance(self.spec.name, completion_tokens, elapsed_time)
                    speed = completion_tokens / elapsed_time if elapsed_time > 0 else 0
                    logger.debug(
                        f"Request to {self.spec.name}: {completion_tokens} tokens in {elapsed_time:.2f}s "
                        f"({speed:.1f} t/s)"
                    )
        except (requests.RequestException, requests.HTTPError, requests.Timeout) as e:
            # If retry is disabled or no pool available, re-raise
            if not retry_on_failure or self.pool is None:
                logger.error(f"Request to {self.spec.name} failed: {e}")
                raise

            # Try to get a healthy fallback LLM
            logger.warning(
                f"Request to {self.spec.name} ({self.spec.api_base}) failed: {e}. "
                "Attempting fallback to next healthy LLM..."
            )

            # Get all healthy LLMs excluding current one
            healthy_llms = self.pool.get_healthy_llms()
            fallback_candidates = [llm for llm in healthy_llms if llm.name != self.spec.name]

            if not fallback_candidates:
                logger.error("No healthy fallback LLMs available")
                raise ValueError(
                    f"Request to {self.spec.name} failed and no healthy fallbacks available"
                ) from e

            # Select best fallback (prefer similar context size)
            original_context = self.spec.capabilities.get("max_context", 4096)
            fallback_spec = min(
                fallback_candidates,
                key=lambda x: abs(x.capabilities.get("max_context", 4096) - original_context),
            )

            logger.info(
                f"Falling back from {self.spec.name} to {fallback_spec.name} "
                f"(context: {fallback_spec.capabilities.get('max_context', 4096)})"
            )

            # Retry with fallback
            fallback_endpoint = f"{fallback_spec.api_base.rstrip('/')}/v1/chat/completions"
            fallback_payload = payload.copy()
            fallback_payload["model"] = fallback_spec.model

            # Handle structured output constraints for fallback
            # Remove structured output from primary, add appropriate format for fallback
            fallback_payload.pop("grammar", None)
            fallback_payload.pop("response_format", None)

            if pydantic_model:
                if fallback_spec.backend == "llamacpp":
                    # Convert to GBNF grammar
                    from maxwell.pydantic_gbnf import generate_gbnf_grammar_and_documentation

                    fallback_grammar, _ = generate_gbnf_grammar_and_documentation([pydantic_model])
                    fallback_payload["grammar"] = fallback_grammar
                    logger.info(f"Using GBNF grammar for fallback {fallback_spec.name}")
                elif fallback_spec.backend in ["vllm", "openai"]:
                    # Convert to response_format (no strict mode for vllm compatibility)
                    fallback_payload["response_format"] = {
                        "type": "json_schema",
                        "json_schema": {
                            "name": pydantic_model.__name__,
                            "schema": pydantic_model.model_json_schema(),
                        },
                    }
                    logger.info(f"Using response_format for fallback {fallback_spec.name}")
                else:
                    logger.warning(
                        f"Fallback {fallback_spec.name} doesn't support structured output"
                    )

            try:
                fallback_start = time.time()
                response = requests.post(fallback_endpoint, json=fallback_payload, timeout=120)
                response.raise_for_status()
                data = response.json()
                fallback_elapsed = time.time() - fallback_start

                # Track fallback performance
                usage = data.get("usage", {})
                completion_tokens = usage.get("completion_tokens", 0)
                if completion_tokens > 0:
                    self.pool._track_performance(
                        fallback_spec.name, completion_tokens, fallback_elapsed
                    )
                    speed = completion_tokens / fallback_elapsed if fallback_elapsed > 0 else 0
                    logger.debug(
                        f"Fallback request to {fallback_spec.name}: {completion_tokens} tokens in "
                        f"{fallback_elapsed:.2f}s ({speed:.1f} t/s)"
                    )

                # Update self.spec to reflect the fallback (for logging)
                self.spec = fallback_spec
                logger.info(f"Fallback request to {fallback_spec.name} succeeded")
            except Exception as fallback_error:
                logger.error(
                    f"Fallback request to {fallback_spec.name} also failed: {fallback_error}"
                )
                raise ValueError(
                    f"Both primary ({self.spec.name}) and fallback ({fallback_spec.name}) requests failed"
                ) from fallback_error

        # JSONL logging for debugging
        import json as json_module
        import os
        from pathlib import Path

        # Create logs directory relative to current working directory (can be disabled with NO_JSONL_LOGGING env var)
        if os.getenv("NO_JSONL_LOGGING"):
            return data["choices"][0]["message"]["content"]

        # Use execution directory for logs (current working directory)
        base_dir = Path.cwd() / ".maxwell"
        log_dir = base_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)

        # Use workflow config session_id if available, otherwise generate
        session_id = None
        if isinstance(messages, dict) and "workflow_config" in messages:  # type: ignore[unreachable]
            config = messages["workflow_config"]  # type: ignore[index]
            if hasattr(config, "session_id") and config.session_id:
                session_id = config.session_id
                logger.info(f"Using workflow session ID: {session_id}")
            else:
                session_id = _get_or_create_session_id()
                logger.info(f"No workflow session ID, using generated: {session_id}")
        else:
            # Fallback for non-workflow calls
            session_id = _get_or_create_session_id()
            logger.info(f"No workflow config, using generated session ID: {session_id}")

        jsonl_file = log_dir / f"{session_id}.jsonl"

        logger.info(f"JSONL logging enabled: {jsonl_file}")

        # Log request/response pair
        log_entry = {
            "timestamp": datetime.datetime.now().isoformat(),
            "model": self.spec.model,
            "request": messages,
            "response": data,
            "response_raw": data,
            "grammar_used": grammar is not None,
        }

        with open(jsonl_file, "a", encoding="utf-8") as f:
            f.write(json_module.dumps(log_entry) + "\n")

        return data["choices"][0]["message"]["content"]

    def _generate_maxwell(
        self,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: int,
        pydantic_model: Optional[Any] = None,
    ) -> str:
        """Generate using Maxwell's native transformers backend.

        Supports:
        - Single model inference
        - R-Stitch entropy-guided routing
        - LoRA adapters

        Args:
            messages: Chat messages in OpenAI format
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            pydantic_model: Optional pydantic model for structured output

        Returns:
            Generated text

        """
        from transformers import AutoTokenizer

        from maxwell.models import MaxwellModel

        # Get maxwell config
        maxwell_config = (
            self.spec.model_extra.get("maxwell_config", {})
            if hasattr(self.spec, "model_extra")
            else {}
        )
        if not maxwell_config:
            # Try getting from spec dict directly (Pydantic v1/v2 compatibility)
            maxwell_config = getattr(self.spec, "maxwell_config", {})

        # Construct prompt from messages
        prompt = self._format_messages(messages)

        # Lazy load model and tokenizer
        if not hasattr(self, "_maxwell_model"):
            logger.info(f"Loading Maxwell model: {self.spec.model}")

            import torch

            dtype_map = {
                "float16": torch.float16,
                "bfloat16": torch.bfloat16,
                "float32": torch.float32,
            }
            torch_dtype = dtype_map.get(maxwell_config.get("torch_dtype", "float16"), torch.float16)

            self._maxwell_model = MaxwellModel.from_pretrained(
                self.spec.model,
                device_map=maxwell_config.get("device", "auto"),
                torch_dtype=torch_dtype,
                load_in_4bit=maxwell_config.get("load_in_4bit", False),
                load_in_8bit=maxwell_config.get("load_in_8bit", False),
            )
            self._maxwell_tokenizer = AutoTokenizer.from_pretrained(self.spec.model)

        # Use standard transformers API
        inputs = self._maxwell_tokenizer(prompt, return_tensors="pt").to(
            self._maxwell_model.model.device
        )
        outputs = self._maxwell_model.generate(
            **inputs, max_new_tokens=max_tokens, temperature=temperature
        )
        text = self._maxwell_tokenizer.decode(outputs[0], skip_special_tokens=True)

        # Handle structured output if requested
        if pydantic_model is not None:
            text = self._extract_json_for_pydantic(text, pydantic_model)

        return text

    def _format_messages(self, messages: List[Dict[str, str]]) -> str:
        """Format OpenAI-style messages into a single prompt string.

        Args:
            messages: List of message dicts with 'role' and 'content'

        Returns:
            Formatted prompt string

        """
        prompt_parts = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if role == "system":
                prompt_parts.append(f"System: {content}")
            elif role == "user":
                prompt_parts.append(f"User: {content}")
            elif role == "assistant":
                prompt_parts.append(f"Assistant: {content}")

        prompt_parts.append("Assistant:")  # Prompt for response
        return "\n\n".join(prompt_parts)

    def _extract_json_for_pydantic(self, text: str, pydantic_model: Any) -> str:
        """Extract JSON from generated text for pydantic model validation.

        Args:
            text: Generated text that may contain JSON
            pydantic_model: Pydantic model for validation

        Returns:
            JSON string matching the pydantic schema

        """
        import json
        import re

        # Try to find JSON in the text
        # Look for {...} or [{...}]
        json_match = re.search(r"(\{.*\}|\[.*\])", text, re.DOTALL)

        if json_match:
            json_str = json_match.group(1)
            try:
                # Validate against pydantic model
                obj = json.loads(json_str)
                validated = (
                    pydantic_model(**obj)
                    if isinstance(obj, dict)
                    else pydantic_model.model_validate(obj)
                )
                return validated.model_dump_json()
            except Exception as e:
                logger.warning(f"Failed to validate JSON against pydantic model: {e}")
                return text
        else:
            logger.warning("No JSON found in maxwell backend output for pydantic model")
            return text

    def complete_with_tools(
        self,
        messages: List[Dict[str, str]],
        tools: List[Dict[str, Any]],
        max_iterations: int = 5,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Generate with tool calling support (OpenAI-compatible).

        Implements ReAct pattern: model can call tools repeatedly until task is done.

        Args:
            messages: Chat messages in OpenAI format
            tools: List of tool definitions in OpenAI format
            max_iterations: Max ReAct iterations (default: 5)
            temperature: Sampling temperature
            max_tokens: Max tokens per generation

        Returns:
            Dict with 'content' (final response) and 'tool_calls' (history)

        Example:
            tools = [{
                "type": "function",
                "function": {
                    "name": "research",
                    "description": "Search codebase",
                    "parameters": {
                        "type": "object",
                        "properties": {"query": {"type": "string"}},
                        "required": ["query"]
                    }
                }
            }]

            result = client.complete_with_tools(
                messages=[{"role": "user", "content": "Find AuthContext"}],
                tools=tools
            )

        """
        import json

        import requests

        temp = temperature if temperature is not None else self.spec.default_temperature
        max_tok = (
            max_tokens if max_tokens is not None else self.spec.capabilities.get("max_tokens", 2000)
        )

        conversation = list(messages)  # Copy to avoid mutation
        tool_call_history = []

        for iteration in range(max_iterations):
            # Make request with tools
            payload = {
                "model": self.spec.model,
                "messages": conversation,
                "temperature": temp,
                "max_tokens": max_tok,
                "tools": tools,
            }

            endpoint_url = f"{self.spec.api_base.rstrip('/')}/v1/chat/completions"

            try:
                response = requests.post(endpoint_url, json=payload, timeout=120)
                response.raise_for_status()
                data = response.json()
            except Exception as e:
                logger.error(f"Tool calling request failed: {e}")
                raise

            message = data["choices"][0]["message"]
            finish_reason = data["choices"][0].get("finish_reason")

            # Check if model wants to call tools
            if finish_reason == "tool_calls" and "tool_calls" in message:
                tool_calls = message["tool_calls"]
                logger.info(f"Model requested {len(tool_calls)} tool calls")

                # Add assistant message with tool calls
                conversation.append(message)

                # Execute each tool call
                for tool_call in tool_calls:
                    function_name = tool_call["function"]["name"]
                    function_args = json.loads(tool_call["function"]["arguments"])

                    logger.info(f"Executing tool: {function_name}({function_args})")

                    # Execute tool via MCP or Maxwell workflow
                    tool_result = self._execute_tool(function_name, function_args)

                    tool_call_history.append(
                        {
                            "name": function_name,
                            "arguments": function_args,
                            "result": tool_result,
                        }
                    )

                    # Add tool result to conversation
                    conversation.append(
                        {
                            "role": "tool",
                            "tool_call_id": tool_call.get("id", f"call_{iteration}"),
                            "name": function_name,
                            "content": json.dumps(tool_result),
                        }
                    )

                # Continue to next iteration (model will see tool results)
                continue

            # No tool calls - model is done
            logger.info(f"Tool calling complete after {iteration + 1} iterations")
            return {
                "content": message.get("content", ""),
                "tool_calls": tool_call_history,
                "iterations": iteration + 1,
            }

        # Hit max iterations
        logger.warning(f"Reached max iterations ({max_iterations})")
        return {
            "content": conversation[-1].get("content", ""),
            "tool_calls": tool_call_history,
            "iterations": max_iterations,
        }

    def _execute_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a tool call (MCP or Maxwell workflow).

        Args:
            tool_name: Tool/function name
            arguments: Tool arguments

        Returns:
            Tool execution result

        """
        # Built-in tool: research (deep_research workflow)
        if tool_name == "research":
            from maxwell.api import execute_workflow

            query = arguments.get("query", "")
            logger.info(f"Executing research workflow: {query}")

            try:
                result = execute_workflow(
                    workflow_id="deep_research",
                    research_question=query,
                    max_iterations=2,
                    results_per_query=5,
                )

                # Extract findings from workflow result
                findings = result.artifacts.get("findings", [])
                summary = "\n\n".join([f"**{f['title']}**\n{f['summary']}" for f in findings[:3]])

                return {
                    "success": True,
                    "results": summary,
                    "num_findings": len(findings),
                }
            except Exception as e:
                logger.error(f"Research tool failed: {e}")
                return {"success": False, "error": str(e)}

        # Unknown tool
        else:
            logger.warning(f"Unknown tool: {tool_name}")
            return {"success": False, "error": f"Unknown tool: {tool_name}"}


def get_lm(
    name: Optional[str] = None,
    prompt: Optional[str] = None,
    max_completion: int = 512,
    time_cost_weight: float = 1.0,
    **selection_kwargs,
) -> LLMClient:
    """Get a language model (LM) client from the pool.

    Args:
        name: Specific LM name, or None to select by capabilities
        prompt: Optional prompt for intelligent routing (enables scheduler)
        max_completion: Expected completion tokens (used with prompt)
        time_cost_weight: How much to value speed vs cost (0-10, used with prompt)
        **selection_kwargs: Capability filters (min_speed, reasoning, vision, etc.)

    Returns:
        LLMClient ready to use

    Examples:
        # Get default (fastest) LM
        lm = get_lm()

        # Get specific LM by name
        lm = get_lm("qwen-coder-30b")

        # Intelligent routing based on prompt size
        lm = get_lm(prompt="Write a function...", time_cost_weight=1.0)

        # Select by capabilities
        lm = get_lm(reasoning=True, min_speed=50)
        lm = get_lm(vision=True)

    """
    pool = LLMPool.from_registry()

    if name:
        spec = pool.get_lm(name)
    elif prompt:
        # Use intelligent routing when prompt is provided
        spec = pool.select_optimal_llm(
            prompt,
            max_completion=max_completion,
            time_cost_weight=time_cost_weight,
            **selection_kwargs,
        )
    elif selection_kwargs:
        spec = pool.select_llm(**selection_kwargs)
    else:
        spec = pool.get_fastest_llm()

    if not spec:
        raise ValueError(f"No LM found matching criteria: name={name}, {selection_kwargs}")

    # Pass pool reference to enable fallback on failure
    return LLMClient(spec, pool=pool)


def get_embedding(name: str = "default") -> EmbeddingSpec:
    """Get an embedding model from the pool.

    Args:
        name: Embedding name or tag (default: "default")

    Returns:
        EmbeddingSpec with embed() method

    Examples:
        # Get default embedding
        emb = get_embedding()
        vector = emb.embed("some text")

        # Get specific embedding by name
        emb = get_embedding("qwen-embed-4b")

    """
    pool = LLMPool.from_registry()
    spec = pool.get_embedding(name)

    if not spec:
        raise ValueError(f"Embedding '{name}' not found. Available: {pool.list_embeddings()}")

    return spec
