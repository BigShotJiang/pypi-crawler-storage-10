"""Logging configuration for Maxwell.

Sets up dual logging:
1. Console (stderr): INFO and above → users see progress and errors
2. File (maxwell.log): DEBUG and above → detailed debugging info
3. LLM conversation logs: Continue to .maxwell/logs/<session>.jsonl (unchanged)

Key design decisions:
- stderr for console (not stdout) - keeps stdout clean for JSON/reports
- INFO level console output - users see what's happening normally
- DEBUG level file logging - developers get full detail for debugging
- Simple console format, detailed file format with timestamps/line numbers

Usage:
    from maxwell.logging_config import setup_logging
    setup_logging(project_root)
"""

import logging
import sys
from pathlib import Path


def setup_logging(
    project_root: Path | None = None,
    log_level: int = logging.INFO,
    enable_console: bool = True,
    enable_file: bool = True,
) -> None:
    """Configure logging for Maxwell.

    Args:
        project_root: Project root directory (defaults to cwd)
        log_level: Minimum log level (default: INFO)
        enable_console: Enable console logging to stderr (default: True)
        enable_file: Enable file logging to .maxwell/logs/maxwell.log (default: True)

    """
    if project_root is None:
        project_root = Path.cwd()

    # Get root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)  # Capture everything, filter at handler level

    # Clear existing handlers to avoid duplicates
    root_logger.handlers.clear()

    # Create formatters
    console_formatter = logging.Formatter(
        "%(levelname)s: %(message)s"  # Simple format for console
    )

    file_formatter = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s:%(lineno)d - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Console handler (stderr) - INFO and above so users see what's happening
    if enable_console:
        console_handler = logging.StreamHandler(sys.stderr)
        console_handler.setLevel(log_level)  # Show INFO and above by default
        console_handler.setFormatter(console_formatter)
        root_logger.addHandler(console_handler)

    # File handler - DEBUG and above for detailed debugging
    if enable_file:
        log_dir = project_root / ".maxwell" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)

        # Use maxwell.log for general logging (not just errors)
        log_path = log_dir / "maxwell.log"

        file_handler = logging.FileHandler(log_path, mode="a", encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)  # Log everything to file
        file_handler.setFormatter(file_formatter)
        root_logger.addHandler(file_handler)

    # Log initialization message
    root_logger.info(f"Maxwell logging initialized (level={logging.getLevelName(log_level)})")


def log_exception(logger: logging.Logger, message: str, exc_info: bool = True) -> None:
    """Log an exception with full traceback.

    Args:
        logger: Logger instance
        message: Error message
        exc_info: Include exception traceback (default: True)

    """
    logger.error(message, exc_info=exc_info)
