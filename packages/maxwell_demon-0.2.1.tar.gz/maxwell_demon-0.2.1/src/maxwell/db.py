"""Database connection helpers.

Simple helpers to load MongoDB and Qdrant connections from ~/.maxwell/db_registry.json

Usage:
    from maxwell.db import get_mongodb, get_qdrant

    mongo = get_mongodb()
    qdrant = get_qdrant()
"""

__all__ = ["get_mongodb", "get_qdrant"]

import json
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_REGISTRY_PATH = Path.home() / ".maxwell" / "db_registry.json"


def _load_registry() -> dict:
    """Load database registry from ~/.maxwell/db_registry.json"""
    if not _REGISTRY_PATH.exists():
        raise FileNotFoundError(
            f"Database registry not found at {_REGISTRY_PATH}. "
            "Please create it with MongoDB and Qdrant configurations."
        )

    with open(_REGISTRY_PATH) as f:
        return json.load(f)


def get_mongodb(database: Optional[str] = None):
    """Get MongoDB client from registry.

    Args:
        database: Optional database name. If not provided, uses the one from registry.

    Returns:
        MongoClient instance

    """
    from pymongo import MongoClient

    registry = _load_registry()

    # Find MongoDB config (tagged as 'default' and 'chat')
    mongo_config = None
    for db in registry.get("databases", []):
        if db.get("type") == "mongodb" and "default" in db.get("tags", []):
            mongo_config = db
            break

    if not mongo_config:
        raise ValueError("No default MongoDB configuration found in registry")

    host = mongo_config.get("host", "localhost")
    port = mongo_config.get("port", 27017)
    db_name = database or mongo_config.get("database", "chat_analytics")

    uri = f"mongodb://{host}:{port}"
    logger.debug(f"Connecting to MongoDB at {uri}, database: {db_name}")

    client = MongoClient(uri)
    return client[db_name]


def get_qdrant():
    """Get Qdrant client from registry.

    Returns:
        QdrantClient instance

    """
    from qdrant_client import QdrantClient

    registry = _load_registry()

    # Find Qdrant config (tagged as 'default' and 'vector')
    qdrant_config = None
    for db in registry.get("databases", []):
        if db.get("type") == "qdrant" and "default" in db.get("tags", []):
            qdrant_config = db
            break

    if not qdrant_config:
        raise ValueError("No default Qdrant configuration found in registry")

    host = qdrant_config.get("host", "localhost")
    port = qdrant_config.get("port", 6333)

    logger.debug(f"Connecting to Qdrant at {host}:{port}")

    return QdrantClient(host=host, port=port)
