"""Universal serialization utilities for Maxwell.

Provides consistent to_dict() interface across dataclasses, Pydantic models,
namedtuples, and regular objects.

Requires Python 3.11+
"""

from dataclasses import asdict, is_dataclass
from typing import Any

__all__ = ["to_dict", "SerializationError"]


class SerializationError(Exception):
    """Raised when an object cannot be serialized to dict."""

    pass


def to_dict(obj: Any, *, exclude_none: bool = False) -> dict[str, Any]:
    """Convert any object to a dictionary.

    Supports:
    - Dataclasses (via dataclasses.asdict)
    - Pydantic models (via .model_dump() or .dict())
    - Named tuples (via ._asdict())
    - Dicts (passthrough)
    - Objects with __dict__ (fallback)

    Args:
        obj: Object to serialize
        exclude_none: If True, exclude None values from output (only for Pydantic)

    Returns:
        Dictionary representation of the object

    Raises:
        SerializationError: If object cannot be serialized

    Examples:
        >>> from dataclasses import dataclass
        >>> @dataclass
        ... class User:
        ...     name: str
        ...     age: int
        >>> to_dict(User("Alice", 30))
        {'name': 'Alice', 'age': 30}

    """
    # Already a dict - passthrough
    if isinstance(obj, dict):
        return obj

    # Dataclass (most common in Maxwell)
    if is_dataclass(obj):
        return asdict(obj)

    # Pydantic v2 (model_dump is the new API)
    if hasattr(obj, "model_dump") and callable(obj.model_dump):
        return obj.model_dump(exclude_none=exclude_none)

    # Pydantic v1 (legacy)
    if hasattr(obj, "dict") and callable(obj.dict):
        return obj.dict(exclude_none=exclude_none)

    # Named tuple
    if hasattr(obj, "_asdict") and callable(obj._asdict):
        return obj._asdict()

    # Fallback: try __dict__ (works for simple classes)
    if hasattr(obj, "__dict__"):
        result = obj.__dict__.copy()
        if exclude_none:
            return {k: v for k, v in result.items() if v is not None}
        return result

    # Give up
    raise SerializationError(
        f"Cannot serialize object of type {type(obj).__name__}. "
        f"Supported types: dataclasses, Pydantic models, namedtuples, dicts, objects with __dict__"
    )
