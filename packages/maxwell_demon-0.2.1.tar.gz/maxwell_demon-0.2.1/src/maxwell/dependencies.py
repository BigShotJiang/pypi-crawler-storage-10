"""Dependency checking utilities for workflows with optional dependencies.

Usage:
    @requires_dependencies(['numpy', 'pandas'])
    @register_workflow(...)
    class MyWorkflow(BaseWorkflow):
        ...
"""

import functools
import importlib.metadata
import logging
from typing import List, Optional

logger = logging.getLogger(__name__)

__all__ = ["requires_dependencies", "check_dependencies"]


def check_dependencies(packages: List[str]) -> tuple[bool, Optional[str]]:
    """Check if required packages are installed.

    Args:
        packages: List of package names to check

    Returns:
        (all_available, missing_package_name)
    """
    for package in packages:
        try:
            importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            return False, package
    return True, None


def requires_dependencies(packages: List[str], extras_name: Optional[str] = None):
    """Decorator to check dependencies before registering a workflow.

    If dependencies are missing, the decorator prevents registration and logs
    a debug message instead of raising an error.

    Args:
        packages: List of package names required
        extras_name: Name of extras group for installation instructions

    Example:
        @requires_dependencies(['pymongo', 'qdrant-client'], extras_name='chat')
        @register_workflow(...)
        class ChatWorkflow(BaseWorkflow):
            ...
    """

    def decorator(cls):
        available, missing = check_dependencies(packages)

        if not available:
            install_msg = (
                f"pip install maxwell-demon[{extras_name}]"
                if extras_name
                else f"pip install {missing}"
            )
            logger.debug(
                f"Skipping registration of {cls.__name__}: "
                f"missing {missing}. Install with: {install_msg}"
            )
            # Return a stub that won't be registered
            # The @register_workflow decorator will be called but on a dummy class
            return type(
                f"_Unavailable{cls.__name__}",
                (),
                {"__module__": cls.__module__, "__doc__": cls.__doc__},
            )

        # Dependencies available, return original class for registration
        return cls

    return decorator
