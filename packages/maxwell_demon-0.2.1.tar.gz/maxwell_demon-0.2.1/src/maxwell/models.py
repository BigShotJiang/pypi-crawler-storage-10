"""Local model infrastructure for Maxwell.

This module provides wrappers and utilities for running models locally:
- MaxwellModel: Drop-in replacement for transformers with extras (LoRA, entropy tracking)

This is core infrastructure (network I/O: model loading), not business logic.
Business logic workflows (like ResearchAugmentedGenerator) should be in workflows/.
"""

import hashlib
import logging
from typing import Dict, List, Optional, Tuple

import torch
from transformers import AutoModelForCausalLM

logger = logging.getLogger(__name__)

__all__ = ["MaxwellModel"]


class MaxwellModel(torch.nn.Module):
    """Drop-in replacement for AutoModelForCausalLM with Maxwell extras.

    100% compatible with transformers API - you can use this exactly like
    AutoModelForCausalLM, plus get entropy tracking, LoRA management, etc.

    Example:
        # Instead of:
        # model = AutoModelForCausalLM.from_pretrained("Qwen/Qwen2.5-7B-Instruct")

        # Use:
        from maxwell.models import MaxwellModel
        model = MaxwellModel.from_pretrained("Qwen/Qwen2.5-7B-Instruct")

        # All standard methods work
        outputs = model(**inputs)
        outputs = model.generate(**gen_inputs)

        # Plus Maxwell extras
        outputs, entropies = model.generate_with_entropy(**gen_inputs)

    """

    def __init__(self, model: AutoModelForCausalLM):
        """Wrap a transformers model with Maxwell functionality.

        Args:
            model: Pre-loaded transformers model

        """
        super().__init__()
        self.model = model
        self.config = model.config
        self.generation_config = model.generation_config

        # LoRA adapters registry
        self.lora_adapters: Dict[str, str] = {}
        self.active_lora: Optional[str] = None

    @classmethod
    def from_pretrained(
        cls,
        model_path: str,
        device_map: str = "auto",
        torch_dtype: Optional[torch.dtype] = None,
        trust_remote_code: bool = False,
        load_in_8bit: bool = False,
        load_in_4bit: bool = False,
        **kwargs,
    ) -> "MaxwellModel":
        """Load a model from pretrained - same API as transformers.

        Args:
            model_path: HuggingFace model ID or local path
            device_map: Device placement (default: "auto")
            torch_dtype: Data type (default: torch.float16)
            trust_remote_code: Trust remote code for custom models
            load_in_8bit: Use 8-bit quantization
            load_in_4bit: Use 4-bit quantization
            **kwargs: Additional arguments passed to AutoModelForCausalLM

        Returns:
            MaxwellModel instance wrapping the transformers model

        """
        logger.info(f"Loading Maxwell model: {model_path}")

        if torch_dtype is None:
            torch_dtype = torch.float16

        load_kwargs = {
            "device_map": device_map,
            "torch_dtype": torch_dtype,
            "trust_remote_code": trust_remote_code,
            **kwargs,
        }

        if load_in_8bit:
            load_kwargs["load_in_8bit"] = True
        elif load_in_4bit:
            load_kwargs["load_in_4bit"] = True

        model = AutoModelForCausalLM.from_pretrained(model_path, **load_kwargs)
        model.eval()

        logger.info(f"Maxwell model loaded: {model_path}")
        return cls(model)

    def forward(self, *args, **kwargs):
        """Forward pass - delegates to underlying model."""
        return self.model(*args, **kwargs)

    def __call__(self, *args, **kwargs):
        """Call - delegates to underlying model."""
        return self.model(*args, **kwargs)

    def __getattr__(self, name: str):
        """Delegate attribute access to underlying model.

        This makes MaxwellModel a perfect drop-in replacement.
        """
        try:
            return super().__getattr__(name)
        except AttributeError:
            # Delegate to wrapped model
            return getattr(self.model, name)

    # Maxwell-specific methods (extras beyond transformers API)

    def load_lora_adapter(self, adapter_path: str, adapter_name: Optional[str] = None):
        """Maxwell extra: Load a LoRA adapter.

        Args:
            adapter_path: Path to LoRA adapter weights
            adapter_name: Optional name (default: hash of path)

        """
        try:
            from peft import PeftModel
        except ImportError:
            logger.error("LoRA requires 'peft': pip install peft")
            raise

        if adapter_name is None:
            adapter_name = hashlib.md5(adapter_path.encode()).hexdigest()[:8]

        logger.info(f"Loading LoRA: {adapter_path} as '{adapter_name}'")
        self.model = PeftModel.from_pretrained(self.model, adapter_path, adapter_name=adapter_name)
        self.lora_adapters[adapter_name] = adapter_path
        self.active_lora = adapter_name
        logger.info(f"LoRA '{adapter_name}' loaded")

    def switch_lora_adapter(self, adapter_name: str):
        """Maxwell extra: Switch LoRA adapter."""
        if adapter_name not in self.lora_adapters:
            raise ValueError(f"Adapter '{adapter_name}' not loaded")
        self.model.set_adapter(adapter_name)
        self.active_lora = adapter_name
        logger.info(f"Switched to LoRA: {adapter_name}")

    def disable_lora(self):
        """Maxwell extra: Disable LoRA, use base model."""
        if hasattr(self.model, "disable_adapter"):
            self.model.disable_adapter()
            self.active_lora = None
            logger.info("LoRA disabled")

    def generate_with_entropy(
        self,
        input_ids: Optional[torch.Tensor] = None,
        **kwargs,
    ) -> Tuple[torch.Tensor, List[float]]:
        """Maxwell extra: Generate with per-token entropy tracking.

        Same as model.generate() but returns (output_ids, entropy_list).

        Args:
            input_ids: Input token IDs
            **kwargs: Same arguments as transformers generate()

        Returns:
            (generated_ids, per_token_entropies)

        Example:
            outputs, entropies = model.generate_with_entropy(
                input_ids, max_new_tokens=50
            )
            print(f"Mean entropy: {sum(entropies)/len(entropies):.3f}")

        """
        # This is a Maxwell-specific method that wraps standard generation
        # For now, delegate to standard generate() - full implementation would
        # require custom GenerationMixin which we can add if needed
        logger.warning("generate_with_entropy() not fully implemented yet.")
        outputs = self.model.generate(input_ids=input_ids, **kwargs)
        return outputs, []
