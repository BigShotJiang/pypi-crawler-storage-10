"""Test that Maxwell works without optional dependencies."""

def test_numpy_not_installed():
    """numpy should not be installed in minimal environment."""
    try:
        import numpy
        assert False, "numpy should not be installed in minimal environment"
    except ImportError:
        pass  # Expected


def test_maxwell_imports():
    """Maxwell should be importable without optional deps."""
    import maxwell
    assert maxwell is not None


def test_registry_works():
    """Workflow registry should work without optional deps."""
    from maxwell.registry import get_workflow_registry

    registry = get_workflow_registry()
    workflows = registry.list_workflow_ids()

    assert len(workflows) > 0, "Should have at least one workflow"
    assert "validate" in workflows, "validate should always be available"
    assert "get-time" in workflows, "get-time should always be available"


def test_agentic_refactoring_not_available():
    """agentic-refactoring should not be available without numpy."""
    from maxwell.registry import get_workflow_registry

    registry = get_workflow_registry()
    workflows = registry.list_workflow_ids()

    # agentic-refactoring requires numpy, should not be in list
    assert "agentic-refactoring" not in workflows, \
        "agentic-refactoring should not be available without numpy"


def test_chat_workflows_not_available():
    """Chat workflows should not be available without pymongo/qdrant."""
    from maxwell.registry import get_workflow_registry

    registry = get_workflow_registry()
    workflows = registry.list_workflow_ids()

    # Chat workflows require pymongo and qdrant-client
    chat_workflows = [w for w in workflows if "chat" in w or "temporal" in w]
    assert len(chat_workflows) == 0, \
        f"Chat workflows should not be available without optional deps: {chat_workflows}"
