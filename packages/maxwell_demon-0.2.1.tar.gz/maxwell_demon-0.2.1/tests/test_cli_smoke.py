"""Smoke tests for Maxwell CLI and core workflows.

These tests verify that basic functionality works without errors.
"""

import subprocess
import sys
from pathlib import Path

import pytest


def test_maxwell_cli_exists():
    """Test that maxwell CLI is available."""
    result = subprocess.run(
        ["maxwell", "--help"],
        capture_output=True,
        text=True,
        timeout=10,
    )
    assert result.returncode == 0 or "maxwell" in result.stderr.lower()


def test_list_workflows():
    """Test that list-workflows command works."""
    result = subprocess.run(
        ["maxwell", "list-workflows"],
        capture_output=True,
        text=True,
        timeout=10,
    )
    assert result.returncode == 0
    assert "validate" in result.stdout
    assert "agentic-refactoring" in result.stdout


def test_validate_help():
    """Test that validate workflow shows help."""
    result = subprocess.run(
        ["maxwell", "validate", "--help"],
        capture_output=True,
        text=True,
        timeout=10,
    )
    assert result.returncode == 0
    assert "--format" in result.stdout or "--format" in result.stderr


def test_get_time_workflow():
    """Test simple utility workflow."""
    result = subprocess.run(
        ["maxwell", "get-time"],
        capture_output=True,
        text=True,
        timeout=10,
    )
    assert result.returncode == 0
    # Should output an ISO timestamp
    assert len(result.stdout.strip()) > 0


def test_imports_core():
    """Test that core modules can be imported."""
    from maxwell import api, cli, config, registry
    from maxwell.workflows import base

    assert api is not None
    assert cli is not None
    assert config is not None
    assert registry is not None
    assert base is not None


def test_imports_workflows():
    """Test that workflow modules can be imported."""
    from maxwell.workflows import (
        agentic_refactoring,
        architecture_lint,
        docstring_enrichment,
        snapshot,
        tag_refactor,
        utilities,
        web_scrape,
    )

    assert agentic_refactoring is not None
    assert architecture_lint is not None
    assert docstring_enrichment is not None
    assert snapshot is not None
    assert tag_refactor is not None
    assert utilities is not None
    assert web_scrape is not None


def test_workflow_registry():
    """Test that workflow registry loads properly."""
    from maxwell.registry import get_workflow_registry

    registry = get_workflow_registry()
    workflows = registry.list_workflow_ids()

    assert len(workflows) > 0
    assert "validate" in workflows
    assert "list-workflows" in workflows or "get-time" in workflows


def test_validate_runs():
    """Test that validate workflow runs without errors."""
    result = subprocess.run(
        ["maxwell", "validate", "--format", "json"],
        capture_output=True,
        text=True,
        timeout=60,
        cwd=Path(__file__).parent.parent,
    )
    # Validate should always succeed even if there are findings
    assert result.returncode == 0
    # Should output valid JSON
    assert result.stdout.strip().startswith("{")


def test_api_execute_workflow():
    """Test that API can execute a simple workflow."""
    from maxwell.api import execute_workflow
    from pathlib import Path

    result = execute_workflow(
        "get-time",
        Path.cwd(),
        {"format": "iso"},
    )

    assert result.status.value == "completed"
    assert result.artifacts is not None


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
