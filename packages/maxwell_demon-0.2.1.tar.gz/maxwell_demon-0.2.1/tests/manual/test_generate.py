"""Test docstring generation with LLM."""

import libcst as cst
from pathlib import Path
from maxwell.workflows.docstring_enrichment import UndocumentedExtractor, DocstringEnrichmentWorkflow
from maxwell.lm_pool import get_lm

# Read test file
test_file = Path("examples/test_docstring.py")
source_code = test_file.read_text()

# Parse and extract
tree = cst.parse_module(source_code)
extractor = UndocumentedExtractor()
tree.visit(extractor)

print(f"Found {len(extractor.undocumented)} undocumented items\n")

# Get LLM
llm = get_lm()
print(f"Using LLM: {llm.spec.name}\n")

# Create workflow instance
workflow = DocstringEnrichmentWorkflow()

# Generate docstrings for first 2 items
batch = extractor.undocumented[:2]
docstrings = workflow._generate_docstrings_batch(batch, llm, language="python")

print(f"Generated {len(docstrings)} docstrings:\n")
for name, docstring in docstrings.items():
    print(f"{name}:")
    print(f'"""{docstring}"""')
    print()
