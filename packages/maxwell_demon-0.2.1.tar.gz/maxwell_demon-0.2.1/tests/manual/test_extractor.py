"""Test spec extractors on portfolio codebase."""

from pathlib import Path
from maxwell.workflows.refactor.extractors import JavaScriptSpecExtractor

# Test on a Next.js file
portfolio_file = Path.home() / "Documents" / "portfolio" / "app" / "page.tsx"

if portfolio_file.exists():
    print(f"Extracting from {portfolio_file}...\n")

    functions, classes = JavaScriptSpecExtractor.extract_from_file(portfolio_file)

    print(f"Found {len(functions)} functions and {len(classes)} classes\n")

    for func in functions:
        print(f"Function: {func.signature()}")
        print(f"  Language: {func.language}")
        if func.docstring:
            print(f"  Doc: {func.docstring[:80]}...")
        print()

    for cls in classes:
        print(f"Class: {cls.name}")
        if cls.inherits_from:
            print(f"  Extends: {', '.join(cls.inherits_from)}")
        print()
else:
    print(f"File not found: {portfolio_file}")
