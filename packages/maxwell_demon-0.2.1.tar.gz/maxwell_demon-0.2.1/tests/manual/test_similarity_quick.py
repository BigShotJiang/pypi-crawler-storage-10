"""Quick test of similarity graph with just a few cliques."""

from pathlib import Path

from maxwell.workflows.refactor.extractors import PythonSpecExtractor
from maxwell.workflows.refactor.graph_builder import CodeGraph
from maxwell.workflows.refactor.optimizer import DRYOptimizer
import numpy as np
from maxwell.lm_pool import get_embedding


def test_quick():
    """Test on a small subset of files."""
    # Just test on refactor module
    refactor_dir = Path("src/maxwell/workflows/refactor")
    py_files = list(refactor_dir.glob("*.py"))[:3]  # Just 3 files

    print(f"Testing on {len(py_files)} files...\n")

    graph = CodeGraph(similarity_threshold=0.80)
    source_map = {}

    for py_file in py_files:
        functions, classes = PythonSpecExtractor.extract_from_file(py_file)
        source_map[py_file] = py_file.read_text()

        for func in functions:
            graph.add_function(func)
        for cls in classes:
            graph.add_class(cls)

    print(f"Extracted {len(graph.functions)} functions")

    # Build graphs
    print("Building call graph...")
    graph.build_call_graph(source_map)

    print("Building similarity graph...")
    embedding_client = get_embedding()

    def embed_fn(text: str) -> np.ndarray:
        return np.array(embedding_client.embed(text))

    graph.build_similarity_graph(embedding_fn=embed_fn)

    stats = graph.stats()
    print(f"Stats: {stats}")

    # Analyze duplicates
    print("\nAnalyzing duplicates...")
    optimizer = DRYOptimizer(graph)
    actions = optimizer.analyze_duplicates()

    print(f"\nCompleted! Generated {len(actions)} refactoring actions")


if __name__ == "__main__":
    test_quick()
