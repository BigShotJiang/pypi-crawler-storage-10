"""Test docstring extraction."""

import libcst as cst
from pathlib import Path
from maxwell.workflows.docstring_enrichment import UndocumentedExtractor

# Read test file
test_file = Path("examples/test_docstring.py")
source_code = test_file.read_text()

# Parse and extract
tree = cst.parse_module(source_code)
extractor = UndocumentedExtractor()
tree.visit(extractor)

print(f"Found {len(extractor.undocumented)} undocumented items:")
for item in extractor.undocumented:
    print(f"  - {item['type']} {item['name']}")
    if item.get('params'):
        print(f"    params: {item['params']}")
