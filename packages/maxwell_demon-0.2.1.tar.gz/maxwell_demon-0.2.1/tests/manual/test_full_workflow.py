"""Test complete agentic refactoring workflow on Maxwell codebase."""

from pathlib import Path

from maxwell.workflows.agentic_refactoring import run_agentic_refactoring


def test_on_maxwell():
    """Test agentic refactoring on Maxwell codebase."""
    project_root = Path.cwd()

    print("=" * 60)
    print("AGENTIC REFACTORING TEST")
    print("=" * 60)

    # Run workflow
    results = run_agentic_refactoring(
        project_root=project_root,
        similarity_threshold=0.75,
        languages=["python"],  # Just Python for now
        dry_run=True,
    )

    print("\n" + "=" * 60)
    print("RESULTS")
    print("=" * 60)
    for key, value in results.items():
        print(f"{key}: {value}")


if __name__ == "__main__":
    test_on_maxwell()
