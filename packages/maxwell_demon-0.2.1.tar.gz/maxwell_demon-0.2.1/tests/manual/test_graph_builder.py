"""Test graph builder on Maxwell codebase."""

from pathlib import Path

from maxwell.workflows.refactor.extractors import PythonSpecExtractor
from maxwell.workflows.refactor.graph_builder import CodeGraph


def test_on_maxwell():
    """Test graph builder on Maxwell Python codebase."""
    # Find some Python files
    src_dir = Path("src/maxwell/workflows")
    python_files = list(src_dir.glob("**/*.py"))[:10]  # Test on first 10 files

    print(f"Extracting specs from {len(python_files)} files...\n")

    # Extract specs
    graph = CodeGraph(similarity_threshold=0.75)
    source_map = {}

    for py_file in python_files:
        if py_file.name == "__init__.py":
            continue

        print(f"  {py_file}")

        functions, classes = PythonSpecExtractor.extract_from_file(py_file)

        # Store source code for call graph
        source_map[py_file] = py_file.read_text()

        # Add to graph
        for func in functions:
            graph.add_function(func)

        for cls in classes:
            graph.add_class(cls)

    print(f"\nBuilding call graph...")
    graph.build_call_graph(source_map)

    print(f"\nGraph Statistics:")
    stats = graph.stats()
    for key, value in stats.items():
        print(f"  {key}: {value}")

    # Find duplicate cliques
    cliques = graph.find_duplicate_cliques()
    if cliques:
        print(f"\nFound {len(cliques)} potential duplicate groups:")
        for i, clique in enumerate(cliques[:5], 1):  # Show first 5
            print(f"\n  Group {i}:")
            for func_id in list(clique)[:3]:  # Show first 3 in each group
                func = graph.functions[func_id]
                print(f"    - {func.name} ({func.file.name}:{func.start_line})")

    # Compute PageRank
    if graph.call_graph.number_of_nodes() > 0:
        print(f"\nTop 10 functions by PageRank (centrality):")
        pagerank = graph.compute_pagerank()
        sorted_funcs = sorted(pagerank.items(), key=lambda x: x[1], reverse=True)
        for func_id, score in sorted_funcs[:10]:
            func = graph.functions[func_id]
            print(f"  {score:.4f} - {func.name} ({func.file.name})")


if __name__ == "__main__":
    test_on_maxwell()
