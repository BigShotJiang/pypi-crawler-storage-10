"""Test similarity graph with embeddings on a small subset."""

from pathlib import Path

from maxwell.workflows.agentic_refactoring import run_agentic_refactoring


def test_similarity_graph():
    """Test similarity graph on Maxwell refactor module (small)."""
    # Create a temp test directory with just the refactor module
    project_root = Path.cwd()

    print("=" * 60)
    print("SIMILARITY GRAPH TEST (Limited to refactor module)")
    print("=" * 60)

    # Run workflow on full codebase but with lower threshold
    results = run_agentic_refactoring(
        project_root=project_root,
        similarity_threshold=0.85,  # Higher threshold = fewer edges
        languages=["python"],
        dry_run=True,
    )

    print("\n" + "=" * 60)
    print("RESULTS")
    print("=" * 60)
    for key, value in results.items():
        print(f"{key}: {value}")


if __name__ == "__main__":
    test_similarity_graph()
