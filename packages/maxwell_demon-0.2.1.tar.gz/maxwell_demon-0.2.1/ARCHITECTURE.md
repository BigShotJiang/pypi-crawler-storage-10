# Maxwell Architecture

Maxwell is an **orchestration framework** that converts scripts into programs by providing unified CLI, API, and MCP interfaces. It manages filesystem I/O, network I/O, and workflow execution. Business logic lives in workflows.

## Core Principles

1. **Core = Infrastructure**: Maxwell's root handles I/O and orchestration only
2. **Workflows = Business Logic**: All domain-specific logic lives in `workflows/`
3. **Workflows as Second Src**: `workflows/` is like a second `src/` with full autonomy

## Directory Structure

```
src/maxwell/
├── CLI/API/MCP Interfaces
│   ├── cli.py              # Command-line interface
│   ├── api.py              # REST API
│   └── mcp_server.py       # Model Context Protocol server
│
├── Filesystem I/O
│   ├── filesystem.py       # File operations
│   ├── storage.py          # Content-addressable storage
│   ├── discovery.py        # File discovery/globbing
│   ├── extractors.py       # Content extraction utilities
│   └── ast/                # AST-based specialized file reading
│       ├── python_parser.py     # Python AST analysis (libcst)
│       ├── javascript_parser.py # JavaScript AST analysis (esprima)
│       └── import_graph.py      # Dependency graph builder
│
├── Network I/O
│   ├── db.py               # MongoDB/Qdrant connections
│   ├── lm_pool.py          # LLM registry and routing
│   └── pydantic_gbnf.py    # Grammar generation for structured output
│
├── Workflow Execution
│   ├── registry.py         # Workflow registry
│   ├── config.py           # Configuration management
│   └── types.py            # Shared type definitions
│
└── workflows/              # Business Logic (Second Src)
    ├── base/               # Base classes (public API for all workflows)
    │   ├── base.py         # BaseWorkflow, WorkflowConfig, etc.
    │   └── __init__.py
    │
    ├── inference/
    │   ├── flashback.py    # FlashBack inference (research-augmented CoT)
    │   └── __init__.py
    │
    ├── validate/
    │   ├── reporting.py    # Validation reporting
    │   ├── rules.py        # Rule engine
    │   ├── validators.py   # Validation plugins
    │   └── validation_engine.py
    │
    ├── chat/
    │   └── incremental_processor.py  # Chat log processing
    │
    └── (other workflows)
        ├── deep_research.py
        ├── temporal_concept_evolution.py
        ├── justification.py
        └── snapshot.py
```

## Architecture Decisions

### What Belongs in Core?

**CLI/API/MCP Interfaces:**
- Entry points for user interaction
- Route commands to workflows
- Handle authentication/authorization

**Filesystem I/O:**
- File discovery, reading, writing
- Content-addressable storage
- Extraction utilities (PDFs, Office docs, etc.)
- AST-based specialized file reading (Python, JavaScript)

**Network I/O:**
- Database connections (MongoDB, Qdrant)
- LLM pool management and routing
- Structured output utilities (GBNF grammars)

**Workflow Execution:**
- Workflow registry and discovery
- Configuration loading
- Shared type definitions

### What Belongs in Workflows?

**Everything Else:**
- Domain-specific logic (validation, inference, research, etc.)
- Analysis algorithms
- Report generation
- Model fine-tuning
- Data processing pipelines

## Key Insight: Workflows as Second Src

Think of `workflows/` as a **second `src/` directory**:

- **Full autonomy**: Can import from core, but core should NOT import from workflows
- **Self-contained**: Each workflow is a mini-application
- **Plugin-like**: New workflows can be added without modifying core
- **Business logic**: All domain expertise lives here

## Example: Inference Workflow

Before refactoring (WRONG):
```python
# /src/maxwell/maxwell_backend.py  ❌ Business logic in core
class MaxwellModel:
    # FlashBack inference implementation
    pass
```

After refactoring (CORRECT):
```python
# /src/maxwell/workflows/inference/flashback.py  ✓ Business logic in workflow
class MaxwellModel:
    # FlashBack inference implementation
    pass

# /src/maxwell/lm_pool.py  ✓ Core imports from workflow
from maxwell.workflows.inference.flashback import MaxwellModel
```

## Import Rules (Plugin Architecture)

Maxwell follows **Plugin Architecture** + **Mediator Pattern**:

1. ✅ **Core can import from core** (infrastructure layer)
2. ✅ **Core can import from workflows/base** (base classes for plugins)
3. ✅ **Workflows can import from core** (plugins depend on host)
4. ✅ **Workflows can import from workflows/base** (base classes)
5. ✅ **Workflows can EXECUTE each other** (via workflow registry)
6. ❌ **Workflows CANNOT import sibling workflows** (no cross-plugin imports)
7. ❌ **Core should NOT import business logic workflows** (except dynamic loading in registry/lm_pool)

### Why This Design?

**Prevents circular dependencies:**
```python
# ❌ BAD: Direct import (circular dependency risk)
from maxwell.workflows.research import deep_research

# ✅ GOOD: Execute via registry (mediated)
from maxwell.registry import execute_workflow
result = execute_workflow("deep_research", query="...")
```

**This follows known conventions:**
- **Django Apps**: Apps don't import each other, communicate via signals/commands
- **VS Code Extensions**: Extensions use VS Code API, not other extensions
- **Symfony Bundles**: Bundles communicate via service container
- **Eclipse Plugins**: Plugins extend core via extension points
- **Microservices**: Services call each other via APIs, not direct imports

### Pattern Name: **Mediator + Plugin Architecture**

```
┌─────────────────────────────────────┐
│      Maxwell Core (Mediator)        │
│   - Workflow Registry               │
│   - Filesystem I/O                  │
│   - Network I/O                     │
└─────────────────────────────────────┘
         ↑                    ↑
         │                    │
    ┌────┴────┐          ┌────┴────┐
    │ Workflow│          │ Workflow│
    │    A    │  execute │    B    │
    │ (Plugin)│◄─────────┤ (Plugin)│
    └─────────┘   via    └─────────┘
                registry
```

Workflows = loosely coupled plugins that communicate through core mediator.

## Recent Refactoring (2025-10-25)

**Business logic → workflows/:**
- `reporting.py` → `workflows/validate/reporting.py`
- `rules.py` → `workflows/validate/rules.py`
- `maxwell_backend.py` → `workflows/inference/flashback.py`

**Base classes → workflows/base/:**
- `workflows/base.py` → `workflows/base/base.py`
- Public API for all workflow plugins to implement

**Specialized I/O → core/ast/:**
- `workflows/ast_analysis.py` → `ast/python_parser.py`
- `workflows/ast_import_graph.py` → `ast/import_graph.py`
- Added `ast/javascript_parser.py` (pyjsparser, optional)
- AST is specialized file reading, not business logic

**Kept infrastructure in core:**
- `extractors.py` (filesystem utility)
- `pydantic_gbnf.py` (network I/O utility)
- `lm_pool.py` (network I/O orchestration)

## Benefits

1. **Clear separation of concerns**: Infrastructure vs business logic
2. **Easier testing**: Mock I/O layer, test workflows independently
3. **Better modularity**: Add new workflows without touching core
4. **Reduced coupling**: Core changes don't break workflows
5. **Plugin architecture**: Workflows can be discovered dynamically
