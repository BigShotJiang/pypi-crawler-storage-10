/**
 * Sample JavaScript file for testing AST parser
 * This demonstrates React component structure
 */

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Button, Card } from './components';

// ES6 Class Component
class UserProfile extends React.Component {
  constructor(props) {
    super(props);
    this.state = { user: null };
  }

  componentDidMount() {
    this.fetchUser();
  }

  fetchUser() {
    axios.get('/api/user').then(response => {
      this.setState({ user: response.data });
    });
  }

  render() {
    return <div>{this.state.user?.name}</div>;
  }
}

// Function Component
function Dashboard({ userId }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [userId]);

  const loadData = async () => {
    setLoading(true);
    const response = await axios.get(`/api/dashboard/${userId}`);
    setData(response.data);
    setLoading(false);
  };

  return (
    <div>
      {loading ? <p>Loading...</p> : <Card data={data} />}
    </div>
  );
}

// Arrow Function
const formatDate = (timestamp) => {
  return new Date(timestamp).toLocaleDateString();
};

// Utility function
function calculateTotal(items) {
  return items.reduce((sum, item) => sum + item.price, 0);
}

// Named exports
export { UserProfile, Dashboard, formatDate };

// Default export
export default function App() {
  return (
    <div>
      <Dashboard userId={1} />
      <UserProfile />
    </div>
  );
}
