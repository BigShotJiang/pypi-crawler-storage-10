"""Test file for docstring enrichment."""


def add(a, b):
    return a + b


def multiply(x, y):
    result = x * y
    return result


class Calculator:
    def __init__(self, name):
        self.name = name

    def divide(self, a, b):
        if b == 0:
            raise ValueError("Cannot divide by zero")
        return a / b
