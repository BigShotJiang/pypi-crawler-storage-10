"""Maxwell as a drop-in replacement for transformers.

This example shows how MaxwellModel is 100% compatible with
transformers API while adding extra functionality.
"""

from transformers import AutoTokenizer

# Option 1: Use standard transformers
from transformers import AutoModelForCausalLM

model = AutoModelForCausalLM.from_pretrained(
    "Qwen/Qwen2.5-7B-Instruct",
    device_map="auto",
    torch_dtype="float16"
)

# Option 2: Drop-in replacement - change ONE line
from maxwell.workflows.inference.flashback import MaxwellModel

model = MaxwellModel.from_pretrained(
    "Qwen/Qwen2.5-7B-Instruct",
    device_map="auto",
    torch_dtype="float16"
)

# Everything else works EXACTLY the same
tokenizer = AutoTokenizer.from_pretrained("Qwen/Qwen2.5-7B-Instruct")

# Standard transformers API
inputs = tokenizer("Hello, how are you?", return_tensors="pt").to(model.model.device)

# All standard methods work
outputs = model(**inputs)  # Forward pass
logits = outputs.logits

# Standard generation
outputs = model.generate(**inputs, max_new_tokens=50)
text = tokenizer.decode(outputs[0], skip_special_tokens=True)
print(f"Generated: {text}")

# Plus Maxwell extras (not available in standard transformers)

# Extra 1: LoRA adapters
model.load_lora_adapter("/path/to/lora", "math-expert")
outputs = model.generate(**inputs, max_new_tokens=50)

model.switch_lora_adapter("code-expert")
outputs = model.generate(**inputs, max_new_tokens=50)

model.disable_lora()  # Back to base model

# Extra 2: Entropy tracking (coming soon)
outputs, entropy = model.generate_with_entropy(**inputs, max_new_tokens=50)
print(f"Mean entropy: {sum(entropy)/len(entropy):.3f}")

# Extra 3: R-Stitch routing
from maxwell.workflows.inference.flashback import RStitchRouter

small = MaxwellModel.from_pretrained("Qwen/Qwen2.5-7B-Instruct")
large = MaxwellModel.from_pretrained("Qwen/Qwen2.5-14B-Instruct")

router = RStitchRouter(
    small_model=small,
    large_model=large,
    tokenizer=tokenizer,
    entropy_threshold=0.5
)

# Router also uses transformers API
result = router.generate(
    prompt="Write a complex algorithm",
    max_tokens=512,
    temperature=0.7
)

print(f"Switches: {result['switches']}")
print(f"Speedup: {result['estimated_speedup']}")
print(f"Text: {result['text']}")
