"""Example: How workflows communicate in Maxwell's Plugin Architecture.

Workflows execute each other via the registry (Mediator Pattern),
NOT by direct imports (prevents circular dependencies).
"""

# ========================================
# ❌ ANTI-PATTERN: Direct Import
# ========================================

# from maxwell.workflows.research import deep_research  # DON'T DO THIS!
# from maxwell.workflows.inference import flashback     # DON'T DO THIS!

# Why not?
# 1. Circular dependency risk
# 2. Tight coupling between workflows
# 3. Can't replace workflows dynamically
# 4. Hard to test in isolation


# ========================================
# ✅ CORRECT PATTERN: Execute via Registry
# ========================================

from maxwell.registry import execute_workflow
from maxwell.lm_pool import get_lm


# Example 1: Inference workflow calls research workflow
def inference_with_research_augmentation(query: str) -> str:
    """Inference workflow executes research workflow via registry.

    This is the Mediator Pattern - workflows don't know about each other,
    they only know about the core registry interface.
    """

    # Step 1: Run research workflow (via registry)
    research_results = execute_workflow(
        workflow_id="deep_research",
        research_question=query,
        data_sources="chat,web",
        max_iterations=2,
    )

    # Step 2: Extract findings
    knowledge = research_results.get("report", "")

    # Step 3: Use findings in inference
    llm = get_lm()
    response = llm.generate(
        prompt=f"Based on this research:\n{knowledge}\n\nAnswer: {query}",
        max_tokens=512
    )

    return response


# Example 2: Research workflow calls validation workflow
def research_with_validation(query: str) -> dict:
    """Research workflow validates its outputs via registry."""

    # Step 1: Run research
    research_results = execute_workflow(
        workflow_id="deep_research",
        research_question=query,
    )

    # Step 2: Validate findings quality (via registry)
    validation_results = execute_workflow(
        workflow_id="validate",
        paths=[research_results["artifacts"]["report"]],
        format="json"
    )

    # Step 3: Return combined results
    return {
        "research": research_results,
        "validation": validation_results,
        "quality_score": len(validation_results.get("findings", [])) == 0
    }


# Example 3: Workflow composition (chain multiple workflows)
def complex_analysis_pipeline(codebase_path: str, research_query: str) -> dict:
    """Compose multiple workflows via registry (no imports between workflows)."""

    # Step 1: Snapshot codebase
    snapshot = execute_workflow(
        workflow_id="snapshot",
        target=codebase_path,
        output="SNAPSHOT.md"
    )

    # Step 2: Analyze architecture
    justification = execute_workflow(
        workflow_id="justification",
        project_root=codebase_path
    )

    # Step 3: Research related topics
    research = execute_workflow(
        workflow_id="deep_research",
        research_question=research_query,
        data_sources="chat,filesystem,web"
    )

    # Step 4: Synthesize findings
    llm = get_lm()
    synthesis = llm.generate(
        prompt=f"""Analyze this codebase:

Snapshot: {snapshot['artifacts']['output']}
Architecture issues: {justification['metrics']['architectural_issues']}
Research findings: {research['report']}

Provide recommendations:""",
        max_tokens=1024
    )

    return {
        "snapshot": snapshot,
        "justification": justification,
        "research": research,
        "synthesis": synthesis
    }


# ========================================
# Pattern Benefits
# ========================================

# 1. **Loose Coupling**: Workflows don't depend on each other's implementation
# 2. **No Circular Dependencies**: Only depends on core registry interface
# 3. **Dynamic Discovery**: Can add new workflows without changing existing ones
# 4. **Easy Testing**: Mock the registry, test workflows in isolation
# 5. **Hot Reload**: Can reload workflows without restarting
# 6. **Version Independence**: Workflows can have different versions


# ========================================
# Known Frameworks Using This Pattern
# ========================================

# Django Apps (use signals/commands):
# from django.core.management import call_command
# call_command('other_app_command', '--arg=value')

# Symfony Bundles (use service container):
# $this->get('other_bundle.service')->execute();

# Laravel (use service container):
# app('other.service')->process();

# VS Code Extensions (use extension API):
# vscode.commands.executeCommand('other.extension.command');

# Eclipse Plugins (use extension points):
# Platform.getExtensionRegistry().getExtensionPoint(...);
