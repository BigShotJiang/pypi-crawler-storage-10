"""Example: How to implement a workflow using workflows/base

workflows/base is the PUBLIC API that all workflow plugins must implement.
This is NOT a sibling workflow - it's the base class package.

Think of it like:
- Django: apps inherit from django.apps.AppConfig
- VS Code: extensions implement vscode.ExtensionContext
- Maxwell: workflows inherit from workflows.base.BaseWorkflow
"""

from pathlib import Path
from typing import Dict, Any
from dataclasses import dataclass

# ✅ CORRECT: Import base classes from workflows.base
from maxwell.workflows.base import (
    BaseWorkflow,
    WorkflowConfig,
    WorkflowInputs,
    WorkflowOutputs,
    WorkflowResult,
    WorkflowStatus,
)


# ========================================
# Step 1: Define Input/Output Schemas
# ========================================

@dataclass(frozen=True)
class MyWorkflowInputs(WorkflowInputs):
    """Typed inputs for MyWorkflow.

    These are validated when the workflow executes.
    """
    query: str
    limit: int = 10
    source: str = "all"


@dataclass(frozen=True)
class MyWorkflowOutputs(WorkflowOutputs):
    """Typed outputs for MyWorkflow.

    These are returned in WorkflowResult.artifacts
    """
    results: list[str]
    count: int
    source_used: str


# ========================================
# Step 2: Implement BaseWorkflow
# ========================================

class MyWorkflow(BaseWorkflow):
    """Example workflow demonstrating base class usage.

    This workflow inherits from BaseWorkflow (from workflows.base),
    which is the public API for all workflow plugins.
    """

    # Required metadata
    workflow_id = "my_workflow"
    name = "My Example Workflow"
    description = "Demonstrates how to use workflows/base"
    version = "1.0"
    category = "example"
    tags = {"demo", "tutorial"}

    # Optional: Define typed schemas
    InputSchema = MyWorkflowInputs
    OutputSchema = MyWorkflowOutputs

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        """Execute the workflow.

        Args:
            project_root: Root directory of the project
            context: Execution context with parameters

        Returns:
            WorkflowResult with findings and artifacts
        """
        # Parse typed inputs
        inputs = self.parse_inputs(context)

        # Access typed fields
        print(f"Searching for: {inputs.query}")
        print(f"Limit: {inputs.limit}")
        print(f"Source: {inputs.source}")

        # Do work...
        results = [f"Result {i}" for i in range(inputs.limit)]

        # Create typed outputs
        outputs = MyWorkflowOutputs(
            results=results,
            count=len(results),
            source_used=inputs.source
        )

        # Return result (automatically converts to WorkflowResult)
        return self.create_result(outputs)


# ========================================
# Step 3: Execute via Registry (Not Direct Import)
# ========================================

def example_workflow_composition():
    """How workflows execute each other via registry (NOT direct import)."""
    from maxwell.registry import execute_workflow

    # ❌ BAD: Don't do this
    # from maxwell.workflows.my_workflow import MyWorkflow
    # result = MyWorkflow().execute(...)

    # ✅ GOOD: Execute via registry
    result = execute_workflow(
        workflow_id="my_workflow",
        query="test",
        limit=5,
        source="web"
    )

    print(f"Status: {result.status}")
    print(f"Results: {result.artifacts['results']}")


# ========================================
# Key Points
# ========================================

"""
1. workflows/base is PUBLIC API (not private like _shared)
   - All workflows inherit from BaseWorkflow
   - This is like Django's AppConfig or VS Code's Extension API

2. workflows/base is NOT a sibling workflow
   - It's base infrastructure, not business logic
   - Architecture linter allows imports from workflows.base

3. Workflows execute siblings via registry
   - Use execute_workflow() to call other workflows
   - Prevents circular dependencies
   - Enables loose coupling

4. Convention comparison:
   - Django: apps inherit from django.apps.AppConfig
   - VS Code: extensions implement vscode.ExtensionContext
   - Eclipse: plugins extend org.eclipse.core.runtime.Plugin
   - Maxwell: workflows inherit from maxwell.workflows.base.BaseWorkflow
"""
