__all__ = ["TextEmbeddings", "TextEncoder"]

from lt_utils.common import *
from lt_tensor.common import *
from lt_tensor.activations_utils import get_activation, ACTIV_NAMES_TP

from lt_tensor.model_zoo.pos_encoders import (
    RotaryPositionalEncoding,
    SinusoidalPositionalEncoding,
    RotaryPositionalEncoding,
)
from lt_tensor.model_zoo.conv_norm import Conv1dNorm, ConvNormConfig


class TextEmbeddings(Model):
    def __init__(
        self,
        vocab_size: int,
        d_model: int = 256,
        position_encoder_type: Optional[
            Literal[
                "absolute",
                "sinusoidal",
                "rotary",
            ]
        ] = "rotary",
        max_seq_len: int = 2048,
        rotary_base: int = 10000,
        rotary_dim: Optional[int] = None,
        rotary_reshape: bool = True,
        padding_idx: Optional[int] = None,
        transposed_output: bool = False,
        *,
        max_norm: Optional[float] = None,
        norm_type: float = 2,
        scale_grad_by_freq: bool = False,
        sparse: bool = False,
    ):
        super().__init__()
        self.embedding = nn.Embedding(
            vocab_size,
            d_model,
            padding_idx=padding_idx,
            max_norm=max_norm,
            norm_type=norm_type,
            scale_grad_by_freq=scale_grad_by_freq,
            sparse=sparse,
        )
        self.position_encoder_type: Optional[
            Literal["absolute", "sinusoidal", "rotary"]
        ] = position_encoder_type
        if self.position_encoder_type is not None:
            if position_encoder_type == "absolute":
                self.pos_emb = nn.Embedding(max_seq_len, d_model)
            elif position_encoder_type == "rotary":
                self.pos_emb = RotaryPositionalEncoding(
                    d_model=d_model,
                    rotary_dim=rotary_dim,
                    base=rotary_base,
                    reshape_output=rotary_reshape,
                )
            else:

                self.pos_emb = SinusoidalPositionalEncoding(
                    d_model=d_model,
                    base=rotary_base or max_seq_len,
                )
        else:
            self.pos_emb = nn.Identity()

        self.transposed_output = transposed_output

    def forward(self, input_ids: Tensor, position_ids: Optional[Tensor] = None):
        """input_ids (long) =  [B, T]"""
        B, T = input_ids.shape
        inputs_embeds = self.embedding(input_ids)  # [B, T, emb]
        if self.position_encoder_type == "absolute":
            if position_ids is None:
                position_ids = (
                    torch.arange(T, device=inputs_embeds.device, dtype=torch.long)
                    .unsqueeze(0)
                    .expand(B, T)
                )
            else:
                position_ids = position_ids.long()
            emb = inputs_embeds + self.pos_emb(position_ids)
        else:
            emb = self.pos_emb(inputs_embeds)

        if self.transposed_output:
            return emb.transpose(-1, -2)
        return emb


class TextEncoder(Model):
    def __init__(
        self,
        vocab_size: int,
        d_model: int = 256,
        cnn_config=ConvNormConfig(
            [256, 256],
            kernel_size=[3, 3],
            activation="gelu",
            norm_bias=False,
        ),
        n_layers: int = 2,
        dropout: float = 0.1,
        padding_id: int = 0,
        position_encoder_type: Optional[
            Literal[
                "absolute",
                "sinusoidal",
                "rotary",
            ]
        ] = "rotary",
        apply_mask_at_output: bool = True,
        rotary_base: int = 10000,
        rotary_dim: Optional[int] = None,
        mask_value: Number = 0.0,
        activation: ACTIV_NAMES_TP = "silu",
        activation_kwargs: Dict[str, Any] = dict(),
        cnn_residual_sum: bool = False,
    ):
        super().__init__()

        self.embedding = TextEmbeddings(
            vocab_size=vocab_size,
            d_model=d_model,
            position_encoder_type=position_encoder_type,
            padding_idx=padding_id,
            rotary_reshape=True,
            rotary_base=rotary_base,
            rotary_dim=rotary_dim,
        )
        self.mask_value = mask_value
        self.cnn_residual_sum = cnn_residual_sum
        self.cnn = nn.ModuleList()
        cnn_config.fix_lists("crop_larger")
        self.cnn_cfg = cnn_config
        self.apply_mask_at_output = apply_mask_at_output

        self.cnn_layers = len(cnn_config)
        for i in range(self.cnn_layers):
            self.cnn.append(Conv1dNorm(self.cnn_cfg, d_model, i))

        self.rnn = nn.LSTM(
            d_model,
            d_model,
            num_layers=n_layers,
            dropout=0 if n_layers < 2 else dropout,
            batch_first=True,
            bidirectional=True,
        )
        self.proj_out = nn.Sequential(
            get_activation(activation, **activation_kwargs),
            nn.Linear(d_model * 2, d_model),
        )
        self.duration_pred = None

    def rnn_pass(
        self,
        x: Tensor,
        B: int,
        T: int,
        lengths: List[int] = None,
        mask: Optional[Tensor] = None,
    ):
        if mask is not None:
            x = x.transpose(-1, -2)
            x.masked_fill_(mask, self.mask_value)
            x = x.transpose(-1, -2)
        if lengths is None:
            lengths = [T for _ in range(B)]
        elif isinstance(lengths, Tensor):
            lengths = lengths.clone().detach().cpu().long().tolist()

        packed = nn.utils.rnn.pack_padded_sequence(
            x,
            lengths,
            batch_first=True,
            enforce_sorted=False,
        )
        self.rnn.flatten_parameters()
        out_packed = self.rnn(packed)[0]
        x = nn.utils.rnn.pad_packed_sequence(out_packed, batch_first=True)[0]
        return x

    def cnn_pass(self, x: Tensor, mask: Optional[Tensor] = None):
        x = x.transpose(-1, -2)  # [B, emb, T]
        for c in self.cnn:
            if self.cnn_residual_sum:
                x = c(x, mask)
            else:
                x = c(x, mask) + x
        x = x.transpose(-1, -2)
        return x

    def forward(
        self,
        input_ids: Tensor,
        lengths: List[int] = None,
        mask: Optional[Tensor] = None,
        return_dict: bool = True,
    ):
        B, T = input_ids.size(0), input_ids.size(-1)
        emb: Tensor = self.embedding(input_ids.view(B, T))  # [B, T, emb]
        x = self.cnn_pass(emb, mask)
        x = self.rnn_pass(x, B, T, lengths, mask)

        x = self.proj_out(x)
        x = x.transpose(-1, -2)

        if mask is not None and self.apply_mask_at_output:
            x.masked_fill_(mask, self.mask_value)

        if not return_dict:
            return x, emb
        return dict(text=x, emb=emb)


class TextEncoder(Model):
    def __init__(
        self,
        vocab_size: int,
        d_model: int = 256,
        cnn_config=ConvNormConfig(
            [256, 256],
            kernel_size=[3, 3],
            activation="gelu",
            norm_bias=False,
        ),
        n_layers: int = 2,
        dropout: float = 0.1,
        padding_id: int = 0,
        position_encoder_type: Optional[
            Literal[
                "absolute",
                "sinusoidal",
                "rotary",
            ]
        ] = "rotary",
        apply_mask_at_output: bool = True,
        rotary_base: int = 10000,
        rotary_dim: Optional[int] = None,
        mask_value: Number = 0.0,
        activation: ACTIV_NAMES_TP = "silu",
        activation_kwargs: Dict[str, Any] = dict(),
        cnn_residual_sum: bool = False,
    ):
        super().__init__()

        self.embedding = TextEmbeddings(
            vocab_size=vocab_size,
            d_model=d_model,
            position_encoder_type=position_encoder_type,
            padding_idx=padding_id,
            rotary_reshape=True,
            rotary_base=rotary_base,
            rotary_dim=rotary_dim,
        )
        self.mask_value = mask_value
        self.cnn_residual_sum = cnn_residual_sum
        self.cnn = nn.ModuleList()
        cnn_config.fix_lists("crop_larger")
        self.cnn_cfg = cnn_config
        self.apply_mask_at_output = apply_mask_at_output

        self.cnn_layers = len(cnn_config)
        for i in range(self.cnn_layers):
            self.cnn.append(Conv1dNorm(self.cnn_cfg, d_model, i))

        self.rnn = nn.LSTM(
            d_model,
            d_model,
            num_layers=n_layers,
            dropout=0 if n_layers < 2 else dropout,
            batch_first=True,
            bidirectional=True,
        )
        self.proj_out = nn.Sequential(
            get_activation(activation, **activation_kwargs),
            nn.Linear(d_model * 2, d_model),
        )
        self.duration_pred = None

    def rnn_pass(
        self,
        x: Tensor,
        B: int,
        T: int,
        lengths: List[int] = None,
        mask: Optional[Tensor] = None,
    ):
        if mask is not None:
            x = x.transpose(-1, -2)
            x.masked_fill_(mask, self.mask_value)
            x = x.transpose(-1, -2)
        if lengths is None:
            lengths = [T for _ in range(B)]
        elif isinstance(lengths, Tensor):
            lengths = lengths.clone().detach().cpu().long().tolist()

        packed = nn.utils.rnn.pack_padded_sequence(
            x,
            lengths,
            batch_first=True,
            enforce_sorted=False,
        )
        self.rnn.flatten_parameters()
        out_packed = self.rnn(packed)[0]
        x = nn.utils.rnn.pad_packed_sequence(out_packed, batch_first=True)[0]
        return x

    def cnn_pass(self, x: Tensor, mask: Optional[Tensor] = None):
        x = x.transpose(-1, -2)  # [B, emb, T]
        for c in self.cnn:
            if self.cnn_residual_sum:
                x = c(x, mask)
            else:
                x = c(x, mask) + x
        x = x.transpose(-1, -2)
        return x

    def forward(
        self,
        input_ids: Tensor,
        lengths: List[int] = None,
        mask: Optional[Tensor] = None,
        return_dict: bool = True,
    ):
        B, T = input_ids.size(0), input_ids.size(-1)
        emb: Tensor = self.embedding(input_ids.view(B, T))  # [B, T, emb]
        x = self.cnn_pass(emb, mask)
        x = self.rnn_pass(x, B, T, lengths, mask)

        x = self.proj_out(x)
        x = x.transpose(-1, -2)

        if mask is not None and self.apply_mask_at_output:
            x.masked_fill_(mask, self.mask_value)

        if not return_dict:
            return x, emb
        return dict(text=x, emb=emb)
