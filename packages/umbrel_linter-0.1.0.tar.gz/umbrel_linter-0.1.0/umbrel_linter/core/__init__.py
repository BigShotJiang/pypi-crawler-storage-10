"""Core linting functionality."""
