from colorama import Fore

color_formats = {
    "green": Fore.GREEN,
    "yellow": Fore.YELLOW,
    "red": Fore.RED,
    "reset": Fore.RESET,
}
