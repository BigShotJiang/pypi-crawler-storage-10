# package_name

`ahmed_linear_regression` is a Python library for instantiating & manipulating rocket objects

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install `ahmed_linear_regression`.

```bash
pip install ahmed_linear_regression
```

## Usage

```python
import ahmed_linear_regression

# returns 'words'
ahmed_linear_regression.module_name('word')

# returns 'geese'
ahmed_linear_regression.module_name('goose')

# returns 'phenomenon'
ahmed_linear_regression.module_name('phenomena')
```

## License
[MIT](https://choosealicense.com/licenses/mit/)