# AgentRuntime CLI (arun)

## Install
```bash
pip install agentruntime-cli
```

## Commands

- arun init
  - Scaffold a minimal Python MCP agent in the current directory
  - Creates `app/` with `main.py`, `tools/`, and `config.yaml`

- arun proxy --target-url <url> [--overlay-file tools.yaml] [--host 127.0.0.1] [--port 8010]
  - Run a lightweight proxy agent that fronts an existing MCP server

- arun generate-openapi -i openapi.json -o app/tools/generated.py
  - Generate tool stubs from an OpenAPI document

## Quick start
```bash
pip install agentruntime-cli agentruntime-mcp
arun init
python -m app.main
```

## Config
- Edit `app/config.yaml` (env overrides: `HOST`, `PORT`, `MCP_AUTH_MODE`)
- Auth modes: `none`, `token` (Bearer or X-MCP-Token), `hmac`
