from typing import Any, Dict
from pydantic import BaseModel, Field
from agentruntime.mcp.decorators import tool


class WorkflowStepInput(BaseModel):
    step_id: str = Field(description="Step identifier")
    action: str = Field(description="Action to perform")
    parameters: Dict[str, Any] = Field(description="Step parameters")


class WorkflowStepOutput(BaseModel):
    step_id: str = Field(description="Step identifier")
    status: str = Field(description="Step status: 'success', 'failed', 'pending'")
    result: Dict[str, Any] = Field(description="Step result")
    execution_time_ms: int = Field(description="Execution time in milliseconds")


@tool(name="workflow_step", input_model=WorkflowStepInput, output_model=WorkflowStepOutput)
def workflow_step_impl(step_id: str, action: str, parameters: Dict[str, Any]) -> WorkflowStepOutput:
    import time

    start_time = time.time()
    try:
        if action == "process_data":
            result = {"processed": True, "data": parameters.get("data", {})}
            status = "success"
        elif action == "validate_input":
            result = {"valid": True, "input": parameters.get("input", "")}
            status = "success"
        elif action == "generate_report":
            result = {"report": f"Report for {parameters.get('name', 'Unknown')}"}
            status = "success"
        elif action == "fail_step":
            result = {"error": "Simulated failure"}
            status = "failed"
        else:
            result = {"message": f"Unknown action: {action}"}
            status = "pending"
        execution_time = int((time.time() - start_time) * 1000)
        return WorkflowStepOutput(step_id=step_id, status=status, result=result, execution_time_ms=execution_time)
    except Exception as e:  # pragma: no cover
        execution_time = int((time.time() - start_time) * 1000)
        return WorkflowStepOutput(step_id=step_id, status="failed", result={"error": str(e)}, execution_time_ms=execution_time)


