from agentruntime.mcp.runtime import run

# Import your tools so @tool decorators register before run()
from app.tools import calculator  # noqa: F401
from app.tools import text  # noqa: F401
from app.tools import workflow  # noqa: F401


if __name__ == "__main__":
    run("app/config.yaml")


