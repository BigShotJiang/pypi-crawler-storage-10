from pydantic import BaseModel, Field
from agentruntime.mcp.decorators import tool


class TextProcessorInput(BaseModel):
    text: str = Field(description="Text to process", min_length=1, max_length=1000)
    operation: str = Field(description="Operation: 'uppercase', 'lowercase', 'reverse', 'word_count'")


class TextProcessorOutput(BaseModel):
    processed_text: str = Field(description="Processed text")
    original_length: int = Field(description="Original text length")
    processed_length: int = Field(description="Processed text length")
    operation: str = Field(description="Operation performed")


@tool(name="text_processor", input_model=TextProcessorInput, output_model=TextProcessorOutput)
def text_processor_impl(text: str, operation: str) -> TextProcessorOutput:
    original_length = len(text)
    if operation == "uppercase":
        processed = text.upper()
    elif operation == "lowercase":
        processed = text.lower()
    elif operation == "reverse":
        processed = text[::-1]
    elif operation == "word_count":
        processed = str(len(text.split()))
    else:
        raise ValueError(f"Unknown operation: {operation}")
    return TextProcessorOutput(
        processed_text=processed,
        original_length=original_length,
        processed_length=len(processed),
        operation=operation,
    )


