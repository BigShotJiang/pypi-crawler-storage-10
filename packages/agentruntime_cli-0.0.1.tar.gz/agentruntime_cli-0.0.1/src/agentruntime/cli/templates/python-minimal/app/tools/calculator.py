from pydantic import BaseModel, Field
from agentruntime.mcp.decorators import tool


class CalculatorInput(BaseModel):
    a: float = Field(description="First number")
    b: float = Field(description="Second number")


class CalculatorOutput(BaseModel):
    result: float = Field(description="Calculation result")
    expression: str = Field(description="Human-readable representation of the operation")


@tool(name="add", input_model=CalculatorInput, output_model=CalculatorOutput)
def add_impl(a: float, b: float) -> CalculatorOutput:
    result_value = a + b
    expression_text = f"{a} + {b}"
    return CalculatorOutput(result=result_value, expression=expression_text)


