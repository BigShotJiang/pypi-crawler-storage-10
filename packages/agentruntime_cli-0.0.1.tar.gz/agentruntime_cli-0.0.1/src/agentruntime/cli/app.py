from __future__ import annotations

import typer
import shutil
import pathlib
from importlib import resources

app = typer.Typer(help="AgentRuntime CLI (arun)")


@app.command()
def init(
    template: str = typer.Option("python-minimal", help="Template name"),
    dest: pathlib.Path = typer.Option(pathlib.Path.cwd(), help="Destination directory"),
) -> None:
    """Scaffold a minimal Python agent template in the destination directory."""
    pkg = "agentruntime.cli.templates"
    try:
        base = resources.files(pkg).joinpath(template)
    except Exception as e:
        typer.echo(f"Template not found: {e}")
        raise typer.Exit(code=1)
    if not base.exists():
        typer.echo(f"Template '{template}' not available")
        raise typer.Exit(code=1)
    try:
        shutil.copytree(base, dest, dirs_exist_ok=True)
    except Exception as e:  # pragma: no cover
        typer.echo(f"Failed to copy template: {e}")
        raise typer.Exit(code=1)
    typer.echo(f"Scaffolded template '{template}' into {dest}")


@app.command()
def proxy(
    target_url: str = typer.Option(..., help="Upstream MCP endpoint, e.g. http://127.0.0.1:8000/mcp"),
    overlay_file: str | None = typer.Option(None, help="YAML overlay file for tools metadata"),
    host: str = typer.Option("127.0.0.1", help="Listen host"),
    port: int = typer.Option(8010, help="Listen port"),
) -> None:
    """Run a lightweight proxy agent in front of an existing MCP server."""
    try:
        from agentruntime.mcp.proxy import run_proxy  # type: ignore
    except Exception as e:  # pragma: no cover
        typer.echo(f"Proxy not available: {e}")
        raise typer.Exit(code=1)
    run_proxy(target_url=target_url, overlay_file=overlay_file, bearer_token=None, host=host, port=port)


@app.command("generate-openapi")
def generate_openapi(
    input: str = typer.Option(..., "-i", "--input", help="openapi.json path"),
    output: str = typer.Option("generated/openapi_tools.py", "-o", "--output"),
) -> None:
    """Generate tool stubs from an OpenAPI spec."""
    try:
        from agentruntime.mcp.generators.openapi_to_mcp import generate  # type: ignore
    except Exception as e:  # pragma: no cover
        typer.echo(f"Generator not available: {e}")
        raise typer.Exit(code=1)
    generate(input, output)


if __name__ == "__main__":
    app()


