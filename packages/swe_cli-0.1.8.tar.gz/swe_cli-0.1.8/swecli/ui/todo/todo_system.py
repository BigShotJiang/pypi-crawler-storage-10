"""Todo system for managing complex task lists in SWE-CLI."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Dict, Any
from datetime import datetime
import uuid


class TodoStatus(Enum):
    """Status of a todo item."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


@dataclass
class TodoItem:
    """Individual todo item."""
    id: str
    content: str
    status: TodoStatus = TodoStatus.PENDING
    active_form: str = ""
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def mark_in_progress(self, active_form: str = "") -> None:
        """Mark todo item as in progress."""
        self.status = TodoStatus.IN_PROGRESS
        self.active_form = active_form
        self.updated_at = datetime.now()

    def mark_completed(self) -> None:
        """Mark todo item as completed."""
        self.status = TodoStatus.COMPLETED
        self.active_form = ""
        self.updated_at = datetime.now()

    def mark_cancelled(self) -> None:
        """Mark todo item as cancelled."""
        self.status = TodoStatus.CANCELLED
        self.active_form = ""
        self.updated_at = datetime.now()

    def to_dict(self) -> Dict[str, Any]:
        """Convert todo item to dictionary."""
        return {
            "id": self.id,
            "content": self.content,
            "status": self.status.value,
            "active_form": self.active_form,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> TodoItem:
        """Create todo item from dictionary."""
        item = cls(
            id=data["id"],
            content=data["content"],
            status=TodoStatus(data["status"]),
            active_form=data.get("active_form", ""),
            metadata=data.get("metadata", {}),
        )
        if "created_at" in data:
            item.created_at = datetime.fromisoformat(data["created_at"])
        if "updated_at" in data:
            item.updated_at = datetime.fromisoformat(data["updated_at"])
        return item


@dataclass
class TodoList:
    """Collection of todo items for a task."""
    id: str
    title: str
    description: str = ""
    items: List[TodoItem] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)

    def add_item(self, content: str, metadata: Optional[Dict[str, Any]] = None) -> TodoItem:
        """Add a new todo item."""
        item = TodoItem(
            id=str(uuid.uuid4())[:8],
            content=content,
            metadata=metadata or {},
        )
        self.items.append(item)
        self.updated_at = datetime.now()
        return item

    def get_item(self, item_id: str) -> Optional[TodoItem]:
        """Get todo item by ID or index."""
        # First try to find by ID
        for item in self.items:
            if item.id == item_id:
                return item

        # If not found by ID, try index-based access
        try:
            index = int(item_id)
            if 0 <= index < len(self.items):
                return self.items[index]
        except (ValueError, IndexError):
            pass

        return None

    def mark_item_in_progress(self, item_id: str, active_form: str = "") -> bool:
        """Mark item as in progress."""
        item = self.get_item(item_id)
        if item:
            item.mark_in_progress(active_form)
            self.updated_at = datetime.now()
            return True
        return False

    def mark_item_completed(self, item_id: str) -> bool:
        """Mark item as completed."""
        item = self.get_item(item_id)
        if item:
            item.mark_completed()
            self.updated_at = datetime.now()
            return True
        return False

    def mark_item_cancelled(self, item_id: str) -> bool:
        """Mark item as cancelled."""
        item = self.get_item(item_id)
        if item:
            item.mark_cancelled()
            self.updated_at = datetime.now()
            return True
        return False

    def get_pending_items(self) -> List[TodoItem]:
        """Get all pending items."""
        return [item for item in self.items if item.status == TodoStatus.PENDING]

    def get_in_progress_items(self) -> List[TodoItem]:
        """Get all in-progress items."""
        return [item for item in self.items if item.status == TodoStatus.IN_PROGRESS]

    def get_completed_items(self) -> List[TodoItem]:
        """Get all completed items."""
        return [item for item in self.items if item.status == TodoStatus.COMPLETED]

    def is_all_completed(self) -> bool:
        """Check if all items are completed or cancelled."""
        if not self.items:
            return True
        return all(item.status in [TodoStatus.COMPLETED, TodoStatus.CANCELLED] for item in self.items)

    def get_progress_percentage(self) -> float:
        """Get completion percentage."""
        if not self.items:
            return 100.0
        completed = len([item for item in self.items if item.status in [TodoStatus.COMPLETED, TodoStatus.CANCELLED]])
        return (completed / len(self.items)) * 100

    def to_dict(self) -> Dict[str, Any]:
        """Convert todo list to dictionary."""
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "items": [item.to_dict() for item in self.items],
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> TodoList:
        """Create todo list from dictionary."""
        todo_list = cls(
            id=data["id"],
            title=data["title"],
            description=data.get("description", ""),
            items=[TodoItem.from_dict(item_data) for item_data in data.get("items", [])],
        )
        if "created_at" in data:
            todo_list.created_at = datetime.fromisoformat(data["created_at"])
        if "updated_at" in data:
            todo_list.updated_at = datetime.fromisoformat(data["updated_at"])
        return todo_list


class TodoManager:
    """Manages todo lists for the current session."""

    def __init__(self):
        """Initialize todo manager."""
        self.current_todo_list: Optional[TodoList] = None
        self._todo_lists: Dict[str, TodoList] = {}

    def create_todo_list(self, title: str, description: str = "") -> TodoList:
        """Create a new todo list."""
        todo_list = TodoList(
            id=str(uuid.uuid4())[:8],
            title=title,
            description=description,
        )
        self._todo_lists[todo_list.id] = todo_list
        self.current_todo_list = todo_list
        return todo_list

    def get_current_todo_list(self) -> Optional[TodoList]:
        """Get the current active todo list."""
        return self.current_todo_list

    def set_current_todo_list(self, todo_list_id: str) -> bool:
        """Set the current todo list by ID."""
        if todo_list_id in self._todo_lists:
            self.current_todo_list = self._todo_lists[todo_list_id]
            return True
        return False

    def clear_current_todo_list(self) -> None:
        """Clear the current todo list."""
        self.current_todo_list = None

    def delete_todo_list(self, todo_list_id: str) -> bool:
        """Delete a todo list."""
        if todo_list_id in self._todo_lists:
            if self.current_todo_list and self.current_todo_list.id == todo_list_id:
                self.current_todo_list = None
            del self._todo_lists[todo_list_id]
            return True
        return False

    def get_all_todo_lists(self) -> List[TodoList]:
        """Get all todo lists."""
        return list(self._todo_lists.values())

    def update_item_status(self, item_id: str, status: TodoStatus, active_form: str = "") -> bool:
        """Update status of an item in the current todo list."""
        if not self.current_todo_list:
            return False

        if status == TodoStatus.IN_PROGRESS:
            return self.current_todo_list.mark_item_in_progress(item_id, active_form)
        elif status == TodoStatus.COMPLETED:
            return self.current_todo_list.mark_item_completed(item_id)
        elif status == TodoStatus.CANCELLED:
            return self.current_todo_list.mark_item_cancelled(item_id)

        return False