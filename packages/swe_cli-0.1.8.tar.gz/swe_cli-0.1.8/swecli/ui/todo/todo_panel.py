"""Todo panel UI component for displaying and managing todo lists."""

from __future__ import annotations

from typing import Optional, Tuple
from prompt_toolkit.formatted_text import FormattedText, StyleAndTextTuples
from prompt_toolkit.layout.controls import FormattedTextControl
from prompt_toolkit.layout.containers import Window, HSplit, VSplit

from swecli.ui.todo.todo_system import TodoManager, TodoStatus, TodoItem

# Fancy spinner frames for todo panel (different from main spinner)
TODO_SPINNER_FRAMES = ["⢿", "⣾", "⣽", "⣻", "⢿", "⣷", "⣯", "⣟", "⡿", "⣿"]


class TodoPanel:
    """Todo panel component that displays todo lists at the bottom of conversation."""

    def __init__(self, todo_manager: TodoManager):
        """Initialize todo panel.

        Args:
            todo_manager: TodoManager instance for managing todo lists
        """
        self.todo_manager = todo_manager
        self.control = FormattedTextControl(self._get_text)
        self.window = Window(
            content=self.control,
            wrap_lines=True,
            style="class:todo-panel",
        )
        self.visible = False
        self.spinner_active = False
        self.spinner_frame = 0
        self.spinner_text = ""
        self._spinner_timer = None

    def _get_text(self) -> FormattedText:
        """Get formatted text for todo panel.

        Returns:
            FormattedText for display
        """
        if not self.visible or not self.todo_manager.current_todo_list:
            return []

        todo_list = self.todo_manager.current_todo_list
        lines = self._format_todo_list(todo_list)
        return lines

    def _format_todo_list(self, todo_list) -> StyleAndTextTuples:
        """Format a todo list for display.

        Args:
            todo_list: TodoList to format

        Returns:
            Formatted text tuples
        """
        lines: StyleAndTextTuples = []

        # Header with title and progress in chat style
        progress = todo_list.get_progress_percentage()
        progress_text = f"{progress:.0f}%"

        # Title line with chat-style indicator and optional spinner
        title_prefix = ""
        if self.spinner_active:
            title_prefix = f"{TODO_SPINNER_FRAMES[self.spinner_frame]} "
        else:
            title_prefix = "⏺ "

        lines.extend([
            ("", title_prefix),
            ("class:todo-title", f"📋 Todo List: {todo_list.title}"),
            ("", f" ({progress_text})"),
            ("", "\n"),
        ])

        # Items
        if not todo_list.items:
            lines.extend([
                ("", "  ⎿ "),
                ("class:todo-empty", "No tasks yet"),
                ("", "\n"),
            ])
        else:
            for item in todo_list.items:
                item_line = self._format_todo_item(item)
                lines.extend(item_line)

        return lines

    def _format_todo_item(self, item: TodoItem) -> StyleAndTextTuples:
        """Format a single todo item.

        Args:
            item: TodoItem to format

        Returns:
            Formatted text tuples for the item
        """
        lines: StyleAndTextTuples = []

        # Determine status symbol and style
        if item.status == TodoStatus.COMPLETED:
            symbol = "✓"
            style = "class:todo-completed"
            content_style = "class:todo-completed-text"
            # Add strikethrough effect using Unicode
            content = self._add_strikethrough(item.content)
        elif item.status == TodoStatus.IN_PROGRESS:
            symbol = "⟳"
            style = "class:todo-in-progress"
            content_style = "class:todo-in-progress-text"
            content = item.active_form or item.content
        elif item.status == TodoStatus.CANCELLED:
            symbol = "✗"
            style = "class:todo-cancelled"
            content_style = "class:todo-cancelled-text"
            content = self._add_strikethrough(item.content)
        else:  # PENDING
            symbol = "○"
            style = "class:todo-pending"
            content_style = "class:todo-pending-text"
            content = item.content

        # Chat-style format with ⎿ indicator
        lines.append(("", "  ⎿ "))

        # Add status symbol with enhanced visibility for in-progress
        if item.status == TodoStatus.IN_PROGRESS:
            # Make in-progress items highly prominent with enhanced styling
            lines.append((style, f"{symbol} "))
            lines.append(("class:todo-in-progress-text bold", content))  # Bold white text for in-progress
        else:
            lines.append((style, f"{symbol} "))
            lines.append((content_style, content))

        # Add newline
        lines.append(("", "\n"))

        return lines

    def _add_strikethrough(self, text: str) -> str:
        """Add strikethrough effect to text using simple line characters.

        Args:
            text: Text to add strikethrough to

        Returns:
            Text with strikethrough effect
        """
        # Simple approach: just wrap with ~ characters which is more reliable
        return f"~{text}~"

    def update_visibility(self) -> bool:
        """Update panel visibility based on current state.

        Returns:
            True if visibility changed, False otherwise
        """
        should_show = (
            self.todo_manager.current_todo_list is not None and
            not self.todo_manager.current_todo_list.is_all_completed()
        )

        if should_show != self.visible:
            self.visible = should_show
            return True
        return False

    def refresh(self) -> None:
        """Refresh the panel display."""
        # Force UI refresh by invalidating the control
        if hasattr(self.control, 'text'):
            # Trigger text refresh
            pass

    def get_preferred_height(self) -> int:
        """Get preferred height for the panel.

        Returns:
            Preferred height in lines
        """
        if not self.visible or not self.todo_manager.current_todo_list:
            return 0

        # Header + items + borders
        item_count = len(self.todo_manager.current_todo_list.items)
        return max(3, item_count + 3)  # At least 3 lines (header, one item, border)

    def start_spinner(self, text: str = "") -> None:
        """Start the todo panel spinner.

        Args:
            text: Optional text to display with spinner
        """
        self.spinner_active = True
        self.spinner_text = text
        self.spinner_frame = 0
        self.refresh()

    def stop_spinner(self) -> None:
        """Stop the todo panel spinner."""
        self.spinner_active = False
        self.spinner_text = ""
        self.refresh()

    def advance_spinner(self) -> None:
        """Advance spinner frame for animation (manual fallback)."""
        if self.spinner_active:
            self.spinner_frame = (self.spinner_frame + 1) % len(TODO_SPINNER_FRAMES)
            self.refresh()


class TodoPanelContainer(Window):
    """Container for todo panel that handles dynamic sizing."""

    def __init__(self, todo_panel: TodoPanel):
        """Initialize todo panel container.

        Args:
            todo_panel: TodoPanel instance to wrap
        """
        self.todo_panel = todo_panel
        super().__init__(
            content=todo_panel.control,
            wrap_lines=True,
            style="class:todo-panel",
            # Start with 0 height, will be calculated dynamically
            height=lambda: self.todo_panel.get_preferred_height() if self.todo_panel.visible else 0,
        )

    def is_visible(self) -> bool:
        """Check if the todo panel should be visible.

        Returns:
            True if visible, False otherwise
        """
        return self.todo_panel.visible