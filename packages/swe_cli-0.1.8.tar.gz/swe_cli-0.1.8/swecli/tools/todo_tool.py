"""Todo tool for creating and managing task lists."""

from typing import Any, Dict, List, Optional
import json

from swecli.tools.base import BaseTool
from swecli.ui.todo.todo_system import TodoManager, TodoStatus


class TodoTool(BaseTool):
    """Tool for creating and managing todo lists during complex tasks."""

    def __init__(self, todo_manager: Optional[TodoManager] = None):
        """Initialize todo tool.

        Args:
            todo_manager: TodoManager instance for managing todo lists
        """
        self.todo_manager = todo_manager

    @property
    def name(self) -> str:
        """Tool name."""
        return "todo"

    @property
    def description(self) -> str:
        """Tool description."""
        return "Create and manage todo lists for complex multi-step tasks. Use this when the user's request is too complicated and needs to be broken down into smaller, manageable tasks."

    def execute(self, **kwargs: Any) -> Any:
        """Execute the todo tool.

        Args:
            **kwargs: Tool parameters
                - action: Action to perform ('create', 'update', 'clear', 'list', 'adapt')
                - title: Title for new todo list (required for 'create')
                - description: Description for new todo list (optional for 'create')
                - items: List of todo items (required for 'create' and 'adapt')
                - item_id: ID of item to update (required for 'update')
                - status: New status for item ('pending', 'in_progress', 'completed', 'cancelled')
                - active_form: Active form description for 'in_progress' status
                - keep_completed: Keep completed items when adapting plan (default: true)

        Returns:
            Tool execution result
        """
        if not self.todo_manager:
            return {"success": False, "error": "Todo manager not available"}

        action = kwargs.get("action", "").lower()

        try:
            if action == "create":
                result = self._create_todo_list(**kwargs)
            elif action == "update":
                result = self._update_todo_item(**kwargs)
            elif action == "clear":
                result = self._clear_todo_list(**kwargs)
            elif action == "list":
                result = self._list_todo_items(**kwargs)
            elif action == "adapt":
                result = self._adapt_todo_list(**kwargs)
            else:
                return {"success": False, "error": f"Unknown action: {action}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

        # Trigger UI update if the operation was successful
        if result.get("success", False):
            self._trigger_ui_update()

        return result

    def _trigger_ui_update(self) -> None:
        """Trigger UI update for todo panel if available."""
        # Try to find the chat app and trigger update
        try:
            # This is a bit of a hack, but we need to trigger UI updates
            # The todo_manager should be connected to a chat app
            current_list = self.todo_manager.get_current_todo_list()
            if hasattr(self.todo_manager, '_chat_app'):
                self.todo_manager._chat_app.update_todo_panel()
        except Exception:
            # Ignore UI update errors
            pass

    def _create_todo_list(self, **kwargs) -> Dict[str, Any]:
        """Create a new todo list.

        Args:
            title: Title for the todo list
            description: Optional description
            items: List of todo item descriptions

        Returns:
            Result of todo list creation
        """
        title = kwargs.get("title")
        description = kwargs.get("description", "")
        items = kwargs.get("items", [])

        if not title:
            return {"success": False, "error": "Title is required for creating todo list"}

        if not items:
            return {"success": False, "error": "Items list is required for creating todo list"}

        # Create todo list
        todo_list = self.todo_manager.create_todo_list(title, description)

        # Add items
        added_items = []
        for item_content in items:
            if isinstance(item_content, str):
                item = todo_list.add_item(item_content)
                added_items.append(item.to_dict())
            elif isinstance(item_content, dict):
                item = todo_list.add_item(
                    content=item_content.get("content", ""),
                    metadata=item_content.get("metadata", {})
                )
                added_items.append(item.to_dict())

        return {
            "success": True,
            "todo_list_id": todo_list.id,
            "title": todo_list.title,
            "items_count": len(added_items),
            "items": added_items,
            "message": f"Created todo list '{title}' with {len(added_items)} tasks"
        }

    def _update_todo_item(self, **kwargs) -> Dict[str, Any]:
        """Update a todo item status.

        Args:
            item_id: ID of item to update
            status: New status
            active_form: Active form description (optional)

        Returns:
            Result of item update
        """
        item_id = kwargs.get("item_id")
        status_str = kwargs.get("status", "").lower()
        active_form = kwargs.get("active_form", "")

        if not item_id:
            return {"success": False, "error": "item_id is required for updating todo item"}

        # Convert status string to TodoStatus enum
        status_map = {
            "pending": TodoStatus.PENDING,
            "in_progress": TodoStatus.IN_PROGRESS,
            "completed": TodoStatus.COMPLETED,
            "cancelled": TodoStatus.CANCELLED,
        }

        if status_str not in status_map:
            return {"success": False, "error": f"Invalid status: {status_str}. Must be one of: {list(status_map.keys())}"}

        status = status_map[status_str]

        # Support both index-based (0, 1, 2) and ID-based updates
        current_list = self.todo_manager.get_current_todo_list()
        if not current_list:
            return {"success": False, "error": "No active todo list found"}

        # Enforce sequential processing rules
        if status == TodoStatus.IN_PROGRESS:
            # Check if there's already an item in progress
            in_progress_items = [item for item in current_list.items if item.status == TodoStatus.IN_PROGRESS]
            if in_progress_items:
                return {
                    "success": False,
                    "error": f"Cannot mark item '{item_id}' as in_progress. Item '{in_progress_items[0].content[:30]}...' is already in progress. Complete it first."
                }

        # Try to find the item
        target_item = None

        # First, try to use item_id directly if it's not a simple index
        if not item_id.isdigit():
            target_item = current_list.get_item(item_id)

        # If not found and item_id is a digit, try index-based access
        if target_item is None:
            try:
                index = int(item_id)
                if 0 <= index < len(current_list.items):
                    target_item = current_list.items[index]

                    # Enforce sequential processing for index-based access
                    if status == TodoStatus.IN_PROGRESS:
                        # Check if all previous items are completed
                        for i in range(index):
                            if current_list.items[i].status not in [TodoStatus.COMPLETED, TodoStatus.CANCELLED]:
                                return {
                                    "success": False,
                                    "error": f"Cannot start item {index}. Previous item {i} ('{current_list.items[i].content[:30]}...') must be completed first."
                                }

            except (ValueError, IndexError):
                pass

        if target_item is None:
            return {"success": False, "error": f"Item with ID or index '{item_id}' not found"}

        # Update item using the found item's actual ID
        success = self.todo_manager.update_item_status(target_item.id, status, active_form)

        # Start todo panel spinner when item is set to in_progress
        if success and status == TodoStatus.IN_PROGRESS:
            try:
                if hasattr(self.todo_manager, '_chat_app'):
                    chat_app = self.todo_manager._chat_app
                    if hasattr(chat_app, 'todo_panel') and hasattr(chat_app.todo_panel, 'start_spinner'):
                        chat_app.todo_panel.start_spinner(active_form or "Working on task...")
                        # Debug: Force UI update to trigger spinner animation
                        if hasattr(chat_app, 'update_todo_panel'):
                            chat_app.update_todo_panel()
            except Exception as e:
                # Debug: Print error to see what's failing
                print(f"DEBUG: Todo spinner error: {e}")
                pass
        elif success and status == TodoStatus.COMPLETED:
            # Stop spinner when item is completed
            try:
                if hasattr(self.todo_manager, '_chat_app'):
                    chat_app = self.todo_manager._chat_app
                    if hasattr(chat_app, 'todo_panel') and hasattr(chat_app.todo_panel, 'stop_spinner'):
                        chat_app.todo_panel.stop_spinner()
            except Exception as e:
                # Silently ignore spinner errors to not affect tool execution
                pass

        if success:
            # Get current todo list for status info
            current_list = self.todo_manager.get_current_todo_list()
            if current_list:
                item = current_list.get_item(item_id)
                if item:
                    progress = current_list.get_progress_percentage()
                    return {
                        "success": True,
                        "item_id": item_id,
                        "status": status.value,
                        "active_form": active_form,
                        "progress_percentage": progress,
                        "message": f"Updated item '{item.content[:50]}...' to {status.value}"
                    }

        return {"success": False, "error": f"Failed to update item {item_id}"}

    def _clear_todo_list(self, **kwargs) -> Dict[str, Any]:
        """Clear the current todo list.

        Returns:
            Result of clearing todo list
        """
        current_list = self.todo_manager.get_current_todo_list()
        if not current_list:
            return {"success": False, "error": "No active todo list to clear"}

        list_title = current_list.title
        self.todo_manager.clear_current_todo_list()

        return {
            "success": True,
            "message": f"Cleared todo list '{list_title}'"
        }

    def _list_todo_items(self, **kwargs) -> Dict[str, Any]:
        """List current todo items.

        Returns:
            Current todo list information
        """
        current_list = self.todo_manager.get_current_todo_list()
        if not current_list:
            return {"success": False, "error": "No active todo list"}

        items = []
        for item in current_list.items:
            items.append(item.to_dict())

        return {
            "success": True,
            "todo_list_id": current_list.id,
            "title": current_list.title,
            "description": current_list.description,
            "items": items,
            "progress_percentage": current_list.get_progress_percentage(),
            "is_all_completed": current_list.is_all_completed()
        }

    def _adapt_todo_list(self, **kwargs) -> Dict[str, Any]:
        """Adapt the current todo list to a new plan, preserving completed work.

        Args:
            title: New title for the todo list (optional)
            description: New description (optional)
            items: New list of todo items
            keep_completed: Whether to keep completed items (default: true)

        Returns:
            Result of adapting todo list
        """
        current_list = self.todo_manager.get_current_todo_list()
        if not current_list:
            return {"success": False, "error": "No active todo list to adapt"}

        title = kwargs.get("title", current_list.title)
        description = kwargs.get("description", current_list.description)
        new_items = kwargs.get("items", [])
        keep_completed = kwargs.get("keep_completed", True)

        if not new_items:
            return {"success": False, "error": "New items list is required for adapting todo list"}

        # Get completed items from current list if keeping them
        completed_items = []
        if keep_completed:
            completed_items = [
                item for item in current_list.items
                if item.status in [TodoStatus.COMPLETED, TodoStatus.CANCELLED]
            ]

        # Create new todo list with updated title and description
        new_list = self.todo_manager.create_todo_list(title, description)

        # Add completed items first with strikethrough indication
        for completed_item in completed_items:
            # Mark as completed but add a note that it was from previous plan
            new_item = new_list.add_item(f"✓ {completed_item.content}")
            new_item.mark_completed()

        # Add new items
        added_items = []
        for item_content in new_items:
            if isinstance(item_content, str):
                item = new_list.add_item(item_content)
                added_items.append(item.to_dict())
            elif isinstance(item_content, dict):
                item = new_list.add_item(
                    content=item_content.get("content", ""),
                    metadata=item_content.get("metadata", {})
                )
                added_items.append(item.to_dict())

        # Calculate progress including previously completed items
        total_items = len(new_list.items)
        completed_count = len([item for item in new_list.items if item.status in [TodoStatus.COMPLETED, TodoStatus.CANCELLED]])
        progress = (completed_count / total_items * 100) if total_items > 0 else 0

        return {
            "success": True,
            "todo_list_id": new_list.id,
            "title": new_list.title,
            "items_count": len(new_list.items),
            "completed_items": completed_count,
            "new_items": len(added_items),
            "progress_percentage": progress,
            "message": f"Adapted todo list '{title}' with {completed_count} completed items and {len(added_items)} new items"
        }

    def get_schema(self) -> Dict[str, Any]:
        """Get JSON schema for the tool parameters.

        Returns:
            JSON schema dictionary
        """
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["create", "update", "clear", "list", "adapt"],
                    "description": "Action to perform"
                },
                "title": {
                    "type": "string",
                    "description": "Title for the todo list (required for create, optional for adapt)"
                },
                "description": {
                    "type": "string",
                    "description": "Optional description for the todo list"
                },
                "items": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    },
                    "description": "List of todo item descriptions (required for create and adapt)"
                },
                "item_id": {
                    "type": "string",
                    "description": "ID of the todo item to update (required for update)"
                },
                "status": {
                    "type": "string",
                    "enum": ["pending", "in_progress", "completed", "cancelled"],
                    "description": "New status for the todo item (required for update)"
                },
                "active_form": {
                    "type": "string",
                    "description": "Description of what's currently being done (for in_progress status)"
                },
                "keep_completed": {
                    "type": "boolean",
                    "description": "Whether to keep completed items when adapting plan (default: true)"
                }
            },
            "required": ["action"]
        }