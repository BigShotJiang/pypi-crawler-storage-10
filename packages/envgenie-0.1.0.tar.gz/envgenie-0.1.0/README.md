# EnvGenie

EnvGenie is a smart environment configuration manager for Python projects.  
It automatically loads configuration values from system environment variables, `.env` files, and YAML/JSON configs — in the right priority.

## 🚀 Features
- Load settings from multiple sources
- Support for multiple profiles (development, production)
- Schema validation
- Simple and safe to use

## 📦 Installation
```bash
pip install envgenie
