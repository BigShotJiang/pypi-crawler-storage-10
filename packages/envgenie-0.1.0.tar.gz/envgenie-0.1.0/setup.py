from setuptools import setup, find_packages

setup(
    name="envgenie",
    version="0.1.0",
    author="Your Name",
    author_email="you@example.com",
    description="Smart environment configuration manager for Python apps",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/envgenie",  # optional if you publish
    packages=find_packages(),
    install_requires=[
        "pyyaml>=6.0"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)
