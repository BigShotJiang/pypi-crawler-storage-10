from panther.openapi.schemas import OutputSchema
