import json
import logging
import os
import pickle
import re
import socket
import weakref
import zlib
from _weakref import ReferenceType
from contextlib import contextmanager, suppress
from dataclasses import dataclass
from functools import cache
from inspect import signature
from struct import unpack
from typing import Callable
from urllib.parse import quote_plus

import pytest
from comfy.domain import (
    COMFY_PROXY_CONNECT_TIMEOUT, COMFY_PROXY_HOST, COMFY_PROXY_PORT
)
from comfy.model import CliOutput, Device
from comfy.model.cliproxy import DeviceProxyCli

__tracebackhide__ = True

from netmiko import ConnectHandler

log = logging.getLogger(__name__)
logx = {False: '.ok', True: '.err'}

CAP_DEVICE_REPLY = 256


@cache
def get_trace_dir() -> str:
    trace_dir = os.environ.get('CLI_TRACE_DIR')
    if trace_dir:
        try:
            os.makedirs(trace_dir, exist_ok=True)
        except OSError:
            log.error('Could not create %s, tracing disabled', trace_dir)
            trace_dir = None
    return trace_dir


# TODO: remove
# @cache
# def get_structured_signature():
#     from netmiko.utilities import structured_data_converter
#     return inspect.signature(structured_data_converter)


# class AsyncTcpConnection:
#     host = None
#     port = None
#     reader = None
#     writer = None
#
#     def __init__(self, host, port):
#         self.host, self.port = host, port
#
#     async def connect(self):
#         channels = await asyncio.open_connection(self.host, self.port)
#         self.reader, self.writer = channels
#
#     async def call(self, data: str):
#         self.writer.write(data.encode())
#         await self.writer.drain()
#         hdr = await self.reader.readline()
#         length = int(hdr.decode()) if hdr else None
#         data = await self.reader.readexactly(length)
#         return None if data is None else data.decode()
#
#
# class AsyncTcpProxyCli(DeviceProxyCli):
#     conn: AsyncTcpConnection = None
#
#     async def proxy(self, method, **kwargs):
#         args = json.dumps(kwargs, separators=(',', ':'))
#         request = f"method {args}"
#         conn = self.ensure_connection()
#         result = await conn.call(request)
#         return result
#
#     async def ensure_connection(self) -> AsyncTcpConnection:
#         if self.conn is None:
#             self.conn = AsyncTcpConnection('localhost', 9876)
#             await self.conn.connect()
#         return self.conn
#
#


class CliProxyError(Exception):
    pass


@dataclass
class Agent:
    host: str
    port: int
    conn_timeout: float


def is_socket_closed(sock: socket.socket) -> bool:
    if sock._closed or sock.fileno() == -1:
        return True
    to = sock.gettimeout()
    sock.settimeout(.01)
    try:
        # this will try to read bytes without blocking and
        # also without removing them from buffer (peek only)
        data = sock.recv(16, socket.MSG_DONTWAIT | socket.MSG_PEEK)
        if len(data) == 0:
            return True
    except BlockingIOError:
        pass  # socket is open and reading from it would block
    except ConnectionResetError:
        return True  # socket was closed for some other reason
    except Exception:
        pass
    sock.settimeout(to)
    return False


ProxySocketKey = tuple[str, int, str]
SocketWeakRef = ReferenceType[socket.socket]


class ProxySockets:
    open_proxies: dict[ProxySocketKey, weakref.ReferenceType] = {}

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release()

    def release(self):
        refs = self.open_proxies.values()
        log.debug('Releasing open_proxies %r', refs)
        sock: socket.socket
        for sock in (sock for sref in refs if sref and (sock := sref())):
            with suppress(Exception):
                sock.close()

    def _remove_socket_ref(self, s: SocketWeakRef) -> ProxySocketKey | None:
        for k, v in self.open_proxies.items():
            if s == v:
                break
        else:
            return None
        self.drop(k)
        return k

    def drop(self, key: ProxySocketKey):
        self.open_proxies.pop(key, None)

    def find(self, key):
        ref = self.open_proxies.get(key)
        if ref and (s := ref()):
            if not is_socket_closed(s):
                return s
            self.drop(key)
        return None

    def open(self, key: ProxySocketKey):
        from _socket import timeout
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(10)
        host, port, _ = key
        try:
            s.connect((host, port))
        except (socket.error, timeout) as exc:
            raise type(exc)(f"{exc} [comfy-cli-proxy {host}:{port}]")
        self.open_proxies[key] = weakref.ref(s, self._remove_socket_ref)
        return s

    def get(
            self,
            host: str,
            port: int,
            device_id: str
    ) -> tuple[socket.socket, bool]:
        key = host, port, device_id
        if s := self.find(key):
            return s, True
        return self.open(key), False


def cap_msg(uncapped: str | bytes):
    capped = uncapped[:CAP_DEVICE_REPLY]
    if len(uncapped) > CAP_DEVICE_REPLY:
        capped = f"{capped}... (length={len(uncapped)})"
    return capped


re_ehlo = re.compile('OK (?P<timeout>[.0-9]+)(?P<override>!??)')
read_timeout = 'read_timeout'


@cache
def plus_five_procent(base: float | int) -> float | int:
    return base + min(int(base) >> 3, 2)


class TcpProxyCli(DeviceProxyCli):
    proxies: ProxySockets = None
    conn: socket.socket | None = None
    socket_timeout: float | None = None
    read_timeout_override: float | None = None

    def __init__(self, agent: Agent, device: Device, proxies: ProxySockets):
        super().__init__(device)
        self.agent = agent
        self.platform = device.platform
        self.proxies = proxies
        device_id = f"{device.tenant}::{device.ipaddress}"
        self.key = agent.host, agent.port, device_id

    def close(self):
        self.proxies.drop(self.key)
        self.conn and self.conn.close()
        self.conn = None

    def set_sock_timeout(self, timeout: float | None = None):
        if timeout != -1 and self.conn is not None:
            value = plus_five_procent(timeout or self.socket_timeout)
            self.conn.settimeout(value)

    def get_timeout(self, method: str, kwargs) -> float | None:
        if self.read_timeout_override:
            return self.read_timeout_override
        handler = ConnectHandler(auto_connect=False,
                                 host='any', device_type=self.platform)
        maybe_method = getattr(handler, method, None)
        if callable(maybe_method) is False:
            return -1
        params = signature(maybe_method).parameters
        if (read_timeout_param := params.get(read_timeout)) is None:
            return -1
        return kwargs.get(read_timeout, read_timeout_param.default)

    def establish_protocol(self, s: socket.socket):
        dev = self.device.as_json()
        hello = f"{dev}\n"
        s.sendall(hello.encode())
        s.settimeout(self.agent.conn_timeout)
        ehlo = self.read_reply(conn=s)
        log.debug('proxy hello %s', ehlo)
        if not (m := re.fullmatch(re_ehlo, ehlo)):
            raise CliProxyError('invalid agent reply')
        kw_group = m.groupdict()
        self.socket_timeout = timeout = int(kw_group['timeout'])
        if kw_group['override']:
            self.read_timeout_override = timeout

    def ensure_connection(self) -> socket.socket:
        if self.conn is None:
            s, with_handshake = self.proxies.get(*self.key)
            if not with_handshake:
                self.establish_protocol(s)
            self.conn = s
            self.set_sock_timeout()
        return self.conn

    @contextmanager
    def set_reply_timeout(self, method, kwargs):
        timeout = self.get_timeout(method, kwargs)
        self.set_sock_timeout(timeout)
        try:
            yield
        finally:
            timeout == -1 or self.set_sock_timeout()

    def proxy(self, method, **kwargs):
        cmd_emitter: str | None = kwargs.pop('cmd_emitter', None)
        args = json.dumps(kwargs, separators=(',', ':'))
        request = f"{method} {args}\n".encode()
        self.trace_and_log(log.debug, request, '>>')
        conn = self.ensure_connection()
        try:
            conn.sendall(request)
        except OSError:
            self.close()
            conn = self.ensure_connection()
            conn.sendall(request)

        with self.set_reply_timeout(method, kwargs):
            result = self.read_reply(cmd_emitter)

        if cmd_emitter and isinstance(result, str):
            result = CliOutput.new(result, self.device.platform, cmd_emitter)
        return result

    def read_reply(self, *args, **kwargs) -> str:
        try:
            return self._read_reply(*args, **kwargs)
        except (socket.error, OSError, TimeoutError, CliProxyError):
            self.close()
            raise

    def _read_reply(
            self,
            cmd_emitter: str | None = None,
            conn: socket.socket | None = None
    ) -> str:
        conn = conn or self.conn
        if is_socket_closed(conn):
            raise CliProxyError('Peer closed the connection')
        size = conn.recv(8 + 1)
        if not size:
            raise CliProxyError('Peer closed the connection')
        length, = unpack('>Q', size[:8])
        flag = size[-1]
        response_bytes = b''
        while length > 0:
            data = conn.recv(min(length, 4096))
            response_bytes += data
            length -= len(data)
        data = response_bytes
        error = (flag & 1) == 0
        if flag & 0x80:
            data = zlib.decompress(data)
        pickled = flag & 0x040
        response = None
        str_emitter = str(cmd_emitter) if cmd_emitter is not None else None
        try:
            if pickled:
                try:
                    result = pickle.loads(data)
                    response = str(result)
                except pickle.PickleError as exc:
                    raise CliProxyError(cap_msg(response_bytes)) from exc
            else:
                response = data.decode()
                try:
                    result = json.loads(response)
                except json.JSONDecodeError as exc:
                    raise CliProxyError(cap_msg(response_bytes)) from exc
            self.record_call(str_emitter, result)
            if error:
                raise CliProxyError(getattr(result, 'message', result))
            return result
        finally:
            self.trace_and_log(log.debug, response, '<<', str_emitter, error)

    def trace_and_log(
            self,
            writer: Callable,
            uncapped: str | bytes,
            prefix: str | None = None,
            cmd: str | None = None,
            error: bool = False
    ):
        fmt = '%r' if prefix is None else f"{prefix} %r"
        writer(fmt, cap_msg(uncapped))
        if cmd and (trace_dir := get_trace_dir()):
            fname = f"{self.device.ipaddress}--{quote_plus(cmd)}"
            file = os.path.join(trace_dir, fname)
            ext = logx[error]
            with suppress(OSError), open(f"{file}{ext}", 'w') as f:
                f.write(uncapped)


@pytest.hookimpl
def pytest_cli_proxy(
        config: pytest.Config,
        device: Device,
        async_ctx: bool
) -> DeviceProxyCli:
    proxies = device.ctx.stash.setdefault('pytest_cli_proxy', ProxySockets())
    device.ctx.finalizers.add(proxies.release)
    host = config.getoption(f"--{COMFY_PROXY_HOST}")
    port = config.getoption(f"--{COMFY_PROXY_PORT}")
    conn_timeout = config.getoption(f"--{COMFY_PROXY_CONNECT_TIMEOUT}")
    agent = Agent(host=host, port=port, conn_timeout=conn_timeout)
    cli = TcpProxyCli(agent, device, proxies)
    log.debug('created cli_proxy for %r', device)
    return cli


@pytest.hookimpl
def pytest_addoption(parser):
    host = os.environ.get('CLI_PROXY_HOST', 'agent')
    port = int(os.environ.get('CLI_PROXY_PORT', '9876'))

    group = parser.getgroup("comfy-cli-proxy")
    group.addoption(
        f"--{COMFY_PROXY_HOST}",
        action='store',
        default=host,
        help='Hostname/address of the cli proxy server',
    )
    group.addoption(
        f"--{COMFY_PROXY_PORT}",
        action='store',
        type=int,
        default=port,
        help='Port of the cli proxy server',
    )
    group.addoption(
        f"--{COMFY_PROXY_CONNECT_TIMEOUT}",
        action='store',
        type=float,
        default=60,
        help='Port of the cli proxy server',
    )
