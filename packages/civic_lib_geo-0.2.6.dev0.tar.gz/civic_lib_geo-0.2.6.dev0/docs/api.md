# API Reference

Auto-generated code documentation.

::: civic_lib_geo
    options:
      show_submodules: true
      show_source: true
