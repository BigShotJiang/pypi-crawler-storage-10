# Civic Interconnect Project Documentation

Welcome to the documentation hub for Civic Interconnect (CI) projects.

Use the navigation menu to explore available modules, APIs, and tools.

For more information, visit the [Civic Interconnect GitHub organization](https://github.com/civic-interconnect).
