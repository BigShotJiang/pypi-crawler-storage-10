class DeviceError(Exception):
    pass
