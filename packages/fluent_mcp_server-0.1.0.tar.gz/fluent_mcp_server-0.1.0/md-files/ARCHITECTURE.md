# ANSYS Fluent MCP Server - Architecture

## Vision

A Python-based MCP server that enables seamless integration between ANSYS Fluent and AI coding assistants, providing access to Fluent's CFD capabilities, documentation, and workflow automation.

**Design Philosophy:** Following the MATLAB MCP server pattern, this server is designed to complement AI coding assistants by:

- **Computational operations** - Leverage Fluent's CFD capabilities
- **Documentation access** - Search and retrieve Fluent help documentation
- **Data bridge** - Move data between files and Fluent sessions
- **Workflow automation** - Common CFD setup and analysis patterns

**Not in scope:** File system operations are handled by the coding assistant's native tools.

## Technology Stack

- **Python 3.10+** - Core language
- **uv** - Fast Python package manager and environment manager
- **FastMCP** - Lightweight MCP server framework (simpler than full `mcp` package)
- **PyFluent** - ANSYS Fluent Python API (if available)
- **Alternative:** Direct interaction with Fluent via TUI commands or journal files

## Core Components

### Project Structure
```
fluent-mcp-server/
├── src/
│   └── fluent_mcp_server/
│       ├── __init__.py
│       ├── server.py          # Main MCP server with FastMCP
│       ├── fluent_engine.py   # Fluent connection/execution wrapper
│       ├── tools.py           # MCP tool definitions
│       ├── resources.py       # MCP resource definitions
│       └── help_search.py     # Documentation search implementation
├── md-files/
│   ├── ARCHITECTURE.md        # This file
│   ├── PLANNING.md           # Roadmap and feature plans
│   ├── TOOLS.md              # Tool catalog and usage
│   └── RESOURCES.md          # Resource documentation
├── examples/
│   └── basic_help_search.py  # Example usage
├── scripts/
│   └── setup_fluent.py       # Environment setup helpers
├── tests/
│   ├── test_server.py
│   ├── test_tools.py
│   └── test_help_search.py
├── pyproject.toml            # uv/pip project config
├── .python-version           # Python version (3.10+)
├── .mcp.json                 # MCP server config example
└── README.md
```

## Phase 1: Minimal Implementation (Current)

### Goals
1. ✅ Project structure with uv + FastMCP
2. 🔄 Implement `search_help` tool
3. ⏳ Basic documentation
4. ⏳ Example usage

### Tool: `search_help`

**Purpose:** Search ANSYS Fluent documentation for commands, concepts, and usage examples.

**Input Schema:**
```json
{
  "query": "string (required) - search term or question",
  "category": "string (optional) - filter by category (commands/theory/tutorial/reference)",
  "max_results": "number (optional) - limit results (default: 5)"
}
```

**Output:**
- Text content with formatted search results
- Each result includes: title, category, summary, relevance score

**Implementation Options:**

1. **Option A: Static Documentation Index**
   - Pre-indexed JSON file with Fluent commands and help topics
   - Fast, no Fluent installation required
   - Limited to indexed content

2. **Option B: PyFluent Integration**
   - Use PyFluent's help system if available
   - Dynamic, up-to-date with user's Fluent version
   - Requires PyFluent and Fluent installation

3. **Option C: Hybrid Approach** (Recommended)
   - Static index for common commands
   - Fallback to PyFluent if available
   - Web scraping Fluent docs as last resort

### Initial Implementation Plan

**File: `src/fluent_mcp_server/help_search.py`**
```python
class FluentHelpSearch:
    """Search engine for Fluent documentation."""

    def __init__(self, index_path: str = None):
        """Initialize with static index or build from PyFluent."""
        pass

    def search(self, query: str, category: str = None,
               max_results: int = 5) -> list[dict]:
        """Search documentation and return results."""
        pass

    def _build_static_index(self) -> dict:
        """Build index from static documentation."""
        pass

    def _search_pyfluent(self, query: str) -> list[dict]:
        """Search using PyFluent help system."""
        pass
```

**File: `src/fluent_mcp_server/server.py`**
```python
from fastmcp import FastMCP

# Initialize FastMCP server
mcp = FastMCP("fluent-mcp-server")

# Register tools
from .tools import register_tools
register_tools(mcp)

# Entry point
if __name__ == "__main__":
    mcp.run()
```

**File: `src/fluent_mcp_server/tools.py`**
```python
from fastmcp import FastMCP
from .help_search import FluentHelpSearch

def register_tools(mcp: FastMCP):
    help_search = FluentHelpSearch()

    @mcp.tool()
    def search_help(query: str, category: str = None,
                    max_results: int = 5) -> str:
        """Search ANSYS Fluent documentation."""
        results = help_search.search(query, category, max_results)
        # Format and return results
        return format_search_results(results)
```

## Future Phases

### Phase 2: Core Fluent Integration
- **execute_tui** - Execute TUI commands
- **workspace** - Manage case data and variables
- **case_io** - Load/save case and data files
- **env** - Get Fluent version and license info

### Phase 3: Workflow Automation
- **mesh_quality** - Check and report mesh quality
- **boundary_conditions** - Setup common BC patterns
- **solver_settings** - Configure solver parameters
- **post_process** - Extract results and create plots

### Phase 4: Advanced Features
- **parametric_studies** - Automated parameter sweeps
- **convergence_monitoring** - Track and analyze convergence
- **batch_processing** - Queue multiple simulations
- **result_comparison** - Compare cases and configurations

## Design Principles

1. **Token Efficiency** - Minimize API calls by combining operations
2. **Fail-Safe** - Graceful degradation when Fluent unavailable
3. **Self-Documenting** - Clear tool descriptions and schemas
4. **Modular** - Easy to add new tools and capabilities
5. **Testable** - Unit tests for all components
6. **Pythonic** - Follow Python best practices with uv/FastMCP

## Configuration

### User Configuration (.mcp.json)
```json
{
  "mcpServers": {
    "fluent": {
      "command": "uvx",
      "args": ["fluent-mcp-server"],
      "env": {
        "FLUENT_VERSION": "2024R2",
        "AWP_ROOT242": "/path/to/ansys_inc/v242"
      }
    }
  }
}
```

### Development Configuration
```bash
# Use uv for development
uv pip install -e ".[dev]"

# Run tests
uv run pytest

# Run server locally
uv run fluent-mcp-server
```

## Success Metrics

### Phase 1 Complete When:
- [x] Project structure created
- [ ] `search_help` tool functional with static index
- [ ] 5+ common Fluent commands indexed
- [ ] Basic tests passing
- [ ] README with quick start guide
- [ ] Example demonstrating help search

### Future Success Metrics:
- [ ] 50+ Fluent commands indexed
- [ ] PyFluent integration working
- [ ] 90%+ test coverage
- [ ] Sub-second response for help queries
- [ ] Full CRUD operations on Fluent cases
