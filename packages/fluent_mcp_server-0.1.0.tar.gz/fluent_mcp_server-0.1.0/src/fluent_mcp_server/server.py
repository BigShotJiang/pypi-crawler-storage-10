"""ANSYS Fluent MCP Server using FastMCP."""

from fastmcp import FastMCP
from .help_search import FluentHelpSearch

# Initialize FastMCP server
mcp = FastMCP("fluent-mcp-server")

# Initialize help search engine
help_search = FluentHelpSearch()


@mcp.tool()
def search_help(
    query: str,
    category: str | None = None,
    max_results: int = 5
) -> str:
    """Search ANSYS Fluent documentation for commands, concepts, and usage examples.

    Args:
        query: Search term or question (e.g., "iterate", "read case", "turbulence model")
        category: Optional filter by category (commands/theory/setup/solver/postprocessing/io/mesh/parallel/models)
        max_results: Maximum number of results to return (default: 5)

    Returns:
        Formatted search results with command names, descriptions, and examples
    """
    # Perform search
    results = help_search.search(query, category, max_results)

    if not results:
        available_categories = ", ".join(help_search.get_categories())
        return (
            f"No results found for '{query}'.\n\n"
            f"Available categories: {available_categories}\n\n"
            f"Try:\n"
            f"- More general search terms (e.g., 'solve' instead of 'solve/iterate')\n"
            f"- Different keywords (e.g., 'run' instead of 'execute')\n"
            f"- Browsing a specific category using the category parameter"
        )

    # Format results
    output = [f"Found {len(results)} result(s) for '{query}':\n"]

    for i, result in enumerate(results, 1):
        output.append(f"\n{'='*60}")
        output.append(f"{i}. {result['name']} ({result['type']}, {result['category']})")
        output.append(f"   Relevance: {result['relevance']:.2f}")
        output.append(f"\n   {result['summary']}")
        output.append(f"\n   {result['description']}")

        if result.get('examples'):
            output.append("\n   Examples:")
            for example in result['examples']:
                output.append(f"     - {example}")

    output.append(f"\n{'='*60}")

    # Add helpful footer
    output.append("\n\nTip: Use the category parameter to filter results by:")
    output.append(f"  {', '.join(help_search.get_categories())}")

    return "\n".join(output)


@mcp.tool()
def list_categories() -> str:
    """List all available documentation categories.

    Returns:
        List of categories that can be used to filter search results
    """
    categories = help_search.get_categories()
    return (
        "Available Fluent documentation categories:\n\n"
        + "\n".join(f"  - {cat}" for cat in categories)
        + "\n\nUse these with search_help(query, category=...) to filter results."
    )


@mcp.tool()
def list_commands() -> str:
    """List all indexed Fluent TUI commands.

    Returns:
        List of all available command names in the help index
    """
    commands = help_search.get_all_commands()
    return (
        f"Indexed Fluent commands ({len(commands)} total):\n\n"
        + "\n".join(f"  - {cmd}" for cmd in commands)
        + "\n\nUse search_help(query) to get detailed information about any command."
    )


def main():
    """Entry point for the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
