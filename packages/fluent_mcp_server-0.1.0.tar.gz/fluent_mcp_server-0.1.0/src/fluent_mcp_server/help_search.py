"""Fluent documentation search engine."""

import json
from pathlib import Path
from typing import Optional


class FluentHelpSearch:
    """Search engine for ANSYS Fluent documentation.

    Supports multiple search strategies:
    1. Static index of common commands (fast, always available)
    2. PyFluent integration (if available)
    3. Future: Web scraping of online docs
    """

    def __init__(self, index_path: Optional[str] = None):
        """Initialize the help search engine.

        Args:
            index_path: Path to custom help index JSON. If None, uses built-in index.
        """
        self.index_path = index_path
        self.help_index = self._load_index()

    def _load_index(self) -> dict:
        """Load help index from file or use built-in static index."""
        if self.index_path and Path(self.index_path).exists():
            with open(self.index_path, 'r') as f:
                return json.load(f)

        # Built-in static index with common Fluent commands
        return self._get_static_index()

    def _get_static_index(self) -> dict:
        """Return built-in static index of common Fluent commands and concepts."""
        return {
            "commands": [
                {
                    "name": "solve/iterate",
                    "category": "solver",
                    "summary": "Perform iterations to solve the current case",
                    "description": "Execute solution iterations. Syntax: solve/iterate <num_iterations>",
                    "examples": ["solve/iterate 100", "solve/iterate 1000"],
                    "keywords": ["solve", "iterate", "run", "calculate", "compute"]
                },
                {
                    "name": "file/read-case",
                    "category": "io",
                    "summary": "Read a case file into Fluent",
                    "description": "Load a case file (.cas or .cas.h5). Syntax: file/read-case <filename>",
                    "examples": ["file/read-case \"case.cas\"", "file/read-case \"simulation.cas.h5\""],
                    "keywords": ["read", "load", "open", "case", "import"]
                },
                {
                    "name": "file/write-case",
                    "category": "io",
                    "summary": "Write the current case to a file",
                    "description": "Save the current case setup. Syntax: file/write-case <filename>",
                    "examples": ["file/write-case \"case.cas\"", "file/write-case \"simulation.cas.h5\""],
                    "keywords": ["write", "save", "export", "case"]
                },
                {
                    "name": "file/read-data",
                    "category": "io",
                    "summary": "Read solution data from a file",
                    "description": "Load solution data (.dat or .dat.h5). Syntax: file/read-data <filename>",
                    "examples": ["file/read-data \"data.dat\"", "file/read-data \"solution.dat.h5\""],
                    "keywords": ["read", "load", "data", "solution", "results"]
                },
                {
                    "name": "file/write-data",
                    "category": "io",
                    "summary": "Write solution data to a file",
                    "description": "Save current solution data. Syntax: file/write-data <filename>",
                    "examples": ["file/write-data \"data.dat\"", "file/write-data \"solution.dat.h5\""],
                    "keywords": ["write", "save", "export", "data", "solution"]
                },
                {
                    "name": "define/models/viscous",
                    "category": "models",
                    "summary": "Set the viscous model (laminar, turbulent, etc.)",
                    "description": "Configure viscosity and turbulence models. Common options: laminar, k-epsilon, k-omega, SST",
                    "examples": ["define/models/viscous/k-epsilon-standard yes", "define/models/viscous/kw-sst yes"],
                    "keywords": ["viscous", "turbulence", "laminar", "k-epsilon", "k-omega", "sst", "model"]
                },
                {
                    "name": "define/boundary-conditions",
                    "category": "setup",
                    "summary": "Set boundary conditions for zones",
                    "description": "Define inlet, outlet, wall, and other boundary conditions",
                    "examples": ["define/boundary-conditions/velocity-inlet inlet no no yes yes no 10 no 0"],
                    "keywords": ["boundary", "bc", "inlet", "outlet", "wall", "conditions"]
                },
                {
                    "name": "solve/monitors/residual",
                    "category": "solver",
                    "summary": "Set residual convergence criteria",
                    "description": "Configure convergence monitoring based on residuals",
                    "examples": ["solve/monitors/residual/convergence-criteria 1e-6 1e-6 1e-6"],
                    "keywords": ["residual", "convergence", "monitor", "criteria"]
                },
                {
                    "name": "report/summary",
                    "category": "postprocessing",
                    "summary": "Display a summary of the current case",
                    "description": "Show case information including mesh, models, and boundary conditions",
                    "examples": ["report/summary"],
                    "keywords": ["report", "summary", "info", "case", "mesh"]
                },
                {
                    "name": "display/contour",
                    "category": "postprocessing",
                    "summary": "Create contour plots of solution variables",
                    "description": "Display contours of pressure, velocity, temperature, etc.",
                    "examples": ["display/contour pressure"],
                    "keywords": ["contour", "plot", "display", "visualize", "pressure", "velocity"]
                },
                {
                    "name": "parallel/timer/usage",
                    "category": "parallel",
                    "summary": "Display parallel performance statistics",
                    "description": "Show timing information for parallel computations",
                    "examples": ["parallel/timer/usage"],
                    "keywords": ["parallel", "performance", "timer", "mpi"]
                },
                {
                    "name": "mesh/check",
                    "category": "mesh",
                    "summary": "Check mesh quality and report issues",
                    "description": "Verify mesh integrity and quality metrics",
                    "examples": ["mesh/check"],
                    "keywords": ["mesh", "check", "quality", "verify", "validate"]
                },
                {
                    "name": "adapt/gradient",
                    "category": "mesh",
                    "summary": "Adapt mesh based on gradients",
                    "description": "Refine mesh in regions with high gradients of selected variables",
                    "examples": ["adapt/gradient pressure"],
                    "keywords": ["adapt", "refine", "gradient", "mesh", "refinement"]
                }
            ],
            "concepts": [
                {
                    "name": "TUI Commands",
                    "category": "general",
                    "summary": "Text User Interface command structure",
                    "description": "Fluent's TUI uses a hierarchical command structure. Navigate menus by typing menu names, execute commands with parameters.",
                    "keywords": ["tui", "command", "interface", "menu", "cli"]
                },
                {
                    "name": "Convergence",
                    "category": "theory",
                    "summary": "Understanding solution convergence",
                    "description": "Monitor residuals, surface integrals, and force coefficients to assess convergence. Typical residual targets: 1e-3 to 1e-6.",
                    "keywords": ["convergence", "residuals", "solution", "steady", "transient"]
                },
                {
                    "name": "Mesh Quality",
                    "category": "mesh",
                    "summary": "Mesh quality metrics and best practices",
                    "description": "Key metrics: skewness (<0.95), aspect ratio, orthogonal quality (>0.1). Use mesh/check to identify issues.",
                    "keywords": ["mesh", "quality", "skewness", "aspect ratio", "orthogonal"]
                }
            ]
        }

    def search(
        self,
        query: str,
        category: Optional[str] = None,
        max_results: int = 5
    ) -> list[dict]:
        """Search documentation for the given query.

        Args:
            query: Search term or question
            category: Optional filter by category (commands/theory/setup/solver/postprocessing/io/mesh/parallel/models)
            max_results: Maximum number of results to return

        Returns:
            List of matching help entries with relevance scores
        """
        query_lower = query.lower()
        results = []

        # Search commands
        for cmd in self.help_index.get("commands", []):
            score = self._calculate_relevance(query_lower, cmd)
            if score > 0 and (not category or cmd["category"] == category):
                results.append({
                    "type": "command",
                    "name": cmd["name"],
                    "category": cmd["category"],
                    "summary": cmd["summary"],
                    "description": cmd["description"],
                    "examples": cmd.get("examples", []),
                    "relevance": score
                })

        # Search concepts
        for concept in self.help_index.get("concepts", []):
            score = self._calculate_relevance(query_lower, concept)
            if score > 0 and (not category or concept["category"] == category):
                results.append({
                    "type": "concept",
                    "name": concept["name"],
                    "category": concept["category"],
                    "summary": concept["summary"],
                    "description": concept["description"],
                    "relevance": score
                })

        # Sort by relevance and limit results
        results.sort(key=lambda x: x["relevance"], reverse=True)
        return results[:max_results]

    def _calculate_relevance(self, query: str, entry: dict) -> float:
        """Calculate relevance score for a help entry.

        Args:
            query: Search query (lowercase)
            entry: Help entry dictionary

        Returns:
            Relevance score (0.0 to 1.0+)
        """
        score = 0.0

        # Exact match in name
        if query in entry["name"].lower():
            score += 2.0

        # Exact match in summary
        if query in entry["summary"].lower():
            score += 1.5

        # Keyword match
        keywords = entry.get("keywords", [])
        if query in [kw.lower() for kw in keywords]:
            score += 1.0

        # Partial matches in description
        if query in entry["description"].lower():
            score += 0.5

        # Word-by-word matching
        query_words = query.split()
        for word in query_words:
            if len(word) > 2:  # Ignore short words
                if word in entry["name"].lower():
                    score += 0.3
                if word in entry["summary"].lower():
                    score += 0.2
                if any(word in kw.lower() for kw in keywords):
                    score += 0.15

        return score

    def get_categories(self) -> list[str]:
        """Return list of available categories."""
        categories = set()
        for cmd in self.help_index.get("commands", []):
            categories.add(cmd["category"])
        for concept in self.help_index.get("concepts", []):
            categories.add(concept["category"])
        return sorted(categories)

    def get_all_commands(self) -> list[str]:
        """Return list of all indexed command names."""
        return [cmd["name"] for cmd in self.help_index.get("commands", [])]
