# ANSYS Fluent MCP Server

WARNING: This is a work still in planning phase Not ready to test it yet.

A Model Context Protocol (MCP) server that enables AI coding assistants to interact with ANSYS Fluent documentation and workflows.

## Features

- **Documentation Search** - Search Fluent TUI commands, concepts, and help topics
- **Fast & Lightweight** - Built with FastMCP for minimal overhead
- **Always Available** - Static index works without Fluent installation
- **Token Efficient** - Optimized for AI assistant interactions

## Quick Start

### Prerequisites

- Python 3.10 or higher
- [uv](https://docs.astral.sh/uv/getting-started/installation/) package manager

### Installation with uvx (Recommended)

No installation needed! Just configure your MCP client:

**Using Claude Code CLI:**

```bash
claude mcp add --transport stdio fluent -- uvx fluent-mcp-server
```

**Manual `.mcp.json` configuration:**

Create `.mcp.json` in your project root:

```json
{
  "mcpServers": {
    "fluent": {
      "command": "uvx",
      "args": ["fluent-mcp-server"]
    }
  }
}
```

### Development Installation

```bash
# Clone the repository
git clone <your-repo-url>
cd fluent-mcp-server

# Install with uv
uv pip install -e ".[dev]"

# Run tests
uv run pytest

# Run server
uv run fluent-mcp-server
```

## Available Tools

### `search_help`

Search ANSYS Fluent documentation for commands, concepts, and usage examples.

**Parameters:**
- `query` (required): Search term or question
- `category` (optional): Filter by category
- `max_results` (optional): Maximum results to return (default: 5)

**Example:**
```python
search_help("iterate")
search_help("boundary conditions", category="setup")
search_help("read case", max_results=3)
```

### `list_categories`

List all available documentation categories.

**Example:**
```python
list_categories()
```

### `list_commands`

List all indexed Fluent TUI commands.

**Example:**
```python
list_commands()
```

## Usage Examples

### In Claude Code

```
You: How do I run iterations in Fluent?
Claude: [Uses search_help tool with query="iterate"]

You: Show me commands for reading case files
Claude: [Uses search_help tool with query="read case" and category="io"]
```

### In Python

```python
from fluent_mcp_server.help_search import FluentHelpSearch

# Initialize search engine
searcher = FluentHelpSearch()

# Search for commands
results = searcher.search("turbulence model")

# Get all categories
categories = searcher.get_categories()

# Get all commands
commands = searcher.get_all_commands()
```

## Architecture

```
fluent-mcp-server/
├── src/fluent_mcp_server/
│   ├── server.py          # FastMCP server & tool definitions
│   ├── help_search.py     # Documentation search engine
│   └── __init__.py
├── md-files/
│   ├── ARCHITECTURE.md    # Technical architecture
│   └── ...
├── tests/                 # Unit tests
├── examples/              # Usage examples
└── pyproject.toml        # Project configuration
```

## Current Status

**Phase 1: Basic Help Search** ✅
- Static index with 13+ common Fluent commands
- Keyword-based search with relevance scoring
- Category filtering
- FastMCP integration

## Roadmap

**Phase 2: Core Fluent Integration**
- Execute TUI commands
- Workspace management
- Case I/O operations

**Phase 3: Workflow Automation**
- Mesh quality checks
- Boundary condition setup
- Solver configuration
- Post-processing

See [md-files/ARCHITECTURE.md](md-files/ARCHITECTURE.md) for details.

## Documentation

- [ARCHITECTURE.md](md-files/ARCHITECTURE.md) - Technical design and roadmap
- [Examples](examples/) - Usage examples

## License

MIT License

## Contributing

Contributions welcome! Please ensure:
- Tests pass: `uv run pytest`
- Code follows existing style
- Documentation updated
