"""Tests for Fluent help search functionality."""

import pytest
from fluent_mcp_server.help_search import FluentHelpSearch


@pytest.fixture
def searcher():
    """Create a FluentHelpSearch instance for testing."""
    return FluentHelpSearch()


def test_search_basic(searcher):
    """Test basic search functionality."""
    results = searcher.search("iterate")
    assert len(results) > 0
    assert results[0]["relevance"] > 0


def test_search_with_category(searcher):
    """Test search with category filter."""
    results = searcher.search("read", category="io")
    assert len(results) > 0
    for result in results:
        assert result["category"] == "io"


def test_search_max_results(searcher):
    """Test max_results parameter."""
    results = searcher.search("file", max_results=2)
    assert len(results) <= 2


def test_search_no_results(searcher):
    """Test search with no matches."""
    results = searcher.search("nonexistent_command_xyz123")
    assert len(results) == 0


def test_get_categories(searcher):
    """Test getting all categories."""
    categories = searcher.get_categories()
    assert len(categories) > 0
    assert "io" in categories
    assert "solver" in categories


def test_get_all_commands(searcher):
    """Test getting all command names."""
    commands = searcher.get_all_commands()
    assert len(commands) > 0
    assert "solve/iterate" in commands
    assert "file/read-case" in commands


def test_relevance_scoring(searcher):
    """Test that relevance scoring prioritizes exact matches."""
    results = searcher.search("solve/iterate")
    assert len(results) > 0
    # Exact match should have higher score
    assert results[0]["name"] == "solve/iterate"
    assert results[0]["relevance"] > 1.0


def test_keyword_matching(searcher):
    """Test keyword-based search."""
    results = searcher.search("turbulence")
    assert len(results) > 0
    # Should find viscous model entry
    assert any("viscous" in r["name"].lower() for r in results)


def test_multi_word_query(searcher):
    """Test multi-word search queries."""
    results = searcher.search("read case")
    assert len(results) > 0
    # Should find file/read-case command
    assert any("read-case" in r["name"] for r in results)


def test_case_insensitive(searcher):
    """Test that search is case-insensitive."""
    results_lower = searcher.search("iterate")
    results_upper = searcher.search("ITERATE")
    results_mixed = searcher.search("Iterate")

    # All should return same results
    assert len(results_lower) == len(results_upper) == len(results_mixed)


def test_concept_search(searcher):
    """Test searching for concepts vs commands."""
    results = searcher.search("convergence")
    assert len(results) > 0
    # Should include convergence concept
    assert any(r["type"] == "concept" for r in results)


def test_command_search(searcher):
    """Test searching specifically for commands."""
    results = searcher.search("mesh/check")
    assert len(results) > 0
    # Should include mesh/check command
    assert any(r["type"] == "command" and "mesh/check" in r["name"] for r in results)
