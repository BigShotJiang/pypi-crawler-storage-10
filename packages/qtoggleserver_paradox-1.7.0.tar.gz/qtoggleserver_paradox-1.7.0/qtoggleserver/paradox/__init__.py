from .paradoxalarm import ParadoxAlarm


__all__ = ["ParadoxAlarm"]

VERSION = "0.0.0"
