from typing import TypeAlias, Union


Property: TypeAlias = Union[int, bool, str]
