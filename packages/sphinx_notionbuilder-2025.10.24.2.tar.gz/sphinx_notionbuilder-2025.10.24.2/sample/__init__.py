"""
Sample documents to demonstrate Sphinx+Notion functionality.
"""
