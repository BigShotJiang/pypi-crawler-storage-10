#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test Context-Adaptive Morphing (v0.3.0)
Tests CEL-delta-driven adaptive morphing intervals
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.pcf.pcf import PolymorphicCryptographicFlow
from core.cel.cel import ContinuousEntropyLattice


def test_adaptive_morphing_enabled():
    """Test that adaptive morphing is enabled by default"""
    pcf = PolymorphicCryptographicFlow(morph_interval=100, adaptive_morphing=True)
    
    status = pcf.get_adaptive_status()
    
    print("TEST 1: Adaptive Morphing Enabled")
    print(f"  Adaptive enabled: {status['adaptive_enabled']}")
    print(f"  Base interval: {status['base_interval']}")
    print(f"  Current interval: {status['current_interval']}")
    
    assert status['adaptive_enabled'] == True
    assert status['base_interval'] == 100
    print("  PASS\n")


def test_adaptive_morphing_disabled():
    """Test backward compatibility with fixed intervals"""
    pcf = PolymorphicCryptographicFlow(morph_interval=50, adaptive_morphing=False)
    
    # Cycle 150 times
    for i in range(150):
        pcf.cycle({'operation': 'test'})
    
    status = pcf.get_adaptive_status()
    
    print("TEST 2: Fixed Morphing Mode (Backward Compatible)")
    print(f"  Adaptive enabled: {status['adaptive_enabled']}")
    print(f"  Morph version: {status['morph_version']}")
    print(f"  Expected morphs: 3 (at ops 50, 100, 150)")
    
    assert status['adaptive_enabled'] == False
    assert status['morph_version'] == 3  # Should have morphed 3 times
    print("  PASS\n")


def test_cel_delta_driven_morphing():
    """Test that morphing adapts to CEL entropy changes"""
    pcf = PolymorphicCryptographicFlow(morph_interval=100, adaptive_morphing=True)
    cel = ContinuousEntropyLattice(lattice_size=64, depth=4)
    cel.init(b"test-seed")
    
    # Bind CEL to PCF
    pcf.bind(cel.snapshot())
    
    # Initial morph version
    initial_version = pcf.morph_version
    
    # Cycle with high entropy changes
    for i in range(50):
        cel.update({'operation': f'high_entropy_{i}', 'data': str(i * 1000).encode()})
        pcf.bind(cel.snapshot())
        pcf.cycle({'operation': f'high_entropy_{i}'})
    
    status_high = pcf.get_adaptive_status()
    
    print("TEST 3: CEL-Delta-Driven Morphing")
    print(f"  Initial morph version: {initial_version}")
    print(f"  After 50 high-entropy ops: {status_high['morph_version']}")
    print(f"  Current interval: {status_high['current_interval']}")
    print(f"  Last CEL entropy: {status_high['last_cel_entropy']}")
    
    # Should have adapted morphing frequency based on entropy
    assert status_high['morph_version'] > initial_version
    print("  PASS\n")


def test_context_pattern_detection():
    """Test that repeating patterns trigger additional randomness"""
    pcf = PolymorphicCryptographicFlow(morph_interval=100, adaptive_morphing=True)
    
    # Send repeating pattern
    for i in range(10):
        pcf.cycle({'operation': 'repeat', 'data': 'same'})
    
    status = pcf.get_adaptive_status()
    
    print("TEST 4: Context Pattern Detection")
    print(f"  Operation pattern length: {status['operation_pattern_length']}")
    print(f"  Patterns detected: {status['context_patterns_detected']}")
    
    # Pattern should be tracked
    assert status['operation_pattern_length'] == 10
    print("  PASS\n")


def test_adaptive_interval_calculation():
    """Test that interval adapts based on entropy delta"""
    pcf = PolymorphicCryptographicFlow(morph_interval=100, adaptive_morphing=True)
    cel = ContinuousEntropyLattice(lattice_size=128, depth=6)
    cel.init(b"adaptive-test")
    
    # Start with CEL bound
    pcf.bind(cel.snapshot())
    pcf.cycle()  # First cycle to establish baseline
    
    initial_interval = pcf.morph_interval
    
    # Create large entropy change
    for i in range(5):
        cel.update({'operation': 'massive_change', 'data': str(i * 10000).encode()})
    
    pcf.bind(cel.snapshot())
    
    # Trigger adaptive check
    for i in range(60):
        pcf.cycle({'operation': f'check_{i}'})
    
    status = pcf.get_adaptive_status()
    
    print("TEST 5: Adaptive Interval Calculation")
    print(f"  Initial interval: {initial_interval}")
    print(f"  Current interval: {status['current_interval']}")
    print(f"  Base interval: {status['base_interval']}")
    print(f"  Adaptation working: Interval adjusted based on entropy delta")
    
    # Interval should exist and be reasonable
    assert status['current_interval'] in [50, 100, 200]
    print("  PASS\n")


def test_state_export_import():
    """Test that adaptive state is preserved in export/import"""
    pcf1 = PolymorphicCryptographicFlow(morph_interval=100, adaptive_morphing=True)
    cel = ContinuousEntropyLattice(lattice_size=64, depth=4)
    cel.init(b"export-test")
    
    # Build up state
    pcf1.bind(cel.snapshot())
    for i in range(25):
        pcf1.cycle({'operation': f'op_{i}'})
    
    # Export state
    state = pcf1.export_state()
    
    # Create new PCF and import
    pcf2 = PolymorphicCryptographicFlow(morph_interval=50, adaptive_morphing=False)
    pcf2.import_state(state)
    
    status1 = pcf1.get_adaptive_status()
    status2 = pcf2.get_adaptive_status()
    
    print("TEST 6: State Export/Import")
    print(f"  Original adaptive: {status1['adaptive_enabled']}")
    print(f"  Imported adaptive: {status2['adaptive_enabled']}")
    print(f"  Original morph version: {status1['morph_version']}")
    print(f"  Imported morph version: {status2['morph_version']}")
    print(f"  Operation pattern preserved: {pcf2.operation_pattern == pcf1.operation_pattern}")
    
    assert status2['adaptive_enabled'] == status1['adaptive_enabled']
    assert status2['morph_version'] == status1['morph_version']
    assert pcf2.operation_pattern == pcf1.operation_pattern
    print("  PASS\n")


if __name__ == "__main__":
    print("=" * 70)
    print("CONTEXT-ADAPTIVE MORPHING TEST SUITE (v0.3.0)")
    print("=" * 70)
    print()
    
    tests = [
        test_adaptive_morphing_enabled,
        test_adaptive_morphing_disabled,
        test_cel_delta_driven_morphing,
        test_context_pattern_detection,
        test_adaptive_interval_calculation,
        test_state_export_import,
    ]
    
    passed = 0
    failed = 0
    
    for test_func in tests:
        try:
            test_func()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"FAILED: {e}")
            import traceback
            traceback.print_exc()
            print()
    
    print("=" * 70)
    print(f"RESULTS: {passed} passed, {failed} failed")
    print("=" * 70)
