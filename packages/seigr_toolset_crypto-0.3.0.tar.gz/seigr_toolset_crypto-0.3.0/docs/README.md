# Seigr Toolset Crypto Documentation

Technical documentation for STC v0.1.0

## Contents

- [Architecture](architecture.md) - System design and component relationships
- [API Reference](api-reference.md) - Complete API documentation
- [Core Modules](core-modules.md) - Detailed module specifications
- [Usage Guide](usage-guide.md) - Practical usage examples
- [Testing](testing.md) - Test suite and validation procedures

## Quick Links

- **Installation**: See main [README.md](../README.md#installation)
- **Examples**: See [examples/](../examples/) directory
- **Source Code**: See [core/](../core/) and [interfaces/](../interfaces/)
