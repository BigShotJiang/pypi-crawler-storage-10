#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Entropy Health Monitoring Example (v0.3.0)

Demonstrates the new Entropy Health API that exposes CEL's internal
entropy monitoring to users for security-conscious applications.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from interfaces.api.stc_api import STCContext


def example_basic_monitoring():
    """Basic entropy health monitoring"""
    print("=" * 70)
    print("EXAMPLE 1: Basic Entropy Health Monitoring")
    print("=" * 70)
    
    # Create context
    ctx = STCContext('secure-seed-2024')
    
    # Check initial entropy health
    profile = ctx.get_entropy_profile()
    
    print(f"\nInitial Entropy Profile:")
    print(f"  Quality Score: {profile['quality_score']:.3f} / 1.000")
    print(f"  Status: {profile['status'].upper()}")
    print(f"  Operation Count: {profile['metrics']['operation_count']}")
    
    if profile['warnings']:
        print(f"\n  ⚠️  Warnings:")
        for warning in profile['warnings']:
            print(f"    - {warning}")
    
    if profile['recommendations']:
        print(f"\n  💡 Recommendations:")
        for rec in profile['recommendations']:
            print(f"    - {rec}")
    
    # Do some operations
    print(f"\n🔄 Performing 20 encryption operations...")
    for i in range(20):
        ctx.encrypt(f"test data {i}", context_data={'index': i})
    
    # Check again
    profile = ctx.get_entropy_profile()
    print(f"\nAfter 20 Operations:")
    print(f"  Quality Score: {profile['quality_score']:.3f}")
    print(f"  Status: {profile['status'].upper()}")
    print(f"  Total Operations: {profile['metrics']['operation_count']}")


def example_threshold_enforcement():
    """Demonstrate automatic threshold enforcement"""
    print("\n" + "=" * 70)
    print("EXAMPLE 2: Automatic Threshold Enforcement")
    print("=" * 70)
    
    ctx = STCContext('paranoid-seed-2024')
    
    # Set a balanced threshold (recommended for production)
    print(f"\n⚙️  Setting minimum entropy threshold: 0.7 (BALANCED)")
    ctx.set_minimum_entropy_threshold(0.7)
    
    print(f"\nThreshold Levels:")
    print(f"  0.9 - PARANOID (excellent entropy required)")
    print(f"  0.7 - BALANCED (good entropy required) [RECOMMENDED]")
    print(f"  0.5 - PERMISSIVE (acceptable entropy ok)")
    print(f"  None - DISABLED (no checking)")
    
    # Check current quality
    profile = ctx.get_entropy_profile()
    print(f"\nCurrent Quality: {profile['quality_score']:.3f}")
    
    # Try encryption - will auto-check before proceeding
    try:
        print(f"\n🔒 Attempting encryption with threshold enforcement...")
        encrypted, metadata = ctx.encrypt("sensitive data")
        print(f"✅ SUCCESS - Entropy quality sufficient")
        print(f"   Encrypted: {len(encrypted)} bytes")
    except ValueError as e:
        print(f"❌ BLOCKED - {e}")
        print(f"   Encryption prevented due to low entropy quality")


def example_paranoid_mode():
    """Example of ultra-secure paranoid mode"""
    print("\n" + "=" * 70)
    print("EXAMPLE 3: Paranoid Mode (0.9 threshold)")
    print("=" * 70)
    
    ctx = STCContext('ultra-secure-seed-2024')
    
    # Build entropy first WITHOUT threshold
    print(f"\n🔄 Building entropy with varied operations (no threshold)...")
    for i in range(30):
        ctx.encrypt(f"data batch {i}", context_data={
            'round': i,
            'type': 'sensitive',
            'variation': i % 5
        })
    
    # Check quality BEFORE setting paranoid threshold
    profile = ctx.get_entropy_profile()
    print(f"\nQuality after warmup: {profile['quality_score']:.3f}")
    print(f"Status: {profile['status'].upper()}")
    
    # NOW set paranoid threshold
    print(f"\n⚙️  Setting PARANOID threshold: 0.9")
    ctx.set_minimum_entropy_threshold(0.9)
    
    try:
        encrypted, _ = ctx.encrypt("ultra-sensitive data")
        print(f"\n✅ PASSED paranoid threshold")
        print(f"   Quality {profile['quality_score']:.3f} >= 0.9")
    except ValueError as e:
        print(f"\n❌ Failed paranoid threshold")
        print(f"   Need quality >= 0.9, currently {profile['quality_score']:.3f}")
        print(f"   This demonstrates automatic rejection of weak entropy!")
        
        # Show how to handle this in production
        print(f"\n💡 Production solution: Reinitialize or lower threshold")
        ctx.set_minimum_entropy_threshold(0.7)  # Lower to acceptable level
        encrypted, _ = ctx.encrypt("ultra-sensitive data")
        print(f"   ✅ Succeeded with threshold 0.7")


def example_monitoring_loop():
    """Continuous monitoring in production environment"""
    print("\n" + "=" * 70)
    print("EXAMPLE 4: Continuous Monitoring Loop")
    print("=" * 70)
    
    ctx = STCContext('production-seed-2024')
    ctx.set_minimum_entropy_threshold(0.7)
    
    print(f"\n📊 Monitoring entropy health over 50 operations...\n")
    
    for i in range(50):
        # Encrypt data
        ctx.encrypt(f"transaction {i}", context_data={'tx_id': i})
        
        # Check health every 10 operations
        if i % 10 == 9:
            profile = ctx.get_entropy_profile()
            status_emoji = {
                'excellent': '🟢',
                'good': '🟢',
                'acceptable': '🟡',
                'weak': '🟠',
                'critical': '🔴'
            }
            
            print(f"Operation {i+1:3d}: "
                  f"{status_emoji[profile['status']]} "
                  f"Quality {profile['quality_score']:.3f} - "
                  f"{profile['status'].upper()}")
            
            if profile['warnings']:
                print(f"            ⚠️  {len(profile['warnings'])} warning(s)")


def example_detailed_metrics():
    """Show detailed entropy metrics"""
    print("\n" + "=" * 70)
    print("EXAMPLE 5: Detailed Entropy Metrics")
    print("=" * 70)
    
    ctx = STCContext('metrics-seed-2024')
    
    # Build up some history
    for i in range(25):
        ctx.encrypt(f"data {i}")
    
    profile = ctx.get_entropy_profile()
    metrics = profile['metrics']
    
    print(f"\n📊 Detailed Metrics:")
    print(f"  Quality Score: {profile['quality_score']:.3f}")
    print(f"  Status: {profile['status'].upper()}")
    print(f"\n  Lattice Metrics:")
    print(f"    Size: {metrics['lattice_size']}")
    print(f"    Depth: {metrics['depth']}")
    print(f"    Diversity Ratio: {metrics['diversity_ratio']:.3f}")
    print(f"    Unique Values: {metrics['unique_values']}")
    print(f"\n  State Metrics:")
    print(f"    Operations: {metrics['operation_count']}")
    print(f"    State Version: {metrics['state_version']}")
    print(f"    History Length: {metrics['history_length']}")
    
    if 'entropy_stddev' in metrics:
        print(f"    Entropy StdDev: {metrics['entropy_stddev']:.1f}")
    
    print(f"\n  Recent Audits: {len(profile['recent_audits'])} entries")
    for i, audit in enumerate(profile['recent_audits'][:3], 1):
        print(f"    {i}. Quality: {audit['quality']}, "
              f"Remediation: {audit['remediation']}")


if __name__ == "__main__":
    print("\n" + "=" * 70)
    print("SEIGR TOOLSET CRYPTO - ENTROPY HEALTH MONITORING (v0.3.0)")
    print("=" * 70)
    
    example_basic_monitoring()
    example_threshold_enforcement()
    example_paranoid_mode()
    example_monitoring_loop()
    example_detailed_metrics()
    
    print("\n" + "=" * 70)
    print("✅ All examples completed successfully!")
    print("=" * 70)
    print("\nKey Takeaways:")
    print("  1. Use get_entropy_profile() to check encryption quality")
    print("  2. Set thresholds to auto-reject weak encryptions")
    print("  3. Monitor quality_score and warnings in production")
    print("  4. Recommended threshold: 0.7 (balanced security)")
    print("=" * 70 + "\n")
