"""
Example: Password manager using STC v0.3.0
Demonstrates password-based credential storage with entropy health monitoring
"""

import sys
import os
# Add parent directory to path for imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

import json
from datetime import datetime
from interfaces.api.stc_api import STCContext


class PasswordManager:
    """
    Simple password manager using STC v0.3.0
    Features: MAC verification, encrypted metadata, entropy health monitoring,
    and adaptive difficulty scaling
    """
    
    def __init__(self, master_password: str, security_level: str = 'balanced'):
        """
        Initialize password manager (v0.3.0: Enhanced)
        
        Args:
            master_password: Master password for encryption/decryption
            security_level: 'paranoid', 'balanced', or 'fast' (v0.3.0)
        """
        self.master_password = master_password
        self.vault = {}
        # Use a unique seed derived from master password for additional entropy
        # v0.3.0: Initialize with adaptive difficulty
        self.context = STCContext(
            f"vault-{master_password}",
            adaptive_difficulty=security_level
        )
        
        # v0.3.0: Set entropy threshold for password manager
        # Require high quality entropy for credential protection
        self.context.set_minimum_entropy_threshold(0.6)
        
        print(f"[OK] Password manager initialized (security: {security_level})")
    
    def add_credential(self, service: str, username: str, password: str):
        """
        Add credential to vault (v0.3.0: Enhanced)
        
        Args:
            service: Service name
            username: Username
            password: Password
        """
        # Create credential entry
        credential = {
            'service': service,
            'username': username,
            'password': password,
            'created': datetime.now().isoformat(),
            'modified': datetime.now().isoformat()
        }
        
        # Convert to JSON
        credential_json = json.dumps(credential)
        
        # v0.3.0: Encrypt with polymorphic decoys for extra protection
        encrypted, metadata = self.context.encrypt(
            password,
            password=self.master_password,
            use_decoys=True,
            variable_decoy_sizes=True,    # v0.3.0
            randomize_decoy_count=True,   # v0.3.0
            timing_randomization=True     # v0.3.0
        )
        
        # Store in vault (both encrypted and metadata are bytes)
        self.vault[service] = {
            'encrypted': encrypted.hex(),  # Store as hex string for JSON compatibility
            'metadata': metadata.hex()      # Metadata is binary TLV format
        }
        
        print(f"[OK] Credential for '{service}' added (encrypted with MAC)")
    
    def get_credential(self, service: str) -> dict:
        """
        Retrieve credential from vault
        
        Args:
            service: Service name
            
        Returns:
            Credential dictionary
            
        Raises:
            ValueError: If service not found or MAC verification fails
        """
        if service not in self.vault:
            raise ValueError(f"No credential found for '{service}'")
        
        # Get encrypted data
        entry = self.vault[service]
        encrypted = bytes.fromhex(entry['encrypted'])
        metadata = bytes.fromhex(entry['metadata'])
        
        # Decrypt with MAC verification (will raise ValueError if wrong password)
        try:
            credential_json = self.context.decrypt(
                encrypted, 
                metadata, 
                password=self.master_password
            )
        except ValueError as e:
            raise ValueError(f"Failed to decrypt '{service}': {e}")
        
        # Parse JSON
        credential = json.loads(credential_json)
        
        return credential
    
    def display_credential(self, service: str, show_password: bool = False):
        """
        Display credential (with password masked by default)
        
        Args:
            service: Service name
            show_password: Whether to show actual password (default: False)
        """
        credential = self.get_credential(service)
        print(f"\nCredential for '{credential['service']}':")
        print(f"  Username: {credential['username']}")
        # Always mask password unless explicitly requested
        masked_password = '*' * 12  # Fixed length to avoid leaking password length
        print(f"  Password: {masked_password}")
        print(f"  Created: {credential['created']}")
    
    def get_health_status(self):
        """Get entropy health status (v0.3.0)"""
        profile = self.context.get_entropy_profile()
        print(f"\nEntropy Health Status:")
        print(f"  Quality Score: {profile['quality_score']:.3f}")
        print(f"  Status: {profile['status']}")
        if profile['warnings']:
            print(f"  Warnings:")
            for warning in profile['warnings']:
                print(f"    - {warning}")
        return profile
    
    def get_security_status(self):
        """Get adaptive difficulty status (v0.3.0)"""
        status = self.context.get_adaptive_difficulty_status()
        print(f"\nSecurity Status:")
        print(f"  Sensitivity Level: {status['sensitivity_level']}")
        print(f"  Attack Detected: {status['attack_detected']}")
        print(f"  Failed Decryptions: {status['failed_decryptions']}")
        print(f"  Current PHE Paths: {status['current_phe_paths']}")
        return status
    
    def list_services(self):
        """List all stored services"""
        return list(self.vault.keys())
    
    def save_vault(self, filepath: str):
        """
        Save vault to file (vault is already in serializable format)
        
        Args:
            filepath: File path
        """
        with open(filepath, 'w') as f:
            json.dump(self.vault, f, indent=2)
        print(f"[OK] Vault saved to {filepath}")
    
    def load_vault(self, filepath: str):
        """
        Load vault from file
        
        Args:
            filepath: File path
        """
        with open(filepath, 'r') as f:
            self.vault = json.load(f)
        print(f"[OK] Vault loaded from {filepath} ({len(self.vault)} credentials)")


if __name__ == '__main__':
    print("=" * 70)
    print("STC v0.3.0 Password Manager Example")
    print("=" * 70)
    
    # Create password manager
    # NOTE: In production, use a strong master password and secure input method
    master_password = "example-master-password-change-in-production"
    # v0.3.0: Choose security level (paranoid, balanced, fast)
    pm = PasswordManager(master_password, security_level='balanced')
    
    # Add credentials (using example data - not real credentials)
    print("\nAdding example credentials...")
    pm.add_credential('github.com', 'user@example.com', 'github-pass-123')
    pm.add_credential('aws.amazon.com', 'admin', 'aws-key-456')
    pm.add_credential('database', 'db_admin', 'db-pass-789')
    
    print(f"\nStored services: {pm.list_services()}")
    
    # v0.3.0: Check entropy health
    pm.get_health_status()
    
    # v0.3.0: Check security status
    pm.get_security_status()
    
    # Retrieve and display credential (password masked by default)
    print("\nRetrieving GitHub credential (password masked):")
    pm.display_credential('github.com')
    
    # Show that password can be retrieved when needed (but not logged)
    github_cred = pm.get_credential('github.com')
    print(f"\n[OK] Password retrieved successfully (length: {len(github_cred['password'])} chars)")
    
    # Save vault
    print("\nSaving vault to encrypted storage...")
    pm.save_vault('password_vault.json')
    
    # Create new manager and load vault
    print("\nCreating new password manager and loading vault...")
    pm2 = PasswordManager(master_password, security_level='balanced')
    pm2.load_vault('password_vault.json')
    
    # Verify decryption works
    print("\nVerifying vault integrity (MAC verification):")
    for service in pm2.list_services():
        cred = pm2.get_credential(service)
        print(f"  [OK] {service}: {cred['username']} (MAC verified)")
    
    # Test wrong password protection
    print("\nTesting wrong password protection...")
    try:
        wrong_pm = PasswordManager("wrong-password", security_level='balanced')
        wrong_pm.load_vault('password_vault.json')
        wrong_pm.get_credential('github.com')
        print("  [FAIL] SECURITY FAILURE: Wrong password accepted!")
    except ValueError as e:
        print(f"  [OK] Wrong password correctly rejected (MAC verification)")
    
    print("\n" + "=" * 70)
    print("[OK] Password manager working correctly!")
    print("[OK] All credentials encrypted with MAC protection!")
    print("=" * 70)
    
    print("\nSecurity Features (v0.3.0):")
    print("  [OK] Password-based encryption with MAC verification")
    print("  [OK] Metadata encrypted with ephemeral keys")
    print("  [OK] Binary TLV format for compact storage")
    print("  [OK] Tamper detection via MAC")
    print("  [OK] Wrong password rejection")
    print("  [OK] Entropy health monitoring (NEW in v0.3.0)")
    print("  [OK] Adaptive difficulty scaling (NEW in v0.3.0)")
    print("  [OK] Polymorphic decoys with randomization (NEW in v0.3.0)")
    
    print("\nSecurity Best Practices:")
    print("  - Your master password is the ONLY key - memorize it securely")
    print("  - No cloud services, no third parties - complete data sovereignty")
    print("  - Backup your vault file separately from your master password")
    print("  - Set proper file permissions on vault file (chmod 600 on Unix/Linux)")
    print("  - Monitor entropy health for high-value credential storage")
    print("  - Choose appropriate security level: 'paranoid' for max security")
    print("  - If you lose your master password, your data is unrecoverable")
    print("  - This is the tradeoff for true cryptographic sovereignty")
