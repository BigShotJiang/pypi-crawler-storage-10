# MoreStore CLI

Python command-line client for [MoreStore.ai](https://morestore.ai) API - AI-powered brand analysis, product intelligence, and photo generation tools.

## Installation

```bash
pip install morestore
```

## Quick Start

```bash
# Analyze a brand
morestore analyze-brand https://example.com

# Generate perfect scene for a product image
morestore perfect-scene image.jpg

# Analyze a product
morestore analyze-product product.jpg --brand-name "My Brand"
```

## Available Commands

### Brand Analysis

```bash
# Analyze a brand's website
morestore analyze-brand https://example.com

# Force fresh analysis
morestore analyze-brand https://example.com --clear-cache

# Get cached analysis
morestore get-analysis example.com

# Clear cached analysis
morestore clear-cache example.com
```

### Product Analysis

```bash
# Analyze a single product image
morestore analyze-product product.jpg --brand-name "Brand" --product-name "Product"

# Batch analyze multiple products (requires products.json file)
morestore batch-analyze-products products.json --output results.json
```

### Photo Generation

```bash
# Generate perfect scene
morestore perfect-scene product.jpg --output result.jpg

# Generate perfect prompt (without generating image)
morestore perfect-prompt product.jpg --color "warm tones" --theme "vintage"

# Generate perfect ad with text overlay
morestore perfect-ad product.jpg --brand-name "Brand" --product-name "Product"

# Batch generate scenes for multiple products
morestore batch-scenes product1.jpg product2.jpg product3.jpg

# Generate seasonal hero images
morestore batch-seasonal products.json christmas
```

### Brand Clustering

```bash
# Find similar brands
morestore closest-brands example.com --top-k 10

# Find contrasting brands
morestore farthest-brands example.com --top-k 5
```

## Usage Examples

### Brand Analysis

```bash
# Analyze a brand with full details
morestore analyze-brand https://www.morestore.ai --output analysis.json

# Retrieve cached analysis
morestore get-analysis morestore.ai
```

### Product Analysis

```bash
# Analyze product with context
morestore analyze-product product.jpg \
  --brand-name "ArtisanCrafts" \
  --product-name "Handcrafted Leather Wallet" \
  --output analysis.json

# Batch analyze products (create products.json first)
morestore batch-analyze-products products.json --no-progress
```

### Perfect Scene Generation

```bash
# Simple usage
morestore perfect-scene photo.jpg

# With brand context
morestore perfect-scene shoe.jpg --brand-name "Nike" --product-name "Air Max"

# Custom prompt and high resolution
morestore perfect-scene watch.jpg \
  --custom-prompt "Create a luxury lifestyle scene with natural lighting" \
  --scale-to-megapixels 2.0 \
  --output high-res-watch.jpg

# Disable progress updates
morestore perfect-scene product.jpg --no-progress
```

### Perfect Ad Generation

```bash
# Generate ad with AI-generated text overlay
morestore perfect-ad product.jpg \
  --brand-name "Artisan Crafts" \
  --product-name "Ceramic Vase" \
  --output ad.jpg
```

### Perfect Prompt Generation

```bash
# Generate optimized prompt with preferences
morestore perfect-prompt product.jpg \
  --brand-name "Coca-Cola" \
  --product-name "Classic Bottle" \
  --color "warm tones" \
  --theme "vintage" \
  --suggestion "outdoor summer picnic setting" \
  --output prompt.json
```

### Batch Operations

```bash
# Batch scene generation
morestore batch-scenes product1.jpg product2.jpg product3.jpg \
  --scene-prompts '["cozy living room","modern kitchen","outdoor patio"]'

# Seasonal hero images
morestore batch-seasonal products.json christmas --output seasonal_results.json
```

### Brand Clustering

```bash
# Find similar brands
morestore closest-brands example.com --top-k 10 --keep-model-loaded --output similar.json

# Find contrasting brands
morestore farthest-brands example.com --top-k 5 --output contrasting.json
```

## Command Reference

### `analyze-brand`
Analyze a brand's website for identity, voice, values, and positioning.

**Arguments:**
- `website_url` (required): URL to analyze
- `--clear-cache`: Force fresh analysis
- `--output`, `-o`: Save results to JSON file
- `--api-url`: Custom API endpoint

### `get-analysis`
Retrieve cached brand analysis for a domain.

**Arguments:**
- `domain` (required): Domain name (e.g., "example.com")
- `--output`, `-o`: Save results to JSON file
- `--api-url`: Custom API endpoint

### `clear-cache`
Clear cached analysis for a domain.

**Arguments:**
- `domain` (required): Domain name
- `--api-url`: Custom API endpoint

### `analyze-product`
Extract product metadata, materials, colors, categories, and SEO keywords.

**Arguments:**
- `image` (required): Product image file path
- `--brand-name`: Brand name for context
- `--product-name`: Product name
- `--output`, `-o`: Save results to JSON file
- `--api-url`: Custom API endpoint

### `batch-analyze-products`
Analyze multiple products with streaming progress.

**Arguments:**
- `products_file` (required): JSON file with products array
- `--no-progress`: Disable progress updates
- `--output`, `-o`: Save results to JSON file
- `--api-url`: Custom API endpoint

### `perfect-prompt`
Generate AI-optimized scene prompts without generating the image.

**Arguments:**
- `image` (required): Product image file path
- `--brand-name`: Brand name
- `--product-name`: Product name
- `--color`: Color preference (e.g., "warm tones", "blue")
- `--theme`: Theme preference (e.g., "modern", "vintage")
- `--suggestion`: User suggestion for prompt
- `--output`, `-o`: Save results to JSON file
- `--api-url`: Custom API endpoint

### `perfect-ad`
Generate perfect ad with AI-generated text overlay.

**Arguments:**
- `image` (required): Product image file path
- `--output`, `-o`: Output image path
- `--brand-name`: Brand name
- `--product-name`: Product name
- `--api-url`: Custom API endpoint

### `perfect-scene`
Generate AI-enhanced product photos with perfect scenes.

**Arguments:**
- `image` (required): Product image file path
- `--output`, `-o`: Output image path
- `--brand-name`: Brand name for context
- `--product-name`: Product name
- `--custom-prompt`: Custom scene prompt
- `--scale-to-megapixels`: Output resolution (default: 1.0)
- `--no-progress`: Disable progress updates
- `--api-url`: Custom API endpoint

### `batch-scenes`
Generate perfect scenes for multiple products.

**Arguments:**
- `images` (required): One or more image file paths
- `--scene-prompts`: JSON array of scene prompts
- `--no-progress`: Disable progress updates
- `--api-url`: Custom API endpoint

### `batch-seasonal`
Generate seasonal hero images for marketing campaigns.

**Arguments:**
- `products_file` (required): JSON file with products (name, image_url)
- `season` (required): Season name (halloween, christmas, spring, summer, autumn, winter)
- `--output`, `-o`: Save results to JSON file
- `--api-url`: Custom API endpoint

### `closest-brands`
Find brands with similar identity using semantic embeddings.

**Arguments:**
- `domain` (required): Domain to find similar brands for
- `--top-k`: Number of similar brands (default: 5)
- `--keep-model-loaded`: Keep model in memory
- `--output`, `-o`: Save results to JSON file
- `--api-url`: Custom API endpoint

### `farthest-brands`
Find brands with contrasting identity for differentiation.

**Arguments:**
- `domain` (required): Domain to find contrasting brands for
- `--top-k`: Number of contrasting brands (default: 5)
- `--output`, `-o`: Save results to JSON file
- `--api-url`: Custom API endpoint

## Python API

You can also use MoreStore as a Python library:

```python
from morestore_cli.client import MoreStoreClient

client = MoreStoreClient()

# Analyze brand
analysis = client.analyze_brand("https://example.com")

# Generate perfect scene
output_path = client.generate_perfect_scene(
    image_path="product.jpg",
    output_path="result.jpg",
    brand_name="My Brand",
    product_name="Product Name",
    show_progress=True
)

# Analyze product
product_data = client.analyze_product(
    image_path="product.jpg",
    brand_name="Brand",
    product_name="Product"
)

# Generate perfect ad
ad_path = client.generate_perfect_ad(
    image_path="product.jpg",
    output_path="ad.jpg",
    brand_name="Brand",
    product_name="Product"
)
```

## Progress Updates

By default, the CLI shows real-time progress updates via Server-Sent Events (SSE):

```
🔗 Starting progress listener for session: 12345678...
📡 Connected to progress stream...
✅ Connected (session: 12345678...)

📤 Uploading image and starting generation...
🚀 Starting perfect scene generation for product.jpg...
   📝 Analyzing product image to generate prompt...
   ✅ Prompt generated: Transform this into a beautiful modern scene...
   🎨 Loading AI model for scene generation...
   🎨 Generating perfect scene (this may take 30-60 seconds)...
   💓 Still generating... (5s elapsed)
   💓 Still generating... (10s elapsed)
✅ Perfect scene generation completed!
   ⏱️  Generation time: 45.2 seconds

✅ Perfect scene image saved successfully!
⏱️  Total generation time: 45.2 seconds
```

## Requirements

- Python 3.7 or higher
- Internet connection (to connect to MoreStore.ai API)

## License

MIT License

## Support

For issues, questions, or suggestions, please visit:
- Website: https://morestore.ai
- Documentation: https://morestore.ai/docs
- Issues: https://github.com/morestore/morestore-cli/issues
