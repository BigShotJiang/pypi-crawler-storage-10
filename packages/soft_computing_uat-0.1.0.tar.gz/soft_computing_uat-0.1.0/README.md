# Soft Computing Project

This package contains fuzzy logic–based Python simulations, including temperature–fan speed control using scikit-fuzzy.
