from setuptools import setup, find_packages

setup(
    name="soft-computing-uat",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "scikit-fuzzy",
        "matplotlib"
    ],
    entry_points={
        "console_scripts": [
            "control-fan=exp_1.control_fan:main"
        ],
    },
    author="suren-sudo",
    description="Soft computing experiments collection",
    long_description=open("README.md").read() if open("README.md", "r", encoding="utf-8") else "",
    long_description_content_type="text/markdown",
    python_requires=">=3.8",
)
