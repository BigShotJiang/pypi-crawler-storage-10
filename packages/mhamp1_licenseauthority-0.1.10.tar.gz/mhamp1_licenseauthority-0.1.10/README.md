# LicenseAuthority
<<<<<<< HEAD

This project manages the **master key** and **license generation** for the Quantum Falcon trading cockpit.  
It is kept separate from the bot code to ensure secrets are never shipped with the executable.

---

## Setup

```bash
python -m venv venv
source venv/bin/activate   # or venv\Scripts\activate on Windows
pip install -r requirements.txt
=======
Secure license generation and validation system
>>>>>>> 741b24870ba92e3186348a54e3120497e37018a4
