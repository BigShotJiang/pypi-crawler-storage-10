#!/usr/bin/env python3
"""
Example usage of the updated PdfImportService with blackening and cropping modes.
"""

import os
import sys
from pathlib import Path

# Add Django project to path
sys.path.insert(0, str(Path(__file__).parent))

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings.dev')
import django
django.setup()

from endoreg_db.services.pdf_import import PdfImportService
import logging

logger = logging.getLogger(__name__)


def example_blackening_mode():
    """Example of using the new PDF blackening mode."""
    print("\n" + "="*60)
    print("📄 Example: PDF Import with Blackening Mode")
    print("="*60)
    
    print("""
🎯 Blackening Mode Features:
- ✅ Fast processing with simple text extraction
- ✅ Creates anonymized PDF with black rectangles over sensitive regions
- ✅ No cropped region images (lightweight)
- ✅ Suitable for bulk processing or when disk space is limited
- ✅ Uses enhanced process_report() method with PDF masking
    """)
    
    # Create service instance for blackening
    service = PdfImportService.with_blackening(allow_meta_overwrite=True)
    print(f"✅ Created PdfImportService with mode: {service.processing_mode}")
    
    # Alternative way to create the same service
    service_alt = PdfImportService(
        processing_mode="blackening",
        allow_meta_overwrite=True
    )
    print(f"✅ Alternative creation with mode: {service_alt.processing_mode}")
    
    print("""
💡 Usage Example:
    # Import and process a PDF with blackening
    pdf_file = service.import_and_anonymize(
        file_path="/path/to/medical_report.pdf",
        center_name="university_hospital_wuerzburg",
        delete_source=False
    )
    
    # The result includes:
    # - pdf_file.text: Extracted and anonymized text
    # - pdf_file.anonymized_file: PDF with black rectangles over sensitive areas
    # - pdf_file.sensitive_meta: Extracted patient metadata
    
🔍 What gets blackened:
    - Patient names (first, last)
    - Dates of birth
    - Case numbers/Patient IDs  
    - Examination dates
    - Examiner names
    - Phone numbers, addresses
    - Other PII detected by OCR
    """)


def example_cropping_mode():
    """Example of using the advanced cropping mode."""
    print("\n" + "="*60)
    print("📄 Example: PDF Import with Cropping Mode")
    print("="*60)
    
    print("""
🎯 Cropping Mode Features:
- ✅ Advanced processing with detailed region analysis
- ✅ Creates anonymized PDF with sensitive regions cropped out
- ✅ Saves cropped sensitive regions as separate image files
- ✅ Detailed processing metadata
- ✅ Uses process_report_with_cropping() method
- ⚠️  Requires more disk space and processing time
    """)
    
    # Create service instance for cropping
    service = PdfImportService.with_cropping(allow_meta_overwrite=True)
    print(f"✅ Created PdfImportService with mode: {service.processing_mode}")
    
    print("""
💡 Usage Example:
    # Import and process a PDF with cropping
    pdf_file = service.import_and_anonymize(
        file_path="/path/to/medical_report.pdf",
        center_name="university_hospital_wuerzburg",
        delete_source=False
    )
    
    # The result includes:
    # - pdf_file.text: Extracted and anonymized text
    # - pdf_file.anonymized_file: PDF with sensitive regions cropped out
    # - pdf_file.sensitive_meta: Extracted patient metadata
    # - Separate cropped region images in storage/pdfs/cropped_regions/
    
📁 Output Structure:
    storage/pdfs/
    ├── sensitive/           # Original PDFs in secure storage
    ├── anonymized/          # Anonymized PDFs
    └── cropped_regions/     # Individual cropped sensitive regions (cropping mode only)
    """)


def example_mode_comparison():
    """Compare the two processing modes."""
    print("\n" + "="*60)
    print("⚖️  Processing Mode Comparison")
    print("="*60)
    
    comparison = """
┌─────────────────┬─────────────────┬─────────────────┐
│     Feature     │   Blackening    │    Cropping     │
├─────────────────┼─────────────────┼─────────────────┤
│ Processing Speed│      Fast       │     Slower      │
│ Disk Usage      │   Lightweight   │    More Space   │
│ Anonymized PDF  │ Black rectangles│  Cropped areas  │
│ Cropped Images  │       No        │      Yes        │
│ Text Extraction │      Yes        │      Yes        │
│ Metadata Extract│      Yes        │      Yes        │
│ Bulk Processing │   Recommended   │  Consider disk  │
│ Research/Archive│      Good       │   Excellent     │
└─────────────────┴─────────────────┴─────────────────┘

🎯 Choose Blackening When:
  - Processing many PDFs in bulk
  - Disk space is limited
  - Simple anonymization needs
  - Fast turnaround required

🎯 Choose Cropping When:
  - Need detailed region analysis
  - Research purposes requiring cropped regions
  - Maximum security/compliance requirements
  - Archival purposes with detailed metadata
    """
    print(comparison)


def example_integration_patterns():
    """Show common integration patterns."""
    print("\n" + "="*60)
    print("🔧 Integration Patterns")
    print("="*60)
    
    patterns = '''
## 1. Simple Processing Pipeline

```python
from endoreg_db.services.pdf_import import PdfImportService

# Create service
service = PdfImportService.with_blackening()

# Process single PDF
pdf_file = service.import_and_anonymize(
    file_path="report.pdf",
    center_name="hospital_a"
)

print(f"Processed: {pdf_file.pdf_hash}")
print(f"Text length: {len(pdf_file.text) if pdf_file.text else 0}")
print(f"Anonymized: {pdf_file.anonymized}")
```

## 2. Batch Processing with Error Handling

```python
import logging
from pathlib import Path

service = PdfImportService.with_blackening(allow_meta_overwrite=True)
pdf_dir = Path("/path/to/pdfs")

for pdf_path in pdf_dir.glob("*.pdf"):
    try:
        result = service.import_and_anonymize(
            file_path=pdf_path,
            center_name="hospital_a",
            delete_source=False  # Keep originals during testing
        )
        if result:
            print(f"✅ Processed: {pdf_path.name}")
        else:
            print(f"⚠️  Skipped: {pdf_path.name}")
    except Exception as e:
        logging.error(f"❌ Failed {pdf_path.name}: {e}")
```

## 3. Mode Selection Based on Requirements

```python
def create_pdf_service(mode="auto", file_count=1):
    """Create appropriate service based on requirements."""
    
    if mode == "auto":
        # Auto-select based on file count
        if file_count > 100:
            mode = "blackening"  # Bulk processing
        else:
            mode = "cropping"    # Detailed processing
    
    if mode == "blackening":
        return PdfImportService.with_blackening()
    else:
        return PdfImportService.with_cropping()

# Usage
service = create_pdf_service(file_count=500)  # Will use blackening
service = create_pdf_service(mode="cropping") # Force cropping
```

## 4. Management Command Integration

```python
# In a Django management command
class Command(BaseCommand):
    def add_arguments(self, parser):
        parser.add_argument('--mode', choices=['blackening', 'cropping'], 
                          default='blackening')
        parser.add_argument('--pdf-dir', required=True)
    
    def handle(self, *args, **options):
        if options['mode'] == 'blackening':
            service = PdfImportService.with_blackening()
        else:
            service = PdfImportService.with_cropping()
        
        # Process PDFs...
```
    '''
    print(patterns)


def main():
    """Run all examples."""
    print("📚 PdfImportService Enhanced Usage Guide")
    print("🎯 Now with PDF Blackening and Cropping Modes!")
    
    example_blackening_mode()
    example_cropping_mode()  
    example_mode_comparison()
    example_integration_patterns()
    
    print("\n" + "="*60)
    print("🎉 PdfImportService is ready with enhanced PDF anonymization!")
    print("✅ Both blackening and cropping modes are available")
    print("✅ Choose the mode that best fits your processing needs")
    print("="*60)


if __name__ == "__main__":
    main()