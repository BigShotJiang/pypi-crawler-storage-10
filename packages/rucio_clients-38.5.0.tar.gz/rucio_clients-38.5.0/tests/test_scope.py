# Copyright European Organization for Nuclear Research (CERN) since 2012
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from json import loads

import pytest

from rucio.common.exception import AccountNotFound, Duplicate, InvalidObject, ScopeNotFound
from rucio.common.types import InternalAccount, InternalScope
from rucio.common.utils import generate_uuid as uuid
from rucio.core.scope import add_scope, get_scopes, is_scope_owner, update_scope
from rucio.tests.common import account_name_generator, auth, hdrdict, headers, scope_name_generator


class TestScopeCoreApi:

    def test_list_scopes(self, vo, jdoe_account):
        scopes = [InternalScope(scope_name_generator(), vo=vo) for _ in range(5)]
        """ SCOPE (CORE): List scopes """
        for scope in scopes:
            add_scope(scope=scope, account=jdoe_account)
        scopes = get_scopes(account=jdoe_account)
        for scope in scopes:
            assert scope in scopes

    def test_is_scope_owner(self, vo, jdoe_account):
        """ SCOPE (CORE): Is scope owner """
        scope = InternalScope(scope_name_generator(), vo=vo)
        add_scope(scope=scope, account=jdoe_account)
        answer = is_scope_owner(scope=scope, account=jdoe_account)
        assert answer is True

    def test_change_scope_owner(self, vo, jdoe_account, random_account):
        """ SCOPE (CORE): Give the scope a different owner"""
        scope = InternalScope(scope_name_generator(), vo=vo)
        add_scope(scope=scope, account=jdoe_account)
        assert is_scope_owner(scope, account=jdoe_account)

        update_scope(scope=scope, account=random_account)
        assert is_scope_owner(scope, account=random_account)
        assert not is_scope_owner(scope, account=jdoe_account)

        account = InternalAccount(account_name_generator())
        with pytest.raises(AccountNotFound):
            update_scope(scope=scope, account=account)

        scope = InternalScope(scope_name_generator())
        with pytest.raises(ScopeNotFound):
            update_scope(scope=scope, account=random_account)


def test_scope_success(rest_client, auth_token):
    """ SCOPE (REST): send a POST to create a new account and scope """
    acntusr = account_name_generator()
    data = {'type': 'USER', 'email': 'rucio.email.com'}
    response = rest_client.post('/accounts/' + acntusr, headers=headers(auth(auth_token)), json=data)
    assert response.status_code == 201

    scopeusr = scope_name_generator()
    response = rest_client.post('/accounts/%s/scopes/%s' % (acntusr, scopeusr), headers=headers(auth(auth_token)))
    assert response.status_code == 201


def test_scope_failure(rest_client, auth_token):
    """ SCOPE (REST): send a POST to create a new scope for a not existing account to test the error"""
    scopeusr = scope_name_generator()
    account_name_generator()
    response = rest_client.post('/accounts/%s/scopes/%s' % (scopeusr, scopeusr), headers=headers(auth(auth_token)))
    assert response.status_code == 404


def test_scope_duplicate(rest_client, auth_token):
    """ SCOPE (REST): send a POST to create a already existing scope to test the error"""
    acntusr = account_name_generator()
    data = {'type': 'USER', 'email': 'rucio@email.com'}
    response = rest_client.post('/accounts/' + acntusr, headers=headers(auth(auth_token)), json=data)
    assert response.status_code == 201

    scopeusr = scope_name_generator()
    response = rest_client.post('/accounts/%s/scopes/%s' % (acntusr, scopeusr), headers=headers(auth(auth_token)))
    assert response.status_code == 201
    response = rest_client.post('/accounts/%s/scopes/%s' % (acntusr, scopeusr), headers=headers(auth(auth_token)))
    assert response.status_code == 409


def test_scope_change_ownership(rest_client, auth_token, random_account_factory):
    """ SCOPE (REST): Send a post to change the existing scope's owner """
    og_owner = random_account_factory()
    scope = scope_name_generator()
    response = rest_client.post(f'/accounts/{og_owner}/scopes/{scope}', headers=headers(auth(auth_token)))
    assert response.status_code == 201

    new_owner = random_account_factory()
    response = rest_client.put(f"/scopes/{new_owner}/{scope}", headers=headers(auth(auth_token)))
    assert response.status_code == 200

    # Try to do it without sufficient permissions
    new_owner = random_account_factory()
    response = rest_client.put(f"/scopes/{new_owner}/{scope}", headers=headers(auth("fake_token")))
    assert response.status_code == 401

    # Try it with an account that doesn't exist
    new_owner = account_name_generator()
    response = rest_client.put(f"/scopes/{new_owner}/{scope}", headers=headers(auth(auth_token)))
    assert response.status_code == 404


def test_list_scope(rest_client, auth_token):
    """ SCOPE (REST): send a GET list all scopes for one account """
    tmp_val = account_name_generator()
    headers_dict = {'Rucio-Type': 'user', 'X-Rucio-Account': 'root'}
    data = {'type': 'USER', 'email': 'rucio@email.com'}
    response = rest_client.post('/accounts/%s' % tmp_val, headers=headers(auth(auth_token), hdrdict(headers_dict)), json=data)
    assert response.status_code == 201

    scopes = [scope_name_generator() for _ in range(5)]
    for scope in scopes:
        response = rest_client.post('/accounts/%s/scopes/%s' % (tmp_val, scope), headers=headers(auth(auth_token)), json={})
        assert response.status_code == 201

    response = rest_client.get('/accounts/%s/scopes/' % tmp_val, headers=headers(auth(auth_token)))
    assert response.status_code == 200

    svr_list = loads(response.get_data(as_text=True))
    for scope in scopes:
        assert scope in svr_list


def test_list_scope_account_not_found(rest_client, auth_token):
    """ SCOPE (REST): send a GET list all scopes for a not existing account """
    response = rest_client.get('/accounts/testaccount/scopes/', headers=headers(auth(auth_token)))
    assert response.status_code == 404
    assert response.headers.get('ExceptionClass') == 'AccountNotFound'


def test_list_scope_no_scopes(rest_client, auth_token):
    """ SCOPE (REST): send a GET list all scopes for one account without scopes """
    acntusr = account_name_generator()
    data = {'type': 'USER', 'email': 'rucio@email.com'}

    response = rest_client.post('/accounts/' + acntusr, headers=headers(auth(auth_token)), json=data)
    assert response.status_code == 201

    response = rest_client.get('/accounts/%s/scopes/' % acntusr, headers=headers(auth(auth_token)))
    assert response.status_code == 404
    assert response.headers.get('ExceptionClass') == 'ScopeNotFound'


class TestScopeClient:

    def test_create_scope(self, rucio_client):
        """ SCOPE (CLIENTS): create a new scope."""
        account = 'jdoe'
        scope = scope_name_generator()
        ret = rucio_client.add_scope(account, scope)
        assert ret
        with pytest.raises(InvalidObject):
            rucio_client.add_scope(account, 'tooooolooooongscooooooooooooope')
        with pytest.raises(InvalidObject):
            rucio_client.add_scope(account, '$?!')

    def test_create_scope_no_account(self, rucio_client):
        """ SCOPE (CLIENTS): try to create scope for not existing account."""
        account = str(uuid()).lower()[:30]
        scope = scope_name_generator()
        with pytest.raises(AccountNotFound):
            rucio_client.add_scope(account, scope)

    def test_create_scope_duplicate(self, rucio_client):
        """ SCOPE (CLIENTS): try to create a duplicate scope."""
        account = 'jdoe'
        scope = scope_name_generator()
        rucio_client.add_scope(account, scope)
        with pytest.raises(Duplicate):
            rucio_client.add_scope(account, scope)

    def test_list_scopes(self, rucio_client):
        """ SCOPE (CLIENTS): try to list scopes for an account."""
        account = 'jdoe'
        scope_list = [scope_name_generator() for _ in range(5)]
        for scope in scope_list:
            rucio_client.add_scope(account, scope)

        svr_list = rucio_client.list_scopes_for_account(account)

        for scope in scope_list:
            if scope not in svr_list:
                assert False

    def test_list_scopes_account_not_found(self, rucio_client):
        """ SCOPE (CLIENTS): try to list scopes for a non existing account."""
        account = account_name_generator()
        with pytest.raises(AccountNotFound):
            rucio_client.list_scopes_for_account(account)

    def test_list_scopes_no_scopes(self, rucio_client):
        """ SCOPE (CLIENTS): try to list scopes for an account without scopes."""
        account = account_name_generator()
        rucio_client.add_account(account, 'USER', 'rucio@email.com')
        with pytest.raises(ScopeNotFound):
            rucio_client.list_scopes_for_account(account)

    def test_list_all_scopes(self, scope_factory, random_account_factory, rucio_client, vo):
        """SCOPE (CLIENTS): List all scopes and verify they have the correct account associated"""

        n_scopes = 5
        accounts = [random_account_factory().external for _ in range(n_scopes)]
        scopes = [scope_factory(vos=[vo], account_name=account)[0] for account in accounts]

        listed_scopes = [i for i in rucio_client.list_scopes()]
        for scope, account in zip(scopes, accounts):
            item = list(filter(lambda d: d['scope'] == scope, listed_scopes))[0]
            assert item['scope'] == scope
            assert item['account'] == account

    def test_update_scope_owner(self, scope_factory, random_account_factory, rucio_client, vo):
        initial_account = random_account_factory().external
        scope, _ = scope_factory(vos=[vo], account_name=initial_account)
        assert scope in rucio_client.list_scopes_for_account(initial_account)

        new_account = random_account_factory().external
        assert rucio_client.update_scope_ownership(new_account, scope)
        assert scope in rucio_client.list_scopes_for_account(new_account)
