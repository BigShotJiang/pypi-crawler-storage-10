import httpx

from .has_http_client import HasHttpClient


def get_http_client_attribute(instance: object, /) -> httpx.Client | None:
    http_client: httpx.Client | None = None

    for attribute_name in ["client", "_client", "http_client"]:
        client = getattr(instance, attribute_name, None)

        match client:
            case httpx.Client():
                http_client = client
                break
            case HasHttpClient():
                http_client = client.http_client
                break
            case _:
                ...

    return http_client
