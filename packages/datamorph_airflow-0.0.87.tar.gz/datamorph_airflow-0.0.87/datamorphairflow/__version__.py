"""
Module contains the version of datamorph-airflow,
ChangeLog.md with the release details for the version change needs to be updated
"""
__version__ = "0.0.87"

"""
0.0.87 - exclude dm_prop_frontend and workflow_id
"""
