from .plugin import setup_tailwindcss_plugin


__version__ = '0.1.0'

__all__ = [
    'setup_tailwindcss_plugin',
]
