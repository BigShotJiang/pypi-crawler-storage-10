"""
Main TTS Client for FonadaLabs SDK
"""

import httpx
import websockets
import asyncio
import json
from typing import Optional, Callable, AsyncGenerator, Dict, Any
from pathlib import Path
import io


class TTSError(Exception):
    """Custom exception for TTS-related errors"""
    pass


class CreditsExhaustedError(TTSError):
    """Raised when API credits are exhausted"""
    def __init__(self, message: str, details: dict = None):
        super().__init__(message)
        self.details = details or {}
        self.current_usage = details.get("current_usage") if details else None
        self.credit_limit = details.get("credit_limit") if details else None
        self.remaining_balance = details.get("remaining_balance") if details else None
        self.estimated_cost = details.get("estimated_cost") if details else None
        self.billing_cycle_end = details.get("billing_cycle_end") if details else None
        self.tier = details.get("tier") if details else None


class RateLimitError(TTSError):
    """Raised when API rate limit is exceeded"""
    def __init__(self, message: str, details: dict = None):
        super().__init__(message)
        self.details = details or {}
        self.rate_limit = details.get("rate_limit") if details else None
        self.current_usage = details.get("current_usage") if details else None
        self.remaining = details.get("remaining") if details else None
        self.reset_at = details.get("reset_at") if details else None
        self.retry_after_seconds = details.get("retry_after_seconds") if details else None
        self.rate_period = details.get("rate_period") if details else None


class TTSClient:
    """
    Client for interacting with FonadaLabs TTS API.
    
    Supports both HTTP POST and WebSocket connections for text-to-speech generation.
    Supports up to 40 concurrent requests.
    
    Example:
        >>> client = TTSClient()
        >>> # HTTP POST method
        >>> audio_data = client.generate_audio("Hello world", "Anuradha")
        >>> # WebSocket method with callbacks
        >>> client.generate_audio_ws(
        ...     "Long text here",
        ...     "Anuradha",
        ...     on_progress=lambda data: print(f"Progress: {data['percent']}%")
        ... )
        >>> # Check server health
        >>> health = client.health_check()
        >>> print(f"Available slots: {health['available_slots']}")
    """
    
    def __init__(self, api_key: Optional[str] = None, timeout: int = 300):
        """
        Initialize the TTS client.
        
        Args:
            api_key: API key for authentication (required, uses FONADALABS_API_KEY env var if not provided)
            timeout: Request timeout in seconds (default: 300)
            
        Raises:
            TTSError: If no API key is provided
            
        Note:
            The base URL is configured internally via FONADALABS_API_URL
            environment variable (default: http://localhost:9557).
            Users cannot override it for security reasons.
        """
        # Internal base URL configuration
        # Users cannot override it for security reasons
        import os
        self.base_url = os.getenv("FONADALABS_API_URL", "https://kb.fonada.ai:8443").rstrip("/")
        self.api_key = api_key or os.getenv("FONADALABS_API_KEY")
        
        # Validate that API key is provided
        if not self.api_key:
            raise TTSError(
                "API key is required. Please provide it via:\n"
                "1. TTSClient(api_key='your-api-key')\n"
                "2. Environment variable: export FONADALABS_API_KEY='your-api-key'\n"
                "3. .env file with FONADALABS_API_KEY='your-api-key'"
            )
        
        self.timeout = timeout
        self.http_client = None
    
    async def _get_http_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client"""
        if self.http_client is None:
            self.http_client = httpx.AsyncClient(timeout=self.timeout)
        return self.http_client
    
    async def _close_http_client(self):
        """Close HTTP client"""
        if self.http_client is not None:
            await self.http_client.aclose()
            self.http_client = None
    
    def _get_auth_headers(self) -> Dict[str, Any]:
        """Get authorization headers for HTTP requests"""
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers
    
    async def generate_audio_async(
        self,
        text: str,
        voice: str,
        output_file: Optional[str] = None
    ) -> bytes:
        """
        Generate audio from text using HTTP POST (async version).
        Suitable for large texts. Streams response progressively.
        
        Args:
            text: Text to convert to speech
            voice: Voice name (e.g., "Anuradha")
            output_file: Optional path to save the audio file
            
        Returns:
            Audio data as bytes
            
        Raises:
            TTSError: If the API request fails
        """
        endpoint = f"{self.base_url}/tts/generate-audio-large"
        
        try:
            client = await self._get_http_client()
            
            async with client.stream(
                "POST",
                endpoint,
                headers=self._get_auth_headers(),
                json={"input": text, "voice": voice}
            ) as response:
                # Check for credit exhaustion or rate limit
                if response.status_code in (402, 429):
                    try:
                        error_text = await response.aread()
                        error_json = json.loads(error_text.decode())
                        error_type = error_json.get("error")
                        
                        if error_type == "credits_exhausted":
                            raise CreditsExhaustedError(
                                error_json.get("message", "Credits exhausted"),
                                details=error_json.get("details", {})
                            )
                        elif error_type == "rate_limit_exceeded":
                            raise RateLimitError(
                                error_json.get("message", "Rate limit exceeded"),
                                details=error_json.get("details", {})
                            )
                    except (json.JSONDecodeError, AttributeError):
                        pass
                
                if response.status_code == 429:
                    error_text = await response.aread()
                    raise TTSError(f"Too many concurrent requests: {error_text.decode()}")
                elif response.status_code != 200:
                    error_text = await response.aread()
                    raise TTSError(
                        f"API request failed with status {response.status_code}: {error_text.decode()}"
                    )
                
                # Collect all chunks
                audio_chunks = []
                async for chunk in response.aiter_bytes():
                    audio_chunks.append(chunk)
                
                audio_data = b"".join(audio_chunks)
                
                # Save to file if requested
                if output_file:
                    Path(output_file).write_bytes(audio_data)
                
                return audio_data
                
        except httpx.HTTPError as e:
            raise TTSError(f"HTTP error occurred: {str(e)}")
        except Exception as e:
            raise TTSError(f"An error occurred: {str(e)}")
    
    def generate_audio(
        self,
        text: str,
        voice: str,
        output_file: Optional[str] = None
    ) -> bytes:
        """
        Generate audio from text using HTTP POST (synchronous wrapper).
        Suitable for large texts. Streams response progressively.
        
        Args:
            text: Text to convert to speech
            voice: Voice name (e.g., "Anuradha")
            output_file: Optional path to save the audio file
            
        Returns:
            Audio data as bytes
            
        Raises:
            TTSError: If the API request fails
        """
        async def _run():
            try:
                return await self.generate_audio_async(text, voice, output_file)
            finally:
                await self._close_http_client()
        
        return asyncio.run(_run())
    
    async def generate_audio_ws_async(
        self,
        text: str,
        voice: str,
        output_file: Optional[str] = None,
        on_status: Optional[Callable[[str], None]] = None,
        on_progress: Optional[Callable[[Dict[str, Any]], None]] = None,
        on_chunk: Optional[Callable[[int, bytes], None]] = None,
        on_complete: Optional[Callable[[Dict[str, Any]], None]] = None,
        on_error: Optional[Callable[[str], None]] = None
    ) -> bytes:
        """
        Generate audio from text using WebSocket (async version).
        Provides real-time progress updates and audio chunks.
        
        Args:
            text: Text to convert to speech
            voice: Voice name (e.g., "Anuradha")
            output_file: Optional path to save the audio file
            on_status: Callback for status messages (receives message string)
            on_progress: Callback for progress updates (receives dict with current, total, percent)
            on_chunk: Callback for audio chunks (receives chunk_id and audio bytes)
            on_complete: Callback when generation is complete (receives completion dict)
            on_error: Callback for errors (receives error message)
            
        Returns:
            Complete audio data as bytes
            
        Raises:
            TTSError: If the WebSocket connection or generation fails
        """
        ws_url = self.base_url.replace("http://", "ws://").replace("https://", "wss://")
        ws_endpoint = f"{ws_url}/tts/generate-audio-ws"
        
        audio_chunks = []
        
        try:
            # Increase max_size to handle large audio chunks (default is 1MB, we set to 16MB)
            async with websockets.connect(ws_endpoint, max_size=16 * 1024 * 1024) as websocket:
                # Receive initial connection message
                initial_msg = await websocket.recv()
                initial_data = json.loads(initial_msg)
                
                if initial_data.get("type") == "status" and on_status:
                    on_status(initial_data.get("message", ""))
                
                # Send TTS request with API key
                request_data = {
                    "input": text,
                    "voice": voice
                }
                if self.api_key:
                    request_data["api_key"] = self.api_key
                
                await websocket.send(json.dumps(request_data))
                
                # Process messages
                while True:
                    try:
                        message = await websocket.recv()
                        
                        # Check if message is JSON or binary
                        if isinstance(message, bytes):
                            # Binary audio data received without preceding audio_chunk JSON
                            # This shouldn't normally happen with the server's protocol, but handle it anyway
                            audio_chunks.append(message)
                            import sys
                            print(f"Warning: Received unexpected standalone binary message: {len(message)} bytes", file=sys.stderr)
                        else:
                            # JSON message
                            data = json.loads(message)
                            msg_type = data.get("type")
                            
                            if msg_type == "status":
                                if on_status:
                                    try:
                                        on_status(data.get("message", ""))
                                    except Exception as callback_error:
                                        import sys
                                        print(f"Warning: on_status callback error: {callback_error}", file=sys.stderr)
                            
                            elif msg_type == "progress":
                                if on_progress:
                                    try:
                                        on_progress({
                                            "current": data.get("current"),
                                            "total": data.get("total"),
                                            "percent": data.get("percent")
                                        })
                                    except Exception as callback_error:
                                        import sys
                                        print(f"Warning: on_progress callback error: {callback_error}", file=sys.stderr)
                            
                            elif msg_type == "audio_chunk":
                                # Server sends TWO messages per chunk:
                                # 1. This JSON message with metadata
                                # 2. Immediately followed by binary audio data
                                chunk_id = data.get("chunk_id")
                                
                                # Check if audio data is embedded in the JSON message (some servers do this)
                                if "data" in data or "audio_data" in data:
                                    # Audio is embedded in JSON (base64 encoded)
                                    import base64
                                    audio_b64 = data.get("data") or data.get("audio_data")
                                    if audio_b64:
                                        audio_bytes = base64.b64decode(audio_b64)
                                        audio_chunks.append(audio_bytes)
                                        if on_chunk:
                                            try:
                                                on_chunk(chunk_id, audio_bytes)
                                            except Exception as callback_error:
                                                import sys
                                                print(f"Warning: on_chunk callback error: {callback_error}", file=sys.stderr)
                                else:
                                    # Audio will be in the NEXT WebSocket message (binary)
                                    # We MUST receive it immediately, not in the next loop iteration
                                    try:
                                        audio_binary = await websocket.recv()
                                        
                                        # Verify it's actually binary data
                                        if isinstance(audio_binary, bytes):
                                            audio_chunks.append(audio_binary)
                                            if on_chunk:
                                                try:
                                                    on_chunk(chunk_id, audio_binary)
                                                except Exception as callback_error:
                                                    import sys
                                                    print(f"Warning: on_chunk callback error: {callback_error}", file=sys.stderr)
                                        else:
                                            # Got JSON when we expected binary - the server might send progress/status between chunks
                                            # Process this JSON message and then get the actual binary data
                                            import sys
                                            print(f"Debug: Got JSON instead of binary after audio_chunk: {audio_binary[:200]}", file=sys.stderr)
                                            
                                            # Parse and handle this intermediate JSON
                                            intermediate_data = json.loads(audio_binary)
                                            intermediate_type = intermediate_data.get("type")
                                            
                                            if intermediate_type == "progress" and on_progress:
                                                try:
                                                    on_progress({
                                                        "current": intermediate_data.get("current"),
                                                        "total": intermediate_data.get("total"),
                                                        "percent": intermediate_data.get("percent")
                                                    })
                                                except Exception as callback_error:
                                                    print(f"Warning: on_progress callback error: {callback_error}", file=sys.stderr)
                                            
                                            # Now try to get the actual binary data
                                            audio_binary = await websocket.recv()
                                            if isinstance(audio_binary, bytes):
                                                audio_chunks.append(audio_binary)
                                                if on_chunk:
                                                    try:
                                                        on_chunk(chunk_id, audio_binary)
                                                    except Exception as callback_error:
                                                        print(f"Warning: on_chunk callback error: {callback_error}", file=sys.stderr)
                                            
                                    except websockets.exceptions.ConnectionClosed as e:
                                        import sys
                                        print(f"Warning: Connection closed while waiting for audio chunk {chunk_id}: {e}", file=sys.stderr)
                                        # Don't break - check if we got any audio data before failing
                                        # The connection might have closed after sending data
                                    except Exception as e:
                                        import sys
                                        print(f"Error receiving audio chunk {chunk_id}: {e}", file=sys.stderr)
                                        # Continue to try processing other chunks
                            
                            elif msg_type == "complete":
                                if on_complete:
                                    try:
                                        on_complete({
                                            "total_chunks": data.get("total_chunks"),
                                            "message": data.get("message")
                                        })
                                    except Exception as callback_error:
                                        import sys
                                        print(f"Warning: on_complete callback error: {callback_error}", file=sys.stderr)
                                break
                            
                            elif msg_type == "error":
                                error_msg = data.get("message", "Unknown error")
                                if on_error:
                                    try:
                                        on_error(error_msg)
                                    except Exception as callback_error:
                                        import sys
                                        print(f"Warning: on_error callback error: {callback_error}", file=sys.stderr)
                                raise TTSError(f"Server error: {error_msg}")
                    
                    except websockets.exceptions.ConnectionClosed:
                        break
                
                # Combine all audio chunks
                audio_data = b"".join(audio_chunks)
                
                if not audio_data:
                    raise TTSError("No audio data received from server")
                
                # Save to file if requested
                if output_file:
                    Path(output_file).write_bytes(audio_data)
                
                return audio_data
                
        except websockets.exceptions.WebSocketException as e:
            raise TTSError(f"WebSocket error: {str(e)}")
        except Exception as e:
            raise TTSError(f"An error occurred: {str(e)}")
    
    def generate_audio_ws(
        self,
        text: str,
        voice: str,
        output_file: Optional[str] = None,
        on_status: Optional[Callable[[str], None]] = None,
        on_progress: Optional[Callable[[Dict[str, Any]], None]] = None,
        on_chunk: Optional[Callable[[int, bytes], None]] = None,
        on_complete: Optional[Callable[[Dict[str, Any]], None]] = None,
        on_error: Optional[Callable[[str], None]] = None
    ) -> bytes:
        """
        Generate audio from text using WebSocket (synchronous wrapper).
        Provides real-time progress updates and audio chunks.
        
        Args:
            text: Text to convert to speech
            voice: Voice name (e.g., "Anuradha")
            output_file: Optional path to save the audio file
            on_status: Callback for status messages (receives message string)
            on_progress: Callback for progress updates (receives dict with current, total, percent)
            on_chunk: Callback for audio chunks (receives chunk_id and audio bytes)
            on_complete: Callback when generation is complete (receives completion dict)
            on_error: Callback for errors (receives error message)
            
        Returns:
            Complete audio data as bytes
            
        Raises:
            TTSError: If the WebSocket connection or generation fails
        """
        return asyncio.run(
            self.generate_audio_ws_async(
                text, voice, output_file,
                on_status, on_progress, on_chunk, on_complete, on_error
            )
        )
    
    async def stream_audio_async(
        self,
        text: str,
        voice: str
    ) -> AsyncGenerator[bytes, None]:
        """
        Stream audio chunks as they are generated (async generator).
        Useful for playing audio in real-time without waiting for full generation.
        
        Args:
            text: Text to convert to speech
            voice: Voice name (e.g., "Anuradha")
            
        Yields:
            Audio chunk bytes
            
        Raises:
            TTSError: If the API request fails
        """
        endpoint = f"{self.base_url}/tts/generate-audio-large"
        
        try:
            client = await self._get_http_client()
            
            async with client.stream(
                "POST",
                endpoint,
                headers=self._get_auth_headers(),
                json={"input": text, "voice": voice}
            ) as response:
                # Check for credit exhaustion or rate limit
                if response.status_code in (402, 429):
                    try:
                        error_text = await response.aread()
                        error_json = json.loads(error_text.decode())
                        error_type = error_json.get("error")
                        
                        if error_type == "credits_exhausted":
                            raise CreditsExhaustedError(
                                error_json.get("message", "Credits exhausted"),
                                details=error_json.get("details", {})
                            )
                        elif error_type == "rate_limit_exceeded":
                            raise RateLimitError(
                                error_json.get("message", "Rate limit exceeded"),
                                details=error_json.get("details", {})
                            )
                    except (json.JSONDecodeError, AttributeError):
                        pass
                
                if response.status_code == 429:
                    error_text = await response.aread()
                    raise TTSError(f"Too many concurrent requests: {error_text.decode()}")
                elif response.status_code != 200:
                    error_text = await response.aread()
                    raise TTSError(
                        f"API request failed with status {response.status_code}: {error_text.decode()}"
                    )
                
                async for chunk in response.aiter_bytes():
                    yield chunk
                    
        except httpx.HTTPError as e:
            raise TTSError(f"HTTP error occurred: {str(e)}")
        except Exception as e:
            raise TTSError(f"An error occurred: {str(e)}")
        finally:
            await self._close_http_client()
    
    async def health_check_async(self) -> Dict[str, Any]:
        """
        Check the health status of the TTS API server (async version).
        
        Returns:
            Dictionary containing health status information:
            - status: "healthy" if server is operational
            - active_requests: Current number of active requests
            - max_concurrent_requests: Maximum allowed concurrent requests
            - available_slots: Number of available request slots
            
        Raises:
            TTSError: If the health check fails
        """
        endpoint = f"{self.base_url}/health"
        
        try:
            client = await self._get_http_client()
            response = await client.get(endpoint, headers=self._get_auth_headers())
            
            if response.status_code != 200:
                raise TTSError(f"Health check failed with status {response.status_code}")
            
            return response.json()
            
        except httpx.HTTPError as e:
            raise TTSError(f"HTTP error during health check: {str(e)}")
        except Exception as e:
            raise TTSError(f"Health check error: {str(e)}")
        finally:
            await self._close_http_client()
    
    def health_check(self) -> Dict[str, Any]:
        """
        Check the health status of the TTS API server (synchronous wrapper).
        
        Returns:
            Dictionary containing health status information
            
        Raises:
            TTSError: If the health check fails
        """
        return asyncio.run(self.health_check_async())
    
    async def get_server_status_async(self) -> Dict[str, Any]:
        """
        Get detailed server status information (async version).
        
        Returns:
            Dictionary containing detailed server status:
            - server: Server name
            - version: Server version
            - concurrency: Concurrency information
            - endpoints: Available endpoints
            
        Raises:
            TTSError: If the status check fails
        """
        endpoint = f"{self.base_url}/status"
        
        try:
            client = await self._get_http_client()
            response = await client.get(endpoint, headers=self._get_auth_headers())
            
            if response.status_code != 200:
                raise TTSError(f"Status check failed with status {response.status_code}")
            
            return response.json()
            
        except httpx.HTTPError as e:
            raise TTSError(f"HTTP error during status check: {str(e)}")
        except Exception as e:
            raise TTSError(f"Status check error: {str(e)}")
        finally:
            await self._close_http_client()
    
    def get_server_status(self) -> Dict[str, Any]:
        """
        Get detailed server status information (synchronous wrapper).
        
        Returns:
            Dictionary containing detailed server status
            
        Raises:
            TTSError: If the status check fails
        """
        return asyncio.run(self.get_server_status_async())
    
    def __enter__(self):
        """Context manager support"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager cleanup"""
        if self.http_client:
            asyncio.run(self._close_http_client())
    
    async def __aenter__(self):
        """Async context manager support"""
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager cleanup"""
        await self._close_http_client()

