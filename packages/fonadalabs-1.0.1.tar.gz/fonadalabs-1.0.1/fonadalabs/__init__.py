"""
FonadaLabs SDK
A unified Python SDK for FonadaLabs Text-to-Speech, Automatic Speech Recognition, and Audio Denoising APIs.

Usage:
    # TTS (Text-to-Speech)
    from fonadalabs import TTSClient, TTSError
    
    client = TTSClient(api_key="your-api-key")
    audio = client.generate_audio("Hello world", "Anuradha")
    
    # ASR (Automatic Speech Recognition)
    from fonadalabs import ASRClient, ASRWebSocketClient
    
    asr_client = ASRClient(api_key="your-api-key")
    result = asr_client.transcribe("audio.wav")
    
    # Denoise (Audio Denoising)
    from fonadalabs import DenoiseHttpClient, DenoiseStreamingClient
    
    denoise_client = DenoiseHttpClient(api_key="your-api-key")
    denoised = denoise_client.denoise_file("noisy.wav", "clean.wav")
"""

# TTS exports
from .tts.client import TTSClient, TTSError, CreditsExhaustedError as TTSCreditsExhaustedError, RateLimitError as TTSRateLimitError

# ASR exports
from .asr.client import ASRClient
from .asr.ws_client import ASRWebSocketClient
from .asr.config import get_config, SDKConfig
from .asr.languages import SUPPORTED_LANGUAGES, normalize_language, is_supported_language
from .asr.exceptions import (
    ASRSDKError,
    ConfigurationError,
    ValidationError,
    AuthenticationError,
    HTTPRequestError,
    ServerError,
    RateLimitError as ASRRateLimitError,
    TimeoutError as ASRTimeoutError,
    CreditsExhaustedError as ASRCreditsExhaustedError,
)
from .asr.models import TranscribeResult, BatchResult, FailedTranscription

# Denoise exports
from .denoise.http_client import DenoiseHttpClient
from .denoise.streaming_client import DenoiseStreamingClient
from .denoise.exceptions import DenoiseError, CreditsExhaustedError as DenoiseCreditsExhaustedError, RateLimitError as DenoiseRateLimitError

__version__ = "1.0.1"
__author__ = "FonadaLabs"

__all__ = [
    # TTS
    "TTSClient",
    "TTSError",
    "TTSCreditsExhaustedError",
    "TTSRateLimitError",
    
    # ASR Core clients
    "ASRClient",
    "ASRWebSocketClient",
    
    # ASR Configuration
    "get_config",
    "SDKConfig",
    
    # ASR Language utilities
    "SUPPORTED_LANGUAGES",
    "normalize_language",
    "is_supported_language",
    
    # ASR Exceptions
    "ASRSDKError",
    "ConfigurationError",
    "ValidationError",
    "AuthenticationError",
    "HTTPRequestError",
    "ServerError",
    "ASRRateLimitError",
    "ASRTimeoutError",
    "ASRCreditsExhaustedError",
    
    # ASR Models
    "TranscribeResult",
    "BatchResult",
    "FailedTranscription",
    
    # Denoise clients
    "DenoiseHttpClient",
    "DenoiseStreamingClient",
    
    # Denoise Exceptions
    "DenoiseError",
    "DenoiseCreditsExhaustedError",
    "DenoiseRateLimitError",
]


