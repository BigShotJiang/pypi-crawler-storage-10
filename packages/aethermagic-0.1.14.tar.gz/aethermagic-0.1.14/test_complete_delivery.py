#!/usr/bin/env python3
"""
Test complete message delivery with real subscriber
"""

import asyncio
import json
from src.aethermagic.magic import AetherMagic
from src.aethermagic.protocols import ConnectionConfig, ProtocolType

async def test_complete_delivery():
    """Test that complete messages are actually received by subscribers"""
    
    print("=== Testing Complete Message Delivery ===")
    print()
    
    # Create subscriber (worker)
    subscriber_config = ConnectionConfig(ProtocolType.MQTT, 'localhost', 1883, union='test-union')
    subscriber = AetherMagic(subscriber_config)
    
    # Create publisher (client)  
    publisher_config = ConnectionConfig(ProtocolType.MQTT, 'localhost', 1883, union='test-union')
    publisher = AetherMagic(publisher_config)
    
    received_messages = []
    
    def handle_complete(job, task, context, tid, action, data):
        print(f"✅ Received complete: {tid} -> {data}")
        received_messages.append({
            'tid': tid,
            'action': action,
            'data': data
        })
    
    try:
        # Set up connection states (bypass actual MQTT for testing)
        subscriber._MultiProtocolAetherMagic__connected = True
        publisher._MultiProtocolAetherMagic__connected = True
        
        # Subscribe to complete messages
        print("Subscribing to complete messages...")
        await subscriber.subscribe(
            job='test-job',
            workgroup='test-group',
            task='test-task', 
            context='test-context',
            tid='task-123',
            action='complete',
            handler_func=handle_complete
        )
        
        # Check subscription topic
        if len(subscriber._MultiProtocolAetherMagic__listeners) > 0:
            listener = subscriber._MultiProtocolAetherMagic__listeners[0]
            topic = subscriber._MultiProtocolAetherMagic__topic_for_listener(listener)
            print(f"Subscribed to topic: {topic}")
        
        # Send complete message
        print("\nSending complete message with immediate=True...")
        await publisher.complete(
            job='test-job',
            workgroup='test-group',
            task='test-task',
            context='test-context', 
            tid='task-123',
            data={'result': 'success', 'processed_items': 42},
            on_handle=None,
            success=True,
            immediate=True
        )
        
        print("Complete message sent!")
        
        # Let's manually check what topic was used for publishing
        # Get the topic that would be generated for publishing
        pub_topic = publisher.protocol.generate_topic('test-job', 'test-task', 'test-context', 'task-123', 'complete')
        print(f"Published to topic: {pub_topic}")
        
        # Check if topics match
        if len(subscriber._MultiProtocolAetherMagic__listeners) > 0:
            listener = subscriber._MultiProtocolAetherMagic__listeners[0] 
            sub_topic = subscriber._MultiProtocolAetherMagic__topic_for_listener(listener)
            
            print(f"\nTopic comparison:")
            print(f"  Publisher sends to: {pub_topic}")
            print(f"  Subscriber listens: {sub_topic}")
            print(f"  Topics match: {pub_topic == sub_topic}")
            
            if pub_topic != sub_topic:
                print("❌ Topic mismatch - this could be the problem!")
            else:
                print("✅ Topics match correctly")
        
    except Exception as e:
        print(f"Error during test: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_complete_delivery())