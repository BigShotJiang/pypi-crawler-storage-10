#!/usr/bin/env python3
"""
Full integration test for complete message delivery using in-memory protocol
"""

import asyncio
import json
from src.aethermagic.magic import AetherMagic
from src.aethermagic.protocols import ConnectionConfig, ProtocolType

from src.aethermagic.protocols import ProtocolInterface

class InMemoryProtocol(ProtocolInterface):
    """Simple in-memory protocol for testing without external dependencies"""
    
    def __init__(self, config):
        super().__init__(config)
        self.subscriptions = {}
        # Use class-level message bus for all instances
        
    async def connect(self):
        self.connected = True
        print(f"InMemory: Connected")
        return True
        
    async def disconnect(self):
        self.connected = False
        return True
        
    async def publish(self, topic, message, retain=False):
        if not self.connected:
            return False
            
        print(f"InMemory: Publishing to {topic}")
        print(f"          Message: {message.to_dict()}")
        
        # Store message in global bus
        if topic not in InMemoryProtocol.message_bus:
            InMemoryProtocol.message_bus[topic] = []
        InMemoryProtocol.message_bus[topic].append(message.to_dict())
        
        # Deliver to all subscribers of this topic
        for protocol_instance in InMemoryProtocol.all_instances:
            if topic in protocol_instance.subscriptions:
                callback = protocol_instance.subscriptions[topic]
                if callback:
                    await callback(topic, message.to_json())
        
        return True
        
    async def subscribe(self, topic, callback=None):
        if not self.connected:
            return False
            
        print(f"InMemory: Subscribed to {topic}")
        self.subscriptions[topic] = callback
        return True
        
    async def unsubscribe(self, topic):
        if topic in self.subscriptions:
            del self.subscriptions[topic]
        return True
        
    def generate_topic(self, job, task, context, tid, action, shared=False, workgroup=""):
        return f'{self.config.union}/{job}/{task}/{context}/{tid}/{action}'
        
    async def receive_messages(self):
        return []  # Handled via callbacks in publish

# Global registry for in-memory protocol instances
InMemoryProtocol.message_bus = {}
InMemoryProtocol.all_instances = []

async def test_complete_with_memory_protocol():
    """Test complete delivery with in-memory protocol"""
    
    print("=== Full Integration Test with In-Memory Protocol ===")
    print()
    
    # Create config but override protocol
    config = ConnectionConfig(ProtocolType.MQTT, 'localhost', 1883, union='test-union')
    
    # Create subscriber
    subscriber = AetherMagic(config)
    subscriber_protocol = InMemoryProtocol(config)
    subscriber.protocol = subscriber_protocol
    InMemoryProtocol.all_instances.append(subscriber_protocol)
    
    # Create publisher
    publisher = AetherMagic(config)  
    publisher_protocol = InMemoryProtocol(config)
    publisher.protocol = publisher_protocol
    InMemoryProtocol.all_instances.append(publisher_protocol)
    
    received_messages = []
    
    def handle_complete(job, task, context, tid, action, data):
        print(f"✅ Handler called: {action} for task {tid}")
        print(f"   Data: {data}")
        received_messages.append({
            'job': job,
            'task': task, 
            'context': context,
            'tid': tid,
            'action': action,
            'data': data
        })
    
    # Connect both
    await subscriber.protocol.connect()
    await publisher.protocol.connect()
    
    subscriber._MultiProtocolAetherMagic__connected = True
    publisher._MultiProtocolAetherMagic__connected = True
    
    # Subscribe to complete messages
    print("Setting up subscription...")
    await subscriber.subscribe(
        job='image-process',
        workgroup='workers',
        task='resize', 
        context='batch1',
        tid='task-001',
        action='complete',
        handler_func=handle_complete
    )
    
    # Check subscription was created
    print(f"Listeners count: {len(subscriber._MultiProtocolAetherMagic__listeners)}")
    
    if len(subscriber._MultiProtocolAetherMagic__listeners) > 0:
        listener = subscriber._MultiProtocolAetherMagic__listeners[0]
        topic = subscriber._MultiProtocolAetherMagic__topic_for_listener(listener)
        print(f"Subscription topic: {topic}")
        
        # Manually subscribe to protocol level
        await subscriber.protocol.subscribe(topic, None)  # We'll handle via message processing
    
    # Send complete message immediately
    print("\nSending complete message...")
    await publisher.complete(
        job='image-process',
        workgroup='workers', 
        task='resize',
        context='batch1',
        tid='task-001',
        data={'result': 'Image resized successfully', 'output_path': '/tmp/resized.jpg'},
        on_handle=None,
        success=True,
        immediate=True
    )
    
    # Simulate message processing loop
    print("\nProcessing messages...")
    
    # Check what's in the message bus
    print("Messages in bus:")
    for topic, messages in InMemoryProtocol.message_bus.items():
        print(f"  {topic}: {len(messages)} messages")
        for msg in messages:
            print(f"    {msg.get('action')} - {msg.get('status')}")
    
    # Simulate incoming message processing
    for topic, messages in InMemoryProtocol.message_bus.items():
        for msg_data in messages:
            # Add to incoming queue 
            subscriber._MultiProtocolAetherMagic__incoming.append({
                'topic': topic,
                'payload': json.dumps(msg_data)
            })
    
    # Process incoming messages
    if len(subscriber._MultiProtocolAetherMagic__incoming) > 0:
        print(f"\nProcessing {len(subscriber._MultiProtocolAetherMagic__incoming)} incoming messages...")
        await subscriber._MultiProtocolAetherMagic__process_incoming()
    
    # Check results
    print(f"\nReceived messages: {len(received_messages)}")
    for msg in received_messages:
        print(f"  {msg}")
    
    if len(received_messages) > 0:
        print("\n✅ Complete message was delivered and processed!")
    else:
        print("\n❌ Complete message was NOT received")
        
        # Debug info
        print(f"Outgoing queue: {len(publisher._MultiProtocolAetherMagic__outgoing)}")
        print(f"Incoming queue: {len(subscriber._MultiProtocolAetherMagic__incoming)}")
        print(f"Listeners: {len(subscriber._MultiProtocolAetherMagic__listeners)}")

if __name__ == "__main__":
    asyncio.run(test_complete_with_memory_protocol())