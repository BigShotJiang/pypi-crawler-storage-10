#!/usr/bin/env python3
"""
Debug version to trace exactly what happens during message processing
"""

import asyncio
import json
from src.aethermagic.magic import AetherMagic
from src.aethermagic.protocols import ConnectionConfig, ProtocolType, ProtocolInterface

class DebugInMemoryProtocol(ProtocolInterface):
    """Debug protocol with detailed logging"""
    
    message_bus = {}
    all_instances = []
    
    def __init__(self, config):
        super().__init__(config)
        self.subscriptions = {}
        DebugInMemoryProtocol.all_instances.append(self)
        
    async def connect(self):
        self.connected = True
        print(f"DEBUG: Connected")
        return True
        
    async def disconnect(self):
        self.connected = False
        return True
        
    async def publish(self, topic, message, retain=False):
        if not self.connected:
            return False
            
        print(f"DEBUG: Publishing to {topic}")
        print(f"DEBUG: Message data: {message.to_dict()}")
        
        # Store message
        if topic not in DebugInMemoryProtocol.message_bus:
            DebugInMemoryProtocol.message_bus[topic] = []
        DebugInMemoryProtocol.message_bus[topic].append(message.to_dict())
        
        return True
        
    async def subscribe(self, topic, callback=None):
        print(f"DEBUG: Subscribed to {topic}")
        self.subscriptions[topic] = callback
        return True
        
    async def unsubscribe(self, topic):
        if topic in self.subscriptions:
            del self.subscriptions[topic]
        return True
        
    async def receive_messages(self):
        return []  # Messages handled via direct queueing in test

async def debug_complete_processing():
    """Debug complete message processing step by step"""
    
    print("=== Debug Complete Message Processing ===")
    print()
    
    # Create instances
    config = ConnectionConfig(ProtocolType.MQTT, 'localhost', 1883, union='test-union')
    
    subscriber = AetherMagic(config)
    subscriber.protocol = DebugInMemoryProtocol(config)
    
    publisher = AetherMagic(config)
    publisher.protocol = DebugInMemoryProtocol(config)
    
    received_calls = []
    
    def debug_handler(action, tid, data, fulldata):
        print(f"🎯 HANDLER CALLED!")
        print(f"   Action: {action}")
        print(f"   TID: {tid}")
        print(f"   Data: {data}")
        print(f"   Fulldata: {fulldata}")
        received_calls.append((action, tid, data, fulldata))
    
    # Connect
    await subscriber.protocol.connect()
    await publisher.protocol.connect()
    
    subscriber._MultiProtocolAetherMagic__connected = True
    publisher._MultiProtocolAetherMagic__connected = True
    
    # Subscribe
    print("1. Setting up subscription...")
    await subscriber.subscribe(
        job='test-job',
        workgroup='test-group',
        task='test-task',
        context='test-context', 
        tid='task-123',
        action='complete',
        handler_func=debug_handler
    )
    
    print(f"   Listeners created: {len(subscriber._MultiProtocolAetherMagic__listeners)}")
    
    # Send message
    print("\n2. Sending complete message...")
    await publisher.complete(
        job='test-job',
        workgroup='test-group', 
        task='test-task',
        context='test-context',
        tid='task-123',
        data={'result': 'success'},
        on_handle=None,
        success=True,
        immediate=True
    )
    
    print(f"   Messages in bus: {len(DebugInMemoryProtocol.message_bus)}")
    for topic, msgs in DebugInMemoryProtocol.message_bus.items():
        print(f"     {topic}: {len(msgs)} messages")
    
    # Manually add message to incoming queue
    print("\n3. Adding message to incoming queue...")
    for topic, messages in DebugInMemoryProtocol.message_bus.items():
        for msg_data in messages:
            incoming_msg = {
                'topic': topic,
                'payload': json.dumps(msg_data)
            }
            subscriber._MultiProtocolAetherMagic__incoming.append(incoming_msg)
            print(f"   Added to incoming: {topic}")
    
    print(f"   Incoming queue size: {len(subscriber._MultiProtocolAetherMagic__incoming)}")
    
    # Process each step
    print("\n4. Processing incoming messages...")
    
    if len(subscriber._MultiProtocolAetherMagic__incoming) > 0:
        # Check each incoming message vs each listener
        for i, incoming in enumerate(subscriber._MultiProtocolAetherMagic__incoming):
            print(f"\n   Message {i+1}:")
            print(f"     Topic: {incoming['topic']}")
            
            # Parse the message
            try:
                topic = incoming['topic']
                payload = incoming['payload']
                fulldata = json.loads(payload)
                
                print(f"     Parsed data: {fulldata}")
                
                # Parse topic
                parts = subscriber.protocol.parse_topic(topic)
                print(f"     Topic parts: {parts}")
                
                # Check against each listener
                for j, listener in enumerate(subscriber._MultiProtocolAetherMagic__listeners):
                    print(f"\n     Listener {j+1}:")
                    print(f"       Job: {listener['job']}")
                    print(f"       Task: {listener['task']}")  
                    print(f"       Context: {listener['context']}")
                    print(f"       TID: {listener['tid']}")
                    print(f"       Action: {listener['action']}")
                    
                    # Check if message fits listener
                    fits = await check_message_fits_listener(incoming, listener, subscriber)
                    print(f"       Fits listener: {fits}")
                    
                    if fits:
                        print(f"       🎯 CALLING HANDLER!")
                        try:
                            # Call handler with correct signature: (action, tid, data, fulldata)
                            listener['handler'](
                                parts.get('action', ''),
                                parts.get('tid', ''),
                                fulldata.get('data', {}),
                                fulldata
                            )
                        except Exception as e:
                            print(f"       Handler error: {e}")
                            
            except Exception as e:
                print(f"     Error processing message: {e}")
                import traceback
                traceback.print_exc()
    
    print(f"\n5. Results:")
    print(f"   Handler calls: {len(received_calls)}")
    for call in received_calls:
        print(f"     {call}")

async def check_message_fits_listener(incoming, listener, aether_instance):
    """Check if a message matches a listener"""
    try:
        topic, payload, fulldata, data, union, job, task, context, tid, action = aether_instance._MultiProtocolAetherMagic__incoming_parts(incoming)
        
        # Check each field
        matches = (
            listener['job'] == job and
            listener['task'] == task and  
            listener['context'] == context and
            listener['action'] == action and
            (listener['tid'] == tid or listener['tid'] == '+')
        )
        
        print(f"         Match details:")
        print(f"           Job: {listener['job']} == {job} = {listener['job'] == job}")
        print(f"           Task: {listener['task']} == {task} = {listener['task'] == task}")
        print(f"           Context: {listener['context']} == {context} = {listener['context'] == context}")
        print(f"           Action: {listener['action']} == {action} = {listener['action'] == action}")
        print(f"           TID: {listener['tid']} == {tid} = {listener['tid'] == tid or listener['tid'] == '+'}")
        
        return matches
        
    except Exception as e:
        print(f"         Error checking fit: {e}")
        return False

if __name__ == "__main__":
    asyncio.run(debug_complete_processing())