#!/usr/bin/env python3
"""
Test to verify that complete() with immediate=True actually sends messages
"""

import asyncio
import json
from src.aethermagic.magic import AetherMagic
from src.aethermagic.protocols import ConnectionConfig, ProtocolType

async def test_complete_immediate():
    """Test immediate complete message sending"""
    
    print("=== Testing Complete with immediate=True ===")
    print()
    
    # Create AetherMagic instance
    config = ConnectionConfig(ProtocolType.MQTT, 'localhost', 1883, union='test-union')
    aether = AetherMagic(config)
    
    # Mock the protocol to capture sent messages
    sent_messages = []
    
    original_publish = aether.protocol.publish
    
    async def mock_publish(topic, message, retain=False):
        sent_messages.append({
            'topic': topic,
            'message': message.to_dict(),
            'retain': retain
        })
        print(f"✅ Message sent to topic: {topic}")
        print(f"   Message: {json.dumps(message.to_dict(), indent=2)}")
        return True
    
    # Replace publish method with mock
    aether.protocol.publish = mock_publish
    
    # Simulate connected state
    aether._MultiProtocolAetherMagic__connected = True
    
    print("Testing complete() with immediate=False (should queue)...")
    await aether.complete(
        job='test-job',
        workgroup='test-group', 
        task='test-task',
        context='test-context',
        tid='task-123',
        data={'result': 'success'},
        on_handle=None,
        success=True,
        immediate=False  # Should go to queue
    )
    
    print(f"Messages sent so far: {len(sent_messages)}")
    print()
    
    print("Testing complete() with immediate=True (should send immediately)...")
    await aether.complete(
        job='test-job',
        workgroup='test-group',
        task='test-task', 
        context='test-context',
        tid='task-456',
        data={'result': 'completed'},
        on_handle=None,
        success=True,
        immediate=True  # Should send immediately
    )
    
    print(f"Messages sent so far: {len(sent_messages)}")
    print()
    
    # Check what was sent
    if len(sent_messages) > 0:
        print("✅ Messages were sent!")
        for i, msg in enumerate(sent_messages):
            print(f"Message {i+1}:")
            print(f"  Topic: {msg['topic']}")
            print(f"  Action: {msg['message'].get('action')}")
            print(f"  Status: {msg['message'].get('status')}")
            print(f"  Data: {msg['message'].get('data')}")
            print()
    else:
        print("❌ No messages were sent!")
    
    # Check the outgoing queue
    print(f"Outgoing queue size: {len(aether._MultiProtocolAetherMagic__outgoing)}")
    if len(aether._MultiProtocolAetherMagic__outgoing) > 0:
        print("Queued messages:")
        for i, msg in enumerate(aether._MultiProtocolAetherMagic__outgoing):
            print(f"  {i+1}. {msg}")

if __name__ == "__main__":
    asyncio.run(test_complete_immediate())