import enum
import typing
from pathlib import Path
from typing import Any, TypeVar

import attrs
import pytest


class _OptionKind(enum.Flag):
    CLI = 1
    INI = 2


@attrs.define
class _OptionData:
    help: str
    kind: _OptionKind


def option(*, default: typing.Any, help: str, kind: _OptionKind):
    """Mark a field to be included as a pytest argument, or as a pytest
    configuration, or both.

    Args:
        default: Default value.
        help: Description for the option.
        kind: Whether its a CLI option, an INI option, or both of them.
    """
    opt = _OptionData(help, kind)
    return attrs.field(default=default, metadata={"option_data": opt})


def _option_data(attrib: attrs.Attribute) -> _OptionData:
    opt = attrib.metadata.get("option_data")
    if opt is None:
        raise ValueError("not a valid pytest option field")
    return opt


def _make_ini_compatible_field(field: attrs.Attribute) -> attrs.Attribute:
    field_cls = typing.get_origin(field.type) or field.type
    field_cls_args = typing.get_args(field.type)

    if field_cls is None:
        raise ValueError("Field is missing type")
    elif field_cls is list:
        if field_cls_args is None:
            raise ValueError(
                f"Field {field.name} missing type annotation for its contents."
            )
        assert len(field_cls_args) == 1
        field_cls_arg = field_cls_args[0]

        if field_cls_arg is Path:
            pytest_ini_type = "paths"
            converter = None
        elif field_cls_arg in [float, int, str]:
            pytest_ini_type = "linelist"
            converter = attrs.Converter(
                lambda values: [
                    field_cls_arg(v) for v in typing.cast(list[str], values)
                ]
            )
        else:
            raise ValueError(
                f"For '{field_cls}' fields, element type can only "
                "be 'float', 'int', or 'str'"
            )
    elif field_cls in [float, int, str] or issubclass(field_cls, enum.Enum):
        pytest_ini_type = "string"
        converter = attrs.Converter(lambda value: field_cls(value))
    else:
        raise TypeError(
            f"Field type '{field.type}' of '{field.name}' is not supported."
        )

    return field.evolve(
        metadata={"_option_pytest_ini_type": pytest_ini_type, **field.metadata},
        converter=converter,
    )


def _prepare_option_converters(
    _: type,
    fields: list[attrs.Attribute[Any]],
) -> list[attrs.Attribute[Any]]:
    new_fields = []
    for field in fields:
        opt = _option_data(field)
        if _OptionKind.INI in opt.kind:
            field = _make_ini_compatible_field(field)
        new_fields.append(field)

    return new_fields


_C = TypeVar("_C", bound=type)


def define(cls: _C) -> _C:
    cls_ = attrs.define(cls, field_transformer=_prepare_option_converters)
    cls_.__pytestargsdefined__ = ""
    return cls_


def add(cls: type, parser: pytest.Parser, group_name: str | None = None):
    if not hasattr(cls, "__pytestargsdefined__"):
        raise ValueError(f"'{cls.__name__}' is not a `pytestargs` compatible class.")
    if group_name is None:
        pargrp = parser
    else:
        pargrp = parser.getgroup(
            group_name, description="Options affecting pytest-otelmark behavior."
        )

    for attrib in attrs.fields(cls):
        attrib: attrs.Attribute
        opt = _option_data(attrib)

        if _OptionKind.CLI in opt.kind:
            pargrp.addoption(
                f"--{group_name}-{attrib.name}",
                help=opt.help,
                type=attrib.converter or attrib.type,
            )

        if _OptionKind.INI in opt.kind:
            parser.addini(
                f"{group_name}_{attrib.name}",
                help=opt.help,
                type=attrib.metadata["_option_pytest_ini_type"],
            )
