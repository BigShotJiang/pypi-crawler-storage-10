from setuptools import setup,find_packages
 
setup(
   name='rocketzinou',
   version='0.1.0',
   author='Zine Eddine Tahri',
   author_email='z.tahri@esi-sba.dz',
   packages=find_packages(),
   url='http://pypi.python.org/pypi/rocketZinou/',
   license='LICENSE.txt',
   description='An awesome package that does something',
   long_description=open('README.md').read(),
   long_description_content_type="text/markdown",
   install_requires=['numpy']
)