# libnpp

A useful Python package with utility functions.

## Installation

```bash
pip install libnpp
```

## Usage

```python
import libnpp

print(libnpp.hello_world())
result = libnpp.add_numbers(5, 3)
print(result)
```
