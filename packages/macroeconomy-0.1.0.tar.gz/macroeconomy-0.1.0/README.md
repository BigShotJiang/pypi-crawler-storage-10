# Macroeconomy  _0.1.0_

An realism economic analysis package.

### Development Status
This programme is currently being planned.

### Download

Here is our website:
* https://github.com/JerrySkywolf/

This package could be downloaded through PyPi by:

`pip install miding`

View at the webpage
* https://pypi.org/project/macroeconomy
