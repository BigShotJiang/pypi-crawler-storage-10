# Bitbucket Integration Setup

## Quick Setup

### 1. Generate Bitbucket HTTP Access Token

1. Go to your Bitbucket instance: `https://scm.devops.cambio.se`
2. Click your profile icon → **Personal settings**
3. Click **HTTP access tokens** (left sidebar)
4. Click **Create token**
5. Settings:
   - **Token name**: `token` (or any name)
   - **Permissions**: Select **Repository write** (allows clone, push, PR creation)
   - **Expiry**: Choose appropriate expiry date
6. Click **Create**
7. **Copy the token immediately** (it won't be shown again that is your token)

### 2. Configure .env File

The `.env` file should already exist in `sdk/.env`. If not, create it:

```bash
# Copy template
cp sdk/.env.example sdk/.env

# Or on Windows PowerShell
Copy-Item sdk\.env.example sdk\.env
```

### 3. Add Your Token

Edit `sdk/.env` and replace the token:

```bash
# Bitbucket Configuration
BITBUCKET_SERVER=scm.devops.cambio.se
BITBUCKET_PROJECT=IAII
BITBUCKET_REPO=cambio_prompt_lib
BITBUCKET_HTTP_TOKEN=paste-your-token-here
BITBUCKET_USERNAME=your_user_name
```

**Important:** 
- Replace only the `BITBUCKET_HTTP_TOKEN` value with your actual token
- Do NOT commit this file to git (it's in .gitignore)



Expected output: `✓ Ready`

## Usage

### Full Workflow with Bitbucket

```bash
promptx init

# Menu:
# 1. Create new draft       → Fill in prompt details
# 2. List drafts           → (skip if you just created one)
# 3. Test draft            → Validate before publishing
# 4. Publish draft         → Choose method 2 (Bitbucket)
# 5. List published        → (skip)
# 6. Edit existing prompt  → (skip)
# 7. Quit
```

### What Happens with Bitbucket Publish

When you select **method 2 (Full Bitbucket workflow)**:

1. ✓ Clones the repository to temp directory
2. ✓ Creates a new branch: `<prompt-name>-<ticket-id>`
3. ✓ Creates directory: `prompts/<role>/<category>/<name>/`
4. ✓ Generates `<name>.yml` with metadata
5. ✓ Generates `<name>.md` with full prompt content
6. ✓ Commits with message: `feat(<role>): Add <name> prompt`
7. ✓ Pushes to remote branch
8. ✓ Creates Pull Request via Bitbucket API



#### Module Not Found
```
ModuleNotFoundError: No module named 'dotenv'
```

**Fix:**
```bash
pip install python-dotenv
# Or reinstall all requirements
pip install -r sdk/requirements.txt
```

#### Permission Denied
```
✗ Failed to push: Permission denied
```

**Fix:**
1. Token needs **Repository write** permission
2. You must be a member of the repository project
3. Repository might be locked (check with admin)

## Alternative: Local Publish

If you don't want to use Bitbucket automation:

```bash
promptx init
# Select option 4 (Publish)
# Choose method 1 (Local files only)
```

This creates files locally in `prompts/` folder. Then you can:

```bash
# Manual git workflow
git checkout -b my-prompt-AI_123
git add prompts/
git commit -m "feat(role): Add my prompt"
git push origin my-prompt-AI_123
# Create PR manually in Bitbucket UI
```

## Security Best Practices

1. ✓ Never commit `.env` file (already in `.gitignore`)
2. ✓ Use HTTP tokens, not password
3. ✓ Set token expiry date (rotate periodically)
4. ✓ Grant minimum permissions needed (Repository write only)
5. ✓ Revoke tokens when no longer needed


---

