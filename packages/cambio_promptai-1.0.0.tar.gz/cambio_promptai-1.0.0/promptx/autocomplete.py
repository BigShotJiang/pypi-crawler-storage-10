from pathlib import Path
import click
from promptx.validator import validate_basic_yaml


def get_prompt_paths():
    prompts_dir = Path("prompts")
    paths = []
    if not prompts_dir.exists():
        return paths
    for category in prompts_dir.iterdir():
        if category.is_dir():
            for prompt in category.iterdir():
                if prompt.is_dir() and (prompt / "prompt.yaml").exists():
                    paths.append(str(prompt))
    return paths


class PromptPathType(click.Path):
    def __init__(self):
        super().__init__(exists=True, file_okay=False, dir_okay=True)

    def shell_complete(self, ctx, param, incomplete):
        paths = get_prompt_paths()
        matches = [p for p in paths if incomplete in p]
        return [click.shell_completion.CompletionItem(path) for path in matches]
