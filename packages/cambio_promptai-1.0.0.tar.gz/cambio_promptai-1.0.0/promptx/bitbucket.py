"""
Bitbucket integration for creating branches, commits, and pull requests
"""
import os
import subprocess
import tempfile
import yaml
import requests
from pathlib import Path
from datetime import datetime
import re
from rich.console import Console
from promptx.config import (
    BITBUCKET_SERVER,
    BITBUCKET_PROJECT,
    BITBUCKET_REPO,
    BITBUCKET_HTTP_TOKEN,
    BITBUCKET_USERNAME,
)
from promptx.auth import get_token_with_fallback, get_user_info

console = Console()

class BitbucketWorkflow:
    def __init__(self):
        self.server = BITBUCKET_SERVER
        self.project = BITBUCKET_PROJECT
        self.repo = BITBUCKET_REPO
        self.token = None  # Will be fetched when needed
        self.username = None  # Will be fetched when needed
    
    def create_prompt_workflow(self, prompt_data):
        """Complete workflow: Create branch, files, and PR using git commands"""
        try:
            # Get credentials from global auth system
            self.token = get_token_with_fallback()
            if not self.token:
                return False, "Authentication required. Please run 'promptx login' to authenticate."
            
            self.username, _ = get_user_info()
            if not self.username:
                return False, "Username not found. Please run 'promptx login' to authenticate."
            
            # Extract and validate data
            role = prompt_data.get('role', '')
            name = prompt_data.get('name', '')
            ticket_id = prompt_data.get('jira_ticket', '')
            
            if not all([role, name, ticket_id]):
                return False, "Missing required fields: role, name, or jira_ticket"
            
            # Normalize name for git compatibility
            normalized_name = name.lower().replace(' ', '-').replace('_', '-')
            normalized_name = re.sub(r'[^a-z0-9-]', '', normalized_name)
            branch_name = f"{normalized_name}-{ticket_id}"
            
            console.print(f"[cyan]Creating prompt workflow for: {branch_name}[/cyan]")
            
            # Create files using git commands
            files_success, files_message = self._create_files_via_git(
                branch_name, normalized_name, role, prompt_data, ticket_id
            )
            if not files_success:
                return False, files_message
            
            # Create Pull Request via API
            pr_success, pr_message = self._create_pull_request(branch_name, normalized_name, ticket_id, prompt_data)
            
            if pr_success:
                return True, f"Prompt created successfully! {pr_message}"
            else:
                return True, f"Files pushed but PR creation failed: {pr_message}. Please create PR manually."
                
        except Exception as e:
            console.print(f"[red]Error in workflow: {e}[/red]")
            return False, f"Error creating prompt: {str(e)}"
            return False, f"Error creating prompt: {str(e)}"
    
    def _create_files_via_git(self, branch_name, normalized_name, role, prompt_data, ticket_id):
        """Create files using git commands"""
        with tempfile.TemporaryDirectory() as temp_dir:
            try:
                # Clone repository
                repo_url = f"https://{self.username}:{self.token}@{self.server}/scm/{self.project.lower()}/{self.repo}.git"
                
                console.print(f"[cyan]Cloning repository...[/cyan]")
                result = subprocess.run(
                    ['git', 'clone', repo_url, temp_dir],
                    capture_output=True, text=True, cwd=os.getcwd()
                )
                
                if result.returncode != 0:
                    return False, f"Failed to clone repository: {result.stderr}"
                
                # Create and checkout new branch
                subprocess.run(['git', 'checkout', '-b', branch_name], cwd=temp_dir, check=True)
                
                # Create directory structure
                category = prompt_data.get('category', 'general')
                prompt_dir = Path(temp_dir) / "prompts" / role / category / normalized_name
                prompt_dir.mkdir(parents=True, exist_ok=True)
                
                # Generate content
                yaml_content = self._generate_yaml_content(prompt_data)
                md_content = self._generate_markdown_content(prompt_data)
                
                # Write files
                with open(prompt_dir / f"{normalized_name}.yml", 'w', encoding='utf-8') as f:
                    f.write(yaml_content)
                
                with open(prompt_dir / f"{normalized_name}.md", 'w', encoding='utf-8') as f:
                    f.write(md_content)
                
                # Git add, commit, push
                # Format ticket ID: AI_908 -> [AI-908] for Jira hook compatibility
                formatted_ticket = ticket_id.replace('_', '-')
                commit_message = f'[{formatted_ticket}] Add {normalized_name} prompt'
                
                subprocess.run(['git', 'add', '.'], cwd=temp_dir, check=True)
                subprocess.run([
                    'git', 'commit', '-m', commit_message
                ], cwd=temp_dir, check=True)
                console.print(f"[dim]Commit: {commit_message}[/dim]")
                
                console.print(f"[cyan]Pushing to remote...[/cyan]")
                # First, verify remote is set correctly
                remote_check = subprocess.run(
                    ['git', 'remote', '-v'],
                    capture_output=True, text=True, cwd=temp_dir
                )
                console.print(f"[dim]Remote: {remote_check.stdout.strip().split()[0] if remote_check.stdout else 'unknown'}[/dim]")
                
                result = subprocess.run(
                    ['git', 'push', '--set-upstream', 'origin', branch_name],
                    capture_output=True, text=True, cwd=temp_dir
                )
                
                if result.returncode == 0:
                    console.print(f"[green]✅ Files created and pushed successfully![/green]")
                    return True, "Files created and pushed successfully!"
                else:
                    error_msg = result.stderr or result.stdout or "Unknown error"
                    console.print(f"[red]Git push failed:[/red]")
                    console.print(f"[dim]{error_msg}[/dim]")
                    # Show helpful message
                    console.print(f"\n[yellow]Tip: Files were committed locally. You can push manually:[/yellow]")
                    console.print(f"[dim]git push origin {branch_name}[/dim]")
                    return False, f"Push failed: {error_msg.strip()}"
            except subprocess.CalledProcessError as e:
                return False, f"Git command failed: {e}"
            except Exception as e:
                return False, f"Error creating files: {e}"
    
    def _generate_yaml_content(self, prompt_data):
        """Generate YAML file content with metadata"""
        # Derive description server-side if the client didn't provide one
        description = self._derive_description(prompt_data)

        yaml_data = {
            'metadata': {
                'title': prompt_data.get('name', ''),
                'description': description,
                'author': {
                    'name': prompt_data.get('author_name', ''),
                    'email': prompt_data.get('author_email', '')
                },
                'version': '1.0.0',
                'created_date': datetime.now().isoformat(),
                'jira_ticket': prompt_data.get('jira_ticket', ''),
                'role': prompt_data.get('role', ''),
                'primary_category': prompt_data.get('role', ''),
                'category': prompt_data.get('category', ''),
                'use_case': prompt_data.get('name', '').lower().replace(' ', '-'),
                'mode': prompt_data.get('mode', 'ask'),
                'tags': prompt_data.get('tags', [])
            },
            'ai_compatibility': {
                'recommended_model': prompt_data.get('recommended_model', 'gpt-4'),
                'tested_models': prompt_data.get('tested_models', ['gpt-4', 'gpt-3.5-turbo']),
                'temperature': prompt_data.get('temperature', 0.7),
                'max_tokens': prompt_data.get('max_tokens', 2000),
                'context_requirements': prompt_data.get('context_requirements', 'moderate')
            }
        }

        return yaml.dump(yaml_data, default_flow_style=False, sort_keys=False)

    def _derive_description(self, prompt_data):
        """Return a short description derived from the prompt data.
        
        Preference order:
        1. Explicit prompt_data['description'] if provided and non-empty
        2. First 2 non-empty lines of prompt_data['task_description']
        3. First 2 non-empty lines of prompt_data['system_role']
        Returns an empty string if nothing usable is found.
        """
        try:
            # Check explicit description first
            desc = (prompt_data.get('description') or '').strip()
            if desc:
                return desc

            # Use task_description (frontend sends merged promptText as task) or fallback to system_role
            task = (prompt_data.get('task_description') or '').strip()
            system_role = (prompt_data.get('system_role') or '').strip()
            
            candidate = task or system_role
            if not candidate:
                return ''

            # Take the first 2 non-empty lines and truncate to a reasonable length
            lines = []
            for line in candidate.splitlines():
                l = line.strip()
                if l:
                    lines.append(l)
                    if len(lines) == 2:
                        break
            
            if not lines:
                return ''
            
            result = ' '.join(lines)
            return result if len(result) <= 200 else result[:197] + '...'
        except Exception as e:
            console.print(f"[yellow]Warning: Could not derive description: {e}[/yellow]")
            return ''
    
    def _generate_markdown_content(self, prompt_data):
        """Generate Markdown file content with prompt details - matches Flask backend format"""
        system_role = prompt_data.get('system_role', '').strip()
        task = prompt_data.get('task_description', '').strip()
        
        # Derive description from task if not explicitly provided
        description = self._derive_description(prompt_data) or 'No description provided'

        # Start with title and basic metadata
        md_content = f"# {prompt_data.get('name', 'Untitled Prompt')}\n\n"
        md_content += f"**Description:** {description}\n\n"
        md_content += f"**Role:** {prompt_data.get('role', 'N/A')}\n\n"
        md_content += f"**Category:** {prompt_data.get('category', 'N/A')}\n\n"
        md_content += f"**Mode:** {prompt_data.get('mode', 'ask')}\n\n"

        if prompt_data.get('tags'):
            md_content += f"**Tags:** {', '.join(prompt_data.get('tags', []))}\n\n"

        md_content += "---\n\n"

        # Add full system role content (not just metadata)
        if system_role:
            md_content += "## System Role\n\n" + system_role + "\n\n"

        # Add full task description content (not just metadata)
        if task:
            md_content += "## Task Description\n\n" + task + "\n\n"

        # If neither system_role nor task provided, add placeholder
        if not system_role and not task:
            md_content += "## Prompt Content\n\n*Please add your prompt content here.*\n\n"

        # Keep the separator but do NOT append Author/Created/Ticket metadata to markdown
        md_content += "---\n\n"

        return md_content
    
    def _create_pull_request(self, branch_name, prompt_name, ticket_id, prompt_data):
        """Create pull request to merge prompt branch to master"""
        try:
            # Token is already fetched in create_prompt_workflow
            if not self.token:
                console.print("[yellow]⚠ BITBUCKET_HTTP_TOKEN not available. Skipping PR creation.[/yellow]")
                console.print(f"[cyan]Create PR manually: https://{self.server}/projects/{self.project}/repos/{self.repo}/pull-requests[/cyan]")
                return False, "Token not configured"
            
            endpoint = f"https://{self.server}/rest/api/1.0/projects/{self.project}/repos/{self.repo}/pull-requests"
            
            title = f"{ticket_id}: Add {prompt_name} prompt"
            derived_description = self._derive_description(prompt_data)
            description = f"""This PR adds a new prompt: **{prompt_data.get('name', prompt_name)}**

**Details:**
- Role: {prompt_data.get('role', 'N/A')}
- Category: {prompt_data.get('category', 'N/A')}
- Author: {prompt_data.get('author_name', 'N/A')}
- Ticket: {ticket_id}

**Description:**
{derived_description or 'No description provided'}

Auto-generated PR for prompt library addition."""
            
            payload = {
                "title": title,
                "description": description,
                "state": "OPEN",
                "open": True,
                "closed": False,
                "fromRef": {
                    "id": f"refs/heads/{branch_name}",
                    "repository": {
                        "slug": self.repo,
                        "name": None,
                        "project": {
                            "key": self.project
                        }
                    }
                },
                "toRef": {
                    "id": "refs/heads/master",
                    "repository": {
                        "slug": self.repo,
                        "name": None,
                        "project": {
                            "key": self.project
                        }
                    }
                },
                "locked": False,
                "reviewers": []
            }
            
            headers = {
                'Authorization': f'Bearer {self.token}',
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
            
            console.print(f"[cyan]Creating pull request...[/cyan]")
            response = requests.post(endpoint, json=payload, headers=headers, timeout=30)
            
            if response.status_code in [200, 201]:
                result = response.json()
                pr_id = result.get('id', 'Unknown')
                pr_url = f"https://{self.server}/projects/{self.project}/repos/{self.repo}/pull-requests/{pr_id}"
                console.print(f"[green]✓ Successfully created PR #{pr_id}[/green]")
                console.print(f"[cyan]PR URL: {pr_url}[/cyan]")
                return True, f"Pull Request #{pr_id} created: {pr_url}"
            else:
                console.print(f"[yellow]⚠ PR creation failed: {response.status_code}[/yellow]")
                console.print(f"[yellow]Response: {response.text[:200]}[/yellow]")
                return False, f"Failed to create Pull Request (status {response.status_code})"
                
        except requests.exceptions.RequestException as e:
            console.print(f"[red]Error creating PR: {e}[/red]")
            return False, f"Error creating Pull Request: {str(e)}"
        except Exception as e:
            console.print(f"[red]Error creating PR: {e}[/red]")
            return False, f"Error creating Pull Request: {str(e)}"
