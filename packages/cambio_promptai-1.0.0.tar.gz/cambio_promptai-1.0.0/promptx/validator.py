from pathlib import Path
import yaml
import json
import jsonschema
from typing import Union
from .config import DEFAULT_SCHEMA_PATH


def sync_description_from_prompt(prompt_path: Path):
    """Extract first line from prompt.md and sync to prompt.yaml"""
    from .utils import locate_prompt_files
    prompt_yaml, prompt_md = locate_prompt_files(Path(prompt_path))

    if prompt_yaml is None or prompt_md is None:
        return False, "missing_files"

    if not prompt_md.exists() or not prompt_yaml.exists():
        return False, "missing_files"

    first_line = None
    with open(prompt_md, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                first_line = line
                break

    with open(prompt_yaml, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}

    if first_line and data.get('description') != first_line:
        data['description'] = first_line
        with open(prompt_yaml, "w", encoding="utf-8") as f:
            yaml.dump(data, f, sort_keys=False)
        return True, first_line

    return False, data.get('description')


def validate_basic_yaml(prompt_path: Path):
    yaml_file = Path(prompt_path) / "prompt.yaml"
    if not yaml_file.exists():
        return False, "prompt.yaml missing"
    try:
        with open(yaml_file, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        return True, data
    except Exception as e:
        return False, str(e)


def validate_prompt_yaml(yaml_file_path_or_data: Union[Path, dict]):
    """Validate a prompt (either a Path to a YAML file or a dict of data)

    This accepts either a Path pointing to a YAML file, or a normalized dict
    (recommended). If given a Path and the YAML uses the legacy `metadata`
    envelope, schema validation will likely fail; prefer passing normalized
    data obtained via `normalize_prompt_data`.
    """
    schema_path = DEFAULT_SCHEMA_PATH / "prompt-schema.json"
    if not Path(schema_path).exists():
        return False, f"Schema file not found: {schema_path}"

    try:
        with open(schema_path, 'r', encoding='utf-8') as f:
            schema = json.load(f)

        if isinstance(yaml_file_path_or_data, dict):
            data = yaml_file_path_or_data
        else:
            with open(yaml_file_path_or_data, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f) or {}

        jsonschema.validate(instance=data, schema=schema)
        return True, None
    except jsonschema.ValidationError as ve:
        return False, str(ve)
    except Exception as e:
        return False, str(e)


def normalize_prompt_data(data: dict, yaml_file_path: Path = None) -> dict:
    """Normalize prompt data to the new flat schema shape.

    Accepts either new prompt.yaml format (flat keys) or legacy format with
    a top-level `metadata` mapping. Returns a normalized dict with keys the
    rest of the tooling expects: name, author, owner_team, category,
    subcategory, tags, description, etc.
    """
    if not isinstance(data, dict):
        return {}

    # Legacy style: { metadata: { ... } }
    if 'metadata' in data and isinstance(data['metadata'], dict):
        m = data['metadata']
        norm = {}
        # Name/title
        norm['name'] = m.get('title') or (Path(yaml_file_path).stem if yaml_file_path else m.get('use_case') or '')

        # Author: can be dict or simple string
        auth = m.get('author')
        if isinstance(auth, dict):
            norm['author'] = auth.get('email') or auth.get('name') or ''
        else:
            norm['author'] = auth or ''

        # Owner: prefer metadata.owner, else fallback to author
        owner = m.get('owner')
        if isinstance(owner, dict):
            norm['owner_team'] = owner.get('name') or owner.get('team') or ''
        else:
            if isinstance(auth, dict):
                norm['owner_team'] = auth.get('name') or auth.get('email') or ''
            else:
                norm['owner_team'] = auth or ''

        # Category/subcategory
        cat = (m.get('primary_category') or m.get('role') or m.get('category') or '').lower()
        norm['category'] = cat
        norm['subcategory'] = m.get('use_case') or ''

        # Risk tier intentionally omitted; governance handled separately

        # Version, tags and description
        norm['version'] = m.get('version') or data.get('version') or '1.0.0'
        norm['tags'] = m.get('tags') or []
        norm['description'] = m.get('description') or ''

        return norm

    # Already in new flat format
    return data
