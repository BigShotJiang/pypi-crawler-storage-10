"""cambio-promptAI SDK package."""
__version__ = "1.0.0"
