"""
Global credential management for PromptX CLI.
Handles secure storage of user credentials in ~/.promptx/credentials.json
"""
import json
import os
from pathlib import Path
from typing import Dict, Optional, Tuple
import stat
import requests
from rich.console import Console
from rich.prompt import Prompt, Confirm

console = Console()

# Global config directory and file
CONFIG_DIR = Path.home() / '.promptx'
CREDENTIALS_FILE = CONFIG_DIR / 'credentials.json'


def ensure_config_dir() -> Path:
    """Ensure the ~/.promptx directory exists with proper permissions."""
    CONFIG_DIR.mkdir(exist_ok=True)
    # Set directory permissions to 700 (owner read/write/execute only)
    CONFIG_DIR.chmod(stat.S_IRWXU)
    return CONFIG_DIR


def load_credentials() -> Dict[str, str]:
    """Load credentials from the global config file."""
    if not CREDENTIALS_FILE.exists():
        return {}

    try:
        with open(CREDENTIALS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        console.print(f"[yellow]Warning: Could not load credentials file: {e}[/yellow]")
        return {}


def save_credentials(credentials: Dict[str, str]) -> bool:
    """Save credentials to the global config file with secure permissions."""
    try:
        ensure_config_dir()

        # Write credentials to file
        with open(CREDENTIALS_FILE, 'w', encoding='utf-8') as f:
            json.dump(credentials, f, indent=2)

        # Set file permissions to 600 (owner read/write only)
        # On Windows, this might not work exactly the same, but we try anyway
        try:
            CREDENTIALS_FILE.chmod(stat.S_IRUSR | stat.S_IWUSR)
        except OSError:
            # On Windows, chmod might not work as expected, but file is still secure
            # since it's in user's home directory
            pass

        return True
    except Exception as e:
        console.print(f"[red]Error saving credentials: {e}[/red]")
        return False


def get_credentials() -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """Get stored credentials (token, username, email)."""
    creds = load_credentials()
    return (
        creds.get('token'),
        creds.get('username'),
        creds.get('email')
    )


def validate_credentials_ss(token: str, username: str, email: str) -> Tuple[bool, str]:
    """
    Validate credentials against the SSO/web API.
    Returns (is_valid, error_message)
    """    
    from promptx.config import PROMPTS_API_URL

    if not PROMPTS_API_URL:
        # If no API URL configured, skip validation
        return True, ""

    try:
        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }

        # Try to access a protected endpoint to validate token
        # This assumes there's an endpoint that requires authentication
        validation_url = f"{PROMPTS_API_URL.rstrip('/')}/auth/validate"

        payload = {
            'username': username,
            'email': email
        }

        response = requests.post(validation_url, json=payload, headers=headers, timeout=10)

        if response.status_code == 200:
            return True, ""
        elif response.status_code == 401:
            return False, "Invalid or expired token"
        elif response.status_code == 403:
            return False, "Access denied - check your permissions"
        else:
            # If the validation endpoint doesn't exist, assume token is valid
            # This provides backward compatibility
            return True, f"Warning: Could not validate token (API returned {response.status_code})"

    except requests.RequestException as e:
        # If we can't reach the API, assume credentials are valid
        # This allows the CLI to work even if the API is down
        console.print(f"[yellow]Warning: Could not validate credentials with API: {e}[/yellow]")
        console.print("[yellow]Proceeding with stored credentials...[/yellow]")
        return True, ""


def login_interactive() -> bool:
    """Interactive login flow to collect and validate credentials."""
    console.print("\n[bold] PromptX Login[/bold]")
    console.print("Connect your account to enable publishing and collaboration.\n")

    # Get current credentials
    current_token, current_username, current_email = get_credentials()

    # Collect credentials
    console.print("Please provide your credentials:")

    # Token - loop until valid
    token = None
    while not token:
        if current_token:
            console.print(f"Current token: {'*' * 20}...{current_token[-4:] if current_token else 'None'}")
            if not Confirm.ask("Update token?", default=False):
                token = current_token
                break
            else:
                token_input = Prompt.ask("Bitbucket HTTP token", password=True)
        else:
            token_input = Prompt.ask("Bitbucket HTTP token", password=True)

        token = token_input.strip()
        if not token:
            console.print("[red]✗ Token is required. Please try again.[/red]\n")

    # Username - loop until valid
    username = None
    while not username:
        if current_username:
            username_input = Prompt.ask("Username", default=current_username)
        else:
            username_input = Prompt.ask("Username (e.g., john.doe or sa-ai-promptlibwebui)")

        username = username_input.strip()
        if not username:
            console.print("[red]✗ Username is required. Please try again.[/red]\n")

    # Email - loop until valid
    email = None
    while not email:
        if current_email:
            email_input = Prompt.ask("Email (e.g., firstname.lastname@cambio.lk)", default=current_email)
        else:
            email_input = Prompt.ask("Email (e.g., firstname.lastname@cambio.lk)")

        email = email_input.strip()
        if not email:
            console.print("[red]✗ Email is required. Please try again.[/red]\n")
            continue

        # Validate email format
        if '@' not in email:
            console.print("[red]✗ Invalid email format. Please enter a valid email address.[/red]\n")
            email = None
            continue
        
        # Split and validate parts
        parts = email.split('@')
        if len(parts) != 2:
            console.print("[red]✗ Invalid email format.[/red]\n")
            email = None
            continue
        
        username_part, domain_part = parts
        
        # Check username format: must contain a dot (firstname.lastname)
        if '.' not in username_part:
            console.print("[red]✗ Email must be in format: firstname.lastname@cambio.lk[/red]\n")
            email = None
            continue

        # Check domain has a dot
        if '.' not in domain_part:
            console.print("[red]✗ Invalid email format.[/red]\n")
            email = None
            continue

        # Validate email domain (must be @cambio.lk only)
        email_domain = domain_part.lower()
        if email_domain != 'cambio.lk':
            console.print("[red]✗ Invalid email domain. Must be @cambio.lk[/red]")
            console.print(f"[yellow]Example: {username}@cambio.lk[/yellow]\n")
            email = None  # Reset to ask again

    # Validate credentials with SSO
    console.print("\n[cyan]Validating credentials...[/cyan]")
    is_valid, error_msg = validate_credentials_ss(token, username, email)

    if not is_valid:
        console.print(f"[red]✗ Authentication failed: {error_msg}[/red]")
        if "expired" in error_msg.lower():
            console.print("[yellow]💡 Your token may have expired. Please generate a new one in Bitbucket.[/yellow]")
        return False

    # Save credentials
    credentials = {
        'token': token,
        'username': username,
        'email': email,
        'created_at': __import__('datetime').datetime.now().isoformat()
    }

    if save_credentials(credentials):
        console.print("[green]✓ Successfully logged in![/green]")
        console.print(f"  Username: {username}")
        console.print(f"  Email: {email}")
        console.print(f"  Credentials saved to: {CREDENTIALS_FILE}")
        return True
    else:
        console.print("[red]✗ Failed to save credentials[/red]")
        return False


def logout() -> bool:
    """Remove stored credentials."""
    if CREDENTIALS_FILE.exists():
        try:
            CREDENTIALS_FILE.unlink()
            console.print("[green]✓ Successfully logged out[/green]")
            return True
        except Exception as e:
            console.print(f"[red]Error during logout: {e}[/red]")
            return False
    else:
        console.print("[yellow]No credentials found to remove[/yellow]")
        return True


def is_logged_in() -> bool:
    """Check if user has valid stored credentials."""
    token, username, email = get_credentials()
    return bool(token and username and email)


def get_token_with_fallback() -> Optional[str]:
    """
    Get token from stored credentials, with fallback for expired tokens.
    Returns token if valid, None if user needs to login again.
    """
    token, username, email = get_credentials()

    if not token:
        # Fallback to old BITBUCKET_HTTP_TOKEN environment variable for backward compatibility
        old_token = os.getenv('BITBUCKET_HTTP_TOKEN')
        if old_token:
            console.print("[yellow]Using BITBUCKET_HTTP_TOKEN from environment (consider using 'promptx login' for better security)[/yellow]")
            return old_token.strip()

        console.print("[yellow]No stored credentials found. Please run 'promptx login' or set BITBUCKET_HTTP_TOKEN environment variable.[/yellow]")
        return None

    # Validate token is still good
    is_valid, error_msg = validate_credentials_ss(token, username, email)

    if not is_valid:
        console.print(f"[red]✗ Stored credentials are invalid: {error_msg}[/red]")
        if "expired" in error_msg.lower():
            console.print("[yellow]💡 Please run 'promptx login' to refresh your token.[/yellow]")
        return None

    return token


def get_user_info() -> Tuple[Optional[str], Optional[str]]:
    """Get stored username and email."""
    _, username, email = get_credentials()
    return username, email