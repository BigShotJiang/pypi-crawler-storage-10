import click
from pathlib import Path
import yaml
from rich.console import Console
from shutil import copy2

console = Console()

@click.command()
@click.argument('old_path', required=True, type=click.Path(exists=True))
def migrate(old_path):
    """Migrate an old prompt (metadata.yml + prompt.md) to new format (prompt.yaml)"""
    old = Path(old_path)
    # Accept metadata.yml or any .yml/.yaml file in the folder (legacy naming varies)
    prompt_md = old / 'prompt.md'
    candidates = list(old.glob('metadata.*')) + list(old.glob('*.yml')) + list(old.glob('*.yaml'))
    metadata = None
    for c in candidates:
        if c.name.lower().startswith('metadata') or c.suffix.lower() in ('.yml', '.yaml'):
            metadata = c
            break

    if metadata is None or not metadata.exists():
        console.print('[red]No metadata .yml/.yaml file found in provided path[/red]')
        raise click.Abort()

    # Read old metadata
    with open(metadata, 'r', encoding='utf-8') as f:
        old_data = yaml.safe_load(f) or {}

    # If prompt.md is missing, create a placeholder from title/description
    if not prompt_md.exists():
        console.print('[yellow]prompt.md not found — creating placeholder from metadata[/yellow]')
        title = old_data.get('title') or old_data.get('metadata', {}).get('title') or old.name
        desc = old_data.get('description') or old_data.get('metadata', {}).get('description', '')
        placeholder = f"# {title}\n\n{desc}\n"
        with open(old / 'prompt.md', 'w', encoding='utf-8') as f:
            f.write(placeholder)
        prompt_md = old / 'prompt.md'

    # old_data is already loaded above

    # Construct new prompt.yaml by mapping legacy metadata where possible
    meta = old_data.get('metadata', old_data)
    new = {}
    # name: use use_case or slugified title or folder name
    title = meta.get('title') or meta.get('use_case') or old.name
    slug_name = title.lower().strip().replace(' ', '-').replace('_', '-')
    new['name'] = slug_name
    new['version'] = str(meta.get('version') or old_data.get('version') or '1.0.0')

    # author: prefer metadata.author.email, else author string
    auth = meta.get('author')
    if isinstance(auth, dict):
        new['author'] = auth.get('email') or auth.get('name') or ''
    else:
        new['author'] = auth or ''

    # owner_team: prefer metadata.owner.name/email, else fallback to author
    owner = meta.get('owner')
    if isinstance(owner, dict):
        new['owner_team'] = owner.get('name') or owner.get('team') or owner.get('email') or ''
    else:
        new['owner_team'] = ''

    new['created_date'] = meta.get('created_date') or old_data.get('created_date', '')
    # set last_modified to now if not provided
    from datetime import datetime

    new['last_modified'] = meta.get('last_modified') or datetime.utcnow().isoformat()
    new['description'] = meta.get('description') or ''

    # Category/subcategory mapping: normalize known roles
    role = (meta.get('role') or meta.get('primary_category') or meta.get('category') or '').lower()
    known_cats = ['developers', 'managers', 'business-analysts', 'quality-assurance']
    if role in known_cats:
        new['category'] = role
        new['subcategory'] = meta.get('use_case') or meta.get('category') or ''
    else:
        # if role looks like a human-readable string, map to 'other' and keep as subcategory
        new['category'] = 'other'
        new['subcategory'] = meta.get('category') or meta.get('use_case') or role

    # tags: normalize lowercased
    tags = meta.get('tags') or []
    new['tags'] = [str(t).lower() for t in tags]

    new['requires_review'] = meta.get('requires_review', True)
    new['approved_by'] = meta.get('approved_by', [])
    new['model_compatibility'] = meta.get('model_compatibility', [])
    new['expected_tokens'] = meta.get('expected_tokens', 2000)
    new['prompt_file'] = 'prompt.md'
    new['examples_dir'] = 'examples/'
    new['test_cases'] = 'tests/'

    # Backup old metadata file
    backup_meta = metadata.with_suffix(metadata.suffix + '.bak')
    copy2(metadata, backup_meta)
    console.print(f'Backed up {metadata.name} to {backup_meta}')

    # Write new prompt.yaml
    new_yaml = old / 'prompt.yaml'
    with open(new_yaml, 'w', encoding='utf-8') as f:
        yaml.dump(new, f, sort_keys=False)

    # Do not create examples/ or tests/ automatically

    console.print('[green]Migration complete. Created prompt.yaml and backups.[/green]')
