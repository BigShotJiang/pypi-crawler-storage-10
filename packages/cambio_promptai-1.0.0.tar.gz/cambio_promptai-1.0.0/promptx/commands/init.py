import datetime
import json
import os
import subprocess
import yaml
from pathlib import Path
from rich.console import Console
from rich.prompt import Prompt, Confirm
from promptx import __version__
from promptx.utils import safe_write_file, ensure_dir, locate_prompt_files
from promptx.tag_generator import generate_tags
from promptx.prompts_reader import get_existing_roles, get_existing_categories

console = Console()

# Draft storage
DRAFTS_DIR = Path('.drafts')


def slugify(s: str) -> str:
    """Convert string to lowercase-hyphenated slug"""
    import re
    s = (s or '').lower().strip()
    s = re.sub(r"[\s_]+", "-", s)
    s = re.sub(r"[^a-z0-9-]", "", s)
    s = re.sub(r"-+", "-", s)
    return s.strip('-')


def git_config(key: str):
    """Get git config value"""
    try:
        v = subprocess.check_output(["git", "config", "--get", key], stderr=subprocess.DEVNULL)
        return v.decode('utf-8').strip()
    except Exception:
        return ""


def validate_email(email: str) -> tuple[bool, str]:
    """
    Validate email format and domain.
    Must be in format: firstname.lastname@cambio.lk
    Returns (is_valid, error_message)
    """
    if not email:
        return False, "Email is required"
    
    # Check basic format
    if '@' not in email:
        return False, "Invalid email format"
    
    # Split and validate parts
    parts = email.split('@')
    if len(parts) != 2:
        return False, "Invalid email format"
    
    username_part, domain_part = parts
    
    # Check username part exists
    if not username_part.strip():
        return False, "Email must have a username before @"
    
    # Check username format: must contain a dot (firstname.lastname)
    if '.' not in username_part:
        return False, "Email must be in format: firstname.lastname@cambio.lk"
    
    # Check domain has a dot
    if '.' not in domain_part:
        return False, "Invalid email format"
    
    # Check domain (must be @cambio.lk)
    email_domain = domain_part.lower()
    if email_domain != 'cambio.lk':
        return False, "Email must be @cambio.lk domain"
    
    return True, ""


def prompt_for_email(prompt_text: str, default: str = "") -> str:
    """
    Prompt for email with validation loop.
    Keeps asking until a valid firstname.lastname@cambio.lk email is provided.
    """
    while True:
        email = Prompt.ask(prompt_text, default=default).strip()
        
        is_valid, error_msg = validate_email(email)
        if is_valid:
            return email
        
        console.print(f"[red]✗ {error_msg}[/red]")
        console.print("[yellow]Example: firstname.lastname@cambio.lk[/yellow]\n")


# prompts are read via promptx.prompts_reader which supports API or repo path configuration


def list_drafts():
    """List all draft prompts"""
    if not DRAFTS_DIR.exists():
        return []
    drafts = []
    for item in DRAFTS_DIR.iterdir():
        if item.is_dir():
            draft_file = item / 'draft.json'
            if draft_file.exists():
                try:
                    with open(draft_file, 'r', encoding='utf-8') as f:
                        draft_data = json.load(f)
                    drafts.append((item.name, draft_data))
                except Exception:
                    continue
    return drafts


def save_draft(draft_data):
    """Save draft prompt"""
    ensure_dir(DRAFTS_DIR)
    draft_name = draft_data.get('name_slug', 'untitled')
    draft_dir = DRAFTS_DIR / draft_name
    ensure_dir(draft_dir)
    # Save draft metadata
    draft_file = draft_dir / 'draft.json'
    with open(draft_file, 'w', encoding='utf-8') as f:
        json.dump(draft_data, f, indent=2)
    # Save markdown preview
    md_file = draft_dir / f'{draft_name}.md'
    md_content = generate_markdown(draft_data)
    safe_write_file(md_file, md_content)
    console.print(f'\n[green]✓ Draft saved: {draft_dir}[/green]')
    return draft_dir


def generate_yaml(draft_data):
    """Generate YAML metadata from draft data"""
    author_name = draft_data.get('author_name', '')
    author_email = draft_data.get('author_email', '')
    # Derive description from first 2 lines of task
    description = _derive_description_from_task(draft_data.get('task', ''))
    yaml_data = {
        'metadata': {
            'title': draft_data.get('name', ''),
            'description': description,
            'author': {
                'name': author_name,
                'email': author_email
            },
            'created_date': datetime.date.today().isoformat(),
            'role': draft_data.get('role', ''),
            'primary_category': draft_data.get('role', ''),
            'category': draft_data.get('category', ''),
            'use_case': draft_data.get('name_slug', ''),
            'mode': 'ask',
            'tags': draft_data.get('tags', []),
            'jira_ticket': draft_data.get('jira_ticket', ''),
        },
        'ai_compatibility': {
            'recommended_model': 'gpt-4',
            'tested_models': ['gpt-4', 'gpt-3.5-turbo'],
            'temperature': 0.7,
            'max_tokens': 2000,
            'context_requirements': 'moderate'
        }
    }
    return yaml.dump(yaml_data, default_flow_style=False, sort_keys=False)


def _derive_description_from_task(task_text):
    """Derive description from first 2 lines of task - matches Flask backend"""
    try:
        task = (task_text or '').strip()
        if not task:
            return ''
        # Take first 2 non-empty lines
        lines = []
        for line in task.splitlines():
            l = line.strip()
            if l:
                lines.append(l)
                if len(lines) == 2:
                    break
        if not lines:
            return ''
        result = ' '.join(lines)
        return result if len(result) <= 200 else result[:197] + '...'
    except Exception:
        return ''


def generate_markdown(draft_data):
    """Generate Markdown content from draft data - matches Flask backend"""
    system_role = draft_data.get('system_role', '').strip()
    task = draft_data.get('task', '').strip()
    name = draft_data.get('name', 'Untitled Prompt')
    role = draft_data.get('role', 'N/A')
    category = draft_data.get('category', 'N/A')
    tags = draft_data.get('tags', [])
    # Derive description from task
    description = _derive_description_from_task(task) or 'No description provided'
    md_content = f"# {name}\n\n"
    md_content += f"**Description:** {description}\n\n"
    md_content += f"**Role:** {role}\n\n"
    md_content += f"**Category:** {category}\n\n"
    md_content += f"**Mode:** ask\n\n"
    if tags:
        md_content += f"**Tags:** {', '.join(tags)}\n\n"
    md_content += "---\n\n"
    # Add FULL system role content (not just a line)
    if system_role:
        md_content += "## System Role\n\n" + system_role + "\n\n"
    # Add FULL task description content (not just a line)
    if task:
        md_content += "## Task Description\n\n" + task + "\n\n"
    if not system_role and not task:
        md_content += "## Prompt Content\n\n*Please add your prompt content here.*\n\n"
    # Keep separator but do NOT append metadata at bottom
    md_content += "---\n\n"
    return md_content


def edit_draft(draft_name=None):
    """Edit an existing draft prompt"""
    # List available drafts
    drafts = list_drafts()
    if not drafts:
        console.print('\n[yellow]No drafts found in .drafts/ folder[/yellow]')
        console.print('[cyan]Create a draft first using: promptx init[/cyan]\n')
        return
    
    # If no draft name provided, let user select
    if not draft_name:
        console.print("\n[bold]Select draft to edit:[/bold]\n")
        for i, (name, data) in enumerate(drafts, 1):
            tested = "✓ tested" if data.get('tested') else "⚠ not tested"
            console.print(f"{i}. {name} - {data.get('name', 'Untitled')} [{tested}]")
        
        choice = Prompt.ask("\nSelect draft number", choices=[str(i) for i in range(1, len(drafts)+1)])
        draft_name, draft_data = drafts[int(choice)-1]
    else:
        # Find draft by name
        matching = [d for d in drafts if d[0] == draft_name]
        if not matching:
            console.print(f'\n[red]Draft not found: {draft_name}[/red]')
            console.print('[cyan]Available drafts:[/cyan]')
            for name, _ in drafts:
                console.print(f'  - {name}')
            return
        draft_name, draft_data = matching[0]
    
    console.print(f"\n[bold]Editing draft: [cyan]{draft_data.get('name', draft_name)}[/cyan][/bold]\n")
    
    # Get current values
    current_name = draft_data.get('name', '')
    current_role = draft_data.get('role', '')
    current_category = draft_data.get('category', '')
    current_tags = draft_data.get('tags', [])
    current_author_name = draft_data.get('author_name', '')
    current_author_email = draft_data.get('author_email', '')
    current_system_role = draft_data.get('system_role', '')
    current_task = draft_data.get('task', '')
    current_jira = draft_data.get('jira_ticket', '')
    
    # Edit fields
    console.print("[yellow]Press Enter to keep current value, or type new value:[/yellow]\n")
    
    # Name
    name = Prompt.ask("Prompt name/title", default=current_name)
    if name and name != current_name:
        draft_data['name'] = name
        draft_data['name_slug'] = slugify(name)
    
    # Role
    role = Prompt.ask("Role/category", default=current_role)
    if role and role != current_role:
        draft_data['role'] = role
    
    # Category
    category = Prompt.ask("Category/subcategory", default=current_category)
    if category and category != current_category:
        draft_data['category'] = category
    
    # Tags
    current_tags_str = ', '.join(current_tags) if current_tags else ''
    tags_input = Prompt.ask("Tags (comma-separated)", default=current_tags_str)
    if tags_input != current_tags_str:
        new_tags = [t.strip() for t in tags_input.split(',') if t.strip()]
        draft_data['tags'] = new_tags
    
    # Author info
    author_name = Prompt.ask("Author name", default=current_author_name)
    if author_name != current_author_name:
        draft_data['author_name'] = author_name
    
    # Email with validation
    author_email = prompt_for_email("Author email", default=current_author_email)
    if author_email != current_author_email:
        draft_data['author_email'] = author_email
    
    # System role
    console.print(f"\nCurrent system role ({len(current_system_role)} chars):")
    console.print(f"[dim]{current_system_role[:100]}{'...' if len(current_system_role) > 100 else ''}[/dim]")
    system_role = Prompt.ask("System role / persona", default=current_system_role)
    if system_role != current_system_role:
        draft_data['system_role'] = system_role
    
    # Task
    console.print(f"\nCurrent task ({len(current_task)} chars):")
    console.print(f"[dim]{current_task[:100]}{'...' if len(current_task) > 100 else ''}[/dim]")
    task = Prompt.ask("Task description/objective", default=current_task)
    if task != current_task:
        draft_data['task'] = task
    
    # Jira ticket
    jira_ticket = Prompt.ask("Jira ticket ID", default=current_jira)
    if jira_ticket != current_jira:
        draft_data['jira_ticket'] = jira_ticket
    
    # Reset tested status since draft was modified
    draft_data['tested'] = False
    draft_data['updated_at'] = datetime.datetime.now().isoformat()
    
    # Save updated draft
    draft_dir = DRAFTS_DIR / draft_name
    draft_file = draft_dir / 'draft.json'
    with open(draft_file, 'w', encoding='utf-8') as f:
        json.dump(draft_data, f, indent=2)
    
    # Regenerate markdown preview
    md_file = draft_dir / f'{draft_name}.md'
    md_content = generate_markdown(draft_data)
    safe_write_file(md_file, md_content)
    
    console.print('\n[green]✓ Draft updated successfully![/green]')
    console.print('[yellow]⚠ Draft marked as untested (re-test before publishing)[/yellow]')
    console.print(f'[dim]Draft location: {draft_dir}[/dim]\n')


def publish_draft(draft_name):
    """Publish a tested draft (local or Bitbucket). Ask whether to remove draft after success."""
    
    # List available drafts
    drafts = list_drafts()
    if not drafts:
        console.print('\n[yellow]No drafts found in .drafts/ folder[/yellow]')
        console.print('[cyan]Create a draft first using: promptx init[/cyan]\n')
        return False
    
    # If no draft name provided, let user select
    if not draft_name:
        tested_drafts = [(n, d) for n, d in drafts if d.get('tested')]
        if not tested_drafts:
            console.print('\n[yellow]No tested drafts ready for publishing[/yellow]')
            console.print('[cyan]Test a draft first using: promptx test[/cyan]\n')
            return False
        
        console.print("\n[bold]Available tested drafts to publish:[/bold]\n")
        for i, (name, data) in enumerate(tested_drafts, 1):
            console.print(f"{i}. {name} - {data.get('name', 'Untitled')}")
        
        choice = Prompt.ask("\nSelect draft number", choices=[str(i) for i in range(1, len(tested_drafts)+1)])
        draft_name, draft_data = tested_drafts[int(choice)-1]
    else:
        # Find draft by name
        matching = [d for d in drafts if d[0] == draft_name]
        if not matching:
            console.print(f'\n[red]Draft not found: {draft_name}[/red]')
            console.print('[cyan]Available drafts:[/cyan]')
            for name, _ in drafts:
                console.print(f'  - {name}')
            return False
        draft_name, draft_data = matching[0]
    
    # Now proceed with publishing the selected draft
    draft_dir = DRAFTS_DIR / draft_name
    draft_file = draft_dir / 'draft.json'
    with open(draft_file, 'r', encoding='utf-8') as f:
        draft_data = json.load(f)
    
    if not draft_data.get('tested'):
        console.print('[red]✗ Draft must be tested before publishing![/red]')
        console.print('[yellow]Run "Test draft" first.[/yellow]')
        return False
    
    console.print(f'\n[cyan]Publishing draft: {draft_name}[/cyan]\n')
    console.print("[bold]Choose publish method:[/bold]")
    console.print("1. Local files only (create files in prompts/ folder)")
    console.print("2. Full Bitbucket workflow (clone, branch, push, create PR)")
    method = Prompt.ask("Select method", choices=["1", "2"], default="1")
    if method == "2":
        from promptx.bitbucket import BitbucketWorkflow
        console.print("\n[yellow]⚠️  This will:[/yellow]")
        console.print("  - Clone the repository")
        console.print("  - Create a new branch")
        console.print("  - Create YAML and MD files")
        console.print("  - Commit and push to remote")
        console.print("  - Create a Pull Request")
        confirm = Prompt.ask("\n[yellow]Proceed with Bitbucket publish?[/yellow]", choices=["yes", "no"], default="no")
        if confirm != "yes":
            console.print("[cyan]Publish cancelled[/cyan]")
            return False
        # Prepare data
        prompt_data = {
            'name': draft_data.get('name', ''),
            'role': draft_data.get('role', ''),
            'category': draft_data.get('category', ''),
            'tags': draft_data.get('tags', []),
            'author_name': draft_data.get('author_name', ''),
            'author_email': draft_data.get('author_email', ''),
            'system_role': draft_data.get('system_role', ''),
            'task_description': draft_data.get('task', ''),
            'jira_ticket': draft_data.get('jira_ticket', ''),
            'mode': 'ask'
        }
        workflow = BitbucketWorkflow()
        success, message = workflow.create_prompt_workflow(prompt_data)
        if success:
            console.print(f"\n[green]✓ {message}[/green]")
            # Ask whether to remove draft
            if Confirm.ask("Remove draft from .drafts/?", default=False):
                import shutil
                shutil.rmtree(draft_dir)
                console.print(f"[cyan]Draft removed: {draft_dir}[/cyan]")
            else:
                console.print(f"[yellow]Draft kept in {draft_dir}[/yellow]")
            return True
        else:
            console.print(f"\n[red]✗ {message}[/red]")
            return False
    else:
        role = draft_data.get('role', 'general')
        category = draft_data.get('category', 'general')
        name_slug = draft_data.get('name_slug', draft_name)
        prompt_path = Path('prompts') / role / category / name_slug
        ensure_dir(prompt_path)
        yaml_content = generate_yaml(draft_data)
        yaml_file = prompt_path / f'{name_slug}.yml'
        safe_write_file(yaml_file, yaml_content)
        md_content = generate_markdown(draft_data)
        md_file = prompt_path / f'{name_slug}.md'
        safe_write_file(md_file, md_content)
        console.print(f'[green]✓ Files created:[/green]')
        console.print(f'  {yaml_file}')
        console.print(f'  {md_file}')
        console.print('\n[green]✓ Draft published locally![/green]')
        console.print(f'[yellow]Next step: Commit and push to repository manually[/yellow]')
        if Confirm.ask("Remove draft from .drafts/?", default=False):
            import shutil
            shutil.rmtree(draft_dir)
            console.print(f"[cyan]Draft removed: {draft_dir}[/cyan]")
        else:
            console.print(f"[yellow]Draft kept in {draft_dir}[/yellow]")
        return True


def create_new_draft():
    """Create new draft flow extracted so menu stays active."""
    console.print("\n[bold] Create New Prompt Draft[/bold]\n")
    
    # Step 1: Get and select ROLE (people/teams only)
    roles = get_existing_roles()
    console.print('\n Select role (team/persona):')
    if roles:
        for i, r in enumerate(roles, 1):
            console.print(f"  {i}. {r}")
        console.print(f"  {len(roles)+1}. [other] enter custom role")
        choice = Prompt.ask("Select option", choices=[str(i) for i in range(1, len(roles) + 2)])
        if choice == str(len(roles)+1):
            role = Prompt.ask("Enter custom role name")
        else:
            role = roles[int(choice)-1]
    else:
        role = Prompt.ask("Enter role/category name")
    
    while not role.strip():
        console.print('[red]Role is required.[/red]')
        role = Prompt.ask("Enter role/category name")
    
    # Step 2: Get and select CATEGORY (with use-case display) for this role
    categories = get_existing_categories(role=role)  # Returns list of tuples: (category, usecase, display)
    
    console.print(f'\n Select category for {role}:')
    if categories:
        for i, (cat, uc, display) in enumerate(categories, 1):
            console.print(f"  {i}. {display}")
        console.print(f"  {len(categories)+1}. [new] create new")
        
        cat_choice = Prompt.ask("Select option", choices=[str(i) for i in range(1, len(categories) + 2)])
        if cat_choice == str(len(categories)+1):
            # User wants to create new
            subcategory = Prompt.ask("Enter category name (e.g., 'code-generation')")
            use_case_part = ""  # New category, no use-case yet
        else:
            # User selected existing
            selected_cat, selected_uc, _ = categories[int(cat_choice)-1]
            subcategory = selected_cat
            use_case_part = selected_uc
    else:
        # No existing categories, prompt for new
        console.print('[yellow]No existing categories found. Creating new...[/yellow]')
        subcategory = Prompt.ask("Enter category name (e.g., 'code-generation')")
        use_case_part = ""
    
    while not subcategory.strip():
        console.print('[red]Category is required.[/red]')
        subcategory = Prompt.ask("Enter category name")
    
    # Step 3: Prompt name (title)
    if use_case_part:
        # prefill name with human-readable version of selected use-case
        suggested_name = use_case_part.replace('-', ' ').replace('_', ' ').title()
        name = Prompt.ask(" Prompt name/title", default=suggested_name)
    else:
        name = Prompt.ask(" Prompt name/title (e.g. 'Backend Development Helper')")
    
    while not name.strip():
        console.print('[red]Name is required.[/red]')
        name = Prompt.ask("Prompt name/title (required)")
    
    # Determine slug: if user selected use_case use it; otherwise slugify name
    if use_case_part:
        name_slug = slugify(use_case_part)
    else:
        name_slug = slugify(name)
    while not name_slug:
        console.print('[red]Name must contain at least one letter or number.[/red]')
        name = Prompt.ask("Prompt name/title")
        name_slug = slugify(name)
    # Auto-generate tags
    auto_tags = generate_tags(role, subcategory)
    console.print(f"\n Auto-generated tags: {auto_tags}")
    additional = Prompt.ask("Add more tags (comma-separated) or press Enter", default="")
    additional_tags = [t.strip() for t in additional.split(",") if t.strip()]
    tags = list(dict.fromkeys(auto_tags + additional_tags))
    
    # Author info - prioritize logged-in user, fallback to git config
    from promptx.auth import get_user_info, is_logged_in
    
    # Try to get from global login first
    logged_in_username, logged_in_email = None, None
    if is_logged_in():
        logged_in_username, logged_in_email = get_user_info()
    
    # Fallback to git config
    git_name = git_config('user.name')
    git_email = git_config('user.email')
    
    # Prefer logged-in credentials over git
    default_name = logged_in_username or git_name or ""
    default_email = logged_in_email or git_email or ""
    
    if logged_in_username:
        console.print(f"[dim]Using logged-in user: {logged_in_username}[/dim]")
    
    author_name = Prompt.ask(" Author name", default=default_name)
    
    # Email with validation
    author_email = prompt_for_email("Author email", default=default_email)
    # Required fields
    system_role = Prompt.ask(" System role / persona (required, e.g. 'You are an expert ...')")
    while not system_role.strip():
        console.print('[red]System role is required.[/red]')
        system_role = Prompt.ask("System role (required)")
    task = Prompt.ask(" Task description/objective (required)")
    while not task.strip():
        console.print('[red]Task description is required.[/red]')
        task = Prompt.ask("Task description (required)")
    jira_ticket = Prompt.ask(" Jira ticket ID (required)")
    while not jira_ticket.strip():
        console.print('[red]Jira ticket ID is required for traceability.[/red]')
        jira_ticket = Prompt.ask("Jira ticket ID (required)")
    # Build draft data
    draft_data = {
        'name': name,
        'name_slug': name_slug,
        'role': role,
        'category': subcategory,
        'tags': tags,
        'author_name': author_name,
        'author_email': author_email,
        'system_role': system_role,
        'task': task,
        'jira_ticket': jira_ticket,
        'created_at': datetime.datetime.now().isoformat(),
        'tested': False
    }
    # Save draft
    draft_dir = save_draft(draft_data)
    console.print('\n[yellow]\u26a0\ufe0f  Draft created but NOT yet published![/yellow]')
    console.print('[cyan]Next steps:[/cyan]')
    console.print('  1. Edit the draft (option 3 from menu)')
    console.print('  2. Test the draft (option 4 from menu)')
    console.print('  3. Publish the draft (option 5 from menu)')
    console.print(f'\n[dim]Draft location: {draft_dir}[/dim]')


def init_interactive():
    """Interactive prompt creation with test-then-publish workflow"""
    from pathlib import Path as PathLib
    from promptx.commands.browse import get_prompts
    from promptx.utils import locate_prompt_files

    while True:
        console.print("\n[bold] Prompt Library - Create & Manage[/bold]")
        console.print("=" * 50)
        console.print("\nWhat would you like to do?\n")
        console.print("Select action")
        console.print("-" * 13)
        options = [
            "1. Create new prompt draft",
            "2. List prompt drafts",
            "3. Edit draft prompt",
            "4. Test prompt draft",
            "5. Publish prompt draft",
            "6. List published prompts",
            "7. Edit existing prompt",
            "8. Quit"
        ]
        for o in options:
            console.print(f"{o}")
        menu_choice = Prompt.ask("\nSelect option [1-8] or press Enter for default", choices=[str(i) for i in range(1,9)], default="1")
        if menu_choice == "8":
            console.print("\n[cyan]Goodbye! [/cyan]\n")
            return
        if menu_choice == "1":
            create_new_draft()
            continue
        if menu_choice == "2":
            drafts = list_drafts()
            if not drafts:
                console.print('\n[yellow]No drafts found[/yellow]')
            else:
                console.print("\n[bold]Drafts:[/bold]")
                for i, (name, data) in enumerate(drafts, 1):
                    tested = "✓ tested" if data.get('tested') else "⚠ not tested"
                    console.print(f"{i}. {name} - {data.get('name', 'Untitled')} [{tested}]")
            continue
        if menu_choice == "3":
            drafts = list_drafts()
            if not drafts:
                console.print('\n[yellow]No drafts to edit[/yellow]')
                continue
            console.print("\n[bold]Select draft to edit:[/bold]")
            for i, (name, data) in enumerate(drafts, 1):
                console.print(f"{i}. {name} - {data.get('name', 'Untitled')}")
            choice = Prompt.ask("Select draft number", choices=[str(i) for i in range(1, len(drafts)+1)])
            draft_name = drafts[int(choice)-1][0]
            edit_draft(draft_name)
            continue
        if menu_choice == "4":
            drafts = list_drafts()
            if not drafts:
                console.print('\n[yellow]No drafts to test[/yellow]')
                continue
            console.print("\n[bold]Select draft to test:[/bold]")
            for i, (name, data) in enumerate(drafts, 1):
                console.print(f"{i}. {name} - {data.get('name', 'Untitled')}")
            choice = Prompt.ask("Select draft number", choices=[str(i) for i in range(1, len(drafts)+1)])
            draft_name = drafts[int(choice)-1][0]
            test_draft(draft_name)
            continue
        if menu_choice == "5":
            drafts = list_drafts()
            if not drafts:
                console.print('\n[yellow]No drafts to publish[/yellow]')
                continue
            tested_drafts = [(n, d) for n, d in drafts if d.get('tested')]
            if not tested_drafts:
                console.print('\n[yellow]No tested drafts ready for publishing[/yellow]')
                console.print('[cyan]Test a draft first (option 4)[/cyan]')
                continue
            console.print("\n[bold]Select tested draft to publish:[/bold]")
            for i, (name, data) in enumerate(tested_drafts, 1):
                console.print(f"{i}. {name} - {data.get('name', 'Untitled')}")
            choice = Prompt.ask("Select draft number", choices=[str(i) for i in range(1, len(tested_drafts)+1)])
            draft_name = tested_drafts[int(choice)-1][0]
            publish_draft(draft_name)
            continue
        if menu_choice == "6":
            prompts = get_prompts()
            if not prompts:
                console.print('\n[yellow]No published prompts found[/yellow]')
            else:
                console.print("\n[bold]Published Prompts:[/bold]")
                for i, (rel, desc, full) in enumerate(prompts, 1):
                    console.print(f"{i}. {rel}")
            continue
        if menu_choice == "7":
            prompts = get_prompts()
            if not prompts:
                console.print('\n[yellow]No prompts found[/yellow]')
                continue
            console.print("")
            for i, (rel, desc, full) in enumerate(prompts, 1):
                console.print(f"{i}. {rel}")
            choice = Prompt.ask(f"Select prompt number to edit", choices=[str(i) for i in range(1, len(prompts)+1)])
            selected_path = prompts[int(choice)-1][2]
            # Check ownership
            yaml_file, md_file = locate_prompt_files(PathLib(selected_path))
            if yaml_file and yaml_file.exists():
                try:
                    with open(yaml_file, 'r', encoding='utf-8') as f:
                        data = yaml.safe_load(f) or {}
                    meta = data.get('metadata', data)
                    author = meta.get('author')
                    if isinstance(author, dict):
                        author_email = author.get('email') or author.get('name')
                    else:
                        author_email = author
                    git_email = git_config('user.email')
                    git_name = git_config('user.name')
                    if author_email and (author_email == git_email or author_email == git_name):
                        console.print(f"\n[green]✓ You are the owner. Opening {md_file} for editing...[/green]\n")
                        if os.name == 'nt':
                            os.startfile(str(md_file))
                        else:
                            subprocess.call(['open', str(md_file)])
                    else:
                        console.print(f"\n[red]✗ You are not the owner of this prompt (owner: {author_email}). You cannot edit it.[/red]\n")
                except Exception as e:
                    console.print(f"[red]Could not verify ownership: {e}[/red]")
            else:
                console.print(f"[red]Could not find prompt metadata file[/red]")
            continue
        # menu_choice == "1" - Create new draft
        break


def test_draft(draft_name):
    """Test a draft prompt - use same validation as CLI test command"""
    from rich.panel import Panel
    from ..commands.test import validate_draft_data
    
    # List available drafts
    drafts = list_drafts()
    if not drafts:
        console.print('\n[yellow]No drafts found in .drafts/ folder[/yellow]')
        console.print('[cyan]Create a draft first using: promptx init[/cyan]\n')
        return False
    
    # If no draft name provided, let user select
    if not draft_name:
        console.print("\n[bold]Available drafts to test:[/bold]\n")
        for i, (name, data) in enumerate(drafts, 1):
            tested = "✓ tested" if data.get('tested') else "⚠ not tested"
            console.print(f"{i}. {name} - {data.get('name', 'Untitled')} [{tested}]")
        
        choice = Prompt.ask("\nSelect draft number", choices=[str(i) for i in range(1, len(drafts)+1)])
        draft_name, draft_data = drafts[int(choice)-1]
    else:
        # Find draft by name
        matching = [d for d in drafts if d[0] == draft_name]
        if not matching:
            console.print(f'\n[red]Draft not found: {draft_name}[/red]')
            console.print('[cyan]Available drafts:[/cyan]')
            for name, _ in drafts:
                console.print(f'  - {name}')
            return False
        draft_name, draft_data = matching[0]
    
    console.print(Panel.fit(f"Running validation for: [cyan]{draft_data.get('name', draft_name)}[/cyan]", border_style="cyan"))
    
    # Get draft directory
    draft_dir = DRAFTS_DIR / draft_name
    
    # Use shared validation logic
    errors = validate_draft_data(draft_data, draft_name, draft_dir)
    
    if errors:
        console.print("\n[red]✗ Validation failed[/red]")
        console.print('[yellow]Fix the above issues and run test again[/yellow]\n')
        return False
    else:
        # Mark draft as tested
        draft_data['tested'] = True
        from datetime import datetime
        draft_data['tested_at'] = datetime.now().isoformat()
        
        draft_file = draft_dir / 'draft.json'
        with open(draft_file, 'w', encoding='utf-8') as f:
            json.dump(draft_data, f, indent=2)
        
        console.print("\n[green]✓ All checks passed![/green]")
        console.print('[cyan]Draft marked as tested. You can now publish it using:[/cyan]')
        console.print(f'[dim]  promptx init  →  select "5. Publish draft"[/dim]\n')
        return True
