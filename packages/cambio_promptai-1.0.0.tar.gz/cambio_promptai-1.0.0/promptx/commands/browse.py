import click
from rich.console import Console
from rich.table import Table
from pathlib import Path
import yaml
from promptx.prompts_reader import get_prompts_from_json

console = Console()

@click.command()
@click.argument('category', required=False)
def browse(category=None):
    """Browse available prompts under prompts/"""
    prompts = get_prompts(category)
    if not prompts:
        console.print('[yellow]No prompts found under prompts/[/yellow]')
        return

    table = Table(title='Available Prompts')
    table.add_column('Path')
    table.add_column('Description')
    for rel, desc, full in prompts:
        table.add_row(rel, desc)

    console.print(table)


def get_prompts(category=None):
    """Return list of (rel_path, description, full_path) for prompts from prompts.json"""
    prompts_list = get_prompts_from_json()
    if not prompts_list:
        console.print('[yellow]prompts.json not found via configured sources, falling back to directory scan[/yellow]')
        return _get_prompts_from_directory(category)

    try:
        results = []
        
        for prompt in prompts_list:
            # Filter by category if specified
            prompt_category = prompt.get('category', '')
            if category and prompt_category != category:
                continue
            
            # Get path components
            file_info = prompt.get('file_info', {})
            rel_path = file_info.get('relative_path', '')
            if not rel_path:
                continue
            
            # Build full path
            full_path = Path('prompts') / rel_path
            
            # Get description
            desc = prompt.get('description', '')
            
            results.append((rel_path, desc, full_path))
        
        return results
        
    except Exception as e:
        console.print(f'[yellow]Error reading prompts.json: {e}, falling back to directory scan[/yellow]')
        return _get_prompts_from_directory(category)


def _get_prompts_from_directory(category=None):
    """Fallback: scan prompts directory (handles 2-level and 3-level structures)"""
    prompts_dir = Path('prompts')
    if not prompts_dir.exists():
        return []

    from ..utils import locate_prompt_files
    results = []
    
    # Iterate through all subdirectories recursively
    for item in prompts_dir.rglob('*'):
        if not item.is_dir():
            continue
        
        # Check if this directory contains a prompt (has .yml file)
        yaml_file, md_file = locate_prompt_files(item)
        if yaml_file is None:
            continue
        
        # Get role (top-level folder)
        try:
            parts = item.relative_to(prompts_dir).parts
            if not parts:
                continue
            role = parts[0]
            
            # Filter by category if specified
            if category and role != category:
                continue
            
            # Get description from YAML
            desc = ''
            try:
                with open(yaml_file, 'r', encoding='utf-8') as f:
                    data = yaml.safe_load(f) or {}
                meta = data.get('metadata', data)
                desc = meta.get('description', '')
            except Exception:
                desc = ''
            
            rel = str(item.relative_to(prompts_dir))
            results.append((rel, desc, item))
        except Exception:
            continue
    
    return results
