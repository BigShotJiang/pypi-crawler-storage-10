import click
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from pathlib import Path
import yaml
import json
from ..validator import validate_prompt_yaml, sync_description_from_prompt
from ..tag_generator import regenerate_tags_if_needed

console = Console()
DRAFTS_DIR = Path('.drafts')


def validate_draft_data(draft_data, draft_name, prompt_dir):
    """Shared validation logic used by both CLI and interactive menu"""
    errors = []
    
    # Validate required fields in draft
    required = ['name', 'role', 'category', 'system_role', 'task', 'jira_ticket']
    missing = [f for f in required if not draft_data.get(f)]
    
    if missing:
        console.print(f'[red]✗ Missing required fields: {", ".join(missing)}[/red]')
        errors.extend(missing)
    else:
        console.print('[green]✓ All required fields present[/green]')
        console.print(f'  ✓ Name: {draft_data.get("name")}')
        console.print(f'  ✓ Role: {draft_data.get("role")}')
        console.print(f'  ✓ Category: {draft_data.get("category")}')
        console.print(f'  ✓ Jira: {draft_data.get("jira_ticket")}')
    
    # Validate content length
    system_role = draft_data.get('system_role', '')
    task = draft_data.get('task', '')
    
    if len(system_role) < 20:
        errors.append('system_role too short')
        console.print(f'[red]✗ System role too short ({len(system_role)} chars, need at least 20)[/red]')
    else:
        console.print(f'✓ System role: {len(system_role)} chars')
    
    if len(task) < 20:
        errors.append('task too short')
        console.print(f'[red]✗ Task description too short ({len(task)} chars, need at least 20)[/red]')
    else:
        console.print(f'✓ Task description: {len(task)} chars')
    
    # Check tags
    tags = draft_data.get('tags', [])
    if tags:
        console.print(f'✓ Tags: {", ".join(tags)}')
    else:
        console.print('[yellow]⚠ No tags set[/yellow]')
    
    # Check if markdown preview exists
    md_file = prompt_dir / f'{draft_name}.md'
    if md_file.exists():
        console.print(f'✓ Markdown preview exists: {md_file.name}')
    else:
        console.print('[yellow]⚠ Markdown preview not found (will be generated on publish)[/yellow]')
    
    return errors


def list_drafts():
    """List all draft prompts from .drafts/ folder"""
    if not DRAFTS_DIR.exists():
        return []
    drafts = []
    for item in DRAFTS_DIR.iterdir():
        if item.is_dir():
            draft_file = item / 'draft.json'
            if draft_file.exists():
                try:
                    with open(draft_file, 'r', encoding='utf-8') as f:
                        draft_data = json.load(f)
                    drafts.append((item.name, draft_data, item))
                except Exception:
                    continue
    return drafts

@click.command()
@click.argument('draft_name', required=False)
def test(draft_name):
    """Validate a draft prompt from .drafts/ folder before publishing"""
    
    # List available drafts
    drafts = list_drafts()
    if not drafts:
        console.print('\n[yellow]No drafts found in .drafts/ folder[/yellow]')
        console.print('[cyan]Create a draft first using: promptx init[/cyan]\n')
        return
    
    # If no draft name provided, let user select
    if not draft_name:
        console.print("\n[bold]Available drafts to test:[/bold]\n")
        for i, (name, data, path) in enumerate(drafts, 1):
            tested = "✓ tested" if data.get('tested') else "⚠ not tested"
            console.print(f"{i}. {name} - {data.get('name', 'Untitled')} [{tested}]")
        
        choice = Prompt.ask("\nSelect draft number", choices=[str(i) for i in range(1, len(drafts)+1)])
        draft_name, draft_data, prompt_dir = drafts[int(choice)-1]
    else:
        # Find draft by name
        matching = [d for d in drafts if d[0] == draft_name]
        if not matching:
            console.print(f'\n[red]Draft not found: {draft_name}[/red]')
            console.print('[cyan]Available drafts:[/cyan]')
            for name, _, _ in drafts:
                console.print(f'  - {name}')
            return
        draft_name, draft_data, prompt_dir = matching[0]
        draft_name, draft_data, prompt_dir = matching[0]
    
    console.print(Panel.fit(f"Running validation for: [cyan]{draft_data.get('name', draft_name)}[/cyan]", border_style="cyan"))
    
    # Load draft JSON
    draft_file = prompt_dir / 'draft.json'
    
    # Use shared validation logic
    errors = validate_draft_data(draft_data, draft_name, prompt_dir)
    
    if errors:
        console.print("\n[red]✗ Validation failed[/red]")
        console.print('[yellow]Fix the above issues and run test again[/yellow]\n')
        exit(1)
    else:
        # Mark draft as tested
        draft_data['tested'] = True
        from datetime import datetime
        draft_data['tested_at'] = datetime.now().isoformat()
        
        with open(draft_file, 'w', encoding='utf-8') as f:
            json.dump(draft_data, f, indent=2)
        
        console.print("\n[green]✓ All checks passed![/green]")
        console.print('[cyan]Draft marked as tested. You can now publish it using:[/cyan]')
        console.print(f'[dim]  promptx init  →  select "4. Publish draft"[/dim]\n')
