import click
from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel

from promptx.commands import init as init_cmd
from promptx.commands.test import test
from promptx.commands.browse import browse
# migrate command removed from CLI help
from promptx.auth import login_interactive, logout, is_logged_in, get_user_info
from promptx.config import ensure_env_file

console = Console()


@click.group(invoke_without_command=True)
@click.version_option(version="1.0.0")
@click.pass_context
def cli(ctx):
    """PromptX - SDK for managing enterprise AI prompts"""
    # Auto-create .env file if it doesn't exist (won't overwrite existing)
    created = ensure_env_file()
    if created:
        console.print("[green]✓[/green] Created .env file with default settings")
        console.print("[dim]Configure your credentials using 'promptx login'[/dim]\n")
    
    if ctx.invoked_subcommand is None:
        init_cmd.init_interactive()



if __name__ == "__main__":
    cli()

# Register subcommands for non-interactive usage
@cli.command(name='init')
def _init_cmd():
    """Show the main interactive menu with create"""
    init_cmd.init_interactive()
cli.add_command(test)
cli.add_command(browse)
# migrate command intentionally not registered to keep CLI help minimal


@cli.command(name='login')
def login():
    """Authenticate with CambioPromptAI and store credentials globally"""
    if login_interactive():
        console.print("\n[green]You can now use 'promptx publish' without re-entering credentials![/green]")
    else:
        console.print("\n[yellow]Login failed. Please try again.[/yellow]")


@cli.command(name='logout')
def logout_cmd():
    """Remove stored credentials"""
    if logout():
        console.print("[green]Successfully logged out[/green]")
    else:
        console.print("[red]Logout failed[/red]")


@cli.command(name='whoami')
def whoami():
    """Show current user information"""
    if is_logged_in():
        username, email = get_user_info()
        console.print(f"[green]Logged in as:[/green] {username} ({email})")
    else:
        console.print("[yellow]Not logged in. Run 'promptx login' to authenticate.[/yellow]")


@cli.command(name='publish')
@click.argument('draft_name', required=False)
def publish(draft_name):
    """Publish a tested draft to Bitbucket"""
    init_cmd.publish_draft(draft_name)



# Reorder the commands shown in --help to a user-friendly sequence.
# Desired order: browse, init, login, logout, publish, test
from collections import OrderedDict
desired_order = ['browse', 'init', 'login', 'logout', 'publish', 'test']
new_commands = OrderedDict()
for name in desired_order:
    if name in cli.commands:
        new_commands[name] = cli.commands[name]
# Append any other commands (e.g. whoami) to the end so they still exist
for name, cmd in list(cli.commands.items()):
    if name not in new_commands:
        new_commands[name] = cmd
cli.commands = new_commands


