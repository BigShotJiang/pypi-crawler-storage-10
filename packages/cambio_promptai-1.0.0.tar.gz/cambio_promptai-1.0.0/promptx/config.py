from dataclasses import dataclass
from pathlib import Path
import os
from dotenv import load_dotenv

# Load .env if present
_env_path = Path(__file__).parent.parent / '.env'
if _env_path.exists():
    load_dotenv(dotenv_path=str(_env_path))

def ensure_env_file():
    """
    Auto-create .env file with defaults if it doesn't exist.
    DOES NOT overwrite existing .env file.
    Returns True if file was created, False if it already existed.
    """
    env_file = Path(__file__).parent.parent / '.env'
    
    # Don't overwrite existing .env file
    if env_file.exists():
        return False
    
    # Create new .env with empty token/username placeholders
    default_content = """# Bitbucket Configuration (self-hosted)
BITBUCKET_SERVER=scm.devops.cambio.se
BITBUCKET_PROJECT=IAII
BITBUCKET_REPO=cambio_prompt_lib
BITBUCKET_HTTP_TOKEN=
BITBUCKET_USERNAME=
BITBUCKET_BRANCH=master


"""
    
    try:
        env_file.write_text(default_content, encoding='utf-8')
        return True
    except Exception as e:
        from rich.console import Console
        Console().print(f'[yellow]Warning: Could not create .env file: {e}[/yellow]')
        return False

def get_bitbucket_token():
    """
    Get Bitbucket token from environment or prompt user for it.
    Optionally saves the token to .env file.
    Returns the token or None if user cancelled/provided empty token.
    """
    # Reload .env to get latest values
    _env_path = Path(__file__).parent.parent / '.env'
    if _env_path.exists():
        load_dotenv(dotenv_path=str(_env_path), override=True)
    
    token = os.getenv('BITBUCKET_HTTP_TOKEN', '').strip()
    
    if token:
        return token
    
    # Token not found, prompt user
    from rich.console import Console
    from rich.prompt import Prompt, Confirm
    
    console = Console()
    console.print("\n[yellow]⚠️  Bitbucket token not found in .env file[/yellow]")
    console.print("You need a Bitbucket HTTP access token to publish prompts.")
    console.print("See BITBUCKET_SETUP.md for instructions on creating a token.\n")
    
    # Loop until we get valid credentials or user cancels
    while True:
        try:
            token = Prompt.ask("Enter your Bitbucket HTTP token (or press Ctrl+C to cancel)", password=True)
            token = token.strip()
            
            if not token:
                console.print("[red]✗[/red] Token cannot be empty.")
                retry = Confirm.ask("Try again?", default=True)
                if not retry:
                    return None
                continue
            
            # Token is valid, ask if user wants to save it
            save = Confirm.ask("Save token to .env file for future use?", default=True)
            if save:
                _save_token_to_env(token)
                console.print("[green]✓[/green] Token saved to .env")
            
            return token
        except KeyboardInterrupt:
            console.print("\n[yellow]Operation cancelled by user[/yellow]")
            return None

def get_bitbucket_username():
    """
    Get Bitbucket username from environment or prompt user for it.
    Optionally saves the username to .env file.
    Returns the username or None if user cancelled.
    """
    # Reload .env to get latest values
    _env_path = Path(__file__).parent.parent / '.env'
    if _env_path.exists():
        load_dotenv(dotenv_path=str(_env_path), override=True)
    
    username = os.getenv('BITBUCKET_USERNAME', '').strip()
    
    # If username is empty or 'token' (old default), ask user for their actual username
    if username and username != 'token':
        return username
    
    from rich.console import Console
    from rich.prompt import Prompt, Confirm
    
    console = Console()
    console.print("\n[yellow]⚠️  Bitbucket username not configured[/yellow]")
    console.print("Enter your Bitbucket username (e.g., john.doe or sa-ai-promptlibwebui)\n")
    
    while True:
        try:
            username = Prompt.ask("Enter your Bitbucket username (or press Ctrl+C to cancel)")
            username = username.strip()
            
            if not username:
                console.print("[red]✗[/red] Username cannot be empty.")
                retry = Confirm.ask("Try again?", default=True)
                if not retry:
                    return None
                continue
            
            # Username is valid, ask if user wants to save it
            save = Confirm.ask("Save username to .env file for future use?", default=True)
            if save:
                _save_username_to_env(username)
                console.print("[green]✓[/green] Username saved to .env")
            
            return username
        except KeyboardInterrupt:
            console.print("\n[yellow]Operation cancelled by user[/yellow]")
            return None

def _save_token_to_env(token):
    """Save token to .env file, updating existing entry or creating new one."""
    if not token or not token.strip():
        raise ValueError("Cannot save empty token to .env file")
    
    token = token.strip()
    env_file = Path(__file__).parent.parent / '.env'
    
    if env_file.exists():
        content = env_file.read_text(encoding='utf-8')
        lines = content.split('\n')
        
        # Update existing BITBUCKET_HTTP_TOKEN line or add new one
        token_found = False
        for i, line in enumerate(lines):
            if line.startswith('BITBUCKET_HTTP_TOKEN='):
                lines[i] = f'BITBUCKET_HTTP_TOKEN={token}'
                token_found = True
                break
        
        if not token_found:
            # Add token after BITBUCKET_REPO line
            for i, line in enumerate(lines):
                if line.startswith('BITBUCKET_REPO='):
                    lines.insert(i + 1, f'BITBUCKET_HTTP_TOKEN={token}')
                    break
        
        env_file.write_text('\n'.join(lines), encoding='utf-8')
    else:
        # Create new .env with token
        ensure_env_file()
        _save_token_to_env(token)  # Recursive call to update the newly created file

def _save_username_to_env(username):
    """Save username to .env file, updating existing entry or creating new one."""
    if not username or not username.strip():
        raise ValueError("Cannot save empty username to .env file")
    
    username = username.strip()
    env_file = Path(__file__).parent.parent / '.env'
    
    if env_file.exists():
        content = env_file.read_text(encoding='utf-8')
        lines = content.split('\n')
        
        # Update existing BITBUCKET_USERNAME line
        username_found = False
        for i, line in enumerate(lines):
            if line.startswith('BITBUCKET_USERNAME='):
                lines[i] = f'BITBUCKET_USERNAME={username}'
                username_found = True
                break
        
        if not username_found:
            # Add username after BITBUCKET_HTTP_TOKEN line
            for i, line in enumerate(lines):
                if line.startswith('BITBUCKET_HTTP_TOKEN='):
                    lines.insert(i + 1, f'BITBUCKET_USERNAME={username}')
                    break
        
        env_file.write_text('\n'.join(lines), encoding='utf-8')
        
        # Reload environment variables
        load_dotenv(dotenv_path=str(env_file), override=True)
    else:
        # Create new .env with username
        ensure_env_file()
        _save_username_to_env(username)  # Recursive call to update the newly created file

# Bitbucket Server configuration (self-hosted)
BITBUCKET_SERVER = os.getenv('BITBUCKET_SERVER', 'scm.devops.cambio.se')
BITBUCKET_PROJECT = os.getenv('BITBUCKET_PROJECT', 'IAII')
BITBUCKET_REPO = os.getenv('BITBUCKET_REPO', 'cambio_prompt_lib')
BITBUCKET_HTTP_TOKEN = os.getenv('BITBUCKET_HTTP_TOKEN', '')
# Don't use default for username - empty means not configured
BITBUCKET_USERNAME = os.getenv('BITBUCKET_USERNAME', '')
BITBUCKET_BRANCH = os.getenv('BITBUCKET_BRANCH') or os.getenv('BITBUCKET_DEFAULT_BRANCH') or os.getenv('PROMPTS_REPO_BRANCH') or 'master'

# Prompts API configuration (optional external prompts service)
PROMPTS_API_URL = os.getenv('PROMPTS_API_URL') or os.getenv('PROMPTS_ENDPOINT')
PROMPTS_API_TOKEN = os.getenv('PROMPTS_API_TOKEN')
PROMPTS_REPO_PATH = os.getenv('PROMPTS_REPO_PATH')

# Legacy Bitbucket Cloud config (keep for compatibility)
BITBUCKET_WORKSPACE = os.getenv("BITBUCKET_WORKSPACE", "your-workspace")
BITBUCKET_API_BASE = os.getenv("BITBUCKET_API_BASE", "https://api.bitbucket.org/2.0")

DEFAULT_SCHEMA_PATH = Path(".schema")
