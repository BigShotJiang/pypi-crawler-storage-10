from pathlib import Path
import json


def load_tag_mappings():
    schema_path = Path(".schema") / "categories.json"
    if schema_path.exists():
        try:
            return json.loads(schema_path.read_text(encoding="utf-8"))
        except Exception:
            return {}
    # Default minimal mapping
    return {
        "developers": {
            "code-review": ["code-quality", "peer-review", "best-practices"],
            "testing": ["unit-tests", "automation", "quality-assurance"],
            "debugging": ["troubleshooting", "error-handling", "logs"]
        }
    }


def generate_tags(category: str, subcategory: str, existing_tags=None):
    tag_map = load_tag_mappings()
    base_tags = [category, subcategory]
    contextual = tag_map.get(category, {}).get(subcategory, [])
    all_tags = base_tags + contextual
    if existing_tags:
        all_tags.extend([t for t in existing_tags if t not in all_tags])
    # Remove duplicates while preserving order
    seen = set()
    out = []
    for t in all_tags:
        if t not in seen:
            seen.add(t)
            out.append(t)
    return out


def regenerate_tags_if_needed(prompt_path):
    """Regenerate tags for a prompt directory if base/contextual tags are missing.
    Returns True if file was updated.
    """
    from .utils import locate_prompt_files
    yaml_file, _ = locate_prompt_files(Path(prompt_path))
    if yaml_file is None:
        return False

    try:
        data = json.loads(yaml_file.read_text(encoding='utf-8'))
    except Exception:
        # fallback to yaml parsing (safer)
        import yaml
        with open(yaml_file, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f) or {}

    current_tags = data.get('tags', []) or []
    category = data.get('category')
    subcategory = data.get('subcategory')
    if not category or not subcategory:
        return False

    expected = generate_tags(category, subcategory, current_tags)
    if expected != current_tags:
        data['tags'] = expected
        import yaml
        with open(yaml_file, 'w', encoding='utf-8') as f:
            yaml.dump(data, f, sort_keys=False)
        return True

    return False
