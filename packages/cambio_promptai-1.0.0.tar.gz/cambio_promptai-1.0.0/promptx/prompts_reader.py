import json
import os
from pathlib import Path
from typing import List, Optional
from rich.console import Console
import requests
from promptx.config import (
    PROMPTS_API_URL,
    PROMPTS_API_TOKEN,
    PROMPTS_REPO_PATH,
    BITBUCKET_SERVER,
    BITBUCKET_PROJECT,
    BITBUCKET_REPO,
    BITBUCKET_HTTP_TOKEN,
    BITBUCKET_BRANCH
)

console = Console()
from promptx.auth import get_token_with_fallback


def _read_prompts_json_from_dir(dir_path: Path) -> List[dict]:
    """Read and parse prompts.json from a directory. Returns a list of prompt dicts."""
    prompts_json = dir_path / 'prompts.json'
    if not prompts_json.exists():
        # No prompts.json in this directory
        return []

    try:
        with open(prompts_json, 'r', encoding='utf-8') as f:
            data = json.load(f)

        if isinstance(data, dict) and 'prompts' in data:
            prompts_list = data['prompts']
        else:
            prompts_list = data if isinstance(data, list) else []

        # Normalize prompts
        results = []
        for prompt in prompts_list:
            if not isinstance(prompt, dict):
                continue
            results.append({
                'id': prompt.get('id', ''),
                'title': prompt.get('title', ''),
                'description': prompt.get('description', ''),
                'category': prompt.get('category', ''),
                'subcategory': prompt.get('subcategory', ''),
                'role': prompt.get('role', ''),
                'metadata': prompt.get('metadata', {}),
                'path': prompt.get('file_info', {}).get('relative_path', ''),
                'tags': prompt.get('tags', [])
            })

        return results

    except json.JSONDecodeError as e:
        console.print(f'[red]Error parsing {prompts_json}: {e}[/red]')
        return []
    except Exception as e:
        console.print(f'[red]Error reading {prompts_json}: {e}[/red]')
        return []


def get_prompts_from_json() -> List[dict]:
    """Fetch prompts.json from Bitbucket API or configured sources.

    Priority order:
    1. Bitbucket REST API (production recommended)
    2. Custom API URL if configured
    3. Local file fallback (development only)
    """
    try:
        # First priority: Bitbucket raw endpoint (production approach)
        if BITBUCKET_SERVER and BITBUCKET_PROJECT and BITBUCKET_REPO:
            try:
                file_path = os.getenv('PROMPTS_FILE_PATH', 'prompts.json')
                raw_endpoint = f"/rest/api/1.0/projects/{BITBUCKET_PROJECT}/repos/{BITBUCKET_REPO}/raw/{file_path}?at={BITBUCKET_BRANCH}"
                raw_url = f"https://{BITBUCKET_SERVER}{raw_endpoint}"
                
                headers = {}
                token = get_token_with_fallback()
                if not token:
                    console.print('[yellow]⚠ No authentication token found. Run "promptx login" to authenticate.[/yellow]')
                    return []
                
                headers['Authorization'] = f'Bearer {token}'
                
                resp = requests.get(raw_url, headers=headers, timeout=10)
                resp.raise_for_status()
                data = resp.json()
                
                if isinstance(data, dict) and 'prompts' in data:
                    return data['prompts']
                if isinstance(data, list):
                    return data
                    
                console.print('[yellow]⚠ Invalid prompts.json format received from API[/yellow]')
                return []
                
            except requests.exceptions.HTTPError as e:
                if e.response.status_code == 401:
                    console.print('[red]✗ Authentication failed. Your token may be expired.[/red]')
                    console.print('[yellow]💡 Run "promptx login" to refresh your credentials.[/yellow]')
                elif e.response.status_code == 403:
                    console.print('[red]✗ Access denied. Check your permissions for the Bitbucket repository.[/red]')
                elif e.response.status_code == 404:
                    console.print('[red]✗ prompts.json not found in repository.[/red]')
                    console.print(f'[yellow]💡 Expected path: {raw_url}[/yellow]')
                else:
                    console.print(f'[red]✗ HTTP {e.response.status_code} error fetching prompts: {e}[/red]')
                return []
            except requests.exceptions.ConnectionError:
                console.print('[red]✗ Connection error. Check your network connection or VPN.[/red]')
                return []
            except requests.exceptions.Timeout:
                console.print('[red]✗ Request timeout. Bitbucket server may be slow or unreachable.[/red]')
                return []
            except requests.exceptions.RequestException as e:
                console.print(f'[red]✗ Request error: {e}[/red]')
                return []
            except json.JSONDecodeError:
                console.print('[red]✗ Invalid JSON response from Bitbucket API[/red]')
                return []

        # Second priority: Custom API URL if configured
        if PROMPTS_API_URL:
            try:
                headers = {}
                if PROMPTS_API_TOKEN:
                    headers['Authorization'] = f'Bearer {PROMPTS_API_TOKEN}'

                resp = requests.get(PROMPTS_API_URL, headers=headers, timeout=10)
                resp.raise_for_status()
                data = resp.json()
                
                if isinstance(data, dict) and 'prompts' in data:
                    return data['prompts']
                if isinstance(data, list):
                    return data
            except Exception as e:
                console.print(f'[yellow]Failed to fetch from custom API {PROMPTS_API_URL}: {e}[/yellow]')

        # Fallback: Local development mode (not recommended for production)
        if PROMPTS_REPO_PATH:
            candidate = Path(PROMPTS_REPO_PATH)
            if candidate.exists() and candidate.is_dir():
                console.print('[yellow]⚠ Using local prompts.json (development mode)[/yellow]')
                return _read_prompts_json_from_dir(candidate)

        # Last resort: check parent directory (development only)
        parent_candidate = Path(__file__).resolve().parents[2] / 'prompts'
        if parent_candidate.exists() and parent_candidate.is_dir():
            parent_root = parent_candidate.parent
            prompts = _read_prompts_json_from_dir(parent_root)
            if prompts:
                console.print('[yellow]⚠ Using local parent directory prompts.json (development mode)[/yellow]')
                return prompts

        # No prompts found
        console.print('[red]✗ No prompts.json found[/red]')
        console.print('[yellow]💡 Configure Bitbucket credentials in .env or run "promptx login"[/yellow]')
        return []

    except Exception as e:
        console.print(f'[red]✗ Unexpected error fetching prompts: {e}[/red]')
        return []


def get_existing_roles():
    """Get unique roles from prompts.json via Bitbucket API
    
    Roles are stored in the 'category' field of prompts (people/teams like 'developers', 'business-analysts')
    NOT in subcategory (which are task types like 'code-generation')
    
    Returns:
        List of role names (sorted)
    """
    roles = set()

    # Get roles from prompts.json via Bitbucket API
    if BITBUCKET_SERVER and BITBUCKET_PROJECT and BITBUCKET_REPO:
        try:
            file_path = 'prompts.json'
            raw_endpoint = f"/rest/api/1.0/projects/{BITBUCKET_PROJECT}/repos/{BITBUCKET_REPO}/raw/{file_path}?at={BITBUCKET_BRANCH}"
            raw_url = f"https://{BITBUCKET_SERVER}{raw_endpoint}"
            
            headers = {}
            token = get_token_with_fallback()
            if not token:
                console.print('[yellow]⚠ No authentication token found for fetching roles[/yellow]')
                return []
            
            headers['Authorization'] = f'Bearer {token}'
            
            resp = requests.get(raw_url, headers=headers, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            
            # Extract unique 'category' values (these are the roles)
            if 'prompts' in data:
                for prompt in data['prompts']:
                    role = prompt.get('category')
                    if role:
                        roles.add(role)
            
            if not roles:
                console.print('[yellow]⚠ No roles found in prompts.json[/yellow]')
                return []
                
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 401:
                console.print('[red]✗ Authentication failed while fetching roles[/red]')
            elif e.response.status_code == 404:
                console.print('[red]✗ prompts.json not found in repository[/red]')
            else:
                console.print(f'[yellow]Failed to fetch roles from Bitbucket API: HTTP {e.response.status_code}[/yellow]')
            return []
        except Exception as e:
            console.print(f'[yellow]Failed to fetch roles from Bitbucket API: {e}[/yellow]')
            return []

    # Fallback: try from local prompts (development only)
    if not roles:
        prompts = get_prompts_from_json()
        for p in prompts:
            if not isinstance(p, dict):
                continue
            role = p.get('category')
            if role:
                roles.add(role)

    return sorted(list(roles))


def get_existing_categories(role: Optional[str] = None):
    """Get unique subcategories (task types) with use-case names from prompts.json via Bitbucket API
    
    Returns list of tuples: (category, usecase, display_string)
    Display string format: "category (use-case-name)"
    
    Args:
        role: Optional role to filter categories by. If provided, only returns categories for that role.
    
    Returns:
        List of tuples: (category, usecase, display_string)
        Example: [('code-generation', 'spring-boot-rest-api', 'code-generation (Spring Boot REST API)')]
    """
    results = []
    seen = set()

    # Get categories from prompts.json via Bitbucket API
    if BITBUCKET_SERVER and BITBUCKET_PROJECT and BITBUCKET_REPO:
        try:
            file_path = 'prompts.json'
            raw_endpoint = f"/rest/api/1.0/projects/{BITBUCKET_PROJECT}/repos/{BITBUCKET_REPO}/raw/{file_path}?at={BITBUCKET_BRANCH}"
            raw_url = f"https://{BITBUCKET_SERVER}{raw_endpoint}"
            
            headers = {}
            token = get_token_with_fallback()
            if not token:
                console.print('[yellow]⚠ No authentication token found for fetching categories[/yellow]')
                return []
            
            headers['Authorization'] = f'Bearer {token}'
            
            resp = requests.get(raw_url, headers=headers, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            
            # Extract category/use-case combinations
            if 'prompts' in data:
                for prompt in data['prompts']:
                    # If role filter is provided, only include from that role
                    if role:
                        prompt_role = prompt.get('category')
                        if prompt_role != role:
                            continue
                    
                    category = prompt.get('subcategory')
                    usecase = prompt.get('id')  # This is the use-case slug
                    title = prompt.get('title')  # Human-readable name
                    
                    if category and usecase:
                        key = f"{category}|{usecase}"
                        if key not in seen:
                            seen.add(key)
                            # Display format: "category (Title)"
                            display = f"{category} ({title})" if title else f"{category}/{usecase}"
                            results.append((category, usecase, display))
            
            if not results:
                role_msg = f" for role '{role}'" if role else ""
                console.print(f'[yellow]⚠ No categories found{role_msg}[/yellow]')
                
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 401:
                console.print('[red]✗ Authentication failed while fetching categories[/red]')
            elif e.response.status_code == 404:
                console.print('[red]✗ prompts.json not found in repository[/red]')
            else:
                console.print(f'[yellow]Failed to fetch categories from Bitbucket API: HTTP {e.response.status_code}[/yellow]')
            return []
        except Exception as e:
            console.print(f'[yellow]Failed to fetch categories from Bitbucket API: {e}[/yellow]')
            return []

    # Fallback: try from local prompts (development only)
    if not results:
        prompts = get_prompts_from_json()
        for p in prompts:
            if not isinstance(p, dict):
                continue
            
            # If role filter is provided, only include from that role
            if role:
                prompt_role = p.get('category')
                if prompt_role != role:
                    continue
            
            category = p.get('subcategory')
            usecase = p.get('id')
            title = p.get('title')
            
            if category and usecase:
                key = f"{category}|{usecase}"
                if key not in seen:
                    seen.add(key)
                    display = f"{category} ({title})" if title else f"{category}/{usecase}"
                    results.append((category, usecase, display))

    # Sort by display string
    return sorted(results, key=lambda x: x[2])

