from pathlib import Path
import yaml
from typing import Any, Tuple, Optional


def ensure_dir(path: Path):
    """Create directory and all parent directories if they don't exist"""
    path.mkdir(parents=True, exist_ok=True)


def safe_write_file(path: Path, data: Any) -> str:
    """Write YAML if data is a dict/list, otherwise write text.
    
    Returns the path as a string.
    """
    if isinstance(data, (dict, list)):
        with open(path, "w", encoding="utf-8") as f:
            yaml.dump(data, f, sort_keys=False)
    else:
        with open(path, "w", encoding="utf-8") as f:
            f.write(str(data))
    
    return str(path)


def locate_prompt_files(prompt_dir: Path) -> Tuple[Optional[Path], Optional[Path]]:
    """Return (yaml_file, md_file) paths for a prompt directory.
    
    Accepts prompt.yaml/prompt.md or <use_case>.yml/.md (first match).
    Returns tuple of (Path|None, Path|None).
    """
    prompt_dir = Path(prompt_dir)
    yaml_file = prompt_dir / 'prompt.yaml'
    md_file = prompt_dir / 'prompt.md'

    if not yaml_file.exists():
        ym = next(prompt_dir.glob('*.yml'), None)
        if ym:
            yaml_file = ym
        else:
            ya = next(prompt_dir.glob('*.yaml'), None)
            if ya:
                yaml_file = ya

    if not md_file.exists():
        mm = next(prompt_dir.glob('*.md'), None)
        if mm:
            md_file = mm

    return yaml_file if yaml_file and yaml_file.exists() else None, md_file if md_file and md_file.exists() else None
