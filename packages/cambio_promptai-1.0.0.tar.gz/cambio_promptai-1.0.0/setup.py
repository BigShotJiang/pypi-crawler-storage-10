from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="cambio-promptai",
    version="1.0.0",
    author="Shaithra Vilvarashah",
    author_email="Shaithra.Vilvarashah@cambio.lk",
    description="A comprehensive CLI tool for managing enterprise AI prompts with integrated Bitbucket workflow",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://scm.devops.cambio.se/scm/~shaithra.vilvarashah/prompt_lib_sdk_v0.1.git",
    packages=find_packages(),
    license="Proprietary",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: Other/Proprietary License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Shells",
        "Topic :: Text Processing :: Markup",
    ],
    keywords="ai prompts cli bitbucket workflow automation",
    python_requires=">=3.8",
    install_requires=[
        "click>=8.1.0",
        "pyyaml>=6.0",
        "jsonschema>=4.17.0",
        "requests>=2.31.0",
        "rich>=13.0.0",
        "gitpython>=3.1.0",
        "python-dotenv>=1.0.0",
    ],
    entry_points={
        "console_scripts": [
            "promptai=promptx.cli:cli",
        ],
    },
    project_urls={
        "Source": "https://scm.devops.cambio.se/scm/~shaithra.vilvarashah/prompt_lib_sdk_v0.1.git",
    },
)
