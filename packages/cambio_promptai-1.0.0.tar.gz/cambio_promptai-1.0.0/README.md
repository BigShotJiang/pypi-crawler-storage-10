# cambio-promptai SDK

A comprehensive CLI tool for managing prompts as code with integrated Bitbucket workflow.

> **INTERNAL USE ONLY**  
> This package is proprietary software for Cambio Healthcare Systems employees only.  

## Installation

```bash
pip install cambio-promptai
```

## Quick Start

### 1. Create Bitbucket Token

Before using promptai, create a Bitbucket HTTP Access Token:

1. Go to: https://scm.devops.cambio.se
2. Click your profile → **Manage account** → **HTTP access tokens**
3. Click **Create token**
4. **Token name**: `promptai-cli` (or any name you prefer)
5. **Permissions**: ✅ **Write** (required for publishing)
6. **Expiry**: ✅ **No expiration**
7. Copy the generated token

### 2. Login (First Time Setup)

```bash
promptai login
```

You'll be prompted for:
- **Bitbucket HTTP token** (the token you just created)
- **Username** (e.g., `john.doe`)
- **Email** (format: `firstname.lastname@cambio.lk`)

Your credentials are securely stored in `~/.promptx/credentials.json`

### 3. Check Login Status

```bash
promptai whoami
```

### 4. Start Creating Prompts

```bash
promptai init
```

This opens an interactive menu where you can create, test, and publish prompts.

## Available Commands

To see all available commands:

```bash
promptai --help
```

### Main Commands:

- `promptai login` - Authenticate with your Bitbucket credentials
- `promptai logout` - Remove stored credentials
- `promptai whoami` - Check current login status
- `promptai init` - Interactive menu for creating and managing prompts
- `promptai browse` - Browse existing prompts from repository
- `promptai test <draft-folder>` - Validate a specific draft


## Requirements

- Python 3.8+
- Git installed and in PATH
- Bitbucket access token with **write permissions** and **no expiration**



