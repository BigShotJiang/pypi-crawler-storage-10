from metaflow import step, kubernetes
from obproject import ProjectFlow
from src.flow_templates import NeuralNetworkFlow


class ConfigOverrideTestFlow(ProjectFlow, NeuralNetworkFlow):

    # @kubernetes
    @step
    def start(self):
        self._resolve_config()
        self.next(self.end)

    @step
    def end(self):
        print("Resolved config:", self.config)


if __name__ == "__main__":
    ConfigOverrideTestFlow()
