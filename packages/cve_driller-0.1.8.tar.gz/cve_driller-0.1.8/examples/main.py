import json

from cve_driller.driller import CVEDriller


if __name__ == "__main__":
    driller = CVEDriller(verbose=True)
    cve_id = "CVE-2018-7187"

    input_path = f"data/inputs/CWE-78/comp_config_condition/{cve_id}.txt"
    #description = open(input_path, 'r').read()
    description = "A SQL injection vulnerability exists in ProjectWorlds Hospital Management System in php 1.0 on login page that allows a remote attacker to compromise Application SQL database."
    detail_type, details = driller(description)
    # CVE-2021-44095

    if details:
        print(json.dumps(details, indent=4))

    #if details:
    #    output_path = f"data/outputs/{detail_type.value}/{cve_id}.json"

    #    with open(output_path, 'w') as f:
    #        json.dump(details, f, indent=4)
