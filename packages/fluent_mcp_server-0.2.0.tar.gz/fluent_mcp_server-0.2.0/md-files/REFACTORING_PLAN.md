# Fluent MCP Server - Refactoring Plan: Remove Static Index

**Date:** 2025-10-31
**Goal:** Transform MCP server from "offline command database" to "smart online resource finder"
**Philosophy:** MCP server should be a **middleman** that helps the LLM find online resources, NOT a static knowledge base

---

## Current State vs. Target State

### Current (Incorrect) Architecture
```
User asks: "How to read case file?"
         ↓
LLM calls: search_help("read case")
         ↓
MCP searches: Static index with 13 hardcoded commands
         ↓
MCP returns: "file/read-case - Load a case file (.cas or .cas.h5)"
         ↓
LLM shows result to user
```

**Problem:**
- ❌ Static index gets outdated
- ❌ Can't cover all Fluent features (combustion, multiphase, UDF, etc.)
- ❌ Maintenance burden (manually index commands)
- ❌ Limited to what we hardcode

### Target (Correct) Architecture
```
User asks: "How to use flamelet model?"
         ↓
LLM calls: search_help("flamelet model")
         ↓
MCP builds: Smart search URL for ANSYS Help
         ↓
MCP returns:
  "Search ANSYS Fluent Help:
   https://ansyshelp.ansys.com/Views/Secured/search.html?q=flamelet+model&v=25.2&pn=Fluent

   Or browse directly:
   - User Guide: [URL to combustion section]
   - Theory Guide: [URL to flamelet theory]
   - TUI Commands: [URL to model commands]"
         ↓
LLM uses WebFetch on the URL
         ↓
LLM reads actual ANSYS documentation
         ↓
LLM answers user with up-to-date, comprehensive info
```

**Benefits:**
- ✅ Always up-to-date (points to official docs)
- ✅ Comprehensive (covers ALL Fluent features)
- ✅ Zero maintenance (ANSYS maintains the docs)
- ✅ Lightweight (no hardcoded database)

---

## Refactoring Steps

### Step 1: Redesign `help_search.py` → `doc_finder.py`

**Current:** `help_search.py` (273 lines)
- Static index with 13 commands
- Relevance scoring algorithm
- Returns content from static database

**Target:** `doc_finder.py` (~100 lines)
- Smart URL builder for ANSYS Help
- Topic/keyword to manual section mapper
- Returns URLs and navigation hints

#### New Architecture:

```python
# src/fluent_mcp_server/doc_finder.py

class FluentDocFinder:
    """Smart URL builder for ANSYS Fluent online documentation."""

    BASE_SEARCH_URL = "https://ansyshelp.ansys.com/Views/Secured/search.html"
    BASE_MANUAL_URL = "https://ansyshelp.ansys.com/Views/Secured/corp/v252/en"
    VERSION = "25.2"  # 2025 R2

    # Lightweight topic → manual section mapping
    TOPIC_MAP = {
        # File I/O
        "file": {"manual": "flu_tui", "section": "file"},
        "read case": {"manual": "flu_tui", "section": "file/read-case"},
        "write case": {"manual": "flu_tui", "section": "file/write-case"},

        # Models
        "turbulence": {"manual": "flu_ug", "section": "turbulence-models", "theory": "flu_th/turbulence"},
        "combustion": {"manual": "flu_ug", "section": "combustion-models", "theory": "flu_th/combustion"},
        "flamelet": {"manual": "flu_ug", "section": "flamelet-model", "theory": "flu_th/flamelet"},
        "multiphase": {"manual": "flu_ug", "section": "multiphase-models", "theory": "flu_th/multiphase"},

        # Solver
        "solve": {"manual": "flu_tui", "section": "solve"},
        "convergence": {"manual": "flu_ug", "section": "convergence"},

        # Mesh
        "mesh": {"manual": "flu_ug", "section": "meshing"},
        "mesh quality": {"manual": "flu_ug", "section": "mesh-quality"},

        # Boundary Conditions
        "boundary": {"manual": "flu_ug", "section": "boundary-conditions"},
        "inlet": {"manual": "flu_ug", "section": "velocity-inlet"},
        "outlet": {"manual": "flu_ug", "section": "pressure-outlet"},

        # UDF
        "udf": {"manual": "flu_udf", "section": "introduction"},
        "user defined function": {"manual": "flu_udf", "section": "introduction"},
    }

    def search(self, query: str, max_results: int = 5) -> dict:
        """Build search URLs for a query.

        Returns:
            dict with search_url, suggested_manuals, and navigation_hints
        """
        query_lower = query.lower().strip()

        # Build search URL
        search_url = self._build_search_url(query)

        # Find relevant manual sections
        suggested_sections = self._find_relevant_sections(query_lower)

        # Get manual links
        manual_links = self._get_manual_links()

        return {
            "query": query,
            "search_url": search_url,
            "suggested_sections": suggested_sections,
            "manual_links": manual_links,
            "tip": "Use WebFetch tool to retrieve the actual documentation from these URLs"
        }

    def _build_search_url(self, query: str) -> str:
        """Build ANSYS Help search URL."""
        import urllib.parse
        encoded_query = urllib.parse.quote_plus(query)
        return f"{self.BASE_SEARCH_URL}?q={encoded_query}&v={self.VERSION}&pn=Fluent&lang=en"

    def _find_relevant_sections(self, query_lower: str) -> list[dict]:
        """Find relevant manual sections based on query."""
        matches = []

        for topic, info in self.TOPIC_MAP.items():
            # Simple keyword matching
            if topic in query_lower or any(word in topic for word in query_lower.split()):
                section_url = f"{self.BASE_MANUAL_URL}/{info['manual']}/{info['section']}.html"
                match = {
                    "topic": topic,
                    "manual": info["manual"],
                    "url": section_url
                }

                # Add theory guide link if available
                if "theory" in info:
                    match["theory_url"] = f"{self.BASE_MANUAL_URL}/{info['theory']}.html"

                matches.append(match)

        return matches

    def _get_manual_links(self) -> dict:
        """Get links to all major manuals."""
        return {
            "User Guide": f"{self.BASE_MANUAL_URL}/flu_ug/flu_ug.html",
            "TUI Commands": f"{self.BASE_MANUAL_URL}/flu_tui/flu_tui.html",
            "Theory Guide": f"{self.BASE_MANUAL_URL}/flu_th/flu_th.html",
            "UDF Manual": f"{self.BASE_MANUAL_URL}/flu_udf/flu_udf.html",
        }

    def list_topics(self) -> list[str]:
        """List all indexed topics."""
        return sorted(self.TOPIC_MAP.keys())
```

**Key Changes:**
- ❌ Remove: Static command database (13 commands)
- ❌ Remove: Relevance scoring algorithm
- ❌ Remove: Content storage
- ✅ Add: Smart URL builder
- ✅ Add: Lightweight topic → manual mapper (~20-30 topics)
- ✅ Add: Manual navigation hints

---

### Step 2: Update MCP Tools in `server.py`

#### Tool 1: `search_help()` → Returns URLs, not content

**Before:**
```python
@mcp.tool()
def search_help(query: str, category: str | None = None, max_results: int = 5) -> str:
    """Search ANSYS Fluent documentation..."""
    results = help_search.search(query, category, max_results)
    # Returns formatted content from static index
    return formatted_content
```

**After:**
```python
@mcp.tool()
def search_help(query: str, max_results: int = 5) -> str:
    """Find ANSYS Fluent documentation for your query.

    Args:
        query: Search term (e.g., "flamelet model", "read case", "turbulence")
        max_results: Maximum suggested sections to return

    Returns:
        URLs and navigation hints for finding the documentation
    """
    logger.info(f"Finding docs for: '{query}'")

    result = doc_finder.search(query, max_results)

    # Format response
    output = [f"# ANSYS Fluent Documentation for: '{query}'\n"]

    # 1. Search URL (primary method)
    output.append("## Search ANSYS Help (Recommended)")
    output.append(f"{result['search_url']}\n")
    output.append("Use WebFetch to retrieve results from this URL.\n")

    # 2. Suggested manual sections
    if result['suggested_sections']:
        output.append("## Suggested Manual Sections")
        for section in result['suggested_sections'][:max_results]:
            output.append(f"- **{section['topic']}** ({section['manual']})")
            output.append(f"  {section['url']}")
            if 'theory_url' in section:
                output.append(f"  Theory: {section['theory_url']}")
        output.append("")

    # 3. Manual links
    output.append("## Browse Manuals")
    for manual, url in result['manual_links'].items():
        output.append(f"- {manual}: {url}")

    output.append(f"\n💡 {result['tip']}")

    return "\n".join(output)
```

#### Tool 2: `get_manual_link()` → Direct manual navigation

**New tool:**
```python
@mcp.tool()
def get_manual_link(manual: str, section: str | None = None) -> str:
    """Get direct link to a specific Fluent manual section.

    Args:
        manual: Manual name (user_guide, tui, theory, udf)
        section: Optional section/chapter (e.g., "turbulence", "file/read-case")

    Returns:
        Direct URL to the manual or section
    """
    manual_codes = {
        "user_guide": "flu_ug",
        "tui": "flu_tui",
        "theory": "flu_th",
        "udf": "flu_udf"
    }

    if manual not in manual_codes:
        return f"Unknown manual: {manual}. Available: {', '.join(manual_codes.keys())}"

    code = manual_codes[manual]
    base_url = f"https://ansyshelp.ansys.com/Views/Secured/corp/v252/en/{code}"

    if section:
        return f"{base_url}/{section}.html"
    else:
        return f"{base_url}/{code}.html"
```

#### Tool 3: Remove `list_categories()` and `list_commands()`

**Reason:** No longer relevant without static index

**Replace with:**
```python
@mcp.tool()
def list_topics() -> str:
    """List common Fluent topics with documentation links.

    Returns:
        List of indexed topics for quick navigation
    """
    topics = doc_finder.list_topics()

    output = ["# Common Fluent Topics\n"]
    output.append("These topics have quick links to relevant documentation:\n")

    for topic in topics:
        output.append(f"- {topic}")

    output.append("\nUse search_help(topic) to get documentation URLs.")

    return "\n".join(output)
```

---

### Step 3: Update MCP Resource

**Before:**
```python
@mcp.resource("fluent://docs/online")
def get_online_docs_info() -> str:
    """Long static text about ANSYS Help..."""
    return """# ANSYS Fluent Online Documentation..."""
```

**After:**
```python
@mcp.resource("fluent://docs/online")
def get_online_docs_info() -> str:
    """Quick reference for ANSYS Fluent documentation structure."""
    return """# ANSYS Fluent Documentation Quick Reference

## Search
https://ansyshelp.ansys.com/Views/Secured/search.html?q={query}&v=25.2&pn=Fluent

## Main Manuals (2025 R2 / v252)
- User Guide: https://ansyshelp.ansys.com/Views/Secured/corp/v252/en/flu_ug/flu_ug.html
- TUI Commands: https://ansyshelp.ansys.com/Views/Secured/corp/v252/en/flu_tui/flu_tui.html
- Theory Guide: https://ansyshelp.ansys.com/Views/Secured/corp/v252/en/flu_th/flu_th.html
- UDF Manual: https://ansyshelp.ansys.com/Views/Secured/corp/v252/en/flu_udf/flu_udf.html

## How to Use
1. Use search_help(query) to find relevant sections
2. Use WebFetch on the returned URLs to read documentation
3. Use get_manual_link(manual, section) for direct navigation

## Version Info
Current: 2025 R2 (v252)
Previous: 2025 R1 (v251), 2024 R2 (v242)
"""
```

---

### Step 4: Create New Test Suite

**Remove:** `test_help_search.py` (tests static index)

**Create:** `test_doc_finder.py` (tests URL generation)

```python
# tests/test_doc_finder.py

import pytest
from fluent_mcp_server.doc_finder import FluentDocFinder


@pytest.fixture
def doc_finder():
    """Create a FluentDocFinder instance."""
    return FluentDocFinder()


def test_search_returns_urls(doc_finder):
    """Test that search returns proper URLs."""
    result = doc_finder.search("read case")

    assert "search_url" in result
    assert "ansyshelp.ansys.com" in result["search_url"]
    assert "read+case" in result["search_url"] or "read%20case" in result["search_url"]


def test_search_finds_relevant_sections(doc_finder):
    """Test that search finds relevant manual sections."""
    result = doc_finder.search("turbulence")

    assert "suggested_sections" in result
    assert len(result["suggested_sections"]) > 0

    # Should suggest turbulence-related sections
    section = result["suggested_sections"][0]
    assert "url" in section
    assert "manual" in section


def test_search_unknown_topic_still_works(doc_finder):
    """Test that search works even for unknown topics."""
    result = doc_finder.search("flamelet model")

    # Should always return a search URL
    assert "search_url" in result
    assert "flamelet+model" in result["search_url"] or "flamelet%20model" in result["search_url"]


def test_manual_links_always_present(doc_finder):
    """Test that all manual links are always returned."""
    result = doc_finder.search("anything")

    assert "manual_links" in result
    assert "User Guide" in result["manual_links"]
    assert "TUI Commands" in result["manual_links"]
    assert "Theory Guide" in result["manual_links"]
    assert "UDF Manual" in result["manual_links"]


def test_list_topics(doc_finder):
    """Test listing all indexed topics."""
    topics = doc_finder.list_topics()

    assert isinstance(topics, list)
    assert len(topics) > 0
    assert "file" in topics or "turbulence" in topics


def test_url_format_valid(doc_finder):
    """Test that generated URLs are valid."""
    result = doc_finder.search("mesh quality")

    # Check search URL format
    assert result["search_url"].startswith("https://")
    assert "ansyshelp.ansys.com" in result["search_url"]

    # Check manual links format
    for manual, url in result["manual_links"].items():
        assert url.startswith("https://")
        assert "ansyshelp.ansys.com" in url


def test_build_search_url(doc_finder):
    """Test search URL building."""
    url = doc_finder._build_search_url("read case file")

    assert "https://ansyshelp.ansys.com" in url
    assert "q=" in url
    assert "v=25.2" in url
    assert "pn=Fluent" in url
```

**Coverage:** URL generation, topic mapping, format validation

---

### Step 5: Update Documentation

#### Update `README.md`

**Before:**
```markdown
## Features
- Search 13+ common Fluent commands
- Offline static index
```

**After:**
```markdown
## Features
- Smart search URL builder for ANSYS Fluent documentation
- Topic-to-manual section mapping for quick navigation
- Always points to latest official ANSYS documentation
- Lightweight - no outdated static content
```

#### Update `ARCHITECTURE.md`

Remove/update:
- ❌ "Tier 1: Static Index (Offline, Fast)"
- ❌ "Static index of 13+ common TUI commands"

Add:
- ✅ "Smart URL Builder for ANSYS Help"
- ✅ "Lightweight topic → manual mapper"
- ✅ "LLM uses WebFetch to retrieve actual content"

#### Update `TOOLS.md`

Document new tool signatures and behavior.

---

### Step 6: Update Examples

**Before:** `examples/basic_help_search.py`
```python
# Searches static index
searcher = FluentHelpSearch()
results = searcher.search("read case")
print(results)  # Shows content from static database
```

**After:** `examples/basic_doc_finder.py`
```python
# Finds documentation URLs
finder = FluentDocFinder()
result = finder.search("flamelet model")

print(f"Search here: {result['search_url']}")
print(f"Suggested sections: {result['suggested_sections']}")

# LLM would then use WebFetch on these URLs
```

---

## Implementation Checklist

### Phase 1: Core Refactoring
- [ ] Create `src/fluent_mcp_server/doc_finder.py`
  - [ ] Implement `FluentDocFinder` class
  - [ ] Add topic mapping (~20-30 topics)
  - [ ] Add URL builder methods
  - [ ] Add manual section finder
- [ ] Update `src/fluent_mcp_server/server.py`
  - [ ] Import `doc_finder` instead of `help_search`
  - [ ] Refactor `search_help()` tool
  - [ ] Add `get_manual_link()` tool
  - [ ] Update `list_topics()` tool
  - [ ] Update MCP resource
- [ ] Remove `src/fluent_mcp_server/help_search.py`
  - [ ] After confirming everything works

### Phase 2: Testing
- [ ] Create `tests/test_doc_finder.py`
  - [ ] Test URL generation
  - [ ] Test topic mapping
  - [ ] Test manual link generation
  - [ ] Test edge cases (unknown topics, special characters)
- [ ] Remove `tests/test_help_search.py`
- [ ] Update Reddit examples test
  - [ ] Change from "finds content" to "finds URLs"
  - [ ] Verify URL correctness

### Phase 3: Documentation
- [ ] Update `README.md`
  - [ ] New architecture description
  - [ ] Updated feature list
  - [ ] New usage examples
- [ ] Update `md-files/ARCHITECTURE.md`
  - [ ] Remove static index section
  - [ ] Add smart URL builder section
  - [ ] Update design philosophy
- [ ] Update `md-files/TOOLS.md`
  - [ ] Document new tool signatures
  - [ ] Add URL format examples
- [ ] Update `CONTRIBUTING.md`
  - [ ] How to add new topic mappings
  - [ ] Testing URL generation

### Phase 4: Examples
- [ ] Create `examples/basic_doc_finder.py`
- [ ] Create `examples/find_combustion_docs.py`
- [ ] Remove `examples/basic_help_search.py`

### Phase 5: Validation
- [ ] Test with real LLM (Claude Desktop)
  - [ ] Query: "How to read case file?"
  - [ ] Query: "How to use flamelet model?"
  - [ ] Query: "Set up k-epsilon turbulence"
  - [ ] Verify LLM can fetch URLs and answer
- [ ] Check all tests pass
- [ ] Check logging still works
- [ ] Update version to 0.2.0

---

## Migration Strategy

### Option 1: Clean Break (Recommended)
1. Create `doc_finder.py` alongside `help_search.py`
2. Update `server.py` to use `doc_finder`
3. Test thoroughly
4. Delete `help_search.py`
5. Release as v0.2.0 with breaking changes

### Option 2: Gradual Migration
1. Keep both `help_search.py` and `doc_finder.py`
2. Add new tools alongside old ones
3. Deprecate old tools
4. Remove in v0.3.0

**Recommendation:** Option 1 (Clean Break)
- Server is still v0.1.0 (early)
- No users yet (assumption)
- Cleaner codebase
- Matches true architecture

---

## Success Criteria

### Functional Requirements
- ✅ `search_help(query)` returns valid ANSYS Help URLs
- ✅ URLs are correctly formatted and reachable
- ✅ Topic mapping covers common queries
- ✅ Unknown topics still return search URLs
- ✅ Manual links always present

### Testing Requirements
- ✅ All new tests pass (10+ tests)
- ✅ URL format validation
- ✅ Topic mapping coverage
- ✅ Edge case handling

### Documentation Requirements
- ✅ Architecture matches implementation
- ✅ README explains new design
- ✅ Examples demonstrate URL-based workflow
- ✅ Tool documentation accurate

### User Experience
- ✅ LLM can fetch and use returned URLs
- ✅ Responses are clear and actionable
- ✅ Works for both common and rare queries
- ✅ Faster than before (no static search overhead)

---

## Risks & Mitigations

### Risk 1: ANSYS URL structure changes
**Impact:** URLs might break if ANSYS reorganizes docs

**Mitigation:**
- Version number in URLs (v252) is stable per release
- Topic mapping is flexible (keywords → sections)
- Always provide search URL as fallback

### Risk 2: LLM can't fetch URLs
**Impact:** User doesn't get documentation

**Mitigation:**
- Provide multiple URL options (search + direct links)
- Clear instructions to use WebFetch
- MCP resource has manual links as backup

### Risk 3: Too few topic mappings
**Impact:** Many queries return only search URL (no section hints)

**Mitigation:**
- Start with 20-30 most common topics
- Easy to add more (just expand TOPIC_MAP)
- Search URL always works as fallback

### Risk 4: Breaking changes for users
**Impact:** Existing workflows break

**Mitigation:**
- Version bump to 0.2.0 (signals breaking change)
- Update README with migration guide
- Current user base is tiny (early stage)

---

## Timeline Estimate

### Immediate (1-2 hours)
- Create `doc_finder.py` with basic functionality
- Update `server.py` tools
- Add 10-15 topic mappings

### Short-term (2-3 hours)
- Write comprehensive tests
- Test with Claude Desktop
- Fix any issues

### Follow-up (1-2 hours)
- Update all documentation
- Update examples
- Clean up old code

**Total:** 4-7 hours

---

## Next Actions

1. **Review this plan** - Confirm approach
2. **Start with `doc_finder.py`** - Core implementation
3. **Update `server.py`** - Wire up new tools
4. **Test with LLM** - Validate user experience
5. **Update docs** - Match implementation
6. **Release v0.2.0** - Breaking change, new architecture

---

## Questions for Clarification

1. **How many topics should we map initially?**
   - Suggestion: 20-30 covering major areas
   - Can expand later based on usage

2. **Should we keep ANY static content?**
   - Suggestion: No, just topic → URL mappings
   - Pure middleman role

3. **What about the logging we just added?**
   - Keep it, but log "URLs generated" instead of "results found"

4. **Version number?**
   - Suggestion: 0.2.0 (breaking changes)

5. **Should we test with real LLM before finalizing?**
   - Yes - validate the URL approach actually works

---

Ready to start implementation! 🚀
