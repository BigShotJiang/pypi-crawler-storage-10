# ANSYS Help Documentation Guide

This guide documents the structure and patterns of the ANSYS Help documentation website for effective retrieval by AI assistants.

---

## Overview

**Base URL:** `https://ansyshelp.ansys.com/`

**Access:** Public access available (no login required for basic documentation)

**Search Functionality:** ✅ Built-in search available

---

## URL Patterns

### Version Mapping

ANSYS uses internal version codes in URLs:

| Version Name | Code | URL Pattern |
|--------------|------|-------------|
| 2024 R2 | v242 | `.../v242/...` |
| 2025 R1 | v251 | `.../v251/...` |
| 2025 R2 | v252 | `.../v252/...` |

**Pattern:** `v{YEAR_LAST_2}{RELEASE}` where release is 1 or 2 per year

### Documentation URL Structure

```
https://ansyshelp.ansys.com/public/account/secured?returnurl=/Views/Secured/corp/{VERSION}/en/{MANUAL_CODE}/{PAGE}.html
```

**Components:**
- `{VERSION}`: Version code (e.g., `v252`)
- `{MANUAL_CODE}`: Manual identifier (see list below)
- `{PAGE}`: Specific page/section identifier

**Example:**
```
https://ansyshelp.ansys.com/public/account/secured?returnurl=/Views/Secured/corp/v252/en/flu_ug/tgd_user_workflow_guided_intro.html
```

---

## Fluent Documentation Manuals

### Available Manuals (Manual Codes)

| Manual Code | Full Name | Content Type |
|-------------|-----------|--------------|
| `flu_ug` | Fluent User's Guide | Complete user documentation |
| `flu_th` | Fluent Theory Guide | Theoretical background |
| `flu_tui` | Fluent TUI Command List | Text User Interface commands |
| `flu_udf` | Fluent UDF Manual | User-Defined Functions |
| `flu_wb` | Fluent in Workbench | Workbench integration |

### Main Documentation Sections

**Fluent User's Guide (`flu_ug`):**
- Part I: Getting Started
- Part II: Meshing Mode
- Part III: Solution Mode
- Part IV: Web Interface

**URL Pattern for Table of Contents:**
```
.../corp/v252/en/flu_ug/flu_ug.html
```

---

## Search Functionality

### Search URL Pattern

```
https://ansyshelp.ansys.com/public/account/secured?returnurl=/Views/Secured/search.html?q={QUERY}&v={VERSION}&man="{MANUAL}"&pn="{PRODUCT}"&lang=en
```

**Parameters:**
- `q`: Search query (URL encoded)
- `v`: Version (e.g., `25.2` for 2025 R2)
- `man`: Manual name (e.g., `"Fluent User's Guide"`)
- `pn`: Product name (e.g., `"Fluent"`)
- `lang`: Language (typically `en`)

**Example Search:**
```
search.html?q=iterate&v=25.2&man="Fluent User's Guide"&pn="Fluent"&lang=en
```

### Search Features

1. **Full-text search** across selected manuals
2. **Filters available:**
   - Release version (2024 R2, 2025 R1, 2025 R2)
   - Product (Fluent, MAPDL, etc.)
   - Manual (User's Guide, Theory Guide, etc.)
   - Type (documentation type)

3. **Search results include:**
   - Page title and section hierarchy
   - Snippet with highlighted matches
   - Direct link to page with query parameter
   - Pagination (25 results per page by default)

4. **Result format:**
   - Results are paginated
   - Each result shows: Version > Manual > Section
   - Links include `?q={query}` for highlighting

---

## How to Use This in MCP Server

### Strategy 1: Direct Search Links

Provide the LLM with search URL patterns so it can construct searches:

```python
# Example MCP resource
search_template = """
To search Fluent documentation:
https://ansyshelp.ansys.com/public/account/secured?returnurl=/Views/Secured/search.html?q={query}&v=25.2&man="Fluent User's Guide"&pn="Fluent"&lang=en

Replace {query} with your search term (URL encode spaces as %20 or +)
"""
```

### Strategy 2: Direct Documentation Links

Provide links to key documentation sections:

```python
fluent_docs = {
    "user_guide_toc": "https://ansyshelp.ansys.com/public/account/secured?returnurl=/Views/Secured/corp/v252/en/flu_ug/flu_ug.html",
    "tui_commands": "https://ansyshelp.ansys.com/public/account/secured?returnurl=/Views/Secured/corp/v252/en/flu_tui/flu_tui.html",
    "theory_guide": "https://ansyshelp.ansys.com/public/account/secured?returnurl=/Views/Secured/corp/v252/en/flu_th/flu_th.html",
}
```

### Strategy 3: Instruct LLM to Use Web Tools

Provide instructions in MCP resources:

```markdown
## Finding Fluent Documentation

1. **Search for topics:**
   Use: https://ansyshelp.ansys.com/Views/Secured/search.html?q={topic}&v=25.2&man="Fluent User's Guide"&pn="Fluent"&lang=en

2. **Browse User Guide:**
   Start at: https://ansyshelp.ansys.com/Views/Secured/corp/v252/en/flu_ug/flu_ug.html

3. **TUI Commands:**
   See: https://ansyshelp.ansys.com/Views/Secured/corp/v252/en/flu_tui/flu_tui.html

Use your WebFetch tool to read these pages and extract relevant information.
```

---

## Common Documentation Topics

### TUI Commands
- **Search for:** "TUI commands", "text interface"
- **Direct link:** `.../flu_tui/...`
- **Categories:** file/, define/, solve/, report/, etc.

### Solver Setup
- **Search for:** "solver settings", "solution methods"
- **Guide section:** Part III: Solution Mode
- **Topics:** Pressure-based, density-based, steady, transient

### Mesh Operations
- **Search for:** "mesh quality", "meshing workflow"
- **Guide section:** Part II: Meshing Mode
- **Topics:** Watertight, fault-tolerant, quality checks

### Boundary Conditions
- **Search for:** "boundary conditions", "inlet", "outlet"
- **Guide section:** Solution Mode > Physics Setup
- **Topics:** Velocity inlet, pressure outlet, wall, etc.

### Post-Processing
- **Search for:** "contour", "surface integral", "report"
- **Guide section:** Solution Mode > Results
- **Topics:** Plots, animations, data export

### Convergence
- **Search for:** "convergence", "residuals", "monitoring"
- **Guide section:** Solution Mode > Solution Controls
- **Topics:** Residuals, monitors, stopping criteria

---

## PDF Downloads

PDFs are also available:

```
https://ansyshelp.ansys.com/corp/v252/en/pdf/Ansys_Fluent_Users_Guide.pdf
```

**Pattern:** `.../corp/{VERSION}/en/pdf/Ansys_{Manual_Name}.pdf`

---

## Version-Specific Notes

### Latest Version (2025 R2 / v252)
- Most up-to-date documentation
- New features and workflows
- Recommended for new projects

### Compatibility
- Older versions available (back to 2024 R1)
- URL pattern remains consistent across versions
- Only change `v{code}` in URL

---

## MCP Implementation Recommendations

### Option 1: Static Links Resource (Simple)

Create an MCP resource that provides:
1. Base search URL template
2. Links to main documentation sections
3. Instructions for LLM to use WebFetch

**Pros:** Simple, no maintenance, works immediately
**Cons:** Relies on LLM's web tools

### Option 2: Search Proxy Tool (Advanced)

Create an MCP tool that:
1. Takes search query
2. Constructs search URL
3. Fetches results
4. Parses and returns formatted results

**Pros:** Structured output, better UX
**Cons:** More complex, needs HTML parsing

### Option 3: Hybrid Approach (Recommended)

1. **MCP Resource:** Provide URL patterns and instructions
2. **MCP Tool (help search):** Keep our static index for offline/quick reference
3. **Let LLM use WebFetch:** For detailed docs when needed

**Pros:** Best of both worlds - fast local search + comprehensive online docs
**Cons:** Requires LLM with web capabilities

---

## Example MCP Resource Content

```markdown
# ANSYS Fluent Documentation Resources

## Quick Search
Search Fluent docs: https://ansyshelp.ansys.com/Views/Secured/search.html?q={query}&v=25.2&man="Fluent User's Guide"&pn="Fluent"&lang=en

## Key Manuals (2025 R2)
- User Guide: https://ansyshelp.ansys.com/Views/Secured/corp/v252/en/flu_ug/flu_ug.html
- TUI Commands: https://ansyshelp.ansys.com/Views/Secured/corp/v252/en/flu_tui/flu_tui.html
- Theory Guide: https://ansyshelp.ansys.com/Views/Secured/corp/v252/en/flu_th/flu_th.html

## How to Use
1. Replace {query} with your search term in the search URL
2. Use your WebFetch tool to retrieve documentation
3. For TUI commands, check the static index first with search_help tool

## Version Info
- Current: 2025 R2 (v252)
- Format: v{year}{release} (e.g., v242 = 2024 R2)
```

---

## Testing the Documentation

To verify access and structure:

1. **Test search:**
   ```
   https://ansyshelp.ansys.com/Views/Secured/search.html?q=solve+iterate&v=25.2&pn="Fluent"&lang=en
   ```

2. **Test manual access:**
   ```
   https://ansyshelp.ansys.com/Views/Secured/corp/v252/en/flu_ug/flu_ug.html
   ```

3. **Test specific page:**
   ```
   https://ansyshelp.ansys.com/Views/Secured/corp/v252/en/flu_ug/flu_ug_sec_solve_calc.html
   ```

All should load without authentication for public documentation.

---

## Summary

**Key Findings:**
1. ✅ Public documentation accessible without login
2. ✅ Built-in search functionality works well
3. ✅ Consistent URL patterns across versions
4. ✅ Multiple manual types available
5. ✅ Direct linking to specific pages possible

**Best Approach for MCP:**
- Provide URL templates in MCP resources
- Let LLM use its WebFetch capabilities
- Keep static index for quick offline reference
- Don't need to build complex scraping infrastructure
