# ANSYS Fluent MCP Server - Architecture

## Vision

A Python-based MCP server that enables seamless integration between ANSYS Fluent and AI coding assistants through two main capabilities:

1. **Documentation Retrieval** - Search and access Fluent documentation
2. **PyFluent Integration** - Execute CFD operations via ANSYS PyFluent API

**Design Philosophy:** Following the MATLAB MCP server pattern, this server is designed to complement AI coding assistants by:

- **Documentation access** - Search and retrieve Fluent help documentation (always available)
- **Computational operations** - Leverage Fluent's CFD capabilities via PyFluent (optional)
- **Progressive enhancement** - Documentation works standalone; PyFluent adds execution
- **Fail-safe design** - Graceful degradation when Fluent/PyFluent unavailable

**Not in scope:** File system operations are handled by the coding assistant's native tools.

---

## Two Core Categories

### Category 1: Documentation Retrieval (Phase 1 - Current)

**Goal:** Provide instant access to Fluent documentation without requiring Fluent installation.

**Status:** ✅ **Implemented (v0.1.0)**

**Two-Tier Approach:**

#### Tier 1: Static Index (Offline, Fast) ✅
- Static index of 13+ common TUI commands and concepts
- Keyword-based search with relevance scoring
- Category filtering (io, solver, mesh, models, etc.)
- No external dependencies, works offline
- Sub-millisecond search time

**Tools:**
1. `search_help(query, category?, max_results?)` - Search static index
2. `list_categories()` - List available categories
3. `list_commands()` - List all indexed commands

#### Tier 2: Official ANSYS Help (Online, Comprehensive) ✅
- MCP Resource providing ANSYS Help URL patterns
- Search URL template for direct queries
- Links to User Guide, TUI Commands, Theory Guide, etc.
- LLM uses its WebFetch capabilities to retrieve docs

**Resources:**
1. `fluent://docs/online` - Guide to ANSYS Help documentation

**How It Works:**
1. **Quick answers:** LLM uses `search_help` tool (offline, instant)
2. **Detailed docs:** LLM uses ANSYS Help search URL + WebFetch
3. **No scraping needed:** Let the LLM's web tools do the work
4. **Best of both worlds:** Fast local + comprehensive online

**ANSYS Help Pattern:**
```
Search: https://ansyshelp.ansys.com/Views/Secured/search.html?q={query}&v=25.2&pn="Fluent"&lang=en
Manuals: https://ansyshelp.ansys.com/Views/Secured/corp/v252/en/{manual_code}/{page}.html
```

**Use Cases:**
- Learning Fluent commands (Tier 1: static index)
- Finding syntax and examples (Tier 1: static index)
- Understanding concepts (Tier 1: static index)
- Detailed documentation (Tier 2: ANSYS Help + WebFetch)
- Latest features and updates (Tier 2: always current online)

---

### Category 2: PyFluent Integration (Phase 2+ - Planned)

**Goal:** Enable execution of CFD operations through ANSYS PyFluent Python API.

**Status:** ⏳ **Planned**

**Features:**
- Connect to Fluent sessions (local or remote)
- Execute TUI commands programmatically
- Manage case/data files
- Query solution data
- Configure solver settings
- Monitor convergence
- Extract results

**Implementation:**
```python
# fluent_engine.py - PyFluent wrapper
class FluentEngine:
    """Wrapper around PyFluent for Fluent operations."""

    def __init__(self):
        self.session = None
        self.pyfluent_available = self._check_pyfluent()

    def connect(self, session_name: str = None) -> dict:
        """Connect to Fluent session."""
        import ansys.fluent.core as pyfluent
        self.session = pyfluent.launch_fluent() or pyfluent.connect_to_fluent()

    def execute_tui(self, command: str) -> dict:
        """Execute TUI command."""
        return self.session.tui.execute(command)

    def read_case(self, file_path: str) -> dict:
        """Read case file."""
        self.session.file.read_case(file_name=file_path)

    def get_solution_variable(self, var_name: str) -> dict:
        """Get solution variable data."""
        return self.session.fields.field_data[var_name]
```

**Planned Tools:**

**Basic Execution:**
- `execute_tui(command)` - Execute TUI command
- `execute_scheme(command)` - Execute Scheme command (if needed)

**Case Management:**
- `case_io(op, path)` - Read/write case and data files
  - `op="read_case"` - Load case file
  - `op="write_case"` - Save case file
  - `op="read_data"` - Load solution data
  - `op="write_data"` - Save solution data

**Workspace/Session:**
- `workspace(op, var?, value?)` - Manage Fluent variables
  - `op="list"` - List available variables
  - `op="get"` - Get variable value
  - `op="set"` - Set variable value
- `session(op, session_name?)` - Manage Fluent sessions
  - `op="list"` - List available sessions
  - `op="connect"` - Connect to session
  - `op="current"` - Get current session info
  - `op="launch"` - Launch new session

**Environment:**
- `env(op, name?)` - Environment information
  - `op="version"` - Get Fluent version
  - `op="license"` - Check license info
  - `op="addons"` - List installed addons

**Solver Operations:**
- `solve(iterations?, time_steps?, settings?)` - Run solver
- `monitor_convergence(criteria?)` - Track convergence
- `solver_settings(op, settings?)` - Configure solver

**Mesh Operations:**
- `mesh_info(op)` - Get mesh information
  - `op="stats"` - Mesh statistics
  - `op="quality"` - Quality metrics
  - `op="zones"` - List zones
- `mesh_check()` - Validate mesh quality

**Boundary Conditions:**
- `boundary_conditions(op, zone?, bc_type?, settings?)` - Manage BCs
  - `op="list"` - List all BCs
  - `op="get"` - Get BC settings for zone
  - `op="set"` - Set BC for zone

**Post-Processing:**
- `post_process(op, variable?, options?)` - Extract results
  - `op="surface_integral"` - Compute surface integrals
  - `op="volume_integral"` - Compute volume integrals
  - `op="export_data"` - Export solution data
  - `op="create_plot"` - Generate plots

**Use Cases:**
- Execute Fluent workflows from Claude
- Automate repetitive setup tasks
- Run parametric studies
- Monitor long-running simulations
- Extract and analyze results

---

## Technology Stack

### Core Dependencies
- **Python 3.10+** - Core language
- **uv** - Fast Python package manager
- **FastMCP** - Lightweight MCP server framework

### Category 1: Documentation (Always Available)
- **No external dependencies** - Static JSON index
- Works without Fluent installation
- Offline-capable

### Category 2: PyFluent (Optional)
- **ansys-fluent-core** - ANSYS PyFluent API
- Requires Fluent installation
- Requires valid ANSYS license
- Optional dependency in pyproject.toml:
  ```toml
  [project.optional-dependencies]
  pyfluent = ["ansys-fluent-core>=0.19.0"]
  ```

---

## Project Structure

```
fluent-mcp-server/
├── src/fluent_mcp_server/
│   ├── __init__.py
│   ├── server.py              # FastMCP server
│   │
│   # Category 1: Documentation Retrieval
│   ├── help_search.py         # Search engine (✅ implemented)
│   │
│   # Category 2: PyFluent Integration
│   ├── fluent_engine.py       # PyFluent wrapper (⏳ planned)
│   ├── tools_execution.py     # Execution tools (⏳ planned)
│   ├── tools_mesh.py          # Mesh tools (⏳ planned)
│   ├── tools_solver.py        # Solver tools (⏳ planned)
│   ├── tools_postprocess.py   # Post-processing tools (⏳ planned)
│   └── resources.py           # MCP resources (⏳ planned)
│
├── md-files/
│   ├── ARCHITECTURE.md        # This file
│   ├── PLANNING.md            # Roadmap
│   ├── TOOLS.md               # Tool catalog
│   └── USERSTORY.md           # User scenarios
│
├── examples/
│   ├── basic_help_search.py   # Documentation example (✅)
│   ├── pyfluent_basic.py      # PyFluent example (⏳)
│   └── workflow_automation.py # Full workflow (⏳)
│
├── tests/
│   ├── test_help_search.py    # Doc tests (✅)
│   ├── test_fluent_engine.py  # PyFluent tests (⏳)
│   └── test_integration.py    # End-to-end tests (⏳)
│
├── pyproject.toml
├── Makefile
└── README.md
```

---

## Implementation Roadmap

### Phase 1: Documentation Retrieval ✅ **COMPLETE (v0.1.0)**

**Deliverables:**
- ✅ Static index with 13+ TUI commands
- ✅ Search engine with relevance scoring
- ✅ 3 MCP tools (search_help, list_categories, list_commands)
- ✅ 12 unit tests (100% passing)
- ✅ Example code and documentation

**No external dependencies required** - Works standalone

---

### Phase 2: PyFluent Basic Integration ⏳ **Next**

**Goals:**
- Connect to Fluent sessions
- Execute TUI commands
- Basic case I/O
- Environment queries

**Tools to Implement:**
1. `execute_tui(command)` - Execute TUI commands
2. `case_io(op, path)` - Read/write case/data files
3. `session(op, session_name?)` - Session management
4. `env(op)` - Version and license info

**Implementation Tasks:**
- [ ] Create `fluent_engine.py` with PyFluent wrapper
- [ ] Implement session connection (launch vs connect)
- [ ] Add TUI command execution
- [ ] Add case file I/O
- [ ] Error handling for Fluent/license issues
- [ ] Unit tests with mock PyFluent
- [ ] Integration tests (require Fluent)
- [ ] Update documentation

**Dependencies:**
```bash
uv pip install -e ".[pyfluent]"  # Installs ansys-fluent-core
```

**Acceptance Criteria:**
- Connect to Fluent successfully
- Execute "report/summary" and get output
- Read/write case files
- Graceful degradation if PyFluent unavailable

---

### Phase 3: Solver & Mesh Tools ⏳ **Future**

**Goals:**
- Mesh quality checks
- Solver configuration
- Convergence monitoring
- Basic boundary conditions

**Tools to Implement:**
1. `mesh_info(op)` - Mesh statistics and quality
2. `mesh_check()` - Validate mesh
3. `solve(iterations, settings?)` - Run solver
4. `monitor_convergence(criteria?)` - Track convergence
5. `boundary_conditions(op, zone?, settings?)` - Manage BCs

**Use Cases:**
- Automated mesh validation
- Quick solver runs from Claude
- Convergence tracking
- BC setup automation

---

### Phase 4: Post-Processing & Automation ⏳ **Future**

**Goals:**
- Result extraction
- Data export
- Plot generation
- Workflow templates

**Tools to Implement:**
1. `post_process(op, variable, options?)` - Extract results
2. `parametric_study(parameters, base_case)` - Parameter sweeps
3. `batch_process(cases)` - Run multiple cases
4. `workflow(name, options?)` - Template-based workflows

**Use Cases:**
- Automated result extraction
- Parametric studies
- Batch processing
- Industry-specific workflows

---

## Design Principles

### 1. Progressive Enhancement
- **Level 1:** Documentation works without Fluent
- **Level 2:** Add PyFluent for execution
- **Level 3:** Add workflow automation
- Users get value at each level

### 2. Graceful Degradation
```python
# Example: Handle missing PyFluent
try:
    import ansys.fluent.core as pyfluent
    PYFLUENT_AVAILABLE = True
except ImportError:
    PYFLUENT_AVAILABLE = False

@mcp.tool()
def execute_tui(command: str) -> str:
    if not PYFLUENT_AVAILABLE:
        return "PyFluent not available. Install with: uv pip install -e '.[pyfluent]'"
    # ... execute command
```

### 3. Clear Separation
- **Category 1** (docs) - `help_search.py` - No external deps
- **Category 2** (execution) - `fluent_engine.py` + `tools_*.py` - Requires PyFluent

### 4. Fail-Safe Operations
- Validate inputs before execution
- Check Fluent connection before commands
- Provide clear error messages
- Suggest fixes for common issues

### 5. Testability
- **Unit tests** - Mock PyFluent, test logic
- **Integration tests** - Require Fluent, test real execution
- **Documentation tests** - Always runnable

---

## Configuration

### User Configuration (.mcp.json)

**Documentation Only (No Fluent):**
```json
{
  "mcpServers": {
    "fluent": {
      "command": "uvx",
      "args": ["fluent-mcp-server"]
    }
  }
}
```

**With PyFluent Integration:**
```json
{
  "mcpServers": {
    "fluent": {
      "command": "uvx",
      "args": ["--from", "fluent-mcp-server[pyfluent]", "fluent-mcp-server"],
      "env": {
        "AWP_ROOT242": "/ansys_inc/v242",
        "FLUENT_VERSION": "2024R2"
      }
    }
  }
}
```

### Development Setup

**Documentation development (no Fluent needed):**
```bash
uv pip install -e ".[dev]"
make test  # Runs doc tests only
```

**PyFluent development (requires Fluent license):**
```bash
uv pip install -e ".[dev,pyfluent]"
export AWP_ROOT242=/path/to/ansys_inc/v242
make test-all  # Runs all tests including integration
```

---

## Success Metrics

### Phase 1 (Current) ✅
- [x] 12+ tests passing
- [x] Documentation search working
- [x] Zero external dependencies
- [x] Example code functional

### Phase 2 (Next)
- [ ] Connect to Fluent sessions
- [ ] Execute TUI commands successfully
- [ ] Read/write case files
- [ ] Handle PyFluent import errors gracefully
- [ ] 20+ tests passing (unit + integration)

### Phase 3 (Future)
- [ ] Mesh validation automated
- [ ] Solver runs from Claude
- [ ] Convergence monitoring working
- [ ] BC setup helpers functional

### Phase 4 (Future)
- [ ] Post-processing automation
- [ ] Parametric studies working
- [ ] Industry workflow templates
- [ ] 50+ tests, 90%+ coverage

---

## Security & Safety

### Category 1: Documentation
- **Low risk** - Read-only operations
- Static data only

### Category 2: PyFluent
- **Medium risk** - Can execute arbitrary TUI commands
- **Mitigations:**
  - Validate inputs before execution
  - Limit file system access (use assistant's tools)
  - Clear warnings for destructive operations
  - Require explicit confirmation for:
    - Deleting cases
    - Overwriting files
    - Modifying mesh
  - Sandbox mode for testing (future)

---

## Next Steps (Phase 2)

1. **Research PyFluent API**
   - Study ansys-fluent-core documentation
   - Test connection methods (launch vs connect)
   - Understand TUI execution interface

2. **Create FluentEngine wrapper**
   - Basic connection management
   - TUI command execution
   - Error handling

3. **Implement 4 core tools**
   - execute_tui
   - case_io
   - session
   - env

4. **Testing strategy**
   - Mock PyFluent for unit tests
   - Optional integration tests with real Fluent
   - CI/CD without Fluent license

5. **Documentation**
   - Update README with PyFluent setup
   - Add examples for each tool
   - Document environment variables
