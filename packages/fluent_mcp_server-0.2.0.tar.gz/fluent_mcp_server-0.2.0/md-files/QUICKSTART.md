# Fluent MCP Server - Quick Start Guide

## Installation & Setup

### 1. Install the MCP Server

From the project directory:

```bash
# Install in development mode with all dependencies
uv pip install -e ".[dev]"
```

### 2. Configure Claude Desktop/Code

Add to your Claude configuration file (`.mcp.json` or Claude Desktop settings):

```json
{
  "mcpServers": {
    "fluent": {
      "command": "uv",
      "args": [
        "--directory",
        "/Users/weiqi/Documents/dropbox-weiqi-api/fluent-mcp-server",
        "run",
        "fluent-mcp-server"
      ],
      "env": {
        "FLUENT_VERSION": "2025R2"
      }
    }
  }
}
```

**Important:** Update the `--directory` path to match your installation location.

### 3. Restart Claude

Restart Claude Desktop or reload Claude Code to load the MCP server.

---

## Available Tools

### Tool 1: `search_help` - Search Fluent Documentation

**Purpose:** Find TUI commands, concepts, and usage examples.

**Parameters:**
- `query` (required): Search term or question
- `category` (optional): Filter by category
- `max_results` (optional): Number of results (default: 5)

**Examples:**

```
Search for "iterate"
→ Returns solve/iterate command with examples

Search for "turbulence" with category "models"
→ Returns define/models/viscous command

Search for "mesh quality"
→ Returns Mesh Quality concept with metrics explained
```

**Available Categories:**
- `commands` - TUI commands
- `io` - File input/output
- `solver` - Solver settings
- `mesh` - Mesh operations
- `models` - Physical models
- `postprocessing` - Results and reports
- `theory` - Concepts and explanations

---

### Tool 2: `list_categories` - List All Categories

**Purpose:** See all available documentation categories.

**Parameters:** None

**Returns:** List of categories for filtering searches

---

### Tool 3: `list_commands` - List All Indexed Commands

**Purpose:** Browse all available TUI commands in the index.

**Parameters:** None

**Returns:** Complete list of indexed command names

---

## Available Resources

### Resource: `fluent://docs/online` - ANSYS Help Documentation Guide

**Purpose:** Instructions for accessing official ANSYS Fluent online documentation.

**Contains:**
- ANSYS Help search URL patterns
- Direct links to User Guide, TUI Commands, Theory Guide, UDF Manual
- Version information (2025 R2 / v252)
- How to use with LLM's WebFetch capabilities

**Usage:** LLM automatically retrieves this resource when detailed documentation is needed.

---

## Usage Examples

### Example 1: Find a Specific Command

**User:** "How do I run 100 iterations in Fluent?"

**MCP Server:**
1. Uses `search_help("iterate")`
2. Returns `solve/iterate` command with syntax
3. Provides example: `/solve/iterate 100`

---

### Example 2: Learn About Mesh Quality

**User:** "What mesh quality metrics should I check?"

**MCP Server:**
1. Uses `search_help("mesh quality")`
2. Returns Mesh Quality concept
3. Explains skewness, aspect ratio, orthogonality
4. Provides acceptable ranges for each metric

---

### Example 3: Detailed Documentation Lookup

**User:** "I need comprehensive information on turbulence models"

**MCP Server:**
1. Uses `search_help("turbulence")` for quick reference
2. Accesses `fluent://docs/online` resource
3. Constructs ANSYS Help search URL
4. Uses WebFetch to retrieve detailed Theory Guide content

---

### Example 4: Browse Available Commands

**User:** "What file I/O commands are available?"

**MCP Server:**
1. Uses `list_categories()` to show available categories
2. Uses `search_help(category="io")` to list all I/O commands
3. Returns: file/read-case, file/write-data, etc.

---

## Two-Tier Documentation Strategy

### Tier 1: Static Index (Offline, Fast)

**What it is:**
- Local JSON database with 13+ common TUI commands
- 3 concept articles (Convergence, Mesh Quality, Workflow)
- Keyword-based search with relevance scoring
- Works without internet connection

**When to use:**
- Quick command lookups
- Common operations (file I/O, solve, mesh check)
- Basic concepts and troubleshooting

**Speed:** <1ms search time

---

### Tier 2: ANSYS Help (Online, Comprehensive)

**What it is:**
- Official ANSYS Fluent documentation website
- Complete User Guide, Theory Guide, TUI Commands, UDF Manual
- Built-in search functionality
- Always up-to-date with latest Fluent features

**When to use:**
- Detailed theoretical background
- Advanced features not in static index
- Latest Fluent updates
- UDF programming guides

**Access:** Via MCP resource + LLM's WebFetch capability

---

## Current Coverage (v0.1.0)

### ✅ Well Covered (Excellent)

**These topics have excellent static index coverage:**

1. **File I/O Operations**
   - Reading/writing case and data files
   - File format information

2. **Mesh Quality**
   - Quality metrics explained
   - mesh/check and mesh/repair-improve commands

3. **Convergence Monitoring**
   - Concept with troubleshooting guidance
   - Residual monitoring

4. **Solver Execution**
   - solve/iterate command
   - Basic solver operations

5. **Reporting**
   - report/summary command
   - Basic result queries

---

### 🟡 Partial Coverage (Accessible via Tier 2)

**These topics work but need static index enhancement:**

1. **Turbulence Models**
   - define/models/viscous indexed
   - Needs expanded keywords (k-epsilon, k-omega, SST, DES, LES)

2. **Dynamic Mesh**
   - Accessible via online docs
   - Needs define/dynamic-mesh command entry

3. **Boundary Conditions**
   - Basic define/boundary-conditions indexed
   - Needs specific BC type examples

---

### ❌ Missing from Static Index (Critical Gaps)

**These topics require Tier 2 (online docs):**

1. **UDF/UDS Programming**
   - Not in static index
   - Fully accessible via UDF Manual (Tier 2)
   - **Planned:** Add concept entry + dedicated resource

2. **Porous Media Models**
   - Not in static index
   - Accessible via Theory Guide (Tier 2)
   - **Planned:** Add command entry

---

## Testing the MCP Server

### Command-Line Test

```bash
# Run the server in development mode
uv run fluent-mcp-server

# Run unit tests
uv run pytest tests/ -v

# Test search functionality directly
uv run python examples/basic_help_search.py
```

---

### In Claude Desktop/Code

**Test 1: Basic Search**
```
Ask: "How do I read a case file in Fluent?"
Expected: Returns file/read-case command with syntax
```

**Test 2: Category Search**
```
Ask: "Show me all mesh-related commands"
Expected: Lists mesh commands from static index
```

**Test 3: Concept Lookup**
```
Ask: "What is convergence in CFD?"
Expected: Returns Convergence concept with explanation
```

**Test 4: Online Documentation**
```
Ask: "I need detailed information about UDF programming"
Expected: Accesses fluent://docs/online resource and suggests UDF Manual URL
```

---

## Validation Against Real-World Questions

**Based on Reddit r/CFD analysis (see `/md-files/REDDIT_REAL_WORLD_EXAMPLES.md`):**

- ✅ **8/10 real user questions covered** (80% effective)
- 🟢 **5/10 questions excellent** (File I/O, mesh quality, convergence, solve, learning)
- 🟡 **3/10 questions partial** (Turbulence, dynamic mesh, BCs - accessible via Tier 2)
- ❌ **2/10 questions missing** (UDF, porous media - require Tier 2)

**Most common user needs fully addressed:**
1. ✅ File operations
2. ✅ Mesh validation
3. ✅ Convergence troubleshooting
4. ✅ Basic solver execution
5. ✅ Learning resources

---

## Next Steps (Roadmap)

### Phase 1 Enhancement (Current - v0.2.0)

**Priority 1 Improvements (~12 minutes):**
1. Add UDF/UDS concept entry
2. Add porous media command
3. Enhance turbulence model keywords

**Expected Impact:** 80% → 100% coverage of real-world questions

---

### Phase 2: PyFluent Integration (Planned)

**Capabilities:**
- Connect to Fluent sessions
- Execute TUI commands programmatically
- Read/write case files via API
- Query solution data
- Automate workflows

**Priority Tools:**
1. `execute_tui(command)` - Execute commands in Fluent
2. `case_io(op, path)` - Programmatic file handling
3. `mesh_check()` - Automated mesh quality reporting
4. `monitor_convergence(criteria?)` - Track convergence

**Requirement:** ANSYS Fluent installation + valid license

---

## Troubleshooting

### MCP Server Not Loading

**Check:**
1. Correct path in `.mcp.json` configuration
2. `uv` is installed and in PATH
3. Restart Claude after configuration changes

**Test manually:**
```bash
uv run fluent-mcp-server
# Should show FastMCP banner
```

---

### Search Returns No Results

**Possible causes:**
1. Query too specific - try broader terms
2. Topic not in static index - check online docs via Tier 2
3. Typo in search query

**Solutions:**
- Use `list_categories()` to see available topics
- Use `list_commands()` to browse all commands
- Try alternative keywords (e.g., "run" instead of "execute")

---

### Need More Detailed Documentation

**The static index is intentionally minimal for speed.**

For detailed documentation:
1. Use online documentation via Tier 2
2. LLM will automatically access `fluent://docs/online` resource
3. WebFetch retrieves comprehensive docs from ANSYS Help

---

## Documentation

**Key Files:**
- `/md-files/ARCHITECTURE.md` - Technical architecture and design
- `/md-files/REDDIT_REAL_WORLD_EXAMPLES.md` - Real user validation
- `/md-files/GAP_ANALYSIS.md` - Detailed coverage analysis
- `/md-files/USERSTORY.md` - User scenarios and examples
- `/md-files/TOOLS.md` - Complete tool catalog
- `/README.md` - Project overview

---

## Support & Feedback

**Found an issue or want to suggest improvements?**

1. Check existing documentation in `/md-files/`
2. Review gap analysis for known limitations
3. Test against real-world examples

**Development:**
```bash
# Install dev dependencies
uv pip install -e ".[dev]"

# Run tests
make test

# Check coverage
make test-coverage
```

---

## Current Status

**Version:** 0.1.0 (Phase 1 - Documentation Retrieval)

**Status:** ✅ **Production Ready** for documentation lookup

**Effectiveness:** 80% coverage of real-world user questions

**Next Release:** v0.2.0 with Priority 1 improvements (100% coverage target)
