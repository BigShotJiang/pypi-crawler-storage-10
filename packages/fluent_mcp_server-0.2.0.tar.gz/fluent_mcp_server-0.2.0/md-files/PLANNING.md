# Fluent MCP Server - Planning & Roadmap

## Vision

A robust, feature-rich MCP server that bridges ANSYS Fluent and AI coding assistants, enabling seamless integration for CFD workflows, documentation access, and automation.

**Design Philosophy:** Following the successful MATLAB MCP server pattern, this server focuses on:

- **Documentation access** - Instant search of Fluent commands and concepts
- **Computational operations** - Leverage Fluent's CFD capabilities
- **Data bridge** - Move data between files and Fluent workspace
- **Workflow automation** - Common CFD setup and analysis patterns

**Not in scope:** File system operations (handled by coding assistant's native tools)

## Current Architecture

### Core Components
- **MCP Server** (`server.py`) - FastMCP protocol implementation
- **Help Search** (`help_search.py`) - Documentation search engine
- **Tools** - MCP tool definitions (search_help, list_categories, list_commands)

### Current Features (v0.1.0)

**Status:** ✅ Phase 1 Complete

- [x] **Project Setup**
  - Python 3.10+ with uv package manager
  - FastMCP integration
  - Project structure following MATLAB MCP pattern
  - Git ignore and Python version configs

- [x] **Help Search Tool**
  - Static index with 13+ common Fluent TUI commands
  - 3 core concepts (TUI, Convergence, Mesh Quality)
  - Keyword-based search with relevance scoring
  - Category filtering (io, solver, mesh, models, etc.)
  - Multi-word query support
  - Case-insensitive search

- [x] **MCP Tools Implemented**
  - `search_help(query, category, max_results)` - Search documentation
  - `list_categories()` - List all available categories
  - `list_commands()` - List all indexed commands

- [x] **Testing**
  - 12 unit tests with 100% pass rate
  - Coverage: basic search, category filtering, relevance scoring
  - Test infrastructure with pytest + pytest-cov

- [x] **Documentation**
  - README with quick start guide
  - ARCHITECTURE.md with technical design
  - Example usage script (basic_help_search.py)
  - .mcp.json configuration example

## Feature Roadmap

### Phase 1: Basic Help Search ✅ COMPLETE

**Achievements:**
- ✅ Static documentation index
- ✅ Search with relevance scoring
- ✅ Category filtering
- ✅ FastMCP integration
- ✅ Comprehensive tests
- ✅ Example code

**Metrics:**
- 12/12 tests passing
- 13 commands indexed
- 3 concepts documented
- 9 categories available

---

### Phase 2: Enhanced Documentation

**Goals:**
- [ ] Expand command index to 50+ commands
- [ ] Add more detailed examples for each command
- [ ] Include common error messages and solutions
- [ ] Add workflow guides (e.g., "How to set up a basic simulation")
- [ ] PyFluent integration for dynamic help (if available)
- [ ] Web scraping fallback for online documentation

**Tools:**
- [ ] `get_command_details(command_name)` - Detailed info for specific command
- [ ] `search_errors(error_message)` - Search for error solutions
- [ ] `get_workflow(workflow_name)` - Get step-by-step workflow guides

---

### Phase 3: Core Fluent Integration

**Goals:**
- [ ] Connect to running Fluent session
- [ ] Execute TUI commands
- [ ] Workspace variable management
- [ ] Case/data file I/O

**Tools:**
- [ ] `execute_tui(command)` - Execute TUI command in Fluent
- [ ] `workspace(op, var, value)` - Get/set/list/clear workspace
- [ ] `case_io(op, path)` - Read/write case and data files
- [ ] `env(op)` - Get Fluent version and license info

**Architecture:**
```python
class FluentEngine:
    """Wrapper around PyFluent or direct TUI interaction."""

    def connect(self, session_name: str = None) -> dict:
        """Connect to Fluent session."""
        pass

    def execute_tui(self, command: str) -> dict:
        """Execute TUI command."""
        pass

    def get_variable(self, var_name: str) -> Any:
        """Get workspace variable."""
        pass
```

---

### Phase 4: Workflow Automation

**Goals:**
- [ ] Mesh quality checks and reporting
- [ ] Boundary condition setup helpers
- [ ] Solver settings configuration
- [ ] Post-processing automation
- [ ] Convergence monitoring

**Tools:**
- [ ] `mesh_quality(check_type)` - Check and report mesh quality
- [ ] `setup_bc(zone, bc_type, settings)` - Setup boundary conditions
- [ ] `configure_solver(settings_dict)` - Configure solver parameters
- [ ] `post_process(variable, operation)` - Extract results
- [ ] `monitor_convergence()` - Track convergence status

---

### Phase 5: Advanced Features

**Goals:**
- [ ] Parametric study automation
- [ ] Batch processing and queuing
- [ ] Result comparison tools
- [ ] Report generation
- [ ] Performance optimization

**Tools:**
- [ ] `parametric_study(parameters, ranges)` - Run parameter sweeps
- [ ] `batch_process(cases)` - Queue multiple simulations
- [ ] `compare_results(case1, case2)` - Compare two cases
- [ ] `generate_report(template)` - Create formatted reports

---

## Technology Decisions

### Why FastMCP?
- **Lightweight** - Simpler than full `mcp` package
- **Fast** - Minimal overhead
- **Pythonic** - Decorator-based API
- **Well-documented** - Clear examples and patterns

### Why uv?
- **Fast** - 10-100x faster than pip
- **Modern** - Python 3.10+ best practices
- **Simple** - One tool for venv + packages
- **Reliable** - Consistent dependency resolution

### Why Static Index First?
- **No dependencies** - Works without Fluent installed
- **Fast** - Sub-millisecond search
- **Predictable** - No version compatibility issues
- **Testable** - Easy to unit test

---

## Success Metrics

### Phase 1 (Current) ✅
- [x] All tests passing (12/12)
- [x] Example code working
- [x] Documentation complete
- [x] Ready for MCP client integration

### Phase 2 Target
- [ ] 50+ commands indexed
- [ ] PyFluent integration working
- [ ] <100ms average query time
- [ ] 90%+ test coverage

### Phase 3 Target
- [ ] Execute TUI commands reliably
- [ ] Read/write case files
- [ ] Workspace variable management
- [ ] Error handling for all operations

### Phase 4 Target
- [ ] 10+ workflow templates
- [ ] Automated mesh quality checks
- [ ] BC setup helpers for common cases
- [ ] Post-processing automation

---

## Design Principles

1. **Token Efficiency** - Minimize API calls by combining operations
2. **Fail-Safe** - Graceful degradation when Fluent unavailable
3. **Self-Documenting** - Clear tool descriptions and schemas
4. **Modular** - Easy to add new tools and capabilities
5. **Testable** - Unit tests for all components
6. **Pythonic** - Follow Python best practices with type hints
7. **Learning from MATLAB MCP** - Reuse proven patterns and architecture

---

## Next Steps

**Immediate (Phase 2):**
1. Expand command index to 30+ commands
2. Add workflow guides (basic setup, turbulence modeling, etc.)
3. Improve relevance scoring algorithm
4. Add command parameter documentation

**Short-term (Phase 3):**
1. Investigate PyFluent integration options
2. Design FluentEngine wrapper
3. Implement TUI command execution
4. Add session management

**Long-term (Phase 4+):**
1. Build workflow automation library
2. Create template system for common cases
3. Develop result comparison tools
4. Implement parametric study framework

---

## Community & Contributions

**Contributing:**
- Follow existing code style (black, isort)
- Add tests for new features
- Update documentation
- Run `pytest` before committing

**Issues & Feedback:**
- Report bugs with minimal reproducible examples
- Request features with use cases
- Share workflow examples

**Resources:**
- MATLAB MCP Server: https://github.com/subspace-lab/matlab-mcp-server
- FastMCP: https://github.com/jlowin/fastmcp
- ANSYS Fluent Docs: https://ansyshelp.ansys.com/
