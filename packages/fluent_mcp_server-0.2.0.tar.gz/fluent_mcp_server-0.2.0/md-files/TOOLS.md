# Fluent MCP Server - Tools Catalog

This document provides detailed documentation for all available MCP tools.

## Table of Contents

- [search_help](#search_help) - Search Fluent documentation
- [list_categories](#list_categories) - List documentation categories
- [list_commands](#list_commands) - List all indexed commands

---

## search_help

Search ANSYS Fluent documentation for commands, concepts, and usage examples.

### Signature

```python
def search_help(
    query: str,
    category: str | None = None,
    max_results: int = 5
) -> str
```

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| query | str | Yes | - | Search term or question (e.g., "iterate", "read case", "turbulence model") |
| category | str | No | None | Filter by category (commands/theory/setup/solver/postprocessing/io/mesh/parallel/models) |
| max_results | int | No | 5 | Maximum number of results to return |

### Returns

Formatted string containing:
- Number of results found
- For each result:
  - Name and type (command/concept)
  - Category
  - Relevance score
  - Summary
  - Description
  - Examples (if available)
- Available categories (footer)

### Examples

#### Basic Search

```python
# Search for iteration commands
search_help("iterate")

# Returns:
# Found 1 result(s) for 'iterate':
#
# 1. solve/iterate (command, solver)
#    Relevance: 3.95
#
#    Perform iterations to solve the current case
#
#    Execute solution iterations. Syntax: solve/iterate <num_iterations>
#
#    Examples:
#      - solve/iterate 100
#      - solve/iterate 1000
```

#### Search with Category Filter

```python
# Search for read commands in I/O category
search_help("read", category="io", max_results=3)

# Returns:
# Found 2 result(s) for 'read':
#
# 1. file/read-case (command, io)
#    ...
# 2. file/read-data (command, io)
#    ...
```

#### Multi-word Query

```python
# Search for turbulence model
search_help("turbulence model")

# Returns results about viscous models and turbulence settings
```

### Use Cases

1. **Learning Fluent Commands**
   - "How do I run iterations?" → search_help("iterate")
   - "How to save a case?" → search_help("save case")

2. **Finding Specific Operations**
   - search_help("boundary conditions")
   - search_help("mesh quality")
   - search_help("convergence")

3. **Category-specific Browsing**
   - search_help("", category="io") - All I/O commands
   - search_help("", category="solver") - All solver commands

4. **Troubleshooting**
   - search_help("mesh check")
   - search_help("residuals")

---

## list_categories

List all available documentation categories.

### Signature

```python
def list_categories() -> str
```

### Parameters

None

### Returns

Formatted string listing all available categories with usage instructions.

### Example

```python
list_categories()

# Returns:
# Available Fluent documentation categories:
#
#   - general
#   - io
#   - mesh
#   - models
#   - parallel
#   - postprocessing
#   - setup
#   - solver
#   - theory
#
# Use these with search_help(query, category=...) to filter results.
```

### Use Cases

1. **Discovering Available Topics**
   - See what areas of Fluent are documented
   - Plan targeted searches

2. **Category-based Navigation**
   - Find the right category for your task
   - Filter search results effectively

---

## list_commands

List all indexed Fluent TUI commands.

### Signature

```python
def list_commands() -> str
```

### Parameters

None

### Returns

Formatted string listing all indexed command names with count and usage instructions.

### Example

```python
list_commands()

# Returns:
# Indexed Fluent commands (13 total):
#
#   - solve/iterate
#   - file/read-case
#   - file/write-case
#   - file/read-data
#   - file/write-data
#   - define/models/viscous
#   - define/boundary-conditions
#   - solve/monitors/residual
#   - report/summary
#   - display/contour
#   - parallel/timer/usage
#   - mesh/check
#   - adapt/gradient
#
# Use search_help(query) to get detailed information about any command.
```

### Use Cases

1. **Quick Reference**
   - See all available commands at a glance
   - Find command names for search

2. **Documentation Coverage**
   - Check which commands are documented
   - Verify command availability

---

## Indexed Content Summary

### Commands (13 total)

| Command | Category | Description |
|---------|----------|-------------|
| solve/iterate | solver | Perform iterations to solve the current case |
| file/read-case | io | Read a case file into Fluent |
| file/write-case | io | Write the current case to a file |
| file/read-data | io | Read solution data from a file |
| file/write-data | io | Write solution data to a file |
| define/models/viscous | models | Set the viscous model (laminar, turbulent, etc.) |
| define/boundary-conditions | setup | Set boundary conditions for zones |
| solve/monitors/residual | solver | Set residual convergence criteria |
| report/summary | postprocessing | Display a summary of the current case |
| display/contour | postprocessing | Create contour plots of solution variables |
| parallel/timer/usage | parallel | Display parallel performance statistics |
| mesh/check | mesh | Check mesh quality and report issues |
| adapt/gradient | mesh | Adapt mesh based on gradients |

### Concepts (3 total)

| Concept | Category | Description |
|---------|----------|-------------|
| TUI Commands | general | Text User Interface command structure |
| Convergence | theory | Understanding solution convergence |
| Mesh Quality | mesh | Mesh quality metrics and best practices |

### Categories (9 total)

- **general** - General concepts and TUI basics
- **io** - File input/output operations
- **mesh** - Mesh operations and quality
- **models** - Physical models and turbulence
- **parallel** - Parallel computing and performance
- **postprocessing** - Results visualization and reporting
- **setup** - Case setup and boundary conditions
- **solver** - Solution controls and monitoring
- **theory** - Theoretical concepts and convergence

---

## Search Algorithm

The search tool uses a weighted relevance scoring system:

### Scoring Weights

| Match Type | Score |
|------------|-------|
| Exact match in name | 2.0 |
| Exact match in summary | 1.5 |
| Keyword match | 1.0 |
| Partial match in description | 0.5 |
| Word match in name | 0.3 |
| Word match in summary | 0.2 |
| Word match in keywords | 0.15 |

### Features

- **Case-insensitive** - "iterate", "ITERATE", "Iterate" all work
- **Multi-word support** - "read case" matches "file/read-case"
- **Keyword expansion** - Searches name, summary, description, keywords
- **Relevance sorting** - Best matches appear first
- **Category filtering** - Narrow results to specific areas

---

## Future Tools (Planned)

### Phase 2: Enhanced Documentation
- `get_command_details(command_name)` - Detailed info for specific command
- `search_errors(error_message)` - Search for error solutions
- `get_workflow(workflow_name)` - Get step-by-step workflow guides

### Phase 3: Core Fluent Integration
- `execute_tui(command)` - Execute TUI command in Fluent
- `workspace(op, var, value)` - Get/set/list/clear workspace
- `case_io(op, path)` - Read/write case and data files
- `env(op)` - Get Fluent version and license info

### Phase 4: Workflow Automation
- `mesh_quality(check_type)` - Check and report mesh quality
- `setup_bc(zone, bc_type, settings)` - Setup boundary conditions
- `configure_solver(settings_dict)` - Configure solver parameters
- `post_process(variable, operation)` - Extract results

See [PLANNING.md](PLANNING.md) for complete roadmap.
