# User Stories and Scenarios (Fluent MCP Server)

## Personas
- **Claude Desktop User**: Conversational workflow; wants quick help and guidance on Fluent commands.
- **Claude Code User**: In-editor iteration; wants to automate CFD workflows and access documentation.
- **CFD Engineer**: Running simulations, setting up cases, analyzing results, automation.
- **Fluent Power User**: Complex cases, batch processing, custom workflows, scripting.

---

## Real-World Examples from Reddit r/CFD

**Source:** Reddit r/CFD community (January 2025)
**Validation:** These are actual user questions testing our MCP server design.

### Example 1: DES Turbulence Convergence Issues
**User Question:** "No convergence (DES Turbulence model)"
**User Need:** Understanding DES setup and convergence troubleshooting

**How MCP Server Helps:**
- ✅ Tier 1: `search_help("convergence")` → Convergence concept with troubleshooting
- 🟡 Tier 1: `search_help("turbulence")` → define/models/viscous (needs enhancement)
- ✅ Tier 2: Online docs via ANSYS Help search for DES-specific guidance

**Gap:** Turbulence keywords need expansion (k-epsilon, k-omega, SST, DES, LES)

### Example 2: UDF Implementation Help
**User Question:** "UDS and UDF implementation on ANSYS Fluent"
**User Need:** Learning UDF workflow and syntax

**How MCP Server Helps:**
- ❌ Tier 1: `search_help("udf")` → No results (MISSING)
- ✅ Tier 2: UDF Manual accessible via resource URL

**Gap:** Need UDF/UDS concept entry + dedicated MCP resource

### Example 3: Dynamic Mesh Setup
**User Question:** "Dynamic Mesh/Solid Motion - Fluent vs. Star"
**User Need:** Understanding dynamic mesh capabilities and setup

**How MCP Server Helps:**
- 🟡 Tier 1: `search_help("dynamic mesh")` → Returns mesh/check (weak match)
- ✅ Tier 2: User Guide Dynamic Mesh chapter via ANSYS Help

**Gap:** Need define/dynamic-mesh command entry

### Example 4: Porous Media Configuration
**User Question:** "Darcy Porous model negative coefficients"
**User Need:** Setting up porous zones and troubleshooting coefficients

**How MCP Server Helps:**
- ❌ Tier 1: `search_help("porous")` → No results (MISSING)
- ✅ Tier 2: Theory Guide porous media section via ANSYS Help

**Gap:** Need porous media command/concept entry

### Example 5: Visualizing URANS/LES Transition
**User Question:** "Visualising switch from URANS to LES in DES ANSYS FLUENT"
**User Need:** Post-processing and field variable visualization

**How MCP Server Helps:**
- ✅ Tier 1: `search_help("report")` → report/summary command
- ✅ Tier 2: Field variable documentation via ANSYS Help

**Enhancement:** Add surface creation and custom field function commands

### Example 6: Learning CFD Fundamentals
**User Question:** "How do you learn to model for CFD?"
**User Need:** Structured learning path and best practices

**How MCP Server Helps:**
- ✅ Tier 2: User Guide Part I: Getting Started accessible
- ✅ MCP resource provides clear navigation to tutorials

**Works well** - Good onboarding guidance available

### Example 7: Mesh Quality Validation
**User Question:** (Common topic) "Checking mesh quality and fixing issues"
**User Need:** Understanding quality metrics and improvement workflows

**How MCP Server Helps:**
- ✅ Tier 1: `search_help("mesh quality")` → Excellent concept with metrics explained
- ✅ Tier 1: `search_help("mesh check")` → mesh/check and mesh/repair-improve

**Excellent coverage** - One of our strongest areas

### Example 8: Boundary Condition Setup
**User Question:** (Frequent topic) "Setting up inlet/outlet BCs"
**User Need:** Configuring boundary conditions for various zone types

**How MCP Server Helps:**
- ✅ Tier 1: `search_help("boundary conditions")` → define/boundary-conditions
- ✅ Tier 2: BC chapter in User Guide

**Enhancement:** Add specific BC type examples (velocity-inlet, pressure-outlet, wall)

### Example 9: Solver Settings Optimization
**User Question:** (Common troubleshooting) "Choosing pressure-velocity coupling, under-relaxation"
**User Need:** Configuring solver for stability and convergence

**How MCP Server Helps:**
- ✅ Tier 1: `search_help("solve")` → solve/iterate command
- ✅ Tier 2: Solution Methods chapter via ANSYS Help

**Enhancement:** Add solve/set/ commands for solver controls

### Example 10: Case File Management
**User Question:** (Operational need) "Reading/writing case and data files"
**User Need:** File I/O and batch processing workflows

**How MCP Server Helps:**
- ✅ Tier 1: `search_help("file")` → Excellent coverage (read-case, write-data, etc.)
- ✅ Tier 2: File formats documentation

**Excellent coverage** - Fully addresses file I/O needs

**Summary of Real-World Validation:**
- ✅ **8/10 examples covered** by current MCP server (80% effective)
- 🟢 **5/10 examples excellent** - File I/O, mesh quality, convergence, solve, learning
- 🟡 **3/10 examples partial** - Turbulence, dynamic mesh, BCs (accessible via Tier 2)
- ❌ **2/10 examples missing** - UDF, porous media (critical gaps)

**See:** `/md-files/REDDIT_REAL_WORLD_EXAMPLES.md` and `/md-files/GAP_ANALYSIS.md` for detailed analysis.

---

## Phase 1: Documentation & Help (v0.1.0 - Current)

### Scenario 1: Learning Fluent Commands (Claude Desktop)
- As a new Fluent user, I ask "How do I run iterations in Fluent?" and get command documentation.
- **Acceptance**
  - Search returns relevant TUI commands
  - Examples and syntax shown
  - Quick copy-paste ready commands
- **Tools**
  - `search_help(query="iterate")`
  - `list_categories()` (to browse topics)
  - `list_commands()` (to see all available commands)

### Scenario 2: Finding File I/O Commands (Claude Code)
- As a developer, I need to know how to read/write case and data files.
- **Acceptance**
  - Category filtering works (category="io")
  - Both read and write commands shown
  - File format examples provided (.cas, .dat, .cas.h5)
- **Tools**
  - `search_help(query="read case", category="io")`
  - `search_help(query="write data", category="io")`

### Scenario 3: Setting Up Turbulence Models
- As a CFD engineer, I ask "What turbulence models are available?"
- **Acceptance**
  - Viscous model commands returned
  - Common models documented (k-epsilon, k-omega, SST)
  - Syntax examples for each model
- **Tools**
  - `search_help(query="turbulence")`
  - `search_help(query="viscous model", category="models")`

### Scenario 4: Understanding Convergence
- As a user, I want to understand convergence monitoring and criteria.
- **Acceptance**
  - Concept explanation provided
  - Residual monitoring commands shown
  - Typical convergence targets documented
- **Tools**
  - `search_help(query="convergence")`
  - `search_help(query="residual", category="solver")`

### Scenario 5: Mesh Quality Checks
- As an engineer, I need to verify mesh quality before running.
- **Acceptance**
  - mesh/check command documented
  - Quality metrics explained (skewness, aspect ratio)
  - Acceptable ranges provided
- **Tools**
  - `search_help(query="mesh quality")`
  - `search_help(query="mesh check", category="mesh")`

---

## Phase 2: Core Fluent Integration (Planned)

### Scenario 6: Execute TUI Commands (Claude Code)
- As a user, I want to execute Fluent TUI commands from Claude.
- **Acceptance**
  - Connect to running Fluent session
  - Execute commands and see output
  - Error messages surfaced clearly
- **Tools (Future)**
  - `execute_tui(command="solve/iterate 100")`
  - `execute_tui(command="report/summary")`
  - `env(op="version")` - Check Fluent version

### Scenario 7: Case File Management
- As a CFD engineer, I want to load a case, modify settings, and save.
- **Acceptance**
  - Case files loaded successfully
  - Modifications applied via TUI
  - Case saved with new name
- **Tools (Future)**
  - `case_io(op="read_case", path="simulation.cas")`
  - `execute_tui(command="define/models/viscous/k-epsilon-standard yes")`
  - `case_io(op="write_case", path="simulation_modified.cas")`

### Scenario 8: Solution Monitoring
- As an engineer, I want to check solution progress and convergence.
- **Acceptance**
  - Residuals retrieved and displayed
  - Iteration count shown
  - Convergence status reported
- **Tools (Future)**
  - `workspace(op="get", var="residuals")`
  - `execute_tui(command="solve/monitors/residual/print")`
  - `report(op="convergence_status")`

---

## Phase 3: Workflow Automation (Planned)

### Scenario 9: Automated Mesh Quality Report
- As a CFD engineer, I want automated mesh quality analysis with recommendations.
- **Acceptance**
  - Mesh statistics computed automatically
  - Quality metrics highlighted (skewness > 0.95, etc.)
  - Recommendations provided for fixing issues
- **Tools (Future)**
  - `mesh_quality(check_type="comprehensive")`
  - `mesh_quality(check_type="skewness", threshold=0.95)`
  - `report(op="mesh_summary")`

### Scenario 10: Batch Boundary Condition Setup
- As an engineer, I want to set up common BC patterns quickly.
- **Acceptance**
  - Template-based BC setup
  - Multiple zones configured at once
  - Settings validated before application
- **Tools (Future)**
  - `setup_bc(zone="inlet", bc_type="velocity_inlet", velocity=10, direction=[1,0,0])`
  - `setup_bc(zone="outlet", bc_type="pressure_outlet", pressure=0)`
  - `validate_bc(zone="inlet")` - Check BC settings

### Scenario 11: Solver Configuration Wizard
- As a user, I want guidance on solver settings for my case type.
- **Acceptance**
  - Case type detected (steady/transient, compressible/incompressible)
  - Recommended solver settings provided
  - Settings applied automatically or as script
- **Tools (Future)**
  - `configure_solver(case_type="steady_incompressible")`
  - `configure_solver(custom={"under_relaxation": 0.3, "scheme": "second_order"})`
  - `validate_solver_settings()` - Check for common issues

### Scenario 12: Post-Processing Automation
- As a CFD engineer, I want to extract results and create standard plots.
- **Acceptance**
  - Variables extracted (pressure, velocity, etc.)
  - Contour plots generated automatically
  - Reports exported (CSV, images)
- **Tools (Future)**
  - `post_process(operation="extract", variable="pressure", location="outlet")`
  - `post_process(operation="contour", variable="velocity-magnitude", save_path="velocity.png")`
  - `post_process(operation="line_plot", variable="pressure", line="centerline")`

---

## Phase 4: Advanced Features (Planned)

### Scenario 13: Parametric Study Automation
- As a researcher, I want to run parameter sweeps (inlet velocity, temperature, etc.).
- **Acceptance**
  - Parameters defined with ranges
  - Multiple cases run automatically
  - Results collected and compared
- **Tools (Future)**
  - `parametric_study(parameters={"inlet_velocity": [5, 10, 15, 20]}, base_case="base.cas")`
  - `parametric_study(parameters={"temperature": range(300, 400, 10)})`
  - `compare_results(cases=["case1.dat", "case2.dat"], variable="drag")`

### Scenario 14: Convergence Monitoring with Auto-Stop
- As an engineer, I want the solver to stop automatically when converged.
- **Acceptance**
  - Convergence criteria monitored in real-time
  - Solver stops when criteria met
  - Notification sent when complete
- **Tools (Future)**
  - `monitor_convergence(criteria={"residuals": 1e-6, "check_interval": 50})`
  - `execute_with_monitoring(command="solve/iterate 10000", stop_on_convergence=True)`

### Scenario 15: Batch Processing Multiple Cases
- As a power user, I want to queue multiple simulations to run sequentially.
- **Acceptance**
  - Multiple cases queued
  - Progress tracking for all cases
  - Results organized by case name
- **Tools (Future)**
  - `batch_process(cases=["case1.cas", "case2.cas", "case3.cas"], iterations=1000)`
  - `batch_status()` - Check queue status
  - `batch_results()` - Get results summary

---

## Industry-Specific Scenarios

**Note:** Tool names below are simplified for readability. Actual tools will use the multi-operation format.

### Scenario 16: Aerospace – External Aerodynamics (Wing/Airfoil)
- As an aerospace engineer, I analyze flow over a wing to compute lift and drag.
- **Acceptance**
  - Mesh imported and validated
  - Boundary conditions set (velocity inlet, pressure far-field)
  - Lift/drag coefficients computed
  - Pressure distribution plotted
- **Tools (Future)**
  - `case_io(op="read_case", path="wing.cas")`
  - `mesh_quality(check_type="comprehensive")`
  - `setup_bc(zone="farfield", bc_type="pressure_far_field", mach=0.8)`
  - `solve(iterations=5000, monitor="cl_cd")`
  - `post_process(op="force_coefficients", zones=["wing"])`
  - `post_process(op="contour", variable="pressure", view="top")`

### Scenario 17: Automotive – Underhood Thermal Management
- As an automotive engineer, I simulate engine compartment cooling.
- **Acceptance**
  - Conjugate heat transfer enabled
  - Temperature distribution computed
  - Hot spots identified
  - Cooling effectiveness evaluated
- **Tools (Future)**
  - `configure_solver(case_type="conjugate_heat_transfer")`
  - `setup_bc(zone="radiator", bc_type="fan", mass_flow_rate=0.5)`
  - `solve(iterations=3000)`
  - `post_process(op="temperature_map", component="engine_block")`
  - `post_process(op="hotspot_analysis", threshold=373)` # K

### Scenario 18: HVAC – Room Ventilation and Comfort
- As an HVAC engineer, I analyze air distribution and thermal comfort.
- **Acceptance**
  - Room geometry with vents modeled
  - Age of air computed
  - PMV/PPD comfort indices calculated
  - Velocity streamlines visualized
- **Tools (Future)**
  - `setup_bc(zone="supply", bc_type="velocity_inlet", temperature=293)`
  - `configure_solver(models=["energy", "species_transport"])`
  - `post_process(op="age_of_air")`
  - `post_process(op="comfort_indices")`
  - `post_process(op="streamlines", seed_surface="floor")`

### Scenario 19: Turbomachinery – Compressor/Turbine Analysis
- As a turbomachinery engineer, I analyze compressor stage performance.
- **Acceptance**
  - Moving reference frame/mixing plane set up
  - Pressure ratio and efficiency computed
  - Blade loading visualized
- **Tools (Future)**
  - `configure_solver(case_type="rotating_machinery")`
  - `setup_bc(zone="rotor", bc_type="wall", motion="rotating", rpm=15000)`
  - `post_process(op="turbo_performance", stage="compressor")`
  - `post_process(op="blade_loading", blade="rotor_blade_1")`

### Scenario 20: Chemical Processing – Multiphase Reactor
- As a chemical engineer, I simulate multiphase flow in a reactor.
- **Acceptance**
  - VOF/Eulerian multiphase model configured
  - Species reactions enabled
  - Phase distribution computed
  - Residence time analyzed
- **Tools (Future)**
  - `configure_solver(models=["multiphase_vof", "species_transport"])`
  - `setup_bc(zone="gas_inlet", bc_type="velocity_inlet", phases={"air": 1.0})`
  - `setup_bc(zone="liquid_inlet", bc_type="velocity_inlet", phases={"water": 1.0})`
  - `post_process(op="phase_contours", phase="water")`
  - `post_process(op="residence_time")`

### Scenario 21: Electronics Cooling – Heat Sink Performance
- As an electronics engineer, I optimize heat sink design for chip cooling.
- **Acceptance**
  - Conjugate heat transfer with solid domains
  - Heat source applied to chip
  - Junction temperature computed
  - Thermal resistance calculated
- **Tools (Future)**
  - `configure_solver(case_type="conjugate_heat_transfer")`
  - `setup_bc(zone="chip", bc_type="wall", heat_flux=50000)` # W/m²
  - `setup_bc(zone="fan", bc_type="velocity_inlet", velocity=2)`
  - `solve(iterations=2000)`
  - `post_process(op="max_temperature", zone="chip")`
  - `post_process(op="thermal_resistance")`

### Scenario 22: Combustion – Burner Design
- As a combustion engineer, I analyze flame structure and emissions.
- **Acceptance**
  - Combustion model configured (EDM/PDF/FGM)
  - Fuel/air mixing analyzed
  - NOx emissions predicted
  - Flame temperature visualized
- **Tools (Future)**
  - `configure_solver(models=["combustion_edm", "species_transport", "nox"])`
  - `setup_bc(zone="fuel_inlet", bc_type="velocity_inlet", species={"ch4": 1.0})`
  - `setup_bc(zone="air_inlet", bc_type="velocity_inlet", species={"o2": 0.21, "n2": 0.79})`
  - `post_process(op="species_contours", species="nox")`
  - `post_process(op="temperature_contours")`

### Scenario 23: Marine – Ship Hull Resistance
- As a naval architect, I compute wave resistance for a hull design.
- **Acceptance**
  - VOF free surface tracking enabled
  - Wave pattern computed
  - Resistance force calculated
  - Wave cuts exported
- **Tools (Future)**
  - `configure_solver(case_type="multiphase_vof", moving_mesh=True)`
  - `setup_bc(zone="inlet", bc_type="velocity_inlet", velocity=5, wave_bc=True)`
  - `solve(iterations=5000, time_step=0.01)`
  - `post_process(op="wave_pattern", view="top")`
  - `post_process(op="force_coefficients", component="resistance")`

### Scenario 24: Biomedical – Blood Flow in Artery
- As a biomedical engineer, I analyze hemodynamics in patient-specific geometry.
- **Acceptance**
  - Non-Newtonian blood model applied
  - Pulsatile inlet BC set up
  - Wall shear stress computed
  - Flow separation identified
- **Tools (Future)**
  - `configure_solver(models=["non_newtonian", "transient"])`
  - `setup_bc(zone="inlet", bc_type="velocity_inlet", profile="pulsatile", period=0.8)`
  - `solve(time_steps=1000, time_step=0.001)`
  - `post_process(op="wall_shear_stress")`
  - `post_process(op="flow_separation_zones")`

### Scenario 25: Oil & Gas – Multiphase Pipeline Flow
- As a petroleum engineer, I simulate oil-gas-water flow in pipelines.
- **Acceptance**
  - Multiphase Eulerian model configured
  - Slug flow patterns captured
  - Pressure drop calculated
  - Phase distribution analyzed
- **Tools (Future)**
  - `configure_solver(models=["multiphase_eulerian"])`
  - `setup_bc(zone="inlet", bc_type="mass_flow_inlet", phases={"oil": 0.6, "gas": 0.3, "water": 0.1})`
  - `solve(time_steps=10000, time_step=0.01)`
  - `post_process(op="phase_animation", variable="volume_fraction_oil")`
  - `post_process(op="pressure_drop")`

---

## Cross-Cutting Tools

### Phase 1 Tools (v0.1.0 - Available Now)
- `search_help(query, category?, max_results?)` - Search Fluent documentation
- `list_categories()` - List all documentation categories
- `list_commands()` - List all indexed TUI commands

### Phase 2 Tools (Core Integration - Planned)
- `execute_tui(command)` - Execute TUI command in Fluent
- `workspace(op, var?, value?)` - Manage Fluent workspace/variables
- `case_io(op, path)` - Read/write case and data files
- `env(op, name?)` - Get Fluent version, license info

### Phase 3 Tools (Workflow Automation - Planned)
- `mesh_quality(check_type, threshold?)` - Check and report mesh quality
- `setup_bc(zone, bc_type, settings)` - Setup boundary conditions
- `configure_solver(case_type?, models?, custom?)` - Configure solver settings
- `post_process(operation, variable?, options?)` - Extract results and plots
- `validate_setup()` - Check case setup for common issues

### Phase 4 Tools (Advanced - Planned)
- `parametric_study(parameters, base_case)` - Run parameter sweeps
- `batch_process(cases, iterations)` - Queue multiple simulations
- `monitor_convergence(criteria)` - Track convergence with auto-stop
- `compare_results(cases, variables)` - Compare multiple cases
- `generate_report(template, cases)` - Create formatted reports

### Workflow Helpers (All Phases)
- `get_workflow(workflow_name)` - Get step-by-step workflow guides
- `search_errors(error_message)` - Search for error solutions
- `get_best_practices(topic)` - Get recommendations for common tasks

---

## Notes on Tool Philosophy

**Phase 1 (Current):**
- Focus on documentation and learning
- No Fluent installation required
- Fast, always-available reference

**Future Phases:**
- Real Fluent integration via PyFluent or TUI
- Automation of repetitive tasks
- Industry-specific workflow templates
- Balance between flexibility (execute_tui) and convenience (high-level helpers)

**Design Principles:**
1. **Progressive Enhancement** - Start with help, add execution, then automation
2. **Safety First** - Validate before executing destructive operations
3. **Industry-Aware** - Provide domain-specific workflows and templates
4. **Composable** - Tools work together for complex workflows
5. **Educational** - Always provide context and explanation
