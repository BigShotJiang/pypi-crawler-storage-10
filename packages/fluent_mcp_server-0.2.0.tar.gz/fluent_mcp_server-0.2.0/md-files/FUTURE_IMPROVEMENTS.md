# Future Improvements

## Priority 1: Local HTML Documentation Support

**Current approach:** Points to online ANSYS Help (requires internet + login)

**Better approach:** Use locally installed Fluent documentation

### Benefits:
- ✅ **Much faster** - No network latency
- ✅ **Works offline** - No internet required
- ✅ **No authentication** - Direct file access
- ✅ **Always available** - If Fluent is installed, docs are there
- ✅ **Better privacy** - No external requests

### Implementation:
```python
# Detect local Fluent installation
FLUENT_PATHS = [
    "/ansys_inc/v252/fluent/",
    "C:/Program Files/ANSYS Inc/v252/fluent/",
    "$AWP_ROOT252/fluent/"
]

# Local HTML docs location (typical structure)
LOCAL_DOC_PATH = "{FLUENT_ROOT}/help/flu_ug/flu_ug.html"

# Fallback chain:
# 1. Try local HTML docs (fastest)
# 2. Fall back to online ANSYS Help (if local not found)
```

### Typical Fluent Doc Locations:
- **Linux:** `/ansys_inc/v{version}/fluent/help/`
- **Windows:** `C:/Program Files/ANSYS Inc/v{version}/fluent/help/`
- **Env var:** `$AWP_ROOT{version}/fluent/help/`

### File Structure:
```
fluent/help/
├── flu_ug/         # User Guide HTML
├── flu_tui/        # TUI Commands HTML
├── flu_th/         # Theory Guide HTML
├── flu_udf/        # UDF Manual HTML
└── ...
```

### Updated doc_finder.py:
```python
class FluentDocFinder:
    def __init__(self):
        self.local_doc_path = self._find_local_docs()
        self.use_local = self.local_doc_path is not None

    def _find_local_docs(self):
        """Try to locate local Fluent documentation."""
        # Check environment variables
        # Check standard installation paths
        # Return path if found, None otherwise
        pass

    def search(self, query, max_suggestions=3):
        """Build URLs - prefer local file:// URLs if available."""
        if self.use_local:
            return self._build_local_urls(query)
        else:
            return self._build_online_urls(query)  # Current approach
```

### URL Format:
```python
# Local (file://)
"file:///ansys_inc/v252/fluent/help/flu_ug/flamelet-model.html"

# Online (https://)
"https://ansyshelp.ansys.com/.../flu_ug/flamelet-model.html"
```

### Configuration:
```json
// .mcp.json
{
  "mcpServers": {
    "fluent": {
      "command": "uv",
      "args": ["run", "fluent-mcp-server"],
      "env": {
        "FLUENT_DOC_PATH": "/ansys_inc/v252/fluent/help",
        "FLUENT_VERSION": "252"
      }
    }
  }
}
```

### Benefits vs Current:
| Feature | Current (Online) | Future (Local) |
|---------|------------------|----------------|
| Speed | ~200-500ms | <10ms |
| Offline | ❌ No | ✅ Yes |
| Auth required | ✅ Yes | ❌ No |
| Network | Required | Not required |
| Privacy | External request | Local only |

### Implementation Plan:
1. Add local doc path detection
2. Update URL builder to use file:// URLs
3. Fallback to online if local not found
4. Test with real Fluent installation
5. Document in README

**Estimated effort:** 2-3 hours

---

## Priority 2: PyFluent Integration

Once local docs working, add PyFluent for:
- Session management
- TUI command execution
- Case file operations

---

## Priority 3: Version Detection

Automatically detect Fluent version and use correct doc paths:
- v251 (2025 R1)
- v252 (2025 R2)
- v253 (2026 R1)

---

Date: 2025-10-31
Status: Planned for future release
