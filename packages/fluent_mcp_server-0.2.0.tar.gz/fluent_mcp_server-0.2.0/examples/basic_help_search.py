"""Basic example demonstrating Fluent help search functionality."""

from fluent_mcp_server.help_search import FluentHelpSearch


def main():
    """Demonstrate basic help search features."""
    print("=" * 70)
    print("ANSYS Fluent MCP Server - Help Search Examples")
    print("=" * 70)

    # Initialize search engine
    searcher = FluentHelpSearch()

    # Example 1: Search for iteration commands
    print("\n\n1. Search for 'iterate':")
    print("-" * 70)
    results = searcher.search("iterate", max_results=2)
    for result in results:
        print(f"\nCommand: {result['name']}")
        print(f"Category: {result['category']}")
        print(f"Summary: {result['summary']}")
        print(f"Relevance: {result['relevance']:.2f}")
        if result.get('examples'):
            print("Examples:")
            for ex in result['examples']:
                print(f"  - {ex}")

    # Example 2: Search with category filter
    print("\n\n2. Search for 'read' in 'io' category:")
    print("-" * 70)
    results = searcher.search("read", category="io", max_results=3)
    for result in results:
        print(f"\n{result['name']}: {result['summary']}")

    # Example 3: Search for turbulence models
    print("\n\n3. Search for 'turbulence model':")
    print("-" * 70)
    results = searcher.search("turbulence model", max_results=2)
    for result in results:
        print(f"\nCommand: {result['name']}")
        print(f"Description: {result['description']}")

    # Example 4: List all categories
    print("\n\n4. Available categories:")
    print("-" * 70)
    categories = searcher.get_categories()
    for cat in categories:
        print(f"  - {cat}")

    # Example 5: List all indexed commands
    print("\n\n5. All indexed commands:")
    print("-" * 70)
    commands = searcher.get_all_commands()
    for cmd in commands:
        print(f"  - {cmd}")

    # Example 6: Search for mesh operations
    print("\n\n6. Search for 'mesh quality':")
    print("-" * 70)
    results = searcher.search("mesh quality", max_results=2)
    for result in results:
        print(f"\n{result['name']} ({result['type']})")
        print(f"{result['description']}")


if __name__ == "__main__":
    main()
