"""Tests for FluentDocFinder."""

import pytest
from fluent_mcp_server.doc_finder import FluentDocFinder


@pytest.fixture
def doc_finder():
    """Create a FluentDocFinder instance."""
    return FluentDocFinder()


def test_search_returns_search_url(doc_finder):
    """Test that search returns a valid search URL."""
    result = doc_finder.search("read case")

    assert "search_url" in result
    assert "ansyshelp.ansys.com" in result["search_url"]
    assert "read" in result["search_url"].lower()


def test_search_finds_known_topic(doc_finder):
    """Test that search finds pre-mapped topics."""
    result = doc_finder.search("flamelet")

    assert "suggested_sections" in result
    assert len(result["suggested_sections"]) > 0
    assert result["suggested_sections"][0]["topic"] == "flamelet"


def test_search_unknown_topic_returns_search_url(doc_finder):
    """Test that unknown topics still return search URL."""
    result = doc_finder.search("unknown_topic_xyz")

    # Should always return search URL
    assert "search_url" in result
    assert "ansyshelp.ansys.com" in result["search_url"]


def test_all_manuals_always_present(doc_finder):
    """Test that all manual links are always returned."""
    result = doc_finder.search("anything")

    assert "all_manuals" in result
    assert "User Guide" in result["all_manuals"]
    assert "TUI Commands" in result["all_manuals"]
    assert "Theory Guide" in result["all_manuals"]
    assert "UDF Manual" in result["all_manuals"]


def test_list_topics(doc_finder):
    """Test listing all topics."""
    topics = doc_finder.list_topics()

    assert isinstance(topics, list)
    assert len(topics) > 30  # Should have 35+
    assert "flamelet" in topics
    assert "turbulence" in topics


def test_get_manual_link_valid(doc_finder):
    """Test getting a valid manual link."""
    success, url = doc_finder.get_manual_link("udf", "introduction")

    assert success is True
    assert "ansyshelp.ansys.com" in url
    assert "flu_udf" in url
    assert "introduction.html" in url


def test_get_manual_link_invalid_manual(doc_finder):
    """Test getting link for invalid manual."""
    success, message = doc_finder.get_manual_link("invalid_manual")

    assert success is False
    assert "Unknown manual" in message


def test_search_url_format(doc_finder):
    """Test that search URLs are properly formatted."""
    result = doc_finder.search("test query with spaces")

    url = result["search_url"]
    assert url.startswith("https://")
    assert "ansyshelp.ansys.com" in url
    assert "q=" in url
    assert "v=25.2" in url
    assert 'pn="Fluent"' in url or 'pn=%22Fluent%22' in url


def test_suggested_sections_have_urls(doc_finder):
    """Test that suggested sections contain valid URLs."""
    result = doc_finder.search("turbulence")

    if result["suggested_sections"]:
        section = result["suggested_sections"][0]
        assert "url" in section
        assert section["url"].startswith("https://")
        assert "ansyshelp.ansys.com" in section["url"]
