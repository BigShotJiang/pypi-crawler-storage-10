"""Test suite for Fluent MCP Server."""
