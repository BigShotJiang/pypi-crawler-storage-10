"""ANSYS Fluent MCP Server using FastMCP."""

import logging
from pathlib import Path
from datetime import datetime
from fastmcp import FastMCP
from .doc_finder import FluentDocFinder

# Setup logging
log_dir = Path.cwd() / "logs"
log_dir.mkdir(exist_ok=True)
log_file = log_dir / f"fluent-mcp-{datetime.now().strftime('%Y%m%d')}.log"

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),  # Console
        logging.FileHandler(log_file)  # File
    ]
)
logger = logging.getLogger("fluent-mcp-server")

# Initialize FastMCP server
mcp = FastMCP("fluent-mcp-server")

# Initialize documentation finder
doc_finder = FluentDocFinder()
logger.info("Fluent MCP Server initialized")


@mcp.tool()
def search_help(query: str, max_suggestions: int = 3) -> str:
    """Find ANSYS Fluent documentation URLs for your query.

    This tool helps you navigate to the right online documentation.
    Use WebFetch to retrieve the actual content from the returned URLs.

    Args:
        query: Search term (e.g., "flamelet model", "read case", "turbulence")
        max_suggestions: Maximum manual section suggestions to return (default: 3)

    Returns:
        URLs and navigation hints for finding the documentation
    """
    logger.info(f"Finding documentation for: '{query}'")

    result = doc_finder.search(query, max_suggestions)
    logger.info(f"Generated search URL and {len(result['suggested_sections'])} section suggestions")

    # Format response
    output = []
    output.append(f"# ANSYS Fluent Documentation: {query}")
    output.append("")

    # 1. Primary: Search URL
    output.append("## 🔍 Search ANSYS Help (Recommended)")
    output.append(result['search_url'])
    output.append("")
    output.append("💡 Use WebFetch tool to retrieve results from this URL")
    output.append("")

    # 2. Suggested manual sections (if found)
    if result['suggested_sections']:
        output.append("## 📚 Suggested Manual Sections")
        for section in result['suggested_sections']:
            output.append(f"### {section['topic']}")
            output.append(f"- Manual: {section['manual']}")
            output.append(f"- URL: {section['url']}")
            if 'theory_url' in section:
                output.append(f"- Theory: {section['theory_url']}")
            output.append("")
    else:
        output.append("## 📚 No Pre-mapped Sections")
        output.append("Use the search URL above or browse manuals below")
        output.append("")

    # 3. All manual links
    output.append("## 📖 Browse All Manuals")
    for manual, url in result['all_manuals'].items():
        output.append(f"- **{manual}**: {url}")
    output.append("")

    return "\n".join(output)


@mcp.tool()
def list_topics() -> str:
    """List common Fluent topics with quick documentation links.

    Returns:
        List of pre-mapped topics for faster navigation
    """
    topics = doc_finder.list_topics()

    output = []
    output.append("# Common Fluent Topics")
    output.append("")
    output.append(f"The following {len(topics)} topics have pre-mapped documentation links:")
    output.append("")

    # Group topics by category (simple grouping)
    for topic in topics:
        output.append(f"- {topic}")

    output.append("")
    output.append("💡 Use search_help(topic) to get documentation URLs for any topic")

    return "\n".join(output)


@mcp.tool()
def get_manual_link(manual: str, section: str | None = None) -> str:
    """Get direct link to a specific Fluent manual or section.

    Args:
        manual: Manual name (user_guide, tui, theory, udf)
        section: Optional section path (e.g., "turbulence", "file/read-case")

    Returns:
        Direct URL to the manual or section
    """
    logger.info(f"Getting manual link: {manual}" + (f"/{section}" if section else ""))

    success, result = doc_finder.get_manual_link(manual, section)

    if not success:
        return result  # Error message

    output = []
    output.append(f"# {manual.upper()} Manual")
    if section:
        output.append(f"Section: {section}")
    output.append("")
    output.append(f"URL: {result}")
    output.append("")
    output.append("💡 Use WebFetch to retrieve content from this URL")

    return "\n".join(output)


@mcp.resource("fluent://docs/online")
def get_online_docs_info() -> str:
    """Provide information about ANSYS Fluent online documentation.

    Returns:
        Guide for accessing official ANSYS Fluent documentation
    """
    return """# ANSYS Fluent Online Documentation

## Quick Search (Recommended)
To search the official ANSYS Fluent documentation, use this URL pattern:

https://ansyshelp.ansys.com/Views/Secured/search.html?q={YOUR_QUERY}&v=25.2&pn="Fluent"&lang=en

Replace {YOUR_QUERY} with your search term (use + or %20 for spaces).

Example searches:
- Iterations: search.html?q=solve+iterate&v=25.2&pn="Fluent"&lang=en
- Mesh quality: search.html?q=mesh+quality&v=25.2&pn="Fluent"&lang=en
- Turbulence: search.html?q=turbulence+model&v=25.2&pn="Fluent"&lang=en

## Key Documentation Manuals (2025 R2)

### Fluent User's Guide (Main Reference)
https://ansyshelp.ansys.com/Views/Secured/corp/v252/en/flu_ug/flu_ug.html

Contents:
- Part I: Getting Started
- Part II: Meshing Mode
- Part III: Solution Mode
- Part IV: Web Interface

### TUI Command Reference
https://ansyshelp.ansys.com/Views/Secured/corp/v252/en/flu_tui/flu_tui.html

Complete Text User Interface command documentation.

### Theory Guide
https://ansyshelp.ansys.com/Views/Secured/corp/v252/en/flu_th/flu_th.html

Mathematical models and theoretical background.

### UDF Manual
https://ansyshelp.ansys.com/Views/Secured/corp/v252/en/flu_udf/flu_udf.html

User-Defined Functions programming guide.

## Version Information

Current documentation: **2025 R2 (v252)**

Version mapping:
- 2024 R2 = v242
- 2025 R1 = v251
- 2025 R2 = v252

To access older versions, change v252 to the appropriate code in URLs.

## How to Use

1. **For quick answers:** Use the search_help tool (offline, fast)
2. **For detailed documentation:** Use the search URL above with WebFetch
3. **For specific sections:** Navigate to the manual URLs and use WebFetch

The official documentation is comprehensive and always up-to-date with the latest Fluent features.

## Common Topics & Search Terms

- **Solver:** "solve iterate", "convergence criteria", "solution methods"
- **Mesh:** "mesh quality", "meshing workflow", "watertight geometry"
- **Boundary Conditions:** "velocity inlet", "pressure outlet", "wall boundary"
- **Turbulence:** "k-epsilon", "k-omega", "SST model"
- **Post-processing:** "contour plot", "surface integral", "reports"
- **Files:** "read case", "write data", "file formats"

## PDF Downloads

Full manuals available as PDFs:
https://ansyshelp.ansys.com/corp/v252/en/pdf/Ansys_Fluent_Users_Guide.pdf

Change the filename for other manuals (Theory_Guide.pdf, etc.)
"""


def main():
    """Entry point for the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
