"""Smart URL finder for ANSYS Fluent online documentation.

This module helps the LLM navigate to the right ANSYS Help pages.
It does NOT store documentation content - just routing/navigation hints.
"""

import urllib.parse
from typing import Optional


class FluentDocFinder:
    """Smart URL builder for ANSYS Fluent online documentation."""

    # ANSYS Help base URLs
    BASE_SEARCH_URL = "https://ansyshelp.ansys.com/Views/Secured/search.html"
    BASE_MANUAL_URL = "https://ansyshelp.ansys.com/Views/Secured/corp/v252/en"
    VERSION = "25.2"  # 2025 R2

    # Lightweight topic → manual section routing
    # This is just navigation help, NOT content storage
    TOPIC_ROUTES = {
        # File I/O
        "file": {"manual": "flu_tui", "path": "file"},
        "read case": {"manual": "flu_tui", "path": "file/read-case"},
        "write case": {"manual": "flu_tui", "path": "file/write-case"},
        "read data": {"manual": "flu_tui", "path": "file/read-data"},
        "write data": {"manual": "flu_tui", "path": "file/write-data"},

        # Models - Turbulence
        "turbulence": {
            "manual": "flu_ug",
            "path": "turbulence-models",
            "theory": "flu_th/turb",
        },
        "k-epsilon": {
            "manual": "flu_ug",
            "path": "k-epsilon-models",
            "theory": "flu_th/turb-k-epsilon",
        },
        "k-omega": {
            "manual": "flu_ug",
            "path": "k-omega-models",
            "theory": "flu_th/turb-k-omega",
        },
        "viscous": {"manual": "flu_tui", "path": "define/models/viscous"},

        # Models - Combustion
        "combustion": {
            "manual": "flu_ug",
            "path": "combustion",
            "theory": "flu_th/combustion",
        },
        "flamelet": {
            "manual": "flu_ug",
            "path": "flamelet-model",
            "theory": "flu_th/flamelet",
        },
        "species": {"manual": "flu_tui", "path": "define/models/species"},

        # Models - Multiphase
        "multiphase": {
            "manual": "flu_ug",
            "path": "multiphase",
            "theory": "flu_th/multiphase",
        },
        "vof": {"manual": "flu_ug", "path": "volume-of-fluid"},
        "eulerian": {"manual": "flu_ug", "path": "eulerian"},

        # Solver
        "solve": {"manual": "flu_tui", "path": "solve"},
        "iterate": {"manual": "flu_tui", "path": "solve/iterate"},
        "convergence": {"manual": "flu_ug", "path": "convergence"},
        "residual": {"manual": "flu_tui", "path": "solve/monitors/residual"},

        # Mesh
        "mesh": {"manual": "flu_ug", "path": "meshing"},
        "mesh quality": {"manual": "flu_ug", "path": "mesh-quality"},
        "mesh check": {"manual": "flu_tui", "path": "mesh/check"},
        "dynamic mesh": {"manual": "flu_ug", "path": "dynamic-mesh"},

        # Boundary Conditions
        "boundary": {"manual": "flu_ug", "path": "boundary-conditions"},
        "boundary condition": {"manual": "flu_tui", "path": "define/boundary-conditions"},
        "inlet": {"manual": "flu_ug", "path": "velocity-inlet"},
        "outlet": {"manual": "flu_ug", "path": "pressure-outlet"},
        "wall": {"manual": "flu_ug", "path": "wall-boundary-conditions"},

        # UDF
        "udf": {"manual": "flu_udf", "path": "udf"},
        "user defined function": {"manual": "flu_udf", "path": "udf"},

        # Post-processing
        "report": {"manual": "flu_tui", "path": "report"},
        "contour": {"manual": "flu_tui", "path": "display/contour"},
        "plot": {"manual": "flu_ug", "path": "postprocessing"},

        # Materials & Properties
        "material": {"manual": "flu_ug", "path": "materials"},
        "density": {"manual": "flu_ug", "path": "material-properties"},
    }

    def search(self, query: str, max_suggestions: int = 3) -> dict:
        """Build search URLs and navigation hints for a query.

        Args:
            query: Search term (e.g., "flamelet model", "read case")
            max_suggestions: Max number of section suggestions to return

        Returns:
            dict with:
                - search_url: ANSYS Help search URL
                - suggested_sections: List of relevant manual sections
                - all_manuals: Links to all major manuals
        """
        query_lower = query.lower().strip()

        return {
            "query": query,
            "search_url": self._build_search_url(query),
            "suggested_sections": self._find_sections(query_lower, max_suggestions),
            "all_manuals": self._get_all_manuals(),
        }

    def _build_search_url(self, query: str) -> str:
        """Build ANSYS Help search URL for the query."""
        encoded_query = urllib.parse.quote_plus(query)
        return f'{self.BASE_SEARCH_URL}?q={encoded_query}&v={self.VERSION}&pn="Fluent"&lang=en'

    def _find_sections(self, query_lower: str, max_results: int) -> list[dict]:
        """Find relevant manual sections based on query keywords.

        This uses simple keyword matching to suggest relevant sections.
        """
        suggestions = []

        for topic, route in self.TOPIC_ROUTES.items():
            # Check if topic matches query
            if self._matches(topic, query_lower):
                suggestion = {
                    "topic": topic,
                    "manual": route["manual"],
                    "url": f"{self.BASE_MANUAL_URL}/{route['manual']}/{route['path']}.html",
                }

                # Add theory guide link if available
                if "theory" in route:
                    suggestion["theory_url"] = f"{self.BASE_MANUAL_URL}/{route['theory']}.html"

                suggestions.append(suggestion)

        # Sort by relevance (exact match first, then contains)
        suggestions.sort(key=lambda x: self._relevance(x["topic"], query_lower), reverse=True)

        return suggestions[:max_results]

    def _matches(self, topic: str, query: str) -> bool:
        """Check if topic matches query."""
        # Exact match
        if topic == query:
            return True

        # Topic contains query or query contains topic
        if topic in query or query in topic:
            return True

        # Word-by-word matching
        topic_words = set(topic.split())
        query_words = set(query.split())

        # At least one word matches
        return len(topic_words & query_words) > 0

    def _relevance(self, topic: str, query: str) -> float:
        """Calculate simple relevance score."""
        score = 0.0

        # Exact match
        if topic == query:
            score += 10.0

        # Topic in query
        if topic in query:
            score += 5.0

        # Query in topic
        if query in topic:
            score += 3.0

        # Word overlap
        topic_words = set(topic.split())
        query_words = set(query.split())
        overlap = len(topic_words & query_words)
        score += overlap * 1.0

        return score

    def _get_all_manuals(self) -> dict[str, str]:
        """Get links to all major Fluent manuals."""
        return {
            "User Guide": f"{self.BASE_MANUAL_URL}/flu_ug/flu_ug.html",
            "TUI Commands": f"{self.BASE_MANUAL_URL}/flu_tui/flu_tui.html",
            "Theory Guide": f"{self.BASE_MANUAL_URL}/flu_th/flu_th.html",
            "UDF Manual": f"{self.BASE_MANUAL_URL}/flu_udf/flu_udf.html",
        }

    def get_manual_link(
        self, manual: str, section: Optional[str] = None
    ) -> tuple[bool, str]:
        """Get direct link to a manual or section.

        Args:
            manual: Manual code (user_guide, tui, theory, udf)
            section: Optional section path

        Returns:
            (success: bool, url_or_error: str)
        """
        manual_codes = {
            "user_guide": "flu_ug",
            "tui": "flu_tui",
            "theory": "flu_th",
            "udf": "flu_udf",
        }

        if manual not in manual_codes:
            available = ", ".join(manual_codes.keys())
            return False, f"Unknown manual '{manual}'. Available: {available}"

        code = manual_codes[manual]
        base_url = f"{self.BASE_MANUAL_URL}/{code}"

        if section:
            url = f"{base_url}/{section}.html"
        else:
            url = f"{base_url}/{code}.html"

        return True, url

    def list_topics(self) -> list[str]:
        """List all indexed topics for navigation."""
        return sorted(self.TOPIC_ROUTES.keys())
