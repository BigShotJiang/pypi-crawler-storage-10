"""ANSYS Fluent MCP Server - Enable AI assistants to interact with Fluent."""

__version__ = "0.1.0"
