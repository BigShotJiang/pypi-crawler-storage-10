# ANSYS Fluent MCP Server

✅ **Ready to Use** - Version 0.2.0 (Smart Documentation Navigator)

A Model Context Protocol (MCP) server that helps AI assistants navigate ANSYS Fluent online documentation efficiently.

## Features

- **Smart URL Navigator** - Find relevant ANSYS Help documentation URLs instantly
- **35+ Topic Routes** - Pre-mapped paths to common Fluent topics
- **Always Up-to-Date** - Points to official ANSYS documentation
- **Zero Maintenance** - No static content to update
- **Lightweight** - Fast URL generation, no heavy indexing

## Quick Start

### Prerequisites

- Python 3.10 or higher
- [uv](https://docs.astral.sh/uv/getting-started/installation/) package manager

### Installation with uvx (Recommended)

No installation needed! Just configure your MCP client:

**Using Claude Code CLI:**

```bash
claude mcp add --transport stdio fluent -- uvx fluent-mcp-server
```

**Manual `.mcp.json` configuration (Development Mode):**

For local development, create `.mcp.json` in your project root:

```json
{
  "mcpServers": {
    "fluent": {
      "command": "uv",
      "args": [
        "--directory",
        "/path/to/fluent-mcp-server",
        "run",
        "fluent-mcp-server"
      ],
      "env": {
        "FLUENT_VERSION": "2025R2"
      }
    }
  }
}
```

**Important:** Update `/path/to/fluent-mcp-server` to your actual installation path.

### Development Installation

```bash
# Clone the repository
git clone https://github.com/your-org/fluent-mcp-server.git
cd fluent-mcp-server

# Install with uv
uv pip install -e ".[dev]"

# Run tests
uv run pytest

# Run server
uv run fluent-mcp-server
```

📖 **For detailed setup and usage instructions, see [`md-files/QUICKSTART.md`](md-files/QUICKSTART.md)**

## Available Tools

### `search_help`

Find ANSYS Fluent documentation URLs for your query. Returns search URLs and suggested manual sections.

**Parameters:**
- `query` (required): Search term (e.g., "flamelet model", "read case", "turbulence")
- `max_suggestions` (optional): Maximum manual section suggestions (default: 3)

**Returns:**
- ANSYS Help search URL
- Suggested manual sections (if topic is pre-mapped)
- Links to all major manuals

**Example:**
```python
search_help("flamelet model")
# Returns:
# - Search URL: https://ansyshelp.ansys.com/search?q=flamelet+model
# - Suggested: flamelet User Guide + Theory Guide
# - All manuals: User Guide, TUI, Theory, UDF

search_help("read case")
# Returns URLs to file/read-case TUI documentation
```

### `list_topics`

List the 35+ topics with pre-mapped documentation routes.

**Returns:** List of topics like: file, turbulence, combustion, flamelet, mesh, boundary, udf, etc.

**Example:**
```python
list_topics()
```

### `get_manual_link`

Get direct link to a specific Fluent manual or section.

**Parameters:**
- `manual` (required): Manual name (`user_guide`, `tui`, `theory`, `udf`)
- `section` (optional): Section path (e.g., "turbulence", "file/read-case")

**Example:**
```python
get_manual_link("udf", "introduction")
# Returns: https://ansyshelp.ansys.com/.../flu_udf/introduction.html
```

## Usage Examples

### In Claude Code / AI Assistant

```
You: How do I use the flamelet model in Fluent?
Claude: [Calls search_help("flamelet model")]
        [Receives URLs to flamelet documentation]
        [Uses WebFetch to read the actual documentation]
        [Provides answer based on official ANSYS docs]

You: Show me the command to read a case file
Claude: [Calls search_help("read case")]
        [Gets URL to file/read-case TUI command]
        [Retrieves documentation and shows syntax]
```

### Architecture Flow

```
User Query → MCP search_help → Returns URLs →
LLM uses WebFetch → Reads official docs → Answers user
```

The MCP server acts as a **smart navigator**, not a content database.

## Architecture

```
fluent-mcp-server/
├── src/fluent_mcp_server/
│   ├── server.py          # FastMCP server & tool definitions
│   ├── doc_finder.py      # Smart URL router (35+ topic mappings)
│   └── __init__.py
├── md-files/
│   ├── ARCHITECTURE.md    # Technical architecture
│   └── ...
├── tests/                 # Unit tests
├── examples/              # Usage examples
└── pyproject.toml        # Project configuration
```

## Current Status

**Version 0.2.0: Smart Documentation Navigator** ✅ **COMPLETE**

**Features:**
- ✅ Smart URL builder for ANSYS Help
- ✅ 35+ pre-mapped topic routes (file, turbulence, combustion, flamelet, mesh, etc.)
- ✅ Works for ALL Fluent topics (not limited to hardcoded content)
- ✅ Always up-to-date (points to official ANSYS docs)
- ✅ Zero maintenance (no static content to update)
- ✅ 3 MCP tools: search_help, list_topics, get_manual_link
- ✅ FastMCP integration with logging

**Coverage:**
- ✅ **100% coverage** - Works for any query (returns search URL)
- ✅ **35+ optimized routes** - Fast navigation for common topics
- ✅ Flamelet, combustion, multiphase, UDF - all supported
- ✅ No gaps - if topic not pre-mapped, returns search URL

## Roadmap

**Phase 1.x: Route Expansion (Future)**
- Add more topic routes based on usage patterns
- Version selection (v251, v252, v253)
- Usage analytics to identify popular topics

**Phase 2: PyFluent Integration (Planned)**
- Connect to Fluent sessions
- Execute TUI commands programmatically
- Case I/O via PyFluent API
- Mesh quality automation
- Convergence monitoring

**Phase 3: Workflow Automation (Planned)**
- Boundary condition templates
- Solver configuration wizards
- Post-processing automation
- Parametric studies

See [`md-files/ARCHITECTURE.md`](md-files/ARCHITECTURE.md) for detailed roadmap.

## Documentation

**Getting Started:**
- [`md-files/QUICKSTART.md`](md-files/QUICKSTART.md) - Setup and usage guide
- [`README.md`](README.md) - This file (overview)

**Technical Documentation:**
- [`md-files/ARCHITECTURE.md`](md-files/ARCHITECTURE.md) - System architecture and design
- [`md-files/TOOLS.md`](md-files/TOOLS.md) - Complete tool catalog
- [`md-files/ANSYS_HELP_GUIDE.md`](md-files/ANSYS_HELP_GUIDE.md) - ANSYS Help site patterns

**Validation & Analysis:**
- [`md-files/REDDIT_REAL_WORLD_EXAMPLES.md`](md-files/REDDIT_REAL_WORLD_EXAMPLES.md) - Real user questions
- [`md-files/GAP_ANALYSIS.md`](md-files/GAP_ANALYSIS.md) - Coverage analysis
- [`md-files/USERSTORY.md`](md-files/USERSTORY.md) - User scenarios

**Development:**
- [`examples/`](examples/) - Usage examples
- [`tests/`](tests/) - Unit tests

## License

MIT License

## Contributing

Contributions welcome! Please ensure:
- Tests pass: `uv run pytest`
- Code follows existing style
- Documentation updated
# fluent-mcp-server
