from __future__ import annotations

import json
import os
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import List, Optional

from .trusted_folders import TrustedFoldersManager, TrustLevel


@dataclass
class ProviderStatus:
    name: str
    configured: bool
    installed: bool
    model: Optional[str]
    model_available: bool
    notes: str = ""


@dataclass
class OnboardingPlan:
    root: str
    trust_level: str
    provider: Optional[ProviderStatus]
    actions: List[str]

    def to_json(self) -> str:
        return json.dumps(
            {
                "root": self.root,
                "trust_level": self.trust_level,
                "provider": asdict(self.provider) if self.provider else None,
                "actions": self.actions,
            },
            indent=2,
        )


def _ollama_installed() -> bool:
    try:
        subprocess.run(["ollama", "--version"], capture_output=True, timeout=2)
        return True
    except Exception:
        return False


def _ollama_list_models() -> List[str]:
    try:
        res = subprocess.run(["ollama", "list"], capture_output=True, text=True, timeout=5)
        if res.returncode != 0:
            return []
        lines = [line.strip() for line in (res.stdout or "").splitlines()]
        # Skip header if present
        if lines and ("MODEL" in lines[0] or lines[0].lower().startswith("name")):
            lines = lines[1:]
        models: List[str] = []
        for line in lines:
            if not line:
                continue
            parts = line.split()
            if parts:
                models.append(parts[0])
        return models
    except Exception:
        return []


def detect_provider(
    env_provider: Optional[str], env_model: Optional[str]
) -> Optional[ProviderStatus]:
    # Prefer explicit provider if set
    name = (env_provider or "").strip().lower()
    model = env_model

    if name == "ollama" or not name:
        installed = _ollama_installed()
        if installed:
            if not model:
                model = "mistral:latest"
            models = _ollama_list_models()
            return ProviderStatus(
                name="ollama",
                configured=True,
                installed=True,
                model=model,
                model_available=(model in models),
                notes="",
            )
        else:
            # If no explicit provider and ollama not present, leave None for cloud path
            if not name:
                return None
            return ProviderStatus(
                name="ollama",
                configured=False,
                installed=False,
                model=model or "mistral:latest",
                model_available=False,
                notes="ollama is not installed",
            )

    # Cloud providers: check simple env var presence as configuration signal
    if name == "openai":
        api = os.environ.get("OPENAI_API_KEY")
        return ProviderStatus(
            name="openai",
            configured=bool(api),
            installed=True,
            model=model or "gpt-4o-mini",
            model_available=True,
            notes="set OPENAI_API_KEY to enable",
        )
    if name == "gemini":
        api = os.environ.get("GEMINI_API_KEY")
        return ProviderStatus(
            name="gemini",
            configured=bool(api),
            installed=True,
            model=model or "gemini-1.5-pro-latest",
            model_available=True,
            notes="set GEMINI_API_KEY to enable",
        )
    if name == "anthropic":
        api = os.environ.get("ANTHROPIC_API_KEY")
        return ProviderStatus(
            name="anthropic",
            configured=bool(api),
            installed=True,
            model=model or "claude-3-5-sonnet-latest",
            model_available=True,
            notes="set ANTHROPIC_API_KEY to enable",
        )

    return None


def build_onboarding_plan(
    root: str, *, provider: Optional[str] = None, model: Optional[str] = None
) -> OnboardingPlan:
    mgr = TrustedFoldersManager()
    level = mgr.get_level(root)

    prov = detect_provider(provider, model)
    actions: List[str] = []

    # Trust recommendations
    if level == TrustLevel.UNTRUSTED:
        actions.append("Set trust level for project (recommended LOW or TRUSTED)")

    # Provider/model recommendations
    if prov is None:
        actions.append(
            "Choose provider: ollama (local) or a cloud provider (openai/gemini/anthropic)"
        )
    else:
        if prov.name == "ollama":
            if not prov.installed:
                actions.append("Install ollama from https://ollama.com and start the daemon")
            else:
                if not prov.model_available and prov.model:
                    actions.append(f"Pull local model: ollama pull {prov.model}")
        else:
            # Cloud provider
            if not prov.configured:
                env_name = {
                    "openai": "OPENAI_API_KEY",
                    "gemini": "GEMINI_API_KEY",
                    "anthropic": "ANTHROPIC_API_KEY",
                }[prov.name]
                actions.append(f"Export {env_name} in your shell to authenticate")

    # Safe defaults
    actions.append("Agent dry-run by default; pass --apply to apply changes")
    actions.append("Trust prompts enforce approvals for risky actions")

    return OnboardingPlan(
        root=str(Path(root).resolve()), trust_level=level.name, provider=prov, actions=actions
    )


def run_onboard(
    *,
    root: str,
    provider: Optional[str] = None,
    model: Optional[str] = None,
    dry_run: bool = True,
    yes: bool = False,
) -> int:
    plan = build_onboarding_plan(root, provider=provider, model=model)
    print("Onboarding plan:\n" + plan.to_json())

    # Execute recommended actions if not dry-run
    if dry_run:
        print("\nDry-run: no changes made. Re-run with --no-dry-run to apply.")
        return 0

    # Step 1: Trust
    mgr = TrustedFoldersManager()
    if plan.trust_level == TrustLevel.UNTRUSTED.name:
        if yes or _confirm("Set trust level to TRUSTED for this project? [y/N] "):
            mgr.set_level(root, TrustLevel.TRUSTED, persist=True)
            print(f"Set {root} -> TRUSTED")

    # Step 2: Provider setup (ollama model pull only; cloud providers rely on env)
    prov = plan.provider
    if (
        prov
        and prov.name == "ollama"
        and prov.installed
        and prov.model
        and not prov.model_available
    ):
        cmd = ["ollama", "pull", prov.model]
        if yes or _confirm(f"Pull model now? {' '.join(cmd)} [y/N] "):
            try:
                subprocess.run(cmd, check=False, timeout=300)
            except Exception:
                pass

    print("\nOnboarding complete.")
    return 0


def _confirm(prompt: str) -> bool:
    try:
        ans = input(prompt).strip().lower()
        return ans.startswith("y")
    except Exception:
        return False
