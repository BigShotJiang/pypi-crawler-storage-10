from __future__ import annotations

import json
import os
import time
import time as _time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class TaskMemory:
    """Memory of a single task execution."""

    task: str
    timestamp: float
    success: bool
    steps_taken: int
    files_modified: List[str] = field(default_factory=list)
    lessons_learned: List[str] = field(default_factory=list)
    errors_encountered: List[str] = field(default_factory=list)
    verification_results: Dict[str, Any] = field(default_factory=dict)
    final_message: str = ""


@dataclass
class ConversationTurn:
    """A single turn in a conversation."""

    role: str  # "user" | "assistant" | "system"
    content: str
    timestamp: float
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AgentSession:
    """A persistent session with context across multiple tasks."""

    session_id: str
    root_dir: str
    created_at: float
    updated_at: float
    tasks: List[TaskMemory] = field(default_factory=list)
    conversation_history: List[ConversationTurn] = field(default_factory=list)
    user_preferences: Dict[str, Any] = field(default_factory=dict)
    file_knowledge: Dict[str, Dict[str, Any]] = field(default_factory=dict)  # path -> metadata

    # Learned patterns
    common_errors: Dict[str, int] = field(default_factory=dict)  # error -> count
    successful_patterns: List[str] = field(default_factory=list)

    # Context
    current_branch: Optional[str] = None
    last_tested_commit: Optional[str] = None


class MemoryStore:
    """Manages persistent agent memory across sessions."""

    def __init__(self, config_path: Optional[str] = None) -> None:
        self.config_path = Path(config_path) if config_path else self._default_path()
        self.sessions: Dict[str, AgentSession] = {}
        self._load()

    def _default_path(self) -> Path:
        return Path.home() / ".config" / "ollcoder" / "agent_memory.json"

    def _lock_path(self) -> Path:
        return self.config_path.with_suffix(self.config_path.suffix + ".lock")

    def _acquire_lock(self, timeout: float = 3.0, poll: float = 0.05) -> Optional[Any]:
        """Cross-platform best-effort file lock. Returns lock handle or None on failure."""
        lock_path = self._lock_path()
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        fh = None
        try:
            fh = open(lock_path, "a+b")
            start = _time.time()
            while True:
                try:
                    # POSIX
                    try:
                        import fcntl  # type: ignore

                        fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                        return fh
                    except Exception:
                        pass
                    # Windows
                    try:
                        import msvcrt  # type: ignore

                        msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
                        return fh
                    except Exception:
                        pass
                except Exception:
                    pass
                if _time.time() - start > timeout:
                    break
                _time.sleep(poll)
        except Exception:
            pass
        # Failed to obtain lock
        try:
            if fh:
                fh.close()
        except Exception:
            pass
        return None

    def _release_lock(self, handle: Any) -> None:
        try:
            # POSIX
            try:
                import fcntl  # type: ignore

                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            except Exception:
                pass
            # Windows
            try:
                import msvcrt  # type: ignore

                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            except Exception:
                pass
            handle.close()
        except Exception:
            pass

    def _load(self) -> None:
        """Load memory from disk."""
        try:
            lock = self._acquire_lock()
            if self.config_path.is_file():
                data = json.loads(self.config_path.read_text())
                for session_data in data.get("sessions", []):
                    sid = session_data.get("session_id", "")
                    if not sid:
                        continue

                    # Reconstruct tasks
                    tasks = []
                    for t in session_data.get("tasks", []):
                        tasks.append(TaskMemory(**t))

                    # Reconstruct conversation
                    conversation = []
                    for c in session_data.get("conversation_history", []):
                        conversation.append(ConversationTurn(**c))

                    session = AgentSession(
                        session_id=sid,
                        root_dir=session_data.get("root_dir", ""),
                        created_at=float(session_data.get("created_at", time.time())),
                        updated_at=float(session_data.get("updated_at", time.time())),
                        tasks=tasks,
                        conversation_history=conversation,
                        user_preferences=session_data.get("user_preferences", {}),
                        file_knowledge=session_data.get("file_knowledge", {}),
                        common_errors=session_data.get("common_errors", {}),
                        successful_patterns=session_data.get("successful_patterns", []),
                        current_branch=session_data.get("current_branch"),
                        last_tested_commit=session_data.get("last_tested_commit"),
                    )
                    self.sessions[sid] = session
        except Exception:
            self.sessions = {}
        finally:
            if "lock" in locals() and lock is not None:
                self._release_lock(lock)

    def _save(self) -> None:
        """Persist memory to disk."""
        lock = None
        try:
            lock = self._acquire_lock()
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            payload = {
                "version": 1,
                "updated_at": time.time(),
                "sessions": [asdict(s) for s in self.sessions.values()],
            }
            tmp_path = self.config_path.with_suffix(self.config_path.suffix + ".tmp")
            Path(tmp_path).write_text(json.dumps(payload, indent=2))
            os.replace(tmp_path, self.config_path)
        except Exception:
            # best-effort
            pass
        finally:
            if lock is not None:
                self._release_lock(lock)

    # ---- Session management ---- #

    def get_or_create_session(
        self, root_dir: str, session_id: Optional[str] = None
    ) -> AgentSession:
        """Get existing session or create new one for this project."""
        if session_id and session_id in self.sessions:
            session = self.sessions[session_id]
            session.updated_at = time.time()
            return session

        # Find existing session by root_dir
        root_abs = str(Path(root_dir).resolve())
        for session in self.sessions.values():
            if Path(session.root_dir).resolve() == Path(root_abs):
                session.updated_at = time.time()
                return session

        # Create new session
        sid = session_id or f"session_{int(time.time())}_{root_abs.replace('/', '_')[-50:]}"
        session = AgentSession(
            session_id=sid,
            root_dir=root_abs,
            created_at=time.time(),
            updated_at=time.time(),
        )
        self.sessions[sid] = session
        self._save()
        return session

    def add_task(self, session_id: str, task_memory: TaskMemory) -> None:
        """Record a completed task."""
        if session_id not in self.sessions:
            return
        session = self.sessions[session_id]
        session.tasks.append(task_memory)
        session.updated_at = time.time()

        # Update learned patterns
        if task_memory.success:
            for lesson in task_memory.lessons_learned:
                if lesson not in session.successful_patterns:
                    session.successful_patterns.append(lesson)

        for error in task_memory.errors_encountered:
            session.common_errors[error] = session.common_errors.get(error, 0) + 1

        self._save()

    def add_conversation_turn(
        self, session_id: str, role: str, content: str, metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """Add a turn to conversation history."""
        if session_id not in self.sessions:
            return
        session = self.sessions[session_id]
        turn = ConversationTurn(
            role=role,
            content=content,
            timestamp=time.time(),
            metadata=metadata or {},
        )
        session.conversation_history.append(turn)
        session.updated_at = time.time()
        self._save()

    def update_file_knowledge(
        self, session_id: str, file_path: str, metadata: Dict[str, Any]
    ) -> None:
        """Record what the agent learned about a file."""
        if session_id not in self.sessions:
            return
        session = self.sessions[session_id]
        session.file_knowledge[file_path] = metadata
        session.updated_at = time.time()
        self._save()

    def get_recent_context(self, session_id: str, max_turns: int = 10) -> List[Dict[str, str]]:
        """Get recent conversation for LLM context."""
        if session_id not in self.sessions:
            return []
        session = self.sessions[session_id]
        recent = session.conversation_history[-max_turns:]
        return [{"role": turn.role, "content": turn.content} for turn in recent]

    def get_relevant_memory(self, session_id: str, task: str) -> str:
        """Build a memory summary relevant to the current task."""
        if session_id not in self.sessions:
            return ""

        session = self.sessions[session_id]
        lines: List[str] = ["# Agent Memory Context"]

        # Recent tasks
        if session.tasks:
            lines.append("\n## Recent Tasks")
            for t in session.tasks[-5:]:
                status = "✓" if t.success else "✗"
                lines.append(f"- {status} {t.task} ({t.steps_taken} steps)")
                if t.files_modified:
                    lines.append(f"  Modified: {', '.join(t.files_modified[:3])}")

        # Learned patterns
        if session.successful_patterns:
            lines.append("\n## Successful Patterns")
            for pattern in session.successful_patterns[-5:]:
                lines.append(f"- {pattern}")

        # Common errors
        if session.common_errors:
            lines.append("\n## Common Errors to Avoid")
            sorted_errors = sorted(session.common_errors.items(), key=lambda x: x[1], reverse=True)
            for error, count in sorted_errors[:3]:
                lines.append(f"- {error} (occurred {count}x)")

        # File knowledge
        task_lower = task.lower()
        relevant_files = []
        for path, meta in session.file_knowledge.items():
            if any(keyword in path.lower() for keyword in task_lower.split()):
                relevant_files.append((path, meta))

        if relevant_files:
            lines.append("\n## Known Files Related to Task")
            for path, meta in relevant_files[:5]:
                purpose = meta.get("purpose", "")
                lines.append(f"- {path}: {purpose}")

        return "\n".join(lines)

    def cleanup_old_sessions(self, days: int = 30) -> int:
        """Remove sessions older than N days. Returns count removed."""
        cutoff = time.time() - (days * 86400)
        to_remove = [sid for sid, session in self.sessions.items() if session.updated_at < cutoff]
        for sid in to_remove:
            del self.sessions[sid]
        if to_remove:
            self._save()
        return len(to_remove)

    def export_session(self, session_id: str, out_path: str) -> None:
        """Export a session to JSON for analysis/debugging."""
        if session_id not in self.sessions:
            return
        session = self.sessions[session_id]
        Path(out_path).write_text(json.dumps(asdict(session), indent=2))

    def get_session_summary(self, session_id: str) -> Dict[str, Any]:
        """Get high-level stats about a session."""
        if session_id not in self.sessions:
            return {}
        session = self.sessions[session_id]
        return {
            "session_id": session.session_id,
            "root_dir": session.root_dir,
            "created_at": session.created_at,
            "updated_at": session.updated_at,
            "total_tasks": len(session.tasks),
            "successful_tasks": sum(1 for t in session.tasks if t.success),
            "conversation_turns": len(session.conversation_history),
            "files_known": len(session.file_knowledge),
            "patterns_learned": len(session.successful_patterns),
        }


# ---- Global instance ---- #

_GLOBAL_STORE: Optional[MemoryStore] = None


def global_memory() -> MemoryStore:
    """Get global memory store singleton."""
    global _GLOBAL_STORE
    if _GLOBAL_STORE is None:
        _GLOBAL_STORE = MemoryStore()
    return _GLOBAL_STORE
