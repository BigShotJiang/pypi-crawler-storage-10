from __future__ import annotations

import json
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from .agent import AgentConfig, run_agent
from .trusted_folders import TrustedFoldersManager, TrustLevel


@dataclass
class ReliabilityMetrics:
    success: bool
    iterations: int
    duration_sec: float
    checks_status: int
    message: str

    def to_json(self) -> str:
        return json.dumps(
            {
                "success": self.success,
                "iterations": self.iterations,
                "duration_sec": round(self.duration_sec, 3),
                "checks_status": self.checks_status,
                "message": self.message,
            },
            indent=2,
        )


class _FakeProvider:
    def __init__(self, root: str) -> None:
        self.root = Path(root)
        self.called = False

    def chat(self, messages, stream=False):  # noqa: ANN001
        # Propose a patch to fix sample project's calc.add
        if not self.called:
            self.called = True
            new_content = "def add(a, b):\n    return a + b\n"
            return {
                "content": json.dumps(
                    {
                        "plan": ["fix add function"],
                        "action": "propose_patch",
                        "edits": [{"path": "src/calc.py", "new_content": new_content}],
                        "reason": "fix addition",
                    }
                )
            }
        return {"content": json.dumps({"plan": [], "action": "done", "reason": "fixed"})}


def run_harness(
    root: str,
    task: str,
    *,
    provider: Any | None,
    max_steps: int = 6,
    apply_changes: bool = True,
    run_tests: bool = True,
    pytest_args: Optional[list[str]] = None,
    fake_provider: bool = False,
) -> ReliabilityMetrics:
    start = time.time()

    # Best-effort trust so the agent can write
    try:
        mgr = TrustedFoldersManager()
        lvl = mgr.get_level(root)
        if lvl.value < TrustLevel.TRUSTED.value:
            mgr.set_level(root, TrustLevel.TRUSTED, persist=False)
    except Exception:
        pass

    if provider is None and fake_provider:
        provider = _FakeProvider(root)
    cfg = AgentConfig(root_dir=root, task=task, max_steps=max_steps, apply_changes=apply_changes)
    result = run_agent(cfg, provider=provider)
    duration = time.time() - start

    # Run local tests if requested (requires pytest in the environment)
    checks_status = 0
    if run_tests:
        try:
            args = ["pytest", "-q"] + (pytest_args or [])
            proc = subprocess.run(args, cwd=root, capture_output=True, text=True, timeout=180)
            checks_status = 0 if proc.returncode == 0 else proc.returncode
        except Exception:
            checks_status = -1

    iters = len(result.steps)
    return ReliabilityMetrics(
        success=result.success,
        iterations=iters,
        duration_sec=duration,
        checks_status=checks_status,
        message=result.final_message,
    )
