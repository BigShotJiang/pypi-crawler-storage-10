from __future__ import annotations

import logging
from typing import Any

try:
    from rich.console import Console
    from rich.live import Live
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.prompt import Prompt

    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False

from .adaptive_builder import AdaptiveConfig, build_adaptive_context
from .context_cache import ContextCache
from .context_strategy import ContextFile
from .providers.base import BaseProvider

# Simple in-memory cache for recent context queries
_context_query_cache = {}


def format_context_simple(files: list[ContextFile], max_files: int = 5) -> str:
    """Format a small selection of context files for chat."""
    parts = []
    for f in files[:max_files]:
        parts.append(f"## {f.path}")
        content = f.content[:2000] if len(f.content) > 2000 else f.content
        parts.append(f"```\n{content}\n```\n")
    return "\n".join(parts)


def _load_relevant_context(root: str, query: str, cache: ContextCache) -> str:
    """Load relevant code context based on user query."""
    query_lower = query.strip().lower()

    # Check cache first for exact query matches
    cache_key = f"{root}:{query_lower}"
    if cache_key in _context_query_cache:
        return _context_query_cache[cache_key]

    # Only skip very simple greetings
    simple_patterns = ["hi", "hello", "hey", "bye", "goodbye"]
    if query_lower in simple_patterns:
        return ""

    # Check if user mentions specific files with @ prefix or just file patterns
    import re

    # Match @filename or standalone filenames with extensions
    mentioned_files = []

    # Pattern 1: @filename mentions
    at_pattern = r"@([\w/.-]+\.(py|js|ts|go|rs|java|cpp|c|h|md|txt|yml|yaml|json|toml))"
    at_matches = re.findall(at_pattern, query, re.IGNORECASE)
    mentioned_files.extend([match[0] for match in at_matches])

    # Pattern 2: Standalone filenames (without @)
    file_pattern = r"\b([\w/.-]+\.(py|js|ts|go|rs|java|cpp|c|h|md|txt|yml|yaml|json|toml))\b"
    file_matches = re.findall(file_pattern, query, re.IGNORECASE)
    mentioned_files.extend([match[0] for match in file_matches])

    # Remove duplicates while preserving order
    seen = set()
    unique_mentioned = [f for f in mentioned_files if not (f in seen or seen.add(f))]

    try:
        cfg = AdaptiveConfig(
            root_dir=root,
            query=query,
            mentioned_files=unique_mentioned if unique_mentioned else None,
            model_max_tokens=8000,  # Increased context size
            compression_level="LITE",  # Light compression for balance
        )
        files, _ = build_adaptive_context(cfg, cache=cache, provider=None)
        # Return more files for better context
        result = format_context_simple(files, max_files=5) if files else ""

        # Cache the result (limit cache size)
        cache_key = f"{root}:{query_lower}"
        if len(_context_query_cache) > 50:  # Clear old entries if cache grows too large
            _context_query_cache.clear()
        _context_query_cache[cache_key] = result

        return result
    except Exception:
        return ""


def run_chat(root: str, provider: Any, model: str, no_context: bool = False) -> int:
    """Run interactive chat session with the AI about the codebase.

    Args:
        root: Project root directory
        provider: AI provider instance
        model: Model name
        no_context: If True, disable context loading for maximum speed
    """
    if provider is None:
        print("Error: Provider required. Use --provider ollama or --provider gemini")
        return 1

    # Suppress verbose logging from httpx and other libraries
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)

    if RICH_AVAILABLE:
        return _run_chat_rich(root, provider, model, no_context)
    else:
        return _run_chat_plain(root, provider, model, no_context)


def _run_chat_rich(root: str, provider: Any, model: str, no_context: bool = False) -> int:
    """Run chat with rich TUI."""
    console = Console()

    # Welcome screen
    console.clear()
    welcome = Panel(
        f"[bold cyan]🤖 Ollcoder Chat[/bold cyan]\n\n"
        f"[dim]Model:[/dim] {model}\n"
        f"[dim]Project:[/dim] {root}\n\n"
        f"[yellow]Commands:[/yellow] [bold]exit[/bold], [bold]quit[/bold], or [bold]Ctrl+C[/bold] to quit",
        title="👋 Welcome",
        border_style="cyan",
    )
    console.print(welcome)
    console.print()

    cache = ContextCache(root)
    messages = [
        {
            "role": "system",
            "content": (
                "You are a helpful coding assistant. Be conversational and concise.\n"
                "When the user asks about specific files or features, I will provide relevant code context.\n"
                "Only explain code details when asked."
            ),
        },
    ]

    while True:
        try:
            user_input = Prompt.ask("\n[bold green]You[/bold green]", console=console).strip()
        except (EOFError, KeyboardInterrupt):
            console.print("\n[yellow]👋 Goodbye![/yellow]")
            return 0

        if not user_input:
            continue

        if user_input.lower() in ("exit", "quit", "q"):
            console.print("\n[yellow]👋 Goodbye![/yellow]")
            return 0

        # Load context only if user explicitly mentions files or uses /context command
        relevant_context = ""
        if not no_context and ("@" in user_input or user_input.startswith("/context")):
            with console.status("[cyan]Loading context...", spinner="dots"):
                relevant_context = _load_relevant_context(root, user_input, cache)

        # Add context and user message
        user_message = user_input
        if relevant_context:
            user_message = f"{user_input}\n\n# Relevant Code Context:\n{relevant_context}"

        messages.append({"role": "user", "content": user_message})

        try:
            console.print("\n[bold cyan]🤖 Assistant[/bold cyan]")
            console.print()

            # Enable streaming if provider supports it
            if isinstance(provider, BaseProvider):
                response = provider.chat(messages, stream=True)
                content_stream = provider.extract_content(response, stream=True)

                # Stream and accumulate response with higher refresh rate
                accumulated = ""
                with Live(console=console, refresh_per_second=20, transient=False) as live:
                    for chunk in content_stream:
                        accumulated += chunk
                        # Only update every few chunks for better performance
                        if len(accumulated) % 50 < len(chunk):  # Update roughly every 50 chars
                            md = Markdown(accumulated)
                            live.update(md)
                    # Final update
                    md = Markdown(accumulated)
                    live.update(md)

                response_text = accumulated
            else:
                # Fallback to non-streaming
                with console.status("[cyan]Thinking...", spinner="dots"):
                    response = provider.chat(messages, stream=False)
                    response_text = _extract_response_text(response)

                md = Markdown(response_text)
                console.print(md)

            console.print()
            messages.append({"role": "assistant", "content": response_text})

        except Exception as e:
            console.print(f"\n[bold red]❌ Error:[/bold red] {e}\n")
            # Remove the last user message if we failed
            if messages[-1]["role"] == "user":
                messages.pop()

    return 0


def _run_chat_plain(root: str, provider: Any, model: str, no_context: bool = False) -> int:
    """Run chat with plain terminal (fallback when rich not available)."""
    print(f"🤖 Ollcoder Chat (model: {model})")
    print(f"📁 Project: {root}")
    if no_context:
        print("⚡ Fast mode: Context loading disabled")
    print("💬 Type your message (or 'exit' to quit)\n")

    cache = ContextCache(root)
    messages = [
        {
            "role": "system",
            "content": (
                "You are a helpful coding assistant. Be conversational and concise.\n"
                "When the user asks about specific files or features, I will provide relevant code context.\n"
                "Only explain code details when asked."
            ),
        },
    ]

    while True:
        try:
            user_input = input("\nYou: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n👋 Goodbye!")
            return 0

        if not user_input:
            continue

        if user_input.lower() in ("exit", "quit", "q"):
            print("\n👋 Goodbye!")
            return 0

        # Dynamically load context (skip for simple queries or if disabled)
        relevant_context = ""
        if not no_context:
            query_lower = user_input.lower().strip()
            needs_context = len(user_input) >= 10 and query_lower not in (
                "hi",
                "hello",
                "hey",
                "thanks",
                "thank you",
                "ok",
                "okay",
                "yes",
                "no",
                "sure",
                "great",
                "cool",
                "nice",
                "good",
            )

            if needs_context:
                print("[Loading context...]", end="", flush=True)
                relevant_context = _load_relevant_context(root, user_input, cache)
                print("\r" + " " * 20 + "\r", end="", flush=True)  # Clear loading message

        user_message = user_input
        if relevant_context:
            user_message = f"{user_input}\n\n# Relevant Code Context:\n{relevant_context}"

        messages.append({"role": "user", "content": user_message})

        try:
            print("\n🤖 Assistant: ", end="", flush=True)

            # Enable streaming if provider supports it
            if isinstance(provider, BaseProvider):
                response = provider.chat(messages, stream=True)
                content_stream = provider.extract_content(response, stream=True)

                accumulated = ""
                for chunk in content_stream:
                    print(chunk, end="", flush=True)
                    accumulated += chunk

                print("\n")
                response_text = accumulated
            else:
                # Fallback to non-streaming
                response = provider.chat(messages, stream=False)
                response_text = _extract_response_text(response)
                print(response_text + "\n")

            messages.append({"role": "assistant", "content": response_text})

        except Exception as e:
            print(f"\n❌ Error: {e}\n")
            if messages[-1]["role"] == "user":
                messages.pop()

    return 0


def _extract_response_text(resp: Any) -> str:
    """Extract text from provider response."""
    if resp is None:
        return ""

    # Ollama returns objects with .message.content attribute
    if hasattr(resp, "message"):
        msg = getattr(resp, "message")
        if msg and hasattr(msg, "content"):
            content = getattr(msg, "content")
            if isinstance(content, str) and content.strip():
                return content

    # Gemini style
    txt = getattr(resp, "text", None)
    if isinstance(txt, str) and txt.strip():
        return txt

    # Dict style fallback
    if isinstance(resp, dict):
        msg = resp.get("message")
        if isinstance(msg, dict):
            c = msg.get("content")
            if isinstance(c, str) and c.strip():
                return c
        c = resp.get("content")
        if isinstance(c, str) and c.strip():
            return c

    return ""


def _extract_chunk_text(chunk: Any) -> str:
    """Extract text from streaming chunk."""
    if isinstance(chunk, dict):
        msg = chunk.get("message", {})
        if isinstance(msg, dict):
            return msg.get("content", "")
        return chunk.get("content", "")

    # Gemini streaming chunks
    txt = getattr(chunk, "text", None)
    if isinstance(txt, str):
        return txt

    return ""
