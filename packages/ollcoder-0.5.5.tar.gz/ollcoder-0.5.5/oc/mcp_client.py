from __future__ import annotations

import json
import os
import subprocess
import threading
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple


def _encode_message(payload: Dict[str, Any]) -> bytes:
    body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    headers = f"Content-Length: {len(body)}\r\n\r\n".encode("ascii")
    return headers + body


def _read_frame(readline, read_exact) -> Optional[Dict[str, Any]]:
    """Read a single Content-Length framed JSON-RPC message.

    readline: function to read a line (including trailing \n), returns bytes
    read_exact: function to read an exact number of bytes, returns bytes
    """
    # Read headers
    content_length = None
    while True:
        line = readline()
        if not line:
            return None
        if line in (b"\r\n", b"\n"):
            break
        lower = line.lower()
        if lower.startswith(b"content-length:"):
            try:
                content_length = int(line.split(b":", 1)[1].strip())
            except Exception:
                pass
    if content_length is None:
        return None
    body = read_exact(content_length)
    if not body:
        return None
    try:
        return json.loads(body.decode("utf-8"))
    except Exception:
        return None


@dataclass
class MCPClientConfig:
    command: Tuple[str, ...]
    cwd: Optional[str] = None
    env: Optional[Dict[str, str]] = None
    timeout_seconds: float = 10.0


class MCPClient:
    """Minimal stdio JSON-RPC (Content-Length) MCP client.

    Methods implemented as conveniences (common MCP shapes):
      - initialize()
      - list_resources()
      - read_resource(uri)
      - list_tools()
      - call_tool(name, arguments)

    A generic rpc(method, params) is provided for flexibility.
    """

    def __init__(self, cfg: MCPClientConfig) -> None:
        self.cfg = cfg
        self.proc: Optional[subprocess.Popen[bytes]] = None
        self._id = 0
        self._lock = threading.Lock()

    # ---- Process management ---- #
    def start(self) -> None:
        if self.proc is not None:
            return
        env = os.environ.copy()
        if self.cfg.env:
            env.update(self.cfg.env)
        self.proc = subprocess.Popen(
            self.cfg.command,
            cwd=self.cfg.cwd or None,
            env=env,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

    def close(self) -> None:
        if self.proc is None:
            return
        try:
            self.proc.terminate()
        except Exception:
            pass
        self.proc = None

    # ---- RPC ---- #
    def rpc(self, method: str, params: Optional[Dict[str, Any]] = None) -> Any:
        if self.proc is None:
            self.start()
        assert self.proc is not None
        assert self.proc.stdin is not None and self.proc.stdout is not None

        with self._lock:
            self._id += 1
            req_id = self._id
            msg = {"jsonrpc": "2.0", "id": req_id, "method": method}
            if params is not None:
                msg["params"] = params

            # Write request
            self.proc.stdin.write(_encode_message(msg))
            self.proc.stdin.flush()

            # Read responses until matching id
            start = time.time()
            while True:
                if time.time() - start > max(1.0, self.cfg.timeout_seconds):
                    raise TimeoutError(f"MCP RPC timeout waiting for {method}")

                # Prepare readers
                def _readline():
                    return self.proc.stdout.readline()

                def _read_exact(n: int):
                    data = b""
                    remaining = n
                    while remaining > 0:
                        chunk = self.proc.stdout.read(remaining)
                        if not chunk:
                            break
                        data += chunk
                        remaining -= len(chunk)
                    return data

                obj = _read_frame(_readline, _read_exact)
                if obj is None:
                    # Possibly stderr noise; continue
                    continue
                if obj.get("id") == req_id:
                    if "error" in obj:
                        raise RuntimeError(f"MCP error: {obj['error']}")
                    return obj.get("result")

    # ---- Convenience methods ---- #
    def initialize(self) -> Any:
        return self.rpc("initialize", {"protocolVersion": "0.1"})

    def list_resources(self) -> Any:
        return self.rpc("resources/list", {})

    def read_resource(self, uri: str) -> Any:
        return self.rpc("resources/read", {"uri": uri})

    def list_tools(self) -> Any:
        return self.rpc("tools/list", {})

    def call_tool(self, name: str, arguments: Optional[Dict[str, Any]] = None) -> Any:
        return self.rpc("tools/call", {"name": name, "arguments": arguments or {}})
