from __future__ import annotations

import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional

try:
    from watchdog.events import FileSystemEventHandler  # type: ignore
    from watchdog.observers import Observer  # type: ignore
except Exception:  # pragma: no cover - optional
    FileSystemEventHandler = None  # type: ignore
    Observer = None  # type: ignore


@dataclass(frozen=True)
class WatchConfig:
    root: str
    command: str = "oc checks run"
    debounce_ms: int = 400
    patterns: Optional[Iterable[str]] = None


def _run(cmd: str) -> int:
    """Run command safely without shell=True.

    Splits command into args to avoid shell injection vulnerabilities.
    """
    print(f"[watch] running: {cmd}")
    try:
        # Split command into args (simple split on whitespace)
        # For more complex commands, user should use a script file
        import shlex

        args = shlex.split(cmd)
        return subprocess.call(args)
    except Exception as e:
        print(f"[watch] error: {e}")
        return 1


def watch(cfg: WatchConfig) -> int:
    root = Path(cfg.root)
    if Observer and FileSystemEventHandler:
        # Watchdog-based
        last_ts = 0.0

        class H(FileSystemEventHandler):  # type: ignore[misc]
            def on_any_event(self, event):  # type: ignore[override]
                nonlocal last_ts
                now = time.time() * 1000
                if now - last_ts < cfg.debounce_ms:
                    return
                last_ts = now
                _run(cfg.command)

        obs = Observer()
        obs.schedule(H(), str(root), recursive=True)
        obs.start()
        print(f"[watch] Watching {root} (Ctrl-C to stop)")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass
        finally:
            obs.stop()
            obs.join()
        return 0

    # Fallback: simple polling by mtime
    print("[watch] watchdog not installed; using polling")
    mtimes: dict[str, float] = {}
    try:
        while True:
            changed = False
            for p in root.rglob("*"):
                if not p.is_file():
                    continue
                try:
                    m = p.stat().st_mtime
                except Exception:
                    continue
                key = str(p)
                old = mtimes.get(key)
                if old is None:
                    mtimes[key] = m
                    continue
                if m > old:
                    mtimes[key] = m
                    changed = True
            if changed:
                _run(cfg.command)
            time.sleep(max(0.2, cfg.debounce_ms / 1000.0))
    except KeyboardInterrupt:
        return 0
