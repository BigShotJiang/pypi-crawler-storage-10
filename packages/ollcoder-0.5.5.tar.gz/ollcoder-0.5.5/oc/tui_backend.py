"""
Backend integration for advanced TUI features.
Connects TUI screens to actual ollcoder functionality.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .adaptive_builder import AdaptiveConfig, build_adaptive_context
from .agent import AgentConfig, run_agent
from .context_cache import ContextCache
from .diff import compute_unified_diff
from .memory import global_memory
from .security import scan as security_scan
from .security import to_sarif


class ContextBuilderBackend:
    """Backend for context builder feature."""

    def __init__(self, root: str, provider: Any):
        self.root = root
        self.provider = provider
        self.cache = ContextCache(root)

    def build_context(self, query: str, compression: str = "LITE") -> tuple[str, dict]:
        """Build context for query.

        Args:
            query: Search query
            compression: CompressionLevel name (NONE, LITE, NO_COMMENTS, SIGNATURES, SUMMARY)
        """
        # Map old values to valid CompressionLevel enum names
        compression_map = {
            "MODERATE": "LITE",
            "SEMANTIC": "NO_COMMENTS",
            "HEURISTIC": "SIGNATURES",
            "AGGRESSIVE": "SUMMARY",
        }
        compression_level = compression_map.get(compression, compression)

        config = AdaptiveConfig(
            root_dir=self.root, query=query, compression_level=compression_level
        )

        files, stats = build_adaptive_context(config, cache=self.cache, provider=self.provider)

        # Format output
        lines = [f"# Context for: {query}", f"# Files: {len(files)}", ""]
        for f in files[:10]:  # Show top 10
            lines.append(f"## {f.path} [{f.priority.name}]")
            lines.append(f"```\n{f.content[:500]}...\n```")
            lines.append("")

        return "\n".join(lines), stats


class MemoryBackend:
    """Backend for memory viewer feature."""

    def __init__(self, root: str):
        self.root = root
        self.memory = global_memory()

    def get_sessions(self) -> list[dict]:
        """Get all sessions."""
        sessions = []
        for sid, session in self.memory.sessions.items():
            sessions.append(
                {
                    "session_id": sid,
                    "root_dir": session.root_dir,
                    "created_at": session.created_at,
                    "task_count": len(session.tasks),
                    "pattern_count": len(session.successful_patterns),
                }
            )
        return sorted(sessions, key=lambda x: x["created_at"], reverse=True)

    def get_patterns(self, session_id: str) -> list[str]:
        """Get learned patterns for session."""
        if session_id not in self.memory.sessions:
            return []
        session = self.memory.sessions[session_id]
        return session.successful_patterns

    def get_errors(self, session_id: str) -> dict[str, int]:
        """Get common errors for session."""
        if session_id not in self.memory.sessions:
            return {}
        session = self.memory.sessions[session_id]
        return session.common_errors


class AgentBackend:
    """Backend for autonomous agent feature."""

    def __init__(self, root: str, provider: Any):
        self.root = root
        self.provider = provider
        self.running = False

    def run(self, task: str, max_steps: int = 6, apply: bool = False, callback=None):
        """Run agent with progress callback."""
        self.running = True

        config = AgentConfig(
            root_dir=self.root, task=task, max_steps=max_steps, apply_changes=apply, use_memory=True
        )

        try:
            result = run_agent(config, provider=self.provider)

            if callback:
                callback(
                    {
                        "status": "complete",
                        "success": result.success,
                        "steps": len(result.steps),
                        "message": result.final_message,
                    }
                )

            return result
        except Exception as e:
            if callback:
                callback({"status": "error", "message": str(e)})
            raise
        finally:
            self.running = False

    def stop(self):
        """Stop agent execution."""
        self.running = False


class SecurityBackend:
    """Backend for security scanner feature."""

    def __init__(self, root: str):
        self.root = root

    def scan(self) -> list[dict]:
        """Run security scan."""
        issues = security_scan(self.root)

        results = []
        for issue in issues:
            results.append(
                {
                    "severity": issue.severity,
                    "file": issue.path,
                    "line": issue.line or 0,
                    "rule": issue.rule,
                    "message": issue.message,
                }
            )

        return sorted(
            results,
            key=lambda x: (
                {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}.get(x["severity"], 4),
                x["file"],
            ),
        )

    def export_sarif(self, output_path: str) -> bool:
        """Export results to SARIF format."""
        try:
            issues = security_scan(self.root)
            sarif = to_sarif(issues)

            Path(output_path).write_text(__import__("json").dumps(sarif, indent=2))
            return True
        except Exception:
            return False


class DiffBackend:
    """Backend for code diff preview."""

    @staticmethod
    def compute_diff(old_content: str, new_content: str, filepath: str) -> str:
        """Compute unified diff."""
        return compute_unified_diff(old_content, new_content, filepath)

    @staticmethod
    def apply_diff(filepath: str, new_content: str) -> bool:
        """Apply changes to file."""
        try:
            Path(filepath).write_text(new_content)
            return True
        except Exception:
            return False


class StreamingBackend:
    """Backend for streaming AI responses."""

    def __init__(self, provider: Any):
        self.provider = provider

    async def stream_response(self, messages: list[dict], callback):
        """Stream AI response character by character."""
        try:
            # Check if provider supports streaming
            if hasattr(self.provider, "chat") and hasattr(self.provider.chat, "__call__"):
                response = self.provider.chat(messages, stream=True)

                # Handle different provider response formats
                if hasattr(response, "__iter__"):
                    buffer = ""
                    for chunk in response:
                        if hasattr(chunk, "message") and hasattr(chunk.message, "content"):
                            text = chunk.message.content
                        elif isinstance(chunk, dict) and "content" in chunk:
                            text = chunk["content"]
                        else:
                            text = str(chunk)

                        buffer += text
                        if callback:
                            await callback(buffer)

                    return buffer
                else:
                    # Fallback: no streaming support
                    result = response
                    if hasattr(result, "message") and hasattr(result.message, "content"):
                        text = result.message.content
                    elif hasattr(result, "text"):
                        text = result.text
                    elif isinstance(result, dict):
                        text = result.get("content", str(result))
                    else:
                        text = str(result)

                    if callback:
                        await callback(text)
                    return text
        except Exception as e:
            if callback:
                await callback(f"Error: {str(e)}")
            raise
