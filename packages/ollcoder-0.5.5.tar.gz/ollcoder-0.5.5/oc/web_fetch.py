from __future__ import annotations

import re
from typing import Optional, Tuple

try:
    import requests  # type: ignore[import-untyped]
except Exception:  # pragma: no cover - optional
    requests = None  # type: ignore[assignment]

try:
    from bs4 import BeautifulSoup  # type: ignore
except Exception:  # pragma: no cover - optional
    BeautifulSoup = None  # type: ignore


def _strip_tags(html: str) -> str:
    # Naive fallback if BeautifulSoup not available
    text = re.sub(r"<script[\s\S]*?</script>", "", html, flags=re.I)
    text = re.sub(r"<style[\s\S]*?</style>", "", text, flags=re.I)
    text = re.sub(r"<[^>]+>", "", text)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def fetch_url(url: str, timeout: int = 15) -> Tuple[str, Optional[str]]:
    if requests is None:
        raise RuntimeError("requests is required; install with `pip install '.[web]'`")
    r = requests.get(url, timeout=timeout)
    r.raise_for_status()
    content_type = (r.headers.get("content-type") or "").lower()
    if "text/html" not in content_type:
        return r.text, None
    html = r.text
    title = None
    if BeautifulSoup is not None:
        soup = BeautifulSoup(html, "html.parser")
        if soup.title and soup.title.string:
            title = soup.title.string.strip()
        for tag in soup(["script", "style", "noscript"]):
            tag.decompose()
        text = soup.get_text("\n")
        # Collapse excessive blanks
        lines = [ln.strip() for ln in text.splitlines()]
        text = "\n".join([ln for ln in lines if ln])
    else:
        text = _strip_tags(html)
    return text, title
