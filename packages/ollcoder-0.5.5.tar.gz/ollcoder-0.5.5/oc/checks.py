from __future__ import annotations

import shutil
import subprocess
from dataclasses import dataclass, field
from typing import List, Tuple


@dataclass(frozen=True)
class ChecksConfig:
    commands: Tuple[Tuple[str, ...], ...] = field(
        default=(
            ("ruff", "check", "."),
            ("mypy", "oc"),
            ("pytest", "-q", "oc_tests"),
        )
    )
    continue_on_error: bool = True
    timeout_seconds: int = 120


@dataclass(frozen=True)
class CheckResult:
    cmd: Tuple[str, ...]
    ok: bool
    exit_code: int
    stdout: str
    stderr: str


def run_checks(cfg: ChecksConfig | None = None) -> Tuple[List[CheckResult], int]:
    cfg = cfg or ChecksConfig()
    results: List[CheckResult] = []
    worst = 0
    for cmd in cfg.commands:
        exe = cmd[0]
        if shutil.which(exe) is None:
            results.append(CheckResult(cmd, True, 0, "", f"{exe} not found; skipping"))
            continue
        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True, timeout=max(1, cfg.timeout_seconds)
            )
            ok = proc.returncode == 0
            results.append(
                CheckResult(cmd, ok, proc.returncode, proc.stdout or "", proc.stderr or "")
            )
            if not ok:
                worst = worst or proc.returncode
                if not cfg.continue_on_error:
                    break
        except Exception as e:
            results.append(CheckResult(cmd, False, -1, "", str(e)))
            worst = worst or 1
            if not cfg.continue_on_error:
                break
    return results, worst
