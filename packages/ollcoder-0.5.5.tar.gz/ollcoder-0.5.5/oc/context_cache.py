from __future__ import annotations

import base64
import gzip
import hashlib
import json
import os
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from .context_compression import CompressedResult, CompressionLevel

DEFAULT_TTL_SECONDS = 24 * 60 * 60  # 24 hours


@dataclass(frozen=True)
class FileState:
    path: str
    size: int
    mtime: float
    md5: Optional[str] = None


@dataclass(frozen=True)
class CacheEntry:
    version: int
    created_at: float
    expires_at: float
    key: str
    provider: Optional[str]
    level: str
    file_state: FileState
    result: CompressedResult


class ContextCache:
    """MD5-keyed cache with 24h TTL and file-change validation.

    Stores compressed results per file and compression level. Keys are derived
    from the normalized absolute path, compression level, and optional provider
    fingerprint. Validation uses TTL expiration and current file mtime/size,
    with an MD5 equality check when mtime/size mismatch is detected.
    """

    def __init__(
        self, root_dir: str, cache_dir: Optional[str] = None, ttl_seconds: int = DEFAULT_TTL_SECONDS
    ) -> None:
        self.root_dir = str(Path(root_dir).resolve())
        self.cache_dir = str(Path(cache_dir or (Path(self.root_dir) / ".oc_cache")).resolve())
        self.ttl_seconds = int(ttl_seconds)
        Path(self.cache_dir).mkdir(parents=True, exist_ok=True)

    # -------- Public API -------- #

    def get(
        self,
        path: str,
        level: CompressionLevel,
        provider_fingerprint: Optional[str] = None,
        *,
        strict_md5_on_mismatch: bool = True,
    ) -> Optional[CompressedResult]:
        """Return cached result if fresh and file unchanged; otherwise None."""
        key = self._make_key(path, level, provider_fingerprint)
        entry = self._read_entry(key)
        if entry is None:
            return None

        now = time.time()
        if now >= entry.expires_at:
            self._delete_key(key)
            return None

        current_state = self._file_state(entry.file_state.path, compute_md5=False)
        # Edge case: same size and same-second mtime can mask content changes; verify by MD5
        if (entry.file_state.size == current_state.size) and (
            int(entry.file_state.mtime) == int(current_state.mtime)
        ):
            current_state = self._file_state(entry.file_state.path, compute_md5=True)
            if (
                entry.file_state.md5 is not None
                and current_state.md5 is not None
                and entry.file_state.md5 != current_state.md5
            ):
                self._delete_key(key)
                return None

        if not self._state_matches(entry.file_state, current_state):
            # If size/mtime mismatch, optionally verify by MD5 to allow same-content rewrites
            if strict_md5_on_mismatch:
                current_state = self._file_state(entry.file_state.path, compute_md5=True)
                if not self._state_matches(entry.file_state, current_state):
                    self._delete_key(key)
                    return None
            else:
                self._delete_key(key)
                return None

        return entry.result

    def put(
        self,
        result: CompressedResult,
        provider_fingerprint: Optional[str] = None,
        *,
        path_override: Optional[str] = None,
    ) -> CacheEntry:
        """Store result and return the cache entry."""
        level = result.level
        path = path_override or result.path
        key = self._make_key(path, level, provider_fingerprint)

        fstate = self._file_state(path, compute_md5=True)
        now = time.time()
        entry = CacheEntry(
            version=1,
            created_at=now,
            expires_at=now + self.ttl_seconds,
            key=key,
            provider=provider_fingerprint,
            level=level.name,
            file_state=fstate,
            result=result,
        )
        self._write_entry(entry)
        return entry

    def invalidate(self, path: Optional[str] = None) -> int:
        """Invalidate cache globally or for a specific file. Returns count removed."""
        if path is None:
            return self._clear()
        # Scan cache files and remove entries matching normalized path
        norm = str(Path(path).resolve())
        removed = 0
        for p in self._iter_cache_files():
            try:
                with open(p, "r", encoding="utf-8") as fh:
                    data = json.load(fh)
                cached_path = data.get("file_state", {}).get("path")
                if cached_path and str(Path(cached_path).resolve()) == norm:
                    os.remove(p)
                    removed += 1
            except Exception:
                continue
        return removed

    # -------- Internals -------- #

    def _make_key(
        self, path: str, level: CompressionLevel, provider_fingerprint: Optional[str]
    ) -> str:
        abs_path = str(Path(path).resolve())
        blob = f"{abs_path}\n{level.name}\n{provider_fingerprint or '-'}".encode("utf-8")
        return hashlib.md5(blob).hexdigest()

    def _cache_path(self, key: str) -> Path:
        sub = key[:2]
        d = Path(self.cache_dir) / sub
        d.mkdir(parents=True, exist_ok=True)
        return d / f"{key}.json"

    def _write_entry(self, entry: CacheEntry) -> None:
        path = self._cache_path(entry.key)
        payload = self._entry_to_json(entry)
        tmp = str(path) + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, separators=(",", ":"))
        os.replace(tmp, path)

    def _read_entry(self, key: str) -> Optional[CacheEntry]:
        path = self._cache_path(key)
        if not path.exists():
            return None
        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            return self._entry_from_json(data)
        except Exception:
            # Corrupt entry, delete it
            try:
                path.unlink(missing_ok=True)
            except Exception:
                pass
            return None

    def _delete_key(self, key: str) -> None:
        try:
            self._cache_path(key).unlink(missing_ok=True)
        except Exception:
            pass

    def _clear(self) -> int:
        removed = 0
        for p in self._iter_cache_files():
            try:
                os.remove(p)
                removed += 1
            except Exception:
                continue
        return removed

    def _iter_cache_files(self):
        base = Path(self.cache_dir)
        if not base.exists():
            return []
        files: List[str] = []
        for root, _dirs, filenames in os.walk(base):
            for fn in filenames:
                if fn.endswith(".json"):
                    files.append(str(Path(root) / fn))
        return files

    def _file_state(self, path: str, *, compute_md5: bool) -> FileState:
        p = Path(path)
        try:
            st = p.stat()
            md5_hex: Optional[str] = None
            if compute_md5:
                md5_hex = _md5_file(p)
            return FileState(path=str(p), size=st.st_size, mtime=st.st_mtime, md5=md5_hex)
        except FileNotFoundError:
            return FileState(path=str(p), size=-1, mtime=-1.0, md5=None)

    @staticmethod
    def _state_matches(a: FileState, b: FileState) -> bool:
        if a.size == b.size and int(a.mtime) == int(b.mtime):
            return True
        # If md5 available on both, compare
        if a.md5 is not None and b.md5 is not None:
            return a.md5 == b.md5
        return False

    @staticmethod
    def _entry_to_json(entry: CacheEntry) -> Dict[str, Any]:
        # dataclasses asdict would deeply convert; we need to flatten enums
        res = entry.result
        payload: Dict[str, Any] = {
            "version": entry.version,
            "created_at": entry.created_at,
            "expires_at": entry.expires_at,
            "key": entry.key,
            "provider": entry.provider,
            "level": entry.level,
            "file_state": asdict(entry.file_state),
            "result": {
                "path": res.path,
                "level": res.level.name,
                "original_bytes": res.original_bytes,
                "compressed_bytes": res.compressed_bytes,
                # content field may be replaced by gzip_b64 for large values
                "meta": res.meta,
            },
        }
        content_bytes = res.content.encode("utf-8", errors="replace")
        if len(content_bytes) > 2048:
            gz = gzip.compress(content_bytes)
            payload["result"]["content_gzip_b64"] = base64.b64encode(gz).decode("ascii")
        else:
            payload["result"]["content"] = res.content
        return payload

    @staticmethod
    def _entry_from_json(data: Dict[str, Any]) -> CacheEntry:
        fs_raw = data.get("file_state", {})
        fs = FileState(
            path=fs_raw.get("path", ""),
            size=int(fs_raw.get("size", -1)),
            mtime=float(fs_raw.get("mtime", -1.0)),
            md5=fs_raw.get("md5"),
        )
        r_raw = data.get("result", {})
        # Support optional gzip+base64 content
        content: str
        if "content" in r_raw:
            content = r_raw.get("content", "")
        else:
            try:
                gz_b64 = r_raw.get("content_gzip_b64")
                content = (
                    gzip.decompress(base64.b64decode(gz_b64)).decode("utf-8", errors="replace")
                    if gz_b64
                    else ""
                )
            except Exception:
                content = ""
        result = CompressedResult(
            path=r_raw.get("path", ""),
            level=CompressionLevel[r_raw.get("level", "NONE")],
            original_bytes=int(r_raw.get("original_bytes", 0)),
            compressed_bytes=int(r_raw.get("compressed_bytes", 0)),
            content=content,
            meta=r_raw.get("meta", {}) or {},
        )
        return CacheEntry(
            version=int(data.get("version", 1)),
            created_at=float(data.get("created_at", 0.0)),
            expires_at=float(data.get("expires_at", 0.0)),
            key=data.get("key", ""),
            provider=data.get("provider"),
            level=data.get("level", "NONE"),
            file_state=fs,
            result=result,
        )


def _md5_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def provider_fingerprint(provider: Any) -> str:
    """Return stable fingerprint for provider config.

    Tries common attributes like `model`/`model_name`; falls back to class name.
    """
    if provider is None:
        return "-"
    model = getattr(provider, "model", None) or getattr(provider, "model_name", None)
    name = provider.__class__.__name__
    raw = f"{name}:{model or '-'}"
    return hashlib.md5(raw.encode("utf-8")).hexdigest()
