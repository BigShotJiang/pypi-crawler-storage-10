from __future__ import annotations

import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Mapping, Optional, Sequence, Tuple


class SandboxError(Exception):
    pass


@dataclass(frozen=True)
class Mount:
    host_path: str
    container_path: str
    read_only: bool = True


@dataclass(frozen=True)
class SandboxConfig:
    image: str
    workdir: str = "/workspace"
    mounts: Tuple[Mount, ...] = field(default_factory=tuple)
    env: Mapping[str, str] = field(default_factory=dict)

    # Security & isolation
    network_isolation: bool = True
    read_only_root: bool = True

    # Resource limits
    cpus: float = 1.0  # e.g. 0.5, 1.0, 2.0
    memory: str = "1g"  # docker-style (e.g. 512m, 2g)
    pids_limit: Optional[int] = 256

    # Execution
    timeout_seconds: Optional[int] = 120
    engine: Optional[str] = None  # "docker" | "podman" | None (auto)
    user: Optional[str] = None  # e.g. "1000:1000"; if None, container default


@dataclass(frozen=True)
class RunResult:
    ok: bool
    exit_code: int
    stdout: str
    stderr: str
    timed_out: bool
    command: List[str]


class SandboxRunner:
    """Run commands inside a container using Docker or Podman.

    Features:
    - Docker & Podman support (auto-detect if not specified)
    - Resource limits: CPUs, memory, PIDs
    - Network isolation via --network=none
    - Read-only root filesystem and read-only mounts by default
    - JSON-friendly results
    - No shell=True; arguments are passed as a list for safety
    """

    def __init__(self, cfg: SandboxConfig) -> None:
        engine = cfg.engine or self._detect_engine()
        if engine not in {"docker", "podman"}:
            raise SandboxError("No supported container engine found (docker or podman)")
        self.engine = engine
        self.cfg = cfg

    # ---- Public API ---- #

    def run(self, args: Sequence[str]) -> RunResult:
        if not args:
            raise SandboxError("No command provided to run in sandbox")

        cmd = self._build_run_command(args)
        timeout = self.cfg.timeout_seconds
        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout if timeout and timeout > 0 else None,
            )
            return RunResult(
                ok=proc.returncode == 0,
                exit_code=proc.returncode,
                stdout=proc.stdout or "",
                stderr=proc.stderr or "",
                timed_out=False,
                command=cmd,
            )
        except subprocess.TimeoutExpired as e:
            stdout_s = str(getattr(e, "stdout", "") or "")
            stderr_s = str(getattr(e, "stderr", "") or "Execution timed out")
            return RunResult(
                ok=False,
                exit_code=-1,
                stdout=stdout_s,
                stderr=stderr_s,
                timed_out=True,
                command=cmd,
            )
        except FileNotFoundError as e:
            raise SandboxError(f"Engine not found: {self.engine}") from e
        except Exception as e:
            raise SandboxError(str(e)) from e

    def pull(self) -> RunResult:
        cmd = [self.engine, "pull", self.cfg.image]
        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.cfg.timeout_seconds
                if self.cfg.timeout_seconds and self.cfg.timeout_seconds > 0
                else None,
            )
            return RunResult(
                ok=proc.returncode == 0,
                exit_code=proc.returncode,
                stdout=proc.stdout or "",
                stderr=proc.stderr or "",
                timed_out=False,
                command=cmd,
            )
        except Exception as e:
            raise SandboxError(str(e)) from e

    # ---- Internals ---- #

    def _detect_engine(self) -> str:
        for name in ("docker", "podman"):
            if shutil.which(name):
                return name
        return ""  # handled by __init__

    def _build_run_command(self, inner_args: Sequence[str]) -> List[str]:
        c = self.cfg
        cmd: List[str] = [self.engine, "run", "--rm"]

        # Network
        if c.network_isolation:
            cmd += ["--network", "none"]

        # Resources
        if c.cpus and c.cpus > 0:
            # Docker/Podman support --cpus
            cmd += ["--cpus", str(c.cpus)]
        if c.memory:
            cmd += ["--memory", c.memory]
        if c.pids_limit:
            cmd += ["--pids-limit", str(c.pids_limit)]

        # FS security
        if c.read_only_root:
            cmd.append("--read-only")
        # No-new-privileges (supported by both; Docker requires true value)
        cmd += ["--security-opt", "no-new-privileges:true"]

        # User mapping if provided
        if c.user:
            cmd += ["--user", c.user]

        # Env vars
        for k, v in (c.env or {}).items():
            # Avoid None values
            if v is None:
                continue
            cmd += ["-e", f"{k}={v}"]

        # Mounts
        mounts = list(c.mounts)
        # Ensure workspace mount exists (even read-only) if a host mount is provided for it
        for m in mounts:
            host = str(Path(m.host_path).resolve())
            cont = m.container_path
            mode = "ro" if m.read_only else "rw"
            cmd += ["-v", f"{host}:{cont}:{mode}"]

        # Workdir
        if c.workdir:
            cmd += ["-w", c.workdir]

        # Image and command
        cmd.append(c.image)
        cmd += list(inner_args)
        return cmd
