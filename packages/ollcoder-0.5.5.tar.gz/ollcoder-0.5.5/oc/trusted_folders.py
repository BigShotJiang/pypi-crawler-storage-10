from __future__ import annotations

import json
import sys
import time
from dataclasses import asdict, dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Tuple


class TrustLevel(Enum):
    UNTRUSTED = 0
    LOW = 1
    TRUSTED = 2
    OWNER = 3


@dataclass
class Policy:
    allow_read: bool = True
    allow_write: bool = False
    allow_execute: bool = False
    allow_delete: bool = False
    allow_network: bool = False

    prompt_on_write: bool = False
    prompt_on_execute: bool = False
    prompt_on_network: bool = False


DEFAULT_POLICIES: Dict[TrustLevel, Policy] = {
    TrustLevel.UNTRUSTED: Policy(
        allow_read=True,
        allow_write=False,
        allow_execute=False,
        allow_delete=False,
        allow_network=False,
        prompt_on_write=False,
        prompt_on_execute=False,
        prompt_on_network=False,
    ),
    TrustLevel.LOW: Policy(
        allow_read=True,
        allow_write=True,
        allow_execute=False,
        allow_delete=False,
        allow_network=False,
        prompt_on_write=False,  # allow writes without prompt at LOW
        prompt_on_execute=False,
        prompt_on_network=False,
    ),
    TrustLevel.TRUSTED: Policy(
        allow_read=True,
        allow_write=True,
        allow_execute=True,
        allow_delete=True,
        allow_network=True,
        prompt_on_write=False,
        prompt_on_execute=True,  # confirm executes
        prompt_on_network=True,  # confirm network
    ),
    TrustLevel.OWNER: Policy(
        allow_read=True,
        allow_write=True,
        allow_execute=True,
        allow_delete=True,
        allow_network=True,
        prompt_on_write=False,
        prompt_on_execute=False,
        prompt_on_network=False,
    ),
}


@dataclass
class TrustEntry:
    path: str
    level: str
    created_at: float
    policy_overrides: Optional[Dict[str, Any]] = None


Prompter = Callable[[str, str, TrustLevel, TrustLevel], Tuple[bool, Optional[TrustLevel], bool]]
# Returns (allow_now, new_level, remember)


def _default_config_path() -> Path:
    return Path.home() / ".config" / "ollcoder" / "trusted_folders.json"


class TrustedFoldersManager:
    def __init__(self, config_path: Optional[str] = None) -> None:
        self.config_path = Path(config_path) if config_path else _default_config_path()
        self.entries: Dict[str, TrustEntry] = {}
        self.session_levels: Dict[str, TrustLevel] = {}
        self._load()

    # ---- Persistence ---- #
    def _load(self) -> None:
        try:
            if self.config_path.is_file():
                data = json.loads(self.config_path.read_text())
                for item in data.get("entries", []):
                    p = str(Path(item["path"]).resolve())
                    lvl = str(item.get("level", "UNTRUSTED"))
                    self.entries[p] = TrustEntry(
                        path=p,
                        level=lvl,
                        created_at=float(item.get("created_at", time.time())),
                        policy_overrides=item.get("policy_overrides"),
                    )
        except Exception:
            self.entries = {}

    def _save(self) -> None:
        try:
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            payload = {
                "version": 1,
                "updated_at": time.time(),
                "entries": [asdict(e) for e in self.entries.values()],
            }
            self.config_path.write_text(json.dumps(payload, indent=2))
        except Exception:
            # best-effort
            pass

    # ---- Query ---- #
    def get_level(self, path: str) -> TrustLevel:
        p = Path(path).resolve()
        # Session override exact or ancestor
        lvl = self._lookup_session_level(p)
        if lvl is not None:
            return lvl
        # Persistent entries: pick the deepest ancestor
        best_path = None
        best_entry = None
        rp = str(p)
        for epath, entry in self.entries.items():
            if rp == epath or rp.startswith(epath.rstrip("/") + "/"):
                if best_path is None or len(epath) > len(best_path):
                    best_path = epath
                    best_entry = entry
        if best_entry is None:
            return TrustLevel.UNTRUSTED
        try:
            return TrustLevel[best_entry.level]
        except Exception:
            return TrustLevel.UNTRUSTED

    def set_level(self, folder: str, level: TrustLevel, *, persist: bool = True) -> None:
        p = str(Path(folder).resolve())
        if persist:
            self.entries[p] = TrustEntry(path=p, level=level.name, created_at=time.time())
            self._save()
        else:
            self.session_levels[p] = level

    def policy_for(self, path: str) -> Policy:
        lvl = self.get_level(path)
        base = DEFAULT_POLICIES.get(lvl, DEFAULT_POLICIES[TrustLevel.UNTRUSTED])
        # Apply overrides for the matched persistent entry only
        entry = self._matched_entry(path)
        if entry and entry.policy_overrides:
            return Policy(**{**asdict(base), **entry.policy_overrides})
        return base

    def allowed(self, path: str, action: str) -> bool:
        pol = self.policy_for(path)
        return _is_action_allowed(pol, action)

    # ---- Enforcement ---- #
    def ensure_allowed(
        self,
        path: str,
        action: str,
        *,
        prompter: Optional[Prompter] = None,
        suggested_level: Optional[TrustLevel] = None,
    ) -> bool:
        pol = self.policy_for(path)
        if _is_action_allowed(pol, action):
            if _needs_prompt(pol, action):
                prompt = prompter or default_prompter
                cur_lvl = self.get_level(path)
                sugg = suggested_level or (
                    TrustLevel.TRUSTED if action in {"execute", "network"} else TrustLevel.LOW
                )
                allow_now, new_level, remember = prompt(
                    str(Path(path).resolve()), action, cur_lvl, sugg
                )
                if allow_now:
                    if new_level is not None:
                        self.set_level(str(Path(path).parent), new_level, persist=remember)
                    return True
                return False
            return True

        # Not allowed by policy — prompt for escalation
        prompt = prompter or default_prompter
        cur_lvl = self.get_level(path)
        sugg = suggested_level or (
            TrustLevel.TRUSTED if action in {"execute", "network"} else TrustLevel.LOW
        )
        allow_now, new_level, remember = prompt(str(Path(path).resolve()), action, cur_lvl, sugg)
        if allow_now:
            if new_level is not None:
                self.set_level(str(Path(path).parent), new_level, persist=remember)
            return True
        return False

    # ---- Helpers ---- #
    def _matched_entry(self, path: str) -> Optional[TrustEntry]:
        p = str(Path(path).resolve())
        best = None
        best_len = -1
        for epath, entry in self.entries.items():
            if p == epath or p.startswith(epath.rstrip("/") + "/"):
                if len(epath) > best_len:
                    best = entry
                    best_len = len(epath)
        return best

    def _lookup_session_level(self, p: Path) -> Optional[TrustLevel]:
        rp = str(p)
        best = None
        best_len = -1
        for epath, lvl in self.session_levels.items():
            if rp == epath or rp.startswith(epath.rstrip("/") + "/"):
                if len(epath) > best_len:
                    best = lvl
                    best_len = len(epath)
        return best


def _is_action_allowed(pol: Policy, action: str) -> bool:
    if action == "read":
        return pol.allow_read
    if action == "write":
        return pol.allow_write
    if action == "execute":
        return pol.allow_execute
    if action == "delete":
        return pol.allow_delete
    if action == "network":
        return pol.allow_network
    return False


def _needs_prompt(pol: Policy, action: str) -> bool:
    if action == "write":
        return pol.prompt_on_write
    if action == "execute":
        return pol.prompt_on_execute
    if action == "network":
        return pol.prompt_on_network
    return False


# ---- Interactive prompt ---- #


def default_prompter(
    path: str, action: str, current: TrustLevel, suggested: TrustLevel
) -> Tuple[bool, Optional[TrustLevel], bool]:
    """CLI-based prompt. Returns (allow_now, new_level, remember).

    If input() is not available (non-interactive), deny by default.
    """
    try:
        sys.stdout.write(
            (
                f"Security prompt: {action} on {path}\n"
                f"Current trust: {current.name}. Suggested: {suggested.name}.\n"
                "Options: [a]llow once, [l]ow, [t]rusted, [o]wner, [d]eny. Persist? y/N\n> "
            )
        )
        sys.stdout.flush()
        ans = input().strip().lower()
    except Exception:
        return (False, None, False)

    allow_once = ans.startswith("a")
    if allow_once:
        return (True, None, False)

    new_level: Optional[TrustLevel] = None
    if ans.startswith("l"):
        new_level = TrustLevel.LOW
    elif ans.startswith("t"):
        new_level = TrustLevel.TRUSTED
    elif ans.startswith("o"):
        new_level = TrustLevel.OWNER
    elif ans.startswith("d") or ans == "":
        return (False, None, False)

    # Persist?
    sys.stdout.write("Persist this trust? [y/N] ")
    sys.stdout.flush()
    try:
        persist_ans = input().strip().lower()
    except Exception:
        persist_ans = "n"
    remember = persist_ans.startswith("y")
    return (True, new_level, remember)


# ---- Convenience wrappers for file operations ---- #

_GLOBAL: Optional[TrustedFoldersManager] = None


def global_trust() -> TrustedFoldersManager:
    global _GLOBAL
    if _GLOBAL is None:
        _GLOBAL = TrustedFoldersManager()
    return _GLOBAL


def guarded_open(
    path: str, mode: str = "r", *args: Any, prompter: Optional[Prompter] = None, **kwargs: Any
):
    action = "read"
    if any(ch in mode for ch in ("w", "a", "+", "x")):
        action = "write"
    mgr = global_trust()
    if not mgr.ensure_allowed(path, action, prompter=prompter):
        raise PermissionError(f"Access denied by trust policy: {action} {path}")
    return open(path, mode, *args, **kwargs)


def guarded_read_text(path: str, *, encoding: str = "utf-8", errors: str = "replace") -> str:
    mgr = global_trust()
    if not mgr.ensure_allowed(path, "read"):
        raise PermissionError(f"Access denied by trust policy: read {path}")
    return Path(path).read_text(encoding=encoding, errors=errors)


def guarded_write_text(path: str, data: str, *, encoding: str = "utf-8") -> None:
    mgr = global_trust()
    if not mgr.ensure_allowed(path, "write"):
        raise PermissionError(f"Access denied by trust policy: write {path}")
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(data, encoding=encoding)
