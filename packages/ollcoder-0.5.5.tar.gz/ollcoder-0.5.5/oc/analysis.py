from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import Any, Dict


def analyze_python(src: str) -> Dict[str, Any]:
    out: Dict[str, Any] = {"functions": [], "classes": [], "imports": []}
    try:
        tree = ast.parse(src)
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                out["functions"].append({"name": node.name, "lineno": node.lineno})
            elif isinstance(node, ast.AsyncFunctionDef):
                out["functions"].append({"name": node.name, "lineno": node.lineno, "async": True})
            elif isinstance(node, ast.ClassDef):
                out["classes"].append({"name": node.name, "lineno": node.lineno})
            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                try:
                    mod = node.module if isinstance(node, ast.ImportFrom) else None
                    names = [a.name for a in node.names]
                    out["imports"].append({"module": mod, "names": names, "lineno": node.lineno})
                except Exception:
                    pass
    except Exception as e:
        out["error"] = str(e)
    return out


JS_FUNC_RE = re.compile(
    r"\bfunction\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*\(|\b([A-Za-z_$][A-Za-z0-9_$]*)\s*=\s*\([^)]*\)\s*=>"
)
JS_CLASS_RE = re.compile(r"\bclass\s+([A-Za-z_$][A-Za-z0-9_$]*)\b")
GO_FUNC_RE = re.compile(r"^\s*func\s+(?:\([^)]*\)\s*)?([A-Za-z_][A-Za-z0-9_]*)\(", re.M)


def analyze_text(path: str, src: str) -> Dict[str, Any]:
    p = Path(path)
    if p.suffix == ".py":
        return {"language": "python", **analyze_python(src)}
    if p.suffix in {".ts", ".tsx", ".js", ".mjs", ".cjs"}:
        funcs = [m.group(1) or m.group(2) for m in JS_FUNC_RE.finditer(src)]
        classes = [m.group(1) for m in JS_CLASS_RE.finditer(src)]
        return {"language": "js/ts", "functions": funcs, "classes": classes}
    if p.suffix == ".go":
        funcs = [m.group(1) for m in GO_FUNC_RE.finditer(src)]
        return {"language": "go", "functions": funcs}
    return {"language": p.suffix or "text"}
