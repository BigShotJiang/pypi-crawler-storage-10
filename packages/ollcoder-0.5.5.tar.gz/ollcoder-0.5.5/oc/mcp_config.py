from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

try:  # Python 3.11+
    import tomllib  # type: ignore[attr-defined]
except Exception:  # pragma: no cover
    tomllib = None  # type: ignore


@dataclass(frozen=True)
class MCPServer:
    name: str
    command: List[str]
    cwd: Optional[str] = None
    env: Optional[Dict[str, str]] = None
    transport: str = "stdio"  # stdio only for now


def _read_pyproject() -> Dict[str, Any]:
    try:
        proj = Path.cwd() / "pyproject.toml"
        if proj.is_file() and tomllib is not None:
            return tomllib.loads(proj.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return {}


def load_mcp_servers() -> Dict[str, MCPServer]:
    """Load MCP server definitions from [tool.ollcoder.mcp.servers] in pyproject.toml.

    Example:
      [tool.ollcoder.mcp.servers.dev]
      command = ["python", "-m", "my_mcp_server"]
      cwd = "."
      transport = "stdio"
    """
    data = _read_pyproject()
    tool = (data.get("tool") or {}).get("ollcoder") or {}
    mcp = tool.get("mcp", {}) if isinstance(tool, dict) else {}
    servers = (mcp.get("servers") or {}) if isinstance(mcp, dict) else {}
    out: Dict[str, MCPServer] = {}
    if not isinstance(servers, dict):
        return out
    for name, cfg in servers.items():
        if not isinstance(cfg, dict):
            continue
        cmd = cfg.get("command") or []
        if isinstance(cmd, str):
            command = [cmd]
        else:
            command = [str(x) for x in (cmd if isinstance(cmd, list) else [])]
        if not command:
            continue
        cwd = cfg.get("cwd")
        env = cfg.get("env") if isinstance(cfg.get("env"), dict) else None
        transport = str(cfg.get("transport") or "stdio")
        out[str(name)] = MCPServer(
            name=str(name), command=command, cwd=cwd, env=env, transport=transport
        )
    return out
