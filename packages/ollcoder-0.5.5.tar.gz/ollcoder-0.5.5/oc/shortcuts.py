from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from .commands import CommandNotFound, CommandRegistry

DEFAULT_CONFIG_PATHS = [
    Path.home() / ".config" / "ollcoder" / "keybindings.json",
    Path.home() / ".ollcoder" / "keybindings.json",
]


@dataclass(frozen=True)
class KeyBindingConfig:
    keys: List[str]  # e.g. ["c-k", "c-s"] or ["c-s"]
    command: str  # command name in registry
    args: Dict[str, Any]
    description: str = ""


DEFAULT_BINDINGS: List[KeyBindingConfig] = [
    KeyBindingConfig(["c-s"], "save_file", {}, "Save file"),
    KeyBindingConfig(["c-o"], "open_file", {}, "Open file"),
    KeyBindingConfig(["c-b"], "build_context", {}, "Build context"),
    KeyBindingConfig(["c-f"], "find", {}, "Find in buffer"),
    KeyBindingConfig(["f3"], "find_next", {}, "Find next"),
    KeyBindingConfig(["s-f3"], "find_prev", {}, "Find previous"),
    KeyBindingConfig(["c-l"], "clear_screen", {}, "Clear screen"),
    KeyBindingConfig(["c-j"], "submit_input", {}, "Submit input"),
    KeyBindingConfig(["f5"], "run_tests", {}, "Run tests"),
    KeyBindingConfig(["s-f5"], "debug_tests", {}, "Debug tests"),
    KeyBindingConfig(["f6"], "rebuild_index", {}, "Rebuild index"),
    KeyBindingConfig(["f7"], "next_issue", {}, "Next issue"),
    KeyBindingConfig(["s-f7"], "prev_issue", {}, "Previous issue"),
    KeyBindingConfig(["f2"], "rename_symbol", {}, "Rename symbol"),
    KeyBindingConfig(["f12"], "go_to_definition", {}, "Go to definition"),
    KeyBindingConfig(["s-f12"], "find_references", {}, "Find references"),
    KeyBindingConfig(["m-left"], "prev_file", {}, "Previous file"),
    KeyBindingConfig(["m-right"], "next_file", {}, "Next file"),
    KeyBindingConfig(["m-up"], "prev_section", {}, "Previous section"),
    KeyBindingConfig(["m-down"], "next_section", {}, "Next section"),
    KeyBindingConfig(["c-p"], "command_palette", {}, "Command palette"),
    KeyBindingConfig(["f9"], "repeat_last_command", {}, "Repeat last command"),
    KeyBindingConfig(["c-t"], "toggle_sidebar", {}, "Toggle sidebar"),
    KeyBindingConfig(["c-k", "c-c"], "copy_selection", {}, "Copy selection"),
    KeyBindingConfig(["c-k", "c-v"], "paste_clipboard", {}, "Paste clipboard"),
]


def _parse_sequence(seq: Iterable[str]) -> Tuple[Tuple[str, ...], ...]:
    # Support 'm-x' as ('escape','x'); 'c-k' as is; 's-f3' as is.
    parts: List[Tuple[str, ...]] = []
    for token in seq:
        token = token.strip()
        if token.startswith("m-"):
            parts.append(("escape", token[2:]))
        else:
            parts.append((token,))
    return tuple(parts)


def _as_list_or_split(keys: Any) -> List[str]:
    if isinstance(keys, list):
        return [str(k) for k in keys]
    s = str(keys)
    return [t for t in s.split() if t]


class KeyBindingManager:
    """Build prompt_toolkit KeyBindings from JSON or defaults and dispatch to commands."""

    def __init__(
        self, registry: Optional[CommandRegistry] = None, config_path: Optional[str] = None
    ) -> None:
        self.registry = registry or CommandRegistry.global_registry()
        self.config_path = Path(config_path) if config_path else self._first_existing_config_path()
        self.bindings: List[KeyBindingConfig] = []
        self.load()

    def _first_existing_config_path(self) -> Path:
        for p in DEFAULT_CONFIG_PATHS:
            if p.exists():
                return p
        return DEFAULT_CONFIG_PATHS[0]

    def load(self) -> None:
        try:
            if self.config_path and Path(self.config_path).is_file():
                data = json.loads(Path(self.config_path).read_text())
                self.bindings = [
                    KeyBindingConfig(
                        keys=_as_list_or_split(item.get("keys", [])),
                        command=item["command"],
                        args=item.get("args", {}),
                        description=item.get("description", ""),
                    )
                    for item in data
                ]
                return
        except Exception:
            # Fallback to defaults on error
            pass
        self.bindings = list(DEFAULT_BINDINGS)

    def save(self, path: Optional[str] = None) -> None:
        target = Path(path) if path else self.config_path
        target.parent.mkdir(parents=True, exist_ok=True)
        payload = [
            {"keys": b.keys, "command": b.command, "args": b.args, "description": b.description}
            for b in self.bindings
        ]
        target.write_text(json.dumps(payload, indent=2))

    def build_key_bindings(self):  # returns prompt_toolkit.key_binding.KeyBindings
        try:
            from prompt_toolkit.key_binding import KeyBindings
        except Exception as e:  # pragma: no cover
            raise RuntimeError("prompt_toolkit is required for keyboard shortcuts") from e

        kb = KeyBindings()
        reg = self.registry

        for b in self.bindings:
            sequences = _parse_sequence(b.keys)

            # Flatten sequences for decorator: KeyBindings.add takes varargs of key strings
            # but we already expanded meta-keys into ('escape','x') tuples. We add accordingly.
            def _factory(cmd: str, args: Dict[str, Any]):
                def handler(event):
                    try:
                        reg.execute(cmd, event=event, **(args or {}))
                    except CommandNotFound:
                        # Surface a minimal message without crashing the UI
                        print(f"[shortcuts] Command not found: {cmd}")
                    except Exception as ex:
                        print(f"[shortcuts] Error executing {cmd}: {ex}")

                return handler

            # prompt_toolkit requires one decorator per distinct sequence length; handle 1 or 2-part
            if all(len(t) == 1 for t in sequences):
                # Single-step or chained keys without meta-expansion
                kb.add(*[t[0] for t in sequences], eager=True)(_factory(b.command, b.args))
            else:
                # If any tuple has multiple keys (e.g., ('escape','left')), add nested binding
                # Build a list of variants where meta-keys are split into multiple steps
                flat: List[str] = []
                for t in sequences:
                    flat.extend(list(t))
                kb.add(*flat, eager=True)(_factory(b.command, b.args))
        return kb

    def list_bindings(self) -> List[Dict[str, Any]]:
        return [
            {"keys": " ".join(b.keys), "command": b.command, "description": b.description}
            for b in self.bindings
        ]
