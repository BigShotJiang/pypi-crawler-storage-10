from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Optional

try:
    from cryptography.hazmat.primitives import serialization  # type: ignore
    from cryptography.hazmat.primitives.asymmetric import ed25519  # type: ignore
    from cryptography.hazmat.primitives.serialization import (  # type: ignore
        Encoding,
        NoEncryption,
        PrivateFormat,
        PublicFormat,
    )
except Exception:  # pragma: no cover - optional
    ed25519 = None  # type: ignore
    serialization = None  # type: ignore
    Encoding = None  # type: ignore
    PrivateFormat = None  # type: ignore
    PublicFormat = None  # type: ignore
    NoEncryption = None  # type: ignore


@dataclass(frozen=True)
class ManifestEntry:
    path: str
    sha256: str


def build_manifest(root: str, patterns: Optional[Iterable[str]] = None) -> List[ManifestEntry]:
    pats = list(patterns or ["**/*"])
    entries: List[ManifestEntry] = []
    root_p = Path(root)
    for pat in pats:
        for p in root_p.glob(pat):
            if not p.is_file():
                continue
            h = hashlib.sha256()
            try:
                h.update(p.read_bytes())
            except Exception:
                continue
            entries.append(ManifestEntry(str(p.resolve()), h.hexdigest()))
    return sorted(entries, key=lambda e: e.path)


def generate_keypair(
    private_key_path: str, public_key_path: str, passphrase: Optional[str] = None
) -> None:
    if ed25519 is None or serialization is None:
        raise RuntimeError("cryptography is required; install with `pip install '.[crypto]'`")
    priv = ed25519.Ed25519PrivateKey.generate()
    if passphrase:
        enc = serialization.BestAvailableEncryption(passphrase.encode("utf-8"))  # type: ignore[attr-defined]
    else:
        enc = NoEncryption()
    priv_pem = priv.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, enc)
    pub = priv.public_key()
    pub_pem = pub.public_bytes(Encoding.PEM, PublicFormat.SubjectPublicKeyInfo)
    Path(private_key_path).write_bytes(priv_pem)
    Path(public_key_path).write_bytes(pub_pem)


def sign_manifest(
    entries: List[ManifestEntry], private_key_path: str, passphrase: Optional[str] = None
) -> bytes:
    if ed25519 is None or serialization is None:
        raise RuntimeError("cryptography is required; install with `pip install '.[crypto]'`")
    data = "\n".join([f"{e.sha256}  {e.path}" for e in entries]).encode()
    key_bytes = Path(private_key_path).read_bytes()
    priv = serialization.load_pem_private_key(
        key_bytes, password=passphrase.encode("utf-8") if passphrase else None
    )  # type: ignore[arg-type]
    assert isinstance(priv, ed25519.Ed25519PrivateKey)
    return priv.sign(data)


def verify_manifest(entries: List[ManifestEntry], signature: bytes, public_key_path: str) -> bool:
    if ed25519 is None or serialization is None:
        return False
    data = "\n".join([f"{e.sha256}  {e.path}" for e in entries]).encode()
    pub_bytes = Path(public_key_path).read_bytes()
    pub = serialization.load_pem_public_key(pub_bytes)
    try:
        assert isinstance(pub, ed25519.Ed25519PublicKey)
        pub.verify(signature, data)
        return True
    except Exception:
        return False


def save_signature(sig: bytes, path: str) -> None:
    Path(path).write_bytes(sig)


def read_signature(path: str) -> bytes:
    return Path(path).read_bytes()
