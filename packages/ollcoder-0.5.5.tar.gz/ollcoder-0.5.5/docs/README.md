# oc Toolkit Documentation

This document covers the oc package components added to Ollcoder: context compression, retrieval strategy, caching, adaptive builder, keyboard shortcuts, sandbox execution, trusted folders, and GitHub Actions.

## Components

- Context Compression (context_compression.py)
  - Levels: NONE, LITE, NO_COMMENTS, SIGNATURES, SUMMARY
  - Python: docstring + comment stripping, AST-based signature extraction
  - JS/TS/Go: regex-based signature extraction
  - Optional LLM summary with fallback to heuristic summary

- Multi-Tier Strategy (context_strategy.py)
  - Priorities: CRITICAL (50%), HIGH (25%), MEDIUM (15%), LOW (10%)
  - Sources: current/mentioned files, recent git changes, query-related files, dependencies/config, docs
  - Compression level auto-selected per tier and budget

- Intelligent Caching (context_cache.py)
  - 24h TTL, MD5-based keys, file state validation (size/mtime + MD5)

- Adaptive Builder (adaptive_builder.py)
  - Estimates capacity, builds tiered context, then recompresses/drops to fit budget

- Keyboard Shortcuts (shortcuts.py, commands.py, wiring.py)
  - 20+ default keybindings (JSON-configurable)
  - Global command registry; editor commands wired as safe no-ops in CLI

- Sandbox Execution (sandbox.py)
  - Docker/Podman, CPU/memory/PIDs limits, --network none, read-only root, mounts

- Trusted Folders (trusted_folders.py)
  - Trust levels: UNTRUSTED, LOW, TRUSTED, OWNER; per-folder policies; interactive prompts
  - Guarded I/O wrappers and integration in indexer/diff

- GitHub Actions (action.yml, Dockerfile, action/entrypoint.py)
  - PR review summaries using compression/signatures; issue auto-labeling
  - Workflow templates in .github/workflows

## CLI Usage

- Build context
  - python -m oc build-context --query "router bug" --json

- Trust management
  - python -m oc trust status .
  - python -m oc trust set . TRUSTED --no-persist

- Sandbox
  - python -m oc sandbox pull --image alpine:3.20
  - python -m oc sandbox run --image alpine:3.20 -- echo hello

- Shortcuts config
  - python -m oc shortcuts list
  - python -m oc shortcuts write-defaults --path ./keybindings.json

## Base TUI Chat

- Launch: `python -m oc chat --tui`
- Live Streaming: enabled by default.
- Toggle Streaming: press `Ctrl+Shift+Z` to switch On/Off.
- Status: the info panel shows an animated spinner while streaming and the current streaming mode.

## Programmatic API

```python
from oc import compress_content, CompressionLevel
text = open("app.py").read()
res = compress_content("app.py", text, CompressionLevel.SIGNATURES)
print(res.content)
```

## Keybindings JSON Format

```json
[
  {"keys": ["c-b"], "command": "build_context", "args": {"json_out": true}, "description": "Build context"}
]
```

## Trusted Folders Policies

- UNTRUSTED: read-only, no prompts
- LOW: read+write, prompt on write
- TRUSTED: full access, prompt on execute/network
- OWNER: full access, no prompts

Trust entries persist at ~/.config/ollcoder/trusted_folders.json.

## GitHub Action

- Use local action in workflows:
  - .github/workflows/pr-review.yml
  - .github/workflows/issue-triage.yml

Inputs:
- github_token: permissions to comment/label (default: GITHUB_TOKEN)
- review_level: none|lite|no_comments|signatures|summary (default: signatures)
- post_comment: whether to comment on PR (default: true)
- max_files: files per PR (default: 60)

## Requirements

- Python 3.11+
- Optional: prompt_toolkit (for interactive keybindings), google-generativeai (LLM summaries), docker/podman (sandbox)

## Testing

- Run locally: PYTHONPATH=. pytest -q oc_tests
- Coverage: PYTHONPATH=. pytest -q oc_tests --cov=oc --cov-report=term-missing
- CI: see .github/workflows/ci.yml

## Linting & Type Checking

- Ruff: ruff check .
- Mypy: PYTHONPATH=. mypy oc
