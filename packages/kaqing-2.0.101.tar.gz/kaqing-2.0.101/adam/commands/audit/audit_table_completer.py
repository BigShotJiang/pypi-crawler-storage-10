from adam.sql.term_completer import TermCompleter
from adam.utils_athena import audit_table_names

class AuditTableNameCompleter(TermCompleter):
    def __init__(self, ignore_case: bool = True):
        super().__init__(audit_table_names(), ignore_case=ignore_case)

    def __repr__(self) -> str:
        return "AuditTableCompleter()"