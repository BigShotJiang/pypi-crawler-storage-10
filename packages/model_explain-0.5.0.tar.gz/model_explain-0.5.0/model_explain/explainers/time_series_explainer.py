# model_explain/explainers/time_series_explainer.py

"""
Explainer for time-series and sequential deep learning models such as RNN, LSTM, GRU, and 1-D CNN. Provides per-timestep
feature attributions using SHAP or (optionally) LIME-based methods.

This module integrates with the model_explain unified API and generates both local (per-instance) and temporal
explanations.

Author:
    Vaibhav Kulshrestha

Date:
    2025-10-30
"""

# Import necessary libraries
from __future__ import annotations

import matplotlib.pyplot as plt
import numpy as np
import shap


class TimeSeriesExplainer:
    """
    Explainer for time-series models (RNN, LSTM, GRU, 1-D CNN).

    Supports SHAP-based explanations for Keras and PyTorch models.
    Produces temporal feature-importance visualizations such as heatmaps and feature importance over time.

    Attributes:
        model (object): The trained deep learning model.
        background_data (np.ndarray): Background data for SHAP value computation.
                                      Shape: (n_samples, timesteps, n_features).
        mode (str): Explanation method ('shap'). Currently, only 'shap' is supported.
        framework (str): Framework name ('keras', 'pytorch'). Automatically detected if None.
    """

    def __init__(self, model, background_data=None, mode="shap", framework=None):
        """
        Initialize the TimeSeriesExplainer.

        :param model: The trained deep learning model.
        :type model: object
        :param background_data: Background data for SHAP value computation. Shape: (n_samples, timesteps, n_features).
                                If None, a random sample from the training data should be provided.
        :type background_data: np.ndarray, optional
        :param mode: Explanation method ('shap'). Currently, only 'shap' is supported.
        :type mode: str, default="shap"
        :param framework: Framework name ('keras', 'pytorch'). Automatically detected if None.
        :type framework: str, optional
        """
        self.model = model
        self.background_data = background_data
        self.mode = mode.lower()
        self.framework = framework or self._detect_framework(model)

        if self.mode != "shap":
            raise NotImplementedError(
                "Currently only 'shap' mode is supported for time-series."
            )

        self.explainer = self._init_shap_explainer()

    # ------------------------------------------------------------------
    # Internal Utilities
    # ------------------------------------------------------------------
    @staticmethod
    def _detect_framework(model):
        """
        Detect model framework (Keras or PyTorch).

        :param model: The trained deep learning model.
        :type model: object
        :return: Framework name ('keras', 'pytorch', or 'unknown').
        :rtype: str
        """
        try:
            import torch
            import tensorflow as tf
        except ImportError:
            return "unknown"

        if isinstance(model, torch.nn.Module):
            return "pytorch"
        if isinstance(model, tf.keras.Model):
            return "keras"
        return "unknown"

    def _init_shap_explainer(self):
        """
        Initialize SHAP explainer depending on framework.
        """
        if self.framework == "keras":
            return shap.DeepExplainer(self.model, self.background_data)
        if self.framework == "pytorch":
            return shap.GradientExplainer(self.model, self.background_data)
        raise ValueError("Unsupported model framework for SHAP explainer.")

    @staticmethod
    def plot_heatmap(
        shap_values,
        feature_names=None,
        title="Temporal Feature Contributions",
        cmap="RdBu_r",
    ):
        """
        Plot a heatmap of SHAP values across time and features.

        :param shap_values: SHAP value matrix of shape (timesteps, n_features).
        :type shap_values: np.ndarray
        :param feature_names: Names of the features.
        :type feature_names: list of str, optional
        :param title: Title for the plot.
        :type title: str, default="Temporal Feature Contributions"
        :param cmap: Matplotlib colormap for visualization.
        :type cmap: str, default="RdBu_r"
        """
        plt.figure(figsize=(12, 6))
        plt.imshow(shap_values.T, aspect="auto", cmap=cmap)
        plt.colorbar(label="Contribution")
        plt.xlabel("Time Step")
        plt.ylabel("Feature")

        if feature_names is not None:
            plt.yticks(np.arange(len(feature_names)), feature_names)

        plt.title(title)
        plt.tight_layout()
        plt.show()

    @staticmethod
    def plot_feature_importance_over_time(
        shap_values,
        title="Average Feature Importance Over Time",
    ):
        """
        Plot line chart showing average feature importance over time.

        :param shap_values: SHAP value matrix of shape (timesteps, n_features).
        :type shap_values: np.ndarray
        :param title: Title for the plot.
        :type title: str, default="Average Feature Importance Over Time"
        """
        mean_importance = np.abs(shap_values).mean(axis=-1)
        plt.figure(figsize=(10, 5))
        plt.plot(mean_importance, label="Mean |SHAP| per timestep")
        plt.xlabel("Time Step")
        plt.ylabel("Mean |SHAP| Value")
        plt.title(title)
        plt.legend()
        plt.tight_layout()
        plt.show()

    # ------------------------------------------------------------------
    # Public Methods
    # ------------------------------------------------------------------
    def explain(self, instance):
        """
        Generate SHAP explanations for a single time-series instance.

        :param instance: Input sequence, shape (1, timesteps, n_features).
        :type instance: np.ndarray
        :returns: SHAP values array of shape (timesteps, n_features).
        :rtype: np.ndarray
        """
        if instance.ndim == 2:
            instance = np.expand_dims(instance, axis=0)

        shap_values = self.explainer.shap_values(instance)
        shap_values = np.array(shap_values)

        # Handle models with multiple outputs (return first output by default)
        if shap_values.ndim == 4:
            shap_values = shap_values[0]

        return shap_values[0]

    # ------------------------------------------------------------------
    # Convenience Utilities
    # ------------------------------------------------------------------
    @staticmethod
    def summarize_importance(shap_values):
        """
        Summarize total feature importance across time.

        :param shap_values: SHAP value matrix of shape (timesteps, n_features).
        :type shap_values: np.ndarray
        :returns: Mean absolute SHAP value per feature.
        :rtype: np.ndarray
        """
        return np.abs(shap_values).mean(axis=0)
