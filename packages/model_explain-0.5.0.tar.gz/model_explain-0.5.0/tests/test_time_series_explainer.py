# tests/test_time_series_explainer.py

"""
Unit tests for the TimeSeriesExplainer in the model_explain package.

Features tested:
- Framework detection (Keras, PyTorch)
- SHAP explainer initialization
- Explanation output shape and validity
- Summary statistics computation
- Visualization methods (heatmap, feature importance over time)

Author:
    Vaibhav Kulshrestha

Date:
    2025-10-30
"""

import matplotlib

matplotlib.use("Agg")  # Non-GUI backend
import matplotlib.pyplot as plt

plt.ioff()  # Disable interactive mode

import numpy as np
import pytest
from unittest.mock import MagicMock, patch

from model_explain.explainers.time_series_explainer import TimeSeriesExplainer


# ----------------------------------------------------------------------
# Fixtures
# ----------------------------------------------------------------------
@pytest.fixture(scope="module")
def dummy_data():
    """Generate synthetic time-series data for tests."""
    X = np.random.randn(10, 8, 3)  # (samples, timesteps, features)
    y = np.random.randn(10, 1)
    return X, y


@pytest.fixture(scope="module")
def dummy_keras_model(dummy_data):
    """Create a simple Keras LSTM model for testing."""
    try:
        import tensorflow as tf
    except ImportError:
        pytest.skip("TensorFlow not installed; skipping Keras model tests.")

    X, y = dummy_data
    model = tf.keras.Sequential(
        [
            tf.keras.layers.LSTM(4, input_shape=(X.shape[1], X.shape[2])),
            tf.keras.layers.Dense(1, activation="linear"),
        ]
    )
    model.compile(optimizer="adam", loss="mse")
    model.fit(X, y, epochs=1, verbose=0)
    return model


# ----------------------------------------------------------------------
# Tests
# ----------------------------------------------------------------------
def test_framework_detection_with_keras(dummy_keras_model):
    """Test that framework detection correctly identifies Keras."""
    explainer = TimeSeriesExplainer(
        dummy_keras_model, background_data=np.zeros((2, 8, 3))
    )
    assert explainer.framework == "keras"


def test_invalid_mode_raises_error(dummy_keras_model):
    """Ensure invalid mode raises NotImplementedError."""
    with pytest.raises(NotImplementedError):
        TimeSeriesExplainer(dummy_keras_model, mode="lime")


@patch("model_explain.explainers.time_series_explainer.shap.DeepExplainer")
def test_explainer_initialization(mock_shap, dummy_keras_model):
    """Verify SHAP explainer is initialized for Keras models."""
    explainer = TimeSeriesExplainer(
        dummy_keras_model, background_data=np.zeros((2, 8, 3))
    )
    mock_shap.assert_called_once()


@patch("model_explain.explainers.time_series_explainer.shap.DeepExplainer")
def test_explain_output_shape(mock_shap, dummy_keras_model, dummy_data):
    """Check explain() returns correct shape (timesteps, features)."""
    X, _ = dummy_data

    # Mock SHAP values
    mock_explainer = MagicMock()
    mock_explainer.shap_values.return_value = [
        np.random.randn(1, X.shape[1], X.shape[2])
    ]
    mock_shap.return_value = mock_explainer

    explainer = TimeSeriesExplainer(dummy_keras_model, background_data=X[:2])
    shap_vals = explainer.explain(X[0])

    assert shap_vals.shape == (X.shape[1], X.shape[2])
    assert np.isfinite(shap_vals).all()


def test_summarize_importance(dummy_data):
    """Test summarize_importance() computes mean absolute SHAP per feature."""
    X, _ = dummy_data
    shap_vals = np.random.randn(X.shape[1], X.shape[2])
    summary = TimeSeriesExplainer.summarize_importance(shap_vals)

    assert summary.shape == (X.shape[2],)
    assert (summary >= 0).all()


def test_plot_heatmap_runs_without_error(dummy_keras_model, dummy_data):
    """Ensure plot_heatmap() executes without exceptions."""
    X, _ = dummy_data
    shap_vals = np.random.randn(X.shape[1], X.shape[2])

    explainer = TimeSeriesExplainer(dummy_keras_model, background_data=X[:2])

    # Patch plt.show() to avoid blocking test
    with patch("matplotlib.pyplot.show"):
        explainer.plot_heatmap(shap_vals, feature_names=["f1", "f2", "f3"])


def test_plot_feature_importance_runs_without_error(dummy_keras_model, dummy_data):
    """Ensure plot_feature_importance_over_time() executes cleanly."""
    X, _ = dummy_data
    shap_vals = np.random.randn(X.shape[1], X.shape[2])

    explainer = TimeSeriesExplainer(dummy_keras_model, background_data=X[:2])

    with patch("matplotlib.pyplot.show"):
        explainer.plot_feature_importance_over_time(shap_vals)


def test_explain_with_2d_input_expands_dimension(dummy_keras_model, dummy_data):
    """Ensure explain() can handle (timesteps, features) input."""
    X, _ = dummy_data

    with patch.object(TimeSeriesExplainer, "_init_shap_explainer") as mock_init:
        mock_explainer = MagicMock()
        mock_explainer.shap_values.return_value = [
            np.random.randn(1, X.shape[1], X.shape[2])
        ]
        mock_init.return_value = mock_explainer

        explainer = TimeSeriesExplainer(dummy_keras_model, background_data=X[:2])
        shap_vals = explainer.explain(X[0])

        assert shap_vals.shape == (X.shape[1], X.shape[2])


def test_detect_framework_returns_unknown_for_invalid_object():
    """Ensure _detect_framework() returns 'unknown' for non-model objects."""
    dummy_object = object()
    result = TimeSeriesExplainer._detect_framework(dummy_object)
    assert result == "unknown"


def main():
    """Run the tests."""
    pytest.main([__file__])


if __name__ == "__main__":
    main()
