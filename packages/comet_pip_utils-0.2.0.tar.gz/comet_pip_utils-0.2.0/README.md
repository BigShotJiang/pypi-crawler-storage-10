# Comet Pip Utils

A Python package providing utility functions for pip package management and environment analysis.

## Installation

```bash
pip install comet-pip-utils
```

## Features

- Get installed pip packages in the current environment
- Parse and analyze frozen requirements
- Check if packages are installed and satisfy version constraints
- Install packages programmatically with custom flags
- Unload packages from memory
- Extract package names from requirement strings

## Usage

### Get Installed Packages

```python
from comet_pip_utils import get_pip_packages

# Get all installed packages
packages = get_pip_packages()
print(packages)
# Output: ['numpy==1.21.0', 'pandas==1.3.0', ...]
```

### Parse Frozen Requirements

```python
from comet_pip_utils import parse_frozen_requirements

frozen_reqs = ['numpy==1.21.0', 'pandas==1.3.0']
installed = parse_frozen_requirements(frozen_reqs)
print(installed)
# Output: {'numpy': Version('1.21.0'), 'pandas': Version('1.3.0')}
```

### Check Package Installation

```python
from comet_pip_utils import is_pip_installed_package

# Check if a package is installed with version constraint
packages = get_pip_packages()
is_installed = is_pip_installed_package('numpy>=1.20.0', packages)
print(is_installed)  # True or False
```

### Install Packages Programmatically

```python
from comet_pip_utils import pip_install_packages

# Install a single package
errors = pip_install_packages('requests')

# Install multiple packages
errors = pip_install_packages(['requests', 'numpy'])

# Install with flags
errors = pip_install_packages('requests', flags=['--user', '--no-deps'])
```

### Unload Packages

```python
from comet_pip_utils import unload_package

# Unload a package from memory
unload_package('numpy==1.21.0')
```

### Extract Package Names

```python
from comet_pip_utils import extract_package_name

# Extract package name from requirement string
package_name = extract_package_name('numpy>=1.20.0')
print(package_name)  # 'numpy'
```

## API Reference

### Functions

- `get_pip_packages()` - Get list of installed packages
- `parse_frozen_requirements(frozen_reqs)` - Parse frozen requirements into version dict
- `is_pip_installed_package(package_name, packages)` - Check if package satisfies requirement
- `pip_install_packages(packages, flags=None)` - Install packages with optional flags
- `unload_package(qualified_name)` - Unload package from memory
- `extract_package_name(package_name)` - Extract package name from requirement string

## Requirements

- Python 3.7+
- packaging>=21.0

## License

Proprietary - Copyright (C) 2015-2023 Comet ML INC

This file can not be copied and/or distributed without the express permission of Comet ML Inc. 