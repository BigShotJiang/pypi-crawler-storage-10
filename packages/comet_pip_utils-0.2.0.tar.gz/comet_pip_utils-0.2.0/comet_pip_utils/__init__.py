"""
Comet Pip Utils - Utility functions for pip package management.

This package provides functions for managing pip packages, checking installations,
and analyzing package requirements.
"""

from ._version import __version__
from .pip_utils import (
    get_pip_packages,
    parse_frozen_requirements,
    is_pip_installed_package,
    pip_install_packages,
    unload_package,
    extract_package_name,
    process_args,
)

__author__ = "Comet ML Inc"
__email__ = "support@comet.com"

__all__ = [
    "get_pip_packages",
    "parse_frozen_requirements",
    "is_pip_installed_package",
    "pip_install_packages",
    "unload_package",
    "extract_package_name",
    "process_args",
]
