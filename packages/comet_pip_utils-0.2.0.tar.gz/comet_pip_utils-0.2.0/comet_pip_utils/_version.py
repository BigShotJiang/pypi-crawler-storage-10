"""
Version information for comet-pip-utils.
"""

__version__ = "0.2.0"
