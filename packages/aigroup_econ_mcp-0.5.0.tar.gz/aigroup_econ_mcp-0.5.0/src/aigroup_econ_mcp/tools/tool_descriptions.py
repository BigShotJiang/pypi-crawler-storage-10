"""
工具描述模块
统一管理所有MCP工具的描述信息，便于维护和复用
"""

from typing import Dict, Any, List
from pydantic import Field


class ToolDescription:
    """工具描述类"""
    
    def __init__(self, name: str, description: str, field_descriptions: Dict[str, str] = None):
        self.name = name
        self.description = description
        self.field_descriptions = field_descriptions or {}
    
    def get_field_description(self, field_name: str, default: str = "") -> str:
        """获取字段描述"""
        return self.field_descriptions.get(field_name, default)


# ============================================================================
# 基础统计工具描述 (5个)
# ============================================================================

DESCRIPTIVE_STATISTICS = ToolDescription(
    name="descriptive_statistics",
    description="计算描述性统计量\n\n支持三种输入方式（按优先级）：\n1. file_path: 文件路径 (如 \"data.csv\")\n2. file_content: 文件内容字符串\n3. data: 直接传入数据字典",
    field_descriptions={
        "file_path": "CSV/JSON文件路径",
        "file_content": "CSV/JSON文件内容",
        "file_format": "文件格式(csv/json/auto)",
        "data": "数据字典(直接数据输入)"
    }
)

OLS_REGRESSION = ToolDescription(
    name="ols_regression",
    description="OLS回归分析\n\n支持文件输入或直接数据输入。文件格式示例：\nCSV: 最后一列为因变量，其余列为自变量",
    field_descriptions={
        "file_path": "CSV/JSON文件路径",
        "file_content": "CSV/JSON文件内容",
        "file_format": "文件格式",
        "y_data": "因变量(直接输入)",
        "x_data": "自变量(直接输入)",
        "feature_names": "特征名称"
    }
)

HYPOTHESIS_TESTING = ToolDescription(
    name="hypothesis_testing",
    description="假设检验 - 支持文件或直接数据输入",
    field_descriptions={
        "file_path": "文件路径",
        "file_content": "文件内容",
        "file_format": "文件格式",
        "data": "第一组数据",
        "data2": "第二组数据",
        "test_type": "检验类型(t_test/adf)"
    }
)

TIME_SERIES_ANALYSIS = ToolDescription(
    name="time_series_analysis",
    description="时间序列分析 - 支持文件或直接数据输入",
    field_descriptions={
        "file_path": "文件路径",
        "file_content": "文件内容",
        "file_format": "文件格式",
        "data": "时间序列数据"
    }
)

CORRELATION_ANALYSIS = ToolDescription(
    name="correlation_analysis",
    description="相关性分析 - 支持文件或直接数据输入",
    field_descriptions={
        "file_path": "文件路径",
        "file_content": "文件内容",
        "file_format": "文件格式",
        "data": "多变量数据",
        "method": "相关系数类型"
    }
)


# ============================================================================
# 面板数据工具描述 (4个)
# ============================================================================

PANEL_FIXED_EFFECTS = ToolDescription(
    name="panel_fixed_effects",
    description="固定效应模型 - 支持文件输入",
    field_descriptions={
        "file_path": "CSV文件路径。CSV格式要求：必须包含实体ID列(列名含entity_id/id/entity/firm/company/country/region之一)和时间列(列名含time_period/time/date/year/month/period/quarter之一)",
        "file_content": "文件内容",
        "file_format": "文件格式",
        "y_data": "因变量数据",
        "x_data": "自变量数据",
        "entity_ids": "实体ID列表",
        "time_periods": "时间周期列表",
        "feature_names": "特征名称",
        "entity_effects": "是否包含实体效应",
        "time_effects": "是否包含时间效应"
    }
)

PANEL_RANDOM_EFFECTS = ToolDescription(
    name="panel_random_effects",
    description="随机效应模型 - 支持文件输入",
    field_descriptions={
        "file_path": "CSV文件路径。CSV格式要求：必须包含实体ID列(列名含entity_id/id/entity/firm/company/country/region之一)和时间列(列名含time_period/time/date/year/month/period/quarter之一)",
        "file_content": "文件内容",
        "file_format": "文件格式",
        "y_data": "因变量数据",
        "x_data": "自变量数据",
        "entity_ids": "实体ID列表",
        "time_periods": "时间周期列表",
        "feature_names": "特征名称",
        "entity_effects": "是否包含实体效应",
        "time_effects": "是否包含时间效应"
    }
)

PANEL_HAUSMAN_TEST = ToolDescription(
    name="panel_hausman_test",
    description="Hausman检验 - 支持文件输入",
    field_descriptions={
        "file_path": "CSV文件路径。CSV格式要求：必须包含实体ID列(列名含entity_id/id/entity/firm/company/country/region之一)和时间列(列名含time_period/time/date/year/month/period/quarter之一)",
        "file_content": "文件内容",
        "file_format": "文件格式",
        "y_data": "因变量数据",
        "x_data": "自变量数据",
        "entity_ids": "实体ID列表",
        "time_periods": "时间周期列表",
        "feature_names": "特征名称"
    }
)

PANEL_UNIT_ROOT_TEST = ToolDescription(
    name="panel_unit_root_test",
    description="面板单位根检验 - 支持文件输入",
    field_descriptions={
        "file_path": "CSV文件路径。CSV格式要求：必须包含实体ID列(列名含entity_id/id/entity/firm/company/country/region之一)和时间列(列名含time_period/time/date/year/month/period/quarter之一)。数据量要求：至少3个实体，每个实体至少5个时间点",
        "file_content": "文件内容",
        "file_format": "文件格式",
        "data": "时间序列数据",
        "y_data": "因变量数据",
        "x_data": "自变量数据",
        "entity_ids": "实体ID列表",
        "time_periods": "时间周期列表",
        "feature_names": "特征名称",
        "test_type": "检验类型"
    }
)


# ============================================================================
# 高级时间序列工具描述 (5个)
# ============================================================================

VAR_MODEL_ANALYSIS = ToolDescription(
    name="var_model_analysis",
    description="VAR模型分析 - 支持文件输入",
    field_descriptions={
        "file_path": "文件路径",
        "file_content": "文件内容",
        "file_format": "文件格式",
        "data": "多变量时间序列数据",
        "max_lags": "最大滞后阶数",
        "ic": "信息准则类型"
    }
)

VECM_MODEL_ANALYSIS = ToolDescription(
    name="vecm_model_analysis",
    description="VECM模型分析 - 支持文件输入",
    field_descriptions={
        "file_path": "文件路径",
        "file_content": "文件内容",
        "file_format": "文件格式",
        "data": "多变量时间序列数据",
        "coint_rank": "协整秩",
        "deterministic": "确定性项类型",
        "max_lags": "最大滞后阶数"
    }
)

GARCH_MODEL_ANALYSIS = ToolDescription(
    name="garch_model_analysis",
    description="GARCH模型分析 - 支持文件输入",
    field_descriptions={
        "file_path": "文件路径",
        "file_content": "文件内容",
        "file_format": "文件格式",
        "data": "时间序列数据",
        "order": "GARCH模型阶数",
        "dist": "误差分布类型"
    }
)

STATE_SPACE_MODEL_ANALYSIS = ToolDescription(
    name="state_space_model_analysis",
    description="状态空间模型分析 - 支持文件输入",
    field_descriptions={
        "file_path": "文件路径",
        "file_content": "文件内容",
        "file_format": "文件格式",
        "data": "时间序列数据",
        "state_dim": "状态维度",
        "observation_dim": "观测维度",
        "trend": "是否包含趋势项",
        "seasonal": "是否包含季节项",
        "period": "季节周期"
    }
)

VARIANCE_DECOMPOSITION_ANALYSIS = ToolDescription(
    name="variance_decomposition_analysis",
    description="方差分解分析 - 支持文件输入",
    field_descriptions={
        "file_path": "文件路径",
        "file_content": "文件内容",
        "file_format": "文件格式",
        "data": "多变量时间序列数据",
        "periods": "分解期数",
        "max_lags": "最大滞后阶数"
    }
)


# ============================================================================
# 机器学习工具描述 (6个)
# ============================================================================

RANDOM_FOREST_REGRESSION_ANALYSIS = ToolDescription(
    name="random_forest_regression_analysis",
    description="随机森林回归 - 支持文件输入",
    field_descriptions={
        "file_path": "文件路径",
        "file_content": "文件内容",
        "file_format": "文件格式",
        "y_data": "因变量数据",
        "x_data": "自变量数据",
        "feature_names": "特征名称",
        "n_estimators": "树的数量",
        "max_depth": "最大深度"
    }
)

GRADIENT_BOOSTING_REGRESSION_ANALYSIS = ToolDescription(
    name="gradient_boosting_regression_analysis",
    description="梯度提升树回归 - 支持文件输入",
    field_descriptions={
        "file_path": "文件路径",
        "file_content": "文件内容",
        "file_format": "文件格式",
        "y_data": "因变量数据",
        "x_data": "自变量数据",
        "feature_names": "特征名称",
        "n_estimators": "树的数量",
        "learning_rate": "学习率",
        "max_depth": "最大深度"
    }
)

LASSO_REGRESSION_ANALYSIS = ToolDescription(
    name="lasso_regression_analysis",
    description="Lasso回归 - 支持文件输入",
    field_descriptions={
        "file_path": "文件路径",
        "file_content": "文件内容",
        "file_format": "文件格式",
        "y_data": "因变量数据",
        "x_data": "自变量数据",
        "feature_names": "特征名称",
        "alpha": "正则化参数"
    }
)

RIDGE_REGRESSION_ANALYSIS = ToolDescription(
    name="ridge_regression_analysis",
    description="Ridge回归 - 支持文件输入",
    field_descriptions={
        "file_path": "文件路径",
        "file_content": "文件内容",
        "file_format": "文件格式",
        "y_data": "因变量数据",
        "x_data": "自变量数据",
        "feature_names": "特征名称",
        "alpha": "正则化参数"
    }
)

CROSS_VALIDATION_ANALYSIS = ToolDescription(
    name="cross_validation_analysis",
    description="交叉验证 - 支持文件输入",
    field_descriptions={
        "file_path": "文件路径",
        "file_content": "文件内容",
        "file_format": "文件格式",
        "y_data": "因变量数据",
        "x_data": "自变量数据",
        "feature_names": "特征名称",
        "model_type": "模型类型",
        "cv_folds": "交叉验证折数",
        "scoring": "评分指标"
    }
)

FEATURE_IMPORTANCE_ANALYSIS_TOOL = ToolDescription(
    name="feature_importance_analysis_tool",
    description="特征重要性分析 - 支持文件输入",
    field_descriptions={
        "file_path": "文件路径",
        "file_content": "文件内容",
        "file_format": "文件格式",
        "y_data": "因变量数据",
        "x_data": "自变量数据",
        "feature_names": "特征名称",
        "method": "分析方法",
        "top_k": "显示前K个重要特征"
    }
)


# ============================================================================
# 工具描述映射
# ============================================================================

TOOL_DESCRIPTIONS: Dict[str, ToolDescription] = {
    # 基础统计工具
    "descriptive_statistics": DESCRIPTIVE_STATISTICS,
    "ols_regression": OLS_REGRESSION,
    "hypothesis_testing": HYPOTHESIS_TESTING,
    "time_series_analysis": TIME_SERIES_ANALYSIS,
    "correlation_analysis": CORRELATION_ANALYSIS,
    
    # 面板数据工具
    "panel_fixed_effects": PANEL_FIXED_EFFECTS,
    "panel_random_effects": PANEL_RANDOM_EFFECTS,
    "panel_hausman_test": PANEL_HAUSMAN_TEST,
    "panel_unit_root_test": PANEL_UNIT_ROOT_TEST,
    
    # 高级时间序列工具
    "var_model_analysis": VAR_MODEL_ANALYSIS,
    "vecm_model_analysis": VECM_MODEL_ANALYSIS,
    "garch_model_analysis": GARCH_MODEL_ANALYSIS,
    "state_space_model_analysis": STATE_SPACE_MODEL_ANALYSIS,
    "variance_decomposition_analysis": VARIANCE_DECOMPOSITION_ANALYSIS,
    
    # 机器学习工具
    "random_forest_regression_analysis": RANDOM_FOREST_REGRESSION_ANALYSIS,
    "gradient_boosting_regression_analysis": GRADIENT_BOOSTING_REGRESSION_ANALYSIS,
    "lasso_regression_analysis": LASSO_REGRESSION_ANALYSIS,
    "ridge_regression_analysis": RIDGE_REGRESSION_ANALYSIS,
    "cross_validation_analysis": CROSS_VALIDATION_ANALYSIS,
    "feature_importance_analysis_tool": FEATURE_IMPORTANCE_ANALYSIS_TOOL,
}


def get_tool_description(tool_name: str) -> ToolDescription:
    """获取工具描述"""
    if tool_name not in TOOL_DESCRIPTIONS:
        raise ValueError(f"未知的工具名称: {tool_name}")
    return TOOL_DESCRIPTIONS[tool_name]


def get_all_tool_names() -> List[str]:
    """获取所有工具名称"""
    return list(TOOL_DESCRIPTIONS.keys())


def get_field_description(tool_name: str, field_name: str, default: str = "") -> str:
    """获取指定工具的字段描述"""
    tool_desc = get_tool_description(tool_name)
    return tool_desc.get_field_description(field_name, default)


# 导出主要类和函数
__all__ = [
    "ToolDescription",
    "TOOL_DESCRIPTIONS",
    "get_tool_description",
    "get_all_tool_names",
    "get_field_description",
    
    # 基础统计工具
    "DESCRIPTIVE_STATISTICS",
    "OLS_REGRESSION",
    "HYPOTHESIS_TESTING",
    "TIME_SERIES_ANALYSIS",
    "CORRELATION_ANALYSIS",
    
    # 面板数据工具
    "PANEL_FIXED_EFFECTS",
    "PANEL_RANDOM_EFFECTS",
    "PANEL_HAUSMAN_TEST",
    "PANEL_UNIT_ROOT_TEST",
    
    # 高级时间序列工具
    "VAR_MODEL_ANALYSIS",
    "VECM_MODEL_ANALYSIS",
    "GARCH_MODEL_ANALYSIS",
    "STATE_SPACE_MODEL_ANALYSIS",
    "VARIANCE_DECOMPOSITION_ANALYSIS",
    
    # 机器学习工具
    "RANDOM_FOREST_REGRESSION_ANALYSIS",
    "GRADIENT_BOOSTING_REGRESSION_ANALYSIS",
    "LASSO_REGRESSION_ANALYSIS",
    "RIDGE_REGRESSION_ANALYSIS",
    "CROSS_VALIDATION_ANALYSIS",
    "FEATURE_IMPORTANCE_ANALYSIS_TOOL",
]