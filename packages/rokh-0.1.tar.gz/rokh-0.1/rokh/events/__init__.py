# -*- coding: utf-8 -*-
"""Initialize the events module."""
