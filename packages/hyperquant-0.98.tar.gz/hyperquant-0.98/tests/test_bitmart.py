import pybotters

from hyperquant.broker.lighter import Lighter
import asyncio
from logging import Logger
import time
from dataclasses import dataclass
from typing import Any, Awaitable, Literal
from hyperquant.logkit import get_logger
from hyperquant.broker.bitmart import Bitmart



async def test_update():
    async with pybotters.Client(apis='./apis.json') as client:
        async with Bitmart(client=client) as broker:
            # print(broker.store.detail.find()[0])
            # await broker.update('balances')
            # print(broker.store.balances.find())
            # await broker.update('ticker')
            # print(broker.store.ticker.find())

            await broker.update('history_orders')
            print(broker.store.orders.find())
            print(broker.store.orders.get({'order_id':3000237069605967}))

async def test_place():
    async with pybotters.Client(apis='./apis.json') as client:
        async with Bitmart(client=client) as broker:

            oid = await broker.place_order(
                symbol='ONDOUSDT',
                side='sell',
                category='limit',
                price=0.7,
                qty=0.2,
            )

            print(f"Placed order ID: {oid}")

            resp = await broker.cancel_order(
                symbol='ONDOUSDT',
                order_ids=[oid],
            )

            print(f"Cancel response: {resp}")

@dataclass
class OrderSyncResult:
    position: dict[str, Any]
    order: dict[str, Any]

async def order_sync_polling(
    broker: Bitmart,
    place_task: Awaitable,
    is_ioc: bool = True,
    cancel_retry: int = 3,
    logger: Logger | None = None,
) -> OrderSyncResult:
    try:
        oid = await place_task
    except Exception as e:
        if logger:
            logger.warning(f"Order placement failed: {e}")

    
    async def sync():
        await broker.update('history_orders')
        await broker.update('positions')
        order = broker.store.orders.get({'order_id': oid})
        if order:
            contract_id = order.get('contract_id')
            positions = broker.store.positions.find({'contract_id': contract_id})
            position = positions[0] if positions else {}
            return OrderSyncResult(position=position, order=order)
    
    if is_ioc:
        return await sync()
    else:
        for attempt in range(cancel_retry):
            await asyncio.sleep(1)
            await broker.update('history_orders')
            order = broker.store.orders.get({'order_id': oid})
            # 说明订单已经置入历史委托
            if order:
                return await sync()
            else:
                try:
                    await broker.cancel_order(
                        symbol=order.get('symbol'),
                        order_ids=[oid],
                    )
                except Exception as e:
                    if logger:
                        logger.warning(f"Order cancellation attempt {attempt + 1} failed: {e}")
       
    return OrderSyncResult(position={}, order={})


async def test_sub_book():
    async with pybotters.Client() as client:
        async with Bitmart(client=client) as broker:
            broker.store.book.limit = 1
            await broker.sub_orderbook(["TRXUSDT", 'XRPUSDT', 'DOTUSDT'])
            while True:
                # await broker.store.book.wait()
                # print(broker.store.book.find())
                asks = broker.store.book.find({"S": "a", 's': 'TRXUSDT'})
                bids = broker.store.book.find({"S": "b", 's': 'TRXUSDT'})
                # 订单薄format化输出
                print("Asks:")
                for ask in asks:
                    print(f"Price: {ask['p']}, Quantity: {ask['q']}")
                print("Bids:")
                for bid in bids:
                    print(f"Price: {bid['p']}, Quantity: {bid['q']}")
                print("-" * 30)
                await asyncio.sleep(1)


            # with broker.store.book.watch() as stream:
            #     async for change in stream:
            #         print(change)

async def test_auto_refresh():
    async with pybotters.Client(apis='./apis.json') as client:
        async with Bitmart(client=client, apis='./apis.json') as broker:
            await broker.auto_refresh(0, test=True)
            await asyncio.sleep(2)

async def test_sync_place():
    logger = get_logger("test_sync_place")
    async with pybotters.Client(apis='./apis.json') as client:
        async with Bitmart(client=client) as broker:
            place_task = broker.place_order(
                symbol='ONDOUSDT',
                side='sell',
                category='market',
                mode='ioc',
                price=0.71,
                qty=0.2,
            )
            result = await order_sync_polling(
                broker,
                place_task,
                is_ioc=False,
                cancel_retry=2,
                logger=logger,
            )
            logger.info(f"Order Sync Result: {result}")

if __name__ == "__main__":
    asyncio.run(test_sync_place())
