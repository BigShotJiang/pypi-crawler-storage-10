from setuptools import setup

setup(
   name='rocket-khaled',
   version='1.0.0',
   author='khaled',
   author_email='m.khaled@esi-sba.dz',
   packages=['rocket'],
   url='http://pypi.python.org/pypi/rocket/',
   license='LICENSE.txt',
   description='An awesome package that does something',
   long_description=open('README.md').read(),
   long_description_content_type="text/markdown",
   install_requires=['rocket']
)