import math 

#Test the codes above
class Rocket():
    # Rocket simulates a rocket ship for a game,
    #  or a physics simulation.
    
    def __init__(self , x=0, y=0):
        # Each rocket has an (x,y) position.
        self.x = x
        self.y = y
        
    def move_up(self, x_increment=0, y_increment=1):
        # Move the rocket according to the paremeters given.
        #  Default behavior is to move the rocket up one unit.
        self.x += x_increment
        self.y += y_increment

    def get_distance(self , rocket):

        return math.sqrt((self.x - rocket.x)**2 + (self.y - rocket.y)**2)

    def __str__(self):
        return "Rocket position: (" + str(self.x) + ", " + str(self.y) + ")"

    def __repr__(self):
        return "Rocket(" + str(self.x) + ", " + str(self.y) + ")"
   
class Shuttle(Rocket):
    # Shuttle simulates a space shuttle, which is really
    #  just a reusable rocket.
    
    def __init__(self, x=0, y=0, flights_completed=0):
        super().__init__(x, y)
        self.flights_completed = flights_completed