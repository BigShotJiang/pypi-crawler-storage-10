from django.apps import AppConfig


class DjangoExampleApplicationConfig(AppConfig):
    name = 'DjangoExampleApplication'
