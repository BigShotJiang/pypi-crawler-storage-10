"""
杂项
"""


__all__ = []

import typing
