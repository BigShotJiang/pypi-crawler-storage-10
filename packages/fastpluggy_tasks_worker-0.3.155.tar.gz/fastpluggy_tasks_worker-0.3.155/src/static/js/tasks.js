/**
 * Format duration with appropriate units (ns, µs, ms, s, m, h)
 * @param {number} seconds - Duration in seconds
 * @returns {string} Formatted duration string
 */
function formatDuration(seconds) {
    if (seconds == null || isNaN(seconds)) return "-";

    // Less than 1 microsecond: show nanoseconds
    if (seconds < 0.000001) {
        return `${(seconds * 1000000000).toFixed(0)} ns`;
    }

    // Less than 1 millisecond: show microseconds
    if (seconds < 0.001) {
        return `${(seconds * 1000000).toFixed(0)} µs`;
    }

    // Less than 1 second: show milliseconds
    if (seconds < 1) {
        return `${(seconds * 1000).toFixed(0)} ms`;
    }

    // Less than 60 seconds: show seconds
    if (seconds < 60) {
        return `${seconds.toFixed(2)} s`;
    }

    // Less than 1 hour: show minutes and seconds
    if (seconds < 3600) {
        const minutes = Math.floor(seconds / 60);
        const secs = (seconds % 60).toFixed(0);
        return `${minutes} m ${secs} s`;
    }

    // 1 hour or more: show hours, minutes, and seconds
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = (seconds % 60).toFixed(0);
    return `${hours} h ${minutes} m ${secs} s`;
}

// Function to submit tasks to the task system
async function submitTask(taskFunction, taskName, taskParams) {
    const response = await fetch(window.global_var['task_submit_url'], {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            function: taskFunction,
            name: taskName,
            kwargs: taskParams
        })
    });

    return await response.json();
}