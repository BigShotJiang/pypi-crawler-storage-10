# ==================================================================================================================== #
#            _     _                                           _                                                       #
#  ___ _ __ | |__ (_)_ __ __  __     _ __ ___ _ __   ___  _ __| |_ ___                                                 #
# / __| '_ \| '_ \| | '_ \\ \/ /____| '__/ _ \ '_ \ / _ \| '__| __/ __|                                                #
# \__ \ |_) | | | | | | | |>  <_____| | |  __/ |_) | (_) | |  | |_\__ \                                                #
# |___/ .__/|_| |_|_|_| |_/_/\_\    |_|  \___| .__/ \___/|_|   \__|___/                                                #
#     |_|                                    |_|                                                                       #
# ==================================================================================================================== #
# Authors:                                                                                                             #
#   Patrick Lehmann                                                                                                    #
#                                                                                                                      #
# License:                                                                                                             #
# ==================================================================================================================== #
# Copyright 2023-2025 Patrick Lehmann - Bötzingen, Germany                                                             #
#                                                                                                                      #
# Licensed under the Apache License, Version 2.0 (the "License");                                                      #
# you may not use this file except in compliance with the License.                                                     #
# You may obtain a copy of the License at                                                                              #
#                                                                                                                      #
#   http://www.apache.org/licenses/LICENSE-2.0                                                                         #
#                                                                                                                      #
# Unless required by applicable law or agreed to in writing, software                                                  #
# distributed under the License is distributed on an "AS IS" BASIS,                                                    #
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.                                             #
# See the License for the specific language governing permissions and                                                  #
# limitations under the License.                                                                                       #
#                                                                                                                      #
# SPDX-License-Identifier: Apache-2.0                                                                                  #
# ==================================================================================================================== #
#
"""
**Report unit test results as Sphinx documentation page(s).**
"""
from typing import Dict, Tuple, Any, List, Mapping, Generator

from docutils                          import nodes
from pyTooling.Decorators              import export
from sphinx.application import Sphinx
from sphinx.config import Config

from sphinx_reports.Common               import ReportExtensionError
from sphinx_reports.Sphinx               import stripAndNormalize, BaseDirective
from sphinx_reports.DataModel.Dependency import Distribution
from sphinx_reports.Adapter.Dependency   import DependencyScanner


@export
class DependencyTable(BaseDirective):
	"""
	This directive will be replaced by a table representing dependencies.
	"""
	has_content = False
	required_arguments = 0
	optional_arguments = 1

	option_spec = {
		"package":       stripAndNormalize
	}

	directiveName: str = "dependency-table"
	configPrefix:  str = "dep"
	configValues:  Dict[str, Tuple[Any, str, Any]] = {
		# f"{configPrefix}_testsuites": ({}, "env", Dict)
	}  #: A dictionary of all configuration values used by unittest directives.

	_packageName:  str

	_distribution: Distribution

	def _CheckOptions(self) -> None:
		"""
		Parse all directive options or use default values.
		"""
		self._packageName = self._ParseStringOption("package")

	@classmethod
	def CheckConfiguration(cls, sphinxApplication: Sphinx, sphinxConfiguration: Config) -> None:
		"""
		Check configuration fields and load necessary values.

		:param sphinxApplication:   Sphinx application instance.
		:param sphinxConfiguration: Sphinx configuration instance.
		"""
		pass

	def _GenerateDependencyTable(self) -> nodes.table:
		# Create a table and table header with 8 columns
		columns = [
			("Package", None, 500),
			("Version", None, 100),
			("License", None, 100),
		]

		tableGroup = self._CreateDoubleRowTableHeader(
			identifier=self._packageName,
			columns=columns,
			classes=["report-dependency-table"]
		)
		tableBody = nodes.tbody()
		tableGroup += tableBody

		# def sortedValues(d: Mapping[str, Testsuite]) -> Generator[Testsuite, None, None]:
		# 	for key in sorted(d.keys()):
		# 		yield d[key]

		def renderRoot(tableBody: nodes.tbody, distribution: Distribution) -> None:
			tableRow = nodes.row("", classes=["report-dependency-table-row", "report-dependency"])
			tableBody += tableRow

			tableRow += nodes.entry("", nodes.Text(f"{distribution.Name}"))
			tableRow += nodes.entry("", nodes.Text(f"{distribution.Version}"))
			tableRow += nodes.entry("", nodes.Text(f"{distribution.Licenses}"))

			# for ts in sortedValues(testsuite._testsuites):
			# 	renderTestsuite(tableBody, ts, 0)

		renderRoot(tableBody, self._distribution)

		# # Add a summary row

		return tableGroup.parent

	def run(self) -> List[nodes.Node]:
		self._CheckOptions()

		# Assemble a list of Python source files
		scanner = DependencyScanner(self._packageName)
		self._distribution = scanner.Distribution

		container = nodes.container()
		container += self._GenerateDependencyTable()

		return [container]
