# Macroeconomy  _0.1.1_

A macroeconomic analysis package followed the philosophy and methods of the New Classical Macro Theory.

### User Guide
Call the classes directly is quite a practical method, for instance,

`from macroenonmy.base import *`

`state = BasicEconomy(1.0, 0.0085, 0.6, 20)`

Detailed introduction of every class is available in their own code areas, and a brief example is available in the `if __name__=='__main__'` part at the end of some main files.

### Download

Here is my website:
* https://github.com/JerrySkywolf

This package could be downloaded through PyPi by:

`pip install macroeconomy`

View at the webpage
* https://pypi.org/project/macroeconomy