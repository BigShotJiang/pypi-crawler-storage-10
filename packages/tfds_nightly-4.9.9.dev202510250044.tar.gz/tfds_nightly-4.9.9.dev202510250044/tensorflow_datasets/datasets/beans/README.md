Beans is a dataset of images of beans taken in the field using smartphone
cameras. It consists of 3 classes: 2 disease classes and the healthy class.
Diseases depicted include Angular Leaf Spot and Bean Rust. Data was annotated by
experts from the National Crops Resources Research Institute (NaCRRI) in Uganda
and collected by the Makerere AI research lab.
