"""Configuration loading and parsing."""

import json
import os
from pathlib import Path
from typing import Any, Dict
from pydantic import BaseModel, Field, ValidationError

from mcp_dynamic_proxy.core.models import (
    PoolConfig,
    CircuitBreakerConfig,
    GlobalLimits,
    RateLimitConfig,
)


def expand_env_vars(value: Any) -> Any:
    """Recursively expand environment variables in config values."""
    if isinstance(value, str) and value.startswith("${") and value.endswith("}"):
        env_var = value[2:-1]
        return os.getenv(env_var, value)
    elif isinstance(value, dict):
        return {k: expand_env_vars(v) for k, v in value.items()}
    elif isinstance(value, list):
        return [expand_env_vars(item) for item in value]
    return value


def load_config(config_path: str | Path | None = None) -> Dict[str, Any]:
    """
    Load MCP server configuration from JSON file.
    
    Args:
        config_path: Path to config file. If None, uses default location.
    
    Returns:
        Dictionary with configuration data
    
    Raises:
        FileNotFoundError: If config file doesn't exist
        json.JSONDecodeError: If config file is invalid JSON
    """
    if config_path is None:
        # Default to config/mcp.json relative to package root
        package_root = Path(__file__).parent.parent.parent
        config_path = package_root / "config" / "mcp.json"
    
    config_path = Path(config_path)
    
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")
    
    with open(config_path, "r", encoding="utf-8") as f:
        raw_config = json.load(f)

    # Expand environment variables before validation (keeps schema simple)
    raw_config = expand_env_vars(raw_config)

    # Validate structure using Pydantic for clear, actionable errors
    try:
        validated = RootConfigModel.model_validate(raw_config)
    except ValidationError as e:
        # Re-raise with a concise message including location of failures
        raise ValueError(f"Invalid MCP configuration: {e}") from e

    return validated.model_dump()


# ----------------------------------------------------------------------------
# Schema models (non-security governance)
# ----------------------------------------------------------------------------


class ServerConfigModel(BaseModel):
    description: str = Field(default="")
    tags: list[str] = Field(default_factory=list)
    category: str = Field(default="other")
    command: str
    args: list[str] = Field(default_factory=list)
    env: Dict[str, str] | None = None
    lazy_load: bool = True
    cache_ttl: int = Field(default=3600, ge=0)


class RootConfigModel(BaseModel):
    version: str = Field(default="1.0")
    mcpServers: Dict[str, ServerConfigModel] = Field(default_factory=dict)

    # Global configuration sections (optional, with defaults)
    pool: PoolConfig = Field(default_factory=PoolConfig)
    circuit_breaker: CircuitBreakerConfig = Field(default_factory=CircuitBreakerConfig)
    retry: Dict[str, Any] = Field(default_factory=dict)  # Retry config as dict (converted to dataclass in server.py)
    global_limits: GlobalLimits = Field(default_factory=GlobalLimits)
    rate_limit: RateLimitConfig = Field(default_factory=RateLimitConfig)

