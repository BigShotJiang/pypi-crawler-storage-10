"""MCP Dynamic Proxy Server - Main entry point"""

import asyncio
import logging
import os
import sys
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncIterator
from fastmcp import FastMCP
import structlog
from structlog import stdlib as structlog_stdlib

from .config import load_config
from .registry import ServerRegistry
from .core.manager import ConnectionManager
from .core.models import PoolConfig, GlobalLimits
from .resilience.circuit_breaker import CircuitBreakerConfig
from .resilience.retry import RetryConfig as ResilienceRetryConfig
from .tools import (
    discover_servers,
    list_all_servers,
    list_tools,
    execute_tool,
)

# Configure Python's standard logging to stderr (stdout is reserved for JSON-RPC)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stderr,
    force=True  # Override any existing configuration
)

# Suppress verbose MCP server logs
mcp_logger = logging.getLogger("mcp.server.lowlevel.server")
mcp_logger.setLevel(logging.WARNING)

# Suppress FastMCP startup banner/info line
fastmcp_logger = logging.getLogger("fastmcp")
fastmcp_logger.setLevel(logging.WARNING)

# Configure structured logging to stderr (stdout is reserved for JSON-RPC)
structlog.configure(
    processors=[
        structlog.processors.add_log_level,
        structlog_stdlib.filter_by_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.dev.ConsoleRenderer(colors=False),  # Disable ANSI colors
    ],
    logger_factory=structlog_stdlib.LoggerFactory(),  # Use stdlib logger for level filtering
    wrapper_class=structlog_stdlib.BoundLogger,
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger(__name__)

# Load configuration
config_path = os.getenv("MCP_CONFIG_PATH")
if config_path:
    config_path = Path(config_path)
else:
    # Default to config/mcp.json relative to package root
    package_root = Path(__file__).parent.parent.parent
    config_path = package_root / "config" / "mcp.json"

config = load_config(config_path)
registry = ServerRegistry(config)

# Load configuration from config file (with defaults from models)
pool_config = PoolConfig(**config.get("pool", {}))
global_limits = GlobalLimits(**config.get("global_limits", {}))

# Circuit breaker config: map Pydantic field names to dataclass field names
cb_config_dict = config.get("circuit_breaker", {})
if "half_open_max_calls" in cb_config_dict:
    cb_config_dict["half_open_max_requests"] = cb_config_dict.pop("half_open_max_calls")
circuit_breaker_config = CircuitBreakerConfig(**cb_config_dict)

retry_config = ResilienceRetryConfig(**config.get("retry", {}))

manager = ConnectionManager(
    registry,
    pool_config,
    global_limits,
    circuit_breaker_config=circuit_breaker_config,
    retry_config=retry_config,
)


# Lifespan hook for graceful startup and shutdown
@asynccontextmanager
async def proxy_lifespan(server: FastMCP) -> AsyncIterator[None]:
    """
    Manage proxy lifecycle: startup and shutdown.

    This ensures the connection manager is properly started before handling
    requests and gracefully shut down when the server stops, preventing
    asyncio cancel scope errors.
    """
    # Startup: Initialize manager
    logger.debug("server_starting")
    await manager.start()
    logger.debug("server_started")

    yield  # Server runs and handles requests

    # Shutdown: Gracefully stop all connections (guaranteed to run)
    logger.debug("server_shutdown_requested")
    await manager.shutdown()
    logger.debug("server_shutdown_complete")


# Initialize FastMCP with lifespan hook
mcp = FastMCP("mcp-dynamic-proxy", lifespan=proxy_lifespan)


@mcp.tool()
async def mcp_list_all_servers() -> dict:
    """
    List all available MCP servers with their descriptions and metadata.
    This tool returns every configured MCP server without any filtering.

    Use this when you want a complete overview of all available MCP servers.
    For filtered searches, use mcp_discover_servers instead.

    Returns:
        Dictionary with count and complete list of all servers including their
        id, description, tags, and category
    """
    return await list_all_servers(registry)


@mcp.tool()
async def mcp_discover_servers(
    tags: list[str] | str | None = None,
    search: str | None = None,
    category: str | None = None,
) -> dict:
    """
    Discover available MCP servers by tags, search term, or category.
    This tool allows you to find MCP servers without loading them.

    Args:
        tags: Optional list of tags to filter servers (e.g., ['aws', 'database']) or comma-separated string
        search: Optional search term to filter by description or server ID
        category: Optional category filter (e.g., 'database', 'documentation')

    Returns:
        Dictionary with count and list of available servers and their metadata
    """
    # Normalize tags parameter
    normalized_tags = None
    if tags:
        if isinstance(tags, str):
            # Convert comma-separated string to list, or ignore if empty
            normalized_tags = [t.strip() for t in tags.split(",") if t.strip()]
        else:
            normalized_tags = tags

    return await discover_servers(registry, normalized_tags, search, category)


@mcp.tool()
async def mcp_list_tools(server_id: str) -> dict:
    """
    Get the list of tools available in a specific MCP server.
    This will load the server if not already loaded.

    Args:
        server_id: The MCP server ID (e.g., 'aws-dynamodb', 'postgres')

    Returns:
        Dictionary with server info and list of available tools with their schemas
    """
    return await list_tools(manager, server_id)


@mcp.tool()
async def mcp_execute_tool(
    server_id: str,
    tool_name: str,
    arguments: dict,
) -> dict:
    """
    Execute a tool from a specific MCP server.
    This will load the server if not already loaded.

    Args:
        server_id: The MCP server ID
        tool_name: The name of the tool to call
        arguments: Dictionary of arguments to pass to the tool

    Returns:
        Dictionary with the result from the tool execution
    """
    return await execute_tool(manager, server_id, tool_name, arguments)


def main():
    """Main entry point for the mcp-dynamic-proxy command."""
    # Disable banner to keep stdout clean for JSON-RPC messages
    mcp.run(show_banner=False)


if __name__ == "__main__":
    main()

