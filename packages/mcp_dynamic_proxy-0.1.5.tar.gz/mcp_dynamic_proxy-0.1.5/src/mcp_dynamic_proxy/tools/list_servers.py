"""Tool implementation: mcp_discover_servers"""

from typing import Optional
from ..registry import ServerRegistry, ServerMetadata


async def execute(
    registry: ServerRegistry,
    tags: Optional[list[str]] = None,
    search: Optional[str] = None,
    category: Optional[str] = None,
) -> dict:
    """
    Execute mcp_discover_servers tool - discover MCP servers by tags, search, or category.
    
    Args:
        registry: Server registry instance
        tags: Optional list of tags to filter by
        search: Optional search term for description/ID
        category: Optional category filter
    
    Returns:
        Dictionary with count and list of matching servers
    """
    servers = registry.search(tags=tags, search=search, category=category)
    
    return {
        "count": len(servers),
        "servers": [
            {
                "id": s.id,
                "description": s.description,
                "tags": s.tags,
                "category": s.category,
                "status": "available",
                "lazy_load": s.lazy_load,
            }
            for s in servers
        ],
    }

