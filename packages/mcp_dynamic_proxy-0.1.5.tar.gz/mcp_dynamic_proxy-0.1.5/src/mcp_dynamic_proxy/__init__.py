"""MCP Dynamic Proxy - Progressive discovery and lazy loading of MCP servers."""

__version__ = "0.1.0"

