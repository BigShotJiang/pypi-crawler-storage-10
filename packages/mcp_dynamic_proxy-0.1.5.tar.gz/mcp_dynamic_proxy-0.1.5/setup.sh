#!/bin/bash
# Setup script for MCP Dynamic Proxy

set -e

echo "🚀 MCP Dynamic Proxy Setup"
echo "=========================="
echo ""

# Check Python version
if ! command -v python3.12 &> /dev/null; then
    echo "❌ Python 3.12 is required but not found"
    exit 1
fi

echo "✓ Python 3.12 found: $(python3.12 --version)"

# Upgrade pip (user-level)
echo "Upgrading pip..."
python3.12 -m pip install --upgrade pip setuptools wheel --quiet

# Install package
echo "Installing mcp-dynamic-proxy..."
python3.12 -m pip install -e "." --quiet

echo ""
echo "✅ Setup complete!"
echo ""
echo "To run the server:"
echo "  python3.12 -m mcp_dynamic_proxy.server"
echo ""
# No bundled tests in this repository

