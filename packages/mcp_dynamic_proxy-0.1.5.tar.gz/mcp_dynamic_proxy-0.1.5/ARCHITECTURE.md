## MCP Dynamic Proxy – Architecture

### Overview
The MCP Dynamic Proxy is a lightweight, reliability-focused proxy for the Model Context Protocol (MCP). It exposes a minimal surface area (core tools) to the assistant and performs progressive discovery and lazy loading of downstream MCP servers on demand.

High-level flow:
- Assistant → MCP tools (discover, list, execute)
- Proxy loads or reuses connections to MCP servers
- Requests are routed via connection pools with timeouts, retry, and circuit breaking

```
Assistant (Cursor) -MCP-> MCP Dynamic Proxy -MCP stdio-> External MCP Servers
```

### Goals and SLOs
- Target environment: single server (VM/bare metal)
- Availability: 99.9%+
- Latency budget: Proxy overhead p95 under ~500 ms (excluding downstream server latency)

### Key Modules
- `src/mcp_dynamic_proxy/server.py`: FastMCP entrypoint, tool registration, lifecycle hooks
- `src/mcp_dynamic_proxy/config.py`: Configuration loading, env expansion, schema validation (Pydantic)
- `src/mcp_dynamic_proxy/registry.py`: In-memory registry of MCP server metadata with permissive search
- `src/mcp_dynamic_proxy/core/`:
  - `models.py`: Pydantic models for pools, limits, and configuration
  - `manager.py`: Orchestrates pools, enforces global limits, circuit breakers, rate limits
  - `pool.py`: Connection pool lifecycle, acquisition with timeouts, internal health checks, recycling
  - `connection.py`: Worker-task-based MCP connection (owns stdio transport and session), robust timeouts
  - `rate_limiter.py`: Token-bucket implementation (global and per-server)
- `src/mcp_dynamic_proxy/tools/`: Core tool implementations (discover, list_tools, execute_tool)

### Core Concepts

#### Progressive Discovery and Lazy Loading
- The proxy initially exposes only three core operations to discover servers, list a server’s tools, and execute a selected tool.
- Connections to MCP servers are established on demand and cached in a pool with TTL/expiration via recycling.

#### Connection Worker Pattern
- Each MCP connection is hosted by a dedicated asyncio worker task that owns all context managers (stdio transport and MCP session). This avoids cancel scope issues and ensures cleanup occurs in the same task that created the resources.
- Requests are sent to the worker via an internal queue; responses return via futures.

#### Connection Pooling
- One pool per MCP server (`ConnectionPool`).
- Dynamic sizing from `min_size` to `max_size` with on-demand creation.
- Acquisition uses bounded waiting with `acquire_timeout` to prevent unbounded queueing.
- Health checks periodically validate available connections; expired or unhealthy connections are recycled.
- Connections are recycled after `max_lifetime` to prevent resource drift.

#### Timeouts and Retries
- Explicit timeouts are enforced for:
  - Connection start (`start_timeout`)
  - Tool execution (`tool_timeout`)
  - Health checks (`health_check_timeout`)
  - Pool acquire (`acquire_timeout`)
- Retries (exponential backoff) are used during connection start; operational requests use retry and circuit breaker at the manager layer.

#### Circuit Breaking
- A per-server circuit breaker guards `call_tool` operations. It opens on sustained failures, fails fast while open, and transitions through half-open to closed upon recovery.

#### Rate Limiting
- Optional token-bucket limiting:
  - Global limiter: caps aggregate request rate across all servers
  - Per-server limiter: protects individual servers from bursty or abusive load
- Fast-fail semantics: when tokens are unavailable, the request is rejected immediately with a `rate_limited` error.

### Configuration
- File: `config/mcp.json`
- Validated by Pydantic models in `config.py` (structure/types). Example fields per server:
  - `description`, `tags`, `category`
  - `command`, `args`, optional `env`
  - `lazy_load` (default true), `cache_ttl` (seconds)
- Environment variable expansion is supported for values like `${VAR}`.

### Lifecycle
- Startup (`server.py`):
  - Loads config and builds a `ServerRegistry`
  - Creates a `ConnectionManager` with pool configuration and global limits
  - Hooks lifecycle via `FastMCP` lifespan to start/shutdown manager cleanly
- Shutdown: manager gracefully stops all pools and connections, suppressing cancel-scope noise and ensuring stdio transport/session cleanup.

### Public MCP Tools
Registered in `server.py` using FastMCP decorators. All return JSON-serializable dicts.
- `mcp_discover_servers(tags?, search?, category?)`: list server metadata
- `mcp_list_tools(server_id)`: load server if needed and return tool schemas
- `mcp_execute_tool(server_id, tool_name, arguments)`: execute tool and return content

### Error Handling and Backpressure
- Backpressure is enforced via:
  - Bounded acquire waiting with explicit `acquire_timeout`
  - Rate limiters (global/per-server) that fast-fail with clear errors
  - Circuit breakers that fail fast during fault conditions
- Errors surface as structured runtime errors with succinct messages suitable for assistant handling.

### Resource Limits and Stats
- Global limits are modeled in `GlobalLimits` (e.g., maximum total connections). The manager enforces these when creating pools.
- `ConnectionStats` and `PoolStats` track connection health and pool sizing information internally for monitoring and debugging.

### Non-Goals (Out of Scope)
- Command/environment security hardening (e.g., process sandboxing) – handled externally.
- Monitoring/observability stacks (metrics/tracing/dashboards) – not included here.
- Load/chaos testing suites – not part of this repository.
- Deployment artifacts/runbooks – not included.

### Extensibility
- Add new tools by implementing `src/mcp_dynamic_proxy/tools/<name>.py` with an `execute(...)` coroutine and exporting it in `tools/__init__.py`, then registering in `server.py`.
- Add new limiters or resilience policies by extending `core/manager.py` and/or `core/*` utilities.

### Appendix: Key Data Models (selection)
- `PoolConfig`: min/max size, acquire/idle timeouts, operation timeouts, max lifetime
- `GlobalLimits`: max total connections, memory/file descriptor ceilings (advisory)
- `ConnectionStats`: status, internal health checks, latency samples, subprocess info
- `PoolStats`: size, availability, in-use counts, timeouts, lifecycle counters


