# MCP Dynamic Proxy - Troubleshooting Guide

This guide helps you diagnose and fix common issues with the MCP Dynamic Proxy.

## Table of Contents

- [Connection Issues](#connection-issues)
- [Timeout Errors](#timeout-errors)
- [Circuit Breaker Issues](#circuit-breaker-issues)
- [Pool Exhaustion](#pool-exhaustion)
- [Configuration Problems](#configuration-problems)
- [Performance Issues](#performance-issues)
- [Debugging](#debugging)

---

## Connection Issues

### Problem: "Server not found" Error

**Symptoms:**
```json
{
  "status": "error",
  "error": "Invalid server ID or server not found"
}
```

**Causes:**
1. Server ID doesn't exist in `config/mcp.json`
2. Typo in server ID
3. Configuration file not loaded

**Solutions:**

1. **Check server ID** in your configuration:
   ```bash
   cat config/mcp.json | grep -A5 "mcpServers"
   ```

2. **Verify server ID spelling** - server IDs are case-sensitive

3. **Use discover tool** to list available servers:
   ```json
   {
     "tool": "mcp_discover_servers"
   }
   ```

4. **Check config file path** - set `MCP_CONFIG_PATH` environment variable if using custom location

---

### Problem: Connection Start Timeout

**Symptoms:**
- Tools hang when calling a server for the first time
- Error: "Connection start timeout"

**Causes:**
1. MCP server command is slow to start
2. Server process is failing to start
3. Network issues (for remote servers)

**Solutions:**

1. **Increase start timeout** in `config/mcp.json`:
   ```json
   {
     "pool": {
       "start_timeout": 60.0
     }
   }
   ```

2. **Test server command manually**:
   ```bash
   # Run the server command directly to see if it starts
   sh -c "uvx mcp-server-fetch 2>/dev/null"
   ```

3. **Check server logs** - stderr output goes to proxy logs:
   ```bash
   # Look for error messages
   grep "worker_error" logs/proxy.log
   ```

4. **Verify server binary exists**:
   ```bash
   which uvx  # Or whatever command your server uses
   ```

---

## Timeout Errors

### Problem: "Request timed out" Errors

**Symptoms:**
```json
{
  "status": "error",
  "error": "Tool execution failed"
}
```

With log message: `Request CALL_TOOL timed out after Xs`

**Causes:**
1. Tool execution is genuinely slow
2. Server is unresponsive
3. Network latency (for remote calls)

**Solutions:**

1. **Increase tool timeout** in `config/mcp.json`:
   ```json
   {
     "pool": {
       "tool_timeout": 600.0
     }
   }
   ```

2. **Check if server is healthy**:
   - Health checks run automatically
   - Look for `health_check_failed` in logs

3. **Reduce concurrent load**:
   - Lower `max_size` in pool config
   - Enable rate limiting

4. **Check system resources**:
   ```bash
   # Check CPU/memory usage
   top -p $(pgrep -f mcp-dynamic-proxy)
   ```

---

## Circuit Breaker Issues

### Problem: Circuit Breaker Open - Requests Rejected

**Symptoms:**
- All requests to a specific server fail immediately
- Error messages about circuit breaker being open

**Causes:**
1. Server had too many consecutive failures
2. Circuit breaker threshold is too low
3. Underlying server issue not resolved

**Solutions:**

1. **Wait for automatic recovery** - circuit breaker will transition to HALF_OPEN after timeout:
   - Default timeout: 60 seconds
   - Check logs for `circuit_breaker_half_open`

2. **Check underlying server issue**:
   ```bash
   # Test server manually
   sh -c "SERVER_COMMAND_HERE"
   ```

3. **Adjust circuit breaker thresholds** in `config/mcp.json`:
   ```json
   {
     "circuit_breaker": {
       "failure_threshold": 10,
       "success_threshold": 2,
       "timeout": 30.0
     }
   }
   ```

4. **Monitor circuit breaker state**:
   ```bash
   # Look for circuit breaker events
   grep "circuit_breaker" logs/proxy.log
   ```

5. **Restart proxy if stuck** - circuit breaker state resets on restart

---

## Pool Exhaustion

### Problem: "Pool exhausted" or "Acquire timeout" Errors

**Symptoms:**
- Requests hang and timeout
- Log message: `pool_acquire_timeout`
- High concurrent load

**Causes:**
1. All connections in pool are busy
2. Pool max size is too small
3. Connections are leaking (not released)
4. Slow tool executions blocking pool

**Solutions:**

1. **Increase pool size** in `config/mcp.json`:
   ```json
   {
     "pool": {
       "min_size": 2,
       "max_size": 10,
       "max_queue_size": 200
     }
   }
   ```

2. **Increase acquire timeout**:
   ```json
   {
     "pool": {
       "acquire_timeout": 60.0
     }
   }
   ```

3. **Check pool stats** - add logging to see pool utilization:
   ```bash
   grep "pool_stats" logs/proxy.log
   ```

4. **Enable rate limiting** to prevent overload:
   ```json
   {
     "rate_limit": {
       "enabled": true,
       "requests_per_second": 10.0
     }
   }
   ```

5. **Check for connection leaks**:
   - Look for `current_size` growing without bound
   - Monitor `in_use` vs `available` connections

---

## Configuration Problems

### Problem: Configuration Not Loading

**Symptoms:**
- Proxy uses default configuration
- Changes to `config/mcp.json` not reflected

**Solutions:**

1. **Check config file exists**:
   ```bash
   ls -la config/mcp.json
   ```

2. **Validate JSON syntax**:
   ```bash
   python -m json.tool config/mcp.json
   ```

3. **Check file permissions**:
   ```bash
   chmod 644 config/mcp.json
   ```

4. **Set config path explicitly**:
   ```bash
   export MCP_CONFIG_PATH=/path/to/config/mcp.json
   python -m mcp_dynamic_proxy.server
   ```

5. **Check Pydantic validation errors** in startup logs

---

### Problem: Environment Variable Expansion Not Working

**Symptoms:**
- Environment variables like `${MY_VAR}` not expanded
- Literal `${MY_VAR}` appears in config

**Solutions:**

1. **Set environment variable before starting**:
   ```bash
   export MY_VAR="value"
   python -m mcp_dynamic_proxy.server
   ```

2. **Check variable format** - must be `${VAR_NAME}`:
   ```json
   {
     "command": "${MCP_COMMAND}"
   }
   ```

3. **Use .env file** for development:
   ```bash
   source .env
   python -m mcp_dynamic_proxy.server
   ```

---

## Performance Issues

### Problem: High Memory Usage

**Symptoms:**
- Proxy memory usage grows over time
- System becomes slow

**Solutions:**

1. **Enable connection recycling** - already configured:
   ```json
   {
     "pool": {
       "max_lifetime": 3600.0,
       "idle_timeout": 300.0
     }
   }
   ```

2. **Reduce pool sizes**:
   ```json
   {
     "pool": {
       "max_size": 3
     }
   }
   ```

3. **Monitor memory**:
   ```bash
   ps aux | grep mcp-dynamic-proxy
   ```

4. **Check for memory leaks** - file issue if memory grows unbounded

---

### Problem: Slow Response Times

**Symptoms:**
- All operations are slow
- High latency

**Solutions:**

1. **Check system load**:
   ```bash
   uptime
   top
   ```

2. **Profile with structlog** - check logs for duration_ms:
   ```bash
   grep "duration_ms" logs/proxy.log | sort -t: -k2 -n
   ```

3. **Reduce concurrent connections**:
   ```json
   {
     "global_limits": {
       "max_total_connections": 20
     }
   }
   ```

4. **Enable connection pooling** (already enabled by default)

---

## Debugging

### Enable Debug Logging

Add to `config/mcp.json`:

```json
{
  "observability": {
    "log_level": "DEBUG",
    "structured_logging": true
  }
}
```

Then check logs for detailed information:

```bash
# Filter by specific component
grep "connection" logs/proxy.log
grep "pool" logs/proxy.log
grep "circuit_breaker" logs/proxy.log
```

---

### Common Log Messages

| Log Message | Meaning | Action |
|-------------|---------|--------|
| `connection_starting` | Connection being established | Normal |
| `connection_timeout` | Connection start timeout | Increase `start_timeout` |
| `health_check_failed` | Health check failed | Check server process |
| `pool_exhausted` | No available connections | Increase `max_size` |
| `circuit_breaker_open` | Circuit opened due to failures | Wait for recovery or check server |
| `retry_exhausted` | All retry attempts failed | Check server availability |
| `worker_error` | MCP worker task error | Check server command |

---

### Diagnostic Commands

```bash
# Check if proxy is running
ps aux | grep mcp-dynamic-proxy

# Check listening ports
netstat -tlnp | grep python

# Check file descriptors
lsof -p $(pgrep -f mcp-dynamic-proxy) | wc -l

# Monitor logs in real-time
tail -f logs/proxy.log

# Count errors by type
grep "error" logs/proxy.log | cut -d' ' -f4 | sort | uniq -c

# Check connection pool stats
grep "pool_stats" logs/proxy.log | tail -20
```

---

### Getting Help

If you're still experiencing issues:

1. **Check GitHub Issues**: https://github.com/your-org/mcp-dynamic-proxy/issues
2. **Enable debug logging** and collect logs
3. **Note your configuration** (sanitize secrets)
4. **Describe the problem** with specific error messages
5. **Include system information**: OS, Python version, dependency versions

---

## Frequently Asked Questions

### Q: Why do connections close unexpectedly?

**A:** Connections are recycled based on `max_lifetime` and `idle_timeout`. This is normal and prevents resource leaks.

### Q: Can I disable lazy loading?

**A:** Yes, set `lazy_load: false` for specific servers in `config/mcp.json`.

### Q: How do I know if circuit breaker is working?

**A:** Look for `circuit_breaker_state_change` in logs. Circuit breaker states are also exposed via health endpoints (if implemented).

### Q: What happens when pool is full?

**A:** New requests wait in a queue (up to `max_queue_size`). If queue is full or `acquire_timeout` is exceeded, request fails.

### Q: Can I configure timeouts per-server?

**A:** Currently, timeouts are global. Per-server configuration could be added in future versions.

---

## Performance Tuning

For optimal performance:

```json
{
  "pool": {
    "min_size": 2,
    "max_size": 10,
    "acquire_timeout": 30.0,
    "tool_timeout": 300.0
  },
  "circuit_breaker": {
    "failure_threshold": 5,
    "timeout": 60.0
  },
  "retry": {
    "max_attempts": 3,
    "min_wait": 1.0,
    "max_wait": 10.0
  },
  "global_limits": {
    "max_total_connections": 50
  },
  "rate_limit": {
    "enabled": true,
    "requests_per_second": 20.0,
    "burst_size": 40
  }
}
```

Adjust based on your workload and system resources.
