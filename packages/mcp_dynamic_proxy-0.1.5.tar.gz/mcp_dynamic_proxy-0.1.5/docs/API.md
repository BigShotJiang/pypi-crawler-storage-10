# MCP Dynamic Proxy - API Documentation

This document describes the MCP tools exposed by the Dynamic Proxy server.

## Overview

The MCP Dynamic Proxy exposes three main tools for discovering and interacting with MCP servers:

1. **mcp_discover_servers** - Discover available MCP servers
2. **mcp_list_tools** - List tools available in a specific server
3. **mcp_execute_tool** - Execute a tool from a specific server

## Tools

### 1. mcp_discover_servers

Discover available MCP servers by tags, search term, or category. This tool allows you to find MCP servers without loading them (lazy discovery).

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `tags` | `list[str]` or `string` | No | List of tags to filter servers (e.g., ['aws', 'database']) or comma-separated string |
| `search` | `string` | No | Search term to filter by description or server ID |
| `category` | `string` | No | Category filter (e.g., 'database', 'documentation', 'infrastructure') |

**Request Example:**

```json
{
  "tags": ["aws", "documentation"],
  "search": "knowledge",
  "category": "documentation"
}
```

**Response Schema:**

```json
{
  "type": "object",
  "properties": {
    "count": {
      "type": "integer",
      "description": "Number of servers found"
    },
    "servers": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "id": {
            "type": "string",
            "description": "Unique server identifier"
          },
          "description": {
            "type": "string",
            "description": "Human-readable description"
          },
          "tags": {
            "type": "array",
            "items": {"type": "string"}
          },
          "category": {
            "type": "string"
          },
          "status": {
            "type": "string",
            "enum": ["available", "loaded", "error"]
          },
          "lazy_load": {
            "type": "boolean"
          }
        }
      }
    }
  }
}
```

**Response Example:**

```json
{
  "count": 1,
  "servers": [
    {
      "id": "aws-knowledge-mcp-server",
      "description": "AWS knowledge base with documentation and best practices",
      "tags": ["aws", "documentation", "cloud", "knowledge"],
      "category": "documentation",
      "status": "available",
      "lazy_load": true
    }
  ]
}
```

---

### 2. mcp_list_tools

Get the list of tools available in a specific MCP server. This will load the server if not already loaded.

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `server_id` | `string` | Yes | The MCP server ID (e.g., 'aws-dynamodb', 'postgres') |

**Request Example:**

```json
{
  "server_id": "fetch"
}
```

**Response Schema:**

```json
{
  "type": "object",
  "properties": {
    "server_id": {"type": "string"},
    "status": {
      "type": "string",
      "enum": ["loaded", "error"]
    },
    "tool_count": {
      "type": "integer",
      "description": "Number of tools available"
    },
    "tools": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "name": {"type": "string"},
          "description": {"type": "string"},
          "input_schema": {
            "type": "object",
            "description": "JSON Schema for tool inputs"
          }
        }
      }
    },
    "error": {
      "type": "string",
      "description": "Error message if status is error"
    }
  }
}
```

**Success Response Example:**

```json
{
  "server_id": "fetch",
  "status": "loaded",
  "tool_count": 1,
  "tools": [
    {
      "name": "fetch",
      "description": "Fetches a URL from the internet and optionally extracts its contents as markdown.",
      "input_schema": {
        "type": "object",
        "properties": {
          "url": {
            "type": "string",
            "description": "URL to fetch"
          },
          "max_length": {
            "type": "integer",
            "description": "Maximum response length"
          }
        },
        "required": ["url"]
      }
    }
  ]
}
```

**Error Response Example:**

```json
{
  "server_id": "nonexistent-server",
  "status": "error",
  "error": "Invalid server ID or server not found"
}
```

---

### 3. mcp_execute_tool

Execute a tool from a specific MCP server. This will load the server if not already loaded.

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `server_id` | `string` | Yes | The MCP server ID |
| `tool_name` | `string` | Yes | The name of the tool to call |
| `arguments` | `object` | Yes | Dictionary of arguments matching the tool's input schema |

**Request Example:**

```json
{
  "server_id": "fetch",
  "tool_name": "fetch",
  "arguments": {
    "url": "https://example.com",
    "max_length": 5000
  }
}
```

**Response Schema:**

```json
{
  "type": "object",
  "properties": {
    "server_id": {"type": "string"},
    "tool_name": {"type": "string"},
    "status": {
      "type": "string",
      "enum": ["success", "error"]
    },
    "result": {
      "type": "object",
      "description": "Tool execution result (if success)"
    },
    "error": {
      "type": "string",
      "description": "Error message (if error)"
    }
  }
}
```

**Success Response Example:**

```json
{
  "server_id": "fetch",
  "tool_name": "fetch",
  "status": "success",
  "result": {
    "content": [
      {
        "type": "text",
        "text": "Example Domain\n\nThis domain is for use in illustrative examples..."
      }
    ],
    "duration_ms": 243.5
  }
}
```

**Error Response Examples:**

**Validation Error:**
```json
{
  "server_id": "fetch",
  "tool_name": "fetch",
  "status": "error",
  "error": "Invalid arguments: 'url' is a required property"
}
```

**Tool Not Found:**
```json
{
  "server_id": "fetch",
  "tool_name": "nonexistent_tool",
  "status": "error",
  "error": "Tool 'nonexistent_tool' not found in server 'fetch'"
}
```

**Execution Error:**
```json
{
  "server_id": "fetch",
  "tool_name": "fetch",
  "status": "error",
  "error": "Tool execution failed"
}
```

---

## Error Handling

All tools follow a consistent error handling pattern:

1. **Validation Errors**: Invalid parameters or arguments return specific error messages
2. **Server Errors**: Connection or server-side issues return sanitized error messages
3. **Unexpected Errors**: Internal errors return generic "Internal server error" message

Error messages are sanitized to prevent information disclosure. Detailed error information is logged server-side for debugging.

---

## Security Features

### Input Validation

All tool arguments are validated against their JSON schemas before execution:

- **mcp_execute_tool** validates arguments against the tool's `input_schema`
- Invalid arguments are rejected before reaching the underlying MCP server
- Validation errors include helpful messages about what's wrong

### Error Sanitization

Error messages returned to clients are sanitized to prevent information disclosure:

- Internal paths are not exposed
- Stack traces are logged but not returned
- Sensitive configuration details are hidden
- Generic error messages for unexpected failures

---

## Rate Limiting

Rate limiting can be configured in `config/mcp.json`:

```json
{
  "rate_limit": {
    "enabled": false,
    "requests_per_second": 10.0,
    "burst_size": 20
  }
}
```

When rate limits are exceeded, requests will be throttled.

---

## Circuit Breaker

The proxy implements circuit breakers to prevent cascading failures:

- **CLOSED**: Normal operation, requests pass through
- **OPEN**: Too many failures, requests are rejected immediately
- **HALF_OPEN**: Testing recovery, limited requests allowed

Circuit breaker thresholds can be configured in `config/mcp.json`:

```json
{
  "circuit_breaker": {
    "failure_threshold": 5,
    "success_threshold": 2,
    "timeout": 60.0,
    "half_open_max_calls": 3
  }
}
```

When a circuit breaker is open, tool execution requests will fail fast with an appropriate error message.
