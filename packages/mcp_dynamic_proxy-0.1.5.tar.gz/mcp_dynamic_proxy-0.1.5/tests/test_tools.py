"""Tests for MCP proxy tools (list_servers, list_tools, call_tool)."""

import pytest
from unittest.mock import AsyncMock, Mock
# Import modules directly by file path to avoid shadowing in __init__.py
from mcp_dynamic_proxy.tools.list_servers import execute as list_servers_execute
from mcp_dynamic_proxy.tools.list_tools import execute as list_tools_execute
from mcp_dynamic_proxy.tools.call_tool import execute as call_tool_execute
from mcp_dynamic_proxy.registry import ServerMetadata


class TestListServers:
    """Test discover_servers tool."""

    @pytest.mark.asyncio
    async def test_list_all_servers(self, mock_registry):
        """Test listing all servers without filters."""
        result = await list_servers_execute(mock_registry)

        assert result["count"] == 1
        assert len(result["servers"]) == 1
        assert result["servers"][0]["id"] == "test-server"

    @pytest.mark.asyncio
    async def test_list_servers_with_tags(self, mock_registry):
        """Test filtering servers by tags."""
        result = await list_servers_execute(mock_registry, tags=["test"])

        assert result["count"] == 1
        assert result["servers"][0]["id"] == "test-server"

    @pytest.mark.asyncio
    async def test_list_servers_with_search(self, mock_registry):
        """Test searching servers by description."""
        result = await list_servers_execute(mock_registry, search="Test")

        assert result["count"] == 1

    @pytest.mark.asyncio
    async def test_list_servers_no_match(self, mock_registry):
        """Test listing servers with no matches."""
        result = await list_servers_execute(mock_registry, tags=["nonexistent"])

        assert result["count"] == 0
        assert result["servers"] == []


class TestListTools:
    """Test list_tools implementation."""

    @pytest.mark.asyncio
    async def test_list_tools_success(self, mock_mcp_session):
        """Test successful tool listing."""
        # Create mock manager
        mock_manager = AsyncMock()
        mock_tool = Mock()
        mock_tool.name = "test_tool"
        mock_tool.description = "A test tool"
        mock_tool.inputSchema = {"type": "object", "properties": {"param": {"type": "string"}}}
        mock_manager.get_tools = AsyncMock(return_value=[mock_tool])

        result = await list_tools_execute(mock_manager, "test-server")

        assert result["server_id"] == "test-server"
        assert result["status"] == "loaded"
        assert result["tool_count"] == 1
        assert len(result["tools"]) == 1
        assert result["tools"][0]["name"] == "test_tool"

    @pytest.mark.asyncio
    async def test_list_tools_server_not_found(self):
        """Test listing tools for non-existent server."""
        mock_manager = AsyncMock()
        mock_manager.get_tools = AsyncMock(side_effect=ValueError("Server not found"))

        result = await list_tools_execute(mock_manager, "nonexistent-server")

        assert result["status"] == "error"
        assert "server not found" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_list_tools_error_sanitization(self):
        """Test error messages are sanitized."""
        mock_manager = AsyncMock()
        mock_manager.get_tools = AsyncMock(side_effect=Exception("Internal path /etc/secret exposed"))

        result = await list_tools_execute(mock_manager, "test-server")

        assert result["status"] == "error"
        # Should not expose internal details
        assert "Internal server error" == result["error"]
        assert "/etc/secret" not in result["error"]


class TestCallTool:
    """Test execute_tool (call_tool) implementation."""

    @pytest.mark.asyncio
    async def test_call_tool_success(self):
        """Test successful tool execution."""
        mock_manager = AsyncMock()

        # Mock get_tools for schema validation
        mock_tool = Mock()
        mock_tool.name = "test_tool"
        mock_tool.inputSchema = {"type": "object", "properties": {"param": {"type": "string"}}}
        mock_manager.get_tools = AsyncMock(return_value=[mock_tool])

        # Mock call_tool
        mock_manager.call_tool = AsyncMock(return_value={"output": "result"})

        result = await call_tool_execute(
            mock_manager,
            "test-server",
            "test_tool",
            {"param": "value"}
        )

        assert result["status"] == "success"
        assert result["tool_name"] == "test_tool"
        assert "result" in result

    @pytest.mark.asyncio
    async def test_call_tool_validation_failure(self):
        """Test tool call with invalid arguments."""
        mock_manager = AsyncMock()

        # Mock get_tools with strict schema
        mock_tool = Mock()
        mock_tool.name = "test_tool"
        mock_tool.inputSchema = {
            "type": "object",
            "properties": {"required_param": {"type": "string"}},
            "required": ["required_param"]
        }
        mock_manager.get_tools = AsyncMock(return_value=[mock_tool])

        # Call without required parameter
        result = await call_tool_execute(
            mock_manager,
            "test-server",
            "test_tool",
            {}  # Missing required_param
        )

        assert result["status"] == "error"
        assert "Invalid arguments" in result["error"]

    @pytest.mark.asyncio
    async def test_call_tool_not_found(self):
        """Test calling non-existent tool."""
        mock_manager = AsyncMock()
        mock_manager.get_tools = AsyncMock(return_value=[])

        result = await call_tool_execute(
            mock_manager,
            "test-server",
            "nonexistent_tool",
            {}
        )

        assert result["status"] == "error"
        assert "not found" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_call_tool_execution_error(self):
        """Test tool execution error handling."""
        mock_manager = AsyncMock()

        mock_tool = Mock()
        mock_tool.name = "test_tool"
        mock_tool.inputSchema = {"type": "object", "properties": {}}
        mock_manager.get_tools = AsyncMock(return_value=[mock_tool])
        mock_manager.call_tool = AsyncMock(side_effect=RuntimeError("Execution failed"))

        result = await call_tool_execute(
            mock_manager,
            "test-server",
            "test_tool",
            {}
        )

        assert result["status"] == "error"
        # Should be sanitized
        assert result["error"] == "Tool execution failed"

    @pytest.mark.asyncio
    async def test_call_tool_error_sanitization(self):
        """Test error messages are properly sanitized."""
        mock_manager = AsyncMock()

        mock_tool = Mock()
        mock_tool.name = "test_tool"
        mock_tool.inputSchema = {"type": "object"}
        mock_manager.get_tools = AsyncMock(return_value=[mock_tool])
        mock_manager.call_tool = AsyncMock(
            side_effect=Exception("Database connection string: postgresql://user:pass@host/db")
        )

        result = await call_tool_execute(
            mock_manager,
            "test-server",
            "test_tool",
            {}
        )

        assert result["status"] == "error"
        # Should not contain sensitive info
        assert "postgresql://" not in result["error"]
        assert "Internal server error" == result["error"]
