"""Tests for retry logic with exponential backoff."""

import pytest
import asyncio
from tenacity import RetryError
from mcp_dynamic_proxy.resilience.retry import RetryableOperation, RetryConfig


class TestRetry:
    """Test retry logic and exponential backoff."""

    @pytest.mark.asyncio
    async def test_retry_success_on_first_attempt(self, retry_config):
        """Test operation succeeds on first attempt."""
        retry_op = RetryableOperation("test-op", retry_config)

        async def success_operation():
            return "success"

        result = await retry_op.execute(success_operation)
        assert result == "success"

    @pytest.mark.asyncio
    async def test_retry_success_after_failures(self, retry_config):
        """Test operation succeeds after transient failures."""
        retry_op = RetryableOperation("test-op", retry_config)
        attempts = []

        async def flaky_operation():
            attempts.append(1)
            if len(attempts) < 2:
                raise OSError("Temporary network error")
            return "success"

        result = await retry_op.execute(flaky_operation)
        assert result == "success"
        assert len(attempts) == 2

    @pytest.mark.asyncio
    async def test_retry_exhausted(self, retry_config):
        """Test all retry attempts exhausted."""
        retry_op = RetryableOperation("test-op", retry_config)
        attempts = []

        async def always_fails():
            attempts.append(1)
            raise OSError("Permanent failure")

        with pytest.raises(RetryError):
            await retry_op.execute(always_fails)

        # Should have tried max_attempts times
        assert len(attempts) == retry_config.max_attempts

    @pytest.mark.asyncio
    async def test_retry_non_retryable_error(self, retry_config):
        """Test non-retryable errors are not retried."""
        retry_op = RetryableOperation("test-op", retry_config)
        attempts = []

        async def non_retryable_error():
            attempts.append(1)
            raise ValueError("Not retryable")

        with pytest.raises(ValueError):
            await retry_op.execute(non_retryable_error)

        # Should only try once
        assert len(attempts) == 1

    @pytest.mark.asyncio
    async def test_retry_timeout_error(self, retry_config):
        """Test timeout errors are retried."""
        retry_op = RetryableOperation("test-op", retry_config)
        attempts = []

        async def timeout_operation():
            attempts.append(1)
            if len(attempts) < 2:
                raise asyncio.TimeoutError("Operation timed out")
            return "success"

        result = await retry_op.execute(timeout_operation)
        assert result == "success"
        assert len(attempts) == 2

    @pytest.mark.asyncio
    async def test_retry_exponential_backoff(self):
        """Test exponential backoff timing."""
        config = RetryConfig(
            max_attempts=3,
            min_wait=0.1,
            max_wait=1.0,
            jitter=0.05,
        )
        retry_op = RetryableOperation("test-op", config)
        attempts = []
        start_times = []

        async def flaky_operation():
            import time
            start_times.append(time.time())
            attempts.append(1)
            if len(attempts) < 3:
                raise OSError("Temporary error")
            return "success"

        result = await retry_op.execute(flaky_operation)
        assert result == "success"
        assert len(attempts) == 3

        # Check that there was delay between attempts
        # (not perfect test due to jitter, but should catch major issues)
        if len(start_times) >= 2:
            delay1 = start_times[1] - start_times[0]
            assert delay1 >= 0.05  # At least some delay
