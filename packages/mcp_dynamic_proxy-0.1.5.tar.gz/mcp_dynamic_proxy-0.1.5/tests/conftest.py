"""Pytest fixtures for MCP Dynamic Proxy tests."""

import asyncio
from unittest.mock import AsyncMock, Mock
import pytest

from mcp_dynamic_proxy.registry import ServerMetadata, ServerRegistry
from mcp_dynamic_proxy.core.models import PoolConfig, GlobalLimits
from mcp_dynamic_proxy.resilience.circuit_breaker import CircuitBreakerConfig
from mcp_dynamic_proxy.resilience.retry import RetryConfig


@pytest.fixture
def event_loop():
    """Create an instance of the default event loop for the test session."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
def mock_server_metadata():
    """Create mock server metadata for testing."""
    return ServerMetadata(
        id="test-server",
        description="Test MCP server",
        tags=["test"],
        category="test",
        command="echo",
        args=["hello"],
        env=None,
        lazy_load=True,
        cache_ttl=300,
    )


@pytest.fixture
def mock_registry(mock_server_metadata):
    """Create mock server registry."""
    config = {
        "version": "1.0",
        "mcpServers": {
            "test-server": {
                "description": "Test MCP server",
                "tags": ["test"],
                "category": "test",
                "command": "echo",
                "args": ["hello"],
                "lazy_load": True,
                "cache_ttl": 300,
            }
        }
    }
    return ServerRegistry(config)


@pytest.fixture
def pool_config():
    """Create default pool configuration for testing."""
    return PoolConfig(
        min_size=1,
        max_size=3,
        acquire_timeout=5.0,
        idle_timeout=30.0,
        max_queue_size=10,
        start_timeout=10.0,
        tool_timeout=30.0,
        health_check_timeout=2.0,
        health_check_interval=10.0,
        max_lifetime=60.0,
    )


@pytest.fixture
def global_limits():
    """Create default global limits for testing."""
    return GlobalLimits(
        max_total_connections=10,
        max_memory_mb=512,
        max_file_descriptors=100,
    )


@pytest.fixture
def circuit_breaker_config():
    """Create circuit breaker configuration for testing."""
    return CircuitBreakerConfig(
        failure_threshold=3,
        success_threshold=2,
        timeout=5.0,
        half_open_max_requests=1,
    )


@pytest.fixture
def retry_config():
    """Create retry configuration for testing."""
    return RetryConfig(
        max_attempts=2,
        min_wait=0.1,
        max_wait=1.0,
        jitter=0.1,
    )


@pytest.fixture
def mock_mcp_session():
    """Create mock MCP session."""
    session = AsyncMock()
    session.list_tools = AsyncMock(return_value=[
        Mock(
            name="test_tool",
            description="Test tool",
            inputSchema={"type": "object", "properties": {}}
        )
    ])
    session.call_tool = AsyncMock(return_value=Mock(
        content=[{"type": "text", "text": "result"}]
    ))
    return session
