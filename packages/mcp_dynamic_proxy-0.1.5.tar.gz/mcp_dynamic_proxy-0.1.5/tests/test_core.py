"""Basic tests for core modules (connection, pool, manager)."""

import pytest
from unittest.mock import AsyncMock, Mock, patch
from mcp_dynamic_proxy.core.models import (
    ServerStatus,
    CircuitBreakerState,
    WorkerRequest,
    RequestType,
)


class TestConnectionBasics:
    """Basic tests for MCPConnection - testing would require mocking MCP clients."""

    def test_connection_initialization(self, mock_server_metadata, pool_config):
        """Test connection can be initialized."""
        from mcp_dynamic_proxy.core.connection import MCPConnection

        conn = MCPConnection(
            mock_server_metadata,
            start_timeout=pool_config.start_timeout,
            tool_timeout=pool_config.tool_timeout,
            health_check_timeout=pool_config.health_check_timeout,
        )

        assert conn.metadata.id == "test-server"
        assert conn.status == ServerStatus.DISCONNECTED

    def test_worker_request_creation(self):
        """Test creating worker requests."""
        request = WorkerRequest(
            request_type=RequestType.LIST_TOOLS,
        )

        assert request.request_type == RequestType.LIST_TOOLS
        assert request.request_id is not None


class TestPoolBasics:
    """Basic tests for ConnectionPool."""

    @pytest.mark.asyncio
    async def test_pool_initialization(self, mock_server_metadata, pool_config):
        """Test pool initialization."""
        from mcp_dynamic_proxy.core.pool import ConnectionPool

        pool = ConnectionPool(mock_server_metadata, pool_config)

        assert pool.metadata.id == "test-server"
        assert pool.current_size == 0

    @pytest.mark.asyncio
    async def test_pool_stats(self, mock_server_metadata, pool_config):
        """Test pool statistics."""
        from mcp_dynamic_proxy.core.pool import ConnectionPool

        pool = ConnectionPool(mock_server_metadata, pool_config)
        stats = pool.get_stats()

        assert stats.server_id == "test-server"
        assert stats.min_size == pool_config.min_size
        assert stats.max_size == pool_config.max_size
        assert stats.current_size == 0
        assert stats.available == 0


class TestManagerBasics:
    """Basic tests for ConnectionManager."""

    def test_manager_initialization(
        self,
        mock_registry,
        pool_config,
        global_limits,
        circuit_breaker_config,
        retry_config,
    ):
        """Test manager can be initialized."""
        from mcp_dynamic_proxy.core.manager import ConnectionManager

        manager = ConnectionManager(
            mock_registry,
            pool_config,
            global_limits,
            circuit_breaker_config,
            retry_config,
        )

        assert manager.registry == mock_registry
        assert manager.pool_config == pool_config
        assert manager.global_limits == global_limits

    @pytest.mark.asyncio
    async def test_manager_lifecycle(
        self,
        mock_registry,
        pool_config,
        global_limits,
        circuit_breaker_config,
        retry_config,
    ):
        """Test manager start and shutdown."""
        from mcp_dynamic_proxy.core.manager import ConnectionManager

        manager = ConnectionManager(
            mock_registry,
            pool_config,
            global_limits,
            circuit_breaker_config,
            retry_config,
        )

        # Start manager
        await manager.start()
        assert manager._started is True

        # Shutdown manager
        await manager.shutdown()
        assert manager._started is False


class TestCircuitBreakerIntegration:
    """Test circuit breaker integration in core modules."""

    def test_circuit_breaker_state_enum(self):
        """Test circuit breaker state enum values."""
        assert CircuitBreakerState.CLOSED == "closed"
        assert CircuitBreakerState.OPEN == "open"
        assert CircuitBreakerState.HALF_OPEN == "half_open"


class TestModelsValidation:
    """Test Pydantic models validation."""

    def test_pool_config_validation(self, pool_config):
        """Test pool config has valid values."""
        assert pool_config.min_size >= 0
        assert pool_config.max_size >= pool_config.min_size
        assert pool_config.acquire_timeout > 0
        assert pool_config.idle_timeout > 0

    def test_global_limits_validation(self, global_limits):
        """Test global limits have valid values."""
        assert global_limits.max_total_connections > 0
        assert global_limits.max_memory_mb > 0
        assert global_limits.max_file_descriptors > 0

    def test_circuit_breaker_config_validation(self, circuit_breaker_config):
        """Test circuit breaker config validation."""
        assert circuit_breaker_config.failure_threshold > 0
        assert circuit_breaker_config.success_threshold > 0
        assert circuit_breaker_config.timeout > 0
