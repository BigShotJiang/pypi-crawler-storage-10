"""Tests for circuit breaker implementation."""

import pytest
import asyncio
from mcp_dynamic_proxy.resilience.circuit_breaker import (
    CircuitBreaker,
    CircuitBreakerConfig,
    CircuitBreakerError,
)
from mcp_dynamic_proxy.core.models import CircuitBreakerState


class TestCircuitBreaker:
    """Test circuit breaker state transitions and error handling."""

    @pytest.mark.asyncio
    async def test_circuit_breaker_closed_state(self, circuit_breaker_config):
        """Test circuit breaker starts in CLOSED state."""
        cb = CircuitBreaker("test-service", circuit_breaker_config)
        assert cb.state == CircuitBreakerState.CLOSED

    @pytest.mark.asyncio
    async def test_circuit_breaker_success(self, circuit_breaker_config):
        """Test successful operation keeps circuit CLOSED."""
        cb = CircuitBreaker("test-service", circuit_breaker_config)

        async def success_operation():
            return "success"

        result = await cb.call(success_operation)
        assert result == "success"
        assert cb.state == CircuitBreakerState.CLOSED

    @pytest.mark.asyncio
    async def test_circuit_breaker_opens_on_failures(self, circuit_breaker_config):
        """Test circuit opens after threshold failures."""
        cb = CircuitBreaker("test-service", circuit_breaker_config)

        async def failing_operation():
            raise RuntimeError("Operation failed")

        # Fail enough times to open circuit
        for _ in range(circuit_breaker_config.failure_threshold):
            try:
                await cb.call(failing_operation)
            except RuntimeError:
                pass

        assert cb.state == CircuitBreakerState.OPEN

    @pytest.mark.asyncio
    async def test_circuit_breaker_rejects_when_open(self, circuit_breaker_config):
        """Test circuit breaker rejects calls when OPEN."""
        # Use short timeout for test
        config = CircuitBreakerConfig(
            failure_threshold=2,
            timeout=0.1,  # Very short timeout
        )
        cb = CircuitBreaker("test-service", config)

        async def failing_operation():
            raise RuntimeError("Operation failed")

        # Open the circuit
        for _ in range(config.failure_threshold):
            try:
                await cb.call(failing_operation)
            except RuntimeError:
                pass

        # Circuit should be open
        assert cb.state == CircuitBreakerState.OPEN

        # Attempt should be rejected
        with pytest.raises(CircuitBreakerError):
            await cb.call(failing_operation)

    @pytest.mark.asyncio
    async def test_circuit_breaker_half_open_transition(self, circuit_breaker_config):
        """Test circuit transitions to HALF_OPEN after timeout."""
        config = CircuitBreakerConfig(
            failure_threshold=2,
            timeout=0.2,  # Short timeout for test
        )
        cb = CircuitBreaker("test-service", config)

        async def failing_operation():
            raise RuntimeError("Operation failed")

        # Open the circuit
        for _ in range(config.failure_threshold):
            try:
                await cb.call(failing_operation)
            except RuntimeError:
                pass

        assert cb.state == CircuitBreakerState.OPEN

        # Wait for timeout
        await asyncio.sleep(0.3)

        # Next call should transition to HALF_OPEN
        async def success_operation():
            return "success"

        result = await cb.call(success_operation)
        assert result == "success"

    @pytest.mark.asyncio
    async def test_circuit_breaker_closes_after_success(self, circuit_breaker_config):
        """Test circuit closes after success threshold in HALF_OPEN."""
        config = CircuitBreakerConfig(
            failure_threshold=2,
            success_threshold=2,
            timeout=0.1,
        )
        cb = CircuitBreaker("test-service", config)

        async def failing_operation():
            raise RuntimeError("fail")

        async def success_operation():
            return "success"

        # Open circuit
        for _ in range(config.failure_threshold):
            try:
                await cb.call(failing_operation)
            except RuntimeError:
                pass

        assert cb.state == CircuitBreakerState.OPEN

        # Wait for timeout
        await asyncio.sleep(0.2)

        # Success calls to close circuit
        for _ in range(config.success_threshold):
            await cb.call(success_operation)

        # Circuit should be closed now
        assert cb.state == CircuitBreakerState.CLOSED
