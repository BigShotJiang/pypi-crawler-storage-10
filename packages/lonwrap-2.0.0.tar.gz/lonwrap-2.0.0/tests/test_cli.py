"""Tests for the CLI module."""

import json
from pathlib import Path

import geopandas as gpd
import pytest
from click import BadParameter
from click.testing import CliRunner

from lonwrap.cli import main, parse_json_to_dict


@pytest.fixture
def test_data_path() -> Path:
    """Return path to test GeoJSON file."""
    return Path(__file__).parent / 'data' / 'test_poly.geojson'


@pytest.fixture
def runner() -> CliRunner:
    """Return Click CLI test runner."""
    return CliRunner()


class TestParseJsonToDict:
    """Tests for parse_json_to_dict callback function."""

    def test_none_value(self):
        """Test that None value returns None."""
        result = parse_json_to_dict(None, None, None)
        assert result is None

    def test_valid_json(self):
        """Test parsing valid JSON string."""
        json_str = '{"key": "value", "number": 42}'
        result = parse_json_to_dict(None, None, json_str)
        assert result == {'key': 'value', 'number': 42}

    def test_invalid_json(self):
        """Test that invalid JSON raises BadParameter."""
        invalid_json = '{invalid json}'
        with pytest.raises(BadParameter) as exc_info:
            parse_json_to_dict(None, 'test_param', invalid_json)

        assert 'Invalid JSON' in str(exc_info.value)
        # Verify exception chaining (B904 fix)
        assert exc_info.value.__cause__ is not None


class TestCLIBasic:
    """Tests for basic CLI functionality."""

    def test_help_option(self, runner: CliRunner):
        """Test that --help displays help message."""
        result = runner.invoke(main, ['--help'])
        assert result.exit_code == 0
        assert 'Unwraps geometries crossing the 180° meridian' in result.output
        assert 'INPUT' in result.output
        assert 'OUTPUT' in result.output
        assert 'Examples:' in result.output

    def test_help_short_option(self, runner: CliRunner):
        """Test that -h displays help message."""
        result = runner.invoke(main, ['-h'])
        assert result.exit_code == 0
        assert 'Unwraps geometries' in result.output

    def test_version_option(self, runner: CliRunner):
        """Test that --version displays version."""
        result = runner.invoke(main, ['--version'])
        assert result.exit_code == 0

    def test_missing_required_args(self, runner: CliRunner):
        """Test that missing required arguments shows error."""
        result = runner.invoke(main, [])
        assert result.exit_code != 0
        assert 'Missing argument INPUT' in result.output

    def test_missing_output_arg(self, runner: CliRunner, test_data_path: Path):
        """Test that missing OUTPUT argument shows error."""
        result = runner.invoke(main, [str(test_data_path)])
        assert result.exit_code != 0
        assert 'Missing argument OUTPUT' in result.output


class TestCLIFileProcessing:
    """Tests for CLI file processing functionality."""

    def test_basic_processing(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test basic file processing with positional arguments."""
        output_path = tmp_path / 'output.geojson'

        result = runner.invoke(
            main,
            [str(test_data_path), str(output_path)],
        )

        assert result.exit_code == 0, f'CLI failed: {result.output}'
        assert output_path.exists(), 'Output file was not created'
        assert 'Successfully processed' in result.output

        # Verify output is valid GeoJSON
        gdf = gpd.read_file(output_path)
        assert not gdf.empty
        assert gdf.geometry.is_valid.all()

    def test_with_unwrap_to_east(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test processing with --unwrap-to east."""
        output_path = tmp_path / 'output_east.geojson'

        result = runner.invoke(
            main,
            [
                str(test_data_path),
                str(output_path),
                '--unwrap-to',
                'east',
            ],
        )

        assert result.exit_code == 0
        assert output_path.exists()

        gdf = gpd.read_file(output_path)
        assert gdf.geometry.is_valid.all()

    def test_with_unwrap_to_west(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test processing with --unwrap-to west."""
        output_path = tmp_path / 'output_west.geojson'

        result = runner.invoke(
            main,
            [
                str(test_data_path),
                str(output_path),
                '--unwrap-to',
                'west',
            ],
        )

        assert result.exit_code == 0
        assert output_path.exists()

    def test_with_unwrap_to_centroid(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test processing with --unwrap-to centroid."""
        output_path = tmp_path / 'output_centroid.geojson'

        result = runner.invoke(
            main,
            [
                str(test_data_path),
                str(output_path),
                '--unwrap-to',
                'centroid',
            ],
        )

        assert result.exit_code == 0
        assert output_path.exists()

    def test_with_custom_gap_threshold(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test processing with custom gap threshold."""
        output_path = tmp_path / 'output_gap.geojson'

        result = runner.invoke(
            main,
            [
                str(test_data_path),
                str(output_path),
                '--gap-threshold',
                '150.0',
            ],
        )

        assert result.exit_code == 0
        assert output_path.exists()

    def test_with_custom_geom_col(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test processing with custom geometry column name."""
        output_path = tmp_path / 'output_geom.geojson'

        result = runner.invoke(
            main,
            [
                str(test_data_path),
                str(output_path),
                '--geom-col',
                'geometry',
            ],
        )

        assert result.exit_code == 0
        assert output_path.exists()

    def test_positional_args_with_options(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test mixing positional arguments with options."""
        output_path = tmp_path / 'output_mixed.geojson'

        result = runner.invoke(
            main,
            [
                '--unwrap-to',
                'west',
                str(test_data_path),
                str(output_path),
                '--gap-threshold',
                '170',
            ],
        )

        assert result.exit_code == 0
        assert output_path.exists()


class TestCLINewFeatures:
    """Tests for new CLI features (verbose, dry-run)."""

    def test_verbose_flag(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test verbose mode shows detailed logs."""
        output_path = tmp_path / 'output_verbose.geojson'

        result = runner.invoke(
            main,
            [
                str(test_data_path),
                str(output_path),
                '--verbose',
            ],
        )

        assert result.exit_code == 0
        # Check for logging output (logged to stderr, mixed into output)
        output_text = result.output + (result.stderr or '')
        assert 'Reading input file' in output_text
        assert 'Loaded' in output_text
        assert 'features' in output_text

    def test_verbose_short_flag(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test verbose mode with short -v flag."""
        output_path = tmp_path / 'output_verbose_short.geojson'

        result = runner.invoke(
            main,
            [
                str(test_data_path),
                str(output_path),
                '-v',
            ],
        )

        assert result.exit_code == 0
        output_text = result.output + (result.stderr or '')
        assert 'Reading input file' in output_text

    def test_dry_run_mode(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test dry-run mode doesn't write output file."""
        output_path = tmp_path / 'output_dryrun.geojson'

        result = runner.invoke(
            main,
            [
                str(test_data_path),
                str(output_path),
                '--dry-run',
            ],
        )

        assert result.exit_code == 0
        # Output file should NOT exist in dry-run mode
        assert not output_path.exists()
        # Check for dry-run message
        assert 'DRY RUN MODE' in result.output
        assert 'No files were written' in result.output

    def test_dry_run_with_verbose(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test dry-run mode with verbose output."""
        output_path = tmp_path / 'output_dryrun_verbose.geojson'

        result = runner.invoke(
            main,
            [
                str(test_data_path),
                str(output_path),
                '--dry-run',
                '--verbose',
            ],
        )

        assert result.exit_code == 0
        assert not output_path.exists()
        output_text = result.output + (result.stderr or '')
        assert 'DRY RUN MODE' in output_text
        assert 'Reading input file' in output_text
        assert 'Features:' in output_text

    def test_success_summary(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test that success summary is displayed."""
        output_path = tmp_path / 'output_summary.geojson'

        result = runner.invoke(
            main,
            [str(test_data_path), str(output_path)],
        )

        assert result.exit_code == 0
        # Check for success message elements
        assert '✓ Successfully processed' in result.output
        assert 'Features:' in result.output
        assert 'Geometries unwrapped:' in result.output
        assert 'CRS:' in result.output
        assert 'Output size:' in result.output


class TestCLIOptions:
    """Tests for CLI options like mode, crs, engine, metadata."""

    def test_mode_write(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test write mode (default)."""
        output_path = tmp_path / 'output_mode_w.geojson'

        result = runner.invoke(
            main,
            [
                str(test_data_path),
                str(output_path),
                '--mode',
                'w',
            ],
        )

        assert result.exit_code == 0
        assert output_path.exists()

    def test_with_crs(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test processing with explicit CRS using fiona engine."""
        output_path = tmp_path / 'output_crs.geojson'

        # CRS parameter requires fiona engine (not supported by pyogrio)
        result = runner.invoke(
            main,
            [
                str(test_data_path),
                str(output_path),
                '--engine',
                'fiona',
                '--crs',
                'EPSG:4326',
            ],
        )

        # Fiona might not be installed, so accept either success or error
        if result.exit_code != 0:
            error_text = str(result.exception) + result.output
            assert 'fiona' in error_text.lower()
        else:
            assert output_path.exists()
            gdf = gpd.read_file(output_path)
            assert gdf.crs is not None

    def test_with_metadata_json(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test processing with metadata as JSON string."""
        output_path = tmp_path / 'output_metadata.gpkg'
        metadata = {'title': 'Test Data', 'author': 'Test'}

        result = runner.invoke(
            main,
            [
                str(test_data_path),
                str(output_path),
                '--metadata',
                json.dumps(metadata),
            ],
        )

        # GPKG format might not be available
        assert result.exit_code in [0, 1]

    def test_with_kwargs_json(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test that kwargs option can be parsed from JSON string."""
        output_path = tmp_path / 'output_kwargs.geojson'
        kwargs = {}  # Empty dict should work without errors

        result = runner.invoke(
            main,
            [
                str(test_data_path),
                str(output_path),
                '--kwargs',
                json.dumps(kwargs),
            ],
        )

        assert result.exit_code == 0
        assert output_path.exists()


class TestCLIBackwardCompatibility:
    """Tests for backward compatibility with legacy options."""

    def test_legacy_data_output_options(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test that legacy --data and --output options still work."""
        output_path = tmp_path / 'output_legacy.geojson'

        result = runner.invoke(
            main,
            [
                '--data',
                str(test_data_path),
                '--output',
                str(output_path),
            ],
        )

        assert result.exit_code == 0
        assert output_path.exists()

    def test_legacy_unwrap_to_option(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test that legacy --unwrap-to option still works."""
        output_path = tmp_path / 'output_legacy_dir.geojson'

        result = runner.invoke(
            main,
            [
                str(test_data_path),
                str(output_path),
                '--unwrap-to',
                'west',
            ],
        )

        assert result.exit_code == 0
        assert output_path.exists()


class TestCLIErrorHandling:
    """Tests for CLI error handling."""

    def test_nonexistent_input_file(self, runner: CliRunner, tmp_path: Path):
        """Test that nonexistent input file raises error."""
        nonexistent = tmp_path / 'nonexistent.geojson'
        output_path = tmp_path / 'output.geojson'

        result = runner.invoke(
            main,
            [str(nonexistent), str(output_path)],
        )

        assert result.exit_code != 0
        # Click will raise error about path not existing
        assert 'does not exist' in result.output.lower()

    def test_invalid_unwrap_to(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test that invalid --unwrap-to value raises error."""
        output_path = tmp_path / 'output.geojson'

        result = runner.invoke(
            main,
            [
                str(test_data_path),
                str(output_path),
                '--unwrap-to',
                'invalid',
            ],
        )

        assert result.exit_code != 0
        assert 'Invalid value' in result.output

    def test_invalid_mode(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test that invalid mode value raises error."""
        output_path = tmp_path / 'output.geojson'

        result = runner.invoke(
            main,
            [
                str(test_data_path),
                str(output_path),
                '--mode',
                'x',  # Invalid mode
            ],
        )

        assert result.exit_code != 0
        assert 'Invalid value' in result.output

    def test_invalid_metadata_json(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test that invalid JSON in metadata raises error."""
        output_path = tmp_path / 'output.geojson'

        result = runner.invoke(
            main,
            [
                str(test_data_path),
                str(output_path),
                '--metadata',
                '{invalid json}',
            ],
        )

        assert result.exit_code != 0
        assert 'Invalid JSON' in result.output

    def test_invalid_kwargs_json(
        self, runner: CliRunner, test_data_path: Path, tmp_path: Path
    ):
        """Test that invalid JSON in kwargs raises error."""
        output_path = tmp_path / 'output.geojson'

        result = runner.invoke(
            main,
            [
                str(test_data_path),
                str(output_path),
                '--kwargs',
                'not a json',
            ],
        )

        assert result.exit_code != 0
        assert 'Invalid JSON' in result.output
