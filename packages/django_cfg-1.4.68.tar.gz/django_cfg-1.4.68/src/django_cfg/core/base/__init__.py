"""Base configuration models for django-cfg."""

from .config_model import DjangoConfig

__all__ = ["DjangoConfig"]
