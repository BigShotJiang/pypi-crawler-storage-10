"""TypeScript thin wrapper generator."""

from .generator import TypeScriptThinGenerator

__all__ = ["TypeScriptThinGenerator"]
