import atexit
import datetime
import subprocess
import threading
import time

import ntplib

from dongle.runtime.runtime_hooks import RuntimeHook


class RestrictHook(RuntimeHook):
    @classmethod
    def init_license(cls, config, license):
        if "expire" in license.options:
            try:
                ntp_client = ntplib.NTPClient()
                ntp_stats = ntp_client.request("pool.ntp.org", version=3)
            except OSError as e:
                raise RuntimeError("Could not verify time.") from e

            if ntp_stats.offset > 24 * 60 * 60:
                raise RuntimeError("Time offset to big.")

            expire_time = time.strptime(license.options["expire"], "%Y-%m-%d")
            if time.mktime(expire_time) < ntp_stats.tx_time:
                raise RuntimeError("License expired.")

        if "hwid" in license.options:
            result = subprocess.check_output("wmic csproduct get uuid", encoding="ascii")
            hwid, *_ = [l.strip() for l in result.splitlines() if l and l.strip() != "UUID"]

            if hwid != license.options["hwid"]:
                raise RuntimeError("License not valid on this host.")

    @classmethod
    def init_dongle(cls, options, package_dongle):
        if "time_limit" in options:
            tm = time.strptime(options["time_limit"], "%H:%M:%S")
            time_delta = datetime.timedelta(hours=tm.tm_hour, minutes=tm.tm_min, seconds=tm.tm_sec)
            time_limit = datetime.datetime.now() + time_delta

            def check_time_limit():
                if datetime.datetime.now() > time_limit:
                    raise RuntimeError("Time limit reached.")

            package_dongle.watchdog.add_check(check_time_limit)

__signature__ = "MGUCMQDkwFVRQLT/VBFQGbX6rE8TANWUhVe0oyKEIL9qd2K06AtxOIodUweCIOujRQJlpbQCMEZzsVTgis4rj7SmMO0elZVMNPkGgGzoKUK+P9195HV5HBco+iP7JZ9LFhIpZ5Y4pw=="
