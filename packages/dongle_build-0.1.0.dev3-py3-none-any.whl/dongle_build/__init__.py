# This module is encrypted.
import dongle


try:
    dongle.init_from(__name__)
    """
-----BEGIN ENCRYPTED MODULE-----
Module: dongle_build.__init__
Build: 28dcaefe-5a5ab745-1496b858
Nonce: NWIkTJnYmW4JtTL7

SdBZ5/e8zwoLiHCEADRELDEq0YA3dZrWkYNyWWu5U+PS2HK6eKWBc+Qd0JYzToGfmao/B4P1NoMpFUvEWauZY29f1xnIogMPeVzmVCikE8j9N7xPI4aIjpGPcCNWKODiDUHe5IpI4Jg0puI4Da+UogNF75bGdEUJgz68uwsiy8DbGWT19AfzsuGY/nBgoZqsgMSdIBQHRlc0rKZdvtRfViyhZMAUJgediWb/LwvRqGnk
-----END ENCRYPTED MODULE-----
    """

except dongle.DongleReady as e:
    e.reload()
