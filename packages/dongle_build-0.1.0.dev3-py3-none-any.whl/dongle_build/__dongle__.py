# This package is controlled by dongle license manager.

vendor_name = "led-inc.eu"
build_name = "dongle-build-dev"
app_name = "dongle-build"
app_key = b"""
-----BEGIN PUBLIC KEY-----
MHYwEAYHKoZIzj0CAQYFK4EEACIDYgAEF6Ewv3VSSutqNfJEAAei8Ib4dQgJwVhb
etVrsVJREthkNY85mFsE8LWrTV9kFfSpe9k0bJlx2liezyaUM7gMxh3wavJ/oMHR
MiX4x6yf7CqFO3nAHFsPrIDZOo1DAL05
-----END PUBLIC KEY-----

"""

hooks = [
    {'scope': 'api', 'use': 'dongle.optional'},
    {'scope': 'dongle', 'use': 'dongle.runtime', 'encrypted': ['dongle_build']},
]

__signature__ = "MGUCMH+wqj5NQ/Qj4n+L0vCq3AWzlSSLcEwzWih0Bt9q6gd2ypFe3t0aOt9IuFlOiqe6CgIxAPRqp9D5KByE+k/78B5AFtl6r0u1tfXnU+ThwDe0361YiVJl7tsbCCR5EJ3IHe5GQQ=="
