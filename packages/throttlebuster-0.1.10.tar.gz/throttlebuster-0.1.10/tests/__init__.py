FILE_URL = "http://localhost:8888/test.1.opus"
DOWNLOAD_DIR = "/tmp/"
PART_DIR = DOWNLOAD_DIR
