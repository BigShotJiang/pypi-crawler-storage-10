GET_OTP = "get-otp"
VALIDATE = "validate"
GENERATE_SECRET = "generate-secret"
GENERATE_SECRET_QR_CODE = "generate-secret-qr-code"
