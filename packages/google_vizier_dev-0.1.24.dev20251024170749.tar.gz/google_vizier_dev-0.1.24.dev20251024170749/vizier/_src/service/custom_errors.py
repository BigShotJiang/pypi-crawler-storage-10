# Copyright 2024 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

"""Custom Errors used in service."""


class AlreadyExistsError(ValueError):
  """The resource key already exists in the database."""

  pass


class NotFoundError(KeyError):
  """The resource key does not exist in the database."""

  pass


class ImmutableStudyError(ValueError):
  """The study is now immutable and cannot be modified."""

  pass


class ImmutableTrialError(ValueError):
  """The trial is now immutable and cannot be modified."""

  pass
