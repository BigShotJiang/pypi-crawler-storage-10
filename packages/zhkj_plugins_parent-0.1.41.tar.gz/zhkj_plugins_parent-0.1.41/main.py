import sys

from zhkj_plugins import PluginManager
from zhkj_plugins.exceptions import PluginManagerError


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("插件管理器使用方法:")
        print("  python main.py install <插件名> [下载地址] - 安装指定插件")
        print("  python main.py install-all                - 安装所有插件")
        print("  python main.py start <插件名>             - 启动指定插件")
        print("  python main.py stop <插件名>              - 停止指定插件")
        print("  python main.py uninstall <插件名>         - 卸载指定插件")
        print("  python main.py list                       - 列出所有插件状态")
        print("  python main.py status <插件名>            - 查看单个插件状态")
        print("  python main.py get-port <插件名>          - 获取服务插件端口")
        print("  python main.py check-updates              - 检查所有插件更新")
        print("  python main.py update <插件名>            - 更新指定插件")
        print("  python main.py auto-update                - 自动更新所有插件")
        print("  python main.py is-installed <插件名>      - 检查插件是否已安装")
        print("  python main.py refresh-version-checks     - 刷新版本检查配置")
        return

    try:
        # 初始化管理器（默认加载当前目录的 config.yaml）
        manager = PluginManager()

        command = sys.argv[1].lower()
        plugin_name = sys.argv[2] if len(sys.argv) > 2 else None
        url = sys.argv[3] if len(sys.argv) > 3 else None

        if command == "install" and plugin_name:
            success = manager.install_plugin(plugin_name, url)
            print(f"安装结果: {'成功' if success else '失败'}")
        elif command == "install-all":
            results = manager.install_all_plugins()
            for name, success in results.items():
                print(f"{name}: {'成功' if success else '失败'}")
        elif command == "start" and plugin_name:
            success = manager.start_plugin(plugin_name)
            print(f"启动结果: {'成功' if success else '失败'}")
        elif command == "stop" and plugin_name:
            success = manager.stop_plugin(plugin_name)
            print(f"停止结果: {'成功' if success else '失败'}")
        elif command == "uninstall" and plugin_name:
            success = manager.uninstall_plugin(plugin_name)
            print(f"卸载结果: {'成功' if success else '失败'}")
        elif command == "list":
            manager.print_plugin_list()
        elif command == "status" and plugin_name:
            status = "运行中" if manager.is_plugin_running(plugin_name) else "未运行"
            port = manager.get_service_port(plugin_name)
            port_info = f", 端口: {port}" if port else ""
            print(f"{plugin_name} 状态: {status}{port_info}")
        elif command == "get-port" and plugin_name:
            port = manager.get_service_port(plugin_name)
            if port:
                print(f"{plugin_name} 端口: {port}")
            else:
                print(f"无法获取 {plugin_name} 的端口")
        elif command == "check-updates":
            updates = manager.check_all_updates()
            if updates:
                print("\n可用的更新:")
                for plugin_name, version_info in updates.items():
                    print(f"  {plugin_name}: {version_info.version} - {version_info.release_notes}")
            else:
                print("所有插件都是最新版本")
        elif command == "update" and plugin_name:
            has_update, version_info = manager.check_plugin_update(plugin_name)
            if has_update and version_info:
                print(f"发现新版本: {version_info.version}")
                print(f"更新说明: {version_info.release_notes}")
                confirm = input("是否更新? (y/N): ")
                if confirm.lower() == 'y':
                    success = manager.update_plugin(plugin_name, version_info)
                    print(f"更新结果: {'成功' if success else '失败'}")
                else:
                    print("取消更新")
            else:
                print(f"插件 {plugin_name} 已是最新版本")
        elif command == "auto-update":
            print("开始自动更新...")
            results = manager.auto_update_plugins()
            if results:
                print("\n自动更新结果:")
                for plugin_name, success in results.items():
                    status = "成功" if success else "失败"
                    print(f"  {plugin_name}: {status}")
            else:
                print("没有需要更新的插件")
        elif command == "refresh-version-checks":
            manager._version_checks_cache = None
            manager._version_checks_last_fetch = 0
            print("版本检查配置已刷新")
        elif command == "is-installed" and plugin_name:
            installed = manager.is_plugin_installed(plugin_name)
            status = "已安装" if installed else "未安装"
            print(f"插件 {plugin_name} {status}")
        else:
            print("未知命令")
    except PluginManagerError as e:
        print(f"插件管理器错误: {str(e)}")
    except Exception as e:
        print(f"执行失败: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    # 需安装依赖：pip install psutil pyyaml requests
    main()