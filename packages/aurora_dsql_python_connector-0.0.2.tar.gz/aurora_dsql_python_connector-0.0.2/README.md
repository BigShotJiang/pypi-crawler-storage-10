# Aurora DSQL Connector for Python

This package is parked by Amazon Web Services. 
An open source package will be made available at https://github.com/awslabs/aurora-dsql-python-connector.
Stay tuned for updates! 
