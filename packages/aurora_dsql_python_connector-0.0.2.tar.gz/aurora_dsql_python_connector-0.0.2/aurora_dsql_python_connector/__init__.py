# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with
# the License. A copy of the License is located at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# or in the "license" file accompanying this file.
# This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
# CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions
# and limitations under the License.

__version__ = '0.0.2'

raise ImportError(
    """
    This package is parked by Amazon Web Services. 
    An open source package will be made available at https://github.com/awslabs/aurora-dsql-python-connector.
    Stay tuned for updates! 
    """
)
