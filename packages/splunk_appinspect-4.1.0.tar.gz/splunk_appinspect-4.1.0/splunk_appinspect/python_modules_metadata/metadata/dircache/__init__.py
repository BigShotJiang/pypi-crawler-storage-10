"""
manipulate cache files/directories
"""
