"""
interfaces that are unique to the Unix operating system, or in some cases to some or many variants of it.
"""

from splunk_appinspect.python_modules_metadata.metadata_common.metadata_consts import TagConsts
from splunk_appinspect.python_modules_metadata.metadata_common.metadata_decorator import tags


@tags(TagConsts.UNIX_SPECIFIC_SERVICES)
def open():
    """
    Create a new posixfile object
    """
    pass


@tags(TagConsts.UNIX_SPECIFIC_SERVICES)
def fileopen():
    """
    Create a new posixfile object
    """
    pass
