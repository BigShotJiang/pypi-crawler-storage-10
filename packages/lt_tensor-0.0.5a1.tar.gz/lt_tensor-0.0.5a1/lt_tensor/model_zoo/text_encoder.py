__all__ = ["TextEmbeddings", "TextEncoder", "TextEncoderConfig"]

from lt_utils.common import *
from lt_tensor.common import *
from lt_tensor.activations_utils import get_activation, ACTIV_NAMES_TP

from lt_tensor.model_zoo.pos_encoders import (
    RotaryPositionalEncoding,
    SinusoidalPositionalEncoding,
    RotaryPositionalEncoding,
)
from lt_tensor.model_zoo.conv_norm import Conv1dNorm, ConvNormConfig


class TextEmbeddings(Model):
    def __init__(
        self,
        vocab_size: int,
        d_model: int = 256,
        position_encoder_type: Optional[
            Literal[
                "absolute",
                "sinusoidal",
                "rotary",
            ]
        ] = "rotary",
        max_seq_len: int = 2048,
        rotary_base: int = 10000,
        rotary_dim: Optional[int] = None,
        rotary_reshape: bool = True,
        padding_idx: Optional[int] = None,
        transposed_output: bool = False,
        *,
        max_norm: Optional[float] = None,
        norm_type: float = 2,
        scale_grad_by_freq: bool = False,
        sparse: bool = False,
    ):
        super().__init__()
        self.embedding = nn.Embedding(
            vocab_size,
            d_model,
            padding_idx=padding_idx,
            max_norm=max_norm,
            norm_type=norm_type,
            scale_grad_by_freq=scale_grad_by_freq,
            sparse=sparse,
        )
        self.position_encoder_type: Optional[
            Literal["absolute", "sinusoidal", "rotary"]
        ] = position_encoder_type
        if self.position_encoder_type is not None:
            if position_encoder_type == "absolute":
                self.pos_emb = nn.Embedding(max_seq_len, d_model)
            elif position_encoder_type == "rotary":
                self.pos_emb = RotaryPositionalEncoding(
                    d_model=d_model,
                    rotary_dim=rotary_dim,
                    base=rotary_base,
                    reshape_output=rotary_reshape,
                )
            else:

                self.pos_emb = SinusoidalPositionalEncoding(
                    d_model=d_model,
                    base=rotary_base or max_seq_len,
                )
        else:
            self.pos_emb = nn.Identity()

        self.transposed_output = transposed_output

    def forward(self, input_ids: Tensor, position_ids: Optional[Tensor] = None):
        """input_ids (long) =  [B, T]"""
        B, T = input_ids.shape
        inputs_embeds = self.embedding(input_ids)  # [B, T, emb]
        if self.position_encoder_type == "absolute":
            if position_ids is None:
                position_ids = (
                    torch.arange(T, device=inputs_embeds.device, dtype=torch.long)
                    .unsqueeze(0)
                    .expand(B, T)
                )
            else:
                position_ids = position_ids.long()
            emb = inputs_embeds + self.pos_emb(position_ids)
        else:
            emb = self.pos_emb(inputs_embeds)

        if self.transposed_output:
            return emb.transpose(-1, -2)
        return emb


class TextEncoderConfig(ModelConfig):
    vocab_size: int = 0
    d_model: int = 256
    cnn_config = ConvNormConfig(
        channels=[256, 256, 384, 512, 256],
        kernel_size=[3, 3, 3, 5, 7],
        dilation=[1, 1, 1, 1, 1],
        stride=[1, 1, 1, 1, 1],
        groups=[1, 1, 1, 1, 1],
        padding=[1, 1, 1, 2, 3],
        activation="gelu",
        norm_bias=False,
    )
    n_layers: int = 2
    lstm_dropout: float = 0.01
    cnn_dropout: float = 0.1
    padding_id: int = 0
    position_encoder_type: Optional[
        Literal[
            "absolute",
            "sinusoidal",
            "rotary",
        ]
    ] = "rotary"
    apply_mask_at_output: bool = True
    rotary_base: int = 10000
    rotary_dim: Optional[int] = None
    mask_value: Number = 0.0
    activation: ACTIV_NAMES_TP = "silu"
    activation_kwargs: Dict[str, Any] = dict()

    def __init__(
        self,
        vocab_size: int = 0,
        d_model: int = 256,
        cnn_config: Union[ConvNormConfig, dict] = ConvNormConfig(
            channels=[256, 256, 384, 512, 256],
            kernel_size=[3, 3, 3, 5, 7],
            dilation=[1, 1, 1, 1, 1],
            stride=[1, 1, 1, 1, 1],
            groups=[1, 1, 1, 1, 1],
            padding=[1, 1, 1, 2, 3],
            activation="gelu",
            norm_bias=False,
        ),
        n_layers: int = 2,
        dropout: float = 0.1,
        padding_id: int = 0,
        position_encoder_type: Optional[
            Literal[
                "absolute",
                "sinusoidal",
                "rotary",
            ]
        ] = "rotary",
        apply_mask_at_output: bool = True,
        rotary_base: int = 10000,
        rotary_dim: Optional[int] = None,
        mask_value: Number = 0.0,
        activation: ACTIV_NAMES_TP = "silu",
        activation_kwargs: Dict[str, Any] = dict(),
    ):
        if not isinstance(cnn_config, (ConvNormConfig, ModelConfig, dict)):
            raise ValueError(
                f"Invalid `cnn_config` {cnn_config}. Use either ConvNormConfig or a dictionary."
            )
        settings = dict(
            vocab_size=vocab_size,
            d_model=d_model,
            cnn_config=cnn_config,
            n_layers=n_layers,
            dropout=dropout,
            padding_id=padding_id,
            position_encoder_type=position_encoder_type,
            apply_mask_at_output=apply_mask_at_output,
            rotary_base=rotary_base,
            rotary_dim=rotary_dim,
            mask_value=mask_value,
            activation=activation,
            activation_kwargs=activation_kwargs,
        )
        super().__init__(**settings)

    def post_process(self):
        if not isinstance(self.cnn_config, (ConvNormConfig, ModelConfig)):
            self.cnn_config = ConvNormConfig(**self.cnn_config)
        items_list = [
            self.cnn_config.channels,
            self.cnn_config.kernel_size,
            self.cnn_config.dilation,
            self.cnn_config.stride,
            self.cnn_config.groups,
            self.cnn_config.padding,
        ]
        sizes = [len(x) for x in items_list]
        # considering that the lists contains 5 items each, we will
        # crop or pad if they are either smaller or larger than 5, but not both.
        min_sizes = min(sizes)
        max_sizes = max(sizes)
        if not max_sizes == 5 or min_sizes == 5:
            if not (max_sizes > 5 and min_sizes < 5):
                if max_sizes > 5:
                    self.cnn_config.fix_lists("pad_smaller")
                else:
                    self.cnn_config.fix_lists("crop_larger")
        self.cnn_config.dropout = self.cnn_dropout


class TextEncoder(Model):
    def __init__(self, config: Union[TextEncoderConfig, Dict[str, Any]]):
        super().__init__()
        if not isinstance(config, (TextEncoderConfig, ModelConfig)):
            assert isinstance(
                config, dict
            ), "Invalid type for config: {config}. use either a dictionary or TextEncoderConfig or a ModelConfig"
            config = TextEncoderConfig(**config)
        assert config.vocab_size > 0, "Vocab size cannot be zero or negative values!"
        self.cfg = config
        
        self.embedding = TextEmbeddings(
            vocab_size=config.vocab_size,
            d_model=config.d_model,
            position_encoder_type=config.position_encoder_type,
            padding_idx=config.padding_id,
            rotary_reshape=True,
            rotary_base=config.rotary_base,
            rotary_dim=config.rotary_dim,
        )
        self.mask_value = config.mask_value
        self.cnn = nn.ModuleList()

        self.cnn_cfg = config.cnn_config
        self.apply_mask_at_output = config.apply_mask_at_output

        self.cnn_layers = len(config.cnn_config)
        for i in range(self.cnn_layers):
            self.cnn.append(Conv1dNorm(self.cnn_cfg, config.d_model, i))

        self.rnn = nn.LSTM(
            config.cnn_config.channels[-1],
            config.d_model,
            num_layers=config.n_layers,
            dropout=0 if config.n_layers < 2 else config.lstm_dropout,
            batch_first=True,
            bidirectional=True,
        )
        self.proj_out = nn.Sequential(
            get_activation(config.activation, **config.activation_kwargs),
            nn.Linear(config.d_model * 2, config.d_model),
        )

    def rnn_pass(
        self,
        x: Tensor,
        B: int,
        T: int,
        lengths: List[int] = None,
        mask: Optional[Tensor] = None,
    ):
        if mask is not None:
            x = x.transpose(-1, -2)
            x.masked_fill_(mask, self.mask_value)
            x = x.transpose(-1, -2)
        if lengths is None:
            lengths = [T for _ in range(B)]
        elif isinstance(lengths, Tensor):
            lengths = lengths.clone().detach().cpu().long().tolist()

        packed = nn.utils.rnn.pack_padded_sequence(
            x,
            lengths,
            batch_first=True,
            enforce_sorted=False,
        )
        self.rnn.flatten_parameters()
        out_packed = self.rnn(packed)[0]
        x = nn.utils.rnn.pad_packed_sequence(out_packed, batch_first=True)[0]
        return x

    def cnn_pass(self, x: Tensor, mask: Optional[Tensor] = None):
        x = x.transpose(-1, -2)  # [B, emb, T]
        for c in self.cnn:
            x = c(x, mask)
        x = x.transpose(-1, -2)
        return x

    def forward(
        self,
        input_ids: Tensor,
        lengths: List[int] = None,
        mask: Optional[Tensor] = None,
        return_dict: bool = True,
    ):
        B, T = input_ids.size(0), input_ids.size(-1)
        emb: Tensor = self.embedding(input_ids.view(B, T))  # [B, T, emb]
        x = self.cnn_pass(emb, mask)
        x = self.rnn_pass(x, B, T, lengths, mask)

        x = self.proj_out(x)
        x = x.transpose(-1, -2)

        if mask is not None and self.apply_mask_at_output:
            x.masked_fill_(mask, self.mask_value)

        if not return_dict:
            return x, emb
        return dict(text=x, emb=emb)
