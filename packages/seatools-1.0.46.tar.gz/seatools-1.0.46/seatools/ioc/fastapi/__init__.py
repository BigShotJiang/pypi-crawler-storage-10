from .adapter import FastAutowired
