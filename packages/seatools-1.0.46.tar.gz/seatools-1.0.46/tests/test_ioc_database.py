import datetime
from sqlalchemy.orm import Session

from sqlalchemy import BigInteger, String, DateTime, select, update, delete
from sqlalchemy.orm import Mapped, mapped_column
from seatools.sqlalchemy import Base
from seatools.ioc import Bean, run
from seatools.ioc.database import DatabaseConfig
from seatools.sqlalchemy import SqlAlchemyClient
from seatools.ioc.sqlalchemy import new_session, auto_session


class User(Base):
    __tablename__ = 'user'

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    create_time: Mapped[datetime.datetime] = mapped_column(DateTime)




def test_ioc_database():
    cfg = DatabaseConfig(
        host='localhost',
        port=6379,
        password='123456',
        database=0,
        driver='redis'
    )
    print(cfg.render_to_string())
    print(cfg.render_to_string(False))


@Bean(name="s1", primary=True)
def sqlalchemy_client() -> SqlAlchemyClient:
    return SqlAlchemyClient(
        url='sqlite:///tmp/example.db'
    )


@Bean(name="s2")
def sqlalchemy_client2() -> SqlAlchemyClient:
    return SqlAlchemyClient(
        url='sqlite:///tmp/example2.db'
    )


@auto_session
def save_auto_session(session: Session) -> int:
    session.add(User(id=2, name="test example", create_time=datetime.datetime.now()))
    return id(session)

@auto_session
def do_auto_session(session: Session):
    session_id = save_auto_session()
    assert id(session) == session_id
    u = session.query(User).where(User.id == 2).first()
    assert u and u.name == "test example"

def test_auto_session():
    run(scan_package_names=['tests.test_ioc_database'])
    do_auto_session()

@auto_session("s1")
@auto_session("s2", field_name="session2")
def save_mult_auto_session(session: Session, session2: Session):
    u1 = User(id=1, name="example1", create_time=datetime.datetime.now())
    u2 = User(id=1, name="example2", create_time=datetime.datetime.now())
    session.add(u1)
    session2.add(u2)
    return id(session), id(session2)


@auto_session("s1")
@auto_session("s2", field_name="session2")
def do_mult_auto_session(session: Session, session2: Session):
    session_id, session2_id = save_mult_auto_session()
    assert id(session) == session_id
    assert id(session2) == session2_id

    u1 = session.query(User).where(User.name == "example1").first()
    u2 = session2.query(User).where(User.name == "example2").first()
    assert u1 and u1.name == "example1"
    assert u2 and u2.name == "example2"
    not_u1 = session.query(User).where(User.name == "example2").first()
    not_u2 = session2.query(User).where(User.name == "example1").first()
    assert not not_u1
    assert not not_u2


def test_mult_auto_session():
    run(scan_package_names=['tests.test_ioc_database'])
    do_mult_auto_session()




def test_sqlalchemy():
    run(scan_package_names=['tests.test_ioc_database'])


