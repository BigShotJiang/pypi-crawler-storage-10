"""Tests for rivet-di."""
