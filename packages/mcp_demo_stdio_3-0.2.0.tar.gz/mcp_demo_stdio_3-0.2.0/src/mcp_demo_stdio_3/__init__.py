from service import mcp

def main() -> None:
    mcp.run(transport='stdio')

