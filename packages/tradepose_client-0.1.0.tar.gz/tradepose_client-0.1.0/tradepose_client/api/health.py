"""健康檢查 API"""

from typing import Dict
import requests


class HealthAPI:
    """健康檢查 API Mixin"""

    def health(self) -> Dict:
        """健康檢查 - 簡單的存活探測

        Returns:
            健康狀態 {"status": "ok"}

        Example:
            >>> status = client.health()
            >>> print(status)  # {"status": "ok"}
        """
        response = requests.get(
            f"{self.api_url}/health",
            headers=self._get_headers()
        )
        response.raise_for_status()
        return response.json()

    def readiness(self) -> Dict:
        """就緒檢查 - 檢查所有依賴是否可用

        Returns:
            就緒狀態

        Raises:
            requests.HTTPError: 503 (Service not ready)

        Example:
            >>> try:
            ...     status = client.readiness()
            ...     print("Service is ready")
            ... except requests.HTTPError as e:
            ...     if e.response.status_code == 503:
            ...         print("Service not ready yet")
        """
        response = requests.get(
            f"{self.api_url}/ready",
            headers=self._get_headers()
        )
        response.raise_for_status()
        return response.json()

    def system_status(self) -> Dict:
        """獲取完整系統狀態

        Returns:
            系統狀態信息（包括緩存、策略等統計）

        Raises:
            requests.HTTPError: 500

        Example:
            >>> status = client.system_status()
            >>> print(f"Strategies: {status.get('strategies_count', 0)}")
            >>> print(f"Cache usage: {status.get('cache_info', {})}")
        """
        response = requests.get(
            f"{self.api_url}/api/v1/status",
            headers=self._get_headers()
        )
        response.raise_for_status()
        return response.json()
