"""引擎管理 API"""

from typing import Dict, Optional
import requests


class EngineAPI:
    """引擎管理 API Mixin"""

    def clear_data(self, instrument_id: Optional[str] = None) -> Dict:
        """清理 OHLCV 數據

        Args:
            instrument_id: 要清理的 instrument ID，None = 清空所有

        Returns:
            清理結果

        Raises:
            requests.HTTPError: 500

        Example:
            >>> # 清理特定商品
            >>> client.clear_data(instrument_id="TXF")
            >>>
            >>> # 清空所有數據
            >>> client.clear_data()
        """
        payload = {}
        if instrument_id is not None:
            payload["instrument_id"] = instrument_id

        response = requests.post(
            f"{self.api_url}/api/v1/engine/clear-data",
            json=payload,
            headers=self._get_headers(),
        )
        response.raise_for_status()
        return response.json()

    def reset_engine(self) -> Dict:
        """重置引擎

        Returns:
            重置結果

        Raises:
            requests.HTTPError: 500

        Example:
            >>> client.reset_engine()
        """
        response = requests.post(
            f"{self.api_url}/api/v1/engine/reset",
            json={},
            headers=self._get_headers(),
        )
        response.raise_for_status()
        return response.json()
