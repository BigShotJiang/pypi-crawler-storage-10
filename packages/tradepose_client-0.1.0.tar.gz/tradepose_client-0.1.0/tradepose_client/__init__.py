"""Tradepose Python Client

易於使用的 Tradepose API 客戶端，提供策略管理、數據導出和分析功能。

Example:
    >>> from tradepose_client import TradeposeClient
    >>> client = TradeposeClient()
    >>>
    >>> # 列出策略
    >>> strategies = client.list_strategies()
    >>>
    >>> # 快速導出數據
    >>> df = client.quick_export("my_strategy")
"""

from .client import TradeposeClient
from .models import (
    StrategyConfig,
    Blueprint,
    Trigger,
    IndicatorSpec,
    Freq,
    OrderStrategy,
    Indicator,
    create_trigger,
    create_blueprint,
    create_indicator_spec,
    parse_strategy,
)
from .schema import (
    enhanced_ohlcv_schema,
    trades_schema,
    performance_schema,
)
from .analysis import (
    calculate_returns,
    calculate_volatility,
    calculate_drawdown,
    get_max_drawdown,
    filter_by_date_range,
    split_train_test,
    find_indicator_columns,
    resample_to_daily,
    print_summary,
)
from .viz import (
    plot_mae_mfe_scatter,
    plot_mfe_mhl_analysis,
    plot_pnl_curves,
    plot_trade_histograms,
    combine_charts,
    add_win_loss_label,
    calculate_mea,
    calculate_mae_atr_ratio,  # Legacy alias
    calculate_cumulative_pnl,
    get_quantiles,
)

__version__ = "0.1.0"

__all__ = [
    # Client
    "TradeposeClient",
    "get_client",
    "quick_export",
    # Models
    "StrategyConfig",
    "Blueprint",
    "Trigger",
    "IndicatorSpec",
    "Freq",
    "OrderStrategy",
    "Indicator",
    "create_trigger",
    "create_blueprint",
    "create_indicator_spec",
    "parse_strategy",
    # Schema
    "enhanced_ohlcv_schema",
    "trades_schema",
    "performance_schema",
    # Analysis
    "calculate_returns",
    "calculate_volatility",
    "calculate_drawdown",
    "get_max_drawdown",
    "filter_by_date_range",
    "split_train_test",
    "find_indicator_columns",
    "resample_to_daily",
    "print_summary",
    # Visualization
    "plot_mae_mfe_scatter",
    "plot_mfe_mhl_analysis",
    "plot_pnl_curves",
    "plot_trade_histograms",
    "combine_charts",
    "add_win_loss_label",
    "calculate_mea",
    "calculate_mae_atr_ratio",  # Legacy alias
    "calculate_cumulative_pnl",
    "get_quantiles",
]


def get_client(
    api_url: str = "http://localhost:8080",
    redis_url: str = "redis://:tradepose_password@localhost:6379",
) -> TradeposeClient:
    """獲取 Tradepose 客戶端實例

    Args:
        api_url: API URL
        redis_url: Redis URL

    Returns:
        TradeposeClient 實例

    Example:
        >>> client = get_client()
        >>> strategies = client.list_strategies()
    """
    return TradeposeClient(api_url=api_url, redis_url=redis_url)


def quick_export(
    strategy_name: str,
    blueprint_name: str = None,
    start_date: str = "2020-01-01T00:00:00",
    end_date: str = None,
    save_path: str = None,
):
    """快速導出數據（最簡單的使用方式）

    Args:
        strategy_name: 策略名稱
        blueprint_name: 藍圖名稱
        start_date: 起始日期
        end_date: 終止日期
        save_path: 保存路徑

    Returns:
        Polars DataFrame

    Example:
        >>> from tradepose_client import quick_export
        >>> df = quick_export("txf_1h_sma30_50", start_date="2020-01-01T00:00:00")
    """
    client = get_client()
    return client.quick_export(
        strategy_name=strategy_name,
        blueprint_name=blueprint_name,
        start_date=start_date,
        end_date=end_date,
        save_path=save_path,
    )
