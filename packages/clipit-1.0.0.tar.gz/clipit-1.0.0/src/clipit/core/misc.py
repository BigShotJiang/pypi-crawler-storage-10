class ClipitError(Exception):
    pass
