import setuptools
setuptools.setup()
