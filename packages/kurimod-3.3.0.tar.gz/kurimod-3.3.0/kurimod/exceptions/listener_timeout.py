class ListenerTimeout(Exception):
    pass
