"""Django La Suite library."""
