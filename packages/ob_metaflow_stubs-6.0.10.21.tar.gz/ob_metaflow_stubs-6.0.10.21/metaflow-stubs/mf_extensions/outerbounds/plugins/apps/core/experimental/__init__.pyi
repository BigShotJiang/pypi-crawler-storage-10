######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.4.1+obcheckpoint(0.2.8);ob(v1)                                                    #
# Generated on 2025-10-29T20:50:15.864103                                                            #
######################################################################################################

from __future__ import annotations



TYPE_CHECKING: bool

DEFAULT_BRANCH: str

def capsule_input_overrides(app_config: "AppConfig", capsule_input: dict):
    ...

