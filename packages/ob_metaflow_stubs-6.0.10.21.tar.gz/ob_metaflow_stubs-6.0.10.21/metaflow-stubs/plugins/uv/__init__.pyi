######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.4.1+obcheckpoint(0.2.8);ob(v1)                                                    #
# Generated on 2025-10-29T20:50:15.848076                                                            #
######################################################################################################

from __future__ import annotations


from . import uv_environment as uv_environment

