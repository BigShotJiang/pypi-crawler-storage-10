######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.4.1+obcheckpoint(0.2.8);ob(v1)                                                    #
# Generated on 2025-10-29T20:50:15.845293                                                            #
######################################################################################################

from __future__ import annotations


from . import pytorch as pytorch

