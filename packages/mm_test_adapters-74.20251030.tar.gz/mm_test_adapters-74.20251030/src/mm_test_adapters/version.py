__version__ = "74.20251030"
GIT_REF = "c54993b"
URL = "https://github.com/micro-manager/mmCoreAndDevices/tree/c54993b"