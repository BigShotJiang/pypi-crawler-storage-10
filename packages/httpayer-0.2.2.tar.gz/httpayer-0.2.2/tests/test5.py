from httpayer import HTTPayerClient
import json
import os

client = HTTPayerClient()

url = "https://helius.api.corbits.dev"
method = "POST"
data = {
    "jsonrpc": "2.0",
    "id": 1,
    "method": "getBlockHeight"
}

response = client.request(method, url, json=data)

print("Response:", json.dumps(response.json(), indent=4))