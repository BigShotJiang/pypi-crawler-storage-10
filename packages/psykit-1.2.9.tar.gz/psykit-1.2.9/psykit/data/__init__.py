#!/usr/bin/env python
# -*- coding: utf-8 -*-
from os import path

data_path = path.realpath(path.dirname(__file__))
