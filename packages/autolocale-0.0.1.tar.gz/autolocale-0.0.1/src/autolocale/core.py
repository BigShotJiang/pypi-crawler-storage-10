

class AutoLocale:
    pass