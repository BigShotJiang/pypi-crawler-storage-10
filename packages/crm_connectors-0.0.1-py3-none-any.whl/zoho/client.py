import requests
import json
import logging
import traceback
import csv
import io

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')


class ZohoClient:
    def __init__(self, client_id: str = None, client_secret: str = None, refresh_token: str = None,
                 access_token: str = None,
                 token_url: str = None, crm_api_url: str = None, domain: str = None, logger: logging.Logger = None):
        """
        Initializes the ZohoClient class.
        Loads configuration from environment variables.
        """
        # Prioritize constructor arguments, then environment variables
        self.client_id = client_id
        self.client_secret = client_secret
        self.refresh_token = refresh_token
        self.access_token = access_token
        self.logger = logger if logger else logging.getLogger("ZOHO-INTEGRATION")

        if not all([client_id, client_secret, refresh_token, token_url, crm_api_url, domain]):
            missing_params = [
                p_name for p_name, p_val in {
                    "client_id": client_id, "client_secret": client_secret,
                    "refresh_token": refresh_token, "token_url": token_url,
                    "crm_api_url": crm_api_url, "domain": domain
                }.items() if not p_val
            ]
            raise ValueError(f"Missing required constructor arguments: {', '.join(missing_params)}")

        self.token_url = token_url.format(domain=domain)
        self.crm_api_url = crm_api_url.rstrip('/') + "/crm/v2"

    def refresh_access_token(self):
        """
        Refreshes the access token using the refresh token.
        Updates self.access_token on success.
        Returns True on success, False on failure.
        """
        if not all([self.refresh_token, self.client_id, self.client_secret, self.token_url]):
            self.logger.error("Cannot refresh token: Missing refresh_token, client_id, client_secret, or token_url.")
            return False

        payload = {
            'refresh_token': self.refresh_token,
            'client_id': self.client_id,
            'client_secret': self.client_secret,
            'grant_type': 'refresh_token'
        }
        try:
            self.logger.info(f"Attempting to refresh access token using URL: {self.token_url}")
            res = requests.post(self.token_url, data=payload)
            res.raise_for_status()  # Raise HTTPError for bad responses (4xx or 5xx)

            token_data = res.json()
            new_access_token = token_data.get('access_token')

            if not new_access_token:
                self.logger.error(f"Failed to refresh access token. 'access_token' not found in response: {token_data}")
                return False

            self.access_token = new_access_token
            self.logger.info("Access token refreshed successfully.")
            # Optionally, handle 'expires_in' if needed for proactive refresh scheduling
            return True
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Request failed during token refresh: {e}")
            if res and res.content:
                self.logger.error(f"Zoho API response (token refresh): {res.text}")
            return False
        except json.JSONDecodeError:
            self.logger.error(
                f"Failed to decode JSON response during token refresh. Response: {res.text if res else 'No response'}")
            return False
        except KeyError as e:
            self.logger.error(
                f"KeyError while parsing token refresh response: {e}. Response: {token_data if 'token_data' in locals() else 'Unknown'}")
            return False

    def _get_access_token(self):
        """
        Retrieves the current access token stored in the instance.
        Call refresh_access_token() to obtain or refresh the token.
        """
        if not self.access_token:
            self.logger.warning(
                "No access token available. Ensure refresh_access_token() has been called successfully.")
        return self.access_token

    def get_all_leads(self, per_page=200):
        """
        Retrieves all leads from Zoho CRM.
        Ensure a valid access token is present (e.g., by calling refresh_access_token()).
        """
        access_token = self._get_access_token()
        if not access_token:
            self.logger.error("No access token. Cannot retrieve leads. Call refresh_access_token() first.")
            return []

        headers = {
            "Authorization": f"Zoho-oauthtoken {access_token}"
        }
        url = f"{self.crm_api_url}/Leads"
        page = 1
        all_leads = []

        while True:
            params = {
                "page": page,
                "per_page": per_page
            }
            try:
                res = requests.get(url, headers=headers, params=params)
                res.raise_for_status()  # Raise HTTPError for bad responses (4xx or 5xx)

                if res.status_code == 204:
                    self.logger.info("No more records found (HTTP 204).")
                    break  # No more records

                data = res.json().get("data", [])
                if not data:
                    self.logger.info(f"No data found on page {page}. Breaking loop.")
                    break

                for lead in data:
                    self.logger.info(
                        f"Lead: Created_Time={lead.get('Created_Time')}, Email={lead.get('Email')}, Lead_Source={lead.get('Lead_Source')}, Data_Source={lead.get('Data_Source')}")

                all_leads.extend(data)
                page += 1
            except requests.exceptions.RequestException as e:
                self.logger.error(f"Request failed: {e}")
                if res and res.content:
                    self.logger.error(f"Zoho API response: {res.text}")
                break
            except json.JSONDecodeError:
                self.logger.error(f"Failed to decode JSON response on page {page}.")
                break

        return all_leads

    def _search_lead(self, email=None, phone=None):
        """
        Searches for a lead in Zoho CRM by email or phone.
        Ensure a valid access token is present (e.g., by calling refresh_access_token()).
        """
        access_token = self._get_access_token()
        if not access_token:
            self.logger.error(
                "No access token. Cannot search lead. Ensure refresh_access_token() has been called successfully.")
            return None

        headers = {
            "Authorization": f"Zoho-oauthtoken {access_token}"
        }

        search_url = f"{self.crm_api_url}/Leads/search"
        params = {}
        if email:
            params["email"] = email
        elif phone:
            params["phone"] = phone
        else:
            self.logger.warning("No email or phone provided for lead search.")
            return None

        try:
            res = requests.get(search_url, headers=headers, params=params)
            res.raise_for_status()

            if res.status_code == 204:
                self.logger.info("No record found (HTTP 204) for search.")
                return None  # No record found

            data = res.json()
            return data.get("data", [])
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Lead search failed: {e}")
            response_text = None
            if 'res' in locals() and hasattr(res, 'content') and res.content:
                response_text = res.text
            self.logger.error(
                f"Zoho API response: {response_text if response_text else 'No response content available'}")
            return None
        except json.JSONDecodeError:
            response_text_for_json_error = 'Unknown (response object not available or has no text)'
            if 'res' in locals() and hasattr(res, 'text'):
                response_text_for_json_error = res.text
            self.logger.error(
                f"Failed to decode JSON response during lead search. Response text: {response_text_for_json_error}")
            return None

    def create_lead(self, lead_data):
        """
        Creates a lead in Zoho CRM.
        Ensure a valid access token is present (e.g., by calling refresh_access_token()).
        """
        access_token = self._get_access_token()
        if not access_token:
            self.logger.error(
                "No access token. Cannot create lead. Ensure refresh_access_token() has been called successfully.")
            return None

        url = f"{self.crm_api_url}/Leads"
        headers = {
            "Authorization": f"Zoho-oauthtoken {access_token}",
            "Content-Type": "application/json"
        }

        payload = {
            "data": [lead_data]
        }
        try:
            res = requests.post(url, json=payload, headers=headers)
            res.raise_for_status()
            data = res.json()
            self.logger.info(f"Create lead raw response: {data}")

            if data and data.get("data") and data["data"][0].get("status") == "error":
                error_details = data["data"][0].get("details", {})
                self.logger.error(f"Zoho Api reported error having following details:  {error_details}")
                self.logger.error(
                    f"Zoho API reported error during lead creation: {error_details.get('message', 'No message')}")
                return None

            lead_id = data["data"][0]["details"]["id"]
            self.logger.info(f"Lead created successfully with ID: {lead_id}")
            return lead_id
        except requests.exceptions.RequestException as e:
            traceback.print_exc()
            self.logger.error(f"Failed to create lead: {e}")
            if res and res.content:
                self.logger.error(f"Zoho API response: {res.text}")
            return None
        except (KeyError, IndexError, json.JSONDecodeError) as e:
            traceback.print_exc()
            self.logger.error(
                f"Failed to parse response or extract lead ID after creation: {e}. Response was: {res.text if res else 'No response'}")
            return None

    def add_note_to_lead(self, lead_id, note_title, note_content):
        """
        Adds a note to a lead in Zoho CRM.
        Ensure a valid access token is present (e.g., by calling refresh_access_token()).
        """
        access_token = self._get_access_token()
        if not access_token:
            self.logger.error(
                "No access token. Cannot add note. Ensure refresh_access_token() has been called successfully.")
            return None

        url = f"{self.crm_api_url}/Leads/{lead_id}/Notes"
        headers = {
            "Authorization": f"Zoho-oauthtoken {access_token}",
            "Content-Type": "application/json"
        }
        payload = {
            "data": [
                {
                    "Note_Title": note_title,
                    "Note_Content": note_content
                }
            ]
        }
        try:
            response = requests.post(url, json=payload, headers=headers)
            response.raise_for_status()
            self.logger.info(f"Note added to lead {lead_id} successfully.")
            return response.json()
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Failed to add note to lead {lead_id}: {e}")
            if response and response.content:
                self.logger.error(f"Zoho API response: {response.text}")
            return None
        except json.JSONDecodeError:
            self.logger.error(f"Failed to decode JSON response when adding note to lead {lead_id}.")
            return None

    def add_lead(self, zoho_data):
        """
        Adds a lead to Zoho CRM.
        If the lead already exists, it adds a note to the existing lead.
        Ensure a valid access token is present (e.g., by calling refresh_access_token()).
        """
        self.logger.info(
            f"Attempting to add lead with email: {zoho_data.get('Email')} and phone: {zoho_data.get('Phone')}")
        lead_id = None
        try:
            # Search for existing lead - _get_access_token will be called internally
            lead = self._search_lead(email=zoho_data.get("Email"), phone=zoho_data.get("Phone"))

            if not lead:
                self.logger.info("Lead not found. Creating new lead.")
                # Create lead - _get_access_token will be called internally
                lead_id = self.create_lead(zoho_data)
            else:
                self.logger.info("Lead already exists. Adding note to existing lead.")
                lead_id = lead[0].get("id")
                if lead_id:
                    title = zoho_data.get("Lead_Source", "")
                    form_title = zoho_data.get("Form_Title", "")
                    user_details = zoho_data.get("User_Details", "")

                    # Add note - _get_access_token will be called internally
                    self.add_note_to_lead(
                        lead_id=lead_id,
                        note_title=f"Returned Customer: {form_title}, on {title}",
                        note_content=user_details
                    )
                    self.logger.info("Note added to existing lead.")
                else:
                    self.logger.error("Existing lead found but no ID available to add note.")
            return lead_id
        except Exception as e:
            traceback.print_exc()
            self.logger.error(f"An unexpected error occurred in add_lead: {e}", exc_info=True)
            return None

    def write_leads_to_file(self, filename="leads.csv"):
        """
        Retrieves all leads from Zoho CRM and writes them to a CSV file.
        """
        try:
            leads = self.get_all_leads()
            if not leads:
                self.logger.info("No leads found to write to file.")
                return

            csv_data = self.generate_leads_csv(leads)
            with open(filename, "w", newline="") as f:
                f.write(csv_data)

            self.logger.info(f"Leads written to {filename} successfully.")

        except IOError as e:
            self.logger.error(f"IOError while writing leads to file: {e}")
        except Exception as e:
            self.logger.error(f"An unexpected error occurred in write_leads_to_file: {e}")

    def generate_leads_csv(self, leads_data):
        """
        Generates CSV data from a list of lead data dictionaries.
        """
        if not leads_data:
            return ""

        output = io.StringIO()
        writer = csv.writer(output)

        # Prepare headers
        headers = set()
        for lead in leads_data:
            for key, value in lead.items():
                if isinstance(value, dict):
                    for sub_key in value:
                        headers.add(f"{key}_{sub_key}")
                else:
                    headers.add(key)

        sorted_headers = sorted(list(headers))
        writer.writerow(sorted_headers)

        # Write data
        for lead in leads_data:
            row = []
            for header in sorted_headers:
                if '_' in header:
                    parent_key, sub_key = header.split('_', 1)
                    if parent_key in lead and isinstance(lead[parent_key], dict):
                        row.append(lead[parent_key].get(sub_key, ""))
                    else:
                        row.append("")
                else:
                    row.append(lead.get(header, ""))
            writer.writerow(row)

        return output.getvalue()


if __name__ == "__main__":
    # Example Usage (ensure to replace placeholders with actual credentials if running)
    # Note: The access_token is initially set for demonstration.
    # In a real application, you might start with no access_token and call refresh_access_token() first.
    try:
        client = ZohoClient(
            client_id="1000.3G1XK16K5IJOIK279SOJ9N8TY8EXIL",  # Replace with actual client_id
            client_secret="f147883d99230a2e6100c68b90abf40d333ab18024",  # Replace with actual client_secret
            refresh_token="1000.9d3709aa920c1c51a1edeeb5bf5d5342.3670af688f73bfdd8e849eefb5151f35",
            # Replace with actual refresh_token
            access_token="1000.38f182112f0fb911eed59d1909412af0.25e236d1f2e17301c6df9d6a26245547",
            # Optional: if you have a fresh one
            token_url="https://accounts.{domain}/oauth/v2/token",
            crm_api_url="https://www.zohoapis.in",  # Or .com, .eu, etc.
            domain="zoho.in",  # Or .com, .eu, etc.
            logger=logging.getLogger("INTEGRATIONS")  # Optional: pass a custom logger
        )

        # # Create an empty leads.csv file
        # with open("leads.csv", "w") as f:
        #     f.write("")

        # print("Created an empty leads.csv file.")
        # client.write_leads_to_file("leads.csv")
        client.refresh_access_token()
        client.create_lead({
            "Last_Name": "kjfj",
            "First_Name": "dfd",
            "Email": "jhansoab@example.com",
            "pagal": "dfd",
        })

    except ValueError as ve:
        print(f"Configuration Error: {ve}")
    except Exception as e:
        print(f"An unexpected error occurred in the example usage: {e}")
        traceback.print_exc()
