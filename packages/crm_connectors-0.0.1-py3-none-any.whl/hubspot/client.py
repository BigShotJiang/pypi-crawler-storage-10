import requests, logging, csv, os
from typing import Optional, List, Dict
import traceback

# Configure logging once
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s"
)


class HubSpotConnector:
    """
        A connector class for interacting with the HubSpot API using OAuth credentials.

        This class provides methods to authenticate and perform operations on HubSpot objects,
        such as contacts, using the provided access and refresh tokens. It manages API endpoints
        and handles authentication setup.

        Attributes:
            client_id (str): HubSpot client ID used for OAuth authentication.
            client_secret (str): HubSpot client secret used for OAuth authentication.
            access_token (str): Current access token for making API requests.
            refresh_token (str): Refresh token used to obtain a new access token.
            base_url (str): Base URL for HubSpot API requests.
            contact_url (str): Endpoint for interacting with HubSpot contacts.
    """

    def __init__(self, client_id: str, client_secret: str, access_token: str, refresh_token: str,
                 base_url: str = "https://api.hubapi.com", contact_path: str = "/crm/v3/objects/contacts",
                 logger: logging.Logger = None):
        """
        Initialize HubSpot connector with OAuth credentials.

        Args:
            client_id (str): HubSpot client ID
            client_secret (str): HubSpot client secret
            access_token (str): Access token for API calls
            refresh_token (str): Refresh token to renew access
        """
        try:
            self.client_id = client_id
            self.client_secret = client_secret
            self.access_token = access_token
            self.refresh_token = refresh_token
            self.base_url = base_url

            # Endpoints
            self.url = f"{self.base_url}{contact_path}"
            self.search_url = f"{self.url}/search"

            self.logger = logger if logger else logging.getLogger("HUBSPOT-INTEGRATION")
            self.logger.info("HubSpotConnector initialized successfully.")

        except Exception as e:
            self.logger.error(f"Failed to initialize HubSpotConnector: {str(e)}")
            raise

    def _get_headers(self) -> Dict[str, str]:
        """Return common headers for HubSpot API requests."""
        return {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }

    def get_all_leads(self) -> List:
        """
        Fetch all leads from the HubSpot account and log their details.

        Returns:
            List of leads as dictionaries.
        """
        try:
            leads = []
            url = self.url  # store as a local variable for the function

            while url:
                response = requests.get(url, headers=self._get_headers())
                response.raise_for_status()
                data = response.json()
                results = data.get("results", [])
                leads.extend(results)

                # Check for next page
                paging = data.get("paging", {})
                next_page = paging.get("next", {})
                url = next_page.get("link") if next_page else None

            self.logger.info(f"Total leads fetched: {len(leads)}")
            return leads

        except requests.exceptions.HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            return []
        except Exception as e:
            traceback.print_exc()
            self.logger.error(f"Error fetching leads: {e}")
            return []

    def create_lead(self, properties: dict) -> Dict:
        """
        Create or update a lead (contact) in HubSpot CRM.

        - If the email already exists, update the contact by appending/updating the 'message' field.
        - Otherwise, create a new contact.

        Args:
            properties (dict): Contact properties including:
                - firstname (str): Lead's first name (mandatory)
                - lastname (str): Lead's last name (mandatory)
                - email (str): Lead's email address (mandatory)
                - phone (str, optional): Lead's phone number
                - message (str, optional): Extra message to store
                - other fields allowed by HubSpot

        Returns:
            dict: The created or updated contact object from HubSpot
        """
        try:

            email = properties.get("email")
            if not email:
                raise ValueError("Email is required to create or update a lead")

            search_url = self.search_url
            url = self.url
            # --- Step 1: Search for existing contact by email ---

            search_payload = {
                "filterGroups": [{
                    "filters": [{
                        "propertyName": "email",
                        "operator": "EQ",
                        "value": email
                    }]
                }]
            }
            search_resp = requests.post(search_url, headers=self._get_headers(), json=search_payload)
            search_resp.raise_for_status()
            results = search_resp.json().get("results", [])

            if results:
                # --- Step 2: Contact exists → update it ---
                contact_id = results[0]["id"]

                # If there's a message, append or update it
                new_message = properties.get("message")
                if new_message:
                    existing_message = results[0]["properties"].get("message", "")
                    combined_message = f"{existing_message}\n{new_message}" if existing_message else new_message
                    properties["message"] = combined_message

                update_url = f"{url}/{contact_id}"
                update_resp = requests.patch(update_url, headers=self._get_headers(), json={"properties": properties})
                update_resp.raise_for_status()
                # updated_contact = update_resp.json()
                self.logger.info(f"Lead updated successfully: ID={contact_id}, Email={email}")
                return True

            else:
                # --- Step 3: No contact → create a new one ---

                create_resp = requests.post(url, headers=self._get_headers(), json={"properties": properties})
                create_resp.raise_for_status()
                new_contact = create_resp.json()
                self.logger.info(f"Lead created successfully: ID={new_contact.get('id')}, Email={email}")
                return True

        except requests.exceptions.HTTPError as http_err:
            if http_err.response is not None:
                try:
                    error_detail = http_err.response.json()
                except ValueError:
                    error_detail = http_err.response.text
                self.logger.error(
                    f"HTTP error {http_err.response.status_code} while creating/updating lead: {error_detail}")
                traceback.print_exc()
                return False
            else:
                self.logger.error(f"HTTP error occurred: {http_err}")
                traceback.print_exc()
                return False
        except Exception as e:
            self.logger.error(f"Unexpected error creating/updating lead: {e}")
            traceback.print_exc()
            return False

    def update_lead(self, email: str, updated_fields: dict) -> Dict:
        """
        Update a lead (contact) in HubSpot by email.

        Args:
            email (str): Email of the lead to update.
            updated_fields (dict): Fields and values to update.

        Returns:
            dict: Updated lead details if successful, else {}.

        Updatable fields in HubSpot contacts include (not exhaustive):
            - firstname (string)
            - lastname (string)
            - email (string, must be unique if changed)
            - phone (string)
            - company (string)
            - jobtitle (string)
            - city (string)
            - state (string)
            - zip (string)
            - country (string)
            - lead_status (dropdown, e.g. NEW, OPEN, IN_PROGRESS, OPEN_DEAL, UNQUALIFIED, ATTEMPTED_TO_CONTACT, CONNECTED, BAD_TIMING)
            - lifecycle_stage (dropdown, e.g. subscriber, lead, opportunity, customer, evangelist, other)
        """
        try:
            # Step 1: Search contact by email
            payload = {
                "filterGroups": [{
                    "filters": [{
                        "propertyName": "email",
                        "operator": "EQ",
                        "value": email
                    }]
                }]
            }
            response = requests.post(self.search_url, headers=self._get_headers(), json=payload)
            response.raise_for_status()
            data = response.json()

            results = data.get("results", [])
            if not results:
                self.logger.warning(f"No lead found with email: {email}")
                return {}

            contact_id = results[0]["id"]

            # Step 2: Validate dropdown fields before update
            valid_lead_statuses = [
                "NEW", "OPEN", "IN_PROGRESS", "OPEN_DEAL",
                "UNQUALIFIED", "ATTEMPTED_TO_CONTACT", "CONNECTED", "BAD_TIMING"
            ]
            valid_lifecycle_stages = [
                "subscriber", "lead", "marketingqualifiedlead", "salesqualifiedlead",
                "opportunity", "customer", "evangelist", "other"
            ]

            safe_fields = {}
            for field, value in updated_fields.items():
                if field == "lead_status" and value not in valid_lead_statuses:
                    self.logger.warning(f"Invalid lead_status '{value}' for {email}. Skipping this field.")
                    continue
                if field == "lifecycle_stage" and value not in valid_lifecycle_stages:
                    self.logger.warning(f"Invalid lifecycle_stage '{value}' for {email}. Skipping this field.")
                    continue
                safe_fields[field] = value

            if not safe_fields:
                self.logger.warning(f"No valid fields to update for {email}.")
                return {}

            # Step 3: Update contact
            update_url = f"{self.url}/{contact_id}"
            update_payload = {"properties": safe_fields}

            update_response = requests.patch(update_url, headers=self._get_headers(), json=update_payload)
            update_response.raise_for_status()
            updated_data = update_response.json()

            self.logger.info(f"Lead {email} updated successfully with fields: {safe_fields}")
            return updated_data

        except requests.exceptions.HTTPError as http_err:
            self.logger.error(f"HTTP error occurred while updating lead: {http_err}")
            return {}
        except Exception as e:
            self.logger.error(f"Error updating lead: {e}")
            return {}

    def get_lead_by_email(self, email: str):
        """
        Fetch a lead/contact from HubSpot using email.

        Args:
            email (str): The email of the lead to fetch.

        Returns:
            dict: Lead details if found, else None.
        """
        try:
            url = self.search_url
            payload = {
                "filterGroups": [
                    {
                        "filters": [
                            {"propertyName": "email", "operator": "EQ", "value": email}
                        ]
                    }
                ],
                "properties": [
                    "firstname", "lastname", "email", "phone", "company",
                    "lead_status", "lifecycle_stage", "jobtitle", "city",
                    "state", "zip", "country", "createdate", "hs_object_id"
                ]
            }

            response = requests.post(url, headers=self._get_headers(), json=payload)
            response.raise_for_status()
            data = response.json()

            results = data.get("results", [])
            if not results:
                self.logger.info(f"No lead found with email: {email}")
                return None

            # Return the first matching lead
            lead = results[0]
            self.logger.info(f"Lead found: ID={lead.get('id')}, Email={email}")
            return lead

        except requests.exceptions.HTTPError as http_err:
            self.logger.error(f"HTTP error occurred while fetching lead: {http_err}")
            return None
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Request failed while fetching lead: {e}")
            return None

    def export_leads_to_csv(self, file_name: str = "Hubspot_lead.csv", path: str = None) -> None:
        """
        Export all HubSpot leads to a CSV file including all possible properties defined in HubSpot,
        even if no lead currently has data for some fields.
        """

        try:
            # Step 1: Fetch all possible lead properties from HubSpot
            # Assuming self.url is the base API URL for HubSpot
            properties_url = f"{self.base_url}/properties/v1/contacts/properties"
            response = requests.get(properties_url, headers=self._get_headers())
            response.raise_for_status()
            properties_metadata = response.json()

            # Collect all property names
            property_fields = [prop["name"] for prop in properties_metadata]

            # Include top-level fields like 'id'
            top_level_fields = ["id", "vid", "canonical-vid", "merged-vids", "portal-id", "is-contact"]
            all_fields = sorted(set(top_level_fields + property_fields))

            # Step 2: Fetch all leads
            leads = self.get_all_leads()  # This returns the actual lead data
            if not leads:
                self.logger.info("No leads found.")
                return None

            # Step 3: Prepare file path
            if not path:
                path = os.getcwd()
            os.makedirs(path, exist_ok=True)
            full_path = os.path.join(path, file_name)

            # Step 4: Write CSV
            with open(full_path, mode="w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=all_fields)
                writer.writeheader()

                for lead in leads:
                    row = {field: None for field in all_fields}

                    # Fill top-level fields
                    for k in top_level_fields:
                        row[k] = lead.get(k, None)

                    # Fill properties
                    for k, v in lead.get("properties", {}).items():
                        row[k] = v

                    writer.writerow(row)

            print(f"✅ Leads exported successfully to {full_path}")
            return full_path

        except Exception as e:
            print(f"Error exporting leads: {e}")
            return None

    def delete_lead_by_email(self, email: str):
        """
        Delete a lead/contact from HubSpot using email.

        Args:
            email (str): The email of the lead to delete.

        Returns:
            dict: {"status": "deleted", "id": lead_id} if deleted,
                {"status": "not_found"} if no lead found,
                {"status": "error"} if deletion failed.
        """
        try:
            # Step 1: Search for the lead by email
            # search_url = f"{self.base_url}{self.contact_url}/search"
            payload = {
                "filterGroups": [
                    {
                        "filters": [
                            {"propertyName": "email", "operator": "EQ", "value": email}
                        ]
                    }
                ],
                "properties": ["email", "firstname", "lastname"]
            }

            response = requests.post(self.search_url, headers=self._get_headers(), json=payload)
            response.raise_for_status()
            data = response.json()
            results = data.get("results", [])

            if not results:
                self.logger.info(f"No lead found with email: {email}")
                return {"status": "not_found", "email": email}

            lead_id = results[0]["id"]
            self.logger.info(f"Lead found: ID={lead_id}, Email={email}. Deleting...")

            # Step 2: Delete the lead by ID
            delete_url = f"{self.url}/{lead_id}"
            del_response = requests.delete(delete_url, headers=self._get_headers())
            del_response.raise_for_status()

            self.logger.info(f"Lead with email {email} deleted successfully.")
            return {"status": "deleted", "id": lead_id, "email": email}

        except requests.exceptions.HTTPError as http_err:
            self.logger.error(f"HTTP error occurred while deleting lead: {http_err}")
            return {"status": "error", "error": str(http_err)}
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Request failed while deleting lead: {e}")
            return {"status": "error", "error": str(e)}
