import logging, traceback, requests, logging, csv, os
from typing import Dict, Optional, List, Any, Tuple

# Configure logging once
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)


# ===========================
# Salesforce Connector Class
# ===========================


class SalesforceConnector:
    """
    A connector class for interacting with the Salesforce REST API using OAuth2 authentication.

    This class handles API authentication, stores necessary credentials, and sets up default
    headers for making authorized API requests to a Salesforce instance. It provides a base
    setup for further methods to interact with Salesforce objects, such as creating or
    retrieving leads, contacts, or other records.

    Attributes:
        client_id (str): Salesforce connected app Client ID.
        client_secret (str): Salesforce connected app Client Secret.
        access_token (str): OAuth2 access token for authenticating API requests.
        refresh_token (str): OAuth2 refresh token for renewing the access token.
        instance_url (str): Salesforce instance base URL (e.g., https://yourInstance.salesforce.com).
        data_url (str): Full Salesforce REST API URL including API version (v61.0 by default).
        headers (dict): Default HTTP headers for API requests, including Authorization and Content-Type.

    Example:
        >>> connector = SalesforceConnector(
        ...     client_id="your_client_id",
        ...     client_secret="your_client_secret",
        ...     access_token="your_access_token",
        ...     refresh_token="your_refresh_token",
        ...     instance_url="https://yourInstance.salesforce.com"
        ... )
        >>> response = connector.get_leads()
    """

    def __init__(self, client_id: str, client_secret: str, access_token: str, refresh_token: str, instance_url: str,
                 logger: logging.Logger = None):
        """
            Initialize the SalesforceConnector instance with authentication credentials and API configuration.

        Args:
            client_id (str): The Salesforce connected app's Client ID.
            client_secret (str): The Salesforce connected app's Client Secret.
            access_token (str): The OAuth2 access token used to authenticate API requests.
            refresh_token (str): The OAuth2 refresh token used to obtain a new access token when it expires.
            token_uri (str): The base Salesforce instance URL (e.g., https://yourInstance.salesforce.com).

        Attributes:
            client_id (str): Stores the Salesforce connected app Client ID.
            client_secret (str): Stores the Salesforce connected app Client Secret.
            access_token (str): Stores the current OAuth2 access token.
            refresh_token (str): Stores the OAuth2 refresh token.
            token_uri (str): Stores the Salesforce instance base URL without trailing slashes.
            instance_url (str): Stores the Salesforce REST API base URL (includes API version, v61.0 by default).
            headers (dict): Default request headers used for API calls, including Authorization and Content-Type.
        """
        try:

            self.client_id = client_id
            self.client_secret = client_secret
            self.access_token = access_token
            self.refresh_token = refresh_token
            self.instance_url = instance_url

            # Set Salesforce base domain internally

            self.data_url = f"{self.instance_url}/services/data/v61.0"
            self.lead_base_url = f"{self.data_url}/sobjects/Lead/"

            self.logger = logger if logger else logging.getLogger("SALESFORCE-INTEGRATION")
            self.logger.info("SalesForceConnector initialized successfully.")
        except Exception as e:
            self.logger.error("Failed to initialize SalesforceConnector: %s", str(e))
            raise

    def _get_headers(self) -> Dict[str, str]:
        """Return common headers for SalesForce API requests."""
        return {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }

    # -------------------------------
    # CRUD Operations
    # -------------------------------

    def create_lead(self, lead_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Create a new lead in Salesforce.
        If the lead already exists, append the new description to the existing one
        instead of overwriting it.
        Uses Salesforce REST API only (no SOQL SELECT).
        """
        self.logger.info("Creating a new lead in Salesforce...")
        try:
            # 🔹 Step 1: Search existing lead by Email (fast + explicit)
            search_url = f"{self.data_url}/parameterizedSearch"
            search_params = {
                "q": lead_data.get("Email"),
                "sobject": "Lead",
                "fields": "Id,Email,FirstName,Description",
                "in": "Email"
            }
            response = requests.get(search_url, headers=self._get_headers(), params=search_params)
            response.raise_for_status()
            records = response.json().get("searchRecords", [])

            if records:
                # ✅ Lead exists — append description
                record = records[0]
                lead_id = record.get("Id")

                # Fetch latest description from Salesforce to avoid stale data
                detail_url = f"{self.lead_base_url}{lead_id}"
                detail_resp = requests.get(detail_url, headers=self._get_headers())
                if detail_resp.status_code == 200:
                    existing_description = detail_resp.json().get("Description", "") or ""
                else:
                    existing_description = ""

                new_description = lead_data.get("Description", "").strip()
                updated_description = (
                    f"{existing_description}\n\n---\n{new_description}"
                    if existing_description and new_description
                    else new_description or existing_description
                )

                update_payload = {"Description": updated_description}
                update_resp = requests.patch(detail_url, headers=self._get_headers(), json=update_payload)

                if update_resp.status_code == 204:
                    self.logger.info(f"📌 Lead {lead_id} already exists. Description updated successfully.")
                    return {"id": lead_id, "success": True, "message": "Existing lead updated."}
                else:
                    self.logger.error(f"❌ Failed to update Lead {lead_id}. Response: {update_resp.text}")
                    return {"id": lead_id, "success": False, "message": "Failed to update existing lead."}

            # 🔹 Step 2: No existing lead — create a new one
            create_url = f"{self.lead_base_url}"
            response = requests.post(create_url, headers=self._get_headers(), json=lead_data)
            data = response.json()

            # Handle duplicate directly (Salesforce 400 error)
            if response.status_code == 400 and any(err.get("errorCode") == "DUPLICATES_DETECTED" for err in data):
                match = data[0]["duplicateResult"]["matchResults"][0]["matchRecords"][0]["record"]
                lead_id = match["Id"]

                self.logger.warning(f"⚠️ Duplicate detected. Appending description to existing Lead {lead_id}...")

                new_description = lead_data.get("Description", "").strip()
                update_url = f"{self.lead_base_url}{lead_id}"
                update_resp = requests.patch(update_url, headers=self._get_headers(),
                                             json={"Description": new_description})

                if update_resp.status_code == 204:
                    self.logger.info(f"✅ Existing lead {lead_id} description updated after duplicate detection.")
                    return {"id": lead_id, "success": True, "message": "Duplicate found; lead updated."}
                else:
                    self.logger.error(
                        f"❌ Failed to update lead after duplicate detection. Response: {update_resp.text}")
                    return {"id": lead_id, "success": False, "message": "Duplicate found; update failed."}

            elif response.status_code == 201:
                lead_id = data.get("id")
                self.logger.info(f"✅ New Lead created successfully! Lead ID: {lead_id}")
                return {"id": lead_id, "success": True, "message": "Lead created successfully."}
            else:
                self.logger.error(f"❌ Failed to create lead. Status: {response.status_code} | Response: {data}")
                return {"success": False, "message": "Failed to create lead."}

        except requests.exceptions.HTTPError as e:
            self.logger.error(f"❌ HTTP Error while creating/updating lead: {str(e)}")
            if e.response is not None:
                self.logger.error(f"📌 Salesforce Response: {e.response.text}")
            return {"success": False, "message": str(e)}

    def update_lead_by_email(self, email: str, update_data: dict) -> dict:
        """
        Update a Salesforce Lead by email with dropdown validation and warnings.

        This method allows you to update any **valid Lead fields** in Salesforce.
        It fetches the field metadata dynamically from Salesforce, so it can handle
        standard fields, custom fields, and dropdown validations automatically.

        ⚡ **Updatable Standard Lead Fields (Common Examples):**
        - **Personal Details:**
            - `FirstName`, `LastName`, `Salutation`, `Title`
        - **Contact Information:**
            - `Phone`, `MobilePhone`, `Fax`, `Email`, `Website`
        - **Company Information:**
            - `Company`, `Industry`, `AnnualRevenue`, `NumberOfEmployees`
        - **Address Details:**
            - `Street`, `City`, `State`, `PostalCode`, `Country`
        - **Lead Status & Source:**
            - `Status` *(picklist — e.g., "New", "Working")*
            - `LeadSource` *(picklist — e.g., "Web", "Phone Inquiry")*
            - `Rating` *(picklist — e.g., "Hot", "Warm", "Cold")*
        - **Custom Fields:**
            - Any Salesforce **custom fields** configured in your org
            (e.g., `Custom_Field__c`, `Region__c`, etc.)
        - **Description:**
            - `Description` → Free-text notes about the lead

        ⚠️ **Important Notes:**
        - Supports all standard and custom fields.
        - Validates dropdown (picklist) values before updating.
        - Ignores invalid field names and invalid dropdown values.
        - If no valid fields remain, the update is skipped.

        Args:
            email (str):
                Lead's email address used to identify the record.
            update_data (dict):
                A dictionary of fields to update.

        Returns:
            dict: Result of the update operation.
        """
        try:
            self.logger.info(f"🔄 Attempting to update Lead with email: {email}")

            # Step 1: Fetch dropdown fields and valid values
            try:
                describe_url = f"{self.lead_base_url}describe"
                describe_response = requests.get(describe_url, headers=self._get_headers())
                describe_response.raise_for_status()
            except requests.exceptions.RequestException as e:
                self.logger.error(f"❌ Failed to fetch Lead metadata: {e}")
                return {"success": False, "message": f"Failed to fetch Lead metadata: {e}"}

            fields_metadata = describe_response.json()["fields"]

            # Build metadata maps
            dropdown_fields = {
                field["name"]: [val["label"] for val in field["picklistValues"]]
                for field in fields_metadata if field.get("type") == "picklist"
            }
            valid_field_names = [field["name"] for field in fields_metadata]

            # Step 2: Validate field names and picklist values
            invalid_fields = []
            invalid_values = []

            for field, value in update_data.items():
                # Invalid field check
                if field not in valid_field_names:
                    invalid_fields.append(field)
                    continue

                # Dropdown validation
                if field in dropdown_fields:
                    valid_values = dropdown_fields[field]
                    if value not in valid_values:
                        invalid_values.append({
                            "field": field,
                            "invalid_value": value,
                            "valid_values": valid_values
                        })

            # Step 3: Show warnings for invalid fields
            if invalid_fields:
                self.logger.warning("⚠️ The following fields are invalid and will be ignored: %s", invalid_fields)

            if invalid_values:
                for iv in invalid_values:
                    self.logger.warning(
                        f"⚠️ Invalid value for '{iv['field']}': '{iv['invalid_value']}'. "
                        f"Valid options: {iv['valid_values']}"
                    )

            # Step 4: Remove invalid fields & invalid picklist values before update
            update_data = {
                field: value
                for field, value in update_data.items()
                if field not in invalid_fields and not any(iv["field"] == field for iv in invalid_values)
            }

            if not update_data:
                self.logger.error("❌ No valid fields left to update.")
                return {"success": False, "message": "No valid fields to update."}

            # ✅ Step 5: Fetch Lead by email (Updated — REST API, no SOQL)
            try:
                search_url = f"{self.data_url}/parameterizedSearch"
                search_params = {
                    "q": email,
                    "sobject": "Lead",
                    "fields": "Id,Email",
                    "in": "Email"
                }
                response = requests.get(search_url, headers=self._get_headers(), params=search_params)
                response.raise_for_status()
            except requests.exceptions.RequestException as e:
                self.logger.error(f"❌ Failed to fetch Lead by email: {e}")
                return {"success": False, "message": f"Failed to fetch Lead by email: {e}"}

            records = response.json().get("searchRecords", [])
            if not records:
                self.logger.warning(f"⚠️ No Lead found with email: {email}")
                return {"success": False, "message": f"No Lead found with email: {email}"}

            lead_id = records[0]["Id"]

            # Step 6: Update Lead
            try:
                update_url = f"{self.lead_base_url}{lead_id}"
                update_response = requests.patch(update_url, headers=self._get_headers(), json=update_data)
                update_response.raise_for_status()
            except requests.exceptions.RequestException as e:
                self.logger.error(f"❌ Failed to update Lead: {e}")
                return {"success": False, "message": f"Failed to update Lead: {e}"}

            self.logger.info(f"✅ Lead with email '{email}' updated successfully.")
            return {"success": True, "message": f"Lead with email '{email}' updated successfully."}

        except Exception as e:
            self.logger.exception(f"🔥 Unexpected error occurred: {e}")
            return {"success": False, "message": f"Unexpected error: {e}"}

    def get_lead_by_email(self, email: str) -> Optional[Dict[str, Any]]:
        """
        Fetch lead details from Salesforce using REST API (no SOQL used).

        Args:
            email (str): The email address of the lead to fetch.

        Returns:
            dict | None:
                - On success → Returns the lead details as a dictionary.
                - If no lead is found or request fails → Returns an empty dictionary.
        """
        self.logger.info("Fetching lead details for email: %s", email)

        url = f"{self.data_url}/parameterizedSearch"
        params = {
            "q": email,
            "sobject": "Lead",
            "Lead.fields": (
                "Id, FirstName, LastName, Email, Company, Title, Phone, "
                "Street, City, State, PostalCode, Country, LeadSource, Status, "
                "Description, Website, Rating, Industry, AnnualRevenue, NumberOfEmployees"
            ),
            "in": "Email"  # Only search within Email field
        }

        try:
            response = requests.get(url, headers=self._get_headers(), params=params)

            if response.status_code != 200:
                self.logger.error(
                    "❌ Failed to fetch lead. Status Code: %s | Response: %s",
                    response.status_code, response.text
                )
                return {}

            records = response.json().get("searchRecords", [])
            if not records:
                self.logger.warning("❌ No lead found with email: %s", email)
                return {}

            lead = records[0]
            self.logger.info("✅ Lead found for email: %s | Lead ID: %s", email, lead.get("Id"))
            return lead

        except requests.exceptions.RequestException as e:
            self.logger.exception("❌ Exception occurred while fetching lead: %s", e)
            return {}

    def get_all_leads(self) -> List[Dict[str, Any]]:
        """
        Fetch all Salesforce leads using the REST API (no SOQL).
        Uses Salesforce's /sobjects/Lead endpoint with pagination.

        Returns:
            list: A list of lead dictionaries.
        """

        all_leads = []

        try:
            # Base API URL for leads
            leads_url = f"{self.lead_base_url}"

            while leads_url:
                response = requests.get(leads_url, headers=self._get_headers())
                print(response.url, "==================")
                if response.status_code != 200:
                    self.logger.error("❌ Failed to fetch leads. Status: %s | Response: %s",
                                      response.status_code, response.text)
                    traceback.print_exc()
                    break

                data = response.json()
                # print(data.get("recentItems")[0]["attributes"].get("url"),"==================")

                # Salesforce returns 'recentItems' in /sobjects/Lead by default,
                # but we want all leads, so we use /queryAllRecords endpoint from 'sobjects'.

                if "recentItems" in data:
                    print(data.get("recentItems")[0]["attributes"].get("url"), "==================")
                    all_leads.extend(data["recentItems"])

                # Check if there's a next page
                leads_url = data.get("nextRecordsUrl")
                if leads_url:
                    leads_url = f"{self.instance_url}{leads_url}"

            self.logger.info("✅ Successfully fetched %d leads.", len(all_leads))
            return all_leads

        except requests.exceptions.RequestException as e:
            self.logger.exception("❌ Exception occurred while fetching leads: %s", e)
            traceback.print_exc()
            return []

    def delete_lead_by_email(self, email: str) -> bool:
        """
        Delete a Salesforce lead using the lead's email via REST API (no SOQL used).

        Args:
            email (str): The email address of the lead to delete.

        Returns:
            bool:
                - True → Lead deleted successfully.
                - False → Lead not found, multiple leads exist, or deletion failed.
        """
        self.logger.info("Deleting lead with email: %s", email)

        search_url = f"{self.data_url}/parameterizedSearch"
        params = {
            "q": email,
            "sobject": "Lead",
            "Lead.fields": "Id",
            "in": "Email"  # Search only in Email field
        }

        try:
            # Fetch lead details by email (no SOQL)
            response = requests.get(search_url, headers=self._get_headers(), params=params)

            if response.status_code != 200:
                self.logger.error(
                    "❌ Failed to fetch lead for deletion. Status Code: %s | Response: %s",
                    response.status_code, response.text
                )
                return False

            records = response.json().get("searchRecords", [])
            if not records:
                self.logger.warning("⚠️ No lead found with email: %s", email)
                return False

            if len(records) > 1:
                self.logger.warning(
                    "⚠️ Multiple leads found with email: %s. Deletion aborted.",
                    email
                )
                return False

            # Extract lead ID
            lead_id = records[0]["Id"]
            delete_url = f"{self.lead_base_url}{lead_id}"
            self.logger.info("Deleting lead with ID: %s", lead_id)

            # Perform DELETE request
            delete_response = requests.delete(delete_url, headers=self._get_headers())

            if delete_response.status_code == 204:
                self.logger.info("🗑️ Lead with email '%s' deleted successfully!", email)
                return True
            else:
                self.logger.error(
                    "❌ Failed to delete lead. Status Code: %s | Response: %s",
                    delete_response.status_code, delete_response.text
                )
                return False

        except requests.exceptions.RequestException as e:
            self.logger.exception("❌ Exception occurred while deleting lead: %s", e)
            return False

    # -------------------------------
    # Fetching all Lead  Saving in csv
    # -------------------------------

    def get_all_leads_and_save_csv(self, filename: Optional[str] = None, path: Optional[str] = None) -> str:
        """
        Fetch all Salesforce leads including Owner Alias and save them into a CSV file.

        This function:
            1. Retrieves all Lead fields + related Owner fields (Alias, Name, Email).
            2. Fetches all leads via Salesforce REST API with pagination.
            3. Saves the leads into a CSV file.

        Args:
            filename (str, optional): CSV file name. Defaults to 'salesforce_leads.csv'.
            path (str, optional): Directory path to save the CSV. Defaults to current working directory.

        Returns:
            str: Full path to the saved CSV file.

        Raises:
            RuntimeError: If fetching fields or leads fails.
        """
        self.logger.info("📄 Fetching all Salesforce leads including Owner Alias...")

        # Step 1: Setup CSV filename and path
        if not filename:
            filename = "salesforce_leads.csv"

        if not path:
            path = os.getcwd()

        os.makedirs(path, exist_ok=True)
        file_path = os.path.join(path, filename)

        # Step 2: Get Lead fields dynamically
        describe_url = f"{self.lead_base_url}describe"
        describe_response = requests.get(describe_url, headers=self._get_headers())

        if describe_response.status_code != 200:
            raise RuntimeError(f"Failed to fetch Lead fields: {describe_response.text}")

        describe_data = describe_response.json()
        lead_fields = [field["name"] for field in describe_data["fields"]]

        # Add Owner-related fields manually (not included in describe API)
        lead_fields.extend(["Owner.Alias", "Owner.Name", "Owner.Email"])

        self.logger.info("✅ Retrieved %d fields for Lead object (including Owner fields).", len(lead_fields))

        # Step 3: Prepare SOQL query including Owner fields
        soql_query = f"SELECT {', '.join(lead_fields)} FROM Lead"
        query_url = f"{self.data_url}/query"
        all_leads = []

        # Step 4: Fetch leads with pagination
        while query_url:
            response = requests.get(query_url, headers=self._get_headers(), params={"q": soql_query})
            if response.status_code != 200:
                raise RuntimeError(f"Failed to fetch leads: {response.text}")

            data = response.json()
            records = data.get("records", [])
            all_leads.extend(records)

            # Pagination support
            query_url = f"{self.instance_url}{data.get('nextRecordsUrl')}" if data.get("nextRecordsUrl") else None

        self.logger.info("✅ Retrieved total %d leads.", len(all_leads))

        # Step 5: Write leads into CSV
        with open(file_path, mode="w", newline="", encoding="utf-8") as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=lead_fields)
            writer.writeheader()

            for lead in all_leads:
                clean_lead = {}
                for field in lead_fields:
                    if "." in field:  # Handle nested fields like Owner.Alias
                        parent, child = field.split(".")
                        clean_lead[field] = lead.get(parent, {}).get(child, None)
                    else:
                        clean_lead[field] = lead.get(field, None)
                writer.writerow(clean_lead)

        self.logger.info("📄 Leads saved successfully at: %s", file_path)
        return file_path


if __name__ == "__main__":
    #   To test the class pass the required fields to the SalesforceConnector
    pass
