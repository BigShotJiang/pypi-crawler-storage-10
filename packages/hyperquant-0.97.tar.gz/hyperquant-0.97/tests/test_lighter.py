import pybotters

# from hyperquant.broker.coinup import Coinup, CoinUpDataStore
from hyperquant.broker.lighter import Lighter
import asyncio
from logging import Logger
import time
from dataclasses import dataclass
from typing import Any, Literal
from hyperquant.logkit import get_logger
from hyperquant.broker.coinup import Coinup

apis = {
    'l1_address': '0x5B3f0AdDfaf4c1d8729e266b22093545EFaE6c0e',
    'secret': '0x56c10a3dfa3e9d27a69044b16300bd529b1d073774fedc138433aa16328b56e3813026b60e396500'
}


async def test_update():
    async with pybotters.Client() as client:
        async with Lighter(
            client=client,
            **apis
        ) as broker:
            print(broker.account_index)
            # print(broker.store.detail.find({'symbol': 'DOLO'}))
            # print(broker.get_contract_id('BTC'))
            # await broker.update('orders', symbol='DOLO')
            # print(broker.store.orders.find())
            # await broker.update('account')
            # print(broker.store.accounts.find())

            # await broker.update("positions")
            # print(broker.store.positions.find())

            await broker.update('history_orders')
            print(broker.store.orders.get({
                'order_id': '21673573193672683'
            }))
            pass



async def test_sub_book():
    async with pybotters.Client() as client:
        async with Lighter(client=client) as broker:
            broker.store.book.limit = 1

            await broker.sub_orderbook("VVV")
            i = 0
            try:
                async with asyncio.timeout(15):
                    while True:
                        await broker.store.book.wait()
                        # print(broker.store.book.find())
                        asks = broker.store.book.find({"S": "a"})
                        bids = broker.store.book.find({"S": "b"})
                        # 订单薄format化输出
                        print("Asks:")
                        for ask in asks:
                            print(
                                f"Price: {ask['p']}, Size: {ask['s']}, Symbol: {ask['s']} quantity: {ask['q']}"
                            )
                        print("Bids:")
                        for bid in bids:
                            print(
                                f"Price: {bid['p']}, Size: {bid['s']}, Symbol: {bid['s']} quantity: {bid['q']}"
                            )
                        print("-" * 20)

            except asyncio.TimeoutError:
                print("测试结束")
                exit(0)


async def test_place():
    async with pybotters.Client() as client:
        async with Lighter(
            client=client,
            **apis
        ) as broker:
            order = await broker.place_order(
                symbol="DOLO",
                base_amount=146.7,
                price=0.075,
                is_ask=False,
                order_type="limit",
            )
            print(order)


async def test_place_cancel():
    async with pybotters.Client() as client:
        async with Lighter(
            client=client,
            **apis
        ) as broker:
            order = await broker.place_order(
                symbol="DOLO",
                base_amount=146.7,
                price=0.075,
                is_ask=False,
                order_type="limit",
                client_order_index=112
            )
            print(order)

            res = await broker.cancel_order('DOLO', order_index=112)
            print(res)



if __name__ == "__main__":
    import asyncio

    asyncio.run(test_update())
