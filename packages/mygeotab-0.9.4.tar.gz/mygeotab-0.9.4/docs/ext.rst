Extras
======

Extras for easier querying of the MyGeotab API. Note that these are currently experimental, and likely to change at any
time without notice.

Data Feed
---------

Handler to get data as efficiently as possible.

A simple example package can be found in the `/examples` directory.

See the API reference for the :class:`DataFeed <mygeotab.ext.feed.DataFeed>` and
:class:`DataFeedListener <mygeotab.ext.feed.DataFeedListener>` classes for more information.