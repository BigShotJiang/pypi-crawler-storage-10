.. MyGeotab Python SDK documentation master file, created by
   sphinx-quickstart on Wed Oct  1 20:55:06 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: ../README.rst

.. include:: ../CHANGELOG.rst

User Guide
----------

How to use this library, and more information about bundled tools and examples.

.. toctree::
   :maxdepth: 2

   usage
   commandline
   ext

API Reference
-------------

The full API reference for all public classes and functions.

.. toctree::
   :maxdepth: 2

   api
   altitude
