# Input

::: sober.input
