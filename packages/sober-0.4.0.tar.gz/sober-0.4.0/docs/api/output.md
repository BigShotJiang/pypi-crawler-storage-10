# Output

::: sober.output
