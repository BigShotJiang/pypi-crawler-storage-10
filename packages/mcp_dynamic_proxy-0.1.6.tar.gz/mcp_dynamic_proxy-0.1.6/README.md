# MCP Dynamic Proxy

A dynamic MCP (Model Context Protocol) proxy server that provides progressive discovery and lazy loading of MCP servers, reducing initial context size from 20-300 tools to just 3 core tools.

## How it works

```
Assistant (Cursor) -MCP-> MCP Dynamic Proxy -MCP-> MCP Servers (AWS, PostgreSQL, etc.)
```

The proxy exposes only 3 core tools that let you discover and interact with any number of configured MCP servers without loading them all upfront.

## Tools

### mcp_list_servers
List all configured MCP servers with their metadata (id, description, tags, principal tools).

**Parameters:** None

**Returns:** `{count: int, servers: [...]}`

### mcp_list_tools
List all tools from a specific MCP server with their JSON schemas. Automatically loads the server if needed.

**Parameters:**
- `server_id` (required): The MCP server ID (e.g., `"aws-knowledge-mcp-server"`)

**Returns:** `{server_id: str, status: "loaded" | "error", tool_count: int, tools: [...], error?: str}`

### mcp_execute_tool
Execute a tool from a specific MCP server. Automatically loads the server if needed.

**Parameters:**
- `server_id` (required): The MCP server ID
- `tool_name` (required): The tool name (e.g., `"aws___read_documentation"`)
- `arguments` (required): Dictionary matching the tool's JSON schema

**Returns:** `{server_id: str, tool_name: str, status: "success" | "error", result?: any, error?: str}`

## Configuration

### config/mcp.json

Create a `config/mcp.json` file with your MCP server configurations:

```json
{
  "version": "1.0",
  "mcpServers": {
    "aws-knowledge-mcp-server": {
      "description": "AWS knowledge base with documentation, best practices, and service information",
      "tags": ["aws", "documentation", "cloud", "knowledge"],
      "tools": ["aws___read_documentation", "aws___search_documentation"],
      "command": "uvx",
      "args": ["fastmcp", "run", "https://knowledge-mcp.global.api.aws"]
    },
    "microsoft.docs.mcp": {
      "description": "Microsoft Learn documentation and Azure documentation access",
      "tags": ["microsoft", "azure", "documentation", "learn"],
      "tools": ["microsoft_docs_search", "microsoft_code_sample_search", "microsoft_docs_fetch"],
      "command": "uvx",
      "args": ["fastmcp", "run", "https://learn.microsoft.com/api/mcp"]
    }
  }
}
```

**Configuration fields:**
- `description`: Human-readable description
- `tags`: List of tags for organization
- `tools`: Optional list of principal tool names (not exhaustive)
- `command`: Command to start the MCP server
- `args`: Arguments for the command
- `env`: Optional environment variables (supports `${VAR_NAME}` expansion)

### Cursor Configuration

Add to your Cursor MCP configuration:

```json
{
  "mcpServers": {
    "mcp-dynamic-proxy": {
      "command": "uvx",
      "args": ["mcp-dynamic-proxy"],
      "env": {
        "MCP_CONFIG_PATH": "/path/to/config/mcp.json"
      }
    }
  }
}
```

## License

MIT
