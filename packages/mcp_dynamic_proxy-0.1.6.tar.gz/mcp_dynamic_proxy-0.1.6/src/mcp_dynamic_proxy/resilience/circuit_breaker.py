"""
Circuit Breaker implementation for fault tolerance.

Implements the Circuit Breaker pattern to prevent cascading failures:
- CLOSED: Normal operation, all requests pass through
- OPEN: Too many failures, fail fast without trying
- HALF_OPEN: Testing if service recovered, limited requests allowed

Key features:
- Configurable failure threshold and timeout
- Exponential backoff for recovery attempts
- Thread-safe with asyncio.Lock
- Detailed state tracking and metrics
"""

import asyncio
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Callable, TypeVar, ParamSpec

import structlog

from ..core.models import CircuitBreakerState

logger = structlog.get_logger(__name__)

P = ParamSpec("P")
T = TypeVar("T")


class CircuitBreakerError(Exception):
    """Raised when circuit breaker is open."""

    pass


@dataclass
class CircuitBreakerConfig:
    """Configuration for circuit breaker."""

    # Failure threshold: open circuit after N consecutive failures
    failure_threshold: int = 5

    # Success threshold in HALF_OPEN: close circuit after N consecutive successes
    success_threshold: int = 2

    # Timeout before attempting recovery (seconds)
    timeout: float = 60.0

    # Exponential backoff multiplier for repeated failures
    backoff_multiplier: float = 2.0

    # Maximum timeout (seconds)
    max_timeout: float = 600.0

    # Half-open request limit: how many concurrent requests in HALF_OPEN state
    half_open_max_requests: int = 1


@dataclass
class CircuitBreakerMetrics:
    """Metrics tracked by circuit breaker."""

    # State
    state: CircuitBreakerState = CircuitBreakerState.CLOSED
    opened_at: datetime | None = None
    last_failure_time: datetime | None = None
    next_attempt_time: datetime | None = None

    # Counters
    consecutive_failures: int = 0
    consecutive_successes: int = 0
    total_calls: int = 0
    total_successes: int = 0
    total_failures: int = 0
    total_rejected: int = 0

    # Half-open state
    half_open_requests: int = 0

    # Current timeout (with exponential backoff)
    current_timeout: float = field(default=60.0)


class CircuitBreaker:
    """
    Circuit breaker for protecting against cascading failures.

    Usage:
        cb = CircuitBreaker("my-service")

        async def my_operation():
            return await external_service_call()

        try:
            result = await cb.call(my_operation)
        except CircuitBreakerError:
            # Circuit is open, fail fast
            logger.error("Circuit breaker is open")
    """

    def __init__(self, name: str, config: CircuitBreakerConfig | None = None):
        """
        Initialize circuit breaker.

        Args:
            name: Circuit breaker name (for logging)
            config: Optional configuration (uses defaults if not provided)
        """
        self.name = name
        self.config = config or CircuitBreakerConfig()
        self.metrics = CircuitBreakerMetrics(current_timeout=self.config.timeout)
        self._lock = asyncio.Lock()

        logger.debug(
            "circuit_breaker_created",
            name=name,
            failure_threshold=self.config.failure_threshold,
            timeout=self.config.timeout,
        )

    @property
    def state(self) -> CircuitBreakerState:
        """Current circuit breaker state."""
        return self.metrics.state

    async def call(self, func: Callable[P, T], *args: P.args, **kwargs: P.kwargs) -> T:
        """
        Execute function with circuit breaker protection.

        Args:
            func: Async function to execute
            *args: Positional arguments for func
            **kwargs: Keyword arguments for func

        Returns:
            Result from func

        Raises:
            CircuitBreakerError: If circuit is open
            Exception: Any exception from func
        """
        async with self._lock:
            self.metrics.total_calls += 1

            # Check if we can proceed
            if self.metrics.state == CircuitBreakerState.OPEN:
                # Check if timeout has passed
                if self.metrics.next_attempt_time and datetime.now() >= self.metrics.next_attempt_time:
                    # Transition to HALF_OPEN
                    self._transition_to_half_open()
                else:
                    # Still open, reject request
                    self.metrics.total_rejected += 1
                    raise CircuitBreakerError(
                        f"Circuit breaker '{self.name}' is OPEN. "
                        f"Next attempt at {self.metrics.next_attempt_time}"
                    )

            elif self.metrics.state == CircuitBreakerState.HALF_OPEN:
                # Check if we've reached half-open request limit
                if self.metrics.half_open_requests >= self.config.half_open_max_requests:
                    self.metrics.total_rejected += 1
                    raise CircuitBreakerError(
                        f"Circuit breaker '{self.name}' is HALF_OPEN with max concurrent requests"
                    )
                self.metrics.half_open_requests += 1

        # Execute function
        try:
            result = await func(*args, **kwargs)

            # Success - update metrics
            async with self._lock:
                await self._on_success()

            return result

        except Exception as e:
            # Failure - update metrics
            async with self._lock:
                await self._on_failure(e)

            raise

    async def _on_success(self) -> None:
        """Handle successful execution."""
        self.metrics.total_successes += 1
        self.metrics.consecutive_successes += 1
        self.metrics.consecutive_failures = 0

        if self.metrics.state == CircuitBreakerState.HALF_OPEN:
            self.metrics.half_open_requests -= 1

            # Check if we can close the circuit
            if self.metrics.consecutive_successes >= self.config.success_threshold:
                self._transition_to_closed()

        logger.debug(
            "circuit_breaker_success",
            name=self.name,
            state=self.metrics.state.value,
            consecutive_successes=self.metrics.consecutive_successes,
        )

    async def _on_failure(self, error: Exception) -> None:
        """Handle failed execution."""
        self.metrics.total_failures += 1
        self.metrics.consecutive_failures += 1
        self.metrics.consecutive_successes = 0
        self.metrics.last_failure_time = datetime.now()

        if self.metrics.state == CircuitBreakerState.HALF_OPEN:
            self.metrics.half_open_requests -= 1
            # HALF_OPEN failure → back to OPEN with increased timeout
            self._transition_to_open(increase_timeout=True)

        elif self.metrics.state == CircuitBreakerState.CLOSED:
            # Check if we should open the circuit
            if self.metrics.consecutive_failures >= self.config.failure_threshold:
                self._transition_to_open(increase_timeout=False)

        logger.warning(
            "circuit_breaker_failure",
            name=self.name,
            state=self.metrics.state.value,
            consecutive_failures=self.metrics.consecutive_failures,
            error=str(error),
        )

    def _transition_to_open(self, increase_timeout: bool) -> None:
        """Transition to OPEN state."""
        if increase_timeout:
            # Exponential backoff
            self.metrics.current_timeout = min(
                self.metrics.current_timeout * self.config.backoff_multiplier,
                self.config.max_timeout,
            )

        self.metrics.state = CircuitBreakerState.OPEN
        self.metrics.opened_at = datetime.now()
        self.metrics.next_attempt_time = datetime.now() + timedelta(
            seconds=self.metrics.current_timeout
        )

        logger.warning(
            "circuit_breaker_opened",
            name=self.name,
            consecutive_failures=self.metrics.consecutive_failures,
            timeout=self.metrics.current_timeout,
            next_attempt=self.metrics.next_attempt_time.isoformat(),
        )

    def _transition_to_half_open(self) -> None:
        """Transition to HALF_OPEN state."""
        self.metrics.state = CircuitBreakerState.HALF_OPEN
        self.metrics.consecutive_successes = 0
        self.metrics.half_open_requests = 0

        logger.debug(
            "circuit_breaker_half_opened",
            name=self.name,
            time_in_open=str(datetime.now() - self.metrics.opened_at)
            if self.metrics.opened_at
            else None,
        )

    def _transition_to_closed(self) -> None:
        """Transition to CLOSED state."""
        self.metrics.state = CircuitBreakerState.CLOSED
        self.metrics.consecutive_failures = 0
        self.metrics.consecutive_successes = 0
        self.metrics.opened_at = None
        self.metrics.next_attempt_time = None

        # Reset timeout to base value
        self.metrics.current_timeout = self.config.timeout

        logger.debug(
            "circuit_breaker_closed",
            name=self.name,
            consecutive_successes=self.metrics.consecutive_successes,
        )

    def get_metrics(self) -> dict:
        """
        Get current metrics.

        Returns:
            Dictionary with circuit breaker metrics
        """
        return {
            "name": self.name,
            "state": self.metrics.state.value,
            "opened_at": self.metrics.opened_at.isoformat() if self.metrics.opened_at else None,
            "last_failure_time": self.metrics.last_failure_time.isoformat()
            if self.metrics.last_failure_time
            else None,
            "next_attempt_time": self.metrics.next_attempt_time.isoformat()
            if self.metrics.next_attempt_time
            else None,
            "consecutive_failures": self.metrics.consecutive_failures,
            "consecutive_successes": self.metrics.consecutive_successes,
            "total_calls": self.metrics.total_calls,
            "total_successes": self.metrics.total_successes,
            "total_failures": self.metrics.total_failures,
            "total_rejected": self.metrics.total_rejected,
            "current_timeout": self.metrics.current_timeout,
        }

    async def reset(self) -> None:
        """Reset circuit breaker to CLOSED state."""
        async with self._lock:
            self.metrics = CircuitBreakerMetrics(current_timeout=self.config.timeout)
            logger.debug("circuit_breaker_reset", name=self.name)
