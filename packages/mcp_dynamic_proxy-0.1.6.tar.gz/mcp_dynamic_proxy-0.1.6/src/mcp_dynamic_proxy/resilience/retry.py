"""
Retry logic with exponential backoff for transient failures.

Uses tenacity for sophisticated retry strategies:
- Exponential backoff with jitter
- Configurable max attempts and delays
- Retry only on specific exceptions
- Detailed logging for debugging
"""

import asyncio
import logging
from dataclasses import dataclass
from typing import Callable, TypeVar, ParamSpec, Type

import structlog
from tenacity import (
    AsyncRetrying,
    RetryError,
    stop_after_attempt,
    wait_exponential_jitter,
    retry_if_exception_type,
    before_sleep_log,
)

logger = structlog.get_logger(__name__)

P = ParamSpec("P")
T = TypeVar("T")


@dataclass
class RetryConfig:
    """Configuration for retry logic."""

    # Maximum number of retry attempts (including first attempt)
    max_attempts: int = 3

    # Minimum wait time between retries (seconds)
    min_wait: float = 1.0

    # Maximum wait time between retries (seconds)
    max_wait: float = 10.0

    # Jitter to add to exponential backoff (prevents thundering herd)
    jitter: float = 2.0

    # Exceptions to retry on
    # Note: asyncio.TimeoutError covers connection timeouts
    # OSError covers network errors including connection errors
    retryable_exceptions: tuple[Type[Exception], ...] = (
        asyncio.TimeoutError,
        OSError,  # Network errors, connection errors
        TimeoutError,  # Standard timeout error
    )


class RetryableOperation:
    """
    Wrapper for operations that should be retried on transient failures.

    Usage:
        config = RetryConfig(max_attempts=3)
        retry_op = RetryableOperation("my-operation", config)

        result = await retry_op.execute(my_async_function, arg1, arg2)
    """

    def __init__(self, operation_name: str, config: RetryConfig | None = None):
        """
        Initialize retryable operation.

        Args:
            operation_name: Name of operation (for logging)
            config: Retry configuration
        """
        self.operation_name = operation_name
        self.config = config or RetryConfig()

        logger.debug(
            "retryable_operation_created",
            operation=operation_name,
            max_attempts=self.config.max_attempts,
            min_wait=self.config.min_wait,
            max_wait=self.config.max_wait,
        )

    async def execute(
        self, func: Callable[P, T], *args: P.args, **kwargs: P.kwargs
    ) -> T:
        """
        Execute function with retry logic.

        Args:
            func: Async function to execute
            *args: Positional arguments for func
            **kwargs: Keyword arguments for func

        Returns:
            Result from func

        Raises:
            RetryError: If all retry attempts failed
            Exception: Any non-retryable exception from func
        """
        # Create tenacity retrying instance
        retrying = AsyncRetrying(
            # Stop after max attempts
            stop=stop_after_attempt(self.config.max_attempts),
            # Exponential backoff with jitter
            wait=wait_exponential_jitter(
                initial=self.config.min_wait,
                max=self.config.max_wait,
                jitter=self.config.jitter,
            ),
            # Only retry on specific exceptions
            retry=retry_if_exception_type(self.config.retryable_exceptions),
            # Log before each retry
            before_sleep=before_sleep_log(logger, logging.WARNING),
            reraise=True,
        )

        attempt = 0

        try:
            async for attempt_state in retrying:
                with attempt_state:
                    attempt += 1

                    logger.debug(
                        "retry_attempt",
                        operation=self.operation_name,
                        attempt=attempt,
                        max_attempts=self.config.max_attempts,
                    )

                    # Execute function
                    result = await func(*args, **kwargs)

                    logger.debug(
                        "retry_success",
                        operation=self.operation_name,
                        attempt=attempt,
                    )

                    return result

        except RetryError as e:
            # All retry attempts failed
            logger.error(
                "retry_exhausted",
                operation=self.operation_name,
                attempts=attempt,
                error=str(e.last_attempt.exception()),
            )
            raise

        except Exception as e:
            # Non-retryable exception
            logger.warning(
                "retry_non_retryable_error",
                operation=self.operation_name,
                error=str(e),
                error_type=type(e).__name__,
            )
            raise

        # Should never reach here, but satisfy type checker
        raise RuntimeError("Unexpected retry state")


# Convenience function for one-off retries
async def retry_async(
    func: Callable[P, T],
    *args: P.args,
    operation_name: str = "operation",
    config: RetryConfig | None = None,
    **kwargs: P.kwargs,
) -> T:
    """
    Execute async function with retry logic (convenience function).

    Args:
        func: Async function to execute
        *args: Positional arguments for func
        operation_name: Operation name for logging
        config: Optional retry configuration
        **kwargs: Keyword arguments for func

    Returns:
        Result from func

    Raises:
        RetryError: If all retry attempts failed
        Exception: Any non-retryable exception from func
    """
    retry_op = RetryableOperation(operation_name, config)
    return await retry_op.execute(func, *args, **kwargs)
