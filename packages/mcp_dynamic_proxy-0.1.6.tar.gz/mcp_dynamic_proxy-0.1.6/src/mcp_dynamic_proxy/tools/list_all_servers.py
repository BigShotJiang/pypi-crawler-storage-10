"""Tool implementation: mcp_list_all_servers"""

from ..registry import ServerRegistry


async def execute(registry: ServerRegistry) -> dict:
    """
    Execute mcp_list_all_servers tool - list all available MCP servers with their descriptions.

    This tool returns all configured MCP servers without any filtering,
    providing complete metadata including descriptions, tags, and tools.

    Args:
        registry: Server registry instance

    Returns:
        Dictionary with count and complete list of all available servers
    """
    servers = registry.list_all()

    return {
        "count": len(servers),
        "servers": [
            {
                "id": s.id,
                "description": s.description,
                "tags": s.tags,
                "tools": s.tools,
            }
            for s in servers
        ],
    }
