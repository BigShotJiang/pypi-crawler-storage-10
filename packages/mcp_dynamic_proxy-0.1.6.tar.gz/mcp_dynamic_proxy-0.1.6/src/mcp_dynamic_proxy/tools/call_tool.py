"""Tool implementation: mcp_execute_tool"""

from typing import Any
import jsonschema
from jsonschema import ValidationError as JSONSchemaValidationError
import structlog
from ..core.manager import ConnectionManager

logger = structlog.get_logger(__name__)


async def execute(
    manager: ConnectionManager,
    server_id: str,
    tool_name: str,
    arguments: dict[str, Any],
) -> dict:
    """
    Execute mcp_execute_tool - call a tool from a specific MCP server.

    Args:
        manager: Connection manager instance
        server_id: The MCP server ID
        tool_name: Name of the tool to call
        arguments: Dictionary of arguments to pass to the tool

    Returns:
        Dictionary with tool execution result
    """
    try:
        # First, get the tool schema for validation
        tools = await manager.get_tools(server_id)
        tool_schema = None
        for tool in tools:
            if tool.name == tool_name:
                tool_schema = tool.inputSchema
                break

        if tool_schema is None:
            return {
                "server_id": server_id,
                "tool_name": tool_name,
                "status": "error",
                "error": f"Tool '{tool_name}' not found in server '{server_id}'",
            }

        # Validate arguments against schema
        try:
            jsonschema.validate(instance=arguments, schema=tool_schema)
        except JSONSchemaValidationError as ve:
            return {
                "server_id": server_id,
                "tool_name": tool_name,
                "status": "error",
                "error": f"Invalid arguments: {ve.message}",
            }

        # Execute the tool
        result = await manager.call_tool(server_id, tool_name, arguments)
        
        return {
            "server_id": server_id,
            "tool_name": tool_name,
            "status": "success",
            "result": result,
        }
    except ValueError as e:
        logger.warning("call_tool_value_error", server_id=server_id, tool_name=tool_name, error=str(e))
        return {
            "server_id": server_id,
            "tool_name": tool_name,
            "status": "error",
            "error": "Invalid server ID or tool not found",
        }
    except RuntimeError as e:
        logger.warning("call_tool_runtime_error", server_id=server_id, tool_name=tool_name, error=str(e))
        return {
            "server_id": server_id,
            "tool_name": tool_name,
            "status": "error",
            "error": "Tool execution failed",
        }
    except Exception as e:
        logger.error("call_tool_unexpected_error", server_id=server_id, tool_name=tool_name, error=str(e), error_type=type(e).__name__)
        return {
            "server_id": server_id,
            "tool_name": tool_name,
            "status": "error",
            "error": "Internal server error",
        }

