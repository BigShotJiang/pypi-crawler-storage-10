"""Tool implementation: mcp_list_tools"""

import structlog
from ..core.manager import ConnectionManager

logger = structlog.get_logger(__name__)


async def execute(manager: ConnectionManager, server_id: str) -> dict:
    """
    Execute mcp_list_tools tool - get tools from a specific MCP server.

    Args:
        manager: Connection manager instance
        server_id: The MCP server ID to query

    Returns:
        Dictionary with server info and list of available tools
    """
    try:
        tools = await manager.get_tools(server_id)

        # Helper to safely convert inputSchema to dict
        def get_input_schema(tool):
            if not tool.inputSchema:
                return {}
            # Check if it's already a dict
            if isinstance(tool.inputSchema, dict):
                return tool.inputSchema
            # Try to call model_dump() if it's a Pydantic model
            if hasattr(tool.inputSchema, 'model_dump'):
                return tool.inputSchema.model_dump()
            # Fallback: try dict() conversion
            try:
                return dict(tool.inputSchema)
            except:
                return {}

        return {
            "server_id": server_id,
            "status": "loaded",
            "tool_count": len(tools),
            "tools": [
                {
                    "name": tool.name,
                    "description": tool.description or "",
                    "input_schema": get_input_schema(tool),
                }
                for tool in tools
            ],
        }
    except ValueError as e:
        logger.warning("list_tools_value_error", server_id=server_id, error=str(e))
        return {
            "server_id": server_id,
            "status": "error",
            "error": "Invalid server ID or server not found",
        }
    except RuntimeError as e:
        logger.warning("list_tools_runtime_error", server_id=server_id, error=str(e))
        return {
            "server_id": server_id,
            "status": "error",
            "error": "Server connection error",
        }
    except Exception as e:
        logger.error("list_tools_unexpected_error", server_id=server_id, error=str(e), error_type=type(e).__name__)
        return {
            "server_id": server_id,
            "status": "error",
            "error": "Internal server error",
        }

