"""Server Registry - Manages MCP server metadata."""

from dataclasses import dataclass
from typing import Dict, List, Optional


@dataclass
class ServerMetadata:
    """Metadata for an MCP server."""
    
    id: str
    description: str
    tags: List[str]
    command: str
    args: List[str]
    env: Dict[str, str]
    lazy_load: bool
    cache_ttl: int
    tools: List[str]


class ServerRegistry:
    """Registry for MCP server metadata with search and filter capabilities."""
    
    def __init__(self, config: dict):
        """
        Initialize registry from configuration.
        
        Args:
            config: Configuration dictionary from load_config()
        """
        self.servers: Dict[str, ServerMetadata] = {}
        self._load_from_config(config)
    
    def _load_from_config(self, config: dict):
        """Load server metadata from configuration."""
        mcp_servers = config.get("mcpServers", {})
        
        for server_id, server_config in mcp_servers.items():
            self.servers[server_id] = ServerMetadata(
                id=server_id,
                description=server_config.get("description", ""),
                tags=server_config.get("tags", []),
                command=server_config.get("command"),
                args=server_config.get("args", []),
                env=server_config.get("env", {}),
                lazy_load=server_config.get("lazy_load", True),
                cache_ttl=server_config.get("cache_ttl", 3600),
                tools=server_config.get("tools", []),
            )
    
    def search(
        self,
        tags: Optional[List[str]] = None,
        search: Optional[str] = None,
    ) -> List[ServerMetadata]:
        """
        Search servers by tags or description.

        Uses a permissive scoring system with OR logic - servers matching ANY
        search term are included, sorted by relevance score. This allows the
        assistant to get a broader list and make its own selection.

        Args:
            tags: Optional list of tags to filter by (any match)
            search: Optional search term to filter by (word-based matching with scoring)

        Returns:
            List of matching ServerMetadata objects, sorted by relevance
        """
        results = list(self.servers.values())

        if tags:
            # Match if any tag in the list matches any tag in server tags
            results = [
                s for s in results
                if any(tag.lower() in [t.lower() for t in s.tags] for tag in tags)
            ]

        if search:
            # Tokenize search query into words
            search_words = [word.lower() for word in search.split() if word.strip()]

            # Score-based matching (OR logic - match ANY word)
            scored_results = []

            for server in results:
                score = 0

                for search_word in search_words:
                    # +3 points: exact match in tags
                    if any(search_word == tag.lower() for tag in server.tags):
                        score += 3
                    # +2 points: exact match in ID
                    elif search_word == server.id.lower():
                        score += 2
                    # +2 points: substring match in tags
                    elif any(search_word in tag.lower() for tag in server.tags):
                        score += 2
                    # +1 point: substring match in ID
                    elif search_word in server.id.lower():
                        score += 1
                    # +1 point: substring match in description
                    elif search_word in server.description.lower():
                        score += 1

                # Include if score > 0 (matched at least one word)
                if score > 0:
                    scored_results.append((score, server))

            # Sort by score (highest first), then by ID for stable ordering
            scored_results.sort(key=lambda x: (-x[0], x[1].id))
            results = [server for _, server in scored_results]

        return results
    
    def get(self, server_id: str) -> Optional[ServerMetadata]:
        """
        Get server metadata by ID.
        
        Args:
            server_id: Server identifier
        
        Returns:
            ServerMetadata if found, None otherwise
        """
        return self.servers.get(server_id)
    
    def list_all(self) -> List[ServerMetadata]:
        """
        List all registered servers.
        
        Returns:
            List of all ServerMetadata objects
        """
        return list(self.servers.values())

