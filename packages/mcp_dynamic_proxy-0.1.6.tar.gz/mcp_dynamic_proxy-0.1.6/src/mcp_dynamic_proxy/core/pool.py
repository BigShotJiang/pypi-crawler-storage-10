"""
Connection Pool for MCP servers.

This module implements a sophisticated connection pool that manages multiple
connections to a single MCP server, providing:
- Connection reuse and lifecycle management
- Min/max pool sizing with dynamic scaling
- Health checks and automatic reconnection
- Connection recycling after max lifetime
- Queue-based connection acquisition with priority support
- Retry logic for connection establishment
"""

import asyncio
import time
from datetime import datetime, timedelta
from typing import Any

import structlog

from ..registry import ServerMetadata
from ..resilience import RetryConfig
from .connection import MCPConnection, ConnectionClosed, ConnectionTimeout
from .models import PoolStats, Priority

logger = structlog.get_logger(__name__)


class PoolExhausted(Exception):
    """Raised when pool is exhausted and cannot create more connections."""

    pass


class PoolClosed(Exception):
    """Raised when operation attempted on closed pool."""

    pass


class ConnectionPool:
    """
    Connection pool for a single MCP server.

    Manages a pool of MCPConnection instances with:
    - Dynamic sizing (min_size to max_size)
    - Connection reuse
    - Health checking
    - Automatic recycling
    - Fair acquisition with priority queuing
    """

    def __init__(
        self,
        metadata: ServerMetadata,
        min_size: int = 1,
        max_size: int = 5,
        acquire_timeout: float = 30.0,
        idle_timeout: float = 300.0,
        max_lifetime: float = 3600.0,
        start_timeout: float = 30.0,
        tool_timeout: float = 300.0,
        health_check_timeout: float = 5.0,
        health_check_interval: float = 30.0,
        retry_config: RetryConfig | None = None,
    ):
        """
        Initialize connection pool.

        Args:
            metadata: Server metadata
            min_size: Minimum number of connections to maintain
            max_size: Maximum number of connections allowed
            acquire_timeout: Timeout when acquiring connection
            idle_timeout: Close idle connections after this time
            max_lifetime: Recycle connections after this time
            start_timeout: Timeout for starting connections
            tool_timeout: Default tool execution timeout
            health_check_timeout: Health check timeout
            health_check_interval: Health check interval
            retry_config: Optional retry configuration for connections
        """
        self.metadata = metadata
        self.min_size = min_size
        self.max_size = max_size
        self.acquire_timeout = acquire_timeout
        self.idle_timeout = idle_timeout
        self.max_lifetime = max_lifetime
        self.start_timeout = start_timeout
        self.tool_timeout = tool_timeout
        self.health_check_timeout = health_check_timeout
        self.health_check_interval = health_check_interval
        self.retry_config = retry_config or RetryConfig()

        # Pool state
        self._connections: set[MCPConnection] = set()
        self._available: asyncio.Queue[MCPConnection] = asyncio.Queue()
        self._in_use: set[MCPConnection] = set()
        self._lock = asyncio.Lock()
        self._closed = True  # Pool starts in closed state (not yet started)

        # Background tasks
        self._health_check_task: asyncio.Task | None = None
        self._recycler_task: asyncio.Task | None = None

        # Statistics
        self._total_created = 0
        self._total_destroyed = 0
        self._total_acquire_timeouts = 0

        logger.debug(
            "pool_created",
            server_id=self.metadata.id,
            min_size=min_size,
            max_size=max_size,
        )

    async def start(self) -> None:
        """
        Start the pool.

        Creates minimum number of connections and starts background tasks.
        """
        async with self._lock:
            if not self._closed:
                raise RuntimeError("Pool already started")

            self._closed = False

            logger.debug("pool_starting", server_id=self.metadata.id)

            # Create minimum connections
            for i in range(self.min_size):
                try:
                    conn = await self._create_connection()
                    await self._available.put(conn)
                    logger.debug(
                        "pool_initial_connection_created",
                        server_id=self.metadata.id,
                        index=i,
                    )
                except Exception as e:
                    logger.error(
                        "pool_initial_connection_failed",
                        server_id=self.metadata.id,
                        index=i,
                        error=str(e),
                    )
                    # Continue trying to create others

            # Start background tasks
            self._health_check_task = asyncio.create_task(
                self._health_check_loop(), name=f"health-{self.metadata.id}"
            )
            self._recycler_task = asyncio.create_task(
                self._recycler_loop(), name=f"recycler-{self.metadata.id}"
            )

            logger.debug(
                "pool_started",
                server_id=self.metadata.id,
                connections=len(self._connections),
            )

    async def stop(self) -> None:
        """
        Stop the pool.

        Closes all connections and stops background tasks.
        """
        async with self._lock:
            if self._closed:
                return

            logger.debug("pool_stopping", server_id=self.metadata.id)
            self._closed = True

            # Stop background tasks
            if self._health_check_task:
                self._health_check_task.cancel()
                try:
                    await self._health_check_task
                except asyncio.CancelledError:
                    pass

            if self._recycler_task:
                self._recycler_task.cancel()
                try:
                    await self._recycler_task
                except asyncio.CancelledError:
                    pass

            # Close all connections
            all_conns = list(self._connections)
            for conn in all_conns:
                try:
                    await conn.stop()
                except Exception as e:
                    logger.warning(
                        "pool_connection_stop_error",
                        server_id=self.metadata.id,
                        error=str(e),
                    )

            self._connections.clear()
            self._in_use.clear()
            # Clear queue
            while not self._available.empty():
                try:
                    self._available.get_nowait()
                except asyncio.QueueEmpty:
                    break

            logger.debug("pool_stopped", server_id=self.metadata.id)

    async def acquire(
        self, priority: Priority = Priority.NORMAL, timeout: float | None = None
    ) -> MCPConnection:
        """
        Acquire a connection from the pool.

        Args:
            priority: Request priority (for future priority queue)
            timeout: Optional timeout (uses default if not specified)

        Returns:
            MCPConnection instance

        Raises:
            PoolClosed: If pool is closed
            PoolExhausted: If unable to get connection
            ConnectionTimeout: If acquisition times out
        """
        if self._closed:
            raise PoolClosed("Pool is closed")

        timeout = timeout or self.acquire_timeout
        start_time = time.perf_counter()

        try:
            while True:
                # Try to get available connection
                try:
                    conn = self._available.get_nowait()

                    # Check if connection is still valid
                    if await self._is_connection_valid(conn):
                        async with self._lock:
                            self._in_use.add(conn)
                        logger.debug(
                            "pool_connection_acquired",
                            server_id=self.metadata.id,
                            available=self._available.qsize(),
                            in_use=len(self._in_use),
                        )
                        return conn
                    else:
                        # Connection invalid, destroy and try again
                        await self._destroy_connection(conn)
                        continue

                except asyncio.QueueEmpty:
                    # No available connections, try to create new one
                    async with self._lock:
                        if len(self._connections) < self.max_size:
                            conn = await self._create_connection()
                            self._in_use.add(conn)
                            logger.debug(
                                "pool_connection_created_on_demand",
                                server_id=self.metadata.id,
                                total=len(self._connections),
                            )
                            return conn

                    # Pool exhausted, wait for connection to become available
                    elapsed = time.perf_counter() - start_time
                    remaining = timeout - elapsed
                    if remaining <= 0:
                        raise ConnectionTimeout(
                            f"Pool acquisition timed out after {timeout}s"
                        )

                    # Wait a bit and retry
                    await asyncio.sleep(min(0.1, remaining))

        except ConnectionTimeout:
            self._total_acquire_timeouts += 1
            raise

    async def release(self, conn: MCPConnection) -> None:
        """
        Release a connection back to the pool.

        Args:
            conn: Connection to release
        """
        async with self._lock:
            if conn not in self._in_use:
                logger.warning(
                    "pool_release_unknown_connection", server_id=self.metadata.id
                )
                return

            self._in_use.remove(conn)

            # Check if connection is still valid
            if await self._is_connection_valid(conn):
                await self._available.put(conn)
                logger.debug(
                    "pool_connection_released",
                    server_id=self.metadata.id,
                    available=self._available.qsize(),
                    in_use=len(self._in_use),
                )
            else:
                # Connection invalid, destroy it
                await self._destroy_connection(conn)

                # If below min size, create replacement
                if len(self._connections) < self.min_size:
                    try:
                        new_conn = await self._create_connection()
                        await self._available.put(new_conn)
                    except Exception as e:
                        logger.error(
                            "pool_replacement_connection_failed",
                            server_id=self.metadata.id,
                            error=str(e),
                        )

    async def _create_connection(self) -> MCPConnection:
        """
        Create and start a new connection with retry logic.

        Returns:
            Started MCPConnection

        Raises:
            Various exceptions if connection fails to start
        """
        conn = MCPConnection(
            metadata=self.metadata,
            start_timeout=self.start_timeout,
            tool_timeout=self.tool_timeout,
            health_check_timeout=self.health_check_timeout,
            retry_config=self.retry_config,
        )

        await conn.start()

        self._connections.add(conn)
        self._total_created += 1

        logger.debug(
            "pool_connection_created",
            server_id=self.metadata.id,
            total=len(self._connections),
        )

        return conn

    async def _destroy_connection(self, conn: MCPConnection) -> None:
        """
        Destroy a connection.

        Args:
            conn: Connection to destroy
        """
        try:
            await conn.stop()
        except Exception as e:
            logger.warning(
                "pool_connection_stop_error",
                server_id=self.metadata.id,
                error=str(e),
            )

        self._connections.discard(conn)
        self._total_destroyed += 1

        logger.debug(
            "pool_connection_destroyed",
            server_id=self.metadata.id,
            total=len(self._connections),
        )

    async def _is_connection_valid(self, conn: MCPConnection) -> bool:
        """
        Check if connection is valid.

        Args:
            conn: Connection to check

        Returns:
            True if valid, False otherwise
        """
        # Check if connection was created too long ago
        stats = conn.get_stats()
        if stats.connected_at:
            age = (datetime.now() - stats.connected_at).total_seconds()
            if age > self.max_lifetime:
                logger.debug(
                    "pool_connection_expired",
                    server_id=self.metadata.id,
                    age_seconds=age,
                )
                return False

        # Check if connection is healthy
        try:
            is_healthy = await conn.health_check()
            if not is_healthy:
                logger.debug(
                    "pool_connection_unhealthy", server_id=self.metadata.id
                )
                return False
        except Exception as e:
            logger.debug(
                "pool_connection_health_check_failed",
                server_id=self.metadata.id,
                error=str(e),
            )
            return False

        return True

    async def _health_check_loop(self) -> None:
        """
        Background task that periodically health checks connections.
        """
        logger.debug("pool_health_checker_started", server_id=self.metadata.id)

        try:
            while not self._closed:
                await asyncio.sleep(self.health_check_interval)

                # Get snapshot of connections to check
                async with self._lock:
                    # Only check available connections (in-use will be checked on release)
                    conns_to_check = []
                    temp_queue = []

                    while not self._available.empty():
                        try:
                            conn = self._available.get_nowait()
                            conns_to_check.append(conn)
                            temp_queue.append(conn)
                        except asyncio.QueueEmpty:
                            break

                # Check connections
                for conn in conns_to_check:
                    if await self._is_connection_valid(conn):
                        temp_queue.append(conn)
                    else:
                        await self._destroy_connection(conn)
                        temp_queue.remove(conn)

                # Put valid connections back
                for conn in temp_queue:
                    await self._available.put(conn)

        except asyncio.CancelledError:
            try:
                logger.debug("pool_health_checker_cancelled", server_id=self.metadata.id)
            except (ValueError, OSError):
                pass  # stdout/stderr already closed during shutdown
        except Exception as e:
            try:
                logger.error(
                    "pool_health_checker_error",
                    server_id=self.metadata.id,
                    error=str(e),
                    exc_info=True,
                )
            except (ValueError, OSError):
                pass  # stdout/stderr already closed during shutdown

    async def _recycler_loop(self) -> None:
        """
        Background task that recycles old connections and maintains min pool size.
        """
        logger.debug("pool_recycler_started", server_id=self.metadata.id)

        try:
            while not self._closed:
                await asyncio.sleep(60)  # Check every minute

                async with self._lock:
                    # Ensure we have at least min_size connections
                    while len(self._connections) < self.min_size:
                        try:
                            conn = await self._create_connection()
                            await self._available.put(conn)
                        except Exception as e:
                            logger.error(
                                "pool_recycler_create_failed",
                                server_id=self.metadata.id,
                                error=str(e),
                            )
                            break

        except asyncio.CancelledError:
            try:
                logger.debug("pool_recycler_cancelled", server_id=self.metadata.id)
            except (ValueError, OSError):
                pass  # stdout/stderr already closed during shutdown
        except Exception as e:
            try:
                logger.error(
                    "pool_recycler_error",
                    server_id=self.metadata.id,
                    error=str(e),
                    exc_info=True,
                )
            except (ValueError, OSError):
                pass  # stdout/stderr already closed during shutdown

    def get_stats(self) -> PoolStats:
        """
        Get pool statistics.

        Returns:
            PoolStats with current metrics
        """
        return PoolStats(
            server_id=self.metadata.id,
            min_size=self.min_size,
            max_size=self.max_size,
            current_size=len(self._connections),
            available=self._available.qsize(),
            in_use=len(self._in_use),
            pending_requests=0,  # Would need request queue to track this
            total_connections_created=self._total_created,
            total_connections_destroyed=self._total_destroyed,
            total_acquire_timeout_errors=self._total_acquire_timeouts,
        )


# Context manager for automatic connection acquisition/release
class PooledConnection:
    """
    Context manager for acquiring/releasing connections from pool.

    Usage:
        async with PooledConnection(pool) as conn:
            await conn.call_tool("my_tool", {})
    """

    def __init__(
        self, pool: ConnectionPool, priority: Priority = Priority.NORMAL, timeout: float | None = None
    ):
        self.pool = pool
        self.priority = priority
        self.timeout = timeout
        self._conn: MCPConnection | None = None

    async def __aenter__(self) -> MCPConnection:
        self._conn = await self.pool.acquire(priority=self.priority, timeout=self.timeout)
        return self._conn

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._conn:
            await self.pool.release(self._conn)
            self._conn = None
