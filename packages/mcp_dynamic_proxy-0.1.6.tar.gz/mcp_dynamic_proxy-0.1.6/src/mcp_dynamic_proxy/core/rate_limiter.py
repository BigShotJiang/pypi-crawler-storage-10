"""
Simple token-bucket rate limiter utilities.

These limiters are intentionally lightweight and dependency-free.
"""

import time
from typing import Optional


class TokenBucket:
    """A basic token bucket limiter.

    - requests_per_second: steady refill rate
    - burst_size: maximum tokens accumulated (bucket capacity)
    """

    def __init__(self, requests_per_second: float, burst_size: int):
        if requests_per_second <= 0 or burst_size <= 0:
            raise ValueError("requests_per_second and burst_size must be > 0")

        self._rate = float(requests_per_second)
        self._capacity = float(burst_size)
        self._tokens = float(burst_size)
        self._last_refill = time.monotonic()

    def _refill(self) -> None:
        now = time.monotonic()
        elapsed = now - self._last_refill
        if elapsed <= 0:
            return
        self._last_refill = now
        self._tokens = min(self._capacity, self._tokens + self._rate * elapsed)

    def allow(self) -> bool:
        """Try to consume a token; return True if allowed, else False."""
        self._refill()
        if self._tokens >= 1.0:
            self._tokens -= 1.0
            return True
        return False


class OptionalLimiter:
    """Wrapper that gracefully disables limiting when configuration is absent."""

    def __init__(self, bucket: Optional[TokenBucket]):
        self._bucket = bucket

    def allow(self) -> bool:
        if self._bucket is None:
            return True
        return self._bucket.allow()


