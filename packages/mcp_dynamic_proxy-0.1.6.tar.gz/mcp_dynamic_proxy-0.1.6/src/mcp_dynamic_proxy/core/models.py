"""
Core data models for MCP Dynamic Proxy.

This module defines all Pydantic models used throughout the system for:
- API request/response types
- Internal message passing between worker tasks
- Connection and pool statistics
- Configuration models
"""

from datetime import datetime
from enum import Enum
from typing import Any, Literal
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


# ============================================================================
# Enums
# ============================================================================


class Priority(str, Enum):
    """Request priority levels for queue management."""

    CRITICAL = "critical"  # Health checks, system operations
    HIGH = "high"  # User-initiated tool calls
    NORMAL = "normal"  # Background operations
    LOW = "low"  # Cleanup, discovery


class ServerStatus(str, Enum):
    """MCP server connection status."""

    AVAILABLE = "available"  # Connected and healthy
    LOADING = "loading"  # Connecting or initializing
    ERROR = "error"  # Connection failed or crashed
    UNHEALTHY = "unhealthy"  # Connected but health check failing
    DISCONNECTED = "disconnected"  # Intentionally disconnected


class CircuitBreakerState(str, Enum):
    """Circuit breaker state."""

    CLOSED = "closed"  # Normal operation
    OPEN = "open"  # Failures exceeded threshold, rejecting requests
    HALF_OPEN = "half_open"  # Testing if service recovered


# ============================================================================
# Public API Models (exposed via MCP tools)
# ============================================================================


class ServerInfo(BaseModel):
    """Information about an MCP server."""

    id: str = Field(..., description="Unique server identifier")
    name: str = Field(..., description="Human-readable server name")
    description: str | None = Field(None, description="Server description")
    status: ServerStatus = Field(..., description="Current server status")
    tools_count: int | None = Field(None, description="Number of available tools")
    circuit_breaker_state: CircuitBreakerState | None = Field(
        None, description="Circuit breaker state if applicable"
    )
    last_error: str | None = Field(None, description="Last error message if any")
    connected_at: datetime | None = Field(None, description="When connection was established")


class ToolInfo(BaseModel):
    """Information about an MCP tool."""

    name: str = Field(..., description="Tool name")
    description: str = Field(..., description="Tool description")
    input_schema: dict[str, Any] = Field(..., description="JSON Schema for tool input")


class ExecutionResult(BaseModel):
    """Result of tool execution."""

    success: bool = Field(..., description="Whether execution succeeded")
    content: list[dict[str, Any]] = Field(..., description="Result content")
    duration_ms: float = Field(..., description="Execution duration in milliseconds")
    trace_id: str = Field(..., description="Trace ID for distributed tracing")
    error: str | None = Field(None, description="Error message if execution failed")
    is_error: bool = Field(False, description="Whether result represents an error")


# ============================================================================
# Internal Request/Response Models (for worker task communication)
# ============================================================================


class RequestType(str, Enum):
    """Types of requests that can be sent to connection worker."""

    LIST_TOOLS = "list_tools"
    CALL_TOOL = "call_tool"
    HEALTH_CHECK = "health_check"
    SHUTDOWN = "shutdown"


class WorkerRequest(BaseModel):
    """Request sent to connection worker task via queue."""

    request_id: UUID = Field(default_factory=uuid4, description="Unique request ID")
    request_type: RequestType = Field(..., description="Type of request")
    priority: Priority = Field(Priority.NORMAL, description="Request priority")
    timeout: float | None = Field(None, description="Request timeout in seconds")
    timestamp: datetime = Field(default_factory=datetime.now, description="Request timestamp")

    # Request-specific data
    tool_name: str | None = None
    arguments: dict[str, Any] | None = None


class WorkerResponse(BaseModel):
    """Response from connection worker task."""

    request_id: UUID = Field(..., description="Corresponding request ID")
    success: bool = Field(..., description="Whether request succeeded")
    data: dict[str, Any] | list[Any] | None = Field(None, description="Response data")
    error: str | None = Field(None, description="Error message if failed")
    duration_ms: float = Field(..., description="Processing duration in milliseconds")
    timestamp: datetime = Field(default_factory=datetime.now, description="Response timestamp")


# ============================================================================
# Statistics Models
# ============================================================================


class ConnectionStats(BaseModel):
    """Statistics for a single MCP connection."""

    server_id: str
    status: ServerStatus
    circuit_breaker_state: CircuitBreakerState

    # Timing
    connected_at: datetime | None = None
    last_used: datetime | None = None
    uptime_seconds: float | None = None

    # Counters
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0

    # Performance
    avg_latency_ms: float | None = None
    p95_latency_ms: float | None = None
    p99_latency_ms: float | None = None

    # Health
    consecutive_failures: int = 0
    last_health_check: datetime | None = None
    health_check_passing: bool = True

    # Resources
    subprocess_pid: int | None = None
    subprocess_status: str | None = None
    memory_mb: float | None = None


class PoolStats(BaseModel):
    """Statistics for a connection pool."""

    server_id: str
    min_size: int
    max_size: int
    current_size: int
    available: int
    in_use: int
    pending_requests: int

    # Aggregate stats
    total_connections_created: int = 0
    total_connections_destroyed: int = 0
    total_acquire_timeout_errors: int = 0


# ============================================================================
# Health Check Models
# ============================================================================


class HealthStatus(BaseModel):
    """Overall system health status."""

    status: Literal["healthy", "degraded", "unhealthy"]
    timestamp: datetime = Field(default_factory=datetime.now)

    # Global stats
    total_servers: int
    healthy_servers: int
    degraded_servers: int
    unhealthy_servers: int

    # Details per server
    servers: dict[str, ConnectionStats]


class ReadinessStatus(BaseModel):
    """System readiness status (for K8s readiness probe)."""

    ready: bool
    timestamp: datetime = Field(default_factory=datetime.now)
    message: str

    # Minimum requirements for readiness
    min_healthy_servers: int
    current_healthy_servers: int


# ============================================================================
# Configuration Models (will be used in config.py refactoring)
# ============================================================================


class ConnectionConfig(BaseModel):
    """Configuration for a single connection."""

    start_timeout: float = Field(30.0, description="Timeout for connection start")
    tool_timeout: float = Field(300.0, description="Default tool execution timeout")
    health_check_timeout: float = Field(5.0, description="Health check timeout")
    health_check_interval: float = Field(30.0, description="Health check interval")

    # Retry configuration
    max_retry_attempts: int = Field(3, description="Max retry attempts for transient failures")
    retry_backoff_base: float = Field(1.0, description="Base delay for exponential backoff")

    # TTL
    cache_ttl: int = Field(300, description="Connection TTL in seconds")
    max_lifetime: float = Field(3600.0, description="Max connection lifetime before recycling")


class PoolConfig(BaseModel):
    """Configuration for connection pool."""

    min_size: int = Field(1, description="Minimum pool size")
    max_size: int = Field(5, description="Maximum pool size")
    acquire_timeout: float = Field(30.0, description="Timeout when acquiring connection")
    idle_timeout: float = Field(300.0, description="Idle connection timeout")
    max_queue_size: int = Field(100, description="Maximum queued requests")
    # Explicit operation timeouts used by underlying connections
    start_timeout: float = Field(30.0, description="Timeout for starting connections")
    tool_timeout: float = Field(300.0, description="Default tool execution timeout")
    health_check_timeout: float = Field(5.0, description="Health check timeout")
    health_check_interval: float = Field(30.0, description="Health check interval in seconds")
    # Connection lifetime management
    max_lifetime: float = Field(3600.0, description="Recycle connections older than this many seconds")


class CircuitBreakerConfig(BaseModel):
    """Configuration for circuit breaker."""

    failure_threshold: int = Field(5, description="Failures before opening circuit")
    success_threshold: int = Field(2, description="Successes in half-open before closing")
    timeout: float = Field(60.0, description="Time to wait before trying half-open")
    half_open_max_calls: int = Field(3, description="Max calls in half-open state")


class RateLimitConfig(BaseModel):
    """Configuration for rate limiting."""

    enabled: bool = Field(False, description="Whether rate limiting is enabled")
    requests_per_second: float = Field(10.0, description="Max requests per second")
    burst_size: int = Field(20, description="Max burst size (token bucket)")


class ObservabilityConfig(BaseModel):
    """Configuration for observability features."""

    # Logging
    log_level: str = Field("INFO", description="Log level")
    structured_logging: bool = Field(True, description="Use structured logging")

    # Metrics
    metrics_enabled: bool = Field(True, description="Enable Prometheus metrics")
    metrics_port: int = Field(9090, description="Metrics endpoint port")

    # Tracing
    tracing_enabled: bool = Field(False, description="Enable OpenTelemetry tracing")
    tracing_endpoint: str | None = Field(None, description="OTLP endpoint")
    tracing_sample_rate: float = Field(1.0, description="Trace sample rate (0.0-1.0)")


class GlobalLimits(BaseModel):
    """Global resource limits."""

    max_total_connections: int = Field(50, description="Max total connections across all servers")
    max_memory_mb: int = Field(1024, description="Max total memory usage")
    max_file_descriptors: int = Field(500, description="Max file descriptors")
