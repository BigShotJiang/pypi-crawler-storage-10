"""
Connection Manager - Central orchestrator for all MCP connections.

This module provides a thread-safe manager that orchestrates all connection pools,
enforces global resource limits, and provides a clean API for MCP operations.

The manager is designed to be used as a singleton instance shared across the
entire application.
"""

import asyncio
from typing import Any

import structlog
from mcp.types import Tool

from ..registry import ServerRegistry
from ..resilience import (
    CircuitBreaker,
    CircuitBreakerError,
    RetryableOperation,
    RetryConfig,
)
from ..resilience.circuit_breaker import CircuitBreakerConfig
from .rate_limiter import TokenBucket
from .models import (
    CircuitBreakerState,
    ConnectionStats,
    GlobalLimits,
    HealthStatus,
    RateLimitConfig,
    PoolConfig,
    PoolStats,
    Priority,
    ReadinessStatus,
    ServerStatus,
)
from .pool import ConnectionPool, PooledConnection

logger = structlog.get_logger(__name__)


class ResourceLimitExceeded(Exception):
    """Raised when global resource limits are exceeded."""

    pass


class ConnectionManager:
    """
    Central manager for all MCP connection pools.

    This class:
    - Creates and manages connection pools (one per MCP server)
    - Enforces global resource limits
    - Provides a clean API for MCP operations
    - Tracks global statistics
    - Handles graceful shutdown
    """

    def __init__(
        self,
        registry: ServerRegistry,
        pool_config: PoolConfig | None = None,
        global_limits: GlobalLimits | None = None,
        circuit_breaker_config: CircuitBreakerConfig | None = None,
        retry_config: RetryConfig | None = None,
        rate_limit_config: RateLimitConfig | None = None,
    ):
        """
        Initialize connection manager.

        Args:
            registry: Server registry with MCP server metadata
            pool_config: Default pool configuration
            global_limits: Global resource limits
            circuit_breaker_config: Circuit breaker configuration
            retry_config: Retry configuration
        """
        self.registry = registry
        self.pool_config = pool_config or PoolConfig()
        self.global_limits = global_limits or GlobalLimits()
        self.circuit_breaker_config = circuit_breaker_config or CircuitBreakerConfig()
        self.retry_config = retry_config or RetryConfig()
        self.rate_limit_config = rate_limit_config or RateLimitConfig()

        # Pool management
        self._pools: dict[str, ConnectionPool] = {}
        self._pool_locks: dict[str, asyncio.Lock] = {}
        self._global_lock = asyncio.Lock()

        # Circuit breakers (one per server)
        self._circuit_breakers: dict[str, CircuitBreaker] = {}

        # Rate limiters
        self._global_rate_limiter: TokenBucket | None = None
        self._server_rate_limiters: dict[str, TokenBucket] = {}

        # State
        self._started = False
        self._shutdown = False

        logger.debug(
            "manager_created",
            max_total_connections=self.global_limits.max_total_connections,
            circuit_breaker_enabled=True,
            retry_enabled=True,
            max_retry_attempts=self.retry_config.max_attempts,
        )

    async def start(self) -> None:
        """Start the connection manager."""
        async with self._global_lock:
            if self._started:
                raise RuntimeError("Manager already started")

            self._started = True
            self._shutdown = False

            # Initialize rate limiters if enabled
            if self.rate_limit_config.enabled:
                # Global limiter
                self._global_rate_limiter = TokenBucket(
                    self.rate_limit_config.requests_per_second,
                    self.rate_limit_config.burst_size,
                )

            logger.debug("manager_started")

    async def shutdown(self) -> None:
        """
        Gracefully shutdown the manager.

        Stops all pools and cleans up resources.
        """
        async with self._global_lock:
            if self._shutdown:
                return

            logger.debug("manager_shutting_down", pools_count=len(self._pools))
            self._shutdown = True

            # Stop all pools
            tasks = [pool.stop() for pool in self._pools.values()]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            # Log any errors
            for server_id, result in zip(self._pools.keys(), results):
                if isinstance(result, Exception):
                    logger.error(
                        "manager_pool_shutdown_error",
                        server_id=server_id,
                        error=str(result),
                    )

            self._pools.clear()
            self._pool_locks.clear()

            logger.debug("manager_shutdown_complete")

    async def get_or_create_pool(self, server_id: str) -> ConnectionPool:
        """
        Get existing pool or create new one for server.

        Args:
            server_id: Server identifier

        Returns:
            ConnectionPool for the server

        Raises:
            ValueError: If server not found in registry
            ResourceLimitExceeded: If global limits exceeded
        """
        if self._shutdown:
            raise RuntimeError("Manager is shutting down")

        # Fast path: pool already exists
        if server_id in self._pools:
            return self._pools[server_id]

        # Get or create lock for this server
        async with self._global_lock:
            if server_id not in self._pool_locks:
                self._pool_locks[server_id] = asyncio.Lock()
            lock = self._pool_locks[server_id]

        # Acquire per-server lock (prevents race condition)
        async with lock:
            # Double-check: another task may have created it
            if server_id in self._pools:
                return self._pools[server_id]

            # Check global limits
            total_connections = sum(
                len(pool._connections) for pool in self._pools.values()
            )
            if total_connections >= self.global_limits.max_total_connections:
                raise ResourceLimitExceeded(
                    f"Global connection limit reached: {self.global_limits.max_total_connections}"
                )

            # Get server metadata
            metadata = self.registry.get(server_id)
            if not metadata:
                raise ValueError(f"Server '{server_id}' not found in registry")

            # Create and start pool
            logger.debug("manager_creating_pool", server_id=server_id)

            pool = ConnectionPool(
                metadata=metadata,
                min_size=self.pool_config.min_size,
                max_size=self.pool_config.max_size,
                acquire_timeout=self.pool_config.acquire_timeout,
                idle_timeout=self.pool_config.idle_timeout,
                max_lifetime=self.pool_config.max_lifetime,
                start_timeout=self.pool_config.start_timeout,
                tool_timeout=self.pool_config.tool_timeout,
                health_check_timeout=self.pool_config.health_check_timeout,
                health_check_interval=self.pool_config.health_check_interval,
                retry_config=self.retry_config,
            )

            await pool.start()

            self._pools[server_id] = pool

            logger.debug(
                "manager_pool_created",
                server_id=server_id,
                total_pools=len(self._pools),
            )

            return pool

    async def get_tools(
        self, server_id: str, force_refresh: bool = False
    ) -> list[Tool]:
        """
        Get tools from a server with retry protection.

        Args:
            server_id: Server identifier
            force_refresh: Force refresh from MCP server

        Returns:
            List of Tool objects

        Raises:
            ValueError: If server not found
            RetryError: If all retry attempts failed
            Various exceptions from pool/connection
        """
        # Create retry operation
        retry_op = RetryableOperation(
            operation_name=f"get_tools-{server_id}",
            config=self.retry_config,
        )

        async def _get_tools_operation():
            pool = await self.get_or_create_pool(server_id)
            async with PooledConnection(pool, priority=Priority.HIGH) as conn:
                return await conn.list_tools(force_refresh=force_refresh)

        # Execute with retry protection
        return await retry_op.execute(_get_tools_operation)

    def _get_or_create_circuit_breaker(self, server_id: str) -> CircuitBreaker:
        """
        Get or create circuit breaker for a server.

        Args:
            server_id: Server identifier

        Returns:
            CircuitBreaker for the server
        """
        if server_id not in self._circuit_breakers:
            self._circuit_breakers[server_id] = CircuitBreaker(
                name=f"cb-{server_id}", config=self.circuit_breaker_config
            )
        return self._circuit_breakers[server_id]

    async def call_tool(
        self,
        server_id: str,
        tool_name: str,
        arguments: dict[str, Any],
        timeout: float | None = None,
        priority: Priority = Priority.NORMAL,
    ) -> dict[str, Any]:
        """
        Call a tool on a server with retry and circuit breaker protection.

        Protection layers (in order):
        1. Retry: Handles transient failures with exponential backoff
        2. Circuit Breaker: Detects systemic failures and fails fast

        Args:
            server_id: Server identifier
            tool_name: Name of tool to call
            arguments: Tool arguments
            timeout: Optional timeout
            priority: Request priority

        Returns:
            Tool execution result

        Raises:
            ValueError: If server or tool not found
            CircuitBreakerError: If circuit breaker is open
            RetryError: If all retry attempts failed
            Various exceptions from pool/connection
        """
        # Rate limiting (global)
        if self._global_rate_limiter is not None and not self._global_rate_limiter.allow():
            raise RuntimeError("rate_limited: global")

        # Per-server rate limiting
        if self.rate_limit_config.enabled:
            limiter = self._server_rate_limiters.get(server_id)
            if limiter is None:
                limiter = TokenBucket(
                    self.rate_limit_config.requests_per_second,
                    self.rate_limit_config.burst_size,
                )
                self._server_rate_limiters[server_id] = limiter
            if not limiter.allow():
                raise RuntimeError("rate_limited: server")

        # Get circuit breaker for this server
        circuit_breaker = self._get_or_create_circuit_breaker(server_id)

        # Create retry operation
        retry_op = RetryableOperation(
            operation_name=f"call_tool-{server_id}-{tool_name}",
            config=self.retry_config,
        )

        # Define operation with circuit breaker protection
        async def _call_tool_with_circuit_breaker():
            async def _actual_call():
                pool = await self.get_or_create_pool(server_id)
                async with PooledConnection(pool, priority=priority) as conn:
                    return await conn.call_tool(tool_name, arguments, timeout=timeout)

            # Execute through circuit breaker
            return await circuit_breaker.call(_actual_call)

        # Execute with retry + circuit breaker protection
        try:
            result = await retry_op.execute(_call_tool_with_circuit_breaker)
            return result
        except CircuitBreakerError as e:
            # Circuit breaker is open, log and re-raise
            # Note: Retry will not retry CircuitBreakerError (it's not in retryable_exceptions)
            logger.warning(
                "call_tool_circuit_breaker_open",
                server_id=server_id,
                tool_name=tool_name,
                circuit_breaker_state=circuit_breaker.state.value,
            )
            raise

    async def health_check(self, server_id: str) -> bool:
        """
        Perform health check on a server.

        Args:
            server_id: Server identifier

        Returns:
            True if healthy, False otherwise
        """
        try:
            pool = self._pools.get(server_id)
            if not pool:
                return False

            async with PooledConnection(
                pool, priority=Priority.CRITICAL, timeout=5.0
            ) as conn:
                return await conn.health_check()
        except Exception as e:
            logger.warning(
                "manager_health_check_failed", server_id=server_id, error=str(e)
            )
            return False

    def get_pool_stats(self, server_id: str) -> PoolStats | None:
        """
        Get statistics for a specific pool.

        Args:
            server_id: Server identifier

        Returns:
            PoolStats or None if pool doesn't exist
        """
        pool = self._pools.get(server_id)
        if not pool:
            return None

        return pool.get_stats()

    async def get_connection_stats(self, server_id: str) -> list[ConnectionStats]:
        """
        Get statistics for all connections in a pool.

        Args:
            server_id: Server identifier

        Returns:
            List of ConnectionStats
        """
        pool = self._pools.get(server_id)
        if not pool:
            return []

        # Get circuit breaker state
        cb_state = CircuitBreakerState.CLOSED
        if server_id in self._circuit_breakers:
            cb_state = self._circuit_breakers[server_id].state

        stats = []
        for conn in pool._connections:
            conn_stats = conn.get_stats()
            # Update circuit breaker state in stats
            conn_stats.circuit_breaker_state = cb_state
            stats.append(conn_stats)

        return stats

    def get_circuit_breaker_metrics(self, server_id: str) -> dict | None:
        """
        Get circuit breaker metrics for a server.

        Args:
            server_id: Server identifier

        Returns:
            Circuit breaker metrics or None if not found
        """
        cb = self._circuit_breakers.get(server_id)
        if not cb:
            return None

        return cb.get_metrics()

    def get_all_circuit_breaker_metrics(self) -> dict[str, dict]:
        """
        Get circuit breaker metrics for all servers.

        Returns:
            Dictionary mapping server_id to circuit breaker metrics
        """
        return {
            server_id: cb.get_metrics()
            for server_id, cb in self._circuit_breakers.items()
        }

    async def get_health_status(self) -> HealthStatus:
        """
        Get overall health status of all servers.

        Returns:
            HealthStatus with aggregated metrics
        """
        servers_stats: dict[str, ConnectionStats] = {}
        healthy_count = 0
        degraded_count = 0
        unhealthy_count = 0

        for server_id, pool in self._pools.items():
            # Get first connection's stats as representative
            if pool._connections:
                conn = next(iter(pool._connections))
                stats = conn.get_stats()
                servers_stats[server_id] = stats

                if stats.status == ServerStatus.AVAILABLE:
                    healthy_count += 1
                elif stats.status == ServerStatus.UNHEALTHY:
                    degraded_count += 1
                else:
                    unhealthy_count += 1

        # Determine overall status
        total = len(self._pools)
        if unhealthy_count == total:
            overall_status = "unhealthy"
        elif degraded_count > 0 or unhealthy_count > 0:
            overall_status = "degraded"
        else:
            overall_status = "healthy"

        return HealthStatus(
            status=overall_status,  # type: ignore
            total_servers=total,
            healthy_servers=healthy_count,
            degraded_servers=degraded_count,
            unhealthy_servers=unhealthy_count,
            servers=servers_stats,
        )

    async def get_readiness_status(self, min_healthy_servers: int = 0) -> ReadinessStatus:
        """
        Get readiness status (for K8s readiness probe).

        Args:
            min_healthy_servers: Minimum number of healthy servers required

        Returns:
            ReadinessStatus
        """
        health = await self.get_health_status()

        ready = health.healthy_servers >= min_healthy_servers
        message = f"Healthy: {health.healthy_servers}/{health.total_servers}"

        return ReadinessStatus(
            ready=ready,
            message=message,
            min_healthy_servers=min_healthy_servers,
            current_healthy_servers=health.healthy_servers,
        )

    def get_global_stats(self) -> dict[str, Any]:
        """
        Get global statistics across all pools.

        Returns:
            Dictionary with global metrics
        """
        total_pools = len(self._pools)
        total_connections = sum(len(pool._connections) for pool in self._pools.values())
        total_available = sum(
            pool._available.qsize() for pool in self._pools.values()
        )
        total_in_use = sum(len(pool._in_use) for pool in self._pools.values())

        return {
            "total_pools": total_pools,
            "total_connections": total_connections,
            "total_available": total_available,
            "total_in_use": total_in_use,
            "pools": {
                server_id: pool.get_stats().model_dump()
                for server_id, pool in self._pools.items()
            },
        }

    async def list_servers(self) -> list[str]:
        """
        List all server IDs currently managed.

        Returns:
            List of server IDs
        """
        return list(self._pools.keys())

    async def unload_server(self, server_id: str) -> bool:
        """Gracefully stop and remove the pool for a specific server.

        Returns True if a pool existed and was stopped, False if none existed.
        """
        async with self._global_lock:
            pool = self._pools.pop(server_id, None)
            if not pool:
                return False
            try:
                await pool.stop()
            finally:
                # Cleanup per-server artifacts
                self._pool_locks.pop(server_id, None)
                self._circuit_breakers.pop(server_id, None)
                self._server_rate_limiters.pop(server_id, None)
            return True
