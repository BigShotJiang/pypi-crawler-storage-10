"""
MCP Connection with Worker Task Pattern.

This module implements a thread-safe, cancel-scope-safe MCP connection using
the worker task pattern. All MCP operations (start, list_tools, call_tool) happen
in a single dedicated asyncio task, eliminating cancel scope violations.

Key features:
- Worker task owns all context managers (transport, session)
- Communication via asyncio queues (request/response)
- Thread-safe by design
- Proper cleanup and resource management
- Timeout support for all operations
- Retry logic for connection establishment
"""

import asyncio
import os
import time
from collections import deque
from datetime import datetime
from typing import Any
from uuid import UUID

import structlog
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from mcp.types import Tool

from ..registry import ServerMetadata
from ..resilience import RetryableOperation, RetryConfig
from .models import (
    ConnectionStats,
    Priority,
    RequestType,
    ServerStatus,
    WorkerRequest,
    WorkerResponse,
    CircuitBreakerState,
)

logger = structlog.get_logger(__name__)


class ConnectionError(OSError):
    """Base exception for connection errors.

    Inherits from OSError so it's automatically retryable.
    """

    pass


class ConnectionTimeout(ConnectionError, TimeoutError):
    """Raised when operation times out.

    Inherits from both ConnectionError and TimeoutError for proper retry handling.
    """

    pass


class ConnectionClosed(ConnectionError):
    """Raised when connection is closed.

    Inherits from ConnectionError (which is OSError) for retry handling.
    """

    pass


class MCPConnection:
    """
    Thread-safe MCP connection using worker task pattern.

    The worker task owns all context managers and MCP session operations.
    External code communicates via request/response queues, eliminating
    the cancel scope issues caused by entering context managers in one
    task and exiting them in another.
    """

    def __init__(
        self,
        metadata: ServerMetadata,
        start_timeout: float = 30.0,
        tool_timeout: float = 300.0,
        health_check_timeout: float = 5.0,
        retry_config: RetryConfig | None = None,
    ):
        """
        Initialize MCP connection.

        Args:
            metadata: Server metadata (command, args, env, etc.)
            start_timeout: Timeout for connection start
            tool_timeout: Default timeout for tool execution
            health_check_timeout: Timeout for health checks
            retry_config: Optional retry configuration for connection establishment
        """
        self.metadata = metadata
        self.start_timeout = start_timeout
        self.tool_timeout = tool_timeout
        self.health_check_timeout = health_check_timeout
        self.retry_config = retry_config or RetryConfig()

        # Worker task and communication
        self._worker_task: asyncio.Task | None = None
        self._request_queue: asyncio.Queue[WorkerRequest] = asyncio.Queue(maxsize=100)
        self._response_futures: dict[UUID, asyncio.Future[WorkerResponse]] = {}
        self._lock = asyncio.Lock()

        # State
        self._status = ServerStatus.DISCONNECTED
        self._tools: list[Tool] = []
        self._subprocess_pid: int | None = None

        # Statistics
        self._connected_at: datetime | None = None
        self._last_used: datetime | None = None
        self._total_requests = 0
        self._successful_requests = 0
        self._failed_requests = 0
        self._latencies: deque[float] = deque(maxlen=1000)  # Last 1000 latencies
        self._connection_attempts = 0

        # Circuit breaker state (managed externally)
        self._circuit_breaker_state = CircuitBreakerState.CLOSED

        logger.debug(
            "connection_created",
            server_id=self.metadata.id,
            command=self.metadata.command,
        )

    @property
    def status(self) -> ServerStatus:
        """Current connection status."""
        return self._status

    @property
    def tools(self) -> list[Tool]:
        """List of available tools."""
        return self._tools.copy()

    @property
    def subprocess_pid(self) -> int | None:
        """PID of MCP server subprocess."""
        return self._subprocess_pid

    async def start(self) -> None:
        """
        Start the connection and worker task with retry logic.

        This starts the worker task which handles all MCP operations.
        If the connection fails with a transient error, it will be retried.

        Raises:
            ConnectionError: If connection fails to start
            ConnectionTimeout: If start times out
            RetryError: If all retry attempts failed
        """
        async with self._lock:
            if self._worker_task is not None:
                raise ConnectionError("Connection already started")

            logger.debug("connection_starting", server_id=self.metadata.id)

        # Create retry operation for connection establishment
        retry_op = RetryableOperation(
            operation_name=f"connect-{self.metadata.id}",
            config=self.retry_config,
        )

        # Execute with retry protection
        try:
            await retry_op.execute(self._start_worker_and_wait)
            logger.debug(
                "connection_started",
                server_id=self.metadata.id,
                tools_count=len(self._tools),
                pid=self._subprocess_pid,
                attempts=self._connection_attempts,
            )
        except Exception as e:
            logger.error(
                "connection_start_failed",
                server_id=self.metadata.id,
                error=str(e),
                attempts=self._connection_attempts,
            )
            # Ensure cleanup
            await self.stop()
            raise

    async def _start_worker_and_wait(self) -> None:
        """
        Helper to start worker task and wait for it to be ready.

        This is wrapped by retry logic in start().

        Raises:
            ConnectionError: If connection fails to start
            ConnectionTimeout: If start times out
        """
        async with self._lock:
            # Cleanup any existing worker (from previous failed attempt)
            if self._worker_task is not None:
                logger.debug(
                    "connection_cleaning_up_previous_worker",
                    server_id=self.metadata.id,
                )
                await self._stop_worker()

            self._connection_attempts += 1
            self._status = ServerStatus.LOADING

            # Start worker task
            self._worker_task = asyncio.create_task(
                self._worker_loop(), name=f"worker-{self.metadata.id}"
            )

            logger.debug(
                "connection_worker_started",
                server_id=self.metadata.id,
                attempt=self._connection_attempts,
            )

        # Wait for initialization (outside lock to allow worker to update status)
        try:
            await asyncio.wait_for(self._wait_for_ready(), timeout=self.start_timeout)
        except asyncio.TimeoutError:
            logger.warning(
                "connection_start_timeout",
                server_id=self.metadata.id,
                timeout=self.start_timeout,
                attempt=self._connection_attempts,
            )
            await self._stop_worker()
            raise ConnectionTimeout(
                f"Connection start timed out after {self.start_timeout}s"
            )
        except Exception as e:
            logger.warning(
                "connection_start_attempt_failed",
                server_id=self.metadata.id,
                error=str(e),
                attempt=self._connection_attempts,
            )
            await self._stop_worker()
            raise

    async def _stop_worker(self) -> None:
        """Stop the worker task (without acquiring lock)."""
        if self._worker_task is None:
            return

        try:
            # Send shutdown request
            shutdown_req = WorkerRequest(
                request_type=RequestType.SHUTDOWN, priority=Priority.CRITICAL
            )
            try:
                await asyncio.wait_for(
                    self._request_queue.put(shutdown_req), timeout=1.0
                )
            except asyncio.TimeoutError:
                pass

            # Wait for worker to finish
            await asyncio.wait_for(self._worker_task, timeout=5.0)
        except asyncio.TimeoutError:
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass
        except Exception:
            pass

        self._worker_task = None
        self._status = ServerStatus.DISCONNECTED

    async def _wait_for_ready(self) -> None:
        """Wait for worker to be ready (status changes from LOADING)."""
        while self._status == ServerStatus.LOADING:
            await asyncio.sleep(0.1)

        if self._status != ServerStatus.AVAILABLE:
            raise ConnectionError(f"Connection failed: status={self._status}")

    async def stop(self) -> None:
        """
        Stop the connection and worker task.

        Sends shutdown request to worker and waits for graceful shutdown.
        """
        async with self._lock:
            if self._worker_task is None:
                return

            logger.debug("connection_stopping", server_id=self.metadata.id)

            try:
                # Send shutdown request (with timeout to prevent hanging)
                shutdown_req = WorkerRequest(
                    request_type=RequestType.SHUTDOWN, priority=Priority.CRITICAL
                )
                await asyncio.wait_for(
                    self._request_queue.put(shutdown_req),
                    timeout=5.0
                )

                # Wait for worker to finish (with timeout)
                await asyncio.wait_for(self._worker_task, timeout=10.0)
            except asyncio.TimeoutError:
                logger.warning(
                    "connection_stop_timeout", server_id=self.metadata.id
                )
                self._worker_task.cancel()
                try:
                    await self._worker_task
                except asyncio.CancelledError:
                    pass
            except Exception as e:
                logger.error(
                    "connection_stop_error", server_id=self.metadata.id, error=str(e)
                )

            self._worker_task = None
            self._status = ServerStatus.DISCONNECTED

            logger.debug("connection_stopped", server_id=self.metadata.id)

    async def list_tools(self, force_refresh: bool = False) -> list[Tool]:
        """
        List available tools.

        Args:
            force_refresh: If True, query MCP server. Otherwise return cached.

        Returns:
            List of Tool objects

        Raises:
            ConnectionClosed: If connection not started
            ConnectionTimeout: If operation times out
        """
        if not force_refresh and self._tools:
            return self.tools

        response = await self._send_request(
            WorkerRequest(request_type=RequestType.LIST_TOOLS, priority=Priority.HIGH),
            timeout=self.health_check_timeout,
        )

        if not response.success:
            raise ConnectionError(f"Failed to list tools: {response.error}")

        return self._tools.copy()

    async def call_tool(
        self, tool_name: str, arguments: dict[str, Any], timeout: float | None = None
    ) -> dict[str, Any]:
        """
        Call a tool on the MCP server.

        Args:
            tool_name: Name of tool to call
            arguments: Tool arguments
            timeout: Optional timeout (uses default if not specified)

        Returns:
            Tool execution result

        Raises:
            ConnectionClosed: If connection not started
            ConnectionTimeout: If operation times out
            ValueError: If tool not found
        """
        # Verify tool exists
        tool_names = [tool.name for tool in self._tools]
        if tool_name not in tool_names:
            raise ValueError(
                f"Tool '{tool_name}' not found. Available: {', '.join(tool_names)}"
            )

        response = await self._send_request(
            WorkerRequest(
                request_type=RequestType.CALL_TOOL,
                tool_name=tool_name,
                arguments=arguments,
                priority=Priority.HIGH,
            ),
            timeout=timeout or self.tool_timeout,
        )

        if not response.success:
            raise ConnectionError(f"Tool execution failed: {response.error}")

        return response.data  # type: ignore

    async def health_check(self) -> bool:
        """
        Perform health check on connection.

        Returns:
            True if healthy, False otherwise
        """
        try:
            response = await self._send_request(
                WorkerRequest(
                    request_type=RequestType.HEALTH_CHECK, priority=Priority.CRITICAL
                ),
                timeout=self.health_check_timeout,
            )
            return response.success
        except Exception as e:
            logger.warning(
                "health_check_failed", server_id=self.metadata.id, error=str(e)
            )
            return False

    async def _send_request(
        self, request: WorkerRequest, timeout: float
    ) -> WorkerResponse:
        """
        Send request to worker and wait for response.

        Args:
            request: Request to send
            timeout: Timeout in seconds

        Returns:
            Response from worker

        Raises:
            ConnectionClosed: If connection not started
            ConnectionTimeout: If operation times out
        """
        if self._worker_task is None:
            raise ConnectionClosed("Connection not started")

        # Create future for response
        future: asyncio.Future[WorkerResponse] = asyncio.Future()
        self._response_futures[request.request_id] = future

        try:
            # Send request
            await asyncio.wait_for(
                self._request_queue.put(request), timeout=timeout
            )

            # Wait for response
            response = await asyncio.wait_for(future, timeout=timeout)
            return response

        except asyncio.TimeoutError:
            raise ConnectionTimeout(
                f"Request {request.request_type} timed out after {timeout}s"
            )
        finally:
            # Cleanup future
            self._response_futures.pop(request.request_id, None)

    async def _worker_loop(self) -> None:
        """
        Worker task main loop.

        This task owns all MCP context managers and processes requests.
        ALL MCP operations happen in this single task, eliminating cancel
        scope violations.
        """
        session: ClientSession | None = None
        transport_ctx = None
        session_ctx = None

        try:
            # Step 1: Start MCP server process
            logger.debug("worker_starting", server_id=self.metadata.id)

            # Always inherit parent environment (including HTTP_PROXY, etc.)
            # Then override with server-specific env vars if any
            env = {**os.environ}
            if self.metadata.env:
                env.update(self.metadata.env)

            server_params = StdioServerParameters(
                command=self.metadata.command,
                args=self.metadata.args,
                env=env,
            )

            # Step 2: Enter transport context (OWNED BY THIS TASK)
            transport_ctx = stdio_client(server_params)
            read, write = await transport_ctx.__aenter__()

            logger.debug("worker_transport_started", server_id=self.metadata.id)

            # Step 3: Enter session context (OWNED BY THIS TASK)
            session_ctx = ClientSession(read, write)
            session = await session_ctx.__aenter__()

            logger.debug("worker_session_started", server_id=self.metadata.id)

            # Step 4: Initialize session
            init_result = await session.initialize()
            self._subprocess_pid = getattr(init_result, "pid", None)

            logger.debug(
                "worker_initialized",
                server_id=self.metadata.id,
                pid=self._subprocess_pid,
            )

            # Step 5: Discover tools
            tools_result = await session.list_tools()
            self._tools = tools_result.tools

            self._connected_at = datetime.now()
            self._status = ServerStatus.AVAILABLE

            logger.debug(
                "worker_ready",
                server_id=self.metadata.id,
                tools_count=len(self._tools),
            )

            # Step 6: Process requests
            while True:
                request = await self._request_queue.get()

                # Handle shutdown
                if request.request_type == RequestType.SHUTDOWN:
                    logger.debug("worker_shutdown_requested", server_id=self.metadata.id)
                    break

                # Process request
                await self._process_request(request, session)

        except Exception as e:
            logger.error(
                "worker_error", server_id=self.metadata.id, error=str(e), exc_info=True
            )
            self._status = ServerStatus.ERROR
        finally:
            # Cleanup: Exit context managers (IN SAME TASK)
            try:
                logger.debug("worker_cleanup_starting", server_id=self.metadata.id)
            except (ValueError, OSError):
                pass  # stdout/stderr already closed during shutdown

            if session_ctx:
                try:
                    await session_ctx.__aexit__(None, None, None)
                    try:
                        logger.debug("worker_session_closed", server_id=self.metadata.id)
                    except (ValueError, OSError):
                        pass
                except RuntimeError as e:
                    # Ignore anyio cancel scope errors during cleanup
                    # These can occur when the task is cancelled externally
                    if "cancel scope" not in str(e).lower():
                        try:
                            logger.warning(
                                "worker_session_close_error",
                                server_id=self.metadata.id,
                                error=str(e),
                            )
                        except (ValueError, OSError):
                            pass
                except Exception as e:
                    try:
                        logger.warning(
                            "worker_session_close_error",
                            server_id=self.metadata.id,
                            error=str(e),
                        )
                    except (ValueError, OSError):
                        pass

            if transport_ctx:
                try:
                    await transport_ctx.__aexit__(None, None, None)
                    try:
                        logger.debug("worker_transport_closed", server_id=self.metadata.id)
                    except (ValueError, OSError):
                        pass
                except RuntimeError as e:
                    # Ignore anyio cancel scope errors during cleanup
                    # These can occur when the task is cancelled externally
                    if "cancel scope" not in str(e).lower():
                        try:
                            logger.warning(
                                "worker_transport_close_error",
                                server_id=self.metadata.id,
                                error=str(e),
                            )
                        except (ValueError, OSError):
                            pass
                except Exception as e:
                    try:
                        logger.warning(
                            "worker_transport_close_error",
                            server_id=self.metadata.id,
                            error=str(e),
                        )
                    except (ValueError, OSError):
                        pass

            try:
                logger.debug("worker_stopped", server_id=self.metadata.id)
            except (ValueError, OSError):
                pass  # stdout/stderr already closed during shutdown

    async def _process_request(
        self, request: WorkerRequest, session: ClientSession
    ) -> None:
        """
        Process a single request.

        Args:
            request: Request to process
            session: MCP session
        """
        start_time = time.perf_counter()
        response: WorkerResponse

        try:
            self._total_requests += 1
            self._last_used = datetime.now()

            if request.request_type == RequestType.LIST_TOOLS:
                tools_result = await session.list_tools()
                self._tools = tools_result.tools
                response = WorkerResponse(
                    request_id=request.request_id,
                    success=True,
                    data=[tool.model_dump() for tool in self._tools],
                    duration_ms=(time.perf_counter() - start_time) * 1000,
                )

            elif request.request_type == RequestType.CALL_TOOL:
                result = await session.call_tool(
                    request.tool_name, request.arguments or {}
                )
                response = WorkerResponse(
                    request_id=request.request_id,
                    success=True,
                    data={
                        "content": [
                            {"type": text.type, "text": text.text}
                            for text in result.content
                        ],
                        "isError": result.isError,
                    },
                    duration_ms=(time.perf_counter() - start_time) * 1000,
                )

            elif request.request_type == RequestType.HEALTH_CHECK:
                # Lightweight health check: verify subprocess is alive
                # This is much faster than calling list_tools()
                is_healthy = session is not None

                # Check if subprocess is still running (if we have access to it)
                if is_healthy and hasattr(self, '_subprocess_pid') and self._subprocess_pid:
                    try:
                        # Send signal 0 to check if process exists (doesn't actually kill it)
                        os.kill(self._subprocess_pid, 0)
                    except (OSError, ProcessLookupError):
                        is_healthy = False

                response = WorkerResponse(
                    request_id=request.request_id,
                    success=is_healthy,
                    data={"healthy": is_healthy},
                    duration_ms=(time.perf_counter() - start_time) * 1000,
                )

            else:
                raise ValueError(f"Unknown request type: {request.request_type}")

            self._successful_requests += 1

        except Exception as e:
            logger.warning(
                "request_failed",
                server_id=self.metadata.id,
                request_type=request.request_type,
                error=str(e),
            )
            response = WorkerResponse(
                request_id=request.request_id,
                success=False,
                error=str(e),
                duration_ms=(time.perf_counter() - start_time) * 1000,
            )
            self._failed_requests += 1

        # Record latency
        self._latencies.append(response.duration_ms)

        # Send response
        future = self._response_futures.get(request.request_id)
        if future and not future.done():
            future.set_result(response)

    def get_stats(self) -> ConnectionStats:
        """
        Get connection statistics.

        Returns:
            ConnectionStats with current metrics
        """
        uptime_seconds = None
        if self._connected_at:
            uptime_seconds = (datetime.now() - self._connected_at).total_seconds()

        # Calculate latency percentiles
        avg_latency = None
        p95_latency = None
        p99_latency = None
        if self._latencies:
            sorted_lat = sorted(self._latencies)
            avg_latency = sum(sorted_lat) / len(sorted_lat)
            p95_idx = int(len(sorted_lat) * 0.95)
            p99_idx = int(len(sorted_lat) * 0.99)
            p95_latency = sorted_lat[p95_idx] if p95_idx < len(sorted_lat) else None
            p99_latency = sorted_lat[p99_idx] if p99_idx < len(sorted_lat) else None

        # Get process status
        subprocess_status = None
        if self._subprocess_pid:
            try:
                import psutil

                proc = psutil.Process(self._subprocess_pid)
                subprocess_status = proc.status()
            except Exception:
                subprocess_status = "unknown"

        return ConnectionStats(
            server_id=self.metadata.id,
            status=self._status,
            circuit_breaker_state=self._circuit_breaker_state,
            connected_at=self._connected_at,
            last_used=self._last_used,
            uptime_seconds=uptime_seconds,
            total_requests=self._total_requests,
            successful_requests=self._successful_requests,
            failed_requests=self._failed_requests,
            avg_latency_ms=avg_latency,
            p95_latency_ms=p95_latency,
            p99_latency_ms=p99_latency,
            subprocess_pid=self._subprocess_pid,
            subprocess_status=subprocess_status,
        )
