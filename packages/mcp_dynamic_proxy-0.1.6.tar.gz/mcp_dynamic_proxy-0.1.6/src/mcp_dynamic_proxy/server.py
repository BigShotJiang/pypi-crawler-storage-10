"""MCP Dynamic Proxy Server - Main entry point"""

import asyncio
import logging
import os
import sys
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncIterator
from fastmcp import FastMCP
import structlog
from structlog import stdlib as structlog_stdlib

# Add parent directory to path for direct execution
if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from mcp_dynamic_proxy.config import load_config
    from mcp_dynamic_proxy.registry import ServerRegistry
    from mcp_dynamic_proxy.core.manager import ConnectionManager
    from mcp_dynamic_proxy.core.models import PoolConfig, GlobalLimits
    from mcp_dynamic_proxy.resilience.circuit_breaker import CircuitBreakerConfig
    from mcp_dynamic_proxy.resilience.retry import RetryConfig as ResilienceRetryConfig
    from mcp_dynamic_proxy.tools import (
        list_all_servers,
        list_tools,
        execute_tool,
    )
else:
    from .config import load_config
    from .registry import ServerRegistry
    from .core.manager import ConnectionManager
    from .core.models import PoolConfig, GlobalLimits
    from .resilience.circuit_breaker import CircuitBreakerConfig
    from .resilience.retry import RetryConfig as ResilienceRetryConfig
    from .tools import (
        list_all_servers,
        list_tools,
        execute_tool,
    )

# Configure Python's standard logging to stderr (stdout is reserved for JSON-RPC)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stderr,
    force=True  # Override any existing configuration
)

# Suppress verbose MCP server logs
mcp_logger = logging.getLogger("mcp.server.lowlevel.server")
mcp_logger.setLevel(logging.WARNING)

# Suppress FastMCP startup banner/info line
fastmcp_logger = logging.getLogger("fastmcp")
fastmcp_logger.setLevel(logging.WARNING)

# Configure structured logging to stderr (stdout is reserved for JSON-RPC)
structlog.configure(
    processors=[
        structlog.processors.add_log_level,
        structlog_stdlib.filter_by_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.dev.ConsoleRenderer(colors=False),  # Disable ANSI colors
    ],
    logger_factory=structlog_stdlib.LoggerFactory(),  # Use stdlib logger for level filtering
    wrapper_class=structlog_stdlib.BoundLogger,
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger(__name__)

# Load configuration
config_path = os.getenv("MCP_CONFIG_PATH")
if config_path:
    config_path = Path(config_path)
else:
    # Default to config/mcp.json relative to package root
    package_root = Path(__file__).parent.parent.parent
    config_path = package_root / "config" / "mcp.json"

config = load_config(config_path)
registry = ServerRegistry(config)

# Load configuration from config file (with defaults from models)
pool_config = PoolConfig(**config.get("pool", {}))
global_limits = GlobalLimits(**config.get("global_limits", {}))

# Circuit breaker config: map Pydantic field names to dataclass field names
cb_config_dict = config.get("circuit_breaker", {})
if "half_open_max_calls" in cb_config_dict:
    cb_config_dict["half_open_max_requests"] = cb_config_dict.pop("half_open_max_calls")
circuit_breaker_config = CircuitBreakerConfig(**cb_config_dict)

retry_config = ResilienceRetryConfig(**config.get("retry", {}))

manager = ConnectionManager(
    registry,
    pool_config,
    global_limits,
    circuit_breaker_config=circuit_breaker_config,
    retry_config=retry_config,
)


# Lifespan hook for graceful startup and shutdown
@asynccontextmanager
async def proxy_lifespan(server: FastMCP) -> AsyncIterator[None]:
    """
    Manage proxy lifecycle: startup and shutdown.

    This ensures the connection manager is properly started before handling
    requests and gracefully shut down when the server stops, preventing
    asyncio cancel scope errors.
    """
    # Startup: Initialize manager
    logger.debug("server_starting")
    await manager.start()
    logger.debug("server_started")

    yield  # Server runs and handles requests

    # Shutdown: Gracefully stop all connections (guaranteed to run)
    logger.debug("server_shutdown_requested")
    await manager.shutdown()
    logger.debug("server_shutdown_complete")


# Initialize FastMCP with lifespan hook
mcp = FastMCP("mcp-dynamic-proxy", lifespan=proxy_lifespan)


@mcp.tool()
async def mcp_list_servers() -> dict:
    """
    List all available MCP servers with their metadata.
    
    This is the first tool to use when exploring what MCP servers are available.
    It returns all configured MCP servers with their id, description, tags, and
    a list of principal tools.
    
    Note: The tools field contains only the main/principal tools (not exhaustive).
    For complete tool list with schemas, use mcp_list_tools.
    
    Use this to discover what capabilities are available, then use mcp_list_tools
    to explore tools from a specific server.

    Returns:
        Dictionary with:
        - count: number of available servers
        - servers: list of server metadata including id, description, tags, and tools
    """
    return await list_all_servers(registry)


@mcp.tool()
async def mcp_list_tools(server_id: str) -> dict:
    """
    List all tools available from a specific MCP server with their JSON schemas.
    
    Use this after mcp_list_servers to explore what tools are available from a specific server.
    This will automatically load the server if it's not already loaded.
    
    Each tool includes its name, description, and input_schema (JSON schema for validation).

    Args:
        server_id: The MCP server ID (e.g., 'aws-knowledge-mcp-server')

    Returns:
        Dictionary with:
        - server_id: the server identifier
        - status: 'loaded' or 'error'
        - tool_count: number of available tools
        - tools: list of tools with name, description, and input_schema
    """
    return await list_tools(manager, server_id)


@mcp.tool()
async def mcp_execute_tool(
    server_id: str,
    tool_name: str,
    arguments: dict,
) -> dict:
    """
    Execute a tool from a specific MCP server.
    
    Use this to call a tool from an MCP server. The server_id identifies which MCP server
    to use, and tool_name is the specific tool from that server. Arguments must match
    the tool's JSON schema (check with mcp_list_tools first).
    
    This will automatically load the server if it's not already loaded.
    
    Important: server_id is the MCP server name not the tool name.

    Args:
        server_id: The MCP server ID (e.g., 'aws-knowledge-mcp-server')
        tool_name: The name of the tool to execute (e.g., 'aws___list_regions')
        arguments: Dictionary of arguments matching the tool's JSON schema

    Returns:
        Dictionary with:
        - server_id: the server identifier
        - tool_name: the tool that was executed
        - status: 'success' or 'error'
        - result: the tool execution result (if status is 'success')
        - error: error message (if status is 'error')
    """
    return await execute_tool(manager, server_id, tool_name, arguments)


def main():
    """Main entry point for the mcp-dynamic-proxy command."""
    # Disable banner to keep stdout clean for JSON-RPC messages
    mcp.run(show_banner=False)


if __name__ == "__main__":
    main()

