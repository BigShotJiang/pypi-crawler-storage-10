"""
EvenAge CLI package.

Production-grade modular CLI with comprehensive testing support.
"""

__version__ = "0.3.9"

from .main import cli, main


__all__ = ["cli", "main"]
