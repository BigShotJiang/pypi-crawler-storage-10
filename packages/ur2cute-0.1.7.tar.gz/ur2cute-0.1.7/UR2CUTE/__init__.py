# UR2CUTE package initialization
from .model import UR2CUTE

__version__ = "0.1.6"

# This makes "from UR2CUTE import UR2CUTE" work
__all__ = ["UR2CUTE"]