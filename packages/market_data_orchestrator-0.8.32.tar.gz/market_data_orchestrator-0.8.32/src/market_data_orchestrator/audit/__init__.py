"""
Audit logging for control actions.

Phase 6.3 Day 4: Persistent audit trail.
"""

from .logger import AuditLogger

__all__ = ["AuditLogger"]

