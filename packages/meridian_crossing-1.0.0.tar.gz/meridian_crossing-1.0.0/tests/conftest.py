import geopandas as gpd
import pytest
import shapely.affinity
from shapely.geometry import MultiPolygon, Polygon


def _gdf() -> gpd.GeoDataFrame:
    polygon_east = Polygon([(170, 60), (180, 60), (180, 68), (170, 65)])
    polygon_west = Polygon([(-170, 60), (-166, 63), (-160, 64), (-170, 66)])
    polygon_invalid = Polygon([(170, 60), (180, 60), (170, 65), (180, 68)])

    gdf = gpd.GeoDataFrame(
        {
            'name': [
                'East',
                'West',
                'EW',
                'EW touch',
                'Invalid Self-intersection',
            ],
            'geometry': [
                polygon_east,
                shapely.affinity.translate(polygon_west, yoff=-10),
                shapely.affinity.translate(
                    MultiPolygon([polygon_east, polygon_west]), yoff=-20
                ),
                shapely.affinity.translate(
                    MultiPolygon(
                        [
                            polygon_east,
                            shapely.affinity.translate(polygon_west, xoff=-10),
                        ]
                    ),
                    yoff=-30,
                ),
                polygon_invalid,
            ],
        }
    )
    return gdf.set_geometry('geometry').set_crs(epsg=4326)


@pytest.fixture
def gdf() -> gpd.GeoDataFrame:
    return _gdf().iloc[0:4].copy()  # Exclude the invalid geometry


@pytest.fixture
def gdf_invalid() -> gpd.GeoDataFrame:
    return _gdf().copy()  # Include the invalid geometry
