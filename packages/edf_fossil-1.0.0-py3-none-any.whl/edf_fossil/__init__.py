"""Fossil module"""
