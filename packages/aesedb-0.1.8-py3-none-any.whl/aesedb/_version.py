__version__ = "0.1.8"
__banner__ = \
"""
# aesedb %s 
# Author: Tamas Jos @skelsec (info@skelsecprojects.com)
""" % __version__