import cv2
import os
from .image_processing import ShapeDetector


def build_path(file: str) -> str:
    current_directory = os.path.dirname(os.path.abspath(path=__file__))
    file_path = current_directory + f"/{file}"
    return file_path


def main():
    file_path = build_path("img/test_image_00.png")
    img = cv2.imread(file_path)
    print(file_path)
    cv2.imshow("Original", img)

    detector = ShapeDetector()
    [img_out, detected] = detector.detect(img)

    print(detected)
    cv2.imshow("Result", img_out)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
