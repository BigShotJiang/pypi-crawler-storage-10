# Campfire Specification: Team Problem-Solving RAG with Auditor Persistence
## Overview
This specification defines a single campfire’s behavior for task orchestration with a focus on **team problem-solving RAG**, where campers individually review and update their role-specific RAG documents for a task. This procedure is distinct from Campfire’s experiential and temporal RAG evaluation, emphasizing role-based RAG updates within a collaborative team effort orchestrated by the orderer. The auditor oversees challenge mode and retry logic, with self-persistence and customizable RAG documents following a standardized naming convention.

## Orderer Configuration
- **Role**: Orchestrates task processing and camper coordination for team-based problem-solving.
- **Default RAG Documents**:
  - **Task Reception**:
    - Description: Receives task and selects optimal team.
    - Prompt: Analyze task requirements. Select team based on expertise, availability, and task complexity. Output team selection with roles and at-names.
  - **Camper Initialization**:
    - Description: Initializes campers with unique at-names.
    - Prompt: Using selected team, initialize campers with at-names (e.g., @Role_TaskID) for addressing. Store role-specific metadata.
  - **RAG Generation**:
    - Description: Creates role-specific RAG documents for each camper.
    - Prompt: Generate tailored RAG document for each camper based on their assigned role. Include system prompt for LLM integration.
  - **Role-Based RAG Optimization**:
    - Description: Campers review and update their individual RAG documents.
    - Prompt: Instruct each camper to review their RAG document for the task and update it to focus on task-specific priorities from their role’s perspective. Reset after each successful stage.
  - **Problem Solving**:
    - Description: Campers propose solutions using their individual RAGs.
    - Prompt: Present task to campers. Request solutions based on their optimized RAG documents. Collect and validate outputs.
  - **Design**:
    - Description: Campers produce design outputs.
    - Prompt: Instruct campers to create design from their solution, using their RAG. Validate via auditor if challenge mode enabled.
  - **Implementation**:
    - Description: Campers implement design.
    - Prompt: Direct campers to implement design, using their RAG. Validate via auditor if challenge mode enabled.
- **Custom RAG Config**:
  - Config File: Included in `manifest.yaml`, points to a folder (e.g., `rag_configs/`) containing RAG documents for orderer stages.
  - Description: Enables customization of the RAG process for the orderer to guide campers through stages. Folder holds stage-specific RAG files (e.g., `task_reception_rag.txt`, `rag_optimization_rag.txt`) that override or supplement default prompts.
- **Persistence**:
  - Save Config: True
  - File: `manifest.yaml`
  - Save Point: After camper initialization
  - Description: Saves primed task config post-camper setup for reuse.

## Auditor Configuration
- **Role**: Oversees challenge mode, retry logic, and error reporting for camper outputs.
- **Challenge Mode**:
  - Enabled: True (default)
  - Max Retries: 3 per stage
  - Retry Behavior:
    - Reset count after each successful stage.
    - On failure (3 retries): Abort task, generate error report with camper, stage, and error details.
  - Prompt: Instruct campers to validate output for errors. If errors detected, request correction up to 3 times. On failure, compile error report and abort.
- **Auditor RAG Documents**:
  - Description: Stage-specific RAG documents for auditor to guide validation process.
  - Storage: Points to a folder (e.g., `auditor_rag_configs/`) defined in `manifest.yaml`.
  - Naming Convention: Files prepended with `auditor_` followed by stage/purpose, separated by underscores.
  - RAG Files:
    - `auditor_problem_solving_validation_rag.txt`: Validation criteria for problem-solving stage (e.g., solution coherence, task alignment).
    - `auditor_design_validation_rag.txt`: Validation criteria for design stage (e.g., design feasibility, consistency).
    - `auditor_implementation_validation_rag.txt`: Validation criteria for implementation stage (e.g., syntax checks, functionality).
  - Prompt Example: For each stage, load the relevant RAG file to define validation criteria (e.g., syntax checks, logic consistency, task alignment).
- **Self-Persistence**:
  - Save Config: True
  - File: Included in `manifest.yaml`
  - Save Point: After auditor initialization and RAG folder configuration
  - Description: Auditor saves its configuration (challenge mode settings, retry logic, RAG folder path, and stage-specific RAG documents) to `manifest.yaml` for restoration in future sessions.
  - Restoration: On startup, auditor reloads its configuration from `manifest.yaml`, including RAG folder path and stage-specific documents.

## Camper Configuration
- **Addressing**:
  - System: at_names
  - Generation: Assign at-names based on role and task (e.g., @Role_TaskID).
- **RAG Storage**:
  - In Memory: True
  - Description: Store role-specific RAG documents in camper memory, updated during role-based optimization.
- **Stages**:
  - Review RAG: Review and update individual RAG for task priorities based on assigned role.
  - Solve: Propose solution using optimized individual RAG.
  - Design: Create design from solution, validate via auditor if required.
  - Implement: Execute design, validate via auditor if required.

## Metadata
- **Created**: 2025-10-23
- **Distributable**: True
- **Compatibility**: Standalone campfire instances, extensible to Campfire Valley.
- **Note**: Focuses on team problem-solving through individual role-based RAG updates, distinct from experiential/temporal RAG evaluation. Includes customizable RAG config folder for orderer and auditor with standardized `auditor_` naming for auditor RAG files.