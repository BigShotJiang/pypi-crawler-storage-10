"""
Campfire class for orchestrating multimodal LLM workflows.
"""

import asyncio
import logging
import yaml
from typing import List, Dict, Any, Optional, Callable, Union
from datetime import datetime, timedelta
from pathlib import Path

from .torch import Torch
from .camper import Camper
from ..party_box.box_driver import BoxDriver
from ..mcp.protocol import MCPMessage, MCPProtocol
from .orderer import Orderer, OrdererConfig
from .team_auditor import TeamAuditor, TeamAuditorConfig
from .graph_store import GraphStore

logger = logging.getLogger(__name__)


class Campfire:
    """
    A Campfire orchestrates a group of Campers (models/tools) to process
    torches (data) and pass results via MCP to other campfires.
    
    Each campfire has a specific purpose and contains one or more campers
    that work together to process incoming torches and generate new ones.
    """
    
    def __init__(
        self,
        name: str,
        campers: List[Camper],
        party_box: BoxDriver,
        mcp_protocol: Optional[MCPProtocol] = None,
        graph_store: Optional[GraphStore] = None,
        mode: str = "default", # New parameter for different modes
        config: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize a Campfire.
        
        Args:
            name: Unique name for this campfire
            campers: List of campers in this campfire
            party_box: Storage driver for assets
            mcp_protocol: MCP protocol for communication
            mode: The operational mode of the campfire (e.g., "default", "team_rag")
            config: Optional configuration dictionary for the campfire
        """
        self.name = name
        self.campers = campers
        self.party_box = party_box
        self.mcp_protocol = mcp_protocol
        self.mode = mode
        self.config = config or {}
        self.graph_store = graph_store

        self.orderer: Optional[Orderer] = None
        if self.mode == "team_rag":
            orderer_config = OrdererConfig()
            self.orderer = Orderer(
                party_box=self.party_box,
                mcp_protocol=self.mcp_protocol,
                auditor_class=TeamAuditor
            )

        # State management
        self.is_running = False
        self.processed_torches: Dict[str, Torch] = {}
        self.torch_queue: asyncio.Queue = asyncio.Queue()
        
        # Configuration
        self.max_concurrent_tasks = 3
        self.torch_ttl = 24
        self.auto_cleanup = True
        
        # Callbacks
        self.on_torch_processed: Optional[Callable[[Torch], None]] = None
        self.on_error: Optional[Callable[[Exception, Torch], None]] = None
        
        # Setup campers
        for camper in self.campers:
            camper.set_party_box(self.party_box)
            camper.set_campfire_name(self.name)
            # Provide a stable address and graph store for sharing
            camper.set_address(f"camper:{self.name}:{camper.name}")
            if self.graph_store:
                camper.set_graph_store(self.graph_store)
    
    async def start(self) -> None:
        """
        Start the campfire processing loop."""
        if self.is_running:
            logger.warning(f"Campfire {self.name} is already running")
            return
        
        self.is_running = True
        logger.info(f"Starting campfire: {self.name}")
        
        # Start processing tasks
        tasks = []
        for i in range(self.max_concurrent_tasks):
            task = asyncio.create_task(self._processing_loop())
            tasks.append(task)
        
        # Start cleanup task if enabled
        if self.auto_cleanup:
            cleanup_task = asyncio.create_task(self._cleanup_loop())
            tasks.append(cleanup_task)
        
        # Subscribe to MCP channels if protocol is available
        if self.mcp_protocol:
            await self._setup_mcp_subscriptions()
        
        # Wait for all tasks to complete
        try:
            await asyncio.gather(*tasks)
        except asyncio.CancelledError:
            logger.info(f"Campfire {self.name} processing cancelled")
        finally:
            self.is_running = False
    
    async def stop(self) -> None:
        """
        Stop the campfire processing."""
        logger.info(f"Stopping campfire: {self.name}")
        self.is_running = False
        
        # Cancel any pending tasks
        for task in asyncio.all_tasks():
            if not task.done() and task.get_name().startswith(f"campfire_{self.name}"):
                task.cancel()
    
    async def process_torch(self, torch: Torch) -> List[Torch]:
        """
        Process a single torch through all campers.
        
        Args:
            torch: Input torch to process
            
        Returns:
            List of output torches generated by campers
        """
        logger.info(f"Processing torch {torch.torch_id} in campfire {self.name}")
        
        try:
            output_torches = []
            
            # Process through each camper
            for camper in self.campers:
                logger.debug(f"Processing torch with camper: {camper.__class__.__name__}")
                
                try:
                    # Process the torch
                    result_torches = await camper.process(torch)
                    
                    if result_torches:
                        if isinstance(result_torches, Torch):
                            result_torches = [result_torches]
                        
                        for result_torch in result_torches:
                            # Set source campfire and channel, prioritizing original torch values
                            result_torch.source_campfire = result_torch.source_campfire or torch.source_campfire or self.name
                            result_torch.channel = result_torch.channel or torch.channel or self.name
                            result_torch.metadata['processed_by'] = camper.__class__.__name__
                            result_torch.metadata['parent_torch_id'] = torch.torch_id
                            
                            output_torches.append(result_torch)
                            
                            # Send via MCP if available
                            if self.mcp_protocol:
                                await self._send_torch_via_mcp(result_torch)
                
                except Exception as e:
                    logger.error(f"Error processing torch with {camper.__class__.__name__}: {e}")
                    if self.on_error:
                        self.on_error(e, torch)
                    continue
            
            # Store processed torch
            self.processed_torches[torch.torch_id] = torch
            
            # Call callback if set
            if self.on_torch_processed:
                self.on_torch_processed(torch)
            
            logger.info(f"Generated {len(output_torches)} output torches from {torch.torch_id}")
            return output_torches
            
        except Exception as e:
            logger.error(f"Error processing torch {torch.torch_id}: {e}")
            if self.on_error:
                self.on_error(e, torch)
            return []
    
    async def add_torch(self, torch: Torch) -> None:
        """
        Add a torch to the processing queue.
        
        Args:
            torch: Torch to add to queue
        """
        await self.torch_queue.put(torch)
        logger.debug(f"Added torch {torch.torch_id} to queue")
    
    async def _processing_loop(self) -> None:
        """
        Main processing loop for the campfire.
        """
        while self.is_running:
            try:
                torch = await self.torch_queue.get()
                await self.process_torch(torch)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in processing loop: {e}")
                if self.on_error:
                    self.on_error(e, None) # Pass None for torch if not available
    
    async def _cleanup_loop(self) -> None:
        """
        Periodically cleans up old torches from processed_torches.
        """
        while self.is_running:
            await asyncio.sleep(3600) # Clean up every hour
            
            cutoff_time = datetime.now() - timedelta(hours=self.torch_ttl)
            torches_to_remove = [
                torch_id for torch_id, torch in self.processed_torches.items()
                if torch.timestamp < cutoff_time
            ]
            
            for torch_id in torches_to_remove:
                del self.processed_torches[torch_id]
                logger.debug(f"Cleaned up old torch: {torch_id}")
    
    async def _setup_mcp_subscriptions(self) -> None:
        """
        Set up MCP subscriptions for incoming torches.
        """
        if self.mcp_protocol:
            # Subscribe to a channel for incoming torches
            await self.mcp_protocol.subscribe(
                channel=f"campfire.{self.name}.in",
                callback=self._handle_mcp_torch
            )
            logger.info(f"Subscribed to MCP channel: campfire.{self.name}.in")
    
    async def _send_torch_via_mcp(self, torch: Torch):
        if self.mcp_protocol and self.mcp_protocol.is_running():
            try:
                await self.mcp_protocol.send_torch(torch)
            except Exception as e:
                logger.error(f"Failed to send torch {torch.torch_id} via MCP: {e}")
        else:
            logger.warning(f"MCP protocol not running, cannot send torch {torch.torch_id}")
    
    async def _handle_mcp_torch(self, message: MCPMessage) -> None:
        """
        Handles incoming MCP messages containing torches.
        """
        if message.message_type == "torch":
            torch = Torch.from_mcp_message(message.to_dict())
            await self.add_torch(torch)
            logger.info(f"Received torch {torch.torch_id} from MCP channel: {message.channel}")
        else:
            logger.warning(f"Received unknown MCP message type: {message.message_type}")


class CampfireManager:
    """
    Manager for multiple campfires, handling coordination and routing.
    """
    
    def __init__(self, mcp_protocol: Optional[MCPProtocol] = None):
        """
        Initialize the campfire manager.
        
        Args:
            mcp_protocol: Shared MCP protocol for all campfires
        """
        self.campfires: Dict[str, Campfire] = {}
        self.mcp_protocol = mcp_protocol
        self.is_running = False
    
    def add_campfire(self, campfire: Campfire) -> None:
        """
        Add a campfire to the manager.
        
        Args:
            campfire: Campfire to add
        """
        self.campfires[campfire.name] = campfire
        
        # Set MCP protocol if not already set
        if self.mcp_protocol and not campfire.mcp_protocol:
            campfire.mcp_protocol = self.mcp_protocol
    
    async def start_all(self) -> None:
        """Start all campfires."""
        self.is_running = True
        
        tasks = []
        for campfire in self.campfires.values():
            task = asyncio.create_task(campfire.start())
            tasks.append(task)
        
        await asyncio.gather(*tasks)
    
    async def stop_all(self) -> None:
        """Stop all campfires."""
        self.is_running = False
        
        tasks = []
        for campfire in self.campfires.values():
            task = asyncio.create_task(campfire.stop())
            tasks.append(task)
        
        await asyncio.gather(*tasks)
    
    def get_campfire(self, name: str) -> Optional[Campfire]:
        """Get a campfire by name."""
        return self.campfires.get(name)
    
    def get_all_stats(self) -> Dict[str, Any]:
        """Get stats for all campfires."""
        return {
            'manager_running': self.is_running,
            'campfires_count': len(self.campfires),
            'campfires': {name: cf.get_stats() for name, cf in self.campfires.items()}
        }
    
    def save_campfire_manifest(self, campfire_name: str, manifest_path: str) -> None:
        """
        Save a specific campfire's configuration to a YAML manifest file.
        
        Args:
            campfire_name: Name of the campfire to save
            manifest_path: Full path where to save the manifest file
            
        Raises:
            KeyError: If campfire with given name doesn't exist
        """
        if campfire_name not in self.campfires:
            raise KeyError(f"Campfire '{campfire_name}' not found in manager")
        
        campfire = self.campfires[campfire_name]
        campfire.save_to_yaml(manifest_path)
        logger.info(f"Saved campfire '{campfire_name}' manifest to: {manifest_path}")
    
    def save_all_manifests(self, base_directory: str, filename_template: str = "{name}.yaml") -> Dict[str, str]:
        """
        Save all campfires' configurations to YAML manifest files.
        
        Args:
            base_directory: Directory where to save all manifest files
            filename_template: Template for filenames, {name} will be replaced with campfire name
            
        Returns:
            Dictionary mapping campfire names to their saved file paths
        """
        base_path = Path(base_directory)
        base_path.mkdir(parents=True, exist_ok=True)
        
        saved_files = {}
        for name, campfire in self.campfires.items():
            filename = filename_template.format(name=name)
            file_path = base_path / filename
            campfire.save_to_yaml(str(file_path))
            saved_files[name] = str(file_path)
        
        logger.info(f"Saved {len(saved_files)} campfire manifests to: {base_directory}")
        return saved_files
    
    def load_campfire_from_manifest(self, manifest_path: str, party_box: 'BoxDriver', 
                                   campfire_name: Optional[str] = None) -> str:
        """
        Load a campfire from a YAML manifest file and add it to the manager.
        
        Args:
            manifest_path: Path to the YAML manifest file
            party_box: Party box driver instance for the campfire
            campfire_name: Optional custom name for the campfire (overrides manifest name)
            
        Returns:
            Name of the loaded campfire
            
        Raises:
            FileNotFoundError: If manifest file doesn't exist
            ValueError: If campfire with same name already exists
        """
        if not Path(manifest_path).exists():
            raise FileNotFoundError(f"Manifest file not found: {manifest_path}")
        
        # Load campfire from YAML
        campfire = Campfire.load_from_yaml(manifest_path, party_box, self.mcp_protocol)
        
        # Use custom name if provided
        if campfire_name:
            campfire.name = campfire_name
        
        # Check for name conflicts
        if campfire.name in self.campfires:
            raise ValueError(f"Campfire with name '{campfire.name}' already exists in manager")
        
        # Add to manager
        self.add_campfire(campfire)
        logger.info(f"Loaded campfire '{campfire.name}' from manifest: {manifest_path}")
        
        return campfire.name
    
    def load_manifests_from_directory(self, manifests_directory: str, party_box: 'BoxDriver', 
                                     pattern: str = "*.yaml") -> List[str]:
        """
        Load all YAML manifest files from a directory.
        
        Args:
            manifests_directory: Directory containing manifest files
            party_box: Party box driver instance for campfires
            pattern: File pattern to match (default: "*.yaml")
            
        Returns:
            List of loaded campfire names
            
        Raises:
            FileNotFoundError: If directory doesn't exist
        """
        manifest_dir = Path(manifests_directory)
        if not manifest_dir.exists():
            raise FileNotFoundError(f"Manifests directory not found: {manifests_directory}")
        
        loaded_campfires = []
        manifest_files = list(manifest_dir.glob(pattern))
        
        for manifest_file in manifest_files:
            try:
                campfire_name = self.load_campfire_from_manifest(
                    str(manifest_file), party_box
                )
                loaded_campfires.append(campfire_name)
            except Exception as e:
                logger.warning(f"Failed to load manifest {manifest_file}: {e}")
                continue
        
        logger.info(f"Loaded {len(loaded_campfires)} campfires from directory: {manifests_directory}")
        return loaded_campfires
    
    def export_manager_state(self, export_path: str) -> Dict[str, Any]:
        """
        Export the entire manager state including all campfires to a directory structure.
        
        Args:
            export_path: Base directory where to export the manager state
            
        Returns:
            Dictionary containing export metadata
        """
        export_dir = Path(export_path)
        export_dir.mkdir(parents=True, exist_ok=True)
        
        # Create subdirectories
        manifests_dir = export_dir / "manifests"
        manifests_dir.mkdir(exist_ok=True)
        
        # Save all campfire manifests
        saved_manifests = self.save_all_manifests(str(manifests_dir))
        
        # Create manager metadata
        manager_metadata = {
            'export_timestamp': datetime.utcnow().isoformat(),
            'manager_stats': self.get_all_stats(),
            'campfires_count': len(self.campfires),
            'manifest_files': saved_manifests,
            'export_version': '1.0'
        }
        
        # Save manager metadata
        metadata_file = export_dir / "manager_metadata.yaml"
        with open(metadata_file, 'w', encoding='utf-8') as f:
            yaml.dump(manager_metadata, f, default_flow_style=False, indent=2)
        
        logger.info(f"Exported manager state to: {export_path}")
        return manager_metadata
    
    def import_manager_state(self, import_path: str, party_box: 'BoxDriver', 
                           clear_existing: bool = False) -> Dict[str, Any]:
        """
        Import manager state from a previously exported directory structure.
        
        Args:
            import_path: Base directory containing exported manager state
            party_box: Party box driver instance for campfires
            clear_existing: Whether to clear existing campfires before importing
            
        Returns:
            Dictionary containing import results
        """
        import_dir = Path(import_path)
        if not import_dir.exists():
            raise FileNotFoundError(f"Import directory not found: {import_path}")
        
        # Clear existing campfires if requested
        if clear_existing:
            self.campfires.clear()
            logger.info("Cleared existing campfires before import")
        
        # Load manager metadata
        metadata_file = import_dir / "manager_metadata.yaml"
        if metadata_file.exists():
            with open(metadata_file, 'r', encoding='utf-8') as f:
                metadata = yaml.safe_load(f)
        else:
            metadata = {}
        
        # Load campfire manifests
        manifests_dir = import_dir / "manifests"
        loaded_campfires = []
        
        if manifests_dir.exists():
            loaded_campfires = self.load_manifests_from_directory(
                str(manifests_dir), party_box
            )
        
        import_results = {
            'import_timestamp': datetime.utcnow().isoformat(),
            'loaded_campfires': loaded_campfires,
            'loaded_count': len(loaded_campfires),
            'original_metadata': metadata
        }
        
        logger.info(f"Imported manager state from: {import_path}")
        return import_results