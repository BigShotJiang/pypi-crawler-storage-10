"""Constants used in this project."""

PROJECT_NAME: str = "sbx_emotions_kb_emoclass"
