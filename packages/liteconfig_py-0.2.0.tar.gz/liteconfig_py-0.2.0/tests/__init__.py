"""
Test package for liteconfig_py.
"""