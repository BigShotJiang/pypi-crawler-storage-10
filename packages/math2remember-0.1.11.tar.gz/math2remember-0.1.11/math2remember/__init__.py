from .isPrime import isPrime
from .getPrimeGen import getPrimeGenFrom, getPrimeGenTo
from .extendedEuclidian import extendedEuclidian
from .fibGen import fibGen

__version__ = '0.1.11'
__all__ = ['extendedEuclidian', 'isPrime', 'getPrimeGenFrom', 'getPrimeGenTo', 'fibGen']