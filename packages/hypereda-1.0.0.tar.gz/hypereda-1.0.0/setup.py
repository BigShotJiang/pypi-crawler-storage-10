from setuptools import setup, find_packages

setup(
    name="hypereda",
    version="1.0.0",
    author="Saurav Bhabak",
    author_email="souravbhabak7@gmail.com",
    description="Automated and Interactive Exploratory Data Analysis with Visualization and Streamlit Interface",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "pandas==2.2.2",
        "numpy==1.26.4",
        "matplotlib==3.9.2",
        "seaborn==0.13.2",
        "plotly==5.24.0",
        "tqdm==4.66.4",
        "termcolor==2.5.0",
        "streamlit==1.38.0"
    ],
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Information Analysis",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
)