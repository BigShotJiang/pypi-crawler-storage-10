"""
HyperEDA Package
Automated and Interactive Exploratory Data Analysis Tool
Author: Saurav Bhabak
Version: 1.0.0
"""

from .EDA import EDA  # Importing main EDA class

__all__ = ["EDA"]
__version__ = "1.0.0"
__author__ = "Saurav Bhabak"
__email__ = "souravbhabak7@gmail.com"
__description__ = "Automated, Interactive, and Visual EDA Library powered by Streamlit"