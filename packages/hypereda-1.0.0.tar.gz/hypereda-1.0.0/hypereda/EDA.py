# smarteda_ultimate.py
# HyperEDA Ultimate v1.0
# Author: Saurav (assembled for user)
# Description: Production-ish interactive EDA dashboard (local only).
# Features: Basic info, head (1..n/all), describe, null/duplicate checks,
# many interactive Plotly plots, multi-plot selection, multi-column comparison,
# auto-sampling for large data, improved summary paragraph, nicer UI.
# NO public tunnel, NO OTP. Port configurable (default 7070).

import os
import sys
import time
import json
import tempfile
import subprocess
import warnings
from pathlib import Path
from typing import Optional, List

import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import seaborn as sns
from termcolor import colored
from tqdm import tqdm

warnings.filterwarnings("ignore")
sns.set_theme()  # seaborn style for any matplotlib fallbacks

# ---------------- utility helpers ----------------
def _safe_mkdir(p: Path):
    try:
        p.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

def _safe_write(path: Path, text: str):
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
        return True
    except Exception as e:
        print(colored(f"⚠️ Write failed: {e}", "red"))
        return False

def _progress_print(steps: List[tuple]):
    print(colored("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", "cyan"))
    print(colored("🚀 HyperEDA: Initializing Interactive Report...", "green", attrs=["bold"]))
    print(colored("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", "cyan"))
    for msg, pct in steps:
        print(colored(f"[{pct}%] {msg}", "yellow"))
        time.sleep(0.02)

# ---------------- core HyperEDA class ----------------
class EDA:
    """
    HyperEDA Ultimate v1.0
    Parameters:
        data (pd.DataFrame): Required.
        max_rows_sample (int): sample size for interactive plotting (default 10000).
        max_head_display (int): safety cap when user asks 'all' for preview (default 20000).
        port (int): Local Streamlit server port (default 7070).
    """
    # canonical plot list (extensible)
    TOP_PLOTS = [
        "Histogram","KDE","ECDF","Boxplot","Violin","Strip","Swarm","Countplot","Barplot","Lineplot",
        "Area","Scatter","Hexbin","Jointplot","Pairplot","ScatterMatrix","Bubble","Heatmap","ParallelCoords",
        "Treemap","Sunburst","StackedBar","GroupedBar","FacetGrid","LagPlot","Autocorr","Radar","DotPlot",
        "SlopeChart","Pyramid","ConfusionMatrix","ROC","FeatureImportance","PCA","ClusterPlot","Dendrogram",
        "Density2D","JointKDE","AreaStack","Funnel","Waterfall","CalendarHeatmap","WordCloud","ECDF2"
    ]

    def __init__(
        self,
        data: pd.DataFrame,
        max_rows_sample: int = 10000,
        max_head_display: int = 20000,
        port: int = 7070,
    ):
        if not isinstance(data, pd.DataFrame):
            raise ValueError("data must be a pandas DataFrame")
        self.df = data.copy()
        self.max_rows_sample = max(100, int(max_rows_sample))
        self.max_head_display = int(max_head_display)
        self.port = int(port)

        # temp workspace
        self.tmpdir = Path(tempfile.gettempdir()) / f"hypereda_{int(time.time())}"
        _safe_mkdir(self.tmpdir)
        self.full_csv = self.tmpdir / "full.csv"
        self.sample_csv = self.tmpdir / "sample.csv"
        self.streamlit_script = self.tmpdir / "hypereda_app.py"
        self.log_file = self.tmpdir / "hypereda_streamlit.log"

        # metadata & summary
        self.meta = {}
        self.summary_text = ""

        # run prepare & launch
        self._prepare()
        self._write_streamlit_script()
        self._launch_streamlit()

    # ---------------- preparation stage ----------------
    def _prepare(self):
        steps = [
            ("Loading dataset into memory...", 5),
            ("Saving full dataset...", 12),
            ("Creating sample for interactive plots...", 30),
            ("Inspecting dtypes, nulls and duplicates...", 55),
            ("Calculating summary statistics...", 75),
            ("Finalizing preparation...", 95),
        ]
        _progress_print(steps)

        # save full (CSV fallback to pickle)
        try:
            self.df.to_csv(self.full_csv, index=False)
            print(colored(f"[12%] Saved full dataset to {self.full_csv}", "green"))
        except Exception:
            try:
                self.df.to_pickle(self.full_csv.with_suffix(".pkl"))
                self.full_csv = self.full_csv.with_suffix(".pkl")
                print(colored("[12%] Saved full dataset as pickle (fallback)", "green"))
            except Exception as e:
                print(colored(f"⚠️ Failed to save full dataset: {e}", "red"))

        # create sample for plotting
        try:
            if len(self.df) > self.max_rows_sample:
                sample = self.df.sample(n=self.max_rows_sample, random_state=42)
            else:
                sample = self.df.copy()
            sample.to_csv(self.sample_csv, index=False)
            print(colored(f"[35%] Sample saved (n={len(sample)}) to {self.sample_csv}", "green"))
        except Exception as e:
            print(colored(f"⚠️ Failed to save sample: {e}", "red"))

        # compute metadata
        try:
            df = self.df
            rows, cols = df.shape
            total_cells = max(1, rows * cols)
            null_count = int(df.isnull().sum().sum())
            null_pct = round((null_count / total_cells) * 100, 4)
            dup_count = int(df.duplicated().sum())
            mem_bytes = int(df.memory_usage(deep=True).sum())
            num_cols = list(df.select_dtypes(include="number").columns)
            cat_cols = list(df.select_dtypes(exclude="number").columns)
            datetime_cols = list(df.select_dtypes(include=["datetime","datetime64"]).columns)
            const_cols = [c for c in df.columns if df[c].nunique(dropna=False) <= 1]
            high_card_cols = [c for c in df.columns if df[c].nunique() > max(50, int(rows*0.1))]

            corr_strength = None
            if len(num_cols) >= 2:
                try:
                    corrmat = df[num_cols].corr().abs()
                    tri = corrmat.values[np.triu_indices(len(num_cols), k=1)]
                    corr_strength = float(np.nanmean(tri)) if len(tri) > 0 else None
                except Exception:
                    corr_strength = None

            self.meta = {
                "rows": rows,
                "cols": cols,
                "null_count": null_count,
                "null_pct": null_pct,
                "dup_count": dup_count,
                "mem_bytes": mem_bytes,
                "num_cols": num_cols,
                "cat_cols": cat_cols,
                "datetime_cols": datetime_cols,
                "const_cols": const_cols,
                "high_card_cols": high_card_cols,
                "corr_strength": corr_strength,
            }
            print(colored("[65%] Metadata computed.", "green"))
        except Exception as e:
            print(colored(f"⚠️ Metadata computation failed: {e}", "red"))

        # generate summary
        try:
            self._generate_summary()
            print(colored("[85%] Summary generated.", "green"))
        except Exception as e:
            print(colored(f"⚠️ Summary generation failed: {e}", "red"))

        print(colored("[95%] Preparation complete.", "cyan"))

    # ---------------- improved summary ----------------
    def _generate_summary(self):
        m = self.meta
        rows = m.get("rows", 0)
        cols = m.get("cols", 0)
        null_pct = m.get("null_pct", 0.0)
        dup = m.get("dup_count", 0)
        nnum = len(m.get("num_cols", []))
        ncat = len(m.get("cat_cols", []))

        corr_msg = "no numeric correlation calculated"
        if m.get("corr_strength") is not None:
            c = m["corr_strength"]
            if c >= 0.7:
                corr_msg = "strong correlations among numeric features"
            elif c >= 0.4:
                corr_msg = "moderate correlations among numeric features"
            else:
                corr_msg = "weak correlations among numeric features"

        # top numeric descriptive highlights (up to 3)
        top_num = m.get("num_cols", [])[:3]
        num_insights = []
        for col in top_num:
            try:
                s = self.df[col].dropna()
                mean = round(s.mean(), 4)
                med = round(s.median(), 4)
                skew = round(s.skew(), 4)
                num_insights.append(f"'{col}' mean={mean}, median={med}, skew={skew}")
            except Exception:
                continue

        # top null columns
        nulls = self.df.isnull().sum()
        top_null_cols = nulls[nulls > 0].sort_values(ascending=False).head(3).to_dict()

        parts = [
            f"The dataset contains {rows:,} rows and {cols} columns.",
            f"There are {nnum} numeric and {ncat} categorical features.",
        ]
        if top_num:
            parts.append("Key numeric highlights: " + "; ".join(num_insights) + ".")
        parts.append(f"Approximately {null_pct}% missing values overall; top missing columns: {top_null_cols}.")
        parts.append(f"{dup} duplicate rows detected.")
        parts.append(corr_msg + ".")
        parts.append("Overall the dataset is " + ("reasonably clean" if null_pct < 5 and dup == 0 else "suggested to be cleaned before modeling") + ".")

        self.summary_text = " ".join(parts)

    # ---------------- write streamlit script ----------------
    def _write_streamlit_script(self):
        print(colored("[97%] Writing Streamlit application...", "yellow"))
        full_path = str(self.full_csv).replace("\\", "\\\\")
        sample_path = str(self.sample_csv).replace("\\", "\\\\")
        summary_esc = self.summary_text.replace('"', '\\"').replace("\n", "\\n")
        plots_json = json.dumps(self.TOP_PLOTS)

        # Build a robust Streamlit script (embedded). NOTE: avoid outer f-strings in template.
        app_template = """
# Auto-generated HyperEDA Ultimate app
import streamlit as st
import pandas as pd, numpy as np, io
import plotly.express as px, plotly.graph_objects as go

st.set_page_config(page_title="HyperEDA Ultimate", layout="wide", initial_sidebar_state="expanded")

FULL_CSV = r"{FULL}"
SAMPLE_CSV = r"{SAMPLE}"
SUMMARY_TEXT = "{SUMMARY}"

# Load sample first (fast)
try:
    df_sample = pd.read_csv(SAMPLE_CSV)
except Exception:
    df_sample = pd.read_csv(FULL_CSV)

try:
    df_full = pd.read_csv(FULL_CSV)
except Exception:
    df_full = df_sample.copy()

# ---------- Sidebar (Core Info & Controls) ----------
st.sidebar.title("🔍 Dataset Overview")
st.sidebar.markdown("Shape: " + str(df_full.shape))
st.sidebar.markdown("Rows: " + str(len(df_full)) + " | Columns: " + str(df_full.shape[1]))
st.sidebar.markdown("---")
st.sidebar.subheader("Column types")
st.sidebar.dataframe(df_full.dtypes.rename('dtype').to_frame())
st.sidebar.markdown("---")
st.sidebar.subheader("Nulls (per column)")
st.sidebar.dataframe(df_sample.isnull().sum().to_frame('nulls'))
st.sidebar.markdown("---")
st.sidebar.write("Duplicate rows: " + str(df_full.duplicated().sum()))
st.sidebar.markdown("---")

# Head control
st.sidebar.subheader("Preview Rows")
head_choice = st.sidebar.text_input("Enter number or 'all'", value="5")

# Plot selection & options
plots_list = {PLOTS}
st.sidebar.subheader("Choose Plots")
selected_plots = st.sidebar.multiselect("Select visualizations", options=plots_list, default=["Histogram", "Heatmap", "Boxplot"])

st.sidebar.markdown("---")
st.sidebar.subheader("Comparison columns")
columns = df_sample.columns.tolist()
comp_cols = st.sidebar.multiselect("Columns (1..N) for comparison", options=columns, default=columns[:2])

# show important plot params (minimal)
st.sidebar.markdown("---")
st.sidebar.subheader("Common plot params")
hist_kde = st.sidebar.checkbox("Histogram: show KDE", value=True)
hist_bins = st.sidebar.slider("Histogram bins", 10, 200, 40)
box_points = st.sidebar.checkbox("Boxplot: show points", value=False)
heatmap_annot = st.sidebar.checkbox("Heatmap: annotate values", value=True)
pair_sample = st.sidebar.slider("Pairplot sample", 100, min(2000, max(200, len(df_sample))), 500)

st.sidebar.markdown("---")
st.sidebar.write("Server: Local only")
st.sidebar.write("Port: {PORT}")
st.sidebar.markdown("---")
if st.sidebar.button("Download sample CSV"):
    tmp = io.BytesIO()
    df_sample.to_csv(tmp, index=False)
    tmp.seek(0)
    st.sidebar.download_button("Download sample", data=tmp, file_name="hypereda_sample.csv", mime="text/csv")

# ---------- Main Layout ----------
tabs = st.tabs(["Overview", "Visualizations", "Correlation", "Summary"])

# ---------- Overview Tab ----------
with tabs[0]:
    st.header("Dataset Overview")
    st.markdown("Top-level statistics")
    col1, col2, col3 = st.columns(3)
    col1.metric("Rows", str(len(df_full)))
    col2.metric("Columns", str(df_full.shape[1]))
    missing_pct = 0.0
    try:
        missing_pct = round((df_full.isnull().sum().sum()/(max(1, df_full.shape[0]*df_full.shape[1]))*100),3)
    except Exception:
        missing_pct = 0.0
    col3.metric("Missing %", str(missing_pct) + "%")

    st.markdown("Preview")
    if str(head_choice).strip().lower() == 'all':
        if df_full.shape[0] > {MAX_HEAD}:
            st.warning("Large dataset: capping preview to {MAX_HEAD} rows.")
            st.dataframe(df_full.head({MAX_HEAD}))
        else:
            st.dataframe(df_full)
    else:
        try:
            n = int(head_choice)
            st.dataframe(df_full.head(max(1, min(n, {MAX_HEAD}))))
        except Exception:
            st.dataframe(df_full.head(5))

    st.markdown("Data Types")
    st.dataframe(df_full.dtypes.rename("dtype").to_frame())
    st.markdown("Descriptive Statistics (sample)")
    try:
        st.dataframe(df_sample.describe(include='all'))
    except Exception:
        st.write("Describe not available.")

# ---------- Visualizations Tab ----------
with tabs[1]:
    st.header("Interactive Visualizations")
    if not selected_plots:
        st.info("Choose visualizations from the sidebar to begin.")
    else:
        for p in selected_plots:
            st.subheader(p)
            try:
                # ---------------- Histogram ----------------
                if p == "Histogram":
                    for c in (comp_cols or columns[:1]):
                        if c in df_sample.select_dtypes(include='number').columns:
                            fig = px.histogram(df_sample, x=c, nbins=hist_bins, title="Histogram - " + str(c))
                            if hist_kde:
                                fig.update_traces(histnorm='probability density')
                            st.plotly_chart(fig, use_container_width=True)
                        else:
                            st.warning("Histogram needs numeric column: " + str(c))

                # ---------------- KDE ----------------
                elif p == "KDE":
                    for c in (comp_cols or columns[:1]):
                        if c in df_sample.select_dtypes(include='number').columns:
                            fig = px.histogram(df_sample, x=c, nbins=200, histnorm='probability density', title="Density (KDE-like) - " + str(c))
                            st.plotly_chart(fig, use_container_width=True)
                        else:
                            st.warning("KDE needs numeric column.")

                # ---------------- ECDF ----------------
                elif p == "ECDF":
                    for c in (comp_cols or columns[:1]):
                        if c in df_sample.select_dtypes(include='number').columns:
                            s = np.sort(df_sample[c].dropna())
                            y = np.arange(1, len(s)+1)/len(s)
                            fig = go.Figure(go.Scatter(x=s, y=y, mode='lines'))
                            fig.update_layout(title="ECDF - " + str(c), xaxis_title=c, yaxis_title="ECDF")
                            st.plotly_chart(fig, use_container_width=True)
                        else:
                            st.warning("ECDF needs numeric column.")

                # ---------------- Boxplot ----------------
                elif p == "Boxplot":
                    for c in (comp_cols or columns[:1]):
                        if c in df_sample.select_dtypes(include='number').columns:
                            fig = px.box(df_sample, y=c, points=("all" if box_points else "outliers"), title="Boxplot - " + str(c))
                            st.plotly_chart(fig, use_container_width=True)
                        else:
                            st.warning("Boxplot needs numeric column.")

                # ---------------- Violin ----------------
                elif p == "Violin":
                    for c in (comp_cols or columns[:1]):
                        if c in df_sample.select_dtypes(include='number').columns:
                            fig = px.violin(df_sample, y=c, box=True, title="Violin - " + str(c))
                            st.plotly_chart(fig, use_container_width=True)
                        else:
                            st.warning("Violin needs numeric column.")

                # ---------------- Scatter ----------------
                elif p == "Scatter":
                    if len(comp_cols) >= 2:
                        x = comp_cols[0]; y = comp_cols[1]
                        if x in df_sample.columns and y in df_sample.columns:
                            fig = px.scatter(df_sample, x=x, y=y, title="Scatter: " + str(x) + " vs " + str(y), hover_data=comp_cols)
                            st.plotly_chart(fig, use_container_width=True)
                        else:
                            st.warning("Select valid columns for scatter.")
                    else:
                        st.warning("Select at least 2 columns for scatter.")

                # ---------------- Pairplot / ScatterMatrix ----------------
                elif p in ("Pairplot", "ScatterMatrix"):
                    numdf = df_sample.select_dtypes(include='number')
                    usecols = list(numdf.columns)[:min(6, len(numdf.columns))]
                    if len(usecols) >= 2:
                        samp = numdf[usecols].sample(n=min(pair_sample, len(numdf)), random_state=42)
                        fig = px.scatter_matrix(samp, dimensions=usecols, title="Pairplot (sampled)")
                        st.plotly_chart(fig, use_container_width=True)
                    else:
                        st.warning("Not enough numeric columns for pairplot.")

                # ---------------- Heatmap ----------------
                elif p == "Heatmap":
                    numdf = df_sample.select_dtypes(include='number')
                    if numdf.shape[1] >= 2:
                        corrm = numdf.corr()
                        fig = px.imshow(corrm, text_auto=heatmap_annot, aspect='auto', color_continuous_scale='RdBu_r', title="Correlation Heatmap")
                        fig.update_layout(height=600)
                        st.plotly_chart(fig, use_container_width=True)
                    else:
                        st.warning("Not enough numeric columns for heatmap.")

                # ---------------- Treemap / Sunburst ----------------
                elif p in ("Treemap", "Sunburst"):
                    if len(comp_cols) >= 2:
                        cat = comp_cols[0]; val = comp_cols[1]
                        if cat in df_sample.columns and val in df_sample.columns:
                            dfagg = df_sample.groupby(cat)[val].sum().reset_index()
                            if p == "Treemap":
                                fig = px.treemap(dfagg, path=[cat], values=val, title="Treemap by " + str(cat))
                            else:
                                fig = px.sunburst(dfagg, path=[cat], values=val, title="Sunburst by " + str(cat))
                            st.plotly_chart(fig, use_container_width=True)
                        else:
                            st.warning("Select categorical and numeric column for Treemap/Sunburst.")
                    else:
                        st.warning("Select at least 2 columns for Treemap/Sunburst.")

                # ---------------- Parallel Coordinates ----------------
                elif p == "ParallelCoords":
                    numdf = df_sample.select_dtypes(include='number')
                    usecols = list(numdf.columns)[:min(8, len(numdf.columns))]
                    if len(usecols) >= 2:
                        samp = df_sample[usecols].dropna().sample(n=min(1000, len(df_sample)), random_state=42)
                        fig = px.parallel_coordinates(samp, dimensions=usecols, title="Parallel Coordinates")
                        st.plotly_chart(fig, use_container_width=True)
                    else:
                        st.warning("Not enough numeric columns for Parallel Coordinates.")

                # ---------------- Time / Autocorr / Lag ----------------
                elif p == "LagPlot":
                    if comp_cols:
                        c = comp_cols[0]
                        if c in df_sample.select_dtypes(include='number').columns:
                            x = df_sample[c].dropna()
                            fig = px.scatter(x=x[:-1], y=x[1:], title="Lag plot - " + str(c))
                            st.plotly_chart(fig, use_container_width=True)
                        else:
                            st.warning("Lag plot needs numeric column.")
                    else:
                        st.warning("Select numeric column for lag plot.")

                elif p == "Autocorr":
                    try:
                        import statsmodels.api as sm
                        c = comp_cols[0] if comp_cols else None
                        if c and c in df_sample.select_dtypes(include='number').columns:
                            acf = sm.tsa.acf(df_sample[c].dropna(), fft=True, nlags=40)
                            fig = go.Figure(data=go.Bar(x=list(range(len(acf))), y=acf))
                            fig.update_layout(title="Autocorrelation - " + str(c), xaxis_title="lag", yaxis_title="ACF")
                            st.plotly_chart(fig, use_container_width=True)
                        else:
                            st.warning("Select numeric column for autocorr.")
                    except Exception as e:
                        st.warning("Autocorr requires statsmodels installed: pip install statsmodels")

                # ---------------- Minimal stubs for advanced plots ----------------
                else:
                    st.info("Plot '" + str(p) + "' not implemented in this build. You can extend the app to add it.")

            except Exception as e:
                st.error("Plot error for " + str(p) + ": " + str(e))

# ---------- Correlation Tab ----------
with tabs[2]:
    st.header("Correlation & Nulls")
    st.write("Correlation matrix (sample, numeric columns)")
    numdf = df_sample.select_dtypes(include='number')
    if numdf.shape[1] >= 2:
        st.dataframe(numdf.corr())
        fig = px.imshow(numdf.corr(), text_auto=True, aspect='auto', color_continuous_scale='RdBu_r', title="Correlation Heatmap (sample)")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.warning("Not enough numeric columns for correlation.")

    st.write("Nulls summary (sample)")
    null_tab = (df_sample.isnull().sum() / max(1, len(df_sample)) * 100).sort_values(ascending=False).head(50)
    st.dataframe(null_tab.to_frame("percent_null"))

# ---------- Summary Tab ----------
with tabs[3]:
    st.header("Intelligent Summary")
    st.markdown("Auto-generated dataset summary & insights")
    st.info(SUMMARY_TEXT)
    st.download_button("Download summary as TXT", data=SUMMARY_TEXT, file_name="hypereda_summary.txt")
"""
        # fill template placeholders safely
        app_code = app_template.format(FULL=full_path, SAMPLE=sample_path, SUMMARY=summary_esc, PLOTS=plots_json, MAX_HEAD=self.max_head_display, PORT=self.port)

        # write script
        ok = _safe_write(self.streamlit_script, app_code)
        if not ok:
            print(colored("⚠️ Failed to write Streamlit app script.", "red"))
        else:
            print(colored(f"[98%] Streamlit app written to {self.streamlit_script}", "green"))

    # ---------------- launch Streamlit (local only) ----------------
    def _launch_streamlit(self):
        try:
            cmd = [sys.executable, "-m", "streamlit", "run", str(self.streamlit_script), "--server.port", str(self.port)]
            logf = open(self.log_file, "ab")
            proc = subprocess.Popen(cmd, stdout=logf, stderr=logf)
            print(colored("[100%] ✅ Report Ready! Launching Streamlit Dashboard...", "green"))
            print(colored(f"Open in browser: http://localhost:{self.port}", "cyan", attrs=["bold"]))
            print(colored(f"Logs: {self.log_file}", "cyan"))
        except Exception as e:
            print(colored(f"⚠️ Failed to launch Streamlit: {e}", "red"))
            print(colored(f"Try manual: streamlit run {self.streamlit_script} --server.port {self.port}", "yellow"))

# ---------------- Example usage ----------------
if __name__ == "__main__":
    # demo dataset
    df_demo = pd.DataFrame({
        "age": np.random.randint(18, 80, 5000),
        "salary": (np.random.randn(5000) * 15000 + 60000).round(0),
        "city": np.random.choice(["A", "B", "C", "D"], size=5000),
        "score": np.random.rand(5000) * 100,
        "joined": pd.date_range("2020-01-01", periods=5000, freq="H")
    })
    EDA(df_demo, max_rows_sample=2000, port=7070)