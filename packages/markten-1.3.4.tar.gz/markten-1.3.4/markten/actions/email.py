"""
# Markten / Actions / Email

Actions for composing emails
"""
from .__email import compose

__all__ = [
    "compose",
]
