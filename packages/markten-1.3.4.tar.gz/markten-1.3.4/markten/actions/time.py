"""
# Markten / Actions / time.py

Actions for managing timing
"""
from .__time import sleep

__all__ = [
    "sleep",
]
