"""
# Markten / Actions / web browser

Actions associated with web browsers
"""
from .__webbrowser import open

__all__ = [
    "open",
]
