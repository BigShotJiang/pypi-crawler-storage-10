"""MCP tool components."""
