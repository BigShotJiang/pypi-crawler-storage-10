"""MCP prompt components."""
