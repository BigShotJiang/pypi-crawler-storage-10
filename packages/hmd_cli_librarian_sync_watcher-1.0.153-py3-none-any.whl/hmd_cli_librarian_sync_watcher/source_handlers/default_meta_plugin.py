def get_metadata(path: str) -> dict:
    return {}
