"""
Storage package for Tyler Stores
"""

from .file_store import FileStore

__all__ = ["FileStore"] 