# bpkit

[![Release](https://img.shields.io/github/v/release/evgnomon/bpkit)](https://img.shields.io/github/v/release/evgnomon/bpkit)
[![Build status](https://img.shields.io/github/actions/workflow/status/evgnomon/bpkit/main.yml?branch=main)](https://github.com/evgnomon/bpkit/actions/workflows/main.yml?query=branch%3Amain)
[![Commit activity](https://img.shields.io/github/commit-activity/m/evgnomon/bpkit)](https://img.shields.io/github/commit-activity/m/evgnomon/bpkit)
[![License](https://img.shields.io/github/license/evgnomon/bpkit)](https://img.shields.io/github/license/evgnomon/bpkit)

Blueprint development kit for Python
