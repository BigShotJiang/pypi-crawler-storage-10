
from .solver import DeepSeekPowSolver
# Tele:@Q_b_h
# dev:Levi
__version__ = "0.1.3"
__all__ = ["DeepSeekPowSolver"]
