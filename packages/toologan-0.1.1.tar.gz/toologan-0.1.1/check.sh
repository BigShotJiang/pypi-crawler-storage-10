#doctests

uv run python tools/general.py 

uv run ruff format --check
uv run ty check
