# Toologan

## A General Toolbag for Logan:


This is a collection of functions, tools, and things I find helpful to have in python. I have worked in the language and there are things I do and don't like about the language. 

Main things that I dislike (and thus, these tools might try to fix):
 
 - Exceptions: They are sort of a nightmare to keep track of and since Python lacks an enforced type or reporting of exception throwing, any function call from a library could potentially bring your program to crash with little to no wanring. 
 - A Lack of Type Enforcement: pretty self explanatory.
 - PODS: Dataclasses are a good step by they lack a lot of potential functionality (like dict-style access by default).


The tools here address issues outside of those gripes, but much of this toolbag has been made to address these issues. 


## Contribution:

Though I appreciate the interest, this is a tool bag for me and the chance of getting code in here that I don't write myself it minimal. 

But please reach out!

### Contact: 

bsky: @doing-fine-thanks