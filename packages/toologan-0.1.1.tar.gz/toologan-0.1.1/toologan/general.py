import typing as T


def attempt(func: T.Callable, default_return: T.Any, *args, **kwargs) -> T.Any:
    """Runs a function in a broad try-catch to suppress
        errors and return a default value on failure.

        If you want tailors behavior for the return, see `attempt_with_values`

    >>> # uncaught exception
    >>> a_func = lambda arg: arg / 0
    >>> a_func(1)
    Traceback (most recent call last):
           ...
    ZeroDivisionError: division by zero

    >>> # covered exception
    >>> default_returns = {ZeroDivisionError: 1}
    >>> attempt(a_func, 1, 10)
    1
    """
    try:
        return func(*args, **kwargs)
    except Exception:
        return default_return


def attempt_with_values(
    func: T.Callable, default_returns: T.Dict[type[Exception], T.Any], *args, **kwargs
) -> T.Any:
    """Runs a function and will return a default value specified by
            in a map of ExceptionType -> DefaultValue.

    for a simple version of this helper, see `attempt`

    >>> # uncaught exception
    >>> a_func = lambda arg: arg / 0
    >>> a_func(1)
    Traceback (most recent call last):
           ...
    ZeroDivisionError: division by zero

    >>> # covered exception
    >>> default_returns = {ZeroDivisionError: 1}
    >>> attempt_with_values(a_func, default_returns, 10)
    1

    >>> # unconfigured exception
    >>> attempt_with_values(a_func, default_returns, "bad") == None
    True
    """
    try:
        return func(*args, **kwargs)
    except Exception as e:
        if type(e) in default_returns:
            return default_returns[type(e)]
        else:
            return None


if __name__ == "__main__":
    import doctest

    doctest.testmod()
