"""LoadedAngularContactBallBearingResults"""

from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar

from mastapy._private._internal import utility
from mastapy._private._internal.dataclasses import extended_dataclass
from mastapy._private._internal.exceptions import CastException
from mastapy._private._internal.python_net import python_net_import
from mastapy._private.bearings.bearing_results.rolling import _2222

_LOADED_ANGULAR_CONTACT_BALL_BEARING_RESULTS = python_net_import(
    "SMT.MastaAPI.Bearings.BearingResults.Rolling",
    "LoadedAngularContactBallBearingResults",
)

if TYPE_CHECKING:
    from typing import Any, Type, TypeVar

    from mastapy._private.bearings import _2090
    from mastapy._private.bearings.bearing_results import _2167, _2172, _2175
    from mastapy._private.bearings.bearing_results.rolling import _2206, _2253

    Self = TypeVar("Self", bound="LoadedAngularContactBallBearingResults")
    CastSelf = TypeVar(
        "CastSelf",
        bound="LoadedAngularContactBallBearingResults._Cast_LoadedAngularContactBallBearingResults",
    )


__docformat__ = "restructuredtext en"
__all__ = ("LoadedAngularContactBallBearingResults",)


@extended_dataclass(frozen=True, slots=True, weakref_slot=True)
class _Cast_LoadedAngularContactBallBearingResults:
    """Special nested class for casting LoadedAngularContactBallBearingResults to subclasses."""

    __parent__: "LoadedAngularContactBallBearingResults"

    @property
    def loaded_ball_bearing_results(
        self: "CastSelf",
    ) -> "_2222.LoadedBallBearingResults":
        return self.__parent__._cast(_2222.LoadedBallBearingResults)

    @property
    def loaded_rolling_bearing_results(
        self: "CastSelf",
    ) -> "_2253.LoadedRollingBearingResults":
        from mastapy._private.bearings.bearing_results.rolling import _2253

        return self.__parent__._cast(_2253.LoadedRollingBearingResults)

    @property
    def loaded_detailed_bearing_results(
        self: "CastSelf",
    ) -> "_2172.LoadedDetailedBearingResults":
        from mastapy._private.bearings.bearing_results import _2172

        return self.__parent__._cast(_2172.LoadedDetailedBearingResults)

    @property
    def loaded_non_linear_bearing_results(
        self: "CastSelf",
    ) -> "_2175.LoadedNonLinearBearingResults":
        from mastapy._private.bearings.bearing_results import _2175

        return self.__parent__._cast(_2175.LoadedNonLinearBearingResults)

    @property
    def loaded_bearing_results(self: "CastSelf") -> "_2167.LoadedBearingResults":
        from mastapy._private.bearings.bearing_results import _2167

        return self.__parent__._cast(_2167.LoadedBearingResults)

    @property
    def bearing_load_case_results_lightweight(
        self: "CastSelf",
    ) -> "_2090.BearingLoadCaseResultsLightweight":
        from mastapy._private.bearings import _2090

        return self.__parent__._cast(_2090.BearingLoadCaseResultsLightweight)

    @property
    def loaded_angular_contact_thrust_ball_bearing_results(
        self: "CastSelf",
    ) -> "_2206.LoadedAngularContactThrustBallBearingResults":
        from mastapy._private.bearings.bearing_results.rolling import _2206

        return self.__parent__._cast(_2206.LoadedAngularContactThrustBallBearingResults)

    @property
    def loaded_angular_contact_ball_bearing_results(
        self: "CastSelf",
    ) -> "LoadedAngularContactBallBearingResults":
        return self.__parent__

    def __getattr__(self: "CastSelf", name: str) -> "Any":
        try:
            return self.__getattribute__(name)
        except AttributeError:
            class_name = utility.camel(name)
            raise CastException(
                f'Detected an invalid cast. Cannot cast to type "{class_name}"'
            ) from None


@extended_dataclass(frozen=True, slots=True, weakref_slot=True, eq=False)
class LoadedAngularContactBallBearingResults(_2222.LoadedBallBearingResults):
    """LoadedAngularContactBallBearingResults

    This is a mastapy class.
    """

    TYPE: ClassVar["Type"] = _LOADED_ANGULAR_CONTACT_BALL_BEARING_RESULTS

    wrapped: "Any"

    def __post_init__(self: "Self") -> None:
        """Override of the post initialisation magic method."""
        if not hasattr(self.wrapped, "reference_count"):
            self.wrapped.reference_count = 0

        self.wrapped.reference_count += 1

    @property
    def cast_to(self: "Self") -> "_Cast_LoadedAngularContactBallBearingResults":
        """Cast to another type.

        Returns:
            _Cast_LoadedAngularContactBallBearingResults
        """
        return _Cast_LoadedAngularContactBallBearingResults(self)
