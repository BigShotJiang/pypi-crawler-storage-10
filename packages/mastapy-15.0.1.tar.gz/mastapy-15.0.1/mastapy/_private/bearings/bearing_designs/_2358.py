"""NonLinearBearing"""

from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar

from mastapy._private._internal import utility
from mastapy._private._internal.dataclasses import extended_dataclass
from mastapy._private._internal.exceptions import CastException
from mastapy._private._internal.python_net import python_net_import
from mastapy._private.bearings.bearing_designs import _2354

_NON_LINEAR_BEARING = python_net_import(
    "SMT.MastaAPI.Bearings.BearingDesigns", "NonLinearBearing"
)

if TYPE_CHECKING:
    from typing import Any, Type, TypeVar

    from mastapy._private.bearings.bearing_designs import _2355
    from mastapy._private.bearings.bearing_designs.concept import _2422, _2423, _2424
    from mastapy._private.bearings.bearing_designs.fluid_film import (
        _2412,
        _2414,
        _2416,
        _2418,
        _2419,
        _2420,
    )
    from mastapy._private.bearings.bearing_designs.rolling import (
        _2359,
        _2360,
        _2361,
        _2362,
        _2363,
        _2364,
        _2366,
        _2372,
        _2373,
        _2374,
        _2378,
        _2383,
        _2384,
        _2385,
        _2386,
        _2389,
        _2391,
        _2394,
        _2395,
        _2396,
        _2397,
        _2398,
        _2399,
    )

    Self = TypeVar("Self", bound="NonLinearBearing")
    CastSelf = TypeVar("CastSelf", bound="NonLinearBearing._Cast_NonLinearBearing")


__docformat__ = "restructuredtext en"
__all__ = ("NonLinearBearing",)


@extended_dataclass(frozen=True, slots=True, weakref_slot=True)
class _Cast_NonLinearBearing:
    """Special nested class for casting NonLinearBearing to subclasses."""

    __parent__: "NonLinearBearing"

    @property
    def bearing_design(self: "CastSelf") -> "_2354.BearingDesign":
        return self.__parent__._cast(_2354.BearingDesign)

    @property
    def detailed_bearing(self: "CastSelf") -> "_2355.DetailedBearing":
        from mastapy._private.bearings.bearing_designs import _2355

        return self.__parent__._cast(_2355.DetailedBearing)

    @property
    def angular_contact_ball_bearing(
        self: "CastSelf",
    ) -> "_2359.AngularContactBallBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2359

        return self.__parent__._cast(_2359.AngularContactBallBearing)

    @property
    def angular_contact_thrust_ball_bearing(
        self: "CastSelf",
    ) -> "_2360.AngularContactThrustBallBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2360

        return self.__parent__._cast(_2360.AngularContactThrustBallBearing)

    @property
    def asymmetric_spherical_roller_bearing(
        self: "CastSelf",
    ) -> "_2361.AsymmetricSphericalRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2361

        return self.__parent__._cast(_2361.AsymmetricSphericalRollerBearing)

    @property
    def axial_thrust_cylindrical_roller_bearing(
        self: "CastSelf",
    ) -> "_2362.AxialThrustCylindricalRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2362

        return self.__parent__._cast(_2362.AxialThrustCylindricalRollerBearing)

    @property
    def axial_thrust_needle_roller_bearing(
        self: "CastSelf",
    ) -> "_2363.AxialThrustNeedleRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2363

        return self.__parent__._cast(_2363.AxialThrustNeedleRollerBearing)

    @property
    def ball_bearing(self: "CastSelf") -> "_2364.BallBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2364

        return self.__parent__._cast(_2364.BallBearing)

    @property
    def barrel_roller_bearing(self: "CastSelf") -> "_2366.BarrelRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2366

        return self.__parent__._cast(_2366.BarrelRollerBearing)

    @property
    def crossed_roller_bearing(self: "CastSelf") -> "_2372.CrossedRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2372

        return self.__parent__._cast(_2372.CrossedRollerBearing)

    @property
    def cylindrical_roller_bearing(
        self: "CastSelf",
    ) -> "_2373.CylindricalRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2373

        return self.__parent__._cast(_2373.CylindricalRollerBearing)

    @property
    def deep_groove_ball_bearing(self: "CastSelf") -> "_2374.DeepGrooveBallBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2374

        return self.__parent__._cast(_2374.DeepGrooveBallBearing)

    @property
    def four_point_contact_ball_bearing(
        self: "CastSelf",
    ) -> "_2378.FourPointContactBallBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2378

        return self.__parent__._cast(_2378.FourPointContactBallBearing)

    @property
    def multi_point_contact_ball_bearing(
        self: "CastSelf",
    ) -> "_2383.MultiPointContactBallBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2383

        return self.__parent__._cast(_2383.MultiPointContactBallBearing)

    @property
    def needle_roller_bearing(self: "CastSelf") -> "_2384.NeedleRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2384

        return self.__parent__._cast(_2384.NeedleRollerBearing)

    @property
    def non_barrel_roller_bearing(self: "CastSelf") -> "_2385.NonBarrelRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2385

        return self.__parent__._cast(_2385.NonBarrelRollerBearing)

    @property
    def roller_bearing(self: "CastSelf") -> "_2386.RollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2386

        return self.__parent__._cast(_2386.RollerBearing)

    @property
    def rolling_bearing(self: "CastSelf") -> "_2389.RollingBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2389

        return self.__parent__._cast(_2389.RollingBearing)

    @property
    def self_aligning_ball_bearing(self: "CastSelf") -> "_2391.SelfAligningBallBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2391

        return self.__parent__._cast(_2391.SelfAligningBallBearing)

    @property
    def spherical_roller_bearing(self: "CastSelf") -> "_2394.SphericalRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2394

        return self.__parent__._cast(_2394.SphericalRollerBearing)

    @property
    def spherical_roller_thrust_bearing(
        self: "CastSelf",
    ) -> "_2395.SphericalRollerThrustBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2395

        return self.__parent__._cast(_2395.SphericalRollerThrustBearing)

    @property
    def taper_roller_bearing(self: "CastSelf") -> "_2396.TaperRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2396

        return self.__parent__._cast(_2396.TaperRollerBearing)

    @property
    def three_point_contact_ball_bearing(
        self: "CastSelf",
    ) -> "_2397.ThreePointContactBallBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2397

        return self.__parent__._cast(_2397.ThreePointContactBallBearing)

    @property
    def thrust_ball_bearing(self: "CastSelf") -> "_2398.ThrustBallBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2398

        return self.__parent__._cast(_2398.ThrustBallBearing)

    @property
    def toroidal_roller_bearing(self: "CastSelf") -> "_2399.ToroidalRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2399

        return self.__parent__._cast(_2399.ToroidalRollerBearing)

    @property
    def pad_fluid_film_bearing(self: "CastSelf") -> "_2412.PadFluidFilmBearing":
        from mastapy._private.bearings.bearing_designs.fluid_film import _2412

        return self.__parent__._cast(_2412.PadFluidFilmBearing)

    @property
    def plain_grease_filled_journal_bearing(
        self: "CastSelf",
    ) -> "_2414.PlainGreaseFilledJournalBearing":
        from mastapy._private.bearings.bearing_designs.fluid_film import _2414

        return self.__parent__._cast(_2414.PlainGreaseFilledJournalBearing)

    @property
    def plain_journal_bearing(self: "CastSelf") -> "_2416.PlainJournalBearing":
        from mastapy._private.bearings.bearing_designs.fluid_film import _2416

        return self.__parent__._cast(_2416.PlainJournalBearing)

    @property
    def plain_oil_fed_journal_bearing(
        self: "CastSelf",
    ) -> "_2418.PlainOilFedJournalBearing":
        from mastapy._private.bearings.bearing_designs.fluid_film import _2418

        return self.__parent__._cast(_2418.PlainOilFedJournalBearing)

    @property
    def tilting_pad_journal_bearing(
        self: "CastSelf",
    ) -> "_2419.TiltingPadJournalBearing":
        from mastapy._private.bearings.bearing_designs.fluid_film import _2419

        return self.__parent__._cast(_2419.TiltingPadJournalBearing)

    @property
    def tilting_pad_thrust_bearing(self: "CastSelf") -> "_2420.TiltingPadThrustBearing":
        from mastapy._private.bearings.bearing_designs.fluid_film import _2420

        return self.__parent__._cast(_2420.TiltingPadThrustBearing)

    @property
    def concept_axial_clearance_bearing(
        self: "CastSelf",
    ) -> "_2422.ConceptAxialClearanceBearing":
        from mastapy._private.bearings.bearing_designs.concept import _2422

        return self.__parent__._cast(_2422.ConceptAxialClearanceBearing)

    @property
    def concept_clearance_bearing(self: "CastSelf") -> "_2423.ConceptClearanceBearing":
        from mastapy._private.bearings.bearing_designs.concept import _2423

        return self.__parent__._cast(_2423.ConceptClearanceBearing)

    @property
    def concept_radial_clearance_bearing(
        self: "CastSelf",
    ) -> "_2424.ConceptRadialClearanceBearing":
        from mastapy._private.bearings.bearing_designs.concept import _2424

        return self.__parent__._cast(_2424.ConceptRadialClearanceBearing)

    @property
    def non_linear_bearing(self: "CastSelf") -> "NonLinearBearing":
        return self.__parent__

    def __getattr__(self: "CastSelf", name: str) -> "Any":
        try:
            return self.__getattribute__(name)
        except AttributeError:
            class_name = utility.camel(name)
            raise CastException(
                f'Detected an invalid cast. Cannot cast to type "{class_name}"'
            ) from None


@extended_dataclass(frozen=True, slots=True, weakref_slot=True, eq=False)
class NonLinearBearing(_2354.BearingDesign):
    """NonLinearBearing

    This is a mastapy class.
    """

    TYPE: ClassVar["Type"] = _NON_LINEAR_BEARING

    wrapped: "Any"

    def __post_init__(self: "Self") -> None:
        """Override of the post initialisation magic method."""
        if not hasattr(self.wrapped, "reference_count"):
            self.wrapped.reference_count = 0

        self.wrapped.reference_count += 1

    @property
    def cast_to(self: "Self") -> "_Cast_NonLinearBearing":
        """Cast to another type.

        Returns:
            _Cast_NonLinearBearing
        """
        return _Cast_NonLinearBearing(self)
