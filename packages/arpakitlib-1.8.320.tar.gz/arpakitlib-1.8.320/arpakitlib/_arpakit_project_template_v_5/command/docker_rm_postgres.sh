cd ..
source .env
sudo docker rm -f ${common_project_name}_postgres
