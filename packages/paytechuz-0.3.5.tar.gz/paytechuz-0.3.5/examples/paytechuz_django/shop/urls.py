from django.urls import path
from . import views

app_name = 'shop'

urlpatterns = [
    path('api/orders/create', views.CreateOrderAPIView.as_view(), name='create_order'),
]
