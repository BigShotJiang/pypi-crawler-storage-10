def main() -> None:
    print("Hello from protostack!")
