class SeaBreezeError(Exception):
    pass
