# This file marks the icon directory as a Python package.
