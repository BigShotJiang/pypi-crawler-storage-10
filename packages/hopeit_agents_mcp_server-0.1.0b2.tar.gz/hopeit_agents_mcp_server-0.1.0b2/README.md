# hopeit_agents MCP Server

Model Context Protocol server that exposes hopeit.engine events as MCP tools for agent integrations.

Check details at [hopeit.agents README](https://github.com/hopeit-git/hopeit.agents/blob/master/README.md).
