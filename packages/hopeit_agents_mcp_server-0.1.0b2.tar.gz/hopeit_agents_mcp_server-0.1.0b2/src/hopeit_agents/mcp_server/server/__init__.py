"""
hopeit-agents-mcp-server server module
"""
