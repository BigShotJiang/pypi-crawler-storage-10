"""
hopeit-agents-mcp-server CLI (Command Line Interface) module
"""
