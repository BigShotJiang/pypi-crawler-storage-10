"""Helpers for translating hopeit tool plugins into MCP metadata."""
