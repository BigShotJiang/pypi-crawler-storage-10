Spike functions
---------------