"""
Lambda@Edge Stack Library Module
"""
from cdk_factory.stack_library.lambda_edge.lambda_edge_stack import LambdaEdgeStack

__all__ = ["LambdaEdgeStack"]
