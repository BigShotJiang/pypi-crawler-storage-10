"""
Monitoring Stack Library Module
"""
from cdk_factory.stack_library.monitoring.monitoring_stack import MonitoringStack

__all__ = ["MonitoringStack"]
