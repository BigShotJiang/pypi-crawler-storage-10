# dc43-integrations

The integration packages connect the dc43 service contracts to runtime platforms. Today the
Spark adapter ships here, and additional adapters can live alongside it while depending only
on the shared client contracts.
