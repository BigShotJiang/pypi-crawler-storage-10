# b402

Gasless crypto payments on BSC. Users pay zero gas fees.

## Install

```bash
pip install b402
```

## Quick Start

```python
from b402 import B402

b402 = B402()

# One-time setup (approve relayer)
b402.setup("USD1")

# Send payment (gasless!)
result = b402.pay(
    amount="0.01",
    token="USD1",
    recipient="0x..."
)

if result.success:
    print(f"TX: https://bscscan.com/tx/{result.tx_hash}")
```

Or use the one-liner (after setup):

```python
from b402 import pay

result = pay(amount="0.01", token="USD1", recipient="0x...")
```

Reads `PRIVATE_KEY` from environment. Defaults to BSC mainnet.

## Complete Example

```python
from b402 import B402

b402 = B402()

# Step 1: Check if setup is needed
approved, allowance = b402.check_approval("USD1")

if not approved:
    print("Setting up (one-time)...")
    result = b402.setup("USD1")
    print(f"Approved! TX: {result['tx_hash']}")

# Step 2: Send payment (gasless!)
payment = b402.pay(
    amount="0.01",
    token="USD1",
    recipient="0x96625c0e209b4e0d4741d8a3ffb6b91c0da6fa5f"
)

if payment.success:
    print(f"Paid {payment.amount} {payment.token}")
    print(f"TX: https://bscscan.com/tx/{payment.tx_hash}")
else:
    print(f"Error: {payment.error}")
```

Run the complete demo: `python examples/complete_demo.py`

## How It Works

1. **Setup** (one-time): Approve B402 relayer to spend tokens (costs gas, ~$0.10)
2. **Payment** (gasless): Sign EIP-712 authorization, relayer submits transaction and pays gas
3. **Settlement**: Payment settles on-chain in <3 seconds

## Supported Tokens

**Mainnet:** USD1, USDT, USDC
**Testnet:** USDT

## API Reference

### `B402()`

Create B402 client. Defaults to mainnet.

```python
b402 = B402()  # mainnet
b402_test = B402(network="testnet")
```

### `b402.setup(token)`

One-time setup: approve relayer to spend tokens.

```python
result = b402.setup("USD1")
# Returns: {"approved": True, "allowance": int, "tx_hash": "0x..."}
```

### `b402.check_approval(token)`

Check if token is approved.

```python
approved, allowance = b402.check_approval("USD1")
```

### `b402.pay(amount, token, recipient)`

Send gasless payment.

```python
result = b402.pay(amount="0.01", token="USD1", recipient="0x...")
# Returns: PaymentResult(success, tx_hash, error, payer, recipient, amount, token)
```

### `pay()` - One-liner

Factory function for simple usage (after setup).

```python
from b402 import pay

result = pay(amount="0.01", token="USD1", recipient="0x...")
```

## Environment Variables

- `PRIVATE_KEY` - Required. Your wallet private key (with 0x prefix)

## Examples

- [examples/complete_demo.py](examples/complete_demo.py) - Full workflow with setup
- [examples/one_liner.py](examples/one_liner.py) - Simplest payment
- [examples/check_approval.py](examples/check_approval.py) - Check approval status

## Network Details

**BSC Mainnet** (Chain ID: 56)
- Relayer: `0xE1C2830d5DDd6B49E9c46EbE03a98Cb44CD8eA5a`
- USD1: `0x8d0d000ee44948fc98c9b98a4fa4921476f08b0d`
- USDT: `0x55d398326f99059fF775485246999027B3197955`
- USDC: `0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d`

**BSC Testnet** (Chain ID: 97)
- Relayer: `0x62150F2c3A29fDA8bCf22c0F22Eb17270FCBb78A`
- USDT: `0x337610d27c682E347C9cD60BD4b3b107C9d34dDd`

## License

MIT
