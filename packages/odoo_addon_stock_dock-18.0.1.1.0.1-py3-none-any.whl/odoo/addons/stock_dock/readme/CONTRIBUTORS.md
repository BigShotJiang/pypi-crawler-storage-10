- Sébastien Alix \<<sebastien.alix@camptocamp.com>\>
- [Trobz](https://trobz.com):
  - Dung Tran \<<dungtd@trobz.com>\>
  - Khoi (Kien Kim) \<<khoikk@trobz.com>\>

## Design

- Joël Grand-Guillaume \<<joel.grandguillaume@camptocamp.com>\>
- Jacques-Etienne Baudoux \<<je@bcim.be>\>
