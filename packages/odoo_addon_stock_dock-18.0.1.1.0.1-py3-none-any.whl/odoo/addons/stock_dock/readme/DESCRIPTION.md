Manage the loading docks of your warehouse.
