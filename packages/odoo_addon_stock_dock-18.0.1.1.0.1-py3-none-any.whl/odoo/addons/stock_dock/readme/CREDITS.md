**Financial support**

- Cosanum
- Camptocamp R&D

The migration of this module from 13.0 to 14.0 and then from 16.0 to 18.0 was financially supported by:

- Camptocamp
