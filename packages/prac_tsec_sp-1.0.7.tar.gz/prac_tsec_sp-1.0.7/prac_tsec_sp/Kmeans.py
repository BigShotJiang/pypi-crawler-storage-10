import random

def euclidean(p1, p2):
    # Calculate Euclidean distance between two points (lists)
    return sum((x - y) ** 2 for x, y in zip(p1, p2)) ** 0.5

def kmeans(data, k, max_iterations=100):
    # Randomly choose k data points as initial centroids
    centroids = random.sample(data, k)
    clusters = []
    for _ in range(max_iterations):
        # Assign points to nearest centroid
        clusters = [[] for _ in range(k)]
        for point in data:
            distances = [euclidean(point, centroid) for centroid in centroids]
            nearest = distances.index(min(distances))
            clusters[nearest].append(point)
        
        # Recompute centroids
        new_centroids = []
        for cluster in clusters:
            if cluster:  # Avoid division by zero
                # Compute mean of points in cluster
                centroid = [sum(dim) / len(cluster) for dim in zip(*cluster)]
                new_centroids.append(centroid)
            else:  # If a cluster is empty, pick a random point as centroid
                new_centroids.append(random.choice(data))
        
        # If centroids didn't change, break early
        if new_centroids == centroids:
            break
        centroids = new_centroids
    
    return clusters, centroids

# Example usage:
data = [
    [2,10],
    [2,5],
    [8,4],
    [5,8],
    [7,5],
    [6,4],
    [1,2],
    [4,9],
]
clusters, centroids = kmeans(data, k=3)
print("Clusters:", clusters)
print("Centroids:", centroids)
