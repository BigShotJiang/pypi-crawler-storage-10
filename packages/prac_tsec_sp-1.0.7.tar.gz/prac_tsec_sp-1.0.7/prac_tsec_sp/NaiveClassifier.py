# Data
data = [
    ["Sunny", "Hot", "High", "Weak", "No"],
    ["Sunny", "Hot", "High", "Strong", "No"],
    ["Overcast", "Hot", "High", "Weak", "Yes"],
    ["Rain", "Mild", "High", "Weak", "Yes"],
    ["Rain", "Cool", "Normal", "Weak", "Yes"],
    ["Rain", "Cool", "Normal", "Strong", "No"],
    ["Overcast", "Cool", "Normal", "Strong", "Yes"],
    ["Sunny", "Mild", "High", "Weak", "No"],
    ["Sunny", "Cool", "Normal", "Weak", "Yes"],
    ["Rain", "Mild", "Normal", "Weak", "Yes"],
    ["Sunny", "Mild", "Normal", "Strong", "Yes"],
    ["Overcast", "Mild", "High", "Strong", "Yes"],
    ["Overcast", "Hot", "Normal", "Weak", "Yes"],
    ["Rain", "Mild", "High", "Strong", "No"],
]

# What we want to predict
test = ["Sunny", "Cool", "High", "Strong"]

# Step 1: Count total Yes and No
total = len(data)
yes_count = 0
no_count = 0

for row in data:
    if row[-1] == "Yes":
        yes_count += 1
    else:
        no_count += 1

# Step 2: Calculate probability for Yes
p_yes = yes_count / total  # Start with base probability

for i in range(4):  # Check each feature
    match = 0
    for row in data:
        if row[-1] == "Yes" and row[i] == test[i]:
            match += 1
    p_yes = p_yes * (match / yes_count)

# Step 3: Calculate probability for No
p_no = no_count / total  # Start with base probability

for i in range(4):  # Check each feature
    match = 0
    for row in data:
        if row[-1] == "No" and row[i] == test[i]:
            match += 1
    p_no = p_no * (match / no_count)

# Step 4: Compare and predict
if p_yes > p_no:
    print("Prediction: Yes")
else:
    print("Prediction: No")

print("P(Yes) =", p_yes)
print("P(No) =", p_no)
