def page_rank(graph, damping=0.85, max_iterations=100, tol=1.0e-6):
    nodes = list(graph.keys())
    n = len(nodes)
    rank = {node: 1 / n for node in nodes}
    out_degree = {node: len(neighbors) for node, neighbors in graph.items()}

    for _ in range(max_iterations):
        new_rank = {}
        for node in nodes:
            rank_sum = 0
            for other_node in nodes:
                if node in graph[other_node]:
                    rank_sum += rank[other_node] / out_degree[other_node]
            new_rank[node] = (1 - damping) / n + damping * rank_sum

        # Check convergence
        diff = sum(abs(new_rank[node] - rank[node]) for node in nodes)
        if diff < tol:
            break
        rank = new_rank

    return rank


# Example usage:
graph = {"A": ["B", "C"], "B": ["A", "D"], "C": ["D"], "D": ["C"]}
print(page_rank(graph))
