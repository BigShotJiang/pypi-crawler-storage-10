# lmao why would you even need a readme for ts!

## just install the package stated as below.

```bash
pip install prac-tsec-sp
```

## once done, run the below command,

```bash
pip show prac-tsec-sp
```

## locate the Location attribute, press CTRL + CLICK on the link, 
## once you reach in the site-packages directory, locate the prac-tsec-sp folder, and enjoy learning.

# Strictly for learning purposes only!!

