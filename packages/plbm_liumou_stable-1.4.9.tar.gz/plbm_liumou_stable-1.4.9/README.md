# 🐧 PythonLinuxBasicModule (PLBM)

<div align="center">

[![Python Version](https://img.shields.io/badge/python-3.0+-blue.svg)](https://www.python.org/downloads/)[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)[![Version](https://img.shields.io/badge/version-1.4.8-orange.svg)](https://pypi.org/project/plbm-liumou-Stable/)

[📖 中文文档](#简介) | [🚀 快速开始](#使用方法) | [💻 代码示例](#demo) | [📦 PyPI](https://pypi.org/project/plbm-liumou-Stable/)

</div>

## 📋 简介

[PythonLinuxBasicModule](https://gitee.com/liumou_site/plbm)（简称 `plbm`）是一个功能强大的Python3 Linux系统管理工具库，专为简化Linux系统管理任务而设计。

在日常工作中，我们经常需要编写大量重复的Linux管理脚本。为了提高开发效率，我将常用的Linux管理功能封装成模块，并以开源方式共享，希望能够帮助更多开发者，同时也欢迎社区贡献。

### 🎯 核心功能

- **📦 软件包管理** - 支持APT、YUM、DPKG等主流包管理器
- **🔧 服务管理** - SystemD服务启停、状态监控、开机自启管理
- **📁 文件管理** - 文件操作、MD5校验、目录管理、压缩解压
- **🌐 网络管理** - 网络状态监控、IP规则配置、网卡管理
- **🔒 安全管理** - 权限验证、防火墙配置、iptables规则管理
- **💻 系统信息** - 操作系统信息、硬件信息、进程管理
- **🐳 Docker支持** - 容器生命周期管理
- **📊 日志系统** - 彩色日志输出、文件日志记录

### ✨ 特色亮点

- 📝 **全中文注释** - 代码注释完整，新手也能轻松理解
- 🔧 **零依赖设计** - 主要使用Python内置模块，即装即用
- 🔄 **语法兼容** - 支持Python 3.0+，兼容新旧版本语法
- 🆓 **完全开源** - MIT协议，永久免费使用
- 🛡️ **类型安全** - 完整的类型提示和参数验证
- 🎨 **友好日志** - 彩色日志输出，开发调试更轻松

## 📊 PyPI 统计数据

<div align="center">

| 📈 统计项 | 🎯 数据 |
|---------|--------|
| 📦 PyPI包名 | `plbm-liumou-Stable` |
| 🏷️ 最新版本 | 1.4.8 |
| 📅 发布时间 | 2024年 |
| 📥 月下载量 | ![PyPI Downloads](https://img.shields.io/pypi/dm/plbm-liumou-Stable) |
| ⭐ 项目评分 | ![PyPI Version](https://img.shields.io/pypi/v/plbm-liumou-Stable) |
| 🗃️ 包格式 | ![PyPI Format](https://img.shields.io/pypi/format/plbm-liumou-Stable) |
| 🚀 项目状态 | ![PyPI Status](https://img.shields.io/pypi/status/plbm-liumou-Stable) |
| 🔗 PyPI链接 | [https://pypi.org/project/plbm-liumou-Stable/](https://pypi.org/project/plbm-liumou-Stable/) |

</div>

# 🚀 使用方法

## 📦 安装方式

### 🎯 方式一：PyPI安装（推荐）

访问PyPI项目地址：[https://pypi.org/project/plbm-liumou-Stable/](https://pypi.org/project/plbm-liumou-Stable/)

```bash
# 使用清华源加速安装
pip3 install --upgrade plbm_liumou_Stable ColorInfo -i https://pypi.tuna.tsinghua.edu.cn/simple

# 或使用官方源
pip3 install --upgrade plbm_liumou_Stable ColorInfo
```

### 🎯 方式二：源码安装

适合需要自定义修改或参与开发的场景：

```bash
# 克隆项目
git clone https://gitee.com/liumou_site/PythonLinuxBasicModule.git

# 进入项目目录
cd PythonLinuxBasicModule

# 执行安装脚本
python3 install.py
```

## ⚙️ 系统要求

- 🐧 **操作系统**: Linux (Ubuntu, CentOS, Debian等)
- 🐍 **Python版本**: 3.0 及以上
- 🔑 **权限要求**: 部分功能需要sudo权限
- 📦 **依赖包**: ColorInfo, psutil, loguru, py7zr

# 💻 代码示例

## 📦 包管理示例

<details>
<summary>🔍 点击查看包管理代码</summary>

### 📋 示例代码

```python
# -*- encoding: utf-8 -*-
"""
@File    :   package_demo.py
@Time    :   2022-10-24 22:45
@Author  :   坐公交也用券
@Version :   1.0
@Contact :   faith01238@hotmail.com
@Homepage : https://liumou.site
@Desc    :   软件包管理示例
"""
from plbm_liumou_Stable import NewPackageManagement
from ColorInfo import ColorLogger


class PackageManager:
    def __init__(self, package_name, password):
        """初始化包管理器"""
        self.package_name = package_name
        self.package_mgr = NewPackageManagement(password=password, package=package_name)
        self.logger = ColorLogger(class_name=self.__class__.__name__)

    def check_and_remove(self):
        """检查并卸载软件包"""
        if self.package_mgr.installed():
            self.logger.info(f"📦 检测到已安装: {self.package_name}")
            
            if self.package_mgr.uninstall():
                self.logger.success(f"✅ 卸载成功: {self.package_name}")
                return True
            else:
                self.logger.error(f"❌ 卸载失败: {self.package_name}")
                return False
        else:
            self.logger.warning(f"⚠️  未安装: {self.package_name}")
            return True

    def install_package(self, update_index=False):
        """安装软件包"""
        if not self.package_mgr.installed():
            self.logger.info(f"📥 开始安装: {self.package_name}")
            
            if self.package_mgr.install(package=self.package_name, update=update_index):
                self.logger.success(f"✅ 安装成功: {self.package_name}")
                return True
            else:
                self.logger.error(f"❌ 安装失败: {self.package_name}")
                return False
        else:
            self.logger.info(f"📦 软件包已存在: {self.package_name}")
            return True


if __name__ == "__main__":
    # 示例：管理vsftpd服务
    manager = PackageManager(package_name="vsftpd", password="your_password")
    
    # 卸载软件包
    manager.check_and_remove()
    
    # 安装软件包（带更新索引）
    # manager.install_package(update_index=True)
```

</details>

### 🖥️ 运行结果

```bash
$ python3 package_demo.py
2023-01-06 22:42:31 [PackageManager] INFO: 📦 检测到已安装: vsftpd
2023-01-06 22:42:31 [PackageManager] INFO: 🔄 开始卸载进程...
2023-01-06 22:42:36 [PackageManager] SUCCESS: ✅ 卸载成功: vsftpd
```

## 🔧 服务管理示例

<details>
<summary>🔍 点击查看服务管理代码</summary>

### 📋 示例代码

```python
# -*- encoding: utf-8 -*-
"""
@File    :   service_demo.py
@Time    :   2022-10-24 22:45
@Author  :   坐公交也用券
@Version :   1.0
@Contact :   faith01238@hotmail.com
@Homepage : https://liumou.site
@Desc    :   服务管理示例
"""
from plbm_liumou_Stable import NewServiceManagement
from ColorInfo import ColorLogger


class ServiceManager:
    def __init__(self, service_name, password):
        """初始化服务管理器"""
        self.service_name = service_name
        self.service_mgr = NewServiceManagement(service=service_name, password=password)
        self.logger = ColorLogger(class_name=self.__class__.__name__)

    def restart_service(self, reload_config=True):
        """重启服务（支持配置重载）"""
        self.logger.info(f"🔄 正在重启服务: {self.service_name}")
        
        if self.service_mgr.restart(reload=reload_config):
            self.logger.success(f"✅ 服务重启成功: {self.service_name}")
            return True
        else:
            self.logger.error(f"❌ 服务重启失败: {self.service_name}")
            return False

    def manage_service(self, action="status"):
        """服务管理（启动/停止/状态检查）"""
        actions = {
            "start": self.service_mgr.start,
            "stop": self.service_mgr.stop,
            "restart": self.service_mgr.restart,
            "enable": self.service_mgr.enable,
            "disable": self.service_mgr.disable
        }
        
        if action in actions:
            self.logger.info(f"🔄 执行操作: {action} {self.service_name}")
            result = actions[action]()
            
            if result:
                self.logger.success(f"✅ 操作成功: {action} {self.service_name}")
            else:
                self.logger.error(f"❌ 操作失败: {action} {self.service_name}")
            
            return result
        else:
            self.logger.warning(f"⚠️  不支持的操作: {action}")
            return False


if __name__ == "__main__":
    # 示例：管理vsftpd服务
    manager = ServiceManager(service_name="vsftpd", password="your_password")
    
    # 重启服务（带配置重载）
    manager.restart_service(reload_config=True)
    
    # 其他操作
    # manager.manage_service("start")   # 启动服务
    # manager.manage_service("stop")    # 停止服务
    # manager.manage_service("enable")  # 设置开机自启
```

</details>

### 🖥️ 运行结果

```bash
$ python3 service_demo.py
2023-01-06 22:36:41 [ServiceManager] INFO: 🔄 正在重启服务: vsftpd
2023-01-06 22:36:41 [ServiceManager] SUCCESS: ✅ 服务重启成功: vsftpd
```

## 📁 文件管理示例

<details>
<summary>🔍 点击查看文件管理代码</summary>

### 📋 示例代码

```python
# -*- encoding: utf-8 -*-
"""
@File    :   file_demo.py
@Desc    :   文件管理示例
"""
from plbm_liumou_Stable import NewFile
from ColorInfo import ColorLogger


class FileManager:
    def __init__(self):
        """初始化文件管理器"""
        self.logger = ColorLogger(class_name=self.__class__.__name__)
        self.file_mgr = NewFile()

    def manage_directory(self, path):
        """目录管理示例"""
        self.logger.info(f"📁 管理目录: {path}")
        
        # 创建目录
        if self.file_mgr.mkdir_p(target=path, mode=0o755):
            self.logger.success(f"✅ 目录创建成功: {path}")
        else:
            self.logger.error(f"❌ 目录创建失败: {path}")
            return False
        
        # 获取文件MD5（示例）
        test_file = "/etc/hosts"
        if self.file_mgr.get_md5(filename=test_file):
            md5_value = self.file_mgr.md5
            self.logger.info(f"🔍 文件 {test_file} 的MD5值: {md5_value}")
        
        return True

    def copy_files(self, src, dst):
        """文件复制示例"""
        self.logger.info(f"📋 复制文件: {src} -> {dst}")
        
        if self.file_mgr.copyfile(src=src, dst=dst, cover=True):
            self.logger.success(f"✅ 文件复制成功")
            return True
        else:
            self.logger.error(f"❌ 文件复制失败")
            return False


if __name__ == "__main__":
    manager = FileManager()
    
    # 目录管理
    manager.manage_directory("/tmp/test_dir")
    
    # 文件复制
    # manager.copy_files("/etc/hosts", "/tmp/hosts_backup")
```

</details>

## 🌐 网络管理示例

<details>
<summary>🔍 点击查看网络管理代码</summary>

### 📋 示例代码

```python
# -*- encoding: utf-8 -*-
"""
@File    :   network_demo.py
@Desc    :   网络管理示例
"""
from plbm_liumou_Stable import NewNetStatus, NewNetworkCardInfo
from ColorInfo import ColorLogger


class NetworkManager:
    def __init__(self):
        """初始化网络管理器"""
        self.logger = ColorLogger(class_name=self.__class__.__name__)
        self.net_status = NewNetStatus()
        self.net_card = NewNetworkCardInfo()

    def check_network_status(self):
        """检查网络状态"""
        self.logger.info("🌐 检查网络状态...")
        
        # 检查网络连接
        if self.net_status.ping(host="8.8.8.8"):
            self.logger.success("✅ 网络连接正常")
        else:
            self.logger.warning("⚠️  网络连接异常")
        
        # 获取网卡信息
        cards = self.net_card.get_cards()
        self.logger.info(f"📊 检测到 {len(cards)} 个网卡")
        
        for card in cards:
            info = self.net_card.get_card_info(card)
            if info:
                self.logger.info(f"🔌 网卡 {card}: {info}")

    def monitor_port(self, port):
        """监控端口状态"""
        from plbm_liumou_Stable import NewListen
        
        listener = NewListen()
        if listener.port_is_listen(port=port):
            self.logger.info(f"🔍 端口 {port} 正在监听")
        else:
            self.logger.info(f"🔍 端口 {port} 未监听")


if __name__ == "__main__":
    manager = NetworkManager()
    manager.check_network_status()
    # manager.monitor_port(80)  # 监控80端口
```

</details>

# 📚 API 参考

## 🔧 核心模块

| 模块 | 类名 | 功能描述 |
|------|------|----------|
| Package | `NewPackageManagement` | 软件包管理（APT/YUM/DPKG） |
| Service | `NewServiceManagement` | SystemD服务管理 |
| File | `NewFile` | 文件和目录管理 |
| NetStatus | `NewNetStatus` | 网络状态监控 |
| NetworkCardInfo | `NewNetworkCardInfo` | 网卡信息管理 |
| Process | `NewProcess` | 进程管理 |
| Docker | `Docker` | Docker容器管理 |
| Iptables | `IpTables` | 防火墙规则管理 |
| Jurisdiction | `Jurisdiction` | 权限验证管理 |

## 📖 快速参考

```python
# 软件包管理
from plbm_liumou_Stable import NewPackageManagement
pkg = NewPackageManagement(password="your_password", package="nginx")
pkg.install()           # 安装
pkg.uninstall()         # 卸载
pkg.installed()         # 检查是否已安装

# 服务管理
from plbm_liumou_Stable import NewServiceManagement
svc = NewServiceManagement(service="nginx", password="your_password")
svc.start()             # 启动
svc.stop()              # 停止
svc.restart()           # 重启
svc.enable()            # 开机自启

# 文件管理
from plbm_liumou_Stable import NewFile
file_mgr = NewFile()
file_mgr.mkdir_p("/tmp/test")      # 创建目录
file_mgr.get_md5("/etc/hosts")    # 获取MD5
file_mgr.copyfile(src, dst)        # 复制文件
```

# 🤝 贡献指南

我们欢迎所有形式的贡献！

- 🐛 **报告Bug** - 请在 [Issues](https://gitee.com/liumou_site/plbm/issues) 中报告
- 💡 **功能建议** - 欢迎提出新功能建议
- 🔧 **代码贡献** - 欢迎提交Pull Request
- 📖 **文档完善** - 帮助改进文档和示例

## 🛠️ 开发环境搭建

```bash
# 克隆项目
git clone https://gitee.com/liumou_site/plbm.git
cd plbm

# 创建虚拟环境
python3 -m venv venv
source venv/bin/activate  # Linux

# 安装依赖
pip install -r requirements.txt

# 运行测试
python3 -m pytest tests/
```

# 📄 许可证

本项目采用 [MIT许可证](LICENSE) 开源协议，您可以自由使用、修改和分发。

# 📞 联系方式

- 📧 **邮箱**: <liumou.site@qq.com>
- 🏠 **主页**: [https://liumou.site](https://liumou.site)
- 🐙 **Gitee**: [https://gitee.com/liumou_site/plbm](https://gitee.com/liumou_site/plbm)
- 📦 **PyPI**: [https://pypi.org/project/plbm-liumou-Stable/](https://pypi.org/project/plbm-liumou-Stable/)

---

<div align="center">

⭐ **如果这个项目对您有帮助，请给我们一个星标！** ⭐

Made with ❤️ by [坐公交也用券](https://gitee.com/liumou_site)

</div>
