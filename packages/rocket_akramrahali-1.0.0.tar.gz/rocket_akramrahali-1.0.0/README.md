# rocket

`rocket` is a Python library for PLAYING AROUND WITH COOL ROCKETS

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install `rocket`.

```bash
pip install rocket
```

## Usage

```python
import rocket

# create rocket instance in the coordinations ( 10 , 20)
rocket.Rocket(10 , 20)

# create shuffle rocket with coordinations ( 20 , 30) and completed flights 5
rocket.Shuttle(20,30,5)

# create a circle rocket in coordinations ( 5 , 15) and radius 5 . then calculate its area and circumference 
CR = rocket.CircleRocket(5 , 15 , 5)
CR.calculate_area()
CR.calculate_circumference()

```

## License
[MIT](https://choosealicense.com/licenses/mit/)