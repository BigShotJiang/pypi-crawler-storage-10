from setuptools import setup

setup(
   name='rocket_akramrahali',
   version='1.0.0',
   author='The Amazing Spider-Man',
   author_email='SpiderMan@marvel.com',
   packages=['rocket'],
   url='http://pypi.python.org/pypi/rocket/',
   license='LICENSE.txt',
   description='An awesome package that does Spider-man stuff',
   long_description=open('README.md').read(),
   long_description_content_type="text/markdown",
   install_requires=['rocket']
)