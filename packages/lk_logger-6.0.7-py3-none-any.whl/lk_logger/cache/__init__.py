from .legacy import LoggingCache
