from . import console
from . import printer
from .control import counting
from .control import delay
from .control import disable
from .control import elevate_caller_stack
from .control import enable
from .control import input
from .control import mute
from .control import reload
from .control import setup
from .control import timing
from .control import unload
from .control import unload as restore_builtin_print
from .control import update
from .deflector import deflector
from .frame_info import FrameInfo
from .logger import logger
from .printer import bprint
from .printer import parallel_printing
from .progress import spinner
from .progress import track
from .screenshot import save_error

fmt = logger.fmt


def _init() -> None:
    import traceback
    deflector.add(traceback, bprint)
    
    setup(quiet=True)
    
    try:
        __IPYTHON__  # noqa
        # from .printer import dprint
        # dprint('running in ipython environment')
    except NameError:
        pass
    else:
        import IPython  # noqa
        deflector.add(IPython, bprint, scope=True)
        # pipeline.add('[ipython]', bprint)


_init()
__version__ = '6.0.7'
