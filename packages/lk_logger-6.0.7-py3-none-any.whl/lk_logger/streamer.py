import airmise as air
import typing as t
from contextlib import contextmanager
from threading import Thread
from time import sleep


class Streamer:
    _locked: bool
    _messages: t.Dict[str, t.List[str]]
    _simple_id_generator: int
    
    def __init__(self):
        self._locked = False
        self._messages = {}
        self._simple_id_generator = 0
    
    def push_message(self, msg):
        if not self._messages:
            return
        while self._locked:
            sleep(0.1)  # this blocks main thread
        for ls in self._messages.values():
            ls.append(msg)
    
    def start(self, port: int = 2033, blocking: bool = True):
        if blocking:
            air.run_server(
                {
                    'init' : self._create_listener,
                    'check': self._check_message_ready,
                    'fetch': self._fetch_messages,
                },
                port=port
            )
        else:
            Thread(
                target=air.run_server,
                args=(
                    {
                        'init' : self._create_listener,
                        'check': self._check_message_ready,
                        'fetch': self._fetch_messages,
                    },
                ),
                kwargs={
                    'port': port,
                },
                daemon=True,
            ).start()
    
    def _create_listener(self) -> str:
        self._simple_id_generator += 1
        id = str(self._simple_id_generator)
        self._messages[id] = []
        return id
    
    def _check_message_ready(self, id: str) -> bool:
        return bool(self._messages[id])
    
    def _fetch_messages(self, id) -> t.Iterator[str]:
        with self._thread_lock():
            msg = self._messages[id]
            yield from msg
            msg.clear()
    
    @contextmanager
    def _thread_lock(self):
        self._locked, bak = True, self._locked
        try:
            yield
        finally:
            self._locked = bak


class Listener:
    def __init__(self, host=air.DEFAULT_HOST, port: int = 2033):
        self._client = air.Client(host, port)
        self._client.open()
    
    def start(self, blocking: bool = True):
        self._client.call('init')
        if blocking:
            self._listening()
        else:
            Thread(target=self._listening, daemon=True).start()
    
    def _listening(self):
        id = self._client.call('init')
        while True:
            if self._client.call('check', id):
                for msg in self._client.call('fetch', id):
                    print(msg)
                sleep(0.1)
            else:
                sleep(1)
