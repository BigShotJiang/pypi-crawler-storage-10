"""
HTTP client for interacting with the Spanish Vehicle Tax Valuation API.
"""

import httpx
from typing import Any, Dict, Optional
from .config import settings


class APIClient:
    """Client for making requests to the Spanish Vehicle Tax Valuation API."""
    
    def __init__(
        self,
        base_url: Optional[str] = None,
        timeout: Optional[int] = None
    ):
        """
        Initialize the API client.
        
        Args:
            base_url: Base URL for the API
            timeout: Request timeout in seconds
        """
        self.base_url = (base_url or settings.api_base_url).rstrip("/")
        self.timeout = timeout or settings.api_timeout
        self.client = httpx.AsyncClient(timeout=self.timeout)
    
    async def close(self):
        """Close the HTTP client."""
        await self.client.aclose()
    
    async def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        json_data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Make an HTTP request to the API.
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint (e.g., "/api/models")
            params: Query parameters
            json_data: JSON body for POST requests
            
        Returns:
            API response as a dictionary
            
        Raises:
            httpx.HTTPError: If the request fails
        """
        url = f"{self.base_url}{endpoint}"
        
        try:
            # Debug: Log the request details
            print(f"DEBUG: Making {method} request to {url}")
            print(f"DEBUG: Params: {params}")
            print(f"DEBUG: JSON data: {json_data}")
            
            response = await self.client.request(
                method=method,
                url=url,
                params=params,
                json=json_data
            )
            response.raise_for_status()
            result = response.json()
            print(f"DEBUG: Response status: {response.status_code}")
            print(f"DEBUG: Response data count: {result.get('count', 'N/A')}")
            return result
        except httpx.HTTPError as e:
            # Re-raise with more context
            raise Exception(f"API request failed: {str(e)}")
    
    # Vehicle Models - Simplified API with single endpoint
    async def get_models(
        self,
        brand: Optional[str] = None,
        model: Optional[str] = None,
        start_year: Optional[int] = None,
        end_year: Optional[int] = None,
        fuel_type: Optional[str] = None,
        price_year: Optional[int] = None,
        page: int = 1,
        per_page: int = 50
    ) -> Dict[str, Any]:
        """
        Get vehicle models with optional filtering.
        
        Args:
            brand: Filter by brand/manufacturer (partial match)
            model: Filter by model name (partial match, case-insensitive)
            start_year: Filter by start year
            end_year: Filter by end year
            fuel_type: Filter by fuel type
            price_year: Filter by price year
            page: Page number for pagination
            per_page: Items per page
            
        Returns:
            API response with models list and pagination info
        """
        params = {
            "page": page,
            "per_page": per_page
        }
        if brand:
            params["brand"] = brand
        if model:
            params["model"] = model
        if start_year is not None:
            params["start_year"] = start_year
        if end_year is not None:
            params["end_year"] = end_year
        if fuel_type:
            params["fuel_type"] = fuel_type
        if price_year is not None:
            params["price_year"] = price_year
        
        return await self._request("GET", "/api/models", params=params)
    
    async def get_model(self, model_id: int) -> Dict[str, Any]:
        """Get a specific model by ID."""
        return await self._request("GET", f"/api/models/{model_id}")
    
    async def create_model(self, model_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new vehicle model."""
        return await self._request("POST", "/api/models", json_data=model_data)
    
    async def update_model(
        self,
        model_id: int,
        model_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Update a vehicle model."""
        return await self._request(
            "PUT",
            f"/api/models/{model_id}",
            json_data=model_data
        )
    
    async def delete_model(self, model_id: int) -> Dict[str, Any]:
        """Delete a vehicle model."""
        return await self._request("DELETE", f"/api/models/{model_id}")
    
    # Health Check
    async def health_check(self) -> Dict[str, Any]:
        """Check API health status."""
        return await self._request("GET", "/health")
