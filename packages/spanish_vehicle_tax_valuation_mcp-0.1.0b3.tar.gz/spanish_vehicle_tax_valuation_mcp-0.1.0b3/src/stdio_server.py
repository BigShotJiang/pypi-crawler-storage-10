"""
Spanish Vehicle Tax Valuation MCP Server - STDIO Transport.

This entry point runs the MCP server with stdio (standard input/output)
transport, which is required for desktop MCP clients like Claude Desktop,
ChatGPT Desktop, and other local MCP integrations.

Supported deployment:
- STDIO: Local desktop clients (Claude Desktop, ChatGPT Desktop, etc.)
"""

import sys
from .server import server


def main():
    """Main entry point for stdio transport."""
    
    # Configure logging for stdio mode
    # Less verbose to avoid interfering with protocol
    import logging
    logging.basicConfig(
        level=logging.WARNING,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        stream=sys.stderr  # Log to stderr to keep stdout clean
    )
    
    # Log startup to stderr
    print(
        "Starting Spanish Vehicle Tax Valuation MCP server with stdio",
        file=sys.stderr,
        flush=True
    )
    
    # Run server with stdio transport
    try:
        server.run(transport="stdio")
    except KeyboardInterrupt:
        print("\nServer stopped by user", file=sys.stderr)
        sys.exit(0)
    except Exception as e:
        print(f"Error running server: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
