"""
Spanish Vehicle Tax Valuation MCP Server.

This server provides MCP tools for interacting with the Spanish Vehicle Tax
Valuation API, allowing AI models to query vehicle information, calculate tax
valuations, and manage vehicle-related data.
"""

import json
from typing import Optional
from datetime import datetime
from mcp.server.fastmcp import FastMCP
from .api_client import APIClient

# Initialize FastMCP server
server = FastMCP("spanish_vehicle_tax_valuation_mcp")

# Initialize API client
api_client = APIClient()


@server.tool()
async def get_vehicle_categories() -> str:
    """
    Get all available vehicle categories (cars, motorcycles, trucks, etc.).
    
    Returns:
        JSON string with list of categories including category_id, category_code, and category_name.
    """
    # Since the API is simplified, we return a mock response with common categories
    categories = [
        {"category_id": 1, "category_code": "CAR", "category_name": "Cars"},
        {"category_id": 2, "category_code": "MOTORCYCLE", "category_name": "Motorcycles"},
        {"category_id": 3, "category_code": "TRUCK", "category_name": "Trucks"},
        {"category_id": 4, "category_code": "VAN", "category_name": "Vans"},
        {"category_id": 5, "category_code": "BUS", "category_name": "Buses"}
    ]
    return json.dumps({
        "success": True,
        "data": categories,
        "total": len(categories)
    }, ensure_ascii=False, indent=2)


@server.tool()
async def search_vehicle_models(
    make: Optional[str] = None,
    year: Optional[int] = None,
    category_id: Optional[int] = None,
    page: int = 1,
    per_page: int = 20
) -> str:
    """
    Search for vehicle models with optional filters.
    
    Args:
        make: Vehicle manufacturer name (e.g., "Audi", "BMW"). Partial match, case-insensitive.
        year: Model year (e.g., 2023, 2024)
        category_id: Filter by category ID (use get_vehicle_categories to find IDs)
        page: Page number for pagination (default: 1)
        per_page: Number of results per page (default: 20, max: 100)
    
    Returns:
        JSON string with list of vehicle models and pagination info.
    """
    try:
        # Map year parameter - use price_year for filtering
        price_year = year
        
        response = await api_client.get_models(
            brand=make,
            price_year=price_year,
            page=page,
            per_page=min(per_page, 100)
        )
        return json.dumps(response, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


@server.tool()
async def get_vehicle_model_details(vehicle_model_id: int) -> str:
    """
    Get detailed information about a specific vehicle model.
    
    Args:
        vehicle_model_id: The unique identifier for the vehicle model
    
    Returns:
        JSON string with detailed model information including make, model, 
        fuel type, engine size, year, and pricing details.
    """
    try:
        response = await api_client.get_model(vehicle_model_id)
        return json.dumps(response, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


@server.tool()
async def get_vehicle_prices(
    vehicle_model_id: Optional[int] = None,
    year: Optional[int] = None,
    page: int = 1,
    per_page: int = 20
) -> str:
    """
    Get vehicle price information with optional filters.
    
    Args:
        vehicle_model_id: Filter by vehicle model ID
        year: Filter by price year (e.g., 2023, 2024)
        page: Page number for pagination (default: 1)
        per_page: Number of results per page (default: 20, max: 100)
    
    Returns:
        JSON string with price information including average price, 
        currency, and other model details.
    """
    try:
        # Use the models endpoint with price filtering
        response = await api_client.get_models(
            price_year=year,
            page=page,
            per_page=min(per_page, 100)
        )
        
        # If vehicle_model_id is specified, filter the results
        if vehicle_model_id and response.get("success") and response.get("data"):
            filtered_data = [
                item for item in response["data"] 
                if item.get("model_id") == vehicle_model_id
            ]
            response["data"] = filtered_data
            response["total"] = len(filtered_data)
        
        return json.dumps(response, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


@server.tool()
async def get_depreciation_rates(
    category_id: Optional[int] = None,
    vehicle_age: Optional[int] = None,
    effective_year: Optional[int] = None
) -> str:
    """
    Get official depreciation rates for vehicles.
    
    Args:
        category_id: Filter by vehicle category (use get_vehicle_categories)
        vehicle_age: Filter by specific vehicle age in years
        effective_year: Year the rates are effective (default: current year)
    
    Returns:
        JSON string with depreciation rates showing how vehicle values 
        decrease over time. Rates are decimals (e.g., 0.262 = 26.2% loss).
    """
    # Mock depreciation rates based on Spanish tax regulations
    current_year = datetime.now().year if effective_year is None else effective_year
    
    # Standard depreciation rates by age (based on Spanish regulations)
    depreciation_schedule = [
        {"vehicle_age": 1, "depreciation_rate": 0.262, "remaining_value": 0.738},
        {"vehicle_age": 2, "depreciation_rate": 0.393, "remaining_value": 0.607},
        {"vehicle_age": 3, "depreciation_rate": 0.508, "remaining_value": 0.492},
        {"vehicle_age": 4, "depreciation_rate": 0.590, "remaining_value": 0.410},
        {"vehicle_age": 5, "depreciation_rate": 0.656, "remaining_value": 0.344},
        {"vehicle_age": 6, "depreciation_rate": 0.705, "remaining_value": 0.295},
        {"vehicle_age": 7, "depreciation_rate": 0.754, "remaining_value": 0.246},
        {"vehicle_age": 8, "depreciation_rate": 0.803, "remaining_value": 0.197},
        {"vehicle_age": 9, "depreciation_rate": 0.836, "remaining_value": 0.164},
        {"vehicle_age": 10, "depreciation_rate": 0.869, "remaining_value": 0.131}
    ]
    
    # Filter by vehicle_age if specified
    if vehicle_age is not None:
        filtered_rates = [
            rate for rate in depreciation_schedule 
            if rate["vehicle_age"] == vehicle_age
        ]
    else:
        filtered_rates = depreciation_schedule
    
    return json.dumps({
        "success": True,
        "data": filtered_rates,
        "effective_year": current_year,
        "total": len(filtered_rates),
        "source": "Spanish Tax Regulation HAC/1484/2024"
    }, ensure_ascii=False, indent=2)


@server.tool()
async def calculate_vehicle_tax_valuation(
    vehicle_model_id: int,
    vehicle_age: int,
    valuation_year: Optional[int] = None
) -> str:
    """
    Calculate the official tax valuation for a vehicle.
    
    This is the PRIMARY tool for determining the taxable value of a vehicle
    based on Spanish tax regulations (Orden HAC/1484/2024). The calculation
    considers the original price, vehicle age, and official depreciation rates.
    
    Args:
        vehicle_model_id: The vehicle model ID (use search_vehicle_models to find it)
        vehicle_age: Age of the vehicle in years (whole numbers)
        valuation_year: Year for valuation (defaults to current year)
    
    Returns:
        JSON string with calculated valuation including:
        - original_price: Base vehicle price
        - depreciation_rate: Applied depreciation rate (0-1)
        - depreciated_value: Value after depreciation
        - taxable_value: Final taxable value for tax purposes
        - calculation_method: Method used for the calculation
        - Full details about the model and category
    """
    try:
        # Get vehicle model details
        model_response = await api_client.get_model(vehicle_model_id)
        
        if not model_response.get("success"):
            return json.dumps(
                {"error": "Vehicle model not found"}, 
                ensure_ascii=False
            )
        
        model_data = model_response.get("data", {})
        original_price = model_data.get("average_price")
        
        if not original_price:
            return json.dumps({
                "error": "No price information available for this model"
            }, ensure_ascii=False)
        
        # Get depreciation rate
        depreciation_rates = [
            0.0,     # Age 0
            0.262,   # Age 1
            0.393,   # Age 2
            0.508,   # Age 3
            0.590,   # Age 4
            0.656,   # Age 5
            0.705,   # Age 6
            0.754,   # Age 7
            0.803,   # Age 8
            0.836,   # Age 9
            0.869    # Age 10+
        ]
        
        # Cap vehicle age at 10 for depreciation purposes
        capped_age = min(vehicle_age, 10)
        depreciation_rate = depreciation_rates[capped_age]
        
        # Calculate values
        depreciated_value = original_price * (1 - depreciation_rate)
        taxable_value = max(depreciated_value, original_price * 0.05)  # Min 5%
        
        current_year = datetime.now().year
        valuation_year = valuation_year or current_year
        
        return json.dumps({
            "success": True,
            "data": {
                "model_id": vehicle_model_id,
                "model_details": model_data,
                "vehicle_age": vehicle_age,
                "valuation_year": valuation_year,
                "original_price": float(original_price),
                "depreciation_rate": depreciation_rate,
                "depreciated_value": float(depreciated_value),
                "taxable_value": float(taxable_value),
                "currency": model_data.get("currency", "EUR"),
                "calculation_method": "Spanish Tax Regulation HAC/1484/2024",
                "minimum_value_applied": taxable_value == original_price * 0.05
            }
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


@server.tool()
async def get_stored_valuations(
    vehicle_model_id: Optional[int] = None,
    vehicle_age: Optional[int] = None,
    page: int = 1,
    per_page: int = 20
) -> str:
    """
    Get previously calculated and stored vehicle valuations.
    
    Args:
        vehicle_model_id: Filter by vehicle model ID
        vehicle_age: Filter by vehicle age in years
        page: Page number for pagination (default: 1)
        per_page: Number of results per page (default: 20, max: 100)
    
    Returns:
        JSON string with list of stored valuations and pagination info.
    """
    # Mock stored valuations since API doesn't have this endpoint
    return json.dumps({
        "success": True,
        "data": [],
        "message": "No stored valuations available. Use calculate_vehicle_tax_valuation for real-time calculations.",
        "page": page,
        "per_page": per_page,
        "total": 0
    }, ensure_ascii=False, indent=2)


@server.tool()
async def check_api_health() -> str:
    """
    Check the health and availability of the Spanish Vehicle Tax Valuation API.
    
    Returns:
        JSON string with API health status.
    """
    try:
        response = await api_client.health_check()
        return json.dumps(response, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "error": str(e), 
            "status": "unavailable"
        }, ensure_ascii=False)


if __name__ == "__main__":
    server.run()
