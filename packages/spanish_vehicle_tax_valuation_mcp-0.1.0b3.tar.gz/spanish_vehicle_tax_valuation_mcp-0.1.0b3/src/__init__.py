"""
Spanish Vehicle Tax Valuation MCP Server - Production Server.

This is the main production MCP server running with SSE (Server-Sent Events)
transport. Designed for Azure Web App deployment.

Supported deployment:
- SSE (HTTP): Production deployment on Azure Web App
"""

import os
from .server import server
from .config import settings

if __name__ == "__main__":
    """Main entry point - Production SSE server only."""
    
    # Configure server settings from environment
    server.settings.log_level = os.environ.get(
        "LOG_LEVEL", settings.log_level
    )
    
    # SSE transport for HTTP-based communication (production)
    port = int(os.environ.get("PORT", settings.port))
    host = os.environ.get("HOST", settings.host)
    server.settings.port = port
    server.settings.host = host
    
    print(
        f"Starting MCP server with SSE transport on {host}:{port}",
        flush=True
    )
    
    server.run(transport="sse")
