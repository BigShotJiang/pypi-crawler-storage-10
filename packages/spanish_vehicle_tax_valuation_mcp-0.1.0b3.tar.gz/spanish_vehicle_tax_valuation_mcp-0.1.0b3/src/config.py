"""
Configuration module for the Spanish Vehicle Tax Valuation MCP Server.
"""

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Configuration settings for the MCP server."""
    
    # API Configuration
    api_base_url: str = "http://localhost:5000"
    api_timeout: int = 30
    
    # Server Configuration
    log_level: str = "INFO"
    port: int = 3001
    host: str = "127.0.0.1"
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False
    )


# Global settings instance
settings = Settings()
