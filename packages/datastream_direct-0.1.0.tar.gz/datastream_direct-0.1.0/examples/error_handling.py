#!/usr/bin/env python3
"""
Error handling example for the DataStream Direct Python client.
"""

import logging
from datastream_direct import (
    connect,
    DataStreamDirectError,
    AuthenticationError,
    ConnectionError,
    QueryError,
    APIError,
)

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def main():
    """Main example function demonstrating error handling."""
    # Connection parameters
    connection_params = {
        "username": "your_username",
        "password": "your_password",
        "host": "your_host",
        "port": 5432,
        "database": "your_database",
        "base_url": "https://api.example.com",
    }

    connection = None
    try:
        # Connect to the API
        logger.info("Connecting to DataStream Direct API...")
        connection = connect(**connection_params)
        logger.info("Successfully connected!")

        # Create a cursor
        cursor = connection.cursor()

        # Example 1: Valid query
        try:
            logger.info("Executing valid query...")
            cursor.execute("SELECT 1 as test_column")
            result = cursor.fetchone()
            logger.info(f"Query result: {result}")
        except QueryError as e:
            logger.error(f"Query error: {e}")
        except Exception as e:
            logger.error(f"Unexpected query error: {e}")

        # Example 2: Invalid query
        try:
            logger.info("Executing invalid query...")
            cursor.execute("INVALID SQL SYNTAX")
            result = cursor.fetchone()
            logger.info(f"Query result: {result}")
        except QueryError as e:
            logger.error(f"Query error (expected): {e}")
        except Exception as e:
            logger.error(f"Unexpected query error: {e}")

        # Example 3: Query without execution
        try:
            logger.info("Trying to fetch without executing query...")
            result = cursor.fetchone()
            logger.info(f"Query result: {result}")
        except QueryError as e:
            logger.error(f"Query error (expected): {e}")
        except Exception as e:
            logger.error(f"Unexpected query error: {e}")

        # Close the cursor
        cursor.close()

    except AuthenticationError as e:
        logger.error(f"Authentication failed: {e}")
    except ConnectionError as e:
        logger.error(f"Connection failed: {e}")
    except APIError as e:
        logger.error(f"API error: {e}")
    except DataStreamDirectError as e:
        logger.error(f"DataStream Direct error: {e}")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
    finally:
        # Always close the connection
        if connection:
            connection.close()
            logger.info("Connection closed")


def demonstrate_connection_errors():
    """Demonstrate various connection error scenarios."""
    logger.info("=== Connection Error Examples ===")

    # Example 1: Invalid configuration
    try:
        logger.info("Testing invalid configuration...")
        connection = connect(
            username="",  # Invalid empty username
            password="test",
            host="localhost",
            port=5432,
            database="testdb",
            base_url="https://api.example.com",
        )
    except ValueError as e:
        logger.error(f"Configuration error (expected): {e}")

    # Example 2: Invalid URL
    try:
        logger.info("Testing invalid URL...")
        connection = connect(
            username="test",
            password="test",
            host="localhost",
            port=5432,
            database="testdb",
            base_url="",  # Invalid empty URL
        )
    except ValueError as e:
        logger.error(f"URL error (expected): {e}")

    # Example 3: Invalid port
    try:
        logger.info("Testing invalid port...")
        connection = connect(
            username="test",
            password="test",
            host="localhost",
            port=0,  # Invalid port
            database="testdb",
            base_url="https://api.example.com",
        )
    except ValueError as e:
        logger.error(f"Port error (expected): {e}")


if __name__ == "__main__":
    main()
    print("\n" + "=" * 50 + "\n")
    demonstrate_connection_errors()
