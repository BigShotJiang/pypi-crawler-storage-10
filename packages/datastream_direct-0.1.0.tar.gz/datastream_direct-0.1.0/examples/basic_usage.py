#!/usr/bin/env python3
"""
Basic usage example for the DataStream Direct Python client.
"""

import logging
from datastream_direct import connect, DataStreamDirectError

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def main():
    """Main example function."""
    # Connection parameters
    connection_params = {
        "username": "your_username",
        "password": "your_password",
        "host": "your_host",
        "port": 5432,
        "database": "your_database",
        "base_url": "https://api.example.com",
    }

    connection = None
    try:
        # Connect to the API
        logger.info("Connecting to DataStream Direct API...")
        connection = connect(**connection_params)
        logger.info("Successfully connected!")

        # Create a cursor
        cursor = connection.cursor()

        # Execute a simple query
        logger.info("Executing query...")
        cursor.execute("SELECT COUNT(*) as total_users FROM users")

        # Fetch the result
        result = cursor.fetchone()
        if result:
            logger.info(f"Total users: {result[0]}")

        # Execute a more complex query
        logger.info("Executing complex query...")
        cursor.execute(
            """
            SELECT 
                id, 
                name, 
                email, 
                created_at 
            FROM users 
            WHERE active = true 
            ORDER BY created_at DESC 
            LIMIT 10
        """
        )

        # Fetch all results
        users = cursor.fetchall()
        logger.info(f"Found {len(users)} active users:")

        for user in users:
            user_id, name, email, created_at = user
            logger.info(
                f"  ID: {user_id}, Name: {name}, Email: {email}, Created: {created_at}"
            )

        # Close the cursor
        cursor.close()

    except DataStreamDirectError as e:
        logger.error(f"DataStream Direct error: {e}")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
    finally:
        # Always close the connection
        if connection:
            connection.close()
            logger.info("Connection closed")


if __name__ == "__main__":
    main()
