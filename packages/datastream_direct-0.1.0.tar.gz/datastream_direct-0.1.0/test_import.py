#!/usr/bin/env python3
"""
Test script to verify package imports work correctly.
"""

import sys
import os

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    # Test basic imports
    from datastream_direct import connect
    from datastream_direct import (
        DataStreamDirectError,
        AuthenticationError,
        ConnectionError,
        QueryError,
        TokenExpiredError,
        APIError,
        ConnectionConfig,
        QueryResult,
    )
    from datastream_direct.connection import DatastreamDirectConnection
    from datastream_direct.cursor import DatastreamDirectCursor
    from datastream_direct.api_client import DataStreamDirectAPIClient

    print("✅ All imports successful!")
    print("✅ Package structure is correct!")

    # Test basic functionality
    try:
        # This should raise a ValueError due to invalid configuration
        connect(
            username="",
            password="test",
            host="localhost",
            port=5432,
            database="test",
            base_url="https://api.example.com",
        )
    except ValueError as e:
        print(f"✅ Input validation working: {e}")

    print("✅ Package is ready for use!")

except ImportError as e:
    print(f"❌ Import error: {e}")
    sys.exit(1)
except Exception as e:
    print(f"❌ Unexpected error: {e}")
    sys.exit(1)
