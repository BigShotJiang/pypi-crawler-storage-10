import importlib.metadata
import logging

__version__ = "1.0.7"


logger = logging.Logger("krrood")
logger.setLevel(logging.INFO)
