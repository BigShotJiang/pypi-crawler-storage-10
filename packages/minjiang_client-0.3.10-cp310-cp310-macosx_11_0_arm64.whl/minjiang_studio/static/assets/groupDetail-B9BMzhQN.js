import{aO as t,r as o}from"./index-Dp6D7Cp9.js";const a=t("groupDetail",()=>{const r=o(),e=o();return{groupInfo:r,spaceList:e}});export{a as u};
