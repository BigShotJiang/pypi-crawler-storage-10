import{aO as o,r as s}from"./index-Dp6D7Cp9.js";const r=o("autoCali",()=>({sessionInfo:s()}));export{r as u};
