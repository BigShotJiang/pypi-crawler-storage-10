"""
Modules for performing flatfields.
TODO: write doc
"""

__title__ = "Flatfielding"

from .flatfield import FlatField
from .pointing import FlatFieldPointing
from .scheduler import FlatFieldScheduler
