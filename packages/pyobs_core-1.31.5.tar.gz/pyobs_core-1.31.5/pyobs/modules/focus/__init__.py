"""
Modules for focus-related tasks.
TODO: write doc
"""

__title__ = "Focus"

from .focusmodel import FocusModel
from .focusseries import AutoFocusSeries
