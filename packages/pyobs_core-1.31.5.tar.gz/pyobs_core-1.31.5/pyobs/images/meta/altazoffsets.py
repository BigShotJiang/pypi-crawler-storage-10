class AltAzOffsets:
    def __init__(self, dalt: float = 0, daz: float = 0):
        self.dalt = dalt
        self.daz = daz


__all__ = ["AltAzOffsets"]
