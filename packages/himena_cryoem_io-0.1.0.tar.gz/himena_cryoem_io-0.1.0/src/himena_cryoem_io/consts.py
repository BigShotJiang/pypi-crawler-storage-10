class Type:
    IMOD_MODEL = "imodmodel"
    NAV = "text.serialem-nav"
