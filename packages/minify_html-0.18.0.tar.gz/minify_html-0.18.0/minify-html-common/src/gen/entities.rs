include!(concat!(env!("OUT_DIR"), "/entities.rs"));
