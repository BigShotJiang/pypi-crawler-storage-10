pub mod ns;
pub mod omission;
pub mod void;
pub mod whitespace;

pub static EMPTY_SLICE: &[u8] = &[];
