from .utils import (
    significance_size,
    add_suffix_to_dupes,
    calc_ttest_ind,
    calc_ttest_paired,
    SimpleLRUCache,
)