def main():
    print("Hello from ducku!")


if __name__ == "__main__":
    main()
