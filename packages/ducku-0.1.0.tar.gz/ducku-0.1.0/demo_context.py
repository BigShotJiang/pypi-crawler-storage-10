#!/usr/bin/env python3
"""
Demo script to show how context is passed to postfilters
"""

from src.core.search_pattern import SearchPattern
from src.core.documentation import DocString

# Create a simple postfilter that uses context
class TestPattern(SearchPattern):
    def context_aware_filter(self, m, context: str | None = None) -> bool:
        """A postfilter that uses context to make decisions"""
        if context is None:
            return True
        
        # Example: only match numbers that have "port" in their context
        match_text = m.group(0)
        context_lower = context.lower()
        
        print(f"Match: '{match_text}' | Context: '{context}' | Has 'port': {'port' in context_lower}")
        
        return 'port' in context_lower

# Test the context-aware postfilter
if __name__ == "__main__":
    # Create a pattern that matches numbers but only when "port" is in context
    pattern = TestPattern("Context-aware number", r'\d+', ["context_aware_filter"])
    
    # Test cases
    test_cases = [
        "The service runs on port 8080 for HTTP traffic",
        "There are 42 items in the list",
        "Server port is 3306 for database connections",
        "The year 2023 was eventful"
    ]
    
    for test_case in test_cases:
        doc = DocString(test_case, "test")
        result = pattern.is_in(doc)
        print(f"Text: '{test_case}'")
        print(f"Match found: {result is not None}")
        print("-" * 50)
