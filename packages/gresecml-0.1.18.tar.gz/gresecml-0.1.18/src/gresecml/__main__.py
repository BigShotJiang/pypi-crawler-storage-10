import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2' # Suppress TensorFlow logging from console
import click
from gresecml.commands.tensorflow_group import tf as tf_group
from pyfiglet import Figlet


class BannerGroup(click.Group):
    def format_help(self, ctx, formatter):
        custom_banner = Figlet(font='slant')
        click.echo(click.style(custom_banner.renderText("GresecML"), fg='yellow'))
        super().format_help(ctx, formatter)

@click.group(cls=BannerGroup)
def main():
    pass
main.add_command(tf_group)