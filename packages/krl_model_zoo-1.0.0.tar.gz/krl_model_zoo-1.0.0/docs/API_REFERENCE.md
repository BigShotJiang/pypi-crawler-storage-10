---
© 2025 KR-Labs. All rights reserved.  
KR-Labs™ is a trademark of Quipu Research Labs, LLC, a subsidiary of Sudiata Giddasira, Inc.

SPDX-License-Identifier: Apache-2.0
---

# KRL Model Zoo - API Reference

**Version:** .  
**Last Updated:** October 24, 22

This document provides detailed API reference for all classes, methods, and functions in the KRL Model Zoo.

---

## Table of ontents

. [Volatility Models](#volatility-models)
   - [GRHModel](#garchmodel)
   - [GRHModel](#egarchmodel)
   - [GJRGRHModel](#gjrgarchmodel)
2. [State Space Models](#state-space-models)
   - [Kalmanilter](#kalmanfilter)
   - [LocalLevelModel](#locallevelmodel)
3. [Core lasses](#core-classes)
   - [ModelInputSchema](#modelinputschema)
   - [ModelMeta](#modelmeta)
   - [orecastResult](#forecastresult)
4. [Utilities](#utilities)
. [Exceptions](#exceptions)

---

## Volatility Models

### GRHModel

**Module:** `krl_models.volatility.garch_model`

Generalized Autoregressive onditional Heteroskedasticity model for volatility forecasting.

#### lass efinition

```python
class GRHModel(aseModel):
    """
    GRH(p,q) model for conditional volatility forecasting.
    
    Models time-varying volatility in financial returns using RH and GRH terms.
    """
```

#### Mathematical Specification

**Returns quation:**
$$r_t = \mu + \epsilon_t$$
$$\epsilon_t = \sigma_t z_t, \quad z_t \sim (,)$$

**Variance quation:**
$$\sigma_t^2 = \omega + \sum_{i=}^{q} \alpha_i \epsilon_{t-i}^2 + \sum_{j=}^{p} \beta_j \sigma_{t-j}^2$$

#### onstructor

```python
def __init__(
    self,
    input_schema: ModelInputSchema,
    params: ict[str, ny],
    meta: ModelMeta
) -> None
```

**Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `input_schema` | `ModelInputSchema` | Validated input schema with data configuration |
| `params` | `ict[str, ny]` | Model parameters (see below) |
| `meta` | `ModelMeta` | Model metadata |

**Parameter ictionary (`params`):**

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `p` | `int` |  | GRH order (lags of conditional variance) |
| `q` | `int` |  | RH order (lags of squared residuals) |
| `mean_model` | `str` | `'onstant'` | Mean specification: `'onstant'`, `'Zero'`, `'R'` |
| `ar_lags` | `int` |  | R order if `mean_model='R'` |
| `distribution` | `str` | `'normal'` | Error distribution: `'normal'`, `'t'`, `'ged'`, `'skewt'` |
| `vol_forecast_horizon` | `int` |  | Default forecast horizon |
| `use_returns` | `bool` | `True` | If alse, convert prices to log returns |

**Raises:**
- `Valuerror`: If p < , q < , or invalid parameter values

**Example:**

```python
from krl_models.volatility import GRHModel
from krl_core.model_input_schema import ModelInputSchema
from krl_core.base_model import ModelMeta

input_schema = ModelInputSchema(
    data_columns=['returns'],
    index_col='date',
    required_columns=['returns']
)

params = {
    'p': ,
    'q': ,
    'mean_model': 'onstant',
    'distribution': 'normal',
    'vol_forecast_horizon': 3
}

meta = ModelMeta(
    name='SPX_GRH',
    version='.',
    author='Risk Team',
    description='S&P  volatility model'
)

model = GRHModel(input_schema=input_schema, params=params, meta=meta)
```

#### Methods

##### `fit(data: pd.atarame) -> orecastResult`

Estimate GRH model parameters using Maximum Likelihood stimation.

**Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `data` | `pd.atarame` | Time series data with returns column |

**Returns:**
- `orecastResult`: Object containing:
  - `success` (bool): Whether optimization converged
  - `log_likelihood` (float): Log-likelihood value
  - `aic` (float): kaike Information Writerion
  - `bic` (float): ayesian Information Writerion
  - `params` (dict): Estimated parameters
  - `std_errors` (dict): Standard errors of parameters
  - `payload` (dict): dditional model-specific outputs

**Raises:**
- `Valuerror`: If data is invalid or empty
- `Runtimerror`: If optimization fails to converge

**Example:**

```python
import pandas as pd
import numpy as np

# Generate sample returns
dates = pd.date_range('22--', periods=, freq='')
returns = np.random.randn() * .2
data = pd.atarame({'returns': returns}, index=dates)

# it model
result = model.fit(data)

print(f"onverged: {result.success}")
print(f"Log-Likelihood: {result.log_likelihood:.2f}")
print(f"I: {result.aic:.2f}")
print(f"I: {result.bic:.2f}")

# ccess Testimated parameters
omega = model.params['omega']
alpha = model.params['alpha'][]
beta = model.params['beta'][]
print(f"ω = {omega:.f}, α = {alpha:.f}, β = {beta:.f}")
```

##### `predict(steps: int = None, **kwargs) -> orecastResult`

Generate multi-step ahead volatility forecasts.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `steps` | `int` | `vol_forecast_horizon` | Number of steps to forecast |
| `**kwargs` | `dict` | `{}` | dditional forecast options |

**Returns:**
- `orecastResult`: Object containing:
  - `forecast_values` (np.ndarray): Point forecasts (volatility)
  - `ci_lower` (np.ndarray): Lower confidence interval
  - `ci_upper` (np.ndarray): Upper confidence interval
  - `forecast_variance` (np.ndarray): orecast variance
  - `payload` (dict): dditional forecast outputs

**Example:**

```python
# 3-day ahead forecast
forecast = model.predict(steps=3)

print(f"ay  volatility: {forecast.forecast_values[]:.f}")
print(f"ay  % I: [{forecast.ci_lower[]:.f}, {forecast.ci_upper[]:.f}]")

# alculate Value-at-Risk
portfolio_value = __
z_score_ = .4
var_ = portfolio_value * z_score_ * forecast.forecast_values[]
print(f"-day % VaR: ${var_:,.2f}")
```

##### `get_conditional_volatility() -> np.ndarray`

xtract fitted conditional volatility (in-sample).

**Returns:**
- `np.ndarray`: onditional volatility σ_t for each time period

**Example:**

```python
cond_vol = model.get_conditional_volatility()

print(f"Mean volatility: {np.mean(cond_vol):.f}")
print(f"Max volatility: {np.max(cond_vol):.f}")
print(f"Min volatility: {np.min(cond_vol):.f}")

# nnualized volatility
annual_vol = np.mean(cond_vol) * np.sqrt(22)
print(f"nnualized volatility: {annual_vol*:.2f}%")
```

##### `get_standardized_residuals() -> np.ndarray`

xtract standardized residuals (ε_t / σ_t) for diagnostic testing.

**Returns:**
- `np.ndarray`: Standardized residuals

**Example:**

```python
std_resid = model.get_standardized_residuals()

# heck for remaining RH effects
from statsmodels.stats.diagnostic import acorr_ljungbox

lb_test = acorr_ljungbox(std_resid**2, lags=, return_df=True)
print(f"Ljung-ox test on squared residuals:")
print(lb_test)

if all(lb_test['lb_pvalue'] > .):
    print(" No remaining RH effects")
else:
    print("  RH effects remain - consider higher order model")
```

##### `calculate_var(confidence_level: float = .) -> float`

alculate Value-at-Risk for -day horizon.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `confidence_level` | `float` | . | onfidence level (-) |

**Returns:**
- `float`: VaR as a proportion of portfolio value

**Example:**

```python
var_ = model.calculate_var(confidence_level=.)
var_ = model.calculate_var(confidence_level=.)

portfolio = __
print(f"% VaR: ${var_ * portfolio:,.2f}")
print(f"% VaR: ${var_ * portfolio:,.2f}")
```

#### Properties

| Property | Type | Description |
|----------|------|-------------|
| `params` | `ict[str, ny]` | Estimated model parameters |
| `fitted` | `bool` | Whether model has been fitted |
| `aic` | `float` | kaike Information Writerion |
| `bic` | `float` | ayesian Information Writerion |
| `log_likelihood` | `float` | Log-likelihood value |

---

### GRHModel

**Module:** `krl_models.volatility.egarch_model`

xponential GRH model for asymmetric volatility (leverage effects).

#### lass efinition

```python
class GRHModel(aseModel):
    """
    GRH(p,o,q) model for asymmetric conditional volatility.
    
    Models leverage effects where negative shocks increase volatility more than
    positive shocks of the same magnitude.
    """
```

#### Mathematical Specification

**Log-Variance quation:**
$$\log(\sigma_t^2) = \omega + \sum_{i=}^{o} \gamma_i z_{t-i} + \sum_{i=}^{q} \alpha_i |z_{t-i}| + \sum_{j=}^{p} \beta_j \log(\sigma_{t-j}^2)$$

where $z_t = \epsilon_t / \sigma_t$ is the standardized residual.

**Leverage ffect:**
- $\gamma < $: Negative shocks increase volatility MOR (typical for equities)
- $\gamma > $: Positive shocks increase volatility MOR (rare)
- $\gamma = $: Symmetric response

#### onstructor

```python
def __init__(
    self,
    input_schema: ModelInputSchema,
    params: ict[str, ny],
    meta: ModelMeta
) -> None
```

**Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `input_schema` | `ModelInputSchema` | Validated input schema |
| `params` | `ict[str, ny]` | Model parameters (see below) |
| `meta` | `ModelMeta` | Model metadata |

**Parameter ictionary (`params`):**

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `p` | `int` |  | GRH order |
| `o` | `int` |  | symmetry order (leverage terms) |
| `q` | `int` |  | RH order |
| `mean_model` | `str` | `'onstant'` | Mean specification |
| `distribution` | `str` | `'normal'` | Error distribution |
| `vol_forecast_horizon` | `int` |  | Default forecast horizon |

**Example:**

```python
from krl_models.volatility import GRHModel

params = {
    'p': ,
    'o': ,  # symmetry order
    'q': ,
    'mean_model': 'onstant',
    'distribution': 'normal'
}

model = GRHModel(input_schema=input_schema, params=params, meta=meta)
result = model.fit(equity_returns)

# heck for leverage effect
gamma = model.params['gamma'][]
if gamma < :
    print(f" Leverage effect detected (γ = {gamma:.4f})")
    print("   Negative shocks increase volatility more")
```

#### Methods

Methods are similar to `GRHModel`:
- `fit(data: pd.atarame) -> orecastResult`
- `predict(steps: int = None) -> orecastResult`
- `get_conditional_volatility() -> np.ndarray`
- `get_standardized_residuals() -> np.ndarray`

dditional method:

##### `get_leverage_parameter() -> float`

Get the Testimated leverage parameter γ.

**Returns:**
- `float`: Leverage parameter (γ <  indicates leverage effect)

**Example:**

```python
gamma = model.get_leverage_parameter()

if gamma < -.:
    effect = "Strong leverage effect"
elif gamma > .:
    effect = "Inverse leverage effect"
else:
    effect = "Symmetric volatility"

print(f"γ = {gamma:.4f}: {effect}")
```

---

### GJRGRHModel

**Module:** `krl_models.volatility.gjr_garch_model`

GJR-GRH model for threshold effects in volatility.

#### lass efinition

```python
class GJRGRHModel(aseModel):
    """
    GJR-GRH(p,o,q) model for threshold volatility effects.
    
    Models asymmetric volatility where negative shocks have different impact
    than positive shocks via indicator function.
    """
```

#### Mathematical Specification

**Variance quation:**
$$\sigma_t^2 = \omega + \sum_{i=}^{q} (\alpha_i + \gamma_i I_{t-i}) \epsilon_{t-i}^2 + \sum_{j=}^{p} \beta_j \sigma_{t-j}^2$$

where $I_t = $ if $\epsilon_t < $ (negative shock), else $I_t = $.

**Threshold ffect:**
- or negative shocks: impact = $\alpha + \gamma$
- or positive shocks: impact = $\alpha$
- If $\gamma > $: Negative shocks have stronger impact

#### onstructor

```python
def __init__(
    self,
    input_schema: ModelInputSchema,
    params: ict[str, ny],
    meta: ModelMeta
) -> None
```

**Parameters:** Same as GRH, with `o` representing threshold order.

**Example:**

```python
from krl_models.volatility import GJRGRHModel

params = {
    'p': ,
    'o': ,  # Threshold order
    'q': ,
    'mean_model': 'onstant',
    'distribution': 'normal'
}

model = GJRGRHModel(input_schema=input_schema, params=params, meta=meta)
result = model.fit(data)

# Analyze threshold effect
alpha = model.params['alpha'][]
gamma = model.params['gamma'][]

print(f"Impact of positive shock: {alpha:.f}")
print(f"Impact of negative shock: {alpha + gamma:.f}")
print(f"symmetry ratio: {(alpha + gamma) / alpha:.2f}x")
```

#### Methods

Same core methods as `GRHModel`. dditional method:

##### `get_threshold_parameter() -> float`

Get the Testimated threshold parameter γ.

**Returns:**
- `float`: Threshold parameter (γ >  indicates threshold effect)

---

## State Space Models

### Kalmanilter

**Module:** `krl_models.state_space.kalman_filter`

Linear Gaussian state space model with Kalman filtering and RTS smoothing.

#### lass efinition

```python
class Kalmanilter:
    """
    Kalman Filter for linear Gaussian state space models.
    
    Provides optimal state Testimation via filtering (online) and smoothing (offline).
    """
```

#### Mathematical Specification

**State quation:**
$$\mathbf{x}_t = \mathbf{} \mathbf{x}_{t-} + \mathbf{w}_t, \quad \mathbf{w}_t \sim N(\mathbf{}, \mathbf{Q})$$

**Observation quation:**
$$\mathbf{y}_t = \mathbf{H} \mathbf{x}_t + \mathbf{v}_t, \quad \mathbf{v}_t \sim N(\mathbf{}, \mathbf{R})$$

#### onstructor

```python
def __init__(
    self,
    n_states: int,
    n_obs: int,
    : np.ndarray,
    H: np.ndarray,
    Q: np.ndarray,
    R: np.ndarray,
    x: np.ndarray,
    P: np.ndarray
) -> None
```

**Parameters:**

| Parameter | Type | Shape | Description |
|-----------|------|-------|-------------|
| `n_states` | `int` | - | Number of state variables |
| `n_obs` | `int` | - | Number of observed variables |
| `` | `np.ndarray` | (n_states, n_states) | State transition matrix |
| `H` | `np.ndarray` | (n_obs, n_states) | Observation matrix |
| `Q` | `np.ndarray` | (n_states, n_states) | Process noise covariance |
| `R` | `np.ndarray` | (n_obs, n_obs) | Measurement noise covariance |
| `x` | `np.ndarray` | (n_states,) | Initial state Testimate |
| `P` | `np.ndarray` | (n_states, n_states) | Initial covariance matrix |

**Example:**

```python
from krl_models.state_space import Kalmanilter
import numpy as np

# Position-velocity tracking model
 = np.array([[., .], [., .]])  # State transition
H = np.array([[., .]])               # Observe position only
Q = np.array([[., .], [., .]]) # Process noise
R = np.array([[.]])                    # Measurement noise
x = np.array([., .])                # Initial state
P = np.array([[., .], [., 4.]]) # Initial covariance

kf = Kalmanilter(
    n_states=2,
    n_obs=,
    =, H=H, Q=Q, R=R,
    x=x, P=P
)
```

#### Methods

##### `fit(data: pd.atarame, smoothing: bool = alse) -> orecastResult`

Run Kalman filter (and optionally RTS smoother) on observed data.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `data` | `pd.atarame` | - | Observed data (n_obs columns) |
| `smoothing` | `bool` | `alse` | Whether to run backward smoothing pass |

**Returns:**
- `orecastResult`: Object containing:
  - `filtered_states` (np.ndarray): orward-filtered state Testimates
  - `filtered_covariances` (np.ndarray): Filtered covariances
  - `smoothed_states` (np.ndarray): Smoothed Testimates (if smoothing=True)
  - `smoothed_covariances` (np.ndarray): Smoothed covariances (if smoothing=True)
  - `innovations` (np.ndarray): Prediction errors (y_t - H x_{t|t-})
  - `log_likelihood` (float): Log-likelihood of observations

**Example:**

```python
import pandas as pd

# Prepare observation data
dates = pd.date_range('22--', periods=2, freq='H')
observed = np.random.randn(2) * .
data = pd.atarame({'position': observed}, index=dates)

# it with smoothing
result = kf.fit(data, smoothing=True)

# xtract results
filtered_states = result.payload['filtered_states']
smoothed_states = result.payload['smoothed_states']

# Filtered position and velocity
position_filtered = filtered_states[:, ]
velocity_filtered = filtered_states[:, ]

# Smoothed Testimates (better, uses all data)
position_smoothed = smoothed_states[:, ]
velocity_smoothed = smoothed_states[:, ]

print(f"inal position (filtered): {position_filtered[-]:.4f}")
print(f"inal position (smoothed): {position_smoothed[-]:.4f}")
print(f"inal velocity Testimate: {velocity_smoothed[-]:.4f}")
```

##### `predict(steps: int) -> orecastResult`

Generate multi-step ahead forecasts with Runcertainty quantification.

**Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `steps` | `int` | Number of steps to forecast |

**Returns:**
- `orecastResult`: orecast values with confidence intervals

**Example:**

```python
# 2-step ahead forecast
forecast = kf.predict(steps=2)

print(f"Step  forecast: {forecast.forecast_values[]:.4f}")
print(f"Step  % I: [{forecast.ci_lower[]:.4f}, {forecast.ci_upper[]:.4f}]")

print(f"Step 2 forecast: {forecast.forecast_values[]:.4f}")
print(f"Step 2 % I: [{forecast.ci_lower[]:.4f}, {forecast.ci_upper[]:.4f}]")

# Uncertainty grows with horizon
ci_widths = forecast.ci_upper - forecast.ci_lower
print(f"I width grows: {ci_widths[]:.4f} → {ci_widths[-]:.4f}")
```

##### `get_filtered_states() -> np.ndarray`

Get filtered state Testimates (forward pass only).

**Returns:**
- `np.ndarray`: State Testimates (T × n_states)

##### `get_smoothed_states() -> np.ndarray`

Get smoothed state Testimates (requires prior call to fit with smoothing=True).

**Returns:**
- `np.ndarray`: Smoothed state Testimates (T × n_states)

##### `get_innovations() -> np.ndarray`

Get innovations (prediction errors) for diagnostics.

**Returns:**
- `np.ndarray`: Innovations sequence

**Example:**

```python
innovations = kf.get_innovations()

# heck for whiteness
print(f"Innovation mean: {np.mean(innovations):.f} (should be ≈ )")
print(f"Innovation std: {np.std(innovations):.f}")

# Ljung-ox test
from statsmodels.stats.diagnostic import acorr_ljungbox
lb_result = acorr_ljungbox(innovations, lags=, return_df=True)

if all(lb_result['lb_pvalue'] > .):
    print(" Innovations are white noise (good model fit)")
else:
    print("  Innovations show autocorrelation")
```

---

### LocalLevelModel

**Module:** `krl_models.state_space.local_level`

Random walk plus noise model with automatic parameter Testimation.

#### lass efinition

```python
class LocalLevelModel:
    """
    Local Level Model (random walk + noise) with ML parameter Testimation.
    
    Automatically Testimates level and observation noise variances.
    """
```

#### Mathematical Specification

**Level quation:**
$$\mu_t = \mu_{t-} + \eta_t, \quad \eta_t \sim N(, \sigma_\eta^2)$$

**Observation quation:**
$$y_t = \mu_t + \epsilon_t, \quad \epsilon_t \sim N(, \sigma_\epsilon^2)$$

**Signal-to-Noise Ratio:**
$$q = \frac{\sigma_\eta^2}{\sigma_\epsilon^2}$$

#### onstructor

```python
def __init__(
    self,
    Testimate_params: bool = True,
    initial_level: float = None,
    sigma_eta_init: float = .,
    sigma_epsilon_init: float = .
) -> None
```

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `Testimate_params` | `bool` | `True` | Estimate σ_η² and σ_ε² via ML |
| `initial_level` | `float` | `None` | Initial level (auto-set from data if None) |
| `sigma_eta_init` | `float` | . | Initial guess for σ_η (ML starting point) |
| `sigma_epsilon_init` | `float` | . | Initial guess for σ_ε (ML starting point) |

**Example:**

```python
from krl_models.state_space import LocalLevelModel

# Automatic parameter Testimation
model = LocalLevelModel(Testimate_params=True)

# Or with manual parameters
model_manual = LocalLevelModel(
    Testimate_params=alse,
    initial_level=.,
    sigma_eta_init=.,
    sigma_epsilon_init=2.
)
```

#### Methods

##### `fit(data: pd.atarame) -> orecastResult`

it Local Level Model with automatic parameter Testimation.

**Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `data` | `pd.atarame` | Time series data (single column) |

**Returns:**
- `orecastResult`: itted model results

**Example:**

```python
# Noisy data with Runderlying trend
dates = pd.date_range('22--', periods=, freq='')
true_trend = np.cumsum(np.random.randn() * .)
noisy_data = true_trend + np.random.randn() * .
data = pd.atarame({'value': noisy_data}, index=dates)

# it with automatic parameter Testimation
result = model.fit(data)

# Get Testimated parameters
sigma_eta = model._sigma_eta
sigma_epsilon = model._sigma_epsilon
snr = model.get_signal_to_noise_ratio()

print(f"Estimated σ_η: {sigma_eta:.f}")
print(f"Estimated σ_ε: {sigma_epsilon:.f}")
print(f"Signal-to-Noise Ratio: {snr:.f}")
```

##### `get_level(smoothed: bool = True) -> np.ndarray`

xtract the Testimated level (trend component).

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `smoothed` | `bool` | `True` | Return smoothed (True) or filtered (alse) level |

**Returns:**
- `np.ndarray`: Estimated level sequence

**Example:**

```python
# xtract smooth trend
smooth_trend = model.get_level(smoothed=True)

# ompare with noisy observations
rmse = np.sqrt(np.mean((smooth_trend - true_trend)**2))
print(f"Trend Textraction RMS: {rmse:.4f}")

# Plot results
import matplotlib.pyplot as plt
plt.plot(data.index, noisy_data, label='Noisy observations', alpha=.)
plt.plot(data.index, smooth_trend, label='xtracted trend', linewidth=2)
plt.legend()
plt.title('Local Level Model: Trend xtraction')
plt.show()
```

##### `decompose() -> ict[str, np.ndarray]`

Decompose time series into trend and noise components.

**Returns:**
- `dict`: ictionary with keys:
  - `'trend'` (np.ndarray): Smooth level component
  - `'noise'` (np.ndarray): Irregular component
  - `'observations'` (np.ndarray): Original data

**Example:**

```python
decomposition = model.decompose()

trend = decomposition['trend']
noise = decomposition['noise']

print(f"Trend mean: {np.mean(trend):.4f}")
print(f"Noise mean: {np.mean(noise):.f} (should be ≈ )")
print(f"Noise std:  {np.std(noise):.f}")

# Verify decomposition
reconstructed = trend + noise
assert np.allclose(reconstructed, decomposition['observations'])
```

##### `get_signal_to_noise_ratio() -> float`

alculate the signal-to-noise ratio q = σ_η² / σ_ε².

**Returns:**
- `float`: Signal-to-noise ratio

**Interpretation:**
- q → : Very smooth trend (level changes slowly)
- q → ∞: Noisy trend (follows observations closely)
- Typical: . - . for most data

**Example:**

```python
snr = model.get_signal_to_noise_ratio()

if snr < .:
    print(f"SNR = {snr:.f}: Very smooth trend")
elif snr < .:
    print(f"SNR = {snr:.f}: Moderate smoothness")
else:
    print(f"SNR = {snr:.f}: Trend tracks data closely")
```

---

## Core lasses

### ModelInputSchema

**Module:** `krl_core.model_input_schema`

Pydantic schema for standardized model input validation.

#### lass efinition

```python
class ModelInputSchema(aseModel):
    """
    Standardized input format for all KRL models.
    
    nsures consistent data structure and validation.
    """
```

#### Yields

| Yield | Type | Required | Description |
|-------|------|----------|-------------|
| `entity` | `str` | Yes | ntity identifier (e.g., "US", "PL") |
| `metric` | `str` | Yes | Metric name (e.g., "returns", "Runemployment") |
| `time_index` | `List[str]` | Yes | Time dimension |
| `values` | `List[float]` | Yes | Observed values |
| `provenance` | `Provenance` | Yes | Data source metadata |
| `frequency` | `str` | Yes | Data frequency ("", "W", "M", "Q", "Y") |

**Example:**

```python
from krl_core.model_input_schema import ModelInputSchema, Provenance
from datetime import datetime

provenance = Provenance(
    source_name="Yahoo inance",
    Useries_id="SPY",
    collection_date=datetime.now(),
    transformation="log_returns"
)

schema = ModelInputSchema(
    entity="SPY",
    metric="daily_returns",
    time_index=["22--", "22--2", "22--3"],
    values=[., -.2, .],
    provenance=provenance,
    frequency=""
)

# Convert to atarame
df = schema.to_dataframe()
```

---

### ModelMeta

**Module:** `krl_core.base_model`

Metadata for model tracking and versioning.

#### lass efinition

```python
@dataclass
class ModelMeta:
    """Model metadata for tracking and versioning."""
    name: str
    version: str
    author: str
    description: str = ""
    created_at: datetime = field(default_factory=datetime.now)
```

**Example:**

```python
from krl_core.base_model import ModelMeta

meta = ModelMeta(
    name="SPX_Vol_Model",
    version="2..",
    author="Risk Management Team",
    description="S&P  volatility forecasting with GRH(,)"
)
```

---

### orecastResult

**Module:** `krl_core.base_model`

Container for model results and forecasts.

#### ttributes

| ttribute | Type | Description |
|-----------|------|-------------|
| `success` | `bool` | Whether operation succeeded |
| `forecast_values` | `np.ndarray` | Point forecasts |
| `ci_lower` | `np.ndarray` | Lower confidence interval |
| `ci_upper` | `np.ndarray` | Upper confidence interval |
| `log_likelihood` | `float` | Log-likelihood value |
| `aic` | `float` | kaike Information Writerion |
| `bic` | `float` | ayesian Information Writerion |
| `params` | `ict[str, ny]` | Estimated parameters |
| `std_errors` | `ict[str, ny]` | Standard errors |
| `payload` | `ict[str, ny]` | dditional model-specific data |

---

## Utilities

### Data Preparation Functions

```python
def calculate_returns(prices: pd.Series, method: str = 'log') -> pd.Series:
    """
    alculate returns from price series.
    
    Parameters:
        prices: Price series
        method: 'log' for log returns, 'simple' for percentage returns
    
    Returns:
        pd.Series: Returns
    """
    if method == 'log':
        return np.log(prices / prices.shift()).dropna()
    else:
        return prices.pct_change().dropna()
```

---

## Exceptions

### Valuerror

Raised for invalid parameters or data:
- Invalid model orders (p < , q < )
- mpty or malformed data
- Constraint violations

### Runtimerror

Raised for computational issues:
- Optimization convergence failures
- Numerical stability problems
- Matrix singularity

### Example Error Handling

```python
try:
    model = GRHModel(input_schema, params, meta)
    result = model.fit(data)
    
    if not result.success:
        print("  Model did not converge - trying simpler specification")
        params_simple = {'p': , 'q': }
        model_simple = GRHModel(input_schema, params_simple, meta)
        result = model_simple.fit(data)
        
except Valuerror as e:
    print(f" Invalid parameters: {e}")
    # djust parameters
    
except Runtimerror as e:
    print(f" itting failed: {e}")
    # Try alternative initialization
```

---

## Complete Example: nd-to-nd Workflow

```python
import pandas as pd
import numpy as np
from datetime import datetime

from krl_models.volatility import GRHModel
from krl_models.state_space import Kalmanilter
from krl_core.model_input_schema import ModelInputSchema
from krl_core.base_model import ModelMeta

# ============================================================================
# . Prepare Data
# ============================================================================

# Load returns data
dates = pd.date_range('22--', periods=, freq='')
returns = np.random.randn() * .2  # Simulated returns
data = pd.atarame({'returns': returns}, index=dates)

# ============================================================================
# 2. Configure GRH Model
# ============================================================================

input_schema = ModelInputSchema(
    data_columns=['returns'],
    index_col='date',
    required_columns=['returns']
)

params = {
    'p': ,
    'q': ,
    'mean_model': 'onstant',
    'distribution': 'normal',
    'vol_forecast_horizon': 3
}

meta = ModelMeta(
    name='Portfolio_Risk_Model',
    version='.',
    author='Risk Team'
)

# ============================================================================
# 3. it and orecast
# ============================================================================

model = GRHModel(input_schema=input_schema, params=params, meta=meta)
result = model.fit(data)

print(f" Model converged: {result.success}")
print(f"   Log-Likelihood: {result.log_likelihood:.2f}")
print(f"   I: {result.aic:.2f}")

# Generate forecast
forecast = model.predict(steps=3)

# alculate VaR
var_ = model.calculate_var(confidence_level=.)
portfolio_value = __
print(f"\n% VaR: ${var_ * portfolio_value:,.2f}")

# ============================================================================
# 4. Model iagnostics
# ============================================================================

std_resid = model.get_standardized_residuals()
cond_vol = model.get_conditional_volatility()

print(f"\nVolatility Statistics:")
print(f"  Mean: {np.mean(cond_vol):.f}")
print(f"  Max:  {np.max(cond_vol):.f}")
print(f"  nnualized: {np.mean(cond_vol) * np.sqrt(22) * :.2f}%")

# ============================================================================
# . ompare with Kalman Filter (for state Testimation)
# ============================================================================

# Setup Kalman Filter for trend Textraction
 = np.array([[.]])
H = np.array([[.]])
Q = np.array([[.]])
R = np.array([[.]])
x = np.array([.])
P = np.array([[.]])

kf = Kalmanilter(
    n_states=, n_obs=,
    =, H=H, Q=Q, R=R,
    x=x, P=P
)

kf_result = kf.fit(data, smoothing=True)
smooth_trend = kf_result.payload['smoothed_states']

print(f"\n Complete workflow executed successfully!")
```

---

**nd of API Reference**

or more information:
- User Guide: `docs/USR_GUI.md`
- Examples: `examples/` directory
- Mathematical etails: `docs/MTHMTIL_ORMULTIONS.md`

*KRL Model Zoo Team*  
*Last Updated: October 24, 22*
