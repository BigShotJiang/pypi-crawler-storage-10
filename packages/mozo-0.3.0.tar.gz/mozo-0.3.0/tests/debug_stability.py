"""
Debug Stability Inpainting model loading issue.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

print("="*70)
print("Stability Inpainting Debug")
print("="*70)

# Check if diffusers is installed
print("\n1. Checking diffusers installation...")
try:
    import diffusers
    print(f"✓ diffusers installed: {diffusers.__version__}")
except ImportError as e:
    print(f"✗ diffusers not installed: {e}")
    sys.exit(1)

# Check if torch is installed
print("\n2. Checking torch installation...")
try:
    import torch
    print(f"✓ torch installed: {torch.__version__}")
except ImportError as e:
    print(f"✗ torch not installed: {e}")
    sys.exit(1)

# Try to load the model
print("\n3. Loading stability_inpainting/default...")
try:
    from mozo.manager import ModelManager
    manager = ModelManager()
    model = manager.get_model('stability_inpainting', 'default')
    print(f"✓ Model loaded successfully")
    print(f"  Type: {type(model)}")
except Exception as e:
    print(f"✗ Failed to load model: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

print("\n" + "="*70)
print("SUCCESS: Stability Inpainting model works!")
print("="*70)
