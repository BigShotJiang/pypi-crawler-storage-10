"""
Inspect the OCRResult object structure.
"""

import cv2
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from mozo.manager import ModelManager

manager = ModelManager()
model = manager.get_model('paddleocr', 'mobile')

test_image = Path(__file__).parent / 'fixtures' / 'test_document.png'
image = cv2.imread(str(test_image))

print("Getting OCRResult object...")
result_list = model.ocr.predict(image)

print(f"Result list length: {len(result_list)}")

if len(result_list) > 0:
    ocr_result = result_list[0]
    print(f"\nOCRResult object type: {type(ocr_result)}")
    print(f"OCRResult attributes: {dir(ocr_result)}")
    print()

    # Check common attributes
    for attr in ['boxes', 'texts', 'scores', 'dt_polys', 'rec_text', 'rec_score', 'input_path', 'json']:
        if hasattr(ocr_result, attr):
            value = getattr(ocr_result, attr)
            print(f"{attr}: type={type(value)}")
            if isinstance(value, list) and len(value) > 0:
                print(f"  Length: {len(value)}")
                print(f"  First item: {value[0]}")
            elif callable(value):
                try:
                    result = value()
                    print(f"  Callable result: {result}")
                except:
                    print(f"  Callable (couldn't call)")
            else:
                print(f"  Value: {value}")