"""Integration tests for Mozo HTTP endpoints."""
