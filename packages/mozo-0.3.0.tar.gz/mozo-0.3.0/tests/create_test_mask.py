"""
Create a simple test mask for stability_inpainting testing.

White areas in the mask indicate regions to be inpainted.
Mask size matches test_document.png (800x600).
"""

import numpy as np
from PIL import Image
from pathlib import Path

# Get the size of test_document.png to match dimensions
test_image_path = Path(__file__).parent / 'fixtures' / 'test_document.png'
test_image = Image.open(test_image_path)
width, height = test_image.size
print(f"Creating mask to match test_document.png size: {width}x{height}")

# Create a black image matching test document size
mask = np.zeros((height, width), dtype=np.uint8)

# Add a white rectangle in the center (area to be inpainted)
center_y, center_x = height // 2, width // 2
rect_h, rect_w = 150, 200
y1, y2 = center_y - rect_h//2, center_y + rect_h//2
x1, x2 = center_x - rect_w//2, center_x + rect_w//2
mask[y1:y2, x1:x2] = 255

# Save as PNG
output_path = Path(__file__).parent / 'fixtures' / 'test_mask.png'
output_path.parent.mkdir(parents=True, exist_ok=True)

mask_image = Image.fromarray(mask)
mask_image.save(output_path)

print(f"✓ Created test mask: {output_path}")
print(f"  Size: {mask_image.size}")
print(f"  White pixels: {np.sum(mask > 0)}")
