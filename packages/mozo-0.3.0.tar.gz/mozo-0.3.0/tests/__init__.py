"""
Mozo Test Suite

This directory contains tests for the Mozo model server.

Test Structure:
- smoke_test.py: Comprehensive integration test of all models via HTTP
- integration/: HTTP endpoint and model prediction tests
- adapters/: Adapter-specific tests
- fixtures/: Test data (images, etc.)
"""
