"""
Detailed debugging to understand the exact format of OCR results.
"""

import cv2
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from mozo.manager import ModelManager


def debug_easyocr():
    """Debug EasyOCR to understand what to_dict() returns."""
    print("="*70)
    print("EasyOCR Detailed Debug")
    print("="*70)

    manager = ModelManager()
    model = manager.get_model('easyocr', 'english-light')

    test_image = Path(__file__).parent / 'fixtures' / 'test_document.png'
    image = cv2.imread(str(test_image))

    detections = model.predict(image)

    print(f"Type of detections: {type(detections)}")
    print(f"detections object: {detections}")
    print()

    # Check what to_dict() actually returns
    result = detections.to_dict()
    print(f"Type of to_dict() result: {type(result)}")
    print(f"Is it a list? {isinstance(result, list)}")
    print(f"Is it a dict? {isinstance(result, dict)}")
    print()

    if isinstance(result, list):
        print(f"Length: {len(result)}")
        if len(result) > 0:
            print(f"First item type: {type(result[0])}")
            print(f"First item: {result[0]}")
    else:
        print(f"Keys: {result.keys() if hasattr(result, 'keys') else 'N/A'}")


def debug_paddleocr():
    """Debug PaddleOCR to see what format it returns."""
    print("\n" + "="*70)
    print("PaddleOCR Detailed Debug")
    print("="*70)

    manager = ModelManager()
    model = manager.get_model('paddleocr', 'mobile')

    test_image = Path(__file__).parent / 'fixtures' / 'test_document.png'
    image = cv2.imread(str(test_image))

    # Call the OCR directly to see raw results
    print("Calling PaddleOCR.ocr() directly...")
    ocr_output = model.ocr.ocr(image, cls=True)

    print(f"Type of ocr_output: {type(ocr_output)}")
    print(f"Is it a list? {isinstance(ocr_output, list)}")
    print(f"Is it a dict? {isinstance(ocr_output, dict)}")
    print()

    if isinstance(ocr_output, list):
        print(f"Length: {len(ocr_output)}")
        if len(ocr_output) > 0:
            print(f"ocr_output[0] type: {type(ocr_output[0])}")
            print(f"ocr_output[0]: {ocr_output[0]}")
    elif isinstance(ocr_output, dict):
        print(f"Keys: {ocr_output.keys()}")
        for key, value in ocr_output.items():
            print(f"  {key}: {type(value)} = {value[:2] if isinstance(value, list) else value}")


if __name__ == "__main__":
    debug_easyocr()
    debug_paddleocr()