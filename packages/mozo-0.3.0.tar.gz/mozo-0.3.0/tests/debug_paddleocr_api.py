"""
Test to see what the new PaddleOCR API actually returns.
"""

import cv2
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from mozo.manager import ModelManager

manager = ModelManager()
model = manager.get_model('paddleocr', 'mobile')

test_image = Path(__file__).parent / 'fixtures' / 'test_document.png'
image = cv2.imread(str(test_image))

print("Testing PaddleOCR API...")
print(f"Model object type: {type(model.ocr)}")
print(f"Has predict method: {hasattr(model.ocr, 'predict')}")
print(f"Has ocr method: {hasattr(model.ocr, 'ocr')}")
print()

# Try the new predict() method
try:
    print("Calling predict()...")
    result = model.ocr.predict(image)
    print(f"Success! Type: {type(result)}")
    print(f"Is dict: {isinstance(result, dict)}")
    print(f"Is list: {isinstance(result, list)}")

    if isinstance(result, dict):
        print(f"Keys: {result.keys()}")
        for key in result.keys():
            value = result[key]
            print(f"  {key}: type={type(value)}")
            if isinstance(value, (list, dict)):
                print(f"    Length/Keys: {len(value) if isinstance(value, list) else list(value.keys())}")
    elif isinstance(result, list):
        print(f"Length: {len(result)}")
        if len(result) > 0:
            print(f"First element type: {type(result[0])}")

except Exception as e:
    print(f"Error calling predict(): {e}")
    import traceback
    traceback.print_exc()