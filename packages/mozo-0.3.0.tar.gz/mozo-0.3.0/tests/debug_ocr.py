"""
Debug script to reproduce EasyOCR and PaddleOCR JSON serialization issues.

This script tests local prediction and JSON serialization to identify
exactly which fields contain numpy types that can't be serialized.
"""

import cv2
import json
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from mozo.manager import ModelManager


def check_dict_types(obj, path="root"):
    """Recursively check for numpy types in nested dict/list structures."""
    import numpy as np

    if isinstance(obj, dict):
        for key, value in obj.items():
            check_dict_types(value, f"{path}.{key}")
    elif isinstance(obj, list):
        for i, value in enumerate(obj):
            check_dict_types(value, f"{path}[{i}]")
    elif isinstance(obj, (np.integer, np.floating)):
        print(f"  Found numpy type at {path}: {type(obj).__name__} = {obj}")


def test_model(family, variant):
    """Test a model and check for serialization issues."""
    print(f"\n{'='*70}")
    print(f"Testing: {family}/{variant}")
    print('='*70)

    manager = ModelManager()

    try:
        # Load model
        print(f"Loading {family}/{variant}...")
        model = manager.get_model(family, variant)
        print(f"✓ Model loaded successfully")

        # Load test image
        test_image = Path(__file__).parent / 'fixtures' / 'test_document.png'
        if not test_image.exists():
            print(f"✗ Test image not found: {test_image}")
            return False

        image = cv2.imread(str(test_image))
        print(f"✓ Test image loaded: {image.shape}")

        # Run prediction
        print(f"Running prediction...")
        detections = model.predict(image)
        print(f"✓ Prediction complete")
        print(f"  Type: {type(detections)}")
        print(f"  Has to_dict: {hasattr(detections, 'to_dict')}")

        if hasattr(detections, 'to_dict'):
            # Convert to dict
            result_dict = detections.to_dict()
            print(f"✓ Converted to dict")
            print(f"  Keys: {list(result_dict.keys())}")

            # Check for numpy types
            print("\nChecking for numpy types...")
            check_dict_types(result_dict)

            # Try JSON serialization
            print("\nAttempting JSON serialization...")
            try:
                json_str = json.dumps(result_dict)
                print(f"✓ JSON serialization succeeded")
                print(f"  Length: {len(json_str)} bytes")
                return True
            except TypeError as e:
                print(f"✗ JSON serialization failed: {e}")
                return False
        else:
            print(f"✗ Result doesn't have to_dict() method")
            return False

    except Exception as e:
        print(f"✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Test all broken OCR models."""
    print("="*70)
    print("OCR MODELS DEBUG SCRIPT")
    print("="*70)

    models_to_test = [
        # EasyOCR (4 broken)
        ('easyocr', 'english-light'),
        # PaddleOCR (5 broken - test just one for now)
        ('paddleocr', 'mobile'),
    ]

    results = {}
    for family, variant in models_to_test:
        success = test_model(family, variant)
        results[f"{family}/{variant}"] = "✓ PASS" if success else "✗ FAIL"

    # Summary
    print("\n" + "="*70)
    print("SUMMARY")
    print("="*70)
    for model_id, status in results.items():
        print(f"{status} {model_id}")


if __name__ == "__main__":
    main()