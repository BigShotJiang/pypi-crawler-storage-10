"""
Test script for EasyOCR integration in Mozo.

Usage:
    python test_easyocr.py <image_path> [variant]

Examples:
    python test_easyocr.py document.jpg
    python test_easyocr.py receipt.png english-full
    python test_easyocr.py multilingual_doc.jpg multilingual
    python test_easyocr.py document.jpg all
"""

import sys
import cv2
from mozo.manager import ModelManager


def test_easyocr_variant(image_path, variant):
    """
    Test EasyOCR with a specific variant.

    Args:
        image_path: Path to test image
        variant: EasyOCR variant name
    """
    print("="*80)
    print(f"Testing EasyOCR with variant: {variant}")
    print("="*80)
    print()

    # Initialize model manager
    manager = ModelManager()

    # Load model
    print(f"[1] Loading model: easyocr/{variant}...")
    try:
        model = manager.get_model('easyocr', variant)
        print(f"Model loaded successfully.")
    except Exception as e:
        print(f"ERROR: Failed to load model: {e}")
        return False
    print()

    # Load image
    print(f"[2] Loading image: {image_path}...")
    image = cv2.imread(image_path)
    if image is None:
        print(f"ERROR: Could not load image from {image_path}")
        return False
    print(f"Image loaded successfully: {image.shape}")
    print()

    # Run prediction
    print("[3] Running OCR prediction...")
    try:
        detections = model.predict(image)
        print(f"Prediction completed.")
    except Exception as e:
        print(f"ERROR: Prediction failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    print()

    # Display results
    print(f"[4] Results:")
    print(f"Found {len(detections)} text regions")
    print()

    if len(detections) > 0:
        print("Detected text (ordered by position):")
        print("-" * 80)

        # Sort detections by position (top to bottom, left to right)
        sorted_dets = sorted(detections.detections, key=lambda d: (d.bbox[1], d.bbox[0]))

        for idx, det in enumerate(sorted_dets, 1):
            # Get OCR data
            if not det.ocr_data:
                print(f"\n[Region {idx}] No OCR data")
                continue

            ocr = det.ocr_data
            text = ocr.text if ocr.text else "N/A"
            confidence = ocr.confidence if ocr.confidence is not None else 0.0
            bbox = det.bbox if det.bbox else [0, 0, 0, 0]
            language = ocr.language if ocr.language else "unknown"

            # Display
            print(f"\n[Region {idx}]")
            print(f"  Text: {text}")
            print(f"  Confidence: {confidence:.2f}")
            print(f"  BBox: {bbox}")
            print(f"  Language: {language}")

            # Show polygon if available
            if det.segments:
                print(f"  Polygon: {det.segments}")

        print()
        print("-" * 80)

        # Reconstruct full text
        texts = [d.ocr_data.text for d in sorted_dets if d.ocr_data and d.ocr_data.text]
        if texts:
            print("\nReconstructed text:")
            print(" ".join(texts))
            print()

        # Statistics
        valid_dets = [d for d in detections.detections if d.ocr_data and d.ocr_data.confidence is not None]
        avg_confidence = sum(d.ocr_data.confidence for d in valid_dets) / len(valid_dets) if valid_dets else 0.0

        print(f"Statistics:")
        print(f"  Total regions: {len(detections)}")
        print(f"  Average confidence: {avg_confidence:.2f}")
        print(f"  High confidence (>0.8): {sum(1 for d in detections.detections if d.ocr_data and d.ocr_data.confidence and d.ocr_data.confidence > 0.8)}")
        print()

    else:
        print("No text detected in the image.")
        print()

    # Test completed
    print(f"✓ Test completed successfully for variant: {variant}")
    print()

    return True


def main():
    """Main test function."""
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    image_path = sys.argv[1]
    variant = sys.argv[2] if len(sys.argv) > 2 else 'english-light'

    # Test all variants if requested
    if variant == 'all':
        variants = ['english-light', 'english-full', 'multilingual', 'chinese']
        print(f"Testing all variants: {variants}")
        print()

        results = {}
        for v in variants:
            success = test_easyocr_variant(image_path, v)
            results[v] = success

        # Summary
        print("="*80)
        print("SUMMARY")
        print("="*80)
        for v, success in results.items():
            status = "✓ PASS" if success else "✗ FAIL"
            print(f"{v:20s} : {status}")
        print()

    else:
        # Test single variant
        success = test_easyocr_variant(image_path, variant)
        sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
