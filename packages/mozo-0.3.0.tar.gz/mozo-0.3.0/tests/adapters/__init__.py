"""Adapter-specific tests."""
