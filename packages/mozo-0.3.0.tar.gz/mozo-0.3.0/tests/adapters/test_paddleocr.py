"""
Test script for PaddleOCR integration in Mozo.

Before running this script, make sure PaddleOCR is installed:
    pip install paddleocr

Usage:
    python test_paddleocr.py <image_path>

Example:
    python test_paddleocr.py examples/invoice.jpg
"""

import sys
import cv2
from mozo.manager import ModelManager


def test_paddleocr(image_path, variant='mobile'):
    """Test PaddleOCR integration."""

    print(f"Testing PaddleOCR with variant: {variant}")
    print(f"Image: {image_path}\n")

    # Load image
    print("Loading image...")
    image = cv2.imread(image_path)
    if image is None:
        print(f"ERROR: Could not load image from {image_path}")
        return False

    print(f"Image shape: {image.shape}")

    # Initialize ModelManager
    print("\nInitializing ModelManager...")
    manager = ModelManager()

    # Get PaddleOCR model
    print(f"\nLoading PaddleOCR model (variant: {variant})...")
    try:
        model = manager.get_model('paddleocr', variant)
        print("Model loaded successfully!")
    except Exception as e:
        print(f"ERROR loading model: {e}")
        return False

    # Run prediction
    print("\nRunning OCR prediction...")
    try:
        detections = model.predict(image)
        print(f"OCR completed! Found {len(detections)} text regions.\n")
    except Exception as e:
        print(f"ERROR during prediction: {e}")
        return False

    # Display results
    print("=" * 80)
    print("OCR RESULTS")
    print("=" * 80)

    for i, det in enumerate(detections, 1):
        if not det.ocr_data:
            print(f"\n[{i}] No OCR data")
            continue

        ocr = det.ocr_data
        print(f"\n[{i}] Text: {ocr.text}")
        print(f"    Confidence: {ocr.confidence:.4f}")
        print(f"    BBox: {det.bbox}")
        print(f"    Language: {ocr.language}")
        if ocr.angle is not None:
            print(f"    Angle: {ocr.angle:.2f}°")
        if ocr.direction:
            print(f"    Direction: {ocr.direction}")
        if det.segments:
            print(f"    Polygon: {det.segments[:2]}... ({len(det.segments)} points)")

    print("\n" + "=" * 80)

    # Test filtering with OCRData
    print("\nTesting OCRData filtering:")

    # Filter by confidence
    high_conf_dets = [d for d in detections.detections if d.ocr_data and d.ocr_data.confidence > 0.8]
    print(f"  High confidence (>0.8): {len(high_conf_dets)} text regions")

    # Sort by reading order
    sorted_dets = sorted(
        [d for d in detections.detections if d.ocr_data],
        key=lambda d: d.ocr_data.order if d.ocr_data.order is not None else 0
    )
    print(f"  Sorted by reading order: {len(sorted_dets)} text regions")

    # Reconstruct text
    print("\nReconstructed text (in reading order):")
    print("-" * 80)
    full_text = " ".join([d.ocr_data.text for d in sorted_dets if d.ocr_data and d.ocr_data.text])
    print(full_text)
    print("-" * 80)

    return True


def test_all_variants(image_path):
    """Test all PaddleOCR variants."""

    variants = ['mobile', 'mobile-chinese', 'mobile-multilingual']

    print("=" * 80)
    print("TESTING ALL PADDLEOCR VARIANTS")
    print("=" * 80)

    for variant in variants:
        print(f"\n{'=' * 80}")
        print(f"Variant: {variant}")
        print(f"{'=' * 80}")

        success = test_paddleocr(image_path, variant)

        if success:
            print(f"\n✓ {variant} test PASSED")
        else:
            print(f"\n✗ {variant} test FAILED")

        print()


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python test_paddleocr.py <image_path> [variant]")
        print("\nVariants:")
        print("  - mobile (default)")
        print("  - server")
        print("  - mobile-chinese")
        print("  - server-chinese")
        print("  - mobile-multilingual")
        print("\nExamples:")
        print("  python test_paddleocr.py invoice.jpg")
        print("  python test_paddleocr.py document.png server")
        print("  python test_paddleocr.py chinese_doc.jpg mobile-chinese")
        sys.exit(1)

    image_path = sys.argv[1]
    variant = sys.argv[2] if len(sys.argv) > 2 else 'mobile'

    # Test specified variant
    if variant == 'all':
        test_all_variants(image_path)
    else:
        success = test_paddleocr(image_path, variant)
        sys.exit(0 if success else 1)
