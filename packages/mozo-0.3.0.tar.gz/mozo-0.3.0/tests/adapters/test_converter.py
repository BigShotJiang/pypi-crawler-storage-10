"""
Direct test of the PP-Structure converter with mock data.
"""
import sys
sys.path.insert(0, '/Users/nazif/Projects/datamarkin/pixelflow')

# Mock LayoutBlock object structure
class MockLayoutBlock:
    def __init__(self, bbox, label, content_text):
        self.bbox = bbox
        self.label = label
        self.content = content_text  # Direct string content
        self.order_label = 0
        self.seg_start_coordinate = None
        self.seg_end_coordinate = None
        self.width = bbox[2] - bbox[0]
        self.height = bbox[3] - bbox[1]
        self.area = self.width * self.height
        self.num_of_lines = 1
        self.image = None
        self.index = 0
        self.order_index = 0
        self.text_line_width = self.width
        self.text_line_height = self.height
        self.child_blocks = []
        self.direction = 'horizontal'
        self.secondary_direction = None
        self.short_side_length = min(self.width, self.height)
        self.long_side_length = max(self.width, self.height)
        self.start_coordinate = (bbox[0], bbox[1])
        self.end_coordinate = (bbox[2], bbox[3])
        self.secondary_direction_start_coordinate = None
        self.secondary_direction_end_coordinate = None

# Create mock parsing_res_list
mock_parsing_res_list = [
    MockLayoutBlock(
        bbox=[219, 125, 562, 228],
        label='doc_title',
        content_text='Document Title Here'
    ),
    MockLayoutBlock(
        bbox=[100, 250, 500, 350],
        label='abstract',
        content_text='This is the abstract text with important information.'
    ),
    MockLayoutBlock(
        bbox=[100, 400, 500, 600],
        label='text',
        content_text='This is the main body text of the document.'
    ),
    MockLayoutBlock(
        bbox=[100, 650, 500, 800],
        label='text',
        content_text='This is more body text in a second paragraph.'
    ),
]

# Test the converter
print("Testing PP-Structure converter with mock data...")
print(f"Mock data has {len(mock_parsing_res_list)} regions")

import pixelflow as pf

detections = pf.detections.Detections()

# Use the private converter function
from pixelflow.detections.converters import _convert_from_parsing_res_list

detections = _convert_from_parsing_res_list(
    parsing_res_list=mock_parsing_res_list,
    language='en',
    page_index=0,
    detections_obj=detections
)

print(f"\nConverted {len(detections.detections)} detections")

# Print results
for idx, det in enumerate(detections.detections):
    print(f"\n=== Detection {idx} ===")
    print(f"BBox: {det.bbox}")
    if det.ocr_data:
        print(f"Element Type: {det.ocr_data.element_type}")
        print(f"Text: {det.ocr_data.text}")
        print(f"Confidence: {det.ocr_data.confidence}")
        print(f"Language: {det.ocr_data.language}")
        print(f"Order: {det.ocr_data.order}")
    else:
        print("No OCR data")
