#!/usr/bin/env python3
"""
Test script for PP-StructureV3 document analysis integration in Mozo.

This script demonstrates:
- Loading PP-StructureV3 models with different variants
- Running document structure analysis on images
- Accessing layout regions, tables, and formulas
- Using PixelFlow filters for document element processing

Usage:
    python test_ppstructure.py <image_path> [variant]

Examples:
    python test_ppstructure.py document.pdf
    python test_ppstructure.py invoice.png full
    python test_ppstructure.py research_paper.jpg formula-analysis
    python test_ppstructure.py spreadsheet.png table-analysis
    python test_ppstructure.py document.pdf all  # Test all variants
"""

import sys
import cv2
from mozo.manager import ModelManager


def test_ppstructure(image_path, variant='full'):
    """
    Test PP-StructureV3 document analysis with specified variant.

    Args:
        image_path: Path to the document image
        variant: Model variant ('layout-only', 'full', 'table-analysis', 'formula-analysis')
    """
    print("="*80)
    print(f"Testing PP-StructureV3 with variant: {variant}")
    print("="*80)

    # Initialize ModelManager
    manager = ModelManager()

    # Load the model
    print(f"\n[1] Loading model: ppstructure/{variant}...")
    model = manager.get_model('ppstructure', variant)

    # Load image
    print(f"\n[2] Loading image: {image_path}...")
    image = cv2.imread(image_path)
    if image is None:
        print(f"ERROR: Could not load image from {image_path}")
        return
    print(f"Image loaded: {image.shape[1]}x{image.shape[0]} pixels")

    # Run document structure analysis
    print(f"\n[3] Running PP-StructureV3 prediction...")
    detections = model.predict(image)

    # Print summary
    print(f"\n[4] Detection Summary:")
    print(f"Total regions detected: {len(detections)}")

    # Count by element type
    element_types = {}
    for det in detections.detections:
        if det.ocr_data and det.ocr_data.element_type:
            elem_type = det.ocr_data.element_type
            element_types[elem_type] = element_types.get(elem_type, 0) + 1

    print("\nDocument structure:")
    for elem_type, count in sorted(element_types.items()):
        print(f"  - {elem_type}: {count} region(s)")

    # Print detailed results
    print(f"\n[5] Detailed Results:")
    print("-" * 80)

    for idx, det in enumerate(detections.detections, 1):
        if not det.ocr_data:
            continue

        ocr_data = det.ocr_data
        elem_type = ocr_data.element_type or 'unknown'
        bbox = det.bbox

        print(f"\nRegion {idx}: {elem_type.upper()}")
        print(f"  BBox: {bbox}")
        print(f"  Confidence: {ocr_data.confidence:.3f}")

        # Print text content
        if ocr_data.text and len(ocr_data.text) > 0:
            text_preview = ocr_data.text[:100]
            if len(ocr_data.text) > 100:
                text_preview += "..."
            print(f"  Text: {text_preview}")

        # Print table HTML
        if ocr_data.table_html:
            html_preview = ocr_data.table_html[:150]
            if len(ocr_data.table_html) > 150:
                html_preview += "..."
            print(f"  Table HTML: {html_preview}")

        # Print formula LaTeX
        if ocr_data.formula_latex:
            print(f"  Formula: {ocr_data.formula_latex}")

    # Demonstrate PixelFlow filtering
    print(f"\n[6] PixelFlow Filtering Examples:")
    print("-" * 80)

    # Filter by element type
    text_regions = [d for d in detections.detections if d.ocr_data and d.ocr_data.element_type == 'text']
    tables = [d for d in detections.detections if d.ocr_data and d.ocr_data.element_type == 'table']
    formulas = [d for d in detections.detections if d.ocr_data and d.ocr_data.element_type == 'formula']

    print(f"Text regions: {len(text_regions)}")
    print(f"Tables: {len(tables)}")
    print(f"Formulas: {len(formulas)}")

    # Print table details
    if tables:
        print(f"\nTable Details:")
        for idx, table in enumerate(tables, 1):
            if table.ocr_data and table.ocr_data.table_html:
                html_len = len(table.ocr_data.table_html)
                print(f"  Table {idx}: HTML length = {html_len} chars")

    # Print formula details
    if formulas:
        print(f"\nFormula Details:")
        for idx, formula in enumerate(formulas, 1):
            if formula.ocr_data and formula.ocr_data.formula_latex:
                print(f"  Formula {idx}: {formula.ocr_data.formula_latex}")

    print("\n" + "="*80)
    print("PP-StructureV3 test completed successfully!")
    print("="*80)


def test_all_variants(image_path):
    """Test all PP-StructureV3 variants on the same image."""
    variants = ['layout-only', 'full', 'table-analysis', 'formula-analysis']

    print("\n" + "="*80)
    print("Testing ALL PP-StructureV3 Variants")
    print("="*80)

    for variant in variants:
        try:
            test_ppstructure(image_path, variant)
            print("\n")
        except Exception as e:
            print(f"\nERROR testing variant '{variant}': {e}")
            import traceback
            traceback.print_exc()

    print("\n" + "="*80)
    print(f"Tested {len(variants)} variants")
    print("="*80)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python test_ppstructure.py <image_path> [variant]")
        print("\nVariants:")
        print("  layout-only       - Layout detection only (fast)")
        print("  full              - Full analysis with tables and formulas (default)")
        print("  table-analysis    - Focus on table recognition")
        print("  formula-analysis  - Focus on formula extraction")
        print("  all               - Test all variants")
        print("\nExamples:")
        print("  python test_ppstructure.py document.pdf")
        print("  python test_ppstructure.py invoice.png full")
        print("  python test_ppstructure.py paper.jpg formula-analysis")
        print("  python test_ppstructure.py document.pdf all")
        sys.exit(1)

    image_path = sys.argv[1]
    variant = sys.argv[2] if len(sys.argv) > 2 else 'full'

    try:
        if variant == 'all':
            test_all_variants(image_path)
        else:
            test_ppstructure(image_path, variant)
    except Exception as e:
        print(f"\nERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
