# @author beyza yildirim
import random
import string
import hashlib

def password_generator(password_len,hash_type,is_digit,is_letter_l,is_letter_u,is_symbol):

   # is_digit = False
   # is_letter_l = True
   # is_letter_u = True
   # is_symbol = True
    is_choice = [is_digit, is_letter_l, is_letter_u, is_symbol]
    symbol = string.punctuation
    letter_l = string.ascii_lowercase
    letter_u = string.ascii_uppercase
    digit = string.digits
    choice = []
    if is_choice[0]:
        choice.append(digit)
    if is_choice[1]:
        choice.append(letter_l)
    if is_choice[2]:
        choice.append(letter_u)
    if is_choice[3]:
        choice.append(symbol)


    if not is_choice:
        raise ValueError("En az bir karakter türü seçilmelidir.")

    password = []
    x=int(password_len)//4
    y = int(password_len)%4
    #print(password_len,x,y)
    #print(choice)
    for i in choice:
     password.extend(random.choices(i,k=x))

    password.extend(random.choices(choice[0],k=y))
    random.shuffle(password)
    random.shuffle(password)
    password = "".join(password)

    if hash_type.lower() == "sha256":
        hashed = hashlib.sha256(password.encode()).hexdigest()
    else:
        hashed = hashlib.md5(password.encode()).hexdigest()
    return password, hashed
