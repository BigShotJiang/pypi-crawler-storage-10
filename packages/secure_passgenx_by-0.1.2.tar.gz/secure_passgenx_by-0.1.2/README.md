# secure_passgen

Basit bir Python şifre üretici ve hash hesaplayıcı kütüphanedir

## Kullanım
```python
   """ def password_generator(password_len,hash_type,is_digit,is_letter_l,is_letter_u,is_symbol):
    
       # is_digit = False
       # is_letter_l = True
       # is_letter_u = True
       # is_symbol = True"""
from secure_passgen import password_generator
password, hash_value = password_generator(12, "sha256", True, True, True, True)
print(password)
print(hash_value)
