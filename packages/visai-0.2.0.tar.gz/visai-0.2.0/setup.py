from setuptools import setup, find_packages
from pathlib import Path

# Safely read README.md
readme = Path(__file__).parent / "README.md"
if readme.exists():
    long_desc = readme.read_text(encoding="utf-8")
else:
    long_desc = "Simple ML visualization helpers"

setup(
    name="VisAI",
    version="0.2.0",
    author="Anjum",
    description="Simple ML visualization helpers",
    long_description=long_desc,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "numpy>=1.24",
        "pandas>=2.0",
        "matplotlib>=3.8",
        "scikit-learn>=1.3",
        "seaborn"
    ],
    python_requires=">=3.8",
)
