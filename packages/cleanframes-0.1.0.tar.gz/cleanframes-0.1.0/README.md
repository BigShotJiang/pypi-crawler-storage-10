# CleanFrames

CleanFrames is a professional tool for removing duplicate or near-duplicate image frames using:
- MD5 (byte-level duplicates)
- Perceptual hashing (visual similarity)
- Deep embeddings (semantic redundancy)

## Installation

```bash
pip install cleanframes
```

## Usage
```
from clean_frames import CleanFrame

cleaner = CleanFrame(device='mps')
embeddings, paths = cleaner.SwinEmbedding("path/to/images")
cleaner.cleanframes(paths, embeddings_list=[("swin", embeddings)], threshold=0.95)
```