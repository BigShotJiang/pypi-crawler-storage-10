"""
Logging configuration for Azure Durable Agent Function App

This module provides proper logging setup for Azure Functions environment.
Azure Functions has its own logging infrastructure, so we need to configure
our loggers to work properly with it.
"""

import logging
from typing import Optional


def setup_logging(
    level: int = logging.INFO,
    format_string: Optional[str] = None,
    logger_name: str = "durableagent"
) -> logging.Logger:
    """
    Configure logging for the durable agent function app.

    This function sets up logging to work properly with Azure Functions Core Tools
    and Azure Functions runtime. It ensures logs are visible in both local development
    and when deployed to Azure.

    Args:
        level: Logging level (default: logging.INFO)
        format_string: Optional custom format string for log messages
        logger_name: Name of the logger to configure (default: "durableagent")

    Returns:
        Configured logger instance

    Usage:
        ```python
        from durableagent.logging_config import setup_logging

        # At module level or app initialization
        logger = setup_logging()

        # Or with custom settings
        logger = setup_logging(
            level=logging.DEBUG,
            format_string='[%(levelname)s] %(name)s: %(message)s'
        )
        ```
    """
    if format_string is None:
        format_string = '[%(asctime)s] [%(name)s] %(levelname)s: %(message)s'

    # Configure the root logger so that all module loggers share the same handler
    root_logger = logging.getLogger()
    root_logger.setLevel(level)

    # Reuse the handlers configured by the host (Azure Functions adds its own).
    for existing_handler in root_logger.handlers:
        existing_handler.setLevel(level)

    # Configure the requested logger to rely on the shared handler
    logger = logging.getLogger(logger_name)
    logger.setLevel(level)
    if logger.handlers:
        logger.handlers.clear()
    logger.propagate = True

    return logger


def configure_module_loggers(level: int = logging.INFO) -> None:
    """
    Configure loggers for all durableagent modules.

    This ensures consistent logging across all modules in the package.

    Args:
        level: Logging level to set for all modules
    """
    module_names = [
        "durableagent",
        "durableagent.app",
        "durableagent.entities",
        "durableagent.models",
    ]

    for module_name in module_names:
        logger = logging.getLogger(module_name)
        logger.setLevel(level)

        # Ensure module loggers rely on the shared root handler
        if logger.handlers:
            logger.handlers.clear()
        logger.propagate = True


# Initialize logging when module is imported
_root_logger = setup_logging()
