"""
Data models for Durable Agent Framework

This module defines the request and response models used by the framework.
"""

from dataclasses import dataclass
from importlib import import_module
import inspect
from typing import Optional, Dict, Any, TYPE_CHECKING, Type
from enum import Enum
import uuid
import azure.durable_functions as df

if TYPE_CHECKING:  # pragma: no cover - type checking imports only
    from pydantic import BaseModel

_PydanticBaseModel: Optional[Type["BaseModel"]]
try:
    from pydantic import BaseModel as _RuntimeBaseModel
except ImportError:  # pragma: no cover - optional dependency
    _PydanticBaseModel = None
else:
    _PydanticBaseModel = _RuntimeBaseModel


class ChatRole(str, Enum):
    """Chat message role enum"""
    USER = "user"
    SYSTEM = "system"
    ASSISTANT = "assistant"


@dataclass
class AgentSessionId:
    """
    Represents an agent session ID, which is used to identify a long-running agent session.

    Attributes:
        name: The name of the agent that owns the session (case-insensitive)
        key: The unique key of the agent session (case-sensitive)
    """
    name: str
    key: str

    ENTITY_NAME_PREFIX: str = "dafx-"

    @staticmethod
    def to_entity_name(name: str) -> str:
        """
        Converts an agent name to an entity name by adding the DAFx prefix.

        Args:
            name: The agent name

        Returns:
            The entity name with the dafx- prefix
        """
        return f"{AgentSessionId.ENTITY_NAME_PREFIX}{name}"

    @staticmethod
    def with_random_key(name: str) -> "AgentSessionId":
        """
        Creates a new AgentSessionId with the specified name and a randomly generated key.

        Args:
            name: The name of the agent that owns the session

        Returns:
            A new AgentSessionId with the specified name and a random GUID key
        """
        return AgentSessionId(name=name, key=uuid.uuid4().hex)

    def to_entity_id(self) -> df.EntityId:
        """
        Converts this AgentSessionId to a Durable Functions EntityId.

        Returns:
            EntityId for use with Durable Functions APIs
        """
        return df.EntityId(self.to_entity_name(self.name), self.key)

    @staticmethod
    def from_entity_id(entity_id: df.EntityId) -> "AgentSessionId":
        """
        Creates an AgentSessionId from a Durable Functions EntityId.

        Args:
            entity_id: The EntityId to convert

        Returns:
            AgentSessionId instance

        Raises:
            ValueError: If the entity ID does not have the expected prefix
        """
        if not entity_id.name.startswith(AgentSessionId.ENTITY_NAME_PREFIX):
            raise ValueError(
                f"'{entity_id}' is not a valid agent session ID. "
                f"Expected entity name to start with '{AgentSessionId.ENTITY_NAME_PREFIX}'"
            )

        agent_name = entity_id.name[len(AgentSessionId.ENTITY_NAME_PREFIX):]
        return AgentSessionId(name=agent_name, key=entity_id.key)

    def __str__(self) -> str:
        """Returns a string representation in the form @name@key"""
        return f"@{self.name}@{self.key}"

    def __repr__(self) -> str:
        """Returns a detailed string representation"""
        return f"AgentSessionId(name='{self.name}', key='{self.key}')"

    @staticmethod
    def parse(session_id_string: str) -> "AgentSessionId":
        """
        Parses a string representation of an agent session ID.

        Args:
            session_id_string: A string in the form @name@key

        Returns:
            AgentSessionId instance

        Raises:
            ValueError: If the string format is invalid
        """
        if not session_id_string.startswith("@"):
            raise ValueError(f"Invalid agent session ID format: {session_id_string}")

        parts = session_id_string[1:].split("@", 1)
        if len(parts) != 2:
            raise ValueError(f"Invalid agent session ID format: {session_id_string}")

        return AgentSessionId(name=parts[0], key=parts[1])


def _serialize_response_format(response_format: Optional[Type["BaseModel"]]) -> Any:
    """Serialize response format for transport across durable function boundaries."""

    if response_format is None:
        return None

    if _PydanticBaseModel is None:
        raise RuntimeError("pydantic is required to use structured response formats")

    if not inspect.isclass(response_format) or not issubclass(response_format, _PydanticBaseModel):
        raise TypeError("response_format must be a Pydantic BaseModel type")

    return {
        "__response_schema_type__": "pydantic_model",
        "module": response_format.__module__,
        "qualname": response_format.__qualname__,
    }


def _deserialize_response_format(response_format: Any) -> Optional[Type["BaseModel"]]:
    """Deserialize response format back into actionable type if possible."""

    if response_format is None:
        return None

    if (
        _PydanticBaseModel is not None
        and inspect.isclass(response_format)
        and issubclass(response_format, _PydanticBaseModel)
    ):
        return response_format

    if not isinstance(response_format, dict):
        return None

    if response_format.get("__response_schema_type__") != "pydantic_model":
        return None

    module_name = response_format.get("module")
    qualname = response_format.get("qualname")
    if not module_name or not qualname:
        return None

    try:
        module = import_module(module_name)
    except ImportError:  # pragma: no cover - user provided module missing
        return None

    attr: Any = module
    for part in qualname.split("."):
        try:
            attr = getattr(attr, part)
        except AttributeError:  # pragma: no cover - invalid qualname
            return None

    if _PydanticBaseModel is not None and inspect.isclass(attr) and issubclass(attr, _PydanticBaseModel):
        return attr

    return None


@dataclass
class RunRequest:
    """
    Represents a request to run an agent with a specific message and configuration.

    Attributes:
        message: The message to send to the agent
        role: The role of the message sender (user, system, or assistant)
        response_format: Optional Pydantic BaseModel type describing the structured response format
        enable_tool_calls: Whether to enable tool calls for this request
        conversation_id: Optional conversation/session ID for tracking
        correlation_id: Optional correlation ID for tracking the response to this specific request
    """
    message: str
    role: Optional[ChatRole] = ChatRole.USER
    response_format: Optional[Type["BaseModel"]] = None
    enable_tool_calls: bool = True
    conversation_id: Optional[str] = None
    correlation_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        result = {
            "message": self.message,
            "enable_tool_calls": self.enable_tool_calls,
        }
        if self.role:
            result["role"] = self.role.value if isinstance(self.role, ChatRole) else self.role
        if self.response_format:
            result["response_format"] = _serialize_response_format(self.response_format)
        if self.conversation_id:
            result["conversation_id"] = self.conversation_id
        if self.correlation_id:
            result["correlation_id"] = self.correlation_id
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RunRequest":
        """Create RunRequest from dictionary"""
        role_str = data.get("role")
        if role_str:
            try:
                role = ChatRole(role_str.lower())
            except ValueError:
                role = ChatRole.USER  # Default to USER if invalid
        else:
            role = ChatRole.USER

        return cls(
            message=data.get("message", ""),
            role=role,
            response_format=_deserialize_response_format(data.get("response_format")),
            enable_tool_calls=data.get("enable_tool_calls", True),
            conversation_id=data.get("conversation_id"),
            correlation_id=data.get("correlation_id"),
        )


@dataclass
class AgentResponse:
    """
    Response from agent execution.

    Attributes:
        response: The agent's text response (or None for structured responses)
        message: The original message sent to the agent
        conversation_id: The conversation/session ID
        status: Status of the execution (success, error, etc.)
        message_count: Number of messages in the conversation
        error: Error message if status is error
        error_type: Type of error if status is error
        structured_response: Structured response if response_format was provided
    """
    response: Optional[str]
    message: str
    conversation_id: Optional[str]
    status: str
    message_count: int = 0
    error: Optional[str] = None
    error_type: Optional[str] = None
    structured_response: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        result = {
            "message": self.message,
            "conversation_id": self.conversation_id,
            "status": self.status,
            "message_count": self.message_count,
        }

        # Add response or structured_response based on what's available
        if self.structured_response is not None:
            result["structured_response"] = self.structured_response  # type: ignore[assignment]
        elif self.response is not None:
            result["response"] = self.response

        if self.error:
            result["error"] = self.error
        if self.error_type:
            result["error_type"] = self.error_type

        return result
