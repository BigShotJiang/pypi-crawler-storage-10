def main():
    print("Hello from mithra!")


if __name__ == "__main__":
    main()
