# This needs to be inside the package because hexdoc isn't a book, so we won't
# necessarily be importing everything from here. We explicitly want to reexport all of
# these resources.
