# -*- coding: utf-8 -*-
'''
  pypos3d.pftk intends to be a highlevel library for:
  - Poser Files 

  Requires : pypos3d.wftk, xlrd, numpy, scipy.spatial
'''
__version__ = '2.2.0'
__author__  = 'Olivier DUFAILLY'
__license__ = 'BSD'
