"""Tests for :mod:`bioontologies`."""
