cat > README.md << 'EOF'
# Sayi

A Vue.js-like framework for Python. Complete ecosystem installer.

## Installation

```bash
pip install sayi