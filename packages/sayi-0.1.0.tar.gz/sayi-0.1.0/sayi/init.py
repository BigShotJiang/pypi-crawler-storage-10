"""
Sayi - A Vue.js-like framework for Python
Complete ecosystem installer and main package.
"""

__version__ = "0.1.0"
__author__ = "gedeon kayembe"
__email__ = "hello@sayi.dev"

# Re-export main exports from core packages for convenience
try:
    from sayi_core import (
        create_app,
        ref,
        reactive, 
        computed,
        watch,
        Component
    )
except ImportError:
    # This allows the package to be installed even if dependencies aren't available yet
    # The actual imports will work when all packages are installed
    pass

__all__ = [
    'create_app',
    'ref', 
    'reactive',
    'computed', 
    'watch',
    'Component'
]