from setuptools import setup, find_packages
import os

# Gestion robuste de la lecture du README
def get_long_description():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    readme_path = os.path.join(current_dir, "README.md")
    
    if os.path.exists(readme_path):
        try:
            with open(readme_path, "r", encoding="utf-8") as fh:
                return fh.read()
        except Exception as e:
            print(f"Warning: Could not read README.md: {e}")
    
    return "Sayi - A Vue.js-like framework for Python. Complete ecosystem installer."

setup(
    name="sayi",
    version="0.1.0",
    author="gedeon kayembe",
    author_email="hello@sayi.dev",
    description="Sayi - A Vue.js-like framework for Python. Complete ecosystem installer.",
    long_description=get_long_description(),
    long_description_content_type="text/markdown",
    url="https://github.com/sayijs/sayi",
    
    # Packages
    packages=find_packages(),
    
    # Requirements
    python_requires=">=3.8",
    install_requires=[
        "sayi-core>=0.1.0",
        "sayi-router>=0.1.0",
        "sayi-store>=0.1.0",
        "sayi-axios>=0.1.0",
        "sayi-cli>=0.1.0",
        "sayi-loader>=0.1.0",
    ],
    
    # Optional dependencies
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "isort>=5.12.0",
            "flake8>=6.0.0",
            "twine>=4.0.0",
            "build>=0.10.0",
        ],
        "docs": [
            "sphinx>=7.0.0",
            "sphinx-rtd-theme>=1.3.0",
            "sphinx-autodoc-typehints>=1.25.0",
        ],
        "test": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "pytest-asyncio>=0.21.0",
        ]
    },
    
    # Entry points
    entry_points={
        "console_scripts": [
            "sayi=sayi_cli.cli:main",
            "sayi-create=sayi_cli.cli:main",  # Alias pour compatibilité
        ],
    },
    
    # Classifiers
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Internet :: WWW/HTTP :: Dynamic Content",
        "Topic :: Software Development :: User Interfaces",
        "Framework :: AsyncIO",
        "Typing :: Typed",
    ],
    
    # Keywords
    keywords=[
        "vue", "python", "framework", "frontend", 
        "reactive", "components", "fullstack", "sayi",
        "web", "ui", "javascript", "brython"
    ],
    
    # Include package data
    include_package_data=True,
    
    # Project URLs
    project_urls={
        "Homepage": "https://sayi.dev",
        "Documentation": "https://sayi.dev/docs",
        "Source": "https://github.com/sayijs/sayi",
        "Tracker": "https://github.com/sayijs/sayi/issues",
        "Discord": "https://discord.gg/sayi",
        "Twitter": "https://twitter.com/sayijs",
    },
    
    # License
    license="MIT",
    
    # Platforms
    platforms=["any"],
    
    # Zip safe
    zip_safe=False,
    
    # Package data
    package_data={
        "sayi": ["py.typed"],  # Pour le support Type hints
    },
)