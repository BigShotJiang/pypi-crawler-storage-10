"""
WS Frappe CLI - A command-line tool for Frappe/ERPNext development environment management.

This package provides utilities for setting up, configuring, and managing
Frappe/ERPNext development environments.
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"
__description__ = "A command-line tool for Frappe/ERPNext development environment management"

from .main import main, cli

__all__ = ["main", "cli"]