# CONTRIBUTING

See our organization-level document on [Contributing](https://github.com/mite-standard/.github/blob/main/CONTRIBUTING.md).
