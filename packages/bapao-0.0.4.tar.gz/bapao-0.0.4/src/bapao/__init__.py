"""
BAPAO - Developer Environment Sync Engine

Make your entire development environment portable.
"""

__version__ = "0.1.0"
__author__ = "BAPAO Team"
__email__ = "team@bapao.dev"