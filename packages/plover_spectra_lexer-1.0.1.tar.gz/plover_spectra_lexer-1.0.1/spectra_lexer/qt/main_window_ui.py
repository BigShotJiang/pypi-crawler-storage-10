# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'main_window.ui'
##
## Created by: Qt User Interface Compiler version 6.10.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QFrame,
    QGridLayout, QHBoxLayout, QLabel, QLineEdit,
    QMainWindow, QMenuBar, QSizePolicy, QSlider,
    QTextEdit, QVBoxLayout, QWidget)

from .board import BoardWidget
from .graph import GraphWidget
from .search import SearchListWidget
from .title import TitleWidget

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(580, 470)
        self.w_central = QWidget(MainWindow)
        self.w_central.setObjectName(u"w_central")
        self.lt_central = QGridLayout(self.w_central)
        self.lt_central.setObjectName(u"lt_central")
        self.lt_central.setContentsMargins(6, 6, 6, 6)
        self.w_input = QLineEdit(self.w_central)
        self.w_input.setObjectName(u"w_input")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.w_input.sizePolicy().hasHeightForWidth())
        self.w_input.setSizePolicy(sizePolicy)
        self.w_input.setReadOnly(False)

        self.lt_central.addWidget(self.w_input, 0, 0, 1, 1)

        self.w_matches = SearchListWidget(self.w_central)
        self.w_matches.setObjectName(u"w_matches")
        self.w_matches.setAutoScroll(False)
        self.w_matches.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.w_matches.setProperty(u"showDropIndicator", False)

        self.lt_central.addWidget(self.w_matches, 1, 0, 1, 1)

        self.f_mappings = QFrame(self.w_central)
        self.f_mappings.setObjectName(u"f_mappings")
        sizePolicy.setHeightForWidth(self.f_mappings.sizePolicy().hasHeightForWidth())
        self.f_mappings.setSizePolicy(sizePolicy)
        self.lt_mappings = QVBoxLayout(self.f_mappings)
        self.lt_mappings.setObjectName(u"lt_mappings")
        self.lt_mappings.setContentsMargins(0, 0, 0, 0)
        self.w_mappings = SearchListWidget(self.f_mappings)
        self.w_mappings.setObjectName(u"w_mappings")
        self.w_mappings.setAutoScroll(False)
        self.w_mappings.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.w_mappings.setProperty(u"showDropIndicator", False)

        self.lt_mappings.addWidget(self.w_mappings)

        self.f_options = QFrame(self.f_mappings)
        self.f_options.setObjectName(u"f_options")
        self.lt_options = QHBoxLayout(self.f_options)
        self.lt_options.setObjectName(u"lt_options")
        self.lt_options.setContentsMargins(0, 3, 0, 3)
        self.f_chk = QFrame(self.f_options)
        self.f_chk.setObjectName(u"f_chk")
        self.lt_chk = QVBoxLayout(self.f_chk)
        self.lt_chk.setObjectName(u"lt_chk")
        self.lt_chk.setContentsMargins(0, 0, 0, 0)
        self.w_strokes = QCheckBox(self.f_chk)
        self.w_strokes.setObjectName(u"w_strokes")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.w_strokes.sizePolicy().hasHeightForWidth())
        self.w_strokes.setSizePolicy(sizePolicy1)

        self.lt_chk.addWidget(self.w_strokes)

        self.w_regex = QCheckBox(self.f_chk)
        self.w_regex.setObjectName(u"w_regex")
        sizePolicy1.setHeightForWidth(self.w_regex.sizePolicy().hasHeightForWidth())
        self.w_regex.setSizePolicy(sizePolicy1)

        self.lt_chk.addWidget(self.w_regex)


        self.lt_options.addWidget(self.f_chk)

        self.ln_options = QFrame(self.f_options)
        self.ln_options.setObjectName(u"ln_options")
        self.ln_options.setFrameShape(QFrame.Shape.VLine)
        self.ln_options.setFrameShadow(QFrame.Shadow.Sunken)

        self.lt_options.addWidget(self.ln_options)

        self.f_sl = QFrame(self.f_options)
        self.f_sl.setObjectName(u"f_sl")
        self.lt_sl = QVBoxLayout(self.f_sl)
        self.lt_sl.setObjectName(u"lt_sl")
        self.lt_sl.setContentsMargins(0, 0, 0, 0)
        self.sl0 = QLabel(self.f_sl)
        self.sl0.setObjectName(u"sl0")

        self.lt_sl.addWidget(self.sl0)

        self.sl1 = QLabel(self.f_sl)
        self.sl1.setObjectName(u"sl1")

        self.lt_sl.addWidget(self.sl1)

        self.sl2 = QLabel(self.f_sl)
        self.sl2.setObjectName(u"sl2")

        self.lt_sl.addWidget(self.sl2)


        self.lt_options.addWidget(self.f_sl)

        self.w_slider = QSlider(self.f_options)
        self.w_slider.setObjectName(u"w_slider")
        self.w_slider.setMaximum(2)
        self.w_slider.setValue(2)
        self.w_slider.setOrientation(Qt.Vertical)
        self.w_slider.setInvertedAppearance(True)
        self.w_slider.setTickPosition(QSlider.TicksAbove)

        self.lt_options.addWidget(self.w_slider)


        self.lt_mappings.addWidget(self.f_options)

        self.lt_mappings.setStretch(0, 100)
        self.lt_mappings.setStretch(1, 1)

        self.lt_central.addWidget(self.f_mappings, 2, 0, 1, 1)

        self.w_title = TitleWidget(self.w_central)
        self.w_title.setObjectName(u"w_title")
        sizePolicy.setHeightForWidth(self.w_title.sizePolicy().hasHeightForWidth())
        self.w_title.setSizePolicy(sizePolicy)
        font = QFont()
        font.setFamilies([u"Courier New"])
        font.setPointSize(10)
        self.w_title.setFont(font)

        self.lt_central.addWidget(self.w_title, 0, 1, 1, 1)

        self.w_graph = GraphWidget(self.w_central)
        self.w_graph.setObjectName(u"w_graph")
        sizePolicy.setHeightForWidth(self.w_graph.sizePolicy().hasHeightForWidth())
        self.w_graph.setSizePolicy(sizePolicy)
        self.w_graph.setFont(font)
        self.w_graph.setMouseTracking(True)
        self.w_graph.setFrameShape(QFrame.Box)
        self.w_graph.setFrameShadow(QFrame.Sunken)
        self.w_graph.setUndoRedoEnabled(False)
        self.w_graph.setLineWrapMode(QTextEdit.NoWrap)
        self.w_graph.setOpenLinks(False)

        self.lt_central.addWidget(self.w_graph, 1, 1, 1, 1)

        self.f_info = QFrame(self.w_central)
        self.f_info.setObjectName(u"f_info")
        sizePolicy.setHeightForWidth(self.f_info.sizePolicy().hasHeightForWidth())
        self.f_info.setSizePolicy(sizePolicy)
        self.f_info.setFrameShape(QFrame.Box)
        self.f_info.setFrameShadow(QFrame.Sunken)
        self.lt_info = QGridLayout(self.f_info)
        self.lt_info.setObjectName(u"lt_info")
        self.lt_info.setContentsMargins(6, 6, 6, 6)
        self.lt_info_main = QVBoxLayout()
        self.lt_info_main.setSpacing(2)
        self.lt_info_main.setObjectName(u"lt_info_main")
        self.w_caption = QLabel(self.f_info)
        self.w_caption.setObjectName(u"w_caption")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.w_caption.sizePolicy().hasHeightForWidth())
        self.w_caption.setSizePolicy(sizePolicy2)
        self.w_caption.setMaximumSize(QSize(16777215, 64))
        self.w_caption.setFont(font)
        self.w_caption.setAlignment(Qt.AlignCenter)
        self.w_caption.setWordWrap(True)

        self.lt_info_main.addWidget(self.w_caption)

        self.w_board = BoardWidget(self.f_info)
        self.w_board.setObjectName(u"w_board")
        sizePolicy.setHeightForWidth(self.w_board.sizePolicy().hasHeightForWidth())
        self.w_board.setSizePolicy(sizePolicy)
        self.w_board.setMinimumSize(QSize(200, 100))

        self.lt_info_main.addWidget(self.w_board)


        self.lt_info.addLayout(self.lt_info_main, 0, 0, 2, 1)

        self.lt_info_links = QHBoxLayout()
        self.lt_info_links.setObjectName(u"lt_info_links")
        self.w_link_save = QLabel(self.f_info)
        self.w_link_save.setObjectName(u"w_link_save")
        self.w_link_save.setTextFormat(Qt.RichText)
        self.w_link_save.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.lt_info_links.addWidget(self.w_link_save)

        self.w_link_examples = QLabel(self.f_info)
        self.w_link_examples.setObjectName(u"w_link_examples")
        self.w_link_examples.setTextFormat(Qt.RichText)
        self.w_link_examples.setAlignment(Qt.AlignBottom|Qt.AlignRight|Qt.AlignTrailing)

        self.lt_info_links.addWidget(self.w_link_examples)


        self.lt_info.addLayout(self.lt_info_links, 1, 0, 1, 1)

        self.lt_info.setRowStretch(0, 1)

        self.lt_central.addWidget(self.f_info, 2, 1, 1, 1)

        self.lt_central.setRowStretch(0, 1)
        self.lt_central.setRowStretch(1, 100)
        self.lt_central.setRowStretch(2, 80)
        self.lt_central.setColumnStretch(0, 1)
        self.lt_central.setColumnStretch(1, 100)
        self.lt_central.setColumnMinimumWidth(0, 150)
        self.lt_central.setColumnMinimumWidth(1, 250)
        self.lt_central.setRowMinimumHeight(0, 22)
        self.lt_central.setRowMinimumHeight(1, 150)
        self.lt_central.setRowMinimumHeight(2, 150)
        MainWindow.setCentralWidget(self.w_central)
        self.w_menubar = QMenuBar(MainWindow)
        self.w_menubar.setObjectName(u"w_menubar")
        self.w_menubar.setGeometry(QRect(0, 0, 580, 21))
        MainWindow.setMenuBar(self.w_menubar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"Spectra Lexer", None))
        self.w_input.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Search...", None))
        self.w_strokes.setText(QCoreApplication.translate("MainWindow", u"Stroke Search", None))
        self.w_regex.setText(QCoreApplication.translate("MainWindow", u"Regex Search", None))
        self.sl0.setText(QCoreApplication.translate("MainWindow", u"Key", None))
        self.sl1.setText(QCoreApplication.translate("MainWindow", u"Snd", None))
        self.sl2.setText(QCoreApplication.translate("MainWindow", u"Txt", None))
        self.w_graph.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Search for any word to see its breakdown.", None))
        self.w_link_save.setText(QCoreApplication.translate("MainWindow", u"<a href='dummy'>Save</a>", None))
        self.w_link_examples.setText(QCoreApplication.translate("MainWindow", u"<a href='dummy'>More Examples</a>", None))
    # retranslateUi

