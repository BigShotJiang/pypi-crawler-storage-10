# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'index_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.10.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QDialog, QDialogButtonBox,
    QFrame, QHBoxLayout, QLabel, QSizePolicy,
    QSlider, QVBoxLayout, QWidget)

class Ui_IndexSizeDialog(object):
    def setupUi(self, IndexSizeDialog):
        if not IndexSizeDialog.objectName():
            IndexSizeDialog.setObjectName(u"IndexSizeDialog")
        IndexSizeDialog.setMinimumSize(QSize(360, 250))
        IndexSizeDialog.setMaximumSize(QSize(360, 250))
        self.lt_central = QVBoxLayout(IndexSizeDialog)
        self.lt_central.setSpacing(10)
        self.lt_central.setObjectName(u"lt_central")
        self.heading = QLabel(IndexSizeDialog)
        self.heading.setObjectName(u"heading")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.heading.sizePolicy().hasHeightForWidth())
        self.heading.setSizePolicy(sizePolicy)
        font = QFont()
        font.setBold(True)
        self.heading.setFont(font)
        self.heading.setAlignment(Qt.AlignCenter)
        self.heading.setMargin(2)

        self.lt_central.addWidget(self.heading)

        self.f_size = QFrame(IndexSizeDialog)
        self.f_size.setObjectName(u"f_size")
        sizePolicy.setHeightForWidth(self.f_size.sizePolicy().hasHeightForWidth())
        self.f_size.setSizePolicy(sizePolicy)
        self.f_size.setFrameShape(QFrame.StyledPanel)
        self.f_size.setLineWidth(2)
        self.lt_size = QVBoxLayout(self.f_size)
        self.lt_size.setObjectName(u"lt_size")
        self.w_info = QLabel(self.f_size)
        self.w_info.setObjectName(u"w_info")
        self.w_info.setAlignment(Qt.AlignCenter)

        self.lt_size.addWidget(self.w_info)

        self.w_slider = QSlider(self.f_size)
        self.w_slider.setObjectName(u"w_slider")
        self.w_slider.setMaximum(20)
        self.w_slider.setOrientation(Qt.Horizontal)
        self.w_slider.setTickPosition(QSlider.TicksBelow)
        self.w_slider.setTickInterval(1)

        self.lt_size.addWidget(self.w_slider)

        self.lt_axis = QHBoxLayout()
        self.lt_axis.setObjectName(u"lt_axis")
        self.w_minsize = QLabel(self.f_size)
        self.w_minsize.setObjectName(u"w_minsize")
        self.w_minsize.setFont(font)
        self.w_minsize.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)

        self.lt_axis.addWidget(self.w_minsize)

        self.w_maxsize = QLabel(self.f_size)
        self.w_maxsize.setObjectName(u"w_maxsize")
        self.w_maxsize.setFont(font)
        self.w_maxsize.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.lt_axis.addWidget(self.w_maxsize)


        self.lt_size.addLayout(self.lt_axis)


        self.lt_central.addWidget(self.f_size)

        self.warning = QLabel(IndexSizeDialog)
        self.warning.setObjectName(u"warning")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.warning.sizePolicy().hasHeightForWidth())
        self.warning.setSizePolicy(sizePolicy1)
        self.warning.setAlignment(Qt.AlignBottom|Qt.AlignJustify)
        self.warning.setWordWrap(True)

        self.lt_central.addWidget(self.warning)

        self.buttonBox = QDialogButtonBox(IndexSizeDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setOrientation(Qt.Horizontal)
        self.buttonBox.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)
        self.buttonBox.setCenterButtons(True)

        self.lt_central.addWidget(self.buttonBox)


        self.retranslateUi(IndexSizeDialog)
        self.buttonBox.accepted.connect(IndexSizeDialog.accept)
        self.buttonBox.rejected.connect(IndexSizeDialog.reject)

        QMetaObject.connectSlotsByName(IndexSizeDialog)
    # setupUi

    def retranslateUi(self, IndexSizeDialog):
        IndexSizeDialog.setWindowTitle(QCoreApplication.translate("IndexSizeDialog", u"Choose Index Size", None))
        self.heading.setText(QCoreApplication.translate("IndexSizeDialog", u"Please choose a size for the new index.", None))
        self.w_info.setText(QCoreApplication.translate("IndexSizeDialog", u"[info for selected size]", None))
        self.w_minsize.setText(QCoreApplication.translate("IndexSizeDialog", u"[min]", None))
        self.w_maxsize.setText(QCoreApplication.translate("IndexSizeDialog", u"[max]", None))
        self.warning.setText(QCoreApplication.translate("IndexSizeDialog", u"An extremely large index is not necessarily more useful. The index is created from the Plover dictionary, which is very large (about 150,000 translations) with many useless and even erroneous entries. As the index grows, so does the loading time, and past a certain point the garbage will start to crowd out useful information. Unless you are doing batch analysis, there is little benefit to a maximum-sized index.", None))
    # retranslateUi

