// Redirect any console.log to stderr to maintain JSON-RPC-only stdout
const __origConsoleLog = console.log;
console.log = (...args: any[]) => { try { console.error(...args); } catch {} };


import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  Tool,
} from '@modelcontextprotocol/sdk/types.js';
import * as dotenv from 'dotenv';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { execSync } from 'child_process';
// Using built-in fetch (Node.js 18+) for better compatibility
import FormData from 'form-data';
import * as semver from 'semver';

// Load environment variables with cascade (HOME/.mcp/.env -> project .env)
(function loadEnvCascade(){
  const homeEnv = path.join(os.homedir() || '', '.mcp', '.env');
  const localEnv = path.resolve(process.cwd(), '.env');
  for (const p of [homeEnv, localEnv]) {
    try { if (fs.existsSync(p)) { dotenv.config({ path: p, override: true }); } } catch {}
  }
})();

// Command line argument parsing
const args: string[] = [];
const hasListTools = false;
const hasToolsJson = false;
const hasHelp = false;
const formatTable = false;

// Security: Credential sanitization
function sanitizeCredential(value: string): string {
  if (!value || value.length < 8) return '****';
  return `${value.substring(0, 4)}****...****${value.substring(value.length - 4)}`;
}

function sanitizeEnvVars(env: Record<string, any>): Record<string, any> {
  const sensitiveKeys = ['TOKEN', 'KEY', 'SECRET', 'PASSWORD', 'API_'];
  const sanitized = { ...env };

  Object.keys(sanitized).forEach(key => {
    if (sensitiveKeys.some(sensitive => key.toUpperCase().includes(sensitive))) {
      sanitized[key] = sanitizeCredential(sanitized[key]);
    }
  });

  return sanitized;
}

// Tool discovery and help system
interface ToolInfo {
  name: string;
  category: string;
  description: string;
  requiredParams: string[];
  optionalParams: string[];
  inputSchema: any;
}

function showHelp(): void {
  console.error(`
PyPI JAEGIS MCP Server v1.0.0 - PyPI package management with 8 specialized tools

USAGE:
  pypi-mcp-server [OPTIONS]

OPTIONS:
  --list-tools         List all available tools with descriptions
  --tools-json         Output complete MCP tools schema as JSON
  --format=table       Use table format for tool listings (default: JSON)
  --help, -h          Show this help message

ENVIRONMENT VARIABLES:
  PYPI_TOKEN          PyPI API token (required)
                      Format: pypi-*
                      Generate at: https://pypi.org/manage/account/token/

  PYPI_USERNAME       PyPI username (required, use __token__ for token auth)
  PYPI_INDEX_URL      PyPI index URL (optional, default: https://upload.pypi.org/legacy/)
  DEFAULT_PROJECT     Default project name (optional, default: JAEGIS-Web-OS)

EXAMPLES:
  # List all tools in table format
  pypi-mcp-server --list-tools --format=table

  # Get tools schema for MCP client integration
  pypi-mcp-server --tools-json

  # Start the MCP server (default)
  pypi-mcp-server

QUICK SETUP:
  1. Generate PyPI token: https://pypi.org/manage/account/token/
  2. Set environment variables:
     export PYPI_TOKEN=pypi-your_token_here
     export PYPI_USERNAME=__token__
  3. Run: pypi-mcp-server

For detailed documentation, see: README.md
`);
}

function getToolsInfo(): ToolInfo[] {
  return [
    {
      name: 'pypi_package_info',
      category: 'Package Information',
      description: 'Get detailed information about a PyPI package including metadata and dependencies',
      requiredParams: ['package_name'],
      optionalParams: ['version'],
      inputSchema: { type: 'object', properties: { package_name: { type: 'string' } } }
    },
    {
      name: 'pypi_search_packages',
      category: 'Package Discovery',
      description: 'Search for PyPI packages using keywords and filters',
      requiredParams: ['query'],
      optionalParams: ['limit'],
      inputSchema: { type: 'object', properties: { query: { type: 'string' } } }
    },
    {
      name: 'pypi_upload_package',
      category: 'Package Publishing',
      description: 'Upload a package to PyPI registry using twine with full authentication and error handling',
      requiredParams: ['package_path'],
      optionalParams: ['repository', 'additional_flags'],
      inputSchema: { type: 'object', properties: { package_path: { type: 'string' } } }
    },
    {
      name: 'pypi_list_versions',
      category: 'Package Information',
      description: 'List all available versions of a package with release information',
      requiredParams: ['package_name'],
      optionalParams: [],
      inputSchema: { type: 'object', properties: { package_name: { type: 'string' } } }
    },
    {
      name: 'pypi_download_stats',
      category: 'Package Analytics',
      description: 'Get download statistics and analytics for a package',
      requiredParams: ['package_name'],
      optionalParams: ['period'],
      inputSchema: { type: 'object', properties: { package_name: { type: 'string' } } }
    },
    {
      name: 'pypi_validate_package',
      category: 'Package Validation',
      description: 'Validate package metadata and check for publishing readiness',
      requiredParams: ['package_path'],
      optionalParams: [],
      inputSchema: { type: 'object', properties: { package_path: { type: 'string' } } }
    },
    {
      name: 'pypi_build_package',
      category: 'Package Building',
      description: 'Build distribution files for a Python package (sdist, wheel)',
      requiredParams: ['package_path'],
      optionalParams: ['build_type'],
      inputSchema: { type: 'object', properties: { package_path: { type: 'string' } } }
    },
    {
      name: 'pypi_check_name_availability',
      category: 'Package Discovery',
      description: 'Check if a package name is available on PyPI registry',
      requiredParams: ['package_name'],
      optionalParams: [],
      inputSchema: { type: 'object', properties: { package_name: { type: 'string' } } }
    },
    {
      name: 'health_check',
      category: 'Diagnostics',
      description: 'Return server health, version, uptime, and dependency status',
      requiredParams: [],
      optionalParams: [],
      inputSchema: { type: 'object', properties: {} }
    }
  ];
}

function displayToolsTable(tools: ToolInfo[]): void {
  console.error('\n🐍 PyPI JAEGIS MCP Server - Tool Inventory\n');
  console.error('┌─────────────────────────────────────┬──────────────────────────────────┬──────────┬──────────┐');
  console.error('│ Tool Name                           │ Category                         │ Required │ Optional │');
  console.error('├─────────────────────────────────────┼──────────────────────────────────┼──────────┼──────────┤');

  tools.forEach(tool => {
    const name = tool.name.padEnd(35);
    const category = tool.category.padEnd(32);
    const required = tool.requiredParams.length.toString().padEnd(8);
    const optional = tool.optionalParams.length.toString().padEnd(8);
    console.error(`│ ${name} │ ${category} │ ${required} │ ${optional} │`);
  });

  console.error('└─────────────────────────────────────┴──────────────────────────────────┴──────────┴──────────┘');

  // Summary by category
  const categories = tools.reduce((acc, tool) => {
    acc[tool.category] = (acc[tool.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  console.error('\n📋 Tool Summary by Category:');
  Object.entries(categories).forEach(([category, count]) => {
    console.error(`  • ${category}: ${count} tools`);
  });
  console.error(`\n🎯 Total: ${tools.length} tools available\n`);
}

function displayToolsJson(tools: ToolInfo[], includeSchema: boolean = false): void {
  const output = {
    server: 'pypi-jaegis-mcp-server',
    version: '1.0.0',
    totalTools: tools.length,
    categories: tools.reduce((acc, tool) => {
      acc[tool.category] = (acc[tool.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>),
    tools: tools.map(tool => ({
      name: tool.name,
      category: tool.category,
      description: tool.description,
      parameters: {
        required: tool.requiredParams,
        optional: tool.optionalParams,
        total: tool.requiredParams.length + tool.optionalParams.length
      },
      ...(includeSchema && { inputSchema: tool.inputSchema })
    }))
  };

  console.error(JSON.stringify(output, null, 2));
}

// Handle command line arguments before server initialization
if (hasHelp) {
  showHelp();
  process.exit(0);
}

if (hasListTools || hasToolsJson) {
  const tools = getToolsInfo();

  if (hasToolsJson) {
    displayToolsJson(tools, true);
  } else if (formatTable) {
    displayToolsTable(tools);
  } else {
    displayToolsJson(tools, false);
  }

  process.exit(0);
}

interface PyPIConfig {
  token: string;
  username: string;
  indexUrl: string;
  repositoryUrl: string;
  defaultProject?: string;
  testMode?: boolean;
}

interface PackageInfo {
  name: string;
  version: string;
  summary?: string;
  description?: string;
  author?: string;
  authorEmail?: string;
  license?: string;
  homepage?: string;
  projectUrls?: Record<string, string>;
  classifiers?: string[];
  keywords?: string[];
  requiresPython?: string;
  dependencies?: string[];
  uploadTime?: string;
  downloads?: {
    lastDay: number;
    lastWeek: number;
    lastMonth: number;
  };
}

interface PublishResult {
  success: boolean;
  packageName: string;
  version: string;
  message: string;
  pypiUrl?: string;
}

class PyPIJAEGISMCPServer {
  private server: Server;
  private config: PyPIConfig;

  constructor() {
    this.config = this.loadConfig();
    this.validateConfiguration();

    this.server = new Server(
      {
        name: 'pypi-jaegis-mcp-server',
        version: '1.0.0',
      },
      {
        capabilities: {
          tools: {},
        },
      }
    );

    this.setupToolHandlers();
    this.setupErrorHandling();
  }

  private loadConfig(): PyPIConfig {
    // Do NOT hard-fail on missing credentials so tools/list always works in clients.
    const token = process.env.PYPI_TOKEN || '';
    const username = process.env.PYPI_USERNAME || '__token__';

    return {
      token,
      username,
      indexUrl: process.env.PYPI_INDEX_URL || 'https://upload.pypi.org/legacy/',
      repositoryUrl: process.env.PYPI_REPOSITORY_URL || 'https://pypi.org/simple/',
      defaultProject: process.env.DEFAULT_PROJECT || 'JAEGIS-Web-OS',
      testMode: process.env.NODE_ENV === 'test'
    };
  }

  private validateConfiguration(): void {
    if (!this.config.token.startsWith('pypi-')) {
      console.warn('Warning: PyPI token format may be invalid. Expected format: pypi-*');
    }

    if (this.config.username !== '__token__') {
      console.warn('Warning: For token authentication, username should be "__token__"');
    }

    console.error(`PyPI MCP Server configured for project: ${this.config.defaultProject}`);
    console.error(`Index URL: ${this.config.indexUrl}`);
    console.error(`Repository URL: ${this.config.repositoryUrl}`);
  }

  private setupToolHandlers(): void {
    this.server.setRequestHandler(ListToolsRequestSchema, async () => {
      return {
        tools: [

          {
            name: 'pypi_package_info',
            description: 'Get detailed information about a PyPI package',
            inputSchema: {
              type: 'object',
              properties: {
                package_name: {
                  type: 'string',
                  description: 'Name of the PyPI package'
                },
                version: {
                  type: 'string',
                  description: 'Specific version (optional, defaults to latest)'
                }
              },
              required: ['package_name']
            }
          },
          {
            name: 'pypi_search_packages',
            description: 'Search for PyPI packages',
            inputSchema: {
              type: 'object',
              properties: {
                query: {
                  type: 'string',
                  description: 'Search query'
                },
                limit: {
                  type: 'number',
                  description: 'Maximum number of results (default: 20)'
                }
              },
              required: ['query']
            }
          },
          {
            name: 'pypi_upload_package',
            description: 'Upload a package to PyPI using twine',
            inputSchema: {
              type: 'object',
              properties: {
                package_path: {
                  type: 'string',
                  description: 'Path to package directory containing dist/ folder or path to distribution file (.tar.gz or .whl)'
                },
                repository: {
                  type: 'string',
                  enum: ['pypi', 'testpypi'],
                  description: 'Target repository (default: pypi)'
                },
                additional_flags: {
                  type: 'string',
                  description: 'Additional twine upload flags (e.g., "--skip-existing")'
                }
              },
              required: ['package_path']
            }
          },
          {
            name: 'pypi_list_versions',
            description: 'List all versions of a package',
            inputSchema: {
              type: 'object',
              properties: {
                package_name: {
                  type: 'string',
                  description: 'Name of the package'
                }
              },
              required: ['package_name']
            }
          },
          {
            name: 'pypi_download_stats',
            description: 'Get download statistics for a package',
            inputSchema: {
              type: 'object',
              properties: {
                package_name: {
                  type: 'string',
                  description: 'Name of the package'
                },
                period: {
                  type: 'string',
                  enum: ['recent', 'last-day', 'last-week', 'last-month'],
                  description: 'Time period for stats (default: last-month)'
                }
              },
              required: ['package_name']
            }
          },
          {
            name: 'pypi_validate_package',
            description: 'Validate package metadata and check for publishing readiness',
            inputSchema: {
              type: 'object',
              properties: {
                package_path: {
                  type: 'string',
                  description: 'Path to package directory containing setup.py or pyproject.toml'
                }
              },
              required: ['package_path']
            }
          },
          {
            name: 'pypi_build_package',
            description: 'Build distribution files for a Python package',
            inputSchema: {
              type: 'object',
              properties: {
                package_path: {
                  type: 'string',
                  description: 'Path to package directory'
                },
                build_type: {
                  type: 'string',
                  enum: ['sdist', 'wheel', 'both'],
                  description: 'Type of distribution to build (default: both)'
                }
              },
              required: ['package_path']
            }
          },
          {
            name: 'pypi_check_name_availability',
            description: 'Check if a package name is available on PyPI',
            inputSchema: {
              type: 'object',
              properties: {
                package_name: {
                  type: 'string',
                  description: 'Name to check for availability'
                }
              },
              required: ['package_name']
            }
          },
          {
            name: 'health_check',
            description: 'Return server health, version, uptime, and dependency status',
            inputSchema: { type: 'object', properties: {} }
          }
        ] as Tool[]
      };
    });

    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      const { name, arguments: args } = request.params;

      try {
        switch (name) {
          case 'pypi_package_info':
            return await this.getPackageInfo(args);
          case 'pypi_search_packages':
            return await this.searchPackages(args);
          case 'pypi_upload_package':
            return await this.uploadPackage(args);
          case 'pypi_list_versions':
            return await this.listVersions(args);
          case 'pypi_download_stats':
            return await this.getDownloadStats(args);
          case 'pypi_validate_package':
            return await this.validatePackage(args);
          case 'pypi_build_package':
            return await this.buildPackage(args);
          case 'pypi_check_name_availability':
            return await this.checkNameAvailability(args);
          case 'health_check': {
            const version = (()=>{ try { return JSON.parse(fs.readFileSync(path.resolve(__dirname,'..','package.json'),'utf8')).version } catch { return '1.0.0' } })();
            const uptime = process.uptime();
            return { content: [{ type: 'text', text: JSON.stringify({ status:'ok', version, uptime, success:true }) }] };
          }
          default:
            throw new Error(`Unknown tool: ${name}`);
        }
      } catch (error) {
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify({
                error: error instanceof Error ? error.message : String(error),
                success: false
              }, null, 2)
            }
          ]
        };
      }
    });
  }

  private setupErrorHandling(): void {
    this.server.onerror = (error) => {
      console.error('[PyPI MCP Server Error]', error);
    };

    process.on('SIGINT', async () => {
      await this.server.close();
      process.exit(0);
    });
  }

  // Tool implementations will be added in the next part
  private async getPackageInfo(args: any) {
    const { package_name, version } = args;
    
    try {
      const url = version 
        ? `https://pypi.org/pypi/${package_name}/${version}/json`
        : `https://pypi.org/pypi/${package_name}/json`;
      
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`Package not found: ${package_name}`);
      }
      
      const data = await response.json() as any;
      
      const packageInfo: PackageInfo = {
        name: data.info.name,
        version: data.info.version,
        summary: data.info.summary,
        description: data.info.description,
        author: data.info.author,
        authorEmail: data.info.author_email,
        license: data.info.license,
        homepage: data.info.home_page,
        projectUrls: data.info.project_urls,
        classifiers: data.info.classifiers,
        keywords: data.info.keywords?.split(',').map((k: string) => k.trim()),
        requiresPython: data.info.requires_python,
        uploadTime: data.urls?.[0]?.upload_time
      };

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              operation: 'pypi_package_info',
              package: packageInfo,
              success: true
            }, null, 2)
          }
        ]
      };
    } catch (error) {
      throw new Error(`Failed to get package info: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private async searchPackages(args: any) {
    const { query, limit = 20 } = args;

    if (!query || typeof query !== 'string') {
      throw new Error('query parameter is required and must be a string');
    }

    if (limit < 1 || limit > 100) {
      throw new Error('limit must be between 1 and 100');
    }

    try {
      // PyPI JSON API search endpoint
      const url = `https://pypi.org/pypi?c=&o=&q=${encodeURIComponent(query)}&page=1`;
      const response = await fetch(url);

      if (!response.ok) {
        throw new Error(`PyPI search failed with status ${response.status}`);
      }

      // PyPI doesn't have a direct JSON search API, so we use the simple API
      // For a more robust solution, we'd use a third-party search service
      const htmlResponse = await response.text();

      // Extract package names from HTML (simplified approach)
      const packageMatches = htmlResponse.match(/<a href="\/project\/([^"]+)"/g) || [];
      const packages = packageMatches
        .slice(0, limit)
        .map(match => match.replace(/<a href="\/project\//, '').replace(/"/, ''));

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              operation: 'pypi_search_packages',
              query,
              results: packages,
              count: packages.length,
              success: true
            }, null, 2)
          }
        ]
      };
    } catch (error) {
      throw new Error(`Failed to search packages: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private async uploadPackage(args: any) {
    try {
      const packagePath = args.package_path;
      const repository = args.repository || 'pypi';
      const additionalFlags = args.additional_flags || '';

      if (!packagePath) throw new Error('package_path is required');
      if (!this.config.token) throw new Error('PYPI_TOKEN environment variable is required');

      // Validate package path exists
      if (!fs.existsSync(packagePath)) {
        throw new Error(`Package path not found: ${packagePath}`);
      }

      // Check if it's a directory (containing dist/) or a file
      const isDirectory = fs.statSync(packagePath).isDirectory();
      let distPath: string;
      let packageName: string;

      if (isDirectory) {
        distPath = path.join(packagePath, 'dist');
        if (!fs.existsSync(distPath)) {
          throw new Error(`dist/ directory not found in ${packagePath}`);
        }

        // Check for setup.py or pyproject.toml
        const hasSetupPy = fs.existsSync(path.join(packagePath, 'setup.py'));
        const hasPyprojectToml = fs.existsSync(path.join(packagePath, 'pyproject.toml'));

        if (!hasSetupPy && !hasPyprojectToml) {
          throw new Error('Neither setup.py nor pyproject.toml found in package directory');
        }

        // Try to extract package name from setup.py or pyproject.toml
        packageName = this.extractPackageName(packagePath);
      } else {
        // Single file upload
        distPath = packagePath;
        packageName = path.basename(packagePath);
      }

      // Verify distribution files exist
      const distFiles = isDirectory ? fs.readdirSync(distPath) : [distPath];
      const hasDistFiles = distFiles.some(f => f.endsWith('.whl') || f.endsWith('.tar.gz'));

      if (!hasDistFiles) {
        throw new Error('No distribution files (.whl or .tar.gz) found in dist/ directory');
      }

      // Get repository URL
      const repositoryUrl = repository === 'testpypi'
        ? 'https://test.pypi.org/legacy/'
        : this.config.indexUrl;

      // Setup PyPI authentication environment
      const publishEnv = {
        ...process.env,
        TWINE_USERNAME: '__token__',
        TWINE_PASSWORD: this.config.token,
        TWINE_REPOSITORY_URL: repositoryUrl
      };

      // Build twine upload command
      const uploadPath = isDirectory ? path.join(distPath, '*') : distPath;
      const publishCmd = `python -m twine upload --verbose ${uploadPath} ${additionalFlags}`.trim();

      console.error(`[PyPI Upload] Executing: ${publishCmd}`);
      console.error(`[PyPI Upload] Package: ${packageName}`);
      console.error(`[PyPI Upload] Repository: ${repository}`);

      // Execute twine upload command
      let publishOutput = '';
      let publishError = '';

      try {
        publishOutput = execSync(publishCmd, {
          cwd: isDirectory ? packagePath : path.dirname(packagePath),
          env: publishEnv,
          encoding: 'utf-8',
          stdio: ['pipe', 'pipe', 'pipe']
        });
      } catch (execError: any) {
        publishError = execError.stderr || execError.stdout || execError.message;

        // Check if it's an authentication error
        if (publishError.includes('401') || publishError.includes('403') ||
            publishError.includes('Forbidden') || publishError.includes('unauthorized') ||
            publishError.includes('Invalid or expired authentication token')) {
          throw new Error('PyPI authentication failed. Check PYPI_TOKEN environment variable.');
        }

        // Check if package already exists
        if (publishError.includes('File already exists') || publishError.includes('already exists')) {
          throw new Error('Package version already exists on PyPI. Increment version number and try again.');
        }

        // Check for invalid metadata
        if (publishError.includes('Invalid metadata') || publishError.includes('metadata')) {
          throw new Error(`Invalid package metadata: ${publishError.substring(0, 200)}`);
        }

        // Check for missing twine
        if (publishError.includes('No module named twine') || publishError.includes('twine: command not found')) {
          throw new Error('twine is not installed. Install it with: pip install twine');
        }

        throw new Error(`twine upload failed: ${publishError.substring(0, 300)}`);
      }

      console.error(`[PyPI Upload] Success: ${packageName}`);

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              success: true,
              message: `Successfully published ${packageName} to PyPI registry`,
              package: packageName,
              repository,
              repositoryUrl,
              uploadOutput: publishOutput.substring(0, 500),
              timestamp: new Date().toISOString()
            }, null, 2)
          }
        ]
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.error(`[PyPI Upload Error] ${errorMessage}`);

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              success: false,
              error: errorMessage,
              timestamp: new Date().toISOString()
            }, null, 2)
          }
        ],
        isError: true
      };
    }
  }

  private extractPackageName(packagePath: string): string {
    try {
      // Try to read from setup.py
      const setupPyPath = path.join(packagePath, 'setup.py');
      if (fs.existsSync(setupPyPath)) {
        const setupContent = fs.readFileSync(setupPyPath, 'utf-8');
        const nameMatch = setupContent.match(/name\s*=\s*['"](.*?)['"]/);
        if (nameMatch) return nameMatch[1];
      }

      // Try to read from pyproject.toml
      const pyprojectPath = path.join(packagePath, 'pyproject.toml');
      if (fs.existsSync(pyprojectPath)) {
        const pyprojectContent = fs.readFileSync(pyprojectPath, 'utf-8');
        const nameMatch = pyprojectContent.match(/name\s*=\s*['"](.*?)['"]/);
        if (nameMatch) return nameMatch[1];
      }

      return 'unknown-package';
    } catch {
      return 'unknown-package';
    }
  }

  private async listVersions(args: any) {
    const { package_name } = args;

    if (!package_name || typeof package_name !== 'string') {
      throw new Error('package_name parameter is required and must be a string');
    }

    try {
      const url = `https://pypi.org/pypi/${package_name}/json`;
      const response = await fetch(url);

      if (!response.ok) {
        throw new Error(`Package not found: ${package_name}`);
      }

      const data = await response.json() as any;
      const releases = data.releases || {};

      // Get all versions and sort them using semver
      const versions = Object.keys(releases)
        .filter(v => semver.valid(v))
        .sort((a, b) => semver.compare(b, a));

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              operation: 'pypi_list_versions',
              package: package_name,
              totalVersions: versions.length,
              versions: versions,
              latest: versions[0] || 'unknown',
              success: true
            }, null, 2)
          }
        ]
      };
    } catch (error) {
      throw new Error(`Failed to list versions: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private async getDownloadStats(args: any) {
    const { package_name, period = 'last-month' } = args;

    if (!package_name || typeof package_name !== 'string') {
      throw new Error('package_name parameter is required and must be a string');
    }

    const validPeriods = ['recent', 'last-day', 'last-week', 'last-month'];
    if (!validPeriods.includes(period)) {
      throw new Error(`period must be one of: ${validPeriods.join(', ')}`);
    }

    try {
      // PyPI Stats API endpoint
      const url = `https://pypistats.org/api/packages/${package_name}/recent?period=${period}`;
      const response = await fetch(url);

      if (!response.ok) {
        // Fallback: return estimated stats from package info
        const infoUrl = `https://pypi.org/pypi/${package_name}/json`;
        const infoResponse = await fetch(infoUrl);

        if (!infoResponse.ok) {
          throw new Error(`Package not found: ${package_name}`);
        }

        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify({
                operation: 'pypi_download_stats',
                package: package_name,
                period,
                downloads: 0,
                note: 'Stats API unavailable, returning zero',
                success: true
              }, null, 2)
            }
          ]
        };
      }

      const data = await response.json() as any;

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              operation: 'pypi_download_stats',
              package: package_name,
              period,
              downloads: data.data?.reduce((sum: number, item: any) => sum + (item.downloads || 0), 0) || 0,
              success: true
            }, null, 2)
          }
        ]
      };
    } catch (error) {
      throw new Error(`Failed to get download stats: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private async validatePackage(args: any) {
    const { package_path } = args;

    if (!package_path || typeof package_path !== 'string') {
      throw new Error('package_path parameter is required and must be a string');
    }

    try {
      const setupPyPath = path.join(package_path, 'setup.py');
      const setupCfgPath = path.join(package_path, 'setup.cfg');
      const pyprojectPath = path.join(package_path, 'pyproject.toml');

      let configExists = false;
      let configType = 'unknown';

      if (fs.existsSync(setupPyPath)) {
        configExists = true;
        configType = 'setup.py';
      } else if (fs.existsSync(setupCfgPath)) {
        configExists = true;
        configType = 'setup.cfg';
      } else if (fs.existsSync(pyprojectPath)) {
        configExists = true;
        configType = 'pyproject.toml';
      }

      const issues: string[] = [];
      const warnings: string[] = [];

      if (!configExists) {
        issues.push('No setup.py, setup.cfg, or pyproject.toml found');
      }

      // Check for README
      const readmeExists = fs.existsSync(path.join(package_path, 'README.md')) ||
                          fs.existsSync(path.join(package_path, 'README.rst')) ||
                          fs.existsSync(path.join(package_path, 'README.txt'));

      if (!readmeExists) {
        warnings.push('No README file found');
      }

      // Check for LICENSE
      const licenseExists = fs.existsSync(path.join(package_path, 'LICENSE')) ||
                           fs.existsSync(path.join(package_path, 'LICENSE.txt'));

      if (!licenseExists) {
        warnings.push('No LICENSE file found');
      }

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              operation: 'pypi_validate_package',
              package_path,
              configType,
              isValid: issues.length === 0,
              issues,
              warnings,
              success: true
            }, null, 2)
          }
        ]
      };
    } catch (error) {
      throw new Error(`Failed to validate package: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private async buildPackage(args: any) {
    const { package_path } = args;

    if (!package_path || typeof package_path !== 'string') {
      throw new Error('package_path parameter is required and must be a string');
    }

    try {
      // Check if directory exists
      if (!fs.existsSync(package_path)) {
        throw new Error(`Package directory not found: ${package_path}`);
      }

      // Check for setup.py or pyproject.toml
      const setupPyPath = path.join(package_path, 'setup.py');
      const pyprojectPath = path.join(package_path, 'pyproject.toml');

      const hasSetupPy = fs.existsSync(setupPyPath);
      const hasPyproject = fs.existsSync(pyprojectPath);

      if (!hasSetupPy && !hasPyproject) {
        throw new Error('No setup.py or pyproject.toml found in package directory');
      }

      // Check for dist directory
      const distPath = path.join(package_path, 'dist');
      const distExists = fs.existsSync(distPath);

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              operation: 'pypi_build_package',
              package_path,
              hasSetupPy,
              hasPyproject,
              distExists,
              buildCommand: 'python -m build',
              message: 'Package is ready to build. Run: python -m build',
              success: true
            }, null, 2)
          }
        ]
      };
    } catch (error) {
      throw new Error(`Failed to build package: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private async checkNameAvailability(args: any) {
    const { package_name } = args;
    
    try {
      const response = await fetch(`https://pypi.org/pypi/${package_name}/json`);
      
      const available = !response.ok;
      
      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              operation: 'pypi_check_name_availability',
              package_name,
              available,
              message: available 
                ? `Package name "${package_name}" is available`
                : `Package name "${package_name}" is already taken`,
              success: true
            }, null, 2)
          }
        ]
      };
    } catch (error) {
      throw new Error(`Failed to check name availability: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  async run(): Promise<void> {
    const transport = new StdioServerTransport();
    await this.server.connect(transport);

    // Display startup summary
    const tools = getToolsInfo();
    const categories = tools.reduce((acc, tool) => {
      acc[tool.category] = (acc[tool.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    console.error('🐍 PyPI JAEGIS MCP Server (v1.0.0) running on stdio');
    console.error(`📊 Total Tools: ${tools.length} | Categories: ${Object.keys(categories).length}`);
    console.error(`🔧 Configured for project: ${this.config.defaultProject}`);
    console.error(`🌐 Index URL: ${this.config.indexUrl}`);
    console.error('✅ Server ready with PyPI package management tools');
    console.error('💡 Use --list-tools to see all available tools');
  }
}

// Run the server
if (require.main === module) {
  try {
    const server = new PyPIJAEGISMCPServer();
    server.run().catch((error) => {
      console.error('Failed to start PyPI JAEGIS MCP Server:', error.message);
      process.exit(1);
    });
  } catch (error) {
    console.error('Failed to initialize PyPI JAEGIS MCP Server:');
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}
