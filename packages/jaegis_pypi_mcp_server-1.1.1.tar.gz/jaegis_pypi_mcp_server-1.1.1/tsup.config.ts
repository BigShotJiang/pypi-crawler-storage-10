import { defineConfig } from 'tsup';

export default defineConfig({
  entry: ['src/index.ts'],
  format: ['cjs'],
  sourcemap: true,
  dts: false,
  clean: true,
  target: 'node18',
  outDir: 'dist',
  outExtension: () => ({ js: '.cjs' }),
  banner: {
    js: '#!/usr/bin/env node',
  },
  minify: false,
});

