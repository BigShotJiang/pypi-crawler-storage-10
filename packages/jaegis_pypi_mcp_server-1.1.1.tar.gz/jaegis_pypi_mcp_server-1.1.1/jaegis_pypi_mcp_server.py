#!/usr/bin/env python3
"""
JAEGIS PyPI MCP Server - Python wrapper for Node.js MCP server
This module provides a Python entry point to launch the Node.js-based MCP server
for PyPI package management.
"""

import sys
import os
import subprocess
import json
from pathlib import Path
import click


def get_server_path() -> Path:
    """Get the path to the compiled Node.js server."""
    # Try multiple locations where the server might be installed
    possible_paths = [
        Path(__file__).parent / 'dist' / 'index.cjs',
        Path(__file__).parent / 'dist' / 'index.js',
        Path(__file__).parent.parent / 'pypi-mcp-server' / 'dist' / 'index.cjs',
    ]
    
    for path in possible_paths:
        if path.exists():
            return path
    
    raise FileNotFoundError(
        f"Could not find pypi-mcp-server executable. Tried: {possible_paths}"
    )


def get_package_info() -> dict:
    """Get package information from package.json."""
    pkg_path = Path(__file__).parent / 'package.json'
    if pkg_path.exists():
        with open(pkg_path, 'r') as f:
            return json.load(f)
    return {'version': 'unknown', 'name': 'jaegis-pypi-mcp-server'}


@click.command()
@click.option('--list-tools', is_flag=True, help='List all available tools')
@click.option('--tools-json', is_flag=True, help='Output tools schema as JSON')
@click.option('--format', type=click.Choice(['table', 'json']), default='json',
              help='Output format for tool listings')
@click.option('--help-flag', is_flag=True, help='Show help message')
def main(list_tools: bool, tools_json: bool, format: str, help_flag: bool) -> None:
    """
    JAEGIS PyPI MCP Server - PyPI package management with 8 specialized tools
    
    This server provides tools for:
    - Package information and search
    - Publishing packages to PyPI
    - Managing package versions
    - Download statistics and analytics
    - Package validation
    """
    try:
        server_path = get_server_path()
        pkg_info = get_package_info()
        
        # Build command arguments
        cmd = ['node', str(server_path)]
        
        if list_tools:
            cmd.append('--list-tools')
        if tools_json:
            cmd.append('--tools-json')
        if format == 'table' and list_tools:
            cmd.append('--format=table')
        if help_flag:
            cmd.append('--help')
        
        # Set up environment
        env = os.environ.copy()
        
        # Load .env file if it exists
        env_file = Path.home() / '.mcp' / '.env'
        if env_file.exists():
            with open(env_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        key, value = line.split('=', 1)
                        env[key.strip()] = value.strip()
        
        # Execute the Node.js server
        result = subprocess.run(cmd, env=env)
        sys.exit(result.returncode)
        
    except FileNotFoundError as e:
        click.echo(f"Error: {e}", err=True)
        click.echo(
            "Please ensure the pypi-mcp-server is properly installed.",
            err=True
        )
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


if __name__ == '__main__':
    main()

