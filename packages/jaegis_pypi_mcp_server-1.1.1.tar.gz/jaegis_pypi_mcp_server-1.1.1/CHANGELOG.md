# Changelog

All notable changes to this project will be documented in this file.

The format is based on Keep a Changelog and this project adheres to Semantic Versioning.

## [1.1.0] - 2025-10-23

### Added
- **Full Implementation of All 8 PyPI Tools**
  - `pypi_package_info` - Get detailed package information from PyPI
  - `pypi_search_packages` - Search PyPI packages with keyword queries
  - `pypi_upload_package` - Upload packages to PyPI or TestPyPI
  - `pypi_list_versions` - List all available versions with semver sorting
  - `pypi_download_stats` - Get download statistics for packages
  - `pypi_validate_package` - Validate package metadata and structure
  - `pypi_build_package` - Prepare packages for building
  - `pypi_check_name_availability` - Check if package name is available

- **Enhanced Security**
  - Removed hardcoded paths from source code
  - Portable environment variable loading (HOME/.mcp/.env)
  - Credential sanitization in logs
  - Token format validation

### Changed
- Migrated from placeholder implementations to full PyPI API integration
- Updated environment variable loading to be portable across systems
- Improved startup logging with tool inventory summary
- Enhanced package validation with semver support

### Fixed
- Removed hardcoded Windows path from environment loading
- Fixed credential exposure in configuration files
- Improved error handling for missing packages
- Better version sorting using semver

### Security
- All real credentials replaced with placeholders in configuration files
- Added credential sanitization for logs
- Implemented token format validation
- Secure environment variable handling

## [1.0.3] - 2025-10-15

### Changed
- Switched build to tsup (CJS-first) and ensured clean stdio separation (stdout = JSON-RPC only)
- Implemented portable dotenv cascade loading (user .mcp path -> home -> local)
- Added health_check tool for diagnostics

### Fixed
- Ensured dotenv v16.x is used to avoid stdout contamination of JSON-RPC
- Removed temporary stdout/console interception workarounds

