from setuptools import setup, find_packages

setup(
    name="regression_soumiaamari",
    version="0.1",
    author="soumia amari",
    author_email="s.amari@esi-sba.dz",
    description="A simple linear regression model from scratch",
    packages=find_packages(),
    install_requires=[],
    license="MIT",
)
