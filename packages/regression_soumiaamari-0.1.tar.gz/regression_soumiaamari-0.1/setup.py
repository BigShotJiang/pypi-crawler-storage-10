
from setuptools import setup, find_packages

setup(
    name="rocket",
    version="1.0.0",
    author="Meriem BERRAHOU",
    author_email="me.berrahou@esi-sba.dz",
    description="A simple rocket simulation package",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    license="MIT",
    packages=find_packages(),
    install_requires=['rocket'],  
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)