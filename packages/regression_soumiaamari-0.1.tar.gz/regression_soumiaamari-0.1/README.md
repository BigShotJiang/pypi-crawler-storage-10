# Rocket Package 🚀

A simple educational Python package that simulates rockets, shuttles, and circular rockets for physics or game simulations.

## Features
- `Rocket`: base class with position and movement
- `Shuttle`: inherits from `Rocket`, adds flight count
- `circleRocket`: inherits from `Rocket`, adds circular geometry (area & circumference)

## Installation
```bash
pip install rocket
```
## License
[MIT](https://choosealicense.com/licenses/mit/)