import gdb
from common import *


@GdbCommandRegistry
class Heap5_free(GdbCommand):
    """
    freertos heap5_free.
    """

    def run(self, arg, from_tty):
        args = gdb.string_to_argv(arg)
        self._debug = True if "debug" in args else False
        self._full = True if "full" in args else False
        self._find = True if "find" in args else False
        self._free = True if "free" in args else False
        xFreeBytesRemaining = int(GdbValue.parse("xFreeBytesRemaining"))
        xMinimumEverFreeBytesRemaining = int(
            GdbValue.parse("xMinimumEverFreeBytesRemaining")
        )
        print(
            f"xFreeBytesRemaining:0x{xFreeBytesRemaining:X} xMinimumEverFreeBytesRemaining:0x{xMinimumEverFreeBytesRemaining:X}",
        )
        xStart = GdbValue.parse("xStart")
        pxEnd = int(GdbValue.parse("pxEnd"))
        print(xStart)
        print(f"pxEnd=0x{pxEnd:X}")
        pxBlock = xStart.pxNextFreeBlock
        while pxBlock != pxEnd:
            block = (
                gdb.Value(pxBlock)
                .cast(gdb.lookup_type("BlockLink_t").pointer())
                .dereference()
            )
            xBlockSize = int(block["xBlockSize"]) & 0x7FFFFFFF
            xBlockAllocatedBit = int(block["xBlockSize"]) >> 31
            if self._debug:
                print(block)
            print(
                f"offset:0x{int(block.address):X} pxNextFreeBlock:{int(block['pxNextFreeBlock']):X} xBlockSize:{xBlockSize} xBlockAllocatedBit:{xBlockAllocatedBit}"
            )
            pxBlock = block["pxNextFreeBlock"]

@GdbCommandRegistry
class Heap5(GdbCommand):
    """
    freertos heap5.
    """

    @staticmethod
    def get_xHeapStructSize():
        if is_object_exist("xHeapStructSize"):
            return int(GdbValue.get("xHeapStructSize"))
        else:
            return 8
    
    @staticmethod
    def get_xBlockAllocatedBit():
        if is_object_exist("xBlockAllocatedBit"):
            return int(GdbValue.get("xBlockAllocatedBit"))
        else:
            return 8
        
    @staticmethod
    def round_up4(size):
        return (size + 3) & ~3
    
    @staticmethod
    def round_up8(size):
        return (size + 7) & ~7
        
    def print_heap(self, idx, heap_start, heap_end, heap_size):
        print(
            f"heap{idx} start_addr:0x{heap_start:X} end_addr:0x{heap_end:X} size:0x{heap_size:X}",
        )
        xHeapStructSize = self.get_xHeapStructSize()
        used_list = {}
        free_list = {}
        heap_addr = self.round_up8(heap_start)
        print(f"heap_addr:0x{heap_addr:X}")
        try:
            while heap_addr < heap_end - xHeapStructSize:
                block = (
                    gdb.Value(heap_addr)
                    .cast(gdb.lookup_type("BlockLink_t").pointer())
                    .dereference()
                )
                xBlockSize = int(block["xBlockSize"]) & 0x7FFFFFFF
                xBlockAllocatedBit = int(block["xBlockSize"]) >> 31
                if self._full:
                    if self._debug:
                        print(block)
                    print(
                        f"offset:0x{int(block.address):X} pxNextFreeBlock:0x{int(block['pxNextFreeBlock']):X} xBlockSize:{xBlockSize} xBlockAllocatedBit:{xBlockAllocatedBit}"
                    )
                    
                if xBlockAllocatedBit:
                    if xBlockSize not in used_list.keys():
                        used_list[xBlockSize] = [block]
                    else:
                        used_list[xBlockSize].append(block)
                else:
                    if xBlockSize not in free_list.keys():
                        free_list[xBlockSize] = [block]
                    else:
                        free_list[xBlockSize].append(block)
                heap_addr += xBlockSize
        except Exception as e:
            print(f"error: {e}")

        print("used:")
        self.used_list = sorted(
            used_list.items(), key=lambda x: len(x[1]) * int(x[0]), reverse=True
        )
        for k, v in self.used_list:
            print(f"size:{k} count:{len(v)}")
            for block in v:
                data_addr = int(block.address) + xHeapStructSize
                if is_object_exist("heap_dbg_block_trace_t"):
                    heap_trace = GdbValue(
                        gdb.Value(data_addr)
                        .cast(gdb.lookup_type("heap_dbg_block_trace_t").pointer())
                        .dereference()
                    )
                    # print(heap_trace)
                    print(
                        "    0x%08X ra:0x%08X rtc:%d"
                        % (
                            int(heap_trace.address),
                            int(heap_trace.ra),
                            int(heap_trace.rtc),
                        )
                    )
                    data_addr += int(GdbValue.parse("sizeof(heap_dbg_block_trace_t)"))
                if self._find:
                    info = gdb.execute(f"wq find 0x{data_addr:08X}")
                    print(f"data_addr:0x{data_addr:08X} {info}")

        print("free:")
        self.free_list = sorted(
            free_list.items(), key=lambda x: len(x[1]) * int(x[0]), reverse=True
        )
        for k, v in self.free_list:
            print(f"size:{k} count:{len(v)}")

    def run(self, arg, from_tty):
        args = gdb.string_to_argv(arg)
        self._debug = True if "debug" in args else False
        self._full = True if "full" in args else False
        self._find = True if "find" in args else False
        self._free = True if "free" in args else False
        xBlockAllocatedBit = 0
        xFreeBytesRemaining = int(GdbValue.parse("xFreeBytesRemaining"))
        xMinimumEverFreeBytesRemaining = int(
            GdbValue.parse("xMinimumEverFreeBytesRemaining")
        )
        print(
            f"xFreeBytesRemaining:0x{xFreeBytesRemaining:X} xMinimumEverFreeBytesRemaining:0x{xMinimumEverFreeBytesRemaining:X}",
        )
        _heap_start = get_heap_start()
        _heap_end = get_heap_end()
        _heap_size = _heap_end - _heap_start
        self.print_heap(0, _heap_start, _heap_end, _heap_size)
        mem_opt_gen_regoins = GdbValue.get("mem_opt_gen_regoins", True)
        if mem_opt_gen_regoins:
            print(f"mem_opt_gen_regoins:{mem_opt_gen_regoins}")
            for i, region in enumerate(mem_opt_gen_regoins):
                self.print_heap(i+1, self.round_up4(int(region.start)), self.round_up4(int(region.end)), self.round_up4(int(region.end)) - self.round_up4(int(region.start)))
               

@GdbCommandRegistry
class TLSF(GdbCommand):
    """
    wq tlsf.

    usage: wq tlsf [full] [find]
    """

    def get_heap_list(self):
        used_list = []
        free_list = []
        used_dict = {}
        free_dict = {}
        g_multi_heap_list = GdbValue.get("g_multi_heap_list")
        for heap in g_multi_heap_list:
            if heap.start != 0x0 and heap.end != 0x0 and heap.heap != 0x0:
                heap_start = int(heap.start)
                heap_end = int(heap.end)
                print(f"heap start:0x{int(heap_start):X} end:0x{int(heap_end):X}")
                print(
                    f"size:{int(heap.heap.pool_size)} free:{int(heap.heap.free_bytes)} min_free:{int(heap.heap.minimum_free_bytes)}"
                )
                print(f"heap_data:0x{int(heap.heap.heap_data):X}")

                control = heap.heap.heap_data.cast("control_t*")
                # print(control)
                control_size = GdbValue.get("sizeof(control_t)")
                block_header_size = GdbValue.get("sizeof(control_t)")
                block_header_free_bit = 1 << 0
                block_header_prev_free_bit = 1 << 1
                block_start_offset = 8
                block_header_overhead = 4
                ptr = GdbValue(int(control) + control_size - 4)

                # print(f"ptr:0x{int(ptr):X}")
                while int(ptr) < (heap_end - block_header_size):
                    # print(f"ptr:0x{int(ptr):X}")
                    block = ptr.cast("block_header_t*")
                    # print(block)
                    size = int(block.size) & 0xFFFFFFFC
                    free = True if int(block.size) & block_header_free_bit else False
                    prev_free = (
                        True if int(block.size) & block_header_prev_free_bit else False
                    )
                    if self._full:
                        print(
                            f"block:0x{int(block):08X} size:{size:05d} is_free:{free} prev_free:{prev_free}"
                        )

                    ptr = ptr + (size + block_start_offset - block_header_overhead)
                    if free:
                        if size not in free_dict.keys():
                            free_dict[size] = [block]
                        else:
                            free_dict[size].append(block)
                    else:
                        if size not in used_dict.keys():
                            used_dict[size] = [block]
                        else:
                            used_dict[size].append(block)

        free_list = sorted(
            free_dict.items(), key=lambda x: len(x[1]) * int(x[0]), reverse=True
        )
        used_list = sorted(
            used_dict.items(), key=lambda x: len(x[1]) * int(x[0]), reverse=True
        )
        return used_list, free_list

    def run(self, arg, from_tty):
        args = gdb.string_to_argv(arg)
        self._full = True if "full" in args else False
        self._find = True if "find" in args else False
        used_list, free_list = self.get_heap_list()
        print("free:")
        for k, v in free_list:
            print(f"size:{k} count:{len(v)}")

        print("used:")
        heap_used_list = [(int(b), k) for k, v in used_list for b in v]

        for k, v in used_list:
            print(f"size:{k} count:{len(v)}")
            if self._find:
                wq_heap_allocate_size = GdbValue.get(
                    "sizeof(wq_heap_allocate_t)", True
                )
                for block in v:
                    if wq_heap_allocate_size:
                        heap_trace = (block.cast("uint8_t*") + 8).cast(
                            "wq_heap_allocate_t*"
                        )
                        # print(heap_trace)
                        print(
                            f"trace:0x{int(heap_trace):08X} rtc:{int(heap_trace.rtc)} ra:0x{int(heap_trace.ra):08X} task_handle:0x{int(heap_trace.task_handle):08X}"
                        )
                        gdb.execute(f"info symbol 0x{int(heap_trace.ra):08X}")
                        addr = int(block) + 8 + int(wq_heap_allocate_size)
                    else:
                        addr = int(block) + 8
                        gdb.execute(f"wq find 0x{addr:08X}")
