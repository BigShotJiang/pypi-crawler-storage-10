def main():
    print("Hello from bioskills!")


if __name__ == "__main__":
    main()
