"""
Fabric SDK Client - Main interface for interacting with Fabric API
"""

import requests
import time
from typing import Dict, Any, Optional, List
from .exceptions import (
    AuthenticationError,
    JobSubmissionError,
    InsufficientCreditsError,
    JobTimeoutError,
    NetworkError
)
from .types import Job, Node, CreditBalance, JobResult


class FabricClient:
    """
    Fabric SDK Client for programmatic job submission
    
    Example:
        >>> client = FabricClient(
        ...     api_url="https://api.fabric.carmel.so",
        ...     email="user@example.com",
        ...     password="password"
        ... )
        >>> job = client.submit_job("pytorch_cnn", params={...})
        >>> result = client.wait_for_job(job['id'])
    """
    
    def __init__(
        self,
        api_url: str,
        email: str,
        password: str,
        auto_login: bool = True,
        timeout: int = 30
    ):
        """
        Initialize Fabric client
        
        Args:
            api_url: Fabric API base URL (e.g., "https://api.fabric.carmel.so")
            email: User email
            password: User password
            auto_login: Automatically login on initialization
            timeout: Default request timeout in seconds
        """
        self.api_url = api_url.rstrip('/')
        self.email = email
        self.password = password
        self.timeout = timeout
        self.token: Optional[str] = None
        
        if auto_login:
            self.login()
    
    def _make_request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        auth_required: bool = True
    ) -> Dict[str, Any]:
        """Make HTTP request with error handling and retry logic"""
        url = f"{self.api_url}{endpoint}"
        headers = {}
        
        if auth_required:
            if not self.token:
                raise AuthenticationError("Not authenticated. Call login() first.")
            headers['Authorization'] = f'Bearer {self.token}'
        
        try:
            response = requests.request(
                method=method,
                url=url,
                json=data,
                params=params,
                headers=headers,
                timeout=self.timeout
            )
            
            if response.status_code == 401:
                raise AuthenticationError("Authentication failed or token expired")
            elif response.status_code == 403:
                raise AuthenticationError("Access forbidden")
            elif response.status_code == 400:
                error_data = response.json()
                if "insufficient credits" in str(error_data).lower():
                    raise InsufficientCreditsError(f"Insufficient credits: {error_data}")
                raise JobSubmissionError(f"Bad request: {error_data}")
            elif response.status_code >= 400:
                raise NetworkError(f"HTTP {response.status_code}: {response.text}")
            
            return response.json()
        
        except requests.exceptions.Timeout:
            raise NetworkError(f"Request timeout after {self.timeout}s")
        except requests.exceptions.ConnectionError as e:
            raise NetworkError(f"Connection error: {e}")
        except requests.exceptions.RequestException as e:
            raise NetworkError(f"Request failed: {e}")
    
    def login(self) -> str:
        """
        Authenticate and obtain access token
        
        Returns:
            Access token
            
        Raises:
            AuthenticationError: If login fails
        """
        try:
            response = self._make_request(
                'POST',
                '/api/auth/login',
                data={'email': self.email, 'password': self.password},
                auth_required=False
            )
            self.token = response.get('access_token')
            return self.token
        except Exception as e:
            raise AuthenticationError(f"Login failed: {e}")
    
    def get_credit_balance(self) -> CreditBalance:
        """
        Get current credit balance
        
        Returns:
            Credit balance object
        """
        return self._make_request('GET', '/api/payment/balance')
    
    def list_nodes(self, status: Optional[str] = None) -> List[Node]:
        """
        List available compute nodes
        
        Args:
            status: Filter by node status (active, inactive, busy)
            
        Returns:
            List of nodes
        """
        params = {'status': status} if status else None
        return self._make_request('GET', '/api/nodes', params=params)
    
    def submit_job(
        self,
        workload_type: str,
        params: Dict[str, Any],
        requirements: Optional[Dict[str, Any]] = None
    ) -> Job:
        """
        Submit a job to the Fabric network
        
        Args:
            workload_type: Type of workload (e.g., "pytorch_cnn", "transformer_attention")
            params: Workload-specific parameters
            requirements: Hardware requirements (optional)
                - min_cpu_cores: Minimum CPU cores
                - min_ram_gb: Minimum RAM in GB
                - gpu_required: Whether GPU is required
                - min_gpu_memory_gb: Minimum GPU memory in GB
        
        Returns:
            Created job object
            
        Raises:
            JobSubmissionError: If submission fails
            InsufficientCreditsError: If insufficient credits
        """
        # Prepare job parameters
        job_params = params.copy()
        if requirements:
            job_params['requirements'] = requirements
        
        payload = {
            'job_type': workload_type,
            'params': job_params
        }
        
        try:
            job_data = self._make_request('POST', '/api/jobs/submit', data=payload)
            
            # Check for capacity warning
            if job_data.get('warning'):
                print(f"⚠️  Warning: {job_data['warning'].get('message')}")
                if job_data['warning'].get('suggestions'):
                    print("Suggestions:")
                    for suggestion in job_data['warning']['suggestions']:
                        print(f"  - {suggestion}")
            
            return job_data
        except Exception as e:
            raise JobSubmissionError(f"Job submission failed: {e}")
    
    def get_job(self, job_id: str) -> Job:
        """
        Get job details
        
        Args:
            job_id: Job ID
            
        Returns:
            Job object
        """
        # Use /my-jobs endpoint to get all jobs, then filter for the specific job
        # This works around a backend bug in the /status endpoint
        jobs = self._make_request('GET', '/api/jobs/my-jobs', params={'limit': 100})
        
        for job in jobs:
            if job['id'] == job_id:
                return job
        
        # Job not found in user's jobs
        raise JobSubmissionError(f"Job {job_id} not found in your jobs")
    
    def wait_for_job(
        self,
        job_id: str,
        timeout: int = 600,
        poll_interval: int = 5
    ) -> JobResult:
        """
        Wait for job to complete
        
        Args:
            job_id: Job ID
            timeout: Maximum wait time in seconds
            poll_interval: Polling interval in seconds
            
        Returns:
            Job result with metadata
            
        Raises:
            JobTimeoutError: If job doesn't complete within timeout
        """
        start_time = time.time()
        
        while True:
            elapsed = time.time() - start_time
            
            if elapsed > timeout:
                raise JobTimeoutError(
                    f"Job {job_id} did not complete within {timeout}s"
                )
            
            job = self.get_job(job_id)
            status = job['status']
            
            if status == 'completed':
                # Get result from /results endpoint
                try:
                    result_response = self._make_request('GET', f'/api/jobs/{job_id}/results')
                    result_data = result_response.get('result')
                    error_msg = result_response.get('error_message')
                except:
                    result_data = None
                    error_msg = None
                
                return JobResult(
                    job_id=job_id,
                    status='completed',
                    result=result_data,
                    actual_cost=job.get('actual_cost', 0.0),
                    duration_seconds=job.get('duration_seconds'),
                    error_message=error_msg
                )
            
            elif status == 'failed':
                # Get error from /results endpoint
                try:
                    result_response = self._make_request('GET', f'/api/jobs/{job_id}/results')
                    error_msg = result_response.get('error_message', 'Job failed')
                except:
                    error_msg = 'Job failed'
                
                return JobResult(
                    job_id=job_id,
                    status='failed',
                    result=None,
                    actual_cost=job.get('actual_cost', 0.0),
                    duration_seconds=job.get('duration_seconds'),
                    error_message=error_msg
                )
            
            # Job still in progress
            time.sleep(poll_interval)
    
    def cancel_job(self, job_id: str) -> Dict[str, Any]:
        """
        Cancel a running job (if supported by backend)
        
        Args:
            job_id: Job ID
            
        Returns:
            Response from backend
        """
        return self._make_request('POST', f'/api/jobs/{job_id}/cancel')
    
    def list_jobs(
        self,
        status: Optional[str] = None,
        limit: int = 50
    ) -> List[Job]:
        """
        List user's jobs
        
        Args:
            status: Filter by status (queued, executing, completed, failed)
            limit: Maximum number of jobs to return
            
        Returns:
            List of jobs
        """
        # Use the /my-jobs endpoint which filters by current user
        params = {'limit': limit}
        if status:
            params['status_filter'] = status
        
        return self._make_request('GET', '/api/jobs/my-jobs', params=params)

