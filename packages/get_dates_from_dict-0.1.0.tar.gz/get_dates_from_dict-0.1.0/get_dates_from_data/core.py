from datetime import datetime

def get_start_and_last_month(data):
    # for memid, estd_org in data.items():
    try:
        new_data = {}
        print(data)
        for estd, years in data.items():
            try:
                new_data[estd] = {}
                print(estd)
                all_entries = []
                if estd == "personal_information":
                    continue
                print(111111)
                # Gather all entries across years for the establishment

                print(years)
                for year, records in years.items():
                    all_entries.extend(records)
                print(79)
                # print(all_entries[:3])
                # Sort by wage_month to get start and last month
                sorted_entries = sorted(all_entries, key=lambda x: datetime.strptime(x["wage_month"], "%b-%Y"))
                print(82)

                # Extract start month (first entry) and last month (last entry)
                start_month_data = sorted_entries[0]
                last_month_data = sorted_entries[-1]

                print(f"Establishment: {estd}")
                print(f"Start --- \"wage_month\": \"{start_month_data['wage_month']}\", \"epf_wages\": \"{start_month_data['employer_share']}\"")
                print(f"End --- \"wage_month\": \"{last_month_data['wage_month']}\", \"epf_wages\": \"{last_month_data['employer_share']}\"")
                print()
                new_data[estd] = {estd: years}
                new_data[estd]["start_end_dates"] = {}
                new_data[estd]["start_end_dates"]["start_month"] = start_month_data["wage_month"]
                new_data[estd]["start_end_dates"]["end_month"] = last_month_data["wage_month"]
                new_data[estd]["start_end_dates"]["start_month_epf_wages"] = start_month_data["employer_share"]
                new_data[estd]["start_end_dates"]["start_month_pension_wages"] = start_month_data["pension_share"]
                new_data[estd]["start_end_dates"]["end_month_epf_wages"] = last_month_data["employer_share"]
                new_data[estd]["start_end_dates"]["end_month_pension_wages"] = last_month_data["pension_share"]
            except Exception as e:
                new_data[estd][estd] = "Passbook/Balance not available to this Member-id as this pertain to exempted establishment (i.e. Trust)."
                new_data[estd]["start_end_dates"] = {}
                new_data[estd]["start_end_dates"]["start_month"] = None
                new_data[estd]["start_end_dates"]["end_month"] = None
                new_data[estd]["start_end_dates"]["start_month_epf_wages"] = None
                new_data[estd]["start_end_dates"]["start_month_pension_wages"] = None
                new_data[estd]["start_end_dates"]["end_month_epf_wages"] = None
                new_data[estd]["start_end_dates"]["end_month_pension_wages"] = None
    except Exception as e:
        print("Error in get_start_and_last_month: "+str(e))
        
        # return data
    # print("##########################################################################")
    # print(new_data)
    # print("##########################################################################")
    return new_data

