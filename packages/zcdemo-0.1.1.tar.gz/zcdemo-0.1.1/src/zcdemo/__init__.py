#!/usr/bin/env python3
from pathlib import Path
import subprocess
from mcp.server.fastmcp import FastMCP
import sys
import os
# 拿到 SSTImap 脚本绝对路径
SSTIMAP_PY = Path(__file__).parent/ "SSTImap" / "sstimap.py"

mcp = FastMCP("SSTI-Scanner")

@mcp.tool()

def scan_ssti(url: str) -> str:
    """
    测试 URL 参数是否存在 SSTI 漏洞: 
    """
    # 拼接命令
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    cmd = [sys.executable, str(SSTIMAP_PY), "-u", url.strip()]

    # 起进程（cwd 设到 SSTImap 目录，相当于你手动 cd 进去）
    proc = subprocess.run(
        cmd,
        cwd=SSTIMAP_PY.parent,
        capture_output=True,
        text=True,
        timeout=60
    )
    # 把 stdout + stderr 一次性返回
    return f"{proc.stderr}{proc.stdout}\n[Exit code] {proc.returncode}"
# Add a dynamic greeting resource
@mcp.resource("greeting://{name}")
def get_greeting(name: str) -> str:
    """Get a personalized greeting"""
    return f"Hello, {name}!"


# Add a prompt
@mcp.prompt()
def greet_user(name: str, style: str = "friendly") -> str:
    """Generate a greeting prompt"""
    styles = {
        "friendly": "Please write a warm, friendly greeting",
        "formal": "Please write a formal, professional greeting",
        "casual": "Please write a casual, relaxed greeting",
    }

    return f"{styles.get(style, styles['friendly'])} for someone named {name}."

def main() :
    mcp.run(transport='stdio')