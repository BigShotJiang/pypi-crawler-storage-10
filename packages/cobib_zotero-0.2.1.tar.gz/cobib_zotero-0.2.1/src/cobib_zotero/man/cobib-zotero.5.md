cobib-zotero(5) -- zotero plugin configuration
==============================================

## SYNOPSIS

```python
from cobib_zotero.config import zotero_plugin_config
```

## DESCRIPTION

The [SYNOPSIS][] section above shows how to import this plugin's configuration object inside coBib's *cobib-config(5)* file.
In the [OPTIONS][] section below all available settings are listed and explained.


## OPTIONS

  * _zotero_plugin_config.field_map_ = `{...}`:
    A dictionary mapping Zotero's field names to coBib's field names.
    When a field name maps to `None`, this means it will skip it without warning about its presence.

## SEE ALSO

*cobib(1)*, *cobib-config(5)*, *cobib-zotero(7)*

[//]: # ( vim: set ft=markdown tw=0: )
