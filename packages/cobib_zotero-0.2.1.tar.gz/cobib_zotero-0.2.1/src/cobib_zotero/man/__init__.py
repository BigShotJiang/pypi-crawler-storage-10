"""cobib-zotero's manual.

.. include:: cobib-zotero.7.html_fragment
"""
