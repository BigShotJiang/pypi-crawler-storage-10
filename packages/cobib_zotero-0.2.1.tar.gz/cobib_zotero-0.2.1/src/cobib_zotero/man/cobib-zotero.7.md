cobib-zotero(7) -- zotero importer backend
==========================================

## SYNOPSIS

`cobib import --zotero` [`--api-key` _KEY_] _ID_ _TYPE_

## DESCRIPTION

Imports the bibliography from [Zotero](https://www.zotero.org).
This importer is registered inside the *cobib-import(1)* command.

Two positional arguments are required:

  * _ID_:
    The Zotero library ID from which to import.

  * _TYPE_:
    The Zotero library type. This can be either `user` or `group`.


## OPTIONS

  * `--api-key`=_KEY_:
    The Zotero API key to use.
    This may ONLY be omitted when the library is publicly accessible.
    And even then, its attachments may not be available.


## EXAMPLES

The following imports a publicly accessible library from the `coBib` user:
```bash
cobib import --zotero -- 8608002 "user"
```

## SEE ALSO

*cobib(1)*, *cobib-import(1)*, *cobib-zotero(5)*, *cobib-importers(7)*, [Zotero](https://www.zotero.org)

[//]: # ( vim: set ft=markdown tw=0: )
