"""cobib-zotero's config module.

.. include:: ../man/cobib-zotero.5.html_fragment
"""

from .config import zotero_plugin_config as zotero_plugin_config
