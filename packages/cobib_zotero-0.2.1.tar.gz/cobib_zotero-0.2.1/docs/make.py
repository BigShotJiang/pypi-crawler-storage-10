"""cobib-zotero's API generation."""

import argparse
import sys
from collections import deque
from pathlib import Path

sys.path.insert(0, ".")

from theme.build import build_html  # type: ignore[import-not-found]

MODULES = [
    Path("src/cobib_zotero"),
    Path("tests"),
]

parser = argparse.ArgumentParser()
parser.add_argument(
    "modules",
    type=Path,
    nargs="*",
    default=MODULES,
    help="The paths to the modules to document.",
)
args = parser.parse_args()

# we don't want to perform any customizations so we simply exhaust the iterator
generator = deque(
    build_html(args.modules, base_url="https://gitlab.com/cobib/cobib-zotero/-/blob/master/"),
    maxlen=0,
)
