"""cobib-zotero Test Suite.

The test suite is organized into submodules which mirror the layout of the source code. As such,
each file in the source should have a corresponding file with unittests.
In most cases, the unittests will be organized into classes which derive from a common base test
class at the submodule level.

To run the test suite with coverage reporting, use:
```
tox -e coverage
```
For quick testing of individual files, it is easier to use:
```
pytest <path/to/test/file.py>
```
Check out `pytest --help` for more options.
"""
