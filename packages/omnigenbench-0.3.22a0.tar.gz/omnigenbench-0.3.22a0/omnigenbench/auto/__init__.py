"""
This package contains modules for automated processes such as benchmarking and training.
"""
