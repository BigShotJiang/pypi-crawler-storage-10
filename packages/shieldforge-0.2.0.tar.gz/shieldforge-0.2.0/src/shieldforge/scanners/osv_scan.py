import os, json, subprocess, shutil

def run(path: str):
    if shutil.which("osv-scanner") is None:
        return {"ok": False, "error": "osv-scanner non installé"}
    target = os.path.abspath(path)
    if not os.path.isdir(target):
        return {"ok": False, "error": f"Chemin invalide: {target}"}
    try:
        res = subprocess.run(
            ["osv-scanner", "--recursive", "--json", target],
            capture_output=True, text=True, check=False
        )
        if res.returncode not in (0,1):  # 1 si vuln trouvées
            return {"ok": False, "error": res.stderr.strip() or "osv-scanner error"}
        data = json.loads(res.stdout or "{}")
        return {"ok": True, "raw": data}
    except Exception as e:
        return {"ok": False, "error": str(e)}
