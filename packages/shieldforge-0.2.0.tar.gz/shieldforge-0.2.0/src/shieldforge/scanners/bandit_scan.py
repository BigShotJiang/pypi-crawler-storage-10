import os, json, subprocess

def run(path: str):
    target = os.path.abspath(path)
    if not os.path.isdir(target):
        return {"ok": False, "error": f"Chemin invalide: {target}"}
    try:
        res = subprocess.run(
            ["bandit", "-r", target, "-f", "json"],
            capture_output=True, text=True, check=False
        )
        if res.returncode not in (0,1):
            return {"ok": False, "error": res.stderr.strip() or "Bandit error"}
        data = json.loads(res.stdout or "{}")
        issues = data.get("results", [])
        return {"ok": True, "issues": issues, "raw": data}
    except Exception as e:
        return {"ok": False, "error": str(e)}
