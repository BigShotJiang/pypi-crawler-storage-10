import os, json, subprocess

def _normalize_findings(data):
    """
    Normalise la sortie pip-audit (liste ou dict) en une liste d'items:
    {"dependency":{"name":..., "version":...}, "vulns":[...] }
    """
    if isinstance(data, list):
        # Format récent: déjà une liste d'objets {dependency:{name,version}, vulns:[...] }
        return data

    if isinstance(data, dict):
        # Ancien/variante: { "dependencies": [...], "vulns": [...] }
        if "dependencies" in data:
            deps = data.get("dependencies") or []
            items = []
            for d in deps:
                dep = {"name": d.get("name"), "version": d.get("version")}
                vulns = d.get("vulns") or []
                items.append({"dependency": dep, "vulns": vulns})
            return items

        # Autre variante: { "results": [ { "name":..., "version":..., "vulns":[...] }, ... ] }
        if "results" in data and isinstance(data["results"], list):
            items = []
            for r in data["results"]:
                dep = {
                    "name": (r.get("name") or r.get("dependency", {}).get("name")),
                    "version": (r.get("version") or r.get("dependency", {}).get("version")),
                }
                vulns = r.get("vulns") or []
                items.append({"dependency": dep, "vulns": vulns})
            return items

    # Par défaut: rien
    return []

def find_requirements(path: str):
    for name in ["requirements.txt", "requirements-dev.txt"]:
        p = os.path.join(path, name)
        if os.path.isfile(p):
            return p
    return None

def run(path: str):
    target = os.path.abspath(path)
    if not os.path.isdir(target):
        return {"ok": False, "error": f"Chemin invalide: {target}"}

    req = find_requirements(target)
    if not req:
        return {"ok": True, "raw": {"note": "Aucun requirements.txt trouvé"}, "findings": []}

    try:
        res = subprocess.run(
            ["pip-audit", "-r", req, "-f", "json"],
            capture_output=True, text=True, check=False
        )
        # 0: pas de vuln / 1: vuln trouvées / >1: erreur
        if res.returncode not in (0, 1):
            return {"ok": False, "error": res.stderr.strip() or "pip-audit error"}

        raw = json.loads(res.stdout or "[]")
        findings = _normalize_findings(raw)
        return {"ok": True, "raw": raw, "findings": findings}
    except Exception as e:
        return {"ok": False, "error": str(e)}
