import os, json, click
from rich.console import Console
from rich.table import Table
from . import __version__
from .reporting import save_report
from .emailer import send_email, can_send_email
from .scanners import bandit_scan, pip_audit_scan, osv_scan

console = Console()

@click.group(help="ShieldForge - Scanner éthique pour l'open source")
@click.version_option(version=__version__)
def main():
    pass

@main.command("scan")
@click.argument("path", type=click.Path(exists=True, file_okay=False), default=".")
@click.option("--bandit", is_flag=True, help="Scanner le code Python avec Bandit")
@click.option("--deps", is_flag=True, help="Scanner les dépendances (pip-audit)")
@click.option("--osv", "use_osv", is_flag=True, help="Scanner avec OSV-Scanner (si installé)")
@click.option("--email", is_flag=True, help="Envoyer un email si vulnérabilités détectées")
def scan_cmd(path, bandit, deps, use_osv, email):
    if not any([bandit, deps, use_osv]):
        bandit = True
        deps = True

    console.rule("[bold]ShieldForge Scan")
    results = {"target": os.path.abspath(path), "version": __version__}

    if bandit:
        console.print("▶ Bandit en cours…")
        b = bandit_scan.run(path)
        results["bandit"] = b
        _render_bandit(b)

    if deps:
        console.print("▶ pip-audit en cours…")
        d = pip_audit_scan.run(path)
        results["pip_audit"] = d
        _render_pip_audit(d)

    if use_osv:
        console.print("▶ OSV-Scanner en cours…")
        o = osv_scan.run(path)
        results["osv"] = o
        _render_osv(o)

    report_path = save_report(results)
    console.print(f"\n[green]✔ Rapport enregistré :[/] {report_path}")

    # Email si demandé et si findings
    if email:
        findings_count = _count_findings(results)
        if findings_count > 0:
            body = json.dumps(results, ensure_ascii=False, indent=2)[:20000]
            send_email(subject=f"[ShieldForge] {findings_count} vuln trouvée(s)", body=body)
        else:
            console.print("Aucune vuln détectée — email non envoyé.")
            if not can_send_email():
                console.print("ℹ Configure .env si tu veux des emails.")

def _count_findings(res: dict) -> int:
    n = 0
    b = res.get("bandit", {})
    n += len(b.get("issues", []) or [])
    d = res.get("pip_audit", {})
    n += len(d.get("findings", []) or [])
    o = res.get("osv", {}).get("raw", {})
    # Pour OSV, on compte les résultats si disponibles
    if isinstance(o, dict) and "results" in o:
        for r in o["results"]:
            n += len(r.get("packages", []) or [])
    return n

def _render_bandit(b):
    if not b or not b.get("ok"):
        console.print(f"[red]Bandit erreur:[/] {b.get('error') if b else 'unknown'}")
        return
    issues = b.get("issues", [])
    table = Table(title=f"Bandit - {len(issues)} problème(s)")
    table.add_column("Fichier")
    table.add_column("Ligne")
    table.add_column("Règle")
    table.add_column("Détail")
    for i in issues[:30]:
        table.add_row(i.get("filename","?"), str(i.get("line_number","?")), i.get("test_id","?"), i.get("issue_text","")[:80])
    console.print(table) if issues else console.print("[green]Aucun problème Bandit.[/]")


def _render_pip_audit(d):
    if not d or not d.get("ok"):
        console.print(f"[red]pip-audit erreur:[/] {d.get('error') if d else 'unknown'}")
        return
    findings = d.get("findings", [])
    if not isinstance(findings, list):
        findings = []
    if not findings:
        console.print("[green]Aucun problème de dépendances (pip-audit).[/]")
        return
    table = Table(title=f"pip-audit - {len(findings)} vuln(s)")
    table.add_column("Package")
    table.add_column("Version")
    table.add_column("Advisory")
    for item in findings[:30]:
        dep = item.get("dependency", {}) or {}
        pkg = dep.get("name", "?")
        ver = dep.get("version", "?")
        vulns = item.get("vulns", []) or []
        advs = ", ".join([ (v.get("id") or v.get("advisory", {}).get("id") or "?") for v in vulns ])
        table.add_row(pkg, ver, advs if advs else "—")
    console.print(table)
def _render_osv(o):
    if not o or not o.get("ok"):
        console.print(f"[yellow]OSV-Scanner:[/] {o.get('error','non disponible')}")
        return
    console.print("[green]OSV-Scanner exécuté (voir JSON dans le rapport).[/]")


@main.command("report")
@click.option("--file", "file_", type=click.Path(exists=True, dir_okay=False), default=None, help="Chemin d'un rapport JSON")
@click.option("--latest", is_flag=True, help="Ouvrir le dernier rapport")
def report_cmd(file_, latest):
    "Afficher un résumé d'un rapport JSON."
    import json, os, glob
    path = file_
    if latest:
        files = sorted(glob.glob("reports/report-*.json"), reverse=True)
        if not files:
            console.print("[yellow]Aucun rapport trouvé dans ./reports[/]")
            return
        path = files[0]
    if not path:
        console.print("[yellow]Précise --latest ou --file <rapport.json>[/]")
        return
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    console.rule(f"[bold]Résumé du rapport[/] — {os.path.basename(path)}")
    # Compte simple
    b = len((data.get("bandit") or {}).get("issues") or [])
    d = len((data.get("pip_audit") or {}).get("findings") or [])
    console.print(f"Bandit: [bold]{b}[/] | Dépendances: [bold]{d}[/]")
    if b:
        table = Table(title="Top Bandit (max 10)")
        table.add_column("Fichier"); table.add_column("Ligne"); table.add_column("Règle"); table.add_column("Détail")
        for i in (data["bandit"]["issues"][:10]):
            table.add_row(i.get("filename","?"), str(i.get("line_number","?")), i.get("test_id","?"), i.get("issue_text","")[:80])
        console.print(table)
