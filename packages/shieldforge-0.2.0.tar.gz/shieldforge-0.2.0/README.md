

cat > README.md << 'EOF'
# ShieldForge

Scanner éthique pour l'open source : **Bandit**, **pip-audit**, **OSV-Scanner** (optionnel), rapports JSON, email d'alerte.

## Utilisation rapide
```bash
pip install -e .
shieldforge scan ./tests/demo_project --bandit --deps


---

## ÉTAPE 5 — `src/shieldforge/__init__.py`

```bash
cat > src/shieldforge/__init__.py << 'EOF'
__version__ = "0.1.0"

## Badges
![PyPI](https://img.shields.io/pypi/v/shieldforge)
![CI](https://github.com/tonuser/ShieldForge/actions/workflows/ci.yml/badge.svg)
