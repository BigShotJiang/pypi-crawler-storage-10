from mcp_server_gaode_sse_thy import main

main()