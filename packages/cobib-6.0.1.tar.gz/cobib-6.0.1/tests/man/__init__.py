"""coBib's man tests."""
