"""coBib's utility tests."""
