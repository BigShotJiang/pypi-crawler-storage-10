"""coBib's Shell tests."""
