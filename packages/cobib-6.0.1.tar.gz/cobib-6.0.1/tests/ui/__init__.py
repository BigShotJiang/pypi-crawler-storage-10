"""coBib's UI tests."""
