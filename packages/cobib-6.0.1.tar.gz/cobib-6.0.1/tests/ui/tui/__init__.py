"""coBib's TUI tests."""
