"""coBib's importer tests."""

from .importer_test import ImporterTest as ImporterTest
