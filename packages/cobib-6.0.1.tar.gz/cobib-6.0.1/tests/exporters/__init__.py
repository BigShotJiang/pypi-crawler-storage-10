"""coBib's exporter tests."""

from .exporter_test import ExporterTest as ExporterTest
