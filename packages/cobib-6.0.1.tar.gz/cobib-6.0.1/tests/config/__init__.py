"""coBib's config tests."""
