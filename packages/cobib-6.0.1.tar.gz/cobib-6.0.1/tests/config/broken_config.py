"""A broken coBib configuration for testing purposes."""

from cobib.config import config

config.database.file = True  # type: ignore[assignment]
