"""coBib's parser tests."""

from .parser_test import ParserTest as ParserTest
