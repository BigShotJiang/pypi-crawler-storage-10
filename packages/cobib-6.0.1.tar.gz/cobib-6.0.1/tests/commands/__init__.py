"""coBib's command tests."""

from .command_test import CommandTest as CommandTest
