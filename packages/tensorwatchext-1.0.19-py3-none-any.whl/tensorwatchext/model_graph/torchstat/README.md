# Credits

Code in this folder is almost as-is from torchstat repository located at https://github.com/Swall0w/torchstat.

Additional merges are from:
- https://github.com/kenshohara/torchstat
- https://github.com/lyakaap/torchstat