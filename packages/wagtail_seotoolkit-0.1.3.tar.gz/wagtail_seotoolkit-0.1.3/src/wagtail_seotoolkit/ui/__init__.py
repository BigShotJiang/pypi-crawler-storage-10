"""
UI components for Wagtail SEO Toolkit
"""
