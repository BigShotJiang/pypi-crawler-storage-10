import ast
import io
import json
import os
import re
import subprocess
import sys
from typing import Tuple
import requests

from .userinfo import UserInfo

DEFAULT_TIMEOUT = 120


def get_jupyter_username():
    # Get the username from the environment variable
    username = os.getenv("JUPYTERHUB_USER")
    return username


def get_from_url(url):
    s = requests.get(url, timeout=DEFAULT_TIMEOUT).content
    return io.StringIO(s.decode("utf-8")).getvalue()


def download_file(url: str, output_file: str):
    """Downloads a file from a given URL and saves it to the specified output file."""
    try:
        response = requests.get(url, stream=True, timeout=DEFAULT_TIMEOUT)
        response.raise_for_status()  # Raise an error for bad responses (e.g., 404, 403)

        with open(output_file, "wb") as file:
            for chunk in response.iter_content(chunk_size=8192):
                file.write(chunk)  # Write in chunks to avoid memory issues

        #print(f"Download successful: {output_file}")

    except requests.exceptions.RequestException as e:
        print(f"Error downloading file: {e}")


def download_file_large(url: str, output_file: str):
    script_name = "dl.py"
    script_dir = os.path.dirname(os.path.abspath(__file__))
    script_path = os.path.join(script_dir, script_name)
    if not os.path.exists(script_path):
        raise FileNotFoundError(f"The script {script_path} was not found.")
    subprocess.run([sys.executable, script_path, url, output_file], check=True)

def is_json(astring):
    try:
        json.loads(astring)
        return True
    except ValueError:
        return False

def _parse_user_info(filename: str) -> Tuple[UserInfo, str]:
    sec_pattern = re.compile(r"^secret_struct\s*=\s*(\{.*\})")
    url_pattern = re.compile(r"^sharing_url_jupyter\s*=\s*'(.*)'")

    sec = None
    url = None

    with open(filename, "r", encoding="utf-8") as file:
        for line in file:
            my_struct_match = sec_pattern.match(line.strip())
            link1_match = url_pattern.match(line.strip())

            if my_struct_match:
                try:
                    struct_dict = ast.literal_eval(my_struct_match.group(1))
                    sec = UserInfo(
                        struct_dict.get("userId", "")
                    )
                except (SyntaxError, ValueError):
                    pass

            if link1_match:
                url = link1_match.group(1)

            if sec is not None and url is not None:
                break

    return sec, url
