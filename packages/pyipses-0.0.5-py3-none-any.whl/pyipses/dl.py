#!/usr/bin/env python3

import sys
import argparse
import requests


def download_file(url: str, output_file: str):
    try:
        response = requests.get(url, stream=True, timeout=120)
        response.raise_for_status()
        with open(output_file, "wb") as file:
            for chunk in response.iter_content(chunk_size=8192):
                file.write(chunk)
        print(f"Download completed: {output_file}")

    except requests.exceptions.RequestException as e:
        print(f"Error downloading file: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Download a file from a given URL.")
    parser.add_argument("url", help="The URL of the file to download")
    parser.add_argument("output_file", help="The name of the output file")

    args = parser.parse_args()
    download_file(args.url, args.output_file)
