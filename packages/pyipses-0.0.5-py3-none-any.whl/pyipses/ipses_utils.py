import pandas as pd
from ipyleaflet import Map, Marker, Popup, basemaps, basemap_to_tiles
from ipywidgets import HTML
import plotly.express as px
import plotly.graph_objs as go


class IpsesUtils:

    def __new__(cls, *args, **kwargs):
        raise TypeError(f"{cls.__name__} cannot be instantiated.")

    @classmethod
    def _extract_popup_content(cls, popup_columns, row):
        popup_content = []
        for col in popup_columns:
            value = row[col]
            if isinstance(value, str) and (
                value.startswith("http://") or value.startswith("https://")
            ):
                value = f'<a href="{value}" target="_blank">{value}</a>'
            popup_content.append(f"<b>{col}</b>: {value}")

        popup_content = "<br>".join(popup_content)
        return popup_content

    @classmethod
    def map_df(
        cls,
        df,
        lat_col,
        lon_col,
        popup_columns=None,
        basemap="OpenStreetMap",
        width=800,
        height=600,
        zoom=4,
    ) -> Map:
        """
        Display a pandas DataFrame on a Leaflet map using ipyleaflet.

        Parameters:
        - df: the input dataframe.
        - lat_col: Name of the column containing latitude values.
        - lon_col: Name of the column containing longitude values.
        - popup_columns: List of column names to display in the popup. Default is all columns )except latitude and longitude=.
        - map_size: Tuple (width, height) specifying the size of the map.
        - basemap: The name of the basemap to use. Default is "OpenStreetMap".
        - width: specifies the the width of the map.
        - height: specifies the height of the map.
        - zoom: specifies the initial zoom for the map.
        """
        if lat_col not in df.columns:
            raise ValueError(f"Column '{lat_col}' not found in the DataFrame.")
        if lon_col not in df.columns:
            raise ValueError(f"Column '{lon_col}' not found in the DataFrame.")

        if popup_columns is not None:
            missing_columns = [col for col in popup_columns if col not in df.columns]
            if missing_columns:
                raise ValueError(
                    f"Columns {missing_columns} not found in the DataFrame."
                )
        else:
            popup_columns = [col for col in df.columns if col not in [lat_col, lon_col]]

        df = df.copy()
        df[lat_col] = pd.to_numeric(df[lat_col], errors="coerce")
        df[lon_col] = pd.to_numeric(df[lon_col], errors="coerce")

        df = df.dropna(subset=[lat_col, lon_col])

        center_lat = df[lat_col].mean()
        center_lon = df[lon_col].mean()

        #pylint: disable=E1101
        basemap_dict = {
            "WorldImagery": basemaps.Esri.WorldImagery, 
            "OpenStreetMap": basemaps.OpenStreetMap.Mapnik,
            "OpenStreetMapTopographic": basemaps.OpenTopoMap,
            "Positron": basemaps.CartoDB.Positron,
            "DarkMatter": basemaps.CartoDB.DarkMatter,
            "WorldTopoMap": basemaps.Esri.WorldTopoMap,
        }
        selected_basemap = basemap_dict.get(basemap, basemaps.OpenStreetMap.Mapnik)

        m = Map(
            center=(center_lat, center_lon),
            zoom=zoom,
            basemap=basemap_to_tiles(selected_basemap),
        )
        m.layout.width = f"{width}px"
        m.layout.height = f"{height}px"

        if popup_columns is None:
            popup_columns = [col for col in df.columns if col not in [lat_col, lon_col]]

        marker_locations = []

        for index, row in df.iterrows(): #pylint: disable=W0612
            popup_content = cls._extract_popup_content(popup_columns, row)

            popup = Popup(
                location=(row[lat_col], row[lon_col]),
                child=HTML(popup_content),
                close_button=False,
                auto_close=False,
            )

            marker = Marker(location=(row[lat_col], row[lon_col]), draggable=False)
            marker.popup = popup

            m.add_layer(marker)

            marker_locations.append((row[lat_col], row[lon_col]))

        if marker_locations:
            min_lat = min(lat for lat, lon in marker_locations)
            max_lat = max(lat for lat, lon in marker_locations)
            min_lon = min(lon for lat, lon in marker_locations)
            max_lon = max(lon for lat, lon in marker_locations)

            m.fit_bounds([[min_lat, min_lon], [max_lat, max_lon]])

        return m

    @classmethod
    def plot_df(
        cls,
        df,
        time_col,
        value_col,
        title="",
        color=None,
        width=None,
        height=None,
    ) -> go.Figure:
        """
        Plots a time series from a pandas DataFrame using Plotly Express.

        Parameters:
        - df: pandas DataFrame containing the time series data.
        - time_col: str, the name of the column in df that contains the time data.
        - value_col: str, the name of the column in df that contains the value data.
        - title: str, optional, the title of the plot.
        - color:  str, name of the column used to assign color to the plot.
        - width: int, optional, the width of the plot in pixels (default is None).
        - height: int, optional, the height of the plot in pixels (default is None).
        """
        # if time_col not in df.columns:
        #    raise ValueError(f"Column '{time_col}' not found in the DataFrame.")
        # if value_col not in df.columns:
        #    raise ValueError(f"Column '{value_col}' not found in the DataFrame.")

        fig = px.line(
            df, x=time_col, y=value_col, title=title, markers=True, color=color
        )

        if width or height:
            fig.update_layout(width=width, height=height)

        return fig
