import json
import re
import requests

from .userinfo import UserInfo
from .utils import DEFAULT_TIMEOUT


class WorkspaceService:
    def __init__(self, service_url):
        self._service_url = service_url

    def get_data_from_service(self, user_info: UserInfo):
        user_data = {
            "userId": user_info.user_id,
        }

        # POST the request to the API endpoint
        response = requests.post(
            self._service_url,
            headers={"Content-Type": "application/json"},
            data=json.dumps(user_data),
            timeout=DEFAULT_TIMEOUT
        )

        def unescape_csv_data(escaped_csv_data):
            return re.sub(r'\\([\\"\u0000])', r"\1", escaped_csv_data)

        # Check the answer
        if response.status_code == 200:
            # If it is OK, get the data
            data = response.json()
            if not data:
                print("Error: workspace data does not exist!")
            else:
                escaped_data = data[0]["jupyterData"]
                ret_data = unescape_csv_data(escaped_data)
                return json.loads(ret_data)
        else:
            print(f"Error {response.status_code}: {response.text}")
            return None
