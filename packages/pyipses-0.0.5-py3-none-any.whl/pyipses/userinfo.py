class UserInfo:
    def __init__(self, user_id: str):
        self.user_id = user_id

    def __repr__(self):
        return f"UserInfo(userId='{self.user_id}')"
