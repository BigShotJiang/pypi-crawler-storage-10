import json

class WorkspaceNode:
    def __init__(
        self,
        name,
        node_type,
        items=None,
        created_at=None,
        formats=None,
        description=None,
    ):
        self.name = name
        self.type = node_type
        self.items = items if items is not None else []
        self.created_at = created_at
        self.formats = formats if formats is not None else []  # Only for bookmarks
        self.description = description  # Only for bookmarks

    def is_folder(self):
        return self.type == "folder"

    def is_bookmark(self):
        return self.type == "bookmark"

    def get_items(self):
        return self.items

    def find(self, path):
        """Find a node by its path (e.g., '/Bookmarks/Google')."""
        if not path:
            return self

        parts = path.strip("/").split("/")
        current = self

        for part in parts:
            if not current.is_folder():
                return None

            found = None
            for item in current.items:
                if item.name == part:
                    found = item
                    break

            if not found:
                return None

            current = found

        return current

    def list_items(self, path=""):
        """List items of a folder at the given path."""
        node = self.find(path)
        if not node or not node.is_folder():
            return None

        return [{"name": item.name, "type": item.type} for item in node.items]

    def get_format_types(self):
        """Returns a list of formats available for the bookmark.
        Empty list if the workspace node is not a bookmark."""
        if not self.is_bookmark():
            return []
        return [fmt["format"] for fmt in self.formats if "format" in fmt]

    def get_url(self, format_type):
        """Returns the URL for the first matching format type, or None if not found."""
        if not self.is_bookmark():
            return None
        for fmt in self.formats:
            if fmt.get("format") == format_type:
                return fmt.get("url")
        return None

    def __repr__(self):
        if self.is_bookmark():
            return f"Bookmark(name={self.name}, formats={self.formats}, description={self.description})"
        return f"{self.type.capitalize()}(name={self.name}, items={self.items})"


class Workspace:
    def __init__(self, json_data=None):
        if json_data:
            self.json_data = json_data
            self.type = json_data.get("type", "Unknown type")
            self.name = json_data.get("name", "Unnamed workspace")
            self.user_id = json_data.get("userId", "Unknown User")
            self.last_modified = json_data.get("lastModified", "Unknown Date")
            self.root = self._parse_json(json_data["items"])
        else:
            self.type = "workspace"
            self.name = "Unnamed Workspace"
            self.user_id = "Unknown User"
            self.last_modified = "Unknown Date"
            self.root = WorkspaceNode("root", "folder")

    def _parse_json(self, data):
        """Recursively parse JSON data into a WorkspaceNode structure."""
        if data["type"] == "bookmark":
            return WorkspaceNode(
                name=data["name"],
                node_type=data["type"],
                created_at=data["createdAt"],
                ##formats=data.get("formats", []),
                formats=data.get("formats", [{"url": data["url"], "format": "unknown"}]) if "url" in data else data.get("formats", []),
                description=data.get("description"),
            )
        node = WorkspaceNode(
            data["name"],
            data["type"],
            created_at=data["createdAt"],
        )
        if node.is_folder():
            for item in data.get("items", []):
                node.items.append(self._parse_json(item))
        return node

    def get_raw_data(self):
        return self.json_data

    def find(self, path):
        """Find a node by its path."""
        return self.root.find(path)

    def list_items(self, path=""):
        """List items of a folder at the given path."""
        return self.root.list_items(path)

    def get_metadata(self):
        """Return metadata about the workspace."""
        return {
            "type": self.type,
            "name": self.name,
            "userId": self.user_id,
            "lastModified": self.last_modified,
        }

    def to_dict(self):
        """Convert the workspace structure to a dictionary."""
        return {
            "type": self.type,
            "name": self.name,
            "userId": self.user_id,
            "lastModified": self.last_modified,
            "items": self._node_to_dict(self.root),
        }

    def _node_to_dict(self, node):
        """Recursively convert a WorkspaceNode to a dictionary."""
        node_dict = {
            "type": node.type,
            "name": node.name,
            "createdAt": node.created_at,
        }
        if node.is_bookmark():
            node_dict["formats"] = node.formats
            node_dict["description"] = node.description
        elif node.is_folder():
            node_dict["items"] = [self._node_to_dict(child) for child in node.items]
        return node_dict

    def get_all_bookmarks(self):
        """Return a list of all nodes of type 'bookmark' in the workspace."""
        bookmarks = []
        self._collect_bookmarks(self.root, bookmarks)
        return bookmarks

    def _collect_bookmarks(self, node, bookmarks):
        """Recursively collect all nodes of type 'bookmark'."""
        if node.is_bookmark():
            bookmarks.append(node)
        elif node.is_folder():
            for child in node.items:
                self._collect_bookmarks(child, bookmarks)

    def get_all_bookmarks_with_paths(self):
        """
        Return a list of all bookmarks in the workspace,
        along with their full paths.
        """
        bookmarks_with_paths = []
        self._collect_bookmarks_with_paths(self.root, "", bookmarks_with_paths)
        return bookmarks_with_paths

    def _collect_bookmarks_with_paths(self, node, current_path, bookmarks_with_paths):
        """
        Recursively collect all bookmarks along with their paths.
        """
        # Update the current path
        new_path = f"{current_path}/{node.name}" if current_path else node.name

        if node.is_bookmark():
            # Add the bookmark and its path to the list
            bookmarks_with_paths.append(
                {
                    "name": node.name,
                    "path": new_path.removeprefix('root'),
                    "description": node.description,
                    "formats": node.formats,
                }
            )
        elif node.is_folder():
            # Recursively process folder items
            for child in node.items:
                self._collect_bookmarks_with_paths(
                    child, new_path, bookmarks_with_paths
                )

    @classmethod
    def read_from_file(cls, file_path):
        """Read JSON data from a file and create a Workspace instance."""
        with open(file_path, "r", encoding="utf-8") as file:
            json_data = json.load(file)
        return cls(json_data)

    def write_to_file(self, file_path):
        """Write the workspace structure to a file as JSON."""
        with open(file_path, "w", encoding="utf-8") as file:
            json.dump(self.to_dict(), file, indent=2)
