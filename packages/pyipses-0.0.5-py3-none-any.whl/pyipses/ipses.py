from .utils import _parse_user_info, get_from_url, download_file, download_file_large
from .workspace import Workspace
from .workspace_service import WorkspaceService


class Ipses:
    USER_INFO_FILE = "./secret.py"

    def __new__(cls, *args, **kwargs):
        raise TypeError(f"{cls.__name__} cannot be instantiated.")

    @classmethod
    def get_workspace(cls, user_info_file: str = USER_INFO_FILE) -> Workspace:
        """
        Retrieve a workspace data structure from a remote service

        Parameters:
        - user_info_file: str, the file name containing the details for the remote service.
        """
        if user_info_file is not None:
            user_info, service_url = _parse_user_info(user_info_file)
            if service_url is not None:
                ipses_userservice = WorkspaceService(service_url)
                data = ipses_userservice.get_data_from_service(user_info)
                return Workspace(data)
        return Workspace()

    @classmethod
    def write_workspace(cls, workspace: Workspace = None, afile: str = None):
        """
        Write a workspace data structure in json format to a file.

        Parameters:
        - workspace: Workspace, the workspace object.
        - user_info_file: str, the name for the json file.
        """

        if workspace is not None and afile is not None:
            workspace.write_to_file(afile)

    @classmethod
    def read_workspace(cls, afile: str = None) -> Workspace:
        """
        Retrieve a workspace data structure from a json file.

        Parameters:
        - afile: str, the name of the json file containing the workspace data.
        """

        if afile is not None:
            return Workspace.read_from_file(afile)
        return Workspace()

    @classmethod
    def download_data(cls, url: str) -> str:
        """
        Download data from a remote service, as a string.

        Parameters:
        - url: str, the url for the service (includes possible parameter).
        """

        return get_from_url(url)

    @classmethod
    def download_data_to_file(cls, url: str, output_file: str) -> None:
        """
        Download data from a remote service, as a string, to a local file.

        Parameters:
        - url: str, the url for the service (includes possible parameter).
        - output_file: str, the name for the file where the downloaded data will be saved.
        """

        download_file(url, output_file)

    @classmethod
    def _download_data_large_to_file(cls, url: str, output_file: str) -> None:
        download_file_large(url, output_file)
