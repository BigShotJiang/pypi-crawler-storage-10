import tomllib
from pathlib import Path


def get_version(file: str) -> str:
    p = Path(file)
    while not (pyproj := p / "pyproject.toml").exists():
        p = p.parent

    project_info = tomllib.loads(pyproj.read_text())
    return project_info["project"]["version"]