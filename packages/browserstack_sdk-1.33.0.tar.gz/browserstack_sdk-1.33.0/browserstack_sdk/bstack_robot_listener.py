# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import os
import threading
from uuid import uuid4
from itertools import zip_longest
from collections import OrderedDict
from robot.libraries.BuiltIn import BuiltIn
from browserstack_sdk.bstack1111lll111_opy_ import RobotHandler
from bstack_utils.capture import bstack111lll1111_opy_
from bstack_utils.bstack111ll1l1ll_opy_ import bstack111l1111ll_opy_, bstack111ll1l1l1_opy_, bstack111l1ll1l1_opy_
from bstack_utils.bstack111ll1llll_opy_ import bstack11l11ll1l1_opy_
from bstack_utils.bstack111ll1ll11_opy_ import bstack1l111l111l_opy_
from bstack_utils.constants import *
from bstack_utils.helper import bstack11l1l1lll_opy_, bstack1l11l1llll_opy_, Result, \
    error_handler, bstack111l1l1111_opy_
class bstack_robot_listener:
    ROBOT_LISTENER_API_VERSION = 2
    _lock = threading.Lock()
    store = {
        bstack1ll1lll_opy_ (u"ࠨࡥࡸࡶࡷ࡫࡮ࡵࡡ࡫ࡳࡴࡱ࡟ࡶࡷ࡬ࡨࠬྉ"): [],
        bstack1ll1lll_opy_ (u"ࠩࡪࡰࡴࡨࡡ࡭ࡡ࡫ࡳࡴࡱࡳࠨྊ"): [],
        bstack1ll1lll_opy_ (u"ࠪࡸࡪࡹࡴࡠࡪࡲࡳࡰࡹࠧྋ"): []
    }
    bstack111l11ll11_opy_ = []
    bstack111l1l1lll_opy_ = []
    @staticmethod
    def bstack111ll1l11l_opy_(log):
        if not ((isinstance(log[bstack1ll1lll_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬྌ")], list) or (isinstance(log[bstack1ll1lll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ྍ")], dict)) and len(log[bstack1ll1lll_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧྎ")])>0) or (isinstance(log[bstack1ll1lll_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨྏ")], str) and log[bstack1ll1lll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩྐ")].strip())):
            return
        active = bstack11l11ll1l1_opy_.bstack111ll111l1_opy_()
        log = {
            bstack1ll1lll_opy_ (u"ࠩ࡯ࡩࡻ࡫࡬ࠨྑ"): log[bstack1ll1lll_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩྒ")],
            bstack1ll1lll_opy_ (u"ࠫࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧྒྷ"): bstack111l1l1111_opy_().isoformat() + bstack1ll1lll_opy_ (u"ࠬࡠࠧྔ"),
            bstack1ll1lll_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧྕ"): log[bstack1ll1lll_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨྖ")],
        }
        if active:
            if active[bstack1ll1lll_opy_ (u"ࠨࡶࡼࡴࡪ࠭ྗ")] == bstack1ll1lll_opy_ (u"ࠩ࡫ࡳࡴࡱࠧ྘"):
                log[bstack1ll1lll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪྙ")] = active[bstack1ll1lll_opy_ (u"ࠫ࡭ࡵ࡯࡬ࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫྚ")]
            elif active[bstack1ll1lll_opy_ (u"ࠬࡺࡹࡱࡧࠪྛ")] == bstack1ll1lll_opy_ (u"࠭ࡴࡦࡵࡷࠫྜ"):
                log[bstack1ll1lll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧྜྷ")] = active[bstack1ll1lll_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨྞ")]
        bstack1l111l111l_opy_.bstack1lll11l1_opy_([log])
    def __init__(self):
        self.messages = bstack1111lll1ll_opy_()
        self._1111l1l1l1_opy_ = None
        self._1111l1llll_opy_ = None
        self._1111l1ll1l_opy_ = OrderedDict()
        self.bstack111ll11ll1_opy_ = bstack111lll1111_opy_(self.bstack111ll1l11l_opy_)
    @error_handler(class_method=True)
    def start_suite(self, name, attrs):
        self.messages.bstack1111l1ll11_opy_()
        if not self._1111l1ll1l_opy_.get(attrs.get(bstack1ll1lll_opy_ (u"ࠩ࡬ࡨࠬྟ")), None):
            self._1111l1ll1l_opy_[attrs.get(bstack1ll1lll_opy_ (u"ࠪ࡭ࡩ࠭ྠ"))] = {}
        bstack111l11llll_opy_ = bstack111l1ll1l1_opy_(
                bstack111l11l1ll_opy_=attrs.get(bstack1ll1lll_opy_ (u"ࠫ࡮ࡪࠧྡ")),
                name=name,
                started_at=bstack1l11l1llll_opy_(),
                file_path=os.path.relpath(attrs[bstack1ll1lll_opy_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠬྡྷ")], start=os.getcwd()) if attrs.get(bstack1ll1lll_opy_ (u"࠭ࡳࡰࡷࡵࡧࡪ࠭ྣ")) != bstack1ll1lll_opy_ (u"ࠧࠨྤ") else bstack1ll1lll_opy_ (u"ࠨࠩྥ"),
                framework=bstack1ll1lll_opy_ (u"ࠩࡕࡳࡧࡵࡴࠨྦ")
            )
        threading.current_thread().current_suite_id = attrs.get(bstack1ll1lll_opy_ (u"ࠪ࡭ࡩ࠭ྦྷ"), None)
        self._1111l1ll1l_opy_[attrs.get(bstack1ll1lll_opy_ (u"ࠫ࡮ࡪࠧྨ"))][bstack1ll1lll_opy_ (u"ࠬࡺࡥࡴࡶࡢࡨࡦࡺࡡࠨྩ")] = bstack111l11llll_opy_
    @error_handler(class_method=True)
    def end_suite(self, name, attrs):
        messages = self.messages.bstack111l111l11_opy_()
        self._1111llllll_opy_(messages)
        with self._lock:
            for bstack111l111ll1_opy_ in self.bstack111l11ll11_opy_:
                bstack111l111ll1_opy_[bstack1ll1lll_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࠨྪ")][bstack1ll1lll_opy_ (u"ࠧࡩࡱࡲ࡯ࡸ࠭ྫ")].extend(self.store[bstack1ll1lll_opy_ (u"ࠨࡩ࡯ࡳࡧࡧ࡬ࡠࡪࡲࡳࡰࡹࠧྫྷ")])
                bstack1l111l111l_opy_.bstack1l1111l11_opy_(bstack111l111ll1_opy_)
            self.bstack111l11ll11_opy_ = []
            self.store[bstack1ll1lll_opy_ (u"ࠩࡪࡰࡴࡨࡡ࡭ࡡ࡫ࡳࡴࡱࡳࠨྭ")] = []
    @error_handler(class_method=True)
    def start_test(self, name, attrs):
        self.bstack111ll11ll1_opy_.start()
        if not self._1111l1ll1l_opy_.get(attrs.get(bstack1ll1lll_opy_ (u"ࠪ࡭ࡩ࠭ྮ")), None):
            self._1111l1ll1l_opy_[attrs.get(bstack1ll1lll_opy_ (u"ࠫ࡮ࡪࠧྯ"))] = {}
        driver = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯ࡘ࡫ࡳࡴ࡫ࡲࡲࡉࡸࡩࡷࡧࡵࠫྰ"), None)
        bstack111ll1l1ll_opy_ = bstack111l1ll1l1_opy_(
            bstack111l11l1ll_opy_=attrs.get(bstack1ll1lll_opy_ (u"࠭ࡩࡥࠩྱ")),
            name=name,
            started_at=bstack1l11l1llll_opy_(),
            file_path=os.path.relpath(attrs[bstack1ll1lll_opy_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠧྲ")], start=os.getcwd()),
            scope=RobotHandler.bstack111l11l11l_opy_(attrs.get(bstack1ll1lll_opy_ (u"ࠨࡵࡲࡹࡷࡩࡥࠨླ"), None)),
            framework=bstack1ll1lll_opy_ (u"ࠩࡕࡳࡧࡵࡴࠨྴ"),
            tags=attrs[bstack1ll1lll_opy_ (u"ࠪࡸࡦ࡭ࡳࠨྵ")],
            hooks=self.store[bstack1ll1lll_opy_ (u"ࠫ࡬ࡲ࡯ࡣࡣ࡯ࡣ࡭ࡵ࡯࡬ࡵࠪྶ")],
            bstack111ll1ll1l_opy_=bstack1l111l111l_opy_.bstack111ll11111_opy_(driver) if driver and driver.session_id else {},
            meta={},
            code=bstack1ll1lll_opy_ (u"ࠧࢁࡽࠡ࡞ࡱࠤࢀࢃࠢྷ").format(bstack1ll1lll_opy_ (u"ࠨࠠࠣྸ").join(attrs[bstack1ll1lll_opy_ (u"ࠧࡵࡣࡪࡷࠬྐྵ")]), name) if attrs[bstack1ll1lll_opy_ (u"ࠨࡶࡤ࡫ࡸ࠭ྺ")] else name
        )
        self._1111l1ll1l_opy_[attrs.get(bstack1ll1lll_opy_ (u"ࠩ࡬ࡨࠬྻ"))][bstack1ll1lll_opy_ (u"ࠪࡸࡪࡹࡴࡠࡦࡤࡸࡦ࠭ྼ")] = bstack111ll1l1ll_opy_
        threading.current_thread().current_test_uuid = bstack111ll1l1ll_opy_.bstack1111ll1l1l_opy_()
        threading.current_thread().current_test_id = attrs.get(bstack1ll1lll_opy_ (u"ࠫ࡮ࡪࠧ྽"), None)
        self.bstack111l1llll1_opy_(bstack1ll1lll_opy_ (u"࡚ࠬࡥࡴࡶࡕࡹࡳ࡙ࡴࡢࡴࡷࡩࡩ࠭྾"), bstack111ll1l1ll_opy_)
    @error_handler(class_method=True)
    def end_test(self, name, attrs):
        self.bstack111ll11ll1_opy_.reset()
        bstack1111l1lll1_opy_ = bstack111l1l111l_opy_.get(attrs.get(bstack1ll1lll_opy_ (u"࠭ࡳࡵࡣࡷࡹࡸ࠭྿")), bstack1ll1lll_opy_ (u"ࠧࡴ࡭࡬ࡴࡵ࡫ࡤࠨ࿀"))
        self._1111l1ll1l_opy_[attrs.get(bstack1ll1lll_opy_ (u"ࠨ࡫ࡧࠫ࿁"))][bstack1ll1lll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡥࡣࡷࡥࠬ࿂")].stop(time=bstack1l11l1llll_opy_(), duration=int(attrs.get(bstack1ll1lll_opy_ (u"ࠪࡩࡱࡧࡰࡴࡧࡧࡸ࡮ࡳࡥࠨ࿃"), bstack1ll1lll_opy_ (u"ࠫ࠵࠭࿄"))), result=Result(result=bstack1111l1lll1_opy_, exception=attrs.get(bstack1ll1lll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭࿅")), bstack111l1lllll_opy_=[attrs.get(bstack1ll1lll_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫࿆ࠧ"))]))
        self.bstack111l1llll1_opy_(bstack1ll1lll_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡇ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩ࿇"), self._1111l1ll1l_opy_[attrs.get(bstack1ll1lll_opy_ (u"ࠨ࡫ࡧࠫ࿈"))][bstack1ll1lll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡥࡣࡷࡥࠬ࿉")], True)
        with self._lock:
            self.store[bstack1ll1lll_opy_ (u"ࠪࡸࡪࡹࡴࡠࡪࡲࡳࡰࡹࠧ࿊")] = []
        threading.current_thread().current_test_uuid = None
        threading.current_thread().current_test_id = None
    @error_handler(class_method=True)
    def start_keyword(self, name, attrs):
        self.messages.bstack1111l1ll11_opy_()
        current_test_id = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤࡺࡥࡴࡶࡢ࡭ࡩ࠭࿋"), None)
        bstack111l1l11ll_opy_ = current_test_id if bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡥࡴࡦࡵࡷࡣ࡮ࡪࠧ࿌"), None) else bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"࠭ࡣࡶࡴࡵࡩࡳࡺ࡟ࡴࡷ࡬ࡸࡪࡥࡩࡥࠩ࿍"), None)
        if attrs.get(bstack1ll1lll_opy_ (u"ࠧࡵࡻࡳࡩࠬ࿎"), bstack1ll1lll_opy_ (u"ࠨࠩ࿏")).lower() in [bstack1ll1lll_opy_ (u"ࠩࡶࡩࡹࡻࡰࠨ࿐"), bstack1ll1lll_opy_ (u"ࠪࡸࡪࡧࡲࡥࡱࡺࡲࠬ࿑")]:
            hook_type = bstack111l1ll111_opy_(attrs.get(bstack1ll1lll_opy_ (u"ࠫࡹࡿࡰࡦࠩ࿒")), bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡥࡴࡦࡵࡷࡣࡺࡻࡩࡥࠩ࿓"), None))
            hook_name = bstack1ll1lll_opy_ (u"࠭ࡻࡾࠩ࿔").format(attrs.get(bstack1ll1lll_opy_ (u"ࠧ࡬ࡹࡱࡥࡲ࡫ࠧ࿕"), bstack1ll1lll_opy_ (u"ࠨࠩ࿖")))
            if hook_type in [bstack1ll1lll_opy_ (u"ࠩࡅࡉࡋࡕࡒࡆࡡࡄࡐࡑ࠭࿗"), bstack1ll1lll_opy_ (u"ࠪࡅࡋ࡚ࡅࡓࡡࡄࡐࡑ࠭࿘")]:
                hook_name = bstack1ll1lll_opy_ (u"ࠫࡠࢁࡽ࡞ࠢࡾࢁࠬ࿙").format(bstack1111ll11l1_opy_.get(hook_type), attrs.get(bstack1ll1lll_opy_ (u"ࠬࡱࡷ࡯ࡣࡰࡩࠬ࿚"), bstack1ll1lll_opy_ (u"࠭ࠧ࿛")))
            bstack1111ll1lll_opy_ = bstack111ll1l1l1_opy_(
                bstack111l11l1ll_opy_=bstack111l1l11ll_opy_ + bstack1ll1lll_opy_ (u"ࠧ࠮ࠩ࿜") + attrs.get(bstack1ll1lll_opy_ (u"ࠨࡶࡼࡴࡪ࠭࿝"), bstack1ll1lll_opy_ (u"ࠩࠪ࿞")).lower(),
                name=hook_name,
                started_at=bstack1l11l1llll_opy_(),
                file_path=os.path.relpath(attrs.get(bstack1ll1lll_opy_ (u"ࠪࡷࡴࡻࡲࡤࡧࠪ࿟")), start=os.getcwd()),
                framework=bstack1ll1lll_opy_ (u"ࠫࡗࡵࡢࡰࡶࠪ࿠"),
                tags=attrs[bstack1ll1lll_opy_ (u"ࠬࡺࡡࡨࡵࠪ࿡")],
                scope=RobotHandler.bstack111l11l11l_opy_(attrs.get(bstack1ll1lll_opy_ (u"࠭ࡳࡰࡷࡵࡧࡪ࠭࿢"), None)),
                hook_type=hook_type,
                meta={}
            )
            threading.current_thread().current_hook_uuid = bstack1111ll1lll_opy_.bstack1111ll1l1l_opy_()
            threading.current_thread().current_hook_id = bstack111l1l11ll_opy_ + bstack1ll1lll_opy_ (u"ࠧ࠮ࠩ࿣") + attrs.get(bstack1ll1lll_opy_ (u"ࠨࡶࡼࡴࡪ࠭࿤"), bstack1ll1lll_opy_ (u"ࠩࠪ࿥")).lower()
            with self._lock:
                self.store[bstack1ll1lll_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣ࡭ࡵ࡯࡬ࡡࡸࡹ࡮ࡪࠧ࿦")] = [bstack1111ll1lll_opy_.bstack1111ll1l1l_opy_()]
                if bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤࡺࡥࡴࡶࡢࡹࡺ࡯ࡤࠨ࿧"), None):
                    self.store[bstack1ll1lll_opy_ (u"ࠬࡺࡥࡴࡶࡢ࡬ࡴࡵ࡫ࡴࠩ࿨")].append(bstack1111ll1lll_opy_.bstack1111ll1l1l_opy_())
                else:
                    self.store[bstack1ll1lll_opy_ (u"࠭ࡧ࡭ࡱࡥࡥࡱࡥࡨࡰࡱ࡮ࡷࠬ࿩")].append(bstack1111ll1lll_opy_.bstack1111ll1l1l_opy_())
            if bstack111l1l11ll_opy_:
                self._1111l1ll1l_opy_[bstack111l1l11ll_opy_ + bstack1ll1lll_opy_ (u"ࠧ࠮ࠩ࿪") + attrs.get(bstack1ll1lll_opy_ (u"ࠨࡶࡼࡴࡪ࠭࿫"), bstack1ll1lll_opy_ (u"ࠩࠪ࿬")).lower()] = { bstack1ll1lll_opy_ (u"ࠪࡸࡪࡹࡴࡠࡦࡤࡸࡦ࠭࿭"): bstack1111ll1lll_opy_ }
            bstack1l111l111l_opy_.bstack111l1llll1_opy_(bstack1ll1lll_opy_ (u"ࠫࡍࡵ࡯࡬ࡔࡸࡲࡘࡺࡡࡳࡶࡨࡨࠬ࿮"), bstack1111ll1lll_opy_)
        else:
            bstack111l1ll1ll_opy_ = {
                bstack1ll1lll_opy_ (u"ࠬ࡯ࡤࠨ࿯"): uuid4().__str__(),
                bstack1ll1lll_opy_ (u"࠭ࡴࡦࡺࡷࠫ࿰"): bstack1ll1lll_opy_ (u"ࠧࡼࡿࠣࡿࢂ࠭࿱").format(attrs.get(bstack1ll1lll_opy_ (u"ࠨ࡭ࡺࡲࡦࡳࡥࠨ࿲")), attrs.get(bstack1ll1lll_opy_ (u"ࠩࡤࡶ࡬ࡹࠧ࿳"), bstack1ll1lll_opy_ (u"ࠪࠫ࿴"))) if attrs.get(bstack1ll1lll_opy_ (u"ࠫࡦࡸࡧࡴࠩ࿵"), []) else attrs.get(bstack1ll1lll_opy_ (u"ࠬࡱࡷ࡯ࡣࡰࡩࠬ࿶")),
                bstack1ll1lll_opy_ (u"࠭ࡳࡵࡧࡳࡣࡦࡸࡧࡶ࡯ࡨࡲࡹ࠭࿷"): attrs.get(bstack1ll1lll_opy_ (u"ࠧࡢࡴࡪࡷࠬ࿸"), []),
                bstack1ll1lll_opy_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࡡࡤࡸࠬ࿹"): bstack1l11l1llll_opy_(),
                bstack1ll1lll_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩ࿺"): bstack1ll1lll_opy_ (u"ࠪࡴࡪࡴࡤࡪࡰࡪࠫ࿻"),
                bstack1ll1lll_opy_ (u"ࠫࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠩ࿼"): attrs.get(bstack1ll1lll_opy_ (u"ࠬࡪ࡯ࡤࠩ࿽"), bstack1ll1lll_opy_ (u"࠭ࠧ࿾"))
            }
            if attrs.get(bstack1ll1lll_opy_ (u"ࠧ࡭࡫ࡥࡲࡦࡳࡥࠨ࿿"), bstack1ll1lll_opy_ (u"ࠨࠩက")) != bstack1ll1lll_opy_ (u"ࠩࠪခ"):
                bstack111l1ll1ll_opy_[bstack1ll1lll_opy_ (u"ࠪ࡯ࡪࡿࡷࡰࡴࡧࠫဂ")] = attrs.get(bstack1ll1lll_opy_ (u"ࠫࡱ࡯ࡢ࡯ࡣࡰࡩࠬဃ"))
            if not self.bstack111l1l1lll_opy_:
                self._1111l1ll1l_opy_[self._1111ll1111_opy_()][bstack1ll1lll_opy_ (u"ࠬࡺࡥࡴࡶࡢࡨࡦࡺࡡࠨင")].add_step(bstack111l1ll1ll_opy_)
                threading.current_thread().current_step_uuid = bstack111l1ll1ll_opy_[bstack1ll1lll_opy_ (u"࠭ࡩࡥࠩစ")]
            self.bstack111l1l1lll_opy_.append(bstack111l1ll1ll_opy_)
    @error_handler(class_method=True)
    def end_keyword(self, name, attrs):
        messages = self.messages.bstack111l111l11_opy_()
        self._1111llllll_opy_(messages)
        current_test_id = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠧࡤࡷࡵࡶࡪࡴࡴࡠࡶࡨࡷࡹࡥࡩࡥࠩဆ"), None)
        bstack111l1l11ll_opy_ = current_test_id if current_test_id else bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠨࡥࡸࡶࡷ࡫࡮ࡵࡡࡶࡹ࡮ࡺࡥࡠ࡫ࡧࠫဇ"), None)
        bstack1111lllll1_opy_ = bstack111l1l111l_opy_.get(attrs.get(bstack1ll1lll_opy_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩဈ")), bstack1ll1lll_opy_ (u"ࠪࡷࡰ࡯ࡰࡱࡧࡧࠫဉ"))
        bstack111l11ll1l_opy_ = attrs.get(bstack1ll1lll_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬည"))
        if bstack1111lllll1_opy_ != bstack1ll1lll_opy_ (u"ࠬࡹ࡫ࡪࡲࡳࡩࡩ࠭ဋ") and not attrs.get(bstack1ll1lll_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧဌ")) and self._1111l1l1l1_opy_:
            bstack111l11ll1l_opy_ = self._1111l1l1l1_opy_
        bstack111l1lll1l_opy_ = Result(result=bstack1111lllll1_opy_, exception=bstack111l11ll1l_opy_, bstack111l1lllll_opy_=[bstack111l11ll1l_opy_])
        if attrs.get(bstack1ll1lll_opy_ (u"ࠧࡵࡻࡳࡩࠬဍ"), bstack1ll1lll_opy_ (u"ࠨࠩဎ")).lower() in [bstack1ll1lll_opy_ (u"ࠩࡶࡩࡹࡻࡰࠨဏ"), bstack1ll1lll_opy_ (u"ࠪࡸࡪࡧࡲࡥࡱࡺࡲࠬတ")]:
            bstack111l1l11ll_opy_ = current_test_id if current_test_id else bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤࡹࡵࡪࡶࡨࡣ࡮ࡪࠧထ"), None)
            if bstack111l1l11ll_opy_:
                bstack111l1lll11_opy_ = bstack111l1l11ll_opy_ + bstack1ll1lll_opy_ (u"ࠧ࠳ࠢဒ") + attrs.get(bstack1ll1lll_opy_ (u"࠭ࡴࡺࡲࡨࠫဓ"), bstack1ll1lll_opy_ (u"ࠧࠨန")).lower()
                self._1111l1ll1l_opy_[bstack111l1lll11_opy_][bstack1ll1lll_opy_ (u"ࠨࡶࡨࡷࡹࡥࡤࡢࡶࡤࠫပ")].stop(time=bstack1l11l1llll_opy_(), duration=int(attrs.get(bstack1ll1lll_opy_ (u"ࠩࡨࡰࡦࡶࡳࡦࡦࡷ࡭ࡲ࡫ࠧဖ"), bstack1ll1lll_opy_ (u"ࠪ࠴ࠬဗ"))), result=bstack111l1lll1l_opy_)
                bstack1l111l111l_opy_.bstack111l1llll1_opy_(bstack1ll1lll_opy_ (u"ࠫࡍࡵ࡯࡬ࡔࡸࡲࡋ࡯࡮ࡪࡵ࡫ࡩࡩ࠭ဘ"), self._1111l1ll1l_opy_[bstack111l1lll11_opy_][bstack1ll1lll_opy_ (u"ࠬࡺࡥࡴࡶࡢࡨࡦࡺࡡࠨမ")])
        else:
            bstack111l1l11ll_opy_ = current_test_id if current_test_id else bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"࠭ࡣࡶࡴࡵࡩࡳࡺ࡟ࡩࡱࡲ࡯ࡤ࡯ࡤࠨယ"), None)
            if bstack111l1l11ll_opy_ and len(self.bstack111l1l1lll_opy_) == 1:
                current_step_uuid = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠧࡤࡷࡵࡶࡪࡴࡴࡠࡵࡷࡩࡵࡥࡵࡶ࡫ࡧࠫရ"), None)
                self._1111l1ll1l_opy_[bstack111l1l11ll_opy_][bstack1ll1lll_opy_ (u"ࠨࡶࡨࡷࡹࡥࡤࡢࡶࡤࠫလ")].bstack111ll111ll_opy_(current_step_uuid, duration=int(attrs.get(bstack1ll1lll_opy_ (u"ࠩࡨࡰࡦࡶࡳࡦࡦࡷ࡭ࡲ࡫ࠧဝ"), bstack1ll1lll_opy_ (u"ࠪ࠴ࠬသ"))), result=bstack111l1lll1l_opy_)
            else:
                self.bstack111l1l11l1_opy_(attrs)
            self.bstack111l1l1lll_opy_.pop()
    def log_message(self, message):
        try:
            if message.get(bstack1ll1lll_opy_ (u"ࠫ࡭ࡺ࡭࡭ࠩဟ"), bstack1ll1lll_opy_ (u"ࠬࡴ࡯ࠨဠ")) == bstack1ll1lll_opy_ (u"࠭ࡹࡦࡵࠪအ"):
                return
            self.messages.push(message)
            logs = []
            if bstack11l11ll1l1_opy_.bstack111ll111l1_opy_():
                logs.append({
                    bstack1ll1lll_opy_ (u"ࠧࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪဢ"): bstack1l11l1llll_opy_(),
                    bstack1ll1lll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩဣ"): message.get(bstack1ll1lll_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪဤ")),
                    bstack1ll1lll_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩဥ"): message.get(bstack1ll1lll_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪဦ")),
                    **bstack11l11ll1l1_opy_.bstack111ll111l1_opy_()
                })
                if len(logs) > 0:
                    bstack1l111l111l_opy_.bstack1lll11l1_opy_(logs)
        except Exception as err:
            pass
    def close(self):
        bstack1l111l111l_opy_.bstack111l1l1l1l_opy_()
    def bstack111l1l11l1_opy_(self, bstack111l11lll1_opy_):
        if not bstack11l11ll1l1_opy_.bstack111ll111l1_opy_():
            return
        kwname = bstack1ll1lll_opy_ (u"ࠬࢁࡽࠡࡽࢀࠫဧ").format(bstack111l11lll1_opy_.get(bstack1ll1lll_opy_ (u"࠭࡫ࡸࡰࡤࡱࡪ࠭ဨ")), bstack111l11lll1_opy_.get(bstack1ll1lll_opy_ (u"ࠧࡢࡴࡪࡷࠬဩ"), bstack1ll1lll_opy_ (u"ࠨࠩဪ"))) if bstack111l11lll1_opy_.get(bstack1ll1lll_opy_ (u"ࠩࡤࡶ࡬ࡹࠧါ"), []) else bstack111l11lll1_opy_.get(bstack1ll1lll_opy_ (u"ࠪ࡯ࡼࡴࡡ࡮ࡧࠪာ"))
        error_message = bstack1ll1lll_opy_ (u"ࠦࡰࡽ࡮ࡢ࡯ࡨ࠾ࠥࡢࠢࡼ࠲ࢀࡠࠧࠦࡼࠡࡵࡷࡥࡹࡻࡳ࠻ࠢ࡟ࠦࢀ࠷ࡽ࡝ࠤࠣࢀࠥ࡫ࡸࡤࡧࡳࡸ࡮ࡵ࡮࠻ࠢ࡟ࠦࢀ࠸ࡽ࡝ࠤࠥိ").format(kwname, bstack111l11lll1_opy_.get(bstack1ll1lll_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬီ")), str(bstack111l11lll1_opy_.get(bstack1ll1lll_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧု"))))
        bstack1111ll11ll_opy_ = bstack1ll1lll_opy_ (u"ࠢ࡬ࡹࡱࡥࡲ࡫࠺ࠡ࡞ࠥࡿ࠵ࢃ࡜ࠣࠢࡿࠤࡸࡺࡡࡵࡷࡶ࠾ࠥࡢࠢࡼ࠳ࢀࡠࠧࠨူ").format(kwname, bstack111l11lll1_opy_.get(bstack1ll1lll_opy_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨေ")))
        bstack1111lll1l1_opy_ = error_message if bstack111l11lll1_opy_.get(bstack1ll1lll_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪဲ")) else bstack1111ll11ll_opy_
        bstack111l1l1l11_opy_ = {
            bstack1ll1lll_opy_ (u"ࠪࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭ဳ"): self.bstack111l1l1lll_opy_[-1].get(bstack1ll1lll_opy_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࡤࡧࡴࠨဴ"), bstack1l11l1llll_opy_()),
            bstack1ll1lll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ဵ"): bstack1111lll1l1_opy_,
            bstack1ll1lll_opy_ (u"࠭࡬ࡦࡸࡨࡰࠬံ"): bstack1ll1lll_opy_ (u"ࠧࡆࡔࡕࡓࡗ့࠭") if bstack111l11lll1_opy_.get(bstack1ll1lll_opy_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨး")) == bstack1ll1lll_opy_ (u"ࠩࡉࡅࡎࡒ္ࠧ") else bstack1ll1lll_opy_ (u"ࠪࡍࡓࡌࡏࠨ်"),
            **bstack11l11ll1l1_opy_.bstack111ll111l1_opy_()
        }
        bstack1l111l111l_opy_.bstack1lll11l1_opy_([bstack111l1l1l11_opy_])
    def _1111ll1111_opy_(self):
        for bstack111l11l1ll_opy_ in reversed(self._1111l1ll1l_opy_):
            bstack111l111l1l_opy_ = bstack111l11l1ll_opy_
            data = self._1111l1ll1l_opy_[bstack111l11l1ll_opy_][bstack1ll1lll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡧࡥࡹࡧࠧျ")]
            if isinstance(data, bstack111ll1l1l1_opy_):
                if not bstack1ll1lll_opy_ (u"ࠬࡋࡁࡄࡊࠪြ") in data.bstack111l111111_opy_():
                    return bstack111l111l1l_opy_
            else:
                return bstack111l111l1l_opy_
    def _1111llllll_opy_(self, messages):
        try:
            bstack1111ll1l11_opy_ = BuiltIn().get_variable_value(bstack1ll1lll_opy_ (u"ࠨࠤࡼࡎࡒࡋࠥࡒࡅࡗࡇࡏࢁࠧွ")) in (bstack111l1l1ll1_opy_.DEBUG, bstack111l1l1ll1_opy_.TRACE)
            for message, bstack111l11l111_opy_ in zip_longest(messages, messages[1:]):
                name = message.get(bstack1ll1lll_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨှ"))
                level = message.get(bstack1ll1lll_opy_ (u"ࠨ࡮ࡨࡺࡪࡲࠧဿ"))
                if level == bstack111l1l1ll1_opy_.FAIL:
                    self._1111l1l1l1_opy_ = name or self._1111l1l1l1_opy_
                    self._1111l1llll_opy_ = bstack111l11l111_opy_.get(bstack1ll1lll_opy_ (u"ࠤࡰࡩࡸࡹࡡࡨࡧࠥ၀")) if bstack1111ll1l11_opy_ and bstack111l11l111_opy_ else self._1111l1llll_opy_
        except:
            pass
    @classmethod
    def bstack111l1llll1_opy_(self, event: str, bstack1111ll1ll1_opy_: bstack111l1111ll_opy_, bstack1111l1l1ll_opy_=False):
        if event == bstack1ll1lll_opy_ (u"ࠪࡘࡪࡹࡴࡓࡷࡱࡊ࡮ࡴࡩࡴࡪࡨࡨࠬ၁"):
            bstack1111ll1ll1_opy_.set(hooks=self.store[bstack1ll1lll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡ࡫ࡳࡴࡱࡳࠨ၂")])
        if event == bstack1ll1lll_opy_ (u"࡚ࠬࡥࡴࡶࡕࡹࡳ࡙࡫ࡪࡲࡳࡩࡩ࠭၃"):
            event = bstack1ll1lll_opy_ (u"࠭ࡔࡦࡵࡷࡖࡺࡴࡆࡪࡰ࡬ࡷ࡭࡫ࡤࠨ၄")
        if bstack1111l1l1ll_opy_:
            bstack1111llll11_opy_ = {
                bstack1ll1lll_opy_ (u"ࠧࡦࡸࡨࡲࡹࡥࡴࡺࡲࡨࠫ၅"): event,
                bstack1111ll1ll1_opy_.bstack111l11111l_opy_(): bstack1111ll1ll1_opy_.bstack1111lll11l_opy_(event)
            }
            with self._lock:
                self.bstack111l11ll11_opy_.append(bstack1111llll11_opy_)
        else:
            bstack1l111l111l_opy_.bstack111l1llll1_opy_(event, bstack1111ll1ll1_opy_)
class bstack1111lll1ll_opy_:
    def __init__(self):
        self._111l111lll_opy_ = []
    def bstack1111l1ll11_opy_(self):
        self._111l111lll_opy_.append([])
    def bstack111l111l11_opy_(self):
        return self._111l111lll_opy_.pop() if self._111l111lll_opy_ else list()
    def push(self, message):
        self._111l111lll_opy_[-1].append(message) if self._111l111lll_opy_ else self._111l111lll_opy_.append([message])
class bstack111l1l1ll1_opy_:
    FAIL = bstack1ll1lll_opy_ (u"ࠨࡈࡄࡍࡑ࠭၆")
    ERROR = bstack1ll1lll_opy_ (u"ࠩࡈࡖࡗࡕࡒࠨ၇")
    WARNING = bstack1ll1lll_opy_ (u"࡛ࠪࡆࡘࡎࠨ၈")
    bstack1111ll111l_opy_ = bstack1ll1lll_opy_ (u"ࠫࡎࡔࡆࡐࠩ၉")
    DEBUG = bstack1ll1lll_opy_ (u"ࠬࡊࡅࡃࡗࡊࠫ၊")
    TRACE = bstack1ll1lll_opy_ (u"࠭ࡔࡓࡃࡆࡉࠬ။")
    bstack111l11l1l1_opy_ = [FAIL, ERROR]
def bstack111l1111l1_opy_(bstack1111llll1l_opy_):
    if not bstack1111llll1l_opy_:
        return None
    if bstack1111llll1l_opy_.get(bstack1ll1lll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡪࡡࡵࡣࠪ၌"), None):
        return getattr(bstack1111llll1l_opy_[bstack1ll1lll_opy_ (u"ࠨࡶࡨࡷࡹࡥࡤࡢࡶࡤࠫ၍")], bstack1ll1lll_opy_ (u"ࠩࡸࡹ࡮ࡪࠧ၎"), None)
    return bstack1111llll1l_opy_.get(bstack1ll1lll_opy_ (u"ࠪࡹࡺ࡯ࡤࠨ၏"), None)
def bstack111l1ll111_opy_(hook_type, current_test_uuid):
    if hook_type.lower() not in [bstack1ll1lll_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࠪၐ"), bstack1ll1lll_opy_ (u"ࠬࡺࡥࡢࡴࡧࡳࡼࡴࠧၑ")]:
        return
    if hook_type.lower() == bstack1ll1lll_opy_ (u"࠭ࡳࡦࡶࡸࡴࠬၒ"):
        if current_test_uuid is None:
            return bstack1ll1lll_opy_ (u"ࠧࡃࡇࡉࡓࡗࡋ࡟ࡂࡎࡏࠫၓ")
        else:
            return bstack1ll1lll_opy_ (u"ࠨࡄࡈࡊࡔࡘࡅࡠࡇࡄࡇࡍ࠭ၔ")
    elif hook_type.lower() == bstack1ll1lll_opy_ (u"ࠩࡷࡩࡦࡸࡤࡰࡹࡱࠫၕ"):
        if current_test_uuid is None:
            return bstack1ll1lll_opy_ (u"ࠪࡅࡋ࡚ࡅࡓࡡࡄࡐࡑ࠭ၖ")
        else:
            return bstack1ll1lll_opy_ (u"ࠫࡆࡌࡔࡆࡔࡢࡉࡆࡉࡈࠨၗ")