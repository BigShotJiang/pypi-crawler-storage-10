# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
from collections import defaultdict
from threading import Lock
from dataclasses import dataclass
import logging
import traceback
from typing import List, Dict, Any
import os
@dataclass
class bstack1llllllll1_opy_:
    sdk_version: str
    path_config: str
    path_project: str
    test_framework: str
    frameworks: List[str]
    framework_versions: Dict[str, str]
    bs_config: Dict[str, Any]
@dataclass
class bstack1ll11l1ll1_opy_:
    pass
class bstack1l11l1lll1_opy_:
    bstack11llll11ll_opy_ = bstack1ll1lll_opy_ (u"ࠨࡢࡰࡱࡷࡷࡹࡸࡡࡱࠤᅿ")
    CONNECT = bstack1ll1lll_opy_ (u"ࠢࡤࡱࡱࡲࡪࡩࡴࠣᆀ")
    bstack1lllll111_opy_ = bstack1ll1lll_opy_ (u"ࠣࡵ࡫ࡹࡹࡪ࡯ࡸࡰࠥᆁ")
    CONFIG = bstack1ll1lll_opy_ (u"ࠤࡦࡳࡳ࡬ࡩࡨࠤᆂ")
    bstack1ll1l111ll1_opy_ = bstack1ll1lll_opy_ (u"ࠥࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡹࠢᆃ")
    bstack1l1111ll_opy_ = bstack1ll1lll_opy_ (u"ࠦࡪࡾࡩࡵࠤᆄ")
class bstack1ll1l111l11_opy_:
    bstack1ll1l111lll_opy_ = bstack1ll1lll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡸࡺࡡࡳࡶࡨࡨࠧᆅ")
    FINISHED = bstack1ll1lll_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪࠢᆆ")
class bstack1ll1l111l1l_opy_:
    bstack1ll1l111lll_opy_ = bstack1ll1lll_opy_ (u"ࠢࡵࡧࡶࡸࡤࡸࡵ࡯ࡡࡶࡸࡦࡸࡴࡦࡦࠥᆇ")
    FINISHED = bstack1ll1lll_opy_ (u"ࠣࡶࡨࡷࡹࡥࡲࡶࡰࡢࡪ࡮ࡴࡩࡴࡪࡨࡨࠧᆈ")
class bstack1ll1l11l111_opy_:
    bstack1ll1l111lll_opy_ = bstack1ll1lll_opy_ (u"ࠤ࡫ࡳࡴࡱ࡟ࡳࡷࡱࡣࡸࡺࡡࡳࡶࡨࡨࠧᆉ")
    FINISHED = bstack1ll1lll_opy_ (u"ࠥ࡬ࡴࡵ࡫ࡠࡴࡸࡲࡤ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪࠢᆊ")
class bstack1ll1l1111ll_opy_:
    bstack1ll1l11l11l_opy_ = bstack1ll1lll_opy_ (u"ࠦࡨࡨࡴࡠࡵࡨࡷࡸ࡯࡯࡯ࡡࡦࡶࡪࡧࡴࡦࡦࠥᆋ")
class bstack1ll1l1111l1_opy_:
    _1ll1llll1l1_opy_ = None
    def __new__(cls):
        if not cls._1ll1llll1l1_opy_:
            cls._1ll1llll1l1_opy_ = super(bstack1ll1l1111l1_opy_, cls).__new__(cls)
        return cls._1ll1llll1l1_opy_
    def __init__(self):
        self._hooks = defaultdict(lambda: defaultdict(list))
        self._lock = Lock()
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(logging.INFO)
    def clear(self):
        with self._lock:
            self._hooks = defaultdict(list)
    def register(self, event_name, callback):
        with self._lock:
            if not callable(callback):
                raise ValueError(bstack1ll1lll_opy_ (u"ࠧࡉࡡ࡭࡮ࡥࡥࡨࡱࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡥࡤࡰࡱࡧࡢ࡭ࡧࠣࡪࡴࡸࠠࠣᆌ") + event_name)
            pid = os.getpid()
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠨࡒࡦࡩ࡬ࡷࡹ࡫ࡲࡪࡰࡪࠤࡨࡧ࡬࡭ࡤࡤࡧࡰࠦࡦࡰࡴࠣࡩࡻ࡫࡮ࡵࠢࠪࡿࡪࡼࡥ࡯ࡶࡢࡲࡦࡳࡥࡾࠩࠣࡻ࡮ࡺࡨࠡࡲ࡬ࡨࠥࠨᆍ") + str(pid) + bstack1ll1lll_opy_ (u"ࠢࠣᆎ"))
            self._hooks[event_name][pid].append(callback)
    def invoke(self, event_name, *args, **kwargs):
        with self._lock:
            pid = os.getpid()
            callbacks = self._hooks.get(event_name, {}).get(pid, [])
            if not callbacks:
                self.logger.warning(bstack1ll1lll_opy_ (u"ࠣࡐࡲࠤࡨࡧ࡬࡭ࡤࡤࡧࡰࡹࠠࡧࡱࡵࠤࡪࡼࡥ࡯ࡶࠣࠫࢀ࡫ࡶࡦࡰࡷࡣࡳࡧ࡭ࡦࡿࠪࠤࡼ࡯ࡴࡩࠢࡳ࡭ࡩࠦࠢᆏ") + str(pid) + bstack1ll1lll_opy_ (u"ࠤࠥᆐ"))
                return
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠥࡍࡳࡼ࡯࡬࡫ࡱ࡫ࠥࢁ࡬ࡦࡰࠫࡧࡦࡲ࡬ࡣࡣࡦ࡯ࡸ࠯ࡽࠡࡥࡤࡰࡱࡨࡡࡤ࡭ࡶࠤ࡫ࡵࡲࠡࡧࡹࡩࡳࡺࠠࠨࡽࡨࡺࡪࡴࡴࡠࡰࡤࡱࡪࢃࠧࠡࡹ࡬ࡸ࡭ࠦࡰࡪࡦࠣࠦᆑ") + str(pid) + bstack1ll1lll_opy_ (u"ࠦࠧᆒ"))
            for callback in callbacks:
                try:
                    self.logger.debug(bstack1ll1lll_opy_ (u"ࠧࡏ࡮ࡷࡱ࡮ࡩࡩࠦࡣࡢ࡮࡯ࡦࡦࡩ࡫ࠡࡨࡲࡶࠥ࡫ࡶࡦࡰࡷࠤࠬࢁࡥࡷࡧࡱࡸࡤࡴࡡ࡮ࡧࢀࠫࠥࡽࡩࡵࡪࠣࡴ࡮ࡪࠠࠣᆓ") + str(pid) + bstack1ll1lll_opy_ (u"ࠨࠢᆔ"))
                    callback(event_name, *args, **kwargs)
                except Exception as e:
                    self.logger.error(bstack1ll1lll_opy_ (u"ࠢࡆࡴࡵࡳࡷࠦࡩ࡯ࡸࡲ࡯࡮ࡴࡧࠡࡥࡤࡰࡱࡨࡡࡤ࡭ࠣࡪࡴࡸࠠࡦࡸࡨࡲࡹࠦࠧࡼࡧࡹࡩࡳࡺ࡟࡯ࡣࡰࡩࢂ࠭ࠠࡸ࡫ࡷ࡬ࠥࡶࡩࡥࠢࡾࡴ࡮ࡪࡽ࠻ࠢࠥᆕ") + str(e) + bstack1ll1lll_opy_ (u"ࠣࠤᆖ"))
                    traceback.print_exc()
bstack1ll1l1ll11_opy_ = bstack1ll1l1111l1_opy_()