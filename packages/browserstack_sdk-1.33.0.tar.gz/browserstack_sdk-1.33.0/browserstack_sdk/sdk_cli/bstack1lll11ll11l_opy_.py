# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import os
import traceback
from typing import Dict, Tuple, Callable, Type, List, Any
from urllib.parse import urlparse
from browserstack_sdk.sdk_cli.bstack1lllll1llll_opy_ import (
    bstack1llll11llll_opy_,
    bstack1lllll1lll1_opy_,
    bstack1llll1l11ll_opy_,
    bstack1lllll11ll1_opy_,
)
import copy
from datetime import datetime, timezone, timedelta
from bstack_utils.bstack11llll1111_opy_ import bstack1llll11111l_opy_
from bstack_utils.constants import EVENTS
class bstack1ll1l11ll1l_opy_(bstack1llll11llll_opy_):
    bstack1l111llllll_opy_ = bstack1ll1lll_opy_ (u"ࠣࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡑࡎࡄࡘࡋࡕࡒࡎࡡࡌࡒࡉࡋࡘࠣᖔ")
    NAME = bstack1ll1lll_opy_ (u"ࠤࡶࡩࡱ࡫࡮ࡪࡷࡰࠦᖕ")
    bstack1l1l111l11l_opy_ = bstack1ll1lll_opy_ (u"ࠥ࡬ࡺࡨ࡟ࡶࡴ࡯ࠦᖖ")
    bstack1l1l111llll_opy_ = bstack1ll1lll_opy_ (u"ࠦ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࡠ࡫ࡧࠦᖗ")
    bstack11llll111l1_opy_ = bstack1ll1lll_opy_ (u"ࠧ࡯࡮ࡱࡷࡷࡣࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠥᖘ")
    bstack1l1l1111l1l_opy_ = bstack1ll1lll_opy_ (u"ࠨࡣࡢࡲࡤࡦ࡮ࡲࡩࡵ࡫ࡨࡷࠧᖙ")
    bstack1l11l1l111l_opy_ = bstack1ll1lll_opy_ (u"ࠢࡪࡵࡢࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡ࡫ࡹࡧࠨᖚ")
    bstack11llll111ll_opy_ = bstack1ll1lll_opy_ (u"ࠣࡵࡷࡥࡷࡺࡥࡥࡡࡤࡸࠧᖛ")
    bstack11lll1lll1l_opy_ = bstack1ll1lll_opy_ (u"ࠤࡨࡲࡩ࡫ࡤࡠࡣࡷࠦᖜ")
    bstack1ll111l1ll1_opy_ = bstack1ll1lll_opy_ (u"ࠥࡴࡱࡧࡴࡧࡱࡵࡱࡤ࡯࡮ࡥࡧࡻࠦᖝ")
    bstack1l11ll1ll1l_opy_ = bstack1ll1lll_opy_ (u"ࠦࡳ࡫ࡷࡴࡧࡶࡷ࡮ࡵ࡮ࠣᖞ")
    bstack11lll1ll1ll_opy_ = bstack1ll1lll_opy_ (u"ࠧ࡭ࡥࡵࠤᖟ")
    bstack1l1ll1l1lll_opy_ = bstack1ll1lll_opy_ (u"ࠨࡳࡤࡴࡨࡩࡳࡹࡨࡰࡶࠥᖠ")
    bstack1l11l111111_opy_ = bstack1ll1lll_opy_ (u"ࠢࡸ࠵ࡦࡩࡽ࡫ࡣࡶࡶࡨࡷࡨࡸࡩࡱࡶࠥᖡ")
    bstack1l111llll1l_opy_ = bstack1ll1lll_opy_ (u"ࠣࡹ࠶ࡧࡪࡾࡥࡤࡷࡷࡩࡸࡩࡲࡪࡲࡷࡥࡸࡿ࡮ࡤࠤᖢ")
    bstack11llll11111_opy_ = bstack1ll1lll_opy_ (u"ࠤࡴࡹ࡮ࡺࠢᖣ")
    bstack11llll1111l_opy_: Dict[str, List[Callable]] = dict()
    bstack1l11l1ll1ll_opy_: str
    platform_index: int
    options: Any
    desired_capabilities: Any
    bstack1ll1l1ll11l_opy_: Any
    bstack1l11l111l1l_opy_: Dict
    def __init__(
        self,
        bstack1l11l1ll1ll_opy_: str,
        platform_index: int,
        framework_name: str,
        framework_version: str,
        classes: List[Type],
        bstack1ll1l1ll11l_opy_: Dict[str, Any],
        methods=[bstack1ll1lll_opy_ (u"ࠥࡣࡤ࡯࡮ࡪࡶࡢࡣࠧᖤ"), bstack1ll1lll_opy_ (u"ࠦࡸࡺࡡࡳࡶࡢࡷࡪࡹࡳࡪࡱࡱࠦᖥ"), bstack1ll1lll_opy_ (u"ࠧ࡫ࡸࡦࡥࡸࡸࡪࠨᖦ"), bstack1ll1lll_opy_ (u"ࠨࡱࡶ࡫ࡷࠦᖧ")],
    ):
        super().__init__(
            framework_name,
            framework_version,
            classes,
        )
        self.bstack1l11l1ll1ll_opy_ = bstack1l11l1ll1ll_opy_
        self.platform_index = platform_index
        self.bstack1llll1ll111_opy_(methods)
        self.bstack1ll1l1ll11l_opy_ = bstack1ll1l1ll11l_opy_
    @staticmethod
    def session_id(target: object, strict=True):
        return bstack1llll11llll_opy_.get_data(bstack1ll1l11ll1l_opy_.bstack1l1l111llll_opy_, target, strict)
    @staticmethod
    def hub_url(target: object, strict=True):
        return bstack1llll11llll_opy_.get_data(bstack1ll1l11ll1l_opy_.bstack1l1l111l11l_opy_, target, strict)
    @staticmethod
    def bstack11lll1llll1_opy_(target: object, strict=True):
        return bstack1llll11llll_opy_.get_data(bstack1ll1l11ll1l_opy_.bstack11llll111l1_opy_, target, strict)
    @staticmethod
    def capabilities(target: object, strict=True):
        return bstack1llll11llll_opy_.get_data(bstack1ll1l11ll1l_opy_.bstack1l1l1111l1l_opy_, target, strict)
    @staticmethod
    def bstack1l1llll111l_opy_(instance: bstack1lllll1lll1_opy_) -> bool:
        return bstack1llll11llll_opy_.bstack1lllll1l1ll_opy_(instance, bstack1ll1l11ll1l_opy_.bstack1l11l1l111l_opy_, False)
    @staticmethod
    def bstack1ll11ll1lll_opy_(instance: bstack1lllll1lll1_opy_, default_value=None):
        return bstack1llll11llll_opy_.bstack1lllll1l1ll_opy_(instance, bstack1ll1l11ll1l_opy_.bstack1l1l111l11l_opy_, default_value)
    @staticmethod
    def bstack1ll111111ll_opy_(instance: bstack1lllll1lll1_opy_, default_value=None):
        return bstack1llll11llll_opy_.bstack1lllll1l1ll_opy_(instance, bstack1ll1l11ll1l_opy_.bstack1l1l1111l1l_opy_, default_value)
    @staticmethod
    def bstack1ll11111111_opy_(hub_url: str, bstack11lll1ll1l1_opy_=bstack1ll1lll_opy_ (u"ࠢ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡤࡱࡰࠦᖨ")):
        try:
            bstack11lll1lllll_opy_ = str(urlparse(hub_url).netloc) if hub_url else None
            return bstack11lll1lllll_opy_.endswith(bstack11lll1ll1l1_opy_)
        except:
            pass
        return False
    @staticmethod
    def bstack1ll111ll1ll_opy_(method_name: str):
        return method_name == bstack1ll1lll_opy_ (u"ࠣࡧࡻࡩࡨࡻࡴࡦࠤᖩ")
    @staticmethod
    def bstack1ll11ll11l1_opy_(method_name: str, *args):
        return (
            bstack1ll1l11ll1l_opy_.bstack1ll111ll1ll_opy_(method_name)
            and bstack1ll1l11ll1l_opy_.bstack1l11ll1l111_opy_(*args) == bstack1ll1l11ll1l_opy_.bstack1l11ll1ll1l_opy_
        )
    @staticmethod
    def bstack1ll11l11ll1_opy_(method_name: str, *args):
        if not bstack1ll1l11ll1l_opy_.bstack1ll111ll1ll_opy_(method_name):
            return False
        if not bstack1ll1l11ll1l_opy_.bstack1l11l111111_opy_ in bstack1ll1l11ll1l_opy_.bstack1l11ll1l111_opy_(*args):
            return False
        bstack1l1llllll11_opy_ = bstack1ll1l11ll1l_opy_.bstack1l1llll1lll_opy_(*args)
        return bstack1l1llllll11_opy_ and bstack1ll1lll_opy_ (u"ࠤࡶࡧࡷ࡯ࡰࡵࠤᖪ") in bstack1l1llllll11_opy_ and bstack1ll1lll_opy_ (u"ࠥࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵࠦᖫ") in bstack1l1llllll11_opy_[bstack1ll1lll_opy_ (u"ࠦࡸࡩࡲࡪࡲࡷࠦᖬ")]
    @staticmethod
    def bstack1ll11ll1111_opy_(method_name: str, *args):
        if not bstack1ll1l11ll1l_opy_.bstack1ll111ll1ll_opy_(method_name):
            return False
        if not bstack1ll1l11ll1l_opy_.bstack1l11l111111_opy_ in bstack1ll1l11ll1l_opy_.bstack1l11ll1l111_opy_(*args):
            return False
        bstack1l1llllll11_opy_ = bstack1ll1l11ll1l_opy_.bstack1l1llll1lll_opy_(*args)
        return (
            bstack1l1llllll11_opy_
            and bstack1ll1lll_opy_ (u"ࠧࡹࡣࡳ࡫ࡳࡸࠧᖭ") in bstack1l1llllll11_opy_
            and bstack1ll1lll_opy_ (u"ࠨࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࡤࡧࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࡡࡶࡧࡷ࡯ࡰࡵࠤᖮ") in bstack1l1llllll11_opy_[bstack1ll1lll_opy_ (u"ࠢࡴࡥࡵ࡭ࡵࡺࠢᖯ")]
        )
    @staticmethod
    def bstack1l11ll1l111_opy_(*args):
        return str(bstack1ll1l11ll1l_opy_.bstack1ll11111l1l_opy_(*args)).lower()
    @staticmethod
    def bstack1ll11111l1l_opy_(*args):
        return args[0] if args and type(args) in [list, tuple] and isinstance(args[0], str) else None
    @staticmethod
    def bstack1l1llll1lll_opy_(*args):
        return args[1] if len(args) > 1 and isinstance(args[1], dict) else None
    @staticmethod
    def bstack1l1ll111_opy_(driver):
        command_executor = getattr(driver, bstack1ll1lll_opy_ (u"ࠣࡥࡲࡱࡲࡧ࡮ࡥࡡࡨࡼࡪࡩࡵࡵࡱࡵࠦᖰ"), None)
        if not command_executor:
            return None
        hub_url = str(command_executor) if isinstance(command_executor, (str, bytes)) else None
        hub_url = str(command_executor._url) if not hub_url and getattr(command_executor, bstack1ll1lll_opy_ (u"ࠤࡢࡹࡷࡲࠢᖱ"), None) else None
        if not hub_url:
            client_config = getattr(command_executor, bstack1ll1lll_opy_ (u"ࠥࡣࡨࡲࡩࡦࡰࡷࡣࡨࡵ࡮ࡧ࡫ࡪࠦᖲ"), None)
            if not client_config:
                return None
            hub_url = getattr(client_config, bstack1ll1lll_opy_ (u"ࠦࡷ࡫࡭ࡰࡶࡨࡣࡸ࡫ࡲࡷࡧࡵࡣࡦࡪࡤࡳࠤᖳ"), None)
        return hub_url
    def bstack1l11l1l1l11_opy_(self, instance, driver, hub_url: str):
        result = False
        if not hub_url:
            return result
        command_executor = getattr(driver, bstack1ll1lll_opy_ (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࡥࡥࡹࡧࡦࡹࡹࡵࡲࠣᖴ"), None)
        if command_executor:
            if isinstance(command_executor, (str, bytes)):
                setattr(driver, bstack1ll1lll_opy_ (u"ࠨࡣࡰ࡯ࡰࡥࡳࡪ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳࠤᖵ"), hub_url)
                result = True
            elif hasattr(command_executor, bstack1ll1lll_opy_ (u"ࠢࡠࡷࡵࡰࠧᖶ")):
                setattr(command_executor, bstack1ll1lll_opy_ (u"ࠣࡡࡸࡶࡱࠨᖷ"), hub_url)
                result = True
        if result:
            self.bstack1l11l1ll1ll_opy_ = hub_url
            bstack1ll1l11ll1l_opy_.bstack1llll1l1l1l_opy_(instance, bstack1ll1l11ll1l_opy_.bstack1l1l111l11l_opy_, hub_url)
            bstack1ll1l11ll1l_opy_.bstack1llll1l1l1l_opy_(
                instance, bstack1ll1l11ll1l_opy_.bstack1l11l1l111l_opy_, bstack1ll1l11ll1l_opy_.bstack1ll11111111_opy_(hub_url)
            )
        return result
    @staticmethod
    def bstack1l11l111l11_opy_(bstack1lllll11l11_opy_: Tuple[bstack1llll1l11ll_opy_, bstack1lllll11ll1_opy_]):
        return bstack1ll1lll_opy_ (u"ࠤ࠽ࠦᖸ").join((bstack1llll1l11ll_opy_(bstack1lllll11l11_opy_[0]).name, bstack1lllll11ll1_opy_(bstack1lllll11l11_opy_[1]).name))
    @staticmethod
    def bstack1ll11lllll1_opy_(bstack1lllll11l11_opy_: Tuple[bstack1llll1l11ll_opy_, bstack1lllll11ll1_opy_], callback: Callable):
        bstack1l111llll11_opy_ = bstack1ll1l11ll1l_opy_.bstack1l11l111l11_opy_(bstack1lllll11l11_opy_)
        if not bstack1l111llll11_opy_ in bstack1ll1l11ll1l_opy_.bstack11llll1111l_opy_:
            bstack1ll1l11ll1l_opy_.bstack11llll1111l_opy_[bstack1l111llll11_opy_] = []
        bstack1ll1l11ll1l_opy_.bstack11llll1111l_opy_[bstack1l111llll11_opy_].append(callback)
    def bstack1lllll11lll_opy_(self, instance: bstack1lllll1lll1_opy_, method_name: str, bstack1llllll1ll1_opy_: timedelta, *args, **kwargs):
        if not instance or method_name in (bstack1ll1lll_opy_ (u"ࠥࡷࡹࡧࡲࡵࡡࡶࡩࡸࡹࡩࡰࡰࠥᖹ")):
            return
        cmd = args[0] if method_name == bstack1ll1lll_opy_ (u"ࠦࡪࡾࡥࡤࡷࡷࡩࠧᖺ") and args and type(args) in [list, tuple] and isinstance(args[0], str) else None
        bstack11lll1lll11_opy_ = bstack1ll1lll_opy_ (u"ࠧࡀࠢᖻ").join(map(str, filter(None, [method_name, cmd])))
        instance.bstack1ll1l111l_opy_(bstack1ll1lll_opy_ (u"ࠨࡤࡳ࡫ࡹࡩࡷࡀࠢᖼ") + bstack11lll1lll11_opy_, bstack1llllll1ll1_opy_)
    def bstack1llllll1111_opy_(
        self,
        target: object,
        exec: Tuple[bstack1lllll1lll1_opy_, str],
        bstack1lllll11l11_opy_: Tuple[bstack1llll1l11ll_opy_, bstack1lllll11ll1_opy_],
        result: Any,
        *args,
        **kwargs,
    ) -> Callable[..., Any]:
        instance, method_name = exec
        bstack1lllllll111_opy_, bstack1l11l11111l_opy_ = bstack1lllll11l11_opy_
        bstack1l111llll11_opy_ = bstack1ll1l11ll1l_opy_.bstack1l11l111l11_opy_(bstack1lllll11l11_opy_)
        self.logger.debug(bstack1ll1lll_opy_ (u"ࠢࡰࡰࡢ࡬ࡴࡵ࡫࠻ࠢࡰࡩࡹ࡮࡯ࡥࡡࡱࡥࡲ࡫࠽ࡼ࡯ࡨࡸ࡭ࡵࡤࡠࡰࡤࡱࡪࢃࠠࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࡀࡿ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵࡽࠡࡣࡵ࡫ࡸࡃࡻࡢࡴࡪࡷࢂࠦ࡫ࡸࡣࡵ࡫ࡸࡃࠢᖽ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠣࠤᖾ"))
        if bstack1lllllll111_opy_ == bstack1llll1l11ll_opy_.QUIT:
            if bstack1l11l11111l_opy_ == bstack1lllll11ll1_opy_.PRE:
                bstack1ll111ll11l_opy_ = bstack1llll11111l_opy_.bstack1ll111l11l1_opy_(EVENTS.bstack11l1l1111_opy_.value)
                bstack1llll11llll_opy_.bstack1llll1l1l1l_opy_(instance, EVENTS.bstack11l1l1111_opy_.value, bstack1ll111ll11l_opy_)
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠤ࡬ࡲࡸࡺࡡ࡯ࡥࡨࡁࢀࢃࠠ࡮ࡧࡷ࡬ࡴࡪ࡟࡯ࡣࡰࡩࡂࢁࡽࠡࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡸࡺࡡࡵࡧࡀࡿࢂࠦࡨࡰࡱ࡮ࡣࡸࡺࡡࡵࡧࡀࡿࢂࠨᖿ").format(instance, method_name, bstack1lllllll111_opy_, bstack1l11l11111l_opy_))
        if bstack1lllllll111_opy_ == bstack1llll1l11ll_opy_.bstack1llll1ll11l_opy_:
            if bstack1l11l11111l_opy_ == bstack1lllll11ll1_opy_.POST and not bstack1ll1l11ll1l_opy_.bstack1l1l111llll_opy_ in instance.data:
                session_id = getattr(target, bstack1ll1lll_opy_ (u"ࠥࡷࡪࡹࡳࡪࡱࡱࡣ࡮ࡪࠢᗀ"), None)
                if session_id:
                    instance.data[bstack1ll1l11ll1l_opy_.bstack1l1l111llll_opy_] = session_id
        elif (
            bstack1lllllll111_opy_ == bstack1llll1l11ll_opy_.bstack1llll1lll1l_opy_
            and bstack1ll1l11ll1l_opy_.bstack1l11ll1l111_opy_(*args) == bstack1ll1l11ll1l_opy_.bstack1l11ll1ll1l_opy_
        ):
            if bstack1l11l11111l_opy_ == bstack1lllll11ll1_opy_.PRE:
                hub_url = bstack1ll1l11ll1l_opy_.bstack1l1ll111_opy_(target)
                if hub_url:
                    instance.data.update(
                        {
                            bstack1ll1l11ll1l_opy_.bstack1l1l111l11l_opy_: hub_url,
                            bstack1ll1l11ll1l_opy_.bstack1l11l1l111l_opy_: bstack1ll1l11ll1l_opy_.bstack1ll11111111_opy_(hub_url),
                            bstack1ll1l11ll1l_opy_.bstack1ll111l1ll1_opy_: int(
                                os.environ.get(bstack1ll1lll_opy_ (u"ࠦࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡔࡑࡇࡔࡇࡑࡕࡑࡤࡏࡎࡅࡇ࡛ࠦᗁ"), str(self.platform_index))
                            ),
                        }
                    )
                bstack1l1llllll11_opy_ = bstack1ll1l11ll1l_opy_.bstack1l1llll1lll_opy_(*args)
                bstack11lll1llll1_opy_ = bstack1l1llllll11_opy_.get(bstack1ll1lll_opy_ (u"ࠧࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶࠦᗂ"), None) if bstack1l1llllll11_opy_ else None
                if isinstance(bstack11lll1llll1_opy_, dict):
                    instance.data[bstack1ll1l11ll1l_opy_.bstack11llll111l1_opy_] = copy.deepcopy(bstack11lll1llll1_opy_)
                    instance.data[bstack1ll1l11ll1l_opy_.bstack1l1l1111l1l_opy_] = bstack11lll1llll1_opy_
            elif bstack1l11l11111l_opy_ == bstack1lllll11ll1_opy_.POST:
                if isinstance(result, dict):
                    framework_session_id = result.get(bstack1ll1lll_opy_ (u"ࠨࡶࡢ࡮ࡸࡩࠧᗃ"), dict()).get(bstack1ll1lll_opy_ (u"ࠢࡴࡧࡶࡷ࡮ࡵ࡮ࡊࡦࠥᗄ"), None)
                    if framework_session_id:
                        instance.data.update(
                            {
                                bstack1ll1l11ll1l_opy_.bstack1l1l111llll_opy_: framework_session_id,
                                bstack1ll1l11ll1l_opy_.bstack11llll111ll_opy_: datetime.now(tz=timezone.utc),
                            }
                        )
        elif (
            bstack1lllllll111_opy_ == bstack1llll1l11ll_opy_.bstack1llll1lll1l_opy_
            and bstack1ll1l11ll1l_opy_.bstack1l11ll1l111_opy_(*args) == bstack1ll1l11ll1l_opy_.bstack11llll11111_opy_
            and bstack1l11l11111l_opy_ == bstack1lllll11ll1_opy_.POST
        ):
            instance.data[bstack1ll1l11ll1l_opy_.bstack11lll1lll1l_opy_] = datetime.now(tz=timezone.utc)
        if bstack1l111llll11_opy_ in bstack1ll1l11ll1l_opy_.bstack11llll1111l_opy_:
            bstack1l11l1111ll_opy_ = None
            for callback in bstack1ll1l11ll1l_opy_.bstack11llll1111l_opy_[bstack1l111llll11_opy_]:
                try:
                    bstack1l111lllll1_opy_ = callback(self, target, exec, bstack1lllll11l11_opy_, result, *args, **kwargs)
                    if bstack1l11l1111ll_opy_ == None:
                        bstack1l11l1111ll_opy_ = bstack1l111lllll1_opy_
                except Exception as e:
                    self.logger.error(bstack1ll1lll_opy_ (u"ࠣࡧࡵࡶࡴࡸࠠࡪࡰࡹࡳࡰ࡯࡮ࡨࠢࡦࡥࡱࡲࡢࡢࡥ࡮࠾ࠥࠨᗅ") + str(e) + bstack1ll1lll_opy_ (u"ࠤࠥᗆ"))
                    traceback.print_exc()
            if bstack1lllllll111_opy_ == bstack1llll1l11ll_opy_.QUIT:
                if bstack1l11l11111l_opy_ == bstack1lllll11ll1_opy_.POST:
                    bstack1ll111ll11l_opy_ = bstack1llll11llll_opy_.bstack1lllll1l1ll_opy_(instance, EVENTS.bstack11l1l1111_opy_.value)
                    if bstack1ll111ll11l_opy_!=None:
                        bstack1llll11111l_opy_.end(EVENTS.bstack11l1l1111_opy_.value, bstack1ll111ll11l_opy_+bstack1ll1lll_opy_ (u"ࠥ࠾ࡸࡺࡡࡳࡶࠥᗇ"), bstack1ll111ll11l_opy_+bstack1ll1lll_opy_ (u"ࠦ࠿࡫࡮ࡥࠤᗈ"), True, None)
            if bstack1l11l11111l_opy_ == bstack1lllll11ll1_opy_.PRE and callable(bstack1l11l1111ll_opy_):
                return bstack1l11l1111ll_opy_
            elif bstack1l11l11111l_opy_ == bstack1lllll11ll1_opy_.POST and bstack1l11l1111ll_opy_:
                return bstack1l11l1111ll_opy_
    def bstack1llll1lll11_opy_(
        self, method_name, previous_state: bstack1llll1l11ll_opy_, *args, **kwargs
    ) -> bstack1llll1l11ll_opy_:
        if method_name == bstack1ll1lll_opy_ (u"ࠧࡥ࡟ࡪࡰ࡬ࡸࡤࡥࠢᗉ") or method_name == bstack1ll1lll_opy_ (u"ࠨࡳࡵࡣࡵࡸࡤࡹࡥࡴࡵ࡬ࡳࡳࠨᗊ"):
            return bstack1llll1l11ll_opy_.bstack1llll1ll11l_opy_
        if method_name == bstack1ll1lll_opy_ (u"ࠢࡲࡷ࡬ࡸࠧᗋ"):
            return bstack1llll1l11ll_opy_.QUIT
        if method_name == bstack1ll1lll_opy_ (u"ࠣࡧࡻࡩࡨࡻࡴࡦࠤᗌ"):
            if previous_state != bstack1llll1l11ll_opy_.NONE:
                command_name = bstack1ll1l11ll1l_opy_.bstack1l11ll1l111_opy_(*args)
                if command_name == bstack1ll1l11ll1l_opy_.bstack1l11ll1ll1l_opy_:
                    return bstack1llll1l11ll_opy_.bstack1llll1ll11l_opy_
            return bstack1llll1l11ll_opy_.bstack1llll1lll1l_opy_
        return bstack1llll1l11ll_opy_.NONE