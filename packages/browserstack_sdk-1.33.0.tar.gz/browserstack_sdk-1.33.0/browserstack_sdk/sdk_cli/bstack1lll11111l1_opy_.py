# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import logging
import abc
from browserstack_sdk.sdk_cli.bstack1lllllll1ll_opy_ import bstack1lllllllll1_opy_
class bstack1lll1ll11l1_opy_(abc.ABC):
    bin_session_id: str
    bstack1lllllll1ll_opy_: bstack1lllllllll1_opy_
    def __init__(self):
        self.bstack1ll1ll1llll_opy_ = None
        self.config = None
        self.bin_session_id = None
        self.bstack1lllllll1ll_opy_ = None
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(logging.INFO)
    def bstack1lll1l1l111_opy_(self):
        return (self.bstack1ll1ll1llll_opy_ != None and self.bin_session_id != None and self.bstack1lllllll1ll_opy_ != None)
    def configure(self, bstack1ll1ll1llll_opy_, config, bin_session_id: str, bstack1lllllll1ll_opy_: bstack1lllllllll1_opy_):
        self.bstack1ll1ll1llll_opy_ = bstack1ll1ll1llll_opy_
        self.config = config
        self.bin_session_id = bin_session_id
        self.bstack1lllllll1ll_opy_ = bstack1lllllll1ll_opy_
        if self.bin_session_id:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠢ࡜ࡽ࡬ࡨ࠭ࡹࡥ࡭ࡨࠬࢁࡢࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡦࡦࠣࡱࡴࡪࡵ࡭ࡧࠣࡿࡸ࡫࡬ࡧ࠰ࡢࡣࡨࡲࡡࡴࡵࡢࡣ࠳ࡥ࡟࡯ࡣࡰࡩࡤࡥࡽ࠻ࠢࡥ࡭ࡳࡥࡳࡦࡵࡶ࡭ࡴࡴ࡟ࡪࡦࡀࠦበ") + str(self.bin_session_id) + bstack1ll1lll_opy_ (u"ࠣࠤቡ"))
    def bstack1ll1111llll_opy_(self):
        if not self.bin_session_id:
            raise ValueError(bstack1ll1lll_opy_ (u"ࠤࡥ࡭ࡳࡥࡳࡦࡵࡶ࡭ࡴࡴ࡟ࡪࡦࠣࡧࡦࡴ࡮ࡰࡶࠣࡦࡪࠦࡎࡰࡰࡨࠦቢ"))
    @abc.abstractmethod
    def is_enabled(self) -> bool:
        return False