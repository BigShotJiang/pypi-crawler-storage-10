# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import json
import time
import os
import threading
import asyncio
from browserstack_sdk.sdk_cli.bstack1lllll1llll_opy_ import (
    bstack1llll1l11ll_opy_,
    bstack1lllll11ll1_opy_,
    bstack1lllll1lll1_opy_,
    bstack1llll1l1l11_opy_,
)
from typing import Tuple, Dict, Any, List, Union
from bstack_utils.helper import bstack1l1l1ll11l1_opy_, bstack1l1111ll1l_opy_
from browserstack_sdk.sdk_cli.bstack1lll11ll11l_opy_ import bstack1ll1l11ll1l_opy_
from browserstack_sdk.sdk_cli.test_framework import TestFramework, bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_, bstack1lll11ll1l1_opy_
from browserstack_sdk.sdk_cli.bstack1lll11llll1_opy_ import bstack1lll11l1ll1_opy_
from browserstack_sdk.sdk_cli.bstack1l1llll1111_opy_ import bstack1l1llll1l1l_opy_
from typing import Tuple, List, Any
from bstack_utils.bstack11ll111l1l_opy_ import bstack1l1llll1ll_opy_, bstack1l1lll1ll1_opy_, bstack1l11l1l11l_opy_
from browserstack_sdk import sdk_pb2 as structs
class bstack1llll111ll1_opy_(bstack1l1llll1l1l_opy_):
    bstack1l11llll1ll_opy_ = bstack1ll1lll_opy_ (u"ࠧࡺࡥࡴࡶࡢࡨࡷ࡯ࡶࡦࡴࡶࠦጩ")
    bstack1l1ll111111_opy_ = bstack1ll1lll_opy_ (u"ࠨࡡࡶࡶࡲࡱࡦࡺࡩࡰࡰࡢࡷࡪࡹࡳࡪࡱࡱࡷࠧጪ")
    bstack1l11llll1l1_opy_ = bstack1ll1lll_opy_ (u"ࠢ࡯ࡱࡱࡣࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࡴࠤጫ")
    bstack1l11lllllll_opy_ = bstack1ll1lll_opy_ (u"ࠣࡶࡨࡷࡹࡥࡳࡦࡵࡶ࡭ࡴࡴࡳࠣጬ")
    bstack1l11lll1l1l_opy_ = bstack1ll1lll_opy_ (u"ࠤࡤࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳࡥࡩ࡯ࡵࡷࡥࡳࡩࡥࡠࡴࡨࡪࡸࠨጭ")
    bstack1l1ll111l11_opy_ = bstack1ll1lll_opy_ (u"ࠥࡧࡧࡺ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࡠࡥࡵࡩࡦࡺࡥࡥࠤጮ")
    bstack1l11lll11l1_opy_ = bstack1ll1lll_opy_ (u"ࠦࡨࡨࡴࡠࡵࡨࡷࡸ࡯࡯࡯ࡡࡱࡥࡲ࡫ࠢጯ")
    bstack1l11lll111l_opy_ = bstack1ll1lll_opy_ (u"ࠧࡩࡢࡵࡡࡶࡩࡸࡹࡩࡰࡰࡢࡷࡹࡧࡴࡶࡵࠥጰ")
    def __init__(self):
        super().__init__(bstack1l1lll1l1ll_opy_=self.bstack1l11llll1ll_opy_, frameworks=[bstack1ll1l11ll1l_opy_.NAME])
        if not self.is_enabled():
            return
        TestFramework.bstack1ll11lllll1_opy_((bstack1lll1111111_opy_.BEFORE_EACH, bstack1lll1l1l1ll_opy_.POST), self.bstack1l11lll1111_opy_)
        if bstack1l1111ll1l_opy_():
            TestFramework.bstack1ll11lllll1_opy_((bstack1lll1111111_opy_.TEST, bstack1lll1l1l1ll_opy_.POST), self.bstack1ll11lll11l_opy_)
        else:
            TestFramework.bstack1ll11lllll1_opy_((bstack1lll1111111_opy_.TEST, bstack1lll1l1l1ll_opy_.PRE), self.bstack1ll11lll11l_opy_)
        TestFramework.bstack1ll11lllll1_opy_((bstack1lll1111111_opy_.TEST, bstack1lll1l1l1ll_opy_.POST), self.bstack1ll11111l11_opy_)
    def is_enabled(self) -> bool:
        return True
    def bstack1l11lll1111_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll11ll1l1_opy_,
        bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_],
        *args,
        **kwargs,
    ):
        bstack1l11lllll11_opy_ = self.bstack1l11lll11ll_opy_(instance.context)
        if not bstack1l11lllll11_opy_:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠨࡳࡦࡶࡢࡥࡨࡺࡩࡷࡧࡢࡴࡦ࡭ࡥ࠻ࠢࡱࡳࠥࡶࡡࡨࡧࠣࡪࡴࡸࠠࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࡀࠦጱ") + str(bstack1lllll11l11_opy_) + bstack1ll1lll_opy_ (u"ࠢࠣጲ"))
            return
        f.bstack1llll1l1l1l_opy_(instance, bstack1llll111ll1_opy_.bstack1l1ll111111_opy_, bstack1l11lllll11_opy_)
    def bstack1l11lll11ll_opy_(self, context: bstack1llll1l1l11_opy_, bstack1l1l1111111_opy_= True):
        if bstack1l1l1111111_opy_:
            bstack1l11lllll11_opy_ = self.bstack1l1lll1ll1l_opy_(context, reverse=True)
        else:
            bstack1l11lllll11_opy_ = self.bstack1l1llll11ll_opy_(context, reverse=True)
        return [f for f in bstack1l11lllll11_opy_ if f[1].state != bstack1llll1l11ll_opy_.QUIT]
    def bstack1ll11lll11l_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll11ll1l1_opy_,
        bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l11lll1111_opy_(f, instance, bstack1lllll11l11_opy_, *args, **kwargs)
        if not bstack1l1l1ll11l1_opy_:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠣࡱࡱࡣࡧ࡫ࡦࡰࡴࡨࡣࡹ࡫ࡳࡵ࠼ࠣࡲࡴࡺࠠࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࠦࡳࡦࡵࡶ࡭ࡴࡴࠠࡧࡱࡵࠤ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵ࠽ࡼࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࢁࠥࡧࡲࡨࡵࡀࡿࡦࡸࡧࡴࡿࠣ࡯ࡼࡧࡲࡨࡵࡀࠦጳ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠤࠥጴ"))
            return
        bstack1l11lllll11_opy_ = f.bstack1lllll1l1ll_opy_(instance, bstack1llll111ll1_opy_.bstack1l1ll111111_opy_, [])
        if not bstack1l11lllll11_opy_:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠥࡳࡳࡥࡢࡦࡨࡲࡶࡪࡥࡴࡦࡵࡷ࠾ࠥࡴ࡯ࠡࡦࡵ࡭ࡻ࡫ࡲࡴࠢࡩࡳࡷࠦࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰ࠿ࡾ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࢃࠠࡢࡴࡪࡷࡂࢁࡡࡳࡩࡶࢁࠥࡱࡷࡢࡴࡪࡷࡂࠨጵ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠦࠧጶ"))
            return
        if len(bstack1l11lllll11_opy_) > 1:
            self.logger.debug(
                bstack11111ll1ll_opy_ (u"ࠧࡵ࡮ࡠࡤࡨࡪࡴࡸࡥࡠࡶࡨࡷࡹࡀࠠࡼ࡮ࡨࡲ࠭ࡶࡡࡨࡧࡢ࡭ࡳࡹࡴࡢࡰࡦࡩࡸ࠯ࡽࠡࡦࡵ࡭ࡻ࡫ࡲࡴࠢࡩࡳࡷࠦࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰ࠿ࡾ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࢃࠠࡢࡴࡪࡷࡂࢁࡡࡳࡩࡶࢁࠥࡱࡷࡢࡴࡪࡷࡂࢁ࡫ࡸࡣࡵ࡫ࡸࢃࠢጷ"))
        bstack1l11lllll1l_opy_, bstack1l1l11ll1l1_opy_ = bstack1l11lllll11_opy_[0]
        page = bstack1l11lllll1l_opy_()
        if not page:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠨ࡯࡯ࡡࡥࡩ࡫ࡵࡲࡦࡡࡷࡩࡸࡺ࠺ࠡࡰࡲࠤࡵࡧࡧࡦࠢࡩࡳࡷࠦࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰ࠿ࡾ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࢃࠠࡢࡴࡪࡷࡂࢁࡡࡳࡩࡶࢁࠥࡱࡷࡢࡴࡪࡷࡂࠨጸ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠢࠣጹ"))
            return
        bstack11lllll111_opy_ = getattr(args[0], bstack1ll1lll_opy_ (u"ࠣࡰࡲࡨࡪ࡯ࡤࠣጺ"), None)
        from browserstack_sdk.sdk_cli.cli import cli
        if not cli.config.get(bstack1ll1lll_opy_ (u"ࠤࡷࡩࡸࡺࡃࡰࡰࡷࡩࡽࡺࡏࡱࡶ࡬ࡳࡳࡹࠢጻ")).get(bstack1ll1lll_opy_ (u"ࠥࡷࡰ࡯ࡰࡔࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠧጼ")):
            try:
                page.evaluate(bstack1ll1lll_opy_ (u"ࠦࡤࠦ࠽࠿ࠢࡾࢁࠧጽ"),
                            bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡱࡥࡲ࡫ࠢ࠻ࠩጾ") + json.dumps(
                                bstack11lllll111_opy_) + bstack1ll1lll_opy_ (u"ࠨࡽࡾࠤጿ"))
            except Exception as e:
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠢࡦࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡰ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶࠣࡷࡪࡹࡳࡪࡱࡱࠤࡳࡧ࡭ࡦࠢࡾࢁࠧፀ"), e)
    def bstack1ll11111l11_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll11ll1l1_opy_,
        bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l11lll1111_opy_(f, instance, bstack1lllll11l11_opy_, *args, **kwargs)
        if not bstack1l1l1ll11l1_opy_:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠣࡱࡱࡣࡧ࡫ࡦࡰࡴࡨࡣࡹ࡫ࡳࡵ࠼ࠣࡲࡴࡺࠠࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࠦࡳࡦࡵࡶ࡭ࡴࡴࠠࡧࡱࡵࠤ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵ࠽ࡼࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࢁࠥࡧࡲࡨࡵࡀࡿࡦࡸࡧࡴࡿࠣ࡯ࡼࡧࡲࡨࡵࡀࠦፁ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠤࠥፂ"))
            return
        bstack1l11lllll11_opy_ = f.bstack1lllll1l1ll_opy_(instance, bstack1llll111ll1_opy_.bstack1l1ll111111_opy_, [])
        if not bstack1l11lllll11_opy_:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠥࡳࡳࡥࡢࡦࡨࡲࡶࡪࡥࡴࡦࡵࡷ࠾ࠥࡴ࡯ࠡࡦࡵ࡭ࡻ࡫ࡲࡴࠢࡩࡳࡷࠦࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰ࠿ࡾ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࢃࠠࡢࡴࡪࡷࡂࢁࡡࡳࡩࡶࢁࠥࡱࡷࡢࡴࡪࡷࡂࠨፃ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠦࠧፄ"))
            return
        if len(bstack1l11lllll11_opy_) > 1:
            self.logger.debug(
                bstack11111ll1ll_opy_ (u"ࠧࡵ࡮ࡠࡤࡨࡪࡴࡸࡥࡠࡶࡨࡷࡹࡀࠠࡼ࡮ࡨࡲ࠭ࡶࡡࡨࡧࡢ࡭ࡳࡹࡴࡢࡰࡦࡩࡸ࠯ࡽࠡࡦࡵ࡭ࡻ࡫ࡲࡴࠢࡩࡳࡷࠦࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰ࠿ࡾ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࢃࠠࡢࡴࡪࡷࡂࢁࡡࡳࡩࡶࢁࠥࡱࡷࡢࡴࡪࡷࡂࢁ࡫ࡸࡣࡵ࡫ࡸࢃࠢፅ"))
        bstack1l11lllll1l_opy_, bstack1l1l11ll1l1_opy_ = bstack1l11lllll11_opy_[0]
        page = bstack1l11lllll1l_opy_()
        if not page:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠨ࡯࡯ࡡࡥࡩ࡫ࡵࡲࡦࡡࡷࡩࡸࡺ࠺ࠡࡰࡲࠤࡵࡧࡧࡦࠢࡩࡳࡷࠦࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰ࠿ࡾ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࢃࠠࡢࡴࡪࡷࡂࢁࡡࡳࡩࡶࢁࠥࡱࡷࡢࡴࡪࡷࡂࠨፆ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠢࠣፇ"))
            return
        status = f.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1l11llll111_opy_, None)
        if not status:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠣࡰࡲࠤࡸࡺࡡࡵࡷࡶࠤ࡫ࡵࡲࠡࡶࡨࡷࡹ࠲ࠠࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࡀࠦፈ") + str(bstack1lllll11l11_opy_) + bstack1ll1lll_opy_ (u"ࠤࠥፉ"))
            return
        bstack1l11lll1lll_opy_ = {bstack1ll1lll_opy_ (u"ࠥࡷࡹࡧࡴࡶࡵࠥፊ"): status.lower()}
        bstack1l11llllll1_opy_ = f.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1l11lll1ll1_opy_, None)
        if status.lower() == bstack1ll1lll_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫፋ") and bstack1l11llllll1_opy_ is not None:
            bstack1l11lll1lll_opy_[bstack1ll1lll_opy_ (u"ࠬࡸࡥࡢࡵࡲࡲࠬፌ")] = bstack1l11llllll1_opy_[0][bstack1ll1lll_opy_ (u"࠭ࡢࡢࡥ࡮ࡸࡷࡧࡣࡦࠩፍ")][0] if isinstance(bstack1l11llllll1_opy_, list) else str(bstack1l11llllll1_opy_)
        from browserstack_sdk.sdk_cli.cli import cli
        if not cli.config.get(bstack1ll1lll_opy_ (u"ࠢࡵࡧࡶࡸࡈࡵ࡮ࡵࡧࡻࡸࡔࡶࡴࡪࡱࡱࡷࠧፎ")).get(bstack1ll1lll_opy_ (u"ࠣࡵ࡮࡭ࡵ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷࠧፏ")):
            try:
                page.evaluate(
                        bstack1ll1lll_opy_ (u"ࠤࡢࠤࡂࡄࠠࡼࡿࠥፐ"),
                        bstack1ll1lll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡷࡪࡺࡓࡦࡵࡶ࡭ࡴࡴࡓࡵࡣࡷࡹࡸࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࠨፑ")
                        + json.dumps(bstack1l11lll1lll_opy_)
                        + bstack1ll1lll_opy_ (u"ࠦࢂࠨፒ")
                    )
            except Exception as e:
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠧ࡫ࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࠡࡵࡨࡷࡸ࡯࡯࡯ࠢࡶࡸࡦࡺࡵࡴࠢࡾࢁࠧፓ"), e)
    def bstack1l1ll1l1l1l_opy_(
        self,
        instance: bstack1lll11ll1l1_opy_,
        f: TestFramework,
        bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l11lll1111_opy_(f, instance, bstack1lllll11l11_opy_, *args, **kwargs)
        if not bstack1l1l1ll11l1_opy_:
            self.logger.debug(
                bstack11111ll1ll_opy_ (u"ࠨ࡭ࡢࡴ࡮ࡣࡴ࠷࠱ࡺࡡࡶࡽࡳࡩ࠺ࠡࡰࡲࡸࠥࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠤࡸ࡫ࡳࡴ࡫ࡲࡲ࠱ࠦࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰ࠿ࡾ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࢃࠠࡢࡴࡪࡷࡂࢁࡡࡳࡩࡶࢁࠥࡱࡷࡢࡴࡪࡷࡂࢁ࡫ࡸࡣࡵ࡫ࡸࢃࠢፔ"))
            return
        bstack1l11lllll11_opy_ = f.bstack1lllll1l1ll_opy_(instance, bstack1llll111ll1_opy_.bstack1l1ll111111_opy_, [])
        if not bstack1l11lllll11_opy_:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠢࡰࡰࡢࡦࡪ࡬࡯ࡳࡧࡢࡸࡪࡹࡴ࠻ࠢࡱࡳࠥࡪࡲࡪࡸࡨࡶࡸࠦࡦࡰࡴࠣ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࡃࡻࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࢀࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡮ࡻࡦࡸࡧࡴ࠿ࠥፕ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠣࠤፖ"))
            return
        if len(bstack1l11lllll11_opy_) > 1:
            self.logger.debug(
                bstack11111ll1ll_opy_ (u"ࠤࡲࡲࡤࡨࡥࡧࡱࡵࡩࡤࡺࡥࡴࡶ࠽ࠤࢀࡲࡥ࡯ࠪࡳࡥ࡬࡫࡟ࡪࡰࡶࡸࡦࡴࡣࡦࡵࠬࢁࠥࡪࡲࡪࡸࡨࡶࡸࠦࡦࡰࡴࠣ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࡃࡻࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࢀࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡮ࡻࡦࡸࡧࡴ࠿ࡾ࡯ࡼࡧࡲࡨࡵࢀࠦፗ"))
        bstack1l11lllll1l_opy_, bstack1l1l11ll1l1_opy_ = bstack1l11lllll11_opy_[0]
        page = bstack1l11lllll1l_opy_()
        if not page:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠥࡱࡦࡸ࡫ࡠࡱ࠴࠵ࡾࡥࡳࡺࡰࡦ࠾ࠥࡴ࡯ࠡࡲࡤ࡫ࡪࠦࡦࡰࡴࠣ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࡃࡻࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࢀࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡮ࡻࡦࡸࡧࡴ࠿ࠥፘ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠦࠧፙ"))
            return
        timestamp = int(time.time() * 1000)
        data = bstack1ll1lll_opy_ (u"ࠧࡕࡢࡴࡧࡵࡺࡦࡨࡩ࡭࡫ࡷࡽࡘࡿ࡮ࡤ࠼ࠥፚ") + str(timestamp)
        try:
            page.evaluate(
                bstack1ll1lll_opy_ (u"ࠨ࡟ࠡ࠿ࡁࠤࢀࢃࠢ፛"),
                bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࢁࠬ፜").format(
                    json.dumps(
                        {
                            bstack1ll1lll_opy_ (u"ࠣࡣࡦࡸ࡮ࡵ࡮ࠣ፝"): bstack1ll1lll_opy_ (u"ࠤࡤࡲࡳࡵࡴࡢࡶࡨࠦ፞"),
                            bstack1ll1lll_opy_ (u"ࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ፟"): {
                                bstack1ll1lll_opy_ (u"ࠦࡹࡿࡰࡦࠤ፠"): bstack1ll1lll_opy_ (u"ࠧࡇ࡮࡯ࡱࡷࡥࡹ࡯࡯࡯ࠤ፡"),
                                bstack1ll1lll_opy_ (u"ࠨࡤࡢࡶࡤࠦ።"): data,
                                bstack1ll1lll_opy_ (u"ࠢ࡭ࡧࡹࡩࡱࠨ፣"): bstack1ll1lll_opy_ (u"ࠣࡦࡨࡦࡺ࡭ࠢ፤")
                            }
                        }
                    )
                )
            )
        except Exception as e:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠤࡨࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡲ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࠥࡵ࠱࠲ࡻࠣࡥࡳࡴ࡯ࡵࡣࡷ࡭ࡴࡴࠠ࡮ࡣࡵ࡯࡮ࡴࡧࠡࡽࢀࠦ፥"), e)
    def bstack1l1ll111lll_opy_(
        self,
        instance: bstack1lll11ll1l1_opy_,
        f: TestFramework,
        bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l11lll1111_opy_(f, instance, bstack1lllll11l11_opy_, *args, **kwargs)
        if f.bstack1lllll1l1ll_opy_(instance, bstack1llll111ll1_opy_.bstack1l1ll111l11_opy_, False):
            return
        self.bstack1ll1111llll_opy_()
        req = structs.TestSessionEventRequest()
        req.bin_session_id = self.bin_session_id
        req.platform_index = TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1ll111l1ll1_opy_)
        req.test_framework_name = TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1ll11ll1l11_opy_)
        req.test_framework_version = TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1l1ll1ll11l_opy_)
        req.test_framework_state = bstack1lllll11l11_opy_[0].name
        req.test_hook_state = bstack1lllll11l11_opy_[1].name
        req.test_uuid = TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1ll11ll111l_opy_)
        for bstack1l11llll11l_opy_ in bstack1lll11l1ll1_opy_.bstack1llllll1lll_opy_.values():
            session = req.automation_sessions.add()
            session.provider = (
                bstack1ll1lll_opy_ (u"ࠥࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠤ፦")
                if bstack1l1l1ll11l1_opy_
                else bstack1ll1lll_opy_ (u"ࠦࡺࡴ࡫࡯ࡱࡺࡲࡤ࡭ࡲࡪࡦࠥ፧")
            )
            session.ref = bstack1l11llll11l_opy_.ref()
            session.hub_url = bstack1lll11l1ll1_opy_.bstack1lllll1l1ll_opy_(bstack1l11llll11l_opy_, bstack1lll11l1ll1_opy_.bstack1l1l111l11l_opy_, bstack1ll1lll_opy_ (u"ࠧࠨ፨"))
            session.framework_name = bstack1l11llll11l_opy_.framework_name
            session.framework_version = bstack1l11llll11l_opy_.framework_version
            session.framework_session_id = bstack1lll11l1ll1_opy_.bstack1lllll1l1ll_opy_(bstack1l11llll11l_opy_, bstack1lll11l1ll1_opy_.bstack1l1l111llll_opy_, bstack1ll1lll_opy_ (u"ࠨࠢ፩"))
        req.execution_context.hash = str(instance.context.hash)
        req.execution_context.thread_id = str(instance.context.thread_id)
        req.execution_context.process_id = str(instance.context.process_id)
        return req
    def bstack1ll11l1ll1l_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll11ll1l1_opy_,
        bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_],
        *args,
        **kwargs
    ):
        bstack1l11lllll11_opy_ = f.bstack1lllll1l1ll_opy_(instance, bstack1llll111ll1_opy_.bstack1l1ll111111_opy_, [])
        if not bstack1l11lllll11_opy_:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠢࡨࡧࡷࡣࡦࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࡠࡦࡵ࡭ࡻ࡫ࡲ࠻ࠢࡱࡳࠥࡶࡡࡨࡧࡶࠤ࡫ࡵࡲࠡࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࡁࢀ࡮࡯ࡰ࡭ࡢ࡭ࡳ࡬࡯ࡾࠢࡤࡶ࡬ࡹ࠽ࡼࡣࡵ࡫ࡸࢃࠠ࡬ࡹࡤࡶ࡬ࡹ࠽ࠣ፪") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠣࠤ፫"))
            return
        if len(bstack1l11lllll11_opy_) > 1:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠤࡪࡩࡹࡥࡡࡶࡶࡲࡱࡦࡺࡩࡰࡰࡢࡨࡷ࡯ࡶࡦࡴ࠽ࠤࢀࡲࡥ࡯ࠪࡳࡥ࡬࡫࡟ࡪࡰࡶࡸࡦࡴࡣࡦࡵࠬࢁࠥࡪࡲࡪࡸࡨࡶࡸࠦࡦࡰࡴࠣ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࡃࡻࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࢀࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡮ࡻࡦࡸࡧࡴ࠿ࠥ፬") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠥࠦ፭"))
        bstack1l11lllll1l_opy_, bstack1l1l11ll1l1_opy_ = bstack1l11lllll11_opy_[0]
        page = bstack1l11lllll1l_opy_()
        if not page:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠦ࡬࡫ࡴࡠࡣࡸࡸࡴࡳࡡࡵ࡫ࡲࡲࡤࡪࡲࡪࡸࡨࡶ࠿ࠦ࡮ࡰࠢࡳࡥ࡬࡫ࠠࡧࡱࡵࠤ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵ࠽ࡼࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࢁࠥࡧࡲࡨࡵࡀࡿࡦࡸࡧࡴࡿࠣ࡯ࡼࡧࡲࡨࡵࡀࠦ፮") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠧࠨ፯"))
            return
        return page
    def bstack1ll1111lll1_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll11ll1l1_opy_,
        bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_],
        *args,
        **kwargs
    ):
        caps = {}
        bstack1l11ll1llll_opy_ = {}
        for bstack1l11llll11l_opy_ in bstack1lll11l1ll1_opy_.bstack1llllll1lll_opy_.values():
            caps = bstack1lll11l1ll1_opy_.bstack1lllll1l1ll_opy_(bstack1l11llll11l_opy_, bstack1lll11l1ll1_opy_.bstack1l1l1111l1l_opy_, bstack1ll1lll_opy_ (u"ࠨࠢ፰"))
        bstack1l11ll1llll_opy_[bstack1ll1lll_opy_ (u"ࠢࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠧ፱")] = caps.get(bstack1ll1lll_opy_ (u"ࠣࡤࡵࡳࡼࡹࡥࡳࠤ፲"), bstack1ll1lll_opy_ (u"ࠤࠥ፳"))
        bstack1l11ll1llll_opy_[bstack1ll1lll_opy_ (u"ࠥࡴࡱࡧࡴࡧࡱࡵࡱࡓࡧ࡭ࡦࠤ፴")] = caps.get(bstack1ll1lll_opy_ (u"ࠦࡴࡹࠢ፵"), bstack1ll1lll_opy_ (u"ࠧࠨ፶"))
        bstack1l11ll1llll_opy_[bstack1ll1lll_opy_ (u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡗࡧࡵࡷ࡮ࡵ࡮ࠣ፷")] = caps.get(bstack1ll1lll_opy_ (u"ࠢࡰࡵࡢࡺࡪࡸࡳࡪࡱࡱࠦ፸"), bstack1ll1lll_opy_ (u"ࠣࠤ፹"))
        bstack1l11ll1llll_opy_[bstack1ll1lll_opy_ (u"ࠤࡥࡶࡴࡽࡳࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠥ፺")] = caps.get(bstack1ll1lll_opy_ (u"ࠥࡦࡷࡵࡷࡴࡧࡵࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧ፻"), bstack1ll1lll_opy_ (u"ࠦࠧ፼"))
        return bstack1l11ll1llll_opy_
    def bstack1ll11l1l11l_opy_(self, page: object, bstack1ll111l1l1l_opy_, args={}):
        try:
            bstack1l11lll1l11_opy_ = bstack1ll1lll_opy_ (u"ࠧࠨࠢࠩࡨࡸࡲࡨࡺࡩࡰࡰࠣࠬ࠳࠴࠮ࡣࡵࡷࡥࡨࡱࡓࡥ࡭ࡄࡶ࡬ࡹࠩࠡࡽࡾࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦ࡮ࡦࡹࠣࡔࡷࡵ࡭ࡪࡵࡨࠬ࠭ࡸࡥࡴࡱ࡯ࡺࡪ࠲ࠠࡳࡧ࡭ࡩࡨࡺࠩࠡ࠿ࡁࠤࢀࢁࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡢࡴࡶࡤࡧࡰ࡙ࡤ࡬ࡃࡵ࡫ࡸ࠴ࡰࡶࡵ࡫ࠬࡷ࡫ࡳࡰ࡮ࡹࡩ࠮ࡁࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡻࡧࡰࡢࡦࡴࡪࡹࡾࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࢂࢃࠩ࠼ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡾࡿࠬࠬࢀࡧࡲࡨࡡ࡭ࡷࡴࡴࡽࠪࠤࠥࠦ፽")
            bstack1ll111l1l1l_opy_ = bstack1ll111l1l1l_opy_.replace(bstack1ll1lll_opy_ (u"ࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ፾"), bstack1ll1lll_opy_ (u"ࠢࡣࡵࡷࡥࡨࡱࡓࡥ࡭ࡄࡶ࡬ࡹࠢ፿"))
            script = bstack1l11lll1l11_opy_.format(fn_body=bstack1ll111l1l1l_opy_, arg_json=json.dumps(args))
            return page.evaluate(script)
        except Exception as e:
            self.logger.error(bstack1ll1lll_opy_ (u"ࠣࡣ࠴࠵ࡾࡥࡳࡤࡴ࡬ࡴࡹࡥࡥࡹࡧࡦࡹࡹ࡫࠺ࠡࡇࡵࡶࡴࡸࠠࡦࡺࡨࡧࡺࡺࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡢ࠳࠴ࡽࠥࡹࡣࡳ࡫ࡳࡸ࠱ࠦࠢᎀ") + str(e) + bstack1ll1lll_opy_ (u"ࠤࠥᎁ"))