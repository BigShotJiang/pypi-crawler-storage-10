# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import os
import traceback
from typing import Dict, Tuple, Callable, Type, List, Any
from urllib.parse import urlparse
from browserstack_sdk.sdk_cli.bstack1lllll1llll_opy_ import (
    bstack1llll11llll_opy_,
    bstack1lllll1lll1_opy_,
    bstack1llll1l11ll_opy_,
    bstack1lllll11ll1_opy_,
)
import copy
from datetime import datetime, timezone, timedelta
class bstack1lll11l1ll1_opy_(bstack1llll11llll_opy_):
    bstack1l111llllll_opy_ = bstack1ll1lll_opy_ (u"ࠧࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡕࡒࡁࡕࡈࡒࡖࡒࡥࡉࡏࡆࡈ࡜ࠧᐬ")
    bstack1l1l111llll_opy_ = bstack1ll1lll_opy_ (u"ࠨࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࡡࡶࡩࡸࡹࡩࡰࡰࡢ࡭ࡩࠨᐭ")
    bstack1l1l111l11l_opy_ = bstack1ll1lll_opy_ (u"ࠢࡩࡷࡥࡣࡺࡸ࡬ࠣᐮ")
    bstack1l1l1111l1l_opy_ = bstack1ll1lll_opy_ (u"ࠣࡥࡤࡴࡦࡨࡩ࡭࡫ࡷ࡭ࡪࡹࠢᐯ")
    bstack1l11l111111_opy_ = bstack1ll1lll_opy_ (u"ࠤࡺ࠷ࡨ࡫ࡸࡦࡥࡸࡸࡪࡹࡣࡳ࡫ࡳࡸࠧᐰ")
    bstack1l111llll1l_opy_ = bstack1ll1lll_opy_ (u"ࠥࡻ࠸ࡩࡥࡹࡧࡦࡹࡹ࡫ࡳࡤࡴ࡬ࡴࡹࡧࡳࡺࡰࡦࠦᐱ")
    NAME = bstack1ll1lll_opy_ (u"ࠦࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࠣᐲ")
    bstack1l11l1111l1_opy_: Dict[str, List[Callable]] = dict()
    platform_index: int
    options: Any
    desired_capabilities: Any
    bstack1ll1l1ll11l_opy_: Any
    bstack1l11l111l1l_opy_: Dict
    def __init__(
        self,
        platform_index: int,
        framework_name: str,
        framework_version: str,
        classes: List[Type],
        methods=[bstack1ll1lll_opy_ (u"ࠧࡲࡡࡶࡰࡦ࡬ࠧᐳ"), bstack1ll1lll_opy_ (u"ࠨࡣࡰࡰࡱࡩࡨࡺࠢᐴ"), bstack1ll1lll_opy_ (u"ࠢ࡯ࡧࡺࡣࡵࡧࡧࡦࠤᐵ"), bstack1ll1lll_opy_ (u"ࠣࡥ࡯ࡳࡸ࡫ࠢᐶ"), bstack1ll1lll_opy_ (u"ࠤࡧ࡭ࡸࡶࡡࡵࡥ࡫ࠦᐷ")],
    ):
        super().__init__(
            framework_name,
            framework_version,
            classes,
        )
        self.platform_index = platform_index
        self.bstack1llll1ll111_opy_(methods)
    def bstack1lllll11lll_opy_(self, instance: bstack1lllll1lll1_opy_, method_name: str, bstack1llllll1ll1_opy_: timedelta, *args, **kwargs):
        pass
    def bstack1llllll1111_opy_(
        self,
        target: object,
        exec: Tuple[bstack1lllll1lll1_opy_, str],
        bstack1lllll11l11_opy_: Tuple[bstack1llll1l11ll_opy_, bstack1lllll11ll1_opy_],
        result: Any,
        *args,
        **kwargs,
    ) -> Callable[..., Any]:
        instance, method_name = exec
        bstack1lllllll111_opy_, bstack1l11l11111l_opy_ = bstack1lllll11l11_opy_
        bstack1l111llll11_opy_ = bstack1lll11l1ll1_opy_.bstack1l11l111l11_opy_(bstack1lllll11l11_opy_)
        if bstack1l111llll11_opy_ in bstack1lll11l1ll1_opy_.bstack1l11l1111l1_opy_:
            bstack1l11l1111ll_opy_ = None
            for callback in bstack1lll11l1ll1_opy_.bstack1l11l1111l1_opy_[bstack1l111llll11_opy_]:
                try:
                    bstack1l111lllll1_opy_ = callback(self, target, exec, bstack1lllll11l11_opy_, result, *args, **kwargs)
                    if bstack1l11l1111ll_opy_ == None:
                        bstack1l11l1111ll_opy_ = bstack1l111lllll1_opy_
                except Exception as e:
                    self.logger.error(bstack1ll1lll_opy_ (u"ࠥࡩࡷࡸ࡯ࡳࠢ࡬ࡲࡻࡵ࡫ࡪࡰࡪࠤࡨࡧ࡬࡭ࡤࡤࡧࡰࡀࠠࠣᐸ") + str(e) + bstack1ll1lll_opy_ (u"ࠦࠧᐹ"))
                    traceback.print_exc()
            if bstack1l11l11111l_opy_ == bstack1lllll11ll1_opy_.PRE and callable(bstack1l11l1111ll_opy_):
                return bstack1l11l1111ll_opy_
            elif bstack1l11l11111l_opy_ == bstack1lllll11ll1_opy_.POST and bstack1l11l1111ll_opy_:
                return bstack1l11l1111ll_opy_
    def bstack1llll1lll11_opy_(
        self, method_name, previous_state: bstack1llll1l11ll_opy_, *args, **kwargs
    ) -> bstack1llll1l11ll_opy_:
        if method_name == bstack1ll1lll_opy_ (u"ࠬࡲࡡࡶࡰࡦ࡬ࠬᐺ") or method_name == bstack1ll1lll_opy_ (u"࠭ࡣࡰࡰࡱࡩࡨࡺࠧᐻ") or method_name == bstack1ll1lll_opy_ (u"ࠧ࡯ࡧࡺࡣࡵࡧࡧࡦࠩᐼ"):
            return bstack1llll1l11ll_opy_.bstack1llll1ll11l_opy_
        if method_name == bstack1ll1lll_opy_ (u"ࠨࡦ࡬ࡷࡵࡧࡴࡤࡪࠪᐽ"):
            return bstack1llll1l11ll_opy_.bstack1llll11ll1l_opy_
        if method_name == bstack1ll1lll_opy_ (u"ࠩࡦࡰࡴࡹࡥࠨᐾ"):
            return bstack1llll1l11ll_opy_.QUIT
        return bstack1llll1l11ll_opy_.NONE
    @staticmethod
    def bstack1l11l111l11_opy_(bstack1lllll11l11_opy_: Tuple[bstack1llll1l11ll_opy_, bstack1lllll11ll1_opy_]):
        return bstack1ll1lll_opy_ (u"ࠥ࠾ࠧᐿ").join((bstack1llll1l11ll_opy_(bstack1lllll11l11_opy_[0]).name, bstack1lllll11ll1_opy_(bstack1lllll11l11_opy_[1]).name))
    @staticmethod
    def bstack1ll11lllll1_opy_(bstack1lllll11l11_opy_: Tuple[bstack1llll1l11ll_opy_, bstack1lllll11ll1_opy_], callback: Callable):
        bstack1l111llll11_opy_ = bstack1lll11l1ll1_opy_.bstack1l11l111l11_opy_(bstack1lllll11l11_opy_)
        if not bstack1l111llll11_opy_ in bstack1lll11l1ll1_opy_.bstack1l11l1111l1_opy_:
            bstack1lll11l1ll1_opy_.bstack1l11l1111l1_opy_[bstack1l111llll11_opy_] = []
        bstack1lll11l1ll1_opy_.bstack1l11l1111l1_opy_[bstack1l111llll11_opy_].append(callback)
    @staticmethod
    def bstack1ll111ll1ll_opy_(method_name: str):
        return True
    @staticmethod
    def bstack1ll11ll11l1_opy_(method_name: str, *args) -> bool:
        return True
    @staticmethod
    def bstack1ll111111ll_opy_(instance: bstack1lllll1lll1_opy_, default_value=None):
        return bstack1llll11llll_opy_.bstack1lllll1l1ll_opy_(instance, bstack1lll11l1ll1_opy_.bstack1l1l1111l1l_opy_, default_value)
    @staticmethod
    def bstack1l1llll111l_opy_(instance: bstack1lllll1lll1_opy_) -> bool:
        return True
    @staticmethod
    def bstack1ll11ll1lll_opy_(instance: bstack1lllll1lll1_opy_, default_value=None):
        return bstack1llll11llll_opy_.bstack1lllll1l1ll_opy_(instance, bstack1lll11l1ll1_opy_.bstack1l1l111l11l_opy_, default_value)
    @staticmethod
    def bstack1ll11111l1l_opy_(*args):
        return args[0] if args and type(args) in [list, tuple] and isinstance(args[0], str) else None
    @staticmethod
    def bstack1ll11l11ll1_opy_(method_name: str, *args):
        if not bstack1lll11l1ll1_opy_.bstack1ll111ll1ll_opy_(method_name):
            return False
        if not bstack1lll11l1ll1_opy_.bstack1l11l111111_opy_ in bstack1lll11l1ll1_opy_.bstack1l11ll1l111_opy_(*args):
            return False
        bstack1l1llllll11_opy_ = bstack1lll11l1ll1_opy_.bstack1l1llll1lll_opy_(*args)
        return bstack1l1llllll11_opy_ and bstack1ll1lll_opy_ (u"ࠦࡸࡩࡲࡪࡲࡷࠦᑀ") in bstack1l1llllll11_opy_ and bstack1ll1lll_opy_ (u"ࠧࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࠨᑁ") in bstack1l1llllll11_opy_[bstack1ll1lll_opy_ (u"ࠨࡳࡤࡴ࡬ࡴࡹࠨᑂ")]
    @staticmethod
    def bstack1ll11ll1111_opy_(method_name: str, *args):
        if not bstack1lll11l1ll1_opy_.bstack1ll111ll1ll_opy_(method_name):
            return False
        if not bstack1lll11l1ll1_opy_.bstack1l11l111111_opy_ in bstack1lll11l1ll1_opy_.bstack1l11ll1l111_opy_(*args):
            return False
        bstack1l1llllll11_opy_ = bstack1lll11l1ll1_opy_.bstack1l1llll1lll_opy_(*args)
        return (
            bstack1l1llllll11_opy_
            and bstack1ll1lll_opy_ (u"ࠢࡴࡥࡵ࡭ࡵࡺࠢᑃ") in bstack1l1llllll11_opy_
            and bstack1ll1lll_opy_ (u"ࠣࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿ࡟ࡢࡷࡷࡳࡲࡧࡴࡪࡱࡱࡣࡸࡩࡲࡪࡲࡷࠦᑄ") in bstack1l1llllll11_opy_[bstack1ll1lll_opy_ (u"ࠤࡶࡧࡷ࡯ࡰࡵࠤᑅ")]
        )
    @staticmethod
    def bstack1l11ll1l111_opy_(*args):
        return str(bstack1lll11l1ll1_opy_.bstack1ll11111l1l_opy_(*args)).lower()