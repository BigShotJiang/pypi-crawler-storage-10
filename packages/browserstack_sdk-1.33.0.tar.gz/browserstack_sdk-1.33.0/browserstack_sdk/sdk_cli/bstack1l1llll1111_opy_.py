# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
from browserstack_sdk.sdk_cli.bstack1lll11111l1_opy_ import bstack1lll1ll11l1_opy_
from browserstack_sdk.sdk_cli.bstack1lllll1llll_opy_ import (
    bstack1llll1l11ll_opy_,
    bstack1lllll11ll1_opy_,
    bstack1llll11llll_opy_,
    bstack1lllll1lll1_opy_,
)
from browserstack_sdk.sdk_cli.bstack1lll11ll11l_opy_ import bstack1ll1l11ll1l_opy_
from browserstack_sdk.sdk_cli.bstack1lll11llll1_opy_ import bstack1lll11l1ll1_opy_
from browserstack_sdk.sdk_cli.bstack1llll1l111l_opy_ import bstack1llll1l1l11_opy_
from typing import Tuple, Dict, Any, List, Callable
from browserstack_sdk.sdk_cli.bstack1lll11111l1_opy_ import bstack1lll1ll11l1_opy_
import weakref
class bstack1l1llll1l1l_opy_(bstack1lll1ll11l1_opy_):
    bstack1l1lll1l1ll_opy_: str
    frameworks: List[str]
    drivers: Dict[str, Tuple[Callable, bstack1lllll1lll1_opy_]]
    pages: Dict[str, Tuple[Callable, bstack1lllll1lll1_opy_]]
    def __init__(self, bstack1l1lll1l1ll_opy_: str, frameworks: List[str]):
        super().__init__()
        self.drivers = dict()
        self.pages = dict()
        self.bstack1l1lll1ll11_opy_ = dict()
        self.bstack1l1lll1l1ll_opy_ = bstack1l1lll1l1ll_opy_
        self.frameworks = frameworks
        bstack1lll11l1ll1_opy_.bstack1ll11lllll1_opy_((bstack1llll1l11ll_opy_.bstack1llll1ll11l_opy_, bstack1lllll11ll1_opy_.POST), self.__1l1llll11l1_opy_)
        if any(bstack1ll1l11ll1l_opy_.NAME in f.lower().strip() for f in frameworks):
            bstack1ll1l11ll1l_opy_.bstack1ll11lllll1_opy_(
                (bstack1llll1l11ll_opy_.bstack1llll1lll1l_opy_, bstack1lllll11ll1_opy_.PRE), self.__1l1lll1llll_opy_
            )
            bstack1ll1l11ll1l_opy_.bstack1ll11lllll1_opy_(
                (bstack1llll1l11ll_opy_.QUIT, bstack1lllll11ll1_opy_.POST), self.__1l1lll1l1l1_opy_
            )
    def __1l1llll11l1_opy_(
        self,
        f: bstack1lll11l1ll1_opy_,
        bstack1l1lll1lll1_opy_: object,
        exec: Tuple[bstack1lllll1lll1_opy_, str],
        bstack1lllll11l11_opy_: Tuple[bstack1llll1l11ll_opy_, bstack1lllll11ll1_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        try:
            instance, method_name = exec
            if method_name != bstack1ll1lll_opy_ (u"ࠥࡲࡪࡽ࡟ࡱࡣࡪࡩࠧባ"):
                return
            contexts = bstack1l1lll1lll1_opy_.browser.contexts
            if contexts:
                for context in contexts:
                    if context.pages:
                        for page in context.pages:
                            if bstack1ll1lll_opy_ (u"ࠦࡦࡨ࡯ࡶࡶ࠽ࡦࡱࡧ࡮࡬ࠤቤ") in page.url:
                                self.logger.debug(bstack1ll1lll_opy_ (u"࡙ࠧࡴࡰࡴ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡲࡪࡽࠠࡱࡣࡪࡩࠥ࡯࡮ࡴࡶࡤࡲࡨ࡫ࠢብ"))
                                self.pages[instance.ref()] = weakref.ref(page), instance
                                bstack1llll11llll_opy_.bstack1llll1l1l1l_opy_(instance, self.bstack1l1lll1l1ll_opy_, True)
                                self.logger.debug(bstack1ll1lll_opy_ (u"ࠨ࡟ࡠࡱࡱࡣࡵࡧࡧࡦࡡ࡬ࡲ࡮ࡺ࠺ࠡ࡫ࡱࡷࡹࡧ࡮ࡤࡧࡀࠦቦ") + str(instance.ref()) + bstack1ll1lll_opy_ (u"ࠢࠣቧ"))
        except Exception as e:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠣࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡴࡶࡲࡶ࡮ࡴࡧࠡࡰࡨࡻࠥࡶࡡࡨࡧࠣ࠾ࠧቨ"),e)
    def __1l1lll1llll_opy_(
        self,
        f: bstack1ll1l11ll1l_opy_,
        driver: object,
        exec: Tuple[bstack1lllll1lll1_opy_, str],
        bstack1lllll11l11_opy_: Tuple[bstack1llll1l11ll_opy_, bstack1lllll11ll1_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance, _ = exec
        if instance.ref() in self.drivers or bstack1llll11llll_opy_.bstack1lllll1l1ll_opy_(instance, self.bstack1l1lll1l1ll_opy_, False):
            return
        if not f.bstack1ll11111111_opy_(f.hub_url(driver)):
            self.bstack1l1lll1ll11_opy_[instance.ref()] = weakref.ref(driver), instance
            bstack1llll11llll_opy_.bstack1llll1l1l1l_opy_(instance, self.bstack1l1lll1l1ll_opy_, True)
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠤࡢࡣࡴࡴ࡟ࡴࡧ࡯ࡩࡳ࡯ࡵ࡮ࡡ࡬ࡲ࡮ࡺ࠺ࠡࡰࡲࡲࡤࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡩࡸࡩࡷࡧࡵࠤ࡮ࡴࡳࡵࡣࡱࡧࡪࡃࠢቩ") + str(instance.ref()) + bstack1ll1lll_opy_ (u"ࠥࠦቪ"))
            return
        self.drivers[instance.ref()] = weakref.ref(driver), instance
        bstack1llll11llll_opy_.bstack1llll1l1l1l_opy_(instance, self.bstack1l1lll1l1ll_opy_, True)
        self.logger.debug(bstack1ll1lll_opy_ (u"ࠦࡤࡥ࡯࡯ࡡࡶࡩࡱ࡫࡮ࡪࡷࡰࡣ࡮ࡴࡩࡵ࠼ࠣ࡭ࡳࡹࡴࡢࡰࡦࡩࡂࠨቫ") + str(instance.ref()) + bstack1ll1lll_opy_ (u"ࠧࠨቬ"))
    def __1l1lll1l1l1_opy_(
        self,
        f: bstack1ll1l11ll1l_opy_,
        driver: object,
        exec: Tuple[bstack1lllll1lll1_opy_, str],
        bstack1lllll11l11_opy_: Tuple[bstack1llll1l11ll_opy_, bstack1lllll11ll1_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance, _ = exec
        if not instance.ref() in self.drivers:
            return
        self.bstack1l1lll1l111_opy_(instance)
        self.logger.debug(bstack1ll1lll_opy_ (u"ࠨ࡟ࡠࡱࡱࡣࡸ࡫࡬ࡦࡰ࡬ࡹࡲࡥࡱࡶ࡫ࡷ࠾ࠥ࡯࡮ࡴࡶࡤࡲࡨ࡫࠽ࠣቭ") + str(instance.ref()) + bstack1ll1lll_opy_ (u"ࠢࠣቮ"))
    def bstack1l1lll1ll1l_opy_(self, context: bstack1llll1l1l11_opy_, reverse=True) -> List[Tuple[Callable, bstack1lllll1lll1_opy_]]:
        matches = []
        if self.pages:
            for data in self.pages.values():
                if data[1].bstack1l1lll1l11l_opy_(context):
                    matches.append(data)
        if self.drivers:
            for data in self.drivers.values():
                if (
                    bstack1ll1l11ll1l_opy_.bstack1l1llll111l_opy_(data[1])
                    and data[1].bstack1l1lll1l11l_opy_(context)
                    and getattr(data[0](), bstack1ll1lll_opy_ (u"ࠣࡵࡨࡷࡸ࡯࡯࡯ࡡ࡬ࡨࠧቯ"), False)
                ):
                    matches.append(data)
        return sorted(matches, key=lambda d: d[1].bstack1llll1ll1ll_opy_, reverse=reverse)
    def bstack1l1llll11ll_opy_(self, context: bstack1llll1l1l11_opy_, reverse=True) -> List[Tuple[Callable, bstack1lllll1lll1_opy_]]:
        matches = []
        for data in self.bstack1l1lll1ll11_opy_.values():
            if (
                data[1].bstack1l1lll1l11l_opy_(context)
                and getattr(data[0](), bstack1ll1lll_opy_ (u"ࠤࡶࡩࡸࡹࡩࡰࡰࡢ࡭ࡩࠨተ"), False)
            ):
                matches.append(data)
        return sorted(matches, key=lambda d: d[1].bstack1llll1ll1ll_opy_, reverse=reverse)
    def bstack1l1llll1l11_opy_(self, instance: bstack1lllll1lll1_opy_) -> bool:
        return instance and instance.ref() in self.drivers
    def bstack1l1lll1l111_opy_(self, instance: bstack1lllll1lll1_opy_) -> bool:
        if self.bstack1l1llll1l11_opy_(instance):
            self.drivers.pop(instance.ref())
            bstack1llll11llll_opy_.bstack1llll1l1l1l_opy_(instance, self.bstack1l1lll1l1ll_opy_, False)
            return True
        return False