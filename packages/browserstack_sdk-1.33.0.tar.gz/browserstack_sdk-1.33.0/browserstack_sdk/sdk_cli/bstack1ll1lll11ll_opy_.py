# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import json
import time
from datetime import datetime, timezone
from browserstack_sdk.sdk_cli.bstack1lllll1llll_opy_ import (
    bstack1llll1l11ll_opy_,
    bstack1lllll11ll1_opy_,
    bstack1llll11llll_opy_,
    bstack1lllll1lll1_opy_,
    bstack1llll1l1l11_opy_,
)
from browserstack_sdk.sdk_cli.bstack1lll11ll11l_opy_ import bstack1ll1l11ll1l_opy_
from browserstack_sdk.sdk_cli.test_framework import TestFramework, bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_, bstack1lll11ll1l1_opy_
from browserstack_sdk.sdk_cli.bstack1l1llll1111_opy_ import bstack1l1llll1l1l_opy_
from typing import Tuple, Dict, Any, List, Union
from bstack_utils.helper import bstack1l1l1ll11l1_opy_
from browserstack_sdk import sdk_pb2 as structs
from bstack_utils.measure import measure
from bstack_utils.constants import *
from typing import Tuple, List, Any
class bstack1lll111llll_opy_(bstack1l1llll1l1l_opy_):
    bstack1l11llll1ll_opy_ = bstack1ll1lll_opy_ (u"ࠨࡴࡦࡵࡷࡣࡩࡸࡩࡷࡧࡵࡷࠧᏙ")
    bstack1l1ll111111_opy_ = bstack1ll1lll_opy_ (u"ࠢࡢࡷࡷࡳࡲࡧࡴࡪࡱࡱࡣࡸ࡫ࡳࡴ࡫ࡲࡲࡸࠨᏚ")
    bstack1l11llll1l1_opy_ = bstack1ll1lll_opy_ (u"ࠣࡰࡲࡲࡤࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡦࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࡠࡵࡨࡷࡸ࡯࡯࡯ࡵࠥᏛ")
    bstack1l11lllllll_opy_ = bstack1ll1lll_opy_ (u"ࠤࡷࡩࡸࡺ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࡴࠤᏜ")
    bstack1l11lll1l1l_opy_ = bstack1ll1lll_opy_ (u"ࠥࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴ࡟ࡪࡰࡶࡸࡦࡴࡣࡦࡡࡵࡩ࡫ࡹࠢᏝ")
    bstack1l1ll111l11_opy_ = bstack1ll1lll_opy_ (u"ࠦࡨࡨࡴࡠࡵࡨࡷࡸ࡯࡯࡯ࡡࡦࡶࡪࡧࡴࡦࡦࠥᏞ")
    bstack1l11lll11l1_opy_ = bstack1ll1lll_opy_ (u"ࠧࡩࡢࡵࡡࡶࡩࡸࡹࡩࡰࡰࡢࡲࡦࡳࡥࠣᏟ")
    bstack1l11lll111l_opy_ = bstack1ll1lll_opy_ (u"ࠨࡣࡣࡶࡢࡷࡪࡹࡳࡪࡱࡱࡣࡸࡺࡡࡵࡷࡶࠦᏠ")
    def __init__(self):
        super().__init__(bstack1l1lll1l1ll_opy_=self.bstack1l11llll1ll_opy_, frameworks=[bstack1ll1l11ll1l_opy_.NAME])
        if not self.is_enabled():
            return
        TestFramework.bstack1ll11lllll1_opy_((bstack1lll1111111_opy_.BEFORE_EACH, bstack1lll1l1l1ll_opy_.POST), self.bstack1l11l11ll11_opy_)
        TestFramework.bstack1ll11lllll1_opy_((bstack1lll1111111_opy_.TEST, bstack1lll1l1l1ll_opy_.PRE), self.bstack1ll11lll11l_opy_)
        TestFramework.bstack1ll11lllll1_opy_((bstack1lll1111111_opy_.TEST, bstack1lll1l1l1ll_opy_.POST), self.bstack1ll11111l11_opy_)
    def is_enabled(self) -> bool:
        return True
    def bstack1l11l11ll11_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll11ll1l1_opy_,
        bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_],
        *args,
        **kwargs,
    ):
        bstack1l1l1l1111l_opy_ = self.bstack1l11l1l1111_opy_(instance.context)
        if not bstack1l1l1l1111l_opy_:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠢࡴࡧࡷࡣࡦࡩࡴࡪࡸࡨࡣࡩࡸࡩࡷࡧࡵࡷ࠿ࠦ࡮ࡰࠢࡧࡶ࡮ࡼࡥࡳࠢࡩࡳࡷࠦࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰ࠿ࠥᏡ") + str(bstack1lllll11l11_opy_) + bstack1ll1lll_opy_ (u"ࠣࠤᏢ"))
        f.bstack1llll1l1l1l_opy_(instance, bstack1lll111llll_opy_.bstack1l1ll111111_opy_, bstack1l1l1l1111l_opy_)
        bstack1l11l11l111_opy_ = self.bstack1l11l1l1111_opy_(instance.context, bstack1l11l11llll_opy_=False)
        f.bstack1llll1l1l1l_opy_(instance, bstack1lll111llll_opy_.bstack1l11llll1l1_opy_, bstack1l11l11l111_opy_)
    def bstack1ll11lll11l_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll11ll1l1_opy_,
        bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l11l11ll11_opy_(f, instance, bstack1lllll11l11_opy_, *args, **kwargs)
        if not f.bstack1lllll1l1ll_opy_(instance, bstack1lll111llll_opy_.bstack1l11lll11l1_opy_, False):
            self.__1l11l1l11l1_opy_(f,instance,bstack1lllll11l11_opy_)
    def bstack1ll11111l11_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll11ll1l1_opy_,
        bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l11l11ll11_opy_(f, instance, bstack1lllll11l11_opy_, *args, **kwargs)
        if not f.bstack1lllll1l1ll_opy_(instance, bstack1lll111llll_opy_.bstack1l11lll11l1_opy_, False):
            self.__1l11l1l11l1_opy_(f, instance, bstack1lllll11l11_opy_)
        if not f.bstack1lllll1l1ll_opy_(instance, bstack1lll111llll_opy_.bstack1l11lll111l_opy_, False):
            self.__1l11l11l1ll_opy_(f, instance, bstack1lllll11l11_opy_)
    def bstack1l11l111ll1_opy_(
        self,
        f: bstack1ll1l11ll1l_opy_,
        driver: object,
        exec: Tuple[bstack1lllll1lll1_opy_, str],
        bstack1lllll11l11_opy_: Tuple[bstack1llll1l11ll_opy_, bstack1lllll11ll1_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance = exec[0]
        if not f.bstack1l1llll111l_opy_(instance):
            return
        if f.bstack1lllll1l1ll_opy_(instance, bstack1lll111llll_opy_.bstack1l11lll111l_opy_, False):
            return
        driver.execute_script(
            bstack1ll1lll_opy_ (u"ࠤࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࢃࠢᏣ").format(
                json.dumps(
                    {
                        bstack1ll1lll_opy_ (u"ࠥࡥࡨࡺࡩࡰࡰࠥᏤ"): bstack1ll1lll_opy_ (u"ࠦࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡔࡶࡤࡸࡺࡹࠢᏥ"),
                        bstack1ll1lll_opy_ (u"ࠧࡧࡲࡨࡷࡰࡩࡳࡺࡳࠣᏦ"): {bstack1ll1lll_opy_ (u"ࠨࡳࡵࡣࡷࡹࡸࠨᏧ"): result},
                    }
                )
            )
        )
        f.bstack1llll1l1l1l_opy_(instance, bstack1lll111llll_opy_.bstack1l11lll111l_opy_, True)
    def bstack1l11l1l1111_opy_(self, context: bstack1llll1l1l11_opy_, bstack1l11l11llll_opy_= True):
        if bstack1l11l11llll_opy_:
            bstack1l1l1l1111l_opy_ = self.bstack1l1lll1ll1l_opy_(context, reverse=True)
        else:
            bstack1l1l1l1111l_opy_ = self.bstack1l1llll11ll_opy_(context, reverse=True)
        return [f for f in bstack1l1l1l1111l_opy_ if f[1].state != bstack1llll1l11ll_opy_.QUIT]
    @measure(event_name=EVENTS.bstack1lll1l1l_opy_, stage=STAGE.bstack111lll1l11_opy_)
    def __1l11l11l1ll_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll11ll1l1_opy_,
        bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_],
    ):
        from browserstack_sdk.sdk_cli.cli import cli
        if not cli.config.get(bstack1ll1lll_opy_ (u"ࠢࡵࡧࡶࡸࡈࡵ࡮ࡵࡧࡻࡸࡔࡶࡴࡪࡱࡱࡷࠧᏨ")).get(bstack1ll1lll_opy_ (u"ࠣࡵ࡮࡭ࡵ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷࠧᏩ")):
            bstack1l1l1l1111l_opy_ = f.bstack1lllll1l1ll_opy_(instance, bstack1lll111llll_opy_.bstack1l1ll111111_opy_, [])
            if not bstack1l1l1l1111l_opy_:
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠤࡶࡩࡹࡥࡡࡤࡶ࡬ࡺࡪࡥࡤࡳ࡫ࡹࡩࡷࡹ࠺ࠡࡰࡲࠤࡩࡸࡩࡷࡧࡵࠤ࡫ࡵࡲࠡࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࡁࠧᏪ") + str(bstack1lllll11l11_opy_) + bstack1ll1lll_opy_ (u"ࠥࠦᏫ"))
                return
            driver = bstack1l1l1l1111l_opy_[0][0]()
            status = f.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1l11llll111_opy_, None)
            if not status:
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠦࡸ࡫ࡴࡠࡣࡦࡸ࡮ࡼࡥࡠࡦࡵ࡭ࡻ࡫ࡲࡴ࠼ࠣࡲࡴࠦࡳࡵࡣࡷࡹࡸࠦࡦࡰࡴࠣࡸࡪࡹࡴ࠭ࠢ࡫ࡳࡴࡱ࡟ࡪࡰࡩࡳࡂࠨᏬ") + str(bstack1lllll11l11_opy_) + bstack1ll1lll_opy_ (u"ࠧࠨᏭ"))
                return
            bstack1l11lll1lll_opy_ = {bstack1ll1lll_opy_ (u"ࠨࡳࡵࡣࡷࡹࡸࠨᏮ"): status.lower()}
            bstack1l11llllll1_opy_ = f.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1l11lll1ll1_opy_, None)
            if status.lower() == bstack1ll1lll_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧᏯ") and bstack1l11llllll1_opy_ is not None:
                bstack1l11lll1lll_opy_[bstack1ll1lll_opy_ (u"ࠨࡴࡨࡥࡸࡵ࡮ࠨᏰ")] = bstack1l11llllll1_opy_[0][bstack1ll1lll_opy_ (u"ࠩࡥࡥࡨࡱࡴࡳࡣࡦࡩࠬᏱ")][0] if isinstance(bstack1l11llllll1_opy_, list) else str(bstack1l11llllll1_opy_)
            driver.execute_script(
                bstack1ll1lll_opy_ (u"ࠥࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࡽࠣᏲ").format(
                    json.dumps(
                        {
                            bstack1ll1lll_opy_ (u"ࠦࡦࡩࡴࡪࡱࡱࠦᏳ"): bstack1ll1lll_opy_ (u"ࠧࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡕࡷࡥࡹࡻࡳࠣᏴ"),
                            bstack1ll1lll_opy_ (u"ࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤᏵ"): bstack1l11lll1lll_opy_,
                        }
                    )
                )
            )
            f.bstack1llll1l1l1l_opy_(instance, bstack1lll111llll_opy_.bstack1l11lll111l_opy_, True)
    @measure(event_name=EVENTS.bstack1lll1l11_opy_, stage=STAGE.bstack111lll1l11_opy_)
    def __1l11l1l11l1_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll11ll1l1_opy_,
        bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_]
    ):
        from browserstack_sdk.sdk_cli.cli import cli
        if not cli.config.get(bstack1ll1lll_opy_ (u"ࠢࡵࡧࡶࡸࡈࡵ࡮ࡵࡧࡻࡸࡔࡶࡴࡪࡱࡱࡷࠧ᏶")).get(bstack1ll1lll_opy_ (u"ࠣࡵ࡮࡭ࡵ࡙ࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠥ᏷")):
            test_name = f.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1l11l11lll1_opy_, None)
            if not test_name:
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠤࡲࡲࡤࡨࡥࡧࡱࡵࡩࡤࡺࡥࡴࡶ࠽ࠤࡲ࡯ࡳࡴ࡫ࡱ࡫ࠥࡺࡥࡴࡶࠣࡲࡦࡳࡥࠣᏸ"))
                return
            bstack1l1l1l1111l_opy_ = f.bstack1lllll1l1ll_opy_(instance, bstack1lll111llll_opy_.bstack1l1ll111111_opy_, [])
            if not bstack1l1l1l1111l_opy_:
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠥࡷࡪࡺ࡟ࡢࡥࡷ࡭ࡻ࡫࡟ࡥࡴ࡬ࡺࡪࡸࡳ࠻ࠢࡱࡳࠥࡹࡴࡢࡶࡸࡷࠥ࡬࡯ࡳࠢࡷࡩࡸࡺࠬࠡࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࡁࠧᏹ") + str(bstack1lllll11l11_opy_) + bstack1ll1lll_opy_ (u"ࠦࠧᏺ"))
                return
            for bstack1l1l11l1ll1_opy_, bstack1l11l11l1l1_opy_ in bstack1l1l1l1111l_opy_:
                if not bstack1ll1l11ll1l_opy_.bstack1l1llll111l_opy_(bstack1l11l11l1l1_opy_):
                    continue
                driver = bstack1l1l11l1ll1_opy_()
                if not driver:
                    continue
                driver.execute_script(
                    bstack1ll1lll_opy_ (u"ࠧࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࡿࠥᏻ").format(
                        json.dumps(
                            {
                                bstack1ll1lll_opy_ (u"ࠨࡡࡤࡶ࡬ࡳࡳࠨᏼ"): bstack1ll1lll_opy_ (u"ࠢࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠣᏽ"),
                                bstack1ll1lll_opy_ (u"ࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ᏾"): {bstack1ll1lll_opy_ (u"ࠤࡱࡥࡲ࡫ࠢ᏿"): test_name},
                            }
                        )
                    )
                )
            f.bstack1llll1l1l1l_opy_(instance, bstack1lll111llll_opy_.bstack1l11lll11l1_opy_, True)
    def bstack1l1ll1l1l1l_opy_(
        self,
        instance: bstack1lll11ll1l1_opy_,
        f: TestFramework,
        bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l11l11ll11_opy_(f, instance, bstack1lllll11l11_opy_, *args, **kwargs)
        bstack1l1l1l1111l_opy_ = [d for d, _ in f.bstack1lllll1l1ll_opy_(instance, bstack1lll111llll_opy_.bstack1l1ll111111_opy_, [])]
        if not bstack1l1l1l1111l_opy_:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠥࡳࡳࡥࡡࡧࡶࡨࡶࡤࡺࡥࡴࡶ࠽ࠤࡳࡵࠠࡴࡧࡶࡷ࡮ࡵ࡮ࡴࠢࡷࡳࠥࡲࡩ࡯࡭ࠥ᐀"))
            return
        if not bstack1l1l1ll11l1_opy_():
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠦࡴࡴ࡟ࡢࡨࡷࡩࡷࡥࡴࡦࡵࡷ࠾ࠥࡴ࡯ࡵࠢࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠡࡵࡨࡷࡸ࡯࡯࡯ࠤᐁ"))
            return
        for bstack1l11l111lll_opy_ in bstack1l1l1l1111l_opy_:
            driver = bstack1l11l111lll_opy_()
            if not driver:
                continue
            timestamp = int(time.time() * 1000)
            data = bstack1ll1lll_opy_ (u"ࠧࡕࡢࡴࡧࡵࡺࡦࡨࡩ࡭࡫ࡷࡽࡘࡿ࡮ࡤ࠼ࠥᐂ") + str(timestamp)
            driver.execute_script(
                bstack1ll1lll_opy_ (u"ࠨࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࢀࠦᐃ").format(
                    json.dumps(
                        {
                            bstack1ll1lll_opy_ (u"ࠢࡢࡥࡷ࡭ࡴࡴࠢᐄ"): bstack1ll1lll_opy_ (u"ࠣࡣࡱࡲࡴࡺࡡࡵࡧࠥᐅ"),
                            bstack1ll1lll_opy_ (u"ࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧᐆ"): {
                                bstack1ll1lll_opy_ (u"ࠥࡸࡾࡶࡥࠣᐇ"): bstack1ll1lll_opy_ (u"ࠦࡆࡴ࡮ࡰࡶࡤࡸ࡮ࡵ࡮ࠣᐈ"),
                                bstack1ll1lll_opy_ (u"ࠧࡪࡡࡵࡣࠥᐉ"): data,
                                bstack1ll1lll_opy_ (u"ࠨ࡬ࡦࡸࡨࡰࠧᐊ"): bstack1ll1lll_opy_ (u"ࠢࡥࡧࡥࡹ࡬ࠨᐋ")
                            }
                        }
                    )
                )
            )
    def bstack1l1ll111lll_opy_(
        self,
        instance: bstack1lll11ll1l1_opy_,
        f: TestFramework,
        bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l11l11ll11_opy_(f, instance, bstack1lllll11l11_opy_, *args, **kwargs)
        keys = [
            bstack1lll111llll_opy_.bstack1l1ll111111_opy_,
            bstack1lll111llll_opy_.bstack1l11llll1l1_opy_,
        ]
        bstack1l1l1l1111l_opy_ = []
        for key in keys:
            bstack1l1l1l1111l_opy_.extend(f.bstack1lllll1l1ll_opy_(instance, key, []))
        if not bstack1l1l1l1111l_opy_:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠣࡱࡱࡣࡦ࡬ࡴࡦࡴࡢࡸࡪࡹࡴ࠻ࠢࡸࡲࡦࡨ࡬ࡦࠢࡷࡳࠥ࡬ࡩ࡯ࡦࠣࡥࡳࡿࠠࡴࡧࡶࡷ࡮ࡵ࡮ࡴࠢࡷࡳࠥࡲࡩ࡯࡭ࠥᐌ"))
            return
        if f.bstack1lllll1l1ll_opy_(instance, bstack1lll111llll_opy_.bstack1l1ll111l11_opy_, False):
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠤࡲࡲࡤࡧࡦࡵࡧࡵࡣࡹ࡫ࡳࡵ࠼ࠣࡇࡇ࡚ࠠࡢ࡮ࡵࡩࡦࡪࡹࠡࡥࡵࡩࡦࡺࡥࡥࠤᐍ"))
            return
        self.bstack1ll1111llll_opy_()
        bstack11l1lll11_opy_ = datetime.now()
        req = structs.TestSessionEventRequest()
        req.bin_session_id = self.bin_session_id
        req.platform_index = TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1ll111l1ll1_opy_)
        req.test_framework_name = TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1ll11ll1l11_opy_)
        req.test_framework_version = TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1l1ll1ll11l_opy_)
        req.test_framework_state = bstack1lllll11l11_opy_[0].name
        req.test_hook_state = bstack1lllll11l11_opy_[1].name
        req.test_uuid = TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1ll11ll111l_opy_)
        for bstack1l1l11l1ll1_opy_, driver in bstack1l1l1l1111l_opy_:
            try:
                webdriver = bstack1l1l11l1ll1_opy_()
                if webdriver is None:
                    self.logger.debug(bstack1ll1lll_opy_ (u"࡛ࠥࡪࡨࡄࡳ࡫ࡹࡩࡷࠦࡩ࡯ࡵࡷࡥࡳࡩࡥࠡ࡫ࡶࠤࡓࡵ࡮ࡦࠢࠫࡶࡪ࡬ࡥࡳࡧࡱࡧࡪࠦࡥࡹࡲ࡬ࡶࡪࡪࠩࠣᐎ"))
                    continue
                session = req.automation_sessions.add()
                session.provider = (
                    bstack1ll1lll_opy_ (u"ࠦࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࠥᐏ")
                    if bstack1ll1l11ll1l_opy_.bstack1lllll1l1ll_opy_(driver, bstack1ll1l11ll1l_opy_.bstack1l11l1l111l_opy_, False)
                    else bstack1ll1lll_opy_ (u"ࠧࡻ࡮࡬ࡰࡲࡻࡳࡥࡧࡳ࡫ࡧࠦᐐ")
                )
                session.ref = driver.ref()
                session.hub_url = bstack1ll1l11ll1l_opy_.bstack1lllll1l1ll_opy_(driver, bstack1ll1l11ll1l_opy_.bstack1l1l111l11l_opy_, bstack1ll1lll_opy_ (u"ࠨࠢᐑ"))
                session.framework_name = driver.framework_name
                session.framework_version = driver.framework_version
                session.framework_session_id = bstack1ll1l11ll1l_opy_.bstack1lllll1l1ll_opy_(driver, bstack1ll1l11ll1l_opy_.bstack1l1l111llll_opy_, bstack1ll1lll_opy_ (u"ࠢࠣᐒ"))
                caps = None
                if hasattr(webdriver, bstack1ll1lll_opy_ (u"ࠣࡥࡤࡴࡦࡨࡩ࡭࡫ࡷ࡭ࡪࡹࠢᐓ")):
                    try:
                        caps = webdriver.capabilities
                        self.logger.debug(bstack1ll1lll_opy_ (u"ࠤࡖࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠡࡴࡨࡸࡷ࡯ࡥࡷࡧࡧࠤࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠣࡨ࡮ࡸࡥࡤࡶ࡯ࡽࠥ࡬ࡲࡰ࡯ࠣࡨࡷ࡯ࡶࡦࡴ࠱ࡧࡦࡶࡡࡣ࡫࡯࡭ࡹ࡯ࡥࡴࠤᐔ"))
                    except Exception as e:
                        self.logger.debug(bstack1ll1lll_opy_ (u"ࠥࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡧࡦࡶࠣࡧࡦࡶࡡࡣ࡫࡯࡭ࡹ࡯ࡥࡴࠢࡩࡶࡴࡳࠠࡥࡴ࡬ࡺࡪࡸ࠮ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸࡀࠠࠣᐕ") + str(e) + bstack1ll1lll_opy_ (u"ࠦࠧᐖ"))
                try:
                    bstack1l11l11ll1l_opy_ = json.dumps(caps).encode(bstack1ll1lll_opy_ (u"ࠧࡻࡴࡧ࠯࠻ࠦᐗ")) if caps else bstack1l11l11l11l_opy_ (u"ࠨࡻࡾࠤᐘ")
                    req.capabilities = bstack1l11l11ll1l_opy_
                except Exception as e:
                    self.logger.debug(bstack1ll1lll_opy_ (u"ࠢࡨࡧࡷࡣࡨࡨࡴࡠࡧࡹࡩࡳࡺ࠺ࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡸ࡫࡮ࡥࠢࡶࡩࡷ࡯ࡡ࡭࡫ࡽࡩࠥࡩࡡࡱࡵࠣࡪࡴࡸࠠࡳࡧࡴࡹࡪࡹࡴ࠻ࠢࠥᐙ") + str(e) + bstack1ll1lll_opy_ (u"ࠣࠤᐚ"))
            except Exception as e:
                self.logger.error(bstack1ll1lll_opy_ (u"ࠤࡈࡶࡷࡵࡲࠡࡲࡵࡳࡨ࡫ࡳࡴ࡫ࡱ࡫ࠥࡪࡲࡪࡸࡨࡶࠥ࡯ࡴࡦ࡯࠽ࠤࠧᐛ") + str(str(e)) + bstack1ll1lll_opy_ (u"ࠥࠦᐜ"))
        req.execution_context.hash = str(instance.context.hash)
        req.execution_context.thread_id = str(instance.context.thread_id)
        req.execution_context.process_id = str(instance.context.process_id)
        return req
    def bstack1ll1111lll1_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll11ll1l1_opy_,
        bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_],
        *args,
        **kwargs
    ):
        bstack1l1l1l1111l_opy_ = f.bstack1lllll1l1ll_opy_(instance, bstack1lll111llll_opy_.bstack1l1ll111111_opy_, [])
        if not bstack1l1l1ll11l1_opy_() and len(bstack1l1l1l1111l_opy_) == 0:
            bstack1l1l1l1111l_opy_ = f.bstack1lllll1l1ll_opy_(instance, bstack1lll111llll_opy_.bstack1l11llll1l1_opy_, [])
        if not bstack1l1l1l1111l_opy_:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠦࡴࡴ࡟ࡣࡧࡩࡳࡷ࡫࡟ࡵࡧࡶࡸ࠿ࠦ࡮ࡰࠢࡧࡶ࡮ࡼࡥࡳࡵࠣࡪࡴࡸࠠࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࡀࡿ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵࡽࠡࡣࡵ࡫ࡸࡃࡻࡢࡴࡪࡷࢂࠦ࡫ࡸࡣࡵ࡫ࡸࡃࠢᐝ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠧࠨᐞ"))
            return {}
        if len(bstack1l1l1l1111l_opy_) > 1:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠨ࡯࡯ࡡࡥࡩ࡫ࡵࡲࡦࡡࡷࡩࡸࡺ࠺ࠡࡽ࡯ࡩࡳ࠮ࡤࡳ࡫ࡹࡩࡷࡥࡩ࡯ࡵࡷࡥࡳࡩࡥࡴࠫࢀࠤࡩࡸࡩࡷࡧࡵࡷࠥ࡬࡯ࡳࠢ࡫ࡳࡴࡱ࡟ࡪࡰࡩࡳࡂࢁࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰࡿࠣࡥࡷ࡭ࡳ࠾ࡽࡤࡶ࡬ࡹࡽࠡ࡭ࡺࡥࡷ࡭ࡳ࠾ࠤᐟ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠢࠣᐠ"))
            return {}
        bstack1l1l11l1ll1_opy_, bstack1l1l11ll1l1_opy_ = bstack1l1l1l1111l_opy_[0]
        driver = bstack1l1l11l1ll1_opy_()
        if not driver:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠣࡱࡱࡣࡧ࡫ࡦࡰࡴࡨࡣࡹ࡫ࡳࡵ࠼ࠣࡲࡴࠦࡤࡳ࡫ࡹࡩࡷࠦࡦࡰࡴࠣ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࡃࡻࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࢀࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡮ࡻࡦࡸࡧࡴ࠿ࠥᐡ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠤࠥᐢ"))
            return {}
        capabilities = f.bstack1lllll1l1ll_opy_(bstack1l1l11ll1l1_opy_, bstack1ll1l11ll1l_opy_.bstack1l1l1111l1l_opy_)
        if not capabilities:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠥࡳࡳࡥࡢࡦࡨࡲࡶࡪࡥࡴࡦࡵࡷ࠾ࠥࡴ࡯ࠡࡥࡤࡴࡦࡨࡩ࡭࡫ࡷ࡭ࡪࡹࠠࡧࡱࡸࡲࡩࠦࡦࡰࡴࠣ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࡃࡻࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࢀࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡮ࡻࡦࡸࡧࡴ࠿ࠥᐣ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠦࠧᐤ"))
            return {}
        return capabilities.get(bstack1ll1lll_opy_ (u"ࠧࡧ࡬ࡸࡣࡼࡷࡒࡧࡴࡤࡪࠥᐥ"), {})
    def bstack1ll11l1ll1l_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll11ll1l1_opy_,
        bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_],
        *args,
        **kwargs
    ):
        bstack1l1l1l1111l_opy_ = f.bstack1lllll1l1ll_opy_(instance, bstack1lll111llll_opy_.bstack1l1ll111111_opy_, [])
        if not bstack1l1l1ll11l1_opy_() and len(bstack1l1l1l1111l_opy_) == 0:
            bstack1l1l1l1111l_opy_ = f.bstack1lllll1l1ll_opy_(instance, bstack1lll111llll_opy_.bstack1l11llll1l1_opy_, [])
        if not bstack1l1l1l1111l_opy_:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠨࡧࡦࡶࡢࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴ࡟ࡥࡴ࡬ࡺࡪࡸ࠺ࠡࡰࡲࠤࡩࡸࡩࡷࡧࡵࡷࠥ࡬࡯ࡳࠢ࡫ࡳࡴࡱ࡟ࡪࡰࡩࡳࡂࢁࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰࡿࠣࡥࡷ࡭ࡳ࠾ࡽࡤࡶ࡬ࡹࡽࠡ࡭ࡺࡥࡷ࡭ࡳ࠾ࠤᐦ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠢࠣᐧ"))
            return
        if len(bstack1l1l1l1111l_opy_) > 1:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠣࡩࡨࡸࡤࡧࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࡡࡧࡶ࡮ࡼࡥࡳ࠼ࠣࡿࡱ࡫࡮ࠩࡦࡵ࡭ࡻ࡫ࡲࡠ࡫ࡱࡷࡹࡧ࡮ࡤࡧࡶ࠭ࢂࠦࡤࡳ࡫ࡹࡩࡷࡹࠠࡧࡱࡵࠤ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵ࠽ࡼࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࢁࠥࡧࡲࡨࡵࡀࡿࡦࡸࡧࡴࡿࠣ࡯ࡼࡧࡲࡨࡵࡀࠦᐨ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠤࠥᐩ"))
        bstack1l1l11l1ll1_opy_, bstack1l1l11ll1l1_opy_ = bstack1l1l1l1111l_opy_[0]
        driver = bstack1l1l11l1ll1_opy_()
        if not driver:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠥ࡫ࡪࡺ࡟ࡢࡷࡷࡳࡲࡧࡴࡪࡱࡱࡣࡩࡸࡩࡷࡧࡵ࠾ࠥࡴ࡯ࠡࡦࡵ࡭ࡻ࡫ࡲࠡࡨࡲࡶࠥ࡮࡯ࡰ࡭ࡢ࡭ࡳ࡬࡯࠾ࡽ࡫ࡳࡴࡱ࡟ࡪࡰࡩࡳࢂࠦࡡࡳࡩࡶࡁࢀࡧࡲࡨࡵࢀࠤࡰࡽࡡࡳࡩࡶࡁࠧᐪ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠦࠧᐫ"))
            return
        return driver