# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
from typing import Dict, List, Any, Callable, Tuple, Union
from browserstack_sdk import sdk_pb2 as structs
from browserstack_sdk.sdk_cli.bstack1lll11111l1_opy_ import bstack1lll1ll11l1_opy_
from browserstack_sdk.sdk_cli.bstack1lllll1llll_opy_ import (
    bstack1llll1l11ll_opy_,
    bstack1lllll11ll1_opy_,
    bstack1lllll1lll1_opy_,
)
from bstack_utils.helper import  bstack11l1l1lll_opy_
from browserstack_sdk.sdk_cli.bstack1lll11ll11l_opy_ import bstack1ll1l11ll1l_opy_
from browserstack_sdk.sdk_cli.test_framework import TestFramework, bstack1lll1111111_opy_, bstack1lll11ll1l1_opy_, bstack1lll1l1l1ll_opy_, bstack1lll1l1l1l1_opy_
from typing import Tuple, Any
import threading
from bstack_utils.bstack1l1111l1l_opy_ import bstack11l1l1ll11_opy_
from browserstack_sdk.sdk_cli.bstack1ll1lll11ll_opy_ import bstack1lll111llll_opy_
from bstack_utils.percy import bstack1l11l111_opy_
from bstack_utils.percy_sdk import PercySDK
from bstack_utils.constants import *
import re
class bstack1lll1111l11_opy_(bstack1lll1ll11l1_opy_):
    def __init__(self, bstack1l1l1l11111_opy_: Dict[str, str]):
        super().__init__()
        self.bstack1l1l1l11111_opy_ = bstack1l1l1l11111_opy_
        self.percy = bstack1l11l111_opy_()
        self.bstack11l11l1l1_opy_ = bstack11l1l1ll11_opy_()
        self.bstack1l1l11ll11l_opy_()
        bstack1ll1l11ll1l_opy_.bstack1ll11lllll1_opy_((bstack1llll1l11ll_opy_.bstack1llll1lll1l_opy_, bstack1lllll11ll1_opy_.PRE), self.bstack1l1l11lllll_opy_)
        TestFramework.bstack1ll11lllll1_opy_((bstack1lll1111111_opy_.TEST, bstack1lll1l1l1ll_opy_.POST), self.bstack1ll11111l11_opy_)
    def is_enabled(self) -> bool:
        return True
    def bstack1l1l1l1l111_opy_(self, instance: bstack1lllll1lll1_opy_, driver: object):
        bstack1l1l1llll11_opy_ = TestFramework.bstack1llll1l1111_opy_(instance.context)
        for t in bstack1l1l1llll11_opy_:
            bstack1l1l1l1111l_opy_ = TestFramework.bstack1lllll1l1ll_opy_(t, bstack1lll111llll_opy_.bstack1l1ll111111_opy_, [])
            if any(instance is d[1] for d in bstack1l1l1l1111l_opy_) or instance == driver:
                return t
    def bstack1l1l11lllll_opy_(
        self,
        f: bstack1ll1l11ll1l_opy_,
        driver: object,
        exec: Tuple[bstack1lllll1lll1_opy_, str],
        bstack1lllll11l11_opy_: Tuple[bstack1llll1l11ll_opy_, bstack1lllll11ll1_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        try:
            instance, method_name = exec
            if not bstack1ll1l11ll1l_opy_.bstack1ll111ll1ll_opy_(method_name):
                return
            platform_index = f.bstack1lllll1l1ll_opy_(instance, bstack1ll1l11ll1l_opy_.bstack1ll111l1ll1_opy_, 0)
            bstack1l1l1l1llll_opy_ = self.bstack1l1l1l1l111_opy_(instance, driver)
            bstack1l1l11llll1_opy_ = TestFramework.bstack1lllll1l1ll_opy_(bstack1l1l1l1llll_opy_, TestFramework.bstack1l1l11lll1l_opy_, None)
            if not bstack1l1l11llll1_opy_:
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠢࡰࡰࡢࡴࡷ࡫࡟ࡦࡺࡨࡧࡺࡺࡥ࠻ࠢࡵࡩࡹࡻࡲ࡯࡫ࡱ࡫ࠥࡧࡳࠡࡵࡨࡷࡸ࡯࡯࡯ࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡼࡩࡹࠦࡳࡵࡣࡵࡸࡪࡪࠢዳ"))
                return
            driver_command = f.bstack1ll11111l1l_opy_(*args)
            for command in bstack1lll1lllll_opy_:
                if command == driver_command:
                    self.bstack1lll111111_opy_(driver, platform_index)
            bstack1l111ll1_opy_ = self.percy.bstack1l11l1ll1l_opy_()
            if driver_command in bstack11l11l11ll_opy_[bstack1l111ll1_opy_]:
                self.bstack11l11l1l1_opy_.bstack11l11llll1_opy_(bstack1l1l11llll1_opy_, driver_command)
        except Exception as e:
            self.logger.error(bstack1ll1lll_opy_ (u"ࠣࡱࡱࡣࡵࡸࡥࡠࡧࡻࡩࡨࡻࡴࡦ࠼ࠣࡩࡷࡸ࡯ࡳࠤዴ"), e)
    def bstack1ll11111l11_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll11ll1l1_opy_,
        bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_],
        *args,
        **kwargs,
    ):
        from bstack_utils.bstack11llll1111_opy_ import bstack1llll11111l_opy_
        bstack1l1l1l1111l_opy_ = f.bstack1lllll1l1ll_opy_(instance, bstack1lll111llll_opy_.bstack1l1ll111111_opy_, [])
        if not bstack1l1l1l1111l_opy_:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠤࡲࡲࡤࡧࡦࡵࡧࡵࡣࡹ࡫ࡳࡵ࠼ࠣࡲࡴࠦࡤࡳ࡫ࡹࡩࡷࡹࠠࡧࡱࡵࠤ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵ࠽ࡼࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࢁࠥࡧࡲࡨࡵࡀࡿࡦࡸࡧࡴࡿࠣ࡯ࡼࡧࡲࡨࡵࡀࠦድ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠥࠦዶ"))
            return
        if len(bstack1l1l1l1111l_opy_) > 1:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠦࡴࡴ࡟ࡢࡨࡷࡩࡷࡥࡴࡦࡵࡷ࠾ࠥࢁ࡬ࡦࡰࠫࡨࡷ࡯ࡶࡦࡴࡢ࡭ࡳࡹࡴࡢࡰࡦࡩࡸ࠯ࡽࠡࡦࡵ࡭ࡻ࡫ࡲࡴࠢࡩࡳࡷࠦࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰ࠿ࡾ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࢃࠠࡢࡴࡪࡷࡂࢁࡡࡳࡩࡶࢁࠥࡱࡷࡢࡴࡪࡷࡂࠨዷ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠧࠨዸ"))
        bstack1l1l11l1ll1_opy_, bstack1l1l11ll1l1_opy_ = bstack1l1l1l1111l_opy_[0]
        driver = bstack1l1l11l1ll1_opy_()
        if not driver:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠨ࡯࡯ࡡࡤࡪࡹ࡫ࡲࡠࡶࡨࡷࡹࡀࠠ࡯ࡱࠣࡨࡷ࡯ࡶࡦࡴࠣࡪࡴࡸࠠࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࡀࡿ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵࡽࠡࡣࡵ࡫ࡸࡃࡻࡢࡴࡪࡷࢂࠦ࡫ࡸࡣࡵ࡫ࡸࡃࠢዹ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠢࠣዺ"))
            return
        bstack1l1l11lll11_opy_ = {
            TestFramework.bstack1ll1l111111_opy_: bstack1ll1lll_opy_ (u"ࠣࡶࡨࡷࡹࠦ࡮ࡢ࡯ࡨࠦዻ"),
            TestFramework.bstack1ll11ll111l_opy_: bstack1ll1lll_opy_ (u"ࠤࡷࡩࡸࡺࠠࡶࡷ࡬ࡨࠧዼ"),
            TestFramework.bstack1l1l11lll1l_opy_: bstack1ll1lll_opy_ (u"ࠥࡸࡪࡹࡴࠡࡴࡨࡶࡺࡴࠠ࡯ࡣࡰࡩࠧዽ")
        }
        bstack1l1l11ll111_opy_ = { key: f.bstack1lllll1l1ll_opy_(instance, key) for key in bstack1l1l11lll11_opy_ }
        bstack1l1l11ll1ll_opy_ = [key for key, value in bstack1l1l11ll111_opy_.items() if not value]
        if bstack1l1l11ll1ll_opy_:
            for key in bstack1l1l11ll1ll_opy_:
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠦࡴࡴ࡟ࡢࡨࡷࡩࡷࡥࡴࡦࡵࡷ࠾ࠥࡳࡩࡴࡵ࡬ࡲ࡬ࠦࠢዾ") + str(key) + bstack1ll1lll_opy_ (u"ࠧࠨዿ"))
            return
        platform_index = f.bstack1lllll1l1ll_opy_(instance, bstack1ll1l11ll1l_opy_.bstack1ll111l1ll1_opy_, 0)
        if self.bstack1l1l1l11111_opy_.percy_capture_mode == bstack1ll1lll_opy_ (u"ࠨࡴࡦࡵࡷࡧࡦࡹࡥࠣጀ"):
            bstack11l1l11l1l_opy_ = bstack1l1l11ll111_opy_.get(TestFramework.bstack1l1l11lll1l_opy_) + bstack1ll1lll_opy_ (u"ࠢ࠮ࡶࡨࡷࡹࡩࡡࡴࡧࠥጁ")
            bstack1ll111ll11l_opy_ = bstack1llll11111l_opy_.bstack1ll111l11l1_opy_(EVENTS.bstack1l1l11l1lll_opy_.value)
            PercySDK.screenshot(
                driver,
                bstack11l1l11l1l_opy_,
                bstack11l11ll111_opy_=bstack1l1l11ll111_opy_[TestFramework.bstack1ll1l111111_opy_],
                bstack111ll111l_opy_=bstack1l1l11ll111_opy_[TestFramework.bstack1ll11ll111l_opy_],
                bstack11l11l11l1_opy_=platform_index
            )
            bstack1llll11111l_opy_.end(EVENTS.bstack1l1l11l1lll_opy_.value, bstack1ll111ll11l_opy_+bstack1ll1lll_opy_ (u"ࠣ࠼ࡶࡸࡦࡸࡴࠣጂ"), bstack1ll111ll11l_opy_+bstack1ll1lll_opy_ (u"ࠤ࠽ࡩࡳࡪࠢጃ"), True, None, None, None, None, test_name=bstack11l1l11l1l_opy_)
    def bstack1lll111111_opy_(self, driver, platform_index):
        if self.bstack11l11l1l1_opy_.bstack1l111ll11_opy_() is True or self.bstack11l11l1l1_opy_.capturing() is True:
            return
        self.bstack11l11l1l1_opy_.bstack11l1l1lll1_opy_()
        while not self.bstack11l11l1l1_opy_.bstack1l111ll11_opy_():
            bstack1l1l11llll1_opy_ = self.bstack11l11l1l1_opy_.bstack11l1l1l11_opy_()
            self.bstack111l11ll_opy_(driver, bstack1l1l11llll1_opy_, platform_index)
        self.bstack11l11l1l1_opy_.bstack1l1lll11l_opy_()
    def bstack111l11ll_opy_(self, driver, bstack1111l1l1_opy_, platform_index, test=None):
        from bstack_utils.bstack11llll1111_opy_ import bstack1llll11111l_opy_
        bstack1ll111ll11l_opy_ = bstack1llll11111l_opy_.bstack1ll111l11l1_opy_(EVENTS.bstack11ll11111_opy_.value)
        if test != None:
            bstack11l11ll111_opy_ = getattr(test, bstack1ll1lll_opy_ (u"ࠪࡲࡦࡳࡥࠨጄ"), None)
            bstack111ll111l_opy_ = getattr(test, bstack1ll1lll_opy_ (u"ࠫࡺࡻࡩࡥࠩጅ"), None)
            PercySDK.screenshot(driver, bstack1111l1l1_opy_, bstack11l11ll111_opy_=bstack11l11ll111_opy_, bstack111ll111l_opy_=bstack111ll111l_opy_, bstack11l11l11l1_opy_=platform_index)
        else:
            PercySDK.screenshot(driver, bstack1111l1l1_opy_)
        bstack1llll11111l_opy_.end(EVENTS.bstack11ll11111_opy_.value, bstack1ll111ll11l_opy_+bstack1ll1lll_opy_ (u"ࠧࡀࡳࡵࡣࡵࡸࠧጆ"), bstack1ll111ll11l_opy_+bstack1ll1lll_opy_ (u"ࠨ࠺ࡦࡰࡧࠦጇ"), True, None, None, None, None, test_name=bstack1111l1l1_opy_)
    def bstack1l1l11ll11l_opy_(self):
        os.environ[bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡐࡆࡔࡆ࡝ࠬገ")] = str(self.bstack1l1l1l11111_opy_.success)
        os.environ[bstack1ll1lll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡑࡇࡕࡇ࡞ࡥࡃࡂࡒࡗ࡙ࡗࡋ࡟ࡎࡑࡇࡉࠬጉ")] = str(self.bstack1l1l1l11111_opy_.percy_capture_mode)
        self.percy.bstack1l1l11l1l11_opy_(self.bstack1l1l1l11111_opy_.is_percy_auto_enabled)
        self.percy.bstack1l1l11l1l1l_opy_(self.bstack1l1l1l11111_opy_.percy_build_id)