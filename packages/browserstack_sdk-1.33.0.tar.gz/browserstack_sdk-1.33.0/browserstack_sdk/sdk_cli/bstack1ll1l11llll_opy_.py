# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import json
import os
import grpc
from browserstack_sdk import sdk_pb2 as structs
from packaging import version
import traceback
from browserstack_sdk.sdk_cli.bstack1lll11111l1_opy_ import bstack1lll1ll11l1_opy_
from browserstack_sdk.sdk_cli.bstack1lllll1llll_opy_ import (
    bstack1llll1l11ll_opy_,
    bstack1lllll11ll1_opy_,
    bstack1lllll1lll1_opy_,
)
from browserstack_sdk.sdk_cli.bstack1lll11ll11l_opy_ import bstack1ll1l11ll1l_opy_
from datetime import datetime
from typing import Tuple, Any
from bstack_utils.messages import bstack1l1llll1l_opy_
from bstack_utils.measure import measure
from bstack_utils.constants import *
import threading
import os
from bstack_utils.bstack11llll1111_opy_ import bstack1llll11111l_opy_
class bstack1ll1llll11l_opy_(bstack1lll1ll11l1_opy_):
    bstack1l11l1l1ll1_opy_ = bstack1ll1lll_opy_ (u"ࠥࡶࡪ࡭ࡩࡴࡶࡨࡶࡤ࡯࡮ࡪࡶࠥᎂ")
    bstack1l11ll111l1_opy_ = bstack1ll1lll_opy_ (u"ࠦࡷ࡫ࡧࡪࡵࡷࡩࡷࡥࡳࡵࡣࡵࡸࠧᎃ")
    bstack1l11l1lllll_opy_ = bstack1ll1lll_opy_ (u"ࠧࡸࡥࡨ࡫ࡶࡸࡪࡸ࡟ࡴࡶࡲࡴࠧᎄ")
    def __init__(self, bstack1lll1l1ll11_opy_):
        super().__init__()
        bstack1ll1l11ll1l_opy_.bstack1ll11lllll1_opy_((bstack1llll1l11ll_opy_.bstack1llll1ll11l_opy_, bstack1lllll11ll1_opy_.PRE), self.bstack1l11ll1l1l1_opy_)
        bstack1ll1l11ll1l_opy_.bstack1ll11lllll1_opy_((bstack1llll1l11ll_opy_.bstack1llll1lll1l_opy_, bstack1lllll11ll1_opy_.PRE), self.bstack1l1lllll1ll_opy_)
        bstack1ll1l11ll1l_opy_.bstack1ll11lllll1_opy_((bstack1llll1l11ll_opy_.bstack1llll1lll1l_opy_, bstack1lllll11ll1_opy_.POST), self.bstack1l11l1lll11_opy_)
        bstack1ll1l11ll1l_opy_.bstack1ll11lllll1_opy_((bstack1llll1l11ll_opy_.bstack1llll1lll1l_opy_, bstack1lllll11ll1_opy_.POST), self.bstack1l11ll11111_opy_)
        bstack1ll1l11ll1l_opy_.bstack1ll11lllll1_opy_((bstack1llll1l11ll_opy_.QUIT, bstack1lllll11ll1_opy_.POST), self.bstack1l11l1lll1l_opy_)
    def is_enabled(self) -> bool:
        return True
    def bstack1l11ll1l1l1_opy_(
        self,
        f: bstack1ll1l11ll1l_opy_,
        driver: object,
        exec: Tuple[bstack1lllll1lll1_opy_, str],
        bstack1lllll11l11_opy_: Tuple[bstack1llll1l11ll_opy_, bstack1lllll11ll1_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance, method_name = exec
        if method_name != bstack1ll1lll_opy_ (u"ࠨ࡟ࡠ࡫ࡱ࡭ࡹࡥ࡟ࠣᎅ"):
            return
        def wrapped(driver, init, *args, **kwargs):
            url = None
            try:
                if isinstance(kwargs.get(bstack1ll1lll_opy_ (u"ࠢࡤࡱࡰࡱࡦࡴࡤࡠࡧࡻࡩࡨࡻࡴࡰࡴࠥᎆ")), str):
                    url = kwargs.get(bstack1ll1lll_opy_ (u"ࠣࡥࡲࡱࡲࡧ࡮ࡥࡡࡨࡼࡪࡩࡵࡵࡱࡵࠦᎇ"))
                elif hasattr(kwargs.get(bstack1ll1lll_opy_ (u"ࠤࡦࡳࡲࡳࡡ࡯ࡦࡢࡩࡽ࡫ࡣࡶࡶࡲࡶࠧᎈ")), bstack1ll1lll_opy_ (u"ࠪࡣࡨࡲࡩࡦࡰࡷࡣࡨࡵ࡮ࡧ࡫ࡪࠫᎉ")):
                    url = kwargs.get(bstack1ll1lll_opy_ (u"ࠦࡨࡵ࡭࡮ࡣࡱࡨࡤ࡫ࡸࡦࡥࡸࡸࡴࡸࠢᎊ"))._client_config.remote_server_addr
                else:
                    url = kwargs.get(bstack1ll1lll_opy_ (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࡥࡥࡹࡧࡦࡹࡹࡵࡲࠣᎋ"))._url
            except Exception as e:
                url = bstack1ll1lll_opy_ (u"࠭ࠧᎌ")
                self.logger.error(bstack1ll1lll_opy_ (u"ࠢࡆࡴࡵࡳࡷࠦࡷࡩ࡫࡯ࡩࠥ࡭ࡥࡵࡶ࡬ࡲ࡬ࠦࡵࡳ࡮ࠣࡪࡷࡵ࡭ࠡࡦࡵ࡭ࡻ࡫ࡲ࠻ࠢࡾࢁࠧᎍ").format(e))
            self.logger.info(bstack1ll1lll_opy_ (u"ࠣࡔࡨࡱࡴࡺࡥࠡࡕࡨࡶࡻ࡫ࡲࠡࡃࡧࡨࡷ࡫ࡳࡴࠢࡥࡩ࡮ࡴࡧࠡࡲࡤࡷࡸ࡫ࡤࠡࡣࡶࠤ࠿ࠦࡻࡾࠤᎎ").format(str(url)))
            self.bstack1l11ll11l1l_opy_(instance, url, f, kwargs)
            self.logger.info(bstack1ll1lll_opy_ (u"ࠤࡧࡶ࡮ࡼࡥࡳ࠰ࡾࡱࡪࡺࡨࡰࡦࡢࡲࡦࡳࡥࡾࠢࡳࡰࡦࡺࡦࡰࡴࡰࡣ࡮ࡴࡤࡦࡺࡀࡿࡵࡲࡡࡵࡨࡲࡶࡲࡥࡩ࡯ࡦࡨࡼࢂࡀࠠࡢࡴࡪࡷࡂࢁࡡࡳࡩࡶࢁࠥࡱࡷࡢࡴࡪࡷࡂࢁ࡫ࡸࡣࡵ࡫ࡸࢃࠢᎏ").format(method_name=method_name, platform_index=f.platform_index, args=args, kwargs=kwargs))
            threading.current_thread().bstackSessionDriver = driver
            return init(driver, *args, **kwargs)
        return wrapped
    def bstack1l1lllll1ll_opy_(
        self,
        f: bstack1ll1l11ll1l_opy_,
        driver: object,
        exec: Tuple[bstack1lllll1lll1_opy_, str],
        bstack1lllll11l11_opy_: Tuple[bstack1llll1l11ll_opy_, bstack1lllll11ll1_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance, method_name = exec
        if f.bstack1lllll1l1ll_opy_(instance, bstack1ll1llll11l_opy_.bstack1l11l1l1ll1_opy_, False):
            return
        if not f.bstack1llll1llll1_opy_(instance, bstack1ll1l11ll1l_opy_.bstack1ll111l1ll1_opy_):
            return
        platform_index = f.bstack1lllll1l1ll_opy_(instance, bstack1ll1l11ll1l_opy_.bstack1ll111l1ll1_opy_)
        if f.bstack1ll11ll11l1_opy_(method_name, *args) and len(args) > 1:
            bstack11l1lll11_opy_ = datetime.now()
            hub_url = bstack1ll1l11ll1l_opy_.hub_url(driver)
            self.logger.warning(bstack1ll1lll_opy_ (u"ࠥ࡬ࡺࡨ࡟ࡶࡴ࡯ࡁࠧ᎐") + str(hub_url) + bstack1ll1lll_opy_ (u"ࠦࠧ᎑"))
            bstack1l11l1l1lll_opy_ = args[1][bstack1ll1lll_opy_ (u"ࠧࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶࠦ᎒")] if isinstance(args[1], dict) and bstack1ll1lll_opy_ (u"ࠨࡣࡢࡲࡤࡦ࡮ࡲࡩࡵ࡫ࡨࡷࠧ᎓") in args[1] else None
            bstack1l11l1ll11l_opy_ = bstack1ll1lll_opy_ (u"ࠢࡢ࡮ࡺࡥࡾࡹࡍࡢࡶࡦ࡬ࠧ᎔")
            if isinstance(bstack1l11l1l1lll_opy_, dict):
                bstack11l1lll11_opy_ = datetime.now()
                r = self.bstack1l11ll1l11l_opy_(
                    instance.ref(),
                    platform_index,
                    f.framework_name,
                    f.framework_version,
                    hub_url
                )
                instance.bstack1ll1l111l_opy_(bstack1ll1lll_opy_ (u"ࠣࡩࡵࡴࡨࡀࡲࡦࡩ࡬ࡷࡹ࡫ࡲࡠ࡫ࡱ࡭ࡹࠨ᎕"), datetime.now() - bstack11l1lll11_opy_)
                try:
                    if not r.success:
                        self.logger.info(bstack1ll1lll_opy_ (u"ࠤࡶࡳࡲ࡫ࡴࡩ࡫ࡱ࡫ࠥࡽࡥ࡯ࡶࠣࡻࡷࡵ࡮ࡨ࠼ࠣࠦ᎖") + str(r) + bstack1ll1lll_opy_ (u"ࠥࠦ᎗"))
                        return
                    if r.hub_url:
                        f.bstack1l11l1l1l11_opy_(instance, driver, r.hub_url)
                        f.bstack1llll1l1l1l_opy_(instance, bstack1ll1llll11l_opy_.bstack1l11l1l1ll1_opy_, True)
                except Exception as e:
                    self.logger.error(bstack1ll1lll_opy_ (u"ࠦࡪࡸࡲࡰࡴࠥ᎘"), e)
    def bstack1l11l1lll11_opy_(
        self,
        f: bstack1ll1l11ll1l_opy_,
        driver: object,
        exec: Tuple[bstack1lllll1lll1_opy_, str],
        bstack1lllll11l11_opy_: Tuple[bstack1llll1l11ll_opy_, bstack1lllll11ll1_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
            session_id = bstack1ll1l11ll1l_opy_.session_id(driver)
            if session_id:
                bstack1l11l1l11ll_opy_ = bstack1ll1lll_opy_ (u"ࠧࢁࡽ࠻ࡵࡷࡥࡷࡺࠢ᎙").format(session_id)
                bstack1llll11111l_opy_.mark(bstack1l11l1l11ll_opy_)
    def bstack1l11ll11111_opy_(
        self,
        f: bstack1ll1l11ll1l_opy_,
        driver: object,
        exec: Tuple[bstack1lllll1lll1_opy_, str],
        bstack1lllll11l11_opy_: Tuple[bstack1llll1l11ll_opy_, bstack1lllll11ll1_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance = exec[0]
        if f.bstack1lllll1l1ll_opy_(instance, bstack1ll1llll11l_opy_.bstack1l11ll111l1_opy_, False):
            return
        ref = instance.ref()
        hub_url = bstack1ll1l11ll1l_opy_.hub_url(driver)
        if not hub_url:
            self.logger.warning(bstack1ll1lll_opy_ (u"ࠨࡦࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡳࡥࡷࡹࡥࠡࡪࡸࡦࡤࡻࡲ࡭࠿ࠥ᎚") + str(hub_url) + bstack1ll1lll_opy_ (u"ࠢࠣ᎛"))
            return
        framework_session_id = bstack1ll1l11ll1l_opy_.session_id(driver)
        if not framework_session_id:
            self.logger.warning(bstack1ll1lll_opy_ (u"ࠣࡨࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡵࡧࡲࡴࡧࠣࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡳࡦࡵࡶ࡭ࡴࡴ࡟ࡪࡦࡀࠦ᎜") + str(framework_session_id) + bstack1ll1lll_opy_ (u"ࠤࠥ᎝"))
            return
        if bstack1ll1l11ll1l_opy_.bstack1l11ll1l111_opy_(*args) == bstack1ll1l11ll1l_opy_.bstack1l11ll1ll1l_opy_:
            bstack1l11l1ll1l1_opy_ = bstack1ll1lll_opy_ (u"ࠥࡿࢂࡀࡥ࡯ࡦࠥ᎞").format(framework_session_id)
            bstack1l11l1l11ll_opy_ = bstack1ll1lll_opy_ (u"ࠦࢀࢃ࠺ࡴࡶࡤࡶࡹࠨ᎟").format(framework_session_id)
            bstack1llll11111l_opy_.end(
                label=bstack1ll1lll_opy_ (u"ࠧࡹࡤ࡬࠼ࡧࡶ࡮ࡼࡥࡳ࠼ࡳࡳࡸࡺ࠭ࡪࡰ࡬ࡸ࡮ࡧ࡬ࡪࡼࡤࡸ࡮ࡵ࡮ࠣᎠ"),
                start=bstack1l11l1l11ll_opy_,
                end=bstack1l11l1ll1l1_opy_,
                status=True,
                failure=None
            )
            bstack11l1lll11_opy_ = datetime.now()
            r = self.bstack1l11ll11lll_opy_(
                ref,
                f.bstack1lllll1l1ll_opy_(instance, bstack1ll1l11ll1l_opy_.bstack1ll111l1ll1_opy_, 0),
                f.framework_name,
                f.framework_version,
                framework_session_id,
                hub_url,
            )
            instance.bstack1ll1l111l_opy_(bstack1ll1lll_opy_ (u"ࠨࡧࡳࡲࡦ࠾ࡷ࡫ࡧࡪࡵࡷࡩࡷࡥࡳࡵࡣࡵࡸࠧᎡ"), datetime.now() - bstack11l1lll11_opy_)
            f.bstack1llll1l1l1l_opy_(instance, bstack1ll1llll11l_opy_.bstack1l11ll111l1_opy_, r.success)
    def bstack1l11l1lll1l_opy_(
        self,
        f: bstack1ll1l11ll1l_opy_,
        driver: object,
        exec: Tuple[bstack1lllll1lll1_opy_, str],
        bstack1lllll11l11_opy_: Tuple[bstack1llll1l11ll_opy_, bstack1lllll11ll1_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance = exec[0]
        if f.bstack1lllll1l1ll_opy_(instance, bstack1ll1llll11l_opy_.bstack1l11l1lllll_opy_, False):
            return
        ref = instance.ref()
        framework_session_id = bstack1ll1l11ll1l_opy_.session_id(driver)
        hub_url = bstack1ll1l11ll1l_opy_.hub_url(driver)
        bstack11l1lll11_opy_ = datetime.now()
        r = self.bstack1l11ll11l11_opy_(
            ref,
            f.bstack1lllll1l1ll_opy_(instance, bstack1ll1l11ll1l_opy_.bstack1ll111l1ll1_opy_, 0),
            f.framework_name,
            f.framework_version,
            framework_session_id,
            hub_url,
        )
        instance.bstack1ll1l111l_opy_(bstack1ll1lll_opy_ (u"ࠢࡨࡴࡳࡧ࠿ࡸࡥࡨ࡫ࡶࡸࡪࡸ࡟ࡴࡶࡲࡴࠧᎢ"), datetime.now() - bstack11l1lll11_opy_)
        f.bstack1llll1l1l1l_opy_(instance, bstack1ll1llll11l_opy_.bstack1l11l1lllll_opy_, r.success)
    @measure(event_name=EVENTS.bstack1ll111ll1l_opy_, stage=STAGE.bstack111lll1l11_opy_)
    def bstack1l1l111ll11_opy_(self, platform_index: int, url: str, ref, user_input_params: bytes):
        req = structs.DriverInitRequest()
        req.bin_session_id = self.bin_session_id
        req.platform_index = platform_index
        req.user_input_params = user_input_params
        req.ref = ref
        req.hub_url = url
        self.logger.debug(bstack1ll1lll_opy_ (u"ࠣࡴࡨ࡫࡮ࡹࡴࡦࡴࡢࡻࡪࡨࡤࡳ࡫ࡹࡩࡷࡥࡩ࡯࡫ࡷ࠾ࠥࠨᎣ") + str(req) + bstack1ll1lll_opy_ (u"ࠤࠥᎤ"))
        try:
            r = self.bstack1ll1ll1llll_opy_.DriverInit(req)
            if not r.success:
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠥࡶࡪࡩࡥࡪࡸࡨࡨࠥ࡬ࡲࡰ࡯ࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡸࡻࡣࡤࡧࡶࡷࡂࠨᎥ") + str(r.success) + bstack1ll1lll_opy_ (u"ࠦࠧᎦ"))
            return r
        except grpc.RpcError as e:
            self.logger.error(bstack1ll1lll_opy_ (u"ࠧࡸࡰࡤ࠯ࡨࡶࡷࡵࡲ࠻ࠢࠥᎧ") + str(e) + bstack1ll1lll_opy_ (u"ࠨࠢᎨ"))
            traceback.print_exc()
            raise e
    @measure(event_name=EVENTS.bstack1l11l1llll1_opy_, stage=STAGE.bstack111lll1l11_opy_)
    def bstack1l11ll1l11l_opy_(
        self,
        ref: str,
        platform_index: int,
        framework_name: str,
        framework_version: str,
        hub_url: str
    ):
        self.bstack1ll1111llll_opy_()
        req = structs.AutomationFrameworkInitRequest()
        req.ref = ref
        req.bin_session_id = self.bin_session_id
        req.platform_index = platform_index
        req.framework_name = framework_name
        req.framework_version = framework_version
        req.hub_url = hub_url
        self.logger.debug(bstack1ll1lll_opy_ (u"ࠢࡳࡧࡪ࡭ࡸࡺࡥࡳࡡ࡬ࡲ࡮ࡺ࠺ࠡࠤᎩ") + str(req) + bstack1ll1lll_opy_ (u"ࠣࠤᎪ"))
        try:
            r = self.bstack1ll1ll1llll_opy_.AutomationFrameworkInit(req)
            if not r.success:
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠤࡵࡩࡨ࡫ࡩࡷࡧࡧࠤ࡫ࡸ࡯࡮ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡷࡺࡩࡣࡦࡵࡶࡁࠧᎫ") + str(r.success) + bstack1ll1lll_opy_ (u"ࠥࠦᎬ"))
            return r
        except grpc.RpcError as e:
            self.logger.error(bstack1ll1lll_opy_ (u"ࠦࡷࡶࡣ࠮ࡧࡵࡶࡴࡸ࠺ࠡࠤᎭ") + str(e) + bstack1ll1lll_opy_ (u"ࠧࠨᎮ"))
            traceback.print_exc()
            raise e
    @measure(event_name=EVENTS.bstack1l11ll1l1ll_opy_, stage=STAGE.bstack111lll1l11_opy_)
    def bstack1l11ll11lll_opy_(
        self,
        ref: str,
        platform_index: int,
        framework_name: str,
        framework_version: str,
        framework_session_id: str,
        hub_url: str,
    ):
        self.bstack1ll1111llll_opy_()
        req = structs.AutomationFrameworkStartRequest()
        req.ref = ref
        req.bin_session_id = self.bin_session_id
        req.platform_index = platform_index
        req.framework_name = framework_name
        req.framework_version = framework_version
        req.framework_session_id = framework_session_id
        req.hub_url = hub_url
        self.logger.debug(bstack1ll1lll_opy_ (u"ࠨࡲࡦࡩ࡬ࡷࡹ࡫ࡲࡠࡵࡷࡥࡷࡺ࠺ࠡࠤᎯ") + str(req) + bstack1ll1lll_opy_ (u"ࠢࠣᎰ"))
        try:
            r = self.bstack1ll1ll1llll_opy_.AutomationFrameworkStart(req)
            if not r.success:
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠣࡴࡨࡧࡪ࡯ࡶࡦࡦࠣࡪࡷࡵ࡭ࠡࡵࡨࡶࡻ࡫ࡲ࠻ࠢࠥᎱ") + str(r) + bstack1ll1lll_opy_ (u"ࠤࠥᎲ"))
            return r
        except grpc.RpcError as e:
            self.logger.error(bstack1ll1lll_opy_ (u"ࠥࡶࡵࡩ࠭ࡦࡴࡵࡳࡷࡀࠠࠣᎳ") + str(e) + bstack1ll1lll_opy_ (u"ࠦࠧᎴ"))
            traceback.print_exc()
            raise e
    @measure(event_name=EVENTS.bstack1l11ll11ll1_opy_, stage=STAGE.bstack111lll1l11_opy_)
    def bstack1l11ll11l11_opy_(
        self,
        ref: str,
        platform_index: int,
        framework_name: str,
        framework_version: str,
        framework_session_id: str,
        hub_url: str,
    ):
        self.bstack1ll1111llll_opy_()
        req = structs.AutomationFrameworkStopRequest()
        req.ref = ref
        req.bin_session_id = self.bin_session_id
        req.platform_index = platform_index
        req.framework_name = framework_name
        req.framework_version = framework_version
        req.framework_session_id = framework_session_id
        req.hub_url = hub_url
        self.logger.debug(bstack1ll1lll_opy_ (u"ࠧࡸࡥࡨ࡫ࡶࡸࡪࡸ࡟ࡴࡶࡲࡴ࠿ࠦࠢᎵ") + str(req) + bstack1ll1lll_opy_ (u"ࠨࠢᎶ"))
        try:
            r = self.bstack1ll1ll1llll_opy_.AutomationFrameworkStop(req)
            if not r.success:
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠢࡳࡧࡦࡩ࡮ࡼࡥࡥࠢࡩࡶࡴࡳࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࠤᎷ") + str(r) + bstack1ll1lll_opy_ (u"ࠣࠤᎸ"))
            return r
        except grpc.RpcError as e:
            self.logger.error(bstack1ll1lll_opy_ (u"ࠤࡵࡴࡨ࠳ࡥࡳࡴࡲࡶ࠿ࠦࠢᎹ") + str(e) + bstack1ll1lll_opy_ (u"ࠥࠦᎺ"))
            traceback.print_exc()
            raise e
    @measure(event_name=EVENTS.bstack1l1ll11ll_opy_, stage=STAGE.bstack111lll1l11_opy_)
    def bstack1l11ll11l1l_opy_(self, instance: bstack1lllll1lll1_opy_, url: str, f: bstack1ll1l11ll1l_opy_, kwargs):
        bstack1l11ll1ll11_opy_ = version.parse(f.framework_version)
        bstack1l11ll111ll_opy_ = kwargs.get(bstack1ll1lll_opy_ (u"ࠦࡴࡶࡴࡪࡱࡱࡷࠧᎻ"))
        bstack1l11l1l1l1l_opy_ = kwargs.get(bstack1ll1lll_opy_ (u"ࠧࡪࡥࡴ࡫ࡵࡩࡩࡥࡣࡢࡲࡤࡦ࡮ࡲࡩࡵ࡫ࡨࡷࠧᎼ"))
        bstack1l1l11l1111_opy_ = {}
        bstack1l11l1ll111_opy_ = {}
        bstack1l11ll1111l_opy_ = None
        bstack1l11ll1lll1_opy_ = {}
        if bstack1l11l1l1l1l_opy_ is not None or bstack1l11ll111ll_opy_ is not None: # check top level caps
            if bstack1l11l1l1l1l_opy_ is not None:
                bstack1l11ll1lll1_opy_[bstack1ll1lll_opy_ (u"࠭ࡤࡦࡵ࡬ࡶࡪࡪ࡟ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸ࠭Ꮍ")] = bstack1l11l1l1l1l_opy_
            if bstack1l11ll111ll_opy_ is not None and callable(getattr(bstack1l11ll111ll_opy_, bstack1ll1lll_opy_ (u"ࠢࡵࡱࡢࡧࡦࡶࡡࡣ࡫࡯࡭ࡹ࡯ࡥࡴࠤᎾ"))):
                bstack1l11ll1lll1_opy_[bstack1ll1lll_opy_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮ࡴࡡࡤࡷࡤࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶࠫᎿ")] = bstack1l11ll111ll_opy_.to_capabilities()
        response = self.bstack1l1l111ll11_opy_(f.platform_index, url, instance.ref(), json.dumps(bstack1l11ll1lll1_opy_).encode(bstack1ll1lll_opy_ (u"ࠤࡸࡸ࡫࠳࠸ࠣᏀ")))
        if response is not None and response.capabilities:
            bstack1l1l11l1111_opy_ = json.loads(response.capabilities.decode(bstack1ll1lll_opy_ (u"ࠥࡹࡹ࡬࠭࠹ࠤᏁ")))
            if not bstack1l1l11l1111_opy_: # empty caps bstack1l1l111l1l1_opy_ bstack1l1l1111l11_opy_ bstack1l1l111111l_opy_ bstack1lll1l1111l_opy_ or error in processing
                return
            bstack1l11ll1111l_opy_ = f.bstack1ll1l1ll11l_opy_[bstack1ll1lll_opy_ (u"ࠦࡨࡸࡥࡢࡶࡨࡣࡴࡶࡴࡪࡱࡱࡷࡤ࡬ࡲࡰ࡯ࡢࡧࡦࡶࡳࠣᏂ")](bstack1l1l11l1111_opy_)
        if bstack1l11ll111ll_opy_ is not None and bstack1l11ll1ll11_opy_ >= version.parse(bstack1ll1lll_opy_ (u"ࠬ࠹࠮࠹࠰࠳ࠫᏃ")):
            bstack1l11l1ll111_opy_ = None
        if (
                not bstack1l11ll111ll_opy_ and not bstack1l11l1l1l1l_opy_
        ) or (
                bstack1l11ll1ll11_opy_ < version.parse(bstack1ll1lll_opy_ (u"࠭࠳࠯࠺࠱࠴ࠬᏄ"))
        ):
            bstack1l11l1ll111_opy_ = {}
            bstack1l11l1ll111_opy_.update(bstack1l1l11l1111_opy_)
        self.logger.info(bstack1l1llll1l_opy_)
        if os.environ.get(bstack1ll1lll_opy_ (u"ࠢࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡁࡖࡖࡒࡑࡆ࡚ࡉࡐࡐࠥᏅ")).lower().__eq__(bstack1ll1lll_opy_ (u"ࠣࡶࡵࡹࡪࠨᏆ")):
            kwargs.update(
                {
                    bstack1ll1lll_opy_ (u"ࠤࡦࡳࡲࡳࡡ࡯ࡦࡢࡩࡽ࡫ࡣࡶࡶࡲࡶࠧᏇ"): f.bstack1l11l1ll1ll_opy_,
                }
            )
        if bstack1l11ll1ll11_opy_ >= version.parse(bstack1ll1lll_opy_ (u"ࠪ࠸࠳࠷࠰࠯࠲ࠪᏈ")):
            if bstack1l11l1l1l1l_opy_ is not None:
                del kwargs[bstack1ll1lll_opy_ (u"ࠦࡩ࡫ࡳࡪࡴࡨࡨࡤࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶࠦᏉ")]
            kwargs.update(
                {
                    bstack1ll1lll_opy_ (u"ࠧࡵࡰࡵ࡫ࡲࡲࡸࠨᏊ"): bstack1l11ll1111l_opy_,
                    bstack1ll1lll_opy_ (u"ࠨ࡫ࡦࡧࡳࡣࡦࡲࡩࡷࡧࠥᏋ"): True,
                    bstack1ll1lll_opy_ (u"ࠢࡧ࡫࡯ࡩࡤࡪࡥࡵࡧࡦࡸࡴࡸࠢᏌ"): None,
                }
            )
        elif bstack1l11ll1ll11_opy_ >= version.parse(bstack1ll1lll_opy_ (u"ࠨ࠵࠱࠼࠳࠶ࠧᏍ")):
            kwargs.update(
                {
                    bstack1ll1lll_opy_ (u"ࠤࡧࡩࡸ࡯ࡲࡦࡦࡢࡧࡦࡶࡡࡣ࡫࡯࡭ࡹ࡯ࡥࡴࠤᏎ"): bstack1l11l1ll111_opy_,
                    bstack1ll1lll_opy_ (u"ࠥࡳࡵࡺࡩࡰࡰࡶࠦᏏ"): bstack1l11ll1111l_opy_,
                    bstack1ll1lll_opy_ (u"ࠦࡰ࡫ࡥࡱࡡࡤࡰ࡮ࡼࡥࠣᏐ"): True,
                    bstack1ll1lll_opy_ (u"ࠧ࡬ࡩ࡭ࡧࡢࡨࡪࡺࡥࡤࡶࡲࡶࠧᏑ"): None,
                }
            )
        elif bstack1l11ll1ll11_opy_ >= version.parse(bstack1ll1lll_opy_ (u"࠭࠲࠯࠷࠶࠲࠵࠭Ꮢ")):
            kwargs.update(
                {
                    bstack1ll1lll_opy_ (u"ࠢࡥࡧࡶ࡭ࡷ࡫ࡤࡠࡥࡤࡴࡦࡨࡩ࡭࡫ࡷ࡭ࡪࡹࠢᏓ"): bstack1l11l1ll111_opy_,
                    bstack1ll1lll_opy_ (u"ࠣ࡭ࡨࡩࡵࡥࡡ࡭࡫ࡹࡩࠧᏔ"): True,
                    bstack1ll1lll_opy_ (u"ࠤࡩ࡭ࡱ࡫࡟ࡥࡧࡷࡩࡨࡺ࡯ࡳࠤᏕ"): None,
                }
            )
        else:
            kwargs.update(
                {
                    bstack1ll1lll_opy_ (u"ࠥࡨࡪࡹࡩࡳࡧࡧࡣࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠥᏖ"): bstack1l11l1ll111_opy_,
                    bstack1ll1lll_opy_ (u"ࠦࡰ࡫ࡥࡱࡡࡤࡰ࡮ࡼࡥࠣᏗ"): True,
                    bstack1ll1lll_opy_ (u"ࠧ࡬ࡩ࡭ࡧࡢࡨࡪࡺࡥࡤࡶࡲࡶࠧᏘ"): None,
                }
            )