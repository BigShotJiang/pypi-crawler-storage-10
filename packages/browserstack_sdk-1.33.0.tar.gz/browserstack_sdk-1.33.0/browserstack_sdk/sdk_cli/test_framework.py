# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import logging
from enum import Enum
import os
import threading
import traceback
from typing import Dict, List, Any, Callable, Tuple, Union
import abc
from datetime import datetime, timezone
from dataclasses import dataclass
from browserstack_sdk.sdk_cli.bstack1lllllll1ll_opy_ import bstack1lllllllll1_opy_
from browserstack_sdk.sdk_cli.bstack1llll1l111l_opy_ import bstack1lllll1ll11_opy_, bstack1llll1l1l11_opy_
class bstack1lll1l1l1ll_opy_(Enum):
    PRE = 0
    POST = 1
    def __repr__(self) -> str:
        return bstack1ll1lll_opy_ (u"ࠤࡗࡩࡸࡺࡈࡰࡱ࡮ࡗࡹࡧࡴࡦ࠰ࡾࢁࠧᗍ").format(self.name)
class bstack1lll1111111_opy_(Enum):
    NONE = 0
    BEFORE_ALL = 1
    LOG = 2
    SETUP_FIXTURE = 3
    INIT_TEST = 4
    BEFORE_EACH = 5
    AFTER_EACH = 6
    TEST = 7
    STEP = 8
    LOG_REPORT = 9
    AFTER_ALL = 10
    def __eq__(self, other):
        if self.__class__ is other.__class__:
            return self.value == other.value
        return NotImplemented
    def __lt__(self, other):
        if self.__class__ is other.__class__:
            return self.value < other.value
        return NotImplemented
    def __repr__(self) -> str:
        return bstack1ll1lll_opy_ (u"ࠥࡘࡪࡹࡴࡇࡴࡤࡱࡪࡽ࡯ࡳ࡭ࡖࡸࡦࡺࡥ࠯ࡽࢀࠦᗎ").format(self.name)
class bstack1lll11ll1l1_opy_(bstack1lllll1ll11_opy_):
    bstack1ll11l11l11_opy_: List[str]
    bstack1l111111111_opy_: Dict[str, str]
    state: bstack1lll1111111_opy_
    bstack1llll1ll1ll_opy_: datetime
    bstack1llll1lllll_opy_: datetime
    def __init__(
        self,
        context: bstack1llll1l1l11_opy_,
        bstack1ll11l11l11_opy_: List[str],
        bstack1l111111111_opy_: Dict[str, str],
        state=bstack1lll1111111_opy_.NONE,
    ):
        super().__init__(context)
        self.bstack1ll11l11l11_opy_ = bstack1ll11l11l11_opy_
        self.bstack1l111111111_opy_ = bstack1l111111111_opy_
        self.state = state
        self.bstack1llll1ll1ll_opy_ = datetime.now(tz=timezone.utc)
        self.bstack1llll1lllll_opy_ = datetime.now(tz=timezone.utc)
    def bstack1llll1l1l1l_opy_(self, bstack1lllll1111l_opy_: bstack1lll1111111_opy_):
        bstack1llllll111l_opy_ = bstack1lll1111111_opy_(bstack1lllll1111l_opy_).name
        if not bstack1llllll111l_opy_:
            return False
        if bstack1lllll1111l_opy_ == self.state:
            return False
        self.state = bstack1lllll1111l_opy_
        self.bstack1llll1lllll_opy_ = datetime.now(tz=timezone.utc)
        return True
@dataclass
class bstack1l111l1ll11_opy_:
    test_framework_name: str
    test_framework_version: str
    platform_index: int
@dataclass
class bstack1lll1l1l1l1_opy_:
    kind: str
    message: str
    level: Union[None, str] = None
    timestamp: Union[None, datetime] = datetime.now(tz=timezone.utc)
    fileName: str = None
    bstack1l1l1llll1l_opy_: int = None
    bstack1l1l1l1l1ll_opy_: str = None
    bstack1l1ll11_opy_: str = None
    bstack11l111l1l1_opy_: str = None
    bstack1l1ll1ll1ll_opy_: str = None
    bstack11llll1ll1l_opy_: str = None
class TestFramework(abc.ABC):
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    bstack1ll11ll111l_opy_ = bstack1ll1lll_opy_ (u"ࠦࡹ࡫ࡳࡵࡡࡸࡹ࡮ࡪࠢᗏ")
    bstack1l11111111l_opy_ = bstack1ll1lll_opy_ (u"ࠧࡺࡥࡴࡶࡢ࡭ࡩࠨᗐ")
    bstack1ll1l111111_opy_ = bstack1ll1lll_opy_ (u"ࠨࡴࡦࡵࡷࡣࡳࡧ࡭ࡦࠤᗑ")
    bstack1l1111lll11_opy_ = bstack1ll1lll_opy_ (u"ࠢࡵࡧࡶࡸࡤ࡬ࡩ࡭ࡧࡢࡴࡦࡺࡨࠣᗒ")
    bstack1l1111111l1_opy_ = bstack1ll1lll_opy_ (u"ࠣࡶࡨࡷࡹࡥࡴࡢࡩࡶࠦᗓ")
    bstack1l11llll111_opy_ = bstack1ll1lll_opy_ (u"ࠤࡷࡩࡸࡺ࡟ࡳࡧࡶࡹࡱࡺࠢᗔ")
    bstack1l1lll111ll_opy_ = bstack1ll1lll_opy_ (u"ࠥࡸࡪࡹࡴࡠࡴࡨࡷࡺࡲࡴࡠࡣࡷࠦᗕ")
    bstack1l1ll1lll11_opy_ = bstack1ll1lll_opy_ (u"ࠦࡹ࡫ࡳࡵࡡࡶࡸࡦࡸࡴࡦࡦࡢࡥࡹࠨᗖ")
    bstack1l1l1ll111l_opy_ = bstack1ll1lll_opy_ (u"ࠧࡺࡥࡴࡶࡢࡩࡳࡪࡥࡥࡡࡤࡸࠧᗗ")
    bstack1l111l1llll_opy_ = bstack1ll1lll_opy_ (u"ࠨࡴࡦࡵࡷࡣࡱࡵࡣࡢࡶ࡬ࡳࡳࠨᗘ")
    bstack1ll11ll1l11_opy_ = bstack1ll1lll_opy_ (u"ࠢࡵࡧࡶࡸࡤ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡰࡤࡱࡪࠨᗙ")
    bstack1l1ll1ll11l_opy_ = bstack1ll1lll_opy_ (u"ࠣࡶࡨࡷࡹࡥࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࡡࡹࡩࡷࡹࡩࡰࡰࠥᗚ")
    bstack11lllll11ll_opy_ = bstack1ll1lll_opy_ (u"ࠤࡷࡩࡸࡺ࡟ࡤࡱࡧࡩࠧᗛ")
    bstack1l1l11lll1l_opy_ = bstack1ll1lll_opy_ (u"ࠥࡸࡪࡹࡴࡠࡴࡨࡶࡺࡴ࡟࡯ࡣࡰࡩࠧᗜ")
    bstack1ll111l1ll1_opy_ = bstack1ll1lll_opy_ (u"ࠦࡵࡲࡡࡵࡨࡲࡶࡲࡥࡩ࡯ࡦࡨࡼࠧᗝ")
    bstack1l11lll1ll1_opy_ = bstack1ll1lll_opy_ (u"ࠧࡺࡥࡴࡶࡢࡪࡦ࡯࡬ࡶࡴࡨࠦᗞ")
    bstack11lllll1111_opy_ = bstack1ll1lll_opy_ (u"ࠨࡴࡦࡵࡷࡣ࡫ࡧࡩ࡭ࡷࡵࡩࡤࡺࡹࡱࡧࠥᗟ")
    bstack1l111lll1l1_opy_ = bstack1ll1lll_opy_ (u"ࠢࡵࡧࡶࡸࡤࡲ࡯ࡨࡵࠥᗠ")
    bstack11lllllll11_opy_ = bstack1ll1lll_opy_ (u"ࠣࡶࡨࡷࡹࡥ࡭ࡦࡶࡤࠦᗡ")
    bstack11llll1l11l_opy_ = bstack1ll1lll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡴࡥࡲࡴࡪࡹࠧᗢ")
    bstack1l11l11lll1_opy_ = bstack1ll1lll_opy_ (u"ࠥࡥࡺࡺ࡯࡮ࡣࡷࡩࡤࡹࡥࡴࡵ࡬ࡳࡳࡥ࡮ࡢ࡯ࡨࠦᗣ")
    bstack11llll1lll1_opy_ = bstack1ll1lll_opy_ (u"ࠦࡪࡼࡥ࡯ࡶࡢࡷࡹࡧࡲࡵࡧࡧࡣࡦࡺࠢᗤ")
    bstack11lllll1l1l_opy_ = bstack1ll1lll_opy_ (u"ࠧ࡫ࡶࡦࡰࡷࡣࡪࡴࡤࡦࡦࡢࡥࡹࠨᗥ")
    bstack1l11111ll1l_opy_ = bstack1ll1lll_opy_ (u"ࠨࡨࡰࡱ࡮ࡣ࡮ࡪࠢᗦ")
    bstack1l11111l11l_opy_ = bstack1ll1lll_opy_ (u"ࠢࡩࡱࡲ࡯ࡤࡸࡥࡴࡷ࡯ࡸࠧᗧ")
    bstack1l111l1ll1l_opy_ = bstack1ll1lll_opy_ (u"ࠣࡪࡲࡳࡰࡥ࡬ࡰࡩࡶࠦᗨ")
    bstack1l11111ll11_opy_ = bstack1ll1lll_opy_ (u"ࠤ࡫ࡳࡴࡱ࡟࡯ࡣࡰࡩࠧᗩ")
    bstack1l111ll1ll1_opy_ = bstack1ll1lll_opy_ (u"ࠥࡰࡴ࡭ࡳࠣᗪ")
    bstack1l111l1l1l1_opy_ = bstack1ll1lll_opy_ (u"ࠦࡨࡻࡳࡵࡱࡰࡣࡲ࡫ࡴࡢࡦࡤࡸࡦࠨᗫ")
    bstack1l111111lll_opy_ = bstack1ll1lll_opy_ (u"ࠧࡶࡥ࡯ࡦ࡬ࡲ࡬ࠨᗬ")
    bstack11lllll111l_opy_ = bstack1ll1lll_opy_ (u"ࠨࡰࡦࡰࡧ࡭ࡳ࡭ࠢᗭ")
    bstack1l1ll11llll_opy_ = bstack1ll1lll_opy_ (u"ࠢࡕࡇࡖࡘࡤ࡙ࡃࡓࡇࡈࡒࡘࡎࡏࡕࠤᗮ")
    bstack1l1lll11lll_opy_ = bstack1ll1lll_opy_ (u"ࠣࡖࡈࡗ࡙ࡥࡌࡐࡉࠥᗯ")
    bstack1l1ll1lll1l_opy_ = bstack1ll1lll_opy_ (u"ࠤࡗࡉࡘ࡚࡟ࡂࡖࡗࡅࡈࡎࡍࡆࡐࡗࠦᗰ")
    bstack1llllll1lll_opy_: Dict[str, bstack1lll11ll1l1_opy_] = dict()
    bstack11llll1111l_opy_: Dict[str, List[Callable]] = dict()
    bstack1ll11l11l11_opy_: List[str]
    bstack1l111111111_opy_: Dict[str, str]
    def __init__(
        self,
        bstack1ll11l11l11_opy_: List[str],
        bstack1l111111111_opy_: Dict[str, str],
        bstack1lllllll1ll_opy_: bstack1lllllllll1_opy_
    ):
        self.bstack1ll11l11l11_opy_ = bstack1ll11l11l11_opy_
        self.bstack1l111111111_opy_ = bstack1l111111111_opy_
        self.bstack1lllllll1ll_opy_ = bstack1lllllll1ll_opy_
    def track_event(
        self,
        context: bstack1l111l1ll11_opy_,
        test_framework_state: bstack1lll1111111_opy_,
        test_hook_state: bstack1lll1l1l1ll_opy_,
        *args,
        **kwargs,
    ):
        self.logger.debug(bstack1ll1lll_opy_ (u"ࠥࡸࡷࡧࡣ࡬ࡡࡨࡺࡪࡴࡴ࠻ࠢࡷࡩࡸࡺ࡟ࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࡢࡷࡹࡧࡴࡦ࠿ࡾࢁࠥࡺࡥࡴࡶࡢ࡬ࡴࡵ࡫ࡠࡵࡷࡥࡹ࡫࠽ࡼࡿࠣࡥࡷ࡭ࡳ࠾ࡽࢀࠤࡰࡽࡡࡳࡩࡶࡁࢀࢃࠢᗱ").format(test_framework_state,test_hook_state,args,kwargs))
    def bstack1l111l11l11_opy_(
        self,
        instance: bstack1lll11ll1l1_opy_,
        bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_],
        *args,
        **kwargs,
    ):
        bstack1l111llll11_opy_ = TestFramework.bstack1l11l111l11_opy_(bstack1lllll11l11_opy_)
        if not bstack1l111llll11_opy_ in TestFramework.bstack11llll1111l_opy_:
            return
        self.logger.debug(bstack1ll1lll_opy_ (u"ࠦ࡮ࡴࡶࡰ࡭࡬ࡲ࡬ࠦࡻࡾࠢࡦࡥࡱࡲࡢࡢࡥ࡮ࡷࠧᗲ").format(len(TestFramework.bstack11llll1111l_opy_[bstack1l111llll11_opy_])))
        for callback in TestFramework.bstack11llll1111l_opy_[bstack1l111llll11_opy_]:
            try:
                callback(self, instance, bstack1lllll11l11_opy_, *args, **kwargs)
            except Exception as e:
                self.logger.error(bstack1ll1lll_opy_ (u"ࠧ࡫ࡲࡳࡱࡵࠤ࡮ࡴࡶࡰ࡭࡬ࡲ࡬ࠦࡣࡢ࡮࡯ࡦࡦࡩ࡫࠻ࠢࡾࢁࠧᗳ").format(e))
                traceback.print_exc()
    @abc.abstractmethod
    def bstack1l1l1lllll1_opy_(self):
        return
    @abc.abstractmethod
    def bstack1l1lll11l11_opy_(self, instance, bstack1lllll11l11_opy_):
        return
    @abc.abstractmethod
    def bstack1l1ll11l1ll_opy_(self, instance, bstack1lllll11l11_opy_):
        return
    @staticmethod
    def bstack1llll1l1ll1_opy_(target: object, strict=True):
        if target is None:
            return None
        ctx = bstack1lllll1ll11_opy_.create_context(target)
        instance = TestFramework.bstack1llllll1lll_opy_.get(ctx.id, None)
        if instance and instance.bstack1llll1l1lll_opy_(target):
            return instance
        return instance if instance and not strict else None
    @staticmethod
    def bstack1l1lll11l1l_opy_(reverse=True) -> List[bstack1lll11ll1l1_opy_]:
        thread_id = threading.get_ident()
        process_id = os.getpid()
        return sorted(
            filter(
                lambda t: t.context.thread_id == thread_id
                and t.context.process_id == process_id,
                TestFramework.bstack1llllll1lll_opy_.values(),
            ),
            key=lambda t: t.bstack1llll1ll1ll_opy_,
            reverse=reverse,
        )
    @staticmethod
    def bstack1llll1l1111_opy_(ctx: bstack1llll1l1l11_opy_, reverse=True) -> List[bstack1lll11ll1l1_opy_]:
        return sorted(
            filter(
                lambda t: t.context.thread_id == ctx.thread_id
                and t.context.process_id == ctx.process_id,
                TestFramework.bstack1llllll1lll_opy_.values(),
            ),
            key=lambda t: t.bstack1llll1ll1ll_opy_,
            reverse=reverse,
        )
    @staticmethod
    def bstack1llll1llll1_opy_(instance: bstack1lll11ll1l1_opy_, key: str):
        return instance and key in instance.data
    @staticmethod
    def bstack1lllll1l1ll_opy_(instance: bstack1lll11ll1l1_opy_, key: str, default_value=None):
        return instance.data.get(key, default_value) if instance else default_value
    @staticmethod
    def bstack1llll1l1l1l_opy_(instance: bstack1lll11ll1l1_opy_, key: str, value: Any):
        TestFramework.logger.debug(bstack1ll1lll_opy_ (u"ࠨࡳࡦࡶࡢࡷࡹࡧࡴࡦ࠼ࠣ࡭ࡳࡹࡴࡢࡰࡦࡩࡂࢁࡽࠡ࡭ࡨࡽࡂࢁࡽࠡࡸࡤࡰࡺ࡫࠽ࡼࡿࠥᗴ").format(instance.ref(),key,value))
        instance.data[key] = value
        return True
    @staticmethod
    def bstack1l111l111ll_opy_(instance: bstack1lll11ll1l1_opy_, entries: Dict[str, Any]):
        TestFramework.logger.debug(bstack1ll1lll_opy_ (u"ࠢࡴࡧࡷࡣࡸࡺࡡࡵࡧࡢࡩࡳࡺࡲࡪࡧࡶ࠾ࠥ࡯࡮ࡴࡶࡤࡲࡨ࡫࠽ࡼࡿࠣࡩࡳࡺࡲࡪࡧࡶࡁࢀࢃࠢᗵ").format(instance.ref(),entries,))
        instance.data.update(entries)
        return True
    @staticmethod
    def bstack11lll1ll11l_opy_(instance: bstack1lll1111111_opy_, key: str, value: Any):
        TestFramework.logger.debug(bstack1ll1lll_opy_ (u"ࠣࡷࡳࡨࡦࡺࡥࡠࡵࡷࡥࡹ࡫࠺ࠡ࡫ࡱࡷࡹࡧ࡮ࡤࡧࡀࡿࢂࠦ࡫ࡦࡻࡀࡿࢂࠦࡶࡢ࡮ࡸࡩࡂࢁࡽࠣᗶ").format(instance.ref(),key,value))
        instance.data.update(key, value)
        return True
    @staticmethod
    def get_data(key: str, target: object, strict=True, default_value=None):
        instance = TestFramework.bstack1llll1l1ll1_opy_(target, strict)
        return TestFramework.bstack1lllll1l1ll_opy_(instance, key, default_value)
    @staticmethod
    def set_data(key: str, value: Any, target: object, strict=True):
        instance = TestFramework.bstack1llll1l1ll1_opy_(target, strict)
        if not instance:
            return False
        instance.data[key] = value
        return True
    @staticmethod
    def bstack1l111ll1111_opy_(instance: bstack1lll11ll1l1_opy_, key: str, value: object):
        if instance == None:
            return
        instance.data[key] = value
    @staticmethod
    def bstack1l111ll11l1_opy_(instance: bstack1lll11ll1l1_opy_, key: str):
        return instance.data[key]
    @staticmethod
    def bstack1l11l111l11_opy_(bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_]):
        return bstack1ll1lll_opy_ (u"ࠤ࠽ࠦᗷ").join((bstack1lll1111111_opy_(bstack1lllll11l11_opy_[0]).name, bstack1lll1l1l1ll_opy_(bstack1lllll11l11_opy_[1]).name))
    @staticmethod
    def bstack1ll11lllll1_opy_(bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_], callback: Callable):
        bstack1l111llll11_opy_ = TestFramework.bstack1l11l111l11_opy_(bstack1lllll11l11_opy_)
        TestFramework.logger.debug(bstack1ll1lll_opy_ (u"ࠥࡷࡪࡺ࡟ࡩࡱࡲ࡯ࡤࡩࡡ࡭࡮ࡥࡥࡨࡱ࠺ࠡࡪࡲࡳࡰࡥࡲࡦࡩ࡬ࡷࡹࡸࡹࡠ࡭ࡨࡽࡂࢁࡽࠣᗸ").format(bstack1l111llll11_opy_))
        if not bstack1l111llll11_opy_ in TestFramework.bstack11llll1111l_opy_:
            TestFramework.bstack11llll1111l_opy_[bstack1l111llll11_opy_] = []
        TestFramework.bstack11llll1111l_opy_[bstack1l111llll11_opy_].append(callback)
    @staticmethod
    def bstack1l1l1ll1ll1_opy_(o):
        klass = o.__class__
        module = klass.__module__
        if module == bstack1ll1lll_opy_ (u"ࠦࡧࡻࡩ࡭ࡶ࡬ࡲࡸࠨᗹ"):
            return klass.__qualname__
        return module + bstack1ll1lll_opy_ (u"ࠧ࠴ࠢᗺ") + klass.__qualname__
    @staticmethod
    def bstack1l1l1l1lll1_opy_(obj, keys, default_value=None):
        return {k: getattr(obj, k, default_value) for k in keys}