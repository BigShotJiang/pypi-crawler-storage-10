# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import os
from datetime import datetime, timezone
from uuid import uuid4
from typing import Dict, List, Any, Tuple
from browserstack_sdk.sdk_cli.bstack1llll1l111l_opy_ import bstack1lllll1ll11_opy_
from browserstack_sdk.sdk_cli.utils.bstack11ll1ll1ll_opy_ import bstack1l1111l111l_opy_
from pathlib import Path
import grpc
from browserstack_sdk import sdk_pb2 as structs
from browserstack_sdk.sdk_cli.test_framework import (
    TestFramework,
    bstack1lll1111111_opy_,
    bstack1lll11ll1l1_opy_,
    bstack1lll1l1l1ll_opy_,
    bstack1l111l1ll11_opy_,
    bstack1lll1l1l1l1_opy_,
)
import traceback
from bstack_utils.helper import bstack1l1l1l1l1l1_opy_
from bstack_utils.bstack11llll1111_opy_ import bstack1llll11111l_opy_
from bstack_utils.constants import EVENTS
from browserstack_sdk.sdk_cli.utils.bstack1ll1l1ll1ll_opy_ import bstack1lll11l11ll_opy_
from browserstack_sdk.sdk_cli.bstack1lllllll1ll_opy_ import bstack1lllllllll1_opy_
bstack1l1ll1l11ll_opy_ = bstack1l1l1l1l1l1_opy_()
bstack1l1ll111ll1_opy_ = bstack1ll1lll_opy_ (u"࡙ࠥࡵࡲ࡯ࡢࡦࡨࡨࡆࡺࡴࡢࡥ࡫ࡱࡪࡴࡴࡴ࠯ࠥᑆ")
bstack11lllll1ll1_opy_ = bstack1ll1lll_opy_ (u"ࠦࡍࡵ࡯࡬ࡎࡨࡺࡪࡲࠢᑇ")
bstack1l111l11l1l_opy_ = bstack1ll1lll_opy_ (u"ࠧࡈࡵࡪ࡮ࡧࡐࡪࡼࡥ࡭ࡊࡲࡳࡰࡋࡶࡦࡰࡷࠦᑈ")
bstack1l1111ll111_opy_ = 1.0
_1l1l1llllll_opy_ = set()
class PytestBDDFramework(TestFramework):
    bstack1l111ll1l1l_opy_ = bstack1ll1lll_opy_ (u"ࠨࡴࡦࡵࡷࡣ࡫࡯ࡸࡵࡷࡵࡩࡸࠨᑉ")
    bstack1l1111l1l11_opy_ = bstack1ll1lll_opy_ (u"ࠢࡵࡧࡶࡸࡤ࡮࡯ࡰ࡭ࡶࡣࡸࡺࡡࡳࡶࡨࡨࠧᑊ")
    bstack1l11111lll1_opy_ = bstack1ll1lll_opy_ (u"ࠣࡶࡨࡷࡹࡥࡨࡰࡱ࡮ࡷࡤ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪࠢᑋ")
    bstack1l111l111l1_opy_ = bstack1ll1lll_opy_ (u"ࠤࡷࡩࡸࡺ࡟ࡩࡱࡲ࡯ࡤࡲࡡࡴࡶࡢࡷࡹࡧࡲࡵࡧࡧࠦᑌ")
    bstack1l111l1l111_opy_ = bstack1ll1lll_opy_ (u"ࠥࡸࡪࡹࡴࡠࡪࡲࡳࡰࡥ࡬ࡢࡵࡷࡣ࡫࡯࡮ࡪࡵ࡫ࡩࡩࠨᑍ")
    bstack1l1111llll1_opy_: bool
    bstack1lllllll1ll_opy_: bstack1lllllllll1_opy_  = None
    bstack1l111ll111l_opy_ = [
        bstack1lll1111111_opy_.BEFORE_ALL,
        bstack1lll1111111_opy_.AFTER_ALL,
        bstack1lll1111111_opy_.BEFORE_EACH,
        bstack1lll1111111_opy_.AFTER_EACH,
    ]
    def __init__(
        self,
        bstack1l111111111_opy_: Dict[str, str],
        bstack1ll11l11l11_opy_: List[str]=[bstack1ll1lll_opy_ (u"ࠦࡵࡿࡴࡦࡵࡷ࠱ࡧࡪࡤࠣᑎ")],
        bstack1lllllll1ll_opy_: bstack1lllllllll1_opy_ = None,
        bstack1ll1ll1llll_opy_=None
    ):
        super().__init__(bstack1ll11l11l11_opy_, bstack1l111111111_opy_, bstack1lllllll1ll_opy_)
        self.bstack1l1111llll1_opy_ = any(bstack1ll1lll_opy_ (u"ࠧࡶࡹࡵࡧࡶࡸ࠲ࡨࡤࡥࠤᑏ") in item.lower() for item in bstack1ll11l11l11_opy_)
        self.bstack1ll1ll1llll_opy_ = bstack1ll1ll1llll_opy_
    def track_event(
        self,
        context: bstack1l111l1ll11_opy_,
        test_framework_state: bstack1lll1111111_opy_,
        test_hook_state: bstack1lll1l1l1ll_opy_,
        *args,
        **kwargs,
    ):
        super().track_event(self, context, test_framework_state, test_hook_state, *args, **kwargs)
        if test_framework_state == bstack1lll1111111_opy_.TEST or test_framework_state in PytestBDDFramework.bstack1l111ll111l_opy_:
            bstack1l1111l111l_opy_(test_framework_state, test_hook_state)
        if test_framework_state == bstack1lll1111111_opy_.NONE:
            self.logger.warning(bstack1ll1lll_opy_ (u"ࠨࡩࡨࡰࡲࡶࡪࡪࠠࡤࡣ࡯ࡰࡧࡧࡣ࡬ࠢࡷࡩࡸࡺ࡟ࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࡢࡷࡹࡧࡴࡦ࠿ࡾࡸࡪࡹࡴࡠࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡸࡺࡡࡵࡧࢀࠤࡹ࡫ࡳࡵࡡ࡫ࡳࡴࡱ࡟ࡴࡶࡤࡸࡪࡃࠢᑐ") + str(test_hook_state) + bstack1ll1lll_opy_ (u"ࠢࠣᑑ"))
            return
        if not self.bstack1l1111llll1_opy_:
            self.logger.warning(bstack1ll1lll_opy_ (u"ࠣࡶࡵࡥࡨࡱ࡟ࡦࡸࡨࡲࡹࡀࠠࡶࡰࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࠥ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫࠾ࠤᑒ") + str(str(self.bstack1ll11l11l11_opy_)) + bstack1ll1lll_opy_ (u"ࠤࠥᑓ"))
            return
        if not isinstance(args, tuple) or len(args) == 0:
            self.logger.warning(bstack1ll1lll_opy_ (u"ࠥࡸࡷࡧࡣ࡬ࡡࡨࡺࡪࡴࡴ࠻ࠢࡸࡲࡪࡾࡰࡦࡥࡷࡩࡩࠦࡡࡳࡩࡶࡁࢀࡧࡲࡨࡵࢀࠤࡰࡽࡡࡳࡩࡶࡁࠧᑔ") + str(kwargs) + bstack1ll1lll_opy_ (u"ࠦࠧᑕ"))
            return
        instance = self.__1l1111ll1ll_opy_(context, test_framework_state, test_hook_state, *args, **kwargs)
        if not instance:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠧࡺࡲࡢࡥ࡮ࡣࡪࡼࡥ࡯ࡶ࠽ࠤࡺࡴࡨࡢࡰࡧࡰࡪࡪࠠࡦࡸࡨࡲࡹࡃࡻࡵࡧࡶࡸࡤ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡵࡷࡥࡹ࡫ࡽ࠯ࡽࡷࡩࡸࡺ࡟ࡩࡱࡲ࡯ࡤࡹࡴࡢࡶࡨࢁࠥࡧࡲࡨࡵࡀࠦᑖ") + str(args) + bstack1ll1lll_opy_ (u"ࠨࠢᑗ"))
            return
        try:
            if instance!= None and test_framework_state in PytestBDDFramework.bstack1l111ll111l_opy_ and test_hook_state == bstack1lll1l1l1ll_opy_.PRE:
                bstack1ll111ll11l_opy_ = bstack1llll11111l_opy_.bstack1ll111l11l1_opy_(EVENTS.bstack11ll1l11l1_opy_.value)
                name = str(EVENTS.bstack11ll1l11l1_opy_.name)+bstack1ll1lll_opy_ (u"ࠢ࠻ࠤᑘ")+str(test_framework_state.name)
                TestFramework.bstack1l111ll1111_opy_(instance, name, bstack1ll111ll11l_opy_)
        except Exception as e:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠣࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡩࡱࡲ࡯ࠥ࡫ࡲࡳࡱࡵࠤࡵࡸࡥ࠻ࠢࡾࢁࠧᑙ").format(e))
        try:
            if test_framework_state == bstack1lll1111111_opy_.TEST:
                if not TestFramework.bstack1llll1llll1_opy_(instance, TestFramework.bstack1l11111111l_opy_) and test_hook_state == bstack1lll1l1l1ll_opy_.PRE:
                    if not (len(args) >= 3):
                        return
                    test = PytestBDDFramework.__1l1111ll1l1_opy_(args)
                    if test:
                        instance.data.update(test)
                        self.logger.debug(bstack1ll1lll_opy_ (u"ࠤ࡯ࡳࡦࡪࡥࡥࠢ࡬ࡲࡸࡺࡡ࡯ࡥࡨࡁࢀ࡯࡮ࡴࡶࡤࡲࡨ࡫࠮ࡳࡧࡩࠬ࠮ࢃࠠࡦࡸࡨࡲࡹࡃࡻࡵࡧࡶࡸࡤ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡵࡷࡥࡹ࡫ࡽ࠯ࠤᑚ") + str(test_hook_state) + bstack1ll1lll_opy_ (u"ࠥࠦᑛ"))
                if test_hook_state == bstack1lll1l1l1ll_opy_.PRE and not TestFramework.bstack1llll1llll1_opy_(instance, TestFramework.bstack1l1ll1lll11_opy_):
                    TestFramework.bstack1llll1l1l1l_opy_(instance, TestFramework.bstack1l1ll1lll11_opy_, datetime.now(tz=timezone.utc))
                    PytestBDDFramework.__11llll1ll11_opy_(instance, args)
                    self.logger.debug(bstack1ll1lll_opy_ (u"ࠦࡸ࡫ࡴࠡࡶࡨࡷࡹ࠳ࡳࡵࡣࡵࡸࠥ࡬࡯ࡳࠢ࡬ࡲࡸࡺࡡ࡯ࡥࡨࡁࢀ࡯࡮ࡴࡶࡤࡲࡨ࡫࠮ࡳࡧࡩࠬ࠮ࢃࠠࡦࡸࡨࡲࡹࡃࡻࡵࡧࡶࡸࡤ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡵࡷࡥࡹ࡫ࡽ࠯ࠤᑜ") + str(test_hook_state) + bstack1ll1lll_opy_ (u"ࠧࠨᑝ"))
                elif test_hook_state == bstack1lll1l1l1ll_opy_.POST and not TestFramework.bstack1llll1llll1_opy_(instance, TestFramework.bstack1l1l1ll111l_opy_):
                    TestFramework.bstack1llll1l1l1l_opy_(instance, TestFramework.bstack1l1l1ll111l_opy_, datetime.now(tz=timezone.utc))
                    self.logger.debug(bstack1ll1lll_opy_ (u"ࠨࡳࡦࡶࠣࡸࡪࡹࡴ࠮ࡧࡱࡨࠥ࡬࡯ࡳࠢ࡬ࡲࡸࡺࡡ࡯ࡥࡨࡁࢀ࡯࡮ࡴࡶࡤࡲࡨ࡫࠮ࡳࡧࡩࠬ࠮ࢃࠠࡦࡸࡨࡲࡹࡃࡻࡵࡧࡶࡸࡤ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡵࡷࡥࡹ࡫ࡽ࠯ࠤᑞ") + str(test_hook_state) + bstack1ll1lll_opy_ (u"ࠢࠣᑟ"))
            elif test_framework_state == bstack1lll1111111_opy_.STEP:
                if test_hook_state == bstack1lll1l1l1ll_opy_.PRE:
                    PytestBDDFramework.__11lllllllll_opy_(instance, args)
                elif test_hook_state == bstack1lll1l1l1ll_opy_.POST:
                    PytestBDDFramework.__1l111ll1l11_opy_(instance, args)
            elif test_framework_state == bstack1lll1111111_opy_.LOG and test_hook_state == bstack1lll1l1l1ll_opy_.POST:
                PytestBDDFramework.__11lllll11l1_opy_(instance, *args)
            elif test_framework_state == bstack1lll1111111_opy_.LOG_REPORT and test_hook_state == bstack1lll1l1l1ll_opy_.POST:
                self.__1l111ll11ll_opy_(instance, *args)
                self.__1l111l11lll_opy_(instance)
            elif test_framework_state in PytestBDDFramework.bstack1l111ll111l_opy_:
                self.__1l111111l1l_opy_(instance, test_framework_state, test_hook_state, *args)
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠣࡶࡵࡥࡨࡱ࡟ࡦࡸࡨࡲࡹࡀࠠࡩࡣࡱࡨࡱ࡫ࡤࠡࡧࡹࡩࡳࡺ࠽ࡼࡶࡨࡷࡹࡥࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࡡࡶࡸࡦࡺࡥࡾ࠰ࡾࡸࡪࡹࡴࡠࡪࡲࡳࡰࡥࡳࡵࡣࡷࡩࢂࠦࡩ࡯ࡵࡷࡥࡳࡩࡥ࠾ࠤᑠ") + str(instance.ref()) + bstack1ll1lll_opy_ (u"ࠤࠥᑡ"))
        except Exception as e:
            self.logger.error(e)
            traceback.print_exc()
        self.bstack1l111l11l11_opy_(instance, (test_framework_state, test_hook_state), *args, **kwargs)
        try:
            if instance!= None and test_framework_state in PytestBDDFramework.bstack1l111ll111l_opy_ and test_hook_state == bstack1lll1l1l1ll_opy_.POST:
                name = str(EVENTS.bstack11ll1l11l1_opy_.name)+bstack1ll1lll_opy_ (u"ࠥ࠾ࠧᑢ")+str(test_framework_state.name)
                bstack1ll111ll11l_opy_ = TestFramework.bstack1l111ll11l1_opy_(instance, name)
                bstack1llll11111l_opy_.end(EVENTS.bstack11ll1l11l1_opy_.value, bstack1ll111ll11l_opy_+bstack1ll1lll_opy_ (u"ࠦ࠿ࡹࡴࡢࡴࡷࠦᑣ"), bstack1ll111ll11l_opy_+bstack1ll1lll_opy_ (u"ࠧࡀࡥ࡯ࡦࠥᑤ"), True, None, test_framework_state.name)
        except Exception as e:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥ࡮࡯ࡰ࡭ࠣࡩࡷࡸ࡯ࡳ࠼ࠣࡿࢂࠨᑥ").format(e))
    def bstack1l1l1lllll1_opy_(self):
        return self.bstack1l1111llll1_opy_
    def __11lllll1lll_opy_(self, *args):
        if len(args) > 2 and callable(getattr(args[2], bstack1ll1lll_opy_ (u"ࠢࡨࡧࡷࡣࡷ࡫ࡳࡶ࡮ࡷࠦᑦ"), None)):
            rep = args[2].get_result()
            if rep:
                return TestFramework.bstack1l1l1l1lll1_opy_(rep, [bstack1ll1lll_opy_ (u"ࠣࡹ࡫ࡩࡳࠨᑧ"), bstack1ll1lll_opy_ (u"ࠤࡲࡹࡹࡩ࡯࡮ࡧࠥᑨ"), bstack1ll1lll_opy_ (u"ࠥࡴࡦࡹࡳࡦࡦࠥᑩ"), bstack1ll1lll_opy_ (u"ࠦ࡫ࡧࡩ࡭ࡧࡧࠦᑪ"), bstack1ll1lll_opy_ (u"ࠧࡹ࡫ࡪࡲࡳࡩࡩࠨᑫ"), bstack1ll1lll_opy_ (u"ࠨ࡬ࡰࡰࡪࡶࡪࡶࡲࡵࡧࡻࡸࠧᑬ")])
        return None
    def __1l111ll11ll_opy_(self, instance: bstack1lll11ll1l1_opy_, *args):
        result = self.__11lllll1lll_opy_(*args)
        if not result:
            return
        failure = None
        bstack1111111l11_opy_ = None
        if result.get(bstack1ll1lll_opy_ (u"ࠢࡰࡷࡷࡧࡴࡳࡥࠣᑭ"), None) == bstack1ll1lll_opy_ (u"ࠣࡨࡤ࡭ࡱ࡫ࡤࠣᑮ") and len(args) > 1 and getattr(args[1], bstack1ll1lll_opy_ (u"ࠤࡨࡼࡨ࡯࡮ࡧࡱࠥᑯ"), None) is not None:
            failure = [{bstack1ll1lll_opy_ (u"ࠪࡦࡦࡩ࡫ࡵࡴࡤࡧࡪ࠭ᑰ"): [args[1].excinfo.exconly(), result.get(bstack1ll1lll_opy_ (u"ࠦࡱࡵ࡮ࡨࡴࡨࡴࡷࡺࡥࡹࡶࠥᑱ"), None)]}]
            bstack1111111l11_opy_ = bstack1ll1lll_opy_ (u"ࠧࡇࡳࡴࡧࡵࡸ࡮ࡵ࡮ࡆࡴࡵࡳࡷࠨᑲ") if bstack1ll1lll_opy_ (u"ࠨࡁࡴࡵࡨࡶࡹ࡯࡯࡯ࠤᑳ") in getattr(args[1].excinfo, bstack1ll1lll_opy_ (u"ࠢࡵࡻࡳࡩࡳࡧ࡭ࡦࠤᑴ"), bstack1ll1lll_opy_ (u"ࠣࠤᑵ")) else bstack1ll1lll_opy_ (u"ࠤࡘࡲ࡭ࡧ࡮ࡥ࡮ࡨࡨࡊࡸࡲࡰࡴࠥᑶ")
        bstack1l111l1111l_opy_ = result.get(bstack1ll1lll_opy_ (u"ࠥࡳࡺࡺࡣࡰ࡯ࡨࠦᑷ"), TestFramework.bstack1l111111lll_opy_)
        if bstack1l111l1111l_opy_ != TestFramework.bstack1l111111lll_opy_:
            TestFramework.bstack1llll1l1l1l_opy_(instance, TestFramework.bstack1l1lll111ll_opy_, datetime.now(tz=timezone.utc))
        TestFramework.bstack1l111l111ll_opy_(instance, {
            TestFramework.bstack1l11lll1ll1_opy_: failure,
            TestFramework.bstack11lllll1111_opy_: bstack1111111l11_opy_,
            TestFramework.bstack1l11llll111_opy_: bstack1l111l1111l_opy_,
        })
    def __1l1111ll1ll_opy_(
        self,
        context: bstack1l111l1ll11_opy_,
        test_framework_state: bstack1lll1111111_opy_,
        test_hook_state: bstack1lll1l1l1ll_opy_,
        *args,
        **kwargs,
    ):
        instance = None
        if test_framework_state == bstack1lll1111111_opy_.SETUP_FIXTURE:
            instance = self.__11llllll111_opy_(context, test_framework_state, test_hook_state, *args, **kwargs)
        else:
            target = None # bstack1l1111l11l1_opy_ bstack1l1111l1ll1_opy_ this to be bstack1ll1lll_opy_ (u"ࠦࡳࡵࡤࡦ࡫ࡧࠦᑸ")
            if test_framework_state == bstack1lll1111111_opy_.INIT_TEST:
                target = args[0] if isinstance(args[0], str) else None
                if target:
                    self.__11lllll1l11_opy_(context, test_framework_state, target, *args)
            elif test_framework_state == bstack1lll1111111_opy_.LOG:
                nodeid = getattr(getattr(args[0], bstack1ll1lll_opy_ (u"ࠧࡴ࡯ࡥࡧࠥᑹ"), None), bstack1ll1lll_opy_ (u"ࠨ࡮ࡰࡦࡨ࡭ࡩࠨᑺ"), None) if args else None
                if isinstance(nodeid, str):
                    target = nodeid
            elif getattr(args[0], bstack1ll1lll_opy_ (u"ࠢ࡯ࡱࡧࡩࠧᑻ"), None):
                target = args[0].node.nodeid
            elif getattr(args[0], bstack1ll1lll_opy_ (u"ࠣࡰࡲࡨࡪ࡯ࡤࠣᑼ"), None):
                target = args[0].nodeid
            instance = TestFramework.bstack1llll1l1ll1_opy_(target) if target else None
        return instance
    def __1l111111l1l_opy_(
        self,
        instance: bstack1lll11ll1l1_opy_,
        test_framework_state: bstack1lll1111111_opy_,
        test_hook_state: bstack1lll1l1l1ll_opy_,
        *args,
    ):
        key = test_framework_state.name
        bstack1l111lll11l_opy_ = TestFramework.bstack1lllll1l1ll_opy_(instance, PytestBDDFramework.bstack1l1111l1l11_opy_, {})
        if not key in bstack1l111lll11l_opy_:
            bstack1l111lll11l_opy_[key] = []
        bstack1l11111l111_opy_ = TestFramework.bstack1lllll1l1ll_opy_(instance, PytestBDDFramework.bstack1l11111lll1_opy_, {})
        if not key in bstack1l11111l111_opy_:
            bstack1l11111l111_opy_[key] = []
        bstack11llllllll1_opy_ = {
            PytestBDDFramework.bstack1l1111l1l11_opy_: bstack1l111lll11l_opy_,
            PytestBDDFramework.bstack1l11111lll1_opy_: bstack1l11111l111_opy_,
        }
        if test_hook_state == bstack1lll1l1l1ll_opy_.PRE:
            hook_name = args[1] if len(args) > 1 else None
            hook = {
                bstack1ll1lll_opy_ (u"ࠤ࡮ࡩࡾࠨᑽ"): key,
                TestFramework.bstack1l11111ll1l_opy_: uuid4().__str__(),
                TestFramework.bstack1l11111l11l_opy_: TestFramework.bstack11lllll111l_opy_,
                TestFramework.bstack11llll1lll1_opy_: datetime.now(tz=timezone.utc),
                TestFramework.bstack1l111l1ll1l_opy_: [],
                TestFramework.bstack1l11111ll11_opy_: hook_name,
                TestFramework.bstack1l111l1l1l1_opy_: bstack1lll11l11ll_opy_.bstack1l1111lll1l_opy_()
            }
            bstack1l111lll11l_opy_[key].append(hook)
            bstack11llllllll1_opy_[PytestBDDFramework.bstack1l111l111l1_opy_] = key
        elif test_hook_state == bstack1lll1l1l1ll_opy_.POST:
            bstack1l111lll111_opy_ = bstack1l111lll11l_opy_.get(key, [])
            hook = bstack1l111lll111_opy_.pop() if bstack1l111lll111_opy_ else None
            if hook:
                result = self.__11lllll1lll_opy_(*args)
                if result:
                    bstack11lllllll1l_opy_ = result.get(bstack1ll1lll_opy_ (u"ࠥࡳࡺࡺࡣࡰ࡯ࡨࠦᑾ"), TestFramework.bstack11lllll111l_opy_)
                    if bstack11lllllll1l_opy_ != TestFramework.bstack11lllll111l_opy_:
                        hook[TestFramework.bstack1l11111l11l_opy_] = bstack11lllllll1l_opy_
                hook[TestFramework.bstack11lllll1l1l_opy_] = datetime.now(tz=timezone.utc)
                hook[TestFramework.bstack1l111l1l1l1_opy_] = bstack1lll11l11ll_opy_.bstack1l1111lll1l_opy_()
                self.bstack1l111111l11_opy_(hook)
                logs = hook.get(TestFramework.bstack1l111ll1ll1_opy_, [])
                self.bstack1l1l1lll1ll_opy_(instance, logs)
                bstack1l11111l111_opy_[key].append(hook)
                bstack11llllllll1_opy_[PytestBDDFramework.bstack1l111l1l111_opy_] = key
        TestFramework.bstack1l111l111ll_opy_(instance, bstack11llllllll1_opy_)
        self.logger.debug(bstack1ll1lll_opy_ (u"ࠦࡹࡸࡡࡤ࡭ࡢ࡬ࡴࡵ࡫ࡠࡧࡹࡩࡳࡺ࠺ࠡࡶࡨࡷࡹࡥࡨࡰࡱ࡮ࡣࡸࡺࡡࡵࡧࡀࡿࡰ࡫ࡹࡾ࠰ࡾࡸࡪࡹࡴࡠࡪࡲࡳࡰࡥࡳࡵࡣࡷࡩࢂࠦࡨࡰࡱ࡮ࡷࡤࡹࡴࡢࡴࡷࡩࡩࡃࡻࡩࡱࡲ࡯ࡸࡥࡳࡵࡣࡵࡸࡪࡪࡽࠡࡪࡲࡳࡰࡹ࡟ࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥ࠿ࠥᑿ") + str(bstack1l11111l111_opy_) + bstack1ll1lll_opy_ (u"ࠧࠨᒀ"))
    def __11llllll111_opy_(
        self,
        context: bstack1l111l1ll11_opy_,
        test_framework_state: bstack1lll1111111_opy_,
        test_hook_state: bstack1lll1l1l1ll_opy_,
        *args,
        **kwargs,
    ):
        fixturedef = TestFramework.bstack1l1l1l1lll1_opy_(args[0], [bstack1ll1lll_opy_ (u"ࠨࡳࡤࡱࡳࡩࠧᒁ"), bstack1ll1lll_opy_ (u"ࠢࡢࡴࡪࡲࡦࡳࡥࠣᒂ"), bstack1ll1lll_opy_ (u"ࠣࡲࡤࡶࡦࡳࡳࠣᒃ"), bstack1ll1lll_opy_ (u"ࠤ࡬ࡨࡸࠨᒄ"), bstack1ll1lll_opy_ (u"ࠥࡹࡳ࡯ࡴࡵࡧࡶࡸࠧᒅ"), bstack1ll1lll_opy_ (u"ࠦࡧࡧࡳࡦ࡫ࡧࠦᒆ")]) if len(args) > 0 else {}
        request = args[1] if len(args) > 1 else None
        scenario = args[2] if len(args) == 3 else None
        scope = request.scope if hasattr(request, bstack1ll1lll_opy_ (u"ࠧࡹࡣࡰࡲࡨࠦᒇ")) else fixturedef.get(bstack1ll1lll_opy_ (u"ࠨࡳࡤࡱࡳࡩࠧᒈ"), None)
        fixturename = request.fixturename if hasattr(request, bstack1ll1lll_opy_ (u"ࠢࡧ࡫ࡻࡸࡺࡸࡥ࡯ࡣࡰࡩࠧᒉ")) else None
        node = request.node if hasattr(request, bstack1ll1lll_opy_ (u"ࠣࡰࡲࡨࡪࠨᒊ")) else None
        target = request.node.nodeid if hasattr(node, bstack1ll1lll_opy_ (u"ࠤࡱࡳࡩ࡫ࡩࡥࠤᒋ")) else None
        baseid = fixturedef.get(bstack1ll1lll_opy_ (u"ࠥࡦࡦࡹࡥࡪࡦࠥᒌ"), None) or bstack1ll1lll_opy_ (u"ࠦࠧᒍ")
        if (not target or len(baseid) > 0) and hasattr(request, bstack1ll1lll_opy_ (u"ࠧࡥࡰࡺࡨࡸࡲࡨ࡯ࡴࡦ࡯ࠥᒎ")):
            target = PytestBDDFramework.__1l1111l11ll_opy_(request._pyfuncitem.location) if hasattr(request._pyfuncitem, bstack1ll1lll_opy_ (u"ࠨ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠣᒏ")) else None
            if target and not TestFramework.bstack1llll1l1ll1_opy_(target):
                self.__11lllll1l11_opy_(context, test_framework_state, target, (target, request._pyfuncitem.location))
                node = request._pyfuncitem
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠢࡵࡴࡤࡧࡰࡥࡦࡪࡺࡷࡹࡷ࡫࡟ࡦࡸࡨࡲࡹࡀࠠࡧࡣ࡯ࡰࡧࡧࡣ࡬ࠢࡷࡥࡷ࡭ࡥࡵ࠿ࡾࡸࡦࡸࡧࡦࡶࢀࠤ࡫࡯ࡸࡵࡷࡵࡩࡳࡧ࡭ࡦ࠿ࡾࡪ࡮ࡾࡴࡶࡴࡨࡲࡦࡳࡥࡾࠢࡱࡳࡩ࡫࠽ࡼࡰࡲࡨࡪࢃࠠࡦࡸࡨࡲࡹࡃࡻࡵࡧࡶࡸࡤ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡵࡷࡥࡹ࡫ࡽ࠯ࠤᒐ") + str(test_hook_state) + bstack1ll1lll_opy_ (u"ࠣࠤᒑ"))
        if not fixturedef or not scope or not target:
            self.logger.warning(bstack1ll1lll_opy_ (u"ࠤࡷࡶࡦࡩ࡫ࡠࡨ࡬ࡼࡹࡻࡲࡦࡡࡨࡺࡪࡴࡴ࠻ࠢࡸࡲ࡭ࡧ࡮ࡥ࡮ࡨࡨࠥ࡫ࡶࡦࡰࡷࡁࢀࡺࡥࡴࡶࡢࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡳࡵࡣࡷࡩࢂ࠴ࡻࡵࡧࡶࡸࡤ࡮࡯ࡰ࡭ࡢࡷࡹࡧࡴࡦࡿࠣࡪ࡮ࡾࡴࡶࡴࡨࡨࡪ࡬࠽ࡼࡨ࡬ࡼࡹࡻࡲࡦࡦࡨࡪࢂࠦࡳࡤࡱࡳࡩࡂࢁࡳࡤࡱࡳࡩࢂࠦࡴࡢࡴࡪࡩࡹࡃࠢᒒ") + str(target) + bstack1ll1lll_opy_ (u"ࠥࠦᒓ"))
            return None
        instance = TestFramework.bstack1llll1l1ll1_opy_(target)
        if not instance:
            self.logger.warning(bstack1ll1lll_opy_ (u"ࠦࡹࡸࡡࡤ࡭ࡢࡪ࡮ࡾࡴࡶࡴࡨࡣࡪࡼࡥ࡯ࡶ࠽ࠤࡺࡴࡨࡢࡰࡧࡰࡪࡪࠠࡦࡸࡨࡲࡹࡃࡻࡵࡧࡶࡸࡤ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡵࡷࡥࡹ࡫ࡽ࠯ࡽࡷࡩࡸࡺ࡟ࡩࡱࡲ࡯ࡤࡹࡴࡢࡶࡨࢁࠥ࡬ࡩࡹࡶࡸࡶࡪࡴࡡ࡮ࡧࡀࡿ࡫࡯ࡸࡵࡷࡵࡩࡳࡧ࡭ࡦࡿࠣࡷࡨࡵࡰࡦ࠿ࡾࡷࡨࡵࡰࡦࡿࠣࡦࡦࡹࡥࡪࡦࡀࡿࡧࡧࡳࡦ࡫ࡧࢁࠥࡺࡡࡳࡩࡨࡸࡂࠨᒔ") + str(target) + bstack1ll1lll_opy_ (u"ࠧࠨᒕ"))
            return None
        bstack1l1111111ll_opy_ = TestFramework.bstack1lllll1l1ll_opy_(instance, PytestBDDFramework.bstack1l111ll1l1l_opy_, {})
        if os.getenv(bstack1ll1lll_opy_ (u"ࠨࡓࡅࡍࡢࡇࡑࡏ࡟ࡇࡎࡄࡋࡤࡌࡉ࡙ࡖࡘࡖࡊ࡙ࠢᒖ"), bstack1ll1lll_opy_ (u"ࠢ࠲ࠤᒗ")) == bstack1ll1lll_opy_ (u"ࠣ࠳ࠥᒘ"):
            bstack1l111ll1lll_opy_ = bstack1ll1lll_opy_ (u"ࠤ࠽ࠦᒙ").join((scope, fixturename))
            bstack1l111l1l1ll_opy_ = datetime.now(tz=timezone.utc)
            bstack11llllll11l_opy_ = {
                bstack1ll1lll_opy_ (u"ࠥ࡯ࡪࡿࠢᒚ"): bstack1l111ll1lll_opy_,
                bstack1ll1lll_opy_ (u"ࠦࡹࡧࡧࡴࠤᒛ"): PytestBDDFramework.__11llllll1ll_opy_(request.node, scenario),
                bstack1ll1lll_opy_ (u"ࠧ࡬ࡩࡹࡶࡸࡶࡪࠨᒜ"): fixturedef,
                bstack1ll1lll_opy_ (u"ࠨࡳࡤࡱࡳࡩࠧᒝ"): scope,
                bstack1ll1lll_opy_ (u"ࠢࡵࡻࡳࡩࠧᒞ"): None,
            }
            try:
                if test_hook_state == bstack1lll1l1l1ll_opy_.POST and callable(getattr(args[-1], bstack1ll1lll_opy_ (u"ࠣࡩࡨࡸࡤࡸࡥࡴࡷ࡯ࡸࠧᒟ"), None)):
                    bstack11llllll11l_opy_[bstack1ll1lll_opy_ (u"ࠤࡷࡽࡵ࡫ࠢᒠ")] = TestFramework.bstack1l1l1ll1ll1_opy_(args[-1].get_result())
            except Exception as e:
                pass
            if test_hook_state == bstack1lll1l1l1ll_opy_.PRE:
                bstack11llllll11l_opy_[bstack1ll1lll_opy_ (u"ࠥࡹࡺ࡯ࡤࠣᒡ")] = uuid4().__str__()
                bstack11llllll11l_opy_[PytestBDDFramework.bstack11llll1lll1_opy_] = bstack1l111l1l1ll_opy_
            elif test_hook_state == bstack1lll1l1l1ll_opy_.POST:
                bstack11llllll11l_opy_[PytestBDDFramework.bstack11lllll1l1l_opy_] = bstack1l111l1l1ll_opy_
            if bstack1l111ll1lll_opy_ in bstack1l1111111ll_opy_:
                bstack1l1111111ll_opy_[bstack1l111ll1lll_opy_].update(bstack11llllll11l_opy_)
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠦࡺࡶࡤࡢࡶࡨࡨࠥ࡬ࡩࡹࡶࡸࡶࡪࡴࡡ࡮ࡧࡀࡿ࡫࡯ࡸࡵࡷࡵࡩࡳࡧ࡭ࡦࡿࠣࡷࡨࡵࡰࡦ࠿ࡾࡷࡨࡵࡰࡦࡿࠣࡪ࡮ࡾࡴࡶࡴࡨࡁࠧᒢ") + str(bstack1l1111111ll_opy_[bstack1l111ll1lll_opy_]) + bstack1ll1lll_opy_ (u"ࠧࠨᒣ"))
            else:
                bstack1l1111111ll_opy_[bstack1l111ll1lll_opy_] = bstack11llllll11l_opy_
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠨࡳࡢࡸࡨࡨࠥ࡬ࡩࡹࡶࡸࡶࡪࡴࡡ࡮ࡧࡀࡿ࡫࡯ࡸࡵࡷࡵࡩࡳࡧ࡭ࡦࡿࠣࡷࡨࡵࡰࡦ࠿ࡾࡷࡨࡵࡰࡦࡿࠣࡪ࡮ࡾࡴࡶࡴࡨࡁࢀࡺࡥࡴࡶࡢࡪ࡮ࡾࡴࡶࡴࡨࢁࠥࡺࡲࡢࡥ࡮ࡩࡩࡥࡦࡪࡺࡷࡹࡷ࡫ࡳ࠾ࠤᒤ") + str(len(bstack1l1111111ll_opy_)) + bstack1ll1lll_opy_ (u"ࠢࠣᒥ"))
        TestFramework.bstack1llll1l1l1l_opy_(instance, PytestBDDFramework.bstack1l111ll1l1l_opy_, bstack1l1111111ll_opy_)
        self.logger.debug(bstack1ll1lll_opy_ (u"ࠣࡵࡤࡺࡪࡪࠠࡧ࡫ࡻࡸࡺࡸࡥࡴ࠿ࡾࡰࡪࡴࠨࡵࡴࡤࡧࡰ࡫ࡤࡠࡨ࡬ࡼࡹࡻࡲࡦࡵࠬࢁࠥ࡯࡮ࡴࡶࡤࡲࡨ࡫࠽ࠣᒦ") + str(instance.ref()) + bstack1ll1lll_opy_ (u"ࠤࠥᒧ"))
        return instance
    def __11lllll1l11_opy_(
        self,
        context: bstack1l111l1ll11_opy_,
        test_framework_state: bstack1lll1111111_opy_,
        target: Any,
        *args,
    ):
        ctx = bstack1lllll1ll11_opy_.create_context(target)
        ob = bstack1lll11ll1l1_opy_(ctx, self.bstack1ll11l11l11_opy_, self.bstack1l111111111_opy_, test_framework_state)
        TestFramework.bstack1l111l111ll_opy_(ob, {
            TestFramework.bstack1ll11ll1l11_opy_: context.test_framework_name,
            TestFramework.bstack1l1ll1ll11l_opy_: context.test_framework_version,
            TestFramework.bstack1l111lll1l1_opy_: [],
            PytestBDDFramework.bstack1l111ll1l1l_opy_: {},
            PytestBDDFramework.bstack1l11111lll1_opy_: {},
            PytestBDDFramework.bstack1l1111l1l11_opy_: {},
        })
        if len(args) > 1 and isinstance(args[1], tuple):
            TestFramework.bstack1llll1l1l1l_opy_(ob, TestFramework.bstack1l111l1llll_opy_, str(args[1][0]))
        if context.platform_index >= 0:
            TestFramework.bstack1llll1l1l1l_opy_(ob, TestFramework.bstack1ll111l1ll1_opy_, context.platform_index)
        TestFramework.bstack1llllll1lll_opy_[ctx.id] = ob
        self.logger.debug(bstack1ll1lll_opy_ (u"ࠥࡷࡦࡼࡥࡥࠢ࡬ࡲࡸࡺࡡ࡯ࡥࡨࠤࡨࡺࡸ࠯࡫ࡧࡁࢀࡩࡴࡹ࠰࡬ࡨࢂࠦࡴࡢࡴࡪࡩࡹࡃࡻࡵࡣࡵ࡫ࡪࡺࡽࠡࡣࡵ࡫ࡸࡃࡻࡢࡴࡪࡷࢂࠦࡩ࡯ࡵࡷࡥࡳࡩࡥࡴ࠿ࠥᒨ") + str(TestFramework.bstack1llllll1lll_opy_.keys()) + bstack1ll1lll_opy_ (u"ࠦࠧᒩ"))
        return ob
    @staticmethod
    def __11llll1ll11_opy_(instance, args):
        request, feature, scenario = args
        steps = []
        for step in scenario.steps:
            steps.append({
                bstack1ll1lll_opy_ (u"ࠬ࡯ࡤࠨᒪ"): id(step),
                bstack1ll1lll_opy_ (u"࠭ࡴࡦࡺࡷࠫᒫ"): step.name,
                bstack1ll1lll_opy_ (u"ࠧ࡬ࡧࡼࡻࡴࡸࡤࠨᒬ"): step.keyword,
            })
        meta = {
            bstack1ll1lll_opy_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࠩᒭ"): {
                bstack1ll1lll_opy_ (u"ࠩࡱࡥࡲ࡫ࠧᒮ"): feature.name,
                bstack1ll1lll_opy_ (u"ࠪࡴࡦࡺࡨࠨᒯ"): feature.filename,
                bstack1ll1lll_opy_ (u"ࠫࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠩᒰ"): feature.description
            },
            bstack1ll1lll_opy_ (u"ࠬࡹࡣࡦࡰࡤࡶ࡮ࡵࠧᒱ"): {
                bstack1ll1lll_opy_ (u"࠭࡮ࡢ࡯ࡨࠫᒲ"): scenario.name
            },
            bstack1ll1lll_opy_ (u"ࠧࡴࡶࡨࡴࡸ࠭ᒳ"): steps,
            bstack1ll1lll_opy_ (u"ࠨࡧࡻࡥࡲࡶ࡬ࡦࡵࠪᒴ"): PytestBDDFramework.__1l11111l1l1_opy_(request.node)
        }
        instance.data.update(
            {
                TestFramework.bstack11lllllll11_opy_: meta
            }
        )
    def bstack1l111111l11_opy_(self, hook: Dict[str, Any]) -> None:
        bstack1ll1lll_opy_ (u"ࠤࠥࠦࠏࠦࠠࠡࠢࠣࠤࠥࠦࡐࡳࡱࡦࡩࡸࡹࡥࡴࠢࡷ࡬ࡪࠦࡈࡰࡱ࡮ࡐࡪࡼࡥ࡭ࠢࡤࡸࡹࡧࡣࡩ࡯ࡨࡲࡹࡹࠠࡴ࡫ࡰ࡭ࡱࡧࡲࠡࡶࡲࠤࡹ࡮ࡥࠡࡌࡤࡺࡦࠦࡩ࡮ࡲ࡯ࡩࡲ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࡗ࡬࡮ࡹࠠ࡮ࡧࡷ࡬ࡴࡪ࠺ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࠲ࠦࡃࡩࡧࡦ࡯ࡸࠦࡴࡩࡧࠣࡌࡴࡵ࡫ࡍࡧࡹࡩࡱࠦࡤࡪࡴࡨࡧࡹࡵࡲࡺࠢ࡬ࡲࡸ࡯ࡤࡦࠢࢁ࠳࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠳࡚ࡶ࡬ࡰࡣࡧࡩࡩࡇࡴࡵࡣࡦ࡬ࡲ࡫࡮ࡵࡵ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠮ࠢࡉࡳࡷࠦࡥࡢࡥ࡫ࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥ࡮࡯ࡰ࡭ࡢࡰࡪࡼࡥ࡭ࡡࡩ࡭ࡱ࡫ࡳ࠭ࠢࡵࡩࡵࡲࡡࡤࡧࡶࠤ࡚ࠧࡥࡴࡶࡏࡩࡻ࡫࡬ࠣࠢࡺ࡭ࡹ࡮ࠠࠣࡊࡲࡳࡰࡒࡥࡷࡧ࡯ࠦࠥ࡯࡮ࠡ࡫ࡷࡷࠥࡶࡡࡵࡪ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠮ࠢࡌࡪࠥࡧࠠࡧ࡫࡯ࡩࠥ࡯࡮ࠡࡶ࡫ࡩࠥࡪࡩࡳࡧࡦࡸࡴࡸࡹࠡ࡯ࡤࡸࡨ࡮ࡥࡴࠢࡤࠤࡲࡵࡤࡪࡨ࡬ࡩࡩࠦࡨࡰࡱ࡮࠱ࡱ࡫ࡶࡦ࡮ࠣࡪ࡮ࡲࡥ࠭ࠢ࡬ࡸࠥࡩࡲࡦࡣࡷࡩࡸࠦࡡࠡࡎࡲ࡫ࡊࡴࡴࡳࡻࠣࡳࡧࡰࡥࡤࡶࠣࡻ࡮ࡺࡨࠡࡣࡷࡸࡦࡩࡨ࡮ࡧࡱࡸࠥࡪࡥࡵࡣ࡬ࡰࡸ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣ࠱࡙ࠥࡩ࡮࡫࡯ࡥࡷࡲࡹ࠭ࠢ࡬ࡸࠥࡶࡲࡰࡥࡨࡷࡸ࡫ࡳࠡࡄࡸ࡭ࡱࡪࡌࡦࡸࡨࡰࠥࡧࡴࡵࡣࡦ࡬ࡲ࡫࡮ࡵࡵࠣࡰࡴࡩࡡࡵࡧࡧࠤ࡮ࡴࠠࡉࡱࡲ࡯ࡑ࡫ࡶࡦ࡮࠲ࡆࡺ࡯࡬ࡥࡎࡨࡺࡪࡲࡈࡰࡱ࡮ࡉࡻ࡫࡮ࡵࠢࡥࡽࠥࡸࡥࡱ࡮ࡤࡧ࡮ࡴࡧࠡࠤࡅࡹ࡮ࡲࡤࡍࡧࡹࡩࡱࠨࠠࡸ࡫ࡷ࡬ࠥࠨࡈࡰࡱ࡮ࡐࡪࡼࡥ࡭࠱ࡅࡹ࡮ࡲࡤࡍࡧࡹࡩࡱࡎ࡯ࡰ࡭ࡈࡺࡪࡴࡴࠣ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠭ࠡࡖ࡫ࡩࠥࡩࡲࡦࡣࡷࡩࡩࠦࡌࡰࡩࡈࡲࡹࡸࡹࠡࡱࡥ࡮ࡪࡩࡴࡴࠢࡤࡶࡪࠦࡡࡥࡦࡨࡨࠥࡺ࡯ࠡࡶ࡫ࡩࠥ࡮࡯ࡰ࡭ࠪࡷࠥࠨ࡬ࡰࡩࡶࠦࠥࡲࡩࡴࡶ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡇࡲࡨࡵ࠽ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࡫ࡳࡴࡱ࠺ࠡࡖ࡫ࡩࠥ࡫ࡶࡦࡰࡷࠤࡩ࡯ࡣࡵ࡫ࡲࡲࡦࡸࡹࠡࡥࡲࡲࡹࡧࡩ࡯࡫ࡱ࡫ࠥ࡫ࡸࡪࡵࡷ࡭ࡳ࡭ࠠ࡭ࡱࡪࡷࠥࡧ࡮ࡥࠢ࡫ࡳࡴࡱࠠࡪࡰࡩࡳࡷࡳࡡࡵ࡫ࡲࡲ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡭ࡵ࡯࡬ࡡ࡯ࡩࡻ࡫࡬ࡠࡨ࡬ࡰࡪࡹ࠺ࠡࡎ࡬ࡷࡹࠦ࡯ࡧࠢࡓࡥࡹ࡮ࠠࡰࡤ࡭ࡩࡨࡺࡳࠡࡨࡵࡳࡲࠦࡴࡩࡧࠣࡘࡪࡹࡴࡍࡧࡹࡩࡱࠦ࡭ࡰࡰ࡬ࡸࡴࡸࡩ࡯ࡩ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡥࡹ࡮ࡲࡤࡠ࡮ࡨࡺࡪࡲ࡟ࡧ࡫࡯ࡩࡸࡀࠠࡍ࡫ࡶࡸࠥࡵࡦࠡࡒࡤࡸ࡭ࠦ࡯ࡣ࡬ࡨࡧࡹࡹࠠࡧࡴࡲࡱࠥࡺࡨࡦࠢࡅࡹ࡮ࡲࡤࡍࡧࡹࡩࡱࠦ࡭ࡰࡰ࡬ࡸࡴࡸࡩ࡯ࡩ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣᒵ")
        global _1l1l1llllll_opy_
        platform_index = os.environ[bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡓࡐࡆ࡚ࡆࡐࡔࡐࡣࡎࡔࡄࡆ࡚ࠪᒶ")]
        bstack1l1lll11111_opy_ = os.path.join(bstack1l1ll1l11ll_opy_, (bstack1l1ll111ll1_opy_ + str(platform_index)), bstack11lllll1ll1_opy_)
        if not os.path.exists(bstack1l1lll11111_opy_) or not os.path.isdir(bstack1l1lll11111_opy_):
            return
        logs = hook.get(bstack1ll1lll_opy_ (u"ࠦࡱࡵࡧࡴࠤᒷ"), [])
        with os.scandir(bstack1l1lll11111_opy_) as entries:
            for entry in entries:
                abs_path = os.path.abspath(entry.path)
                if abs_path in _1l1l1llllll_opy_:
                    self.logger.info(bstack1ll1lll_opy_ (u"ࠧࡖࡡࡵࡪࠣࡥࡱࡸࡥࡢࡦࡼࠤࡵࡸ࡯ࡤࡧࡶࡷࡪࡪࠠࡼࡿࠥᒸ").format(abs_path))
                    continue
                if entry.is_file():
                    try:
                        timestamp = datetime.fromtimestamp(entry.stat().st_mtime, tz=timezone.utc).isoformat()
                    except Exception:
                        timestamp = bstack1ll1lll_opy_ (u"ࠨࠢᒹ")
                    log_entry = bstack1lll1l1l1l1_opy_(
                        kind=bstack1ll1lll_opy_ (u"ࠢࡕࡇࡖࡘࡤࡇࡔࡕࡃࡆࡌࡒࡋࡎࡕࠤᒺ"),
                        message=bstack1ll1lll_opy_ (u"ࠣࠤᒻ"),
                        level=bstack1ll1lll_opy_ (u"ࠤࠥᒼ"),
                        timestamp=timestamp,
                        fileName=entry.name,
                        bstack1l1l1llll1l_opy_=entry.stat().st_size,
                        bstack1l1l1l1l1ll_opy_=bstack1ll1lll_opy_ (u"ࠥࡑࡆࡔࡕࡂࡎࡢ࡙ࡕࡒࡏࡂࡆࠥᒽ"),
                        bstack1l1ll11_opy_=os.path.abspath(entry.path),
                        bstack11llll1ll1l_opy_=hook.get(TestFramework.bstack1l11111ll1l_opy_)
                    )
                    logs.append(log_entry)
                    _1l1l1llllll_opy_.add(abs_path)
        platform_index = os.environ[bstack1ll1lll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡔࡑࡇࡔࡇࡑࡕࡑࡤࡏࡎࡅࡇ࡛ࠫᒾ")]
        bstack1l111l11ll1_opy_ = os.path.join(bstack1l1ll1l11ll_opy_, (bstack1l1ll111ll1_opy_ + str(platform_index)), bstack11lllll1ll1_opy_, bstack1l111l11l1l_opy_)
        if not os.path.exists(bstack1l111l11ll1_opy_) or not os.path.isdir(bstack1l111l11ll1_opy_):
            self.logger.info(bstack1ll1lll_opy_ (u"ࠧࡔ࡯ࠡࡄࡸ࡭ࡱࡪࡌࡦࡸࡨࡰࡍࡵ࡯࡬ࡇࡹࡩࡳࡺࠠࡢࡶࡷࡥࡨ࡮࡭ࡦࡰࡷࡷࠥࡪࡩࡳࡧࡦࡸࡴࡸࡹࠡࡨࡲࡹࡳࡪࠠࡢࡶ࠽ࠤࢀࢃࠢᒿ").format(bstack1l111l11ll1_opy_))
        else:
            self.logger.info(bstack1ll1lll_opy_ (u"ࠨࡐࡳࡱࡦࡩࡸࡹࡩ࡯ࡩࠣࡆࡺ࡯࡬ࡥࡎࡨࡺࡪࡲࡈࡰࡱ࡮ࡉࡻ࡫࡮ࡵࠢࡤࡸࡹࡧࡣࡩ࡯ࡨࡲࡹࡹࠠࡧࡴࡲࡱࠥࡪࡩࡳࡧࡦࡸࡴࡸࡹ࠻ࠢࡾࢁࠧᓀ").format(bstack1l111l11ll1_opy_))
            with os.scandir(bstack1l111l11ll1_opy_) as entries:
                for entry in entries:
                    abs_path = os.path.abspath(entry.path)
                    if abs_path in _1l1l1llllll_opy_:
                        self.logger.info(bstack1ll1lll_opy_ (u"ࠢࡑࡣࡷ࡬ࠥࡧ࡬ࡳࡧࡤࡨࡾࠦࡰࡳࡱࡦࡩࡸࡹࡥࡥࠢࡾࢁࠧᓁ").format(abs_path))
                        continue
                    if entry.is_file():
                        try:
                            timestamp = datetime.fromtimestamp(entry.stat().st_mtime, tz=timezone.utc).isoformat()
                        except Exception:
                            timestamp = bstack1ll1lll_opy_ (u"ࠣࠤᓂ")
                        log_entry = bstack1lll1l1l1l1_opy_(
                            kind=bstack1ll1lll_opy_ (u"ࠤࡗࡉࡘ࡚࡟ࡂࡖࡗࡅࡈࡎࡍࡆࡐࡗࠦᓃ"),
                            message=bstack1ll1lll_opy_ (u"ࠥࠦᓄ"),
                            level=bstack1ll1lll_opy_ (u"ࠦࡇࡻࡩ࡭ࡦࡏࡩࡻ࡫࡬ࠣᓅ"),
                            timestamp=timestamp,
                            fileName=entry.name,
                            bstack1l1l1llll1l_opy_=entry.stat().st_size,
                            bstack1l1l1l1l1ll_opy_=bstack1ll1lll_opy_ (u"ࠧࡓࡁࡏࡗࡄࡐࡤ࡛ࡐࡍࡑࡄࡈࠧᓆ"),
                            bstack1l1ll11_opy_=os.path.abspath(entry.path),
                            bstack1l1ll1ll1ll_opy_=hook.get(TestFramework.bstack1l11111ll1l_opy_)
                        )
                        logs.append(log_entry)
                        _1l1l1llllll_opy_.add(abs_path)
        hook[bstack1ll1lll_opy_ (u"ࠨ࡬ࡰࡩࡶࠦᓇ")] = logs
    def bstack1l1l1lll1ll_opy_(
        self,
        bstack1l1l1l1llll_opy_: bstack1lll11ll1l1_opy_,
        entries: List[bstack1lll1l1l1l1_opy_],
    ):
        req = structs.LogCreatedEventRequest()
        req.bin_session_id = os.environ.get(bstack1ll1lll_opy_ (u"ࠢࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡃࡍࡋࡢࡆࡎࡔ࡟ࡔࡇࡖࡗࡎࡕࡎࡠࡋࡇࠦᓈ"))
        req.platform_index = TestFramework.bstack1lllll1l1ll_opy_(bstack1l1l1l1llll_opy_, TestFramework.bstack1ll111l1ll1_opy_)
        req.execution_context.hash = str(bstack1l1l1l1llll_opy_.context.hash)
        req.execution_context.thread_id = str(bstack1l1l1l1llll_opy_.context.thread_id)
        req.execution_context.process_id = str(bstack1l1l1l1llll_opy_.context.process_id)
        for entry in entries:
            log_entry = req.logs.add()
            log_entry.test_framework_name = TestFramework.bstack1lllll1l1ll_opy_(bstack1l1l1l1llll_opy_, TestFramework.bstack1ll11ll1l11_opy_)
            log_entry.test_framework_version = TestFramework.bstack1lllll1l1ll_opy_(bstack1l1l1l1llll_opy_, TestFramework.bstack1l1ll1ll11l_opy_)
            log_entry.uuid = entry.bstack11llll1ll1l_opy_ if entry.bstack11llll1ll1l_opy_ else TestFramework.bstack1lllll1l1ll_opy_(bstack1l1l1l1llll_opy_, TestFramework.bstack1ll11ll111l_opy_)
            log_entry.test_framework_state = bstack1l1l1l1llll_opy_.state.name
            log_entry.message = entry.message.encode(bstack1ll1lll_opy_ (u"ࠣࡷࡷࡪ࠲࠾ࠢᓉ"))
            log_entry.kind = entry.kind
            log_entry.timestamp = (
                entry.timestamp.isoformat()
                if isinstance(entry.timestamp, datetime)
                else datetime.now(tz=timezone.utc).isoformat()
            )
            if isinstance(entry.level, str) and len(entry.level.strip()) > 0:
                log_entry.level = entry.level.strip()
            if entry.kind == bstack1ll1lll_opy_ (u"ࠤࡗࡉࡘ࡚࡟ࡂࡖࡗࡅࡈࡎࡍࡆࡐࡗࠦᓊ"):
                log_entry.file_name = entry.fileName
                log_entry.file_size = entry.bstack1l1l1llll1l_opy_
                log_entry.file_path = entry.bstack1l1ll11_opy_
        def bstack1l1ll11l111_opy_():
            bstack11l1lll11_opy_ = datetime.now()
            try:
                self.bstack1ll1ll1llll_opy_.LogCreatedEvent(req)
                bstack1l1l1l1llll_opy_.bstack1ll1l111l_opy_(bstack1ll1lll_opy_ (u"ࠥ࡫ࡷࡶࡣ࠻ࡵࡨࡲࡩࡥ࡬ࡰࡩࡢࡧࡷ࡫ࡡࡵࡧࡧࡣࡪࡼࡥ࡯ࡶࡢࡥࡹࡺࡡࡤࡪࡰࡩࡳࡺࠢᓋ"), datetime.now() - bstack11l1lll11_opy_)
            except grpc.RpcError as e:
                self.log_error(bstack1ll1lll_opy_ (u"ࠦࡷࡶࡣ࠮ࡧࡵࡶࡴࡸ࠺ࠡࡵࡨࡲࡩࡥ࡬ࡰࡩࡢࡧࡷ࡫ࡡࡵࡧࡧࡣࡪࡼࡥ࡯ࡶࡢࡥࡹࡺࡡࡤࡪࡰࡩࡳࡺࠠࡼࡿࠥᓌ").format(str(e)))
                traceback.print_exc()
        self.bstack1lllllll1ll_opy_.enqueue(bstack1l1ll11l111_opy_)
    def __1l111l11lll_opy_(self, instance) -> None:
        bstack1ll1lll_opy_ (u"ࠧࠨࠢࠋࠢࠣࠤࠥࠦࠠࠡࠢࡏࡳࡦࡪࡳࠡࡥࡸࡷࡹࡵ࡭ࠡࡶࡤ࡫ࡸࠦࡦࡰࡴࠣࡸ࡭࡫ࠠࡨ࡫ࡹࡩࡳࠦࡴࡦࡵࡷࠤ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱࠠࡪࡰࡶࡸࡦࡴࡣࡦ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࡈࡸࡥࡢࡶࡨࡷࠥࡧࠠࡥ࡫ࡦࡸࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡯࡮ࡨࠢࡷࡩࡸࡺࠠ࡭ࡧࡹࡩࡱࠦࡣࡶࡵࡷࡳࡲࠦ࡭ࡦࡶࡤࡨࡦࡺࡡࠡࡴࡨࡸࡷ࡯ࡥࡷࡧࡧࠤ࡫ࡸ࡯࡮ࠌࠣࠤࠥࠦࠠࠡࠢࠣࡇࡺࡹࡴࡰ࡯ࡗࡥ࡬ࡓࡡ࡯ࡣࡪࡩࡷࠦࡡ࡯ࡦࠣࡹࡵࡪࡡࡵࡧࡶࠤࡹ࡮ࡥࠡ࡫ࡱࡷࡹࡧ࡮ࡤࡧࠣࡷࡹࡧࡴࡦࠢࡸࡷ࡮ࡴࡧࠡࡵࡨࡸࡤࡹࡴࡢࡶࡨࡣࡪࡴࡴࡳ࡫ࡨࡷ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥᓍ")
        bstack11llllllll1_opy_ = {bstack1ll1lll_opy_ (u"ࠨࡣࡶࡵࡷࡳࡲࡥ࡭ࡦࡶࡤࡨࡦࡺࡡࠣᓎ"): bstack1lll11l11ll_opy_.bstack1l1111lll1l_opy_()}
        TestFramework.bstack1l111l111ll_opy_(instance, bstack11llllllll1_opy_)
    @staticmethod
    def __11lllllllll_opy_(instance, args):
        request, bstack11llll1l1ll_opy_ = args
        bstack1l111111ll1_opy_ = id(bstack11llll1l1ll_opy_)
        bstack11llll1l1l1_opy_ = instance.data[TestFramework.bstack11lllllll11_opy_]
        step = next(filter(lambda st: st[bstack1ll1lll_opy_ (u"ࠧࡪࡦࠪᓏ")] == bstack1l111111ll1_opy_, bstack11llll1l1l1_opy_[bstack1ll1lll_opy_ (u"ࠨࡵࡷࡩࡵࡹࠧᓐ")]), None)
        step.update({
            bstack1ll1lll_opy_ (u"ࠩࡶࡸࡦࡸࡴࡦࡦࡢࡥࡹ࠭ᓑ"): datetime.now(tz=timezone.utc)
        })
        index = next((i for i, st in enumerate(bstack11llll1l1l1_opy_[bstack1ll1lll_opy_ (u"ࠪࡷࡹ࡫ࡰࡴࠩᓒ")]) if st[bstack1ll1lll_opy_ (u"ࠫ࡮ࡪࠧᓓ")] == step[bstack1ll1lll_opy_ (u"ࠬ࡯ࡤࠨᓔ")]), None)
        if index is not None:
            bstack11llll1l1l1_opy_[bstack1ll1lll_opy_ (u"࠭ࡳࡵࡧࡳࡷࠬᓕ")][index] = step
        instance.data[TestFramework.bstack11lllllll11_opy_] = bstack11llll1l1l1_opy_
    @staticmethod
    def __1l111ll1l11_opy_(instance, args):
        bstack1ll1lll_opy_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࠡࠢࠣࠤࡼ࡮ࡥ࡯ࠢ࡯ࡩࡳࠦࡡࡳࡩࡶࠤ࡮ࡹࠠ࠳࠮ࠣ࡭ࡹࠦࡳࡪࡩࡱ࡭࡫࡯ࡥࡴࠢࡷ࡬ࡪࡸࡥࠡ࡫ࡶࠤࡳࡵࠠࡦࡺࡦࡩࡵࡺࡩࡰࡰࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡣࡵ࡫ࡸࠦࡡࡳࡧࠣ࠱ࠥࡡࡲࡦࡳࡸࡩࡸࡺࠬࠡࡵࡷࡩࡵࡣࠊࠡࠢࠣࠤࠥࠦࠠࠡ࡫ࡩࠤࡦࡸࡧࡴࠢࡤࡶࡪࠦ࠳ࠡࡶ࡫ࡩࡳࠦࡴࡩࡧࠣࡰࡦࡹࡴࠡࡸࡤࡰࡺ࡫ࠠࡪࡵࠣࡩࡽࡩࡥࡱࡶ࡬ࡳࡳࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥᓖ")
        bstack1l111l1lll1_opy_ = datetime.now(tz=timezone.utc)
        request = args[0]
        bstack11llll1l1ll_opy_ = args[1]
        bstack1l111111ll1_opy_ = id(bstack11llll1l1ll_opy_)
        bstack11llll1l1l1_opy_ = instance.data[TestFramework.bstack11lllllll11_opy_]
        step = None
        if bstack1l111111ll1_opy_ is not None and bstack11llll1l1l1_opy_.get(bstack1ll1lll_opy_ (u"ࠨࡵࡷࡩࡵࡹࠧᓗ")):
            step = next(filter(lambda st: st[bstack1ll1lll_opy_ (u"ࠩ࡬ࡨࠬᓘ")] == bstack1l111111ll1_opy_, bstack11llll1l1l1_opy_[bstack1ll1lll_opy_ (u"ࠪࡷࡹ࡫ࡰࡴࠩᓙ")]), None)
            step.update({
                bstack1ll1lll_opy_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡥࡡࡵࠩᓚ"): bstack1l111l1lll1_opy_,
            })
        if len(args) > 2:
            exception = args[2]
            step.update({
                bstack1ll1lll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬᓛ"): bstack1ll1lll_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ᓜ"),
                bstack1ll1lll_opy_ (u"ࠧࡧࡣ࡬ࡰࡺࡸࡥࠨᓝ"): str(exception)
            })
        else:
            if step is not None:
                step.update({
                    bstack1ll1lll_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨᓞ"): bstack1ll1lll_opy_ (u"ࠩࡳࡥࡸࡹࡥࡥࠩᓟ"),
                })
        index = next((i for i, st in enumerate(bstack11llll1l1l1_opy_[bstack1ll1lll_opy_ (u"ࠪࡷࡹ࡫ࡰࡴࠩᓠ")]) if st[bstack1ll1lll_opy_ (u"ࠫ࡮ࡪࠧᓡ")] == step[bstack1ll1lll_opy_ (u"ࠬ࡯ࡤࠨᓢ")]), None)
        if index is not None:
            bstack11llll1l1l1_opy_[bstack1ll1lll_opy_ (u"࠭ࡳࡵࡧࡳࡷࠬᓣ")][index] = step
        instance.data[TestFramework.bstack11lllllll11_opy_] = bstack11llll1l1l1_opy_
    @staticmethod
    def __1l11111l1l1_opy_(node):
        try:
            examples = []
            if hasattr(node, bstack1ll1lll_opy_ (u"ࠧࡤࡣ࡯ࡰࡸࡶࡥࡤࠩᓤ")):
                examples = list(node.callspec.params[bstack1ll1lll_opy_ (u"ࠨࡡࡳࡽࡹ࡫ࡳࡵࡡࡥࡨࡩࡥࡥࡹࡣࡰࡴࡱ࡫ࠧᓥ")].values())
            return examples
        except:
            return []
    def bstack1l1lll11l11_opy_(self, instance: bstack1lll11ll1l1_opy_, bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_]):
        bstack1l1111l1111_opy_ = (
            PytestBDDFramework.bstack1l111l111l1_opy_
            if bstack1lllll11l11_opy_[1] == bstack1lll1l1l1ll_opy_.PRE
            else PytestBDDFramework.bstack1l111l1l111_opy_
        )
        hook = PytestBDDFramework.bstack11llllll1l1_opy_(instance, bstack1l1111l1111_opy_)
        entries = hook.get(TestFramework.bstack1l111l1ll1l_opy_, []) if isinstance(hook, dict) else []
        entries.extend(TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1l111lll1l1_opy_, []))
        return entries
    def bstack1l1ll11l1ll_opy_(self, instance: bstack1lll11ll1l1_opy_, bstack1lllll11l11_opy_: Tuple[bstack1lll1111111_opy_, bstack1lll1l1l1ll_opy_]):
        bstack1l1111l1111_opy_ = (
            PytestBDDFramework.bstack1l111l111l1_opy_
            if bstack1lllll11l11_opy_[1] == bstack1lll1l1l1ll_opy_.PRE
            else PytestBDDFramework.bstack1l111l1l111_opy_
        )
        PytestBDDFramework.bstack1l1111l1lll_opy_(instance, bstack1l1111l1111_opy_)
        TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1l111lll1l1_opy_, []).clear()
    @staticmethod
    def bstack11llllll1l1_opy_(instance: bstack1lll11ll1l1_opy_, bstack1l1111l1111_opy_: str):
        bstack1l111l1l11l_opy_ = (
            PytestBDDFramework.bstack1l11111lll1_opy_
            if bstack1l1111l1111_opy_ == PytestBDDFramework.bstack1l111l1l111_opy_
            else PytestBDDFramework.bstack1l1111l1l11_opy_
        )
        bstack1l1111l1l1l_opy_ = TestFramework.bstack1lllll1l1ll_opy_(instance, bstack1l1111l1111_opy_, None)
        bstack1l11111l1ll_opy_ = TestFramework.bstack1lllll1l1ll_opy_(instance, bstack1l111l1l11l_opy_, None) if bstack1l1111l1l1l_opy_ else None
        return (
            bstack1l11111l1ll_opy_[bstack1l1111l1l1l_opy_][-1]
            if isinstance(bstack1l11111l1ll_opy_, dict) and len(bstack1l11111l1ll_opy_.get(bstack1l1111l1l1l_opy_, [])) > 0
            else None
        )
    @staticmethod
    def bstack1l1111l1lll_opy_(instance: bstack1lll11ll1l1_opy_, bstack1l1111l1111_opy_: str):
        hook = PytestBDDFramework.bstack11llllll1l1_opy_(instance, bstack1l1111l1111_opy_)
        if isinstance(hook, dict):
            hook.get(TestFramework.bstack1l111l1ll1l_opy_, []).clear()
    @staticmethod
    def __11lllll11l1_opy_(instance: bstack1lll11ll1l1_opy_, *args):
        if len(args) < 2 or not callable(getattr(args[1], bstack1ll1lll_opy_ (u"ࠤࡪࡩࡹࡥࡲࡦࡥࡲࡶࡩࡹࠢᓦ"), None)):
            return
        if os.getenv(bstack1ll1lll_opy_ (u"ࠥࡗࡉࡑ࡟ࡄࡎࡌࡣࡋࡒࡁࡈࡡࡏࡓࡌ࡙ࠢᓧ"), bstack1ll1lll_opy_ (u"ࠦ࠶ࠨᓨ")) != bstack1ll1lll_opy_ (u"ࠧ࠷ࠢᓩ"):
            PytestBDDFramework.logger.warning(bstack1ll1lll_opy_ (u"ࠨࡩࡨࡰࡲࡶ࡮ࡴࡧࠡࡥࡤࡴࡱࡵࡧࠣᓪ"))
            return
        bstack1l1111lllll_opy_ = {
            bstack1ll1lll_opy_ (u"ࠢࡴࡧࡷࡹࡵࠨᓫ"): (PytestBDDFramework.bstack1l111l111l1_opy_, PytestBDDFramework.bstack1l1111l1l11_opy_),
            bstack1ll1lll_opy_ (u"ࠣࡶࡨࡥࡷࡪ࡯ࡸࡰࠥᓬ"): (PytestBDDFramework.bstack1l111l1l111_opy_, PytestBDDFramework.bstack1l11111lll1_opy_),
        }
        for when in (bstack1ll1lll_opy_ (u"ࠤࡶࡩࡹࡻࡰࠣᓭ"), bstack1ll1lll_opy_ (u"ࠥࡧࡦࡲ࡬ࠣᓮ"), bstack1ll1lll_opy_ (u"ࠦࡹ࡫ࡡࡳࡦࡲࡻࡳࠨᓯ")):
            bstack1l11111llll_opy_ = args[1].get_records(when)
            if not bstack1l11111llll_opy_:
                continue
            records = [
                bstack1lll1l1l1l1_opy_(
                    kind=TestFramework.bstack1l1lll11lll_opy_,
                    message=r.message,
                    level=r.levelname if hasattr(r, bstack1ll1lll_opy_ (u"ࠧࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠣᓰ")) and r.levelname else None,
                    timestamp=(
                        datetime.fromtimestamp(r.created, tz=timezone.utc)
                        if hasattr(r, bstack1ll1lll_opy_ (u"ࠨࡣࡳࡧࡤࡸࡪࡪࠢᓱ")) and r.created
                        else None
                    ),
                )
                for r in bstack1l11111llll_opy_
                if isinstance(getattr(r, bstack1ll1lll_opy_ (u"ࠢ࡮ࡧࡶࡷࡦ࡭ࡥࠣᓲ"), None), str) and r.message.strip()
            ]
            if not records:
                continue
            bstack1l111l11111_opy_, bstack1l111l1l11l_opy_ = bstack1l1111lllll_opy_.get(when, (None, None))
            bstack1l111lll1ll_opy_ = TestFramework.bstack1lllll1l1ll_opy_(instance, bstack1l111l11111_opy_, None) if bstack1l111l11111_opy_ else None
            bstack1l11111l1ll_opy_ = TestFramework.bstack1lllll1l1ll_opy_(instance, bstack1l111l1l11l_opy_, None) if bstack1l111lll1ll_opy_ else None
            if isinstance(bstack1l11111l1ll_opy_, dict) and len(bstack1l11111l1ll_opy_.get(bstack1l111lll1ll_opy_, [])) > 0:
                hook = bstack1l11111l1ll_opy_[bstack1l111lll1ll_opy_][-1]
                if isinstance(hook, dict) and TestFramework.bstack1l111l1ll1l_opy_ in hook:
                    hook[TestFramework.bstack1l111l1ll1l_opy_].extend(records)
                    continue
            logs = TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1l111lll1l1_opy_, [])
            logs.extend(records)
    @staticmethod
    def __1l1111ll1l1_opy_(args) -> Dict[str, Any]:
        request, feature, scenario = args
        bstack1l11l1l1l_opy_ = request.node.nodeid
        test_name = PytestBDDFramework.__11llll1llll_opy_(request.node, scenario)
        bstack1l1111ll11l_opy_ = feature.filename
        if not bstack1l11l1l1l_opy_ or not test_name or not bstack1l1111ll11l_opy_:
            return None
        code = None
        return {
            TestFramework.bstack1ll11ll111l_opy_: uuid4().__str__(),
            TestFramework.bstack1l11111111l_opy_: bstack1l11l1l1l_opy_,
            TestFramework.bstack1ll1l111111_opy_: test_name,
            TestFramework.bstack1l1l11lll1l_opy_: bstack1l11l1l1l_opy_,
            TestFramework.bstack1l1111lll11_opy_: bstack1l1111ll11l_opy_,
            TestFramework.bstack1l1111111l1_opy_: PytestBDDFramework.__11llllll1ll_opy_(feature, scenario),
            TestFramework.bstack11lllll11ll_opy_: code,
            TestFramework.bstack1l11llll111_opy_: TestFramework.bstack1l111111lll_opy_,
            TestFramework.bstack1l11l11lll1_opy_: test_name
        }
    @staticmethod
    def __11llll1llll_opy_(node, scenario):
        if hasattr(node, bstack1ll1lll_opy_ (u"ࠨࡥࡤࡰࡱࡹࡰࡦࡥࠪᓳ")):
            parts = node.nodeid.rsplit(bstack1ll1lll_opy_ (u"ࠤ࡞ࠦᓴ"))
            params = parts[-1]
            return bstack1ll1lll_opy_ (u"ࠥࡿࢂ࡛ࠦࡼࡿࠥᓵ").format(scenario.name, params)
        return scenario.name
    @staticmethod
    def __11llllll1ll_opy_(feature, scenario) -> List[str]:
        return (list(feature.tags) if hasattr(feature, bstack1ll1lll_opy_ (u"ࠫࡹࡧࡧࡴࠩᓶ")) else []) + (list(scenario.tags) if hasattr(scenario, bstack1ll1lll_opy_ (u"ࠬࡺࡡࡨࡵࠪᓷ")) else [])
    @staticmethod
    def __1l1111l11ll_opy_(location):
        return bstack1ll1lll_opy_ (u"ࠨ࠺࠻ࠤᓸ").join(filter(lambda x: isinstance(x, str), location))