# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import multiprocessing
import os
import json
from time import sleep
import time
import bstack_utils.accessibility as bstack1l11l1l1_opy_
import subprocess
import re
from browserstack_sdk.bstack11lll11111_opy_ import *
from bstack_utils.config import Config
from bstack_utils.messages import bstack1llll111l_opy_
from bstack_utils.bstack1llll111ll_opy_ import bstack11lll1lll1_opy_
from bstack_utils.constants import bstack11111l1lll_opy_
from bstack_utils.bstack11ll1ll11l_opy_ import bstack11ll11ll11_opy_
class bstack11lll1l111_opy_:
    bstack111111l111_opy_ = bstack1ll1lll_opy_ (u"ࡷ࠭࠼ࡎࡱࡧࡹࡱ࡫ࠠࠩ࡝ࡡࡂࡢ࠱ࠩ࠿ࠩၘ")  # bstack11111l1l1l_opy_ lines bstack11l111l_opy_ <Module path/to/bstack1111l1l11_opy_.py> in pytest --collect-bstack11111lllll_opy_ output
    def __init__(self, args, logger, bstack1111l111ll_opy_, bstack1111l1l111_opy_):
        self.args = args
        self.logger = logger
        self.bstack1111l111ll_opy_ = bstack1111l111ll_opy_
        self.bstack1111l1l111_opy_ = bstack1111l1l111_opy_
        self._prepareconfig = None
        self.Config = None
        self.runner = None
        self.bstack11l1ll1111_opy_ = []
        self.bstack111111ll1l_opy_ = []
        self.bstack111111l11_opy_ = []
        self.bstack111111ll11_opy_ = self.bstack1l1ll1ll_opy_()
        self.bstack1ll1ll1ll1_opy_ = -1
    def bstack1l11lll11_opy_(self, bstack111111l1ll_opy_):
        self.parse_args()
        self.bstack11111llll1_opy_()
        self.bstack11111l111l_opy_(bstack111111l1ll_opy_)
        self.bstack111111l1l1_opy_()
    def bstack1llll11l1_opy_(self):
        bstack11ll1ll11l_opy_ = bstack11ll11ll11_opy_.bstack1l1l111l_opy_(self.bstack1111l111ll_opy_, self.logger)
        if bstack11ll1ll11l_opy_ is None:
            self.logger.warn(bstack1ll1lll_opy_ (u"ࠨࡏࡳࡥ࡫ࡩࡸࡺࡲࡢࡶ࡬ࡳࡳࠦࡨࡢࡰࡧࡰࡪࡸࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰ࡬ࡸ࡮ࡧ࡬ࡪࡼࡨࡨ࠳ࠦࡓ࡬࡫ࡳࡴ࡮ࡴࡧࠡࡱࡵࡧ࡭࡫ࡳࡵࡴࡤࡸ࡮ࡵ࡮࠯ࠤၙ"))
            return
        bstack111111llll_opy_ = False
        bstack11ll1ll11l_opy_.bstack111111l11l_opy_(bstack1ll1lll_opy_ (u"ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣၚ"), bstack11ll1ll11l_opy_.bstack1ll11lll1l_opy_())
        start_time = time.time()
        if bstack11ll1ll11l_opy_.bstack1ll11lll1l_opy_():
            test_files = self.bstack11111ll111_opy_()
            bstack111111llll_opy_ = True
            bstack11111ll1l1_opy_ = bstack11ll1ll11l_opy_.bstack11111lll11_opy_(test_files)
            if bstack11111ll1l1_opy_:
                self.bstack11l1ll1111_opy_ = [os.path.normpath(item).replace(bstack1ll1lll_opy_ (u"ࠨ࡞࡟ࠫၛ"), bstack1ll1lll_opy_ (u"ࠩ࠲ࠫၜ")) for item in bstack11111ll1l1_opy_]
                self.__11111ll11l_opy_()
                bstack11ll1ll11l_opy_.bstack1111l11ll1_opy_(bstack111111llll_opy_)
                self.logger.info(bstack1ll1lll_opy_ (u"ࠥࡘࡪࡹࡴࡴࠢࡵࡩࡴࡸࡤࡦࡴࡨࡨࠥࡻࡳࡪࡰࡪࠤࡴࡸࡣࡩࡧࡶࡸࡷࡧࡴࡪࡱࡱ࠾ࠥࢁࡽࠣၝ").format(self.bstack11l1ll1111_opy_))
            else:
                self.logger.info(bstack1ll1lll_opy_ (u"ࠦࡓࡵࠠࡵࡧࡶࡸࠥ࡬ࡩ࡭ࡧࡶࠤࡼ࡫ࡲࡦࠢࡵࡩࡴࡸࡤࡦࡴࡨࡨࠥࡨࡹࠡࡱࡵࡧ࡭࡫ࡳࡵࡴࡤࡸ࡮ࡵ࡮࠯ࠤၞ"))
        bstack11ll1ll11l_opy_.bstack111111l11l_opy_(bstack1ll1lll_opy_ (u"ࠧࡺࡩ࡮ࡧࡗࡥࡰ࡫࡮ࡕࡱࡄࡴࡵࡲࡹࠣၟ"), int((time.time() - start_time) * 1000)) # bstack11111l11ll_opy_ to bstack11111l1ll1_opy_
    def __11111ll11l_opy_(self):
        bstack1ll1lll_opy_ (u"ࠨࠢࠣࠌࠣࠤࠥࠦࠠࠡࠢࠣࡊࡴࡸࠠࡦࡣࡦ࡬ࠥࡺࡥࡴࡶࠣࡪ࡮ࡲࡥࠡ࡫ࡱࠤࡸ࡫࡬ࡧ࠰ࡶࡴࡪࡩ࡟ࡧ࡫࡯ࡩࡸ࠲ࠠࡤࡱ࡯ࡰࡪࡩࡴࠡࡣ࡯ࡰࠥࡴ࡯ࡥࡧ࡬ࡨࡸࠦࡵࡴ࡫ࡱ࡫ࠥࡶࡹࡵࡧࡶࡸࠥ࠳࠭ࡤࡱ࡯ࡰࡪࡩࡴ࠮ࡱࡱࡰࡾࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥၠ")
        bstack11111l1l11_opy_ = []
        for bstack1111l1l11_opy_ in self.bstack11l1ll1111_opy_:
            bstack1111l11l1l_opy_ = [bstack1ll1lll_opy_ (u"ࠢࡱࡻࡷࡩࡸࡺࠢၡ"), bstack1111l1l11_opy_, bstack1ll1lll_opy_ (u"ࠣ࠯࠰ࡧࡴࡲ࡬ࡦࡥࡷ࠱ࡴࡴ࡬ࡺࠤၢ"), bstack1ll1lll_opy_ (u"ࠤ࠰ࡵࠧၣ")]
            result = subprocess.run(bstack1111l11l1l_opy_, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            if result.returncode != 0:
                self.logger.error(bstack11111ll1ll_opy_ (u"ࠥࡉࡷࡸ࡯ࡳࠢࡦࡳࡱࡲࡥࡤࡶ࡬ࡲ࡬ࠦ࡮ࡰࡦࡨ࡭ࡩࡹࠠࡧࡱࡵࠤࢀࡺࡥࡴࡶࡢࡪ࡮ࡲࡥࡾ࠼ࠣࡿࡷ࡫ࡳࡶ࡮ࡷ࠲ࡸࡺࡤࡦࡴࡵࢁࠧၤ"))
                continue
            for line in result.stdout.splitlines():
                line = line.strip()
                if line and not line.startswith(bstack1ll1lll_opy_ (u"ࠦࡁࠨၥ")) and bstack1ll1lll_opy_ (u"ࠧࡀ࠺ࠣၦ") in line:
                    bstack11111l1l11_opy_.append(line)
        os.environ[bstack1ll1lll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡕࡒࡄࡊࡈࡗ࡙ࡘࡁࡕࡇࡇࡣࡘࡋࡌࡆࡅࡗࡓࡗ࡙ࠧၧ")] = json.dumps(bstack11111l1l11_opy_)
    @staticmethod
    def version():
        import pytest
        return pytest.__version__
    @staticmethod
    def bstack1111l11111_opy_():
        import importlib
        if getattr(importlib, bstack1ll1lll_opy_ (u"ࠧࡧ࡫ࡱࡨࡤࡲ࡯ࡢࡦࡨࡶࠬၨ"), False):
            bstack1111l1l11l_opy_ = importlib.find_loader(bstack1ll1lll_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࡠࡵࡨࡰࡪࡴࡩࡶ࡯ࠪၩ"))
        else:
            bstack1111l1l11l_opy_ = importlib.util.find_spec(bstack1ll1lll_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࡡࡶࡩࡱ࡫࡮ࡪࡷࡰࠫၪ"))
    def bstack11111lll1l_opy_(self, arg):
        if arg in self.args:
            i = self.args.index(arg)
            self.args.pop(i + 1)
            self.args.pop(i)
    def parse_args(self):
        self.bstack1ll1ll1ll1_opy_ = -1
        if self.bstack1111l1l111_opy_ and bstack1ll1lll_opy_ (u"ࠪࡴࡦࡸࡡ࡭࡮ࡨࡰࡸࡖࡥࡳࡒ࡯ࡥࡹ࡬࡯ࡳ࡯ࠪၫ") in self.bstack1111l111ll_opy_:
            self.bstack1ll1ll1ll1_opy_ = int(self.bstack1111l111ll_opy_[bstack1ll1lll_opy_ (u"ࠫࡵࡧࡲࡢ࡮࡯ࡩࡱࡹࡐࡦࡴࡓࡰࡦࡺࡦࡰࡴࡰࠫၬ")])
        try:
            bstack11111l11l1_opy_ = [bstack1ll1lll_opy_ (u"ࠬ࠳࠭ࡥࡴ࡬ࡺࡪࡸࠧၭ"), bstack1ll1lll_opy_ (u"࠭࠭࠮ࡲ࡯ࡹ࡬࡯࡮ࡴࠩၮ"), bstack1ll1lll_opy_ (u"ࠧ࠮ࡲࠪၯ")]
            if self.bstack1ll1ll1ll1_opy_ >= 0:
                bstack11111l11l1_opy_.extend([bstack1ll1lll_opy_ (u"ࠨ࠯࠰ࡲࡺࡳࡰࡳࡱࡦࡩࡸࡹࡥࡴࠩၰ"), bstack1ll1lll_opy_ (u"ࠩ࠰ࡲࠬၱ")])
            for arg in bstack11111l11l1_opy_:
                self.bstack11111lll1l_opy_(arg)
        except Exception as exc:
            self.logger.error(str(exc))
    def get_args(self):
        return self.args
    def bstack11111llll1_opy_(self):
        bstack111111ll1l_opy_ = [os.path.normpath(item) for item in self.args]
        self.bstack111111ll1l_opy_ = bstack111111ll1l_opy_
        return self.bstack111111ll1l_opy_
    def bstack111l1111l_opy_(self):
        try:
            from _pytest.config import _prepareconfig
            from _pytest.config import Config
            from _pytest import runner
            self.bstack1111l11111_opy_()
            self._prepareconfig = _prepareconfig
            self.Config = Config
            self.runner = runner
        except Exception as e:
            self.logger.warn(e, bstack1llll111l_opy_)
    def bstack11111l111l_opy_(self, bstack111111l1ll_opy_):
        bstack11l1l11l_opy_ = Config.bstack1l1l111l_opy_()
        if bstack111111l1ll_opy_:
            self.bstack111111ll1l_opy_.append(bstack1ll1lll_opy_ (u"ࠪ࠱࠲ࡹ࡫ࡪࡲࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧၲ"))
            self.bstack111111ll1l_opy_.append(bstack1ll1lll_opy_ (u"࡙ࠫࡸࡵࡦࠩၳ"))
        if bstack11l1l11l_opy_.bstack1111l11lll_opy_():
            self.bstack111111ll1l_opy_.append(bstack1ll1lll_opy_ (u"ࠬ࠳࠭ࡴ࡭࡬ࡴࡘ࡫ࡳࡴ࡫ࡲࡲࡘࡺࡡࡵࡷࡶࠫၴ"))
            self.bstack111111ll1l_opy_.append(bstack1ll1lll_opy_ (u"࠭ࡔࡳࡷࡨࠫၵ"))
        self.bstack111111ll1l_opy_.append(bstack1ll1lll_opy_ (u"ࠧ࠮ࡲࠪၶ"))
        self.bstack111111ll1l_opy_.append(bstack1ll1lll_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࡠࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡰ࡭ࡷࡪ࡭ࡳ࠭ၷ"))
        self.bstack111111ll1l_opy_.append(bstack1ll1lll_opy_ (u"ࠩ࠰࠱ࡩࡸࡩࡷࡧࡵࠫၸ"))
        self.bstack111111ll1l_opy_.append(bstack1ll1lll_opy_ (u"ࠪࡧ࡭ࡸ࡯࡮ࡧࠪၹ"))
        if self.bstack1ll1ll1ll1_opy_ > 1:
            self.bstack111111ll1l_opy_.append(bstack1ll1lll_opy_ (u"ࠫ࠲ࡴࠧၺ"))
            self.bstack111111ll1l_opy_.append(str(self.bstack1ll1ll1ll1_opy_))
    def bstack111111l1l1_opy_(self):
        if bstack11lll1lll1_opy_.bstack1111ll1l1_opy_(self.bstack1111l111ll_opy_):
             self.bstack111111ll1l_opy_ += [
                bstack11111l1lll_opy_.get(bstack1ll1lll_opy_ (u"ࠬࡸࡥࡳࡷࡱࠫၻ")), str(bstack11lll1lll1_opy_.bstack11l1l1111l_opy_(self.bstack1111l111ll_opy_)),
                bstack11111l1lll_opy_.get(bstack1ll1lll_opy_ (u"࠭ࡤࡦ࡮ࡤࡽࠬၼ")), str(bstack11111l1lll_opy_.get(bstack1ll1lll_opy_ (u"ࠧࡳࡧࡵࡹࡳ࠳ࡤࡦ࡮ࡤࡽࠬၽ")))
            ]
    def bstack1111l11l11_opy_(self):
        bstack111111l11_opy_ = []
        for spec in self.bstack11l1ll1111_opy_:
            bstack11llll11l_opy_ = [spec]
            bstack11llll11l_opy_ += self.bstack111111ll1l_opy_
            bstack111111l11_opy_.append(bstack11llll11l_opy_)
        self.bstack111111l11_opy_ = bstack111111l11_opy_
        return bstack111111l11_opy_
    def bstack1l1ll1ll_opy_(self):
        try:
            from pytest_bdd import reporting
            self.bstack111111ll11_opy_ = True
            return True
        except Exception as e:
            self.bstack111111ll11_opy_ = False
        return self.bstack111111ll11_opy_
    def bstack1l1l1l11l1_opy_(self):
        bstack1ll1lll_opy_ (u"ࠣࠤࠥࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡊࡩࡹࠦࡴࡩࡧࠣࡧࡴࡻ࡮ࡵࠢࡲࡪࠥࡺࡥࡴࡶࡶࠤࡼ࡯ࡴࡩࡱࡸࡸࠥࡸࡵ࡯ࡰ࡬ࡲ࡬ࠦࡴࡩࡧࡰࠤࡺࡹࡩ࡯ࡩࠣࡴࡾࡺࡥࡴࡶࠪࡷࠥ࠳࠭ࡤࡱ࡯ࡰࡪࡩࡴ࠮ࡱࡱࡰࡾࠦࡦ࡭ࡣࡪ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡖࡪࡺࡵࡳࡰࡶ࠾ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡪࡰࡷ࠾࡚ࠥࡨࡦࠢࡷࡳࡹࡧ࡬ࠡࡰࡸࡱࡧ࡫ࡲࠡࡱࡩࠤࡹ࡫ࡳࡵࡵࠣࡧࡴࡲ࡬ࡦࡥࡷࡩࡩ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦၾ")
        try:
            self.logger.info(bstack1ll1lll_opy_ (u"ࠤࡆࡳࡱࡲࡥࡤࡶ࡬ࡲ࡬ࠦࡴࡦࡵࡷࡷࠥࡻࡳࡪࡰࡪࠤࡵࡿࡴࡦࡵࡷࠤ࠲࠳ࡣࡰ࡮࡯ࡩࡨࡺ࠭ࡰࡰ࡯ࡽࠧၿ"))
            bstack1111l11l1l_opy_ = [bstack1ll1lll_opy_ (u"ࠥࡴࡾࡺࡥࡴࡶࠥႀ"), *self.bstack111111ll1l_opy_, bstack1ll1lll_opy_ (u"ࠦ࠲࠳ࡣࡰ࡮࡯ࡩࡨࡺ࠭ࡰࡰ࡯ࡽࠧႁ")]
            result = subprocess.run(bstack1111l11l1l_opy_, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            if result.returncode != 0:
                self.logger.error(bstack1ll1lll_opy_ (u"ࠧࡋࡲࡳࡱࡵࠤࡼ࡮ࡩ࡭ࡧࠣࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡳ࡭ࠠࡵࡧࡶࡸࡸࡀࠠࡼࡿࠥႂ").format(result.stderr))
                return 0
            test_count = result.stdout.count(bstack1ll1lll_opy_ (u"ࠨ࠼ࡇࡷࡱࡧࡹ࡯࡯࡯ࠢࠥႃ"))
            self.logger.info(bstack1ll1lll_opy_ (u"ࠢࡕࡱࡷࡥࡱࠦࡴࡦࡵࡷࡷࠥࡩ࡯࡭࡮ࡨࡧࡹ࡫ࡤ࠻ࠢࡾࢁࠧႄ").format(test_count))
            return test_count
        except Exception as e:
            self.logger.error(bstack1ll1lll_opy_ (u"ࠣࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤࡼ࡮ࡩ࡭ࡧࠣ࡫ࡪࡺࡴࡪࡰࡪࠤࡹ࡫ࡳࡵࠢࡦࡳࡺࡴࡴ࠻ࠢࡾࢁࠧႅ").format(e))
            return 0
    def bstack11111lll1_opy_(self, bstack1111111lll_opy_, bstack1l11lll11_opy_):
        bstack1l11lll11_opy_[bstack1ll1lll_opy_ (u"ࠩࡆࡓࡓࡌࡉࡈࠩႆ")] = self.bstack1111l111ll_opy_
        multiprocessing.set_start_method(bstack1ll1lll_opy_ (u"ࠪࡷࡵࡧࡷ࡯ࠩႇ"))
        bstack1lll1111l_opy_ = []
        manager = multiprocessing.Manager()
        bstack11111l1111_opy_ = manager.list()
        if bstack1ll1lll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧႈ") in self.bstack1111l111ll_opy_:
            for index, platform in enumerate(self.bstack1111l111ll_opy_[bstack1ll1lll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨႉ")]):
                bstack1lll1111l_opy_.append(multiprocessing.Process(name=str(index),
                                                            target=bstack1111111lll_opy_,
                                                            args=(self.bstack111111ll1l_opy_, bstack1l11lll11_opy_, bstack11111l1111_opy_)))
            bstack1111l1111l_opy_ = len(self.bstack1111l111ll_opy_[bstack1ll1lll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩႊ")])
        else:
            bstack1lll1111l_opy_.append(multiprocessing.Process(name=str(0),
                                                        target=bstack1111111lll_opy_,
                                                        args=(self.bstack111111ll1l_opy_, bstack1l11lll11_opy_, bstack11111l1111_opy_)))
            bstack1111l1111l_opy_ = 1
        i = 0
        for t in bstack1lll1111l_opy_:
            os.environ[bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡐࡍࡃࡗࡊࡔࡘࡍࡠࡋࡑࡈࡊ࡞ࠧႋ")] = str(i)
            if bstack1ll1lll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫႌ") in self.bstack1111l111ll_opy_:
                os.environ[bstack1ll1lll_opy_ (u"ࠩࡆ࡙ࡗࡘࡅࡏࡖࡢࡔࡑࡇࡔࡇࡑࡕࡑࡤࡊࡁࡕࡃႍࠪ")] = json.dumps(self.bstack1111l111ll_opy_[bstack1ll1lll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ႎ")][i % bstack1111l1111l_opy_])
            i += 1
            t.start()
        for t in bstack1lll1111l_opy_:
            t.join()
        return list(bstack11111l1111_opy_)
    @staticmethod
    def bstack111ll11l1_opy_(driver, bstack1111l111l1_opy_, logger, item=None, wait=False):
        item = item or getattr(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤࡺࡥࡴࡶࡢ࡭ࡹ࡫࡭ࠨႏ"), None)
        if item and getattr(item, bstack1ll1lll_opy_ (u"ࠬࡥࡡ࠲࠳ࡼࡣࡹ࡫ࡳࡵࡡࡦࡥࡸ࡫ࠧ႐"), None) and not getattr(item, bstack1ll1lll_opy_ (u"࠭࡟ࡢ࠳࠴ࡽࡤࡹࡴࡰࡲࡢࡨࡴࡴࡥࠨ႑"), False):
            logger.info(
                bstack1ll1lll_opy_ (u"ࠢࡂࡷࡷࡳࡲࡧࡴࡦࠢࡷࡩࡸࡺࠠࡤࡣࡶࡩࠥ࡫ࡸࡦࡥࡸࡸ࡮ࡵ࡮ࠡࡪࡤࡷࠥ࡫࡮ࡥࡧࡧ࠲ࠥࡖࡲࡰࡥࡨࡷࡸ࡯࡮ࡨࠢࡩࡳࡷࠦࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡴࡦࡵࡷ࡭ࡳ࡭ࠠࡪࡵࠣࡹࡳࡪࡥࡳࡹࡤࡽ࠳ࠨ႒"))
            bstack111111lll1_opy_ = item.cls.__name__ if not item.cls is None else None
            bstack1l11l1l1_opy_.bstack11llllll1_opy_(driver, item.name, item.path)
            item._a11y_stop_done = True
            if wait:
                sleep(2)
    def bstack11111ll111_opy_(self):
        bstack1ll1lll_opy_ (u"ࠣࠤࠥࠎࠥࠦࠠࠡࠢࠣࠤࠥࡘࡥࡵࡷࡵࡲࡸࠦࡴࡩࡧࠣࡰ࡮ࡹࡴࠡࡱࡩࠤࡹ࡫ࡳࡵࠢࡩ࡭ࡱ࡫ࡳࠡࡶࡲࠤࡧ࡫ࠠࡦࡺࡨࡧࡺࡺࡥࡥࠢࡥࡽࠥࡶࡡࡳࡵ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡳࡺࡺࡰࡶࡶࠣࡳ࡫ࠦࡰࡺࡶࡨࡷࡹࠦ࠭࠮ࡥࡲࡰࡱ࡫ࡣࡵ࠯ࡲࡲࡱࡿ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࡑࡳࡹ࡫࠺ࠡࡖ࡫ࡩࠥࡸࡥࡨࡧࡻࠤࡵࡧࡴࡵࡧࡵࡲࠥࡻࡳࡦࡦࠣ࡬ࡪࡸࡥࠡࡦࡨࡴࡪࡴࡤࡴࠢࡲࡲࠥࡶࡹࡵࡧࡶࡸࠬࡹࠠࡰࡷࡷࡴࡺࡺࠠࡧࡱࡵࡱࡦࡺࠠࡧࡱࡵࠤࡁࡓ࡯ࡥࡷ࡯ࡩࠥ࠴࠮࠯ࡀࠣࡰ࡮ࡴࡥࡴ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢ႓")
        try:
            bstack1111l11l1l_opy_ = [bstack1ll1lll_opy_ (u"ࠤࡳࡽࡹ࡫ࡳࡵࠤ႔"), *self.bstack111111ll1l_opy_, bstack1ll1lll_opy_ (u"ࠥ࠱࠲ࡩ࡯࡭࡮ࡨࡧࡹ࠳࡯࡯࡮ࡼࠦ႕")]
            result = subprocess.run(bstack1111l11l1l_opy_, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            if result.returncode != 0:
                self.logger.error(bstack1ll1lll_opy_ (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡭࡯࡬ࡦࠢࡦࡳࡱࡲࡥࡤࡶ࡬ࡲ࡬ࠦࡴࡦࡵࡷࡷࠥ࡬ࡩ࡭ࡧ࠽ࠤࢀࢃࠢ႖").format(result.stderr))
                return []
            file_names = set(re.findall(self.bstack111111l111_opy_, result.stdout))
            file_names = sorted(file_names)
            return list(file_names)
        except Exception as e:
            self.logger.error(bstack11111ll1ll_opy_ (u"ࠧࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡࡹ࡫࡭ࡱ࡫ࠠࡤࡱ࡯ࡰࡪࡩࡴࡪࡰࡪࠤࡹ࡫ࡳࡵࠢࡩ࡭ࡱ࡫ࡳ࠻ࠢࡾࡩࢂࠨ႗"))
            return []