# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import os
import json
import logging
logger = logging.getLogger(__name__)
class BrowserStackSdk:
    def get_current_platform():
        bstack1llllll1l1_opy_ = {}
        bstack111lll11l1_opy_ = os.environ.get(bstack1ll1lll_opy_ (u"ࠫࡈ࡛ࡒࡓࡇࡑࡘࡤࡖࡌࡂࡖࡉࡓࡗࡓ࡟ࡅࡃࡗࡅࠬ༕"), bstack1ll1lll_opy_ (u"ࠬ࠭༖"))
        if not bstack111lll11l1_opy_:
            return bstack1llllll1l1_opy_
        try:
            bstack111lll11ll_opy_ = json.loads(bstack111lll11l1_opy_)
            if bstack1ll1lll_opy_ (u"ࠨ࡯ࡴࠤ༗") in bstack111lll11ll_opy_:
                bstack1llllll1l1_opy_[bstack1ll1lll_opy_ (u"ࠢࡰࡵ༘ࠥ")] = bstack111lll11ll_opy_[bstack1ll1lll_opy_ (u"ࠣࡱࡶ༙ࠦ")]
            if bstack1ll1lll_opy_ (u"ࠤࡲࡷࡤࡼࡥࡳࡵ࡬ࡳࡳࠨ༚") in bstack111lll11ll_opy_ or bstack1ll1lll_opy_ (u"ࠥࡳࡸ࡜ࡥࡳࡵ࡬ࡳࡳࠨ༛") in bstack111lll11ll_opy_:
                bstack1llllll1l1_opy_[bstack1ll1lll_opy_ (u"ࠦࡴࡹࡖࡦࡴࡶ࡭ࡴࡴࠢ༜")] = bstack111lll11ll_opy_.get(bstack1ll1lll_opy_ (u"ࠧࡵࡳࡠࡸࡨࡶࡸ࡯࡯࡯ࠤ༝"), bstack111lll11ll_opy_.get(bstack1ll1lll_opy_ (u"ࠨ࡯ࡴࡘࡨࡶࡸ࡯࡯࡯ࠤ༞")))
            if bstack1ll1lll_opy_ (u"ࠢࡣࡴࡲࡻࡸ࡫ࡲࠣ༟") in bstack111lll11ll_opy_ or bstack1ll1lll_opy_ (u"ࠣࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪࠨ༠") in bstack111lll11ll_opy_:
                bstack1llllll1l1_opy_[bstack1ll1lll_opy_ (u"ࠤࡥࡶࡴࡽࡳࡦࡴࡑࡥࡲ࡫ࠢ༡")] = bstack111lll11ll_opy_.get(bstack1ll1lll_opy_ (u"ࠥࡦࡷࡵࡷࡴࡧࡵࠦ༢"), bstack111lll11ll_opy_.get(bstack1ll1lll_opy_ (u"ࠦࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠤ༣")))
            if bstack1ll1lll_opy_ (u"ࠧࡨࡲࡰࡹࡶࡩࡷࡥࡶࡦࡴࡶ࡭ࡴࡴࠢ༤") in bstack111lll11ll_opy_ or bstack1ll1lll_opy_ (u"ࠨࡢࡳࡱࡺࡷࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠢ༥") in bstack111lll11ll_opy_:
                bstack1llllll1l1_opy_[bstack1ll1lll_opy_ (u"ࠢࡣࡴࡲࡻࡸ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠣ༦")] = bstack111lll11ll_opy_.get(bstack1ll1lll_opy_ (u"ࠣࡤࡵࡳࡼࡹࡥࡳࡡࡹࡩࡷࡹࡩࡰࡰࠥ༧"), bstack111lll11ll_opy_.get(bstack1ll1lll_opy_ (u"ࠤࡥࡶࡴࡽࡳࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠥ༨")))
            if bstack1ll1lll_opy_ (u"ࠥࡨࡪࡼࡩࡤࡧࠥ༩") in bstack111lll11ll_opy_ or bstack1ll1lll_opy_ (u"ࠦࡩ࡫ࡶࡪࡥࡨࡒࡦࡳࡥࠣ༪") in bstack111lll11ll_opy_:
                bstack1llllll1l1_opy_[bstack1ll1lll_opy_ (u"ࠧࡪࡥࡷ࡫ࡦࡩࡓࡧ࡭ࡦࠤ༫")] = bstack111lll11ll_opy_.get(bstack1ll1lll_opy_ (u"ࠨࡤࡦࡸ࡬ࡧࡪࠨ༬"), bstack111lll11ll_opy_.get(bstack1ll1lll_opy_ (u"ࠢࡥࡧࡹ࡭ࡨ࡫ࡎࡢ࡯ࡨࠦ༭")))
            if bstack1ll1lll_opy_ (u"ࠣࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࠥ༮") in bstack111lll11ll_opy_ or bstack1ll1lll_opy_ (u"ࠤࡳࡰࡦࡺࡦࡰࡴࡰࡒࡦࡳࡥࠣ༯") in bstack111lll11ll_opy_:
                bstack1llllll1l1_opy_[bstack1ll1lll_opy_ (u"ࠥࡴࡱࡧࡴࡧࡱࡵࡱࡓࡧ࡭ࡦࠤ༰")] = bstack111lll11ll_opy_.get(bstack1ll1lll_opy_ (u"ࠦࡵࡲࡡࡵࡨࡲࡶࡲࠨ༱"), bstack111lll11ll_opy_.get(bstack1ll1lll_opy_ (u"ࠧࡶ࡬ࡢࡶࡩࡳࡷࡳࡎࡢ࡯ࡨࠦ༲")))
            if bstack1ll1lll_opy_ (u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡠࡸࡨࡶࡸ࡯࡯࡯ࠤ༳") in bstack111lll11ll_opy_ or bstack1ll1lll_opy_ (u"ࠢࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡘࡨࡶࡸ࡯࡯࡯ࠤ༴") in bstack111lll11ll_opy_:
                bstack1llllll1l1_opy_[bstack1ll1lll_opy_ (u"ࠣࡲ࡯ࡥࡹ࡬࡯ࡳ࡯࡙ࡩࡷࡹࡩࡰࡰ༵ࠥ")] = bstack111lll11ll_opy_.get(bstack1ll1lll_opy_ (u"ࠤࡳࡰࡦࡺࡦࡰࡴࡰࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧ༶"), bstack111lll11ll_opy_.get(bstack1ll1lll_opy_ (u"ࠥࡴࡱࡧࡴࡧࡱࡵࡱ࡛࡫ࡲࡴ࡫ࡲࡲ༷ࠧ")))
            if bstack1ll1lll_opy_ (u"ࠦࡨࡻࡳࡵࡱࡰ࡚ࡦࡸࡩࡢࡤ࡯ࡩࡸࠨ༸") in bstack111lll11ll_opy_:
                bstack1llllll1l1_opy_[bstack1ll1lll_opy_ (u"ࠧࡩࡵࡴࡶࡲࡱ࡛ࡧࡲࡪࡣࡥࡰࡪࡹ༹ࠢ")] = bstack111lll11ll_opy_[bstack1ll1lll_opy_ (u"ࠨࡣࡶࡵࡷࡳࡲ࡜ࡡࡳ࡫ࡤࡦࡱ࡫ࡳࠣ༺")]
        except Exception as error:
            logger.error(bstack1ll1lll_opy_ (u"ࠢࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣࡻ࡭࡯࡬ࡦࠢࡪࡩࡹࡺࡩ࡯ࡩࠣࡧࡺࡸࡲࡦࡰࡷࠤࡵࡲࡡࡵࡨࡲࡶࡲࠦࡤࡢࡶࡤ࠾ࠥࠨ༻") +  str(error))
        return bstack1llllll1l1_opy_