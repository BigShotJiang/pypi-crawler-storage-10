# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import threading
import os
import logging
from uuid import uuid4
from bstack_utils.bstack111ll1l1ll_opy_ import bstack111ll1l1l1_opy_, bstack111l1ll1l1_opy_
from bstack_utils.bstack111ll1llll_opy_ import bstack11l11ll1l1_opy_
from bstack_utils.helper import bstack11l1l1lll_opy_, bstack1l11l1llll_opy_, Result
from bstack_utils.bstack111ll1ll11_opy_ import bstack1l111l111l_opy_
from bstack_utils.capture import bstack111lll1111_opy_
from bstack_utils.constants import *
logger = logging.getLogger(__name__)
class bstack1lllll1111_opy_:
    def __init__(self):
        self.bstack111ll11ll1_opy_ = bstack111lll1111_opy_(self.bstack111ll1l11l_opy_)
        self.tests = {}
    @staticmethod
    def bstack111ll1l11l_opy_(log):
        if not (log[bstack1ll1lll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩ༼")] and log[bstack1ll1lll_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪ༽")].strip()):
            return
        active = bstack11l11ll1l1_opy_.bstack111ll111l1_opy_()
        log = {
            bstack1ll1lll_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩ༾"): log[bstack1ll1lll_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪ༿")],
            bstack1ll1lll_opy_ (u"ࠬࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨཀ"): bstack1l11l1llll_opy_(),
            bstack1ll1lll_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧཁ"): log[bstack1ll1lll_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨག")],
        }
        if active:
            if active[bstack1ll1lll_opy_ (u"ࠨࡶࡼࡴࡪ࠭གྷ")] == bstack1ll1lll_opy_ (u"ࠩ࡫ࡳࡴࡱࠧང"):
                log[bstack1ll1lll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪཅ")] = active[bstack1ll1lll_opy_ (u"ࠫ࡭ࡵ࡯࡬ࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫཆ")]
            elif active[bstack1ll1lll_opy_ (u"ࠬࡺࡹࡱࡧࠪཇ")] == bstack1ll1lll_opy_ (u"࠭ࡴࡦࡵࡷࠫ཈"):
                log[bstack1ll1lll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧཉ")] = active[bstack1ll1lll_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨཊ")]
        bstack1l111l111l_opy_.bstack1lll11l1_opy_([log])
    def start_test(self, attrs):
        test_uuid = uuid4().__str__()
        self.tests[test_uuid] = {}
        self.bstack111ll11ll1_opy_.start()
        driver = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡕࡨࡷࡸ࡯࡯࡯ࡆࡵ࡭ࡻ࡫ࡲࠨཋ"), None)
        bstack111ll1l1ll_opy_ = bstack111l1ll1l1_opy_(
            name=attrs.scenario.name,
            uuid=test_uuid,
            started_at=bstack1l11l1llll_opy_(),
            file_path=attrs.feature.filename,
            result=bstack1ll1lll_opy_ (u"ࠥࡴࡪࡴࡤࡪࡰࡪࠦཌ"),
            framework=bstack1ll1lll_opy_ (u"ࠫࡇ࡫ࡨࡢࡸࡨࠫཌྷ"),
            scope=[attrs.feature.name],
            bstack111ll1ll1l_opy_=bstack1l111l111l_opy_.bstack111ll11111_opy_(driver) if driver and driver.session_id else {},
            meta={},
            tags=attrs.scenario.tags
        )
        self.tests[test_uuid][bstack1ll1lll_opy_ (u"ࠬࡺࡥࡴࡶࡢࡨࡦࡺࡡࠨཎ")] = bstack111ll1l1ll_opy_
        threading.current_thread().current_test_uuid = test_uuid
        bstack1l111l111l_opy_.bstack111l1llll1_opy_(bstack1ll1lll_opy_ (u"࠭ࡔࡦࡵࡷࡖࡺࡴࡓࡵࡣࡵࡸࡪࡪࠧཏ"), bstack111ll1l1ll_opy_)
    def end_test(self, attrs):
        bstack111ll11lll_opy_ = {
            bstack1ll1lll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧཐ"): attrs.feature.name,
            bstack1ll1lll_opy_ (u"ࠣࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠨད"): attrs.feature.description
        }
        current_test_uuid = threading.current_thread().current_test_uuid
        bstack111ll1l1ll_opy_ = self.tests[current_test_uuid][bstack1ll1lll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡥࡣࡷࡥࠬདྷ")]
        meta = {
            bstack1ll1lll_opy_ (u"ࠥࡪࡪࡧࡴࡶࡴࡨࠦན"): bstack111ll11lll_opy_,
            bstack1ll1lll_opy_ (u"ࠦࡸࡺࡥࡱࡵࠥཔ"): bstack111ll1l1ll_opy_.meta.get(bstack1ll1lll_opy_ (u"ࠬࡹࡴࡦࡲࡶࠫཕ"), []),
            bstack1ll1lll_opy_ (u"ࠨࡳࡤࡧࡱࡥࡷ࡯࡯ࠣབ"): {
                bstack1ll1lll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧབྷ"): attrs.feature.scenarios[0].name if len(attrs.feature.scenarios) else None
            }
        }
        bstack111ll1l1ll_opy_.bstack111ll1111l_opy_(meta)
        bstack111ll1l1ll_opy_.bstack111ll11l1l_opy_(bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠨࡥࡸࡶࡷ࡫࡮ࡵࡡࡷࡩࡸࡺ࡟ࡩࡱࡲ࡯ࡸ࠭མ"), []))
        bstack111l1ll11l_opy_, exception = self._111lll111l_opy_(attrs)
        bstack111l1lll1l_opy_ = Result(result=attrs.status.name, exception=exception, bstack111l1lllll_opy_=[bstack111l1ll11l_opy_])
        self.tests[threading.current_thread().current_test_uuid][bstack1ll1lll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡥࡣࡷࡥࠬཙ")].stop(time=bstack1l11l1llll_opy_(), duration=int(attrs.duration)*1000, result=bstack111l1lll1l_opy_)
        bstack1l111l111l_opy_.bstack111l1llll1_opy_(bstack1ll1lll_opy_ (u"ࠪࡘࡪࡹࡴࡓࡷࡱࡊ࡮ࡴࡩࡴࡪࡨࡨࠬཚ"), self.tests[threading.current_thread().current_test_uuid][bstack1ll1lll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡧࡥࡹࡧࠧཛ")])
    def bstack1l111ll1l_opy_(self, attrs):
        bstack111l1ll1ll_opy_ = {
            bstack1ll1lll_opy_ (u"ࠬ࡯ࡤࠨཛྷ"): uuid4().__str__(),
            bstack1ll1lll_opy_ (u"࠭࡫ࡦࡻࡺࡳࡷࡪࠧཝ"): attrs.keyword,
            bstack1ll1lll_opy_ (u"ࠧࡴࡶࡨࡴࡤࡧࡲࡨࡷࡰࡩࡳࡺࠧཞ"): [],
            bstack1ll1lll_opy_ (u"ࠨࡶࡨࡼࡹ࠭ཟ"): attrs.name,
            bstack1ll1lll_opy_ (u"ࠩࡶࡸࡦࡸࡴࡦࡦࡢࡥࡹ࠭འ"): bstack1l11l1llll_opy_(),
            bstack1ll1lll_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪཡ"): bstack1ll1lll_opy_ (u"ࠫࡵ࡫࡮ࡥ࡫ࡱ࡫ࠬར"),
            bstack1ll1lll_opy_ (u"ࠬࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠪལ"): bstack1ll1lll_opy_ (u"࠭ࠧཤ")
        }
        self.tests[threading.current_thread().current_test_uuid][bstack1ll1lll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡪࡡࡵࡣࠪཥ")].add_step(bstack111l1ll1ll_opy_)
        threading.current_thread().current_step_uuid = bstack111l1ll1ll_opy_[bstack1ll1lll_opy_ (u"ࠨ࡫ࡧࠫས")]
    def bstack111lll1l1_opy_(self, attrs):
        current_test_id = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࡢࡸࡪࡹࡴࡠࡷࡸ࡭ࡩ࠭ཧ"), None)
        current_step_uuid = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣࡸࡺࡥࡱࡡࡸࡹ࡮ࡪࠧཨ"), None)
        bstack111l1ll11l_opy_, exception = self._111lll111l_opy_(attrs)
        bstack111l1lll1l_opy_ = Result(result=attrs.status.name, exception=exception, bstack111l1lllll_opy_=[bstack111l1ll11l_opy_])
        self.tests[current_test_id][bstack1ll1lll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡧࡥࡹࡧࠧཀྵ")].bstack111ll111ll_opy_(current_step_uuid, duration=int(attrs.duration)*1000, result=bstack111l1lll1l_opy_)
        threading.current_thread().current_step_uuid = None
    def bstack1llll11111_opy_(self, name, attrs):
        try:
            bstack111ll1l111_opy_ = uuid4().__str__()
            self.tests[bstack111ll1l111_opy_] = {}
            self.bstack111ll11ll1_opy_.start()
            scopes = []
            driver = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯ࡘ࡫ࡳࡴ࡫ࡲࡲࡉࡸࡩࡷࡧࡵࠫཪ"), None)
            current_thread = threading.current_thread()
            if not hasattr(current_thread, bstack1ll1lll_opy_ (u"࠭ࡣࡶࡴࡵࡩࡳࡺ࡟ࡵࡧࡶࡸࡤ࡮࡯ࡰ࡭ࡶࠫཫ")):
                current_thread.current_test_hooks = []
            current_thread.current_test_hooks.append(bstack111ll1l111_opy_)
            if name in [bstack1ll1lll_opy_ (u"ࠢࡣࡧࡩࡳࡷ࡫࡟ࡢ࡮࡯ࠦཬ"), bstack1ll1lll_opy_ (u"ࠣࡣࡩࡸࡪࡸ࡟ࡢ࡮࡯ࠦ཭")]:
                file_path = os.path.join(attrs.config.base_dir, attrs.config.environment_file)
                scopes = [attrs.config.environment_file]
            elif name in [bstack1ll1lll_opy_ (u"ࠤࡥࡩ࡫ࡵࡲࡦࡡࡩࡩࡦࡺࡵࡳࡧࠥ཮"), bstack1ll1lll_opy_ (u"ࠥࡥ࡫ࡺࡥࡳࡡࡩࡩࡦࡺࡵࡳࡧࠥ཯")]:
                file_path = attrs.filename
                scopes = [attrs.name]
            else:
                file_path = attrs.filename
                if hasattr(attrs, bstack1ll1lll_opy_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࠬ཰")):
                    scopes =  [attrs.feature.name]
            hook_data = bstack111ll1l1l1_opy_(
                name=name,
                uuid=bstack111ll1l111_opy_,
                started_at=bstack1l11l1llll_opy_(),
                file_path=file_path,
                framework=bstack1ll1lll_opy_ (u"ࠧࡈࡥࡩࡣࡹࡩཱࠧ"),
                bstack111ll1ll1l_opy_=bstack1l111l111l_opy_.bstack111ll11111_opy_(driver) if driver and driver.session_id else {},
                scope=scopes,
                result=bstack1ll1lll_opy_ (u"ࠨࡰࡦࡰࡧ࡭ࡳ࡭ིࠢ"),
                hook_type=name
            )
            self.tests[bstack111ll1l111_opy_][bstack1ll1lll_opy_ (u"ࠢࡵࡧࡶࡸࡤࡪࡡࡵࡣཱིࠥ")] = hook_data
            current_test_id = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠣࡥࡸࡶࡷ࡫࡮ࡵࡡࡷࡩࡸࡺ࡟ࡶࡷ࡬ࡨུࠧ"), None)
            if current_test_id:
                hook_data.bstack111ll11l11_opy_(current_test_id)
            if name == bstack1ll1lll_opy_ (u"ࠤࡥࡩ࡫ࡵࡲࡦࡡࡤࡰࡱࠨཱུ"):
                threading.current_thread().before_all_hook_uuid = bstack111ll1l111_opy_
            threading.current_thread().current_hook_uuid = bstack111ll1l111_opy_
            bstack1l111l111l_opy_.bstack111l1llll1_opy_(bstack1ll1lll_opy_ (u"ࠥࡌࡴࡵ࡫ࡓࡷࡱࡗࡹࡧࡲࡵࡧࡧࠦྲྀ"), hook_data)
        except Exception as e:
            logger.debug(bstack1ll1lll_opy_ (u"ࠦࡊࡸࡲࡰࡴࠣࡳࡨࡩࡵࡳࡴࡨࡨࠥ࡯࡮ࠡࡵࡷࡥࡷࡺࠠࡩࡱࡲ࡯ࠥ࡫ࡶࡦࡰࡷࡷ࠱ࠦࡨࡰࡱ࡮ࠤࡳࡧ࡭ࡦ࠼ࠣࠩࡸ࠲ࠠࡦࡴࡵࡳࡷࡀࠠࠦࡵࠥཷ"), name, e)
    def bstack1l1lll1111_opy_(self, attrs):
        bstack111l1lll11_opy_ = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡥࡨࡰࡱ࡮ࡣࡺࡻࡩࡥࠩླྀ"), None)
        hook_data = self.tests[bstack111l1lll11_opy_][bstack1ll1lll_opy_ (u"࠭ࡴࡦࡵࡷࡣࡩࡧࡴࡢࠩཹ")]
        status = bstack1ll1lll_opy_ (u"ࠢࡱࡣࡶࡷࡪࡪེࠢ")
        exception = None
        bstack111l1ll11l_opy_ = None
        if hook_data.name == bstack1ll1lll_opy_ (u"ࠣࡣࡩࡸࡪࡸ࡟ࡢ࡮࡯ཻࠦ"):
            self.bstack111ll11ll1_opy_.reset()
            bstack111ll1lll1_opy_ = self.tests[bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠩࡥࡩ࡫ࡵࡲࡦࡡࡤࡰࡱࡥࡨࡰࡱ࡮ࡣࡺࡻࡩࡥོࠩ"), None)][bstack1ll1lll_opy_ (u"ࠪࡸࡪࡹࡴࡠࡦࡤࡸࡦཽ࠭")].result.result
            if bstack111ll1lll1_opy_ == bstack1ll1lll_opy_ (u"ࠦ࡫ࡧࡩ࡭ࡧࡧࠦཾ"):
                if attrs.hook_failures == 1:
                    status = bstack1ll1lll_opy_ (u"ࠧࡶࡡࡴࡵࡨࡨࠧཿ")
                elif attrs.hook_failures == 2:
                    status = bstack1ll1lll_opy_ (u"ࠨࡦࡢ࡫࡯ࡩࡩࠨྀ")
            elif attrs.aborted:
                status = bstack1ll1lll_opy_ (u"ࠢࡧࡣ࡬ࡰࡪࡪཱྀࠢ")
            threading.current_thread().before_all_hook_uuid = None
        else:
            if hook_data.name == bstack1ll1lll_opy_ (u"ࠨࡤࡨࡪࡴࡸࡥࡠࡣ࡯ࡰࠬྂ") and attrs.hook_failures == 1:
                status = bstack1ll1lll_opy_ (u"ࠤࡩࡥ࡮ࡲࡥࡥࠤྃ")
            elif hasattr(attrs, bstack1ll1lll_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࡡࡰࡩࡸࡹࡡࡨࡧ྄ࠪ")) and attrs.error_message:
                status = bstack1ll1lll_opy_ (u"ࠦ࡫ࡧࡩ࡭ࡧࡧࠦ྅")
            bstack111l1ll11l_opy_, exception = self._111lll111l_opy_(attrs)
        bstack111l1lll1l_opy_ = Result(result=status, exception=exception, bstack111l1lllll_opy_=[bstack111l1ll11l_opy_])
        hook_data.stop(time=bstack1l11l1llll_opy_(), duration=0, result=bstack111l1lll1l_opy_)
        bstack1l111l111l_opy_.bstack111l1llll1_opy_(bstack1ll1lll_opy_ (u"ࠬࡎ࡯ࡰ࡭ࡕࡹࡳࡌࡩ࡯࡫ࡶ࡬ࡪࡪࠧ྆"), self.tests[bstack111l1lll11_opy_][bstack1ll1lll_opy_ (u"࠭ࡴࡦࡵࡷࡣࡩࡧࡴࡢࠩ྇")])
        threading.current_thread().current_hook_uuid = None
    def _111lll111l_opy_(self, attrs):
        try:
            import traceback
            bstack11l1111l1_opy_ = traceback.format_tb(attrs.exc_traceback)
            bstack111l1ll11l_opy_ = bstack11l1111l1_opy_[-1] if bstack11l1111l1_opy_ else None
            exception = attrs.exception
        except Exception:
            logger.debug(bstack1ll1lll_opy_ (u"ࠢࡆࡴࡵࡳࡷࠦ࡯ࡤࡥࡸࡶࡷ࡫ࡤࠡࡹ࡫࡭ࡱ࡫ࠠࡨࡧࡷࡸ࡮ࡴࡧࠡࡥࡸࡷࡹࡵ࡭ࠡࡶࡵࡥࡨ࡫ࡢࡢࡥ࡮ࠦྈ"))
            bstack111l1ll11l_opy_ = None
            exception = None
        return bstack111l1ll11l_opy_, exception