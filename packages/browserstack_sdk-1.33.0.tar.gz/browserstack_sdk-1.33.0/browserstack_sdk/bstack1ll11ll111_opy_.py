# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import json
import multiprocessing
import os
from bstack_utils.config import Config
class bstack1l1l11l1_opy_():
  def __init__(self, args, logger, bstack1111l111ll_opy_, bstack1111l1l111_opy_, bstack1111111l1l_opy_):
    self.args = args
    self.logger = logger
    self.bstack1111l111ll_opy_ = bstack1111l111ll_opy_
    self.bstack1111l1l111_opy_ = bstack1111l1l111_opy_
    self.bstack1111111l1l_opy_ = bstack1111111l1l_opy_
  def bstack11111lll1_opy_(self, bstack1111111lll_opy_, bstack1l11lll11_opy_, bstack1111111ll1_opy_=False):
    bstack1lll1111l_opy_ = []
    manager = multiprocessing.Manager()
    bstack11111l1111_opy_ = manager.list()
    bstack11l1l11l_opy_ = Config.bstack1l1l111l_opy_()
    if bstack1111111ll1_opy_:
      for index, platform in enumerate(self.bstack1111l111ll_opy_[bstack1ll1lll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩ႘")]):
        if index == 0:
          bstack1l11lll11_opy_[bstack1ll1lll_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪ႙")] = self.args
        bstack1lll1111l_opy_.append(multiprocessing.Process(name=str(index),
                                                    target=bstack1111111lll_opy_,
                                                    args=(bstack1l11lll11_opy_, bstack11111l1111_opy_)))
    else:
      for index, platform in enumerate(self.bstack1111l111ll_opy_[bstack1ll1lll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫႚ")]):
        bstack1lll1111l_opy_.append(multiprocessing.Process(name=str(index),
                                                    target=bstack1111111lll_opy_,
                                                    args=(bstack1l11lll11_opy_, bstack11111l1111_opy_)))
    i = 0
    for t in bstack1lll1111l_opy_:
      try:
        if bstack11l1l11l_opy_.get_property(bstack1ll1lll_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡡࡶࡩࡸࡹࡩࡰࡰࠪႛ")):
          os.environ[bstack1ll1lll_opy_ (u"ࠪࡇ࡚ࡘࡒࡆࡐࡗࡣࡕࡒࡁࡕࡈࡒࡖࡒࡥࡄࡂࡖࡄࠫႜ")] = json.dumps(self.bstack1111l111ll_opy_[bstack1ll1lll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧႝ")][i % self.bstack1111111l1l_opy_])
      except Exception as e:
        self.logger.debug(bstack1ll1lll_opy_ (u"ࠧࡋࡲࡳࡱࡵࠤࡼ࡮ࡩ࡭ࡧࠣࡷࡹࡵࡲࡪࡰࡪࠤࡨࡻࡲࡳࡧࡱࡸࠥࡶ࡬ࡢࡶࡩࡳࡷࡳࠠࡥࡧࡷࡥ࡮ࡲࡳ࠻ࠢࡾࢁࠧ႞").format(str(e)))
      i += 1
      t.start()
    for t in bstack1lll1111l_opy_:
      t.join()
    return list(bstack11111l1111_opy_)