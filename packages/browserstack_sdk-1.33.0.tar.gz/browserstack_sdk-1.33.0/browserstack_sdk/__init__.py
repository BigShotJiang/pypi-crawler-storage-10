# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import atexit
import shlex
import signal
import yaml
import socket
import datetime
import string
import random
import collections.abc
import traceback
import copy
import threading
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError
import json
from packaging import version
from browserstack.local import Local
from urllib.parse import urlparse
from dotenv import load_dotenv
from browserstack_sdk.bstack1ll11ll111_opy_ import bstack1l1l11l1_opy_
from browserstack_sdk.bstack1l11l1l111_opy_ import *
import time
import requests
from bstack_utils.constants import EVENTS, STAGE, bstack1l1l1111l_opy_
from bstack_utils.messages import bstack1l1ll1l1_opy_, bstack1lll111ll1_opy_, bstack1ll1l1l1_opy_, bstack111l11111_opy_, bstack1l1llll111_opy_, bstack11ll1ll1l_opy_
from bstack_utils.measure import measure
from bstack_utils.bstack1ll1ll1111_opy_ import get_logger
from bstack_utils.helper import bstack1l111l1111_opy_
from browserstack_sdk.bstack11lll11111_opy_ import bstack1llll1l1ll_opy_
logger = get_logger(__name__)
def bstack1l111111l1_opy_():
  global CONFIG
  headers = {
        bstack1ll1lll_opy_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡹࡿࡰࡦࠩࡶ"): bstack1ll1lll_opy_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱࡭ࡷࡴࡴࠧࡷ"),
      }
  proxies = bstack1l111l1111_opy_(CONFIG, bstack1l1l1111l_opy_)
  try:
    response = requests.get(bstack1l1l1111l_opy_, headers=headers, proxies=proxies, timeout=5)
    if response.json():
      bstack1l1ll1lll1_opy_ = response.json()[bstack1ll1lll_opy_ (u"ࠬ࡮ࡵࡣࡵࠪࡸ")]
      logger.debug(bstack1l1ll1l1_opy_.format(response.json()))
      return bstack1l1ll1lll1_opy_
    else:
      logger.debug(bstack1lll111ll1_opy_.format(bstack1ll1lll_opy_ (u"ࠨࡒࡦࡵࡳࡳࡳࡹࡥࠡࡌࡖࡓࡓࠦࡰࡢࡴࡶࡩࠥ࡫ࡲࡳࡱࡵࠤࠧࡹ")))
  except Exception as e:
    logger.debug(bstack1lll111ll1_opy_.format(e))
def bstack1111ll11_opy_(hub_url):
  global CONFIG
  url = bstack1ll1lll_opy_ (u"ࠢࡩࡶࡷࡴࡸࡀ࠯࠰ࠤࡺ")+  hub_url + bstack1ll1lll_opy_ (u"ࠣ࠱ࡦ࡬ࡪࡩ࡫ࠣࡻ")
  headers = {
        bstack1ll1lll_opy_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡸࡾࡶࡥࠨࡼ"): bstack1ll1lll_opy_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳ࠭ࡽ"),
      }
  proxies = bstack1l111l1111_opy_(CONFIG, url)
  try:
    start_time = time.perf_counter()
    requests.get(url, headers=headers, proxies=proxies, timeout=5)
    latency = time.perf_counter() - start_time
    logger.debug(bstack1ll1l1l1_opy_.format(hub_url, latency))
    return dict(hub_url=hub_url, latency=latency)
  except Exception as e:
    logger.debug(bstack111l11111_opy_.format(hub_url, e))
@measure(event_name=EVENTS.bstack11ll1l111_opy_, stage=STAGE.bstack111lll1l11_opy_)
def bstack111llll1_opy_():
  try:
    global bstack111ll111_opy_
    global CONFIG
    if bstack1ll1lll_opy_ (u"ࠫ࡭ࡻࡢࡓࡧࡪ࡭ࡴࡴࠧࡾ") in CONFIG and CONFIG[bstack1ll1lll_opy_ (u"ࠬ࡮ࡵࡣࡔࡨ࡫࡮ࡵ࡮ࠨࡿ")]:
      from bstack_utils.constants import bstack1l11l1lll_opy_
      bstack1ll11l11ll_opy_ = CONFIG[bstack1ll1lll_opy_ (u"࠭ࡨࡶࡤࡕࡩ࡬࡯࡯࡯ࠩࢀ")]
      if bstack1ll11l11ll_opy_ in bstack1l11l1lll_opy_:
        bstack111ll111_opy_ = bstack1l11l1lll_opy_[bstack1ll11l11ll_opy_]
        logger.debug(bstack1l1llll111_opy_.format(bstack111ll111_opy_))
        return
      else:
        logger.debug(bstack1ll1lll_opy_ (u"ࠢࡉࡷࡥࠤࡰ࡫ࡹࠡࠩࡾࢁࠬࠦ࡮ࡰࡶࠣࡪࡴࡻ࡮ࡥࠢ࡬ࡲࠥࡎࡕࡃࡡࡘࡖࡑࡥࡍࡂࡒ࠯ࠤ࡫ࡧ࡬࡭࡫ࡱ࡫ࠥࡨࡡࡤ࡭ࠣࡸࡴࠦ࡯ࡱࡶ࡬ࡱࡦࡲࠠࡩࡷࡥࠤࡩ࡫ࡴࡦࡥࡷ࡭ࡴࡴࠢࢁ").format(bstack1ll11l11ll_opy_))
    bstack1l1ll1lll1_opy_ = bstack1l111111l1_opy_()
    bstack11lll11l_opy_ = []
    results = []
    for bstack11l11l11l_opy_ in bstack1l1ll1lll1_opy_:
      bstack11lll11l_opy_.append(bstack1llll1l1ll_opy_(target=bstack1111ll11_opy_,args=(bstack11l11l11l_opy_,)))
    for t in bstack11lll11l_opy_:
      t.start()
    for t in bstack11lll11l_opy_:
      results.append(t.join())
    bstack1lll11lll_opy_ = {}
    for item in results:
      hub_url = item[bstack1ll1lll_opy_ (u"ࠨࡪࡸࡦࡤࡻࡲ࡭ࠩࢂ")]
      latency = item[bstack1ll1lll_opy_ (u"ࠩ࡯ࡥࡹ࡫࡮ࡤࡻࠪࢃ")]
      bstack1lll11lll_opy_[hub_url] = latency
    bstack1111111ll_opy_ = min(bstack1lll11lll_opy_, key= lambda x: bstack1lll11lll_opy_[x])
    bstack111ll111_opy_ = bstack1111111ll_opy_
    logger.debug(bstack1l1llll111_opy_.format(bstack1111111ll_opy_))
  except Exception as e:
    logger.debug(bstack11ll1ll1l_opy_.format(e))
from browserstack_sdk.bstack1lll1ll111_opy_ import *
from browserstack_sdk.bstack11lll11111_opy_ import *
from browserstack_sdk.bstack1lllll1111_opy_ import *
import logging
import requests
from bstack_utils.constants import *
from bstack_utils.bstack1ll1ll1111_opy_ import get_logger
from bstack_utils.measure import measure
logger = get_logger(__name__)
@measure(event_name=EVENTS.bstack11lllll1_opy_, stage=STAGE.bstack111lll1l11_opy_)
def bstack111lllll11_opy_():
    global bstack111ll111_opy_
    try:
        bstack111lllll1l_opy_ = bstack11l1l1l1_opy_()
        bstack111l1l111_opy_(bstack111lllll1l_opy_)
        hub_url = bstack111lllll1l_opy_.get(bstack1ll1lll_opy_ (u"ࠥࡹࡷࡲࠢࢄ"), bstack1ll1lll_opy_ (u"ࠦࠧࢅ"))
        if hub_url.endswith(bstack1ll1lll_opy_ (u"ࠬ࠵ࡷࡥ࠱࡫ࡹࡧ࠭ࢆ")):
            hub_url = hub_url.rsplit(bstack1ll1lll_opy_ (u"࠭࠯ࡸࡦ࠲࡬ࡺࡨࠧࢇ"), 1)[0]
        if hub_url.startswith(bstack1ll1lll_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨ࢈")):
            hub_url = hub_url[7:]
        elif hub_url.startswith(bstack1ll1lll_opy_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪࢉ")):
            hub_url = hub_url[8:]
        bstack111ll111_opy_ = hub_url
    except Exception as e:
        raise RuntimeError(e)
def bstack11l1l1l1_opy_():
    global CONFIG
    bstack111llll11_opy_ = CONFIG.get(bstack1ll1lll_opy_ (u"ࠩࡷࡹࡷࡨ࡯ࡔࡥࡤࡰࡪࡕࡰࡵ࡫ࡲࡲࡸ࠭ࢊ"), {}).get(bstack1ll1lll_opy_ (u"ࠪ࡫ࡷ࡯ࡤࡏࡣࡰࡩࠬࢋ"), bstack1ll1lll_opy_ (u"ࠫࡓࡕ࡟ࡈࡔࡌࡈࡤࡔࡁࡎࡇࡢࡔࡆ࡙ࡓࡆࡆࠪࢌ"))
    if not isinstance(bstack111llll11_opy_, str):
        raise ValueError(bstack1ll1lll_opy_ (u"ࠧࡇࡔࡔࠢ࠽ࠤࡌࡸࡩࡥࠢࡱࡥࡲ࡫ࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡺࡦࡲࡩࡥࠢࡶࡸࡷ࡯࡮ࡨࠤࢍ"))
    try:
        bstack111lllll1l_opy_ = bstack1ll1l11l_opy_(bstack111llll11_opy_)
        return bstack111lllll1l_opy_
    except Exception as e:
        logger.error(bstack1ll1lll_opy_ (u"ࠨࡁࡕࡕࠣ࠾ࠥࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡨࡧࡷࡸ࡮ࡴࡧࠡࡩࡵ࡭ࡩࠦࡤࡦࡶࡤ࡭ࡱࡹࠠ࠻ࠢࡾࢁࠧࢎ").format(str(e)))
        return {}
def bstack1ll1l11l_opy_(bstack111llll11_opy_):
    global CONFIG
    try:
        if not CONFIG[bstack1ll1lll_opy_ (u"ࠧࡶࡵࡨࡶࡓࡧ࡭ࡦࠩ࢏")] or not CONFIG[bstack1ll1lll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡌࡧࡼࠫ࢐")]:
            raise ValueError(bstack1ll1lll_opy_ (u"ࠤࡐ࡭ࡸࡹࡩ࡯ࡩࠣࡆࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࠢࡸࡷࡪࡸ࡮ࡢ࡯ࡨࠤࡴࡸࠠࡢࡥࡦࡩࡸࡹࠠ࡬ࡧࡼࠦ࢑"))
        url = bstack11l1ll11ll_opy_ + bstack111llll11_opy_
        auth = (CONFIG[bstack1ll1lll_opy_ (u"ࠪࡹࡸ࡫ࡲࡏࡣࡰࡩࠬ࢒")], CONFIG[bstack1ll1lll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶࡏࡪࡿࠧ࢓")])
        response = requests.get(url, auth=auth)
        if response.status_code == 200 and response.text:
            bstack11l1lll1ll_opy_ = json.loads(response.text)
            return bstack11l1lll1ll_opy_
    except ValueError as ve:
        logger.error(bstack1ll1lll_opy_ (u"ࠧࡇࡔࡔࠢ࠽ࠤࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡦࡦࡶࡦ࡬࡮ࡴࡧࠡࡩࡵ࡭ࡩࠦࡤࡦࡶࡤ࡭ࡱࡹࠠ࠻ࠢࡾࢁࠧ࢔").format(str(ve)))
        raise ValueError(ve)
    except Exception as e:
        logger.error(bstack1ll1lll_opy_ (u"ࠨࡁࡕࡕࠣ࠾ࠥࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡧࡧࡷࡧ࡭࡯࡮ࡨࠢࡪࡶ࡮ࡪࠠࡥࡧࡷࡥ࡮ࡲࡳࠡ࠼ࠣࡿࢂࠨ࢕").format(str(e)))
        raise RuntimeError(e)
    return {}
def bstack111l1l111_opy_(bstack1lllll1l11_opy_):
    global CONFIG
    if bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࠫ࢖") not in CONFIG or str(CONFIG[bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡌࡰࡥࡤࡰࠬࢗ")]).lower() == bstack1ll1lll_opy_ (u"ࠩࡩࡥࡱࡹࡥࠨ࢘"):
        CONFIG[bstack1ll1lll_opy_ (u"ࠪࡰࡴࡩࡡ࡭࢙ࠩ")] = False
    elif bstack1ll1lll_opy_ (u"ࠫ࡮ࡹࡔࡳ࡫ࡤࡰࡌࡸࡩࡥ࢚ࠩ") in bstack1lllll1l11_opy_:
        bstack1ll1llll_opy_ = CONFIG.get(bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴ࢛ࠩ"), {})
        logger.debug(bstack1ll1lll_opy_ (u"ࠨࡁࡕࡕࠣ࠾ࠥࡋࡸࡪࡵࡷ࡭ࡳ࡭ࠠ࡭ࡱࡦࡥࡱࠦ࡯ࡱࡶ࡬ࡳࡳࡹ࠺ࠡࠧࡶࠦ࢜"), bstack1ll1llll_opy_)
        bstack1lll111ll_opy_ = bstack1lllll1l11_opy_.get(bstack1ll1lll_opy_ (u"ࠢࡤࡷࡶࡸࡴࡳࡒࡦࡲࡨࡥࡹ࡫ࡲࡴࠤ࢝"), [])
        bstack111ll1lll_opy_ = bstack1ll1lll_opy_ (u"ࠣ࠮ࠥ࢞").join(bstack1lll111ll_opy_)
        logger.debug(bstack1ll1lll_opy_ (u"ࠤࡄࡘࡘࠦ࠺ࠡࡅࡸࡷࡹࡵ࡭ࠡࡴࡨࡴࡪࡧࡴࡦࡴࠣࡷࡹࡸࡩ࡯ࡩ࠽ࠤࠪࡹࠢ࢟"), bstack111ll1lll_opy_)
        bstack1l111l1ll1_opy_ = {
            bstack1ll1lll_opy_ (u"ࠥࡰࡴࡩࡡ࡭ࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠧࢠ"): bstack1ll1lll_opy_ (u"ࠦࡦࡺࡳ࠮ࡴࡨࡴࡪࡧࡴࡦࡴࠥࢡ"),
            bstack1ll1lll_opy_ (u"ࠧ࡬࡯ࡳࡥࡨࡐࡴࡩࡡ࡭ࠤࢢ"): bstack1ll1lll_opy_ (u"ࠨࡴࡳࡷࡨࠦࢣ"),
            bstack1ll1lll_opy_ (u"ࠢࡤࡷࡶࡸࡴࡳ࠭ࡳࡧࡳࡩࡦࡺࡥࡳࠤࢤ"): bstack111ll1lll_opy_
        }
        bstack1ll1llll_opy_.update(bstack1l111l1ll1_opy_)
        logger.debug(bstack1ll1lll_opy_ (u"ࠣࡃࡗࡗࠥࡀࠠࡖࡲࡧࡥࡹ࡫ࡤࠡ࡮ࡲࡧࡦࡲࠠࡰࡲࡷ࡭ࡴࡴࡳ࠻ࠢࠨࡷࠧࢥ"), bstack1ll1llll_opy_)
        CONFIG[bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࡍࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭ࢦ")] = bstack1ll1llll_opy_
        logger.debug(bstack1ll1lll_opy_ (u"ࠥࡅ࡙࡙ࠠ࠻ࠢࡉ࡭ࡳࡧ࡬ࠡࡅࡒࡒࡋࡏࡇ࠻ࠢࠨࡷࠧࢧ"), CONFIG)
def bstack1ll11ll11l_opy_():
    bstack111lllll1l_opy_ = bstack11l1l1l1_opy_()
    if not bstack111lllll1l_opy_[bstack1ll1lll_opy_ (u"ࠫࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࡖࡴ࡯ࠫࢨ")]:
      raise ValueError(bstack1ll1lll_opy_ (u"ࠧࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵࡗࡵࡰࠥ࡯ࡳࠡ࡯࡬ࡷࡸ࡯࡮ࡨࠢࡩࡶࡴࡳࠠࡨࡴ࡬ࡨࠥࡪࡥࡵࡣ࡬ࡰࡸ࠴ࠢࢩ"))
    return bstack111lllll1l_opy_[bstack1ll1lll_opy_ (u"࠭ࡰ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶࡘࡶࡱ࠭ࢪ")] + bstack1ll1lll_opy_ (u"ࠧࡀࡥࡤࡴࡸࡃࠧࢫ")
@measure(event_name=EVENTS.bstack1llllll1l_opy_, stage=STAGE.bstack111lll1l11_opy_)
def bstack1l1llllll1_opy_() -> list:
    global CONFIG
    result = []
    if CONFIG:
        auth = (CONFIG[bstack1ll1lll_opy_ (u"ࠨࡷࡶࡩࡷࡔࡡ࡮ࡧࠪࢬ")], CONFIG[bstack1ll1lll_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴࡍࡨࡽࠬࢭ")])
        url = bstack1ll1lll1_opy_
        logger.debug(bstack1ll1lll_opy_ (u"ࠥࡅࡹࡺࡥ࡮ࡲࡷ࡭ࡳ࡭ࠠࡵࡱࠣࡪࡪࡺࡣࡩࠢࡥࡹ࡮ࡲࡤࡴࠢࡩࡶࡴࡳࠠࡃࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࠦࡔࡶࡴࡥࡳࡘࡩࡡ࡭ࡧࠣࡅࡕࡏࠢࢮ"))
        try:
            response = requests.get(url, auth=auth, headers={bstack1ll1lll_opy_ (u"ࠦࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠥࢯ"): bstack1ll1lll_opy_ (u"ࠧࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠣࢰ")})
            if response.status_code == 200:
                bstack11l1lll1l_opy_ = json.loads(response.text)
                bstack111l11l1l_opy_ = bstack11l1lll1l_opy_.get(bstack1ll1lll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡸ࠭ࢱ"), [])
                if bstack111l11l1l_opy_:
                    bstack11llll1lll_opy_ = bstack111l11l1l_opy_[0]
                    build_hashed_id = bstack11llll1lll_opy_.get(bstack1ll1lll_opy_ (u"ࠧࡩࡣࡶ࡬ࡪࡪ࡟ࡪࡦࠪࢲ"))
                    bstack1l1l11ll11_opy_ = bstack1lll1111l1_opy_ + build_hashed_id
                    result.extend([build_hashed_id, bstack1l1l11ll11_opy_])
                    logger.info(bstack1l11111ll1_opy_.format(bstack1l1l11ll11_opy_))
                    bstack1l1111lll_opy_ = CONFIG[bstack1ll1lll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫࢳ")]
                    if bstack1ll1lll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫࢴ") in CONFIG:
                      bstack1l1111lll_opy_ += bstack1ll1lll_opy_ (u"ࠪࠤࠬࢵ") + CONFIG[bstack1ll1lll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭ࢶ")]
                    if bstack1l1111lll_opy_ != bstack11llll1lll_opy_.get(bstack1ll1lll_opy_ (u"ࠬࡴࡡ࡮ࡧࠪࢷ")):
                      logger.debug(bstack11l11llll_opy_.format(bstack11llll1lll_opy_.get(bstack1ll1lll_opy_ (u"࠭࡮ࡢ࡯ࡨࠫࢸ")), bstack1l1111lll_opy_))
                    return result
                else:
                    logger.debug(bstack1ll1lll_opy_ (u"ࠢࡂࡖࡖࠤ࠿ࠦࡎࡰࠢࡥࡹ࡮ࡲࡤࡴࠢࡩࡳࡺࡴࡤࠡ࡫ࡱࠤࡹ࡮ࡥࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࠦࢹ"))
            else:
                logger.debug(bstack1ll1lll_opy_ (u"ࠣࡃࡗࡗࠥࡀࠠࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡪࡪࡺࡣࡩࠢࡥࡹ࡮ࡲࡤࡴ࠰ࠥࢺ"))
        except Exception as e:
            logger.error(bstack1ll1lll_opy_ (u"ࠤࡄࡘࡘࠦ࠺ࠡࡇࡵࡶࡴࡸࠠࡪࡰࠣ࡫ࡪࡺࡴࡪࡰࡪࠤࡧࡻࡩ࡭ࡦࡶࠤ࠿ࠦࡻࡾࠤࢻ").format(str(e)))
    else:
        logger.debug(bstack1ll1lll_opy_ (u"ࠥࡅ࡙࡙ࠠ࠻ࠢࡆࡓࡓࡌࡉࡈࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡶࡩࡹ࠴ࠠࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡪࡪࡺࡣࡩࠢࡥࡹ࡮ࡲࡤࡴ࠰ࠥࢼ"))
    return [None, None]
from browserstack_sdk.sdk_cli.cli import cli
from browserstack_sdk.sdk_cli.bstack1ll1l1ll11_opy_ import bstack1ll1l1ll11_opy_, bstack1l11l1lll1_opy_, bstack1llllllll1_opy_, bstack1ll11l1ll1_opy_
from bstack_utils.measure import bstack11llll1111_opy_
from bstack_utils.measure import measure
from bstack_utils.percy import *
from bstack_utils.percy_sdk import PercySDK
from bstack_utils.bstack1l1111l1l_opy_ import bstack11l1l1ll11_opy_
from bstack_utils.messages import *
from bstack_utils import bstack1ll1ll1111_opy_
from bstack_utils.constants import *
from bstack_utils.helper import bstack1l11ll11l1_opy_, bstack111lll1ll1_opy_, bstack1l1111l11l_opy_, bstack11l1l1lll_opy_, \
  bstack11ll1l1111_opy_, \
  Notset, bstack11l1l1ll1l_opy_, \
  bstack11lll1l1ll_opy_, bstack11111l11l_opy_, bstack11l1l111l1_opy_, bstack1l111l1l_opy_, bstack1l1111ll1l_opy_, bstack111llllll1_opy_, \
  bstack1111l1lll_opy_, \
  bstack1l1l111l11_opy_, bstack1l11lllll1_opy_, bstack11lllll11_opy_, bstack1ll111ll_opy_, \
  bstack11ll1111_opy_, bstack111l111l1_opy_, bstack1ll111ll11_opy_, bstack1ll11l1l1l_opy_
from bstack_utils.bstack11l1111l_opy_ import bstack11l1l111ll_opy_
from bstack_utils.bstack1l1111llll_opy_ import bstack111llllll_opy_, bstack1lllll1lll_opy_
from bstack_utils.bstack1ll1l11lll_opy_ import bstack1111l1ll_opy_
from bstack_utils.bstack11ll111l1l_opy_ import bstack1l1lll1ll1_opy_, bstack1l11l1l11l_opy_
from bstack_utils.bstack1l11llll_opy_ import bstack1l11llll_opy_
from bstack_utils.bstack11ll1l11_opy_ import bstack11lll1l11l_opy_
from bstack_utils.proxy import bstack1l111l1l11_opy_, bstack1l111l1111_opy_, bstack1ll1111ll1_opy_, bstack1l1lllllll_opy_
from bstack_utils.bstack1ll11ll11_opy_ import bstack111l1l11l_opy_
import bstack_utils.bstack11llll111l_opy_ as bstack1llll1111_opy_
import bstack_utils.bstack1l11lll1l_opy_ as bstack1ll111l11l_opy_
from browserstack_sdk.sdk_cli.cli import cli
from browserstack_sdk.sdk_cli.utils.bstack11ll1ll1ll_opy_ import bstack1lll1ll1_opy_
from bstack_utils.bstack1llll111ll_opy_ import bstack11lll1lll1_opy_
from bstack_utils.bstack1l1l1l1111_opy_ import bstack1llll11l11_opy_
if os.getenv(bstack1ll1lll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡇࡑࡏ࡟ࡉࡑࡒࡏࡘ࠭ࢽ")):
  cli.bstack111lll11l_opy_()
else:
  os.environ[bstack1ll1lll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡈࡒࡉࡠࡊࡒࡓࡐ࡙ࠧࢾ")] = bstack1ll1lll_opy_ (u"࠭ࡴࡳࡷࡨࠫࢿ")
bstack11l11l1l1l_opy_ = bstack1ll1lll_opy_ (u"ࠧࠡࠢ࠲࠮ࠥࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠢ࠭࠳ࡡࡴࠠࠡ࡫ࡩࠬࡵࡧࡧࡦࠢࡀࡁࡂࠦࡶࡰ࡫ࡧࠤ࠵࠯ࠠࡼ࡞ࡱࠤࠥࠦࡴࡳࡻࡾࡠࡳࠦࡣࡰࡰࡶࡸࠥ࡬ࡳࠡ࠿ࠣࡶࡪࡷࡵࡪࡴࡨࠬࡡ࠭ࡦࡴ࡞ࠪ࠭ࡀࡢ࡮ࠡࠢࠣࠤࠥ࡬ࡳ࠯ࡣࡳࡴࡪࡴࡤࡇ࡫࡯ࡩࡘࡿ࡮ࡤࠪࡥࡷࡹࡧࡣ࡬ࡡࡳࡥࡹ࡮ࠬࠡࡌࡖࡓࡓ࠴ࡳࡵࡴ࡬ࡲ࡬࡯ࡦࡺࠪࡳࡣ࡮ࡴࡤࡦࡺࠬࠤ࠰ࠦࠢ࠻ࠤࠣ࠯ࠥࡐࡓࡐࡐ࠱ࡷࡹࡸࡩ࡯ࡩ࡬ࡪࡾ࠮ࡊࡔࡑࡑ࠲ࡵࡧࡲࡴࡧࠫࠬࡦࡽࡡࡪࡶࠣࡲࡪࡽࡐࡢࡩࡨ࠶࠳࡫ࡶࡢ࡮ࡸࡥࡹ࡫ࠨࠣࠪࠬࠤࡂࡄࠠࡼࡿࠥ࠰ࠥࡢࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡨࡧࡷࡗࡪࡹࡳࡪࡱࡱࡈࡪࡺࡡࡪ࡮ࡶࠦࢂࡢࠧࠪࠫࠬ࡟ࠧ࡮ࡡࡴࡪࡨࡨࡤ࡯ࡤࠣ࡟ࠬࠤ࠰ࠦࠢ࠭࡞࡟ࡲࠧ࠯࡜࡯ࠢࠣࠤࠥࢃࡣࡢࡶࡦ࡬࠭࡫ࡸࠪࡽ࡟ࡲࠥࠦࠠࠡࡿ࡟ࡲࠥࠦࡽ࡝ࡰࠣࠤ࠴࠰ࠠ࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࠤ࠯࠵ࠧࣀ")
bstack1l111ll11l_opy_ = bstack1ll1lll_opy_ (u"ࠨ࡞ࡱ࠳࠯ࠦ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࠣ࠮࠴ࡢ࡮ࡤࡱࡱࡷࡹࠦࡢࡴࡶࡤࡧࡰࡥࡰࡢࡶ࡫ࠤࡂࠦࡰࡳࡱࡦࡩࡸࡹ࠮ࡢࡴࡪࡺࡠࡶࡲࡰࡥࡨࡷࡸ࠴ࡡࡳࡩࡹ࠲ࡱ࡫࡮ࡨࡶ࡫ࠤ࠲ࠦ࠳࡞࡞ࡱࡧࡴࡴࡳࡵࠢࡥࡷࡹࡧࡣ࡬ࡡࡦࡥࡵࡹࠠ࠾ࠢࡳࡶࡴࡩࡥࡴࡵ࠱ࡥࡷ࡭ࡶ࡜ࡲࡵࡳࡨ࡫ࡳࡴ࠰ࡤࡶ࡬ࡼ࠮࡭ࡧࡱ࡫ࡹ࡮ࠠ࠮ࠢ࠴ࡡࡡࡴࡣࡰࡰࡶࡸࠥࡶ࡟ࡪࡰࡧࡩࡽࠦ࠽ࠡࡲࡵࡳࡨ࡫ࡳࡴ࠰ࡤࡶ࡬ࡼ࡛ࡱࡴࡲࡧࡪࡹࡳ࠯ࡣࡵ࡫ࡻ࠴࡬ࡦࡰࡪࡸ࡭ࠦ࠭ࠡ࠴ࡠࡠࡳࡶࡲࡰࡥࡨࡷࡸ࠴ࡡࡳࡩࡹࠤࡂࠦࡰࡳࡱࡦࡩࡸࡹ࠮ࡢࡴࡪࡺ࠳ࡹ࡬ࡪࡥࡨࠬ࠵࠲ࠠࡱࡴࡲࡧࡪࡹࡳ࠯ࡣࡵ࡫ࡻ࠴࡬ࡦࡰࡪࡸ࡭ࠦ࠭ࠡ࠵ࠬࡠࡳࡩ࡯࡯ࡵࡷࠤ࡮ࡳࡰࡰࡴࡷࡣࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴ࠵ࡡࡥࡷࡹࡧࡣ࡬ࠢࡀࠤࡷ࡫ࡱࡶ࡫ࡵࡩ࠭ࠨࡰ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶࠥ࠭ࡀࡢ࡮ࡪ࡯ࡳࡳࡷࡺ࡟ࡱ࡮ࡤࡽࡼࡸࡩࡨࡪࡷ࠸ࡤࡨࡳࡵࡣࡦ࡯࠳ࡩࡨࡳࡱࡰ࡭ࡺࡳ࠮࡭ࡣࡸࡲࡨ࡮ࠠ࠾ࠢࡤࡷࡾࡴࡣࠡࠪ࡯ࡥࡺࡴࡣࡩࡑࡳࡸ࡮ࡵ࡮ࡴࠫࠣࡁࡃࠦࡻ࡝ࡰ࡯ࡩࡹࠦࡣࡢࡲࡶ࠿ࡡࡴࡴࡳࡻࠣࡿࡡࡴࡣࡢࡲࡶࠤࡂࠦࡊࡔࡑࡑ࠲ࡵࡧࡲࡴࡧࠫࡦࡸࡺࡡࡤ࡭ࡢࡧࡦࡶࡳࠪ࡞ࡱࠤࠥࢃࠠࡤࡣࡷࡧ࡭࠮ࡥࡹࠫࠣࡿࡡࡴࠠࠡࠢࠣࢁࡡࡴࠠࠡࡴࡨࡸࡺࡸ࡮ࠡࡣࡺࡥ࡮ࡺࠠࡪ࡯ࡳࡳࡷࡺ࡟ࡱ࡮ࡤࡽࡼࡸࡩࡨࡪࡷ࠸ࡤࡨࡳࡵࡣࡦ࡯࠳ࡩࡨࡳࡱࡰ࡭ࡺࡳ࠮ࡤࡱࡱࡲࡪࡩࡴࠩࡽ࡟ࡲࠥࠦࠠࠡࡹࡶࡉࡳࡪࡰࡰ࡫ࡱࡸ࠿ࠦࡠࡸࡵࡶ࠾࠴࠵ࡣࡥࡲ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡦࡳࡲ࠵ࡰ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶࡂࡧࡦࡶࡳ࠾ࠦࡾࡩࡳࡩ࡯ࡥࡧࡘࡖࡎࡉ࡯࡮ࡲࡲࡲࡪࡴࡴࠩࡌࡖࡓࡓ࠴ࡳࡵࡴ࡬ࡲ࡬࡯ࡦࡺࠪࡦࡥࡵࡹࠩࠪࡿࡣ࠰ࡡࡴࠠࠡࠢࠣ࠲࠳࠴࡬ࡢࡷࡱࡧ࡭ࡕࡰࡵ࡫ࡲࡲࡸࡢ࡮ࠡࠢࢀ࠭ࡡࡴࡽ࡝ࡰ࠲࠮ࠥࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠢ࠭࠳ࡡࡴࠧࣁ")
from ._version import __version__
bstack1l1l11llll_opy_ = None
CONFIG = {}
bstack11llllll_opy_ = {}
bstack11l1ll1l_opy_ = {}
bstack111l11l1_opy_ = None
bstack111l1l11_opy_ = None
bstack1lll11111l_opy_ = None
bstack1lllll1ll1_opy_ = -1
bstack1l11l11l1l_opy_ = 0
bstack11l111l11l_opy_ = bstack1l1lll1l11_opy_
bstack1lll1ll1ll_opy_ = 1
bstack11llll1l11_opy_ = False
bstack1l1l1111_opy_ = False
bstack11111l1ll_opy_ = bstack1ll1lll_opy_ (u"ࠩࠪࣂ")
bstack1ll1lll1l1_opy_ = bstack1ll1lll_opy_ (u"ࠪࠫࣃ")
bstack1l1lll1lll_opy_ = False
bstack1l11111l1l_opy_ = True
bstack1l1lllll1_opy_ = bstack1ll1lll_opy_ (u"ࠫࠬࣄ")
bstack1ll11ll1l1_opy_ = []
bstack11llllll11_opy_ = threading.Lock()
bstack1lll111lll_opy_ = threading.Lock()
bstack111ll111_opy_ = bstack1ll1lll_opy_ (u"ࠬ࠭ࣅ")
bstack1ll11llll1_opy_ = False
bstack1ll1l111l1_opy_ = None
bstack1l111l1ll_opy_ = None
bstack1lll1l1l1l_opy_ = None
bstack1ll11l111_opy_ = -1
bstack1lllllll11_opy_ = os.path.join(os.path.expanduser(bstack1ll1lll_opy_ (u"࠭ࡾࠨࣆ")), bstack1ll1lll_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧࣇ"), bstack1ll1lll_opy_ (u"ࠨ࠰ࡵࡳࡧࡵࡴ࠮ࡴࡨࡴࡴࡸࡴ࠮ࡪࡨࡰࡵ࡫ࡲ࠯࡬ࡶࡳࡳ࠭ࣈ"))
bstack1ll1l11ll_opy_ = 0
bstack11ll1ll1_opy_ = 0
bstack11111111l_opy_ = []
bstack1l11ll111l_opy_ = []
bstack11ll1l1ll_opy_ = []
bstack11l1l1l11l_opy_ = []
bstack1l1l1l11_opy_ = bstack1ll1lll_opy_ (u"ࠩࠪࣉ")
bstack1l11111ll_opy_ = bstack1ll1lll_opy_ (u"ࠪࠫ࣊")
bstack1l1l11ll1_opy_ = False
bstack1l11l11lll_opy_ = False
bstack11ll1lll11_opy_ = {}
bstack1111ll1l_opy_ = None
bstack1lll1lll1_opy_ = None
bstack11l1ll1lll_opy_ = None
bstack1l1l111ll1_opy_ = None
bstack1ll1llll1l_opy_ = None
bstack11llll11_opy_ = None
bstack1ll1lllll1_opy_ = None
bstack11ll111l1_opy_ = None
bstack11lllll11l_opy_ = None
bstack11l111111l_opy_ = None
bstack11lll1111l_opy_ = None
bstack1l1l11111_opy_ = None
bstack1llllll1ll_opy_ = None
bstack11ll1ll1l1_opy_ = None
bstack1ll1lll11_opy_ = None
bstack1l1ll1l1ll_opy_ = None
bstack1lll11l1ll_opy_ = None
bstack1l11111l11_opy_ = None
bstack1l1l1l1l1l_opy_ = None
bstack11ll1l1l_opy_ = None
bstack11llllll1l_opy_ = None
bstack11l11ll11l_opy_ = None
bstack1llll1ll1l_opy_ = None
thread_local = threading.local()
bstack11l11l1l11_opy_ = False
bstack1l1l111ll_opy_ = bstack1ll1lll_opy_ (u"ࠦࠧ࣋")
logger = bstack1ll1ll1111_opy_.get_logger(__name__, bstack11l111l11l_opy_)
bstack11l1l11l_opy_ = Config.bstack1l1l111l_opy_()
percy = bstack1l11l111_opy_()
bstack11l11l1l1_opy_ = bstack11l1l1ll11_opy_()
bstack11ll1l11l_opy_ = bstack1lllll1111_opy_()
def bstack11ll111ll1_opy_():
  global CONFIG
  global bstack1l1l11ll1_opy_
  global bstack11l1l11l_opy_
  testContextOptions = bstack1l11l111l1_opy_(CONFIG)
  if bstack11ll1l1111_opy_(CONFIG):
    if (bstack1ll1lll_opy_ (u"ࠬࡹ࡫ࡪࡲࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧ࣌") in testContextOptions and str(testContextOptions[bstack1ll1lll_opy_ (u"࠭ࡳ࡬࡫ࡳࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠨ࣍")]).lower() == bstack1ll1lll_opy_ (u"ࠧࡵࡴࡸࡩࠬ࣎")):
      bstack1l1l11ll1_opy_ = True
    bstack11l1l11l_opy_.bstack11lll1l11_opy_(testContextOptions.get(bstack1ll1lll_opy_ (u"ࠨࡵ࡮࡭ࡵ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷ࣏ࠬ"), False))
  else:
    bstack1l1l11ll1_opy_ = True
    bstack11l1l11l_opy_.bstack11lll1l11_opy_(True)
def bstack1lll1ll1l_opy_():
  from appium.version import version as appium_version
  return version.parse(appium_version)
def bstack1lll1l1ll1_opy_():
  from selenium import webdriver
  return version.parse(webdriver.__version__)
def bstack1l1llll11l_opy_():
  args = sys.argv
  for i in range(len(args)):
    if bstack1ll1lll_opy_ (u"ࠤ࠰࠱ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡦࡳࡳ࡬ࡩࡨࡨ࡬ࡰࡪࠨ࣐") == args[i].lower() or bstack1ll1lll_opy_ (u"ࠥ࠱࠲ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡨࡵ࡮ࡧ࡫ࡪ࣑ࠦ") == args[i].lower():
      path = args[i + 1]
      sys.argv.remove(args[i])
      sys.argv.remove(path)
      global bstack1l1lllll1_opy_
      bstack1l1lllll1_opy_ += bstack1ll1lll_opy_ (u"ࠫ࠲࠳ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡈࡵ࡮ࡧ࡫ࡪࡊ࡮ࡲࡥ࣒ࠡࠩ") + shlex.quote(path)
      return path
  return None
bstack111l11l11_opy_ = re.compile(bstack1ll1lll_opy_ (u"ࡷࠨ࠮ࠫࡁ࡟ࠨࢀ࠮࠮ࠫࡁࠬࢁ࠳࠰࠿࣓ࠣ"))
def bstack11111llll_opy_(loader, node):
  value = loader.construct_scalar(node)
  for group in bstack111l11l11_opy_.findall(value):
    if group is not None and os.environ.get(group) is not None:
      value = value.replace(bstack1ll1lll_opy_ (u"ࠨࠤࡼࠤࣔ") + group + bstack1ll1lll_opy_ (u"ࠢࡾࠤࣕ"), os.environ.get(group))
  return value
def bstack11l11ll1ll_opy_():
  global bstack1llll1ll1l_opy_
  if bstack1llll1ll1l_opy_ is None:
        bstack1llll1ll1l_opy_ = bstack1l1llll11l_opy_()
  bstack11ll1l111l_opy_ = bstack1llll1ll1l_opy_
  if bstack11ll1l111l_opy_ and os.path.exists(os.path.abspath(bstack11ll1l111l_opy_)):
    fileName = bstack11ll1l111l_opy_
  if bstack1ll1lll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡄࡑࡑࡊࡎࡍ࡟ࡇࡋࡏࡉࠬࣖ") in os.environ and os.path.exists(
          os.path.abspath(os.environ[bstack1ll1lll_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡅࡒࡒࡋࡏࡇࡠࡈࡌࡐࡊ࠭ࣗ")])) and not bstack1ll1lll_opy_ (u"ࠪࡪ࡮ࡲࡥࡏࡣࡰࡩࠬࣘ") in locals():
    fileName = os.environ[bstack1ll1lll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡇࡔࡔࡆࡊࡉࡢࡊࡎࡒࡅࠨࣙ")]
  if bstack1ll1lll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡑࡥࡲ࡫ࠧࣚ") in locals():
    bstack1l1ll11_opy_ = os.path.abspath(fileName)
  else:
    bstack1l1ll11_opy_ = bstack1ll1lll_opy_ (u"࠭ࠧࣛ")
  bstack11111l11_opy_ = os.getcwd()
  bstack1llll11l_opy_ = bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡹ࡮࡮ࠪࣜ")
  bstack1llllll111_opy_ = bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡺࡣࡰࡰࠬࣝ")
  while (not os.path.exists(bstack1l1ll11_opy_)) and bstack11111l11_opy_ != bstack1ll1lll_opy_ (u"ࠤࠥࣞ"):
    bstack1l1ll11_opy_ = os.path.join(bstack11111l11_opy_, bstack1llll11l_opy_)
    if not os.path.exists(bstack1l1ll11_opy_):
      bstack1l1ll11_opy_ = os.path.join(bstack11111l11_opy_, bstack1llllll111_opy_)
    if bstack11111l11_opy_ != os.path.dirname(bstack11111l11_opy_):
      bstack11111l11_opy_ = os.path.dirname(bstack11111l11_opy_)
    else:
      bstack11111l11_opy_ = bstack1ll1lll_opy_ (u"ࠥࠦࣟ")
  bstack1llll1ll1l_opy_ = bstack1l1ll11_opy_ if os.path.exists(bstack1l1ll11_opy_) else None
  return bstack1llll1ll1l_opy_
def bstack1111llll1_opy_(config):
    if bstack1ll1lll_opy_ (u"ࠫࡹ࡫ࡳࡵࡔࡨࡴࡴࡸࡴࡪࡰࡪࠫ࣠") in config:
      config[bstack1ll1lll_opy_ (u"ࠬࡺࡥࡴࡶࡒࡦࡸ࡫ࡲࡷࡣࡥ࡭ࡱ࡯ࡴࡺࠩ࣡")] = config[bstack1ll1lll_opy_ (u"࠭ࡴࡦࡵࡷࡖࡪࡶ࡯ࡳࡶ࡬ࡲ࡬࠭࣢")]
    if bstack1ll1lll_opy_ (u"ࠧࡵࡧࡶࡸࡗ࡫ࡰࡰࡴࡷ࡭ࡳ࡭ࡏࡱࡶ࡬ࡳࡳࡹࣣࠧ") in config:
      config[bstack1ll1lll_opy_ (u"ࠨࡶࡨࡷࡹࡕࡢࡴࡧࡵࡺࡦࡨࡩ࡭࡫ࡷࡽࡔࡶࡴࡪࡱࡱࡷࠬࣤ")] = config[bstack1ll1lll_opy_ (u"ࠩࡷࡩࡸࡺࡒࡦࡲࡲࡶࡹ࡯࡮ࡨࡑࡳࡸ࡮ࡵ࡮ࡴࠩࣥ")]
def bstack1l1l1l1ll_opy_():
  bstack1l1ll11_opy_ = bstack11l11ll1ll_opy_()
  if not os.path.exists(bstack1l1ll11_opy_):
    bstack1ll11ll1l_opy_(
      bstack11ll1llll1_opy_.format(os.getcwd()))
  try:
    with open(bstack1l1ll11_opy_, bstack1ll1lll_opy_ (u"ࠪࡶࣦࠬ")) as stream:
      yaml.add_implicit_resolver(bstack1ll1lll_opy_ (u"ࠦࠦࡶࡡࡵࡪࡨࡼࠧࣧ"), bstack111l11l11_opy_)
      yaml.add_constructor(bstack1ll1lll_opy_ (u"ࠧࠧࡰࡢࡶ࡫ࡩࡽࠨࣨ"), bstack11111llll_opy_)
      config = yaml.load(stream, yaml.FullLoader)
      bstack1111llll1_opy_(config)
      return config
  except:
    with open(bstack1l1ll11_opy_, bstack1ll1lll_opy_ (u"࠭ࡲࠨࣩ")) as stream:
      try:
        config = yaml.safe_load(stream)
        bstack1111llll1_opy_(config)
        return config
      except yaml.YAMLError as exc:
        bstack1ll11ll1l_opy_(bstack1l1111lll1_opy_.format(str(exc)))
def bstack1ll1l1l111_opy_(config):
  bstack11l1ll1l1l_opy_ = bstack1l1lll1l1l_opy_(config)
  for option in list(bstack11l1ll1l1l_opy_):
    if option.lower() in bstack1llll111_opy_ and option != bstack1llll111_opy_[option.lower()]:
      bstack11l1ll1l1l_opy_[bstack1llll111_opy_[option.lower()]] = bstack11l1ll1l1l_opy_[option]
      del bstack11l1ll1l1l_opy_[option]
  return config
def bstack1ll1lll1l_opy_():
  global bstack11l1ll1l_opy_
  for key, bstack11l1lll111_opy_ in bstack1ll1llllll_opy_.items():
    if isinstance(bstack11l1lll111_opy_, list):
      for var in bstack11l1lll111_opy_:
        if var in os.environ and os.environ[var] and str(os.environ[var]).strip():
          bstack11l1ll1l_opy_[key] = os.environ[var]
          break
    elif bstack11l1lll111_opy_ in os.environ and os.environ[bstack11l1lll111_opy_] and str(os.environ[bstack11l1lll111_opy_]).strip():
      bstack11l1ll1l_opy_[key] = os.environ[bstack11l1lll111_opy_]
  if bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡌࡐࡅࡄࡐࡤࡏࡄࡆࡐࡗࡍࡋࡏࡅࡓࠩ࣪") in os.environ:
    bstack11l1ll1l_opy_[bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬ࣫")] = {}
    bstack11l1ll1l_opy_[bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࡍࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭࣬")][bstack1ll1lll_opy_ (u"ࠪࡰࡴࡩࡡ࡭ࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶ࣭ࠬ")] = os.environ[bstack1ll1lll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡐࡔࡉࡁࡍࡡࡌࡈࡊࡔࡔࡊࡈࡌࡉࡗ࣮࠭")]
def bstack111lllll_opy_():
  global bstack11llllll_opy_
  global bstack1l1lllll1_opy_
  bstack1l1lll1l_opy_ = []
  for idx, val in enumerate(sys.argv):
    if idx < len(sys.argv) - 1 and bstack1ll1lll_opy_ (u"ࠬ࠳࠭ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴࡬ࡰࡥࡤࡰࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨ࣯").lower() == val.lower():
      bstack11llllll_opy_[bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࣰࠪ")] = {}
      bstack11llllll_opy_[bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࣱࠫ")][bstack1ll1lll_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࣲࠪ")] = sys.argv[idx + 1]
      bstack1l1lll1l_opy_.extend([idx, idx + 1])
      break
  for key, bstack1l1111l1_opy_ in bstack1ll11111_opy_.items():
    if isinstance(bstack1l1111l1_opy_, list):
      for idx, val in enumerate(sys.argv):
        if idx >= len(sys.argv) - 1:
          continue
        for var in bstack1l1111l1_opy_:
          if bstack1ll1lll_opy_ (u"ࠩ࠰࠱ࠬࣳ") + var.lower() == val.lower() and key not in bstack11llllll_opy_:
            bstack11llllll_opy_[key] = sys.argv[idx + 1]
            bstack1l1lllll1_opy_ += bstack1ll1lll_opy_ (u"ࠪࠤ࠲࠳ࠧࣴ") + var + bstack1ll1lll_opy_ (u"ࠫࠥ࠭ࣵ") + shlex.quote(sys.argv[idx + 1])
            bstack1l1lll1l_opy_.extend([idx, idx + 1])
            break
    else:
      for idx, val in enumerate(sys.argv):
        if idx >= len(sys.argv) - 1:
          continue
        if bstack1ll1lll_opy_ (u"ࠬ࠳࠭ࠨࣶ") + bstack1l1111l1_opy_.lower() == val.lower() and key not in bstack11llllll_opy_:
          bstack11llllll_opy_[key] = sys.argv[idx + 1]
          bstack1l1lllll1_opy_ += bstack1ll1lll_opy_ (u"࠭ࠠ࠮࠯ࠪࣷ") + bstack1l1111l1_opy_ + bstack1ll1lll_opy_ (u"ࠧࠡࠩࣸ") + shlex.quote(sys.argv[idx + 1])
          bstack1l1lll1l_opy_.extend([idx, idx + 1])
  for idx in sorted(set(bstack1l1lll1l_opy_), reverse=True):
    if idx < len(sys.argv):
      del sys.argv[idx]
def bstack1ll1ll11l1_opy_(config):
  bstack1lll1ll1l1_opy_ = config.keys()
  for bstack1llll1ll11_opy_, bstack1111l1ll1_opy_ in bstack1111111l_opy_.items():
    if bstack1111l1ll1_opy_ in bstack1lll1ll1l1_opy_:
      config[bstack1llll1ll11_opy_] = config[bstack1111l1ll1_opy_]
      del config[bstack1111l1ll1_opy_]
  for bstack1llll1ll11_opy_, bstack1111l1ll1_opy_ in bstack1l1l111l1_opy_.items():
    if isinstance(bstack1111l1ll1_opy_, list):
      for bstack1ll11lll_opy_ in bstack1111l1ll1_opy_:
        if bstack1ll11lll_opy_ in bstack1lll1ll1l1_opy_:
          config[bstack1llll1ll11_opy_] = config[bstack1ll11lll_opy_]
          del config[bstack1ll11lll_opy_]
          break
    elif bstack1111l1ll1_opy_ in bstack1lll1ll1l1_opy_:
      config[bstack1llll1ll11_opy_] = config[bstack1111l1ll1_opy_]
      del config[bstack1111l1ll1_opy_]
  for bstack1ll11lll_opy_ in list(config):
    for bstack1l11l111l_opy_ in bstack1l1111111l_opy_:
      if bstack1ll11lll_opy_.lower() == bstack1l11l111l_opy_.lower() and bstack1ll11lll_opy_ != bstack1l11l111l_opy_:
        config[bstack1l11l111l_opy_] = config[bstack1ll11lll_opy_]
        del config[bstack1ll11lll_opy_]
  bstack1111l11l_opy_ = [{}]
  if not config.get(bstack1ll1lll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࣹࠫ")):
    config[bstack1ll1lll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࣺࠬ")] = [{}]
  bstack1111l11l_opy_ = config[bstack1ll1lll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ࣻ")]
  for platform in bstack1111l11l_opy_:
    for bstack1ll11lll_opy_ in list(platform):
      for bstack1l11l111l_opy_ in bstack1l1111111l_opy_:
        if bstack1ll11lll_opy_.lower() == bstack1l11l111l_opy_.lower() and bstack1ll11lll_opy_ != bstack1l11l111l_opy_:
          platform[bstack1l11l111l_opy_] = platform[bstack1ll11lll_opy_]
          del platform[bstack1ll11lll_opy_]
  for bstack1llll1ll11_opy_, bstack1111l1ll1_opy_ in bstack1l1l111l1_opy_.items():
    for platform in bstack1111l11l_opy_:
      if isinstance(bstack1111l1ll1_opy_, list):
        for bstack1ll11lll_opy_ in bstack1111l1ll1_opy_:
          if bstack1ll11lll_opy_ in platform:
            platform[bstack1llll1ll11_opy_] = platform[bstack1ll11lll_opy_]
            del platform[bstack1ll11lll_opy_]
            break
      elif bstack1111l1ll1_opy_ in platform:
        platform[bstack1llll1ll11_opy_] = platform[bstack1111l1ll1_opy_]
        del platform[bstack1111l1ll1_opy_]
  for bstack111111lll_opy_ in bstack11l1llll1l_opy_:
    if bstack111111lll_opy_ in config:
      if not bstack11l1llll1l_opy_[bstack111111lll_opy_] in config:
        config[bstack11l1llll1l_opy_[bstack111111lll_opy_]] = {}
      config[bstack11l1llll1l_opy_[bstack111111lll_opy_]].update(config[bstack111111lll_opy_])
      del config[bstack111111lll_opy_]
  for platform in bstack1111l11l_opy_:
    for bstack111111lll_opy_ in bstack11l1llll1l_opy_:
      if bstack111111lll_opy_ in list(platform):
        if not bstack11l1llll1l_opy_[bstack111111lll_opy_] in platform:
          platform[bstack11l1llll1l_opy_[bstack111111lll_opy_]] = {}
        platform[bstack11l1llll1l_opy_[bstack111111lll_opy_]].update(platform[bstack111111lll_opy_])
        del platform[bstack111111lll_opy_]
  config = bstack1ll1l1l111_opy_(config)
  return config
def bstack11l11111l1_opy_(config):
  global bstack1ll1lll1l1_opy_
  bstack111ll1ll_opy_ = False
  if bstack1ll1lll_opy_ (u"ࠫࡹࡻࡲࡣࡱࡖࡧࡦࡲࡥࠨࣼ") in config and str(config[bstack1ll1lll_opy_ (u"ࠬࡺࡵࡳࡤࡲࡗࡨࡧ࡬ࡦࠩࣽ")]).lower() != bstack1ll1lll_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬࣾ"):
    if bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࠫࣿ") not in config or str(config[bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡌࡰࡥࡤࡰࠬऀ")]).lower() == bstack1ll1lll_opy_ (u"ࠩࡩࡥࡱࡹࡥࠨँ"):
      config[bstack1ll1lll_opy_ (u"ࠪࡰࡴࡩࡡ࡭ࠩं")] = False
    else:
      bstack111lllll1l_opy_ = bstack11l1l1l1_opy_()
      if bstack1ll1lll_opy_ (u"ࠫ࡮ࡹࡔࡳ࡫ࡤࡰࡌࡸࡩࡥࠩः") in bstack111lllll1l_opy_:
        if not bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩऄ") in config:
          config[bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪअ")] = {}
        config[bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫआ")][bstack1ll1lll_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪइ")] = bstack1ll1lll_opy_ (u"ࠩࡤࡸࡸ࠳ࡲࡦࡲࡨࡥࡹ࡫ࡲࠨई")
        bstack111ll1ll_opy_ = True
        bstack1ll1lll1l1_opy_ = config[bstack1ll1lll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࡏࡱࡶ࡬ࡳࡳࡹࠧउ")].get(bstack1ll1lll_opy_ (u"ࠫࡱࡵࡣࡢ࡮ࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭ऊ"))
  if bstack11ll1l1111_opy_(config) and bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࠩऋ") in config and str(config[bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࠪऌ")]).lower() != bstack1ll1lll_opy_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭ऍ") and not bstack111ll1ll_opy_:
    if not bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬऎ") in config:
      config[bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࡍࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭ए")] = {}
    if not config[bstack1ll1lll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࡏࡱࡶ࡬ࡳࡳࡹࠧऐ")].get(bstack1ll1lll_opy_ (u"ࠫࡸࡱࡩࡱࡄ࡬ࡲࡦࡸࡹࡊࡰ࡬ࡸ࡮ࡧ࡬ࡪࡵࡤࡸ࡮ࡵ࡮ࠨऑ")) and not bstack1ll1lll_opy_ (u"ࠬࡲ࡯ࡤࡣ࡯ࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧऒ") in config[bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪओ")]:
      bstack1l11l1llll_opy_ = datetime.datetime.now()
      bstack1lll1l1lll_opy_ = bstack1l11l1llll_opy_.strftime(bstack1ll1lll_opy_ (u"ࠧࠦࡦࡢࠩࡧࡥࠥࡉࠧࡐࠫऔ"))
      hostname = socket.gethostname()
      bstack1l1l1llll_opy_ = bstack1ll1lll_opy_ (u"ࠨࠩक").join(random.choices(string.ascii_lowercase + string.digits, k=4))
      identifier = bstack1ll1lll_opy_ (u"ࠩࡾࢁࡤࢁࡽࡠࡽࢀࠫख").format(bstack1lll1l1lll_opy_, hostname, bstack1l1l1llll_opy_)
      config[bstack1ll1lll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࡏࡱࡶ࡬ࡳࡳࡹࠧग")][bstack1ll1lll_opy_ (u"ࠫࡱࡵࡣࡢ࡮ࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭घ")] = identifier
    bstack1ll1lll1l1_opy_ = config[bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩङ")].get(bstack1ll1lll_opy_ (u"࠭࡬ࡰࡥࡤࡰࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨच"))
  return config
def bstack1ll11l11l_opy_():
  bstack1ll1ll1l1_opy_ =  bstack1l111l1l_opy_()[bstack1ll1lll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷ࠭छ")]
  return bstack1ll1ll1l1_opy_ if bstack1ll1ll1l1_opy_ else -1
def bstack1lll11llll_opy_(bstack1ll1ll1l1_opy_):
  global CONFIG
  if not bstack1ll1lll_opy_ (u"ࠨࠦࡾࡆ࡚ࡏࡌࡅࡡࡑ࡙ࡒࡈࡅࡓࡿࠪज") in CONFIG[bstack1ll1lll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫझ")]:
    return
  CONFIG[bstack1ll1lll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬञ")] = CONFIG[bstack1ll1lll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭ट")].replace(
    bstack1ll1lll_opy_ (u"ࠬࠪࡻࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗࢃࠧठ"),
    str(bstack1ll1ll1l1_opy_)
  )
def bstack1l11111lll_opy_():
  global CONFIG
  if not bstack1ll1lll_opy_ (u"࠭ࠤࡼࡆࡄࡘࡊࡥࡔࡊࡏࡈࢁࠬड") in CONFIG[bstack1ll1lll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩढ")]:
    return
  bstack1l11l1llll_opy_ = datetime.datetime.now()
  bstack1lll1l1lll_opy_ = bstack1l11l1llll_opy_.strftime(bstack1ll1lll_opy_ (u"ࠨࠧࡧ࠱ࠪࡨ࠭ࠦࡊ࠽ࠩࡒ࠭ण"))
  CONFIG[bstack1ll1lll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫत")] = CONFIG[bstack1ll1lll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬथ")].replace(
    bstack1ll1lll_opy_ (u"ࠫࠩࢁࡄࡂࡖࡈࡣ࡙ࡏࡍࡆࡿࠪद"),
    bstack1lll1l1lll_opy_
  )
def bstack111ll1l1_opy_():
  global CONFIG
  if bstack1ll1lll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧध") in CONFIG and not bool(CONFIG[bstack1ll1lll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨन")]):
    del CONFIG[bstack1ll1lll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩऩ")]
    return
  if not bstack1ll1lll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪप") in CONFIG:
    CONFIG[bstack1ll1lll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫफ")] = bstack1ll1lll_opy_ (u"ࠪࠧࠩࢁࡂࡖࡋࡏࡈࡤࡔࡕࡎࡄࡈࡖࢂ࠭ब")
  if bstack1ll1lll_opy_ (u"ࠫࠩࢁࡄࡂࡖࡈࡣ࡙ࡏࡍࡆࡿࠪभ") in CONFIG[bstack1ll1lll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧम")]:
    bstack1l11111lll_opy_()
    os.environ[bstack1ll1lll_opy_ (u"࠭ࡂࡔࡖࡄࡇࡐࡥࡃࡐࡏࡅࡍࡓࡋࡄࡠࡄࡘࡍࡑࡊ࡟ࡊࡆࠪय")] = CONFIG[bstack1ll1lll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩर")]
  if not bstack1ll1lll_opy_ (u"ࠨࠦࡾࡆ࡚ࡏࡌࡅࡡࡑ࡙ࡒࡈࡅࡓࡿࠪऱ") in CONFIG[bstack1ll1lll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫल")]:
    return
  bstack1ll1ll1l1_opy_ = bstack1ll1lll_opy_ (u"ࠪࠫळ")
  bstack1l111ll1l1_opy_ = bstack1ll11l11l_opy_()
  if bstack1l111ll1l1_opy_ != -1:
    bstack1ll1ll1l1_opy_ = bstack1ll1lll_opy_ (u"ࠫࡈࡏࠠࠨऴ") + str(bstack1l111ll1l1_opy_)
  if bstack1ll1ll1l1_opy_ == bstack1ll1lll_opy_ (u"ࠬ࠭व"):
    bstack1lll11111_opy_ = bstack11l1111ll1_opy_(CONFIG[bstack1ll1lll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠩश")])
    if bstack1lll11111_opy_ != -1:
      bstack1ll1ll1l1_opy_ = str(bstack1lll11111_opy_)
  if bstack1ll1ll1l1_opy_:
    bstack1lll11llll_opy_(bstack1ll1ll1l1_opy_)
    os.environ[bstack1ll1lll_opy_ (u"ࠧࡃࡕࡗࡅࡈࡑ࡟ࡄࡑࡐࡆࡎࡔࡅࡅࡡࡅ࡙ࡎࡒࡄࡠࡋࡇࠫष")] = CONFIG[bstack1ll1lll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪस")]
def bstack1ll11llll_opy_(bstack1ll1ll1l_opy_, bstack111l111ll_opy_, path):
  bstack1ll1ll11_opy_ = {
    bstack1ll1lll_opy_ (u"ࠩ࡬ࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭ह"): bstack111l111ll_opy_
  }
  if os.path.exists(path):
    bstack1lll1lll1l_opy_ = json.load(open(path, bstack1ll1lll_opy_ (u"ࠪࡶࡧ࠭ऺ")))
  else:
    bstack1lll1lll1l_opy_ = {}
  bstack1lll1lll1l_opy_[bstack1ll1ll1l_opy_] = bstack1ll1ll11_opy_
  with open(path, bstack1ll1lll_opy_ (u"ࠦࡼ࠱ࠢऻ")) as outfile:
    json.dump(bstack1lll1lll1l_opy_, outfile)
def bstack11l1111ll1_opy_(bstack1ll1ll1l_opy_):
  bstack1ll1ll1l_opy_ = str(bstack1ll1ll1l_opy_)
  bstack1lll111l1_opy_ = os.path.join(os.path.expanduser(bstack1ll1lll_opy_ (u"ࠬࢄ़ࠧ")), bstack1ll1lll_opy_ (u"࠭࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠭ऽ"))
  try:
    if not os.path.exists(bstack1lll111l1_opy_):
      os.makedirs(bstack1lll111l1_opy_)
    file_path = os.path.join(os.path.expanduser(bstack1ll1lll_opy_ (u"ࠧࡿࠩा")), bstack1ll1lll_opy_ (u"ࠨ࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠨि"), bstack1ll1lll_opy_ (u"ࠩ࠱ࡦࡺ࡯࡬ࡥ࠯ࡱࡥࡲ࡫࠭ࡤࡣࡦ࡬ࡪ࠴ࡪࡴࡱࡱࠫी"))
    if not os.path.isfile(file_path):
      with open(file_path, bstack1ll1lll_opy_ (u"ࠪࡻࠬु")):
        pass
      with open(file_path, bstack1ll1lll_opy_ (u"ࠦࡼ࠱ࠢू")) as outfile:
        json.dump({}, outfile)
    with open(file_path, bstack1ll1lll_opy_ (u"ࠬࡸࠧृ")) as bstack11l111llll_opy_:
      bstack1l1ll1111l_opy_ = json.load(bstack11l111llll_opy_)
    if bstack1ll1ll1l_opy_ in bstack1l1ll1111l_opy_:
      bstack1l111ll1ll_opy_ = bstack1l1ll1111l_opy_[bstack1ll1ll1l_opy_][bstack1ll1lll_opy_ (u"࠭ࡩࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪॄ")]
      bstack11ll11ll1_opy_ = int(bstack1l111ll1ll_opy_) + 1
      bstack1ll11llll_opy_(bstack1ll1ll1l_opy_, bstack11ll11ll1_opy_, file_path)
      return bstack11ll11ll1_opy_
    else:
      bstack1ll11llll_opy_(bstack1ll1ll1l_opy_, 1, file_path)
      return 1
  except Exception as e:
    logger.warn(bstack1l1lll11ll_opy_.format(str(e)))
    return -1
def bstack1ll1ll11l_opy_(config):
  if not config[bstack1ll1lll_opy_ (u"ࠧࡶࡵࡨࡶࡓࡧ࡭ࡦࠩॅ")] or not config[bstack1ll1lll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡌࡧࡼࠫॆ")]:
    return True
  else:
    return False
def bstack1l11l1ll_opy_(config, index=0):
  global bstack1l1lll1lll_opy_
  bstack1ll1llll11_opy_ = {}
  caps = bstack1ll1l111ll_opy_ + bstack11l11lll1l_opy_
  if config.get(bstack1ll1lll_opy_ (u"ࠩࡷࡹࡷࡨ࡯ࡔࡥࡤࡰࡪ࠭े"), False):
    bstack1ll1llll11_opy_[bstack1ll1lll_opy_ (u"ࠪࡸࡺࡸࡢࡰࡵࡦࡥࡱ࡫ࠧै")] = True
    bstack1ll1llll11_opy_[bstack1ll1lll_opy_ (u"ࠫࡹࡻࡲࡣࡱࡖࡧࡦࡲࡥࡐࡲࡷ࡭ࡴࡴࡳࠨॉ")] = config.get(bstack1ll1lll_opy_ (u"ࠬࡺࡵࡳࡤࡲࡗࡨࡧ࡬ࡦࡑࡳࡸ࡮ࡵ࡮ࡴࠩॊ"), {})
  if bstack1l1lll1lll_opy_:
    caps += bstack11111l1l_opy_
  for key in config:
    if key in caps + [bstack1ll1lll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩो")]:
      continue
    bstack1ll1llll11_opy_[key] = config[key]
  if bstack1ll1lll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪौ") in config:
    for bstack1lllllll1_opy_ in config[bstack1ll1lll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶ्ࠫ")][index]:
      if bstack1lllllll1_opy_ in caps:
        continue
      bstack1ll1llll11_opy_[bstack1lllllll1_opy_] = config[bstack1ll1lll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬॎ")][index][bstack1lllllll1_opy_]
  bstack1ll1llll11_opy_[bstack1ll1lll_opy_ (u"ࠪ࡬ࡴࡹࡴࡏࡣࡰࡩࠬॏ")] = socket.gethostname()
  if bstack1ll1lll_opy_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬॐ") in bstack1ll1llll11_opy_:
    del (bstack1ll1llll11_opy_[bstack1ll1lll_opy_ (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭॑")])
  return bstack1ll1llll11_opy_
def bstack1l11llllll_opy_(config):
  global bstack1l1lll1lll_opy_
  bstack11ll11111l_opy_ = {}
  caps = bstack11l11lll1l_opy_
  if bstack1l1lll1lll_opy_:
    caps += bstack11111l1l_opy_
  for key in caps:
    if key in config:
      bstack11ll11111l_opy_[key] = config[key]
  return bstack11ll11111l_opy_
def bstack111l1ll11_opy_(bstack1ll1llll11_opy_, bstack11ll11111l_opy_):
  bstack1lll11ll11_opy_ = {}
  for key in bstack1ll1llll11_opy_.keys():
    if key in bstack1111111l_opy_:
      bstack1lll11ll11_opy_[bstack1111111l_opy_[key]] = bstack1ll1llll11_opy_[key]
    else:
      bstack1lll11ll11_opy_[key] = bstack1ll1llll11_opy_[key]
  for key in bstack11ll11111l_opy_:
    if key in bstack1111111l_opy_:
      bstack1lll11ll11_opy_[bstack1111111l_opy_[key]] = bstack11ll11111l_opy_[key]
    else:
      bstack1lll11ll11_opy_[key] = bstack11ll11111l_opy_[key]
  return bstack1lll11ll11_opy_
def bstack1l1ll1ll11_opy_(config, index=0):
  global bstack1l1lll1lll_opy_
  caps = {}
  config = copy.deepcopy(config)
  bstack1llll11ll_opy_ = bstack1l11ll11l1_opy_(bstack1l11ll1l1l_opy_, config, logger)
  bstack11ll11111l_opy_ = bstack1l11llllll_opy_(config)
  bstack11lllllll_opy_ = bstack11l11lll1l_opy_
  bstack11lllllll_opy_ += bstack111l1111_opy_
  bstack11ll11111l_opy_ = update(bstack11ll11111l_opy_, bstack1llll11ll_opy_)
  if bstack1l1lll1lll_opy_:
    bstack11lllllll_opy_ += bstack11111l1l_opy_
  if bstack1ll1lll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴ॒ࠩ") in config:
    if bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬ॓") in config[bstack1ll1lll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫ॔")][index]:
      caps[bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡑࡥࡲ࡫ࠧॕ")] = config[bstack1ll1lll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ॖ")][index][bstack1ll1lll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩॗ")]
    if bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡜ࡥࡳࡵ࡬ࡳࡳ࠭क़") in config[bstack1ll1lll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩख़")][index]:
      caps[bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨग़")] = str(config[bstack1ll1lll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫज़")][index][bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪड़")])
    bstack1ll111l1l1_opy_ = bstack1l11ll11l1_opy_(bstack1l11ll1l1l_opy_, config[bstack1ll1lll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ढ़")][index], logger)
    bstack11lllllll_opy_ += list(bstack1ll111l1l1_opy_.keys())
    for bstack1l1l1l1lll_opy_ in bstack11lllllll_opy_:
      if bstack1l1l1l1lll_opy_ in config[bstack1ll1lll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧफ़")][index]:
        if bstack1l1l1l1lll_opy_ == bstack1ll1lll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡖࡦࡴࡶ࡭ࡴࡴࠧय़"):
          try:
            bstack1ll111l1l1_opy_[bstack1l1l1l1lll_opy_] = str(config[bstack1ll1lll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩॠ")][index][bstack1l1l1l1lll_opy_] * 1.0)
          except:
            bstack1ll111l1l1_opy_[bstack1l1l1l1lll_opy_] = str(config[bstack1ll1lll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪॡ")][index][bstack1l1l1l1lll_opy_])
        else:
          bstack1ll111l1l1_opy_[bstack1l1l1l1lll_opy_] = config[bstack1ll1lll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫॢ")][index][bstack1l1l1l1lll_opy_]
        del (config[bstack1ll1lll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬॣ")][index][bstack1l1l1l1lll_opy_])
    bstack11ll11111l_opy_ = update(bstack11ll11111l_opy_, bstack1ll111l1l1_opy_)
  bstack1ll1llll11_opy_ = bstack1l11l1ll_opy_(config, index)
  for bstack1ll11lll_opy_ in bstack11l11lll1l_opy_ + list(bstack1llll11ll_opy_.keys()):
    if bstack1ll11lll_opy_ in bstack1ll1llll11_opy_:
      bstack11ll11111l_opy_[bstack1ll11lll_opy_] = bstack1ll1llll11_opy_[bstack1ll11lll_opy_]
      del (bstack1ll1llll11_opy_[bstack1ll11lll_opy_])
  if bstack11l1l1ll1l_opy_(config):
    bstack1ll1llll11_opy_[bstack1ll1lll_opy_ (u"ࠪࡹࡸ࡫ࡗ࠴ࡅࠪ।")] = True
    caps.update(bstack11ll11111l_opy_)
    caps[bstack1ll1lll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮࠾ࡴࡶࡴࡪࡱࡱࡷࠬ॥")] = bstack1ll1llll11_opy_
  else:
    bstack1ll1llll11_opy_[bstack1ll1lll_opy_ (u"ࠬࡻࡳࡦ࡙࠶ࡇࠬ०")] = False
    caps.update(bstack111l1ll11_opy_(bstack1ll1llll11_opy_, bstack11ll11111l_opy_))
    if bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡎࡢ࡯ࡨࠫ१") in caps:
      caps[bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࠨ२")] = caps[bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪ࠭३")]
      del (caps[bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡑࡥࡲ࡫ࠧ४")])
    if bstack1ll1lll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫ५") in caps:
      caps[bstack1ll1lll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭६")] = caps[bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡜ࡥࡳࡵ࡬ࡳࡳ࠭७")]
      del (caps[bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧ८")])
  return caps
def bstack1l1ll111_opy_():
  global bstack111ll111_opy_
  global CONFIG
  if bstack1lll1l1ll1_opy_() <= version.parse(bstack1ll1lll_opy_ (u"ࠧ࠴࠰࠴࠷࠳࠶ࠧ९")):
    if bstack111ll111_opy_ != bstack1ll1lll_opy_ (u"ࠨࠩ॰"):
      return bstack1ll1lll_opy_ (u"ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࠥॱ") + bstack111ll111_opy_ + bstack1ll1lll_opy_ (u"ࠥ࠾࠽࠶࠯ࡸࡦ࠲࡬ࡺࡨࠢॲ")
    return bstack111l1lll1_opy_
  if bstack111ll111_opy_ != bstack1ll1lll_opy_ (u"ࠫࠬॳ"):
    return bstack1ll1lll_opy_ (u"ࠧ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠢॴ") + bstack111ll111_opy_ + bstack1ll1lll_opy_ (u"ࠨ࠯ࡸࡦ࠲࡬ࡺࡨࠢॵ")
  return bstack11ll1111l_opy_
def bstack1111l111l_opy_(options):
  return hasattr(options, bstack1ll1lll_opy_ (u"ࠧࡴࡧࡷࡣࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡹࠨॶ"))
def update(d, u):
  for k, v in u.items():
    if isinstance(v, collections.abc.Mapping):
      d[k] = update(d.get(k, {}), v)
    else:
      if isinstance(v, list):
        d[k] = d.get(k, []) + v
      else:
        d[k] = v
  return d
def bstack1llll1l1l_opy_(options, bstack11llll11l1_opy_):
  for bstack1lll11ll_opy_ in bstack11llll11l1_opy_:
    if bstack1lll11ll_opy_ in [bstack1ll1lll_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭ॷ"), bstack1ll1lll_opy_ (u"ࠩࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࡸ࠭ॸ")]:
      continue
    if bstack1lll11ll_opy_ in options._experimental_options:
      options._experimental_options[bstack1lll11ll_opy_] = update(options._experimental_options[bstack1lll11ll_opy_],
                                                         bstack11llll11l1_opy_[bstack1lll11ll_opy_])
    else:
      options.add_experimental_option(bstack1lll11ll_opy_, bstack11llll11l1_opy_[bstack1lll11ll_opy_])
  if bstack1ll1lll_opy_ (u"ࠪࡥࡷ࡭ࡳࠨॹ") in bstack11llll11l1_opy_:
    for arg in bstack11llll11l1_opy_[bstack1ll1lll_opy_ (u"ࠫࡦࡸࡧࡴࠩॺ")]:
      options.add_argument(arg)
    del (bstack11llll11l1_opy_[bstack1ll1lll_opy_ (u"ࠬࡧࡲࡨࡵࠪॻ")])
  if bstack1ll1lll_opy_ (u"࠭ࡥࡹࡶࡨࡲࡸ࡯࡯࡯ࡵࠪॼ") in bstack11llll11l1_opy_:
    for ext in bstack11llll11l1_opy_[bstack1ll1lll_opy_ (u"ࠧࡦࡺࡷࡩࡳࡹࡩࡰࡰࡶࠫॽ")]:
      try:
        options.add_extension(ext)
      except OSError:
        options.add_encoded_extension(ext)
    del (bstack11llll11l1_opy_[bstack1ll1lll_opy_ (u"ࠨࡧࡻࡸࡪࡴࡳࡪࡱࡱࡷࠬॾ")])
def bstack1l1l1l1l1_opy_(options, bstack11l11111l_opy_):
  if bstack1ll1lll_opy_ (u"ࠩࡳࡶࡪ࡬ࡳࠨॿ") in bstack11l11111l_opy_:
    for bstack1l1l1lll1l_opy_ in bstack11l11111l_opy_[bstack1ll1lll_opy_ (u"ࠪࡴࡷ࡫ࡦࡴࠩঀ")]:
      if bstack1l1l1lll1l_opy_ in options._preferences:
        options._preferences[bstack1l1l1lll1l_opy_] = update(options._preferences[bstack1l1l1lll1l_opy_], bstack11l11111l_opy_[bstack1ll1lll_opy_ (u"ࠫࡵࡸࡥࡧࡵࠪঁ")][bstack1l1l1lll1l_opy_])
      else:
        options.set_preference(bstack1l1l1lll1l_opy_, bstack11l11111l_opy_[bstack1ll1lll_opy_ (u"ࠬࡶࡲࡦࡨࡶࠫং")][bstack1l1l1lll1l_opy_])
  if bstack1ll1lll_opy_ (u"࠭ࡡࡳࡩࡶࠫঃ") in bstack11l11111l_opy_:
    for arg in bstack11l11111l_opy_[bstack1ll1lll_opy_ (u"ࠧࡢࡴࡪࡷࠬ঄")]:
      options.add_argument(arg)
def bstack1ll11ll1_opy_(options, bstack11l1111111_opy_):
  if bstack1ll1lll_opy_ (u"ࠨࡹࡨࡦࡻ࡯ࡥࡸࠩঅ") in bstack11l1111111_opy_:
    options.use_webview(bool(bstack11l1111111_opy_[bstack1ll1lll_opy_ (u"ࠩࡺࡩࡧࡼࡩࡦࡹࠪআ")]))
  bstack1llll1l1l_opy_(options, bstack11l1111111_opy_)
def bstack111llll111_opy_(options, bstack111111111_opy_):
  for bstack1l11l11ll_opy_ in bstack111111111_opy_:
    if bstack1l11l11ll_opy_ in [bstack1ll1lll_opy_ (u"ࠪࡸࡪࡩࡨ࡯ࡱ࡯ࡳ࡬ࡿࡐࡳࡧࡹ࡭ࡪࡽࠧই"), bstack1ll1lll_opy_ (u"ࠫࡦࡸࡧࡴࠩঈ")]:
      continue
    options.set_capability(bstack1l11l11ll_opy_, bstack111111111_opy_[bstack1l11l11ll_opy_])
  if bstack1ll1lll_opy_ (u"ࠬࡧࡲࡨࡵࠪউ") in bstack111111111_opy_:
    for arg in bstack111111111_opy_[bstack1ll1lll_opy_ (u"࠭ࡡࡳࡩࡶࠫঊ")]:
      options.add_argument(arg)
  if bstack1ll1lll_opy_ (u"ࠧࡵࡧࡦ࡬ࡳࡵ࡬ࡰࡩࡼࡔࡷ࡫ࡶࡪࡧࡺࠫঋ") in bstack111111111_opy_:
    options.bstack1l111l11l1_opy_(bool(bstack111111111_opy_[bstack1ll1lll_opy_ (u"ࠨࡶࡨࡧ࡭ࡴ࡯࡭ࡱࡪࡽࡕࡸࡥࡷ࡫ࡨࡻࠬঌ")]))
def bstack11ll111ll_opy_(options, bstack11l1ll1l1_opy_):
  for bstack1ll1l1llll_opy_ in bstack11l1ll1l1_opy_:
    if bstack1ll1l1llll_opy_ in [bstack1ll1lll_opy_ (u"ࠩࡤࡨࡩ࡯ࡴࡪࡱࡱࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭঍"), bstack1ll1lll_opy_ (u"ࠪࡥࡷ࡭ࡳࠨ঎")]:
      continue
    options._options[bstack1ll1l1llll_opy_] = bstack11l1ll1l1_opy_[bstack1ll1l1llll_opy_]
  if bstack1ll1lll_opy_ (u"ࠫࡦࡪࡤࡪࡶ࡬ࡳࡳࡧ࡬ࡐࡲࡷ࡭ࡴࡴࡳࠨএ") in bstack11l1ll1l1_opy_:
    for bstack1ll1lll111_opy_ in bstack11l1ll1l1_opy_[bstack1ll1lll_opy_ (u"ࠬࡧࡤࡥ࡫ࡷ࡭ࡴࡴࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩঐ")]:
      options.bstack11lll111ll_opy_(
        bstack1ll1lll111_opy_, bstack11l1ll1l1_opy_[bstack1ll1lll_opy_ (u"࠭ࡡࡥࡦ࡬ࡸ࡮ࡵ࡮ࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪ঑")][bstack1ll1lll111_opy_])
  if bstack1ll1lll_opy_ (u"ࠧࡢࡴࡪࡷࠬ঒") in bstack11l1ll1l1_opy_:
    for arg in bstack11l1ll1l1_opy_[bstack1ll1lll_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭ও")]:
      options.add_argument(arg)
def bstack1lll1ll11l_opy_(options, caps):
  if not hasattr(options, bstack1ll1lll_opy_ (u"ࠩࡎࡉ࡞࠭ঔ")):
    return
  if options.KEY == bstack1ll1lll_opy_ (u"ࠪ࡫ࡴࡵࡧ࠻ࡥ࡫ࡶࡴࡳࡥࡐࡲࡷ࡭ࡴࡴࡳࠨক"):
    options = bstack1l11l1l1_opy_.bstack11l1llll_opy_(bstack1l1llll1_opy_=options, config=CONFIG)
  if options.KEY == bstack1ll1lll_opy_ (u"ࠫ࡬ࡵ࡯ࡨ࠼ࡦ࡬ࡷࡵ࡭ࡦࡑࡳࡸ࡮ࡵ࡮ࡴࠩখ") and options.KEY in caps:
    bstack1llll1l1l_opy_(options, caps[bstack1ll1lll_opy_ (u"ࠬ࡭࡯ࡰࡩ࠽ࡧ࡭ࡸ࡯࡮ࡧࡒࡴࡹ࡯࡯࡯ࡵࠪগ")])
  elif options.KEY == bstack1ll1lll_opy_ (u"࠭࡭ࡰࡼ࠽ࡪ࡮ࡸࡥࡧࡱࡻࡓࡵࡺࡩࡰࡰࡶࠫঘ") and options.KEY in caps:
    bstack1l1l1l1l1_opy_(options, caps[bstack1ll1lll_opy_ (u"ࠧ࡮ࡱࡽ࠾࡫࡯ࡲࡦࡨࡲࡼࡔࡶࡴࡪࡱࡱࡷࠬঙ")])
  elif options.KEY == bstack1ll1lll_opy_ (u"ࠨࡵࡤࡪࡦࡸࡩ࠯ࡱࡳࡸ࡮ࡵ࡮ࡴࠩচ") and options.KEY in caps:
    bstack111llll111_opy_(options, caps[bstack1ll1lll_opy_ (u"ࠩࡶࡥ࡫ࡧࡲࡪ࠰ࡲࡴࡹ࡯࡯࡯ࡵࠪছ")])
  elif options.KEY == bstack1ll1lll_opy_ (u"ࠪࡱࡸࡀࡥࡥࡩࡨࡓࡵࡺࡩࡰࡰࡶࠫজ") and options.KEY in caps:
    bstack1ll11ll1_opy_(options, caps[bstack1ll1lll_opy_ (u"ࠫࡲࡹ࠺ࡦࡦࡪࡩࡔࡶࡴࡪࡱࡱࡷࠬঝ")])
  elif options.KEY == bstack1ll1lll_opy_ (u"ࠬࡹࡥ࠻࡫ࡨࡓࡵࡺࡩࡰࡰࡶࠫঞ") and options.KEY in caps:
    bstack11ll111ll_opy_(options, caps[bstack1ll1lll_opy_ (u"࠭ࡳࡦ࠼࡬ࡩࡔࡶࡴࡪࡱࡱࡷࠬট")])
def bstack11111111_opy_(caps):
  global bstack1l1lll1lll_opy_
  if isinstance(os.environ.get(bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡉࡔࡡࡄࡔࡕࡥࡁࡖࡖࡒࡑࡆ࡚ࡅࠨঠ")), str):
    bstack1l1lll1lll_opy_ = eval(os.getenv(bstack1ll1lll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡊࡕࡢࡅࡕࡖ࡟ࡂࡗࡗࡓࡒࡇࡔࡆࠩড")))
  if bstack1l1lll1lll_opy_:
    if bstack1lll1ll1l_opy_() < version.parse(bstack1ll1lll_opy_ (u"ࠩ࠵࠲࠸࠴࠰ࠨঢ")):
      return None
    else:
      from appium.options.common.base import AppiumOptions
      options = AppiumOptions().load_capabilities(caps)
      return options
  else:
    browser = bstack1ll1lll_opy_ (u"ࠪࡧ࡭ࡸ࡯࡮ࡧࠪণ")
    if bstack1ll1lll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩত") in caps:
      browser = caps[bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠪথ")]
    elif bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࠧদ") in caps:
      browser = caps[bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࠨধ")]
    browser = str(browser).lower()
    if browser == bstack1ll1lll_opy_ (u"ࠨ࡫ࡳ࡬ࡴࡴࡥࠨন") or browser == bstack1ll1lll_opy_ (u"ࠩ࡬ࡴࡦࡪࠧ঩"):
      browser = bstack1ll1lll_opy_ (u"ࠪࡷࡦ࡬ࡡࡳ࡫ࠪপ")
    if browser == bstack1ll1lll_opy_ (u"ࠫࡸࡧ࡭ࡴࡷࡱ࡫ࠬফ"):
      browser = bstack1ll1lll_opy_ (u"ࠬࡩࡨࡳࡱࡰࡩࠬব")
    if browser not in [bstack1ll1lll_opy_ (u"࠭ࡣࡩࡴࡲࡱࡪ࠭ভ"), bstack1ll1lll_opy_ (u"ࠧࡦࡦࡪࡩࠬম"), bstack1ll1lll_opy_ (u"ࠨ࡫ࡨࠫয"), bstack1ll1lll_opy_ (u"ࠩࡶࡥ࡫ࡧࡲࡪࠩর"), bstack1ll1lll_opy_ (u"ࠪࡪ࡮ࡸࡥࡧࡱࡻࠫ঱")]:
      return None
    try:
      package = bstack1ll1lll_opy_ (u"ࠫࡸ࡫࡬ࡦࡰ࡬ࡹࡲ࠴ࡷࡦࡤࡧࡶ࡮ࡼࡥࡳ࠰ࡾࢁ࠳ࡵࡰࡵ࡫ࡲࡲࡸ࠭ল").format(browser)
      name = bstack1ll1lll_opy_ (u"ࠬࡕࡰࡵ࡫ࡲࡲࡸ࠭঳")
      browser_options = getattr(__import__(package, fromlist=[name]), name)
      options = browser_options()
      if not bstack1111l111l_opy_(options):
        return None
      for bstack1ll11lll_opy_ in caps.keys():
        options.set_capability(bstack1ll11lll_opy_, caps[bstack1ll11lll_opy_])
      bstack1lll1ll11l_opy_(options, caps)
      return options
    except Exception as e:
      logger.debug(str(e))
      return None
def bstack11l11lll1_opy_(options, bstack11ll11llll_opy_):
  if not bstack1111l111l_opy_(options):
    return
  for bstack1ll11lll_opy_ in bstack11ll11llll_opy_.keys():
    if bstack1ll11lll_opy_ in bstack111l1111_opy_:
      continue
    if bstack1ll11lll_opy_ in options._caps and type(options._caps[bstack1ll11lll_opy_]) in [dict, list]:
      options._caps[bstack1ll11lll_opy_] = update(options._caps[bstack1ll11lll_opy_], bstack11ll11llll_opy_[bstack1ll11lll_opy_])
    else:
      options.set_capability(bstack1ll11lll_opy_, bstack11ll11llll_opy_[bstack1ll11lll_opy_])
  bstack1lll1ll11l_opy_(options, bstack11ll11llll_opy_)
  if bstack1ll1lll_opy_ (u"࠭࡭ࡰࡼ࠽ࡨࡪࡨࡵࡨࡩࡨࡶࡆࡪࡤࡳࡧࡶࡷࠬ঴") in options._caps:
    if options._caps[bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬ঵")] and options._caps[bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪ࠭শ")].lower() != bstack1ll1lll_opy_ (u"ࠩࡩ࡭ࡷ࡫ࡦࡰࡺࠪষ"):
      del options._caps[bstack1ll1lll_opy_ (u"ࠪࡱࡴࢀ࠺ࡥࡧࡥࡹ࡬࡭ࡥࡳࡃࡧࡨࡷ࡫ࡳࡴࠩস")]
def bstack1lllll1l1l_opy_(proxy_config):
  if bstack1ll1lll_opy_ (u"ࠫ࡭ࡺࡴࡱࡵࡓࡶࡴࡾࡹࠨহ") in proxy_config:
    proxy_config[bstack1ll1lll_opy_ (u"ࠬࡹࡳ࡭ࡒࡵࡳࡽࡿࠧ঺")] = proxy_config[bstack1ll1lll_opy_ (u"࠭ࡨࡵࡶࡳࡷࡕࡸ࡯ࡹࡻࠪ঻")]
    del (proxy_config[bstack1ll1lll_opy_ (u"ࠧࡩࡶࡷࡴࡸࡖࡲࡰࡺࡼ়ࠫ")])
  if bstack1ll1lll_opy_ (u"ࠨࡲࡵࡳࡽࡿࡔࡺࡲࡨࠫঽ") in proxy_config and proxy_config[bstack1ll1lll_opy_ (u"ࠩࡳࡶࡴࡾࡹࡕࡻࡳࡩࠬা")].lower() != bstack1ll1lll_opy_ (u"ࠪࡨ࡮ࡸࡥࡤࡶࠪি"):
    proxy_config[bstack1ll1lll_opy_ (u"ࠫࡵࡸ࡯ࡹࡻࡗࡽࡵ࡫ࠧী")] = bstack1ll1lll_opy_ (u"ࠬࡳࡡ࡯ࡷࡤࡰࠬু")
  if bstack1ll1lll_opy_ (u"࠭ࡰࡳࡱࡻࡽࡆࡻࡴࡰࡥࡲࡲ࡫࡯ࡧࡖࡴ࡯ࠫূ") in proxy_config:
    proxy_config[bstack1ll1lll_opy_ (u"ࠧࡱࡴࡲࡼࡾ࡚ࡹࡱࡧࠪৃ")] = bstack1ll1lll_opy_ (u"ࠨࡲࡤࡧࠬৄ")
  return proxy_config
def bstack11lll1l1l1_opy_(config, proxy):
  from selenium.webdriver.common.proxy import Proxy
  if not bstack1ll1lll_opy_ (u"ࠩࡳࡶࡴࡾࡹࠨ৅") in config:
    return proxy
  config[bstack1ll1lll_opy_ (u"ࠪࡴࡷࡵࡸࡺࠩ৆")] = bstack1lllll1l1l_opy_(config[bstack1ll1lll_opy_ (u"ࠫࡵࡸ࡯ࡹࡻࠪে")])
  if proxy == None:
    proxy = Proxy(config[bstack1ll1lll_opy_ (u"ࠬࡶࡲࡰࡺࡼࠫৈ")])
  return proxy
def bstack11ll1lll1l_opy_(self):
  global CONFIG
  global bstack1l1l11111_opy_
  try:
    proxy = bstack1ll1111ll1_opy_(CONFIG)
    if proxy:
      if proxy.endswith(bstack1ll1lll_opy_ (u"࠭࠮ࡱࡣࡦࠫ৉")):
        proxies = bstack1l111l1l11_opy_(proxy, bstack1l1ll111_opy_())
        if len(proxies) > 0:
          protocol, bstack11ll1ll11_opy_ = proxies.popitem()
          if bstack1ll1lll_opy_ (u"ࠢ࠻࠱࠲ࠦ৊") in bstack11ll1ll11_opy_:
            return bstack11ll1ll11_opy_
          else:
            return bstack1ll1lll_opy_ (u"ࠣࡪࡷࡸࡵࡀ࠯࠰ࠤো") + bstack11ll1ll11_opy_
      else:
        return proxy
  except Exception as e:
    logger.error(bstack1ll1lll_opy_ (u"ࠤࡈࡶࡷࡵࡲࠡ࡫ࡱࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥࡶࡲࡰࡺࡼࠤࡺࡸ࡬ࠡ࠼ࠣࡿࢂࠨৌ").format(str(e)))
  return bstack1l1l11111_opy_(self)
def bstack1l1111111_opy_():
  global CONFIG
  return bstack1l1lllllll_opy_(CONFIG) and bstack111llllll1_opy_() and bstack1lll1l1ll1_opy_() >= version.parse(bstack1llll11l1l_opy_)
def bstack1l1lll111l_opy_():
  global CONFIG
  return (bstack1ll1lll_opy_ (u"ࠪ࡬ࡹࡺࡰࡑࡴࡲࡼࡾ্࠭") in CONFIG or bstack1ll1lll_opy_ (u"ࠫ࡭ࡺࡴࡱࡵࡓࡶࡴࡾࡹࠨৎ") in CONFIG) and bstack1111l1lll_opy_()
def bstack1l1lll1l1l_opy_(config):
  bstack11l1ll1l1l_opy_ = {}
  if bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩ৏") in config:
    bstack11l1ll1l1l_opy_ = config[bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪ৐")]
  if bstack1ll1lll_opy_ (u"ࠧ࡭ࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭৑") in config:
    bstack11l1ll1l1l_opy_ = config[bstack1ll1lll_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡏࡱࡶ࡬ࡳࡳࡹࠧ৒")]
  proxy = bstack1ll1111ll1_opy_(config)
  if proxy:
    if proxy.endswith(bstack1ll1lll_opy_ (u"ࠩ࠱ࡴࡦࡩࠧ৓")) and os.path.isfile(proxy):
      bstack11l1ll1l1l_opy_[bstack1ll1lll_opy_ (u"ࠪ࠱ࡵࡧࡣ࠮ࡨ࡬ࡰࡪ࠭৔")] = proxy
    else:
      parsed_url = None
      if proxy.endswith(bstack1ll1lll_opy_ (u"ࠫ࠳ࡶࡡࡤࠩ৕")):
        proxies = bstack1l111l1111_opy_(config, bstack1l1ll111_opy_())
        if len(proxies) > 0:
          protocol, bstack11ll1ll11_opy_ = proxies.popitem()
          if bstack1ll1lll_opy_ (u"ࠧࡀ࠯࠰ࠤ৖") in bstack11ll1ll11_opy_:
            parsed_url = urlparse(bstack11ll1ll11_opy_)
          else:
            parsed_url = urlparse(protocol + bstack1ll1lll_opy_ (u"ࠨ࠺࠰࠱ࠥৗ") + bstack11ll1ll11_opy_)
      else:
        parsed_url = urlparse(proxy)
      if parsed_url and parsed_url.hostname: bstack11l1ll1l1l_opy_[bstack1ll1lll_opy_ (u"ࠧࡱࡴࡲࡼࡾࡎ࡯ࡴࡶࠪ৘")] = str(parsed_url.hostname)
      if parsed_url and parsed_url.port: bstack11l1ll1l1l_opy_[bstack1ll1lll_opy_ (u"ࠨࡲࡵࡳࡽࡿࡐࡰࡴࡷࠫ৙")] = str(parsed_url.port)
      if parsed_url and parsed_url.username: bstack11l1ll1l1l_opy_[bstack1ll1lll_opy_ (u"ࠩࡳࡶࡴࡾࡹࡖࡵࡨࡶࠬ৚")] = str(parsed_url.username)
      if parsed_url and parsed_url.password: bstack11l1ll1l1l_opy_[bstack1ll1lll_opy_ (u"ࠪࡴࡷࡵࡸࡺࡒࡤࡷࡸ࠭৛")] = str(parsed_url.password)
  return bstack11l1ll1l1l_opy_
def bstack1l11l111l1_opy_(config):
  if bstack1ll1lll_opy_ (u"ࠫࡹ࡫ࡳࡵࡅࡲࡲࡹ࡫ࡸࡵࡑࡳࡸ࡮ࡵ࡮ࡴࠩড়") in config:
    return config[bstack1ll1lll_opy_ (u"ࠬࡺࡥࡴࡶࡆࡳࡳࡺࡥࡹࡶࡒࡴࡹ࡯࡯࡯ࡵࠪঢ়")]
  return {}
def bstack1ll1111l_opy_(caps):
  global bstack1ll1lll1l1_opy_
  if bstack1ll1lll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡀ࡯ࡱࡶ࡬ࡳࡳࡹࠧ৞") in caps:
    caps[bstack1ll1lll_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࠺ࡰࡲࡷ࡭ࡴࡴࡳࠨয়")][bstack1ll1lll_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࠧৠ")] = True
    if bstack1ll1lll1l1_opy_:
      caps[bstack1ll1lll_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠼ࡲࡴࡹ࡯࡯࡯ࡵࠪৡ")][bstack1ll1lll_opy_ (u"ࠪࡰࡴࡩࡡ࡭ࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬৢ")] = bstack1ll1lll1l1_opy_
  else:
    caps[bstack1ll1lll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡰࡴࡩࡡ࡭ࠩৣ")] = True
    if bstack1ll1lll1l1_opy_:
      caps[bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡱࡵࡣࡢ࡮ࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭৤")] = bstack1ll1lll1l1_opy_
@measure(event_name=EVENTS.bstack1111l11ll_opy_, stage=STAGE.bstack111lll1l11_opy_, bstack11lllll111_opy_=bstack1lll11111l_opy_)
def bstack11ll1lll1_opy_():
  global CONFIG
  if not bstack11ll1l1111_opy_(CONFIG) or cli.is_enabled(CONFIG):
    return
  if bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࠪ৥") in CONFIG and bstack1ll111ll11_opy_(CONFIG[bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࠫ০")]):
    if (
      bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬ১") in CONFIG
      and bstack1ll111ll11_opy_(CONFIG[bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࡍࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭২")].get(bstack1ll1lll_opy_ (u"ࠪࡷࡰ࡯ࡰࡃ࡫ࡱࡥࡷࡿࡉ࡯࡫ࡷ࡭ࡦࡲࡩࡴࡣࡷ࡭ࡴࡴࠧ৩")))
    ):
      logger.debug(bstack1ll1lll_opy_ (u"ࠦࡑࡵࡣࡢ࡮ࠣࡦ࡮ࡴࡡࡳࡻࠣࡲࡴࡺࠠࡴࡶࡤࡶࡹ࡫ࡤࠡࡣࡶࠤࡸࡱࡩࡱࡄ࡬ࡲࡦࡸࡹࡊࡰ࡬ࡸ࡮ࡧ࡬ࡪࡵࡤࡸ࡮ࡵ࡮ࠡ࡫ࡶࠤࡪࡴࡡࡣ࡮ࡨࡨࠧ৪"))
      return
    bstack11l1ll1l1l_opy_ = bstack1l1lll1l1l_opy_(CONFIG)
    bstack1lll1ll11_opy_(CONFIG[bstack1ll1lll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨ৫")], bstack11l1ll1l1l_opy_)
def bstack1lll1ll11_opy_(key, bstack11l1ll1l1l_opy_):
  global bstack1l1l11llll_opy_
  logger.info(bstack1ll1111l11_opy_)
  try:
    bstack1l1l11llll_opy_ = Local()
    bstack11llll1ll1_opy_ = {bstack1ll1lll_opy_ (u"࠭࡫ࡦࡻࠪ৬"): key}
    bstack11llll1ll1_opy_.update(bstack11l1ll1l1l_opy_)
    logger.debug(bstack1l11l1ll1_opy_.format(str(bstack11llll1ll1_opy_)).replace(key, bstack1ll1lll_opy_ (u"ࠧ࡜ࡔࡈࡈࡆࡉࡔࡆࡆࡠࠫ৭")))
    bstack1l1l11llll_opy_.start(**bstack11llll1ll1_opy_)
    if bstack1l1l11llll_opy_.isRunning():
      logger.info(bstack1llll111l1_opy_)
  except Exception as e:
    bstack1ll11ll1l_opy_(bstack1l1ll1l111_opy_.format(str(e)))
def bstack11llll1l1l_opy_():
  global bstack1l1l11llll_opy_
  if bstack1l1l11llll_opy_.isRunning():
    logger.info(bstack1ll1l11l1_opy_)
    bstack1l1l11llll_opy_.stop()
  bstack1l1l11llll_opy_ = None
def bstack1ll1ll1lll_opy_(bstack1l111l11l_opy_=[]):
  global CONFIG
  bstack1l111llll_opy_ = []
  bstack1ll1ll11ll_opy_ = [bstack1ll1lll_opy_ (u"ࠨࡱࡶࠫ৮"), bstack1ll1lll_opy_ (u"ࠩࡲࡷ࡛࡫ࡲࡴ࡫ࡲࡲࠬ৯"), bstack1ll1lll_opy_ (u"ࠪࡨࡪࡼࡩࡤࡧࡑࡥࡲ࡫ࠧৰ"), bstack1ll1lll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ৱ"), bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠪ৲"), bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧ৳")]
  try:
    for err in bstack1l111l11l_opy_:
      bstack111llll1ll_opy_ = {}
      for k in bstack1ll1ll11ll_opy_:
        val = CONFIG[bstack1ll1lll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪ৴")][int(err[bstack1ll1lll_opy_ (u"ࠨ࡫ࡱࡨࡪࡾࠧ৵")])].get(k)
        if val:
          bstack111llll1ll_opy_[k] = val
      if(err[bstack1ll1lll_opy_ (u"ࠩࡨࡶࡷࡵࡲࠨ৶")] != bstack1ll1lll_opy_ (u"ࠪࠫ৷")):
        bstack111llll1ll_opy_[bstack1ll1lll_opy_ (u"ࠫࡹ࡫ࡳࡵࡵࠪ৸")] = {
          err[bstack1ll1lll_opy_ (u"ࠬࡴࡡ࡮ࡧࠪ৹")]: err[bstack1ll1lll_opy_ (u"࠭ࡥࡳࡴࡲࡶࠬ৺")]
        }
        bstack1l111llll_opy_.append(bstack111llll1ll_opy_)
  except Exception as e:
    logger.debug(bstack1ll1lll_opy_ (u"ࠧࡆࡴࡵࡳࡷࠦࡩ࡯ࠢࡩࡳࡷࡳࡡࡵࡶ࡬ࡲ࡬ࠦࡤࡢࡶࡤࠤ࡫ࡵࡲࠡࡧࡹࡩࡳࡺ࠺ࠡࠩ৻") + str(e))
  finally:
    return bstack1l111llll_opy_
def bstack11111l1l1_opy_(file_name):
  bstack11l1111l1l_opy_ = []
  try:
    bstack1l1l1ll11l_opy_ = os.path.join(tempfile.gettempdir(), file_name)
    if os.path.exists(bstack1l1l1ll11l_opy_):
      with open(bstack1l1l1ll11l_opy_) as f:
        bstack11l1111l11_opy_ = json.load(f)
        bstack11l1111l1l_opy_ = bstack11l1111l11_opy_
      os.remove(bstack1l1l1ll11l_opy_)
    return bstack11l1111l1l_opy_
  except Exception as e:
    logger.debug(bstack1ll1lll_opy_ (u"ࠨࡇࡵࡶࡴࡸࠠࡪࡰࠣࡪ࡮ࡴࡤࡪࡰࡪࠤࡪࡸࡲࡰࡴࠣࡰ࡮ࡹࡴ࠻ࠢࠪৼ") + str(e))
    return bstack11l1111l1l_opy_
def bstack11ll11l11_opy_():
  try:
      from bstack_utils.constants import bstack11l1l1l111_opy_, EVENTS
      from bstack_utils.helper import bstack111lll1ll1_opy_, get_host_info, bstack11l1l11l_opy_
      from datetime import datetime
      from filelock import FileLock
      bstack11llllllll_opy_ = os.path.join(os.getcwd(), bstack1ll1lll_opy_ (u"ࠩ࡯ࡳ࡬࠭৽"), bstack1ll1lll_opy_ (u"ࠪ࡯ࡪࡿ࠭࡮ࡧࡷࡶ࡮ࡩࡳ࠯࡬ࡶࡳࡳ࠭৾"))
      lock = FileLock(bstack11llllllll_opy_+bstack1ll1lll_opy_ (u"ࠦ࠳ࡲ࡯ࡤ࡭ࠥ৿"))
      def bstack1l1111l11_opy_():
          try:
              with lock:
                  with open(bstack11llllllll_opy_, bstack1ll1lll_opy_ (u"ࠧࡸࠢ਀"), encoding=bstack1ll1lll_opy_ (u"ࠨࡵࡵࡨ࠰࠼ࠧਁ")) as file:
                      data = json.load(file)
                      config = {
                          bstack1ll1lll_opy_ (u"ࠢࡩࡧࡤࡨࡪࡸࡳࠣਂ"): {
                              bstack1ll1lll_opy_ (u"ࠣࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠢਃ"): bstack1ll1lll_opy_ (u"ࠤࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠧ਄"),
                          }
                      }
                      bstack1l1l1lllll_opy_ = datetime.utcnow()
                      bstack1l11l1llll_opy_ = bstack1l1l1lllll_opy_.strftime(bstack1ll1lll_opy_ (u"ࠥࠩ࡞࠳ࠥ࡮࠯ࠨࡨ࡙ࠫࡈ࠻ࠧࡐ࠾࡙ࠪ࠮ࠦࡨ࡙࡙ࠣࡉࠢਅ"))
                      bstack1l11l1l1l_opy_ = os.environ.get(bstack1ll1lll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡘࡊ࡙ࡔࡉࡗࡅࡣ࡚࡛ࡉࡅࠩਆ")) if os.environ.get(bstack1ll1lll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤ࡛ࡕࡊࡆࠪਇ")) else bstack11l1l11l_opy_.get_property(bstack1ll1lll_opy_ (u"ࠨࡳࡥ࡭ࡕࡹࡳࡏࡤࠣਈ"))
                      payload = {
                          bstack1ll1lll_opy_ (u"ࠢࡦࡸࡨࡲࡹࡥࡴࡺࡲࡨࠦਉ"): bstack1ll1lll_opy_ (u"ࠣࡵࡧ࡯ࡤ࡫ࡶࡦࡰࡷࡷࠧਊ"),
                          bstack1ll1lll_opy_ (u"ࠤࡧࡥࡹࡧࠢ਋"): {
                              bstack1ll1lll_opy_ (u"ࠥࡸࡪࡹࡴࡩࡷࡥࡣࡺࡻࡩࡥࠤ਌"): bstack1l11l1l1l_opy_,
                              bstack1ll1lll_opy_ (u"ࠦࡨࡸࡥࡢࡶࡨࡨࡤࡪࡡࡺࠤ਍"): bstack1l11l1llll_opy_,
                              bstack1ll1lll_opy_ (u"ࠧ࡫ࡶࡦࡰࡷࡣࡳࡧ࡭ࡦࠤ਎"): bstack1ll1lll_opy_ (u"ࠨࡓࡅࡍࡉࡩࡦࡺࡵࡳࡧࡓࡩࡷ࡬࡯ࡳ࡯ࡤࡲࡨ࡫ࠢਏ"),
                              bstack1ll1lll_opy_ (u"ࠢࡦࡸࡨࡲࡹࡥࡪࡴࡱࡱࠦਐ"): {
                                  bstack1ll1lll_opy_ (u"ࠣ࡯ࡨࡥࡸࡻࡲࡦࡵࠥ਑"): data,
                                  bstack1ll1lll_opy_ (u"ࠤࡶࡨࡰࡘࡵ࡯ࡋࡧࠦ਒"): bstack11l1l11l_opy_.get_property(bstack1ll1lll_opy_ (u"ࠥࡷࡩࡱࡒࡶࡰࡌࡨࠧਓ"))
                              },
                              bstack1ll1lll_opy_ (u"ࠦࡺࡹࡥࡳࡡࡧࡥࡹࡧࠢਔ"): bstack11l1l11l_opy_.get_property(bstack1ll1lll_opy_ (u"ࠧࡻࡳࡦࡴࡑࡥࡲ࡫ࠢਕ")),
                              bstack1ll1lll_opy_ (u"ࠨࡨࡰࡵࡷࡣ࡮ࡴࡦࡰࠤਖ"): get_host_info()
                          }
                      }
                      bstack11l1ll1l11_opy_ = bstack1l1111l11l_opy_(cli.config, [bstack1ll1lll_opy_ (u"ࠢࡢࡲ࡬ࡷࠧਗ"), bstack1ll1lll_opy_ (u"ࠣࡧࡧࡷࡎࡴࡳࡵࡴࡸࡱࡪࡴࡴࡢࡶ࡬ࡳࡳࠨਘ"), bstack1ll1lll_opy_ (u"ࠤࡤࡴ࡮ࠨਙ")], bstack11l1l1l111_opy_)
                      response = bstack111lll1ll1_opy_(bstack1ll1lll_opy_ (u"ࠥࡔࡔ࡙ࡔࠣਚ"), bstack11l1ll1l11_opy_, payload, config)
                      if(response.status_code >= 200 and response.status_code < 300):
                          logger.debug(bstack1ll1lll_opy_ (u"ࠦࡉࡧࡴࡢࠢࡶࡩࡳࡺࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࡰࡾࠦࡴࡰࠢࡾࢁࠥࡽࡩࡵࡪࠣࡨࡦࡺࡡࠡࡽࢀࠦਛ").format(bstack11l1l1l111_opy_, payload))
                      else:
                          logger.debug(bstack1ll1lll_opy_ (u"ࠧࡘࡥࡲࡷࡨࡷࡹࠦࡦࡢ࡫࡯ࡩࡩࠦࡦࡰࡴࠣࡿࢂࠦࡷࡪࡶ࡫ࠤࡩࡧࡴࡢࠢࡾࢁࠧਜ").format(bstack11l1l1l111_opy_, payload))
          except Exception as e:
              logger.debug(bstack1ll1lll_opy_ (u"ࠨࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡶࡩࡳࡪࠠ࡬ࡧࡼࠤࡲ࡫ࡴࡳ࡫ࡦࡷࠥࡪࡡࡵࡣࠣࡻ࡮ࡺࡨࠡࡧࡵࡶࡴࡸࠠࡼࡿࠥਝ").format(e))
      bstack1l1111l11_opy_()
      bstack11111l11l_opy_(bstack11llllllll_opy_, logger)
  except:
    pass
def bstack1l1111ll11_opy_():
  global bstack1l1l111ll_opy_
  global bstack1ll11ll1l1_opy_
  global bstack11111111l_opy_
  global bstack1l11ll111l_opy_
  global bstack11ll1l1ll_opy_
  global bstack1l11111ll_opy_
  global CONFIG
  bstack1lll1111_opy_ = os.environ.get(bstack1ll1lll_opy_ (u"ࠧࡇࡔࡄࡑࡊ࡝ࡏࡓࡍࡢ࡙ࡘࡋࡄࠨਞ"))
  if bstack1lll1111_opy_ in [bstack1ll1lll_opy_ (u"ࠨࡴࡲࡦࡴࡺࠧਟ"), bstack1ll1lll_opy_ (u"ࠩࡳࡥࡧࡵࡴࠨਠ")]:
    bstack11lll111l_opy_()
  percy.shutdown()
  if bstack1l1l111ll_opy_:
    logger.warning(bstack11l1llllll_opy_.format(str(bstack1l1l111ll_opy_)))
  else:
    try:
      bstack1lll1lll1l_opy_ = bstack11lll1l1ll_opy_(bstack1ll1lll_opy_ (u"ࠪ࠲ࡧࡹࡴࡢࡥ࡮࠱ࡨࡵ࡮ࡧ࡫ࡪ࠲࡯ࡹ࡯࡯ࠩਡ"), logger)
      if bstack1lll1lll1l_opy_.get(bstack1ll1lll_opy_ (u"ࠫࡳࡻࡤࡨࡧࡢࡰࡴࡩࡡ࡭ࠩਢ")) and bstack1lll1lll1l_opy_.get(bstack1ll1lll_opy_ (u"ࠬࡴࡵࡥࡩࡨࡣࡱࡵࡣࡢ࡮ࠪਣ")).get(bstack1ll1lll_opy_ (u"࠭ࡨࡰࡵࡷࡲࡦࡳࡥࠨਤ")):
        logger.warning(bstack11l1llllll_opy_.format(str(bstack1lll1lll1l_opy_[bstack1ll1lll_opy_ (u"ࠧ࡯ࡷࡧ࡫ࡪࡥ࡬ࡰࡥࡤࡰࠬਥ")][bstack1ll1lll_opy_ (u"ࠨࡪࡲࡷࡹࡴࡡ࡮ࡧࠪਦ")])))
    except Exception as e:
      logger.error(e)
  if cli.is_running():
    bstack1ll1l1ll11_opy_.invoke(bstack1l11l1lll1_opy_.bstack1lllll111_opy_)
  logger.info(bstack1111l11l1_opy_)
  global bstack1l1l11llll_opy_
  if bstack1l1l11llll_opy_:
    bstack11llll1l1l_opy_()
  try:
    with bstack11llllll11_opy_:
      bstack1l1l111l1l_opy_ = bstack1ll11ll1l1_opy_.copy()
    for driver in bstack1l1l111l1l_opy_:
      driver.quit()
  except Exception as e:
    pass
  logger.info(bstack11l1llll1_opy_)
  if bstack1l11111ll_opy_ == bstack1ll1lll_opy_ (u"ࠩࡵࡳࡧࡵࡴࠨਧ"):
    bstack11ll1l1ll_opy_ = bstack11111l1l1_opy_(bstack1ll1lll_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࡡࡨࡶࡷࡵࡲࡠ࡮࡬ࡷࡹ࠴ࡪࡴࡱࡱࠫਨ"))
  if bstack1l11111ll_opy_ == bstack1ll1lll_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࠫ਩") and len(bstack1l11ll111l_opy_) == 0:
    bstack1l11ll111l_opy_ = bstack11111l1l1_opy_(bstack1ll1lll_opy_ (u"ࠬࡶࡷࡠࡲࡼࡸࡪࡹࡴࡠࡧࡵࡶࡴࡸ࡟࡭࡫ࡶࡸ࠳ࡰࡳࡰࡰࠪਪ"))
    if len(bstack1l11ll111l_opy_) == 0:
      bstack1l11ll111l_opy_ = bstack11111l1l1_opy_(bstack1ll1lll_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹࡥࡰࡱࡲࡢࡩࡷࡸ࡯ࡳࡡ࡯࡭ࡸࡺ࠮࡫ࡵࡲࡲࠬਫ"))
  bstack111l1lll_opy_ = bstack1ll1lll_opy_ (u"ࠧࠨਬ")
  if len(bstack11111111l_opy_) > 0:
    bstack111l1lll_opy_ = bstack1ll1ll1lll_opy_(bstack11111111l_opy_)
  elif len(bstack1l11ll111l_opy_) > 0:
    bstack111l1lll_opy_ = bstack1ll1ll1lll_opy_(bstack1l11ll111l_opy_)
  elif len(bstack11ll1l1ll_opy_) > 0:
    bstack111l1lll_opy_ = bstack1ll1ll1lll_opy_(bstack11ll1l1ll_opy_)
  elif len(bstack11l1l1l11l_opy_) > 0:
    bstack111l1lll_opy_ = bstack1ll1ll1lll_opy_(bstack11l1l1l11l_opy_)
  if bool(bstack111l1lll_opy_):
    bstack1l1ll1llll_opy_(bstack111l1lll_opy_)
  else:
    bstack1l1ll1llll_opy_()
  bstack11111l11l_opy_(bstack1lll1lll_opy_, logger)
  if bstack1lll1111_opy_ not in [bstack1ll1lll_opy_ (u"ࠨࡴࡲࡦࡴࡺ࠭ࡪࡰࡷࡩࡷࡴࡡ࡭ࠩਭ")]:
    bstack11ll11l11_opy_()
  bstack1ll1ll1111_opy_.bstack1lll11l1_opy_(CONFIG)
  if len(bstack11ll1l1ll_opy_) > 0:
    sys.exit(len(bstack11ll1l1ll_opy_))
def bstack1l1l11l1ll_opy_(bstack111ll11ll_opy_, frame):
  global bstack11l1l11l_opy_
  logger.error(bstack11l111l11_opy_)
  bstack11l1l11l_opy_.bstack111lll111_opy_(bstack1ll1lll_opy_ (u"ࠩࡶࡨࡰࡑࡩ࡭࡮ࡑࡳࠬਮ"), bstack111ll11ll_opy_)
  if hasattr(signal, bstack1ll1lll_opy_ (u"ࠪࡗ࡮࡭࡮ࡢ࡮ࡶࠫਯ")):
    bstack11l1l11l_opy_.bstack111lll111_opy_(bstack1ll1lll_opy_ (u"ࠫࡸࡪ࡫ࡌ࡫࡯ࡰࡘ࡯ࡧ࡯ࡣ࡯ࠫਰ"), signal.Signals(bstack111ll11ll_opy_).name)
  else:
    bstack11l1l11l_opy_.bstack111lll111_opy_(bstack1ll1lll_opy_ (u"ࠬࡹࡤ࡬ࡍ࡬ࡰࡱ࡙ࡩࡨࡰࡤࡰࠬ਱"), bstack1ll1lll_opy_ (u"࠭ࡓࡊࡉࡘࡒࡐࡔࡏࡘࡐࠪਲ"))
  if cli.is_running():
    bstack1ll1l1ll11_opy_.invoke(bstack1l11l1lll1_opy_.bstack1lllll111_opy_)
  bstack1lll1111_opy_ = os.environ.get(bstack1ll1lll_opy_ (u"ࠧࡇࡔࡄࡑࡊ࡝ࡏࡓࡍࡢ࡙ࡘࡋࡄࠨਲ਼"))
  if bstack1lll1111_opy_ == bstack1ll1lll_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࠨ਴") and not cli.is_enabled(CONFIG):
    bstack1l111l111l_opy_.stop(bstack11l1l11l_opy_.get_property(bstack1ll1lll_opy_ (u"ࠩࡶࡨࡰࡑࡩ࡭࡮ࡖ࡭࡬ࡴࡡ࡭ࠩਵ")))
  bstack1l1111ll11_opy_()
  sys.exit(1)
def bstack1ll11ll1l_opy_(err):
  logger.critical(bstack1l1ll1111_opy_.format(str(err)))
  bstack1l1ll1llll_opy_(bstack1l1ll1111_opy_.format(str(err)), True)
  atexit.unregister(bstack1l1111ll11_opy_)
  bstack11lll111l_opy_()
  sys.exit(1)
def bstack11ll111lll_opy_(error, message):
  logger.critical(str(error))
  logger.critical(message)
  bstack1l1ll1llll_opy_(message, True)
  atexit.unregister(bstack1l1111ll11_opy_)
  bstack11lll111l_opy_()
  sys.exit(1)
def bstack1lll1llll1_opy_():
  global CONFIG
  global bstack11llllll_opy_
  global bstack11l1ll1l_opy_
  global bstack1l11111l1l_opy_
  CONFIG = bstack1l1l1l1ll_opy_()
  load_dotenv(CONFIG.get(bstack1ll1lll_opy_ (u"ࠪࡩࡳࡼࡆࡪ࡮ࡨࠫਸ਼")))
  bstack1ll1lll1l_opy_()
  bstack111lllll_opy_()
  CONFIG = bstack1ll1ll11l1_opy_(CONFIG)
  update(CONFIG, bstack11l1ll1l_opy_)
  update(CONFIG, bstack11llllll_opy_)
  if not cli.is_enabled(CONFIG):
    CONFIG = bstack11l11111l1_opy_(CONFIG)
  bstack1l11111l1l_opy_ = bstack11ll1l1111_opy_(CONFIG)
  os.environ[bstack1ll1lll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡅ࡚࡚ࡏࡎࡃࡗࡍࡔࡔࠧ਷")] = bstack1l11111l1l_opy_.__str__().lower()
  bstack11l1l11l_opy_.bstack111lll111_opy_(bstack1ll1lll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯ࡤࡹࡥࡴࡵ࡬ࡳࡳ࠭ਸ"), bstack1l11111l1l_opy_)
  if (bstack1ll1lll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠩਹ") in CONFIG and bstack1ll1lll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠪ਺") in bstack11llllll_opy_) or (
          bstack1ll1lll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫ਻") in CONFIG and bstack1ll1lll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩ਼ࠬ") not in bstack11l1ll1l_opy_):
    if os.getenv(bstack1ll1lll_opy_ (u"ࠪࡆࡘ࡚ࡁࡄࡍࡢࡇࡔࡓࡂࡊࡐࡈࡈࡤࡈࡕࡊࡎࡇࡣࡎࡊࠧ਽")):
      CONFIG[bstack1ll1lll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭ਾ")] = os.getenv(bstack1ll1lll_opy_ (u"ࠬࡈࡓࡕࡃࡆࡏࡤࡉࡏࡎࡄࡌࡒࡊࡊ࡟ࡃࡗࡌࡐࡉࡥࡉࡅࠩਿ"))
    else:
      if not CONFIG.get(bstack1ll1lll_opy_ (u"ࠨࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࠤੀ"), bstack1ll1lll_opy_ (u"ࠢࠣੁ")) in bstack11ll111l_opy_:
        bstack111ll1l1_opy_()
  elif (bstack1ll1lll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫੂ") not in CONFIG and bstack1ll1lll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫ੃") in CONFIG) or (
          bstack1ll1lll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭੄") in bstack11l1ll1l_opy_ and bstack1ll1lll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧ੅") not in bstack11llllll_opy_):
    del (CONFIG[bstack1ll1lll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧ੆")])
  if bstack1ll1ll11l_opy_(CONFIG):
    bstack1ll11ll1l_opy_(bstack1llllllll_opy_)
  Config.bstack1l1l111l_opy_().bstack111lll111_opy_(bstack1ll1lll_opy_ (u"ࠨࡵࡴࡧࡵࡒࡦࡳࡥࠣੇ"), CONFIG[bstack1ll1lll_opy_ (u"ࠧࡶࡵࡨࡶࡓࡧ࡭ࡦࠩੈ")])
  bstack1l11llll1l_opy_()
  bstack11111l111_opy_()
  if bstack1l1lll1lll_opy_ and not CONFIG.get(bstack1ll1lll_opy_ (u"ࠣࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࠦ੉"), bstack1ll1lll_opy_ (u"ࠤࠥ੊")) in bstack11ll111l_opy_:
    CONFIG[bstack1ll1lll_opy_ (u"ࠪࡥࡵࡶࠧੋ")] = bstack11l1l1ll1_opy_(CONFIG)
    logger.info(bstack111111ll_opy_.format(CONFIG[bstack1ll1lll_opy_ (u"ࠫࡦࡶࡰࠨੌ")]))
  if not bstack1l11111l1l_opy_:
    CONFIG[bstack1ll1lll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨ੍")] = [{}]
def bstack1l1l1111l1_opy_(config, bstack1ll1l111_opy_):
  global CONFIG
  global bstack1l1lll1lll_opy_
  CONFIG = config
  bstack1l1lll1lll_opy_ = bstack1ll1l111_opy_
def bstack11111l111_opy_():
  global CONFIG
  global bstack1l1lll1lll_opy_
  if bstack1ll1lll_opy_ (u"࠭ࡡࡱࡲࠪ੎") in CONFIG:
    try:
      from appium import version
    except Exception as e:
      bstack11ll111lll_opy_(e, bstack11l1l1l1l_opy_)
    bstack1l1lll1lll_opy_ = True
    bstack11l1l11l_opy_.bstack111lll111_opy_(bstack1ll1lll_opy_ (u"ࠧࡢࡲࡳࡣࡦࡻࡴࡰ࡯ࡤࡸࡪ࠭੏"), True)
def bstack11l1l1ll1_opy_(config):
  bstack11l11l1lll_opy_ = bstack1ll1lll_opy_ (u"ࠨࠩ੐")
  app = config[bstack1ll1lll_opy_ (u"ࠩࡤࡴࡵ࠭ੑ")]
  if isinstance(app, str):
    if os.path.splitext(app)[1] in bstack1111ll111_opy_:
      if os.path.exists(app):
        bstack11l11l1lll_opy_ = bstack1l1l1l1l11_opy_(config, app)
      elif bstack1ll1ll1ll_opy_(app):
        bstack11l11l1lll_opy_ = app
      else:
        bstack1ll11ll1l_opy_(bstack1l11lll1ll_opy_.format(app))
    else:
      if bstack1ll1ll1ll_opy_(app):
        bstack11l11l1lll_opy_ = app
      elif os.path.exists(app):
        bstack11l11l1lll_opy_ = bstack1l1l1l1l11_opy_(app)
      else:
        bstack1ll11ll1l_opy_(bstack11l1ll1ll1_opy_)
  else:
    if len(app) > 2:
      bstack1ll11ll1l_opy_(bstack11l111lll_opy_)
    elif len(app) == 2:
      if bstack1ll1lll_opy_ (u"ࠪࡴࡦࡺࡨࠨ੒") in app and bstack1ll1lll_opy_ (u"ࠫࡨࡻࡳࡵࡱࡰࡣ࡮ࡪࠧ੓") in app:
        if os.path.exists(app[bstack1ll1lll_opy_ (u"ࠬࡶࡡࡵࡪࠪ੔")]):
          bstack11l11l1lll_opy_ = bstack1l1l1l1l11_opy_(config, app[bstack1ll1lll_opy_ (u"࠭ࡰࡢࡶ࡫ࠫ੕")], app[bstack1ll1lll_opy_ (u"ࠧࡤࡷࡶࡸࡴࡳ࡟ࡪࡦࠪ੖")])
        else:
          bstack1ll11ll1l_opy_(bstack1l11lll1ll_opy_.format(app))
      else:
        bstack1ll11ll1l_opy_(bstack11l111lll_opy_)
    else:
      for key in app:
        if key in bstack11lllll1l1_opy_:
          if key == bstack1ll1lll_opy_ (u"ࠨࡲࡤࡸ࡭࠭੗"):
            if os.path.exists(app[key]):
              bstack11l11l1lll_opy_ = bstack1l1l1l1l11_opy_(config, app[key])
            else:
              bstack1ll11ll1l_opy_(bstack1l11lll1ll_opy_.format(app))
          else:
            bstack11l11l1lll_opy_ = app[key]
        else:
          bstack1ll11ll1l_opy_(bstack1llll1l1_opy_)
  return bstack11l11l1lll_opy_
def bstack1ll1ll1ll_opy_(bstack11l11l1lll_opy_):
  import re
  bstack11lll1ll_opy_ = re.compile(bstack1ll1lll_opy_ (u"ࡴࠥࡢࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹࡝ࡡ࠱ࡠ࠲ࡣࠪࠥࠤ੘"))
  bstack1l1l111111_opy_ = re.compile(bstack1ll1lll_opy_ (u"ࡵࠦࡣࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺࡞ࡢ࠲ࡡ࠳࡝ࠫ࠱࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡢ࡟࠯࡞࠰ࡡ࠯ࠪࠢਖ਼"))
  if bstack1ll1lll_opy_ (u"ࠫࡧࡹ࠺࠰࠱ࠪਗ਼") in bstack11l11l1lll_opy_ or re.fullmatch(bstack11lll1ll_opy_, bstack11l11l1lll_opy_) or re.fullmatch(bstack1l1l111111_opy_, bstack11l11l1lll_opy_):
    return True
  else:
    return False
@measure(event_name=EVENTS.bstack1l1111ll1_opy_, stage=STAGE.bstack111lll1l11_opy_, bstack11lllll111_opy_=bstack1lll11111l_opy_)
def bstack1l1l1l1l11_opy_(config, path, bstack1l1l1ll1_opy_=None):
  import requests
  from requests_toolbelt.multipart.encoder import MultipartEncoder
  import hashlib
  md5_hash = hashlib.md5(open(os.path.abspath(path), bstack1ll1lll_opy_ (u"ࠬࡸࡢࠨਜ਼")).read()).hexdigest()
  bstack1l111111_opy_ = bstack1l1lll11_opy_(md5_hash)
  bstack11l11l1lll_opy_ = None
  if bstack1l111111_opy_:
    logger.info(bstack1l11ll1l1_opy_.format(bstack1l111111_opy_, md5_hash))
    return bstack1l111111_opy_
  bstack11l1lll11_opy_ = datetime.datetime.now()
  bstack1111lll11_opy_ = MultipartEncoder(
    fields={
      bstack1ll1lll_opy_ (u"࠭ࡦࡪ࡮ࡨࠫੜ"): (os.path.basename(path), open(os.path.abspath(path), bstack1ll1lll_opy_ (u"ࠧࡳࡤࠪ੝")), bstack1ll1lll_opy_ (u"ࠨࡶࡨࡼࡹ࠵ࡰ࡭ࡣ࡬ࡲࠬਫ਼")),
      bstack1ll1lll_opy_ (u"ࠩࡦࡹࡸࡺ࡯࡮ࡡ࡬ࡨࠬ੟"): bstack1l1l1ll1_opy_
    }
  )
  response = requests.post(bstack1l11l1l1l1_opy_, data=bstack1111lll11_opy_,
                           headers={bstack1ll1lll_opy_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ੠"): bstack1111lll11_opy_.content_type},
                           auth=(config[bstack1ll1lll_opy_ (u"ࠫࡺࡹࡥࡳࡐࡤࡱࡪ࠭੡")], config[bstack1ll1lll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨ੢")]))
  try:
    res = json.loads(response.text)
    bstack11l11l1lll_opy_ = res[bstack1ll1lll_opy_ (u"࠭ࡡࡱࡲࡢࡹࡷࡲࠧ੣")]
    logger.info(bstack1l1ll1l1l_opy_.format(bstack11l11l1lll_opy_))
    bstack1l11llll11_opy_(md5_hash, bstack11l11l1lll_opy_)
    cli.bstack1ll1l111l_opy_(bstack1ll1lll_opy_ (u"ࠢࡩࡶࡷࡴ࠿ࡻࡰ࡭ࡱࡤࡨࡤࡧࡰࡱࠤ੤"), datetime.datetime.now() - bstack11l1lll11_opy_)
  except ValueError as err:
    bstack1ll11ll1l_opy_(bstack1lll11l1l1_opy_.format(str(err)))
  return bstack11l11l1lll_opy_
def bstack1l11llll1l_opy_(framework_name=None, args=None):
  global CONFIG
  global bstack1lll1ll1ll_opy_
  bstack1llllll1l1_opy_ = 1
  bstack111llll1l1_opy_ = 1
  if bstack1ll1lll_opy_ (u"ࠨࡲࡤࡶࡦࡲ࡬ࡦ࡮ࡶࡔࡪࡸࡐ࡭ࡣࡷࡪࡴࡸ࡭ࠨ੥") in CONFIG:
    bstack111llll1l1_opy_ = CONFIG[bstack1ll1lll_opy_ (u"ࠩࡳࡥࡷࡧ࡬࡭ࡧ࡯ࡷࡕ࡫ࡲࡑ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩ੦")]
  else:
    bstack111llll1l1_opy_ = bstack11ll1l1ll1_opy_(framework_name, args) or 1
  if bstack1ll1lll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭੧") in CONFIG:
    bstack1llllll1l1_opy_ = len(CONFIG[bstack1ll1lll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧ੨")])
  bstack1lll1ll1ll_opy_ = int(bstack111llll1l1_opy_) * int(bstack1llllll1l1_opy_)
def bstack11ll1l1ll1_opy_(framework_name, args):
  if framework_name == bstack1111l1111_opy_ and args and bstack1ll1lll_opy_ (u"ࠬ࠳࠭ࡱࡴࡲࡧࡪࡹࡳࡦࡵࠪ੩") in args:
      bstack1ll1l11l1l_opy_ = args.index(bstack1ll1lll_opy_ (u"࠭࠭࠮ࡲࡵࡳࡨ࡫ࡳࡴࡧࡶࠫ੪"))
      return int(args[bstack1ll1l11l1l_opy_ + 1]) or 1
  return 1
def bstack1l1lll11_opy_(md5_hash):
  try:
    from filelock import FileLock
  except ImportError:
    logger.debug(bstack1ll1lll_opy_ (u"ࠧࡧ࡫࡯ࡩࡱࡵࡣ࡬ࠢࡱࡳࡹࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦ࠮ࠣࡹࡸ࡯࡮ࡨࠢࡥࡥࡸ࡯ࡣࠡࡨ࡬ࡰࡪࠦ࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠪ੫"))
    bstack11lllllll1_opy_ = os.path.join(os.path.expanduser(bstack1ll1lll_opy_ (u"ࠨࢀࠪ੬")), bstack1ll1lll_opy_ (u"ࠩ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠩ੭"), bstack1ll1lll_opy_ (u"ࠪࡥࡵࡶࡕࡱ࡮ࡲࡥࡩࡓࡄ࠶ࡊࡤࡷ࡭࠴ࡪࡴࡱࡱࠫ੮"))
    if os.path.exists(bstack11lllllll1_opy_):
      try:
        bstack11l1ll111_opy_ = json.load(open(bstack11lllllll1_opy_, bstack1ll1lll_opy_ (u"ࠫࡷࡨࠧ੯")))
        if md5_hash in bstack11l1ll111_opy_:
          bstack11ll11lll_opy_ = bstack11l1ll111_opy_[md5_hash]
          bstack1ll111lll_opy_ = datetime.datetime.now()
          bstack11ll1l1l1l_opy_ = datetime.datetime.strptime(bstack11ll11lll_opy_[bstack1ll1lll_opy_ (u"ࠬࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨੰ")], bstack1ll1lll_opy_ (u"࠭ࠥࡥ࠱ࠨࡱ࠴࡙ࠫࠡࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠪੱ"))
          if (bstack1ll111lll_opy_ - bstack11ll1l1l1l_opy_).days > 30:
            return None
          elif version.parse(str(__version__)) > version.parse(bstack11ll11lll_opy_[bstack1ll1lll_opy_ (u"ࠧࡴࡦ࡮ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬੲ")]):
            return None
          return bstack11ll11lll_opy_[bstack1ll1lll_opy_ (u"ࠨ࡫ࡧࠫੳ")]
      except Exception as e:
        logger.debug(bstack1ll1lll_opy_ (u"ࠩࡈࡶࡷࡵࡲࠡࡴࡨࡥࡩ࡯࡮ࡨࠢࡐࡈ࠺ࠦࡨࡢࡵ࡫ࠤ࡫࡯࡬ࡦ࠼ࠣࡿࢂ࠭ੴ").format(str(e)))
    return None
  bstack11lllllll1_opy_ = os.path.join(os.path.expanduser(bstack1ll1lll_opy_ (u"ࠪࢂࠬੵ")), bstack1ll1lll_opy_ (u"ࠫ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠫ੶"), bstack1ll1lll_opy_ (u"ࠬࡧࡰࡱࡗࡳࡰࡴࡧࡤࡎࡆ࠸ࡌࡦࡹࡨ࠯࡬ࡶࡳࡳ࠭੷"))
  lock_file = bstack11lllllll1_opy_ + bstack1ll1lll_opy_ (u"࠭࠮࡭ࡱࡦ࡯ࠬ੸")
  try:
    with FileLock(lock_file, timeout=10):
      if os.path.exists(bstack11lllllll1_opy_):
        with open(bstack11lllllll1_opy_, bstack1ll1lll_opy_ (u"ࠧࡳࠩ੹")) as f:
          content = f.read().strip()
          if content:
            bstack11l1ll111_opy_ = json.loads(content)
            if md5_hash in bstack11l1ll111_opy_:
              bstack11ll11lll_opy_ = bstack11l1ll111_opy_[md5_hash]
              bstack1ll111lll_opy_ = datetime.datetime.now()
              bstack11ll1l1l1l_opy_ = datetime.datetime.strptime(bstack11ll11lll_opy_[bstack1ll1lll_opy_ (u"ࠨࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠫ੺")], bstack1ll1lll_opy_ (u"ࠩࠨࡨ࠴ࠫ࡭࠰ࠧ࡜ࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘ࠭੻"))
              if (bstack1ll111lll_opy_ - bstack11ll1l1l1l_opy_).days > 30:
                return None
              elif version.parse(str(__version__)) > version.parse(bstack11ll11lll_opy_[bstack1ll1lll_opy_ (u"ࠪࡷࡩࡱ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ੼")]):
                return None
              return bstack11ll11lll_opy_[bstack1ll1lll_opy_ (u"ࠫ࡮ࡪࠧ੽")]
      return None
  except Exception as e:
    logger.debug(bstack1ll1lll_opy_ (u"ࠬࡋࡲࡳࡱࡵࠤࡼ࡯ࡴࡩࠢࡩ࡭ࡱ࡫ࠠ࡭ࡱࡦ࡯࡮ࡴࡧࠡࡨࡲࡶࠥࡓࡄ࠶ࠢ࡫ࡥࡸ࡮࠺ࠡࡽࢀࠫ੾").format(str(e)))
    return None
def bstack1l11llll11_opy_(md5_hash, bstack11l11l1lll_opy_):
  try:
    from filelock import FileLock
  except ImportError:
    logger.debug(bstack1ll1lll_opy_ (u"࠭ࡦࡪ࡮ࡨࡰࡴࡩ࡫ࠡࡰࡲࡸࠥࡧࡶࡢ࡫࡯ࡥࡧࡲࡥ࠭ࠢࡸࡷ࡮ࡴࡧࠡࡤࡤࡷ࡮ࡩࠠࡧ࡫࡯ࡩࠥࡵࡰࡦࡴࡤࡸ࡮ࡵ࡮ࡴࠩ੿"))
    bstack1lll111l1_opy_ = os.path.join(os.path.expanduser(bstack1ll1lll_opy_ (u"ࠧࡿࠩ઀")), bstack1ll1lll_opy_ (u"ࠨ࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠨઁ"))
    if not os.path.exists(bstack1lll111l1_opy_):
      os.makedirs(bstack1lll111l1_opy_)
    bstack11lllllll1_opy_ = os.path.join(os.path.expanduser(bstack1ll1lll_opy_ (u"ࠩࢁࠫં")), bstack1ll1lll_opy_ (u"ࠪ࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࠪઃ"), bstack1ll1lll_opy_ (u"ࠫࡦࡶࡰࡖࡲ࡯ࡳࡦࡪࡍࡅ࠷ࡋࡥࡸ࡮࠮࡫ࡵࡲࡲࠬ઄"))
    bstack1111111l1_opy_ = {
      bstack1ll1lll_opy_ (u"ࠬ࡯ࡤࠨઅ"): bstack11l11l1lll_opy_,
      bstack1ll1lll_opy_ (u"࠭ࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩઆ"): datetime.datetime.strftime(datetime.datetime.now(), bstack1ll1lll_opy_ (u"ࠧࠦࡦ࠲ࠩࡲ࠵࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠫઇ")),
      bstack1ll1lll_opy_ (u"ࠨࡵࡧ࡯ࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭ઈ"): str(__version__)
    }
    try:
      bstack11l1ll111_opy_ = {}
      if os.path.exists(bstack11lllllll1_opy_):
        bstack11l1ll111_opy_ = json.load(open(bstack11lllllll1_opy_, bstack1ll1lll_opy_ (u"ࠩࡵࡦࠬઉ")))
      bstack11l1ll111_opy_[md5_hash] = bstack1111111l1_opy_
      with open(bstack11lllllll1_opy_, bstack1ll1lll_opy_ (u"ࠥࡻ࠰ࠨઊ")) as outfile:
        json.dump(bstack11l1ll111_opy_, outfile)
    except Exception as e:
      logger.debug(bstack1ll1lll_opy_ (u"ࠫࡊࡸࡲࡰࡴࠣࡹࡵࡪࡡࡵ࡫ࡱ࡫ࠥࡓࡄ࠶ࠢ࡫ࡥࡸ࡮ࠠࡧ࡫࡯ࡩ࠿ࠦࡻࡾࠩઋ").format(str(e)))
    return
  bstack1lll111l1_opy_ = os.path.join(os.path.expanduser(bstack1ll1lll_opy_ (u"ࠬࢄࠧઌ")), bstack1ll1lll_opy_ (u"࠭࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠭ઍ"))
  if not os.path.exists(bstack1lll111l1_opy_):
    os.makedirs(bstack1lll111l1_opy_)
  bstack11lllllll1_opy_ = os.path.join(os.path.expanduser(bstack1ll1lll_opy_ (u"ࠧࡿࠩ઎")), bstack1ll1lll_opy_ (u"ࠨ࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠨએ"), bstack1ll1lll_opy_ (u"ࠩࡤࡴࡵ࡛ࡰ࡭ࡱࡤࡨࡒࡊ࠵ࡉࡣࡶ࡬࠳ࡰࡳࡰࡰࠪઐ"))
  lock_file = bstack11lllllll1_opy_ + bstack1ll1lll_opy_ (u"ࠪ࠲ࡱࡵࡣ࡬ࠩઑ")
  bstack1111111l1_opy_ = {
    bstack1ll1lll_opy_ (u"ࠫ࡮ࡪࠧ઒"): bstack11l11l1lll_opy_,
    bstack1ll1lll_opy_ (u"ࠬࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨઓ"): datetime.datetime.strftime(datetime.datetime.now(), bstack1ll1lll_opy_ (u"࠭ࠥࡥ࠱ࠨࡱ࠴࡙ࠫࠡࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠪઔ")),
    bstack1ll1lll_opy_ (u"ࠧࡴࡦ࡮ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬક"): str(__version__)
  }
  try:
    with FileLock(lock_file, timeout=10):
      bstack11l1ll111_opy_ = {}
      if os.path.exists(bstack11lllllll1_opy_):
        with open(bstack11lllllll1_opy_, bstack1ll1lll_opy_ (u"ࠨࡴࠪખ")) as f:
          content = f.read().strip()
          if content:
            bstack11l1ll111_opy_ = json.loads(content)
      bstack11l1ll111_opy_[md5_hash] = bstack1111111l1_opy_
      with open(bstack11lllllll1_opy_, bstack1ll1lll_opy_ (u"ࠤࡺࠦગ")) as outfile:
        json.dump(bstack11l1ll111_opy_, outfile)
  except Exception as e:
    logger.debug(bstack1ll1lll_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠࡧ࡫࡯ࡩࠥࡲ࡯ࡤ࡭࡬ࡲ࡬ࠦࡦࡰࡴࠣࡑࡉ࠻ࠠࡩࡣࡶ࡬ࠥࡻࡰࡥࡣࡷࡩ࠿ࠦࡻࡾࠩઘ").format(str(e)))
def bstack11l11111_opy_(self):
  return
def bstack111l11ll1_opy_(self):
  return
def bstack1l1lll1ll_opy_():
  global bstack1lll1l1l1l_opy_
  bstack1lll1l1l1l_opy_ = True
@measure(event_name=EVENTS.bstack11l1l1111_opy_, stage=STAGE.bstack111lll1l11_opy_, bstack11lllll111_opy_=bstack1lll11111l_opy_)
def bstack1l1ll111l1_opy_(self):
  global bstack11111l1ll_opy_
  global bstack111l11l1_opy_
  global bstack1lll1lll1_opy_
  try:
    if bstack1ll1lll_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࠫઙ") in bstack11111l1ll_opy_ and self.session_id != None and bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠬࡺࡥࡴࡶࡖࡸࡦࡺࡵࡴࠩચ"), bstack1ll1lll_opy_ (u"࠭ࠧછ")) != bstack1ll1lll_opy_ (u"ࠧࡴ࡭࡬ࡴࡵ࡫ࡤࠨજ"):
      bstack1lll11lll1_opy_ = bstack1ll1lll_opy_ (u"ࠨࡲࡤࡷࡸ࡫ࡤࠨઝ") if len(threading.current_thread().bstackTestErrorMessages) == 0 else bstack1ll1lll_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩઞ")
      if bstack1lll11lll1_opy_ == bstack1ll1lll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪટ"):
        bstack11ll1111_opy_(logger)
      if self != None:
        bstack1l1lll1ll1_opy_(self, bstack1lll11lll1_opy_, bstack1ll1lll_opy_ (u"ࠫ࠱ࠦࠧઠ").join(threading.current_thread().bstackTestErrorMessages))
    threading.current_thread().testStatus = bstack1ll1lll_opy_ (u"ࠬ࠭ડ")
    if bstack1ll1lll_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭ઢ") in bstack11111l1ll_opy_ and getattr(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠧࡢ࠳࠴ࡽࡕࡲࡡࡵࡨࡲࡶࡲ࠭ણ"), None):
      bstack11lll1l111_opy_.bstack111ll11l1_opy_(self, bstack11ll1lll11_opy_, logger, wait=True)
    if bstack1ll1lll_opy_ (u"ࠨࡤࡨ࡬ࡦࡼࡥࠨત") in bstack11111l1ll_opy_:
      if not threading.currentThread().behave_test_status:
        bstack1l1lll1ll1_opy_(self, bstack1ll1lll_opy_ (u"ࠤࡳࡥࡸࡹࡥࡥࠤથ"))
      bstack1ll111l11l_opy_.bstack11111ll1l_opy_(self)
  except Exception as e:
    logger.debug(bstack1ll1lll_opy_ (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡬࡮ࡲࡥࠡ࡯ࡤࡶࡰ࡯࡮ࡨࠢࡶࡸࡦࡺࡵࡴ࠼ࠣࠦદ") + str(e))
  bstack1lll1lll1_opy_(self)
  self.session_id = None
def bstack11l11ll11_opy_(self, *args, **kwargs):
  try:
    from selenium.webdriver.remote.remote_connection import RemoteConnection
    from bstack_utils.helper import bstack1l11ll11ll_opy_
    global bstack11111l1ll_opy_
    command_executor = kwargs.get(bstack1ll1lll_opy_ (u"ࠫࡨࡵ࡭࡮ࡣࡱࡨࡤ࡫ࡸࡦࡥࡸࡸࡴࡸࠧધ"), bstack1ll1lll_opy_ (u"ࠬ࠭ન"))
    bstack1llll1l1l1_opy_ = False
    if type(command_executor) == str and bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡩ࡯࡮ࠩ઩") in command_executor:
      bstack1llll1l1l1_opy_ = True
    elif isinstance(command_executor, RemoteConnection) and bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡣࡰ࡯ࠪપ") in str(getattr(command_executor, bstack1ll1lll_opy_ (u"ࠨࡡࡸࡶࡱ࠭ફ"), bstack1ll1lll_opy_ (u"ࠩࠪબ"))):
      bstack1llll1l1l1_opy_ = True
    else:
      kwargs = bstack1l11l1l1_opy_.bstack11l1llll_opy_(bstack1l1llll1_opy_=kwargs, config=CONFIG)
      return bstack1111ll1l_opy_(self, *args, **kwargs)
    if bstack1llll1l1l1_opy_:
      bstack11l1l1l1ll_opy_ = bstack1llll1111_opy_.bstack11l11l1l_opy_(CONFIG, bstack11111l1ll_opy_)
      if kwargs.get(bstack1ll1lll_opy_ (u"ࠪࡳࡵࡺࡩࡰࡰࡶࠫભ")):
        kwargs[bstack1ll1lll_opy_ (u"ࠫࡴࡶࡴࡪࡱࡱࡷࠬમ")] = bstack1l11ll11ll_opy_(kwargs[bstack1ll1lll_opy_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࡸ࠭ય")], bstack11111l1ll_opy_, CONFIG, bstack11l1l1l1ll_opy_)
      elif kwargs.get(bstack1ll1lll_opy_ (u"࠭ࡤࡦࡵ࡬ࡶࡪࡪ࡟ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸ࠭ર")):
        kwargs[bstack1ll1lll_opy_ (u"ࠧࡥࡧࡶ࡭ࡷ࡫ࡤࡠࡥࡤࡴࡦࡨࡩ࡭࡫ࡷ࡭ࡪࡹࠧ઱")] = bstack1l11ll11ll_opy_(kwargs[bstack1ll1lll_opy_ (u"ࠨࡦࡨࡷ࡮ࡸࡥࡥࡡࡦࡥࡵࡧࡢࡪ࡮࡬ࡸ࡮࡫ࡳࠨલ")], bstack11111l1ll_opy_, CONFIG, bstack11l1l1l1ll_opy_)
  except Exception as e:
    logger.error(bstack1ll1lll_opy_ (u"ࠤࡈࡶࡷࡵࡲࠡࡹ࡫ࡩࡳࠦࡰࡳࡱࡦࡩࡸࡹࡩ࡯ࡩࠣࡗࡉࡑࠠࡤࡣࡳࡷ࠿ࠦࡻࡾࠤળ").format(str(e)))
  return bstack1111ll1l_opy_(self, *args, **kwargs)
@measure(event_name=EVENTS.bstack11lll111_opy_, stage=STAGE.bstack111lll1l11_opy_, bstack11lllll111_opy_=bstack1lll11111l_opy_)
def bstack1l1l1ll111_opy_(self, command_executor=bstack1ll1lll_opy_ (u"ࠥ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠴࠵࠶࠷ࠦ઴"), *args, **kwargs):
  global bstack111l11l1_opy_
  global bstack1ll11ll1l1_opy_
  bstack1l1l1lll1_opy_ = bstack11l11ll11_opy_(self, command_executor=command_executor, *args, **kwargs)
  if not bstack11l11ll1l1_opy_.on():
    return bstack1l1l1lll1_opy_
  try:
    logger.debug(bstack1ll1lll_opy_ (u"ࠫࡈࡵ࡭࡮ࡣࡱࡨࠥࡋࡸࡦࡥࡸࡸࡴࡸࠠࡸࡪࡨࡲࠥࡈࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࠤࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠡ࡫ࡶࠤ࡫ࡧ࡬ࡴࡧࠣ࠱ࠥࢁࡽࠨવ").format(str(command_executor)))
    logger.debug(bstack1ll1lll_opy_ (u"ࠬࡎࡵࡣࠢࡘࡖࡑࠦࡩࡴࠢ࠰ࠤࢀࢃࠧશ").format(str(command_executor._url)))
    from selenium.webdriver.remote.remote_connection import RemoteConnection
    if isinstance(command_executor, RemoteConnection) and bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡩ࡯࡮ࠩષ") in command_executor._url:
      bstack11l1l11l_opy_.bstack111lll111_opy_(bstack1ll1lll_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨસ"), True)
  except:
    pass
  if (isinstance(command_executor, str) and bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡤࡱࡰࠫહ") in command_executor):
    bstack11l1l11l_opy_.bstack111lll111_opy_(bstack1ll1lll_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡡࡶࡩࡸࡹࡩࡰࡰࠪ઺"), True)
  threading.current_thread().bstackSessionDriver = self
  bstack1ll1l1l11_opy_ = getattr(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭ࡗࡩࡸࡺࡍࡦࡶࡤࠫ઻"), None)
  bstack11l1l11111_opy_ = {}
  if self.capabilities is not None:
    bstack11l1l11111_opy_[bstack1ll1lll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡤࡴࡡ࡮ࡧ઼ࠪ")] = self.capabilities.get(bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠪઽ"))
    bstack11l1l11111_opy_[bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨા")] = self.capabilities.get(bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨિ"))
    bstack11l1l11111_opy_[bstack1ll1lll_opy_ (u"ࠨࡥ࡫ࡶࡴࡳࡥࡠࡱࡳࡸ࡮ࡵ࡮ࡴࠩી")] = self.capabilities.get(bstack1ll1lll_opy_ (u"ࠩࡪࡳࡴ࡭࠺ࡤࡪࡵࡳࡲ࡫ࡏࡱࡶ࡬ࡳࡳࡹࠧુ"))
  if CONFIG.get(bstack1ll1lll_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪૂ"), False) and bstack1l11l1l1_opy_.bstack11l11lll11_opy_(bstack11l1l11111_opy_):
    threading.current_thread().a11yPlatform = True
  if bstack1ll1lll_opy_ (u"ࠫࡧ࡫ࡨࡢࡸࡨࠫૃ") in bstack11111l1ll_opy_ or bstack1ll1lll_opy_ (u"ࠬࡸ࡯ࡣࡱࡷࠫૄ") in bstack11111l1ll_opy_:
    bstack1l111l111l_opy_.bstack1llll1lll1_opy_(self)
  if bstack1ll1lll_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭ૅ") in bstack11111l1ll_opy_ and bstack1ll1l1l11_opy_ and bstack1ll1l1l11_opy_.get(bstack1ll1lll_opy_ (u"ࠧࡴࡶࡤࡸࡺࡹࠧ૆"), bstack1ll1lll_opy_ (u"ࠨࠩે")) == bstack1ll1lll_opy_ (u"ࠩࡳࡩࡳࡪࡩ࡯ࡩࠪૈ"):
    bstack1l111l111l_opy_.bstack1llll1lll1_opy_(self)
  bstack111l11l1_opy_ = self.session_id
  with bstack11llllll11_opy_:
    bstack1ll11ll1l1_opy_.append(self)
  return bstack1l1l1lll1_opy_
def bstack1l111lll11_opy_(args):
  return bstack1ll1lll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵࠫૉ") in str(args)
def bstack1ll1l11111_opy_(self, driver_command, *args, **kwargs):
  global bstack11ll1l1l_opy_
  global bstack11l11l1l11_opy_
  bstack11111ll1_opy_ = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠫ࡮ࡹࡁ࠲࠳ࡼࡘࡪࡹࡴࠨ૊"), None) and bstack11l1l1lll_opy_(
          threading.current_thread(), bstack1ll1lll_opy_ (u"ࠬࡧ࠱࠲ࡻࡓࡰࡦࡺࡦࡰࡴࡰࠫો"), None)
  bstack1l11l11l1_opy_ = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"࠭ࡩࡴࡃࡳࡴࡆ࠷࠱ࡺࡖࡨࡷࡹ࠭ૌ"), None) and bstack11l1l1lll_opy_(
          threading.current_thread(), bstack1ll1lll_opy_ (u"ࠧࡢࡲࡳࡅ࠶࠷ࡹࡑ࡮ࡤࡸ࡫ࡵࡲ࡮્ࠩ"), None)
  bstack1l1111l1l1_opy_ = getattr(self, bstack1ll1lll_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫ࡂ࠳࠴ࡽࡘ࡮࡯ࡶ࡮ࡧࡗࡨࡧ࡮ࠨ૎"), None) != None and getattr(self, bstack1ll1lll_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡃ࠴࠵ࡾ࡙ࡨࡰࡷ࡯ࡨࡘࡩࡡ࡯ࠩ૏"), None) == True
  if not bstack11l11l1l11_opy_ and bstack1ll1lll_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪૐ") in CONFIG and CONFIG[bstack1ll1lll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠫ૑")] == True and bstack1l11llll_opy_.bstack1ll1l1l11l_opy_(driver_command) and (bstack1l1111l1l1_opy_ or bstack11111ll1_opy_ or bstack1l11l11l1_opy_) and not bstack1l111lll11_opy_(args):
    try:
      bstack11l11l1l11_opy_ = True
      logger.debug(bstack1ll1lll_opy_ (u"ࠬࡖࡥࡳࡨࡲࡶࡲ࡯࡮ࡨࠢࡶࡧࡦࡴࠠࡧࡱࡵࠤࢀࢃࠧ૒").format(driver_command))
      logger.debug(perform_scan(self, driver_command=driver_command))
    except Exception as err:
      logger.debug(bstack1ll1lll_opy_ (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡳࡩࡷ࡬࡯ࡳ࡯ࠣࡷࡨࡧ࡮ࠡࡽࢀࠫ૓").format(str(err)))
    bstack11l11l1l11_opy_ = False
  response = bstack11ll1l1l_opy_(self, driver_command, *args, **kwargs)
  if (bstack1ll1lll_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠭૔") in str(bstack11111l1ll_opy_).lower() or bstack1ll1lll_opy_ (u"ࠨࡤࡨ࡬ࡦࡼࡥࠨ૕") in str(bstack11111l1ll_opy_).lower()) and bstack11l11ll1l1_opy_.on():
    try:
      if driver_command == bstack1ll1lll_opy_ (u"ࠩࡶࡧࡷ࡫ࡥ࡯ࡵ࡫ࡳࡹ࠭૖"):
        bstack1l111l111l_opy_.bstack1l111llll1_opy_({
            bstack1ll1lll_opy_ (u"ࠪ࡭ࡲࡧࡧࡦࠩ૗"): response[bstack1ll1lll_opy_ (u"ࠫࡻࡧ࡬ࡶࡧࠪ૘")],
            bstack1ll1lll_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬ૙"): bstack1l111l111l_opy_.current_test_uuid() if bstack1l111l111l_opy_.current_test_uuid() else bstack11l11ll1l1_opy_.current_hook_uuid()
        })
    except:
      pass
  return response
@measure(event_name=EVENTS.bstack1l1ll11ll_opy_, stage=STAGE.bstack111lll1l11_opy_, bstack11lllll111_opy_=bstack1lll11111l_opy_)
def bstack1l1ll1ll1l_opy_(self, command_executor,
             desired_capabilities=None, browser_profile=None, proxy=None,
             keep_alive=True, file_detector=None, options=None, *args, **kwargs):
  global CONFIG
  global bstack111l11l1_opy_
  global bstack1lllll1ll1_opy_
  global bstack1lll11111l_opy_
  global bstack11llll1l11_opy_
  global bstack1l1l1111_opy_
  global bstack11111l1ll_opy_
  global bstack1111ll1l_opy_
  global bstack1ll11ll1l1_opy_
  global bstack1ll11l111_opy_
  global bstack11ll1lll11_opy_
  if os.getenv(bstack1ll1lll_opy_ (u"࠭ࡂࡔࡡࡄ࠵࠶࡟࡟ࡋ࡙ࡗࠫ૚")) is not None and bstack1l11l1l1_opy_.bstack111lll11_opy_(CONFIG) is None:
    CONFIG[bstack1ll1lll_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠧ૛")] = True
  CONFIG[bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡓࡅࡍࠪ૜")] = str(bstack11111l1ll_opy_) + str(__version__)
  bstack1ll1lllll_opy_ = os.environ[bstack1ll1lll_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡎࡕࡃࡡࡘ࡙ࡎࡊࠧ૝")]
  bstack11l1l1l1ll_opy_ = bstack1llll1111_opy_.bstack11l11l1l_opy_(CONFIG, bstack11111l1ll_opy_)
  CONFIG[bstack1ll1lll_opy_ (u"ࠪࡸࡪࡹࡴࡩࡷࡥࡆࡺ࡯࡬ࡥࡗࡸ࡭ࡩ࠭૞")] = bstack1ll1lllll_opy_
  CONFIG[bstack1ll1lll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡓࡶࡴࡪࡵࡤࡶࡐࡥࡵ࠭૟")] = bstack11l1l1l1ll_opy_
  if CONFIG.get(bstack1ll1lll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࡔࡶࡴࡪࡱࡱࡷࠬૠ"),bstack1ll1lll_opy_ (u"࠭ࠧૡ")) and bstack1ll1lll_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠭ૢ") in bstack11111l1ll_opy_:
    CONFIG[bstack1ll1lll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࡐࡲࡷ࡭ࡴࡴࡳࠨૣ")].pop(bstack1ll1lll_opy_ (u"ࠩ࡬ࡲࡨࡲࡵࡥࡧࡗࡥ࡬ࡹࡉ࡯ࡖࡨࡷࡹ࡯࡮ࡨࡕࡦࡳࡵ࡫ࠧ૤"), None)
    CONFIG[bstack1ll1lll_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࡒࡴࡹ࡯࡯࡯ࡵࠪ૥")].pop(bstack1ll1lll_opy_ (u"ࠫࡪࡾࡣ࡭ࡷࡧࡩ࡙ࡧࡧࡴࡋࡱࡘࡪࡹࡴࡪࡰࡪࡗࡨࡵࡰࡦࠩ૦"), None)
  command_executor = bstack1l1ll111_opy_()
  logger.debug(bstack1l1ll1l11l_opy_.format(command_executor))
  proxy = bstack11lll1l1l1_opy_(CONFIG, proxy)
  bstack1l1ll11lll_opy_ = 0 if bstack1lllll1ll1_opy_ < 0 else bstack1lllll1ll1_opy_
  try:
    if bstack11llll1l11_opy_ is True:
      bstack1l1ll11lll_opy_ = int(multiprocessing.current_process().name)
    elif bstack1l1l1111_opy_ is True:
      bstack1l1ll11lll_opy_ = int(threading.current_thread().name)
  except:
    bstack1l1ll11lll_opy_ = 0
  bstack11ll11llll_opy_ = bstack1l1ll1ll11_opy_(CONFIG, bstack1l1ll11lll_opy_)
  logger.debug(bstack1lll1111ll_opy_.format(str(bstack11ll11llll_opy_)))
  if bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࠩ૧") in CONFIG and bstack1ll111ll11_opy_(CONFIG[bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࠪ૨")]):
    bstack1ll1111l_opy_(bstack11ll11llll_opy_)
  if bstack1l11l1l1_opy_.bstack11l1111lll_opy_(CONFIG, bstack1l1ll11lll_opy_) and bstack1l11l1l1_opy_.bstack1lll11l11_opy_(bstack11ll11llll_opy_, options, desired_capabilities, CONFIG):
    threading.current_thread().a11yPlatform = True
    if (cli.accessibility is None or not cli.accessibility.is_enabled()):
      bstack1l11l1l1_opy_.set_capabilities(bstack11ll11llll_opy_, CONFIG)
  if desired_capabilities:
    bstack1ll1l1lll1_opy_ = bstack1ll1ll11l1_opy_(desired_capabilities)
    bstack1ll1l1lll1_opy_[bstack1ll1lll_opy_ (u"ࠧࡶࡵࡨ࡛࠸ࡉࠧ૩")] = bstack11l1l1ll1l_opy_(CONFIG)
    bstack1lll1l1111_opy_ = bstack1l1ll1ll11_opy_(bstack1ll1l1lll1_opy_)
    if bstack1lll1l1111_opy_:
      bstack11ll11llll_opy_ = update(bstack1lll1l1111_opy_, bstack11ll11llll_opy_)
    desired_capabilities = None
  if options:
    bstack11l11lll1_opy_(options, bstack11ll11llll_opy_)
  if not options:
    options = bstack11111111_opy_(bstack11ll11llll_opy_)
  bstack11ll1lll11_opy_ = CONFIG.get(bstack1ll1lll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫ૪"))[bstack1l1ll11lll_opy_]
  if proxy and bstack1lll1l1ll1_opy_() >= version.parse(bstack1ll1lll_opy_ (u"ࠩ࠷࠲࠶࠶࠮࠱ࠩ૫")):
    options.proxy(proxy)
  if options and bstack1lll1l1ll1_opy_() >= version.parse(bstack1ll1lll_opy_ (u"ࠪ࠷࠳࠾࠮࠱ࠩ૬")):
    desired_capabilities = None
  if (
          not options and not desired_capabilities
  ) or (
          bstack1lll1l1ll1_opy_() < version.parse(bstack1ll1lll_opy_ (u"ࠫ࠸࠴࠸࠯࠲ࠪ૭")) and not desired_capabilities
  ):
    desired_capabilities = {}
    desired_capabilities.update(bstack11ll11llll_opy_)
  logger.info(bstack1l1llll1l_opy_)
  bstack11llll1111_opy_.end(EVENTS.bstack11ll1l1l11_opy_.value, EVENTS.bstack11ll1l1l11_opy_.value + bstack1ll1lll_opy_ (u"ࠧࡀࡳࡵࡣࡵࡸࠧ૮"), EVENTS.bstack11ll1l1l11_opy_.value + bstack1ll1lll_opy_ (u"ࠨ࠺ࡦࡰࡧࠦ૯"), status=True, failure=None, test_name=bstack1lll11111l_opy_)
  if bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡠࡲࡵࡳ࡫࡯࡬ࡦࠩ૰") in kwargs:
    del kwargs[bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡡࡳࡶࡴ࡬ࡩ࡭ࡧࠪ૱")]
  try:
    if bstack1lll1l1ll1_opy_() >= version.parse(bstack1ll1lll_opy_ (u"ࠩ࠷࠲࠶࠶࠮࠱ࠩ૲")):
      bstack1111ll1l_opy_(self, command_executor=command_executor,
                options=options, keep_alive=keep_alive, file_detector=file_detector, *args, **kwargs)
    elif bstack1lll1l1ll1_opy_() >= version.parse(bstack1ll1lll_opy_ (u"ࠪ࠷࠳࠾࠮࠱ࠩ૳")):
      bstack1111ll1l_opy_(self, command_executor=command_executor,
                desired_capabilities=desired_capabilities, options=options,
                browser_profile=browser_profile, proxy=proxy,
                keep_alive=keep_alive, file_detector=file_detector)
    elif bstack1lll1l1ll1_opy_() >= version.parse(bstack1ll1lll_opy_ (u"ࠫ࠷࠴࠵࠴࠰࠳ࠫ૴")):
      bstack1111ll1l_opy_(self, command_executor=command_executor,
                desired_capabilities=desired_capabilities,
                browser_profile=browser_profile, proxy=proxy,
                keep_alive=keep_alive, file_detector=file_detector)
    else:
      bstack1111ll1l_opy_(self, command_executor=command_executor,
                desired_capabilities=desired_capabilities,
                browser_profile=browser_profile, proxy=proxy,
                keep_alive=keep_alive)
  except Exception as bstack1llll1111l_opy_:
    logger.error(bstack1lll1l11l_opy_.format(bstack1ll1lll_opy_ (u"ࠬࡈࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࠫ૵"), str(bstack1llll1111l_opy_)))
    raise bstack1llll1111l_opy_
  if bstack1l11l1l1_opy_.bstack11l1111lll_opy_(CONFIG, bstack1l1ll11lll_opy_) and bstack1l11l1l1_opy_.bstack1lll11l11_opy_(self.caps, options, desired_capabilities):
    if CONFIG[bstack1ll1lll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡕࡸ࡯ࡥࡷࡦࡸࡒࡧࡰࠨ૶")][bstack1ll1lll_opy_ (u"ࠧࡢࡲࡳࡣࡦࡻࡴࡰ࡯ࡤࡸࡪ࠭૷")] == True:
      threading.current_thread().appA11yPlatform = True
      if cli.accessibility is None or not cli.accessibility.is_enabled():
        bstack1l11l1l1_opy_.set_capabilities(bstack11ll11llll_opy_, CONFIG)
  try:
    bstack1111lll1_opy_ = bstack1ll1lll_opy_ (u"ࠨࠩ૸")
    if bstack1lll1l1ll1_opy_() >= version.parse(bstack1ll1lll_opy_ (u"ࠩ࠷࠲࠵࠴࠰ࡣ࠳ࠪૹ")):
      if self.caps is not None:
        bstack1111lll1_opy_ = self.caps.get(bstack1ll1lll_opy_ (u"ࠥࡳࡵࡺࡩ࡮ࡣ࡯ࡌࡺࡨࡕࡳ࡮ࠥૺ"))
    else:
      if self.capabilities is not None:
        bstack1111lll1_opy_ = self.capabilities.get(bstack1ll1lll_opy_ (u"ࠦࡴࡶࡴࡪ࡯ࡤࡰࡍࡻࡢࡖࡴ࡯ࠦૻ"))
    if bstack1111lll1_opy_:
      bstack11lllll11_opy_(bstack1111lll1_opy_)
      if bstack1lll1l1ll1_opy_() <= version.parse(bstack1ll1lll_opy_ (u"ࠬ࠹࠮࠲࠵࠱࠴ࠬૼ")):
        self.command_executor._url = bstack1ll1lll_opy_ (u"ࠨࡨࡵࡶࡳ࠾࠴࠵ࠢ૽") + bstack111ll111_opy_ + bstack1ll1lll_opy_ (u"ࠢ࠻࠺࠳࠳ࡼࡪ࠯ࡩࡷࡥࠦ૾")
      else:
        self.command_executor._url = bstack1ll1lll_opy_ (u"ࠣࡪࡷࡸࡵࡹ࠺࠰࠱ࠥ૿") + bstack1111lll1_opy_ + bstack1ll1lll_opy_ (u"ࠤ࠲ࡻࡩ࠵ࡨࡶࡤࠥ଀")
      logger.debug(bstack1l111lll1l_opy_.format(bstack1111lll1_opy_))
    else:
      logger.debug(bstack11ll1ll111_opy_.format(bstack1ll1lll_opy_ (u"ࠥࡓࡵࡺࡩ࡮ࡣ࡯ࠤࡍࡻࡢࠡࡰࡲࡸࠥ࡬࡯ࡶࡰࡧࠦଁ")))
  except Exception as e:
    logger.debug(bstack11ll1ll111_opy_.format(e))
  if bstack1ll1lll_opy_ (u"ࠫࡷࡵࡢࡰࡶࠪଂ") in bstack11111l1ll_opy_:
    bstack111llll11l_opy_(bstack1lllll1ll1_opy_, bstack1ll11l111_opy_)
  bstack111l11l1_opy_ = self.session_id
  if bstack1ll1lll_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸࠬଃ") in bstack11111l1ll_opy_ or bstack1ll1lll_opy_ (u"࠭ࡢࡦࡪࡤࡺࡪ࠭଄") in bstack11111l1ll_opy_ or bstack1ll1lll_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠭ଅ") in bstack11111l1ll_opy_:
    threading.current_thread().bstackSessionId = self.session_id
    threading.current_thread().bstackSessionDriver = self
    threading.current_thread().bstackTestErrorMessages = []
  bstack1ll1l1l11_opy_ = getattr(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫ࡕࡧࡶࡸࡒ࡫ࡴࡢࠩଆ"), None)
  if bstack1ll1lll_opy_ (u"ࠩࡥࡩ࡭ࡧࡶࡦࠩଇ") in bstack11111l1ll_opy_ or bstack1ll1lll_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩଈ") in bstack11111l1ll_opy_:
    bstack1l111l111l_opy_.bstack1llll1lll1_opy_(self)
  if bstack1ll1lll_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࠫଉ") in bstack11111l1ll_opy_ and bstack1ll1l1l11_opy_ and bstack1ll1l1l11_opy_.get(bstack1ll1lll_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬଊ"), bstack1ll1lll_opy_ (u"࠭ࠧଋ")) == bstack1ll1lll_opy_ (u"ࠧࡱࡧࡱࡨ࡮ࡴࡧࠨଌ"):
    bstack1l111l111l_opy_.bstack1llll1lll1_opy_(self)
  with bstack11llllll11_opy_:
    bstack1ll11ll1l1_opy_.append(self)
  if bstack1ll1lll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫ଍") in CONFIG and bstack1ll1lll_opy_ (u"ࠩࡶࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧ଎") in CONFIG[bstack1ll1lll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ଏ")][bstack1l1ll11lll_opy_]:
    bstack1lll11111l_opy_ = CONFIG[bstack1ll1lll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧଐ")][bstack1l1ll11lll_opy_][bstack1ll1lll_opy_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪ଑")]
  logger.debug(bstack1lllllllll_opy_.format(bstack111l11l1_opy_))
try:
  try:
    import Browser
    from subprocess import Popen
    from browserstack_sdk.__init__ import bstack1ll11ll11l_opy_
    def bstack11l1ll11l1_opy_(self, args, bufsize=-1, executable=None,
              stdin=None, stdout=None, stderr=None,
              preexec_fn=None, close_fds=True,
              shell=False, cwd=None, env=None, universal_newlines=None,
              startupinfo=None, creationflags=0,
              restore_signals=True, start_new_session=False,
              pass_fds=(), *, user=None, group=None, extra_groups=None,
              encoding=None, errors=None, text=None, umask=-1, pipesize=-1):
      global CONFIG
      global bstack1ll11llll1_opy_
      if(bstack1ll1lll_opy_ (u"ࠨࡩ࡯ࡦࡨࡼ࠳ࡰࡳࠣ଒") in args[1]):
        with open(os.path.join(os.path.expanduser(bstack1ll1lll_opy_ (u"ࠧࡿࠩଓ")), bstack1ll1lll_opy_ (u"ࠨ࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠨଔ"), bstack1ll1lll_opy_ (u"ࠩ࠱ࡷࡪࡹࡳࡪࡱࡱ࡭ࡩࡹ࠮ࡵࡺࡷࠫକ")), bstack1ll1lll_opy_ (u"ࠪࡻࠬଖ")) as fp:
          fp.write(bstack1ll1lll_opy_ (u"ࠦࠧଗ"))
        if(not os.path.exists(os.path.join(os.path.dirname(args[1]), bstack1ll1lll_opy_ (u"ࠧ࡯࡮ࡥࡧࡻࡣࡧࡹࡴࡢࡥ࡮࠲࡯ࡹࠢଘ")))):
          with open(args[1], bstack1ll1lll_opy_ (u"࠭ࡲࠨଙ")) as f:
            lines = f.readlines()
            index = next((i for i, line in enumerate(lines) if bstack1ll1lll_opy_ (u"ࠧࡢࡵࡼࡲࡨࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡࡡࡱࡩࡼࡖࡡࡨࡧࠫࡧࡴࡴࡴࡦࡺࡷ࠰ࠥࡶࡡࡨࡧࠣࡁࠥࡼ࡯ࡪࡦࠣ࠴࠮࠭ଚ") in line), None)
            if index is not None:
                lines.insert(index+2, bstack11l11l1l1l_opy_)
            if bstack1ll1lll_opy_ (u"ࠨࡶࡸࡶࡧࡵࡓࡤࡣ࡯ࡩࠬଛ") in CONFIG and str(CONFIG[bstack1ll1lll_opy_ (u"ࠩࡷࡹࡷࡨ࡯ࡔࡥࡤࡰࡪ࠭ଜ")]).lower() != bstack1ll1lll_opy_ (u"ࠪࡪࡦࡲࡳࡦࠩଝ"):
                bstack1l11l1111l_opy_ = bstack1ll11ll11l_opy_()
                bstack1l111ll11l_opy_ = bstack1ll1lll_opy_ (u"ࠫࠬ࠭ࠊ࠰ࠬࠣࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃࠠࠫ࠱ࠍࡧࡴࡴࡳࡵࠢࡥࡷࡹࡧࡣ࡬ࡡࡳࡥࡹ࡮ࠠ࠾ࠢࡳࡶࡴࡩࡥࡴࡵ࠱ࡥࡷ࡭ࡶ࡜ࡲࡵࡳࡨ࡫ࡳࡴ࠰ࡤࡶ࡬ࡼ࠮࡭ࡧࡱ࡫ࡹ࡮ࠠ࠮ࠢ࠶ࡡࡀࠐࡣࡰࡰࡶࡸࠥࡨࡳࡵࡣࡦ࡯ࡤࡩࡡࡱࡵࠣࡁࠥࡶࡲࡰࡥࡨࡷࡸ࠴ࡡࡳࡩࡹ࡟ࡵࡸ࡯ࡤࡧࡶࡷ࠳ࡧࡲࡨࡸ࠱ࡰࡪࡴࡧࡵࡪࠣ࠱ࠥ࠷࡝࠼ࠌࡦࡳࡳࡹࡴࠡࡲࡢ࡭ࡳࡪࡥࡹࠢࡀࠤࡵࡸ࡯ࡤࡧࡶࡷ࠳ࡧࡲࡨࡸ࡞ࡴࡷࡵࡣࡦࡵࡶ࠲ࡦࡸࡧࡷ࠰࡯ࡩࡳ࡭ࡴࡩࠢ࠰ࠤ࠷ࡣ࠻ࠋࡲࡵࡳࡨ࡫ࡳࡴ࠰ࡤࡶ࡬ࡼࠠ࠾ࠢࡳࡶࡴࡩࡥࡴࡵ࠱ࡥࡷ࡭ࡶ࠯ࡵ࡯࡭ࡨ࡫ࠨ࠱࠮ࠣࡴࡷࡵࡣࡦࡵࡶ࠲ࡦࡸࡧࡷ࠰࡯ࡩࡳ࡭ࡴࡩࠢ࠰ࠤ࠸࠯࠻ࠋࡥࡲࡲࡸࡺࠠࡪ࡯ࡳࡳࡷࡺ࡟ࡱ࡮ࡤࡽࡼࡸࡩࡨࡪࡷ࠸ࡤࡨࡳࡵࡣࡦ࡯ࠥࡃࠠࡳࡧࡴࡹ࡮ࡸࡥࠩࠤࡳࡰࡦࡿࡷࡳ࡫ࡪ࡬ࡹࠨࠩ࠼ࠌ࡬ࡱࡵࡵࡲࡵࡡࡳࡰࡦࡿࡷࡳ࡫ࡪ࡬ࡹ࠺࡟ࡣࡵࡷࡥࡨࡱ࠮ࡤࡪࡵࡳࡲ࡯ࡵ࡮࠰࡯ࡥࡺࡴࡣࡩࠢࡀࠤࡦࡹࡹ࡯ࡥࠣࠬࡱࡧࡵ࡯ࡥ࡫ࡓࡵࡺࡩࡰࡰࡶ࠭ࠥࡃ࠾ࠡࡽࡾࠎࠥࠦ࡬ࡦࡶࠣࡧࡦࡶࡳ࠼ࠌࠣࠤࡹࡸࡹࠡࡽࡾࠎࠥࠦࠠࠡࡥࡤࡴࡸࠦ࠽ࠡࡌࡖࡓࡓ࠴ࡰࡢࡴࡶࡩ࠭ࡨࡳࡵࡣࡦ࡯ࡤࡩࡡࡱࡵࠬ࠿ࠏࠦࠠࡾࡿࠣࡧࡦࡺࡣࡩࠢࠫࡩࡽ࠯ࠠࡼࡽࠍࠤࠥࠦࠠࡤࡱࡱࡷࡴࡲࡥ࠯ࡧࡵࡶࡴࡸࠨࠣࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡵࡧࡲࡴࡧࠣࡧࡦࡶࡡࡣ࡫࡯࡭ࡹ࡯ࡥࡴ࠼ࠥ࠰ࠥ࡫ࡸࠪ࠽ࠍࠤࠥࢃࡽࠋࠢࠣࡶࡪࡺࡵࡳࡰࠣࡥࡼࡧࡩࡵࠢ࡬ࡱࡵࡵࡲࡵࡡࡳࡰࡦࡿࡷࡳ࡫ࡪ࡬ࡹ࠺࡟ࡣࡵࡷࡥࡨࡱ࠮ࡤࡪࡵࡳࡲ࡯ࡵ࡮࠰ࡦࡳࡳࡴࡥࡤࡶࠫࡿࢀࠐࠠࠡࠢࠣࡻࡸࡋ࡮ࡥࡲࡲ࡭ࡳࡺ࠺ࠡࠩࡾࡧࡩࡶࡕࡳ࡮ࢀࠫࠥ࠱ࠠࡦࡰࡦࡳࡩ࡫ࡕࡓࡋࡆࡳࡲࡶ࡯࡯ࡧࡱࡸ࠭ࡐࡓࡐࡐ࠱ࡷࡹࡸࡩ࡯ࡩ࡬ࡪࡾ࠮ࡣࡢࡲࡶ࠭࠮࠲ࠊࠡࠢࠣࠤ࠳࠴࠮࡭ࡣࡸࡲࡨ࡮ࡏࡱࡶ࡬ࡳࡳࡹࠊࠡࠢࢀࢁ࠮ࡁࠊࡾࡿ࠾ࠎ࠴࠰ࠠ࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࠤ࠯࠵ࠊࠨࠩࠪଞ").format(bstack1l11l1111l_opy_=bstack1l11l1111l_opy_)
            lines.insert(1, bstack1l111ll11l_opy_)
            f.seek(0)
            with open(os.path.join(os.path.dirname(args[1]), bstack1ll1lll_opy_ (u"ࠧ࡯࡮ࡥࡧࡻࡣࡧࡹࡴࡢࡥ࡮࠲࡯ࡹࠢଟ")), bstack1ll1lll_opy_ (u"࠭ࡷࠨଠ")) as bstack1lll1llll_opy_:
              bstack1lll1llll_opy_.writelines(lines)
        CONFIG[bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࡙ࡄࡌࠩଡ")] = str(bstack11111l1ll_opy_) + str(__version__)
        bstack1ll1lllll_opy_ = os.environ[bstack1ll1lll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡇࡖࡘࡍ࡛ࡂࡠࡗࡘࡍࡉ࠭ଢ")]
        bstack11l1l1l1ll_opy_ = bstack1llll1111_opy_.bstack11l11l1l_opy_(CONFIG, bstack11111l1ll_opy_)
        CONFIG[bstack1ll1lll_opy_ (u"ࠩࡷࡩࡸࡺࡨࡶࡤࡅࡹ࡮ࡲࡤࡖࡷ࡬ࡨࠬଣ")] = bstack1ll1lllll_opy_
        CONFIG[bstack1ll1lll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡒࡵࡳࡩࡻࡣࡵࡏࡤࡴࠬତ")] = bstack11l1l1l1ll_opy_
        bstack1l1ll11lll_opy_ = 0 if bstack1lllll1ll1_opy_ < 0 else bstack1lllll1ll1_opy_
        try:
          if bstack11llll1l11_opy_ is True:
            bstack1l1ll11lll_opy_ = int(multiprocessing.current_process().name)
          elif bstack1l1l1111_opy_ is True:
            bstack1l1ll11lll_opy_ = int(threading.current_thread().name)
        except:
          bstack1l1ll11lll_opy_ = 0
        CONFIG[bstack1ll1lll_opy_ (u"ࠦࡺࡹࡥࡘ࠵ࡆࠦଥ")] = False
        CONFIG[bstack1ll1lll_opy_ (u"ࠧ࡯ࡳࡑ࡮ࡤࡽࡼࡸࡩࡨࡪࡷࠦଦ")] = True
        bstack11ll11llll_opy_ = bstack1l1ll1ll11_opy_(CONFIG, bstack1l1ll11lll_opy_)
        logger.debug(bstack1lll1111ll_opy_.format(str(bstack11ll11llll_opy_)))
        if CONFIG.get(bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࠪଧ")):
          bstack1ll1111l_opy_(bstack11ll11llll_opy_)
        if bstack1ll1lll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪନ") in CONFIG and bstack1ll1lll_opy_ (u"ࠨࡵࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪ࠭଩") in CONFIG[bstack1ll1lll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬପ")][bstack1l1ll11lll_opy_]:
          bstack1lll11111l_opy_ = CONFIG[bstack1ll1lll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ଫ")][bstack1l1ll11lll_opy_][bstack1ll1lll_opy_ (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩବ")]
        args.append(os.path.join(os.path.expanduser(bstack1ll1lll_opy_ (u"ࠬࢄࠧଭ")), bstack1ll1lll_opy_ (u"࠭࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠭ମ"), bstack1ll1lll_opy_ (u"ࠧ࠯ࡵࡨࡷࡸ࡯࡯࡯࡫ࡧࡷ࠳ࡺࡸࡵࠩଯ")))
        args.append(str(threading.get_ident()))
        args.append(json.dumps(bstack11ll11llll_opy_))
        args[1] = os.path.join(os.path.dirname(args[1]), bstack1ll1lll_opy_ (u"ࠣ࡫ࡱࡨࡪࡾ࡟ࡣࡵࡷࡥࡨࡱ࠮࡫ࡵࠥର"))
      bstack1ll11llll1_opy_ = True
      return bstack1ll1lll11_opy_(self, args, bufsize=bufsize, executable=executable,
                    stdin=stdin, stdout=stdout, stderr=stderr,
                    preexec_fn=preexec_fn, close_fds=close_fds,
                    shell=shell, cwd=cwd, env=env, universal_newlines=universal_newlines,
                    startupinfo=startupinfo, creationflags=creationflags,
                    restore_signals=restore_signals, start_new_session=start_new_session,
                    pass_fds=pass_fds, user=user, group=group, extra_groups=extra_groups,
                    encoding=encoding, errors=errors, text=text, umask=umask, pipesize=pipesize)
  except Exception as e:
    pass
  import playwright._impl._api_structures
  import playwright._impl._helper
  def bstack11l1lllll_opy_(self,
        executablePath = None,
        channel = None,
        args = None,
        ignoreDefaultArgs = None,
        handleSIGINT = None,
        handleSIGTERM = None,
        handleSIGHUP = None,
        timeout = None,
        env = None,
        headless = None,
        devtools = None,
        proxy = None,
        downloadsPath = None,
        slowMo = None,
        tracesDir = None,
        chromiumSandbox = None,
        firefoxUserPrefs = None
        ):
    global CONFIG
    global bstack1lllll1ll1_opy_
    global bstack1lll11111l_opy_
    global bstack11llll1l11_opy_
    global bstack1l1l1111_opy_
    global bstack11111l1ll_opy_
    CONFIG[bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡔࡆࡎࠫ଱")] = str(bstack11111l1ll_opy_) + str(__version__)
    bstack1ll1lllll_opy_ = os.environ[bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚ࡈࡖࡄࡢ࡙࡚ࡏࡄࠨଲ")]
    bstack11l1l1l1ll_opy_ = bstack1llll1111_opy_.bstack11l11l1l_opy_(CONFIG, bstack11111l1ll_opy_)
    CONFIG[bstack1ll1lll_opy_ (u"ࠫࡹ࡫ࡳࡵࡪࡸࡦࡇࡻࡩ࡭ࡦࡘࡹ࡮ࡪࠧଳ")] = bstack1ll1lllll_opy_
    CONFIG[bstack1ll1lll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡔࡷࡵࡤࡶࡥࡷࡑࡦࡶࠧ଴")] = bstack11l1l1l1ll_opy_
    bstack1l1ll11lll_opy_ = 0 if bstack1lllll1ll1_opy_ < 0 else bstack1lllll1ll1_opy_
    try:
      if bstack11llll1l11_opy_ is True:
        bstack1l1ll11lll_opy_ = int(multiprocessing.current_process().name)
      elif bstack1l1l1111_opy_ is True:
        bstack1l1ll11lll_opy_ = int(threading.current_thread().name)
    except:
      bstack1l1ll11lll_opy_ = 0
    CONFIG[bstack1ll1lll_opy_ (u"ࠨࡩࡴࡒ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࠧଵ")] = True
    bstack11ll11llll_opy_ = bstack1l1ll1ll11_opy_(CONFIG, bstack1l1ll11lll_opy_)
    logger.debug(bstack1lll1111ll_opy_.format(str(bstack11ll11llll_opy_)))
    if CONFIG.get(bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࠫଶ")):
      bstack1ll1111l_opy_(bstack11ll11llll_opy_)
    if bstack1ll1lll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫଷ") in CONFIG and bstack1ll1lll_opy_ (u"ࠩࡶࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧସ") in CONFIG[bstack1ll1lll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ହ")][bstack1l1ll11lll_opy_]:
      bstack1lll11111l_opy_ = CONFIG[bstack1ll1lll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧ଺")][bstack1l1ll11lll_opy_][bstack1ll1lll_opy_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪ଻")]
    import urllib
    import json
    if bstack1ll1lll_opy_ (u"࠭ࡴࡶࡴࡥࡳࡘࡩࡡ࡭ࡧ଼ࠪ") in CONFIG and str(CONFIG[bstack1ll1lll_opy_ (u"ࠧࡵࡷࡵࡦࡴ࡙ࡣࡢ࡮ࡨࠫଽ")]).lower() != bstack1ll1lll_opy_ (u"ࠨࡨࡤࡰࡸ࡫ࠧା"):
        bstack1l11lll1_opy_ = bstack1ll11ll11l_opy_()
        bstack1l11l1111l_opy_ = bstack1l11lll1_opy_ + urllib.parse.quote(json.dumps(bstack11ll11llll_opy_))
    else:
        bstack1l11l1111l_opy_ = bstack1ll1lll_opy_ (u"ࠩࡺࡷࡸࡀ࠯࠰ࡥࡧࡴ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡨࡵ࡭࠰ࡲ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࡄࡩࡡࡱࡵࡀࠫି") + urllib.parse.quote(json.dumps(bstack11ll11llll_opy_))
    browser = self.connect(bstack1l11l1111l_opy_)
    return browser
except Exception as e:
    pass
def bstack1l11ll1l11_opy_():
    global bstack1ll11llll1_opy_
    global bstack11111l1ll_opy_
    global CONFIG
    try:
        from playwright._impl._browser_type import BrowserType
        from bstack_utils.helper import bstack11ll11l1l1_opy_
        global bstack11l1l11l_opy_
        if not bstack1l11111l1l_opy_:
          global bstack11l11ll11l_opy_
          if not bstack11l11ll11l_opy_:
            from bstack_utils.helper import bstack1ll11l1lll_opy_, bstack11111lll_opy_, bstack1lllll1l1_opy_
            bstack11l11ll11l_opy_ = bstack1ll11l1lll_opy_()
            bstack11111lll_opy_(bstack11111l1ll_opy_)
            bstack11l1l1l1ll_opy_ = bstack1llll1111_opy_.bstack11l11l1l_opy_(CONFIG, bstack11111l1ll_opy_)
            bstack11l1l11l_opy_.bstack111lll111_opy_(bstack1ll1lll_opy_ (u"ࠥࡔࡑࡇ࡙ࡘࡔࡌࡋࡍ࡚࡟ࡑࡔࡒࡈ࡚ࡉࡔࡠࡏࡄࡔࠧୀ"), bstack11l1l1l1ll_opy_)
          BrowserType.connect = bstack11ll11l1l1_opy_
          return
        BrowserType.launch = bstack11l1lllll_opy_
        bstack1ll11llll1_opy_ = True
    except Exception as e:
        pass
    try:
      import Browser
      from subprocess import Popen
      Popen.__init__ = bstack11l1ll11l1_opy_
      bstack1ll11llll1_opy_ = True
    except Exception as e:
      pass
def bstack1l1l1ll1l1_opy_(context, bstack1lll11ll1_opy_):
  try:
    context.page.evaluate(bstack1ll1lll_opy_ (u"ࠦࡤࠦ࠽࠿ࠢࡾࢁࠧୁ"), bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡱࡥࡲ࡫ࠢ࠻ࠩୂ")+ json.dumps(bstack1lll11ll1_opy_) + bstack1ll1lll_opy_ (u"ࠨࡽࡾࠤୃ"))
  except Exception as e:
    logger.debug(bstack1ll1lll_opy_ (u"ࠢࡦࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡰ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶࠣࡷࡪࡹࡳࡪࡱࡱࠤࡳࡧ࡭ࡦࠢࡾࢁ࠿ࠦࡻࡾࠤୄ").format(str(e), traceback.format_exc()))
def bstack111l1l1l1_opy_(context, message, level):
  try:
    context.page.evaluate(bstack1ll1lll_opy_ (u"ࠣࡡࠣࡁࡃࠦࡻࡾࠤ୅"), bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠡࠤࡤࡲࡳࡵࡴࡢࡶࡨࠦ࠱ࠦࠢࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠥ࠾ࠥࢁࠢࡥࡣࡷࡥࠧࡀࠧ୆") + json.dumps(message) + bstack1ll1lll_opy_ (u"ࠪ࠰ࠧࡲࡥࡷࡧ࡯ࠦ࠿࠭େ") + json.dumps(level) + bstack1ll1lll_opy_ (u"ࠫࢂࢃࠧୈ"))
  except Exception as e:
    logger.debug(bstack1ll1lll_opy_ (u"ࠧ࡫ࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࠡࡣࡱࡲࡴࡺࡡࡵ࡫ࡲࡲࠥࢁࡽ࠻ࠢࡾࢁࠧ୉").format(str(e), traceback.format_exc()))
@measure(event_name=EVENTS.bstack1ll111ll1l_opy_, stage=STAGE.bstack111lll1l11_opy_, bstack11lllll111_opy_=bstack1lll11111l_opy_)
def bstack1l11ll1ll_opy_(self, url):
  global bstack11ll1ll1l1_opy_
  try:
    bstack1ll11l1111_opy_(url)
  except Exception as err:
    logger.debug(bstack1l1lllll_opy_.format(str(err)))
  try:
    bstack11ll1ll1l1_opy_(self, url)
  except Exception as e:
    try:
      bstack1llll11lll_opy_ = str(e)
      if any(err_msg in bstack1llll11lll_opy_ for err_msg in bstack1ll1111ll_opy_):
        bstack1ll11l1111_opy_(url, True)
    except Exception as err:
      logger.debug(bstack1l1lllll_opy_.format(str(err)))
    raise e
def bstack11llll1ll_opy_(self):
  global bstack1l111l1ll_opy_
  bstack1l111l1ll_opy_ = self
  return
def bstack1lllll11l_opy_(self):
  global bstack1ll1l111l1_opy_
  bstack1ll1l111l1_opy_ = self
  return
def bstack1l11ll11_opy_(test_name, bstack11lll1ll1l_opy_):
  global CONFIG
  if percy.bstack11ll1l11ll_opy_() == bstack1ll1lll_opy_ (u"ࠨࡴࡳࡷࡨࠦ୊"):
    bstack1l1l11l111_opy_ = os.path.relpath(bstack11lll1ll1l_opy_, start=os.getcwd())
    suite_name, _ = os.path.splitext(bstack1l1l11l111_opy_)
    bstack11lllll111_opy_ = suite_name + bstack1ll1lll_opy_ (u"ࠢ࠮ࠤୋ") + test_name
    threading.current_thread().percySessionName = bstack11lllll111_opy_
def bstack1l11ll1l_opy_(self, test, *args, **kwargs):
  global bstack11l1ll1lll_opy_
  test_name = None
  bstack11lll1ll1l_opy_ = None
  if test:
    test_name = str(test.name)
    bstack11lll1ll1l_opy_ = str(test.source)
  bstack1l11ll11_opy_(test_name, bstack11lll1ll1l_opy_)
  bstack11l1ll1lll_opy_(self, test, *args, **kwargs)
@measure(event_name=EVENTS.bstack11ll1lll_opy_, stage=STAGE.bstack111lll1l11_opy_, bstack11lllll111_opy_=bstack1lll11111l_opy_)
def bstack1l1ll111l_opy_(driver, bstack11lllll111_opy_):
  if not bstack1l1l11ll1_opy_ and bstack11lllll111_opy_:
      bstack1l1l1l1l_opy_ = {
          bstack1ll1lll_opy_ (u"ࠨࡣࡦࡸ࡮ࡵ࡮ࠨୌ"): bstack1ll1lll_opy_ (u"ࠩࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧ୍ࠪ"),
          bstack1ll1lll_opy_ (u"ࠪࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸ࠭୎"): {
              bstack1ll1lll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩ୏"): bstack11lllll111_opy_
          }
      }
      bstack1l1ll11l1l_opy_ = bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࡿࠪ୐").format(json.dumps(bstack1l1l1l1l_opy_))
      driver.execute_script(bstack1l1ll11l1l_opy_)
  if bstack111l1l11_opy_:
      bstack11lll1l1l_opy_ = {
          bstack1ll1lll_opy_ (u"࠭ࡡࡤࡶ࡬ࡳࡳ࠭୑"): bstack1ll1lll_opy_ (u"ࠧࡢࡰࡱࡳࡹࡧࡴࡦࠩ୒"),
          bstack1ll1lll_opy_ (u"ࠨࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠫ୓"): {
              bstack1ll1lll_opy_ (u"ࠩࡧࡥࡹࡧࠧ୔"): bstack11lllll111_opy_ + bstack1ll1lll_opy_ (u"ࠪࠤࡵࡧࡳࡴࡧࡧࠥࠬ୕"),
              bstack1ll1lll_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪୖ"): bstack1ll1lll_opy_ (u"ࠬ࡯࡮ࡧࡱࠪୗ")
          }
      }
      if bstack111l1l11_opy_.status == bstack1ll1lll_opy_ (u"࠭ࡐࡂࡕࡖࠫ୘"):
          bstack11l1l111l_opy_ = bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࢁࠬ୙").format(json.dumps(bstack11lll1l1l_opy_))
          driver.execute_script(bstack11l1l111l_opy_)
          bstack1l1lll1ll1_opy_(driver, bstack1ll1lll_opy_ (u"ࠨࡲࡤࡷࡸ࡫ࡤࠨ୚"))
      elif bstack111l1l11_opy_.status == bstack1ll1lll_opy_ (u"ࠩࡉࡅࡎࡒࠧ୛"):
          reason = bstack1ll1lll_opy_ (u"ࠥࠦଡ଼")
          bstack1ll1ll111l_opy_ = bstack11lllll111_opy_ + bstack1ll1lll_opy_ (u"ࠫࠥ࡬ࡡࡪ࡮ࡨࡨࠬଢ଼")
          if bstack111l1l11_opy_.message:
              reason = str(bstack111l1l11_opy_.message)
              bstack1ll1ll111l_opy_ = bstack1ll1ll111l_opy_ + bstack1ll1lll_opy_ (u"ࠬࠦࡷࡪࡶ࡫ࠤࡪࡸࡲࡰࡴ࠽ࠤࠬ୞") + reason
          bstack11lll1l1l_opy_[bstack1ll1lll_opy_ (u"࠭ࡡࡳࡩࡸࡱࡪࡴࡴࡴࠩୟ")] = {
              bstack1ll1lll_opy_ (u"ࠧ࡭ࡧࡹࡩࡱ࠭ୠ"): bstack1ll1lll_opy_ (u"ࠨࡧࡵࡶࡴࡸࠧୡ"),
              bstack1ll1lll_opy_ (u"ࠩࡧࡥࡹࡧࠧୢ"): bstack1ll1ll111l_opy_
          }
          bstack11l1l111l_opy_ = bstack1ll1lll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࡽࠨୣ").format(json.dumps(bstack11lll1l1l_opy_))
          driver.execute_script(bstack11l1l111l_opy_)
          bstack1l1lll1ll1_opy_(driver, bstack1ll1lll_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ୤"), reason)
          bstack111l111l1_opy_(reason, str(bstack111l1l11_opy_), str(bstack1lllll1ll1_opy_), logger)
@measure(event_name=EVENTS.bstack1ll1l1ll1_opy_, stage=STAGE.bstack111lll1l11_opy_, bstack11lllll111_opy_=bstack1lll11111l_opy_)
def bstack1l1ll1ll1_opy_(driver, test):
  if percy.bstack11ll1l11ll_opy_() == bstack1ll1lll_opy_ (u"ࠧࡺࡲࡶࡧࠥ୥") and percy.bstack1l11l1ll1l_opy_() == bstack1ll1lll_opy_ (u"ࠨࡴࡦࡵࡷࡧࡦࡹࡥࠣ୦"):
      bstack11l1l11l1l_opy_ = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠧࡱࡧࡵࡧࡾ࡙ࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪ୧"), None)
      bstack111l11ll_opy_(driver, bstack11l1l11l1l_opy_, test)
  if (bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠨ࡫ࡶࡅ࠶࠷ࡹࡕࡧࡶࡸࠬ୨"), None) and
      bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠩࡤ࠵࠶ࡿࡐ࡭ࡣࡷࡪࡴࡸ࡭ࠨ୩"), None)) or (
      bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠪ࡭ࡸࡇࡰࡱࡃ࠴࠵ࡾ࡚ࡥࡴࡶࠪ୪"), None) and
      bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠫࡦࡶࡰࡂ࠳࠴ࡽࡕࡲࡡࡵࡨࡲࡶࡲ࠭୫"), None)):
      logger.info(bstack1ll1lll_opy_ (u"ࠧࡇࡵࡵࡱࡰࡥࡹ࡫ࠠࡵࡧࡶࡸࠥࡩࡡࡴࡧࠣࡩࡽ࡫ࡣࡶࡶ࡬ࡳࡳࠦࡨࡢࡵࠣࡩࡳࡪࡥࡥ࠰ࠣࡔࡷࡵࡣࡦࡵࡶ࡭ࡳ࡭ࠠࡧࡱࡵࠤࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡹ࡫ࡳࡵ࡫ࡱ࡫ࠥ࡯ࡳࠡࡷࡱࡨࡪࡸࡷࡢࡻ࠱ࠤࠧ୬"))
      bstack1l11l1l1_opy_.bstack11llllll1_opy_(driver, name=test.name, path=test.source)
def bstack11llll1l1_opy_(test, bstack11lllll111_opy_):
    try:
      bstack11l1lll11_opy_ = datetime.datetime.now()
      data = {}
      if test:
        data[bstack1ll1lll_opy_ (u"࠭࡮ࡢ࡯ࡨࠫ୭")] = bstack11lllll111_opy_
      if bstack111l1l11_opy_:
        if bstack111l1l11_opy_.status == bstack1ll1lll_opy_ (u"ࠧࡑࡃࡖࡗࠬ୮"):
          data[bstack1ll1lll_opy_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨ୯")] = bstack1ll1lll_opy_ (u"ࠩࡳࡥࡸࡹࡥࡥࠩ୰")
        elif bstack111l1l11_opy_.status == bstack1ll1lll_opy_ (u"ࠪࡊࡆࡏࡌࠨୱ"):
          data[bstack1ll1lll_opy_ (u"ࠫࡸࡺࡡࡵࡷࡶࠫ୲")] = bstack1ll1lll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ୳")
          if bstack111l1l11_opy_.message:
            data[bstack1ll1lll_opy_ (u"࠭ࡲࡦࡣࡶࡳࡳ࠭୴")] = str(bstack111l1l11_opy_.message)
      user = CONFIG[bstack1ll1lll_opy_ (u"ࠧࡶࡵࡨࡶࡓࡧ࡭ࡦࠩ୵")]
      key = CONFIG[bstack1ll1lll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡌࡧࡼࠫ୶")]
      host = bstack1l1111l11l_opy_(cli.config, [bstack1ll1lll_opy_ (u"ࠤࡤࡴ࡮ࡹࠢ୷"), bstack1ll1lll_opy_ (u"ࠥࡥࡺࡺ࡯࡮ࡣࡷࡩࠧ୸"), bstack1ll1lll_opy_ (u"ࠦࡦࡶࡩࠣ୹")], bstack1ll1lll_opy_ (u"ࠧ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡱ࡫࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡦࡳࡲࠨ୺"))
      url = bstack1ll1lll_opy_ (u"࠭ࡻࡾ࠱ࡤࡹࡹࡵ࡭ࡢࡶࡨ࠳ࡸ࡫ࡳࡴ࡫ࡲࡲࡸ࠵ࡻࡾ࠰࡭ࡷࡴࡴࠧ୻").format(host, bstack111l11l1_opy_)
      headers = {
        bstack1ll1lll_opy_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡶࡼࡴࡪ࠭୼"): bstack1ll1lll_opy_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫ୽"),
      }
      if bool(data):
        requests.put(url, json=data, headers=headers, auth=(user, key))
        cli.bstack1ll1l111l_opy_(bstack1ll1lll_opy_ (u"ࠤ࡫ࡸࡹࡶ࠺ࡶࡲࡧࡥࡹ࡫࡟ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡳࡵࡣࡷࡹࡸࠨ୾"), datetime.datetime.now() - bstack11l1lll11_opy_)
    except Exception as e:
      logger.error(bstack11lll11lll_opy_.format(str(e)))
def bstack11l111ll1l_opy_(test, bstack11lllll111_opy_):
  global CONFIG
  global bstack1ll1l111l1_opy_
  global bstack1l111l1ll_opy_
  global bstack111l11l1_opy_
  global bstack111l1l11_opy_
  global bstack1lll11111l_opy_
  global bstack1l1l111ll1_opy_
  global bstack1ll1llll1l_opy_
  global bstack11llll11_opy_
  global bstack11llllll1l_opy_
  global bstack1ll11ll1l1_opy_
  global bstack11ll1lll11_opy_
  global bstack1lll111lll_opy_
  try:
    if not bstack111l11l1_opy_:
      with bstack1lll111lll_opy_:
        bstack1lll111l_opy_ = os.path.join(os.path.expanduser(bstack1ll1lll_opy_ (u"ࠪࢂࠬ୿")), bstack1ll1lll_opy_ (u"ࠫ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠫ஀"), bstack1ll1lll_opy_ (u"ࠬ࠴ࡳࡦࡵࡶ࡭ࡴࡴࡩࡥࡵ࠱ࡸࡽࡺࠧ஁"))
        if os.path.exists(bstack1lll111l_opy_):
          with open(bstack1lll111l_opy_, bstack1ll1lll_opy_ (u"࠭ࡲࠨஂ")) as f:
            content = f.read().strip()
            if content:
              bstack1l1ll11l1_opy_ = json.loads(bstack1ll1lll_opy_ (u"ࠢࡼࠤஃ") + content + bstack1ll1lll_opy_ (u"ࠨࠤࡻࠦ࠿ࠦࠢࡺࠤࠪ஄") + bstack1ll1lll_opy_ (u"ࠤࢀࠦஅ"))
              bstack111l11l1_opy_ = bstack1l1ll11l1_opy_.get(str(threading.get_ident()))
  except Exception as e:
    logger.debug(bstack1ll1lll_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࡵࡩࡦࡪࡩ࡯ࡩࠣࡷࡪࡹࡳࡪࡱࡱࠤࡎࡊࡳࠡࡨ࡬ࡰࡪࡀࠠࠨஆ") + str(e))
  if bstack1ll11ll1l1_opy_:
    with bstack11llllll11_opy_:
      bstack1l111l1l1l_opy_ = bstack1ll11ll1l1_opy_.copy()
    for driver in bstack1l111l1l1l_opy_:
      if bstack111l11l1_opy_ == driver.session_id:
        if test:
          bstack1l1ll1ll1_opy_(driver, test)
        bstack1l1ll111l_opy_(driver, bstack11lllll111_opy_)
  elif bstack111l11l1_opy_:
    bstack11llll1l1_opy_(test, bstack11lllll111_opy_)
  if bstack1ll1l111l1_opy_:
    bstack1ll1llll1l_opy_(bstack1ll1l111l1_opy_)
  if bstack1l111l1ll_opy_:
    bstack11llll11_opy_(bstack1l111l1ll_opy_)
  if bstack1lll1l1l1l_opy_:
    bstack11llllll1l_opy_()
def bstack11lll11ll_opy_(self, test, *args, **kwargs):
  bstack11lllll111_opy_ = None
  if test:
    bstack11lllll111_opy_ = str(test.name)
  bstack11l111ll1l_opy_(test, bstack11lllll111_opy_)
  bstack1l1l111ll1_opy_(self, test, *args, **kwargs)
def bstack1llllll11_opy_(self, parent, test, skip_on_failure=None, rpa=False):
  global bstack1ll1lllll1_opy_
  global CONFIG
  global bstack1ll11ll1l1_opy_
  global bstack111l11l1_opy_
  global bstack1lll111lll_opy_
  bstack1llll1lll_opy_ = None
  try:
    if bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠫࡦ࠷࠱ࡺࡒ࡯ࡥࡹ࡬࡯ࡳ࡯ࠪஇ"), None) or bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠬࡧࡰࡱࡃ࠴࠵ࡾࡖ࡬ࡢࡶࡩࡳࡷࡳࠧஈ"), None):
      try:
        if not bstack111l11l1_opy_:
          bstack1lll111l_opy_ = os.path.join(os.path.expanduser(bstack1ll1lll_opy_ (u"࠭ࡾࠨஉ")), bstack1ll1lll_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧஊ"), bstack1ll1lll_opy_ (u"ࠨ࠰ࡶࡩࡸࡹࡩࡰࡰ࡬ࡨࡸ࠴ࡴࡹࡶࠪ஋"))
          with bstack1lll111lll_opy_:
            if os.path.exists(bstack1lll111l_opy_):
              with open(bstack1lll111l_opy_, bstack1ll1lll_opy_ (u"ࠩࡵࠫ஌")) as f:
                content = f.read().strip()
                if content:
                  bstack1l1ll11l1_opy_ = json.loads(bstack1ll1lll_opy_ (u"ࠥࡿࠧ஍") + content + bstack1ll1lll_opy_ (u"ࠫࠧࡾࠢ࠻ࠢࠥࡽࠧ࠭எ") + bstack1ll1lll_opy_ (u"ࠧࢃࠢஏ"))
                  bstack111l11l1_opy_ = bstack1l1ll11l1_opy_.get(str(threading.get_ident()))
      except Exception as e:
        logger.debug(bstack1ll1lll_opy_ (u"࠭ࡅࡳࡴࡲࡶࠥࡸࡥࡢࡦ࡬ࡲ࡬ࠦࡳࡦࡵࡶ࡭ࡴࡴࠠࡊࡆࡶࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥࡺࡥࡴࡶࠣࡷࡹࡧࡴࡶࡵ࠽ࠤࠬஐ") + str(e))
      if bstack1ll11ll1l1_opy_:
        with bstack11llllll11_opy_:
          bstack1l111l1l1l_opy_ = bstack1ll11ll1l1_opy_.copy()
        for driver in bstack1l111l1l1l_opy_:
          if bstack111l11l1_opy_ == driver.session_id:
            bstack1llll1lll_opy_ = driver
    bstack1lll11ll1l_opy_ = bstack1l11l1l1_opy_.bstack11l1l11ll1_opy_(test.tags)
    if bstack1llll1lll_opy_:
      threading.current_thread().isA11yTest = bstack1l11l1l1_opy_.bstack1l1ll111ll_opy_(bstack1llll1lll_opy_, bstack1lll11ll1l_opy_)
      threading.current_thread().isAppA11yTest = bstack1l11l1l1_opy_.bstack1l1ll111ll_opy_(bstack1llll1lll_opy_, bstack1lll11ll1l_opy_)
    else:
      threading.current_thread().isA11yTest = bstack1lll11ll1l_opy_
      threading.current_thread().isAppA11yTest = bstack1lll11ll1l_opy_
  except:
    pass
  bstack1ll1lllll1_opy_(self, parent, test, skip_on_failure=skip_on_failure, rpa=rpa)
  global bstack111l1l11_opy_
  try:
    bstack111l1l11_opy_ = self._test
  except:
    bstack111l1l11_opy_ = self.test
def bstack1l1l11lll1_opy_():
  global bstack1lllllll11_opy_
  try:
    if os.path.exists(bstack1lllllll11_opy_):
      os.remove(bstack1lllllll11_opy_)
  except Exception as e:
    logger.debug(bstack1ll1lll_opy_ (u"ࠧࡆࡴࡵࡳࡷࠦࡩ࡯ࠢࡧࡩࡱ࡫ࡴࡪࡰࡪࠤࡷࡵࡢࡰࡶࠣࡶࡪࡶ࡯ࡳࡶࠣࡪ࡮ࡲࡥ࠻ࠢࠪ஑") + str(e))
def bstack11l111ll11_opy_():
  global bstack1lllllll11_opy_
  bstack1lll1lll1l_opy_ = {}
  lock_file = bstack1lllllll11_opy_ + bstack1ll1lll_opy_ (u"ࠨ࠰࡯ࡳࡨࡱࠧஒ")
  try:
    from filelock import FileLock
  except ImportError:
    logger.debug(bstack1ll1lll_opy_ (u"ࠩࡩ࡭ࡱ࡫࡬ࡰࡥ࡮ࠤࡳࡵࡴࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨ࠰ࠥࡻࡳࡪࡰࡪࠤࡧࡧࡳࡪࡥࠣࡪ࡮ࡲࡥࠡࡱࡳࡩࡷࡧࡴࡪࡱࡱࡷࠬஓ"))
    try:
      if not os.path.isfile(bstack1lllllll11_opy_):
        with open(bstack1lllllll11_opy_, bstack1ll1lll_opy_ (u"ࠪࡻࠬஔ")) as f:
          json.dump({}, f)
      if os.path.exists(bstack1lllllll11_opy_):
        with open(bstack1lllllll11_opy_, bstack1ll1lll_opy_ (u"ࠫࡷ࠭க")) as f:
          content = f.read().strip()
          if content:
            bstack1lll1lll1l_opy_ = json.loads(content)
    except Exception as e:
      logger.debug(bstack1ll1lll_opy_ (u"ࠬࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡳࡧࡤࡨ࡮ࡴࡧࠡࡴࡲࡦࡴࡺࠠࡳࡧࡳࡳࡷࡺࠠࡧ࡫࡯ࡩ࠿ࠦࠧ஖") + str(e))
    return bstack1lll1lll1l_opy_
  try:
    os.makedirs(os.path.dirname(bstack1lllllll11_opy_), exist_ok=True)
    with FileLock(lock_file, timeout=10):
      if not os.path.isfile(bstack1lllllll11_opy_):
        with open(bstack1lllllll11_opy_, bstack1ll1lll_opy_ (u"࠭ࡷࠨ஗")) as f:
          json.dump({}, f)
      if os.path.exists(bstack1lllllll11_opy_):
        with open(bstack1lllllll11_opy_, bstack1ll1lll_opy_ (u"ࠧࡳࠩ஘")) as f:
          content = f.read().strip()
          if content:
            bstack1lll1lll1l_opy_ = json.loads(content)
  except Exception as e:
    logger.debug(bstack1ll1lll_opy_ (u"ࠨࡇࡵࡶࡴࡸࠠࡪࡰࠣࡶࡪࡧࡤࡪࡰࡪࠤࡷࡵࡢࡰࡶࠣࡶࡪࡶ࡯ࡳࡶࠣࡪ࡮ࡲࡥ࠻ࠢࠪங") + str(e))
  finally:
    return bstack1lll1lll1l_opy_
def bstack111llll11l_opy_(platform_index, item_index):
  global bstack1lllllll11_opy_
  lock_file = bstack1lllllll11_opy_ + bstack1ll1lll_opy_ (u"ࠩ࠱ࡰࡴࡩ࡫ࠨச")
  try:
    from filelock import FileLock
  except ImportError:
    logger.debug(bstack1ll1lll_opy_ (u"ࠪࡪ࡮ࡲࡥ࡭ࡱࡦ࡯ࠥࡴ࡯ࡵࠢࡤࡺࡦ࡯࡬ࡢࡤ࡯ࡩ࠱ࠦࡵࡴ࡫ࡱ࡫ࠥࡨࡡࡴ࡫ࡦࠤ࡫࡯࡬ࡦࠢࡲࡴࡪࡸࡡࡵ࡫ࡲࡲࡸ࠭஛"))
    try:
      bstack1lll1lll1l_opy_ = {}
      if os.path.exists(bstack1lllllll11_opy_):
        with open(bstack1lllllll11_opy_, bstack1ll1lll_opy_ (u"ࠫࡷ࠭ஜ")) as f:
          content = f.read().strip()
          if content:
            bstack1lll1lll1l_opy_ = json.loads(content)
      bstack1lll1lll1l_opy_[item_index] = platform_index
      with open(bstack1lllllll11_opy_, bstack1ll1lll_opy_ (u"ࠧࡽࠢ஝")) as outfile:
        json.dump(bstack1lll1lll1l_opy_, outfile)
    except Exception as e:
      logger.debug(bstack1ll1lll_opy_ (u"࠭ࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡹࡵ࡭ࡹ࡯࡮ࡨࠢࡷࡳࠥࡸ࡯ࡣࡱࡷࠤࡷ࡫ࡰࡰࡴࡷࠤ࡫࡯࡬ࡦ࠼ࠣࠫஞ") + str(e))
    return
  try:
    os.makedirs(os.path.dirname(bstack1lllllll11_opy_), exist_ok=True)
    with FileLock(lock_file, timeout=10):
      bstack1lll1lll1l_opy_ = {}
      if os.path.exists(bstack1lllllll11_opy_):
        with open(bstack1lllllll11_opy_, bstack1ll1lll_opy_ (u"ࠧࡳࠩட")) as f:
          content = f.read().strip()
          if content:
            bstack1lll1lll1l_opy_ = json.loads(content)
      bstack1lll1lll1l_opy_[item_index] = platform_index
      with open(bstack1lllllll11_opy_, bstack1ll1lll_opy_ (u"ࠣࡹࠥ஠")) as outfile:
        json.dump(bstack1lll1lll1l_opy_, outfile)
  except Exception as e:
    logger.debug(bstack1ll1lll_opy_ (u"ࠩࡈࡶࡷࡵࡲࠡ࡫ࡱࠤࡼࡸࡩࡵ࡫ࡱ࡫ࠥࡺ࡯ࠡࡴࡲࡦࡴࡺࠠࡳࡧࡳࡳࡷࡺࠠࡧ࡫࡯ࡩ࠿ࠦࠧ஡") + str(e))
def bstack1ll1l1ll1l_opy_(bstack1l11lll1l1_opy_):
  global CONFIG
  bstack11l1l11l1_opy_ = bstack1ll1lll_opy_ (u"ࠪࠫ஢")
  if not bstack1ll1lll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧண") in CONFIG:
    logger.info(bstack1ll1lll_opy_ (u"ࠬࡔ࡯ࠡࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠤࡵࡧࡳࡴࡧࡧࠤࡺࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡨࡧࡱࡩࡷࡧࡴࡦࠢࡵࡩࡵࡵࡲࡵࠢࡩࡳࡷࠦࡒࡰࡤࡲࡸࠥࡸࡵ࡯ࠩத"))
  try:
    platform = CONFIG[bstack1ll1lll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩ஥")][bstack1l11lll1l1_opy_]
    if bstack1ll1lll_opy_ (u"ࠧࡰࡵࠪ஦") in platform:
      bstack11l1l11l1_opy_ += str(platform[bstack1ll1lll_opy_ (u"ࠨࡱࡶࠫ஧")]) + bstack1ll1lll_opy_ (u"ࠩ࠯ࠤࠬந")
    if bstack1ll1lll_opy_ (u"ࠪࡳࡸ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ன") in platform:
      bstack11l1l11l1_opy_ += str(platform[bstack1ll1lll_opy_ (u"ࠫࡴࡹࡖࡦࡴࡶ࡭ࡴࡴࠧப")]) + bstack1ll1lll_opy_ (u"ࠬ࠲ࠠࠨ஫")
    if bstack1ll1lll_opy_ (u"࠭ࡤࡦࡸ࡬ࡧࡪࡔࡡ࡮ࡧࠪ஬") in platform:
      bstack11l1l11l1_opy_ += str(platform[bstack1ll1lll_opy_ (u"ࠧࡥࡧࡹ࡭ࡨ࡫ࡎࡢ࡯ࡨࠫ஭")]) + bstack1ll1lll_opy_ (u"ࠨ࠮ࠣࠫம")
    if bstack1ll1lll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰ࡚ࡪࡸࡳࡪࡱࡱࠫய") in platform:
      bstack11l1l11l1_opy_ += str(platform[bstack1ll1lll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱ࡛࡫ࡲࡴ࡫ࡲࡲࠬர")]) + bstack1ll1lll_opy_ (u"ࠫ࠱ࠦࠧற")
    if bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠪல") in platform:
      bstack11l1l11l1_opy_ += str(platform[bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡎࡢ࡯ࡨࠫள")]) + bstack1ll1lll_opy_ (u"ࠧ࠭ࠢࠪழ")
    if bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩவ") in platform:
      bstack11l1l11l1_opy_ += str(platform[bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪஶ")]) + bstack1ll1lll_opy_ (u"ࠪ࠰ࠥ࠭ஷ")
  except Exception as e:
    logger.debug(bstack1ll1lll_opy_ (u"ࠫࡘࡵ࡭ࡦࠢࡨࡶࡷࡵࡲࠡ࡫ࡱࠤ࡬࡫࡮ࡦࡴࡤࡸ࡮ࡴࡧࠡࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࠣࡷࡹࡸࡩ࡯ࡩࠣࡪࡴࡸࠠࡳࡧࡳࡳࡷࡺࠠࡨࡧࡱࡩࡷࡧࡴࡪࡱࡱࠫஸ") + str(e))
  finally:
    if bstack11l1l11l1_opy_[len(bstack11l1l11l1_opy_) - 2:] == bstack1ll1lll_opy_ (u"ࠬ࠲ࠠࠨஹ"):
      bstack11l1l11l1_opy_ = bstack11l1l11l1_opy_[:-2]
    return bstack11l1l11l1_opy_
def bstack11l11ll1_opy_(path, bstack11l1l11l1_opy_):
  try:
    import xml.etree.ElementTree as ET
    bstack11l111l1l_opy_ = ET.parse(path)
    bstack11l1l1llll_opy_ = bstack11l111l1l_opy_.getroot()
    bstack1l1ll11ll1_opy_ = None
    for suite in bstack11l1l1llll_opy_.iter(bstack1ll1lll_opy_ (u"࠭ࡳࡶ࡫ࡷࡩࠬ஺")):
      if bstack1ll1lll_opy_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠧ஻") in suite.attrib:
        suite.attrib[bstack1ll1lll_opy_ (u"ࠨࡰࡤࡱࡪ࠭஼")] += bstack1ll1lll_opy_ (u"ࠩࠣࠫ஽") + bstack11l1l11l1_opy_
        bstack1l1ll11ll1_opy_ = suite
    bstack1111llll_opy_ = None
    for robot in bstack11l1l1llll_opy_.iter(bstack1ll1lll_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩா")):
      bstack1111llll_opy_ = robot
    bstack1ll1l1111_opy_ = len(bstack1111llll_opy_.findall(bstack1ll1lll_opy_ (u"ࠫࡸࡻࡩࡵࡧࠪி")))
    if bstack1ll1l1111_opy_ == 1:
      bstack1111llll_opy_.remove(bstack1111llll_opy_.findall(bstack1ll1lll_opy_ (u"ࠬࡹࡵࡪࡶࡨࠫீ"))[0])
      bstack1lll11l111_opy_ = ET.Element(bstack1ll1lll_opy_ (u"࠭ࡳࡶ࡫ࡷࡩࠬு"), attrib={bstack1ll1lll_opy_ (u"ࠧ࡯ࡣࡰࡩࠬூ"): bstack1ll1lll_opy_ (u"ࠨࡕࡸ࡭ࡹ࡫ࡳࠨ௃"), bstack1ll1lll_opy_ (u"ࠩ࡬ࡨࠬ௄"): bstack1ll1lll_opy_ (u"ࠪࡷ࠵࠭௅")})
      bstack1111llll_opy_.insert(1, bstack1lll11l111_opy_)
      bstack11l111l1_opy_ = None
      for suite in bstack1111llll_opy_.iter(bstack1ll1lll_opy_ (u"ࠫࡸࡻࡩࡵࡧࠪெ")):
        bstack11l111l1_opy_ = suite
      bstack11l111l1_opy_.append(bstack1l1ll11ll1_opy_)
      bstack111ll1ll1_opy_ = None
      for status in bstack1l1ll11ll1_opy_.iter(bstack1ll1lll_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬே")):
        bstack111ll1ll1_opy_ = status
      bstack11l111l1_opy_.append(bstack111ll1ll1_opy_)
    bstack11l111l1l_opy_.write(path)
  except Exception as e:
    logger.debug(bstack1ll1lll_opy_ (u"࠭ࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡲࡤࡶࡸ࡯࡮ࡨࠢࡺ࡬࡮ࡲࡥࠡࡩࡨࡲࡪࡸࡡࡵ࡫ࡱ࡫ࠥࡸ࡯ࡣࡱࡷࠤࡷ࡫ࡰࡰࡴࡷࠫை") + str(e))
def bstack1l1l11l1l1_opy_(outs_dir, pabot_args, options, start_time_string, tests_root_name):
  global bstack1l11111l11_opy_
  global CONFIG
  if bstack1ll1lll_opy_ (u"ࠢࡱࡻࡷ࡬ࡴࡴࡰࡢࡶ࡫ࠦ௉") in options:
    del options[bstack1ll1lll_opy_ (u"ࠣࡲࡼࡸ࡭ࡵ࡮ࡱࡣࡷ࡬ࠧொ")]
  bstack1ll1ll11_opy_ = bstack11l111ll11_opy_()
  for item_id in bstack1ll1ll11_opy_.keys():
    path = os.path.join(os.getcwd(), bstack1ll1lll_opy_ (u"ࠩࡳࡥࡧࡵࡴࡠࡴࡨࡷࡺࡲࡴࡴࠩோ"), str(item_id), bstack1ll1lll_opy_ (u"ࠪࡳࡺࡺࡰࡶࡶ࠱ࡼࡲࡲࠧௌ"))
    bstack11l11ll1_opy_(path, bstack1ll1l1ll1l_opy_(bstack1ll1ll11_opy_[item_id]))
  bstack1l1l11lll1_opy_()
  return bstack1l11111l11_opy_(outs_dir, pabot_args, options, start_time_string, tests_root_name)
def bstack1l1l1111ll_opy_(self, ff_profile_dir):
  global bstack11ll111l1_opy_
  if not ff_profile_dir:
    return None
  return bstack11ll111l1_opy_(self, ff_profile_dir)
def bstack1ll1111l1_opy_(datasources, opts_for_run, outs_dir, pabot_args, suite_group):
  from pabot.pabot import QueueItem
  global CONFIG
  global bstack1ll1lll1l1_opy_
  bstack11lll1111_opy_ = []
  if bstack1ll1lll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹ்ࠧ") in CONFIG:
    bstack11lll1111_opy_ = CONFIG[bstack1ll1lll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨ௎")]
  return [
    QueueItem(
      datasources,
      outs_dir,
      opts_for_run,
      suite,
      pabot_args[bstack1ll1lll_opy_ (u"ࠨࡣࡰ࡯ࡰࡥࡳࡪࠢ௏")],
      pabot_args[bstack1ll1lll_opy_ (u"ࠢࡷࡧࡵࡦࡴࡹࡥࠣௐ")],
      argfile,
      pabot_args.get(bstack1ll1lll_opy_ (u"ࠣࡪ࡬ࡺࡪࠨ௑")),
      pabot_args[bstack1ll1lll_opy_ (u"ࠤࡳࡶࡴࡩࡥࡴࡵࡨࡷࠧ௒")],
      platform[0],
      bstack1ll1lll1l1_opy_
    )
    for suite in suite_group
    for argfile in pabot_args[bstack1ll1lll_opy_ (u"ࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸ࡫࡯࡬ࡦࡵࠥ௓")] or [(bstack1ll1lll_opy_ (u"ࠦࠧ௔"), None)]
    for platform in enumerate(bstack11lll1111_opy_)
  ]
def bstack11lll11l11_opy_(self, datasources, outs_dir, options,
                        execution_item, command, verbose, argfile,
                        hive=None, processes=0, platform_index=0, bstack1l1l11l1l_opy_=bstack1ll1lll_opy_ (u"ࠬ࠭௕")):
  global bstack11l111111l_opy_
  self.platform_index = platform_index
  self.bstack1llllll11l_opy_ = bstack1l1l11l1l_opy_
  bstack11l111111l_opy_(self, datasources, outs_dir, options,
                      execution_item, command, verbose, argfile, hive, processes)
def bstack1l1111l1ll_opy_(caller_id, datasources, is_last, item, outs_dir):
  global bstack11lll1111l_opy_
  global bstack1l1lllll1_opy_
  bstack1l1ll1l11_opy_ = copy.deepcopy(item)
  if not bstack1ll1lll_opy_ (u"࠭ࡶࡢࡴ࡬ࡥࡧࡲࡥࠨ௖") in item.options:
    bstack1l1ll1l11_opy_.options[bstack1ll1lll_opy_ (u"ࠧࡷࡣࡵ࡭ࡦࡨ࡬ࡦࠩௗ")] = []
  bstack1l11l11l11_opy_ = bstack1l1ll1l11_opy_.options[bstack1ll1lll_opy_ (u"ࠨࡸࡤࡶ࡮ࡧࡢ࡭ࡧࠪ௘")].copy()
  for v in bstack1l1ll1l11_opy_.options[bstack1ll1lll_opy_ (u"ࠩࡹࡥࡷ࡯ࡡࡣ࡮ࡨࠫ௙")]:
    if bstack1ll1lll_opy_ (u"ࠪࡆࡘ࡚ࡁࡄࡍࡓࡐࡆ࡚ࡆࡐࡔࡐࡍࡓࡊࡅ࡙ࠩ௚") in v:
      bstack1l11l11l11_opy_.remove(v)
    if bstack1ll1lll_opy_ (u"ࠫࡇ࡙ࡔࡂࡅࡎࡇࡑࡏࡁࡓࡉࡖࠫ௛") in v:
      bstack1l11l11l11_opy_.remove(v)
    if bstack1ll1lll_opy_ (u"ࠬࡈࡓࡕࡃࡆࡏࡉࡋࡆࡍࡑࡆࡅࡑࡏࡄࡆࡐࡗࡍࡋࡏࡅࡓࠩ௜") in v:
      bstack1l11l11l11_opy_.remove(v)
  bstack1l11l11l11_opy_.insert(0, bstack1ll1lll_opy_ (u"࠭ࡂࡔࡖࡄࡇࡐࡖࡌࡂࡖࡉࡓࡗࡓࡉࡏࡆࡈ࡜࠿ࢁࡽࠨ௝").format(bstack1l1ll1l11_opy_.platform_index))
  bstack1l11l11l11_opy_.insert(0, bstack1ll1lll_opy_ (u"ࠧࡃࡕࡗࡅࡈࡑࡄࡆࡈࡏࡓࡈࡇࡌࡊࡆࡈࡒ࡙ࡏࡆࡊࡇࡕ࠾ࢀࢃࠧ௞").format(bstack1l1ll1l11_opy_.bstack1llllll11l_opy_))
  bstack1l1ll1l11_opy_.options[bstack1ll1lll_opy_ (u"ࠨࡸࡤࡶ࡮ࡧࡢ࡭ࡧࠪ௟")] = bstack1l11l11l11_opy_
  if bstack1l1lllll1_opy_:
    bstack1l1ll1l11_opy_.options[bstack1ll1lll_opy_ (u"ࠩࡹࡥࡷ࡯ࡡࡣ࡮ࡨࠫ௠")].insert(0, bstack1ll1lll_opy_ (u"ࠪࡆࡘ࡚ࡁࡄࡍࡆࡐࡎࡇࡒࡈࡕ࠽ࡿࢂ࠭௡").format(bstack1l1lllll1_opy_))
  return bstack11lll1111l_opy_(caller_id, datasources, is_last, bstack1l1ll1l11_opy_, outs_dir)
def bstack1ll1ll1l11_opy_(command, item_index):
  try:
    if bstack11l1l11l_opy_.get_property(bstack1ll1lll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡣࡸ࡫ࡳࡴ࡫ࡲࡲࠬ௢")):
      os.environ[bstack1ll1lll_opy_ (u"ࠬࡉࡕࡓࡔࡈࡒ࡙ࡥࡐࡍࡃࡗࡊࡔࡘࡍࡠࡆࡄࡘࡆ࠭௣")] = json.dumps(CONFIG[bstack1ll1lll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩ௤")][item_index % bstack1l11l11l1l_opy_])
    global bstack1l1lllll1_opy_
    if bstack1l1lllll1_opy_:
      command[0] = command[0].replace(bstack1ll1lll_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠭௥"), bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠭ࡴࡦ࡮ࠤࡷࡵࡢࡰࡶ࠰࡭ࡳࡺࡥࡳࡰࡤࡰࠥ࠳࠭ࡣࡵࡷࡥࡨࡱ࡟ࡪࡶࡨࡱࡤ࡯࡮ࡥࡧࡻࠤࠬ௦") + str(
        item_index) + bstack1ll1lll_opy_ (u"ࠩࠣࠫ௧") + bstack1l1lllll1_opy_, 1)
    else:
      command[0] = command[0].replace(bstack1ll1lll_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩ௨"),
                                      bstack1ll1lll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠰ࡷࡩࡱࠠࡳࡱࡥࡳࡹ࠳ࡩ࡯ࡶࡨࡶࡳࡧ࡬ࠡ࠯࠰ࡦࡸࡺࡡࡤ࡭ࡢ࡭ࡹ࡫࡭ࡠ࡫ࡱࡨࡪࡾࠠࠨ௩") + str(item_index), 1)
  except Exception as e:
    logger.error(bstack1ll1lll_opy_ (u"ࠬࡋࡲࡳࡱࡵࠤࡲࡵࡤࡪࡨࡼ࡭ࡳ࡭ࠠࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡶࡡࡣࡱࡷࠤࡷࡻ࡮࠻ࠢࡾࢁࠬ௪").format(str(e)))
def bstack1l11llll1_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index):
  global bstack11lllll11l_opy_
  try:
    bstack1ll1ll1l11_opy_(command, item_index)
    return bstack11lllll11l_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index)
  except Exception as e:
    logger.error(bstack1ll1lll_opy_ (u"࠭ࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡲࡤࡦࡴࡺࠠࡳࡷࡱ࠾ࠥࢁࡽࠨ௫").format(str(e)))
    raise e
def bstack1l1ll11l11_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir):
  global bstack11lllll11l_opy_
  try:
    bstack1ll1ll1l11_opy_(command, item_index)
    return bstack11lllll11l_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir)
  except Exception as e:
    logger.error(bstack1ll1lll_opy_ (u"ࠧࡆࡴࡵࡳࡷࠦࡩ࡯ࠢࡳࡥࡧࡵࡴࠡࡴࡸࡲࠥ࠸࠮࠲࠵࠽ࠤࢀࢃࠧ௬").format(str(e)))
    try:
      return bstack11lllll11l_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index)
    except Exception as e2:
      logger.error(bstack1ll1lll_opy_ (u"ࠨࡇࡵࡶࡴࡸࠠࡪࡰࠣࡴࡦࡨ࡯ࡵࠢ࠵࠲࠶࠹ࠠࡧࡣ࡯ࡰࡧࡧࡣ࡬࠼ࠣࡿࢂ࠭௭").format(str(e2)))
      raise e
def bstack1l11111l1_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout):
  global bstack11lllll11l_opy_
  try:
    bstack1ll1ll1l11_opy_(command, item_index)
    if process_timeout is None:
      process_timeout = 3600
    return bstack11lllll11l_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout)
  except Exception as e:
    logger.error(bstack1ll1lll_opy_ (u"ࠩࡈࡶࡷࡵࡲࠡ࡫ࡱࠤࡵࡧࡢࡰࡶࠣࡶࡺࡴࠠ࠳࠰࠴࠹࠿ࠦࡻࡾࠩ௮").format(str(e)))
    try:
      return bstack11lllll11l_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir)
    except Exception as e2:
      logger.error(bstack1ll1lll_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥࡶࡡࡣࡱࡷࠤ࠷࠴࠱࠶ࠢࡩࡥࡱࡲࡢࡢࡥ࡮࠾ࠥࢁࡽࠨ௯").format(str(e2)))
      raise e
def _11lllll1l_opy_(bstack11lll1l1_opy_, item_index, process_timeout, sleep_before_start, bstack1llll1l111_opy_):
  bstack1ll1ll1l11_opy_(bstack11lll1l1_opy_, item_index)
  if process_timeout is None:
    process_timeout = 3600
  if sleep_before_start and sleep_before_start > 0:
    time.sleep(min(sleep_before_start, 5))
  return process_timeout
def bstack1ll11l111l_opy_(command, bstack11l11l111_opy_, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout, sleep_before_start):
  global bstack11lllll11l_opy_
  try:
    bstack1ll1ll1l11_opy_(command, item_index)
    if process_timeout is None:
      process_timeout = 3600
    if sleep_before_start and sleep_before_start > 0:
      time.sleep(min(sleep_before_start, 5))
    return bstack11lllll11l_opy_(command, bstack11l11l111_opy_, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout, sleep_before_start)
  except Exception as e:
    logger.error(bstack1ll1lll_opy_ (u"ࠫࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡰࡢࡤࡲࡸࠥࡸࡵ࡯ࠢ࠸࠲࠵ࡀࠠࡼࡿࠪ௰").format(str(e)))
    try:
      return bstack11lllll11l_opy_(command, bstack11l11l111_opy_, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout)
    except Exception as e2:
      logger.error(bstack1ll1lll_opy_ (u"ࠬࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡱࡣࡥࡳࡹࠦࡦࡢ࡮࡯ࡦࡦࡩ࡫࠻ࠢࡾࢁࠬ௱").format(str(e2)))
      raise e
def bstack1l11ll1111_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout, sleep_before_start):
  global bstack11lllll11l_opy_
  try:
    process_timeout = _11lllll1l_opy_(command, item_index, process_timeout, sleep_before_start, bstack1ll1lll_opy_ (u"࠭࠴࠯࠴ࠪ௲"))
    return bstack11lllll11l_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout, sleep_before_start)
  except Exception as e:
    logger.error(bstack1ll1lll_opy_ (u"ࠧࡆࡴࡵࡳࡷࠦࡩ࡯ࠢࡳࡥࡧࡵࡴࠡࡴࡸࡲࠥ࠺࠮࠳࠼ࠣࡿࢂ࠭௳").format(str(e)))
    try:
      return bstack11lllll11l_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout)
    except Exception as e2:
      logger.error(bstack1ll1lll_opy_ (u"ࠨࡇࡵࡶࡴࡸࠠࡪࡰࠣࡴࡦࡨ࡯ࡵࠢࡩࡥࡱࡲࡢࡢࡥ࡮࠾ࠥࢁࡽࠨ௴").format(str(e2)))
      raise e
def is_driver_active(driver):
  return True if driver and driver.session_id else False
def bstack11l1ll111l_opy_(self, runner, quiet=False, capture=True):
  global bstack1l1l1llll1_opy_
  bstack1ll11lll1_opy_ = bstack1l1l1llll1_opy_(self, runner, quiet=quiet, capture=capture)
  if self.exception:
    if not hasattr(runner, bstack1ll1lll_opy_ (u"ࠩࡨࡼࡨ࡫ࡰࡵ࡫ࡲࡲࡤࡧࡲࡳࠩ௵")):
      runner.exception_arr = []
    if not hasattr(runner, bstack1ll1lll_opy_ (u"ࠪࡩࡽࡩ࡟ࡵࡴࡤࡧࡪࡨࡡࡤ࡭ࡢࡥࡷࡸࠧ௶")):
      runner.exc_traceback_arr = []
    runner.exception = self.exception
    runner.exc_traceback = self.exc_traceback
    runner.exception_arr.append(self.exception)
    runner.exc_traceback_arr.append(self.exc_traceback)
  return bstack1ll11lll1_opy_
def bstack11ll1111l1_opy_(runner, hook_name, context, element, bstack1l11lll111_opy_, *args):
  try:
    if runner.hooks.get(hook_name):
      bstack11ll1l11l_opy_.bstack1llll11111_opy_(hook_name, element)
    bstack1l11lll111_opy_(runner, hook_name, context, *args)
    if runner.hooks.get(hook_name):
      bstack11ll1l11l_opy_.bstack1l1lll1111_opy_(element)
      if hook_name not in [bstack1ll1lll_opy_ (u"ࠫࡧ࡫ࡦࡰࡴࡨࡣࡦࡲ࡬ࠨ௷"), bstack1ll1lll_opy_ (u"ࠬࡧࡦࡵࡧࡵࡣࡦࡲ࡬ࠨ௸")] and args and hasattr(args[0], bstack1ll1lll_opy_ (u"࠭ࡥࡳࡴࡲࡶࡤࡳࡥࡴࡵࡤ࡫ࡪ࠭௹")):
        args[0].error_message = bstack1ll1lll_opy_ (u"ࠧࠨ௺")
  except Exception as e:
    logger.debug(bstack1ll1lll_opy_ (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤ࡭ࡧ࡮ࡥ࡮ࡨࠤ࡭ࡵ࡯࡬ࡵࠣ࡭ࡳࠦࡢࡦࡪࡤࡺࡪࡀࠠࡼࡿࠪ௻").format(str(e)))
@measure(event_name=EVENTS.bstack11ll1l11l1_opy_, stage=STAGE.bstack111lll1l11_opy_, hook_type=bstack1ll1lll_opy_ (u"ࠤࡥࡩ࡫ࡵࡲࡦࡃ࡯ࡰࠧ௼"), bstack11lllll111_opy_=bstack1lll11111l_opy_)
def bstack1l11l11111_opy_(runner, name, context, bstack1l11lll111_opy_, *args):
    if runner.hooks.get(bstack1ll1lll_opy_ (u"ࠥࡦࡪ࡬࡯ࡳࡧࡢࡥࡱࡲࠢ௽")).__name__ != bstack1ll1lll_opy_ (u"ࠦࡧ࡫ࡦࡰࡴࡨࡣࡦࡲ࡬ࡠࡦࡨࡪࡦࡻ࡬ࡵࡡ࡫ࡳࡴࡱࠢ௾"):
      bstack11ll1111l1_opy_(runner, name, context, runner, bstack1l11lll111_opy_, *args)
    try:
      threading.current_thread().bstackSessionDriver if bstack11l111l111_opy_(bstack1ll1lll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯ࡘ࡫ࡳࡴ࡫ࡲࡲࡉࡸࡩࡷࡧࡵࠫ௿")) else context.browser
      runner.driver_initialised = bstack1ll1lll_opy_ (u"ࠨࡢࡦࡨࡲࡶࡪࡥࡡ࡭࡮ࠥఀ")
    except Exception as e:
      logger.debug(bstack1ll1lll_opy_ (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡷࡪࡺࠠࡥࡴ࡬ࡺࡪࡸࠠࡪࡰ࡬ࡸ࡮ࡧ࡬ࡪࡵࡨࠤࡦࡺࡴࡳ࡫ࡥࡹࡹ࡫࠺ࠡࡽࢀࠫఁ").format(str(e)))
def bstack11l11l1ll1_opy_(runner, name, context, bstack1l11lll111_opy_, *args):
    bstack11ll1111l1_opy_(runner, name, context, context.feature, bstack1l11lll111_opy_, *args)
    try:
      if not bstack1l1l11ll1_opy_:
        bstack1llll1lll_opy_ = threading.current_thread().bstackSessionDriver if bstack11l111l111_opy_(bstack1ll1lll_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫ࡔࡧࡶࡷ࡮ࡵ࡮ࡅࡴ࡬ࡺࡪࡸࠧం")) else context.browser
        if is_driver_active(bstack1llll1lll_opy_):
          if runner.driver_initialised is None: runner.driver_initialised = bstack1ll1lll_opy_ (u"ࠤࡥࡩ࡫ࡵࡲࡦࡡࡩࡩࡦࡺࡵࡳࡧࠥః")
          bstack1lll11ll1_opy_ = str(runner.feature.name)
          bstack1l1l1ll1l1_opy_(context, bstack1lll11ll1_opy_)
          bstack1llll1lll_opy_.execute_script(bstack1ll1lll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡷࡪࡺࡓࡦࡵࡶ࡭ࡴࡴࡎࡢ࡯ࡨࠦ࠱ࠦࠢࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠥ࠾ࠥࢁࠢ࡯ࡣࡰࡩࠧࡀࠠࠨఄ") + json.dumps(bstack1lll11ll1_opy_) + bstack1ll1lll_opy_ (u"ࠫࢂࢃࠧఅ"))
    except Exception as e:
      logger.debug(bstack1ll1lll_opy_ (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡵࡨࡸࠥࡹࡥࡴࡵ࡬ࡳࡳࠦ࡮ࡢ࡯ࡨࠤ࡮ࡴࠠࡣࡧࡩࡳࡷ࡫ࠠࡧࡧࡤࡸࡺࡸࡥ࠻ࠢࡾࢁࠬఆ").format(str(e)))
def bstack11ll11lll1_opy_(runner, name, context, bstack1l11lll111_opy_, *args):
    if hasattr(context, bstack1ll1lll_opy_ (u"࠭ࡳࡤࡧࡱࡥࡷ࡯࡯ࠨఇ")):
        bstack11ll1l11l_opy_.start_test(context)
    target = context.scenario if hasattr(context, bstack1ll1lll_opy_ (u"ࠧࡴࡥࡨࡲࡦࡸࡩࡰࠩఈ")) else context.feature
    bstack11ll1111l1_opy_(runner, name, context, target, bstack1l11lll111_opy_, *args)
@measure(event_name=EVENTS.bstack1l11l1111_opy_, stage=STAGE.bstack111lll1l11_opy_, bstack11lllll111_opy_=bstack1lll11111l_opy_)
def bstack1l1l11lll_opy_(runner, name, context, bstack1l11lll111_opy_, *args):
    if len(context.scenario.tags) == 0: bstack11ll1l11l_opy_.start_test(context)
    bstack11ll1111l1_opy_(runner, name, context, context.scenario, bstack1l11lll111_opy_, *args)
    threading.current_thread().a11y_stop = False
    bstack1ll111l11l_opy_.bstack11l1ll1ll_opy_(context, *args)
    try:
      bstack1llll1lll_opy_ = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫ࡔࡧࡶࡷ࡮ࡵ࡮ࡅࡴ࡬ࡺࡪࡸࠧఉ"), context.browser)
      if is_driver_active(bstack1llll1lll_opy_):
        bstack1l111l111l_opy_.bstack1llll1lll1_opy_(bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡕࡨࡷࡸ࡯࡯࡯ࡆࡵ࡭ࡻ࡫ࡲࠨఊ"), {}))
        if runner.driver_initialised is None: runner.driver_initialised = bstack1ll1lll_opy_ (u"ࠥࡦࡪ࡬࡯ࡳࡧࡢࡷࡨ࡫࡮ࡢࡴ࡬ࡳࠧఋ")
        if (not bstack1l1l11ll1_opy_):
          scenario_name = args[0].name
          feature_name = bstack1lll11ll1_opy_ = str(runner.feature.name)
          bstack1lll11ll1_opy_ = feature_name + bstack1ll1lll_opy_ (u"ࠫࠥ࠳ࠠࠨఌ") + scenario_name
          if runner.driver_initialised == bstack1ll1lll_opy_ (u"ࠧࡨࡥࡧࡱࡵࡩࡤࡹࡣࡦࡰࡤࡶ࡮ࡵࠢ఍"):
            bstack1l1l1ll1l1_opy_(context, bstack1lll11ll1_opy_)
            bstack1llll1lll_opy_.execute_script(bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡲࡦࡳࡥࠣ࠼ࠣࠫఎ") + json.dumps(bstack1lll11ll1_opy_) + bstack1ll1lll_opy_ (u"ࠧࡾࡿࠪఏ"))
    except Exception as e:
      logger.debug(bstack1ll1lll_opy_ (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡸ࡫ࡴࠡࡵࡨࡷࡸ࡯࡯࡯ࠢࡱࡥࡲ࡫ࠠࡪࡰࠣࡦࡪ࡬࡯ࡳࡧࠣࡷࡨ࡫࡮ࡢࡴ࡬ࡳ࠿ࠦࡻࡾࠩఐ").format(str(e)))
@measure(event_name=EVENTS.bstack11ll1l11l1_opy_, stage=STAGE.bstack111lll1l11_opy_, hook_type=bstack1ll1lll_opy_ (u"ࠤࡥࡩ࡫ࡵࡲࡦࡕࡷࡩࡵࠨ఑"), bstack11lllll111_opy_=bstack1lll11111l_opy_)
def bstack11l11l1111_opy_(runner, name, context, bstack1l11lll111_opy_, *args):
    bstack11ll1111l1_opy_(runner, name, context, args[0], bstack1l11lll111_opy_, *args)
    try:
      bstack1llll1lll_opy_ = threading.current_thread().bstackSessionDriver if bstack11l111l111_opy_(bstack1ll1lll_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭ࡖࡩࡸࡹࡩࡰࡰࡇࡶ࡮ࡼࡥࡳࠩఒ")) else context.browser
      if is_driver_active(bstack1llll1lll_opy_):
        if runner.driver_initialised is None: runner.driver_initialised = bstack1ll1lll_opy_ (u"ࠦࡧ࡫ࡦࡰࡴࡨࡣࡸࡺࡥࡱࠤఓ")
        bstack11ll1l11l_opy_.bstack1l111ll1l_opy_(args[0])
        if runner.driver_initialised == bstack1ll1lll_opy_ (u"ࠧࡨࡥࡧࡱࡵࡩࡤࡹࡴࡦࡲࠥఔ"):
          feature_name = bstack1lll11ll1_opy_ = str(runner.feature.name)
          bstack1lll11ll1_opy_ = feature_name + bstack1ll1lll_opy_ (u"࠭ࠠ࠮ࠢࠪక") + context.scenario.name
          bstack1llll1lll_opy_.execute_script(bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡳࡧ࡭ࡦࠤ࠽ࠤࠬఖ") + json.dumps(bstack1lll11ll1_opy_) + bstack1ll1lll_opy_ (u"ࠨࡿࢀࠫగ"))
    except Exception as e:
      logger.debug(bstack1ll1lll_opy_ (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡹࡥࡵࠢࡶࡩࡸࡹࡩࡰࡰࠣࡲࡦࡳࡥࠡ࡫ࡱࠤࡧ࡫ࡦࡰࡴࡨࠤࡸࡺࡥࡱ࠼ࠣࡿࢂ࠭ఘ").format(str(e)))
@measure(event_name=EVENTS.bstack11ll1l11l1_opy_, stage=STAGE.bstack111lll1l11_opy_, hook_type=bstack1ll1lll_opy_ (u"ࠥࡥ࡫ࡺࡥࡳࡕࡷࡩࡵࠨఙ"), bstack11lllll111_opy_=bstack1lll11111l_opy_)
def bstack111lll1ll_opy_(runner, name, context, bstack1l11lll111_opy_, *args):
  bstack11ll1l11l_opy_.bstack111lll1l1_opy_(args[0])
  try:
    step_status = args[0].status.name
    bstack1llll1lll_opy_ = threading.current_thread().bstackSessionDriver if bstack1ll1lll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡗࡪࡹࡳࡪࡱࡱࡈࡷ࡯ࡶࡦࡴࠪచ") in threading.current_thread().__dict__.keys() else context.browser
    if is_driver_active(bstack1llll1lll_opy_):
      if runner.driver_initialised is None:
        runner.driver_initialised  = bstack1ll1lll_opy_ (u"ࠬ࡯࡮ࡴࡶࡨࡴࠬఛ")
        feature_name = bstack1lll11ll1_opy_ = str(runner.feature.name)
        bstack1lll11ll1_opy_ = feature_name + bstack1ll1lll_opy_ (u"࠭ࠠ࠮ࠢࠪజ") + context.scenario.name
        bstack1llll1lll_opy_.execute_script(bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡳࡧ࡭ࡦࠤ࠽ࠤࠬఝ") + json.dumps(bstack1lll11ll1_opy_) + bstack1ll1lll_opy_ (u"ࠨࡿࢀࠫఞ"))
    if str(step_status).lower() == bstack1ll1lll_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩట"):
      bstack1l1llllll_opy_ = bstack1ll1lll_opy_ (u"ࠪࠫఠ")
      bstack11l11lllll_opy_ = bstack1ll1lll_opy_ (u"ࠫࠬడ")
      bstack1l1l11ll_opy_ = bstack1ll1lll_opy_ (u"ࠬ࠭ఢ")
      try:
        import traceback
        bstack1l1llllll_opy_ = runner.exception.__class__.__name__
        bstack11l1111l1_opy_ = traceback.format_tb(runner.exc_traceback)
        bstack11l11lllll_opy_ = bstack1ll1lll_opy_ (u"࠭ࠠࠨణ").join(bstack11l1111l1_opy_)
        bstack1l1l11ll_opy_ = bstack11l1111l1_opy_[-1]
      except Exception as e:
        logger.debug(bstack111l1llll_opy_.format(str(e)))
      bstack1l1llllll_opy_ += bstack1l1l11ll_opy_
      bstack111l1l1l1_opy_(context, json.dumps(str(args[0].name) + bstack1ll1lll_opy_ (u"ࠢࠡ࠯ࠣࡊࡦ࡯࡬ࡦࡦࠤࡠࡳࠨత") + str(bstack11l11lllll_opy_)),
                          bstack1ll1lll_opy_ (u"ࠣࡧࡵࡶࡴࡸࠢథ"))
      if runner.driver_initialised == bstack1ll1lll_opy_ (u"ࠤࡥࡩ࡫ࡵࡲࡦࡡࡶࡸࡪࡶࠢద"):
        bstack1l11l1l11l_opy_(getattr(context, bstack1ll1lll_opy_ (u"ࠪࡴࡦ࡭ࡥࠨధ"), None), bstack1ll1lll_opy_ (u"ࠦ࡫ࡧࡩ࡭ࡧࡧࠦన"), bstack1l1llllll_opy_)
        bstack1llll1lll_opy_.execute_script(bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡧ࡮࡯ࡱࡷࡥࡹ࡫ࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡨࡦࡺࡡࠣ࠼ࠪ఩") + json.dumps(str(args[0].name) + bstack1ll1lll_opy_ (u"ࠨࠠ࠮ࠢࡉࡥ࡮ࡲࡥࡥࠣ࡟ࡲࠧప") + str(bstack11l11lllll_opy_)) + bstack1ll1lll_opy_ (u"ࠧ࠭ࠢࠥࡰࡪࡼࡥ࡭ࠤ࠽ࠤࠧ࡫ࡲࡳࡱࡵࠦࢂࢃࠧఫ"))
      if runner.driver_initialised == bstack1ll1lll_opy_ (u"ࠣࡤࡨࡪࡴࡸࡥࡠࡵࡷࡩࡵࠨబ"):
        bstack1l1lll1ll1_opy_(bstack1llll1lll_opy_, bstack1ll1lll_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩభ"), bstack1ll1lll_opy_ (u"ࠥࡗࡨ࡫࡮ࡢࡴ࡬ࡳࠥ࡬ࡡࡪ࡮ࡨࡨࠥࡽࡩࡵࡪ࠽ࠤࡡࡴࠢమ") + str(bstack1l1llllll_opy_))
    else:
      bstack111l1l1l1_opy_(context, bstack1ll1lll_opy_ (u"ࠦࡕࡧࡳࡴࡧࡧࠥࠧయ"), bstack1ll1lll_opy_ (u"ࠧ࡯࡮ࡧࡱࠥర"))
      if runner.driver_initialised == bstack1ll1lll_opy_ (u"ࠨࡢࡦࡨࡲࡶࡪࡥࡳࡵࡧࡳࠦఱ"):
        bstack1l11l1l11l_opy_(getattr(context, bstack1ll1lll_opy_ (u"ࠧࡱࡣࡪࡩࠬల"), None), bstack1ll1lll_opy_ (u"ࠣࡲࡤࡷࡸ࡫ࡤࠣళ"))
      bstack1llll1lll_opy_.execute_script(bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠡࠤࡤࡲࡳࡵࡴࡢࡶࡨࠦ࠱ࠦࠢࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠥ࠾ࠥࢁࠢࡥࡣࡷࡥࠧࡀࠧఴ") + json.dumps(str(args[0].name) + bstack1ll1lll_opy_ (u"ࠥࠤ࠲ࠦࡐࡢࡵࡶࡩࡩࠧࠢవ")) + bstack1ll1lll_opy_ (u"ࠫ࠱ࠦࠢ࡭ࡧࡹࡩࡱࠨ࠺ࠡࠤ࡬ࡲ࡫ࡵࠢࡾࡿࠪశ"))
      if runner.driver_initialised == bstack1ll1lll_opy_ (u"ࠧࡨࡥࡧࡱࡵࡩࡤࡹࡴࡦࡲࠥష"):
        bstack1l1lll1ll1_opy_(bstack1llll1lll_opy_, bstack1ll1lll_opy_ (u"ࠨࡰࡢࡵࡶࡩࡩࠨస"))
  except Exception as e:
    logger.debug(bstack1ll1lll_opy_ (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡱࡦࡸ࡫ࠡࡵࡨࡷࡸ࡯࡯࡯ࠢࡶࡸࡦࡺࡵࡴࠢ࡬ࡲࠥࡧࡦࡵࡧࡵࠤࡸࡺࡥࡱ࠼ࠣࡿࢂ࠭హ").format(str(e)))
  bstack11ll1111l1_opy_(runner, name, context, args[0], bstack1l11lll111_opy_, *args)
@measure(event_name=EVENTS.bstack111llll1l_opy_, stage=STAGE.bstack111lll1l11_opy_, bstack11lllll111_opy_=bstack1lll11111l_opy_)
def bstack1l111l1lll_opy_(runner, name, context, bstack1l11lll111_opy_, *args):
  bstack11ll1l11l_opy_.end_test(args[0])
  try:
    bstack11lll11ll1_opy_ = args[0].status.name
    bstack1llll1lll_opy_ = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫ࡔࡧࡶࡷ࡮ࡵ࡮ࡅࡴ࡬ࡺࡪࡸࠧ఺"), context.browser)
    bstack1ll111l11l_opy_.bstack11111ll1l_opy_(bstack1llll1lll_opy_)
    if str(bstack11lll11ll1_opy_).lower() == bstack1ll1lll_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ఻"):
      bstack1l1llllll_opy_ = bstack1ll1lll_opy_ (u"఼ࠪࠫ")
      bstack11l11lllll_opy_ = bstack1ll1lll_opy_ (u"ࠫࠬఽ")
      bstack1l1l11ll_opy_ = bstack1ll1lll_opy_ (u"ࠬ࠭ా")
      try:
        import traceback
        bstack1l1llllll_opy_ = runner.exception.__class__.__name__
        bstack11l1111l1_opy_ = traceback.format_tb(runner.exc_traceback)
        bstack11l11lllll_opy_ = bstack1ll1lll_opy_ (u"࠭ࠠࠨి").join(bstack11l1111l1_opy_)
        bstack1l1l11ll_opy_ = bstack11l1111l1_opy_[-1]
      except Exception as e:
        logger.debug(bstack111l1llll_opy_.format(str(e)))
      bstack1l1llllll_opy_ += bstack1l1l11ll_opy_
      bstack111l1l1l1_opy_(context, json.dumps(str(args[0].name) + bstack1ll1lll_opy_ (u"ࠢࠡ࠯ࠣࡊࡦ࡯࡬ࡦࡦࠤࡠࡳࠨీ") + str(bstack11l11lllll_opy_)),
                          bstack1ll1lll_opy_ (u"ࠣࡧࡵࡶࡴࡸࠢు"))
      if runner.driver_initialised == bstack1ll1lll_opy_ (u"ࠤࡥࡩ࡫ࡵࡲࡦࡡࡶࡧࡪࡴࡡࡳ࡫ࡲࠦూ") or runner.driver_initialised == bstack1ll1lll_opy_ (u"ࠪ࡭ࡳࡹࡴࡦࡲࠪృ"):
        bstack1l11l1l11l_opy_(getattr(context, bstack1ll1lll_opy_ (u"ࠫࡵࡧࡧࡦࠩౄ"), None), bstack1ll1lll_opy_ (u"ࠧ࡬ࡡࡪ࡮ࡨࡨࠧ౅"), bstack1l1llllll_opy_)
        bstack1llll1lll_opy_.execute_script(bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡡ࡯ࡰࡲࡸࡦࡺࡥࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡩࡧࡴࡢࠤ࠽ࠫె") + json.dumps(str(args[0].name) + bstack1ll1lll_opy_ (u"ࠢࠡ࠯ࠣࡊࡦ࡯࡬ࡦࡦࠤࡠࡳࠨే") + str(bstack11l11lllll_opy_)) + bstack1ll1lll_opy_ (u"ࠨ࠮ࠣࠦࡱ࡫ࡶࡦ࡮ࠥ࠾ࠥࠨࡥࡳࡴࡲࡶࠧࢃࡽࠨై"))
      if runner.driver_initialised == bstack1ll1lll_opy_ (u"ࠤࡥࡩ࡫ࡵࡲࡦࡡࡶࡧࡪࡴࡡࡳ࡫ࡲࠦ౉") or runner.driver_initialised == bstack1ll1lll_opy_ (u"ࠪ࡭ࡳࡹࡴࡦࡲࠪొ"):
        bstack1l1lll1ll1_opy_(bstack1llll1lll_opy_, bstack1ll1lll_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫో"), bstack1ll1lll_opy_ (u"࡙ࠧࡣࡦࡰࡤࡶ࡮ࡵࠠࡧࡣ࡬ࡰࡪࡪࠠࡸ࡫ࡷ࡬࠿ࠦ࡜࡯ࠤౌ") + str(bstack1l1llllll_opy_))
    else:
      bstack111l1l1l1_opy_(context, bstack1ll1lll_opy_ (u"ࠨࡐࡢࡵࡶࡩࡩ్ࠧࠢ"), bstack1ll1lll_opy_ (u"ࠢࡪࡰࡩࡳࠧ౎"))
      if runner.driver_initialised == bstack1ll1lll_opy_ (u"ࠣࡤࡨࡪࡴࡸࡥࡠࡵࡦࡩࡳࡧࡲࡪࡱࠥ౏") or runner.driver_initialised == bstack1ll1lll_opy_ (u"ࠩ࡬ࡲࡸࡺࡥࡱࠩ౐"):
        bstack1l11l1l11l_opy_(getattr(context, bstack1ll1lll_opy_ (u"ࠪࡴࡦ࡭ࡥࠨ౑"), None), bstack1ll1lll_opy_ (u"ࠦࡵࡧࡳࡴࡧࡧࠦ౒"))
      bstack1llll1lll_opy_.execute_script(bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡧ࡮࡯ࡱࡷࡥࡹ࡫ࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡨࡦࡺࡡࠣ࠼ࠪ౓") + json.dumps(str(args[0].name) + bstack1ll1lll_opy_ (u"ࠨࠠ࠮ࠢࡓࡥࡸࡹࡥࡥࠣࠥ౔")) + bstack1ll1lll_opy_ (u"ࠧ࠭ࠢࠥࡰࡪࡼࡥ࡭ࠤ࠽ࠤࠧ࡯࡮ࡧࡱࠥࢁࢂౕ࠭"))
      if runner.driver_initialised == bstack1ll1lll_opy_ (u"ࠣࡤࡨࡪࡴࡸࡥࡠࡵࡦࡩࡳࡧࡲࡪࡱౖࠥ") or runner.driver_initialised == bstack1ll1lll_opy_ (u"ࠩ࡬ࡲࡸࡺࡥࡱࠩ౗"):
        bstack1l1lll1ll1_opy_(bstack1llll1lll_opy_, bstack1ll1lll_opy_ (u"ࠥࡴࡦࡹࡳࡦࡦࠥౘ"))
  except Exception as e:
    logger.debug(bstack1ll1lll_opy_ (u"ࠫࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠ࡮ࡣࡵ࡯ࠥࡹࡥࡴࡵ࡬ࡳࡳࠦࡳࡵࡣࡷࡹࡸࠦࡩ࡯ࠢࡤࡪࡹ࡫ࡲࠡࡨࡨࡥࡹࡻࡲࡦ࠼ࠣࡿࢂ࠭ౙ").format(str(e)))
  bstack11ll1111l1_opy_(runner, name, context, context.scenario, bstack1l11lll111_opy_, *args)
  if len(context.scenario.tags) == 0: threading.current_thread().current_test_uuid = None
def bstack111ll11l_opy_(runner, name, context, bstack1l11lll111_opy_, *args):
    target = context.scenario if hasattr(context, bstack1ll1lll_opy_ (u"ࠬࡹࡣࡦࡰࡤࡶ࡮ࡵࠧౚ")) else context.feature
    bstack11ll1111l1_opy_(runner, name, context, target, bstack1l11lll111_opy_, *args)
    threading.current_thread().current_test_uuid = None
def bstack11l11lll_opy_(runner, name, context, bstack1l11lll111_opy_, *args):
    try:
      bstack1llll1lll_opy_ = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰ࡙ࡥࡴࡵ࡬ࡳࡳࡊࡲࡪࡸࡨࡶࠬ౛"), context.browser)
      bstack1ll111l11_opy_ = bstack1ll1lll_opy_ (u"ࠧࠨ౜")
      if context.failed is True:
        bstack11l1ll11_opy_ = []
        bstack1llll11ll1_opy_ = []
        bstack1lllllll1l_opy_ = []
        try:
          import traceback
          for exc in runner.exception_arr:
            bstack11l1ll11_opy_.append(exc.__class__.__name__)
          for exc_tb in runner.exc_traceback_arr:
            bstack11l1111l1_opy_ = traceback.format_tb(exc_tb)
            bstack1llll1ll_opy_ = bstack1ll1lll_opy_ (u"ࠨࠢࠪౝ").join(bstack11l1111l1_opy_)
            bstack1llll11ll1_opy_.append(bstack1llll1ll_opy_)
            bstack1lllllll1l_opy_.append(bstack11l1111l1_opy_[-1])
        except Exception as e:
          logger.debug(bstack111l1llll_opy_.format(str(e)))
        bstack1l1llllll_opy_ = bstack1ll1lll_opy_ (u"ࠩࠪ౞")
        for i in range(len(bstack11l1ll11_opy_)):
          bstack1l1llllll_opy_ += bstack11l1ll11_opy_[i] + bstack1lllllll1l_opy_[i] + bstack1ll1lll_opy_ (u"ࠪࡠࡳ࠭౟")
        bstack1ll111l11_opy_ = bstack1ll1lll_opy_ (u"ࠫࠥ࠭ౠ").join(bstack1llll11ll1_opy_)
        if runner.driver_initialised in [bstack1ll1lll_opy_ (u"ࠧࡨࡥࡧࡱࡵࡩࡤ࡬ࡥࡢࡶࡸࡶࡪࠨౡ"), bstack1ll1lll_opy_ (u"ࠨࡢࡦࡨࡲࡶࡪࡥࡡ࡭࡮ࠥౢ")]:
          bstack111l1l1l1_opy_(context, bstack1ll111l11_opy_, bstack1ll1lll_opy_ (u"ࠢࡦࡴࡵࡳࡷࠨౣ"))
          bstack1l11l1l11l_opy_(getattr(context, bstack1ll1lll_opy_ (u"ࠨࡲࡤ࡫ࡪ࠭౤"), None), bstack1ll1lll_opy_ (u"ࠤࡩࡥ࡮ࡲࡥࡥࠤ౥"), bstack1l1llllll_opy_)
          bstack1llll1lll_opy_.execute_script(bstack1ll1lll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡥࡳࡴ࡯ࡵࡣࡷࡩࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡦࡤࡸࡦࠨ࠺ࠨ౦") + json.dumps(bstack1ll111l11_opy_) + bstack1ll1lll_opy_ (u"ࠫ࠱ࠦࠢ࡭ࡧࡹࡩࡱࠨ࠺ࠡࠤࡨࡶࡷࡵࡲࠣࡿࢀࠫ౧"))
          bstack1l1lll1ll1_opy_(bstack1llll1lll_opy_, bstack1ll1lll_opy_ (u"ࠧ࡬ࡡࡪ࡮ࡨࡨࠧ౨"), bstack1ll1lll_opy_ (u"ࠨࡓࡰ࡯ࡨࠤࡸࡩࡥ࡯ࡣࡵ࡭ࡴࡹࠠࡧࡣ࡬ࡰࡪࡪ࠺ࠡ࡞ࡱࠦ౩") + str(bstack1l1llllll_opy_))
          bstack11l1l1l1l1_opy_ = bstack1ll111ll_opy_(bstack1ll111l11_opy_, runner.feature.name, logger)
          if (bstack11l1l1l1l1_opy_ != None):
            bstack11l1l1l11l_opy_.append(bstack11l1l1l1l1_opy_)
      else:
        if runner.driver_initialised in [bstack1ll1lll_opy_ (u"ࠢࡣࡧࡩࡳࡷ࡫࡟ࡧࡧࡤࡸࡺࡸࡥࠣ౪"), bstack1ll1lll_opy_ (u"ࠣࡤࡨࡪࡴࡸࡥࡠࡣ࡯ࡰࠧ౫")]:
          bstack111l1l1l1_opy_(context, bstack1ll1lll_opy_ (u"ࠤࡉࡩࡦࡺࡵࡳࡧ࠽ࠤࠧ౬") + str(runner.feature.name) + bstack1ll1lll_opy_ (u"ࠥࠤࡵࡧࡳࡴࡧࡧࠥࠧ౭"), bstack1ll1lll_opy_ (u"ࠦ࡮ࡴࡦࡰࠤ౮"))
          bstack1l11l1l11l_opy_(getattr(context, bstack1ll1lll_opy_ (u"ࠬࡶࡡࡨࡧࠪ౯"), None), bstack1ll1lll_opy_ (u"ࠨࡰࡢࡵࡶࡩࡩࠨ౰"))
          bstack1llll1lll_opy_.execute_script(bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡢࡰࡱࡳࡹࡧࡴࡦࠤ࠯ࠤࠧࡧࡲࡨࡷࡰࡩࡳࡺࡳࠣ࠼ࠣࡿࠧࡪࡡࡵࡣࠥ࠾ࠬ౱") + json.dumps(bstack1ll1lll_opy_ (u"ࠣࡈࡨࡥࡹࡻࡲࡦ࠼ࠣࠦ౲") + str(runner.feature.name) + bstack1ll1lll_opy_ (u"ࠤࠣࡴࡦࡹࡳࡦࡦࠤࠦ౳")) + bstack1ll1lll_opy_ (u"ࠪ࠰ࠥࠨ࡬ࡦࡸࡨࡰࠧࡀࠠࠣ࡫ࡱࡪࡴࠨࡽࡾࠩ౴"))
          bstack1l1lll1ll1_opy_(bstack1llll1lll_opy_, bstack1ll1lll_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫ౵"))
          bstack11l1l1l1l1_opy_ = bstack1ll111ll_opy_(bstack1ll111l11_opy_, runner.feature.name, logger)
          if (bstack11l1l1l1l1_opy_ != None):
            bstack11l1l1l11l_opy_.append(bstack11l1l1l1l1_opy_)
    except Exception as e:
      logger.debug(bstack1ll1lll_opy_ (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡ࡯ࡤࡶࡰࠦࡳࡦࡵࡶ࡭ࡴࡴࠠࡴࡶࡤࡸࡺࡹࠠࡪࡰࠣࡥ࡫ࡺࡥࡳࠢࡩࡩࡦࡺࡵࡳࡧ࠽ࠤࢀࢃࠧ౶").format(str(e)))
    bstack11ll1111l1_opy_(runner, name, context, context.feature, bstack1l11lll111_opy_, *args)
@measure(event_name=EVENTS.bstack11ll1l11l1_opy_, stage=STAGE.bstack111lll1l11_opy_, hook_type=bstack1ll1lll_opy_ (u"ࠨࡡࡧࡶࡨࡶࡆࡲ࡬ࠣ౷"), bstack11lllll111_opy_=bstack1lll11111l_opy_)
def bstack11lll111l1_opy_(runner, name, context, bstack1l11lll111_opy_, *args):
    bstack11ll1111l1_opy_(runner, name, context, runner, bstack1l11lll111_opy_, *args)
def bstack1lllll1ll_opy_(self, name, context, *args):
  try:
    if bstack1l11111l1l_opy_:
      platform_index = int(threading.current_thread()._name) % bstack1l11l11l1l_opy_
      bstack11l1lll1l1_opy_ = CONFIG[bstack1ll1lll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪ౸")][platform_index]
      os.environ[bstack1ll1lll_opy_ (u"ࠨࡅࡘࡖࡗࡋࡎࡕࡡࡓࡐࡆ࡚ࡆࡐࡔࡐࡣࡉࡇࡔࡂࠩ౹")] = json.dumps(bstack11l1lll1l1_opy_)
    global bstack1l11lll111_opy_
    if not hasattr(self, bstack1ll1lll_opy_ (u"ࠩࡧࡶ࡮ࡼࡥࡳࡡ࡬ࡲ࡮ࡺࡩࡢ࡮࡬ࡷࡪࡪࠧ౺")):
      self.driver_initialised = None
    bstack1lll1l11l1_opy_ = {
        bstack1ll1lll_opy_ (u"ࠪࡦࡪ࡬࡯ࡳࡧࡢࡥࡱࡲࠧ౻"): bstack1l11l11111_opy_,
        bstack1ll1lll_opy_ (u"ࠫࡧ࡫ࡦࡰࡴࡨࡣ࡫࡫ࡡࡵࡷࡵࡩࠬ౼"): bstack11l11l1ll1_opy_,
        bstack1ll1lll_opy_ (u"ࠬࡨࡥࡧࡱࡵࡩࡤࡺࡡࡨࠩ౽"): bstack11ll11lll1_opy_,
        bstack1ll1lll_opy_ (u"࠭ࡢࡦࡨࡲࡶࡪࡥࡳࡤࡧࡱࡥࡷ࡯࡯ࠨ౾"): bstack1l1l11lll_opy_,
        bstack1ll1lll_opy_ (u"ࠧࡣࡧࡩࡳࡷ࡫࡟ࡴࡶࡨࡴࠬ౿"): bstack11l11l1111_opy_,
        bstack1ll1lll_opy_ (u"ࠨࡣࡩࡸࡪࡸ࡟ࡴࡶࡨࡴࠬಀ"): bstack111lll1ll_opy_,
        bstack1ll1lll_opy_ (u"ࠩࡤࡪࡹ࡫ࡲࡠࡵࡦࡩࡳࡧࡲࡪࡱࠪಁ"): bstack1l111l1lll_opy_,
        bstack1ll1lll_opy_ (u"ࠪࡥ࡫ࡺࡥࡳࡡࡷࡥ࡬࠭ಂ"): bstack111ll11l_opy_,
        bstack1ll1lll_opy_ (u"ࠫࡦ࡬ࡴࡦࡴࡢࡪࡪࡧࡴࡶࡴࡨࠫಃ"): bstack11l11lll_opy_,
        bstack1ll1lll_opy_ (u"ࠬࡧࡦࡵࡧࡵࡣࡦࡲ࡬ࠨ಄"): bstack11lll111l1_opy_
    }
    handler = bstack1lll1l11l1_opy_.get(name, bstack1l11lll111_opy_)
    try:
      handler(self, name, context, bstack1l11lll111_opy_, *args)
    except Exception as e:
      logger.debug(bstack1ll1lll_opy_ (u"࠭ࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡤࡨ࡬ࡦࡼࡥࠡࡪࡲࡳࡰࠦࡨࡢࡰࡧࡰࡪࡸࠠࡼࡿ࠽ࠤࢀࢃࠧಅ").format(name, str(e)))
    if name in [bstack1ll1lll_opy_ (u"ࠧࡢࡨࡷࡩࡷࡥࡦࡦࡣࡷࡹࡷ࡫ࠧಆ"), bstack1ll1lll_opy_ (u"ࠨࡣࡩࡸࡪࡸ࡟ࡴࡥࡨࡲࡦࡸࡩࡰࠩಇ"), bstack1ll1lll_opy_ (u"ࠩࡤࡪࡹ࡫ࡲࡠࡣ࡯ࡰࠬಈ")]:
      try:
        bstack1llll1lll_opy_ = threading.current_thread().bstackSessionDriver if bstack11l111l111_opy_(bstack1ll1lll_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭ࡖࡩࡸࡹࡩࡰࡰࡇࡶ࡮ࡼࡥࡳࠩಉ")) else context.browser
        bstack1l1l1ll1l_opy_ = (
          (name == bstack1ll1lll_opy_ (u"ࠫࡦ࡬ࡴࡦࡴࡢࡥࡱࡲࠧಊ") and self.driver_initialised == bstack1ll1lll_opy_ (u"ࠧࡨࡥࡧࡱࡵࡩࡤࡧ࡬࡭ࠤಋ")) or
          (name == bstack1ll1lll_opy_ (u"࠭ࡡࡧࡶࡨࡶࡤ࡬ࡥࡢࡶࡸࡶࡪ࠭ಌ") and self.driver_initialised == bstack1ll1lll_opy_ (u"ࠢࡣࡧࡩࡳࡷ࡫࡟ࡧࡧࡤࡸࡺࡸࡥࠣ಍")) or
          (name == bstack1ll1lll_opy_ (u"ࠨࡣࡩࡸࡪࡸ࡟ࡴࡥࡨࡲࡦࡸࡩࡰࠩಎ") and self.driver_initialised in [bstack1ll1lll_opy_ (u"ࠤࡥࡩ࡫ࡵࡲࡦࡡࡶࡧࡪࡴࡡࡳ࡫ࡲࠦಏ"), bstack1ll1lll_opy_ (u"ࠥ࡭ࡳࡹࡴࡦࡲࠥಐ")]) or
          (name == bstack1ll1lll_opy_ (u"ࠫࡦ࡬ࡴࡦࡴࡢࡷࡹ࡫ࡰࠨ಑") and self.driver_initialised == bstack1ll1lll_opy_ (u"ࠧࡨࡥࡧࡱࡵࡩࡤࡹࡴࡦࡲࠥಒ"))
        )
        if bstack1l1l1ll1l_opy_:
          self.driver_initialised = None
          if bstack1llll1lll_opy_ and hasattr(bstack1llll1lll_opy_, bstack1ll1lll_opy_ (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴ࡟ࡪࡦࠪಓ")):
            try:
              bstack1llll1lll_opy_.quit()
            except Exception as e:
              logger.debug(bstack1ll1lll_opy_ (u"ࠧࡆࡴࡵࡳࡷࠦࡱࡶ࡫ࡷࡸ࡮ࡴࡧࠡࡦࡵ࡭ࡻ࡫ࡲࠡ࡫ࡱࠤࡧ࡫ࡨࡢࡸࡨࠤ࡭ࡵ࡯࡬࠼ࠣࡿࢂ࠭ಔ").format(str(e)))
      except Exception as e:
        logger.debug(bstack1ll1lll_opy_ (u"ࠨࡇࡵࡶࡴࡸࠠࡪࡰࠣࡥ࡫ࡺࡥࡳࠢ࡫ࡳࡴࡱࠠࡤ࡮ࡨࡥࡳࡻࡰࠡࡨࡲࡶࠥࢁࡽ࠻ࠢࡾࢁࠬಕ").format(name, str(e)))
  except Exception as e:
    logger.debug(bstack1ll1lll_opy_ (u"ࠩࡆࡶ࡮ࡺࡩࡤࡣ࡯ࠤࡪࡸࡲࡰࡴࠣ࡭ࡳࠦࡢࡦࡪࡤࡺࡪࠦࡲࡶࡰࠣ࡬ࡴࡵ࡫ࠡࡽࢀ࠾ࠥࢁࡽࠨಖ").format(name, str(e)))
    try:
      bstack1l11lll111_opy_(self, name, context, *args)
    except Exception as e2:
      logger.debug(bstack1ll1lll_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥ࡬ࡡ࡭࡮ࡥࡥࡨࡱࠠࡰࡴ࡬࡫࡮ࡴࡡ࡭ࠢࡥࡩ࡭ࡧࡶࡦࠢ࡫ࡳࡴࡱࠠࡼࡿ࠽ࠤࢀࢃࠧಗ").format(name, str(e2)))
def bstack1111lll1l_opy_(config, startdir):
  return bstack1ll1lll_opy_ (u"ࠦࡩࡸࡩࡷࡧࡵ࠾ࠥࢁ࠰ࡾࠤಘ").format(bstack1ll1lll_opy_ (u"ࠧࡈࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࠦಙ"))
notset = Notset()
def bstack1l1l1lll11_opy_(self, name: str, default=notset, skip: bool = False):
  global bstack1l1ll1l1ll_opy_
  if str(name).lower() == bstack1ll1lll_opy_ (u"࠭ࡤࡳ࡫ࡹࡩࡷ࠭ಚ"):
    return bstack1ll1lll_opy_ (u"ࠢࡃࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࠨಛ")
  else:
    return bstack1l1ll1l1ll_opy_(self, name, default, skip)
def bstack1l1llll1l1_opy_(item, when):
  global bstack1lll11l1ll_opy_
  try:
    bstack1lll11l1ll_opy_(item, when)
  except Exception as e:
    pass
def bstack11ll11l1ll_opy_():
  return
def bstack1l1llll1ll_opy_(type, name, status, reason, bstack11l11ll1l_opy_, bstack1llll1l11_opy_):
  bstack1l1l1l1l_opy_ = {
    bstack1ll1lll_opy_ (u"ࠨࡣࡦࡸ࡮ࡵ࡮ࠨಜ"): type,
    bstack1ll1lll_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬಝ"): {}
  }
  if type == bstack1ll1lll_opy_ (u"ࠪࡥࡳࡴ࡯ࡵࡣࡷࡩࠬಞ"):
    bstack1l1l1l1l_opy_[bstack1ll1lll_opy_ (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧಟ")][bstack1ll1lll_opy_ (u"ࠬࡲࡥࡷࡧ࡯ࠫಠ")] = bstack11l11ll1l_opy_
    bstack1l1l1l1l_opy_[bstack1ll1lll_opy_ (u"࠭ࡡࡳࡩࡸࡱࡪࡴࡴࡴࠩಡ")][bstack1ll1lll_opy_ (u"ࠧࡥࡣࡷࡥࠬಢ")] = json.dumps(str(bstack1llll1l11_opy_))
  if type == bstack1ll1lll_opy_ (u"ࠨࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩಣ"):
    bstack1l1l1l1l_opy_[bstack1ll1lll_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬತ")][bstack1ll1lll_opy_ (u"ࠪࡲࡦࡳࡥࠨಥ")] = name
  if type == bstack1ll1lll_opy_ (u"ࠫࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡔࡶࡤࡸࡺࡹࠧದ"):
    bstack1l1l1l1l_opy_[bstack1ll1lll_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨಧ")][bstack1ll1lll_opy_ (u"࠭ࡳࡵࡣࡷࡹࡸ࠭ನ")] = status
    if status == bstack1ll1lll_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ಩"):
      bstack1l1l1l1l_opy_[bstack1ll1lll_opy_ (u"ࠨࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠫಪ")][bstack1ll1lll_opy_ (u"ࠩࡵࡩࡦࡹ࡯࡯ࠩಫ")] = json.dumps(str(reason))
  bstack1l1ll11l1l_opy_ = bstack1ll1lll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࡽࠨಬ").format(json.dumps(bstack1l1l1l1l_opy_))
  return bstack1l1ll11l1l_opy_
def bstack11ll11ll1l_opy_(driver_command, response):
    if driver_command == bstack1ll1lll_opy_ (u"ࠫࡸࡩࡲࡦࡧࡱࡷ࡭ࡵࡴࠨಭ"):
        bstack1l111l111l_opy_.bstack1l111llll1_opy_({
            bstack1ll1lll_opy_ (u"ࠬ࡯࡭ࡢࡩࡨࠫಮ"): response[bstack1ll1lll_opy_ (u"࠭ࡶࡢ࡮ࡸࡩࠬಯ")],
            bstack1ll1lll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧರ"): bstack1l111l111l_opy_.current_test_uuid()
        })
def bstack111l1ll1l_opy_(item, call, rep):
  global bstack1l1l1l1l1l_opy_
  global bstack1ll11ll1l1_opy_
  global bstack1l1l11ll1_opy_
  name = bstack1ll1lll_opy_ (u"ࠨࠩಱ")
  try:
    if rep.when == bstack1ll1lll_opy_ (u"ࠩࡦࡥࡱࡲࠧಲ"):
      bstack111l11l1_opy_ = threading.current_thread().bstackSessionId
      try:
        if not bstack1l1l11ll1_opy_:
          name = str(rep.nodeid)
          bstack1llll1ll1_opy_ = bstack1l1llll1ll_opy_(bstack1ll1lll_opy_ (u"ࠪࡷࡪࡺࡓࡦࡵࡶ࡭ࡴࡴࡎࡢ࡯ࡨࠫಳ"), name, bstack1ll1lll_opy_ (u"ࠫࠬ಴"), bstack1ll1lll_opy_ (u"ࠬ࠭ವ"), bstack1ll1lll_opy_ (u"࠭ࠧಶ"), bstack1ll1lll_opy_ (u"ࠧࠨಷ"))
          threading.current_thread().bstack1l111111ll_opy_ = name
          for driver in bstack1ll11ll1l1_opy_:
            if bstack111l11l1_opy_ == driver.session_id:
              driver.execute_script(bstack1llll1ll1_opy_)
      except Exception as e:
        logger.debug(bstack1ll1lll_opy_ (u"ࠨࡇࡵࡶࡴࡸࠠࡪࡰࠣࡷࡪࡺࡴࡪࡰࡪࠤࡸ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠢࡩࡳࡷࠦࡰࡺࡶࡨࡷࡹ࠳ࡢࡥࡦࠣࡷࡪࡹࡳࡪࡱࡱ࠾ࠥࢁࡽࠨಸ").format(str(e)))
      try:
        bstack111l1l11l_opy_(rep.outcome.lower())
        if rep.outcome.lower() != bstack1ll1lll_opy_ (u"ࠩࡶ࡯࡮ࡶࡰࡦࡦࠪಹ"):
          status = bstack1ll1lll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ಺") if rep.outcome.lower() == bstack1ll1lll_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ಻") else bstack1ll1lll_opy_ (u"ࠬࡶࡡࡴࡵࡨࡨ಼ࠬ")
          reason = bstack1ll1lll_opy_ (u"࠭ࠧಽ")
          if status == bstack1ll1lll_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧಾ"):
            reason = rep.longrepr.reprcrash.message
            if (not threading.current_thread().bstackTestErrorMessages):
              threading.current_thread().bstackTestErrorMessages = []
            threading.current_thread().bstackTestErrorMessages.append(reason)
          level = bstack1ll1lll_opy_ (u"ࠨ࡫ࡱࡪࡴ࠭ಿ") if status == bstack1ll1lll_opy_ (u"ࠩࡳࡥࡸࡹࡥࡥࠩೀ") else bstack1ll1lll_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࠩು")
          data = name + bstack1ll1lll_opy_ (u"ࠫࠥࡶࡡࡴࡵࡨࡨࠦ࠭ೂ") if status == bstack1ll1lll_opy_ (u"ࠬࡶࡡࡴࡵࡨࡨࠬೃ") else name + bstack1ll1lll_opy_ (u"࠭ࠠࡧࡣ࡬ࡰࡪࡪࠡࠡࠩೄ") + reason
          bstack11ll1lllll_opy_ = bstack1l1llll1ll_opy_(bstack1ll1lll_opy_ (u"ࠧࡢࡰࡱࡳࡹࡧࡴࡦࠩ೅"), bstack1ll1lll_opy_ (u"ࠨࠩೆ"), bstack1ll1lll_opy_ (u"ࠩࠪೇ"), bstack1ll1lll_opy_ (u"ࠪࠫೈ"), level, data)
          for driver in bstack1ll11ll1l1_opy_:
            if bstack111l11l1_opy_ == driver.session_id:
              driver.execute_script(bstack11ll1lllll_opy_)
      except Exception as e:
        logger.debug(bstack1ll1lll_opy_ (u"ࠫࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡳࡦࡶࡷ࡭ࡳ࡭ࠠࡴࡧࡶࡷ࡮ࡵ࡮ࠡࡥࡲࡲࡹ࡫ࡸࡵࠢࡩࡳࡷࠦࡰࡺࡶࡨࡷࡹ࠳ࡢࡥࡦࠣࡷࡪࡹࡳࡪࡱࡱ࠾ࠥࢁࡽࠨ೉").format(str(e)))
  except Exception as e:
    logger.debug(bstack1ll1lll_opy_ (u"ࠬࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡨࡧࡷࡸ࡮ࡴࡧࠡࡵࡷࡥࡹ࡫ࠠࡪࡰࠣࡴࡾࡺࡥࡴࡶ࠰ࡦࡩࡪࠠࡵࡧࡶࡸࠥࡹࡴࡢࡶࡸࡷ࠿ࠦࡻࡾࠩೊ").format(str(e)))
  bstack1l1l1l1l1l_opy_(item, call, rep)
def bstack111l11ll_opy_(driver, bstack1111l1l1_opy_, test=None):
  global bstack1lllll1ll1_opy_
  if test != None:
    bstack11l11ll111_opy_ = getattr(test, bstack1ll1lll_opy_ (u"࠭࡮ࡢ࡯ࡨࠫೋ"), None)
    bstack111ll111l_opy_ = getattr(test, bstack1ll1lll_opy_ (u"ࠧࡶࡷ࡬ࡨࠬೌ"), None)
    PercySDK.screenshot(driver, bstack1111l1l1_opy_, bstack11l11ll111_opy_=bstack11l11ll111_opy_, bstack111ll111l_opy_=bstack111ll111l_opy_, bstack11l11l11l1_opy_=bstack1lllll1ll1_opy_)
  else:
    PercySDK.screenshot(driver, bstack1111l1l1_opy_)
@measure(event_name=EVENTS.bstack11ll11111_opy_, stage=STAGE.bstack111lll1l11_opy_, bstack11lllll111_opy_=bstack1lll11111l_opy_)
def bstack1lll111111_opy_(driver):
  if bstack11l11l1l1_opy_.bstack1l111ll11_opy_() is True or bstack11l11l1l1_opy_.capturing() is True:
    return
  bstack11l11l1l1_opy_.bstack11l1l1lll1_opy_()
  while not bstack11l11l1l1_opy_.bstack1l111ll11_opy_():
    bstack1lllll11l1_opy_ = bstack11l11l1l1_opy_.bstack11l1l1l11_opy_()
    bstack111l11ll_opy_(driver, bstack1lllll11l1_opy_)
  bstack11l11l1l1_opy_.bstack1l1lll11l_opy_()
def bstack111ll1111_opy_(sequence, driver_command, response = None, bstack1ll11111l1_opy_ = None, args = None):
    try:
      if sequence != bstack1ll1lll_opy_ (u"ࠨࡤࡨࡪࡴࡸࡥࠨ್"):
        return
      if percy.bstack11ll1l11ll_opy_() == bstack1ll1lll_opy_ (u"ࠤࡩࡥࡱࡹࡥࠣ೎"):
        return
      bstack1lllll11l1_opy_ = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠪࡴࡪࡸࡣࡺࡕࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪ࠭೏"), None)
      for command in bstack1lll1lllll_opy_:
        if command == driver_command:
          with bstack11llllll11_opy_:
            bstack1l111l1l1l_opy_ = bstack1ll11ll1l1_opy_.copy()
          for driver in bstack1l111l1l1l_opy_:
            bstack1lll111111_opy_(driver)
      bstack1l111ll1_opy_ = percy.bstack1l11l1ll1l_opy_()
      if driver_command in bstack11l11l11ll_opy_[bstack1l111ll1_opy_]:
        bstack11l11l1l1_opy_.bstack11l11llll1_opy_(bstack1lllll11l1_opy_, driver_command)
    except Exception as e:
      pass
def bstack1l1lllll1l_opy_(framework_name):
  if bstack11l1l11l_opy_.get_property(bstack1ll1lll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡣࡲࡵࡤࡠࡥࡤࡰࡱ࡫ࡤࠨ೐")):
      return
  bstack11l1l11l_opy_.bstack111lll111_opy_(bstack1ll1lll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯ࡤࡳ࡯ࡥࡡࡦࡥࡱࡲࡥࡥࠩ೑"), True)
  global bstack11111l1ll_opy_
  global bstack1ll11llll1_opy_
  global bstack1l11l11lll_opy_
  bstack11111l1ll_opy_ = framework_name
  logger.info(bstack1lllll11ll_opy_.format(bstack11111l1ll_opy_.split(bstack1ll1lll_opy_ (u"࠭࠭ࠨ೒"))[0]))
  bstack11ll111ll1_opy_()
  try:
    from selenium import webdriver
    from selenium.webdriver.common.service import Service
    from selenium.webdriver.remote.webdriver import WebDriver
    if bstack1l11111l1l_opy_:
      Service.start = bstack11l11111_opy_
      Service.stop = bstack111l11ll1_opy_
      webdriver.Remote.get = bstack1l11ll1ll_opy_
      WebDriver.quit = bstack1l1ll111l1_opy_
      webdriver.Remote.__init__ = bstack1l1ll1ll1l_opy_
    if not bstack1l11111l1l_opy_:
        webdriver.Remote.__init__ = bstack1l1l1ll111_opy_
    WebDriver.getAccessibilityResults = getAccessibilityResults
    WebDriver.get_accessibility_results = getAccessibilityResults
    WebDriver.getAccessibilityResultsSummary = getAccessibilityResultsSummary
    WebDriver.get_accessibility_results_summary = getAccessibilityResultsSummary
    WebDriver.performScan = perform_scan
    WebDriver.perform_scan = perform_scan
    WebDriver.execute = bstack1ll1l11111_opy_
    bstack1ll11llll1_opy_ = True
  except Exception as e:
    pass
  try:
    if bstack1l11111l1l_opy_:
      from QWeb.keywords import browser
      browser.close_browser = bstack1l1lll1ll_opy_
  except Exception as e:
    pass
  bstack1l11ll1l11_opy_()
  if not bstack1ll11llll1_opy_:
    bstack11ll111lll_opy_(bstack1ll1lll_opy_ (u"ࠢࡑࡣࡦ࡯ࡦ࡭ࡥࡴࠢࡱࡳࡹࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠤ೓"), bstack11l111l1ll_opy_)
  if bstack1l1111111_opy_():
    try:
      from selenium.webdriver.remote.remote_connection import RemoteConnection
      if hasattr(RemoteConnection, bstack1ll1lll_opy_ (u"ࠨࡡࡪࡩࡹࡥࡰࡳࡱࡻࡽࡤࡻࡲ࡭ࠩ೔")) and callable(getattr(RemoteConnection, bstack1ll1lll_opy_ (u"ࠩࡢ࡫ࡪࡺ࡟ࡱࡴࡲࡼࡾࡥࡵࡳ࡮ࠪೕ"))):
        RemoteConnection._get_proxy_url = bstack11ll1lll1l_opy_
      else:
        from selenium.webdriver.remote.client_config import ClientConfig
        ClientConfig.get_proxy_url = bstack11ll1lll1l_opy_
    except Exception as e:
      logger.error(bstack1111ll1ll_opy_.format(str(e)))
  if bstack1l1lll111l_opy_():
    bstack1l1l111l11_opy_(CONFIG, logger)
  if (bstack1ll1lll_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩೖ") in str(framework_name).lower()):
    try:
      from robot import run_cli
      from robot.output import Output
      from robot.running.status import TestStatus
      from pabot.pabot import QueueItem
      from pabot import pabot
      try:
        if percy.bstack11ll1l11ll_opy_() == bstack1ll1lll_opy_ (u"ࠦࡹࡸࡵࡦࠤ೗"):
          bstack1111l1ll_opy_(bstack111ll1111_opy_)
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCreator
        WebDriverCreator._get_ff_profile = bstack1l1l1111ll_opy_
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCache
        WebDriverCache.close = bstack1lllll11l_opy_
      except Exception as e:
        logger.warn(bstack1l11l11l_opy_ + str(e))
      try:
        from AppiumLibrary.utils.applicationcache import ApplicationCache
        ApplicationCache.close = bstack11llll1ll_opy_
      except Exception as e:
        logger.debug(bstack1llll1l11l_opy_ + str(e))
    except Exception as e:
      bstack11ll111lll_opy_(e, bstack1l11l11l_opy_)
    Output.start_test = bstack1l11ll1l_opy_
    Output.end_test = bstack11lll11ll_opy_
    TestStatus.__init__ = bstack1llllll11_opy_
    QueueItem.__init__ = bstack11lll11l11_opy_
    pabot._create_items = bstack1ll1111l1_opy_
    try:
      from pabot import __version__ as bstack1ll111ll1_opy_
      if version.parse(bstack1ll111ll1_opy_) >= version.parse(bstack1ll1lll_opy_ (u"ࠬ࠻࠮࠱࠰࠳ࠫ೘")):
        pabot._run = bstack1ll11l111l_opy_
      elif version.parse(bstack1ll111ll1_opy_) >= version.parse(bstack1ll1lll_opy_ (u"࠭࠴࠯࠴࠱࠴ࠬ೙")):
        pabot._run = bstack1l11ll1111_opy_
      elif version.parse(bstack1ll111ll1_opy_) >= version.parse(bstack1ll1lll_opy_ (u"ࠧ࠳࠰࠴࠹࠳࠶ࠧ೚")):
        pabot._run = bstack1l11111l1_opy_
      elif version.parse(bstack1ll111ll1_opy_) >= version.parse(bstack1ll1lll_opy_ (u"ࠨ࠴࠱࠵࠸࠴࠰ࠨ೛")):
        pabot._run = bstack1l1ll11l11_opy_
      else:
        pabot._run = bstack1l11llll1_opy_
    except Exception as e:
      pabot._run = bstack1l11llll1_opy_
    pabot._create_command_for_execution = bstack1l1111l1ll_opy_
    pabot._report_results = bstack1l1l11l1l1_opy_
  if bstack1ll1lll_opy_ (u"ࠩࡥࡩ࡭ࡧࡶࡦࠩ೜") in str(framework_name).lower():
    try:
      from behave.runner import Runner
      from behave.model import Step
    except Exception as e:
      bstack11ll111lll_opy_(e, bstack11l1ll11l_opy_)
    Runner.run_hook = bstack1lllll1ll_opy_
    Step.run = bstack11l1ll111l_opy_
  if bstack1ll1lll_opy_ (u"ࠪࡴࡾࡺࡥࡴࡶࠪೝ") in str(framework_name).lower():
    if not bstack1l11111l1l_opy_:
      return
    try:
      from pytest_selenium import pytest_selenium
      from _pytest.config import Config
      pytest_selenium.pytest_report_header = bstack1111lll1l_opy_
      from pytest_selenium.drivers import browserstack
      browserstack.pytest_selenium_runtest_makereport = bstack11ll11l1ll_opy_
      Config.getoption = bstack1l1l1lll11_opy_
    except Exception as e:
      pass
    try:
      from pytest_bdd import reporting
      reporting.runtest_makereport = bstack111l1ll1l_opy_
    except Exception as e:
      pass
def bstack1ll1llll1_opy_():
  global CONFIG
  if bstack1ll1lll_opy_ (u"ࠫࡵࡧࡲࡢ࡮࡯ࡩࡱࡹࡐࡦࡴࡓࡰࡦࡺࡦࡰࡴࡰࠫೞ") in CONFIG and int(CONFIG[bstack1ll1lll_opy_ (u"ࠬࡶࡡࡳࡣ࡯ࡰࡪࡲࡳࡑࡧࡵࡔࡱࡧࡴࡧࡱࡵࡱࠬ೟")]) > 1:
    logger.warn(bstack1111l1l1l_opy_)
def bstack1l1llll11_opy_(arg, bstack1l11lll11_opy_, bstack11l1111l1l_opy_=None):
  global CONFIG
  global bstack111ll111_opy_
  global bstack1l1lll1lll_opy_
  global bstack1l11111l1l_opy_
  global bstack11l1l11l_opy_
  bstack1lll1111_opy_ = bstack1ll1lll_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭ೠ")
  if bstack1l11lll11_opy_ and isinstance(bstack1l11lll11_opy_, str):
    bstack1l11lll11_opy_ = eval(bstack1l11lll11_opy_)
  CONFIG = bstack1l11lll11_opy_[bstack1ll1lll_opy_ (u"ࠧࡄࡑࡑࡊࡎࡍࠧೡ")]
  bstack111ll111_opy_ = bstack1l11lll11_opy_[bstack1ll1lll_opy_ (u"ࠨࡊࡘࡆࡤ࡛ࡒࡍࠩೢ")]
  bstack1l1lll1lll_opy_ = bstack1l11lll11_opy_[bstack1ll1lll_opy_ (u"ࠩࡌࡗࡤࡇࡐࡑࡡࡄ࡙࡙ࡕࡍࡂࡖࡈࠫೣ")]
  bstack1l11111l1l_opy_ = bstack1l11lll11_opy_[bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡄ࡙࡙ࡕࡍࡂࡖࡌࡓࡓ࠭೤")]
  bstack11l1l11l_opy_.bstack111lll111_opy_(bstack1ll1lll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡣࡸ࡫ࡳࡴ࡫ࡲࡲࠬ೥"), bstack1l11111l1l_opy_)
  os.environ[bstack1ll1lll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡋࡘࡁࡎࡇ࡚ࡓࡗࡑࠧ೦")] = bstack1lll1111_opy_
  os.environ[bstack1ll1lll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡉࡏࡏࡈࡌࡋࠬ೧")] = json.dumps(CONFIG)
  os.environ[bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡈࡖࡄࡢ࡙ࡗࡒࠧ೨")] = bstack111ll111_opy_
  os.environ[bstack1ll1lll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡊࡕࡢࡅࡕࡖ࡟ࡂࡗࡗࡓࡒࡇࡔࡆࠩ೩")] = str(bstack1l1lll1lll_opy_)
  os.environ[bstack1ll1lll_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡒ࡜ࡘࡊ࡙ࡔࡠࡒࡏ࡙ࡌࡏࡎࠨ೪")] = str(True)
  if bstack11l1l111l1_opy_(arg, [bstack1ll1lll_opy_ (u"ࠪ࠱ࡳ࠭೫"), bstack1ll1lll_opy_ (u"ࠫ࠲࠳࡮ࡶ࡯ࡳࡶࡴࡩࡥࡴࡵࡨࡷࠬ೬")]) != -1:
    os.environ[bstack1ll1lll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡕ࡟ࡔࡆࡕࡗࡣࡕࡇࡒࡂࡎࡏࡉࡑ࠭೭")] = str(True)
  if len(sys.argv) <= 1:
    logger.critical(bstack1ll11l1ll_opy_)
    return
  bstack111lll1lll_opy_()
  global bstack1lll1ll1ll_opy_
  global bstack1lllll1ll1_opy_
  global bstack1ll1lll1l1_opy_
  global bstack1l1lllll1_opy_
  global bstack1l11ll111l_opy_
  global bstack1l11l11lll_opy_
  global bstack11llll1l11_opy_
  arg.append(bstack1ll1lll_opy_ (u"ࠨ࠭ࡘࠤ೮"))
  arg.append(bstack1ll1lll_opy_ (u"ࠢࡪࡩࡱࡳࡷ࡫࠺ࡎࡱࡧࡹࡱ࡫ࠠࡢ࡮ࡵࡩࡦࡪࡹࠡ࡫ࡰࡴࡴࡸࡴࡦࡦ࠽ࡴࡾࡺࡥࡴࡶ࠱ࡔࡾࡺࡥࡴࡶ࡚ࡥࡷࡴࡩ࡯ࡩࠥ೯"))
  arg.append(bstack1ll1lll_opy_ (u"ࠣ࠯࡚ࠦ೰"))
  arg.append(bstack1ll1lll_opy_ (u"ࠤ࡬࡫ࡳࡵࡲࡦ࠼ࡗ࡬ࡪࠦࡨࡰࡱ࡮࡭ࡲࡶ࡬ࠣೱ"))
  global bstack1111ll1l_opy_
  global bstack1lll1lll1_opy_
  global bstack11ll1l1l_opy_
  global bstack1ll1lllll1_opy_
  global bstack11ll111l1_opy_
  global bstack11l111111l_opy_
  global bstack11lll1111l_opy_
  global bstack1llllll1ll_opy_
  global bstack11ll1ll1l1_opy_
  global bstack1l1l11111_opy_
  global bstack1l1ll1l1ll_opy_
  global bstack1lll11l1ll_opy_
  global bstack1l1l1l1l1l_opy_
  try:
    from selenium import webdriver
    from selenium.webdriver.remote.webdriver import WebDriver
    bstack1111ll1l_opy_ = webdriver.Remote.__init__
    bstack1lll1lll1_opy_ = WebDriver.quit
    bstack1llllll1ll_opy_ = WebDriver.close
    bstack11ll1ll1l1_opy_ = WebDriver.get
    bstack11ll1l1l_opy_ = WebDriver.execute
  except Exception as e:
    pass
  if bstack1l1lllllll_opy_(CONFIG) and bstack111llllll1_opy_():
    if bstack1lll1l1ll1_opy_() < version.parse(bstack1llll11l1l_opy_):
      logger.error(bstack1l1lll111_opy_.format(bstack1lll1l1ll1_opy_()))
    else:
      try:
        from selenium.webdriver.remote.remote_connection import RemoteConnection
        if hasattr(RemoteConnection, bstack1ll1lll_opy_ (u"ࠪࡣ࡬࡫ࡴࡠࡲࡵࡳࡽࡿ࡟ࡶࡴ࡯ࠫೲ")) and callable(getattr(RemoteConnection, bstack1ll1lll_opy_ (u"ࠫࡤ࡭ࡥࡵࡡࡳࡶࡴࡾࡹࡠࡷࡵࡰࠬೳ"))):
          bstack1l1l11111_opy_ = RemoteConnection._get_proxy_url
        else:
          from selenium.webdriver.remote.client_config import ClientConfig
          bstack1l1l11111_opy_ = ClientConfig.get_proxy_url
      except Exception as e:
        logger.error(bstack1111ll1ll_opy_.format(str(e)))
  try:
    from _pytest.config import Config
    bstack1l1ll1l1ll_opy_ = Config.getoption
    from _pytest import runner
    bstack1lll11l1ll_opy_ = runner._update_current_test_var
  except Exception as e:
    logger.warn(e, bstack1llll111l_opy_)
  try:
    from pytest_bdd import reporting
    bstack1l1l1l1l1l_opy_ = reporting.runtest_makereport
  except Exception as e:
    logger.debug(bstack1ll1lll_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥ࡯࡮ࡴࡶࡤࡰࡱࠦࡰࡺࡶࡨࡷࡹ࠳ࡢࡥࡦࠣࡸࡴࠦࡲࡶࡰࠣࡴࡾࡺࡥࡴࡶ࠰ࡦࡩࡪࠠࡵࡧࡶࡸࡸ࠭೴"))
  bstack1ll1lll1l1_opy_ = CONFIG.get(bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪ೵"), {}).get(bstack1ll1lll_opy_ (u"ࠧ࡭ࡱࡦࡥࡱࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩ೶"))
  bstack11llll1l11_opy_ = True
  if cli.is_enabled(CONFIG):
    if cli.bstack1lll1l111l_opy_():
      bstack1ll1l1ll11_opy_.invoke(bstack1l11l1lll1_opy_.CONNECT, bstack1ll11l1ll1_opy_())
    platform_index = int(os.environ.get(bstack1ll1lll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡑࡎࡄࡘࡋࡕࡒࡎࡡࡌࡒࡉࡋࡘࠨ೷"), bstack1ll1lll_opy_ (u"ࠩ࠳ࠫ೸")))
  else:
    bstack1l1lllll1l_opy_(bstack1ll11111ll_opy_)
  os.environ[bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡘࡗࡊࡘࡎࡂࡏࡈࠫ೹")] = CONFIG[bstack1ll1lll_opy_ (u"ࠫࡺࡹࡥࡳࡐࡤࡱࡪ࠭೺")]
  os.environ[bstack1ll1lll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡆࡉࡃࡆࡕࡖࡣࡐࡋ࡙ࠨ೻")] = CONFIG[bstack1ll1lll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸࡑࡥࡺࠩ೼")]
  os.environ[bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡁࡖࡖࡒࡑࡆ࡚ࡉࡐࡐࠪ೽")] = bstack1l11111l1l_opy_.__str__()
  from _pytest.config import main as bstack1l111ll111_opy_
  bstack1ll1lll11l_opy_ = []
  try:
    exit_code = bstack1l111ll111_opy_(arg)
    if cli.is_enabled(CONFIG):
      cli.bstack11ll111l11_opy_()
    if bstack1ll1lll_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫ࡠࡧࡵࡶࡴࡸ࡟࡭࡫ࡶࡸࠬ೾") in multiprocessing.current_process().__dict__.keys():
      for bstack1l11lllll_opy_ in multiprocessing.current_process().bstack_error_list:
        bstack1ll1lll11l_opy_.append(bstack1l11lllll_opy_)
    try:
      bstack1l11ll11l_opy_ = (bstack1ll1lll11l_opy_, int(exit_code))
      bstack11l1111l1l_opy_.append(bstack1l11ll11l_opy_)
    except:
      bstack11l1111l1l_opy_.append((bstack1ll1lll11l_opy_, exit_code))
  except Exception as e:
    logger.error(traceback.format_exc())
    bstack1ll1lll11l_opy_.append({bstack1ll1lll_opy_ (u"ࠩࡱࡥࡲ࡫ࠧ೿"): bstack1ll1lll_opy_ (u"ࠪࡔࡷࡵࡣࡦࡵࡶࠤࠬഀ") + os.environ.get(bstack1ll1lll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡔࡑࡇࡔࡇࡑࡕࡑࡤࡏࡎࡅࡇ࡛ࠫഁ")), bstack1ll1lll_opy_ (u"ࠬ࡫ࡲࡳࡱࡵࠫം"): traceback.format_exc(), bstack1ll1lll_opy_ (u"࠭ࡩ࡯ࡦࡨࡼࠬഃ"): int(os.environ.get(bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡐࡍࡃࡗࡊࡔࡘࡍࡠࡋࡑࡈࡊ࡞ࠧഄ")))})
    bstack11l1111l1l_opy_.append((bstack1ll1lll11l_opy_, 1))
def mod_behave_main(args, retries):
  try:
    from behave.configuration import Configuration
    from behave.__main__ import run_behave
    from browserstack_sdk.bstack_behave_runner import BehaveRunner
    config = Configuration(args)
    config.update_userdata({bstack1ll1lll_opy_ (u"ࠣࡴࡨࡸࡷ࡯ࡥࡴࠤഅ"): str(retries)})
    return run_behave(config, runner_class=BehaveRunner)
  except Exception as e:
    bstack11l1111ll_opy_ = e.__class__.__name__
    print(bstack1ll1lll_opy_ (u"ࠤࠨࡷ࠿ࠦࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡸࡵ࡯ࡰ࡬ࡲ࡬ࠦࡢࡦࡪࡤࡺࡪࠦࡴࡦࡵࡷࠤࠪࡹࠢആ") % (bstack11l1111ll_opy_, e))
    return 1
def bstack1l1l11111l_opy_(arg):
  global bstack11ll1ll1_opy_
  bstack1l1lllll1l_opy_(bstack1l1l11l11l_opy_)
  os.environ[bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡌࡗࡤࡇࡐࡑࡡࡄ࡙࡙ࡕࡍࡂࡖࡈࠫഇ")] = str(bstack1l1lll1lll_opy_)
  retries = bstack11lll1lll1_opy_.bstack11l1l1111l_opy_(CONFIG)
  status_code = 0
  if bstack11lll1lll1_opy_.bstack1111ll1l1_opy_(CONFIG):
    status_code = mod_behave_main(arg, retries)
  else:
    from behave.__main__ import main as bstack1lllll11_opy_
    status_code = bstack1lllll11_opy_(arg)
  if status_code != 0:
    bstack11ll1ll1_opy_ = status_code
def bstack111ll1l1l_opy_():
  logger.info(bstack11lll1ll11_opy_)
  import argparse
  parser = argparse.ArgumentParser()
  parser.add_argument(bstack1ll1lll_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࠪഈ"), help=bstack1ll1lll_opy_ (u"ࠬࡍࡥ࡯ࡧࡵࡥࡹ࡫ࠠࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࠦࡣࡰࡰࡩ࡭࡬࠭ഉ"))
  parser.add_argument(bstack1ll1lll_opy_ (u"࠭࠭ࡶࠩഊ"), bstack1ll1lll_opy_ (u"ࠧ࠮࠯ࡸࡷࡪࡸ࡮ࡢ࡯ࡨࠫഋ"), help=bstack1ll1lll_opy_ (u"ࠨ࡛ࡲࡹࡷࠦࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠥࡻࡳࡦࡴࡱࡥࡲ࡫ࠧഌ"))
  parser.add_argument(bstack1ll1lll_opy_ (u"ࠩ࠰࡯ࠬ഍"), bstack1ll1lll_opy_ (u"ࠪ࠱࠲ࡱࡥࡺࠩഎ"), help=bstack1ll1lll_opy_ (u"ࠫ࡞ࡵࡵࡳࠢࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠡࡣࡦࡧࡪࡹࡳࠡ࡭ࡨࡽࠬഏ"))
  parser.add_argument(bstack1ll1lll_opy_ (u"ࠬ࠳ࡦࠨഐ"), bstack1ll1lll_opy_ (u"࠭࠭࠮ࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࠫ഑"), help=bstack1ll1lll_opy_ (u"࡚ࠧࡱࡸࡶࠥࡺࡥࡴࡶࠣࡪࡷࡧ࡭ࡦࡹࡲࡶࡰ࠭ഒ"))
  bstack1ll11l1l1_opy_ = parser.parse_args()
  try:
    bstack1l11ll1ll1_opy_ = bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡨࡧࡱࡩࡷ࡯ࡣ࠯ࡻࡰࡰ࠳ࡹࡡ࡮ࡲ࡯ࡩࠬഓ")
    if bstack1ll11l1l1_opy_.framework and bstack1ll11l1l1_opy_.framework not in (bstack1ll1lll_opy_ (u"ࠩࡳࡽࡹ࡮࡯࡯ࠩഔ"), bstack1ll1lll_opy_ (u"ࠪࡴࡾࡺࡨࡰࡰ࠶ࠫക")):
      bstack1l11ll1ll1_opy_ = bstack1ll1lll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡪࡷࡧ࡭ࡦࡹࡲࡶࡰ࠴ࡹ࡮࡮࠱ࡷࡦࡳࡰ࡭ࡧࠪഖ")
    bstack111lll1l1l_opy_ = os.path.join(os.path.dirname(os.path.realpath(__file__)), bstack1l11ll1ll1_opy_)
    bstack1l1l1l1ll1_opy_ = open(bstack111lll1l1l_opy_, bstack1ll1lll_opy_ (u"ࠬࡸࠧഗ"))
    bstack11ll11l1l_opy_ = bstack1l1l1l1ll1_opy_.read()
    bstack1l1l1l1ll1_opy_.close()
    if bstack1ll11l1l1_opy_.username:
      bstack11ll11l1l_opy_ = bstack11ll11l1l_opy_.replace(bstack1ll1lll_opy_ (u"࡙࠭ࡐࡗࡕࡣ࡚࡙ࡅࡓࡐࡄࡑࡊ࠭ഘ"), bstack1ll11l1l1_opy_.username)
    if bstack1ll11l1l1_opy_.key:
      bstack11ll11l1l_opy_ = bstack11ll11l1l_opy_.replace(bstack1ll1lll_opy_ (u"࡚ࠧࡑࡘࡖࡤࡇࡃࡄࡇࡖࡗࡤࡑࡅ࡚ࠩങ"), bstack1ll11l1l1_opy_.key)
    if bstack1ll11l1l1_opy_.framework:
      bstack11ll11l1l_opy_ = bstack11ll11l1l_opy_.replace(bstack1ll1lll_opy_ (u"ࠨ࡛ࡒ࡙ࡗࡥࡆࡓࡃࡐࡉ࡜ࡕࡒࡌࠩച"), bstack1ll11l1l1_opy_.framework)
    file_name = bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡻࡰࡰࠬഛ")
    file_path = os.path.abspath(file_name)
    bstack1lll111l11_opy_ = open(file_path, bstack1ll1lll_opy_ (u"ࠪࡻࠬജ"))
    bstack1lll111l11_opy_.write(bstack11ll11l1l_opy_)
    bstack1lll111l11_opy_.close()
    logger.info(bstack11lll11l1_opy_)
    try:
      os.environ[bstack1ll1lll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡊࡗࡇࡍࡆ࡙ࡒࡖࡐ࠭ഝ")] = bstack1ll11l1l1_opy_.framework if bstack1ll11l1l1_opy_.framework != None else bstack1ll1lll_opy_ (u"ࠧࠨഞ")
      config = yaml.safe_load(bstack11ll11l1l_opy_)
      config[bstack1ll1lll_opy_ (u"࠭ࡳࡰࡷࡵࡧࡪ࠭ട")] = bstack1ll1lll_opy_ (u"ࠧࡱࡻࡷ࡬ࡴࡴ࠭ࡴࡧࡷࡹࡵ࠭ഠ")
      bstack1ll1l1l1l1_opy_(bstack1ll11l11l1_opy_, config)
    except Exception as e:
      logger.debug(bstack1ll111l111_opy_.format(str(e)))
  except Exception as e:
    logger.error(bstack1ll11l11_opy_.format(str(e)))
def bstack1ll1l1l1l1_opy_(bstack111lll1l_opy_, config, bstack11lll1lll_opy_={}):
  global bstack1l11111l1l_opy_
  global bstack1l11111ll_opy_
  global bstack11l1l11l_opy_
  if not config:
    return
  bstack1ll1lll1ll_opy_ = bstack1l1l1l11l_opy_ if not bstack1l11111l1l_opy_ else (
    bstack11lll1llll_opy_ if bstack1ll1lll_opy_ (u"ࠨࡣࡳࡴࠬഡ") in config else (
        bstack1ll11lll11_opy_ if config.get(bstack1ll1lll_opy_ (u"ࠩࡷࡹࡷࡨ࡯ࡔࡥࡤࡰࡪ࠭ഢ")) else bstack11lll1ll1_opy_
    )
)
  bstack1ll1ll111_opy_ = False
  bstack111ll1l11_opy_ = False
  if bstack1l11111l1l_opy_ is True:
      if bstack1ll1lll_opy_ (u"ࠪࡥࡵࡶࠧണ") in config:
          bstack1ll1ll111_opy_ = True
      else:
          bstack111ll1l11_opy_ = True
  bstack11l1l1l1ll_opy_ = bstack1llll1111_opy_.bstack11l11l1l_opy_(config, bstack1l11111ll_opy_)
  bstack11lllll1ll_opy_ = bstack1lllll1lll_opy_()
  data = {
    bstack1ll1lll_opy_ (u"ࠫࡺࡹࡥࡳࡐࡤࡱࡪ࠭ത"): config[bstack1ll1lll_opy_ (u"ࠬࡻࡳࡦࡴࡑࡥࡲ࡫ࠧഥ")],
    bstack1ll1lll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸࡑࡥࡺࠩദ"): config[bstack1ll1lll_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡋࡦࡻࠪധ")],
    bstack1ll1lll_opy_ (u"ࠨࡧࡹࡩࡳࡺ࡟ࡵࡻࡳࡩࠬന"): bstack111lll1l_opy_,
    bstack1ll1lll_opy_ (u"ࠩࡧࡩࡹ࡫ࡣࡵࡧࡧࡊࡷࡧ࡭ࡦࡹࡲࡶࡰ࠭ഩ"): os.environ.get(bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡉࡖࡆࡓࡅࡘࡑࡕࡏࠬപ"), bstack1l11111ll_opy_),
    bstack1ll1lll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡢ࡬ࡦࡹࡨࡦࡦࡢ࡭ࡩ࠭ഫ"): bstack1l1l1l11_opy_,
    bstack1ll1lll_opy_ (u"ࠬࡵࡰࡵ࡫ࡰࡥࡱࡥࡨࡶࡤࡢࡹࡷࡲࠧബ"): bstack1l11lllll1_opy_(),
    bstack1ll1lll_opy_ (u"࠭ࡥࡷࡧࡱࡸࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠩഭ"): {
      bstack1ll1lll_opy_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࡡࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬമ"): str(config[bstack1ll1lll_opy_ (u"ࠨࡵࡲࡹࡷࡩࡥࠨയ")]) if bstack1ll1lll_opy_ (u"ࠩࡶࡳࡺࡸࡣࡦࠩര") in config else bstack1ll1lll_opy_ (u"ࠥࡹࡳࡱ࡮ࡰࡹࡱࠦറ"),
      bstack1ll1lll_opy_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ല"): sys.version,
      bstack1ll1lll_opy_ (u"ࠬࡸࡥࡧࡧࡵࡶࡪࡸࠧള"): bstack1l1l1lll_opy_(os.environ.get(bstack1ll1lll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡌࡒࡂࡏࡈ࡛ࡔࡘࡋࠨഴ"), bstack1l11111ll_opy_)),
      bstack1ll1lll_opy_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩവ"): bstack1ll1lll_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨശ"),
      bstack1ll1lll_opy_ (u"ࠩࡳࡶࡴࡪࡵࡤࡶࠪഷ"): bstack1ll1lll1ll_opy_,
      bstack1ll1lll_opy_ (u"ࠪࡴࡷࡵࡤࡶࡥࡷࡣࡲࡧࡰࠨസ"): bstack11l1l1l1ll_opy_,
      bstack1ll1lll_opy_ (u"ࠫࡹ࡫ࡳࡵࡪࡸࡦࡤࡻࡵࡪࡦࠪഹ"): os.environ[bstack1ll1lll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤ࡛ࡕࡊࡆࠪഺ")],
      bstack1ll1lll_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬഻ࠩ"): os.environ.get(bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡆࡓࡃࡐࡉ࡜ࡕࡒࡌ഼ࠩ"), bstack1l11111ll_opy_),
      bstack1ll1lll_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮࡚ࡪࡸࡳࡪࡱࡱࠫഽ"): bstack111llllll_opy_(os.environ.get(bstack1ll1lll_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡈࡕࡅࡒࡋࡗࡐࡔࡎࠫാ"), bstack1l11111ll_opy_)),
      bstack1ll1lll_opy_ (u"ࠪࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࡆࡳࡣࡰࡩࡼࡵࡲ࡬ࠩി"): bstack11lllll1ll_opy_.get(bstack1ll1lll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩീ")),
      bstack1ll1lll_opy_ (u"ࠬࡧࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࡈࡵࡥࡲ࡫ࡷࡰࡴ࡮࡚ࡪࡸࡳࡪࡱࡱࠫു"): bstack11lllll1ll_opy_.get(bstack1ll1lll_opy_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧൂ")),
      bstack1ll1lll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠪൃ"): config[bstack1ll1lll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫൄ")] if config[bstack1ll1lll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬ൅")] else bstack1ll1lll_opy_ (u"ࠥࡹࡳࡱ࡮ࡰࡹࡱࠦെ"),
      bstack1ll1lll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭േ"): str(config[bstack1ll1lll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧൈ")]) if bstack1ll1lll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨ൉") in config else bstack1ll1lll_opy_ (u"ࠢࡶࡰ࡮ࡲࡴࡽ࡮ࠣൊ"),
      bstack1ll1lll_opy_ (u"ࠨࡱࡶࠫോ"): sys.platform,
      bstack1ll1lll_opy_ (u"ࠩ࡫ࡳࡸࡺ࡮ࡢ࡯ࡨࠫൌ"): socket.gethostname(),
      bstack1ll1lll_opy_ (u"ࠪࡷࡩࡱࡒࡶࡰࡌࡨ്ࠬ"): bstack11l1l11l_opy_.get_property(bstack1ll1lll_opy_ (u"ࠫࡸࡪ࡫ࡓࡷࡱࡍࡩ࠭ൎ"))
    }
  }
  if not bstack11l1l11l_opy_.get_property(bstack1ll1lll_opy_ (u"ࠬࡹࡤ࡬ࡍ࡬ࡰࡱ࡙ࡩࡨࡰࡤࡰࠬ൏")) is None:
    data[bstack1ll1lll_opy_ (u"࠭ࡥࡷࡧࡱࡸࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠩ൐")][bstack1ll1lll_opy_ (u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ൑")] = {
      bstack1ll1lll_opy_ (u"ࠨࡴࡨࡥࡸࡵ࡮ࠨ൒"): bstack1ll1lll_opy_ (u"ࠩࡸࡷࡪࡸ࡟࡬࡫࡯ࡰࡪࡪࠧ൓"),
      bstack1ll1lll_opy_ (u"ࠪࡷ࡮࡭࡮ࡢ࡮ࠪൔ"): bstack11l1l11l_opy_.get_property(bstack1ll1lll_opy_ (u"ࠫࡸࡪ࡫ࡌ࡫࡯ࡰࡘ࡯ࡧ࡯ࡣ࡯ࠫൕ")),
      bstack1ll1lll_opy_ (u"ࠬࡹࡩࡨࡰࡤࡰࡓࡻ࡭ࡣࡧࡵࠫൖ"): bstack11l1l11l_opy_.get_property(bstack1ll1lll_opy_ (u"࠭ࡳࡥ࡭ࡎ࡭ࡱࡲࡎࡰࠩൗ"))
    }
  if bstack111lll1l_opy_ == bstack1ll111111l_opy_:
    data[bstack1ll1lll_opy_ (u"ࠧࡦࡸࡨࡲࡹࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࠪ൘")][bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡃࡰࡰࡩ࡭࡬࠭൙")] = bstack1ll11l1l1l_opy_(config)
    data[bstack1ll1lll_opy_ (u"ࠩࡨࡺࡪࡴࡴࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࠬ൚")][bstack1ll1lll_opy_ (u"ࠪ࡭ࡸࡖࡥࡳࡥࡼࡅࡺࡺ࡯ࡆࡰࡤࡦࡱ࡫ࡤࠨ൛")] = percy.bstack1l1l11ll1l_opy_
    data[bstack1ll1lll_opy_ (u"ࠫࡪࡼࡥ࡯ࡶࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠧ൜")][bstack1ll1lll_opy_ (u"ࠬࡶࡥࡳࡥࡼࡆࡺ࡯࡬ࡥࡋࡧࠫ൝")] = percy.percy_build_id
  if not bstack11lll1lll1_opy_.bstack1ll11ll1ll_opy_(CONFIG):
    data[bstack1ll1lll_opy_ (u"࠭ࡥࡷࡧࡱࡸࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠩ൞")][bstack1ll1lll_opy_ (u"ࠧࡵࡧࡶࡸࡔࡸࡣࡩࡧࡶࡸࡷࡧࡴࡪࡱࡱࠫൟ")] = bstack11lll1lll1_opy_.bstack1ll11ll1ll_opy_(CONFIG)
  bstack11ll1ll11l_opy_ = bstack11ll11ll11_opy_.bstack1l1l111l_opy_(CONFIG, logger)
  bstack1llll111ll_opy_ = bstack11lll1lll1_opy_.bstack1l1l111l_opy_(config=CONFIG)
  if bstack11ll1ll11l_opy_ is not None and bstack1llll111ll_opy_ is not None and bstack1llll111ll_opy_.bstack1ll11lll1l_opy_():
    data[bstack1ll1lll_opy_ (u"ࠨࡧࡹࡩࡳࡺ࡟ࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࠫൠ")][bstack1llll111ll_opy_.bstack1ll1l1l1ll_opy_()] = bstack11ll1ll11l_opy_.bstack1lll1l1ll_opy_()
  update(data[bstack1ll1lll_opy_ (u"ࠩࡨࡺࡪࡴࡴࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࠬൡ")], bstack11lll1lll_opy_)
  try:
    response = bstack111lll1ll1_opy_(bstack1ll1lll_opy_ (u"ࠪࡔࡔ࡙ࡔࠨൢ"), bstack11l1l111ll_opy_(bstack1ll1111l1l_opy_), data, {
      bstack1ll1lll_opy_ (u"ࠫࡦࡻࡴࡩࠩൣ"): (config[bstack1ll1lll_opy_ (u"ࠬࡻࡳࡦࡴࡑࡥࡲ࡫ࠧ൤")], config[bstack1ll1lll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸࡑࡥࡺࠩ൥")])
    })
    if response:
      logger.debug(bstack1l11l111ll_opy_.format(bstack111lll1l_opy_, str(response.json())))
  except Exception as e:
    logger.debug(bstack1ll1l11l11_opy_.format(str(e)))
def bstack1l1l1lll_opy_(framework):
  return bstack1ll1lll_opy_ (u"ࠢࡼࡿ࠰ࡴࡾࡺࡨࡰࡰࡤ࡫ࡪࡴࡴ࠰ࡽࢀࠦ൦").format(str(framework), __version__) if framework else bstack1ll1lll_opy_ (u"ࠣࡲࡼࡸ࡭ࡵ࡮ࡢࡩࡨࡲࡹ࠵ࡻࡾࠤ൧").format(
    __version__)
def bstack111lll1lll_opy_():
  global CONFIG
  global bstack11l111l11l_opy_
  if bool(CONFIG):
    return
  try:
    bstack1lll1llll1_opy_()
    logger.debug(bstack1ll111l1ll_opy_.format(str(CONFIG)))
    bstack11l111l11l_opy_ = bstack1ll1ll1111_opy_.configure_logger(CONFIG, bstack11l111l11l_opy_)
    bstack11ll111ll1_opy_()
  except Exception as e:
    logger.error(bstack1ll1lll_opy_ (u"ࠤࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡹࡥࡵࡷࡳ࠰ࠥ࡫ࡲࡳࡱࡵ࠾ࠥࠨ൨") + str(e))
    sys.exit(1)
  sys.excepthook = bstack1l111lllll_opy_
  atexit.register(bstack1l1111ll11_opy_)
  signal.signal(signal.SIGINT, bstack1l1l11l1ll_opy_)
  signal.signal(signal.SIGTERM, bstack1l1l11l1ll_opy_)
def bstack1l111lllll_opy_(exctype, value, traceback):
  global bstack1ll11ll1l1_opy_
  try:
    for driver in bstack1ll11ll1l1_opy_:
      bstack1l1lll1ll1_opy_(driver, bstack1ll1lll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ൩"), bstack1ll1lll_opy_ (u"ࠦࡘ࡫ࡳࡴ࡫ࡲࡲࠥ࡬ࡡࡪ࡮ࡨࡨࠥࡽࡩࡵࡪ࠽ࠤࡡࡴࠢ൪") + str(value))
  except Exception:
    pass
  logger.info(bstack1ll11111l_opy_)
  bstack1l1ll1llll_opy_(value, True)
  sys.__excepthook__(exctype, value, traceback)
  sys.exit(1)
def bstack1l1ll1llll_opy_(message=bstack1ll1lll_opy_ (u"ࠬ࠭൫"), bstack11l1llll11_opy_ = False):
  global CONFIG
  bstack1l111l1l1_opy_ = bstack1ll1lll_opy_ (u"࠭ࡧ࡭ࡱࡥࡥࡱࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠨ൬") if bstack11l1llll11_opy_ else bstack1ll1lll_opy_ (u"ࠧࡦࡴࡵࡳࡷ࠭൭")
  try:
    if message:
      bstack11lll1lll_opy_ = {
        bstack1l111l1l1_opy_ : str(message)
      }
      bstack1ll1l1l1l1_opy_(bstack1ll111111l_opy_, CONFIG, bstack11lll1lll_opy_)
    else:
      bstack1ll1l1l1l1_opy_(bstack1ll111111l_opy_, CONFIG)
  except Exception as e:
    logger.debug(bstack1l1l1l11ll_opy_.format(str(e)))
def bstack1ll1ll1l1l_opy_(bstack111l11lll_opy_, size):
  bstack1l111lll_opy_ = []
  while len(bstack111l11lll_opy_) > size:
    bstack11l1lll11l_opy_ = bstack111l11lll_opy_[:size]
    bstack1l111lll_opy_.append(bstack11l1lll11l_opy_)
    bstack111l11lll_opy_ = bstack111l11lll_opy_[size:]
  bstack1l111lll_opy_.append(bstack111l11lll_opy_)
  return bstack1l111lll_opy_
def bstack1lllll111l_opy_(args):
  if bstack1ll1lll_opy_ (u"ࠨ࠯ࡰࠫ൮") in args and bstack1ll1lll_opy_ (u"ࠩࡳࡨࡧ࠭൯") in args:
    return True
  return False
@measure(event_name=EVENTS.bstack11ll1l1l11_opy_, stage=STAGE.bstack11ll11l111_opy_)
def run_on_browserstack(bstack1ll1111111_opy_=None, bstack11l1111l1l_opy_=None, bstack1l11ll1lll_opy_=False):
  global CONFIG
  global bstack111ll111_opy_
  global bstack1l1lll1lll_opy_
  global bstack1l11111ll_opy_
  global bstack11l1l11l_opy_
  bstack1lll1111_opy_ = bstack1ll1lll_opy_ (u"ࠪࠫ൰")
  bstack11111l11l_opy_(bstack1lll1lll_opy_, logger)
  if bstack1ll1111111_opy_ and isinstance(bstack1ll1111111_opy_, str):
    bstack1ll1111111_opy_ = eval(bstack1ll1111111_opy_)
  if bstack1ll1111111_opy_:
    CONFIG = bstack1ll1111111_opy_[bstack1ll1lll_opy_ (u"ࠫࡈࡕࡎࡇࡋࡊࠫ൱")]
    bstack111ll111_opy_ = bstack1ll1111111_opy_[bstack1ll1lll_opy_ (u"ࠬࡎࡕࡃࡡࡘࡖࡑ࠭൲")]
    bstack1l1lll1lll_opy_ = bstack1ll1111111_opy_[bstack1ll1lll_opy_ (u"࠭ࡉࡔࡡࡄࡔࡕࡥࡁࡖࡖࡒࡑࡆ࡚ࡅࠨ൳")]
    bstack11l1l11l_opy_.bstack111lll111_opy_(bstack1ll1lll_opy_ (u"ࠧࡊࡕࡢࡅࡕࡖ࡟ࡂࡗࡗࡓࡒࡇࡔࡆࠩ൴"), bstack1l1lll1lll_opy_)
    bstack1lll1111_opy_ = bstack1ll1lll_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨ൵")
  bstack11l1l11l_opy_.bstack111lll111_opy_(bstack1ll1lll_opy_ (u"ࠩࡶࡨࡰࡘࡵ࡯ࡋࡧࠫ൶"), uuid4().__str__())
  logger.info(bstack1ll1lll_opy_ (u"ࠪࡗࡉࡑࠠࡳࡷࡱࠤࡸࡺࡡࡳࡶࡨࡨࠥࡽࡩࡵࡪࠣ࡭ࡩࡀࠠࠨ൷") + bstack11l1l11l_opy_.get_property(bstack1ll1lll_opy_ (u"ࠫࡸࡪ࡫ࡓࡷࡱࡍࡩ࠭൸")));
  logger.debug(bstack1ll1lll_opy_ (u"ࠬࡹࡤ࡬ࡔࡸࡲࡎࡪ࠽ࠨ൹") + bstack11l1l11l_opy_.get_property(bstack1ll1lll_opy_ (u"࠭ࡳࡥ࡭ࡕࡹࡳࡏࡤࠨൺ")))
  if not bstack1l11ll1lll_opy_:
    if len(sys.argv) <= 1:
      logger.critical(bstack1ll11l1ll_opy_)
      return
    if sys.argv[1] == bstack1ll1lll_opy_ (u"ࠧ࠮࠯ࡹࡩࡷࡹࡩࡰࡰࠪൻ") or sys.argv[1] == bstack1ll1lll_opy_ (u"ࠨ࠯ࡹࠫർ"):
      logger.info(bstack1ll1lll_opy_ (u"ࠩࡅࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠡࡒࡼࡸ࡭ࡵ࡮ࠡࡕࡇࡏࠥࡼࡻࡾࠩൽ").format(__version__))
      return
    if sys.argv[1] == bstack1ll1lll_opy_ (u"ࠪࡷࡪࡺࡵࡱࠩൾ"):
      bstack111ll1l1l_opy_()
      return
  args = sys.argv
  bstack111lll1lll_opy_()
  global bstack1lll1ll1ll_opy_
  global bstack1l11l11l1l_opy_
  global bstack11llll1l11_opy_
  global bstack1l1l1111_opy_
  global bstack1lllll1ll1_opy_
  global bstack1ll1lll1l1_opy_
  global bstack1l1lllll1_opy_
  global bstack11111111l_opy_
  global bstack1l11ll111l_opy_
  global bstack1l11l11lll_opy_
  global bstack1ll1l11ll_opy_
  bstack1l11l11l1l_opy_ = len(CONFIG.get(bstack1ll1lll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧൿ"), []))
  if not bstack1lll1111_opy_:
    if args[1] == bstack1ll1lll_opy_ (u"ࠬࡶࡹࡵࡪࡲࡲࠬ඀") or args[1] == bstack1ll1lll_opy_ (u"࠭ࡰࡺࡶ࡫ࡳࡳ࠹ࠧඁ"):
      bstack1lll1111_opy_ = bstack1ll1lll_opy_ (u"ࠧࡱࡻࡷ࡬ࡴࡴࠧං")
      args = args[2:]
    elif args[1] == bstack1ll1lll_opy_ (u"ࠨࡴࡲࡦࡴࡺࠧඃ"):
      bstack1lll1111_opy_ = bstack1ll1lll_opy_ (u"ࠩࡵࡳࡧࡵࡴࠨ඄")
      args = args[2:]
    elif args[1] == bstack1ll1lll_opy_ (u"ࠪࡴࡦࡨ࡯ࡵࠩඅ"):
      bstack1lll1111_opy_ = bstack1ll1lll_opy_ (u"ࠫࡵࡧࡢࡰࡶࠪආ")
      args = args[2:]
    elif args[1] == bstack1ll1lll_opy_ (u"ࠬࡸ࡯ࡣࡱࡷ࠱࡮ࡴࡴࡦࡴࡱࡥࡱ࠭ඇ"):
      bstack1lll1111_opy_ = bstack1ll1lll_opy_ (u"࠭ࡲࡰࡤࡲࡸ࠲࡯࡮ࡵࡧࡵࡲࡦࡲࠧඈ")
      args = args[2:]
    elif args[1] == bstack1ll1lll_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺࠧඉ"):
      bstack1lll1111_opy_ = bstack1ll1lll_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࠨඊ")
      args = args[2:]
    elif args[1] == bstack1ll1lll_opy_ (u"ࠩࡥࡩ࡭ࡧࡶࡦࠩඋ"):
      bstack1lll1111_opy_ = bstack1ll1lll_opy_ (u"ࠪࡦࡪ࡮ࡡࡷࡧࠪඌ")
      args = args[2:]
    else:
      if not bstack1ll1lll_opy_ (u"ࠫ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱࠧඍ") in CONFIG or str(CONFIG[bstack1ll1lll_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࠨඎ")]).lower() in [bstack1ll1lll_opy_ (u"࠭ࡰࡺࡶ࡫ࡳࡳ࠭ඏ"), bstack1ll1lll_opy_ (u"ࠧࡱࡻࡷ࡬ࡴࡴ࠳ࠨඐ")]:
        bstack1lll1111_opy_ = bstack1ll1lll_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨඑ")
        args = args[1:]
      elif str(CONFIG[bstack1ll1lll_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬඒ")]).lower() == bstack1ll1lll_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩඓ"):
        bstack1lll1111_opy_ = bstack1ll1lll_opy_ (u"ࠫࡷࡵࡢࡰࡶࠪඔ")
        args = args[1:]
      elif str(CONFIG[bstack1ll1lll_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࠨඕ")]).lower() == bstack1ll1lll_opy_ (u"࠭ࡰࡢࡤࡲࡸࠬඖ"):
        bstack1lll1111_opy_ = bstack1ll1lll_opy_ (u"ࠧࡱࡣࡥࡳࡹ࠭඗")
        args = args[1:]
      elif str(CONFIG[bstack1ll1lll_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࠫ඘")]).lower() == bstack1ll1lll_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࠩ඙"):
        bstack1lll1111_opy_ = bstack1ll1lll_opy_ (u"ࠪࡴࡾࡺࡥࡴࡶࠪක")
        args = args[1:]
      elif str(CONFIG[bstack1ll1lll_opy_ (u"ࠫ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱࠧඛ")]).lower() == bstack1ll1lll_opy_ (u"ࠬࡨࡥࡩࡣࡹࡩࠬග"):
        bstack1lll1111_opy_ = bstack1ll1lll_opy_ (u"࠭ࡢࡦࡪࡤࡺࡪ࠭ඝ")
        args = args[1:]
      else:
        os.environ[bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡆࡓࡃࡐࡉ࡜ࡕࡒࡌࠩඞ")] = bstack1lll1111_opy_
        bstack1ll11ll1l_opy_(bstack1l1lll1l1_opy_)
  os.environ[bstack1ll1lll_opy_ (u"ࠨࡈࡕࡅࡒࡋࡗࡐࡔࡎࡣ࡚࡙ࡅࡅࠩඟ")] = bstack1lll1111_opy_
  bstack1l11111ll_opy_ = bstack1lll1111_opy_
  if cli.is_enabled(CONFIG):
    try:
      bstack11l1lllll1_opy_ = bstack111111l1_opy_[bstack1ll1lll_opy_ (u"ࠩࡓ࡝࡙ࡋࡓࡕ࠯ࡅࡈࡉ࠭ච")] if bstack1lll1111_opy_ == bstack1ll1lll_opy_ (u"ࠪࡴࡾࡺࡥࡴࡶࠪඡ") and bstack1l1111ll1l_opy_() else bstack1lll1111_opy_
      bstack1ll1l1ll11_opy_.invoke(bstack1l11l1lll1_opy_.bstack11llll11ll_opy_, bstack1llllllll1_opy_(
        sdk_version=__version__,
        path_config=bstack11l11ll1ll_opy_(),
        path_project=os.getcwd(),
        test_framework=bstack11l1lllll1_opy_,
        frameworks=[bstack11l1lllll1_opy_],
        framework_versions={
          bstack11l1lllll1_opy_: bstack111llllll_opy_(bstack1ll1lll_opy_ (u"ࠫࡗࡵࡢࡰࡶࠪජ") if bstack1lll1111_opy_ in [bstack1ll1lll_opy_ (u"ࠬࡶࡡࡣࡱࡷࠫඣ"), bstack1ll1lll_opy_ (u"࠭ࡲࡰࡤࡲࡸࠬඤ"), bstack1ll1lll_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠳ࡩ࡯ࡶࡨࡶࡳࡧ࡬ࠨඥ")] else bstack1lll1111_opy_)
        },
        bs_config=CONFIG
      ))
      if cli.config.get(bstack1ll1lll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠥඦ"), None):
        CONFIG[bstack1ll1lll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠦට")] = cli.config.get(bstack1ll1lll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠧඨ"), None)
    except Exception as e:
      bstack1ll1l1ll11_opy_.invoke(bstack1l11l1lll1_opy_.bstack1l1111ll_opy_, e.__traceback__, 1)
    if bstack1l1lll1lll_opy_:
      CONFIG[bstack1ll1lll_opy_ (u"ࠦࡦࡶࡰࠣඩ")] = cli.config[bstack1ll1lll_opy_ (u"ࠧࡧࡰࡱࠤඪ")]
      logger.info(bstack111111ll_opy_.format(CONFIG[bstack1ll1lll_opy_ (u"࠭ࡡࡱࡲࠪණ")]))
  else:
    bstack1ll1l1ll11_opy_.clear()
  global bstack1ll1lll11_opy_
  global bstack11l11ll11l_opy_
  if bstack1ll1111111_opy_:
    try:
      bstack11l1lll11_opy_ = datetime.datetime.now()
      os.environ[bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡆࡓࡃࡐࡉ࡜ࡕࡒࡌࠩඬ")] = bstack1lll1111_opy_
      bstack1ll1l1l1l1_opy_(bstack1l1l1l111l_opy_, CONFIG)
      cli.bstack1ll1l111l_opy_(bstack1ll1lll_opy_ (u"ࠣࡪࡷࡸࡵࡀࡳࡥ࡭ࡢࡸࡪࡹࡴࡠࡣࡷࡸࡪࡳࡰࡵࡧࡧࠦත"), datetime.datetime.now() - bstack11l1lll11_opy_)
    except Exception as e:
      logger.debug(bstack1l1lll11l1_opy_.format(str(e)))
  global bstack1111ll1l_opy_
  global bstack1lll1lll1_opy_
  global bstack11l1ll1lll_opy_
  global bstack1l1l111ll1_opy_
  global bstack11llll11_opy_
  global bstack1ll1llll1l_opy_
  global bstack1ll1lllll1_opy_
  global bstack11ll111l1_opy_
  global bstack11lllll11l_opy_
  global bstack11l111111l_opy_
  global bstack11lll1111l_opy_
  global bstack1llllll1ll_opy_
  global bstack1l11lll111_opy_
  global bstack1l1l1llll1_opy_
  global bstack11ll1ll1l1_opy_
  global bstack1l1l11111_opy_
  global bstack1l1ll1l1ll_opy_
  global bstack1lll11l1ll_opy_
  global bstack1l11111l11_opy_
  global bstack1l1l1l1l1l_opy_
  global bstack11ll1l1l_opy_
  try:
    from selenium import webdriver
    from selenium.webdriver.remote.webdriver import WebDriver
    bstack1111ll1l_opy_ = webdriver.Remote.__init__
    bstack1lll1lll1_opy_ = WebDriver.quit
    bstack1llllll1ll_opy_ = WebDriver.close
    bstack11ll1ll1l1_opy_ = WebDriver.get
    bstack11ll1l1l_opy_ = WebDriver.execute
  except Exception as e:
    pass
  try:
    import Browser
    from subprocess import Popen
    bstack1ll1lll11_opy_ = Popen.__init__
  except Exception as e:
    pass
  try:
    from bstack_utils.helper import bstack1ll11l1lll_opy_
    bstack11l11ll11l_opy_ = bstack1ll11l1lll_opy_()
  except Exception as e:
    pass
  try:
    global bstack11llllll1l_opy_
    from QWeb.keywords import browser
    bstack11llllll1l_opy_ = browser.close_browser
  except Exception as e:
    pass
  if bstack1l1lllllll_opy_(CONFIG) and bstack111llllll1_opy_():
    if bstack1lll1l1ll1_opy_() < version.parse(bstack1llll11l1l_opy_):
      logger.error(bstack1l1lll111_opy_.format(bstack1lll1l1ll1_opy_()))
    else:
      try:
        from selenium.webdriver.remote.remote_connection import RemoteConnection
        if hasattr(RemoteConnection, bstack1ll1lll_opy_ (u"ࠩࡢ࡫ࡪࡺ࡟ࡱࡴࡲࡼࡾࡥࡵࡳ࡮ࠪථ")) and callable(getattr(RemoteConnection, bstack1ll1lll_opy_ (u"ࠪࡣ࡬࡫ࡴࡠࡲࡵࡳࡽࡿ࡟ࡶࡴ࡯ࠫද"))):
          RemoteConnection._get_proxy_url = bstack11ll1lll1l_opy_
        else:
          from selenium.webdriver.remote.client_config import ClientConfig
          ClientConfig.get_proxy_url = bstack11ll1lll1l_opy_
      except Exception as e:
        logger.error(bstack1111ll1ll_opy_.format(str(e)))
  if not CONFIG.get(bstack1ll1lll_opy_ (u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡆࡻࡴࡰࡅࡤࡴࡹࡻࡲࡦࡎࡲ࡫ࡸ࠭ධ"), False) and not bstack1ll1111111_opy_:
    logger.info(bstack1l1l1l111_opy_)
  if not cli.is_enabled(CONFIG):
    if bstack1ll1lll_opy_ (u"ࠬࡺࡵࡳࡤࡲࡗࡨࡧ࡬ࡦࠩන") in CONFIG and str(CONFIG[bstack1ll1lll_opy_ (u"࠭ࡴࡶࡴࡥࡳࡘࡩࡡ࡭ࡧࠪ඲")]).lower() != bstack1ll1lll_opy_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭ඳ"):
      bstack111lllll11_opy_()
    elif bstack1lll1111_opy_ != bstack1ll1lll_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨප") or (bstack1lll1111_opy_ == bstack1ll1lll_opy_ (u"ࠩࡳࡽࡹ࡮࡯࡯ࠩඵ") and not bstack1ll1111111_opy_):
      bstack111llll1_opy_()
  if (bstack1lll1111_opy_ in [bstack1ll1lll_opy_ (u"ࠪࡴࡦࡨ࡯ࡵࠩබ"), bstack1ll1lll_opy_ (u"ࠫࡷࡵࡢࡰࡶࠪභ"), bstack1ll1lll_opy_ (u"ࠬࡸ࡯ࡣࡱࡷ࠱࡮ࡴࡴࡦࡴࡱࡥࡱ࠭ම")]):
    try:
      from robot import run_cli
      from robot.output import Output
      from robot.running.status import TestStatus
      from pabot.pabot import QueueItem
      from pabot import pabot
      try:
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCreator
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCache
        WebDriverCreator._get_ff_profile = bstack1l1l1111ll_opy_
        bstack1ll1llll1l_opy_ = WebDriverCache.close
      except Exception as e:
        logger.warn(bstack1l11l11l_opy_ + str(e))
      try:
        from AppiumLibrary.utils.applicationcache import ApplicationCache
        bstack11llll11_opy_ = ApplicationCache.close
      except Exception as e:
        logger.debug(bstack1llll1l11l_opy_ + str(e))
    except Exception as e:
      bstack11ll111lll_opy_(e, bstack1l11l11l_opy_)
    if bstack1lll1111_opy_ != bstack1ll1lll_opy_ (u"࠭ࡲࡰࡤࡲࡸ࠲࡯࡮ࡵࡧࡵࡲࡦࡲࠧඹ"):
      bstack1l1l11lll1_opy_()
    bstack11l1ll1lll_opy_ = Output.start_test
    bstack1l1l111ll1_opy_ = Output.end_test
    bstack1ll1lllll1_opy_ = TestStatus.__init__
    bstack11lllll11l_opy_ = pabot._run
    bstack11l111111l_opy_ = QueueItem.__init__
    bstack11lll1111l_opy_ = pabot._create_command_for_execution
    bstack1l11111l11_opy_ = pabot._report_results
  if bstack1lll1111_opy_ == bstack1ll1lll_opy_ (u"ࠧࡣࡧ࡫ࡥࡻ࡫ࠧය"):
    try:
      from behave.runner import Runner
      from behave.model import Step
    except Exception as e:
      bstack11ll111lll_opy_(e, bstack11l1ll11l_opy_)
    bstack1l11lll111_opy_ = Runner.run_hook
    bstack1l1l1llll1_opy_ = Step.run
  if bstack1lll1111_opy_ == bstack1ll1lll_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࠨර"):
    try:
      from _pytest.config import Config
      bstack1l1ll1l1ll_opy_ = Config.getoption
      from _pytest import runner
      bstack1lll11l1ll_opy_ = runner._update_current_test_var
    except Exception as e:
      logger.warn(e, bstack1llll111l_opy_)
    try:
      from pytest_bdd import reporting
      bstack1l1l1l1l1l_opy_ = reporting.runtest_makereport
    except Exception as e:
      logger.debug(bstack1ll1lll_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡴࡾࡺࡥࡴࡶ࠰ࡦࡩࡪࠠࡵࡱࠣࡶࡺࡴࠠࡱࡻࡷࡩࡸࡺ࠭ࡣࡦࡧࠤࡹ࡫ࡳࡵࡵࠪ඼"))
  try:
    framework_name = bstack1ll1lll_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩල") if bstack1lll1111_opy_ in [bstack1ll1lll_opy_ (u"ࠫࡵࡧࡢࡰࡶࠪ඾"), bstack1ll1lll_opy_ (u"ࠬࡸ࡯ࡣࡱࡷࠫ඿"), bstack1ll1lll_opy_ (u"࠭ࡲࡰࡤࡲࡸ࠲࡯࡮ࡵࡧࡵࡲࡦࡲࠧව")] else bstack1l1ll11l_opy_(bstack1lll1111_opy_)
    bstack11ll11l1_opy_ = {
      bstack1ll1lll_opy_ (u"ࠧࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࡢࡲࡦࡳࡥࠨශ"): bstack1ll1lll_opy_ (u"ࠨࡒࡼࡸࡪࡹࡴ࠮ࡥࡸࡧࡺࡳࡢࡦࡴࠪෂ") if bstack1lll1111_opy_ == bstack1ll1lll_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࠩස") and bstack1l1111ll1l_opy_() else framework_name,
      bstack1ll1lll_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡶࡦࡴࡶ࡭ࡴࡴࠧහ"): bstack111llllll_opy_(framework_name),
      bstack1ll1lll_opy_ (u"ࠫࡸࡪ࡫ࡠࡸࡨࡶࡸ࡯࡯࡯ࠩළ"): __version__,
      bstack1ll1lll_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡷࡶࡩࡩ࠭ෆ"): bstack1lll1111_opy_
    }
    if bstack1lll1111_opy_ in bstack11l11l1ll_opy_ + bstack11llll1l_opy_:
      if bstack1l11l1l1_opy_.bstack1lll11l11l_opy_(CONFIG):
        if bstack1ll1lll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࡕࡰࡵ࡫ࡲࡲࡸ࠭෇") in CONFIG:
          os.environ[bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡣࡆࡉࡃࡆࡕࡖࡍࡇࡏࡌࡊࡖ࡜ࡣࡈࡕࡎࡇࡋࡊ࡙ࡗࡇࡔࡊࡑࡑࡣ࡞ࡓࡌࠨ෈")] = os.getenv(bstack1ll1lll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡇࡖࡘࡤࡇࡃࡄࡇࡖࡗࡎࡈࡉࡍࡋࡗ࡝ࡤࡉࡏࡏࡈࡌࡋ࡚ࡘࡁࡕࡋࡒࡒࡤ࡟ࡍࡍࠩ෉"), json.dumps(CONFIG[bstack1ll1lll_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࡑࡳࡸ࡮ࡵ࡮ࡴ්ࠩ")]))
          CONFIG[bstack1ll1lll_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࡒࡴࡹ࡯࡯࡯ࡵࠪ෋")].pop(bstack1ll1lll_opy_ (u"ࠫ࡮ࡴࡣ࡭ࡷࡧࡩ࡙ࡧࡧࡴࡋࡱࡘࡪࡹࡴࡪࡰࡪࡗࡨࡵࡰࡦࠩ෌"), None)
          CONFIG[bstack1ll1lll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࡔࡶࡴࡪࡱࡱࡷࠬ෍")].pop(bstack1ll1lll_opy_ (u"࠭ࡥࡹࡥ࡯ࡹࡩ࡫ࡔࡢࡩࡶࡍࡳ࡚ࡥࡴࡶ࡬ࡲ࡬࡙ࡣࡰࡲࡨࠫ෎"), None)
        bstack11ll11l1_opy_[bstack1ll1lll_opy_ (u"ࠧࡵࡧࡶࡸࡋࡸࡡ࡮ࡧࡺࡳࡷࡱࠧා")] = {
          bstack1ll1lll_opy_ (u"ࠨࡰࡤࡱࡪ࠭ැ"): bstack1ll1lll_opy_ (u"ࠩࡶࡩࡱ࡫࡮ࡪࡷࡰࠫෑ"),
          bstack1ll1lll_opy_ (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫි"): str(bstack1lll1l1ll1_opy_())
        }
    if bstack1lll1111_opy_ not in [bstack1ll1lll_opy_ (u"ࠫࡷࡵࡢࡰࡶ࠰࡭ࡳࡺࡥࡳࡰࡤࡰࠬී")] and not cli.is_running():
      bstack1l1lllll11_opy_, bstack1l111111l_opy_ = bstack1l111l111l_opy_.launch(CONFIG, bstack11ll11l1_opy_)
      if bstack1l111111l_opy_.get(bstack1ll1lll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠬු")) is not None and bstack1l11l1l1_opy_.bstack111lll11_opy_(CONFIG) is None:
        value = bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࠭෕")].get(bstack1ll1lll_opy_ (u"ࠧࡴࡷࡦࡧࡪࡹࡳࠨූ"))
        if value is not None:
            CONFIG[bstack1ll1lll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨ෗")] = value
        else:
          logger.debug(bstack1ll1lll_opy_ (u"ࠤࡑࡳࠥࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡪࡡࡵࡣࠣࡪࡴࡻ࡮ࡥࠢ࡬ࡲࠥࡸࡥࡴࡲࡲࡲࡸ࡫ࠢෘ"))
  except Exception as e:
    logger.debug(bstack1lll1l11l_opy_.format(bstack1ll1lll_opy_ (u"ࠪࡘࡪࡹࡴࡉࡷࡥࠫෙ"), str(e)))
  if bstack1lll1111_opy_ == bstack1ll1lll_opy_ (u"ࠫࡵࡿࡴࡩࡱࡱࠫේ"):
    bstack11llll1l11_opy_ = True
    if bstack1ll1111111_opy_ and bstack1l11ll1lll_opy_:
      bstack1ll1lll1l1_opy_ = CONFIG.get(bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩෛ"), {}).get(bstack1ll1lll_opy_ (u"࠭࡬ࡰࡥࡤࡰࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨො"))
      bstack1l1lllll1l_opy_(bstack1ll111l1_opy_)
    elif bstack1ll1111111_opy_:
      bstack1ll1lll1l1_opy_ = CONFIG.get(bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫෝ"), {}).get(bstack1ll1lll_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪෞ"))
      global bstack1ll11ll1l1_opy_
      try:
        if bstack1lllll111l_opy_(bstack1ll1111111_opy_[bstack1ll1lll_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬෟ")]) and multiprocessing.current_process().name == bstack1ll1lll_opy_ (u"ࠪ࠴ࠬ෠"):
          bstack1ll1111111_opy_[bstack1ll1lll_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧ෡")].remove(bstack1ll1lll_opy_ (u"ࠬ࠳࡭ࠨ෢"))
          bstack1ll1111111_opy_[bstack1ll1lll_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩ෣")].remove(bstack1ll1lll_opy_ (u"ࠧࡱࡦࡥࠫ෤"))
          bstack1ll1111111_opy_[bstack1ll1lll_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫ෥")] = bstack1ll1111111_opy_[bstack1ll1lll_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬ෦")][0]
          with open(bstack1ll1111111_opy_[bstack1ll1lll_opy_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭෧")], bstack1ll1lll_opy_ (u"ࠫࡷ࠭෨")) as f:
            bstack1ll1111lll_opy_ = f.read()
          bstack1l11l11ll1_opy_ = bstack1ll1lll_opy_ (u"ࠧࠨࠢࡧࡴࡲࡱࠥࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡸࡪ࡫ࠡ࡫ࡰࡴࡴࡸࡴࠡࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡪࡰ࡬ࡸ࡮ࡧ࡬ࡪࡼࡨ࠿ࠥࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣ࡮ࡴࡩࡵ࡫ࡤࡰ࡮ࢀࡥࠩࡽࢀ࠭ࡀࠦࡦࡳࡱࡰࠤࡵࡪࡢࠡ࡫ࡰࡴࡴࡸࡴࠡࡒࡧࡦࡀࠦ࡯ࡨࡡࡧࡦࠥࡃࠠࡑࡦࡥ࠲ࡩࡵ࡟ࡣࡴࡨࡥࡰࡁࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡨࡪ࡬ࠠ࡮ࡱࡧࡣࡧࡸࡥࡢ࡭ࠫࡷࡪࡲࡦ࠭ࠢࡤࡶ࡬࠲ࠠࡵࡧࡰࡴࡴࡸࡡࡳࡻࠣࡁࠥ࠶ࠩ࠻ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡵࡴࡼ࠾ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡧࡲࡨࠢࡀࠤࡸࡺࡲࠩ࡫ࡱࡸ࠭ࡧࡲࡨࠫ࠮࠵࠵࠯ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥ࡫ࡸࡤࡧࡳࡸࠥࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡࡣࡶࠤࡪࡀࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡱࡣࡶࡷࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡳ࡬ࡥࡤࡣࠪࡶࡩࡱ࡬ࠬࡢࡴࡪ࠰ࡹ࡫࡭ࡱࡱࡵࡥࡷࡿࠩࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡕࡪࡢ࠯ࡦࡲࡣࡧࠦ࠽ࠡ࡯ࡲࡨࡤࡨࡲࡦࡣ࡮ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡑࡦࡥ࠲ࡩࡵ࡟ࡣࡴࡨࡥࡰࠦ࠽ࠡ࡯ࡲࡨࡤࡨࡲࡦࡣ࡮ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡑࡦࡥࠬ࠮࠴ࡳࡦࡶࡢࡸࡷࡧࡣࡦࠪࠬࡠࡳࠨࠢࠣ෩").format(str(bstack1ll1111111_opy_))
          bstack11l1l111_opy_ = bstack1l11l11ll1_opy_ + bstack1ll1111lll_opy_
          bstack1lll11l1l_opy_ = bstack1ll1111111_opy_[bstack1ll1lll_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩ෪")] + bstack1ll1lll_opy_ (u"ࠧࡠࡤࡶࡸࡦࡩ࡫ࡠࡶࡨࡱࡵ࠴ࡰࡺࠩ෫")
          with open(bstack1lll11l1l_opy_, bstack1ll1lll_opy_ (u"ࠨࡹࠪ෬")):
            pass
          with open(bstack1lll11l1l_opy_, bstack1ll1lll_opy_ (u"ࠤࡺ࠯ࠧ෭")) as f:
            f.write(bstack11l1l111_opy_)
          import subprocess
          bstack1l11l1ll11_opy_ = subprocess.run([bstack1ll1lll_opy_ (u"ࠥࡴࡾࡺࡨࡰࡰࠥ෮"), bstack1lll11l1l_opy_])
          if os.path.exists(bstack1lll11l1l_opy_):
            os.unlink(bstack1lll11l1l_opy_)
          os._exit(bstack1l11l1ll11_opy_.returncode)
        else:
          if bstack1lllll111l_opy_(bstack1ll1111111_opy_[bstack1ll1lll_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧ෯")]):
            bstack1ll1111111_opy_[bstack1ll1lll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨ෰")].remove(bstack1ll1lll_opy_ (u"࠭࠭࡮ࠩ෱"))
            bstack1ll1111111_opy_[bstack1ll1lll_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪෲ")].remove(bstack1ll1lll_opy_ (u"ࠨࡲࡧࡦࠬෳ"))
            bstack1ll1111111_opy_[bstack1ll1lll_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬ෴")] = bstack1ll1111111_opy_[bstack1ll1lll_opy_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭෵")][0]
          bstack1l1lllll1l_opy_(bstack1ll111l1_opy_)
          sys.path.append(os.path.dirname(os.path.abspath(bstack1ll1111111_opy_[bstack1ll1lll_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧ෶")])))
          sys.argv = sys.argv[2:]
          mod_globals = globals()
          mod_globals[bstack1ll1lll_opy_ (u"ࠬࡥ࡟࡯ࡣࡰࡩࡤࡥࠧ෷")] = bstack1ll1lll_opy_ (u"࠭࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠨ෸")
          mod_globals[bstack1ll1lll_opy_ (u"ࠧࡠࡡࡩ࡭ࡱ࡫࡟ࡠࠩ෹")] = os.path.abspath(bstack1ll1111111_opy_[bstack1ll1lll_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫ෺")])
          exec(open(bstack1ll1111111_opy_[bstack1ll1lll_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬ෻")]).read(), mod_globals)
      except BaseException as e:
        try:
          traceback.print_exc()
          logger.error(bstack1ll1lll_opy_ (u"ࠪࡇࡦࡻࡧࡩࡶࠣࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࡀࠠࡼࡿࠪ෼").format(str(e)))
          for driver in bstack1ll11ll1l1_opy_:
            bstack11l1111l1l_opy_.append({
              bstack1ll1lll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩ෽"): bstack1ll1111111_opy_[bstack1ll1lll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨ෾")],
              bstack1ll1lll_opy_ (u"࠭ࡥࡳࡴࡲࡶࠬ෿"): str(e),
              bstack1ll1lll_opy_ (u"ࠧࡪࡰࡧࡩࡽ࠭฀"): multiprocessing.current_process().name
            })
            bstack1l1lll1ll1_opy_(driver, bstack1ll1lll_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨก"), bstack1ll1lll_opy_ (u"ࠤࡖࡩࡸࡹࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣࡻ࡮ࡺࡨ࠻ࠢ࡟ࡲࠧข") + str(e))
        except Exception:
          pass
      finally:
        try:
          for driver in bstack1ll11ll1l1_opy_:
            driver.quit()
        except Exception as e:
          pass
    else:
      percy.init(bstack1l1lll1lll_opy_, CONFIG, logger)
      bstack11ll1lll1_opy_()
      bstack1ll1llll1_opy_()
      percy.bstack1lll111l1l_opy_()
      bstack1l11lll11_opy_ = {
        bstack1ll1lll_opy_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭ฃ"): args[0],
        bstack1ll1lll_opy_ (u"ࠫࡈࡕࡎࡇࡋࡊࠫค"): CONFIG,
        bstack1ll1lll_opy_ (u"ࠬࡎࡕࡃࡡࡘࡖࡑ࠭ฅ"): bstack111ll111_opy_,
        bstack1ll1lll_opy_ (u"࠭ࡉࡔࡡࡄࡔࡕࡥࡁࡖࡖࡒࡑࡆ࡚ࡅࠨฆ"): bstack1l1lll1lll_opy_
      }
      if bstack1ll1lll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪง") in CONFIG:
        bstack111lllll1_opy_ = bstack1l1l11l1_opy_(args, logger, CONFIG, bstack1l11111l1l_opy_, bstack1l11l11l1l_opy_)
        bstack11111111l_opy_ = bstack111lllll1_opy_.bstack11111lll1_opy_(run_on_browserstack, bstack1l11lll11_opy_, bstack1lllll111l_opy_(args))
      else:
        if bstack1lllll111l_opy_(args):
          bstack1l11lll11_opy_[bstack1ll1lll_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫจ")] = args
          test = multiprocessing.Process(name=str(0),
                                         target=run_on_browserstack, args=(bstack1l11lll11_opy_,))
          test.start()
          test.join()
        else:
          bstack1l1lllll1l_opy_(bstack1ll111l1_opy_)
          sys.path.append(os.path.dirname(os.path.abspath(args[0])))
          mod_globals = globals()
          mod_globals[bstack1ll1lll_opy_ (u"ࠩࡢࡣࡳࡧ࡭ࡦࡡࡢࠫฉ")] = bstack1ll1lll_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬช")
          mod_globals[bstack1ll1lll_opy_ (u"ࠫࡤࡥࡦࡪ࡮ࡨࡣࡤ࠭ซ")] = os.path.abspath(args[0])
          sys.argv = sys.argv[2:]
          exec(open(args[0]).read(), mod_globals)
  elif bstack1lll1111_opy_ == bstack1ll1lll_opy_ (u"ࠬࡶࡡࡣࡱࡷࠫฌ") or bstack1lll1111_opy_ == bstack1ll1lll_opy_ (u"࠭ࡲࡰࡤࡲࡸࠬญ"):
    percy.init(bstack1l1lll1lll_opy_, CONFIG, logger)
    percy.bstack1lll111l1l_opy_()
    try:
      from pabot import pabot
    except Exception as e:
      bstack11ll111lll_opy_(e, bstack1l11l11l_opy_)
    bstack11ll1lll1_opy_()
    bstack1l1lllll1l_opy_(bstack1111l1111_opy_)
    if bstack1l11111l1l_opy_:
      bstack1l11llll1l_opy_(bstack1111l1111_opy_, args)
      if bstack1ll1lll_opy_ (u"ࠧ࠮࠯ࡳࡶࡴࡩࡥࡴࡵࡨࡷࠬฎ") in args:
        i = args.index(bstack1ll1lll_opy_ (u"ࠨ࠯࠰ࡴࡷࡵࡣࡦࡵࡶࡩࡸ࠭ฏ"))
        args.pop(i)
        args.pop(i)
      if bstack1ll1lll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬฐ") not in CONFIG:
        CONFIG[bstack1ll1lll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ฑ")] = [{}]
        bstack1l11l11l1l_opy_ = 1
      if bstack1lll1ll1ll_opy_ == 0:
        bstack1lll1ll1ll_opy_ = 1
      args.insert(0, str(bstack1lll1ll1ll_opy_))
      args.insert(0, str(bstack1ll1lll_opy_ (u"ࠫ࠲࠳ࡰࡳࡱࡦࡩࡸࡹࡥࡴࠩฒ")))
    if bstack1l111l111l_opy_.on():
      try:
        from robot.run import USAGE
        from robot.utils import ArgumentParser
        from pabot.arguments import _parse_pabot_args
        bstack11l11l11_opy_, pabot_args = _parse_pabot_args(args)
        opts, bstack1l111l111_opy_ = ArgumentParser(
            USAGE,
            auto_pythonpath=False,
            auto_argumentfile=True,
            env_options=bstack1ll1lll_opy_ (u"ࠧࡘࡏࡃࡑࡗࡣࡔࡖࡔࡊࡑࡑࡗࠧณ"),
        ).parse_args(bstack11l11l11_opy_)
        bstack11l111lll1_opy_ = args.index(bstack11l11l11_opy_[0]) if len(bstack11l11l11_opy_) > 0 else len(args)
        args.insert(bstack11l111lll1_opy_, str(bstack1ll1lll_opy_ (u"࠭࠭࠮࡮࡬ࡷࡹ࡫࡮ࡦࡴࠪด")))
        args.insert(bstack11l111lll1_opy_ + 1, str(os.path.join(os.path.dirname(os.path.realpath(__file__)), bstack1ll1lll_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࡟ࡳࡱࡥࡳࡹࡥ࡬ࡪࡵࡷࡩࡳ࡫ࡲ࠯ࡲࡼࠫต"))))
        if bstack11lll1lll1_opy_.bstack1111ll1l1_opy_(CONFIG):
          args.insert(bstack11l111lll1_opy_, str(bstack1ll1lll_opy_ (u"ࠨ࠯࠰ࡰ࡮ࡹࡴࡦࡰࡨࡶࠬถ")))
          args.insert(bstack11l111lll1_opy_ + 1, str(bstack1ll1lll_opy_ (u"ࠩࡕࡩࡹࡸࡹࡇࡣ࡬ࡰࡪࡪ࠺ࡼࡿࠪท").format(bstack11lll1lll1_opy_.bstack11l1l1111l_opy_(CONFIG))))
        if bstack1ll111ll11_opy_(os.environ.get(bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡕࡉࡗ࡛ࡎࠨธ"))) and str(os.environ.get(bstack1ll1lll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡖࡊࡘࡕࡏࡡࡗࡉࡘ࡚ࡓࠨน"), bstack1ll1lll_opy_ (u"ࠬࡴࡵ࡭࡮ࠪบ"))) != bstack1ll1lll_opy_ (u"࠭࡮ࡶ࡮࡯ࠫป"):
          for bstack1l1l1ll11_opy_ in bstack1l111l111_opy_:
            args.remove(bstack1l1l1ll11_opy_)
          test_files = os.environ.get(bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡒࡆࡔࡘࡒࡤ࡚ࡅࡔࡖࡖࠫผ")).split(bstack1ll1lll_opy_ (u"ࠨ࠮ࠪฝ"))
          for bstack1111l1l11_opy_ in test_files:
            args.append(bstack1111l1l11_opy_)
      except Exception as e:
        logger.error(bstack1ll1lll_opy_ (u"ࠤࡈࡶࡷࡵࡲࠡࡹ࡫࡭ࡱ࡫ࠠࡢࡶࡷࡥࡨ࡮ࡩ࡯ࡩࠣࡰ࡮ࡹࡴࡦࡰࡨࡶࠥ࡬࡯ࡳࠢࡾࢁ࠳ࠦࡅࡳࡴࡲࡶࠥ࠳ࠠࡼࡿࠥพ").format(bstack1ll111llll_opy_, e))
    pabot.main(args)
  elif bstack1lll1111_opy_ == bstack1ll1lll_opy_ (u"ࠪࡶࡴࡨ࡯ࡵ࠯࡬ࡲࡹ࡫ࡲ࡯ࡣ࡯ࠫฟ"):
    try:
      from robot import run_cli
    except Exception as e:
      bstack11ll111lll_opy_(e, bstack1l11l11l_opy_)
    for a in args:
      if bstack1ll1lll_opy_ (u"ࠫࡇ࡙ࡔࡂࡅࡎࡔࡑࡇࡔࡇࡑࡕࡑࡎࡔࡄࡆ࡚ࠪภ") in a:
        bstack1lllll1ll1_opy_ = int(a.split(bstack1ll1lll_opy_ (u"ࠬࡀࠧม"))[1])
      if bstack1ll1lll_opy_ (u"࠭ࡂࡔࡖࡄࡇࡐࡊࡅࡇࡎࡒࡇࡆࡒࡉࡅࡇࡑࡘࡎࡌࡉࡆࡔࠪย") in a:
        bstack1ll1lll1l1_opy_ = str(a.split(bstack1ll1lll_opy_ (u"ࠧ࠻ࠩร"))[1])
      if bstack1ll1lll_opy_ (u"ࠨࡄࡖࡘࡆࡉࡋࡄࡎࡌࡅࡗࡍࡓࠨฤ") in a:
        bstack1l1lllll1_opy_ = str(a.split(bstack1ll1lll_opy_ (u"ࠩ࠽ࠫล"))[1])
    bstack1lll1l1l11_opy_ = None
    if bstack1ll1lll_opy_ (u"ࠪ࠱࠲ࡨࡳࡵࡣࡦ࡯ࡤ࡯ࡴࡦ࡯ࡢ࡭ࡳࡪࡥࡹࠩฦ") in args:
      i = args.index(bstack1ll1lll_opy_ (u"ࠫ࠲࠳ࡢࡴࡶࡤࡧࡰࡥࡩࡵࡧࡰࡣ࡮ࡴࡤࡦࡺࠪว"))
      args.pop(i)
      bstack1lll1l1l11_opy_ = args.pop(i)
    if bstack1lll1l1l11_opy_ is not None:
      global bstack1ll11l111_opy_
      bstack1ll11l111_opy_ = bstack1lll1l1l11_opy_
      bstack1lllll1ll1_opy_ = int(bstack1lll1l1l11_opy_)
    bstack1l1lllll1l_opy_(bstack1111l1111_opy_)
    run_cli(args)
    if bstack1ll1lll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯ࡤ࡫ࡲࡳࡱࡵࡣࡱ࡯ࡳࡵࠩศ") in multiprocessing.current_process().__dict__.keys():
      for bstack1l11lllll_opy_ in multiprocessing.current_process().bstack_error_list:
        bstack11l1111l1l_opy_.append(bstack1l11lllll_opy_)
  elif bstack1lll1111_opy_ == bstack1ll1lll_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭ษ"):
    bstack11l1l11l11_opy_ = bstack11lll1l111_opy_(args, logger, CONFIG, bstack1l11111l1l_opy_)
    bstack11l1l11l11_opy_.bstack111l1111l_opy_()
    bstack11ll1lll1_opy_()
    bstack1l1l1111_opy_ = True
    bstack1l11l11lll_opy_ = bstack11l1l11l11_opy_.bstack1l1ll1ll_opy_()
    bstack11l1l11l11_opy_.bstack1l11lll11_opy_(bstack1l1l11ll1_opy_)
    bstack11l1l11l11_opy_.bstack1llll11l1_opy_()
    bstack1llll11l11_opy_(bstack1lll1111_opy_, CONFIG, bstack11l1l11l11_opy_.bstack1l1l1l11l1_opy_())
    bstack11l1l11ll_opy_ = bstack11l1l11l11_opy_.bstack11111lll1_opy_(bstack1l1llll11_opy_, {
      bstack1ll1lll_opy_ (u"ࠧࡉࡗࡅࡣ࡚ࡘࡌࠨส"): bstack111ll111_opy_,
      bstack1ll1lll_opy_ (u"ࠨࡋࡖࡣࡆࡖࡐࡠࡃࡘࡘࡔࡓࡁࡕࡇࠪห"): bstack1l1lll1lll_opy_,
      bstack1ll1lll_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡃࡘࡘࡔࡓࡁࡕࡋࡒࡒࠬฬ"): bstack1l11111l1l_opy_
    })
    try:
      bstack1ll1lll11l_opy_, bstack11lll11l1l_opy_ = map(list, zip(*bstack11l1l11ll_opy_))
      bstack1l11ll111l_opy_ = bstack1ll1lll11l_opy_[0]
      for status_code in bstack11lll11l1l_opy_:
        if status_code != 0:
          bstack1ll1l11ll_opy_ = status_code
          break
    except Exception as e:
      logger.debug(bstack1ll1lll_opy_ (u"࡙ࠥࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡳࡢࡸࡨࠤࡪࡸࡲࡰࡴࡶࠤࡦࡴࡤࠡࡵࡷࡥࡹࡻࡳࠡࡥࡲࡨࡪ࠴ࠠࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࠾ࠥࢁࡽࠣอ").format(str(e)))
  elif bstack1lll1111_opy_ == bstack1ll1lll_opy_ (u"ࠫࡧ࡫ࡨࡢࡸࡨࠫฮ"):
    try:
      from behave.__main__ import main as bstack1lllll11_opy_
      from behave.configuration import Configuration
    except Exception as e:
      bstack11ll111lll_opy_(e, bstack11l1ll11l_opy_)
    bstack11ll1lll1_opy_()
    bstack1l1l1111_opy_ = True
    bstack1ll1ll1ll1_opy_ = 1
    if bstack1ll1lll_opy_ (u"ࠬࡶࡡࡳࡣ࡯ࡰࡪࡲࡳࡑࡧࡵࡔࡱࡧࡴࡧࡱࡵࡱࠬฯ") in CONFIG:
      bstack1ll1ll1ll1_opy_ = CONFIG[bstack1ll1lll_opy_ (u"࠭ࡰࡢࡴࡤࡰࡱ࡫࡬ࡴࡒࡨࡶࡕࡲࡡࡵࡨࡲࡶࡲ࠭ะ")]
    if bstack1ll1lll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪั") in CONFIG:
      bstack11ll1111ll_opy_ = int(bstack1ll1ll1ll1_opy_) * int(len(CONFIG[bstack1ll1lll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫา")]))
    else:
      bstack11ll1111ll_opy_ = int(bstack1ll1ll1ll1_opy_)
    config = Configuration(args)
    bstack1l11111l_opy_ = config.paths
    if len(bstack1l11111l_opy_) == 0:
      import glob
      pattern = bstack1ll1lll_opy_ (u"ࠩ࠭࠮࠴࠰࠮ࡧࡧࡤࡸࡺࡸࡥࠨำ")
      bstack11ll1l1lll_opy_ = glob.glob(pattern, recursive=True)
      args.extend(bstack11ll1l1lll_opy_)
      config = Configuration(args)
      bstack1l11111l_opy_ = config.paths
    bstack11l1ll1111_opy_ = [os.path.normpath(item) for item in bstack1l11111l_opy_]
    bstack1l1ll11111_opy_ = [os.path.normpath(item) for item in args]
    bstack1l1l111lll_opy_ = [item for item in bstack1l1ll11111_opy_ if item not in bstack11l1ll1111_opy_]
    import platform as pf
    if pf.system().lower() == bstack1ll1lll_opy_ (u"ࠪࡻ࡮ࡴࡤࡰࡹࡶࠫิ"):
      from pathlib import PureWindowsPath, PurePosixPath
      bstack11l1ll1111_opy_ = [str(PurePosixPath(PureWindowsPath(bstack1ll111l1l_opy_)))
                    for bstack1ll111l1l_opy_ in bstack11l1ll1111_opy_]
    bstack111111l11_opy_ = []
    for spec in bstack11l1ll1111_opy_:
      bstack11llll11l_opy_ = []
      bstack11llll11l_opy_ += bstack1l1l111lll_opy_
      bstack11llll11l_opy_.append(spec)
      bstack111111l11_opy_.append(bstack11llll11l_opy_)
    execution_items = []
    for bstack11llll11l_opy_ in bstack111111l11_opy_:
      if bstack1ll1lll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧี") in CONFIG:
        for index, _ in enumerate(CONFIG[bstack1ll1lll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨึ")]):
          item = {}
          item[bstack1ll1lll_opy_ (u"࠭ࡡࡳࡩࠪื")] = bstack1ll1lll_opy_ (u"ุࠧࠡࠩ").join(bstack11llll11l_opy_)
          item[bstack1ll1lll_opy_ (u"ࠨ࡫ࡱࡨࡪࡾูࠧ")] = index
          execution_items.append(item)
      else:
        item = {}
        item[bstack1ll1lll_opy_ (u"ࠩࡤࡶ࡬ฺ࠭")] = bstack1ll1lll_opy_ (u"ࠪࠤࠬ฻").join(bstack11llll11l_opy_)
        item[bstack1ll1lll_opy_ (u"ࠫ࡮ࡴࡤࡦࡺࠪ฼")] = 0
        execution_items.append(item)
    bstack1lll1l11ll_opy_ = bstack1ll1ll1l1l_opy_(execution_items, bstack11ll1111ll_opy_)
    for execution_item in bstack1lll1l11ll_opy_:
      bstack1lll1111l_opy_ = []
      for item in execution_item:
        bstack1lll1111l_opy_.append(bstack1llll1l1ll_opy_(name=str(item[bstack1ll1lll_opy_ (u"ࠬ࡯࡮ࡥࡧࡻࠫ฽")]),
                                             target=bstack1l1l11111l_opy_,
                                             args=(item[bstack1ll1lll_opy_ (u"࠭ࡡࡳࡩࠪ฾")],)))
      for t in bstack1lll1111l_opy_:
        t.start()
      for t in bstack1lll1111l_opy_:
        t.join()
  else:
    bstack1ll11ll1l_opy_(bstack1l1lll1l1_opy_)
  if not bstack1ll1111111_opy_:
    bstack11lll111l_opy_()
    if(bstack1lll1111_opy_ in [bstack1ll1lll_opy_ (u"ࠧࡣࡧ࡫ࡥࡻ࡫ࠧ฿"), bstack1ll1lll_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࠨเ")]):
      bstack11ll11l11_opy_()
  bstack1ll1ll1111_opy_.bstack11l11111ll_opy_()
def browserstack_initialize(bstack1l11lll11l_opy_=None):
  logger.info(bstack1ll1lll_opy_ (u"ࠩࡕࡹࡳࡴࡩ࡯ࡩࠣࡗࡉࡑࠠࡸ࡫ࡷ࡬ࠥࡧࡲࡨࡵ࠽ࠤࠬแ") + str(bstack1l11lll11l_opy_))
  run_on_browserstack(bstack1l11lll11l_opy_, None, True)
@measure(event_name=EVENTS.bstack1ll1l1111l_opy_, stage=STAGE.bstack111lll1l11_opy_, bstack11lllll111_opy_=bstack1lll11111l_opy_)
def bstack11lll111l_opy_():
  global CONFIG
  global bstack1l11111ll_opy_
  global bstack1ll1l11ll_opy_
  global bstack11ll1ll1_opy_
  global bstack11l1l11l_opy_
  bstack1lll1ll1_opy_.bstack11l1lll1_opy_()
  if cli.is_running():
    bstack1ll1l1ll11_opy_.invoke(bstack1l11l1lll1_opy_.bstack1lllll111_opy_)
  else:
    bstack1llll111ll_opy_ = bstack11lll1lll1_opy_.bstack1l1l111l_opy_(config=CONFIG)
    bstack1llll111ll_opy_.bstack111l1l1l_opy_(CONFIG)
  if bstack1l11111ll_opy_ == bstack1ll1lll_opy_ (u"ࠪࡴࡾࡺࡥࡴࡶࠪโ"):
    if not cli.is_enabled(CONFIG):
      bstack1l111l111l_opy_.stop()
  else:
    bstack1l111l111l_opy_.stop()
  if not cli.is_enabled(CONFIG):
    bstack11l11ll1l1_opy_.bstack1ll1l1lll_opy_()
  if bstack1ll1lll_opy_ (u"ࠫࡹࡻࡲࡣࡱࡖࡧࡦࡲࡥࠨใ") in CONFIG and str(CONFIG[bstack1ll1lll_opy_ (u"ࠬࡺࡵࡳࡤࡲࡗࡨࡧ࡬ࡦࠩไ")]).lower() != bstack1ll1lll_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬๅ"):
    hashed_id, bstack1l1l11ll11_opy_ = bstack1l1llllll1_opy_()
  else:
    hashed_id, bstack1l1l11ll11_opy_ = get_build_link()
  bstack1lll1l111_opy_(hashed_id)
  logger.info(bstack1ll1lll_opy_ (u"ࠧࡔࡆࡎࠤࡷࡻ࡮ࠡࡧࡱࡨࡪࡪࠠࡧࡱࡵࠤ࡮ࡪ࠺ࠨๆ") + bstack11l1l11l_opy_.get_property(bstack1ll1lll_opy_ (u"ࠨࡵࡧ࡯ࡗࡻ࡮ࡊࡦࠪ็"), bstack1ll1lll_opy_ (u"่ࠩࠪ")) + bstack1ll1lll_opy_ (u"ࠪ࠰ࠥࡺࡥࡴࡶ࡫ࡹࡧࠦࡩࡥ࠼้ࠣࠫ") + os.getenv(bstack1ll1lll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡘࡊ࡙ࡔࡉࡗࡅࡣ࡚࡛ࡉࡅ๊ࠩ"), bstack1ll1lll_opy_ (u"๋ࠬ࠭")))
  if hashed_id is not None and bstack1ll11l11l_opy_() != -1:
    sessions = bstack11ll111111_opy_(hashed_id)
    bstack1l1l1ll1ll_opy_(sessions, bstack1l1l11ll11_opy_)
  if bstack1l11111ll_opy_ == bstack1ll1lll_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭์") and bstack1ll1l11ll_opy_ != 0:
    sys.exit(bstack1ll1l11ll_opy_)
  if bstack1l11111ll_opy_ == bstack1ll1lll_opy_ (u"ࠧࡣࡧ࡫ࡥࡻ࡫ࠧํ") and bstack11ll1ll1_opy_ != 0:
    sys.exit(bstack11ll1ll1_opy_)
def bstack1lll1l111_opy_(new_id):
    global bstack1l1l1l11_opy_
    bstack1l1l1l11_opy_ = new_id
def bstack1l1ll11l_opy_(bstack1ll11l1l_opy_):
  if bstack1ll11l1l_opy_:
    return bstack1ll11l1l_opy_.capitalize()
  else:
    return bstack1ll1lll_opy_ (u"ࠨࠩ๎")
@measure(event_name=EVENTS.bstack1lll1l11_opy_, stage=STAGE.bstack111lll1l11_opy_, bstack11lllll111_opy_=bstack1lll11111l_opy_)
def bstack111111l1l_opy_(bstack1lll1lll11_opy_):
  if bstack1ll1lll_opy_ (u"ࠩࡱࡥࡲ࡫ࠧ๏") in bstack1lll1lll11_opy_ and bstack1lll1lll11_opy_[bstack1ll1lll_opy_ (u"ࠪࡲࡦࡳࡥࠨ๐")] != bstack1ll1lll_opy_ (u"ࠫࠬ๑"):
    return bstack1lll1lll11_opy_[bstack1ll1lll_opy_ (u"ࠬࡴࡡ࡮ࡧࠪ๒")]
  else:
    bstack11lllll111_opy_ = bstack1ll1lll_opy_ (u"ࠨࠢ๓")
    if bstack1ll1lll_opy_ (u"ࠧࡥࡧࡹ࡭ࡨ࡫ࠧ๔") in bstack1lll1lll11_opy_ and bstack1lll1lll11_opy_[bstack1ll1lll_opy_ (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨ๕")] != None:
      bstack11lllll111_opy_ += bstack1lll1lll11_opy_[bstack1ll1lll_opy_ (u"ࠩࡧࡩࡻ࡯ࡣࡦࠩ๖")] + bstack1ll1lll_opy_ (u"ࠥ࠰ࠥࠨ๗")
      if bstack1lll1lll11_opy_[bstack1ll1lll_opy_ (u"ࠫࡴࡹࠧ๘")] == bstack1ll1lll_opy_ (u"ࠧ࡯࡯ࡴࠤ๙"):
        bstack11lllll111_opy_ += bstack1ll1lll_opy_ (u"ࠨࡩࡐࡕࠣࠦ๚")
      bstack11lllll111_opy_ += (bstack1lll1lll11_opy_[bstack1ll1lll_opy_ (u"ࠧࡰࡵࡢࡺࡪࡸࡳࡪࡱࡱࠫ๛")] or bstack1ll1lll_opy_ (u"ࠨࠩ๜"))
      return bstack11lllll111_opy_
    else:
      bstack11lllll111_opy_ += bstack1l1ll11l_opy_(bstack1lll1lll11_opy_[bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࠪ๝")]) + bstack1ll1lll_opy_ (u"ࠥࠤࠧ๞") + (
              bstack1lll1lll11_opy_[bstack1ll1lll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭๟")] or bstack1ll1lll_opy_ (u"ࠬ࠭๠")) + bstack1ll1lll_opy_ (u"ࠨࠬࠡࠤ๡")
      if bstack1lll1lll11_opy_[bstack1ll1lll_opy_ (u"ࠧࡰࡵࠪ๢")] == bstack1ll1lll_opy_ (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ๣"):
        bstack11lllll111_opy_ += bstack1ll1lll_opy_ (u"ࠤ࡚࡭ࡳࠦࠢ๤")
      bstack11lllll111_opy_ += bstack1lll1lll11_opy_[bstack1ll1lll_opy_ (u"ࠪࡳࡸࡥࡶࡦࡴࡶ࡭ࡴࡴࠧ๥")] or bstack1ll1lll_opy_ (u"ࠫࠬ๦")
      return bstack11lllll111_opy_
@measure(event_name=EVENTS.bstack1lll1l1l_opy_, stage=STAGE.bstack111lll1l11_opy_, bstack11lllll111_opy_=bstack1lll11111l_opy_)
def bstack1l111l11_opy_(bstack1l11l1l1ll_opy_):
  if bstack1l11l1l1ll_opy_ == bstack1ll1lll_opy_ (u"ࠧࡪ࡯࡯ࡧࠥ๧"):
    return bstack1ll1lll_opy_ (u"࠭࠼ࡵࡦࠣࡧࡱࡧࡳࡴ࠿ࠥࡦࡸࡺࡡࡤ࡭࠰ࡨࡦࡺࡡࠣࠢࡶࡸࡾࡲࡥ࠾ࠤࡦࡳࡱࡵࡲ࠻ࡩࡵࡩࡪࡴ࠻ࠣࡀ࠿ࡪࡴࡴࡴࠡࡥࡲࡰࡴࡸ࠽ࠣࡩࡵࡩࡪࡴࠢ࠿ࡅࡲࡱࡵࡲࡥࡵࡧࡧࡀ࠴࡬࡯࡯ࡶࡁࡀ࠴ࡺࡤ࠿ࠩ๨")
  elif bstack1l11l1l1ll_opy_ == bstack1ll1lll_opy_ (u"ࠢࡧࡣ࡬ࡰࡪࡪࠢ๩"):
    return bstack1ll1lll_opy_ (u"ࠨ࠾ࡷࡨࠥࡩ࡬ࡢࡵࡶࡁࠧࡨࡳࡵࡣࡦ࡯࠲ࡪࡡࡵࡣࠥࠤࡸࡺࡹ࡭ࡧࡀࠦࡨࡵ࡬ࡰࡴ࠽ࡶࡪࡪ࠻ࠣࡀ࠿ࡪࡴࡴࡴࠡࡥࡲࡰࡴࡸ࠽ࠣࡴࡨࡨࠧࡄࡆࡢ࡫࡯ࡩࡩࡂ࠯ࡧࡱࡱࡸࡃࡂ࠯ࡵࡦࡁࠫ๪")
  elif bstack1l11l1l1ll_opy_ == bstack1ll1lll_opy_ (u"ࠤࡳࡥࡸࡹࡥࡥࠤ๫"):
    return bstack1ll1lll_opy_ (u"ࠪࡀࡹࡪࠠࡤ࡮ࡤࡷࡸࡃࠢࡣࡵࡷࡥࡨࡱ࠭ࡥࡣࡷࡥࠧࠦࡳࡵࡻ࡯ࡩࡂࠨࡣࡰ࡮ࡲࡶ࠿࡭ࡲࡦࡧࡱ࠿ࠧࡄ࠼ࡧࡱࡱࡸࠥࡩ࡯࡭ࡱࡵࡁࠧ࡭ࡲࡦࡧࡱࠦࡃࡖࡡࡴࡵࡨࡨࡁ࠵ࡦࡰࡰࡷࡂࡁ࠵ࡴࡥࡀࠪ๬")
  elif bstack1l11l1l1ll_opy_ == bstack1ll1lll_opy_ (u"ࠦࡪࡸࡲࡰࡴࠥ๭"):
    return bstack1ll1lll_opy_ (u"ࠬࡂࡴࡥࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡷࡹࡧࡣ࡬࠯ࡧࡥࡹࡧࠢࠡࡵࡷࡽࡱ࡫࠽ࠣࡥࡲࡰࡴࡸ࠺ࡳࡧࡧ࠿ࠧࡄ࠼ࡧࡱࡱࡸࠥࡩ࡯࡭ࡱࡵࡁࠧࡸࡥࡥࠤࡁࡉࡷࡸ࡯ࡳ࠾࠲ࡪࡴࡴࡴ࠿࠾࠲ࡸࡩࡄࠧ๮")
  elif bstack1l11l1l1ll_opy_ == bstack1ll1lll_opy_ (u"ࠨࡴࡪ࡯ࡨࡳࡺࡺࠢ๯"):
    return bstack1ll1lll_opy_ (u"ࠧ࠽ࡶࡧࠤࡨࡲࡡࡴࡵࡀࠦࡧࡹࡴࡢࡥ࡮࠱ࡩࡧࡴࡢࠤࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡧࡴࡲ࡯ࡳ࠼ࠦࡩࡪࡧ࠳࠳࠸࠾ࠦࡃࡂࡦࡰࡰࡷࠤࡨࡵ࡬ࡰࡴࡀࠦࠨ࡫ࡥࡢ࠵࠵࠺ࠧࡄࡔࡪ࡯ࡨࡳࡺࡺ࠼࠰ࡨࡲࡲࡹࡄ࠼࠰ࡶࡧࡂࠬ๰")
  elif bstack1l11l1l1ll_opy_ == bstack1ll1lll_opy_ (u"ࠣࡴࡸࡲࡳ࡯࡮ࡨࠤ๱"):
    return bstack1ll1lll_opy_ (u"ࠩ࠿ࡸࡩࠦࡣ࡭ࡣࡶࡷࡂࠨࡢࡴࡶࡤࡧࡰ࠳ࡤࡢࡶࡤࠦࠥࡹࡴࡺ࡮ࡨࡁࠧࡩ࡯࡭ࡱࡵ࠾ࡧࡲࡡࡤ࡭࠾ࠦࡃࡂࡦࡰࡰࡷࠤࡨࡵ࡬ࡰࡴࡀࠦࡧࡲࡡࡤ࡭ࠥࡂࡗࡻ࡮࡯࡫ࡱ࡫ࡁ࠵ࡦࡰࡰࡷࡂࡁ࠵ࡴࡥࡀࠪ๲")
  else:
    return bstack1ll1lll_opy_ (u"ࠪࡀࡹࡪࠠࡢ࡮࡬࡫ࡳࡃࠢࡤࡧࡱࡸࡪࡸࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡶࡸࡦࡩ࡫࠮ࡦࡤࡸࡦࠨࠠࡴࡶࡼࡰࡪࡃࠢࡤࡱ࡯ࡳࡷࡀࡢ࡭ࡣࡦ࡯ࡀࠨ࠾࠽ࡨࡲࡲࡹࠦࡣࡰ࡮ࡲࡶࡂࠨࡢ࡭ࡣࡦ࡯ࠧࡄࠧ๳") + bstack1l1ll11l_opy_(
      bstack1l11l1l1ll_opy_) + bstack1ll1lll_opy_ (u"ࠫࡁ࠵ࡦࡰࡰࡷࡂࡁ࠵ࡴࡥࡀࠪ๴")
def bstack11llll111_opy_(session):
  return bstack1ll1lll_opy_ (u"ࠬࡂࡴࡳࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡷࡹࡧࡣ࡬࠯ࡵࡳࡼࠨ࠾࠽ࡶࡧࠤࡨࡲࡡࡴࡵࡀࠦࡧࡹࡴࡢࡥ࡮࠱ࡩࡧࡴࡢࠢࡶࡩࡸࡹࡩࡰࡰ࠰ࡲࡦࡳࡥࠣࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦࢀࢃࠢࠡࡶࡤࡶ࡬࡫ࡴ࠾ࠤࡢࡦࡱࡧ࡮࡬ࠤࡁࡿࢂࡂ࠯ࡢࡀ࠿࠳ࡹࡪ࠾ࡼࡿࡾࢁࡁࡺࡤࠡࡣ࡯࡭࡬ࡴ࠽ࠣࡥࡨࡲࡹ࡫ࡲࠣࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡷࡹࡧࡣ࡬࠯ࡧࡥࡹࡧࠢ࠿ࡽࢀࡀ࠴ࡺࡤ࠿࠾ࡷࡨࠥࡧ࡬ࡪࡩࡱࡁࠧࡩࡥ࡯ࡶࡨࡶࠧࠦࡣ࡭ࡣࡶࡷࡂࠨࡢࡴࡶࡤࡧࡰ࠳ࡤࡢࡶࡤࠦࡃࢁࡽ࠽࠱ࡷࡨࡃࡂࡴࡥࠢࡤࡰ࡮࡭࡮࠾ࠤࡦࡩࡳࡺࡥࡳࠤࠣࡧࡱࡧࡳࡴ࠿ࠥࡦࡸࡺࡡࡤ࡭࠰ࡨࡦࡺࡡࠣࡀࡾࢁࡁ࠵ࡴࡥࡀ࠿ࡸࡩࠦࡡ࡭࡫ࡪࡲࡂࠨࡣࡦࡰࡷࡩࡷࠨࠠࡤ࡮ࡤࡷࡸࡃࠢࡣࡵࡷࡥࡨࡱ࠭ࡥࡣࡷࡥࠧࡄࡻࡾ࠾࠲ࡸࡩࡄ࠼࠰ࡶࡵࡂࠬ๵").format(
    session[bstack1ll1lll_opy_ (u"࠭ࡰࡶࡤ࡯࡭ࡨࡥࡵࡳ࡮ࠪ๶")], bstack111111l1l_opy_(session), bstack1l111l11_opy_(session[bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡳࡵࡣࡷࡹࡸ࠭๷")]),
    bstack1l111l11_opy_(session[bstack1ll1lll_opy_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨ๸")]),
    bstack1l1ll11l_opy_(session[bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࠪ๹")] or session[bstack1ll1lll_opy_ (u"ࠪࡨࡪࡼࡩࡤࡧࠪ๺")] or bstack1ll1lll_opy_ (u"ࠫࠬ๻")) + bstack1ll1lll_opy_ (u"ࠧࠦࠢ๼") + (session[bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ๽")] or bstack1ll1lll_opy_ (u"ࠧࠨ๾")),
    session[bstack1ll1lll_opy_ (u"ࠨࡱࡶࠫ๿")] + bstack1ll1lll_opy_ (u"ࠤࠣࠦ຀") + session[bstack1ll1lll_opy_ (u"ࠪࡳࡸࡥࡶࡦࡴࡶ࡭ࡴࡴࠧກ")], session[bstack1ll1lll_opy_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭ຂ")] or bstack1ll1lll_opy_ (u"ࠬ࠭຃"),
    session[bstack1ll1lll_opy_ (u"࠭ࡣࡳࡧࡤࡸࡪࡪ࡟ࡢࡶࠪຄ")] if session[bstack1ll1lll_opy_ (u"ࠧࡤࡴࡨࡥࡹ࡫ࡤࡠࡣࡷࠫ຅")] else bstack1ll1lll_opy_ (u"ࠨࠩຆ"))
@measure(event_name=EVENTS.bstack1l11ll111_opy_, stage=STAGE.bstack111lll1l11_opy_, bstack11lllll111_opy_=bstack1lll11111l_opy_)
def bstack1l1l1ll1ll_opy_(sessions, bstack1l1l11ll11_opy_):
  try:
    bstack11ll11ll_opy_ = bstack1ll1lll_opy_ (u"ࠤࠥງ")
    if not os.path.exists(bstack1ll111lll1_opy_):
      os.mkdir(bstack1ll111lll1_opy_)
    with open(os.path.join(os.path.dirname(os.path.realpath(__file__)), bstack1ll1lll_opy_ (u"ࠪࡥࡸࡹࡥࡵࡵ࠲ࡶࡪࡶ࡯ࡳࡶ࠱࡬ࡹࡳ࡬ࠨຈ")), bstack1ll1lll_opy_ (u"ࠫࡷ࠭ຉ")) as f:
      bstack11ll11ll_opy_ = f.read()
    bstack11ll11ll_opy_ = bstack11ll11ll_opy_.replace(bstack1ll1lll_opy_ (u"ࠬࢁࠥࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡅࡒ࡙ࡓ࡚ࠥࡾࠩຊ"), str(len(sessions)))
    bstack11ll11ll_opy_ = bstack11ll11ll_opy_.replace(bstack1ll1lll_opy_ (u"࠭ࡻࠦࡄࡘࡍࡑࡊ࡟ࡖࡔࡏࠩࢂ࠭຋"), bstack1l1l11ll11_opy_)
    bstack11ll11ll_opy_ = bstack11ll11ll_opy_.replace(bstack1ll1lll_opy_ (u"ࠧࡼࠧࡅ࡙ࡎࡒࡄࡠࡐࡄࡑࡊࠫࡽࠨຌ"),
                                              sessions[0].get(bstack1ll1lll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪ࡟࡯ࡣࡰࡩࠬຍ")) if sessions[0] else bstack1ll1lll_opy_ (u"ࠩࠪຎ"))
    with open(os.path.join(bstack1ll111lll1_opy_, bstack1ll1lll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠯ࡵࡩࡵࡵࡲࡵ࠰࡫ࡸࡲࡲࠧຏ")), bstack1ll1lll_opy_ (u"ࠫࡼ࠭ຐ")) as stream:
      stream.write(bstack11ll11ll_opy_.split(bstack1ll1lll_opy_ (u"ࠬࢁࠥࡔࡇࡖࡗࡎࡕࡎࡔࡡࡇࡅ࡙ࡇࠥࡾࠩຑ"))[0])
      for session in sessions:
        stream.write(bstack11llll111_opy_(session))
      stream.write(bstack11ll11ll_opy_.split(bstack1ll1lll_opy_ (u"࠭ࡻࠦࡕࡈࡗࡘࡏࡏࡏࡕࡢࡈࡆ࡚ࡁࠦࡿࠪຒ"))[1])
    logger.info(bstack1ll1lll_opy_ (u"ࠧࡈࡧࡱࡩࡷࡧࡴࡦࡦࠣࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠢࡥࡹ࡮ࡲࡤࠡࡣࡵࡸ࡮࡬ࡡࡤࡶࡶࠤࡦࡺࠠࡼࡿࠪຓ").format(bstack1ll111lll1_opy_));
  except Exception as e:
    logger.debug(bstack11l111ll_opy_.format(str(e)))
def bstack11ll111111_opy_(hashed_id):
  global CONFIG
  try:
    bstack11l1lll11_opy_ = datetime.datetime.now()
    host = bstack1ll1lll_opy_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡴ࡮࠳ࡣ࡭ࡱࡸࡨ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡨࡵ࡭ࠨດ") if bstack1ll1lll_opy_ (u"ࠩࡤࡴࡵ࠭ຕ") in CONFIG else bstack1ll1lll_opy_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡶࡩ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡤࡱࡰࠫຖ")
    user = CONFIG[bstack1ll1lll_opy_ (u"ࠫࡺࡹࡥࡳࡐࡤࡱࡪ࠭ທ")]
    key = CONFIG[bstack1ll1lll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨຘ")]
    bstack1l1ll1lll_opy_ = bstack1ll1lll_opy_ (u"࠭ࡡࡱࡲ࠰ࡥࡺࡺ࡯࡮ࡣࡷࡩࠬນ") if bstack1ll1lll_opy_ (u"ࠧࡢࡲࡳࠫບ") in CONFIG else (bstack1ll1lll_opy_ (u"ࠨࡶࡸࡶࡧࡵࡳࡤࡣ࡯ࡩࠬປ") if CONFIG.get(bstack1ll1lll_opy_ (u"ࠩࡷࡹࡷࡨ࡯ࡴࡥࡤࡰࡪ࠭ຜ")) else bstack1ll1lll_opy_ (u"ࠪࡥࡺࡺ࡯࡮ࡣࡷࡩࠬຝ"))
    host = bstack1l1111l11l_opy_(cli.config, [bstack1ll1lll_opy_ (u"ࠦࡦࡶࡩࡴࠤພ"), bstack1ll1lll_opy_ (u"ࠧࡧࡰࡱࡃࡸࡸࡴࡳࡡࡵࡧࠥຟ"), bstack1ll1lll_opy_ (u"ࠨࡡࡱ࡫ࠥຠ")], host) if bstack1ll1lll_opy_ (u"ࠧࡢࡲࡳࠫມ") in CONFIG else bstack1l1111l11l_opy_(cli.config, [bstack1ll1lll_opy_ (u"ࠣࡣࡳ࡭ࡸࠨຢ"), bstack1ll1lll_opy_ (u"ࠤࡤࡹࡹࡵ࡭ࡢࡶࡨࠦຣ"), bstack1ll1lll_opy_ (u"ࠥࡥࡵ࡯ࠢ຤")], host)
    url = bstack1ll1lll_opy_ (u"ࠫࢀࢃ࠯ࡼࡿ࠲ࡦࡺ࡯࡬ࡥࡵ࠲ࡿࢂ࠵ࡳࡦࡵࡶ࡭ࡴࡴࡳ࠯࡬ࡶࡳࡳ࠭ລ").format(host, bstack1l1ll1lll_opy_, hashed_id)
    headers = {
      bstack1ll1lll_opy_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡴࡺࡲࡨࠫ຦"): bstack1ll1lll_opy_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩວ"),
    }
    proxies = bstack1l111l1111_opy_(CONFIG, url)
    response = requests.get(url, headers=headers, proxies=proxies, auth=(user, key))
    if response.json():
      cli.bstack1ll1l111l_opy_(bstack1ll1lll_opy_ (u"ࠢࡩࡶࡷࡴ࠿࡭ࡥࡵࡡࡶࡩࡸࡹࡩࡰࡰࡶࡣࡱ࡯ࡳࡵࠤຨ"), datetime.datetime.now() - bstack11l1lll11_opy_)
      return list(map(lambda session: session[bstack1ll1lll_opy_ (u"ࠨࡣࡸࡸࡴࡳࡡࡵ࡫ࡲࡲࡤࡹࡥࡴࡵ࡬ࡳࡳ࠭ຩ")], response.json()))
  except Exception as e:
    logger.debug(bstack1ll1l11ll1_opy_.format(str(e)))
@measure(event_name=EVENTS.bstack1ll111111_opy_, stage=STAGE.bstack111lll1l11_opy_, bstack11lllll111_opy_=bstack1lll11111l_opy_)
def get_build_link():
  global CONFIG
  global bstack1l1l1l11_opy_
  try:
    if bstack1ll1lll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬສ") in CONFIG:
      bstack11l1lll11_opy_ = datetime.datetime.now()
      host = bstack1ll1lll_opy_ (u"ࠪࡥࡵ࡯࠭ࡤ࡮ࡲࡹࡩ࠭ຫ") if bstack1ll1lll_opy_ (u"ࠫࡦࡶࡰࠨຬ") in CONFIG else bstack1ll1lll_opy_ (u"ࠬࡧࡰࡪࠩອ")
      user = CONFIG[bstack1ll1lll_opy_ (u"࠭ࡵࡴࡧࡵࡒࡦࡳࡥࠨຮ")]
      key = CONFIG[bstack1ll1lll_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡋࡦࡻࠪຯ")]
      bstack1l1ll1lll_opy_ = bstack1ll1lll_opy_ (u"ࠨࡣࡳࡴ࠲ࡧࡵࡵࡱࡰࡥࡹ࡫ࠧະ") if bstack1ll1lll_opy_ (u"ࠩࡤࡴࡵ࠭ັ") in CONFIG else bstack1ll1lll_opy_ (u"ࠪࡥࡺࡺ࡯࡮ࡣࡷࡩࠬາ")
      url = bstack1ll1lll_opy_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࢁࡽ࠻ࡽࢀࡄࢀࢃ࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡣࡰ࡯࠲ࡿࢂ࠵ࡢࡶ࡫࡯ࡨࡸ࠴ࡪࡴࡱࡱࠫຳ").format(user, key, host, bstack1l1ll1lll_opy_)
      if cli.is_enabled(CONFIG):
        bstack1l1l11ll11_opy_, hashed_id = cli.bstack1ll11lllll_opy_()
        logger.info(bstack1l11111ll1_opy_.format(bstack1l1l11ll11_opy_))
        return [hashed_id, bstack1l1l11ll11_opy_]
      else:
        headers = {
          bstack1ll1lll_opy_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡴࡺࡲࡨࠫິ"): bstack1ll1lll_opy_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩີ"),
        }
        if bstack1ll1lll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩຶ") in CONFIG:
          params = {bstack1ll1lll_opy_ (u"ࠨࡰࡤࡱࡪ࠭ື"): CONFIG[bstack1ll1lll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩຸࠬ")], bstack1ll1lll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡡ࡬ࡨࡪࡴࡴࡪࡨ࡬ࡩࡷູ࠭"): CONFIG[bstack1ll1lll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ຺࠭")]}
        else:
          params = {bstack1ll1lll_opy_ (u"ࠬࡴࡡ࡮ࡧࠪົ"): CONFIG[bstack1ll1lll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠩຼ")]}
        proxies = bstack1l111l1111_opy_(CONFIG, url)
        response = requests.get(url, params=params, headers=headers, proxies=proxies)
        if response.json():
          bstack1llll1llll_opy_ = response.json()[0][bstack1ll1lll_opy_ (u"ࠧࡢࡷࡷࡳࡲࡧࡴࡪࡱࡱࡣࡧࡻࡩ࡭ࡦࠪຽ")]
          if bstack1llll1llll_opy_:
            bstack1l1l11ll11_opy_ = bstack1llll1llll_opy_[bstack1ll1lll_opy_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡠࡷࡵࡰࠬ຾")].split(bstack1ll1lll_opy_ (u"ࠩࡳࡹࡧࡲࡩࡤ࠯ࡥࡹ࡮ࡲࡤࠨ຿"))[0] + bstack1ll1lll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡵ࠲ࠫເ") + bstack1llll1llll_opy_[
              bstack1ll1lll_opy_ (u"ࠫ࡭ࡧࡳࡩࡧࡧࡣ࡮ࡪࠧແ")]
            logger.info(bstack1l11111ll1_opy_.format(bstack1l1l11ll11_opy_))
            bstack1l1l1l11_opy_ = bstack1llll1llll_opy_[bstack1ll1lll_opy_ (u"ࠬ࡮ࡡࡴࡪࡨࡨࡤ࡯ࡤࠨໂ")]
            bstack1l1111lll_opy_ = CONFIG[bstack1ll1lll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠩໃ")]
            if bstack1ll1lll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩໄ") in CONFIG:
              bstack1l1111lll_opy_ += bstack1ll1lll_opy_ (u"ࠨࠢࠪ໅") + CONFIG[bstack1ll1lll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫໆ")]
            if bstack1l1111lll_opy_ != bstack1llll1llll_opy_[bstack1ll1lll_opy_ (u"ࠪࡲࡦࡳࡥࠨ໇")]:
              logger.debug(bstack11l11llll_opy_.format(bstack1llll1llll_opy_[bstack1ll1lll_opy_ (u"ࠫࡳࡧ࡭ࡦ່ࠩ")], bstack1l1111lll_opy_))
            cli.bstack1ll1l111l_opy_(bstack1ll1lll_opy_ (u"ࠧ࡮ࡴࡵࡲ࠽࡫ࡪࡺ࡟ࡣࡷ࡬ࡰࡩࡥ࡬ࡪࡰ࡮້ࠦ"), datetime.datetime.now() - bstack11l1lll11_opy_)
            return [bstack1llll1llll_opy_[bstack1ll1lll_opy_ (u"࠭ࡨࡢࡵ࡫ࡩࡩࡥࡩࡥ໊ࠩ")], bstack1l1l11ll11_opy_]
    else:
      logger.warn(bstack111l1l1ll_opy_)
  except Exception as e:
    logger.debug(bstack11l111111_opy_.format(str(e)))
  return [None, None]
def bstack1ll11l1111_opy_(url, bstack1111lllll_opy_=False):
  global CONFIG
  global bstack1l1l111ll_opy_
  if not bstack1l1l111ll_opy_:
    hostname = bstack1l111l11ll_opy_(url)
    is_private = bstack1lll1l1l1_opy_(hostname)
    if (bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯໋ࠫ") in CONFIG and not bstack1ll111ll11_opy_(CONFIG[bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡌࡰࡥࡤࡰࠬ໌")])) and (is_private or bstack1111lllll_opy_):
      bstack1l1l111ll_opy_ = hostname
def bstack1l111l11ll_opy_(url):
  return urlparse(url).hostname
def bstack1lll1l1l1_opy_(hostname):
  for bstack1l111lll1_opy_ in bstack1l1ll1l1l1_opy_:
    regex = re.compile(bstack1l111lll1_opy_)
    if regex.match(hostname):
      return True
  return False
def bstack11l111l111_opy_(bstack111l1ll1_opy_):
  return True if bstack111l1ll1_opy_ in threading.current_thread().__dict__.keys() else False
@measure(event_name=EVENTS.bstack1l1111l111_opy_, stage=STAGE.bstack111lll1l11_opy_, bstack11lllll111_opy_=bstack1lll11111l_opy_)
def getAccessibilityResults(driver):
  global CONFIG
  global bstack1lllll1ll1_opy_
  bstack11l11l111l_opy_ = not (bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠩ࡬ࡷࡆ࠷࠱ࡺࡖࡨࡷࡹ࠭ໍ"), None) and bstack11l1l1lll_opy_(
          threading.current_thread(), bstack1ll1lll_opy_ (u"ࠪࡥ࠶࠷ࡹࡑ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩ໎"), None))
  bstack1ll1l1l1l_opy_ = getattr(driver, bstack1ll1lll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡅ࠶࠷ࡹࡔࡪࡲࡹࡱࡪࡓࡤࡣࡱࠫ໏"), None) != True
  bstack1l11l11l1_opy_ = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠬ࡯ࡳࡂࡲࡳࡅ࠶࠷ࡹࡕࡧࡶࡸࠬ໐"), None) and bstack11l1l1lll_opy_(
          threading.current_thread(), bstack1ll1lll_opy_ (u"࠭ࡡࡱࡲࡄ࠵࠶ࡿࡐ࡭ࡣࡷࡪࡴࡸ࡭ࠨ໑"), None)
  if bstack1l11l11l1_opy_:
    if not bstack11l1l1ll_opy_():
      logger.warning(bstack1ll1lll_opy_ (u"ࠢࡏࡱࡷࠤࡦࡴࠠࡂࡲࡳࠤࡆࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠡࡵࡨࡷࡸ࡯࡯࡯࠮ࠣࡧࡦࡴ࡮ࡰࡶࠣࡶࡪࡺࡲࡪࡧࡹࡩࠥࡇࡰࡱࠢࡄࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡵࡩࡸࡻ࡬ࡵࡵ࠱ࠦ໒"))
      return {}
    logger.debug(bstack1ll1lll_opy_ (u"ࠨࡒࡨࡶ࡫ࡵࡲ࡮࡫ࡱ࡫ࠥࡹࡣࡢࡰࠣࡦࡪ࡬࡯ࡳࡧࠣ࡫ࡪࡺࡴࡪࡰࡪࠤࡷ࡫ࡳࡶ࡮ࡷࡷࠬ໓"))
    logger.debug(perform_scan(driver, driver_command=bstack1ll1lll_opy_ (u"ࠩࡨࡼࡪࡩࡵࡵࡧࡖࡧࡷ࡯ࡰࡵࠩ໔")))
    results = bstack11ll1l1l1_opy_(bstack1ll1lll_opy_ (u"ࠥࡶࡪࡹࡵ࡭ࡶࡶࠦ໕"))
    if results is not None and results.get(bstack1ll1lll_opy_ (u"ࠦ࡮ࡹࡳࡶࡧࡶࠦ໖")) is not None:
        return results[bstack1ll1lll_opy_ (u"ࠧ࡯ࡳࡴࡷࡨࡷࠧ໗")]
    logger.error(bstack1ll1lll_opy_ (u"ࠨࡎࡰࠢࡄࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡕࡩࡸࡻ࡬ࡵࡵࠣࡻࡪࡸࡥࠡࡨࡲࡹࡳࡪ࠮ࠣ໘"))
    return []
  if not bstack1l11l1l1_opy_.bstack11l1111lll_opy_(CONFIG, bstack1lllll1ll1_opy_) or (bstack1ll1l1l1l_opy_ and bstack11l11l111l_opy_):
    logger.warning(bstack1ll1lll_opy_ (u"ࠢࡏࡱࡷࠤࡦࡴࠠࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠤࡸ࡫ࡳࡴ࡫ࡲࡲ࠱ࠦࡣࡢࡰࡱࡳࡹࠦࡲࡦࡶࡵ࡭ࡪࡼࡥࠡࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡴࡨࡷࡺࡲࡴࡴ࠰ࠥ໙"))
    return {}
  try:
    logger.debug(bstack1ll1lll_opy_ (u"ࠨࡒࡨࡶ࡫ࡵࡲ࡮࡫ࡱ࡫ࠥࡹࡣࡢࡰࠣࡦࡪ࡬࡯ࡳࡧࠣ࡫ࡪࡺࡴࡪࡰࡪࠤࡷ࡫ࡳࡶ࡮ࡷࡷࠬ໚"))
    logger.debug(perform_scan(driver))
    results = driver.execute_async_script(bstack1l11llll_opy_.bstack1l11l1l11_opy_)
    return results
  except Exception:
    logger.error(bstack1ll1lll_opy_ (u"ࠤࡑࡳࠥࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡸࡥࡴࡷ࡯ࡸࡸࠦࡷࡦࡴࡨࠤ࡫ࡵࡵ࡯ࡦ࠱ࠦ໛"))
    return {}
@measure(event_name=EVENTS.bstack1ll1l1ll_opy_, stage=STAGE.bstack111lll1l11_opy_, bstack11lllll111_opy_=bstack1lll11111l_opy_)
def getAccessibilityResultsSummary(driver):
  global CONFIG
  global bstack1lllll1ll1_opy_
  bstack11l11l111l_opy_ = not (bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠪ࡭ࡸࡇ࠱࠲ࡻࡗࡩࡸࡺࠧໜ"), None) and bstack11l1l1lll_opy_(
          threading.current_thread(), bstack1ll1lll_opy_ (u"ࠫࡦ࠷࠱ࡺࡒ࡯ࡥࡹ࡬࡯ࡳ࡯ࠪໝ"), None))
  bstack1ll1l1l1l_opy_ = getattr(driver, bstack1ll1lll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯ࡆ࠷࠱ࡺࡕ࡫ࡳࡺࡲࡤࡔࡥࡤࡲࠬໞ"), None) != True
  bstack1l11l11l1_opy_ = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"࠭ࡩࡴࡃࡳࡴࡆ࠷࠱ࡺࡖࡨࡷࡹ࠭ໟ"), None) and bstack11l1l1lll_opy_(
          threading.current_thread(), bstack1ll1lll_opy_ (u"ࠧࡢࡲࡳࡅ࠶࠷ࡹࡑ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩ໠"), None)
  if bstack1l11l11l1_opy_:
    if not bstack11l1l1ll_opy_():
      logger.warning(bstack1ll1lll_opy_ (u"ࠣࡐࡲࡸࠥࡧ࡮ࠡࡃࡳࡴࠥࡇࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡇࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࠢࡶࡩࡸࡹࡩࡰࡰ࠯ࠤࡨࡧ࡮࡯ࡱࡷࠤࡷ࡫ࡴࡳ࡫ࡨࡺࡪࠦࡁࡱࡲࠣࡅࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡶࡪࡹࡵ࡭ࡶࡶࠤࡸࡻ࡭࡮ࡣࡵࡽ࠳ࠨ໡"))
      return {}
    logger.debug(bstack1ll1lll_opy_ (u"ࠩࡓࡩࡷ࡬࡯ࡳ࡯࡬ࡲ࡬ࠦࡳࡤࡣࡱࠤࡧ࡫ࡦࡰࡴࡨࠤ࡬࡫ࡴࡵ࡫ࡱ࡫ࠥࡸࡥࡴࡷ࡯ࡸࡸࠦࡳࡶ࡯ࡰࡥࡷࡿࠧ໢"))
    logger.debug(perform_scan(driver, driver_command=bstack1ll1lll_opy_ (u"ࠪࡩࡽ࡫ࡣࡶࡶࡨࡗࡨࡸࡩࡱࡶࠪ໣")))
    results = bstack11ll1l1l1_opy_(bstack1ll1lll_opy_ (u"ࠦࡷ࡫ࡳࡶ࡮ࡷࡗࡺࡳ࡭ࡢࡴࡼࠦ໤"))
    if results is not None and results.get(bstack1ll1lll_opy_ (u"ࠧࡹࡵ࡮࡯ࡤࡶࡾࠨ໥")) is not None:
        return results[bstack1ll1lll_opy_ (u"ࠨࡳࡶ࡯ࡰࡥࡷࡿࠢ໦")]
    logger.error(bstack1ll1lll_opy_ (u"ࠢࡏࡱࠣࡅࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡖࡪࡹࡵ࡭ࡶࡶࠤࡘࡻ࡭࡮ࡣࡵࡽࠥࡽࡡࡴࠢࡩࡳࡺࡴࡤ࠯ࠤ໧"))
    return {}
  if not bstack1l11l1l1_opy_.bstack11l1111lll_opy_(CONFIG, bstack1lllll1ll1_opy_) or (bstack1ll1l1l1l_opy_ and bstack11l11l111l_opy_):
    logger.warning(bstack1ll1lll_opy_ (u"ࠣࡐࡲࡸࠥࡧ࡮ࠡࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡃࡸࡸࡴࡳࡡࡵ࡫ࡲࡲࠥࡹࡥࡴࡵ࡬ࡳࡳ࠲ࠠࡤࡣࡱࡲࡴࡺࠠࡳࡧࡷࡶ࡮࡫ࡶࡦࠢࡄࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡵࡩࡸࡻ࡬ࡵࡵࠣࡷࡺࡳ࡭ࡢࡴࡼ࠲ࠧ໨"))
    return {}
  try:
    logger.debug(bstack1ll1lll_opy_ (u"ࠩࡓࡩࡷ࡬࡯ࡳ࡯࡬ࡲ࡬ࠦࡳࡤࡣࡱࠤࡧ࡫ࡦࡰࡴࡨࠤ࡬࡫ࡴࡵ࡫ࡱ࡫ࠥࡸࡥࡴࡷ࡯ࡸࡸࠦࡳࡶ࡯ࡰࡥࡷࡿࠧ໩"))
    logger.debug(perform_scan(driver))
    bstack1111ll11l_opy_ = driver.execute_async_script(bstack1l11llll_opy_.bstack11ll11l11l_opy_)
    return bstack1111ll11l_opy_
  except Exception:
    logger.error(bstack1ll1lll_opy_ (u"ࠥࡒࡴࠦࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡳࡶ࡯ࡰࡥࡷࡿࠠࡸࡣࡶࠤ࡫ࡵࡵ࡯ࡦ࠱ࠦ໪"))
    return {}
def bstack11l1l1ll_opy_():
  global CONFIG
  global bstack1lllll1ll1_opy_
  bstack111l111l_opy_ = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠫ࡮ࡹࡁࡱࡲࡄ࠵࠶ࡿࡔࡦࡵࡷࠫ໫"), None) and bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠬࡧࡰࡱࡃ࠴࠵ࡾࡖ࡬ࡢࡶࡩࡳࡷࡳࠧ໬"), None)
  if not bstack1l11l1l1_opy_.bstack11l1111lll_opy_(CONFIG, bstack1lllll1ll1_opy_) or not bstack111l111l_opy_:
        logger.warning(bstack1ll1lll_opy_ (u"ࠨࡎࡰࡶࠣࡥࡳࠦࡁࡱࡲࠣࡅࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡅࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࠠࡴࡧࡶࡷ࡮ࡵ࡮࠭ࠢࡦࡥࡳࡴ࡯ࡵࠢࡵࡩࡹࡸࡩࡦࡸࡨࠤࡷ࡫ࡳࡶ࡮ࡷࡷ࠳ࠨ໭"))
        return False
  return True
def bstack11ll1l1l1_opy_(bstack11l111ll1_opy_):
    bstack11l111l1l1_opy_ = bstack1l111l111l_opy_.current_test_uuid() if bstack1l111l111l_opy_.current_test_uuid() else bstack11l11ll1l1_opy_.current_hook_uuid()
    with ThreadPoolExecutor() as executor:
        future = executor.submit(bstack11lll1l11l_opy_(bstack11l111l1l1_opy_, bstack11l111ll1_opy_))
        try:
            return future.result(timeout=bstack1111l111_opy_)
        except TimeoutError:
            logger.error(bstack1ll1lll_opy_ (u"ࠢࡕ࡫ࡰࡩࡴࡻࡴࠡࡣࡩࡸࡪࡸࠠࡼࡿࡶࠤࡼ࡮ࡩ࡭ࡧࠣࡪࡪࡺࡣࡩ࡫ࡱ࡫ࠥࡇࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡘࡥࡴࡷ࡯ࡸࡸࠨ໮").format(bstack1111l111_opy_))
        except Exception as ex:
            logger.debug(bstack1ll1lll_opy_ (u"ࠣࡇࡵࡶࡴࡸࠠࡳࡧࡷࡶ࡮࡫ࡶࡪࡰࡪࠤࡆࡶࡰࠡࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡃࡸࡸࡴࡳࡡࡵ࡫ࡲࡲࠥࢁࡽ࠯ࠢࡈࡶࡷࡵࡲࠡ࠯ࠣࡿࢂࠨ໯").format(bstack11l111ll1_opy_, str(ex)))
    return {}
@measure(event_name=EVENTS.bstack1l11111111_opy_, stage=STAGE.bstack111lll1l11_opy_, bstack11lllll111_opy_=bstack1lll11111l_opy_)
def perform_scan(driver, *args, **kwargs):
  global CONFIG
  global bstack1lllll1ll1_opy_
  bstack11l11l111l_opy_ = not (bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠩ࡬ࡷࡆ࠷࠱ࡺࡖࡨࡷࡹ࠭໰"), None) and bstack11l1l1lll_opy_(
          threading.current_thread(), bstack1ll1lll_opy_ (u"ࠪࡥ࠶࠷ࡹࡑ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩ໱"), None))
  bstack1ll11l1l11_opy_ = not (bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠫ࡮ࡹࡁࡱࡲࡄ࠵࠶ࡿࡔࡦࡵࡷࠫ໲"), None) and bstack11l1l1lll_opy_(
          threading.current_thread(), bstack1ll1lll_opy_ (u"ࠬࡧࡰࡱࡃ࠴࠵ࡾࡖ࡬ࡢࡶࡩࡳࡷࡳࠧ໳"), None))
  bstack1ll1l1l1l_opy_ = getattr(driver, bstack1ll1lll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡇ࠱࠲ࡻࡖ࡬ࡴࡻ࡬ࡥࡕࡦࡥࡳ࠭໴"), None) != True
  if not bstack1l11l1l1_opy_.bstack11l1111lll_opy_(CONFIG, bstack1lllll1ll1_opy_) or (bstack1ll1l1l1l_opy_ and bstack11l11l111l_opy_ and bstack1ll11l1l11_opy_):
    logger.warning(bstack1ll1lll_opy_ (u"ࠢࡏࡱࡷࠤࡦࡴࠠࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠤࡸ࡫ࡳࡴ࡫ࡲࡲ࠱ࠦࡣࡢࡰࡱࡳࡹࠦࡲࡶࡰࠣࡅࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡷࡨࡧ࡮࠯ࠤ໵"))
    return {}
  try:
    bstack11ll1llll_opy_ = bstack1ll1lll_opy_ (u"ࠨࡣࡳࡴࠬ໶") in CONFIG and CONFIG.get(bstack1ll1lll_opy_ (u"ࠩࡤࡴࡵ࠭໷"), bstack1ll1lll_opy_ (u"ࠪࠫ໸"))
    session_id = getattr(driver, bstack1ll1lll_opy_ (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࡤ࡯ࡤࠨ໹"), None)
    if not session_id:
      logger.warning(bstack1ll1lll_opy_ (u"ࠧࡔ࡯ࠡࡵࡨࡷࡸ࡯࡯࡯ࠢࡌࡈࠥ࡬࡯ࡶࡰࡧࠤ࡫ࡵࡲࠡࡦࡵ࡭ࡻ࡫ࡲࠣ໺"))
      return {bstack1ll1lll_opy_ (u"ࠨࡥࡳࡴࡲࡶࠧ໻"): bstack1ll1lll_opy_ (u"ࠢࡏࡱࠣࡷࡪࡹࡳࡪࡱࡱࠤࡎࡊࠠࡧࡱࡸࡲࡩࠨ໼")}
    if bstack11ll1llll_opy_:
      try:
        bstack111111ll1_opy_ = {
              bstack1ll1lll_opy_ (u"ࠨࡶ࡫ࡎࡼࡺࡔࡰ࡭ࡨࡲࠬ໽"): os.environ.get(bstack1ll1lll_opy_ (u"ࠩࡅࡗࡤࡇ࠱࠲࡛ࡢࡎ࡜࡚ࠧ໾"), os.environ.get(bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚ࡈࡖࡄࡢࡎ࡜࡚ࠧ໿"), bstack1ll1lll_opy_ (u"ࠫࠬༀ"))),
              bstack1ll1lll_opy_ (u"ࠬࡺࡨࡕࡧࡶࡸࡗࡻ࡮ࡖࡷ࡬ࡨࠬ༁"): bstack1l111l111l_opy_.current_test_uuid() if bstack1l111l111l_opy_.current_test_uuid() else bstack11l11ll1l1_opy_.current_hook_uuid(),
              bstack1ll1lll_opy_ (u"࠭ࡡࡶࡶ࡫ࡌࡪࡧࡤࡦࡴࠪ༂"): os.environ.get(bstack1ll1lll_opy_ (u"ࠧࡃࡕࡢࡅ࠶࠷࡙ࡠࡌ࡚ࡘࠬ༃")),
              bstack1ll1lll_opy_ (u"ࠨࡵࡦࡥࡳ࡚ࡩ࡮ࡧࡶࡸࡦࡳࡰࠨ༄"): str(int(datetime.datetime.now().timestamp() * 1000)),
              bstack1ll1lll_opy_ (u"ࠩࡷ࡬ࡇࡻࡩ࡭ࡦࡘࡹ࡮ࡪࠧ༅"): os.environ.get(bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚ࡈࡖࡄࡢ࡙࡚ࡏࡄࠨ༆"), bstack1ll1lll_opy_ (u"ࠫࠬ༇")),
              bstack1ll1lll_opy_ (u"ࠬࡳࡥࡵࡪࡲࡨࠬ༈"): kwargs.get(bstack1ll1lll_opy_ (u"࠭ࡤࡳ࡫ࡹࡩࡷࡥࡣࡰ࡯ࡰࡥࡳࡪࠧ༉"), None) or bstack1ll1lll_opy_ (u"ࠧࠨ༊")
          }
        if not hasattr(thread_local, bstack1ll1lll_opy_ (u"ࠨࡤࡤࡷࡪࡥࡡࡱࡲࡢࡥ࠶࠷ࡹࡠࡵࡦࡶ࡮ࡶࡴࠨ་")):
            scripts = {bstack1ll1lll_opy_ (u"ࠩࡶࡧࡦࡴࠧ༌"): bstack1l11llll_opy_.perform_scan}
            thread_local.base_app_a11y_script = scripts
        bstack11111ll11_opy_ = copy.deepcopy(thread_local.base_app_a11y_script)
        bstack11111ll11_opy_[bstack1ll1lll_opy_ (u"ࠪࡷࡨࡧ࡮ࠨ།")] = bstack11111ll11_opy_[bstack1ll1lll_opy_ (u"ࠫࡸࡩࡡ࡯ࠩ༎")] % json.dumps(bstack111111ll1_opy_)
        bstack1l11llll_opy_.bstack11l1l11lll_opy_(bstack11111ll11_opy_)
        bstack1l11llll_opy_.store()
        bstack111lllllll_opy_ = driver.execute_script(bstack1l11llll_opy_.perform_scan)
      except Exception as bstack1l1l11l11_opy_:
        logger.info(bstack1ll1lll_opy_ (u"ࠧࡇࡰࡱ࡫ࡸࡱࠥࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡹࡣࡢࡰࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠧ༏") + str(bstack1l1l11l11_opy_))
        bstack111lllllll_opy_ = {bstack1ll1lll_opy_ (u"ࠨࡥࡳࡴࡲࡶࠧ༐"): str(bstack1l1l11l11_opy_)}
    else:
      bstack111lllllll_opy_ = driver.execute_async_script(bstack1l11llll_opy_.perform_scan, {bstack1ll1lll_opy_ (u"ࠧ࡮ࡧࡷ࡬ࡴࡪࠧ༑"): kwargs.get(bstack1ll1lll_opy_ (u"ࠨࡦࡵ࡭ࡻ࡫ࡲࡠࡥࡲࡱࡲࡧ࡮ࡥࠩ༒"), None) or bstack1ll1lll_opy_ (u"ࠩࠪ༓")})
    return bstack111lllllll_opy_
  except Exception as err:
    logger.error(bstack1ll1lll_opy_ (u"࡙ࠥࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡲࡶࡰࠣࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡷࡨࡧ࡮࠯ࠢࡾࢁࠧ༔").format(str(err)))
    return {}