# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import os
class RobotHandler():
    def __init__(self, args, logger, bstack1111l111ll_opy_, bstack1111l1l111_opy_):
        self.args = args
        self.logger = logger
        self.bstack1111l111ll_opy_ = bstack1111l111ll_opy_
        self.bstack1111l1l111_opy_ = bstack1111l1l111_opy_
    @staticmethod
    def version():
        import robot
        return robot.__version__
    @staticmethod
    def bstack111l11l11l_opy_(bstack11111111l1_opy_):
        bstack11111111ll_opy_ = []
        if bstack11111111l1_opy_:
            tokens = str(os.path.basename(bstack11111111l1_opy_)).split(bstack1ll1lll_opy_ (u"ࠨ࡟ࠣ႟"))
            camelcase_name = bstack1ll1lll_opy_ (u"ࠢࠡࠤႠ").join(t.title() for t in tokens)
            suite_name, bstack111111111l_opy_ = os.path.splitext(camelcase_name)
            bstack11111111ll_opy_.append(suite_name)
        return bstack11111111ll_opy_
    @staticmethod
    def bstack1111111l11_opy_(typename):
        if bstack1ll1lll_opy_ (u"ࠣࡃࡶࡷࡪࡸࡴࡪࡱࡱࠦႡ") in typename:
            return bstack1ll1lll_opy_ (u"ࠤࡄࡷࡸ࡫ࡲࡵ࡫ࡲࡲࡊࡸࡲࡰࡴࠥႢ")
        return bstack1ll1lll_opy_ (u"࡙ࠥࡳ࡮ࡡ࡯ࡦ࡯ࡩࡩࡋࡲࡳࡱࡵࠦႣ")