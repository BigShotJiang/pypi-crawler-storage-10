# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import builtins
import logging
class bstack111lll1111_opy_:
    def __init__(self, handler):
        self._11l1lllll1l_opy_ = builtins.print
        self.handler = handler
        self._started = False
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        self._11l1lllllll_opy_ = {
            level: getattr(self.logger, level)
            for level in [bstack1ll1lll_opy_ (u"ࠪ࡭ࡳ࡬࡯ࠨវ"), bstack1ll1lll_opy_ (u"ࠫࡩ࡫ࡢࡶࡩࠪឝ"), bstack1ll1lll_opy_ (u"ࠬࡽࡡࡳࡰ࡬ࡲ࡬࠭ឞ"), bstack1ll1lll_opy_ (u"࠭ࡥࡳࡴࡲࡶࠬស")]
        }
    def start(self):
        if self._started:
            return
        self._started = True
        builtins.print = self._11l1lllll11_opy_
        self._11ll1111111_opy_()
    def _11l1lllll11_opy_(self, *args, **kwargs):
        self._11l1lllll1l_opy_(*args, **kwargs)
        message = bstack1ll1lll_opy_ (u"ࠧࠡࠩហ").join(map(str, args)) + bstack1ll1lll_opy_ (u"ࠨ࡞ࡱࠫឡ")
        self._log_message(bstack1ll1lll_opy_ (u"ࠩࡌࡒࡋࡕࠧអ"), message)
    def _log_message(self, level, msg, *args, **kwargs):
        if self.handler:
            self.handler({bstack1ll1lll_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩឣ"): level, bstack1ll1lll_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬឤ"): msg})
    def _11ll1111111_opy_(self):
        for level, bstack11l1llllll1_opy_ in self._11l1lllllll_opy_.items():
            setattr(logging, level, self._11l1llll1ll_opy_(level, bstack11l1llllll1_opy_))
    def _11l1llll1ll_opy_(self, level, bstack11l1llllll1_opy_):
        def wrapper(msg, *args, **kwargs):
            bstack11l1llllll1_opy_(msg, *args, **kwargs)
            self._log_message(level.upper(), msg)
        return wrapper
    def reset(self):
        if not self._started:
            return
        self._started = False
        builtins.print = self._11l1lllll1l_opy_
        for level, bstack11l1llllll1_opy_ in self._11l1lllllll_opy_.items():
            setattr(logging, level, bstack11l1llllll1_opy_)