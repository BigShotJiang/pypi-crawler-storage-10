# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import os
from urllib.parse import urlparse
from bstack_utils.config import Config
from bstack_utils.messages import bstack111l11ll1l1_opy_
bstack11l1l11l_opy_ = Config.bstack1l1l111l_opy_()
def bstack1lllllll111l_opy_(url):
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except:
        return False
def bstack1lllllll1111_opy_(bstack1lllllll1l11_opy_, bstack1lllllll1ll1_opy_):
    from pypac import get_pac
    from pypac import PACSession
    from pypac.parser import PACFile
    import socket
    if os.path.isfile(bstack1lllllll1l11_opy_):
        with open(bstack1lllllll1l11_opy_) as f:
            pac = PACFile(f.read())
    elif bstack1lllllll111l_opy_(bstack1lllllll1l11_opy_):
        pac = get_pac(url=bstack1lllllll1l11_opy_)
    else:
        raise Exception(bstack1ll1lll_opy_ (u"ࠧࡑࡣࡦࠤ࡫࡯࡬ࡦࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤࡪࡾࡩࡴࡶ࠽ࠤࢀࢃࠧᾎ").format(bstack1lllllll1l11_opy_))
    session = PACSession(pac)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect((bstack1ll1lll_opy_ (u"ࠣ࠺࠱࠼࠳࠾࠮࠹ࠤᾏ"), 80))
        bstack1lllllll11ll_opy_ = s.getsockname()[0]
        s.close()
    except:
        bstack1lllllll11ll_opy_ = bstack1ll1lll_opy_ (u"ࠩ࠳࠲࠵࠴࠰࠯࠲ࠪᾐ")
    proxy_url = session.get_pac().find_proxy_for_url(bstack1lllllll1ll1_opy_, bstack1lllllll11ll_opy_)
    return proxy_url
def bstack1l1lllllll_opy_(config):
    return bstack1ll1lll_opy_ (u"ࠪ࡬ࡹࡺࡰࡑࡴࡲࡼࡾ࠭ᾑ") in config or bstack1ll1lll_opy_ (u"ࠫ࡭ࡺࡴࡱࡵࡓࡶࡴࡾࡹࠨᾒ") in config
def bstack1ll1111ll1_opy_(config):
    if not bstack1l1lllllll_opy_(config):
        return
    if config.get(bstack1ll1lll_opy_ (u"ࠬ࡮ࡴࡵࡲࡓࡶࡴࡾࡹࠨᾓ")):
        return config.get(bstack1ll1lll_opy_ (u"࠭ࡨࡵࡶࡳࡔࡷࡵࡸࡺࠩᾔ"))
    if config.get(bstack1ll1lll_opy_ (u"ࠧࡩࡶࡷࡴࡸࡖࡲࡰࡺࡼࠫᾕ")):
        return config.get(bstack1ll1lll_opy_ (u"ࠨࡪࡷࡸࡵࡹࡐࡳࡱࡻࡽࠬᾖ"))
def bstack1l111l1111_opy_(config, bstack1lllllll1ll1_opy_):
    proxy = bstack1ll1111ll1_opy_(config)
    proxies = {}
    if config.get(bstack1ll1lll_opy_ (u"ࠩ࡫ࡸࡹࡶࡐࡳࡱࡻࡽࠬᾗ")) or config.get(bstack1ll1lll_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࡒࡵࡳࡽࡿࠧᾘ")):
        if proxy.endswith(bstack1ll1lll_opy_ (u"ࠫ࠳ࡶࡡࡤࠩᾙ")):
            proxies = bstack1l111l1l11_opy_(proxy, bstack1lllllll1ll1_opy_)
        else:
            proxies = {
                bstack1ll1lll_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࠫᾚ"): proxy
            }
    bstack11l1l11l_opy_.bstack111lll111_opy_(bstack1ll1lll_opy_ (u"࠭ࡰࡳࡱࡻࡽࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠭ᾛ"), proxies)
    return proxies
def bstack1l111l1l11_opy_(bstack1lllllll1l11_opy_, bstack1lllllll1ll1_opy_):
    proxies = {}
    global bstack1lllllll11l1_opy_
    if bstack1ll1lll_opy_ (u"ࠧࡑࡃࡆࡣࡕࡘࡏ࡙࡛ࠪᾜ") in globals():
        return bstack1lllllll11l1_opy_
    try:
        proxy = bstack1lllllll1111_opy_(bstack1lllllll1l11_opy_, bstack1lllllll1ll1_opy_)
        if bstack1ll1lll_opy_ (u"ࠣࡆࡌࡖࡊࡉࡔࠣᾝ") in proxy:
            proxies = {}
        elif bstack1ll1lll_opy_ (u"ࠤࡋࡘ࡙ࡖࠢᾞ") in proxy or bstack1ll1lll_opy_ (u"ࠥࡌ࡙࡚ࡐࡔࠤᾟ") in proxy or bstack1ll1lll_opy_ (u"ࠦࡘࡕࡃࡌࡕࠥᾠ") in proxy:
            bstack1lllllll1l1l_opy_ = proxy.split(bstack1ll1lll_opy_ (u"ࠧࠦࠢᾡ"))
            if bstack1ll1lll_opy_ (u"ࠨ࠺࠰࠱ࠥᾢ") in bstack1ll1lll_opy_ (u"ࠢࠣᾣ").join(bstack1lllllll1l1l_opy_[1:]):
                proxies = {
                    bstack1ll1lll_opy_ (u"ࠨࡪࡷࡸࡵࡹࠧᾤ"): bstack1ll1lll_opy_ (u"ࠤࠥᾥ").join(bstack1lllllll1l1l_opy_[1:])
                }
            else:
                proxies = {
                    bstack1ll1lll_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࠩᾦ"): str(bstack1lllllll1l1l_opy_[0]).lower() + bstack1ll1lll_opy_ (u"ࠦ࠿࠵࠯ࠣᾧ") + bstack1ll1lll_opy_ (u"ࠧࠨᾨ").join(bstack1lllllll1l1l_opy_[1:])
                }
        elif bstack1ll1lll_opy_ (u"ࠨࡐࡓࡑ࡛࡝ࠧᾩ") in proxy:
            bstack1lllllll1l1l_opy_ = proxy.split(bstack1ll1lll_opy_ (u"ࠢࠡࠤᾪ"))
            if bstack1ll1lll_opy_ (u"ࠣ࠼࠲࠳ࠧᾫ") in bstack1ll1lll_opy_ (u"ࠤࠥᾬ").join(bstack1lllllll1l1l_opy_[1:]):
                proxies = {
                    bstack1ll1lll_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࠩᾭ"): bstack1ll1lll_opy_ (u"ࠦࠧᾮ").join(bstack1lllllll1l1l_opy_[1:])
                }
            else:
                proxies = {
                    bstack1ll1lll_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࠫᾯ"): bstack1ll1lll_opy_ (u"ࠨࡨࡵࡶࡳ࠾࠴࠵ࠢᾰ") + bstack1ll1lll_opy_ (u"ࠢࠣᾱ").join(bstack1lllllll1l1l_opy_[1:])
                }
        else:
            proxies = {
                bstack1ll1lll_opy_ (u"ࠨࡪࡷࡸࡵࡹࠧᾲ"): proxy
            }
    except Exception as e:
        print(bstack1ll1lll_opy_ (u"ࠤࡶࡳࡲ࡫ࠠࡦࡴࡵࡳࡷࠨᾳ"), bstack111l11ll1l1_opy_.format(bstack1lllllll1l11_opy_, str(e)))
    bstack1lllllll11l1_opy_ = proxies
    return proxies