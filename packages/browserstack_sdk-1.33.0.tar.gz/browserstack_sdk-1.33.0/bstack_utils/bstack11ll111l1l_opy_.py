# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import json
import os
import threading
from bstack_utils.config import Config
from bstack_utils.constants import EVENTS, STAGE
from bstack_utils.helper import bstack11l111111ll_opy_, bstack1l111l11ll_opy_, bstack11l1l1lll_opy_, bstack1lll1l1l1_opy_, \
    bstack11l111ll11l_opy_
from bstack_utils.measure import measure
def bstack1l1111ll11_opy_(bstack1lllll111l1l_opy_):
    for driver in bstack1lllll111l1l_opy_:
        try:
            driver.quit()
        except Exception as e:
            pass
@measure(event_name=EVENTS.bstack1lll1l1l_opy_, stage=STAGE.bstack111lll1l11_opy_)
def bstack1l1lll1ll1_opy_(driver, status, reason=bstack1ll1lll_opy_ (u"ࠪࠫ‹")):
    bstack11l1l11l_opy_ = Config.bstack1l1l111l_opy_()
    if bstack11l1l11l_opy_.bstack1111l11lll_opy_():
        return
    bstack1llll1ll1_opy_ = bstack1l1llll1ll_opy_(bstack1ll1lll_opy_ (u"ࠫࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡔࡶࡤࡸࡺࡹࠧ›"), bstack1ll1lll_opy_ (u"ࠬ࠭※"), status, reason, bstack1ll1lll_opy_ (u"࠭ࠧ‼"), bstack1ll1lll_opy_ (u"ࠧࠨ‽"))
    driver.execute_script(bstack1llll1ll1_opy_)
@measure(event_name=EVENTS.bstack1lll1l1l_opy_, stage=STAGE.bstack111lll1l11_opy_)
def bstack1l11l1l11l_opy_(page, status, reason=bstack1ll1lll_opy_ (u"ࠨࠩ‾")):
    try:
        if page is None:
            return
        bstack11l1l11l_opy_ = Config.bstack1l1l111l_opy_()
        if bstack11l1l11l_opy_.bstack1111l11lll_opy_():
            return
        bstack1llll1ll1_opy_ = bstack1l1llll1ll_opy_(bstack1ll1lll_opy_ (u"ࠩࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷࠬ‿"), bstack1ll1lll_opy_ (u"ࠪࠫ⁀"), status, reason, bstack1ll1lll_opy_ (u"ࠫࠬ⁁"), bstack1ll1lll_opy_ (u"ࠬ࠭⁂"))
        page.evaluate(bstack1ll1lll_opy_ (u"ࠨ࡟ࠡ࠿ࡁࠤࢀࢃࠢ⁃"), bstack1llll1ll1_opy_)
    except Exception as e:
        print(bstack1ll1lll_opy_ (u"ࠢࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡳࡦࡶࡷ࡭ࡳ࡭ࠠࡴࡧࡶࡷ࡮ࡵ࡮ࠡࡵࡷࡥࡹࡻࡳࠡࡨࡲࡶࠥࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵࠢࡾࢁࠧ⁄"), e)
def bstack1l1llll1ll_opy_(type, name, status, reason, bstack11l11ll1l_opy_, bstack1llll1l11_opy_):
    bstack1l1l1l1l_opy_ = {
        bstack1ll1lll_opy_ (u"ࠨࡣࡦࡸ࡮ࡵ࡮ࠨ⁅"): type,
        bstack1ll1lll_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬ⁆"): {}
    }
    if type == bstack1ll1lll_opy_ (u"ࠪࡥࡳࡴ࡯ࡵࡣࡷࡩࠬ⁇"):
        bstack1l1l1l1l_opy_[bstack1ll1lll_opy_ (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧ⁈")][bstack1ll1lll_opy_ (u"ࠬࡲࡥࡷࡧ࡯ࠫ⁉")] = bstack11l11ll1l_opy_
        bstack1l1l1l1l_opy_[bstack1ll1lll_opy_ (u"࠭ࡡࡳࡩࡸࡱࡪࡴࡴࡴࠩ⁊")][bstack1ll1lll_opy_ (u"ࠧࡥࡣࡷࡥࠬ⁋")] = json.dumps(str(bstack1llll1l11_opy_))
    if type == bstack1ll1lll_opy_ (u"ࠨࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩ⁌"):
        bstack1l1l1l1l_opy_[bstack1ll1lll_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬ⁍")][bstack1ll1lll_opy_ (u"ࠪࡲࡦࡳࡥࠨ⁎")] = name
    if type == bstack1ll1lll_opy_ (u"ࠫࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡔࡶࡤࡸࡺࡹࠧ⁏"):
        bstack1l1l1l1l_opy_[bstack1ll1lll_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨ⁐")][bstack1ll1lll_opy_ (u"࠭ࡳࡵࡣࡷࡹࡸ࠭⁑")] = status
        if status == bstack1ll1lll_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ⁒") and str(reason) != bstack1ll1lll_opy_ (u"ࠣࠤ⁓"):
            bstack1l1l1l1l_opy_[bstack1ll1lll_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬ⁔")][bstack1ll1lll_opy_ (u"ࠪࡶࡪࡧࡳࡰࡰࠪ⁕")] = json.dumps(str(reason))
    bstack1l1ll11l1l_opy_ = bstack1ll1lll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࡾࠩ⁖").format(json.dumps(bstack1l1l1l1l_opy_))
    return bstack1l1ll11l1l_opy_
def bstack1ll11l1111_opy_(url, config, logger, bstack1111lllll_opy_=False):
    hostname = bstack1l111l11ll_opy_(url)
    is_private = bstack1lll1l1l1_opy_(hostname)
    try:
        if is_private or bstack1111lllll_opy_:
            file_path = bstack11l111111ll_opy_(bstack1ll1lll_opy_ (u"ࠬ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠬ⁗"), bstack1ll1lll_opy_ (u"࠭࠮ࡣࡵࡷࡥࡨࡱ࠭ࡤࡱࡱࡪ࡮࡭࠮࡫ࡵࡲࡲࠬ⁘"), logger)
            if os.environ.get(bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡌࡐࡅࡄࡐࡤࡔࡏࡕࡡࡖࡉ࡙ࡥࡅࡓࡔࡒࡖࠬ⁙")) and eval(
                    os.environ.get(bstack1ll1lll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡍࡑࡆࡅࡑࡥࡎࡐࡖࡢࡗࡊ࡚࡟ࡆࡔࡕࡓࡗ࠭⁚"))):
                return
            if (bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭⁛") in config and not config[bstack1ll1lll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࠧ⁜")]):
                os.environ[bstack1ll1lll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡐࡔࡉࡁࡍࡡࡑࡓ࡙ࡥࡓࡆࡖࡢࡉࡗࡘࡏࡓࠩ⁝")] = str(True)
                bstack1lllll111ll1_opy_ = {bstack1ll1lll_opy_ (u"ࠬ࡮࡯ࡴࡶࡱࡥࡲ࡫ࠧ⁞"): hostname}
                bstack11l111ll11l_opy_(bstack1ll1lll_opy_ (u"࠭࠮ࡣࡵࡷࡥࡨࡱ࠭ࡤࡱࡱࡪ࡮࡭࠮࡫ࡵࡲࡲࠬ "), bstack1ll1lll_opy_ (u"ࠧ࡯ࡷࡧ࡫ࡪࡥ࡬ࡰࡥࡤࡰࠬ⁠"), bstack1lllll111ll1_opy_, logger)
    except Exception as e:
        pass
def bstack1ll1111l_opy_(caps, bstack1lllll111lll_opy_):
    if bstack1ll1lll_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫࠻ࡱࡳࡸ࡮ࡵ࡮ࡴࠩ⁡") in caps:
        caps[bstack1ll1lll_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠼ࡲࡴࡹ࡯࡯࡯ࡵࠪ⁢")][bstack1ll1lll_opy_ (u"ࠪࡰࡴࡩࡡ࡭ࠩ⁣")] = True
        if bstack1lllll111lll_opy_:
            caps[bstack1ll1lll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮࠾ࡴࡶࡴࡪࡱࡱࡷࠬ⁤")][bstack1ll1lll_opy_ (u"ࠬࡲ࡯ࡤࡣ࡯ࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧ⁥")] = bstack1lllll111lll_opy_
    else:
        caps[bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡲ࡯ࡤࡣ࡯ࠫ⁦")] = True
        if bstack1lllll111lll_opy_:
            caps[bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴࡬ࡰࡥࡤࡰࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨ⁧")] = bstack1lllll111lll_opy_
def bstack1llllll111l1_opy_(bstack1111l1lll1_opy_):
    bstack1lllll11l111_opy_ = bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠨࡶࡨࡷࡹ࡙ࡴࡢࡶࡸࡷࠬ⁨"), bstack1ll1lll_opy_ (u"ࠩࠪ⁩"))
    if bstack1lllll11l111_opy_ == bstack1ll1lll_opy_ (u"ࠪࠫ⁪") or bstack1lllll11l111_opy_ == bstack1ll1lll_opy_ (u"ࠫࡸࡱࡩࡱࡲࡨࡨࠬ⁫"):
        threading.current_thread().testStatus = bstack1111l1lll1_opy_
    else:
        if bstack1111l1lll1_opy_ == bstack1ll1lll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ⁬"):
            threading.current_thread().testStatus = bstack1111l1lll1_opy_