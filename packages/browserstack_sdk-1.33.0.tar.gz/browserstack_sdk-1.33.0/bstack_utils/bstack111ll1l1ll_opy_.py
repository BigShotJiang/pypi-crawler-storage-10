# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import os
from uuid import uuid4
from bstack_utils.helper import bstack1l11l1llll_opy_, bstack111ll1l1l11_opy_
from bstack_utils.bstack1ll11ll11_opy_ import bstack1llllll1l11l_opy_
class bstack111l1111ll_opy_:
    def __init__(self, name=None, code=None, uuid=None, file_path=None, started_at=None, framework=None, tags=[], scope=[], bstack1llll1llll1l_opy_=None, bstack1llll1ll1lll_opy_=True, bstack1l111l1lll1_opy_=None, bstack111lll1l_opy_=None, result=None, duration=None, bstack111l11l1ll_opy_=None, meta={}):
        self.bstack111l11l1ll_opy_ = bstack111l11l1ll_opy_
        self.name = name
        self.code = code
        self.file_path = file_path
        self.uuid = uuid
        if not self.uuid and bstack1llll1ll1lll_opy_:
            self.uuid = uuid4().__str__()
        self.started_at = started_at
        self.framework = framework
        self.tags = tags
        self.scope = scope
        self.bstack1llll1llll1l_opy_ = bstack1llll1llll1l_opy_
        self.bstack1l111l1lll1_opy_ = bstack1l111l1lll1_opy_
        self.bstack111lll1l_opy_ = bstack111lll1l_opy_
        self.result = result
        self.duration = duration
        self.meta = meta
        self.hooks = []
    def bstack1111ll1l1l_opy_(self):
        if self.uuid:
            return self.uuid
        self.uuid = uuid4().__str__()
        return self.uuid
    def bstack111ll1111l_opy_(self, meta):
        self.meta = meta
    def bstack111ll11l1l_opy_(self, hooks):
        self.hooks = hooks
    def bstack1lllll1111l1_opy_(self):
        bstack1lllll111111_opy_ = os.path.relpath(self.file_path, start=os.getcwd())
        return {
            bstack1ll1lll_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩ⁭"): bstack1lllll111111_opy_,
            bstack1ll1lll_opy_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩ⁮"): bstack1lllll111111_opy_,
            bstack1ll1lll_opy_ (u"ࠨࡸࡦࡣ࡫࡯࡬ࡦࡲࡤࡸ࡭࠭⁯"): bstack1lllll111111_opy_
        }
    def set(self, **kwargs):
        for key, val in kwargs.items():
            if not hasattr(self, key):
                raise TypeError(bstack1ll1lll_opy_ (u"ࠤࡘࡲࡪࡾࡰࡦࡥࡷࡩࡩࠦࡡࡳࡩࡸࡱࡪࡴࡴ࠻ࠢࠥ⁰") + key)
            setattr(self, key, val)
    def bstack1llll1lllll1_opy_(self):
        return {
            bstack1ll1lll_opy_ (u"ࠪࡲࡦࡳࡥࠨⁱ"): self.name,
            bstack1ll1lll_opy_ (u"ࠫࡧࡵࡤࡺࠩ⁲"): {
                bstack1ll1lll_opy_ (u"ࠬࡲࡡ࡯ࡩࠪ⁳"): bstack1ll1lll_opy_ (u"࠭ࡰࡺࡶ࡫ࡳࡳ࠭⁴"),
                bstack1ll1lll_opy_ (u"ࠧࡤࡱࡧࡩࠬ⁵"): self.code
            },
            bstack1ll1lll_opy_ (u"ࠨࡵࡦࡳࡵ࡫ࡳࠨ⁶"): self.scope,
            bstack1ll1lll_opy_ (u"ࠩࡷࡥ࡬ࡹࠧ⁷"): self.tags,
            bstack1ll1lll_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰ࠭⁸"): self.framework,
            bstack1ll1lll_opy_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࡤࡧࡴࠨ⁹"): self.started_at
        }
    def bstack1llll1ll1l1l_opy_(self):
        return {
         bstack1ll1lll_opy_ (u"ࠬࡳࡥࡵࡣࠪ⁺"): self.meta
        }
    def bstack1llll1ll1l11_opy_(self):
        return {
            bstack1ll1lll_opy_ (u"࠭ࡣࡶࡵࡷࡳࡲࡘࡥࡳࡷࡱࡔࡦࡸࡡ࡮ࠩ⁻"): {
                bstack1ll1lll_opy_ (u"ࠧࡳࡧࡵࡹࡳࡥ࡮ࡢ࡯ࡨࠫ⁼"): self.bstack1llll1llll1l_opy_
            }
        }
    def bstack1llll1llllll_opy_(self, bstack1lllll111l11_opy_, details):
        step = next(filter(lambda st: st[bstack1ll1lll_opy_ (u"ࠨ࡫ࡧࠫ⁽")] == bstack1lllll111l11_opy_, self.meta[bstack1ll1lll_opy_ (u"ࠩࡶࡸࡪࡶࡳࠨ⁾")]), None)
        step.update(details)
    def bstack1l111ll1l_opy_(self, bstack1lllll111l11_opy_):
        step = next(filter(lambda st: st[bstack1ll1lll_opy_ (u"ࠪ࡭ࡩ࠭ⁿ")] == bstack1lllll111l11_opy_, self.meta[bstack1ll1lll_opy_ (u"ࠫࡸࡺࡥࡱࡵࠪ₀")]), None)
        step.update({
            bstack1ll1lll_opy_ (u"ࠬࡹࡴࡢࡴࡷࡩࡩࡥࡡࡵࠩ₁"): bstack1l11l1llll_opy_()
        })
    def bstack111ll111ll_opy_(self, bstack1lllll111l11_opy_, result, duration=None):
        bstack1l111l1lll1_opy_ = bstack1l11l1llll_opy_()
        if bstack1lllll111l11_opy_ is not None and self.meta.get(bstack1ll1lll_opy_ (u"࠭ࡳࡵࡧࡳࡷࠬ₂")):
            step = next(filter(lambda st: st[bstack1ll1lll_opy_ (u"ࠧࡪࡦࠪ₃")] == bstack1lllll111l11_opy_, self.meta[bstack1ll1lll_opy_ (u"ࠨࡵࡷࡩࡵࡹࠧ₄")]), None)
            step.update({
                bstack1ll1lll_opy_ (u"ࠩࡩ࡭ࡳ࡯ࡳࡩࡧࡧࡣࡦࡺࠧ₅"): bstack1l111l1lll1_opy_,
                bstack1ll1lll_opy_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ₆"): duration if duration else bstack111ll1l1l11_opy_(step[bstack1ll1lll_opy_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࡤࡧࡴࠨ₇")], bstack1l111l1lll1_opy_),
                bstack1ll1lll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬ₈"): result.result,
                bstack1ll1lll_opy_ (u"࠭ࡦࡢ࡫࡯ࡹࡷ࡫ࠧ₉"): str(result.exception) if result.exception else None
            })
    def add_step(self, bstack1lllll11111l_opy_):
        if self.meta.get(bstack1ll1lll_opy_ (u"ࠧࡴࡶࡨࡴࡸ࠭₊")):
            self.meta[bstack1ll1lll_opy_ (u"ࠨࡵࡷࡩࡵࡹࠧ₋")].append(bstack1lllll11111l_opy_)
        else:
            self.meta[bstack1ll1lll_opy_ (u"ࠩࡶࡸࡪࡶࡳࠨ₌")] = [ bstack1lllll11111l_opy_ ]
    def bstack1llll1llll11_opy_(self):
        return {
            bstack1ll1lll_opy_ (u"ࠪࡹࡺ࡯ࡤࠨ₍"): self.bstack1111ll1l1l_opy_(),
            **self.bstack1llll1lllll1_opy_(),
            **self.bstack1lllll1111l1_opy_(),
            **self.bstack1llll1ll1l1l_opy_()
        }
    def bstack1llll1lll1ll_opy_(self):
        if not self.result:
            return {}
        data = {
            bstack1ll1lll_opy_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡥࡡࡵࠩ₎"): self.bstack1l111l1lll1_opy_,
            bstack1ll1lll_opy_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴ࡟ࡪࡰࡢࡱࡸ࠭₏"): self.duration,
            bstack1ll1lll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ₐ"): self.result.result
        }
        if data[bstack1ll1lll_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧₑ")] == bstack1ll1lll_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨₒ"):
            data[bstack1ll1lll_opy_ (u"ࠩࡩࡥ࡮ࡲࡵࡳࡧࡢࡸࡾࡶࡥࠨₓ")] = self.result.bstack1111111l11_opy_()
            data[bstack1ll1lll_opy_ (u"ࠪࡪࡦ࡯࡬ࡶࡴࡨࠫₔ")] = [{bstack1ll1lll_opy_ (u"ࠫࡧࡧࡣ࡬ࡶࡵࡥࡨ࡫ࠧₕ"): self.result.bstack11l1111111l_opy_()}]
        return data
    def bstack1llll1lll1l1_opy_(self):
        return {
            bstack1ll1lll_opy_ (u"ࠬࡻࡵࡪࡦࠪₖ"): self.bstack1111ll1l1l_opy_(),
            **self.bstack1llll1lllll1_opy_(),
            **self.bstack1lllll1111l1_opy_(),
            **self.bstack1llll1lll1ll_opy_(),
            **self.bstack1llll1ll1l1l_opy_()
        }
    def bstack1111lll11l_opy_(self, event, result=None):
        if result:
            self.result = result
        if bstack1ll1lll_opy_ (u"࠭ࡓࡵࡣࡵࡸࡪࡪࠧₗ") in event:
            return self.bstack1llll1llll11_opy_()
        elif bstack1ll1lll_opy_ (u"ࠧࡇ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩₘ") in event:
            return self.bstack1llll1lll1l1_opy_()
    def bstack111l11111l_opy_(self):
        pass
    def stop(self, time=None, duration=None, result=None):
        self.bstack1l111l1lll1_opy_ = time if time else bstack1l11l1llll_opy_()
        self.duration = duration if duration else bstack111ll1l1l11_opy_(self.started_at, self.bstack1l111l1lll1_opy_)
        if result:
            self.result = result
class bstack111l1ll1l1_opy_(bstack111l1111ll_opy_):
    def __init__(self, hooks=[], bstack111ll1ll1l_opy_={}, *args, **kwargs):
        self.hooks = hooks
        self.bstack111ll1ll1l_opy_ = bstack111ll1ll1l_opy_
        super().__init__(*args, **kwargs, bstack111lll1l_opy_=bstack1ll1lll_opy_ (u"ࠨࡶࡨࡷࡹ࠭ₙ"))
    @classmethod
    def bstack1llll1ll1ll1_opy_(cls, scenario, feature, test, **kwargs):
        steps = []
        for step in scenario.steps:
            steps.append({
                bstack1ll1lll_opy_ (u"ࠩ࡬ࡨࠬₚ"): id(step),
                bstack1ll1lll_opy_ (u"ࠪࡸࡪࡾࡴࠨₛ"): step.name,
                bstack1ll1lll_opy_ (u"ࠫࡰ࡫ࡹࡸࡱࡵࡨࠬₜ"): step.keyword,
            })
        return bstack111l1ll1l1_opy_(
            **kwargs,
            meta={
                bstack1ll1lll_opy_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪ࠭₝"): {
                    bstack1ll1lll_opy_ (u"࠭࡮ࡢ࡯ࡨࠫ₞"): feature.name,
                    bstack1ll1lll_opy_ (u"ࠧࡱࡣࡷ࡬ࠬ₟"): feature.filename,
                    bstack1ll1lll_opy_ (u"ࠨࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭₠"): feature.description
                },
                bstack1ll1lll_opy_ (u"ࠩࡶࡧࡪࡴࡡࡳ࡫ࡲࠫ₡"): {
                    bstack1ll1lll_opy_ (u"ࠪࡲࡦࡳࡥࠨ₢"): scenario.name
                },
                bstack1ll1lll_opy_ (u"ࠫࡸࡺࡥࡱࡵࠪ₣"): steps,
                bstack1ll1lll_opy_ (u"ࠬ࡫ࡸࡢ࡯ࡳࡰࡪࡹࠧ₤"): bstack1llllll1l11l_opy_(test)
            }
        )
    def bstack1lllll1111ll_opy_(self):
        return {
            bstack1ll1lll_opy_ (u"࠭ࡨࡰࡱ࡮ࡷࠬ₥"): self.hooks
        }
    def bstack1llll1lll11l_opy_(self):
        if self.bstack111ll1ll1l_opy_:
            return {
                bstack1ll1lll_opy_ (u"ࠧࡪࡰࡷࡩ࡬ࡸࡡࡵ࡫ࡲࡲࡸ࠭₦"): self.bstack111ll1ll1l_opy_
            }
        return {}
    def bstack1llll1lll1l1_opy_(self):
        return {
            **super().bstack1llll1lll1l1_opy_(),
            **self.bstack1lllll1111ll_opy_()
        }
    def bstack1llll1llll11_opy_(self):
        return {
            **super().bstack1llll1llll11_opy_(),
            **self.bstack1llll1lll11l_opy_()
        }
    def bstack111l11111l_opy_(self):
        return bstack1ll1lll_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࠪ₧")
class bstack111ll1l1l1_opy_(bstack111l1111ll_opy_):
    def __init__(self, hook_type, *args,bstack111ll1ll1l_opy_={}, **kwargs):
        self.hook_type = hook_type
        self.bstack1ll1111111l_opy_ = None
        self.bstack111ll1ll1l_opy_ = bstack111ll1ll1l_opy_
        super().__init__(*args, **kwargs, bstack111lll1l_opy_=bstack1ll1lll_opy_ (u"ࠩ࡫ࡳࡴࡱࠧ₨"))
    def bstack111l111111_opy_(self):
        return self.hook_type
    def bstack1llll1lll111_opy_(self):
        return {
            bstack1ll1lll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡠࡶࡼࡴࡪ࠭₩"): self.hook_type
        }
    def bstack1llll1lll1l1_opy_(self):
        return {
            **super().bstack1llll1lll1l1_opy_(),
            **self.bstack1llll1lll111_opy_()
        }
    def bstack1llll1llll11_opy_(self):
        return {
            **super().bstack1llll1llll11_opy_(),
            bstack1ll1lll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳࡥࡩࡥࠩ₪"): self.bstack1ll1111111l_opy_,
            **self.bstack1llll1lll111_opy_()
        }
    def bstack111l11111l_opy_(self):
        return bstack1ll1lll_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡢࡶࡺࡴࠧ₫")
    def bstack111ll11l11_opy_(self, bstack1ll1111111l_opy_):
        self.bstack1ll1111111l_opy_ = bstack1ll1111111l_opy_