# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import threading
import logging
import bstack_utils.accessibility as bstack1l11l1l1_opy_
from bstack_utils.helper import bstack11l1l1lll_opy_
logger = logging.getLogger(__name__)
def bstack11l111l111_opy_(bstack111l1ll1_opy_):
  return True if bstack111l1ll1_opy_ in threading.current_thread().__dict__.keys() else False
def bstack11l1ll1ll_opy_(context, *args):
    tags = getattr(args[0], bstack1ll1lll_opy_ (u"ࠨࡶࡤ࡫ࡸ࠭ន"), [])
    bstack1lll11ll1l_opy_ = bstack1l11l1l1_opy_.bstack11l1l11ll1_opy_(tags)
    threading.current_thread().isA11yTest = bstack1lll11ll1l_opy_
    try:
      bstack1llll1lll_opy_ = threading.current_thread().bstackSessionDriver if bstack11l111l111_opy_(bstack1ll1lll_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡕࡨࡷࡸ࡯࡯࡯ࡆࡵ࡭ࡻ࡫ࡲࠨប")) else context.browser
      if bstack1llll1lll_opy_ and bstack1llll1lll_opy_.session_id and bstack1lll11ll1l_opy_ and bstack11l1l1lll_opy_(
              threading.current_thread(), bstack1ll1lll_opy_ (u"ࠪࡥ࠶࠷ࡹࡑ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩផ"), None):
          threading.current_thread().isA11yTest = bstack1l11l1l1_opy_.bstack1l1ll111ll_opy_(bstack1llll1lll_opy_, bstack1lll11ll1l_opy_)
    except Exception as e:
       logger.debug(bstack1ll1lll_opy_ (u"ࠫࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡴࡶࡤࡶࡹࠦࡡ࠲࠳ࡼࠤ࡮ࡴࠠࡣࡧ࡫ࡥࡻ࡫࠺ࠡࡽࢀࠫព").format(str(e)))
def bstack11111ll1l_opy_(bstack1llll1lll_opy_):
    if bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠬ࡯ࡳࡂ࠳࠴ࡽ࡙࡫ࡳࡵࠩភ"), None) and bstack11l1l1lll_opy_(
      threading.current_thread(), bstack1ll1lll_opy_ (u"࠭ࡡ࠲࠳ࡼࡔࡱࡧࡴࡧࡱࡵࡱࠬម"), None) and not bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠧࡢ࠳࠴ࡽࡤࡹࡴࡰࡲࠪយ"), False):
      threading.current_thread().a11y_stop = True
      bstack1l11l1l1_opy_.bstack11llllll1_opy_(bstack1llll1lll_opy_, name=bstack1ll1lll_opy_ (u"ࠣࠤរ"), path=bstack1ll1lll_opy_ (u"ࠤࠥល"))