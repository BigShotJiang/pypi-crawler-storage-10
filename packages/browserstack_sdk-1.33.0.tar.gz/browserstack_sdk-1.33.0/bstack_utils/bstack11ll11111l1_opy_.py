# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import requests
from urllib.parse import urljoin, urlencode
from datetime import datetime
import os
import logging
import json
from bstack_utils.constants import bstack11l1l1l1l1l_opy_
logger = logging.getLogger(__name__)
class bstack11ll111l111_opy_:
    @staticmethod
    def results(builder,params=None):
        bstack1lllll1l1111_opy_ = urljoin(builder, bstack1ll1lll_opy_ (u"ࠪ࡭ࡸࡹࡵࡦࡵࠪῬ"))
        if params:
            bstack1lllll1l1111_opy_ += bstack1ll1lll_opy_ (u"ࠦࡄࢁࡽࠣ῭").format(urlencode({bstack1ll1lll_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬ΅"): params.get(bstack1ll1lll_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭`"))}))
        return bstack11ll111l111_opy_.bstack1lllll1l11l1_opy_(bstack1lllll1l1111_opy_)
    @staticmethod
    def bstack11ll1111lll_opy_(builder,params=None):
        bstack1lllll1l1111_opy_ = urljoin(builder, bstack1ll1lll_opy_ (u"ࠧࡪࡵࡶࡹࡪࡹ࠭ࡴࡷࡰࡱࡦࡸࡹࠨ῰"))
        if params:
            bstack1lllll1l1111_opy_ += bstack1ll1lll_opy_ (u"ࠣࡁࡾࢁࠧ῱").format(urlencode({bstack1ll1lll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩῲ"): params.get(bstack1ll1lll_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪῳ"))}))
        return bstack11ll111l111_opy_.bstack1lllll1l11l1_opy_(bstack1lllll1l1111_opy_)
    @staticmethod
    def bstack1lllll1l11l1_opy_(bstack1lllll1l1l11_opy_):
        bstack1lllll1l1l1l_opy_ = os.environ.get(bstack1ll1lll_opy_ (u"ࠫࡇ࡙࡟ࡂ࠳࠴࡝ࡤࡐࡗࡕࠩῴ"), os.environ.get(bstack1ll1lll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤࡐࡗࡕࠩ῵"), bstack1ll1lll_opy_ (u"࠭ࠧῶ")))
        headers = {bstack1ll1lll_opy_ (u"ࠧࡂࡷࡷ࡬ࡴࡸࡩࡻࡣࡷ࡭ࡴࡴࠧῷ"): bstack1ll1lll_opy_ (u"ࠨࡄࡨࡥࡷ࡫ࡲࠡࡽࢀࠫῸ").format(bstack1lllll1l1l1l_opy_)}
        response = requests.get(bstack1lllll1l1l11_opy_, headers=headers)
        bstack1lllll1l11ll_opy_ = {}
        try:
            bstack1lllll1l11ll_opy_ = response.json()
        except Exception as e:
            logger.debug(bstack1ll1lll_opy_ (u"ࠤࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡶࡡࡳࡵࡨࠤࡏ࡙ࡏࡏࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠾ࠥࢁࡽࠣΌ").format(e))
            pass
        if bstack1lllll1l11ll_opy_ is not None:
            bstack1lllll1l11ll_opy_[bstack1ll1lll_opy_ (u"ࠪࡲࡪࡾࡴࡠࡲࡲࡰࡱࡥࡴࡪ࡯ࡨࠫῺ")] = response.headers.get(bstack1ll1lll_opy_ (u"ࠫࡳ࡫ࡸࡵࡡࡳࡳࡱࡲ࡟ࡵ࡫ࡰࡩࠬΏ"), str(int(datetime.now().timestamp() * 1000)))
            bstack1lllll1l11ll_opy_[bstack1ll1lll_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬῼ")] = response.status_code
        return bstack1lllll1l11ll_opy_
    @staticmethod
    def bstack1lllll1l111l_opy_(bstack1lllll11llll_opy_, data):
        logger.debug(bstack1ll1lll_opy_ (u"ࠨࡐࡳࡱࡦࡩࡸࡹࡩ࡯ࡩࠣࡖࡪࡷࡵࡦࡵࡷࠤ࡫ࡵࡲࠡࡶࡨࡷࡹࡕࡲࡤࡪࡨࡷࡹࡸࡡࡵ࡫ࡲࡲࡘࡶ࡬ࡪࡶࡗࡩࡸࡺࡳࠣ´"))
        return bstack11ll111l111_opy_.bstack1lllll11lll1_opy_(bstack1ll1lll_opy_ (u"ࠧࡑࡑࡖࡘࠬ῾"), bstack1lllll11llll_opy_, data=data)
    @staticmethod
    def bstack1lllll1l1ll1_opy_(bstack1lllll11llll_opy_, data):
        logger.debug(bstack1ll1lll_opy_ (u"ࠣࡒࡵࡳࡨ࡫ࡳࡴ࡫ࡱ࡫ࠥࡘࡥࡲࡷࡨࡷࡹࠦࡦࡰࡴࠣ࡫ࡪࡺࡔࡦࡵࡷࡓࡷࡩࡨࡦࡵࡷࡶࡦࡺࡩࡰࡰࡒࡶࡩ࡫ࡲࡦࡦࡗࡩࡸࡺࡳࠣ῿"))
        res = bstack11ll111l111_opy_.bstack1lllll11lll1_opy_(bstack1ll1lll_opy_ (u"ࠩࡊࡉ࡙࠭ "), bstack1lllll11llll_opy_, data=data)
        return res
    @staticmethod
    def bstack1lllll11lll1_opy_(method, bstack1lllll11llll_opy_, data=None, params=None, extra_headers=None):
        bstack1lllll1l1l1l_opy_ = os.environ.get(bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚ࡈࡖࡄࡢࡎ࡜࡚ࠧ "), bstack1ll1lll_opy_ (u"ࠫࠬ "))
        headers = {
            bstack1ll1lll_opy_ (u"ࠬࡧࡵࡵࡪࡲࡶ࡮ࢀࡡࡵ࡫ࡲࡲࠬ "): bstack1ll1lll_opy_ (u"࠭ࡂࡦࡣࡵࡩࡷࠦࡻࡾࠩ ").format(bstack1lllll1l1l1l_opy_),
            bstack1ll1lll_opy_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ "): bstack1ll1lll_opy_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫ "),
            bstack1ll1lll_opy_ (u"ࠩࡄࡧࡨ࡫ࡰࡵࠩ "): bstack1ll1lll_opy_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳ࠭ ")
        }
        if extra_headers:
            headers.update(extra_headers)
        url = bstack11l1l1l1l1l_opy_ + bstack1ll1lll_opy_ (u"ࠦ࠴ࠨ ") + bstack1lllll11llll_opy_.lstrip(bstack1ll1lll_opy_ (u"ࠬ࠵ࠧ "))
        try:
            if method == bstack1ll1lll_opy_ (u"࠭ࡇࡆࡖࠪ​"):
                response = requests.get(url, headers=headers, params=params, json=data)
            elif method == bstack1ll1lll_opy_ (u"ࠧࡑࡑࡖࡘࠬ‌"):
                response = requests.post(url, headers=headers, json=data)
            elif method == bstack1ll1lll_opy_ (u"ࠨࡒࡘࡘࠬ‍"):
                response = requests.put(url, headers=headers, json=data)
            else:
                raise ValueError(bstack1ll1lll_opy_ (u"ࠤࡘࡲࡸࡻࡰࡱࡱࡵࡸࡪࡪࠠࡉࡖࡗࡔࠥࡳࡥࡵࡪࡲࡨ࠿ࠦࡻࡾࠤ‎").format(method))
            logger.debug(bstack1ll1lll_opy_ (u"ࠥࡓࡷࡩࡨࡦࡵࡷࡶࡦࡺࡩࡰࡰࠣࡶࡪࡷࡵࡦࡵࡷࠤࡲࡧࡤࡦࠢࡷࡳ࡛ࠥࡒࡍ࠼ࠣࡿࢂࠦࡷࡪࡶ࡫ࠤࡲ࡫ࡴࡩࡱࡧ࠾ࠥࢁࡽࠣ‏").format(url, method))
            bstack1lllll1l11ll_opy_ = {}
            try:
                bstack1lllll1l11ll_opy_ = response.json()
            except Exception as e:
                logger.debug(bstack1ll1lll_opy_ (u"ࠦࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡱࡣࡵࡷࡪࠦࡊࡔࡑࡑࠤࡷ࡫ࡳࡱࡱࡱࡷࡪࡀࠠࡼࡿࠣ࠱ࠥࢁࡽࠣ‐").format(e, response.text))
            if bstack1lllll1l11ll_opy_ is not None:
                bstack1lllll1l11ll_opy_[bstack1ll1lll_opy_ (u"ࠬࡴࡥࡹࡶࡢࡴࡴࡲ࡬ࡠࡶ࡬ࡱࡪ࠭‑")] = response.headers.get(
                    bstack1ll1lll_opy_ (u"࠭࡮ࡦࡺࡷࡣࡵࡵ࡬࡭ࡡࡷ࡭ࡲ࡫ࠧ‒"), str(int(datetime.now().timestamp() * 1000))
                )
                bstack1lllll1l11ll_opy_[bstack1ll1lll_opy_ (u"ࠧࡴࡶࡤࡸࡺࡹࠧ–")] = response.status_code
            return bstack1lllll1l11ll_opy_
        except Exception as e:
            logger.error(bstack1ll1lll_opy_ (u"ࠣࡑࡵࡧ࡭࡫ࡳࡵࡴࡤࡸ࡮ࡵ࡮ࠡࡴࡨࡵࡺ࡫ࡳࡵࠢࡩࡥ࡮ࡲࡥࡥ࠼ࠣࡿࢂࠦ࠭ࠡࡽࢀࠦ—").format(e, url))
            return None
    @staticmethod
    def bstack11l1l11l1ll_opy_(bstack1lllll1l1l11_opy_, data):
        bstack1ll1lll_opy_ (u"ࠤࠥࠦࠏࠦࠠࠡࠢࠣࠤࠥࠦࡓࡦࡰࡧࡷࠥࡧࠠࡑࡗࡗࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡺ࡯ࠡࡵࡷࡳࡷ࡫ࠠࡵࡪࡨࠤ࡫ࡧࡩ࡭ࡧࡧࠤࡹ࡫ࡳࡵࡵࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢ―")
        bstack1lllll1l1l1l_opy_ = os.environ.get(bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚ࡈࡖࡄࡢࡎ࡜࡚ࠧ‖"), bstack1ll1lll_opy_ (u"ࠫࠬ‗"))
        headers = {
            bstack1ll1lll_opy_ (u"ࠬࡧࡵࡵࡪࡲࡶ࡮ࢀࡡࡵ࡫ࡲࡲࠬ‘"): bstack1ll1lll_opy_ (u"࠭ࡂࡦࡣࡵࡩࡷࠦࡻࡾࠩ’").format(bstack1lllll1l1l1l_opy_),
            bstack1ll1lll_opy_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭‚"): bstack1ll1lll_opy_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫ‛")
        }
        response = requests.put(bstack1lllll1l1l11_opy_, headers=headers, json=data)
        bstack1lllll1l11ll_opy_ = {}
        try:
            bstack1lllll1l11ll_opy_ = response.json()
        except Exception as e:
            logger.debug(bstack1ll1lll_opy_ (u"ࠤࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡶࡡࡳࡵࡨࠤࡏ࡙ࡏࡏࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠾ࠥࢁࡽࠣ“").format(e))
            pass
        logger.debug(bstack1ll1lll_opy_ (u"ࠥࡖࡪࡷࡵࡦࡵࡷ࡙ࡹ࡯࡬ࡴ࠼ࠣࡴࡺࡺ࡟ࡧࡣ࡬ࡰࡪࡪ࡟ࡵࡧࡶࡸࡸࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠻ࠢࡾࢁࠧ”").format(bstack1lllll1l11ll_opy_))
        if bstack1lllll1l11ll_opy_ is not None:
            bstack1lllll1l11ll_opy_[bstack1ll1lll_opy_ (u"ࠫࡳ࡫ࡸࡵࡡࡳࡳࡱࡲ࡟ࡵ࡫ࡰࡩࠬ„")] = response.headers.get(
                bstack1ll1lll_opy_ (u"ࠬࡴࡥࡹࡶࡢࡴࡴࡲ࡬ࡠࡶ࡬ࡱࡪ࠭‟"), str(int(datetime.now().timestamp() * 1000))
            )
            bstack1lllll1l11ll_opy_[bstack1ll1lll_opy_ (u"࠭ࡳࡵࡣࡷࡹࡸ࠭†")] = response.status_code
        return bstack1lllll1l11ll_opy_
    @staticmethod
    def bstack11l11lll1ll_opy_(bstack1lllll1l1l11_opy_):
        bstack1ll1lll_opy_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࠡࠢࠣࠤࡘ࡫࡮ࡥࡵࠣࡥࠥࡍࡅࡕࠢࡵࡩࡶࡻࡥࡴࡶࠣࡸࡴࠦࡧࡦࡶࠣࡸ࡭࡫ࠠࡤࡱࡸࡲࡹࠦ࡯ࡧࠢࡩࡥ࡮ࡲࡥࡥࠢࡷࡩࡸࡺࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ‡")
        bstack1lllll1l1l1l_opy_ = os.environ.get(bstack1ll1lll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡇࡖࡘࡍ࡛ࡂࡠࡌ࡚ࡘࠬ•"), bstack1ll1lll_opy_ (u"ࠩࠪ‣"))
        headers = {
            bstack1ll1lll_opy_ (u"ࠪࡥࡺࡺࡨࡰࡴ࡬ࡾࡦࡺࡩࡰࡰࠪ․"): bstack1ll1lll_opy_ (u"ࠫࡇ࡫ࡡࡳࡧࡵࠤࢀࢃࠧ‥").format(bstack1lllll1l1l1l_opy_),
            bstack1ll1lll_opy_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ…"): bstack1ll1lll_opy_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩ‧")
        }
        response = requests.get(bstack1lllll1l1l11_opy_, headers=headers)
        bstack1lllll1l11ll_opy_ = {}
        try:
            bstack1lllll1l11ll_opy_ = response.json()
            logger.debug(bstack1ll1lll_opy_ (u"ࠢࡓࡧࡴࡹࡪࡹࡴࡖࡶ࡬ࡰࡸࡀࠠࡨࡧࡷࡣ࡫ࡧࡩ࡭ࡧࡧࡣࡹ࡫ࡳࡵࡵࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠿ࠦࡻࡾࠤ ").format(bstack1lllll1l11ll_opy_))
        except Exception as e:
            logger.debug(bstack1ll1lll_opy_ (u"ࠣࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡵࡧࡲࡴࡧࠣࡎࡘࡕࡎࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠽ࠤࢀࢃࠠ࠮ࠢࡾࢁࠧ ").format(e, response.text))
            pass
        if bstack1lllll1l11ll_opy_ is not None:
            bstack1lllll1l11ll_opy_[bstack1ll1lll_opy_ (u"ࠩࡱࡩࡽࡺ࡟ࡱࡱ࡯ࡰࡤࡺࡩ࡮ࡧࠪ‪")] = response.headers.get(
                bstack1ll1lll_opy_ (u"ࠪࡲࡪࡾࡴࡠࡲࡲࡰࡱࡥࡴࡪ࡯ࡨࠫ‫"), str(int(datetime.now().timestamp() * 1000))
            )
            bstack1lllll1l11ll_opy_[bstack1ll1lll_opy_ (u"ࠫࡸࡺࡡࡵࡷࡶࠫ‬")] = response.status_code
        return bstack1lllll1l11ll_opy_
    @staticmethod
    def bstack1111ll111ll_opy_(bstack11ll111l1l1_opy_, payload):
        bstack1ll1lll_opy_ (u"ࠧࠨࠢࠋࠢࠣࠤࠥࠦࠠࠡࠢࡐࡥࡰ࡫ࡳࠡࡣࠣࡔࡔ࡙ࡔࠡࡴࡨࡵࡺ࡫ࡳࡵࠢࡷࡳࠥࡺࡨࡦࠢࡦࡳࡱࡲࡥࡤࡶ࠰ࡦࡺ࡯࡬ࡥ࠯ࡧࡥࡹࡧࠠࡦࡰࡧࡴࡴ࡯࡮ࡵ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࡆࡸࡧࡴ࠼ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡧࡱࡨࡵࡵࡩ࡯ࡶࠣࠬࡸࡺࡲࠪ࠼ࠣࡘ࡭࡫ࠠࡂࡒࡌࠤࡪࡴࡤࡱࡱ࡬ࡲࡹࠦࡰࡢࡶ࡫࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡴࡦࡿ࡬ࡰࡣࡧࠤ࠭ࡪࡩࡤࡶࠬ࠾࡚ࠥࡨࡦࠢࡵࡩࡶࡻࡥࡴࡶࠣࡴࡦࡿ࡬ࡰࡣࡧ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࡒࡦࡶࡸࡶࡳࡹ࠺ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡤࡪࡥࡷ࠾ࠥࡘࡥࡴࡲࡲࡲࡸ࡫ࠠࡧࡴࡲࡱࠥࡺࡨࡦࠢࡄࡔࡎ࠲ࠠࡰࡴࠣࡒࡴࡴࡥࠡ࡫ࡩࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤ‭")
        try:
            url = bstack1ll1lll_opy_ (u"ࠨࡻࡾ࠱ࡾࢁࠧ‮").format(bstack11l1l1l1l1l_opy_, bstack11ll111l1l1_opy_)
            bstack1lllll1l1l1l_opy_ = os.environ.get(bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡌ࡚ࡈ࡟ࡋ࡙ࡗࠫ "), bstack1ll1lll_opy_ (u"ࠨࠩ‰"))
            headers = {
                bstack1ll1lll_opy_ (u"ࠩࡤࡹࡹ࡮࡯ࡳ࡫ࡽࡥࡹ࡯࡯࡯ࠩ‱"): bstack1ll1lll_opy_ (u"ࠪࡆࡪࡧࡲࡦࡴࠣࡿࢂ࠭′").format(bstack1lllll1l1l1l_opy_),
                bstack1ll1lll_opy_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ″"): bstack1ll1lll_opy_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨ‴")
            }
            response = requests.post(url, json=payload, headers=headers, timeout=30)
            bstack1lllll11ll1l_opy_ = [200, 202]
            if response.status_code in bstack1lllll11ll1l_opy_:
                return response.json()
            else:
                logger.error(bstack1ll1lll_opy_ (u"ࠨࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡦࡳࡱࡲࡥࡤࡶࠣࡦࡺ࡯࡬ࡥࠢࡧࡥࡹࡧ࠮ࠡࡕࡷࡥࡹࡻࡳ࠻ࠢࡾࢁ࠱ࠦࡒࡦࡵࡳࡳࡳࡹࡥ࠻ࠢࡾࢁࠧ‵").format(
                    response.status_code, response.text))
                return None
        except Exception as e:
            logger.error(bstack1ll1lll_opy_ (u"ࠢࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡰࡰࡵࡷࡣࡨࡵ࡬࡭ࡧࡦࡸࡤࡨࡵࡪ࡮ࡧࡣࡩࡧࡴࡢ࠼ࠣࡿࢂࠨ‶").format(e))
            return None