# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import re
from bstack_utils.bstack11ll111l1l_opy_ import bstack1llllll111l1_opy_
def bstack1llllll1l1ll_opy_(fixture_name):
    if fixture_name.startswith(bstack1ll1lll_opy_ (u"ࠪࡣࡽࡻ࡮ࡪࡶࡢࡷࡪࡺࡵࡱࡡࡩࡹࡳࡩࡴࡪࡱࡱࡣ࡫࡯ࡸࡵࡷࡵࡩࠬᾴ")):
        return bstack1ll1lll_opy_ (u"ࠫࡸ࡫ࡴࡶࡲ࠰ࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ᾵")
    elif fixture_name.startswith(bstack1ll1lll_opy_ (u"ࠬࡥࡸࡶࡰ࡬ࡸࡤࡹࡥࡵࡷࡳࡣࡲࡵࡤࡶ࡮ࡨࡣ࡫࡯ࡸࡵࡷࡵࡩࠬᾶ")):
        return bstack1ll1lll_opy_ (u"࠭ࡳࡦࡶࡸࡴ࠲ࡳ࡯ࡥࡷ࡯ࡩࠬᾷ")
    elif fixture_name.startswith(bstack1ll1lll_opy_ (u"ࠧࡠࡺࡸࡲ࡮ࡺ࡟ࡵࡧࡤࡶࡩࡵࡷ࡯ࡡࡩࡹࡳࡩࡴࡪࡱࡱࡣ࡫࡯ࡸࡵࡷࡵࡩࠬᾸ")):
        return bstack1ll1lll_opy_ (u"ࠨࡶࡨࡥࡷࡪ࡯ࡸࡰ࠰ࡪࡺࡴࡣࡵ࡫ࡲࡲࠬᾹ")
    elif fixture_name.startswith(bstack1ll1lll_opy_ (u"ࠩࡢࡼࡺࡴࡩࡵࡡࡷࡩࡦࡸࡤࡰࡹࡱࡣ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࡥࡦࡪࡺࡷࡹࡷ࡫ࠧᾺ")):
        return bstack1ll1lll_opy_ (u"ࠪࡸࡪࡧࡲࡥࡱࡺࡲ࠲ࡳ࡯ࡥࡷ࡯ࡩࠬΆ")
def bstack1llllll11l1l_opy_(fixture_name):
    return bool(re.match(bstack1ll1lll_opy_ (u"ࠫࡣࡥࡸࡶࡰ࡬ࡸࡤ࠮ࡳࡦࡶࡸࡴࢁࡺࡥࡢࡴࡧࡳࡼࡴࠩࡠࠪࡩࡹࡳࡩࡴࡪࡱࡱࢀࡲࡵࡤࡶ࡮ࡨ࠭ࡤ࡬ࡩࡹࡶࡸࡶࡪࡥ࠮ࠫࠩᾼ"), fixture_name))
def bstack1llllll1ll11_opy_(fixture_name):
    return bool(re.match(bstack1ll1lll_opy_ (u"ࠬࡤ࡟ࡹࡷࡱ࡭ࡹࡥࠨࡴࡧࡷࡹࡵࢂࡴࡦࡣࡵࡨࡴࡽ࡮ࠪࡡࡰࡳࡩࡻ࡬ࡦࡡࡩ࡭ࡽࡺࡵࡳࡧࡢ࠲࠯࠭᾽"), fixture_name))
def bstack1llllll111ll_opy_(fixture_name):
    return bool(re.match(bstack1ll1lll_opy_ (u"࠭࡞ࡠࡺࡸࡲ࡮ࡺ࡟ࠩࡵࡨࡸࡺࡶࡼࡵࡧࡤࡶࡩࡵࡷ࡯ࠫࡢࡧࡱࡧࡳࡴࡡࡩ࡭ࡽࡺࡵࡳࡧࡢ࠲࠯࠭ι"), fixture_name))
def bstack1llllll1l111_opy_(fixture_name):
    if fixture_name.startswith(bstack1ll1lll_opy_ (u"ࠧࡠࡺࡸࡲ࡮ࡺ࡟ࡴࡧࡷࡹࡵࡥࡦࡶࡰࡦࡸ࡮ࡵ࡮ࡠࡨ࡬ࡼࡹࡻࡲࡦࠩ᾿")):
        return bstack1ll1lll_opy_ (u"ࠨࡵࡨࡸࡺࡶ࠭ࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ῀"), bstack1ll1lll_opy_ (u"ࠩࡅࡉࡋࡕࡒࡆࡡࡈࡅࡈࡎࠧ῁")
    elif fixture_name.startswith(bstack1ll1lll_opy_ (u"ࠪࡣࡽࡻ࡮ࡪࡶࡢࡷࡪࡺࡵࡱࡡࡰࡳࡩࡻ࡬ࡦࡡࡩ࡭ࡽࡺࡵࡳࡧࠪῂ")):
        return bstack1ll1lll_opy_ (u"ࠫࡸ࡫ࡴࡶࡲ࠰ࡱࡴࡪࡵ࡭ࡧࠪῃ"), bstack1ll1lll_opy_ (u"ࠬࡈࡅࡇࡑࡕࡉࡤࡇࡌࡍࠩῄ")
    elif fixture_name.startswith(bstack1ll1lll_opy_ (u"࠭࡟ࡹࡷࡱ࡭ࡹࡥࡴࡦࡣࡵࡨࡴࡽ࡮ࡠࡨࡸࡲࡨࡺࡩࡰࡰࡢࡪ࡮ࡾࡴࡶࡴࡨࠫ῅")):
        return bstack1ll1lll_opy_ (u"ࠧࡵࡧࡤࡶࡩࡵࡷ࡯࠯ࡩࡹࡳࡩࡴࡪࡱࡱࠫῆ"), bstack1ll1lll_opy_ (u"ࠨࡃࡉࡘࡊࡘ࡟ࡆࡃࡆࡌࠬῇ")
    elif fixture_name.startswith(bstack1ll1lll_opy_ (u"ࠩࡢࡼࡺࡴࡩࡵࡡࡷࡩࡦࡸࡤࡰࡹࡱࡣࡲࡵࡤࡶ࡮ࡨࡣ࡫࡯ࡸࡵࡷࡵࡩࠬῈ")):
        return bstack1ll1lll_opy_ (u"ࠪࡸࡪࡧࡲࡥࡱࡺࡲ࠲ࡳ࡯ࡥࡷ࡯ࡩࠬΈ"), bstack1ll1lll_opy_ (u"ࠫࡆࡌࡔࡆࡔࡢࡅࡑࡒࠧῊ")
    return None, None
def bstack1llllll11lll_opy_(hook_name):
    if hook_name in [bstack1ll1lll_opy_ (u"ࠬࡹࡥࡵࡷࡳࠫΉ"), bstack1ll1lll_opy_ (u"࠭ࡴࡦࡣࡵࡨࡴࡽ࡮ࠨῌ")]:
        return hook_name.capitalize()
    return hook_name
def bstack1llllll11l11_opy_(hook_name):
    if hook_name in [bstack1ll1lll_opy_ (u"ࠧࡴࡧࡷࡹࡵࡥࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ῍"), bstack1ll1lll_opy_ (u"ࠨࡵࡨࡸࡺࡶ࡟࡮ࡧࡷ࡬ࡴࡪࠧ῎")]:
        return bstack1ll1lll_opy_ (u"ࠩࡅࡉࡋࡕࡒࡆࡡࡈࡅࡈࡎࠧ῏")
    elif hook_name in [bstack1ll1lll_opy_ (u"ࠪࡷࡪࡺࡵࡱࡡࡰࡳࡩࡻ࡬ࡦࠩῐ"), bstack1ll1lll_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࡢࡧࡱࡧࡳࡴࠩῑ")]:
        return bstack1ll1lll_opy_ (u"ࠬࡈࡅࡇࡑࡕࡉࡤࡇࡌࡍࠩῒ")
    elif hook_name in [bstack1ll1lll_opy_ (u"࠭ࡴࡦࡣࡵࡨࡴࡽ࡮ࡠࡨࡸࡲࡨࡺࡩࡰࡰࠪΐ"), bstack1ll1lll_opy_ (u"ࠧࡵࡧࡤࡶࡩࡵࡷ࡯ࡡࡰࡩࡹ࡮࡯ࡥࠩ῔")]:
        return bstack1ll1lll_opy_ (u"ࠨࡃࡉࡘࡊࡘ࡟ࡆࡃࡆࡌࠬ῕")
    elif hook_name in [bstack1ll1lll_opy_ (u"ࠩࡷࡩࡦࡸࡤࡰࡹࡱࡣࡲࡵࡤࡶ࡮ࡨࠫῖ"), bstack1ll1lll_opy_ (u"ࠪࡸࡪࡧࡲࡥࡱࡺࡲࡤࡩ࡬ࡢࡵࡶࠫῗ")]:
        return bstack1ll1lll_opy_ (u"ࠫࡆࡌࡔࡆࡔࡢࡅࡑࡒࠧῘ")
    return hook_name
def bstack1llllll11ll1_opy_(node, scenario):
    if hasattr(node, bstack1ll1lll_opy_ (u"ࠬࡩࡡ࡭࡮ࡶࡴࡪࡩࠧῙ")):
        parts = node.nodeid.rsplit(bstack1ll1lll_opy_ (u"ࠨ࡛ࠣῚ"))
        params = parts[-1]
        return bstack1ll1lll_opy_ (u"ࠢࡼࡿࠣ࡟ࢀࢃࠢΊ").format(scenario.name, params)
    return scenario.name
def bstack1llllll1l11l_opy_(node):
    try:
        examples = []
        if hasattr(node, bstack1ll1lll_opy_ (u"ࠨࡥࡤࡰࡱࡹࡰࡦࡥࠪ῜")):
            examples = list(node.callspec.params[bstack1ll1lll_opy_ (u"ࠩࡢࡴࡾࡺࡥࡴࡶࡢࡦࡩࡪ࡟ࡦࡺࡤࡱࡵࡲࡥࠨ῝")].values())
        return examples
    except:
        return []
def bstack1llllll1llll_opy_(feature, scenario):
    return list(feature.tags) + list(scenario.tags)
def bstack1llllll1ll1l_opy_(report):
    try:
        status = bstack1ll1lll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ῞")
        if report.passed or (report.failed and hasattr(report, bstack1ll1lll_opy_ (u"ࠦࡼࡧࡳࡹࡨࡤ࡭ࡱࠨ῟"))):
            status = bstack1ll1lll_opy_ (u"ࠬࡶࡡࡴࡵࡨࡨࠬῠ")
        elif report.skipped:
            status = bstack1ll1lll_opy_ (u"࠭ࡳ࡬࡫ࡳࡴࡪࡪࠧῡ")
        bstack1llllll111l1_opy_(status)
    except:
        pass
def bstack111l1l11l_opy_(status):
    try:
        bstack1llllll1lll1_opy_ = bstack1ll1lll_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧῢ")
        if status == bstack1ll1lll_opy_ (u"ࠨࡲࡤࡷࡸ࡫ࡤࠨΰ"):
            bstack1llllll1lll1_opy_ = bstack1ll1lll_opy_ (u"ࠩࡳࡥࡸࡹࡥࡥࠩῤ")
        elif status == bstack1ll1lll_opy_ (u"ࠪࡷࡰ࡯ࡰࡱࡧࡧࠫῥ"):
            bstack1llllll1lll1_opy_ = bstack1ll1lll_opy_ (u"ࠫࡸࡱࡩࡱࡲࡨࡨࠬῦ")
        bstack1llllll111l1_opy_(bstack1llllll1lll1_opy_)
    except:
        pass
def bstack1llllll1l1l1_opy_(item=None, report=None, summary=None, extra=None):
    return