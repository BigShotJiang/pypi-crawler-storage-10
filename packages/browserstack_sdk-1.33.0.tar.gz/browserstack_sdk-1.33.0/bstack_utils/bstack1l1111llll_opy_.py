# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
from browserstack_sdk.bstack1lll1ll111_opy_ import bstack11lll1l111_opy_
from browserstack_sdk.bstack1111lll111_opy_ import RobotHandler
def bstack111llllll_opy_(framework):
    if framework.lower() == bstack1ll1lll_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭ᬟ"):
        return bstack11lll1l111_opy_.version()
    elif framework.lower() == bstack1ll1lll_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠭ᬠ"):
        return RobotHandler.version()
    elif framework.lower() == bstack1ll1lll_opy_ (u"ࠨࡤࡨ࡬ࡦࡼࡥࠨᬡ"):
        import behave
        return behave.__version__
    else:
        return bstack1ll1lll_opy_ (u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࠪᬢ")
def bstack1lllll1lll_opy_():
    import importlib.metadata
    framework_name = []
    framework_version = []
    try:
        from selenium import webdriver
        framework_name.append(bstack1ll1lll_opy_ (u"ࠪࡷࡪࡲࡥ࡯࡫ࡸࡱࠬᬣ"))
        framework_version.append(importlib.metadata.version(bstack1ll1lll_opy_ (u"ࠦࡸ࡫࡬ࡦࡰ࡬ࡹࡲࠨᬤ")))
    except:
        pass
    try:
        import playwright
        framework_name.append(bstack1ll1lll_opy_ (u"ࠬࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵࠩᬥ"))
        framework_version.append(importlib.metadata.version(bstack1ll1lll_opy_ (u"ࠨࡰ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶࠥᬦ")))
    except:
        pass
    return {
        bstack1ll1lll_opy_ (u"ࠧ࡯ࡣࡰࡩࠬᬧ"): bstack1ll1lll_opy_ (u"ࠨࡡࠪᬨ").join(framework_name),
        bstack1ll1lll_opy_ (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪᬩ"): bstack1ll1lll_opy_ (u"ࠪࡣࠬᬪ").join(framework_version)
    }