# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import os
import re
import sys
import json
import time
import shutil
import tempfile
import requests
import subprocess
from threading import Thread
from os.path import expanduser
from bstack_utils.constants import *
from requests.auth import HTTPBasicAuth
from bstack_utils.helper import bstack111lll1ll1_opy_
from bstack_utils.measure import measure
from bstack_utils.bstack11l1111l_opy_ import bstack11l1l111ll_opy_
class bstack1l11l111_opy_:
  working_dir = os.getcwd()
  bstack1ll1l111_opy_ = False
  config = {}
  bstack11l11l11ll1_opy_ = bstack1ll1lll_opy_ (u"ࠫࠬự")
  binary_path = bstack1ll1lll_opy_ (u"ࠬ࠭Ỳ")
  bstack1111l1111ll_opy_ = bstack1ll1lll_opy_ (u"࠭ࠧỳ")
  bstack11l11l1l1_opy_ = False
  bstack11111ll11l1_opy_ = None
  bstack1111l111l11_opy_ = {}
  bstack111111l1ll1_opy_ = 300
  bstack111111l1111_opy_ = False
  logger = None
  bstack1111111lll1_opy_ = False
  bstack1l1l11ll1l_opy_ = False
  percy_build_id = None
  bstack111111l11l1_opy_ = bstack1ll1lll_opy_ (u"ࠧࠨỴ")
  bstack1111l11llll_opy_ = {
    bstack1ll1lll_opy_ (u"ࠨࡥ࡫ࡶࡴࡳࡥࠨỵ") : 1,
    bstack1ll1lll_opy_ (u"ࠩࡩ࡭ࡷ࡫ࡦࡰࡺࠪỶ") : 2,
    bstack1ll1lll_opy_ (u"ࠪࡩࡩ࡭ࡥࠨỷ") : 3,
    bstack1ll1lll_opy_ (u"ࠫࡸࡧࡦࡢࡴ࡬ࠫỸ") : 4
  }
  def __init__(self) -> None: pass
  def bstack1111l111l1l_opy_(self):
    bstack11111l1111l_opy_ = bstack1ll1lll_opy_ (u"ࠬ࠭ỹ")
    bstack111111lll1l_opy_ = sys.platform
    bstack11111lll1l1_opy_ = bstack1ll1lll_opy_ (u"࠭ࡰࡦࡴࡦࡽࠬỺ")
    if re.match(bstack1ll1lll_opy_ (u"ࠢࡥࡣࡵࡻ࡮ࡴࡼ࡮ࡣࡦࠤࡴࡹࠢỻ"), bstack111111lll1l_opy_) != None:
      bstack11111l1111l_opy_ = bstack11l1lll1111_opy_ + bstack1ll1lll_opy_ (u"ࠣ࠱ࡳࡩࡷࡩࡹ࠮ࡱࡶࡼ࠳ࢀࡩࡱࠤỼ")
      self.bstack111111l11l1_opy_ = bstack1ll1lll_opy_ (u"ࠩࡰࡥࡨ࠭ỽ")
    elif re.match(bstack1ll1lll_opy_ (u"ࠥࡱࡸࡽࡩ࡯ࡾࡰࡷࡾࡹࡼ࡮࡫ࡱ࡫ࡼࢂࡣࡺࡩࡺ࡭ࡳࢂࡢࡤࡥࡺ࡭ࡳࢂࡷࡪࡰࡦࡩࢁ࡫࡭ࡤࡾࡺ࡭ࡳ࠹࠲ࠣỾ"), bstack111111lll1l_opy_) != None:
      bstack11111l1111l_opy_ = bstack11l1lll1111_opy_ + bstack1ll1lll_opy_ (u"ࠦ࠴ࡶࡥࡳࡥࡼ࠱ࡼ࡯࡮࠯ࡼ࡬ࡴࠧỿ")
      bstack11111lll1l1_opy_ = bstack1ll1lll_opy_ (u"ࠧࡶࡥࡳࡥࡼ࠲ࡪࡾࡥࠣἀ")
      self.bstack111111l11l1_opy_ = bstack1ll1lll_opy_ (u"࠭ࡷࡪࡰࠪἁ")
    else:
      bstack11111l1111l_opy_ = bstack11l1lll1111_opy_ + bstack1ll1lll_opy_ (u"ࠢ࠰ࡲࡨࡶࡨࡿ࠭࡭࡫ࡱࡹࡽ࠴ࡺࡪࡲࠥἂ")
      self.bstack111111l11l1_opy_ = bstack1ll1lll_opy_ (u"ࠨ࡮࡬ࡲࡺࡾࠧἃ")
    return bstack11111l1111l_opy_, bstack11111lll1l1_opy_
  def bstack1111l111ll1_opy_(self):
    try:
      bstack111111l1l11_opy_ = [os.path.join(expanduser(bstack1ll1lll_opy_ (u"ࠤࢁࠦἄ")), bstack1ll1lll_opy_ (u"ࠪ࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࠪἅ")), self.working_dir, tempfile.gettempdir()]
      for path in bstack111111l1l11_opy_:
        if(self.bstack11111ll111l_opy_(path)):
          return path
      raise bstack1ll1lll_opy_ (u"࡚ࠦࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡳࡩࡷࡩࡹࠡࡤ࡬ࡲࡦࡸࡹࠣἆ")
    except Exception as e:
      self.logger.error(bstack1ll1lll_opy_ (u"ࠧࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡨ࡬ࡲࡩࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡵ࡫ࡲࡤࡻࠣࡨࡴࡽ࡮࡭ࡱࡤࡨ࠱ࠦࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࠰ࠤࢀࢃࠢἇ").format(e))
  def bstack11111ll111l_opy_(self, path):
    try:
      if not os.path.exists(path):
        os.makedirs(path)
      return True
    except:
      return False
  def bstack1111l11ll1l_opy_(self, bstack1111l111lll_opy_):
    return os.path.join(bstack1111l111lll_opy_, self.bstack11l11l11ll1_opy_ + bstack1ll1lll_opy_ (u"ࠨ࠮ࡦࡶࡤ࡫ࠧἈ"))
  def bstack111111l1lll_opy_(self, bstack1111l111lll_opy_, bstack111111lllll_opy_):
    if not bstack111111lllll_opy_: return
    try:
      bstack1111l1111l1_opy_ = self.bstack1111l11ll1l_opy_(bstack1111l111lll_opy_)
      with open(bstack1111l1111l1_opy_, bstack1ll1lll_opy_ (u"ࠢࡸࠤἉ")) as f:
        f.write(bstack111111lllll_opy_)
        self.logger.debug(bstack1ll1lll_opy_ (u"ࠣࡕࡤࡺࡪࡪࠠ࡯ࡧࡺࠤࡊ࡚ࡡࡨࠢࡩࡳࡷࠦࡰࡦࡴࡦࡽࠧἊ"))
    except Exception as e:
      self.logger.error(bstack1ll1lll_opy_ (u"ࠤࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡹࡡࡷࡧࠣࡸ࡭࡫ࠠࡦࡶࡤ࡫࠱ࠦࡥࡳࡴࡲࡶ࠿ࠦࡻࡾࠤἋ").format(e))
  def bstack11111l1l1ll_opy_(self, bstack1111l111lll_opy_):
    try:
      bstack1111l1111l1_opy_ = self.bstack1111l11ll1l_opy_(bstack1111l111lll_opy_)
      if os.path.exists(bstack1111l1111l1_opy_):
        with open(bstack1111l1111l1_opy_, bstack1ll1lll_opy_ (u"ࠥࡶࠧἌ")) as f:
          bstack111111lllll_opy_ = f.read().strip()
          return bstack111111lllll_opy_ if bstack111111lllll_opy_ else None
    except Exception as e:
      self.logger.error(bstack1ll1lll_opy_ (u"ࠦࡋࡧࡩ࡭ࡧࡧࠤࡱࡵࡡࡥ࡫ࡱ࡫ࠥࡋࡔࡢࡩ࠯ࠤࡪࡸࡲࡰࡴ࠽ࠤࢀࢃࠢἍ").format(e))
  def bstack11111lll111_opy_(self, bstack1111l111lll_opy_, bstack11111l1111l_opy_):
    bstack111111llll1_opy_ = self.bstack11111l1l1ll_opy_(bstack1111l111lll_opy_)
    if bstack111111llll1_opy_:
      try:
        bstack11111lllll1_opy_ = self.bstack11111l1ll1l_opy_(bstack111111llll1_opy_, bstack11111l1111l_opy_)
        if not bstack11111lllll1_opy_:
          self.logger.debug(bstack1ll1lll_opy_ (u"ࠧࡖࡥࡳࡥࡼࠤࡧ࡯࡮ࡢࡴࡼࠤ࡮ࡹࠠࡶࡲࠣࡸࡴࠦࡤࡢࡶࡨࠤ࠭ࡋࡔࡢࡩࠣࡹࡳࡩࡨࡢࡰࡪࡩࡩ࠯ࠢἎ"))
          return True
        self.logger.debug(bstack1ll1lll_opy_ (u"ࠨࡎࡦࡹࠣࡔࡪࡸࡣࡺࠢࡥ࡭ࡳࡧࡲࡺࠢࡹࡩࡷࡹࡩࡰࡰࠣࡥࡻࡧࡩ࡭ࡣࡥࡰࡪ࠲ࠠࡥࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠥࡻࡰࡥࡣࡷࡩࠧἏ"))
        return False
      except Exception as e:
        self.logger.warn(bstack1ll1lll_opy_ (u"ࠢࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡧ࡭࡫ࡣ࡬ࠢࡩࡳࡷࠦࡢࡪࡰࡤࡶࡾࠦࡵࡱࡦࡤࡸࡪࡹࠬࠡࡷࡶ࡭ࡳ࡭ࠠࡦࡺ࡬ࡷࡹ࡯࡮ࡨࠢࡥ࡭ࡳࡧࡲࡺ࠼ࠣࡿࢂࠨἐ").format(e))
    return False
  def bstack11111l1ll1l_opy_(self, bstack111111llll1_opy_, bstack11111l1111l_opy_):
    try:
      headers = {
        bstack1ll1lll_opy_ (u"ࠣࡋࡩ࠱ࡓࡵ࡮ࡦ࠯ࡐࡥࡹࡩࡨࠣἑ"): bstack111111llll1_opy_
      }
      response = bstack111lll1ll1_opy_(bstack1ll1lll_opy_ (u"ࠩࡊࡉ࡙࠭ἒ"), bstack11111l1111l_opy_, {}, {bstack1ll1lll_opy_ (u"ࠥ࡬ࡪࡧࡤࡦࡴࡶࠦἓ"): headers})
      if response.status_code == 304:
        return False
      return True
    except Exception as e:
      raise(bstack1ll1lll_opy_ (u"ࠦࡊࡸࡲࡰࡴࠣࡧ࡭࡫ࡣ࡬࡫ࡱ࡫ࠥ࡬࡯ࡳࠢࡓࡩࡷࡩࡹࠡࡤ࡬ࡲࡦࡸࡹࠡࡷࡳࡨࡦࡺࡥࡴ࠼ࠣࡿࢂࠨἔ").format(e))
  @measure(event_name=EVENTS.bstack11l1ll1111l_opy_, stage=STAGE.bstack111lll1l11_opy_)
  def bstack1111l111111_opy_(self, bstack11111l1111l_opy_, bstack11111lll1l1_opy_):
    try:
      bstack111111ll1l1_opy_ = self.bstack1111l111ll1_opy_()
      bstack11111ll1l11_opy_ = os.path.join(bstack111111ll1l1_opy_, bstack1ll1lll_opy_ (u"ࠬࡶࡥࡳࡥࡼ࠲ࡿ࡯ࡰࠨἕ"))
      bstack11111lll1ll_opy_ = os.path.join(bstack111111ll1l1_opy_, bstack11111lll1l1_opy_)
      if self.bstack11111lll111_opy_(bstack111111ll1l1_opy_, bstack11111l1111l_opy_): # if bstack11111l11111_opy_, bstack1l1l111l1l1_opy_ bstack111111lllll_opy_ is bstack11111l1l111_opy_ to bstack11l11ll11ll_opy_ version available (response 304)
        if os.path.exists(bstack11111lll1ll_opy_):
          self.logger.info(bstack1ll1lll_opy_ (u"ࠨࡐࡦࡴࡦࡽࠥࡨࡩ࡯ࡣࡵࡽࠥ࡬࡯ࡶࡰࡧࠤ࡮ࡴࠠࡼࡿ࠯ࠤࡸࡱࡩࡱࡲ࡬ࡲ࡬ࠦࡤࡰࡹࡱࡰࡴࡧࡤࠣ἖").format(bstack11111lll1ll_opy_))
          return bstack11111lll1ll_opy_
        if os.path.exists(bstack11111ll1l11_opy_):
          self.logger.info(bstack1ll1lll_opy_ (u"ࠢࡑࡧࡵࡧࡾࠦࡺࡪࡲࠣࡪࡴࡻ࡮ࡥࠢ࡬ࡲࠥࢁࡽ࠭ࠢࡸࡲࡿ࡯ࡰࡱ࡫ࡱ࡫ࠧ἗").format(bstack11111ll1l11_opy_))
          return self.bstack11111l11l11_opy_(bstack11111ll1l11_opy_, bstack11111lll1l1_opy_)
      self.logger.info(bstack1ll1lll_opy_ (u"ࠣࡆࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬ࠦࡰࡦࡴࡦࡽࠥࡨࡩ࡯ࡣࡵࡽࠥ࡬ࡲࡰ࡯ࠣࡿࢂࠨἘ").format(bstack11111l1111l_opy_))
      response = bstack111lll1ll1_opy_(bstack1ll1lll_opy_ (u"ࠩࡊࡉ࡙࠭Ἑ"), bstack11111l1111l_opy_, {}, {})
      if response.status_code == 200:
        bstack11111ll1l1l_opy_ = response.headers.get(bstack1ll1lll_opy_ (u"ࠥࡉ࡙ࡧࡧࠣἚ"), bstack1ll1lll_opy_ (u"ࠦࠧἛ"))
        if bstack11111ll1l1l_opy_:
          self.bstack111111l1lll_opy_(bstack111111ll1l1_opy_, bstack11111ll1l1l_opy_)
        with open(bstack11111ll1l11_opy_, bstack1ll1lll_opy_ (u"ࠬࡽࡢࠨἜ")) as file:
          file.write(response.content)
        self.logger.info(bstack1ll1lll_opy_ (u"ࠨࡄࡰࡹࡱࡰࡴࡧࡤࡦࡦࠣࡴࡪࡸࡣࡺࠢࡥ࡭ࡳࡧࡲࡺࠢࡤࡲࡩࠦࡳࡢࡸࡨࡨࠥࡧࡴࠡࡽࢀࠦἝ").format(bstack11111ll1l11_opy_))
        return self.bstack11111l11l11_opy_(bstack11111ll1l11_opy_, bstack11111lll1l1_opy_)
      else:
        raise(bstack1ll1lll_opy_ (u"ࠢࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡺࡨࡦࠢࡩ࡭ࡱ࡫࠮ࠡࡕࡷࡥࡹࡻࡳࠡࡥࡲࡨࡪࡀࠠࡼࡿࠥ἞").format(response.status_code))
    except Exception as e:
      self.logger.error(bstack1ll1lll_opy_ (u"ࠣࡗࡱࡥࡧࡲࡥࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡰࡦࡴࡦࡽࠥࡨࡩ࡯ࡣࡵࡽ࠿ࠦࡻࡾࠤ἟").format(e))
  def bstack11111l1ll11_opy_(self, bstack11111l1111l_opy_, bstack11111lll1l1_opy_):
    try:
      retry = 2
      bstack11111lll1ll_opy_ = None
      bstack1111l11l1l1_opy_ = False
      while retry > 0:
        bstack11111lll1ll_opy_ = self.bstack1111l111111_opy_(bstack11111l1111l_opy_, bstack11111lll1l1_opy_)
        bstack1111l11l1l1_opy_ = self.bstack11111ll1ll1_opy_(bstack11111l1111l_opy_, bstack11111lll1l1_opy_, bstack11111lll1ll_opy_)
        if bstack1111l11l1l1_opy_:
          break
        retry -= 1
      return bstack11111lll1ll_opy_, bstack1111l11l1l1_opy_
    except Exception as e:
      self.logger.error(bstack1ll1lll_opy_ (u"ࠤࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥ࡭ࡥࡵࠢࡳࡩࡷࡩࡹࠡࡤ࡬ࡲࡦࡸࡹࠡࡲࡤࡸ࡭ࠨἠ").format(e))
    return bstack11111lll1ll_opy_, False
  def bstack11111ll1ll1_opy_(self, bstack11111l1111l_opy_, bstack11111lll1l1_opy_, bstack11111lll1ll_opy_, bstack111111lll11_opy_ = 0):
    if bstack111111lll11_opy_ > 1:
      return False
    if bstack11111lll1ll_opy_ == None or os.path.exists(bstack11111lll1ll_opy_) == False:
      self.logger.warn(bstack1ll1lll_opy_ (u"ࠥࡔࡪࡸࡣࡺࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤ࡫ࡵࡵ࡯ࡦ࠯ࠤࡷ࡫ࡴࡳࡻ࡬ࡲ࡬ࠦࡤࡰࡹࡱࡰࡴࡧࡤࠣἡ"))
      return False
    bstack11111l1lll1_opy_ = bstack1ll1lll_opy_ (u"ࡶࠧࡤ࠮ࠫࡂࡳࡩࡷࡩࡹ࠰ࡥ࡯࡭ࠥࡢࡤࠬ࡞࠱ࡠࡩ࠱࡜࠯࡞ࡧ࠯ࠧἢ")
    command = bstack1ll1lll_opy_ (u"ࠬࢁࡽࠡ࠯࠰ࡺࡪࡸࡳࡪࡱࡱࠫἣ").format(bstack11111lll1ll_opy_)
    bstack11111l1l11l_opy_ = subprocess.check_output(command, shell=True, text=True)
    if re.match(bstack11111l1lll1_opy_, bstack11111l1l11l_opy_) != None:
      return True
    else:
      self.logger.error(bstack1ll1lll_opy_ (u"ࠨࡐࡦࡴࡦࡽࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡣࡩࡧࡦ࡯ࠥ࡬ࡡࡪ࡮ࡨࡨࠧἤ"))
      return False
  def bstack11111l11l11_opy_(self, bstack11111ll1l11_opy_, bstack11111lll1l1_opy_):
    try:
      working_dir = os.path.dirname(bstack11111ll1l11_opy_)
      shutil.unpack_archive(bstack11111ll1l11_opy_, working_dir)
      bstack11111lll1ll_opy_ = os.path.join(working_dir, bstack11111lll1l1_opy_)
      os.chmod(bstack11111lll1ll_opy_, 0o755)
      return bstack11111lll1ll_opy_
    except Exception as e:
      self.logger.error(bstack1ll1lll_opy_ (u"ࠢࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡹࡳࢀࡩࡱࠢࡳࡩࡷࡩࡹࠡࡤ࡬ࡲࡦࡸࡹࠣἥ"))
  def bstack11111ll1lll_opy_(self):
    try:
      bstack11111l11ll1_opy_ = self.config.get(bstack1ll1lll_opy_ (u"ࠨࡲࡨࡶࡨࡿࠧἦ"))
      bstack11111ll1lll_opy_ = bstack11111l11ll1_opy_ or (bstack11111l11ll1_opy_ is None and self.bstack1ll1l111_opy_)
      if not bstack11111ll1lll_opy_ or self.config.get(bstack1ll1lll_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬἧ"), None) not in bstack11l1ll111l1_opy_:
        return False
      self.bstack11l11l1l1_opy_ = True
      return True
    except Exception as e:
      self.logger.error(bstack1ll1lll_opy_ (u"࡙ࠥࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡤࡦࡶࡨࡧࡹࠦࡰࡦࡴࡦࡽ࠱ࠦࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡾࢁࠧἨ").format(e))
  def bstack1111l11l1ll_opy_(self):
    try:
      bstack1111l11l1ll_opy_ = self.percy_capture_mode
      return bstack1111l11l1ll_opy_
    except Exception as e:
      self.logger.error(bstack1ll1lll_opy_ (u"࡚ࠦࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡥࡧࡷࡩࡨࡺࠠࡱࡧࡵࡧࡾࠦࡣࡢࡲࡷࡹࡷ࡫ࠠ࡮ࡱࡧࡩ࠱ࠦࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡾࢁࠧἩ").format(e))
  def init(self, bstack1ll1l111_opy_, config, logger):
    self.bstack1ll1l111_opy_ = bstack1ll1l111_opy_
    self.config = config
    self.logger = logger
    if not self.bstack11111ll1lll_opy_():
      return
    self.bstack1111l111l11_opy_ = config.get(bstack1ll1lll_opy_ (u"ࠬࡶࡥࡳࡥࡼࡓࡵࡺࡩࡰࡰࡶࠫἪ"), {})
    self.percy_capture_mode = config.get(bstack1ll1lll_opy_ (u"࠭ࡰࡦࡴࡦࡽࡈࡧࡰࡵࡷࡵࡩࡒࡵࡤࡦࠩἫ"))
    try:
      bstack11111l1111l_opy_, bstack11111lll1l1_opy_ = self.bstack1111l111l1l_opy_()
      self.bstack11l11l11ll1_opy_ = bstack11111lll1l1_opy_
      bstack11111lll1ll_opy_, bstack1111l11l1l1_opy_ = self.bstack11111l1ll11_opy_(bstack11111l1111l_opy_, bstack11111lll1l1_opy_)
      if bstack1111l11l1l1_opy_:
        self.binary_path = bstack11111lll1ll_opy_
        thread = Thread(target=self.bstack1111l11ll11_opy_)
        thread.start()
      else:
        self.bstack1111111lll1_opy_ = True
        self.logger.error(bstack1ll1lll_opy_ (u"ࠢࡊࡰࡹࡥࡱ࡯ࡤࠡࡲࡨࡶࡨࡿࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡶࡰࡧࠤ࠲ࠦࡻࡾ࠮࡙ࠣࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡳࡵࡣࡵࡸࠥࡖࡥࡳࡥࡼࠦἬ").format(bstack11111lll1ll_opy_))
    except Exception as e:
      self.logger.error(bstack1ll1lll_opy_ (u"ࠣࡗࡱࡥࡧࡲࡥࠡࡶࡲࠤࡸࡺࡡࡳࡶࠣࡴࡪࡸࡣࡺ࠮ࠣࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡻࡾࠤἭ").format(e))
  def bstack11111l11lll_opy_(self):
    try:
      logfile = os.path.join(self.working_dir, bstack1ll1lll_opy_ (u"ࠩ࡯ࡳ࡬࠭Ἦ"), bstack1ll1lll_opy_ (u"ࠪࡴࡪࡸࡣࡺ࠰࡯ࡳ࡬࠭Ἧ"))
      os.makedirs(os.path.dirname(logfile)) if not os.path.exists(os.path.dirname(logfile)) else None
      self.logger.debug(bstack1ll1lll_opy_ (u"ࠦࡕࡻࡳࡩ࡫ࡱ࡫ࠥࡶࡥࡳࡥࡼࠤࡱࡵࡧࡴࠢࡤࡸࠥࢁࡽࠣἰ").format(logfile))
      self.bstack1111l1111ll_opy_ = logfile
    except Exception as e:
      self.logger.error(bstack1ll1lll_opy_ (u"࡛ࠧ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡵࡨࡸࠥࡶࡥࡳࡥࡼࠤࡱࡵࡧࠡࡲࡤࡸ࡭࠲ࠠࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣࡿࢂࠨἱ").format(e))
  @measure(event_name=EVENTS.bstack11l1l1ll1ll_opy_, stage=STAGE.bstack111lll1l11_opy_)
  def bstack1111l11ll11_opy_(self):
    bstack11111l1llll_opy_ = self.bstack1111111llll_opy_()
    if bstack11111l1llll_opy_ == None:
      self.bstack1111111lll1_opy_ = True
      self.logger.error(bstack1ll1lll_opy_ (u"ࠨࡐࡦࡴࡦࡽࠥࡺ࡯࡬ࡧࡱࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪࠬࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡸࡺࡡࡳࡶࠣࡴࡪࡸࡣࡺࠤἲ"))
      return False
    bstack11111l1l1l1_opy_ = [bstack1ll1lll_opy_ (u"ࠢࡢࡲࡳ࠾ࡪࡾࡥࡤ࠼ࡶࡸࡦࡸࡴࠣἳ") if self.bstack1ll1l111_opy_ else bstack1ll1lll_opy_ (u"ࠨࡧࡻࡩࡨࡀࡳࡵࡣࡵࡸࠬἴ")]
    bstack111l11llll1_opy_ = self.bstack111111ll111_opy_()
    if bstack111l11llll1_opy_ != None:
      bstack11111l1l1l1_opy_.append(bstack1ll1lll_opy_ (u"ࠤ࠰ࡧࠥࢁࡽࠣἵ").format(bstack111l11llll1_opy_))
    env = os.environ.copy()
    env[bstack1ll1lll_opy_ (u"ࠥࡔࡊࡘࡃ࡚ࡡࡗࡓࡐࡋࡎࠣἶ")] = bstack11111l1llll_opy_
    env[bstack1ll1lll_opy_ (u"࡙ࠦࡎ࡟ࡃࡗࡌࡐࡉࡥࡕࡖࡋࡇࠦἷ")] = os.environ.get(bstack1ll1lll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤ࡛ࡕࡊࡆࠪἸ"), bstack1ll1lll_opy_ (u"࠭ࠧἹ"))
    bstack11111ll11ll_opy_ = [self.binary_path]
    self.bstack11111l11lll_opy_()
    self.bstack11111ll11l1_opy_ = self.bstack11111llll1l_opy_(bstack11111ll11ll_opy_ + bstack11111l1l1l1_opy_, env)
    self.logger.debug(bstack1ll1lll_opy_ (u"ࠢࡔࡶࡤࡶࡹ࡯࡮ࡨࠢࡋࡩࡦࡲࡴࡩࠢࡆ࡬ࡪࡩ࡫ࠣἺ"))
    bstack111111lll11_opy_ = 0
    while self.bstack11111ll11l1_opy_.poll() == None:
      bstack111111l1l1l_opy_ = self.bstack111111ll11l_opy_()
      if bstack111111l1l1l_opy_:
        self.logger.debug(bstack1ll1lll_opy_ (u"ࠣࡊࡨࡥࡱࡺࡨࠡࡅ࡫ࡩࡨࡱࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࠦἻ"))
        self.bstack111111l1111_opy_ = True
        return True
      bstack111111lll11_opy_ += 1
      self.logger.debug(bstack1ll1lll_opy_ (u"ࠤࡋࡩࡦࡲࡴࡩࠢࡆ࡬ࡪࡩ࡫ࠡࡔࡨࡸࡷࡿࠠ࠮ࠢࡾࢁࠧἼ").format(bstack111111lll11_opy_))
      time.sleep(2)
    self.logger.error(bstack1ll1lll_opy_ (u"ࠥࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡳࡵࡣࡵࡸࠥࡶࡥࡳࡥࡼ࠰ࠥࡎࡥࡢ࡮ࡷ࡬ࠥࡉࡨࡦࡥ࡮ࠤࡋࡧࡩ࡭ࡧࡧࠤࡦ࡬ࡴࡦࡴࠣࡿࢂࠦࡡࡵࡶࡨࡱࡵࡺࡳࠣἽ").format(bstack111111lll11_opy_))
    self.bstack1111111lll1_opy_ = True
    return False
  def bstack111111ll11l_opy_(self, bstack111111lll11_opy_ = 0):
    if bstack111111lll11_opy_ > 10:
      return False
    try:
      bstack111111l111l_opy_ = os.environ.get(bstack1ll1lll_opy_ (u"ࠫࡕࡋࡒࡄ࡛ࡢࡗࡊࡘࡖࡆࡔࡢࡅࡉࡊࡒࡆࡕࡖࠫἾ"), bstack1ll1lll_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡲ࡯ࡤࡣ࡯࡬ࡴࡹࡴ࠻࠷࠶࠷࠽࠭Ἷ"))
      bstack11111l111ll_opy_ = bstack111111l111l_opy_ + bstack11l1lll111l_opy_
      response = requests.get(bstack11111l111ll_opy_)
      data = response.json()
      self.percy_build_id = data.get(bstack1ll1lll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࠬὀ"), {}).get(bstack1ll1lll_opy_ (u"ࠧࡪࡦࠪὁ"), None)
      return True
    except:
      self.logger.debug(bstack1ll1lll_opy_ (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡥࡦࡹࡷࡸࡥࡥࠢࡺ࡬࡮ࡲࡥࠡࡲࡵࡳࡨ࡫ࡳࡴ࡫ࡱ࡫ࠥ࡮ࡥࡢ࡮ࡷ࡬ࠥࡩࡨࡦࡥ࡮ࠤࡷ࡫ࡳࡱࡱࡱࡷࡪࠨὂ"))
      return False
  def bstack1111111llll_opy_(self):
    bstack1111l11lll1_opy_ = bstack1ll1lll_opy_ (u"ࠩࡤࡴࡵ࠭ὃ") if self.bstack1ll1l111_opy_ else bstack1ll1lll_opy_ (u"ࠪࡥࡺࡺ࡯࡮ࡣࡷࡩࠬὄ")
    bstack11111llllll_opy_ = bstack1ll1lll_opy_ (u"ࠦࡺࡴࡤࡦࡨ࡬ࡲࡪࡪࠢὅ") if self.config.get(bstack1ll1lll_opy_ (u"ࠬࡶࡥࡳࡥࡼࠫ὆")) is None else True
    bstack11ll111l1l1_opy_ = bstack1ll1lll_opy_ (u"ࠨࡡࡱ࡫࠲ࡥࡵࡶ࡟ࡱࡧࡵࡧࡾ࠵ࡧࡦࡶࡢࡴࡷࡵࡪࡦࡥࡷࡣࡹࡵ࡫ࡦࡰࡂࡲࡦࡳࡥ࠾ࡽࢀࠪࡹࡿࡰࡦ࠿ࡾࢁࠫࡶࡥࡳࡥࡼࡁࢀࢃࠢ὇").format(self.config[bstack1ll1lll_opy_ (u"ࠧࡱࡴࡲ࡮ࡪࡩࡴࡏࡣࡰࡩࠬὈ")], bstack1111l11lll1_opy_, bstack11111llllll_opy_)
    if self.percy_capture_mode:
      bstack11ll111l1l1_opy_ += bstack1ll1lll_opy_ (u"ࠣࠨࡳࡩࡷࡩࡹࡠࡥࡤࡴࡹࡻࡲࡦࡡࡰࡳࡩ࡫࠽ࡼࡿࠥὉ").format(self.percy_capture_mode)
    uri = bstack11l1l111ll_opy_(bstack11ll111l1l1_opy_)
    try:
      response = bstack111lll1ll1_opy_(bstack1ll1lll_opy_ (u"ࠩࡊࡉ࡙࠭Ὂ"), uri, {}, {bstack1ll1lll_opy_ (u"ࠪࡥࡺࡺࡨࠨὋ"): (self.config[bstack1ll1lll_opy_ (u"ࠫࡺࡹࡥࡳࡐࡤࡱࡪ࠭Ὄ")], self.config[bstack1ll1lll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨὍ")])})
      if response.status_code == 200:
        data = response.json()
        self.bstack11l11l1l1_opy_ = data.get(bstack1ll1lll_opy_ (u"࠭ࡳࡶࡥࡦࡩࡸࡹࠧ὎"))
        self.percy_capture_mode = data.get(bstack1ll1lll_opy_ (u"ࠧࡱࡧࡵࡧࡾࡥࡣࡢࡲࡷࡹࡷ࡫࡟࡮ࡱࡧࡩࠬ὏"))
        os.environ[bstack1ll1lll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡑࡇࡕࡇ࡞࠭ὐ")] = str(self.bstack11l11l1l1_opy_)
        os.environ[bstack1ll1lll_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡒࡈࡖࡈ࡟࡟ࡄࡃࡓࡘ࡚ࡘࡅࡠࡏࡒࡈࡊ࠭ὑ")] = str(self.percy_capture_mode)
        if bstack11111llllll_opy_ == bstack1ll1lll_opy_ (u"ࠥࡹࡳࡪࡥࡧ࡫ࡱࡩࡩࠨὒ") and str(self.bstack11l11l1l1_opy_).lower() == bstack1ll1lll_opy_ (u"ࠦࡹࡸࡵࡦࠤὓ"):
          self.bstack1l1l11ll1l_opy_ = True
        if bstack1ll1lll_opy_ (u"ࠧࡺ࡯࡬ࡧࡱࠦὔ") in data:
          return data[bstack1ll1lll_opy_ (u"ࠨࡴࡰ࡭ࡨࡲࠧὕ")]
        else:
          raise bstack1ll1lll_opy_ (u"ࠧࡕࡱ࡮ࡩࡳࠦࡎࡰࡶࠣࡊࡴࡻ࡮ࡥࠢ࠰ࠤࢀࢃࠧὖ").format(data)
      else:
        raise bstack1ll1lll_opy_ (u"ࠣࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤ࡫࡫ࡴࡤࡪࠣࡴࡪࡸࡣࡺࠢࡷࡳࡰ࡫࡮࠭ࠢࡕࡩࡸࡶ࡯࡯ࡵࡨࠤࡸࡺࡡࡵࡷࡶࠤ࠲ࠦࡻࡾ࠮ࠣࡖࡪࡹࡰࡰࡰࡶࡩࠥࡈ࡯ࡥࡻࠣ࠱ࠥࢁࡽࠣὗ").format(response.status_code, response.json())
    except Exception as e:
      self.logger.error(bstack1ll1lll_opy_ (u"ࠤࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡥࡵࡩࡦࡺࡩ࡯ࡩࠣࡴࡪࡸࡣࡺࠢࡳࡶࡴࡰࡥࡤࡶࠥ὘").format(e))
  def bstack111111ll111_opy_(self):
    bstack11111l111l1_opy_ = os.path.join(tempfile.gettempdir(), bstack1ll1lll_opy_ (u"ࠥࡴࡪࡸࡣࡺࡅࡲࡲ࡫࡯ࡧ࠯࡬ࡶࡳࡳࠨὙ"))
    try:
      if bstack1ll1lll_opy_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬ὚") not in self.bstack1111l111l11_opy_:
        self.bstack1111l111l11_opy_[bstack1ll1lll_opy_ (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭Ὓ")] = 2
      with open(bstack11111l111l1_opy_, bstack1ll1lll_opy_ (u"࠭ࡷࠨ὜")) as fp:
        json.dump(self.bstack1111l111l11_opy_, fp)
      return bstack11111l111l1_opy_
    except Exception as e:
      self.logger.error(bstack1ll1lll_opy_ (u"ࠢࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡧࡷ࡫ࡡࡵࡧࠣࡴࡪࡸࡣࡺࠢࡦࡳࡳ࡬ࠬࠡࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤࢀࢃࠢὝ").format(e))
  def bstack11111llll1l_opy_(self, cmd, env = os.environ.copy()):
    try:
      if self.bstack111111l11l1_opy_ == bstack1ll1lll_opy_ (u"ࠨࡹ࡬ࡲࠬ὞"):
        bstack1111l11l111_opy_ = [bstack1ll1lll_opy_ (u"ࠩࡦࡱࡩ࠴ࡥࡹࡧࠪὟ"), bstack1ll1lll_opy_ (u"ࠪ࠳ࡨ࠭ὠ")]
        cmd = bstack1111l11l111_opy_ + cmd
      cmd = bstack1ll1lll_opy_ (u"ࠫࠥ࠭ὡ").join(cmd)
      self.logger.debug(bstack1ll1lll_opy_ (u"ࠧࡘࡵ࡯ࡰ࡬ࡲ࡬ࠦࡻࡾࠤὢ").format(cmd))
      with open(self.bstack1111l1111ll_opy_, bstack1ll1lll_opy_ (u"ࠨࡡࠣὣ")) as bstack1111l11111l_opy_:
        process = subprocess.Popen(cmd, shell=True, stdout=bstack1111l11111l_opy_, text=True, stderr=bstack1111l11111l_opy_, env=env, universal_newlines=True)
      return process
    except Exception as e:
      self.bstack1111111lll1_opy_ = True
      self.logger.error(bstack1ll1lll_opy_ (u"ࠢࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡷࡹࡧࡲࡵࠢࡳࡩࡷࡩࡹࠡࡹ࡬ࡸ࡭ࠦࡣ࡮ࡦࠣ࠱ࠥࢁࡽ࠭ࠢࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲ࠿ࠦࡻࡾࠤὤ").format(cmd, e))
  def shutdown(self):
    try:
      if self.bstack111111l1111_opy_:
        self.logger.info(bstack1ll1lll_opy_ (u"ࠣࡕࡷࡳࡵࡶࡩ࡯ࡩࠣࡔࡪࡸࡣࡺࠤὥ"))
        cmd = [self.binary_path, bstack1ll1lll_opy_ (u"ࠤࡨࡼࡪࡩ࠺ࡴࡶࡲࡴࠧὦ")]
        self.bstack11111llll1l_opy_(cmd)
        self.bstack111111l1111_opy_ = False
    except Exception as e:
      self.logger.error(bstack1ll1lll_opy_ (u"ࠥࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡳࡵࡱࡳࠤࡸ࡫ࡳࡴ࡫ࡲࡲࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧࠤ࠲ࠦࡻࡾ࠮ࠣࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࡀࠠࡼࡿࠥὧ").format(cmd, e))
  def bstack1lll111l1l_opy_(self):
    if not self.bstack11l11l1l1_opy_:
      return
    try:
      bstack11111lll11l_opy_ = 0
      while not self.bstack111111l1111_opy_ and bstack11111lll11l_opy_ < self.bstack111111l1ll1_opy_:
        if self.bstack1111111lll1_opy_:
          self.logger.info(bstack1ll1lll_opy_ (u"ࠦࡕ࡫ࡲࡤࡻࠣࡷࡪࡺࡵࡱࠢࡩࡥ࡮ࡲࡥࡥࠤὨ"))
          return
        time.sleep(1)
        bstack11111lll11l_opy_ += 1
      os.environ[bstack1ll1lll_opy_ (u"ࠬࡖࡅࡓࡅ࡜ࡣࡇࡋࡓࡕࡡࡓࡐࡆ࡚ࡆࡐࡔࡐࠫὩ")] = str(self.bstack11111l11l1l_opy_())
      self.logger.info(bstack1ll1lll_opy_ (u"ࠨࡐࡦࡴࡦࡽࠥࡹࡥࡵࡷࡳࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࡪࠢὪ"))
    except Exception as e:
      self.logger.error(bstack1ll1lll_opy_ (u"ࠢࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡷࡪࡺࡵࡱࠢࡳࡩࡷࡩࡹ࠭ࠢࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥࢁࡽࠣὫ").format(e))
  def bstack11111l11l1l_opy_(self):
    if self.bstack1ll1l111_opy_:
      return
    try:
      bstack111111l11ll_opy_ = [platform[bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪ࠭Ὤ")].lower() for platform in self.config.get(bstack1ll1lll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬὭ"), [])]
      bstack11111ll1111_opy_ = sys.maxsize
      bstack11111llll11_opy_ = bstack1ll1lll_opy_ (u"ࠪࠫὮ")
      for browser in bstack111111l11ll_opy_:
        if browser in self.bstack1111l11llll_opy_:
          bstack1111l11l11l_opy_ = self.bstack1111l11llll_opy_[browser]
        if bstack1111l11l11l_opy_ < bstack11111ll1111_opy_:
          bstack11111ll1111_opy_ = bstack1111l11l11l_opy_
          bstack11111llll11_opy_ = browser
      return bstack11111llll11_opy_
    except Exception as e:
      self.logger.error(bstack1ll1lll_opy_ (u"࡚ࠦࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡧ࡫ࡱࡨࠥࡨࡥࡴࡶࠣࡴࡱࡧࡴࡧࡱࡵࡱ࠱ࠦࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡾࢁࠧὯ").format(e))
  @classmethod
  def bstack11ll1l11ll_opy_(self):
    return os.getenv(bstack1ll1lll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡕࡋࡒࡄ࡛ࠪὰ"), bstack1ll1lll_opy_ (u"࠭ࡆࡢ࡮ࡶࡩࠬά")).lower()
  @classmethod
  def bstack1l11l1ll1l_opy_(self):
    return os.getenv(bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡐࡆࡔࡆ࡝ࡤࡉࡁࡑࡖࡘࡖࡊࡥࡍࡐࡆࡈࠫὲ"), bstack1ll1lll_opy_ (u"ࠨࠩέ"))
  @classmethod
  def bstack1l1l11l1l11_opy_(cls, value):
    cls.bstack1l1l11ll1l_opy_ = value
  @classmethod
  def bstack1111l1l1111_opy_(cls):
    return cls.bstack1l1l11ll1l_opy_
  @classmethod
  def bstack1l1l11l1l1l_opy_(cls, value):
    cls.percy_build_id = value
  @classmethod
  def bstack111111ll1ll_opy_(cls):
    return cls.percy_build_id