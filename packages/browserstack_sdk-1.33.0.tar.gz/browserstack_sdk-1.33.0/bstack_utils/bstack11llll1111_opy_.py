# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
from filelock import FileLock
import json
import os
import time
import uuid
import logging
from typing import Dict, List, Optional
from bstack_utils.bstack1ll1ll1111_opy_ import get_logger
logger = get_logger(__name__)
bstack1lllllllll11_opy_: Dict[str, float] = {}
bstack1lllllll1lll_opy_: List = []
bstack1llllllllll1_opy_ = 5
bstack11llllllll_opy_ = os.path.join(os.getcwd(), bstack1ll1lll_opy_ (u"ࠪࡰࡴ࡭ࠧή"), bstack1ll1lll_opy_ (u"ࠫࡰ࡫ࡹ࠮࡯ࡨࡸࡷ࡯ࡣࡴ࠰࡭ࡷࡴࡴࠧὶ"))
logging.getLogger(bstack1ll1lll_opy_ (u"ࠬ࡬ࡩ࡭ࡧ࡯ࡳࡨࡱࠧί")).setLevel(logging.WARNING)
lock = FileLock(bstack11llllllll_opy_+bstack1ll1lll_opy_ (u"ࠨ࠮࡭ࡱࡦ࡯ࠧὸ"))
class bstack1llllllll111_opy_:
    duration: float
    name: str
    startTime: float
    worker: int
    status: bool
    failure: str
    details: Optional[str]
    entryType: str
    platform: Optional[int]
    command: Optional[str]
    hookType: Optional[str]
    cli: Optional[bool]
    def __init__(self, duration: float, name: str, start_time: float, bstack1llllllll11l_opy_: int, status: bool, failure: str, details: Optional[str] = None, platform: Optional[int] = None, command: Optional[str] = None, test_name: Optional[str] = None, hook_type: Optional[str] = None, cli: Optional[bool] = False) -> None:
        self.duration = duration
        self.name = name
        self.startTime = start_time
        self.worker = bstack1llllllll11l_opy_
        self.status = status
        self.failure = failure
        self.details = details
        self.entryType = bstack1ll1lll_opy_ (u"ࠢ࡮ࡧࡤࡷࡺࡸࡥࠣό")
        self.platform = platform
        self.command = command
        self.testName = test_name
        self.hookType = hook_type
        self.cli = cli
class bstack1llll11111l_opy_:
    global bstack1lllllllll11_opy_
    @staticmethod
    def bstack1ll111l11l1_opy_(key: str):
        bstack1ll111ll11l_opy_ = bstack1llll11111l_opy_.bstack11ll11l1l1l_opy_(key)
        bstack1llll11111l_opy_.mark(bstack1ll111ll11l_opy_+bstack1ll1lll_opy_ (u"ࠣ࠼ࡶࡸࡦࡸࡴࠣὺ"))
        return bstack1ll111ll11l_opy_
    @staticmethod
    def mark(key: str) -> None:
        try:
            bstack1lllllllll11_opy_[key] = time.time_ns() / 1000000
        except Exception as e:
            logger.debug(bstack1ll1lll_opy_ (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾࢁࠧύ").format(e))
    @staticmethod
    def end(label: str, start: str, end: str, status: bool, failure: Optional[str] = None, hook_type: Optional[str] = None, details: Optional[str] = None, command: Optional[str] = None, test_name: Optional[str] = None) -> None:
        try:
            bstack1llll11111l_opy_.mark(end)
            bstack1llll11111l_opy_.measure(label, start, end, status, failure, hook_type, details, command, test_name)
        except Exception as e:
            logger.debug(bstack1ll1lll_opy_ (u"ࠥࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥࡱࡥࡺࠢࡰࡩࡹࡸࡩࡤࡵ࠽ࠤࢀࢃࠢὼ").format(e))
    @staticmethod
    def measure(label: str, start: str, end: str, status: bool, failure: Optional[str], hook_type: Optional[str] = None, details: Optional[str] = None, command: Optional[str] = None, test_name: Optional[str] = None) -> None:
        try:
            if start not in bstack1lllllllll11_opy_ or end not in bstack1lllllllll11_opy_:
                logger.debug(bstack1ll1lll_opy_ (u"ࠦࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡳࡵࡣࡵࡸࠥࡱࡥࡺࠢࡺ࡭ࡹ࡮ࠠࡷࡣ࡯ࡹࡪࠦࡻࡾࠢࡲࡶࠥ࡫࡮ࡥࠢ࡮ࡩࡾࠦࡷࡪࡶ࡫ࠤࡻࡧ࡬ࡶࡧࠣࡿࢂࠨώ").format(start,end))
                return
            duration: float = bstack1lllllllll11_opy_[end] - bstack1lllllllll11_opy_[start]
            bstack11111111111_opy_ = os.environ.get(bstack1ll1lll_opy_ (u"ࠧࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡇࡏࡎࡂࡔ࡜ࡣࡎ࡙࡟ࡓࡗࡑࡒࡎࡔࡇࠣ὾"), bstack1ll1lll_opy_ (u"ࠨࡦࡢ࡮ࡶࡩࠧ὿")).lower() == bstack1ll1lll_opy_ (u"ࠢࡵࡴࡸࡩࠧᾀ")
            bstack1lllllllllll_opy_: bstack1llllllll111_opy_ = bstack1llllllll111_opy_(duration, label, bstack1lllllllll11_opy_[start], os.getpid(), status, failure, details, os.environ.get(bstack1ll1lll_opy_ (u"ࠣࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡑࡎࡄࡘࡋࡕࡒࡎࡡࡌࡒࡉࡋࡘࠣᾁ"), 0), command, test_name, hook_type, bstack11111111111_opy_)
            del bstack1lllllllll11_opy_[start]
            del bstack1lllllllll11_opy_[end]
            bstack1llll11111l_opy_.bstack1llllllll1ll_opy_(bstack1lllllllllll_opy_)
        except Exception as e:
            logger.debug(bstack1ll1lll_opy_ (u"ࠤࡈࡶࡷࡵࡲࠡࡹ࡫࡭ࡱ࡫ࠠ࡮ࡧࡤࡷࡺࡸࡩ࡯ࡩࠣ࡯ࡪࡿࠠ࡮ࡧࡷࡶ࡮ࡩࡳ࠻ࠢࡾࢁࠧᾂ").format(e))
    @staticmethod
    def bstack1llllllll1ll_opy_(bstack1lllllllllll_opy_):
        os.makedirs(os.path.dirname(bstack11llllllll_opy_)) if not os.path.exists(os.path.dirname(bstack11llllllll_opy_)) else None
        bstack1llll11111l_opy_.bstack1lllllllll1l_opy_()
        try:
            with lock:
                with open(bstack11llllllll_opy_, bstack1ll1lll_opy_ (u"ࠥࡶ࠰ࠨᾃ"), encoding=bstack1ll1lll_opy_ (u"ࠦࡺࡺࡦ࠮࠺ࠥᾄ")) as file:
                    try:
                        data = json.load(file)
                    except json.JSONDecodeError:
                        data = []
                    data.append(bstack1lllllllllll_opy_.__dict__)
                    file.seek(0)
                    file.truncate()
                    json.dump(data, file, indent=4)
        except FileNotFoundError as bstack1llllllll1l1_opy_:
            logger.debug(bstack1ll1lll_opy_ (u"ࠧࡌࡩ࡭ࡧࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠦࡻࡾࠤᾅ").format(bstack1llllllll1l1_opy_))
            with lock:
                with open(bstack11llllllll_opy_, bstack1ll1lll_opy_ (u"ࠨࡷࠣᾆ"), encoding=bstack1ll1lll_opy_ (u"ࠢࡶࡶࡩ࠱࠽ࠨᾇ")) as file:
                    data = [bstack1lllllllllll_opy_.__dict__]
                    json.dump(data, file, indent=4)
        except Exception as e:
            logger.debug(bstack1ll1lll_opy_ (u"ࠣࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤࡼ࡮ࡩ࡭ࡧࠣ࡯ࡪࡿࠠ࡮ࡧࡷࡶ࡮ࡩࡳࠡࡣࡳࡴࡪࡴࡤࠡࡽࢀࠦᾈ").format(str(e)))
        finally:
            if os.path.exists(bstack11llllllll_opy_+bstack1ll1lll_opy_ (u"ࠤ࠱ࡰࡴࡩ࡫ࠣᾉ")):
                os.remove(bstack11llllllll_opy_+bstack1ll1lll_opy_ (u"ࠥ࠲ࡱࡵࡣ࡬ࠤᾊ"))
    @staticmethod
    def bstack1lllllllll1l_opy_():
        attempt = 0
        while (attempt < bstack1llllllllll1_opy_):
            attempt += 1
            if os.path.exists(bstack11llllllll_opy_+bstack1ll1lll_opy_ (u"ࠦ࠳ࡲ࡯ࡤ࡭ࠥᾋ")):
                time.sleep(0.5)
            else:
                break
    @staticmethod
    def bstack11ll11l1l1l_opy_(label: str) -> str:
        try:
            return bstack1ll1lll_opy_ (u"ࠧࢁࡽ࠻ࡽࢀࠦᾌ").format(label,str(uuid.uuid4().hex)[:6])
        except Exception as e:
            logger.debug(bstack1ll1lll_opy_ (u"ࠨࡅࡳࡴࡲࡶ࠿ࠦࡻࡾࠤᾍ").format(e))