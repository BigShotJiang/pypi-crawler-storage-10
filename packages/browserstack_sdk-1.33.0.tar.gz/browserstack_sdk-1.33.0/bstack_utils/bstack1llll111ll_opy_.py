# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import os
import tempfile
import math
from bstack_utils import bstack1ll1ll1111_opy_
from bstack_utils.constants import bstack1l1lll1l11_opy_, bstack11l1ll11l11_opy_
from bstack_utils.helper import bstack11l11l11l11_opy_, get_host_info
from bstack_utils.bstack11ll11111l1_opy_ import bstack11ll111l111_opy_
import json
import re
import sys
bstack1111llll1ll_opy_ = bstack1ll1lll_opy_ (u"ࠤࡵࡩࡹࡸࡹࡕࡧࡶࡸࡸࡕ࡮ࡇࡣ࡬ࡰࡺࡸࡥࠣṸ")
bstack1111lll11ll_opy_ = bstack1ll1lll_opy_ (u"ࠥࡥࡧࡵࡲࡵࡄࡸ࡭ࡱࡪࡏ࡯ࡈࡤ࡭ࡱࡻࡲࡦࠤṹ")
bstack1111ll1l1ll_opy_ = bstack1ll1lll_opy_ (u"ࠦࡷࡻ࡮ࡑࡴࡨࡺ࡮ࡵࡵࡴ࡮ࡼࡊࡦ࡯࡬ࡦࡦࡉ࡭ࡷࡹࡴࠣṺ")
bstack1111lll1l11_opy_ = bstack1ll1lll_opy_ (u"ࠧࡸࡥࡳࡷࡱࡔࡷ࡫ࡶࡪࡱࡸࡷࡱࡿࡆࡢ࡫࡯ࡩࡩࠨṻ")
bstack1111lll1ll1_opy_ = bstack1ll1lll_opy_ (u"ࠨࡳ࡬࡫ࡳࡊࡱࡧ࡫ࡺࡣࡱࡨࡋࡧࡩ࡭ࡧࡧࠦṼ")
bstack1111lll1l1l_opy_ = bstack1ll1lll_opy_ (u"ࠢࡳࡷࡱࡗࡲࡧࡲࡵࡕࡨࡰࡪࡩࡴࡪࡱࡱࠦṽ")
bstack1111llll11l_opy_ = {
    bstack1111llll1ll_opy_,
    bstack1111lll11ll_opy_,
    bstack1111ll1l1ll_opy_,
    bstack1111lll1l11_opy_,
    bstack1111lll1ll1_opy_,
    bstack1111lll1l1l_opy_
}
bstack111l111l111_opy_ = {bstack1ll1lll_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࠨṾ")}
logger = bstack1ll1ll1111_opy_.get_logger(__name__, bstack1l1lll1l11_opy_)
class bstack1111l1ll1ll_opy_:
    def __init__(self):
        self.enabled = False
        self.name = None
    def enable(self, name):
        self.enabled = True
        self.name = name
    def disable(self):
        self.enabled = False
        self.name = None
    def bstack1111ll111l1_opy_(self):
        return self.enabled
    def get_name(self):
        return self.name
class bstack11lll1lll1_opy_:
    _1ll1llll1l1_opy_ = None
    def __init__(self, config):
        self.bstack1111ll1llll_opy_ = False
        self.bstack1111ll1l111_opy_ = False
        self.bstack1111l1l11l1_opy_ = False
        self.bstack1111l1ll111_opy_ = False
        self.bstack111l11111ll_opy_ = None
        self.bstack1111lllll11_opy_ = bstack1111l1ll1ll_opy_()
        self.bstack1111llll111_opy_ = None
        opts = config.get(bstack1ll1lll_opy_ (u"ࠩࡷࡩࡸࡺࡏࡳࡥ࡫ࡩࡸࡺࡲࡢࡶ࡬ࡳࡳࡕࡰࡵ࡫ࡲࡲࡸ࠭ṿ"), {})
        self.bstack1111l1llll1_opy_ = config.get(bstack1ll1lll_opy_ (u"ࠪࡷࡲࡧࡲࡵࡕࡨࡰࡪࡩࡴࡪࡱࡱࡊࡪࡧࡴࡶࡴࡨࡆࡷࡧ࡮ࡤࡪࡨࡷࡊࡔࡖࠨẀ"), bstack1ll1lll_opy_ (u"ࠦࠧẁ"))
        self.bstack1111llllll1_opy_ = config.get(bstack1ll1lll_opy_ (u"ࠬࡹ࡭ࡢࡴࡷࡗࡪࡲࡥࡤࡶ࡬ࡳࡳࡌࡥࡢࡶࡸࡶࡪࡈࡲࡢࡰࡦ࡬ࡪࡹࡃࡍࡋࠪẂ"), bstack1ll1lll_opy_ (u"ࠨࠢẃ"))
        bstack1111ll1111l_opy_ = opts.get(bstack1111lll1l1l_opy_, {})
        bstack1111lll111l_opy_ = None
        if bstack1ll1lll_opy_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠧẄ") in bstack1111ll1111l_opy_:
            bstack1111lll111l_opy_ = bstack1111ll1111l_opy_[bstack1ll1lll_opy_ (u"ࠨࡵࡲࡹࡷࡩࡥࠨẅ")]
            if bstack1111lll111l_opy_ is None:
                bstack1111lll111l_opy_ = []
        self.__1111ll1ll11_opy_(
            bstack1111ll1111l_opy_.get(bstack1ll1lll_opy_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࡦࠪẆ"), False),
            bstack1111ll1111l_opy_.get(bstack1ll1lll_opy_ (u"ࠪࡱࡴࡪࡥࠨẇ"), bstack1ll1lll_opy_ (u"ࠫࡷ࡫࡬ࡦࡸࡤࡲࡹࡌࡩࡳࡵࡷࠫẈ")),
            bstack1111lll111l_opy_
        )
        self.__1111lllllll_opy_(opts.get(bstack1111ll1l1ll_opy_, False))
        self.__1111l1l1ll1_opy_(opts.get(bstack1111lll1l11_opy_, False))
        self.__111l1111111_opy_(opts.get(bstack1111lll1ll1_opy_, False))
    @classmethod
    def bstack1l1l111l_opy_(cls, config=None):
        if cls._1ll1llll1l1_opy_ is None and config is not None:
            cls._1ll1llll1l1_opy_ = bstack11lll1lll1_opy_(config)
        return cls._1ll1llll1l1_opy_
    @staticmethod
    def bstack1111ll1l1_opy_(config: dict) -> bool:
        bstack1111lll11l1_opy_ = config.get(bstack1ll1lll_opy_ (u"ࠬࡺࡥࡴࡶࡒࡶࡨ࡮ࡥࡴࡶࡵࡥࡹ࡯࡯࡯ࡑࡳࡸ࡮ࡵ࡮ࡴࠩẉ"), {}).get(bstack1111llll1ll_opy_, {})
        return bstack1111lll11l1_opy_.get(bstack1ll1lll_opy_ (u"࠭ࡥ࡯ࡣࡥࡰࡪࡪࠧẊ"), False)
    @staticmethod
    def bstack11l1l1111l_opy_(config: dict) -> int:
        bstack1111lll11l1_opy_ = config.get(bstack1ll1lll_opy_ (u"ࠧࡵࡧࡶࡸࡔࡸࡣࡩࡧࡶࡸࡷࡧࡴࡪࡱࡱࡓࡵࡺࡩࡰࡰࡶࠫẋ"), {}).get(bstack1111llll1ll_opy_, {})
        retries = 0
        if bstack11lll1lll1_opy_.bstack1111ll1l1_opy_(config):
            retries = bstack1111lll11l1_opy_.get(bstack1ll1lll_opy_ (u"ࠨ࡯ࡤࡼࡗ࡫ࡴࡳ࡫ࡨࡷࠬẌ"), 1)
        return retries
    @staticmethod
    def bstack1ll11ll1ll_opy_(config: dict) -> dict:
        bstack111l1111l11_opy_ = config.get(bstack1ll1lll_opy_ (u"ࠩࡷࡩࡸࡺࡏࡳࡥ࡫ࡩࡸࡺࡲࡢࡶ࡬ࡳࡳࡕࡰࡵ࡫ࡲࡲࡸ࠭ẍ"), {})
        return {
            key: value for key, value in bstack111l1111l11_opy_.items() if key in bstack1111llll11l_opy_
        }
    @staticmethod
    def bstack1111llll1l1_opy_():
        bstack1ll1lll_opy_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡄࡪࡨࡧࡰࠦࡩࡧࠢࡷ࡬ࡪࠦࡡࡣࡱࡵࡸࠥࡨࡵࡪ࡮ࡧࠤ࡫࡯࡬ࡦࠢࡨࡼ࡮ࡹࡴࡴ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢẎ")
        return os.path.exists(os.path.join(tempfile.gettempdir(), bstack1ll1lll_opy_ (u"ࠦࡦࡨ࡯ࡳࡶࡢࡦࡺ࡯࡬ࡥࡡࡾࢁࠧẏ").format(os.getenv(bstack1ll1lll_opy_ (u"ࠧࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤ࡛ࡕࡊࡆࠥẐ")))))
    @staticmethod
    def bstack1111l1l11ll_opy_(test_name: str):
        bstack1ll1lll_opy_ (u"ࠨࠢࠣࠌࠣࠤࠥࠦࠠࠡࠢࠣࡇ࡭࡫ࡣ࡬ࠢ࡬ࡪࠥࡺࡨࡦࠢࡤࡦࡴࡸࡴࠡࡤࡸ࡭ࡱࡪࠠࡧ࡫࡯ࡩࠥ࡫ࡸࡪࡵࡷࡷ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥẑ")
        bstack1111l1l1l1l_opy_ = os.path.join(tempfile.gettempdir(), bstack1ll1lll_opy_ (u"ࠢࡧࡣ࡬ࡰࡪࡪ࡟ࡵࡧࡶࡸࡸࡥࡻࡾ࠰ࡷࡼࡹࠨẒ").format(os.getenv(bstack1ll1lll_opy_ (u"ࠣࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡇࡖࡘࡍ࡛ࡂࡠࡗࡘࡍࡉࠨẓ"))))
        with open(bstack1111l1l1l1l_opy_, bstack1ll1lll_opy_ (u"ࠩࡤࠫẔ")) as file:
            file.write(bstack1ll1lll_opy_ (u"ࠥࡿࢂࡢ࡮ࠣẕ").format(test_name))
    @staticmethod
    def bstack1111l1lllll_opy_(framework: str) -> bool:
       return framework.lower() in bstack111l111l111_opy_
    @staticmethod
    def bstack11l11lllll1_opy_(config: dict) -> bool:
        bstack1111ll11ll1_opy_ = config.get(bstack1ll1lll_opy_ (u"ࠫࡹ࡫ࡳࡵࡑࡵࡧ࡭࡫ࡳࡵࡴࡤࡸ࡮ࡵ࡮ࡐࡲࡷ࡭ࡴࡴࡳࠨẖ"), {}).get(bstack1111lll11ll_opy_, {})
        return bstack1111ll11ll1_opy_.get(bstack1ll1lll_opy_ (u"ࠬ࡫࡮ࡢࡤ࡯ࡩࡩ࠭ẗ"), False)
    @staticmethod
    def bstack11l1l1111ll_opy_(config: dict, bstack11l1l11llll_opy_: int = 0) -> int:
        bstack1ll1lll_opy_ (u"ࠨࠢࠣࠌࠣࠤࠥࠦࠠࠡࠢࠣࡋࡪࡺࠠࡵࡪࡨࠤ࡫ࡧࡩ࡭ࡷࡵࡩࠥࡺࡨࡳࡧࡶ࡬ࡴࡲࡤ࠭ࠢࡺ࡬࡮ࡩࡨࠡࡥࡤࡲࠥࡨࡥࠡࡣࡱࠤࡦࡨࡳࡰ࡮ࡸࡸࡪࠦ࡮ࡶ࡯ࡥࡩࡷࠦ࡯ࡳࠢࡤࠤࡵ࡫ࡲࡤࡧࡱࡸࡦ࡭ࡥ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࡅࡷ࡭ࡳ࠻ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡤࡱࡱࡪ࡮࡭ࠠࠩࡦ࡬ࡧࡹ࠯࠺ࠡࡖ࡫ࡩࠥࡩ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲࠥࡪࡩࡤࡶ࡬ࡳࡳࡧࡲࡺ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡶࡲࡸࡦࡲ࡟ࡵࡧࡶࡸࡸࠦࠨࡪࡰࡷ࠭࠿ࠦࡔࡩࡧࠣࡸࡴࡺࡡ࡭ࠢࡱࡹࡲࡨࡥࡳࠢࡲࡪࠥࡺࡥࡴࡶࡶࠤ࠭ࡸࡥࡲࡷ࡬ࡶࡪࡪࠠࡧࡱࡵࠤࡵ࡫ࡲࡤࡧࡱࡸࡦ࡭ࡥ࠮ࡤࡤࡷࡪࡪࠠࡵࡪࡵࡩࡸ࡮࡯࡭ࡦࡶ࠭࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࡓࡧࡷࡹࡷࡴࡳ࠻ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡪࡰࡷ࠾࡚ࠥࡨࡦࠢࡩࡥ࡮ࡲࡵࡳࡧࠣࡸ࡭ࡸࡥࡴࡪࡲࡰࡩ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦẘ")
        bstack1111ll11ll1_opy_ = config.get(bstack1ll1lll_opy_ (u"ࠧࡵࡧࡶࡸࡔࡸࡣࡩࡧࡶࡸࡷࡧࡴࡪࡱࡱࡓࡵࡺࡩࡰࡰࡶࠫẙ"), {}).get(bstack1ll1lll_opy_ (u"ࠨࡣࡥࡳࡷࡺࡂࡶ࡫࡯ࡨࡔࡴࡆࡢ࡫࡯ࡹࡷ࡫ࠧẚ"), {})
        bstack1111l1lll1l_opy_ = 0
        bstack1111ll1ll1l_opy_ = 0
        if bstack11lll1lll1_opy_.bstack11l11lllll1_opy_(config):
            bstack1111ll1ll1l_opy_ = bstack1111ll11ll1_opy_.get(bstack1ll1lll_opy_ (u"ࠩࡰࡥࡽࡌࡡࡪ࡮ࡸࡶࡪࡹࠧẛ"), 5)
            if isinstance(bstack1111ll1ll1l_opy_, str) and bstack1111ll1ll1l_opy_.endswith(bstack1ll1lll_opy_ (u"ࠪࠩࠬẜ")):
                try:
                    percentage = int(bstack1111ll1ll1l_opy_.strip(bstack1ll1lll_opy_ (u"ࠫࠪ࠭ẝ")))
                    if bstack11l1l11llll_opy_ > 0:
                        bstack1111l1lll1l_opy_ = math.ceil((percentage * bstack11l1l11llll_opy_) / 100)
                    else:
                        raise ValueError(bstack1ll1lll_opy_ (u"࡚ࠧ࡯ࡵࡣ࡯ࠤࡹ࡫ࡳࡵࡵࠣࡱࡺࡹࡴࠡࡤࡨࠤࡵࡸ࡯ࡷ࡫ࡧࡩࡩࠦࡦࡰࡴࠣࡴࡪࡸࡣࡦࡰࡷࡥ࡬࡫࠭ࡣࡣࡶࡩࡩࠦࡴࡩࡴࡨࡷ࡭ࡵ࡬ࡥࡵ࠱ࠦẞ"))
                except ValueError as e:
                    raise ValueError(bstack1ll1lll_opy_ (u"ࠨࡉ࡯ࡸࡤࡰ࡮ࡪࠠࡱࡧࡵࡧࡪࡴࡴࡢࡩࡨࠤࡻࡧ࡬ࡶࡧࠣࡪࡴࡸࠠ࡮ࡣࡻࡊࡦ࡯࡬ࡶࡴࡨࡷ࠿ࠦࡻࡾࠤẟ").format(bstack1111ll1ll1l_opy_)) from e
            else:
                bstack1111l1lll1l_opy_ = int(bstack1111ll1ll1l_opy_)
        logger.info(bstack1ll1lll_opy_ (u"ࠢࡎࡣࡻࠤ࡫ࡧࡩ࡭ࡷࡵࡩࡸࠦࡴࡩࡴࡨࡷ࡭ࡵ࡬ࡥࠢࡶࡩࡹࠦࡴࡰ࠼ࠣࡿࢂࠦࠨࡧࡴࡲࡱࠥࡩ࡯࡯ࡨ࡬࡫࠿ࠦࡻࡾࠫࠥẠ").format(bstack1111l1lll1l_opy_, bstack1111ll1ll1l_opy_))
        return bstack1111l1lll1l_opy_
    def bstack1111l1ll11l_opy_(self):
        return self.bstack1111l1ll111_opy_
    def bstack1111ll11111_opy_(self):
        return self.bstack111l11111ll_opy_
    def bstack1111ll11lll_opy_(self):
        return self.bstack1111llll111_opy_
    def __1111ll1ll11_opy_(self, enabled, mode, source=None):
        try:
            self.bstack1111l1ll111_opy_ = bool(enabled)
            if mode not in [bstack1ll1lll_opy_ (u"ࠨࡴࡨࡰࡪࡼࡡ࡯ࡶࡉ࡭ࡷࡹࡴࠨạ"), bstack1ll1lll_opy_ (u"ࠩࡵࡩࡱ࡫ࡶࡢࡰࡷࡓࡳࡲࡹࠨẢ")]:
                logger.warning(bstack1ll1lll_opy_ (u"ࠥࡍࡳࡼࡡ࡭࡫ࡧࠤࡸࡳࡡࡳࡶࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࡭ࡰࡦࡨࠤࠬࢁࡽࠨࠢࡳࡶࡴࡼࡩࡥࡧࡧ࠲ࠥࡊࡥࡧࡣࡸࡰࡹ࡯࡮ࡨࠢࡷࡳࠥ࠭ࡲࡦ࡮ࡨࡺࡦࡴࡴࡇ࡫ࡵࡷࡹ࠭࠮ࠣả").format(mode))
                mode = bstack1ll1lll_opy_ (u"ࠫࡷ࡫࡬ࡦࡸࡤࡲࡹࡌࡩࡳࡵࡷࠫẤ")
            self.bstack111l11111ll_opy_ = mode
            if source is None:
                self.bstack1111llll111_opy_ = None
            elif isinstance(source, list):
                self.bstack1111llll111_opy_ = source
            elif isinstance(source, str) and source.endswith(bstack1ll1lll_opy_ (u"ࠬ࠴ࡪࡴࡱࡱࠫấ")):
                self.bstack1111llll111_opy_ = self._1111ll11l1l_opy_(source)
            self.__111l1111lll_opy_()
        except Exception as e:
            logger.error(bstack1ll1lll_opy_ (u"ࠨࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡶࡩࡹࠦࡳ࡮ࡣࡵࡸࠥࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡ࠯ࠣࡩࡳࡧࡢ࡭ࡧࡧ࠾ࠥࢁࡽ࠭ࠢࡰࡳࡩ࡫࠺ࠡࡽࢀ࠰ࠥࡹ࡯ࡶࡴࡦࡩ࠿ࠦࡻࡾ࠰ࠣࡉࡷࡸ࡯ࡳ࠼ࠣࡿࢂࠨẦ").format(enabled, mode, source, e))
    def bstack1111l1lll11_opy_(self):
        return self.bstack1111ll1llll_opy_
    def __1111lllllll_opy_(self, value):
        self.bstack1111ll1llll_opy_ = bool(value)
        self.__111l1111lll_opy_()
    def bstack1111l1l1lll_opy_(self):
        return self.bstack1111ll1l111_opy_
    def __1111l1l1ll1_opy_(self, value):
        self.bstack1111ll1l111_opy_ = bool(value)
        self.__111l1111lll_opy_()
    def bstack1111lllll1l_opy_(self):
        return self.bstack1111l1l11l1_opy_
    def __111l1111111_opy_(self, value):
        self.bstack1111l1l11l1_opy_ = bool(value)
        self.__111l1111lll_opy_()
    def __111l1111lll_opy_(self):
        if self.bstack1111l1ll111_opy_:
            self.bstack1111ll1llll_opy_ = False
            self.bstack1111ll1l111_opy_ = False
            self.bstack1111l1l11l1_opy_ = False
            self.bstack1111lllll11_opy_.enable(bstack1111lll1l1l_opy_)
        elif self.bstack1111ll1llll_opy_:
            self.bstack1111ll1l111_opy_ = False
            self.bstack1111l1l11l1_opy_ = False
            self.bstack1111l1ll111_opy_ = False
            self.bstack1111lllll11_opy_.enable(bstack1111ll1l1ll_opy_)
        elif self.bstack1111ll1l111_opy_:
            self.bstack1111ll1llll_opy_ = False
            self.bstack1111l1l11l1_opy_ = False
            self.bstack1111l1ll111_opy_ = False
            self.bstack1111lllll11_opy_.enable(bstack1111lll1l11_opy_)
        elif self.bstack1111l1l11l1_opy_:
            self.bstack1111ll1llll_opy_ = False
            self.bstack1111ll1l111_opy_ = False
            self.bstack1111l1ll111_opy_ = False
            self.bstack1111lllll11_opy_.enable(bstack1111lll1ll1_opy_)
        else:
            self.bstack1111lllll11_opy_.disable()
    def bstack1ll11lll1l_opy_(self):
        return self.bstack1111lllll11_opy_.bstack1111ll111l1_opy_()
    def bstack1ll1l1l1ll_opy_(self):
        if self.bstack1111lllll11_opy_.bstack1111ll111l1_opy_():
            return self.bstack1111lllll11_opy_.get_name()
        return None
    def _1111ll11l1l_opy_(self, bstack111l11111l1_opy_):
        bstack1ll1lll_opy_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࠡࠢࠣࠤࡕࡧࡲࡴࡧࠣࡎࡘࡕࡎࠡࡵࡲࡹࡷࡩࡥࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡡ࡯ࡦࠣࡪࡴࡸ࡭ࡢࡶࠣ࡭ࡹࠦࡦࡰࡴࠣࡷࡲࡧࡲࡵࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࡂࡴࡪࡷ࠿ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡸࡵࡵࡳࡥࡨࡣ࡫࡯࡬ࡦࡡࡳࡥࡹ࡮ࠠࠩࡵࡷࡶ࠮ࡀࠠࡑࡣࡷ࡬ࠥࡺ࡯ࠡࡶ࡫ࡩࠥࡐࡓࡐࡐࠣࡧࡴࡴࡦࡪࡩࡸࡶࡦࡺࡩࡰࡰࠣࡪ࡮ࡲࡥࠋࠢࠣࠤࠥࠦࠠࠡࠢࡕࡩࡹࡻࡲ࡯ࡵ࠽ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࡯࡭ࡸࡺ࠺ࠡࡈࡲࡶࡲࡧࡴࡵࡧࡧࠤࡱ࡯ࡳࡵࠢࡲࡪࠥࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺࠢࡦࡳࡳ࡬ࡩࡨࡷࡵࡥࡹ࡯࡯࡯ࡵࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢầ")
        if not os.path.isfile(bstack111l11111l1_opy_):
            logger.error(bstack1ll1lll_opy_ (u"ࠣࡕࡲࡹࡷࡩࡥࠡࡨ࡬ࡰࡪࠦࠧࡼࡿࠪࠤࡩࡵࡥࡴࠢࡱࡳࡹࠦࡥࡹ࡫ࡶࡸ࠳ࠨẨ").format(bstack111l11111l1_opy_))
            return []
        data = None
        try:
            with open(bstack111l11111l1_opy_, bstack1ll1lll_opy_ (u"ࠤࡵࠦẩ")) as f:
                data = json.load(f)
        except json.JSONDecodeError as e:
            logger.error(bstack1ll1lll_opy_ (u"ࠥࡉࡷࡸ࡯ࡳࠢࡳࡥࡷࡹࡩ࡯ࡩࠣࡎࡘࡕࡎࠡࡨࡵࡳࡲࠦࡳࡰࡷࡵࡧࡪࠦࡦࡪ࡮ࡨࠤࠬࢁࡽࠨ࠼ࠣࡿࢂࠨẪ").format(bstack111l11111l1_opy_, e))
            return []
        _1111lll1lll_opy_ = None
        _1111l1l111l_opy_ = None
        def _1111ll11l11_opy_():
            bstack111l111111l_opy_ = {}
            bstack1111l1l1l11_opy_ = {}
            try:
                if self.bstack1111l1llll1_opy_.startswith(bstack1ll1lll_opy_ (u"ࠫࢀ࠭ẫ")) and self.bstack1111l1llll1_opy_.endswith(bstack1ll1lll_opy_ (u"ࠬࢃࠧẬ")):
                    bstack111l111111l_opy_ = json.loads(self.bstack1111l1llll1_opy_)
                else:
                    bstack111l111111l_opy_ = dict(item.split(bstack1ll1lll_opy_ (u"࠭࠺ࠨậ")) for item in self.bstack1111l1llll1_opy_.split(bstack1ll1lll_opy_ (u"ࠧ࠭ࠩẮ")) if bstack1ll1lll_opy_ (u"ࠨ࠼ࠪắ") in item) if self.bstack1111l1llll1_opy_ else {}
                if self.bstack1111llllll1_opy_.startswith(bstack1ll1lll_opy_ (u"ࠩࡾࠫẰ")) and self.bstack1111llllll1_opy_.endswith(bstack1ll1lll_opy_ (u"ࠪࢁࠬằ")):
                    bstack1111l1l1l11_opy_ = json.loads(self.bstack1111llllll1_opy_)
                else:
                    bstack1111l1l1l11_opy_ = dict(item.split(bstack1ll1lll_opy_ (u"ࠫ࠿࠭Ẳ")) for item in self.bstack1111llllll1_opy_.split(bstack1ll1lll_opy_ (u"ࠬ࠲ࠧẳ")) if bstack1ll1lll_opy_ (u"࠭࠺ࠨẴ") in item) if self.bstack1111llllll1_opy_ else {}
            except json.JSONDecodeError as e:
                logger.error(bstack1ll1lll_opy_ (u"ࠢࡆࡴࡵࡳࡷࠦࡰࡢࡴࡶ࡭ࡳ࡭ࠠࡧࡧࡤࡸࡺࡸࡥࠡࡤࡵࡥࡳࡩࡨࠡ࡯ࡤࡴࡵ࡯࡮ࡨࡵ࠽ࠤࢀࢃࠢẵ").format(e))
            logger.debug(bstack1ll1lll_opy_ (u"ࠣࡈࡨࡥࡹࡻࡲࡦࠢࡥࡶࡦࡴࡣࡩࠢࡰࡥࡵࡶࡩ࡯ࡩࡶࠤ࡫ࡸ࡯࡮ࠢࡨࡲࡻࡀࠠࡼࡿ࠯ࠤࡈࡒࡉ࠻ࠢࡾࢁࠧẶ").format(bstack111l111111l_opy_, bstack1111l1l1l11_opy_))
            return bstack111l111111l_opy_, bstack1111l1l1l11_opy_
        if _1111lll1lll_opy_ is None or _1111l1l111l_opy_ is None:
            _1111lll1lll_opy_, _1111l1l111l_opy_ = _1111ll11l11_opy_()
        def bstack1111ll1l1l1_opy_(name, bstack1111lll1111_opy_):
            if name in _1111l1l111l_opy_:
                return _1111l1l111l_opy_[name]
            if name in _1111lll1lll_opy_:
                return _1111lll1lll_opy_[name]
            if bstack1111lll1111_opy_.get(bstack1ll1lll_opy_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡅࡶࡦࡴࡣࡩࠩặ")):
                return bstack1111lll1111_opy_[bstack1ll1lll_opy_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡆࡷࡧ࡮ࡤࡪࠪẸ")]
            return None
        if isinstance(data, dict):
            bstack1111ll1l11l_opy_ = []
            bstack1111l1ll1l1_opy_ = re.compile(bstack1ll1lll_opy_ (u"ࡶࠬࡤ࡛ࡂ࠯࡝࠴࠲࠿࡟࡞࠭ࠧࠫẹ"))
            for name, bstack1111lll1111_opy_ in data.items():
                if not isinstance(bstack1111lll1111_opy_, dict):
                    continue
                if not bstack1111lll1111_opy_.get(bstack1ll1lll_opy_ (u"ࠬࡻࡲ࡭ࠩẺ")):
                    logger.warning(bstack1ll1lll_opy_ (u"ࠨࡒࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࡙ࠣࡗࡒࠠࡪࡵࠣࡱ࡮ࡹࡳࡪࡰࡪࠤ࡫ࡵࡲࠡࡵࡲࡹࡷࡩࡥࠡࠩࡾࢁࠬࡀࠠࡼࡿࠥẻ").format(name, bstack1111lll1111_opy_))
                    continue
                if not bstack1111l1ll1l1_opy_.match(name):
                    logger.warning(bstack1ll1lll_opy_ (u"ࠢࡊࡰࡹࡥࡱ࡯ࡤࠡࡵࡲࡹࡷࡩࡥࠡ࡫ࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠥ࡬࡯ࡳ࡯ࡤࡸࠥ࡬࡯ࡳࠢࠪࡿࢂ࠭࠺ࠡࡽࢀࠦẼ").format(name, bstack1111lll1111_opy_))
                    continue
                if len(name) > 30 or len(name) < 1:
                    logger.warning(bstack1ll1lll_opy_ (u"ࠣࡕࡲࡹࡷࡩࡥࠡ࡫ࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠥ࠭ࡻࡾࠩࠣࡱࡺࡹࡴࠡࡪࡤࡺࡪࠦࡡࠡ࡮ࡨࡲ࡬ࡺࡨࠡࡤࡨࡸࡼ࡫ࡥ࡯ࠢ࠴ࠤࡦࡴࡤࠡ࠵࠳ࠤࡨ࡮ࡡࡳࡣࡦࡸࡪࡸࡳ࠯ࠤẽ").format(name))
                    continue
                bstack1111lll1111_opy_ = bstack1111lll1111_opy_.copy()
                bstack1111lll1111_opy_[bstack1ll1lll_opy_ (u"ࠩࡱࡥࡲ࡫ࠧẾ")] = name
                bstack1111lll1111_opy_[bstack1ll1lll_opy_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡆࡷࡧ࡮ࡤࡪࠪế")] = bstack1111ll1l1l1_opy_(name, bstack1111lll1111_opy_)
                if not bstack1111lll1111_opy_.get(bstack1ll1lll_opy_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡇࡸࡡ࡯ࡥ࡫ࠫỀ")):
                    logger.warning(bstack1ll1lll_opy_ (u"ࠧࡌࡥࡢࡶࡸࡶࡪࠦࡢࡳࡣࡱࡧ࡭ࠦ࡮ࡰࡶࠣࡷࡵ࡫ࡣࡪࡨ࡬ࡩࡩࠦࡦࡰࡴࠣࡷࡴࡻࡲࡤࡧࠣࠫࢀࢃࠧ࠻ࠢࡾࢁࠧề").format(name, bstack1111lll1111_opy_))
                    continue
                if bstack1111lll1111_opy_.get(bstack1ll1lll_opy_ (u"࠭ࡢࡢࡵࡨࡆࡷࡧ࡮ࡤࡪࠪỂ")) and bstack1111lll1111_opy_[bstack1ll1lll_opy_ (u"ࠧࡣࡣࡶࡩࡇࡸࡡ࡯ࡥ࡫ࠫể")] == bstack1111lll1111_opy_[bstack1ll1lll_opy_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡄࡵࡥࡳࡩࡨࠨỄ")]:
                    logger.warning(bstack1ll1lll_opy_ (u"ࠤࡉࡩࡦࡺࡵࡳࡧࠣࡦࡷࡧ࡮ࡤࡪࠣࡥࡳࡪࠠࡣࡣࡶࡩࠥࡨࡲࡢࡰࡦ࡬ࠥࡩࡡ࡯ࡰࡲࡸࠥࡨࡥࠡࡶ࡫ࡩࠥࡹࡡ࡮ࡧࠣࡪࡴࡸࠠࡴࡱࡸࡶࡨ࡫ࠠࠨࡽࢀࠫ࠿ࠦࡻࡾࠤễ").format(name, bstack1111lll1111_opy_))
                    continue
                bstack1111ll1l11l_opy_.append(bstack1111lll1111_opy_)
            return bstack1111ll1l11l_opy_
        return data
    def bstack111l111l1ll_opy_(self):
        data = {
            bstack1ll1lll_opy_ (u"ࠪࡶࡺࡴ࡟ࡴ࡯ࡤࡶࡹࡥࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠩỆ"): {
                bstack1ll1lll_opy_ (u"ࠫࡪࡴࡡࡣ࡮ࡨࡨࠬệ"): self.bstack1111l1ll11l_opy_(),
                bstack1ll1lll_opy_ (u"ࠬࡳ࡯ࡥࡧࠪỈ"): self.bstack1111ll11111_opy_(),
                bstack1ll1lll_opy_ (u"࠭ࡳࡰࡷࡵࡧࡪ࠭ỉ"): self.bstack1111ll11lll_opy_()
            }
        }
        return data
    def bstack111l1111ll1_opy_(self, config):
        bstack1111ll1lll1_opy_ = {}
        bstack1111ll1lll1_opy_[bstack1ll1lll_opy_ (u"ࠧࡳࡷࡱࡣࡸࡳࡡࡳࡶࡢࡷࡪࡲࡥࡤࡶ࡬ࡳࡳ࠭Ị")] = {
            bstack1ll1lll_opy_ (u"ࠨࡧࡱࡥࡧࡲࡥࡥࠩị"): self.bstack1111l1ll11l_opy_(),
            bstack1ll1lll_opy_ (u"ࠩࡰࡳࡩ࡫ࠧỌ"): self.bstack1111ll11111_opy_()
        }
        bstack1111ll1lll1_opy_[bstack1ll1lll_opy_ (u"ࠪࡶࡪࡸࡵ࡯ࡡࡳࡶࡪࡼࡩࡰࡷࡶࡰࡾࡥࡦࡢ࡫࡯ࡩࡩ࠭ọ")] = {
            bstack1ll1lll_opy_ (u"ࠫࡪࡴࡡࡣ࡮ࡨࡨࠬỎ"): self.bstack1111l1l1lll_opy_()
        }
        bstack1111ll1lll1_opy_[bstack1ll1lll_opy_ (u"ࠬࡸࡵ࡯ࡡࡳࡶࡪࡼࡩࡰࡷࡶࡰࡾࡥࡦࡢ࡫࡯ࡩࡩࡥࡦࡪࡴࡶࡸࠬỏ")] = {
            bstack1ll1lll_opy_ (u"࠭ࡥ࡯ࡣࡥࡰࡪࡪࠧỐ"): self.bstack1111l1lll11_opy_()
        }
        bstack1111ll1lll1_opy_[bstack1ll1lll_opy_ (u"ࠧࡴ࡭࡬ࡴࡤ࡬ࡡࡪ࡮࡬ࡲ࡬ࡥࡡ࡯ࡦࡢࡪࡱࡧ࡫ࡺࠩố")] = {
            bstack1ll1lll_opy_ (u"ࠨࡧࡱࡥࡧࡲࡥࡥࠩỒ"): self.bstack1111lllll1l_opy_()
        }
        if self.bstack1111ll1l1_opy_(config):
            bstack1111ll1lll1_opy_[bstack1ll1lll_opy_ (u"ࠩࡵࡩࡹࡸࡹࡠࡶࡨࡷࡹࡹ࡟ࡰࡰࡢࡪࡦ࡯࡬ࡶࡴࡨࠫồ")] = {
                bstack1ll1lll_opy_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࡧࠫỔ"): True,
                bstack1ll1lll_opy_ (u"ࠫࡲࡧࡸࡠࡴࡨࡸࡷ࡯ࡥࡴࠩổ"): self.bstack11l1l1111l_opy_(config)
            }
        if self.bstack11l11lllll1_opy_(config):
            bstack1111ll1lll1_opy_[bstack1ll1lll_opy_ (u"ࠬࡧࡢࡰࡴࡷࡣࡧࡻࡩ࡭ࡦࡢࡳࡳࡥࡦࡢ࡫࡯ࡹࡷ࡫ࠧỖ")] = {
                bstack1ll1lll_opy_ (u"࠭ࡥ࡯ࡣࡥࡰࡪࡪࠧỗ"): True,
                bstack1ll1lll_opy_ (u"ࠧ࡮ࡣࡻࡣ࡫ࡧࡩ࡭ࡷࡵࡩࡸ࠭Ộ"): self.bstack11l1l1111ll_opy_(config)
            }
        return bstack1111ll1lll1_opy_
    def bstack111l1l1l_opy_(self, config):
        bstack1ll1lll_opy_ (u"ࠣࠤࠥࠎࠥࠦࠠࠡࠢࠣࠤࠥࡉ࡯࡭࡮ࡨࡧࡹࡹࠠࡣࡷ࡬ࡰࡩࠦࡤࡢࡶࡤࠤࡧࡿࠠ࡮ࡣ࡮࡭ࡳ࡭ࠠࡢࠢࡦࡥࡱࡲࠠࡵࡱࠣࡸ࡭࡫ࠠࡤࡱ࡯ࡰࡪࡩࡴ࠮ࡤࡸ࡭ࡱࡪ࠭ࡥࡣࡷࡥࠥ࡫࡮ࡥࡲࡲ࡭ࡳࡺ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࡄࡶ࡬ࡹ࠺ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡢࡶ࡫࡯ࡨࡤࡻࡵࡪࡦࠣࠬࡸࡺࡲࠪ࠼ࠣࡘ࡭࡫ࠠࡖࡗࡌࡈࠥࡵࡦࠡࡶ࡫ࡩࠥࡨࡵࡪ࡮ࡧࠤࡹࡵࠠࡤࡱ࡯ࡰࡪࡩࡴࠡࡦࡤࡸࡦࠦࡦࡰࡴ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡘࡥࡵࡷࡵࡲࡸࡀࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡪࡩࡤࡶ࠽ࠤࡗ࡫ࡳࡱࡱࡱࡷࡪࠦࡦࡳࡱࡰࠤࡹ࡮ࡥࠡࡥࡲࡰࡱ࡫ࡣࡵ࠯ࡥࡹ࡮ࡲࡤ࠮ࡦࡤࡸࡦࠦࡥ࡯ࡦࡳࡳ࡮ࡴࡴ࠭ࠢࡲࡶࠥࡔ࡯࡯ࡧࠣ࡭࡫ࠦࡦࡢ࡫࡯ࡩࡩ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦộ")
        if not (config.get(bstack1ll1lll_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬỚ"), None) in bstack11l1ll11l11_opy_ and self.bstack1111l1ll11l_opy_()):
            return None
        bstack111l1111l1l_opy_ = os.environ.get(bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚ࡈࡖࡄࡢ࡙࡚ࡏࡄࠨớ"), None)
        logger.debug(bstack1ll1lll_opy_ (u"ࠦࡠࡩ࡯࡭࡮ࡨࡧࡹࡈࡵࡪ࡮ࡧࡈࡦࡺࡡ࡞ࠢࡆࡳࡱࡲࡥࡤࡶ࡬ࡲ࡬ࠦࡢࡶ࡫࡯ࡨࠥࡪࡡࡵࡣࠣࡪࡴࡸࠠࡣࡷ࡬ࡰࡩࠦࡕࡖࡋࡇ࠾ࠥࢁࡽࠣỜ").format(bstack111l1111l1l_opy_))
        try:
            bstack11ll111l1l1_opy_ = bstack1ll1lll_opy_ (u"ࠧࡺࡥࡴࡶࡲࡶࡨ࡮ࡥࡴࡶࡵࡥࡹ࡯࡯࡯࠱ࡤࡴ࡮࠵ࡶ࠲࠱ࡥࡹ࡮ࡲࡤࡴ࠱ࡾࢁ࠴ࡩ࡯࡭࡮ࡨࡧࡹ࠳ࡢࡶ࡫࡯ࡨ࠲ࡪࡡࡵࡣࠥờ").format(bstack111l1111l1l_opy_)
            payload = {
                bstack1ll1lll_opy_ (u"ࠨࡰࡳࡱ࡭ࡩࡨࡺࡎࡢ࡯ࡨࠦỞ"): config.get(bstack1ll1lll_opy_ (u"ࠧࡱࡴࡲ࡮ࡪࡩࡴࡏࡣࡰࡩࠬở"), bstack1ll1lll_opy_ (u"ࠨࠩỠ")),
                bstack1ll1lll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠧỡ"): config.get(bstack1ll1lll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭Ợ"), os.path.basename(os.path.abspath(os.getcwd()))),
                bstack1ll1lll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡕࡹࡳࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠤợ"): os.environ.get(bstack1ll1lll_opy_ (u"ࠧࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡇ࡛ࡉࡍࡆࡢࡖ࡚ࡔ࡟ࡊࡆࡈࡒ࡙ࡏࡆࡊࡇࡕࠦỤ"), bstack1ll1lll_opy_ (u"ࠨࠢụ")),
                bstack1ll1lll_opy_ (u"ࠢ࡯ࡱࡧࡩࡎࡴࡤࡦࡺࠥỦ"): int(os.environ.get(bstack1ll1lll_opy_ (u"ࠣࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡏࡑࡇࡉࡤࡏࡎࡅࡇ࡛ࠦủ")) or bstack1ll1lll_opy_ (u"ࠤ࠳ࠦỨ")),
                bstack1ll1lll_opy_ (u"ࠥࡸࡴࡺࡡ࡭ࡐࡲࡨࡪࡹࠢứ"): int(os.environ.get(bstack1ll1lll_opy_ (u"ࠦࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡘࡔ࡚ࡁࡍࡡࡑࡓࡉࡋ࡟ࡄࡑࡘࡒ࡙ࠨỪ")) or bstack1ll1lll_opy_ (u"ࠧ࠷ࠢừ")),
                bstack1ll1lll_opy_ (u"ࠨࡨࡰࡵࡷࡍࡳ࡬࡯ࠣỬ"): get_host_info(),
            }
            logger.debug(bstack1ll1lll_opy_ (u"ࠢ࡜ࡥࡲࡰࡱ࡫ࡣࡵࡄࡸ࡭ࡱࡪࡄࡢࡶࡤࡡ࡙ࠥࡥ࡯ࡦ࡬ࡲ࡬ࠦࡢࡶ࡫࡯ࡨࠥࡪࡡࡵࡣࠣࡴࡦࡿ࡬ࡰࡣࡧ࠾ࠥࢁࡽࠣử").format(payload))
            response = bstack11ll111l111_opy_.bstack1111ll111ll_opy_(bstack11ll111l1l1_opy_, payload)
            if response:
                logger.debug(bstack1ll1lll_opy_ (u"ࠣ࡝ࡦࡳࡱࡲࡥࡤࡶࡅࡹ࡮ࡲࡤࡅࡣࡷࡥࡢࠦࡂࡶ࡫࡯ࡨࠥࡪࡡࡵࡣࠣࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡴࡴࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠼ࠣࡿࢂࠨỮ").format(response))
                return response
            else:
                logger.error(bstack1ll1lll_opy_ (u"ࠤ࡞ࡧࡴࡲ࡬ࡦࡥࡷࡆࡺ࡯࡬ࡥࡆࡤࡸࡦࡣࠠࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡧࡴࡲ࡬ࡦࡥࡷࠤࡧࡻࡩ࡭ࡦࠣࡨࡦࡺࡡࠡࡨࡲࡶࠥࡨࡵࡪ࡮ࡧࠤ࡚࡛ࡉࡅ࠼ࠣࡿࢂࠨữ").format(bstack111l1111l1l_opy_))
                return None
        except Exception as e:
            logger.error(bstack1ll1lll_opy_ (u"ࠥ࡟ࡨࡵ࡬࡭ࡧࡦࡸࡇࡻࡩ࡭ࡦࡇࡥࡹࡧ࡝ࠡࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡤࡱ࡯ࡰࡪࡩࡴࡪࡰࡪࠤࡧࡻࡩ࡭ࡦࠣࡨࡦࡺࡡࠡࡨࡲࡶࠥࡨࡵࡪ࡮ࡧࠤ࡚࡛ࡉࡅࠢࡾࢁ࠿ࠦࡻࡾࠤỰ").format(bstack111l1111l1l_opy_, e))
            return None