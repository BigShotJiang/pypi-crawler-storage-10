# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import os
import json
from bstack_utils.bstack1ll1ll1111_opy_ import get_logger
logger = get_logger(__name__)
class bstack11ll11l1111_opy_(object):
  bstack1lll111l1_opy_ = os.path.join(os.path.expanduser(bstack1ll1lll_opy_ (u"ࠧࡿࠩᝨ")), bstack1ll1lll_opy_ (u"ࠨ࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠨᝩ"))
  bstack11ll111lll1_opy_ = os.path.join(bstack1lll111l1_opy_, bstack1ll1lll_opy_ (u"ࠩࡦࡳࡲࡳࡡ࡯ࡦࡶ࠲࡯ࡹ࡯࡯ࠩᝪ"))
  commands_to_wrap = None
  perform_scan = None
  bstack1l11l1l11_opy_ = None
  bstack11ll11l11l_opy_ = None
  bstack11ll1ll1l11_opy_ = None
  bstack11ll1ll11l1_opy_ = None
  def __new__(cls):
    if not hasattr(cls, bstack1ll1lll_opy_ (u"ࠪ࡭ࡳࡹࡴࡢࡰࡦࡩࠬᝫ")):
      cls.instance = super(bstack11ll11l1111_opy_, cls).__new__(cls)
      cls.instance.bstack11ll111llll_opy_()
    return cls.instance
  def bstack11ll111llll_opy_(self):
    try:
      with open(self.bstack11ll111lll1_opy_, bstack1ll1lll_opy_ (u"ࠫࡷ࠭ᝬ")) as bstack11l111llll_opy_:
        bstack11ll111ll1l_opy_ = bstack11l111llll_opy_.read()
        data = json.loads(bstack11ll111ll1l_opy_)
        if bstack1ll1lll_opy_ (u"ࠬࡩ࡯࡮࡯ࡤࡲࡩࡹࠧ᝭") in data:
          self.bstack11ll1l1lll1_opy_(data[bstack1ll1lll_opy_ (u"࠭ࡣࡰ࡯ࡰࡥࡳࡪࡳࠨᝮ")])
        if bstack1ll1lll_opy_ (u"ࠧࡴࡥࡵ࡭ࡵࡺࡳࠨᝯ") in data:
          self.bstack11l1l11lll_opy_(data[bstack1ll1lll_opy_ (u"ࠨࡵࡦࡶ࡮ࡶࡴࡴࠩᝰ")])
        if bstack1ll1lll_opy_ (u"ࠩࡱࡳࡳࡈࡓࡵࡣࡦ࡯ࡎࡴࡦࡳࡣࡄ࠵࠶ࡿࡃࡩࡴࡲࡱࡪࡕࡰࡵ࡫ࡲࡲࡸ࠭᝱") in data:
          self.bstack11ll111ll11_opy_(data[bstack1ll1lll_opy_ (u"ࠪࡲࡴࡴࡂࡔࡶࡤࡧࡰࡏ࡮ࡧࡴࡤࡅ࠶࠷ࡹࡄࡪࡵࡳࡲ࡫ࡏࡱࡶ࡬ࡳࡳࡹࠧᝲ")])
    except:
      pass
  def bstack11ll111ll11_opy_(self, bstack11ll1ll11l1_opy_):
    if bstack11ll1ll11l1_opy_ != None:
      self.bstack11ll1ll11l1_opy_ = bstack11ll1ll11l1_opy_
  def bstack11l1l11lll_opy_(self, scripts):
    if scripts != None:
      self.perform_scan = scripts.get(bstack1ll1lll_opy_ (u"ࠫࡸࡩࡡ࡯ࠩᝳ"),bstack1ll1lll_opy_ (u"ࠬ࠭᝴"))
      self.bstack1l11l1l11_opy_ = scripts.get(bstack1ll1lll_opy_ (u"࠭ࡧࡦࡶࡕࡩࡸࡻ࡬ࡵࡵࠪ᝵"),bstack1ll1lll_opy_ (u"ࠧࠨ᝶"))
      self.bstack11ll11l11l_opy_ = scripts.get(bstack1ll1lll_opy_ (u"ࠨࡩࡨࡸࡗ࡫ࡳࡶ࡮ࡷࡷࡘࡻ࡭࡮ࡣࡵࡽࠬ᝷"),bstack1ll1lll_opy_ (u"ࠩࠪ᝸"))
      self.bstack11ll1ll1l11_opy_ = scripts.get(bstack1ll1lll_opy_ (u"ࠪࡷࡦࡼࡥࡓࡧࡶࡹࡱࡺࡳࠨ᝹"),bstack1ll1lll_opy_ (u"ࠫࠬ᝺"))
  def bstack11ll1l1lll1_opy_(self, commands_to_wrap):
    if commands_to_wrap != None and len(commands_to_wrap) != 0:
      self.commands_to_wrap = commands_to_wrap
  def store(self):
    try:
      with open(self.bstack11ll111lll1_opy_, bstack1ll1lll_opy_ (u"ࠬࡽࠧ᝻")) as file:
        json.dump({
          bstack1ll1lll_opy_ (u"ࠨࡣࡰ࡯ࡰࡥࡳࡪࡳࠣ᝼"): self.commands_to_wrap,
          bstack1ll1lll_opy_ (u"ࠢࡴࡥࡵ࡭ࡵࡺࡳࠣ᝽"): {
            bstack1ll1lll_opy_ (u"ࠣࡵࡦࡥࡳࠨ᝾"): self.perform_scan,
            bstack1ll1lll_opy_ (u"ࠤࡪࡩࡹࡘࡥࡴࡷ࡯ࡸࡸࠨ᝿"): self.bstack1l11l1l11_opy_,
            bstack1ll1lll_opy_ (u"ࠥ࡫ࡪࡺࡒࡦࡵࡸࡰࡹࡹࡓࡶ࡯ࡰࡥࡷࡿࠢក"): self.bstack11ll11l11l_opy_,
            bstack1ll1lll_opy_ (u"ࠦࡸࡧࡶࡦࡔࡨࡷࡺࡲࡴࡴࠤខ"): self.bstack11ll1ll1l11_opy_
          },
          bstack1ll1lll_opy_ (u"ࠧࡴ࡯࡯ࡄࡖࡸࡦࡩ࡫ࡊࡰࡩࡶࡦࡇ࠱࠲ࡻࡆ࡬ࡷࡵ࡭ࡦࡑࡳࡸ࡮ࡵ࡮ࡴࠤគ"): self.bstack11ll1ll11l1_opy_
        }, file)
    except Exception as e:
      logger.error(bstack1ll1lll_opy_ (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡨࡪ࡮ࡨࠤࡸࡺ࡯ࡳ࡫ࡱ࡫ࠥࡩ࡯࡮࡯ࡤࡲࡩࡹ࠺ࠡࡽࢀࠦឃ").format(e))
      pass
  def bstack1ll1l1l11l_opy_(self, command_name):
    try:
      return any(command.get(bstack1ll1lll_opy_ (u"ࠧ࡯ࡣࡰࡩࠬង")) == command_name for command in self.commands_to_wrap)
    except:
      return False
bstack1l11llll_opy_ = bstack11ll11l1111_opy_()