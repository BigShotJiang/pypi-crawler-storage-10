# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
from time import sleep
from datetime import datetime
from urllib.parse import urlencode
from bstack_utils.bstack11ll11111l1_opy_ import bstack11ll111l111_opy_
from bstack_utils.constants import *
import json
class bstack11lll1l11l_opy_:
    def __init__(self, bstack11l111l1l1_opy_, bstack11ll11111ll_opy_):
        self.bstack11l111l1l1_opy_ = bstack11l111l1l1_opy_
        self.bstack11ll11111ll_opy_ = bstack11ll11111ll_opy_
        self.bstack11ll111111l_opy_ = None
    def __call__(self):
        bstack11ll1111l11_opy_ = {}
        while True:
            self.bstack11ll111111l_opy_ = bstack11ll1111l11_opy_.get(
                bstack1ll1lll_opy_ (u"ࠬࡴࡥࡹࡶࡢࡴࡴࡲ࡬ࡠࡶ࡬ࡱࡪ࠭ញ"),
                int(datetime.now().timestamp() * 1000)
            )
            bstack11ll111l11l_opy_ = self.bstack11ll111111l_opy_ - int(datetime.now().timestamp() * 1000)
            if bstack11ll111l11l_opy_ > 0:
                sleep(bstack11ll111l11l_opy_ / 1000)
            params = {
                bstack1ll1lll_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭ដ"): self.bstack11l111l1l1_opy_,
                bstack1ll1lll_opy_ (u"ࠧࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪឋ"): int(datetime.now().timestamp() * 1000)
            }
            bstack11ll1111l1l_opy_ = bstack1ll1lll_opy_ (u"ࠣࡪࡷࡸࡵࡹ࠺࠰࠱ࠥឌ") + bstack11ll1111ll1_opy_ + bstack1ll1lll_opy_ (u"ࠤ࠲ࡥࡺࡺ࡯࡮ࡣࡷࡩ࠴ࡧࡰࡪ࠱ࡹ࠵࠴ࠨឍ")
            if self.bstack11ll11111ll_opy_.lower() == bstack1ll1lll_opy_ (u"ࠥࡶࡪࡹࡵ࡭ࡶࡶࠦណ"):
                bstack11ll1111l11_opy_ = bstack11ll111l111_opy_.results(bstack11ll1111l1l_opy_, params)
            else:
                bstack11ll1111l11_opy_ = bstack11ll111l111_opy_.bstack11ll1111lll_opy_(bstack11ll1111l1l_opy_, params)
            if str(bstack11ll1111l11_opy_.get(bstack1ll1lll_opy_ (u"ࠫࡸࡺࡡࡵࡷࡶࠫត"), bstack1ll1lll_opy_ (u"ࠬ࠸࠰࠱ࠩថ"))) != bstack1ll1lll_opy_ (u"࠭࠴࠱࠶ࠪទ"):
                break
        return bstack11ll1111l11_opy_.get(bstack1ll1lll_opy_ (u"ࠧࡥࡣࡷࡥࠬធ"), bstack11ll1111l11_opy_)