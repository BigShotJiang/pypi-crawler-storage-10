# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
from bstack_utils.constants import bstack11ll111l1ll_opy_
def bstack11l1l111ll_opy_(bstack11ll111l1l1_opy_):
    from browserstack_sdk.sdk_cli.cli import cli
    from bstack_utils.helper import bstack1l1111l11l_opy_
    host = bstack1l1111l11l_opy_(cli.config, [bstack1ll1lll_opy_ (u"ࠣࡣࡳ࡭ࡸࠨច"), bstack1ll1lll_opy_ (u"ࠤࡤࡹࡹࡵ࡭ࡢࡶࡨࠦឆ"), bstack1ll1lll_opy_ (u"ࠥࡥࡵ࡯ࠢជ")], bstack11ll111l1ll_opy_)
    return bstack1ll1lll_opy_ (u"ࠫࢀࢃ࠯ࡼࡿࠪឈ").format(host, bstack11ll111l1l1_opy_)