# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import collections
import datetime
import json
import os
import platform
import re
import subprocess
import traceback
import tempfile
import multiprocessing
import threading
import sys
import logging
from math import ceil
from unittest import result
import urllib
from urllib.parse import urlparse
import copy
import zipfile
import git
import requests
from packaging import version
from bstack_utils.config import Config
from bstack_utils.constants import (bstack1l1ll1l1l1_opy_, bstack111l1lll1_opy_, bstack11ll1111l_opy_,
                                    bstack11l1l1ll111_opy_, bstack11l1l1lll11_opy_, bstack11l1l1l111l_opy_, bstack11l1lll1l11_opy_)
from bstack_utils.measure import measure
from bstack_utils.messages import bstack1l1lll11ll_opy_, bstack1111ll1ll_opy_
from bstack_utils.proxy import bstack1l111l1111_opy_, bstack1ll1111ll1_opy_
from bstack_utils.constants import *
from bstack_utils import bstack1ll1ll1111_opy_
from bstack_utils.bstack11l1111l_opy_ import bstack11l1l111ll_opy_
from browserstack_sdk._version import __version__
bstack11l1l11l_opy_ = Config.bstack1l1l111l_opy_()
logger = bstack1ll1ll1111_opy_.get_logger(__name__, bstack1ll1ll1111_opy_.bstack1lll1l111ll_opy_())
def bstack11ll1ll1ll1_opy_(config):
    return config[bstack1ll1lll_opy_ (u"ࠫࡺࡹࡥࡳࡐࡤࡱࡪ࠭ᬫ")]
def bstack11ll1l111ll_opy_(config):
    return config[bstack1ll1lll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨᬬ")]
def bstack1111l1lll_opy_():
    try:
        import playwright
        return True
    except ImportError:
        return False
def bstack111ll1l111l_opy_(obj):
    values = []
    bstack111lllllll1_opy_ = re.compile(bstack1ll1lll_opy_ (u"ࡸࠢ࡟ࡅࡘࡗ࡙ࡕࡍࡠࡖࡄࡋࡤࡢࡤࠬࠦࠥᬭ"), re.I)
    for key in obj.keys():
        if bstack111lllllll1_opy_.match(key):
            values.append(obj[key])
    return values
def bstack111ll1l11ll_opy_(config):
    tags = []
    tags.extend(bstack111ll1l111l_opy_(os.environ))
    tags.extend(bstack111ll1l111l_opy_(config))
    return tags
def bstack11l11111l11_opy_(markers):
    tags = []
    for marker in markers:
        tags.append(marker.name)
    return tags
def bstack111ll111ll1_opy_(bstack11l1111l1ll_opy_):
    if not bstack11l1111l1ll_opy_:
        return bstack1ll1lll_opy_ (u"ࠧࠨᬮ")
    return bstack1ll1lll_opy_ (u"ࠣࡽࢀࠤ࠭ࢁࡽࠪࠤᬯ").format(bstack11l1111l1ll_opy_.name, bstack11l1111l1ll_opy_.email)
def bstack11ll1l1ll1l_opy_():
    try:
        repo = git.Repo(search_parent_directories=True)
        bstack111ll11ll1l_opy_ = repo.common_dir
        info = {
            bstack1ll1lll_opy_ (u"ࠤࡶ࡬ࡦࠨᬰ"): repo.head.commit.hexsha,
            bstack1ll1lll_opy_ (u"ࠥࡷ࡭ࡵࡲࡵࡡࡶ࡬ࡦࠨᬱ"): repo.git.rev_parse(repo.head.commit, short=True),
            bstack1ll1lll_opy_ (u"ࠦࡧࡸࡡ࡯ࡥ࡫ࠦᬲ"): repo.active_branch.name,
            bstack1ll1lll_opy_ (u"ࠧࡺࡡࡨࠤᬳ"): repo.git.describe(all=True, tags=True, exact_match=True),
            bstack1ll1lll_opy_ (u"ࠨࡣࡰ࡯ࡰ࡭ࡹࡺࡥࡳࠤ᬴"): bstack111ll111ll1_opy_(repo.head.commit.committer),
            bstack1ll1lll_opy_ (u"ࠢࡤࡱࡰࡱ࡮ࡺࡴࡦࡴࡢࡨࡦࡺࡥࠣᬵ"): repo.head.commit.committed_datetime.isoformat(),
            bstack1ll1lll_opy_ (u"ࠣࡣࡸࡸ࡭ࡵࡲࠣᬶ"): bstack111ll111ll1_opy_(repo.head.commit.author),
            bstack1ll1lll_opy_ (u"ࠤࡤࡹࡹ࡮࡯ࡳࡡࡧࡥࡹ࡫ࠢᬷ"): repo.head.commit.authored_datetime.isoformat(),
            bstack1ll1lll_opy_ (u"ࠥࡧࡴࡳ࡭ࡪࡶࡢࡱࡪࡹࡳࡢࡩࡨࠦᬸ"): repo.head.commit.message,
            bstack1ll1lll_opy_ (u"ࠦࡷࡵ࡯ࡵࠤᬹ"): repo.git.rev_parse(bstack1ll1lll_opy_ (u"ࠧ࠳࠭ࡴࡪࡲࡻ࠲ࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠢᬺ")),
            bstack1ll1lll_opy_ (u"ࠨࡣࡰ࡯ࡰࡳࡳࡥࡧࡪࡶࡢࡨ࡮ࡸࠢᬻ"): bstack111ll11ll1l_opy_,
            bstack1ll1lll_opy_ (u"ࠢࡸࡱࡵ࡯ࡹࡸࡥࡦࡡࡪ࡭ࡹࡥࡤࡪࡴࠥᬼ"): subprocess.check_output([bstack1ll1lll_opy_ (u"ࠣࡩ࡬ࡸࠧᬽ"), bstack1ll1lll_opy_ (u"ࠤࡵࡩࡻ࠳ࡰࡢࡴࡶࡩࠧᬾ"), bstack1ll1lll_opy_ (u"ࠥ࠱࠲࡭ࡩࡵ࠯ࡦࡳࡲࡳ࡯࡯࠯ࡧ࡭ࡷࠨᬿ")]).strip().decode(
                bstack1ll1lll_opy_ (u"ࠫࡺࡺࡦ࠮࠺ࠪᭀ")),
            bstack1ll1lll_opy_ (u"ࠧࡲࡡࡴࡶࡢࡸࡦ࡭ࠢᭁ"): repo.git.describe(tags=True, abbrev=0, always=True),
            bstack1ll1lll_opy_ (u"ࠨࡣࡰ࡯ࡰ࡭ࡹࡹ࡟ࡴ࡫ࡱࡧࡪࡥ࡬ࡢࡵࡷࡣࡹࡧࡧࠣᭂ"): repo.git.rev_list(
                bstack1ll1lll_opy_ (u"ࠢࡼࡿ࠱࠲ࢀࢃࠢᭃ").format(repo.head.commit, repo.git.describe(tags=True, abbrev=0, always=True)), count=True)
        }
        remotes = repo.remotes
        bstack11l111lll1l_opy_ = []
        for remote in remotes:
            bstack111llll111l_opy_ = {
                bstack1ll1lll_opy_ (u"ࠣࡰࡤࡱࡪࠨ᭄"): remote.name,
                bstack1ll1lll_opy_ (u"ࠤࡸࡶࡱࠨᭅ"): remote.url,
            }
            bstack11l111lll1l_opy_.append(bstack111llll111l_opy_)
        bstack11l1111l111_opy_ = {
            bstack1ll1lll_opy_ (u"ࠥࡲࡦࡳࡥࠣᭆ"): bstack1ll1lll_opy_ (u"ࠦ࡬࡯ࡴࠣᭇ"),
            **info,
            bstack1ll1lll_opy_ (u"ࠧࡸࡥ࡮ࡱࡷࡩࡸࠨᭈ"): bstack11l111lll1l_opy_
        }
        bstack11l1111l111_opy_ = bstack11l1111ll11_opy_(bstack11l1111l111_opy_)
        return bstack11l1111l111_opy_
    except git.InvalidGitRepositoryError:
        return {}
    except Exception as err:
        print(bstack1ll1lll_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡶ࡯ࡱࡷ࡯ࡥࡹ࡯࡮ࡨࠢࡊ࡭ࡹࠦ࡭ࡦࡶࡤࡨࡦࡺࡡࠡࡹ࡬ࡸ࡭ࠦࡥࡳࡴࡲࡶ࠿ࠦࡻࡾࠤᭉ").format(err))
        return {}
def bstack11l11l11l11_opy_(bstack111ll1lll11_opy_=None):
    bstack1ll1lll_opy_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࡈࡧࡷࠤ࡬࡯ࡴࠡ࡯ࡨࡸࡦࡪࡡࡵࡣࠣࡷࡵ࡫ࡣࡪࡨ࡬ࡧࡦࡲ࡬ࡺࠢࡩࡳࡷࡳࡡࡵࡶࡨࡨࠥ࡬࡯ࡳࠢࡄࡍࠥࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡࡷࡶࡩࠥࡩࡡࡴࡧࡶࠤ࡫ࡵࡲࠡࡧࡤࡧ࡭ࠦࡦࡰ࡮ࡧࡩࡷࠦࡩ࡯ࠢࡷ࡬ࡪࠦ࡬ࡪࡵࡷ࠲ࠏࠦࠠࠡࠢࡄࡶ࡬ࡹ࠺ࠋࠢࠣࠤࠥࠦࠠࠡࠢࡩࡳࡱࡪࡥࡳࡵࠣࠬࡱ࡯ࡳࡵ࠮ࠣࡳࡵࡺࡩࡰࡰࡤࡰ࠮ࡀࠠࡍ࡫ࡶࡸࠥࡵࡦࠡࡨࡲࡰࡩ࡫ࡲࠡࡲࡤࡸ࡭ࡹࠠࡵࡱࠣࡩࡽࡺࡲࡢࡥࡷࠤ࡬࡯ࡴࠡ࡯ࡨࡸࡦࡪࡡࡵࡣࠣࡪࡷࡵ࡭࠯ࠢࡇࡩ࡫ࡧࡵ࡭ࡶࡶࠤࡹࡵࠠ࡜ࡱࡶ࠲࡬࡫ࡴࡤࡹࡧࠬ࠮ࡣ࠮ࠋࠢࠣࠤࠥࡘࡥࡵࡷࡵࡲࡸࡀࠊࠡࠢࠣࠤࠥࠦࠠࠡ࡮࡬ࡷࡹࡀࠠࡍ࡫ࡶࡸࠥࡵࡦࠡࡦ࡬ࡧࡹࡹࠬࠡࡧࡤࡧ࡭ࠦࡣࡰࡰࡷࡥ࡮ࡴࡩ࡯ࡩࠣ࡫࡮ࡺࠠ࡮ࡧࡷࡥࡩࡧࡴࡢࠢࡩࡳࡷࠦࡡࠡࡨࡲࡰࡩ࡫ࡲ࠯ࠌࠣࠤࠥࠦࠢࠣࠤᭊ")
    if bstack111ll1lll11_opy_ == None: # bstack111llll1l1l_opy_ for bstack11l11111ll1_opy_-repo
        bstack111ll1lll11_opy_ = [os.getcwd()]
    results = []
    for folder in bstack111ll1lll11_opy_:
        try:
            repo = git.Repo(folder, search_parent_directories=True)
            result = {
                bstack1ll1lll_opy_ (u"ࠣࡲࡵࡍࡩࠨᭋ"): bstack1ll1lll_opy_ (u"ࠤࠥᭌ"),
                bstack1ll1lll_opy_ (u"ࠥࡪ࡮ࡲࡥࡴࡅ࡫ࡥࡳ࡭ࡥࡥࠤ᭍"): [],
                bstack1ll1lll_opy_ (u"ࠦࡦࡻࡴࡩࡱࡵࡷࠧ᭎"): [],
                bstack1ll1lll_opy_ (u"ࠧࡶࡲࡅࡣࡷࡩࠧ᭏"): bstack1ll1lll_opy_ (u"ࠨࠢ᭐"),
                bstack1ll1lll_opy_ (u"ࠢࡤࡱࡰࡱ࡮ࡺࡍࡦࡵࡶࡥ࡬࡫ࡳࠣ᭑"): [],
                bstack1ll1lll_opy_ (u"ࠣࡲࡵࡘ࡮ࡺ࡬ࡦࠤ᭒"): bstack1ll1lll_opy_ (u"ࠤࠥ᭓"),
                bstack1ll1lll_opy_ (u"ࠥࡴࡷࡊࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠥ᭔"): bstack1ll1lll_opy_ (u"ࠦࠧ᭕"),
                bstack1ll1lll_opy_ (u"ࠧࡶࡲࡓࡣࡺࡈ࡮࡬ࡦࠣ᭖"): bstack1ll1lll_opy_ (u"ࠨࠢ᭗")
            }
            bstack111ll1l11l1_opy_ = repo.active_branch.name
            bstack111lll111l1_opy_ = repo.head.commit
            result[bstack1ll1lll_opy_ (u"ࠢࡱࡴࡌࡨࠧ᭘")] = bstack111lll111l1_opy_.hexsha
            bstack111lll1llll_opy_ = _11l111l1l11_opy_(repo)
            logger.debug(bstack1ll1lll_opy_ (u"ࠣࡄࡤࡷࡪࠦࡢࡳࡣࡱࡧ࡭ࠦࡦࡰࡴࠣࡧࡴࡳࡰࡢࡴ࡬ࡷࡴࡴ࠺ࠡࠤ᭙") + str(bstack111lll1llll_opy_) + bstack1ll1lll_opy_ (u"ࠤࠥ᭚"))
            if bstack111lll1llll_opy_:
                try:
                    bstack111lll11l1l_opy_ = repo.git.diff(bstack1ll1lll_opy_ (u"ࠥ࠱࠲ࡴࡡ࡮ࡧ࠰ࡳࡳࡲࡹࠣ᭛"), bstack11111ll1ll_opy_ (u"ࠦࢀࡨࡡࡴࡧࡢࡦࡷࡧ࡮ࡤࡪࢀ࠲࠳࠴ࡻࡤࡷࡵࡶࡪࡴࡴࡠࡤࡵࡥࡳࡩࡨࡾࠤ᭜")).split(bstack1ll1lll_opy_ (u"ࠬࡢ࡮ࠨ᭝"))
                    logger.debug(bstack1ll1lll_opy_ (u"ࠨࡃࡩࡣࡱ࡫ࡪࡪࠠࡧ࡫࡯ࡩࡸࠦࡢࡦࡶࡺࡩࡪࡴࠠࡼࡤࡤࡷࡪࡥࡢࡳࡣࡱࡧ࡭ࢃࠠࡢࡰࡧࠤࢀࡩࡵࡳࡴࡨࡲࡹࡥࡢࡳࡣࡱࡧ࡭ࢃ࠺ࠡࠤ᭞") + str(bstack111lll11l1l_opy_) + bstack1ll1lll_opy_ (u"ࠢࠣ᭟"))
                    result[bstack1ll1lll_opy_ (u"ࠣࡨ࡬ࡰࡪࡹࡃࡩࡣࡱ࡫ࡪࡪࠢ᭠")] = [f.strip() for f in bstack111lll11l1l_opy_ if f.strip()]
                    commits = list(repo.iter_commits(bstack11111ll1ll_opy_ (u"ࠤࡾࡦࡦࡹࡥࡠࡤࡵࡥࡳࡩࡨࡾ࠰࠱ࡿࡨࡻࡲࡳࡧࡱࡸࡤࡨࡲࡢࡰࡦ࡬ࢂࠨ᭡")))
                except Exception:
                    logger.debug(bstack1ll1lll_opy_ (u"ࠥࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡧࡦࡶࠣࡧ࡭ࡧ࡮ࡨࡧࡧࠤ࡫࡯࡬ࡦࡵࠣࡪࡷࡵ࡭ࠡࡤࡵࡥࡳࡩࡨࠡࡥࡲࡱࡵࡧࡲࡪࡵࡲࡲ࠳ࠦࡆࡢ࡮࡯࡭ࡳ࡭ࠠࡣࡣࡦ࡯ࠥࡺ࡯ࠡࡴࡨࡧࡪࡴࡴࠡࡥࡲࡱࡲ࡯ࡴࡴ࠰ࠥ᭢"))
                    commits = list(repo.iter_commits(max_count=10))
                    if commits:
                        result[bstack1ll1lll_opy_ (u"ࠦ࡫࡯࡬ࡦࡵࡆ࡬ࡦࡴࡧࡦࡦࠥ᭣")] = _11l111l111l_opy_(commits[:5])
            else:
                commits = list(repo.iter_commits(max_count=10))
                if commits:
                    result[bstack1ll1lll_opy_ (u"ࠧ࡬ࡩ࡭ࡧࡶࡇ࡭ࡧ࡮ࡨࡧࡧࠦ᭤")] = _11l111l111l_opy_(commits[:5])
            bstack111ll11l1ll_opy_ = set()
            bstack111llllllll_opy_ = []
            for commit in commits:
                logger.debug(bstack1ll1lll_opy_ (u"ࠨࡐࡳࡱࡦࡩࡸࡹࡩ࡯ࡩࠣࡧࡴࡳ࡭ࡪࡶ࠽ࠤࠧ᭥") + str(commit.message) + bstack1ll1lll_opy_ (u"ࠢࠣ᭦"))
                bstack111ll1l1l1l_opy_ = commit.author.name if commit.author else bstack1ll1lll_opy_ (u"ࠣࡗࡱ࡯ࡳࡵࡷ࡯ࠤ᭧")
                bstack111ll11l1ll_opy_.add(bstack111ll1l1l1l_opy_)
                bstack111llllllll_opy_.append({
                    bstack1ll1lll_opy_ (u"ࠤࡰࡩࡸࡹࡡࡨࡧࠥ᭨"): commit.message.strip(),
                    bstack1ll1lll_opy_ (u"ࠥࡹࡸ࡫ࡲࠣ᭩"): bstack111ll1l1l1l_opy_
                })
            result[bstack1ll1lll_opy_ (u"ࠦࡦࡻࡴࡩࡱࡵࡷࠧ᭪")] = list(bstack111ll11l1ll_opy_)
            result[bstack1ll1lll_opy_ (u"ࠧࡩ࡯࡮࡯࡬ࡸࡒ࡫ࡳࡴࡣࡪࡩࡸࠨ᭫")] = bstack111llllllll_opy_
            result[bstack1ll1lll_opy_ (u"ࠨࡰࡳࡆࡤࡸࡪࠨ᭬")] = bstack111lll111l1_opy_.committed_datetime.strftime(bstack1ll1lll_opy_ (u"࡛ࠢࠦ࠰ࠩࡲ࠳ࠥࡥࠤ᭭"))
            if (not result[bstack1ll1lll_opy_ (u"ࠣࡲࡵࡘ࡮ࡺ࡬ࡦࠤ᭮")] or result[bstack1ll1lll_opy_ (u"ࠤࡳࡶ࡙࡯ࡴ࡭ࡧࠥ᭯")].strip() == bstack1ll1lll_opy_ (u"ࠥࠦ᭰")) and bstack111lll111l1_opy_.message:
                bstack111llll11l1_opy_ = bstack111lll111l1_opy_.message.strip().splitlines()
                result[bstack1ll1lll_opy_ (u"ࠦࡵࡸࡔࡪࡶ࡯ࡩࠧ᭱")] = bstack111llll11l1_opy_[0] if bstack111llll11l1_opy_ else bstack1ll1lll_opy_ (u"ࠧࠨ᭲")
                if len(bstack111llll11l1_opy_) > 2:
                    result[bstack1ll1lll_opy_ (u"ࠨࡰࡳࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠨ᭳")] = bstack1ll1lll_opy_ (u"ࠧ࡝ࡰࠪ᭴").join(bstack111llll11l1_opy_[2:]).strip()
            results.append(result)
        except Exception as err:
            logger.error(bstack1ll1lll_opy_ (u"ࠣࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡱࡱࡳࡹࡱࡧࡴࡪࡰࡪࠤࡌ࡯ࡴࠡ࡯ࡨࡸࡦࡪࡡࡵࡣࠣࡪࡴࡸࠠࡂࡋࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦࠨࡧࡱ࡯ࡨࡪࡸ࠺ࠡࡽࡩࡳࡱࡪࡥࡳࡿࠬ࠾ࠥࠨ᭵") + str(err) + bstack1ll1lll_opy_ (u"ࠤࠥ᭶"))
    filtered_results = [
        result
        for result in results
        if _11l11l1l1l1_opy_(result)
    ]
    return filtered_results
def _11l11l1l1l1_opy_(result):
    bstack1ll1lll_opy_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࡌࡪࡲࡰࡦࡴࠣࡸࡴࠦࡣࡩࡧࡦ࡯ࠥ࡯ࡦࠡࡣࠣ࡫࡮ࡺࠠ࡮ࡧࡷࡥࡩࡧࡴࡢࠢࡵࡩࡸࡻ࡬ࡵࠢ࡬ࡷࠥࡼࡡ࡭࡫ࡧࠤ࠭ࡴ࡯࡯࠯ࡨࡱࡵࡺࡹࠡࡨ࡬ࡰࡪࡹࡃࡩࡣࡱ࡫ࡪࡪࠠࡢࡰࡧࠤࡦࡻࡴࡩࡱࡵࡷ࠮࠴ࠊࠡࠢࠣࠤࠧࠨࠢ᭷")
    return (
        isinstance(result.get(bstack1ll1lll_opy_ (u"ࠦ࡫࡯࡬ࡦࡵࡆ࡬ࡦࡴࡧࡦࡦࠥ᭸"), None), list)
        and len(result[bstack1ll1lll_opy_ (u"ࠧ࡬ࡩ࡭ࡧࡶࡇ࡭ࡧ࡮ࡨࡧࡧࠦ᭹")]) > 0
        and isinstance(result.get(bstack1ll1lll_opy_ (u"ࠨࡡࡶࡶ࡫ࡳࡷࡹࠢ᭺"), None), list)
        and len(result[bstack1ll1lll_opy_ (u"ࠢࡢࡷࡷ࡬ࡴࡸࡳࠣ᭻")]) > 0
    )
def _11l111l1l11_opy_(repo):
    bstack1ll1lll_opy_ (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡖࡵࡽࠥࡺ࡯ࠡࡦࡨࡸࡪࡸ࡭ࡪࡰࡨࠤࡹ࡮ࡥࠡࡤࡤࡷࡪࠦࡢࡳࡣࡱࡧ࡭ࠦࡦࡰࡴࠣࡸ࡭࡫ࠠࡨ࡫ࡹࡩࡳࠦࡲࡦࡲࡲࠤࡼ࡯ࡴࡩࡱࡸࡸࠥ࡮ࡡࡳࡦࡦࡳࡩ࡫ࡤࠡࡰࡤࡱࡪࡹࠠࡢࡰࡧࠤࡼࡵࡲ࡬ࠢࡺ࡭ࡹ࡮ࠠࡢ࡮࡯ࠤ࡛ࡉࡓࠡࡲࡵࡳࡻ࡯ࡤࡦࡴࡶ࠲ࠏࠦࠠࠡࠢࡕࡩࡹࡻࡲ࡯ࡵࠣࡸ࡭࡫ࠠࡥࡧࡩࡥࡺࡲࡴࠡࡤࡵࡥࡳࡩࡨࠡ࡫ࡩࠤࡵࡵࡳࡴ࡫ࡥࡰࡪ࠲ࠠࡦ࡮ࡶࡩࠥࡔ࡯࡯ࡧ࠱ࠎࠥࠦࠠࠡࠤࠥࠦ᭼")
    try:
        try:
            origin = repo.remotes.origin
            bstack111ll1llll1_opy_ = origin.refs[bstack1ll1lll_opy_ (u"ࠩࡋࡉࡆࡊࠧ᭽")]
            target = bstack111ll1llll1_opy_.reference.name
            if target.startswith(bstack1ll1lll_opy_ (u"ࠪࡳࡷ࡯ࡧࡪࡰ࠲ࠫ᭾")):
                return target
        except Exception:
            pass
        if repo.remotes and repo.remotes.origin.refs:
            for ref in repo.remotes.origin.refs:
                if ref.name.startswith(bstack1ll1lll_opy_ (u"ࠫࡴࡸࡩࡨ࡫ࡱ࠳ࠬ᭿")):
                    return ref.name
        if repo.heads:
            return repo.heads[0].name
    except Exception:
        pass
    return None
def _11l111l111l_opy_(commits):
    bstack1ll1lll_opy_ (u"ࠧࠨࠢࠋࠢࠣࠤࠥࡍࡥࡵࠢ࡯࡭ࡸࡺࠠࡰࡨࠣࡧ࡭ࡧ࡮ࡨࡧࡧࠤ࡫࡯࡬ࡦࡵࠣࡪࡷࡵ࡭ࠡࡣࠣࡰ࡮ࡹࡴࠡࡱࡩࠤࡨࡵ࡭࡮࡫ࡷࡷ࠳ࠐࠠࠡࠢࠣࠦࠧࠨᮀ")
    bstack111lll11l1l_opy_ = set()
    try:
        for commit in commits:
            if commit.parents:
                for parent in commit.parents:
                    diff = commit.diff(parent)
                    for bstack11l111l1lll_opy_ in diff:
                        if bstack11l111l1lll_opy_.a_path:
                            bstack111lll11l1l_opy_.add(bstack11l111l1lll_opy_.a_path)
                        if bstack11l111l1lll_opy_.b_path:
                            bstack111lll11l1l_opy_.add(bstack11l111l1lll_opy_.b_path)
    except Exception:
        pass
    return list(bstack111lll11l1l_opy_)
def bstack11l1111ll11_opy_(bstack11l1111l111_opy_):
    bstack111lllll1ll_opy_ = bstack111llllll1l_opy_(bstack11l1111l111_opy_)
    if bstack111lllll1ll_opy_ and bstack111lllll1ll_opy_ > bstack11l1l1ll111_opy_:
        bstack111ll1lll1l_opy_ = bstack111lllll1ll_opy_ - bstack11l1l1ll111_opy_
        bstack111llll1lll_opy_ = bstack111lll1l11l_opy_(bstack11l1111l111_opy_[bstack1ll1lll_opy_ (u"ࠨࡣࡰ࡯ࡰ࡭ࡹࡥ࡭ࡦࡵࡶࡥ࡬࡫ࠢᮁ")], bstack111ll1lll1l_opy_)
        bstack11l1111l111_opy_[bstack1ll1lll_opy_ (u"ࠢࡤࡱࡰࡱ࡮ࡺ࡟࡮ࡧࡶࡷࡦ࡭ࡥࠣᮂ")] = bstack111llll1lll_opy_
        logger.info(bstack1ll1lll_opy_ (u"ࠣࡖ࡫ࡩࠥࡩ࡯࡮࡯࡬ࡸࠥ࡮ࡡࡴࠢࡥࡩࡪࡴࠠࡵࡴࡸࡲࡨࡧࡴࡦࡦ࠱ࠤࡘ࡯ࡺࡦࠢࡲࡪࠥࡩ࡯࡮࡯࡬ࡸࠥࡧࡦࡵࡧࡵࠤࡹࡸࡵ࡯ࡥࡤࡸ࡮ࡵ࡮ࠡ࡫ࡶࠤࢀࢃࠠࡌࡄࠥᮃ")
                    .format(bstack111llllll1l_opy_(bstack11l1111l111_opy_) / 1024))
    return bstack11l1111l111_opy_
def bstack111llllll1l_opy_(bstack1ll1ll11_opy_):
    try:
        if bstack1ll1ll11_opy_:
            bstack11l11ll111l_opy_ = json.dumps(bstack1ll1ll11_opy_)
            bstack111lll1l1l1_opy_ = sys.getsizeof(bstack11l11ll111l_opy_)
            return bstack111lll1l1l1_opy_
    except Exception as e:
        logger.debug(bstack1ll1lll_opy_ (u"ࠤࡖࡳࡲ࡫ࡴࡩ࡫ࡱ࡫ࠥࡽࡥ࡯ࡶࠣࡻࡷࡵ࡮ࡨࠢࡺ࡬࡮ࡲࡥࠡࡥࡤࡰࡨࡻ࡬ࡢࡶ࡬ࡲ࡬ࠦࡳࡪࡼࡨࠤࡴ࡬ࠠࡋࡕࡒࡒࠥࡵࡢ࡫ࡧࡦࡸ࠿ࠦࡻࡾࠤᮄ").format(e))
    return -1
def bstack111lll1l11l_opy_(field, bstack11l11l1lll1_opy_):
    try:
        bstack111ll11llll_opy_ = len(bytes(bstack11l1l1lll11_opy_, bstack1ll1lll_opy_ (u"ࠪࡹࡹ࡬࠭࠹ࠩᮅ")))
        bstack11l111llll1_opy_ = bytes(field, bstack1ll1lll_opy_ (u"ࠫࡺࡺࡦ࠮࠺ࠪᮆ"))
        bstack11l111l1l1l_opy_ = len(bstack11l111llll1_opy_)
        bstack11l11l1llll_opy_ = ceil(bstack11l111l1l1l_opy_ - bstack11l11l1lll1_opy_ - bstack111ll11llll_opy_)
        if bstack11l11l1llll_opy_ > 0:
            bstack111lllll11l_opy_ = bstack11l111llll1_opy_[:bstack11l11l1llll_opy_].decode(bstack1ll1lll_opy_ (u"ࠬࡻࡴࡧ࠯࠻ࠫᮇ"), errors=bstack1ll1lll_opy_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭ᮈ")) + bstack11l1l1lll11_opy_
            return bstack111lllll11l_opy_
    except Exception as e:
        logger.debug(bstack1ll1lll_opy_ (u"ࠢࡆࡴࡵࡳࡷࠦࡷࡩ࡫࡯ࡩࠥࡺࡲࡶࡰࡦࡥࡹ࡯࡮ࡨࠢࡩ࡭ࡪࡲࡤ࠭ࠢࡱࡳࡹ࡮ࡩ࡯ࡩࠣࡻࡦࡹࠠࡵࡴࡸࡲࡨࡧࡴࡦࡦࠣ࡬ࡪࡸࡥ࠻ࠢࡾࢁࠧᮉ").format(e))
    return field
def bstack1l111l1l_opy_():
    env = os.environ
    if (bstack1ll1lll_opy_ (u"ࠣࡌࡈࡒࡐࡏࡎࡔࡡࡘࡖࡑࠨᮊ") in env and len(env[bstack1ll1lll_opy_ (u"ࠤࡍࡉࡓࡑࡉࡏࡕࡢ࡙ࡗࡒࠢᮋ")]) > 0) or (
            bstack1ll1lll_opy_ (u"ࠥࡎࡊࡔࡋࡊࡐࡖࡣࡍࡕࡍࡆࠤᮌ") in env and len(env[bstack1ll1lll_opy_ (u"ࠦࡏࡋࡎࡌࡋࡑࡗࡤࡎࡏࡎࡇࠥᮍ")]) > 0):
        return {
            bstack1ll1lll_opy_ (u"ࠧࡴࡡ࡮ࡧࠥᮎ"): bstack1ll1lll_opy_ (u"ࠨࡊࡦࡰ࡮࡭ࡳࡹࠢᮏ"),
            bstack1ll1lll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥᮐ"): env.get(bstack1ll1lll_opy_ (u"ࠣࡄࡘࡍࡑࡊ࡟ࡖࡔࡏࠦᮑ")),
            bstack1ll1lll_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦᮒ"): env.get(bstack1ll1lll_opy_ (u"ࠥࡎࡔࡈ࡟ࡏࡃࡐࡉࠧᮓ")),
            bstack1ll1lll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥᮔ"): env.get(bstack1ll1lll_opy_ (u"ࠧࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࡃࡇࡕࠦᮕ"))
        }
    if env.get(bstack1ll1lll_opy_ (u"ࠨࡃࡊࠤᮖ")) == bstack1ll1lll_opy_ (u"ࠢࡵࡴࡸࡩࠧᮗ") and bstack1ll111ll11_opy_(env.get(bstack1ll1lll_opy_ (u"ࠣࡅࡌࡖࡈࡒࡅࡄࡋࠥᮘ"))):
        return {
            bstack1ll1lll_opy_ (u"ࠤࡱࡥࡲ࡫ࠢᮙ"): bstack1ll1lll_opy_ (u"ࠥࡇ࡮ࡸࡣ࡭ࡧࡆࡍࠧᮚ"),
            bstack1ll1lll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢᮛ"): env.get(bstack1ll1lll_opy_ (u"ࠧࡉࡉࡓࡅࡏࡉࡤࡈࡕࡊࡎࡇࡣ࡚ࡘࡌࠣᮜ")),
            bstack1ll1lll_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣᮝ"): env.get(bstack1ll1lll_opy_ (u"ࠢࡄࡋࡕࡇࡑࡋ࡟ࡋࡑࡅࠦᮞ")),
            bstack1ll1lll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢᮟ"): env.get(bstack1ll1lll_opy_ (u"ࠤࡆࡍࡗࡉࡌࡆࡡࡅ࡙ࡎࡒࡄࡠࡐࡘࡑࠧᮠ"))
        }
    if env.get(bstack1ll1lll_opy_ (u"ࠥࡇࡎࠨᮡ")) == bstack1ll1lll_opy_ (u"ࠦࡹࡸࡵࡦࠤᮢ") and bstack1ll111ll11_opy_(env.get(bstack1ll1lll_opy_ (u"࡚ࠧࡒࡂࡘࡌࡗࠧᮣ"))):
        return {
            bstack1ll1lll_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦᮤ"): bstack1ll1lll_opy_ (u"ࠢࡕࡴࡤࡺ࡮ࡹࠠࡄࡋࠥᮥ"),
            bstack1ll1lll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦᮦ"): env.get(bstack1ll1lll_opy_ (u"ࠤࡗࡖࡆ࡜ࡉࡔࡡࡅ࡙ࡎࡒࡄࡠ࡙ࡈࡆࡤ࡛ࡒࡍࠤᮧ")),
            bstack1ll1lll_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧᮨ"): env.get(bstack1ll1lll_opy_ (u"࡙ࠦࡘࡁࡗࡋࡖࡣࡏࡕࡂࡠࡐࡄࡑࡊࠨᮩ")),
            bstack1ll1lll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵ᮪ࠦ"): env.get(bstack1ll1lll_opy_ (u"ࠨࡔࡓࡃ࡙ࡍࡘࡥࡂࡖࡋࡏࡈࡤࡔࡕࡎࡄࡈࡖ᮫ࠧ"))
        }
    if env.get(bstack1ll1lll_opy_ (u"ࠢࡄࡋࠥᮬ")) == bstack1ll1lll_opy_ (u"ࠣࡶࡵࡹࡪࠨᮭ") and env.get(bstack1ll1lll_opy_ (u"ࠤࡆࡍࡤࡔࡁࡎࡇࠥᮮ")) == bstack1ll1lll_opy_ (u"ࠥࡧࡴࡪࡥࡴࡪ࡬ࡴࠧᮯ"):
        return {
            bstack1ll1lll_opy_ (u"ࠦࡳࡧ࡭ࡦࠤ᮰"): bstack1ll1lll_opy_ (u"ࠧࡉ࡯ࡥࡧࡶ࡬࡮ࡶࠢ᮱"),
            bstack1ll1lll_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤ᮲"): None,
            bstack1ll1lll_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤ᮳"): None,
            bstack1ll1lll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢ᮴"): None
        }
    if env.get(bstack1ll1lll_opy_ (u"ࠤࡅࡍ࡙ࡈࡕࡄࡍࡈࡘࡤࡈࡒࡂࡐࡆࡌࠧ᮵")) and env.get(bstack1ll1lll_opy_ (u"ࠥࡆࡎ࡚ࡂࡖࡅࡎࡉ࡙ࡥࡃࡐࡏࡐࡍ࡙ࠨ᮶")):
        return {
            bstack1ll1lll_opy_ (u"ࠦࡳࡧ࡭ࡦࠤ᮷"): bstack1ll1lll_opy_ (u"ࠧࡈࡩࡵࡤࡸࡧࡰ࡫ࡴࠣ᮸"),
            bstack1ll1lll_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤ᮹"): env.get(bstack1ll1lll_opy_ (u"ࠢࡃࡋࡗࡆ࡚ࡉࡋࡆࡖࡢࡋࡎ࡚࡟ࡉࡖࡗࡔࡤࡕࡒࡊࡉࡌࡒࠧᮺ")),
            bstack1ll1lll_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥᮻ"): None,
            bstack1ll1lll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣᮼ"): env.get(bstack1ll1lll_opy_ (u"ࠥࡆࡎ࡚ࡂࡖࡅࡎࡉ࡙ࡥࡂࡖࡋࡏࡈࡤࡔࡕࡎࡄࡈࡖࠧᮽ"))
        }
    if env.get(bstack1ll1lll_opy_ (u"ࠦࡈࡏࠢᮾ")) == bstack1ll1lll_opy_ (u"ࠧࡺࡲࡶࡧࠥᮿ") and bstack1ll111ll11_opy_(env.get(bstack1ll1lll_opy_ (u"ࠨࡄࡓࡑࡑࡉࠧᯀ"))):
        return {
            bstack1ll1lll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧᯁ"): bstack1ll1lll_opy_ (u"ࠣࡆࡵࡳࡳ࡫ࠢᯂ"),
            bstack1ll1lll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧᯃ"): env.get(bstack1ll1lll_opy_ (u"ࠥࡈࡗࡕࡎࡆࡡࡅ࡙ࡎࡒࡄࡠࡎࡌࡒࡐࠨᯄ")),
            bstack1ll1lll_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨᯅ"): None,
            bstack1ll1lll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦᯆ"): env.get(bstack1ll1lll_opy_ (u"ࠨࡄࡓࡑࡑࡉࡤࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࡃࡇࡕࠦᯇ"))
        }
    if env.get(bstack1ll1lll_opy_ (u"ࠢࡄࡋࠥᯈ")) == bstack1ll1lll_opy_ (u"ࠣࡶࡵࡹࡪࠨᯉ") and bstack1ll111ll11_opy_(env.get(bstack1ll1lll_opy_ (u"ࠤࡖࡉࡒࡇࡐࡉࡑࡕࡉࠧᯊ"))):
        return {
            bstack1ll1lll_opy_ (u"ࠥࡲࡦࡳࡥࠣᯋ"): bstack1ll1lll_opy_ (u"ࠦࡘ࡫࡭ࡢࡲ࡫ࡳࡷ࡫ࠢᯌ"),
            bstack1ll1lll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣᯍ"): env.get(bstack1ll1lll_opy_ (u"ࠨࡓࡆࡏࡄࡔࡍࡕࡒࡆࡡࡒࡖࡌࡇࡎࡊ࡜ࡄࡘࡎࡕࡎࡠࡗࡕࡐࠧᯎ")),
            bstack1ll1lll_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤᯏ"): env.get(bstack1ll1lll_opy_ (u"ࠣࡕࡈࡑࡆࡖࡈࡐࡔࡈࡣࡏࡕࡂࡠࡐࡄࡑࡊࠨᯐ")),
            bstack1ll1lll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣᯑ"): env.get(bstack1ll1lll_opy_ (u"ࠥࡗࡊࡓࡁࡑࡊࡒࡖࡊࡥࡊࡐࡄࡢࡍࡉࠨᯒ"))
        }
    if env.get(bstack1ll1lll_opy_ (u"ࠦࡈࡏࠢᯓ")) == bstack1ll1lll_opy_ (u"ࠧࡺࡲࡶࡧࠥᯔ") and bstack1ll111ll11_opy_(env.get(bstack1ll1lll_opy_ (u"ࠨࡇࡊࡖࡏࡅࡇࡥࡃࡊࠤᯕ"))):
        return {
            bstack1ll1lll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧᯖ"): bstack1ll1lll_opy_ (u"ࠣࡉ࡬ࡸࡑࡧࡢࠣᯗ"),
            bstack1ll1lll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧᯘ"): env.get(bstack1ll1lll_opy_ (u"ࠥࡇࡎࡥࡊࡐࡄࡢ࡙ࡗࡒࠢᯙ")),
            bstack1ll1lll_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨᯚ"): env.get(bstack1ll1lll_opy_ (u"ࠧࡉࡉࡠࡌࡒࡆࡤࡔࡁࡎࡇࠥᯛ")),
            bstack1ll1lll_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧᯜ"): env.get(bstack1ll1lll_opy_ (u"ࠢࡄࡋࡢࡎࡔࡈ࡟ࡊࡆࠥᯝ"))
        }
    if env.get(bstack1ll1lll_opy_ (u"ࠣࡅࡌࠦᯞ")) == bstack1ll1lll_opy_ (u"ࠤࡷࡶࡺ࡫ࠢᯟ") and bstack1ll111ll11_opy_(env.get(bstack1ll1lll_opy_ (u"ࠥࡆ࡚ࡏࡌࡅࡍࡌࡘࡊࠨᯠ"))):
        return {
            bstack1ll1lll_opy_ (u"ࠦࡳࡧ࡭ࡦࠤᯡ"): bstack1ll1lll_opy_ (u"ࠧࡈࡵࡪ࡮ࡧ࡯࡮ࡺࡥࠣᯢ"),
            bstack1ll1lll_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤᯣ"): env.get(bstack1ll1lll_opy_ (u"ࠢࡃࡗࡌࡐࡉࡑࡉࡕࡇࡢࡆ࡚ࡏࡌࡅࡡࡘࡖࡑࠨᯤ")),
            bstack1ll1lll_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥᯥ"): env.get(bstack1ll1lll_opy_ (u"ࠤࡅ࡙ࡎࡒࡄࡌࡋࡗࡉࡤࡒࡁࡃࡇࡏ᯦ࠦ")) or env.get(bstack1ll1lll_opy_ (u"ࠥࡆ࡚ࡏࡌࡅࡍࡌࡘࡊࡥࡐࡊࡒࡈࡐࡎࡔࡅࡠࡐࡄࡑࡊࠨᯧ")),
            bstack1ll1lll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥᯨ"): env.get(bstack1ll1lll_opy_ (u"ࠧࡈࡕࡊࡎࡇࡏࡎ࡚ࡅࡠࡄࡘࡍࡑࡊ࡟ࡏࡗࡐࡆࡊࡘࠢᯩ"))
        }
    if bstack1ll111ll11_opy_(env.get(bstack1ll1lll_opy_ (u"ࠨࡔࡇࡡࡅ࡙ࡎࡒࡄࠣᯪ"))):
        return {
            bstack1ll1lll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧᯫ"): bstack1ll1lll_opy_ (u"ࠣࡘ࡬ࡷࡺࡧ࡬ࠡࡕࡷࡹࡩ࡯࡯ࠡࡖࡨࡥࡲࠦࡓࡦࡴࡹ࡭ࡨ࡫ࡳࠣᯬ"),
            bstack1ll1lll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧᯭ"): bstack1ll1lll_opy_ (u"ࠥࡿࢂࢁࡽࠣᯮ").format(env.get(bstack1ll1lll_opy_ (u"ࠫࡘ࡟ࡓࡕࡇࡐࡣ࡙ࡋࡁࡎࡈࡒ࡙ࡓࡊࡁࡕࡋࡒࡒࡘࡋࡒࡗࡇࡕ࡙ࡗࡏࠧᯯ")), env.get(bstack1ll1lll_opy_ (u"࡙࡙ࠬࡔࡖࡈࡑࡤ࡚ࡅࡂࡏࡓࡖࡔࡐࡅࡄࡖࡌࡈࠬᯰ"))),
            bstack1ll1lll_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣᯱ"): env.get(bstack1ll1lll_opy_ (u"ࠢࡔ࡛ࡖࡘࡊࡓ࡟ࡅࡇࡉࡍࡓࡏࡔࡊࡑࡑࡍࡉࠨ᯲")),
            bstack1ll1lll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸ᯳ࠢ"): env.get(bstack1ll1lll_opy_ (u"ࠤࡅ࡙ࡎࡒࡄࡠࡄࡘࡍࡑࡊࡉࡅࠤ᯴"))
        }
    if bstack1ll111ll11_opy_(env.get(bstack1ll1lll_opy_ (u"ࠥࡅࡕࡖࡖࡆ࡛ࡒࡖࠧ᯵"))):
        return {
            bstack1ll1lll_opy_ (u"ࠦࡳࡧ࡭ࡦࠤ᯶"): bstack1ll1lll_opy_ (u"ࠧࡇࡰࡱࡸࡨࡽࡴࡸࠢ᯷"),
            bstack1ll1lll_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤ᯸"): bstack1ll1lll_opy_ (u"ࠢࡼࡿ࠲ࡴࡷࡵࡪࡦࡥࡷ࠳ࢀࢃ࠯ࡼࡿ࠲ࡦࡺ࡯࡬ࡥࡵ࠲ࡿࢂࠨ᯹").format(env.get(bstack1ll1lll_opy_ (u"ࠨࡃࡓࡔ࡛ࡋ࡙ࡐࡔࡢ࡙ࡗࡒࠧ᯺")), env.get(bstack1ll1lll_opy_ (u"ࠩࡄࡔࡕ࡜ࡅ࡚ࡑࡕࡣࡆࡉࡃࡐࡗࡑࡘࡤࡔࡁࡎࡇࠪ᯻")), env.get(bstack1ll1lll_opy_ (u"ࠪࡅࡕࡖࡖࡆ࡛ࡒࡖࡤࡖࡒࡐࡌࡈࡇ࡙ࡥࡓࡍࡗࡊࠫ᯼")), env.get(bstack1ll1lll_opy_ (u"ࠫࡆࡖࡐࡗࡇ࡜ࡓࡗࡥࡂࡖࡋࡏࡈࡤࡏࡄࠨ᯽"))),
            bstack1ll1lll_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢ᯾"): env.get(bstack1ll1lll_opy_ (u"ࠨࡁࡑࡒ࡙ࡉ࡞ࡕࡒࡠࡌࡒࡆࡤࡔࡁࡎࡇࠥ᯿")),
            bstack1ll1lll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨᰀ"): env.get(bstack1ll1lll_opy_ (u"ࠣࡃࡓࡔ࡛ࡋ࡙ࡐࡔࡢࡆ࡚ࡏࡌࡅࡡࡑ࡙ࡒࡈࡅࡓࠤᰁ"))
        }
    if env.get(bstack1ll1lll_opy_ (u"ࠤࡄ࡞࡚ࡘࡅࡠࡊࡗࡘࡕࡥࡕࡔࡇࡕࡣࡆࡍࡅࡏࡖࠥᰂ")) and env.get(bstack1ll1lll_opy_ (u"ࠥࡘࡋࡥࡂࡖࡋࡏࡈࠧᰃ")):
        return {
            bstack1ll1lll_opy_ (u"ࠦࡳࡧ࡭ࡦࠤᰄ"): bstack1ll1lll_opy_ (u"ࠧࡇࡺࡶࡴࡨࠤࡈࡏࠢᰅ"),
            bstack1ll1lll_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤᰆ"): bstack1ll1lll_opy_ (u"ࠢࡼࡿࡾࢁ࠴ࡥࡢࡶ࡫࡯ࡨ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡢࡶ࡫࡯ࡨࡎࡪ࠽ࡼࡿࠥᰇ").format(env.get(bstack1ll1lll_opy_ (u"ࠨࡕ࡜ࡗ࡙ࡋࡍࡠࡖࡈࡅࡒࡌࡏࡖࡐࡇࡅ࡙ࡏࡏࡏࡕࡈࡖ࡛ࡋࡒࡖࡔࡌࠫᰈ")), env.get(bstack1ll1lll_opy_ (u"ࠩࡖ࡝ࡘ࡚ࡅࡎࡡࡗࡉࡆࡓࡐࡓࡑࡍࡉࡈ࡚ࠧᰉ")), env.get(bstack1ll1lll_opy_ (u"ࠪࡆ࡚ࡏࡌࡅࡡࡅ࡙ࡎࡒࡄࡊࡆࠪᰊ"))),
            bstack1ll1lll_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨᰋ"): env.get(bstack1ll1lll_opy_ (u"ࠧࡈࡕࡊࡎࡇࡣࡇ࡛ࡉࡍࡆࡌࡈࠧᰌ")),
            bstack1ll1lll_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧᰍ"): env.get(bstack1ll1lll_opy_ (u"ࠢࡃࡗࡌࡐࡉࡥࡂࡖࡋࡏࡈࡎࡊࠢᰎ"))
        }
    if any([env.get(bstack1ll1lll_opy_ (u"ࠣࡅࡒࡈࡊࡈࡕࡊࡎࡇࡣࡇ࡛ࡉࡍࡆࡢࡍࡉࠨᰏ")), env.get(bstack1ll1lll_opy_ (u"ࠤࡆࡓࡉࡋࡂࡖࡋࡏࡈࡤࡘࡅࡔࡑࡏ࡚ࡊࡊ࡟ࡔࡑࡘࡖࡈࡋ࡟ࡗࡇࡕࡗࡎࡕࡎࠣᰐ")), env.get(bstack1ll1lll_opy_ (u"ࠥࡇࡔࡊࡅࡃࡗࡌࡐࡉࡥࡓࡐࡗࡕࡇࡊࡥࡖࡆࡔࡖࡍࡔࡔࠢᰑ"))]):
        return {
            bstack1ll1lll_opy_ (u"ࠦࡳࡧ࡭ࡦࠤᰒ"): bstack1ll1lll_opy_ (u"ࠧࡇࡗࡔࠢࡆࡳࡩ࡫ࡂࡶ࡫࡯ࡨࠧᰓ"),
            bstack1ll1lll_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤᰔ"): env.get(bstack1ll1lll_opy_ (u"ࠢࡄࡑࡇࡉࡇ࡛ࡉࡍࡆࡢࡔ࡚ࡈࡌࡊࡅࡢࡆ࡚ࡏࡌࡅࡡࡘࡖࡑࠨᰕ")),
            bstack1ll1lll_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥᰖ"): env.get(bstack1ll1lll_opy_ (u"ࠤࡆࡓࡉࡋࡂࡖࡋࡏࡈࡤࡈࡕࡊࡎࡇࡣࡎࡊࠢᰗ")),
            bstack1ll1lll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤᰘ"): env.get(bstack1ll1lll_opy_ (u"ࠦࡈࡕࡄࡆࡄࡘࡍࡑࡊ࡟ࡃࡗࡌࡐࡉࡥࡉࡅࠤᰙ"))
        }
    if env.get(bstack1ll1lll_opy_ (u"ࠧࡨࡡ࡮ࡤࡲࡳࡤࡨࡵࡪ࡮ࡧࡒࡺࡳࡢࡦࡴࠥᰚ")):
        return {
            bstack1ll1lll_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦᰛ"): bstack1ll1lll_opy_ (u"ࠢࡃࡣࡰࡦࡴࡵࠢᰜ"),
            bstack1ll1lll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦᰝ"): env.get(bstack1ll1lll_opy_ (u"ࠤࡥࡥࡲࡨ࡯ࡰࡡࡥࡹ࡮ࡲࡤࡓࡧࡶࡹࡱࡺࡳࡖࡴ࡯ࠦᰞ")),
            bstack1ll1lll_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧᰟ"): env.get(bstack1ll1lll_opy_ (u"ࠦࡧࡧ࡭ࡣࡱࡲࡣࡸ࡮࡯ࡳࡶࡍࡳࡧࡔࡡ࡮ࡧࠥᰠ")),
            bstack1ll1lll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦᰡ"): env.get(bstack1ll1lll_opy_ (u"ࠨࡢࡢ࡯ࡥࡳࡴࡥࡢࡶ࡫࡯ࡨࡓࡻ࡭ࡣࡧࡵࠦᰢ"))
        }
    if env.get(bstack1ll1lll_opy_ (u"ࠢࡘࡇࡕࡇࡐࡋࡒࠣᰣ")) or env.get(bstack1ll1lll_opy_ (u"࡙ࠣࡈࡖࡈࡑࡅࡓࡡࡐࡅࡎࡔ࡟ࡑࡋࡓࡉࡑࡏࡎࡆࡡࡖࡘࡆࡘࡔࡆࡆࠥᰤ")):
        return {
            bstack1ll1lll_opy_ (u"ࠤࡱࡥࡲ࡫ࠢᰥ"): bstack1ll1lll_opy_ (u"࡛ࠥࡪࡸࡣ࡬ࡧࡵࠦᰦ"),
            bstack1ll1lll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢᰧ"): env.get(bstack1ll1lll_opy_ (u"ࠧ࡝ࡅࡓࡅࡎࡉࡗࡥࡂࡖࡋࡏࡈࡤ࡛ࡒࡍࠤᰨ")),
            bstack1ll1lll_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣᰩ"): bstack1ll1lll_opy_ (u"ࠢࡎࡣ࡬ࡲࠥࡖࡩࡱࡧ࡯࡭ࡳ࡫ࠢᰪ") if env.get(bstack1ll1lll_opy_ (u"࡙ࠣࡈࡖࡈࡑࡅࡓࡡࡐࡅࡎࡔ࡟ࡑࡋࡓࡉࡑࡏࡎࡆࡡࡖࡘࡆࡘࡔࡆࡆࠥᰫ")) else None,
            bstack1ll1lll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣᰬ"): env.get(bstack1ll1lll_opy_ (u"࡛ࠥࡊࡘࡃࡌࡇࡕࡣࡌࡏࡔࡠࡅࡒࡑࡒࡏࡔࠣᰭ"))
        }
    if any([env.get(bstack1ll1lll_opy_ (u"ࠦࡌࡉࡐࡠࡒࡕࡓࡏࡋࡃࡕࠤᰮ")), env.get(bstack1ll1lll_opy_ (u"ࠧࡍࡃࡍࡑࡘࡈࡤࡖࡒࡐࡌࡈࡇ࡙ࠨᰯ")), env.get(bstack1ll1lll_opy_ (u"ࠨࡇࡐࡑࡊࡐࡊࡥࡃࡍࡑࡘࡈࡤࡖࡒࡐࡌࡈࡇ࡙ࠨᰰ"))]):
        return {
            bstack1ll1lll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧᰱ"): bstack1ll1lll_opy_ (u"ࠣࡉࡲࡳ࡬ࡲࡥࠡࡅ࡯ࡳࡺࡪࠢᰲ"),
            bstack1ll1lll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧᰳ"): None,
            bstack1ll1lll_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧᰴ"): env.get(bstack1ll1lll_opy_ (u"ࠦࡕࡘࡏࡋࡇࡆࡘࡤࡏࡄࠣᰵ")),
            bstack1ll1lll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦᰶ"): env.get(bstack1ll1lll_opy_ (u"ࠨࡂࡖࡋࡏࡈࡤࡏࡄ᰷ࠣ"))
        }
    if env.get(bstack1ll1lll_opy_ (u"ࠢࡔࡊࡌࡔࡕࡇࡂࡍࡇࠥ᰸")):
        return {
            bstack1ll1lll_opy_ (u"ࠣࡰࡤࡱࡪࠨ᰹"): bstack1ll1lll_opy_ (u"ࠤࡖ࡬࡮ࡶࡰࡢࡤ࡯ࡩࠧ᰺"),
            bstack1ll1lll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨ᰻"): env.get(bstack1ll1lll_opy_ (u"ࠦࡘࡎࡉࡑࡒࡄࡆࡑࡋ࡟ࡃࡗࡌࡐࡉࡥࡕࡓࡎࠥ᰼")),
            bstack1ll1lll_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢ᰽"): bstack1ll1lll_opy_ (u"ࠨࡊࡰࡤࠣࠧࢀࢃࠢ᰾").format(env.get(bstack1ll1lll_opy_ (u"ࠧࡔࡊࡌࡔࡕࡇࡂࡍࡇࡢࡎࡔࡈ࡟ࡊࡆࠪ᰿"))) if env.get(bstack1ll1lll_opy_ (u"ࠣࡕࡋࡍࡕࡖࡁࡃࡎࡈࡣࡏࡕࡂࡠࡋࡇࠦ᱀")) else None,
            bstack1ll1lll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣ᱁"): env.get(bstack1ll1lll_opy_ (u"ࠥࡗࡍࡏࡐࡑࡃࡅࡐࡊࡥࡂࡖࡋࡏࡈࡤࡔࡕࡎࡄࡈࡖࠧ᱂"))
        }
    if bstack1ll111ll11_opy_(env.get(bstack1ll1lll_opy_ (u"ࠦࡓࡋࡔࡍࡋࡉ࡝ࠧ᱃"))):
        return {
            bstack1ll1lll_opy_ (u"ࠧࡴࡡ࡮ࡧࠥ᱄"): bstack1ll1lll_opy_ (u"ࠨࡎࡦࡶ࡯࡭࡫ࡿࠢ᱅"),
            bstack1ll1lll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥ᱆"): env.get(bstack1ll1lll_opy_ (u"ࠣࡆࡈࡔࡑࡕ࡙ࡠࡗࡕࡐࠧ᱇")),
            bstack1ll1lll_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦ᱈"): env.get(bstack1ll1lll_opy_ (u"ࠥࡗࡎ࡚ࡅࡠࡐࡄࡑࡊࠨ᱉")),
            bstack1ll1lll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥ᱊"): env.get(bstack1ll1lll_opy_ (u"ࠧࡈࡕࡊࡎࡇࡣࡎࡊࠢ᱋"))
        }
    if bstack1ll111ll11_opy_(env.get(bstack1ll1lll_opy_ (u"ࠨࡇࡊࡖࡋ࡙ࡇࡥࡁࡄࡖࡌࡓࡓ࡙ࠢ᱌"))):
        return {
            bstack1ll1lll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧᱍ"): bstack1ll1lll_opy_ (u"ࠣࡉ࡬ࡸࡍࡻࡢࠡࡃࡦࡸ࡮ࡵ࡮ࡴࠤᱎ"),
            bstack1ll1lll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧᱏ"): bstack1ll1lll_opy_ (u"ࠥࡿࢂ࠵ࡻࡾ࠱ࡤࡧࡹ࡯࡯࡯ࡵ࠲ࡶࡺࡴࡳ࠰ࡽࢀࠦ᱐").format(env.get(bstack1ll1lll_opy_ (u"ࠫࡌࡏࡔࡉࡗࡅࡣࡘࡋࡒࡗࡇࡕࡣ࡚ࡘࡌࠨ᱑")), env.get(bstack1ll1lll_opy_ (u"ࠬࡍࡉࡕࡊࡘࡆࡤࡘࡅࡑࡑࡖࡍ࡙ࡕࡒ࡚ࠩ᱒")), env.get(bstack1ll1lll_opy_ (u"࠭ࡇࡊࡖࡋ࡙ࡇࡥࡒࡖࡐࡢࡍࡉ࠭᱓"))),
            bstack1ll1lll_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤ᱔"): env.get(bstack1ll1lll_opy_ (u"ࠣࡉࡌࡘࡍ࡛ࡂࡠ࡙ࡒࡖࡐࡌࡌࡐ࡙ࠥ᱕")),
            bstack1ll1lll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣ᱖"): env.get(bstack1ll1lll_opy_ (u"ࠥࡋࡎ࡚ࡈࡖࡄࡢࡖ࡚ࡔ࡟ࡊࡆࠥ᱗"))
        }
    if env.get(bstack1ll1lll_opy_ (u"ࠦࡈࡏࠢ᱘")) == bstack1ll1lll_opy_ (u"ࠧࡺࡲࡶࡧࠥ᱙") and env.get(bstack1ll1lll_opy_ (u"ࠨࡖࡆࡔࡆࡉࡑࠨᱚ")) == bstack1ll1lll_opy_ (u"ࠢ࠲ࠤᱛ"):
        return {
            bstack1ll1lll_opy_ (u"ࠣࡰࡤࡱࡪࠨᱜ"): bstack1ll1lll_opy_ (u"ࠤ࡙ࡩࡷࡩࡥ࡭ࠤᱝ"),
            bstack1ll1lll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨᱞ"): bstack1ll1lll_opy_ (u"ࠦ࡭ࡺࡴࡱ࠼࠲࠳ࢀࢃࠢᱟ").format(env.get(bstack1ll1lll_opy_ (u"ࠬ࡜ࡅࡓࡅࡈࡐࡤ࡛ࡒࡍࠩᱠ"))),
            bstack1ll1lll_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣᱡ"): None,
            bstack1ll1lll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨᱢ"): None,
        }
    if env.get(bstack1ll1lll_opy_ (u"ࠣࡖࡈࡅࡒࡉࡉࡕ࡛ࡢ࡚ࡊࡘࡓࡊࡑࡑࠦᱣ")):
        return {
            bstack1ll1lll_opy_ (u"ࠤࡱࡥࡲ࡫ࠢᱤ"): bstack1ll1lll_opy_ (u"ࠥࡘࡪࡧ࡭ࡤ࡫ࡷࡽࠧᱥ"),
            bstack1ll1lll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢᱦ"): None,
            bstack1ll1lll_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢᱧ"): env.get(bstack1ll1lll_opy_ (u"ࠨࡔࡆࡃࡐࡇࡎ࡚࡙ࡠࡒࡕࡓࡏࡋࡃࡕࡡࡑࡅࡒࡋࠢᱨ")),
            bstack1ll1lll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨᱩ"): env.get(bstack1ll1lll_opy_ (u"ࠣࡄࡘࡍࡑࡊ࡟ࡏࡗࡐࡆࡊࡘࠢᱪ"))
        }
    if any([env.get(bstack1ll1lll_opy_ (u"ࠤࡆࡓࡓࡉࡏࡖࡔࡖࡉࠧᱫ")), env.get(bstack1ll1lll_opy_ (u"ࠥࡇࡔࡔࡃࡐࡗࡕࡗࡊࡥࡕࡓࡎࠥᱬ")), env.get(bstack1ll1lll_opy_ (u"ࠦࡈࡕࡎࡄࡑࡘࡖࡘࡋ࡟ࡖࡕࡈࡖࡓࡇࡍࡆࠤᱭ")), env.get(bstack1ll1lll_opy_ (u"ࠧࡉࡏࡏࡅࡒ࡙ࡗ࡙ࡅࡠࡖࡈࡅࡒࠨᱮ"))]):
        return {
            bstack1ll1lll_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦᱯ"): bstack1ll1lll_opy_ (u"ࠢࡄࡱࡱࡧࡴࡻࡲࡴࡧࠥᱰ"),
            bstack1ll1lll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦᱱ"): None,
            bstack1ll1lll_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦᱲ"): env.get(bstack1ll1lll_opy_ (u"ࠥࡆ࡚ࡏࡌࡅࡡࡍࡓࡇࡥࡎࡂࡏࡈࠦᱳ")) or None,
            bstack1ll1lll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥᱴ"): env.get(bstack1ll1lll_opy_ (u"ࠧࡈࡕࡊࡎࡇࡣࡎࡊࠢᱵ"), 0)
        }
    if env.get(bstack1ll1lll_opy_ (u"ࠨࡇࡐࡡࡍࡓࡇࡥࡎࡂࡏࡈࠦᱶ")):
        return {
            bstack1ll1lll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧᱷ"): bstack1ll1lll_opy_ (u"ࠣࡉࡲࡇࡉࠨᱸ"),
            bstack1ll1lll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧᱹ"): None,
            bstack1ll1lll_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧᱺ"): env.get(bstack1ll1lll_opy_ (u"ࠦࡌࡕ࡟ࡋࡑࡅࡣࡓࡇࡍࡆࠤᱻ")),
            bstack1ll1lll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦᱼ"): env.get(bstack1ll1lll_opy_ (u"ࠨࡇࡐࡡࡓࡍࡕࡋࡌࡊࡐࡈࡣࡈࡕࡕࡏࡖࡈࡖࠧᱽ"))
        }
    if env.get(bstack1ll1lll_opy_ (u"ࠢࡄࡈࡢࡆ࡚ࡏࡌࡅࡡࡌࡈࠧ᱾")):
        return {
            bstack1ll1lll_opy_ (u"ࠣࡰࡤࡱࡪࠨ᱿"): bstack1ll1lll_opy_ (u"ࠤࡆࡳࡩ࡫ࡆࡳࡧࡶ࡬ࠧᲀ"),
            bstack1ll1lll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨᲁ"): env.get(bstack1ll1lll_opy_ (u"ࠦࡈࡌ࡟ࡃࡗࡌࡐࡉࡥࡕࡓࡎࠥᲂ")),
            bstack1ll1lll_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢᲃ"): env.get(bstack1ll1lll_opy_ (u"ࠨࡃࡇࡡࡓࡍࡕࡋࡌࡊࡐࡈࡣࡓࡇࡍࡆࠤᲄ")),
            bstack1ll1lll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨᲅ"): env.get(bstack1ll1lll_opy_ (u"ࠣࡅࡉࡣࡇ࡛ࡉࡍࡆࡢࡍࡉࠨᲆ"))
        }
    return {bstack1ll1lll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣᲇ"): None}
def get_host_info():
    return {
        bstack1ll1lll_opy_ (u"ࠥ࡬ࡴࡹࡴ࡯ࡣࡰࡩࠧᲈ"): platform.node(),
        bstack1ll1lll_opy_ (u"ࠦࡵࡲࡡࡵࡨࡲࡶࡲࠨᲉ"): platform.system(),
        bstack1ll1lll_opy_ (u"ࠧࡺࡹࡱࡧࠥᲊ"): platform.machine(),
        bstack1ll1lll_opy_ (u"ࠨࡶࡦࡴࡶ࡭ࡴࡴࠢ᲋"): platform.version(),
        bstack1ll1lll_opy_ (u"ࠢࡢࡴࡦ࡬ࠧ᲌"): platform.architecture()[0]
    }
def bstack111llllll1_opy_():
    try:
        import selenium
        return True
    except ImportError:
        return False
def bstack11l11l111ll_opy_():
    if bstack11l1l11l_opy_.get_property(bstack1ll1lll_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫ࡠࡵࡨࡷࡸ࡯࡯࡯ࠩ᲍")):
        return bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠨ᲎")
    return bstack1ll1lll_opy_ (u"ࠪࡹࡳࡱ࡮ࡰࡹࡱࡣ࡬ࡸࡩࡥࠩ᲏")
def bstack111ll1l1111_opy_(driver):
    info = {
        bstack1ll1lll_opy_ (u"ࠫࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠪᲐ"): driver.capabilities,
        bstack1ll1lll_opy_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳࡥࡩࡥࠩᲑ"): driver.session_id,
        bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࠧᲒ"): driver.capabilities.get(bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬᲓ"), None),
        bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡡࡹࡩࡷࡹࡩࡰࡰࠪᲔ"): driver.capabilities.get(bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪᲕ"), None),
        bstack1ll1lll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࠬᲖ"): driver.capabilities.get(bstack1ll1lll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡔࡡ࡮ࡧࠪᲗ"), None),
        bstack1ll1lll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨᲘ"):driver.capabilities.get(bstack1ll1lll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡗࡧࡵࡷ࡮ࡵ࡮ࠨᲙ"), None),
    }
    if bstack11l11l111ll_opy_() == bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠭Ლ"):
        if bstack1ll1l111_opy_():
            info[bstack1ll1lll_opy_ (u"ࠨࡲࡵࡳࡩࡻࡣࡵࠩᲛ")] = bstack1ll1lll_opy_ (u"ࠩࡤࡴࡵ࠳ࡡࡶࡶࡲࡱࡦࡺࡥࠨᲜ")
        elif driver.capabilities.get(bstack1ll1lll_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭࠽ࡳࡵࡺࡩࡰࡰࡶࠫᲝ"), {}).get(bstack1ll1lll_opy_ (u"ࠫࡹࡻࡲࡣࡱࡶࡧࡦࡲࡥࠨᲞ"), False):
            info[bstack1ll1lll_opy_ (u"ࠬࡶࡲࡰࡦࡸࡧࡹ࠭Ჟ")] = bstack1ll1lll_opy_ (u"࠭ࡴࡶࡴࡥࡳࡸࡩࡡ࡭ࡧࠪᲠ")
        else:
            info[bstack1ll1lll_opy_ (u"ࠧࡱࡴࡲࡨࡺࡩࡴࠨᲡ")] = bstack1ll1lll_opy_ (u"ࠨࡣࡸࡸࡴࡳࡡࡵࡧࠪᲢ")
    return info
def bstack1ll1l111_opy_():
    if bstack11l1l11l_opy_.get_property(bstack1ll1lll_opy_ (u"ࠩࡤࡴࡵࡥࡡࡶࡶࡲࡱࡦࡺࡥࠨᲣ")):
        return True
    if bstack1ll111ll11_opy_(os.environ.get(bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡌࡗࡤࡇࡐࡑࡡࡄ࡙࡙ࡕࡍࡂࡖࡈࠫᲤ"), None)):
        return True
    return False
def bstack111lll1ll1_opy_(bstack111lll1ll1l_opy_, url, data, config):
    headers = config.get(bstack1ll1lll_opy_ (u"ࠫ࡭࡫ࡡࡥࡧࡵࡷࠬᲥ"), None)
    proxies = bstack1l111l1111_opy_(config, url)
    auth = config.get(bstack1ll1lll_opy_ (u"ࠬࡧࡵࡵࡪࠪᲦ"), None)
    response = requests.request(
            bstack111lll1ll1l_opy_,
            url=url,
            headers=headers,
            auth=auth,
            json=data,
            proxies=proxies
        )
    return response
def bstack1ll1ll1l1l_opy_(bstack111l11lll_opy_, size):
    bstack1l111lll_opy_ = []
    while len(bstack111l11lll_opy_) > size:
        bstack11l1lll11l_opy_ = bstack111l11lll_opy_[:size]
        bstack1l111lll_opy_.append(bstack11l1lll11l_opy_)
        bstack111l11lll_opy_ = bstack111l11lll_opy_[size:]
    bstack1l111lll_opy_.append(bstack111l11lll_opy_)
    return bstack1l111lll_opy_
def bstack11l11ll11l1_opy_(message, bstack111llllll11_opy_=False):
    os.write(1, bytes(message, bstack1ll1lll_opy_ (u"࠭ࡵࡵࡨ࠰࠼ࠬᲧ")))
    os.write(1, bytes(bstack1ll1lll_opy_ (u"ࠧ࡝ࡰࠪᲨ"), bstack1ll1lll_opy_ (u"ࠨࡷࡷࡪ࠲࠾ࠧᲩ")))
    if bstack111llllll11_opy_:
        with open(bstack1ll1lll_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠯ࡲ࠵࠶ࡿ࠭ࠨᲪ") + os.environ[bstack1ll1lll_opy_ (u"ࠪࡆࡘࡥࡔࡆࡕࡗࡓࡕ࡙࡟ࡃࡗࡌࡐࡉࡥࡈࡂࡕࡋࡉࡉࡥࡉࡅࠩᲫ")] + bstack1ll1lll_opy_ (u"ࠫ࠳ࡲ࡯ࡨࠩᲬ"), bstack1ll1lll_opy_ (u"ࠬࡧࠧᲭ")) as f:
            f.write(message + bstack1ll1lll_opy_ (u"࠭࡜࡯ࠩᲮ"))
def bstack1l1l1ll11l1_opy_():
    return os.environ[bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡁࡖࡖࡒࡑࡆ࡚ࡉࡐࡐࠪᲯ")].lower() == bstack1ll1lll_opy_ (u"ࠨࡶࡵࡹࡪ࠭Ჰ")
def bstack1l11l1llll_opy_():
    return bstack111l1l1111_opy_().replace(tzinfo=None).isoformat() + bstack1ll1lll_opy_ (u"ࠩ࡝ࠫᲱ")
def bstack111ll1l1l11_opy_(start, finish):
    return (datetime.datetime.fromisoformat(finish.rstrip(bstack1ll1lll_opy_ (u"ࠪ࡞ࠬᲲ"))) - datetime.datetime.fromisoformat(start.rstrip(bstack1ll1lll_opy_ (u"ࠫ࡟࠭Ჳ")))).total_seconds() * 1000
def bstack11l11l111l1_opy_(timestamp):
    return bstack11l1111ll1l_opy_(timestamp).isoformat() + bstack1ll1lll_opy_ (u"ࠬࡠࠧᲴ")
def bstack11l11l1ll1l_opy_(bstack11l1111lll1_opy_):
    date_format = bstack1ll1lll_opy_ (u"࡚࠭ࠥࠧࡰࠩࡩࠦࠥࡉ࠼ࠨࡑ࠿ࠫࡓ࠯ࠧࡩࠫᲵ")
    bstack111ll1l1lll_opy_ = datetime.datetime.strptime(bstack11l1111lll1_opy_, date_format)
    return bstack111ll1l1lll_opy_.isoformat() + bstack1ll1lll_opy_ (u"࡛ࠧࠩᲶ")
def bstack111lll111ll_opy_(outcome):
    _, exception, _ = outcome.excinfo or (None, None, None)
    if exception:
        return bstack1ll1lll_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨᲷ")
    else:
        return bstack1ll1lll_opy_ (u"ࠩࡳࡥࡸࡹࡥࡥࠩᲸ")
def bstack1ll111ll11_opy_(val):
    if val is None:
        return False
    return val.__str__().lower() == bstack1ll1lll_opy_ (u"ࠪࡸࡷࡻࡥࠨᲹ")
def bstack111lll1lll1_opy_(val):
    return val.__str__().lower() == bstack1ll1lll_opy_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪᲺ")
def error_handler(bstack111lllll111_opy_=Exception, class_method=False, default_value=None):
    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except bstack111lllll111_opy_ as e:
                print(bstack1ll1lll_opy_ (u"ࠧࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠦࡻࡾࠢ࠰ࡂࠥࢁࡽ࠻ࠢࡾࢁࠧ᲻").format(func.__name__, bstack111lllll111_opy_.__name__, str(e)))
                return default_value
        return wrapper
    def bstack111ll11ll11_opy_(bstack111ll11l1l1_opy_):
        def wrapped(cls, *args, **kwargs):
            try:
                return bstack111ll11l1l1_opy_(cls, *args, **kwargs)
            except bstack111lllll111_opy_ as e:
                print(bstack1ll1lll_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡼࡿࠣ࠱ࡃࠦࡻࡾ࠼ࠣࡿࢂࠨ᲼").format(bstack111ll11l1l1_opy_.__name__, bstack111lllll111_opy_.__name__, str(e)))
                return default_value
        return wrapped
    if class_method:
        return bstack111ll11ll11_opy_
    else:
        return decorator
def bstack11ll1l1111_opy_(bstack1111l111ll_opy_):
    if os.getenv(bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡁࡖࡖࡒࡑࡆ࡚ࡉࡐࡐࠪᲽ")) is not None:
        return bstack1ll111ll11_opy_(os.getenv(bstack1ll1lll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡂࡗࡗࡓࡒࡇࡔࡊࡑࡑࠫᲾ")))
    if bstack1ll1lll_opy_ (u"ࠩࡤࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳ࠭Ჿ") in bstack1111l111ll_opy_ and bstack111lll1lll1_opy_(bstack1111l111ll_opy_[bstack1ll1lll_opy_ (u"ࠪࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࠧ᳀")]):
        return False
    if bstack1ll1lll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳ࠭᳁") in bstack1111l111ll_opy_ and bstack111lll1lll1_opy_(bstack1111l111ll_opy_[bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡅࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࠧ᳂")]):
        return False
    return True
def bstack1l1111ll1l_opy_():
    try:
        from pytest_bdd import reporting
        bstack11l11lll11l_opy_ = os.environ.get(bstack1ll1lll_opy_ (u"ࠨࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤ࡛ࡓࡆࡔࡢࡊࡗࡇࡍࡆ࡙ࡒࡖࡐࠨ᳃"), None)
        return bstack11l11lll11l_opy_ is None or bstack11l11lll11l_opy_ == bstack1ll1lll_opy_ (u"ࠢࡱࡻࡷࡩࡸࡺ࠭ࡣࡦࡧࠦ᳄")
    except Exception as e:
        return False
def bstack1l1ll111_opy_(hub_url, CONFIG):
    if bstack1lll1l1ll1_opy_() <= version.parse(bstack1ll1lll_opy_ (u"ࠨ࠵࠱࠵࠸࠴࠰ࠨ᳅")):
        if hub_url:
            return bstack1ll1lll_opy_ (u"ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࠥ᳆") + hub_url + bstack1ll1lll_opy_ (u"ࠥ࠾࠽࠶࠯ࡸࡦ࠲࡬ࡺࡨࠢ᳇")
        return bstack111l1lll1_opy_
    if hub_url:
        return bstack1ll1lll_opy_ (u"ࠦ࡭ࡺࡴࡱࡵ࠽࠳࠴ࠨ᳈") + hub_url + bstack1ll1lll_opy_ (u"ࠧ࠵ࡷࡥ࠱࡫ࡹࡧࠨ᳉")
    return bstack11ll1111l_opy_
def bstack111llll1ll1_opy_():
    return isinstance(os.getenv(bstack1ll1lll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡖ࡙ࡕࡇࡖࡘࡤࡖࡌࡖࡉࡌࡒࠬ᳊")), str)
def bstack1l111l11ll_opy_(url):
    return urlparse(url).hostname
def bstack1lll1l1l1_opy_(hostname):
    for bstack1l111lll1_opy_ in bstack1l1ll1l1l1_opy_:
        regex = re.compile(bstack1l111lll1_opy_)
        if regex.match(hostname):
            return True
    return False
def bstack11l111111ll_opy_(bstack11l11ll1ll1_opy_, file_name, logger):
    bstack1lll111l1_opy_ = os.path.join(os.path.expanduser(bstack1ll1lll_opy_ (u"ࠧࡿࠩ᳋")), bstack11l11ll1ll1_opy_)
    try:
        if not os.path.exists(bstack1lll111l1_opy_):
            os.makedirs(bstack1lll111l1_opy_)
        file_path = os.path.join(os.path.expanduser(bstack1ll1lll_opy_ (u"ࠨࢀࠪ᳌")), bstack11l11ll1ll1_opy_, file_name)
        if not os.path.isfile(file_path):
            with open(file_path, bstack1ll1lll_opy_ (u"ࠩࡺࠫ᳍")):
                pass
            with open(file_path, bstack1ll1lll_opy_ (u"ࠥࡻ࠰ࠨ᳎")) as outfile:
                json.dump({}, outfile)
        return file_path
    except Exception as e:
        logger.debug(bstack1l1lll11ll_opy_.format(str(e)))
def bstack11l111ll11l_opy_(file_name, key, value, logger):
    file_path = bstack11l111111ll_opy_(bstack1ll1lll_opy_ (u"ࠫ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠫ᳏"), file_name, logger)
    if file_path != None:
        if os.path.exists(file_path):
            bstack1lll1lll1l_opy_ = json.load(open(file_path, bstack1ll1lll_opy_ (u"ࠬࡸࡢࠨ᳐")))
        else:
            bstack1lll1lll1l_opy_ = {}
        bstack1lll1lll1l_opy_[key] = value
        with open(file_path, bstack1ll1lll_opy_ (u"ࠨࡷࠬࠤ᳑")) as outfile:
            json.dump(bstack1lll1lll1l_opy_, outfile)
def bstack11lll1l1ll_opy_(file_name, logger):
    file_path = bstack11l111111ll_opy_(bstack1ll1lll_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧ᳒"), file_name, logger)
    bstack1lll1lll1l_opy_ = {}
    if file_path != None and os.path.exists(file_path):
        with open(file_path, bstack1ll1lll_opy_ (u"ࠨࡴࠪ᳓")) as bstack11l111llll_opy_:
            bstack1lll1lll1l_opy_ = json.load(bstack11l111llll_opy_)
    return bstack1lll1lll1l_opy_
def bstack11111l11l_opy_(file_path, logger):
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
    except Exception as e:
        logger.debug(bstack1ll1lll_opy_ (u"ࠩࡈࡶࡷࡵࡲࠡ࡫ࡱࠤࡩ࡫࡬ࡦࡶ࡬ࡲ࡬ࠦࡦࡪ࡮ࡨ࠾᳔ࠥ࠭") + file_path + bstack1ll1lll_opy_ (u"ࠪࠤ᳕ࠬ") + str(e))
def bstack1lll1l1ll1_opy_():
    from selenium import webdriver
    return version.parse(webdriver.__version__)
class Notset:
    def __repr__(self):
        return bstack1ll1lll_opy_ (u"ࠦࡁࡔࡏࡕࡕࡈࡘࡃࠨ᳖")
def bstack11l1l1ll1l_opy_(config):
    if bstack1ll1lll_opy_ (u"ࠬ࡯ࡳࡑ࡮ࡤࡽࡼࡸࡩࡨࡪࡷ᳗ࠫ") in config:
        del (config[bstack1ll1lll_opy_ (u"࠭ࡩࡴࡒ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸ᳘ࠬ")])
        return False
    if bstack1lll1l1ll1_opy_() < version.parse(bstack1ll1lll_opy_ (u"ࠧ࠴࠰࠷࠲࠵᳙࠭")):
        return False
    if bstack1lll1l1ll1_opy_() >= version.parse(bstack1ll1lll_opy_ (u"ࠨ࠶࠱࠵࠳࠻ࠧ᳚")):
        return True
    if bstack1ll1lll_opy_ (u"ࠩࡸࡷࡪ࡝࠳ࡄࠩ᳛") in config and config[bstack1ll1lll_opy_ (u"ࠪࡹࡸ࡫ࡗ࠴ࡅ᳜ࠪ")] is False:
        return False
    else:
        return True
def bstack11l1l111l1_opy_(args_list, bstack11l11l1ll11_opy_):
    index = -1
    for value in bstack11l11l1ll11_opy_:
        try:
            index = args_list.index(value)
            return index
        except Exception as e:
            return index
    return index
def bstack11ll11l1ll1_opy_(a, b):
  for k, v in b.items():
    if isinstance(v, dict) and k in a and isinstance(a[k], dict):
        bstack11ll11l1ll1_opy_(a[k], v)
    else:
        a[k] = v
class Result:
    def __init__(self, result=None, duration=None, exception=None, bstack111l1lllll_opy_=None):
        self.result = result
        self.duration = duration
        self.exception = exception
        self.exception_type = type(self.exception).__name__ if exception else None
        self.bstack111l1lllll_opy_ = bstack111l1lllll_opy_
    @classmethod
    def passed(cls):
        return Result(result=bstack1ll1lll_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧ᳝ࠫ"))
    @classmethod
    def failed(cls, exception=None):
        return Result(result=bstack1ll1lll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨ᳞ࠬ"), exception=exception)
    def bstack1111111l11_opy_(self):
        if self.result != bstack1ll1lll_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ᳟࠭"):
            return None
        if isinstance(self.exception_type, str) and bstack1ll1lll_opy_ (u"ࠢࡂࡵࡶࡩࡷࡺࡩࡰࡰࠥ᳠") in self.exception_type:
            return bstack1ll1lll_opy_ (u"ࠣࡃࡶࡷࡪࡸࡴࡪࡱࡱࡉࡷࡸ࡯ࡳࠤ᳡")
        return bstack1ll1lll_opy_ (u"ࠤࡘࡲ࡭ࡧ࡮ࡥ࡮ࡨࡨࡊࡸࡲࡰࡴ᳢ࠥ")
    def bstack11l1111111l_opy_(self):
        if self.result != bstack1ll1lll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦ᳣ࠪ"):
            return None
        if self.bstack111l1lllll_opy_:
            return self.bstack111l1lllll_opy_
        return bstack11l11ll1lll_opy_(self.exception)
def bstack11l11ll1lll_opy_(exc):
    return [traceback.format_exception(exc)]
def bstack11l11l1l1ll_opy_(message):
    if isinstance(message, str):
        return not bool(message and message.strip())
    return True
def bstack11l1l1lll_opy_(object, key, default_value):
    if not object or not object.__dict__:
        return default_value
    if key in object.__dict__.keys():
        return object.__dict__.get(key)
    return default_value
def bstack1l1l111l11_opy_(config, logger):
    try:
        import playwright
        bstack111llll1111_opy_ = playwright.__file__
        bstack111lll11ll1_opy_ = os.path.split(bstack111llll1111_opy_)
        bstack11l111l11ll_opy_ = bstack111lll11ll1_opy_[0] + bstack1ll1lll_opy_ (u"ࠫ࠴ࡪࡲࡪࡸࡨࡶ࠴ࡶࡡࡤ࡭ࡤ࡫ࡪ࠵࡬ࡪࡤ࠲ࡧࡱ࡯࠯ࡤ࡮࡬࠲࡯ࡹ᳤ࠧ")
        os.environ[bstack1ll1lll_opy_ (u"ࠬࡍࡌࡐࡄࡄࡐࡤࡇࡇࡆࡐࡗࡣࡍ࡚ࡔࡑࡡࡓࡖࡔ࡞࡙ࠨ᳥")] = bstack1ll1111ll1_opy_(config)
        with open(bstack11l111l11ll_opy_, bstack1ll1lll_opy_ (u"࠭ࡲࠨ᳦")) as f:
            bstack1ll1111lll_opy_ = f.read()
            bstack111ll1l1ll1_opy_ = bstack1ll1lll_opy_ (u"ࠧࡨ࡮ࡲࡦࡦࡲ࠭ࡢࡩࡨࡲࡹ᳧࠭")
            bstack11l11l11l1l_opy_ = bstack1ll1111lll_opy_.find(bstack111ll1l1ll1_opy_)
            if bstack11l11l11l1l_opy_ == -1:
              process = subprocess.Popen(bstack1ll1lll_opy_ (u"ࠣࡰࡳࡱࠥ࡯࡮ࡴࡶࡤࡰࡱࠦࡧ࡭ࡱࡥࡥࡱ࠳ࡡࡨࡧࡱࡸ᳨ࠧ"), shell=True, cwd=bstack111lll11ll1_opy_[0])
              process.wait()
              bstack11l111ll1l1_opy_ = bstack1ll1lll_opy_ (u"ࠩࠥࡹࡸ࡫ࠠࡴࡶࡵ࡭ࡨࡺࠢ࠼ࠩᳩ")
              bstack11l111lll11_opy_ = bstack1ll1lll_opy_ (u"ࠥࠦࠧࠦ࡜ࠣࡷࡶࡩࠥࡹࡴࡳ࡫ࡦࡸࡡࠨ࠻ࠡࡥࡲࡲࡸࡺࠠࡼࠢࡥࡳࡴࡺࡳࡵࡴࡤࡴࠥࢃࠠ࠾ࠢࡵࡩࡶࡻࡩࡳࡧࠫࠫ࡬ࡲ࡯ࡣࡣ࡯࠱ࡦ࡭ࡥ࡯ࡶࠪ࠭ࡀࠦࡩࡧࠢࠫࡴࡷࡵࡣࡦࡵࡶ࠲ࡪࡴࡶ࠯ࡉࡏࡓࡇࡇࡌࡠࡃࡊࡉࡓ࡚࡟ࡉࡖࡗࡔࡤࡖࡒࡐ࡚࡜࠭ࠥࡨ࡯ࡰࡶࡶࡸࡷࡧࡰࠩࠫ࠾ࠤࠧࠨࠢᳪ")
              bstack111lll1ll11_opy_ = bstack1ll1111lll_opy_.replace(bstack11l111ll1l1_opy_, bstack11l111lll11_opy_)
              with open(bstack11l111l11ll_opy_, bstack1ll1lll_opy_ (u"ࠫࡼ࠭ᳫ")) as f:
                f.write(bstack111lll1ll11_opy_)
    except Exception as e:
        logger.error(bstack1111ll1ll_opy_.format(str(e)))
def bstack1l11lllll1_opy_():
  try:
    bstack111lll11l11_opy_ = os.path.join(tempfile.gettempdir(), bstack1ll1lll_opy_ (u"ࠬࡵࡰࡵ࡫ࡰࡥࡱࡥࡨࡶࡤࡢࡹࡷࡲ࠮࡫ࡵࡲࡲࠬᳬ"))
    bstack11l111l11l1_opy_ = []
    if os.path.exists(bstack111lll11l11_opy_):
      with open(bstack111lll11l11_opy_) as f:
        bstack11l111l11l1_opy_ = json.load(f)
      os.remove(bstack111lll11l11_opy_)
    return bstack11l111l11l1_opy_
  except:
    pass
  return []
def bstack11lllll11_opy_(bstack1111lll1_opy_):
  try:
    bstack11l111l11l1_opy_ = []
    bstack111lll11l11_opy_ = os.path.join(tempfile.gettempdir(), bstack1ll1lll_opy_ (u"࠭࡯ࡱࡶ࡬ࡱࡦࡲ࡟ࡩࡷࡥࡣࡺࡸ࡬࠯࡬ࡶࡳࡳ᳭࠭"))
    if os.path.exists(bstack111lll11l11_opy_):
      with open(bstack111lll11l11_opy_) as f:
        bstack11l111l11l1_opy_ = json.load(f)
    bstack11l111l11l1_opy_.append(bstack1111lll1_opy_)
    with open(bstack111lll11l11_opy_, bstack1ll1lll_opy_ (u"ࠧࡸࠩᳮ")) as f:
        json.dump(bstack11l111l11l1_opy_, f)
  except:
    pass
def bstack11ll1111_opy_(logger, bstack111ll11l111_opy_ = False):
  try:
    test_name = os.environ.get(bstack1ll1lll_opy_ (u"ࠨࡒ࡜ࡘࡊ࡙ࡔࡠࡖࡈࡗ࡙ࡥࡎࡂࡏࡈࠫᳯ"), bstack1ll1lll_opy_ (u"ࠩࠪᳰ"))
    if test_name == bstack1ll1lll_opy_ (u"ࠪࠫᳱ"):
        test_name = threading.current_thread().__dict__.get(bstack1ll1lll_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࡆࡩࡪ࡟ࡵࡧࡶࡸࡤࡴࡡ࡮ࡧࠪᳲ"), bstack1ll1lll_opy_ (u"ࠬ࠭ᳳ"))
    bstack11l1111l11l_opy_ = bstack1ll1lll_opy_ (u"࠭ࠬࠡࠩ᳴").join(threading.current_thread().bstackTestErrorMessages)
    if bstack111ll11l111_opy_:
        bstack1l1ll11lll_opy_ = os.environ.get(bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡐࡍࡃࡗࡊࡔࡘࡍࡠࡋࡑࡈࡊ࡞ࠧᳵ"), bstack1ll1lll_opy_ (u"ࠨ࠲ࠪᳶ"))
        bstack11l1l1l1l1_opy_ = {bstack1ll1lll_opy_ (u"ࠩࡱࡥࡲ࡫ࠧ᳷"): test_name, bstack1ll1lll_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࠩ᳸"): bstack11l1111l11l_opy_, bstack1ll1lll_opy_ (u"ࠫ࡮ࡴࡤࡦࡺࠪ᳹"): bstack1l1ll11lll_opy_}
        bstack111ll11l11l_opy_ = []
        bstack11l11111111_opy_ = os.path.join(tempfile.gettempdir(), bstack1ll1lll_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸࡤࡶࡰࡱࡡࡨࡶࡷࡵࡲࡠ࡮࡬ࡷࡹ࠴ࡪࡴࡱࡱࠫᳺ"))
        if os.path.exists(bstack11l11111111_opy_):
            with open(bstack11l11111111_opy_) as f:
                bstack111ll11l11l_opy_ = json.load(f)
        bstack111ll11l11l_opy_.append(bstack11l1l1l1l1_opy_)
        with open(bstack11l11111111_opy_, bstack1ll1lll_opy_ (u"࠭ࡷࠨ᳻")) as f:
            json.dump(bstack111ll11l11l_opy_, f)
    else:
        bstack11l1l1l1l1_opy_ = {bstack1ll1lll_opy_ (u"ࠧ࡯ࡣࡰࡩࠬ᳼"): test_name, bstack1ll1lll_opy_ (u"ࠨࡧࡵࡶࡴࡸࠧ᳽"): bstack11l1111l11l_opy_, bstack1ll1lll_opy_ (u"ࠩ࡬ࡲࡩ࡫ࡸࠨ᳾"): str(multiprocessing.current_process().name)}
        if bstack1ll1lll_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭ࡢࡩࡷࡸ࡯ࡳࡡ࡯࡭ࡸࡺࠧ᳿") not in multiprocessing.current_process().__dict__.keys():
            multiprocessing.current_process().bstack_error_list = []
        multiprocessing.current_process().bstack_error_list.append(bstack11l1l1l1l1_opy_)
  except Exception as e:
      logger.warn(bstack1ll1lll_opy_ (u"࡚ࠦࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡴࡶࡲࡶࡪࠦࡰࡺࡶࡨࡷࡹࠦࡦࡶࡰࡱࡩࡱࠦࡤࡢࡶࡤ࠾ࠥࢁࡽࠣᴀ").format(e))
def bstack111l111l1_opy_(error_message, test_name, index, logger):
  try:
    from filelock import FileLock
  except ImportError:
    logger.debug(bstack1ll1lll_opy_ (u"ࠬ࡬ࡩ࡭ࡧ࡯ࡳࡨࡱࠠ࡯ࡱࡷࠤࡦࡼࡡࡪ࡮ࡤࡦࡱ࡫ࠬࠡࡷࡶ࡭ࡳ࡭ࠠࡣࡣࡶ࡭ࡨࠦࡦࡪ࡮ࡨࠤࡴࡶࡥࡳࡣࡷ࡭ࡴࡴࡳࠨᴁ"))
    try:
      bstack11l1111l1l1_opy_ = []
      bstack11l1l1l1l1_opy_ = {bstack1ll1lll_opy_ (u"࠭࡮ࡢ࡯ࡨࠫᴂ"): test_name, bstack1ll1lll_opy_ (u"ࠧࡦࡴࡵࡳࡷ࠭ᴃ"): error_message, bstack1ll1lll_opy_ (u"ࠨ࡫ࡱࡨࡪࡾࠧᴄ"): index}
      bstack11l11ll1l11_opy_ = os.path.join(tempfile.gettempdir(), bstack1ll1lll_opy_ (u"ࠩࡵࡳࡧࡵࡴࡠࡧࡵࡶࡴࡸ࡟࡭࡫ࡶࡸ࠳ࡰࡳࡰࡰࠪᴅ"))
      if os.path.exists(bstack11l11ll1l11_opy_):
          with open(bstack11l11ll1l11_opy_) as f:
              bstack11l1111l1l1_opy_ = json.load(f)
      bstack11l1111l1l1_opy_.append(bstack11l1l1l1l1_opy_)
      with open(bstack11l11ll1l11_opy_, bstack1ll1lll_opy_ (u"ࠪࡻࠬᴆ")) as f:
          json.dump(bstack11l1111l1l1_opy_, f)
    except Exception as e:
      logger.warn(bstack1ll1lll_opy_ (u"࡚ࠦࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡴࡶࡲࡶࡪࠦࡲࡰࡤࡲࡸࠥ࡬ࡵ࡯ࡰࡨࡰࠥࡪࡡࡵࡣ࠽ࠤࢀࢃࠢᴇ").format(e))
    return
  bstack11l1111l1l1_opy_ = []
  bstack11l1l1l1l1_opy_ = {bstack1ll1lll_opy_ (u"ࠬࡴࡡ࡮ࡧࠪᴈ"): test_name, bstack1ll1lll_opy_ (u"࠭ࡥࡳࡴࡲࡶࠬᴉ"): error_message, bstack1ll1lll_opy_ (u"ࠧࡪࡰࡧࡩࡽ࠭ᴊ"): index}
  bstack11l11ll1l11_opy_ = os.path.join(tempfile.gettempdir(), bstack1ll1lll_opy_ (u"ࠨࡴࡲࡦࡴࡺ࡟ࡦࡴࡵࡳࡷࡥ࡬ࡪࡵࡷ࠲࡯ࡹ࡯࡯ࠩᴋ"))
  lock_file = bstack11l11ll1l11_opy_ + bstack1ll1lll_opy_ (u"ࠩ࠱ࡰࡴࡩ࡫ࠨᴌ")
  try:
    with FileLock(lock_file, timeout=10):
      if os.path.exists(bstack11l11ll1l11_opy_):
          with open(bstack11l11ll1l11_opy_, bstack1ll1lll_opy_ (u"ࠪࡶࠬᴍ")) as f:
              content = f.read().strip()
              if content:
                  bstack11l1111l1l1_opy_ = json.load(open(bstack11l11ll1l11_opy_))
      bstack11l1111l1l1_opy_.append(bstack11l1l1l1l1_opy_)
      with open(bstack11l11ll1l11_opy_, bstack1ll1lll_opy_ (u"ࠫࡼ࠭ᴎ")) as f:
          json.dump(bstack11l1111l1l1_opy_, f)
  except Exception as e:
    logger.warn(bstack1ll1lll_opy_ (u"࡛ࠧ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡵࡷࡳࡷ࡫ࠠࡳࡱࡥࡳࡹࠦࡦࡶࡰࡱࡩࡱࠦࡤࡢࡶࡤࠤࡼ࡯ࡴࡩࠢࡩ࡭ࡱ࡫ࠠ࡭ࡱࡦ࡯࡮ࡴࡧ࠻ࠢࡾࢁࠧᴏ").format(e))
def bstack1ll111ll_opy_(bstack1ll111l11_opy_, name, logger):
  try:
    bstack11l1l1l1l1_opy_ = {bstack1ll1lll_opy_ (u"࠭࡮ࡢ࡯ࡨࠫᴐ"): name, bstack1ll1lll_opy_ (u"ࠧࡦࡴࡵࡳࡷ࠭ᴑ"): bstack1ll111l11_opy_, bstack1ll1lll_opy_ (u"ࠨ࡫ࡱࡨࡪࡾࠧᴒ"): str(threading.current_thread()._name)}
    return bstack11l1l1l1l1_opy_
  except Exception as e:
    logger.warn(bstack1ll1lll_opy_ (u"ࠤࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡹࡴࡰࡴࡨࠤࡧ࡫ࡨࡢࡸࡨࠤ࡫ࡻ࡮࡯ࡧ࡯ࠤࡩࡧࡴࡢ࠼ࠣࡿࢂࠨᴓ").format(e))
  return
def bstack111llll1l11_opy_():
    return platform.system() == bstack1ll1lll_opy_ (u"࡛ࠪ࡮ࡴࡤࡰࡹࡶࠫᴔ")
def bstack1l11ll11l1_opy_(bstack11l111lllll_opy_, config, logger):
    bstack11l111111l1_opy_ = {}
    try:
        return {key: config[key] for key in config if bstack11l111lllll_opy_.match(key)}
    except Exception as e:
        logger.debug(bstack1ll1lll_opy_ (u"࡚ࠦࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡧ࡫࡯ࡸࡪࡸࠠࡤࡱࡱࡪ࡮࡭ࠠ࡬ࡧࡼࡷࠥࡨࡹࠡࡴࡨ࡫ࡪࡾࠠ࡮ࡣࡷࡧ࡭ࡀࠠࡼࡿࠥᴕ").format(e))
    return bstack11l111111l1_opy_
def bstack11l11l1l11l_opy_(bstack111ll11lll1_opy_, bstack111ll1ll11l_opy_):
    bstack111lllll1l1_opy_ = version.parse(bstack111ll11lll1_opy_)
    bstack111ll1ll111_opy_ = version.parse(bstack111ll1ll11l_opy_)
    if bstack111lllll1l1_opy_ > bstack111ll1ll111_opy_:
        return 1
    elif bstack111lllll1l1_opy_ < bstack111ll1ll111_opy_:
        return -1
    else:
        return 0
def bstack111l1l1111_opy_():
    return datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
def bstack11l1111ll1l_opy_(timestamp):
    return datetime.datetime.fromtimestamp(timestamp, datetime.timezone.utc).replace(tzinfo=None)
def bstack11l11111lll_opy_(framework):
    from browserstack_sdk._version import __version__
    return str(framework) + str(__version__)
def bstack1l11ll11ll_opy_(options, framework, config, bstack11l1l1l1ll_opy_={}):
    if options is None:
        return
    if getattr(options, bstack1ll1lll_opy_ (u"ࠬ࡭ࡥࡵࠩᴖ"), None):
        caps = options
    else:
        caps = options.to_capabilities()
    bstack1ll1llll11_opy_ = caps.get(bstack1ll1lll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡀ࡯ࡱࡶ࡬ࡳࡳࡹࠧᴗ"))
    bstack11l11ll1l1l_opy_ = True
    bstack1ll1lllll_opy_ = os.environ[bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡌ࡚ࡈ࡟ࡖࡗࡌࡈࠬᴘ")]
    bstack1ll11l1llll_opy_ = config.get(bstack1ll1lll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨᴙ"), False)
    if bstack1ll11l1llll_opy_:
        bstack1llll11l111_opy_ = config.get(bstack1ll1lll_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࡑࡳࡸ࡮ࡵ࡮ࡴࠩᴚ"), {})
        bstack1llll11l111_opy_[bstack1ll1lll_opy_ (u"ࠪࡥࡺࡺࡨࡕࡱ࡮ࡩࡳ࠭ᴛ")] = os.getenv(bstack1ll1lll_opy_ (u"ࠫࡇ࡙࡟ࡂ࠳࠴࡝ࡤࡐࡗࡕࠩᴜ"))
        bstack11ll11lll1l_opy_ = json.loads(os.getenv(bstack1ll1lll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡡࡄࡇࡈࡋࡓࡔࡋࡅࡍࡑࡏࡔ࡚ࡡࡆࡓࡓࡌࡉࡈࡗࡕࡅ࡙ࡏࡏࡏࡡ࡜ࡑࡑ࠭ᴝ"), bstack1ll1lll_opy_ (u"࠭ࡻࡾࠩᴞ"))).get(bstack1ll1lll_opy_ (u"ࠧࡴࡥࡤࡲࡳ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨᴟ"))
    if bstack111lll1lll1_opy_(caps.get(bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡶࡵࡨ࡛࠸ࡉࠧᴠ"))) or bstack111lll1lll1_opy_(caps.get(bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡷࡶࡩࡤࡽ࠳ࡤࠩᴡ"))):
        bstack11l11ll1l1l_opy_ = False
    if bstack11l1l1ll1l_opy_({bstack1ll1lll_opy_ (u"ࠥࡹࡸ࡫ࡗ࠴ࡅࠥᴢ"): bstack11l11ll1l1l_opy_}):
        bstack1ll1llll11_opy_ = bstack1ll1llll11_opy_ or {}
        bstack1ll1llll11_opy_[bstack1ll1lll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡖࡈࡐ࠭ᴣ")] = bstack11l11111lll_opy_(framework)
        bstack1ll1llll11_opy_[bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡅࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࠧᴤ")] = bstack1l1l1ll11l1_opy_()
        bstack1ll1llll11_opy_[bstack1ll1lll_opy_ (u"࠭ࡴࡦࡵࡷ࡬ࡺࡨࡂࡶ࡫࡯ࡨ࡚ࡻࡩࡥࠩᴥ")] = bstack1ll1lllll_opy_
        bstack1ll1llll11_opy_[bstack1ll1lll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡖࡲࡰࡦࡸࡧࡹࡓࡡࡱࠩᴦ")] = bstack11l1l1l1ll_opy_
        if bstack1ll11l1llll_opy_:
            bstack1ll1llll11_opy_[bstack1ll1lll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨᴧ")] = bstack1ll11l1llll_opy_
            bstack1ll1llll11_opy_[bstack1ll1lll_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࡑࡳࡸ࡮ࡵ࡮ࡴࠩᴨ")] = bstack1llll11l111_opy_
            bstack1ll1llll11_opy_[bstack1ll1lll_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࡒࡴࡹ࡯࡯࡯ࡵࠪᴩ")][bstack1ll1lll_opy_ (u"ࠫࡸࡩࡡ࡯ࡰࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬᴪ")] = bstack11ll11lll1l_opy_
        if getattr(options, bstack1ll1lll_opy_ (u"ࠬࡹࡥࡵࡡࡦࡥࡵࡧࡢࡪ࡮࡬ࡸࡾ࠭ᴫ"), None):
            options.set_capability(bstack1ll1lll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡀ࡯ࡱࡶ࡬ࡳࡳࡹࠧᴬ"), bstack1ll1llll11_opy_)
        else:
            options[bstack1ll1lll_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࠺ࡰࡲࡷ࡭ࡴࡴࡳࠨᴭ")] = bstack1ll1llll11_opy_
    else:
        if getattr(options, bstack1ll1lll_opy_ (u"ࠨࡵࡨࡸࡤࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡺࠩᴮ"), None):
            options.set_capability(bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡓࡅࡍࠪᴯ"), bstack11l11111lll_opy_(framework))
            options.set_capability(bstack1ll1lll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠫᴰ"), bstack1l1l1ll11l1_opy_())
            options.set_capability(bstack1ll1lll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡸࡪࡹࡴࡩࡷࡥࡆࡺ࡯࡬ࡥࡗࡸ࡭ࡩ࠭ᴱ"), bstack1ll1lllll_opy_)
            options.set_capability(bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡧࡻࡩ࡭ࡦࡓࡶࡴࡪࡵࡤࡶࡐࡥࡵ࠭ᴲ"), bstack11l1l1l1ll_opy_)
            if bstack1ll11l1llll_opy_:
                options.set_capability(bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠬᴳ"), bstack1ll11l1llll_opy_)
                options.set_capability(bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࡕࡰࡵ࡫ࡲࡲࡸ࠭ᴴ"), bstack1llll11l111_opy_)
                options.set_capability(bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࡏࡱࡶ࡬ࡳࡳࡹ࠮ࡴࡥࡤࡲࡳ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨᴵ"), bstack11ll11lll1l_opy_)
        else:
            options[bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡓࡅࡍࠪᴶ")] = bstack11l11111lll_opy_(framework)
            options[bstack1ll1lll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠫᴷ")] = bstack1l1l1ll11l1_opy_()
            options[bstack1ll1lll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡸࡪࡹࡴࡩࡷࡥࡆࡺ࡯࡬ࡥࡗࡸ࡭ࡩ࠭ᴸ")] = bstack1ll1lllll_opy_
            options[bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡧࡻࡩ࡭ࡦࡓࡶࡴࡪࡵࡤࡶࡐࡥࡵ࠭ᴹ")] = bstack11l1l1l1ll_opy_
            if bstack1ll11l1llll_opy_:
                options[bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠬᴺ")] = bstack1ll11l1llll_opy_
                options[bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࡕࡰࡵ࡫ࡲࡲࡸ࠭ᴻ")] = bstack1llll11l111_opy_
                options[bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࡏࡱࡶ࡬ࡳࡳࡹࠧᴼ")][bstack1ll1lll_opy_ (u"ࠩࡶࡧࡦࡴ࡮ࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪᴽ")] = bstack11ll11lll1l_opy_
    return options
def bstack11l1111llll_opy_(bstack11l11lll111_opy_, framework):
    bstack11l1l1l1ll_opy_ = bstack11l1l11l_opy_.get_property(bstack1ll1lll_opy_ (u"ࠥࡔࡑࡇ࡙ࡘࡔࡌࡋࡍ࡚࡟ࡑࡔࡒࡈ࡚ࡉࡔࡠࡏࡄࡔࠧᴾ"))
    if bstack11l11lll111_opy_ and len(bstack11l11lll111_opy_.split(bstack1ll1lll_opy_ (u"ࠫࡨࡧࡰࡴ࠿ࠪᴿ"))) > 1:
        ws_url = bstack11l11lll111_opy_.split(bstack1ll1lll_opy_ (u"ࠬࡩࡡࡱࡵࡀࠫᵀ"))[0]
        if bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡩ࡯࡮ࠩᵁ") in ws_url:
            from browserstack_sdk._version import __version__
            bstack111lll11111_opy_ = json.loads(urllib.parse.unquote(bstack11l11lll111_opy_.split(bstack1ll1lll_opy_ (u"ࠧࡤࡣࡳࡷࡂ࠭ᵂ"))[1]))
            bstack111lll11111_opy_ = bstack111lll11111_opy_ or {}
            bstack1ll1lllll_opy_ = os.environ[bstack1ll1lll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡇࡖࡘࡍ࡛ࡂࡠࡗࡘࡍࡉ࠭ᵃ")]
            bstack111lll11111_opy_[bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡓࡅࡍࠪᵄ")] = str(framework) + str(__version__)
            bstack111lll11111_opy_[bstack1ll1lll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠫᵅ")] = bstack1l1l1ll11l1_opy_()
            bstack111lll11111_opy_[bstack1ll1lll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡸࡪࡹࡴࡩࡷࡥࡆࡺ࡯࡬ࡥࡗࡸ࡭ࡩ࠭ᵆ")] = bstack1ll1lllll_opy_
            bstack111lll11111_opy_[bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡧࡻࡩ࡭ࡦࡓࡶࡴࡪࡵࡤࡶࡐࡥࡵ࠭ᵇ")] = bstack11l1l1l1ll_opy_
            bstack11l11lll111_opy_ = bstack11l11lll111_opy_.split(bstack1ll1lll_opy_ (u"࠭ࡣࡢࡲࡶࡁࠬᵈ"))[0] + bstack1ll1lll_opy_ (u"ࠧࡤࡣࡳࡷࡂ࠭ᵉ") + urllib.parse.quote(json.dumps(bstack111lll11111_opy_))
    return bstack11l11lll111_opy_
def bstack1ll11l1lll_opy_():
    global bstack11l11ll11l_opy_
    from playwright._impl._browser_type import BrowserType
    bstack11l11ll11l_opy_ = BrowserType.connect
    return bstack11l11ll11l_opy_
def bstack11111lll_opy_(framework_name):
    global bstack11111l1ll_opy_
    bstack11111l1ll_opy_ = framework_name
    return framework_name
def bstack11ll11l1l1_opy_(self, *args, **kwargs):
    global bstack11l11ll11l_opy_
    try:
        global bstack11111l1ll_opy_
        if bstack1ll1lll_opy_ (u"ࠨࡹࡶࡉࡳࡪࡰࡰ࡫ࡱࡸࠬᵊ") in kwargs:
            kwargs[bstack1ll1lll_opy_ (u"ࠩࡺࡷࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭ᵋ")] = bstack11l1111llll_opy_(
                kwargs.get(bstack1ll1lll_opy_ (u"ࠪࡻࡸࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧᵌ"), None),
                bstack11111l1ll_opy_
            )
    except Exception as e:
        logger.error(bstack1ll1lll_opy_ (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡭࡫࡮ࠡࡲࡵࡳࡨ࡫ࡳࡴ࡫ࡱ࡫࡙ࠥࡄࡌࠢࡦࡥࡵࡹ࠺ࠡࡽࢀࠦᵍ").format(str(e)))
    return bstack11l11ll11l_opy_(self, *args, **kwargs)
def bstack11l11l11111_opy_(bstack111ll1ll1l1_opy_, proxies):
    proxy_settings = {}
    try:
        if not proxies:
            proxies = bstack1l111l1111_opy_(bstack111ll1ll1l1_opy_, bstack1ll1lll_opy_ (u"ࠧࠨᵎ"))
        if proxies and proxies.get(bstack1ll1lll_opy_ (u"ࠨࡨࡵࡶࡳࡷࠧᵏ")):
            parsed_url = urlparse(proxies.get(bstack1ll1lll_opy_ (u"ࠢࡩࡶࡷࡴࡸࠨᵐ")))
            if parsed_url and parsed_url.hostname: proxy_settings[bstack1ll1lll_opy_ (u"ࠨࡲࡵࡳࡽࡿࡈࡰࡵࡷࠫᵑ")] = str(parsed_url.hostname)
            if parsed_url and parsed_url.port: proxy_settings[bstack1ll1lll_opy_ (u"ࠩࡳࡶࡴࡾࡹࡑࡱࡵࡸࠬᵒ")] = str(parsed_url.port)
            if parsed_url and parsed_url.username: proxy_settings[bstack1ll1lll_opy_ (u"ࠪࡴࡷࡵࡸࡺࡗࡶࡩࡷ࠭ᵓ")] = str(parsed_url.username)
            if parsed_url and parsed_url.password: proxy_settings[bstack1ll1lll_opy_ (u"ࠫࡵࡸ࡯ࡹࡻࡓࡥࡸࡹࠧᵔ")] = str(parsed_url.password)
        return proxy_settings
    except:
        return proxy_settings
def bstack1ll11l1l1l_opy_(bstack111ll1ll1l1_opy_):
    bstack11l11l1111l_opy_ = {
        bstack11l1lll1l11_opy_[bstack111llll11ll_opy_]: bstack111ll1ll1l1_opy_[bstack111llll11ll_opy_]
        for bstack111llll11ll_opy_ in bstack111ll1ll1l1_opy_
        if bstack111llll11ll_opy_ in bstack11l1lll1l11_opy_
    }
    bstack11l11l1111l_opy_[bstack1ll1lll_opy_ (u"ࠧࡶࡲࡰࡺࡼࡗࡪࡺࡴࡪࡰࡪࡷࠧᵕ")] = bstack11l11l11111_opy_(bstack111ll1ll1l1_opy_, bstack11l1l11l_opy_.get_property(bstack1ll1lll_opy_ (u"ࠨࡰࡳࡱࡻࡽࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠨᵖ")))
    bstack11l111ll1ll_opy_ = [element.lower() for element in bstack11l1l1l111l_opy_]
    bstack111ll111lll_opy_(bstack11l11l1111l_opy_, bstack11l111ll1ll_opy_)
    return bstack11l11l1111l_opy_
def bstack111ll111lll_opy_(d, keys):
    for key in list(d.keys()):
        if key.lower() in keys:
            d[key] = bstack1ll1lll_opy_ (u"ࠢࠫࠬ࠭࠮ࠧᵗ")
    for value in d.values():
        if isinstance(value, dict):
            bstack111ll111lll_opy_(value, keys)
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    bstack111ll111lll_opy_(item, keys)
def bstack1l1l1l1l1l1_opy_():
    bstack11l111l1111_opy_ = [os.environ.get(bstack1ll1lll_opy_ (u"ࠣࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡇࡋࡏࡉࡘࡥࡄࡊࡔࠥᵘ")), os.path.join(os.path.expanduser(bstack1ll1lll_opy_ (u"ࠤࢁࠦᵙ")), bstack1ll1lll_opy_ (u"ࠪ࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࠪᵚ")), os.path.join(bstack1ll1lll_opy_ (u"ࠫ࠴ࡺ࡭ࡱࠩᵛ"), bstack1ll1lll_opy_ (u"ࠬ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠬᵜ"))]
    for path in bstack11l111l1111_opy_:
        if path is None:
            continue
        try:
            if os.path.exists(path):
                logger.debug(bstack1ll1lll_opy_ (u"ࠨࡆࡪ࡮ࡨࠤࠬࠨᵝ") + str(path) + bstack1ll1lll_opy_ (u"ࠢࠨࠢࡨࡼ࡮ࡹࡴࡴ࠰ࠥᵞ"))
                if not os.access(path, os.W_OK):
                    logger.debug(bstack1ll1lll_opy_ (u"ࠣࡉ࡬ࡺ࡮ࡴࡧࠡࡲࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸࠦࡦࡰࡴࠣࠫࠧᵟ") + str(path) + bstack1ll1lll_opy_ (u"ࠤࠪࠦᵠ"))
                    os.chmod(path, 0o777)
                else:
                    logger.debug(bstack1ll1lll_opy_ (u"ࠥࡊ࡮ࡲࡥࠡࠩࠥᵡ") + str(path) + bstack1ll1lll_opy_ (u"ࠦࠬࠦࡡ࡭ࡴࡨࡥࡩࡿࠠࡩࡣࡶࠤࡹ࡮ࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࡦࠣࡴࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳ࠯ࠤᵢ"))
            else:
                logger.debug(bstack1ll1lll_opy_ (u"ࠧࡉࡲࡦࡣࡷ࡭ࡳ࡭ࠠࡧ࡫࡯ࡩࠥ࠭ࠢᵣ") + str(path) + bstack1ll1lll_opy_ (u"ࠨࠧࠡࡹ࡬ࡸ࡭ࠦࡷࡳ࡫ࡷࡩࠥࡶࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯࠰ࠥᵤ"))
                os.makedirs(path, exist_ok=True)
                os.chmod(path, 0o777)
            logger.debug(bstack1ll1lll_opy_ (u"ࠢࡐࡲࡨࡶࡦࡺࡩࡰࡰࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࠦࡦࡰࡴࠣࠫࠧᵥ") + str(path) + bstack1ll1lll_opy_ (u"ࠣࠩ࠱ࠦᵦ"))
            return path
        except Exception as e:
            logger.debug(bstack1ll1lll_opy_ (u"ࠤࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡹࡥࡵࠢࡸࡴࠥ࡬ࡩ࡭ࡧࠣࠫࢀࡶࡡࡵࡪࢀࠫ࠿ࠦࠢᵧ") + str(e) + bstack1ll1lll_opy_ (u"ࠥࠦᵨ"))
    logger.debug(bstack1ll1lll_opy_ (u"ࠦࡆࡲ࡬ࠡࡲࡤࡸ࡭ࡹࠠࡧࡣ࡬ࡰࡪࡪ࠮ࠣᵩ"))
    return None
@measure(event_name=EVENTS.bstack11l1lll1lll_opy_, stage=STAGE.bstack111lll1l11_opy_)
def bstack1lll1l1lll1_opy_(binary_path, bstack1ll1l11l1ll_opy_, bs_config):
    logger.debug(bstack1ll1lll_opy_ (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠦࡃࡍࡋࠣࡔࡦࡺࡨࠡࡨࡲࡹࡳࡪ࠺ࠡࡽࢀࠦᵪ").format(binary_path))
    bstack111ll1ll1ll_opy_ = bstack1ll1lll_opy_ (u"࠭ࠧᵫ")
    bstack111lll1l111_opy_ = {
        bstack1ll1lll_opy_ (u"ࠧࡴࡦ࡮ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬᵬ"): __version__,
        bstack1ll1lll_opy_ (u"ࠣࡱࡶࠦᵭ"): platform.system(),
        bstack1ll1lll_opy_ (u"ࠤࡲࡷࡤࡧࡲࡤࡪࠥᵮ"): platform.machine(),
        bstack1ll1lll_opy_ (u"ࠥࡧࡱ࡯࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠣᵯ"): bstack1ll1lll_opy_ (u"ࠫ࠵࠭ᵰ"),
        bstack1ll1lll_opy_ (u"ࠧࡹࡤ࡬ࡡ࡯ࡥࡳ࡭ࡵࡢࡩࡨࠦᵱ"): bstack1ll1lll_opy_ (u"࠭ࡰࡺࡶ࡫ࡳࡳ࠭ᵲ")
    }
    bstack11l11111l1l_opy_(bstack111lll1l111_opy_)
    try:
        if binary_path:
            bstack111lll1l111_opy_[bstack1ll1lll_opy_ (u"ࠧࡤ࡮࡬ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬᵳ")] = subprocess.check_output([binary_path, bstack1ll1lll_opy_ (u"ࠣࡸࡨࡶࡸ࡯࡯࡯ࠤᵴ")]).strip().decode(bstack1ll1lll_opy_ (u"ࠩࡸࡸ࡫࠳࠸ࠨᵵ"))
        response = requests.request(
            bstack1ll1lll_opy_ (u"ࠪࡋࡊ࡚ࠧᵶ"),
            url=bstack11l1l111ll_opy_(bstack11l1ll1l111_opy_),
            headers=None,
            auth=(bs_config[bstack1ll1lll_opy_ (u"ࠫࡺࡹࡥࡳࡐࡤࡱࡪ࠭ᵷ")], bs_config[bstack1ll1lll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨᵸ")]),
            json=None,
            params=bstack111lll1l111_opy_
        )
        data = response.json()
        if response.status_code == 200 and bstack1ll1lll_opy_ (u"࠭ࡵࡳ࡮ࠪᵹ") in data.keys() and bstack1ll1lll_opy_ (u"ࠧࡶࡲࡧࡥࡹ࡫ࡤࡠࡥ࡯࡭ࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭ᵺ") in data.keys():
            logger.debug(bstack1ll1lll_opy_ (u"ࠣࡐࡨࡩࡩࠦࡴࡰࠢࡸࡴࡩࡧࡴࡦࠢࡥ࡭ࡳࡧࡲࡺ࠮ࠣࡧࡺࡸࡲࡦࡰࡷࠤࡧ࡯࡮ࡢࡴࡼࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠿ࠦࡻࡾࠤᵻ").format(bstack111lll1l111_opy_[bstack1ll1lll_opy_ (u"ࠩࡦࡰ࡮ࡥࡶࡦࡴࡶ࡭ࡴࡴࠧᵼ")]))
            if bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡅࡍࡓࡇࡒ࡚ࡡࡘࡖࡑ࠭ᵽ") in os.environ:
                logger.debug(bstack1ll1lll_opy_ (u"ࠦࡘࡱࡩࡱࡲ࡬ࡲ࡬ࠦࡢࡪࡰࡤࡶࡾࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡣࡶࠤࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡆࡎࡔࡁࡓ࡛ࡢ࡙ࡗࡒࠠࡪࡵࠣࡷࡪࡺࠢᵾ"))
                data[bstack1ll1lll_opy_ (u"ࠬࡻࡲ࡭ࠩᵿ")] = os.environ[bstack1ll1lll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡈࡉࡏࡃࡕ࡝ࡤ࡛ࡒࡍࠩᶀ")]
            bstack11l11l11ll1_opy_ = bstack11l11ll1111_opy_(data[bstack1ll1lll_opy_ (u"ࠧࡶࡴ࡯ࠫᶁ")], bstack1ll1l11l1ll_opy_)
            bstack111ll1ll1ll_opy_ = os.path.join(bstack1ll1l11l1ll_opy_, bstack11l11l11ll1_opy_)
            os.chmod(bstack111ll1ll1ll_opy_, 0o777) # bstack11l111l1ll1_opy_ permission
            return bstack111ll1ll1ll_opy_
    except Exception as e:
        logger.debug(bstack1ll1lll_opy_ (u"ࠣࡇࡵࡶࡴࡸࠠࡸࡪ࡬ࡰࡪࠦࡤࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡳ࡫ࡷࠡࡕࡇࡏࠥࢁࡽࠣᶂ").format(e))
    return binary_path
def bstack11l11111l1l_opy_(bstack111lll1l111_opy_):
    try:
        if bstack1ll1lll_opy_ (u"ࠩ࡯࡭ࡳࡻࡸࠨᶃ") not in bstack111lll1l111_opy_[bstack1ll1lll_opy_ (u"ࠪࡳࡸ࠭ᶄ")].lower():
            return
        if os.path.exists(bstack1ll1lll_opy_ (u"ࠦ࠴࡫ࡴࡤ࠱ࡲࡷ࠲ࡸࡥ࡭ࡧࡤࡷࡪࠨᶅ")):
            with open(bstack1ll1lll_opy_ (u"ࠧ࠵ࡥࡵࡥ࠲ࡳࡸ࠳ࡲࡦ࡮ࡨࡥࡸ࡫ࠢᶆ"), bstack1ll1lll_opy_ (u"ࠨࡲࠣᶇ")) as f:
                bstack111lll1l1ll_opy_ = {}
                for line in f:
                    if bstack1ll1lll_opy_ (u"ࠢ࠾ࠤᶈ") in line:
                        key, value = line.rstrip().split(bstack1ll1lll_opy_ (u"ࠣ࠿ࠥᶉ"), 1)
                        bstack111lll1l1ll_opy_[key] = value.strip(bstack1ll1lll_opy_ (u"ࠩࠥࡠࠬ࠭ᶊ"))
                bstack111lll1l111_opy_[bstack1ll1lll_opy_ (u"ࠪࡨ࡮ࡹࡴࡳࡱࠪᶋ")] = bstack111lll1l1ll_opy_.get(bstack1ll1lll_opy_ (u"ࠦࡎࡊࠢᶌ"), bstack1ll1lll_opy_ (u"ࠧࠨᶍ"))
        elif os.path.exists(bstack1ll1lll_opy_ (u"ࠨ࠯ࡦࡶࡦ࠳ࡦࡲࡰࡪࡰࡨ࠱ࡷ࡫࡬ࡦࡣࡶࡩࠧᶎ")):
            bstack111lll1l111_opy_[bstack1ll1lll_opy_ (u"ࠧࡥ࡫ࡶࡸࡷࡵࠧᶏ")] = bstack1ll1lll_opy_ (u"ࠨࡣ࡯ࡴ࡮ࡴࡥࠨᶐ")
    except Exception as e:
        logger.debug(bstack1ll1lll_opy_ (u"ࠤࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥ࡭ࡥࡵࠢࡧ࡭ࡸࡺࡲࡰࠢࡲࡪࠥࡲࡩ࡯ࡷࡻࠦᶑ") + e)
@measure(event_name=EVENTS.bstack11l1lll1l1l_opy_, stage=STAGE.bstack111lll1l11_opy_)
def bstack11l11ll1111_opy_(bstack11l111ll111_opy_, bstack11l11l1l111_opy_):
    logger.debug(bstack1ll1lll_opy_ (u"ࠥࡈࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧࠡࡕࡇࡏࠥࡨࡩ࡯ࡣࡵࡽࠥ࡬ࡲࡰ࡯࠽ࠤࠧᶒ") + str(bstack11l111ll111_opy_) + bstack1ll1lll_opy_ (u"ࠦࠧᶓ"))
    zip_path = os.path.join(bstack11l11l1l111_opy_, bstack1ll1lll_opy_ (u"ࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥࡡࡩ࡭ࡱ࡫࠮ࡻ࡫ࡳࠦᶔ"))
    bstack11l11l11ll1_opy_ = bstack1ll1lll_opy_ (u"࠭ࠧᶕ")
    with requests.get(bstack11l111ll111_opy_, stream=True) as response:
        response.raise_for_status()
        with open(zip_path, bstack1ll1lll_opy_ (u"ࠢࡸࡤࠥᶖ")) as file:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    file.write(chunk)
        logger.debug(bstack1ll1lll_opy_ (u"ࠣࡈ࡬ࡰࡪࠦࡤࡰࡹࡱࡰࡴࡧࡤࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠥᶗ"))
    with zipfile.ZipFile(zip_path, bstack1ll1lll_opy_ (u"ࠩࡵࠫᶘ")) as zip_ref:
        bstack111ll1lllll_opy_ = zip_ref.namelist()
        if len(bstack111ll1lllll_opy_) > 0:
            bstack11l11l11ll1_opy_ = bstack111ll1lllll_opy_[0] # bstack111lll11lll_opy_ bstack11l1l1l1ll1_opy_ will be bstack11111lllll_opy_ 1 file i.e. the binary in the zip
        zip_ref.extractall(bstack11l11l1l111_opy_)
        logger.debug(bstack1ll1lll_opy_ (u"ࠥࡊ࡮ࡲࡥࡴࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠡࡧࡻࡸࡷࡧࡣࡵࡧࡧࠤࡹࡵࠠࠨࠤᶙ") + str(bstack11l11l1l111_opy_) + bstack1ll1lll_opy_ (u"ࠦࠬࠨᶚ"))
    os.remove(zip_path)
    return bstack11l11l11ll1_opy_
def get_cli_dir():
    bstack111lll1111l_opy_ = bstack1l1l1l1l1l1_opy_()
    if bstack111lll1111l_opy_:
        bstack1ll1l11l1ll_opy_ = os.path.join(bstack111lll1111l_opy_, bstack1ll1lll_opy_ (u"ࠧࡩ࡬ࡪࠤᶛ"))
        if not os.path.exists(bstack1ll1l11l1ll_opy_):
            os.makedirs(bstack1ll1l11l1ll_opy_, mode=0o777, exist_ok=True)
        return bstack1ll1l11l1ll_opy_
    else:
        raise FileNotFoundError(bstack1ll1lll_opy_ (u"ࠨࡎࡰࠢࡺࡶ࡮ࡺࡡࡣ࡮ࡨࠤࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠠࡢࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡪࡴࡸࠠࡵࡪࡨࠤࡘࡊࡋࠡࡤ࡬ࡲࡦࡸࡹ࠯ࠤᶜ"))
def bstack1ll1ll1ll1l_opy_(bstack1ll1l11l1ll_opy_):
    bstack1ll1lll_opy_ (u"ࠢࠣࠤࡊࡩࡹࠦࡴࡩࡧࠣࡴࡦࡺࡨࠡࡨࡲࡶࠥࡺࡨࡦࠢࡅࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࠡࡕࡇࡏࠥࡨࡩ࡯ࡣࡵࡽࠥ࡯࡮ࠡࡣࠣࡻࡷ࡯ࡴࡢࡤ࡯ࡩࠥࡪࡩࡳࡧࡦࡸࡴࡸࡹ࠯ࠤࠥࠦᶝ")
    bstack11l11l11lll_opy_ = [
        os.path.join(bstack1ll1l11l1ll_opy_, f)
        for f in os.listdir(bstack1ll1l11l1ll_opy_)
        if os.path.isfile(os.path.join(bstack1ll1l11l1ll_opy_, f)) and f.startswith(bstack1ll1lll_opy_ (u"ࠣࡤ࡬ࡲࡦࡸࡹ࠮ࠤᶞ"))
    ]
    if len(bstack11l11l11lll_opy_) > 0:
        return max(bstack11l11l11lll_opy_, key=os.path.getmtime) # get bstack11l11ll11ll_opy_ binary
    return bstack1ll1lll_opy_ (u"ࠤࠥᶟ")
def bstack11ll11lllll_opy_():
  from selenium import webdriver
  return version.parse(webdriver.__version__)
def bstack1ll11l111ll_opy_(d, u):
  for k, v in u.items():
    if isinstance(v, collections.abc.Mapping):
      d[k] = bstack1ll11l111ll_opy_(d.get(k, {}), v)
    else:
      if isinstance(v, list):
        d[k] = d.get(k, []) + v
      else:
        d[k] = v
  return d
def bstack1l1111l11l_opy_(data, keys, default=None):
    bstack1ll1lll_opy_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࡗࡦ࡬ࡥ࡭ࡻࠣ࡫ࡪࡺࠠࡢࠢࡱࡩࡸࡺࡥࡥࠢࡹࡥࡱࡻࡥࠡࡨࡵࡳࡲࠦࡡࠡࡦ࡬ࡧࡹ࡯࡯࡯ࡣࡵࡽࠥࡵࡲࠡ࡮࡬ࡷࡹ࠴ࠊࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡩࡧࡴࡢ࠼ࠣࡘ࡭࡫ࠠࡥ࡫ࡦࡸ࡮ࡵ࡮ࡢࡴࡼࠤࡴࡸࠠ࡭࡫ࡶࡸࠥࡺ࡯ࠡࡶࡵࡥࡻ࡫ࡲࡴࡧ࠱ࠎࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡ࡭ࡨࡽࡸࡀࠠࡂࠢ࡯࡭ࡸࡺࠠࡰࡨࠣ࡯ࡪࡿࡳ࠰࡫ࡱࡨ࡮ࡩࡥࡴࠢࡵࡩࡵࡸࡥࡴࡧࡱࡸ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡶࡡࡵࡪ࠱ࠎࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡦࡨࡪࡦࡻ࡬ࡵ࠼࡚ࠣࡦࡲࡵࡦࠢࡷࡳࠥࡸࡥࡵࡷࡵࡲࠥ࡯ࡦࠡࡶ࡫ࡩࠥࡶࡡࡵࡪࠣࡨࡴ࡫ࡳࠡࡰࡲࡸࠥ࡫ࡸࡪࡵࡷ࠲ࠏࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙࡮ࡥࠡࡸࡤࡰࡺ࡫ࠠࡢࡶࠣࡸ࡭࡫ࠠ࡯ࡧࡶࡸࡪࡪࠠࡱࡣࡷ࡬࠱ࠦ࡯ࡳࠢࡧࡩ࡫ࡧࡵ࡭ࡶࠣ࡭࡫ࠦ࡮ࡰࡶࠣࡪࡴࡻ࡮ࡥ࠰ࠍࠤࠥࠦࠠࠣࠤࠥᶠ")
    if not data:
        return default
    current = data
    try:
        for key in keys:
            if isinstance(current, dict):
                current = current[key]
            elif isinstance(current, list) and isinstance(key, int):
                current = current[key]
            else:
                return default
        return current
    except (KeyError, IndexError, TypeError):
        return default