# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import sys
import logging
import tarfile
import io
import os
import time
import requests
import re
from requests_toolbelt.multipart.encoder import MultipartEncoder
from bstack_utils.constants import bstack11l1lll11ll_opy_, bstack11l1ll11111_opy_, bstack11l1l1l111l_opy_
import tempfile
import json
bstack111l1ll11l1_opy_ = os.getenv(bstack1ll1lll_opy_ (u"ࠧࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡑࡕࡇࡠࡈࡌࡐࡊࠨ᷌"), None) or os.path.join(tempfile.gettempdir(), bstack1ll1lll_opy_ (u"ࠨࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡪࡥࡣࡷࡪ࠲ࡱࡵࡧࠣ᷍"))
bstack111l1l111ll_opy_ = os.path.join(bstack1ll1lll_opy_ (u"ࠢ࡭ࡱࡪ᷎ࠦ"), bstack1ll1lll_opy_ (u"ࠨࡵࡧ࡯࠲ࡩ࡬ࡪ࠯ࡧࡩࡧࡻࡧ࠯࡮ࡲ࡫᷏ࠬ"))
logging.Formatter.converter = time.gmtime
def get_logger(name=__name__, level=None):
  logger = logging.getLogger(name)
  if level:
    logging.basicConfig(
      level=level,
      format=bstack1ll1lll_opy_ (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࡜ࠧࠫࡲࡦࡳࡥࠪࡵࡠ࡟ࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࡡࠥ࠳ࠠࠦࠪࡰࡩࡸࡹࡡࡨࡧࠬࡷ᷐ࠬ"),
      datefmt=bstack1ll1lll_opy_ (u"ࠪࠩ࡞࠳ࠥ࡮࠯ࠨࡨ࡙ࠫࡈ࠻ࠧࡐ࠾࡙࡚ࠪࠨ᷑"),
      stream=sys.stdout
    )
  return logger
def bstack1lll1l111ll_opy_():
  bstack111l1l1l111_opy_ = os.environ.get(bstack1ll1lll_opy_ (u"ࠦࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡆࡎࡔࡁࡓ࡛ࡢࡈࡊࡈࡕࡈࠤ᷒"), bstack1ll1lll_opy_ (u"ࠧ࡬ࡡ࡭ࡵࡨࠦᷓ"))
  return logging.DEBUG if bstack111l1l1l111_opy_.lower() == bstack1ll1lll_opy_ (u"ࠨࡴࡳࡷࡨࠦᷔ") else logging.INFO
def bstack1l1ll11l1ll_opy_():
  global bstack111l1ll11l1_opy_
  if os.path.exists(bstack111l1ll11l1_opy_):
    os.remove(bstack111l1ll11l1_opy_)
  if os.path.exists(bstack111l1l111ll_opy_):
    os.remove(bstack111l1l111ll_opy_)
def bstack11l11111ll_opy_():
  for handler in logging.getLogger().handlers:
    logging.getLogger().removeHandler(handler)
def configure_logger(config, log_level):
  bstack111l1l11l11_opy_ = log_level
  if bstack1ll1lll_opy_ (u"ࠧ࡭ࡱࡪࡐࡪࡼࡥ࡭ࠩᷕ") in config and config[bstack1ll1lll_opy_ (u"ࠨ࡮ࡲ࡫ࡑ࡫ࡶࡦ࡮ࠪᷖ")] in bstack11l1ll11111_opy_:
    bstack111l1l11l11_opy_ = bstack11l1ll11111_opy_[config[bstack1ll1lll_opy_ (u"ࠩ࡯ࡳ࡬ࡒࡥࡷࡧ࡯ࠫᷗ")]]
  if config.get(bstack1ll1lll_opy_ (u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡅࡺࡺ࡯ࡄࡣࡳࡸࡺࡸࡥࡍࡱࡪࡷࠬᷘ"), False):
    logging.getLogger().setLevel(bstack111l1l11l11_opy_)
    return bstack111l1l11l11_opy_
  global bstack111l1ll11l1_opy_
  bstack11l11111ll_opy_()
  bstack111l1l1ll11_opy_ = logging.Formatter(
    fmt=bstack1ll1lll_opy_ (u"ࠫࠪ࠮ࡡࡴࡥࡷ࡭ࡲ࡫ࠩࡴࠢ࡞ࠩ࠭ࡴࡡ࡮ࡧࠬࡷࡢࡡࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࡣࠠ࠮ࠢࠨࠬࡲ࡫ࡳࡴࡣࡪࡩ࠮ࡹࠧᷙ"),
    datefmt=bstack1ll1lll_opy_ (u"࡙ࠬࠫ࠮ࠧࡰ࠱ࠪࡪࡔࠦࡊ࠽ࠩࡒࡀࠥࡔ࡜ࠪᷚ"),
  )
  bstack111l1l1l1l1_opy_ = logging.StreamHandler(sys.stdout)
  file_handler = logging.FileHandler(bstack111l1ll11l1_opy_)
  file_handler.setFormatter(bstack111l1l1ll11_opy_)
  bstack111l1l1l1l1_opy_.setFormatter(bstack111l1l1ll11_opy_)
  file_handler.setLevel(logging.DEBUG)
  bstack111l1l1l1l1_opy_.setLevel(log_level)
  file_handler.addFilter(lambda r: r.name != bstack1ll1lll_opy_ (u"࠭ࡳࡦ࡮ࡨࡲ࡮ࡻ࡭࠯ࡹࡨࡦࡩࡸࡩࡷࡧࡵ࠲ࡷ࡫࡭ࡰࡶࡨ࠲ࡷ࡫࡭ࡰࡶࡨࡣࡨࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮ࠨᷛ"))
  logging.getLogger().setLevel(logging.DEBUG)
  bstack111l1l1l1l1_opy_.setLevel(bstack111l1l11l11_opy_)
  logging.getLogger().addHandler(bstack111l1l1l1l1_opy_)
  logging.getLogger().addHandler(file_handler)
  return bstack111l1l11l11_opy_
def bstack111l1l1lll1_opy_(config):
  try:
    bstack111l11lllll_opy_ = set(bstack11l1l1l111l_opy_)
    bstack111l1ll1l11_opy_ = bstack1ll1lll_opy_ (u"ࠧࠨᷜ")
    with open(bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡺ࡯࡯ࠫᷝ")) as bstack111l1ll1111_opy_:
      bstack111l1ll111l_opy_ = bstack111l1ll1111_opy_.read()
      bstack111l1ll1l11_opy_ = re.sub(bstack1ll1lll_opy_ (u"ࡴࠪࡢ࠭ࡢࡳࠬࠫࡂࠧ࠳࠰ࠤ࡝ࡰࠪᷞ"), bstack1ll1lll_opy_ (u"ࠪࠫᷟ"), bstack111l1ll111l_opy_, flags=re.M)
      bstack111l1ll1l11_opy_ = re.sub(
        bstack1ll1lll_opy_ (u"ࡶࠬࡤࠨ࡝ࡵ࠮࠭ࡄ࠮ࠧᷠ") + bstack1ll1lll_opy_ (u"ࠬࢂࠧᷡ").join(bstack111l11lllll_opy_) + bstack1ll1lll_opy_ (u"࠭ࠩ࠯ࠬࠧࠫᷢ"),
        bstack1ll1lll_opy_ (u"ࡲࠨ࡞࠵࠾ࠥࡡࡒࡆࡆࡄࡇ࡙ࡋࡄ࡞ࠩᷣ"),
        bstack111l1ll1l11_opy_, flags=re.M | re.I
      )
    def bstack111l1l1l1ll_opy_(dic):
      bstack111l1l111l1_opy_ = {}
      for key, value in dic.items():
        if key in bstack111l11lllll_opy_:
          bstack111l1l111l1_opy_[key] = bstack1ll1lll_opy_ (u"ࠨ࡝ࡕࡉࡉࡇࡃࡕࡇࡇࡡࠬᷤ")
        else:
          if isinstance(value, dict):
            bstack111l1l111l1_opy_[key] = bstack111l1l1l1ll_opy_(value)
          else:
            bstack111l1l111l1_opy_[key] = value
      return bstack111l1l111l1_opy_
    bstack111l1l111l1_opy_ = bstack111l1l1l1ll_opy_(config)
    return {
      bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡻࡰࡰࠬᷥ"): bstack111l1ll1l11_opy_,
      bstack1ll1lll_opy_ (u"ࠪࡪ࡮ࡴࡡ࡭ࡥࡲࡲ࡫࡯ࡧ࠯࡬ࡶࡳࡳ࠭ᷦ"): json.dumps(bstack111l1l111l1_opy_)
    }
  except Exception as e:
    return {}
def bstack111l1l1l11l_opy_(inipath, rootpath):
  log_dir = os.path.join(os.getcwd(), bstack1ll1lll_opy_ (u"ࠫࡱࡵࡧࠨᷧ"))
  if not os.path.exists(log_dir):
    os.makedirs(log_dir)
  bstack111l11llll1_opy_ = os.path.join(log_dir, bstack1ll1lll_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸࡤࡩ࡯࡯ࡨ࡬࡫ࡸ࠭ᷨ"))
  if not os.path.exists(bstack111l11llll1_opy_):
    bstack111l1l11l1l_opy_ = {
      bstack1ll1lll_opy_ (u"ࠨࡩ࡯࡫ࡳࡥࡹ࡮ࠢᷩ"): str(inipath),
      bstack1ll1lll_opy_ (u"ࠢࡳࡱࡲࡸࡵࡧࡴࡩࠤᷪ"): str(rootpath)
    }
    with open(os.path.join(log_dir, bstack1ll1lll_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࡠࡥࡲࡲ࡫࡯ࡧࡴ࠰࡭ࡷࡴࡴࠧᷫ")), bstack1ll1lll_opy_ (u"ࠩࡺࠫᷬ")) as bstack111l1l11111_opy_:
      bstack111l1l11111_opy_.write(json.dumps(bstack111l1l11l1l_opy_))
def bstack111l1l1111l_opy_():
  try:
    bstack111l11llll1_opy_ = os.path.join(os.getcwd(), bstack1ll1lll_opy_ (u"ࠪࡰࡴ࡭ࠧᷭ"), bstack1ll1lll_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࡣࡨࡵ࡮ࡧ࡫ࡪࡷ࠳ࡰࡳࡰࡰࠪᷮ"))
    if os.path.exists(bstack111l11llll1_opy_):
      with open(bstack111l11llll1_opy_, bstack1ll1lll_opy_ (u"ࠬࡸࠧᷯ")) as bstack111l1l11111_opy_:
        bstack111l1l11ll1_opy_ = json.load(bstack111l1l11111_opy_)
      return bstack111l1l11ll1_opy_.get(bstack1ll1lll_opy_ (u"࠭ࡩ࡯࡫ࡳࡥࡹ࡮ࠧᷰ"), bstack1ll1lll_opy_ (u"ࠧࠨᷱ")), bstack111l1l11ll1_opy_.get(bstack1ll1lll_opy_ (u"ࠨࡴࡲࡳࡹࡶࡡࡵࡪࠪᷲ"), bstack1ll1lll_opy_ (u"ࠩࠪᷳ"))
  except:
    pass
  return None, None
def bstack111l1l1llll_opy_():
  try:
    bstack111l11llll1_opy_ = os.path.join(os.getcwd(), bstack1ll1lll_opy_ (u"ࠪࡰࡴ࡭ࠧᷴ"), bstack1ll1lll_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࡣࡨࡵ࡮ࡧ࡫ࡪࡷ࠳ࡰࡳࡰࡰࠪ᷵"))
    if os.path.exists(bstack111l11llll1_opy_):
      os.remove(bstack111l11llll1_opy_)
  except:
    pass
def bstack1lll11l1_opy_(config):
  try:
    from bstack_utils.helper import bstack11l1l11l_opy_, bstack1l1111l11l_opy_
    from browserstack_sdk.sdk_cli.cli import cli
    global bstack111l1ll11l1_opy_
    if config.get(bstack1ll1lll_opy_ (u"ࠬࡪࡩࡴࡣࡥࡰࡪࡇࡵࡵࡱࡆࡥࡵࡺࡵࡳࡧࡏࡳ࡬ࡹࠧ᷶"), False):
      return
    uuid = os.getenv(bstack1ll1lll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤ࡚ࡅࡔࡖࡋ࡙ࡇࡥࡕࡖࡋࡇ᷷ࠫ")) if os.getenv(bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡌ࡚ࡈ࡟ࡖࡗࡌࡈ᷸ࠬ")) else bstack11l1l11l_opy_.get_property(bstack1ll1lll_opy_ (u"ࠣࡵࡧ࡯ࡗࡻ࡮ࡊࡦ᷹ࠥ"))
    if not uuid or uuid == bstack1ll1lll_opy_ (u"ࠩࡱࡹࡱࡲ᷺ࠧ"):
      return
    bstack111l1l11lll_opy_ = [bstack1ll1lll_opy_ (u"ࠪࡶࡪࡷࡵࡪࡴࡨࡱࡪࡴࡴࡴ࠰ࡷࡼࡹ࠭᷻"), bstack1ll1lll_opy_ (u"ࠫࡕ࡯ࡰࡧ࡫࡯ࡩࠬ᷼"), bstack1ll1lll_opy_ (u"ࠬࡶࡹࡱࡴࡲ࡮ࡪࡩࡴ࠯ࡶࡲࡱࡱ᷽࠭"), bstack111l1ll11l1_opy_, bstack111l1l111ll_opy_]
    bstack111l1ll11ll_opy_, root_path = bstack111l1l1111l_opy_()
    if bstack111l1ll11ll_opy_ != None:
      bstack111l1l11lll_opy_.append(bstack111l1ll11ll_opy_)
    if root_path != None:
      bstack111l1l11lll_opy_.append(os.path.join(root_path, bstack1ll1lll_opy_ (u"࠭ࡣࡰࡰࡩࡸࡪࡹࡴ࠯ࡲࡼࠫ᷾")))
    bstack11l11111ll_opy_()
    logging.shutdown()
    output_file = os.path.join(tempfile.gettempdir(), bstack1ll1lll_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࠭࡭ࡱࡪࡷ࠲᷿࠭") + uuid + bstack1ll1lll_opy_ (u"ࠨ࠰ࡷࡥࡷ࠴ࡧࡻࠩḀ"))
    with tarfile.open(output_file, bstack1ll1lll_opy_ (u"ࠤࡺ࠾࡬ࢀࠢḁ")) as archive:
      for file in filter(lambda f: os.path.exists(f), bstack111l1l11lll_opy_):
        try:
          archive.add(file,  arcname=os.path.basename(file))
        except:
          pass
      for name, data in bstack111l1l1lll1_opy_(config).items():
        tarinfo = tarfile.TarInfo(name)
        bstack111l1l1ll1l_opy_ = data.encode()
        tarinfo.size = len(bstack111l1l1ll1l_opy_)
        archive.addfile(tarinfo, io.BytesIO(bstack111l1l1ll1l_opy_))
    bstack1111lll11_opy_ = MultipartEncoder(
      fields= {
        bstack1ll1lll_opy_ (u"ࠪࡨࡦࡺࡡࠨḂ"): (os.path.basename(output_file), open(os.path.abspath(output_file), bstack1ll1lll_opy_ (u"ࠫࡷࡨࠧḃ")), bstack1ll1lll_opy_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲࡭ࡺࡪࡲࠪḄ")),
        bstack1ll1lll_opy_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡈࡵࡪ࡮ࡧ࡙ࡺ࡯ࡤࠨḅ"): uuid
      }
    )
    bstack111l1ll1l1l_opy_ = bstack1l1111l11l_opy_(cli.config, [bstack1ll1lll_opy_ (u"ࠢࡢࡲ࡬ࡷࠧḆ"), bstack1ll1lll_opy_ (u"ࠣࡱࡥࡷࡪࡸࡶࡢࡤ࡬ࡰ࡮ࡺࡹࠣḇ"), bstack1ll1lll_opy_ (u"ࠤࡸࡴࡱࡵࡡࡥࠤḈ")], bstack11l1lll11ll_opy_)
    response = requests.post(
      bstack1ll1lll_opy_ (u"ࠥࡿࢂ࠵ࡣ࡭࡫ࡨࡲࡹ࠳࡬ࡰࡩࡶ࠳ࡺࡶ࡬ࡰࡣࡧࠦḉ").format(bstack111l1ll1l1l_opy_),
      data=bstack1111lll11_opy_,
      headers={bstack1ll1lll_opy_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪḊ"): bstack1111lll11_opy_.content_type},
      auth=(config[bstack1ll1lll_opy_ (u"ࠬࡻࡳࡦࡴࡑࡥࡲ࡫ࠧḋ")], config[bstack1ll1lll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸࡑࡥࡺࠩḌ")])
    )
    os.remove(output_file)
    if response.status_code != 200:
      get_logger().debug(bstack1ll1lll_opy_ (u"ࠧࡆࡴࡵࡳࡷࠦࡵࡱ࡮ࡲࡥࡩࠦ࡬ࡰࡩࡶ࠾ࠥ࠭ḍ") + response.status_code)
  except Exception as e:
    get_logger().debug(bstack1ll1lll_opy_ (u"ࠨࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡴࡧࡱࡨ࡮ࡴࡧࠡ࡮ࡲ࡫ࡸࡀࠧḎ") + str(e))
  finally:
    try:
      bstack1l1ll11l1ll_opy_()
      bstack111l1l1llll_opy_()
    except:
      pass