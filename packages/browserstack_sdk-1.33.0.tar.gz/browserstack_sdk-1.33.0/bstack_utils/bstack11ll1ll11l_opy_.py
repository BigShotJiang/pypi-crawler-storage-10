# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import os
from bstack_utils.constants import *
from browserstack_sdk.sdk_cli.cli import cli
from bstack_utils.bstack111l11ll111_opy_ import bstack111l111lll1_opy_
from bstack_utils.bstack1llll111ll_opy_ import bstack11lll1lll1_opy_
from bstack_utils.helper import bstack1ll111ll11_opy_
import json
class bstack11ll11ll11_opy_:
    _1ll1llll1l1_opy_ = None
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.bstack111l11l1l11_opy_ = bstack111l111lll1_opy_(self.config, logger)
        self.bstack1llll111ll_opy_ = bstack11lll1lll1_opy_.bstack1l1l111l_opy_(config=self.config)
        self.bstack111l111llll_opy_ = {}
        self.bstack111111llll_opy_ = False
        self.bstack111l111l11l_opy_ = (
            self.__111l111l1l1_opy_()
            and self.bstack1llll111ll_opy_ is not None
            and self.bstack1llll111ll_opy_.bstack1ll11lll1l_opy_()
            and config.get(bstack1ll1lll_opy_ (u"ࠩࡳࡶࡴࡰࡥࡤࡶࡑࡥࡲ࡫ࠧṜ"), None) is not None
            and config.get(bstack1ll1lll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭ṝ"), os.path.basename(os.getcwd())) is not None
        )
    @classmethod
    def bstack1l1l111l_opy_(cls, config, logger):
        if cls._1ll1llll1l1_opy_ is None and config is not None:
            cls._1ll1llll1l1_opy_ = bstack11ll11ll11_opy_(config, logger)
        return cls._1ll1llll1l1_opy_
    def bstack1ll11lll1l_opy_(self):
        bstack1ll1lll_opy_ (u"ࠦࠧࠨࠊࠡࠢࠣࠤࠥࠦࠠࠡࡆࡲࠤࡳࡵࡴࠡࡣࡳࡴࡱࡿࠠࡵࡧࡶࡸࠥࡵࡲࡥࡧࡵ࡭ࡳ࡭ࠠࡸࡪࡨࡲ࠿ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠰ࠤࡔ࠷࠱ࡺࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡨࡲࡦࡨ࡬ࡦࡦࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠭ࠡࡑࡵࡨࡪࡸࡩ࡯ࡩࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡩࡳࡧࡢ࡭ࡧࡧࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠮ࠢࡳࡶࡴࡰࡥࡤࡶࡑࡥࡲ࡫ࠠࡪࡵࠣࡒࡴࡴࡥࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࠲ࠦࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠢ࡬ࡷࠥࡔ࡯࡯ࡧࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢṞ")
        return self.bstack111l111l11l_opy_ and self.bstack111l11l11ll_opy_()
    def bstack111l11l11ll_opy_(self):
        bstack111l11l111l_opy_ = os.getenv(bstack1ll1lll_opy_ (u"ࠬࡌࡒࡂࡏࡈ࡛ࡔࡘࡋࡠࡗࡖࡉࡉ࠭ṟ"), self.config.get(bstack1ll1lll_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࠩṠ"), None))
        return bstack111l11l111l_opy_ in bstack11l1ll11l11_opy_
    def __111l111l1l1_opy_(self):
        bstack11l1llll11l_opy_ = False
        for fw in bstack11l1l1l1l11_opy_:
            if fw in self.config.get(bstack1ll1lll_opy_ (u"ࠧࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࠪṡ"), bstack1ll1lll_opy_ (u"ࠨࠩṢ")):
                bstack11l1llll11l_opy_ = True
        return bstack1ll111ll11_opy_(self.config.get(bstack1ll1lll_opy_ (u"ࠩࡷࡩࡸࡺࡏࡣࡵࡨࡶࡻࡧࡢࡪ࡮࡬ࡸࡾ࠭ṣ"), bstack11l1llll11l_opy_))
    def bstack111l11l1111_opy_(self):
        return (not self.bstack1ll11lll1l_opy_() and
                self.bstack1llll111ll_opy_ is not None and self.bstack1llll111ll_opy_.bstack1ll11lll1l_opy_())
    def bstack111l11l1l1l_opy_(self):
        if not self.bstack111l11l1111_opy_():
            return
        if self.config.get(bstack1ll1lll_opy_ (u"ࠪࡴࡷࡵࡪࡦࡥࡷࡒࡦࡳࡥࠨṤ"), None) is None or self.config.get(bstack1ll1lll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧṥ"), os.path.basename(os.getcwd())) is None:
            self.logger.info(bstack1ll1lll_opy_ (u"࡚ࠧࡥࡴࡶࠣࡖࡪࡵࡲࡥࡧࡵ࡭ࡳ࡭ࠠࡤࡣࡱࠫࡹࠦࡷࡰࡴ࡮ࠤࡦࡹࠠࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠣࡳࡷࠦࡰࡳࡱ࡭ࡩࡨࡺࡎࡢ࡯ࡨࠤ࡮ࡹࠠ࡯ࡷ࡯ࡰ࠳ࠦࡐ࡭ࡧࡤࡷࡪࠦࡳࡦࡶࠣࡥࠥࡴ࡯࡯࠯ࡱࡹࡱࡲࠠࡷࡣ࡯ࡹࡪ࠴ࠢṦ"))
        if not self.__111l111l1l1_opy_():
            self.logger.info(bstack1ll1lll_opy_ (u"ࠨࡔࡦࡵࡷࠤࡗ࡫࡯ࡳࡦࡨࡶ࡮ࡴࡧࠡࡥࡤࡲࠬࡺࠠࡸࡱࡵ࡯ࠥࡧࡳࠡࡶࡨࡷࡹࡘࡥࡱࡱࡵࡸ࡮ࡴࡧࠡ࡫ࡶࠤࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠴ࠠࡑ࡮ࡨࡥࡸ࡫ࠠࡦࡰࡤࡦࡱ࡫ࠠࡪࡶࠣࡪࡷࡵ࡭ࠡࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡺ࡯࡯ࠤ࡫࡯࡬ࡦ࠰ࠥṧ"))
    def bstack111l11l1lll_opy_(self):
        return self.bstack111111llll_opy_
    def bstack1111l11ll1_opy_(self, bstack111l11l11l1_opy_):
        self.bstack111111llll_opy_ = bstack111l11l11l1_opy_
        self.bstack111111l11l_opy_(bstack1ll1lll_opy_ (u"ࠢࡢࡲࡳࡰ࡮࡫ࡤࠣṨ"), bstack111l11l11l1_opy_)
    def bstack11111lll11_opy_(self, test_files):
        try:
            if test_files is None:
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠣ࡝ࡵࡩࡴࡸࡤࡦࡴࡢࡸࡪࡹࡴࡠࡨ࡬ࡰࡪࡹ࡝ࠡࡐࡲࠤࡹ࡫ࡳࡵࠢࡩ࡭ࡱ࡫ࡳࠡࡲࡵࡳࡻ࡯ࡤࡦࡦࠣࡪࡴࡸࠠࡰࡴࡧࡩࡷ࡯࡮ࡨ࠰ࠥṩ"))
                return None
            orchestration_strategy = None
            bstack1lll111l1l1_opy_ = self.bstack1llll111ll_opy_.bstack111l111l1ll_opy_()
            if self.bstack1llll111ll_opy_ is not None:
                orchestration_strategy = self.bstack1llll111ll_opy_.bstack1ll1l1l1ll_opy_()
            if orchestration_strategy is None:
                self.logger.error(bstack1ll1lll_opy_ (u"ࠤࡒࡶࡨ࡮ࡥࡴࡶࡵࡥࡹ࡯࡯࡯ࠢࡶࡸࡷࡧࡴࡦࡩࡼࠤ࡮ࡹࠠࡏࡱࡱࡩ࠳ࠦࡃࡢࡰࡱࡳࡹࠦࡰࡳࡱࡦࡩࡪࡪࠠࡸ࡫ࡷ࡬ࠥࡺࡥࡴࡶࠣࡳࡷࡩࡨࡦࡵࡷࡶࡦࡺࡩࡰࡰࠣࡷࡪࡹࡳࡪࡱࡱ࠲ࠧṪ"))
                return None
            self.logger.info(bstack1ll1lll_opy_ (u"ࠥࡖࡪࡵࡲࡥࡧࡵ࡭ࡳ࡭ࠠࡵࡧࡶࡸࠥ࡬ࡩ࡭ࡧࡶࠤࡼ࡯ࡴࡩࠢࡲࡶࡨ࡮ࡥࡴࡶࡵࡥࡹ࡯࡯࡯ࠢࡶࡸࡷࡧࡴࡦࡩࡼ࠾ࠥࢁࡽࠣṫ").format(orchestration_strategy))
            if cli.is_running():
                self.logger.debug(bstack1ll1lll_opy_ (u"࡚ࠦࡹࡩ࡯ࡩࠣࡇࡑࡏࠠࡧ࡮ࡲࡻࠥ࡬࡯ࡳࠢࡷࡩࡸࡺࠠࡧ࡫࡯ࡩࡸࠦ࡯ࡳࡥ࡫ࡩࡸࡺࡲࡢࡶ࡬ࡳࡳ࠴ࠢṬ"))
                ordered_test_files = cli.test_orchestration_session(test_files, orchestration_strategy, json.dumps(bstack1lll111l1l1_opy_))
            else:
                self.logger.debug(bstack1ll1lll_opy_ (u"࡛ࠧࡳࡪࡰࡪࠤࡸࡪ࡫ࠡࡨ࡯ࡳࡼࠦࡦࡰࡴࠣࡸࡪࡹࡴࠡࡨ࡬ࡰࡪࡹࠠࡰࡴࡦ࡬ࡪࡹࡴࡳࡣࡷ࡭ࡴࡴ࠮ࠣṭ"))
                self.bstack111l11l1l11_opy_.bstack111l111ll1l_opy_(test_files, orchestration_strategy, bstack1lll111l1l1_opy_)
                ordered_test_files = self.bstack111l11l1l11_opy_.bstack111l11l1ll1_opy_()
            if not ordered_test_files:
                return None
            self.bstack111111l11l_opy_(bstack1ll1lll_opy_ (u"ࠨࡵࡱ࡮ࡲࡥࡩ࡫ࡤࡕࡧࡶࡸࡋ࡯࡬ࡦࡵࡆࡳࡺࡴࡴࠣṮ"), len(test_files))
            self.bstack111111l11l_opy_(bstack1ll1lll_opy_ (u"ࠢ࡯ࡱࡧࡩࡎࡴࡤࡦࡺࠥṯ"), int(os.environ.get(bstack1ll1lll_opy_ (u"ࠣࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡏࡑࡇࡉࡤࡏࡎࡅࡇ࡛ࠦṰ")) or bstack1ll1lll_opy_ (u"ࠤ࠳ࠦṱ")))
            self.bstack111111l11l_opy_(bstack1ll1lll_opy_ (u"ࠥࡸࡴࡺࡡ࡭ࡐࡲࡨࡪࡹࠢṲ"), int(os.environ.get(bstack1ll1lll_opy_ (u"ࠦࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡒࡔࡊࡅࡠࡅࡒ࡙ࡓ࡚ࠢṳ")) or bstack1ll1lll_opy_ (u"ࠧ࠷ࠢṴ")))
            self.bstack111111l11l_opy_(bstack1ll1lll_opy_ (u"ࠨࡤࡰࡹࡱࡰࡴࡧࡤࡦࡦࡗࡩࡸࡺࡆࡪ࡮ࡨࡷࡈࡵࡵ࡯ࡶࠥṵ"), len(ordered_test_files))
            self.bstack111111l11l_opy_(bstack1ll1lll_opy_ (u"ࠢࡴࡲ࡯࡭ࡹ࡚ࡥࡴࡶࡶࡅࡕࡏࡃࡢ࡮࡯ࡇࡴࡻ࡮ࡵࠤṶ"), self.bstack111l11l1l11_opy_.bstack111l111ll11_opy_())
            return ordered_test_files
        except Exception as e:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠣ࡝ࡵࡩࡴࡸࡤࡦࡴࡢࡸࡪࡹࡴࡠࡨ࡬ࡰࡪࡹ࡝ࠡࡇࡵࡶࡴࡸࠠࡪࡰࠣࡳࡷࡪࡥࡳ࡫ࡱ࡫ࠥࡺࡥࡴࡶࠣࡧࡱࡧࡳࡴࡧࡶ࠾ࠥࢁࡽࠣṷ").format(e))
        return None
    def bstack111111l11l_opy_(self, key, value):
        self.bstack111l111llll_opy_[key] = value
    def bstack1lll1l1ll_opy_(self):
        return self.bstack111l111llll_opy_