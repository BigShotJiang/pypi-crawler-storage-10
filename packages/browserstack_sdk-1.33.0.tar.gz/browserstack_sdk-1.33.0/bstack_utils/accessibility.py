# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import os
import json
import requests
import logging
import threading
import bstack_utils.constants as bstack11ll1ll111l_opy_
from urllib.parse import urlparse
from bstack_utils.constants import bstack11ll1l1llll_opy_ as bstack11ll11l11l1_opy_, EVENTS
from bstack_utils.bstack1l11llll_opy_ import bstack1l11llll_opy_
from bstack_utils.helper import bstack1l11l1llll_opy_, bstack111l1l1111_opy_, bstack11ll1l1111_opy_, bstack11ll1ll1ll1_opy_, \
  bstack11ll1l111ll_opy_, bstack1l111l1l_opy_, get_host_info, bstack11ll1l1ll1l_opy_, bstack111lll1ll1_opy_, error_handler, bstack11ll11l1ll1_opy_, bstack11ll11lllll_opy_, bstack11l1l1lll_opy_
from browserstack_sdk._version import __version__
from bstack_utils.bstack1ll1ll1111_opy_ import get_logger
from bstack_utils.bstack11llll1111_opy_ import bstack1llll11111l_opy_
from selenium.webdriver.chrome.options import Options as ChromeOptions
from browserstack_sdk.sdk_cli.cli import cli
from bstack_utils.constants import *
logger = get_logger(__name__)
bstack11llll1111_opy_ = bstack1llll11111l_opy_()
@error_handler(class_method=False)
def _11ll1l1ll11_opy_(driver, bstack1111l111l1_opy_):
  response = {}
  try:
    caps = driver.capabilities
    response = {
        bstack1ll1lll_opy_ (u"ࠬࡵࡳࡠࡰࡤࡱࡪ࠭ᘲ"): caps.get(bstack1ll1lll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡏࡣࡰࡩࠬᘳ"), None),
        bstack1ll1lll_opy_ (u"ࠧࡰࡵࡢࡺࡪࡸࡳࡪࡱࡱࠫᘴ"): bstack1111l111l1_opy_.get(bstack1ll1lll_opy_ (u"ࠨࡱࡶ࡚ࡪࡸࡳࡪࡱࡱࠫᘵ"), None),
        bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡢࡲࡦࡳࡥࠨᘶ"): caps.get(bstack1ll1lll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨᘷ"), None),
        bstack1ll1lll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭ᘸ"): caps.get(bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ᘹ"), None)
    }
  except Exception as error:
    logger.debug(bstack1ll1lll_opy_ (u"࠭ࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥ࡬ࡥࡵࡥ࡫࡭ࡳ࡭ࠠࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࠢࡧࡩࡹࡧࡩ࡭ࡵࠣࡻ࡮ࡺࡨࠡࡧࡵࡶࡴࡸࠠ࠻ࠢࠪᘺ") + str(error))
  return response
def on():
    if os.environ.get(bstack1ll1lll_opy_ (u"ࠧࡃࡕࡢࡅ࠶࠷࡙ࡠࡌ࡚ࡘࠬᘻ"), None) is None or os.environ[bstack1ll1lll_opy_ (u"ࠨࡄࡖࡣࡆ࠷࠱࡚ࡡࡍ࡛࡙࠭ᘼ")] == bstack1ll1lll_opy_ (u"ࠤࡱࡹࡱࡲࠢᘽ"):
        return False
    return True
def bstack1lll11l11l_opy_(config):
  return config.get(bstack1ll1lll_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪᘾ"), False) or any([p.get(bstack1ll1lll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠫᘿ"), False) == True for p in config.get(bstack1ll1lll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨᙀ"), [])])
def bstack11l1111lll_opy_(config, bstack1l1ll11lll_opy_):
  try:
    bstack11ll1l11111_opy_ = config.get(bstack1ll1lll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࠭ᙁ"), False)
    if int(bstack1l1ll11lll_opy_) < len(config.get(bstack1ll1lll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪᙂ"), [])) and config[bstack1ll1lll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫᙃ")][bstack1l1ll11lll_opy_]:
      bstack11ll11l1lll_opy_ = config[bstack1ll1lll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬᙄ")][bstack1l1ll11lll_opy_].get(bstack1ll1lll_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪᙅ"), None)
    else:
      bstack11ll11l1lll_opy_ = config.get(bstack1ll1lll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠫᙆ"), None)
    if bstack11ll11l1lll_opy_ != None:
      bstack11ll1l11111_opy_ = bstack11ll11l1lll_opy_
    bstack11ll1l11ll1_opy_ = os.getenv(bstack1ll1lll_opy_ (u"ࠬࡈࡓࡠࡃ࠴࠵࡞ࡥࡊࡘࡖࠪᙇ")) is not None and len(os.getenv(bstack1ll1lll_opy_ (u"࠭ࡂࡔࡡࡄ࠵࠶࡟࡟ࡋ࡙ࡗࠫᙈ"))) > 0 and os.getenv(bstack1ll1lll_opy_ (u"ࠧࡃࡕࡢࡅ࠶࠷࡙ࡠࡌ࡚ࡘࠬᙉ")) != bstack1ll1lll_opy_ (u"ࠨࡰࡸࡰࡱ࠭ᙊ")
    return bstack11ll1l11111_opy_ and bstack11ll1l11ll1_opy_
  except Exception as error:
    logger.debug(bstack1ll1lll_opy_ (u"ࠩࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡸࡨࡶ࡮࡬ࡹࡪࡰࡪࠤࡹ࡮ࡥࠡࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡵࡨࡷࡸ࡯࡯࡯ࠢࡺ࡭ࡹ࡮ࠠࡦࡴࡵࡳࡷࠦ࠺ࠡࠩᙋ") + str(error))
  return False
def bstack11l1l11ll1_opy_(test_tags):
  bstack1ll11l1ll11_opy_ = os.getenv(bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚࡟ࡂࡅࡆࡉࡘ࡙ࡉࡃࡋࡏࡍ࡙࡟࡟ࡄࡑࡑࡊࡎࡍࡕࡓࡃࡗࡍࡔࡔ࡟࡚ࡏࡏࠫᙌ"))
  if bstack1ll11l1ll11_opy_ is None:
    return True
  bstack1ll11l1ll11_opy_ = json.loads(bstack1ll11l1ll11_opy_)
  try:
    include_tags = bstack1ll11l1ll11_opy_[bstack1ll1lll_opy_ (u"ࠫ࡮ࡴࡣ࡭ࡷࡧࡩ࡙ࡧࡧࡴࡋࡱࡘࡪࡹࡴࡪࡰࡪࡗࡨࡵࡰࡦࠩᙍ")] if bstack1ll1lll_opy_ (u"ࠬ࡯࡮ࡤ࡮ࡸࡨࡪ࡚ࡡࡨࡵࡌࡲ࡙࡫ࡳࡵ࡫ࡱ࡫ࡘࡩ࡯ࡱࡧࠪᙎ") in bstack1ll11l1ll11_opy_ and isinstance(bstack1ll11l1ll11_opy_[bstack1ll1lll_opy_ (u"࠭ࡩ࡯ࡥ࡯ࡹࡩ࡫ࡔࡢࡩࡶࡍࡳ࡚ࡥࡴࡶ࡬ࡲ࡬࡙ࡣࡰࡲࡨࠫᙏ")], list) else []
    exclude_tags = bstack1ll11l1ll11_opy_[bstack1ll1lll_opy_ (u"ࠧࡦࡺࡦࡰࡺࡪࡥࡕࡣࡪࡷࡎࡴࡔࡦࡵࡷ࡭ࡳ࡭ࡓࡤࡱࡳࡩࠬᙐ")] if bstack1ll1lll_opy_ (u"ࠨࡧࡻࡧࡱࡻࡤࡦࡖࡤ࡫ࡸࡏ࡮ࡕࡧࡶࡸ࡮ࡴࡧࡔࡥࡲࡴࡪ࠭ᙑ") in bstack1ll11l1ll11_opy_ and isinstance(bstack1ll11l1ll11_opy_[bstack1ll1lll_opy_ (u"ࠩࡨࡼࡨࡲࡵࡥࡧࡗࡥ࡬ࡹࡉ࡯ࡖࡨࡷࡹ࡯࡮ࡨࡕࡦࡳࡵ࡫ࠧᙒ")], list) else []
    excluded = any(tag in exclude_tags for tag in test_tags)
    included = len(include_tags) == 0 or any(tag in include_tags for tag in test_tags)
    return not excluded and included
  except Exception as error:
    logger.debug(bstack1ll1lll_opy_ (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡬࡮ࡲࡥࠡࡸࡤࡰ࡮ࡪࡡࡵ࡫ࡱ࡫ࠥࡺࡥࡴࡶࠣࡧࡦࡹࡥࠡࡨࡲࡶࠥࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡨࡥࡧࡱࡵࡩࠥࡹࡣࡢࡰࡱ࡭ࡳ࡭࠮ࠡࡇࡵࡶࡴࡸࠠ࠻ࠢࠥᙓ") + str(error))
  return False
def bstack11ll1l11l1l_opy_(config, bstack11ll11ll1l1_opy_, bstack11ll1ll1111_opy_, bstack11ll1l11lll_opy_):
  bstack11ll1lll11l_opy_ = bstack11ll1ll1ll1_opy_(config)
  bstack11ll11l1l11_opy_ = bstack11ll1l111ll_opy_(config)
  if bstack11ll1lll11l_opy_ is None or bstack11ll11l1l11_opy_ is None:
    logger.error(bstack1ll1lll_opy_ (u"ࠫࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡸࡪ࡬ࡰࡪࠦࡣࡳࡧࡤࡸ࡮ࡴࡧࠡࡶࡨࡷࡹࠦࡲࡶࡰࠣࡪࡴࡸࠠࡃࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࠦࡁࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰ࠽ࠤࡒ࡯ࡳࡴ࡫ࡱ࡫ࠥࡧࡵࡵࡪࡨࡲࡹ࡯ࡣࡢࡶ࡬ࡳࡳࠦࡴࡰ࡭ࡨࡲࠬᙔ"))
    return [None, None]
  try:
    settings = json.loads(os.getenv(bstack1ll1lll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡡࡄࡇࡈࡋࡓࡔࡋࡅࡍࡑࡏࡔ࡚ࡡࡆࡓࡓࡌࡉࡈࡗࡕࡅ࡙ࡏࡏࡏࡡ࡜ࡑࡑ࠭ᙕ"), bstack1ll1lll_opy_ (u"࠭ࡻࡾࠩᙖ")))
    data = {
        bstack1ll1lll_opy_ (u"ࠧࡱࡴࡲ࡮ࡪࡩࡴࡏࡣࡰࡩࠬᙗ"): config[bstack1ll1lll_opy_ (u"ࠨࡲࡵࡳ࡯࡫ࡣࡵࡐࡤࡱࡪ࠭ᙘ")],
        bstack1ll1lll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬᙙ"): config.get(bstack1ll1lll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭ᙚ"), os.path.basename(os.getcwd())),
        bstack1ll1lll_opy_ (u"ࠫࡸࡺࡡࡳࡶࡗ࡭ࡲ࡫ࠧᙛ"): bstack1l11l1llll_opy_(),
        bstack1ll1lll_opy_ (u"ࠬࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠪᙜ"): config.get(bstack1ll1lll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡉ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠩᙝ"), bstack1ll1lll_opy_ (u"ࠧࠨᙞ")),
        bstack1ll1lll_opy_ (u"ࠨࡵࡲࡹࡷࡩࡥࠨᙟ"): {
            bstack1ll1lll_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࡓࡧ࡭ࡦࠩᙠ"): bstack11ll11ll1l1_opy_,
            bstack1ll1lll_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ᙡ"): bstack11ll1ll1111_opy_,
            bstack1ll1lll_opy_ (u"ࠫࡸࡪ࡫ࡗࡧࡵࡷ࡮ࡵ࡮ࠨᙢ"): __version__,
            bstack1ll1lll_opy_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧᙣ"): bstack1ll1lll_opy_ (u"࠭ࡰࡺࡶ࡫ࡳࡳ࠭ᙤ"),
            bstack1ll1lll_opy_ (u"ࠧࡵࡧࡶࡸࡋࡸࡡ࡮ࡧࡺࡳࡷࡱࠧᙥ"): bstack1ll1lll_opy_ (u"ࠨࡵࡨࡰࡪࡴࡩࡶ࡯ࠪᙦ"),
            bstack1ll1lll_opy_ (u"ࠩࡷࡩࡸࡺࡆࡳࡣࡰࡩࡼࡵࡲ࡬ࡘࡨࡶࡸ࡯࡯࡯ࠩᙧ"): bstack11ll1l11lll_opy_
        },
        bstack1ll1lll_opy_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷࠬᙨ"): settings,
        bstack1ll1lll_opy_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࡈࡵ࡮ࡵࡴࡲࡰࠬᙩ"): bstack11ll1l1ll1l_opy_(),
        bstack1ll1lll_opy_ (u"ࠬࡩࡩࡊࡰࡩࡳࠬᙪ"): bstack1l111l1l_opy_(),
        bstack1ll1lll_opy_ (u"࠭ࡨࡰࡵࡷࡍࡳ࡬࡯ࠨᙫ"): get_host_info(),
        bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡇࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࠩᙬ"): bstack11ll1l1111_opy_(config)
    }
    headers = {
        bstack1ll1lll_opy_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ᙭"): bstack1ll1lll_opy_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬ᙮"),
    }
    config = {
        bstack1ll1lll_opy_ (u"ࠪࡥࡺࡺࡨࠨᙯ"): (bstack11ll1lll11l_opy_, bstack11ll11l1l11_opy_),
        bstack1ll1lll_opy_ (u"ࠫ࡭࡫ࡡࡥࡧࡵࡷࠬᙰ"): headers
    }
    response = bstack111lll1ll1_opy_(bstack1ll1lll_opy_ (u"ࠬࡖࡏࡔࡖࠪᙱ"), bstack11ll11l11l1_opy_ + bstack1ll1lll_opy_ (u"࠭࠯ࡷ࠴࠲ࡸࡪࡹࡴࡠࡴࡸࡲࡸ࠭ᙲ"), data, config)
    bstack11ll1l1l1ll_opy_ = response.json()
    if bstack11ll1l1l1ll_opy_[bstack1ll1lll_opy_ (u"ࠧࡴࡷࡦࡧࡪࡹࡳࠨᙳ")]:
      parsed = json.loads(os.getenv(bstack1ll1lll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡇࡖࡘࡤࡇࡃࡄࡇࡖࡗࡎࡈࡉࡍࡋࡗ࡝ࡤࡉࡏࡏࡈࡌࡋ࡚ࡘࡁࡕࡋࡒࡒࡤ࡟ࡍࡍࠩᙴ"), bstack1ll1lll_opy_ (u"ࠩࡾࢁࠬᙵ")))
      parsed[bstack1ll1lll_opy_ (u"ࠪࡷࡨࡧ࡮࡯ࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫᙶ")] = bstack11ll1l1l1ll_opy_[bstack1ll1lll_opy_ (u"ࠫࡩࡧࡴࡢࠩᙷ")][bstack1ll1lll_opy_ (u"ࠬࡹࡣࡢࡰࡱࡩࡷ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ᙸ")]
      os.environ[bstack1ll1lll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤ࡚ࡅࡔࡖࡢࡅࡈࡉࡅࡔࡕࡌࡆࡎࡒࡉࡕ࡛ࡢࡇࡔࡔࡆࡊࡉࡘࡖࡆ࡚ࡉࡐࡐࡢ࡝ࡒࡒࠧᙹ")] = json.dumps(parsed)
      bstack1l11llll_opy_.bstack11l1l11lll_opy_(bstack11ll1l1l1ll_opy_[bstack1ll1lll_opy_ (u"ࠧࡥࡣࡷࡥࠬᙺ")][bstack1ll1lll_opy_ (u"ࠨࡵࡦࡶ࡮ࡶࡴࡴࠩᙻ")])
      bstack1l11llll_opy_.bstack11ll1l1lll1_opy_(bstack11ll1l1l1ll_opy_[bstack1ll1lll_opy_ (u"ࠩࡧࡥࡹࡧࠧᙼ")][bstack1ll1lll_opy_ (u"ࠪࡧࡴࡳ࡭ࡢࡰࡧࡷࠬᙽ")])
      bstack1l11llll_opy_.store()
      return bstack11ll1l1l1ll_opy_[bstack1ll1lll_opy_ (u"ࠫࡩࡧࡴࡢࠩᙾ")][bstack1ll1lll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽ࡙ࡵ࡫ࡦࡰࠪᙿ")], bstack11ll1l1l1ll_opy_[bstack1ll1lll_opy_ (u"࠭ࡤࡢࡶࡤࠫ ")][bstack1ll1lll_opy_ (u"ࠧࡪࡦࠪᚁ")]
    else:
      logger.error(bstack1ll1lll_opy_ (u"ࠨࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤࡼ࡮ࡩ࡭ࡧࠣࡶࡺࡴ࡮ࡪࡰࡪࠤࡇࡸ࡯ࡸࡵࡨࡶࡘࡺࡡࡤ࡭ࠣࡅࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡅࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴ࠺ࠡࠩᚂ") + bstack11ll1l1l1ll_opy_[bstack1ll1lll_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪᚃ")])
      if bstack11ll1l1l1ll_opy_[bstack1ll1lll_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫᚄ")] == bstack1ll1lll_opy_ (u"ࠫࡎࡴࡶࡢ࡮࡬ࡨࠥࡩ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲࠥࡶࡡࡴࡵࡨࡨ࠳࠭ᚅ"):
        for bstack11ll1l1l11l_opy_ in bstack11ll1l1l1ll_opy_[bstack1ll1lll_opy_ (u"ࠬ࡫ࡲࡳࡱࡵࡷࠬᚆ")]:
          logger.error(bstack11ll1l1l11l_opy_[bstack1ll1lll_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧᚇ")])
      return None, None
  except Exception as error:
    logger.error(bstack1ll1lll_opy_ (u"ࠢࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣࡻ࡭࡯࡬ࡦࠢࡦࡶࡪࡧࡴࡪࡰࡪࠤࡹ࡫ࡳࡵࠢࡵࡹࡳࠦࡦࡰࡴࠣࡆࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࠢࡄࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳࡀࠠࠣᚈ") +  str(error))
    return None, None
def bstack11ll1ll11ll_opy_():
  if os.getenv(bstack1ll1lll_opy_ (u"ࠨࡄࡖࡣࡆ࠷࠱࡚ࡡࡍ࡛࡙࠭ᚉ")) is None:
    return {
        bstack1ll1lll_opy_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩᚊ"): bstack1ll1lll_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࠩᚋ"),
        bstack1ll1lll_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬᚌ"): bstack1ll1lll_opy_ (u"ࠬࡈࡵࡪ࡮ࡧࠤࡨࡸࡥࡢࡶ࡬ࡳࡳࠦࡨࡢࡦࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠫᚍ")
    }
  data = {bstack1ll1lll_opy_ (u"࠭ࡥ࡯ࡦࡗ࡭ࡲ࡫ࠧᚎ"): bstack1l11l1llll_opy_()}
  headers = {
      bstack1ll1lll_opy_ (u"ࠧࡂࡷࡷ࡬ࡴࡸࡩࡻࡣࡷ࡭ࡴࡴࠧᚏ"): bstack1ll1lll_opy_ (u"ࠨࡄࡨࡥࡷ࡫ࡲࠡࠩᚐ") + os.getenv(bstack1ll1lll_opy_ (u"ࠤࡅࡗࡤࡇ࠱࠲࡛ࡢࡎ࡜࡚ࠢᚑ")),
      bstack1ll1lll_opy_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩᚒ"): bstack1ll1lll_opy_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱࡭ࡷࡴࡴࠧᚓ")
  }
  response = bstack111lll1ll1_opy_(bstack1ll1lll_opy_ (u"ࠬࡖࡕࡕࠩᚔ"), bstack11ll11l11l1_opy_ + bstack1ll1lll_opy_ (u"࠭࠯ࡵࡧࡶࡸࡤࡸࡵ࡯ࡵ࠲ࡷࡹࡵࡰࠨᚕ"), data, { bstack1ll1lll_opy_ (u"ࠧࡩࡧࡤࡨࡪࡸࡳࠨᚖ"): headers })
  try:
    if response.status_code == 200:
      logger.info(bstack1ll1lll_opy_ (u"ࠣࡄࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࠠࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠤ࡙࡫ࡳࡵࠢࡕࡹࡳࠦ࡭ࡢࡴ࡮ࡩࡩࠦࡡࡴࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࡨࠥࡧࡴࠡࠤᚗ") + bstack111l1l1111_opy_().isoformat() + bstack1ll1lll_opy_ (u"ࠩ࡝ࠫᚘ"))
      return {bstack1ll1lll_opy_ (u"ࠪࡷࡹࡧࡴࡶࡵࠪᚙ"): bstack1ll1lll_opy_ (u"ࠫࡸࡻࡣࡤࡧࡶࡷࠬᚚ"), bstack1ll1lll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭᚛"): bstack1ll1lll_opy_ (u"࠭ࠧ᚜")}
    else:
      response.raise_for_status()
  except requests.RequestException as error:
    logger.error(bstack1ll1lll_opy_ (u"ࠢࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣࡻ࡭࡯࡬ࡦࠢࡰࡥࡷࡱࡩ࡯ࡩࠣࡧࡴࡳࡰ࡭ࡧࡷ࡭ࡴࡴࠠࡰࡨࠣࡆࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࠢࡄࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳࠦࡔࡦࡵࡷࠤࡗࡻ࡮࠻ࠢࠥ᚝") + str(error))
    return {
        bstack1ll1lll_opy_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨ᚞"): bstack1ll1lll_opy_ (u"ࠩࡨࡶࡷࡵࡲࠨ᚟"),
        bstack1ll1lll_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫᚠ"): str(error)
    }
def bstack11ll1ll1lll_opy_(bstack11ll1l1l111_opy_):
    return re.match(bstack1ll1lll_opy_ (u"ࡶࠬࡤ࡜ࡥ࠭ࠫࡠ࠳ࡢࡤࠬࠫࡂࠨࠬᚡ"), bstack11ll1l1l111_opy_.strip()) is not None
def bstack1lll11l11_opy_(caps, options, desired_capabilities={}, config=None):
    try:
        if options:
          bstack11ll11l111l_opy_ = options.to_capabilities()
        elif desired_capabilities:
          bstack11ll11l111l_opy_ = desired_capabilities
        else:
          bstack11ll11l111l_opy_ = {}
        bstack1ll11l11111_opy_ = (bstack11ll11l111l_opy_.get(bstack1ll1lll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡎࡢ࡯ࡨࠫᚢ"), bstack1ll1lll_opy_ (u"࠭ࠧᚣ")).lower() or caps.get(bstack1ll1lll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡐࡤࡱࡪ࠭ᚤ"), bstack1ll1lll_opy_ (u"ࠨࠩᚥ")).lower())
        if bstack1ll11l11111_opy_ == bstack1ll1lll_opy_ (u"ࠩ࡬ࡳࡸ࠭ᚦ"):
            return True
        if bstack1ll11l11111_opy_ == bstack1ll1lll_opy_ (u"ࠪࡥࡳࡪࡲࡰ࡫ࡧࠫᚧ"):
            bstack1ll11ll11ll_opy_ = str(float(caps.get(bstack1ll1lll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ᚨ")) or bstack11ll11l111l_opy_.get(bstack1ll1lll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯࠿ࡵࡰࡵ࡫ࡲࡲࡸ࠭ᚩ"), {}).get(bstack1ll1lll_opy_ (u"࠭࡯ࡴࡘࡨࡶࡸ࡯࡯࡯ࠩᚪ"),bstack1ll1lll_opy_ (u"ࠧࠨᚫ"))))
            if bstack1ll11l11111_opy_ == bstack1ll1lll_opy_ (u"ࠨࡣࡱࡨࡷࡵࡩࡥࠩᚬ") and int(bstack1ll11ll11ll_opy_.split(bstack1ll1lll_opy_ (u"ࠩ࠱ࠫᚭ"))[0]) < float(bstack11ll1lll1l1_opy_):
                logger.warning(str(bstack11ll1l11l11_opy_))
                return False
            return True
        bstack1ll11l1l1ll_opy_ = caps.get(bstack1ll1lll_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭࠽ࡳࡵࡺࡩࡰࡰࡶࠫᚮ"), {}).get(bstack1ll1lll_opy_ (u"ࠫࡩ࡫ࡶࡪࡥࡨࡒࡦࡳࡥࠨᚯ"), caps.get(bstack1ll1lll_opy_ (u"ࠬࡪࡥࡷ࡫ࡦࡩࠬᚰ"), bstack1ll1lll_opy_ (u"࠭ࠧᚱ")))
        if bstack1ll11l1l1ll_opy_:
            logger.warning(bstack1ll1lll_opy_ (u"ࠢࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠤࡼ࡯࡬࡭ࠢࡵࡹࡳࠦ࡯࡯࡮ࡼࠤࡴࡴࠠࡅࡧࡶ࡯ࡹࡵࡰࠡࡤࡵࡳࡼࡹࡥࡳࡵ࠱ࠦᚲ"))
            return False
        browser = caps.get(bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪ࠭ᚳ"), bstack1ll1lll_opy_ (u"ࠩࠪᚴ")).lower() or bstack11ll11l111l_opy_.get(bstack1ll1lll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨᚵ"), bstack1ll1lll_opy_ (u"ࠫࠬᚶ")).lower()
        if browser != bstack1ll1lll_opy_ (u"ࠬࡩࡨࡳࡱࡰࡩࠬᚷ"):
            logger.warning(bstack1ll1lll_opy_ (u"ࠨࡁࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰࠣࡻ࡮ࡲ࡬ࠡࡴࡸࡲࠥࡵ࡮࡭ࡻࠣࡳࡳࠦࡃࡩࡴࡲࡱࡪࠦࡢࡳࡱࡺࡷࡪࡸࡳ࠯ࠤᚸ"))
            return False
        browser_version = caps.get(bstack1ll1lll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨᚹ")) or caps.get(bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡡࡹࡩࡷࡹࡩࡰࡰࠪᚺ")) or bstack11ll11l111l_opy_.get(bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪᚻ")) or bstack11ll11l111l_opy_.get(bstack1ll1lll_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭࠽ࡳࡵࡺࡩࡰࡰࡶࠫᚼ"), {}).get(bstack1ll1lll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬᚽ")) or bstack11ll11l111l_opy_.get(bstack1ll1lll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯࠿ࡵࡰࡵ࡫ࡲࡲࡸ࠭ᚾ"), {}).get(bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨᚿ"))
        bstack1ll111ll1l1_opy_ = bstack11ll1ll111l_opy_.bstack1ll11ll1ll1_opy_
        bstack11ll1l111l1_opy_ = False
        if config is not None:
          bstack11ll1l111l1_opy_ = bstack1ll1lll_opy_ (u"ࠧࡵࡷࡵࡦࡴ࡙ࡣࡢ࡮ࡨࠫᛀ") in config and str(config[bstack1ll1lll_opy_ (u"ࠨࡶࡸࡶࡧࡵࡓࡤࡣ࡯ࡩࠬᛁ")]).lower() != bstack1ll1lll_opy_ (u"ࠩࡩࡥࡱࡹࡥࠨᛂ")
        if os.environ.get(bstack1ll1lll_opy_ (u"ࠪࡍࡘࡥࡎࡐࡐࡢࡆࡘ࡚ࡁࡄࡍࡢࡍࡓࡌࡒࡂࡡࡄ࠵࠶࡟࡟ࡔࡇࡖࡗࡎࡕࡎࠨᛃ"), bstack1ll1lll_opy_ (u"ࠫࠬᛄ")).lower() == bstack1ll1lll_opy_ (u"ࠬࡺࡲࡶࡧࠪᛅ") or bstack11ll1l111l1_opy_:
          bstack1ll111ll1l1_opy_ = bstack11ll1ll111l_opy_.bstack1ll11l11lll_opy_
        if browser_version and browser_version != bstack1ll1lll_opy_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭ᛆ") and int(browser_version.split(bstack1ll1lll_opy_ (u"ࠧ࠯ࠩᛇ"))[0]) <= bstack1ll111ll1l1_opy_:
          logger.warning(bstack11111ll1ll_opy_ (u"ࠨࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡃࡸࡸࡴࡳࡡࡵ࡫ࡲࡲࠥࡽࡩ࡭࡮ࠣࡶࡺࡴࠠࡰࡰ࡯ࡽࠥࡵ࡮ࠡࡅ࡫ࡶࡴࡳࡥࠡࡤࡵࡳࡼࡹࡥࡳࠢࡹࡩࡷࡹࡩࡰࡰࠣ࡫ࡷ࡫ࡡࡵࡧࡵࠤࡹ࡮ࡡ࡯ࠢࡾࡱ࡮ࡴ࡟ࡢ࠳࠴ࡽࡤࡹࡵࡱࡲࡲࡶࡹ࡫ࡤࡠࡥ࡫ࡶࡴࡳࡥࡠࡸࡨࡶࡸ࡯࡯࡯ࡿ࠱ࠫᛈ"))
          return False
        if not options:
          bstack1ll11lll1ll_opy_ = caps.get(bstack1ll1lll_opy_ (u"ࠩࡪࡳࡴ࡭࠺ࡤࡪࡵࡳࡲ࡫ࡏࡱࡶ࡬ࡳࡳࡹࠧᛉ")) or bstack11ll11l111l_opy_.get(bstack1ll1lll_opy_ (u"ࠪ࡫ࡴࡵࡧ࠻ࡥ࡫ࡶࡴࡳࡥࡐࡲࡷ࡭ࡴࡴࡳࠨᛊ"), {})
          if bstack1ll1lll_opy_ (u"ࠫ࠲࠳ࡨࡦࡣࡧࡰࡪࡹࡳࠨᛋ") in bstack1ll11lll1ll_opy_.get(bstack1ll1lll_opy_ (u"ࠬࡧࡲࡨࡵࠪᛌ"), []):
              logger.warning(bstack1ll1lll_opy_ (u"ࠨࡁࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡸࡵ࡯ࠢࡲࡲࠥࡲࡥࡨࡣࡦࡽࠥ࡮ࡥࡢࡦ࡯ࡩࡸࡹࠠ࡮ࡱࡧࡩ࠳ࠦࡓࡸ࡫ࡷࡧ࡭ࠦࡴࡰࠢࡱࡩࡼࠦࡨࡦࡣࡧࡰࡪࡹࡳࠡ࡯ࡲࡨࡪࠦ࡯ࡳࠢࡤࡺࡴ࡯ࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡩࡧࡤࡨࡱ࡫ࡳࡴࠢࡰࡳࡩ࡫࠮ࠣᛍ"))
              return False
        return True
    except Exception as error:
        logger.debug(bstack1ll1lll_opy_ (u"ࠢࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡶࡢ࡮࡬ࡨࡦࡺࡥࠡࡣ࠴࠵ࡾࠦࡳࡶࡲࡳࡳࡷࡺࠠ࠻ࠤᛎ") + str(error))
        return False
def set_capabilities(caps, config):
  try:
    bstack1llll11l111_opy_ = config.get(bstack1ll1lll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࡐࡲࡷ࡭ࡴࡴࡳࠨᛏ"), {})
    bstack1llll11l111_opy_[bstack1ll1lll_opy_ (u"ࠩࡤࡹࡹ࡮ࡔࡰ࡭ࡨࡲࠬᛐ")] = os.getenv(bstack1ll1lll_opy_ (u"ࠪࡆࡘࡥࡁ࠲࠳࡜ࡣࡏ࡝ࡔࠨᛑ"))
    bstack11ll11lll1l_opy_ = json.loads(os.getenv(bstack1ll1lll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡘࡊ࡙ࡔࡠࡃࡆࡇࡊ࡙ࡓࡊࡄࡌࡐࡎ࡚࡙ࡠࡅࡒࡒࡋࡏࡇࡖࡔࡄࡘࡎࡕࡎࡠ࡛ࡐࡐࠬᛒ"), bstack1ll1lll_opy_ (u"ࠬࢁࡽࠨᛓ"))).get(bstack1ll1lll_opy_ (u"࠭ࡳࡤࡣࡱࡲࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧᛔ"))
    if not config[bstack1ll1lll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡖࡲࡰࡦࡸࡧࡹࡓࡡࡱࠩᛕ")].get(bstack1ll1lll_opy_ (u"ࠣࡣࡳࡴࡤࡧࡵࡵࡱࡰࡥࡹ࡫ࠢᛖ")):
      if bstack1ll1lll_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠼ࡲࡴࡹ࡯࡯࡯ࡵࠪᛗ") in caps:
        caps[bstack1ll1lll_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭࠽ࡳࡵࡺࡩࡰࡰࡶࠫᛘ")][bstack1ll1lll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࡓࡵࡺࡩࡰࡰࡶࠫᛙ")] = bstack1llll11l111_opy_
        caps[bstack1ll1lll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯࠿ࡵࡰࡵ࡫ࡲࡲࡸ࠭ᛚ")][bstack1ll1lll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࡕࡰࡵ࡫ࡲࡲࡸ࠭ᛛ")][bstack1ll1lll_opy_ (u"ࠧࡴࡥࡤࡲࡳ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨᛜ")] = bstack11ll11lll1l_opy_
      else:
        caps[bstack1ll1lll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࡏࡱࡶ࡬ࡳࡳࡹࠧᛝ")] = bstack1llll11l111_opy_
        caps[bstack1ll1lll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࡐࡲࡷ࡭ࡴࡴࡳࠨᛞ")][bstack1ll1lll_opy_ (u"ࠪࡷࡨࡧ࡮࡯ࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫᛟ")] = bstack11ll11lll1l_opy_
  except Exception as error:
    logger.debug(bstack1ll1lll_opy_ (u"ࠦࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡸࡪ࡬ࡰࡪࠦࡳࡦࡶࡷ࡭ࡳ࡭ࠠࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠤࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵ࠱ࠤࡊࡸࡲࡰࡴ࠽ࠤࠧᛠ") +  str(error))
def bstack1l1ll111ll_opy_(driver, bstack11ll1l1111l_opy_):
  try:
    setattr(driver, bstack1ll1lll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯ࡆ࠷࠱ࡺࡕ࡫ࡳࡺࡲࡤࡔࡥࡤࡲࠬᛡ"), True)
    session = driver.session_id
    if session:
      bstack11ll1l1l1l1_opy_ = True
      current_url = driver.current_url
      try:
        url = urlparse(current_url)
      except Exception as e:
        bstack11ll1l1l1l1_opy_ = False
      bstack11ll1l1l1l1_opy_ = url.scheme in [bstack1ll1lll_opy_ (u"ࠨࡨࡵࡶࡳࠦᛢ"), bstack1ll1lll_opy_ (u"ࠢࡩࡶࡷࡴࡸࠨᛣ")]
      if bstack11ll1l1l1l1_opy_:
        if bstack11ll1l1111l_opy_:
          logger.info(bstack1ll1lll_opy_ (u"ࠣࡕࡨࡸࡺࡶࠠࡧࡱࡵࠤࡆࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡹ࡫ࡳࡵ࡫ࡱ࡫ࠥ࡮ࡡࡴࠢࡶࡸࡦࡸࡴࡦࡦ࠱ࠤࡆࡻࡴࡰ࡯ࡤࡸࡪࠦࡴࡦࡵࡷࠤࡨࡧࡳࡦࠢࡨࡼࡪࡩࡵࡵ࡫ࡲࡲࠥࡽࡩ࡭࡮ࠣࡦࡪ࡭ࡩ࡯ࠢࡰࡳࡲ࡫࡮ࡵࡣࡵ࡭ࡱࡿ࠮ࠣᛤ"))
      return bstack11ll1l1111l_opy_
  except Exception as e:
    logger.error(bstack1ll1lll_opy_ (u"ࠤࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡵࡷࡥࡷࡺࡩ࡯ࡩࠣࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࠠࡴࡥࡤࡲࠥ࡬࡯ࡳࠢࡷ࡬࡮ࡹࠠࡵࡧࡶࡸࠥࡩࡡࡴࡧ࠽ࠤࠧᛥ") + str(e))
    return False
def bstack11llllll1_opy_(driver, name, path):
  try:
    bstack1ll111ll111_opy_ = {
        bstack1ll1lll_opy_ (u"ࠪࡸ࡭࡚ࡥࡴࡶࡕࡹࡳ࡛ࡵࡪࡦࠪᛦ"): threading.current_thread().current_test_uuid,
        bstack1ll1lll_opy_ (u"ࠫࡹ࡮ࡂࡶ࡫࡯ࡨ࡚ࡻࡩࡥࠩᛧ"): os.environ.get(bstack1ll1lll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤ࡛ࡕࡊࡆࠪᛨ"), bstack1ll1lll_opy_ (u"࠭ࠧᛩ")),
        bstack1ll1lll_opy_ (u"ࠧࡵࡪࡍࡻࡹ࡚࡯࡬ࡧࡱࠫᛪ"): os.environ.get(bstack1ll1lll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡇࡖࡘࡍ࡛ࡂࡠࡌ࡚ࡘࠬ᛫"), bstack1ll1lll_opy_ (u"ࠩࠪ᛬"))
    }
    bstack1ll111ll11l_opy_ = bstack11llll1111_opy_.bstack1ll111l11l1_opy_(EVENTS.bstack1l11111111_opy_.value)
    logger.debug(bstack1ll1lll_opy_ (u"ࠪࡔࡪࡸࡦࡰࡴࡰ࡭ࡳ࡭ࠠࡴࡥࡤࡲࠥࡨࡥࡧࡱࡵࡩࠥࡹࡡࡷ࡫ࡱ࡫ࠥࡸࡥࡴࡷ࡯ࡸࡸ࠭᛭"))
    try:
      if (bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠫ࡮ࡹࡁࡱࡲࡄ࠵࠶ࡿࡔࡦࡵࡷࠫᛮ"), None) and bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠬࡧࡰࡱࡃ࠴࠵ࡾࡖ࡬ࡢࡶࡩࡳࡷࡳࠧᛯ"), None)):
        scripts = {bstack1ll1lll_opy_ (u"࠭ࡳࡤࡣࡱࠫᛰ"): bstack1l11llll_opy_.perform_scan}
        bstack11ll11ll1ll_opy_ = json.loads(scripts[bstack1ll1lll_opy_ (u"ࠢࡴࡥࡤࡲࠧᛱ")].replace(bstack1ll1lll_opy_ (u"ࠣࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࠦᛲ"), bstack1ll1lll_opy_ (u"ࠤࠥᛳ")))
        bstack11ll11ll1ll_opy_[bstack1ll1lll_opy_ (u"ࠪࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸ࠭ᛴ")][bstack1ll1lll_opy_ (u"ࠫࡲ࡫ࡴࡩࡱࡧࠫᛵ")] = None
        scripts[bstack1ll1lll_opy_ (u"ࠧࡹࡣࡢࡰࠥᛶ")] = bstack1ll1lll_opy_ (u"ࠨࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࠤᛷ") + json.dumps(bstack11ll11ll1ll_opy_)
        bstack1l11llll_opy_.bstack11l1l11lll_opy_(scripts)
        bstack1l11llll_opy_.store()
        logger.debug(driver.execute_script(bstack1l11llll_opy_.perform_scan))
      else:
        logger.debug(driver.execute_async_script(bstack1l11llll_opy_.perform_scan, {bstack1ll1lll_opy_ (u"ࠢ࡮ࡧࡷ࡬ࡴࡪࠢᛸ"): name}))
      bstack11llll1111_opy_.end(EVENTS.bstack1l11111111_opy_.value, bstack1ll111ll11l_opy_ + bstack1ll1lll_opy_ (u"ࠣ࠼ࡶࡸࡦࡸࡴࠣ᛹"), bstack1ll111ll11l_opy_ + bstack1ll1lll_opy_ (u"ࠤ࠽ࡩࡳࡪࠢ᛺"), True, None)
    except Exception as error:
      bstack11llll1111_opy_.end(EVENTS.bstack1l11111111_opy_.value, bstack1ll111ll11l_opy_ + bstack1ll1lll_opy_ (u"ࠥ࠾ࡸࡺࡡࡳࡶࠥ᛻"), bstack1ll111ll11l_opy_ + bstack1ll1lll_opy_ (u"ࠦ࠿࡫࡮ࡥࠤ᛼"), False, str(error))
    bstack1ll111ll11l_opy_ = bstack11llll1111_opy_.bstack11ll11l1l1l_opy_(EVENTS.bstack1ll11llll11_opy_.value)
    bstack11llll1111_opy_.mark(bstack1ll111ll11l_opy_ + bstack1ll1lll_opy_ (u"ࠧࡀࡳࡵࡣࡵࡸࠧ᛽"))
    try:
      if (bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"࠭ࡩࡴࡃࡳࡴࡆ࠷࠱ࡺࡖࡨࡷࡹ࠭᛾"), None) and bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠧࡢࡲࡳࡅ࠶࠷ࡹࡑ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩ᛿"), None)):
        scripts = {bstack1ll1lll_opy_ (u"ࠨࡵࡦࡥࡳ࠭ᜀ"): bstack1l11llll_opy_.perform_scan}
        bstack11ll11ll1ll_opy_ = json.loads(scripts[bstack1ll1lll_opy_ (u"ࠤࡶࡧࡦࡴࠢᜁ")].replace(bstack1ll1lll_opy_ (u"ࠥࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࠨᜂ"), bstack1ll1lll_opy_ (u"ࠦࠧᜃ")))
        bstack11ll11ll1ll_opy_[bstack1ll1lll_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨᜄ")][bstack1ll1lll_opy_ (u"࠭࡭ࡦࡶ࡫ࡳࡩ࠭ᜅ")] = None
        scripts[bstack1ll1lll_opy_ (u"ࠢࡴࡥࡤࡲࠧᜆ")] = bstack1ll1lll_opy_ (u"ࠣࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࠦᜇ") + json.dumps(bstack11ll11ll1ll_opy_)
        bstack1l11llll_opy_.bstack11l1l11lll_opy_(scripts)
        bstack1l11llll_opy_.store()
        logger.debug(driver.execute_script(bstack1l11llll_opy_.perform_scan))
      else:
        logger.debug(driver.execute_async_script(bstack1l11llll_opy_.bstack11ll1ll1l11_opy_, bstack1ll111ll111_opy_))
      bstack11llll1111_opy_.end(bstack1ll111ll11l_opy_, bstack1ll111ll11l_opy_ + bstack1ll1lll_opy_ (u"ࠤ࠽ࡷࡹࡧࡲࡵࠤᜈ"), bstack1ll111ll11l_opy_ + bstack1ll1lll_opy_ (u"ࠥ࠾ࡪࡴࡤࠣᜉ"),True, None)
    except Exception as error:
      bstack11llll1111_opy_.end(bstack1ll111ll11l_opy_, bstack1ll111ll11l_opy_ + bstack1ll1lll_opy_ (u"ࠦ࠿ࡹࡴࡢࡴࡷࠦᜊ"), bstack1ll111ll11l_opy_ + bstack1ll1lll_opy_ (u"ࠧࡀࡥ࡯ࡦࠥᜋ"),False, str(error))
    logger.info(bstack1ll1lll_opy_ (u"ࠨࡁࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡴࡦࡵࡷ࡭ࡳ࡭ࠠࡧࡱࡵࠤࡹ࡮ࡩࡴࠢࡷࡩࡸࡺࠠࡤࡣࡶࡩࠥ࡮ࡡࡴࠢࡨࡲࡩ࡫ࡤ࠯ࠤᜌ"))
  except Exception as bstack1ll11l1l1l1_opy_:
    logger.error(bstack1ll1lll_opy_ (u"ࠢࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡳࡧࡶࡹࡱࡺࡳࠡࡥࡲࡹࡱࡪࠠ࡯ࡱࡷࠤࡧ࡫ࠠࡱࡴࡲࡧࡪࡹࡳࡦࡦࠣࡪࡴࡸࠠࡵࡪࡨࠤࡹ࡫ࡳࡵࠢࡦࡥࡸ࡫࠺ࠡࠤᜍ") + str(path) + bstack1ll1lll_opy_ (u"ࠣࠢࡈࡶࡷࡵࡲࠡ࠼ࠥᜎ") + str(bstack1ll11l1l1l1_opy_))
def bstack11ll11ll11l_opy_(driver):
    caps = driver.capabilities
    if caps.get(bstack1ll1lll_opy_ (u"ࠤࡳࡰࡦࡺࡦࡰࡴࡰࡒࡦࡳࡥࠣᜏ")) and str(caps.get(bstack1ll1lll_opy_ (u"ࠥࡴࡱࡧࡴࡧࡱࡵࡱࡓࡧ࡭ࡦࠤᜐ"))).lower() == bstack1ll1lll_opy_ (u"ࠦࡦࡴࡤࡳࡱ࡬ࡨࠧᜑ"):
        bstack1ll11ll11ll_opy_ = caps.get(bstack1ll1lll_opy_ (u"ࠧࡧࡰࡱ࡫ࡸࡱ࠿ࡶ࡬ࡢࡶࡩࡳࡷࡳࡖࡦࡴࡶ࡭ࡴࡴࠢᜒ")) or caps.get(bstack1ll1lll_opy_ (u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡗࡧࡵࡷ࡮ࡵ࡮ࠣᜓ"))
        if bstack1ll11ll11ll_opy_ and int(str(bstack1ll11ll11ll_opy_)) < bstack11ll1lll1l1_opy_:
            return False
    return True
def bstack111lll11_opy_(config):
  if bstack1ll1lll_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿ᜔ࠧ") in config:
        return config[bstack1ll1lll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨ᜕")]
  for platform in config.get(bstack1ll1lll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬ᜖"), []):
      if bstack1ll1lll_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪ᜗") in platform:
          return platform[bstack1ll1lll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠫ᜘")]
  return None
def bstack11l11lll11_opy_(bstack11l1l11111_opy_):
  try:
    browser_name = bstack11l1l11111_opy_[bstack1ll1lll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡥ࡮ࡢ࡯ࡨࠫ᜙")]
    browser_version = bstack11l1l11111_opy_[bstack1ll1lll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ᜚")]
    chrome_options = bstack11l1l11111_opy_[bstack1ll1lll_opy_ (u"ࠧࡤࡪࡵࡳࡲ࡫࡟ࡰࡲࡷ࡭ࡴࡴࡳࠨ᜛")]
    try:
        bstack11ll11llll1_opy_ = int(browser_version.split(bstack1ll1lll_opy_ (u"ࠨ࠰ࠪ᜜"))[0])
    except ValueError as e:
        logger.error(bstack1ll1lll_opy_ (u"ࠤࡈࡶࡷࡵࡲࠡࡹ࡫࡭ࡱ࡫ࠠࡤࡱࡱࡺࡪࡸࡴࡪࡰࡪࠤࡧࡸ࡯ࡸࡵࡨࡶࠥࡼࡥࡳࡵ࡬ࡳࡳࠨ᜝") + str(e))
        return False
    if not (browser_name and browser_name.lower() == bstack1ll1lll_opy_ (u"ࠪࡧ࡭ࡸ࡯࡮ࡧࠪ᜞")):
        logger.warning(bstack1ll1lll_opy_ (u"ࠦࡆࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠡࡹ࡬ࡰࡱࠦࡲࡶࡰࠣࡳࡳࡲࡹࠡࡱࡱࠤࡈ࡮ࡲࡰ࡯ࡨࠤࡧࡸ࡯ࡸࡵࡨࡶࡸ࠴ࠢᜟ"))
        return False
    if bstack11ll11llll1_opy_ < bstack11ll1ll111l_opy_.bstack1ll11l11lll_opy_:
        logger.warning(bstack11111ll1ll_opy_ (u"ࠬࡇࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡇࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࠢࡵࡩࡶࡻࡩࡳࡧࡶࠤࡈ࡮ࡲࡰ࡯ࡨࠤࡻ࡫ࡲࡴ࡫ࡲࡲࠥࢁࡃࡐࡐࡖࡘࡆࡔࡔࡔ࠰ࡐࡍࡓࡏࡍࡖࡏࡢࡒࡔࡔ࡟ࡃࡕࡗࡅࡈࡑ࡟ࡊࡐࡉࡖࡆࡥࡁ࠲࠳࡜ࡣࡘ࡛ࡐࡑࡑࡕࡘࡊࡊ࡟ࡄࡊࡕࡓࡒࡋ࡟ࡗࡇࡕࡗࡎࡕࡎࡾࠢࡲࡶࠥ࡮ࡩࡨࡪࡨࡶ࠳࠭ᜠ"))
        return False
    if chrome_options and any(bstack1ll1lll_opy_ (u"࠭࠭࠮ࡪࡨࡥࡩࡲࡥࡴࡵࠪᜡ") in value for value in chrome_options.values() if isinstance(value, str)):
        logger.warning(bstack1ll1lll_opy_ (u"ࠢࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠤࡼ࡯࡬࡭ࠢࡱࡳࡹࠦࡲࡶࡰࠣࡳࡳࠦ࡬ࡦࡩࡤࡧࡾࠦࡨࡦࡣࡧࡰࡪࡹࡳࠡ࡯ࡲࡨࡪ࠴ࠠࡔࡹ࡬ࡸࡨ࡮ࠠࡵࡱࠣࡲࡪࡽࠠࡩࡧࡤࡨࡱ࡫ࡳࡴࠢࡰࡳࡩ࡫ࠠࡰࡴࠣࡥࡻࡵࡩࡥࠢࡸࡷ࡮ࡴࡧࠡࡪࡨࡥࡩࡲࡥࡴࡵࠣࡱࡴࡪࡥ࠯ࠤᜢ"))
        return False
    return True
  except Exception as e:
    logger.error(bstack1ll1lll_opy_ (u"ࠣࡇࡵࡶࡴࡸࠠࡪࡰࠣࡧ࡭࡫ࡣ࡬࡫ࡱ࡫ࠥࡶ࡬ࡢࡶࡩࡳࡷࡳࠠࡴࡷࡳࡴࡴࡸࡴࠡࡨࡲࡶࠥࡲ࡯ࡤࡣ࡯ࠤࡈ࡮ࡲࡰ࡯ࡨ࠾ࠥࠨᜣ") + str(e))
    return False
def bstack11l1llll_opy_(bstack1l1llll1_opy_, config):
    try:
      bstack1ll11l1llll_opy_ = bstack1ll1lll_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠩᜤ") in config and config[bstack1ll1lll_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪᜥ")] == True
      bstack11ll1l111l1_opy_ = bstack1ll1lll_opy_ (u"ࠫࡹࡻࡲࡣࡱࡖࡧࡦࡲࡥࠨᜦ") in config and str(config[bstack1ll1lll_opy_ (u"ࠬࡺࡵࡳࡤࡲࡗࡨࡧ࡬ࡦࠩᜧ")]).lower() != bstack1ll1lll_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬᜨ")
      if not (bstack1ll11l1llll_opy_ and (not bstack11ll1l1111_opy_(config) or bstack11ll1l111l1_opy_)):
        return bstack1l1llll1_opy_
      bstack11ll1ll1l1l_opy_ = bstack1l11llll_opy_.bstack11ll1ll11l1_opy_
      if bstack11ll1ll1l1l_opy_ is None:
        logger.debug(bstack1ll1lll_opy_ (u"ࠢࡈࡱࡲ࡫ࡱ࡫ࠠࡤࡪࡵࡳࡲ࡫ࠠࡰࡲࡷ࡭ࡴࡴࡳࠡࡣࡵࡩࠥࡔ࡯࡯ࡧࠥᜩ"))
        return bstack1l1llll1_opy_
      bstack11ll1lll1ll_opy_ = int(str(bstack11ll11lllll_opy_()).split(bstack1ll1lll_opy_ (u"ࠨ࠰ࠪᜪ"))[0])
      logger.debug(bstack1ll1lll_opy_ (u"ࠤࡖࡩࡱ࡫࡮ࡪࡷࡰࠤࡻ࡫ࡲࡴ࡫ࡲࡲࠥࡪࡥࡵࡧࡦࡸࡪࡪ࠺ࠡࠤᜫ") + str(bstack11ll1lll1ll_opy_) + bstack1ll1lll_opy_ (u"ࠥࠦᜬ"))
      if bstack11ll1lll1ll_opy_ == 3 and isinstance(bstack1l1llll1_opy_, dict) and bstack1ll1lll_opy_ (u"ࠫࡩ࡫ࡳࡪࡴࡨࡨࡤࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶࠫᜭ") in bstack1l1llll1_opy_ and bstack11ll1ll1l1l_opy_ is not None:
        if bstack1ll1lll_opy_ (u"ࠬ࡭࡯ࡰࡩ࠽ࡧ࡭ࡸ࡯࡮ࡧࡒࡴࡹ࡯࡯࡯ࡵࠪᜮ") not in bstack1l1llll1_opy_[bstack1ll1lll_opy_ (u"࠭ࡤࡦࡵ࡬ࡶࡪࡪ࡟ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸ࠭ᜯ")]:
          bstack1l1llll1_opy_[bstack1ll1lll_opy_ (u"ࠧࡥࡧࡶ࡭ࡷ࡫ࡤࡠࡥࡤࡴࡦࡨࡩ࡭࡫ࡷ࡭ࡪࡹࠧᜰ")][bstack1ll1lll_opy_ (u"ࠨࡩࡲࡳ࡬ࡀࡣࡩࡴࡲࡱࡪࡕࡰࡵ࡫ࡲࡲࡸ࠭ᜱ")] = {}
        if bstack1ll1lll_opy_ (u"ࠩࡤࡶ࡬ࡹࠧᜲ") in bstack11ll1ll1l1l_opy_:
          if bstack1ll1lll_opy_ (u"ࠪࡥࡷ࡭ࡳࠨᜳ") not in bstack1l1llll1_opy_[bstack1ll1lll_opy_ (u"ࠫࡩ࡫ࡳࡪࡴࡨࡨࡤࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶ᜴ࠫ")][bstack1ll1lll_opy_ (u"ࠬ࡭࡯ࡰࡩ࠽ࡧ࡭ࡸ࡯࡮ࡧࡒࡴࡹ࡯࡯࡯ࡵࠪ᜵")]:
            bstack1l1llll1_opy_[bstack1ll1lll_opy_ (u"࠭ࡤࡦࡵ࡬ࡶࡪࡪ࡟ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸ࠭᜶")][bstack1ll1lll_opy_ (u"ࠧࡨࡱࡲ࡫࠿ࡩࡨࡳࡱࡰࡩࡔࡶࡴࡪࡱࡱࡷࠬ᜷")][bstack1ll1lll_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭᜸")] = []
          for arg in bstack11ll1ll1l1l_opy_[bstack1ll1lll_opy_ (u"ࠩࡤࡶ࡬ࡹࠧ᜹")]:
            if arg not in bstack1l1llll1_opy_[bstack1ll1lll_opy_ (u"ࠪࡨࡪࡹࡩࡳࡧࡧࡣࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠪ᜺")][bstack1ll1lll_opy_ (u"ࠫ࡬ࡵ࡯ࡨ࠼ࡦ࡬ࡷࡵ࡭ࡦࡑࡳࡸ࡮ࡵ࡮ࡴࠩ᜻")][bstack1ll1lll_opy_ (u"ࠬࡧࡲࡨࡵࠪ᜼")]:
              bstack1l1llll1_opy_[bstack1ll1lll_opy_ (u"࠭ࡤࡦࡵ࡬ࡶࡪࡪ࡟ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸ࠭᜽")][bstack1ll1lll_opy_ (u"ࠧࡨࡱࡲ࡫࠿ࡩࡨࡳࡱࡰࡩࡔࡶࡴࡪࡱࡱࡷࠬ᜾")][bstack1ll1lll_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭᜿")].append(arg)
        if bstack1ll1lll_opy_ (u"ࠩࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࡸ࠭ᝀ") in bstack11ll1ll1l1l_opy_:
          if bstack1ll1lll_opy_ (u"ࠪࡩࡽࡺࡥ࡯ࡵ࡬ࡳࡳࡹࠧᝁ") not in bstack1l1llll1_opy_[bstack1ll1lll_opy_ (u"ࠫࡩ࡫ࡳࡪࡴࡨࡨࡤࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶࠫᝂ")][bstack1ll1lll_opy_ (u"ࠬ࡭࡯ࡰࡩ࠽ࡧ࡭ࡸ࡯࡮ࡧࡒࡴࡹ࡯࡯࡯ࡵࠪᝃ")]:
            bstack1l1llll1_opy_[bstack1ll1lll_opy_ (u"࠭ࡤࡦࡵ࡬ࡶࡪࡪ࡟ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸ࠭ᝄ")][bstack1ll1lll_opy_ (u"ࠧࡨࡱࡲ࡫࠿ࡩࡨࡳࡱࡰࡩࡔࡶࡴࡪࡱࡱࡷࠬᝅ")][bstack1ll1lll_opy_ (u"ࠨࡧࡻࡸࡪࡴࡳࡪࡱࡱࡷࠬᝆ")] = []
          for ext in bstack11ll1ll1l1l_opy_[bstack1ll1lll_opy_ (u"ࠩࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࡸ࠭ᝇ")]:
            if ext not in bstack1l1llll1_opy_[bstack1ll1lll_opy_ (u"ࠪࡨࡪࡹࡩࡳࡧࡧࡣࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠪᝈ")][bstack1ll1lll_opy_ (u"ࠫ࡬ࡵ࡯ࡨ࠼ࡦ࡬ࡷࡵ࡭ࡦࡑࡳࡸ࡮ࡵ࡮ࡴࠩᝉ")][bstack1ll1lll_opy_ (u"ࠬ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮ࡴࠩᝊ")]:
              bstack1l1llll1_opy_[bstack1ll1lll_opy_ (u"࠭ࡤࡦࡵ࡬ࡶࡪࡪ࡟ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸ࠭ᝋ")][bstack1ll1lll_opy_ (u"ࠧࡨࡱࡲ࡫࠿ࡩࡨࡳࡱࡰࡩࡔࡶࡴࡪࡱࡱࡷࠬᝌ")][bstack1ll1lll_opy_ (u"ࠨࡧࡻࡸࡪࡴࡳࡪࡱࡱࡷࠬᝍ")].append(ext)
        if bstack1ll1lll_opy_ (u"ࠩࡳࡶࡪ࡬ࡳࠨᝎ") in bstack11ll1ll1l1l_opy_:
          if bstack1ll1lll_opy_ (u"ࠪࡴࡷ࡫ࡦࡴࠩᝏ") not in bstack1l1llll1_opy_[bstack1ll1lll_opy_ (u"ࠫࡩ࡫ࡳࡪࡴࡨࡨࡤࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶࠫᝐ")][bstack1ll1lll_opy_ (u"ࠬ࡭࡯ࡰࡩ࠽ࡧ࡭ࡸ࡯࡮ࡧࡒࡴࡹ࡯࡯࡯ࡵࠪᝑ")]:
            bstack1l1llll1_opy_[bstack1ll1lll_opy_ (u"࠭ࡤࡦࡵ࡬ࡶࡪࡪ࡟ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸ࠭ᝒ")][bstack1ll1lll_opy_ (u"ࠧࡨࡱࡲ࡫࠿ࡩࡨࡳࡱࡰࡩࡔࡶࡴࡪࡱࡱࡷࠬᝓ")][bstack1ll1lll_opy_ (u"ࠨࡲࡵࡩ࡫ࡹࠧ᝔")] = {}
          bstack11ll11l1ll1_opy_(bstack1l1llll1_opy_[bstack1ll1lll_opy_ (u"ࠩࡧࡩࡸ࡯ࡲࡦࡦࡢࡧࡦࡶࡡࡣ࡫࡯࡭ࡹ࡯ࡥࡴࠩ᝕")][bstack1ll1lll_opy_ (u"ࠪ࡫ࡴࡵࡧ࠻ࡥ࡫ࡶࡴࡳࡥࡐࡲࡷ࡭ࡴࡴࡳࠨ᝖")][bstack1ll1lll_opy_ (u"ࠫࡵࡸࡥࡧࡵࠪ᝗")],
                    bstack11ll1ll1l1l_opy_[bstack1ll1lll_opy_ (u"ࠬࡶࡲࡦࡨࡶࠫ᝘")])
        os.environ[bstack1ll1lll_opy_ (u"࠭ࡉࡔࡡࡑࡓࡓࡥࡂࡔࡖࡄࡇࡐࡥࡉࡏࡈࡕࡅࡤࡇ࠱࠲࡛ࡢࡗࡊ࡙ࡓࡊࡑࡑࠫ᝙")] = bstack1ll1lll_opy_ (u"ࠧࡵࡴࡸࡩࠬ᝚")
        return bstack1l1llll1_opy_
      else:
        chrome_options = None
        if isinstance(bstack1l1llll1_opy_, ChromeOptions):
          chrome_options = bstack1l1llll1_opy_
        elif isinstance(bstack1l1llll1_opy_, dict):
          for value in bstack1l1llll1_opy_.values():
            if isinstance(value, ChromeOptions):
              chrome_options = value
              break
        if chrome_options is None:
          chrome_options = ChromeOptions()
          if isinstance(bstack1l1llll1_opy_, dict):
            bstack1l1llll1_opy_[bstack1ll1lll_opy_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮ࡴࠩ᝛")] = chrome_options
          else:
            bstack1l1llll1_opy_ = chrome_options
        if bstack11ll1ll1l1l_opy_ is not None:
          if bstack1ll1lll_opy_ (u"ࠩࡤࡶ࡬ࡹࠧ᝜") in bstack11ll1ll1l1l_opy_:
                bstack11ll11l11ll_opy_ = chrome_options.arguments or []
                new_args = bstack11ll1ll1l1l_opy_[bstack1ll1lll_opy_ (u"ࠪࡥࡷ࡭ࡳࠨ᝝")]
                for arg in new_args:
                    if arg not in bstack11ll11l11ll_opy_:
                        chrome_options.add_argument(arg)
          if bstack1ll1lll_opy_ (u"ࠫࡪࡾࡴࡦࡰࡶ࡭ࡴࡴࡳࠨ᝞") in bstack11ll1ll1l1l_opy_:
                existing_extensions = chrome_options.experimental_options.get(bstack1ll1lll_opy_ (u"ࠬ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮ࡴࠩ᝟"), [])
                bstack11ll11ll111_opy_ = bstack11ll1ll1l1l_opy_[bstack1ll1lll_opy_ (u"࠭ࡥࡹࡶࡨࡲࡸ࡯࡯࡯ࡵࠪᝠ")]
                for extension in bstack11ll11ll111_opy_:
                    if extension not in existing_extensions:
                        chrome_options.add_encoded_extension(extension)
          if bstack1ll1lll_opy_ (u"ࠧࡱࡴࡨࡪࡸ࠭ᝡ") in bstack11ll1ll1l1l_opy_:
                bstack11ll1lll111_opy_ = chrome_options.experimental_options.get(bstack1ll1lll_opy_ (u"ࠨࡲࡵࡩ࡫ࡹࠧᝢ"), {})
                bstack11ll11lll11_opy_ = bstack11ll1ll1l1l_opy_[bstack1ll1lll_opy_ (u"ࠩࡳࡶࡪ࡬ࡳࠨᝣ")]
                bstack11ll11l1ll1_opy_(bstack11ll1lll111_opy_, bstack11ll11lll11_opy_)
                chrome_options.add_experimental_option(bstack1ll1lll_opy_ (u"ࠪࡴࡷ࡫ࡦࡴࠩᝤ"), bstack11ll1lll111_opy_)
        os.environ[bstack1ll1lll_opy_ (u"ࠫࡎ࡙࡟ࡏࡑࡑࡣࡇ࡙ࡔࡂࡅࡎࡣࡎࡔࡆࡓࡃࡢࡅ࠶࠷࡙ࡠࡕࡈࡗࡘࡏࡏࡏࠩᝥ")] = bstack1ll1lll_opy_ (u"ࠬࡺࡲࡶࡧࠪᝦ")
        return bstack1l1llll1_opy_
    except Exception as e:
      logger.error(bstack1ll1lll_opy_ (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡨࡪ࡮ࡨࠤࡦࡪࡤࡪࡰࡪࠤࡳࡵ࡮࠮ࡄࡖࠤ࡮ࡴࡦࡳࡣࠣࡥ࠶࠷ࡹࠡࡥ࡫ࡶࡴࡳࡥࠡࡱࡳࡸ࡮ࡵ࡮ࡴ࠼ࠣࠦᝧ") + str(e))
      return bstack1l1llll1_opy_