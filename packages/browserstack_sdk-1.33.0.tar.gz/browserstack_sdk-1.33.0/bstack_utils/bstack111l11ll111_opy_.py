# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import os
import time
from bstack_utils.bstack11ll11111l1_opy_ import bstack11ll111l111_opy_
from bstack_utils.constants import bstack11l1l1l1l1l_opy_
from bstack_utils.helper import get_host_info, bstack11l11l11l11_opy_
class bstack111l111lll1_opy_:
    bstack1ll1lll_opy_ (u"ࠨࠢࠣࠌࠣࠤࠥࠦࡈࡢࡰࡧࡰࡪࡹࠠࡵࡧࡶࡸࠥࡵࡲࡥࡧࡵ࡭ࡳ࡭ࠠࡰࡴࡦ࡬ࡪࡹࡴࡳࡣࡷ࡭ࡴࡴࠠࡸ࡫ࡷ࡬ࠥࡺࡨࡦࠢࡅࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࠡࡵࡨࡶࡻ࡫ࡲ࠯ࠌࠣࠤࠥࠦࠢࠣࠤ€")
    def __init__(self, config, logger):
        bstack1ll1lll_opy_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡨࡵ࡮ࡧ࡫ࡪ࠾ࠥࡪࡩࡤࡶ࠯ࠤࡹ࡫ࡳࡵࠢࡲࡶࡨ࡮ࡥࡴࡶࡵࡥࡹ࡯࡯࡯ࠢࡦࡳࡳ࡬ࡩࡨࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡳࡷࡩࡨࡦࡵࡷࡶࡦࡺࡩࡰࡰࡢࡷࡹࡸࡡࡵࡧࡪࡽ࠿ࠦࡳࡵࡴ࠯ࠤࡹ࡫ࡳࡵࠢࡲࡶࡩ࡫ࡲࡪࡰࡪࠤࡸࡺࡲࡢࡶࡨ࡫ࡾࠦ࡮ࡢ࡯ࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣ₭")
        self.config = config
        self.logger = logger
        self.bstack1llll1l1llll_opy_ = bstack1ll1lll_opy_ (u"ࠣࡶࡨࡷࡹࡵࡲࡤࡪࡨࡷࡹࡸࡡࡵ࡫ࡲࡲ࠴ࡧࡰࡪ࠱ࡹ࠵࠴ࡹࡰ࡭࡫ࡷ࠱ࡹ࡫ࡳࡵࡵࠥ₮")
        self.bstack1llll1l11ll1_opy_ = None
        self.bstack1llll1ll11ll_opy_ = 60
        self.bstack1llll1l1lll1_opy_ = 5
        self.bstack1llll1l1l111_opy_ = 0
    def bstack111l111ll1l_opy_(self, test_files, orchestration_strategy, bstack1lll111l1l1_opy_={}):
        bstack1ll1lll_opy_ (u"ࠤࠥࠦࠏࠦࠠࠡࠢࠣࠤࠥࠦࡉ࡯࡫ࡷ࡭ࡦࡺࡥࡴࠢࡷ࡬ࡪࠦࡳࡱ࡮࡬ࡸࠥࡺࡥࡴࡶࡶࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡧ࡮ࡥࠢࡶࡸࡴࡸࡥࡴࠢࡷ࡬ࡪࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡࡦࡤࡸࡦࠦࡦࡰࡴࠣࡴࡴࡲ࡬ࡪࡰࡪ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤ₯")
        self.logger.debug(bstack1ll1lll_opy_ (u"ࠥ࡟ࡸࡶ࡬ࡪࡶࡗࡩࡸࡺࡳ࡞ࠢࡌࡲ࡮ࡺࡩࡢࡶ࡬ࡲ࡬ࠦࡳࡱ࡮࡬ࡸࠥࡺࡥࡴࡶࡶࠤࡼ࡯ࡴࡩࠢࡶࡸࡷࡧࡴࡦࡩࡼ࠾ࠥࢁࡽࠣ₰").format(orchestration_strategy))
        try:
            bstack1llll1l1ll11_opy_ = []
            bstack1ll1lll_opy_ (u"ࠦࠧࠨࡗࡦࠢࡺ࡭ࡱࡲࠠ࡯ࡱࡷࠤ࡫࡫ࡴࡤࡪࠣ࡫࡮ࡺࠠ࡮ࡧࡷࡥࡩࡧࡴࡢࠢ࡬ࡷࠥࡹ࡯ࡶࡴࡦࡩࠥ࡯ࡳࠡࡶࡼࡴࡪࠦ࡯ࡧࠢࡤࡶࡷࡧࡹࠡࡣࡱࡨࠥ࡯ࡴࠨࡵࠣࡩࡱ࡫࡭ࡦࡰࡷࡷࠥࡧࡲࡦࠢࡲࡪࠥࡺࡹࡱࡧࠣࡨ࡮ࡩࡴࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡪࡰࠣࡸ࡭ࡧࡴࠡࡥࡤࡷࡪ࠲ࠠࡶࡵࡨࡶࠥ࡮ࡡࡴࠢࡳࡶࡴࡼࡩࡥࡧࡧࠤࡲࡻ࡬ࡵ࡫࠰ࡶࡪࡶ࡯ࠡࡵࡲࡹࡷࡩࡥࠡࡹ࡬ࡸ࡭ࠦࡦࡦࡣࡷࡹࡷ࡫ࡂࡳࡣࡱࡧ࡭ࠦࡩ࡯ࠢࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠣࠤࠥ₱")
            source = bstack1lll111l1l1_opy_[bstack1ll1lll_opy_ (u"ࠬࡸࡵ࡯ࡡࡶࡱࡦࡸࡴࡠࡵࡨࡰࡪࡩࡴࡪࡱࡱࠫ₲")].get(bstack1ll1lll_opy_ (u"࠭ࡳࡰࡷࡵࡧࡪ࠭₳"), [])
            bstack1llll1ll111l_opy_ = isinstance(source, list) and all(isinstance(src, dict) and src is not None for src in source) and len(source) > 0
            if bstack1lll111l1l1_opy_[bstack1ll1lll_opy_ (u"ࠧࡳࡷࡱࡣࡸࡳࡡࡳࡶࡢࡷࡪࡲࡥࡤࡶ࡬ࡳࡳ࠭₴")].get(bstack1ll1lll_opy_ (u"ࠨࡧࡱࡥࡧࡲࡥࡥࠩ₵"), False) and not bstack1llll1ll111l_opy_:
                bstack1llll1l1ll11_opy_ = bstack11l11l11l11_opy_(source) # bstack11l11111ll1_opy_-repo is handled bstack1llll1ll11l1_opy_
            payload = {
                bstack1ll1lll_opy_ (u"ࠤࡷࡩࡸࡺࡳࠣ₶"): [{bstack1ll1lll_opy_ (u"ࠥࡪ࡮ࡲࡥࡑࡣࡷ࡬ࠧ₷"): f} for f in test_files],
                bstack1ll1lll_opy_ (u"ࠦࡴࡸࡣࡩࡧࡶࡸࡷࡧࡴࡪࡱࡱࡗࡹࡸࡡࡵࡧࡪࡽࠧ₸"): orchestration_strategy,
                bstack1ll1lll_opy_ (u"ࠧࡵࡲࡤࡪࡨࡷࡹࡸࡡࡵ࡫ࡲࡲࡒ࡫ࡴࡢࡦࡤࡸࡦࠨ₹"): bstack1lll111l1l1_opy_,
                bstack1ll1lll_opy_ (u"ࠨ࡮ࡰࡦࡨࡍࡳࡪࡥࡹࠤ₺"): int(os.environ.get(bstack1ll1lll_opy_ (u"ࠢࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡎࡐࡆࡈࡣࡎࡔࡄࡆ࡚ࠥ₻")) or bstack1ll1lll_opy_ (u"ࠣ࠲ࠥ₼")),
                bstack1ll1lll_opy_ (u"ࠤࡷࡳࡹࡧ࡬ࡏࡱࡧࡩࡸࠨ₽"): int(os.environ.get(bstack1ll1lll_opy_ (u"ࠥࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡓ࡙ࡇࡌࡠࡐࡒࡈࡊࡥࡃࡐࡗࡑࡘࠧ₾")) or bstack1ll1lll_opy_ (u"ࠦ࠶ࠨ₿")),
                bstack1ll1lll_opy_ (u"ࠧࡶࡲࡰ࡬ࡨࡧࡹࡔࡡ࡮ࡧࠥ⃀"): self.config.get(bstack1ll1lll_opy_ (u"࠭ࡰࡳࡱ࡭ࡩࡨࡺࡎࡢ࡯ࡨࠫ⃁"), bstack1ll1lll_opy_ (u"ࠧࠨ⃂")),
                bstack1ll1lll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠦ⃃"): self.config.get(bstack1ll1lll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬ⃄"), os.path.basename(os.path.abspath(os.getcwd()))),
                bstack1ll1lll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡔࡸࡲࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠣ⃅"): os.environ.get(bstack1ll1lll_opy_ (u"ࠦࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡆ࡚ࡏࡌࡅࡡࡕ࡙ࡓࡥࡉࡅࡇࡑࡘࡎࡌࡉࡆࡔࠥ⃆"), bstack1ll1lll_opy_ (u"ࠧࠨ⃇")),
                bstack1ll1lll_opy_ (u"ࠨࡨࡰࡵࡷࡍࡳ࡬࡯ࠣ⃈"): get_host_info(),
                bstack1ll1lll_opy_ (u"ࠢࡱࡴࡇࡩࡹࡧࡩ࡭ࡵࠥ⃉"): bstack1llll1l1ll11_opy_
            }
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠣ࡝ࡶࡴࡱ࡯ࡴࡕࡧࡶࡸࡸࡣࠠࡔࡧࡱࡨ࡮ࡴࡧࠡࡶࡨࡷࡹࠦࡦࡪ࡮ࡨࡷ࠿ࠦࡻࡾࠤ⃊").format(payload))
            response = bstack11ll111l111_opy_.bstack1lllll1l111l_opy_(self.bstack1llll1l1llll_opy_, payload)
            if response:
                self.bstack1llll1l11ll1_opy_ = self._1llll1l11l1l_opy_(response)
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠤ࡞ࡷࡵࡲࡩࡵࡖࡨࡷࡹࡹ࡝ࠡࡕࡳࡰ࡮ࡺࠠࡵࡧࡶࡸࡸࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠻ࠢࡾࢁࠧ⃋").format(self.bstack1llll1l11ll1_opy_))
            else:
                self.logger.error(bstack1ll1lll_opy_ (u"ࠥ࡟ࡸࡶ࡬ࡪࡶࡗࡩࡸࡺࡳ࡞ࠢࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥ࡭ࡥࡵࠢࡶࡴࡱ࡯ࡴࠡࡶࡨࡷࡹࡹࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࠥ⃌"))
        except Exception as e:
            self.logger.error(bstack1ll1lll_opy_ (u"ࠦࡠࡹࡰ࡭࡫ࡷࡘࡪࡹࡴࡴ࡟ࠣࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡶࡩࡳࡪࡩ࡯ࡩࠣࡸࡪࡹࡴࠡࡨ࡬ࡰࡪࡹ࠺࠻ࠢࡾࢁࠧ⃍").format(e))
    def _1llll1l11l1l_opy_(self, response):
        bstack1ll1lll_opy_ (u"ࠧࠨࠢࠋࠢࠣࠤࠥࠦࠠࠡࠢࡓࡶࡴࡩࡥࡴࡵࡨࡷࠥࡺࡨࡦࠢࡶࡴࡱ࡯ࡴࠡࡶࡨࡷࡹࡹࠠࡂࡒࡌࠤࡷ࡫ࡳࡱࡱࡱࡷࡪࠦࡡ࡯ࡦࠣࡩࡽࡺࡲࡢࡥࡷࡷࠥࡸࡥ࡭ࡧࡹࡥࡳࡺࠠࡧ࡫ࡨࡰࡩࡹ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ⃎")
        bstack1l111111l_opy_ = {}
        bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠨࡴࡪ࡯ࡨࡳࡺࡺࠢ⃏")] = response.get(bstack1ll1lll_opy_ (u"ࠢࡵ࡫ࡰࡩࡴࡻࡴࠣ⃐"), self.bstack1llll1ll11ll_opy_)
        bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠣࡶ࡬ࡱࡪࡵࡵࡵࡋࡱࡸࡪࡸࡶࡢ࡮ࠥ⃑")] = response.get(bstack1ll1lll_opy_ (u"ࠤࡷ࡭ࡲ࡫࡯ࡶࡶࡌࡲࡹ࡫ࡲࡷࡣ࡯⃒ࠦ"), self.bstack1llll1l1lll1_opy_)
        bstack1llll1ll1111_opy_ = response.get(bstack1ll1lll_opy_ (u"ࠥࡶࡪࡹࡵ࡭ࡶࡘࡶࡱࠨ⃓"))
        bstack1llll1l11l11_opy_ = response.get(bstack1ll1lll_opy_ (u"ࠦࡹ࡯࡭ࡦࡱࡸࡸ࡚ࡸ࡬ࠣ⃔"))
        if bstack1llll1ll1111_opy_:
            bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠧࡸࡥࡴࡷ࡯ࡸ࡚ࡸ࡬ࠣ⃕")] = bstack1llll1ll1111_opy_.split(bstack11l1l1l1l1l_opy_ + bstack1ll1lll_opy_ (u"ࠨ࠯ࠣ⃖"))[1] if bstack11l1l1l1l1l_opy_ + bstack1ll1lll_opy_ (u"ࠢ࠰ࠤ⃗") in bstack1llll1ll1111_opy_ else bstack1llll1ll1111_opy_
        else:
            bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠣࡴࡨࡷࡺࡲࡴࡖࡴ࡯⃘ࠦ")] = None
        if bstack1llll1l11l11_opy_:
            bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠤࡷ࡭ࡲ࡫࡯ࡶࡶࡘࡶࡱࠨ⃙")] = bstack1llll1l11l11_opy_.split(bstack11l1l1l1l1l_opy_ + bstack1ll1lll_opy_ (u"ࠥ࠳⃚ࠧ"))[1] if bstack11l1l1l1l1l_opy_ + bstack1ll1lll_opy_ (u"ࠦ࠴ࠨ⃛") in bstack1llll1l11l11_opy_ else bstack1llll1l11l11_opy_
        else:
            bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠧࡺࡩ࡮ࡧࡲࡹࡹ࡛ࡲ࡭ࠤ⃜")] = None
        if (
            response.get(bstack1ll1lll_opy_ (u"ࠨࡴࡪ࡯ࡨࡳࡺࡺࠢ⃝")) is None or
            response.get(bstack1ll1lll_opy_ (u"ࠢࡵ࡫ࡰࡩࡴࡻࡴࡊࡰࡷࡩࡷࡼࡡ࡭ࠤ⃞")) is None or
            response.get(bstack1ll1lll_opy_ (u"ࠣࡶ࡬ࡱࡪࡵࡵࡵࡗࡵࡰࠧ⃟")) is None or
            response.get(bstack1ll1lll_opy_ (u"ࠤࡵࡩࡸࡻ࡬ࡵࡗࡵࡰࠧ⃠")) is None
        ):
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠥ࡟ࡵࡸ࡯ࡤࡧࡶࡷࡤࡹࡰ࡭࡫ࡷࡣࡹ࡫ࡳࡵࡵࡢࡶࡪࡹࡰࡰࡰࡶࡩࡢࠦࡒࡦࡥࡨ࡭ࡻ࡫ࡤࠡࡰࡸࡰࡱࠦࡶࡢ࡮ࡸࡩ࠭ࡹࠩࠡࡨࡲࡶࠥࡹ࡯࡮ࡧࠣࡥࡹࡺࡲࡪࡤࡸࡸࡪࡹࠠࡪࡰࠣࡷࡵࡲࡩࡵࠢࡷࡩࡸࡺࡳࠡࡃࡓࡍࠥࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ⃡"))
        return bstack1l111111l_opy_
    def bstack111l11l1ll1_opy_(self):
        if not self.bstack1llll1l11ll1_opy_:
            self.logger.error(bstack1ll1lll_opy_ (u"ࠦࡠ࡭ࡥࡵࡑࡵࡨࡪࡸࡥࡥࡖࡨࡷࡹࡌࡩ࡭ࡧࡶࡡࠥࡔ࡯ࠡࡴࡨࡵࡺ࡫ࡳࡵࠢࡧࡥࡹࡧࠠࡢࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡸࡴࠦࡦࡦࡶࡦ࡬ࠥࡵࡲࡥࡧࡵࡩࡩࠦࡴࡦࡵࡷࠤ࡫࡯࡬ࡦࡵ࠱ࠦ⃢"))
            return None
        bstack1llll1l1l11l_opy_ = None
        test_files = []
        bstack1llll1l1l1ll_opy_ = int(time.time() * 1000) # bstack1llll1l11lll_opy_ sec
        bstack1llll1l1l1l1_opy_ = int(self.bstack1llll1l11ll1_opy_.get(bstack1ll1lll_opy_ (u"ࠧࡺࡩ࡮ࡧࡲࡹࡹࡏ࡮ࡵࡧࡵࡺࡦࡲࠢ⃣"), self.bstack1llll1l1lll1_opy_))
        bstack1llll1l1ll1l_opy_ = int(self.bstack1llll1l11ll1_opy_.get(bstack1ll1lll_opy_ (u"ࠨࡴࡪ࡯ࡨࡳࡺࡺࠢ⃤"), self.bstack1llll1ll11ll_opy_)) * 1000
        bstack1llll1l11l11_opy_ = self.bstack1llll1l11ll1_opy_.get(bstack1ll1lll_opy_ (u"ࠢࡵ࡫ࡰࡩࡴࡻࡴࡖࡴ࡯⃥ࠦ"), None)
        bstack1llll1ll1111_opy_ = self.bstack1llll1l11ll1_opy_.get(bstack1ll1lll_opy_ (u"ࠣࡴࡨࡷࡺࡲࡴࡖࡴ࡯⃦ࠦ"), None)
        if bstack1llll1ll1111_opy_ is None and bstack1llll1l11l11_opy_ is None:
            return None
        try:
            while bstack1llll1ll1111_opy_ and (time.time() * 1000 - bstack1llll1l1l1ll_opy_) < bstack1llll1l1ll1l_opy_:
                response = bstack11ll111l111_opy_.bstack1lllll1l1ll1_opy_(bstack1llll1ll1111_opy_, {})
                if response and response.get(bstack1ll1lll_opy_ (u"ࠤࡷࡩࡸࡺࡳࠣ⃧")):
                    bstack1llll1l1l11l_opy_ = response.get(bstack1ll1lll_opy_ (u"ࠥࡸࡪࡹࡴࡴࠤ⃨"))
                self.bstack1llll1l1l111_opy_ += 1
                if bstack1llll1l1l11l_opy_:
                    break
                time.sleep(bstack1llll1l1l1l1_opy_)
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠦࡠ࡭ࡥࡵࡑࡵࡨࡪࡸࡥࡥࡖࡨࡷࡹࡌࡩ࡭ࡧࡶࡡࠥࡌࡥࡵࡥ࡫࡭ࡳ࡭ࠠࡰࡴࡧࡩࡷ࡫ࡤࠡࡶࡨࡷࡹࡹࠠࡧࡴࡲࡱࠥࡸࡥࡴࡷ࡯ࡸ࡛ࠥࡒࡍࠢࡤࡪࡹ࡫ࡲࠡࡹࡤ࡭ࡹ࡯࡮ࡨࠢࡩࡳࡷࠦࡻࡾࠢࡶࡩࡨࡵ࡮ࡥࡵ࠱ࠦ⃩").format(bstack1llll1l1l1l1_opy_))
            if bstack1llll1l11l11_opy_ and not bstack1llll1l1l11l_opy_:
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠧࡡࡧࡦࡶࡒࡶࡩ࡫ࡲࡦࡦࡗࡩࡸࡺࡆࡪ࡮ࡨࡷࡢࠦࡆࡦࡶࡦ࡬࡮ࡴࡧࠡࡱࡵࡨࡪࡸࡥࡥࠢࡷࡩࡸࡺࡳࠡࡨࡵࡳࡲࠦࡴࡪ࡯ࡨࡳࡺࡺࠠࡖࡔࡏ⃪ࠦ"))
                response = bstack11ll111l111_opy_.bstack1lllll1l1ll1_opy_(bstack1llll1l11l11_opy_, {})
                if response and response.get(bstack1ll1lll_opy_ (u"ࠨࡴࡦࡵࡷࡷ⃫ࠧ")):
                    bstack1llll1l1l11l_opy_ = response.get(bstack1ll1lll_opy_ (u"ࠢࡵࡧࡶࡸࡸࠨ⃬"))
            if bstack1llll1l1l11l_opy_ and len(bstack1llll1l1l11l_opy_) > 0:
                for bstack111ll1l1ll_opy_ in bstack1llll1l1l11l_opy_:
                    file_path = bstack111ll1l1ll_opy_.get(bstack1ll1lll_opy_ (u"ࠣࡨ࡬ࡰࡪࡖࡡࡵࡪ⃭ࠥ"))
                    if file_path:
                        test_files.append(file_path)
            if not bstack1llll1l1l11l_opy_:
                return None
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠤ࡞࡫ࡪࡺࡏࡳࡦࡨࡶࡪࡪࡔࡦࡵࡷࡊ࡮ࡲࡥࡴ࡟ࠣࡓࡷࡪࡥࡳࡧࡧࠤࡹ࡫ࡳࡵࠢࡩ࡭ࡱ࡫ࡳࠡࡴࡨࡧࡪ࡯ࡶࡦࡦ࠽ࠤࢀࢃ⃮ࠢ").format(test_files))
            return test_files
        except Exception as e:
            self.logger.error(bstack1ll1lll_opy_ (u"ࠥ࡟࡬࡫ࡴࡐࡴࡧࡩࡷ࡫ࡤࡕࡧࡶࡸࡋ࡯࡬ࡦࡵࡠࠤࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡪࡪࡺࡣࡩ࡫ࡱ࡫ࠥࡵࡲࡥࡧࡵࡩࡩࠦࡴࡦࡵࡷࠤ࡫࡯࡬ࡦࡵ࠽ࠤࢀࢃ⃯ࠢ").format(e))
            return None
    def bstack111l111ll11_opy_(self):
        bstack1ll1lll_opy_ (u"ࠦࠧࠨࠊࠡࠢࠣࠤࠥࠦࠠࠡࡔࡨࡸࡺࡸ࡮ࡴࠢࡷ࡬ࡪࠦࡣࡰࡷࡱࡸࠥࡵࡦࠡࡵࡳࡰ࡮ࡺࠠࡵࡧࡶࡸࡸࠦࡁࡑࡋࠣࡧࡦࡲ࡬ࡴࠢࡰࡥࡩ࡫࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ⃰")
        return self.bstack1llll1l1l111_opy_