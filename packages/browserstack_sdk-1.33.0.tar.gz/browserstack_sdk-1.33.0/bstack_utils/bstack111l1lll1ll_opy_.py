# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
from _pytest import fixtures
from _pytest.python import _call_with_optional_argument
from pytest import Module, Class
from bstack_utils.helper import Result, bstack11l11l1l11l_opy_
from browserstack_sdk.bstack1lll1ll111_opy_ import bstack11lll1l111_opy_
def _111ll11111l_opy_(method, this, arg):
    arg_count = method.__code__.co_argcount
    if arg_count > 1:
        method(this, arg)
    else:
        method(this)
class bstack111ll111l11_opy_:
    def __init__(self, handler):
        self._111l1lll1l1_opy_ = {}
        self._111l1lllll1_opy_ = {}
        self.handler = handler
        self.patch()
        pass
    def patch(self):
        pytest_version = bstack11lll1l111_opy_.version()
        if bstack11l11l1l11l_opy_(pytest_version, bstack1ll1lll_opy_ (u"ࠦ࠽࠴࠱࠯࠳ࠥᶡ")) >= 0:
            self._111l1lll1l1_opy_[bstack1ll1lll_opy_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡟ࡧ࡫ࡻࡸࡺࡸࡥࠨᶢ")] = Module._register_setup_function_fixture
            self._111l1lll1l1_opy_[bstack1ll1lll_opy_ (u"࠭࡭ࡰࡦࡸࡰࡪࡥࡦࡪࡺࡷࡹࡷ࡫ࠧᶣ")] = Module._register_setup_module_fixture
            self._111l1lll1l1_opy_[bstack1ll1lll_opy_ (u"ࠧࡤ࡮ࡤࡷࡸࡥࡦࡪࡺࡷࡹࡷ࡫ࠧᶤ")] = Class._register_setup_class_fixture
            self._111l1lll1l1_opy_[bstack1ll1lll_opy_ (u"ࠨ࡯ࡨࡸ࡭ࡵࡤࡠࡨ࡬ࡼࡹࡻࡲࡦࠩᶥ")] = Class._register_setup_method_fixture
            Module._register_setup_function_fixture = self.bstack111l1llll1l_opy_(bstack1ll1lll_opy_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࡣ࡫࡯ࡸࡵࡷࡵࡩࠬᶦ"))
            Module._register_setup_module_fixture = self.bstack111l1llll1l_opy_(bstack1ll1lll_opy_ (u"ࠪࡱࡴࡪࡵ࡭ࡧࡢࡪ࡮ࡾࡴࡶࡴࡨࠫᶧ"))
            Class._register_setup_class_fixture = self.bstack111l1llll1l_opy_(bstack1ll1lll_opy_ (u"ࠫࡨࡲࡡࡴࡵࡢࡪ࡮ࡾࡴࡶࡴࡨࠫᶨ"))
            Class._register_setup_method_fixture = self.bstack111l1llll1l_opy_(bstack1ll1lll_opy_ (u"ࠬࡳࡥࡵࡪࡲࡨࡤ࡬ࡩࡹࡶࡸࡶࡪ࠭ᶩ"))
        else:
            self._111l1lll1l1_opy_[bstack1ll1lll_opy_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࡠࡨ࡬ࡼࡹࡻࡲࡦࠩᶪ")] = Module._inject_setup_function_fixture
            self._111l1lll1l1_opy_[bstack1ll1lll_opy_ (u"ࠧ࡮ࡱࡧࡹࡱ࡫࡟ࡧ࡫ࡻࡸࡺࡸࡥࠨᶫ")] = Module._inject_setup_module_fixture
            self._111l1lll1l1_opy_[bstack1ll1lll_opy_ (u"ࠨࡥ࡯ࡥࡸࡹ࡟ࡧ࡫ࡻࡸࡺࡸࡥࠨᶬ")] = Class._inject_setup_class_fixture
            self._111l1lll1l1_opy_[bstack1ll1lll_opy_ (u"ࠩࡰࡩࡹ࡮࡯ࡥࡡࡩ࡭ࡽࡺࡵࡳࡧࠪᶭ")] = Class._inject_setup_method_fixture
            Module._inject_setup_function_fixture = self.bstack111l1llll1l_opy_(bstack1ll1lll_opy_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࡤ࡬ࡩࡹࡶࡸࡶࡪ࠭ᶮ"))
            Module._inject_setup_module_fixture = self.bstack111l1llll1l_opy_(bstack1ll1lll_opy_ (u"ࠫࡲࡵࡤࡶ࡮ࡨࡣ࡫࡯ࡸࡵࡷࡵࡩࠬᶯ"))
            Class._inject_setup_class_fixture = self.bstack111l1llll1l_opy_(bstack1ll1lll_opy_ (u"ࠬࡩ࡬ࡢࡵࡶࡣ࡫࡯ࡸࡵࡷࡵࡩࠬᶰ"))
            Class._inject_setup_method_fixture = self.bstack111l1llll1l_opy_(bstack1ll1lll_opy_ (u"࠭࡭ࡦࡶ࡫ࡳࡩࡥࡦࡪࡺࡷࡹࡷ࡫ࠧᶱ"))
    def bstack111l1llll11_opy_(self, bstack111l1lll11l_opy_, hook_type):
        bstack111l1lll111_opy_ = id(bstack111l1lll11l_opy_.__class__)
        if (bstack111l1lll111_opy_, hook_type) in self._111l1lllll1_opy_:
            return
        meth = getattr(bstack111l1lll11l_opy_, hook_type, None)
        if meth is not None and fixtures.getfixturemarker(meth) is None:
            self._111l1lllll1_opy_[(bstack111l1lll111_opy_, hook_type)] = meth
            setattr(bstack111l1lll11l_opy_, hook_type, self.bstack111l1ll1ll1_opy_(hook_type, bstack111l1lll111_opy_))
    def bstack111l1ll1lll_opy_(self, instance, bstack111ll111111_opy_):
        if bstack111ll111111_opy_ == bstack1ll1lll_opy_ (u"ࠢࡧࡷࡱࡧࡹ࡯࡯࡯ࡡࡩ࡭ࡽࡺࡵࡳࡧࠥᶲ"):
            self.bstack111l1llll11_opy_(instance.obj, bstack1ll1lll_opy_ (u"ࠣࡵࡨࡸࡺࡶ࡟ࡧࡷࡱࡧࡹ࡯࡯࡯ࠤᶳ"))
            self.bstack111l1llll11_opy_(instance.obj, bstack1ll1lll_opy_ (u"ࠤࡷࡩࡦࡸࡤࡰࡹࡱࡣ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠨᶴ"))
        if bstack111ll111111_opy_ == bstack1ll1lll_opy_ (u"ࠥࡱࡴࡪࡵ࡭ࡧࡢࡪ࡮ࡾࡴࡶࡴࡨࠦᶵ"):
            self.bstack111l1llll11_opy_(instance.obj, bstack1ll1lll_opy_ (u"ࠦࡸ࡫ࡴࡶࡲࡢࡱࡴࡪࡵ࡭ࡧࠥᶶ"))
            self.bstack111l1llll11_opy_(instance.obj, bstack1ll1lll_opy_ (u"ࠧࡺࡥࡢࡴࡧࡳࡼࡴ࡟࡮ࡱࡧࡹࡱ࡫ࠢᶷ"))
        if bstack111ll111111_opy_ == bstack1ll1lll_opy_ (u"ࠨࡣ࡭ࡣࡶࡷࡤ࡬ࡩࡹࡶࡸࡶࡪࠨᶸ"):
            self.bstack111l1llll11_opy_(instance.obj, bstack1ll1lll_opy_ (u"ࠢࡴࡧࡷࡹࡵࡥࡣ࡭ࡣࡶࡷࠧᶹ"))
            self.bstack111l1llll11_opy_(instance.obj, bstack1ll1lll_opy_ (u"ࠣࡶࡨࡥࡷࡪ࡯ࡸࡰࡢࡧࡱࡧࡳࡴࠤᶺ"))
        if bstack111ll111111_opy_ == bstack1ll1lll_opy_ (u"ࠤࡰࡩࡹ࡮࡯ࡥࡡࡩ࡭ࡽࡺࡵࡳࡧࠥᶻ"):
            self.bstack111l1llll11_opy_(instance.obj, bstack1ll1lll_opy_ (u"ࠥࡷࡪࡺࡵࡱࡡࡰࡩࡹ࡮࡯ࡥࠤᶼ"))
            self.bstack111l1llll11_opy_(instance.obj, bstack1ll1lll_opy_ (u"ࠦࡹ࡫ࡡࡳࡦࡲࡻࡳࡥ࡭ࡦࡶ࡫ࡳࡩࠨᶽ"))
    @staticmethod
    def bstack111ll1111l1_opy_(hook_type, func, args):
        if hook_type in [bstack1ll1lll_opy_ (u"ࠬࡹࡥࡵࡷࡳࡣࡲ࡫ࡴࡩࡱࡧࠫᶾ"), bstack1ll1lll_opy_ (u"࠭ࡴࡦࡣࡵࡨࡴࡽ࡮ࡠ࡯ࡨࡸ࡭ࡵࡤࠨᶿ")]:
            _111ll11111l_opy_(func, args[0], args[1])
            return
        _call_with_optional_argument(func, args[0])
    def bstack111l1ll1ll1_opy_(self, hook_type, bstack111l1lll111_opy_):
        def bstack111l1llllll_opy_(arg=None):
            self.handler(hook_type, bstack1ll1lll_opy_ (u"ࠧࡣࡧࡩࡳࡷ࡫ࠧ᷀"))
            result = None
            try:
                bstack1llllll11l1_opy_ = self._111l1lllll1_opy_[(bstack111l1lll111_opy_, hook_type)]
                self.bstack111ll1111l1_opy_(hook_type, bstack1llllll11l1_opy_, (arg,))
                result = Result(result=bstack1ll1lll_opy_ (u"ࠨࡲࡤࡷࡸ࡫ࡤࠨ᷁"))
            except Exception as e:
                result = Result(result=bstack1ll1lll_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥ᷂ࠩ"), exception=e)
                self.handler(hook_type, bstack1ll1lll_opy_ (u"ࠪࡥ࡫ࡺࡥࡳࠩ᷃"), result)
                raise e.with_traceback(e.__traceback__)
            self.handler(hook_type, bstack1ll1lll_opy_ (u"ࠫࡦ࡬ࡴࡦࡴࠪ᷄"), result)
        def bstack111ll1111ll_opy_(this, arg=None):
            self.handler(hook_type, bstack1ll1lll_opy_ (u"ࠬࡨࡥࡧࡱࡵࡩࠬ᷅"))
            result = None
            exception = None
            try:
                self.bstack111ll1111l1_opy_(hook_type, self._111l1lllll1_opy_[hook_type], (this, arg))
                result = Result(result=bstack1ll1lll_opy_ (u"࠭ࡰࡢࡵࡶࡩࡩ࠭᷆"))
            except Exception as e:
                result = Result(result=bstack1ll1lll_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ᷇"), exception=e)
                self.handler(hook_type, bstack1ll1lll_opy_ (u"ࠨࡣࡩࡸࡪࡸࠧ᷈"), result)
                raise e.with_traceback(e.__traceback__)
            self.handler(hook_type, bstack1ll1lll_opy_ (u"ࠩࡤࡪࡹ࡫ࡲࠨ᷉"), result)
        if hook_type in [bstack1ll1lll_opy_ (u"ࠪࡷࡪࡺࡵࡱࡡࡰࡩࡹ࡮࡯ࡥ᷊ࠩ"), bstack1ll1lll_opy_ (u"ࠫࡹ࡫ࡡࡳࡦࡲࡻࡳࡥ࡭ࡦࡶ࡫ࡳࡩ࠭᷋")]:
            return bstack111ll1111ll_opy_
        return bstack111l1llllll_opy_
    def bstack111l1llll1l_opy_(self, bstack111ll111111_opy_):
        def bstack111ll111l1l_opy_(this, *args, **kwargs):
            self.bstack111l1ll1lll_opy_(this, bstack111ll111111_opy_)
            self._111l1lll1l1_opy_[bstack111ll111111_opy_](this, *args, **kwargs)
        return bstack111ll111l1l_opy_