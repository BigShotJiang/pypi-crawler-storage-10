# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import threading
from collections import deque
from bstack_utils.constants import *
class bstack11l1l1ll11_opy_:
    def __init__(self):
        self._1111111111l_opy_ = deque()
        self._1111111l11l_opy_ = {}
        self._11111111lll_opy_ = False
        self._lock = threading.RLock()
    def bstack111111111ll_opy_(self, test_name, bstack111111111l1_opy_):
        with self._lock:
            bstack1111111l1l1_opy_ = self._1111111l11l_opy_.get(test_name, {})
            return bstack1111111l1l1_opy_.get(bstack111111111l1_opy_, 0)
    def bstack1111111l111_opy_(self, test_name, bstack111111111l1_opy_):
        with self._lock:
            bstack1111111l1ll_opy_ = self.bstack111111111ll_opy_(test_name, bstack111111111l1_opy_)
            self.bstack1111111ll1l_opy_(test_name, bstack111111111l1_opy_)
            return bstack1111111l1ll_opy_
    def bstack1111111ll1l_opy_(self, test_name, bstack111111111l1_opy_):
        with self._lock:
            if test_name not in self._1111111l11l_opy_:
                self._1111111l11l_opy_[test_name] = {}
            bstack1111111l1l1_opy_ = self._1111111l11l_opy_[test_name]
            bstack1111111l1ll_opy_ = bstack1111111l1l1_opy_.get(bstack111111111l1_opy_, 0)
            bstack1111111l1l1_opy_[bstack111111111l1_opy_] = bstack1111111l1ll_opy_ + 1
    def bstack11l11llll1_opy_(self, bstack11111111ll1_opy_, bstack1111111ll11_opy_):
        bstack11111111l11_opy_ = self.bstack1111111l111_opy_(bstack11111111ll1_opy_, bstack1111111ll11_opy_)
        event_name = bstack11l1ll111ll_opy_[bstack1111111ll11_opy_]
        bstack1l1l11llll1_opy_ = bstack1ll1lll_opy_ (u"ࠤࡾࢁ࠲ࢁࡽ࠮ࡽࢀࠦὴ").format(bstack11111111ll1_opy_, event_name, bstack11111111l11_opy_)
        with self._lock:
            self._1111111111l_opy_.append(bstack1l1l11llll1_opy_)
    def bstack1l111ll11_opy_(self):
        with self._lock:
            return len(self._1111111111l_opy_) == 0
    def bstack11l1l1l11_opy_(self):
        with self._lock:
            if self._1111111111l_opy_:
                bstack11111111l1l_opy_ = self._1111111111l_opy_.popleft()
                return bstack11111111l1l_opy_
            return None
    def capturing(self):
        with self._lock:
            return self._11111111lll_opy_
    def bstack11l1l1lll1_opy_(self):
        with self._lock:
            self._11111111lll_opy_ = True
    def bstack1l1lll11l_opy_(self):
        with self._lock:
            self._11111111lll_opy_ = False