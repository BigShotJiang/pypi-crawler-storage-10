# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import json
import logging
import os
import datetime
import threading
from bstack_utils.constants import EVENTS, STAGE
from bstack_utils.helper import bstack11ll1ll1ll1_opy_, bstack11ll1l111ll_opy_, bstack111lll1ll1_opy_, error_handler, bstack11l11l111ll_opy_, bstack111ll1l1111_opy_, bstack11l11ll11l1_opy_, bstack1l11l1llll_opy_, bstack11l1l1lll_opy_
from bstack_utils.measure import measure
from bstack_utils.bstack1llllll11111_opy_ import bstack1lllll1llll1_opy_
import bstack_utils.bstack11llll111l_opy_ as bstack1llll1111_opy_
from bstack_utils.bstack111ll1llll_opy_ import bstack11l11ll1l1_opy_
import bstack_utils.accessibility as bstack1l11l1l1_opy_
from bstack_utils.bstack1l11llll_opy_ import bstack1l11llll_opy_
from bstack_utils.bstack111ll1l1ll_opy_ import bstack111l1111ll_opy_
from bstack_utils.constants import bstack1ll111llll_opy_
bstack1llll11ll11l_opy_ = bstack1ll1lll_opy_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡰ࡮࡯ࡩࡨࡺ࡯ࡳ࠯ࡲࡦࡸ࡫ࡲࡷࡣࡥ࡭ࡱ࡯ࡴࡺ࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡥࡲࡱࠬ⃱")
logger = logging.getLogger(__name__)
class bstack1l111l111l_opy_:
    bstack1llllll11111_opy_ = None
    bs_config = None
    bstack11ll11l1_opy_ = None
    @classmethod
    @error_handler(class_method=True)
    @measure(event_name=EVENTS.bstack11l1l1llll1_opy_, stage=STAGE.bstack111lll1l11_opy_)
    def launch(cls, bs_config, bstack11ll11l1_opy_):
        cls.bs_config = bs_config
        cls.bstack11ll11l1_opy_ = bstack11ll11l1_opy_
        try:
            cls.bstack1llll111l1ll_opy_()
            bstack11ll1lll11l_opy_ = bstack11ll1ll1ll1_opy_(bs_config)
            bstack11ll11l1l11_opy_ = bstack11ll1l111ll_opy_(bs_config)
            data = bstack1llll1111_opy_.bstack1llll11lll11_opy_(bs_config, bstack11ll11l1_opy_)
            config = {
                bstack1ll1lll_opy_ (u"࠭ࡡࡶࡶ࡫ࠫ⃲"): (bstack11ll1lll11l_opy_, bstack11ll11l1l11_opy_),
                bstack1ll1lll_opy_ (u"ࠧࡩࡧࡤࡨࡪࡸࡳࠨ⃳"): cls.default_headers()
            }
            response = bstack111lll1ll1_opy_(bstack1ll1lll_opy_ (u"ࠨࡒࡒࡗ࡙࠭⃴"), cls.request_url(bstack1ll1lll_opy_ (u"ࠩࡤࡴ࡮࠵ࡶ࠳࠱ࡥࡹ࡮ࡲࡤࡴࠩ⃵")), data, config)
            if response.status_code != 200:
                bstack1l111111l_opy_ = response.json()
                if bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠪࡷࡺࡩࡣࡦࡵࡶࠫ⃶")] == False:
                    cls.bstack1llll11ll1l1_opy_(bstack1l111111l_opy_)
                    return
                cls.bstack1llll111llll_opy_(bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠫࡴࡨࡳࡦࡴࡹࡥࡧ࡯࡬ࡪࡶࡼࠫ⃷")])
                cls.bstack1llll11l11ll_opy_(bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠬ⃸")])
                return None
            bstack1llll11l1l1l_opy_ = cls.bstack1llll11llll1_opy_(response)
            return bstack1llll11l1l1l_opy_, response.json()
        except Exception as error:
            logger.error(bstack1ll1lll_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡺ࡬࡮ࡲࡥࠡࡥࡵࡩࡦࡺࡩ࡯ࡩࠣࡦࡺ࡯࡬ࡥࠢࡩࡳࡷࠦࡔࡦࡵࡷࡌࡺࡨ࠺ࠡࡽࢀࠦ⃹").format(str(error)))
            return None
    @classmethod
    @error_handler(class_method=True)
    def stop(cls, bstack1llll11l111l_opy_=None):
        if not bstack11l11ll1l1_opy_.on() and not bstack1l11l1l1_opy_.on():
            return
        if os.environ.get(bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡌ࡚ࡈ࡟ࡋ࡙ࡗࠫ⃺")) == bstack1ll1lll_opy_ (u"ࠣࡰࡸࡰࡱࠨ⃻") or os.environ.get(bstack1ll1lll_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡎࡕࡃࡡࡘ࡙ࡎࡊࠧ⃼")) == bstack1ll1lll_opy_ (u"ࠥࡲࡺࡲ࡬ࠣ⃽"):
            logger.error(bstack1ll1lll_opy_ (u"ࠫࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡷࡹࡵࡰࠡࡤࡸ࡭ࡱࡪࠠࡳࡧࡴࡹࡪࡹࡴࠡࡶࡲࠤ࡙࡫ࡳࡵࡊࡸࡦ࠿ࠦࡍࡪࡵࡶ࡭ࡳ࡭ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡶࡲ࡯ࡪࡴࠧ⃾"))
            return {
                bstack1ll1lll_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬ⃿"): bstack1ll1lll_opy_ (u"࠭ࡥࡳࡴࡲࡶࠬ℀"),
                bstack1ll1lll_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨ℁"): bstack1ll1lll_opy_ (u"ࠨࡖࡲ࡯ࡪࡴ࠯ࡣࡷ࡬ࡰࡩࡏࡄࠡ࡫ࡶࠤࡺࡴࡤࡦࡨ࡬ࡲࡪࡪࠬࠡࡤࡸ࡭ࡱࡪࠠࡤࡴࡨࡥࡹ࡯࡯࡯ࠢࡰ࡭࡬࡮ࡴࠡࡪࡤࡺࡪࠦࡦࡢ࡫࡯ࡩࡩ࠭ℂ")
            }
        try:
            cls.bstack1llllll11111_opy_.shutdown()
            data = {
                bstack1ll1lll_opy_ (u"ࠩࡩ࡭ࡳ࡯ࡳࡩࡧࡧࡣࡦࡺࠧ℃"): bstack1l11l1llll_opy_()
            }
            if not bstack1llll11l111l_opy_ is None:
                data[bstack1ll1lll_opy_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࡤࡳࡥࡵࡣࡧࡥࡹࡧࠧ℄")] = [{
                    bstack1ll1lll_opy_ (u"ࠫࡷ࡫ࡡࡴࡱࡱࠫ℅"): bstack1ll1lll_opy_ (u"ࠬࡻࡳࡦࡴࡢ࡯࡮ࡲ࡬ࡦࡦࠪ℆"),
                    bstack1ll1lll_opy_ (u"࠭ࡳࡪࡩࡱࡥࡱ࠭ℇ"): bstack1llll11l111l_opy_
                }]
            config = {
                bstack1ll1lll_opy_ (u"ࠧࡩࡧࡤࡨࡪࡸࡳࠨ℈"): cls.default_headers()
            }
            bstack11ll111l1l1_opy_ = bstack1ll1lll_opy_ (u"ࠨࡣࡳ࡭࠴ࡼ࠱࠰ࡤࡸ࡭ࡱࡪࡳ࠰ࡽࢀ࠳ࡸࡺ࡯ࡱࠩ℉").format(os.environ[bstack1ll1lll_opy_ (u"ࠤࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡎࡕࡃࡡࡘ࡙ࡎࡊࠢℊ")])
            bstack1llll1l1111l_opy_ = cls.request_url(bstack11ll111l1l1_opy_)
            response = bstack111lll1ll1_opy_(bstack1ll1lll_opy_ (u"ࠪࡔ࡚࡚ࠧℋ"), bstack1llll1l1111l_opy_, data, config)
            if not response.ok:
                raise Exception(bstack1ll1lll_opy_ (u"ࠦࡘࡺ࡯ࡱࠢࡵࡩࡶࡻࡥࡴࡶࠣࡲࡴࡺࠠࡰ࡭ࠥℌ"))
        except Exception as error:
            logger.error(bstack1ll1lll_opy_ (u"ࠧࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤࡸࡺ࡯ࡱࠢࡥࡹ࡮ࡲࡤࠡࡴࡨࡵࡺ࡫ࡳࡵࠢࡷࡳ࡚ࠥࡥࡴࡶࡋࡹࡧࡀ࠺ࠡࠤℍ") + str(error))
            return {
                bstack1ll1lll_opy_ (u"࠭ࡳࡵࡣࡷࡹࡸ࠭ℎ"): bstack1ll1lll_opy_ (u"ࠧࡦࡴࡵࡳࡷ࠭ℏ"),
                bstack1ll1lll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩℐ"): str(error)
            }
    @classmethod
    @error_handler(class_method=True)
    def bstack1llll11llll1_opy_(cls, response):
        bstack1l111111l_opy_ = response.json() if not isinstance(response, dict) else response
        bstack1llll11l1l1l_opy_ = {}
        if bstack1l111111l_opy_.get(bstack1ll1lll_opy_ (u"ࠩ࡭ࡻࡹ࠭ℑ")) is None:
            os.environ[bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚ࡈࡖࡄࡢࡎ࡜࡚ࠧℒ")] = bstack1ll1lll_opy_ (u"ࠫࡳࡻ࡬࡭ࠩℓ")
        else:
            os.environ[bstack1ll1lll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤࡐࡗࡕࠩ℔")] = bstack1l111111l_opy_.get(bstack1ll1lll_opy_ (u"࠭ࡪࡸࡶࠪℕ"), bstack1ll1lll_opy_ (u"ࠧ࡯ࡷ࡯ࡰࠬ№"))
        os.environ[bstack1ll1lll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡇࡖࡘࡍ࡛ࡂࡠࡗࡘࡍࡉ࠭℗")] = bstack1l111111l_opy_.get(bstack1ll1lll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡠࡪࡤࡷ࡭࡫ࡤࡠ࡫ࡧࠫ℘"), bstack1ll1lll_opy_ (u"ࠪࡲࡺࡲ࡬ࠨℙ"))
        logger.info(bstack1ll1lll_opy_ (u"࡙ࠫ࡫ࡳࡵࡪࡸࡦࠥࡹࡴࡢࡴࡷࡩࡩࠦࡷࡪࡶ࡫ࠤ࡮ࡪ࠺ࠡࠩℚ") + os.getenv(bstack1ll1lll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤ࡛ࡕࡊࡆࠪℛ")));
        if bstack11l11ll1l1_opy_.bstack1llll11l1111_opy_(cls.bs_config, cls.bstack11ll11l1_opy_.get(bstack1ll1lll_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࡡࡸࡷࡪࡪࠧℜ"), bstack1ll1lll_opy_ (u"ࠧࠨℝ"))) is True:
            bstack1lllll1l1l1l_opy_, build_hashed_id, bstack1llll11lllll_opy_ = cls.bstack1llll1l11111_opy_(bstack1l111111l_opy_)
            if bstack1lllll1l1l1l_opy_ != None and build_hashed_id != None:
                bstack1llll11l1l1l_opy_[bstack1ll1lll_opy_ (u"ࠨࡱࡥࡷࡪࡸࡶࡢࡤ࡬ࡰ࡮ࡺࡹࠨ℞")] = {
                    bstack1ll1lll_opy_ (u"ࠩ࡭ࡻࡹࡥࡴࡰ࡭ࡨࡲࠬ℟"): bstack1lllll1l1l1l_opy_,
                    bstack1ll1lll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡡ࡫ࡥࡸ࡮ࡥࡥࡡ࡬ࡨࠬ℠"): build_hashed_id,
                    bstack1ll1lll_opy_ (u"ࠫࡦࡲ࡬ࡰࡹࡢࡷࡨࡸࡥࡦࡰࡶ࡬ࡴࡺࡳࠨ℡"): bstack1llll11lllll_opy_
                }
            else:
                bstack1llll11l1l1l_opy_[bstack1ll1lll_opy_ (u"ࠬࡵࡢࡴࡧࡵࡺࡦࡨࡩ࡭࡫ࡷࡽࠬ™")] = {}
        else:
            bstack1llll11l1l1l_opy_[bstack1ll1lll_opy_ (u"࠭࡯ࡣࡵࡨࡶࡻࡧࡢࡪ࡮࡬ࡸࡾ࠭℣")] = {}
        bstack1llll111ll11_opy_, build_hashed_id = cls.bstack1llll111lll1_opy_(bstack1l111111l_opy_)
        if bstack1llll111ll11_opy_ != None and build_hashed_id != None:
            bstack1llll11l1l1l_opy_[bstack1ll1lll_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠧℤ")] = {
                bstack1ll1lll_opy_ (u"ࠨࡣࡸࡸ࡭ࡥࡴࡰ࡭ࡨࡲࠬ℥"): bstack1llll111ll11_opy_,
                bstack1ll1lll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡠࡪࡤࡷ࡭࡫ࡤࡠ࡫ࡧࠫΩ"): build_hashed_id,
            }
        else:
            bstack1llll11l1l1l_opy_[bstack1ll1lll_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪ℧")] = {}
        if bstack1llll11l1l1l_opy_[bstack1ll1lll_opy_ (u"ࠫࡴࡨࡳࡦࡴࡹࡥࡧ࡯࡬ࡪࡶࡼࠫℨ")].get(bstack1ll1lll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡣ࡭ࡧࡳࡩࡧࡧࡣ࡮ࡪࠧ℩")) != None or bstack1llll11l1l1l_opy_[bstack1ll1lll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࠭K")].get(bstack1ll1lll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡥࡨࡢࡵ࡫ࡩࡩࡥࡩࡥࠩÅ")) != None:
            cls.bstack1llll1l111ll_opy_(bstack1l111111l_opy_.get(bstack1ll1lll_opy_ (u"ࠨ࡬ࡺࡸࠬℬ")), bstack1l111111l_opy_.get(bstack1ll1lll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡠࡪࡤࡷ࡭࡫ࡤࡠ࡫ࡧࠫℭ")))
        return bstack1llll11l1l1l_opy_
    @classmethod
    def bstack1llll1l11111_opy_(cls, bstack1l111111l_opy_):
        if bstack1l111111l_opy_.get(bstack1ll1lll_opy_ (u"ࠪࡳࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻࠪ℮")) == None:
            cls.bstack1llll111llll_opy_()
            return [None, None, None]
        if bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠫࡴࡨࡳࡦࡴࡹࡥࡧ࡯࡬ࡪࡶࡼࠫℯ")][bstack1ll1lll_opy_ (u"ࠬࡹࡵࡤࡥࡨࡷࡸ࠭ℰ")] != True:
            cls.bstack1llll111llll_opy_(bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"࠭࡯ࡣࡵࡨࡶࡻࡧࡢࡪ࡮࡬ࡸࡾ࠭ℱ")])
            return [None, None, None]
        logger.debug(bstack1ll1lll_opy_ (u"ࠧࡼࡿࠣࡆࡺ࡯࡬ࡥࠢࡦࡶࡪࡧࡴࡪࡱࡱࠤࡘࡻࡣࡤࡧࡶࡷ࡫ࡻ࡬ࠢࠩℲ").format(bstack1ll111llll_opy_))
        os.environ[bstack1ll1lll_opy_ (u"ࠨࡄࡖࡣ࡙ࡋࡓࡕࡑࡓࡗࡤࡈࡕࡊࡎࡇࡣࡈࡕࡍࡑࡎࡈࡘࡊࡊࠧℳ")] = bstack1ll1lll_opy_ (u"ࠩࡷࡶࡺ࡫ࠧℴ")
        if bstack1l111111l_opy_.get(bstack1ll1lll_opy_ (u"ࠪ࡮ࡼࡺࠧℵ")):
            os.environ[bstack1ll1lll_opy_ (u"ࠫࡈࡘࡅࡅࡇࡑࡘࡎࡇࡌࡔࡡࡉࡓࡗࡥࡃࡓࡃࡖࡌࡤࡘࡅࡑࡑࡕࡘࡎࡔࡇࠨℶ")] = json.dumps({
                bstack1ll1lll_opy_ (u"ࠬࡻࡳࡦࡴࡱࡥࡲ࡫ࠧℷ"): bstack11ll1ll1ll1_opy_(cls.bs_config),
                bstack1ll1lll_opy_ (u"࠭ࡰࡢࡵࡶࡻࡴࡸࡤࠨℸ"): bstack11ll1l111ll_opy_(cls.bs_config)
            })
        if bstack1l111111l_opy_.get(bstack1ll1lll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡥࡨࡢࡵ࡫ࡩࡩࡥࡩࡥࠩℹ")):
            os.environ[bstack1ll1lll_opy_ (u"ࠨࡄࡖࡣ࡙ࡋࡓࡕࡑࡓࡗࡤࡈࡕࡊࡎࡇࡣࡍࡇࡓࡉࡇࡇࡣࡎࡊࠧ℺")] = bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡠࡪࡤࡷ࡭࡫ࡤࡠ࡫ࡧࠫ℻")]
        if bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠪࡳࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻࠪℼ")].get(bstack1ll1lll_opy_ (u"ࠫࡴࡶࡴࡪࡱࡱࡷࠬℽ"), {}).get(bstack1ll1lll_opy_ (u"ࠬࡧ࡬࡭ࡱࡺࡣࡸࡩࡲࡦࡧࡱࡷ࡭ࡵࡴࡴࠩℾ")):
            os.environ[bstack1ll1lll_opy_ (u"࠭ࡂࡔࡡࡗࡉࡘ࡚ࡏࡑࡕࡢࡅࡑࡒࡏࡘࡡࡖࡇࡗࡋࡅࡏࡕࡋࡓ࡙࡙ࠧℿ")] = str(bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠧࡰࡤࡶࡩࡷࡼࡡࡣ࡫࡯࡭ࡹࡿࠧ⅀")][bstack1ll1lll_opy_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮ࡴࠩ⅁")][bstack1ll1lll_opy_ (u"ࠩࡤࡰࡱࡵࡷࡠࡵࡦࡶࡪ࡫࡮ࡴࡪࡲࡸࡸ࠭⅂")])
        else:
            os.environ[bstack1ll1lll_opy_ (u"ࠪࡆࡘࡥࡔࡆࡕࡗࡓࡕ࡙࡟ࡂࡎࡏࡓ࡜ࡥࡓࡄࡔࡈࡉࡓ࡙ࡈࡐࡖࡖࠫ⅃")] = bstack1ll1lll_opy_ (u"ࠦࡳࡻ࡬࡭ࠤ⅄")
        return [bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠬࡰࡷࡵࠩⅅ")], bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡤ࡮ࡡࡴࡪࡨࡨࡤ࡯ࡤࠨⅆ")], os.environ[bstack1ll1lll_opy_ (u"ࠧࡃࡕࡢࡘࡊ࡙ࡔࡐࡒࡖࡣࡆࡒࡌࡐ࡙ࡢࡗࡈࡘࡅࡆࡐࡖࡌࡔ࡚ࡓࠨⅇ")]]
    @classmethod
    def bstack1llll111lll1_opy_(cls, bstack1l111111l_opy_):
        if bstack1l111111l_opy_.get(bstack1ll1lll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨⅈ")) == None:
            cls.bstack1llll11l11ll_opy_()
            return [None, None]
        if bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠩⅉ")][bstack1ll1lll_opy_ (u"ࠪࡷࡺࡩࡣࡦࡵࡶࠫ⅊")] != True:
            cls.bstack1llll11l11ll_opy_(bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠫ⅋")])
            return [None, None]
        if bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠬ⅌")].get(bstack1ll1lll_opy_ (u"࠭࡯ࡱࡶ࡬ࡳࡳࡹࠧ⅍")):
            logger.debug(bstack1ll1lll_opy_ (u"ࠧࡕࡧࡶࡸࠥࡇࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡈࡵࡪ࡮ࡧࠤࡨࡸࡥࡢࡶ࡬ࡳࡳࠦࡓࡶࡥࡦࡩࡸࡹࡦࡶ࡮ࠤࠫⅎ"))
            parsed = json.loads(os.getenv(bstack1ll1lll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡇࡖࡘࡤࡇࡃࡄࡇࡖࡗࡎࡈࡉࡍࡋࡗ࡝ࡤࡉࡏࡏࡈࡌࡋ࡚ࡘࡁࡕࡋࡒࡒࡤ࡟ࡍࡍࠩ⅏"), bstack1ll1lll_opy_ (u"ࠩࡾࢁࠬ⅐")))
            capabilities = bstack1llll1111_opy_.bstack1llll11l1l11_opy_(bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪ⅑")][bstack1ll1lll_opy_ (u"ࠫࡴࡶࡴࡪࡱࡱࡷࠬ⅒")][bstack1ll1lll_opy_ (u"ࠬࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶࠫ⅓")], bstack1ll1lll_opy_ (u"࠭࡮ࡢ࡯ࡨࠫ⅔"), bstack1ll1lll_opy_ (u"ࠧࡷࡣ࡯ࡹࡪ࠭⅕"))
            bstack1llll111ll11_opy_ = capabilities[bstack1ll1lll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࡕࡱ࡮ࡩࡳ࠭⅖")]
            os.environ[bstack1ll1lll_opy_ (u"ࠩࡅࡗࡤࡇ࠱࠲࡛ࡢࡎ࡜࡚ࠧ⅗")] = bstack1llll111ll11_opy_
            if bstack1ll1lll_opy_ (u"ࠥࡥࡺࡺ࡯࡮ࡣࡷࡩࠧ⅘") in bstack1l111111l_opy_ and bstack1l111111l_opy_.get(bstack1ll1lll_opy_ (u"ࠦࡦࡶࡰࡠࡣࡸࡸࡴࡳࡡࡵࡧࠥ⅙")) is None:
                parsed[bstack1ll1lll_opy_ (u"ࠬࡹࡣࡢࡰࡱࡩࡷ࡜ࡥࡳࡵ࡬ࡳࡳ࠭⅚")] = capabilities[bstack1ll1lll_opy_ (u"࠭ࡳࡤࡣࡱࡲࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧ⅛")]
            os.environ[bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡣࡆࡉࡃࡆࡕࡖࡍࡇࡏࡌࡊࡖ࡜ࡣࡈࡕࡎࡇࡋࡊ࡙ࡗࡇࡔࡊࡑࡑࡣ࡞ࡓࡌࠨ⅜")] = json.dumps(parsed)
            scripts = bstack1llll1111_opy_.bstack1llll11l1l11_opy_(bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨ⅝")][bstack1ll1lll_opy_ (u"ࠩࡲࡴࡹ࡯࡯࡯ࡵࠪ⅞")][bstack1ll1lll_opy_ (u"ࠪࡷࡨࡸࡩࡱࡶࡶࠫ⅟")], bstack1ll1lll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩⅠ"), bstack1ll1lll_opy_ (u"ࠬࡩ࡯࡮࡯ࡤࡲࡩ࠭Ⅱ"))
            bstack1l11llll_opy_.bstack11l1l11lll_opy_(scripts)
            commands = bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࠭Ⅲ")][bstack1ll1lll_opy_ (u"ࠧࡰࡲࡷ࡭ࡴࡴࡳࠨⅣ")][bstack1ll1lll_opy_ (u"ࠨࡥࡲࡱࡲࡧ࡮ࡥࡵࡗࡳ࡜ࡸࡡࡱࠩⅤ")].get(bstack1ll1lll_opy_ (u"ࠩࡦࡳࡲࡳࡡ࡯ࡦࡶࠫⅥ"))
            bstack1l11llll_opy_.bstack11ll1l1lll1_opy_(commands)
            bstack11ll1ll11l1_opy_ = capabilities.get(bstack1ll1lll_opy_ (u"ࠪ࡫ࡴࡵࡧ࠻ࡥ࡫ࡶࡴࡳࡥࡐࡲࡷ࡭ࡴࡴࡳࠨⅦ"))
            bstack1l11llll_opy_.bstack11ll111ll11_opy_(bstack11ll1ll11l1_opy_)
            bstack1l11llll_opy_.store()
        return [bstack1llll111ll11_opy_, bstack1l111111l_opy_[bstack1ll1lll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡢ࡬ࡦࡹࡨࡦࡦࡢ࡭ࡩ࠭Ⅷ")]]
    @classmethod
    def bstack1llll111llll_opy_(cls, response=None):
        os.environ[bstack1ll1lll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤ࡛ࡕࡊࡆࠪⅨ")] = bstack1ll1lll_opy_ (u"࠭࡮ࡶ࡮࡯ࠫⅩ")
        os.environ[bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡌ࡚ࡈ࡟ࡋ࡙ࡗࠫⅪ")] = bstack1ll1lll_opy_ (u"ࠨࡰࡸࡰࡱ࠭Ⅻ")
        os.environ[bstack1ll1lll_opy_ (u"ࠩࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡂࡖࡋࡏࡈࡤࡉࡏࡎࡒࡏࡉ࡙ࡋࡄࠨⅬ")] = bstack1ll1lll_opy_ (u"ࠪࡪࡦࡲࡳࡦࠩⅭ")
        os.environ[bstack1ll1lll_opy_ (u"ࠫࡇ࡙࡟ࡕࡇࡖࡘࡔࡖࡓࡠࡄࡘࡍࡑࡊ࡟ࡉࡃࡖࡌࡊࡊ࡟ࡊࡆࠪⅮ")] = bstack1ll1lll_opy_ (u"ࠧࡴࡵ࡭࡮ࠥⅯ")
        os.environ[bstack1ll1lll_opy_ (u"࠭ࡂࡔࡡࡗࡉࡘ࡚ࡏࡑࡕࡢࡅࡑࡒࡏࡘࡡࡖࡇࡗࡋࡅࡏࡕࡋࡓ࡙࡙ࠧⅰ")] = bstack1ll1lll_opy_ (u"ࠢ࡯ࡷ࡯ࡰࠧⅱ")
        cls.bstack1llll11ll1l1_opy_(response, bstack1ll1lll_opy_ (u"ࠣࡱࡥࡷࡪࡸࡶࡢࡤ࡬ࡰ࡮ࡺࡹࠣⅲ"))
        return [None, None, None]
    @classmethod
    def bstack1llll11l11ll_opy_(cls, response=None):
        os.environ[bstack1ll1lll_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡎࡕࡃࡡࡘ࡙ࡎࡊࠧⅳ")] = bstack1ll1lll_opy_ (u"ࠪࡲࡺࡲ࡬ࠨⅴ")
        os.environ[bstack1ll1lll_opy_ (u"ࠫࡇ࡙࡟ࡂ࠳࠴࡝ࡤࡐࡗࡕࠩⅵ")] = bstack1ll1lll_opy_ (u"ࠬࡴࡵ࡭࡮ࠪⅶ")
        os.environ[bstack1ll1lll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤ࡚ࡅࡔࡖࡋ࡙ࡇࡥࡊࡘࡖࠪⅷ")] = bstack1ll1lll_opy_ (u"ࠧ࡯ࡷ࡯ࡰࠬⅸ")
        cls.bstack1llll11ll1l1_opy_(response, bstack1ll1lll_opy_ (u"ࠣࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠣⅹ"))
        return [None, None, None]
    @classmethod
    def bstack1llll1l111ll_opy_(cls, jwt, build_hashed_id):
        os.environ[bstack1ll1lll_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡎࡕࡃࡡࡍ࡛࡙࠭ⅺ")] = jwt
        os.environ[bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚ࡈࡖࡄࡢ࡙࡚ࡏࡄࠨⅻ")] = build_hashed_id
    @classmethod
    def bstack1llll11ll1l1_opy_(cls, response=None, product=bstack1ll1lll_opy_ (u"ࠦࠧⅼ")):
        if response == None or response.get(bstack1ll1lll_opy_ (u"ࠬ࡫ࡲࡳࡱࡵࡷࠬⅽ")) == None:
            logger.error(product + bstack1ll1lll_opy_ (u"ࠨࠠࡃࡷ࡬ࡰࡩࠦࡣࡳࡧࡤࡸ࡮ࡵ࡮ࠡࡨࡤ࡭ࡱ࡫ࡤࠣⅾ"))
            return
        for error in response[bstack1ll1lll_opy_ (u"ࠧࡦࡴࡵࡳࡷࡹࠧⅿ")]:
            bstack111lllll111_opy_ = error[bstack1ll1lll_opy_ (u"ࠨ࡭ࡨࡽࠬↀ")]
            error_message = error[bstack1ll1lll_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪↁ")]
            if error_message:
                if bstack111lllll111_opy_ == bstack1ll1lll_opy_ (u"ࠥࡉࡗࡘࡏࡓࡡࡄࡇࡈࡋࡓࡔࡡࡇࡉࡓࡏࡅࡅࠤↂ"):
                    logger.info(error_message)
                else:
                    logger.error(error_message)
            else:
                logger.error(bstack1ll1lll_opy_ (u"ࠦࡉࡧࡴࡢࠢࡸࡴࡱࡵࡡࡥࠢࡷࡳࠥࡈࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࠤࠧↃ") + product + bstack1ll1lll_opy_ (u"ࠧࠦࡦࡢ࡫࡯ࡩࡩࠦࡤࡶࡧࠣࡸࡴࠦࡳࡰ࡯ࡨࠤࡪࡸࡲࡰࡴࠥↄ"))
    @classmethod
    def bstack1llll111l1ll_opy_(cls):
        if cls.bstack1llllll11111_opy_ is not None:
            return
        cls.bstack1llllll11111_opy_ = bstack1lllll1llll1_opy_(cls.bstack1llll11l1lll_opy_)
        cls.bstack1llllll11111_opy_.start()
    @classmethod
    def bstack111l1l1l1l_opy_(cls):
        if cls.bstack1llllll11111_opy_ is None:
            return
        cls.bstack1llllll11111_opy_.shutdown()
    @classmethod
    @error_handler(class_method=True)
    def bstack1llll11l1lll_opy_(cls, bstack1111ll1ll1_opy_, event_url=bstack1ll1lll_opy_ (u"࠭ࡡࡱ࡫࠲ࡺ࠶࠵ࡢࡢࡶࡦ࡬ࠬↅ")):
        config = {
            bstack1ll1lll_opy_ (u"ࠧࡩࡧࡤࡨࡪࡸࡳࠨↆ"): cls.default_headers()
        }
        logger.debug(bstack1ll1lll_opy_ (u"ࠣࡲࡲࡷࡹࡥࡤࡢࡶࡤ࠾࡙ࠥࡥ࡯ࡦ࡬ࡲ࡬ࠦࡤࡢࡶࡤࠤࡹࡵࠠࡵࡧࡶࡸ࡭ࡻࡢࠡࡨࡲࡶࠥ࡫ࡶࡦࡰࡷࡷࠥࢁࡽࠣↇ").format(bstack1ll1lll_opy_ (u"ࠩ࠯ࠤࠬↈ").join([event[bstack1ll1lll_opy_ (u"ࠪࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠧ↉")] for event in bstack1111ll1ll1_opy_])))
        response = bstack111lll1ll1_opy_(bstack1ll1lll_opy_ (u"ࠫࡕࡕࡓࡕࠩ↊"), cls.request_url(event_url), bstack1111ll1ll1_opy_, config)
        bstack11ll1l1l1ll_opy_ = response.json()
    @classmethod
    def bstack1l1111l11_opy_(cls, bstack1111ll1ll1_opy_, event_url=bstack1ll1lll_opy_ (u"ࠬࡧࡰࡪ࠱ࡹ࠵࠴ࡨࡡࡵࡥ࡫ࠫ↋")):
        logger.debug(bstack1ll1lll_opy_ (u"ࠨࡳࡦࡰࡧࡣࡩࡧࡴࡢ࠼ࠣࡅࡹࡺࡥ࡮ࡲࡷ࡭ࡳ࡭ࠠࡵࡱࠣࡥࡩࡪࠠࡥࡣࡷࡥࠥࡺ࡯ࠡࡤࡤࡸࡨ࡮ࠠࡸ࡫ࡷ࡬ࠥ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦ࠼ࠣࡿࢂࠨ↌").format(bstack1111ll1ll1_opy_[bstack1ll1lll_opy_ (u"ࠧࡦࡸࡨࡲࡹࡥࡴࡺࡲࡨࠫ↍")]))
        if not bstack1llll1111_opy_.bstack1llll111ll1l_opy_(bstack1111ll1ll1_opy_[bstack1ll1lll_opy_ (u"ࠨࡧࡹࡩࡳࡺ࡟ࡵࡻࡳࡩࠬ↎")]):
            logger.debug(bstack1ll1lll_opy_ (u"ࠤࡶࡩࡳࡪ࡟ࡥࡣࡷࡥ࠿ࠦࡎࡰࡶࠣࡥࡩࡪࡩ࡯ࡩࠣࡨࡦࡺࡡࠡࡹ࡬ࡸ࡭ࠦࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧ࠽ࠤࢀࢃࠢ↏").format(bstack1111ll1ll1_opy_[bstack1ll1lll_opy_ (u"ࠪࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠧ←")]))
            return
        bstack11l1l1l1ll_opy_ = bstack1llll1111_opy_.bstack1llll11ll111_opy_(bstack1111ll1ll1_opy_[bstack1ll1lll_opy_ (u"ࠫࡪࡼࡥ࡯ࡶࡢࡸࡾࡶࡥࠨ↑")], bstack1111ll1ll1_opy_.get(bstack1ll1lll_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴࠧ→")))
        if bstack11l1l1l1ll_opy_ != None:
            if bstack1111ll1ll1_opy_.get(bstack1ll1lll_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࠨ↓")) != None:
                bstack1111ll1ll1_opy_[bstack1ll1lll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࠩ↔")][bstack1ll1lll_opy_ (u"ࠨࡲࡵࡳࡩࡻࡣࡵࡡࡰࡥࡵ࠭↕")] = bstack11l1l1l1ll_opy_
            else:
                bstack1111ll1ll1_opy_[bstack1ll1lll_opy_ (u"ࠩࡳࡶࡴࡪࡵࡤࡶࡢࡱࡦࡶࠧ↖")] = bstack11l1l1l1ll_opy_
        if event_url == bstack1ll1lll_opy_ (u"ࠪࡥࡵ࡯࠯ࡷ࠳࠲ࡦࡦࡺࡣࡩࠩ↗"):
            cls.bstack1llll111l1ll_opy_()
            logger.debug(bstack1ll1lll_opy_ (u"ࠦࡸ࡫࡮ࡥࡡࡧࡥࡹࡧ࠺ࠡࡃࡧࡨ࡮ࡴࡧࠡࡦࡤࡸࡦࠦࡴࡰࠢࡥࡥࡹࡩࡨࠡࡹ࡬ࡸ࡭ࠦࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧ࠽ࠤࢀࢃࠢ↘").format(bstack1111ll1ll1_opy_[bstack1ll1lll_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠩ↙")]))
            cls.bstack1llllll11111_opy_.add(bstack1111ll1ll1_opy_)
        elif event_url == bstack1ll1lll_opy_ (u"࠭ࡡࡱ࡫࠲ࡺ࠶࠵ࡳࡤࡴࡨࡩࡳࡹࡨࡰࡶࡶࠫ↚"):
            cls.bstack1llll11l1lll_opy_([bstack1111ll1ll1_opy_], event_url)
    @classmethod
    @error_handler(class_method=True)
    def bstack1lll11l1_opy_(cls, logs):
        for log in logs:
            bstack1llll11lll1l_opy_ = {
                bstack1ll1lll_opy_ (u"ࠧ࡬࡫ࡱࡨࠬ↛"): bstack1ll1lll_opy_ (u"ࠨࡖࡈࡗ࡙ࡥࡌࡐࡉࠪ↜"),
                bstack1ll1lll_opy_ (u"ࠩ࡯ࡩࡻ࡫࡬ࠨ↝"): log[bstack1ll1lll_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩ↞")],
                bstack1ll1lll_opy_ (u"ࠫࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧ↟"): log[bstack1ll1lll_opy_ (u"ࠬࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨ↠")],
                bstack1ll1lll_opy_ (u"࠭ࡨࡵࡶࡳࡣࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭↡"): {},
                bstack1ll1lll_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨ↢"): log[bstack1ll1lll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩ↣")],
            }
            if bstack1ll1lll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩ↤") in log:
                bstack1llll11lll1l_opy_[bstack1ll1lll_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪ↥")] = log[bstack1ll1lll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫ↦")]
            elif bstack1ll1lll_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬ↧") in log:
                bstack1llll11lll1l_opy_[bstack1ll1lll_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭↨")] = log[bstack1ll1lll_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧ↩")]
            cls.bstack1l1111l11_opy_({
                bstack1ll1lll_opy_ (u"ࠨࡧࡹࡩࡳࡺ࡟ࡵࡻࡳࡩࠬ↪"): bstack1ll1lll_opy_ (u"ࠩࡏࡳ࡬ࡉࡲࡦࡣࡷࡩࡩ࠭↫"),
                bstack1ll1lll_opy_ (u"ࠪࡰࡴ࡭ࡳࠨ↬"): [bstack1llll11lll1l_opy_]
            })
    @classmethod
    @error_handler(class_method=True)
    def bstack1llll111l1l1_opy_(cls, steps):
        bstack1llll11l11l1_opy_ = []
        for step in steps:
            bstack1llll11ll1ll_opy_ = {
                bstack1ll1lll_opy_ (u"ࠫࡰ࡯࡮ࡥࠩ↭"): bstack1ll1lll_opy_ (u"࡚ࠬࡅࡔࡖࡢࡗ࡙ࡋࡐࠨ↮"),
                bstack1ll1lll_opy_ (u"࠭࡬ࡦࡸࡨࡰࠬ↯"): step[bstack1ll1lll_opy_ (u"ࠧ࡭ࡧࡹࡩࡱ࠭↰")],
                bstack1ll1lll_opy_ (u"ࠨࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠫ↱"): step[bstack1ll1lll_opy_ (u"ࠩࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ↲")],
                bstack1ll1lll_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫ↳"): step[bstack1ll1lll_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬ↴")],
                bstack1ll1lll_opy_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧ↵"): step[bstack1ll1lll_opy_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ↶")]
            }
            if bstack1ll1lll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧ↷") in step:
                bstack1llll11ll1ll_opy_[bstack1ll1lll_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨ↸")] = step[bstack1ll1lll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩ↹")]
            elif bstack1ll1lll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪ↺") in step:
                bstack1llll11ll1ll_opy_[bstack1ll1lll_opy_ (u"ࠫ࡭ࡵ࡯࡬ࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫ↻")] = step[bstack1ll1lll_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬ↼")]
            bstack1llll11l11l1_opy_.append(bstack1llll11ll1ll_opy_)
        cls.bstack1l1111l11_opy_({
            bstack1ll1lll_opy_ (u"࠭ࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧࠪ↽"): bstack1ll1lll_opy_ (u"ࠧࡍࡱࡪࡇࡷ࡫ࡡࡵࡧࡧࠫ↾"),
            bstack1ll1lll_opy_ (u"ࠨ࡮ࡲ࡫ࡸ࠭↿"): bstack1llll11l11l1_opy_
        })
    @classmethod
    @error_handler(class_method=True)
    @measure(event_name=EVENTS.bstack1ll1l1ll1_opy_, stage=STAGE.bstack111lll1l11_opy_)
    def bstack1l111llll1_opy_(cls, screenshot):
        cls.bstack1l1111l11_opy_({
            bstack1ll1lll_opy_ (u"ࠩࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪ࠭⇀"): bstack1ll1lll_opy_ (u"ࠪࡐࡴ࡭ࡃࡳࡧࡤࡸࡪࡪࠧ⇁"),
            bstack1ll1lll_opy_ (u"ࠫࡱࡵࡧࡴࠩ⇂"): [{
                bstack1ll1lll_opy_ (u"ࠬࡱࡩ࡯ࡦࠪ⇃"): bstack1ll1lll_opy_ (u"࠭ࡔࡆࡕࡗࡣࡘࡉࡒࡆࡇࡑࡗࡍࡕࡔࠨ⇄"),
                bstack1ll1lll_opy_ (u"ࠧࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪ⇅"): datetime.datetime.utcnow().isoformat() + bstack1ll1lll_opy_ (u"ࠨ࡜ࠪ⇆"),
                bstack1ll1lll_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪ⇇"): screenshot[bstack1ll1lll_opy_ (u"ࠪ࡭ࡲࡧࡧࡦࠩ⇈")],
                bstack1ll1lll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫ⇉"): screenshot[bstack1ll1lll_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬ⇊")]
            }]
        }, event_url=bstack1ll1lll_opy_ (u"࠭ࡡࡱ࡫࠲ࡺ࠶࠵ࡳࡤࡴࡨࡩࡳࡹࡨࡰࡶࡶࠫ⇋"))
    @classmethod
    @error_handler(class_method=True)
    def bstack1llll1lll1_opy_(cls, driver):
        current_test_uuid = cls.current_test_uuid()
        if not current_test_uuid:
            return
        cls.bstack1l1111l11_opy_({
            bstack1ll1lll_opy_ (u"ࠧࡦࡸࡨࡲࡹࡥࡴࡺࡲࡨࠫ⇌"): bstack1ll1lll_opy_ (u"ࠨࡅࡅࡘࡘ࡫ࡳࡴ࡫ࡲࡲࡈࡸࡥࡢࡶࡨࡨࠬ⇍"),
            bstack1ll1lll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡳࡷࡱࠫ⇎"): {
                bstack1ll1lll_opy_ (u"ࠥࡹࡺ࡯ࡤࠣ⇏"): cls.current_test_uuid(),
                bstack1ll1lll_opy_ (u"ࠦ࡮ࡴࡴࡦࡩࡵࡥࡹ࡯࡯࡯ࡵࠥ⇐"): cls.bstack111ll11111_opy_(driver)
            }
        })
    @classmethod
    def bstack111l1llll1_opy_(cls, event: str, bstack1111ll1ll1_opy_: bstack111l1111ll_opy_):
        bstack1111llll11_opy_ = {
            bstack1ll1lll_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠩ⇑"): event,
            bstack1111ll1ll1_opy_.bstack111l11111l_opy_(): bstack1111ll1ll1_opy_.bstack1111lll11l_opy_(event)
        }
        cls.bstack1l1111l11_opy_(bstack1111llll11_opy_)
        result = getattr(bstack1111ll1ll1_opy_, bstack1ll1lll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭⇒"), None)
        if event == bstack1ll1lll_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡔࡶࡤࡶࡹ࡫ࡤࠨ⇓"):
            threading.current_thread().bstackTestMeta = {bstack1ll1lll_opy_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨ⇔"): bstack1ll1lll_opy_ (u"ࠩࡳࡩࡳࡪࡩ࡯ࡩࠪ⇕")}
        elif event == bstack1ll1lll_opy_ (u"ࠪࡘࡪࡹࡴࡓࡷࡱࡊ࡮ࡴࡩࡴࡪࡨࡨࠬ⇖"):
            threading.current_thread().bstackTestMeta = {bstack1ll1lll_opy_ (u"ࠫࡸࡺࡡࡵࡷࡶࠫ⇗"): getattr(result, bstack1ll1lll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬ⇘"), bstack1ll1lll_opy_ (u"࠭ࠧ⇙"))}
    @classmethod
    def on(cls):
        if (os.environ.get(bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡌ࡚ࡈ࡟ࡋ࡙ࡗࠫ⇚"), None) is None or os.environ[bstack1ll1lll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡇࡖࡘࡍ࡛ࡂࡠࡌ࡚ࡘࠬ⇛")] == bstack1ll1lll_opy_ (u"ࠤࡱࡹࡱࡲࠢ⇜")) and (os.environ.get(bstack1ll1lll_opy_ (u"ࠪࡆࡘࡥࡁ࠲࠳࡜ࡣࡏ࡝ࡔࠨ⇝"), None) is None or os.environ[bstack1ll1lll_opy_ (u"ࠫࡇ࡙࡟ࡂ࠳࠴࡝ࡤࡐࡗࡕࠩ⇞")] == bstack1ll1lll_opy_ (u"ࠧࡴࡵ࡭࡮ࠥ⇟")):
            return False
        return True
    @staticmethod
    def bstack1llll1l111l1_opy_(func):
        def wrap(*args, **kwargs):
            if bstack1l111l111l_opy_.on():
                return func(*args, **kwargs)
            return
        return wrap
    @staticmethod
    def default_headers():
        headers = {
            bstack1ll1lll_opy_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ⇠"): bstack1ll1lll_opy_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡰࡳࡰࡰࠪ⇡"),
            bstack1ll1lll_opy_ (u"ࠨ࡚࠰ࡆࡘ࡚ࡁࡄࡍ࠰ࡘࡊ࡙ࡔࡐࡒࡖࠫ⇢"): bstack1ll1lll_opy_ (u"ࠩࡷࡶࡺ࡫ࠧ⇣")
        }
        if os.environ.get(bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚ࡈࡖࡄࡢࡎ࡜࡚ࠧ⇤"), None):
            headers[bstack1ll1lll_opy_ (u"ࠫࡆࡻࡴࡩࡱࡵ࡭ࡿࡧࡴࡪࡱࡱࠫ⇥")] = bstack1ll1lll_opy_ (u"ࠬࡈࡥࡢࡴࡨࡶࠥࢁࡽࠨ⇦").format(os.environ[bstack1ll1lll_opy_ (u"ࠨࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤ࡚ࡅࡔࡖࡋ࡙ࡇࡥࡊࡘࡖࠥ⇧")])
        return headers
    @staticmethod
    def request_url(url):
        return bstack1ll1lll_opy_ (u"ࠧࡼࡿ࠲ࡿࢂ࠭⇨").format(bstack1llll11ll11l_opy_, url)
    @staticmethod
    def current_test_uuid():
        return getattr(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠨࡥࡸࡶࡷ࡫࡮ࡵࡡࡷࡩࡸࡺ࡟ࡶࡷ࡬ࡨࠬ⇩"), None)
    @staticmethod
    def bstack111ll11111_opy_(driver):
        return {
            bstack11l11l111ll_opy_(): bstack111ll1l1111_opy_(driver)
        }
    @staticmethod
    def bstack1llll11l1ll1_opy_(exception_info, report):
        return [{bstack1ll1lll_opy_ (u"ࠩࡥࡥࡨࡱࡴࡳࡣࡦࡩࠬ⇪"): [exception_info.exconly(), report.longreprtext]}]
    @staticmethod
    def bstack1111111l11_opy_(typename):
        if bstack1ll1lll_opy_ (u"ࠥࡅࡸࡹࡥࡳࡶ࡬ࡳࡳࠨ⇫") in typename:
            return bstack1ll1lll_opy_ (u"ࠦࡆࡹࡳࡦࡴࡷ࡭ࡴࡴࡅࡳࡴࡲࡶࠧ⇬")
        return bstack1ll1lll_opy_ (u"࡛ࠧ࡮ࡩࡣࡱࡨࡱ࡫ࡤࡆࡴࡵࡳࡷࠨ⇭")