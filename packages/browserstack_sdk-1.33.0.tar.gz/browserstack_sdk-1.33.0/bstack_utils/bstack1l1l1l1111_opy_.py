# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import threading
import tempfile
import os
import time
from datetime import datetime
from bstack_utils.bstack11ll11111l1_opy_ import bstack11ll111l111_opy_
from bstack_utils.constants import bstack11l1l1l1l1l_opy_, bstack1l1lll1l11_opy_
from bstack_utils.bstack1llll111ll_opy_ import bstack11lll1lll1_opy_
from bstack_utils import bstack1ll1ll1111_opy_
bstack11l1l11l111_opy_ = 10
class bstack1llll11l11_opy_:
    def __init__(self, bstack1lll1111_opy_, config, bstack11l1l11llll_opy_=0):
        self.bstack11l1l11111l_opy_ = set()
        self.lock = threading.Lock()
        self.bstack11l1l11ll1l_opy_ = bstack1ll1lll_opy_ (u"ࠣࡽࢀ࠳ࡹ࡫ࡳࡵࡱࡵࡧ࡭࡫ࡳࡵࡴࡤࡸ࡮ࡵ࡮࠰ࡣࡳ࡭࠴ࡼ࠱࠰ࡨࡤ࡭ࡱ࡫ࡤ࠮ࡶࡨࡷࡹࡹࠢ᫷").format(bstack11l1l1l1l1l_opy_)
        self.bstack11l11llllll_opy_ = os.path.join(tempfile.gettempdir(), bstack1ll1lll_opy_ (u"ࠤࡤࡦࡴࡸࡴࡠࡤࡸ࡭ࡱࡪ࡟ࡼࡿࠥ᫸").format(os.environ.get(bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚ࡈࡖࡄࡢ࡙࡚ࡏࡄࠨ᫹"))))
        self.bstack11l1l111lll_opy_ = os.path.join(tempfile.gettempdir(), bstack1ll1lll_opy_ (u"ࠦ࡫ࡧࡩ࡭ࡧࡧࡣࡹ࡫ࡳࡵࡵࡢࡿࢂ࠴ࡴࡹࡶࠥ᫺").format(os.environ.get(bstack1ll1lll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤ࡛ࡕࡊࡆࠪ᫻"))))
        self.bstack11l11llll1l_opy_ = 2
        self.bstack1lll1111_opy_ = bstack1lll1111_opy_
        self.config = config
        self.logger = bstack1ll1ll1111_opy_.get_logger(__name__, bstack1l1lll1l11_opy_)
        self.bstack11l1l11llll_opy_ = bstack11l1l11llll_opy_
        self.bstack11l1l11l11l_opy_ = False
        self.bstack11l1l111l11_opy_ = not (
                            os.environ.get(bstack1ll1lll_opy_ (u"ࠨࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡈࡕࡊࡎࡇࡣࡗ࡛ࡎࡠࡋࡇࡉࡓ࡚ࡉࡇࡋࡈࡖࠧ᫼")) and
                            os.environ.get(bstack1ll1lll_opy_ (u"ࠢࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡎࡐࡆࡈࡣࡎࡔࡄࡆ࡚ࠥ᫽")) and
                            os.environ.get(bstack1ll1lll_opy_ (u"ࠣࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡑࡗࡅࡑࡥࡎࡐࡆࡈࡣࡈࡕࡕࡏࡖࠥ᫾"))
                        )
        if bstack11lll1lll1_opy_.bstack11l11lllll1_opy_(config):
            self.bstack11l11llll1l_opy_ = bstack11lll1lll1_opy_.bstack11l1l1111ll_opy_(config, self.bstack11l1l11llll_opy_)
            self.bstack11l1l111111_opy_()
    def bstack11l1l11ll11_opy_(self):
        return bstack1ll1lll_opy_ (u"ࠤࡾࢁࡤࢁࡽࠣ᫿").format(self.config.get(bstack1ll1lll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭ᬀ")), os.environ.get(bstack1ll1lll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡆ࡚ࡏࡌࡅࡡࡕ࡙ࡓࡥࡉࡅࡇࡑࡘࡎࡌࡉࡆࡔࠪᬁ")))
    def bstack11l1l111l1l_opy_(self):
        try:
            if self.bstack11l1l111l11_opy_:
                return
            with self.lock:
                try:
                    with open(self.bstack11l1l111lll_opy_, bstack1ll1lll_opy_ (u"ࠧࡸࠢᬂ")) as f:
                        bstack11l11lll1l1_opy_ = set(line.strip() for line in f if line.strip())
                except FileNotFoundError:
                    bstack11l11lll1l1_opy_ = set()
                bstack11l1l111ll1_opy_ = bstack11l11lll1l1_opy_ - self.bstack11l1l11111l_opy_
                if not bstack11l1l111ll1_opy_:
                    return
                self.bstack11l1l11111l_opy_.update(bstack11l1l111ll1_opy_)
                data = {bstack1ll1lll_opy_ (u"ࠨࡦࡢ࡫࡯ࡩࡩ࡚ࡥࡴࡶࡶࠦᬃ"): list(self.bstack11l1l11111l_opy_), bstack1ll1lll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠥᬄ"): self.config.get(bstack1ll1lll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫᬅ")), bstack1ll1lll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡓࡷࡱࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠢᬆ"): os.environ.get(bstack1ll1lll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡅ࡙ࡎࡒࡄࡠࡔࡘࡒࡤࡏࡄࡆࡐࡗࡍࡋࡏࡅࡓࠩᬇ")), bstack1ll1lll_opy_ (u"ࠦࡵࡸ࡯࡫ࡧࡦࡸࡓࡧ࡭ࡦࠤᬈ"): self.config.get(bstack1ll1lll_opy_ (u"ࠬࡶࡲࡰ࡬ࡨࡧࡹࡔࡡ࡮ࡧࠪᬉ"))}
            response = bstack11ll111l111_opy_.bstack11l1l11l1ll_opy_(self.bstack11l1l11ll1l_opy_, data)
            if response.get(bstack1ll1lll_opy_ (u"ࠨࡳࡵࡣࡷࡹࡸࠨᬊ")) == 200:
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠢࡔࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࡰࡾࠦࡳࡦࡰࡷࠤ࡫ࡧࡩ࡭ࡧࡧࠤࡹ࡫ࡳࡵࡵ࠽ࠤࢀࢃࠢᬋ").format(data))
            else:
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠣࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡸ࡫࡮ࡥࠢࡩࡥ࡮ࡲࡥࡥࠢࡷࡩࡸࡺࡳ࠻ࠢࡾࢁࠧᬌ").format(response))
        except Exception as e:
            self.logger.debug(bstack1ll1lll_opy_ (u"ࠤࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥࡪࡵࡳ࡫ࡱ࡫ࠥࡹࡥ࡯ࡦ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩࠦࡴࡦࡵࡷࡷ࠿ࠦࡻࡾࠤᬍ").format(e))
    def bstack11l11lll1ll_opy_(self):
        if self.bstack11l1l111l11_opy_:
            with self.lock:
                try:
                    with open(self.bstack11l1l111lll_opy_, bstack1ll1lll_opy_ (u"ࠥࡶࠧᬎ")) as f:
                        bstack11l1l1111l1_opy_ = set(line.strip() for line in f if line.strip())
                    failed_count = len(bstack11l1l1111l1_opy_)
                except FileNotFoundError:
                    failed_count = 0
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠦࡕࡵ࡬࡭ࡧࡧࠤ࡫ࡧࡩ࡭ࡧࡧࠤࡹ࡫ࡳࡵࡵࠣࡧࡴࡻ࡮ࡵࠢࠫࡰࡴࡩࡡ࡭ࠫ࠽ࠤࢀࢃࠢᬏ").format(failed_count))
                if failed_count >= self.bstack11l11llll1l_opy_:
                    self.logger.info(bstack1ll1lll_opy_ (u"࡚ࠧࡨࡳࡧࡶ࡬ࡴࡲࡤࠡࡥࡵࡳࡸࡹࡥࡥࠢࠫࡰࡴࡩࡡ࡭ࠫ࠽ࠤࢀࢃࠠ࠿࠿ࠣࡿࢂࠨᬐ").format(failed_count, self.bstack11l11llll1l_opy_))
                    self.bstack11l1l11lll1_opy_(failed_count)
                    self.bstack11l1l11l11l_opy_ = True
            return
        try:
            response = bstack11ll111l111_opy_.bstack11l11lll1ll_opy_(bstack1ll1lll_opy_ (u"ࠨࡻࡾࡁࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࡂࢁࡽࠧࡤࡸ࡭ࡱࡪࡒࡶࡰࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷࡃࡻࡾࠨࡳࡶࡴࡰࡥࡤࡶࡑࡥࡲ࡫࠽ࡼࡿࠥᬑ").format(self.bstack11l1l11ll1l_opy_, self.config.get(bstack1ll1lll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠪᬒ")), os.environ.get(bstack1ll1lll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡃࡗࡌࡐࡉࡥࡒࡖࡐࡢࡍࡉࡋࡎࡕࡋࡉࡍࡊࡘࠧᬓ")), self.config.get(bstack1ll1lll_opy_ (u"ࠩࡳࡶࡴࡰࡥࡤࡶࡑࡥࡲ࡫ࠧᬔ"))))
            if response.get(bstack1ll1lll_opy_ (u"ࠥࡷࡹࡧࡴࡶࡵࠥᬕ")) == 200:
                failed_count = response.get(bstack1ll1lll_opy_ (u"ࠦ࡫ࡧࡩ࡭ࡧࡧࡘࡪࡹࡴࡴࡅࡲࡹࡳࡺࠢᬖ"), 0)
                self.logger.debug(bstack1ll1lll_opy_ (u"ࠧࡖ࡯࡭࡮ࡨࡨࠥ࡬ࡡࡪ࡮ࡨࡨࠥࡺࡥࡴࡶࡶࠤࡨࡵࡵ࡯ࡶ࠽ࠤࢀࢃࠢᬗ").format(failed_count))
                if failed_count >= self.bstack11l11llll1l_opy_:
                    self.logger.info(bstack1ll1lll_opy_ (u"ࠨࡔࡩࡴࡨࡷ࡭ࡵ࡬ࡥࠢࡦࡶࡴࡹࡳࡦࡦ࠽ࠤࢀࢃࠠ࠿࠿ࠣࡿࢂࠨᬘ").format(failed_count, self.bstack11l11llll1l_opy_))
                    self.bstack11l1l11lll1_opy_(failed_count)
                    self.bstack11l1l11l11l_opy_ = True
            else:
                self.logger.error(bstack1ll1lll_opy_ (u"ࠢࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡴࡲ࡬ࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡶࡨࡷࡹࡹ࠺ࠡࡽࢀࠦᬙ").format(response))
        except Exception as e:
            self.logger.error(bstack1ll1lll_opy_ (u"ࠣࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤࡩࡻࡲࡪࡰࡪࠤࡵࡵ࡬࡭࡫ࡱ࡫࠿ࠦࡻࡾࠤᬚ").format(e))
    def bstack11l1l11lll1_opy_(self, failed_count):
        with open(self.bstack11l11llllll_opy_, bstack1ll1lll_opy_ (u"ࠤࡺࠦᬛ")) as f:
            f.write(bstack1ll1lll_opy_ (u"ࠥࡘ࡭ࡸࡥࡴࡪࡲࡰࡩࠦࡣࡳࡱࡶࡷࡪࡪࠠࡢࡶࠣࡿࢂࡢ࡮ࠣᬜ").format(datetime.now()))
            f.write(bstack1ll1lll_opy_ (u"ࠦࡋࡧࡩ࡭ࡧࡧࠤࡹ࡫ࡳࡵࡵࠣࡧࡴࡻ࡮ࡵ࠼ࠣࡿࢂࡢ࡮ࠣᬝ").format(failed_count))
        self.logger.debug(bstack1ll1lll_opy_ (u"ࠧࡇࡢࡰࡴࡷࠤࡇࡻࡩ࡭ࡦࠣࡪ࡮ࡲࡥࠡࡥࡵࡩࡦࡺࡥࡥ࠼ࠣࡿࢂࠨᬞ").format(self.bstack11l11llllll_opy_))
    def bstack11l1l111111_opy_(self):
        def bstack11l11llll11_opy_():
            while not self.bstack11l1l11l11l_opy_:
                time.sleep(bstack11l1l11l111_opy_)
                self.bstack11l1l111l1l_opy_()
                self.bstack11l11lll1ll_opy_()
        bstack11l1l11l1l1_opy_ = threading.Thread(target=bstack11l11llll11_opy_, daemon=True)
        bstack11l1l11l1l1_opy_.start()