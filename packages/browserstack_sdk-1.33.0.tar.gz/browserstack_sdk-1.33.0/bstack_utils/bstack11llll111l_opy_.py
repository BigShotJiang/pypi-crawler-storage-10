# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
import os
import json
import logging
import datetime
import threading
from bstack_utils.helper import bstack11ll1l1ll1l_opy_, bstack1l111l1l_opy_, get_host_info, bstack111ll1l11ll_opy_, \
 bstack11ll1l1111_opy_, bstack11l1l1lll_opy_, error_handler, bstack11l11ll11l1_opy_, bstack1l11l1llll_opy_
import bstack_utils.accessibility as bstack1l11l1l1_opy_
from bstack_utils.bstack1llll111ll_opy_ import bstack11lll1lll1_opy_
from bstack_utils.bstack111ll1llll_opy_ import bstack11l11ll1l1_opy_
from bstack_utils.percy import bstack1l11l111_opy_
from bstack_utils.config import Config
bstack11l1l11l_opy_ = Config.bstack1l1l111l_opy_()
logger = logging.getLogger(__name__)
percy = bstack1l11l111_opy_()
@error_handler(class_method=False)
def bstack1llll11lll11_opy_(bs_config, bstack11ll11l1_opy_):
  try:
    data = {
        bstack1ll1lll_opy_ (u"࠭ࡦࡰࡴࡰࡥࡹ࠭⇮"): bstack1ll1lll_opy_ (u"ࠧ࡫ࡵࡲࡲࠬ⇯"),
        bstack1ll1lll_opy_ (u"ࠨࡲࡵࡳ࡯࡫ࡣࡵࡡࡱࡥࡲ࡫ࠧ⇰"): bs_config.get(bstack1ll1lll_opy_ (u"ࠩࡳࡶࡴࡰࡥࡤࡶࡑࡥࡲ࡫ࠧ⇱"), bstack1ll1lll_opy_ (u"ࠪࠫ⇲")),
        bstack1ll1lll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩ⇳"): bs_config.get(bstack1ll1lll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡒࡦࡳࡥࠨ⇴"), os.path.basename(os.path.abspath(os.getcwd()))),
        bstack1ll1lll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡤ࡯ࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩ⇵"): bs_config.get(bstack1ll1lll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩ⇶")),
        bstack1ll1lll_opy_ (u"ࠨࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭⇷"): bs_config.get(bstack1ll1lll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡅࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠬ⇸"), bstack1ll1lll_opy_ (u"ࠪࠫ⇹")),
        bstack1ll1lll_opy_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࡤࡧࡴࠨ⇺"): bstack1l11l1llll_opy_(),
        bstack1ll1lll_opy_ (u"ࠬࡺࡡࡨࡵࠪ⇻"): bstack111ll1l11ll_opy_(bs_config),
        bstack1ll1lll_opy_ (u"࠭ࡨࡰࡵࡷࡣ࡮ࡴࡦࡰࠩ⇼"): get_host_info(),
        bstack1ll1lll_opy_ (u"ࠧࡤ࡫ࡢ࡭ࡳ࡬࡯ࠨ⇽"): bstack1l111l1l_opy_(),
        bstack1ll1lll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪ࡟ࡳࡷࡱࡣ࡮ࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨ⇾"): os.environ.get(bstack1ll1lll_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡄࡘࡍࡑࡊ࡟ࡓࡗࡑࡣࡎࡊࡅࡏࡖࡌࡊࡎࡋࡒࠨ⇿")),
        bstack1ll1lll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࡢࡸࡪࡹࡴࡴࡡࡵࡩࡷࡻ࡮ࠨ∀"): os.environ.get(bstack1ll1lll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡖࡊࡘࡕࡏࠩ∁"), False),
        bstack1ll1lll_opy_ (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳࡥࡣࡰࡰࡷࡶࡴࡲࠧ∂"): bstack11ll1l1ll1l_opy_(),
        bstack1ll1lll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࠭∃"): bstack1llll11111ll_opy_(bs_config),
        bstack1ll1lll_opy_ (u"ࠧࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࡢࡨࡪࡺࡡࡪ࡮ࡶࠫ∄"): bstack1llll1111l1l_opy_(bstack11ll11l1_opy_),
        bstack1ll1lll_opy_ (u"ࠨࡲࡵࡳࡩࡻࡣࡵࡡࡰࡥࡵ࠭∅"): bstack1llll1111111_opy_(bs_config, bstack11ll11l1_opy_.get(bstack1ll1lll_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࡤࡻࡳࡦࡦࠪ∆"), bstack1ll1lll_opy_ (u"ࠪࠫ∇"))),
        bstack1ll1lll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳ࠭∈"): bstack11ll1l1111_opy_(bs_config),
        bstack1ll1lll_opy_ (u"ࠬࡺࡥࡴࡶࡢࡳࡷࡩࡨࡦࡵࡷࡶࡦࡺࡩࡰࡰࠪ∉"): bstack1llll111111l_opy_(bs_config)
    }
    return data
  except Exception as error:
    logger.error(bstack1ll1lll_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡺ࡬࡮ࡲࡥࠡࡥࡵࡩࡦࡺࡩ࡯ࡩࠣࡴࡦࡿ࡬ࡰࡣࡧࠤ࡫ࡵࡲࠡࡖࡨࡷࡹࡎࡵࡣ࠼ࠣࠤࢀࢃࠢ∊").format(str(error)))
    return None
def bstack1llll1111l1l_opy_(framework):
  return {
    bstack1ll1lll_opy_ (u"ࠧࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࡑࡥࡲ࡫ࠧ∋"): framework.get(bstack1ll1lll_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡳࡧ࡭ࡦࠩ∌"), bstack1ll1lll_opy_ (u"ࠩࡓࡽࡹ࡫ࡳࡵࠩ∍")),
    bstack1ll1lll_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰ࡜ࡥࡳࡵ࡬ࡳࡳ࠭∎"): framework.get(bstack1ll1lll_opy_ (u"ࠫ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ∏")),
    bstack1ll1lll_opy_ (u"ࠬࡹࡤ࡬ࡘࡨࡶࡸ࡯࡯࡯ࠩ∐"): framework.get(bstack1ll1lll_opy_ (u"࠭ࡳࡥ࡭ࡢࡺࡪࡸࡳࡪࡱࡱࠫ∑")),
    bstack1ll1lll_opy_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ−"): bstack1ll1lll_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨ∓"),
    bstack1ll1lll_opy_ (u"ࠩࡷࡩࡸࡺࡆࡳࡣࡰࡩࡼࡵࡲ࡬ࠩ∔"): framework.get(bstack1ll1lll_opy_ (u"ࠪࡸࡪࡹࡴࡇࡴࡤࡱࡪࡽ࡯ࡳ࡭ࠪ∕"))
  }
def bstack1llll111111l_opy_(bs_config):
  bstack1ll1lll_opy_ (u"ࠦࠧࠨࠊࠡࠢࡕࡩࡹࡻࡲ࡯ࡵࠣࡸ࡭࡫ࠠࡵࡧࡶࡸࠥࡵࡲࡤࡪࡨࡷࡹࡸࡡࡵ࡫ࡲࡲࠥࡪࡡࡵࡣࠣࡪࡴࡸࠠࡣࡷ࡬ࡰࡩࠦࡳࡵࡣࡵࡸ࠳ࠐࠠࠡࠤࠥࠦ∖")
  if not bs_config:
    return {}
  bstack111l1111l11_opy_ = bstack11lll1lll1_opy_(bs_config).bstack111l1111ll1_opy_(bs_config)
  return bstack111l1111l11_opy_
def bstack11l11l1l_opy_(bs_config, framework):
  bstack1ll1ll111_opy_ = False
  bstack111ll1l11_opy_ = False
  bstack1lll1lllllll_opy_ = False
  if bstack1ll1lll_opy_ (u"ࠬࡺࡵࡳࡤࡲࡗࡨࡧ࡬ࡦࠩ∗") in bs_config:
    bstack1lll1lllllll_opy_ = True
  elif bstack1ll1lll_opy_ (u"࠭ࡡࡱࡲࠪ∘") in bs_config:
    bstack1ll1ll111_opy_ = True
  else:
    bstack111ll1l11_opy_ = True
  bstack11l1l1l1ll_opy_ = {
    bstack1ll1lll_opy_ (u"ࠧࡰࡤࡶࡩࡷࡼࡡࡣ࡫࡯࡭ࡹࡿࠧ∙"): bstack11l11ll1l1_opy_.bstack1llll111l11l_opy_(bs_config, framework),
    bstack1ll1lll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨ√"): bstack1l11l1l1_opy_.bstack1lll11l11l_opy_(bs_config),
    bstack1ll1lll_opy_ (u"ࠩࡳࡩࡷࡩࡹࠨ∛"): bs_config.get(bstack1ll1lll_opy_ (u"ࠪࡴࡪࡸࡣࡺࠩ∜"), False),
    bstack1ll1lll_opy_ (u"ࠫࡦࡻࡴࡰ࡯ࡤࡸࡪ࠭∝"): bstack111ll1l11_opy_,
    bstack1ll1lll_opy_ (u"ࠬࡧࡰࡱࡡࡤࡹࡹࡵ࡭ࡢࡶࡨࠫ∞"): bstack1ll1ll111_opy_,
    bstack1ll1lll_opy_ (u"࠭ࡴࡶࡴࡥࡳࡸࡩࡡ࡭ࡧࠪ∟"): bstack1lll1lllllll_opy_
  }
  return bstack11l1l1l1ll_opy_
@error_handler(class_method=False)
def bstack1llll11111ll_opy_(bs_config):
  try:
    bstack1llll1111l11_opy_ = json.loads(os.getenv(bstack1ll1lll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡣࡆࡉࡃࡆࡕࡖࡍࡇࡏࡌࡊࡖ࡜ࡣࡈࡕࡎࡇࡋࡊ࡙ࡗࡇࡔࡊࡑࡑࡣ࡞ࡓࡌࠨ∠"), bstack1ll1lll_opy_ (u"ࠨࡽࢀࠫ∡")))
    bstack1llll1111l11_opy_ = bstack1lll1llllll1_opy_(bs_config, bstack1llll1111l11_opy_)
    return {
        bstack1ll1lll_opy_ (u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶࠫ∢"): bstack1llll1111l11_opy_
    }
  except Exception as error:
    logger.error(bstack1ll1lll_opy_ (u"ࠥࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡷࡩ࡫࡯ࡩࠥࡩࡲࡦࡣࡷ࡭ࡳ࡭ࠠࡨࡧࡷࡣࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࡣࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸࠦࡦࡰࡴࠣࡘࡪࡹࡴࡉࡷࡥ࠾ࠥࠦࡻࡾࠤ∣").format(str(error)))
    return {}
def bstack1lll1llllll1_opy_(bs_config, bstack1llll1111l11_opy_):
  if ((bstack1ll1lll_opy_ (u"ࠫࡹࡻࡲࡣࡱࡖࡧࡦࡲࡥࠨ∤") in bs_config or not bstack11ll1l1111_opy_(bs_config)) and bstack1l11l1l1_opy_.bstack1lll11l11l_opy_(bs_config)):
    bstack1llll1111l11_opy_[bstack1ll1lll_opy_ (u"ࠧ࡯࡮ࡤ࡮ࡸࡨࡪࡋ࡮ࡤࡱࡧࡩࡩࡋࡸࡵࡧࡱࡷ࡮ࡵ࡮ࠣ∥")] = True
  return bstack1llll1111l11_opy_
def bstack1llll11l1l11_opy_(array, bstack1lll1lllll11_opy_, bstack1llll1111lll_opy_):
  result = {}
  for o in array:
    key = o[bstack1lll1lllll11_opy_]
    result[key] = o[bstack1llll1111lll_opy_]
  return result
def bstack1llll111ll1l_opy_(bstack111lll1l_opy_=bstack1ll1lll_opy_ (u"࠭ࠧ∦")):
  bstack1lll1lllll1l_opy_ = bstack1l11l1l1_opy_.on()
  bstack1llll1111ll1_opy_ = bstack11l11ll1l1_opy_.on()
  bstack1llll111l111_opy_ = percy.bstack11ll1l11ll_opy_()
  if bstack1llll111l111_opy_ and not bstack1llll1111ll1_opy_ and not bstack1lll1lllll1l_opy_:
    return bstack111lll1l_opy_ not in [bstack1ll1lll_opy_ (u"ࠧࡄࡄࡗࡗࡪࡹࡳࡪࡱࡱࡇࡷ࡫ࡡࡵࡧࡧࠫ∧"), bstack1ll1lll_opy_ (u"ࠨࡎࡲ࡫ࡈࡸࡥࡢࡶࡨࡨࠬ∨")]
  elif bstack1lll1lllll1l_opy_ and not bstack1llll1111ll1_opy_:
    return bstack111lll1l_opy_ not in [bstack1ll1lll_opy_ (u"ࠩࡋࡳࡴࡱࡒࡶࡰࡖࡸࡦࡸࡴࡦࡦࠪ∩"), bstack1ll1lll_opy_ (u"ࠪࡌࡴࡵ࡫ࡓࡷࡱࡊ࡮ࡴࡩࡴࡪࡨࡨࠬ∪"), bstack1ll1lll_opy_ (u"ࠫࡑࡵࡧࡄࡴࡨࡥࡹ࡫ࡤࠨ∫")]
  return bstack1lll1lllll1l_opy_ or bstack1llll1111ll1_opy_ or bstack1llll111l111_opy_
@error_handler(class_method=False)
def bstack1llll11ll111_opy_(bstack111lll1l_opy_, test=None):
  bstack1llll11111l1_opy_ = bstack1l11l1l1_opy_.on()
  if not bstack1llll11111l1_opy_ or bstack111lll1l_opy_ not in [bstack1ll1lll_opy_ (u"࡚ࠬࡥࡴࡶࡕࡹࡳࡌࡩ࡯࡫ࡶ࡬ࡪࡪࠧ∬")] or test == None:
    return None
  return {
    bstack1ll1lll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࠭∭"): bstack1llll11111l1_opy_ and bstack11l1l1lll_opy_(threading.current_thread(), bstack1ll1lll_opy_ (u"ࠧࡢ࠳࠴ࡽࡕࡲࡡࡵࡨࡲࡶࡲ࠭∮"), None) == True and bstack1l11l1l1_opy_.bstack11l1l11ll1_opy_(test[bstack1ll1lll_opy_ (u"ࠨࡶࡤ࡫ࡸ࠭∯")])
  }
def bstack1llll1111111_opy_(bs_config, framework):
  bstack1ll1ll111_opy_ = False
  bstack111ll1l11_opy_ = False
  bstack1lll1lllllll_opy_ = False
  if bstack1ll1lll_opy_ (u"ࠩࡷࡹࡷࡨ࡯ࡔࡥࡤࡰࡪ࠭∰") in bs_config:
    bstack1lll1lllllll_opy_ = True
  elif bstack1ll1lll_opy_ (u"ࠪࡥࡵࡶࠧ∱") in bs_config:
    bstack1ll1ll111_opy_ = True
  else:
    bstack111ll1l11_opy_ = True
  bstack11l1l1l1ll_opy_ = {
    bstack1ll1lll_opy_ (u"ࠫࡴࡨࡳࡦࡴࡹࡥࡧ࡯࡬ࡪࡶࡼࠫ∲"): bstack11l11ll1l1_opy_.bstack1llll111l11l_opy_(bs_config, framework),
    bstack1ll1lll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠬ∳"): bstack1l11l1l1_opy_.bstack111lll11_opy_(bs_config),
    bstack1ll1lll_opy_ (u"࠭ࡰࡦࡴࡦࡽࠬ∴"): bs_config.get(bstack1ll1lll_opy_ (u"ࠧࡱࡧࡵࡧࡾ࠭∵"), False),
    bstack1ll1lll_opy_ (u"ࠨࡣࡸࡸࡴࡳࡡࡵࡧࠪ∶"): bstack111ll1l11_opy_,
    bstack1ll1lll_opy_ (u"ࠩࡤࡴࡵࡥࡡࡶࡶࡲࡱࡦࡺࡥࠨ∷"): bstack1ll1ll111_opy_,
    bstack1ll1lll_opy_ (u"ࠪࡸࡺࡸࡢࡰࡵࡦࡥࡱ࡫ࠧ∸"): bstack1lll1lllllll_opy_
  }
  return bstack11l1l1l1ll_opy_