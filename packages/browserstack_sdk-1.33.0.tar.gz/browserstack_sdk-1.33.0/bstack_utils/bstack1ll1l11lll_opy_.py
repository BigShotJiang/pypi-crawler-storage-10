# coding: UTF-8
import sys
bstack1111_opy_ = sys.version_info [0] == 2
bstack1ll1l11_opy_ = 2048
bstack11llll_opy_ = 7
def bstack1ll1lll_opy_ (bstack11111_opy_):
    global bstack1l1l1_opy_
    bstack1lllll1l_opy_ = ord (bstack11111_opy_ [-1])
    bstack111lll1_opy_ = bstack11111_opy_ [:-1]
    bstack1l1ll_opy_ = bstack1lllll1l_opy_ % len (bstack111lll1_opy_)
    bstack1l11ll_opy_ = bstack111lll1_opy_ [:bstack1l1ll_opy_] + bstack111lll1_opy_ [bstack1l1ll_opy_:]
    if bstack1111_opy_:
        bstack11l1111_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    else:
        bstack11l1111_opy_ = str () .join ([chr (ord (char) - bstack1ll1l11_opy_ - (bstack1l1l111_opy_ + bstack1lllll1l_opy_) % bstack11llll_opy_) for bstack1l1l111_opy_, char in enumerate (bstack1l11ll_opy_)])
    return eval (bstack11l1111_opy_)
class bstack1111l1ll_opy_:
    def __init__(self, handler):
        self._1lllll11ll11_opy_ = None
        self.handler = handler
        self._1lllll11l1ll_opy_ = self.bstack1lllll11l11l_opy_()
        self.patch()
    def patch(self):
        self._1lllll11ll11_opy_ = self._1lllll11l1ll_opy_.execute
        self._1lllll11l1ll_opy_.execute = self.bstack1lllll11l1l1_opy_()
    def bstack1lllll11l1l1_opy_(self):
        def execute(this, driver_command, *args, **kwargs):
            self.handler(bstack1ll1lll_opy_ (u"ࠣࡤࡨࡪࡴࡸࡥࠣ‷"), driver_command, None, this, args)
            response = self._1lllll11ll11_opy_(this, driver_command, *args, **kwargs)
            self.handler(bstack1ll1lll_opy_ (u"ࠤࡤࡪࡹ࡫ࡲࠣ‸"), driver_command, response)
            return response
        return execute
    def reset(self):
        self._1lllll11l1ll_opy_.execute = self._1lllll11ll11_opy_
    @staticmethod
    def bstack1lllll11l11l_opy_():
        from selenium.webdriver.remote.webdriver import WebDriver
        return WebDriver