# @Coding: UTF-8
# @Time: 2024/9/22 2:26
# @Author: xieyang_ls
# @Filename: color.py

# 黑色
BLACK = "\033[30m"

# 红色
RED = "\033[31m"

# 绿色
GREEN = "\033[32m"

# 黄色
YELLOW = "\033[33m"

# 蓝色
BLUE = "\033[34m"

# 洋红色
MAGENTA = "\033[35m"

# 青色
CYAN = "\033[36m"

# 白色
WHITE = "\033[37m"

# 默认颜色
RESET = "\033[0m"
