# @Coding: UTF-8
# @Time: 2024/9/14 21:51
# @Author: xieyang_ls
# @Filename: __init__.py.py

from pyutils_spirit.annotation.interpreter import connection, get_instance_signature, singleton

__all__ = ['connection',
           'get_instance_signature',
           'singleton']
