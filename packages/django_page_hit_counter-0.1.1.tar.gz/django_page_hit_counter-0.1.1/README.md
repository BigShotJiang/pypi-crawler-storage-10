# django-page-hit-counter

Simple Django app that counts page hits per path.
-@drnimishadavis