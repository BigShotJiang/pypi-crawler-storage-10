from django.apps import AppConfig
class PageHitCounterConfig(AppConfig):
    name = "django_page_hit_counter"
    verbose_name = "Django Page Hit Counter"
