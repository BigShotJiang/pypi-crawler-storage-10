__version__ = "0.1.1"
default_app_config = "django_page_hit_counter.apps.PageHitCounterConfig"
