"""
Python thin wrapper generator.
"""

from .generator import PythonThinGenerator

__all__ = ["PythonThinGenerator"]
