"""
Messages API endpoints for chat functionality.
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List
from datetime import datetime

# Import authentication decorators from base
try:
    from src.auth_decorators import require_auth
except ImportError:
    # Fallback if running in different context
    def require_auth(func):
        return func

router = APIRouter()

# Simple in-memory message history
message_history: List[dict] = []


class ChatMessage(BaseModel):
    """Chat message model."""
    content: str
    sender: str = "user"


@router.get("/")
@require_auth
async def get_all_messages():
    """Get all messages from history."""
    return {"messages": message_history}


@router.post("/")
@require_auth
async def post_message(message: ChatMessage):
    """Post a new message to the chat."""
    new_message = {
        "id": len(message_history) + 1,
        "content": message.content,
        "sender": message.sender,
        "timestamp": datetime.utcnow().isoformat()
    }
    
    message_history.append(new_message)
    
    return {
        "status": "success",
        "message": new_message
    }


@router.delete("/")
async def clear_messages():
    """Clear all messages from history."""
    global message_history
    message_history = []
    return {"status": "success", "message": "Chat history cleared"}


@router.get("/count")
async def get_message_count():
    """Get the total number of messages."""
    return {
        "count": len(message_history),
        "user_messages": len([m for m in message_history if m["sender"] == "user"]),
        "assistant_messages": len([m for m in message_history if m["sender"] == "assistant"])
    }
