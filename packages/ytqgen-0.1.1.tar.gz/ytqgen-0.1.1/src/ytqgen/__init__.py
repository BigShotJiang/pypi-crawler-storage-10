"""
YtQGen - YouTube to Questionnaire Generator

A Python library for converting educational videos into interactive learning materials.
Transcribes, summarizes, and generates questionnaires from video/audio content.
"""

__version__ = "0.1.1"
__author__ = "YtQGen Contributors"

# Public API - use lazy imports to avoid loading config before CLI can set environment
__all__ = [
    "process_stream",
    "LLM_PROVIDER",
    "TRANSCRIPTION_PROVIDER",
    "OPENAI_MODEL",
    "MISTRAL_MODEL",
    "GROQ_MODEL",
]


def __getattr__(name):
    """Lazy import to avoid loading config/pipeline before CLI sets environment."""
    if name == "process_stream":
        from .pipeline import process_stream
        return process_stream
    elif name in ["LLM_PROVIDER", "TRANSCRIPTION_PROVIDER", "OPENAI_MODEL", "MISTRAL_MODEL", "GROQ_MODEL"]:
        from .config import (
            LLM_PROVIDER,
            TRANSCRIPTION_PROVIDER,
            OPENAI_MODEL,
            MISTRAL_MODEL,
            GROQ_MODEL,
        )
        return locals()[name]
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
