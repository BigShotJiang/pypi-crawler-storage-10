# YtQGen - YouTube to Questionnaire Generator

A powerful pipeline that converts YouTube videos into structured educational questionnaires using AI.

## 🚀 Features

- **Multi-Provider Support**: Works with OpenAI, Mistral, and Groq APIs
- **Automatic Transcription**: Uses Whisper API (OpenAI or Groq) for accurate audio transcription
- **Smart Summarization**: Handles long transcriptions with intelligent chunking
- **Questionnaire Generation**: Creates diverse question types (MCQ, open-ended, scenario-based)
- **PDF Export**: Generates professionally formatted PDF questionnaires

## 📋 Prerequisites

- Python 3.8+
- API keys for at least one provider:
  - [OpenAI API Key](https://platform.openai.com/api-keys)
  - [Mistral API Key](https://console.mistral.ai/)
  - [Groq API Key](https://console.groq.com/)
- **No external ffmpeg installation needed!** PyAV includes FFmpeg bindings automatically.

## 🛠️ Installation

1. **Clone the repository**
```bash
git clone <your-repo-url>
cd YtQGen
```

2. **Install dependencies**
```bash
pip install -r requirements.txt
```

This will install PyAV which includes FFmpeg bindings - no need to install ffmpeg separately!

3. **Set up environment variables**

Create a `.env` file in the project root (copy from `.env.example`):
```bash
cp .env.example .env
```

Edit `.env` and add your API keys:
```env
LLM_PROVIDER=openai
TRANSCRIPTION_PROVIDER=openai
OPENAI_API_KEY=your-actual-api-key-here
```

Alternatively, set environment variables directly:
```bash
# Windows (PowerShell)
$env:OPENAI_API_KEY="your-api-key-here"
$env:LLM_PROVIDER="openai"

# Windows (CMD)
set OPENAI_API_KEY=your-api-key-here
set LLM_PROVIDER=openai

# Linux/Mac
export OPENAI_API_KEY="your-api-key-here"
export LLM_PROVIDER="openai"
```

## 🎯 Usage

### Basic Usage

```python
from src.pipeline import process_stream

youtube_url = "https://www.youtube.com/watch?v=YOUR_VIDEO_ID"
pdf_file = process_stream(youtube_url, output_pdf="questionnaire.pdf")
```

### Run the Example

```bash
python main.py
```

### Configuration Options

Edit `src/config.py` to customize:

- **LLM Models**:
  - OpenAI: `gpt-4o-mini`, `gpt-4`, `gpt-3.5-turbo`
  - Mistral: `mistral-large-latest`, `mistral-medium`, `mistral-small`
  - Groq: `llama-3.1-70b-versatile`, `mixtral-8x7b-32768`

- **Processing Parameters**:
  - `MAX_WORDS_PER_CHUNK`: Chunk size for long transcriptions
  - `LLM_TEMPERATURE`: Creativity level (0.0-1.0)
  - `LLM_MAX_TOKENS`: Maximum output length

## 📁 Project Structure

```
YtQGen/
├── src/
│   ├── __init__.py              # Package initialization
│   ├── config.py                # Configuration settings
│   ├── audio_processor.py       # YouTube audio download
│   ├── transcription.py         # Whisper API transcription
│   ├── summarizer.py            # Text summarization
│   ├── model_loader.py          # API client initialization
│   ├── questionnaire_generator.py # Question generation
│   ├── pdf_generator.py         # PDF creation
│   └── pipeline.py              # Main orchestrator
├── main.py                      # Entry point
├── requirements.txt             # Python dependencies
├── .env.example                 # Environment variables template
└── README.md                    # This file
```

## 🔧 Supported Providers

### OpenAI
- **LLM**: GPT-4o-mini, GPT-4, GPT-3.5-turbo
- **Transcription**: Whisper API
- **Best for**: High quality, most reliable

### Mistral
- **LLM**: Mistral Large, Medium, Small
- **Transcription**: Voxtral (mini-latest model)
- **Best for**: European data compliance, cost-effective

### Groq
- **LLM**: Llama 3.1, Mixtral
- **Transcription**: Whisper Large v3
- **Best for**: Speed, open-source models, generous free tier

## 📝 Generated Questionnaire Format

The generated questionnaire includes:
1. **3 Simple MCQs** - Basic comprehension (4 options each)
2. **1 Moderate MCQ** - Intermediate difficulty (4 options)
3. **2 Simple Open-ended** - Short answer questions
4. **3 Moderate Open-ended** - Detailed response questions
5. **1 Hard Scenario-based** - Complex application question

## 💡 Tips

- **For long videos**: The pipeline automatically chunks transcriptions
- **API costs**: Groq offers generous free tier, OpenAI charges per token
- **Quality vs Speed**: OpenAI GPT-4 > GPT-3.5; Groq is fastest
- **Transcription options**: 
  - OpenAI Whisper: Most accurate, pay per minute
  - Groq Whisper: Very fast, generous free tier
  - Mistral Voxtral: Good quality, European compliance

## 🐛 Troubleshooting

**Error: API key not set**
```bash
# Make sure you've set the environment variable
echo $OPENAI_API_KEY  # Linux/Mac
echo %OPENAI_API_KEY%  # Windows CMD
```

**Error: yt-dlp download failed**
```bash
# Update yt-dlp
pip install --upgrade yt-dlp
```

**Import errors**
```bash
# Reinstall dependencies
pip install -r requirements.txt --force-reinstall
```

## 📄 License

MIT License - feel free to use and modify as needed.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📧 Support

For issues, questions, or suggestions, please open an issue on GitHub
