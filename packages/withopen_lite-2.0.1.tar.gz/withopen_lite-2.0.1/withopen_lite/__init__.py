"""
WITHOPEN PACKAGE
----------------
A simple interface for reading, writing, and appending structured text files.
All logic is contained in main.py.
"""

from .main import r, w, a

__all__ = ["r", "w", "a"]
