from importlib.resources import files
from pathlib import Path

from fastapi import HTTPException
from pydantic_settings import BaseSettings

BASE_PATH = Path(__file__).parent.parent.parent


class ServerSettings(BaseSettings):
    working_data_path: Path = BASE_PATH / "working-data"


def read_settings() -> ServerSettings:
    settings = ServerSettings()
    if not settings.working_data_path.exists():
        print(settings.working_data_path)
        raise HTTPException(
            status_code=500, detail="server error: data path does not exist"
        )
    return settings
