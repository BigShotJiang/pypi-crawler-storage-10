def hello() -> str:
    return "Hello from code-aster-whale!"
