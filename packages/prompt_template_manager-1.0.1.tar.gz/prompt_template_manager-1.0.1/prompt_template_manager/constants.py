import re

"""
A general regex to find any text enclosed in curly braces {}.
It is non-greedy (.*?), so it will match the shortest possible span
e.g., in "{var1} {var2}", it will match "{var1}" and "{var2}" separately.
Example matches: "{variable}", "{include file.txt}", "{ complex_{expr} }"
"""
VARIABLE_REGEX = re.compile(r"(\{.*?\})")

"""
A strict regex to find and capture valid variable names enclosed in curly braces.
A valid variable name is defined as:
1. A single letter: e.g., {a}
2. A name starting with a letter, optionally followed by letters, numbers,
   underscores, or hyphens, and ending in a letter or number.
This ensures names like {my-var} and {var1} are valid, but {my-var-} or {_var}
are not. The parentheses ( ) create a capturing group for the name itself.
Example matches: "{name}", "{user_name}", "{var-1}"
Capturing group examples: "name", "user_name", "var-1"
"""
VALID_VARIABLE_NAME_REGEX = re.compile(r"\{([a-zA-Z]|[a-zA-Z][\w-]*[a-zA-Z0-9])\}")

"""
A regex to find "include" directives.
It matches the literal "{include", followed by one or more whitespace
characters (\s+), followed by any characters non-greedily (.+?),
and ending with a "}".
Example matches: "{include my_prompt}", "{include path/to/file.txt}"
"""
INCLUDE_REGEX = re.compile(r"\{include\s+.+?\}")

"""
A strict regex to find and capture valid "include" directives.
This is similar to VALID_VARIABLE_NAME_REGEX but ensures the content
is prefixed by "include ". It validates that the name of the item
to be included follows the same rules as a valid variable name.
The parentheses ( ) create a capturing group for the included name.
Example matches: "{include my_prompt}", "{include other-prompt-1}"
Capturing group examples: "my_prompt", "other-prompt-1"
"""
VALID_INCLUDE_NAME_REGEX = re.compile(r"\{include ([a-zA-Z]|[a-zA-Z][\w-]*[a-zA-Z0-9])\}")

"""
A regex to validate a string as a valid prompt name.
The name must:
- Start with a letter (a-z, A-Z) or an underscore (_)
- Be followed by zero or more letters, numbers, or underscores.
This pattern is equivalent to a valid Python identifier.
Example matches: "my_prompt", "prompt_1", "_internal"
Example non-matches: "1_prompt", "my-prompt"
"""
VALID_PROMPT_NAME_REGEX = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")

"""
A regex to validate a version key string.
The string must:
- Start with the literal character 'v'.
- Be followed by one or more digits (\d+).
- Cover the entire string (from ^ to $).
Example matches: "v1", "v123"
Example non-matches: "v", "v1.0", "version1"
"""
VALID_VERSION_KEY_REGEX = re.compile(r"^v\d+$")