import logging
from typing import Dict, Tuple, List, Any
import yaml
import re
from pathlib import Path
from Prompt import Prompt  # Assuming Prompt class is in a file named Prompt.py
import constants  # Assuming constants.py holds the regex definitions

# Set up a logger for this module
logger = logging.getLogger(f"{__name__}.PromptManager")


class PromptManager:
    """
    Manages loading, validation, and retrieval of prompts.

    Loads prompt configurations from a directory of .txt files
    or from a single, structured .yaml file. It handles prompt versioning,
    metadata, and resolving `{include ...}` directives.

    Attributes:
        prompts (dict[str, dict]): A dictionary holding all loaded prompt
            configurations. The keys are prompt names, and the values are
            either the prompt string (for .txt files) or a dictionary
            (for versioned prompts from YAML).
    """

    def __init__(self, source_path: str | Path):
        """
        Initializes the PromptManager by loading prompts from the prompt_template_manager.

        Args:
            source_path (str | Path): The path to a directory of .txt files
                or a single .yaml configuration file.

        Raises:
            FileNotFoundError: If the source_path does not exist.
            ValueError: If the source_path is not a file or directory,
                or if a file is not a valid .yaml/.yml file.
        """
        self.prompts: dict[str, dict] = {}
        source = Path(source_path)

        if not source.exists():
            msg = f"Source path not found: {source}"
            logger.error(msg)
            raise FileNotFoundError(msg)

        # Load prompts based on whether the path is a directory or file
        if source.is_dir():
            self._load_from_directory(source)
        elif source.is_file():
            self._load_from_file(source)
        else:
            msg = f"Source path is not a valid file or directory: {source}"
            logger.error(msg)
            raise ValueError(msg)

    def _load_from_directory(self, dir_path: Path):
        """
        Loads all .txt files from a directory.

        Each file is treated as a single prompt. The filename (without
        the .txt extension) becomes the prompt name. These prompts are
        automatically assigned a 'v1' and set as the '_default'.

        Args:
            dir_path (Path): The directory to scan for .txt files.
        """
        logger.info(f"Loading prompts from directory: {dir_path}")
        for file_path in dir_path.glob("*.txt"):
            prompt_name = file_path.stem  # Filename without extension
            with open(file_path, 'r') as f:
                content = f.read()
                # Store in the same versioned format as YAML for consistency
                self.prompts[prompt_name] = {"_default": "v1", "v1": content}
        logger.info(f"Loaded {len(self.prompts)} prompts.")

    def _load_from_file(self, file_path: Path):
        """
        Loads and validates prompts from a single YAML file.

        Args:
            file_path (Path): The path to the .yaml or .yml file.

        Raises:
            ValueError: If the file is not .yaml/.yml, or if the
                configuration data is invalid.
            yaml.YAMLError: If the YAML file is malformed.
        """
        # Enforce YAML file extension
        if file_path.suffix not in ['.yaml', '.yml']:
            msg = f"Invalid file extenstion. Only .yaml or .yml files are supported"
            logger.error(msg)
            raise ValueError(msg)

        logger.info(f"Loading prompts from file: {file_path}")
        with open(file_path, 'r') as f:
            try:
                # Load the raw data from the YAML file
                data = yaml.safe_load(f)

                # Validate the structure of the loaded data
                is_valid, errors = PromptManager.validate_prompt_config(data)

                if is_valid:
                    # If valid, store the prompts
                    for prompt_name, content in data.items():
                        self.prompts[prompt_name] = content
                    logger.info(f"Loaded {len(self.prompts)} prompt configurations.")
                else:
                    # If invalid, compile errors and raise
                    msg = f"Invalid prompt configuration in {file_path}:"
                    for error in errors:
                        msg += f"\n\t- {error}"
                    logger.error(msg)
                    raise ValueError(msg)
            except yaml.YAMLError as e:
                # Handle cases where the YAML itself is malformed
                raise e

    def _resolve_includes(self, prompt_name: str, content: str) -> str:
        """
        Recursively finds and replaces all {include ...} directives.

        This method uses an inner recursive function to traverse the
        dependency graph and detect circular references.

        Args:
            prompt_name (str): The name of the root prompt (for logging).
            content (str): The raw prompt content to resolve.

        Raises:
            ValueError: If an {include} directive is invalid or a
                prompt to be included is not found.
            ImportError: If a circular reference is detected.

        Returns:
            str: The prompt content with all {include} directives resolved.
        """

        def _recursive_resolver(_prompt_name: str, _content: str, _visited: list[str]) -> str:
            """
            Inner recursive function to handle nested includes.

            Args:
                _prompt_name (str): The name of the *current* prompt being resolved.
                _content (str): The content of the current prompt.
                _visited (list[str]): The path of prompts visited to reach this
                    point, used for circular dependency detection.

            Returns:
                str: The fully resolved content for this branch.
            """
            # We use a 'while' loop because an included string might
            # contain new includes that need to be found and resolved.
            while True:
                # 1. Find the next include in the current content
                includes = re.findall(constants.INCLUDE_REGEX, _content)

                # 2. Base Case: No includes found, content is fully resolved.
                if not includes:
                    break  # Exit the while loop

                # 3. Process one include at a time. We'll loop again.
                include_tag = includes[0]  # Get the full tag, e.g., "{include other_prompt}"

                include_name = ""
                try:
                    # Extract just the name, e.g., "other_prompt"
                    include_name = re.findall(constants.VALID_INCLUDE_NAME_REGEX, include_tag)[0]
                except IndexError:
                    is_valid = False
                else:
                    is_valid = bool(include_name)

                # Check if the extracted name is valid and exists in our registry
                if not is_valid or include_name not in self.prompts:
                    msg = f"'{include_tag}' is not a valid include in '{_prompt_name}'"
                    logger.error(msg)
                    raise ValueError(msg)

                # 4. Check for circular reference
                if include_name in _visited:
                    # Build the graph string: A -> B -> C -> A
                    dependency_graph = " -> ".join(_visited) + f" -> {include_name}"
                    msg = f"Circular reference detected when resolving '{include_name}'.\n\tDependency graph: {dependency_graph}"
                    logger.error(msg)
                    raise ImportError(msg)

                # 5. Get the content for the include
                include_content_data = self.prompts[include_name]
                content_to_resolve: str
                if isinstance(include_content_data, str):
                    # Simple (e.g., from .txt) or non-versioned YAML entry
                    content_to_resolve = include_content_data
                else:
                    # Handle versioned prompts
                    default_version = include_content_data.get("_default")
                    if not default_version:
                        msg = f"Prompt '{include_name}' (included by '{_prompt_name}') is versioned but has no '_default' key."
                        logger.error(msg)
                        raise ValueError(msg)
                    content_to_resolve = include_content_data[default_version]

                # 6. Create the NEW path for this specific recursive branch
                new_path = _visited + [include_name]

                # 7. Recurse first on the new content before injecting it.
                # This resolves nested includes (e.g., A includes B, B includes C).
                fully_resolved_include = _recursive_resolver(
                    include_name,
                    content_to_resolve,
                    new_path  # Pass the new, isolated path
                )

                # 8. Replace the include with its fully resolved content.
                # We use replace(..., 1) to only replace the first instance,
                # then let the 'while' loop find the next one.
                _content = _content.replace(include_tag, f"{fully_resolved_include}", 1)

            # 9. Return the fully resolved content for this level
            return _content

        # Start the resolution process with the initial prompt name
        visited: list[str] = [prompt_name]
        resolved_content = _recursive_resolver(prompt_name, content, visited)
        return resolved_content.strip()  # Clean up leading/trailing newlines

    @staticmethod
    def validate_prompt_config(config: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """
        Validates the entire prompt configuration dictionary.

        Checks that all top-level keys are valid prompt names and that their
        values are either a valid string or a valid versioned prompt dict.

        Args:
            config: The dictionary loaded from the YAML file.

        Returns:
            A tuple (is_valid, errors) where is_valid is a boolean and
            errors is a list of error messages.
        """
        if not isinstance(config, dict):
            return False, ["Configuration root must be a dictionary."]

        errors: List[str] = []

        # Loop over each top-level entry (e.g., 'system_persona_default')
        for prompt_name, value in config.items():

            # 1. Check top-level key (prompt name) format
            if not constants.VALID_PROMPT_NAME_REGEX.fullmatch(prompt_name):
                errors.append(
                    f"Invalid prompt name '{prompt_name}': Does not match the "
                    "required format (letters, numbers, underscores)."
                )
                # If key is bad, don't bother checking its value
                continue

            # 2. Check value type (must be string or dictionary)
            if isinstance(value, str):
                # This is a simple, non-versioned prompt.
                # Check for invalid variable/include syntax.
                variables = re.findall(constants.VARIABLE_REGEX, value)
                invalid_variables = []
                for variable in variables:
                    # A tag is valid if it's a {variable} OR {include ...}
                    is_var = constants.VALID_VARIABLE_NAME_REGEX.fullmatch(variable)
                    is_include = constants.INCLUDE_REGEX.fullmatch(variable)
                    if not is_var and not is_include:
                        invalid_variables.append(variable)
                if len(invalid_variables) > 0:
                    errors.append(
                        f"Error in '{prompt_name}': Invalid variable/tag syntax: ({', '.join(invalid_variables)})"
                    )
                continue  # This entry is processed

            elif isinstance(value, dict):
                # This is a "versioned prompt". It needs deeper validation.
                is_valid_versioned, version_errors = PromptManager.validate_versioned_prompt(prompt_name, value)
                if not is_valid_versioned:
                    errors.extend(version_errors)  # Add all errors from the sub-validation

            else:
                # Not a string, not a dictionary. This is an error.
                errors.append(
                    f"Invalid value for '{prompt_name}': Value must be a string or a "
                    f"dictionary, but found {type(value).__name__}."
                )

        is_valid = len(errors) == 0
        return is_valid, errors

    @staticmethod
    def validate_versioned_prompt(
            prompt_name: str, prompt_dict: Dict[str, Any]
    ) -> Tuple[bool, List[str]]:
        """
        Validates a single "versioned prompt" dictionary structure.

        A valid structure must contain:
          - `_default`: A string matching one of the version keys.
          - At least one version key (e.g., `v1`).
        It may optionally contain:
          - `_meta`: A dictionary of string key-value pairs.

        Args:
            prompt_name (str): The name of the prompt (for error messages).
            prompt_dict (Dict[str, Any]): The dictionary value to validate.

        Returns:
            A tuple (is_valid, errors) where is_valid is a boolean and
            errors is a list of error messages.
        """
        errors: List[str] = []

        # 1. Validate _default key existence
        if "_default" not in prompt_dict:
            errors.append(f"Error in '{prompt_name}': Missing required key '_default'.")

        # 2. Validate _meta key (if it exists)
        if "_meta" in prompt_dict:
            meta_val = prompt_dict["_meta"]
            if not isinstance(meta_val, dict):
                errors.append(
                    f"Error in '{prompt_name}': '_meta' must be a dictionary, "
                    f"but found {type(meta_val).__name__}."
                )
            else:
                # Check all keys/values within _meta are strings
                for mk, mv in meta_val.items():
                    if not isinstance(mk, str) or not isinstance(mv, str):
                        errors.append(
                            f"Error in '{prompt_name}._meta': All keys and values "
                            "must be strings."
                        )
                        break  # One error is enough for _meta

        # 3. Find all version keys and unknown keys
        version_keys: List[str] = []
        unknown_keys: List[str] = []

        for key in prompt_dict.keys():
            if key in ("_meta", "_default"):
                continue  # Already accounted for

            if constants.VALID_VERSION_KEY_REGEX.fullmatch(key):
                version_keys.append(key)
            else:
                unknown_keys.append(key)

        # 4. Report any unknown keys
        if unknown_keys:
            errors.append(
                f"Error in '{prompt_name}': Found unknown keys: {unknown_keys}. "
                "Only '_meta', '_default', and 'v{{number}}' are allowed."
            )

        # 5. Check if at least one version was found
        if not version_keys:
            errors.append(
                f"Error in '{prompt_name}': No version keys (e.g., 'v1', 'v2') "
                "found for this versioned prompt."
            )

        # 6. Validate the value (string) and syntax of each version key
        for v_key in version_keys:
            v_value = prompt_dict[v_key]
            if not isinstance(v_value, str):
                errors.append(
                    f"Error in '{prompt_name}.{v_key}': Version value must be a "
                    f"string, but found {type(v_value).__name__}."
                )
                continue  # Can't check variables if it's not a string

            # Check variable formats
            variables = re.findall(constants.VARIABLE_REGEX, v_value)
            invalid_variables = []
            for variable in variables:
                is_var = constants.VALID_VARIABLE_NAME_REGEX.fullmatch(variable)
                is_include = constants.INCLUDE_REGEX.fullmatch(variable)
                if not is_var and not is_include:
                    invalid_variables.append(variable)
            if len(invalid_variables) > 0:
                errors.append(
                    f"Error in '{prompt_name}.{v_key}': Invalid variable/tag syntax: ({', '.join(invalid_variables)})"
                )

        # 7. Validate _default value against found versions
        if "_default" in prompt_dict:
            default_val = prompt_dict["_default"]

            if not isinstance(default_val, str):
                errors.append(
                    f"Error in '{prompt_name}': '_default' value must be a "
                    f"string, but found {type(default_val).__name__}."
                )
            elif version_keys and default_val not in version_keys:
                # Only check this if versions were found, otherwise the
                # "no versions found" error (step 5) is more important.
                errors.append(
                    f"Error in '{prompt_name}': '_default' value '{default_val}' "
                    f"is not one of the defined versions: {version_keys}."
                )

        is_valid = len(errors) == 0
        return is_valid, errors

    def get(self, name: str, version: int | None = None) -> Prompt:
        """
        Retrieves a prompt by name and optional version.

        This method fetches the raw prompt, resolves any {include}
        directives, and returns an initialized `Prompt` object.

        Args:
            name (str): The name of the prompt to retrieve.
            version (int | None, optional): The specific version number
                to retrieve (e.g., 1, 2). If None, the default version
                is used.

        Raises:
            KeyError: If the prompt name or the specified version is not found.
            ValueError: If a version is requested for a non-versioned prompt.
            TypeError: If the prompt data is malformed (should be
                prevented by validation).

        Returns:
            Prompt: An initialized Prompt object ready for formatting.
        """
        try:
            # Get the top-level configuration for this prompt
            content_data = self.prompts[name]
        except KeyError:
            msg = f"Prompt '{name}' not found. Available: {list(self.prompts.keys())}"
            logger.error(msg)
            raise KeyError(msg) from None

        raw_prompt: str
        metadata: Dict[str, str]
        prompt_identifier: str = name  # For logging/error messages

        if isinstance(content_data, str):
            # Case 1: Simple, non-versioned prompt (e.g., from .txt or simple YAML)
            if version is not None:
                msg = f"Prompt '{name}' is not versioned; cannot get version {version}"
                logger.error(msg)
                raise ValueError(msg)
            raw_prompt = content_data
            metadata = {}

        elif isinstance(content_data, dict):
            # Case 2: Versioned prompt (from YAML or .txt)
            prompt_version_key: str
            try:
                if version is not None:
                    # User requested a specific version
                    prompt_version_key = f"v{version}"
                else:
                    # User wants the default version
                    prompt_version_key = content_data["_default"]  # Could raise KeyError

                # Retrieve the raw prompt string for that version
                raw_prompt = content_data[prompt_version_key]  # Could raise KeyError

                # Get metadata if it exists, otherwise default to empty dict
                metadata = content_data.get("_meta", {})

                prompt_identifier = f"{name} (version: {prompt_version_key})"

            except KeyError as e:
                # This handles missing '_default', missing version key, etc.
                msg = f"Could not find required version key for '{name}'. Missing key: {e}"
                logger.error(msg)
                raise KeyError(msg) from e
        else:
            # This should be impossible if validation passed
            msg = f"Unexpected data type for prompt '{name}': {type(content_data)}"
            logger.error(msg)
            raise TypeError(msg)

        # After retrieving the correct raw string, resolve its includes
        resolved_prompt = self._resolve_includes(prompt_identifier, raw_prompt)

        # Create and return the final Prompt object
        prompt = Prompt(resolved_prompt, metadata)
        return prompt