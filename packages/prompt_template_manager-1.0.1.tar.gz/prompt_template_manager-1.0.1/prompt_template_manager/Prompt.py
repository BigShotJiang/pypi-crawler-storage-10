import logging
import re
from typing import Dict, List, Self

import constants

# Set up a logger for this module, specific to Prompt operations
logger = logging.getLogger(f"{__name__}.Prompt")


class SafeDict(dict):
    """
    A dictionary subclass that handles missing keys gracefully for string formatting.

    When a key is missing during a lookup (e.g., in `str.format_map`),
    this class returns the key itself enclosed in curly braces,
    preserving it as a placeholder.
    """

    def __missing__(self, key):
        """
        Handles missing keys by returning them as a placeholder string.

        Args:
            key (any): The key that was not found in the dictionary.

        Returns:
            str: The key formatted as a string placeholder (e.g., "{key}").
        """
        # Return the key as its own placeholder
        return f'{{{key}}}'


class Prompt:
    """
    Manages a prompt template, its variables, and its metadata.

    This class provides a way to define a prompt with dynamic placeholders
    (variables), format them safely, and handle partial formatting.
    """

    def __init__(self, raw_content: str, metadata: Dict[str, str]):
        """
        Initializes the Prompt object.

        Args:
            raw_content (str): The raw template string containing
                               placeholders (e.g., "Hello, {name}").
            metadata (Dict[str, str]): A dictionary of key-value metadata.
        """
        self.__raw_prompt = raw_content
        self.__metadata = metadata
        # Parse and store variables upon initialization
        self.__variables = Prompt.parse_prompt_variables(raw_content)

    @staticmethod
    def parse_prompt_variables(raw_prompt) -> Dict[str, str | None]:
        """
        Parses a raw prompt string to find all variable placeholders.

        Uses a regex defined in `constants.VALID_VARIABLE_NAME_REGEX` to
        extract variable names.

        Args:
            raw_prompt (str): The template string to parse.

        Returns:
            Dict[str, str | None]: A dictionary where keys are the extracted
                                   variable names and values are None.
        """
        variables: Dict[str, str | None] = {}
        # Find all occurrences matching the variable regex
        parsed_variables: List[str] = re.findall(constants.VALID_VARIABLE_NAME_REGEX, raw_prompt)
        for variable in parsed_variables:
            # Store the cleaned variable name
            variables[variable.strip()] = None
        return variables

    def get_raw_content(self) -> str:
        """Returns the original, unformatted prompt string."""
        return self.__raw_prompt

    def get_variables(self) -> Dict[str, str | None]:
        """Returns a dictionary of variables recognized in the prompt."""
        return self.__variables

    def get_metadata(self) -> Dict[str, str]:
        """Returns the metadata dictionary associated with the prompt."""
        return self.__metadata

    def format(self, data: Dict[str, str | int | float | bool], strict: bool = True) -> str:
        """
        Formats the prompt string by substituting variables with provided data.

        Args:
            data (Dict[str, str | int | float | bool]): A dictionary where keys
                are variable names and values are the data to substitute.
            strict (bool, optional): If True (default), raises an Exception
                if `data` is missing any variables that were parsed from the
                prompt. If False, missing variables are replaced with an
                empty string.

        Raises:
            Exception: If `strict` is True and not all variables are provided
                       in the `data` dictionary.

        Returns:
            str: The formatted prompt string.
        """
        if strict:
            # Check for missing variables only if strict mode is enabled
            missing_variables: List[str] = []
            for key in self.__variables.keys():
                if key not in data:
                    missing_variables.append(key)

            # If any variables are missing, log an error and raise an exception
            if len(missing_variables) > 0:
                msg = "Strict mode is enabled but not all variables are present\n\tMissing variables: {}".format(
                    ", ".join(missing_variables))
                logger.error(msg)
                raise Exception(msg)

        # Prepare the data for formatting
        formatted_data: Dict[str, str] = {}
        for key in self.__variables.keys():
            value = data.get(key)
            # Default to empty string. if strict is enabled,
            # the earlier check would make sure that all variables are present and
            # none would default to an empty string.
            if value is None:
                value = ""
            # Ensure all values are strings for formatting
            formatted_data[key] = str(value)

        # Use standard string formatting with the prepared data
        formatted_prompt = self.__raw_prompt.format(**formatted_data)
        return formatted_prompt

    def partial(self, data: Dict[str, str | int | float | bool]) -> Self:
        """
        Partially formats the prompt, substituting only the provided variables.

        This method substitutes any variables present in `data` and leaves
        all other variables as placeholders in the raw string. It returns a
        new `Prompt` object with the partially formatted content.

        Args:
            data (Dict[str, str | int | float | bool]): A dictionary of
                variables to substitute.

        Returns:
            Prompt: A new `Prompt` instance with the partially formatted string.
        """
        # Use SafeDict to handle missing keys by leaving them as placeholders
        safe_data = SafeDict(data)
        # format_map is used with SafeDict to achieve partial substitution
        partially_formatted_prompt = self.__raw_prompt.format_map(safe_data)
        # Return a new Prompt object with the new content and original metadata
        return Prompt(partially_formatted_prompt, self.__metadata)