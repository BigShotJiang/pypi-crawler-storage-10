import re
import constants
from PromptManager import PromptManager

TestData = list[dict[str, str | bool]]

def test_regex() -> None:
    variables_test: TestData = [
        {"test": "{{name}}", "expected": True},
        {"test": "name", "expected": False},
        {"test": "{name}", "expected": False},
    ]
    variable_names_test: TestData = [
        {"test": "{{name}}", "expected": True},
        {"test": "{{na_me}}", "expected": True},
        {"test": "{{na-me}}", "expected": True},
        {"test": "{{_name}}", "expected": False},
        {"test": "{{-name}}", "expected": False},
        {"test": "{{na me}}", "expected": False},
        {"test": "{{na.me}}", "expected": False},
        {"test": "{{name_}}", "expected": False},
        {"test": "{{name-}}", "expected": False},
    ]
    includes_test: TestData = [
        # Basic cases
        {"test": "{{include header}}", "expected": True},
        {"test": "{{include footer}}", "expected": True},

        # Single-letter case
        {"test": "{{include n}}", "expected": True},
        {"test": "{{include Z}}", "expected": True},

        # Cases with underscores
        {"test": "{{include my_header}}", "expected": True},
        {"test": "{{include user_profile}}", "expected": True},

        # Cases with hyphens
        {"test": "{{include my-header}}", "expected": True},
        {"test": "{{include user-profile}}", "expected": True},

        # Cases with numbers
        {"test": "{{include header2}}", "expected": True},
        {"test": "{{include v2_header}}", "expected": True},
        {"test": "{{include user-profile-1}}", "expected": True},

        # Mixed/complex cases
        {"test": "{{include MyHeader_v2-light}}", "expected": True},
        {"test": "{{include section-1_block-A}}", "expected": True},

        # Edge case: multiple underscores/hyphens (allowed)
        {"test": "{{include my__header}}", "expected": True},
        {"test": "{{include my--header}}", "expected": True},
        {"test": "{{include my-header_with-extra--padding}}", "expected": True},

        # Rule 1 & 2: Invalid syntax (spacing, braces)
        {"test": "{{includename}}", "expected": False},  # Fails: Missing space
        {"test": "{{include  header}}", "expected": False},  # Fails: Too many spaces
        {"test": "{{ include header}}", "expected": False},  # Fails: Space before 'include'
        {"test": "{{include header }}", "expected": False},  # Fails: Space after name
        {"test": "{include header}}", "expected": False},  # Fails: Missing opening brace
        {"test": "{{include header}", "expected": False},  # Fails: Missing closing brace
        {"test": "include header", "expected": False},  # Fails: No braces
        {"test": "{{INCLUDE header}}", "expected": False},  # Fails: 'INCLUDE' in wrong case

        # Rule 3: Invalid starting character
        {"test": "{{include _header}}", "expected": False},  # Fails: Starts with underscore
        {"test": "{{include -header}}", "expected": False},  # Fails: Starts with hyphen
        {"test": "{{include 1header}}", "expected": False},  # Fails: Starts with number

        # Rule 5: Invalid ending character
        {"test": "{{include header_}}", "expected": False},  # Fails: Ends with underscore
        {"test": "{{include header-}}", "expected": False},  # Fails: Ends with hyphen
        {"test": "{{include my_header_v1-}}", "expected": False},  # Fails: Ends with hyphen

        # Rule 6: Invalid characters
        {"test": "{{include my header}}", "expected": False},  # Fails: Contains space
        {"test": "{{include header.html}}", "expected": False},  # Fails: Contains dot
        {"test": "{{include nav/main}}", "expected": False},  # Fails: Contains slash
        {"test": "{{include user@nav}}", "expected": False},  # Fails: Contains special char

        # Rule 6: Empty name
        {"test": "{{include}}", "expected": False},  # Fails: No name (and no space)
        {"test": "{{include }}", "expected": False},
    ]
    print("--- Variables ---")
    variables_test_results: list[bool] = []
    for variable in variables_test:
        test = variable["test"]
        check = bool(re.search(constants.VARIABLE_REGEX_PATTERN, test))
        passed = check == variable["expected"]
        variables_test_results.append(passed)
        # print(f"{test}: {passed}")
    num_passed = variables_test_results.count(True)
    print(f"{num_passed} / {len(variables_test_results)} tests passed")

    print("--- Variable Names ---")
    variable_names_test_results: list[bool] = []
    for variable in variable_names_test:
        test = variable["test"]
        check = bool(re.search(constants.VALID_VARIABLE_NAME_PATTERN, test))
        passed = check == variable["expected"]
        variable_names_test_results.append(passed)
        # print(f"{test}: {passed}")
    num_passed = variable_names_test_results.count(True)
    print(f"{num_passed} / {len(variable_names_test_results)} tests passed")

    print("--- Includes ---")
    includes_test_results: list[bool] = []
    for include in includes_test:
        test = include["test"]
        check = bool(re.search(constants.VALID_INCLUDE_PATTERN, test))
        passed = check == include["expected"]
        includes_test_results.append(passed)
        # print(f"{test}: {check}")
    num_passed = includes_test_results.count(True)
    print(f"{num_passed} / {len(includes_test_results)} tests passed")

def test_manager() -> None:
    manager = PromptManager("test.yaml")
    print("---------------- Test 1 ----------------")
    test = manager.get("generate_user_profile")
    print("-- Raw Prompt")
    print(test.get_raw_content())
    print("-- Variables")
    print(test.get_variables())
    print()
    print("-- Metadata")
    print(test.get_metadata())
    print()
    print("-- Formatted Prompt:")
    print(test.format({'bio_text': "Simple Bio Text"}))
    print("--------------------------------")
    print()
    print()
    print("---------------- Test 2 ----------------")
    test_2 = manager.get("summarize_and_translate")
    print("-- Variables:")
    print(test_2.get_variables())
    print()
    print("-- Partial:")
    partial = test_2.partial({'num_sentences': 2})
    print(partial.get_raw_content())
    print("--------------------------------")



def main():
    # test_regex()
    test_manager()



if __name__ == "__main__":
    main()