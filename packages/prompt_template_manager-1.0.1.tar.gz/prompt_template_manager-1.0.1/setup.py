from setuptools import setup, find_packages

setup(
    name='prompt-template-manager',
    version='1.0.1',
    author='Dave Manufor',
    description='A lightweight and extensible Python library for managing, versioning, and composing reusable prompt templates from YAML or text files.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://promptmanager.davman.dev',
    packages=['prompt_template_manager'],
    install_requires=[
        'PyYAML',
    ],
    classifiers = [
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Text Processing :: Linguistic',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Operating System :: OS Independent',
    ]

)