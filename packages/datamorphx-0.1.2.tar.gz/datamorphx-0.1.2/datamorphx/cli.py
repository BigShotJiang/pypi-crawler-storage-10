import argparse
import pandas as pd
from datamorphx import Augmentor

def main():
    parser = argparse.ArgumentParser(description="Run datamorphx text augmentation.")
    parser.add_argument("--input", required=True)
    parser.add_argument("--column", required=True)
    parser.add_argument("--strategy", default="synonym")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    df = pd.read_csv(args.input)
    aug = Augmentor(strategy=args.strategy)
    df[args.column + "_aug"] = aug.expand(df[args.column].tolist())
    df.to_csv(args.output, index=False)
    print(f"Saved augmented data to {args.output}")

if __name__ == "__main__":
    main()
