from nltk.corpus import wordnet

def synonym_augment(text: str) -> str:
    """Replace words in a sentence with random synonyms from WordNet."""
    words = text.split()
    augmented = []

    for w in words:
        synsets = wordnet.synsets(w)
        if synsets:
            lemmas = [l.name().replace("_", " ") for s in synsets for l in s.lemmas() if l.name().lower() != w.lower()]
            if lemmas:
                augmented.append(lemmas[0])  # simple first synonym
                continue
        augmented.append(w)
    return " ".join(augmented)
