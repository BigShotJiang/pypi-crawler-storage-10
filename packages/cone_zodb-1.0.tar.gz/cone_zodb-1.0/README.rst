cone.zodb
=========

.. image:: https://img.shields.io/pypi/v/cone.zodb.svg
    :target: https://pypi.python.org/pypi/cone.zodb
    :alt: Latest PyPI version

.. image:: https://img.shields.io/pypi/dm/cone.zodb.svg
    :target: https://pypi.python.org/pypi/cone.zodb
    :alt: Number of PyPI downloads

.. image:: https://github.com/conestack/cone.zodb/actions/workflows/test.yaml/badge.svg
    :target: https://github.com/conestack/cone.zodb/actions/workflows/test.yaml
    :alt: Test cone.zodb

This package provides ZODB integration in ``cone.app`` and basic
application nodes for publishing ZODB models.
