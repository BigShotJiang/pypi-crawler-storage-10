from setuptools import setup, find_packages

# Read the content of the README.md file
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='value_iteration_lib',  # Replace with your unique package name
    version='0.1.0',             # Start with 0.1.0 and increment for changes
    author='Your Name',          # Your name
    author_email='your.email@example.com', # Your email
    description='A simple Python library for Value Iteration in Reinforcement Learning.',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/yourusername/value_iteration_lib', # Link to your GitHub repo
    packages=find_packages(),    # Automatically find your inner 'value_iteration_lib' package
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License', # Choose an appropriate license
        'Operating System :: OS Independent',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
    ],
    python_requires='>=3.8',     # Minimum Python version
    install_requires=[
        'numpy>=1.20',           # Add any dependencies your code needs
    ],
)