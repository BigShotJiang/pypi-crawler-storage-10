import numpy as np

def value_iteration(P, R, gamma=0.99, theta=1e-6):
    """
    Performs Value Iteration to find the optimal value function and policy.

    Args:
        P: Transition probabilities (P[s][a][s'] = probability of s' from s with a)
        R: Reward function (R[s][a][s'] = reward for s, a, s')
        gamma: Discount factor
        theta: Threshold for convergence

    Returns:
        V: Optimal value function
        policy: Optimal policy
    """
    num_states = len(P)
    num_actions = len(P[0])

    V = np.zeros(num_states)
    while True:
        delta = 0
        for s in range(num_states):
            v = V[s]
            q_values = np.zeros(num_actions)
            for a in range(num_actions):
                for prob, next_state, reward, _ in P[s][a]:
                    q_values[a] += prob * (reward + gamma * V[next_state])
            V[s] = np.max(q_values)
            delta = max(delta, abs(v - V[s]))
        if delta < theta:
            break

    # Derive optimal policy
    policy = np.zeros(num_states, dtype=int)
    for s in range(num_states):
        q_values = np.zeros(num_actions)
        for a in range(num_actions):
            for prob, next_state, reward, _ in P[s][a]:
                q_values[a] += prob * (reward + gamma * V[next_state])
        policy[s] = np.argmax(q_values)

    return V, policy

if __name__ == '__main__':
    # Example usage (e.g., a simple grid world)
    # You'd define P and R here for a specific problem.
    # For a PyPI package, you might put examples in documentation or separate files.
    print("Value Iteration module loaded.")