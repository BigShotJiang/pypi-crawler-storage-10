"""
Troubleshooting MCP Server

A Model Context Protocol server for system troubleshooting and diagnostics.
"""

__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"