# mypy: ignore-errors

class Pygtail:
    def __init__(self, filename: str, offset_file: str = None, paranoid: bool = False, copytruncate: bool = True,
                 every_n: int = 0, on_update: bool = False, read_from_end: bool = False, log_patterns: list = None,
                 full_lines: bool = False):
        ...
    def __iter__(self):
        ...

def __iter__():
    ...
