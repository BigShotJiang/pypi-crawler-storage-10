"""
Stub for IDP scoring pull.

TODO:
  - Mirror structure of export_official_scores.py
  - Focus: detect slot 17 (IDP) and validate stat coverage
  - Will integrate into qc_team_week_breakdown once stat parity verified
"""


def main():
    print("IDP scoring fetch stub active (placeholder).")


if __name__ == "__main__":
    main()
