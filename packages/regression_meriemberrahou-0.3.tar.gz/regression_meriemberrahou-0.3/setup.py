from setuptools import setup, find_packages

setup(
    name="regression_meriemberrahou",
    version="0.3",
    author="meriem berrahou",
    author_email="me.berrahou@esi-sba.dz",
    description="A simple linear regression model from scratch",
    packages=find_packages(),
    install_requires=[],
    license="MIT",
)
