# COLA-PY

Python обертка над фреймворком COLA

## Publish

```shell
python -m build
python -m twine upload dist/*
```
