//! Aggregated Rust integration tests for codetracer-python-recorder.

#[path = "rust/code_object_wrapper.rs"]
mod code_object_wrapper;

#[path = "rust/print_tracer.rs"]
mod print_tracer;
