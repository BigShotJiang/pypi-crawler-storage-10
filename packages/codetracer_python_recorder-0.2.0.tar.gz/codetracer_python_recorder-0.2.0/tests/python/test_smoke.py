import codetracer_python_recorder as m

def test_is_tracing_returns_false() -> None:
    assert m.is_tracing() == False

