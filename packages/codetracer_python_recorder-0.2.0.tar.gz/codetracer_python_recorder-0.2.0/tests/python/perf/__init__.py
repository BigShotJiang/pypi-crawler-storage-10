"""Performance-oriented smoke tests for the Python surface."""
