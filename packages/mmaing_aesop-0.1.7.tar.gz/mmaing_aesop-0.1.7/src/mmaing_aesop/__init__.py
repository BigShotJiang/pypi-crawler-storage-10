from .model import MMAING

__all__ = ["MMAING"]
