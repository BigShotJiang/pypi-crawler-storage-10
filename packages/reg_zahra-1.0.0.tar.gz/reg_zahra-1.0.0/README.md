
# package_name

rocket is a Python library for dealing with rockets and their properties.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install `rocket`.

```bash
pip install reg-zahra
```

```bash
pip install package_name
```

## Usage

```python
import reg-zahra

# returns 'words'
reg-zahra.module_name('word')

# returns 'geese'
reg-zahra.module_name('goose')

# returns 'phenomenon'
reg-zahra.module_name('phenomena')
```

## License
[MIT](https://choosealicense.com/licenses/mit/)