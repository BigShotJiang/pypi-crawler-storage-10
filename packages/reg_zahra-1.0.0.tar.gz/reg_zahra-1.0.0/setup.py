
from setuptools import find_packages, setup

setup(
   name='reg-zahra',
   version='1.0.0',
   author='MAROUF Zahra',
   author_email='z.marouf@esi-sba.dz',
   packages=find_packages(),
   url='http://pypi.python.org/pypi/reg-zahra/',
   license='LICENSE.txt',
   description='An awesome package that deals with rockets!!',
   long_description=open('README.md').read(),
   long_description_content_type="text/markdown",
   install_requires=['reg-zahra']
)