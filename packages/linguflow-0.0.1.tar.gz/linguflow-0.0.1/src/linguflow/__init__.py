def main() -> None:
    print("Hello from linguflow!")
