# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2025-09-28 10:48
# @Author : 毛鹏

import smtplib
import threading
import time
import traceback
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formataddr

import sys

python_version = sys.version_info

if "3.1" not in f"{python_version.major}.{python_version.minor}":
    raise Exception("必须使用>Python3.10.4")


def s(func, error, trace, username=None, *args, **kwargs):
    # 邮件配置参数
    smtp_server = 'smtp.qq.com'
    smtp_port = 587
    sender_email = '2716185083@qq.com'
    sender_name = '芒果测试平台'
    sender_password = 'jmuamgciqntydeji'
    receiver_email = '729164035@qq.com'
    email_subject = '服务异常消息通知'
    
    def ss():
        try:
            if kwargs.get('content', None):
                content = kwargs['content']
            else:

                content = f"""
                  芒果测试平台管理员请注意查收:
                      触发用户：{username}
                      触发时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
                      错误函数：{func.__name__}
                      异常类型: {type(error)}
                      错误提示: {str(error)}
                      错误详情：{trace}
                      参数list：{args}
                      参数dict：{kwargs}

                  **********************************
                  详细情况可前往芒果测试平台查看，非相关负责人员可忽略此消息。谢谢！

                                                                -----------芒果测试平台
                  """
            msg = MIMEMultipart()
            # 使用定义的参数设置邮件信息
            msg['From'] = formataddr((sender_name, sender_email))
            msg['To'] = receiver_email
            msg['Subject'] = email_subject
            msg.attach(MIMEText(content, 'plain'))
            with smtplib.SMTP(smtp_server, smtp_port) as server:
                server.starttls()
                server.login(sender_email, sender_password)
                server.sendmail(sender_email, receiver_email, msg.as_string())
                server.quit()
        except Exception:
            traceback.print_exc()
            pass

    thread = threading.Thread(target=ss)
    thread.start()


s(1,2,3,content='1j22j111j')
time.sleep(3)