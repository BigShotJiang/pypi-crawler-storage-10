# Solana Analyzer

一个用于分析 Solana/Rust 项目的 Python 包，基于 rust-analyzer 提供强大的代码分析功能。

## 功能特性

- **符号查找**: 在 Rust 项目中查找特定符号（函数、结构体等）
- **结构体分析**: 分析项目中的所有结构体定义
- **调用图分析**: 生成函数调用关系图
- **多种使用方式**: 支持 Python API 和命令行接口

## 安装

### 1. 构建 rust-analyzer

```bash
cargo build --release
```

### 2. 安装 Python 包

```bash
pip install -e .
```

## 使用方法

### Python API

```python
from solana_fcg_tool import SolanaAnalyzer

# 创建分析器实例
analyzer = SolanaAnalyzer("/path/to/your/rust/project")

# 查找符号
symbols = analyzer.find_symbols("main")

# 分析结构体
structs = analyzer.analyze_structs()

# 分析调用图
call_graph = analyzer.analyze_call_graph()
```

### 便捷函数

```python
from solana_fcg_tool import find_symbols, analyze_structs, analyze_call_graph

# 直接使用便捷函数
symbols = find_symbols("/path/to/project", "main")
structs = analyze_structs("/path/to/project")
call_graph = analyze_call_graph("/path/to/project")
```

### 命令行接口

```bash
# 查找符号
solana-fcg-tool source-finder main /path/to/project

# 分析结构体
solana-fcg-tool struct-analyzer /path/to/project

# 分析调用图
solana-fcg-tool call-graph /path/to/project
```

## 示例

运行示例代码：

```bash
python example_usage.py
```

## 项目结构

```
RustGraph/
├── solana_fcg_tool/          # Python 包源码
│   ├── __init__.py          # 包初始化和 API 导出
│   ├── cli.py               # 命令行接口
│   ├── interface.py         # 核心分析器类
│   └── ...
├── crates/                  # Rust 源码
│   └── rust-analyzer/       # rust-analyzer 可执行文件
├── lib/                     # 依赖库
├── setup.py                 # 包配置
├── pyproject.toml          # 现代 Python 包配置
└── example_usage.py        # 使用示例
```

## 依赖关系

- **Python**: >= 3.7
- **Rust**: 用于构建 rust-analyzer
- **rust-analyzer**: 核心分析引擎

## 开发

### 安装

```bash
pip install -e .
```

### 重新构建

```bash
# 重新构建 rust-analyzer
cargo build --release

# 重新安装包
pip install -e . --force-reinstall
```

### 测试

```bash
python example_usage.py
```

## 故障排除

### 常见问题

1. **rust-analyzer 未找到**
   - 确保已运行 `cargo build --release`
   - 检查 `target/release/rust-analyzer` 是否存在

2. **导入错误**
   - 确保包已正确安装：`pip list | grep solana-fcg-tool`
   - 尝试重新安装：`pip install -e . --force-reinstall`

3. **权限问题**
   - 确保 rust-analyzer 二进制文件有执行权限
   - 运行：`chmod +x target/release/rust-analyzer`

### 调试模式

```python
import logging
logging.basicConfig(level=logging.DEBUG)

from solana_fcg_tool import SolanaAnalyzer
analyzer = SolanaAnalyzer("/path/to/project", debug=True)
```

## 许可证

MIT License

## 贡献

欢迎提交 Issue 和 Pull Request！