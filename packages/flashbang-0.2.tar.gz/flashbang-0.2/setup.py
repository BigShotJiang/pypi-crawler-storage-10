from setuptools import setup, find_packages

setup(
    name="flashbang",
    version="0.2",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "Pillow",
        "playsound",
    ],
    entry_points={
        "console_scripts": [
            "flashbang=flashbang.main:flashbang",
        ],
    },
)
