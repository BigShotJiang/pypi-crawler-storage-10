"""
Command implementations for keynet-train CLI.

This module contains individual command handlers:
- submit: Submit training code to remote platform
- list: List registered templates
- describe: Get detailed information about a template
- config: Manage server configuration
"""
