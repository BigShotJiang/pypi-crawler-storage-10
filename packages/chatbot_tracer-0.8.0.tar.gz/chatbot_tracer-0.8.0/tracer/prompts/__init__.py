"""Package for all the prompts used in the other modules."""
