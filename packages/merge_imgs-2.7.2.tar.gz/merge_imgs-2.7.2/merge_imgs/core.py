import base64
from io import BytesIO
from PIL import Image




def merge_base64_images(img1_base64, img2_base64, orientation='vertical'):
    # Decode the base64 images
    img1_data = base64.b64decode(img1_base64)
    img2_data = base64.b64decode(img2_base64)
    
    # Open the images using PIL
    img1 = Image.open(BytesIO(img1_data))
    img2 = Image.open(BytesIO(img2_data))
    
    # Ensure both images have the same mode and size
    if img1.size != img2.size:
        img2 = img2.resize(img1.size)  # Resize img2 to match img1 size

    # Merge the images
    if orientation == 'horizontal':
        merged_width = img1.width + img2.width
        merged_height = img1.height
        merged_image = Image.new("RGB", (merged_width, merged_height))
        merged_image.paste(img1, (0, 0))
        merged_image.paste(img2, (img1.width, 0))
    elif orientation == 'vertical':
        merged_width = img1.width
        merged_height = img1.height + img2.height
        merged_image = Image.new("RGB", (merged_width, merged_height))
        merged_image.paste(img1, (0, 0))
        merged_image.paste(img2, (0, img1.height))
    else:
        raise ValueError("Invalid orientation. Choose 'horizontal' or 'vertical'.")
    
    # Convert the merged image back to base64
    buffered = BytesIO()
    merged_image.save(buffered, format="PNG")
    merged_base64 = base64.b64encode(buffered.getvalue()).decode("utf-8")
    
    return merged_base64