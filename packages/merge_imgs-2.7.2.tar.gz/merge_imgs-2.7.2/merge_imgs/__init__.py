from .core import merge_base64_images as merge_imgs
__all__ = ["merge_imgs"]
__version__ = "2.7.2"
