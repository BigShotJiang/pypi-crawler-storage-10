"""Azure AI Foundry integration with LangChain/LangGraph."""
