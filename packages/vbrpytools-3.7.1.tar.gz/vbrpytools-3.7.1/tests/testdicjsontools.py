''' testing stuff
'''
from vbrpytools.dicjsontools import create_nested_dict


if __name__ == "__main__":
    print(create_nested_dict(['a', 'b', 'c'], "here's my value"))
