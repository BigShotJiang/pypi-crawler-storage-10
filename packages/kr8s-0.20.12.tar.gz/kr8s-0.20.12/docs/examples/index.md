# Examples

This section contains code examples to demonstrate what you can do with `kr8s`.

```{toctree}
creating_resources
generating_resources
listing_resources
inspecting_resources
modifying_resources
pod_operations
```
