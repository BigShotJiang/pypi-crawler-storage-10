# Installation

## Pip

You can install `kr8s` from PyPI using `pip`.

```console
$ pip install kr8s
```

## Conda

You can also install `kr8s` from conda-forge.

```console
$ conda install -c conda-forge kr8s
```

