from typing import Annotated, Any, Dict, List, Optional
from loguru import logger

from fastmcp import FastMCP

from agentlin.tools.tool_arxiv import (
    arxiv_search_papers as _arxiv_search_papers,
    arxiv_download_papers as _arxiv_download_papers,
)


mcp = FastMCP(
    "ArXiv Tool Server",
    version="0.1.0",
)


@mcp.tool(
    name="arxiv_search_papers",
    title="ArxivSearch",
    description=("Search for academic papers on arXiv using a query string and optional paper IDs. " "Supports advanced search operators (ti for title, au for author, abs for abstract, " "AND/OR/ANDNOT, and submittedDate ranges). Returns a list of papers with metadata."),
)
async def arxiv_search_papers_tool(
    query: Annotated[Optional[str], "Search query string (supports advanced operators). Provide either query or paper_ids"] = None,
    paper_ids: Annotated[Optional[List[str]], "Specific arXiv paper IDs to fetch (e.g., ['2101.00001'])"] = None,
    max_results: Annotated[Optional[int], "Maximum number of results to return (default 5)"] = 5,
):
    """搜索 arXiv 论文并返回元数据列表"""
    try:
        result = await _arxiv_search_papers(query or "", paper_ids, max_results)
        return result
    except Exception as e:
        logger.error(f"arxiv_search_papers tool failed: {e}")
        return {"error": str(e)}


@mcp.tool(
    name="arxiv_download_papers",
    title="ArxivDownload",
    description=("Download PDFs of academic papers from arXiv based on a query or specific IDs. " "Saves files to the given output directory with safe filenames."),
)
async def arxiv_download_papers_tool(
    query: Annotated[Optional[str], "Search query string (supports advanced operators). Provide either query or paper_ids"] = None,
    paper_ids: Annotated[Optional[List[str]], "Specific arXiv paper IDs to download (e.g., ['2101.00001'])"] = None,
    max_results: Annotated[Optional[int], "Maximum number of papers to download (default 5)"] = 5,
    output_dir: Annotated[Optional[str], "Directory to save PDF files (default './')"] = "./",
):
    """下载 arXiv 论文 PDF 到本地目录"""
    try:
        status = await _arxiv_download_papers(query or "", paper_ids, max_results, output_dir)
        return {"message": status}
    except Exception as e:
        logger.error(f"arxiv_download_papers tool failed: {e}")
        return {"error": str(e)}


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Run ArXiv MCP SSE-based server")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    parser.add_argument("--port", type=int, default=7781, help="Port to listen on")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    args = parser.parse_args()

    logger.info("Starting ArXiv MCP Server...")
    logger.info("Available tools: arxiv_search_papers, arxiv_download_papers")

    mcp.run("http", host=args.host, port=args.port, log_level="debug" if args.debug else "info")
