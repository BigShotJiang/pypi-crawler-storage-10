from typing import Any
import httpx


class DocParsingClient:
    def __init__(self, server_url: str):
        self.server_url = server_url.rstrip("/")

    async def parse_document(self, document: str) -> dict[str, Any]:
        async with httpx.AsyncClient() as client:
            response = await client.post(f"{self.server_url}/parse", json={"document": document})
            response.raise_for_status()
            return response.json()
