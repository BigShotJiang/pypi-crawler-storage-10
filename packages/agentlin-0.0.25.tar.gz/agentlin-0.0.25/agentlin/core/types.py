from abc import ABC
from enum import Enum
from typing import Iterator
from typing_extensions import Union, Any, Literal, List, Annotated, Optional, Dict, Set, TypeAlias
from pydantic import BaseModel, Field, TypeAdapter, ConfigDict, field_serializer
import datetime
import uuid

from openai.types.responses import ToolParam, ResponseInputItemParam, ResponseInputContentParam
from openai.types.chat import ChatCompletionMessageParam, ChatCompletionContentPartParam
from openai.types.chat.chat_completion_tool_param import (
    ChatCompletionFunctionToolParam,
)
from openai.types.chat.chat_completion_message_function_tool_call_param import (
    ChatCompletionMessageFunctionToolCallParam,
)

from openai.types.shared_params.function_definition import (
    FunctionParameters,
    FunctionDefinition,
)
from mcp.types import Tool as McpToolData

from agentlin.code_interpreter.types import Block, ToolResponse
from agentlin.core.usage import Usage
from agentlin.tools.validate import validate_function_call_arguments


ContentData: TypeAlias = ChatCompletionContentPartParam  # {"type": "text", "text": ""}
DialogData: TypeAlias = ChatCompletionMessageParam  # {"role": "user", "content": "" | [ContentData]}
ToolData: TypeAlias = ChatCompletionFunctionToolParam  # {"type": "function", "function": FunctionDefinition}

ResponsesContentData: TypeAlias = ResponseInputContentParam  # {"type": "input_text", "text": ""}
ResponsesDialogData: TypeAlias = ResponseInputItemParam  # {"type": "message", "role": "user", "content": "" | [ContentData]}
ResponsesToolData: TypeAlias = ToolParam  # {"type": "function", "name": ...FunctionDefinition}

BlockData: TypeAlias = Block
ToolCallContentData: TypeAlias = ChatCompletionMessageFunctionToolCallParam

ToolParams: TypeAlias = Dict[str, Any]

class ToolResult(BaseModel):
    message_content: list[dict] = []
    block_list: list[dict] = []
    data: Optional[dict] = None

    @classmethod
    def from_dict(cls, data: ToolResponse) -> "ToolResult":
        return cls(
            message_content=data.get("message_content", []),
            block_list=data.get("block_list", []),
            data=data.get("data"),
        )

    def append_content(self, content: ContentData):
        """Append content to the message_content list."""
        self.message_content.append(content)

    def append_block(self, block: BlockData):
        """Append block to the block_list."""
        self.block_list.append(block)

    def extend_message_content(self, content_list: List[ContentData]):
        """Extend message_content with a list of ContentData."""
        if not content_list:
            return
        self.message_content.extend(content_list)

    def extend_block_list(self, block_list: List[BlockData]):
        """Extend block_list with a list of Block."""
        if not block_list:
            return
        self.block_list.extend(block_list)

    def extend_result(self, other: "ToolResult"):
        """Extend this ToolResult with another ToolResult."""
        self.extend_message_content(other.message_content)
        self.extend_block_list(other.block_list)


def sanitize_parameters(schema: Optional[FunctionDefinition]) -> None:
    _sanitize_parameters(schema, set())


def _sanitize_parameters(schema: Optional[FunctionDefinition], visited: Set[int]) -> None:
    if not schema or id(schema) in visited:
        return
    visited.add(id(schema))

    if "anyOf" in schema:
        schema.pop("default", None)
        for sub in schema["anyOf"]:
            if isinstance(sub, dict):
                _sanitize_parameters(sub, visited)

    if "items" in schema and isinstance(schema["items"], dict):
        _sanitize_parameters(schema["items"], visited)

    if "properties" in schema:
        for value in schema["properties"].values():
            if isinstance(value, dict):
                _sanitize_parameters(value, visited)

    if schema.get("type") == "string" and "format" in schema:
        if schema["format"] not in ("enum", "date-time"):
            schema["format"] = None


class BaseTool(ABC):
    def __init__(
        self,
        name: str,
        title: str,
        description: str,
        parameters: FunctionParameters,
        strict: bool = True,
    ):
        self.name = name
        self.title = title
        self.description = description
        self.parameters = parameters or {}
        self.strict = strict or True
        self.schema = FunctionDefinition(
            name=name,
            description=description,
            parameters=parameters,
            strict=strict,
        )

    @property
    def function_tool_schema(self) -> ToolData:
        return ToolData(
            type="function",
            function=self.schema,
        )

    async def execute(self, params: ToolParams) -> ToolResult:
        # Implement the tool's logic here
        raise NotImplementedError

    def validate_arguments(self, arguments: dict[str, Any]) -> Optional[dict[str, Any]]:
        """Validate and coerce the arguments according to the tool's parameter schema."""
        return validate_function_call_arguments(self.parameters, arguments)

    def to_mcp_tool(self) -> McpToolData:
        return McpToolData(
            name=self.name,
            title=self.title,
            description=self.description,
            inputSchema=self.parameters,
        )


class TaskState(str, Enum):
    SUBMITTED = "submitted"
    WORKING = "working"
    INPUT_REQUIRED = "input-required"
    COMPLETED = "completed"
    CANCELED = "canceled"
    FAILED = "failed"
    UNKNOWN = "unknown"


class TaskStatus(BaseModel):
    state: TaskState
    payload: Any = None
    timestamp: datetime.datetime = Field(default_factory=datetime.datetime.now)

    @field_serializer("timestamp")
    def serialize_dt(self, dt: datetime.datetime, _info):
        return dt.isoformat()


class Task(BaseModel):
    id: str
    sessionId: Optional[str] = None
    status: TaskStatus
    metadata: Optional[dict[str, Any]] = None


class TaskStatusUpdateEvent(BaseModel):
    id: str
    status: TaskStatus
    final: bool = False
    metadata: Optional[Union[dict[str, Any], BaseModel]] = None


class TaskArtifactUpdateEvent(BaseModel):
    id: str
    metadata: Optional[dict[str, Any]] = None


class AuthenticationInfo(BaseModel):
    model_config = ConfigDict(extra="allow")

    schemes: List[str]
    credentials: Optional[str] = None


class PushNotificationConfig(BaseModel):
    url: str
    token: Optional[str] = None
    authentication: Optional[AuthenticationInfo] = None


class TaskIdParams(BaseModel):
    id: str
    metadata: Optional[dict[str, Any]] = None


class TaskQueryParams(TaskIdParams):
    pass


class TaskSendParams(BaseModel):
    id: str = Field(default_factory=lambda: uuid.uuid4().hex)
    sessionId: str = Field(default_factory=lambda: uuid.uuid4().hex)
    payload: dict | BaseModel
    acceptedOutputModes: Optional[List[str]] = None
    pushNotification: Optional[PushNotificationConfig] = None
    metadata: Optional[dict[str, Any]] = None


class TaskPushNotificationConfig(BaseModel):
    id: str
    pushNotificationConfig: PushNotificationConfig


## RPC Messages


class JSONRPCMessage(BaseModel):
    jsonrpc: Literal["2.0"] = "2.0"
    id: Optional[int | str] = Field(default_factory=lambda: uuid.uuid4().hex)


class JSONRPCRequest(JSONRPCMessage):
    method: str
    params: Optional[dict[str, Any]] = None


class JSONRPCError(BaseModel):
    code: int
    message: str
    data: Optional[Any] = None


class JSONRPCResponse(JSONRPCMessage):
    result: Optional[Any] = None
    error: Optional[JSONRPCError] = None


class SendTaskRequest(JSONRPCRequest):
    method: Literal["tasks/send"] = "tasks/send"
    params: TaskSendParams


class SendTaskResponse(JSONRPCResponse):
    result: Optional[Task] = None


class SendTaskStreamingRequest(JSONRPCRequest):
    method: Literal["tasks/sendSubscribe"] = "tasks/sendSubscribe"
    params: TaskSendParams


class SendTaskStreamingResponse(JSONRPCResponse):
    result: Optional[TaskStatusUpdateEvent | TaskArtifactUpdateEvent] = None


class GetTaskRequest(JSONRPCRequest):
    method: Literal["tasks/get"] = "tasks/get"
    params: TaskQueryParams


class GetTaskResponse(JSONRPCResponse):
    result: Optional[Task] = None


class CancelTaskRequest(JSONRPCRequest):
    method: Literal["tasks/cancel",] = "tasks/cancel"
    params: TaskIdParams


class CancelTaskResponse(JSONRPCResponse):
    result: Optional[Task] = None


class SetTaskPushNotificationRequest(JSONRPCRequest):
    method: Literal["tasks/pushNotification/set",] = "tasks/pushNotification/set"
    params: TaskPushNotificationConfig


class SetTaskPushNotificationResponse(JSONRPCResponse):
    result: Optional[TaskPushNotificationConfig] = None


class GetTaskPushNotificationRequest(JSONRPCRequest):
    method: Literal["tasks/pushNotification/get",] = "tasks/pushNotification/get"
    params: TaskIdParams


class GetTaskPushNotificationResponse(JSONRPCResponse):
    result: Optional[TaskPushNotificationConfig] = None


class TaskResubscriptionRequest(JSONRPCRequest):
    method: Literal["tasks/resubscribe",] = "tasks/resubscribe"
    params: TaskIdParams


TaskRequest = Union[
    SendTaskRequest,
    GetTaskRequest,
    CancelTaskRequest,
    SetTaskPushNotificationRequest,
    GetTaskPushNotificationRequest,
    TaskResubscriptionRequest,
    SendTaskStreamingRequest,
]
TaskRequestType = TypeAdapter(
    Annotated[
        TaskRequest,
        Field(discriminator="method"),
    ]
)

## Agent Responses
class TextContentItem(BaseModel):
    type: Union[Literal["text"], Literal["input_text"], Literal["output_text"]]
    text: str
    status: Union[Literal["in_progress", "completed", "incomplete"], None] = None

class ImageURL(BaseModel):
    url: str
    detail: Union[Literal["auto", "low", "high"], None] = None

class ImageContentItem(BaseModel):
    type: Literal["image_url"] = "image_url"
    image_url: Union[ImageURL, str]
    detail: Union[Literal["low", "high", "auto"], None] = None

class InputAudio(BaseModel):
    data: str
    format: Literal["wav", "mp3"] = "wav"

class AudioContentItem(BaseModel):
    type: Literal["input_audio"] = "input_audio"
    input_audio: InputAudio

class FileDetail(BaseModel):
    file_data: Optional[str] = None # base64
    file_url: str
    filename: str

class FileContentItem(BaseModel):
    type: Literal["file"] = "file"
    file: FileDetail

ContentItem = Union[
    TextContentItem,
    ImageContentItem,
    AudioContentItem,
    FileContentItem,
    str,
]

class SummaryTextContentItem(BaseModel):
    type: Literal["summary_text"] = "summary_text"
    text: str

class ReasoningTextContentItem(BaseModel):
    type: Literal["reasoning_text"] = "reasoning_text"
    text: str

class ReasoningItem(BaseModel):
    type: Literal["reasoning"] = "reasoning"
    id: str = Field(default_factory=lambda: f"rs_{uuid.uuid4().hex}")
    summary: list[SummaryTextContentItem] = []
    content: Optional[list[ReasoningTextContentItem]] = []


class MessageItem(BaseModel):
    type: Optional[Literal["message"]] = "message"
    role: Literal["user", "assistant", "system", "developer"]
    content: Union[list[ContentItem], str]
    status: Union[Literal["in_progress", "completed", "incomplete"], None] = None
    id: Optional[str] = Field(default_factory=lambda: f"msg_{uuid.uuid4().hex}")
    call_id: Optional[str] = None
    message_content: Optional[list[dict]] = None
    block_list: Optional[list[dict]] = None


class FunctionCallItem(BaseModel):
    type: Literal["function_call"] = "function_call"
    id: str = Field(default_factory=lambda: f"fc_{uuid.uuid4().hex}")
    call_id: str  # = Field(default_factory=lambda: f"call_{uuid.uuid4().hex}")
    name: str
    arguments: str
    language: Optional[Literal["json", "yaml", "python", "javascript"]] = "json"
    status: Literal["in_progress", "completed", "incomplete"] = "in_progress"


class FunctionCallOutputItem(BaseModel):
    type: Literal["function_call_output"] = "function_call_output"
    id: str = Field(default_factory=lambda: f"fco_{uuid.uuid4().hex}")
    call_id: str  # = Field(default_factory=lambda: f"call_{uuid.uuid4().hex}")
    output: Union[list[ContentItem], str] = []
    message_content: list[dict] = []  # 必须支持工具结果协议，所以这个字段一定非空
    block_list: list[dict] = []


OutputItem: TypeAlias = Union[
    MessageItem,
    ReasoningItem,
    FunctionCallItem,
    FunctionCallOutputItem,
]


class FunctionToolDefinition(BaseModel):
    type: Literal["function"] = "function"
    name: str
    parameters: dict  # this should be typed stricter if you add strict mode
    strict: bool = False  # change this if you support strict mode
    description: Optional[str] = ""

class ResponseObject(BaseModel):
    object: str = "response"
    id: str = Field(default_factory=lambda: f"resp_{uuid.uuid4().hex}")
    status: Literal["completed", "failed", "incomplete", "in_progress"] = "in_progress"
    created_at: int = Field(default_factory=lambda: int(datetime.datetime.now(datetime.timezone.utc).timestamp()))
    output: list[OutputItem]
    usage: Usage = Field(default_factory=Usage)
    error: Optional[JSONRPCError] = None
    metadata: Optional[Dict[str, Any]] = None
    previous_response_id: Optional[str] = None
    rollouts: Optional[list["ResponseRolloutEvent"]] = None

    def append_rollout(self, rollout: "ResponseRolloutEvent"):
        if self.rollouts is None:
            self.rollouts = []
        self.rollouts.append(rollout)


## Agent Responses Events
class ResponseEvent(BaseModel):
    sequence_number: Optional[int] = 1


class ResponseCreatedEvent(ResponseEvent):
    type: Literal["response.created"] = "response.created"
    response: ResponseObject

class ResponseInProgressEvent(ResponseEvent):
    type: Literal["response.in_progress"] = "response.in_progress"
    response: ResponseObject

class ResponseCompletedEvent(ResponseEvent):
    type: Literal["response.completed"] = "response.completed"
    response: ResponseObject

class ResponseIncompleteEvent(ResponseEvent):
    type: Literal["response.incomplete"] = "response.incomplete"
    response: ResponseObject

class ResponseFailedEvent(ResponseEvent):
    type: Literal["response.failed"] = "response.failed"
    response: ResponseObject

class ResponseToolsUpdatedEvent(ResponseEvent):
    type: Literal["response.tools_updated"] = "response.tools_updated"
    tools: List[ToolData]

class ResponseContextCompressionCreatedEvent(ResponseEvent):
    type: Literal["response.context_compression.created"] = "response.context_compression.created"

class ResponseContextCompressionInProgressEvent(ResponseEvent):
    type: Literal["response.context_compression.in_progress"] = "response.context_compression.in_progress"

class ResponseContextCompressionCompletedEvent(ResponseEvent):
    type: Literal["response.context_compression.completed"] = "response.context_compression.completed"

class ResponseOutputItemAddedEvent(ResponseEvent):
    type: Literal["response.output_item.added"] = "response.output_item.added"
    agent_step: int = 0
    item: OutputItem

class ResponseOutputItemDoneEvent(ResponseEvent):
    type: Literal["response.output_item.done"] = "response.output_item.done"
    agent_step: int = 0
    item: OutputItem

class ResponseContentPartAddedEvent(ResponseEvent):
    type: Literal["response.content_part.added"] = "response.content_part.added"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    agent_step: int = 0
    content_index: int = 0
    part: Union[ContentItem, ReasoningTextContentItem]

class ResponseContentPartDoneEvent(ResponseEvent):
    type: Literal["response.content_part.done"] = "response.content_part.done"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    agent_step: int = 0
    content_index: int = 0
    part: Union[ContentItem, ReasoningTextContentItem]


class Part(BaseModel):
    type: Literal["summary_text"] = "summary_text"
    text: str

class ResponseReasoningSummaryPartAddedEvent(ResponseEvent):
    type: Literal["response.reasoning_summary_part.added"] = "response.reasoning_summary_part.added"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    agent_step: int
    part: Part
    summary_index: int

class ResponseReasoningSummaryPartDoneEvent(ResponseEvent):
    type: Literal["response.reasoning_summary_part.done"] = "response.reasoning_summary_part.done"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    agent_step: int
    part: Part
    summary_index: int

class ResponseReasoningSummaryTextDeltaEvent(ResponseEvent):
    type: Literal["response.reasoning_summary_text.delta"] = "response.reasoning_summary_text.delta"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    agent_step: int = 0
    content_index: int = 0
    delta: str = ""

class ResponseReasoningSummaryTextDoneEvent(ResponseEvent):
    type: Literal["response.reasoning_summary_text.done"] = "response.reasoning_summary_text.done"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    agent_step: int
    summary_index: int
    text: str

class ResponseReasoningTextDeltaEvent(ResponseEvent):
    type: Literal["response.reasoning_text.delta"] = "response.reasoning_text.delta"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    agent_step: int = 0
    content_index: int = 0
    delta: str = ""


class ResponseReasoningTextDoneEvent(ResponseEvent):
    type: Literal["response.reasoning_text.done"] = "response.reasoning_text.done"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    agent_step: int = 0
    content_index: int = 0
    text: str = ""

class ResponseTextDeltaEvent(ResponseEvent):
    type: Literal["response.text.delta"] = "response.text.delta"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    agent_step: int = 0
    content_index: int = 0
    delta: str = ""
    logprobs: list = []

class ResponseTextDoneEvent(ResponseEvent):
    type: Literal["response.text.done"] = "response.text.done"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    agent_step: int = 0
    content_index: int = 0
    text: str = ""
    logprobs: list = []

class ResponseToolCallArgumentsDeltaEvent(ResponseEvent):
    type: Literal["response.tool_call_arguments.delta"] = "response.tool_call_arguments.delta"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    call_id: str
    agent_step: int
    delta: str

class ResponseToolCallArgumentsDoneEvent(ResponseEvent):
    type: Literal["response.tool_call_arguments.done"] = "response.tool_call_arguments.done"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    call_id: str
    agent_step: int
    arguments: str

class ResponseToolCallResultDeltaEvent(ResponseEvent):
    type: Literal["response.tool_call_result.delta"] = "response.tool_call_result.delta"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    call_id: str
    agent_step: int
    delta_message_content: list[dict] = []
    delta_block_list: list[dict] = []

class ResponseToolCallResultDoneEvent(ResponseEvent):
    type: Literal["response.tool_call_result.done"] = "response.tool_call_result.done"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    call_id: str
    agent_step: int
    message_content: list[dict] = []
    block_list: list[dict] = []

class ResponseBlockDeltaEvent(ResponseEvent):
    type: Literal["response.block.delta"] = "response.block.delta"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    agent_step: int
    block: dict

class ResponseBlockDoneEvent(ResponseEvent):
    type: Literal["response.block.done"] = "response.block.done"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    agent_step: int
    block: dict

class ResponseToolCallCreatedEvent(ResponseEvent):
    type: Literal["response.tool_call.created"] = "response.tool_call.created"
    agent_step: int = 0
    item: FunctionCallItem
    response: ResponseObject

class ResponseToolCallInProgressEvent(ResponseEvent):
    type: Literal["response.tool_call.in_progress"] = "response.tool_call.in_progress"
    agent_step: int = 0
    item: FunctionCallItem
    response: ResponseObject

class ResponseToolCallCompletedEvent(ResponseEvent):
    type: Literal["response.tool_call.completed"] = "response.tool_call.completed"
    agent_step: int = 0
    item: FunctionCallItem
    response: ResponseObject


class ResponseAudioDeltaEvent(ResponseEvent):
    type: Literal["response.audio.delta"] = "response.audio.delta"
    delta: str
    """A chunk of Base64 encoded response audio bytes."""
    agent_step: int

class ResponseAudioDoneEvent(ResponseEvent):
    type: Literal["response.audio.done"] = "response.audio.done"
    agent_step: int


class ResponseImageDeltaEvent(ResponseEvent):
    type: Literal["response.image.delta"] = "response.image.delta"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    agent_step: int
    partial_image_b64: str
    partial_image_index: int

class ResponseImageDoneEvent(ResponseEvent):
    type: Literal["response.image.done"] = "response.image.done"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    agent_step: int

class ResponseFileDeltaEvent(ResponseEvent):
    type: Literal["response.file.delta"] = "response.file.delta"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    agent_step: int
    partial_file_b64: str
    partial_file_index: int

class ResponseFileDoneEvent(ResponseEvent):
    type: Literal["response.file.done"] = "response.file.done"
    item_id: str  # 指向 ResponseOutputItemAdded 的 item.id
    agent_step: int

class ResponseRolloutEvent(ResponseEvent):
    type: Literal["response.rollout"] = "response.rollout"
    session_id: str = Field(default_factory=lambda: f"session_{uuid.uuid4().hex}")
    response_id: str = Field(default_factory=lambda: f"resp_{uuid.uuid4().hex}")
    trace_id: str = Field(default_factory=lambda: f"trace_{uuid.uuid4().hex}")
    request_id: str = Field(default_factory=lambda: f"request_{uuid.uuid4().hex}")
    rollout_id: str = Field(default_factory=lambda: f"rollout_{uuid.uuid4().hex}")
    input_messages: List[dict]
    output_messages: List[dict]
    inference_args: dict[str, Any] = {}
    tools: list[ToolData] = []
    request: dict[str, Any] = {}
    is_answer: bool = False
    turn: int
    step: Optional[int] = None

AgentResponseEvent = Union[
    ResponseCreatedEvent,
    ResponseInProgressEvent,
    ResponseCompletedEvent,
    ResponseIncompleteEvent,
    ResponseFailedEvent,
    ResponseToolsUpdatedEvent,
    ResponseContextCompressionCreatedEvent,
    ResponseContextCompressionInProgressEvent,
    ResponseContextCompressionCompletedEvent,
    ResponseOutputItemAddedEvent,
    ResponseOutputItemDoneEvent,
    ResponseContentPartAddedEvent,
    ResponseContentPartDoneEvent,
    ResponseReasoningSummaryPartAddedEvent,
    ResponseReasoningSummaryPartDoneEvent,
    ResponseReasoningSummaryTextDeltaEvent,
    ResponseReasoningSummaryTextDoneEvent,
    ResponseReasoningTextDeltaEvent,
    ResponseReasoningTextDoneEvent,
    ResponseToolCallArgumentsDeltaEvent,
    ResponseToolCallArgumentsDoneEvent,
    ResponseToolCallResultDeltaEvent,
    ResponseToolCallResultDoneEvent,
    # ResponseBlockDeltaEvent,
    # ResponseBlockDoneEvent,
    ResponseToolCallCreatedEvent,
    ResponseToolCallInProgressEvent,
    ResponseToolCallCompletedEvent,
    ResponseTextDeltaEvent,
    ResponseTextDoneEvent,
    ResponseImageDeltaEvent,
    ResponseImageDoneEvent,
    ResponseAudioDeltaEvent,
    ResponseAudioDoneEvent,
    ResponseFileDeltaEvent,
    ResponseFileDoneEvent,
    ResponseRolloutEvent,
]
AgentResponseEventType = TypeAdapter(
    Annotated[
        AgentResponseEvent,
        Field(discriminator="type"),
    ]
)

# def check_stream(stream: Iterator[AgentResponseEvent]):
#     # 有限状态机
#     transition: list[dict[AgentResponseEvent, int]] = [
#         {}, # fail
#         # state 1
#         {ResponseCreatedEvent: 2},
#         # state 2
#         {ResponseInProgressEvent: 3},
#         # state 3
#         {ResponseToolsUpdatedEvent: 3, ResponseOutputItemAddedEvent: 4},  # -> reasoning, text/image/audio/file, tool_call, tool_call_result
#         # state 4
#         {
#             ResponseContentPartAddedEvent: 5, # -> reasoning, text/image/audio/file, tool_call_result
#             ResponseToolCallArgumentsDeltaEvent: 6, # -> tool_call
#         },
#         # state 5
#         {
#             ResponseReasoningTextDeltaEvent: 7, # -> reasoning
#             ResponseTextDeltaEvent: 8,
#             ResponseImageDeltaEvent: 9,
#             ResponseAudioDeltaEvent: 10,
#             ResponseFileDeltaEvent: 11,
#             ResponseToolCallResultDeltaEvent: 12,
#         },
#         # state 6
#         {ResponseToolCallArgumentsDoneEvent: 13},
#         # state 7
#         {ResponseReasoningTextDoneEvent: 14},
#         # state 8
#         {ResponseTextDoneEvent: 15},
#         # state 9
#         {ResponseImageDoneEvent: 15},
#         # state 10
#         {ResponseAudioDoneEvent: 15},
#         # state 11
#         {ResponseFileDoneEvent: 15},
#         # state 12
#         {ResponseToolCallResultDoneEvent: 15},
#         # state 13
#         {ResponseOutputItemDoneEvent: 3},
#         # state 14
#         {ResponseContentPartDoneEvent: 17, ResponseReasoningSummaryPartAddedEvent: 16},
#         # state 15
#         {ResponseContentPartDoneEvent: 3},
#     ]
#     def event_to_action(event: AgentResponseEvent):
#         if isinstance(event, ResponseCreatedEvent):
#             return ResponseCreatedEvent
#     init_state = 1
#     stop_state = {}
#     current_state = init_state
#     for event in stream:
#         action = event_to_action(event)
#         next_state = transition[current_state]
#         if action not in next_state:
#             return False
#         current_state = next_state[action]
#     return current_state in stop_state


## Error types


class JSONParseError(JSONRPCError):
    code: int = -32700
    message: str = "Invalid JSON payload"
    data: Optional[Any] = None


class InvalidRequestError(JSONRPCError):
    code: int = -32600
    message: str = "Request payload validation error"
    data: Optional[Any] = None


class MethodNotFoundError(JSONRPCError):
    code: int = -32601
    message: str = "Method not found"
    data: None = None


class InvalidParamsError(JSONRPCError):
    code: int = -32602
    message: str = "Invalid parameters"
    data: Optional[Any] = None


class InternalError(JSONRPCError):
    code: int = -32603
    message: str = "Internal error"
    data: Optional[Any] = None


class TaskNotFoundError(JSONRPCError):
    code: int = -32001
    message: str = "Task not found"
    data: None = None


class TaskNotCancelableError(JSONRPCError):
    code: int = -32002
    message: str = "Task cannot be canceled"
    data: None = None


class PushNotificationNotSupportedError(JSONRPCError):
    code: int = -32003
    message: str = "Push Notification is not supported"
    data: None = None


class UnsupportedOperationError(JSONRPCError):
    code: int = -32004
    message: str = "This operation is not supported"
    data: None = None


class ContentTypeNotSupportedError(JSONRPCError):
    code: int = -32005
    message: str = "Incompatible content types"
    data: None = None


class RPCTimeoutError(JSONRPCError):
    code: int = -32006
    message: str = "RPC call timed out"
    data: None = None


class RPCMethodNotFoundError(JSONRPCError):
    code: int = -32007
    message: str = "RPC method not found"
    data: None = None


class RPCExecutionError(JSONRPCError):
    code: int = -32008
    message: str = "RPC method execution failed"
    data: Optional[Any] = None


## RPC-specific request/response types

class RPCCallRequest(JSONRPCRequest):
    """RPC方法调用请求"""
    method: Literal["rpc/call"] = "rpc/call"
    params: dict[str, Any]  # 包含 target_agent_id, rpc_method, args, kwargs


class RPCCallResponse(JSONRPCResponse):
    """RPC方法调用响应"""
    result: Optional[Any] = None


def are_modalities_compatible(server_output_modes: List[str], client_output_modes: List[str]):
    """Modalities are compatible if they are both non-empty
    and there is at least one common element."""
    if client_output_modes is None or len(client_output_modes) == 0:
        return True

    if server_output_modes is None or len(server_output_modes) == 0:
        return True

    return any(x in server_output_modes for x in client_output_modes)


def append_metadata(metadata: dict[str, list], new_metadata: dict[str, Any]) -> None:
    """Append data to the metadata dictionary."""
    for key, value in new_metadata.items():
        if key not in metadata:
            metadata[key] = []
        if isinstance(value, list):
            metadata[key].extend(value)
        else:
            if not isinstance(metadata[key], list):
                metadata[key] = [metadata[key]]
            metadata[key].append(value)

def send_task_request(
    request_id: str,
    session_id: str,
    task_id: str,
    payload: dict[str, Any],
):
    return SendTaskRequest(
        id=request_id,
        params=TaskSendParams(
            id=task_id,
            sessionId=session_id,
            payload=payload,
        ),
    )