from typing_extensions import Any, Literal, TypedDict, Optional, Union, Annotated, TypeAlias
from pydantic import Field
import re


MIME_MARKDOWN = "text/markdown"
MIME_TEXT = "text/plain"


class TextBlock(TypedDict, total=False):
    type: Literal["text"]
    text: str
    id: Optional[int]


MIME_IMAGE_PNG = "image/png"
MIME_IMAGE_JPEG = "image/jpeg"


class ImageUrl(TypedDict, total=False):
    url: str  # base64, http, or file path


class ImageBlock(TypedDict):
    type: Literal["image_url"]
    image_url: ImageUrl
    id: Optional[int]

BasicBlock = Union[
    TextBlock,
    ImageBlock,
]

MIME_PLOTLY = "application/vnd.plotly.v1+json"


class PlotlyBlock(TypedDict):
    type: Literal["plotly-json"]
    data: dict[Literal["application/vnd.plotly.v1+json"], dict]
    id: Optional[int]


TYPE_TABLE = "table-json"
MIME_TABLE_V1 = "application/vnd.aime.table.v1+json"


class TableDataV1(TypedDict):
    # v1 是通用 dataframe 的渲染
    columns: list[dict[str, Any]]
    datas: list[dict[str, Any]]


MIME_TABLE_V2 = "application/vnd.aime.table.v2+json"


class TableDataV2(TypedDict):
    # v2 是带 text2sql 的 dataframe 渲染
    columns: list[dict[str, Any]]
    datas: list[dict[str, Any]]
    condition: str
    model_sql: str
    model_condition: str
    chunks_info: str
    meta: str
    row_count: str
    code_count: str
    token: str
    status_code: str
    status_msg: str

MIME_TABLE_V3 = "application/vnd.aime.table.v3+json"

class TableDataV3(TypedDict):
    # v3 是带压缩的 dataframe 渲染
    # 只保留前 50 行数据，超出部分只保留行数信息
    table_id: str  # 前端根据此 id 进行翻页
    columns: list[dict[str, Any]]
    datas: list[dict[str, Any]]
    condition: str
    model_sql: str
    model_condition: str
    chunks_info: str
    meta: str
    row_count: str
    code_count: str
    token: str
    status_code: str
    status_msg: str

class TableBlock(TypedDict):
    type: Literal["table-json"]
    data: Union[
        dict[Literal["application/vnd.aime.table.v1+json"], TableDataV1],
        dict[Literal["application/vnd.aime.table.v2+json"], TableDataV2],
        dict[Literal["application/vnd.aime.table.v3+json"], TableDataV3],
    ]
    id: Optional[int]


MIME_HTML = "text/html"


class HtmlBlock(TypedDict):
    type: Literal["html"]
    data: dict[Literal["text/html"], str]  # HTML content
    id: Optional[int]


MIME_JSON = "application/json"


class JsonBlock(TypedDict):
    type: Literal["json"]
    data: dict[Literal["application/json"], dict]
    id: Optional[int]


TYPE_ENV_EVENT = "env_event"
MIME_ENV_EVENT = "application/vnd.env.event.v1+json"


class EnvEvent(TypedDict):
    done: bool
    info: Optional[dict[str, Any]]


class EnvEventBlock(TypedDict):
    type: Literal["env_event"]
    data: dict[Literal["application/vnd.env.event.v1+json"], EnvEvent]


TYPE_SEARCH_RESULT = "search_result"
MIME_SEARCH_RESULT = "application/vnd.search_result.v1+json"
MIME_SEARCH_RESULT_LIST = "application/vnd.search_result_list.v1+json"


class SearchResult(TypedDict):
    title: str
    url: str
    abstract: Optional[str]
    content: Optional[str]
    error: Optional[str]
    result_id: Optional[str]
    publish_time: Optional[str]


class SearchResultBlock(TypedDict):
    type: Literal["search_result"]
    data: dict[Literal["application/vnd.search_result.v1+json"], SearchResult]
    id: Optional[int]


MIME_TOOL_CALL = "application/vnd.aime.tool.call+json"


class ToolCallData(TypedDict):
    tool_name: str
    tool_args: dict[str, Any]
    call_id: str


class ToolCallBlock(TypedDict):
    type: Literal["tool_call"]
    data: dict[Literal["application/vnd.aime.tool.call+json"], ToolCallData]


TYPE_VISUAL = "visual-json"
MIME_VISUAL = "application/vnd.aime.visual.v1+json"
# from chatkit.widgets import Card, ListView

# VisualData: TypeAlias = Annotated[
#     Card | ListView,
#     Field(discriminator="type"),
# ]
# TODO 集成 openai 的 chatkit.widgets

class VisualDataV1(TypedDict):
    # v1 是通用 visual 的渲染
    type: str
    config: dict[str, Any]
    caption: Optional[str]

class VisualBlock(TypedDict):
    type: Literal["visual-json"]
    data: dict[Literal["application/vnd.aime.visual.v1+json"], VisualDataV1]
    id: Optional[int]
    # embed_id: Optional[str]  # 用于前端定位嵌入位置的 ID


TYPE_DOCUMENT = "document-json"
MIME_DOCUMENT = "application/vnd.aime.document.v1+json"


class DocumentTextBlock(TypedDict):
    type: Literal["text"]
    text: str
    # 标题会被归一为 text，并附带 text_level
    text_level: Optional[int]
    bbox: list[int]
    id: Optional[int]
    page_index: int
    # 某些构造函数可能使用 page_idx 字段
    page_idx: Optional[int]

class DocumentImageBlock(TypedDict):
    # 兼容两种表示：image（配合 img_path）与 image_url（配合 image_url）
    type: Literal["image", "image_url"]
    # 直接路径/URL（make_blocks_to_content_list 产物）
    img_path: Optional[str]
    # 结构化的 image_url（其他通路产物）
    image_url: Optional[ImageUrl]
    # 说明与脚注均为字符串列表
    image_caption: Optional[list[str]]
    image_footnote: Optional[list[str]]
    bbox: list[int]
    id: Optional[int]
    page_index: int
    page_idx: Optional[int]

class DocumentPageNumberBlock(TypedDict):
    type: Literal["page_number"]
    text: str
    bbox: list[int]
    id: Optional[int]
    page_index: int
    page_idx: Optional[int]

class DocumentPageFootnoteBlock(TypedDict):
    type: Literal["page_footnote"]
    text: str
    bbox: list[int]
    id: Optional[int]
    page_index: int
    page_idx: Optional[int]

class DocumentListBlock(TypedDict):
    type: Literal["list"]
    sub_type: str
    list_items: list[str]
    bbox: list[int]
    id: Optional[int]
    page_index: int
    page_idx: Optional[int]

# 头/脚/侧栏/引用/音标等文本型块
class DocumentHeaderBlock(TypedDict):
    type: Literal["header"]
    text: str
    bbox: list[int]
    id: Optional[int]
    page_index: int
    page_idx: Optional[int]

class DocumentFooterBlock(TypedDict):
    type: Literal["footer"]
    text: str
    bbox: list[int]
    id: Optional[int]
    page_index: int
    page_idx: Optional[int]

class DocumentAsideTextBlock(TypedDict):
    type: Literal["aside_text"]
    text: str
    bbox: list[int]
    id: Optional[int]
    page_index: int
    page_idx: Optional[int]

class DocumentRefTextBlock(TypedDict):
    type: Literal["ref_text"]
    text: str
    bbox: list[int]
    id: Optional[int]
    page_index: int
    page_idx: Optional[int]

class DocumentPhoneticBlock(TypedDict):
    type: Literal["phonetic"]
    text: str
    bbox: list[int]
    id: Optional[int]
    page_index: int
    page_idx: Optional[int]

# 公式（行间公式统一为 equation + latex）
class DocumentEquationBlock(TypedDict):
    type: Literal["equation"]
    text: str
    text_format: Literal["latex"]
    bbox: list[int]
    id: Optional[int]
    page_index: int
    page_idx: Optional[int]

# 表格，既可能携带 HTML，也可能只有图片路径
class DocumentTableBlock(TypedDict):
    type: Literal["table"]
    # HTML 内容（如果有）
    table_body: Optional[str]
    # 备选的图片路径
    img_path: Optional[str]
    table_caption: Optional[list[str]]
    table_footnote: Optional[list[str]]
    bbox: list[int]
    id: Optional[int]
    page_index: int
    page_idx: Optional[int]

# 代码块
class DocumentCodeBlock(TypedDict):
    type: Literal["code"]
    sub_type: str
    code_body: Optional[str]
    code_caption: Optional[list[str]]
    guess_lang: Optional[str]
    bbox: list[int]
    id: Optional[int]
    page_index: int
    page_idx: Optional[int]

DocumentDataBlock: TypeAlias = Union[
    DocumentTextBlock,
    DocumentImageBlock,
    DocumentPageNumberBlock,
    DocumentPageFootnoteBlock,
    DocumentListBlock,
    DocumentHeaderBlock,
    DocumentFooterBlock,
    DocumentAsideTextBlock,
    DocumentRefTextBlock,
    DocumentPhoneticBlock,
    DocumentEquationBlock,
    DocumentTableBlock,
    DocumentCodeBlock,
]

class DocumentPageData(TypedDict):
    message_content: list[dict[str, Any]]
    block_list: list[dict[str, Any]]
    page_index: int

class DocumentData(TypedDict):
    page_start: int
    page_end: int
    pages: list[DocumentPageData]
    origin_file_url: str
    filename: str

class DocumentBlock(TypedDict):
    type: Literal["document-json"]
    data: dict[Literal["application/vnd.aime.document.v1+json"], DocumentData]
    id: Optional[int]
    embed_id: Optional[str]  # 用于前端定位嵌入位置的 ID


Block: TypeAlias = Union[
    BasicBlock,
    PlotlyBlock,
    TableBlock,
    HtmlBlock,
    JsonBlock,
    SearchResultBlock,
    VisualBlock,
    ToolCallBlock,
    EnvEventBlock,
    DocumentBlock,
]


MIME_TOOL_RESPONSE = "application/vnd.aime.tool.response+json"


class ToolResponse(TypedDict):
    message_content: list[dict[str, Any]]
    block_list: list[Block]
    data: dict[str, Any]


def is_block_json_version(data: dict[str, Any], type: str="table") -> bool:
    for k in data:
        if type == "table":
            if re.match(r"application/vnd\.aime\.table\.v[0-9]+\+json", k):
                return True
        elif type == "visual":
            if re.match(r"application/vnd\.aime\.visual\.v[0-9]+\+json", k):
                return True
        elif type == "plotly-json":
            if re.match(r"application/vnd\.plotly\.v[0-9]+\+json", k):
                return True
        elif type == "document":
            if re.match(r"application/vnd\.aime\.document\.v[0-9]+\+json", k):
                return True
        elif type == "env_event":
            if re.match(r"application/vnd\.env\.event\.v[0-9]+\+json", k):
                return True
        elif type == "search_result":
            if re.match(r"application/vnd\.search_result(_list)?\.v[0-9]+\+json", k):
                return True
        elif type == "tool_call":
            if re.match(r"application/vnd\.aime\.tool\.call(\.v[0-9]+)?\+json", k):
                return True
        elif type == "tool_response":
            if re.match(r"application/vnd\.aime\.tool\.response(\.v[0-9]+)?\+json", k):
                return True
    return False
