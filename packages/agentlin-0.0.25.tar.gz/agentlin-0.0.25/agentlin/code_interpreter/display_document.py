from typing import Any

from agentlin.code_interpreter.types import MIME_DOCUMENT, DocumentData
from agentlin.code_interpreter.display_mime import MimeDisplayObject, display


def display_document(document: DocumentData, **extra: Any) -> None:
    """Display a document in a Jupyter notebook.

    参数:
        document: 遵循 `DocumentData` 的实例
        **extra: 预留扩展字段（当前未使用，便于未来扩展携带元信息）
    """
    # 直接将 document 数据作为 payload，创建支持多 MIME 输出的对象
    display_obj = MimeDisplayObject(MIME_DOCUMENT, document)
    display(display_obj)
