import asyncio
import json
import os
import traceback
from typing import AsyncIterable
from typing_extensions import Any, AsyncGenerator
import uuid

from fastmcp import Client
from fastmcp.client.transports import ClientTransportT
from fastmcp.client.elicitation import ElicitRequestParams, ElicitResult, RequestContext, ClientSession, LifespanContextT

from loguru import logger

from agentlin.core.agent_message_queue import AgentMessageQueue
from agentlin.core.agent_schema import apply_environment_variables, extract_variables
from agentlin.route.task_manager import InMemoryTaskManager, SequenceCounter, StreamableResponseParser
from agentlin.core.types import *
from agentlin.tools.builtin.file_system_tools import (
    ListDirectoryTool,
    ReadFileTool,
    WriteFileTool,
    GlobTool,
    GrepTool,
    ReplaceInFileTool,
    BashTool,
)
from agentlin.tools.builtin.web_tools import (
    WebSearchTool,
    WebFetchTool,
)
from agentlin.tools.core import DiscoveredMcpTool, message_content_to_output, tool_result_of_internal_error
from agentlin.tools.stateful_memory.memory_tool import MemoryTool
from agentlin.tools.stateful_memory.todo_tool import TodoWriteTool


class CallToolRequest(BaseModel):
    call_name: str
    call_args: dict[str, Any]

    return_response_event: bool = False  # Whether to return response events during streaming


TOOL_TASK_MANAGER = "tool_task_manager"


class ToolTaskManager(InMemoryTaskManager, AgentMessageQueue):
    def __init__(
        self,
        host_frontend_id: str,
        agent_id: str,
        mcp_config: Optional[ClientTransportT] = None,
        workspace_dir: Optional[str] = None,
        env: Optional[dict[str, str]] = None,
        *,
        rabbitmq_host: str = "localhost",
        rabbitmq_port: int = 5672,
        rabbitmq_user: str = "guest",
        rabbitmq_password: str = "guest",
        auto_ack: bool = False,
        reconnect_initial_delay: float = 5.0,
        reconnect_max_delay: float = 60.0,
        message_timeout: float = 30.0,
        rpc_timeout: float = 30.0,
        log_dir: Optional[str] = None,
    ):
        InMemoryTaskManager.__init__(self)
        AgentMessageQueue.__init__(
            self,
            name=f"{agent_id}/{TOOL_TASK_MANAGER}",
            rabbitmq_host=rabbitmq_host,
            rabbitmq_port=rabbitmq_port,
            rabbitmq_user=rabbitmq_user,
            rabbitmq_password=rabbitmq_password,
            auto_ack=auto_ack,
            reconnect_initial_delay=reconnect_initial_delay,
            reconnect_max_delay=reconnect_max_delay,
            message_timeout=message_timeout,
            rpc_timeout=rpc_timeout,
            log_dir=log_dir,
        )
        self.host_frontend_id = host_frontend_id
        self.env = env
        self.mcp_config = mcp_config
        if mcp_config:
            if isinstance(mcp_config, dict):
                for item in mcp_config:
                    if isinstance(mcp_config[item], dict):
                        if "url" in mcp_config[item]:
                            mcp_url = mcp_config[item]["url"]
                            if not isinstance(mcp_url, str):
                                continue
                            mcp_url = apply_environment_variables(mcp_url)
                            mcp_config[item]["url"] = mcp_url
            self.client = Client(
                mcp_config,
                elicitation_handler=self.on_elicitation,
            )
        self.workspace_dir = workspace_dir
        self.name2tool: dict[str, BaseTool] = {}
        self.register_rpc_method("call_tool", self.call_tool)

    async def on_elicitation(
        self,
        message: str,
        response_type: type,
        params: ElicitRequestParams,
        context: RequestContext[ClientSession, LifespanContextT],
    ):
        # Present the message to the user and collect input
        # user_input = input(f"{message}: ")
        print(f"{message}")
        print("===Params===")
        print(params)
        print("===Context===")
        print(context)
        data = {
            "params": params.model_dump(),
        }
        result = await self.call_rpc(self.host_frontend_id, "elicitation", message, response_type, data, context)
        if not result:
            logger.error(f"Failed to send elicitation message to {self.host_frontend_id}")
            return ElicitResult(action="reject")

        return ElicitResult(action="accept", content=result)

    def apply_env_change(self, env: Optional[dict[str, str]]):
        if not env:
            return
        diff = {k: v for k, v in env.items() if k not in self.env or self.env[k] != v}
        if len(diff) == 0:
            return
        self.env.update(env)


    def get_function_declarations(self) -> List[FunctionDefinition]:
        return [tool.schema for tool in self.name2tool.values()]

    def get_all_tools(self) -> List[BaseTool]:
        return list(self.name2tool.values())

    def get_tool(self, name: str) -> Optional[BaseTool]:
        return self.name2tool.get(name)

    def register_tool(self, tool: BaseTool):
        if tool.name in self.name2tool:
            logger.warning(f'Warning: Tool "{tool.name}" already registered. Overwriting.')
        self.name2tool[tool.name] = tool

    async def discover_tools(self, session_state):
        tasks = [
            self.discover_session_tools(session_state),
            self.discover_mcp_tools(),
            self.discover_file_system_tools(self.workspace_dir),
        ]
        await asyncio.gather(*tasks)

    async def discover_mcp_tools(self):
        if not self.mcp_config:
            return
        async with self.client:
            tools = await self.client.list_tools()
            for tool in tools:
                self.register_tool(DiscoveredMcpTool(self.client, tool))

    async def discover_file_system_tools(self, workspace_dir: Optional[str] = None):
        workspace_dir = workspace_dir if workspace_dir else os.getcwd()
        if not workspace_dir or not os.path.isdir(workspace_dir):
            return
        if self.workspace_dir != workspace_dir:
            self.workspace_dir = workspace_dir
        tools = [
            ListDirectoryTool(workspace_dir=workspace_dir),
            ReadFileTool(workspace_dir=workspace_dir),
            WriteFileTool(workspace_dir=workspace_dir),
            GlobTool(workspace_dir=workspace_dir),
            GrepTool(workspace_dir=workspace_dir),
            ReplaceInFileTool(workspace_dir=workspace_dir),
            BashTool(workspace_dir=workspace_dir),
        ]
        for tool in tools:
            self.register_tool(tool)

    async def discover_session_tools(self, session_state):
        tools = [
            TodoWriteTool(session_state=session_state.todo_state),
            MemoryTool(session_state=session_state.memory_state),
            # WebFetchTool(),
            # WebSearchTool(engine="duckduckgo"),
        ]
        for tool in tools:
            self.register_tool(tool)

    async def get_tools(self, allowed_tools: Optional[list[str]] = None) -> list[ToolData]:
        results = []
        for name, tool in self.name2tool.items():
            if allowed_tools is None:
                results.append(tool.function_tool_schema)
                continue
            # 如果指定了 allowed_tools，则只返回这些工具
            if name in allowed_tools:
                results.append(tool.function_tool_schema)
        return results

    async def _handle_regular_message(self, msg: dict[str, Any]):
        """
        Handle regular (non-time) messages from other agents.

        Must be implemented by concrete agent classes to define
        agent-specific message handling behavior.

        Args:
            msg: The decoded message dictionary.
        """
        self.logger.info(msg)

    async def call_tool(
        self,
        request_id: str,
        call_id: str,
        session_id: str,
        call_name: str,
        call_args: dict[str, Any],
    ):
        tool_request = await self.new_task_request(
            request_id=request_id,
            task_id=call_id,
            session_id=session_id,
            payload={
                "call_name": call_name,
                "call_args": call_args,
            }
        )
        resp = await self.on_send_task(tool_request)
        return resp

    def _validate_request(self, request: Union[SendTaskRequest, SendTaskStreamingRequest]):
        task_send_params: TaskSendParams = request.params
        try:
            req = CallToolRequest.model_validate(task_send_params.payload)
        except Exception as e:
            self.logger.error(f"Invalid request payload: {e}")
            return InvalidParamsError(message=str(e))
        return req

    async def on_send_task_subscribe(self, request: SendTaskStreamingRequest) -> AsyncIterable[SendTaskStreamingResponse]:
        await self.upsert_task(request.params)
        task_send_params: TaskSendParams = request.params
        request_id = request.id
        task_id = task_send_params.id
        session_id = task_send_params.sessionId
        return self._stream_generator(request, session_id, request_id, task_id)

    async def _stream_generator(
        self,
        request: SendTaskStreamingRequest,
        session_id: str,
        request_id: str,
        task_id: str,
    ) -> AsyncIterable[SendTaskStreamingResponse]:
        resp = await self.working_streaming_response(request_id=request_id, task_id=task_id)
        yield resp

        req = self._validate_request(request)
        if isinstance(req, JSONRPCError):
            self.logger.error(f"Error in tool task: {req}")
            resp = await self.fail_streaming_response(request_id=request_id, task_id=task_id, error=req)
            yield resp
            return
        self.logger.debug(f"Tool Call\n{req.call_name}\n{req.call_args}")
        tool = self.get_tool(req.call_name)
        if not tool:
            error_message = f"Tool not found: {req.call_name}"
            self.logger.error(error_message)
            resp = await self.fail_streaming_response(request_id=request_id, task_id=task_id, error=error_message)
            yield resp
            return

        parser = StreamableResponseParser()
        response = parser.init_response(response_id=task_id)
        seq_counter = SequenceCounter()
        resp = await self.counting_event_streaming_response(
            request_id=request_id,
            task_id=task_id,
            parser=parser,
            seq_counter=seq_counter,
            event=ResponseCreatedEvent(
                response=parser.response,
            ),
        )
        if req.return_response_event:
            yield resp
        resp = await self.counting_event_streaming_response(
            request_id=request_id,
            task_id=task_id,
            parser=parser,
            seq_counter=seq_counter,
            event=ResponseInProgressEvent(
                response=parser.response,
            ),
        )
        if req.return_response_event:
            yield resp
        current_step = 0
        output_item = FunctionCallOutputItem(
            call_id=task_id,
            output=[],
            message_content=[],
            block_list=[],
        )
        resp = await self.counting_event_streaming_response(
            request_id=request_id,
            task_id=task_id,
            parser=parser,
            seq_counter=seq_counter,
            event=ResponseOutputItemAddedEvent(
                agent_step=current_step,
                item=output_item,
            ),
        )
        if req.return_response_event:
            yield resp

        try:
            tool_result = await tool.execute(req.call_args)
        except Exception as e:
            error_message = f"Error while calling {req.call_name}: {e}"
            self.logger.error(f"{error_message}\n{traceback.format_exc()}")
            tool_result = tool_result_of_internal_error(error_message)

        resp = await self.counting_event_streaming_response(
            request_id=request_id,
            task_id=task_id,
            parser=parser,
            seq_counter=seq_counter,
            event=ResponseToolCallResultDeltaEvent(
                item_id=output_item.id,
                call_id=output_item.call_id,
                agent_step=current_step,
                delta_message_content=tool_result.message_content,
                delta_block_list=tool_result.block_list,
            ),
        )
        if req.return_response_event:
            yield resp

        resp = await self.counting_event_streaming_response(
            request_id=request_id,
            task_id=task_id,
            parser=parser,
            seq_counter=seq_counter,
            event=ResponseToolCallResultDoneEvent(
                item_id=output_item.id,
                call_id=output_item.call_id,
                agent_step=current_step,
                message_content=tool_result.message_content,
                block_list=tool_result.block_list,
            ),
        )
        if req.return_response_event:
            yield resp
        output_item.message_content = tool_result.message_content
        output_item.block_list = tool_result.block_list
        output_item.output = message_content_to_output(tool_result.message_content)
        resp = await self.counting_event_streaming_response(
            request_id=request_id,
            task_id=task_id,
            parser=parser,
            seq_counter=seq_counter,
            event=ResponseOutputItemDoneEvent(
                agent_step=current_step,
                item=output_item,
            ),
        )
        if req.return_response_event:
            yield resp

        resp = await self.counting_event_streaming_response(
            request_id=request_id,
            task_id=task_id,
            parser=parser,
            seq_counter=seq_counter,
            event=ResponseCompletedEvent(
                response=parser.response,
            ),
        )
        if req.return_response_event:
            yield resp
        final_response = response if not req.return_response_event else None
        resp = await self.complete_streaming_response(request_id=request_id, task_id=task_id, metadata=final_response)
        yield resp

    async def on_send_task(self, request: SendTaskRequest) -> SendTaskResponse:
        await self.upsert_task(request.params)
        return await self._invoke(request)

    async def _invoke(self, request: SendTaskRequest) -> SendTaskResponse:
        task_send_params: TaskSendParams = request.params
        session_id = task_send_params.sessionId
        payload = task_send_params.payload
        call_id: str = payload.get("call_id", f"call_{uuid.uuid4().hex}")
        call_name: str = payload.get("call_name", "unknown_function")
        call_args: dict[str, Any] = payload.get("call_args", {})

        self.logger.debug(f"Tool Call\n{call_name}\n{call_args}")
        tool = self.get_tool(call_name)
        if not tool:
            error_message = f"Tool not found: {call_name}"
            self.logger.error(error_message)
            return SendTaskResponse(id=request.id, error=JSONRPCError(code=-32000, message=error_message))
        try:
            result = await tool.execute(call_args)
            self.logger.debug(f"Tool Result\n{result}")
            task = await self.update_store(
                task_send_params.id,
                TaskStatus(state=TaskState.COMPLETED),
                result,
            )
            return SendTaskResponse(id=request.id, result=task)
        except Exception as exc:
            self.logger.error(f"Error in tool task: {exc}")
            return SendTaskResponse(id=request.id, error=JSONRPCError(code=-32000, message=str(exc)))
