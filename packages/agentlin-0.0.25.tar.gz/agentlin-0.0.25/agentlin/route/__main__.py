from pathlib import Path
import traceback
from typing import Annotated, Optional
import uuid

import typer
import asyncio
from loguru import logger
from dotenv import load_dotenv

from agentlin.core.types import AgentResponseEvent, AgentResponseEventType, ResponseCompletedEvent, SendTaskStreamingResponse, TaskArtifactUpdateEvent
from agentlin.route.agent import Agent
from agentlin.route.agent_config import load_agent_config

app = typer.Typer()


@app.callback(invoke_without_command=True)
def run(
    agent: Annotated[str, typer.Option(..., "--agent", "-a", help="Path to the agent config directory or file")],
    instruction: Annotated[str, typer.Option(..., "--instruction", "-i", help="Instruction to guide the agent")],
    rollout_dir: Annotated[Optional[str], typer.Option(..., "--rollout-dir", help="Directory to save rollouts")] = None,
    workspace_path: Annotated[Optional[str], typer.Option(..., "--workspace", "-w", help="Path to the workspace directory")] = None,
    verbose: Annotated[bool, typer.Option(..., "--verbose", "-v", help="Whether to print progress bars and logs")] = True,
):
    """Run an agent.

    Examples:

    $ agent-run --agent ./path/to/agent/main.md -i "Tell me a joke"
    """
    load_dotenv()
    workspace_path: Path = Path.cwd() if workspace_path is None else Path(workspace_path)
    if not workspace_path.exists():
        workspace_path.mkdir(parents=True, exist_ok=True)

    asyncio.run(
        run_async(
            agent_path=agent,
            instruction=instruction,
            rollout_dir=rollout_dir,
            workspace_path=workspace_path,
            verbose=verbose,
        )
    )


async def run_async(
    agent_path: str,
    instruction: str,
    rollout_dir: Optional[str],
    workspace_path: Path,
    verbose: bool,
):
    # Prepare agent config
    agent_config = await load_agent_config(agent_path)
    logger.success(f"Loaded agent config from {agent_path}")
    agent = Agent(debug=verbose)
    session_id = str(uuid.uuid4().hex)
    stream = await agent(
        session_id=session_id,
        user_message_content=[{"type": "text", "text": instruction}],
        stream=True,
        agent_config=agent_config,
        workspace_dir=str(workspace_path),
        rollout_save_dir=rollout_dir,
        return_rollout=True,
        return_response_event=True,
    )
    try:
        async for response in stream:
            if isinstance(response, SendTaskStreamingResponse):
                result = response.result
                if isinstance(result, TaskArtifactUpdateEvent):
                    data = result.metadata
                    if not data:
                        continue
                    event: AgentResponseEvent = AgentResponseEventType.validate_python(data)
                    # logger.info(event)
                    if isinstance(event, ResponseCompletedEvent):
                        response_item = event.response
    except Exception as e:
        logger.error(f"Failed: {e}\n{traceback.format_exc()}")
        agent.delete_session(session_id)



if __name__ == "__main__":
    app()
