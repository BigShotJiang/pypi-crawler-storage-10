from agentlin.route.session_manager import SessionTaskManager


class Agent(SessionTaskManager):
    pass