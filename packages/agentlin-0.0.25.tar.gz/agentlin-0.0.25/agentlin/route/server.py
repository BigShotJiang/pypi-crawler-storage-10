
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
from loguru import logger

from agentlin.route.route_chatkit import AgentChatKitServer, InMemoryStore, create_chatkit_router
from agentlin.route.route_task import create_task_router


def create_server() -> FastAPI:
    app = FastAPI(
        title="Agent Server",
        description="A service for managing agent tasks and sessions",
        version="1.0.0",
        openapi_tags=[
            {
                "name": "Agent Server",
                "description": "Endpoints for managing agent tasks and sessions",
            }
        ],
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    store = InMemoryStore()
    server = AgentChatKitServer(
        store,
        debug=True,
        use_message_queue=False,
    )
    app.include_router(create_chatkit_router(server))
    app.include_router(create_task_router(server.session_task_manager), prefix="/v1")


    @app.get("/readiness")
    def readiness():
        """
        Readiness endpoint to check if the service is ready.
        """
        return {"readiness": "ok"}


    @app.get("/liveness")
    def liveness():
        """
        Liveness endpoint to check if the service is alive.
        """
        return {"liveness": "ok"}


    @app.get("/")
    def root():
        """
        Root endpoint to check if the service is running.
        """
        return {"message": "Session Manager Service is running."}


    @app.get("/health")
    def health():
        """
        Health check endpoint to verify the service is operational.
        """
        return {"status": "healthy"}


    @app.get("/version")
    def version():
        """
        Version endpoint to return the service version.
        """
        return {
            "version": "1.0.0",
            "description": "Session Manager Service for Jupyter Kernels",
        }
    return app


if __name__ == "__main__":
    import argparse
    import uvicorn

    parser = argparse.ArgumentParser(description="Run the FastAPI app")
    parser.add_argument("--host", type=str, default="0.0.0.0", help="Host to bind")
    parser.add_argument("--port", type=int, default=9999, help="Port to bind")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    parser.add_argument("--env-file", type=str, default=".env", help="Path to the .env file")
    args = parser.parse_args()

    logger.info(f"Loading environment variables from {args.env_file}")
    load_dotenv(args.env_file)

    logger.info(f"Starting Agent Server on {args.host}:{args.port}")

    app = create_server()
    if args.debug:
        logger.info("Debug mode is enabled.")
        app.debug = True
        app.logger.setLevel("DEBUG")

    uvicorn.run(app, host=args.host, port=args.port)
