class RemovedInWhistle2Error(Exception):
    pass
