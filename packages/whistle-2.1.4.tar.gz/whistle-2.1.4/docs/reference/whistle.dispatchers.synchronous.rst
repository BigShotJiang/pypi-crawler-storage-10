whistle.dispatchers.synchronous
===============================

.. automodule:: whistle.dispatchers.synchronous
    :members:
    :undoc-members:
    :show-inheritance:
