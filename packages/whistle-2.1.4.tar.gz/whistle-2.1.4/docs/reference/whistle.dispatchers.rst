whistle.dispatchers
===================

.. automodule:: whistle.dispatchers
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

.. toctree::
    :maxdepth: 1

    whistle.dispatchers.asynchronous
    whistle.dispatchers.base
    whistle.dispatchers.synchronous
