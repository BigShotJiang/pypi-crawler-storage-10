whistle.typing.dispatcher
=========================

.. automodule:: whistle.typing.dispatcher
    :members:
    :undoc-members:
    :show-inheritance:
