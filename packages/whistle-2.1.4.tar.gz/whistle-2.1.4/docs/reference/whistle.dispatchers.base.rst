whistle.dispatchers.base
========================

.. automodule:: whistle.dispatchers.base
    :members:
    :undoc-members:
    :show-inheritance:
