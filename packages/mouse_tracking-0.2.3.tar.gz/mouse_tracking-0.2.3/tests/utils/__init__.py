"""Tests for utils module."""
