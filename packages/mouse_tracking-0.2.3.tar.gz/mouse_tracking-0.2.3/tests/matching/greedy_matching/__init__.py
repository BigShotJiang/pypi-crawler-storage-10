"""Tests for greedy matching."""
