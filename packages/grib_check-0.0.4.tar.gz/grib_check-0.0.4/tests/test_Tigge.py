#
# (C) Copyright 2025- ECMWF.
#
# This software is licensed under the terms of the Apache Licence Version 2.0
# which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
# In applying this licence, ECMWF does not waive the privileges and immunities
# granted to it by virtue of its status as an intergovernmental organisation
# nor does it submit to any jurisdiction.
#

import os

from grib_check.checker.Tigge import Tigge
from grib_check.Grib import Grib
from grib_check.LookupTable import SimpleLookupTable

src_path = f"{os.path.dirname(os.path.realpath(__file__))}/../src/grib_check"


class TestTigge:
    def test_tigge_param_10v_good(self):
        tigge_params = (f"{src_path}/checker/TiggeParameters.jsonnet")
        checker = Tigge(SimpleLookupTable(tigge_params), check_limits=False, check_validity=False)
        grib = Grib("./tests/tigge/tigge_ecmf_sfc_10v.grib")
        message = next(grib)
        report = checker.validate(message)
        assert report.status() is True
