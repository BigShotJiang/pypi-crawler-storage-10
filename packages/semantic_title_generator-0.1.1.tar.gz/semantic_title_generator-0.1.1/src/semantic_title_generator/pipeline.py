"""Pipeline module for semantic_title_generator.

This module defines the configuration dataclass :class:`STGConfig`, the main
class :class:`SemanticTitleGenerator` implementing the five‑step pipeline for
preprocessing, chunking, summarisation, aggregation and title/keyword
generation, and the convenience wrapper function :func:`Semantic_title_generator`.

The library depends on the Google Generative AI SDK (``google-generativeai``)
and requires a valid API key.  It also optionally uses ``PyPDF2`` to extract
text from PDFs, ``python-docx`` to read DOCX files and ``beautifulsoup4``
with ``lxml`` for HTML parsing.  These dependencies are declared in
``pyproject.toml`` and will be installed automatically when the package is
installed.
"""

from __future__ import annotations

import os
import re
import ast
from dataclasses import dataclass
from typing import List, Tuple, Optional

try:
    import google.generativeai as genai
except ImportError as e:
    raise ImportError(
        "Package 'google-generativeai' is required. Install via: pip install google-generativeai"
    )


def _read_text_file(path: str) -> str:
    """Read the contents of a text file using UTF‑8 encoding.

    Errors are ignored to avoid UnicodeDecodeErrors when reading arbitrary files.
    """
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def _read_pdf(path: str) -> str:
    """Extract text from a PDF using PyPDF2.

    Raises ImportError if ``PyPDF2`` is not installed.
    """
    try:
        from PyPDF2 import PdfReader
    except ImportError:
        raise ImportError("Install PyPDF2 to read PDFs: pip install PyPDF2")
    reader = PdfReader(path)
    # Concatenate text from all pages, substituting empty strings if no text found
    return "\n".join(page.extract_text() or "" for page in reader.pages)


def _read_docx(path: str) -> str:
    """Extract text from a DOCX file using python‑docx.

    Raises ImportError if ``python-docx`` is not installed.
    """
    try:
        import docx
    except ImportError:
        raise ImportError("Install python-docx to read .docx: pip install python-docx")
    doc = docx.Document(path)
    return "\n".join(p.text for p in doc.paragraphs)


def _read_html(path: str) -> str:
    """Extract visible text from an HTML file using BeautifulSoup.

    Falls back to a simple regular expression based strip if BeautifulSoup/lxml is not available.
    """
    text = _read_text_file(path)
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(text, "lxml")
        return soup.get_text(separator=" ")
    except Exception:
        # Fall back to regex stripping if bs4/lxml not present
        text = re.sub(r"<script.*?>.*?</script>", " ", text, flags=re.S)
        text = re.sub(r"<style.*?>.*?</style>", " ", text, flags=re.S)
        text = re.sub(r"<[^>]+>", " ", text)
        return text


def _read_any(path: str) -> str:
    """Read a file of various supported types and return its text contents.

    Supports .txt, .md, .markdown, .html/.htm, .pdf and .docx.  Any other
    extension is treated as plain text.
    """
    ext = os.path.splitext(path)[1].lower()
    if ext in [".txt", ".md", ".markdown"]:
        return _read_text_file(path)
    if ext in [".html", ".htm"]:
        return _read_html(path)
    if ext in [".pdf"]:
        return _read_pdf(path)
    if ext in [".docx"]:
        return _read_docx(path)
    # Fallback: treat as text
    return _read_text_file(path)


@dataclass
class STGConfig:
    """Configuration for the SemanticTitleGenerator.

    Parameters
    ----------
    model_name : str
        The name of the Gemini model to use.  Default is ``gemini-2.5-pro``.
    temperature : float
        The sampling temperature for the model.  Lower values make the output more deterministic.
    chunk_size : int
        Number of words per chunk when splitting the document.  Default is 512.
    overlap : int
        Number of words to overlap between successive chunks.  Default is 128 (25% of the default chunk size).
    max_reduce_fan_in : int
        How many summaries to combine in a single reduce step during aggregation.  Default is 8.
    """

    model_name: str = "gemini-2.5-pro"
    temperature: float = 0.3
    chunk_size: int = 512
    overlap: int = 128
    max_reduce_fan_in: int = 8


class SemanticTitleGenerator:
    """Implements a five‑step pipeline to generate a title and keywords for long documents.

    The steps are:

    1. **Preprocess** the raw input text (normalise whitespace, strip control characters).
    2. **Chunk** the text with optional overlap so that each segment is manageable for the API.
    3. **Summarise** each chunk using the Gemini API.
    4. **Aggregate** all chunk summaries using a hierarchical map‑reduce approach to produce a single abstract.
    5. **Generate** a final title and list of keywords from the abstract.

    Use the :func:`run` method to orchestrate the entire pipeline.
    """

    def __init__(self, api_key: str, config: Optional[STGConfig] = None) -> None:
        if not api_key:
            raise ValueError("Gemini API key is required.")
        # configure the genai module globally
        genai.configure(api_key=api_key)
        self.cfg = config or STGConfig()
        # instantiate the generative model
        self.model = genai.GenerativeModel(
            model_name=self.cfg.model_name,
            generation_config={"temperature": self.cfg.temperature},
        )

    # Step 1: Preprocess
    @staticmethod
    def preprocess(text: str) -> str:
        """Normalise a text string by removing control characters and excess whitespace."""
        text = text.replace("\u200c", " ")  # normalise ZWNJ (zero width non‑joiner)
        text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", " ", text)
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()

    # Step 2: Chunking with overlap
    def chunk_text(
        self,
        text: str,
        chunk_size: Optional[int] = None,
        overlap: Optional[int] = None,
    ) -> List[str]:
        """Split the input text into overlapping chunks.

        Parameters
        ----------
        text : str
            The input document as a single string.
        chunk_size : int, optional
            Override the configured chunk size.  If not provided, the value from
            ``self.cfg.chunk_size`` is used.
        overlap : int, optional
            Override the configured overlap.  If not provided, the value from
            ``self.cfg.overlap`` is used.

        Returns
        -------
        list of str
            A list of text chunks.
        """
        cs = int(chunk_size or self.cfg.chunk_size)
        ov = int(overlap if overlap is not None else self.cfg.overlap)
        ov = max(0, min(ov, cs - 1))
        words = text.split()
        if not words:
            return []
        step = cs - ov
        chunks = []
        for start in range(0, len(words), step):
            end = min(start + cs, len(words))
            chunk = " ".join(words[start:end])
            chunks.append(chunk)
            if end == len(words):
                break
        return chunks

    # Step 3: Summarise each chunk
    def _llm(self, prompt: str) -> str:
        """Send a prompt to the generative model and return the text of the response."""
        resp = self.model.generate_content(prompt)
        return (resp.text or "").strip()

    def summarize_chunk(self, chunk: str) -> str:
        """Produce a concise summary of a single chunk (2–3 sentences)."""
        prompt = (
            "You are a precise summarizer. Summarize the following text chunk in 2–3 concise sentences, "
            "capturing the central topic, key entities, and salient facts. "
            "Write in the same language as the input. Avoid opinions.\n\n"
            f"Text:\n```{chunk}```\n\nSummary:"
        )
        return self._llm(prompt)

    def summarize_chunks(self, chunks: List[str]) -> List[str]:
        """Summarise a list of chunks sequentially and return their summaries."""
        summaries: List[str] = []
        for ch in chunks:
            if ch.strip():
                summaries.append(self.summarize_chunk(ch))
        return summaries

    # Step 4: Aggregate (map‑reduce)
    def _reduce_once(self, pieces: List[str]) -> List[str]:
        """Reduce a list of summary pieces into fewer aggregated summaries.

        Groups up to ``max_reduce_fan_in`` summaries and asks the model to
        produce a cohesive abstract.  Returns a list of reduced summaries.
        """
        reduced: List[str] = []
        for i in range(0, len(pieces), self.cfg.max_reduce_fan_in):
            window = pieces[i : i + self.cfg.max_reduce_fan_in]
            joined = "\n\n".join(f"- {p}" for p in window)
            prompt = (
                "You are an expert at hierarchical summarization. Given these chunk summaries, "
                "produce a single cohesive abstract (4–6 sentences) that integrates overlapping points, "
                "resolves contradictions, and keeps named entities and facts accurate. "
                "Write in the same language as the input summaries.\n\n"
                f"Chunk summaries:\n{joined}\n\nAbstract:"
            )
            reduced.append(self._llm(prompt))
        return reduced

    def aggregate_summaries(self, chunk_summaries: List[str]) -> str:
        """Aggregate a list of chunk summaries into a single abstract using hierarchical reduction."""
        if not chunk_summaries:
            return ""
        level = chunk_summaries[:]
        while len(level) > 1:
            level = self._reduce_once(level)
        return level[0]

    # Step 5: Generate title and keywords
    def generate_title_keywords(self, abstract_text: str, k: int = 5) -> Tuple[str, List[str]]:
        """Generate a title and keywords from an abstract.

        Parameters
        ----------
        abstract_text : str
            The abstract or document summary.
        k : int
            The number of keywords to generate.

        Returns
        -------
        tuple[str, list[str]]
            The title and a list of keywords.
        """
        prompt = (
            "You will generate a title and main keywords from the abstract below.\n"
            f"Return output STRICTLY as a Python dict with two keys exactly: 'title' and 'keywords'.\n"
            f"- 'title': a concise, informative title (<= 12 words), same language as input.\n"
            f"- 'keywords': exactly {k} main keywords as a Python list of strings.\n"
            "No extra text, no markdown. Output ONLY the Python dict.\n\n"
            f"Abstract:\n```{abstract_text}```\n\n"
            "Python dict:"
        )
        raw = self._llm(prompt)
        title: str = ""
        keywords: List[str] = []
        # Try to parse the returned string as a Python literal
        try:
            data = ast.literal_eval(raw)  # type: ignore[arg-type]
            title = str(data.get("title", "")).strip()
            kw = data.get("keywords", [])
            if isinstance(kw, (list, tuple)):
                keywords = [str(x).strip() for x in kw if str(x).strip()]
        except Exception:
            # Fallback: attempt to extract using regex if the model did not follow instructions
            m = re.search(r"title'\s*:\s*'([^']+)'", raw)
            if m:
                title = m.group(1)
            m = re.search(r"keywords'\s*:\s*\[([^\]]+)\]", raw)
            if m:
                parts = [p.strip().strip("'\"") for p in m.group(1).split(",")]
                keywords = [p for p in parts if p]
        return title, keywords

    # Orchestrator
    def run(
        self,
        path_or_text: str,
        chunk_size: Optional[int] = None,
        overlap: Optional[int] = None,
    ) -> Tuple[str, List[str]]:
        """Run the full pipeline on a document path or raw text.

        Parameters
        ----------
        path_or_text : str
            Either the path to a file (supported types: txt, md, markdown, html, pdf, docx) or a raw text string.
        chunk_size : int, optional
            Override the configured chunk size.
        overlap : int, optional
            Override the configured overlap.

        Returns
        -------
        tuple[str, list[str]]
            The generated title and keywords.
        """
        text = path_or_text
        # If the path exists on disk, read the file
        if os.path.exists(path_or_text):
            text = _read_any(path_or_text)
        # Step 1
        cleaned = self.preprocess(text)
        # Step 2
        chunks = self.chunk_text(cleaned, chunk_size=chunk_size, overlap=overlap)
        # Step 3
        summaries = self.summarize_chunks(chunks)
        # Step 4
        abstract_text = self.aggregate_summaries(summaries) if summaries else ""
        basis = abstract_text if abstract_text.strip() else cleaned
        # Step 5
        title, keywords = self.generate_title_keywords(basis, k=5)
        return title, keywords


def Semantic_title_generator(
    path_document: str = "",
    Gemini_API_KEY: str = "",
    chunkSize: int = 512,
    model: str = "gemini-2.5-pro",
    temperature: float = 0.3,
    Model: Optional[str] = None,
) -> Tuple[str, List[str]]:
    """Convenience function to run the pipeline on a document.

    This wrapper exists for API compatibility with earlier versions.  It accepts
    both ``model`` (preferred) and ``Model`` (deprecated) keyword arguments for
    selecting the Gemini model.  If both are provided, ``Model`` takes
    precedence.

    Parameters
    ----------
    path_document : str
        Path to a document (txt/pdf/docx/html/markdown) or a raw text string.
    Gemini_API_KEY : str
        Your Gemini API key.
    chunkSize : int
        Number of words per chunk.  Overlap is calculated as ``chunkSize//4``.
    model : str
        Name of the Gemini model (e.g., ``"gemini-2.5-pro"``).
    temperature : float
        Sampling temperature for the model.
    Model : str, optional
        Alternate capitalised parameter for the model name.  Takes precedence over
        ``model`` if provided.

    Returns
    -------
    tuple[str, list[str]]
        The generated title and keywords.
    """
    if not Gemini_API_KEY:
        raise ValueError("Please provide Gemini_API_KEY.")
    selected_model = Model or model
    cfg = STGConfig(
        model_name=selected_model,
        temperature=temperature,
        chunk_size=chunkSize,
        overlap=max(1, chunkSize // 4),
    )
    pipe = SemanticTitleGenerator(api_key=Gemini_API_KEY, config=cfg)
    return pipe.run(path_document, chunk_size=chunkSize, overlap=cfg.overlap)