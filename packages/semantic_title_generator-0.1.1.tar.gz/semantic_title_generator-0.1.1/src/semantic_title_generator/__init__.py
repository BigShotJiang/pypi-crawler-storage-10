"""Top‑level package for semantic_title_generator.

This module exposes the main entry points:

- :func:`Semantic_title_generator` – convenience function to generate a title and keywords from a document or raw text.
- :class:`SemanticTitleGenerator` – class implementing the full five‑step pipeline.
- :class:`STGConfig` – configuration dataclass.

Example::

    from semantic_title_generator import Semantic_title_generator

    title, keywords = Semantic_title_generator(
        path_document="mydoc.pdf",
        Gemini_API_KEY="your_api_key",
        model="gemini-2.5-pro",
    )
"""

from .pipeline import STGConfig, SemanticTitleGenerator, Semantic_title_generator

__all__ = [
    "STGConfig",
    "SemanticTitleGenerator",
    "Semantic_title_generator",
]

__version__ = "0.1.0"