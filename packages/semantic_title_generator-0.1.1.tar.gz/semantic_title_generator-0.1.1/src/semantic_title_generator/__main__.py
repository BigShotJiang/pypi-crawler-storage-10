"""Command line interface for semantic-title-generator.

Usage:

```
stg <path_or_text> [--api_key KEY] [--model MODEL] [--chunk N] [--temperature T]
```

This script can be executed directly via ``python -m semantic_title_generator``
or through the ``stg`` entry point installed by the package.
"""

import argparse
import os
from typing import Optional

from .pipeline import Semantic_title_generator


def main(argv: Optional[list[str]] = None) -> None:
    parser = argparse.ArgumentParser(
        description="Generate a concise title and keywords from a document.",
        epilog="You can also set the GEMINI_API_KEY environment variable instead of passing --api_key."
    )
    parser.add_argument(
        "path",
        help=(
            "Path to the document (txt/pdf/docx/html/markdown) or raw text. "
            "If the argument is not an existing file, it will be treated as raw text."
        ),
    )
    parser.add_argument(
        "--api_key",
        default=None,
        help="Gemini API key. If omitted, GEMINI_API_KEY environment variable is used.",
    )
    parser.add_argument(
        "--model",
        default="gemini-2.5-pro",
        help="Name of the Gemini model to use (e.g., 'gemini-1.5-flash', 'gemini-2.5-pro').",
    )
    parser.add_argument(
        "--chunk",
        type=int,
        default=512,
        help="Chunk size (in words) for splitting the document. Default is 512.",
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=0.3,
        help="Sampling temperature for the model (0.0–1.0). Default is 0.3.",
    )
    args = parser.parse_args(argv)
    api_key = args.api_key or os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise SystemExit("Gemini API key is required. Provide --api_key or set GEMINI_API_KEY.")
    # Determine whether input is a file path or raw text
    path_or_text = args.path
    # Run the pipeline
    title, keywords = Semantic_title_generator(
        path_document=path_or_text,
        Gemini_API_KEY=api_key,
        model=args.model,
        chunkSize=args.chunk,
        temperature=args.temperature,
    )
    print("Title:", title)
    print("Keywords:", keywords)


if __name__ == "__main__":
    main()