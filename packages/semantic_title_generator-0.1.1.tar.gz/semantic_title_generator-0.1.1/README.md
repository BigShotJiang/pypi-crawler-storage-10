# Semantic Title Generator

Generate concise titles and keywords from long documents using Google’s Gemini API.  This library chunks long input texts, summarizes each chunk, aggregates the summaries with a hierarchical map‑reduce approach, then produces a final title and a list of keywords.

## Features

- Supports plain text, PDF, DOCX and HTML inputs.
- Uses configurable chunk sizes with overlap to preserve context across boundaries.
- Summarises text hierarchically to handle long inputs efficiently.
- Generates a title and a list of keywords in one API call.
- Flexible configuration of the Gemini model and temperature.
- Comes with a command‑line interface (CLI) for quick use.

## Installation

Install the package from PyPI (replace `<version>` with the latest release):

```bash
pip install semantic-title-generator
```

Alternatively, clone the repository and install locally:

```bash
git clone https://github.com/yourusername/semantic-title-generator.git
cd semantic-title-generator
pip install .
```

## Usage

### Python API

Import the helper function `Semantic_title_generator` to quickly produce a title and keywords.  You will need a Gemini API key with access to the specified model.

```python
from semantic_title_generator import Semantic_title_generator

title, keywords = Semantic_title_generator(
    path_document="path/to/file.pdf",  # can also be a raw text string
    Gemini_API_KEY="YOUR_GEMINI_API_KEY",
    model="gemini-2.5-pro",    # or another supported model like "gemini-1.5-flash"
    chunkSize=512,              # number of words per chunk (default 512)
    temperature=0.3             # sampling temperature (default 0.3)
)

print("Title:", title)
print("Keywords:", keywords)
```

### Command‑line interface

After installation the package exposes a CLI entry point `stg`.  You can call it on a file or raw text.  Set your API key via the `--api_key` argument or the `GEMINI_API_KEY` environment variable.

```bash
export GEMINI_API_KEY="YOUR_GEMINI_API_KEY"

# generate a title and keywords for a PDF
stg path/to/document.pdf --model gemini-2.5-pro --chunk 512

# generate for a plain text file and override the temperature
stg path/to/text.txt --temperature 0.2
```

Use `stg --help` to see all options.

## License

This project is licensed under the MIT License.  See the [LICENSE](LICENSE) file for details.
