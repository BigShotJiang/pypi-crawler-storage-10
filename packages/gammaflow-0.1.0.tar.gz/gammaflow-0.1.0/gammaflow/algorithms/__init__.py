"""
Algorithms for advanced spectral analysis.

This module provides implementations of advanced algorithms for gamma-ray
spectroscopy, including optimal ROI generation and anomaly detection.

Modules
-------
censored_energy_window : Censored Energy Window (CEW) method for optimal ROI generation
"""

from gammaflow.algorithms.censored_energy_window import (
    optimize_cew_windows,
    fit_cew_predictor,
    CEWPredictor,
)

__all__ = [
    'optimize_cew_windows',
    'fit_cew_predictor',
    'CEWPredictor',
]

