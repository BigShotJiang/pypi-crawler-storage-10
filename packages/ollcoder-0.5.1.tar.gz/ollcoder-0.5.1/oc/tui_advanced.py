"""
Advanced TUI for Ollcoder with full feature set.

This is a comprehensive TUI implementation including:
- Context Builder
- Memory Viewer  
- Autonomous Agent
- Security Scanner
- Code Diff Preview
- Session Management
- Streaming Responses
- File Editor
- Settings Panel
- Chat Search/Filter
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Optional
import json
import asyncio

try:
    from textual.app import App, ComposeResult
    from textual.containers import Container, Horizontal, Vertical, ScrollableContainer, VerticalScroll
    from textual.widgets import (
        Header, Footer, DirectoryTree, Input, Static, Label, 
        Button, SelectionList, OptionList, ListView, ListItem, Markdown,
        TabbedContent, TabPane, TextArea, ProgressBar, DataTable, Tree
    )
    from textual.widgets.option_list import Option
    from textual.binding import Binding
    from textual.screen import Screen, ModalScreen
    from textual import events, work
    from textual.message import Message
    from textual.reactive import reactive
    TEXTUAL_AVAILABLE = True
except ImportError:
    TEXTUAL_AVAILABLE = False
    # Minimal stubs to allow import without textual installed
    class App: ...
    class ComposeResult: ...
    class Container: ...
    class Horizontal: ...
    class Vertical: ...
    class VerticalScroll: ...
    class ScrollableContainer: ...
    class Header: ...
    class Footer: ...
    class DirectoryTree:
        class FileSelected: ...
    class Input:
        class Submitted: ...
        def __init__(self, *args, **kwargs): pass
    class Static:
        def __init__(self, *args, **kwargs): pass
    class Label: ...
    class Button:
        class Pressed: ...
        def __init__(self, *args, **kwargs): pass
    class SelectionList: ...
    class OptionList:
        class OptionSelected: ...
        def __init__(self, *args, **kwargs): pass
    class ListView: ...
    class ListItem: ...
    class Markdown: ...
    class TabbedContent: ...
    class TabPane:
        def __init__(self, *args, **kwargs): pass
    class TextArea:
        def __init__(self, *args, **kwargs): pass
        @property
        def text(self):
            return ""
    class ProgressBar: ...
    class DataTable:
        def add_columns(self, *args, **kwargs): pass
    class Tree: ...
    class Option:
        def __init__(self, *args, **kwargs): pass
    class Binding:
        def __init__(self, *args, **kwargs): pass
    class Screen: ...
    class ModalScreen: ...
    class events: ...
    class work: ...
    class Message: ...
    class reactive: ...

import re


# ==================== Modal Screens ====================

class ContextBuilderScreen(ModalScreen):
    """Build and view codebase context."""
    
    def compose(self) -> ComposeResult:
        with Container(id="context-dialog"):
            yield Static("[bold cyan]Context Builder[/bold cyan]", id="dialog-title")
            yield Input(placeholder="Enter query (e.g. 'authentication')", id="query-input")
            
            with Horizontal(id="compression-select"):
                yield Static("Compression: ")
                yield OptionList(
                    Option("NONE", id="NONE"),
                    Option("SEMANTIC", id="SEMANTIC"),
                    Option("HEURISTIC", id="HEURISTIC"),
                    Option("MODERATE", id="MODERATE"),
                    Option("SUMMARY", id="SUMMARY"),
                    id="compression-list"
                )
            
            yield ScrollableContainer(
                Static("Context will appear here...", id="context-output"),
                id="context-scroll"
            )
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Build", variant="primary", id="build-btn")
                yield Button("Copy", variant="default", id="copy-btn")
                yield Button("Close", variant="default", id="close-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss(None)
        elif event.button.id == "build-btn":
            self.build_context()
        elif event.button.id == "copy-btn":
            output = self.query_one("#context-output", Static)
            text = output.renderable if hasattr(output, 'renderable') else str(output)
            
            # Try pyperclip first, fall back to manual methods
            try:
                import pyperclip
                # Strip rich markup for clipboard
                import re
                clean_text = re.sub(r'\[.*?\]', '', str(text))
                pyperclip.copy(clean_text)
                output.update(output.renderable + "\n\n[green]✓ Copied to clipboard![/green]")
            except ImportError:
                # Fallback: try xclip on Linux
                try:
                    import subprocess
                    clean_text = re.sub(r'\[.*?\]', '', str(text))
                    subprocess.run(['xclip', '-selection', 'clipboard'], 
                                 input=clean_text.encode(), check=True)
                    output.update(output.renderable + "\n\n[green]✓ Copied to clipboard (xclip)![/green]")
                except Exception:
                    # Last resort: save to file
                    try:
                        import tempfile
                        clean_text = re.sub(r'\[.*?\]', '', str(text))
                        tmp = tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt')
                        tmp.write(clean_text)
                        tmp.close()
                        output.update(output.renderable + f"\n\n[yellow]Saved to: {tmp.name}[/yellow]")
                    except Exception as e:
                        output.update(output.renderable + f"\n\n[red]Could not copy: {e}[/red]")
    
    def build_context(self) -> None:
        """Build context from query."""
        from .adaptive_builder import AdaptiveConfig, build_adaptive_context
        from .context_cache import ContextCache
        from .context_strategy import format_context_summary
        
        query_input = self.query_one("#query-input", Input)
        query = query_input.value.strip()
        
        if not query:
            return
        
        output = self.query_one("#context-output", Static)
        output.update(f"[cyan]Building context for:[/cyan] {query}\\n\\n[dim]Loading...[/dim]")
        
        try:
            # Get root directory from parent app
            root = str(Path.cwd())
            cache = ContextCache(root)
            cfg = AdaptiveConfig(root_dir=root, query=query)
            
            files, stats = build_adaptive_context(cfg, cache=cache, provider=None)
            
            # Format output
            result = [f"[bold green]✓ Built context with {len(files)} files[/bold green]\\n"]
            result.append(f"[dim]Token estimate: {stats.get('total_tokens', 0)}[/dim]\\n\\n")
            
            for f in files[:10]:  # Show first 10 files
                result.append(f"[cyan]{f.path}[/cyan] [{f.priority.name}]\\n")
                content_preview = f.content[:200].replace('\\n', ' ')
                result.append(f"[dim]{content_preview}...[/dim]\\n\\n")
            
            output.update("".join(result))
        except Exception as e:
            output.update(f"[red]❌ Error:[/red] {e}")


class MemoryViewerScreen(ModalScreen):
    """View agent memory sessions and learned patterns."""
    
    def compose(self) -> ComposeResult:
        with Container(id="memory-dialog"):
            yield Static("[bold cyan]Memory Viewer[/bold cyan]", id="dialog-title")
            
            with TabbedContent(initial="sessions"):
                with TabPane("Sessions", id="sessions"):
                    yield ScrollableContainer(
                        Static("Loading sessions...", id="sessions-list"),
                        id="sessions-scroll"
                    )
                
                with TabPane("Patterns", id="patterns"):
                    yield ScrollableContainer(
                        Static("Loading patterns...", id="patterns-list"),
                        id="patterns-scroll"
                    )
                
                with TabPane("Errors", id="errors"):
                    yield ScrollableContainer(
                        Static("Loading errors...", id="errors-list"),
                        id="errors-scroll"
                    )
            
            yield Button("Close", variant="primary", id="close-btn")
    
    def on_mount(self) -> None:
        """Load memory data on mount."""
        self.load_memory()
    
    def load_memory(self) -> None:
        """Load memory from store."""
        from .memory import global_memory
        
        try:
            mem = global_memory()
            sessions = mem.list_sessions()
            
            # Update sessions list
            sessions_widget = self.query_one("#sessions-list", Static)
            if not sessions:
                sessions_widget.update("[dim]No sessions found[/dim]")
            else:
                lines = ["[bold cyan]Available Sessions:[/bold cyan]\\n"]
                for session_id in sessions:
                    session = mem.get_session(session_id)
                    if session:
                        lines.append(f"\\n[cyan]• {session_id}[/cyan]")
                        lines.append(f"  Root: {session.root_dir}")
                        lines.append(f"  Tasks: {len(session.tasks)}")
                sessions_widget.update("".join(lines))
            
            # Load patterns from first session
            patterns_widget = self.query_one("#patterns-list", Static)
            if sessions:
                session = mem.get_session(sessions[0])
                if session and session.tasks:
                    lines = ["[bold cyan]Learned Patterns:[/bold cyan]\\n"]
                    for task in session.tasks[-5:]:  # Last 5 tasks
                        if task.lessons_learned:
                            lines.append(f"\\n[green]✓[/green] {task.task}")
                            for lesson in task.lessons_learned[:3]:
                                lines.append(f"  • {lesson}")
                    patterns_widget.update("".join(lines))
                else:
                    patterns_widget.update("[dim]No patterns learned yet[/dim]")
            
            # Load errors
            errors_widget = self.query_one("#errors-list", Static)
            if sessions:
                session = mem.get_session(sessions[0])
                if session and session.tasks:
                    lines = ["[bold cyan]Common Errors:[/bold cyan]\\n"]
                    for task in session.tasks[-5:]:
                        if task.errors_encountered:
                            lines.append(f"\\n[red]✗[/red] {task.task}")
                            for error in task.errors_encountered[:3]:
                                lines.append(f"  • {error}")
                    errors_widget.update("".join(lines) if len(lines) > 1 else "[dim]No errors recorded[/dim]")
                else:
                    errors_widget.update("[dim]No errors recorded[/dim]")
        except Exception as e:
            sessions_widget = self.query_one("#sessions-list", Static)
            sessions_widget.update(f"[red]Error loading memory:[/red] {e}")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss()


class AgentRunnerScreen(ModalScreen):
    """Run autonomous agent tasks with progress tracking."""
    
    def __init__(self, root: str, provider: Any, apply_changes: bool = False):
        super().__init__()
        self.root = root
        self.provider = provider
        self.apply_changes_default = apply_changes
        self.apply_changes = apply_changes
    
    def compose(self) -> ComposeResult:
        with Container(id="agent-dialog"):
            yield Static("[bold cyan]Autonomous Agent[/bold cyan]", id="dialog-title")
            yield Input(placeholder="Enter task (e.g. 'Add error handling to API')", id="task-input")
            
            with Horizontal():
                yield Static("Max Steps: ")
                yield Input(value="6", id="steps-input")
            
            with Horizontal():
                yield Static("Apply Changes: ")
                yield Button("Yes", variant="primary", id="apply-yes")
                yield Button("No", variant="default", id="apply-no")
            
            yield ProgressBar(total=100, show_eta=False, id="progress-bar")
            
            yield ScrollableContainer(
                Static("Agent output will appear here...", id="agent-output"),
                id="agent-scroll"
            )
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Run", variant="primary", id="run-btn")
                yield Button("Stop", variant="error", id="stop-btn", disabled=True)
                yield Button("Close", variant="default", id="close-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss()
        elif event.button.id == "run-btn":
            self.run_agent()
        elif event.button.id == "stop-btn":
            self.stop_agent()
        elif event.button.id == "apply-yes":
            self.apply_changes = True
            self.query_one("#apply-yes", Button).variant = "primary"
            self.query_one("#apply-no", Button).variant = "default"
        elif event.button.id == "apply-no":
            self.apply_changes = False
            self.query_one("#apply-yes", Button).variant = "default"
            self.query_one("#apply-no", Button).variant = "primary"
    
    def run_agent(self) -> None:
        """Start agent execution."""
        from .agent import AgentConfig, run_agent
        
        task_input = self.query_one("#task-input", Input)
        steps_input = self.query_one("#steps-input", Input)
        output = self.query_one("#agent-output", Static)
        progress = self.query_one("#progress-bar", ProgressBar)
        
        task = task_input.value.strip()
        if not task:
            output.update("[red]Please enter a task[/red]")
            return
        
        try:
            max_steps = int(steps_input.value)
        except ValueError:
            max_steps = 6
        
        output.update(f"[cyan]Starting agent...\\nTask: {task}\\nMax steps: {max_steps}\\nApply changes: {self.apply_changes}[/cyan]")
        
        # Disable run button, enable stop
        self.query_one("#run-btn", Button).disabled = True
        self.query_one("#stop-btn", Button).disabled = False
        
        try:
            cfg = AgentConfig(
                root_dir=self.root,
                task=task,
                max_steps=max_steps,
                apply_changes=self.apply_changes
            )
            
            result = run_agent(cfg, provider=self.provider)
            
            # Format output
            lines = [f"[bold]{'✓ SUCCESS' if result.success else '✗ INCOMPLETE'}[/bold]\\n"]
            lines.append(f"[cyan]{result.final_message}[/cyan]\\n\\n")
            
            for step in result.steps:
                lines.append(f"[bold]Step {step.step}:[/bold] {step.action}")
                if step.plan:
                    lines.append(f"  Plan: {', '.join(step.plan[:3])}")
                if step.edits_applied:
                    lines.append(f"  [green]Edits:[/green] {len(step.edits_applied)} files")
                if step.checks:
                    failed = [c for c in step.checks if not c.ok]
                    if failed:
                        lines.append(f"  [red]Checks:[/red] {len(failed)} failed")
                    else:
                        lines.append(f"  [green]Checks:[/green] All passed")
                lines.append("")
            
            progress.update(total=max_steps, progress=len(result.steps))
            output.update("\\n".join(lines))
            
        except Exception as e:
            output.update(f"[red]Error:[/red] {e}")
        finally:
            self.query_one("#run-btn", Button).disabled = False
            self.query_one("#stop-btn", Button).disabled = True
    
    def stop_agent(self) -> None:
        """Stop agent execution (not yet supported)."""
        output = self.query_one("#agent-output", Static)
        output.update("[yellow]Stop functionality requires async refactor - agent will complete current step[/yellow]")


class SecurityScannerScreen(ModalScreen):
    """Display security scan results."""
    
    def compose(self) -> ComposeResult:
        with Container(id="security-dialog"):
            yield Static("[bold cyan]Security Scanner[/bold cyan]", id="dialog-title")
            
            yield DataTable(id="security-table")
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Scan", variant="primary", id="scan-btn")
                yield Button("Export SARIF", variant="default", id="export-btn")
                yield Button("Close", variant="default", id="close-btn")
    
    def on_mount(self) -> None:
        """Setup table on mount."""
        table = self.query_one(DataTable)
        table.add_columns("Severity", "File", "Line", "Rule", "Message")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss()
        elif event.button.id == "scan-btn":
            self.run_scan()
        elif event.button.id == "export-btn":
            self.export_sarif()
    
    def run_scan(self) -> None:
        """Run security scan."""
        from .security import scan
        
        table = self.query_one(DataTable)
        table.clear()
        
        try:
            root = str(Path.cwd())
            issues = scan(root)
            
            if not issues:
                table.add_row("No issues", "-", "-", "-", "All clear!")
            else:
                for issue in issues:
                    table.add_row(
                        issue.get('severity', 'UNKNOWN'),
                        issue.get('file', 'unknown'),
                        str(issue.get('line', '-')),
                        issue.get('rule_id', '-'),
                        issue.get('message', '')[:50]
                    )
        except Exception as e:
            table.add_row("ERROR", "-", "-", "-", str(e))
    
    def export_sarif(self) -> None:
        """Export scan results to SARIF."""
        from .security import scan
        import json
        
        try:
            root = str(Path.cwd())
            issues = scan(root)
            
            # Simple SARIF format
            sarif = {
                "version": "2.1.0",
                "runs": [{
                    "tool": {"driver": {"name": "ollcoder-security"}},
                    "results": issues
                }]
            }
            
            output_path = Path.cwd() / "security-results.sarif"
            output_path.write_text(json.dumps(sarif, indent=2))
            
            table = self.query_one(DataTable)
            table.add_row("SUCCESS", "-", "-", "-", f"Exported to {output_path.name}")
        except Exception as e:
            table = self.query_one(DataTable)
            table.add_row("ERROR", "-", "-", "-", str(e))


class DiffViewerScreen(ModalScreen):
    """Preview code diffs before applying."""
    
    def compose(self) -> ComposeResult:
        with Container(id="diff-dialog"):
            yield Static("[bold cyan]Code Diff Preview[/bold cyan]", id="dialog-title")
            
            yield ScrollableContainer(
                TextArea("", language="diff", id="diff-content"),
                id="diff-scroll"
            )
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Apply", variant="primary", id="apply-btn")
                yield Button("Cancel", variant="default", id="cancel-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "cancel-btn":
            self.dismiss(False)
        elif event.button.id == "apply-btn":
            self.dismiss(True)


class FileEditorScreen(ModalScreen):
    """Simple file editor."""
    
    def __init__(self, filepath: str, content: str):
        super().__init__()
        self.filepath = filepath
        self.content = content
    
    def compose(self) -> ComposeResult:
        with Container(id="editor-dialog"):
            yield Static(f"[bold cyan]Editing: {self.filepath}[/bold cyan]", id="dialog-title")
            
            yield TextArea(self.content, language="python", id="editor-content")
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Save", variant="primary", id="save-btn")
                yield Button("Cancel", variant="default", id="cancel-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "cancel-btn":
            self.dismiss(None)
        elif event.button.id == "save-btn":
            editor = self.query_one("#editor-content", TextArea)
            self.dismiss(editor.text)


class SettingsScreen(ModalScreen):
    """Configure TUI settings."""
    
    def __init__(self):
        super().__init__()
        self.settings_file = Path.home() / ".config" / "ollcoder" / "tui_settings.json"
        self.settings = self.load_settings()
    
    def load_settings(self) -> dict:
        """Load settings from file."""
        if self.settings_file.exists():
            try:
                return json.loads(self.settings_file.read_text())
            except Exception:
                pass
        return {"compression": "MODERATE", "trust_level": "MEDIUM", "memory_enabled": True}
    
    def save_settings(self) -> None:
        """Save settings to file."""
        try:
            self.settings_file.parent.mkdir(parents=True, exist_ok=True)
            self.settings_file.write_text(json.dumps(self.settings, indent=2))
        except Exception:
            pass
    
    def compose(self) -> ComposeResult:
        with Container(id="settings-dialog"):
            yield Static("[bold cyan]Settings[/bold cyan]", id="dialog-title")
            
            with TabbedContent(initial="general"):
                with TabPane("General", id="general"):
                    yield Label("Compression Level:")
                    yield OptionList(
                        Option("NONE", id="NONE"),
                        Option("SEMANTIC", id="SEMANTIC"),
                        Option("MODERATE", id="MODERATE"),
                        Option("SUMMARY", id="SUMMARY"),
                        id="compression-setting"
                    )
                
                with TabPane("Trust", id="trust"):
                    yield Label("Default Trust Level:")
                    yield OptionList(
                        Option("OWNER", id="OWNER"),
                        Option("HIGH", id="HIGH"),
                        Option("MEDIUM", id="MEDIUM"),
                        Option("LOW", id="LOW"),
                        id="trust-setting"
                    )
                
                with TabPane("Memory", id="memory"):
                    yield Label("Enable Memory:")
                    yield Button("On", variant="primary", id="memory-on")
                    yield Button("Off", variant="default", id="memory-off")
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Save", variant="primary", id="save-btn")
                yield Button("Cancel", variant="default", id="cancel-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "cancel-btn":
            self.dismiss(None)
        elif event.button.id == "save-btn":
            # Save compression setting
            compression_list = self.query_one("#compression-setting", OptionList)
            if compression_list.highlighted is not None:
                selected = compression_list.get_option_at_index(compression_list.highlighted)
                self.settings["compression"] = selected.id
            
            # Save trust setting
            trust_list = self.query_one("#trust-setting", OptionList)
            if trust_list.highlighted is not None:
                selected = trust_list.get_option_at_index(trust_list.highlighted)
                self.settings["trust_level"] = selected.id
            
            # Save settings to file
            self.save_settings()
            self.dismiss(True)


class SearchScreen(ModalScreen):
    """Search and filter chat messages."""
    
    def compose(self) -> ComposeResult:
        with Container(id="search-dialog"):
            yield Static("[bold cyan]Search Chat[/bold cyan]", id="dialog-title")
            yield Input(placeholder="Search messages...", id="search-input")
            
            yield Label("Filter by:")
            yield OptionList(
                Option("All", id="all"),
                Option("User", id="user"),
                Option("Assistant", id="assistant"),
                id="filter-list"
            )
            
            yield ScrollableContainer(
                Static("Search results will appear here...", id="search-results"),
                id="results-scroll"
            )
            
            yield Button("Close", variant="primary", id="close-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss()


class TrustManagerScreen(ModalScreen):
    """Manage trusted folders and their access levels."""
    
    def compose(self) -> ComposeResult:
        with Container(id="trust-dialog"):
            yield Static("[bold cyan]Trust Manager[/bold cyan]", id="dialog-title")
            yield Static("Current working directory: " + str(Path.cwd()), id="cwd-info")
            
            yield DataTable(id="trust-table")
            
            with Horizontal():
                yield Input(placeholder="Path to add (. for current dir)...", id="path-input")
                yield OptionList(
                    Option("OWNER", id="OWNER"),
                    Option("TRUSTED", id="TRUSTED"),
                    Option("LOW", id="LOW"),
                    Option("UNTRUSTED", id="UNTRUSTED"),
                    id="trust-level"
                )
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Add", variant="primary", id="add-btn")
                yield Button("Remove", variant="error", id="remove-btn")
                yield Button("Refresh", variant="default", id="refresh-btn")
                yield Button("Close", variant="default", id="close-btn")
    
    def on_mount(self) -> None:
        """Setup table on mount."""
        from .trusted_folders import TrustLevel
        table = self.query_one(DataTable)
        table.add_columns("Path", "Trust Level", "Permissions")
        table.cursor_type = "row"
        self.load_trust_data()
    
    def load_trust_data(self) -> None:
        """Load current trust configuration."""
        from .trusted_folders import global_trust, TrustLevel
        
        table = self.query_one(DataTable)
        table.clear()
        
        trust_mgr = global_trust()
        if not trust_mgr.entries:
            table.add_row("No trusted folders configured", "-", "-")
            return
        
        for path, entry in trust_mgr.entries.items():
            policy = trust_mgr.policy_for(path)
            perms = []
            if policy.allow_read:
                perms.append("read")
            if policy.allow_write:
                perms.append("write")
            if policy.allow_execute:
                perms.append("exec")
            if policy.allow_delete:
                perms.append("delete")
            
            table.add_row(path, entry.level, ", ".join(perms))
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss()
        elif event.button.id == "add-btn":
            self.add_trust_entry()
        elif event.button.id == "remove-btn":
            self.remove_trust_entry()
        elif event.button.id == "refresh-btn":
            self.load_trust_data()
    
    def add_trust_entry(self) -> None:
        """Add new trust entry."""
        from .trusted_folders import global_trust, TrustLevel
        
        path_input = self.query_one("#path-input", Input)
        level_list = self.query_one("#trust-level", OptionList)
        
        path = path_input.value.strip()
        if not path:
            return
        
        # Resolve path
        if path == ".":
            path = str(Path.cwd())
        else:
            path = str(Path(path).resolve())
        
        # Get selected level
        selected_idx = level_list.highlighted
        if selected_idx is None:
            level = TrustLevel.OWNER
        else:
            selected = level_list.get_option_at_index(selected_idx)
            level = TrustLevel[selected.id]
        
        # Set trust level
        trust_mgr = global_trust()
        trust_mgr.set_level(path, level, persist=True)
        
        # Clear input and refresh
        path_input.value = ""
        self.load_trust_data()
    
    def remove_trust_entry(self) -> None:
        """Remove selected trust entry."""
        from .trusted_folders import global_trust
        
        table = self.query_one(DataTable)
        if table.cursor_row is None or table.cursor_row < 0:
            return
        
        # Get the path from the selected row
        row_key = table.get_row_at(table.cursor_row)
        if not row_key or len(row_key) < 1:
            return
        
        path = str(row_key[0])
        if path == "No trusted folders configured":
            return
        
        # Remove from trust manager
        trust_mgr = global_trust()
        if path in trust_mgr.entries:
            del trust_mgr.entries[path]
            trust_mgr._save()
            self.load_trust_data()


class ChecksRunnerScreen(ModalScreen):
    """Run linters and tests, display results."""
    
    def compose(self) -> ComposeResult:
        with Container(id="checks-dialog"):
            yield Static("[bold cyan]Checks Runner[/bold cyan]", id="dialog-title")
            
            with TabbedContent(initial="ruff"):
                with TabPane("Ruff", id="ruff"):
                    yield ScrollableContainer(
                        Static("Ruff results will appear here...", id="ruff-output"),
                        id="ruff-scroll"
                    )
                
                with TabPane("Mypy", id="mypy"):
                    yield ScrollableContainer(
                        Static("Mypy results will appear here...", id="mypy-output"),
                        id="mypy-scroll"
                    )
                
                with TabPane("Tests", id="tests"):
                    yield ScrollableContainer(
                        Static("Test results will appear here...", id="test-output"),
                        id="test-scroll"
                    )
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Run All", variant="primary", id="run-all-btn")
                yield Button("Run Ruff", variant="default", id="run-ruff-btn")
                yield Button("Run Mypy", variant="default", id="run-mypy-btn")
                yield Button("Run Tests", variant="default", id="run-tests-btn")
                yield Button("Close", variant="default", id="close-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss()
        elif event.button.id == "run-all-btn":
            self.run_all_checks()
        elif event.button.id == "run-ruff-btn":
            self.run_ruff()
        elif event.button.id == "run-mypy-btn":
            self.run_mypy()
        elif event.button.id == "run-tests-btn":
            self.run_tests()
    
    def run_all_checks(self) -> None:
        """Run all checks."""
        self.run_ruff()
        self.run_mypy()
        self.run_tests()
    
    def run_ruff(self) -> None:
        """Run ruff linter."""
        from .checks import ChecksConfig, run_checks
        
        output = self.query_one("#ruff-output", Static)
        output.update("[cyan]Running ruff...[/cyan]")
        
        try:
            results, exit_code = run_checks(ChecksConfig())
            ruff_results = [r for r in results if 'ruff' in ' '.join(r.cmd)]
            
            if ruff_results:
                result = ruff_results[0]
                if result.ok:
                    output.update("[green]✓ Ruff passed![/green]")
                else:
                    output.update(f"[red]✗ Ruff failed[/red]\\n\\n{result.stdout or result.stderr}")
            else:
                output.update("[yellow]Ruff not configured[/yellow]")
        except Exception as e:
            output.update(f"[red]Error:[/red] {e}")
    
    def run_mypy(self) -> None:
        """Run mypy type checker."""
        from .checks import ChecksConfig, run_checks
        
        output = self.query_one("#mypy-output", Static)
        output.update("[cyan]Running mypy...[/cyan]")
        
        try:
            results, exit_code = run_checks(ChecksConfig())
            mypy_results = [r for r in results if 'mypy' in ' '.join(r.cmd)]
            
            if mypy_results:
                result = mypy_results[0]
                if result.ok:
                    output.update("[green]✓ Mypy passed![/green]")
                else:
                    output.update(f"[red]✗ Mypy found issues[/red]\\n\\n{result.stdout or result.stderr}")
            else:
                output.update("[yellow]Mypy not configured[/yellow]")
        except Exception as e:
            output.update(f"[red]Error:[/red] {e}")
    
    def run_tests(self) -> None:
        """Run pytest."""
        from .checks import ChecksConfig, run_checks
        
        output = self.query_one("#test-output", Static)
        output.update("[cyan]Running tests...[/cyan]")
        
        try:
            results, exit_code = run_checks(ChecksConfig())
            test_results = [r for r in results if 'pytest' in ' '.join(r.cmd) or 'test' in ' '.join(r.cmd)]
            
            if test_results:
                result = test_results[0]
                if result.ok:
                    output.update("[green]✓ All tests passed![/green]")
                else:
                    output.update(f"[red]✗ Tests failed[/red]\\n\\n{result.stdout or result.stderr}")
            else:
                output.update("[yellow]Tests not configured[/yellow]")
        except Exception as e:
            output.update(f"[red]Error:[/red] {e}")


class MultiRepoScreen(ModalScreen):
    """Manage multiple repository roots."""
    
    def compose(self) -> ComposeResult:
        with Container(id="multi-dialog"):
            yield Static("[bold cyan]Multi-Repo Manager[/bold cyan]", id="dialog-title")
            
            yield Label("Active Repositories:")
            yield SelectionList(id="repo-list")
            
            with Horizontal():
                yield Input(placeholder="Path to add...", id="repo-path-input")
                yield Button("Add", variant="primary", id="add-repo-btn")
            
            yield ScrollableContainer(
                Static("Combined context will appear here...", id="multi-context"),
                id="context-scroll"
            )
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Build Context", variant="primary", id="build-btn")
                yield Button("Remove Selected", variant="error", id="remove-btn")
                yield Button("Close", variant="default", id="close-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss()
        elif event.button.id == "add-repo-btn":
            self.add_repository()
        elif event.button.id == "remove-btn":
            self.remove_repository()
        elif event.button.id == "build-btn":
            self.build_multi_context()
    
    def __init__(self):
        super().__init__()
        self.repos: list[str] = []
    
    def on_mount(self) -> None:
        """Initialize repo list."""
        # Add current directory by default
        self.repos.append(str(Path.cwd()))
        self.refresh_repo_list()
    
    def refresh_repo_list(self) -> None:
        """Refresh the repository list display."""
        from textual.widgets.selection_list import Selection
        repo_list = self.query_one("#repo-list", SelectionList)
        repo_list.clear_options()
        for repo in self.repos:
            repo_list.add_option(Selection(repo, repo, True))
    
    def add_repository(self) -> None:
        """Add repository to list."""
        path_input = self.query_one("#repo-path-input", Input)
        path = path_input.value.strip()
        
        if not path:
            return
        
        resolved = str(Path(path).resolve())
        if resolved not in self.repos:
            self.repos.append(resolved)
            self.refresh_repo_list()
        
        path_input.value = ""
    
    def remove_repository(self) -> None:
        """Remove selected repository."""
        repo_list = self.query_one("#repo-list", SelectionList)
        selected = repo_list.selected
        
        for repo in selected:
            if repo in self.repos:
                self.repos.remove(repo)
        
        self.refresh_repo_list()
    
    def build_multi_context(self) -> None:
        """Build context across all repos."""
        from .multi import build_multi_context
        
        output = self.query_one("#multi-context", Static)
        output.update("[cyan]Building multi-repo context...[/cyan]")
        
        try:
            if not self.repos:
                output.update("[yellow]No repositories added[/yellow]")
                return
            
            files = build_multi_context(self.repos, query="", provider=None)
            
            lines = [f"[bold green]✓ Built context from {len(self.repos)} repositories[/bold green]\\n"]
            lines.append(f"[dim]Total files: {len(files)}[/dim]\\n\\n")
            
            # Group by repo
            by_repo: dict[str, list[str]] = {}
            for root, path in files:
                by_repo.setdefault(root, []).append(path)
            
            for repo, paths in by_repo.items():
                lines.append(f"[cyan]{Path(repo).name}[/cyan]: {len(paths)} files")
                for path in paths[:5]:  # Show first 5
                    lines.append(f"  • {Path(path).name}")
                if len(paths) > 5:
                    lines.append(f"  [dim]... and {len(paths) - 5} more[/dim]")
                lines.append("")
            
            output.update("".join(lines))
        except Exception as e:
            output.update(f"[red]Error:[/red] {e}")


class EcoDashboardScreen(ModalScreen):
    """Carbon tracking and complexity metrics."""
    
    def compose(self) -> ComposeResult:
        with Container(id="eco-dialog"):
            yield Static("[bold cyan]Eco Dashboard[/bold cyan]", id="dialog-title")
            
            with TabbedContent(initial="carbon"):
                with TabPane("Carbon", id="carbon"):
                    yield Static("Estimated CO2: Loading...", id="carbon-stats")
                    yield ProgressBar(id="carbon-bar")
                    yield ScrollableContainer(
                        Static("Carbon details...", id="carbon-details"),
                        id="carbon-scroll"
                    )
                
                with TabPane("Complexity", id="complexity"):
                    yield DataTable(id="complexity-table")
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Analyze", variant="primary", id="analyze-btn")
                yield Button("Export", variant="default", id="export-btn")
                yield Button("Close", variant="default", id="close-btn")
    
    def on_mount(self) -> None:
        """Setup complexity table."""
        table = self.query_one("#complexity-table", DataTable)
        table.add_columns("File", "Complexity", "Maintainability", "Issues")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss()
        elif event.button.id == "analyze-btn":
            self.run_analysis()
        elif event.button.id == "export-btn":
            self.export_results()
    
    def run_analysis(self) -> None:
        """Run eco analysis."""
        from .eco import analyze, track_emissions
        
        carbon_stats = self.query_one("#carbon-stats", Static)
        carbon_details = self.query_one("#carbon-details", Static)
        complexity_table = self.query_one("#complexity-table", DataTable)
        carbon_bar = self.query_one("#carbon-bar", ProgressBar)
        
        carbon_stats.update("[cyan]Analyzing...[/cyan]")
        
        try:
            root = str(Path.cwd())
            
            # Run complexity analysis
            issues = analyze(root)
            
            # Update complexity table
            complexity_table.clear()
            if not issues:
                complexity_table.add_row("No issues", "-", "-", "-")
            else:
                for issue in issues[:20]:  # Limit to 20
                    complexity_table.add_row(
                        Path(issue.path).name,
                        str(issue.score),
                        issue.kind,
                        issue.message[:50]
                    )
            
            # Estimate carbon (simple)
            total_issues = len(issues)
            estimated_co2 = total_issues * 0.001  # Rough estimate
            
            carbon_stats.update(f"[bold]Estimated CO2:[/bold] {estimated_co2:.4f} kg")
            carbon_bar.update(total=100, progress=min(int(estimated_co2 * 10), 100))
            
            details = [f"[cyan]Analysis Complete[/cyan]\\n\\n"]
            details.append(f"Total complexity issues: {total_issues}\\n")
            details.append(f"High complexity functions: {sum(1 for i in issues if i.kind == 'complexity')}\\n")
            details.append(f"Energy-intensive patterns: {sum(1 for i in issues if i.kind == 'loops')}\\n")
            carbon_details.update("".join(details))
            
        except Exception as e:
            carbon_stats.update(f"[red]Error:[/red] {e}")
    
    def export_results(self) -> None:
        """Export analysis results."""
        from .eco import analyze
        import json
        
        try:
            root = str(Path.cwd())
            issues = analyze(root)
            
            export_data = {
                "timestamp": str(Path.cwd()),
                "total_issues": len(issues),
                "issues": [{"path": i.path, "line": i.line, "kind": i.kind, "message": i.message, "score": i.score} for i in issues]
            }
            
            output_path = Path.cwd() / "eco-analysis.json"
            output_path.write_text(json.dumps(export_data, indent=2))
            
            carbon_stats = self.query_one("#carbon-stats", Static)
            carbon_stats.update(f"[green]✓ Exported to {output_path.name}[/green]")
        except Exception as e:
            carbon_stats = self.query_one("#carbon-stats", Static)
            carbon_stats.update(f"[red]Error:[/red] {e}")


class EthicsScannerScreen(ModalScreen):
    """Bias and ethics detection."""
    
    def compose(self) -> ComposeResult:
        with Container(id="ethics-dialog"):
            yield Static("[bold cyan]Ethics Scanner[/bold cyan]", id="dialog-title")
            
            yield DataTable(id="ethics-table")
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Scan", variant="primary", id="scan-btn")
                yield Button("Close", variant="default", id="close-btn")
    
    def on_mount(self) -> None:
        """Setup table."""
        table = self.query_one(DataTable)
        table.add_columns("File", "Line", "Category", "Term", "Suggestion")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss()
        elif event.button.id == "scan-btn":
            self.run_scan()
    
    def run_scan(self) -> None:
        """Run ethics scan."""
        from .ethics import scan
        
        table = self.query_one(DataTable)
        table.clear()
        
        try:
            root = str(Path.cwd())
            issues = scan(root)
            
            if not issues:
                table.add_row("No issues found", "-", "-", "-", "All clear!")
            else:
                for issue in issues[:50]:  # Limit display
                    table.add_row(
                        Path(issue.path).name,
                        str(issue.line),
                        issue.kind,
                        issue.message.split("'")[1] if "'" in issue.message else "-",
                        "Review terminology"
                    )
        except Exception as e:
            table.add_row("ERROR", "-", "-", "-", str(e))


class BlockchainViewerScreen(ModalScreen):
    """View and verify code signatures."""
    
    def compose(self) -> ComposeResult:
        with Container(id="blockchain-dialog"):
            yield Static("[bold cyan]Blockchain Viewer[/bold cyan]", id="dialog-title")
            
            with TabbedContent(initial="manifest"):
                with TabPane("Manifest", id="manifest"):
                    yield ScrollableContainer(
                        Static("Manifest will appear here...", id="manifest-content"),
                        id="manifest-scroll"
                    )
                
                with TabPane("Signature", id="signature"):
                    yield ScrollableContainer(
                        Static("Signature details...", id="signature-content"),
                        id="signature-scroll"
                    )
                
                with TabPane("Verify", id="verify"):
                    yield Input(placeholder="Public key path...", id="pubkey-input")
                    yield Input(placeholder="Signature path...", id="sig-input")
                    yield Static("Verification result will appear here...", id="verify-result")
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Build Manifest", variant="primary", id="manifest-btn")
                yield Button("Sign", variant="default", id="sign-btn")
                yield Button("Verify", variant="default", id="verify-btn")
                yield Button("Close", variant="default", id="close-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss()
        elif event.button.id == "manifest-btn":
            self.build_manifest()
        elif event.button.id == "sign-btn":
            self.sign_manifest()
        elif event.button.id == "verify-btn":
            self.verify_signature()
    
    def __init__(self):
        super().__init__()
        self.manifest_entries = []
    
    def build_manifest(self) -> None:
        """Build code manifest."""
        from .blockchain import build_manifest
        
        manifest_content = self.query_one("#manifest-content", Static)
        manifest_content.update("[cyan]Building manifest...[/cyan]")
        
        try:
            root = str(Path.cwd())
            self.manifest_entries = build_manifest(root, patterns=["**/*.py", "**/*.ts", "**/*.js"])
            
            lines = [f"[bold green]✓ Built manifest with {len(self.manifest_entries)} files[/bold green]\\n\\n"]
            for entry in self.manifest_entries[:20]:  # Show first 20
                lines.append(f"[cyan]{Path(entry.path).name}[/cyan]")
                lines.append(f"  SHA256: [dim]{entry.sha256[:16]}...[/dim]\\n")
            
            if len(self.manifest_entries) > 20:
                lines.append(f"\\n[dim]... and {len(self.manifest_entries) - 20} more files[/dim]")
            
            manifest_content.update("".join(lines))
        except Exception as e:
            manifest_content.update(f"[red]Error:[/red] {e}")
    
    def sign_manifest(self) -> None:
        """Sign manifest."""
        from .blockchain import sign_manifest, save_signature
        
        sig_content = self.query_one("#signature-content", Static)
        
        if not self.manifest_entries:
            sig_content.update("[yellow]Build manifest first[/yellow]")
            return
        
        sig_content.update("[cyan]Signing manifest...[/cyan]")
        
        try:
            # Check for private key
            key_path = Path.home() / ".ollcoder" / "private.pem"
            if not key_path.exists():
                sig_content.update(
                    f"[yellow]No private key found at {key_path}[/yellow]\\n\\n"
                    f"Generate one with: oc blockchain generate-keypair"
                )
                return
            
            signature = sign_manifest(self.manifest_entries, str(key_path), passphrase=None)
            
            # Save signature
            sig_path = Path.cwd() / "code.sig"
            save_signature(signature, str(sig_path))
            
            sig_content.update(
                f"[green]✓ Signed manifest[/green]\\n\\n"
                f"Signature: [dim]{signature.hex()[:32]}...[/dim]\\n"
                f"Saved to: {sig_path.name}"
            )
        except Exception as e:
            sig_content.update(f"[red]Error:[/red] {e}")
    
    def verify_signature(self) -> None:
        """Verify signature."""
        from .blockchain import verify_manifest, read_signature
        
        pubkey_input = self.query_one("#pubkey-input", Input)
        sig_input = self.query_one("#sig-input", Input)
        verify_result = self.query_one("#verify-result", Static)
        
        pubkey_path = pubkey_input.value.strip() or str(Path.home() / ".ollcoder" / "public.pem")
        sig_path = sig_input.value.strip() or str(Path.cwd() / "code.sig")
        
        if not self.manifest_entries:
            verify_result.update("[yellow]Build manifest first[/yellow]")
            return
        
        verify_result.update("[cyan]Verifying signature...[/cyan]")
        
        try:
            if not Path(pubkey_path).exists():
                verify_result.update(f"[red]Public key not found:[/red] {pubkey_path}")
                return
            
            if not Path(sig_path).exists():
                verify_result.update(f"[red]Signature file not found:[/red] {sig_path}")
                return
            
            signature = read_signature(sig_path)
            valid = verify_manifest(self.manifest_entries, signature, pubkey_path)
            
            if valid:
                verify_result.update("[bold green]✓ SIGNATURE VALID[/bold green]\\n\\nThe code has not been tampered with.")
            else:
                verify_result.update("[bold red]✗ SIGNATURE INVALID[/bold red]\\n\\nThe code may have been modified.")
        except Exception as e:
            verify_result.update(f"[red]Error:[/red] {e}")


class WebFetchScreen(ModalScreen):
    """Fetch and display web content."""
    
    def compose(self) -> ComposeResult:
        with Container(id="web-dialog"):
            yield Static("[bold cyan]Web Fetch[/bold cyan]", id="dialog-title")
            
            with Horizontal():
                yield Input(placeholder="Enter URL...", id="url-input")
                yield Button("Fetch", variant="primary", id="fetch-btn")
            
            yield ScrollableContainer(
                Markdown("", id="web-content"),
                id="web-scroll"
            )
            
            yield Button("Close", variant="default", id="close-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss()
        elif event.button.id == "fetch-btn":
            self.fetch_url()
    
    def fetch_url(self) -> None:
        """Fetch URL content."""
        from .web_fetch import fetch_url
        
        url_input = self.query_one("#url-input", Input)
        url = url_input.value.strip()
        
        if not url:
            return
        
        content_widget = self.query_one("#web-content", Markdown)
        content_widget.update(f"[cyan]Fetching {url}...[/cyan]")
        
        try:
            content = fetch_url(url)
            if content:
                # Limit content size for display
                if len(content) > 10000:
                    content = content[:10000] + "\\n\\n[dim]... (truncated)[/dim]"
                content_widget.update(content)
            else:
                content_widget.update("[yellow]No content retrieved[/yellow]")
        except Exception as e:
            content_widget.update(f"[red]Error:[/red] {e}")


# ==================== Session Management ====================

class SessionManager:
    """Manage chat sessions."""
    
    def __init__(self, root: str):
        self.root = Path(root)
        self.sessions_dir = Path.home() / ".ollcoder" / "sessions"
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.current_session: Optional[str] = None
    
    def list_sessions(self) -> list[tuple[str, float]]:
        """List all sessions with timestamps."""
        sessions = []
        for f in self.sessions_dir.glob("*.json"):
            try:
                data = json.loads(f.read_text())
                sessions.append((f.stem, data.get("timestamp", 0)))
            except Exception:
                pass
        return sorted(sessions, key=lambda x: x[1], reverse=True)
    
    def save_session(self, session_id: str, messages: list[dict], metadata: dict) -> None:
        """Save session to disk."""
        filepath = self.sessions_dir / f"{session_id}.json"
        data = {
            "session_id": session_id,
            "timestamp": metadata.get("timestamp", 0),
            "root": str(self.root),
            "messages": messages,
            "metadata": metadata
        }
        filepath.write_text(json.dumps(data, indent=2))
    
    def load_session(self, session_id: str) -> Optional[dict]:
        """Load session from disk."""
        filepath = self.sessions_dir / f"{session_id}.json"
        if not filepath.exists():
            return None
        try:
            return json.loads(filepath.read_text())
        except Exception:
            return None


# ==================== Enhanced Chat Panel ====================

class EnhancedChatPanel(ScrollableContainer):
    """Enhanced chat panel with search and filtering."""
    
    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.messages: list[tuple[str, str]] = []
        self.filter_role: Optional[str] = None
        self.search_query: str = ""
    
    def add_message(self, role: str, content: str, stream: bool = False) -> None:
        """Add a message to chat."""
        self.messages.append((role, content))
        
        # Apply filters
        if self.filter_role and role != self.filter_role:
            return
        if self.search_query and self.search_query.lower() not in content.lower():
            return
        
        role_style = "bold cyan" if role == "assistant" else "bold green"
        role_label = "🤖 Assistant" if role == "assistant" else "👤 You"
        
        msg_text = f"[{role_style}]{role_label}[/{role_style}]\n{content}\n"
        msg = Static(msg_text)
        self.mount(msg)
        msg.scroll_visible()
    
    def filter_messages(self, role: Optional[str] = None, query: str = "") -> None:
        """Filter displayed messages."""
        self.filter_role = role
        self.search_query = query
        self.remove_children()
        
        for msg_role, content in self.messages:
            if role and msg_role != role:
                continue
            if query and query.lower() not in content.lower():
                continue
            self.add_message(msg_role, content)


class SessionSelectorScreen(ModalScreen):
    """Select or create sessions."""
    
    def __init__(self, session_manager: SessionManager):
        super().__init__()
        self.session_manager = session_manager
    
    def compose(self) -> ComposeResult:
        with Container(id="session-dialog"):
            yield Static("[bold cyan]Session Manager[/bold cyan]", id="dialog-title")
            
            sessions = self.session_manager.list_sessions()
            options = [Option(f"{sid} ({self._format_time(ts)})", id=sid) 
                      for sid, ts in sessions]
            
            if not options:
                options = [Option("No saved sessions", id="", disabled=True)]
            
            yield OptionList(*options, id="session-list")
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Load", variant="primary", id="load-btn")
                yield Button("New", variant="default", id="new-btn")
                yield Button("Delete", variant="error", id="delete-btn")
                yield Button("Cancel", variant="default", id="cancel-btn")
    
    def _format_time(self, timestamp: float) -> str:
        """Format timestamp."""
        import datetime
        dt = datetime.datetime.fromtimestamp(timestamp)
        return dt.strftime("%Y-%m-%d %H:%M")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "cancel-btn":
            self.dismiss(None)
        elif event.button.id == "load-btn":
            option_list = self.query_one("#session-list", OptionList)
            if option_list.highlighted is not None:
                selected = option_list.get_option_at_index(option_list.highlighted)
                if selected.id:
                    self.dismiss({"action": "load", "session_id": selected.id})
        elif event.button.id == "new-btn":
            self.dismiss({"action": "new"})
        elif event.button.id == "delete-btn":
            option_list = self.query_one("#session-list", OptionList)
            if option_list.highlighted is not None:
                selected = option_list.get_option_at_index(option_list.highlighted)
                if selected.id:
                    # Delete session file
                    session_file = self.session_manager.sessions_dir / f"{selected.id}.json"
                    try:
                        if session_file.exists():
                            session_file.unlink()
                            # Refresh the list
                            sessions = self.session_manager.list_sessions()
                            option_list.clear_options()
                            if sessions:
                                for sid, ts in sessions:
                                    option_list.add_option(Option(f"{sid} ({self._format_time(ts)})", id=sid))
                            else:
                                option_list.add_option(Option("No saved sessions", id="", disabled=True))
                    except Exception:
                        pass


# ==================== Main Advanced TUI ====================

class OllcoderAdvancedTUI(App):
    """Advanced Ollcoder TUI with all features."""
    
    CSS = """
    /* Inherit base styles and add advanced features */
    Screen {
        background: #000000;
    }
    
    Header {
        background: #0a0a0a;
        color: #00ff88;
    }
    
    Footer {
        background: #0a0a0a;
        color: #00ff88;
    }
    
    #sidebar {
        width: 30;
        background: #0a0a0a;
        border-right: solid #00ff88;
    }
    
    #chat-container {
        width: 1fr;
        background: #000000;
    }
    
    TabbedContent {
        height: 1fr;
    }
    
    EnhancedChatPanel {
        background: #000000;
        padding: 1;
    }
    
    #input-container {
        height: 3;
        background: #0a0a0a;
        padding: 0 1;
    }
    
    Input {
        background: #0a0a0a;
        color: #00ff88;
        border: solid #00ff88;
    }
    
    DirectoryTree {
        padding: 1;
        background: #0a0a0a;
        color: #888888;
    }
    
    Static {
        color: #cccccc;
    }
    
    /* Advanced feature dialogs */
    ModalScreen {
        align: center middle;
    }
    
    #context-dialog, #memory-dialog, #agent-dialog, 
    #security-dialog, #diff-dialog, #editor-dialog,
    #settings-dialog, #search-dialog, #session-dialog {
        width: 80;
        height: 40;
        background: #0a0a0a;
        border: solid #00ff88;
        padding: 2;
    }
    
    DataTable {
        height: 1fr;
        background: #000000;
    }
    
    TextArea {
        height: 1fr;
        background: #000000;
        border: solid #00ff88;
    }
    
    ProgressBar {
        background: #0a0a0a;
    }
    """
    
    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit", priority=True),
        Binding("ctrl+q", "quit", "Quit"),
        Binding("ctrl+l", "clear_chat", "Clear"),
        Binding("ctrl+m", "change_model", "Model"),
        Binding("ctrl+n", "new_file", "New File"),
        Binding("ctrl+p", "command_palette", "Commands"),
        Binding("ctrl+e", "export_chat", "Export"),
        # Advanced features - Core
        Binding("ctrl+b", "context_builder", "Context"),
        Binding("ctrl+r", "run_agent", "Agent"),
        Binding("ctrl+k", "security_scan", "Security"),
        Binding("ctrl+t", "trust_manager", "Trust"),
        Binding("ctrl+w", "web_fetch", "Web"),
        # Advanced features - Shift variants
        Binding("ctrl+shift+m", "view_memory", "Memory"),
        Binding("ctrl+shift+s", "manage_sessions", "Sessions"),
        Binding("ctrl+shift+f", "search_chat", "Search"),
        Binding("ctrl+shift+e", "edit_file", "Edit"),
        Binding("ctrl+shift+c", "checks_runner", "Checks"),
        Binding("ctrl+shift+r", "multi_repo", "Multi-Repo"),
        Binding("ctrl+shift+o", "eco_dashboard", "Eco"),
        Binding("ctrl+shift+t", "ethics_scan", "Ethics"),
        Binding("ctrl+shift+b", "blockchain_view", "Blockchain"),
        # Settings
        Binding("ctrl+comma", "settings", "Settings"),
    ]
    
    def __init__(self, root: str, provider: Any, model: str, provider_name: str = "ollama"):
        super().__init__()
        self.root = root
        self.provider = provider
        self.model = model
        self.provider_name = provider_name
        self.session_manager = SessionManager(root)
        self.messages: list[dict[str, str]] = [
            {"role": "system", "content": (
                "You are a helpful coding assistant with access to the codebase.\n"
                "Be conversational and concise. Provide context when helpful."
            )},
        ]
        self.streaming_enabled = True
    
    def compose(self) -> ComposeResult:
        """Create child widgets."""
        yield Header()
        
        with Horizontal():
            with Vertical(id="sidebar"):
                yield Static(
                    f"[bold cyan]🤖 Ollcoder Advanced[/bold cyan]\n"
                    f"Provider: {self.provider_name}\n"
                    f"Model: {self.model}\n"
                    f"Project: {Path(self.root).name}",
                    id="info-panel"
                )
                yield DirectoryTree(self.root)
            
            with Vertical(id="chat-container"):
                with TabbedContent(initial="chat-1"):
                    with TabPane("Chat 1", id="chat-1"):
                        yield EnhancedChatPanel(id="chat-panel-1")
                    with TabPane("Chat 2", id="chat-2"):
                        yield EnhancedChatPanel(id="chat-panel-2")
                with Container(id="input-container"):
                    yield Input(placeholder="Type your message... (Ctrl+B: Context, Ctrl+R: Agent)", id="chat-input")
        
        yield Footer()
    
    def on_mount(self) -> None:
        """Handle app mount."""
        chat_panel = self.query_one("#chat-panel-1", EnhancedChatPanel)
        chat_panel.add_message(
            "assistant",
            "👋 Welcome to Ollcoder Advanced!\n\n"
            "**Quick Actions:**\n"
            "• Ctrl+B - Build Context\n"
            "• Ctrl+R - Run Agent\n"
            "• Ctrl+K - Security Scan\n"
            "• Ctrl+Shift+M - View Memory\n"
            "• Ctrl+Comma - Settings"
        )
        self.query_one("#chat-input", Input).focus()
    
    def _get_active_chat_panel(self) -> EnhancedChatPanel:
        """Get currently active chat panel."""
        tabbed = self.query_one(TabbedContent)
        active_tab = tabbed.active
        if active_tab == "chat-1":
            return self.query_one("#chat-panel-1", EnhancedChatPanel)
        else:
            return self.query_one("#chat-panel-2", EnhancedChatPanel)
    
    # File interactions
    def on_directory_tree_file_selected(self, event: DirectoryTree.FileSelected) -> None:
        try:
            filepath = event.path
            content = filepath.read_text(encoding='utf-8', errors='ignore')[:5000]
            chat_panel = self._get_active_chat_panel()
            chat_panel.add_message(
                "assistant",
                f"**File: {filepath.name}**\n\n```\n{content}\n```\n\nWhat would you like to do with this file?"
            )
        except Exception as e:
            chat_panel = self._get_active_chat_panel()
            chat_panel.add_message("assistant", f"❌ Error reading file: {e}")
    
    # Handle chat input
    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id != "chat-input":
            return
        user_input = event.value.strip()
        if not user_input:
            return
        event.input.value = ""
        chat_panel = self._get_active_chat_panel()
        chat_panel.add_message("you", user_input)
        self.messages.append({"role": "user", "content": user_input})
        # For reliability, use non-streaming by default here
        try:
            thinking = Static("[dim]🤖 Thinking...[/dim]")
            chat_panel.mount(thinking)
            response = self.provider.chat(self.messages, stream=False)
            response_text = self._extract_response_text(response)
            thinking.remove()
            chat_panel.add_message("assistant", response_text)
            self.messages.append({"role": "assistant", "content": response_text})
        except Exception as e:
            try:
                thinking.remove()
            except Exception:
                pass
            chat_panel.add_message("assistant", f"❌ Error: {e}")
    
    def _extract_response_text(self, resp: Any) -> str:
        if resp is None:
            return ""
        if hasattr(resp, "message"):
            msg = getattr(resp, "message")
            if msg and hasattr(msg, "content"):
                content = getattr(msg, "content")
                if isinstance(content, str) and content.strip():
                    return content
        txt = getattr(resp, "text", None)
        if isinstance(txt, str) and txt.strip():
            return txt
        if isinstance(resp, dict):
            msg = resp.get("message")
            if isinstance(msg, dict):
                c = msg.get("content")
                if isinstance(c, str) and c.strip():
                    return c
            c = resp.get("content")
            if isinstance(c, str) and c.strip():
                return c
        return ""
    
    # ==================== Actions ====================
    
    def action_context_builder(self) -> None:
        """Open context builder."""
        async def show_builder():
            await self.push_screen_wait(ContextBuilderScreen())
        self.run_worker(show_builder())
    
    def action_view_memory(self) -> None:
        """Open memory viewer."""
        async def show_memory():
            await self.push_screen_wait(MemoryViewerScreen())
        self.run_worker(show_memory())
    
    def action_run_agent(self) -> None:
        """Open agent runner."""
        async def show_agent():
            await self.push_screen_wait(AgentRunnerScreen(self.root, self.provider, apply_changes=False))
        self.run_worker(show_agent())
    
    def action_security_scan(self) -> None:
        """Open security scanner."""
        async def show_scanner():
            await self.push_screen_wait(SecurityScannerScreen())
        self.run_worker(show_scanner())
    
    def action_manage_sessions(self) -> None:
        """Open session manager."""
        async def show_sessions():
            result = await self.push_screen_wait(SessionSelectorScreen(self.session_manager))
            if result:
                if result["action"] == "load":
                    self.load_session(result["session_id"])
                elif result["action"] == "new":
                    self.new_session()
        self.run_worker(show_sessions())
    
    def action_search_chat(self) -> None:
        """Open chat search."""
        async def show_search():
            await self.push_screen_wait(SearchScreen())
        self.run_worker(show_search())
    
    def action_edit_file(self) -> None:
        """Open file editor for the currently selected file in the DirectoryTree, if any."""
        try:
            tree = self.query_one(DirectoryTree)
            node = getattr(tree, "cursor_node", None)
            path_obj = getattr(node, "data", None).path if node and getattr(node, "data", None) else None
            if not path_obj or not Path(path_obj).is_file():
                chat_panel = self._get_active_chat_panel()
                chat_panel.add_message("assistant", "❌ No file selected in the tree.")
                return
            content = Path(path_obj).read_text(encoding="utf-8", errors="ignore")
            async def show_editor():
                result = await self.push_screen_wait(FileEditorScreen(str(path_obj), content))
                if isinstance(result, str):
                    Path(path_obj).write_text(result)
                    chat_panel = self._get_active_chat_panel()
                    chat_panel.add_message("assistant", f"✅ Saved changes to {Path(path_obj).name}")
            self.run_worker(show_editor())
        except Exception as e:
            chat_panel = self._get_active_chat_panel()
            chat_panel.add_message("assistant", f"❌ Error opening editor: {e}")
    
    def action_settings(self) -> None:
        """Open settings."""
        async def show_settings():
            await self.push_screen_wait(SettingsScreen())
        self.run_worker(show_settings())
    
    def action_trust_manager(self) -> None:
        """Open trust manager."""
        async def show_trust():
            await self.push_screen_wait(TrustManagerScreen())
        self.run_worker(show_trust())
    
    def action_checks_runner(self) -> None:
        """Open checks runner."""
        async def show_checks():
            await self.push_screen_wait(ChecksRunnerScreen())
        self.run_worker(show_checks())
    
    def action_multi_repo(self) -> None:
        """Open multi-repo manager."""
        async def show_multi():
            await self.push_screen_wait(MultiRepoScreen())
        self.run_worker(show_multi())
    
    def action_eco_dashboard(self) -> None:
        """Open eco dashboard."""
        async def show_eco():
            await self.push_screen_wait(EcoDashboardScreen())
        self.run_worker(show_eco())
    
    def action_ethics_scan(self) -> None:
        """Open ethics scanner."""
        async def show_ethics():
            await self.push_screen_wait(EthicsScannerScreen())
        self.run_worker(show_ethics())
    
    def action_blockchain_view(self) -> None:
        """Open blockchain viewer."""
        async def show_blockchain():
            await self.push_screen_wait(BlockchainViewerScreen())
        self.run_worker(show_blockchain())
    
    def action_web_fetch(self) -> None:
        """Open web fetch panel."""
        async def show_web():
            await self.push_screen_wait(WebFetchScreen())
        self.run_worker(show_web())
    
    def action_clear_chat(self) -> None:
        """Clear current chat."""
        chat_panel = self._get_active_chat_panel()
        chat_panel.remove_children()
        chat_panel.messages.clear()
        self.messages = self.messages[:1]
        chat_panel.add_message("assistant", "Chat cleared!")
    
    def action_change_model(self) -> None:
        """Change AI model/provider using the selector from basic TUI."""
        from .tui import ModelSelectorScreen  # reuse existing selector
        async def show_model_selector():
            result = await self.push_screen_wait(ModelSelectorScreen(self.provider_name, self.model))
            if result:
                from .providers.factory import create_provider
                new_provider_name = result.get("provider", self.provider_name)
                new_model = result.get("model", self.model)
                try:
                    # Load API key if needed
                    api_key = None
                    if new_provider_name == "gemini":
                        from .secrets import get_gemini_api_key
                        api_key = get_gemini_api_key(optional=True)
                    elif new_provider_name == "openai":
                        from .secrets import get_openai_api_key
                        api_key = get_openai_api_key(optional=True)
                    elif new_provider_name == "anthropic":
                        from .secrets import get_anthropic_api_key
                        api_key = get_anthropic_api_key(optional=True)
                    
                    self.provider = create_provider(new_provider_name, new_model, api_key)
                    self.provider_name = new_provider_name
                    self.model = new_model
                    # Update info panel
                    info_panel = self.query_one("#info-panel", Static)
                    info_panel.update(
                        f"[bold cyan]🤖 Ollcoder Advanced[/bold cyan]\\n"
                        f"Provider: {self.provider_name}\\n"
                        f"Model: {self.model}\\n"
                        f"Project: {Path(self.root).name}"
                    )
                    chat_panel = self._get_active_chat_panel()
                    chat_panel.add_message("assistant", f"✅ Switched to {new_provider_name}/{new_model}")
                except Exception as e:
                    chat_panel = self._get_active_chat_panel()
                    chat_panel.add_message("assistant", f"❌ Failed to switch provider: {e}")
        self.run_worker(show_model_selector())
    
    def action_new_file(self) -> None:
        """Create a new file in the project root."""
        from .tui import CreateFileScreen
        async def show_create_dialog():
            result = await self.push_screen_wait(CreateFileScreen())
            if result:
                try:
                    filepath = Path(self.root) / result["filename"]
                    filepath.write_text(result.get("content") or "")
                    chat_panel = self._get_active_chat_panel()
                    chat_panel.add_message("assistant", f"✅ Created file: {result['filename']}")
                    # Refresh directory tree
                    tree = self.query_one(DirectoryTree)
                    tree.reload()
                except Exception as e:
                    chat_panel = self._get_active_chat_panel()
                    chat_panel.add_message("assistant", f"❌ Error creating file: {e}")
        self.run_worker(show_create_dialog())
    
    def action_export_chat(self) -> None:
        """Export current chat to a markdown file in the project root."""
        try:
            from datetime import datetime
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"chat_export_{timestamp}.md"
            filepath = Path(self.root) / filename
            chat_panel = self._get_active_chat_panel()
            content = f"# Ollcoder Chat Export\\n\\nProvider: {self.provider_name}\\nModel: {self.model}\\nDate: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\\n\\n---\\n\\n"
            for role, text in chat_panel.messages:
                role_name = "Assistant" if role == "assistant" else "You"
                content += f"## {role_name}\\n\\n{text}\\n\\n"
            filepath.write_text(content)
            chat_panel.add_message("assistant", f"✅ Chat exported to: {filename}")
        except Exception as e:
            chat_panel = self._get_active_chat_panel()
            chat_panel.add_message("assistant", f"❌ Error exporting: {e}")
    
    def action_command_palette(self) -> None:
        """Show command palette and execute selected action."""
        from .tui import CommandPaletteScreen
        async def show_palette():
            result = await self.push_screen_wait(CommandPaletteScreen())
            if result:
                command_map = {
                    "change_model": self.action_change_model,
                    "new_file": self.action_new_file,
                    "export_chat": self.action_export_chat,
                    "clear_chat": self.action_clear_chat,
                    "mcp_servers": self.action_view_memory,  # reuse to show something useful
                    "quit": self.action_quit,
                }
                if result in command_map:
                    command_map[result]()
        self.run_worker(show_palette())
    
    # ==================== Session Management ====================
    
    def load_session(self, session_id: str) -> None:
        """Load a saved session."""
        data = self.session_manager.load_session(session_id)
        if data:
            self.messages = data.get("messages", [])
            chat_panel = self._get_active_chat_panel()
            chat_panel.remove_children()
            chat_panel.messages.clear()
            for msg in self.messages[1:]:  # Skip system message
                chat_panel.add_message(msg["role"], msg["content"])
    
    def new_session(self) -> None:
        """Start a new session."""
        import time
        session_id = f"session_{int(time.time())}"
        self.session_manager.current_session = session_id
        self.action_clear_chat()
    
    def save_current_session(self) -> None:
        """Save current session."""
        import time
        if not self.session_manager.current_session:
            self.session_manager.current_session = f"session_{int(time.time())}"
        
        metadata = {
            "timestamp": time.time(),
            "model": self.model,
            "message_count": len(self.messages)
        }
        self.session_manager.save_session(
            self.session_manager.current_session,
            self.messages,
            metadata
        )


def run_advanced_tui(root: str, provider: Any, model: str, provider_name: str = "ollama") -> int:
    """Run the advanced TUI."""
    if not TEXTUAL_AVAILABLE:
        print("Error: Textual not installed. Run: pip install 'ollcoder[ui]'")
        return 1
    
    app = OllcoderAdvancedTUI(root, provider, model, provider_name)
    app.run()
    return 0
