# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.8] - 2025-10-28
### Changed
- Version bump for PyPI release

## [0.1.7] - 2025-10-28

### Enhanced
- **Improved dependency data structure**: Both dependencies and dependents now include both component type and dependency type for richer analysis
- **Fixed type assignment bug**: Dependents now correctly show the component type instead of dependency type
- **Enhanced relationship information**: Added `dependencyType` field alongside `type` field for complete relationship context

## [0.1.6] - 2024-10-27

### Added
- Job flow analysis tools for scheduled task execution sequences
- Critical path analysis for job dependencies
- Job impact boundary analysis (forward and backward dependencies)
- Enhanced sample prompts for job execution flow analysis

## [0.1.6] - 2024-09-02

### Added
- Initial release of ATX Mainframe Dependency Manager MCP
- Core dependency management functionality
- Component relationship tracking
- Source code analysis tools
- MCP server implementation

## [0.1.0] - 2024-09-01

### Added
- Initial project structure
- Basic dependency management features
- MCP server integration
- Component analysis tools
