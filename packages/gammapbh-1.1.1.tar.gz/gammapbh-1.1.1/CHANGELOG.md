v1.0.0 - 08/25/2025

 	- First public release as an executable.

v1.1.0 - 10/28/2025

 	- Released as a Python Package on PyPi

 	- Added the ability to enter custom PDF equations.

v1.1.1 - 10/29/2025

&nbsp;	-Fixed issues regarding faulty data upload.

