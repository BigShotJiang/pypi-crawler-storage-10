from casageo.client import AuthenticatedClient
from casageo.client.api.v1 import v1_accountinfo_retrieve

from casageo._util import load_json
from casageo.consts import SERVER


def account_info(key: str) -> dict:
    """Returns a dictionary containing account information.

    - "credits": Remaining credits (int).
    - "app_identifier": Application identifier (str).
    - "expires": Expiry date (str).
    - "expires_unix": Expiry date timestamp (float).
    - "key": License key (str).
    - "user": Username (str).
    """
    return load_json(
        v1_accountinfo_retrieve.sync_detailed(
            client=AuthenticatedClient(base_url=SERVER, token=key, prefix="")
        )
    )
