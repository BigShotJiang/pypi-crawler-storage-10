TABLE_ORDER = [
    "id",
    "subid",
    "inputStr",
    "label",
    "street",
    "houseNumber",
    "postalCode",
    "city",
    "county",
    "state",
    "countryName",
    "access_lat",
    "access_lng",
    "pos_lat",
    "pos_lng",
    "resultType",
    "houseNumberType",
    "countryCode",
    "stateCode",
    "countyCode",
    "scoreQuery",
    "score_country",
    "score_city",
    "score_houseNumber",
    "score_postalCode",
    "score_streets",
]

ALLOWED_COLUMNS = {
    "id",
    "street",
    "housenumber",
    "postalcode",
    "city",
    "ctrycode",
    "address_string",
    "_",
}

GEOCODE_COST = 3

SERVER = "https://cg-license.casageo.eu/"
# SERVER = "https://cgl-server02.de/"
