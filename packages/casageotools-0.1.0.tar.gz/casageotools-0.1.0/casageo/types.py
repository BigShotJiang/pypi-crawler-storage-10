class CasaGeoError(Exception):
    pass
