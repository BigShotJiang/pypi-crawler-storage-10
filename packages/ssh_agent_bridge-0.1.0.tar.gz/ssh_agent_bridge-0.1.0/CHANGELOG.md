# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- **Phase 3 Session 3:** Robust marker-based command completion detection system
  - Distinctive marker format `______END_MARKER_{uuid}______` to avoid parsing conflicts
  - Regex-based exit code extraction from `marker=exit_code` pattern
  - Handles command echoing in PTY sessions correctly
- **Phase 3 Session 3:** Example scripts demonstrating all core features:
  - `simple_command.py` - Single command execution (ephemeral)
  - `persistent_session.py` - Multi-command persistent sessions
  - `multi_agent_multi_session.py` - Concurrent multi-agent execution with connection pooling
  - `interactive_prompt.py` - Interactive command handling
  - `error_recovery.py` - Error recovery and resilience patterns
  - `signal_handling.py` - Process signal sending (SIGINT, SIGTERM, etc.)
  - `buffer_benchmark.py` - Performance benchmarking
- **Phase 3 Session 3:** Cross-platform compatibility improvements
  - Windows-aware file permission checks for SSH keys
  - Proper command construction for PTY shell sessions
  - Robust data encoding/decoding for both bytes and string returns

### Changed
- **Phase 3 Session 3:** Fixed marker parsing to use regex pattern matching instead of line-based splitting
- **Phase 3 Session 3:** Updated marker format from `MARKER_uuid` to `______END_MARKER_uuid______`
- **Phase 3 Session 3:** Changed command echo format from `echo marker $?` to `echo marker="$?"`
- **Phase 3 Session 3:** Fixed send_signal method to work with asyncssh process objects (removed await)
- **Phase 3 Session 3:** Updated all 22 marker-related tests to use new marker format
- **Phase 3 Session 3:** Improved buffer management with better data type handling

### Deprecated
- N/A

### Removed
- N/A

### Fixed
- **Phase 3 Session 3:** Fixed `$?` parsing error in PTY sessions caused by command echoing
- **Phase 3 Session 3:** Fixed marker detection to handle incomplete commands during buffer accumulation
- **Phase 3 Session 3:** Fixed send_signal attempting to await non-coroutine function
- **Phase 3 Session 3:** Fixed Windows compatibility for SSH key permission checks
- **Phase 3 Session 3:** Fixed test cases to work with new marker format

### Security
- N/A

## Phase 3 Status

**Session 3 Complete (2025-10-26):**
- ✅ All examples working successfully with IP 192.168.1.105
- ✅ 7/7 example scripts tested and passing
- ✅ Robust marker-based completion detection implemented
- ✅ All 55 unit tests passing
- ✅ Cross-platform compatibility verified
- 🎯 Next: Documentation updates, commit to main, prepare for release

## [0.1.0] - 2025-10-25

### Added
- Project initialized with basic package structure
- Core module stubs for future implementation
- Type definitions and exception classes
- Build system configuration
- Development environment setup

### Changed
- N/A

### Deprecated
- N/A

### Removed
- N/A

### Fixed
- N/A

### Security
- N/A