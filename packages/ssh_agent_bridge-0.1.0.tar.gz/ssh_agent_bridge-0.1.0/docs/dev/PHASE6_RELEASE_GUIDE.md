# Phase 6: Packaging & Release Guide

**Status:** In Progress (October 26, 2025)
**Completed Steps:** 4 of 8

## Current Status

✅ **Step 1:** Install Build Tools (setuptools, wheel, twine, build)
✅ **Step 2:** Verify Build System Configuration (PEP 517)
✅ **Step 3:** Review & Prepare PyPI Metadata
✅ **Step 4:** Generate Distribution Packages

**Output Files:**
- `dist/ssh_agent_bridge-0.1.0-py3-none-any.whl` (13,298 bytes)
- `dist/ssh_agent_bridge-0.1.0.tar.gz` (62,668 bytes)

## Remaining Steps

### Step 5: Test PyPI Upload (Optional but Recommended)

Before uploading to production PyPI, test with TestPyPI first:

1. **Create TestPyPI Account:**
   - Go to https://test.pypi.org/
   - Create free account
   - Generate API token under "Account settings → API tokens"

2. **Configure `.pypirc` (optional but convenient):**
   Create `~/.pypirc` on Linux/Mac or `%APPDATA%\pip\pip.ini` on Windows:
   ```ini
   [distutils]
   index-servers =
       pypi
       testpypi

   [testpypi]
   repository = https://test.pypi.org/legacy/
   username = __token__
   password = pypi-AgEIcHlwaS5vcmc...  # Your TestPyPI token

   [pypi]
   username = __token__
   password = pypi-AgEIcHlwaS5vcmc...  # Your PyPI token
   ```

3. **Upload to TestPyPI:**
   ```bash
   uv run twine upload --repository testpypi dist/*
   ```

4. **Verify on TestPyPI:**
   - Visit https://test.pypi.org/project/ssh-agent-bridge/
   - Check that package metadata looks correct

5. **Test Installation:**
   ```bash
   # Create fresh venv for testing
   python -m venv test_env
   source test_env/bin/activate  # or test_env\Scripts\activate.ps1 on Windows
   
   # Install from TestPyPI
   pip install -i https://test.pypi.org/simple/ ssh-agent-bridge
   
   # Test import
   python -c "import ssh_agent_bridge; print(ssh_agent_bridge.__version__)"
   ```

### Step 6: Create Git Tag

After successful testing, tag the release:

```bash
# Create annotated tag
git tag -a v0.1.0 -m "Release v0.1.0 - Initial stable release"

# Verify tag
git tag -l -n3

# Push tag to remote
git push origin v0.1.0
```

### Step 7: Upload to Production PyPI

1. **Create PyPI Account:**
   - Go to https://pypi.org/
   - Create free account
   - Generate API token under "Account settings → API tokens"
   - Store token securely

2. **Upload to Production:**
   ```bash
   uv run twine upload dist/*
   ```
   
   When prompted, enter:
   - Username: `__token__`
   - Password: Your PyPI API token

3. **Verify Package on PyPI:**
   - Visit https://pypi.org/project/ssh-agent-bridge/
   - Verify metadata, description, version, dependencies

### Step 8: Documentation & Announcement

1. **Update CHANGELOG.md:**
   ```markdown
   ## [0.1.0] - 2025-10-26

   ### Added
   - Initial stable release of SSH Agent Bridge
   - Full SSH session management for AI agents
   - Marker-based command completion detection
   - Support for interactive prompts and signal handling
   - Comprehensive documentation and examples
   - Complete test coverage (>80%)

   ### Security
   - Host key verification and private key validation
   - Credential security best practices implemented
   ```

2. **Update README.md (if needed):**
   - Add installation instructions: `pip install ssh-agent-bridge`
   - Verify quick start examples are current
   - Check all links are working

3. **Commit Changes:**
   ```bash
   git add CHANGELOG.md README.md dist/
   git commit -m "[Phase 6] Release v0.1.0 to PyPI"
   ```

4. **Create GitHub Release (optional):**
   - Go to Releases page
   - Create release from v0.1.0 tag
   - Copy CHANGELOG.md content as description
   - Add wheel and sdist files as assets

## Quality Checklist

Before releasing:

- [ ] All 52+ unit tests passing
- [ ] Code coverage >80%
- [ ] Type checking (mypy) passing
- [ ] Code formatting (black, isort) passing
- [ ] Linting (flake8, pylint) passing
- [ ] Documentation complete and accurate
- [ ] CHANGELOG.md updated with release notes
- [ ] README.md installation instructions current
- [ ] Examples in `/examples` all working
- [ ] Both wheel and sdist files generated

## Post-Release

After successful PyPI upload:

1. **Verify Installation:**
   ```bash
   # In fresh environment
   pip install ssh-agent-bridge
   python -c "from ssh_agent_bridge import SSHService; print('✓ Import successful')"
   ```

2. **Update Issue Tracker:**
   - Close release issues
   - Create issues for Phase 7 enhancements

3. **Plan Next Release:**
   - Review Phase 7 backlog items
   - Prioritize feature requests
   - Plan v0.2.0 roadmap

## Troubleshooting

### Upload Issues

**"Twine: Could not find existing project"**
- Your package may be queued for processing
- Wait a few minutes and try again
- Verify package name matches exactly

**"Error: HTTPError 403"**
- Check your PyPI token is correct
- Verify username is `__token__` (not your username)
- Ensure token has upload permissions

**"The file already exists"**
- Can't upload same version twice
- Increment patch version and rebuild
- Or delete from test PyPI and try again

### Build Issues

**"SetuptoolsDeprecationWarning"**
- These are cosmetic warnings about future compatibility
- Can be safely ignored for v0.1.0
- Will be fixed in next version

**"No module named 'asyncssh'"**
- Your test environment needs dependencies installed
- Run: `pip install asyncssh`

## Verification Steps

After upload to PyPI:

```bash
# Search PyPI
pip search ssh-agent-bridge  # or visit pypi.org

# Install from PyPI
pip install ssh-agent-bridge --upgrade

# Verify version
python -c "from ssh_agent_bridge import __version__; print(f'Version: {__version__}')"

# Try importing all modules
python -c "from ssh_agent_bridge import SSHService, CommandResult, SSHError"

# Check dependencies installed
pip show ssh-agent-bridge
```

## Timeline

- Phase 6 started: October 26, 2025
- Build system verified: ✅ 2025-10-26
- Distribution packages created: ✅ 2025-10-26
- Target completion: 2025-10-26 (same day)

## References

- PyPI Packaging Guide: https://packaging.python.org/
- PEP 517 (Build System Interface): https://www.python.org/dev/peps/pep-0517/
- Twine Documentation: https://twine.readthedocs.io/
- TestPyPI: https://test.pypi.org/
- Production PyPI: https://pypi.org/
