"""
Basic package import and structure tests.
"""

import pytest


def test_package_import():
    """Test that ytqgen package can be imported."""
    import ytqgen
    assert ytqgen.__version__ is not None


def test_package_version():
    """Test that package has a version string."""
    import ytqgen
    assert isinstance(ytqgen.__version__, str)
    assert len(ytqgen.__version__) > 0


def test_public_api_exports():
    """Test that public API functions are exported."""
    import ytqgen
    
    # Check main function is exported
    assert hasattr(ytqgen, "process_stream")
    assert callable(ytqgen.process_stream)
    
    # Check config exports
    assert hasattr(ytqgen, "LLM_PROVIDER")
    assert hasattr(ytqgen, "TRANSCRIPTION_PROVIDER")


def test_cli_module_import():
    """Test that CLI module can be imported."""
    from ytqgen import cli
    assert hasattr(cli, "main")
    assert callable(cli.main)


def test_config_module_import():
    """Test that config module can be imported."""
    from ytqgen import config
    assert hasattr(config, "LLM_PROVIDER")
    assert hasattr(config, "NUM_QUESTIONS")


def test_pipeline_module_import():
    """Test that pipeline module can be imported."""
    from ytqgen import pipeline
    assert hasattr(pipeline, "process_stream")


def test_all_core_modules_import():
    """Test that all core modules can be imported."""
    from ytqgen import (
        audio_processor,
        transcription,
        summarizer,
        questionnaire_generator,
        pdf_generator,
        model_loader
    )
    
    assert audio_processor is not None
    assert transcription is not None
    assert summarizer is not None
    assert questionnaire_generator is not None
    assert pdf_generator is not None
    assert model_loader is not None
