"""
Configuration and YAML loading tests.
"""

import pytest
import yaml
from pathlib import Path


def test_load_test_config(test_config_path):
    """Test that test config file exists and can be loaded."""
    assert test_config_path.exists(), f"Test config not found: {test_config_path}"
    
    with open(test_config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    assert config is not None
    assert isinstance(config, dict)


def test_config_has_required_fields(test_config_path):
    """Test that config has all required fields."""
    with open(test_config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    # Check top-level fields
    assert "provider" in config
    assert "transcription_provider" in config
    assert "keys" in config
    assert "generation" in config


def test_config_providers_valid(test_config_path):
    """Test that configured providers are valid."""
    with open(test_config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    valid_providers = ["openai", "mistral", "groq"]
    assert config["provider"] in valid_providers
    assert config["transcription_provider"] in valid_providers


def test_config_generation_settings(test_config_path):
    """Test that generation settings are properly configured."""
    with open(test_config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    gen = config["generation"]
    
    # Check required fields
    assert "num_questions" in gen
    assert "question_types" in gen
    assert "difficulty" in gen
    assert "style" in gen
    
    # Check num_questions is positive
    assert gen["num_questions"] > 0


def test_config_percentage_sums():
    """Test that percentages sum to 100."""
    from ytqgen.cli import load_config, validate_config
    
    config_path = Path(__file__).parent.parent / "test_config.yml"
    config = load_config(str(config_path))
    
    # This should not raise any errors
    validate_config(config)


def test_cli_load_config_function():
    """Test CLI config loading function."""
    from ytqgen.cli import load_config
    
    config_path = Path(__file__).parent.parent / "test_config.yml"
    config = load_config(str(config_path))
    
    assert config is not None
    assert isinstance(config, dict)
    assert "provider" in config


def test_cli_validate_config_function():
    """Test CLI config validation function."""
    from ytqgen.cli import validate_config
    
    # Valid config should not raise
    valid_config = {
        "provider": "groq",
        "transcription_provider": "groq",
        "generation": {
            "num_questions": 5,
            "question_types": {
                "mcq_percentage": 40,
                "subjective_percentage": 60
            },
            "difficulty": {
                "easy_percentage": 30,
                "medium_percentage": 50,
                "hard_percentage": 20
            },
            "style": {
                "scenario_percentage": 50,
                "theoretical_percentage": 50
            }
        }
    }
    
    validate_config(valid_config)  # Should not raise


def test_cli_validate_config_invalid_provider():
    """Test that invalid provider raises error."""
    from ytqgen.cli import validate_config
    
    invalid_config = {
        "provider": "invalid_provider"
    }
    
    with pytest.raises(ValueError, match="Invalid provider"):
        validate_config(invalid_config)


def test_cli_validate_config_invalid_percentages():
    """Test that invalid percentages raise error."""
    from ytqgen.cli import validate_config
    
    invalid_config = {
        "generation": {
            "question_types": {
                "mcq_percentage": 50,
                "subjective_percentage": 60  # Sums to 110, not 100
            }
        }
    }
    
    with pytest.raises(ValueError, match="must sum to 100"):
        validate_config(invalid_config)
