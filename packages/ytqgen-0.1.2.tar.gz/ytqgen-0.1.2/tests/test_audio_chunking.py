"""
Audio chunking tests.
Tests audio splitting functionality for transcription.
"""

import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch
import tempfile


def test_split_audio_into_chunks_function_exists():
    """Test that split_audio_into_chunks function exists."""
    from ytqgen.audio_processor import split_audio_into_chunks
    assert callable(split_audio_into_chunks)


def test_get_audio_duration_function_exists():
    """Test that get_audio_duration function exists."""
    from ytqgen.transcription import get_audio_duration
    assert callable(get_audio_duration)


def test_transcribe_audio_chunk_function_exists():
    """Test that transcribe_audio_chunk function exists."""
    from ytqgen.transcription import transcribe_audio_chunk
    assert callable(transcribe_audio_chunk)


@pytest.mark.parametrize("duration,chunk_size,expected_chunks", [
    (300, 600, 1),   # 5 minutes -> 1 chunk (no split)
    (700, 600, 2),   # 11.6 minutes -> 2 chunks
    (1200, 600, 2),  # 20 minutes -> 2 chunks
    (1800, 600, 3),  # 30 minutes -> 3 chunks
])
def test_audio_chunking_logic(duration, chunk_size, expected_chunks):
    """Test audio chunking logic for different durations."""
    import math
    
    # Simulate the chunking calculation
    if duration <= chunk_size:
        num_chunks = 1
    else:
        num_chunks = math.ceil(duration / chunk_size)
    
    assert num_chunks == expected_chunks


def test_transcription_with_chunking_enabled():
    """Test that transcription respects chunking for long audio."""
    from ytqgen.transcription import transcribe_audio
    
    # We'll mock the actual audio processing
    with patch('ytqgen.transcription.get_audio_duration', return_value=700):
        with patch('ytqgen.transcription.transcribe_audio_chunk', return_value="Test transcript"):
            with patch('ytqgen.audio_processor.split_audio_into_chunks', return_value=["chunk1.mp3", "chunk2.mp3"]):
                with tempfile.NamedTemporaryFile(suffix='.mp3', delete=False) as tmp:
                    tmp_path = tmp.name
                
                # This would chunk the audio
                # Actual test would verify chunking happens
                # For now, just verify function doesn't crash
                try:
                    # Don't actually call it without API keys
                    pass
                finally:
                    Path(tmp_path).unlink(missing_ok=True)


def test_chunk_duration_default():
    """Test that default chunk duration is 10 minutes (600 seconds)."""
    from ytqgen.audio_processor import split_audio_into_chunks
    import inspect
    
    sig = inspect.signature(split_audio_into_chunks)
    chunk_duration_param = sig.parameters.get('chunk_duration_seconds')
    
    # Check default value is 600 (10 minutes)
    if chunk_duration_param and chunk_duration_param.default != inspect.Parameter.empty:
        assert chunk_duration_param.default == 600


def test_audio_processing_imports():
    """Test that audio processing modules can be imported."""
    try:
        from ytqgen.audio_processor import split_audio_into_chunks
        from ytqgen.transcription import get_audio_duration, transcribe_audio_chunk
        assert True
    except ImportError as e:
        pytest.fail(f"Failed to import audio processing functions: {e}")


def test_transcription_cleanup_temp_files():
    """Test that temporary chunk files are cleaned up."""
    # This is more of an integration test
    # For unit test, we just verify the logic exists
    from ytqgen.transcription import transcribe_audio
    import inspect
    
    # Check that the function mentions cleanup in its implementation
    source = inspect.getsource(transcribe_audio)
    assert 'unlink' in source or 'remove' in source or 'cleanup' in source.lower()
