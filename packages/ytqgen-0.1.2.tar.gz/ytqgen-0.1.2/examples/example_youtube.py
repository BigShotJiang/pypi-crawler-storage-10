"""
Example: Process a YouTube video using YtQGen library.

NOTE: YouTube downloads work when run LOCALLY (not in cloud environments).
YouTube blocks requests from cloud IPs, so this will work on your local machine
but may fail on cloud servers like Kaggle, Colab, AWS Lambda, etc.

For cloud deployments, use local file upload instead.
"""

import os
from ytqgen import process_stream

# Set API keys via environment variables
os.environ['LLM_PROVIDER'] = 'openai'
os.environ['OPENAI_API_KEY'] = 'your-api-key-here'
os.environ['TRANSCRIPTION_PROVIDER'] = 'openai'

# YouTube video URL
youtube_url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"

# Process and generate questionnaire
print(f"Processing YouTube video: {youtube_url}")
print("Note: This downloads the video locally using yt-dlp, then processes it.")

pdf_output = process_stream(youtube_url, output_pdf="youtube_questionnaire.pdf")

if pdf_output:
    print(f"✓ Success! Generated: {pdf_output}")
else:
    print("✗ Failed to generate questionnaire")
