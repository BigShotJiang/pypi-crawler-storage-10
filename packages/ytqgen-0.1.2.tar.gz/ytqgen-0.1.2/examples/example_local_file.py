"""
Example: Process a local video file using YtQGen library.

This demonstrates using YtQGen programmatically from Python code.
"""

import os
from ytqgen import process_stream

# Set API keys via environment variables
os.environ['LLM_PROVIDER'] = 'openai'
os.environ['OPENAI_API_KEY'] = 'your-api-key-here'
os.environ['TRANSCRIPTION_PROVIDER'] = 'openai'

# Path to your local video file
video_file = "path/to/your/video.mp4"

# Process and generate questionnaire
print(f"Processing video: {video_file}")
pdf_output = process_stream(video_file, output_pdf="my_questionnaire.pdf")

if pdf_output:
    print(f"✓ Success! Generated: {pdf_output}")
else:
    print("✗ Failed to generate questionnaire")
