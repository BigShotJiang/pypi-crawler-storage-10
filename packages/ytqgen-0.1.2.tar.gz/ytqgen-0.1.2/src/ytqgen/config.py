"""
Configuration settings for the YtQGen pipeline.
"""

import os
import sys

# Add parent directory to path if running from src folder
if __name__ != "__main__":
    parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if parent_dir not in sys.path:
        sys.path.insert(0, parent_dir)

# Load .env only if not already loaded (to allow YAML config to take precedence)
# YAML config is applied BEFORE this module is imported by setting os.environ
# So we only load .env as a fallback if values aren't already present
try:
    from dotenv import load_dotenv
    # Check if critical env vars are already set (from YAML or environment)
    # If not set, load from .env file
    if not os.getenv("LLM_PROVIDER") and not os.getenv("OPENAI_API_KEY"):
        # Look for .env in: 1) current dir, 2) project root
        load_dotenv()  # Current directory
        project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        env_path = os.path.join(project_root, '.env')
        if os.path.exists(env_path):
            load_dotenv(env_path, override=False)  # Don't override existing values
except ImportError:
    # dotenv not installed, use os.environ directly
    pass

# API Configuration
# Supported providers: "openai", "mistral", "groq"
LLM_PROVIDER = os.getenv("LLM_PROVIDER", "openai")  # Default to OpenAI
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
MISTRAL_API_KEY = os.getenv("MISTRAL_API_KEY", "")
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")

# Model names for each provider
# Can be overridden via environment variables or YAML config
OPENAI_MODEL = os.getenv("YTQGEN_OPENAI_MODEL", "gpt-4o-mini")  # or "gpt-4", "gpt-3.5-turbo"
MISTRAL_MODEL = os.getenv("YTQGEN_MISTRAL_MODEL", "mistral-small-latest")  # or "mistral-medium", "mistral-large-latest"
GROQ_MODEL = os.getenv("YTQGEN_GROQ_MODEL", "llama-3.1-70b-versatile")  # or "mixtral-8x7b-32768", "llama-3.3-70b-versatile"

# Transcription configuration
TRANSCRIPTION_PROVIDER = os.getenv("TRANSCRIPTION_PROVIDER", "openai")  # "openai", "groq", or "mistral"

# Processing parameters
MAX_WORDS_PER_CHUNK = 512
MAX_TOKENS = 512
SUMMARY_MAX_LENGTH = 150
SUMMARY_MIN_LENGTH = 50

# Audio parameters
AUDIO_SAMPLE_RATE = 16000
AUDIO_CHANNELS = 1

# LLM generation parameters
LLM_MAX_TOKENS = 2000
LLM_TEMPERATURE = 0.2
LLM_TOP_P = 0.8

# PDF parameters
PDF_MARGIN = 50
PDF_FONT_SIZE = 12
PDF_MAX_CHARS_PER_LINE = 100

# Questionnaire generation parameters
NUM_QUESTIONS = int(os.getenv("YTQGEN_NUM_QUESTIONS", "10"))

# Question type distribution (percentages)
MCQ_PERCENTAGE = int(os.getenv("YTQGEN_MCQ_PERCENTAGE", "20"))
SUBJECTIVE_PERCENTAGE = int(os.getenv("YTQGEN_SUBJECTIVE_PERCENTAGE", "80"))

# Difficulty distribution (percentages, should sum to 100)
EASY_PERCENTAGE = int(os.getenv("YTQGEN_EASY_PERCENTAGE", "30"))
MEDIUM_PERCENTAGE = int(os.getenv("YTQGEN_MEDIUM_PERCENTAGE", "50"))
HARD_PERCENTAGE = int(os.getenv("YTQGEN_HARD_PERCENTAGE", "20"))

# Question style distribution (percentages, should sum to 100)
SCENARIO_PERCENTAGE = int(os.getenv("YTQGEN_SCENARIO_PERCENTAGE", "40"))  # Real-world scenarios
THEORETICAL_PERCENTAGE = int(os.getenv("YTQGEN_THEORETICAL_PERCENTAGE", "60"))  # Theory-based
