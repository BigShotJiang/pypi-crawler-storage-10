"""
Main entry point for the YtQGen application.
Run this file to process a YouTube video and generate a questionnaire.

Environment Variables Required:
    - LLM_PROVIDER: "openai", "mistral", or "groq" (default: "openai")
    - TRANSCRIPTION_PROVIDER: "openai", "groq", or "mistral" (default: "openai")
    - OPENAI_API_KEY: Your OpenAI API key (if using OpenAI)
    - MISTRAL_API_KEY: Your Mistral API key (if using Mistral)
    - GROQ_API_KEY: Your Groq API key (if using Groq)

Requirements:
    pip install openai mistralai groq yt-dlp reportlab requests
"""

import os

# Handle imports for both running from src and from parent directory
try:
    from pipeline import process_stream
except ImportError:
    from .pipeline import process_stream

# Optional: For Jupyter/Kaggle environments
try:
    from IPython.display import FileLink, display
    JUPYTER_ENV = True
except ImportError:
    JUPYTER_ENV = False


if __name__ == "__main__":
    print("=" * 60)
    print("YtQGen - YouTube to Questionnaire Generator")
    print("=" * 60)
    print()
    
    # Example: Set environment variables (you can also set these in your system)
    # os.environ["LLM_PROVIDER"] = "openai"  # or "mistral" or "groq"
    # os.environ["TRANSCRIPTION_PROVIDER"] = "openai"  # or "groq"
    # os.environ["OPENAI_API_KEY"] = "your-api-key-here"
    
    # Replace with your YouTube video link
    youtube_url = "https://www.youtube.com/watch?v=O_G2hVZvNBg"
    
    print(f"Processing video: {youtube_url}")
    print()
    
    # Process the video and generate questionnaire
    pdf_file = process_stream(youtube_url)
    
    if pdf_file:
        print(f"\nSuccess! Questionnaire saved to: {pdf_file}")
        
        # Display a download link in Jupyter/Kaggle environments
        if JUPYTER_ENV:
            display(FileLink(pdf_file))
    else:
        print("\nFailed to generate questionnaire. Please check the errors above.")