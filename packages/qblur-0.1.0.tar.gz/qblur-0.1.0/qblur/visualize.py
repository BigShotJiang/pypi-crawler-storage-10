import numpy as np
import cv2
import matplotlib.pyplot as plt
from .core import qblur_image

def visualize_decoherence(image: np.ndarray, steps: int = 5, kernel_size: int = 7):
    fig, axes = plt.subplots(1, steps, figsize=(15, 4))
    for i, c in enumerate(np.linspace(1, 0, steps)):
        out = qblur_image(image, coherence=c, kernel_size=kernel_size)
        axes[i].imshow(cv2.cvtColor(out, cv2.COLOR_BGR2RGB))
        axes[i].set_title(f"Coherence = {c:.2f}")
        axes[i].axis("off")
    plt.tight_layout()
    plt.show()