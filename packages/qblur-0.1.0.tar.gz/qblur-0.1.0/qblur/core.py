import cv2
import numpy as np

def qblur_image(image: np.ndarray, coherence: float = 0.8, kernel_size: int = 7) -> np.ndarray:
    if not (0 <= coherence <= 1):
        raise ValueError("Coherence must be between 0 and 1")

    if image.ndim == 2:
        blurred = cv2.GaussianBlur(image, (kernel_size, kernel_size), 0)
        return (coherence * image + (1 - coherence) * blurred).astype(np.uint8)
    elif image.ndim == 3:
        blurred = cv2.GaussianBlur(image, (kernel_size, kernel_size), 0)
        return cv2.addWeighted(image, coherence, blurred, 1 - coherence, 0)
    else:
        raise ValueError("Input image must be 2D or 3D numpy array")