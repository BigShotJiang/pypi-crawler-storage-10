# qblur

**Quantum-Inspired Image Smoothing**

This package simulates quantum decoherence as image blurring.  
It treats blurring as a loss of phase coherence in the intensity field.

### Example

```python
import qblur
img = qblur.qblur_image("cameraman.png", decoherence=0.6)