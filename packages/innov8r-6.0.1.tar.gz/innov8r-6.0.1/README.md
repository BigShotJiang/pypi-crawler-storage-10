# innov8r

**innov8r** is a Python-based GUI application designed to streamline software development workflows with innovative tools and utilities. It provides developers with an intuitive and user-friendly interface for building efficient and scalable solutions.

---

## Installation

Install the application using pip:

```bash
pip install innov8r
```

## Script to run and start

```python
from innov8r import launch, report_time
from innov8r.flask_app import startFlaskApp


startFlaskApp()
report_time("Before launch")
launch()
```
