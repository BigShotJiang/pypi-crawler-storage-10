from flask import Flask, request, jsonify, render_template,redirect, url_for, flash, session
from flask_cors import CORS
from threading import Thread
from innov8r import get_runner, get_workbench, get_shell
import requests


FlaskAPP =Flask(__name__)

CORS(FlaskAPP, resources={r"/*": {"origins": "*"}})


@FlaskAPP.route('/')
def index():
    return render_template('index.html')



@FlaskAPP.route('/api/v1/esp32/make-request-on-esp32', methods=['POST'])
def make_request_on_esp32():
    try:
        data = request.get_json()
        endpoint = data['endpoint']
        if endpoint == None:
            return jsonify({
                'status': 'error',
                'message': 'Endpoint is required',
                'response': None
            })
        ip_address = data['ip_address']
        if ip_address == None:
            return jsonify({
                'status': 'error',
                'message': 'IP address is required',
                'response': None
            })
        parameters = data['parameters']
        response = requests.get(f'http://{ip_address}/{endpoint}?{parameters}')
        return jsonify({
            'status': 'success',
            'message': 'Request made successfully',
            'response': response.text
        })
    except:
        return jsonify({
            'status': 'error',
            'message': 'Invalid request',
            'response': None
        }), 500


@FlaskAPP.route('/api/v1/esp32/deploy', methods=['POST'])
def deploy():
    data = request.get_json()
    code = data['data']
    get_workbench().get_editor_notebook().get_current_editor().get_code_view().set_content(code)
    get_runner().cmd_run_current_script()
    return jsonify({
        'status': 'success',
        'message': 'Reached to IDE successfully',
        'response': None
    })

@FlaskAPP.route('/ide/shell/get/messages', methods=['GET'])
def get_shell_messages():
    messages=get_shell().text.get("1.0", "end-1c")
    # print(messages)
    return jsonify({
        'status': 'success',
        'messages': messages,
        'response': None
    })

@FlaskAPP.route('/ide/shell/restart-backend', methods=['GET'])
def restart_shell():
    get_runner().restart_backend(clean=True)
    return jsonify({
        'status': 'success',
        'message': 'Shell restarted successfully',
        'response': None
    })

@FlaskAPP.route('/ide/shell/save-in-persistent-storage', methods=['POST'])
def save_in_persistent_storage():
    data = request.get_json()
    code = data['data']
    code = code.replace("\"", "\\\"")
    new_code = f"""bootPyContent = \"\"\"# This file is executed on every boot (including wake-boot from deepsleep)
#import esp
#esp.osdebug(None)
#import webrepl
#webrepl.start()
import program
\"\"\"

code = \"\"\"{code}\"\"\"

with open("boot.py", "w") as f:
    f.write(bootPyContent)
with open("program.py", "w") as f:
    f.write(code)"""
    get_workbench().get_editor_notebook().get_current_editor().get_code_view().set_content(new_code)
    get_runner().cmd_run_current_script()
    print(new_code)
    return jsonify({
        'status': 'success',
        'message': 'Code saved in persistent storage successfully',
        'response': None
    })

def run_app():
    FlaskAPP.run(host='0.0.0.0', port=8080, debug=False, use_reloader=False)

def startFlaskApp():
    flask_thread = Thread(target=run_app)
    flask_thread.daemon = True
    flask_thread.start()

if __name__ == '__main__':
    FlaskAPP.run(debug=True)



