from innov8r import launch, report_time
from innov8r.flask_app import startFlaskApp


startFlaskApp()
report_time("Before launch")
launch()
