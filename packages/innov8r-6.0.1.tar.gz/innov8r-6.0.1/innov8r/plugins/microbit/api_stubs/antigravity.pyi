"""
Easter-egg.
"""
