# moai-lang-sql - CLI Reference

_Last updated: 2025-10-22_

## Quick Reference

### Installation

```bash
# Installation commands
```

### Common Commands

```bash
# Test
# Lint
# Format
# Build
```

## Tool Versions (2025-10-22)

- **PostgreSQL**: 17.2
- **MySQL**: 9.1.0
- **sqlfluff**: 3.2.5
- **pgTAP**: 1.3.3

---

_For detailed usage, see SKILL.md_
