# moai-lang-dart - CLI Reference

_Last updated: 2025-10-22_

## Quick Reference

### Installation

```bash
# Installation commands
```

### Common Commands

```bash
# Test
# Lint
# Format
# Build
```

## Tool Versions (2025-10-22)

- **Dart**: 3.6.0
- **Flutter**: 3.27.0
- **dart analyze**: 3.6.0

---

_For detailed usage, see SKILL.md_
