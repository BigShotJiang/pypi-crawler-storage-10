---
name: "Skill Name (Gerund + Domain)"
description: "[Capability]. Use when [trigger 1], [trigger 2], [trigger 3]."
allowed-tools: "Read, Write, Bash(python:*)"
---

# Skill Name

## Quick Start

## Core Patterns

## Examples

See examples.md for real-world scenarios.
