# moai-domain-data-science - CLI Reference

_Last updated: 2025-10-22_

## Quick Reference

### Installation

```bash
# Installation commands
```

### Common Commands

```bash
# Test
# Lint
# Format
# Build
```

## Tool Versions (2025-10-22)

- **Pandas**: 2.2.0
- **NumPy**: 2.2.0
- **Jupyter**: 1.1.0

---

_For detailed usage, see SKILL.md_
