# moai-foundation-git - CLI Reference

_Last updated: 2025-10-22_

## Quick Reference

### Installation

```bash
# Installation commands
```

### Common Commands

```bash
# Test
# Lint
# Format
# Build
```

## Tool Versions (2025-10-22)

- **Git**: 2.47.0
- **GitHub CLI**: 2.63.0

---

_For detailed usage, see SKILL.md_
