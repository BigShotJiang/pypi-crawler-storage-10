# moai-lang-ruby - Working Examples

_Last updated: 2025-10-22_

## Example 1: Basic Setup

```bash
# Setup commands
# ...
```

## Example 2: TDD Workflow

```bash
# RED: Write failing test
# GREEN: Implement feature
# REFACTOR: Improve code
```

## Example 3: Quality Gate

```bash
# Run quality checks
# Verify coverage ≥85%
```

---

_For more examples, see SKILL.md reference section_
