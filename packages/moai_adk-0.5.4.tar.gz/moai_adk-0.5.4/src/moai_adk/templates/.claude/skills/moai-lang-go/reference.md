# moai-lang-go - CLI Reference

_Last updated: 2025-10-22_

## Quick Reference

### Installation

```bash
# Installation commands
```

### Common Commands

```bash
# Test
# Lint
# Format
# Build
```

## Tool Versions (2025-10-22)

- **Go**: 1.24.0
- **golangci-lint**: 1.62.2
- **gofmt**: 1.24.0
- **gotestsum**: 1.12.0

---

_For detailed usage, see SKILL.md_
