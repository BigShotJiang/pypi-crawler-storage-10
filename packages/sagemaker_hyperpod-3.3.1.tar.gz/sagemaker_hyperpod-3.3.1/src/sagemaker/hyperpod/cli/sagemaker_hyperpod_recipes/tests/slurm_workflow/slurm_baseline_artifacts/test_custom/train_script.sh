#!/bin/bash
set -ex
export NCCL_DEBUG=DEBUG
export FI_PROVIDER=efa
export NCCL_SOCKET_IFNAME=^lo,docker0,veth_def_agent
export NCCL_IGNORE_DISABLED_P2P=1
export TORCH_NCCL_ASYNC_ERROR_HANDLING=1
export TORCH_DIST_INIT_BARRIER=1
export CUDA_DEVICE_MAX_CONNECTIONS=1
MASTER_ADDR=$(head -n 1 {$results_dir}/test_custom/hostname)
NODEID=$(($(grep -nx -o "\b$(hostname)\b" {$results_dir}/test_custom/hostname | cut -d ":" -f 1) - 1))
NNODES=2
PROCESSES_PER_NODE=8
MASTER_PORT=41000

DISTRIBUTED_ARGS="--nproc_per_node $PROCESSES_PER_NODE --nnodes $NNODES --rdzv_endpoint=$MASTER_ADDR --rdzv_id=100 --rdzv_backend=c10d"

# For greater env stability, grab hostname from `hostname`
# https://sim.amazon.com/issues/P162624109
LAUNCHER_HOSTNAME="$(hostname)"

mkdir -p $HOME/tmp
GIT_CLONE_DIR="$HOME/tmp/$LAUNCHER_HOSTNAME"
[[ -d $GIT_CLONE_DIR ]] && rm -rf $GIT_CLONE_DIR
git clone https://github.com/example $GIT_CLONE_DIR
GIT_CLONE_DIR=${GIT_CLONE_DIR}/
cd $GIT_CLONE_DIR
rm -rf __pycache__

unset SLURM_NTASKS

torchrun $DISTRIBUTED_ARGS  \
  test.py \
  