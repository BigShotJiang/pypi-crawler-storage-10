"""
测试 tongWnB 与 Transformers 的集成功能。
"""

import os
import unittest
from unittest.mock import Mock, patch, MagicMock

import tongWnB
from tongWnB.integration import TongWnBCallback, is_transformers_available


class TestTongWnBCallback(unittest.TestCase):
    """测试 TongWnBCallback 类。"""

    def setUp(self):
        """每个测试前的设置。"""
        # 重置全局 run 对象
        tongWnB.export.run = None

    def test_callback_initialization(self):
        """测试回调初始化。"""
        callback = TongWnBCallback(
            labHost="http://test.com",
            company="test_company",
            projectName="test_project",
            experimentName="test_experiment",
            apiKey="test_key",
            gpus=[0, 1],
        )
        
        self.assertFalse(callback._initialized)
        self.assertEqual(callback._labHost, "http://test.com")
        self.assertEqual(callback._company, "test_company")
        self.assertEqual(callback._projectName, "test_project")

    def test_callback_with_config(self):
        """测试带配置的回调初始化。"""
        config = {
            "learning_rate": 0.001,
            "batch_size": 32,
            "model": "gpt2"
        }
        
        callback = TongWnBCallback(
            labHost="http://test.com",
            company="test_company",
            projectName="test_project",
            experimentName="test_experiment",
            apiKey="test_key",
            gpus=[0],
            config=config,
        )
        
        self.assertEqual(callback._config, config)

    @patch("tongWnB.integration.init")
    def test_setup_with_args(self, mock_init):
        """测试使用 TrainingArguments 进行设置。"""
        callback = TongWnBCallback(
            labHost="http://test.com",
            company="test_company",
            projectName="test_project",
            experimentName="test_experiment",
            apiKey="test_key",
            gpus=[0],
        )
        
        # 模拟 TrainingArguments
        mock_args = Mock()
        mock_args.learning_rate = 5e-5
        mock_args.num_train_epochs = 3
        mock_args.per_device_train_batch_size = 8
        mock_args.per_device_eval_batch_size = 8
        mock_args.weight_decay = 0.01
        mock_args.warmup_steps = 500
        mock_args.logging_steps = 10
        mock_args.save_steps = 500
        mock_args.eval_steps = 500
        mock_args.seed = 42
        mock_args.run_name = "test_run"
        
        mock_state = Mock()
        mock_model = Mock()
        
        callback.setup(mock_args, mock_state, mock_model)
        
        # 验证 init 被调用
        mock_init.assert_called_once()
        call_kwargs = mock_init.call_args[1]
        
        self.assertEqual(call_kwargs["labHost"], "http://test.com")
        self.assertEqual(call_kwargs["company"], "test_company")
        self.assertEqual(call_kwargs["projectName"], "test_project")
        self.assertEqual(call_kwargs["experimentName"], "test_experiment")
        self.assertTrue(callback._initialized)

    @patch.dict(os.environ, {
        "TONGWNB_LAB_HOST": "http://env-test.com",
        "TONGWNB_API_KEY": "env_key",
        "TONGWNB_COMPANY": "env_company",
        "TONGWNB_PROJECT": "env_project",
        "TONGWNB_EXPERIMENT": "env_experiment",
        "TONGWNB_GPUS": "0,1,2",
    })
    @patch("tongWnB.integration.init")
    def test_setup_with_env_vars(self, mock_init):
        """测试使用环境变量进行设置。"""
        callback = TongWnBCallback()
        
        mock_args = Mock()
        mock_args.learning_rate = 5e-5
        mock_args.num_train_epochs = 1
        mock_args.per_device_train_batch_size = 2
        mock_args.per_device_eval_batch_size = 2
        mock_args.weight_decay = 0.0
        mock_args.warmup_steps = 0
        mock_args.logging_steps = 10
        mock_args.save_steps = 500
        mock_args.eval_steps = 500
        mock_args.seed = 42
        
        mock_state = Mock()
        mock_model = Mock()
        
        callback.setup(mock_args, mock_state, mock_model)
        
        # 验证使用了环境变量
        call_kwargs = mock_init.call_args[1]
        self.assertEqual(call_kwargs["labHost"], "http://env-test.com")
        self.assertEqual(call_kwargs["apiKey"], "env_key")
        self.assertEqual(call_kwargs["company"], "env_company")
        self.assertEqual(call_kwargs["projectName"], "env_project")
        self.assertEqual(call_kwargs["gpus"], [0, 1, 2])

    def test_organize_metrics(self):
        """测试指标组织功能。"""
        callback = TongWnBCallback()
        
        logs = {
            "loss": 0.5,
            "grad_norm": 2.3,
            "learning_rate": 0.0001,
            "eval_loss": 0.4,
            "eval_accuracy": 0.95,
            "epoch": 1,
            "step": 100,
            "custom_metric": 123.45,
        }
        
        organized = callback._organize_metrics(logs)
        
        # 验证训练指标
        self.assertIn("training", organized)
        self.assertEqual(organized["training"]["loss"], 0.5)
        self.assertEqual(organized["training"]["grad_norm"], 2.3)
        self.assertEqual(organized["training"]["learning_rate"], 0.0001)
        
        # 验证验证指标
        self.assertIn("evaluation", organized)
        self.assertEqual(organized["evaluation"]["loss"], 0.4)
        self.assertEqual(organized["evaluation"]["accuracy"], 0.95)
        
        # 验证其他指标
        self.assertEqual(organized["custom_metric"], 123.45)
        
        # 验证 epoch 和 step 被排除
        self.assertNotIn("epoch", organized)
        self.assertNotIn("step", organized)

    def test_organize_metrics_filter_non_numeric(self):
        """测试过滤非数值类型的指标。"""
        callback = TongWnBCallback()
        
        logs = {
            "loss": 0.5,
            "model_name": "gpt2",  # 字符串，应该被过滤
            "config": {"lr": 0.001},  # 字典，应该被过滤
            "grad_norm": 2.3,
        }
        
        organized = callback._organize_metrics(logs)
        
        # 验证只有数值类型被保留
        self.assertIn("training", organized)
        self.assertEqual(len(organized["training"]), 2)
        self.assertNotIn("model_name", organized)
        self.assertNotIn("config", organized)

    def test_parse_gpus(self):
        """测试 GPU 字符串解析。"""
        callback = TongWnBCallback()
        
        # 测试正常情况
        self.assertEqual(callback._parse_gpus("0,1,2,3"), [0, 1, 2, 3])
        self.assertEqual(callback._parse_gpus("0"), [0])
        self.assertEqual(callback._parse_gpus("1,3,5"), [1, 3, 5])
        
        # 测试空字符串
        self.assertIsNone(callback._parse_gpus(""))
        
        # 测试无效字符串
        self.assertIsNone(callback._parse_gpus("a,b,c"))

    @patch("tongWnB.integration.get_run")
    def test_on_log(self, mock_get_run):
        """测试 on_log 回调。"""
        mock_run = Mock()
        mock_get_run.return_value = mock_run
        
        callback = TongWnBCallback()
        callback._initialized = True  # 跳过初始化
        
        logs = {
            "loss": 0.5,
            "learning_rate": 0.0001,
        }
        
        mock_args = Mock()
        mock_state = Mock()
        mock_control = Mock()
        
        callback.on_log(mock_args, mock_state, mock_control, logs)
        
        # 验证 create_chart 被调用
        mock_run.create_chart.assert_called_once()
        call_args = mock_run.create_chart.call_args[0][0]
        
        self.assertIn("training", call_args)


class TestIntegrationHelpers(unittest.TestCase):
    """测试集成辅助函数。"""

    def test_is_transformers_available(self):
        """测试检测 transformers 库是否可用。"""
        # 这个测试的结果取决于环境
        # 只验证函数返回布尔值
        result = is_transformers_available()
        self.assertIsInstance(result, bool)


class TestTransformersIntegration(unittest.TestCase):
    """测试与 Transformers 的实际集成。"""

    @unittest.skipUnless(is_transformers_available(), "transformers not installed")
    def test_integration_registered(self):
        """测试集成是否注册到 Transformers。"""
        try:
            from transformers.integrations import INTEGRATION_TO_CALLBACK
            
            # 验证 tongWnB 已注册
            self.assertIn("tongWnB", INTEGRATION_TO_CALLBACK)
            self.assertIn("tongwnb", INTEGRATION_TO_CALLBACK)
        except ImportError:
            self.skipTest("transformers integration not available")


if __name__ == "__main__":
    unittest.main()

