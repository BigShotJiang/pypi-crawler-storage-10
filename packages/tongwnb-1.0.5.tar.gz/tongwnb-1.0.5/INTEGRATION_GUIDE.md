# tongWnB Transformers 集成使用指南

## 概述

tongWnB 现在支持与 Hugging Face Transformers 库的无缝集成，可以自动记录训练过程中的所有指标到 tongWnB 平台。

## 功能特性

- ✅ 自动记录训练指标（loss、learning_rate、grad_norm 等）
- ✅ 自动记录验证指标（eval_loss、eval_accuracy 等）
- ✅ 支持 `report_to="tongWnB"` 参数
- ✅ 支持手动添加 Callback
- ✅ 自动上传系统监控数据（CPU、GPU、内存等）
- ✅ 指标自动分组（训练指标、验证指标）

## 使用方式

### 方式一：使用 `report_to` 参数（推荐）

这是最简单的使用方式，只需要在 `TrainingArguments` 中设置 `report_to="tongWnB"`。

#### 步骤 1：设置环境变量

在运行训练脚本前，设置以下环境变量：

```bash
export TONGWNB_LAB_HOST="http://your-lab-host.com"
export TONGWNB_API_KEY="your_api_key"
export TONGWNB_COMPANY="your_company"
export TONGWNB_PROJECT="your_project_name"
export TONGWNB_EXPERIMENT="your_experiment_name"
export TONGWNB_GPUS="0,1,2,3"  # 使用的 GPU 列表
```

#### 步骤 2：修改训练代码

```python
import tongWnB  # 导入 tongWnB
from transformers import TrainingArguments, Trainer

# 配置训练参数
training_args = TrainingArguments(
    output_dir='./results',
    report_to="tongWnB",  # 使用 tongWnB
    logging_steps=10,
    # ... 其他参数
)

# 创建 Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=eval_dataset,
)

# 开始训练
trainer.train()
```

### 方式二：手动添加 Callback

如果你需要更多控制，可以手动创建和添加 `TongWnBCallback`。

```python
import tongWnB
from tongWnB import TongWnBCallback
from transformers import TrainingArguments, Trainer

# 方式 2a：使用环境变量配置
callback = TongWnBCallback()

# 方式 2b：直接传入配置参数
callback = TongWnBCallback(
    labHost="http://your-lab-host.com",
    company="your_company",
    projectName="your_project",
    experimentName="your_experiment",
    apiKey="your_api_key",
    gpus=[0, 1, 2, 3],
    config={
        "model_name": "gpt2",
        "batch_size": 32,
        "learning_rate": 5e-5,
    }
)

# 创建 Trainer，添加 callback
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=eval_dataset,
    callbacks=[callback],  # 添加 callback
)

# 开始训练
trainer.train()
```

### 方式三：先初始化再使用

如果你想在训练开始前就初始化 tongWnB（例如记录预处理信息），可以先调用 `tongWnB.init()`。

```python
import tongWnB
from transformers import TrainingArguments, Trainer

# 先初始化
tongWnB.init(
    labHost="http://your-lab-host.com",
    company="your_company",
    projectName="your_project",
    experimentName="your_experiment",
    apiKey="your_api_key",
    gpus=[0, 1, 2, 3],
    experimentConfig={
        "model_name": "gpt2",
        "dataset": "wikitext-2",
        "preprocessing": "custom",
    }
)

# 记录预处理信息
tongWnB.log({"data_preprocessing": {"samples_count": 10000, "avg_length": 512}})

# 配置训练参数（tongWnB 会自动接管）
training_args = TrainingArguments(
    output_dir='./results',
    report_to="tongWnB",
    # ... 其他参数
)

trainer = Trainer(model=model, args=training_args, ...)
trainer.train()
```

## 环境变量说明

| 环境变量             | 说明                 | 必需 | 示例                           |
| -------------------- | -------------------- | ---- | ------------------------------ |
| `TONGWNB_LAB_HOST`   | tongWnB 平台地址    | 是   | `http://lab.example.com`       |
| `TONGWNB_API_KEY`    | API 密钥             | 是   | `your_api_key`                 |
| `TONGWNB_COMPANY`    | 公司名称             | 是   | `my_company`                   |
| `TONGWNB_PROJECT`    | 项目名称             | 是   | `gpt2-training`                |
| `TONGWNB_EXPERIMENT` | 实验名称             | 否   | `exp-001`（默认使用 run_name） |
| `TONGWNB_GPUS`       | GPU 列表（逗号分隔） | 是   | `0,1,2,3`                      |
| `TONGWNB_NODE_IP`    | 训练节点 IP          | 否   | 自动检测                       |

## 记录的指标

### 自动记录的训练指标

- `loss` - 训练损失
- `grad_norm` - 梯度范数
- `learning_rate` - 学习率
- `epoch` - 训练轮次

### 自动记录的验证指标

- `eval_loss` - 验证损失
- `eval_accuracy` - 验证准确率
- 以及其他所有以 `eval_` 开头的指标

### 自动记录的系统指标

- CPU 使用率
- GPU 使用率
- 内存使用情况
- GPU 显存使用情况

## 指标分组

tongWnB 会自动将相关指标分组：

- **训练指标组** (`training`): loss, grad_norm, learning_rate
- **验证指标组** (`evaluation`): eval_loss, eval_accuracy 等
- **其他指标**: 自定义指标保持原样

在 tongWnB 平台上，你可以看到清晰分组的指标图表。

## 完整示例

### 示例 1：基础 GPT-2 训练

```python
import os
import tongWnB
from transformers import GPT2Tokenizer, GPT2LMHeadModel
from transformers import Trainer, TrainingArguments
from datasets import load_dataset

# 设置环境变量（也可以在 shell 中设置）
os.environ["TONGWNB_LAB_HOST"] = "http://your-lab-host.com"
os.environ["TONGWNB_API_KEY"] = "your_api_key"
os.environ["TONGWNB_COMPANY"] = "your_company"
os.environ["TONGWNB_PROJECT"] = "gpt2-finetuning"
os.environ["TONGWNB_EXPERIMENT"] = "baseline-exp"
os.environ["TONGWNB_GPUS"] = "0,1,2,3"

# 加载模型和数据
tokenizer = GPT2Tokenizer.from_pretrained('gpt2')
model = GPT2LMHeadModel.from_pretrained('gpt2')
dataset = load_dataset('wikitext', 'wikitext-2-raw-v1')

# 配置训练参数
training_args = TrainingArguments(
    output_dir='./results',
    num_train_epochs=3,
    per_device_train_batch_size=8,
    logging_steps=10,
    evaluation_strategy="steps",
    eval_steps=100,
    report_to="tongWnB",  # 使用 tongWnB
)

# 创建 Trainer 并训练
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=dataset['train'],
    eval_dataset=dataset['validation'],
)

trainer.train()
```

### 示例 2：分布式训练

```bash
# 使用 torchrun 进行分布式训练
export TONGWNB_LAB_HOST="http://your-lab-host.com"
export TONGWNB_API_KEY="your_api_key"
export TONGWNB_COMPANY="your_company"
export TONGWNB_PROJECT="distributed-training"
export TONGWNB_GPUS="0,1,2,3"

torchrun --nproc_per_node=4 train.py
```

训练脚本 `train.py` 内容相同，tongWnB 会自动检测分布式环境。

## 故障排查

### 问题 1：报错 "run is not initialized"

**原因**：tongWnB 未正确初始化。

**解决方案**：

- 检查环境变量是否正确设置
- 确保 `import tongWnB` 在代码开头
- 如果使用手动初始化，确保在训练前调用 `tongWnB.init()`

### 问题 2：指标未上传

**原因**：网络连接问题或配置错误。

**解决方案**：

- 检查 `TONGWNB_LAB_HOST` 是否可访问
- 检查 `TONGWNB_API_KEY` 是否有效
- 查看控制台错误信息

### 问题 3：`report_to="tongWnB"` 不生效

**原因**：集成未正确注册。

**解决方案**：

- 确保 `import tongWnB` 在代码开头（导入时会自动注册集成）
- 检查 transformers 版本是否支持（需要 4.x 及以上）

## 与 W&B 对比

| 特性             | W&B                 | tongWnB              |
| ---------------- | ------------------- | --------------------- |
| 自动记录训练指标 | ✅                  | ✅                    |
| 系统监控         | ✅                  | ✅                    |
| 指标分组         | ✅                  | ✅                    |
| 私有化部署       | ❌                  | ✅                    |
| 使用方式         | `report_to="wandb"` | `report_to="tongWnB"` |
| 需要手动结束     | `wandb.finish()`    | 自动完成              |

## 高级用法

### 自定义指标记录

你可以在训练过程中记录自定义指标：

```python
import tongWnB

# 在训练循环中的任何地方
tongWnB.log({
    "custom_metrics": {
        "perplexity": 12.5,
        "bleu_score": 0.85,
    }
})
```

### 混合使用多个平台

tongWnB 可以与其他日志平台同时使用：

```python
training_args = TrainingArguments(
    report_to=["tongWnB", "tensorboard"],  # 同时使用多个平台
    # ...
)
```

## 最佳实践

1. **使用环境变量配置**：方便在不同环境间切换
2. **合理设置 logging_steps**：太频繁会影响训练速度
3. **为实验取有意义的名称**：便于后续查找和对比
4. **记录重要的超参数**：使用 `experimentConfig` 参数
5. **在训练前验证配置**：确保能正常连接到 tongWnB 平台

## 更多信息

- 项目地址：https://github.com/your-org/tongWnB
- 文档地址：https://docs.tongWnB.com
- 问题反馈：https://github.com/your-org/tongWnB/issues
