# 🚀 多机 DDP 快速启动指南

## 一分钟快速启动

### 步骤 1：修改配置

编辑 `start_node0.sh` 和 `start_node1.sh`，修改 `MASTER_ADDR` 为服务器 1 的实际 IP：

```bash
MASTER_ADDR="你的服务器1的IP"  # 例如：192.168.1.100
```

### 步骤 2：在服务器 1（主节点）运行

```bash
./start_node0.sh
```

### 步骤 3：在服务器 2（从节点）运行

```bash
./start_node1.sh
```

## 验证 DDP 是否工作

看到以下输出说明 DDP 已成功启动：

**服务器 1：**

```
✓ DDP 配置:
  - RANK (全局进程编号): 0
  - WORLD_SIZE (总进程数): 2

🎉 DDP 初始化成功！
   当前节点是: 【主节点】

✓ Rank 0: DDP 模型创建成功！
  模型类型: DistributedDataParallel
```

**服务器 2：**

```
✓ DDP 配置:
  - RANK (全局进程编号): 1
  - WORLD_SIZE (总进程数): 2

🎉 DDP 初始化成功！
   当前节点是: 【从节点】

✓ Rank 1: DDP 模型创建成功！
  模型类型: DistributedDataParallel
```

## 文件说明

| 文件                         | 说明                       |
| ---------------------------- | -------------------------- |
| `tongWnB01_MultiNode_DDP.py` | 主训练脚本（显式使用 DDP） |
| `start_node0.sh`             | 服务器 1（主节点）启动脚本 |
| `start_node1.sh`             | 服务器 2（从节点）启动脚本 |
| `DDP_MULTINODE_GUIDE.md`     | 详细使用指南               |

## 关键 DDP 代码位置

脚本中显式使用 DDP 的位置：

1. **初始化进程组**（第 112 行）：

```python
dist.init_process_group(backend='nccl', init_method='env://')
```

2. **设置 GPU 设备**（第 119 行）：

```python
torch.cuda.set_device(local_rank)
```

3. **Trainer 自动应用 DDP**：
   - ⚠️ **重要**：不要手动用 DDP 包装模型
   - Trainer 会自动检测分布式环境并应用 DDP
   - Trainer 自动使用 DistributedSampler 分片数据
   - 训练时会看到 `model` 类型变为 `DistributedDataParallel`

## 常见问题速查

| 问题       | 解决方法               |
| ---------- | ---------------------- |
| 连接超时   | 检查防火墙端口 29500   |
| 地址已占用 | 修改 MASTER_PORT       |
| NCCL 错误  | 检查 CUDA 版本一致性   |
| 找不到脚本 | 检查两台服务器代码同步 |

## 检查清单

- [ ] 修改了 `MASTER_ADDR` 为实际 IP
- [ ] 两台服务器网络互通（可以 ping 通）
- [ ] 防火墙开放端口 29500
- [ ] 两台服务器代码一致
- [ ] 先启动服务器 1，再启动服务器 2

## 需要帮助？

查看详细文档：`DDP_MULTINODE_GUIDE.md`
