import os
import torch
from transformers import GPT2Tokenizer, GPT2LMHeadModel
from transformers import Trainer, TrainingArguments
from datasets import load_dataset
import torch.distributed as dist
import tongWnB


os.environ["TONGWNB_LAB_HOST"] = "http://10.10.1.84:30800"
os.environ["TONGWNB_NODE_IP"] = "10.10.1.84"
os.environ["TONGWNB_GPUS"] = "0"
os.environ["TONGWNB_API_KEY"] = "TSPQyMn14VKBI3M"
os.environ["TONGWNB_COMPANY"] = "公司hhh"
os.environ["TONGWNB_PROJECT"] = "pythonTest"
os.environ["TONGWNB_EXPERIMENT"] = "training02"

if dist.is_initialized():
    print(f"Current backend: {dist.get_backend()}")


def main():
    # 或者手动初始化（推荐用于开发测试）
    tongWnB.init(
        labHost="http://10.10.1.84:30800",
        nodeIP="10.10.1.84",
        gpus=[0],
        company="公司hhh",
        projectName="pythonTest",
        experimentName="training01",
        apiKey="TSPQyMn14VKBI3M",
        experimentConfig={
            "learning_rate": 1,
            "architecture": "MLP",
            "dataset": "MNIST",
            "epochs": 20,
        }
    )

    # Load the tokenizer and model
    tokenizer = GPT2Tokenizer.from_pretrained('gpt2')
    tokenizer.pad_token = tokenizer.eos_token  # 设置pad_token

    model = GPT2LMHeadModel.from_pretrained('gpt2')

    # Load the dataset
    dataset = load_dataset('wikitext', 'wikitext-2-raw-v1')

    def tokenize_function(examples):
        tokenized_output = tokenizer(examples['text'], truncation=True, padding='max_length', max_length=512)
        tokenized_output["labels"] = tokenized_output["input_ids"].copy()
        return tokenized_output

    tokenized_dataset = dataset.map(tokenize_function, batched=True, remove_columns=["text"])

    # Define training arguments
    training_args = TrainingArguments(
        output_dir='./results',
        overwrite_output_dir=True,
        num_train_epochs=1,
        per_device_train_batch_size=2,
        save_steps=500,  # 根据数据集大小调整
        save_total_limit=2,
        logging_dir='./logs',
        logging_steps=10,  # 日志输出频率
        evaluation_strategy="steps",  # 评估策略
        eval_steps=500,  # 评估间隔
        load_best_model_at_end=True,
        metric_for_best_model="loss",  # 选择最佳模型的指标
        report_to="tongWnB",  # 将日志报告到 tongWnB 平台
        ddp_find_unused_parameters=True  # 如果使用分布式数据并行（DDP），通常需要设为False
    )

    # Initialize the Trainer
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized_dataset['train'],
        eval_dataset=tokenized_dataset['validation'],
    )

    # Train the model
    trainer.train()

    # tongWnB 会自动完成记录，无需手动调用 finish()

if __name__ == "__main__":
    main()