"""
Transformers 集成模块，提供 TrainerCallback 支持。

该模块实现了与 Hugging Face Transformers 库的集成，
允许在训练过程中自动记录指标到 tongWnB 平台。
"""

from typing import Any, Dict

from .export import get_run


class TongWnBCallback:
    """
    tongWnB 的 Transformers Trainer 回调类。
    
    该回调类会在训练过程中自动记录各种指标到 tongWnB 平台，
    包括训练损失、验证损失、学习率、梯度范数等。
    
    重要：此回调类不负责创建实验，只负责记录日志。
    用户必须在创建 Trainer 之前手动调用 tongWnB.init() 初始化实验。
    
    使用方式：
        # 先初始化实验
        tongWnB.init(
            labHost="http://...",
            projectName="my_project",
            experimentName="my_experiment",
            ...
        )
        
        # 然后创建 Trainer，使用 report_to 参数
        training_args = TrainingArguments(
            report_to="tongWnB",
            ...
        )
        trainer = Trainer(model=model, args=training_args, ...)
    """

    def __init__(self):
        """
        初始化 TongWnBCallback。
        
        注意：此回调不接受任何参数，因为它只负责记录日志。
        实验的创建和配置应该通过 tongWnB.init() 完成。
        """
        self._initialized = False

    def setup(self, args, state, model, **kwargs):
        """
        在训练开始前设置 tongWnB。
        
        注意：此方法不负责创建实验，只检查是否已有活跃的 run。
        用户必须在创建 Trainer 之前手动调用 tongWnB.init() 初始化实验。
        
        Args:
            args: TrainingArguments
            state: TrainerState
            model: 模型实例
            **kwargs: 其他参数
            
        Raises:
            RuntimeError: 如果没有活跃的 tongWnB run
        """
        if self._initialized:
            return

        # 检查是否已经有活跃的 run
        existing_run = get_run()
        if existing_run is None:
            raise RuntimeError(
                "❌ 未找到活跃的 tongWnB run！\n"
                "请在创建 Trainer 之前先调用 tongWnB.init() 初始化实验。\n"
                "示例：\n"
                "  tongWnB.init(\n"
                "      labHost='...',\n"
                "      projectName='your_project',\n"
                "      experimentName='your_experiment',\n"
                "      ...\n"
                "  )\n"
                "  trainer = Trainer(...)"
            )
        
        self._initialized = True
        print(f"✅ tongWnB 已连接到活跃的实验")

    def on_log(self, args, state, control, logs=None, **kwargs):
        """
        在每次日志记录时调用，将指标发送到 tongWnB。
        
        Args:
            args: TrainingArguments
            state: TrainerState
            control: TrainerControl
            logs: 日志字典
            **kwargs: 其他参数
        """
        if not self._initialized:
            model = kwargs.pop("model", None)  # 从 kwargs 中移除 model，避免重复传递
            self.setup(args, state, model, **kwargs)

        if logs:
            # 过滤并组织指标
            metrics = self._organize_metrics(logs)
            
            if metrics:
                try:
                    run = get_run()
                    run.create_chart(metrics)
                except Exception as e:
                    print(f"⚠️ tongWnB 记录指标失败: {e}")

    def on_train_begin(self, args, state, control, **kwargs):
        """训练开始时的回调。"""
        if not self._initialized:
            model = kwargs.pop("model", None)  # 从 kwargs 中移除 model，避免重复传递
            self.setup(args, state, model, **kwargs)

    def on_train_end(self, args, state, control, **kwargs):
        """训练结束时的回调。"""
        if self._initialized:
            print("✅ 训练完成，tongWnB 记录已结束")

    def _organize_metrics(self, logs: Dict[str, Any]) -> Dict[str, Any]:
        """
        组织指标，将相关指标分组。
        
        Args:
            logs: 原始日志字典
            
        Returns:
            组织后的指标字典
        """
        organized = {}
        
        # 训练指标组
        train_metrics = {}
        # 验证指标组
        eval_metrics = {}
        # 其他指标（不分组）
        other_metrics = {}
        
        for key, value in logs.items():
            # 跳过非数值类型
            if not isinstance(value, (int, float)):
                continue
                
            # 分类指标
            if key.startswith("eval_"):
                # 验证指标
                metric_name = key.replace("eval_", "")
                eval_metrics[metric_name] = value
            elif key in ["loss", "grad_norm", "learning_rate"]:
                # 训练指标
                train_metrics[key] = value
            elif key not in ["epoch", "step"]:
                # 其他指标（不包括 epoch 和 step，因为这些由系统自动处理）
                other_metrics[key] = value
        
        # 组装最终指标
        if train_metrics:
            organized["training"] = train_metrics
        if eval_metrics:
            organized["evaluation"] = eval_metrics
        # 其他指标不分组
        organized.update(other_metrics)
        
        return organized
        

def is_transformers_available() -> bool:
    """
    检查是否安装了 transformers 库。
    
    Returns:
        bool: 如果安装了 transformers 返回 True，否则返回 False
    """
    try:
        import transformers  # noqa: F401
        return True
    except ImportError:
        return False


def _patch_transformers_integration():
    """
    修补 Transformers 集成，注册 tongWnB 为可用的集成。
    
    这个函数会在模块加载时自动调用，将 tongWnB 注册到
    Transformers 的集成列表中，使得 report_to="tongWnB" 可用。
    """
    if not is_transformers_available():
        return
    
    try:
        from transformers.integrations import INTEGRATION_TO_CALLBACK
        from transformers.trainer_callback import TrainerCallback
        
        # 创建一个适配器类，将我们的 TongWnBCallback 转换为 TrainerCallback
        class TongWnBTrainerCallback(TrainerCallback):
            """适配器类，使 TongWnBCallback 兼容 TrainerCallback 接口。"""
            
            def __init__(self):
                self._callback = TongWnBCallback()
            
            def on_train_begin(self, args, state, control, **kwargs):
                self._callback.on_train_begin(args, state, control, **kwargs)
            
            def on_log(self, args, state, control, logs=None, **kwargs):
                self._callback.on_log(args, state, control, logs, **kwargs)
            
            def on_train_end(self, args, state, control, **kwargs):
                self._callback.on_train_end(args, state, control, **kwargs)
        
        # 注册到 Transformers 集成系统
        INTEGRATION_TO_CALLBACK["tongWnB"] = TongWnBTrainerCallback
        
        # 也注册小写版本，以防用户使用小写
        INTEGRATION_TO_CALLBACK["tongwnb"] = TongWnBTrainerCallback
        
    except (ImportError, AttributeError) as e:
        # 如果注册失败，静默失败（用户仍可以手动使用回调）
        pass


# 在模块加载时自动注册集成
_patch_transformers_integration()

