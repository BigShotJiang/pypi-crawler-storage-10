# TongWnB 发布流程

## 📦 重新打包发布步骤

### 1. 更新版本号

编辑 `tongWnB/package.json` 文件：

```json
{
  "name": "tongWnB",
  "version": "1.0.1",  // 更新版本号
  "description": "",
  "python": "true"
}
```

### 2. 清理和构建

```bash
# 激活虚拟环境
source venv/bin/activate

# 清理旧的构建文件
rm -rf dist/ build/

# 重新构建包
python -m build
```

### 3. 配置PyPI认证

在发布之前，需要配置PyPI认证信息。有两种方式：

#### 方式1：使用 .pypirc 文件（推荐）

在用户主目录创建 `.pypirc` 文件：

```bash
# 创建.pypirc文件
cat > ~/.pypirc << EOF
[distutils]
index-servers = pypi

[pypi]
repository = https://upload.pypi.org/legacy/
username = __token__
password = pypi-AgEIcHlwaS5vcmcCJDUwOWMxMWNmLTNhYWItNDdlZC04NjNjLTFiMTM5YzYzYjE2NAACD1sxLFsidG9uZ3duYiJdXQACLFsyLFsiNWJjYTFhMWQtZGVkZC00YTNkLWFkY2ItNjcyYzhkNWIwOWE5Il1dAAAGICdgPjrP05rig_F5Au6nU2ovbRwpkirJtS6KARqg-6Ql
EOF

# 设置文件权限
chmod 600 ~/.pypirc
```

#### 方式2：使用环境变量

```bash
# 设置环境变量
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-你的API令牌
```

#### 获取PyPI API令牌

1. 登录 [PyPI官网](https://pypi.org)
2. 进入 Account settings > API tokens
3. 点击 "Add API token"
4. 选择作用域（推荐选择"Entire account"）
5. 创建令牌并复制保存

### 4. 发布到PyPI

```bash
# 发布到PyPI
twine upload dist/*
```

## 🔄 完整命令

```bash
# 一键发布脚本
source venv/bin/activate && \
rm -rf dist/ build/ && \
python -m build && \
twine upload dist/*
```

## ✅ 验证发布

发布成功后，可以测试安装：

```bash
# 在新环境中测试安装
python -m venv test_env
source test_env/bin/activate
pip install tongwnb==新版本号
python -c "import tongWnB; print('安装成功!')"
deactivate
rm -rf test_env
```

## 📝 注意事项

- 确保版本号遵循语义化版本规范 (major.minor.patch)
- 发布前建议先在本地测试功能
- 每次发布后记得更新README中的版本信息
- 如果需要发布预览版本，可以使用 `1.0.1rc1` 等格式
- `.pypirc` 文件包含敏感信息，不要提交到版本控制系统中
- API令牌具有完整的账户权限，请妥善保管
- 如果令牌泄露，请立即在PyPI官网撤销并重新生成
