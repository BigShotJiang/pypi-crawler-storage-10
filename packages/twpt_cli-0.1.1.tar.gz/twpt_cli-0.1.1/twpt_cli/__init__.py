"""ThreatWinds Pentest CLI - Python implementation."""

__version__ = "0.1.0"
__author__ = "ThreatWinds"
__email__ = "support@threatwinds.com"