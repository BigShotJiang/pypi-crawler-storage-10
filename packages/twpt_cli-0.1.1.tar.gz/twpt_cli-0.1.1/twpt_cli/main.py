#!/usr/bin/env python3
"""Main entry point for ThreatWinds Pentest CLI."""

import click
import sys
from pathlib import Path

from twpt_cli import __version__
from twpt_cli.commands import (
    init,
    configure,
    install_server,
    schedule_pentest,
    get_pentest,
    download_evidence,
    list_pentests,
    update,
    uninstall,
    version_cmd
)


@click.group(invoke_without_command=True)
@click.version_option(version=__version__, prog_name="twpt-cli")
@click.option(
    '--shell', '-s',
    is_flag=True,
    help='Start interactive shell mode'
)
@click.pass_context
def cli(ctx, shell):
    """ThreatWinds Pentest CLI - Manage containerized pentesting environments.

    This CLI tool helps you set up and manage automated penetration testing
    using ThreatWinds' containerized Kali Linux environment.

    Start without arguments or use --shell to enter interactive mode.
    """
    # Ensure context object exists
    ctx.ensure_object(dict)

    # If no command is given or shell flag is used, start interactive shell
    if ctx.invoked_subcommand is None or shell:
        from twpt_cli.shell import InteractiveShell
        shell = InteractiveShell()
        shell.run()
        sys.exit(0)


# Register all commands with both old and new names
cli.add_command(init.init)
cli.add_command(configure.configure)
cli.add_command(install_server.install_server)

# Add schedule-pentest with both names
cli.add_command(schedule_pentest.schedule_pentest)
cli.add_command(schedule_pentest.schedule_pentest, name="run")  # Alias

# Add get-pentest with both names
cli.add_command(get_pentest.get_pentest)
cli.add_command(get_pentest.get_pentest, name="get")  # Alias

# Add download-evidence with both names
cli.add_command(download_evidence.download_evidence)
cli.add_command(download_evidence.download_evidence, name="download")  # Alias

# Add list-pentests with both names
cli.add_command(list_pentests.list_pentests)
cli.add_command(list_pentests.list_pentests, name="list")  # Alias

cli.add_command(update.update_latest)
cli.add_command(uninstall.uninstall)
cli.add_command(version_cmd.version)


def main():
    """Main entry point for the CLI."""
    # Check if no arguments provided - start shell
    if len(sys.argv) == 1:
        # No arguments, start interactive shell
        from twpt_cli.shell import InteractiveShell
        shell = InteractiveShell()
        shell.run()
        sys.exit(0)

    try:
        cli()
    except KeyboardInterrupt:
        click.echo("\n\nOperation cancelled by user.", err=True)
        sys.exit(130)
    except Exception as e:
        click.echo(f"\nError: {e}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    main()