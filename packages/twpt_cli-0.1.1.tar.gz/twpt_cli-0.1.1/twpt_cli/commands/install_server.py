"""Install local server command for ThreatWinds Pentest CLI."""

import sys
import subprocess
from pathlib import Path

import click
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from twpt_cli.config import save_credentials, save_endpoint_config, clear_endpoint_config
from twpt_cli.docker import (
    is_docker_installed,
    install_docker_if_needed,
    pull_pentest_image,
    setup_container,
    is_container_running,
    container_exists,
    start_container
)

console = Console()

# Constants
CONTAINER_NAME = "twpt-agent"
IMAGE_NAME = "ghcr.io/threatwinds/twpt-agent:latest"
API_PORT = "9741"
GRPC_PORT = "9742"


@click.command(name='install-srv')
@click.option(
    '--api-key',
    help='API Key for ThreatWinds Pentest (required)'
)
@click.option(
    '--api-secret',
    help='API Secret for ThreatWinds Pentest (required)'
)
@click.option(
    '--skip-docker-install',
    is_flag=True,
    help='Skip Docker installation check (assumes Docker is already installed)'
)
@click.option(
    '--force',
    is_flag=True,
    help='Force reinstall even if server is already running'
)
def install_server(api_key: str, api_secret: str, skip_docker_install: bool, force: bool):
    """Install and configure local ThreatWinds Pentest server.

    This command will:
    1. Install Docker if needed (Linux only)
    2. Pull the ThreatWinds Pentest server container image
    3. Start the container locally
    4. Configure the CLI to use the local server
    5. Save API credentials

    The server will run as a Docker container named 'twpt-agent'
    and will be accessible at localhost:9741 (API) and localhost:9742 (gRPC).

    Examples:
        twpt-cli install-srv --api-key YOUR_KEY --api-secret YOUR_SECRET
        twpt-cli install-srv --api-key YOUR_KEY --api-secret YOUR_SECRET --force
    """
    console.print("\n╔════════════════════════════════════════════╗", style="cyan")
    console.print("║   ThreatWinds Pentest Server Installation  ║", style="cyan")
    console.print("╚════════════════════════════════════════════╝\n", style="cyan")

    # Check if already running
    if not force:
        if container_exists() and is_container_running():
            console.print("✓ ThreatWinds server is already running", style="green")
            console.print("\nIf you want to reinstall, use the --force flag", style="yellow")
            console.print("  twpt-cli install-srv --force", style="white")
            sys.exit(0)

    # Prompt for credentials if not provided
    if not api_key or not api_secret:
        console.print("[yellow]API credentials are required for the local server[/yellow]\n")
        if not api_key:
            api_key = console.input("Enter API/Pentest Key: ")
        if not api_secret:
            from rich.prompt import Prompt
            api_secret = Prompt.ask("Enter API/Pentest Secret", password=True, console=console)

    # Step 1: Check and install Docker
    if not skip_docker_install:
        console.print("\n[bold]Step 1:[/bold] Checking Docker installation...", style="blue")
        if not is_docker_installed():
            console.print("  ✗ Docker is not installed", style="red")
            console.print("\nPlease install Docker before continuing:", style="yellow")
            console.print("  Visit: https://docs.docker.com/get-docker/", style="white")
            console.print("\nOn macOS: Install Docker Desktop", style="dim")
            console.print("On Linux: Use 'install_docker_if_needed()' or install manually", style="dim")
            sys.exit(1)
        else:
            console.print("  ✓ Docker is installed", style="green")

        # Check if Docker daemon is running
        console.print("  Checking if Docker daemon is running...", style="blue")
        try:
            from twpt_cli.docker import get_docker_client
            get_docker_client()
            console.print("  ✓ Docker daemon is running", style="green")
        except Exception as e:
            console.print(f"  ✗ Docker daemon is not running", style="red")
            console.print(f"\n[yellow]Error: {e}[/yellow]")
            console.print("\nPlease start Docker and try again:", style="yellow")
            console.print("  • On macOS: Start Docker Desktop application", style="white")
            console.print("  • On Linux: Run 'sudo systemctl start docker'", style="white")
            console.print("\nThen run this command again.", style="dim")
            sys.exit(1)
    else:
        console.print("\n[bold]Step 1:[/bold] Skipping Docker installation check", style="dim")

    # Step 2: Pull Docker image
    console.print("\n[bold]Step 2:[/bold] Downloading ThreatWinds server image...", style="blue")
    console.print(f"  Image: {IMAGE_NAME}", style="dim")
    console.print("  This may take several minutes on first download...\n", style="dim")

    # Pull without Progress wrapper since pull_pentest_image has its own
    if not pull_pentest_image():
        console.print("\n✗ Failed to pull Docker image", style="red")
        console.print("Please check your internet connection and try again.", style="yellow")
        sys.exit(1)

    # Step 3: Setup and start container
    console.print("\n[bold]Step 3:[/bold] Setting up and starting container...", style="blue")

    if not setup_container():
        console.print("\n✗ Failed to setup container", style="red")
        console.print("Please check Docker logs for more details:", style="yellow")
        console.print("  docker logs twpt-agent", style="white")
        sys.exit(1)

    # Step 4: Save credentials
    console.print("\n[bold]Step 4:[/bold] Saving API credentials...", style="blue")

    try:
        save_credentials(api_key, api_secret)
        console.print("✓ API credentials saved", style="green")
    except Exception as e:
        console.print(f"✗ Failed to save credentials: {e}", style="red")
        sys.exit(1)

    # Step 5: Configure CLI to use local server
    console.print("\n[bold]Step 5:[/bold] Configuring CLI to use local server...", style="blue")

    try:
        # Clear any remote endpoint config to use localhost
        clear_endpoint_config()
        console.print("✓ CLI configured to use local server", style="green")
    except Exception as e:
        console.print(f"✗ Failed to configure CLI: {e}", style="red")
        sys.exit(1)

    # Success message
    console.print("\n╔════════════════════════════════════════════╗", style="green")
    console.print("║        Installation Completed!              ║", style="green bold")
    console.print("╚════════════════════════════════════════════╝\n", style="green")

    console.print("✓ The ThreatWinds Pentest server is running locally and ready to use!", style="green")
    console.print("\n[bold]Server Details:[/bold]", style="cyan")
    console.print(f"  • Container Name: {CONTAINER_NAME}", style="white")
    console.print(f"  • API Endpoint: http://localhost:{API_PORT}", style="white")
    console.print(f"  • gRPC Endpoint: localhost:{GRPC_PORT}", style="white")
    console.print(f"  • Status: [green]Running[/green]")

    console.print("\n[bold]Quick Start:[/bold]", style="cyan")
    console.print("  twpt-cli                                    # Start interactive shell", style="white")
    console.print("  twpt-cli run --target example.com           # Run a pentest", style="white")
    console.print("  twpt-cli list                               # List pentests", style="white")

    console.print("\n[bold]Server Management:[/bold]", style="cyan")
    console.print("  docker stop twpt-agent                      # Stop the server", style="white")
    console.print("  docker start twpt-agent                     # Start the server", style="white")
    console.print("  docker logs twpt-agent                      # View server logs", style="white")
    console.print("  twpt-cli uninstall --remove-data            # Uninstall everything\n", style="white")
