from bella_companion.eucovid.run_beast import run_beast

__all__ = ["run_beast"]
