# Documentation

The `greeter` component is responsible for providing a friendly greeting message.

````{spec} Greeting nicely
:id: SWDD_G-100

Depending on the selected language, the greeting message may be translated accordingly.

For English:

```c
printf("Hello, World!\n");
```

````
