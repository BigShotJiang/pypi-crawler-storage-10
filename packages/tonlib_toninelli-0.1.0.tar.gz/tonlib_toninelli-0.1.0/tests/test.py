from fastapi.responses import JSONResponse

from tonlib.fastapi.response_helper import ok


def test_ok_response_schema():
    resp = ok({"x": 1})
    assert isinstance(resp, JSONResponse)
    # body = resp.body.decode("utf-8")
    # assert '"data": {"x": 1}' in body
    # assert '"error": null' in body