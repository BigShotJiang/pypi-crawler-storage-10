# Prac TSEC SP

AI algorithm implementations package. Install and check your venv/lib folder for all source codes.

## Installation

```bash
pip install prac-tsec-sp
```

## Usage

After installation, you can find all the source code in your virtual environment's `lib` folder:

```
your_venv/lib/python3.x/site-packages/prac_tsec_sp/
```

### Available Algorithms

- **A* Search**: Pathfinding algorithm with visualization
- **Alpha-Beta Pruning**: Minimax algorithm optimization
- **Graph Traversal**: BFS and DFS implementations

### Quick Import

```python
from prac_tsec_sp import Node, a_star, bfs, dfs, alpha_beta_pruning
```

## Requirements

- Python >= 3.8
- matplotlib >= 3.5.0
- networkx >= 2.6

## License

MIT License

## Author

**shreyas pansare**
- Email: shreyaspansare123@gmail.com