class Node:
    def __init__(self, value):
        self.next = None
        self.value = value


class LinkedList:
    def __init__(self, array=None):
        self.head: Node | None = None
        if array:
            for value in array:
                self.append(value)


    def append(self, value):
        node = Node(value)
        if self.head is None:
            self.head = node
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = node

    def delete(self, value) -> None | Node:
        current = self.head
        previous = None
        while current:
            if current.value == value:
                if previous is None:
                    self.head = current.next
                    return current
                previous.next = current.next
                return current
            previous = current
            current = current.next
        return None

    def display(self):
        print("START THE LINKED LIST")
        current = self.head
        while current:
            print(current.value)
            current = current.next
        print("END THE LINKED LIST")

    def find(self, value) -> bool:
        current = self.head
        while current:
            if current.value == value:
                return True
            current = current.next
        return False

    def prepend(self, value):
        node = Node(value)
        node.next = self.head
        self.head = node

    def __iter__(self):
        current = self.head
        while current:
            yield current.value
            current = current.next

    def __repr__(self):
        return " -> ".join(str(v) for v in self) + " -> None"

    def __len__(self):
        return sum(1 for _ in self)

    def reverse(self):
        return reverse_linked_list(self)

def reverse_linked_list(linked_list):
    prev = None
    current = linked_list.head
    next_node = linked_list.head.next
    while current:
        next_node = current.next
        current.next = prev
        prev = current
        current = next_node

    linked_list.head = prev
    return linked_list