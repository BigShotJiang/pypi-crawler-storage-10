# model_explain/explainers/text_explainer.py

"""
This module provides text explanation capabilities for classification models
using LIME and SHAP.

Features:
- Use LIME for local explanations of individual text instances.
- Use SHAP for token-level importance visualization, especially for Transformer models.

Author:
    Vaibhav Kulshrestha

Date:
    2025-10-27
"""

# Import necessary libraries
import shap
from lime.lime_text import LimeTextExplainer


class TextExplainer:
    """
    Explain text classification models using LIME and SHAP.

    Attributes:
    model (torch.nn.Module): The classification model to explain.
    class_names (list[str]): Names of target classes.
    lime_explainer (LimeTextExplainer): LIME text explainer instance.
    """

    def __init__(self, model, class_names=None):
        """
        Initialize the TextExplainer with a model and class names.

        :param model: Model implementing `predict` or `predict_proba`.
                      For Transformers, pass a HuggingFace model and tokenizer.
        :type model: torch.nn.Module
        :param class_names: Names of target classes.
        :type class_names: list of str, optional
        """
        self.model = model
        self.class_names = class_names
        self.lime_explainer = LimeTextExplainer(class_names=class_names)

    # ---------------------------------------------------------------
    # LIME EXPLANATION
    # ---------------------------------------------------------------
    def explain_lime(self, text, num_features=10):
        """
        Explain a single text instance using LIME.

        :param text: The text input to explain.
        :type text: str
        :param num_features: Number of words to highlight.
        :type num_features: int
        :return: LIME explanation object.
        :rtype: lime.explanation.Explanation
        """
        try:
            pred_func = getattr(self.model, "predict_proba", self.model.predict)
        except Exception as e:
            raise ValueError(f"Model must have predict or predict_proba: {e}")

        exp = self.lime_explainer.explain_instance(
            text, pred_func, num_features=num_features
        )
        exp.show_in_notebook(text=True)
        return exp

    # ---------------------------------------------------------------
    # SHAP EXPLANATION
    # ---------------------------------------------------------------
    def explain_shap(self, texts, tokenizer=None):
        """
        Explain one or more text inputs using SHAP.

        :param texts: List of text inputs to explain.
        :type texts: list of str
        :param tokenizer: Tokenizer for Transformer models (e.g., HuggingFace tokenizer).
                          If None, uses model's predict or predict_proba method.
        :type tokenizer: object, optional
        :return: SHAP values object.
        :rtype: shap.Explanation
        """
        if tokenizer:

            def f(x):
                import torch

                inputs = tokenizer(
                    list(x), return_tensors="pt", padding=True, truncation=True
                )
                with torch.no_grad():
                    outputs = self.model(**inputs)
                return outputs.logits.detach().numpy()

        else:
            f = getattr(self.model, "predict_proba", None)
            if f is None:
                f = getattr(self.model, "predict", None)
            if f is None or not callable(f):
                raise ValueError(
                    "Model must have a callable 'predict' or 'predict_proba' method."
                )

        explainer = shap.Explainer(f, shap.maskers.Text())
        shap_values = explainer(texts)
        shap.plots.text(shap_values[0])
        return shap_values
