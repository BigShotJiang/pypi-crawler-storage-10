"""
Unit tests for TextExplainer class in model_explain.explainers.text_explainer module.

Covers:
- LIME explanation (mock model with predict_proba)
- SHAP explanation (mock model, with and without tokenizer)
- Error handling for invalid models

Author:
    Vaibhav Kulshrestha

Date:
    2025-10-27
"""

from unittest.mock import MagicMock, patch

import numpy as np
import pytest

from model_explain.explainers.text_explainer import TextExplainer


# ---------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------


class DummyModel:
    """
    Simple dummy model for testing LIME/SHAP APIs.
    """

    def predict_proba(self, texts):
        """
        Dummy predict_proba method.

        :param texts: List of text inputs.
        :type texts: list of str
        :return: 2D array of probabilities for each class.
        :rtype: np.ndarray
        """
        # Return fake probabilities [p(neg), p(pos)]
        probs = np.array([[0.2, 0.8] for _ in texts])
        return probs

    def predict(self, texts):
        """
        Dummy predict method.

        :param texts: List of text inputs.
        :type texts: list of str
        :return: Predicted class labels.
        :rtype: np.ndarray
        """
        return np.array([1 for _ in texts])


@pytest.fixture
def dummy_model():
    """
    Fixture for a dummy classification model.

    :return: DummyModel instance.
    :rtype: DummyModel
    """
    return DummyModel()


@pytest.fixture
def sample_texts():
    """
    Fixture for sample text inputs.

    :return: List of sample texts.
    :rtype: list of str
    """
    return ["This movie was great!", "I did not like the plot."]


# ---------------------------------------------------------------------
# Tests for LIME explanation
# ---------------------------------------------------------------------


@patch("lime.lime_text.LimeTextExplainer.explain_instance")
def test_explain_lime_returns_explanation(mock_explain_instance, dummy_model):
    """
    Test that explain_lime returns a LIME explanation object.

    :param mock_explain_instance: Mocked explain_instance method.
    :param dummy_model: Dummy classification model.
    :type mock_explain_instance: MagicMock
    :type dummy_model: DummyModel
    """
    mock_explain = MagicMock()
    mock_explain_instance.return_value = mock_explain

    explainer = TextExplainer(dummy_model, class_names=["neg", "pos"])
    result = explainer.explain_lime("Good movie", num_features=5)

    mock_explain_instance.assert_called_once()
    assert result == mock_explain


def test_explain_lime_invalid_model():
    """
    Test that explain_lime raises ValueError for invalid model.
    """

    class BadModel:
        pass

    explainer = TextExplainer(BadModel())
    with pytest.raises(ValueError):
        explainer.explain_lime("Some text")


# ---------------------------------------------------------------------
# Tests for SHAP explanation
# ---------------------------------------------------------------------


@patch("shap.Explainer")
@patch("shap.plots.text")
def test_explain_shap_with_predict_proba(
    mock_plot, mock_explainer, dummy_model, sample_texts
):
    """
    Test SHAP explanation when model has predict_proba method.
    :param mock_plot: Mocked SHAP text plot function.
    :type mock_plot: MagicMock
    :param mock_explainer: Mocked SHAP Explainer class.
    :type mock_explainer: MagicMock
    :param dummy_model: Dummy classification model.
    :type dummy_model: DummyModel
    :param sample_texts: Sample text inputs.
    :type sample_texts: list of str
    """
    # Mock SHAP explainer output
    mock_shap_values = MagicMock()
    mock_explainer.return_value = lambda texts: mock_shap_values

    explainer = TextExplainer(dummy_model)
    result = explainer.explain_shap(sample_texts)

    mock_explainer.assert_called_once()
    mock_plot.assert_called_once()
    assert result == mock_shap_values


@patch("torch.no_grad")
@patch("shap.Explainer")
@patch("shap.plots.text")
def test_explain_shap_with_tokenizer(
    mock_plot, mock_explainer, dummy_model, sample_texts
):
    """
    Test SHAP explanation when a tokenizer is provided.

    :param mock_plot: Mocked SHAP text plot function.
    :type mock_plot: MagicMock
    :param mock_explainer: Mocked SHAP Explainer class.
    :type mock_explainer: MagicMock
    :param dummy_model: Dummy classification model.
    :type dummy_model: DummyModel
    :param sample_texts: Sample text inputs.
    :type sample_texts: list of str
    """
    mock_shap_values = MagicMock()
    mock_explainer.return_value = lambda texts: mock_shap_values

    # Mock tokenizer
    mock_tokenizer = MagicMock()
    mock_tokenizer.side_effect = lambda texts, **_: {
        "input_ids": [1],
        "attention_mask": [1],
    }

    # Mock model.forward to return dummy logits
    import torch

    dummy_output = MagicMock()
    dummy_output.logits = torch.tensor([[0.1, 0.9]])
    dummy_model.__call__ = MagicMock(return_value=dummy_output)
    dummy_model.forward = MagicMock(return_value=dummy_output)

    explainer = TextExplainer(dummy_model)
    result = explainer.explain_shap(sample_texts, tokenizer=mock_tokenizer)

    mock_explainer.assert_called_once()
    mock_plot.assert_called_once()
    assert result == mock_shap_values


def test_explain_shap_invalid_model():
    """
    Test that explain_shap raises ValueError for invalid model.
    :raise: ValueError: If model lacks predict or predict_proba method.
    """

    class InvalidModel:
        pass

    explainer = TextExplainer(InvalidModel())
    with pytest.raises(ValueError):
        explainer.explain_shap(["some text"])


def main():
    pytest.main([__file__])


if __name__ == "__main__":
    main()
