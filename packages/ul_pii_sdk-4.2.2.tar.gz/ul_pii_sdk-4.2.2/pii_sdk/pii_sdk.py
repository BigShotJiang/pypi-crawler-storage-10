import json
from uuid import UUID
from typing import List

from ul_api_utils.internal_api.internal_api import InternalApi
from ul_api_utils.internal_api.internal_api_response import InternalApiResponse

from pii_sdk.pii_sdk_config import PiiSdkConfig
from pii_sdk.types.api_ogranization import ApiOrganization, ApiOrganizationAvailableEvents, ApiOrganizationSendCriticalEventsEmailResponse
from pii_sdk.utils.internal_api_error_handler import internal_api_error_handler


class PiiSdk:
    def __init__(self, config: PiiSdkConfig) -> None:
        self._config = config
        self._api = InternalApi(self._config.api_url, default_auth_token=self._config.api_token)

    @internal_api_error_handler
    def get_organization_by_id(self, organization_id: UUID) -> InternalApiResponse[ApiOrganization]:
        return self._api.request_get(f'/organizations/{organization_id}').typed(ApiOrganization).check()

    @internal_api_error_handler
    def get_organization_by_name(self, organization_name: str) -> InternalApiResponse[List[ApiOrganization]]:       # type: ignore
        return self._api.request_get(
            '/organizations',
            q={"filter": '[{"name":"organization_data","op":"has","val":{"name":"name","op": "==","val": "%s"}}]' % organization_name},
        ).typed(List[ApiOrganization]).check()

    @internal_api_error_handler
    def get_organizations_by_id_list(self, organization_ids: List[UUID]) -> InternalApiResponse[List[ApiOrganization]]:     # type: ignore
        organization_ids_str = json.dumps([str(org_id) for org_id in organization_ids])
        return self._api.request_get(
            '/organizations',
            q={"filter": '[{"name":"id","op": "in","val": %s}]' % organization_ids_str},
        ).typed(List[ApiOrganization]).check()

    @internal_api_error_handler
    def get_organizations(self) -> InternalApiResponse[List[ApiOrganization]]:      # type: ignore
        return self._api.request_get('/organizations').typed(List[ApiOrganization]).check()

    @internal_api_error_handler
    def get_organizations_available_events(self, organization_id: UUID) -> InternalApiResponse[ApiOrganizationAvailableEvents]:
        return self._api.request_get(f'/organizations/{organization_id}/available_events').typed(ApiOrganizationAvailableEvents).check()

    @internal_api_error_handler
    def send_critical_events_email(
        self,
        organization_id: UUID,
        organization_name: str,
        abnormal_event_objects: list[str],
        other_critical: list[str] | None = None,
    ) -> InternalApiResponse[ApiOrganizationSendCriticalEventsEmailResponse]:
        """
        Отправляет письма о критических событиях всем актуальным пользователям организации.
        organization_id: UUID организации, в которой делается рассылка
        organization_name: строка, имя организации (опционально)
        abnormal_event_objects: список объектов с аномалиями
        other_critical: список иных критических уведомлений (опционально)
        Возвращает: InternalApiResponse[ApiOrganizationSendCriticalEventsEmailResponse]
        """
        data = {
            "organization_name": organization_name,
            "abnormal_event_objects": abnormal_event_objects,
        }
        if other_critical is not None:
            data["other_critical"] = other_critical
        return self._api.request_post(
            f"/organizations/{organization_id}/send-critical-events-email",
            json={
                "organization_name": organization_name,
                "abnormal_event_objects": abnormal_event_objects,
                "other_critical": other_critical,
            }
        ).typed(ApiOrganizationSendCriticalEventsEmailResponse).check()
