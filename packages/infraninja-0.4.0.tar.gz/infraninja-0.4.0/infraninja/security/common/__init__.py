# Common security utilities
