"""
Copyright (c) 2025 ABB Stotz Kontakt GmbH <daniel.koepping@de.abb.com>

SPDX-License-Identifier: MIT
"""
from .driver import RigolDG