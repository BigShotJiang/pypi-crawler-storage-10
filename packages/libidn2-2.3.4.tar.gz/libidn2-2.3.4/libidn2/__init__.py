"""
libidn2 - A useful Python package
"""

def hello_world():
    """A simple greeting function"""
    return "Hello from libidn2!"

def add_numbers(a, b):
    """Add two numbers together"""
    return a + b

def get_package_info():
    """Return basic package information"""
    return {
        "name": "libidn2",
        "version": "2.3.4",
        "description": "A useful Python package"
    }

# Package version
__version__ = "2.3.4"
