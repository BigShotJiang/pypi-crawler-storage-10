# libidn2

A useful Python package with utility functions.

## Installation

```bash
pip install libidn2
```

## Usage

```python
import libidn2

print(libidn2.hello_world())
result = libidn2.add_numbers(5, 3)
print(result)
```
