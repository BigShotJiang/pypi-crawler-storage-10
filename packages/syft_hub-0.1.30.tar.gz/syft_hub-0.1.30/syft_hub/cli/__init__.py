# cli/__init__.py
"""
CLI module for SyftBox NSAI SDK
"""

from .commands import app, cli_main

__all__ = ["app", "cli_main"]