@ECHO OFF

pushd %~dp0

REM Command file for Sphinx documentation

set SPHINXBUILD=sphinx-build
set SOURCEDIR=.
set BUILDDIR=_build

if "%1" == "" goto help

%SPHINXBUILD% >NUL 2>NUL
if errorlevel 9009 (
	echo.
	echo.The Sphinx module was not found. Make sure you have Sphinx installed,
	echo.then set the SPHINXBUILD variable to point to the full path of the
	echo.``sphinx-build`` executable. Alternatively you may add the Sphinx
	echo.directory to PATH.
	echo.
	echo.If you don't have Sphinx installed, grab it from
	echo.https://sphinx-doc.org/
	exit /b 1
)

%SPHINXBUILD% -M %1 %SOURCEDIR% %BUILDDIR% %*
goto end

:help
%SPHINXBUILD% -M help %SOURCEDIR% %BUILDDIR% %*

:end
popd

