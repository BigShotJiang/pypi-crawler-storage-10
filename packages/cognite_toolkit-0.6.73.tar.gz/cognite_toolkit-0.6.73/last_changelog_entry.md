## cdf 

### Fixed

- [alpha] Change the data model deployed with `cdf migrate prepare`.

## templates

No changes.