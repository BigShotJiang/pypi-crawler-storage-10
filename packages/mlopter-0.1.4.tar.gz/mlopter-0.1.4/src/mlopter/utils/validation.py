# mlopt/utils/validation.py
from __future__ import annotations

from typing import Iterable, Set, Tuple, List

from ..core.model import Model
from ..core.variables import Var as ModelVar
from ..core.constraints import Constraint
from ..core.objective import Objective


class ValidationError(ValueError):
    pass


def validate_model_basic(m: Model) -> None:
    """
    Basic validation for a modeling container before sending to a solver.

    Checks
    ------
    - At least one variable exists.
    - Objective is set.
    - Constraints reference only declared variables.
    - Variable categories and bounds are consistent.
    - No duplicate variable names.
    """
    # Variables present
    if not m.vars:
        raise ValidationError("Model has no variables. Add variables before solving.")

    # Objective present
    if m.objective is None:
        raise ValidationError("Objective is not set.")

    # Duplicate names
    names: List[str] = list(m.vars.keys())
    if len(set(names)) != len(names):
        raise ValidationError("Duplicate variable names detected.")

    # Variable bounds and categories
    for v in m.vars.values():
        if v.cat not in ("Continuous", "Integer", "Binary"):
            raise ValidationError(f"Unknown variable category for '{v.name}': {v.cat}")
        if v.up is not None and v.low is not None and v.up < v.low:
            raise ValidationError(f"Upper bound < lower bound for variable '{v.name}'")
        if v.cat == "Binary":
            # Optional: bounds consistency for binaries
            if v.low is not None and v.low > 1:
                raise ValidationError(f"Binary variable '{v.name}' has low bound > 1")
            if v.up is not None and v.up < 0:
                raise ValidationError(f"Binary variable '{v.name}' has up bound < 0")

    # Expressions variables exist
    def _vars_in_linexpr(expr) -> Set[str]:
        return set(v.name for v in expr.coeffs.keys())

    used_in_obj = _vars_in_linexpr(m.objective.expr)
    unknown_in_obj = used_in_obj.difference(m.vars.keys())
    if unknown_in_obj:
        raise ValidationError(f"Objective references unknown variables: {sorted(unknown_in_obj)}")

    for c in m.constraints:
        used_in_c = _vars_in_linexpr(c.lhs)
        unknown_in_c = used_in_c.difference(m.vars.keys())
        if unknown_in_c:
            raise ValidationError(
                f"Constraint '{c.name}' references unknown variables: {sorted(unknown_in_c)}"
            )
        if c.sense not in ("<=", ">=", "=="):
            raise ValidationError(f"Constraint '{c.name}' has invalid sense: {c.sense}")


def validate_readiness_for_solver(m: Model) -> None:
    """
    Call before invoking a solver to catch common modeling mistakes early.
    """
    validate_model_basic(m)

    # Additional checks can be added here, e.g., integrality checks for certain solvers,
    # or specific domain constraints required by backend integrations.


def summary(m: Model) -> str:
    """
    Produce a short, human-readable model summary for logs.
    """
    n_bin = sum(1 for v in m.vars.values() if v.cat == "Binary")
    n_int = sum(1 for v in m.vars.values() if v.cat == "Integer")
    n_cont = sum(1 for v in m.vars.values() if v.cat == "Continuous")
    n_cons = len(m.constraints)
    obj_dir = m.objective.direction if m.objective else "<unset>"
    return (
        f"Model(name={m.name}, vars={len(m.vars)} "
        f"[bin={n_bin}, int={n_int}, cont={n_cont}], "
        f"constraints={n_cons}, objective={obj_dir})"
    )
