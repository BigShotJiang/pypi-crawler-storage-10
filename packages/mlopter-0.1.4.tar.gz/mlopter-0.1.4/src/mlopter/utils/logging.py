# mlopt/utils/logging.py
from __future__ import annotations

import logging
import os
from typing import Optional


DEFAULT_LEVEL = os.getenv("MLOPT_LOG_LEVEL", "INFO").upper()
DEFAULT_FORMAT = "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
DEFAULT_DATEFMT = "%Y-%m-%d %H:%M:%S"


def get_logger(name: str, level: Optional[str] = None) -> logging.Logger:
    """
    Create or retrieve a namespaced logger with sensible defaults.

    Parameters
    ----------
    name : str
        Logger name, typically __name__ from the caller module.
    level : Optional[str]
        Log level name (e.g., "DEBUG", "INFO"). If None, reads MLOPT_LOG_LEVEL
        from the environment or defaults to INFO.

    Returns
    -------
    logging.Logger
        Configured logger instance.
    """
    logger = logging.getLogger(name)

    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(fmt=DEFAULT_FORMAT, datefmt=DEFAULT_DATEFMT)
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        # Avoid duplicate logs if root has handlers
        logger.propagate = False

    lvl = (level or DEFAULT_LEVEL).upper()
    try:
        logger.setLevel(getattr(logging, lvl))
    except Exception:
        logger.setLevel(logging.INFO)

    return logger


def set_global_level(level: str) -> None:
    """
    Set global logging level for the root logger and all existing mlopt loggers.
    """
    lvl = getattr(logging, level.upper(), logging.INFO)
    logging.getLogger().setLevel(lvl)
    # Also set for mlopt namespace if present
    logging.getLogger("mlopt").setLevel(lvl)


def enable_debug() -> None:
    set_global_level("DEBUG")


def disable_debug() -> None:
    set_global_level("INFO")
