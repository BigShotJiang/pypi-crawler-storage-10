# mlopt/__init__.py
"""
mlopt: Machine-learning enhanced optimization with pluggable solvers.
Public API re-exports core modeling primitives, solvers registry, and common solvers.
"""

from importlib.metadata import version as _pkg_version

try:
    __version__ = _pkg_version("mlopt")
except Exception:
    # Fallback for editable installs before metadata is available
    __version__ = "0.0.0"

# Public API: core modeling
from .core.model import Model
from .core.variables import Var
from .core.expressions import LinExpr
from .core.constraints import Constraint
from .core.objective import Objective

# Public API: solvers and registry
from .core.registry import SolverRegistry
from .solvers.base import SolveResult
from .solvers.pulp_cbc import PuLPCBC
from .solvers.meta_ga import GeneticSolver
from .solvers.bayesopt import BayesianOpt

# Public API: ML helpers
from .ml.surrogate import SurrogateModel
from .ml.learning_hints import LearningHints

__all__ = [
    "Model",
    "Var",
    "LinExpr",
    "Constraint",
    "Objective",
    "SolveResult",
    "SolverRegistry",
    "PuLPCBC",
    "GeneticSolver",
    "BayesianOpt",
    "SurrogateModel",
    "LearningHints",
    "__version__",
]
