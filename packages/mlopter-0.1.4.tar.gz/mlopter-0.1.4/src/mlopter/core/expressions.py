# expressions.py
from __future__ import annotations
from typing import Dict, Union

# Minimal Var identity for expressions; the full Var lives in variables.py.
# This is only to allow LinExpr to use Var as dict keys safely.
class Var:
    def __init__(self, name: str):
        self.name = name

    def __hash__(self) -> int:
        return hash(self.name)

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Var) and self.name == other.name

    def __repr__(self) -> str:
        return f"Var({self.name})"


Number = Union[int, float]


class LinExpr:
    def __init__(self, coeffs: Dict[Var, float], const: float = 0.0):
        self.coeffs: Dict[Var, float] = dict(coeffs)
        self.const: float = float(const)

    def __add__(self, other: Union["LinExpr", Number]) -> "LinExpr":
        if isinstance(other, LinExpr):
            out = dict(self.coeffs)
            for v, c in other.coeffs.items():
                out[v] = out.get(v, 0.0) + c
            return LinExpr(out, self.const + other.const)
        return LinExpr(dict(self.coeffs), self.const + float(other))

    __radd__ = __add__

    def __mul__(self, k: Number) -> "LinExpr":
        kf = float(k)
        return LinExpr({v: c * kf for v, c in self.coeffs.items()}, self.const * kf)

    __rmul__ = __mul__

    def __sub__(self, other: Union["LinExpr", Number]) -> "LinExpr":
        if isinstance(other, LinExpr):
            return self + (-1.0) * other
        return self + (-float(other))

    def copy(self) -> "LinExpr":
        return LinExpr(dict(self.coeffs), self.const)

    def __repr__(self) -> str:
        terms = [f"{c}*{v.name}" for v, c in self.coeffs.items()]
        s = " + ".join(terms) if terms else "0"
        if self.const:
            s += f" + {self.const}"
        return f"LinExpr({s})"
