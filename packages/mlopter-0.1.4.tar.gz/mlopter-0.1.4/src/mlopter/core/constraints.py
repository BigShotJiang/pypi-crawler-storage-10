# constraints.py
from __future__ import annotations
from typing import Literal
from .expressions import LinExpr

Sense = Literal["<=", ">=", "=="]


class Constraint:
    def __init__(self, lhs: LinExpr, sense: Sense, rhs: float, name: str = ""):
        if sense not in ("<=", ">=", "=="):
            raise ValueError(f"Invalid sense: {sense}")
        self.lhs = lhs
        self.sense = sense
        self.rhs = float(rhs)
        self.name = name or "c"

    def __repr__(self) -> str:
        return f"Constraint({self.name}: {self.lhs} {self.sense} {self.rhs})"
