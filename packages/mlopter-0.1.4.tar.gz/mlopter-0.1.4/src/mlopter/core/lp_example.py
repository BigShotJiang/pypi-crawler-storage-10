# examples/lp_example.py

from .model import Model
from .objective import Objective
from .constraints import Constraint
from .registry import SolverRegistry

def main():
    m = Model("diet_like")

    x1 = m.add_var("x1", low=0)
    x2 = m.add_var("x2", low=0)

    # min 3 x1 + 2 x2
    obj = m.linexpr({x1: 3.0, x2: 2.0})
    m.set_objective(Objective(obj, direction="min"))

    # constraints
    m.add_constraint(Constraint(m.linexpr({x1: 2.0, x2: 1.0}), "<=", 100, name="c1"))
    m.add_constraint(Constraint(m.linexpr({x1: 1.0, x2: 1.0}), ">=", 50, name="c2"))

    solver = SolverRegistry.create("pulp_cbc")
    m.set_solver(solver)

    res = m.solve()
    print(f"status={res.status} obj={res.obj:.6f} solver={res.solver_name} x={res.x}")

    if res.status not in ("Optimal", "Heuristic", "Converged"):
        raise SystemExit(f"Unexpected solve status: {res.status}")

if __name__ == "__main__":
    main()
