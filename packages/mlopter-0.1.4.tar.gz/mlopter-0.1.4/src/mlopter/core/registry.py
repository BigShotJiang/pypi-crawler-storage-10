# mlopt/plugins/registry.py
from __future__ import annotations
from typing import Dict, Type
from ..solvers.base import SolverBase

class SolverRegistry:
    _solvers: Dict[str, Type[SolverBase]] = {}

    @classmethod
    def register(cls, name: str, solver_cls: Type[SolverBase]):
        cls._solvers[name] = solver_cls

    @classmethod
    def create(cls, name: str, **kwargs) -> SolverBase:
        if name not in cls._solvers:
            raise KeyError(f"Unknown solver '{name}'")
        return cls._solvers[name](**kwargs)

# bootstrap registrations
from ..solvers.pulp_cbc import PuLPCBC
from ..solvers.meta_ga import GeneticSolver
from ..solvers.bayesopt import BayesianOpt
SolverRegistry.register("pulp_cbc", PuLPCBC)
SolverRegistry.register("genetic", GeneticSolver)
SolverRegistry.register("bayesopt", BayesianOpt)
