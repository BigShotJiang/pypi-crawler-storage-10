# examples/bayes_example.py

from typing import Dict
from .model import Model
from .objective import Objective
from .constraints import Constraint
from .registry import SolverRegistry

def black_box(assign: Dict[str, float]) -> float:
    x1 = assign["x1"]
    x2 = assign["x2"]
    # f(x) = (x1 - 2)^2 + (x2 - 3)^2
    return (x1 - 2.0) ** 2 + (x2 - 3.0) ** 2

def penalty_with_constraints(m: Model, assign: Dict[str, float]) -> float:
    # Compute constraint penalty
    penalty = 0.0
    for c in m.constraints:
        lhs = sum(coef * assign[v.name] for v, coef in c.lhs.coeffs.items()) + c.lhs.const
        if c.sense == "<=" and lhs > c.rhs:
            penalty += (lhs - c.rhs) ** 2
        elif c.sense == ">=" and lhs < c.rhs:
            penalty += (c.rhs - lhs) ** 2
        elif c.sense == "==" and abs(lhs - c.rhs) > 1e-12:
            penalty += (lhs - c.rhs) ** 2
    return black_box(assign) + 1e3 * penalty

def main():
    m = Model("black_box")

    x1 = m.add_var("x1", low=0.0, up=5.0)
    x2 = m.add_var("x2", low=0.0, up=5.0)

    # Dummy linear objective as placeholder; Bayesian solver will use the callable
    m.set_objective(Objective(m.linexpr({}, 0.0), direction="min"))
    # Optional trivial constraint example; keep domain via var bounds primarily
    m.add_constraint(Constraint(m.linexpr({}, 0.0), ">=", 0.0, name="noop"))

    # Prefer to use the BayesianOpt solver which expects to evaluate via callback
    solver = SolverRegistry.create("bayesopt", n_calls=25, random_state=42)

    # If your BayesianOpt adapter supports passing a callable, call it here.
    # Otherwise, you can temporarily monkey-patch the solver or model.
    try:
        # Assuming the solver exposes a simple API: solve_with_callable(model, fn)
        res = solver.solve_with_callable(  # type: ignore[attr-defined]
            m, lambda a: penalty_with_constraints(m, a)
        )
    except AttributeError:
        # Fallback: attach the callable to the model for the solver to find.
        # Your BayesianOpt.solve() should look for model._black_box when present.
        setattr(m, "_black_box", lambda a: penalty_with_constraints(m, a))
        res = solver.solve(m)

    print(f"status={res.status} obj={res.obj:.6f} x={res.x}")

if __name__ == "__main__":
    main()
