# objective.py
from __future__ import annotations
from typing import Literal
from .expressions import LinExpr

Direction = Literal["min", "max"]


class Objective:
    def __init__(self, expr: LinExpr, direction: Direction = "min"):
        if direction not in ("min", "max"):
            raise ValueError(f"Invalid direction: {direction}")
        self.expr = expr
        self.direction: Direction = direction

    def __repr__(self) -> str:
        return f"Objective({self.direction}: {self.expr})"
