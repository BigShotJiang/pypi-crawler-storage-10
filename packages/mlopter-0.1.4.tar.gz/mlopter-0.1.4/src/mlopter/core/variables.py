# variables.py
from __future__ import annotations
from typing import Optional, Literal

VarCat = Literal["Continuous", "Integer", "Binary"]


class Var:
    def __init__(self, name: str, low: float = 0.0, up: Optional[float] = None, cat: VarCat = "Continuous"):
        if cat not in ("Continuous", "Integer", "Binary"):
            raise ValueError(f"Unknown category: {cat}")
        self.name = name
        self.low = low
        self.up = up
        self.cat: VarCat = cat

    def __repr__(self) -> str:
        return f"Var(name={self.name}, low={self.low}, up={self.up}, cat={self.cat})"
