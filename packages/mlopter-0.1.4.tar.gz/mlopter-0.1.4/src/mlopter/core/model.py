# model.py
from __future__ import annotations
from typing import Dict, List, Optional, Literal
from .variables import Var as ModelVar, VarCat
from .expressions import LinExpr
from .constraints import Constraint
from .objective import Objective
from ..solvers.base import SolverBase  # type: ignore[reportMissingImports]


class Model:
    def __init__(self, name: str = "model"):
        self.name = name
        self.vars: Dict[str, ModelVar] = {}
        self.constraints: List[Constraint] = []
        self.objective: Optional[Objective] = None
        self.solver: Optional[SolverBase] = None
        self.solution: Dict[str, float] = {}
        self.obj_value: Optional[float] = None
        self.status: str = "NotSolved"

    def add_var(self, name: str, low: float = 0.0, up: Optional[float] = None, cat: VarCat = "Continuous") -> ModelVar:
        if name in self.vars:
            raise ValueError(f"Variable '{name}' already exists")
        v = ModelVar(name, low=low, up=up, cat=cat)  # pass-through
        self.vars[name] = v
        return v

    def linexpr(self, terms: Dict[ModelVar, float], const: float = 0.0) -> LinExpr:
        # Build LinExpr using variable identity from expressions module
        # Map ModelVar -> expressions.Var by name for consistent hashing if needed
        from .expressions import Var as ExprVar
        mapped = {ExprVar(v.name): coef for v, coef in terms.items()}
        return LinExpr(mapped, const)

    def add_constraint(self, c: Constraint) -> None:
        self.constraints.append(c)

    def set_objective(self, obj: Objective) -> None:
        self.objective = obj

    def set_solver(self, solver: SolverBase) -> None:
        self.solver = solver

    def solve(self):
        if self.solver is None:
            raise ValueError("No solver attached")
        if self.objective is None:
            raise ValueError("Objective is not set")
        res = self.solver.solve(self)
        self.status = res.status
        self.solution = res.x
        self.obj_value = res.obj
        return res
