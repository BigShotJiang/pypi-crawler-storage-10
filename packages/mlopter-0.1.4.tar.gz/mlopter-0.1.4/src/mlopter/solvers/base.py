# mlopt/solvers/base.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

try:
    from typing import Protocol
except ImportError:
    from typing_extensions import Protocol  # type: ignore[assignment]


@dataclass
class SolveResult:
    status: str
    obj: float
    x: Dict[str, float]
    solver_name: str


class SolverBase(Protocol):
    name: str
    def solve(self, model) -> SolveResult: ...
