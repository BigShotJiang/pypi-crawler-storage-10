# mlopt/solvers/meta_ga.py
from __future__ import annotations

import random
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from .base import SolverBase, SolveResult


@dataclass
class GeneticSolver(SolverBase):
    name: str = "genetic"
    pop_size: int = 50
    generations: int = 100
    cx_prob: float = 0.7
    mut_prob: float = 0.2
    seed: Optional[int] = 42
    stagnation_tol: int = 20  # early stop if no improvement

    def solve(self, model) -> SolveResult:
        rng = random.Random(self.seed)
        vars_list = list(model.vars.values())

        # default bounds for unbounded variables in heuristic search
        def bounds_of(v) -> Tuple[float, float]:
            low = v.low if v.low is not None else 0.0
            up = v.up if v.up is not None else (1.0 if v.cat == "Binary" else 100.0)
            return float(low), float(up)

        def random_individual() -> Dict[str, float]:
            gene = {}
            for v in vars_list:
                low, up = bounds_of(v)
                if v.cat == "Binary":
                    gene[v.name] = rng.randint(0, 1)
                elif v.cat == "Integer":
                    gene[v.name] = rng.randint(int(low), int(up))
                else:
                    gene[v.name] = rng.uniform(low, up)
            return gene

        def constraint_violation(gene: Dict[str, float]) -> float:
            pen = 0.0
            for c in model.constraints:
                lhs = sum(coef * gene[v.name] for v, coef in c.lhs.coeffs.items()) + c.lhs.const
                if c.sense == "<=" and lhs > c.rhs:
                    pen += (lhs - c.rhs) ** 2
                elif c.sense == ">=" and lhs < c.rhs:
                    pen += (c.rhs - lhs) ** 2
                elif c.sense == "==":
                    pen += (lhs - c.rhs) ** 2
            return pen

        def raw_objective(gene: Dict[str, float]) -> float:
            val = sum(coef * gene[v.name] for v, coef in model.objective.expr.coeffs.items()) + model.objective.expr.const
            return val if model.objective.direction == "min" else -val

        def objective(gene: Dict[str, float]) -> float:
            return raw_objective(gene) + 1e3 * constraint_violation(gene)

        pop = [random_individual() for _ in range(self.pop_size)]
        best: Optional[Tuple[float, Dict[str, float]]] = None
        no_improve = 0

        for _ in range(self.generations):
            scored = [(objective(g), g) for g in pop]
            scored.sort(key=lambda t: t[0])
            if best is None or scored[0][0] < best[0]:
                best = scored[0]
                no_improve = 0
            else:
                no_improve += 1
            if no_improve >= self.stagnation_tol:
                break

            elites = [g for _, g in scored[: max(2, self.pop_size // 5)]]
            children: List[Dict[str, float]] = elites[:]
            while len(children) < self.pop_size:
                a, b = rng.sample(elites, 2)
                child = a.copy()
                if rng.random() < self.cx_prob:
                    for k in child:
                        if rng.random() < 0.5:
                            child[k] = b[k]
                if rng.random() < self.mut_prob:
                    k = rng.choice(list(child.keys()))
                    v = model.vars[k]
                    low, up = bounds_of(v)
                    if v.cat == "Binary":
                        child[k] = 1 - int(child[k])
                    elif v.cat == "Integer":
                        child[k] = max(int(low), min(int(up), int(child[k]) + rng.randint(-3, 3)))
                    else:
                        child[k] = max(low, min(up, float(child[k]) + rng.uniform(-1.0, 1.0)))
                children.append(child)
            pop = children

        assert best is not None
        best_gene = best[1]
        best_obj = raw_objective(best_gene)
        final_obj = best_obj if model.objective.direction == "min" else -best_obj
        return SolveResult(status="Heuristic", obj=final_obj, x=best_gene, solver_name=self.name)
