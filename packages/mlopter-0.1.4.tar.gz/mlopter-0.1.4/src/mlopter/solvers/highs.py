# mlopt/solvers/highs.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any

from .base import SolverBase, SolveResult

try:
    import pulp as pl  # runtime dependency
except Exception:
    pl = None  # type: ignore[assignment]


@dataclass
class HiGHS(SolverBase):
    name: str = "highs"
    msg: bool = False  # control solver logging if supported

    def _get_highs_cmd(self) -> Any:
        """
        Return a PuLP HiGHS command object, supporting both historical names:
        - HiGHS_CMD (common)
        - Highs_CMD (some builds)
        """
        if pl is None:
            raise RuntimeError("PuLP is not installed; install with `pip install pulp`")
        if hasattr(pl, "HiGHS_CMD"):
            return pl.HiGHS_CMD(msg=self.msg)  # type: ignore[attr-defined]
        if hasattr(pl, "Highs_CMD"):
            return pl.Highs_CMD(msg_log=self.msg)  # type: ignore[attr-defined]
        raise RuntimeError("HiGHS command not available in PuLP; ensure PuLP is built with HiGHS support")

    def solve(self, model) -> SolveResult:
        if pl is None:
            raise RuntimeError("PuLP is not installed; install with `pip install pulp`")
        if model.objective is None:
            raise ValueError("Objective must be set before calling solve()")

        sense = pl.LpMinimize if model.objective.direction == "min" else pl.LpMaximize
        lp = pl.LpProblem(model.name, sense)

        # Use Any to avoid referencing runtime classes in type annotations
        pv: Dict[str, Any] = {}
        for v in model.vars.values():
            cat = (
                pl.LpContinuous
                if v.cat == "Continuous"
                else (pl.LpInteger if v.cat == "Integer" else pl.LpBinary)
            )
            pv[v.name] = pl.LpVariable(v.name, lowBound=v.low, upBound=v.up, cat=cat)

        # Objective
        obj_expr = 0
        for var, coef in model.objective.expr.coeffs.items():
            obj_expr += coef * pv[var.name]
        if model.objective.expr.const:
            obj_expr += float(model.objective.expr.const)
        lp += obj_expr

        # Constraints
        for c in model.constraints:
            lhs = 0
            for var, coef in c.lhs.coeffs.items():
                lhs += coef * pv[var.name]
            if c.lhs.const:
                lhs += float(c.lhs.const)
            if c.sense == "<=":
                lp += (lhs <= c.rhs, c.name)
            elif c.sense == ">=":
                lp += (lhs >= c.rhs, c.name)
            else:
                lp += (lhs == c.rhs, c.name)

        highs_cmd = self._get_highs_cmd()
        status_code = lp.solve(highs_cmd)

        try:
            status = pl.LpStatus[status_code]
        except Exception:
            status = str(status_code)

        x = {name: (pv[name].value() if pv[name].value() is not None else 0.0) for name in pv}
        objv = float(pl.value(lp.objective))
        return SolveResult(status=status, obj=objv, x=x, solver_name=self.name)
