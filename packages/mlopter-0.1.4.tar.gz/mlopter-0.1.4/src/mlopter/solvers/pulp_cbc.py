# mlopt/solvers/pulp_cbc.py
from __future__ import annotations

from typing import Dict, Any
from dataclasses import dataclass
from .base import SolverBase, SolveResult

try:
    import pulp as pl  # Requires PuLP installed
except Exception:
    pl = None  # type: ignore[assignment]


@dataclass
class PuLPCBC(SolverBase):
    name: str = "pulp_cbc"
    msg: bool = False  # control solver output

    def solve(self, model) -> SolveResult:
        if pl is None:
            raise RuntimeError("PuLP is not installed; install with `pip install pulp`")
        if model.objective is None:
            raise ValueError("Objective must be set before calling solve()")

        sense = pl.LpMinimize if model.objective.direction == "min" else pl.LpMaximize
        lp = pl.LpProblem(model.name, sense)

        # Use Any for PuLP variables to avoid referencing runtime classes in type annotations
        pv: Dict[str, Any] = {}
        for v in model.vars.values():
            cat = (
                pl.LpContinuous
                if v.cat == "Continuous"
                else (pl.LpInteger if v.cat == "Integer" else pl.LpBinary)
            )
            pv[v.name] = pl.LpVariable(v.name, lowBound=v.low, upBound=v.up, cat=cat)

        # Objective
        obj_expr = 0
        for var, coef in model.objective.expr.coeffs.items():
            obj_expr += coef * pv[var.name]
        if model.objective.expr.const:
            obj_expr += float(model.objective.expr.const)
        lp += obj_expr

        # Constraints
        for c in model.constraints:
            lhs = 0
            for var, coef in c.lhs.coeffs.items():
                lhs += coef * pv[var.name]
            if c.lhs.const:
                lhs += float(c.lhs.const)
            if c.sense == "<=":
                lp += (lhs <= c.rhs, c.name)
            elif c.sense == ">=":
                lp += (lhs >= c.rhs, c.name)
            else:
                lp += (lhs == c.rhs, c.name)

        # Solve with CBC
        cmd = getattr(pl, "PULP_CBC_CMD", None)
        if cmd is None:
            raise RuntimeError("PULP_CBC_CMD not available; check your PuLP installation")
        status_code = lp.solve(cmd(msg=self.msg))

        try:
            status = pl.LpStatus[status_code]
        except Exception:
            status = str(status_code)

        x = {name: (pv[name].value() if pv[name].value() is not None else 0.0) for name in pv}
        objv = float(pl.value(lp.objective))
        return SolveResult(status=status, obj=objv, x=x, solver_name=self.name)
