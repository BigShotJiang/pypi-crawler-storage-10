# mlopt/solvers/bayesopt.py
from __future__ import annotations

from typing import Callable, Dict, List, Optional
from dataclasses import dataclass
from .base import SolverBase, SolveResult

try:
    from skopt import gp_minimize
    from skopt.space import Real, Integer
except Exception:
    gp_minimize = None  # type: ignore[assignment]


@dataclass
class BayesianOpt(SolverBase):
    name: str = "bayesopt"
    n_calls: int = 30
    random_state: int = 42
    n_initial_points: int = 5

    def _space_from_model(self, model):
        var_list = list(model.vars.values())
        space = []
        for v in var_list:
            low = float(v.low if v.low is not None else 0.0)
            up = float(v.up if v.up is not None else (1.0 if v.cat == "Binary" else 100.0))
            if v.cat == "Integer":
                space.append(Integer(int(low), int(up), name=v.name))
            else:
                space.append(Real(low, up, name=v.name))
        return var_list, space

    def _objective_from_model(self, model) -> Callable[[List[float]], float]:
        # If a black-box callable is attached, use it
        black_box: Optional[Callable[[Dict[str, float]], float]] = getattr(model, "_black_box", None)

        var_list = list(model.vars.values())

        def objective(x: List[float]) -> float:
            assign = {var_list[i].name: x[i] for i in range(len(var_list))}
            if callable(black_box):
                val = float(black_box(assign))
            else:
                # linear objective fallback
                val = sum(coef * assign[v.name] for v, coef in model.objective.expr.coeffs.items()) + model.objective.expr.const
            # constraint penalty
            penalty = 0.0
            for c in model.constraints:
                lhs = sum(coef * assign[v.name] for v, coef in c.lhs.coeffs.items()) + c.lhs.const
                if c.sense == "<=" and lhs > c.rhs:
                    penalty += (lhs - c.rhs) ** 2
                elif c.sense == ">=" and lhs < c.rhs:
                    penalty += (c.rhs - lhs) ** 2
                elif c.sense == "==":
                    penalty += (lhs - c.rhs) ** 2
            if model.objective.direction == "min":
                return val + 1e3 * penalty
            else:
                return -(val - 1e3 * penalty)

        return objective

    # Optional convenience if the user wants to pass a callable directly
    def solve_with_callable(self, model, fn: Callable[[Dict[str, float]], float]) -> SolveResult:
        setattr(model, "_black_box", fn)
        return self.solve(model)

    def solve(self, model) -> SolveResult:
        if gp_minimize is None:
            raise RuntimeError("scikit-optimize not installed; install with `pip install scikit-optimize`")
        if model.objective is None:
            raise ValueError("Objective must be set before calling solve()")

        var_list, space = self._space_from_model(model)
        objective = self._objective_from_model(model)
        res = gp_minimize(
            objective,
            space,
            n_calls=self.n_calls,
            n_initial_points=self.n_initial_points,
            random_state=self.random_state,
            noise=1e-10,  # small noise helps stability
        )
        x_map = {var_list[i].name: res.x[i] for i in range(len(var_list))}
        obj = float(res.fun if model.objective.direction == "min" else -res.fun)
        return SolveResult(status="Converged", obj=obj, x=x_map, solver_name=self.name)
