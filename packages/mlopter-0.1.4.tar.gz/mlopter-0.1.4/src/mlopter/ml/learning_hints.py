# mlopt/ml/learning_hints.py
from __future__ import annotations

from typing import Dict, Any, Optional


class LearningHints:
    """
    Container for learning-augmented solver hints.

    Parameters
    ----------
    var_priorities : Optional[Dict[str, int]]
        Branching priorities by variable name; higher means branch earlier.
    var_fixings : Optional[Dict[str, float]]
        Suggested fixings for variables (e.g., 0/1 for binaries, integers for MIPs).
    cut_hints : Optional[Dict[str, float]]
        Named cut strengths or thresholds (solver-specific).
    """

    def __init__(
        self,
        var_priorities: Optional[Dict[str, int]] = None,
        var_fixings: Optional[Dict[str, float]] = None,
        cut_hints: Optional[Dict[str, float]] = None,
    ):
        self.var_priorities: Dict[str, int] = dict(var_priorities or {})
        self.var_fixings: Dict[str, float] = dict(var_fixings or {})
        self.cut_hints: Dict[str, float] = dict(cut_hints or {})
        self._validate()

    def _validate(self) -> None:
        for k, v in self.var_priorities.items():
            if not isinstance(v, int):
                raise TypeError(f"var_priorities[{k}] must be int, got {type(v)}")
        for k, v in self.var_fixings.items():
            if not isinstance(v, (int, float)):
                raise TypeError(f"var_fixings[{k}] must be number, got {type(v)}")
        for k, v in self.cut_hints.items():
            if not isinstance(v, (int, float)):
                raise TypeError(f"cut_hints[{k}] must be number, got {type(v)}")

    def to_solver_kwargs(self) -> Dict[str, Any]:
        """
        Normalize hints to a solver-agnostic kwargs dict that adapters can interpret.
        """
        return {
            "var_priorities": dict(self.var_priorities),
            "var_fixings": dict(self.var_fixings),
            "cut_hints": dict(self.cut_hints),
        }
