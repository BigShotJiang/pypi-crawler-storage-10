# mlopt/ml/surrogate.py
from __future__ import annotations

from typing import Optional, Tuple

import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern


class SurrogateModel:
    """
    Gaussian-process surrogate for black-box optimization.

    Parameters
    ----------
    nu : float
        Smoothness of the Matern kernel; common values are 1.5 or 2.5.
    length_scale : float
        Initial kernel length scale.
    normalize_y : bool
        Whether to normalize target y internally.
    random_state : Optional[int]
        Random seed for reproducibility.
    """

    def __init__(
        self,
        nu: float = 2.5,
        length_scale: float = 1.0,
        normalize_y: bool = True,
        random_state: Optional[int] = 42,
    ):
        kernel = Matern(length_scale=length_scale, nu=nu)
        self.gp = GaussianProcessRegressor(
            kernel=kernel,
            normalize_y=normalize_y,
            random_state=random_state,
            n_restarts_optimizer=2,
        )

    def fit(self, X: np.ndarray, y: np.ndarray) -> None:
        """
        Fit surrogate on observations.

        X: shape (n_samples, n_features) or (n_samples,)
        y: shape (n_samples,)
        """
        X = self._ensure_2d(X)
        y = np.asarray(y).reshape(-1)
        if X.shape[0] != y.shape[0]:
            raise ValueError(f"X rows {X.shape[0]} != y length {y.shape[0]}")
        self.gp.fit(X, y)

    def predict(self, X: np.ndarray, return_std: bool = False) -> np.ndarray | Tuple[np.ndarray, np.ndarray] | Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Predict mean (and optionally std) at new points.

        X: shape (n_samples, n_features) or (n_samples,)
        return_std: if True, returns (mean, std) or (mean, std, std_grad)
        """
        X = self._ensure_2d(X)
        return self.gp.predict(X, return_std=return_std)

    @staticmethod
    def _ensure_2d(X: np.ndarray) -> np.ndarray:
        X = np.asarray(X)
        if X.ndim == 1:
            X = X.reshape(-1, 1)
        if X.ndim != 2:
            raise ValueError(f"X must be 1D or 2D, got shape {X.shape}")
        return X
