#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Конфигурация - Общие конфигурации и константы

Модуль содержит общие конфигурации для всех пакетов.
"""

import os
from pathlib import Path
from typing import Optional, Dict, Any

__version__ = "1.0.0"
__author__ = "NativeMind.ru & УРАБИ.РФ"

__all__ = [
    "__version__",
    "__author__",
    "Config",
    "QuantumConfig",
    "config"
]


class Config:
    """Общая конфигурация pyQuantumAI"""
    
    # Пути
    ROOT_DIR = Path(__file__).parent.parent.parent.parent
    CACHE_DIR = ROOT_DIR / ".cache"
    OUTPUT_DIR = ROOT_DIR / "output"
    MODELS_DIR = ROOT_DIR / "models"
    
    # Логирование
    LOG_LEVEL = os.getenv("PYQUANTUM_LOG_LEVEL", "INFO")
    LOG_FILE = os.getenv("PYQUANTUM_LOG_FILE", None)
    
    # HuggingFace
    HF_TOKEN = os.getenv("HF_TOKEN", None)
    HF_CACHE_DIR = os.getenv("HF_HOME", str(CACHE_DIR / "huggingface"))
    
    # Устройство
    DEVICE = os.getenv("PYQUANTUM_DEVICE", "auto")  # auto, mps, cuda, cpu
    USE_MPS = os.getenv("PYQUANTUM_USE_MPS", "true").lower() == "true"
    
    # Параллелизм
    MAX_WORKERS = int(os.getenv("PYQUANTUM_MAX_WORKERS", "4"))
    
    # Безопасность
    TRUST_REMOTE_CODE = os.getenv("PYQUANTUM_TRUST_REMOTE_CODE", "true").lower() == "true"
    
    @classmethod
    def ensure_dirs(cls):
        """Создание необходимых директорий"""
        cls.CACHE_DIR.mkdir(parents=True, exist_ok=True)
        cls.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        cls.MODELS_DIR.mkdir(parents=True, exist_ok=True)
    
    @classmethod
    def get_device(cls) -> str:
        """Получить устройство для вычислений"""
        import torch
        
        if cls.DEVICE != "auto":
            return cls.DEVICE
        
        # Автоопределение
        if cls.USE_MPS and torch.backends.mps.is_available():
            return "mps"
        elif torch.cuda.is_available():
            return "cuda"
        else:
            return "cpu"
    
    @classmethod
    def to_dict(cls) -> Dict[str, Any]:
        """Конвертация в словарь"""
        return {
            'root_dir': str(cls.ROOT_DIR),
            'cache_dir': str(cls.CACHE_DIR),
            'output_dir': str(cls.OUTPUT_DIR),
            'models_dir': str(cls.MODELS_DIR),
            'log_level': cls.LOG_LEVEL,
            'hf_cache_dir': cls.HF_CACHE_DIR,
            'device': cls.get_device(),
            'use_mps': cls.USE_MPS,
            'max_workers': cls.MAX_WORKERS,
            'trust_remote_code': cls.TRUST_REMOTE_CODE
        }


class QuantumConfig:
    """Конфигурация квантовых параметров"""
    
    # Физические константы
    RESONANCE_FREQ = 440.0  # Hz (A4 нота)
    GOLDEN_RATIO = 1.618033988749895  # φ (фи)
    PI = 3.141592653589793
    PLANCK_CONSTANT = 6.62607015e-34  # Дж·с
    
    # Пирамида FreeDome
    FREEDOME_BASE = 50.8  # мм
    FREEDOME_HEIGHT = 48.05  # мм
    FREEDOME_FACES = 4
    
    # Параметры синхронизации
    DEFAULT_CYCLES = 20
    DEFAULT_LEARNING_RATE = 0.05
    DEFAULT_SYNC_TARGET = 0.90
    REST_PERIOD = 30  # секунд
    
    # FFT параметры
    FFT_SAMPLE_SIZE = 1000
    NUM_HARMONICS = 8
    
    # LoRA параметры
    LORA_R = 8
    LORA_ALPHA = 16
    LORA_DROPOUT = 0.05
    
    # MPS оптимизации
    MPS_USE_MIXED_PRECISION = True
    MPS_MEMORY_EFFICIENT = True
    
    @classmethod
    def get_harmonics(cls, base_freq: Optional[float] = None) -> list:
        """Получить гармоники базовой частоты"""
        if base_freq is None:
            base_freq = cls.RESONANCE_FREQ
        
        return [base_freq * (i + 1) for i in range(cls.NUM_HARMONICS)]
    
    @classmethod
    def to_dict(cls) -> Dict[str, Any]:
        """Конвертация в словарь"""
        return {
            'resonance_freq': cls.RESONANCE_FREQ,
            'golden_ratio': cls.GOLDEN_RATIO,
            'freedome_base': cls.FREEDOME_BASE,
            'freedome_height': cls.FREEDOME_HEIGHT,
            'freedome_faces': cls.FREEDOME_FACES,
            'default_cycles': cls.DEFAULT_CYCLES,
            'default_learning_rate': cls.DEFAULT_LEARNING_RATE,
            'default_sync_target': cls.DEFAULT_SYNC_TARGET,
            'fft_sample_size': cls.FFT_SAMPLE_SIZE,
            'num_harmonics': cls.NUM_HARMONICS,
            'lora_r': cls.LORA_R,
            'lora_alpha': cls.LORA_ALPHA,
            'lora_dropout': cls.LORA_DROPOUT,
            'mps_use_mixed_precision': cls.MPS_USE_MIXED_PRECISION,
            'mps_memory_efficient': cls.MPS_MEMORY_EFFICIENT
        }


# Создание директорий при импорте
Config.ensure_dirs()

# Глобальный экземпляр конфигурации
config = Config()
