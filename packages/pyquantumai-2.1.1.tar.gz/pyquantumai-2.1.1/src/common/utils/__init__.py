#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Общие утилиты - Вспомогательные функции

Модуль содержит общие утилиты для работы с данными, HuggingFace моделями и промптами.
"""

import os
import sys
import json
import logging
from pathlib import Path
from typing import Optional, Dict, Any, List
import torch
from datetime import datetime

__version__ = "1.0.0"
__author__ = "NativeMind.ru"

__all__ = [
    "__version__",
    "__author__",
    "DataUtils",
    "HuggingFaceUtils",
    "PromptUtils",
    "logger"
]


class DataUtils:
    """Утилиты для работы с данными"""
    
    @staticmethod
    def setup_logging(
        level: int = logging.INFO,
        log_file: Optional[str] = None
    ) -> logging.Logger:
        """
        Настройка логирования
        
        Args:
            level: Уровень логирования
            log_file: Путь к файлу логов (опционально)
        
        Returns:
            Настроенный logger
        """
        logger = logging.getLogger('pyQuantumAI')
        logger.setLevel(level)
        
        # Формат
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        # Консоль
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
        
        # Файл (опционально)
        if log_file:
            file_handler = logging.FileHandler(log_file)
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
        
        return logger
    
    @staticmethod
    def load_json(path: str) -> Dict[str, Any]:
        """Загрузка JSON файла"""
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    @staticmethod
    def save_json(data: Dict[str, Any], path: str):
        """Сохранение JSON файла"""
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    
    @staticmethod
    def get_device(prefer_mps: bool = True) -> torch.device:
        """
        Получить оптимальное устройство для вычислений
        
        Args:
            prefer_mps: Предпочитать MPS на Apple Silicon
        
        Returns:
            torch.device
        """
        if prefer_mps and torch.backends.mps.is_available():
            return torch.device("mps")
        elif torch.cuda.is_available():
            return torch.device("cuda")
        else:
            return torch.device("cpu")
    
    @staticmethod
    def format_size(bytes_size: int) -> str:
        """Форматирование размера в читаемый вид"""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if bytes_size < 1024.0:
                return f"{bytes_size:.2f} {unit}"
            bytes_size /= 1024.0
        return f"{bytes_size:.2f} PB"
    
    @staticmethod
    def ensure_dir(path: str) -> Path:
        """Создание директории если не существует"""
        dir_path = Path(path)
        dir_path.mkdir(parents=True, exist_ok=True)
        return dir_path


class HuggingFaceUtils:
    """Утилиты для работы с HuggingFace"""
    
    @staticmethod
    def is_hf_model(model_path: str) -> bool:
        """
        Проверка, является ли путь HuggingFace моделью
        
        Args:
            model_path: Путь или ID модели
        
        Returns:
            True если это HF модель
        """
        # HF модели обычно в формате "username/modelname"
        return '/' in model_path and not model_path.startswith('./')
    
    @staticmethod
    def download_model(
        model_id: str,
        cache_dir: Optional[str] = None,
        token: Optional[str] = None
    ) -> str:
        """
        Загрузка модели из HuggingFace
        
        Args:
            model_id: ID модели на HF
            cache_dir: Директория кеша
            token: HF токен (для приватных моделей)
        
        Returns:
            Путь к загруженной модели
        """
        try:
            from transformers import AutoModel
            
            model = AutoModel.from_pretrained(
                model_id,
                cache_dir=cache_dir,
                token=token,
                trust_remote_code=True
            )
            
            # Возвращаем путь к кешу
            if cache_dir:
                return str(Path(cache_dir) / model_id.replace('/', '_'))
            else:
                return model_id
        
        except Exception as e:
            raise RuntimeError(f"Ошибка загрузки модели {model_id}: {e}")
    
    @staticmethod
    def get_model_info(model_id: str) -> Dict[str, Any]:
        """
        Получение информации о модели из HuggingFace
        
        Args:
            model_id: ID модели
        
        Returns:
            Словарь с информацией о модели
        """
        try:
            from transformers import AutoConfig
            
            config = AutoConfig.from_pretrained(model_id, trust_remote_code=True)
            
            return {
                'model_id': model_id,
                'model_type': config.model_type if hasattr(config, 'model_type') else 'unknown',
                'hidden_size': config.hidden_size if hasattr(config, 'hidden_size') else 0,
                'num_layers': config.num_hidden_layers if hasattr(config, 'num_hidden_layers') else 0,
                'vocab_size': config.vocab_size if hasattr(config, 'vocab_size') else 0
            }
        
        except Exception as e:
            return {
                'model_id': model_id,
                'error': str(e)
            }


class PromptUtils:
    """Утилиты для работы с промптами"""
    
    @staticmethod
    def create_system_prompt(
        role: str = "assistant",
        expertise: Optional[List[str]] = None,
        language: str = "ru"
    ) -> str:
        """
        Создание системного промпта
        
        Args:
            role: Роль (assistant, developer, lawyer, etc.)
            expertise: Области экспертизы
            language: Язык (ru, en, etc.)
        
        Returns:
            Системный промпт
        """
        prompts = {
            'ru': {
                'assistant': "Ты — полезный AI ассистент.",
                'developer': "Ты — опытный разработчик программного обеспечения.",
                'lawyer': "Ты — квалифицированный юрист.",
                'teacher': "Ты — опытный преподаватель."
            },
            'en': {
                'assistant': "You are a helpful AI assistant.",
                'developer': "You are an experienced software developer.",
                'lawyer': "You are a qualified lawyer.",
                'teacher': "You are an experienced teacher."
            }
        }
        
        base_prompt = prompts.get(language, prompts['en']).get(role, prompts[language]['assistant'])
        
        if expertise:
            expertise_str = ", ".join(expertise)
            if language == 'ru':
                base_prompt += f" Твои области экспертизы: {expertise_str}."
            else:
                base_prompt += f" Your areas of expertise: {expertise_str}."
        
        return base_prompt
    
    @staticmethod
    def format_chat_prompt(
        messages: List[Dict[str, str]],
        system_prompt: Optional[str] = None
    ) -> str:
        """
        Форматирование промпта для чата
        
        Args:
            messages: Список сообщений [{"role": "user/assistant", "content": "..."}]
            system_prompt: Системный промпт (опционально)
        
        Returns:
            Отформатированный промпт
        """
        formatted = []
        
        if system_prompt:
            formatted.append(f"System: {system_prompt}")
        
        for msg in messages:
            role = msg.get('role', 'user')
            content = msg.get('content', '')
            
            if role == 'user':
                formatted.append(f"User: {content}")
            elif role == 'assistant':
                formatted.append(f"Assistant: {content}")
            elif role == 'system':
                formatted.append(f"System: {content}")
        
        return "\n".join(formatted)


# Создаем глобальный logger
logger = DataUtils.setup_logging()
