#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Совместимость - Совместимость с зарубежными библиотеками

Модуль обеспечивает совместимость с существующими библиотеками:
- transformers (HuggingFace)
- torch / PyTorch
- peft (Parameter-Efficient Fine-Tuning)
- numpy
"""

import sys
import warnings
from typing import Optional, Any

__version__ = "1.0.0"
__author__ = "NativeMind.ru & УРАБИ.РФ"

__all__ = [
    "__version__",
    "__author__",
    "CompatibilityLayer",
    "check_dependencies",
    "import_optional"
]


class CompatibilityLayer:
    """Слой совместимости с зарубежными библиотеками"""
    
    # Минимальные версии
    MIN_VERSIONS = {
        'torch': '2.0.0',
        'transformers': '4.30.0',
        'peft': '0.4.0',
        'numpy': '1.20.0'
    }
    
    # Опциональные зависимости
    OPTIONAL_DEPS = {
        'accelerate': '0.20.0',
        'bitsandbytes': '0.40.0',
        'sentencepiece': '0.1.99',
        'protobuf': '3.20.0'
    }
    
    @classmethod
    def check_torch(cls) -> bool:
        """Проверка PyTorch"""
        try:
            import torch
            
            version = torch.__version__.split('+')[0]  # Убираем +cu118 и т.д.
            
            if version < cls.MIN_VERSIONS['torch']:
                warnings.warn(
                    f"PyTorch версии {version} может быть несовместим. "
                    f"Рекомендуется версия >= {cls.MIN_VERSIONS['torch']}"
                )
            
            return True
        except ImportError:
            return False
    
    @classmethod
    def check_transformers(cls) -> bool:
        """Проверка transformers"""
        try:
            import transformers
            
            version = transformers.__version__
            
            if version < cls.MIN_VERSIONS['transformers']:
                warnings.warn(
                    f"transformers версии {version} может быть несовместим. "
                    f"Рекомендуется версия >= {cls.MIN_VERSIONS['transformers']}"
                )
            
            return True
        except ImportError:
            return False
    
    @classmethod
    def check_peft(cls) -> bool:
        """Проверка PEFT"""
        try:
            import peft
            return True
        except ImportError:
            warnings.warn(
                "PEFT не установлен. Функции LoRA будут недоступны. "
                "Установите: pip install peft"
            )
            return False
    
    @classmethod
    def check_numpy(cls) -> bool:
        """Проверка NumPy"""
        try:
            import numpy as np
            
            version = np.__version__
            
            if version < cls.MIN_VERSIONS['numpy']:
                warnings.warn(
                    f"NumPy версии {version} может быть несовместим. "
                    f"Рекомендуется версия >= {cls.MIN_VERSIONS['numpy']}"
                )
            
            return True
        except ImportError:
            return False
    
    @classmethod
    def check_optional_dependency(cls, name: str) -> bool:
        """Проверка опциональной зависимости"""
        try:
            __import__(name)
            return True
        except ImportError:
            return False
    
    @classmethod
    def get_available_backends(cls) -> dict:
        """Получить доступные бэкенды"""
        import torch
        
        backends = {
            'cpu': True,
            'cuda': torch.cuda.is_available(),
            'mps': torch.backends.mps.is_available() if hasattr(torch.backends, 'mps') else False,
            'xla': cls.check_optional_dependency('torch_xla')
        }
        
        return backends
    
    @classmethod
    def get_device_info(cls) -> dict:
        """Получить информацию об устройствах"""
        import torch
        import platform
        
        info = {
            'platform': platform.system(),
            'architecture': platform.machine(),
            'python_version': sys.version,
            'torch_version': torch.__version__,
            'backends': cls.get_available_backends()
        }
        
        # CUDA info
        if torch.cuda.is_available():
            info['cuda'] = {
                'version': torch.version.cuda,
                'device_count': torch.cuda.device_count(),
                'devices': [
                    {
                        'name': torch.cuda.get_device_name(i),
                        'capability': torch.cuda.get_device_capability(i)
                    }
                    for i in range(torch.cuda.device_count())
                ]
            }
        
        # MPS info
        if hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
            info['mps'] = {
                'available': True,
                'built': torch.backends.mps.is_built()
            }
        
        return info
    
    @classmethod
    def print_system_info(cls):
        """Вывести информацию о системе"""
        info = cls.get_device_info()
        
        print("\n" + "=" * 80)
        print("ИНФОРМАЦИЯ О СИСТЕМЕ")
        print("=" * 80)
        print(f"Платформа: {info['platform']}")
        print(f"Архитектура: {info['architecture']}")
        print(f"Python: {info['python_version'].split()[0]}")
        print(f"PyTorch: {info['torch_version']}")
        print("\nДоступные бэкенды:")
        for backend, available in info['backends'].items():
            status = "✅" if available else "❌"
            print(f"  {status} {backend.upper()}")
        
        if 'cuda' in info:
            print(f"\nCUDA: {info['cuda']['version']}")
            print(f"  Устройств: {info['cuda']['device_count']}")
            for i, device in enumerate(info['cuda']['devices']):
                print(f"  [{i}] {device['name']} (Capability: {device['capability']})")
        
        if 'mps' in info:
            print(f"\nMPS (Apple Silicon): ✅ Доступен")
        
        print("=" * 80)
        print()


def check_dependencies() -> dict:
    """
    Проверка всех зависимостей
    
    Returns:
        Словарь {dependency: available}
    """
    results = {
        'torch': CompatibilityLayer.check_torch(),
        'transformers': CompatibilityLayer.check_transformers(),
        'peft': CompatibilityLayer.check_peft(),
        'numpy': CompatibilityLayer.check_numpy()
    }
    
    # Опциональные
    for dep in CompatibilityLayer.OPTIONAL_DEPS:
        results[f'{dep} (optional)'] = CompatibilityLayer.check_optional_dependency(dep)
    
    return results


def import_optional(name: str, error_msg: Optional[str] = None) -> Any:
    """
    Импорт опциональной зависимости с понятным сообщением об ошибке
    
    Args:
        name: Имя модуля
        error_msg: Сообщение об ошибке (опционально)
    
    Returns:
        Импортированный модуль
    
    Raises:
        ImportError: Если модуль не найден
    """
    try:
        return __import__(name)
    except ImportError:
        if error_msg is None:
            error_msg = (
                f"Модуль '{name}' не установлен. "
                f"Установите его: pip install {name}"
            )
        raise ImportError(error_msg)


# Проверка критических зависимостей при импорте
if not CompatibilityLayer.check_torch():
    raise ImportError(
        "PyTorch не установлен. "
        "Установите: pip install torch"
    )

if not CompatibilityLayer.check_transformers():
    raise ImportError(
        "transformers не установлен. "
        "Установите: pip install transformers"
    )

if not CompatibilityLayer.check_numpy():
    raise ImportError(
        "NumPy не установлен. "
        "Установите: pip install numpy"
    )
