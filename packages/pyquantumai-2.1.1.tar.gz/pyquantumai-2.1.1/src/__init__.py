"""
pyQuantumAI - Библиотека квантовой AI педагогики

Квантовая педагогика AI:
- quantum_sync: замена transformers и peft
- Квантовое переобучение через резонанс 440 Hz
- Объёмная интерференция в пирамидальной геометрии

Примечание: Blockchain, Crypto и VPN инструменты вынесены
в отдельный пакет pyNativeMindOther

© 2025 NativeMind
"""

__version__ = "1.0.0"
__author__ = "NativeMind & УРАБИ.РФ"
__license__ = "NativeMindNONC"

# Импорт основных модулей
from .quantum_sync import (
    QuantumBatteryEqualizer,
    QuantumPyramid,
    ModelChannel,
    SignatureExtractor,
    apply_signature,
    ProjectionLayer,
    AdaptiveProjection
)

__all__ = [
    # QuantumSync (transformers/peft replacement)
    "QuantumBatteryEqualizer",
    "QuantumPyramid",
    "ModelChannel",
    "SignatureExtractor",
    "apply_signature",
    "ProjectionLayer",
    "AdaptiveProjection",
]
