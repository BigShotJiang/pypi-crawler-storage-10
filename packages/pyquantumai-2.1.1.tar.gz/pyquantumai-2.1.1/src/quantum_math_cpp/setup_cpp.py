"""
Setup script для компиляции C++ компонентов pyQuantumAI

Использует pybind11 и CMake для создания Python extension

© 2025 NativeMind
"""

from pathlib import Path
import subprocess
import sys
import platform

def check_requirements():
    """Проверка необходимых компонентов"""
    requirements = {
        'cmake': 'CMake',
        'c++': 'C++ compiler (g++/clang++)',
        'python3-dev': 'Python development headers'
    }
    
    print("🔧 Проверка требований...")
    
    # Проверяем CMake
    try:
        result = subprocess.run(['cmake', '--version'], 
                              capture_output=True, text=True)
        if result.returncode == 0:
            print(f"   ✅ CMake: {result.stdout.split()[2]}")
        else:
            print(f"   ❌ CMake не найден")
            return False
    except FileNotFoundError:
        print(f"   ❌ CMake не найден")
        return False
    
    # Проверяем C++ компилятор
    compilers = ['g++', 'clang++', 'c++']
    compiler_found = False
    for compiler in compilers:
        try:
            result = subprocess.run([compiler, '--version'],
                                  capture_output=True, text=True)
            if result.returncode == 0:
                print(f"   ✅ C++ compiler: {compiler}")
                compiler_found = True
                break
        except FileNotFoundError:
            continue
    
    if not compiler_found:
        print(f"   ❌ C++ compiler не найден")
        return False
    
    # Проверяем Python headers
    import sysconfig
    include_dir = sysconfig.get_path('include')
    python_h = Path(include_dir) / 'Python.h'
    
    if python_h.exists():
        print(f"   ✅ Python headers: {include_dir}")
    else:
        print(f"   ❌ Python headers не найдены")
        print(f"      Установите: python3-dev или python3-devel")
        return False
    
    return True

def install_pybind11():
    """Установка pybind11 если не установлен"""
    try:
        import pybind11
        print(f"   ✅ pybind11: {pybind11.__version__}")
        return True
    except ImportError:
        print("   📦 Устанавливаю pybind11...")
        try:
            subprocess.run([sys.executable, '-m', 'pip', 'install', 'pybind11'],
                         check=True)
            print("   ✅ pybind11 установлен")
            return True
        except subprocess.CalledProcessError:
            print("   ❌ Не удалось установить pybind11")
            return False

def detect_platform():
    """Определение платформы и возможностей"""
    info = {
        'system': platform.system(),
        'machine': platform.machine(),
        'python': platform.python_version(),
        'mps_available': False,
        'cuda_available': False
    }
    
    print(f"\n🖥️  Платформа:")
    print(f"   Система: {info['system']}")
    print(f"   Архитектура: {info['machine']}")
    print(f"   Python: {info['python']}")
    
    # Проверяем MPS (Apple Silicon)
    if info['system'] == 'Darwin' and info['machine'] == 'arm64':
        info['mps_available'] = True
        print(f"   ✅ Apple Silicon (MPS доступен)")
        
        # Определяем модель чипа
        try:
            result = subprocess.run(['sysctl', '-n', 'machdep.cpu.brand_string'],
                                  capture_output=True, text=True)
            if result.returncode == 0:
                chip = result.stdout.strip()
                print(f"   🍎 Чип: {chip}")
        except:
            pass
    
    # Проверяем CUDA (NVIDIA GPU)
    try:
        result = subprocess.run(['nvcc', '--version'],
                              capture_output=True, text=True)
        if result.returncode == 0:
            info['cuda_available'] = True
            print(f"   ✅ CUDA доступен")
    except FileNotFoundError:
        pass
    
    return info

def build_cpp_extension():
    """Компиляция C++ extension"""
    print("\n🔨 Компиляция C++ компонентов...")
    
    build_dir = Path(__file__).parent / 'build'
    build_dir.mkdir(exist_ok=True)
    
    # CMake configure
    print("   Конфигурация CMake...")
    cmake_args = [
        'cmake',
        '..',
        f'-DCMAKE_BUILD_TYPE=Release',
        f'-DPYTHON_EXECUTABLE={sys.executable}'
    ]
    
    try:
        result = subprocess.run(cmake_args, cwd=build_dir,
                              capture_output=True, text=True)
        if result.returncode != 0:
            print(f"   ❌ Ошибка конфигурации CMake:")
            print(result.stderr)
            return False
        
        print(f"   ✅ CMake сконфигурирован")
        
        # Build
        print("   Сборка...")
        result = subprocess.run(['cmake', '--build', '.', '--config', 'Release'],
                              cwd=build_dir,
                              capture_output=True, text=True)
        
        if result.returncode != 0:
            print(f"   ❌ Ошибка сборки:")
            print(result.stderr)
            return False
        
        print(f"   ✅ C++ extension собран")
        
        # Находим собранный .so/.dylib файл
        extensions = ['.so', '.dylib', '.pyd']
        for ext in extensions:
            built_file = list(build_dir.rglob(f'quantum_math_cpp*{ext}'))
            if built_file:
                print(f"   📦 Extension: {built_file[0].name}")
                
                # Копируем в src/quantum_sync
                target_dir = Path(__file__).parent.parent / 'quantum_sync'
                target_dir.mkdir(exist_ok=True)
                
                import shutil
                shutil.copy2(built_file[0], target_dir)
                print(f"   ✅ Extension скопирован в {target_dir}")
                return True
        
        print("   ⚠️ Extension собран, но файл не найден")
        return False
        
    except Exception as e:
        print(f"   ❌ Ошибка: {e}")
        return False

def main():
    """Главная функция"""
    print("=" * 80)
    print("🔮 pyQuantumAI - Компиляция C++ компонентов")
    print("=" * 80)
    
    # Проверка требований
    if not check_requirements():
        print("\n❌ Не все требования выполнены")
        print("\nУстановите необходимые компоненты:")
        print("  macOS: brew install cmake")
        print("  Ubuntu: sudo apt-get install cmake g++ python3-dev")
        return 1
    
    # Установка pybind11
    if not install_pybind11():
        return 1
    
    # Определение платформы
    platform_info = detect_platform()
    
    # Компиляция
    if not build_cpp_extension():
        return 1
    
    print("\n" + "=" * 80)
    print("🎉 C++ компоненты успешно скомпилированы!")
    print("=" * 80)
    
    if platform_info['mps_available']:
        print("✅ Аппаратное ускорение MPS (Apple Silicon) включено")
    
    print("\nИспользование:")
    print("  from quantum_sync import quantum_math_cpp")
    print("  result = quantum_math_cpp.QuantumMath.fft([1.0, 2.0, 3.0])")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())



