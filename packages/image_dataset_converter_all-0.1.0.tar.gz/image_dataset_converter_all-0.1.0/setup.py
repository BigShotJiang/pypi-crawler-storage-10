from setuptools import setup


def _read(f):
    """
    Reads in the content of the file.
    :param f: the file to read
    :type f: str
    :return: the content
    :rtype: str
    """
    return open(f, 'rb').read()


setup(
    name="image_dataset_converter_all",
    description="Meta-library that combines all image_dataset_converter libraries.",
    long_description=(
            _read('DESCRIPTION.rst') + b'\n' +
            _read('CHANGES.rst')).decode('utf-8'),
    url="https://github.com/waikato-datamining/image-dataset-converter-all",
    classifiers=[
        'Development Status :: 4 - Beta',
        'License :: OSI Approved :: MIT License',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
        'Topic :: Scientific/Engineering :: Image Processing',
    ],
    license='MIT License',
    packages=[],
    install_requires=[
        "kasperl_plots>=0.0.1",
        "image_dataset_converter>=0.1.0",
        "image_dataset_converter_imgaug>=0.1.0",
        "image_dataset_converter_imgstats>=0.1.0",
        "image_dataset_converter_imgvis>=0.1.0",
        "image_dataset_converter_labelme>=0.1.0",
        "image_dataset_converter_paddle>=0.1.0",
        "image_dataset_converter_pdf>=0.1.0",
        "image_dataset_converter_plantcv>=0.1.0",
        "image_dataset_converter_redis>=0.1.0",
        "image_dataset_converter_video>=0.1.0",
    ],
    version="0.1.0",
    author='Peter Reutemann',
    author_email='fracpete@waikato.ac.nz',
)
