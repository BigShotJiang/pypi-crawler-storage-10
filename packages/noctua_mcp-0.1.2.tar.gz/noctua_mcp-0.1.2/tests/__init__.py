"""Tests for noctua-mcp."""
