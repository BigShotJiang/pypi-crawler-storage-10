# Azlibs V1.0.0
**A Family Dev Project**

## in Package
- RSA & OAEP PROJECT

###  Features on RSA & OAEP
-  RSA key generation (512–4096 bits)
-  OAEP secure padding (SHA-256)
-  Text encryption & decryption
-  Digital signature support (sign & verify)
-  Pure Python — no external dependencies

##  Installation Azlibs
```
pip install azlibs
```

## Usage of RSA

### Generate RSA Keypair
```python
from Azlib.RSATools import genkey

# Generate a 2048-bit RSA keypair
public_key, private_key = genkey(2048)

print("Public Key:", public_key)
print("Private Key:", private_key)
```

### Encrypt and Decrypt Text
```python
from Azlib.RSATools import encrypt_text, decrypt_text

message = "Hello from AkzDev!"
cipher = encrypt_text(message, public_key)
print("Encrypted:", cipher)

decrypted = decrypt_text(cipher, private_key)
print("Decrypted:", decrypted)
```

Output (contoh):
```
Encrypted: 592031591054735219...
Decrypted: Hello from AkzDev!
```

### Sign and Verify Messages
```python
from Azlib.RSATools import sign_message, verify_signature

msg = "This is an important message"
signature = sign_message(msg, private_key)
print("Signature:", signature)

# Verification
is_valid = verify_signature(msg, signature, public_key)
print("Valid:", is_valid)
```

Output (contoh):
```
Signature: 38475018274018247...
Valid: True
```

## License
This project is licensed under the MIT License — see LICENSE for details.  
Made with love by AkzDev Team  
A project proudly part of the Akuzz Open Source Ecosystem.

### Note
Azlibs is still in Version 1.0.0

“Azlibs: simple, powerful, and open for every developer.”