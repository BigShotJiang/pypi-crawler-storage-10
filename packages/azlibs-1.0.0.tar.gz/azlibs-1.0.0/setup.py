from setuptools import setup, find_packages

setup(
    name="azlibs",
    version="1.0.0",
    author="AkzDev",
    author_email="",
    description="Azlibs — a Package for dev library by AkzDev",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://linxa.xyz/index/azlibs",
    project_urls={
        "Bug Tracker": "https://linxa.xyz/issue",
        "Documentation": "https://linxa.xyz/index/azlibs/wiki",
    },
    license="MIT",
    packages=find_packages(),
    include_package_data=True,
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Topic :: Security :: Cryptography",
        "Operating System :: OS Independent",
    ],
    keywords=[
        "rsa",
        "oaep",
        "cryptography",
        "akzdev",
        "azlibs",
        "encryption",
        "security",
        "python-library"
    ],
)
