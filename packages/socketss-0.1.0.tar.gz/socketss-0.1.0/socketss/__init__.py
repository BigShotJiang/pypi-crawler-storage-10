"""socketss - Tek satırda socket programlama"""
import socket as socket_module
import threading
import time

__version__ = "0.1.0"
__author__ = "Özgür"

class socket:
    """Socket wrapper sınıfı"""
    socket = socket_module.socket
    AF_INET = socket_module.AF_INET
    SOCK_STREAM = socket_module.SOCK_STREAM
    SOL_SOCKET = socket_module.SOL_SOCKET
    SO_REUSEADDR = socket_module.SO_REUSEADDR
    
    @staticmethod
    def easy_server(port=5000, host="0.0.0.0"):
        """Tek satırda sunucu başlat"""
        server = socket_module.socket()
        server.setsockopt(socket_module.SOL_SOCKET, socket_module.SO_REUSEADDR, 1)
        server.bind((host, port))
        server.listen(5)
        print(f"✅ Sunucu {host}:{port} adresinde başlatıldı!")
        return server
    
    @staticmethod
    def easy_client(host, port):
        """Tek satırda istemci bağlan"""
        client = socket_module.socket()
        client.connect((host, port))
        print(f"✅ {host}:{port} adresine bağlandı!")
        return client
    
    @staticmethod
    def send_message(sock, message):
        """Mesaj gönder (otomatik UTF-8)"""
        if isinstance(message, str):
            message = message.encode('utf-8')
        sock.send(message)
    
    @staticmethod
    def receive_message(sock, buffer=1024):
        """Mesaj al (otomatik UTF-8)"""
        data = sock.recv(buffer)
        return data.decode('utf-8') if data else ""


class EasyServer:
    """Otomatik sunucu - tek satırda çalışan sunucu"""
    
    def __init__(self, port=5000, host="0.0.0.0", on_message=None):
        """
        Args:
            port: Port numarası
            host: Host adresi
            on_message: Mesaj geldiğinde çağrılacak fonksiyon
        """
        self.server = socket_module.socket()
        self.server.setsockopt(socket_module.SOL_SOCKET, socket_module.SO_REUSEADDR, 1)
        self.server.bind((host, port))
        self.server.listen(5)
        self.host = host
        self.port = port
        self.on_message = on_message
        self.running = False
        self.connections = []
        print(f"✅ Sunucu {host}:{port} adresinde başlatıldı!")
    
    def handle_client(self, conn, addr):
        """Her client için ayrı thread"""
        print(f"📱 Yeni bağlantı: {addr}")
        self.connections.append(conn)
        
        try:
            while self.running:
                data = conn.recv(1024)
                if not data:
                    break
                
                message = data.decode('utf-8')
                print(f"📨 {addr}: {message}")
                
                # Kullanıcı fonksiyonu çağır
                if self.on_message:
                    response = self.on_message(message, addr)
                    if response:
                        conn.send(response.encode('utf-8'))
                else:
                    # Varsayılan: echo
                    conn.send(f"Echo: {message}".encode('utf-8'))
        
        except Exception as e:
            print(f"❌ Hata: {e}")
        finally:
            print(f"👋 {addr} bağlantısı koptu")
            self.connections.remove(conn)
            conn.close()
    
    def start(self):
        """Sunucuyu başlat (arka planda)"""
        self.running = True
        
        def accept_loop():
            while self.running:
                try:
                    conn, addr = self.server.accept()
                    client_thread = threading.Thread(
                        target=self.handle_client,
                        args=(conn, addr),
                        daemon=True
                    )
                    client_thread.start()
                except:
                    break
        
        thread = threading.Thread(target=accept_loop, daemon=True)
        thread.start()
        print("🚀 Sunucu başlatıldı! (Arka planda çalışıyor)")
    
    def broadcast(self, message):
        """Tüm bağlı clientlara mesaj gönder"""
        if isinstance(message, str):
            message = message.encode('utf-8')
        
        for conn in self.connections:
            try:
                conn.send(message)
            except:
                pass
    
    def stop(self):
        """Sunucuyu durdur"""
        self.running = False
        for conn in self.connections:
            conn.close()
        self.server.close()
        print("🛑 Sunucu durduruldu")


class EasyClient:
    """Otomatik istemci - tek satırda çalışan client"""
    
    def __init__(self, host, port, on_message=None):
        """
        Args:
            host: Bağlanılacak host
            port: Bağlanılacak port
            on_message: Mesaj geldiğinde çağrılacak fonksiyon
        """
        self.client = socket_module.socket()
        self.client.connect((host, port))
        self.host = host
        self.port = port
        self.on_message = on_message
        self.running = False
        print(f"✅ {host}:{port} adresine bağlandı!")
    
    def send(self, message):
        """Mesaj gönder"""
        if isinstance(message, str):
            message = message.encode('utf-8')
        self.client.send(message)
    
    def receive(self, buffer=1024):
        """Mesaj al"""
        data = self.client.recv(buffer)
        return data.decode('utf-8') if data else ""
    
    def start_listening(self):
        """Arka planda mesaj dinlemeye başla"""
        self.running = True
        
        def listen_loop():
            while self.running:
                try:
                    data = self.client.recv(1024)
                    if not data:
                        break
                    
                    message = data.decode('utf-8')
                    print(f"📨 Sunucu: {message}")
                    
                    if self.on_message:
                        self.on_message(message)
                
                except Exception as e:
                    if self.running:
                        print(f"❌ Hata: {e}")
                    break
        
        thread = threading.Thread(target=listen_loop, daemon=True)
        thread.start()
        print("👂 Dinleme başladı!")
    
    def close(self):
        """Bağlantıyı kapat"""
        self.running = False
        self.client.close()
        print("👋 Bağlantı kapatıldı")


# TEK SATIRLIK FONKSİYONLAR

def quick_server(port=5000, message_handler=None):
    """
    Tek satırda sunucu başlat ve çalıştır
    
    Örnek:
        socketss.quick_server(8000, lambda msg, addr: f"Aldım: {msg}")
    """
    server = EasyServer(port=port, on_message=message_handler)
    server.start()
    return server


def quick_client(host, port, message_handler=None):
    """
    Tek satırda client oluştur
    
    Örnek:
        client = socketss.quick_client("localhost", 8000)
        client.send("Merhaba!")
    """
    client = EasyClient(host, port, on_message=message_handler)
    return client


def chat_server(port=5000):
    """Tek satırda chat sunucusu"""
    server = EasyServer(port=port)
    server.start()
    
    print("\n💬 Chat Sunucusu Başladı!")
    print("Mesaj göndermek için yazın, çıkmak için 'exit'")
    
    try:
        while True:
            message = input("\n📤 Broadcast mesaj: ")
            if message.lower() == 'exit':
                break
            server.broadcast(f"[Sunucu]: {message}")
    except KeyboardInterrupt:
        pass
    finally:
        server.stop()


def chat_client(host="localhost", port=5000):
    """Tek satırda chat istemcisi"""
    client = EasyClient(host, port)
    client.start_listening()
    
    print("\n💬 Chat'e Bağlandınız!")
    print("Mesaj göndermek için yazın, çıkmak için 'exit'")
    
    try:
        while True:
            message = input("\n📤 Mesajınız: ")
            if message.lower() == 'exit':
                break
            client.send(message)
    except KeyboardInterrupt:
        pass
    finally:
        client.close()


# Yardımcı fonksiyonlar
def get_local_ip():
    """Yerel IP adresini döndürür"""
    s = socket_module.socket(socket_module.AF_INET, socket_module.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip


def is_port_open(host, port, timeout=2):
    """Port açık mı kontrol et"""
    try:
        s = socket_module.socket(socket_module.AF_INET, socket_module.SOCK_STREAM)
        s.settimeout(timeout)
        result = s.connect_ex((host, port))
        s.close()
        return result == 0
    except:
        return False


def scan_ports(host, start_port=1, end_port=100, timeout=0.5):
    """Port taraması yap"""
    open_ports = []
    print(f"🔍 {host} taranıyor ({start_port}-{end_port})...")
    for port in range(start_port, end_port + 1):
        if is_port_open(host, port, timeout):
            open_ports.append(port)
            print(f"  ✅ Port {port} açık")
    return open_ports


__all__ = [
    'socket', 
    'EasyServer', 
    'EasyClient',
    'quick_server',
    'quick_client',
    'chat_server',
    'chat_client',
    'get_local_ip', 
    'is_port_open', 
    'scan_ports'
]