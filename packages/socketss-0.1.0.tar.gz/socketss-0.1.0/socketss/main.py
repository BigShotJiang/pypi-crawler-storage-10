import socketss as socketss_module  # Kendi paketiniz (socketss)

class socket:
    socket = socketss_module.socket