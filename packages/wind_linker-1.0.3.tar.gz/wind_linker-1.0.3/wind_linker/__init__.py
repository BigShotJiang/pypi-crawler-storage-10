"""
Wind Linker - Wind 数据本地转发 API 客户端

使用方法:
    from wind_linker import w
    
    # 查询数据
    data = w.wsd("000001.SZ", "close", "2025-01-01", "2025-01-10")
    
    # 转换为 DataFrame
    df = data.to_df()
"""

from .client import WindAPI

# 创建全局实例
w = WindAPI()

__version__ = "1.0.3"
__all__ = ["w", "WindAPI"]

