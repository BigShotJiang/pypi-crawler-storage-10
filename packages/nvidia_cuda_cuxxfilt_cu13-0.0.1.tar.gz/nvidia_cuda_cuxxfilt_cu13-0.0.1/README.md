⚠️ THIS PROJECT 'nvidia-cuda-cuxxfilt-cu13' IS DEPRECATED.
Please use 'nvidia-cuda-cuxxfilt' instead.

To install the correct package, use:

    pip install nvidia-cuda-cuxxfilt

For more information, visit: https://pypi.org/project/nvidia-cuda-cuxxfilt/
