"""Version information for test-api-x."""

__version__ = "0.3.0"
