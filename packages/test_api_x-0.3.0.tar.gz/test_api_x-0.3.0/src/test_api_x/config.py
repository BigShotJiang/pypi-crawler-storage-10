"""Configuration management for test-api-x.

Provides centralized configuration loading from environment variables and .env files.
"""

import os
from pathlib import Path
from typing import Any

from dotenv import dotenv_values

from test_api_x.exceptions import ConfigurationError


class Config:
    """Configuration manager for test environments.

    Supports loading configuration from:
    - Environment variables
    - .env files
    - Auto-detection based on ENV variable

    Examples:
        # Load from environment variables
        config = Config.from_env()

        # Load from specific .env file
        config = Config.from_file(".env.staging")

        # Auto-load based on ENV variable
        config = Config.auto()  # Loads .env.{ENV} or .env or environ

        # Access configuration
        api_url = config.api_base_url
        env = config.env
        custom = config.get("CUSTOM_KEY", "default")
    """

    def __init__(self, data: dict[str, Any]):
        """Initialize configuration with data dictionary.

        Args:
            data: Configuration data (typically from environment or .env file)
        """
        self.data = data
        self.env: str = data.get("ENV") or "dev"
        self.api_base_url: str | None = data.get("API_BASE_URL")

    @classmethod
    def from_env(cls) -> "Config":
        """Load configuration from environment variables.

        Returns:
            Config instance with data from os.environ

        Examples:
            config = Config.from_env()
            print(config.env)  # Current ENV value or 'dev'
        """
        return cls(dict(os.environ))

    @classmethod
    def from_file(cls, filepath: str) -> "Config":
        """Load configuration from .env file.

        Args:
            filepath: Path to .env file

        Returns:
            Config instance with data from file

        Raises:
            ConfigurationError: If file cannot be loaded

        Examples:
            config = Config.from_file(".env.staging")
        """
        try:
            data = dotenv_values(filepath)
            # Convert None values to empty dict for consistency
            config_data = {k: v for k, v in data.items() if v is not None}
            return cls(config_data)
        except Exception as e:
            raise ConfigurationError(
                f"Failed to load config from {filepath}: {e}"
            ) from e

    @classmethod
    def auto(cls, env: str | None = None) -> "Config":
        """Auto-load configuration with priority-based detection.

        Loading priority:
        1. .env.{env} file (if exists)
        2. .env file (if exists)
        3. Environment variables (fallback)

        Args:
            env: Environment name (uses ENV variable if None)

        Returns:
            Config instance from best available source

        Examples:
            # Auto-detect from ENV variable
            config = Config.auto()

            # Explicit environment
            config = Config.auto(env="staging")
        """
        # Determine environment
        target_env = env or os.getenv("ENV", "dev")

        # Priority 1: .env.{env} file
        env_file = Path(f".env.{target_env}")
        if env_file.exists():
            return cls.from_file(str(env_file))

        # Priority 2: .env file
        generic_env_file = Path(".env")
        if generic_env_file.exists():
            return cls.from_file(str(generic_env_file))

        # Priority 3: Environment variables
        return cls.from_env()

    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value by key.

        Args:
            key: Configuration key
            default: Default value if key not found

        Returns:
            Configuration value or default

        Examples:
            db_url = config.get("DATABASE_URL", "sqlite:///test.db")
        """
        return self.data.get(key, default)

    def __repr__(self) -> str:
        """String representation for debugging.

        Returns:
            Readable string showing env and config count
        """
        return f"<Config env={self.env!r} keys={len(self.data)}>"
