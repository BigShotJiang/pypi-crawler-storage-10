"""Example plugin demonstrating the plugin system."""

from collections.abc import Callable
from typing import Any

from test_api_x.plugins.base import Plugin


class ExampleHelper:
    """Example helper provided by the plugin."""

    def __init__(self, config: dict[str, Any] | None = None):
        """Initialize the helper.

        Args:
            config: Optional configuration dictionary
        """
        self.config = config or {}

    def greet(self, name: str) -> str:
        """Return a greeting message.

        Args:
            name: Name to greet

        Returns:
            Greeting message
        """
        prefix = self.config.get("greeting_prefix", "Hello")
        return f"{prefix}, {name}!"

    def process_data(self, data: dict[str, Any]) -> dict[str, Any]:
        """Process data with the helper.

        Args:
            data: Input data

        Returns:
            Processed data
        """
        return {"processed": True, "original": data, **self.config}


class ExamplePlugin(Plugin):
    """Example plugin demonstrating the plugin system.

    This plugin shows how to:
    - Implement the Plugin interface
    - Register fixtures
    - Provide configuration
    - Use from_env() for initialization

    Example:
        # Manual registration
        manager = PluginManager()
        plugin = ExamplePlugin()
        manager.register(plugin)

        # Use the fixture
        helper = manager.get_fixture("example_helper")()
        result = helper.greet("World")

        # Or via entry point discovery (in pyproject.toml):
        [project.entry-points."test_api_x.plugins"]
        example = "test_api_x.plugins.examples:ExamplePlugin"
    """

    def __init__(self, config: dict[str, Any] | None = None):
        """Initialize the example plugin.

        Args:
            config: Optional configuration dictionary
        """
        self._config = config or {}

    @property
    def name(self) -> str:
        """Return the plugin name."""
        return "example"

    def register_fixtures(self) -> dict[str, Callable[..., Any]]:
        """Register fixtures provided by this plugin.

        Returns:
            Dictionary of fixture name to fixture callable
        """
        return {"example_helper": self._example_helper_fixture}

    def register_auth_providers(self) -> dict[str, type]:
        """Register auth providers.

        This example plugin doesn't provide any auth providers.

        Returns:
            Empty dictionary
        """
        return {}

    def _example_helper_fixture(self) -> ExampleHelper:
        """Fixture that returns an ExampleHelper instance.

        Returns:
            Configured ExampleHelper instance
        """
        return ExampleHelper(config=self._config)

    @classmethod
    def from_env(cls) -> "ExamplePlugin":
        """Initialize plugin from environment variables.

        Reads EXAMPLE_PLUGIN_GREETING_PREFIX from environment.

        Returns:
            Configured plugin instance
        """
        import os

        config = {}
        greeting_prefix = os.getenv("EXAMPLE_PLUGIN_GREETING_PREFIX")
        if greeting_prefix:
            config["greeting_prefix"] = greeting_prefix

        return cls(config=config)
