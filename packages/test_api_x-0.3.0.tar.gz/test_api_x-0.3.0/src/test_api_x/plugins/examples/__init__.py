"""Example plugins demonstrating the plugin system."""

from test_api_x.plugins.examples.example_plugin import ExamplePlugin

__all__ = ["ExamplePlugin"]
