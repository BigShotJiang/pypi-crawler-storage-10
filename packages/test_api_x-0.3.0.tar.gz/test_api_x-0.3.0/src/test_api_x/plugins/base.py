"""Base class for test-api-x plugins."""

from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any


class Plugin(ABC):
    """Abstract base class for test-api-x plugins.

    Plugins extend test-api-x with custom functionality:
    - Pytest fixtures for test helpers
    - Authentication providers for new auth methods
    - Custom configuration and initialization

    Example:
        class MyPlugin(Plugin):
            @property
            def name(self) -> str:
                return "my_plugin"

            def register_fixtures(self) -> dict[str, Callable[..., Any]]:
                return {"my_fixture": self._my_fixture}

            def register_auth_providers(self) -> dict[str, type]:
                return {"my_auth": MyAuthProvider}

            def _my_fixture(self):
                return MyHelper()
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Return the plugin name for registration.

        The name must be unique across all plugins and will be used
        to identify the plugin in the plugin manager.

        Returns:
            Unique plugin name (e.g., "aws", "database", "custom_auth")
        """

    @abstractmethod
    def register_fixtures(self) -> dict[str, Callable[..., Any]]:
        """Return pytest fixtures this plugin provides.

        Fixtures are callable functions that return test helpers or resources.
        They will be made available to tests through the plugin manager.

        Returns:
            Dictionary mapping fixture names to callable fixture functions

        Example:
            def register_fixtures(self):
                return {
                    "db_connection": self._db_fixture,
                    "api_mock": self._mock_fixture
                }
        """

    @abstractmethod
    def register_auth_providers(self) -> dict[str, type]:
        """Return authentication providers this plugin adds.

        Auth providers are classes that implement the AuthProvider protocol
        and handle authentication for specific auth methods.

        Returns:
            Dictionary mapping provider names to provider classes

        Example:
            def register_auth_providers(self):
                from my_plugin.auth import AWSAuthProvider
                return {"aws": AWSAuthProvider}
        """

    @classmethod
    def from_env(cls) -> "Plugin":
        """Initialize plugin from environment variables.

        This method provides a default implementation that creates a plugin
        instance with no arguments. Plugins that require configuration should
        override this method to read environment variables or config files.

        Returns:
            Initialized plugin instance

        Example:
            @classmethod
            def from_env(cls):
                import os
                config = {
                    "api_key": os.getenv("MY_PLUGIN_API_KEY"),
                    "endpoint": os.getenv("MY_PLUGIN_ENDPOINT")
                }
                return cls(config=config)
        """
        return cls()
