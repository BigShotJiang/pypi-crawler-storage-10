"""Plugin system for extending test-api-x functionality."""

from test_api_x.plugins.base import Plugin
from test_api_x.plugins.manager import PluginManager

__all__ = ["Plugin", "PluginManager"]
