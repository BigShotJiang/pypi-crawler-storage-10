"""Plugin manager for discovering and managing plugins."""

from collections.abc import Callable
from typing import Any

from test_api_x.plugins.base import Plugin


class PluginManager:
    """Manages plugin discovery, registration, and access.

    The PluginManager handles:
    - Automatic plugin discovery via entry points
    - Manual plugin registration
    - Fixture and auth provider management
    - Conflict resolution for duplicate names

    Example:
        manager = PluginManager()
        manager.discover_plugins()

        # Get fixture from any registered plugin
        my_fixture = manager.get_fixture("db_connection")

        # Get auth provider from any registered plugin
        provider_class = manager.get_provider("aws")
    """

    def __init__(self) -> None:
        """Initialize an empty plugin manager."""
        self.plugins: dict[str, Plugin] = {}
        self.fixtures: dict[str, Callable[..., Any]] = {}
        self.auth_providers: dict[str, type] = {}

    def discover_plugins(self) -> None:
        """Auto-discover plugins via entry points.

        Scans for entry points in the 'test_api_x.plugins' group and
        automatically loads and registers all discovered plugins.

        Entry points are defined in plugin packages' pyproject.toml:
            [project.entry-points."test_api_x.plugins"]
            my_plugin = "my_package.plugin:MyPlugin"
        """
        from importlib.metadata import entry_points

        # Get entry points for test_api_x.plugins group
        eps = entry_points(group="test_api_x.plugins")

        for ep in eps:
            try:
                # Load the plugin class
                plugin_class = ep.load()

                # Instantiate the plugin
                plugin = plugin_class.from_env()

                # Register it
                self.register(plugin)
            except Exception as e:
                # Log but don't fail - plugins should fail gracefully
                import warnings

                warnings.warn(
                    f"Failed to load plugin from entry point '{ep.name}': {e}",
                    stacklevel=2,
                )

    def register(self, plugin: Plugin) -> None:
        """Manually register a plugin.

        Args:
            plugin: Plugin instance to register

        Raises:
            ValueError: If plugin name is already registered
            TypeError: If plugin is not a Plugin instance
        """
        if not isinstance(plugin, Plugin):
            raise TypeError(f"Expected Plugin instance, got {type(plugin)}")

        if plugin.name in self.plugins:
            raise ValueError(f"Plugin '{plugin.name}' is already registered")

        # Store the plugin
        self.plugins[plugin.name] = plugin

        # Register fixtures
        fixtures = plugin.register_fixtures()
        for fixture_name, fixture_func in fixtures.items():
            if fixture_name in self.fixtures:
                import warnings

                warnings.warn(
                    f"Fixture '{fixture_name}' from plugin '{plugin.name}' "
                    f"overwrites existing fixture",
                    stacklevel=2,
                )
            self.fixtures[fixture_name] = fixture_func

        # Register auth providers
        providers = plugin.register_auth_providers()
        for provider_name, provider_class in providers.items():
            if provider_name in self.auth_providers:
                import warnings

                warnings.warn(
                    f"Auth provider '{provider_name}' from plugin '{plugin.name}' "
                    f"overwrites existing provider",
                    stacklevel=2,
                )
            self.auth_providers[provider_name] = provider_class

    def get_fixture(self, name: str) -> Callable[..., Any]:
        """Get fixture from registered plugins.

        Args:
            name: Fixture name

        Returns:
            Fixture callable

        Raises:
            KeyError: If fixture not found
        """
        if name not in self.fixtures:
            raise KeyError(f"Fixture '{name}' not found in any registered plugin")
        return self.fixtures[name]

    def get_provider(self, name: str) -> type:
        """Get auth provider from registered plugins.

        Args:
            name: Provider name

        Returns:
            Provider class

        Raises:
            KeyError: If provider not found
        """
        if name not in self.auth_providers:
            raise KeyError(f"Auth provider '{name}' not found in any registered plugin")
        return self.auth_providers[name]
