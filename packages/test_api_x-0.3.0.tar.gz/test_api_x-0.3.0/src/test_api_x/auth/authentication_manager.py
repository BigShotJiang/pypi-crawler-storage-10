"""Authentication Manager - orchestrates auth providers and sessions."""

import time
from typing import Any

from test_api_x.auth.providers.base import AuthProvider
from test_api_x.auth.session_cache import SessionCache
from test_api_x.auth.user_registry import UserRegistry
from test_api_x.exceptions import AuthenticationError, ProviderNotFoundError
from test_api_x.logging import get_logger

logger = get_logger("auth.manager")


class AuthenticationManager:
    """Coordinates authentication providers and session management."""

    def __init__(
        self,
        session_cache: SessionCache | None = None,
        user_registry: UserRegistry | None = None,
    ) -> None:
        """Initialize authentication manager.

        Args:
            session_cache: Session cache (creates default if None)
            user_registry: User registry (creates default if None)

        """
        self.providers: dict[str, AuthProvider] = {}
        self.session_cache = session_cache or SessionCache()
        self.user_registry = user_registry or UserRegistry()

        logger.info("AuthenticationManager initialized")

    def register_provider(self, name: str, provider: AuthProvider) -> None:
        """Register an authentication provider.

        Args:
            name: Provider name ('basic', 'auth0', etc.)
            provider: Provider instance

        """
        self.providers[name] = provider
        logger.info(f"Authentication provider registered: {name}")

    async def authenticate_user(
        self, persona: str, auth_method: str | None = None
    ) -> dict[str, Any]:
        """Authenticate user by persona.

        Args:
            persona: User persona ('admin', 'user', etc.)
            auth_method: Optional auth method filter

        Returns:
            Session dict with auth data

        Raises:
            AuthenticationError: If authentication fails

        """
        # Find user
        user = self.user_registry.get_user_by_persona(persona, auth_method)
        if not user:
            raise AuthenticationError(f"No user with persona: '{persona}'")

        # Check cache
        cached_session = self.session_cache.get(user["id"])
        if cached_session and not self._is_session_expired(cached_session):
            logger.debug(f"Using cached session for user '{user['id']}'")
            return cached_session

        # Get provider
        provider = self.providers.get(user["auth_method"])
        if not provider:
            raise ProviderNotFoundError(f"No provider for: '{user['auth_method']}'")

        # Authenticate
        start_time = time.time()
        try:
            session_data = await provider.authenticate(user)
            session: dict[str, Any] = dict(session_data)

            # Add metadata
            session["user_id"] = user["id"]
            session["persona"] = persona
            session["auth_method"] = user["auth_method"]

            # Cache session
            ttl = session.get("expires_in", 3600)
            self.session_cache.set(user["id"], session, ttl)

            duration_ms = (time.time() - start_time) * 1000
            logger.log_auth_attempt(
                persona, user["auth_method"], user["id"], True, duration_ms
            )

            return session

        except Exception as e:
            duration_ms = (time.time() - start_time) * 1000
            logger.log_auth_attempt(
                persona, user["auth_method"], user["id"], False, duration_ms, str(e)
            )
            raise AuthenticationError(f"Authentication failed: {e}") from e

    def _is_session_expired(self, session: dict[str, Any]) -> bool:
        """Check if session is expired."""
        expires_at = session.get("expires_at")
        if expires_at is None:
            return False
        assert isinstance(expires_at, int | float), "expires_at must be numeric"
        return time.time() >= expires_at

    async def get_auth_headers(self, session: dict[str, Any]) -> dict[str, str]:
        """Get auth headers for session.

        Args:
            session: Session from authenticate_user()

        Returns:
            Headers dict to inject

        """
        auth_method = session.get("auth_method")
        if not auth_method:
            return {}

        provider = self.providers.get(auth_method)
        if not provider:
            return {}

        return await provider.get_headers(session)

    async def refresh_session(self, session: dict[str, Any]) -> dict[str, Any]:
        """Refresh expired session.

        Args:
            session: Expired session

        Returns:
            New session with refreshed token

        """
        auth_method = session.get("auth_method")
        if not auth_method:
            raise AuthenticationError("Session missing auth_method")

        provider = self.providers.get(auth_method)
        if not provider:
            raise ProviderNotFoundError(f"No provider for: '{auth_method}'")

        refreshed = await provider.refresh_session(session)

        # Update cache
        user_id = session.get("user_id")
        if user_id:
            ttl = refreshed.get("expires_in", 3600)
            self.session_cache.set(user_id, refreshed, ttl)

        return refreshed
