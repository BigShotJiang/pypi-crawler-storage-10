"""Abstract base class for authentication providers."""

from abc import ABC, abstractmethod
from typing import Any


class AuthProvider(ABC):
    """Base class for authentication providers.

    All auth providers must implement these methods.
    """

    @abstractmethod
    async def authenticate(self, user: dict[str, Any]) -> dict[str, Any]:
        """Authenticate user and return session data.

        Args:
            user: User config from registry

        Returns:
            Session dict with access_token, user_id, expires_at, etc.

        Raises:
            AuthenticationError: If authentication fails

        """
        ...  # pragma: no cover

    @abstractmethod
    async def get_headers(self, session: dict[str, Any]) -> dict[str, str]:
        """Get auth headers from session.

        Args:
            session: Session dict from authenticate()

        Returns:
            Headers dict to inject into requests

        """
        ...  # pragma: no cover

    async def refresh_session(self, session: dict[str, Any]) -> dict[str, Any]:
        """Refresh expired session (optional).

        Args:
            session: Expired session

        Returns:
            New session with refreshed token

        Raises:
            SessionExpiredError: If refresh not supported or fails

        """
        from test_api_x.exceptions import SessionExpiredError

        raise SessionExpiredError("Session refresh not supported by this provider")
