"""Basic Authentication Provider."""

import base64
from typing import Any

from test_api_x.auth.providers.base import AuthProvider
from test_api_x.exceptions import AuthenticationError


class BasicAuthProvider(AuthProvider):
    """Basic HTTP authentication provider.

    Uses username:password encoded in Base64.
    """

    async def authenticate(self, user: dict[str, Any]) -> dict[str, Any]:
        """Authenticate using Basic auth.

        Args:
            user: User config with 'username' and 'password'

        Returns:
            Session dict with credentials

        """
        username = user.get("username")
        password = user.get("password")

        if not username or not password:
            raise AuthenticationError("Basic auth requires username and password")

        # Encode credentials
        credentials = f"{username}:{password}".encode()
        encoded = base64.b64encode(credentials).decode("utf-8")

        return {
            "auth_type": "basic",
            "username": username,
            "encoded_credentials": encoded,
            "expires_at": 9999999999,  # Basic auth doesn't expire
        }

    async def get_headers(self, session: dict[str, Any]) -> dict[str, str]:
        """Get Basic auth header.

        Returns:
            Authorization header with Basic auth

        """
        encoded = session.get("encoded_credentials")
        if not encoded:
            raise AuthenticationError("Session missing encoded_credentials")

        return {"Authorization": f"Basic {encoded}"}
