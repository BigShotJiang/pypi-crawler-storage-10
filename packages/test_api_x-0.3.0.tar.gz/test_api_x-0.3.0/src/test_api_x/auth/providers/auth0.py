"""Auth0 Authentication Provider with JWT token refresh."""

import time
from typing import Any

import httpx

from test_api_x.auth.providers.base import AuthProvider
from test_api_x.exceptions import AuthenticationError, SessionExpiredError
from test_api_x.logging import get_logger

logger = get_logger("auth.auth0")


class Auth0Provider(AuthProvider):
    """Auth0 OAuth2/JWT authentication provider.

    Supports:
    - Password grant authentication
    - Automatic token refresh
    - JWT token management
    """

    def __init__(
        self,
        domain: str,
        client_id: str,
        client_secret: str,
        audience: str | None = None,
    ):
        """Initialize Auth0 provider.

        Args:
            domain: Auth0 domain (e.g., 'dev-xxx.auth0.com')
            client_id: Application client ID
            client_secret: Application client secret
            audience: API audience/identifier

        """
        self.domain = domain
        self.client_id = client_id
        self.client_secret = client_secret
        self.audience = audience
        self.token_url = f"https://{domain}/oauth/token"

    async def authenticate(self, user: dict[str, Any]) -> dict[str, Any]:
        """Authenticate with Auth0 using password grant.

        Args:
            user: User config with 'username'/'email' and 'password'

        Returns:
            Session dict with access_token, refresh_token, expires_at

        """
        username = user.get("username") or user.get("email")
        password = user.get("password")
        realm = user.get("realm")  # Optional: specify DB connection

        if not username or not password:
            raise AuthenticationError("Auth0 requires username/email and password")

        # Use password-realm grant when realm is specified
        if realm:
            payload = {
                "grant_type": "http://auth0.com/oauth/grant-type/password-realm",
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "username": username,
                "password": password,
                "realm": realm,
                "scope": "openid profile email offline_access",
            }
        else:
            payload = {
                "grant_type": "password",
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "username": username,
                "password": password,
                "scope": "openid profile email offline_access",
            }

        if self.audience:
            payload["audience"] = self.audience

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(self.token_url, json=payload)

                if response.status_code != 200:
                    error_msg = response.json().get("error_description", "Auth failed")
                    raise AuthenticationError(
                        f"Auth0 authentication failed: {error_msg}"
                    )

                data = response.json()

                return {
                    "auth_type": "auth0",
                    "access_token": data["access_token"],
                    "refresh_token": data.get("refresh_token"),
                    "token_type": data.get("token_type", "Bearer"),
                    "expires_in": data.get("expires_in", 86400),
                    "expires_at": time.time() + data.get("expires_in", 86400),
                    "scope": data.get("scope"),
                }

        except httpx.RequestError as e:
            raise AuthenticationError(f"Auth0 request failed: {e}") from e

    async def get_headers(self, session: dict[str, Any]) -> dict[str, str]:
        """Get Bearer token header.

        Returns:
            Authorization header with Bearer token

        """
        access_token = session.get("access_token")
        if not access_token:
            raise AuthenticationError("Session missing access_token")

        token_type = session.get("token_type", "Bearer")
        return {"Authorization": f"{token_type} {access_token}"}

    async def refresh_session(self, session: dict[str, Any]) -> dict[str, Any]:
        """Refresh expired Auth0 session.

        Args:
            session: Expired session with refresh_token

        Returns:
            New session with fresh tokens

        Raises:
            SessionExpiredError: If refresh fails

        """
        refresh_token = session.get("refresh_token")
        if not refresh_token:
            raise SessionExpiredError("Session missing refresh_token")

        payload = {
            "grant_type": "refresh_token",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "refresh_token": refresh_token,
        }

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(self.token_url, json=payload)

                if response.status_code != 200:
                    error_msg = response.json().get(
                        "error_description", "Refresh failed"
                    )
                    raise SessionExpiredError(f"Token refresh failed: {error_msg}")

                data = response.json()

                # Return new session with updated tokens
                return {
                    **session,  # Keep existing session data
                    "access_token": data["access_token"],
                    "refresh_token": data.get("refresh_token", refresh_token),
                    "expires_in": data.get("expires_in", 86400),
                    "expires_at": time.time() + data.get("expires_in", 86400),
                }

        except httpx.RequestError as e:
            raise SessionExpiredError(f"Token refresh request failed: {e}") from e
