"""Session Cache - in-memory cache for auth sessions."""

import time
from typing import Any, TypedDict


class CacheEntry(TypedDict):
    """Cache entry structure."""

    session: dict[str, Any]
    expires_at: float
    cached_at: float


class SessionCache:
    """In-memory cache for authenticated sessions.

    Caches sessions with TTL to avoid repeated authentication.
    """

    def __init__(self, default_ttl: int = 3600):
        """Initialize session cache.

        Args:
            default_ttl: Default TTL in seconds (1 hour)

        """
        self.cache: dict[str, CacheEntry] = {}
        self.default_ttl = default_ttl

    def set(
        self, user_id: str, session: dict[str, Any], ttl: int | None = None
    ) -> None:
        """Cache a session.

        Args:
            user_id: User identifier
            session: Session data to cache
            ttl: TTL in seconds (uses default if None)

        """
        cache_ttl = ttl if ttl is not None else self.default_ttl
        expires_at = time.time() + cache_ttl

        self.cache[user_id] = {
            "session": session,
            "expires_at": expires_at,
            "cached_at": time.time(),
        }

    def get(self, user_id: str) -> dict[str, Any] | None:
        """Get cached session if not expired.

        Args:
            user_id: User identifier

        Returns:
            Session dict or None if not found/expired

        """
        if user_id not in self.cache:
            return None

        cached = self.cache[user_id]

        # Check if expired
        if time.time() >= cached["expires_at"]:
            del self.cache[user_id]
            return None

        return cached["session"]

    def invalidate(self, user_id: str) -> None:
        """Invalidate cached session."""
        if user_id in self.cache:
            del self.cache[user_id]

    def clear(self) -> None:
        """Clear all cached sessions."""
        self.cache.clear()

    def get_ttl(self, user_id: str) -> int | None:
        """Get remaining TTL for cached session.

        Returns:
            TTL in seconds or None if not cached

        """
        if user_id not in self.cache:
            return None

        cached = self.cache[user_id]
        remaining = int(cached["expires_at"] - time.time())

        return max(0, remaining)
