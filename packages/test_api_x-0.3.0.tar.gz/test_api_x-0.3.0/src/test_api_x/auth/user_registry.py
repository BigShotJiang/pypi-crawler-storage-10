"""User Registry - manages test user personas and credentials with pool support."""

import json
import os
import random
import re
from pathlib import Path
from typing import Any

from test_api_x.exceptions import ConfigurationError


class UserRegistry:
    """Registry of test users with personas, credentials, and pool management.

    Supports:
    - Multiple user pools (dev, staging, prod)
    - Pool-level authentication configuration
    - Environment variable substitution in JSON
    - Auto-loading from multiple sources

    Examples:
        # Auto-load from environment
        registry = UserRegistry.auto()

        # Get user from active pool
        user = registry.get_user(persona="admin")

        # Get user from specific pool
        user = registry.get_user(persona="admin", pool="staging")

        # Random user for parallel testing
        user = registry.get_random_user(persona="admin")
    """

    def __init__(
        self,
        test_users_json: str | None = None,
        active_pool: str | None = None,
    ):
        """Initialize user registry.

        Args:
            test_users_json: JSON string of test users (from env if None)
            active_pool: Active pool name (from ENV var if None)
        """
        self.pools: dict[str, dict[str, Any]] = {}
        self.users: list[dict[str, Any]] = []  # For backward compatibility
        self.active_pool: str = active_pool or os.getenv("ENV") or "dev"
        self._user_counters: dict[str, int] = {}  # For round-robin

        if test_users_json is None:
            test_users_json = os.getenv("TEST_USERS", "[]")

        self._load_users(test_users_json)

    @classmethod
    def auto(cls, active_pool: str | None = None) -> "UserRegistry":
        """Auto-load registry from multiple sources with priority.

        Loading priority:
        1. TEST_USERS_JSON env var (inline JSON)
        2. TEST_USERS_FILE env var (path to file)
        3. config/users.json (default location)
        4. Empty registry (programmatic setup)

        Args:
            active_pool: Active pool name (from ENV if None)

        Returns:
            Configured UserRegistry instance

        Examples:
            registry = UserRegistry.auto()
            registry = UserRegistry.auto(active_pool="staging")
        """
        # Ensure active_pool is always str for type safety
        if active_pool is None:
            active_pool = os.getenv("ENV", "dev")
        pool: str = active_pool

        # Priority 1: TEST_USERS_JSON env var
        test_users_json = os.getenv("TEST_USERS_JSON")
        if test_users_json:
            return cls(test_users_json=test_users_json, active_pool=pool)

        # Priority 2: TEST_USERS_FILE env var
        test_users_file = os.getenv("TEST_USERS_FILE")
        if test_users_file:
            return cls._load_from_file(test_users_file, pool)

        # Priority 3: config/users.json
        default_path = Path("config/users.json")
        if default_path.exists():
            return cls._load_from_file(str(default_path), pool)

        # Priority 4: Empty registry
        return cls(test_users_json="[]", active_pool=pool)

    @classmethod
    def _load_from_file(cls, filepath: str, active_pool: str) -> "UserRegistry":
        """Load registry from JSON file.

        Args:
            filepath: Path to JSON file
            active_pool: Active pool name

        Returns:
            UserRegistry instance
        """
        try:
            with open(filepath, encoding="utf-8") as f:
                json_content = f.read()
            return cls(test_users_json=json_content, active_pool=active_pool)
        except FileNotFoundError as e:
            raise ConfigurationError(f"User file not found: {filepath}") from e
        except Exception as e:
            raise ConfigurationError(
                f"Failed to load users from {filepath}: {e}"
            ) from e

    def _load_users(self, json_str: str) -> None:
        """Load users from JSON string with environment variable substitution.

        Supports both:
        - New pool-based structure: {"pools": {...}}
        - Legacy flat structure: [{"id": "user1", ...}]

        Args:
            json_str: JSON string
        """
        try:
            # Substitute environment variables first
            json_str = self._substitute_env_vars(json_str)

            users_data = json.loads(json_str)

            # Check if pool-based structure
            if isinstance(users_data, dict) and "pools" in users_data:
                self._load_from_pools(users_data)
            # Legacy flat structure
            elif isinstance(users_data, list):
                self._load_from_flat_list(users_data)
            else:
                raise ConfigurationError(
                    "TEST_USERS must be a JSON array or pool-based object"
                )

        except json.JSONDecodeError as e:
            raise ConfigurationError(f"Invalid TEST_USERS JSON: {e}") from e

    def _substitute_env_vars(self, text: str) -> str:
        """Substitute environment variables in text.

        Supports:
        - ${VAR} - simple substitution
        - ${VAR:-default} - substitution with default value

        Args:
            text: Text with ${VAR} placeholders

        Returns:
            Text with substituted values

        Examples:
            "${API_URL}" -> "https://api.example.com"
            "${MISSING:-default}" -> "default"
        """

        def replace_var(match: re.Match[str]) -> str:
            """Replace a single variable match."""
            full_match = match.group(1)

            # Check for default value syntax: VAR:-default
            if ":-" in full_match:
                var_name, default_value = full_match.split(":-", 1)
                return os.getenv(var_name.strip(), default_value.strip())
            else:
                # Simple substitution, keep ${VAR} if not found
                var_name = full_match.strip()
                value = os.getenv(var_name)
                if value is None:
                    # Keep original placeholder if var not found
                    return match.group(0)
                return value

        # Pattern matches ${VAR} or ${VAR:-default}
        pattern = r"\$\{([^}]+)\}"
        return re.sub(pattern, replace_var, text)

    def _load_from_pools(self, data: dict[str, Any]) -> None:
        """Load users from pool-based structure.

        Args:
            data: Pool-based config dict
        """
        self.pools = data.get("pools", {})

        # Set active pool from default_pool if specified
        default_pool = data.get("default_pool")
        if default_pool:
            self.active_pool = default_pool

        # Validate pools
        for pool_name, pool_data in self.pools.items():
            if not isinstance(pool_data, dict):
                raise ConfigurationError(f"Pool '{pool_name}' must be an object")

            users = pool_data.get("users", [])
            if not isinstance(users, list):
                raise ConfigurationError(f"Pool '{pool_name}' users must be an array")

            # Validate each user
            for user in users:
                self._validate_user(user)

    def _load_from_flat_list(self, users_data: list[dict[str, Any]]) -> None:
        """Load users from legacy flat list structure.

        Args:
            users_data: List of user dicts
        """
        for user in users_data:
            self._validate_user(user)
            self.users.append(user)

    def _validate_user(self, user: dict[str, Any]) -> None:
        """Validate user config has required fields.

        Args:
            user: User dict

        Raises:
            ConfigurationError: If validation fails
        """
        required = ["id", "persona", "auth_method"]
        missing = [f for f in required if f not in user]

        if missing:
            raise ConfigurationError(
                f"User missing required fields: {', '.join(missing)}"
            )

    def _merge_auth_config(
        self, user: dict[str, Any], pool_auth_config: dict[str, Any]
    ) -> dict[str, Any]:
        """Merge pool-level auth config into user.

        Pool config provides defaults, user can override.

        Args:
            user: User dict
            pool_auth_config: Pool-level auth config

        Returns:
            User dict with merged auth config
        """
        # Create copy to avoid modifying original
        merged_user = dict(user)

        # Get auth config for this user's auth method
        auth_method = user.get("auth_method")
        if not auth_method:
            return merged_user

        method_config = pool_auth_config.get(auth_method, {})

        # Merge pool config into user (user values take precedence)
        for key, value in method_config.items():
            if key not in merged_user:
                merged_user[key] = value

        return merged_user

    def get_user(
        self,
        persona: str | None = None,
        user_id: str | None = None,
        pool: str | None = None,
        auth_method: str | None = None,
    ) -> dict[str, Any] | None:
        """Get user by persona or ID with pool support.

        Args:
            persona: User persona ('admin', 'user', etc.)
            user_id: Specific user ID
            pool: Pool name (uses active pool if None)
            auth_method: Filter by auth method

        Returns:
            User dict with merged auth config or None if not found

        Examples:
            user = registry.get_user(persona="admin")
            user = registry.get_user(user_id="prod_admin_1", pool="prod")
        """
        # Ensure pool is str for type safety (active_pool is always str from __init__)
        pool_name = pool if pool is not None else self.active_pool

        # Check pools first
        if self.pools:
            pool_data = self.pools.get(pool_name)
            if not pool_data:
                return None

            users = pool_data.get("users", [])
            auth_config = pool_data.get("auth_config", {})

            for user in users:
                # Match by user_id or persona
                if (
                    user_id
                    and user.get("id") == user_id
                    or (
                        persona
                        and user.get("persona") == persona
                        and (
                            auth_method is None
                            or user.get("auth_method") == auth_method
                        )
                    )
                ):
                    return self._merge_auth_config(user, auth_config)

        # Fallback to flat list (backward compatibility)
        for user in self.users:
            if (
                user_id
                and user.get("id") == user_id
                or (
                    persona
                    and user.get("persona") == persona
                    and (auth_method is None or user.get("auth_method") == auth_method)
                )
            ):
                return user

        return None

    def get_pool_users(
        self, pool: str | None = None, persona: str | None = None
    ) -> list[dict[str, Any]]:
        """Get all users from a pool, optionally filtered by persona.

        Args:
            pool: Pool name (uses active pool if None)
            persona: Optional persona filter

        Returns:
            List of user dicts with merged auth config

        Examples:
            all_users = registry.get_pool_users("staging")
            admins = registry.get_pool_users("staging", persona="admin")
        """
        # Ensure pool is str for type safety (active_pool is always str from __init__)
        pool_name = pool if pool is not None else self.active_pool

        # Get from pools
        if self.pools:
            pool_data = self.pools.get(pool_name)
            if not pool_data:
                return []

            users = pool_data.get("users", [])
            auth_config = pool_data.get("auth_config", {})

            # Filter by persona if specified
            if persona:
                users = [u for u in users if u.get("persona") == persona]

            # Merge auth config
            return [self._merge_auth_config(u, auth_config) for u in users]

        # Fallback to flat list
        if persona:
            return [u for u in self.users if u.get("persona") == persona]
        return self.users.copy()

    def get_random_user(
        self,
        persona: str,
        pool: str | None = None,
        auth_method: str | None = None,
    ) -> dict[str, Any] | None:
        """Get random user from pool for parallel testing.

        Useful when running tests in parallel to distribute load across users.

        Args:
            persona: User persona
            pool: Pool name (uses active pool if None)
            auth_method: Filter by auth method

        Returns:
            Random user dict or None if no users found

        Examples:
            user = registry.get_random_user(persona="admin")
        """
        users = self.get_pool_users(pool=pool, persona=persona)

        if auth_method:
            users = [u for u in users if u.get("auth_method") == auth_method]

        if not users:
            return None

        return random.choice(users)

    def get_next_user(
        self,
        persona: str,
        pool: str | None = None,
        auth_method: str | None = None,
    ) -> dict[str, Any] | None:
        """Get next user in round-robin fashion.

        Maintains internal counter per persona/pool combination for
        sequential distribution of users.

        Args:
            persona: User persona
            pool: Pool name (uses active pool if None)
            auth_method: Filter by auth method

        Returns:
            Next user dict or None if no users found

        Examples:
            user1 = registry.get_next_user(persona="admin")
            user2 = registry.get_next_user(persona="admin")  # Next in rotation
        """
        pool = pool or self.active_pool
        users = self.get_pool_users(pool=pool, persona=persona)

        if auth_method:
            users = [u for u in users if u.get("auth_method") == auth_method]

        if not users:
            return None

        # Create key for counter
        counter_key = f"{pool}:{persona}:{auth_method or 'any'}"

        # Get or initialize counter
        if counter_key not in self._user_counters:
            self._user_counters[counter_key] = 0

        # Get user and increment counter
        index = self._user_counters[counter_key] % len(users)
        user = users[index]
        self._user_counters[counter_key] += 1

        return user

    # Maintain backward compatibility methods
    def get_user_by_persona(
        self, persona: str, auth_method: str | None = None
    ) -> dict[str, Any] | None:
        """Get user by persona (backward compatible).

        Args:
            persona: User persona
            auth_method: Filter by auth method

        Returns:
            User dict or None
        """
        return self.get_user(persona=persona, auth_method=auth_method)

    def get_user_by_id(self, user_id: str) -> dict[str, Any] | None:
        """Get user by ID (backward compatible).

        Args:
            user_id: User ID

        Returns:
            User dict or None
        """
        return self.get_user(user_id=user_id)

    def get_all_users(self) -> list[dict[str, Any]]:
        """Get all registered users from active pool (backward compatible).

        Returns:
            List of all users
        """
        return self.get_pool_users()
