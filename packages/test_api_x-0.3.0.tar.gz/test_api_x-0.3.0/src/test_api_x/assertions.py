"""Fluent Assertions for API Testing.

Chainable assertion interface for API responses with clear error messages.
"""

import re
from re import Pattern
from typing import Any


class ResponseAssertion:
    """Fluent assertion interface for API responses.

    Chainable assertions for testing API responses:

        assert_that(response).has_status(200).has_json_path("user.id")

    Each method returns self for chaining.
    """

    def __init__(self, response: Any):  # EnhancedResponse type
        """Initialize assertions for response.

        Args:
            response: EnhancedResponse object to assert against

        """
        self.response = response
        self._assertion_chain: list[str] = []

    def _add_assertion(self, assertion_type: str) -> None:
        """Track assertion for error context."""
        self._assertion_chain.append(assertion_type)

    def _format_error(
        self,
        message: str,
        expected: Any = None,
        actual: Any = None,
        details: str | None = None,
    ) -> str:
        """Format clear error message with context.

        Args:
            message: Base error message
            expected: Expected value
            actual: Actual value
            details: Additional details

        Returns:
            Formatted error message

        """
        parts = [message]

        if expected is not None and actual is not None:
            parts.append(f"\n  Expected: {expected}")
            parts.append(f"  Actual: {actual}")

        if details:
            parts.append(f"\n  Details: {details}")

        # Add response context
        response_info = f"{self.response.status_code}"
        # Check if request is available (may not be in test scenarios)
        if (
            hasattr(self.response, "_response")
            and hasattr(self.response._response, "_request")
            and self.response._response._request is not None
        ):
            response_info += (
                f" {self.response.request.method} {self.response.request.url}"
            )
        parts.append(f"\n  Response: {response_info}")

        return "".join(parts)

    def has_status(self, expected_status: int) -> "ResponseAssertion":
        """Assert response has expected status code.

        Args:
            expected_status: Expected HTTP status code

        Returns:
            Self for chaining

        Raises:
            AssertionError: If status code doesn't match

        """
        self._add_assertion(f"has_status({expected_status})")
        actual_status = self.response.status_code

        if actual_status != expected_status:
            error_msg = self._format_error(
                "Status code mismatch",
                expected=expected_status,
                actual=actual_status,
            )
            raise AssertionError(error_msg)

        return self

    def has_header(
        self, header_name: str, expected_value: str | None = None
    ) -> "ResponseAssertion":
        """Assert response has header, optionally with specific value.

        Args:
            header_name: Header name to check
            expected_value: Expected header value (if checking value)

        Returns:
            Self for chaining

        Raises:
            AssertionError: If header missing or value doesn't match

        """
        self._add_assertion(f"has_header({header_name})")
        header_name_lower = header_name.lower()

        # Check header exists
        actual_headers = {k.lower(): v for k, v in self.response.headers.items()}

        if header_name_lower not in actual_headers:
            error_msg = self._format_error(
                f"Header '{header_name}' not found",
                details=f"Available headers: {', '.join(actual_headers.keys())}",
            )
            raise AssertionError(error_msg)

        # Check value if specified
        if expected_value is not None:
            actual_value = actual_headers[header_name_lower]
            if actual_value != expected_value:
                error_msg = self._format_error(
                    f"Header '{header_name}' value mismatch",
                    expected=expected_value,
                    actual=actual_value,
                )
                raise AssertionError(error_msg)

        return self

    def has_json_path(self, path: str) -> "ResponseAssertion":
        """Assert JSON path exists in response.

        Args:
            path: JSON path (dot notation + array indexing)

        Returns:
            Self for chaining

        Raises:
            AssertionError: If path doesn't exist

        """
        self._add_assertion(f"has_json_path({path})")

        if not self.response.has_json_path(path):
            error_msg = self._format_error(
                f"JSON path '{path}' not found",
                details="Use response.json_data to inspect structure",
            )
            raise AssertionError(error_msg)

        return self

    def json_path_equals(self, path: str, expected_value: Any) -> "ResponseAssertion":
        """Assert JSON path has expected value.

        Args:
            path: JSON path
            expected_value: Expected value at path

        Returns:
            Self for chaining

        Raises:
            AssertionError: If value doesn't match

        """
        self._add_assertion(f"json_path_equals({path}, {expected_value})")
        actual_value = self.response.json_path(path)

        if actual_value != expected_value:
            error_msg = self._format_error(
                f"JSON path '{path}' value mismatch",
                expected=expected_value,
                actual=actual_value,
            )
            raise AssertionError(error_msg)

        return self

    def json_path_matches(
        self, path: str, pattern: str | Pattern[str]
    ) -> "ResponseAssertion":
        """Assert JSON path value matches regex pattern.

        Args:
            path: JSON path
            pattern: Regex pattern (string or compiled)

        Returns:
            Self for chaining

        Raises:
            AssertionError: If value doesn't match pattern

        """
        self._add_assertion(f"json_path_matches({path}, {pattern})")
        actual_value = self.response.json_path(path)

        if actual_value is None:
            error_msg = self._format_error(
                f"JSON path '{path}' not found for pattern matching"
            )
            raise AssertionError(error_msg)

        # Compile pattern if string
        if isinstance(pattern, str):
            pattern = re.compile(pattern)

        if not pattern.search(str(actual_value)):
            error_msg = self._format_error(
                f"JSON path '{path}' value doesn't match pattern",
                expected=f"pattern: {pattern.pattern}",
                actual=actual_value,
            )
            raise AssertionError(error_msg)

        return self

    def response_time_less_than(self, max_seconds: float) -> "ResponseAssertion":
        """Assert response time is under threshold.

        Args:
            max_seconds: Maximum acceptable response time

        Returns:
            Self for chaining

        Raises:
            AssertionError: If response too slow

        """
        self._add_assertion(f"response_time_less_than({max_seconds})")
        actual_time = self.response.response_time

        if actual_time > max_seconds:
            error_msg = self._format_error(
                "Response time exceeded threshold",
                expected=f"< {max_seconds}s",
                actual=f"{actual_time:.3f}s",
            )
            raise AssertionError(error_msg)

        return self


def assert_that(response: Any) -> ResponseAssertion:
    """Create fluent assertion for response.

    Args:
        response: EnhancedResponse to assert

    Returns:
        ResponseAssertion for chaining

    Example:
        assert_that(response).has_status(200).has_json_path("user.id")

    """
    return ResponseAssertion(response)
