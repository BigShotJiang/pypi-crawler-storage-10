"""Async API Testing Library with pluggable authentication.

Minimal, powerful API testing library with auth plugin support.

Basic usage:
    from test_api_x import Client, assert_that

    async with Client(base_url="https://api.example.com") as client:
        response = await client.get("/users")
        assert_that(response).has_status(200).has_json_path("users")
"""

from test_api_x._version import __version__
from test_api_x.assertions import assert_that
from test_api_x.auth import (
    AuthenticationManager,
    AuthProvider,
    SessionCache,
    UserRegistry,
)
from test_api_x.auth.providers import Auth0Provider, BasicAuthProvider
from test_api_x.client import Client, EnhancedResponse
from test_api_x.config import Config
from test_api_x.exceptions import (
    APIXError,
    AuthenticationError,
    ConfigurationError,
    ProviderNotFoundError,
    RequestError,
    SessionExpiredError,
    TimeoutError,
    ValidationError,
)
from test_api_x.logging import SecureLogger, get_logger

__all__ = [
    # Version
    "__version__",
    # Core
    "Client",
    "EnhancedResponse",
    "assert_that",
    "Config",
    # Logging
    "SecureLogger",
    "get_logger",
    # Exceptions
    "APIXError",
    "AuthenticationError",
    "SessionExpiredError",
    "ProviderNotFoundError",
    "RequestError",
    "TimeoutError",
    "ValidationError",
    "ConfigurationError",
    # Auth
    "AuthenticationManager",
    "AuthProvider",
    "SessionCache",
    "UserRegistry",
    # Providers
    "BasicAuthProvider",
    "Auth0Provider",
]
