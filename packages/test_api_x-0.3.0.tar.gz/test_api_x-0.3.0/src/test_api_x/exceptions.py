"""Exception Hierarchy for API Testing.

Custom exceptions for clear error handling and context.
"""

from typing import Any


class APIXError(Exception):
    """Base exception for all API testing errors.

    All library exceptions inherit from this base class, making it easy
    to catch all framework-specific errors.
    """

    def __init__(self, message: str, context: dict[str, Any] | None = None):
        """Initialize exception with message and context.

        Args:
            message: Error message
            context: Additional context data (non-sensitive only)

        """
        super().__init__(message)
        self.message = message
        self.context = context or {}

    def __str__(self) -> str:
        """String representation with context."""
        if self.context:
            context_str = ", ".join(f"{k}={v}" for k, v in self.context.items())
            return f"{self.message} ({context_str})"
        return self.message


class AuthenticationError(APIXError):
    """Authentication failed.

    Raised when authentication cannot be completed, credentials are invalid,
    or auth provider encounters an error.
    """

    def __init__(
        self,
        message: str,
        user_id: str | None = None,
        auth_method: str | None = None,
        context: dict[str, Any] | None = None,
    ):
        """Initialize authentication error.

        Args:
            message: Error message
            user_id: User identifier (safe to log)
            auth_method: Authentication method used
            context: Additional context

        """
        error_context = context or {}
        if user_id:
            error_context["user_id"] = user_id
        if auth_method:
            error_context["auth_method"] = auth_method

        super().__init__(message, error_context)


class SessionExpiredError(AuthenticationError):
    """Session has expired and cannot be refreshed."""

    pass


class ProviderNotFoundError(APIXError):
    """Auth provider not found."""

    pass


class RequestError(APIXError):
    """HTTP request failed."""

    pass


class TimeoutError(RequestError):
    """Request timed out."""

    pass


class ValidationError(APIXError):
    """Data validation failed."""

    pass


class ConfigurationError(APIXError):
    """Configuration error."""

    pass
