"""Core HTTP Client with Enhanced Response.

Minimal async HTTP client for API testing with retry logic, auth integration,
and secure logging.
"""

import asyncio
import time
import uuid
from typing import Any, cast
from urllib.parse import urljoin

import httpx

from .exceptions import RequestError, TimeoutError
from .logging import get_logger

logger = get_logger("client")


class EnhancedResponse:
    """Response wrapper with testing utilities.

    Wraps httpx.Response to add:
    - JSON path extraction (dot notation + array indexing)
    - Response timing
    - Convenient data access

    Delegates unknown attributes to underlying response.
    """

    def __init__(self, response: httpx.Response, request_start_time: float):
        """Initialize enhanced response.

        Args:
            response: httpx response to wrap
            request_start_time: Unix timestamp when request started

        """
        self._response = response
        self.request_start_time = request_start_time
        self.response_time = time.time() - request_start_time
        self._json_cache: dict[str, Any] | None = None

    def __getattr__(self, name: str) -> Any:
        """Delegate unknown attributes to wrapped response."""
        return getattr(self._response, name)

    def __repr__(self) -> str:
        """Helpful representation for debugging."""
        if hasattr(self._response, "request") and self._response.request:
            return (
                f"<EnhancedResponse [{self._response.status_code}] "
                f"{self._response.request.method} {self._response.request.url}>"
            )
        return f"<EnhancedResponse [{self._response.status_code}]>"

    @property
    def ok(self) -> bool:
        """Check if response has successful status code (2xx)."""
        return 200 <= self._response.status_code < 300

    @property
    def json_data(self) -> dict[str, Any]:
        """Get JSON data with caching."""
        if self._json_cache is None:
            self._json_cache = self._response.json()
        return cast(dict[str, Any], self._json_cache)

    def json_path(self, path: str, default: Any = None) -> Any:
        """Extract data using JSON path syntax.

        Supports:
        - Nested: "user.profile.name"
        - Arrays: "users[0].email"
        - Mixed: "data.users[0].city"

        Args:
            path: JSON path string
            default: Value if path not found

        Returns:
            Value at path or default

        Examples:
            response.json_path("user.name")
            response.json_path("items[0].id")

        """
        try:
            current: Any = self.json_data
            parts = path.split(".")

            for part in parts:
                if "[" in part and part.endswith("]"):
                    # Handle array access: key[index]
                    key, index_str = part.split("[", 1)
                    index_str = index_str.rstrip("]")

                    if key:
                        current = current[key]

                    index = int(index_str)
                    current = current[index]
                else:
                    # Handle object access
                    current = current[part]

            return current
        except (KeyError, IndexError, TypeError, ValueError):
            return default

    def has_json_path(self, path: str) -> bool:
        """Check if JSON path exists.

        Args:
            path: JSON path to check

        Returns:
            True if path exists

        """
        sentinel = object()
        return self.json_path(path, default=sentinel) is not sentinel


class Client:
    """Async HTTP client for API testing.

    Features:
    - Automatic retry with exponential backoff
    - Auth session integration
    - Request/response logging with correlation IDs
    - Connection pooling via httpx
    - Context manager support

    Usage:
        async with Client("https://api.example.com") as client:
            response = await client.get("/users")
    """

    def __init__(
        self,
        base_url: str | None = None,
        headers: dict[str, str] | None = None,
        timeout: float = 30.0,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        retry_backoff: float = 2.0,
        verify_ssl: bool = True,
        follow_redirects: bool = True,
        session: dict[str, Any] | None = None,
        auth_manager: Any | None = None,  # Will type properly in Stage 3
    ):
        """Initialize client.

        Args:
            base_url: Base URL for requests
            headers: Default headers for all requests
            timeout: Request timeout in seconds
            max_retries: Number of retry attempts
            retry_delay: Initial delay between retries
            retry_backoff: Backoff multiplier for retries
            verify_ssl: Verify SSL certificates
            follow_redirects: Follow HTTP redirects
            session: Auth session dict (from AuthenticationManager.authenticate_user())
            auth_manager: AuthenticationManager instance for session refresh

        """
        self.base_url = base_url or ""
        self.default_headers = headers or {}
        self.timeout = timeout
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.retry_backoff = retry_backoff
        self.session = session
        self.auth_manager = auth_manager

        # Create httpx client
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(timeout),
            follow_redirects=follow_redirects,
            verify=verify_ssl,
            headers=self.default_headers,
        )

    async def close(self) -> None:
        """Close client and release resources."""
        await self._client.aclose()

    async def __aenter__(self) -> "Client":
        """Enter context manager."""
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit context manager and cleanup."""
        await self.close()

    @classmethod
    def with_basic_auth(
        cls, username: str, password: str, base_url: str, **kwargs: Any
    ) -> "Client":
        """Create client with Basic authentication.

        Args:
            username: Username for authentication
            password: Password for authentication
            base_url: Base URL for API requests
            **kwargs: Additional arguments passed to Client()

        Returns:
            Client instance configured with basic auth (use as async context manager)

        Examples:
            async with Client.with_basic_auth("user", "pass", "https://api.example.com") as client:
                response = await client.get("/users")
        """
        from test_api_x.auth.providers import BasicAuthProvider

        # Create wrapper that handles async authentication
        class BasicAuthClient(cls):  # type: ignore
            async def __aenter__(self) -> "Client":
                # Create provider and authenticate
                provider = BasicAuthProvider()
                session = await provider.authenticate(
                    {"username": username, "password": password}
                )
                self.session = session
                return await super().__aenter__()  # type: ignore[no-any-return]

        return BasicAuthClient(base_url=base_url, **kwargs)

    @classmethod
    def with_auth0(
        cls,
        domain: str,
        client_id: str,
        client_secret: str,
        username: str,
        password: str,
        base_url: str,
        audience: str | None = None,
        realm: str | None = None,
        **kwargs: Any,
    ) -> "Client":
        """Create client with Auth0 authentication.

        Args:
            domain: Auth0 domain (e.g., 'dev-xxx.auth0.com')
            client_id: Auth0 client ID
            client_secret: Auth0 client secret
            username: User's username/email
            password: User's password
            base_url: Base URL for API requests
            audience: API audience identifier (optional)
            realm: Authentication realm (optional, default: 'Username-Password-Authentication')
            **kwargs: Additional arguments passed to Client()

        Returns:
            Client instance configured with Auth0 (use as async context manager)

        Examples:
            async with Client.with_auth0(
                domain="dev-xxx.auth0.com",
                client_id="client_id",
                client_secret="secret",
                username="user@example.com",
                password="password",
                base_url="https://api.example.com"
            ) as client:
                response = await client.get("/users")
        """
        from test_api_x.auth.providers import Auth0Provider

        # Create wrapper that handles async authentication
        class Auth0Client(cls):  # type: ignore
            async def __aenter__(self) -> "Client":
                # Create provider
                provider = Auth0Provider(
                    domain=domain,
                    client_id=client_id,
                    client_secret=client_secret,
                    audience=audience,
                )

                # Build user dict for authentication
                user_config = {"username": username, "password": password}
                if realm:
                    user_config["realm"] = realm
                if audience:
                    user_config["audience"] = audience

                # Authenticate
                session = await provider.authenticate(user_config)
                self.session = session
                return await super().__aenter__()  # type: ignore[no-any-return]

        return Auth0Client(base_url=base_url, **kwargs)

    @classmethod
    def with_user(cls, user: dict[str, Any], base_url: str, **kwargs: Any) -> "Client":
        """Create client from user dictionary.

        Detects auth_method from user dict and creates appropriate client.

        Args:
            user: User configuration dict with auth_method and credentials
            base_url: Base URL for API requests
            **kwargs: Additional arguments passed to Client()

        Returns:
            Client instance configured with user's auth method

        Raises:
            ValueError: If auth_method missing or unknown

        Examples:
            user = {
                "id": "admin1",
                "auth_method": "basic",
                "username": "admin",
                "password": "secret"
            }
            async with Client.with_user(user, "https://api.example.com") as client:
                response = await client.get("/users")
        """
        auth_method = user.get("auth_method")
        if not auth_method:
            raise ValueError("User dict must contain 'auth_method' field")

        # Route to appropriate factory based on auth_method
        if auth_method == "basic":
            return cls.with_basic_auth(
                username=user["username"],
                password=user["password"],
                base_url=base_url,
                **kwargs,
            )
        elif auth_method == "auth0":
            return cls.with_auth0(
                domain=user["domain"],
                client_id=user["client_id"],
                client_secret=user["client_secret"],
                username=user["username"],
                password=user["password"],
                base_url=base_url,
                audience=user.get("audience"),
                realm=user.get("realm"),
                **kwargs,
            )
        else:
            raise ValueError(f"Unknown auth method: {auth_method}")

    @classmethod
    def from_registry(
        cls,
        registry: Any,  # UserRegistry type
        base_url: str,
        persona: str | None = None,
        user_id: str | None = None,
        pool: str | None = None,
        **kwargs: Any,
    ) -> "Client":
        """Create client from user registry.

        Looks up user by persona or user_id and creates authenticated client.

        Args:
            registry: UserRegistry instance
            base_url: Base URL for API requests
            persona: User persona to lookup (e.g., 'admin', 'user')
            user_id: Specific user ID to lookup
            pool: Pool name for user lookup (optional)
            **kwargs: Additional arguments passed to Client()

        Returns:
            Client instance for the specified user

        Raises:
            ValueError: If neither persona nor user_id provided
            KeyError: If user not found in registry

        Examples:
            registry = UserRegistry.auto()
            async with Client.from_registry(
                registry, "https://api.example.com", persona="admin"
            ) as client:
                response = await client.get("/users")
        """
        # Get user from registry
        if not persona and not user_id:
            raise ValueError("Must provide either persona or user_id")

        user = registry.get_user(persona=persona, user_id=user_id, pool=pool)

        if not user:
            raise ValueError(f"User not found: persona={persona}, user_id={user_id}")

        # Delegate to with_user
        return cls.with_user(user=user, base_url=base_url, **kwargs)

    def _build_url(self, path: str) -> str:
        """Build full URL from base URL and path.

        Args:
            path: URL path or full URL

        Returns:
            Complete URL

        """
        # If path is already full URL, return as-is
        if path.startswith(("http://", "https://")):
            return path

        # Combine with base URL
        if self.base_url:
            base = self.base_url.rstrip("/") + "/"
            path = path.lstrip("/")
            return urljoin(base, path)

        return path

    def _generate_correlation_id(self) -> str:
        """Generate unique correlation ID for request tracing."""
        return str(uuid.uuid4())[:8]

    async def _get_auth_headers(self) -> dict[str, str]:
        """Get auth headers from session via AuthenticationManager.

        Returns:
            Auth headers dict (empty if no session)

        """
        if not self.session or not self.auth_manager:
            return {}

        try:
            headers: dict[str, str] = await self.auth_manager.get_auth_headers(
                self.session
            )
            logger.debug(f"Got auth headers for session: {list(headers.keys())}")
            return headers
        except Exception as e:
            logger.error(f"Failed to get auth headers: {e}")
            return {}

    async def _execute_with_retries(
        self, method: str, url: str, **kwargs: Any
    ) -> httpx.Response:
        """Execute request with retry logic.

        Args:
            method: HTTP method
            url: Full URL
            **kwargs: Request parameters

        Returns:
            httpx.Response

        Raises:
            TimeoutError: If request times out after all retries
            RequestError: If request fails after all retries

        """
        last_exception: Exception | None = None
        delay = self.retry_delay

        for attempt in range(self.max_retries + 1):
            try:
                response = await self._client.request(method, url, **kwargs)

                # Handle 401 Unauthorized with session refresh
                if (
                    response.status_code == 401
                    and self.session
                    and self.auth_manager
                    and attempt < self.max_retries
                ):
                    logger.warning(
                        "Received 401 Unauthorized, attempting session refresh"
                    )
                    try:
                        # Refresh the session
                        self.session = await self.auth_manager.refresh_session(
                            self.session
                        )
                        # Update auth headers in kwargs for retry
                        auth_headers = await self._get_auth_headers()
                        if "headers" in kwargs:
                            kwargs["headers"].update(auth_headers)
                        else:
                            kwargs["headers"] = auth_headers
                        logger.info("Session refreshed successfully, retrying request")
                        continue  # Retry with refreshed session
                    except Exception as e:
                        logger.error(f"Session refresh failed: {e}")
                        return response  # Return 401 if refresh fails

                return response

            except httpx.TimeoutException:
                last_exception = TimeoutError(
                    f"Request timed out: {method} {url}",
                    context={"attempt": attempt + 1, "max_retries": self.max_retries},
                )
            except httpx.RequestError as e:
                last_exception = RequestError(
                    f"Request failed: {method} {url} - {str(e)}",
                    context={"attempt": attempt + 1, "max_retries": self.max_retries},
                )

            # Don't retry on last attempt
            if attempt < self.max_retries:
                await asyncio.sleep(delay)
                delay *= self.retry_backoff

        # All retries exhausted
        if last_exception:
            raise last_exception
        raise RequestError(f"Request failed after {self.max_retries + 1} attempts")

    async def request(
        self,
        method: str,
        endpoint: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any | None = None,
        data: Any | None = None,
        headers: dict[str, str] | None = None,
        **kwargs: Any,
    ) -> EnhancedResponse:
        """Make HTTP request with all enhancements.

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: URL path or full URL
            params: Query parameters
            json: JSON data to send
            data: Form data or raw bytes
            headers: Additional headers
            **kwargs: Additional httpx arguments

        Returns:
            EnhancedResponse object

        """
        # Build full URL
        url = self._build_url(endpoint)

        # Generate correlation ID
        correlation_id = self._generate_correlation_id()

        # Merge headers
        merged_headers = {**self.default_headers}

        # Add auth headers from session
        auth_headers = await self._get_auth_headers()
        merged_headers.update(auth_headers)

        # Add user headers (override auth/default)
        if headers:
            merged_headers.update(headers)

        # Log request with correlation ID
        logger.log_request(method, url, merged_headers, json or data, correlation_id)

        # Execute with retries
        start_time = time.time()
        response = await self._execute_with_retries(
            method=method,
            url=url,
            params=params,
            json=json,
            data=data,
            headers=merged_headers,
            **kwargs,
        )

        elapsed_ms = (time.time() - start_time) * 1000

        # Log response with correlation ID
        try:
            response_body = response.json() if response.text else None
        except Exception:
            response_body = response.text if response.text else None

        logger.log_response(
            response.status_code,
            dict(response.headers),
            response_body,
            elapsed_ms,
            correlation_id,
        )

        # Return enhanced response
        return EnhancedResponse(response, start_time)

    # Convenience methods for HTTP verbs
    async def get(self, endpoint: str, **kwargs: Any) -> EnhancedResponse:
        """Make GET request."""
        return await self.request("GET", endpoint, **kwargs)

    async def post(self, endpoint: str, **kwargs: Any) -> EnhancedResponse:
        """Make POST request."""
        return await self.request("POST", endpoint, **kwargs)

    async def put(self, endpoint: str, **kwargs: Any) -> EnhancedResponse:
        """Make PUT request."""
        return await self.request("PUT", endpoint, **kwargs)

    async def patch(self, endpoint: str, **kwargs: Any) -> EnhancedResponse:
        """Make PATCH request."""
        return await self.request("PATCH", endpoint, **kwargs)

    async def delete(self, endpoint: str, **kwargs: Any) -> EnhancedResponse:
        """Make DELETE request."""
        return await self.request("DELETE", endpoint, **kwargs)

    async def head(self, endpoint: str, **kwargs: Any) -> EnhancedResponse:
        """Make HEAD request."""
        return await self.request("HEAD", endpoint, **kwargs)

    async def options(self, endpoint: str, **kwargs: Any) -> EnhancedResponse:
        """Make OPTIONS request."""
        return await self.request("OPTIONS", endpoint, **kwargs)
