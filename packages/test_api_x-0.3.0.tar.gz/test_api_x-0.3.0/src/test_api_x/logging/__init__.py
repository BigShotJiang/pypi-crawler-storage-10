"""Secure Logging Module.

Provides SecureLogger instances and masking utilities.
"""

import logging
import os

from test_api_x.logging.masking import (
    mask_any,
    mask_dict,
    mask_headers,
    mask_list,
    mask_string,
    mask_url,
)
from test_api_x.logging.secure_logger import SecureLogger

__all__ = [
    "SecureLogger",
    "get_logger",
    "mask_any",
    "mask_dict",
    "mask_list",
    "mask_string",
    "mask_headers",
    "mask_url",
]


def get_logger(name: str, level: str | None = None) -> SecureLogger:
    """Get or create a SecureLogger instance.

    Args:
        name: Logger name (usually module name)
        level: Log level (DEBUG, INFO, WARNING, ERROR)

    Returns:
        SecureLogger instance

    """
    if level is None:
        level = os.getenv("TESTAPIX_LOG_LEVEL", "INFO")

    # Configure root logger if not already configured
    if not logging.getLogger().handlers:
        logging.basicConfig(
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            level=getattr(logging, level.upper()),
        )

    return SecureLogger(name, level)
