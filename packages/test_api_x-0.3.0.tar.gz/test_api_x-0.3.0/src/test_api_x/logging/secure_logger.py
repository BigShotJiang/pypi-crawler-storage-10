"""Secure Logger with Automatic Credential Masking.

Provides structured logging with correlation IDs and automatic masking of sensitive data.
"""

import json
import logging
import uuid
from typing import Any

from test_api_x.logging.masking import mask_any, mask_headers, mask_url


class SecureLogger:
    """Logger that automatically masks sensitive information.

    Features:
    - Automatic credential masking in all logs
    - Correlation IDs for request tracing
    - Structured logging (JSON or pretty format)
    - Context-aware log levels
    """

    def __init__(self, name: str, level: str = "INFO"):
        """Initialize secure logger.

        Args:
            name: Logger name
            level: Log level (DEBUG, INFO, WARNING, ERROR)

        """
        self.logger = logging.getLogger(name)
        self.logger.setLevel(getattr(logging, level.upper()))
        self.correlation_id: str | None = None

    def _generate_correlation_id(self) -> str:
        """Generate unique correlation ID for request tracing."""
        return str(uuid.uuid4())[:8]

    def debug(self, message: str) -> None:
        """Log debug message."""
        self.logger.debug(message)

    def info(self, message: str) -> None:
        """Log info message."""
        self.logger.info(message)

    def warning(self, message: str) -> None:
        """Log warning message."""
        self.logger.warning(message)

    def error(self, message: str) -> None:
        """Log error message."""
        self.logger.error(message)

    def log_request(
        self,
        method: str,
        url: str,
        headers: dict[str, str] | None = None,
        body: Any = None,
        correlation_id: str | None = None,
    ) -> None:
        """Log HTTP request with masked sensitive data.

        Args:
            method: HTTP method
            url: Request URL
            headers: Request headers
            body: Request body
            correlation_id: Correlation ID for tracing

        """
        self.correlation_id = correlation_id or self._generate_correlation_id()

        log_data = {
            "type": "request",
            "correlation_id": self.correlation_id,
            "method": method,
            "url": mask_url(url),
            "headers": mask_headers(headers or {}),
        }

        if body:
            log_data["body"] = mask_any(body)

        self.logger.debug(f"Request: {method} {mask_url(url)} [{self.correlation_id}]")
        if self.logger.isEnabledFor(logging.DEBUG):
            self.logger.debug(f"  Headers: {json.dumps(log_data['headers'])}")
            if body:
                body_str = json.dumps(log_data["body"])
                if len(body_str) > 500:
                    body_str = body_str[:500] + "..."
                self.logger.debug(f"  Body: {body_str}")

    def log_response(
        self,
        status_code: int,
        headers: dict[str, str] | None = None,
        body: Any = None,
        elapsed_ms: float | None = None,
        correlation_id: str | None = None,
    ) -> None:
        """Log HTTP response with masked sensitive data.

        Args:
            status_code: HTTP status code
            headers: Response headers
            body: Response body
            elapsed_ms: Response time in milliseconds
            correlation_id: Correlation ID for tracing

        """
        corr_id = correlation_id or self.correlation_id or "unknown"

        log_data = {
            "type": "response",
            "correlation_id": corr_id,
            "status_code": status_code,
            "elapsed_ms": elapsed_ms,
            "headers": mask_headers(headers or {}),
        }

        if body:
            log_data["body"] = mask_any(body)

        # Choose log level based on status code
        if 200 <= status_code < 400:
            level = logging.DEBUG
            status_icon = "OK"
        elif 400 <= status_code < 500:
            level = logging.WARNING
            status_icon = "CLIENT_ERROR"
        else:
            level = logging.WARNING
            status_icon = "SERVER_ERROR"

        timing = f"({elapsed_ms:.0f}ms)" if elapsed_ms else ""
        self.logger.log(
            level, f"Response: {status_code} {status_icon} {timing} [{corr_id}]"
        )

        if self.logger.isEnabledFor(logging.DEBUG):
            self.logger.debug(f"  Headers: {json.dumps(log_data['headers'])}")
            if body and isinstance(body, dict | list):
                body_str = json.dumps(mask_any(body))
                if len(body_str) > 500:
                    body_str = body_str[:500] + "..."
                self.logger.debug(f"  Body: {body_str}")

    def log_auth_attempt(
        self,
        persona: str,
        auth_method: str,
        user_id: str,
        success: bool,
        duration_ms: float | None = None,
        error: str | None = None,
    ) -> None:
        """Log authentication attempt (never log credentials).

        Args:
            persona: User persona
            auth_method: Authentication method
            user_id: User identifier (safe to log)
            success: Whether auth succeeded
            duration_ms: Auth duration in milliseconds
            error: Error message if failed

        """
        log_data = {
            "type": "auth_attempt",
            "persona": persona,
            "auth_method": auth_method,
            "user_id": user_id,
            "success": success,
            "duration_ms": duration_ms,
        }

        if error:
            log_data["error"] = mask_any(error)

        status = "SUCCESS" if success else "FAILED"
        timing = f"({duration_ms:.0f}ms)" if duration_ms else ""
        level = logging.INFO if success else logging.WARNING

        self.logger.log(
            level,
            f"Auth {status}: {persona} via {auth_method} {timing} (user: {user_id})",
        )

        if error and not success:
            self.logger.debug(f"  Error: {mask_any(error)}")

    def log_session_cached(self, user_id: str, persona: str, ttl_seconds: int) -> None:
        """Log session cache hit.

        Args:
            user_id: User identifier
            persona: User persona
            ttl_seconds: Session TTL

        """
        self.logger.debug(
            f"Session cached: {persona} (user: {user_id}, ttl: {ttl_seconds}s)"
        )

    def log_session_refresh(
        self, user_id: str, auth_method: str, success: bool
    ) -> None:
        """Log session refresh attempt.

        Args:
            user_id: User identifier
            auth_method: Auth method
            success: Whether refresh succeeded

        """
        status = "SUCCESS" if success else "FAILED"
        level = logging.INFO if success else logging.WARNING

        self.logger.log(
            level,
            f"Session refresh {status}: {auth_method} (user: {user_id})",
        )
