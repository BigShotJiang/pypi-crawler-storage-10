"""Credential Masking Utilities.

Automatically detect and redact sensitive data from logs, headers, and request/response bodies.
"""

import re
from typing import Any

# Mask replacement string
MASK_VALUE = "***REDACTED***"

# Keywords that indicate sensitive data in keys/field names
SENSITIVE_KEYWORDS = [
    "password",
    "secret",
    "token",
    "key",
    "auth",
    "credential",
    "api_key",
    "apikey",
    "access_token",
    "refresh_token",
    "session",
    "cookie",
]

# Header names that should be masked
SENSITIVE_HEADER_NAMES = [
    "authorization",
    "x-api-key",
    "api-key",
    "apikey",
    "x-auth-token",
    "auth-token",
    "x-session-token",
    "session-token",
    "cookie",
    "set-cookie",
    "proxy-authorization",
    "x-csrf-token",
]


def _is_sensitive_key(key: str) -> bool:
    """Check if a key name indicates sensitive data.

    Args:
        key: Key name to check

    Returns:
        True if key indicates sensitive data

    """
    key_lower = key.lower().replace("-", "_")
    return any(keyword in key_lower for keyword in SENSITIVE_KEYWORDS)


def mask_string(text: str) -> str:
    """Mask sensitive patterns in strings.

    This is a fallback for string values that aren't in dict/list context.
    Generally, key-based masking (mask_dict) is more reliable.

    Args:
        text: String to mask

    Returns:
        Masked string with sensitive data redacted

    """
    if not text:
        return text

    # Just return the string as-is
    # Key-based masking in mask_dict/mask_headers is more reliable
    return text


def mask_dict(data: Any) -> Any:
    """Recursively mask sensitive data in dictionary.

    Args:
        data: Dictionary to mask (any type accepted, dict expected)

    Returns:
        Masked dict if input is dict, original value otherwise

    """
    if not isinstance(data, dict):
        return data

    masked: dict[str, Any] = {}
    for key, value in data.items():
        # Check if key itself is sensitive
        if _is_sensitive_key(key):
            masked[key] = MASK_VALUE
        elif isinstance(value, dict):
            masked[key] = mask_dict(value)
        elif isinstance(value, list):
            masked[key] = mask_list(value)
        else:
            # Keep non-sensitive values as-is
            masked[key] = value

    return masked


def mask_list(data: Any) -> Any:
    """Recursively mask sensitive data in list.

    Args:
        data: List to mask (any type accepted, list expected)

    Returns:
        Masked list if input is list, original value otherwise

    """
    if not isinstance(data, list):
        return data

    result: list[Any] = []
    for item in data:
        if isinstance(item, dict):
            result.append(mask_dict(item))
        elif isinstance(item, list):
            result.append(mask_list(item))
        else:
            # Keep non-dict/list items as-is
            result.append(item)

    return result


def mask_headers(headers: dict[str, str]) -> dict[str, str]:
    """Mask sensitive headers.

    Args:
        headers: Headers dict

    Returns:
        New dict with sensitive headers masked

    """
    if not headers:
        return headers

    masked = {}
    for key, value in headers.items():
        key_lower = key.lower()

        if key_lower in SENSITIVE_HEADER_NAMES:
            masked[key] = MASK_VALUE
        else:
            masked[key] = value

    return masked


def mask_url(url: str) -> str:
    """Mask sensitive data in URL (query params, basic auth).

    Args:
        url: URL to mask

    Returns:
        Masked URL

    """
    if not url:
        return url

    # Mask basic auth in URL (https://user:pass@host/path)
    url = re.sub(r"(https?://)[^:]+:[^@]+@", rf"\1{MASK_VALUE}:{MASK_VALUE}@", url)

    # Mask sensitive query parameters
    url = re.sub(
        r"([?&])(api[-_]?key|token|password|secret|auth|session)=([^&]+)",
        rf"\1\2={MASK_VALUE}",
        url,
        flags=re.IGNORECASE,
    )

    return url


def mask_any(data: Any) -> Any:
    """Mask any type of data recursively.

    Args:
        data: Data to mask (dict, list, str, or other)

    Returns:
        Masked data

    """
    if isinstance(data, dict):
        return mask_dict(data)
    elif isinstance(data, list):
        return mask_list(data)
    elif isinstance(data, str):
        return mask_string(data)
    else:
        return data
