# FinRav 💹

**FinRav** is an open-source Python library for **quantitative finance** and **statistical modeling**.  
It provides clean, modular tools for simulating stochastic processes and analyzing financial time series.

---

## ✨ Features
- **stoch** — A comprehensive module for simulating stochastic processes,
including Brownian motion, fractional Brownian motion, and other time-series models commonly used in quantitative finance.


- **stats** — A collection of statistical analysis tools for parameter estimation, distribution fitting, 
and evaluating heavy-tailed behavior in financial data


- **monte_carlo** — A flexible Monte Carlo simulation framework for modeling uncertainty, pricing derivatives, 
and analyzing risk under stochastic dynamics.


## ⚙️ Installation
```bash
pip install finRav
```