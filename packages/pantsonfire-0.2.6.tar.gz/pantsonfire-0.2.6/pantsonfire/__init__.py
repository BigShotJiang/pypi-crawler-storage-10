"""pantsonfire - Find wrong information in technical docs online"""

__version__ = "0.2.6"

from .factory import create_app

__all__ = ["create_app", "__version__"]
