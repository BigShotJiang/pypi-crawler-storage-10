# Tests to validate geoPFA
