# -*- coding: utf-8 -*-

"""Interactive TUI for Feature Flag Service (FFS) management."""

import asyncio
import json
from typing import Dict, List, Optional, Any
from textual.app import App, ComposeResult
from textual.screen import Screen
from textual.containers import Container, Horizontal, Vertical
from textual.widgets import (
    Button,
    DataTable,
    Footer,
    Header,
    Input,
    Label,
    TextArea,
)
from textual.binding import Binding
from .ffs_service import ffs_service


class FFSSearchScreen(Screen):
    """Search screen for feature flags."""
    
    BINDINGS = [
        Binding("escape", "back", "Back", priority=True),
    ]
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            with Container(id="search-container"):
                yield Label("🔍 Search Feature Flags", id="search-title")
                yield Input(
                    placeholder="Enter search query...",
                    id="search-input"
                )
                yield DataTable(id="search-results")
                with Horizontal(id="search-buttons"):
                    yield Button("Search", id="search-btn", variant="primary")
                    yield Button("Clear", id="clear-btn")
                    yield Button("Back", id="back-btn")
        yield Footer()
    
    def action_back(self) -> None:
        """Go back to previous screen."""
        self.app.pop_screen()
    
    def on_mount(self) -> None:
        """Initialize the search screen."""
        table = self.query_one("#search-results", DataTable)
        table.add_columns("Flag ID", "Status", "Description")
        self.query_one("#search-input", Input).focus()
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "search-btn":
            await self._perform_search()
        elif event.button.id == "clear-btn":
            self.query_one("#search-input", Input).value = ""
            table = self.query_one("#search-results", DataTable)
            table.clear()
        elif event.button.id == "back-btn":
            self.action_back()
    
    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle input submission."""
        if event.input.id == "search-input":
            await self._perform_search()
    
    async def _perform_search(self) -> None:
        """Perform feature flag search."""
        input_widget = self.query_one("#search-input", Input)
        query = input_widget.value.strip()
        
        if not query:
            return
        
        table = self.query_one("#search-results", DataTable)
        table.clear()
        
        # Show loading
        self.query_one("#search-title", Label).update("🔍 Searching...")
        
        try:
            result = await ffs_service.search_feature_flags(query)
            
            if not result.success:
                self.query_one("#search-title", Label).update(
                    f"❌ Error: {result.error_message}"
                )
                return
            
            flags = result.data
            
            if not flags:
                self.query_one("#search-title", Label).update(
                    f"🔍 No results found for '{query}'"
                )
                return
            
            # Add results to table
            for flag in flags:
                flag_id = flag.get("id", "N/A")
                status = flag.get("status", "N/A")
                description = flag.get("description", "N/A")
                
                # Truncate description if too long
                if len(description) > 50:
                    description = description[:47] + "..."
                
                table.add_row(flag_id, status, description, key=flag_id)
            
            self.query_one("#search-title", Label).update(
                f"🔍 Found {len(flags)} results for '{query}'"
            )
            
        except Exception as e:
            self.query_one("#search-title", Label).update(
                f"❌ Error: {str(e)}"
            )


class FFSGetScreen(Screen):
    """Screen for getting feature flag."""
    
    BINDINGS = [
        Binding("escape", "back", "Back", priority=True),
    ]
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            with Container(id="get-container"):
                yield Label("📖 Get Feature Flag", id="get-title")
                yield Input(placeholder="Flag ID (e.g., rc-app-mobile.user.sms_translate_sms)", id="flag-id-input")
                yield TextArea(id="result-area", read_only=True)
                with Horizontal(id="get-buttons"):
                    yield Button("Get Flag", id="get-btn", variant="primary")
                    yield Button("Clear", id="clear-btn")
                    yield Button("Back", id="back-btn")
        yield Footer()
    
    def action_back(self) -> None:
        """Go back to previous screen."""
        self.app.pop_screen()
    
    def on_mount(self) -> None:
        """Initialize the get screen."""
        self.query_one("#flag-id-input", Input).focus()
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "get-btn":
            await self._get_flag()
        elif event.button.id == "clear-btn":
            self.query_one("#flag-id-input", Input).value = ""
            self.query_one("#result-area", TextArea).text = ""
        elif event.button.id == "back-btn":
            self.action_back()
    
    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle input submission."""
        if event.input.id == "flag-id-input":
            await self._get_flag()
    
    async def _get_flag(self) -> None:
        """Get feature flag."""
        flag_id = self.query_one("#flag-id-input", Input).value.strip()
        
        if not flag_id:
            self.query_one("#get-title", Label).update(
                "⚠️  Please enter Flag ID"
            )
            return
        
        result_area = self.query_one("#result-area", TextArea)
        self.query_one("#get-title", Label).update("📖 Loading...")
        result_area.text = ""
        
        try:
            result = await ffs_service.get_feature_flag(flag_id)
            
            if not result.success:
                self.query_one("#get-title", Label).update(
                    f"❌ Error: {result.error_message}"
                )
                result_area.text = f"Error: {result.error_message}"
                return
            
            flag_data = result.data
            formatted_output = ffs_service.format_flag_display(flag_data)
            
            result_area.text = formatted_output
            self.query_one("#get-title", Label).update(
                f"✅ Flag {flag_id} retrieved"
            )
            
        except Exception as e:
            self.query_one("#get-title", Label).update(
                f"❌ Error: {str(e)}"
            )
            result_area.text = f"Error: {str(e)}"


class FFSEvaluateScreen(Screen):
    """Screen for evaluating feature flag."""
    
    BINDINGS = [
        Binding("escape", "back", "Back", priority=True),
    ]
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            with Container(id="evaluate-container"):
                yield Label("📊 Evaluate Feature Flag", id="evaluate-title")
                yield Input(placeholder="Flag ID", id="flag-id-input")
                yield Input(placeholder="Account ID (optional)", id="account-id-input")
                yield Input(placeholder="Extension ID (optional)", id="extension-id-input")
                yield Input(placeholder="Email Domain (optional)", id="email-domain-input")
                yield TextArea(id="result-area", read_only=True)
                with Horizontal(id="evaluate-buttons"):
                    yield Button("Evaluate", id="evaluate-btn", variant="primary")
                    yield Button("Clear", id="clear-btn")
                    yield Button("Back", id="back-btn")
        yield Footer()
    
    def action_back(self) -> None:
        """Go back to previous screen."""
        self.app.pop_screen()
    
    def on_mount(self) -> None:
        """Initialize the evaluate screen."""
        self.query_one("#flag-id-input", Input).focus()
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "evaluate-btn":
            await self._evaluate_flag()
        elif event.button.id == "clear-btn":
            self.query_one("#flag-id-input", Input).value = ""
            self.query_one("#account-id-input", Input).value = ""
            self.query_one("#extension-id-input", Input).value = ""
            self.query_one("#email-domain-input", Input).value = ""
            self.query_one("#result-area", TextArea).text = ""
        elif event.button.id == "back-btn":
            self.action_back()
    
    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle input submission."""
        if event.input.id == "email-domain-input":
            await self._evaluate_flag()
        elif event.input.id == "flag-id-input":
            self.query_one("#account-id-input", Input).focus()
        elif event.input.id == "account-id-input":
            self.query_one("#extension-id-input", Input).focus()
        elif event.input.id == "extension-id-input":
            self.query_one("#email-domain-input", Input).focus()
    
    async def _evaluate_flag(self) -> None:
        """Evaluate feature flag."""
        flag_id = self.query_one("#flag-id-input", Input).value.strip()
        account_id = self.query_one("#account-id-input", Input).value.strip()
        extension_id = self.query_one("#extension-id-input", Input).value.strip()
        email_domain = self.query_one("#email-domain-input", Input).value.strip()
        
        if not flag_id:
            self.query_one("#evaluate-title", Label).update(
                "⚠️  Please enter Flag ID"
            )
            return
        
        # Build context
        context: Dict[str, Any] = {}
        if account_id:
            context["accountId"] = account_id
        if extension_id:
            context["extensionId"] = extension_id
        if email_domain:
            context["emailDomain"] = email_domain
        
        result_area = self.query_one("#result-area", TextArea)
        self.query_one("#evaluate-title", Label).update("📊 Evaluating...")
        result_area.text = ""
        
        try:
            result = await ffs_service.evaluate_feature_flag(flag_id, context)
            
            if not result.success:
                self.query_one("#evaluate-title", Label).update(
                    f"❌ Error: {result.error_message}"
                )
                result_area.text = f"Error: {result.error_message}"
                return
            
            eval_data = result.data
            formatted_output = ffs_service.format_evaluation_display(eval_data)
            
            result_area.text = formatted_output
            self.query_one("#evaluate-title", Label).update(
                f"✅ Flag {flag_id} evaluated"
            )
            
        except Exception as e:
            self.query_one("#evaluate-title", Label).update(
                f"❌ Error: {str(e)}"
            )
            result_area.text = f"Error: {str(e)}"


class FFSCheckScreen(Screen):
    """Screen for checking if feature is enabled."""
    
    BINDINGS = [
        Binding("escape", "back", "Back", priority=True),
    ]
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            with Container(id="check-container"):
                yield Label("✅ Check Feature Enabled", id="check-title")
                yield Input(placeholder="Flag ID", id="flag-id-input")
                yield Input(placeholder="Account ID (optional)", id="account-id-input")
                yield Input(placeholder="Extension ID (optional)", id="extension-id-input")
                yield TextArea(id="result-area", read_only=True)
                with Horizontal(id="check-buttons"):
                    yield Button("Check", id="check-btn", variant="primary")
                    yield Button("Clear", id="clear-btn")
                    yield Button("Back", id="back-btn")
        yield Footer()
    
    def action_back(self) -> None:
        """Go back to previous screen."""
        self.app.pop_screen()
    
    def on_mount(self) -> None:
        """Initialize the check screen."""
        self.query_one("#flag-id-input", Input).focus()
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "check-btn":
            await self._check_enabled()
        elif event.button.id == "clear-btn":
            self.query_one("#flag-id-input", Input).value = ""
            self.query_one("#account-id-input", Input).value = ""
            self.query_one("#extension-id-input", Input).value = ""
            self.query_one("#result-area", TextArea).text = ""
        elif event.button.id == "back-btn":
            self.action_back()
    
    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle input submission."""
        if event.input.id == "extension-id-input":
            await self._check_enabled()
        elif event.input.id == "flag-id-input":
            self.query_one("#account-id-input", Input).focus()
        elif event.input.id == "account-id-input":
            self.query_one("#extension-id-input", Input).focus()
    
    async def _check_enabled(self) -> None:
        """Check if feature is enabled."""
        flag_id = self.query_one("#flag-id-input", Input).value.strip()
        account_id = self.query_one("#account-id-input", Input).value.strip()
        extension_id = self.query_one("#extension-id-input", Input).value.strip()
        
        if not flag_id:
            self.query_one("#check-title", Label).update(
                "⚠️  Please enter Flag ID"
            )
            return
        
        # Build context
        context: Dict[str, Any] = {}
        if account_id:
            context["accountId"] = account_id
        if extension_id:
            context["extensionId"] = extension_id
        
        result_area = self.query_one("#result-area", TextArea)
        self.query_one("#check-title", Label).update("✅ Checking...")
        result_area.text = ""
        
        try:
            result = await ffs_service.check_feature_enabled(flag_id, context)
            
            if not result.success:
                self.query_one("#check-title", Label).update(
                    f"❌ Error: {result.error_message}"
                )
                result_area.text = f"Error: {result.error_message}"
                return
            
            check_data = result.data
            enabled = check_data.get("enabled", False)
            
            status_text = "ENABLED ✅" if enabled else "DISABLED ❌"
            result_text = f"Flag ID: {check_data.get('flagId', 'N/A')}\n"
            result_text += f"Status: {status_text}\n"
            result_text += f"Matched Rule ID: {check_data.get('matchedRuleId', 'N/A')}\n"
            if context:
                result_text += f"Context: {json.dumps(context, indent=2)}"
            
            result_area.text = result_text
            self.query_one("#check-title", Label).update(
                f"✅ Feature {status_text}"
            )
            
        except Exception as e:
            self.query_one("#check-title", Label).update(
                f"❌ Error: {str(e)}"
            )
            result_area.text = f"Error: {str(e)}"


class FFSInfoScreen(Screen):
    """Screen for server information."""
    
    BINDINGS = [
        Binding("escape", "back", "Back", priority=True),
    ]
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            with Container(id="info-container"):
                yield Label("🔧 Server Information", id="info-title")
                yield TextArea(id="info-area", read_only=True)
                with Horizontal(id="info-buttons"):
                    yield Button("Refresh", id="refresh-btn", variant="primary")
                    yield Button("Clear Cache", id="clear-cache-btn")
                    yield Button("Back", id="back-btn")
        yield Footer()
    
    def action_back(self) -> None:
        """Go back to previous screen."""
        self.app.pop_screen()
    
    def on_mount(self) -> None:
        """Initialize the info screen."""
        self._load_server_info()
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "refresh-btn":
            self._load_server_info()
        elif event.button.id == "clear-cache-btn":
            ffs_service.clear_cache()
            self._load_server_info()
            self.query_one("#info-title", Label).update(
                "✅ Cache cleared successfully"
            )
        elif event.button.id == "back-btn":
            self.action_back()
    
    def _load_server_info(self) -> None:
        """Load server information."""
        server_info = ffs_service.get_server_info()
        formatted_output = ffs_service.format_server_info_display(server_info)
        
        info_area = self.query_one("#info-area", TextArea)
        info_area.text = formatted_output
        self.query_one("#info-title", Label).update("🔧 Server Information")


class MainMenuScreen(Screen):
    """Main menu screen."""
    
    BINDINGS = [
        Binding("q", "quit", "Quit", priority=True),
    ]
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            with Container(id="menu-container"):
                yield Label("🚩 Feature Flag Service (FFS) Management", id="menu-title")
                with Vertical(id="menu-buttons"):
                    yield Button("🔍 Search Flags", id="search-btn", variant="primary")
                    yield Button("📖 Get Flag", id="get-btn")
                    yield Button("📊 Evaluate Flag", id="evaluate-btn")
                    yield Button("✅ Check Enabled", id="check-btn")
                    yield Button("🔧 Server Info", id="info-btn")
                    yield Button("❌ Exit", id="exit-btn")
        yield Footer()
    
    def action_quit(self) -> None:
        """Quit the application."""
        self.app.exit()
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "search-btn":
            self.app.push_screen("search")
        elif event.button.id == "get-btn":
            self.app.push_screen("get")
        elif event.button.id == "evaluate-btn":
            self.app.push_screen("evaluate")
        elif event.button.id == "check-btn":
            self.app.push_screen("check")
        elif event.button.id == "info-btn":
            self.app.push_screen("info")
        elif event.button.id == "exit-btn":
            self.app.exit()


class FFSTUIApp(App):
    """Main TUI application for FFS management."""
    
    CSS = """
    Screen {
        align: center middle;
    }
    
    #menu-container {
        width: 60;
        height: auto;
        border: solid $primary;
        padding: 1;
    }
    
    #menu-title {
        text-align: center;
        width: 100%;
        margin: 1;
    }
    
    #menu-buttons {
        width: 100%;
        height: auto;
    }
    
    #menu-buttons > Button {
        width: 100%;
        margin: 1;
    }
    
    #search-container, #get-container, #evaluate-container,
    #check-container, #info-container {
        width: 90;
        height: auto;
        border: solid $primary;
        padding: 1;
    }
    
    #search-title, #get-title, #evaluate-title,
    #check-title, #info-title {
        text-align: center;
        width: 100%;
        margin: 1;
    }
    
    #search-results {
        height: 20;
        width: 100%;
    }
    
    #result-area, #info-area {
        height: 30;
        width: 100%;
    }
    
    #search-input, #flag-id-input, #account-id-input,
    #extension-id-input, #email-domain-input {
        width: 100%;
        margin: 1;
    }
    
    #search-buttons, #get-buttons, #evaluate-buttons,
    #check-buttons, #info-buttons {
        width: 100%;
        height: auto;
        margin-top: 1;
    }
    
    #search-buttons > Button, #get-buttons > Button,
    #evaluate-buttons > Button, #check-buttons > Button,
    #info-buttons > Button {
        margin: 1;
    }
    """
    
    TITLE = "FFS Management TUI"
    BINDINGS = [
        Binding("q", "quit", "Quit", priority=True),
        Binding("escape", "back", "Back", priority=True),
    ]
    
    def on_mount(self) -> None:
        """Set up the initial screen."""
        self.push_screen("main")
    
    def action_quit(self) -> None:
        """Quit the application."""
        self.exit()
    
    def action_back(self) -> None:
        """Go back to previous screen."""
        if len(self.screen_stack) > 1:
            self.pop_screen()
    
    def push_screen(self, screen_name: str) -> None:
        """Push a screen by name."""
        screens = {
            "main": MainMenuScreen(),
            "search": FFSSearchScreen(),
            "get": FFSGetScreen(),
            "evaluate": FFSEvaluateScreen(),
            "check": FFSCheckScreen(),
            "info": FFSInfoScreen(),
        }
        
        if screen_name in screens:
            super().push_screen(screens[screen_name])


def run_tui():
    """Run the TUI application."""
    try:
        app = FFSTUIApp()
        app.run()
    except Exception as e:
        import sys
        print(f"Error running TUI: {e}", file=sys.stderr)
        raise


if __name__ == "__main__":
    run_tui()

