# -*- coding: utf-8 -*-

"""Interactive TUI for Service Parameter (SP) management."""

import asyncio
from typing import Dict, List, Optional, Any
from textual.app import App, ComposeResult
from textual.screen import Screen
from textual.containers import Container, Horizontal, Vertical
from textual.widgets import (
    Button,
    DataTable,
    Footer,
    Header,
    Input,
    Label,
    Log,
    Static,
    TextArea,
)
from textual.binding import Binding
from textual import events
from .sp_service import sp_service
from my_cli_utilities_common.config import DisplayUtils


class SPSearchScreen(Screen):
    """Search screen for SP parameters."""
    
    BINDINGS = [
        Binding("escape", "back", "Back", priority=True),
    ]
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            with Container(id="search-container"):
                yield Label("🔍 Search Service Parameters", id="search-title")
                yield Input(
                    placeholder="Enter search query...",
                    id="search-input"
                )
                yield DataTable(id="search-results")
                with Horizontal(id="search-buttons"):
                    yield Button("Search", id="search-btn", variant="primary")
                    yield Button("Clear", id="clear-btn")
                    yield Button("Back", id="back-btn")
        yield Footer()
    
    def action_back(self) -> None:
        """Go back to previous screen."""
        self.app.pop_screen()
    
    def on_mount(self) -> None:
        """Initialize the search screen."""
        table = self.query_one("#search-results", DataTable)
        table.add_columns("SP ID", "Description")
        self.query_one("#search-input", Input).focus()
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "search-btn":
            await self._perform_search()
        elif event.button.id == "clear-btn":
            self.query_one("#search-input", Input).value = ""
            table = self.query_one("#search-results", DataTable)
            table.clear()
        elif event.button.id == "back-btn":
            self.action_back()
    
    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle input submission."""
        if event.input.id == "search-input":
            await self._perform_search()
    
    async def _perform_search(self) -> None:
        """Perform SP search."""
        input_widget = self.query_one("#search-input", Input)
        query = input_widget.value.strip()
        
        if not query:
            return
        
        table = self.query_one("#search-results", DataTable)
        table.clear()
        
        # Show loading
        self.query_one("#search-title", Label).update("🔍 Searching...")
        
        try:
            result = await sp_service.search_service_parameters(query)
            
            if not result.success:
                self.query_one("#search-title", Label).update(
                    f"❌ Error: {result.error_message}"
                )
                return
            
            matching_sps = result.data
            
            if not matching_sps:
                self.query_one("#search-title", Label).update(
                    f"🔍 No results found for '{query}'"
                )
                return
            
            # Add results to table
            for sp_id, description in matching_sps.items():
                # Truncate description if too long
                display_desc = description
                if len(display_desc) > 60:
                    display_desc = display_desc[:57] + "..."
                table.add_row(sp_id, display_desc, key=sp_id)
            
            self.query_one("#search-title", Label).update(
                f"🔍 Found {len(matching_sps)} results for '{query}'"
            )
            
        except Exception as e:
            self.query_one("#search-title", Label).update(
                f"❌ Error: {str(e)}"
            )


class SPListScreen(Screen):
    """List screen for all SP parameters."""
    
    BINDINGS = [
        Binding("escape", "back", "Back", priority=True),
    ]
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            with Container(id="list-container"):
                yield Label("📋 All Service Parameters", id="list-title")
                yield DataTable(id="sp-list")
                with Horizontal(id="list-buttons"):
                    yield Button("Refresh", id="refresh-btn", variant="primary")
                    yield Button("Search", id="search-btn")
                    yield Button("Back", id="back-btn")
        yield Footer()
    
    def action_back(self) -> None:
        """Go back to previous screen."""
        self.app.pop_screen()
    
    def on_mount(self) -> None:
        """Initialize the list screen."""
        table = self.query_one("#sp-list", DataTable)
        table.add_columns("SP ID", "Description")
        self.app.call_later(self._load_sp_list)
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "refresh-btn":
            await self._load_sp_list()
        elif event.button.id == "search-btn":
            self.app.push_screen("search")
        elif event.button.id == "back-btn":
            self.action_back()
    
    async def _load_sp_list(self) -> None:
        """Load all SP parameters."""
        table = self.query_one("#sp-list", DataTable)
        table.clear()
        
        self.query_one("#list-title", Label).update("📋 Loading...")
        
        try:
            result = await sp_service.get_all_service_parameters()
            
            if not result.success:
                self.query_one("#list-title", Label).update(
                    f"❌ Error: {result.error_message}"
                )
                return
            
            service_parameters = result.data
            
            # Add results to table
            for sp_id, description in service_parameters.items():
                # Truncate description if too long
                display_desc = description
                if len(display_desc) > 60:
                    display_desc = display_desc[:57] + "..."
                table.add_row(sp_id, display_desc, key=sp_id)
            
            self.query_one("#list-title", Label).update(
                f"📋 {len(service_parameters)} Service Parameters"
            )
            
        except Exception as e:
            self.query_one("#list-title", Label).update(
                f"❌ Error: {str(e)}"
            )


class SPGetValueScreen(Screen):
    """Screen for getting SP value."""
    
    BINDINGS = [
        Binding("escape", "back", "Back", priority=True),
    ]
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            with Container(id="get-container"):
                yield Label("📊 Get Service Parameter Value", id="get-title")
                yield Input(placeholder="SP ID (e.g., SP-123)", id="sp-id-input")
                yield Input(placeholder="Account ID (e.g., 8023391076)", id="account-id-input")
                yield TextArea(id="result-area", read_only=True)
                with Horizontal(id="get-buttons"):
                    yield Button("Get Value", id="get-btn", variant="primary")
                    yield Button("Clear", id="clear-btn")
                    yield Button("Back", id="back-btn")
        yield Footer()
    
    def action_back(self) -> None:
        """Go back to previous screen."""
        self.app.pop_screen()
    
    def on_mount(self) -> None:
        """Initialize the get value screen."""
        self.query_one("#sp-id-input", Input).focus()
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "get-btn":
            await self._get_sp_value()
        elif event.button.id == "clear-btn":
            self.query_one("#sp-id-input", Input).value = ""
            self.query_one("#account-id-input", Input).value = ""
            self.query_one("#result-area", TextArea).text = ""
        elif event.button.id == "back-btn":
            self.action_back()
    
    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle input submission."""
        if event.input.id == "account-id-input":
            await self._get_sp_value()
        elif event.input.id == "sp-id-input":
            self.query_one("#account-id-input", Input).focus()
    
    async def _get_sp_value(self) -> None:
        """Get SP value for account."""
        sp_id = self.query_one("#sp-id-input", Input).value.strip()
        account_id = self.query_one("#account-id-input", Input).value.strip()
        
        if not sp_id or not account_id:
            self.query_one("#get-title", Label).update(
                "⚠️  Please enter both SP ID and Account ID"
            )
            return
        
        result_area = self.query_one("#result-area", TextArea)
        self.query_one("#get-title", Label).update("📊 Loading...")
        result_area.text = ""
        
        try:
            result = await sp_service.get_service_parameter_value(sp_id, account_id)
            
            if not result.success:
                self.query_one("#get-title", Label).update(
                    f"❌ Error: {result.error_message}"
                )
                result_area.text = f"Error: {result.error_message}"
                return
            
            sp_data = result.data
            formatted_output = sp_service.format_sp_value_display(sp_data)
            
            result_area.text = formatted_output
            self.query_one("#get-title", Label).update(
                f"✅ SP {sp_id} value retrieved"
            )
            
        except Exception as e:
            self.query_one("#get-title", Label).update(
                f"❌ Error: {str(e)}"
            )
            result_area.text = f"Error: {str(e)}"


class SPDefinitionScreen(Screen):
    """Screen for getting SP definition."""
    
    BINDINGS = [
        Binding("escape", "back", "Back", priority=True),
    ]
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            with Container(id="definition-container"):
                yield Label("📖 Get Service Parameter Definition", id="definition-title")
                yield Input(placeholder="SP ID (e.g., SP-123)", id="sp-id-input")
                yield TextArea(id="result-area", read_only=True)
                with Horizontal(id="definition-buttons"):
                    yield Button("Get Definition", id="get-btn", variant="primary")
                    yield Button("Clear", id="clear-btn")
                    yield Button("Back", id="back-btn")
        yield Footer()
    
    def action_back(self) -> None:
        """Go back to previous screen."""
        self.app.pop_screen()
    
    def on_mount(self) -> None:
        """Initialize the definition screen."""
        self.query_one("#sp-id-input", Input).focus()
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "get-btn":
            await self._get_sp_definition()
        elif event.button.id == "clear-btn":
            self.query_one("#sp-id-input", Input).value = ""
            self.query_one("#result-area", TextArea).text = ""
        elif event.button.id == "back-btn":
            self.action_back()
    
    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle input submission."""
        if event.input.id == "sp-id-input":
            await self._get_sp_definition()
    
    async def _get_sp_definition(self) -> None:
        """Get SP definition."""
        sp_id = self.query_one("#sp-id-input", Input).value.strip()
        
        if not sp_id:
            self.query_one("#definition-title", Label).update(
                "⚠️  Please enter SP ID"
            )
            return
        
        result_area = self.query_one("#result-area", TextArea)
        self.query_one("#definition-title", Label).update("📖 Loading...")
        result_area.text = ""
        
        try:
            result = await sp_service.get_service_parameter_definition(sp_id)
            
            if not result.success:
                self.query_one("#definition-title", Label).update(
                    f"❌ Error: {result.error_message}"
                )
                result_area.text = f"Error: {result.error_message}"
                return
            
            sp_definition = result.data
            formatted_output = sp_service.format_sp_definition_display(sp_definition)
            
            result_area.text = formatted_output
            self.query_one("#definition-title", Label).update(
                f"✅ SP {sp_id} definition retrieved"
            )
            
        except Exception as e:
            self.query_one("#definition-title", Label).update(
                f"❌ Error: {str(e)}"
            )
            result_area.text = f"Error: {str(e)}"


class SPInfoScreen(Screen):
    """Screen for server information."""
    
    BINDINGS = [
        Binding("escape", "back", "Back", priority=True),
    ]
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            with Container(id="info-container"):
                yield Label("🔧 Server Information", id="info-title")
                yield TextArea(id="info-area", read_only=True)
                with Horizontal(id="info-buttons"):
                    yield Button("Refresh", id="refresh-btn", variant="primary")
                    yield Button("Clear Cache", id="clear-cache-btn")
                    yield Button("Back", id="back-btn")
        yield Footer()
    
    def action_back(self) -> None:
        """Go back to previous screen."""
        self.app.pop_screen()
    
    def on_mount(self) -> None:
        """Initialize the info screen."""
        self._load_server_info()
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "refresh-btn":
            self._load_server_info()
        elif event.button.id == "clear-cache-btn":
            sp_service.clear_cache()
            self._load_server_info()
            self.query_one("#info-title", Label).update(
                "✅ Cache cleared successfully"
            )
        elif event.button.id == "back-btn":
            self.action_back()
    
    def _load_server_info(self) -> None:
        """Load server information."""
        server_info = sp_service.get_server_info()
        formatted_output = sp_service.format_server_info_display(server_info)
        
        info_area = self.query_one("#info-area", TextArea)
        info_area.text = formatted_output
        self.query_one("#info-title", Label).update("🔧 Server Information")


class MainMenuScreen(Screen):
    """Main menu screen."""
    
    BINDINGS = [
        Binding("q", "quit", "Quit", priority=True),
    ]
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            with Container(id="menu-container"):
                yield Label("🔧 Service Parameter (SP) Management", id="menu-title")
                with Vertical(id="menu-buttons"):
                    yield Button("📋 List All SPs", id="list-btn", variant="primary")
                    yield Button("🔍 Search SPs", id="search-btn")
                    yield Button("📊 Get SP Value", id="get-value-btn")
                    yield Button("📖 Get SP Definition", id="get-definition-btn")
                    yield Button("🔧 Server Info", id="info-btn")
                    yield Button("❌ Exit", id="exit-btn")
        yield Footer()
    
    def action_quit(self) -> None:
        """Quit the application."""
        self.app.exit()
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "list-btn":
            self.app.push_screen("list")
        elif event.button.id == "search-btn":
            self.app.push_screen("search")
        elif event.button.id == "get-value-btn":
            self.app.push_screen("get_value")
        elif event.button.id == "get-definition-btn":
            self.app.push_screen("definition")
        elif event.button.id == "info-btn":
            self.app.push_screen("info")
        elif event.button.id == "exit-btn":
            self.app.exit()


class SPTUIApp(App):
    """Main TUI application for SP management."""
    
    CSS = """
    Screen {
        align: center middle;
    }
    
    #menu-container {
        width: 60;
        height: auto;
        border: solid $primary;
        padding: 1;
    }
    
    #menu-title {
        text-align: center;
        width: 100%;
        margin: 1;
    }
    
    #menu-buttons {
        width: 100%;
        height: auto;
    }
    
    #menu-buttons > Button {
        width: 100%;
        margin: 1;
    }
    
    #search-container, #list-container, #get-container, 
    #definition-container, #info-container {
        width: 80;
        height: auto;
        border: solid $primary;
        padding: 1;
    }
    
    #search-title, #list-title, #get-title, 
    #definition-title, #info-title {
        text-align: center;
        width: 100%;
        margin: 1;
    }
    
    #search-results, #sp-list {
        height: 20;
        width: 100%;
    }
    
    #result-area, #info-area {
        height: 10;
        width: 100%;
    }
    
    #search-input, #sp-id-input, #account-id-input {
        width: 100%;
        margin: 1;
    }
    
    #search-buttons, #list-buttons, #get-buttons, 
    #definition-buttons, #info-buttons {
        width: 100%;
        height: auto;
        margin-top: 1;
    }
    
    #search-buttons > Button, #list-buttons > Button,
    #get-buttons > Button, #definition-buttons > Button,
    #info-buttons > Button {
        margin: 1;
    }
    """
    
    TITLE = "SP Management TUI"
    BINDINGS = [
        Binding("q", "quit", "Quit", priority=True),
        Binding("escape", "back", "Back", priority=True),
    ]
    
    def on_mount(self) -> None:
        """Set up the initial screen."""
        # Push the main menu as the initial screen
        self.push_screen("main")
    
    def action_quit(self) -> None:
        """Quit the application."""
        self.exit()
    
    def action_back(self) -> None:
        """Go back to previous screen."""
        if len(self.screen_stack) > 1:
            self.pop_screen()
    
    def push_screen(self, screen_name: str) -> None:
        """Push a screen by name."""
        screens = {
            "main": MainMenuScreen(),
            "list": SPListScreen(),
            "search": SPSearchScreen(),
            "get_value": SPGetValueScreen(),
            "definition": SPDefinitionScreen(),
            "info": SPInfoScreen(),
        }
        
        if screen_name in screens:
            super().push_screen(screens[screen_name])


def run_tui():
    """Run the TUI application."""
    try:
        app = SPTUIApp()
        app.run()
    except Exception as e:
        import sys
        print(f"Error running TUI: {e}", file=sys.stderr)
        raise


if __name__ == "__main__":
    run_tui()

