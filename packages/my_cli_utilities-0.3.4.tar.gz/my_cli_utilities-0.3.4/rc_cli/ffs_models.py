# -*- coding: utf-8 -*-

"""Data models for Feature Flag Service (FFS) operations."""

from typing import Optional, Dict, Any
from dataclasses import dataclass


@dataclass
class FFSResult:
    """Result wrapper for FFS operations."""
    
    success: bool
    data: Optional[Any] = None
    error_message: str = ""
    count: int = 0


class FFSConfig:
    """Configuration for FFS operations."""
    
    # FFS API settings
    DEFAULT_BASE_URL = "http://aws16-c01-ffs01.ffs.svc.c01.eks02.k8s.aws16.lab.nordigy.ru:8080"
    DEFAULT_TIMEOUT = 30.0
    CACHE_TTL = 300  # 5 minutes
    
    # Request settings
    MAX_SEARCH_RESULTS = 100
    MAX_DESCRIPTION_LENGTH = 80

