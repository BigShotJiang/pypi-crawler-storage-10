"""Test package for shinkuro."""
