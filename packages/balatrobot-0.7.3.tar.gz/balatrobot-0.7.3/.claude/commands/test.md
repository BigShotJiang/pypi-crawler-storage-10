Run tests following the testing guidelines in CLAUDE.md.

See the Testing section in CLAUDE.md for complete instructions on prerequisites, workflow, and troubleshooting.
