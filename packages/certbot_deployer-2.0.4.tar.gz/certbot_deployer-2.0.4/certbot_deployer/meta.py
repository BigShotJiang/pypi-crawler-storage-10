"""
Package metadata
"""

__author__ = "IAS"
__version__ = "2.0.4"
__title__ = "certbot_deployer"
__prog__ = "certbot-deployer"
__license__ = "License :: OSI Approved :: MIT License"
