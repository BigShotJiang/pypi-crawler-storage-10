Manage your (un)loading process through shipment advices.
