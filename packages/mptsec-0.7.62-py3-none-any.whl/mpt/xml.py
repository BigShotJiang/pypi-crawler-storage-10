#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import xml.dom.minidom

from colorama import Fore, Back, Style
from mpt import functions
from mpt import settings, logger
from mpt.config import Config


global log
log = logger.getLogger()

DEFAULT_NETWORK_CONFIG_XML = """<?xml version="1.0" ?>
<network-security-config> 
    <base-config> 
        <trust-anchors> 
            <certificates src="system" /> 
            <certificates src="user" /> 
        </trust-anchors> 
    </base-config> 
</network-security-config>
"""


def xml_file_exists(path):
    return os.path.exists(path)


def xml_file_create(path, content):
    with open(path, 'w') as file:
        file.write(content)

def xml_file_update(path, content):
    if not xml_file_exists(path):
        return False

    with open(path, 'w') as file: # With 'w' mode the file is truncated automatically
        file.write(content)

    return True


def xml_update_attribute(path, tag, attr_name, attr_value):
    if not xml_file_exists(path):
        return False

    log.info("Updating attribute " + Fore.CYAN + attr_name + Fore.WHITE)

    # Parse file and get given tags
    xml_file = xml.dom.minidom.parse(path)
    xml_tags = xml_file.getElementsByTagName(tag)
    if not xml_tags:
        log.error("Given xml tag not found!")
        return False

    # Loop through all found tags and set given attribute
    for tag in xml_tags:
        tag.setAttribute(attr_name, attr_value)

    # Update file
    xml_file_update(path, xml_file.toxml())
    return True


def xml_create_network_config(path):
    if xml_file_exists(path):
        return False

    xml_file_create(path, DEFAULT_NETWORK_CONFIG_XML)
    return True


def xml_update_network_config(path):
    if not xml_file_exists(path):
        return False

    user_cert_exists = False
    network_config = xml.dom.minidom.parse(path)
    root_element = network_config.documentElement

    # Check for <base-config> tag
    base_config = network_config.getElementsByTagName("base-config")
    if not base_config:
        log.warn("No " + Fore.CYAN + "<base-config>" + Fore.YELLOW + " tag found, creating one ...")
        base_config = network_config.createElement("base-config")
        root_element.appendChild(base_config)
        base_config = network_config.getElementsByTagName("base-config")

    # Check for <trust-anchors> tag
    trust_anchors = network_config.getElementsByTagName("trust-anchors")
    if not trust_anchors:
        log.warn("No " + Fore.CYAN + "<trust-anchors>" + Fore.YELLOW + " tag found, creating one ...")
        trust_anchors = network_config.createElement("trust-anchors")
        base_config[0].appendChild(trust_anchors)
        trust_anchors = network_config.getElementsByTagName("trust-anchors")

    # Check for <certificates> tag
    certificates = trust_anchors[0].getElementsByTagName("certificates")
    if certificates:
        for cert in certificates:
            if cert.getAttribute("src") == "user":
                user_cert_exists = True

    if user_cert_exists:
        log.info("Already trusting user certificates, nothing to do ...")
        return False

    # Create <certificates src="user"> tag to trust user certificates
    new_cert_element = network_config.createElement("certificates")
    new_cert_element.setAttribute("src", "user")
    trust_anchors[0].appendChild(new_cert_element)

    # Update xml file
    update_success = xml_file_update(path, network_config.toxml())
    if update_success:
        log.success("User certificates are trusted now")
    else:
        log.error("Could not update XML-File")
        return False

    return True




