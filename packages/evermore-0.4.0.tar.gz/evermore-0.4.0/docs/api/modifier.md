# Modifier

```{eval-rst}
.. automodule:: evermore.binned.modifier
    :show-inheritance:
    :members:
```
