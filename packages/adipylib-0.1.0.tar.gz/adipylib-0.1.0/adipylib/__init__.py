# adipylib/__init__.py

# Import functions from your .py files

# The original basic functions
from .core import hello_adipylib, add_numbers

# Our new, more interesting functions
from .keywords import extract_keywords
from .summarizer import extractive_summary

# IMPORTANT: Update the version here to match pyproject.toml
__version__ = "0.1.0"