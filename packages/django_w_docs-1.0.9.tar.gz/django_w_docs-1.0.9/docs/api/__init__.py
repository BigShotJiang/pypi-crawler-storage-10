"""Django Docs APIs"""
