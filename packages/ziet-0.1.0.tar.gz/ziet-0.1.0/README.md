# ziet

A minimal Python utility package.

## Installation

```bash
pip install ziet
```

## Usage

```python
from ziet import add

result = add(2, 3)
print(result)  # 5
```
