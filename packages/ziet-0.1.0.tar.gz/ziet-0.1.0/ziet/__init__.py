def add(a, b):
    """Add two numbers together."""
    return a + b


__version__ = "0.1.0"
__all__ = ["add"]
