# SevenSeg MicroPython Library
# Author: Kritish Mohapatra
# Year: 2025

from .sevenseg import SevenSeg