#pragma once

#define mir_VERSION_STR "1.27.10"
#define mir_VERSION     "1.27.10"

#define mir_VERSION_MAJOR 1
#define mir_VERSION_MINOR 27
#define mir_VERSION_PATCH 10

const char * mir_version();

unsigned int mir_version_int();

const char * mir_version_str();

const char * mir_git_sha1();
