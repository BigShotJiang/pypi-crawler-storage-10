# mkdocs-material-codeberg-source-facts

Adds support to mkdocs-material to parse codeberg source facts
following [https://github.com/squidfunk/mkdocs-material/issues/5942](https://github.com/squidfunk/mkdocs-material/issues/5942).

To use include in your mkdocs file via

```yaml
theme:
  name: material

plugins:
  - codeberg-source-facts
  - search
```

For more information see [https://helge.codeberg.page/mkdocs-material-codeberg-source-facts/](https://helge.codeberg.page/mkdocs-material-codeberg-source-facts/)