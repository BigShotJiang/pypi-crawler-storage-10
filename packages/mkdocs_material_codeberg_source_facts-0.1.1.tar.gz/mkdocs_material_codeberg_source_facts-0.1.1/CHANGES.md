# Changes

## 0.1.1

* Add ability to comment from Fediverse [source-facts#3](https://codeberg.org/helge/mkdocs-material-codeberg-source-facts/issues/3)
* Enable caching [source-facts#2](https://codeberg.org/helge/mkdocs-material-codeberg-source-facts/issues/2)

## 0.1.0

* initial release