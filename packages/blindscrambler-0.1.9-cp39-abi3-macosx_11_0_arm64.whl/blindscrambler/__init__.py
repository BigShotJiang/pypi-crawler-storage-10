from blindscrambler._core import hello_from_bin
from blindscrambler.model import LinearRegression


def hello() -> str:
    return hello_from_bin()
