"""Context Engine - CLI-based Context Management for AI Coding Tools"""

__version__ = "1.0.0"
