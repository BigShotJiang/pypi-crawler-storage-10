"""Model integrations for Context Engine"""

from .openrouter import OpenRouterClient

__all__ = ['OpenRouterClient']
