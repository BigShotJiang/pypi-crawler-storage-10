"""
Type definitions for Mothership Python
"""
from typing import TypedDict, List, Optional, Callable, Awaitable, Any, Union, Literal, Pattern
from telegram import Update
from telegram.ext import ContextTypes

# Type aliases
CommandHandler = Callable[[Update, ContextTypes.DEFAULT_TYPE], Awaitable[None]]
MessageHandler = Callable[[Update, ContextTypes.DEFAULT_TYPE], Awaitable[None]]
LifecycleHook = Callable[[], Awaitable[None]]

# Query operators
QueryOperator = Literal["==", "!=", ">", ">=", "<", "<=", "array-contains", "in", "array-contains-any"]


class BotConfig(TypedDict, total=False):
    """Bot configuration"""
    name: str  # Required
    description: Optional[str]
    token: Optional[str]


class BotCommand(TypedDict, total=False):
    """Bot command definition"""
    command: str  # Required - without '/' prefix
    description: str  # Required
    handler: CommandHandler  # Required


class BotMessageHandler(TypedDict, total=False):
    """Bot message handler definition"""
    pattern: Optional[Union[str, Pattern[str]]]  # Optional regex/string matching
    handler: MessageHandler  # Required


class BotDefinition(TypedDict, total=False):
    """Bot definition structure"""
    config: BotConfig  # Required
    commands: List[BotCommand]  # Required
    message_handlers: Optional[List[BotMessageHandler]]
    on_start: Optional[LifecycleHook]
    on_stop: Optional[LifecycleHook]


class ValidationResult(TypedDict):
    """Validation result"""
    valid: bool
    errors: List[str]


class StorageFilter(TypedDict):
    """Storage query filter"""
    field: str
    operator: QueryOperator
    value: Any


class DeploymentConfig(TypedDict, total=False):
    """Deployment configuration"""
    platform: Literal["local", "vercel", "netlify"]
    port: Optional[int]
    webhook_url: Optional[str]
    webhook_secret: Optional[str]


class LoggerOptions(TypedDict, total=False):
    """Logger options"""
    level: Optional[Literal["debug", "info", "warn", "error"]]
    prefix: Optional[str]
    colors: Optional[bool]
