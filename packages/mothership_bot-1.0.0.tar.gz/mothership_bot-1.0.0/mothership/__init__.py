"""
Mothership - Python Edition

A minimalist framework for building Telegram bots rapidly.
"""

# Version
__version__ = "1.0.0"

# Core exports
from .bot_factory import BotFactory, BotInstance
from .storage import StorageClient, BotStorage, StorageAdapter
from .logger import Logger, create_logger
from .firebase import FirebaseClient
from .deployer import Deployer, create_webhook_app

# Type exports
from .types import (
    BotDefinition,
    BotConfig,
    BotCommand,
    BotMessageHandler,
    ValidationResult,
    StorageFilter,
    DeploymentConfig,
    LoggerOptions,
    CommandHandler,
    MessageHandler,
    LifecycleHook,
)

# Re-export telegram types for convenience
from telegram import Update
from telegram.ext import ContextTypes

__all__ = [
    # Version
    "__version__",

    # Core classes
    "BotFactory",
    "BotInstance",
    "StorageClient",
    "BotStorage",
    "StorageAdapter",
    "Logger",
    "create_logger",
    "FirebaseClient",
    "Deployer",
    "create_webhook_app",

    # Types
    "BotDefinition",
    "BotConfig",
    "BotCommand",
    "BotMessageHandler",
    "ValidationResult",
    "StorageFilter",
    "DeploymentConfig",
    "LoggerOptions",
    "CommandHandler",
    "MessageHandler",
    "LifecycleHook",

    # Telegram types
    "Update",
    "ContextTypes",
]
