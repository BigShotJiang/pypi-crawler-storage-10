#!/bin/bash
# Publish mothership-bot to PyPI
# Usage: ./publish.sh [test|prod]

set -e

TARGET=${1:-test}

cd "$(dirname "$0")"

echo "🔨 Building package..."
rm -rf dist/
uv build

echo "✅ Build complete:"
ls -lh dist/

echo ""
echo "📦 Package contents:"
tar -tzf dist/mothership_bot-*.tar.gz | head -15

if [ "$TARGET" = "test" ]; then
    echo ""
    echo "🧪 Publishing to TestPyPI..."
    echo "Make sure UV_PUBLISH_TOKEN is set for TestPyPI"
    echo ""
    read -p "Press Enter to continue or Ctrl+C to cancel..."

    uv publish --publish-url https://test.pypi.org/legacy/

    echo ""
    echo "✅ Published to TestPyPI!"
    echo "Test with: pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ mothership-bot"

elif [ "$TARGET" = "prod" ]; then
    echo ""
    echo "🚀 Publishing to PyPI (PRODUCTION)..."
    echo "Make sure UV_PUBLISH_TOKEN is set for PyPI"
    echo ""
    read -p "Are you sure you want to publish to production PyPI? (yes/no): " confirm

    if [ "$confirm" != "yes" ]; then
        echo "Cancelled."
        exit 1
    fi

    uv publish

    echo ""
    echo "✅ Published to PyPI!"
    echo "Install with: pip install mothership-bot"
    echo "View at: https://pypi.org/project/mothership-bot/"

else
    echo "❌ Invalid target: $TARGET"
    echo "Usage: ./publish.sh [test|prod]"
    exit 1
fi
