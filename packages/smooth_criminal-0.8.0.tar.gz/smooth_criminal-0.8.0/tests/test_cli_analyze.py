import logging

from smooth_criminal.cli import analyze_file


def test_analyze_file_handles_relative_imports(tmp_path, caplog):
    package = tmp_path / "pkg"
    package.mkdir()
    (package / "__init__.py").write_text("", encoding="utf-8")
    (package / "helpers.py").write_text(
        """
def helper():
    return 21
""".strip()
        + "\n",
        encoding="utf-8",
    )

    module_source = """
from .helpers import helper


def target():
    total = sum(range(5))
    return helper() + total
"""
    module_path = package / "module.py"
    module_path.write_text(module_source, encoding="utf-8")

    caplog.set_level(logging.INFO, "SmoothCriminal")

    analyze_file(str(module_path))

    messages = "\n".join(caplog.messages)
    assert "Analyzing function" in messages
    assert "target" in messages
    assert not any(record.levelno >= logging.ERROR for record in caplog.records)
