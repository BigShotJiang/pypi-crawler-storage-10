"""
Main entry point for the Commitizen MCP Connector server.
"""

from src.commit_helper_mcp.mcp_server import mcp

# Export the server for MCP dev tools
server = mcp

if __name__ == "__main__":
    # Run the FastMCP server directly
    mcp.run()
