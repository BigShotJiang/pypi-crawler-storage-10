# Quick Start: Commit Helper MCP with Cline

## 🚀 One-Minute Setup

### 1. Add to Cline Settings
In VSCode, press `Cmd/Ctrl + Shift + P` → "Cline: Open Settings" → Add MCP Server:

```json
{
  "name": "commit-helper-mcp",
  "command": "uv",
  "args": ["run", "python", "main.py"],
  "cwd": "/Users/jcarroll/Projects/commit-helper-mcp"
}
```

### 2. Restart Cline
Close and reopen the Cline panel.

### 3. Test Connection
Ask Cline: *"Use the health_check tool to verify the Commitizen MCP server is working"*

## 🎯 What You Get

### Instant Commit Messages
> *"Generate a commit message for adding user authentication"*

**Cline Response:**
```
feat: add user authentication

Implement JWT-based authentication system with login and logout functionality
```

### Git Workflow Integration
> *"Check what files are staged and generate a commit message"*

**Cline will:**
1. Check `git status` 
2. Generate appropriate commit message
3. Show preview before committing
4. Ask for confirmation

### Safety Features
- **Preview First**: See what will happen before execution
- **Force Confirmation**: Actual commits require explicit approval
- **Validation**: Messages checked against your project's rules
- **Repository Aware**: Only works in valid git repositories

## 🛠️ Available Tools

| Tool | Purpose | Safety |
|------|---------|--------|
| `generate_commit_message` | Create conventional commits | ✅ Safe |
| `validate_commit_message` | Check message format | ✅ Safe |
| `get_git_status` | Check repository status | ✅ Safe |
| `preview_git_commit` | Preview commits (dry-run) | ✅ Safe |
| `execute_git_commit` | Actually commit changes | ⚠️ Requires force flag |
| `validate_commit_readiness` | Check if ready to commit | ✅ Safe |

## 📋 Project Setup

For each project, add to `pyproject.toml`:

```toml
[tool.commitizen]
name = "cz_conventional_commits"
tag_format = "v$version"
version_scheme = "semver"
```

## 🎉 Ready to Use!

The server is now available to Cline in any git repository. Just ask Cline to help with commits and it will automatically use the appropriate tools.

**Example workflows:**
- *"Generate a commit message for this bug fix"*
- *"Check if the repository is ready for commit"*
- *"Create and preview a commit for the new feature"*
- *"Validate this commit message: 'fix: resolve memory leak'"*

The connector automatically detects your project's Commitizen configuration and generates messages that follow your team's standards.
