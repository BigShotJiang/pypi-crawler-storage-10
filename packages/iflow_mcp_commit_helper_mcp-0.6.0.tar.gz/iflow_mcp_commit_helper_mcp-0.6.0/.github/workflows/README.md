# GitHub Actions Workflows

This directory contains the GitHub Actions workflows for the Commit Helper MCP project.

## Workflows Overview

### 1. Reusable Checks (`reusable-checks.yml`)
A reusable workflow that runs tests, linting, and formatting checks. This workflow is called by other workflows to avoid duplication.

**Runs:**
- `uv run pytest` - Run all tests
- `uv run ruff check src/ tests/` - Check code linting
- `uv run ruff format --check src/ tests/` - Check code formatting

### 2. PR Checks (`pr-checks.yml`)
Automatically runs when a PR is opened, synchronized, or marked ready for review.

**Actions:**
1. Calls the reusable checks workflow
2. If checks pass and PR is not a draft, adds a comment with approval instructions

### 3. PR Version Bump (`pr-version-bump.yml`)
Triggered by PR comments containing `/approve-version-bump`.

**Actions:**
1. Validates the comment is on a PR
2. Checks out the PR branch
3. Uses Commitizen to bump version and update changelog
4. Merges the PR with the version bump commit

### 4. Code Checks (`checks.yml`)
Runs on all branches except `main` when code is pushed.

**Actions:**
- Calls the reusable checks workflow

### 5. Build and Release (`release.yml`)
Runs when code is pushed to the `main` branch.

**Actions:**
1. Builds the Python package
2. Creates a GitHub release with the built artifacts
3. Publishes the package to PyPI using trusted publishing

## Workflow Usage

### For Contributors

1. Create a feature branch from `main`
2. Make your changes and push to your branch
3. The `checks.yml` workflow will automatically run tests, linting, and formatting
4. Create a PR to merge your branch into `main`
5. The `pr-checks.yml` workflow will run and add approval instructions if checks pass

### For Maintainers

1. Review the PR and ensure all checks pass
2. When ready to merge, add a comment with `/approve-version-bump`
3. The `pr-version-bump.yml` workflow will:
   - Bump the version based on commit messages
   - Update the changelog
   - Merge the PR
4. Once merged, the `release.yml` workflow will automatically:
   - Build the package
   - Create a GitHub release
   - Publish to PyPI

## Branch Strategy

Each journal folder should be its own branch where work is completed:
- `journal/context-provider`
- `journal/git`
- `journal/git-terminal-tasks`
- `journal/refactor`
- `journal/v0`

Work is done in these branches and merged to `main` via pull requests.

## Required Secrets

- `GITHUB_TOKEN` - Automatically provided by GitHub Actions
- PyPI publishing uses trusted publishing (OIDC), so no PyPI token is needed

## Permissions

The workflows require the following permissions:
- `contents: write` - For creating releases and pushing commits
- `pull-requests: write` - For adding comments to PRs
- `id-token: write` - For PyPI trusted publishing
