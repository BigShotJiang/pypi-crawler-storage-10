"""
Custom Test Assertions

Provides domain-specific assertions for testing.
"""

from typing import Dict, Any, List


def assert_valid_commit_message(message: str):
    """Assert that a commit message follows conventional format."""
    assert isinstance(message, str)
    assert len(message) > 0
    assert ":" in message

    # Basic conventional commit format check
    parts = message.split(":", 1)
    assert len(parts) == 2
    assert len(parts[0].strip()) > 0
    assert len(parts[1].strip()) > 0


def assert_mcp_tool_response(response: Dict[str, Any]):
    """Assert that response follows MCP tool format."""
    assert isinstance(response, dict)

    # Should have either success=True or error field
    if "success" in response:
        assert isinstance(response["success"], bool)
    else:
        assert "error" in response


def assert_git_status_response(response: Dict[str, Any]):
    """Assert that git status response is valid."""
    assert_mcp_tool_response(response)

    if response.get("success"):
        assert "staged_files" in response
        assert isinstance(response["staged_files"], list)
        assert "staged_count" in response
        assert isinstance(response["staged_count"], int)


def assert_error_response(response: Dict[str, Any]):
    """Assert that error response has proper structure."""
    assert isinstance(response, dict)
    assert response.get("success") is False
    assert "error" in response
    assert isinstance(response["error"], str)
    assert len(response["error"]) > 0
