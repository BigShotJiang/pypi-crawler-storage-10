"""
Mock Creation Utilities

Provides functions to create mock objects for testing.
"""

from unittest.mock import Mock, MagicMock
from typing import Dict, Any, List, Optional
from pathlib import Path


def create_mock_repo(
    working_dir: str = "/test/repo",
    current_branch: str = "main",
    staged_files: Optional[List[str]] = None,
) -> Mock:
    """Create a mock git repository."""
    mock_repo = MagicMock()
    mock_repo.working_dir = working_dir
    mock_repo.git_dir = f"{working_dir}/.git"

    # Mock active branch
    mock_branch = Mock()
    mock_branch.name = current_branch
    mock_repo.active_branch = mock_branch

    # Mock index for staged files
    if staged_files:
        mock_repo.index.diff.return_value = [Mock(a_path=f) for f in staged_files]

    return mock_repo


def create_mock_config(
    plugin_name: str = "cz_conventional_commits", version: str = "0.1.0"
) -> Dict[str, Any]:
    """Create a mock Commitizen configuration."""
    return {
        "commitizen": {
            "name": plugin_name,
            "version": version,
            "tag_format": "v$version",
            "update_changelog_on_bump": True,
        }
    }


def create_mock_response(
    success: bool = True,
    data: Optional[Dict[str, Any]] = None,
    error: Optional[str] = None,
) -> Dict[str, Any]:
    """Create a mock MCP tool response."""
    response = {"success": success}

    if success and data:
        response.update(data)
    elif not success and error:
        response["error"] = error

    return response


def create_mock_mcp_tool(
    name: str,
    return_value: Optional[Dict[str, Any]] = None,
    side_effect: Optional[Exception] = None,
) -> Mock:
    """Create a mock MCP tool function."""
    mock_tool = Mock()
    mock_tool.__name__ = name

    if side_effect:
        mock_tool.side_effect = side_effect
    elif return_value:
        mock_tool.return_value = return_value
    else:
        mock_tool.return_value = create_mock_response(success=True)

    return mock_tool


def create_mock_service(service_type: str = "commitizen") -> Mock:
    """Create a mock service based on type."""
    mock_service = Mock()

    if service_type == "commitizen":
        mock_service.generate_message.return_value = "feat: add new feature"
        mock_service.validate_message.return_value = True
        mock_service.get_commit_types.return_value = [
            {"name": "feat", "value": "feat"},
            {"name": "fix", "value": "fix"},
        ]
    elif service_type == "git":
        mock_service.is_git_project.return_value = True
        mock_service.get_staged_files.return_value = ["test.py"]
        mock_service.preview_commit.return_value = {
            "success": True,
            "staged_files": ["test.py"],
        }

    return mock_service
