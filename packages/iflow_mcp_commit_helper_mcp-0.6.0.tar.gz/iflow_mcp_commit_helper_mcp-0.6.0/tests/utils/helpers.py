"""
Test Helper Functions

Provides utility functions to simplify test setup and execution.
"""

import os
import tempfile
from pathlib import Path
from typing import Dict, Any, Optional
from git import Repo


def create_test_repository(path: Optional[Path] = None) -> Repo:
    """Create a test git repository with initial setup."""
    if path is None:
        path = Path(tempfile.mkdtemp())

    repo = Repo.init(path)

    # Configure git user
    with repo.config_writer() as config:
        config.set_value("user", "name", "Test User")
        config.set_value("user", "email", "test@example.com")

    # Create initial commit
    readme = path / "README.md"
    readme.write_text("# Test Repository\n")
    repo.index.add([str(readme)])
    repo.index.commit("Initial commit")

    return repo


def create_test_config(path: Path, config_type: str = "conventional") -> Path:
    """Create a test Commitizen configuration file."""
    config_file = path / "pyproject.toml"

    if config_type == "conventional":
        config_file.write_text("""
[tool.commitizen]
name = "cz_conventional_commits"
version = "0.1.0"
tag_format = "v$version"
update_changelog_on_bump = true
""")
    elif config_type == "custom":
        config_file.write_text("""
[tool.commitizen]
name = "cz_custom"
version = "1.0.0"

[tool.commitizen.customize]
message_template = "{{change_type}}: {{message}}"
example = "feat: add new feature"
schema = "<type>: <subject>"
""")

    return config_file


def run_mcp_tool(tool_name: str, **kwargs) -> Dict[str, Any]:
    """Helper to run an MCP tool with given parameters."""
    # This is a placeholder that would be implemented based on actual tool running mechanism
    # In real tests, this would import and call the actual tool functions
    return {
        "success": True,
        "tool": tool_name,
        "parameters": kwargs,
        "result": f"Mock result for {tool_name}",
    }


def setup_test_environment(temp_dir: Path) -> Dict[str, Any]:
    """Set up a complete test environment with repo and config."""
    repo = create_test_repository(temp_dir)
    config = create_test_config(temp_dir)

    return {"repo": repo, "config": config, "path": temp_dir}


def cleanup_test_environment(env: Dict[str, Any]):
    """Clean up test environment."""
    import shutil

    if "path" in env and env["path"].exists():
        shutil.rmtree(env["path"])
