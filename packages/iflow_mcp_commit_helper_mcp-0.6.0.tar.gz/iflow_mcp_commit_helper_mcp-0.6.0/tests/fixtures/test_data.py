"""
Test Data Fixtures

Provides sample data for testing.
"""

import pytest
from typing import List, Dict, Any


@pytest.fixture
def sample_commit_messages() -> List[str]:
    """Sample commit messages for testing."""
    return [
        "feat: add user authentication",
        "fix(api): resolve authentication bug",
        "docs: update README with installation instructions",
        "style: format code according to black",
        "refactor: restructure user module",
        "test: add unit tests for auth service",
        "chore: update dependencies",
        "ci: add GitHub Actions workflow",
        "build: update webpack configuration",
        "perf: optimize database queries",
    ]


@pytest.fixture
def sample_git_status() -> Dict[str, Any]:
    """Sample git status response."""
    return {
        "success": True,
        "git_enabled": True,
        "staged_files": ["src/auth.py", "tests/test_auth.py"],
        "staged_count": 2,
        "repository_path": "/path/to/repo",
        "repository_status": {
            "current_branch": "main",
            "has_staged_files": True,
            "has_unstaged_files": False,
            "is_clean": False,
        },
    }


@pytest.fixture
def sample_mcp_responses() -> Dict[str, Dict[str, Any]]:
    """Sample MCP tool responses."""
    return {
        "generate_commit_message": {
            "message": "feat(auth): add JWT authentication",
            "is_valid": True,
            "parameters": {
                "type": "feat",
                "subject": "add JWT authentication",
                "scope": "auth",
            },
        },
        "validate_commit_message": {
            "is_valid": True,
            "message": "feat: add new feature",
            "validation_details": {
                "pattern_match": True,
                "type_valid": True,
                "subject_valid": True,
            },
        },
        "get_commit_types": {
            "commit_types": [
                {"name": "feat", "value": "feat", "description": "A new feature"},
                {"name": "fix", "value": "fix", "description": "A bug fix"},
            ],
            "count": 2,
            "plugin": "cz_conventional_commits",
        },
        "health_check": {
            "status": "healthy",
            "service_info": {
                "plugin": "cz_conventional_commits",
                "git_enabled": True,
                "version": "0.1.0",
            },
            "timestamp": "2025-01-10T08:00:00Z",
        },
    }
