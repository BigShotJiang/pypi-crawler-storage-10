"""
Mock Service Fixtures

Provides mock implementations of services for testing.
"""

import pytest
from unittest.mock import Mock, MagicMock
from typing import Dict, Any


@pytest.fixture
def mock_commitizen_service():
    """Mock CommitzenCore for testing."""
    service = Mock()
    service.generate_message.return_value = "feat: add new feature"
    service.validate_message.return_value = True
    service.get_commit_types.return_value = [
        {"name": "feat", "value": "feat"},
        {"name": "fix", "value": "fix"},
    ]
    service.get_info.return_value = {
        "plugin_name": "cz_conventional_commits",
        "config": {"name": "cz_conventional_commits"},
    }
    return service


@pytest.fixture
def mock_git_service():
    """Mock GitPythonCore for testing."""
    service = Mock()
    service.is_git_project.return_value = True
    service.get_repository_status.return_value = {
        "is_git_repository": True,
        "staged_files": ["test.py"],
        "unstaged_files": [],
        "untracked_files": [],
    }
    service.preview_commit.return_value = {
        "success": True,
        "staged_files": ["test.py"],
        "would_execute": True,
    }
    service.execute_commit.return_value = {
        "success": True,
        "executed": True,
        "commit_hash": "abc123",
    }
    return service


@pytest.fixture
def mock_mcp_server():
    """Mock MCP server for testing."""
    server = Mock()
    server._tools = {}
    server._resources = {}
    return server
