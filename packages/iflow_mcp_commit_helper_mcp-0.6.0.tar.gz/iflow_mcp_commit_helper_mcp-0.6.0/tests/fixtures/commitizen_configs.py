"""
Commitizen Configuration Fixtures

Provides fixtures for different Commitizen configurations.
"""

import pytest
import json
from pathlib import Path
from typing import Dict, Any


@pytest.fixture
def conventional_commits_config(temp_dir) -> Path:
    """Create a conventional commits configuration."""
    config = {
        "commitizen": {
            "name": "cz_conventional_commits",
            "version": "0.1.0",
            "tag_format": "v$version",
            "update_changelog_on_bump": True,
        }
    }

    config_file = temp_dir / "pyproject.toml"
    config_file.write_text(f"""
[tool.commitizen]
name = "cz_conventional_commits"
version = "0.1.0"
tag_format = "v$version"
update_changelog_on_bump = true
""")

    return temp_dir


@pytest.fixture
def custom_plugin_config(temp_dir) -> Path:
    """Create a custom plugin configuration."""
    config_file = temp_dir / ".cz.toml"
    config_file.write_text("""
[tool.commitizen]
name = "cz_custom"
version = "1.0.0"

[tool.commitizen.customize]
message_template = "{{change_type}}{% if scope %}({{scope}}){% endif %}: {{message}}"
example = "feat(auth): add login endpoint"
schema = "<type>(<scope>): <subject>"
schema_pattern = "^(feat|fix|docs|style|refactor|test|chore)(\\([a-z]+\\))?: .+$"

[[tool.commitizen.customize.questions]]
type = "list"
name = "change_type"
message = "Select the type of change you are committing"
choices = [
    {value = "feat", name = "feat: A new feature"},
    {value = "fix", name = "fix: A bug fix"},
    {value = "docs", name = "docs: Documentation only changes"}
]

[[tool.commitizen.customize.questions]]
type = "input"
name = "scope"
message = "Scope of this change (optional)"

[[tool.commitizen.customize.questions]]
type = "input"
name = "message"
message = "Short description of the change"
""")

    return temp_dir


@pytest.fixture
def invalid_config(temp_dir) -> Path:
    """Create an invalid configuration for error testing."""
    config_file = temp_dir / "pyproject.toml"
    config_file.write_text("""
[tool.commitizen]
# Missing required fields
name = "invalid_plugin_name"
""")

    return temp_dir
