"""
Git Repository Fixtures

Provides fixtures for creating and managing test git repositories.
"""

import pytest
import subprocess
from pathlib import Path
from typing import Generator
from git import Repo


@pytest.fixture
def temp_git_repo(temp_dir) -> Generator[Repo, None, None]:
    """Create a temporary git repository."""
    repo = Repo.init(temp_dir)

    # Configure git user for tests
    with repo.config_writer() as config:
        config.set_value("user", "name", "Test User")
        config.set_value("user", "email", "test@example.com")

    yield repo


@pytest.fixture
def git_repo_with_commits(temp_git_repo) -> Repo:
    """Create git repository with some initial commits."""
    repo = temp_git_repo

    # Create initial commit
    test_file = Path(repo.working_dir) / "README.md"
    test_file.write_text("# Test Repository\n")
    repo.index.add([str(test_file)])
    repo.index.commit("Initial commit")

    # Create second commit
    test_file.write_text("# Test Repository\n\nSome content\n")
    repo.index.add([str(test_file)])
    repo.index.commit("Add content to README")

    return repo


@pytest.fixture
def git_repo_with_staged_files(temp_git_repo) -> Repo:
    """Create git repository with staged files ready for commit."""
    repo = temp_git_repo

    # Create and stage files
    test_file = Path(repo.working_dir) / "test.py"
    test_file.write_text("print('Hello, World!')\n")
    repo.index.add([str(test_file)])

    return repo
