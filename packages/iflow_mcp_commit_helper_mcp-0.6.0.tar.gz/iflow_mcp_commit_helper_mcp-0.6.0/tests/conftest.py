"""
Global Test Configuration

Provides shared fixtures, configuration, and utilities for all tests
in the Commit Helper MCP test suite.
"""

import pytest
import tempfile
import shutil
from pathlib import Path
from typing import Dict, Any, Generator
from unittest.mock import Mock, MagicMock

# Import fixtures from fixtures package
from tests.fixtures.git_repositories import *
from tests.fixtures.commitizen_configs import *
from tests.fixtures.mock_services import *
from tests.fixtures.test_data import *


@pytest.fixture(scope="session")
def test_data_dir() -> Path:
    """Get path to test data directory."""
    return Path(__file__).parent / "fixtures" / "data"


@pytest.fixture
def temp_dir() -> Generator[Path, None, None]:
    """Create temporary directory for test isolation."""
    with tempfile.TemporaryDirectory() as tmp_dir:
        yield Path(tmp_dir)


@pytest.fixture
def mock_logger():
    """Mock logger for testing logging behavior."""
    return Mock()


@pytest.fixture(autouse=True)
def reset_global_state():
    """Reset global state between tests."""
    # Reset any global singletons or caches
    yield
    # Cleanup after test


# Pytest configuration
def pytest_configure(config):
    """Configure pytest with custom markers."""
    config.addinivalue_line("markers", "unit: mark test as a unit test")
    config.addinivalue_line("markers", "integration: mark test as an integration test")
    config.addinivalue_line("markers", "e2e: mark test as an end-to-end test")
    config.addinivalue_line("markers", "slow: mark test as slow running")
    config.addinivalue_line("markers", "git: mark test as requiring git operations")


def pytest_collection_modifyitems(config, items):
    """Modify test collection to add markers based on location."""
    for item in items:
        # Add markers based on test file location
        if "unit/" in str(item.fspath):
            item.add_marker(pytest.mark.unit)
        elif "integration/" in str(item.fspath):
            item.add_marker(pytest.mark.integration)
        elif "end_to_end/" in str(item.fspath):
            item.add_marker(pytest.mark.e2e)

        # Add git marker for git-related tests
        if any(keyword in str(item.fspath) for keyword in ["git", "repository"]):
            item.add_marker(pytest.mark.git)
