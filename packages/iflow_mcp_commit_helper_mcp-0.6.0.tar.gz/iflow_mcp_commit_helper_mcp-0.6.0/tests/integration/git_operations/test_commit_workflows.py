"""
Integration Tests for Commit Workflows

Tests the complete commit workflow integration between services.
"""

import pytest
from commit_helper_mcp.services.commit_orchestrator import CommitOrchestrator


class TestCommitWorkflows:
    """Test cases for complete commit workflows."""

    @pytest.fixture
    def orchestrator(self, mock_commitizen_service, mock_git_service):
        """Create CommitOrchestrator for testing."""
        return CommitOrchestrator(mock_commitizen_service, mock_git_service)

    def test_preview_commit_workflow(self, orchestrator):
        """Test complete preview workflow."""
        message = "feat: add new feature"

        result = orchestrator.preview_commit_operation(message)

        assert "error" not in result
        assert result["message"] == message
        assert result["is_valid"] is True
        assert "git_preview" in result

    def test_execute_commit_workflow(self, orchestrator):
        """Test complete execution workflow."""
        message = "feat: add new feature"

        result = orchestrator.execute_commit_operation(message, force_execute=True)

        assert result["success"] is True
        assert result["executed"] is True
