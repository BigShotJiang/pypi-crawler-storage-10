"""
End-to-End Tests for Complete Workflows

These tests validate complete workflows from start to finish,
exercising the entire system as a whole.
"""

import pytest
from pathlib import Path
from git import Repo


@pytest.mark.e2e
class TestCompleteWorkflows:
    """Test cases for complete end-to-end workflows."""

    def test_generate_and_commit_workflow(self, temp_dir):
        """Test the complete generate-and-commit workflow."""
        # Setup a test repository
        repo_path = temp_dir
        repo = Repo.init(repo_path)

        # Configure git user for tests
        with repo.config_writer() as config:
            config.set_value("user", "name", "Test User")
            config.set_value("user", "email", "test@example.com")

        # Create and stage a test file
        test_file = Path(repo_path) / "test.py"
        test_file.write_text("print('Hello, World!')\n")
        repo.git.add(str(test_file))

        # Import services directly to avoid MCP overhead in tests
        from commit_helper_mcp.services.commitizen_core import CommitzenCore
        from commit_helper_mcp.services.gitpython_core import GitPythonCore
        from commit_helper_mcp.services.commit_orchestrator import CommitOrchestrator

        # Initialize services
        cz_service = CommitzenCore(repo_path=str(repo_path))
        git_service = GitPythonCore(repo_path=str(repo_path))
        orchestrator = CommitOrchestrator(
            commitizen_core=cz_service, gitpython_core=git_service
        )

        # Generate commit message
        message = cz_service.generate_message(
            {
                "type": "feat",
                "subject": "add test file",
                "body": "This is a test commit for end-to-end testing",
            }
        )

        # Validate message
        assert cz_service.validate_message(message)

        # Preview commit
        preview = orchestrator.preview_commit_operation(
            message=message, repo_path=str(repo_path)
        )

        # Verify preview
        assert "git_preview" in preview
        assert preview["is_valid"] is True
        assert preview["git_enabled"] is True
        assert "staged_files" in preview["git_preview"]
        assert len(preview["git_preview"]["staged_files"]) == 1
        assert "test.py" in preview["git_preview"]["staged_files"][0]

        # Execute commit
        result = orchestrator.execute_commit_operation(
            message=message, repo_path=str(repo_path), force_execute=True
        )

        # Verify commit result
        assert result["success"] is True
        assert result["executed"] is True

        # Verify commit in repository
        commits = list(repo.iter_commits())
        assert len(commits) == 1
        # Check that the commit message contains our message (might have sign-off line)
        assert "feat: add test file" in commits[0].message
        assert "This is a test commit for end-to-end testing" in commits[0].message


@pytest.mark.e2e
class TestMultiRepositoryWorkflows:
    """Test cases for multi-repository workflows."""

    def test_repository_targeting(self, temp_dir):
        """Test operations targeting different repositories."""
        # Setup two test repositories
        repo1_path = Path(temp_dir) / "repo1"
        repo2_path = Path(temp_dir) / "repo2"

        repo1_path.mkdir()
        repo2_path.mkdir()

        repo1 = Repo.init(repo1_path)
        repo2 = Repo.init(repo2_path)

        # Configure git users
        with repo1.config_writer() as config:
            config.set_value("user", "name", "Test User 1")
            config.set_value("user", "email", "test1@example.com")

        with repo2.config_writer() as config:
            config.set_value("user", "name", "Test User 2")
            config.set_value("user", "email", "test2@example.com")

        # Create and stage files in both repositories
        test_file1 = Path(repo1_path) / "test1.py"
        test_file1.write_text("print('Repo 1')\n")
        repo1.git.add(str(test_file1))

        test_file2 = Path(repo2_path) / "test2.py"
        test_file2.write_text("print('Repo 2')\n")
        repo2.git.add(str(test_file2))

        # Import repository manager
        from commit_helper_mcp.services.repository_manager import RepositoryManager

        # Test repository manager with different targets
        manager = RepositoryManager()

        # Verify repo1
        repo1_info = manager.switch_repository(str(repo1_path))
        assert repo1_info["success"] is True
        assert repo1_info["has_git"] is True

        # Get services for repo1
        cz_service1, git_service1 = manager.get_repository_services(str(repo1_path))
        status1 = git_service1.get_repository_status()
        assert "test1.py" in status1["staged_files"][0]

        # Verify repo2
        repo2_info = manager.switch_repository(str(repo2_path))
        assert repo2_info["success"] is True
        assert repo2_info["has_git"] is True

        # Get services for repo2
        cz_service2, git_service2 = manager.get_repository_services(str(repo2_path))
        status2 = git_service2.get_repository_status()
        assert "test2.py" in status2["staged_files"][0]


@pytest.mark.e2e
class TestErrorScenarios:
    """Test cases for error scenarios and recovery."""

    def test_invalid_repository_handling(self, temp_dir):
        """Test handling of invalid repository paths."""
        # Non-existent repository path
        invalid_path = Path(temp_dir) / "non_existent"

        # Import repository manager
        from commit_helper_mcp.services.repository_manager import RepositoryManager

        # Test repository manager with invalid path
        manager = RepositoryManager()

        # Verify error handling
        repo_info = manager.switch_repository(str(invalid_path))
        assert repo_info["success"] is False
        assert "error" in repo_info

    def test_invalid_commit_message_handling(self, temp_git_repo):
        """Test handling of invalid commit messages."""
        # Import services
        from commit_helper_mcp.services.commitizen_core import CommitzenCore

        # Initialize service
        cz_service = CommitzenCore(repo_path=temp_git_repo.working_dir)

        # Test invalid message
        invalid_message = "This is not a conventional commit message"

        # Verify validation fails
        assert cz_service.validate_message(invalid_message) is False
