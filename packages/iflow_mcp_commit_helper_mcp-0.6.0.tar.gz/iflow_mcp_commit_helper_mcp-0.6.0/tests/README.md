# Commit Helper MCP Test Suite

This directory contains the comprehensive test suite for the Commit Helper MCP project.

## Test Structure

The test suite is organized into the following structure:

```
tests/
├── conftest.py                    # Shared fixtures and configuration
├── unit/                          # Unit tests (isolated components)
│   ├── services/                  # Service layer tests
│   ├── server/                    # Server module tests
│   ├── config/                    # Configuration tests
│   └── errors/                    # Error handling tests
├── integration/                   # Integration tests (component interactions)
│   ├── git_operations/            # Git operation integration tests
│   ├── mcp_protocol/              # MCP protocol integration tests
│   └── end_to_end/                # Complete workflow tests
├── fixtures/                      # Shared test fixtures
│   ├── git_repositories.py        # Git repository fixtures
│   ├── commitizen_configs.py      # Commitizen configuration fixtures
│   ├── mock_services.py           # Service mock fixtures
│   └── test_data.py               # Test data fixtures
└── utils/                         # Test utilities
    ├── assertions.py              # Custom test assertions
    ├── helpers.py                 # Test helper functions
    └── mocks.py                   # Mock objects and functions
```

## Test Categories

### Unit Tests

Unit tests focus on testing individual components in isolation. They are fast, deterministic, and do not require external dependencies.

- **Location**: `tests/unit/`
- **Marker**: `@pytest.mark.unit`
- **Run Command**: `make test-unit`

### Integration Tests

Integration tests verify that different components work together correctly. They may require external dependencies like git repositories.

- **Location**: `tests/integration/`
- **Marker**: `@pytest.mark.integration`
- **Run Command**: `make test-integration`

### End-to-End Tests

End-to-end tests validate complete workflows from start to finish. They test the system as a whole.

- **Location**: `tests/integration/end_to_end/`
- **Marker**: `@pytest.mark.e2e`
- **Run Command**: `make test-e2e`

## Running Tests

### Running All Tests

```bash
make test
```

### Running Specific Test Categories

```bash
# Run only unit tests
make test-unit

# Run only integration tests
make test-integration

# Run end-to-end tests
make test-e2e

# Run tests for a specific component
make test tests/unit/services/

# Run with coverage
make test-coverage
```

### Running Tests with Specific Conditions

```bash
# Skip slow tests
make test -m "not slow"

# Run only git-related tests
make test -m git

# Run specific test file with pattern
make test tests/unit/services/test_gitpython_core.py -k security
```

## Test Fixtures

Shared fixtures are available in the `tests/fixtures/` directory:

- **Git Repository Fixtures**: `git_repositories.py`
- **Commitizen Configuration Fixtures**: `commitizen_configs.py`
- **Service Mock Fixtures**: `mock_services.py`
- **Test Data Fixtures**: `test_data.py`

Common fixtures include:

- `temp_git_repo`: Creates a temporary git repository
- `git_repo_with_commits`: Creates a git repository with sample commits
- `git_repo_with_staged_files`: Creates a git repository with staged files
- `mock_commitizen_service`: Mock implementation of the Commitizen service
- `mock_git_service`: Mock implementation of the Git service

## Test Utilities

Test utilities are available in the `tests/utils/` directory:

- **Custom Assertions**: `assertions.py`
- **Helper Functions**: `helpers.py`
- **Mock Objects**: `mocks.py`

These utilities provide consistent testing patterns and reduce duplication.

## Writing New Tests

### Test File Naming

- Unit test files should be named `test_<component>.py`
- Integration test files should be named `test_<feature>_integration.py`
- End-to-end test files should be named `test_<workflow>.py`

### Test Class Structure

```python
class Test<Component>:
    """Test cases for <Component>."""
    
    @pytest.fixture
    def setup_fixture(self):
        """Setup for tests."""
        # Setup code
        yield # or return setup object
        # Teardown code if needed
    
    def test_<functionality>_<scenario>(self, setup_fixture):
        """Test <functionality> when <scenario>."""
        # Arrange
        # Act
        # Assert
```

### Using Markers

```python
@pytest.mark.unit
def test_unit_functionality():
    """Unit test example."""
    pass

@pytest.mark.integration
def test_integration_functionality():
    """Integration test example."""
    pass

@pytest.mark.e2e
def test_end_to_end_workflow():
    """End-to-end test example."""
    pass

@pytest.mark.slow
def test_slow_operation():
    """Slow test example."""
    pass
```

## Test Migration

The test suite migration has been completed. All tests have been successfully migrated from the old structure to the new organized structure. The migration included:

1. **Directory Reorganization**: Tests are now organized into unit, integration, and end-to-end categories
2. **Shared Fixtures**: Common test fixtures have been extracted to reduce duplication
3. **Test Utilities**: Custom assertions and helpers have been created for consistent testing
4. **Documentation**: Comprehensive documentation has been added for all test components
5. **Cleanup**: Old test files have been removed and the cleanup script has been deleted

For historical reference, see `MIGRATION_STATUS.md` for the detailed migration process.

## Best Practices

1. **Test Isolation**: Each test should be independent and not rely on the state from other tests
2. **Clear Naming**: Test names should clearly describe what is being tested
3. **Arrange-Act-Assert**: Follow the AAA pattern for test structure
4. **Use Fixtures**: Leverage fixtures for common setup and teardown
5. **Mock External Dependencies**: Use mocks for external services in unit tests
6. **Test Edge Cases**: Include tests for error conditions and edge cases
7. **Keep Tests Fast**: Unit tests should execute quickly
8. **Maintain Test Coverage**: Aim for high test coverage of critical paths
