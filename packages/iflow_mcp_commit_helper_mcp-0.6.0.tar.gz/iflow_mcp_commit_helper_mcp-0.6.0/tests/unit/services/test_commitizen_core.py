"""
Unit Tests for CommitzenCore Service

Tests the core Commitizen functionality in isolation.
"""

import pytest
from unittest.mock import Mock, patch
from commit_helper_mcp.services.commitizen_core import CommitzenCore


class TestCommitzenCore:
    """Test cases for CommitzenCore service."""

    @pytest.fixture
    def commitizen_core(self, temp_dir):
        """Create CommitzenCore instance for testing."""
        return CommitzenCore(repo_path=str(temp_dir))

    def test_generate_message_success(self, commitizen_core):
        """Test successful message generation."""
        answers = {
            "type": "feat",
            "subject": "add new feature",
            "body": "Detailed description",
        }

        message = commitizen_core.generate_message(answers)

        assert message.startswith("feat:")
        assert "add new feature" in message

    def test_validate_message_valid(self, commitizen_core):
        """Test validation of valid commit message."""
        message = "feat: add new feature"

        is_valid = commitizen_core.validate_message(message)

        assert is_valid is True

    def test_validate_message_invalid(self, commitizen_core):
        """Test validation of invalid commit message."""
        message = "invalid message format"

        is_valid = commitizen_core.validate_message(message)

        assert is_valid is False

    def test_get_commit_types(self, commitizen_core):
        """Test getting available commit types."""
        commit_types = commitizen_core.get_commit_types()

        assert isinstance(commit_types, list)
        assert len(commit_types) > 0
        assert all("name" in ct and "value" in ct for ct in commit_types)
