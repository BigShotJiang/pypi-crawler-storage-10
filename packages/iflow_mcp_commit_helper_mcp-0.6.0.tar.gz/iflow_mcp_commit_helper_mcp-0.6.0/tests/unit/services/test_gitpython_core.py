"""
Unit tests for GitPythonCore service.

Tests the core functionality of the GitPython service implementation.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from pathlib import Path

from commit_helper_mcp.services.gitpython_core import GitPythonCore


class TestGitPythonCore:
    """Test suite for GitPythonCore service."""

    def test_gitpython_import(self):
        """Test that GitPython can be imported."""
        try:
            import git

            assert hasattr(git, "Repo")
            assert hasattr(git, "InvalidGitRepositoryError")
        except ImportError:
            pytest.fail("GitPython not available - should be installed")

    def test_gitpython_availability_flag(self):
        """Test GitPython availability flag."""
        from commit_helper_mcp.services.gitpython_core import GITPYTHON_AVAILABLE

        assert GITPYTHON_AVAILABLE is True, "GitPython should be available"

    @patch("git.Repo")
    def test_gitpython_service_initialization(self, mock_repo_class):
        """Test GitPythonCore service initialization."""
        # Mock successful repository initialization
        mock_repo = MagicMock()
        mock_repo.git_dir = ".git"
        mock_repo_class.return_value = mock_repo

        service = GitPythonCore()
        assert service.repo is not None
        assert service.repo_path is not None

    def test_gitpython_service_import_error_handling(self):
        """Test GitPythonCore service handles import errors gracefully."""
        with patch(
            "commit_helper_mcp.services.gitpython_core.GITPYTHON_AVAILABLE", False
        ):
            with pytest.raises(ImportError, match="GitPython is not available"):
                GitPythonCore()

    def test_git_features_detection(self):
        """Test GitPython features detection."""
        # Test GitPython availability directly
        try:
            import git

            version = git.__version__
            assert version is not None
        except ImportError:
            pytest.fail("GitPython should be available")

    def test_git_service(self):
        """Test GitPythonCore service directly."""
        # Mock GitPython repository
        with patch("git.Repo") as mock_repo_class:
            mock_repo = MagicMock()
            mock_repo.git_dir = ".git"
            mock_repo_class.return_value = mock_repo

            service = GitPythonCore()

            # Should use GitPython implementation
            assert service.repo is not None
            assert service.repo_path is not None

    @patch("git.Repo")
    def test_gitpython_enhanced_features(self, mock_repo_class):
        """Test GitPythonCore enhanced features availability."""
        # Mock GitPython repository
        mock_repo = MagicMock()
        mock_repo.git_dir = ".git"
        mock_repo_class.return_value = mock_repo

        service = GitPythonCore()

        # Should have enhanced features with GitPython
        assert service.repo is not None
        assert hasattr(service, "get_repository_status")
        assert hasattr(service, "preview_commit")
        assert hasattr(service, "execute_commit")


class TestSecurityFunctions:
    """Test security functions in GitPythonCore."""

    def test_sanitize_commit_message_valid(self):
        """Test sanitization of valid commit messages."""
        with patch("git.Repo"):
            service = GitPythonCore()
            message = "feat: add new feature"
            result = service._sanitize_commit_message(message)
            assert result == message

    def test_sanitize_commit_message_dangerous_chars(self):
        """Test removal of dangerous shell characters."""
        with patch("git.Repo"):
            service = GitPythonCore()
            message = "feat: add feature `rm file`"
            result = service._sanitize_commit_message(message)
            assert "`" not in result
            assert "rm file" in result

    def test_sanitize_commit_message_too_long(self):
        """Test length limit enforcement."""
        with patch("git.Repo"):
            service = GitPythonCore()
            message = "x" * 1001
            with pytest.raises(ValueError, match="too long"):
                service._sanitize_commit_message(message)

    def test_sanitize_commit_message_empty(self):
        """Test empty message handling."""
        with patch("git.Repo"):
            service = GitPythonCore()
            with pytest.raises(ValueError, match="cannot be empty"):
                service._sanitize_commit_message("")

    def test_validate_file_path_valid(self):
        """Test validation of valid file paths."""
        with patch("git.Repo"):
            service = GitPythonCore()
            repo_root = Path("/repo")
            service.repo_path = repo_root
            file_path = "src/file.py"
            result = service._validate_file_path(file_path)
            assert result == file_path

    def test_validate_file_path_traversal(self):
        """Test prevention of directory traversal."""
        with patch("git.Repo"):
            service = GitPythonCore()
            repo_root = Path("/repo")
            service.repo_path = repo_root
            file_path = "../outside/file.py"
            with pytest.raises(ValueError, match="outside repository"):
                service._validate_file_path(file_path)


class TestGitServiceOperations:
    """Test GitPythonCore operations with mocked git."""

    @patch("git.Repo")
    def setup_method(self, method, mock_repo):
        """Set up test with mocked git repository."""
        # Mock successful repo initialization
        mock_repo.return_value.git_dir = ".git"
        mock_repo.return_value.index.diff.return_value = []  # No staged files
        mock_repo.return_value.index.entries = {}  # No index entries
        self.service = GitPythonCore()

    def test_preview_commit_no_staged_files(self):
        """Test preview when no files are staged."""
        result = self.service.preview_commit("feat: test message")
        assert result["success"] is False
        assert "No staged changes" in result["error"]

    def test_execute_commit_requires_force(self):
        """Test that execute_commit requires force flag."""
        result = self.service.execute_commit("feat: test message")
        assert result["success"] is False
        assert "force_execute=True required" in result["error"]
        assert result["executed"] is False

    def test_add_files_requires_force(self):
        """Test that add_files requires force flag."""
        result = self.service.add_files("file1.py", "file2.py")
        assert result["success"] is False
        assert "force_execute=True required" in result["error"]
        assert result["executed"] is False
