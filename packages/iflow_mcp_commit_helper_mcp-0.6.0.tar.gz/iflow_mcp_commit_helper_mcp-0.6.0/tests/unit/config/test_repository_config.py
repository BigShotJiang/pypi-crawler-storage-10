"""
Unit tests for repository_config module in the configuration system.

Tests the RepositoryConfig class for detecting and managing git repository configurations.
"""

import pytest
import os
import tempfile
import shutil
from pathlib import Path
from unittest.mock import patch, MagicMock

from commit_helper_mcp.config.repository_config import RepositoryConfig


class TestRepositoryConfig:
    """Test suite for RepositoryConfig class."""

    def setup_method(self):
        """Set up test environment."""
        self.temp_dir = tempfile.mkdtemp()
        self.original_cwd = os.getcwd()

    def teardown_method(self):
        """Clean up test environment."""
        os.chdir(self.original_cwd)
        shutil.rmtree(self.temp_dir)

    def create_git_repo(self, with_config=True):
        """Create a temporary git repository with optional config."""
        repo_dir = Path(self.temp_dir) / "test_repo"
        repo_dir.mkdir(parents=True)

        # Initialize git repository
        os.chdir(repo_dir)
        os.system("git init")
        os.system("git config user.name 'Test User'")
        os.system("git config user.email 'test@example.com'")

        # Create config file if requested
        if with_config:
            config_content = """
            [tool.commitizen]
            name = "cz_conventional_commits"
            version = "0.1.0"
            tag_format = "v$version"
            """
            pyproject_path = repo_dir / "pyproject.toml"
            pyproject_path.write_text(config_content)

        return repo_dir

    def test_repository_config_initialization(self):
        """Test RepositoryConfig initialization with valid repository."""
        repo_dir = self.create_git_repo()

        # Initialize with explicit path
        config = RepositoryConfig(repo_dir)

        # Should detect repository correctly
        assert config.repo_path == repo_dir.resolve()
        assert config.is_valid_repo is True
        assert config.config_file_path is not None
        assert config.config_file_path.name == "pyproject.toml"

    def test_repository_config_current_directory(self):
        """Test RepositoryConfig initialization with current directory."""
        repo_dir = self.create_git_repo()

        # Initialize with current directory
        config = RepositoryConfig(Path.cwd())

        # Should detect repository correctly
        assert config.repo_path == repo_dir.resolve()
        assert config.is_valid_repo is True

    def test_repository_config_invalid_repository(self):
        """Test RepositoryConfig with invalid repository path."""
        invalid_path = Path(self.temp_dir) / "not_a_repo"
        invalid_path.mkdir()

        # Initialize with invalid path
        config = RepositoryConfig(invalid_path)

        # Should handle invalid repository gracefully
        assert config.repo_path == invalid_path.resolve()
        assert config.is_valid_repo is False
        assert config.config_file_path is None

    def test_get_plugin_name_with_config(self):
        """Test get_plugin_name with configuration file."""
        repo_dir = self.create_git_repo()
        config = RepositoryConfig(repo_dir)

        # Should get plugin name from config
        plugin_name = config.get_plugin_name()
        assert plugin_name == "cz_conventional_commits"

    def test_get_plugin_name_without_config(self):
        """Test get_plugin_name without configuration file."""
        repo_dir = self.create_git_repo(with_config=False)
        config = RepositoryConfig(repo_dir)

        # Should fall back to default plugin
        plugin_name = config.get_plugin_name()
        assert plugin_name == "cz_conventional_commits"  # Default plugin

    def test_get_plugin_name_invalid_repo(self):
        """Test get_plugin_name with invalid repository."""
        invalid_path = Path(self.temp_dir) / "not_a_repo"
        invalid_path.mkdir()
        config = RepositoryConfig(invalid_path)

        # Should fall back to default plugin
        plugin_name = config.get_plugin_name()
        assert plugin_name == "cz_conventional_commits"  # Default plugin

    def test_config_file_pyproject_toml(self):
        """Test finding config in pyproject.toml."""
        repo_dir = self.create_git_repo()
        config = RepositoryConfig(repo_dir)

        # Should find pyproject.toml
        assert config.config_file_path is not None
        assert config.config_file_path.name == "pyproject.toml"

    def test_config_file_cz_toml(self):
        """Test finding config in .cz.toml."""
        repo_dir = self.create_git_repo(with_config=False)

        # Create .cz.toml
        cz_config = """
        [commitizen]
        name = "cz_conventional_commits"
        version = "0.1.0"
        """
        cz_path = repo_dir / ".cz.toml"
        cz_path.write_text(cz_config)

        config = RepositoryConfig(repo_dir)

        # Should find .cz.toml
        assert config.config_file_path is not None
        assert config.config_file_path.name == ".cz.toml"

    def test_config_file_no_config(self):
        """Test finding config when no config file exists."""
        repo_dir = self.create_git_repo(with_config=False)
        config = RepositoryConfig(repo_dir)

        # Should return None
        assert config.config_file_path is None

    def test_parse_config_file_pyproject_toml(self):
        """Test parsing config from pyproject.toml."""
        repo_dir = self.create_git_repo()
        config = RepositoryConfig(repo_dir)

        # Get commitizen config
        config_data = config.commitizen_config

        # Should have commitizen config
        assert config_data is not None
        assert "name" in config_data
        assert config_data["name"] == "cz_conventional_commits"
        assert "version" in config_data
        assert "tag_format" in config_data

    def test_parse_config_file_no_config(self):
        """Test parsing config when no config file exists."""
        repo_dir = self.create_git_repo(with_config=False)
        config = RepositoryConfig(repo_dir)

        # Get commitizen config
        config_data = config.commitizen_config

        # Should return empty dict
        assert config_data == {}

    def test_get_config_value(self):
        """Test getting specific config value."""
        repo_dir = self.create_git_repo()
        config = RepositoryConfig(repo_dir)

        # Get specific values
        name = config.get_commitizen_setting("name")
        version = config.get_commitizen_setting("version")
        tag_format = config.get_commitizen_setting("tag_format")

        # Should return correct values
        assert name == "cz_conventional_commits"
        assert version == "0.1.0"
        assert tag_format == "v$version"

        # Non-existent value should return None
        assert config.get_commitizen_setting("nonexistent") is None
