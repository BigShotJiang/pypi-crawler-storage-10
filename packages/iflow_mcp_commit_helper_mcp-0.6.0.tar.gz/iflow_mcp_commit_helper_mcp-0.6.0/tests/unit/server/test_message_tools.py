"""
Unit tests for message tools in the MCP server.

Tests the message generation and validation tools provided by the MCP server.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock

from commit_helper_mcp.server.message_tools import (
    generate_commit_message,
    create_commit_message,
    validate_commit_message,
    get_commit_types,
)


class TestMessageTools:
    """Test suite for message tools in the MCP server."""

    @patch("commit_helper_mcp.server.message_tools.service")
    def test_generate_commit_message(self, mock_service):
        """Test generate_commit_message tool."""
        # Setup mock
        mock_service.generate_message.return_value = (
            "feat(scope): subject\n\nbody\n\nBREAKING CHANGE: details\n\nfooter"
        )
        mock_service.validate_message.return_value = True

        # Call the tool
        result = generate_commit_message(
            type="feat",
            subject="subject",
            body="body",
            scope="scope",
            breaking=True,
            footer="footer",
        )

        # Verify result
        assert "message" in result
        assert "is_valid" in result
        assert "parameters" in result
        assert result["is_valid"] is True
        assert "feat(scope): subject" in result["message"]
        assert "body" in result["message"]
        assert "BREAKING CHANGE" in result["message"]
        assert "footer" in result["message"]

        # Verify service was called correctly
        mock_service.generate_message.assert_called_once()
        args = mock_service.generate_message.call_args[0][0]
        assert args["prefix"] == "feat"
        assert args["subject"] == "subject"
        assert args["body"] == "body"
        assert args["scope"] == "scope"
        assert args["breaking"] is True
        assert args["is_breaking_change"] is True
        assert args["footer"] == "footer"

    @patch("commit_helper_mcp.server.message_tools.service")
    def test_create_commit_message(self, mock_service):
        """Test create_commit_message tool."""
        # Setup mock
        mock_service.generate_message.return_value = "feat: subject"
        mock_service.validate_message.return_value = True

        # Call the tool
        answers_dict = {
            "type": "feat",
            "prefix": "feat",
            "subject": "subject",
            "body": "",
            "scope": "",
            "breaking": False,
            "is_breaking_change": False,
            "footer": "",
        }
        result = create_commit_message(answers_dict)

        # Verify result
        assert "message" in result
        assert "is_valid" in result
        assert result["success"] is True
        assert result["message"] == "feat: subject"

        # Verify service was called correctly
        mock_service.generate_message.assert_called_once_with(answers_dict)

    @patch("commit_helper_mcp.server.message_tools.service")
    def test_validate_commit_message(self, mock_service):
        """Test validate_commit_message tool."""
        # Setup mock
        mock_service.validate_message.return_value = True
        mock_service.get_info.return_value = {"pattern": ".*", "plugin_name": "test"}

        # Call the tool
        message = "feat: test message"
        result = validate_commit_message(message)

        # Verify result
        assert "is_valid" in result
        assert "message" in result
        assert result["success"] is True
        assert result["is_valid"] is True
        assert result["message"] == message

        # Verify service was called correctly
        mock_service.validate_message.assert_called_once_with(message)

    @patch("commit_helper_mcp.server.message_tools.service")
    def test_get_commit_types(self, mock_service):
        """Test get_commit_types tool."""
        # Setup mock
        mock_service.get_commit_types.return_value = [
            {"name": "feat", "description": "A new feature"},
            {"name": "fix", "description": "A bug fix"},
        ]
        mock_service.get_info.return_value = {"plugin_name": "test"}

        # Call the tool
        result = get_commit_types()

        # Verify result
        assert "commit_types" in result
        assert "count" in result
        assert result["success"] is True
        assert result["count"] == 2
        assert len(result["commit_types"]) == 2
        assert result["commit_types"][0]["name"] == "feat"
        assert result["commit_types"][1]["name"] == "fix"

        # Verify service was called correctly
        mock_service.get_commit_types.assert_called_once()


class TestMessageToolsErrorHandling:
    """Test error handling in message tools."""

    @patch("commit_helper_mcp.server.message_tools.service")
    def test_generate_commit_message_validation_failure(self, mock_service):
        """Test generate_commit_message when validation fails."""
        # Setup mock
        mock_service.generate_message.return_value = "invalid message"
        mock_service.validate_message.return_value = False

        # Call the tool - this should raise a ValidationError which is caught by handle_errors
        result = generate_commit_message(type="invalid", subject="")

        # Verify result
        assert "error" in result
        assert "success" in result
        assert result["success"] is False
        assert "error_type" in result
        assert result["error_type"] == "ValidationError"

    @patch("commit_helper_mcp.server.message_tools.service")
    def test_validate_commit_message_invalid(self, mock_service):
        """Test validate_commit_message with invalid message."""
        # Setup mock
        mock_service.validate_message.return_value = False
        mock_service.get_info.return_value = {"pattern": ".*", "plugin_name": "test"}

        # Call the tool
        message = "invalid message"
        result = validate_commit_message(message)

        # Verify result
        assert "is_valid" in result
        assert "message" in result
        assert "success" in result
        assert result["success"] is False
        assert result["is_valid"] is False
        assert result["message"] == message
        assert "error" in result

    @patch("commit_helper_mcp.server.message_tools.service")
    def test_create_commit_message_missing_fields(self, mock_service):
        """Test create_commit_message with missing fields."""
        # Setup mock
        mock_service.generate_message.return_value = "feat: subject"
        mock_service.validate_message.return_value = True

        # Call the tool with incomplete answers
        answers_dict = {"prefix": "feat"}  # Missing type and subject
        result = create_commit_message(answers_dict)

        # Verify result
        assert "error" in result
        assert "success" in result
        assert result["success"] is False
        assert "error_type" in result
        assert result["error_type"] == "ValidationError"
