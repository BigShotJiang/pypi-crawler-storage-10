"""
Error Response Formatting

Provides standardized response formatting for errors and success cases
with consistent structure and helpful information.
"""

from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
from .exceptions import CommitHelperMCPError


@dataclass
class ErrorResponse:
    """Standardized error response structure."""

    success: bool = field(default=False)
    error: str = field(default="")
    error_type: str = field(default="")
    details: Dict[str, Any] = field(default_factory=dict)
    suggestions: List[str] = field(default_factory=list)
    recovery_actions: List[str] = field(default_factory=list)
    context: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {"success": self.success, "error": self.error}

        if self.error_type:
            result["error_type"] = self.error_type

        if self.details:
            result["details"] = self.details

        if self.suggestions:
            result["suggestions"] = self.suggestions

        if self.recovery_actions:
            result["recovery_actions"] = self.recovery_actions

        if self.context:
            result["context"] = self.context

        return result


def create_error_response(
    error: CommitHelperMCPError,
    include_context: bool = True,
    include_suggestions: bool = True,
) -> Dict[str, Any]:
    """Create standardized error response from exception."""
    response = ErrorResponse(
        success=False,
        error=error.get_user_message(),
        error_type=error.__class__.__name__,
    )

    if include_context and error.context:
        response.context = {
            "operation": error.context.operation,
            "component": error.context.component,
        }

        if error.context.details:
            response.details = error.context.details

    if include_suggestions:
        response.suggestions = error.get_suggestions()
        response.recovery_actions = error.get_recovery_actions()

    return response.to_dict()


def create_success_response(
    data: Dict[str, Any], message: Optional[str] = None
) -> Dict[str, Any]:
    """Create standardized success response."""
    response = {"success": True, **data}

    if message:
        response["message"] = message

    return response


def format_validation_error(
    message: str,
    invalid_value: Optional[str] = None,
    expected_format: Optional[str] = None,
    validation_rules: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Format validation error with helpful information."""
    from .exceptions import ValidationError

    error = ValidationError(
        message=message,
        validation_type="format_validation",
        invalid_value=invalid_value,
        expected_format=expected_format,
    )

    if validation_rules:
        error.context.suggestions.extend(validation_rules)

    return create_error_response(error)


def format_git_error(
    message: str,
    git_command: Optional[str] = None,
    repo_path: Optional[str] = None,
    exit_code: Optional[int] = None,
) -> Dict[str, Any]:
    """Format git operation error with command context."""
    from .exceptions import GitOperationError

    error = GitOperationError(
        message=message, git_command=git_command, repo_path=repo_path
    )

    if exit_code is not None:
        error.context.details["exit_code"] = exit_code

    return create_error_response(error)


def format_service_error(
    message: str, service_name: str, operation: Optional[str] = None
) -> Dict[str, Any]:
    """Format service error with service context."""
    from .exceptions import ServiceError

    error = ServiceError(message=message, service_name=service_name)

    if operation:
        error.context.operation = operation

    return create_error_response(error)


def add_troubleshooting_info(
    response: Dict[str, Any], troubleshooting_steps: List[str]
) -> Dict[str, Any]:
    """Add troubleshooting information to error response."""
    response = response.copy()

    if "suggestions" not in response:
        response["suggestions"] = []

    response["suggestions"].extend(troubleshooting_steps)

    return response


def add_documentation_links(
    response: Dict[str, Any], doc_links: Dict[str, str]
) -> Dict[str, Any]:
    """Add documentation links to error response."""
    response = response.copy()

    if "context" not in response:
        response["context"] = {}

    response["context"]["documentation"] = doc_links

    return response
