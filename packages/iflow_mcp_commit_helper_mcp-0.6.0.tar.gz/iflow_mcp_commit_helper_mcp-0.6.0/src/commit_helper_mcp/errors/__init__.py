"""
Error Handling for Commit Helper MCP

This package provides standardized error handling with custom exceptions,
consistent response formats, and comprehensive error recovery mechanisms.
"""

from .exceptions import (
    CommitHelperMCPError,
    GitOperationError,
    ValidationError,
    ConfigurationError,
    RepositoryError,
    PluginError,
    ServiceError,
    create_git_error,
    create_validation_error,
    create_config_error,
)

from .handlers import (
    handle_errors,
    handle_git_errors,
    handle_validation_errors,
    handle_configuration_errors,
    log_error_context,
    ErrorHandler,
    create_error_recovery_response,
)

from .responses import (
    ErrorResponse,
    create_error_response,
    create_success_response,
    format_validation_error,
    format_git_error,
    format_service_error,
    add_troubleshooting_info,
    add_documentation_links,
)

__all__ = [
    # Exceptions
    "CommitHelperMCPError",
    "GitOperationError",
    "ValidationError",
    "ConfigurationError",
    "RepositoryError",
    "PluginError",
    "ServiceError",
    "create_git_error",
    "create_validation_error",
    "create_config_error",
    # Handlers
    "handle_errors",
    "handle_git_errors",
    "handle_validation_errors",
    "handle_configuration_errors",
    "log_error_context",
    "ErrorHandler",
    "create_error_recovery_response",
    # Responses
    "ErrorResponse",
    "create_error_response",
    "create_success_response",
    "format_validation_error",
    "format_git_error",
    "format_service_error",
    "add_troubleshooting_info",
    "add_documentation_links",
]
