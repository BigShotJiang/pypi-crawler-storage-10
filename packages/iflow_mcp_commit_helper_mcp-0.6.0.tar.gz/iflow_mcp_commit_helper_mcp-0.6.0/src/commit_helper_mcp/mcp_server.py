"""
Commitizen MCP Server

FastMCP server that exposes Commitizen functionality through MCP tools and resources.
This is now a modular server that imports tools and resources from focused modules.
"""

import logging
import asyncio

# Import all tools and resources from modules
from .server.base_server import mcp
from .server import message_tools
from .server import git_tools
from .server import workflow_tools
from .server import enhanced_tools
from .server import resources

from .errors import handle_errors, ServiceError

# Configure logging
logger = logging.getLogger(__name__)

# Export all tool functions for backward compatibility with tests
# Message tools
from .server.message_tools import (
    generate_commit_message,
    create_commit_message,
    validate_commit_message,
    get_commit_types,
)

# Git tools
from .server.git_tools import (
    get_git_implementation_info,
    get_enhanced_git_status,
    get_git_status,
    preview_git_commit,
    execute_git_commit,
    generate_and_commit,
    validate_commit_readiness,
    stage_files_and_commit,
)

# Workflow tools
from .server.workflow_tools import (
    get_commit_questions,
    health_check,
    refresh_configuration,
    commit_workflow_step,
)

# Enhanced tools
from .server.enhanced_tools import (
    analyze_repository_health,
    get_detailed_diff_analysis,
    get_branch_analysis,
    smart_commit_suggestion,
    batch_commit_analysis,
)

# Resources
from .server.resources import (
    get_config_resource,
    get_schema_resource,
    get_example_resource,
)

# Export the server and all tools for backward compatibility
__all__ = [
    "mcp",
    # Message tools
    "generate_commit_message",
    "create_commit_message",
    "validate_commit_message",
    "get_commit_types",
    # Git tools
    "get_git_implementation_info",
    "get_enhanced_git_status",
    "get_git_status",
    "preview_git_commit",
    "execute_git_commit",
    "generate_and_commit",
    "validate_commit_readiness",
    "stage_files_and_commit",
    # Workflow tools
    "get_commit_questions",
    "health_check",
    "refresh_configuration",
    "commit_workflow_step",
    # Enhanced tools
    "analyze_repository_health",
    "get_detailed_diff_analysis",
    "get_branch_analysis",
    "smart_commit_suggestion",
    "batch_commit_analysis",
    # Resources
    "get_config_resource",
    "get_schema_resource",
    "get_example_resource",
]

if __name__ == "__main__":
    # This allows the server to be run directly for testing
    @handle_errors(log_errors=True)
    async def main():
        logger.info("Starting Commitizen MCP Server...")
        logger.info("Server initialized successfully")

        # List available tools and resources
        try:
            tools = getattr(mcp, "_tools", {})
            resources_dict = getattr(mcp, "_resources", {})

            logger.info(
                f"Server has {len(tools)} tools and {len(resources_dict)} resources"
            )

            if tools:
                logger.info("Available tools:")
                for tool_name in tools.keys():
                    logger.info(f"  - {tool_name}")

            if resources_dict:
                logger.info("Available resources:")
                for resource_pattern in resources_dict.keys():
                    logger.info(f"  - {resource_pattern}")
        except Exception as e:
            logger.error(f"Could not list tools/resources: {e}")
            raise ServiceError(
                "Failed to list tools and resources", service_name="MCP Server", cause=e
            )

    asyncio.run(main())
