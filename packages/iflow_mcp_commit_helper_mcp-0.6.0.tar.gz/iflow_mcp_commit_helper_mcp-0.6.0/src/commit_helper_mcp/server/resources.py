"""
Resources

MCP resources for configuration and schema access.
"""

import logging
import json
from .base_server import mcp, service
from ..errors import handle_errors, ConfigurationError, ServiceError

logger = logging.getLogger(__name__)


@mcp.resource("commitizen://config")
@handle_errors(log_errors=True)
def get_config_resource() -> str:
    """
    Get current Commitizen configuration as a resource.

    Returns:
        String representation of the current configuration
    """
    try:
        info = service.get_info()
        config_data = {
            "plugin": info.get("plugin_name"),
            "config": info.get("config", {}),
            "capabilities": info.get("capabilities", {}),
            "pattern": info.get("pattern"),
        }

        return json.dumps(config_data, indent=2)

    except Exception as e:
        logger.error(f"Failed to get config resource: {e}")
        raise ConfigurationError(
            "Failed to get configuration resource",
            config_key="commitizen://config",
            cause=e,
        )


@mcp.resource("commitizen://schema")
@handle_errors(log_errors=True)
def get_schema_resource() -> str:
    """
    Get commit message schema as a resource.

    Returns:
        String representation of the commit message schema
    """
    try:
        schema = service.get_schema()

        return json.dumps(schema, indent=2)

    except Exception as e:
        logger.error(f"Failed to get schema resource: {e}")
        raise ConfigurationError(
            "Failed to get schema resource", config_key="commitizen://schema", cause=e
        )


@mcp.resource("commitizen://example")
@handle_errors(log_errors=True)
def get_example_resource() -> str:
    """
    Get example commit message as a resource.

    Returns:
        String containing an example commit message
    """
    try:
        example = service.get_example()

        # Format as a nice text resource
        info = service.get_info()
        plugin_name = info.get("plugin_name", "Unknown")

        return f"""Example Commit Message ({plugin_name} plugin):

{example}

This example demonstrates the expected format for commit messages
using the current Commitizen plugin configuration.
"""

    except Exception as e:
        logger.error(f"Failed to get example resource: {e}")
        raise ServiceError(
            "Failed to get example resource",
            service_name="get_example_resource",
            cause=e,
        )
