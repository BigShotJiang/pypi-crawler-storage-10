"""
Base MCP Server Setup

Common utilities and FastMCP initialization for the Commit Helper MCP Connector.
"""

import logging
from mcp.server.fastmcp import FastMCP
from ..service_facade import CommitzenService
from ..errors import handle_errors, ServiceError

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastMCP server
mcp = FastMCP("Commitizen MCP Connector")


# Initialize global service instance with environment variable support
@handle_errors(log_errors=True)
def initialize_service():
    """Initialize the CommitzenService with error handling."""
    try:
        service_instance = (
            CommitzenService()
        )  # Will check COMMITIZEN_REPO_PATH automatically
        logger.info("CommitzenService initialized successfully")
        return service_instance
    except Exception as e:
        logger.error(f"Failed to initialize CommitzenService: {e}")
        raise ServiceError(
            "Failed to initialize CommitzenService",
            service_name="CommitzenService",
            cause=e,
        )


# Initialize service
service = initialize_service()
