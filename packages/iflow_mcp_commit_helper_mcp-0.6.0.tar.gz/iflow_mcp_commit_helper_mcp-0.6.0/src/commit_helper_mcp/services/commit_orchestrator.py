"""
Orchestrates complex workflows between Commitizen and Git operations.

This service coordinates between CommitzenCore and GitPythonCore to handle
complex workflows that require both services.
"""

import logging
from typing import Dict, Any, Optional, List

from .commitizen_core import CommitzenCore
from .gitpython_core import GitPythonCore

from ..errors import (
    handle_errors,
    handle_git_errors,
    GitOperationError,
    ValidationError,
    RepositoryError,
    ServiceError,
    create_error_response,
    create_success_response,
)

logger = logging.getLogger(__name__)


class CommitOrchestrator:
    """Orchestrates complex workflows between Commitizen and Git operations."""

    def __init__(
        self, commitizen_core: CommitzenCore, gitpython_core: Optional[GitPythonCore]
    ):
        """
        Initialize orchestrator with core services.

        Args:
            commitizen_core: CommitzenCore instance for message operations
            gitpython_core: Optional GitPythonCore instance for git operations
        """
        self.commitizen = commitizen_core
        self.git = gitpython_core
        self.git_enabled = gitpython_core is not None

        logger.info(
            f"Initialized CommitOrchestrator with git_enabled={self.git_enabled}"
        )

    @handle_errors(log_errors=True)
    def preview_commit_operation(
        self, message: str, sign_off: bool = True, **kwargs
    ) -> Dict[str, Any]:
        """
        Orchestrate commit preview with message validation and git preview.

        Combines Commitizen message validation with git preview.

        Args:
            message: Commit message to preview
            sign_off: Whether to add sign-off to commit (default: True)
            **kwargs: Additional commit options

        Returns:
            Dict containing preview results and validation status
        """
        if not self.git_enabled:
            raise RepositoryError(
                "Git operations not available - not in a git repository", repo_path=None
            )

        # Validate message using Commitizen
        try:
            is_valid = self.commitizen.validate_message(message)
            if not is_valid:
                raise ValidationError(
                    "Invalid commit message format",
                    validation_type="commit_message",
                    invalid_value=message,
                )
        except Exception as e:
            if not isinstance(e, ValidationError):
                raise ValidationError(
                    f"Message validation failed: {str(e)}",
                    validation_type="commit_message",
                    invalid_value=message,
                    cause=e,
                )
            raise

        # Get git preview
        git_preview = self.git.preview_commit(message, sign_off=sign_off, **kwargs)

        return create_success_response(
            {
                "message": message,
                "is_valid": is_valid,
                "git_preview": git_preview,
                "git_enabled": True,
            }
        )

    @handle_git_errors
    @handle_errors(log_errors=True)
    def execute_commit_operation(
        self, message: str, force_execute: bool = False, sign_off: bool = True, **kwargs
    ) -> Dict[str, Any]:
        """
        Orchestrate commit execution with full validation pipeline.

        Combines message validation, safety checks, and execution.

        Args:
            message: Commit message
            force_execute: Must be True for actual execution
            sign_off: Whether to add sign-off to commit (default: True)
            **kwargs: Additional commit options

        Returns:
            Dict containing execution results
        """
        if not self.git_enabled:
            raise RepositoryError(
                "Git operations not available - not in a git repository", repo_path=None
            )

        # Validate message format first
        is_valid = self.commitizen.validate_message(message)
        if not is_valid:
            raise ValidationError(
                "Invalid commit message format",
                validation_type="commit_message",
                invalid_value=message,
                expected_format="type(scope): subject",
            )

        # Execute commit with safety checks
        result = self.git.execute_commit(
            message=message, force_execute=force_execute, sign_off=sign_off, **kwargs
        )

        # Add validation info to result
        result["is_valid"] = is_valid
        result["git_enabled"] = True

        return result

    @handle_errors(log_errors=True)
    def validate_commit_readiness(
        self, repo_path: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Comprehensive validation combining git status and message requirements.

        Args:
            repo_path: Optional repository path (uses current if not provided)

        Returns:
            Dict containing readiness status and recommendations
        """
        if not self.git_enabled:
            return create_success_response(
                {
                    "ready_to_commit": False,
                    "checks": {
                        "git_repository": False,
                        "has_staged_files": False,
                        "has_commitizen_config": True,
                    },
                    "recommendations": ["Not in a git repository"],
                    "git_enabled": False,
                }
            )

        # Get repository status
        try:
            status = self.git.get_repository_status()
        except Exception as e:
            raise RepositoryError(
                f"Failed to get repository status: {str(e)}",
                repo_path=repo_path,
                cause=e,
            )

        # Get Commitizen info
        try:
            commitizen_info = self.commitizen.get_info()
        except Exception as e:
            raise ServiceError(
                f"Failed to get Commitizen information: {str(e)}",
                service_name="commitizen_core",
                cause=e,
            )

        # Perform checks
        checks = {
            "git_repository": status.get("is_git_repository", False),
            "has_staged_files": len(status.get("staged_files", [])) > 0,
            "has_commitizen_config": commitizen_info.get("config", {}).get("name")
            != "unknown",
            "has_unstaged_files": len(status.get("unstaged_files", [])) > 0,
            "has_untracked_files": len(status.get("untracked_files", [])) > 0,
        }

        # Build recommendations
        recommendations = []
        if not checks["has_staged_files"]:
            recommendations.append("Stage files before committing (git add <files>)")
        if checks["has_unstaged_files"]:
            recommendations.append(
                f"You have {len(status['unstaged_files'])} unstaged files"
            )
        if checks["has_untracked_files"]:
            recommendations.append(
                f"You have {len(status['untracked_files'])} untracked files"
            )

        ready_to_commit = (
            checks["git_repository"]
            and checks["has_staged_files"]
            and checks["has_commitizen_config"]
        )

        return create_success_response(
            {
                "ready_to_commit": ready_to_commit,
                "checks": checks,
                "recommendations": recommendations,
                "repository_status": status,
                "commitizen_info": commitizen_info,
                "git_enabled": True,
            }
        )

    @handle_errors(log_errors=True)
    def smart_commit_suggestions(
        self,
        repo_path: Optional[str] = None,
        analyze_changes: bool = True,
        suggest_type: bool = True,
        suggest_scope: bool = True,
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Generate intelligent commit suggestions based on repository changes.

        Args:
            repo_path: Optional repository path
            analyze_changes: Whether to analyze file changes
            suggest_type: Whether to suggest commit type
            suggest_scope: Whether to suggest scope

        Returns:
            Dict containing commit suggestions
        """
        if not self.git_enabled:
            raise RepositoryError("Git operations not available", repo_path=repo_path)

        suggestions = {}

        # Get repository status
        try:
            status = self.git.get_repository_status()
            staged_files = status.get("staged_files", [])
        except Exception as e:
            raise RepositoryError(
                f"Failed to get repository status: {str(e)}",
                repo_path=repo_path,
                cause=e,
            )

        if not staged_files:
            raise ValidationError(
                "No staged files to analyze",
                validation_type="staged_files",
                invalid_value="[]",
            )

        # Analyze file patterns for type suggestion
        if suggest_type:
            file_patterns = {
                "feat": ["src/", "lib/", "components/", "features/"],
                "fix": ["fix", "bug", "issue"],
                "docs": ["README", "docs/", ".md", "documentation"],
                "test": ["test", "spec", "__tests__"],
                "style": [".css", ".scss", ".less", "style"],
                "refactor": ["refactor", "cleanup"],
                "chore": ["package.json", "requirements", "Makefile", "config"],
                "ci": [".github/", ".gitlab", "jenkins", "travis", "ci/"],
            }

            type_scores = {}
            for file_path in staged_files:
                for commit_type, patterns in file_patterns.items():
                    if any(pattern in file_path for pattern in patterns):
                        type_scores[commit_type] = type_scores.get(commit_type, 0) + 1

            if type_scores:
                suggested_type = max(type_scores, key=type_scores.get)
                suggestions["type"] = {
                    "value": suggested_type,
                    "confidence": type_scores[suggested_type] / len(staged_files),
                    "reason": f"Based on {type_scores[suggested_type]} matching files",
                }

        # Analyze directory structure for scope suggestion
        if suggest_scope:
            # Extract common directory prefixes
            directories = set()
            for file_path in staged_files:
                parts = file_path.split("/")
                if len(parts) > 1:
                    directories.add(parts[0])

            if len(directories) == 1:
                suggestions["scope"] = {
                    "value": list(directories)[0],
                    "confidence": 1.0,
                    "reason": "All changes in single directory",
                }
            elif len(directories) <= 3:
                suggestions["scope"] = {
                    "value": "/".join(sorted(directories)),
                    "confidence": 0.7,
                    "reason": f"Changes across {len(directories)} directories",
                }

        # Get available commit types from Commitizen
        try:
            commit_types = self.commitizen.get_commit_types()
        except Exception as e:
            raise ServiceError(
                f"Failed to get commit types: {str(e)}",
                service_name="commitizen_core",
                cause=e,
            )

        return create_success_response(
            {
                "suggestions": suggestions,
                "staged_files": staged_files,
                "available_types": commit_types,
                "git_enabled": True,
            }
        )

    @handle_errors(log_errors=True)
    def batch_commit_analysis(
        self,
        repo_path: Optional[str],
        file_groups: List[Dict[str, Any]],
        generate_messages: bool = True,
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Analyze multiple file groups for batch commit operations.

        Args:
            repo_path: Repository path
            file_groups: List of file groups with metadata
            generate_messages: Whether to generate commit messages

        Returns:
            Dict containing batch analysis and suggestions
        """
        if not self.git_enabled:
            raise RepositoryError("Git operations not available", repo_path=repo_path)

        analyzed_groups = []

        for group in file_groups:
            group_analysis = {
                "group_id": group.get("id", "unnamed"),
                "files": group.get("files", []),
                "description": group.get("description", ""),
            }

            # Generate commit message if requested
            if generate_messages and group.get("type") and group.get("subject"):
                try:
                    message = self.commitizen.generate_message(
                        {
                            "type": group["type"],
                            "subject": group["subject"],
                            "scope": group.get("scope"),
                            "body": group.get("body"),
                            "breaking": group.get("breaking", False),
                            "footer": group.get("footer"),
                        }
                    )

                    group_analysis["generated_message"] = message
                    group_analysis["is_valid"] = self.commitizen.validate_message(
                        message
                    )
                except Exception as e:
                    logger.warning(
                        f"Failed to generate message for group {group.get('id')}: {e}"
                    )
                    group_analysis["message_error"] = str(e)

            analyzed_groups.append(group_analysis)

        return create_success_response(
            {
                "groups": analyzed_groups,
                "total_groups": len(file_groups),
                "valid_messages": len(
                    [g for g in analyzed_groups if g.get("is_valid", False)]
                ),
                "git_enabled": True,
            }
        )
