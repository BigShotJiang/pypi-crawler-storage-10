"""
GitPython-based Git Service

Alternative implementation using GitPython instead of commitizen.git.
Provides enhanced capabilities while maintaining full compatibility.
"""

import logging
from pathlib import Path
from typing import Dict, Any, List, Optional, Union
from datetime import datetime
import re

from ..errors import (
    handle_errors,
    handle_git_errors,
    GitOperationError,
    RepositoryError,
    ValidationError,
    create_success_response,
)

try:
    from git import Repo, InvalidGitRepositoryError, GitCommandError
    from git.exc import GitError, NoSuchPathError
    from git.objects import Commit
    from git import Actor

    GITPYTHON_AVAILABLE = True
except ImportError:
    GITPYTHON_AVAILABLE = False

    # Fallback classes for type hints when GitPython not available
    class Repo:
        pass

    class InvalidGitRepositoryError(Exception):
        pass

    class GitCommandError(Exception):
        pass

    class GitError(Exception):
        pass

    class Actor:
        pass


logger = logging.getLogger(__name__)


class GitPythonCore:
    """
    Pure GitPython implementation replacing commitizen.git functionality.

    Key improvements over commitizen.git:
    - No directory changes required (thread-safe)
    - Rich git object access with detailed metadata
    - Better error handling with specific exception types
    - Enhanced repository information and statistics
    - Detailed diff analysis capabilities
    """

    def __init__(self, repo_path: Optional[Union[str, Path]] = None):
        """Initialize GitPython service with repository validation."""
        if not GITPYTHON_AVAILABLE:
            raise ImportError(
                "GitPython is not available. Install with: pip install GitPython>=3.1.40"
            )

        self.repo_path = Path(repo_path) if repo_path else Path.cwd()

        try:
            self.repo = Repo(self.repo_path)
            logger.info(f"GitPython repository initialized: {self.repo_path}")
        except InvalidGitRepositoryError:
            raise RepositoryError(
                f"Not a git repository: {self.repo_path}", repo_path=str(self.repo_path)
            )
        except Exception as e:
            raise GitOperationError(
                f"Failed to initialize repository: {e}",
                repo_path=str(self.repo_path),
                cause=e,
            )

    # Core methods that replace commitizen.git functions
    @handle_errors(log_errors=True)
    def is_git_project(self) -> bool:
        """Replace commitizen.git.is_git_project()"""
        return self.repo is not None and self.repo.git_dir is not None

    @handle_errors(log_errors=True)
    def is_staging_clean(self) -> bool:
        """Replace commitizen.git.is_staging_clean()"""
        try:
            # Check if index differs from HEAD (has staged changes)
            return len(self.repo.index.diff("HEAD")) == 0
        except Exception:
            # If HEAD doesn't exist (new repo), check if index has entries
            try:
                # In a new repository, if index has entries, it's not clean
                return len(self.repo.index.entries) == 0
            except Exception:
                return True  # Assume clean on error

    @handle_errors(log_errors=True)
    def get_staged_files(self) -> List[str]:
        """Enhanced staged files detection using GitPython."""
        try:
            # Try to diff against HEAD first
            return [item.a_path for item in self.repo.index.diff("HEAD")]
        except Exception as e:
            logger.warning(f"Could not get staged files: {e}")
            # If HEAD doesn't exist (new repo), check index entries directly
            try:
                # In a new repository, all index entries are staged files
                return [item[0] for item in self.repo.index.entries.keys()]
            except Exception as e2:
                logger.warning(f"Could not get index entries: {e2}")
                return []

    @handle_errors(log_errors=True)
    def get_unstaged_files(self) -> List[str]:
        """Get list of unstaged files (not available in commitizen.git)."""
        try:
            return [item.a_path for item in self.repo.index.diff(None)]
        except Exception as e:
            logger.warning(f"Could not get unstaged files: {e}")
            return []

    @handle_errors(log_errors=True)
    def get_untracked_files(self) -> List[str]:
        """Get list of untracked files (not available in commitizen.git)."""
        try:
            return self.repo.untracked_files
        except Exception as e:
            logger.warning(f"Could not get untracked files: {e}")
            return []

    @handle_git_errors
    @handle_errors(log_errors=True)
    def get_repository_status(self) -> Dict[str, Any]:
        """Enhanced repository status using pure GitPython."""
        staged_files = self.get_staged_files()
        unstaged_files = self.get_unstaged_files()
        untracked_files = self.get_untracked_files()

        # Get current branch info
        try:
            current_branch = self.repo.active_branch.name
            branch_commit = self.repo.active_branch.commit
        except Exception as e:
            logger.debug(f"Could not get active branch: {e}")
            try:
                current_branch = "HEAD (detached)"
                branch_commit = self.repo.head.commit
            except Exception as e2:
                logger.debug(f"Could not get head commit: {e2}")
                # New repository with no commits
                current_branch = "main (no commits)"
                branch_commit = None

        # Get recent commits with rich information
        recent_commits = []
        try:
            for commit in self.repo.iter_commits(max_count=5):
                recent_commits.append(
                    {
                        "sha": commit.hexsha,
                        "short_sha": commit.hexsha[:8],
                        "message": commit.message.strip(),
                        "summary": commit.summary,
                        "author_name": commit.author.name,
                        "author_email": commit.author.email,
                        "committer_name": commit.committer.name,
                        "committer_email": commit.committer.email,
                        "authored_date": commit.authored_datetime.isoformat(),
                        "committed_date": commit.committed_datetime.isoformat(),
                        "parents": [parent.hexsha[:8] for parent in commit.parents],
                        "stats": {
                            "total_insertions": commit.stats.total["insertions"],
                            "total_deletions": commit.stats.total["deletions"],
                            "files_changed": commit.stats.total["files"],
                        },
                    }
                )
        except Exception as e:
            logger.warning(f"Could not get recent commits: {e}")

        # Get repository statistics
        try:
            total_commits = sum(1 for _ in self.repo.iter_commits())
            total_branches = len(list(self.repo.branches))
            total_tags = len(list(self.repo.tags))
        except Exception as e:
            logger.debug(f"Could not get repository statistics: {e}")
            total_commits = total_branches = total_tags = 0

        return {
            "repository_path": str(self.repo_path),
            "is_git_repository": True,
            "staging_clean": len(staged_files) == 0,
            "staged_files": staged_files,
            "staged_files_count": len(staged_files),
            "unstaged_files": unstaged_files,
            "unstaged_files_count": len(unstaged_files),
            "untracked_files": untracked_files,
            "untracked_files_count": len(untracked_files),
            "current_branch": current_branch,
            "head_commit": {
                "sha": branch_commit.hexsha[:8] if branch_commit else None,
                "message": branch_commit.summary if branch_commit else None,
                "author": branch_commit.author.name if branch_commit else None,
                "committed_date": branch_commit.committed_datetime.isoformat()
                if branch_commit
                else None,
            }
            if branch_commit
            else None,
            "recent_commits": recent_commits,
            "repository_stats": {
                "total_commits": total_commits,
                "total_branches": total_branches,
                "total_tags": total_tags,
            },
        }

    @handle_git_errors
    @handle_errors(log_errors=True)
    def preview_commit(
        self, message: str, sign_off: bool = True, **kwargs
    ) -> Dict[str, Any]:
        """Enhanced commit preview using GitPython's diff capabilities."""
        status = self.get_repository_status()

        if status["staging_clean"]:
            raise ValidationError(
                "No staged changes to commit",
                validation_type="staged_files",
                invalid_value="[]",
            )

        # Get detailed diff information
        try:
            staged_diff = self.repo.index.diff("HEAD")
        except Exception as e:
            # Handle case where HEAD doesn't exist (new repo)
            logger.warning(f"Could not get diff against HEAD: {e}")
            staged_diff = []

        changes_detail = []
        total_insertions = 0
        total_deletions = 0

        for item in staged_diff:
            try:
                # Get diff statistics
                diff_text = item.diff.decode("utf-8", errors="ignore")
                insertions = diff_text.count("\n+") - diff_text.count("\n+++")
                deletions = diff_text.count("\n-") - diff_text.count("\n---")

                changes_detail.append(
                    {
                        "file": item.a_path or item.b_path,
                        "change_type": item.change_type,
                        "insertions": max(0, insertions),
                        "deletions": max(0, deletions),
                        "is_binary": item.diff == b"",
                        "old_file": item.a_path,
                        "new_file": item.b_path,
                    }
                )

                total_insertions += max(0, insertions)
                total_deletions += max(0, deletions)

            except Exception as e:
                logger.warning(f"Could not analyze diff for {item.a_path}: {e}")
                changes_detail.append(
                    {
                        "file": item.a_path or item.b_path,
                        "change_type": item.change_type,
                        "insertions": 0,
                        "deletions": 0,
                        "is_binary": True,
                        "error": str(e),
                    }
                )

        return create_success_response(
            {
                "message": message,
                "staged_files": status["staged_files"],
                "staged_files_count": status["staged_files_count"],
                "changes_detail": changes_detail,
                "total_insertions": total_insertions,
                "total_deletions": total_deletions,
                "total_changes": total_insertions + total_deletions,
                "would_execute": True,
                "repository_path": str(self.repo_path),
                "current_branch": status["current_branch"],
                "head_commit": status["head_commit"],
            }
        )

    @handle_git_errors
    @handle_errors(log_errors=True)
    def execute_commit(
        self,
        message: str,
        force_execute: bool = False,
        author_name: Optional[str] = None,
        author_email: Optional[str] = None,
        committer_name: Optional[str] = None,
        committer_email: Optional[str] = None,
        commit_date: Optional[datetime] = None,
        sign_off: bool = True,
        **kwargs,
    ) -> Dict[str, Any]:
        """Replace commitizen.git.commit() with enhanced GitPython implementation."""

        if not force_execute:
            preview = self.preview_commit(message, **kwargs)
            return create_success_response(
                {
                    "success": False,
                    "error": "force_execute=True required for actual commit execution",
                    "message": message,
                    "executed": False,
                    "preview": preview,
                }
            )

        # Sanitize message
        try:
            sanitized_message = self._sanitize_commit_message(message)
        except ValueError as e:
            raise ValidationError(
                str(e), validation_type="commit_message", invalid_value=message
            )

        # Add sign-off if requested
        if sign_off:
            # Get git config for sign-off
            try:
                user_name = self.repo.config_reader().get_value("user", "name")
                user_email = self.repo.config_reader().get_value("user", "email")
                sanitized_message += f"\n\nSigned-off-by: {user_name} <{user_email}>"
            except Exception as e:
                logger.warning(
                    f"Could not add sign-off - git user config not found: {e}"
                )

        # Check for staged changes
        if self.is_staging_clean():
            raise ValidationError(
                "No staged changes to commit",
                validation_type="staged_files",
                invalid_value="[]",
            )

        # Prepare commit parameters
        commit_kwargs = {}

        # Set author if provided
        if author_name and author_email:
            commit_kwargs["author"] = Actor(author_name, author_email)

        # Set committer if provided
        if committer_name and committer_email:
            commit_kwargs["committer"] = Actor(committer_name, committer_email)

        # Set commit date if provided
        if commit_date:
            commit_kwargs["commit_date"] = commit_date
            commit_kwargs["author_date"] = commit_date

        try:
            # Execute commit using GitPython
            commit_obj = self.repo.index.commit(sanitized_message, **commit_kwargs)

            # Get commit statistics
            commit_stats = commit_obj.stats.total

            return create_success_response(
                {
                    "success": True,
                    "message": sanitized_message,
                    "original_message": message,
                    "executed": True,
                    "commit_hash": commit_obj.hexsha,
                    "commit_short_hash": commit_obj.hexsha[:8],
                    "author": {
                        "name": commit_obj.author.name,
                        "email": commit_obj.author.email,
                    },
                    "committer": {
                        "name": commit_obj.committer.name,
                        "email": commit_obj.committer.email,
                    },
                    "authored_date": commit_obj.authored_datetime.isoformat(),
                    "committed_date": commit_obj.committed_datetime.isoformat(),
                    "stats": {
                        "files_changed": commit_stats["files"],
                        "insertions": commit_stats["insertions"],
                        "deletions": commit_stats["deletions"],
                    },
                    "parents": [parent.hexsha[:8] for parent in commit_obj.parents],
                    "repository_path": str(self.repo_path),
                }
            )

        except GitError as e:
            raise GitOperationError(
                f"Git commit failed: {e}",
                git_command="commit",
                repo_path=str(self.repo_path),
                cause=e,
            )

    def add_files(self, *files: str, force_execute: bool = False) -> Dict[str, Any]:
        """Replace commitizen.git.add() with GitPython."""
        if not force_execute:
            return {
                "success": False,
                "error": "force_execute=True required for actual file staging",
                "files": list(files),
                "executed": False,
                "preview": self._preview_add_files(*files),
            }

        try:
            # Validate file paths
            validated_files = []
            for file_path in files:
                validated_path = self._validate_file_path(file_path)
                validated_files.append(validated_path)

            # Add files using GitPython
            self.repo.index.add(validated_files)

            # Get updated status
            updated_staged = self.get_staged_files()

            return {
                "success": True,
                "files": validated_files,
                "executed": True,
                "repository_path": str(self.repo_path),
                "updated_staged_files": updated_staged,
                "staged_files_count": len(updated_staged),
            }

        except GitError as e:
            logger.error(f"Git add failed: {e}")
            return {
                "success": False,
                "error": f"Git add failed: {e}",
                "files": list(files),
                "executed": False,
            }
        except Exception as e:
            logger.error(f"Add execution failed: {e}")
            return {
                "success": False,
                "error": f"Add execution failed: {e}",
                "files": list(files),
                "executed": False,
            }

    def get_commits(
        self, max_count: int = 10, since: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Replace commitizen.git.get_commits() with enhanced GitPython implementation."""
        try:
            commits = []

            # Build iterator arguments
            iter_kwargs = {"max_count": max_count}
            if since:
                iter_kwargs["since"] = since

            for commit in self.repo.iter_commits(**iter_kwargs):
                # Get commit statistics
                try:
                    stats = commit.stats.total
                    files_changed = stats["files"]
                    insertions = stats["insertions"]
                    deletions = stats["deletions"]
                except Exception:
                    files_changed = insertions = deletions = 0

                commits.append(
                    {
                        "sha": commit.hexsha,
                        "short_sha": commit.hexsha[:8],
                        "message": commit.message.strip(),
                        "summary": commit.summary,
                        "author_name": commit.author.name,
                        "author_email": commit.author.email,
                        "committer_name": commit.committer.name,
                        "committer_email": commit.committer.email,
                        "authored_date": commit.authored_datetime.isoformat(),
                        "committed_date": commit.committed_datetime.isoformat(),
                        "parents": [parent.hexsha[:8] for parent in commit.parents],
                        "stats": {
                            "files_changed": files_changed,
                            "insertions": insertions,
                            "deletions": deletions,
                        },
                    }
                )
            return commits
        except Exception as e:
            logger.error(f"Failed to get commits: {e}")
            return []

    # Utility methods
    def _validate_file_path(self, file_path: str) -> str:
        """Validate file path is within repository bounds."""
        if not file_path or not file_path.strip():
            raise ValueError("File path cannot be empty")

        try:
            # Resolve path and ensure it's within repository
            full_path = (self.repo_path / file_path).resolve()
            repo_root_resolved = self.repo_path.resolve()

            # Check if path is within repository bounds
            if not str(full_path).startswith(str(repo_root_resolved)):
                raise ValueError(f"File path outside repository: {file_path}")

            return file_path.strip()
        except Exception as e:
            raise ValueError(f"Invalid file path '{file_path}': {e}")

    def _sanitize_commit_message(self, message: str) -> str:
        """Sanitize commit message for security."""
        if not message or not message.strip():
            raise ValueError("Commit message cannot be empty")

        # Remove dangerous shell metacharacters
        dangerous_chars = ["`", "$", ";", "|", "&", ">", "<", "\x00"]
        sanitized = message
        for char in dangerous_chars:
            sanitized = sanitized.replace(char, "")

        # Basic length limit
        if len(sanitized) > 1000:
            raise ValueError("Commit message too long (max 1000 characters)")

        # Remove excessive whitespace
        sanitized = re.sub(r"\s+", " ", sanitized.strip())

        if not sanitized:
            raise ValueError("Commit message becomes empty after sanitization")

        return sanitized

    def _preview_add_files(self, *files: str) -> Dict[str, Any]:
        """Preview file staging operation."""
        try:
            file_info = []
            for file_path in files:
                try:
                    validated_path = self._validate_file_path(file_path)
                    full_path = self.repo_path / validated_path

                    if full_path.exists():
                        file_info.append(
                            {
                                "file": validated_path,
                                "exists": True,
                                "size": full_path.stat().st_size,
                                "is_tracked": validated_path
                                in [item.a_path for item in self.repo.index.diff(None)],
                            }
                        )
                    else:
                        file_info.append(
                            {
                                "file": validated_path,
                                "exists": False,
                                "error": "File does not exist",
                            }
                        )
                except ValueError as e:
                    file_info.append(
                        {"file": file_path, "exists": False, "error": str(e)}
                    )

            return {
                "files": file_info,
                "total_files": len(files),
                "valid_files": len([f for f in file_info if f.get("exists", False)]),
            }
        except Exception as e:
            return {"error": str(e), "files": list(files)}
