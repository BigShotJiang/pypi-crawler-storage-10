"""
Pure Commitizen operations without git dependencies.

This service handles all Commitizen-specific functionality including:
- Plugin management and configuration
- Message generation and validation
- Schema and example retrieval
- Commit type extraction
"""

import logging
from typing import Dict, List, Any, Optional

from commitizen import factory
from commitizen.config import BaseConfig
from commitizen.exceptions import CommitizenException

from ..plugin_adapters import PluginAdapterFactory, PluginAdapter
from ..config import get_settings, RepositoryConfig, PluginConfig
from ..errors import (
    handle_errors,
    ConfigurationError,
    PluginError,
    ValidationError,
    create_success_response,
)


logger = logging.getLogger(__name__)


class CommitzenCore:
    """Pure Commitizen operations without git dependencies."""

    def __init__(self, repo_path: Optional[str] = None):
        """
        Initialize Commitizen configuration and plugin adapter.

        Args:
            repo_path: Optional path to repository for config detection
        """
        try:
            # Load centralized settings
            self.settings = get_settings()

            # Load repository configuration
            repo_path = repo_path or self.settings.default_repo_path or "."
            self.repo_config = RepositoryConfig(repo_path)

            # Initialize Commitizen with detected configuration
            self.config = BaseConfig()
            self.committer = factory.committer_factory(self.config)

            # Initialize plugin configuration
            plugin_name = self.committer.__class__.__name__
            self.plugin_config = PluginConfig(plugin_name)

            # Initialize plugin adapter
            self.adapter = PluginAdapterFactory.create_adapter(plugin_name)

            logger.info(f"Initialized CommitzenCore with plugin: {plugin_name}")
            logger.info(f"Using adapter: {self.adapter.__class__.__name__}")
            logger.info(f"Repository: {self.repo_config.repo_path}")
        except CommitizenException as e:
            logger.error(f"Failed to initialize CommitzenCore: {e}")
            raise ConfigurationError(
                f"CommitzenCore initialization failed: {e}",
                config_file=str(self.repo_config.repo_path)
                if hasattr(self, "repo_config")
                else None,
                cause=e,
            )
        except Exception as e:
            logger.error(f"Failed to initialize CommitzenCore: {e}")
            raise ConfigurationError(
                f"CommitzenCore initialization failed: {e}",
                config_file=str(self.repo_config.repo_path)
                if hasattr(self, "repo_config")
                else None,
                cause=e,
            )

    @handle_errors(log_errors=True)
    def refresh_config(self) -> None:
        """Reload configuration if it changes."""
        try:
            self.config = BaseConfig()
            self.committer = factory.committer_factory(self.config)

            # Refresh plugin adapter
            plugin_name = self.committer.__class__.__name__
            self.adapter = PluginAdapterFactory.create_adapter(plugin_name)

            logger.info("Configuration refreshed successfully")
            logger.info(f"Using adapter: {self.adapter.__class__.__name__}")
        except CommitizenException as e:
            logger.error(f"Failed to refresh configuration: {e}")
            raise ConfigurationError(
                f"Configuration refresh failed: {e}",
                config_file=str(self.repo_config.repo_path),
                cause=e,
            )
        except Exception as e:
            logger.error(f"Failed to refresh configuration: {e}")
            raise ConfigurationError(
                f"Configuration refresh failed: {e}",
                config_file=str(self.repo_config.repo_path),
                cause=e,
            )

    @handle_errors(log_errors=True)
    def get_questions(self) -> List[Dict[str, Any]]:
        """Get interactive questions from current plugin."""
        try:
            if hasattr(self.committer, "questions"):
                questions = self.committer.questions
                # Handle case where questions might be callable
                if callable(questions):
                    questions = questions()
                logger.debug(f"Retrieved {len(questions)} questions from plugin")
                return questions
            else:
                logger.warning("Current plugin does not support questions")
                return []
        except CommitizenException as e:
            logger.error(f"Failed to get questions: {e}")
            raise PluginError(
                f"Failed to retrieve questions: {e}",
                plugin_name=self.committer.__class__.__name__,
                cause=e,
            )
        except Exception as e:
            logger.error(f"Failed to get questions: {e}")
            raise PluginError(
                f"Failed to retrieve questions: {e}",
                plugin_name=self.committer.__class__.__name__,
                cause=e,
            )

    @handle_errors(log_errors=True)
    def generate_message(self, answers: Dict[str, Any]) -> str:
        """Generate commit message from answers dictionary."""
        try:
            if hasattr(self.committer, "message"):
                # Use adapter to map fields to plugin-specific format
                mapped_answers = self.adapter.map_fields(answers)
                logger.debug(f"Mapped answers: {mapped_answers}")

                message = self.committer.message(mapped_answers)
                logger.debug(f"Generated message: {message}")
                return message
            else:
                logger.error("Current plugin does not support message generation")
                raise PluginError(
                    "Plugin does not support message generation",
                    plugin_name=self.committer.__class__.__name__,
                )
        except CommitizenException as e:
            logger.error(f"Failed to generate message: {e}")
            raise ValidationError(
                f"Message generation failed: {e}",
                validation_type="commit_message",
                invalid_value=str(answers),
                cause=e,
            )
        except Exception as e:
            if not isinstance(e, (PluginError, ValidationError)):
                logger.error(f"Failed to generate message: {e}")
                raise ValidationError(
                    f"Message generation failed: {e}",
                    validation_type="commit_message",
                    invalid_value=str(answers),
                    cause=e,
                )
            raise

    @handle_errors(log_errors=True)
    def validate_message(self, message: str) -> bool:
        """Validate commit message format."""
        try:
            # First try plugin validation if available
            if hasattr(self.committer, "pattern"):
                import re

                pattern = self.committer.pattern
                is_valid = bool(re.match(pattern, message))
                logger.debug(f"Plugin validation result: {is_valid}")
                return is_valid
            else:
                # Fall back to adapter validation
                is_valid = self.adapter.validate_message(message)
                logger.debug(f"Adapter validation result: {is_valid}")
                return is_valid
        except CommitizenException as e:
            logger.error(f"Failed to validate message: {e}")
            raise ValidationError(
                f"Message validation failed: {e}",
                validation_type="commit_message",
                invalid_value=message,
                cause=e,
            )
        except Exception as e:
            if not isinstance(e, ValidationError):
                logger.error(f"Failed to validate message: {e}")
                raise ValidationError(
                    f"Message validation failed: {e}",
                    validation_type="commit_message",
                    invalid_value=message,
                    cause=e,
                )
            raise

    @handle_errors(log_errors=True)
    def get_example(self) -> str:
        """Get example commit message."""
        try:
            if hasattr(self.committer, "example"):
                example = self.committer.example
                # Handle case where example might be callable
                if callable(example):
                    example = example()
                # Ensure it's a string
                example_str = (
                    str(example) if example is not None else "No example available"
                )
                logger.debug(f"Retrieved example: {example_str}")
                return example_str
            else:
                logger.warning("Current plugin does not provide example")
                return "No example available for current plugin"
        except CommitizenException as e:
            logger.error(f"Failed to get example: {e}")
            raise PluginError(
                f"Failed to retrieve example: {e}",
                plugin_name=self.committer.__class__.__name__,
                cause=e,
            )
        except Exception as e:
            if not isinstance(e, PluginError):
                logger.error(f"Failed to get example: {e}")
                raise PluginError(
                    f"Failed to retrieve example: {e}",
                    plugin_name=self.committer.__class__.__name__,
                    cause=e,
                )
            raise

    @handle_errors(log_errors=True)
    def get_schema(self) -> Dict[str, Any]:
        """Get commit message schema."""
        try:
            if hasattr(self.committer, "schema"):
                schema = self.committer.schema
                # Handle case where schema might be callable
                if callable(schema):
                    schema = schema()
                # Ensure it's a dict
                if isinstance(schema, dict):
                    logger.debug("Retrieved schema from plugin")
                    return schema
                else:
                    logger.debug("Schema is not a dict, wrapping it")
                    return {"schema": schema}
            elif hasattr(self.committer, "schema_pattern"):
                # Some plugins might use schema_pattern instead
                schema_pattern = self.committer.schema_pattern
                logger.debug("Retrieved schema pattern from plugin")
                return {"pattern": schema_pattern}
            else:
                logger.warning("Current plugin does not provide schema")
                return {"message": "No schema available for current plugin"}
        except CommitizenException as e:
            logger.error(f"Failed to get schema: {e}")
            raise PluginError(
                f"Failed to retrieve schema: {e}",
                plugin_name=self.committer.__class__.__name__,
                cause=e,
            )
        except Exception as e:
            if not isinstance(e, PluginError):
                logger.error(f"Failed to get schema: {e}")
                raise PluginError(
                    f"Failed to retrieve schema: {e}",
                    plugin_name=self.committer.__class__.__name__,
                    cause=e,
                )
            raise

    @handle_errors(log_errors=True)
    def get_info(self) -> Dict[str, Any]:
        """Get comprehensive plugin information."""
        try:
            info = {
                "plugin_name": self.committer.__class__.__name__,
                "plugin_module": self.committer.__class__.__module__,
                "config": {
                    "name": getattr(self.config, "name", "unknown"),
                    "version": getattr(self.config, "version", "unknown"),
                    "tag_format": getattr(self.config, "tag_format", None),
                },
                "capabilities": {
                    "has_questions": hasattr(self.committer, "questions"),
                    "has_message": hasattr(self.committer, "message"),
                    "has_pattern": hasattr(self.committer, "pattern"),
                    "has_example": hasattr(self.committer, "example"),
                    "has_schema": hasattr(self.committer, "schema")
                    or hasattr(self.committer, "schema_pattern"),
                },
            }

            # Add example if available
            if info["capabilities"]["has_example"]:
                try:
                    info["example"] = self.get_example()
                except Exception as e:
                    logger.warning(f"Failed to get example for info: {e}")
                    info["example"] = "Error retrieving example"

            # Add pattern if available
            if info["capabilities"]["has_pattern"]:
                info["pattern"] = getattr(self.committer, "pattern", None)

            logger.debug("Retrieved comprehensive plugin info")
            return info
        except CommitizenException as e:
            logger.error(f"Failed to get info: {e}")
            raise PluginError(
                f"Failed to retrieve plugin info: {e}",
                plugin_name=self.committer.__class__.__name__,
                cause=e,
            )
        except Exception as e:
            if not isinstance(e, PluginError):
                logger.error(f"Failed to get info: {e}")
                raise PluginError(
                    f"Failed to retrieve plugin info: {e}",
                    plugin_name=self.committer.__class__.__name__,
                    cause=e,
                )
            raise

    @handle_errors(log_errors=True)
    def get_commit_types(self) -> List[Dict[str, str]]:
        """Extract available commit types from questions."""
        try:
            questions = self.get_questions()
            commit_types = []

            for question in questions:
                if question.get("name") == "prefix" and "choices" in question:
                    # Handle different choice formats
                    choices = question["choices"]
                    for choice in choices:
                        if isinstance(choice, dict):
                            # Choice is a dict with 'name' and 'value'
                            commit_types.append(
                                {
                                    "name": choice.get(
                                        "name", choice.get("value", str(choice))
                                    ),
                                    "value": choice.get(
                                        "value", choice.get("name", str(choice))
                                    ),
                                }
                            )
                        elif isinstance(choice, str):
                            # Choice is a simple string
                            commit_types.append({"name": choice, "value": choice})
                        else:
                            # Fallback for other formats
                            commit_types.append(
                                {"name": str(choice), "value": str(choice)}
                            )
                    break

            logger.debug(f"Extracted {len(commit_types)} commit types")
            return commit_types
        except CommitizenException as e:
            logger.error(f"Failed to get commit types: {e}")
            raise PluginError(
                f"Failed to extract commit types: {e}",
                plugin_name=self.committer.__class__.__name__,
                cause=e,
            )
        except Exception as e:
            if not isinstance(e, (PluginError, ValidationError)):
                logger.error(f"Failed to get commit types: {e}")
                raise PluginError(
                    f"Failed to extract commit types: {e}",
                    plugin_name=self.committer.__class__.__name__,
                    cause=e,
                )
            raise
