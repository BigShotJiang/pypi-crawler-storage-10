# Task 0: Project Rename to commit-helper-mcp

## Overview

**Priority**: High (Prerequisite)  
**Goal**: Rename project from "commitizen-mcp-connector" to "commit-helper-mcp"  
**Target**: Complete project rename with updated references  
**Status**: ✅ COMPLETE (2025-07-10)
**Commit**: e3f8627

## Current Problem

The project is currently named "commitizen-mcp-connector" but needs to be renamed to "commit-helper-mcp" for better branding and clarity. This involves:
- Directory structure changes
- Import path updates
- Configuration file updates
- Documentation updates
- Test file updates

## Target Structure

```
src/
└── commit_helper_mcp/          # Renamed from commitizen_mcp_connector/
    ├── __init__.py
    ├── commitizen_server.py
    ├── commitizen_service.py
    ├── gitpython_service.py
    └── plugin_adapters.py
```

## Implementation Steps

### Step 1: Rename Source Directory

**Action**: Rename the main source directory
```bash
mv src/commitizen_mcp_connector src/commit_helper_mcp
```

**Files Affected**:
- All Python files in the source directory
- Import statements throughout the codebase

### Step 2: Update Import Statements

**Files to Update**:
- `main.py`: Update import from `commitizen_mcp_connector` to `commit_helper_mcp`
- All test files: Update import statements
- Any configuration files referencing the old name

**Example Changes**:
```python
# Before
from commitizen_mcp_connector.commitizen_server import mcp

# After  
from commit_helper_mcp.commitizen_server import mcp
```

### Step 3: Update Configuration Files

**Files to Update**:
- `pyproject.toml`: Update package name and paths
- `README.md`: Update project name references
- `SETUP.md`: Update installation instructions
- `CHANGELOG.md`: Update project references

**pyproject.toml Changes**:
```toml
[project]
name = "commit-helper-mcp"  # Changed from "commitizen-mcp-connector"

[tool.setuptools.packages.find]
where = ["src"]
include = ["commit_helper_mcp*"]  # Changed from "commitizen_mcp_connector*"
```

### Step 4: Update Test Files

**Files to Update**:
- All files in `tests/` directory
- Update import statements
- Update any hardcoded references to the old name

**Test Directory Structure**:
```
tests/
├── commit_helper_mcp/          # Renamed from commitizen_mcp_connector/
│   ├── test_commitizen_server.py
│   ├── test_commitizen_service.py
│   └── test_plugin_adapters.py
└── [other test files with updated imports]
```

### Step 5: Update Documentation

**Files to Update**:
- `README.md`: Project title and references
- `SETUP.md`: Installation commands and paths
- `QUICK_START.md`: Usage examples
- Any journal documentation referencing the old name

### Step 6: Update MCP Server Configuration

**Files to Update**:
- `main.py`: Server initialization
- Any MCP client configuration examples
- Claude Desktop configuration examples

**Example Configuration Update**:
```json
{
  "mcpServers": {
    "commit-helper-mcp": {
      "command": "uv",
      "args": ["run", "python", "/path/to/main.py"],
      "cwd": "/path/to/commit-helper-mcp"
    }
  }
}
```

### Step 7: Verify All References

**Verification Checklist**:
- [ ] All import statements updated
- [ ] All test files pass
- [ ] Configuration files updated
- [ ] Documentation updated
- [ ] MCP server starts correctly
- [ ] No remaining references to old name

## Implementation Guidelines

### Rename Strategy
1. **Complete Rename**: Change all references in one step to avoid partial state
2. **Test After Each Step**: Ensure functionality works after each major change
3. **Documentation First**: Update documentation to reflect new name
4. **Import Consistency**: Ensure all imports use new package name

### Testing Strategy
1. **Import Testing**: Verify all imports work with new name
2. **Functionality Testing**: Run full test suite after rename
3. **MCP Testing**: Verify MCP server starts and tools work
4. **Integration Testing**: Test with MCP clients

## Validation Criteria

### Success Metrics
- [x] All files successfully renamed
- [x] All import statements updated
- [x] All tests pass with new package name (144 tests passing)
- [x] MCP server starts correctly
- [x] Documentation reflects new name
- [x] No references to old name remain

### File Rename Targets
- [x] `src/commitizen_mcp_connector/` → `src/commit_helper_mcp/`
- [x] `tests/commitizen_mcp_connector/` → `tests/commit_helper_mcp/`
- [x] All import statements updated (16 files)
- [x] All configuration references updated

## Potential Issues and Solutions

### Issue 1: Import Errors
**Problem**: Broken imports after directory rename
**Solution**: Systematic update of all import statements

### Issue 2: Test Failures
**Problem**: Tests fail due to import path changes
**Solution**: Update test imports and run tests incrementally

### Issue 3: Configuration Conflicts
**Problem**: Old configuration references cause errors
**Solution**: Update all configuration files before testing

## Testing Plan

### Unit Tests
- Verify all modules can be imported with new name
- Test that all functionality works after rename
- Check that no old import paths remain

### Integration Tests
- Test MCP server startup with new package name
- Verify all MCP tools work correctly
- Test with actual MCP clients

### Documentation Tests
- Verify all documentation examples work
- Check that installation instructions are correct
- Test configuration examples

## Dependencies

### Prerequisites
- Current codebase is stable and all tests pass
- Understanding of Python package structure
- Familiarity with import system

### Affected Files
- `src/commitizen_mcp_connector/` (entire directory)
- `tests/commitizen_mcp_connector/` (entire directory)
- `main.py` (import statements)
- `pyproject.toml` (package configuration)
- All test files (import statements)
- All documentation files

## Estimated Effort

**Time Estimate**: 15 minutes
**Complexity**: Medium
**Risk Level**: Medium (affects all imports, but straightforward changes)

## Next Steps

After completing this task:
1. Proceed to Task 1: MCP Server Decomposition
2. Verify all refactoring tasks work with new package name
3. Update any external references or documentation
4. Consider updating repository name if applicable

## Completion Summary

**Completed**: 2025-07-10  
**Duration**: ~15 minutes (as estimated)  
**Commit**: e3f8627  

### What Was Done:
1. **Updated pyproject.toml**: Changed package name and discovery paths
2. **Renamed directories**: Source and test directories renamed successfully
3. **Updated imports**: Created and ran script to update all 16 Python files
4. **Updated documentation**: README.md, SETUP.md, QUICK_START.md all updated
5. **Verified tests**: All 144 tests passing after rename
6. **Committed changes**: 27 files changed, 111 insertions, 111 deletions

### Key Achievements:
- Clean rename with no broken imports
- All tests passing without modification
- Documentation fully updated
- Project ready for next refactoring phases

## Notes

This task was completed successfully as a prerequisite before other refactoring tasks. The rename was executed cleanly with automated import updates, ensuring consistency across the entire codebase. The project now uses the more descriptive name "commit-helper-mcp" throughout.
