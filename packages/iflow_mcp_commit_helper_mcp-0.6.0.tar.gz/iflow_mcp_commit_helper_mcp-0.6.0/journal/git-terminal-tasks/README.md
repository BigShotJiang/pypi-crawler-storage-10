# Git Terminal Tasks Documentation

This directory contains comprehensive documentation of common git terminal tasks and specifications for MCP tools to automate and enhance these operations.

## Overview

This documentation was created to address the need for advanced git operations that developers frequently perform in the terminal, starting with the specific use case of removing commits between two tags and expanding to cover a wide range of git workflows.

## Directory Structure

```
git-terminal-tasks/
├── README.md                          # This file - overview and index
├── common-tasks/                      # Documentation of common git operations
│   ├── history-rewriting.md          # Rewriting git history (rebasing, filtering)
│   ├── commit-operations.md          # Creating and managing commits
│   ├── branch-management.md          # Branch operations and workflows
│   ├── tag-operations.md             # Tag management and manipulation
│   └── repository-maintenance.md     # Repository cleanup and optimization
├── tool-specifications/               # MCP tool specifications
│   ├── history-tools.md              # Tools for history manipulation
│   ├── tag-tools.md                  # Tools for tag management
│   ├── diff-tools.md                 # Advanced diff and comparison tools
│   ├── maintenance-tools.md          # Repository maintenance tools
│   └── workflow-tools.md             # Workflow automation tools
└── implementation-plan.md            # Overall implementation strategy
```

## Quick Reference

### Common Tasks

1. **[History Rewriting](common-tasks/history-rewriting.md)**
   - Remove commits between tags
   - Interactive rebase workflows
   - Filter branch operations
   - History cleanup

2. **[Commit Operations](common-tasks/commit-operations.md)**
   - Advanced commit creation
   - Commit message editing
   - Partial commits
   - Commit signing

3. **[Branch Management](common-tasks/branch-management.md)**
   - Branch creation and deletion
   - Branch merging strategies
   - Remote branch operations
   - Branch protection

4. **[Tag Operations](common-tasks/tag-operations.md)**
   - Tag creation and management
   - Tag migration during rebases
   - Annotated vs lightweight tags
   - Tag verification

5. **[Repository Maintenance](common-tasks/repository-maintenance.md)**
   - Repository cleanup (gc, prune)
   - Hook management
   - Configuration management
   - Performance optimization

### Tool Categories

1. **[History Tools](tool-specifications/history-tools.md)**
   - `rewrite_history_between_tags`
   - `interactive_rebase_helper`
   - `history_cleanup_tool`

2. **[Tag Tools](tool-specifications/tag-tools.md)**
   - `tag_analysis_tool`
   - `tag_migration_helper`
   - `tag_validation_tool`

3. **[Diff Tools](tool-specifications/diff-tools.md)**
   - `compare_branches_tool`
   - `conflict_resolution_helper`
   - `patch_generation_tool`

4. **[Maintenance Tools](tool-specifications/maintenance-tools.md)**
   - `repository_cleanup_tool`
   - `hook_management_tool`
   - `config_management_tool`

5. **[Workflow Tools](tool-specifications/workflow-tools.md)**
   - `release_workflow_tool`
   - `feature_branch_helper`
   - `hotfix_automation_tool`

## Key Use Cases

### 1. Removing Commits Between Tags

**Problem**: Need to remove specific commits between two tags while preserving the rest of the history.

**Solution**: Use `rewrite_history_between_tags` tool with safety checks and automatic tag migration.

**Manual Process**:
```bash
git rebase -i tag1^
# Mark commits as 'drop'
git tag -f tag2 <new-commit>
git push --force-with-lease
```

### 2. Complex Branch Merging

**Problem**: Need to merge branches with complex conflict resolution and history preservation.

**Solution**: Use `compare_branches_tool` and `conflict_resolution_helper` for guided merging.

### 3. Repository Optimization

**Problem**: Repository has become slow due to accumulated history and objects.

**Solution**: Use `repository_cleanup_tool` for safe and comprehensive cleanup.

## Safety Principles

All tools follow these safety principles:

1. **Preview First**: All destructive operations show preview before execution
2. **Backup Creation**: Automatic backup before history rewriting
3. **Force Flags**: Explicit confirmation required for dangerous operations
4. **Rollback Support**: Ability to undo operations when possible
5. **Validation**: Comprehensive checks before and after operations

## Integration with Commit Helper MCP

These tools extend the existing Commit Helper MCP functionality:

- **Complementary**: Work alongside existing commit generation tools
- **Consistent Interface**: Follow same MCP tool patterns
- **Safety Mechanisms**: Use same force_execute patterns
- **Repository Targeting**: Support same multi-repository workflows

## Getting Started

1. Review the [common tasks](common-tasks/) to understand git operations
2. Check [tool specifications](tool-specifications/) for available automation
3. See [implementation plan](implementation-plan.md) for development roadmap

## Contributing

When adding new tasks or tools:

1. Document the manual terminal process first
2. Identify safety concerns and edge cases
3. Design tool with preview and force_execute patterns
4. Include comprehensive error handling
5. Add examples and use cases

## Related Documentation

- [Git Commit Implementation Plan](../git/git-commit-implementation-plan.md)
- [GitPython Exploration](../git/gitpython-exploration.md)
- [Commit Helper MCP README](../../README.md)
