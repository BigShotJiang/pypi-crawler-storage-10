# Common Git Terminal Tasks Summary

This document compiles a comprehensive list of common git terminal tasks that developers frequently perform, organized by category. This list was compiled based on the specific request to document terminal operations, starting with the use case of removing commits between tags.

## History Manipulation Tasks

### 1. Remove Commits Between Tags
**Original Request**: "how do I in git remove some commits between two tags and check out the rest"

```bash
# Identify commits between tags
git log --oneline tag1..tag2

# Interactive rebase to remove commits
git rebase -i tag1^
# Mark commits as 'drop' in editor

# Update tag positions
git tag -f tag2 <new-commit-hash>

# Force push if needed
git push --force-with-lease
```

### 2. Reorder Commits
```bash
git rebase -i HEAD~5
# Reorder lines in editor
```

### 3. Squash Multiple Commits
```bash
git rebase -i HEAD~3
# Change 'pick' to 'squash'
```

### 4. Split a Commit
```bash
git rebase -i HEAD~1
# Change 'pick' to 'edit'
git reset HEAD^
git add -p  # Add partially
git commit
git rebase --continue
```

### 5. Remove Large Files from History
```bash
git filter-branch --index-filter 'git rm --cached --ignore-unmatch large-file.bin' HEAD
```

## Commit Operations

### 6. Stage Parts of Files
```bash
git add -p
# Interactive staging
```

### 7. Amend Last Commit
```bash
git commit --amend -m "New message"
```

### 8. Sign Commits
```bash
git commit -S -m "Signed commit"
```

### 9. Create Empty Commit
```bash
git commit --allow-empty -m "Trigger CI"
```

### 10. Commit as Different Author
```bash
git commit --author="Name <email>" -m "Message"
```

## Branch Management

### 11. Create and Switch Branch
```bash
git checkout -b feature-branch
```

### 12. Delete Local and Remote Branch
```bash
git branch -d local-branch
git push origin --delete remote-branch
```

### 13. Rename Branch
```bash
git branch -m old-name new-name
```

### 14. Track Remote Branch
```bash
git checkout -b local-branch origin/remote-branch
```

### 15. Compare Branches
```bash
git diff branch1..branch2
```

## Tag Operations

### 16. Create Annotated Tag
```bash
git tag -a v1.0.0 -m "Release version 1.0.0"
```

### 17. Move Tag to Different Commit
```bash
git tag -f tag-name <commit-hash>
```

### 18. List Tags Matching Pattern
```bash
git tag -l "v1.*"
```

### 19. Push All Tags
```bash
git push --tags
```

### 20. Delete Local and Remote Tag
```bash
git tag -d tag-name
git push origin :refs/tags/tag-name
```

## Repository Maintenance

### 21. Clean Untracked Files
```bash
git clean -fd
```

### 22. Garbage Collection
```bash
git gc --aggressive --prune=now
```

### 23. Verify Repository Integrity
```bash
git fsck --full
```

### 24. Prune Remote Tracking Branches
```bash
git remote prune origin
```

### 25. Optimize Repository
```bash
git repack -a -d --depth=250 --window=250
```

## Stash Operations

### 26. Stash with Message
```bash
git stash push -m "Work in progress"
```

### 27. Apply Specific Stash
```bash
git stash apply stash@{2}
```

### 28. Create Branch from Stash
```bash
git stash branch new-branch stash@{0}
```

## Advanced Diff Operations

### 29. Show Word-Level Diff
```bash
git diff --word-diff
```

### 30. Compare File Across Branches
```bash
git diff branch1:file.txt branch2:file.txt
```

### 31. Generate Patch
```bash
git format-patch -3 HEAD
```

## Remote Operations

### 32. Add Multiple Remotes
```bash
git remote add upstream https://github.com/original/repo.git
```

### 33. Fetch All Remotes
```bash
git fetch --all
```

### 34. Change Remote URL
```bash
git remote set-url origin new-url
```

## Merge and Rebase

### 35. Merge with No Fast-Forward
```bash
git merge --no-ff feature-branch
```

### 36. Rebase onto Different Base
```bash
git rebase --onto new-base old-base branch
```

### 37. Continue After Conflict
```bash
git rebase --continue
```

## Log and History

### 38. Show Commits by Author
```bash
git log --author="Name"
```

### 39. Show File History
```bash
git log --follow file.txt
```

### 40. Find Commit by Message
```bash
git log --grep="pattern"
```

## Cherry-Pick Operations

### 41. Cherry-Pick Range
```bash
git cherry-pick commit1..commit2
```

### 42. Cherry-Pick with Edit
```bash
git cherry-pick -e <commit>
```

## Bisect Operations

### 43. Find Bad Commit
```bash
git bisect start
git bisect bad HEAD
git bisect good v1.0
# Test and mark commits
git bisect reset
```

## Submodule Operations

### 44. Add Submodule
```bash
git submodule add https://github.com/user/repo.git path/to/submodule
```

### 45. Update All Submodules
```bash
git submodule update --init --recursive
```

## Configuration

### 46. Set Global Aliases
```bash
git config --global alias.co checkout
git config --global alias.br branch
```

### 47. Configure Line Endings
```bash
git config --global core.autocrlf true
```

### 48. Set Default Branch
```bash
git config --global init.defaultBranch main
```

## Recovery Operations

### 49. Recover Deleted Branch
```bash
git reflog
git checkout -b recovered-branch <commit-hash>
```

### 50. Undo Last Push
```bash
git push --force-with-lease origin HEAD^:branch-name
```

## MCP Tool Mapping

For each of these common tasks, the following MCP tools have been proposed:

1. **History Manipulation**: `rewrite_history_between_tags`, `interactive_rebase_helper`
2. **Commit Operations**: `partial_commit_helper`, `commit_amend_helper`
3. **Branch Management**: `compare_branches_tool`, `branch_workflow_helper`
4. **Tag Operations**: `tag_analysis_tool`, `tag_migration_helper`
5. **Repository Maintenance**: `repository_cleanup_tool`, `optimization_helper`
6. **Advanced Operations**: `conflict_resolution_helper`, `patch_generation_tool`

## Key Insights

Based on this compilation of common tasks:

1. **Safety is Paramount**: Many operations can be destructive (force push, history rewriting)
2. **Preview is Essential**: Users need to see what will happen before execution
3. **Automation Opportunity**: Repetitive multi-step operations are prime candidates for tools
4. **Error Recovery**: Every operation should have a clear recovery path
5. **Context Awareness**: Tools should understand repository state and provide guidance

This list forms the foundation for the comprehensive MCP tool suite designed to automate and enhance these common git operations while maintaining safety and user control.
