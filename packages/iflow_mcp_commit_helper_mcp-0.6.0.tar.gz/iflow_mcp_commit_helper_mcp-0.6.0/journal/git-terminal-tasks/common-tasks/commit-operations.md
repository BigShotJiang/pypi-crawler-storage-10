# Commit Operations in Git

This document covers advanced commit operations beyond basic `git commit`, including partial commits, commit amendments, and commit signing.

## Table of Contents

1. [Partial Commits](#partial-commits)
2. [Amending Commits](#amending-commits)
3. [Commit Signing](#commit-signing)
4. [Advanced Commit Creation](#advanced-commit-creation)
5. [Commit Templates](#commit-templates)

## Partial Commits

### Interactive Staging (Patch Mode)

```bash
# Stage parts of files interactively
git add -p

# Options during interactive staging:
# y - stage this hunk
# n - do not stage this hunk
# q - quit; do not stage this hunk or remaining ones
# a - stage this hunk and all later hunks in the file
# d - do not stage this hunk or any later hunks in the file
# s - split the current hunk into smaller hunks
# e - manually edit the current hunk
```

### Staging Specific Lines

```bash
# Using git gui for visual selection
git gui

# Or using command line with specific hunks
git add -p file.txt

# Stage only specific lines by editing hunks
# Press 'e' to edit, then remove lines you don't want to stage
```

### Proposed MCP Tool

```yaml
tool: partial_commit_helper
parameters:
  files: array[string]
  selection_mode: enum["hunks", "lines", "interactive"]
  auto_split: boolean
  preview_changes: boolean
  force_execute: boolean
```

## Amending Commits

### Basic Amendment

```bash
# Amend the last commit message
git commit --amend -m "New commit message"

# Amend the last commit, adding new changes
git add forgotten-file.txt
git commit --amend --no-edit

# Amend with editor
git commit --amend
```

### Advanced Amendment

```bash
# Amend a specific commit (not the last one)
git rebase -i HEAD~3
# Mark the commit as 'edit'
# Make changes
git commit --amend
git rebase --continue

# Amend author information
git commit --amend --author="Name <email@example.com>"

# Amend commit date
git commit --amend --date="2024-01-15T10:30:00"
```

### Proposed MCP Tool

```yaml
tool: commit_amend_helper
parameters:
  target: enum["last", "specific"]
  commit_ref: string (if target="specific")
  amend_options:
    message: string
    author: object {name, email}
    date: string
    add_files: array[string]
  preserve_timestamp: boolean
  force_execute: boolean
```

## Commit Signing

### GPG Signing Setup

```bash
# List GPG keys
gpg --list-secret-keys --keyid-format=long

# Configure git to use GPG key
git config --global user.signingkey <key-id>

# Enable automatic signing
git config --global commit.gpgsign true

# Sign a specific commit
git commit -S -m "Signed commit"
```

### SSH Signing (Git 2.34+)

```bash
# Configure SSH signing
git config --global gpg.format ssh
git config --global user.signingkey ~/.ssh/id_ed25519.pub

# Create allowed signers file
echo "$(git config user.email) $(cat ~/.ssh/id_ed25519.pub)" > ~/.ssh/allowed_signers
git config --global gpg.ssh.allowedSignersFile ~/.ssh/allowed_signers

# Sign with SSH
git commit -S -m "SSH signed commit"
```

### Verification

```bash
# Verify commit signatures
git log --show-signature

# Verify specific commit
git verify-commit <commit-hash>

# Show only signed commits
git log --pretty="format:%h %G? %aN %s" --graph
```

### Proposed MCP Tool

```yaml
tool: commit_signing_manager
parameters:
  action: enum["setup", "sign", "verify", "list"]
  signing_method: enum["gpg", "ssh"]
  key_config:
    key_id: string
    key_path: string (for SSH)
  auto_sign: boolean
  verify_options:
    commits: array[string]
    show_details: boolean
```

## Advanced Commit Creation

### Commit with Specific Timestamp

```bash
# Commit with custom author date
GIT_AUTHOR_DATE="2024-01-15T10:30:00" git commit -m "Message"

# Commit with both author and committer date
export GIT_AUTHOR_DATE="2024-01-15T10:30:00"
export GIT_COMMITTER_DATE="2024-01-15T10:30:00"
git commit -m "Message"
```

### Commit as Different Author

```bash
# Single commit as different author
git commit --author="Other Person <other@example.com>" -m "Message"

# Configure for multiple commits
git config user.name "Other Person"
git config user.email "other@example.com"
```

### Empty Commits

```bash
# Create empty commit (useful for triggering CI)
git commit --allow-empty -m "Trigger CI build"

# Empty commit with sign-off
git commit --allow-empty -s -m "Signed empty commit"
```

### Proposed MCP Tool

```yaml
tool: advanced_commit_creator
parameters:
  message: string
  commit_options:
    author: object {name, email}
    committer: object {name, email}
    author_date: string
    committer_date: string
    allow_empty: boolean
    sign_off: boolean
    gpg_sign: boolean
  stage_files: array[string]
  force_execute: boolean
```

## Commit Templates

### Setting Up Templates

```bash
# Create a commit template file
cat > ~/.gitmessage << 'EOF'
# Type: feat, fix, docs, style, refactor, test, chore
# Scope: component or file name
# Subject: imperative mood, max 50 chars

# Body: explain what and why, not how
# Wrap at 72 characters

# Footer: references to issues, breaking changes
# BREAKING CHANGE: description
# Closes: #123, #456
EOF

# Configure git to use template
git config --global commit.template ~/.gitmessage

# Use template for single commit
git commit -t ~/.gitmessage
```

### Project-Specific Templates

```bash
# Set template for current repository
git config commit.template .gitmessage

# Create project template
cat > .gitmessage << 'EOF'
[JIRA-] Subject

Why:
- 

What:
- 

Testing:
- [ ] Unit tests pass
- [ ] Integration tests pass
- [ ] Manual testing completed
EOF
```

### Proposed MCP Tool

```yaml
tool: commit_template_manager
parameters:
  action: enum["create", "apply", "list", "delete"]
  template_name: string
  template_content: string (for create)
  scope: enum["global", "project"]
  variables: object (for template substitution)
  force_execute: boolean
```

## Best Practices

### 1. Atomic Commits
- Each commit should represent one logical change
- Use partial staging to separate unrelated changes
- Split large changes into multiple commits

### 2. Commit Message Quality
- Use imperative mood ("Add feature" not "Added feature")
- First line: 50 characters max
- Body: wrap at 72 characters
- Explain why, not just what

### 3. Commit Hygiene
- No commented-out code
- No debugging statements
- Run tests before committing
- Use pre-commit hooks

### 4. Security
- Never commit secrets or credentials
- Use `.gitignore` for sensitive files
- Sign commits for authenticity
- Review commits before pushing

## Common Issues and Solutions

### Issue: Committed to Wrong Branch

```bash
# Move commit to correct branch
git checkout correct-branch
git cherry-pick <commit-hash>
git checkout wrong-branch
git reset --hard HEAD~1
```

### Issue: Committed Sensitive Data

```bash
# Remove from last commit
git reset HEAD~1
# Edit files to remove sensitive data
git add .
git commit -m "Safe commit"

# For older commits, use filter-branch or BFG
```

### Issue: Forgot to Sign Commit

```bash
# Sign the last commit
git commit --amend -S --no-edit

# Sign multiple commits
git rebase -i HEAD~3 --exec 'git commit --amend -S --no-edit'
```

## Integration with Commit Helper MCP

These advanced commit operations complement the existing Commit Helper MCP:

1. **Enhanced Message Generation**: Use templates with `generate_commit_message`
2. **Partial Commit Support**: Stage specific changes before commit
3. **Signing Integration**: Automatic signing with generated messages
4. **Amendment Workflow**: Fix commits while maintaining conventions

## Proposed Workflow Enhancement

```yaml
enhanced_commit_workflow:
  1. analyze_changes: Identify logical change groups
  2. partial_stage: Stage related changes together
  3. generate_message: Create conventional commit message
  4. sign_commit: Add GPG/SSH signature
  5. verify_commit: Ensure commit meets standards
  6. push_changes: Safe push with lease
```

This enhanced workflow ensures high-quality, secure, and well-organized commits that follow project conventions and best practices.
