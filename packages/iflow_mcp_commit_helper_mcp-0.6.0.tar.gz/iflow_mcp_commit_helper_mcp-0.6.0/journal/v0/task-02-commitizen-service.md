# Task 02: Create Commitizen Service

## Objective
Create a service class that wraps Commitizen's internal APIs for direct integration, replacing the need for custom plugins and subprocess calls.

## Current State
- Dependencies are configured with MCP SDK and Commitizen (from Task 01)
- No service layer exists yet

## Task Details

### 1. Create Commitizen Service Module
Create `commitizen_service.py` with a `CommitzenService` class that provides:

**Required Methods:**
- `__init__()` - Initialize with BaseConfig and committer factory
- `refresh_config()` - Reload configuration if it changes
- `get_questions()` - Get interactive questions from current plugin
- `generate_message(answers)` - Generate commit message from answers dict
- `validate_message(message)` - Validate commit message format
- `get_example()` - Get example commit message
- `get_schema()` - Get commit message schema
- `get_info()` - Get comprehensive plugin information
- `get_commit_types()` - Extract available commit types from questions

**Key Imports:**
- `from commitizen import factory`
- `from commitizen.config import BaseConfig`
- `from commitizen.exceptions import CommitzenException`

### 2. Create Basic Test Script
Create `test_service.py` to verify the service works:
- Initialize CommitzenService
- Test basic functionality (info, example, questions)
- Test message generation with sample answers
- Test validation

## Expected Deliverables

### Files to Create:
1. ✅ `commitizen_service.py` with complete service implementation
2. ✅ Direct API integration with Commitizen's factory system
3. ✅ Methods for questions, message generation, validation
4. ✅ Configuration management and error handling
5. ✅ Basic test script to verify functionality

## Success Criteria
- [x] Service can initialize with current Commitizen configuration
- [x] All methods work without subprocess calls
- [x] Proper error handling and logging
- [x] Test script runs successfully
- [x] Service works with any installed Commitizen plugin

## Next Task
After completion, proceed to Task 03: Create FastMCP Server

## Notes
- Use Commitizen's factory.committer_factory() for plugin detection
- BaseConfig() automatically loads project configuration
- Direct API calls eliminate subprocess overhead
- Service should work with conventional, angular, or any other plugin
