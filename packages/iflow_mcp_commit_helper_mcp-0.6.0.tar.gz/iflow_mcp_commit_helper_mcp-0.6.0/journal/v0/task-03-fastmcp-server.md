# Task 03: Create FastMCP Server

## Objective
Implement a FastMCP server that exposes Commitizen functionality through MCP tools and resources using the service layer.

## Current State
- Commitizen service is implemented (from Task 02)
- Dependencies are configured with MCP SDK (from Task 01)

## Task Details

### 1. Create the Main MCP Server
Create `commitizen_server.py` with FastMCP server that provides:

**Required Tools:**
- `generate_commit_message(type, subject, body, ...)` - Generate with validation
- `create_commit_message(answers_dict)` - Generate from full answers
- `validate_commit_message(message)` - Validate existing message
- `get_commit_types()` - List available commit types
- `get_commit_questions()` - Get interactive questions

**Required Resources:**
- `commitizen://config` - Current Commitizen configuration
- `commitizen://schema` - Commit message schema
- `commitizen://example` - Example commit message

**Key Imports:**
- `from mcp.server.fastmcp import FastMCP, Context`
- `from commitizen_service import CommitzenService`
- `from commitizen.exceptions import CommitzenException`

### 2. Initialize Server and Service
- Create FastMCP instance with name "Commitizen MCP Connector"
- Initialize global CommitzenService instance
- Configure logging appropriately

### 3. Implement Tool Decorators
Use `@mcp.tool()` decorators for each tool function with:
- Proper type hints for parameters and return values
- Comprehensive docstrings
- Error handling with try/catch blocks
- Return structured data (dicts) for complex responses

### 4. Implement Resource Decorators
Use `@mcp.resource()` decorators for each resource with:
- URI patterns like `commitizen://config`
- Return string content for resources
- Error handling for resource access

## Expected Deliverables

### Files to Create:
1. ✅ `commitizen_server.py` with complete FastMCP server
2. ✅ All required tools implemented with proper decorators
3. ✅ All required resources implemented
4. ✅ Integration with CommitzenService
5. ✅ Proper error handling and logging
6. ✅ Type hints and documentation

## Success Criteria
- [x] FastMCP server initializes without errors
- [x] All tools are properly decorated and functional
- [x] All resources are accessible
- [x] Service integration works correctly
- [x] Error handling prevents crashes
- [x] Server can be tested with `uv run mcp dev main.py` (via MCP Inspector)

## Next Task
After completion, proceed to Task 04: Testing and Development

## Notes
- FastMCP handles all JSON-RPC protocol details automatically
- Use structured return types (dicts) for rich tool responses
- Resources should return string content
- The server will be testable with MCP Inspector
- No manual JSON-RPC handling required
