# Task 01: Setup MCP SDK and Dependencies

## Objective
Configure the project with MCP Python SDK and Commitizen dependencies for direct API integration, eliminating the need for custom plugins and manual JSON-RPC handling.

## Current State
- Basic `pyproject.toml` exists with minimal configuration
- No dependencies are currently defined
- Project metadata is incomplete

## Task Details

### 1. Add MCP SDK and Required Dependencies
Update the `[project]` section in `pyproject.toml`:

```toml
dependencies = [
    "mcp[cli]>=1.10.0",
    "commitizen>=3.0.0",
]
```

### 2. Update Project Metadata
Enhance the project configuration with:

```toml
[project]
name = "commitizen-mcp-connector"
version = "0.1.0"
description = "MCP server for Commitizen integration with direct API access"
readme = "README.md"
requires-python = ">=3.13"
authors = [
    {name = "MCP Connector Team", email = "team@example.com"}
]
license = {text = "MIT"}
keywords = ["commitizen", "mcp", "commit", "git", "fastmcp"]
classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.13",
    "Topic :: Software Development :: Version Control :: Git",
]
```

### 3. Add Development Dependencies and Build System
```toml
[project.optional-dependencies]
dev = [
    "pytest>=7.0.0",
    "black>=23.0.0",
    "ruff>=0.1.0",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.black]
line-length = 88
target-version = ['py313']

[tool.ruff]
target-version = "py313"
line-length = 88
```

## Expected Deliverables

### Updated pyproject.toml should include:
1. ✅ MCP SDK dependency with CLI tools (>=1.10.0)
2. ✅ Commitizen dependency for direct API access (>=3.0.0)
3. ✅ Enhanced project metadata with proper description
4. ✅ Proper Python version requirement (>=3.13)
5. ✅ Development dependencies for code quality
6. ✅ Build system configuration

## Success Criteria
- [x] `pyproject.toml` contains MCP SDK and Commitizen dependencies
- [x] Project metadata is complete and accurate
- [x] Dependencies are compatible with Python 3.13+
- [x] Can install with `make install`
- [x] MCP CLI tools are available after installation

## Next Task
After completion, proceed to Task 02: Create Commitizen Service

## Notes
- MCP SDK provides FastMCP framework, eliminating need for manual JSON-RPC
- Direct Commitizen API integration removes need for custom plugins
- Use `uv` for dependency management as specified in the original plan
- The MCP CLI tools will be used for development and testing
