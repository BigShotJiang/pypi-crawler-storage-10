# Task 04b: Improve Validation and Plugin Integration

## Objective
Enhance the CommitzenService to provide proper validation functionality and fix plugin integration issues.

## Current Issues Identified
From integration test results:
1. **Missing validation pattern** - ConventionalCommitsCz plugin doesn't expose validation pattern properly
2. **Field mapping issues** - Plugin expects different field names than what we're providing
3. **All messages considered valid** - No proper validation happening

## Task Details

### 1. Fix Plugin Field Mapping
The ConventionalCommitsCz plugin expects specific field names:

**Current issues:**
- Plugin expects `footer` field but we're not always providing it
- Plugin expects `scope` field in specific format
- Need to map our generic fields to plugin-specific requirements

**Solution:**
- Update `generate_commit_message` tool to map fields correctly
- Add field validation before calling plugin
- Handle optional fields properly

### 2. Implement Proper Validation
**Current issue:**
- Plugin doesn't expose `pattern` attribute properly
- All messages return as valid

**Solution:**
- Implement custom validation logic for conventional commits
- Add regex pattern for conventional commit format
- Fallback to plugin validation if available

### 3. Add Plugin-Specific Adapters
**Goal:**
- Create adapter pattern for different Commitizen plugins
- Handle ConventionalCommitsCz specifically
- Make system extensible for other plugins

### 4. Improve Error Handling
**Current issues:**
- Generic error messages
- Missing field errors not user-friendly

**Solution:**
- Add specific error messages for missing fields
- Provide helpful suggestions for fixing issues
- Better error context

## Implementation Plan

### Step 1: Create Plugin Adapter System
```python
class PluginAdapter:
    """Base adapter for Commitizen plugins."""
    
    def map_fields(self, answers: Dict[str, Any]) -> Dict[str, Any]:
        """Map generic fields to plugin-specific fields."""
        pass
    
    def validate_message(self, message: str) -> bool:
        """Validate message using plugin-specific rules."""
        pass

class ConventionalCommitsAdapter(PluginAdapter):
    """Adapter for ConventionalCommitsCz plugin."""
    
    PATTERN = r'^(feat|fix|docs|style|refactor|test|chore)(\(.+\))?: .{1,50}'
    
    def map_fields(self, answers: Dict[str, Any]) -> Dict[str, Any]:
        """Map to conventional commits format."""
        mapped = {
            'prefix': answers.get('type', answers.get('prefix', '')),
            'subject': answers.get('subject', ''),
            'body': answers.get('body', ''),
            'scope': answers.get('scope', ''),
            'footer': answers.get('footer', ''),
            'is_breaking_change': answers.get('breaking', False)
        }
        return mapped
    
    def validate_message(self, message: str) -> bool:
        """Validate using conventional commits pattern."""
        import re
        return bool(re.match(self.PATTERN, message))
```

### Step 2: Update CommitzenService
- Add plugin detection and adapter selection
- Implement proper field mapping
- Add custom validation logic
- Improve error messages

### Step 3: Update Server Tools
- Fix `generate_commit_message` to use adapters
- Update `create_commit_message` with proper field mapping
- Enhance `validate_commit_message` with custom validation

### Step 4: Update Tests
- Fix integration tests with correct field expectations
- Add tests for validation functionality
- Test different message formats properly

## Expected Deliverables

### Files to Create/Update:
1. ✅ `src/commitizen_mcp_connector/plugin_adapters.py` - Plugin adapter system
2. ✅ Updated `src/commitizen_mcp_connector/commitizen_service.py` - Enhanced service
3. ✅ Updated `src/commitizen_mcp_connector/commitizen_server.py` - Fixed server tools
4. ✅ Updated `test_integration.py` - Fixed integration tests
5. ✅ New unit tests for validation functionality

## Success Criteria
- [ ] Integration tests pass (10/10)
- [ ] Proper validation distinguishes valid/invalid messages
- [ ] Field mapping works correctly for ConventionalCommitsCz
- [ ] Error messages are helpful and specific
- [ ] Performance remains acceptable
- [ ] MCP Inspector shows working validation

## Implementation Notes
- Focus on ConventionalCommitsCz plugin first (most common)
- Make system extensible for other plugins later
- Maintain backward compatibility
- Keep error handling robust

## Testing Strategy
1. **Unit tests** for plugin adapters
2. **Integration tests** for full workflow
3. **Manual testing** with MCP Inspector
4. **Edge case testing** for validation

This task addresses the core validation issues identified in Task 04 testing.
