<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" class="logo" width="120"/>

## 1-Hour Project Plan: Commitizen MCP Connector with Custom Plugin (uv Environment)

### Objective

Develop a minimal Commitizen MCP connector in Python, using a custom Commitizen plugin tailored for MCP requirements. All steps assume your Python environment is already set up and managed by `uv`—no environment creation or dependency installation instructions are needed.

### 0–10 min: Project Structure

- Create a new project directory:
`commitizen_mcp_connector/`
- Inside, create a plugin package:
`cz_mcp_plugin/`
- Example directory layout:

```
commitizen_mcp_connector/
  cz_mcp_plugin/
    __init__.py
    mcp_cz.py
  mcp_connector.py
  pyproject.toml
  README.md
```


### 10–25 min: Custom Commitizen Plugin

- In `cz_mcp_plugin/mcp_cz.py`, implement your plugin:

```python
from commitizen.plugin import BaseCommitizen

class McpCz(BaseCommitizen):
    def questions(self):
        return [
            {"type": "input", "name": "type", "message": "Commit type:"},
            {"type": "input", "name": "subject", "message": "Commit subject:"},
        ]

    def message(self, answers):
        return f"{answers['type']}: {answers['subject']}"
```

- Register the plugin as a Commitizen entry point in `pyproject.toml`:

```toml
[project.entry-points."commitizen.plugin"]
mcp_cz = "cz_mcp_plugin.mcp_cz:McpCz"
```


### 25–40 min: MCP Connector Script

- In `mcp_connector.py`, implement the connector logic:

```python
import sys
import json
import subprocess

def handle_json_rpc():
    request = json.load(sys.stdin)
    result = subprocess.run(
        ["cz", "commit", "--name", "mcp_cz", "--dry-run"],
        capture_output=True, text=True
    )
    response = {
        "jsonrpc": "2.0",
        "id": request["id"],
        "result": result.stdout
    }
    print(json.dumps(response))

if __name__ == "__main__":
    handle_json_rpc()
```

- This script reads JSON-RPC requests from stdin, invokes Commitizen with your plugin, and outputs the result as a JSON-RPC response.


### 40–50 min: Configuration \& Testing

- In `pyproject.toml`, configure Commitizen to use your plugin:

```toml
[tool.commitizen]
name = "mcp_cz"
```

- Test the connector:
    - Simulate a JSON-RPC request via stdin.
    - Confirm the correct commit message is returned.


### 50–60 min: Documentation \& Polish

- In `README.md`, document:
    - How to run the connector script.
    - How to configure and use the custom Commitizen plugin.
    - Example JSON-RPC request/response.
- Clean up code and add comments as needed.


### Deliverables

| Component | Description |
| :-- | :-- |
| `cz_mcp_plugin/` | Custom Commitizen plugin package |
| `mcp_connector.py` | MCP connector script |
| `pyproject.toml` | Project and plugin configuration |
| `README.md` | Setup and usage instructions |

**Tips:**

- Since the environment is managed by `uv`, skip all virtual environment and dependency installation steps.
- Focus on functionality and integration between Commitizen and MCP.
- Test early to ensure smooth end-to-end operation.

