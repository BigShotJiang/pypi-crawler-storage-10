# Architecture Diagrams: Security-Focused Design

## Security-Focused CWD Flow

```mermaid
graph TD
    A[MCP Tool Called] --> B[Get CWD]
    B --> C[Validate CWD]
    
    C --> D{Is Valid Directory?}
    D -->|No| E[Error: Invalid CWD]
    D -->|Yes| F{Is Git Repo?}
    
    F -->|No| G{Git Required?}
    G -->|Yes| H[Error: Not Git Repo]
    G -->|No| I[Execute Operation]
    
    F -->|Yes| I[Execute Operation]
    
    E --> J[Return Error Response]
    H --> J
    I --> K[Return Success Response]
```

## Simplified Architecture

```mermaid
classDiagram
    class SecureRepositoryManager {
        -_context: CWDContext
        +__init__()
        +get_repository_path() str
        +validate_cwd() bool
        +validate_git_repository() bool
    }
    
    class CWDContext {
        +cwd_path: str
        +is_valid_directory: bool
        +is_git_repository: bool
        +validation_error: Optional[str]
    }
    
    class ValidationFunctions {
        +validate_cwd_for_operation() Tuple
        +validate_cwd_for_git_operation() Tuple
    }
    
    SecureRepositoryManager --> CWDContext
    ValidationFunctions --> SecureRepositoryManager
```

## Error Handling Flow (Simplified)

```mermaid
flowchart LR
    A[Current Working Directory] --> B[Is Directory?]
    B -->|Always Yes| C[Has Read Access?]
    
    C -->|No| D[Error: Permission Denied]
    C -->|Yes| E[Is Git Repo?]
    
    E -->|No| F[Limited Operations]
    E -->|Yes| G[Full Operations]
    
    D --> H[Create Error Response]
```

## Tool Architecture Comparison

### Before: Flexible Path Resolution

```mermaid
graph TD
    A[Tool Called] --> B{repo_path?}
    B -->|Yes| C[Use Parameter]
    B -->|No| D{Environment?}
    D -->|Yes| E[Use Env Var]
    D -->|No| F{Client Context?}
    F -->|Yes| G[Use Client Path]
    F -->|No| H[Use CWD]
    
    C --> I[Validate & Execute]
    E --> I
    G --> I
    H --> I
```

### After: Security-Focused CWD Only

```mermaid
graph TD
    A[Tool Called] --> B[Use CWD]
    B --> C[Validate CWD]
    C --> D[Execute Operation]
```

## Service Layer Changes

```mermaid
graph LR
    subgraph "Before: Complex Services"
        A1[Tool] --> B1[Service with repo_path]
        B1 --> C1[Path Resolution]
        C1 --> D1[Validation]
        D1 --> E1[Operation]
    end
    
    subgraph "After: Simple Services"
        A2[Tool] --> B2[Service using CWD]
        B2 --> C2[CWD Validation]
        C2 --> D2[Operation]
    end
```

## Security Benefits Visualization

```mermaid
graph TD
    subgraph "Security Vulnerabilities Eliminated"
        A[Path Traversal] --> X[❌ Eliminated]
        B[Arbitrary Directory Access] --> X
        C[Environment Variable Injection] --> X
        D[Client Path Manipulation] --> X
    end
    
    subgraph "Security Guarantees"
        E[CWD Only] --> Y[✅ Enforced]
        F[No External Paths] --> Y
        G[Explicit Directory Changes] --> Y
        H[Clear Operation Scope] --> Y
    end
```

## Testing Architecture

```mermaid
graph TD
    subgraph "Before: Complex Testing"
        A1[Test Setup] --> B1[Mock Paths]
        B1 --> C1[Mock Env Vars]
        C1 --> D1[Mock Context]
        D1 --> E1[Test Execution]
        E1 --> F1[Complex Cleanup]
    end
    
    subgraph "After: Simple Testing"
        A2[Test Setup] --> B2[Change Directory]
        B2 --> C2[Test Execution]
        C2 --> D2[Natural Cleanup]
    end
```

## Migration Path

```mermaid
graph TD
    A[v1.x with repo_path] --> B{User Action}
    B -->|Update Code| C[Remove repo_path calls]
    C --> D[Add cd commands]
    D --> E[v2.0 CWD Only]
    
    B -->|Update Scripts| F[Replace --repo-path]
    F --> G[Use cd && command]
    G --> E
    
    B -->|Update CI/CD| H[Update pipelines]
    H --> I[Add directory navigation]
    I --> E
```

## Component Relationships (Security-Focused)

```mermaid
graph TD
    subgraph "MCP Layer"
        A[MCP Tools - No Path Parameters]
    end
    
    subgraph "Validation Layer"
        B[CWD Validation Functions]
        C[Git Repository Checks]
    end
    
    subgraph "Service Layer"
        D[Services - CWD Only]
        E[No Path Resolution]
    end
    
    subgraph "Security Layer"
        F[No External Paths]
        G[No Environment Variables]
        H[CWD Enforcement]
    end
    
    A --> B
    B --> C
    C --> D
    D --> E
    
    F --> A
    G --> A
    H --> B
```

## Performance Impact

```mermaid
graph LR
    subgraph "Removed Overhead"
        A[Path Resolution Logic] --> X[❌]
        B[Environment Checks] --> X
        C[Context Provider] --> X
        D[Thread-Local Storage] --> X
    end
    
    subgraph "Remaining Operations"
        E[CWD Validation] --> Y[✅ Fast]
        F[Git Check] --> Y
        G[Direct Execution] --> Y
    end
```

## Summary Diagram

```mermaid
mindmap
  root((Security-Focused<br/>CWD Operations))
    Benefits
      Enhanced Security
        No Path Traversal
        No Arbitrary Access
        Clear Boundaries
      Simplified Code
        No Path Parameters
        No Complex Resolution
        Stateless Operations
      Better Testing
        Natural Isolation
        Simple Setup
        No Mocking
    Trade-offs
      Less Flexible
        CWD Only
        Manual Navigation
        Script Updates
      Breaking Changes
        API Changes
        Migration Required
        Documentation Updates
