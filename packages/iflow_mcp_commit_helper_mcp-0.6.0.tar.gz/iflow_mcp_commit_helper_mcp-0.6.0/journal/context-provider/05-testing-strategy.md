# Testing Strategy: Security-Focused CWD Operations

## Overview

Testing the security-focused repository manager is significantly simpler than testing a flexible context provider. With all operations restricted to the current working directory, tests focus on CWD validation and error handling rather than complex path resolution scenarios.

## Test Categories

### 1. Unit Tests

Unit tests focus on the simplified components:

#### Core Functionality Tests
- Test CWD validation logic
- Test git repository detection in CWD
- Test permission checking for CWD
- Test error message generation

#### Validation Method Tests
- Test `validate_cwd_for_operation()` with valid/invalid CWD
- Test `validate_cwd_for_git_operation()` with git/non-git CWD
- Test CWD status reporting

#### Manager Tests
- Test `SecureRepositoryManager` initialization
- Test `get_repository_path()` always returns CWD
- Test validation methods

### 2. Integration Tests

Integration tests verify CWD-only operations:

#### Tool Integration Tests
- Test MCP tools work with CWD
- Test error handling when CWD is invalid
- Test tools cannot accept path parameters
- Test environment variables are ignored

#### Service Integration Tests
- Test services only use CWD
- Test service initialization without path parameters
- Test error propagation from services

#### Security Tests
- Verify tools cannot access other directories
- Test that path parameters are rejected
- Ensure environment variables have no effect

### 3. End-to-End Tests

End-to-end tests with real directories:

#### Real Repository Tests
- Test with CWD as git repository
- Test with CWD as non-git directory
- Test directory navigation workflows

#### Tool Execution Tests
- Test git tools in git repositories
- Test message generation in valid repos
- Test workflow tools with CWD

#### Error Handling Tests
- Test operations in non-git directories
- Test helpful error messages
- Test recovery suggestions

### 4. Performance Tests

Simplified performance testing:

#### Validation Performance
- Measure CWD validation time
- Verify minimal overhead

#### Tool Execution Performance
- Compare with previous implementation
- Ensure no performance regression

### 5. Security Tests

Critical security validation:

#### Path Restriction Tests
- Verify operations limited to CWD
- Test rejection of path traversal attempts
- Ensure no filesystem information leakage

#### Environment Isolation Tests
- Test environment variables are ignored
- Verify no external configuration affects operations

### 6. Migration Tests

Tests for migration scenarios:

#### Breaking Change Tests
- Test old API calls fail appropriately
- Verify clear migration error messages
- Test documentation examples

## Test Implementation

### Simplified Test Structure

```
tests/
├── unit/
│   └── security/
│       ├── test_secure_repository_manager.py
│       └── test_cwd_validation.py
├── integration/
│   └── security/
│       ├── test_cwd_only_tools.py
│       └── test_security_restrictions.py
└── end_to_end/
    └── security/
        ├── test_real_cwd_operations.py
        └── test_migration_scenarios.py
```

### Example Unit Test

```python
class TestSecureRepositoryManager:
    """Test the security-focused repository manager."""
    
    def test_always_uses_cwd(self):
        """Test manager always returns current working directory."""
        manager = SecureRepositoryManager()
        assert manager.get_repository_path() == os.getcwd()
    
    def test_validates_cwd_is_directory(self):
        """Test validation of current working directory."""
        with temporary_directory() as temp_dir:
            os.chdir(temp_dir)
            manager = SecureRepositoryManager()
            assert manager._context.is_valid_directory
    
    def test_detects_git_repository(self):
        """Test git repository detection in CWD."""
        with temporary_git_repo() as repo:
            os.chdir(repo.working_dir)
            manager = SecureRepositoryManager()
            assert manager._context.is_git_repository
```

### Example Integration Test

```python
class TestCWDOnlyTools:
    """Test tools only operate on CWD."""
    
    def test_tool_uses_cwd(self):
        """Test tool operates on current directory."""
        with temporary_git_repo() as repo:
            os.chdir(repo.working_dir)
            
            # Tool should work without parameters
            result = get_git_status()
            assert result["success"] is True
            assert result["repository_path"] == repo.working_dir
    
    def test_tool_rejects_path_parameter(self):
        """Test tool cannot accept path parameter."""
        # In new design, tools don't have path parameters
        # This test verifies the API change
        with pytest.raises(TypeError):
            get_git_status(repo_path="/some/path")
```

### Example Security Test

```python
class TestSecurityRestrictions:
    """Test security restrictions are enforced."""
    
    def test_cannot_access_parent_directory(self):
        """Test operations cannot access parent directories."""
        with temporary_directory() as temp_dir:
            sub_dir = os.path.join(temp_dir, "subdir")
            os.makedirs(sub_dir)
            os.chdir(sub_dir)
            
            # Operations should only see current directory
            result = list_files()
            assert temp_dir not in str(result)
    
    def test_environment_variable_ignored(self):
        """Test COMMITIZEN_REPO_PATH is ignored."""
        with temporary_directory() as temp_dir:
            other_dir = os.path.join(temp_dir, "other")
            os.makedirs(other_dir)
            
            # Set environment variable
            os.environ["COMMITIZEN_REPO_PATH"] = other_dir
            
            # Should still use CWD
            os.chdir(temp_dir)
            manager = SecureRepositoryManager()
            assert manager.get_repository_path() == temp_dir
            assert manager.get_repository_path() != other_dir
```

## Key Testing Simplifications

### 1. No Path Mocking
- Tests always use actual CWD
- No complex path resolution to test
- Simpler test setup and teardown

### 2. Fewer Error Cases
- No "path not found" errors
- No path traversal scenarios
- Focus on CWD validation only

### 3. Clearer Test Intent
- Each test has single responsibility
- No parameter variations to test
- Security focus is explicit

### 4. Faster Test Execution
- No environment variable manipulation
- Fewer test permutations
- Simpler validation logic

## Test Coverage Goals

1. **100% Coverage**: All CWD validation paths
2. **Security Validation**: Verify all restrictions
3. **Error Messages**: Test all error scenarios
4. **Migration Path**: Validate breaking changes
5. **Performance**: No regression from simplification

## Benefits of Simplified Testing

1. **Fewer Tests Needed**: Eliminated path-related test cases
2. **Clearer Tests**: Each test has obvious purpose
3. **Faster Execution**: Less setup and teardown
4. **Better Security**: Explicit security validation
5. **Easier Maintenance**: Simpler test infrastructure
