# Security-Focused Repository Manager Design

## Core Components

### 1. CWDContext

A simplified context class for current working directory operations:

```python
@dataclass
class CWDContext:
    """Current working directory context information."""
    
    # Always the current working directory
    cwd_path: str = field(default_factory=os.getcwd)
    
    # Validation status
    is_valid_directory: bool = field(default=False)
    is_git_repository: bool = field(default=False)
    validation_error: Optional[str] = field(default=None)
    
    # Git information (if applicable)
    git_enabled: bool = field(default=False)
    branch_name: Optional[str] = field(default=None)
    commit_count: int = field(default=0)
```

### 2. SecureRepositoryManager

A simplified manager that only works with CWD:

```python
class SecureRepositoryManager:
    """
    Repository manager that only operates on current working directory.
    
    Provides validation and context for CWD-only operations.
    """
    
    def __init__(self):
        """Initialize with current working directory."""
        self._context = CWDContext()
        self._validate_cwd()
    
    def get_repository_path(self) -> str:
        """Always returns current working directory."""
        return os.getcwd()
    
    def _validate_cwd(self):
        """Validate current working directory."""
        cwd = os.getcwd()
        
        # Basic validation
        if not os.path.exists(cwd):
            self._context.is_valid_directory = False
            self._context.validation_error = "Current working directory does not exist"
            return
            
        if not os.path.isdir(cwd):
            self._context.is_valid_directory = False
            self._context.validation_error = "Current working directory is not a directory"
            return
            
        if not os.access(cwd, os.R_OK):
            self._context.is_valid_directory = False
            self._context.validation_error = "No read access to current working directory"
            return
            
        self._context.is_valid_directory = True
        
        # Check if it's a git repository
        git_dir = os.path.join(cwd, ".git")
        self._context.is_git_repository = os.path.exists(git_dir)
        self._context.git_enabled = self._context.is_git_repository
```

### 3. Validation Functions

Simplified validation functions for CWD operations:

```python
def validate_cwd_for_operation() -> Tuple[bool, Optional[Dict[str, Any]]]:
    """Validate current working directory is suitable for operations."""
    manager = SecureRepositoryManager()
    
    if not manager._context.is_valid_directory:
        return False, create_error_response(
            RepositoryError(
                message=manager._context.validation_error or "Invalid directory",
                repo_path=os.getcwd()
            )
        )
    
    return True, None

def validate_cwd_for_git_operation() -> Tuple[bool, Optional[Dict[str, Any]]]:
    """Validate current working directory is a git repository."""
    manager = SecureRepositoryManager()
    
    # First check basic directory validity
    is_valid, error = validate_cwd_for_operation()
    if not is_valid:
        return False, error
    
    # Then check git repository
    if not manager._context.is_git_repository:
        return False, create_error_response(
            RepositoryError(
                message="Current directory is not a git repository",
                repo_path=os.getcwd(),
                suggestions=[
                    "Run 'git init' to initialize a repository",
                    "Change to a directory containing a git repository"
                ]
            )
        )
    
    return True, None
```

## No Repository Detection

Unlike the flexible context provider design, this security-focused approach:

1. **No Path Parameters**: Tools cannot accept repository paths
2. **No Environment Variables**: `COMMITIZEN_REPO_PATH` is ignored
3. **No Client Context**: MCP client cannot specify repository
4. **Only CWD**: Always uses `os.getcwd()`

## Repository Validation

The manager validates only the current working directory:

1. **Existence Check**: Verify CWD exists (should always pass)
2. **Directory Check**: Verify CWD is a directory (should always pass)
3. **Access Check**: Verify read access to CWD
4. **Git Check**: Check if CWD is a git repository

## Integration with MCP Server

No special integration needed - tools always use CWD:

```python
# No need for connection handlers or context updates
# Each tool independently validates CWD when called
```

## Integration with Tools

Tools are simplified to always use CWD:

```python
@mcp.tool()
def get_enhanced_git_status() -> Dict[str, Any]:
    """Get enhanced git repository status for current directory."""
    # Validate CWD is a git repository
    is_valid, error_response = validate_cwd_for_git_operation()
    if not is_valid:
        return error_response
    
    # Always use CWD
    service = GitPythonCore(repo_path=os.getcwd())
    return service.get_enhanced_status()
```

## Benefits

1. **Maximum Security**: No possibility of accessing other directories
2. **Simplicity**: No complex path resolution or priority logic
3. **Predictability**: Always operates on current directory
4. **Reduced Code**: Significant reduction in codebase complexity
5. **Clear Errors**: Simple, actionable error messages

## Trade-offs

1. **No Flexibility**: Cannot operate on other directories
2. **Manual Navigation**: Users must `cd` to target directory
3. **Breaking Change**: Not backward compatible
4. **Script Changes**: Multi-repository scripts need updates
