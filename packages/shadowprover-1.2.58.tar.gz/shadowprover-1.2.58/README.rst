
## ShadowProver
ShadowProver is a theorem prover (multi-modal logic with quantifiers). 

