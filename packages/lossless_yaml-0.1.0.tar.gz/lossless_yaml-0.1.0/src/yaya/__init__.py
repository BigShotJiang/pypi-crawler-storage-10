"""
yaya: Yet Another YAML AST transformer - Byte-for-byte preserving YAML editor.
"""
from .document import YAYA

__version__ = "0.1.0"
__all__ = ["YAYA"]
