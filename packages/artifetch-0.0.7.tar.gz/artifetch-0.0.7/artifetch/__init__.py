from .core import fetch

__all__ = ["fetch"]