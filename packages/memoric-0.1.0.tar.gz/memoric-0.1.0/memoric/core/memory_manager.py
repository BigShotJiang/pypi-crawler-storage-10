from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

from .config_loader import ConfigLoader
from .config_loader import load_yaml, _deep_merge  # type: ignore
from ..db.postgres_connector import PostgresConnector
from ..agents.metadata_agent import MetadataAgent
from ..utils.scoring import score_memory
from .retriever import Retriever
from .policy_executor import PolicyExecutor


class Memoric:
    def __init__(
        self,
        *,
        config_path: Optional[str] = None,
        overrides: Optional[Dict[str, Any]] = None,
    ) -> None:
        self._init_args = {"config_path": config_path, "overrides": overrides}
        self._initialized = False
        self.config: Dict[str, Any] = {}
        self.db: Optional[PostgresConnector] = None
        self.metadata_agent = None
        self.retriever = None

    def _create_sqlite_fallback(self) -> PostgresConnector:
        # For local dev without PG, allow sqlite URL via config or fallback file
        sqlite_dsn = self.config.get("storage", {}).get("sqlite_dsn") or "sqlite:///memoric_dev.db"
        return PostgresConnector(dsn=sqlite_dsn)

    def _resolve_db_config(self) -> Dict[str, Any]:
        # Pick long_term or mid_term sqlite/postgres as primary write store
        storage = self.config.get("storage", {})
        tiers = storage.get("tiers", [])
        for preferred in ("long_term", "mid_term"):
            for tier in tiers:
                if tier.get("name") == preferred and tier.get("dsn"):
                    return {"dsn": tier["dsn"]}
        return {"dsn": None}

    def _ensure_initialized(self) -> None:
        if self._initialized:
            return
        config_path = self._init_args.get("config_path")
        overrides = self._init_args.get("overrides")
        loader = ConfigLoader(runtime_overrides=overrides)
        self.config = loader.load()
        if config_path:
            from pathlib import Path

            self.config = _deep_merge(self.config, load_yaml(Path(config_path)))  # type: ignore

        db_cfg = self._resolve_db_config()
        self.db = (
            PostgresConnector(dsn=db_cfg["dsn"])
            if db_cfg.get("dsn")
            else self._create_sqlite_fallback()
        )
        self.db.create_schema_if_not_exists()

        # Read metadata agent model from config with fallback
        metadata_cfg = self.config.get("metadata", {}).get("enrichment", {})
        model = metadata_cfg.get("model", "gpt-4o-mini")
        self.metadata_agent = MetadataAgent(
            model=model,
            api_key=os.getenv("OPENAI_API_KEY")
        )
        recall_cfg = self.config.get("recall") or {}
        scoring_cfg = self.config.get("scoring") or {}
        self.retriever = Retriever(
            db=self.db,
            default_top_k=int(recall_cfg.get("default_top_k", 10)),
            scoring_config=scoring_cfg,
            custom_rules=None,
        )
        self._initialized = True

    # Public API
    def save(
        self,
        *,
        user_id: str,
        content: Optional[str] = None,
        thread_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        session_id: Optional[str] = None,
        namespace: Optional[str] = None,
        # Aliases for better UX
        message: Optional[str] = None,
        role: Optional[str] = None,
    ) -> int:
        """Save a memory to the database.

        Args:
            user_id: User identifier (required)
            content: Memory content (or use 'message' alias)
            thread_id: Thread/conversation identifier
            metadata: Additional metadata dictionary
            session_id: Session identifier
            namespace: Namespace for multi-tenancy
            message: Alias for 'content' parameter
            role: Optional role (e.g., 'user', 'assistant') - stored in metadata

        Returns:
            Memory ID (int)
        """
        self._ensure_initialized()

        # Handle parameter aliases
        if message is not None and content is None:
            content = message

        if content is None:
            raise ValueError("Either 'content' or 'message' parameter is required")

        metadata = dict(metadata or {})

        # Add role to metadata if provided
        if role is not None:
            metadata['role'] = role
        enriched = self.metadata_agent.extract(
            text=content, user_id=user_id, thread_id=thread_id, session_id=session_id
        )
        merged_meta = {**metadata, **enriched}

        # Use shared importance mapping (includes 'critical' level)
        from ..utils.scoring import IMPORTANCE_LEVELS
        importance_level = IMPORTANCE_LEVELS.get(
            str(merged_meta.get("importance", "medium")).lower(), 5
        )
        score = score_memory(
            importance_level=importance_level,
            last_seen_at=None,
            seen_count=int(merged_meta.get("seen_count", 1)),
        )

        write_policy = self.config.get("policies", {}).get("write") or []
        target_tier = None
        for rule in write_policy:
            when = (rule.get("when") or "").strip().lower()
            if when == "always":
                target_tier = (rule.get("to") or [None])[0]
                break
            if ">=" in when and "score" in when:
                try:
                    threshold_str = when.split(">=")[-1].strip()
                    threshold = float(threshold_str)

                    # Handle both 0-1 scale (0.8) and 0-100 scale (80)
                    # If threshold < 1, assume it's 0-1 scale and multiply by 100
                    if threshold < 1.0:
                        threshold_score = int(threshold * 100)
                    else:
                        threshold_score = int(threshold)

                    if score >= threshold_score:
                        target_tier = (rule.get("to") or [None])[0]
                        break
                except Exception:
                    continue

        new_id = self.db.insert_memory(
            user_id=user_id,
            thread_id=thread_id,
            content=content,
            tier=target_tier,
            score=score,
            metadata=merged_meta,
            namespace=namespace or (self.config.get("privacy", {}).get("default_namespace")),
        )
        return new_id

    def retrieve(
        self,
        *,
        user_id: Optional[str] = None,
        thread_id: Optional[str] = None,
        metadata_filter: Optional[Dict[str, Any]] = None,
        scope: Optional[str] = None,
        top_k: Optional[int] = None,
        namespace: Optional[str] = None,
        session_id: Optional[str] = None,
        # Aliases for better UX
        query: Optional[str] = None,
        max_results: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """Retrieve memories from the database.

        Args:
            user_id: Filter by user ID
            thread_id: Filter by thread ID
            metadata_filter: Filter by metadata fields
            scope: Retrieval scope (thread|topic|user|global)
            top_k: Maximum number of results (or use 'max_results' alias)
            namespace: Filter by namespace
            session_id: Session identifier
            query: Search query - automatically added to metadata filter
            max_results: Alias for 'top_k' parameter

        Returns:
            List of memory dictionaries with scores
        """
        self._ensure_initialized()

        # Handle parameter aliases
        if max_results is not None and top_k is None:
            top_k = max_results

        # Handle query parameter - add to metadata filter
        if query is not None:
            metadata_filter = metadata_filter or {}
            # Store query for potential semantic search
            metadata_filter['_query'] = query

        recall_scope = scope or (self.config.get("recall", {}).get("scope") or "thread")
        privacy_cfg = self.config.get("privacy", {})
        enforce_user = bool(privacy_cfg.get("enforce_user_scope", True))
        allow_shared = bool(privacy_cfg.get("allow_shared_namespace", False))

        # Enforce user scope unless explicitly allowed via namespace
        eff_user_id = user_id
        eff_namespace = namespace or privacy_cfg.get("default_namespace")
        if not allow_shared:
            eff_namespace = None
        if enforce_user and not eff_namespace:
            # user_id required for retrieval in privacy-first mode
            pass
        return self.retriever.search(
            user_id=eff_user_id,
            thread_id=thread_id,
            metadata_filter=metadata_filter,
            scope=recall_scope,
            namespace=eff_namespace,
            top_k=top_k,
        )

    def retrieve_context(
        self,
        *,
        user_id: Optional[str] = None,
        thread_id: Optional[str] = None,
        metadata_filter: Optional[Dict[str, Any]] = None,
        scope: Optional[str] = None,
        top_k: Optional[int] = None,
        namespace: Optional[str] = None,
        query: Optional[str] = None,
        max_results: Optional[int] = None,
        format_type: str = "structured",
        include_scores: bool = False,
    ) -> Dict[str, Any]:
        """Retrieve memories and assemble into structured context.

        This method retrieves memories and formats them into a structured context
        with separate thread_context and related_history sections.

        Args:
            user_id: Filter by user ID
            thread_id: Filter by thread ID
            metadata_filter: Filter by metadata fields
            scope: Retrieval scope (thread|topic|user|global)
            top_k: Maximum number of results
            namespace: Filter by namespace
            query: Search query string
            max_results: Alias for top_k
            format_type: Output format - 'structured', 'simple', or 'chat'
            include_scores: Include relevance scores in output

        Returns:
            Structured context dictionary with thread_context and related_history
        """
        # Retrieve raw memories
        memories = self.retrieve(
            user_id=user_id,
            thread_id=thread_id,
            metadata_filter=metadata_filter,
            scope=scope,
            top_k=top_k,
            namespace=namespace,
            query=query,
            max_results=max_results,
        )

        # Assemble into structured context
        from .context_assembler import ContextAssembler

        assembler = ContextAssembler(
            include_metadata=True,
            include_scores=include_scores,
        )

        return assembler.assemble(
            memories=memories,
            thread_id=thread_id,
            user_id=user_id,
            format_type=format_type,
        )

    def run_policies(self) -> None:
        self._ensure_initialized()
        executor = PolicyExecutor(db=self.db, config=self.config)
        return executor.run()

    def initialize(self) -> None:
        """Explicitly initialize Memoric (creates DB connection, loads config).

        This is called automatically on first use, but can be called manually
        for eager initialization (e.g., in CLI commands or health checks).
        """
        self._ensure_initialized()

    def inspect(self) -> Dict[str, Any]:
        self._ensure_initialized()
        return {
            "config": self.config,
            "db_table": self.db.table_name,
            "counts_by_tier": self.db.count_by_tier(),
        }

    def rebuild_clusters(self, user_id: str) -> int:
        """Rebuild topic/category clusters for a user.

        This method:
        1. Fetches all user memories
        2. Groups them into topic/category clusters
        3. Upserts clusters (updates existing, creates new)
        4. Tracks which clusters were touched
        5. Deletes orphaned clusters that no longer have memories

        Args:
            user_id: User ID to rebuild clusters for

        Returns:
            Number of clusters created or updated
        """
        self._ensure_initialized()
        from .clustering import SimpleClustering

        # Get all memories for this user
        memories = self.db.get_memories(user_id=user_id, limit=10000)

        # Group into clusters
        clustering = SimpleClustering()
        clusters = clustering.group(memories)

        # Track which clusters we've updated (by topic+category key)
        updated_keys = set()

        # Upsert each cluster
        for cluster in clusters:
            self.db.upsert_cluster(
                user_id=user_id,
                topic=cluster.topic,
                category=cluster.category,
                memory_ids=cluster.memory_ids,
                summary=cluster.summary
            )
            updated_keys.add((cluster.topic, cluster.category))

        # Delete orphaned clusters (those not in current clustering)
        existing = self.db.get_clusters(user_id=user_id, limit=10000)
        for existing_cluster in existing:
            key = (existing_cluster["topic"], existing_cluster["category"])
            if key not in updated_keys:
                # This cluster no longer has memories - delete it
                self.db.delete_cluster(cluster_id=existing_cluster["cluster_id"])

        return len(clusters)

    def get_topic_clusters(
        self,
        user_id: str,
        topic: Optional[str] = None,
        category: Optional[str] = None,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """Get topic clusters for a user.

        Args:
            user_id: User ID to get clusters for
            topic: Optional topic filter
            category: Optional category filter
            limit: Maximum number of clusters to return

        Returns:
            List of cluster dictionaries
        """
        self._ensure_initialized()
        return self.db.get_clusters(
            user_id=user_id,
            topic=topic,
            category=category,
            limit=limit
        )

    def as_storage_context(self) -> Any:
        """
        Create a LlamaIndex-compatible storage context.

        This method provides integration with LlamaIndex by exposing
        Memoric as a storage backend.

        Returns:
            Storage context object compatible with LlamaIndex

        Example:
            >>> from memoric import Memoric
            >>> mem = Memoric()
            >>> storage_context = mem.as_storage_context()
            >>> # Use with LlamaIndex
        """
        try:
            from ..integrations.llamaindex import MemoricStorageContext
            self._ensure_initialized()
            return MemoricStorageContext(memoric=self)
        except ImportError as e:
            raise ImportError(
                "LlamaIndex integration not available. "
                "Install with: pip install llama-index"
            ) from e
