from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Iterable, List, Optional

from sqlalchemy import (
    JSON,
    Column,
    DateTime,
    Integer,
    MetaData,
    String,
    Table,
    Text,
    and_,
    create_engine,
    func,
    insert,
    or_,
    select,
    update,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.engine import Engine
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.pool import QueuePool

from ..utils.encryption import EncryptionService

logger = logging.getLogger(__name__)


DEFAULT_TABLE_NAME = "memories"


class PostgresConnector:
    def __init__(
        self,
        dsn: str,
        table_name: str = DEFAULT_TABLE_NAME,
        pool_size: int = 5,
        max_overflow: int = 10,
        encryption_key: Optional[str] = None,
        encrypt_content: bool = False,
    ) -> None:
        self.dsn = dsn
        self.table_name = table_name
        self.engine: Engine = create_engine(
            dsn,
            poolclass=QueuePool,
            pool_size=pool_size,
            max_overflow=max_overflow,
            future=True,
        )
        self.metadata = MetaData()

        # Initialize encryption service
        self.encryptor = EncryptionService(
            encryption_key=encryption_key,
            enabled=encrypt_content
        )
        self.encrypt_content = encrypt_content

        # Fields to encrypt
        self.encrypted_fields = ["content"] if encrypt_content else []
        self.table = Table(
            self.table_name,
            self.metadata,
            Column("id", Integer, primary_key=True, autoincrement=True),
            Column("user_id", String(128), index=True, nullable=False),
            Column("namespace", String(128), index=True, nullable=True),
            Column("thread_id", String(128), index=True, nullable=True),
            Column("content", Text, nullable=False),
            Column("tier", String(64), index=True, nullable=True),
            Column("score", Integer, nullable=True),
            Column("metadata", JSONB().with_variant(JSON, "sqlite"), nullable=True),
            Column("related_threads", JSONB().with_variant(JSON, "sqlite"), nullable=True),
            Column("summarized", Integer, nullable=True),  # 1=true, 0/NULL=false
            Column("created_at", DateTime, nullable=False, default=lambda: datetime.now(timezone.utc)),
            Column(
                "updated_at",
                DateTime,
                nullable=False,
                default=lambda: datetime.now(timezone.utc),
                onupdate=lambda: datetime.now(timezone.utc),
            ),
        )
        # clusters table
        from sqlalchemy import UniqueConstraint, Index
        self.clusters_table = Table(
            "memory_clusters",
            self.metadata,
            Column("cluster_id", Integer, primary_key=True, autoincrement=True),
            Column("user_id", String, nullable=False, index=True),  # Added index for performance
            Column("topic", String, nullable=False),
            Column("category", String, nullable=False),
            Column("memory_ids", JSONB().with_variant(JSON, "sqlite"), nullable=False),
            Column("summary", Text, nullable=True),
            Column("created_at", DateTime, nullable=False, default=lambda: datetime.now(timezone.utc)),
            Column("last_built_at", DateTime, nullable=True),
            # Unique constraint: one cluster per (user_id, topic, category) combination
            UniqueConstraint('user_id', 'topic', 'category', name='uq_cluster_user_topic_category'),
        )

    def create_schema_if_not_exists(self) -> None:
        self.metadata.create_all(self.engine, checkfirst=True)

    def _metadata_contains(self, metadata_dict: Dict[str, Any], filter_dict: Dict[str, Any]) -> bool:
        """Check if metadata_dict contains all key-value pairs from filter_dict (JSON containment).

        This implements PostgreSQL-style JSONB containment (@>) for Python/SQLite.
        """
        if not filter_dict:
            return True

        for key, value in filter_dict.items():
            if key not in metadata_dict:
                return False

            metadata_value = metadata_dict[key]

            # Exact match for primitives
            if isinstance(value, (str, int, float, bool, type(None))):
                if metadata_value != value:
                    return False
            # Recursive check for nested dicts
            elif isinstance(value, dict):
                if not isinstance(metadata_value, dict):
                    return False
                if not self._metadata_contains(metadata_value, value):
                    return False
            # List containment (all filter items must be in metadata list)
            elif isinstance(value, list):
                if not isinstance(metadata_value, list):
                    return False
                for item in value:
                    if item not in metadata_value:
                        return False
            else:
                # Fallback: exact match
                if metadata_value != value:
                    return False

        return True

    # CRUD Operations
    def insert_memory(
        self,
        *,
        user_id: str,
        content: str,
        thread_id: Optional[str] = None,
        tier: Optional[str] = None,
        score: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
        namespace: Optional[str] = None,
    ) -> int:
        """Insert a new memory into the database.

        Args:
            user_id: User ID (required for user isolation)
            content: Memory content
            thread_id: Optional thread ID for grouping
            tier: Storage tier (short_term, mid_term, long_term)
            score: Memory importance score (0-100). If None, defaults to 50 (medium importance)
            metadata: Optional metadata dictionary
            namespace: Optional namespace for multi-tenancy

        Returns:
            ID of the inserted memory

        Raises:
            SQLAlchemyError: If database operation fails
        """
        # Default score to 50 (medium importance) if not provided
        if score is None:
            score = 50

        # Encrypt content if encryption is enabled
        encrypted_content = self.encryptor.encrypt(content) if self.encrypt_content else content

        try:
            with self.engine.begin() as conn:
                stmt = (
                    insert(self.table)
                    .values(
                        user_id=user_id,
                        namespace=namespace,
                        thread_id=thread_id,
                        content=encrypted_content,
                        tier=tier,
                        score=score,
                        metadata=metadata,
                        created_at=datetime.now(timezone.utc),
                        updated_at=datetime.now(timezone.utc),
                    )
                    .returning(self.table.c.id)
                )
                result = conn.execute(stmt)
                new_id = result.scalar_one()
                return int(new_id)
        except SQLAlchemyError as e:
            logger.error(
                f"Failed to insert memory: {e}",
                extra={
                    "user_id": user_id,
                    "thread_id": thread_id,
                    "tier": tier,
                    "error": str(e)
                }
            )
            raise

    def get_memories(
        self,
        *,
        user_id: Optional[str] = None,
        thread_id: Optional[str] = None,
        tier: Optional[str] = None,
        where_metadata: Optional[Dict[str, Any]] = None,
        namespace: Optional[str] = None,
        related_threads_any_of: Optional[List[str]] = None,
        summarized: Optional[bool] = None,
        limit: Optional[int] = 50,
    ) -> List[Dict[str, Any]]:
        conditions: List[Any] = []
        if user_id:
            conditions.append(self.table.c.user_id == user_id)
        if namespace:
            conditions.append(self.table.c.namespace == namespace)
        if thread_id:
            conditions.append(self.table.c.thread_id == thread_id)
        if tier:
            conditions.append(self.table.c.tier == tier)

        # Handle metadata filtering with dialect awareness
        use_python_filter = False
        if where_metadata:
            if self.engine.url.get_backend_name().startswith("postgres"):
                # Use native JSONB containment for PostgreSQL
                conditions.append(self.table.c.metadata.contains(where_metadata))
            else:
                # For SQLite, we'll filter in Python after query
                use_python_filter = True

        if summarized is not None:
            if summarized:
                conditions.append((self.table.c.summarized == 1))
            else:
                conditions.append(
                    (self.table.c.summarized.is_(None)) | (self.table.c.summarized == 0)
                )
        if related_threads_any_of:
            if self.engine.url.get_backend_name().startswith("postgres"):
                # OR of JSONB array contains checks
                contains_clauses = [
                    self.table.c.related_threads.contains([t]) for t in related_threads_any_of
                ]
                if contains_clauses:
                    conditions.append(or_(*contains_clauses))
            else:
                # Fallback: match by thread_id being in the list
                conditions.append(self.table.c.thread_id.in_(related_threads_any_of))

        stmt = select(self.table)
        if conditions:
            stmt = stmt.where(and_(*conditions))

        # Don't apply limit if we need Python-level filtering
        if limit and not use_python_filter:
            stmt = stmt.limit(limit)

        with self.engine.connect() as conn:
            rows = conn.execute(stmt).mappings().all()
            results = [dict(row) for row in rows]

            # Decrypt content if encryption is enabled
            if self.encrypt_content:
                for result in results:
                    if "content" in result and result["content"]:
                        try:
                            result["content"] = self.encryptor.decrypt(result["content"])
                        except Exception as e:
                            logger.warning(
                                f"Failed to decrypt content for memory {result.get('id')}: {e}"
                            )
                            # Leave encrypted if decryption fails (wrong key or corrupted data)

            # Apply Python-level metadata filtering for SQLite
            if use_python_filter and where_metadata:
                results = [
                    r for r in results
                    if self._metadata_contains(r.get("metadata", {}), where_metadata)
                ]

            # Apply limit after Python filtering if needed
            if limit and use_python_filter:
                results = results[:limit]

            return results

    def update_tier(self, *, memory_ids: Iterable[int], new_tier: str) -> int:
        """Update the tier for multiple memories.

        Args:
            memory_ids: IDs of memories to update
            new_tier: New tier name

        Returns:
            Number of memories updated

        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with self.engine.begin() as conn:
                stmt = (
                    update(self.table)
                    .where(self.table.c.id.in_(list(memory_ids)))
                    .values(tier=new_tier, updated_at=datetime.now(timezone.utc))
                )
                result = conn.execute(stmt)
                return int(result.rowcount or 0)
        except SQLAlchemyError as e:
            logger.error(
                f"Failed to update tier: {e}",
                extra={
                    "memory_ids": list(memory_ids)[:10],  # Log first 10 IDs
                    "new_tier": new_tier,
                    "error": str(e)
                }
            )
            raise

    def mark_summarized(self, *, memory_ids: Iterable[int]) -> int:
        with self.engine.begin() as conn:
            stmt = (
                update(self.table)
                .where(self.table.c.id.in_(list(memory_ids)))
                .values(summarized=1, updated_at=datetime.now(timezone.utc))
            )
            result = conn.execute(stmt)
            return int(result.rowcount or 0)

    # Cluster CRUD
    def upsert_cluster(
        self,
        *,
        user_id: str,
        topic: str,
        category: str,
        memory_ids: List[int],
        summary: str = ""
    ) -> int:
        """Upsert a cluster for a user.

        If a cluster with the same user_id, topic, and category exists, update it.
        Otherwise, create a new cluster.

        Args:
            user_id: User ID
            topic: Topic name
            category: Category name
            memory_ids: List of memory IDs in this cluster
            summary: Optional summary text

        Returns:
            Cluster ID

        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with self.engine.begin() as conn:
                # Check if cluster exists
                stmt = select(self.clusters_table).where(
                    and_(
                        self.clusters_table.c.user_id == user_id,
                        self.clusters_table.c.topic == topic,
                        self.clusters_table.c.category == category,
                    )
                )
                existing = conn.execute(stmt).mappings().first()

                if existing:
                    # Update existing cluster
                    update_stmt = (
                        update(self.clusters_table)
                        .where(self.clusters_table.c.cluster_id == existing["cluster_id"])
                        .values(
                            memory_ids=memory_ids,
                            summary=summary,
                            last_built_at=datetime.now(timezone.utc),
                        )
                        .returning(self.clusters_table.c.cluster_id)
                    )
                    result = conn.execute(update_stmt)
                    return int(result.scalar_one())
                else:
                    # Insert new cluster
                    insert_stmt = (
                        insert(self.clusters_table)
                        .values(
                            user_id=user_id,
                            topic=topic,
                            category=category,
                            memory_ids=memory_ids,
                            summary=summary,
                            created_at=datetime.now(timezone.utc),
                            last_built_at=datetime.now(timezone.utc),
                        )
                        .returning(self.clusters_table.c.cluster_id)
                )
                result = conn.execute(insert_stmt)
                return int(result.scalar_one())
        except SQLAlchemyError as e:
            logger.error(
                f"Failed to upsert cluster: {e}",
                extra={
                    "user_id": user_id,
                    "topic": topic,
                    "category": category,
                    "error": str(e)
                }
            )
            raise

    def get_clusters(
        self,
        *,
        user_id: Optional[str] = None,
        topic: Optional[str] = None,
        category: Optional[str] = None,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """Get clusters with optional filtering."""
        conditions: List[Any] = []
        if user_id:
            conditions.append(self.clusters_table.c.user_id == user_id)
        if topic:
            conditions.append(self.clusters_table.c.topic == topic)
        if category:
            conditions.append(self.clusters_table.c.category == category)

        stmt = select(self.clusters_table)
        if conditions:
            stmt = stmt.where(and_(*conditions))
        stmt = stmt.limit(limit)

        with self.engine.connect() as conn:
            rows = conn.execute(stmt).mappings().all()
            return [dict(r) for r in rows]

    def delete_cluster(self, *, cluster_id: int) -> int:
        """Delete a cluster by ID.

        Args:
            cluster_id: Cluster ID to delete

        Returns:
            Number of rows deleted (0 or 1)

        Raises:
            SQLAlchemyError: If database operation fails
        """
        from sqlalchemy import delete
        try:
            with self.engine.begin() as conn:
                stmt = delete(self.clusters_table).where(
                    self.clusters_table.c.cluster_id == cluster_id
                )
                result = conn.execute(stmt)
                return int(result.rowcount or 0)
        except SQLAlchemyError as e:
            logger.error(
                f"Failed to delete cluster: {e}",
                extra={"cluster_id": cluster_id, "error": str(e)}
            )
            raise

    def update_content(self, *, memory_id: int, new_content: str) -> int:
        """Update the content of a memory.

        Args:
            memory_id: ID of memory to update
            new_content: New content text

        Returns:
            Number of memories updated (0 or 1)

        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with self.engine.begin() as conn:
                stmt = (
                    update(self.table)
                    .where(self.table.c.id == memory_id)
                    .values(content=new_content, updated_at=datetime.now(timezone.utc))
                )
                result = conn.execute(stmt)
                return int(result.rowcount or 0)
        except SQLAlchemyError as e:
            logger.error(
                f"Failed to update content: {e}",
                extra={"memory_id": memory_id, "error": str(e)}
            )
            raise

    def update_metadata(self, *, memory_id: int, new_metadata: Dict[str, Any]) -> int:
        """Update the metadata of a memory.

        Args:
            memory_id: ID of memory to update
            new_metadata: New metadata dictionary

        Returns:
            Number of memories updated (0 or 1)

        Raises:
            SQLAlchemyError: If database operation fails
        """
        try:
            with self.engine.begin() as conn:
                stmt = (
                    update(self.table)
                    .where(self.table.c.id == memory_id)
                    .values(metadata=new_metadata, updated_at=datetime.now(timezone.utc))
                )
                result = conn.execute(stmt)
                return int(result.rowcount or 0)
        except SQLAlchemyError as e:
            logger.error(
                f"Failed to update metadata: {e}",
                extra={"memory_id": memory_id, "error": str(e)}
            )
            raise

    def set_updated_at(self, *, memory_ids: Iterable[int], updated_at: datetime) -> int:
        with self.engine.begin() as conn:
            stmt = (
                update(self.table)
                .where(self.table.c.id.in_(list(memory_ids)))
                .values(updated_at=updated_at)
            )
            result = conn.execute(stmt)
            return int(result.rowcount or 0)

    # Thread helpers
    def set_related_threads(self, *, memory_id: int, related_threads: List[str]) -> int:
        with self.engine.begin() as conn:
            stmt = (
                update(self.table)
                .where(self.table.c.id == memory_id)
                .values(related_threads=related_threads, updated_at=datetime.now(timezone.utc))
            )
            result = conn.execute(stmt)
            return int(result.rowcount or 0)

    def link_threads_by_topic(self, user_id: str, topic: str) -> List[str]:
        """Get all thread_ids for a user that share a specific topic.

        This enables topic-scoped retrieval by finding all threads
        that contain memories with the given topic.

        Args:
            user_id: User ID to search within
            topic: Topic to match

        Returns:
            List of thread_ids that have memories with this topic
        """
        # Check if we're using PostgreSQL (has native JSONB support)
        is_postgres = self.engine.url.get_backend_name().startswith("postgres")

        if is_postgres:
            # Use native JSONB containment
            stmt = (
                select(self.table.c.thread_id)
                .distinct()
                .where(
                    and_(
                        self.table.c.user_id == user_id,
                        self.table.c.metadata.contains({"topic": topic})
                    )
                )
            )
            with self.engine.connect() as conn:
                rows = conn.execute(stmt).scalars().all()
                return [r for r in rows if r]
        else:
            # For SQLite, fetch all and filter in Python
            stmt = select(self.table.c.thread_id, self.table.c.metadata).where(
                self.table.c.user_id == user_id
            )
            with self.engine.connect() as conn:
                rows = conn.execute(stmt).all()
                thread_ids = set()
                for thread_id, metadata in rows:
                    if thread_id and metadata and metadata.get("topic") == topic:
                        thread_ids.add(thread_id)
                return list(thread_ids)

    def distinct_threads(
        self, *, user_id: Optional[str] = None, tier: Optional[str] = None, limit: int = 1000
    ) -> List[str]:
        stmt = select(self.table.c.thread_id).distinct()
        conditions: List[Any] = []
        if user_id:
            conditions.append(self.table.c.user_id == user_id)
        if tier:
            conditions.append(self.table.c.tier == tier)
        if conditions:
            stmt = stmt.where(and_(*conditions))
        stmt = stmt.limit(limit)
        with self.engine.connect() as conn:
            rows = conn.execute(stmt).all()
            return [r[0] for r in rows if r[0]]

    # Policy helpers
    def count_by_tier(self) -> Dict[str, int]:
        stmt = select(self.table.c.tier, func.count()).group_by(self.table.c.tier)
        with self.engine.connect() as conn:
            rows = conn.execute(stmt).all()
            return {str(tier): int(count) for tier, count in rows}

    def find_older_than(
        self, *, days: int, from_tier: Optional[str] = None, limit: int = 1000
    ) -> List[Dict[str, Any]]:
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
        conditions = [self.table.c.updated_at < cutoff]
        if from_tier:
            conditions.append(self.table.c.tier == from_tier)
        stmt = select(self.table).where(and_(*conditions)).limit(limit)
        with self.engine.connect() as conn:
            rows = conn.execute(stmt).mappings().all()
            return [dict(r) for r in rows]
