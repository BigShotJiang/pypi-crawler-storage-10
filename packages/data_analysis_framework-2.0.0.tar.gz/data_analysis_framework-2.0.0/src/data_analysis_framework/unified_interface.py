"""Unified interface compatibility layer for data-analysis-framework.

This module provides a consistent interface wrapper that ensures all analysis
results have the same access patterns regardless of the underlying implementation.
"""

from typing import Dict, Any, Optional, List
from analysis_framework_base import UnifiedAnalysisResult as BaseUnifiedAnalysisResult


class UnifiedAnalysisResult(BaseUnifiedAnalysisResult):
    """Wrapper to provide consistent interface for data-analysis-framework results.

    This class extends the base UnifiedAnalysisResult and adapts structured data
    analysis results to the common interface.

    This class provides:
    - Dictionary-style access: result['key']
    - Attribute access: result.key
    - Consistent method interface: result.to_dict()
    """

    def __init__(self, data_analysis_result: Dict[str, Any]):
        """Initialize with a data analysis result dictionary.

        Args:
            data_analysis_result: The raw analysis result from DataAnalyzer.analyze_file()
        """
        # Store raw result for backward compatibility
        self._raw = data_analysis_result

        # Extract values for base class initialization
        document_type = self._extract_document_type(data_analysis_result)
        confidence = self._extract_confidence(data_analysis_result)
        metadata = self._extract_metadata(data_analysis_result)
        content = self._extract_content(data_analysis_result)
        ai_opportunities = self._extract_ai_opportunities(data_analysis_result)

        # Initialize base class
        super().__init__(
            document_type=document_type,
            confidence=confidence,
            framework='data-analysis-framework',
            metadata=metadata,
            content=content,
            ai_opportunities=ai_opportunities,
            raw_analysis=data_analysis_result
        )

    def _extract_document_type(self, result: Dict[str, Any]) -> str:
        """Extract document type from raw result."""
        if isinstance(result, dict) and 'data_type' in result:
            data_type_obj = result['data_type']
            if hasattr(data_type_obj, 'type_name'):
                type_name = data_type_obj.type_name
                type_map = {
                    'excel': 'Excel Spreadsheet',
                    'csv': 'CSV Data',
                    'json': 'JSON Data',
                    'sql': 'SQL Database',
                    'parquet': 'Parquet Data',
                    'xml': 'XML Data'
                }
                return type_map.get(type_name, f'{type_name.title()} Data')
            elif isinstance(data_type_obj, dict):
                type_name = data_type_obj.get('type_name', 'unknown')
                return f'{type_name.title()} Data'
        return 'unknown'

    def _extract_confidence(self, result: Dict[str, Any]) -> float:
        """Extract confidence from raw result."""
        if 'analysis' in result:
            analysis_obj = result['analysis']
            if hasattr(analysis_obj, 'quality_score'):
                return float(analysis_obj.quality_score)
            elif isinstance(analysis_obj, dict) and 'quality_score' in analysis_obj:
                return float(analysis_obj['quality_score'])
        return 0.8  # Default confidence for structured data

    def _extract_metadata(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """Extract metadata from raw result."""
        metadata = {}

        # Add file metadata
        if 'file_path' in result:
            metadata['file_path'] = result['file_path']

        # Add data type metadata
        if 'data_type' in result:
            data_type_obj = result['data_type']
            if hasattr(data_type_obj, 'tables_count'):
                metadata['tables_count'] = data_type_obj.tables_count
            if hasattr(data_type_obj, 'total_rows'):
                metadata['total_rows'] = data_type_obj.total_rows
            if hasattr(data_type_obj, 'total_columns'):
                metadata['total_columns'] = data_type_obj.total_columns
            if hasattr(data_type_obj, 'file_size_mb'):
                metadata['file_size_mb'] = data_type_obj.file_size_mb
            if hasattr(data_type_obj, 'sheets_or_tables') and data_type_obj.sheets_or_tables:
                metadata['sheets_or_tables'] = data_type_obj.sheets_or_tables
            if hasattr(data_type_obj, 'encoding'):
                metadata['encoding'] = data_type_obj.encoding

        # Add analysis metadata
        if 'analysis' in result:
            analysis_obj = result['analysis']
            if hasattr(analysis_obj, 'completeness_ratio'):
                metadata['completeness_ratio'] = analysis_obj.completeness_ratio
            if hasattr(analysis_obj, 'query_complexity'):
                metadata['query_complexity'] = analysis_obj.query_complexity

        # Add AI readiness
        if 'ai_readiness' in result:
            metadata['ai_readiness'] = result['ai_readiness']

        return metadata

    def _extract_content(self, result: Dict[str, Any]) -> str:
        """Extract content summary from raw result."""
        content_parts = []

        if 'data_type' in result:
            data_type_obj = result['data_type']
            # Use _extract_document_type instead of self.document_type (not initialized yet)
            doc_type = self._extract_document_type(result)
            content_parts.append(f"Data Type: {doc_type}")

            if hasattr(data_type_obj, 'total_rows') and hasattr(data_type_obj, 'total_columns'):
                content_parts.append(f"Shape: {data_type_obj.total_rows} rows × {data_type_obj.total_columns} columns")

            if hasattr(data_type_obj, 'column_types') and data_type_obj.column_types:
                content_parts.append(f"Columns: {', '.join(list(data_type_obj.column_types.keys())[:5])}")
                if len(data_type_obj.column_types) > 5:
                    content_parts.append(f"... and {len(data_type_obj.column_types) - 5} more columns")

        if 'analysis' in result:
            analysis_obj = result['analysis']
            if hasattr(analysis_obj, 'detected_patterns') and analysis_obj.detected_patterns:
                content_parts.append(f"Patterns: {', '.join(analysis_obj.detected_patterns[:3])}")
            if hasattr(analysis_obj, 'business_metrics') and analysis_obj.business_metrics:
                content_parts.append(f"Metrics: {len(analysis_obj.business_metrics)} business metrics detected")

        return '\n'.join(content_parts) if content_parts else 'No content summary available'

    def _extract_ai_opportunities(self, result: Dict[str, Any]) -> List[str]:
        """Extract AI opportunities from raw result."""
        opportunities = []

        # Get from analysis.recommended_operations
        if 'analysis' in result:
            analysis_obj = result['analysis']
            if hasattr(analysis_obj, 'recommended_operations'):
                opportunities.extend(analysis_obj.recommended_operations)
            elif isinstance(analysis_obj, dict) and 'recommended_operations' in analysis_obj:
                opportunities.extend(analysis_obj['recommended_operations'])

        # Add from agent_capabilities
        if 'agent_capabilities' in result and isinstance(result['agent_capabilities'], list):
            opportunities.extend(result['agent_capabilities'])

        # Add generic opportunities based on data type
        if not opportunities and 'data_type' in result:
            data_type_obj = result['data_type']
            if hasattr(data_type_obj, 'type_name'):
                type_name = data_type_obj.type_name
                if type_name in ['excel', 'csv']:
                    opportunities = [
                        'Data profiling and quality assessment',
                        'Statistical analysis and visualization',
                        'Anomaly detection',
                        'Predictive modeling'
                    ]
                elif type_name == 'json':
                    opportunities = [
                        'Schema validation',
                        'Data transformation',
                        'API integration',
                        'Configuration management'
                    ]

        return opportunities

    # Backward compatibility methods for _raw access
    def __getattr__(self, name):
        """Proxy attribute access to the raw object for backward compatibility."""
        # First check if it's in the raw dict
        if hasattr(self, '_raw') and isinstance(self._raw, dict) and name in self._raw:
            return self._raw[name]
        # Otherwise raise AttributeError
        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'") 