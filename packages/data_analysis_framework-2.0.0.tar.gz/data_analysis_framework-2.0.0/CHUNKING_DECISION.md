# Chunking Interface Decision for Data Analysis Framework

## Decision: Not Implementing BaseChunker

The `data-analysis-framework` v2.0.0 inherits from `BaseAnalyzer` but intentionally **does not** implement `BaseChunker` from `analysis-framework-base`.

## Rationale

### Different Paradigm: Query-Based vs Document-Based

The data-analysis-framework serves a fundamentally different purpose than document-based frameworks:

**Document Frameworks (xml, docling, document):**
- Process documents for RAG/LLM consumption
- Break content into semantic chunks for vector embeddings
- Focus on text extraction and context preservation
- Use case: "Chunk this technical manual for semantic search"

**Data Framework (data-analysis):**
- Provides safe AI agent access to structured data
- Uses natural language queries to interact with databases/tables
- Focuses on data profiling, schema detection, and query generation
- Use case: "Find all customers with revenue > $10M in Q4"

### AgentQueryInterface Instead of Chunking

This framework implements `AgentQueryInterface` which provides:

```python
# Query-based interaction (data-analysis-framework)
interface = create_agent_interface("sales_data.xlsx")
result = interface.execute_query("Show top 10 products by revenue")
report = interface.generate_report(result, "Sales Analysis")

# vs. Chunk-based interaction (document frameworks)
chunks = chunk("manual.pdf", strategy="hierarchical")
embeddings = embed_chunks(chunks)
```

### Key Differences

| Aspect | Document Frameworks | Data Framework |
|--------|-------------------|----------------|
| **Input** | Unstructured documents | Structured data (tables, DBs) |
| **Output** | Text chunks for embedding | Query results and insights |
| **AI Integration** | RAG, semantic search | Natural language SQL/queries |
| **Processing** | Extract → Chunk → Embed | Profile → Query → Analyze |
| **Use Case** | "Search the manual for X" | "Show me customers where Y" |

## Implementation Status

### ✅ Implemented from analysis-framework-base:
- `BaseAnalyzer` - Provides consistent analysis interface
- `UnifiedAnalysisResult` - Standard result format across frameworks
- `get_supported_formats()` - Format discovery

### ❌ Not Implemented (by design):
- `BaseChunker` - Not applicable to structured data paradigm
- `chunk_document()` - Replaced by `AgentQueryInterface.execute_query()`
- `get_supported_strategies()` - Query strategies instead of chunking strategies

## Complementary Frameworks

The data-analysis-framework complements the document frameworks:

- **Document Processing**: Use xml/docling/document frameworks to chunk technical documentation, PDFs, Office docs
- **Data Access**: Use data-analysis-framework to let AI agents query databases, spreadsheets, and configuration files
- **Combined Solution**: Document frameworks for knowledge base + data framework for operational data access

## Future Considerations

If query result chunking becomes necessary (e.g., for very large result sets), we would:

1. Create `ResultChunker` class separate from document chunking
2. Focus on table row/column pagination rather than semantic chunking
3. Maintain clear separation between document chunks and data partitions
4. Consider implementing if user demand warrants

## Summary

This is not a missing feature - it's an intentional architectural decision. The data-analysis-framework uses a **query-based paradigm** that is complementary to, not a replacement for, the **chunk-based paradigm** of document frameworks.

Both approaches are valid for AI integration and serve different purposes in the analysis framework suite.
