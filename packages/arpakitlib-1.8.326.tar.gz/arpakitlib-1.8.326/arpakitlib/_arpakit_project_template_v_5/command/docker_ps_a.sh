cd ..
docker ps -a