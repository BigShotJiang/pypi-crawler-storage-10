cd ..
git remote -v