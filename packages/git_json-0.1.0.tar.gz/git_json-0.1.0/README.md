# git-json
[![codecov](https://codecov.io/github/unenv/git-json/graph/badge.svg?token=0QQ7JROLWL)](https://codecov.io/github/unenv/git-json)

A Python tool to generate comprehensive git information for your projects.

## Installation

```bash
pip install git-json
```

## Usage

### Command Line

```bash
# Generate git info to default 'resources' directory
git-json

# Generate git info to custom directory
git-json --package-path my-resources
```

### Python API

```python
from git_json import GitJsonGenerator

generator = GitJsonGenerator()
generator.generate_git_json("output-directory")
```

## Output

Generates a `git.json` file with comprehensive git information including:

- Branch information
- Commit details (hash, message, author, time)
- Build information (host, time, user)
- Repository status (dirty, ahead/behind)
- Tags and version information

## Development

```bash
# Install dependencies
poetry install --with dev

# Run tests
poetry run pytest

# Run linting
poetry run ruff check .

# Generate git info
poetry run git-json
```