#!/usr/bin/env python3

import argparse
from .generator import GitJsonGenerator

def main():
    """Generate git info."""
    parser = argparse.ArgumentParser(description="Generate git info")
    parser.add_argument("--package-path", default="resources", 
                       help="Package path for git info output (default: resources)")
    args = parser.parse_args()
    
    generator = GitJsonGenerator()
    generator.generate_git_json(args.package_path)

if __name__ == "__main__":
    main()