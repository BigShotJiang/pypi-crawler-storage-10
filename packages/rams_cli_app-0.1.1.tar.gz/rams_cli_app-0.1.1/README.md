# rams-cli-app

A sample Python CLI package that prints a greeting using your name.

## Usage

After installation, run:

    mycli Ram --greet
