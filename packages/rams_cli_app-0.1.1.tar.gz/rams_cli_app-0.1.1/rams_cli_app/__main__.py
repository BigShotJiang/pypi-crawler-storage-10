import argparse

def main():
    parser = argparse.ArgumentParser(description="A simple Ram's CLI app")
    parser.add_argument("name", help="Your name")
    parser.add_argument("--greet", action="store_true", help="Print greeting")
    args = parser.parse_args()
    if args.greet:
        print(f"Hello, {args.name}!")

if __name__ == "__main__":
    main()
