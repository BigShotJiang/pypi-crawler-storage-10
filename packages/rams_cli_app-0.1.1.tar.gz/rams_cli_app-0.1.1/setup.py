from setuptools import setup, find_packages

setup(
    name="rams-cli-app",
    version="0.1.1",
    packages=find_packages(),
    entry_points={
        'console_scripts': [
            'mycli=rams_cli_app.__main__:main',
        ],
    },
    description="A sample CLI app",
    author="Ram",
    python_requires=">=3.7",
)
