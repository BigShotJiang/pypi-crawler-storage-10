The files in this directory are licensed with the 3-clause BSD license.
This is done to be consistent with the license used by the SDF C and FORTRAN
libraries. This applies to all versions of the SDF utilities dating back
to 2010.
