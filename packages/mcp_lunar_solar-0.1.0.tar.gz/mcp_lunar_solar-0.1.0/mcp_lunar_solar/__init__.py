from mcp.server.fastmcp import FastMCP
from zhdate import ZhDate
from datetime import datetime  # 统一使用datetime类型

mcp = FastMCP(name="LunarSolarBridge")

@mcp.tool()
def solar_to_lunar(year: int, month: int, day: int) -> dict:
    """将阳历（公历）日期转换为阴历（农历）日期"""
    try:
        solar_date = datetime(year, month, day)
        lunar_date = ZhDate.from_datetime(solar_date)
        
        # 直接访问底层私有属性_leap（兼容绝大多数版本）
        return {
            "lunar_year": lunar_date.lunar_year,
            "lunar_month": lunar_date.lunar_month,
            "lunar_day": lunar_date.lunar_day,
            "chinese_repr": lunar_date.chinese()
        }
    except Exception as e:
        return {"error": f"转换失败：{str(e)}"}

@mcp.tool()
def lunar_to_solar(year: int, month: int, day: int, is_leap: bool = False) -> dict:
    """将阴历（农历）日期转换为阳历（公历）日期"""
    try:
        # 创建农历对象时，参数名统一用is_leap，内部处理兼容
        lunar_date = ZhDate(year, month, day, is_leap)
        solar_date = lunar_date.to_datetime()
        return {
            "solar_year": solar_date.year,
            "solar_month": solar_date.month,
            "solar_day": solar_date.day,
            "weekday": solar_date.weekday()
        }
    except Exception as e:
        return {"error": f"转换失败：{str(e)}"}

def main():
    print(f"{mcp.name} 服务启动成功")
    print("支持功能：阳历转阴历、阴历转阳历")

if __name__ == "__main__":
    main()
    # print(solar_to_lunar(1988,11,23))
    mcp.run(transport='stdio')