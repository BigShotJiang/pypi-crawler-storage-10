import argparse
from server import mcp


def main():
    """MCP 计算器服务器：提供计算功能的 MCP 服务器"""
    # 创建命令行参数解析器
    parser = argparse.ArgumentParser(
        description="提供文档解析功能的 MCP (Model Context Protocol) 服务器"
    )
    # 解析命令行参数（当前没有定义具体参数）
    parser.parse_args()

    # 启动 MCP 服务器
    mcp.run()


# 当直接运行此文件时，执行主函数
if __name__ == "__main__":
    main()