from setuptools import setup, find_packages

setup(
    name="seds_lab3",
    version="0.1.0",
    author="Safou",
    description="A project for SEDS Lab 3 using rockets, shuttles, and circle calculations.",
    packages=find_packages(),
    install_requires=[],
    include_package_data=True,
    python_requires=">=3.8",
)