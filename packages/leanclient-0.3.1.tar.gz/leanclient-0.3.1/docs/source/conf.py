# Configuration file for the Sphinx documentation builder.

# Project information

project = "leanclient"
copyright = "2025, Oliver Dressler"
author = "Oliver Dressler"

release = "0.1"
version = "0.1.0"

# General configuration

extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "sphinx.ext.autosummary",
    "sphinx.ext.intersphinx",
]

intersphinx_mapping = {
    "python": ("https://docs.python.org/3/", None),
    "sphinx": ("https://www.sphinx-doc.org/en/master/", None),
}
intersphinx_disabled_domains = ["std"]

templates_path = ["_templates"]

# Options for HTML output

html_theme = "sphinx_rtd_theme"

# Options for EPUB output
epub_show_urls = "footnote"
