"""Benchmark tests package."""
