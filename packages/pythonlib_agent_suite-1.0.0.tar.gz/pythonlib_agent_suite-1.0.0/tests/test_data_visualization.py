import unittest
from src.data_visualization import plot_line, plot_histogram

class TestDataVisualization(unittest.TestCase):
    def test_plot_line(self):
        # Sadece fonksiyonun hata vermemesi test edilir
        plot_line([1, 2], [3, 4])

    def test_plot_histogram(self):
        plot_histogram([1, 2, 2, 3])

if __name__ == "__main__":
    unittest.main()
