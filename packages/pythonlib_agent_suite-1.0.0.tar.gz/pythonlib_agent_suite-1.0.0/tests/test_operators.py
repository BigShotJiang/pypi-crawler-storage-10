import unittest

class TestOperators(unittest.TestCase):
    def test_arithmetic(self):
        self.assertEqual(10 + 3, 13)
        self.assertEqual(10 % 3, 1)
    def test_comparison(self):
        self.assertTrue(10 > 3)
        self.assertFalse(10 < 3)
    def test_logical(self):
        self.assertTrue((10 > 5) and (3 < 5))
        self.assertTrue((10 > 5) or (3 > 5))
        self.assertTrue(not (10 < 3))

if __name__ == "__main__":
    unittest.main()
