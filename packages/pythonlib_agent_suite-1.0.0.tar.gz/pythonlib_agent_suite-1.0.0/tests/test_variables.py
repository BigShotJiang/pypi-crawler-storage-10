import unittest
from src import variables

class TestVariables(unittest.TestCase):
    def test_number_variable(self):
        x = 5
        self.assertEqual(x, 5)
    def test_string_variable(self):
        name = "Ali"
        self.assertEqual(name, "Ali")

if __name__ == "__main__":
    unittest.main()
