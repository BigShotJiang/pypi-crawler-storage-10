import unittest
from src.error_handling_debugging import safe_divide

class TestErrorHandlingDebugging(unittest.TestCase):
    def test_safe_divide_zero(self):
        self.assertEqual(safe_divide(0), float('inf'))

    def test_safe_divide_normal(self):
        self.assertEqual(safe_divide(2), 5.0)

if __name__ == "__main__":
    unittest.main()
