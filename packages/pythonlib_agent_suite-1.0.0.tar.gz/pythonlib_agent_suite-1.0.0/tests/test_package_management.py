import unittest
from src.package_management import install_package
import importlib

class TestPackageManagement(unittest.TestCase):
    def test_install_package(self):
        # 'requests' should be installed
        install_package('requests')
        self.assertIsNotNone(importlib.util.find_spec('requests'))

if __name__ == "__main__":
    unittest.main()
