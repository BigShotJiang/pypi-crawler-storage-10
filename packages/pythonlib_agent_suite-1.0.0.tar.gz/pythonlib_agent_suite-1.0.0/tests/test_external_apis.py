import unittest
from src.external_apis import get_github_status

class TestExternalAPIs(unittest.TestCase):
    def test_get_github_status(self):
        status = get_github_status()
        self.assertIsInstance(status, int)
        self.assertTrue(100 <= status < 600)

if __name__ == "__main__":
    unittest.main()
