import unittest
from src.oop import Araba, SporAraba

class TestOOP(unittest.TestCase):
    def test_araba(self):
        araba = Araba("Renault")
        self.assertEqual(araba.marka, "Renault")

    def test_spor_araba_inheritance(self):
        spor_araba = SporAraba("Ferrari")
        self.assertEqual(spor_araba.marka, "Ferrari")
        self.assertIsInstance(spor_araba, Araba)

if __name__ == "__main__":
    unittest.main()
