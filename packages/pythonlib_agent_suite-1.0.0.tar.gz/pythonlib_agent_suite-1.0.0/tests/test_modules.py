import unittest
import selam

class TestModules(unittest.TestCase):
    def test_selamla(self):
        # Test if selamla prints something (basic test)
        import io
        import sys
        captured = io.StringIO()
        sys.stdout = captured
        selam.selamla()
        sys.stdout = sys.__stdout__
        self.assertIn("Merhaba!", captured.getvalue())

if __name__ == "__main__":
    unittest.main()
