import unittest
from src.advanced_data_structures import stack_example, queue_example

class TestAdvancedDataStructures(unittest.TestCase):
    def test_stack_example(self):
        self.assertEqual(stack_example(), 2)

    def test_queue_example(self):
        self.assertEqual(queue_example(), 1)

if __name__ == "__main__":
    unittest.main()
