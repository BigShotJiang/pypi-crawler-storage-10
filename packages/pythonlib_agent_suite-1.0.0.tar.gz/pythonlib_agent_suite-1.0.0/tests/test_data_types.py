import unittest

class TestDataTypes(unittest.TestCase):
    def test_int(self):
        self.assertIsInstance(10, int)
    def test_float(self):
        self.assertIsInstance(3.14, float)
    def test_str(self):
        self.assertIsInstance("Hello", str)
    def test_bool(self):
        self.assertIsInstance(True, bool)
    def test_list(self):
        self.assertIsInstance([1,2,3], list)
    def test_tuple(self):
        self.assertIsInstance((1,2,3), tuple)
    def test_dict(self):
        self.assertIsInstance({"name": "Ali"}, dict)
    def test_set(self):
        self.assertIsInstance({1,2,3}, set)

if __name__ == "__main__":
    unittest.main()
