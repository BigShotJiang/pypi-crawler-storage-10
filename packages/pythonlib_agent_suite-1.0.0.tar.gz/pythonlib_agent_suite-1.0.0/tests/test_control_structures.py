import unittest

class TestControlStructures(unittest.TestCase):
    def test_if_else(self):
        x = 10
        result = "x büyük" if x > 5 else "x küçük veya eşit"
        self.assertEqual(result, "x büyük")
    def test_for_loop(self):
        numbers = []
        for i in range(1, 11):
            numbers.append(i)
        self.assertEqual(numbers, list(range(1, 11)))

if __name__ == "__main__":
    unittest.main()
