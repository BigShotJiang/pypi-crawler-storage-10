import unittest
from src.functional_programming import square_numbers, filter_even, sum_numbers

class TestFunctionalProgramming(unittest.TestCase):
    def test_square_numbers(self):
        self.assertEqual(square_numbers([1, 2, 3]), [1, 4, 9])

    def test_filter_even(self):
        self.assertEqual(filter_even([1, 2, 3, 4]), [2, 4])

    def test_sum_numbers(self):
        self.assertEqual(sum_numbers([1, 2, 3, 4]), 10)

if __name__ == "__main__":
    unittest.main()
