import unittest

class TestExceptions(unittest.TestCase):
    def test_value_error(self):
        try:
            int("abc")
        except ValueError:
            self.assertTrue(True)
        else:
            self.fail("ValueError bekleniyordu!")

if __name__ == "__main__":
    unittest.main()
