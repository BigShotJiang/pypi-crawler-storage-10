"""Mixin for tools that need file support."""

import logging
from typing import Dict, Tuple, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from codemie_tools.base.file_object import FileObject

logger = logging.getLogger(__name__)


class FileToolMixin:
    """Mixin for tools that work with files via config.input_files."""

    def _resolve_files(self) -> Dict[str, Tuple[bytes, str]]:
        """
        Get files from config, validate them, and return name->(content, mime_type) mapping.

        Returns:
            Dictionary mapping file names to tuples of (content, mime_type)
        """
        input_files = []
        if hasattr(self, 'config') and self.config and hasattr(self.config, 'input_files'):
            input_files = self.config.input_files or []

        logger.debug(f"Resolving files from config. Total files available: {len(input_files)}")

        result = {}
        for file_obj in input_files:
            try:
                logger.debug(f"Processing file: {file_obj.name}, type: {type(file_obj)}, mime_type: {file_obj.mime_type}")
                content = file_obj.bytes_content()
                logger.debug(f"File '{file_obj.name}' content retrieved: {len(content) if content else 0} bytes")

                if content:
                    result[file_obj.name] = (content, file_obj.mime_type)
                else:
                    logger.warning(f"File '{file_obj.name}' has no content, excluding from processing")
            except Exception as e:
                logger.warning(f"Failed to get content for file '{file_obj.name}': {e}, excluding from processing", exc_info=True)

        logger.debug(f"Successfully resolved {len(result)} files: {list(result.keys())}")
        return result

    def _filter_requested_files(self, all_files: Dict[str, Tuple[bytes, str]], params_dict: dict) -> Dict[str, Tuple[bytes, str]]:
        """
        Filter files based on file names specified in params.

        Args:
            all_files: Dictionary of all available files
            params_dict: Parsed params dict that may contain file names

        Returns:
            Filtered dictionary of requested files, or all files if no specific files requested
        """
        logger.debug(f"Filtering requested files. Available files: {list(all_files.keys())}, params_dict: {params_dict}")

        requested_file_names = []
        if "file" in params_dict:
            file_param = params_dict["file"]
            if isinstance(file_param, list):
                requested_file_names = file_param
            else:
                requested_file_names = [file_param]
        elif "files" in params_dict:
            files_param = params_dict["files"]
            if isinstance(files_param, list):
                requested_file_names = files_param
            else:
                requested_file_names = [files_param]

        logger.debug(f"Requested file names from params: {requested_file_names}")

        if not requested_file_names:
            logger.debug("No specific files requested, returning all files")
            return all_files

        filtered_files = {}
        for file_name in requested_file_names:
            if file_name in all_files:
                filtered_files[file_name] = all_files[file_name]
                logger.debug(f"Matched requested file: {file_name}")
            else:
                logger.warning(f"Requested file '{file_name}' not found in available files: {list(all_files.keys())}")

        result = filtered_files if filtered_files else all_files
        logger.debug(f"Filtered result: {len(result)} files - {list(result.keys())}")
        return result
