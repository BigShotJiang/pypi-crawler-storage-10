default_app_config = 'django_softdelete.apps.DjangoSoftDeleteConfig'
