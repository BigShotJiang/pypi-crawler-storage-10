import pytest

def test_placeholder():
    """Dieser Test macht immer OK."""
    assert True