import cv2
from .image_processing import ShapeDetector


def main():
    img = cv2.imread("tests/img/test_image_00.png")
    cv2.imshow("Original", img)

    detector = ShapeDetector()
    [img_out, detected] = detector.detect(img)

    print(detected)
    cv2.imshow("Result", img_out)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
