"""This package provides a class for detecting and labeling geometric shapes in images.

Modules
-------
shape_detector   :  Defines the 'ShapeDetector' class for detecting and labeling shapes in images.
"""

from .shape_detector import ShapeDetector

__all__ = ["ShapeDetector"]
