"""This package provides different classes for detecting geometric shapes in images using OpenCV.

Modules
-------
triangle    :  Defines the 'Triangle' class for detecting triangles.
circle      :  Defines the 'Circle' class for detecting circles.
rectangle   :  Defines the 'Rectangle' class for detecting rectangles.
square      :  Defines the 'Square' class for detecting squares.
shape       :  Defines the abstract base class `Shape`, providing common functionality.
"""

from .shape import Shape
from .rectangle import Rectangle
from .square import Square
from .triangle import Triangle
from .circle import Circle

__all__ = ["Shape", "Rectangle", "Square", "Triangle", "Circle"]
