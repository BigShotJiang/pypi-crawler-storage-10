"""Module with an abstract base class for geometric shape detection in an image using OpenCV.

This module defines the 'Shape' abstract base class, which serves as the foundation
for specific shape detectors such as 'Circle', 'Triangle' or 'Rectangle'. It provides
common functionality for detecting and labeling geometric shapes in images, including:

- Drawing shape contours and text labels on an image.
- Detecting the dominant color of each shape region using predefined HSV color ranges.
- Providing a structured interface for extending new shape types.

Classes
-------
Shape
    Abstract base class defining shared behavior for all shape types.
"""

from abc import ABC, abstractmethod
import cv2
import numpy as np
from ._color_config import hsv_ranges


class Shape(ABC):
    """Abstract base class for geometric shape detection in an image using OpenCV.

    This class provides common functionality for all shape types, such as:
    - Drawing detected contours on an image.
    - Detecting the dominant color within a shape.
    - Storing metadata like the shape's name and detected color.

    Subclasses (e.g., 'Circle', 'Triangle', 'Rectangle') must implement
    the 'matches' method to define how the specific shape is recognized.

    Parameters
    ----------
    name : str
        The name of the shape (e.g., "Circle", "Square").

    Attributes
    ----------
    _name : str
        The name of the shape (e.g., "Circle", "Square").
    _color : str
        The color of the shape
    """

    def __init__(self, name: str) -> None:
        self._name = name
        self._color = "UNKNOWN"

    def get_name(self) -> str:
        """Get the name of the shape.

        Returns
        -------
        str
            Name of the shape.
        """
        return f"{self._name}"

    def get_color(self) -> str:
        """Get the color of the shape.

        Returns
        -------
        str
            Color of the shape.
        """
        return f"{self._color}"

    def draw(self, image: cv2.typing.MatLike, approx: cv2.typing.MatLike) -> None:
        """Draw the detected shape contour and its label (color + name) in the image.

        Parameters
        ----------
        image : cv2.typing.MatLike
            The image on which to draw.
        approx : cv2.typing.MatLike
            The approximated contour points of the shape.

        Notes
        -----
        The shape is drawn in green, the text label is drawn in red and
        placed slightly above the bounding box of the contour.
        """
        cv2.drawContours(image, [approx], 0, (0, 255, 0), 2)
        x, y, _, _ = cv2.boundingRect(approx)
        cv2.putText(
            image,
            f"{self.get_color()} {self.get_name()}",
            (x, y - 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 0, 255),
            1,
            cv2.LINE_AA,
        )

    def detect_color(
        self, image: cv2.typing.MatLike, approx: cv2.typing.MatLike
    ) -> None:
        """Detect the dominant color within the shape area using predefined ranges.

        The method performs the following steps:
        - Creates a mask from the shape contour.
        - Converts the image to HSV color space.
        - Counts pixels within each predefined HSV color range.
        - Determines the dominant color by maximum pixel count.

        Parameters
        ----------
        image : cv2.typing.MatLike
            The image in BGR color space.
        approx : cv2.typing.MatLike
            The approximated contour points of the shape.

        Notes
        -----
        If no significant color is found, the color is set to "UNKNOWN".
        The color thresholds are stored in a seperate file _color_config.py.
        """
        mask = np.zeros(image.shape[:2], dtype=np.uint8)
        cv2.drawContours(mask, [approx], 0, 255, thickness=cv2.FILLED)

        hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        hsv_roi = cv2.bitwise_and(hsv_image, hsv_image, mask=mask)

        color_counts = {}
        for color, (lower, upper) in hsv_ranges.items():
            mask_color = cv2.inRange(hsv_roi, lower, upper)
            count = cv2.countNonZero(mask_color)
            color_counts[color] = count

        if len(color_counts) == 0 or max(color_counts.values()) == 0:
            detected_color = "UNKNOWN"
        else:
            detected_color = max(color_counts, key=lambda c: color_counts[c])
            if detected_color in ("RED0", "RED1"):
                detected_color = "RED"

        self._color = detected_color

    @abstractmethod
    def matches(self, contour: cv2.typing.MatLike, approx: cv2.typing.MatLike) -> bool:
        """Determine whether the given contour matches the specific shape type.

        This method must be implemented by all subclasses.

        Parameters
        ----------
        contour : cv2.typing.MatLike
            The contour detected in the image.
        approx : cv2.typing.MatLike
            The approximated contour points.

        Returns
        -------
        bool
            True if the contour corresponds to this shape type, False otherwise.
        """
