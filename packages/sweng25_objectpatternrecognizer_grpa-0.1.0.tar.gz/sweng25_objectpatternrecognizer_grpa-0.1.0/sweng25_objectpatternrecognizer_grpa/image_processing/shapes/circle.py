"""Module with a class for circle shape detection in an image using OpenCV.

This module provides the 'Circle' class, a subclass of 'Shape', which
implements detection logic specific to circles in images using OpenCV.

Classes
-------
Circle
    Detects circular shapes in images by analyzing contours.
"""

import cv2
from .shape import Shape


class Circle(Shape):
    """Class for circle shape detection in an image using OpenCV.

    Subclass of 'Shape' representing a circle. It implements the 'matches' method
    to determine whether a given contour corresponds to a circle.

    Parameters
    ----------
    name : str
        The name of the shape, default: Circle.
    """

    def __init__(self):
        super().__init__(name="Circle")

    def matches(self, contour: cv2.typing.MatLike, approx: cv2.typing.MatLike) -> bool:
        return len(approx) > 10
