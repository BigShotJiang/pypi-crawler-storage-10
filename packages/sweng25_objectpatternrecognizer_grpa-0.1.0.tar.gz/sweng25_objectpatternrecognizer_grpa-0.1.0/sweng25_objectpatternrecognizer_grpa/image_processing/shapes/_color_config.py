"""Defines the ranges for different colors in the HSV-colorspace

Attributes
----------
hsv_ranges : dict
    The ranges for different colors in the HSV-colorspace.
"""

import numpy as np

hsv_ranges = {
    "RED0": (np.array([0, 70, 50]), np.array([10, 255, 255])),
    "RED1": (np.array([170, 70, 50]), np.array([180, 255, 255])),
    "GREEN": (np.array([25, 52, 72]), np.array([102, 255, 255])),
    "BLUE": (np.array([94, 120, 120]), np.array([120, 255, 255])),
    "YELLOW": (np.array([15, 150, 20]), np.array([35, 255, 255])),
    "VIOLET": (np.array([130, 100, 100]), np.array([160, 255, 255])),
}
