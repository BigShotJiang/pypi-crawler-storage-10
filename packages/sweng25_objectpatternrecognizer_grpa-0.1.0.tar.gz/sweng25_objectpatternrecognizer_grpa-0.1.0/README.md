# SWENG25_ObjectPatternRecognizer_GrpA

A small Python application that uses a camera livestream to perform real-time object pattern recognition and color detection.  
The main purpose of this project is to **practice software engineering principles**.

From our perspective, this includes:
1. Collaborating as a team on a shared software project using a version control system (Git/GitHub).
2. Writing proper documentation that is clear, structured, and maintainable.
3. Implementing unit tests to ensure code quality and reliability.

---

## Installation and Usage

These instructions explain how to set up the environment and run the application.  
We recommend using **Visual Studio Code (VS Code)** as the development environment, since the steps below refer to its interface.

### Requirements

#### Extensions
Make sure the following VS Code extensions are installed:
- **Mypy** – for static type checking  
- **Pylint** – for code linting and style checks  
- **Black Formatter** – for automatic code formatting  

To enable automatic formatting on save, open your VS Code settings and set:
```json
"editor.formatOnSave": true
```

---

### Setting Up the Virtual Environment

We use **venv**, which comes preinstalled with Python. This ensures compatibility across all systems.

Follow these steps to create and activate the virtual environment:

1. Open the project folder in VS Code.  
2. Open the integrated terminal (`Ctrl+`` or via *View > Terminal*).  
3. Run the following commands:

   ```bash
   python -m venv venv
   .\venv\Scripts\activate
   pip install -r requirements.txt
   ```

---

### Updating the Virtual Environment

If you install new packages (e.g., using `pip install package_name`), remember to update the `requirements.txt` file so teammates can reproduce your environment.

```bash
pip freeze > requirements.txt
```

---

### Notes

- Make sure Python is added to your system PATH.  
- If you encounter issues activating the virtual environment on Windows, run PowerShell as an administrator and use:
  ```bash
  Set-ExecutionPolicy RemoteSigned
  ```
- For macOS/Linux, activate the environment with:
  ```bash
  source venv/bin/activate
  ```

## Development Process and Community Rules:
### responsibility
Lenny: config, log, sources, output
Sascha: Main, ImgProc
Fabian: CICD, GUI, DOC

### Branching
main-Branch \
development-Branch \
feature-Branch \
doc-Branch

### Pull-Requests
due to small project and learn process one creats pull-request, second person aproves by coment and third aproves realy.




and state how you work and which rules to you
have
## Repository Structure: 
introduce your folder structure, which folder contains what.
## Features: 
tate which awesome features this project contains
## Architecture: 
We will learn how to document the architecture in a separate lecture
## Additionals: 
Placeholder for all the other project related stuff