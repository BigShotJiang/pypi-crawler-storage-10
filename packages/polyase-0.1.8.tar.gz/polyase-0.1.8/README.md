
![potatoesaregreat](polyase_diagramm.png)
# Polyase

A Python package for analyzing allele-specific expression in polyploid organisms.

## Installation

You can install polyase using pip:
pip install polyase==0.1.8





Pyranges must be installed manually for reading GTF files.


