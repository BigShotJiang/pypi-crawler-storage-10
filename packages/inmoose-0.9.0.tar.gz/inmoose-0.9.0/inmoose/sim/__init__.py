from .splat import sim_rnaseq as sim_rnaseq
