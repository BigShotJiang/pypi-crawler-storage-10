#!/usr/bin/env python
from jdDesktopEntryEdit import main
main()
