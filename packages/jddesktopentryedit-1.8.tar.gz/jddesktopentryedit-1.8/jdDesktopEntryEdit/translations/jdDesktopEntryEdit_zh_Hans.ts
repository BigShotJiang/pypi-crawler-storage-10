<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_Hans">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../ui/AboutDialog.ui" line="0"/>
        <location filename="../ui/AboutDialog.ui" line="0"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../ui/AboutDialog.ui" line="0"/>
        <source>A graphical Program to create and edit Desktop Entries</source>
        <translation>创建和编辑桌面条目的图形化程序</translation>
    </message>
    <message>
        <location filename="../ui/AboutDialog.ui" line="0"/>
        <source>The Icon was created by &lt;a href=&quot;https://icon-icons.com/icon/preferences-desktop-theme/93638&quot;&gt;Papirus Development Team&lt;/a&gt;</source>
        <translation>图标由 &lt;a href=&quot;https://icon-icons.com/icon/preferences-desktop-theme/93638&quot;&gt;Papirus 开发团队&lt;/a&gt;创建</translation>
    </message>
    <message>
        <location filename="../ui/AboutDialog.ui" line="0"/>
        <source>This Program is licensed under GPL 3</source>
        <translation>本程序采用 GPL 3 许可</translation>
    </message>
    <message>
        <location filename="../ui/AboutDialog.ui" line="0"/>
        <source>Translators</source>
        <translation>翻译人员</translation>
    </message>
    <message>
        <location filename="../ui/AboutDialog.ui" line="0"/>
        <source>The following people translated jdDesktopEntryEdit:</source>
        <translation>以下人员翻译了 jdDesktopEntryEdit：</translation>
    </message>
    <message>
        <location filename="../ui/AboutDialog.ui" line="0"/>
        <source>Changelog</source>
        <translation>更新日志</translation>
    </message>
    <message>
        <location filename="../ui/AboutDialog.ui" line="0"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
</context>
<context>
    <name>EditActionDialog</name>
    <message>
        <location filename="../EditActionDialog.py" line="35"/>
        <source>Identifier empty</source>
        <translation>标识符为空</translation>
    </message>
    <message>
        <location filename="../EditActionDialog.py" line="35"/>
        <source>The Identifier can&apos;t be empty</source>
        <translation>标识符不能为空</translation>
    </message>
    <message>
        <location filename="../EditActionDialog.py" line="40"/>
        <source>Invalid Identifier</source>
        <translation>无效的标识符</translation>
    </message>
    <message>
        <location filename="../EditActionDialog.py" line="40"/>
        <source>This Identifier is not valid</source>
        <translation>此标识符无效</translation>
    </message>
    <message>
        <location filename="../EditActionDialog.py" line="44"/>
        <source>Identifier exists</source>
        <translation>标识符已存在</translation>
    </message>
    <message>
        <location filename="../EditActionDialog.py" line="44"/>
        <source>This Identifier already exists</source>
        <translation>此标识符已存在</translation>
    </message>
    <message>
        <location filename="../ui/EditActionDialog.ui" line="0"/>
        <source>Identifier:</source>
        <translation>标识符：</translation>
    </message>
    <message>
        <location filename="../ui/EditActionDialog.ui" line="0"/>
        <source>Name:</source>
        <translation>名称：</translation>
    </message>
    <message>
        <location filename="../ui/EditActionDialog.ui" line="0"/>
        <source>Translate</source>
        <translation>翻译</translation>
    </message>
    <message>
        <location filename="../ui/EditActionDialog.ui" line="0"/>
        <source>Icon:</source>
        <translation>图标：</translation>
    </message>
    <message>
        <location filename="../ui/EditActionDialog.ui" line="0"/>
        <source>Exec:</source>
        <translation>执行：</translation>
    </message>
</context>
<context>
    <name>EditKeywordsTranslationDialog</name>
    <message>
        <location filename="../EditKeywordsTranslationDialog.py" line="24"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../EditKeywordsTranslationDialog.py" line="25"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../EditKeywordsTranslationDialog.py" line="34"/>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="../EditKeywordsTranslationDialog.py" line="53"/>
        <source>No Language</source>
        <translation>无语言</translation>
    </message>
    <message>
        <location filename="../EditKeywordsTranslationDialog.py" line="53"/>
        <source>You have to enter a Language</source>
        <translation>您必须输入一种语言</translation>
    </message>
    <message>
        <location filename="../EditKeywordsTranslationDialog.py" line="58"/>
        <source>Language exists</source>
        <translation>语言已存在</translation>
    </message>
    <message>
        <location filename="../EditKeywordsTranslationDialog.py" line="58"/>
        <source>This Language already exists</source>
        <translation>此语言已存在</translation>
    </message>
    <message>
        <location filename="../EditKeywordsTranslationDialog.py" line="77"/>
        <source>Add new Keywords translation</source>
        <translation>添加新的关键词翻译</translation>
    </message>
    <message>
        <location filename="../EditKeywordsTranslationDialog.py" line="79"/>
        <source>Edit Keywords for {{language}}</source>
        <translation>编辑 {{language}} 的关键词</translation>
    </message>
</context>
<context>
    <name>Functions</name>
    <message>
        <location filename="../Functions.py" line="139"/>
        <source>{{module}} not installed</source>
        <translation>{{module}} 未安装</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="139"/>
        <source>Optional module {{module}} not found. It is required to use this Feature.</source>
        <translation>未找到可选模块 {{module}}。此功能需要该模块。</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="150"/>
        <source>Invalid URL</source>
        <translation>无效的 URL</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="150"/>
        <source>The given URL is not valid</source>
        <translation>给定的 URL 无效</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="153"/>
        <source>Invalid Schema</source>
        <translation>无效的架构</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="153"/>
        <source>Only http and https are supported</source>
        <translation>仅支持 http 和 https</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="156"/>
        <source>Could not connect</source>
        <translation>无法连接</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="156"/>
        <source>Could not connect to the Website</source>
        <translation>无法连接到网站</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="159"/>
        <source>Unknown Error</source>
        <translation>未知错误</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="159"/>
        <source>An unknown Error happened while trying to conenct to the given URL</source>
        <translation>尝试连接到给定的 URL 时发生未知错误</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="163"/>
        <source>Could not get data</source>
        <translation>无法获取数据</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="163"/>
        <source>Could not get data from the URL</source>
        <translation>无法从 URL 获取数据</translation>
    </message>
</context>
<context>
    <name>Language</name>
    <message>
        <location filename="../Languages.py" line="6"/>
        <source>English</source>
        <translation>英语</translation>
    </message>
    <message>
        <location filename="../Languages.py" line="7"/>
        <source>German</source>
        <translation>德语</translation>
    </message>
    <message>
        <location filename="../Languages.py" line="8"/>
        <source>Dutch</source>
        <translation>荷兰语</translation>
    </message>
    <message>
        <location filename="../Languages.py" line="9"/>
        <source>Turkish</source>
        <translation>土耳其语</translation>
    </message>
    <message>
        <location filename="../Languages.py" line="10"/>
        <source>Chinese (Simplified)</source>
        <translation>中文（简体）</translation>
    </message>
</context>
<context>
    <name>ListEditWidget</name>
    <message>
        <location filename="../ListEditWidget.py" line="24"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="../ListEditWidget.py" line="25"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="../ListEditWidget.py" line="26"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <location filename="../ListEditWidget.py" line="68"/>
        <location filename="../ListEditWidget.py" line="62"/>
        <source>Add Item</source>
        <translation>添加项目</translation>
    </message>
    <message>
        <location filename="../ListEditWidget.py" line="69"/>
        <location filename="../ListEditWidget.py" line="63"/>
        <source>Please enter a new Item</source>
        <translation>请输入新项目</translation>
    </message>
    <message>
        <location filename="../ListEditWidget.py" line="103"/>
        <location filename="../ListEditWidget.py" line="75"/>
        <source>Item in List</source>
        <translation>列表中的项目</translation>
    </message>
    <message>
        <location filename="../ListEditWidget.py" line="103"/>
        <location filename="../ListEditWidget.py" line="75"/>
        <source>This Item is already in the List</source>
        <translation>此项目已在列表中</translation>
    </message>
    <message>
        <location filename="../ListEditWidget.py" line="95"/>
        <location filename="../ListEditWidget.py" line="89"/>
        <source>Edit Item</source>
        <translation>编辑项目</translation>
    </message>
    <message>
        <location filename="../ListEditWidget.py" line="96"/>
        <location filename="../ListEditWidget.py" line="90"/>
        <source>Please edit the Item</source>
        <translation>请编辑项目</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../MainWindow.py" line="50"/>
        <source>A list of MimeTypes that this Application can open</source>
        <translation>此应用程序可以打开的 MIME 类型列表</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="51"/>
        <source>The untranslated Keywords</source>
        <translation>未翻译的关键词</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="52"/>
        <source>A list of interfaces that this application implements. If you don&apos;t know what this means, you probably won&apos;t need it.</source>
        <translation>此应用程序实现的接口列表。如果您不知道这意味着什么，您可能不需要它。</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="53"/>
        <source>If set, the Application is only visible when using this Desktop Environments</source>
        <translation>如果设置，则应用程序仅在使用此桌面环境时可见</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="54"/>
        <source>The Application is not visible when using this Desktop Environments</source>
        <translation>在使用此桌面环境时，应用程序不可见</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="70"/>
        <source>Application</source>
        <translation>应用程序</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="71"/>
        <source>Link</source>
        <translation>链接</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="72"/>
        <source>Directory</source>
        <translation>目录</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="73"/>
        <source>Service</source>
        <translation>服务</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="168"/>
        <source>Unsaved changes</source>
        <translation>未保存的更改</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="168"/>
        <source>You have unsaved changes. Do you want to save now?</source>
        <translation>您有未保存的更改。是否要立即保存？</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="180"/>
        <source>Untitled</source>
        <translation>无标题</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="196"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="211"/>
        <source>No templates found</source>
        <translation>未找到模板</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="234"/>
        <source>No recent files</source>
        <translation>无最近文件</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="247"/>
        <source>Clear</source>
        <translation>清除</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="297"/>
        <location filename="../MainWindow.py" line="270"/>
        <source>Desktop Entries</source>
        <translation>桌面条目</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="314"/>
        <location filename="../MainWindow.py" line="297"/>
        <location filename="../MainWindow.py" line="270"/>
        <source>All Files</source>
        <translation>所有文件</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="283"/>
        <source>Open URL</source>
        <translation>打开 URL</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="283"/>
        <source>Please enter the URL to the Desktop Entry</source>
        <translation>请输入桌面条目的 URL</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="310"/>
        <source>All Images</source>
        <translation>所有图片</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="311"/>
        <source>PNG Images</source>
        <translation>PNG 图片</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="312"/>
        <source>SVG Images</source>
        <translation>SVG 图片</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="313"/>
        <source>XPM Images</source>
        <translation>XPM 图片</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="353"/>
        <source>Add a Categorie</source>
        <translation>添加类别</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="353"/>
        <source>Please select a Categorie from the list below</source>
        <translation>请从下方列表中选择类别</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="357"/>
        <source>Categorie already added</source>
        <translation>类别已添加</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="357"/>
        <source>You can&apos;t add the same Categorie twice</source>
        <translation>您不能重复添加相同的类别</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="399"/>
        <source>Delete Keywords translation</source>
        <translation>删除关键词翻译</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="399"/>
        <source>Are you really want to delete {{language}}?</source>
        <translation>是否确定要删除 {{language}}？</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="416"/>
        <source>Add Action</source>
        <translation>添加操作</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="416"/>
        <source>Please enter the identifier for the new Action</source>
        <translation>请输入新操作的标识符</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="422"/>
        <source>Invalid Identifier</source>
        <translation>无效的标识符</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="422"/>
        <source>This Identifier is not valid</source>
        <translation>此标识符无效</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="426"/>
        <source>Identifier exists</source>
        <translation>标识符已存在</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="426"/>
        <source>This Identifier already exists</source>
        <translation>此标识符已存在</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="450"/>
        <source>Delete Action</source>
        <translation>删除操作</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="450"/>
        <source>Are you really want to delete {{identifier}}?</source>
        <translation>是否确定要删除 {{identifier}}？</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../MainWindow.py" line="475"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="497"/>
        <source>Invalid Key</source>
        <translation>无效的键</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="497"/>
        <source>{{key}} is not a valid custom Key</source>
        <translation>{{key}} 不是有效的自定义键</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="501"/>
        <source>Everything valid</source>
        <translation>一切有效</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="501"/>
        <source>No issues found</source>
        <translation>未找到问题</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="520"/>
        <source>File not found</source>
        <translation>未找到文件</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="520"/>
        <source>{{path}} was not found</source>
        <translation>未找到 {{path}}</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="551"/>
        <location filename="../MainWindow.py" line="524"/>
        <source>Error loading Desktop Entry</source>
        <translation>加载桌面条目时出错</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="551"/>
        <location filename="../MainWindow.py" line="524"/>
        <source>This Desktop Entry couldn&apos;t be loaded. Make sure, it is in the right format.</source>
        <translation>无法加载此桌面条目，请确保格式正确。</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>General</source>
        <translation>常规</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Type:</source>
        <translation>类型：</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Name:</source>
        <translation>名称：</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>GenericName:</source>
        <translation>通用名称：</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Comment:</source>
        <translation>注释：</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Icon:</source>
        <translation>图标：</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Exec:</source>
        <translation>执行：</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Browse</source>
        <translation>浏览</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>TryExec:</source>
        <translation>尝试执行：</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Path:</source>
        <translation>路径：</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>StartupWMClass:</source>
        <translation>启动窗口类：</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Don&apos;t display in Menu (NoDisplay)</source>
        <translation>不要在菜单中显示（NoDisplay）</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Hide Desktop Entry (Hidden)</source>
        <translation>隐藏桌面条目（Hidden）</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Can be activated with D-Bus (DBusActivatable)</source>
        <translation>可以用 D-Bus 激活（DBusActivatable）</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Run in a Terminal (Terminal)</source>
        <translation>在终端中运行（Terminal）</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Send a Message when started (StartupNotify)</source>
        <translation>启动时发送消息（StartupNotify）</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Run on a more powerful discrete GPU if available (PrefersNonDefaultGPU)</source>
        <translation>如果可用，在性能更强的独立显卡上运行（PrefersNonDefaultGPU）</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Program has a single main window (SingleMainWindow)</source>
        <translation>程序有单一主窗口（SingleMainWindow）</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Translate</source>
        <translation>翻译</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Categories</source>
        <translation>类别</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>MimeType</source>
        <translation>MIME 类型</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Keywords</source>
        <translation>关键词</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Untranslated</source>
        <translation>未翻译</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Translated</source>
        <translation>已翻译</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>A List of Languages in which are the Keywords translated</source>
        <translation>已翻译的关键词的语言列表</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Actions</source>
        <translation>操作</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Implements</source>
        <translation>实现</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>OnlyShowIn</source>
        <translation>仅显示在</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>NotShowIn</source>
        <translation>不显示在</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Custom</source>
        <translation>自定义</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>All Custom Keys of your Desktop Entry. Make sure the Keys starts with X-.</source>
        <translation>您的桌面条目的所有自定义键。确保键以 X- 开头。</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Key</source>
        <translation>键</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Value</source>
        <translation>值</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Check</source>
        <translation>检查</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Open recent</source>
        <translation>最近打开</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>New (from Template)</source>
        <translation>新（来自模板）</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Tools</source>
        <translation>工具</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>New</source>
        <translation>新</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Save as...</source>
        <translation>另存为…</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Exit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Validate</source>
        <translation>验证</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Desktop Entry Specification</source>
        <translation>桌面条目规范</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>About Qt</source>
        <translation>关于 Qt</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Manage templates</source>
        <translation>管理模板</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Open from URL</source>
        <translation>从 URL 打开</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Show Welcome Dialog</source>
        <translation>显示欢迎对话框</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>View Source</source>
        <translation>查看源代码</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Report Bug</source>
        <translation>报告错误</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Donate</source>
        <translation>捐赠</translation>
    </message>
</context>
<context>
    <name>ManageTemplatesWindow</name>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="68"/>
        <location filename="../ManageTemplatesWindow.py" line="47"/>
        <source>Enter name</source>
        <translation>输入名称</translation>
    </message>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="47"/>
        <source>This will save your current document as template. Please enter a name.</source>
        <translation>这会将您当前的文档作为模板保存。请输入名称。</translation>
    </message>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="74"/>
        <location filename="../ManageTemplatesWindow.py" line="53"/>
        <source>Name exists</source>
        <translation>名称已存在</translation>
    </message>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="74"/>
        <location filename="../ManageTemplatesWindow.py" line="53"/>
        <source>There is already a template with this name</source>
        <translation>已存在同名模板</translation>
    </message>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="68"/>
        <source>Please enter the new name</source>
        <translation>请输入新名称</translation>
    </message>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="100"/>
        <location filename="../ManageTemplatesWindow.py" line="83"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="83"/>
        <source>A error occurred while renaming</source>
        <translation>重命名时出错</translation>
    </message>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="93"/>
        <source>Delete {{name}}</source>
        <translation>删除 {{name}}</translation>
    </message>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="93"/>
        <source>Are you sure you want to delete {{name}}?</source>
        <translation>是否确定要删除 {{name}}？</translation>
    </message>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="100"/>
        <source>A error occurred while deleting</source>
        <translation>删除时出错</translation>
    </message>
    <message>
        <location filename="../ui/ManageTemplatesWindow.ui" line="0"/>
        <source>Manage templates</source>
        <translation>管理模板</translation>
    </message>
    <message>
        <location filename="../ui/ManageTemplatesWindow.ui" line="0"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../ui/ManageTemplatesWindow.ui" line="0"/>
        <source>Rename</source>
        <translation>重命名</translation>
    </message>
    <message>
        <location filename="../ui/ManageTemplatesWindow.ui" line="0"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="../ui/ManageTemplatesWindow.ui" line="0"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
</context>
<context>
    <name>PreviewDialog</name>
    <message>
        <location filename="../ui/PreviewDialog.ui" line="0"/>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <location filename="../ui/PreviewDialog.ui" line="0"/>
        <source>Preview of your desktop entry</source>
        <translation>您的桌面条目的预览</translation>
    </message>
    <message>
        <location filename="../ui/PreviewDialog.ui" line="0"/>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../ui/PreviewDialog.ui" line="0"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../SettingsDialog.py" line="36"/>
        <source>System language</source>
        <translation>系统语言</translation>
    </message>
    <message>
        <location filename="../SettingsDialog.py" line="41"/>
        <source>Nothing</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../SettingsDialog.py" line="42"/>
        <source>Filename</source>
        <translation>文件名</translation>
    </message>
    <message>
        <location filename="../SettingsDialog.py" line="43"/>
        <source>Path</source>
        <translation>路径</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Language:</source>
        <translation>语言：</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>(needs restart)</source>
        <translation>（需要重启）</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Length of recent files list:</source>
        <translation>最近文件列表的长度：</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Window title:</source>
        <translation>窗口标题：</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Ask before closing unsaved File</source>
        <translation>关闭未保存的文件前询问</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Show in Title if File is edited</source>
        <translation>如果文件已编辑，则在标题中显示</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Add comment to Files</source>
        <translation>向文件添加注释</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Remove extra spaces when saving</source>
        <translation>保存时移除多余空格</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>TranslateDialog</name>
    <message>
        <location filename="../ui/TranslateDialog.ui" line="0"/>
        <location filename="../TranslateDialog.py" line="38"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <location filename="../TranslateDialog.py" line="54"/>
        <source>No Language</source>
        <translation>无语言</translation>
    </message>
    <message>
        <location filename="../TranslateDialog.py" line="54"/>
        <source>You had no Language for at least one Item</source>
        <translation>您至少有一个项目没有语言</translation>
    </message>
    <message>
        <location filename="../TranslateDialog.py" line="58"/>
        <source>Language double</source>
        <translation>语言重复</translation>
    </message>
    <message>
        <location filename="../TranslateDialog.py" line="58"/>
        <source>{{Language}} appears twice or more times in the table</source>
        <translation>{{Language}} 在表格中出现两次或两次以上</translation>
    </message>
    <message>
        <location filename="../ui/TranslateDialog.ui" line="0"/>
        <source>Translate</source>
        <translation>翻译</translation>
    </message>
    <message>
        <location filename="../ui/TranslateDialog.ui" line="0"/>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="../ui/TranslateDialog.ui" line="0"/>
        <source>Translation</source>
        <translation>翻译</translation>
    </message>
    <message>
        <location filename="../ui/TranslateDialog.ui" line="0"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="../ui/TranslateDialog.ui" line="0"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../ui/TranslateDialog.ui" line="0"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>ValidationDialog</name>
    <message>
        <location filename="../ValidationDialog.py" line="22"/>
        <source>Errors:</source>
        <translation>错误：</translation>
    </message>
    <message>
        <location filename="../ValidationDialog.py" line="24"/>
        <source>Future errors:</source>
        <translation>潜在错误：</translation>
    </message>
    <message>
        <location filename="../ValidationDialog.py" line="26"/>
        <source>Warnings:</source>
        <translation>警告：</translation>
    </message>
    <message>
        <location filename="../ValidationDialog.py" line="28"/>
        <source>Hint:</source>
        <translation>提示：</translation>
    </message>
    <message>
        <location filename="../ValidationDialog.py" line="36"/>
        <source>desktop-file-validate was not found</source>
        <translation>未找到 desktop-file-validate</translation>
    </message>
    <message>
        <location filename="../ValidationDialog.py" line="44"/>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../ui/ValidationDialog.ui" line="0"/>
        <source>Validate</source>
        <translation>验证</translation>
    </message>
    <message>
        <location filename="../ui/ValidationDialog.ui" line="0"/>
        <source>The Box below shows the output of desktop-file-validate</source>
        <translation>下框显示了 desktop-file-validate 的输出</translation>
    </message>
</context>
<context>
    <name>WelcomeDialog</name>
    <message>
        <location filename="../ui/WelcomeDialog.ui" line="0"/>
        <source>Welcome</source>
        <translation>欢迎</translation>
    </message>
    <message>
        <location filename="../ui/WelcomeDialog.ui" line="0"/>
        <source>Welcome to jdDesktopEntryEdit!</source>
        <translation>欢迎使用 jdDesktopEntryEdit！</translation>
    </message>
    <message>
        <location filename="../ui/WelcomeDialog.ui" line="0"/>
        <source>This Program allows you to create and edit Desktop Entries according to the Freedesktop Specification.</source>
        <translation>本程序允许您根据 Freedesktop 规范创建和编辑桌面条目。</translation>
    </message>
    <message>
        <location filename="../ui/WelcomeDialog.ui" line="0"/>
        <source>Unlike other Programs, which try to make things easy by implementing only the main parts, the Goal of jdDesktopEntryEdit is to support the full specification. Thefore, it is expected to read the Specification before using this Program.</source>
        <translation>与其他仅实现主要部分以简化操作的程序不同，jdDesktopEntryEdit 的目标是支持完整的规范。因此，在使用本程序之前，请先阅读规范。</translation>
    </message>
    <message>
        <location filename="../ui/WelcomeDialog.ui" line="0"/>
        <source>You can view the Specification at ?&gt;Destop Entry Specification.</source>
        <translation>您可以通过“？&gt; 桌面条目规范”查看规范。</translation>
    </message>
    <message>
        <location filename="../ui/WelcomeDialog.ui" line="0"/>
        <source>You can validate your Desktop Entry at Tools&gt;Validate.</source>
        <translation>您可以通过“工具”&gt;“验证”验证您的桌面条目。</translation>
    </message>
    <message>
        <location filename="../ui/WelcomeDialog.ui" line="0"/>
        <source>Show this Dialog on Startup</source>
        <translation>启动时显示此对话框</translation>
    </message>
</context>
</TS>
