<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nl">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../ui/AboutDialog.ui" line="0"/>
        <location filename="../ui/AboutDialog.ui" line="0"/>
        <source>About</source>
        <translation>Over</translation>
    </message>
    <message>
        <location filename="../ui/AboutDialog.ui" line="0"/>
        <source>A graphical Program to create and edit Desktop Entries</source>
        <translation>Een programma om .desktopbestanden mee te maken en bewerken</translation>
    </message>
    <message>
        <location filename="../ui/AboutDialog.ui" line="0"/>
        <source>The Icon was created by &lt;a href=&quot;https://icon-icons.com/icon/preferences-desktop-theme/93638&quot;&gt;Papirus Development Team&lt;/a&gt;</source>
        <translation>Het pictogram is gemaakt door het &lt;a href=&quot;https://icon-icons.com/icon/preferences-desktop-theme/93638&quot;&gt;Papirus-ontwikkelaarsteam&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../ui/AboutDialog.ui" line="0"/>
        <source>This Program is licensed under GPL 3</source>
        <translation>Dit programma is uitgebracht onder de GPL3-licentie</translation>
    </message>
    <message>
        <location filename="../ui/AboutDialog.ui" line="0"/>
        <source>Translators</source>
        <translation>Vertalers</translation>
    </message>
    <message>
        <location filename="../ui/AboutDialog.ui" line="0"/>
        <source>The following people translated jdDesktopEntryEdit:</source>
        <translation>Deze mensen hebben jdDesktopEntryEdit vertaald:</translation>
    </message>
    <message>
        <location filename="../ui/AboutDialog.ui" line="0"/>
        <source>Changelog</source>
        <translation>Wĳzigingslog</translation>
    </message>
    <message>
        <location filename="../ui/AboutDialog.ui" line="0"/>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
</context>
<context>
    <name>EditActionDialog</name>
    <message>
        <location filename="../EditActionDialog.py" line="35"/>
        <source>Identifier empty</source>
        <translation>Blanco identificatie</translation>
    </message>
    <message>
        <location filename="../EditActionDialog.py" line="35"/>
        <source>The Identifier can&apos;t be empty</source>
        <translation>De identificatie mag niet blanco zĳn</translation>
    </message>
    <message>
        <location filename="../EditActionDialog.py" line="40"/>
        <source>Invalid Identifier</source>
        <translation>Ongeldige identificatie</translation>
    </message>
    <message>
        <location filename="../EditActionDialog.py" line="40"/>
        <source>This Identifier is not valid</source>
        <translation>De identificatie is ongeldig</translation>
    </message>
    <message>
        <location filename="../EditActionDialog.py" line="44"/>
        <source>Identifier exists</source>
        <translation>Identificatie in gebruik</translation>
    </message>
    <message>
        <location filename="../EditActionDialog.py" line="44"/>
        <source>This Identifier already exists</source>
        <translation>Deze identificatie is al in gebruik</translation>
    </message>
    <message>
        <location filename="../ui/EditActionDialog.ui" line="0"/>
        <source>Identifier:</source>
        <translation>Identificatie:</translation>
    </message>
    <message>
        <location filename="../ui/EditActionDialog.ui" line="0"/>
        <source>Name:</source>
        <translation>Naam:</translation>
    </message>
    <message>
        <location filename="../ui/EditActionDialog.ui" line="0"/>
        <source>Translate</source>
        <translation>Vertalen</translation>
    </message>
    <message>
        <location filename="../ui/EditActionDialog.ui" line="0"/>
        <source>Icon:</source>
        <translation>Pictogram:</translation>
    </message>
    <message>
        <location filename="../ui/EditActionDialog.ui" line="0"/>
        <source>Exec:</source>
        <translation>Opdracht:</translation>
    </message>
</context>
<context>
    <name>EditKeywordsTranslationDialog</name>
    <message>
        <location filename="../EditKeywordsTranslationDialog.py" line="24"/>
        <source>OK</source>
        <translation>Oké</translation>
    </message>
    <message>
        <location filename="../EditKeywordsTranslationDialog.py" line="25"/>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
    <message>
        <location filename="../EditKeywordsTranslationDialog.py" line="34"/>
        <source>Language</source>
        <translation>Taal</translation>
    </message>
    <message>
        <location filename="../EditKeywordsTranslationDialog.py" line="53"/>
        <source>No Language</source>
        <translation>Geen taal</translation>
    </message>
    <message>
        <location filename="../EditKeywordsTranslationDialog.py" line="53"/>
        <source>You have to enter a Language</source>
        <translation>Voer een taal in</translation>
    </message>
    <message>
        <location filename="../EditKeywordsTranslationDialog.py" line="58"/>
        <source>Language exists</source>
        <translation>Taal in gebruik</translation>
    </message>
    <message>
        <location filename="../EditKeywordsTranslationDialog.py" line="58"/>
        <source>This Language already exists</source>
        <translation>Deze taal is al in gebruik</translation>
    </message>
    <message>
        <location filename="../EditKeywordsTranslationDialog.py" line="77"/>
        <source>Add new Keywords translation</source>
        <translation>Trefwoordvertalingen invoeren</translation>
    </message>
    <message>
        <location filename="../EditKeywordsTranslationDialog.py" line="79"/>
        <source>Edit Keywords for {{language}}</source>
        <translation>Trefwoorden van {{language}} bewerken</translation>
    </message>
</context>
<context>
    <name>Functions</name>
    <message>
        <location filename="../Functions.py" line="139"/>
        <source>{{module}} not installed</source>
        <translation>{{module}} is niet geïnstalleerd</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="139"/>
        <source>Optional module {{module}} not found. It is required to use this Feature.</source>
        <translation>De optionele module ‘{{module}}’ is niet aangetroffen. Deze module is vereist om deze functie te kunnen gebruiken.</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="150"/>
        <source>Invalid URL</source>
        <translation>Ongeldige url</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="150"/>
        <source>The given URL is not valid</source>
        <translation>Deze opgegeven url is ongeldig</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="153"/>
        <source>Invalid Schema</source>
        <translation>Ongeldig schema</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="153"/>
        <source>Only http and https are supported</source>
        <translation>Alleen http en https zĳn geldig</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="156"/>
        <source>Could not connect</source>
        <translation>Geen verbinding mogelĳk</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="156"/>
        <source>Could not connect to the Website</source>
        <translation>Er kan geen verbinding met de website worden gemaakt</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="159"/>
        <source>Unknown Error</source>
        <translation>Onbekende foutmelding</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="159"/>
        <source>An unknown Error happened while trying to conenct to the given URL</source>
        <translation>Er is een onbekende foutmelding opgetreden tĳdens het verbinden met de opgegeven url</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="163"/>
        <source>Could not get data</source>
        <translation>Geen gegevens opgehaald</translation>
    </message>
    <message>
        <location filename="../Functions.py" line="163"/>
        <source>Could not get data from the URL</source>
        <translation>Er kunnen geen gegevens van de url worden opgehaald</translation>
    </message>
</context>
<context>
    <name>Language</name>
    <message>
        <location filename="../Languages.py" line="6"/>
        <source>English</source>
        <translation>Engels</translation>
    </message>
    <message>
        <location filename="../Languages.py" line="7"/>
        <source>German</source>
        <translation>Duits</translation>
    </message>
    <message>
        <location filename="../Languages.py" line="8"/>
        <source>Dutch</source>
        <translation>Nederlands</translation>
    </message>
    <message>
        <location filename="../Languages.py" line="9"/>
        <source>Turkish</source>
        <translation>Turks</translation>
    </message>
    <message>
        <location filename="../Languages.py" line="10"/>
        <source>Chinese (Simplified)</source>
        <translation>Chinees (Vereenvoudigd)</translation>
    </message>
</context>
<context>
    <name>ListEditWidget</name>
    <message>
        <location filename="../ListEditWidget.py" line="24"/>
        <source>Add</source>
        <translation>Toevoegen</translation>
    </message>
    <message>
        <location filename="../ListEditWidget.py" line="25"/>
        <source>Edit</source>
        <translation>Bewerken</translation>
    </message>
    <message>
        <location filename="../ListEditWidget.py" line="26"/>
        <source>Remove</source>
        <translation>Verwĳderen</translation>
    </message>
    <message>
        <location filename="../ListEditWidget.py" line="68"/>
        <location filename="../ListEditWidget.py" line="62"/>
        <source>Add Item</source>
        <translation>Item toevoegen</translation>
    </message>
    <message>
        <location filename="../ListEditWidget.py" line="69"/>
        <location filename="../ListEditWidget.py" line="63"/>
        <source>Please enter a new Item</source>
        <translation>Geef het nieuwe item een naam</translation>
    </message>
    <message>
        <location filename="../ListEditWidget.py" line="103"/>
        <location filename="../ListEditWidget.py" line="75"/>
        <source>Item in List</source>
        <translation>Item op lĳst</translation>
    </message>
    <message>
        <location filename="../ListEditWidget.py" line="103"/>
        <location filename="../ListEditWidget.py" line="75"/>
        <source>This Item is already in the List</source>
        <translation>Dit item staat al op de lĳst</translation>
    </message>
    <message>
        <location filename="../ListEditWidget.py" line="95"/>
        <location filename="../ListEditWidget.py" line="89"/>
        <source>Edit Item</source>
        <translation>Item bewerken</translation>
    </message>
    <message>
        <location filename="../ListEditWidget.py" line="96"/>
        <location filename="../ListEditWidget.py" line="90"/>
        <source>Please edit the Item</source>
        <translation>Bewerk het item</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../MainWindow.py" line="50"/>
        <source>A list of MimeTypes that this Application can open</source>
        <translation>Een lĳst met mimetypes die dit programma kan openen</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="51"/>
        <source>The untranslated Keywords</source>
        <translation>Onvertaalde trefwoorden</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="52"/>
        <source>A list of interfaces that this application implements. If you don&apos;t know what this means, you probably won&apos;t need it.</source>
        <translation>Een lĳst met interfaces die dit programma gebruikt. Als u niet weet wat dit inhoudt, dan kunt u deze optie negeren.</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="53"/>
        <source>If set, the Application is only visible when using this Desktop Environments</source>
        <translation>Stel in om het programma alleen in deze werkomgevingen te tonen</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="54"/>
        <source>The Application is not visible when using this Desktop Environments</source>
        <translation>Dit programma wordt niet in deze werkomgevingen getoond</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="70"/>
        <source>Application</source>
        <translation>Programma</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="71"/>
        <source>Link</source>
        <translation>Link</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="72"/>
        <source>Directory</source>
        <translation>Map</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="73"/>
        <source>Service</source>
        <translation>Dienst</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="168"/>
        <source>Unsaved changes</source>
        <translation>Niet-opgeslagen wĳzigingen</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="168"/>
        <source>You have unsaved changes. Do you want to save now?</source>
        <translation>U heeft niet-opgeslagen wĳzigingen. Wilt u ze nu opslaan?</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="180"/>
        <source>Untitled</source>
        <translation>Naamloos</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="196"/>
        <source>Error</source>
        <translation>Foutmelding</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="211"/>
        <source>No templates found</source>
        <translation>Geen sjablonen aangetroffen</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="234"/>
        <source>No recent files</source>
        <translation>Geen onlangs geopende bestanden</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="247"/>
        <source>Clear</source>
        <translation>Wissen</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="297"/>
        <location filename="../MainWindow.py" line="270"/>
        <source>Desktop Entries</source>
        <translation>Desktopitems</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="314"/>
        <location filename="../MainWindow.py" line="297"/>
        <location filename="../MainWindow.py" line="270"/>
        <source>All Files</source>
        <translation>Alle bestanden</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="283"/>
        <source>Open URL</source>
        <translation>Url openen</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="283"/>
        <source>Please enter the URL to the Desktop Entry</source>
        <translation>Voer de url van een dekstopitem in</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="310"/>
        <source>All Images</source>
        <translation>Alle afbeeldingen</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="311"/>
        <source>PNG Images</source>
        <translation>Png-afbeeldingen</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="312"/>
        <source>SVG Images</source>
        <translation>Svg-afbeeldingen</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="313"/>
        <source>XPM Images</source>
        <translation>Xpm-afbeeldingen</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="353"/>
        <source>Add a Categorie</source>
        <translation>Categorie toevoegen</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="353"/>
        <source>Please select a Categorie from the list below</source>
        <translation>Kies een categorie van onderstaande lĳst</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="357"/>
        <source>Categorie already added</source>
        <translation>Categorie reeds toegevoegd</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="357"/>
        <source>You can&apos;t add the same Categorie twice</source>
        <translation>Deze categorie is al toegevoegd</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="399"/>
        <source>Delete Keywords translation</source>
        <translation>Trefwoordvertalingen wissen</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="399"/>
        <source>Are you really want to delete {{language}}?</source>
        <translation>Weet u zeker dat u {{language}} wilt wissen?</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="416"/>
        <source>Add Action</source>
        <translation>Actie toevoegen</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="416"/>
        <source>Please enter the identifier for the new Action</source>
        <translation>Voer de identificatie van een nieuwe actie in</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="422"/>
        <source>Invalid Identifier</source>
        <translation>Ongeldige identificatie</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="422"/>
        <source>This Identifier is not valid</source>
        <translation>De identificatie is ongeldig</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="426"/>
        <source>Identifier exists</source>
        <translation>Identificatie in gebruik</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="426"/>
        <source>This Identifier already exists</source>
        <translation>Deze identificatie is al in gebruik</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="450"/>
        <source>Delete Action</source>
        <translation>Actie verwĳderen</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="450"/>
        <source>Are you really want to delete {{identifier}}?</source>
        <translation>Weet u zeker dat u {{identifier}} wilt verwĳderen?</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../MainWindow.py" line="475"/>
        <source>Remove</source>
        <translation>Verwĳderen</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="497"/>
        <source>Invalid Key</source>
        <translation>Ongeldige sleutel</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="497"/>
        <source>{{key}} is not a valid custom Key</source>
        <translation>{{key}} is geen geldige sleutel</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="501"/>
        <source>Everything valid</source>
        <translation>Alles is in orde</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="501"/>
        <source>No issues found</source>
        <translation>Er zĳn geen problemen aangetroffen</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="520"/>
        <source>File not found</source>
        <translation>Bestand niet gevonden</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="520"/>
        <source>{{path}} was not found</source>
        <translation>{{path}} is niet aangetroffen</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="551"/>
        <location filename="../MainWindow.py" line="524"/>
        <source>Error loading Desktop Entry</source>
        <translation>Fout tĳdens laden van item</translation>
    </message>
    <message>
        <location filename="../MainWindow.py" line="551"/>
        <location filename="../MainWindow.py" line="524"/>
        <source>This Desktop Entry couldn&apos;t be loaded. Make sure, it is in the right format.</source>
        <translation>Er is een fout opgetreden tĳdens het laden van het item. Controleer of het bestandsformaat juist is.</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>General</source>
        <translation>Algemeen</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Type:</source>
        <translation>Type:</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Name:</source>
        <translation>Naam:</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>GenericName:</source>
        <translation>Algemene naam:</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Comment:</source>
        <translation>Opmerking:</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Icon:</source>
        <translation>Pictogram:</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Exec:</source>
        <translation>Opdracht:</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Browse</source>
        <translation>Bladeren</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>TryExec:</source>
        <translation>Probeeropdracht:</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Path:</source>
        <translation>Locatie:</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>StartupWMClass:</source>
        <translation>StartupWMClass:</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>URL:</source>
        <translation>Url:</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Don&apos;t display in Menu (NoDisplay)</source>
        <translation>Niet tonen in menu (NoDiplay)</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Hide Desktop Entry (Hidden)</source>
        <translation>Item verbergen</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Can be activated with D-Bus (DBusActivatable)</source>
        <translation>Kan worden gestart met behulp van D-Bus (DBusActivatable)</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Run in a Terminal (Terminal)</source>
        <translation>Uitvoeren in terminalvenster</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Send a Message when started (StartupNotify)</source>
        <translation>Bericht versturen na opstarten (StartupNotify)</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Run on a more powerful discrete GPU if available (PrefersNonDefaultGPU)</source>
        <translation>Uitvoeren op krachtigere, losse gpu indien beschikbaar (PrefersNonDefaultGPU)</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Program has a single main window (SingleMainWindow)</source>
        <translation>Dit programma heeft slechts één hoofdvenster (SingleMainWindow)</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Translate</source>
        <translation>Vertalen</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Categories</source>
        <translation>Categorieën</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Add</source>
        <translation>Toevoegen</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>MimeType</source>
        <translation>Mimetype</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Keywords</source>
        <translation>Trefwoorden</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Untranslated</source>
        <translation>Onvertaald</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Translated</source>
        <translation>Vertaald</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>A List of Languages in which are the Keywords translated</source>
        <translation>Een lĳst met talen waarin de trefwoorden zĳn vertaald</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Edit</source>
        <translation>Bewerken</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Actions</source>
        <translation>Acties</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Delete</source>
        <translation>Verwĳderen</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Implements</source>
        <translation>Implementeert</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>OnlyShowIn</source>
        <translation>Alleen tonen in</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>NotShowIn</source>
        <translation>Niet tonen in</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Custom</source>
        <translation>Aangepast</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>All Custom Keys of your Desktop Entry. Make sure the Keys starts with X-.</source>
        <translation>Alle eigen sleutels van uw desktopitem. Let op: sleutels dienen te beginnen met X-.</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Key</source>
        <translation>Sleutel</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Value</source>
        <translation>Waarde</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Check</source>
        <translation>Controleren</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>File</source>
        <translation>Bestand</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Open recent</source>
        <translation>Onlangs geopend</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>New (from Template)</source>
        <translation>Nieuw (uit sjabloon)</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Tools</source>
        <translation>Hulpmiddelen</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Settings</source>
        <translation>Instellingen</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>New</source>
        <translation>Nieuw</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Open</source>
        <translation>Openen</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Save</source>
        <translation>Opslaan</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Save as...</source>
        <translation>Opslaan als…</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Exit</source>
        <translation>Afsluiten</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Validate</source>
        <translation>Verifiëren</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Preview</source>
        <translation>Voorvertoning</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Desktop Entry Specification</source>
        <translation>Desktopitemspecificatie</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>About</source>
        <translation>Over</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>About Qt</source>
        <translation>Over Qt</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Manage templates</source>
        <translation>Sjablonen beheren</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Open from URL</source>
        <translation>Openen via url</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Show Welcome Dialog</source>
        <translation>Welkomstvenster tonen</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>View Source</source>
        <translation>Broncode bekĳken</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Report Bug</source>
        <translation>Bug melden</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="0"/>
        <source>Donate</source>
        <translation>Doneren</translation>
    </message>
</context>
<context>
    <name>ManageTemplatesWindow</name>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="68"/>
        <location filename="../ManageTemplatesWindow.py" line="47"/>
        <source>Enter name</source>
        <translation>Voer een naam in</translation>
    </message>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="47"/>
        <source>This will save your current document as template. Please enter a name.</source>
        <translation>Hierdoor wordt het huidige item opgeslagen als sjabloon. Geef het sjabloon een naam.</translation>
    </message>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="74"/>
        <location filename="../ManageTemplatesWindow.py" line="53"/>
        <source>Name exists</source>
        <translation>Naam is al in gebruik</translation>
    </message>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="74"/>
        <location filename="../ManageTemplatesWindow.py" line="53"/>
        <source>There is already a template with this name</source>
        <translation>Er is al een sjabloon met deze naam</translation>
    </message>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="68"/>
        <source>Please enter the new name</source>
        <translation>Geef het sjabloon een nieuwe naam</translation>
    </message>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="100"/>
        <location filename="../ManageTemplatesWindow.py" line="83"/>
        <source>Error</source>
        <translation>Foutmelding</translation>
    </message>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="83"/>
        <source>A error occurred while renaming</source>
        <translation>Er is een fout opgetreden tĳdens het wĳzigen van de naam</translation>
    </message>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="93"/>
        <source>Delete {{name}}</source>
        <translation>{{name}} verwĳderen</translation>
    </message>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="93"/>
        <source>Are you sure you want to delete {{name}}?</source>
        <translation>Weet u zeker dat u {{name}} wilt verwĳderen?</translation>
    </message>
    <message>
        <location filename="../ManageTemplatesWindow.py" line="100"/>
        <source>A error occurred while deleting</source>
        <translation>Er is een fout opgetreden tĳdens het verwĳderen</translation>
    </message>
    <message>
        <location filename="../ui/ManageTemplatesWindow.ui" line="0"/>
        <source>Manage templates</source>
        <translation>Sjablonen beheren</translation>
    </message>
    <message>
        <location filename="../ui/ManageTemplatesWindow.ui" line="0"/>
        <source>Save</source>
        <translation>Opslaan</translation>
    </message>
    <message>
        <location filename="../ui/ManageTemplatesWindow.ui" line="0"/>
        <source>Rename</source>
        <translation>Naam wĳzigen</translation>
    </message>
    <message>
        <location filename="../ui/ManageTemplatesWindow.ui" line="0"/>
        <source>Delete</source>
        <translation>Verwĳderen</translation>
    </message>
    <message>
        <location filename="../ui/ManageTemplatesWindow.ui" line="0"/>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
</context>
<context>
    <name>PreviewDialog</name>
    <message>
        <location filename="../ui/PreviewDialog.ui" line="0"/>
        <source>Preview</source>
        <translation>Voorvertoning</translation>
    </message>
    <message>
        <location filename="../ui/PreviewDialog.ui" line="0"/>
        <source>Preview of your desktop entry</source>
        <translation>Bekĳk hoe uw desktopitem er uit komt te zien</translation>
    </message>
    <message>
        <location filename="../ui/PreviewDialog.ui" line="0"/>
        <source>Copy</source>
        <translation>Kopiëren</translation>
    </message>
    <message>
        <location filename="../ui/PreviewDialog.ui" line="0"/>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../SettingsDialog.py" line="36"/>
        <source>System language</source>
        <translation>Systeemtaal</translation>
    </message>
    <message>
        <location filename="../SettingsDialog.py" line="41"/>
        <source>Nothing</source>
        <translation>Niets</translation>
    </message>
    <message>
        <location filename="../SettingsDialog.py" line="42"/>
        <source>Filename</source>
        <translation>Bestandsnaam</translation>
    </message>
    <message>
        <location filename="../SettingsDialog.py" line="43"/>
        <source>Path</source>
        <translation>Locatie</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Settings</source>
        <translation>Instellingen</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Language:</source>
        <translation>Taal:</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>(needs restart)</source>
        <translation>(herstart vereist)</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Length of recent files list:</source>
        <translation>Aantal onlangs geopende bestanden:</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Window title:</source>
        <translation>Venstertitel:</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Ask before closing unsaved File</source>
        <translation>Om bevestiging vragen bĳ niet-opgeslagen bestand</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Show in Title if File is edited</source>
        <translation>In titel aangeven of bestand bewerkt is</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Add comment to Files</source>
        <translation>Opmerking toevoegen aan bestanden</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Remove extra spaces when saving</source>
        <translation>Witruimtes wissen na opslaan</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Reset</source>
        <translation>Standaardwaarden</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>OK</source>
        <translation>Oké</translation>
    </message>
    <message>
        <location filename="../ui/SettingsDialog.ui" line="0"/>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
</context>
<context>
    <name>TranslateDialog</name>
    <message>
        <location filename="../ui/TranslateDialog.ui" line="0"/>
        <location filename="../TranslateDialog.py" line="38"/>
        <source>Remove</source>
        <translation>Verwĳderen</translation>
    </message>
    <message>
        <location filename="../TranslateDialog.py" line="54"/>
        <source>No Language</source>
        <translation>Geen taal</translation>
    </message>
    <message>
        <location filename="../TranslateDialog.py" line="54"/>
        <source>You had no Language for at least one Item</source>
        <translation>Minimaal één item bevat geen taal</translation>
    </message>
    <message>
        <location filename="../TranslateDialog.py" line="58"/>
        <source>Language double</source>
        <translation>Meerdere talen</translation>
    </message>
    <message>
        <location filename="../TranslateDialog.py" line="58"/>
        <source>{{Language}} appears twice or more times in the table</source>
        <translation>{{Language}} komt twee of meerdere keren voor in de tabel</translation>
    </message>
    <message>
        <location filename="../ui/TranslateDialog.ui" line="0"/>
        <source>Translate</source>
        <translation>Vertalen</translation>
    </message>
    <message>
        <location filename="../ui/TranslateDialog.ui" line="0"/>
        <source>Language</source>
        <translation>Taal</translation>
    </message>
    <message>
        <location filename="../ui/TranslateDialog.ui" line="0"/>
        <source>Translation</source>
        <translation>Vertaling</translation>
    </message>
    <message>
        <location filename="../ui/TranslateDialog.ui" line="0"/>
        <source>Add</source>
        <translation>Toevoegen</translation>
    </message>
    <message>
        <location filename="../ui/TranslateDialog.ui" line="0"/>
        <source>OK</source>
        <translation>Oké</translation>
    </message>
    <message>
        <location filename="../ui/TranslateDialog.ui" line="0"/>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
</context>
<context>
    <name>ValidationDialog</name>
    <message>
        <location filename="../ValidationDialog.py" line="22"/>
        <source>Errors:</source>
        <translation>Foutmeldingen:</translation>
    </message>
    <message>
        <location filename="../ValidationDialog.py" line="24"/>
        <source>Future errors:</source>
        <translation>Toekomstige foutmeldingen:</translation>
    </message>
    <message>
        <location filename="../ValidationDialog.py" line="26"/>
        <source>Warnings:</source>
        <translation>Waarschuwingen:</translation>
    </message>
    <message>
        <location filename="../ValidationDialog.py" line="28"/>
        <source>Hint:</source>
        <translation>Hint:</translation>
    </message>
    <message>
        <location filename="../ValidationDialog.py" line="36"/>
        <source>desktop-file-validate was not found</source>
        <translation>desktop-file-validate is niet aangetroffen</translation>
    </message>
    <message>
        <location filename="../ValidationDialog.py" line="44"/>
        <source>None</source>
        <translation>Geen</translation>
    </message>
    <message>
        <location filename="../ui/ValidationDialog.ui" line="0"/>
        <source>Validate</source>
        <translation>Verifiëren</translation>
    </message>
    <message>
        <location filename="../ui/ValidationDialog.ui" line="0"/>
        <source>The Box below shows the output of desktop-file-validate</source>
        <translation>De uitvoer van desktop-file-validate wordt hieronder getoond</translation>
    </message>
</context>
<context>
    <name>WelcomeDialog</name>
    <message>
        <location filename="../ui/WelcomeDialog.ui" line="0"/>
        <source>Welcome</source>
        <translation>Welkom</translation>
    </message>
    <message>
        <location filename="../ui/WelcomeDialog.ui" line="0"/>
        <source>Welcome to jdDesktopEntryEdit!</source>
        <translation>Welkom in jdDesktopEntryEdit!</translation>
    </message>
    <message>
        <location filename="../ui/WelcomeDialog.ui" line="0"/>
        <source>This Program allows you to create and edit Desktop Entries according to the Freedesktop Specification.</source>
        <translation>Met dit programma kunt u .desktopitems op basis van de Freedesktop-specificatie aanmaken en bewerken.</translation>
    </message>
    <message>
        <location filename="../ui/WelcomeDialog.ui" line="0"/>
        <source>Unlike other Programs, which try to make things easy by implementing only the main parts, the Goal of jdDesktopEntryEdit is to support the full specification. Thefore, it is expected to read the Specification before using this Program.</source>
        <translation>In tegenstelling tot andere programma&apos;s die alleen het minimale implementeren, implementeert jdDesktopEntryEdit álle specificaties. Voor gebruik van dit programma is dus enige kennis van de specificatie vereist.</translation>
    </message>
    <message>
        <location filename="../ui/WelcomeDialog.ui" line="0"/>
        <source>You can view the Specification at ?&gt;Destop Entry Specification.</source>
        <translation>U kunt de specificatie doornemen via ? → Desktopitemspecificatie.</translation>
    </message>
    <message>
        <location filename="../ui/WelcomeDialog.ui" line="0"/>
        <source>You can validate your Desktop Entry at Tools&gt;Validate.</source>
        <translation>U kunt uw item verifiëren via Hulpmiddelen → Verifiëren.</translation>
    </message>
    <message>
        <location filename="../ui/WelcomeDialog.ui" line="0"/>
        <source>Show this Dialog on Startup</source>
        <translation>Altĳd tonen na opstarten</translation>
    </message>
</context>
</TS>
