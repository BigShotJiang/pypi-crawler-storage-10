"""Test suite for peepomap."""
