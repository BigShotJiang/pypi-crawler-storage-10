"""
libcusparse - A useful Python package
"""

def hello_world():
    """A simple greeting function"""
    return "Hello from libcusparse!"

def add_numbers(a, b):
    """Add two numbers together"""
    return a + b

def get_package_info():
    """Return basic package information"""
    return {
        "name": "libcusparse",
        "version": "11.7.5.86",
        "description": "A useful Python package"
    }

# Package version
__version__ = "11.7.5.86"
