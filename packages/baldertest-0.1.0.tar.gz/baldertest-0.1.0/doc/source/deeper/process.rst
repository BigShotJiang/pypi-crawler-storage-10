Balder process
**************

.. important::

    .. todo complete reworking of this section

    Please note that this part of the documentation is not yet finished. It will still be revised and updated.

This section describes the process how Balder executes a test session and which steps it passes during it.
