Metadata management
*******************

.. important::

    .. todo complete reworking of this section

    Please note that this part of the documentation is not yet finished. It will still be revised and updated.

Balder uses a lot of inner hidden class properties that manages the workflow of Balder. This section describes them.
