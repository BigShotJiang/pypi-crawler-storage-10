Connections Lifecycle over stages
*********************************

.. important::

    .. todo complete reworking of this section

    Please note that this part of the documentation is not yet finished. It will still be revised and updated.

Connections will be reduced, optimized and calculated trough the lifecycle of a Balder session. This section shows how
Balder calculates these connection over the different stages of a Balder test session.