``balderglob.py`` API
*********************

The ``balderglob.py`` file is the central configuration file for your balder session. This section contains all
important objects you can use here.

The setting class ``BalderSetting``
===================================

.. autoclass:: balder.BalderSettings
    :members:
