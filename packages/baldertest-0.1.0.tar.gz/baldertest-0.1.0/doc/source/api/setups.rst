Setup API
*********

Setups describes real-world constellations of custom test environments. They contains the implementation of
:class:`Feature`'s within :class:`Device`'s and the whole information about the real existing
:class:`Connection`'s between this :class:`Device`'s.

Basic ``Setup``
===============

The basic :class:`Setup` class is the master class of every setup.

.. autoclass:: balder.Setup
    :members:
