import balder


class MySimplySharedMemoryConnection(balder.Connection):
    """This is a simply shared memory connection"""
    pass
