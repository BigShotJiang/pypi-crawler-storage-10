

class SharedObj:
    """this class simulates a basic shared memory"""

    shared_mem_list = []
