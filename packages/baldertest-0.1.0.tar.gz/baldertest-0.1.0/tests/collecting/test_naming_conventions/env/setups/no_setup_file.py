import balder


class SetupNoMatching(balder.Setup):
    """This setup should not be collected"""
    pass
