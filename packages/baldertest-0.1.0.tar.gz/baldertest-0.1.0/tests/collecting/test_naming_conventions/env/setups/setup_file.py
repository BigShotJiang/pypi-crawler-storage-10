import balder


class SetupMatching(balder.Setup):
    """This setup should be collected"""
    pass
