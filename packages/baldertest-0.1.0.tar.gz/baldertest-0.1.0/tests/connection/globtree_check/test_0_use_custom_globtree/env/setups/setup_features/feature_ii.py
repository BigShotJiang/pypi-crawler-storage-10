from ...lib.features import FeatureII


class SetupFeatureII(FeatureII):

    def do_something(self):
        pass
