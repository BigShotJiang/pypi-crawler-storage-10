from ...lib.features import FeatureIV


class SetupFeatureIV(FeatureIV):

    def do_something(self):
        pass
