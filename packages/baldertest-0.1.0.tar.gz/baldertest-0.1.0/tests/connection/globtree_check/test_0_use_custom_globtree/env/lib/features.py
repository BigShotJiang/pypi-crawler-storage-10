import balder


class FeatureI(balder.Feature):

    def do_something(self):
        raise NotImplementedError("has to be overwritten in subclass")


class FeatureII(balder.Feature):

    def do_something(self):
        raise NotImplementedError("has to be overwritten in subclass")


class FeatureIII(balder.Feature):

    def do_something(self):
        raise NotImplementedError("has to be overwritten in subclass")


class FeatureIV(balder.Feature):

    def do_something(self):
        raise NotImplementedError("has to be overwritten in subclass")