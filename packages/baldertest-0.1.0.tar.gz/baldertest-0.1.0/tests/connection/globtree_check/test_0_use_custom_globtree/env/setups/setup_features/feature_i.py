from ...lib.features import FeatureI


class SetupFeatureI(FeatureI):

    def do_something(self):
        pass
