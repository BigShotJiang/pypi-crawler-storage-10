from ...lib.features import FeatureIII


class SetupFeatureIII(FeatureIII):

    def do_something(self):
        pass
