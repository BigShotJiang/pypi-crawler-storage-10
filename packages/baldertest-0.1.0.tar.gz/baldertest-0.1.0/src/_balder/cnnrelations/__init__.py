from .and_connection_relation import AndConnectionRelation
from .or_connection_relation import OrConnectionRelation

__all__ = [
    'AndConnectionRelation',
    'OrConnectionRelation'
]
