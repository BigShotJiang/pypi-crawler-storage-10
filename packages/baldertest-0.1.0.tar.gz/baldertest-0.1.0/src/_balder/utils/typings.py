from typing import Literal


MethodLiteralType = Literal["function", "classmethod", "staticmethod", "instancemethod"]
