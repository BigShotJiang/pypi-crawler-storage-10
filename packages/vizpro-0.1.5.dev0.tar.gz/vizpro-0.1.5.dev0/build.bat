@echo off

echo === Instalando dependencias ===
jlpm install

echo === Compilando la librería ===
jlpm run build:lib

echo === Construyendo la extensión de Notebook ===
jlpm run build:nbextension

echo === Construyendo la extensión de JupyterLab ===
jlpm run build:labextension:dev

echo === Proceso completado ===
pause