
export interface MatrixParams{
    matrix: number[][], 
    grid_areas: string[], 
    grid_template_areas: string, 
    style: string,
    rows?: number,
    columns?: number
}
