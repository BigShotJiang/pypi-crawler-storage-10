#!/usr/bin/env python
# coding: utf-8

# Copyright (c) MATIUS.
# Distributed under the terms of the Modified BSD License.

major_v = 0
minor_v = 1
patch_v = 5
version_info = (major_v, minor_v, patch_v, 'dev0')
__version__ = ".".join(map(str, version_info))
