var cache_require = window.require;

window.addEventListener('load', function() {
  window.require = cache_require;
  if (window.requirejs) {
    window.requirejs.config({
      paths: {
        d3: 'https://cdn.jsdelivr.net/npm/d3@7.9.0/dist/d3.min'
      }
    });
  }
});
