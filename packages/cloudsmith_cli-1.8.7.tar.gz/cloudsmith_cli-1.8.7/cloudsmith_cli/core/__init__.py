"""Non-CLI functionality."""
