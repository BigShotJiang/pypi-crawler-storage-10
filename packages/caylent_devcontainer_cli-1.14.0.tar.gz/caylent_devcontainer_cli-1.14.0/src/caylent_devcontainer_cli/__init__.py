"""Caylent Devcontainer CLI package."""

__version__ = "1.14.0"
