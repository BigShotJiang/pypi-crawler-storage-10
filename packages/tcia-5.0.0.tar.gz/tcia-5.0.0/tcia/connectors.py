import requests

class Connector:
    def __init__(self, endpoint=None, mode="echo"):
        self.endpoint = endpoint
        self.mode = mode

    def send(self, message):
        if self.mode == "echo":
            return message[::-1]
        elif self.endpoint:
            try:
                response = requests.post(self.endpoint, json={"message": message})
                return response.text
            except Exception as e:
                return f"Erro na conexão: {e}"
        else:
            return "Nenhum modo válido definido."