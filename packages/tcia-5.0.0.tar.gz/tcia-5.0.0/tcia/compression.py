import base64, zlib

class Compressor:
    def compress(self, text: str):
        data = zlib.compress(text.encode())
        return base64.b64encode(data).decode()

    def decompress(self, text: str):
        try:
            data = base64.b64decode(text.encode())
            return zlib.decompress(data).decode()
        except Exception:
            return text