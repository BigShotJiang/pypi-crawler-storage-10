import json

class Translator:
    def __init__(self, lang="pt"):
        self.lang = lang

    def translate(self, text):
        try:
            data = json.loads(text)
            data["lang"] = self.lang
            return json.dumps(data)
        except Exception:
            return text

    def untranslate(self, text):
        try:
            data = json.loads(text)
            data.pop("lang", None)
            return json.dumps(data)
        except Exception:
            return text