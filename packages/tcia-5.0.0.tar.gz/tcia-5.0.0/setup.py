from setuptools import setup, find_packages

setup(
    name="TCIA",
    version="5.0.0",
    author="Filipe",
    author_email="filipe1990lg@gmail.com",
    description="TCIA — TokenChat Intelligent Assistant. Biblioteca universal de comunicação entre humanos e IAs com aprendizado adaptativo.",
    packages=find_packages(),
    python_requires=">=3.7",
    license="Licença Espiritual Kiriri",
)