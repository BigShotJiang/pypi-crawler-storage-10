# TCIA 5.0

**TokenChat Intelligent Assistant (TCIA)**

TCIA é uma biblioteca Python que fornece uma ponte universal de tokenização e adaptação entre modelos de IA e chatbots, permitindo comunicação padronizada e aprendizado adaptativo. É o cérebro que ensina as IAs a se entenderem — um tradutor universal que aprende sozinho e conecta mentes artificiais sem mudar seus códigos.

## Instalação

```bash
pip install tcia
```

## Exemplo de uso

```python
from tcia import TokenchatUniversal, Compressor, Translator

def dummy_ai(msg):
    return msg[::-1]

tcia = TokenchatUniversal()
comp = Compressor()
trans = Translator("en")

resposta = tcia.bridge(dummy_ai, "Olá, tudo bem?", compressor=comp, translator=trans)
print(resposta)
```