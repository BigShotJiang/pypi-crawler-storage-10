from dramatiq.brokers.stub import StubBroker, _StubMessageProxy


class EagerBroker(StubBroker):
    def __init__(self, middleware, *args, **kwargs):
        super().__init__(middleware)

    def process_message(self, message):
        # Ensure middlewares are executed
        self.emit_before("process_message", message)

        actor = self.get_actor(message.actor_name)
        result = actor(*message.args, **message.kwargs)

        self.emit_after("process_message", message, result=result)

    def enqueue(self, message, *, delay=None):
        self.process_message(_StubMessageProxy(message))
