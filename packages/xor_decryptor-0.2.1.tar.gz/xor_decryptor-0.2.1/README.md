# manga_xor
A faster Python XOR decryption package for manga RP. Uses rust under the hood.
