"""
XandAI Processors - Processadores de modo (Chat/Task)
"""
