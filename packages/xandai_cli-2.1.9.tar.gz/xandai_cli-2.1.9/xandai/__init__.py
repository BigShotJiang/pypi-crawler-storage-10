"""
XandAI - CLI Assistant with Ollama Integration

Uma ferramenta CLI inteligente para assistência em desenvolvimento
com integração nativa a modelos Ollama e suporte a múltiplos modos.
"""

__version__ = "2.1.9"
__author__ = "XandNet"
__description__ = "Production-grade CLI Assistant with Ollama Integration, Terminal Commands, and Context Tracking"
