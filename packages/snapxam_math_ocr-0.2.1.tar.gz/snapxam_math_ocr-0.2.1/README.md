# SnapXam Math OCR API — Python Client

A lightweight Python client for the [SnapXam Math OCR API](https://www.snapxam.com/apis/math-apis) — convert handwritten or printed math equations into text or LaTeX effortlessly.

---

## Features

- Converts images of math expressions into LaTeX or infix notation  
- Simple interface using `PIL.Image` or file paths  
- Minimal dependencies (`requests`, `Pillow`)
- Requires an API key for authentication. An api key can be obtained [here](https://www.snapxam.com/apis/math-apis/docs).

---
Setup
---

### Installation

```bash
pip install snapxam-math-ocr
```

---
Recognize math images
---

### Basic usage

```bash
from snapxam_math_ocr import SnapXamMathOCR

ocr = SnapXamMathOCR(api_key="your-api-key")
img = Image.open("image_with_some_math.png")
result = ocr.recognize(img)
print(result)  # sample response: {'latex': '\\frac{a}{b}', 'infix': 'a/b'}

```