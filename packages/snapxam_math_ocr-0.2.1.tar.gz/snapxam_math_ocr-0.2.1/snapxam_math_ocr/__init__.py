from .client import SnapXamMathOCR

__version__ = "0.2.1"
