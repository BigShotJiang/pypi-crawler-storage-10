// Fallback kernel metadata to use until the .deepnote file format includes kernel information
export const kernelMetadataFallback = {
  kernelspec: {
    display_name: 'Python 3 (ipykernel)',
    language: 'python',
    name: 'python3'
  },
  language_info: {
    codemirror_mode: {
      name: 'ipython',
      version: 3
    },
    file_extension: '.py',
    mimetype: 'text/x-python',
    name: 'python',
    nbconvert_exporter: 'python',
    pygments_lexer: 'ipython3',
    version: '3.12.11'
  }
};
