from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Optional

from .adaptive_builder import AdaptiveConfig, build_adaptive_context
from .context_cache import ContextCache
from .context_strategy import ContextFile


def format_context_simple(files: list[ContextFile], max_files: int = 5) -> str:
    """Format a small selection of context files for chat."""
    parts = ["# Codebase Context\n"]
    for f in files[:max_files]:
        parts.append(f"## {f.path}")
        content = f.content[:2000] if len(f.content) > 2000 else f.content
        parts.append(f"```\n{content}\n```\n")
    return "\n".join(parts)


def run_chat(root: str, provider: Any, model: str) -> int:
    """Run interactive chat session with the AI about the codebase."""
    if provider is None:
        print("Error: Provider required. Use --provider ollama or --provider gemini")
        return 1

    print(f"🤖 Ollcoder Chat (model: {model})")
    print(f"📁 Project: {root}")
    print("💬 Type your message (or 'exit' to quit)\n")

    # Build initial context without compression
    cache = ContextCache(root)
    cfg = AdaptiveConfig(
        root_dir=root,
        query="",
        model_max_tokens=8000,  # Conservative to avoid hanging
    )
    
    print("Building context... ", end="", flush=True)
    try:
        # Skip compression by not passing provider to context building
        files, stats = build_adaptive_context(cfg, cache=cache, provider=None)
        print(f"✓ ({len(files)} files, {stats['used_tokens']} tokens)\n")
    except Exception as e:
        print(f"✗ Error: {e}\n")
        files = []

    context = format_context_simple(files) if files else "# No context available\n"
    
    messages = [
        {"role": "system", "content": "You are a helpful coding assistant. Help the user with their codebase."},
        {"role": "user", "content": f"Here's the codebase context:\n\n{context}"},
    ]

    while True:
        try:
            user_input = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n👋 Goodbye!")
            return 0

        if not user_input:
            continue
            
        if user_input.lower() in ("exit", "quit", "q"):
            print("\n👋 Goodbye!")
            return 0

        # Don't send exit commands to the AI
        if user_input.strip().lower().startswith(("exit", "quit")):
            print("\n👋 Goodbye!")
            return 0

        messages.append({"role": "user", "content": user_input})

        try:
            print("\n🤖 Assistant: ", end="", flush=True)
            
            # Check if provider supports streaming
            if hasattr(provider, 'chat') and hasattr(provider, 'supports_streaming'):
                # Stream the response
                response_text = ""
                for chunk in provider.chat(messages, stream=True):
                    chunk_text = _extract_chunk_text(chunk)
                    if chunk_text:
                        print(chunk_text, end="", flush=True)
                        response_text += chunk_text
                print("\n")
            else:
                # Non-streaming fallback
                response = provider.chat(messages, stream=False)
                response_text = _extract_response_text(response)
                print(response_text + "\n")

            messages.append({"role": "assistant", "content": response_text})

        except Exception as e:
            print(f"\n❌ Error: {e}\n")
            # Remove the last user message if we failed
            if messages[-1]["role"] == "user":
                messages.pop()

    return 0


def _extract_response_text(resp: Any) -> str:
    """Extract text from provider response."""
    if resp is None:
        return ""
    
    # Gemini style
    txt = getattr(resp, "text", None)
    if isinstance(txt, str) and txt.strip():
        return txt
    
    # Ollama style
    if isinstance(resp, dict):
        msg = resp.get("message")
        if isinstance(msg, dict):
            c = msg.get("content")
            if isinstance(c, str) and c.strip():
                return c
        c = resp.get("content")
        if isinstance(c, str) and c.strip():
            return c
    
    return str(resp)


def _extract_chunk_text(chunk: Any) -> str:
    """Extract text from streaming chunk."""
    if isinstance(chunk, dict):
        msg = chunk.get("message", {})
        if isinstance(msg, dict):
            return msg.get("content", "")
        return chunk.get("content", "")
    
    # Gemini streaming chunks
    txt = getattr(chunk, "text", None)
    if isinstance(txt, str):
        return txt
    
    return ""
