This module allows you to attach several customizable exceptions to your
opportunities. You can also define an exception rule to be applied to
specific CRM stages.
