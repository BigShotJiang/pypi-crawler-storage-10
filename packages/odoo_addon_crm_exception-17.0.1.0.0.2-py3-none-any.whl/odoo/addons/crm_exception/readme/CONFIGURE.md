**To configure CRM exception rule:**

1.  Create a new exception rule.
2.  Select "Lead" in the "Apply On" field (the 'stage_ids' field will be
    displayed).
3.  Choose the CRM stage to which you want to apply the exception rule.
4.  Specify the exception type and define the condition, then save the
    rule.

**Note:** If you don't specify a CRM stage for stage_ids (leave it
blank), the rule will be checked at every stage.
