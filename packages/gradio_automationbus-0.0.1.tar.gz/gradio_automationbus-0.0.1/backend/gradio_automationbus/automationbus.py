"""Automation lane component."""

from __future__ import annotations

import json
import math
import random
from collections.abc import Callable, Sequence
from typing import TYPE_CHECKING, Any, Literal

from gradio_client.documentation import document

from gradio.components.base import Component, FormComponent
from gradio.components.number import Number
from gradio.events import Events
from gradio.i18n import I18nData

if TYPE_CHECKING:
    from gradio.components import Timer


class AutomationBus(FormComponent):
    """
    A DAW-like automation lane for plotting control points over time.

    Renders a 2D canvas (x: time, y: value) with an optional audio waveform background.
    Users can click to add/update points; points are connected left-to-right and x values
    are unique. The component's OUTPUT is always a list of [x, y] coordinates.
    """

    EVENTS = [Events.change, Events.input, Events.release]

    def __init__(
        self,
        value: list[list[float]] | dict[str, Any] | Callable | None = None,
        *,
        x_min: float = 0.0,
        x_max: float = 1.0,
        y_min: float = 0.0,
        y_max: float = 1.0,
        precision: int | None = 3,
        audio_url: str | None = None,
        shade_enabled: bool = True,
        shade_above_color: str | None = "rgba(250, 204, 21, 0.25)",
        shade_below_color: str | None = "rgba(34, 197, 94, 0.25)",
        top_label: str | None = None,
        bottom_label: str | None = None,
        label: str | I18nData | None = None,
        info: str | I18nData | None = None,
        every: Timer | float | None = None,
        inputs: Component | Sequence[Component] | set[Component] | None = None,
        show_label: bool | None = None,
        container: bool = True,
        scale: int | None = None,
        min_width: int = 160,
        interactive: bool | None = None,
        visible: bool | Literal["hidden"] = True,
        elem_id: str | None = None,
        elem_classes: list[str] | str | None = None,
        render: bool = True,
        key: int | str | tuple[int | str, ...] | None = None,
        preserved_by_key: list[str] | str | None = "value",
        show_reset_button: bool = True,
    ):
        """
        Parameters:
            value: Initial points list ([[x, y], ...]) or an object {"points": [[x,y],...], "audio_url": str}.
            x_min: Minimum x value of the canvas domain.
            x_max: Maximum x value of the canvas domain.
            y_min: Minimum y value of the canvas range.
            y_max: Maximum y value of the canvas range.
            precision: Number of decimal places to round values to when serializing.
            audio_url: Optional URL or path to an audio file to render waveform background.
            label, info, every, inputs, show_label, container, scale, min_width, interactive, visible, elem_id, elem_classes, render, key, preserved_by_key, show_reset_button: Standard component options.
        """
        self.x_min = x_min
        self.x_max = x_max
        self.y_min = y_min
        self.y_max = y_max
        self.precision = precision
        self.audio_url = audio_url
        self.shade_enabled = shade_enabled
        self.shade_above_color = shade_above_color
        self.shade_below_color = shade_below_color
        self.top_label = top_label
        self.bottom_label = bottom_label
        self.show_reset_button = show_reset_button
        super().__init__(
            label=label,
            info=info,
            every=every,
            inputs=inputs,
            show_label=show_label,
            container=container,
            scale=scale,
            min_width=min_width,
            interactive=interactive,
            visible=visible,
            elem_id=elem_id,
            elem_classes=elem_classes,
            render=render,
            key=key,
            preserved_by_key=preserved_by_key,
            value=value,
        )

    def api_info(self) -> dict[str, Any]:
        return {
            "type": "array",
            "items": {
                "type": "array",
                "items": {"type": "number"},
                "minItems": 2,
                "maxItems": 2,
            },
            "description": "List of [x, y] points (sorted by x; unique x).",
        }

    def example_payload(self) -> Any:
        return [[0.0, 0.5], [0.5, 0.8], [1.0, 0.2]]

    def example_value(self) -> Any:
        return [[0.0, 0.5], [0.5, 0.8], [1.0, 0.2]]

    @staticmethod
    def _round(value: float | None, precision: int | None) -> float:
        if value is None:
            return 0.0
        if precision is None:
            return float(value)
        return round(float(value), precision)

    def postprocess(self, value: Any) -> list[list[float]] | dict[str, Any]:
        """
        Accepts either a list of [x, y] points, or an object like
        {"points": [[x, y], ...], "audio_url": str}. Returns the same shape back
        to the frontend, rounding to the configured precision. The frontend will
        always SEND BACK just the list of points when used as an input to a function.
        """
        if value is None:
            return []
        # Allow passing {points, audio_url} to update waveform source from Python
        if isinstance(value, dict):
            points = value.get("points", [])
            rounded = [
                [
                    self._round(float(p[0]), self.precision),
                    self._round(float(p[1]), self.precision),
                ]
                for p in points
                if isinstance(p, (list, tuple)) and len(p) == 2
            ]
            payload: dict[str, Any] = {
                "points": rounded,
            }
            if "audio_url" in value and value["audio_url"] is not None:
                payload["audio_url"] = value["audio_url"]
            # Include axis bounds so frontend can render consistently
            payload["x_min"] = self.x_min
            payload["x_max"] = self.x_max
            payload["y_min"] = self.y_min
            payload["y_max"] = self.y_max
            payload["shade_enabled"] = self.shade_enabled
            if self.shade_above_color is not None:
                payload["shade_above_color"] = self.shade_above_color
            if self.shade_below_color is not None:
                payload["shade_below_color"] = self.shade_below_color
            if self.top_label is not None:
                payload["top_label"] = self.top_label
            if self.bottom_label is not None:
                payload["bottom_label"] = self.bottom_label
            return payload
        # Otherwise assume it's points only
        if isinstance(value, (list, tuple)):
            rounded = [
                [
                    self._round(float(p[0]), self.precision),
                    self._round(float(p[1]), self.precision),
                ]
                for p in value
                if isinstance(p, (list, tuple)) and len(p) == 2
            ]
            return rounded
        return []

    def preprocess(self, payload: Any) -> list[list[float]]:
        """
        Parameters:
            payload: list of [x, y] points from the frontend.
        Returns:
            The validated and rounded list of points.
        """
        if payload is None:
            return []
        if not isinstance(payload, (list, tuple)):
            return []
        points: list[list[float]] = []
        seen_x: set[float] = set()
        for p in payload:
            if not (isinstance(p, (list, tuple)) and len(p) == 2):
                continue
            x_raw, y_raw = float(p[0]), float(p[1])
            # Clamp to bounds
            x = max(self.x_min, min(self.x_max, x_raw))
            y = max(self.y_min, min(self.y_max, y_raw))
            # Enforce unique x by skipping duplicates (frontend should already handle)
            if x in seen_x:
                continue
            seen_x.add(x)
            points.append([
                Number.round_to_precision(x, self.precision),
                Number.round_to_precision(y, self.precision),
            ])
        # Sort by x
        points.sort(key=lambda p: p[0])
        return points

    def read_from_flag(self, payload: Any):
        """Points arrays are stored as strings in the flagging file; parse as JSON."""
        return json.loads(payload)
