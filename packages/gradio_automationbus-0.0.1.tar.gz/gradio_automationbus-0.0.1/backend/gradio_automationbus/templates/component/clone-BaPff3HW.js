import { b as r } from "./_baseUniq-C0QWl0ZD.js";
var e = 4;
function a(o) {
  return r(o, e);
}
export {
  a as c
};
