import { I as f } from "./Index-DMa58JTc.js";
export {
  f as default
};
