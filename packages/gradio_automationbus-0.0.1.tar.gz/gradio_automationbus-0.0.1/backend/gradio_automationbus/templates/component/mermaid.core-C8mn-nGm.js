var Qm = Object.defineProperty;
var Jm = (e, t, r) => t in e ? Qm(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r;
var mt = (e, t, r) => Jm(e, typeof t != "symbol" ? t + "" : t, r);
import { g as t0, c as e0 } from "./Index-DMa58JTc.js";
var jl = {
  name: "mermaid",
  version: "11.12.0",
  description: "Markdown-ish syntax for generating flowcharts, mindmaps, sequence diagrams, class diagrams, gantt charts, git graphs and more.",
  type: "module",
  module: "./dist/mermaid.core.mjs",
  types: "./dist/mermaid.d.ts",
  exports: {
    ".": {
      types: "./dist/mermaid.d.ts",
      import: "./dist/mermaid.core.mjs",
      default: "./dist/mermaid.core.mjs"
    },
    "./*": "./*"
  },
  keywords: [
    "diagram",
    "markdown",
    "flowchart",
    "sequence diagram",
    "gantt",
    "class diagram",
    "git graph",
    "mindmap",
    "packet diagram",
    "c4 diagram",
    "er diagram",
    "pie chart",
    "pie diagram",
    "quadrant chart",
    "requirement diagram",
    "graph"
  ],
  scripts: {
    clean: "rimraf dist",
    dev: "pnpm -w dev",
    "docs:code": "typedoc src/defaultConfig.ts src/config.ts src/mermaid.ts && prettier --write ./src/docs/config/setup",
    "docs:build": "rimraf ../../docs && pnpm docs:code && pnpm docs:spellcheck && tsx scripts/docs.cli.mts",
    "docs:verify": "pnpm docs:code && pnpm docs:spellcheck && tsx scripts/docs.cli.mts --verify",
    "docs:pre:vitepress": "pnpm --filter ./src/docs prefetch && rimraf src/vitepress && pnpm docs:code && tsx scripts/docs.cli.mts --vitepress && pnpm --filter ./src/vitepress install --no-frozen-lockfile --ignore-scripts",
    "docs:build:vitepress": "pnpm docs:pre:vitepress && (cd src/vitepress && pnpm run build) && cpy --flat src/docs/landing/ ./src/vitepress/.vitepress/dist/landing",
    "docs:dev": 'pnpm docs:pre:vitepress && concurrently "pnpm --filter ./src/vitepress dev" "tsx scripts/docs.cli.mts --watch --vitepress"',
    "docs:dev:docker": 'pnpm docs:pre:vitepress && concurrently "pnpm --filter ./src/vitepress dev:docker" "tsx scripts/docs.cli.mts --watch --vitepress"',
    "docs:serve": "pnpm docs:build:vitepress && vitepress serve src/vitepress",
    "docs:spellcheck": 'cspell "src/docs/**/*.md"',
    "docs:release-version": "tsx scripts/update-release-version.mts",
    "docs:verify-version": "tsx scripts/update-release-version.mts --verify",
    "types:build-config": "tsx scripts/create-types-from-json-schema.mts",
    "types:verify-config": "tsx scripts/create-types-from-json-schema.mts --verify",
    checkCircle: "npx madge --circular ./src",
    prepublishOnly: "pnpm docs:verify-version"
  },
  repository: {
    type: "git",
    url: "https://github.com/mermaid-js/mermaid"
  },
  author: "Knut Sveidqvist",
  license: "MIT",
  standard: {
    ignore: [
      "**/parser/*.js",
      "dist/**/*.js",
      "cypress/**/*.js"
    ],
    globals: [
      "page"
    ]
  },
  dependencies: {
    "@braintree/sanitize-url": "^7.1.1",
    "@iconify/utils": "^3.0.1",
    "@mermaid-js/parser": "workspace:^",
    "@types/d3": "^7.4.3",
    cytoscape: "^3.29.3",
    "cytoscape-cose-bilkent": "^4.1.0",
    "cytoscape-fcose": "^2.2.0",
    d3: "^7.9.0",
    "d3-sankey": "^0.12.3",
    "dagre-d3-es": "7.0.11",
    dayjs: "^1.11.18",
    dompurify: "^3.2.5",
    katex: "^0.16.22",
    khroma: "^2.1.0",
    "lodash-es": "^4.17.21",
    marked: "^16.2.1",
    roughjs: "^4.6.6",
    stylis: "^4.3.6",
    "ts-dedent": "^2.2.0",
    uuid: "^11.1.0"
  },
  devDependencies: {
    "@adobe/jsonschema2md": "^8.0.5",
    "@iconify/types": "^2.0.0",
    "@types/cytoscape": "^3.21.9",
    "@types/cytoscape-fcose": "^2.2.4",
    "@types/d3-sankey": "^0.12.4",
    "@types/d3-scale": "^4.0.9",
    "@types/d3-scale-chromatic": "^3.1.0",
    "@types/d3-selection": "^3.0.11",
    "@types/d3-shape": "^3.1.7",
    "@types/jsdom": "^21.1.7",
    "@types/katex": "^0.16.7",
    "@types/lodash-es": "^4.17.12",
    "@types/micromatch": "^4.0.9",
    "@types/stylis": "^4.2.7",
    "@types/uuid": "^10.0.0",
    ajv: "^8.17.1",
    canvas: "^3.1.2",
    chokidar: "3.6.0",
    concurrently: "^9.1.2",
    "csstree-validator": "^4.0.1",
    globby: "^14.1.0",
    jison: "^0.4.18",
    "js-base64": "^3.7.8",
    jsdom: "^26.1.0",
    "json-schema-to-typescript": "^15.0.4",
    micromatch: "^4.0.8",
    "path-browserify": "^1.0.1",
    prettier: "^3.5.3",
    remark: "^15.0.1",
    "remark-frontmatter": "^5.0.0",
    "remark-gfm": "^4.0.1",
    rimraf: "^6.0.1",
    "start-server-and-test": "^2.0.13",
    "type-fest": "^4.35.0",
    typedoc: "^0.28.12",
    "typedoc-plugin-markdown": "^4.8.1",
    typescript: "~5.7.3",
    "unist-util-flatmap": "^1.0.0",
    "unist-util-visit": "^5.0.0",
    vitepress: "^1.6.4",
    "vitepress-plugin-search": "1.0.4-alpha.22"
  },
  files: [
    "dist/",
    "README.md"
  ],
  publishConfig: {
    access: "public"
  }
}, kh = { exports: {} };
(function(e, t) {
  (function(r, i) {
    e.exports = i();
  })(e0, function() {
    var r = 1e3, i = 6e4, n = 36e5, a = "millisecond", o = "second", s = "minute", l = "hour", c = "day", h = "week", u = "month", f = "quarter", p = "year", g = "date", m = "Invalid Date", y = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, x = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, b = { name: "en", weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"), months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"), ordinal: function(M) {
      var A = ["th", "st", "nd", "rd"], B = M % 100;
      return "[" + M + (A[(B - 20) % 10] || A[B] || A[0]) + "]";
    } }, _ = function(M, A, B) {
      var E = String(M);
      return !E || E.length >= A ? M : "" + Array(A + 1 - E.length).join(B) + M;
    }, v = { s: _, z: function(M) {
      var A = -M.utcOffset(), B = Math.abs(A), E = Math.floor(B / 60), L = B % 60;
      return (A <= 0 ? "+" : "-") + _(E, 2, "0") + ":" + _(L, 2, "0");
    }, m: function M(A, B) {
      if (A.date() < B.date()) return -M(B, A);
      var E = 12 * (B.year() - A.year()) + (B.month() - A.month()), L = A.clone().add(E, u), W = B - L < 0, X = A.clone().add(E + (W ? -1 : 1), u);
      return +(-(E + (B - L) / (W ? L - X : X - L)) || 0);
    }, a: function(M) {
      return M < 0 ? Math.ceil(M) || 0 : Math.floor(M);
    }, p: function(M) {
      return { M: u, y: p, w: h, d: c, D: g, h: l, m: s, s: o, ms: a, Q: f }[M] || String(M || "").toLowerCase().replace(/s$/, "");
    }, u: function(M) {
      return M === void 0;
    } }, w = "en", C = {};
    C[w] = b;
    var S = "$isDayjsObject", D = function(M) {
      return M instanceof z || !(!M || !M[S]);
    }, P = function M(A, B, E) {
      var L;
      if (!A) return w;
      if (typeof A == "string") {
        var W = A.toLowerCase();
        C[W] && (L = W), B && (C[W] = B, L = W);
        var X = A.split("-");
        if (!L && X.length > 1) return M(X[0]);
      } else {
        var H = A.name;
        C[H] = A, L = H;
      }
      return !E && L && (w = L), L || !E && w;
    }, R = function(M, A) {
      if (D(M)) return M.clone();
      var B = typeof A == "object" ? A : {};
      return B.date = M, B.args = arguments, new z(B);
    }, $ = v;
    $.l = P, $.i = D, $.w = function(M, A) {
      return R(M, { locale: A.$L, utc: A.$u, x: A.$x, $offset: A.$offset });
    };
    var z = function() {
      function M(B) {
        this.$L = P(B.locale, null, !0), this.parse(B), this.$x = this.$x || B.x || {}, this[S] = !0;
      }
      var A = M.prototype;
      return A.parse = function(B) {
        this.$d = function(E) {
          var L = E.date, W = E.utc;
          if (L === null) return /* @__PURE__ */ new Date(NaN);
          if ($.u(L)) return /* @__PURE__ */ new Date();
          if (L instanceof Date) return new Date(L);
          if (typeof L == "string" && !/Z$/i.test(L)) {
            var X = L.match(y);
            if (X) {
              var H = X[2] - 1 || 0, ut = (X[7] || "0").substring(0, 3);
              return W ? new Date(Date.UTC(X[1], H, X[3] || 1, X[4] || 0, X[5] || 0, X[6] || 0, ut)) : new Date(X[1], H, X[3] || 1, X[4] || 0, X[5] || 0, X[6] || 0, ut);
            }
          }
          return new Date(L);
        }(B), this.init();
      }, A.init = function() {
        var B = this.$d;
        this.$y = B.getFullYear(), this.$M = B.getMonth(), this.$D = B.getDate(), this.$W = B.getDay(), this.$H = B.getHours(), this.$m = B.getMinutes(), this.$s = B.getSeconds(), this.$ms = B.getMilliseconds();
      }, A.$utils = function() {
        return $;
      }, A.isValid = function() {
        return this.$d.toString() !== m;
      }, A.isSame = function(B, E) {
        var L = R(B);
        return this.startOf(E) <= L && L <= this.endOf(E);
      }, A.isAfter = function(B, E) {
        return R(B) < this.startOf(E);
      }, A.isBefore = function(B, E) {
        return this.endOf(E) < R(B);
      }, A.$g = function(B, E, L) {
        return $.u(B) ? this[E] : this.set(L, B);
      }, A.unix = function() {
        return Math.floor(this.valueOf() / 1e3);
      }, A.valueOf = function() {
        return this.$d.getTime();
      }, A.startOf = function(B, E) {
        var L = this, W = !!$.u(E) || E, X = $.p(B), H = function(Ct, xt) {
          var vt = $.w(L.$u ? Date.UTC(L.$y, xt, Ct) : new Date(L.$y, xt, Ct), L);
          return W ? vt : vt.endOf(c);
        }, ut = function(Ct, xt) {
          return $.w(L.toDate()[Ct].apply(L.toDate("s"), (W ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(xt)), L);
        }, nt = this.$W, gt = this.$M, st = this.$D, at = "set" + (this.$u ? "UTC" : "");
        switch (X) {
          case p:
            return W ? H(1, 0) : H(31, 11);
          case u:
            return W ? H(1, gt) : H(0, gt + 1);
          case h:
            var ct = this.$locale().weekStart || 0, yt = (nt < ct ? nt + 7 : nt) - ct;
            return H(W ? st - yt : st + (6 - yt), gt);
          case c:
          case g:
            return ut(at + "Hours", 0);
          case l:
            return ut(at + "Minutes", 1);
          case s:
            return ut(at + "Seconds", 2);
          case o:
            return ut(at + "Milliseconds", 3);
          default:
            return this.clone();
        }
      }, A.endOf = function(B) {
        return this.startOf(B, !1);
      }, A.$set = function(B, E) {
        var L, W = $.p(B), X = "set" + (this.$u ? "UTC" : ""), H = (L = {}, L[c] = X + "Date", L[g] = X + "Date", L[u] = X + "Month", L[p] = X + "FullYear", L[l] = X + "Hours", L[s] = X + "Minutes", L[o] = X + "Seconds", L[a] = X + "Milliseconds", L)[W], ut = W === c ? this.$D + (E - this.$W) : E;
        if (W === u || W === p) {
          var nt = this.clone().set(g, 1);
          nt.$d[H](ut), nt.init(), this.$d = nt.set(g, Math.min(this.$D, nt.daysInMonth())).$d;
        } else H && this.$d[H](ut);
        return this.init(), this;
      }, A.set = function(B, E) {
        return this.clone().$set(B, E);
      }, A.get = function(B) {
        return this[$.p(B)]();
      }, A.add = function(B, E) {
        var L, W = this;
        B = Number(B);
        var X = $.p(E), H = function(gt) {
          var st = R(W);
          return $.w(st.date(st.date() + Math.round(gt * B)), W);
        };
        if (X === u) return this.set(u, this.$M + B);
        if (X === p) return this.set(p, this.$y + B);
        if (X === c) return H(1);
        if (X === h) return H(7);
        var ut = (L = {}, L[s] = i, L[l] = n, L[o] = r, L)[X] || 1, nt = this.$d.getTime() + B * ut;
        return $.w(nt, this);
      }, A.subtract = function(B, E) {
        return this.add(-1 * B, E);
      }, A.format = function(B) {
        var E = this, L = this.$locale();
        if (!this.isValid()) return L.invalidDate || m;
        var W = B || "YYYY-MM-DDTHH:mm:ssZ", X = $.z(this), H = this.$H, ut = this.$m, nt = this.$M, gt = L.weekdays, st = L.months, at = L.meridiem, ct = function(xt, vt, le, ie) {
          return xt && (xt[vt] || xt(E, W)) || le[vt].slice(0, ie);
        }, yt = function(xt) {
          return $.s(H % 12 || 12, xt, "0");
        }, Ct = at || function(xt, vt, le) {
          var ie = xt < 12 ? "AM" : "PM";
          return le ? ie.toLowerCase() : ie;
        };
        return W.replace(x, function(xt, vt) {
          return vt || function(le) {
            switch (le) {
              case "YY":
                return String(E.$y).slice(-2);
              case "YYYY":
                return $.s(E.$y, 4, "0");
              case "M":
                return nt + 1;
              case "MM":
                return $.s(nt + 1, 2, "0");
              case "MMM":
                return ct(L.monthsShort, nt, st, 3);
              case "MMMM":
                return ct(st, nt);
              case "D":
                return E.$D;
              case "DD":
                return $.s(E.$D, 2, "0");
              case "d":
                return String(E.$W);
              case "dd":
                return ct(L.weekdaysMin, E.$W, gt, 2);
              case "ddd":
                return ct(L.weekdaysShort, E.$W, gt, 3);
              case "dddd":
                return gt[E.$W];
              case "H":
                return String(H);
              case "HH":
                return $.s(H, 2, "0");
              case "h":
                return yt(1);
              case "hh":
                return yt(2);
              case "a":
                return Ct(H, ut, !0);
              case "A":
                return Ct(H, ut, !1);
              case "m":
                return String(ut);
              case "mm":
                return $.s(ut, 2, "0");
              case "s":
                return String(E.$s);
              case "ss":
                return $.s(E.$s, 2, "0");
              case "SSS":
                return $.s(E.$ms, 3, "0");
              case "Z":
                return X;
            }
            return null;
          }(xt) || X.replace(":", "");
        });
      }, A.utcOffset = function() {
        return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
      }, A.diff = function(B, E, L) {
        var W, X = this, H = $.p(E), ut = R(B), nt = (ut.utcOffset() - this.utcOffset()) * i, gt = this - ut, st = function() {
          return $.m(X, ut);
        };
        switch (H) {
          case p:
            W = st() / 12;
            break;
          case u:
            W = st();
            break;
          case f:
            W = st() / 3;
            break;
          case h:
            W = (gt - nt) / 6048e5;
            break;
          case c:
            W = (gt - nt) / 864e5;
            break;
          case l:
            W = gt / n;
            break;
          case s:
            W = gt / i;
            break;
          case o:
            W = gt / r;
            break;
          default:
            W = gt;
        }
        return L ? W : $.a(W);
      }, A.daysInMonth = function() {
        return this.endOf(u).$D;
      }, A.$locale = function() {
        return C[this.$L];
      }, A.locale = function(B, E) {
        if (!B) return this.$L;
        var L = this.clone(), W = P(B, E, !0);
        return W && (L.$L = W), L;
      }, A.clone = function() {
        return $.w(this.$d, this);
      }, A.toDate = function() {
        return new Date(this.valueOf());
      }, A.toJSON = function() {
        return this.isValid() ? this.toISOString() : null;
      }, A.toISOString = function() {
        return this.$d.toISOString();
      }, A.toString = function() {
        return this.$d.toUTCString();
      }, M;
    }(), O = z.prototype;
    return R.prototype = O, [["$ms", a], ["$s", o], ["$m", s], ["$H", l], ["$W", c], ["$M", u], ["$y", p], ["$D", g]].forEach(function(M) {
      O[M[1]] = function(A) {
        return this.$g(A, M[0], M[1]);
      };
    }), R.extend = function(M, A) {
      return M.$i || (M(A, z, R), M.$i = !0), R;
    }, R.locale = P, R.isDayjs = D, R.unix = function(M) {
      return R(1e3 * M);
    }, R.en = C[w], R.Ls = C, R.p = {}, R;
  });
})(kh);
var r0 = kh.exports;
const i0 = /* @__PURE__ */ t0(r0);
var vh = Object.defineProperty, d = (e, t) => vh(e, "name", { value: t, configurable: !0 }), n0 = (e, t) => {
  for (var r in t)
    vh(e, r, { get: t[r], enumerable: !0 });
}, Me = {
  trace: 0,
  debug: 1,
  info: 2,
  warn: 3,
  error: 4,
  fatal: 5
}, F = {
  trace: /* @__PURE__ */ d((...e) => {
  }, "trace"),
  debug: /* @__PURE__ */ d((...e) => {
  }, "debug"),
  info: /* @__PURE__ */ d((...e) => {
  }, "info"),
  warn: /* @__PURE__ */ d((...e) => {
  }, "warn"),
  error: /* @__PURE__ */ d((...e) => {
  }, "error"),
  fatal: /* @__PURE__ */ d((...e) => {
  }, "fatal")
}, ko = /* @__PURE__ */ d(function(e = "fatal") {
  let t = Me.fatal;
  typeof e == "string" ? e.toLowerCase() in Me && (t = Me[e]) : typeof e == "number" && (t = e), F.trace = () => {
  }, F.debug = () => {
  }, F.info = () => {
  }, F.warn = () => {
  }, F.error = () => {
  }, F.fatal = () => {
  }, t <= Me.fatal && (F.fatal = console.error ? console.error.bind(console, ne("FATAL"), "color: orange") : console.log.bind(console, "\x1B[35m", ne("FATAL"))), t <= Me.error && (F.error = console.error ? console.error.bind(console, ne("ERROR"), "color: orange") : console.log.bind(console, "\x1B[31m", ne("ERROR"))), t <= Me.warn && (F.warn = console.warn ? console.warn.bind(console, ne("WARN"), "color: orange") : console.log.bind(console, "\x1B[33m", ne("WARN"))), t <= Me.info && (F.info = console.info ? console.info.bind(console, ne("INFO"), "color: lightblue") : console.log.bind(console, "\x1B[34m", ne("INFO"))), t <= Me.debug && (F.debug = console.debug ? console.debug.bind(console, ne("DEBUG"), "color: lightgreen") : console.log.bind(console, "\x1B[32m", ne("DEBUG"))), t <= Me.trace && (F.trace = console.debug ? console.debug.bind(console, ne("TRACE"), "color: lightgreen") : console.log.bind(console, "\x1B[32m", ne("TRACE")));
}, "setLogLevel"), ne = /* @__PURE__ */ d((e) => `%c${i0().format("ss.SSS")} : ${e} : `, "format");
const vn = {
  /* CLAMP */
  min: {
    r: 0,
    g: 0,
    b: 0,
    s: 0,
    l: 0,
    a: 0
  },
  max: {
    r: 255,
    g: 255,
    b: 255,
    h: 360,
    s: 100,
    l: 100,
    a: 1
  },
  clamp: {
    r: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    g: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    b: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    h: (e) => e % 360,
    s: (e) => e >= 100 ? 100 : e < 0 ? 0 : e,
    l: (e) => e >= 100 ? 100 : e < 0 ? 0 : e,
    a: (e) => e >= 1 ? 1 : e < 0 ? 0 : e
  },
  /* CONVERSION */
  //SOURCE: https://planetcalc.com/7779
  toLinear: (e) => {
    const t = e / 255;
    return e > 0.03928 ? Math.pow((t + 0.055) / 1.055, 2.4) : t / 12.92;
  },
  //SOURCE: https://gist.github.com/mjackson/5311256
  hue2rgb: (e, t, r) => (r < 0 && (r += 1), r > 1 && (r -= 1), r < 1 / 6 ? e + (t - e) * 6 * r : r < 1 / 2 ? t : r < 2 / 3 ? e + (t - e) * (2 / 3 - r) * 6 : e),
  hsl2rgb: ({ h: e, s: t, l: r }, i) => {
    if (!t)
      return r * 2.55;
    e /= 360, t /= 100, r /= 100;
    const n = r < 0.5 ? r * (1 + t) : r + t - r * t, a = 2 * r - n;
    switch (i) {
      case "r":
        return vn.hue2rgb(a, n, e + 1 / 3) * 255;
      case "g":
        return vn.hue2rgb(a, n, e) * 255;
      case "b":
        return vn.hue2rgb(a, n, e - 1 / 3) * 255;
    }
  },
  rgb2hsl: ({ r: e, g: t, b: r }, i) => {
    e /= 255, t /= 255, r /= 255;
    const n = Math.max(e, t, r), a = Math.min(e, t, r), o = (n + a) / 2;
    if (i === "l")
      return o * 100;
    if (n === a)
      return 0;
    const s = n - a, l = o > 0.5 ? s / (2 - n - a) : s / (n + a);
    if (i === "s")
      return l * 100;
    switch (n) {
      case e:
        return ((t - r) / s + (t < r ? 6 : 0)) * 60;
      case t:
        return ((r - e) / s + 2) * 60;
      case r:
        return ((e - t) / s + 4) * 60;
      default:
        return -1;
    }
  }
}, a0 = {
  /* API */
  clamp: (e, t, r) => t > r ? Math.min(t, Math.max(r, e)) : Math.min(r, Math.max(t, e)),
  round: (e) => Math.round(e * 1e10) / 1e10
}, s0 = {
  /* API */
  dec2hex: (e) => {
    const t = Math.round(e).toString(16);
    return t.length > 1 ? t : `0${t}`;
  }
}, it = {
  channel: vn,
  lang: a0,
  unit: s0
}, We = {};
for (let e = 0; e <= 255; e++)
  We[e] = it.unit.dec2hex(e);
const Rt = {
  ALL: 0,
  RGB: 1,
  HSL: 2
};
class o0 {
  constructor() {
    this.type = Rt.ALL;
  }
  /* API */
  get() {
    return this.type;
  }
  set(t) {
    if (this.type && this.type !== t)
      throw new Error("Cannot change both RGB and HSL channels at the same time");
    this.type = t;
  }
  reset() {
    this.type = Rt.ALL;
  }
  is(t) {
    return this.type === t;
  }
}
class l0 {
  /* CONSTRUCTOR */
  constructor(t, r) {
    this.color = r, this.changed = !1, this.data = t, this.type = new o0();
  }
  /* API */
  set(t, r) {
    return this.color = r, this.changed = !1, this.data = t, this.type.type = Rt.ALL, this;
  }
  /* HELPERS */
  _ensureHSL() {
    const t = this.data, { h: r, s: i, l: n } = t;
    r === void 0 && (t.h = it.channel.rgb2hsl(t, "h")), i === void 0 && (t.s = it.channel.rgb2hsl(t, "s")), n === void 0 && (t.l = it.channel.rgb2hsl(t, "l"));
  }
  _ensureRGB() {
    const t = this.data, { r, g: i, b: n } = t;
    r === void 0 && (t.r = it.channel.hsl2rgb(t, "r")), i === void 0 && (t.g = it.channel.hsl2rgb(t, "g")), n === void 0 && (t.b = it.channel.hsl2rgb(t, "b"));
  }
  /* GETTERS */
  get r() {
    const t = this.data, r = t.r;
    return !this.type.is(Rt.HSL) && r !== void 0 ? r : (this._ensureHSL(), it.channel.hsl2rgb(t, "r"));
  }
  get g() {
    const t = this.data, r = t.g;
    return !this.type.is(Rt.HSL) && r !== void 0 ? r : (this._ensureHSL(), it.channel.hsl2rgb(t, "g"));
  }
  get b() {
    const t = this.data, r = t.b;
    return !this.type.is(Rt.HSL) && r !== void 0 ? r : (this._ensureHSL(), it.channel.hsl2rgb(t, "b"));
  }
  get h() {
    const t = this.data, r = t.h;
    return !this.type.is(Rt.RGB) && r !== void 0 ? r : (this._ensureRGB(), it.channel.rgb2hsl(t, "h"));
  }
  get s() {
    const t = this.data, r = t.s;
    return !this.type.is(Rt.RGB) && r !== void 0 ? r : (this._ensureRGB(), it.channel.rgb2hsl(t, "s"));
  }
  get l() {
    const t = this.data, r = t.l;
    return !this.type.is(Rt.RGB) && r !== void 0 ? r : (this._ensureRGB(), it.channel.rgb2hsl(t, "l"));
  }
  get a() {
    return this.data.a;
  }
  /* SETTERS */
  set r(t) {
    this.type.set(Rt.RGB), this.changed = !0, this.data.r = t;
  }
  set g(t) {
    this.type.set(Rt.RGB), this.changed = !0, this.data.g = t;
  }
  set b(t) {
    this.type.set(Rt.RGB), this.changed = !0, this.data.b = t;
  }
  set h(t) {
    this.type.set(Rt.HSL), this.changed = !0, this.data.h = t;
  }
  set s(t) {
    this.type.set(Rt.HSL), this.changed = !0, this.data.s = t;
  }
  set l(t) {
    this.type.set(Rt.HSL), this.changed = !0, this.data.l = t;
  }
  set a(t) {
    this.changed = !0, this.data.a = t;
  }
}
const Ca = new l0({ r: 0, g: 0, b: 0, a: 0 }, "transparent"), Or = {
  /* VARIABLES */
  re: /^#((?:[a-f0-9]{2}){2,4}|[a-f0-9]{3})$/i,
  /* API */
  parse: (e) => {
    if (e.charCodeAt(0) !== 35)
      return;
    const t = e.match(Or.re);
    if (!t)
      return;
    const r = t[1], i = parseInt(r, 16), n = r.length, a = n % 4 === 0, o = n > 4, s = o ? 1 : 17, l = o ? 8 : 4, c = a ? 0 : -1, h = o ? 255 : 15;
    return Ca.set({
      r: (i >> l * (c + 3) & h) * s,
      g: (i >> l * (c + 2) & h) * s,
      b: (i >> l * (c + 1) & h) * s,
      a: a ? (i & h) * s / 255 : 1
    }, e);
  },
  stringify: (e) => {
    const { r: t, g: r, b: i, a: n } = e;
    return n < 1 ? `#${We[Math.round(t)]}${We[Math.round(r)]}${We[Math.round(i)]}${We[Math.round(n * 255)]}` : `#${We[Math.round(t)]}${We[Math.round(r)]}${We[Math.round(i)]}`;
  }
}, ar = {
  /* VARIABLES */
  re: /^hsla?\(\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?(?:deg|grad|rad|turn)?)\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?%)\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?%)(?:\s*?(?:,|\/)\s*?\+?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?(%)?))?\s*?\)$/i,
  hueRe: /^(.+?)(deg|grad|rad|turn)$/i,
  /* HELPERS */
  _hue2deg: (e) => {
    const t = e.match(ar.hueRe);
    if (t) {
      const [, r, i] = t;
      switch (i) {
        case "grad":
          return it.channel.clamp.h(parseFloat(r) * 0.9);
        case "rad":
          return it.channel.clamp.h(parseFloat(r) * 180 / Math.PI);
        case "turn":
          return it.channel.clamp.h(parseFloat(r) * 360);
      }
    }
    return it.channel.clamp.h(parseFloat(e));
  },
  /* API */
  parse: (e) => {
    const t = e.charCodeAt(0);
    if (t !== 104 && t !== 72)
      return;
    const r = e.match(ar.re);
    if (!r)
      return;
    const [, i, n, a, o, s] = r;
    return Ca.set({
      h: ar._hue2deg(i),
      s: it.channel.clamp.s(parseFloat(n)),
      l: it.channel.clamp.l(parseFloat(a)),
      a: o ? it.channel.clamp.a(s ? parseFloat(o) / 100 : parseFloat(o)) : 1
    }, e);
  },
  stringify: (e) => {
    const { h: t, s: r, l: i, a: n } = e;
    return n < 1 ? `hsla(${it.lang.round(t)}, ${it.lang.round(r)}%, ${it.lang.round(i)}%, ${n})` : `hsl(${it.lang.round(t)}, ${it.lang.round(r)}%, ${it.lang.round(i)}%)`;
  }
}, Li = {
  /* VARIABLES */
  colors: {
    aliceblue: "#f0f8ff",
    antiquewhite: "#faebd7",
    aqua: "#00ffff",
    aquamarine: "#7fffd4",
    azure: "#f0ffff",
    beige: "#f5f5dc",
    bisque: "#ffe4c4",
    black: "#000000",
    blanchedalmond: "#ffebcd",
    blue: "#0000ff",
    blueviolet: "#8a2be2",
    brown: "#a52a2a",
    burlywood: "#deb887",
    cadetblue: "#5f9ea0",
    chartreuse: "#7fff00",
    chocolate: "#d2691e",
    coral: "#ff7f50",
    cornflowerblue: "#6495ed",
    cornsilk: "#fff8dc",
    crimson: "#dc143c",
    cyanaqua: "#00ffff",
    darkblue: "#00008b",
    darkcyan: "#008b8b",
    darkgoldenrod: "#b8860b",
    darkgray: "#a9a9a9",
    darkgreen: "#006400",
    darkgrey: "#a9a9a9",
    darkkhaki: "#bdb76b",
    darkmagenta: "#8b008b",
    darkolivegreen: "#556b2f",
    darkorange: "#ff8c00",
    darkorchid: "#9932cc",
    darkred: "#8b0000",
    darksalmon: "#e9967a",
    darkseagreen: "#8fbc8f",
    darkslateblue: "#483d8b",
    darkslategray: "#2f4f4f",
    darkslategrey: "#2f4f4f",
    darkturquoise: "#00ced1",
    darkviolet: "#9400d3",
    deeppink: "#ff1493",
    deepskyblue: "#00bfff",
    dimgray: "#696969",
    dimgrey: "#696969",
    dodgerblue: "#1e90ff",
    firebrick: "#b22222",
    floralwhite: "#fffaf0",
    forestgreen: "#228b22",
    fuchsia: "#ff00ff",
    gainsboro: "#dcdcdc",
    ghostwhite: "#f8f8ff",
    gold: "#ffd700",
    goldenrod: "#daa520",
    gray: "#808080",
    green: "#008000",
    greenyellow: "#adff2f",
    grey: "#808080",
    honeydew: "#f0fff0",
    hotpink: "#ff69b4",
    indianred: "#cd5c5c",
    indigo: "#4b0082",
    ivory: "#fffff0",
    khaki: "#f0e68c",
    lavender: "#e6e6fa",
    lavenderblush: "#fff0f5",
    lawngreen: "#7cfc00",
    lemonchiffon: "#fffacd",
    lightblue: "#add8e6",
    lightcoral: "#f08080",
    lightcyan: "#e0ffff",
    lightgoldenrodyellow: "#fafad2",
    lightgray: "#d3d3d3",
    lightgreen: "#90ee90",
    lightgrey: "#d3d3d3",
    lightpink: "#ffb6c1",
    lightsalmon: "#ffa07a",
    lightseagreen: "#20b2aa",
    lightskyblue: "#87cefa",
    lightslategray: "#778899",
    lightslategrey: "#778899",
    lightsteelblue: "#b0c4de",
    lightyellow: "#ffffe0",
    lime: "#00ff00",
    limegreen: "#32cd32",
    linen: "#faf0e6",
    magenta: "#ff00ff",
    maroon: "#800000",
    mediumaquamarine: "#66cdaa",
    mediumblue: "#0000cd",
    mediumorchid: "#ba55d3",
    mediumpurple: "#9370db",
    mediumseagreen: "#3cb371",
    mediumslateblue: "#7b68ee",
    mediumspringgreen: "#00fa9a",
    mediumturquoise: "#48d1cc",
    mediumvioletred: "#c71585",
    midnightblue: "#191970",
    mintcream: "#f5fffa",
    mistyrose: "#ffe4e1",
    moccasin: "#ffe4b5",
    navajowhite: "#ffdead",
    navy: "#000080",
    oldlace: "#fdf5e6",
    olive: "#808000",
    olivedrab: "#6b8e23",
    orange: "#ffa500",
    orangered: "#ff4500",
    orchid: "#da70d6",
    palegoldenrod: "#eee8aa",
    palegreen: "#98fb98",
    paleturquoise: "#afeeee",
    palevioletred: "#db7093",
    papayawhip: "#ffefd5",
    peachpuff: "#ffdab9",
    peru: "#cd853f",
    pink: "#ffc0cb",
    plum: "#dda0dd",
    powderblue: "#b0e0e6",
    purple: "#800080",
    rebeccapurple: "#663399",
    red: "#ff0000",
    rosybrown: "#bc8f8f",
    royalblue: "#4169e1",
    saddlebrown: "#8b4513",
    salmon: "#fa8072",
    sandybrown: "#f4a460",
    seagreen: "#2e8b57",
    seashell: "#fff5ee",
    sienna: "#a0522d",
    silver: "#c0c0c0",
    skyblue: "#87ceeb",
    slateblue: "#6a5acd",
    slategray: "#708090",
    slategrey: "#708090",
    snow: "#fffafa",
    springgreen: "#00ff7f",
    tan: "#d2b48c",
    teal: "#008080",
    thistle: "#d8bfd8",
    transparent: "#00000000",
    turquoise: "#40e0d0",
    violet: "#ee82ee",
    wheat: "#f5deb3",
    white: "#ffffff",
    whitesmoke: "#f5f5f5",
    yellow: "#ffff00",
    yellowgreen: "#9acd32"
  },
  /* API */
  parse: (e) => {
    e = e.toLowerCase();
    const t = Li.colors[e];
    if (t)
      return Or.parse(t);
  },
  stringify: (e) => {
    const t = Or.stringify(e);
    for (const r in Li.colors)
      if (Li.colors[r] === t)
        return r;
  }
}, Ci = {
  /* VARIABLES */
  re: /^rgba?\(\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))(?:\s*?(?:,|\/)\s*?\+?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?)))?\s*?\)$/i,
  /* API */
  parse: (e) => {
    const t = e.charCodeAt(0);
    if (t !== 114 && t !== 82)
      return;
    const r = e.match(Ci.re);
    if (!r)
      return;
    const [, i, n, a, o, s, l, c, h] = r;
    return Ca.set({
      r: it.channel.clamp.r(n ? parseFloat(i) * 2.55 : parseFloat(i)),
      g: it.channel.clamp.g(o ? parseFloat(a) * 2.55 : parseFloat(a)),
      b: it.channel.clamp.b(l ? parseFloat(s) * 2.55 : parseFloat(s)),
      a: c ? it.channel.clamp.a(h ? parseFloat(c) / 100 : parseFloat(c)) : 1
    }, e);
  },
  stringify: (e) => {
    const { r: t, g: r, b: i, a: n } = e;
    return n < 1 ? `rgba(${it.lang.round(t)}, ${it.lang.round(r)}, ${it.lang.round(i)}, ${it.lang.round(n)})` : `rgb(${it.lang.round(t)}, ${it.lang.round(r)}, ${it.lang.round(i)})`;
  }
}, ke = {
  /* VARIABLES */
  format: {
    keyword: Li,
    hex: Or,
    rgb: Ci,
    rgba: Ci,
    hsl: ar,
    hsla: ar
  },
  /* API */
  parse: (e) => {
    if (typeof e != "string")
      return e;
    const t = Or.parse(e) || Ci.parse(e) || ar.parse(e) || Li.parse(e);
    if (t)
      return t;
    throw new Error(`Unsupported color format: "${e}"`);
  },
  stringify: (e) => !e.changed && e.color ? e.color : e.type.is(Rt.HSL) || e.data.r === void 0 ? ar.stringify(e) : e.a < 1 || !Number.isInteger(e.r) || !Number.isInteger(e.g) || !Number.isInteger(e.b) ? Ci.stringify(e) : Or.stringify(e)
}, Sh = (e, t) => {
  const r = ke.parse(e);
  for (const i in t)
    r[i] = it.channel.clamp[i](t[i]);
  return ke.stringify(r);
}, Mi = (e, t, r = 0, i = 1) => {
  if (typeof e != "number")
    return Sh(e, { a: t });
  const n = Ca.set({
    r: it.channel.clamp.r(e),
    g: it.channel.clamp.g(t),
    b: it.channel.clamp.b(r),
    a: it.channel.clamp.a(i)
  });
  return ke.stringify(n);
}, c0 = (e) => {
  const { r: t, g: r, b: i } = ke.parse(e), n = 0.2126 * it.channel.toLinear(t) + 0.7152 * it.channel.toLinear(r) + 0.0722 * it.channel.toLinear(i);
  return it.lang.round(n);
}, h0 = (e) => c0(e) >= 0.5, Xi = (e) => !h0(e), Th = (e, t, r) => {
  const i = ke.parse(e), n = i[t], a = it.channel.clamp[t](n + r);
  return n !== a && (i[t] = a), ke.stringify(i);
}, j = (e, t) => Th(e, "l", t), J = (e, t) => Th(e, "l", -t), T = (e, t) => {
  const r = ke.parse(e), i = {};
  for (const n in t)
    t[n] && (i[n] = r[n] + t[n]);
  return Sh(e, i);
}, u0 = (e, t, r = 50) => {
  const { r: i, g: n, b: a, a: o } = ke.parse(e), { r: s, g: l, b: c, a: h } = ke.parse(t), u = r / 100, f = u * 2 - 1, p = o - h, m = ((f * p === -1 ? f : (f + p) / (1 + f * p)) + 1) / 2, y = 1 - m, x = i * m + s * y, b = n * m + l * y, _ = a * m + c * y, v = o * u + h * (1 - u);
  return Mi(x, b, _, v);
}, N = (e, t = 100) => {
  const r = ke.parse(e);
  return r.r = 255 - r.r, r.g = 255 - r.g, r.b = 255 - r.b, u0(r, e, t);
};
/*! @license DOMPurify 3.3.0 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.3.0/LICENSE */
const {
  entries: Bh,
  setPrototypeOf: Yl,
  isFrozen: f0,
  getPrototypeOf: p0,
  getOwnPropertyDescriptor: d0
} = Object;
let {
  freeze: Gt,
  seal: ae,
  create: ks
} = Object, {
  apply: vs,
  construct: Ss
} = typeof Reflect < "u" && Reflect;
Gt || (Gt = function(t) {
  return t;
});
ae || (ae = function(t) {
  return t;
});
vs || (vs = function(t, r) {
  for (var i = arguments.length, n = new Array(i > 2 ? i - 2 : 0), a = 2; a < i; a++)
    n[a - 2] = arguments[a];
  return t.apply(r, n);
});
Ss || (Ss = function(t) {
  for (var r = arguments.length, i = new Array(r > 1 ? r - 1 : 0), n = 1; n < r; n++)
    i[n - 1] = arguments[n];
  return new t(...i);
});
const un = Xt(Array.prototype.forEach), g0 = Xt(Array.prototype.lastIndexOf), Ul = Xt(Array.prototype.pop), ci = Xt(Array.prototype.push), m0 = Xt(Array.prototype.splice), Sn = Xt(String.prototype.toLowerCase), rs = Xt(String.prototype.toString), is = Xt(String.prototype.match), hi = Xt(String.prototype.replace), y0 = Xt(String.prototype.indexOf), x0 = Xt(String.prototype.trim), ce = Xt(Object.prototype.hasOwnProperty), Ht = Xt(RegExp.prototype.test), ui = b0(TypeError);
function Xt(e) {
  return function(t) {
    t instanceof RegExp && (t.lastIndex = 0);
    for (var r = arguments.length, i = new Array(r > 1 ? r - 1 : 0), n = 1; n < r; n++)
      i[n - 1] = arguments[n];
    return vs(e, t, i);
  };
}
function b0(e) {
  return function() {
    for (var t = arguments.length, r = new Array(t), i = 0; i < t; i++)
      r[i] = arguments[i];
    return Ss(e, r);
  };
}
function ot(e, t) {
  let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Sn;
  Yl && Yl(e, null);
  let i = t.length;
  for (; i--; ) {
    let n = t[i];
    if (typeof n == "string") {
      const a = r(n);
      a !== n && (f0(t) || (t[i] = a), n = a);
    }
    e[n] = !0;
  }
  return e;
}
function C0(e) {
  for (let t = 0; t < e.length; t++)
    ce(e, t) || (e[t] = null);
  return e;
}
function Ee(e) {
  const t = ks(null);
  for (const [r, i] of Bh(e))
    ce(e, r) && (Array.isArray(i) ? t[r] = C0(i) : i && typeof i == "object" && i.constructor === Object ? t[r] = Ee(i) : t[r] = i);
  return t;
}
function fi(e, t) {
  for (; e !== null; ) {
    const i = d0(e, t);
    if (i) {
      if (i.get)
        return Xt(i.get);
      if (typeof i.value == "function")
        return Xt(i.value);
    }
    e = p0(e);
  }
  function r() {
    return null;
  }
  return r;
}
const Gl = Gt(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "search", "section", "select", "shadow", "slot", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), ns = Gt(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "enterkeyhint", "exportparts", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "inputmode", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "part", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), as = Gt(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), _0 = Gt(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), ss = Gt(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), w0 = Gt(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Xl = Gt(["#text"]), Vl = Gt(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "exportparts", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inert", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "part", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "slot", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), os = Gt(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "mask-type", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), Zl = Gt(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), fn = Gt(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), k0 = ae(/\{\{[\w\W]*|[\w\W]*\}\}/gm), v0 = ae(/<%[\w\W]*|[\w\W]*%>/gm), S0 = ae(/\$\{[\w\W]*/gm), T0 = ae(/^data-[\-\w.\u00B7-\uFFFF]+$/), B0 = ae(/^aria-[\-\w]+$/), Ah = ae(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), A0 = ae(/^(?:\w+script|data):/i), L0 = ae(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), Lh = ae(/^html$/i), M0 = ae(/^[a-z][.\w]*(-[.\w]+)+$/i);
var Kl = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: B0,
  ATTR_WHITESPACE: L0,
  CUSTOM_ELEMENT: M0,
  DATA_ATTR: T0,
  DOCTYPE_NAME: Lh,
  ERB_EXPR: v0,
  IS_ALLOWED_URI: Ah,
  IS_SCRIPT_OR_DATA: A0,
  MUSTACHE_EXPR: k0,
  TMPLIT_EXPR: S0
});
const pi = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, $0 = function() {
  return typeof window > "u" ? null : window;
}, E0 = function(t, r) {
  if (typeof t != "object" || typeof t.createPolicy != "function")
    return null;
  let i = null;
  const n = "data-tt-policy-suffix";
  r && r.hasAttribute(n) && (i = r.getAttribute(n));
  const a = "dompurify" + (i ? "#" + i : "");
  try {
    return t.createPolicy(a, {
      createHTML(o) {
        return o;
      },
      createScriptURL(o) {
        return o;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + a + " could not be created."), null;
  }
}, Ql = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function Mh() {
  let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : $0();
  const t = (Q) => Mh(Q);
  if (t.version = "3.3.0", t.removed = [], !e || !e.document || e.document.nodeType !== pi.document || !e.Element)
    return t.isSupported = !1, t;
  let {
    document: r
  } = e;
  const i = r, n = i.currentScript, {
    DocumentFragment: a,
    HTMLTemplateElement: o,
    Node: s,
    Element: l,
    NodeFilter: c,
    NamedNodeMap: h = e.NamedNodeMap || e.MozNamedAttrMap,
    HTMLFormElement: u,
    DOMParser: f,
    trustedTypes: p
  } = e, g = l.prototype, m = fi(g, "cloneNode"), y = fi(g, "remove"), x = fi(g, "nextSibling"), b = fi(g, "childNodes"), _ = fi(g, "parentNode");
  if (typeof o == "function") {
    const Q = r.createElement("template");
    Q.content && Q.content.ownerDocument && (r = Q.content.ownerDocument);
  }
  let v, w = "";
  const {
    implementation: C,
    createNodeIterator: S,
    createDocumentFragment: D,
    getElementsByTagName: P
  } = r, {
    importNode: R
  } = i;
  let $ = Ql();
  t.isSupported = typeof Bh == "function" && typeof _ == "function" && C && C.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: z,
    ERB_EXPR: O,
    TMPLIT_EXPR: M,
    DATA_ATTR: A,
    ARIA_ATTR: B,
    IS_SCRIPT_OR_DATA: E,
    ATTR_WHITESPACE: L,
    CUSTOM_ELEMENT: W
  } = Kl;
  let {
    IS_ALLOWED_URI: X
  } = Kl, H = null;
  const ut = ot({}, [...Gl, ...ns, ...as, ...ss, ...Xl]);
  let nt = null;
  const gt = ot({}, [...Vl, ...os, ...Zl, ...fn]);
  let st = Object.seal(ks(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), at = null, ct = null;
  const yt = Object.seal(ks(null, {
    tagCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    }
  }));
  let Ct = !0, xt = !0, vt = !1, le = !0, ie = !1, ze = !0, Je = !1, Ga = !1, Xa = !1, vr = !1, an = !1, sn = !1, Tl = !0, Bl = !1;
  const jm = "user-content-";
  let Va = !0, oi = !1, Sr = {}, Tr = null;
  const Al = ot({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let Ll = null;
  const Ml = ot({}, ["audio", "video", "img", "source", "image", "track"]);
  let Za = null;
  const $l = ot({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), on = "http://www.w3.org/1998/Math/MathML", ln = "http://www.w3.org/2000/svg", Be = "http://www.w3.org/1999/xhtml";
  let Br = Be, Ka = !1, Qa = null;
  const Ym = ot({}, [on, ln, Be], rs);
  let cn = ot({}, ["mi", "mo", "mn", "ms", "mtext"]), hn = ot({}, ["annotation-xml"]);
  const Um = ot({}, ["title", "style", "font", "a", "script"]);
  let li = null;
  const Gm = ["application/xhtml+xml", "text/html"], Xm = "text/html";
  let Mt = null, Ar = null;
  const Vm = r.createElement("form"), El = function(k) {
    return k instanceof RegExp || k instanceof Function;
  }, Ja = function() {
    let k = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(Ar && Ar === k)) {
      if ((!k || typeof k != "object") && (k = {}), k = Ee(k), li = // eslint-disable-next-line unicorn/prefer-includes
      Gm.indexOf(k.PARSER_MEDIA_TYPE) === -1 ? Xm : k.PARSER_MEDIA_TYPE, Mt = li === "application/xhtml+xml" ? rs : Sn, H = ce(k, "ALLOWED_TAGS") ? ot({}, k.ALLOWED_TAGS, Mt) : ut, nt = ce(k, "ALLOWED_ATTR") ? ot({}, k.ALLOWED_ATTR, Mt) : gt, Qa = ce(k, "ALLOWED_NAMESPACES") ? ot({}, k.ALLOWED_NAMESPACES, rs) : Ym, Za = ce(k, "ADD_URI_SAFE_ATTR") ? ot(Ee($l), k.ADD_URI_SAFE_ATTR, Mt) : $l, Ll = ce(k, "ADD_DATA_URI_TAGS") ? ot(Ee(Ml), k.ADD_DATA_URI_TAGS, Mt) : Ml, Tr = ce(k, "FORBID_CONTENTS") ? ot({}, k.FORBID_CONTENTS, Mt) : Al, at = ce(k, "FORBID_TAGS") ? ot({}, k.FORBID_TAGS, Mt) : Ee({}), ct = ce(k, "FORBID_ATTR") ? ot({}, k.FORBID_ATTR, Mt) : Ee({}), Sr = ce(k, "USE_PROFILES") ? k.USE_PROFILES : !1, Ct = k.ALLOW_ARIA_ATTR !== !1, xt = k.ALLOW_DATA_ATTR !== !1, vt = k.ALLOW_UNKNOWN_PROTOCOLS || !1, le = k.ALLOW_SELF_CLOSE_IN_ATTR !== !1, ie = k.SAFE_FOR_TEMPLATES || !1, ze = k.SAFE_FOR_XML !== !1, Je = k.WHOLE_DOCUMENT || !1, vr = k.RETURN_DOM || !1, an = k.RETURN_DOM_FRAGMENT || !1, sn = k.RETURN_TRUSTED_TYPE || !1, Xa = k.FORCE_BODY || !1, Tl = k.SANITIZE_DOM !== !1, Bl = k.SANITIZE_NAMED_PROPS || !1, Va = k.KEEP_CONTENT !== !1, oi = k.IN_PLACE || !1, X = k.ALLOWED_URI_REGEXP || Ah, Br = k.NAMESPACE || Be, cn = k.MATHML_TEXT_INTEGRATION_POINTS || cn, hn = k.HTML_INTEGRATION_POINTS || hn, st = k.CUSTOM_ELEMENT_HANDLING || {}, k.CUSTOM_ELEMENT_HANDLING && El(k.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (st.tagNameCheck = k.CUSTOM_ELEMENT_HANDLING.tagNameCheck), k.CUSTOM_ELEMENT_HANDLING && El(k.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (st.attributeNameCheck = k.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), k.CUSTOM_ELEMENT_HANDLING && typeof k.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (st.allowCustomizedBuiltInElements = k.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), ie && (xt = !1), an && (vr = !0), Sr && (H = ot({}, Xl), nt = [], Sr.html === !0 && (ot(H, Gl), ot(nt, Vl)), Sr.svg === !0 && (ot(H, ns), ot(nt, os), ot(nt, fn)), Sr.svgFilters === !0 && (ot(H, as), ot(nt, os), ot(nt, fn)), Sr.mathMl === !0 && (ot(H, ss), ot(nt, Zl), ot(nt, fn))), k.ADD_TAGS && (typeof k.ADD_TAGS == "function" ? yt.tagCheck = k.ADD_TAGS : (H === ut && (H = Ee(H)), ot(H, k.ADD_TAGS, Mt))), k.ADD_ATTR && (typeof k.ADD_ATTR == "function" ? yt.attributeCheck = k.ADD_ATTR : (nt === gt && (nt = Ee(nt)), ot(nt, k.ADD_ATTR, Mt))), k.ADD_URI_SAFE_ATTR && ot(Za, k.ADD_URI_SAFE_ATTR, Mt), k.FORBID_CONTENTS && (Tr === Al && (Tr = Ee(Tr)), ot(Tr, k.FORBID_CONTENTS, Mt)), Va && (H["#text"] = !0), Je && ot(H, ["html", "head", "body"]), H.table && (ot(H, ["tbody"]), delete at.tbody), k.TRUSTED_TYPES_POLICY) {
        if (typeof k.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw ui('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof k.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw ui('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        v = k.TRUSTED_TYPES_POLICY, w = v.createHTML("");
      } else
        v === void 0 && (v = E0(p, n)), v !== null && typeof w == "string" && (w = v.createHTML(""));
      Gt && Gt(k), Ar = k;
    }
  }, Fl = ot({}, [...ns, ...as, ..._0]), Dl = ot({}, [...ss, ...w0]), Zm = function(k) {
    let I = _(k);
    (!I || !I.tagName) && (I = {
      namespaceURI: Br,
      tagName: "template"
    });
    const Z = Sn(k.tagName), _t = Sn(I.tagName);
    return Qa[k.namespaceURI] ? k.namespaceURI === ln ? I.namespaceURI === Be ? Z === "svg" : I.namespaceURI === on ? Z === "svg" && (_t === "annotation-xml" || cn[_t]) : !!Fl[Z] : k.namespaceURI === on ? I.namespaceURI === Be ? Z === "math" : I.namespaceURI === ln ? Z === "math" && hn[_t] : !!Dl[Z] : k.namespaceURI === Be ? I.namespaceURI === ln && !hn[_t] || I.namespaceURI === on && !cn[_t] ? !1 : !Dl[Z] && (Um[Z] || !Fl[Z]) : !!(li === "application/xhtml+xml" && Qa[k.namespaceURI]) : !1;
  }, ye = function(k) {
    ci(t.removed, {
      element: k
    });
    try {
      _(k).removeChild(k);
    } catch {
      y(k);
    }
  }, tr = function(k, I) {
    try {
      ci(t.removed, {
        attribute: I.getAttributeNode(k),
        from: I
      });
    } catch {
      ci(t.removed, {
        attribute: null,
        from: I
      });
    }
    if (I.removeAttribute(k), k === "is")
      if (vr || an)
        try {
          ye(I);
        } catch {
        }
      else
        try {
          I.setAttribute(k, "");
        } catch {
        }
  }, Ol = function(k) {
    let I = null, Z = null;
    if (Xa)
      k = "<remove></remove>" + k;
    else {
      const St = is(k, /^[\r\n\t ]+/);
      Z = St && St[0];
    }
    li === "application/xhtml+xml" && Br === Be && (k = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + k + "</body></html>");
    const _t = v ? v.createHTML(k) : k;
    if (Br === Be)
      try {
        I = new f().parseFromString(_t, li);
      } catch {
      }
    if (!I || !I.documentElement) {
      I = C.createDocument(Br, "template", null);
      try {
        I.documentElement.innerHTML = Ka ? w : _t;
      } catch {
      }
    }
    const Ot = I.body || I.documentElement;
    return k && Z && Ot.insertBefore(r.createTextNode(Z), Ot.childNodes[0] || null), Br === Be ? P.call(I, Je ? "html" : "body")[0] : Je ? I.documentElement : Ot;
  }, Rl = function(k) {
    return S.call(
      k.ownerDocument || k,
      k,
      // eslint-disable-next-line no-bitwise
      c.SHOW_ELEMENT | c.SHOW_COMMENT | c.SHOW_TEXT | c.SHOW_PROCESSING_INSTRUCTION | c.SHOW_CDATA_SECTION,
      null
    );
  }, ts = function(k) {
    return k instanceof u && (typeof k.nodeName != "string" || typeof k.textContent != "string" || typeof k.removeChild != "function" || !(k.attributes instanceof h) || typeof k.removeAttribute != "function" || typeof k.setAttribute != "function" || typeof k.namespaceURI != "string" || typeof k.insertBefore != "function" || typeof k.hasChildNodes != "function");
  }, Il = function(k) {
    return typeof s == "function" && k instanceof s;
  };
  function Ae(Q, k, I) {
    un(Q, (Z) => {
      Z.call(t, k, I, Ar);
    });
  }
  const Pl = function(k) {
    let I = null;
    if (Ae($.beforeSanitizeElements, k, null), ts(k))
      return ye(k), !0;
    const Z = Mt(k.nodeName);
    if (Ae($.uponSanitizeElement, k, {
      tagName: Z,
      allowedTags: H
    }), ze && k.hasChildNodes() && !Il(k.firstElementChild) && Ht(/<[/\w!]/g, k.innerHTML) && Ht(/<[/\w!]/g, k.textContent) || k.nodeType === pi.progressingInstruction || ze && k.nodeType === pi.comment && Ht(/<[/\w]/g, k.data))
      return ye(k), !0;
    if (!(yt.tagCheck instanceof Function && yt.tagCheck(Z)) && (!H[Z] || at[Z])) {
      if (!at[Z] && zl(Z) && (st.tagNameCheck instanceof RegExp && Ht(st.tagNameCheck, Z) || st.tagNameCheck instanceof Function && st.tagNameCheck(Z)))
        return !1;
      if (Va && !Tr[Z]) {
        const _t = _(k) || k.parentNode, Ot = b(k) || k.childNodes;
        if (Ot && _t) {
          const St = Ot.length;
          for (let Vt = St - 1; Vt >= 0; --Vt) {
            const Le = m(Ot[Vt], !0);
            Le.__removalCount = (k.__removalCount || 0) + 1, _t.insertBefore(Le, x(k));
          }
        }
      }
      return ye(k), !0;
    }
    return k instanceof l && !Zm(k) || (Z === "noscript" || Z === "noembed" || Z === "noframes") && Ht(/<\/no(script|embed|frames)/i, k.innerHTML) ? (ye(k), !0) : (ie && k.nodeType === pi.text && (I = k.textContent, un([z, O, M], (_t) => {
      I = hi(I, _t, " ");
    }), k.textContent !== I && (ci(t.removed, {
      element: k.cloneNode()
    }), k.textContent = I)), Ae($.afterSanitizeElements, k, null), !1);
  }, Nl = function(k, I, Z) {
    if (Tl && (I === "id" || I === "name") && (Z in r || Z in Vm))
      return !1;
    if (!(xt && !ct[I] && Ht(A, I))) {
      if (!(Ct && Ht(B, I))) {
        if (!(yt.attributeCheck instanceof Function && yt.attributeCheck(I, k))) {
          if (!nt[I] || ct[I]) {
            if (
              // First condition does a very basic check if a) it's basically a valid custom element tagname AND
              // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
              // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
              !(zl(k) && (st.tagNameCheck instanceof RegExp && Ht(st.tagNameCheck, k) || st.tagNameCheck instanceof Function && st.tagNameCheck(k)) && (st.attributeNameCheck instanceof RegExp && Ht(st.attributeNameCheck, I) || st.attributeNameCheck instanceof Function && st.attributeNameCheck(I, k)) || // Alternative, second condition checks if it's an `is`-attribute, AND
              // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
              I === "is" && st.allowCustomizedBuiltInElements && (st.tagNameCheck instanceof RegExp && Ht(st.tagNameCheck, Z) || st.tagNameCheck instanceof Function && st.tagNameCheck(Z)))
            ) return !1;
          } else if (!Za[I]) {
            if (!Ht(X, hi(Z, L, ""))) {
              if (!((I === "src" || I === "xlink:href" || I === "href") && k !== "script" && y0(Z, "data:") === 0 && Ll[k])) {
                if (!(vt && !Ht(E, hi(Z, L, "")))) {
                  if (Z)
                    return !1;
                }
              }
            }
          }
        }
      }
    }
    return !0;
  }, zl = function(k) {
    return k !== "annotation-xml" && is(k, W);
  }, Wl = function(k) {
    Ae($.beforeSanitizeAttributes, k, null);
    const {
      attributes: I
    } = k;
    if (!I || ts(k))
      return;
    const Z = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: nt,
      forceKeepAttr: void 0
    };
    let _t = I.length;
    for (; _t--; ) {
      const Ot = I[_t], {
        name: St,
        namespaceURI: Vt,
        value: Le
      } = Ot, Lr = Mt(St), es = Le;
      let Et = St === "value" ? es : x0(es);
      if (Z.attrName = Lr, Z.attrValue = Et, Z.keepAttr = !0, Z.forceKeepAttr = void 0, Ae($.uponSanitizeAttribute, k, Z), Et = Z.attrValue, Bl && (Lr === "id" || Lr === "name") && (tr(St, k), Et = jm + Et), ze && Ht(/((--!?|])>)|<\/(style|title|textarea)/i, Et)) {
        tr(St, k);
        continue;
      }
      if (Lr === "attributename" && is(Et, "href")) {
        tr(St, k);
        continue;
      }
      if (Z.forceKeepAttr)
        continue;
      if (!Z.keepAttr) {
        tr(St, k);
        continue;
      }
      if (!le && Ht(/\/>/i, Et)) {
        tr(St, k);
        continue;
      }
      ie && un([z, O, M], (Hl) => {
        Et = hi(Et, Hl, " ");
      });
      const ql = Mt(k.nodeName);
      if (!Nl(ql, Lr, Et)) {
        tr(St, k);
        continue;
      }
      if (v && typeof p == "object" && typeof p.getAttributeType == "function" && !Vt)
        switch (p.getAttributeType(ql, Lr)) {
          case "TrustedHTML": {
            Et = v.createHTML(Et);
            break;
          }
          case "TrustedScriptURL": {
            Et = v.createScriptURL(Et);
            break;
          }
        }
      if (Et !== es)
        try {
          Vt ? k.setAttributeNS(Vt, St, Et) : k.setAttribute(St, Et), ts(k) ? ye(k) : Ul(t.removed);
        } catch {
          tr(St, k);
        }
    }
    Ae($.afterSanitizeAttributes, k, null);
  }, Km = function Q(k) {
    let I = null;
    const Z = Rl(k);
    for (Ae($.beforeSanitizeShadowDOM, k, null); I = Z.nextNode(); )
      Ae($.uponSanitizeShadowNode, I, null), Pl(I), Wl(I), I.content instanceof a && Q(I.content);
    Ae($.afterSanitizeShadowDOM, k, null);
  };
  return t.sanitize = function(Q) {
    let k = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, I = null, Z = null, _t = null, Ot = null;
    if (Ka = !Q, Ka && (Q = "<!-->"), typeof Q != "string" && !Il(Q))
      if (typeof Q.toString == "function") {
        if (Q = Q.toString(), typeof Q != "string")
          throw ui("dirty is not a string, aborting");
      } else
        throw ui("toString is not a function");
    if (!t.isSupported)
      return Q;
    if (Ga || Ja(k), t.removed = [], typeof Q == "string" && (oi = !1), oi) {
      if (Q.nodeName) {
        const Le = Mt(Q.nodeName);
        if (!H[Le] || at[Le])
          throw ui("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (Q instanceof s)
      I = Ol("<!---->"), Z = I.ownerDocument.importNode(Q, !0), Z.nodeType === pi.element && Z.nodeName === "BODY" || Z.nodeName === "HTML" ? I = Z : I.appendChild(Z);
    else {
      if (!vr && !ie && !Je && // eslint-disable-next-line unicorn/prefer-includes
      Q.indexOf("<") === -1)
        return v && sn ? v.createHTML(Q) : Q;
      if (I = Ol(Q), !I)
        return vr ? null : sn ? w : "";
    }
    I && Xa && ye(I.firstChild);
    const St = Rl(oi ? Q : I);
    for (; _t = St.nextNode(); )
      Pl(_t), Wl(_t), _t.content instanceof a && Km(_t.content);
    if (oi)
      return Q;
    if (vr) {
      if (an)
        for (Ot = D.call(I.ownerDocument); I.firstChild; )
          Ot.appendChild(I.firstChild);
      else
        Ot = I;
      return (nt.shadowroot || nt.shadowrootmode) && (Ot = R.call(i, Ot, !0)), Ot;
    }
    let Vt = Je ? I.outerHTML : I.innerHTML;
    return Je && H["!doctype"] && I.ownerDocument && I.ownerDocument.doctype && I.ownerDocument.doctype.name && Ht(Lh, I.ownerDocument.doctype.name) && (Vt = "<!DOCTYPE " + I.ownerDocument.doctype.name + `>
` + Vt), ie && un([z, O, M], (Le) => {
      Vt = hi(Vt, Le, " ");
    }), v && sn ? v.createHTML(Vt) : Vt;
  }, t.setConfig = function() {
    let Q = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    Ja(Q), Ga = !0;
  }, t.clearConfig = function() {
    Ar = null, Ga = !1;
  }, t.isValidAttribute = function(Q, k, I) {
    Ar || Ja({});
    const Z = Mt(Q), _t = Mt(k);
    return Nl(Z, _t, I);
  }, t.addHook = function(Q, k) {
    typeof k == "function" && ci($[Q], k);
  }, t.removeHook = function(Q, k) {
    if (k !== void 0) {
      const I = g0($[Q], k);
      return I === -1 ? void 0 : m0($[Q], I, 1)[0];
    }
    return Ul($[Q]);
  }, t.removeHooks = function(Q) {
    $[Q] = [];
  }, t.removeAllHooks = function() {
    $ = Ql();
  }, t;
}
var Ur = Mh(), $h = /^-{3}\s*[\n\r](.*?)[\n\r]-{3}\s*[\n\r]+/s, $i = /%{2}{\s*(?:(\w+)\s*:|(\w+))\s*(?:(\w+)|((?:(?!}%{2}).|\r?\n)*))?\s*(?:}%{2})?/gi, F0 = /\s*%%.*\n/gm, Pr, Eh = (Pr = class extends Error {
  constructor(t) {
    super(t), this.name = "UnknownDiagramError";
  }
}, d(Pr, "UnknownDiagramError"), Pr), fr = {}, vo = /* @__PURE__ */ d(function(e, t) {
  e = e.replace($h, "").replace($i, "").replace(F0, `
`);
  for (const [r, { detector: i }] of Object.entries(fr))
    if (i(e, t))
      return r;
  throw new Eh(
    `No diagram type detected matching given configuration for text: ${e}`
  );
}, "detectType"), Ts = /* @__PURE__ */ d((...e) => {
  for (const { id: t, detector: r, loader: i } of e)
    Fh(t, r, i);
}, "registerLazyLoadedDiagrams"), Fh = /* @__PURE__ */ d((e, t, r) => {
  fr[e] && F.warn(`Detector with key ${e} already exists. Overwriting.`), fr[e] = { detector: t, loader: r }, F.debug(`Detector with key ${e} added${r ? " with loader" : ""}`);
}, "addDetector"), D0 = /* @__PURE__ */ d((e) => fr[e].loader, "getDiagramLoader"), Bs = /* @__PURE__ */ d((e, t, { depth: r = 2, clobber: i = !1 } = {}) => {
  const n = { depth: r, clobber: i };
  return Array.isArray(t) && !Array.isArray(e) ? (t.forEach((a) => Bs(e, a, n)), e) : Array.isArray(t) && Array.isArray(e) ? (t.forEach((a) => {
    e.includes(a) || e.push(a);
  }), e) : e === void 0 || r <= 0 ? e != null && typeof e == "object" && typeof t == "object" ? Object.assign(e, t) : t : (t !== void 0 && typeof e == "object" && typeof t == "object" && Object.keys(t).forEach((a) => {
    typeof t[a] == "object" && (e[a] === void 0 || typeof e[a] == "object") ? (e[a] === void 0 && (e[a] = Array.isArray(t[a]) ? [] : {}), e[a] = Bs(e[a], t[a], { depth: r - 1, clobber: i })) : (i || typeof e[a] != "object" && typeof t[a] != "object") && (e[a] = t[a]);
  }), e);
}, "assignWithDepth"), Bt = Bs, _a = "#ffffff", wa = "#f2f2f2", jt = /* @__PURE__ */ d((e, t) => t ? T(e, { s: -40, l: 10 }) : T(e, { s: -40, l: -10 }), "mkBorder"), Nr, O0 = (Nr = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#fff4dd", this.noteBkgColor = "#fff5ad", this.noteTextColor = "#333", this.THEME_COLOR_LIMIT = 12, this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px";
  }
  updateColors() {
    var r, i, n, a, o, s, l, c, h, u, f, p, g, m, y, x, b, _, v, w, C;
    if (this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#333"), this.secondaryColor = this.secondaryColor || T(this.primaryColor, { h: -120 }), this.tertiaryColor = this.tertiaryColor || T(this.primaryColor, { h: 180, l: 5 }), this.primaryBorderColor = this.primaryBorderColor || jt(this.primaryColor, this.darkMode), this.secondaryBorderColor = this.secondaryBorderColor || jt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = this.tertiaryBorderColor || jt(this.tertiaryColor, this.darkMode), this.noteBorderColor = this.noteBorderColor || jt(this.noteBkgColor, this.darkMode), this.noteBkgColor = this.noteBkgColor || "#fff5ad", this.noteTextColor = this.noteTextColor || "#333", this.secondaryTextColor = this.secondaryTextColor || N(this.secondaryColor), this.tertiaryTextColor = this.tertiaryTextColor || N(this.tertiaryColor), this.lineColor = this.lineColor || N(this.background), this.arrowheadColor = this.arrowheadColor || N(this.background), this.textColor = this.textColor || this.primaryTextColor, this.border2 = this.border2 || this.tertiaryBorderColor, this.nodeBkg = this.nodeBkg || this.primaryColor, this.mainBkg = this.mainBkg || this.primaryColor, this.nodeBorder = this.nodeBorder || this.primaryBorderColor, this.clusterBkg = this.clusterBkg || this.tertiaryColor, this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor, this.defaultLinkColor = this.defaultLinkColor || this.lineColor, this.titleColor = this.titleColor || this.tertiaryTextColor, this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? J(this.secondaryColor, 30) : this.secondaryColor), this.nodeTextColor = this.nodeTextColor || this.primaryTextColor, this.actorBorder = this.actorBorder || this.primaryBorderColor, this.actorBkg = this.actorBkg || this.mainBkg, this.actorTextColor = this.actorTextColor || this.primaryTextColor, this.actorLineColor = this.actorLineColor || this.actorBorder, this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg, this.signalColor = this.signalColor || this.textColor, this.signalTextColor = this.signalTextColor || this.textColor, this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder, this.labelTextColor = this.labelTextColor || this.actorTextColor, this.loopTextColor = this.loopTextColor || this.actorTextColor, this.activationBorderColor = this.activationBorderColor || J(this.secondaryColor, 10), this.activationBkgColor = this.activationBkgColor || this.secondaryColor, this.sequenceNumberColor = this.sequenceNumberColor || N(this.lineColor), this.sectionBkgColor = this.sectionBkgColor || this.tertiaryColor, this.altSectionBkgColor = this.altSectionBkgColor || "white", this.sectionBkgColor = this.sectionBkgColor || this.secondaryColor, this.sectionBkgColor2 = this.sectionBkgColor2 || this.primaryColor, this.excludeBkgColor = this.excludeBkgColor || "#eeeeee", this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor, this.taskBkgColor = this.taskBkgColor || this.primaryColor, this.activeTaskBorderColor = this.activeTaskBorderColor || this.primaryColor, this.activeTaskBkgColor = this.activeTaskBkgColor || j(this.primaryColor, 23), this.gridColor = this.gridColor || "lightgrey", this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey", this.doneTaskBorderColor = this.doneTaskBorderColor || "grey", this.critBorderColor = this.critBorderColor || "#ff8888", this.critBkgColor = this.critBkgColor || "red", this.todayLineColor = this.todayLineColor || "red", this.vertLineColor = this.vertLineColor || "navy", this.taskTextColor = this.taskTextColor || this.textColor, this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor, this.taskTextLightColor = this.taskTextLightColor || this.textColor, this.taskTextColor = this.taskTextColor || this.primaryTextColor, this.taskTextDarkColor = this.taskTextDarkColor || this.textColor, this.taskTextClickableColor = this.taskTextClickableColor || "#003163", this.personBorder = this.personBorder || this.primaryBorderColor, this.personBkg = this.personBkg || this.mainBkg, this.darkMode ? (this.rowOdd = this.rowOdd || J(this.mainBkg, 5) || "#ffffff", this.rowEven = this.rowEven || J(this.mainBkg, 10)) : (this.rowOdd = this.rowOdd || j(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || j(this.mainBkg, 5)), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || this.tertiaryColor, this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.nodeBorder, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.specialStateColor = this.lineColor, this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || T(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || T(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || T(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || T(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || T(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || T(this.primaryColor, { h: 210, l: 150 }), this.cScale9 = this.cScale9 || T(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || T(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || T(this.primaryColor, { h: 330 }), this.darkMode)
      for (let S = 0; S < this.THEME_COLOR_LIMIT; S++)
        this["cScale" + S] = J(this["cScale" + S], 75);
    else
      for (let S = 0; S < this.THEME_COLOR_LIMIT; S++)
        this["cScale" + S] = J(this["cScale" + S], 25);
    for (let S = 0; S < this.THEME_COLOR_LIMIT; S++)
      this["cScaleInv" + S] = this["cScaleInv" + S] || N(this["cScale" + S]);
    for (let S = 0; S < this.THEME_COLOR_LIMIT; S++)
      this.darkMode ? this["cScalePeer" + S] = this["cScalePeer" + S] || j(this["cScale" + S], 10) : this["cScalePeer" + S] = this["cScalePeer" + S] || J(this["cScale" + S], 10);
    this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
    for (let S = 0; S < this.THEME_COLOR_LIMIT; S++)
      this["cScaleLabel" + S] = this["cScaleLabel" + S] || this.scaleLabelColor;
    const t = this.darkMode ? -4 : -1;
    for (let S = 0; S < 5; S++)
      this["surface" + S] = this["surface" + S] || T(this.mainBkg, { h: 180, s: -15, l: t * (5 + S * 3) }), this["surfacePeer" + S] = this["surfacePeer" + S] || T(this.mainBkg, { h: 180, s: -15, l: t * (8 + S * 3) });
    this.classText = this.classText || this.textColor, this.fillType0 = this.fillType0 || this.primaryColor, this.fillType1 = this.fillType1 || this.secondaryColor, this.fillType2 = this.fillType2 || T(this.primaryColor, { h: 64 }), this.fillType3 = this.fillType3 || T(this.secondaryColor, { h: 64 }), this.fillType4 = this.fillType4 || T(this.primaryColor, { h: -64 }), this.fillType5 = this.fillType5 || T(this.secondaryColor, { h: -64 }), this.fillType6 = this.fillType6 || T(this.primaryColor, { h: 128 }), this.fillType7 = this.fillType7 || T(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || this.tertiaryColor, this.pie4 = this.pie4 || T(this.primaryColor, { l: -10 }), this.pie5 = this.pie5 || T(this.secondaryColor, { l: -10 }), this.pie6 = this.pie6 || T(this.tertiaryColor, { l: -10 }), this.pie7 = this.pie7 || T(this.primaryColor, { h: 60, l: -10 }), this.pie8 = this.pie8 || T(this.primaryColor, { h: -60, l: -10 }), this.pie9 = this.pie9 || T(this.primaryColor, { h: 120, l: 0 }), this.pie10 = this.pie10 || T(this.primaryColor, { h: 60, l: -20 }), this.pie11 = this.pie11 || T(this.primaryColor, { h: -60, l: -20 }), this.pie12 = this.pie12 || T(this.primaryColor, { h: 120, l: -10 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.radar = {
      axisColor: ((r = this.radar) == null ? void 0 : r.axisColor) || this.lineColor,
      axisStrokeWidth: ((i = this.radar) == null ? void 0 : i.axisStrokeWidth) || 2,
      axisLabelFontSize: ((n = this.radar) == null ? void 0 : n.axisLabelFontSize) || 12,
      curveOpacity: ((a = this.radar) == null ? void 0 : a.curveOpacity) || 0.5,
      curveStrokeWidth: ((o = this.radar) == null ? void 0 : o.curveStrokeWidth) || 2,
      graticuleColor: ((s = this.radar) == null ? void 0 : s.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((l = this.radar) == null ? void 0 : l.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((c = this.radar) == null ? void 0 : c.graticuleOpacity) || 0.3,
      legendBoxSize: ((h = this.radar) == null ? void 0 : h.legendBoxSize) || 12,
      legendFontSize: ((u = this.radar) == null ? void 0 : u.legendFontSize) || 12
    }, this.archEdgeColor = this.archEdgeColor || "#777", this.archEdgeArrowColor = this.archEdgeArrowColor || "#777", this.archEdgeWidth = this.archEdgeWidth || "3", this.archGroupBorderColor = this.archGroupBorderColor || "#000", this.archGroupBorderWidth = this.archGroupBorderWidth || "2px", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || T(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || T(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || T(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || T(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || T(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || T(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Xi(this.quadrant1Fill) ? j(this.quadrant1Fill) : J(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: ((f = this.xyChart) == null ? void 0 : f.backgroundColor) || this.background,
      titleColor: ((p = this.xyChart) == null ? void 0 : p.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((g = this.xyChart) == null ? void 0 : g.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((m = this.xyChart) == null ? void 0 : m.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((y = this.xyChart) == null ? void 0 : y.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((x = this.xyChart) == null ? void 0 : x.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((b = this.xyChart) == null ? void 0 : b.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((_ = this.xyChart) == null ? void 0 : _.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((v = this.xyChart) == null ? void 0 : v.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((w = this.xyChart) == null ? void 0 : w.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((C = this.xyChart) == null ? void 0 : C.plotColorPalette) || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? J(this.secondaryColor, 30) : this.secondaryColor), this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || T(this.primaryColor, { h: -30 }), this.git4 = this.git4 || T(this.primaryColor, { h: -60 }), this.git5 = this.git5 || T(this.primaryColor, { h: -90 }), this.git6 = this.git6 || T(this.primaryColor, { h: 60 }), this.git7 = this.git7 || T(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = j(this.git0, 25), this.git1 = j(this.git1, 25), this.git2 = j(this.git2, 25), this.git3 = j(this.git3, 25), this.git4 = j(this.git4, 25), this.git5 = j(this.git5, 25), this.git6 = j(this.git6, 25), this.git7 = j(this.git7, 25)) : (this.git0 = J(this.git0, 25), this.git1 = J(this.git1, 25), this.git2 = J(this.git2, 25), this.git3 = J(this.git3, 25), this.git4 = J(this.git4, 25), this.git5 = J(this.git5, 25), this.git6 = J(this.git6, 25), this.git7 = J(this.git7, 25)), this.gitInv0 = this.gitInv0 || N(this.git0), this.gitInv1 = this.gitInv1 || N(this.git1), this.gitInv2 = this.gitInv2 || N(this.git2), this.gitInv3 = this.gitInv3 || N(this.git3), this.gitInv4 = this.gitInv4 || N(this.git4), this.gitInv5 = this.gitInv5 || N(this.git5), this.gitInv6 = this.gitInv6 || N(this.git6), this.gitInv7 = this.gitInv7 || N(this.git7), this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor), this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor, this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor, this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor, this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || _a, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || wa;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(Nr, "Theme"), Nr), R0 = /* @__PURE__ */ d((e) => {
  const t = new O0();
  return t.calculate(e), t;
}, "getThemeVariables"), zr, I0 = (zr = class {
  constructor() {
    this.background = "#333", this.primaryColor = "#1f2020", this.secondaryColor = j(this.primaryColor, 16), this.tertiaryColor = T(this.primaryColor, { h: -160 }), this.primaryBorderColor = N(this.background), this.secondaryBorderColor = jt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = jt(this.tertiaryColor, this.darkMode), this.primaryTextColor = N(this.primaryColor), this.secondaryTextColor = N(this.secondaryColor), this.tertiaryTextColor = N(this.tertiaryColor), this.lineColor = N(this.background), this.textColor = N(this.background), this.mainBkg = "#1f2020", this.secondBkg = "calculated", this.mainContrastColor = "lightgrey", this.darkTextColor = j(N("#323D47"), 10), this.lineColor = "calculated", this.border1 = "#ccc", this.border2 = Mi(255, 255, 255, 0.25), this.arrowheadColor = "calculated", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.labelBackground = "#181818", this.textColor = "#ccc", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "#F9FFFE", this.edgeLabelBackground = "calculated", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "calculated", this.actorLineColor = "calculated", this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "calculated", this.activationBkgColor = "calculated", this.sequenceNumberColor = "black", this.sectionBkgColor = J("#EAE8D9", 30), this.altSectionBkgColor = "calculated", this.sectionBkgColor2 = "#EAE8D9", this.excludeBkgColor = J(this.sectionBkgColor, 10), this.taskBorderColor = Mi(255, 255, 255, 70), this.taskBkgColor = "calculated", this.taskTextColor = "calculated", this.taskTextLightColor = "calculated", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = Mi(255, 255, 255, 50), this.activeTaskBkgColor = "#81B1DB", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "grey", this.critBorderColor = "#E83737", this.critBkgColor = "#E83737", this.taskTextDarkColor = "calculated", this.todayLineColor = "#DB5757", this.vertLineColor = "#00BFFF", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = this.rowOdd || j(this.mainBkg, 5) || "#ffffff", this.rowEven = this.rowEven || J(this.mainBkg, 10), this.labelColor = "calculated", this.errorBkgColor = "#a44141", this.errorTextColor = "#ddd";
  }
  updateColors() {
    var t, r, i, n, a, o, s, l, c, h, u, f, p, g, m, y, x, b, _, v, w;
    this.secondBkg = j(this.mainBkg, 16), this.lineColor = this.mainContrastColor, this.arrowheadColor = this.mainContrastColor, this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.edgeLabelBackground = j(this.labelBackground, 25), this.actorBorder = this.border1, this.actorBkg = this.mainBkg, this.actorTextColor = this.mainContrastColor, this.actorLineColor = this.actorBorder, this.signalColor = this.mainContrastColor, this.signalTextColor = this.mainContrastColor, this.labelBoxBkgColor = this.actorBkg, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.mainContrastColor, this.loopTextColor = this.mainContrastColor, this.noteBorderColor = this.secondaryBorderColor, this.noteBkgColor = this.secondBkg, this.noteTextColor = this.secondaryTextColor, this.activationBorderColor = this.border1, this.activationBkgColor = this.secondBkg, this.altSectionBkgColor = this.background, this.taskBkgColor = j(this.mainBkg, 23), this.taskTextColor = this.darkTextColor, this.taskTextLightColor = this.mainContrastColor, this.taskTextOutsideColor = this.taskTextLightColor, this.gridColor = this.mainContrastColor, this.doneTaskBkgColor = this.mainContrastColor, this.taskTextDarkColor = this.darkTextColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#555", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = "#f4f4f4", this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = T(this.primaryColor, { h: 64 }), this.fillType3 = T(this.secondaryColor, { h: 64 }), this.fillType4 = T(this.primaryColor, { h: -64 }), this.fillType5 = T(this.secondaryColor, { h: -64 }), this.fillType6 = T(this.primaryColor, { h: 128 }), this.fillType7 = T(this.secondaryColor, { h: 128 }), this.cScale1 = this.cScale1 || "#0b0000", this.cScale2 = this.cScale2 || "#4d1037", this.cScale3 = this.cScale3 || "#3f5258", this.cScale4 = this.cScale4 || "#4f2f1b", this.cScale5 = this.cScale5 || "#6e0a0a", this.cScale6 = this.cScale6 || "#3b0048", this.cScale7 = this.cScale7 || "#995a01", this.cScale8 = this.cScale8 || "#154706", this.cScale9 = this.cScale9 || "#161722", this.cScale10 = this.cScale10 || "#00296f", this.cScale11 = this.cScale11 || "#01629c", this.cScale12 = this.cScale12 || "#010029", this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || T(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || T(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || T(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || T(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || T(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || T(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || T(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || T(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || T(this.primaryColor, { h: 330 });
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || N(this["cScale" + C]);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScalePeer" + C] = this["cScalePeer" + C] || j(this["cScale" + C], 10);
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || T(this.mainBkg, { h: 30, s: -30, l: -(-10 + C * 4) }), this["surfacePeer" + C] = this["surfacePeer" + C] || T(this.mainBkg, { h: 30, s: -30, l: -(-7 + C * 4) });
    this.scaleLabelColor = this.scaleLabelColor || (this.darkMode ? "black" : this.labelTextColor);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.scaleLabelColor;
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["pie" + C] = this["cScale" + C];
    this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || T(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || T(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || T(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || T(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || T(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || T(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Xi(this.quadrant1Fill) ? j(this.quadrant1Fill) : J(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: ((t = this.xyChart) == null ? void 0 : t.backgroundColor) || this.background,
      titleColor: ((r = this.xyChart) == null ? void 0 : r.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((i = this.xyChart) == null ? void 0 : i.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((n = this.xyChart) == null ? void 0 : n.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((a = this.xyChart) == null ? void 0 : a.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((o = this.xyChart) == null ? void 0 : o.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((s = this.xyChart) == null ? void 0 : s.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((l = this.xyChart) == null ? void 0 : l.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((c = this.xyChart) == null ? void 0 : c.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((h = this.xyChart) == null ? void 0 : h.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((u = this.xyChart) == null ? void 0 : u.plotColorPalette) || "#3498db,#2ecc71,#e74c3c,#f1c40f,#bdc3c7,#ffffff,#34495e,#9b59b6,#1abc9c,#e67e22"
    }, this.packet = {
      startByteColor: this.primaryTextColor,
      endByteColor: this.primaryTextColor,
      labelColor: this.primaryTextColor,
      titleColor: this.primaryTextColor,
      blockStrokeColor: this.primaryTextColor,
      blockFillColor: this.background
    }, this.radar = {
      axisColor: ((f = this.radar) == null ? void 0 : f.axisColor) || this.lineColor,
      axisStrokeWidth: ((p = this.radar) == null ? void 0 : p.axisStrokeWidth) || 2,
      axisLabelFontSize: ((g = this.radar) == null ? void 0 : g.axisLabelFontSize) || 12,
      curveOpacity: ((m = this.radar) == null ? void 0 : m.curveOpacity) || 0.5,
      curveStrokeWidth: ((y = this.radar) == null ? void 0 : y.curveStrokeWidth) || 2,
      graticuleColor: ((x = this.radar) == null ? void 0 : x.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((b = this.radar) == null ? void 0 : b.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((_ = this.radar) == null ? void 0 : _.graticuleOpacity) || 0.3,
      legendBoxSize: ((v = this.radar) == null ? void 0 : v.legendBoxSize) || 12,
      legendFontSize: ((w = this.radar) == null ? void 0 : w.legendFontSize) || 12
    }, this.classText = this.primaryTextColor, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? J(this.secondaryColor, 30) : this.secondaryColor), this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = j(this.secondaryColor, 20), this.git1 = j(this.pie2 || this.secondaryColor, 20), this.git2 = j(this.pie3 || this.tertiaryColor, 20), this.git3 = j(this.pie4 || T(this.primaryColor, { h: -30 }), 20), this.git4 = j(this.pie5 || T(this.primaryColor, { h: -60 }), 20), this.git5 = j(this.pie6 || T(this.primaryColor, { h: -90 }), 10), this.git6 = j(this.pie7 || T(this.primaryColor, { h: 60 }), 10), this.git7 = j(this.pie8 || T(this.primaryColor, { h: 120 }), 20), this.gitInv0 = this.gitInv0 || N(this.git0), this.gitInv1 = this.gitInv1 || N(this.git1), this.gitInv2 = this.gitInv2 || N(this.git2), this.gitInv3 = this.gitInv3 || N(this.git3), this.gitInv4 = this.gitInv4 || N(this.git4), this.gitInv5 = this.gitInv5 || N(this.git5), this.gitInv6 = this.gitInv6 || N(this.git6), this.gitInv7 = this.gitInv7 || N(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || N(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || N(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || j(this.background, 12), this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || j(this.background, 2), this.nodeBorder = this.nodeBorder || "#999";
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(zr, "Theme"), zr), P0 = /* @__PURE__ */ d((e) => {
  const t = new I0();
  return t.calculate(e), t;
}, "getThemeVariables"), Wr, N0 = (Wr = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#ECECFF", this.secondaryColor = T(this.primaryColor, { h: 120 }), this.secondaryColor = "#ffffde", this.tertiaryColor = T(this.primaryColor, { h: -160 }), this.primaryBorderColor = jt(this.primaryColor, this.darkMode), this.secondaryBorderColor = jt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = jt(this.tertiaryColor, this.darkMode), this.primaryTextColor = N(this.primaryColor), this.secondaryTextColor = N(this.secondaryColor), this.tertiaryTextColor = N(this.tertiaryColor), this.lineColor = N(this.background), this.textColor = N(this.background), this.background = "white", this.mainBkg = "#ECECFF", this.secondBkg = "#ffffde", this.lineColor = "#333333", this.border1 = "#9370DB", this.border2 = "#aaaa33", this.arrowheadColor = "#333333", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.labelBackground = "rgba(232,232,232, 0.8)", this.textColor = "#333", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "calculated", this.edgeLabelBackground = "calculated", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "black", this.actorLineColor = "calculated", this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "calculated", this.altSectionBkgColor = "calculated", this.sectionBkgColor2 = "calculated", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "calculated", this.taskTextLightColor = "calculated", this.taskTextColor = this.taskTextLightColor, this.taskTextDarkColor = "calculated", this.taskTextOutsideColor = this.taskTextDarkColor, this.taskTextClickableColor = "calculated", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "calculated", this.critBorderColor = "calculated", this.critBkgColor = "calculated", this.todayLineColor = "calculated", this.vertLineColor = "calculated", this.sectionBkgColor = Mi(102, 102, 255, 0.49), this.altSectionBkgColor = "white", this.sectionBkgColor2 = "#fff400", this.taskBorderColor = "#534fbc", this.taskBkgColor = "#8a90dd", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "black", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "#534fbc", this.activeTaskBkgColor = "#bfc7ff", this.gridColor = "lightgrey", this.doneTaskBkgColor = "lightgrey", this.doneTaskBorderColor = "grey", this.critBorderColor = "#ff8888", this.critBkgColor = "red", this.todayLineColor = "red", this.vertLineColor = "navy", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = "calculated", this.rowEven = "calculated", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222", this.updateColors();
  }
  updateColors() {
    var t, r, i, n, a, o, s, l, c, h, u, f, p, g, m, y, x, b, _, v, w;
    this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || T(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || T(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || T(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || T(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || T(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || T(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || T(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || T(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || T(this.primaryColor, { h: 330 }), this.cScalePeer1 = this.cScalePeer1 || J(this.secondaryColor, 45), this.cScalePeer2 = this.cScalePeer2 || J(this.tertiaryColor, 40);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScale" + C] = J(this["cScale" + C], 10), this["cScalePeer" + C] = this["cScalePeer" + C] || J(this["cScale" + C], 25);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || T(this["cScale" + C], { h: 180 });
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || T(this.mainBkg, { h: 30, l: -(5 + C * 5) }), this["surfacePeer" + C] = this["surfacePeer" + C] || T(this.mainBkg, { h: 30, l: -(7 + C * 5) });
    if (this.scaleLabelColor = this.scaleLabelColor !== "calculated" && this.scaleLabelColor ? this.scaleLabelColor : this.labelTextColor, this.labelTextColor !== "calculated") {
      this.cScaleLabel0 = this.cScaleLabel0 || N(this.labelTextColor), this.cScaleLabel3 = this.cScaleLabel3 || N(this.labelTextColor);
      for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
        this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.labelTextColor;
    }
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.titleColor = this.textColor, this.edgeLabelBackground = this.labelBackground, this.actorBorder = j(this.border1, 23), this.actorBkg = this.mainBkg, this.labelBoxBkgColor = this.actorBkg, this.signalColor = this.textColor, this.signalTextColor = this.textColor, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.actorTextColor, this.loopTextColor = this.actorTextColor, this.noteBorderColor = this.border2, this.noteTextColor = this.actorTextColor, this.actorLineColor = this.actorBorder, this.taskTextColor = this.taskTextLightColor, this.taskTextOutsideColor = this.taskTextDarkColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.rowOdd = this.rowOdd || j(this.primaryColor, 75) || "#ffffff", this.rowEven = this.rowEven || j(this.primaryColor, 1), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f0f0f0", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.nodeBorder, this.specialStateColor = this.lineColor, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = T(this.primaryColor, { h: 64 }), this.fillType3 = T(this.secondaryColor, { h: 64 }), this.fillType4 = T(this.primaryColor, { h: -64 }), this.fillType5 = T(this.secondaryColor, { h: -64 }), this.fillType6 = T(this.primaryColor, { h: 128 }), this.fillType7 = T(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || T(this.tertiaryColor, { l: -40 }), this.pie4 = this.pie4 || T(this.primaryColor, { l: -10 }), this.pie5 = this.pie5 || T(this.secondaryColor, { l: -30 }), this.pie6 = this.pie6 || T(this.tertiaryColor, { l: -20 }), this.pie7 = this.pie7 || T(this.primaryColor, { h: 60, l: -20 }), this.pie8 = this.pie8 || T(this.primaryColor, { h: -60, l: -40 }), this.pie9 = this.pie9 || T(this.primaryColor, { h: 120, l: -40 }), this.pie10 = this.pie10 || T(this.primaryColor, { h: 60, l: -40 }), this.pie11 = this.pie11 || T(this.primaryColor, { h: -90, l: -40 }), this.pie12 = this.pie12 || T(this.primaryColor, { h: 120, l: -30 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || T(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || T(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || T(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || T(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || T(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || T(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Xi(this.quadrant1Fill) ? j(this.quadrant1Fill) : J(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.radar = {
      axisColor: ((t = this.radar) == null ? void 0 : t.axisColor) || this.lineColor,
      axisStrokeWidth: ((r = this.radar) == null ? void 0 : r.axisStrokeWidth) || 2,
      axisLabelFontSize: ((i = this.radar) == null ? void 0 : i.axisLabelFontSize) || 12,
      curveOpacity: ((n = this.radar) == null ? void 0 : n.curveOpacity) || 0.5,
      curveStrokeWidth: ((a = this.radar) == null ? void 0 : a.curveStrokeWidth) || 2,
      graticuleColor: ((o = this.radar) == null ? void 0 : o.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((s = this.radar) == null ? void 0 : s.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((l = this.radar) == null ? void 0 : l.graticuleOpacity) || 0.3,
      legendBoxSize: ((c = this.radar) == null ? void 0 : c.legendBoxSize) || 12,
      legendFontSize: ((h = this.radar) == null ? void 0 : h.legendFontSize) || 12
    }, this.xyChart = {
      backgroundColor: ((u = this.xyChart) == null ? void 0 : u.backgroundColor) || this.background,
      titleColor: ((f = this.xyChart) == null ? void 0 : f.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((p = this.xyChart) == null ? void 0 : p.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((g = this.xyChart) == null ? void 0 : g.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((m = this.xyChart) == null ? void 0 : m.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((y = this.xyChart) == null ? void 0 : y.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((x = this.xyChart) == null ? void 0 : x.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((b = this.xyChart) == null ? void 0 : b.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((_ = this.xyChart) == null ? void 0 : _.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((v = this.xyChart) == null ? void 0 : v.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((w = this.xyChart) == null ? void 0 : w.plotColorPalette) || "#ECECFF,#8493A6,#FFC3A0,#DCDDE1,#B8E994,#D1A36F,#C3CDE6,#FFB6C1,#496078,#F8F3E3"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.labelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || T(this.primaryColor, { h: -30 }), this.git4 = this.git4 || T(this.primaryColor, { h: -60 }), this.git5 = this.git5 || T(this.primaryColor, { h: -90 }), this.git6 = this.git6 || T(this.primaryColor, { h: 60 }), this.git7 = this.git7 || T(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = j(this.git0, 25), this.git1 = j(this.git1, 25), this.git2 = j(this.git2, 25), this.git3 = j(this.git3, 25), this.git4 = j(this.git4, 25), this.git5 = j(this.git5, 25), this.git6 = j(this.git6, 25), this.git7 = j(this.git7, 25)) : (this.git0 = J(this.git0, 25), this.git1 = J(this.git1, 25), this.git2 = J(this.git2, 25), this.git3 = J(this.git3, 25), this.git4 = J(this.git4, 25), this.git5 = J(this.git5, 25), this.git6 = J(this.git6, 25), this.git7 = J(this.git7, 25)), this.gitInv0 = this.gitInv0 || J(N(this.git0), 25), this.gitInv1 = this.gitInv1 || N(this.git1), this.gitInv2 = this.gitInv2 || N(this.git2), this.gitInv3 = this.gitInv3 || N(this.git3), this.gitInv4 = this.gitInv4 || N(this.git4), this.gitInv5 = this.gitInv5 || N(this.git5), this.gitInv6 = this.gitInv6 || N(this.git6), this.gitInv7 = this.gitInv7 || N(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || N(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || N(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || _a, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || wa;
  }
  calculate(t) {
    if (Object.keys(this).forEach((i) => {
      this[i] === "calculated" && (this[i] = void 0);
    }), typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(Wr, "Theme"), Wr), z0 = /* @__PURE__ */ d((e) => {
  const t = new N0();
  return t.calculate(e), t;
}, "getThemeVariables"), qr, W0 = (qr = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#cde498", this.secondaryColor = "#cdffb2", this.background = "white", this.mainBkg = "#cde498", this.secondBkg = "#cdffb2", this.lineColor = "green", this.border1 = "#13540c", this.border2 = "#6eaa49", this.arrowheadColor = "green", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.tertiaryColor = j("#cde498", 10), this.primaryBorderColor = jt(this.primaryColor, this.darkMode), this.secondaryBorderColor = jt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = jt(this.tertiaryColor, this.darkMode), this.primaryTextColor = N(this.primaryColor), this.secondaryTextColor = N(this.secondaryColor), this.tertiaryTextColor = N(this.primaryColor), this.lineColor = N(this.background), this.textColor = N(this.background), this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "#333", this.edgeLabelBackground = "#e8e8e8", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "black", this.actorLineColor = "calculated", this.signalColor = "#333", this.signalTextColor = "#333", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "#326932", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "#6eaa49", this.altSectionBkgColor = "white", this.sectionBkgColor2 = "#6eaa49", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "#487e3a", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "black", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "lightgrey", this.doneTaskBkgColor = "lightgrey", this.doneTaskBorderColor = "grey", this.critBorderColor = "#ff8888", this.critBkgColor = "red", this.todayLineColor = "red", this.vertLineColor = "#00BFFF", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222";
  }
  updateColors() {
    var t, r, i, n, a, o, s, l, c, h, u, f, p, g, m, y, x, b, _, v, w;
    this.actorBorder = J(this.mainBkg, 20), this.actorBkg = this.mainBkg, this.labelBoxBkgColor = this.actorBkg, this.labelTextColor = this.actorTextColor, this.loopTextColor = this.actorTextColor, this.noteBorderColor = this.border2, this.noteTextColor = this.actorTextColor, this.actorLineColor = this.actorBorder, this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || T(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || T(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || T(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || T(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || T(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || T(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || T(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || T(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || T(this.primaryColor, { h: 330 }), this.cScalePeer1 = this.cScalePeer1 || J(this.secondaryColor, 45), this.cScalePeer2 = this.cScalePeer2 || J(this.tertiaryColor, 40);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScale" + C] = J(this["cScale" + C], 10), this["cScalePeer" + C] = this["cScalePeer" + C] || J(this["cScale" + C], 25);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || T(this["cScale" + C], { h: 180 });
    this.scaleLabelColor = this.scaleLabelColor !== "calculated" && this.scaleLabelColor ? this.scaleLabelColor : this.labelTextColor;
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.scaleLabelColor;
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || T(this.mainBkg, { h: 30, s: -30, l: -(5 + C * 5) }), this["surfacePeer" + C] = this["surfacePeer" + C] || T(this.mainBkg, { h: 30, s: -30, l: -(8 + C * 5) });
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.taskBorderColor = this.border1, this.taskTextColor = this.taskTextLightColor, this.taskTextOutsideColor = this.taskTextDarkColor, this.activeTaskBorderColor = this.taskBorderColor, this.activeTaskBkgColor = this.mainBkg, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.rowOdd = this.rowOdd || j(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || j(this.mainBkg, 20), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f0f0f0", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = this.lineColor, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = T(this.primaryColor, { h: 64 }), this.fillType3 = T(this.secondaryColor, { h: 64 }), this.fillType4 = T(this.primaryColor, { h: -64 }), this.fillType5 = T(this.secondaryColor, { h: -64 }), this.fillType6 = T(this.primaryColor, { h: 128 }), this.fillType7 = T(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || this.tertiaryColor, this.pie4 = this.pie4 || T(this.primaryColor, { l: -30 }), this.pie5 = this.pie5 || T(this.secondaryColor, { l: -30 }), this.pie6 = this.pie6 || T(this.tertiaryColor, { h: 40, l: -40 }), this.pie7 = this.pie7 || T(this.primaryColor, { h: 60, l: -10 }), this.pie8 = this.pie8 || T(this.primaryColor, { h: -60, l: -10 }), this.pie9 = this.pie9 || T(this.primaryColor, { h: 120, l: 0 }), this.pie10 = this.pie10 || T(this.primaryColor, { h: 60, l: -50 }), this.pie11 = this.pie11 || T(this.primaryColor, { h: -60, l: -50 }), this.pie12 = this.pie12 || T(this.primaryColor, { h: 120, l: -50 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || T(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || T(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || T(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || T(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || T(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || T(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Xi(this.quadrant1Fill) ? j(this.quadrant1Fill) : J(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.packet = {
      startByteColor: this.primaryTextColor,
      endByteColor: this.primaryTextColor,
      labelColor: this.primaryTextColor,
      titleColor: this.primaryTextColor,
      blockStrokeColor: this.primaryTextColor,
      blockFillColor: this.mainBkg
    }, this.radar = {
      axisColor: ((t = this.radar) == null ? void 0 : t.axisColor) || this.lineColor,
      axisStrokeWidth: ((r = this.radar) == null ? void 0 : r.axisStrokeWidth) || 2,
      axisLabelFontSize: ((i = this.radar) == null ? void 0 : i.axisLabelFontSize) || 12,
      curveOpacity: ((n = this.radar) == null ? void 0 : n.curveOpacity) || 0.5,
      curveStrokeWidth: ((a = this.radar) == null ? void 0 : a.curveStrokeWidth) || 2,
      graticuleColor: ((o = this.radar) == null ? void 0 : o.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((s = this.radar) == null ? void 0 : s.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((l = this.radar) == null ? void 0 : l.graticuleOpacity) || 0.3,
      legendBoxSize: ((c = this.radar) == null ? void 0 : c.legendBoxSize) || 12,
      legendFontSize: ((h = this.radar) == null ? void 0 : h.legendFontSize) || 12
    }, this.xyChart = {
      backgroundColor: ((u = this.xyChart) == null ? void 0 : u.backgroundColor) || this.background,
      titleColor: ((f = this.xyChart) == null ? void 0 : f.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((p = this.xyChart) == null ? void 0 : p.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((g = this.xyChart) == null ? void 0 : g.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((m = this.xyChart) == null ? void 0 : m.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((y = this.xyChart) == null ? void 0 : y.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((x = this.xyChart) == null ? void 0 : x.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((b = this.xyChart) == null ? void 0 : b.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((_ = this.xyChart) == null ? void 0 : _.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((v = this.xyChart) == null ? void 0 : v.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((w = this.xyChart) == null ? void 0 : w.plotColorPalette) || "#CDE498,#FF6B6B,#A0D2DB,#D7BDE2,#F0F0F0,#FFC3A0,#7FD8BE,#FF9A8B,#FAF3E0,#FFF176"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.edgeLabelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || T(this.primaryColor, { h: -30 }), this.git4 = this.git4 || T(this.primaryColor, { h: -60 }), this.git5 = this.git5 || T(this.primaryColor, { h: -90 }), this.git6 = this.git6 || T(this.primaryColor, { h: 60 }), this.git7 = this.git7 || T(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = j(this.git0, 25), this.git1 = j(this.git1, 25), this.git2 = j(this.git2, 25), this.git3 = j(this.git3, 25), this.git4 = j(this.git4, 25), this.git5 = j(this.git5, 25), this.git6 = j(this.git6, 25), this.git7 = j(this.git7, 25)) : (this.git0 = J(this.git0, 25), this.git1 = J(this.git1, 25), this.git2 = J(this.git2, 25), this.git3 = J(this.git3, 25), this.git4 = J(this.git4, 25), this.git5 = J(this.git5, 25), this.git6 = J(this.git6, 25), this.git7 = J(this.git7, 25)), this.gitInv0 = this.gitInv0 || N(this.git0), this.gitInv1 = this.gitInv1 || N(this.git1), this.gitInv2 = this.gitInv2 || N(this.git2), this.gitInv3 = this.gitInv3 || N(this.git3), this.gitInv4 = this.gitInv4 || N(this.git4), this.gitInv5 = this.gitInv5 || N(this.git5), this.gitInv6 = this.gitInv6 || N(this.git6), this.gitInv7 = this.gitInv7 || N(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || N(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || N(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || _a, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || wa;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(qr, "Theme"), qr), q0 = /* @__PURE__ */ d((e) => {
  const t = new W0();
  return t.calculate(e), t;
}, "getThemeVariables"), Hr, H0 = (Hr = class {
  constructor() {
    this.primaryColor = "#eee", this.contrast = "#707070", this.secondaryColor = j(this.contrast, 55), this.background = "#ffffff", this.tertiaryColor = T(this.primaryColor, { h: -160 }), this.primaryBorderColor = jt(this.primaryColor, this.darkMode), this.secondaryBorderColor = jt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = jt(this.tertiaryColor, this.darkMode), this.primaryTextColor = N(this.primaryColor), this.secondaryTextColor = N(this.secondaryColor), this.tertiaryTextColor = N(this.tertiaryColor), this.lineColor = N(this.background), this.textColor = N(this.background), this.mainBkg = "#eee", this.secondBkg = "calculated", this.lineColor = "#666", this.border1 = "#999", this.border2 = "calculated", this.note = "#ffa", this.text = "#333", this.critical = "#d42", this.done = "#bbb", this.arrowheadColor = "#333333", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "calculated", this.edgeLabelBackground = "white", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "calculated", this.actorLineColor = this.actorBorder, this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "calculated", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "calculated", this.altSectionBkgColor = "white", this.sectionBkgColor2 = "calculated", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "calculated", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "calculated", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "calculated", this.critBkgColor = "calculated", this.critBorderColor = "calculated", this.todayLineColor = "calculated", this.vertLineColor = "calculated", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = this.rowOdd || j(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || "#f4f4f4", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222";
  }
  updateColors() {
    var t, r, i, n, a, o, s, l, c, h, u, f, p, g, m, y, x, b, _, v, w;
    this.secondBkg = j(this.contrast, 55), this.border2 = this.contrast, this.actorBorder = j(this.border1, 23), this.actorBkg = this.mainBkg, this.actorTextColor = this.text, this.actorLineColor = this.actorBorder, this.signalColor = this.text, this.signalTextColor = this.text, this.labelBoxBkgColor = this.actorBkg, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.text, this.loopTextColor = this.text, this.noteBorderColor = "#999", this.noteBkgColor = "#666", this.noteTextColor = "#fff", this.cScale0 = this.cScale0 || "#555", this.cScale1 = this.cScale1 || "#F4F4F4", this.cScale2 = this.cScale2 || "#555", this.cScale3 = this.cScale3 || "#BBB", this.cScale4 = this.cScale4 || "#777", this.cScale5 = this.cScale5 || "#999", this.cScale6 = this.cScale6 || "#DDD", this.cScale7 = this.cScale7 || "#FFF", this.cScale8 = this.cScale8 || "#DDD", this.cScale9 = this.cScale9 || "#BBB", this.cScale10 = this.cScale10 || "#999", this.cScale11 = this.cScale11 || "#777";
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || N(this["cScale" + C]);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this.darkMode ? this["cScalePeer" + C] = this["cScalePeer" + C] || j(this["cScale" + C], 10) : this["cScalePeer" + C] = this["cScalePeer" + C] || J(this["cScale" + C], 10);
    this.scaleLabelColor = this.scaleLabelColor || (this.darkMode ? "black" : this.labelTextColor), this.cScaleLabel0 = this.cScaleLabel0 || this.cScale1, this.cScaleLabel2 = this.cScaleLabel2 || this.cScale1;
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.scaleLabelColor;
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || T(this.mainBkg, { l: -(5 + C * 5) }), this["surfacePeer" + C] = this["surfacePeer" + C] || T(this.mainBkg, { l: -(8 + C * 5) });
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.titleColor = this.text, this.sectionBkgColor = j(this.contrast, 30), this.sectionBkgColor2 = j(this.contrast, 30), this.taskBorderColor = J(this.contrast, 10), this.taskBkgColor = this.contrast, this.taskTextColor = this.taskTextLightColor, this.taskTextDarkColor = this.text, this.taskTextOutsideColor = this.taskTextDarkColor, this.activeTaskBorderColor = this.taskBorderColor, this.activeTaskBkgColor = this.mainBkg, this.gridColor = j(this.border1, 30), this.doneTaskBkgColor = this.done, this.doneTaskBorderColor = this.lineColor, this.critBkgColor = this.critical, this.critBorderColor = J(this.critBkgColor, 10), this.todayLineColor = this.critBkgColor, this.vertLineColor = this.critBkgColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.transitionColor = this.transitionColor || "#000", this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f4f4f4", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.stateBorder = this.stateBorder || "#000", this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = "#222", this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = T(this.primaryColor, { h: 64 }), this.fillType3 = T(this.secondaryColor, { h: 64 }), this.fillType4 = T(this.primaryColor, { h: -64 }), this.fillType5 = T(this.secondaryColor, { h: -64 }), this.fillType6 = T(this.primaryColor, { h: 128 }), this.fillType7 = T(this.secondaryColor, { h: 128 });
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["pie" + C] = this["cScale" + C];
    this.pie12 = this.pie0, this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || T(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || T(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || T(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || T(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || T(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || T(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Xi(this.quadrant1Fill) ? j(this.quadrant1Fill) : J(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: ((t = this.xyChart) == null ? void 0 : t.backgroundColor) || this.background,
      titleColor: ((r = this.xyChart) == null ? void 0 : r.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((i = this.xyChart) == null ? void 0 : i.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((n = this.xyChart) == null ? void 0 : n.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((a = this.xyChart) == null ? void 0 : a.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((o = this.xyChart) == null ? void 0 : o.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((s = this.xyChart) == null ? void 0 : s.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((l = this.xyChart) == null ? void 0 : l.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((c = this.xyChart) == null ? void 0 : c.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((h = this.xyChart) == null ? void 0 : h.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((u = this.xyChart) == null ? void 0 : u.plotColorPalette) || "#EEE,#6BB8E4,#8ACB88,#C7ACD6,#E8DCC2,#FFB2A8,#FFF380,#7E8D91,#FFD8B1,#FAF3E0"
    }, this.radar = {
      axisColor: ((f = this.radar) == null ? void 0 : f.axisColor) || this.lineColor,
      axisStrokeWidth: ((p = this.radar) == null ? void 0 : p.axisStrokeWidth) || 2,
      axisLabelFontSize: ((g = this.radar) == null ? void 0 : g.axisLabelFontSize) || 12,
      curveOpacity: ((m = this.radar) == null ? void 0 : m.curveOpacity) || 0.5,
      curveStrokeWidth: ((y = this.radar) == null ? void 0 : y.curveStrokeWidth) || 2,
      graticuleColor: ((x = this.radar) == null ? void 0 : x.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((b = this.radar) == null ? void 0 : b.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((_ = this.radar) == null ? void 0 : _.graticuleOpacity) || 0.3,
      legendBoxSize: ((v = this.radar) == null ? void 0 : v.legendBoxSize) || 12,
      legendFontSize: ((w = this.radar) == null ? void 0 : w.legendFontSize) || 12
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.edgeLabelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = J(this.pie1, 25) || this.primaryColor, this.git1 = this.pie2 || this.secondaryColor, this.git2 = this.pie3 || this.tertiaryColor, this.git3 = this.pie4 || T(this.primaryColor, { h: -30 }), this.git4 = this.pie5 || T(this.primaryColor, { h: -60 }), this.git5 = this.pie6 || T(this.primaryColor, { h: -90 }), this.git6 = this.pie7 || T(this.primaryColor, { h: 60 }), this.git7 = this.pie8 || T(this.primaryColor, { h: 120 }), this.gitInv0 = this.gitInv0 || N(this.git0), this.gitInv1 = this.gitInv1 || N(this.git1), this.gitInv2 = this.gitInv2 || N(this.git2), this.gitInv3 = this.gitInv3 || N(this.git3), this.gitInv4 = this.gitInv4 || N(this.git4), this.gitInv5 = this.gitInv5 || N(this.git5), this.gitInv6 = this.gitInv6 || N(this.git6), this.gitInv7 = this.gitInv7 || N(this.git7), this.branchLabelColor = this.branchLabelColor || this.labelTextColor, this.gitBranchLabel0 = this.branchLabelColor, this.gitBranchLabel1 = "white", this.gitBranchLabel2 = this.branchLabelColor, this.gitBranchLabel3 = "white", this.gitBranchLabel4 = this.branchLabelColor, this.gitBranchLabel5 = this.branchLabelColor, this.gitBranchLabel6 = this.branchLabelColor, this.gitBranchLabel7 = this.branchLabelColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || _a, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || wa;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(Hr, "Theme"), Hr), j0 = /* @__PURE__ */ d((e) => {
  const t = new H0();
  return t.calculate(e), t;
}, "getThemeVariables"), Oe = {
  base: {
    getThemeVariables: R0
  },
  dark: {
    getThemeVariables: P0
  },
  default: {
    getThemeVariables: z0
  },
  forest: {
    getThemeVariables: q0
  },
  neutral: {
    getThemeVariables: j0
  }
}, xe = {
  flowchart: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    subGraphTitleMargin: {
      top: 0,
      bottom: 0
    },
    diagramPadding: 8,
    htmlLabels: !0,
    nodeSpacing: 50,
    rankSpacing: 50,
    curve: "basis",
    padding: 15,
    defaultRenderer: "dagre-wrapper",
    wrappingWidth: 200,
    inheritDir: !1
  },
  sequence: {
    useMaxWidth: !0,
    hideUnusedParticipants: !1,
    activationWidth: 10,
    diagramMarginX: 50,
    diagramMarginY: 10,
    actorMargin: 50,
    width: 150,
    height: 65,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    mirrorActors: !0,
    forceMenus: !1,
    bottomMarginAdj: 1,
    rightAngles: !1,
    showSequenceNumbers: !1,
    actorFontSize: 14,
    actorFontFamily: '"Open Sans", sans-serif',
    actorFontWeight: 400,
    noteFontSize: 14,
    noteFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    noteFontWeight: 400,
    noteAlign: "center",
    messageFontSize: 16,
    messageFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    messageFontWeight: 400,
    wrap: !1,
    wrapPadding: 10,
    labelBoxWidth: 50,
    labelBoxHeight: 20
  },
  gantt: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    barHeight: 20,
    barGap: 4,
    topPadding: 50,
    rightPadding: 75,
    leftPadding: 75,
    gridLineStartPadding: 35,
    fontSize: 11,
    sectionFontSize: 11,
    numberSectionStyles: 4,
    axisFormat: "%Y-%m-%d",
    topAxis: !1,
    displayMode: "",
    weekday: "sunday"
  },
  journey: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    leftMargin: 150,
    maxLabelWidth: 360,
    width: 150,
    height: 50,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    bottomMarginAdj: 1,
    rightAngles: !1,
    taskFontSize: 14,
    taskFontFamily: '"Open Sans", sans-serif',
    taskMargin: 50,
    activationWidth: 10,
    textPlacement: "fo",
    actorColours: [
      "#8FBC8F",
      "#7CFC00",
      "#00FFFF",
      "#20B2AA",
      "#B0E0E6",
      "#FFFFE0"
    ],
    sectionFills: [
      "#191970",
      "#8B008B",
      "#4B0082",
      "#2F4F4F",
      "#800000",
      "#8B4513",
      "#00008B"
    ],
    sectionColours: [
      "#fff"
    ],
    titleColor: "",
    titleFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    titleFontSize: "4ex"
  },
  class: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    arrowMarkerAbsolute: !1,
    dividerMargin: 10,
    padding: 5,
    textHeight: 10,
    defaultRenderer: "dagre-wrapper",
    htmlLabels: !1,
    hideEmptyMembersBox: !1
  },
  state: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    dividerMargin: 10,
    sizeUnit: 5,
    padding: 8,
    textHeight: 10,
    titleShift: -15,
    noteMargin: 10,
    forkWidth: 70,
    forkHeight: 7,
    miniPadding: 2,
    fontSizeFactor: 5.02,
    fontSize: 24,
    labelHeight: 16,
    edgeLengthFactor: "20",
    compositTitleSize: 35,
    radius: 5,
    defaultRenderer: "dagre-wrapper"
  },
  er: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    diagramPadding: 20,
    layoutDirection: "TB",
    minEntityWidth: 100,
    minEntityHeight: 75,
    entityPadding: 15,
    nodeSpacing: 140,
    rankSpacing: 80,
    stroke: "gray",
    fill: "honeydew",
    fontSize: 12
  },
  pie: {
    useMaxWidth: !0,
    textPosition: 0.75
  },
  quadrantChart: {
    useMaxWidth: !0,
    chartWidth: 500,
    chartHeight: 500,
    titleFontSize: 20,
    titlePadding: 10,
    quadrantPadding: 5,
    xAxisLabelPadding: 5,
    yAxisLabelPadding: 5,
    xAxisLabelFontSize: 16,
    yAxisLabelFontSize: 16,
    quadrantLabelFontSize: 16,
    quadrantTextTopPadding: 5,
    pointTextPadding: 5,
    pointLabelFontSize: 12,
    pointRadius: 5,
    xAxisPosition: "top",
    yAxisPosition: "left",
    quadrantInternalBorderStrokeWidth: 1,
    quadrantExternalBorderStrokeWidth: 2
  },
  xyChart: {
    useMaxWidth: !0,
    width: 700,
    height: 500,
    titleFontSize: 20,
    titlePadding: 10,
    showDataLabel: !1,
    showTitle: !0,
    xAxis: {
      $ref: "#/$defs/XYChartAxisConfig",
      showLabel: !0,
      labelFontSize: 14,
      labelPadding: 5,
      showTitle: !0,
      titleFontSize: 16,
      titlePadding: 5,
      showTick: !0,
      tickLength: 5,
      tickWidth: 2,
      showAxisLine: !0,
      axisLineWidth: 2
    },
    yAxis: {
      $ref: "#/$defs/XYChartAxisConfig",
      showLabel: !0,
      labelFontSize: 14,
      labelPadding: 5,
      showTitle: !0,
      titleFontSize: 16,
      titlePadding: 5,
      showTick: !0,
      tickLength: 5,
      tickWidth: 2,
      showAxisLine: !0,
      axisLineWidth: 2
    },
    chartOrientation: "vertical",
    plotReservedSpacePercent: 50
  },
  requirement: {
    useMaxWidth: !0,
    rect_fill: "#f9f9f9",
    text_color: "#333",
    rect_border_size: "0.5px",
    rect_border_color: "#bbb",
    rect_min_width: 200,
    rect_min_height: 200,
    fontSize: 14,
    rect_padding: 10,
    line_height: 20
  },
  mindmap: {
    useMaxWidth: !0,
    padding: 10,
    maxNodeWidth: 200,
    layoutAlgorithm: "cose-bilkent"
  },
  kanban: {
    useMaxWidth: !0,
    padding: 8,
    sectionWidth: 200,
    ticketBaseUrl: ""
  },
  timeline: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    leftMargin: 150,
    width: 150,
    height: 50,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    bottomMarginAdj: 1,
    rightAngles: !1,
    taskFontSize: 14,
    taskFontFamily: '"Open Sans", sans-serif',
    taskMargin: 50,
    activationWidth: 10,
    textPlacement: "fo",
    actorColours: [
      "#8FBC8F",
      "#7CFC00",
      "#00FFFF",
      "#20B2AA",
      "#B0E0E6",
      "#FFFFE0"
    ],
    sectionFills: [
      "#191970",
      "#8B008B",
      "#4B0082",
      "#2F4F4F",
      "#800000",
      "#8B4513",
      "#00008B"
    ],
    sectionColours: [
      "#fff"
    ],
    disableMulticolor: !1
  },
  gitGraph: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    diagramPadding: 8,
    nodeLabel: {
      width: 75,
      height: 100,
      x: -25,
      y: 0
    },
    mainBranchName: "main",
    mainBranchOrder: 0,
    showCommitLabel: !0,
    showBranches: !0,
    rotateCommitLabel: !0,
    parallelCommits: !1,
    arrowMarkerAbsolute: !1
  },
  c4: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    c4ShapeMargin: 50,
    c4ShapePadding: 20,
    width: 216,
    height: 60,
    boxMargin: 10,
    c4ShapeInRow: 4,
    nextLinePaddingX: 0,
    c4BoundaryInRow: 2,
    personFontSize: 14,
    personFontFamily: '"Open Sans", sans-serif',
    personFontWeight: "normal",
    external_personFontSize: 14,
    external_personFontFamily: '"Open Sans", sans-serif',
    external_personFontWeight: "normal",
    systemFontSize: 14,
    systemFontFamily: '"Open Sans", sans-serif',
    systemFontWeight: "normal",
    external_systemFontSize: 14,
    external_systemFontFamily: '"Open Sans", sans-serif',
    external_systemFontWeight: "normal",
    system_dbFontSize: 14,
    system_dbFontFamily: '"Open Sans", sans-serif',
    system_dbFontWeight: "normal",
    external_system_dbFontSize: 14,
    external_system_dbFontFamily: '"Open Sans", sans-serif',
    external_system_dbFontWeight: "normal",
    system_queueFontSize: 14,
    system_queueFontFamily: '"Open Sans", sans-serif',
    system_queueFontWeight: "normal",
    external_system_queueFontSize: 14,
    external_system_queueFontFamily: '"Open Sans", sans-serif',
    external_system_queueFontWeight: "normal",
    boundaryFontSize: 14,
    boundaryFontFamily: '"Open Sans", sans-serif',
    boundaryFontWeight: "normal",
    messageFontSize: 12,
    messageFontFamily: '"Open Sans", sans-serif',
    messageFontWeight: "normal",
    containerFontSize: 14,
    containerFontFamily: '"Open Sans", sans-serif',
    containerFontWeight: "normal",
    external_containerFontSize: 14,
    external_containerFontFamily: '"Open Sans", sans-serif',
    external_containerFontWeight: "normal",
    container_dbFontSize: 14,
    container_dbFontFamily: '"Open Sans", sans-serif',
    container_dbFontWeight: "normal",
    external_container_dbFontSize: 14,
    external_container_dbFontFamily: '"Open Sans", sans-serif',
    external_container_dbFontWeight: "normal",
    container_queueFontSize: 14,
    container_queueFontFamily: '"Open Sans", sans-serif',
    container_queueFontWeight: "normal",
    external_container_queueFontSize: 14,
    external_container_queueFontFamily: '"Open Sans", sans-serif',
    external_container_queueFontWeight: "normal",
    componentFontSize: 14,
    componentFontFamily: '"Open Sans", sans-serif',
    componentFontWeight: "normal",
    external_componentFontSize: 14,
    external_componentFontFamily: '"Open Sans", sans-serif',
    external_componentFontWeight: "normal",
    component_dbFontSize: 14,
    component_dbFontFamily: '"Open Sans", sans-serif',
    component_dbFontWeight: "normal",
    external_component_dbFontSize: 14,
    external_component_dbFontFamily: '"Open Sans", sans-serif',
    external_component_dbFontWeight: "normal",
    component_queueFontSize: 14,
    component_queueFontFamily: '"Open Sans", sans-serif',
    component_queueFontWeight: "normal",
    external_component_queueFontSize: 14,
    external_component_queueFontFamily: '"Open Sans", sans-serif',
    external_component_queueFontWeight: "normal",
    wrap: !0,
    wrapPadding: 10,
    person_bg_color: "#08427B",
    person_border_color: "#073B6F",
    external_person_bg_color: "#686868",
    external_person_border_color: "#8A8A8A",
    system_bg_color: "#1168BD",
    system_border_color: "#3C7FC0",
    system_db_bg_color: "#1168BD",
    system_db_border_color: "#3C7FC0",
    system_queue_bg_color: "#1168BD",
    system_queue_border_color: "#3C7FC0",
    external_system_bg_color: "#999999",
    external_system_border_color: "#8A8A8A",
    external_system_db_bg_color: "#999999",
    external_system_db_border_color: "#8A8A8A",
    external_system_queue_bg_color: "#999999",
    external_system_queue_border_color: "#8A8A8A",
    container_bg_color: "#438DD5",
    container_border_color: "#3C7FC0",
    container_db_bg_color: "#438DD5",
    container_db_border_color: "#3C7FC0",
    container_queue_bg_color: "#438DD5",
    container_queue_border_color: "#3C7FC0",
    external_container_bg_color: "#B3B3B3",
    external_container_border_color: "#A6A6A6",
    external_container_db_bg_color: "#B3B3B3",
    external_container_db_border_color: "#A6A6A6",
    external_container_queue_bg_color: "#B3B3B3",
    external_container_queue_border_color: "#A6A6A6",
    component_bg_color: "#85BBF0",
    component_border_color: "#78A8D8",
    component_db_bg_color: "#85BBF0",
    component_db_border_color: "#78A8D8",
    component_queue_bg_color: "#85BBF0",
    component_queue_border_color: "#78A8D8",
    external_component_bg_color: "#CCCCCC",
    external_component_border_color: "#BFBFBF",
    external_component_db_bg_color: "#CCCCCC",
    external_component_db_border_color: "#BFBFBF",
    external_component_queue_bg_color: "#CCCCCC",
    external_component_queue_border_color: "#BFBFBF"
  },
  sankey: {
    useMaxWidth: !0,
    width: 600,
    height: 400,
    linkColor: "gradient",
    nodeAlignment: "justify",
    showValues: !0,
    prefix: "",
    suffix: ""
  },
  block: {
    useMaxWidth: !0,
    padding: 8
  },
  packet: {
    useMaxWidth: !0,
    rowHeight: 32,
    bitWidth: 32,
    bitsPerRow: 32,
    showBits: !0,
    paddingX: 5,
    paddingY: 5
  },
  architecture: {
    useMaxWidth: !0,
    padding: 40,
    iconSize: 80,
    fontSize: 16
  },
  radar: {
    useMaxWidth: !0,
    width: 600,
    height: 600,
    marginTop: 50,
    marginRight: 50,
    marginBottom: 50,
    marginLeft: 50,
    axisScaleFactor: 1,
    axisLabelFactor: 1.05,
    curveTension: 0.17
  },
  theme: "default",
  look: "classic",
  handDrawnSeed: 0,
  layout: "dagre",
  maxTextSize: 5e4,
  maxEdges: 500,
  darkMode: !1,
  fontFamily: '"trebuchet ms", verdana, arial, sans-serif;',
  logLevel: 5,
  securityLevel: "strict",
  startOnLoad: !0,
  arrowMarkerAbsolute: !1,
  secure: [
    "secure",
    "securityLevel",
    "startOnLoad",
    "maxTextSize",
    "suppressErrorRendering",
    "maxEdges"
  ],
  legacyMathML: !1,
  forceLegacyMathML: !1,
  deterministicIds: !1,
  fontSize: 16,
  markdownAutoWrap: !0,
  suppressErrorRendering: !1
}, Dh = {
  ...xe,
  // Set, even though they're `undefined` so that `configKeys` finds these keys
  // TODO: Should we replace these with `null` so that they can go in the JSON Schema?
  deterministicIDSeed: void 0,
  elk: {
    // mergeEdges is needed here to be considered
    mergeEdges: !1,
    nodePlacementStrategy: "BRANDES_KOEPF",
    forceNodeModelOrder: !1,
    considerModelOrder: "NODES_AND_EDGES"
  },
  themeCSS: void 0,
  // add non-JSON default config values
  themeVariables: Oe.default.getThemeVariables(),
  sequence: {
    ...xe.sequence,
    messageFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.messageFontFamily,
        fontSize: this.messageFontSize,
        fontWeight: this.messageFontWeight
      };
    }, "messageFont"),
    noteFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.noteFontFamily,
        fontSize: this.noteFontSize,
        fontWeight: this.noteFontWeight
      };
    }, "noteFont"),
    actorFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.actorFontFamily,
        fontSize: this.actorFontSize,
        fontWeight: this.actorFontWeight
      };
    }, "actorFont")
  },
  class: {
    hideEmptyMembersBox: !1
  },
  gantt: {
    ...xe.gantt,
    tickInterval: void 0,
    useWidth: void 0
    // can probably be removed since `configKeys` already includes this
  },
  c4: {
    ...xe.c4,
    useWidth: void 0,
    personFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.personFontFamily,
        fontSize: this.personFontSize,
        fontWeight: this.personFontWeight
      };
    }, "personFont"),
    flowchart: {
      ...xe.flowchart,
      inheritDir: !1
      // default to legacy behavior
    },
    external_personFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_personFontFamily,
        fontSize: this.external_personFontSize,
        fontWeight: this.external_personFontWeight
      };
    }, "external_personFont"),
    systemFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.systemFontFamily,
        fontSize: this.systemFontSize,
        fontWeight: this.systemFontWeight
      };
    }, "systemFont"),
    external_systemFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_systemFontFamily,
        fontSize: this.external_systemFontSize,
        fontWeight: this.external_systemFontWeight
      };
    }, "external_systemFont"),
    system_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.system_dbFontFamily,
        fontSize: this.system_dbFontSize,
        fontWeight: this.system_dbFontWeight
      };
    }, "system_dbFont"),
    external_system_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_system_dbFontFamily,
        fontSize: this.external_system_dbFontSize,
        fontWeight: this.external_system_dbFontWeight
      };
    }, "external_system_dbFont"),
    system_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.system_queueFontFamily,
        fontSize: this.system_queueFontSize,
        fontWeight: this.system_queueFontWeight
      };
    }, "system_queueFont"),
    external_system_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_system_queueFontFamily,
        fontSize: this.external_system_queueFontSize,
        fontWeight: this.external_system_queueFontWeight
      };
    }, "external_system_queueFont"),
    containerFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.containerFontFamily,
        fontSize: this.containerFontSize,
        fontWeight: this.containerFontWeight
      };
    }, "containerFont"),
    external_containerFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_containerFontFamily,
        fontSize: this.external_containerFontSize,
        fontWeight: this.external_containerFontWeight
      };
    }, "external_containerFont"),
    container_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.container_dbFontFamily,
        fontSize: this.container_dbFontSize,
        fontWeight: this.container_dbFontWeight
      };
    }, "container_dbFont"),
    external_container_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_container_dbFontFamily,
        fontSize: this.external_container_dbFontSize,
        fontWeight: this.external_container_dbFontWeight
      };
    }, "external_container_dbFont"),
    container_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.container_queueFontFamily,
        fontSize: this.container_queueFontSize,
        fontWeight: this.container_queueFontWeight
      };
    }, "container_queueFont"),
    external_container_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_container_queueFontFamily,
        fontSize: this.external_container_queueFontSize,
        fontWeight: this.external_container_queueFontWeight
      };
    }, "external_container_queueFont"),
    componentFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.componentFontFamily,
        fontSize: this.componentFontSize,
        fontWeight: this.componentFontWeight
      };
    }, "componentFont"),
    external_componentFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_componentFontFamily,
        fontSize: this.external_componentFontSize,
        fontWeight: this.external_componentFontWeight
      };
    }, "external_componentFont"),
    component_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.component_dbFontFamily,
        fontSize: this.component_dbFontSize,
        fontWeight: this.component_dbFontWeight
      };
    }, "component_dbFont"),
    external_component_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_component_dbFontFamily,
        fontSize: this.external_component_dbFontSize,
        fontWeight: this.external_component_dbFontWeight
      };
    }, "external_component_dbFont"),
    component_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.component_queueFontFamily,
        fontSize: this.component_queueFontSize,
        fontWeight: this.component_queueFontWeight
      };
    }, "component_queueFont"),
    external_component_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_component_queueFontFamily,
        fontSize: this.external_component_queueFontSize,
        fontWeight: this.external_component_queueFontWeight
      };
    }, "external_component_queueFont"),
    boundaryFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.boundaryFontFamily,
        fontSize: this.boundaryFontSize,
        fontWeight: this.boundaryFontWeight
      };
    }, "boundaryFont"),
    messageFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.messageFontFamily,
        fontSize: this.messageFontSize,
        fontWeight: this.messageFontWeight
      };
    }, "messageFont")
  },
  pie: {
    ...xe.pie,
    useWidth: 984
  },
  xyChart: {
    ...xe.xyChart,
    useWidth: void 0
  },
  requirement: {
    ...xe.requirement,
    useWidth: void 0
  },
  packet: {
    ...xe.packet
  },
  radar: {
    ...xe.radar
  },
  treemap: {
    useMaxWidth: !0,
    padding: 10,
    diagramPadding: 8,
    showValues: !0,
    nodeWidth: 100,
    nodeHeight: 40,
    borderWidth: 1,
    valueFontSize: 12,
    labelFontSize: 14,
    valueFormat: ","
  }
}, Oh = /* @__PURE__ */ d((e, t = "") => Object.keys(e).reduce((r, i) => Array.isArray(e[i]) ? r : typeof e[i] == "object" && e[i] !== null ? [...r, t + i, ...Oh(e[i], "")] : [...r, t + i], []), "keyify"), Y0 = new Set(Oh(Dh, "")), Rh = Dh, Pn = /* @__PURE__ */ d((e) => {
  if (F.debug("sanitizeDirective called with", e), !(typeof e != "object" || e == null)) {
    if (Array.isArray(e)) {
      e.forEach((t) => Pn(t));
      return;
    }
    for (const t of Object.keys(e)) {
      if (F.debug("Checking key", t), t.startsWith("__") || t.includes("proto") || t.includes("constr") || !Y0.has(t) || e[t] == null) {
        F.debug("sanitize deleting key: ", t), delete e[t];
        continue;
      }
      if (typeof e[t] == "object") {
        F.debug("sanitizing object", t), Pn(e[t]);
        continue;
      }
      const r = ["themeCSS", "fontFamily", "altFontFamily"];
      for (const i of r)
        t.includes(i) && (F.debug("sanitizing css option", t), e[t] = U0(e[t]));
    }
    if (e.themeVariables)
      for (const t of Object.keys(e.themeVariables)) {
        const r = e.themeVariables[t];
        r != null && r.match && !r.match(/^[\d "#%(),.;A-Za-z]+$/) && (e.themeVariables[t] = "");
      }
    F.debug("After sanitization", e);
  }
}, "sanitizeDirective"), U0 = /* @__PURE__ */ d((e) => {
  let t = 0, r = 0;
  for (const i of e) {
    if (t < r)
      return "{ /* ERROR: Unbalanced CSS */ }";
    i === "{" ? t++ : i === "}" && r++;
  }
  return t !== r ? "{ /* ERROR: Unbalanced CSS */ }" : e;
}, "sanitizeCss"), Gr = Object.freeze(Rh), Kt = Bt({}, Gr), Nn, pr = [], Ei = Bt({}, Gr), ka = /* @__PURE__ */ d((e, t) => {
  let r = Bt({}, e), i = {};
  for (const n of t)
    Nh(n), i = Bt(i, n);
  if (r = Bt(r, i), i.theme && i.theme in Oe) {
    const n = Bt({}, Nn), a = Bt(
      n.themeVariables || {},
      i.themeVariables
    );
    r.theme && r.theme in Oe && (r.themeVariables = Oe[r.theme].getThemeVariables(a));
  }
  return Ei = r, zh(Ei), Ei;
}, "updateCurrentConfig"), G0 = /* @__PURE__ */ d((e) => (Kt = Bt({}, Gr), Kt = Bt(Kt, e), e.theme && Oe[e.theme] && (Kt.themeVariables = Oe[e.theme].getThemeVariables(e.themeVariables)), ka(Kt, pr), Kt), "setSiteConfig"), X0 = /* @__PURE__ */ d((e) => {
  Nn = Bt({}, e);
}, "saveConfigFromInitialize"), V0 = /* @__PURE__ */ d((e) => (Kt = Bt(Kt, e), ka(Kt, pr), Kt), "updateSiteConfig"), Ih = /* @__PURE__ */ d(() => Bt({}, Kt), "getSiteConfig"), Ph = /* @__PURE__ */ d((e) => (zh(e), Bt(Ei, e), Nt()), "setConfig"), Nt = /* @__PURE__ */ d(() => Bt({}, Ei), "getConfig"), Nh = /* @__PURE__ */ d((e) => {
  e && (["secure", ...Kt.secure ?? []].forEach((t) => {
    Object.hasOwn(e, t) && (F.debug(`Denied attempt to modify a secure key ${t}`, e[t]), delete e[t]);
  }), Object.keys(e).forEach((t) => {
    t.startsWith("__") && delete e[t];
  }), Object.keys(e).forEach((t) => {
    typeof e[t] == "string" && (e[t].includes("<") || e[t].includes(">") || e[t].includes("url(data:")) && delete e[t], typeof e[t] == "object" && Nh(e[t]);
  }));
}, "sanitize"), Z0 = /* @__PURE__ */ d((e) => {
  var t;
  Pn(e), e.fontFamily && !((t = e.themeVariables) != null && t.fontFamily) && (e.themeVariables = {
    ...e.themeVariables,
    fontFamily: e.fontFamily
  }), pr.push(e), ka(Kt, pr);
}, "addDirective"), zn = /* @__PURE__ */ d((e = Kt) => {
  pr = [], ka(e, pr);
}, "reset"), K0 = {
  LAZY_LOAD_DEPRECATED: "The configuration options lazyLoadedDiagrams and loadExternalDiagramsAtStartup are deprecated. Please use registerExternalDiagrams instead."
}, Jl = {}, Q0 = /* @__PURE__ */ d((e) => {
  Jl[e] || (F.warn(K0[e]), Jl[e] = !0);
}, "issueWarning"), zh = /* @__PURE__ */ d((e) => {
  e && (e.lazyLoadedDiagrams || e.loadExternalDiagramsAtStartup) && Q0("LAZY_LOAD_DEPRECATED");
}, "checkConfig"), ZA = /* @__PURE__ */ d(() => {
  let e = {};
  Nn && (e = Bt(e, Nn));
  for (const t of pr)
    e = Bt(e, t);
  return e;
}, "getUserDefinedConfig"), Vi = /<br\s*\/?>/gi, J0 = /* @__PURE__ */ d((e) => e ? Hh(e).replace(/\\n/g, "#br#").split("#br#") : [""], "getRows"), ty = /* @__PURE__ */ (() => {
  let e = !1;
  return () => {
    e || (Wh(), e = !0);
  };
})();
function Wh() {
  const e = "data-temp-href-target";
  Ur.addHook("beforeSanitizeAttributes", (t) => {
    t.tagName === "A" && t.hasAttribute("target") && t.setAttribute(e, t.getAttribute("target") ?? "");
  }), Ur.addHook("afterSanitizeAttributes", (t) => {
    t.tagName === "A" && t.hasAttribute(e) && (t.setAttribute("target", t.getAttribute(e) ?? ""), t.removeAttribute(e), t.getAttribute("target") === "_blank" && t.setAttribute("rel", "noopener"));
  });
}
d(Wh, "setupDompurifyHooks");
var qh = /* @__PURE__ */ d((e) => (ty(), Ur.sanitize(e)), "removeScript"), tc = /* @__PURE__ */ d((e, t) => {
  var r;
  if (((r = t.flowchart) == null ? void 0 : r.htmlLabels) !== !1) {
    const i = t.securityLevel;
    i === "antiscript" || i === "strict" ? e = qh(e) : i !== "loose" && (e = Hh(e), e = e.replace(/</g, "&lt;").replace(/>/g, "&gt;"), e = e.replace(/=/g, "&equals;"), e = ny(e));
  }
  return e;
}, "sanitizeMore"), se = /* @__PURE__ */ d((e, t) => e && (t.dompurifyConfig ? e = Ur.sanitize(tc(e, t), t.dompurifyConfig).toString() : e = Ur.sanitize(tc(e, t), {
  FORBID_TAGS: ["style"]
}).toString(), e), "sanitizeText"), ey = /* @__PURE__ */ d((e, t) => typeof e == "string" ? se(e, t) : e.flat().map((r) => se(r, t)), "sanitizeTextOrArray"), ry = /* @__PURE__ */ d((e) => Vi.test(e), "hasBreaks"), iy = /* @__PURE__ */ d((e) => e.split(Vi), "splitBreaks"), ny = /* @__PURE__ */ d((e) => e.replace(/#br#/g, "<br/>"), "placeholderToBreak"), Hh = /* @__PURE__ */ d((e) => e.replace(Vi, "#br#"), "breakToPlaceholder"), ay = /* @__PURE__ */ d((e) => {
  let t = "";
  return e && (t = window.location.protocol + "//" + window.location.host + window.location.pathname + window.location.search, t = CSS.escape(t)), t;
}, "getUrl"), Lt = /* @__PURE__ */ d((e) => !(e === !1 || ["false", "null", "0"].includes(String(e).trim().toLowerCase())), "evaluate"), sy = /* @__PURE__ */ d(function(...e) {
  const t = e.filter((r) => !isNaN(r));
  return Math.max(...t);
}, "getMax"), oy = /* @__PURE__ */ d(function(...e) {
  const t = e.filter((r) => !isNaN(r));
  return Math.min(...t);
}, "getMin"), ec = /* @__PURE__ */ d(function(e) {
  const t = e.split(/(,)/), r = [];
  for (let i = 0; i < t.length; i++) {
    let n = t[i];
    if (n === "," && i > 0 && i + 1 < t.length) {
      const a = t[i - 1], o = t[i + 1];
      ly(a, o) && (n = a + "," + o, i++, r.pop());
    }
    r.push(cy(n));
  }
  return r.join("");
}, "parseGenericTypes"), As = /* @__PURE__ */ d((e, t) => Math.max(0, e.split(t).length - 1), "countOccurrence"), ly = /* @__PURE__ */ d((e, t) => {
  const r = As(e, "~"), i = As(t, "~");
  return r === 1 && i === 1;
}, "shouldCombineSets"), cy = /* @__PURE__ */ d((e) => {
  const t = As(e, "~");
  let r = !1;
  if (t <= 1)
    return e;
  t % 2 !== 0 && e.startsWith("~") && (e = e.substring(1), r = !0);
  const i = [...e];
  let n = i.indexOf("~"), a = i.lastIndexOf("~");
  for (; n !== -1 && a !== -1 && n !== a; )
    i[n] = "<", i[a] = ">", n = i.indexOf("~"), a = i.lastIndexOf("~");
  return r && i.unshift("~"), i.join("");
}, "processSet"), rc = /* @__PURE__ */ d(() => window.MathMLElement !== void 0, "isMathMLSupported"), Ls = /\$\$(.*)\$\$/g, Xr = /* @__PURE__ */ d((e) => {
  var t;
  return (((t = e.match(Ls)) == null ? void 0 : t.length) ?? 0) > 0;
}, "hasKatex"), KA = /* @__PURE__ */ d(async (e, t) => {
  const r = document.createElement("div");
  r.innerHTML = await So(e, t), r.id = "katex-temp", r.style.visibility = "hidden", r.style.position = "absolute", r.style.top = "0";
  const i = document.querySelector("body");
  i == null || i.insertAdjacentElement("beforeend", r);
  const n = { width: r.clientWidth, height: r.clientHeight };
  return r.remove(), n;
}, "calculateMathMLDimensions"), hy = /* @__PURE__ */ d(async (e, t) => {
  if (!Xr(e))
    return e;
  if (!(rc() || t.legacyMathML || t.forceLegacyMathML))
    return e.replace(Ls, "MathML is unsupported in this environment.");
  {
    const { default: r } = await import("./katex-dDbcVckU.js"), i = t.forceLegacyMathML || !rc() && t.legacyMathML ? "htmlAndMathml" : "mathml";
    return e.split(Vi).map(
      (n) => Xr(n) ? `<div style="display: flex; align-items: center; justify-content: center; white-space: nowrap;">${n}</div>` : `<div>${n}</div>`
    ).join("").replace(
      Ls,
      (n, a) => r.renderToString(a, {
        throwOnError: !0,
        displayMode: !0,
        output: i
      }).replace(/\n/g, " ").replace(/<annotation.*<\/annotation>/g, "")
    );
  }
}, "renderKatexUnsanitized"), So = /* @__PURE__ */ d(async (e, t) => se(await hy(e, t), t), "renderKatexSanitized"), ei = {
  getRows: J0,
  sanitizeText: se,
  sanitizeTextOrArray: ey,
  hasBreaks: ry,
  splitBreaks: iy,
  lineBreakRegex: Vi,
  removeScript: qh,
  getUrl: ay,
  evaluate: Lt,
  getMax: sy,
  getMin: oy
}, uy = /* @__PURE__ */ d(function(e, t) {
  for (let r of t)
    e.attr(r[0], r[1]);
}, "d3Attrs"), fy = /* @__PURE__ */ d(function(e, t, r) {
  let i = /* @__PURE__ */ new Map();
  return r ? (i.set("width", "100%"), i.set("style", `max-width: ${t}px;`)) : (i.set("height", e), i.set("width", t)), i;
}, "calculateSvgSizeAttrs"), jh = /* @__PURE__ */ d(function(e, t, r, i) {
  const n = fy(t, r, i);
  uy(e, n);
}, "configureSvgSize"), py = /* @__PURE__ */ d(function(e, t, r, i) {
  const n = t.node().getBBox(), a = n.width, o = n.height;
  F.info(`SVG bounds: ${a}x${o}`, n);
  let s = 0, l = 0;
  F.info(`Graph bounds: ${s}x${l}`, e), s = a + r * 2, l = o + r * 2, F.info(`Calculated bounds: ${s}x${l}`), jh(t, l, s, i);
  const c = `${n.x - r} ${n.y - r} ${n.width + 2 * r} ${n.height + 2 * r}`;
  t.attr("viewBox", c);
}, "setupGraphViewbox"), Tn = {}, dy = /* @__PURE__ */ d((e, t, r) => {
  let i = "";
  return e in Tn && Tn[e] ? i = Tn[e](r) : F.warn(`No theme found for ${e}`), ` & {
    font-family: ${r.fontFamily};
    font-size: ${r.fontSize};
    fill: ${r.textColor}
  }
  @keyframes edge-animation-frame {
    from {
      stroke-dashoffset: 0;
    }
  }
  @keyframes dash {
    to {
      stroke-dashoffset: 0;
    }
  }
  & .edge-animation-slow {
    stroke-dasharray: 9,5 !important;
    stroke-dashoffset: 900;
    animation: dash 50s linear infinite;
    stroke-linecap: round;
  }
  & .edge-animation-fast {
    stroke-dasharray: 9,5 !important;
    stroke-dashoffset: 900;
    animation: dash 20s linear infinite;
    stroke-linecap: round;
  }
  /* Classes common for multiple diagrams */

  & .error-icon {
    fill: ${r.errorBkgColor};
  }
  & .error-text {
    fill: ${r.errorTextColor};
    stroke: ${r.errorTextColor};
  }

  & .edge-thickness-normal {
    stroke-width: 1px;
  }
  & .edge-thickness-thick {
    stroke-width: 3.5px
  }
  & .edge-pattern-solid {
    stroke-dasharray: 0;
  }
  & .edge-thickness-invisible {
    stroke-width: 0;
    fill: none;
  }
  & .edge-pattern-dashed{
    stroke-dasharray: 3;
  }
  .edge-pattern-dotted {
    stroke-dasharray: 2;
  }

  & .marker {
    fill: ${r.lineColor};
    stroke: ${r.lineColor};
  }
  & .marker.cross {
    stroke: ${r.lineColor};
  }

  & svg {
    font-family: ${r.fontFamily};
    font-size: ${r.fontSize};
  }
   & p {
    margin: 0
   }

  ${i}

  ${t}
`;
}, "getStyles"), gy = /* @__PURE__ */ d((e, t) => {
  t !== void 0 && (Tn[e] = t);
}, "addStylesForDiagram"), my = dy, Yh = {};
n0(Yh, {
  clear: () => yy,
  getAccDescription: () => _y,
  getAccTitle: () => by,
  getDiagramTitle: () => ky,
  setAccDescription: () => Cy,
  setAccTitle: () => xy,
  setDiagramTitle: () => wy
});
var To = "", Bo = "", Ao = "", Lo = /* @__PURE__ */ d((e) => se(e, Nt()), "sanitizeText"), yy = /* @__PURE__ */ d(() => {
  To = "", Ao = "", Bo = "";
}, "clear"), xy = /* @__PURE__ */ d((e) => {
  To = Lo(e).replace(/^\s+/g, "");
}, "setAccTitle"), by = /* @__PURE__ */ d(() => To, "getAccTitle"), Cy = /* @__PURE__ */ d((e) => {
  Ao = Lo(e).replace(/\n\s+/g, `
`);
}, "setAccDescription"), _y = /* @__PURE__ */ d(() => Ao, "getAccDescription"), wy = /* @__PURE__ */ d((e) => {
  Bo = Lo(e);
}, "setDiagramTitle"), ky = /* @__PURE__ */ d(() => Bo, "getDiagramTitle"), ic = F, vy = ko, pt = Nt, QA = Ph, JA = Gr, Mo = /* @__PURE__ */ d((e) => se(e, pt()), "sanitizeText"), Sy = py, Ty = /* @__PURE__ */ d(() => Yh, "getCommonDb"), Wn = {}, qn = /* @__PURE__ */ d((e, t, r) => {
  var i;
  Wn[e] && ic.warn(`Diagram with id ${e} already registered. Overwriting.`), Wn[e] = t, r && Fh(e, r), gy(e, t.styles), (i = t.injectUtils) == null || i.call(
    t,
    ic,
    vy,
    pt,
    Mo,
    Sy,
    Ty(),
    () => {
    }
  );
}, "registerDiagram"), Ms = /* @__PURE__ */ d((e) => {
  if (e in Wn)
    return Wn[e];
  throw new By(e);
}, "getDiagram"), jr, By = (jr = class extends Error {
  constructor(t) {
    super(`Diagram ${t} not found.`);
  }
}, d(jr, "DiagramNotFoundError"), jr), Ay = { value: () => {
} };
function Uh() {
  for (var e = 0, t = arguments.length, r = {}, i; e < t; ++e) {
    if (!(i = arguments[e] + "") || i in r || /[\s.]/.test(i)) throw new Error("illegal type: " + i);
    r[i] = [];
  }
  return new Bn(r);
}
function Bn(e) {
  this._ = e;
}
function Ly(e, t) {
  return e.trim().split(/^|\s+/).map(function(r) {
    var i = "", n = r.indexOf(".");
    if (n >= 0 && (i = r.slice(n + 1), r = r.slice(0, n)), r && !t.hasOwnProperty(r)) throw new Error("unknown type: " + r);
    return { type: r, name: i };
  });
}
Bn.prototype = Uh.prototype = {
  constructor: Bn,
  on: function(e, t) {
    var r = this._, i = Ly(e + "", r), n, a = -1, o = i.length;
    if (arguments.length < 2) {
      for (; ++a < o; ) if ((n = (e = i[a]).type) && (n = My(r[n], e.name))) return n;
      return;
    }
    if (t != null && typeof t != "function") throw new Error("invalid callback: " + t);
    for (; ++a < o; )
      if (n = (e = i[a]).type) r[n] = nc(r[n], e.name, t);
      else if (t == null) for (n in r) r[n] = nc(r[n], e.name, null);
    return this;
  },
  copy: function() {
    var e = {}, t = this._;
    for (var r in t) e[r] = t[r].slice();
    return new Bn(e);
  },
  call: function(e, t) {
    if ((n = arguments.length - 2) > 0) for (var r = new Array(n), i = 0, n, a; i < n; ++i) r[i] = arguments[i + 2];
    if (!this._.hasOwnProperty(e)) throw new Error("unknown type: " + e);
    for (a = this._[e], i = 0, n = a.length; i < n; ++i) a[i].value.apply(t, r);
  },
  apply: function(e, t, r) {
    if (!this._.hasOwnProperty(e)) throw new Error("unknown type: " + e);
    for (var i = this._[e], n = 0, a = i.length; n < a; ++n) i[n].value.apply(t, r);
  }
};
function My(e, t) {
  for (var r = 0, i = e.length, n; r < i; ++r)
    if ((n = e[r]).name === t)
      return n.value;
}
function nc(e, t, r) {
  for (var i = 0, n = e.length; i < n; ++i)
    if (e[i].name === t) {
      e[i] = Ay, e = e.slice(0, i).concat(e.slice(i + 1));
      break;
    }
  return r != null && e.push({ name: t, value: r }), e;
}
var $s = "http://www.w3.org/1999/xhtml";
const ac = {
  svg: "http://www.w3.org/2000/svg",
  xhtml: $s,
  xlink: "http://www.w3.org/1999/xlink",
  xml: "http://www.w3.org/XML/1998/namespace",
  xmlns: "http://www.w3.org/2000/xmlns/"
};
function va(e) {
  var t = e += "", r = t.indexOf(":");
  return r >= 0 && (t = e.slice(0, r)) !== "xmlns" && (e = e.slice(r + 1)), ac.hasOwnProperty(t) ? { space: ac[t], local: e } : e;
}
function $y(e) {
  return function() {
    var t = this.ownerDocument, r = this.namespaceURI;
    return r === $s && t.documentElement.namespaceURI === $s ? t.createElement(e) : t.createElementNS(r, e);
  };
}
function Ey(e) {
  return function() {
    return this.ownerDocument.createElementNS(e.space, e.local);
  };
}
function Gh(e) {
  var t = va(e);
  return (t.local ? Ey : $y)(t);
}
function Fy() {
}
function $o(e) {
  return e == null ? Fy : function() {
    return this.querySelector(e);
  };
}
function Dy(e) {
  typeof e != "function" && (e = $o(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], o = a.length, s = i[n] = new Array(o), l, c, h = 0; h < o; ++h)
      (l = a[h]) && (c = e.call(l, l.__data__, h, a)) && ("__data__" in l && (c.__data__ = l.__data__), s[h] = c);
  return new re(i, this._parents);
}
function Oy(e) {
  return e == null ? [] : Array.isArray(e) ? e : Array.from(e);
}
function Ry() {
  return [];
}
function Xh(e) {
  return e == null ? Ry : function() {
    return this.querySelectorAll(e);
  };
}
function Iy(e) {
  return function() {
    return Oy(e.apply(this, arguments));
  };
}
function Py(e) {
  typeof e == "function" ? e = Iy(e) : e = Xh(e);
  for (var t = this._groups, r = t.length, i = [], n = [], a = 0; a < r; ++a)
    for (var o = t[a], s = o.length, l, c = 0; c < s; ++c)
      (l = o[c]) && (i.push(e.call(l, l.__data__, c, o)), n.push(l));
  return new re(i, n);
}
function Vh(e) {
  return function() {
    return this.matches(e);
  };
}
function Zh(e) {
  return function(t) {
    return t.matches(e);
  };
}
var Ny = Array.prototype.find;
function zy(e) {
  return function() {
    return Ny.call(this.children, e);
  };
}
function Wy() {
  return this.firstElementChild;
}
function qy(e) {
  return this.select(e == null ? Wy : zy(typeof e == "function" ? e : Zh(e)));
}
var Hy = Array.prototype.filter;
function jy() {
  return Array.from(this.children);
}
function Yy(e) {
  return function() {
    return Hy.call(this.children, e);
  };
}
function Uy(e) {
  return this.selectAll(e == null ? jy : Yy(typeof e == "function" ? e : Zh(e)));
}
function Gy(e) {
  typeof e != "function" && (e = Vh(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], o = a.length, s = i[n] = [], l, c = 0; c < o; ++c)
      (l = a[c]) && e.call(l, l.__data__, c, a) && s.push(l);
  return new re(i, this._parents);
}
function Kh(e) {
  return new Array(e.length);
}
function Xy() {
  return new re(this._enter || this._groups.map(Kh), this._parents);
}
function Hn(e, t) {
  this.ownerDocument = e.ownerDocument, this.namespaceURI = e.namespaceURI, this._next = null, this._parent = e, this.__data__ = t;
}
Hn.prototype = {
  constructor: Hn,
  appendChild: function(e) {
    return this._parent.insertBefore(e, this._next);
  },
  insertBefore: function(e, t) {
    return this._parent.insertBefore(e, t);
  },
  querySelector: function(e) {
    return this._parent.querySelector(e);
  },
  querySelectorAll: function(e) {
    return this._parent.querySelectorAll(e);
  }
};
function Vy(e) {
  return function() {
    return e;
  };
}
function Zy(e, t, r, i, n, a) {
  for (var o = 0, s, l = t.length, c = a.length; o < c; ++o)
    (s = t[o]) ? (s.__data__ = a[o], i[o] = s) : r[o] = new Hn(e, a[o]);
  for (; o < l; ++o)
    (s = t[o]) && (n[o] = s);
}
function Ky(e, t, r, i, n, a, o) {
  var s, l, c = /* @__PURE__ */ new Map(), h = t.length, u = a.length, f = new Array(h), p;
  for (s = 0; s < h; ++s)
    (l = t[s]) && (f[s] = p = o.call(l, l.__data__, s, t) + "", c.has(p) ? n[s] = l : c.set(p, l));
  for (s = 0; s < u; ++s)
    p = o.call(e, a[s], s, a) + "", (l = c.get(p)) ? (i[s] = l, l.__data__ = a[s], c.delete(p)) : r[s] = new Hn(e, a[s]);
  for (s = 0; s < h; ++s)
    (l = t[s]) && c.get(f[s]) === l && (n[s] = l);
}
function Qy(e) {
  return e.__data__;
}
function Jy(e, t) {
  if (!arguments.length) return Array.from(this, Qy);
  var r = t ? Ky : Zy, i = this._parents, n = this._groups;
  typeof e != "function" && (e = Vy(e));
  for (var a = n.length, o = new Array(a), s = new Array(a), l = new Array(a), c = 0; c < a; ++c) {
    var h = i[c], u = n[c], f = u.length, p = tx(e.call(h, h && h.__data__, c, i)), g = p.length, m = s[c] = new Array(g), y = o[c] = new Array(g), x = l[c] = new Array(f);
    r(h, u, m, y, x, p, t);
    for (var b = 0, _ = 0, v, w; b < g; ++b)
      if (v = m[b]) {
        for (b >= _ && (_ = b + 1); !(w = y[_]) && ++_ < g; ) ;
        v._next = w || null;
      }
  }
  return o = new re(o, i), o._enter = s, o._exit = l, o;
}
function tx(e) {
  return typeof e == "object" && "length" in e ? e : Array.from(e);
}
function ex() {
  return new re(this._exit || this._groups.map(Kh), this._parents);
}
function rx(e, t, r) {
  var i = this.enter(), n = this, a = this.exit();
  return typeof e == "function" ? (i = e(i), i && (i = i.selection())) : i = i.append(e + ""), t != null && (n = t(n), n && (n = n.selection())), r == null ? a.remove() : r(a), i && n ? i.merge(n).order() : n;
}
function ix(e) {
  for (var t = e.selection ? e.selection() : e, r = this._groups, i = t._groups, n = r.length, a = i.length, o = Math.min(n, a), s = new Array(n), l = 0; l < o; ++l)
    for (var c = r[l], h = i[l], u = c.length, f = s[l] = new Array(u), p, g = 0; g < u; ++g)
      (p = c[g] || h[g]) && (f[g] = p);
  for (; l < n; ++l)
    s[l] = r[l];
  return new re(s, this._parents);
}
function nx() {
  for (var e = this._groups, t = -1, r = e.length; ++t < r; )
    for (var i = e[t], n = i.length - 1, a = i[n], o; --n >= 0; )
      (o = i[n]) && (a && o.compareDocumentPosition(a) ^ 4 && a.parentNode.insertBefore(o, a), a = o);
  return this;
}
function ax(e) {
  e || (e = sx);
  function t(u, f) {
    return u && f ? e(u.__data__, f.__data__) : !u - !f;
  }
  for (var r = this._groups, i = r.length, n = new Array(i), a = 0; a < i; ++a) {
    for (var o = r[a], s = o.length, l = n[a] = new Array(s), c, h = 0; h < s; ++h)
      (c = o[h]) && (l[h] = c);
    l.sort(t);
  }
  return new re(n, this._parents).order();
}
function sx(e, t) {
  return e < t ? -1 : e > t ? 1 : e >= t ? 0 : NaN;
}
function ox() {
  var e = arguments[0];
  return arguments[0] = this, e.apply(null, arguments), this;
}
function lx() {
  return Array.from(this);
}
function cx() {
  for (var e = this._groups, t = 0, r = e.length; t < r; ++t)
    for (var i = e[t], n = 0, a = i.length; n < a; ++n) {
      var o = i[n];
      if (o) return o;
    }
  return null;
}
function hx() {
  let e = 0;
  for (const t of this) ++e;
  return e;
}
function ux() {
  return !this.node();
}
function fx(e) {
  for (var t = this._groups, r = 0, i = t.length; r < i; ++r)
    for (var n = t[r], a = 0, o = n.length, s; a < o; ++a)
      (s = n[a]) && e.call(s, s.__data__, a, n);
  return this;
}
function px(e) {
  return function() {
    this.removeAttribute(e);
  };
}
function dx(e) {
  return function() {
    this.removeAttributeNS(e.space, e.local);
  };
}
function gx(e, t) {
  return function() {
    this.setAttribute(e, t);
  };
}
function mx(e, t) {
  return function() {
    this.setAttributeNS(e.space, e.local, t);
  };
}
function yx(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? this.removeAttribute(e) : this.setAttribute(e, r);
  };
}
function xx(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? this.removeAttributeNS(e.space, e.local) : this.setAttributeNS(e.space, e.local, r);
  };
}
function bx(e, t) {
  var r = va(e);
  if (arguments.length < 2) {
    var i = this.node();
    return r.local ? i.getAttributeNS(r.space, r.local) : i.getAttribute(r);
  }
  return this.each((t == null ? r.local ? dx : px : typeof t == "function" ? r.local ? xx : yx : r.local ? mx : gx)(r, t));
}
function Qh(e) {
  return e.ownerDocument && e.ownerDocument.defaultView || e.document && e || e.defaultView;
}
function Cx(e) {
  return function() {
    this.style.removeProperty(e);
  };
}
function _x(e, t, r) {
  return function() {
    this.style.setProperty(e, t, r);
  };
}
function wx(e, t, r) {
  return function() {
    var i = t.apply(this, arguments);
    i == null ? this.style.removeProperty(e) : this.style.setProperty(e, i, r);
  };
}
function kx(e, t, r) {
  return arguments.length > 1 ? this.each((t == null ? Cx : typeof t == "function" ? wx : _x)(e, t, r ?? "")) : Vr(this.node(), e);
}
function Vr(e, t) {
  return e.style.getPropertyValue(t) || Qh(e).getComputedStyle(e, null).getPropertyValue(t);
}
function vx(e) {
  return function() {
    delete this[e];
  };
}
function Sx(e, t) {
  return function() {
    this[e] = t;
  };
}
function Tx(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? delete this[e] : this[e] = r;
  };
}
function Bx(e, t) {
  return arguments.length > 1 ? this.each((t == null ? vx : typeof t == "function" ? Tx : Sx)(e, t)) : this.node()[e];
}
function Jh(e) {
  return e.trim().split(/^|\s+/);
}
function Eo(e) {
  return e.classList || new tu(e);
}
function tu(e) {
  this._node = e, this._names = Jh(e.getAttribute("class") || "");
}
tu.prototype = {
  add: function(e) {
    var t = this._names.indexOf(e);
    t < 0 && (this._names.push(e), this._node.setAttribute("class", this._names.join(" ")));
  },
  remove: function(e) {
    var t = this._names.indexOf(e);
    t >= 0 && (this._names.splice(t, 1), this._node.setAttribute("class", this._names.join(" ")));
  },
  contains: function(e) {
    return this._names.indexOf(e) >= 0;
  }
};
function eu(e, t) {
  for (var r = Eo(e), i = -1, n = t.length; ++i < n; ) r.add(t[i]);
}
function ru(e, t) {
  for (var r = Eo(e), i = -1, n = t.length; ++i < n; ) r.remove(t[i]);
}
function Ax(e) {
  return function() {
    eu(this, e);
  };
}
function Lx(e) {
  return function() {
    ru(this, e);
  };
}
function Mx(e, t) {
  return function() {
    (t.apply(this, arguments) ? eu : ru)(this, e);
  };
}
function $x(e, t) {
  var r = Jh(e + "");
  if (arguments.length < 2) {
    for (var i = Eo(this.node()), n = -1, a = r.length; ++n < a; ) if (!i.contains(r[n])) return !1;
    return !0;
  }
  return this.each((typeof t == "function" ? Mx : t ? Ax : Lx)(r, t));
}
function Ex() {
  this.textContent = "";
}
function Fx(e) {
  return function() {
    this.textContent = e;
  };
}
function Dx(e) {
  return function() {
    var t = e.apply(this, arguments);
    this.textContent = t ?? "";
  };
}
function Ox(e) {
  return arguments.length ? this.each(e == null ? Ex : (typeof e == "function" ? Dx : Fx)(e)) : this.node().textContent;
}
function Rx() {
  this.innerHTML = "";
}
function Ix(e) {
  return function() {
    this.innerHTML = e;
  };
}
function Px(e) {
  return function() {
    var t = e.apply(this, arguments);
    this.innerHTML = t ?? "";
  };
}
function Nx(e) {
  return arguments.length ? this.each(e == null ? Rx : (typeof e == "function" ? Px : Ix)(e)) : this.node().innerHTML;
}
function zx() {
  this.nextSibling && this.parentNode.appendChild(this);
}
function Wx() {
  return this.each(zx);
}
function qx() {
  this.previousSibling && this.parentNode.insertBefore(this, this.parentNode.firstChild);
}
function Hx() {
  return this.each(qx);
}
function jx(e) {
  var t = typeof e == "function" ? e : Gh(e);
  return this.select(function() {
    return this.appendChild(t.apply(this, arguments));
  });
}
function Yx() {
  return null;
}
function Ux(e, t) {
  var r = typeof e == "function" ? e : Gh(e), i = t == null ? Yx : typeof t == "function" ? t : $o(t);
  return this.select(function() {
    return this.insertBefore(r.apply(this, arguments), i.apply(this, arguments) || null);
  });
}
function Gx() {
  var e = this.parentNode;
  e && e.removeChild(this);
}
function Xx() {
  return this.each(Gx);
}
function Vx() {
  var e = this.cloneNode(!1), t = this.parentNode;
  return t ? t.insertBefore(e, this.nextSibling) : e;
}
function Zx() {
  var e = this.cloneNode(!0), t = this.parentNode;
  return t ? t.insertBefore(e, this.nextSibling) : e;
}
function Kx(e) {
  return this.select(e ? Zx : Vx);
}
function Qx(e) {
  return arguments.length ? this.property("__data__", e) : this.node().__data__;
}
function Jx(e) {
  return function(t) {
    e.call(this, t, this.__data__);
  };
}
function tb(e) {
  return e.trim().split(/^|\s+/).map(function(t) {
    var r = "", i = t.indexOf(".");
    return i >= 0 && (r = t.slice(i + 1), t = t.slice(0, i)), { type: t, name: r };
  });
}
function eb(e) {
  return function() {
    var t = this.__on;
    if (t) {
      for (var r = 0, i = -1, n = t.length, a; r < n; ++r)
        a = t[r], (!e.type || a.type === e.type) && a.name === e.name ? this.removeEventListener(a.type, a.listener, a.options) : t[++i] = a;
      ++i ? t.length = i : delete this.__on;
    }
  };
}
function rb(e, t, r) {
  return function() {
    var i = this.__on, n, a = Jx(t);
    if (i) {
      for (var o = 0, s = i.length; o < s; ++o)
        if ((n = i[o]).type === e.type && n.name === e.name) {
          this.removeEventListener(n.type, n.listener, n.options), this.addEventListener(n.type, n.listener = a, n.options = r), n.value = t;
          return;
        }
    }
    this.addEventListener(e.type, a, r), n = { type: e.type, name: e.name, value: t, listener: a, options: r }, i ? i.push(n) : this.__on = [n];
  };
}
function ib(e, t, r) {
  var i = tb(e + ""), n, a = i.length, o;
  if (arguments.length < 2) {
    var s = this.node().__on;
    if (s) {
      for (var l = 0, c = s.length, h; l < c; ++l)
        for (n = 0, h = s[l]; n < a; ++n)
          if ((o = i[n]).type === h.type && o.name === h.name)
            return h.value;
    }
    return;
  }
  for (s = t ? rb : eb, n = 0; n < a; ++n) this.each(s(i[n], t, r));
  return this;
}
function iu(e, t, r) {
  var i = Qh(e), n = i.CustomEvent;
  typeof n == "function" ? n = new n(t, r) : (n = i.document.createEvent("Event"), r ? (n.initEvent(t, r.bubbles, r.cancelable), n.detail = r.detail) : n.initEvent(t, !1, !1)), e.dispatchEvent(n);
}
function nb(e, t) {
  return function() {
    return iu(this, e, t);
  };
}
function ab(e, t) {
  return function() {
    return iu(this, e, t.apply(this, arguments));
  };
}
function sb(e, t) {
  return this.each((typeof t == "function" ? ab : nb)(e, t));
}
function* ob() {
  for (var e = this._groups, t = 0, r = e.length; t < r; ++t)
    for (var i = e[t], n = 0, a = i.length, o; n < a; ++n)
      (o = i[n]) && (yield o);
}
var nu = [null];
function re(e, t) {
  this._groups = e, this._parents = t;
}
function Zi() {
  return new re([[document.documentElement]], nu);
}
function lb() {
  return this;
}
re.prototype = Zi.prototype = {
  constructor: re,
  select: Dy,
  selectAll: Py,
  selectChild: qy,
  selectChildren: Uy,
  filter: Gy,
  data: Jy,
  enter: Xy,
  exit: ex,
  join: rx,
  merge: ix,
  selection: lb,
  order: nx,
  sort: ax,
  call: ox,
  nodes: lx,
  node: cx,
  size: hx,
  empty: ux,
  each: fx,
  attr: bx,
  style: kx,
  property: Bx,
  classed: $x,
  text: Ox,
  html: Nx,
  raise: Wx,
  lower: Hx,
  append: jx,
  insert: Ux,
  remove: Xx,
  clone: Kx,
  datum: Qx,
  on: ib,
  dispatch: sb,
  [Symbol.iterator]: ob
};
function ht(e) {
  return typeof e == "string" ? new re([[document.querySelector(e)]], [document.documentElement]) : new re([[e]], nu);
}
function Fo(e, t, r) {
  e.prototype = t.prototype = r, r.constructor = e;
}
function au(e, t) {
  var r = Object.create(e.prototype);
  for (var i in t) r[i] = t[i];
  return r;
}
function Ki() {
}
var Oi = 0.7, jn = 1 / Oi, Rr = "\\s*([+-]?\\d+)\\s*", Ri = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*", we = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*", cb = /^#([0-9a-f]{3,8})$/, hb = new RegExp(`^rgb\\(${Rr},${Rr},${Rr}\\)$`), ub = new RegExp(`^rgb\\(${we},${we},${we}\\)$`), fb = new RegExp(`^rgba\\(${Rr},${Rr},${Rr},${Ri}\\)$`), pb = new RegExp(`^rgba\\(${we},${we},${we},${Ri}\\)$`), db = new RegExp(`^hsl\\(${Ri},${we},${we}\\)$`), gb = new RegExp(`^hsla\\(${Ri},${we},${we},${Ri}\\)$`), sc = {
  aliceblue: 15792383,
  antiquewhite: 16444375,
  aqua: 65535,
  aquamarine: 8388564,
  azure: 15794175,
  beige: 16119260,
  bisque: 16770244,
  black: 0,
  blanchedalmond: 16772045,
  blue: 255,
  blueviolet: 9055202,
  brown: 10824234,
  burlywood: 14596231,
  cadetblue: 6266528,
  chartreuse: 8388352,
  chocolate: 13789470,
  coral: 16744272,
  cornflowerblue: 6591981,
  cornsilk: 16775388,
  crimson: 14423100,
  cyan: 65535,
  darkblue: 139,
  darkcyan: 35723,
  darkgoldenrod: 12092939,
  darkgray: 11119017,
  darkgreen: 25600,
  darkgrey: 11119017,
  darkkhaki: 12433259,
  darkmagenta: 9109643,
  darkolivegreen: 5597999,
  darkorange: 16747520,
  darkorchid: 10040012,
  darkred: 9109504,
  darksalmon: 15308410,
  darkseagreen: 9419919,
  darkslateblue: 4734347,
  darkslategray: 3100495,
  darkslategrey: 3100495,
  darkturquoise: 52945,
  darkviolet: 9699539,
  deeppink: 16716947,
  deepskyblue: 49151,
  dimgray: 6908265,
  dimgrey: 6908265,
  dodgerblue: 2003199,
  firebrick: 11674146,
  floralwhite: 16775920,
  forestgreen: 2263842,
  fuchsia: 16711935,
  gainsboro: 14474460,
  ghostwhite: 16316671,
  gold: 16766720,
  goldenrod: 14329120,
  gray: 8421504,
  green: 32768,
  greenyellow: 11403055,
  grey: 8421504,
  honeydew: 15794160,
  hotpink: 16738740,
  indianred: 13458524,
  indigo: 4915330,
  ivory: 16777200,
  khaki: 15787660,
  lavender: 15132410,
  lavenderblush: 16773365,
  lawngreen: 8190976,
  lemonchiffon: 16775885,
  lightblue: 11393254,
  lightcoral: 15761536,
  lightcyan: 14745599,
  lightgoldenrodyellow: 16448210,
  lightgray: 13882323,
  lightgreen: 9498256,
  lightgrey: 13882323,
  lightpink: 16758465,
  lightsalmon: 16752762,
  lightseagreen: 2142890,
  lightskyblue: 8900346,
  lightslategray: 7833753,
  lightslategrey: 7833753,
  lightsteelblue: 11584734,
  lightyellow: 16777184,
  lime: 65280,
  limegreen: 3329330,
  linen: 16445670,
  magenta: 16711935,
  maroon: 8388608,
  mediumaquamarine: 6737322,
  mediumblue: 205,
  mediumorchid: 12211667,
  mediumpurple: 9662683,
  mediumseagreen: 3978097,
  mediumslateblue: 8087790,
  mediumspringgreen: 64154,
  mediumturquoise: 4772300,
  mediumvioletred: 13047173,
  midnightblue: 1644912,
  mintcream: 16121850,
  mistyrose: 16770273,
  moccasin: 16770229,
  navajowhite: 16768685,
  navy: 128,
  oldlace: 16643558,
  olive: 8421376,
  olivedrab: 7048739,
  orange: 16753920,
  orangered: 16729344,
  orchid: 14315734,
  palegoldenrod: 15657130,
  palegreen: 10025880,
  paleturquoise: 11529966,
  palevioletred: 14381203,
  papayawhip: 16773077,
  peachpuff: 16767673,
  peru: 13468991,
  pink: 16761035,
  plum: 14524637,
  powderblue: 11591910,
  purple: 8388736,
  rebeccapurple: 6697881,
  red: 16711680,
  rosybrown: 12357519,
  royalblue: 4286945,
  saddlebrown: 9127187,
  salmon: 16416882,
  sandybrown: 16032864,
  seagreen: 3050327,
  seashell: 16774638,
  sienna: 10506797,
  silver: 12632256,
  skyblue: 8900331,
  slateblue: 6970061,
  slategray: 7372944,
  slategrey: 7372944,
  snow: 16775930,
  springgreen: 65407,
  steelblue: 4620980,
  tan: 13808780,
  teal: 32896,
  thistle: 14204888,
  tomato: 16737095,
  turquoise: 4251856,
  violet: 15631086,
  wheat: 16113331,
  white: 16777215,
  whitesmoke: 16119285,
  yellow: 16776960,
  yellowgreen: 10145074
};
Fo(Ki, Ii, {
  copy(e) {
    return Object.assign(new this.constructor(), this, e);
  },
  displayable() {
    return this.rgb().displayable();
  },
  hex: oc,
  // Deprecated! Use color.formatHex.
  formatHex: oc,
  formatHex8: mb,
  formatHsl: yb,
  formatRgb: lc,
  toString: lc
});
function oc() {
  return this.rgb().formatHex();
}
function mb() {
  return this.rgb().formatHex8();
}
function yb() {
  return su(this).formatHsl();
}
function lc() {
  return this.rgb().formatRgb();
}
function Ii(e) {
  var t, r;
  return e = (e + "").trim().toLowerCase(), (t = cb.exec(e)) ? (r = t[1].length, t = parseInt(t[1], 16), r === 6 ? cc(t) : r === 3 ? new Jt(t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, (t & 15) << 4 | t & 15, 1) : r === 8 ? pn(t >> 24 & 255, t >> 16 & 255, t >> 8 & 255, (t & 255) / 255) : r === 4 ? pn(t >> 12 & 15 | t >> 8 & 240, t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, ((t & 15) << 4 | t & 15) / 255) : null) : (t = hb.exec(e)) ? new Jt(t[1], t[2], t[3], 1) : (t = ub.exec(e)) ? new Jt(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, 1) : (t = fb.exec(e)) ? pn(t[1], t[2], t[3], t[4]) : (t = pb.exec(e)) ? pn(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, t[4]) : (t = db.exec(e)) ? fc(t[1], t[2] / 100, t[3] / 100, 1) : (t = gb.exec(e)) ? fc(t[1], t[2] / 100, t[3] / 100, t[4]) : sc.hasOwnProperty(e) ? cc(sc[e]) : e === "transparent" ? new Jt(NaN, NaN, NaN, 0) : null;
}
function cc(e) {
  return new Jt(e >> 16 & 255, e >> 8 & 255, e & 255, 1);
}
function pn(e, t, r, i) {
  return i <= 0 && (e = t = r = NaN), new Jt(e, t, r, i);
}
function xb(e) {
  return e instanceof Ki || (e = Ii(e)), e ? (e = e.rgb(), new Jt(e.r, e.g, e.b, e.opacity)) : new Jt();
}
function Es(e, t, r, i) {
  return arguments.length === 1 ? xb(e) : new Jt(e, t, r, i ?? 1);
}
function Jt(e, t, r, i) {
  this.r = +e, this.g = +t, this.b = +r, this.opacity = +i;
}
Fo(Jt, Es, au(Ki, {
  brighter(e) {
    return e = e == null ? jn : Math.pow(jn, e), new Jt(this.r * e, this.g * e, this.b * e, this.opacity);
  },
  darker(e) {
    return e = e == null ? Oi : Math.pow(Oi, e), new Jt(this.r * e, this.g * e, this.b * e, this.opacity);
  },
  rgb() {
    return this;
  },
  clamp() {
    return new Jt(hr(this.r), hr(this.g), hr(this.b), Yn(this.opacity));
  },
  displayable() {
    return -0.5 <= this.r && this.r < 255.5 && -0.5 <= this.g && this.g < 255.5 && -0.5 <= this.b && this.b < 255.5 && 0 <= this.opacity && this.opacity <= 1;
  },
  hex: hc,
  // Deprecated! Use color.formatHex.
  formatHex: hc,
  formatHex8: bb,
  formatRgb: uc,
  toString: uc
}));
function hc() {
  return `#${sr(this.r)}${sr(this.g)}${sr(this.b)}`;
}
function bb() {
  return `#${sr(this.r)}${sr(this.g)}${sr(this.b)}${sr((isNaN(this.opacity) ? 1 : this.opacity) * 255)}`;
}
function uc() {
  const e = Yn(this.opacity);
  return `${e === 1 ? "rgb(" : "rgba("}${hr(this.r)}, ${hr(this.g)}, ${hr(this.b)}${e === 1 ? ")" : `, ${e})`}`;
}
function Yn(e) {
  return isNaN(e) ? 1 : Math.max(0, Math.min(1, e));
}
function hr(e) {
  return Math.max(0, Math.min(255, Math.round(e) || 0));
}
function sr(e) {
  return e = hr(e), (e < 16 ? "0" : "") + e.toString(16);
}
function fc(e, t, r, i) {
  return i <= 0 ? e = t = r = NaN : r <= 0 || r >= 1 ? e = t = NaN : t <= 0 && (e = NaN), new fe(e, t, r, i);
}
function su(e) {
  if (e instanceof fe) return new fe(e.h, e.s, e.l, e.opacity);
  if (e instanceof Ki || (e = Ii(e)), !e) return new fe();
  if (e instanceof fe) return e;
  e = e.rgb();
  var t = e.r / 255, r = e.g / 255, i = e.b / 255, n = Math.min(t, r, i), a = Math.max(t, r, i), o = NaN, s = a - n, l = (a + n) / 2;
  return s ? (t === a ? o = (r - i) / s + (r < i) * 6 : r === a ? o = (i - t) / s + 2 : o = (t - r) / s + 4, s /= l < 0.5 ? a + n : 2 - a - n, o *= 60) : s = l > 0 && l < 1 ? 0 : o, new fe(o, s, l, e.opacity);
}
function Cb(e, t, r, i) {
  return arguments.length === 1 ? su(e) : new fe(e, t, r, i ?? 1);
}
function fe(e, t, r, i) {
  this.h = +e, this.s = +t, this.l = +r, this.opacity = +i;
}
Fo(fe, Cb, au(Ki, {
  brighter(e) {
    return e = e == null ? jn : Math.pow(jn, e), new fe(this.h, this.s, this.l * e, this.opacity);
  },
  darker(e) {
    return e = e == null ? Oi : Math.pow(Oi, e), new fe(this.h, this.s, this.l * e, this.opacity);
  },
  rgb() {
    var e = this.h % 360 + (this.h < 0) * 360, t = isNaN(e) || isNaN(this.s) ? 0 : this.s, r = this.l, i = r + (r < 0.5 ? r : 1 - r) * t, n = 2 * r - i;
    return new Jt(
      ls(e >= 240 ? e - 240 : e + 120, n, i),
      ls(e, n, i),
      ls(e < 120 ? e + 240 : e - 120, n, i),
      this.opacity
    );
  },
  clamp() {
    return new fe(pc(this.h), dn(this.s), dn(this.l), Yn(this.opacity));
  },
  displayable() {
    return (0 <= this.s && this.s <= 1 || isNaN(this.s)) && 0 <= this.l && this.l <= 1 && 0 <= this.opacity && this.opacity <= 1;
  },
  formatHsl() {
    const e = Yn(this.opacity);
    return `${e === 1 ? "hsl(" : "hsla("}${pc(this.h)}, ${dn(this.s) * 100}%, ${dn(this.l) * 100}%${e === 1 ? ")" : `, ${e})`}`;
  }
}));
function pc(e) {
  return e = (e || 0) % 360, e < 0 ? e + 360 : e;
}
function dn(e) {
  return Math.max(0, Math.min(1, e || 0));
}
function ls(e, t, r) {
  return (e < 60 ? t + (r - t) * e / 60 : e < 180 ? r : e < 240 ? t + (r - t) * (240 - e) / 60 : t) * 255;
}
const Do = (e) => () => e;
function ou(e, t) {
  return function(r) {
    return e + r * t;
  };
}
function _b(e, t, r) {
  return e = Math.pow(e, r), t = Math.pow(t, r) - e, r = 1 / r, function(i) {
    return Math.pow(e + i * t, r);
  };
}
function tL(e, t) {
  var r = t - e;
  return r ? ou(e, r > 180 || r < -180 ? r - 360 * Math.round(r / 360) : r) : Do(isNaN(e) ? t : e);
}
function wb(e) {
  return (e = +e) == 1 ? lu : function(t, r) {
    return r - t ? _b(t, r, e) : Do(isNaN(t) ? r : t);
  };
}
function lu(e, t) {
  var r = t - e;
  return r ? ou(e, r) : Do(isNaN(e) ? t : e);
}
const dc = function e(t) {
  var r = wb(t);
  function i(n, a) {
    var o = r((n = Es(n)).r, (a = Es(a)).r), s = r(n.g, a.g), l = r(n.b, a.b), c = lu(n.opacity, a.opacity);
    return function(h) {
      return n.r = o(h), n.g = s(h), n.b = l(h), n.opacity = c(h), n + "";
    };
  }
  return i.gamma = e, i;
}(1);
function qe(e, t) {
  return e = +e, t = +t, function(r) {
    return e * (1 - r) + t * r;
  };
}
var Fs = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g, cs = new RegExp(Fs.source, "g");
function kb(e) {
  return function() {
    return e;
  };
}
function vb(e) {
  return function(t) {
    return e(t) + "";
  };
}
function Sb(e, t) {
  var r = Fs.lastIndex = cs.lastIndex = 0, i, n, a, o = -1, s = [], l = [];
  for (e = e + "", t = t + ""; (i = Fs.exec(e)) && (n = cs.exec(t)); )
    (a = n.index) > r && (a = t.slice(r, a), s[o] ? s[o] += a : s[++o] = a), (i = i[0]) === (n = n[0]) ? s[o] ? s[o] += n : s[++o] = n : (s[++o] = null, l.push({ i: o, x: qe(i, n) })), r = cs.lastIndex;
  return r < t.length && (a = t.slice(r), s[o] ? s[o] += a : s[++o] = a), s.length < 2 ? l[0] ? vb(l[0].x) : kb(t) : (t = l.length, function(c) {
    for (var h = 0, u; h < t; ++h) s[(u = l[h]).i] = u.x(c);
    return s.join("");
  });
}
var gc = 180 / Math.PI, Ds = {
  translateX: 0,
  translateY: 0,
  rotate: 0,
  skewX: 0,
  scaleX: 1,
  scaleY: 1
};
function cu(e, t, r, i, n, a) {
  var o, s, l;
  return (o = Math.sqrt(e * e + t * t)) && (e /= o, t /= o), (l = e * r + t * i) && (r -= e * l, i -= t * l), (s = Math.sqrt(r * r + i * i)) && (r /= s, i /= s, l /= s), e * i < t * r && (e = -e, t = -t, l = -l, o = -o), {
    translateX: n,
    translateY: a,
    rotate: Math.atan2(t, e) * gc,
    skewX: Math.atan(l) * gc,
    scaleX: o,
    scaleY: s
  };
}
var gn;
function Tb(e) {
  const t = new (typeof DOMMatrix == "function" ? DOMMatrix : WebKitCSSMatrix)(e + "");
  return t.isIdentity ? Ds : cu(t.a, t.b, t.c, t.d, t.e, t.f);
}
function Bb(e) {
  return e == null || (gn || (gn = document.createElementNS("http://www.w3.org/2000/svg", "g")), gn.setAttribute("transform", e), !(e = gn.transform.baseVal.consolidate())) ? Ds : (e = e.matrix, cu(e.a, e.b, e.c, e.d, e.e, e.f));
}
function hu(e, t, r, i) {
  function n(c) {
    return c.length ? c.pop() + " " : "";
  }
  function a(c, h, u, f, p, g) {
    if (c !== u || h !== f) {
      var m = p.push("translate(", null, t, null, r);
      g.push({ i: m - 4, x: qe(c, u) }, { i: m - 2, x: qe(h, f) });
    } else (u || f) && p.push("translate(" + u + t + f + r);
  }
  function o(c, h, u, f) {
    c !== h ? (c - h > 180 ? h += 360 : h - c > 180 && (c += 360), f.push({ i: u.push(n(u) + "rotate(", null, i) - 2, x: qe(c, h) })) : h && u.push(n(u) + "rotate(" + h + i);
  }
  function s(c, h, u, f) {
    c !== h ? f.push({ i: u.push(n(u) + "skewX(", null, i) - 2, x: qe(c, h) }) : h && u.push(n(u) + "skewX(" + h + i);
  }
  function l(c, h, u, f, p, g) {
    if (c !== u || h !== f) {
      var m = p.push(n(p) + "scale(", null, ",", null, ")");
      g.push({ i: m - 4, x: qe(c, u) }, { i: m - 2, x: qe(h, f) });
    } else (u !== 1 || f !== 1) && p.push(n(p) + "scale(" + u + "," + f + ")");
  }
  return function(c, h) {
    var u = [], f = [];
    return c = e(c), h = e(h), a(c.translateX, c.translateY, h.translateX, h.translateY, u, f), o(c.rotate, h.rotate, u, f), s(c.skewX, h.skewX, u, f), l(c.scaleX, c.scaleY, h.scaleX, h.scaleY, u, f), c = h = null, function(p) {
      for (var g = -1, m = f.length, y; ++g < m; ) u[(y = f[g]).i] = y.x(p);
      return u.join("");
    };
  };
}
var Ab = hu(Tb, "px, ", "px)", "deg)"), Lb = hu(Bb, ", ", ")", ")"), Zr = 0, _i = 0, di = 0, uu = 1e3, Un, wi, Gn = 0, dr = 0, Sa = 0, Pi = typeof performance == "object" && performance.now ? performance : Date, fu = typeof window == "object" && window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : function(e) {
  setTimeout(e, 17);
};
function Oo() {
  return dr || (fu(Mb), dr = Pi.now() + Sa);
}
function Mb() {
  dr = 0;
}
function Xn() {
  this._call = this._time = this._next = null;
}
Xn.prototype = pu.prototype = {
  constructor: Xn,
  restart: function(e, t, r) {
    if (typeof e != "function") throw new TypeError("callback is not a function");
    r = (r == null ? Oo() : +r) + (t == null ? 0 : +t), !this._next && wi !== this && (wi ? wi._next = this : Un = this, wi = this), this._call = e, this._time = r, Os();
  },
  stop: function() {
    this._call && (this._call = null, this._time = 1 / 0, Os());
  }
};
function pu(e, t, r) {
  var i = new Xn();
  return i.restart(e, t, r), i;
}
function $b() {
  Oo(), ++Zr;
  for (var e = Un, t; e; )
    (t = dr - e._time) >= 0 && e._call.call(void 0, t), e = e._next;
  --Zr;
}
function mc() {
  dr = (Gn = Pi.now()) + Sa, Zr = _i = 0;
  try {
    $b();
  } finally {
    Zr = 0, Fb(), dr = 0;
  }
}
function Eb() {
  var e = Pi.now(), t = e - Gn;
  t > uu && (Sa -= t, Gn = e);
}
function Fb() {
  for (var e, t = Un, r, i = 1 / 0; t; )
    t._call ? (i > t._time && (i = t._time), e = t, t = t._next) : (r = t._next, t._next = null, t = e ? e._next = r : Un = r);
  wi = e, Os(i);
}
function Os(e) {
  if (!Zr) {
    _i && (_i = clearTimeout(_i));
    var t = e - dr;
    t > 24 ? (e < 1 / 0 && (_i = setTimeout(mc, e - Pi.now() - Sa)), di && (di = clearInterval(di))) : (di || (Gn = Pi.now(), di = setInterval(Eb, uu)), Zr = 1, fu(mc));
  }
}
function yc(e, t, r) {
  var i = new Xn();
  return t = t == null ? 0 : +t, i.restart((n) => {
    i.stop(), e(n + t);
  }, t, r), i;
}
var Db = Uh("start", "end", "cancel", "interrupt"), Ob = [], du = 0, xc = 1, Rs = 2, An = 3, bc = 4, Is = 5, Ln = 6;
function Ta(e, t, r, i, n, a) {
  var o = e.__transition;
  if (!o) e.__transition = {};
  else if (r in o) return;
  Rb(e, r, {
    name: t,
    index: i,
    // For context during callback.
    group: n,
    // For context during callback.
    on: Db,
    tween: Ob,
    time: a.time,
    delay: a.delay,
    duration: a.duration,
    ease: a.ease,
    timer: null,
    state: du
  });
}
function Ro(e, t) {
  var r = me(e, t);
  if (r.state > du) throw new Error("too late; already scheduled");
  return r;
}
function Se(e, t) {
  var r = me(e, t);
  if (r.state > An) throw new Error("too late; already running");
  return r;
}
function me(e, t) {
  var r = e.__transition;
  if (!r || !(r = r[t])) throw new Error("transition not found");
  return r;
}
function Rb(e, t, r) {
  var i = e.__transition, n;
  i[t] = r, r.timer = pu(a, 0, r.time);
  function a(c) {
    r.state = xc, r.timer.restart(o, r.delay, r.time), r.delay <= c && o(c - r.delay);
  }
  function o(c) {
    var h, u, f, p;
    if (r.state !== xc) return l();
    for (h in i)
      if (p = i[h], p.name === r.name) {
        if (p.state === An) return yc(o);
        p.state === bc ? (p.state = Ln, p.timer.stop(), p.on.call("interrupt", e, e.__data__, p.index, p.group), delete i[h]) : +h < t && (p.state = Ln, p.timer.stop(), p.on.call("cancel", e, e.__data__, p.index, p.group), delete i[h]);
      }
    if (yc(function() {
      r.state === An && (r.state = bc, r.timer.restart(s, r.delay, r.time), s(c));
    }), r.state = Rs, r.on.call("start", e, e.__data__, r.index, r.group), r.state === Rs) {
      for (r.state = An, n = new Array(f = r.tween.length), h = 0, u = -1; h < f; ++h)
        (p = r.tween[h].value.call(e, e.__data__, r.index, r.group)) && (n[++u] = p);
      n.length = u + 1;
    }
  }
  function s(c) {
    for (var h = c < r.duration ? r.ease.call(null, c / r.duration) : (r.timer.restart(l), r.state = Is, 1), u = -1, f = n.length; ++u < f; )
      n[u].call(e, h);
    r.state === Is && (r.on.call("end", e, e.__data__, r.index, r.group), l());
  }
  function l() {
    r.state = Ln, r.timer.stop(), delete i[t];
    for (var c in i) return;
    delete e.__transition;
  }
}
function Ib(e, t) {
  var r = e.__transition, i, n, a = !0, o;
  if (r) {
    t = t == null ? null : t + "";
    for (o in r) {
      if ((i = r[o]).name !== t) {
        a = !1;
        continue;
      }
      n = i.state > Rs && i.state < Is, i.state = Ln, i.timer.stop(), i.on.call(n ? "interrupt" : "cancel", e, e.__data__, i.index, i.group), delete r[o];
    }
    a && delete e.__transition;
  }
}
function Pb(e) {
  return this.each(function() {
    Ib(this, e);
  });
}
function Nb(e, t) {
  var r, i;
  return function() {
    var n = Se(this, e), a = n.tween;
    if (a !== r) {
      i = r = a;
      for (var o = 0, s = i.length; o < s; ++o)
        if (i[o].name === t) {
          i = i.slice(), i.splice(o, 1);
          break;
        }
    }
    n.tween = i;
  };
}
function zb(e, t, r) {
  var i, n;
  if (typeof r != "function") throw new Error();
  return function() {
    var a = Se(this, e), o = a.tween;
    if (o !== i) {
      n = (i = o).slice();
      for (var s = { name: t, value: r }, l = 0, c = n.length; l < c; ++l)
        if (n[l].name === t) {
          n[l] = s;
          break;
        }
      l === c && n.push(s);
    }
    a.tween = n;
  };
}
function Wb(e, t) {
  var r = this._id;
  if (e += "", arguments.length < 2) {
    for (var i = me(this.node(), r).tween, n = 0, a = i.length, o; n < a; ++n)
      if ((o = i[n]).name === e)
        return o.value;
    return null;
  }
  return this.each((t == null ? Nb : zb)(r, e, t));
}
function Io(e, t, r) {
  var i = e._id;
  return e.each(function() {
    var n = Se(this, i);
    (n.value || (n.value = {}))[t] = r.apply(this, arguments);
  }), function(n) {
    return me(n, i).value[t];
  };
}
function gu(e, t) {
  var r;
  return (typeof t == "number" ? qe : t instanceof Ii ? dc : (r = Ii(t)) ? (t = r, dc) : Sb)(e, t);
}
function qb(e) {
  return function() {
    this.removeAttribute(e);
  };
}
function Hb(e) {
  return function() {
    this.removeAttributeNS(e.space, e.local);
  };
}
function jb(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var o = this.getAttribute(e);
    return o === n ? null : o === i ? a : a = t(i = o, r);
  };
}
function Yb(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var o = this.getAttributeNS(e.space, e.local);
    return o === n ? null : o === i ? a : a = t(i = o, r);
  };
}
function Ub(e, t, r) {
  var i, n, a;
  return function() {
    var o, s = r(this), l;
    return s == null ? void this.removeAttribute(e) : (o = this.getAttribute(e), l = s + "", o === l ? null : o === i && l === n ? a : (n = l, a = t(i = o, s)));
  };
}
function Gb(e, t, r) {
  var i, n, a;
  return function() {
    var o, s = r(this), l;
    return s == null ? void this.removeAttributeNS(e.space, e.local) : (o = this.getAttributeNS(e.space, e.local), l = s + "", o === l ? null : o === i && l === n ? a : (n = l, a = t(i = o, s)));
  };
}
function Xb(e, t) {
  var r = va(e), i = r === "transform" ? Lb : gu;
  return this.attrTween(e, typeof t == "function" ? (r.local ? Gb : Ub)(r, i, Io(this, "attr." + e, t)) : t == null ? (r.local ? Hb : qb)(r) : (r.local ? Yb : jb)(r, i, t));
}
function Vb(e, t) {
  return function(r) {
    this.setAttribute(e, t.call(this, r));
  };
}
function Zb(e, t) {
  return function(r) {
    this.setAttributeNS(e.space, e.local, t.call(this, r));
  };
}
function Kb(e, t) {
  var r, i;
  function n() {
    var a = t.apply(this, arguments);
    return a !== i && (r = (i = a) && Zb(e, a)), r;
  }
  return n._value = t, n;
}
function Qb(e, t) {
  var r, i;
  function n() {
    var a = t.apply(this, arguments);
    return a !== i && (r = (i = a) && Vb(e, a)), r;
  }
  return n._value = t, n;
}
function Jb(e, t) {
  var r = "attr." + e;
  if (arguments.length < 2) return (r = this.tween(r)) && r._value;
  if (t == null) return this.tween(r, null);
  if (typeof t != "function") throw new Error();
  var i = va(e);
  return this.tween(r, (i.local ? Kb : Qb)(i, t));
}
function t1(e, t) {
  return function() {
    Ro(this, e).delay = +t.apply(this, arguments);
  };
}
function e1(e, t) {
  return t = +t, function() {
    Ro(this, e).delay = t;
  };
}
function r1(e) {
  var t = this._id;
  return arguments.length ? this.each((typeof e == "function" ? t1 : e1)(t, e)) : me(this.node(), t).delay;
}
function i1(e, t) {
  return function() {
    Se(this, e).duration = +t.apply(this, arguments);
  };
}
function n1(e, t) {
  return t = +t, function() {
    Se(this, e).duration = t;
  };
}
function a1(e) {
  var t = this._id;
  return arguments.length ? this.each((typeof e == "function" ? i1 : n1)(t, e)) : me(this.node(), t).duration;
}
function s1(e, t) {
  if (typeof t != "function") throw new Error();
  return function() {
    Se(this, e).ease = t;
  };
}
function o1(e) {
  var t = this._id;
  return arguments.length ? this.each(s1(t, e)) : me(this.node(), t).ease;
}
function l1(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    if (typeof r != "function") throw new Error();
    Se(this, e).ease = r;
  };
}
function c1(e) {
  if (typeof e != "function") throw new Error();
  return this.each(l1(this._id, e));
}
function h1(e) {
  typeof e != "function" && (e = Vh(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], o = a.length, s = i[n] = [], l, c = 0; c < o; ++c)
      (l = a[c]) && e.call(l, l.__data__, c, a) && s.push(l);
  return new Ie(i, this._parents, this._name, this._id);
}
function u1(e) {
  if (e._id !== this._id) throw new Error();
  for (var t = this._groups, r = e._groups, i = t.length, n = r.length, a = Math.min(i, n), o = new Array(i), s = 0; s < a; ++s)
    for (var l = t[s], c = r[s], h = l.length, u = o[s] = new Array(h), f, p = 0; p < h; ++p)
      (f = l[p] || c[p]) && (u[p] = f);
  for (; s < i; ++s)
    o[s] = t[s];
  return new Ie(o, this._parents, this._name, this._id);
}
function f1(e) {
  return (e + "").trim().split(/^|\s+/).every(function(t) {
    var r = t.indexOf(".");
    return r >= 0 && (t = t.slice(0, r)), !t || t === "start";
  });
}
function p1(e, t, r) {
  var i, n, a = f1(t) ? Ro : Se;
  return function() {
    var o = a(this, e), s = o.on;
    s !== i && (n = (i = s).copy()).on(t, r), o.on = n;
  };
}
function d1(e, t) {
  var r = this._id;
  return arguments.length < 2 ? me(this.node(), r).on.on(e) : this.each(p1(r, e, t));
}
function g1(e) {
  return function() {
    var t = this.parentNode;
    for (var r in this.__transition) if (+r !== e) return;
    t && t.removeChild(this);
  };
}
function m1() {
  return this.on("end.remove", g1(this._id));
}
function y1(e) {
  var t = this._name, r = this._id;
  typeof e != "function" && (e = $o(e));
  for (var i = this._groups, n = i.length, a = new Array(n), o = 0; o < n; ++o)
    for (var s = i[o], l = s.length, c = a[o] = new Array(l), h, u, f = 0; f < l; ++f)
      (h = s[f]) && (u = e.call(h, h.__data__, f, s)) && ("__data__" in h && (u.__data__ = h.__data__), c[f] = u, Ta(c[f], t, r, f, c, me(h, r)));
  return new Ie(a, this._parents, t, r);
}
function x1(e) {
  var t = this._name, r = this._id;
  typeof e != "function" && (e = Xh(e));
  for (var i = this._groups, n = i.length, a = [], o = [], s = 0; s < n; ++s)
    for (var l = i[s], c = l.length, h, u = 0; u < c; ++u)
      if (h = l[u]) {
        for (var f = e.call(h, h.__data__, u, l), p, g = me(h, r), m = 0, y = f.length; m < y; ++m)
          (p = f[m]) && Ta(p, t, r, m, f, g);
        a.push(f), o.push(h);
      }
  return new Ie(a, o, t, r);
}
var b1 = Zi.prototype.constructor;
function C1() {
  return new b1(this._groups, this._parents);
}
function _1(e, t) {
  var r, i, n;
  return function() {
    var a = Vr(this, e), o = (this.style.removeProperty(e), Vr(this, e));
    return a === o ? null : a === r && o === i ? n : n = t(r = a, i = o);
  };
}
function mu(e) {
  return function() {
    this.style.removeProperty(e);
  };
}
function w1(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var o = Vr(this, e);
    return o === n ? null : o === i ? a : a = t(i = o, r);
  };
}
function k1(e, t, r) {
  var i, n, a;
  return function() {
    var o = Vr(this, e), s = r(this), l = s + "";
    return s == null && (l = s = (this.style.removeProperty(e), Vr(this, e))), o === l ? null : o === i && l === n ? a : (n = l, a = t(i = o, s));
  };
}
function v1(e, t) {
  var r, i, n, a = "style." + t, o = "end." + a, s;
  return function() {
    var l = Se(this, e), c = l.on, h = l.value[a] == null ? s || (s = mu(t)) : void 0;
    (c !== r || n !== h) && (i = (r = c).copy()).on(o, n = h), l.on = i;
  };
}
function S1(e, t, r) {
  var i = (e += "") == "transform" ? Ab : gu;
  return t == null ? this.styleTween(e, _1(e, i)).on("end.style." + e, mu(e)) : typeof t == "function" ? this.styleTween(e, k1(e, i, Io(this, "style." + e, t))).each(v1(this._id, e)) : this.styleTween(e, w1(e, i, t), r).on("end.style." + e, null);
}
function T1(e, t, r) {
  return function(i) {
    this.style.setProperty(e, t.call(this, i), r);
  };
}
function B1(e, t, r) {
  var i, n;
  function a() {
    var o = t.apply(this, arguments);
    return o !== n && (i = (n = o) && T1(e, o, r)), i;
  }
  return a._value = t, a;
}
function A1(e, t, r) {
  var i = "style." + (e += "");
  if (arguments.length < 2) return (i = this.tween(i)) && i._value;
  if (t == null) return this.tween(i, null);
  if (typeof t != "function") throw new Error();
  return this.tween(i, B1(e, t, r ?? ""));
}
function L1(e) {
  return function() {
    this.textContent = e;
  };
}
function M1(e) {
  return function() {
    var t = e(this);
    this.textContent = t ?? "";
  };
}
function $1(e) {
  return this.tween("text", typeof e == "function" ? M1(Io(this, "text", e)) : L1(e == null ? "" : e + ""));
}
function E1(e) {
  return function(t) {
    this.textContent = e.call(this, t);
  };
}
function F1(e) {
  var t, r;
  function i() {
    var n = e.apply(this, arguments);
    return n !== r && (t = (r = n) && E1(n)), t;
  }
  return i._value = e, i;
}
function D1(e) {
  var t = "text";
  if (arguments.length < 1) return (t = this.tween(t)) && t._value;
  if (e == null) return this.tween(t, null);
  if (typeof e != "function") throw new Error();
  return this.tween(t, F1(e));
}
function O1() {
  for (var e = this._name, t = this._id, r = yu(), i = this._groups, n = i.length, a = 0; a < n; ++a)
    for (var o = i[a], s = o.length, l, c = 0; c < s; ++c)
      if (l = o[c]) {
        var h = me(l, t);
        Ta(l, e, r, c, o, {
          time: h.time + h.delay + h.duration,
          delay: 0,
          duration: h.duration,
          ease: h.ease
        });
      }
  return new Ie(i, this._parents, e, r);
}
function R1() {
  var e, t, r = this, i = r._id, n = r.size();
  return new Promise(function(a, o) {
    var s = { value: o }, l = { value: function() {
      --n === 0 && a();
    } };
    r.each(function() {
      var c = Se(this, i), h = c.on;
      h !== e && (t = (e = h).copy(), t._.cancel.push(s), t._.interrupt.push(s), t._.end.push(l)), c.on = t;
    }), n === 0 && a();
  });
}
var I1 = 0;
function Ie(e, t, r, i) {
  this._groups = e, this._parents = t, this._name = r, this._id = i;
}
function yu() {
  return ++I1;
}
var $e = Zi.prototype;
Ie.prototype = {
  constructor: Ie,
  select: y1,
  selectAll: x1,
  selectChild: $e.selectChild,
  selectChildren: $e.selectChildren,
  filter: h1,
  merge: u1,
  selection: C1,
  transition: O1,
  call: $e.call,
  nodes: $e.nodes,
  node: $e.node,
  size: $e.size,
  empty: $e.empty,
  each: $e.each,
  on: d1,
  attr: Xb,
  attrTween: Jb,
  style: S1,
  styleTween: A1,
  text: $1,
  textTween: D1,
  remove: m1,
  tween: Wb,
  delay: r1,
  duration: a1,
  ease: o1,
  easeVarying: c1,
  end: R1,
  [Symbol.iterator]: $e[Symbol.iterator]
};
function P1(e) {
  return ((e *= 2) <= 1 ? e * e * e : (e -= 2) * e * e + 2) / 2;
}
var N1 = {
  time: null,
  // Set on use.
  delay: 0,
  duration: 250,
  ease: P1
};
function z1(e, t) {
  for (var r; !(r = e.__transition) || !(r = r[t]); )
    if (!(e = e.parentNode))
      throw new Error(`transition ${t} not found`);
  return r;
}
function W1(e) {
  var t, r;
  e instanceof Ie ? (t = e._id, e = e._name) : (t = yu(), (r = N1).time = Oo(), e = e == null ? null : e + "");
  for (var i = this._groups, n = i.length, a = 0; a < n; ++a)
    for (var o = i[a], s = o.length, l, c = 0; c < s; ++c)
      (l = o[c]) && Ta(l, e, t, c, o, r || z1(l, t));
  return new Ie(i, this._parents, e, t);
}
Zi.prototype.interrupt = Pb;
Zi.prototype.transition = W1;
const Ps = Math.PI, Ns = 2 * Ps, rr = 1e-6, q1 = Ns - rr;
function xu(e) {
  this._ += e[0];
  for (let t = 1, r = e.length; t < r; ++t)
    this._ += arguments[t] + e[t];
}
function H1(e) {
  let t = Math.floor(e);
  if (!(t >= 0)) throw new Error(`invalid digits: ${e}`);
  if (t > 15) return xu;
  const r = 10 ** t;
  return function(i) {
    this._ += i[0];
    for (let n = 1, a = i.length; n < a; ++n)
      this._ += Math.round(arguments[n] * r) / r + i[n];
  };
}
class j1 {
  constructor(t) {
    this._x0 = this._y0 = // start of current subpath
    this._x1 = this._y1 = null, this._ = "", this._append = t == null ? xu : H1(t);
  }
  moveTo(t, r) {
    this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +r}`;
  }
  closePath() {
    this._x1 !== null && (this._x1 = this._x0, this._y1 = this._y0, this._append`Z`);
  }
  lineTo(t, r) {
    this._append`L${this._x1 = +t},${this._y1 = +r}`;
  }
  quadraticCurveTo(t, r, i, n) {
    this._append`Q${+t},${+r},${this._x1 = +i},${this._y1 = +n}`;
  }
  bezierCurveTo(t, r, i, n, a, o) {
    this._append`C${+t},${+r},${+i},${+n},${this._x1 = +a},${this._y1 = +o}`;
  }
  arcTo(t, r, i, n, a) {
    if (t = +t, r = +r, i = +i, n = +n, a = +a, a < 0) throw new Error(`negative radius: ${a}`);
    let o = this._x1, s = this._y1, l = i - t, c = n - r, h = o - t, u = s - r, f = h * h + u * u;
    if (this._x1 === null)
      this._append`M${this._x1 = t},${this._y1 = r}`;
    else if (f > rr) if (!(Math.abs(u * l - c * h) > rr) || !a)
      this._append`L${this._x1 = t},${this._y1 = r}`;
    else {
      let p = i - o, g = n - s, m = l * l + c * c, y = p * p + g * g, x = Math.sqrt(m), b = Math.sqrt(f), _ = a * Math.tan((Ps - Math.acos((m + f - y) / (2 * x * b))) / 2), v = _ / b, w = _ / x;
      Math.abs(v - 1) > rr && this._append`L${t + v * h},${r + v * u}`, this._append`A${a},${a},0,0,${+(u * p > h * g)},${this._x1 = t + w * l},${this._y1 = r + w * c}`;
    }
  }
  arc(t, r, i, n, a, o) {
    if (t = +t, r = +r, i = +i, o = !!o, i < 0) throw new Error(`negative radius: ${i}`);
    let s = i * Math.cos(n), l = i * Math.sin(n), c = t + s, h = r + l, u = 1 ^ o, f = o ? n - a : a - n;
    this._x1 === null ? this._append`M${c},${h}` : (Math.abs(this._x1 - c) > rr || Math.abs(this._y1 - h) > rr) && this._append`L${c},${h}`, i && (f < 0 && (f = f % Ns + Ns), f > q1 ? this._append`A${i},${i},0,1,${u},${t - s},${r - l}A${i},${i},0,1,${u},${this._x1 = c},${this._y1 = h}` : f > rr && this._append`A${i},${i},0,${+(f >= Ps)},${u},${this._x1 = t + i * Math.cos(a)},${this._y1 = r + i * Math.sin(a)}`);
  }
  rect(t, r, i, n) {
    this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +r}h${i = +i}v${+n}h${-i}Z`;
  }
  toString() {
    return this._;
  }
}
function Mr(e) {
  return function() {
    return e;
  };
}
const eL = Math.abs, rL = Math.atan2, iL = Math.cos, nL = Math.max, aL = Math.min, sL = Math.sin, oL = Math.sqrt, Cc = 1e-12, Po = Math.PI, _c = Po / 2, lL = 2 * Po;
function cL(e) {
  return e > 1 ? 0 : e < -1 ? Po : Math.acos(e);
}
function hL(e) {
  return e >= 1 ? _c : e <= -1 ? -_c : Math.asin(e);
}
function Y1(e) {
  let t = 3;
  return e.digits = function(r) {
    if (!arguments.length) return t;
    if (r == null)
      t = null;
    else {
      const i = Math.floor(r);
      if (!(i >= 0)) throw new RangeError(`invalid digits: ${r}`);
      t = i;
    }
    return e;
  }, () => new j1(t);
}
function U1(e) {
  return typeof e == "object" && "length" in e ? e : Array.from(e);
}
function bu(e) {
  this._context = e;
}
bu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
      default:
        this._context.lineTo(e, t);
        break;
    }
  }
};
function Vn(e) {
  return new bu(e);
}
function G1(e) {
  return e[0];
}
function X1(e) {
  return e[1];
}
function V1(e, t) {
  var r = Mr(!0), i = null, n = Vn, a = null, o = Y1(s);
  e = typeof e == "function" ? e : e === void 0 ? G1 : Mr(e), t = typeof t == "function" ? t : t === void 0 ? X1 : Mr(t);
  function s(l) {
    var c, h = (l = U1(l)).length, u, f = !1, p;
    for (i == null && (a = n(p = o())), c = 0; c <= h; ++c)
      !(c < h && r(u = l[c], c, l)) === f && ((f = !f) ? a.lineStart() : a.lineEnd()), f && a.point(+e(u, c, l), +t(u, c, l));
    if (p) return a = null, p + "" || null;
  }
  return s.x = function(l) {
    return arguments.length ? (e = typeof l == "function" ? l : Mr(+l), s) : e;
  }, s.y = function(l) {
    return arguments.length ? (t = typeof l == "function" ? l : Mr(+l), s) : t;
  }, s.defined = function(l) {
    return arguments.length ? (r = typeof l == "function" ? l : Mr(!!l), s) : r;
  }, s.curve = function(l) {
    return arguments.length ? (n = l, i != null && (a = n(i)), s) : n;
  }, s.context = function(l) {
    return arguments.length ? (l == null ? i = a = null : a = n(i = l), s) : i;
  }, s;
}
class Cu {
  constructor(t, r) {
    this._context = t, this._x = r;
  }
  areaStart() {
    this._line = 0;
  }
  areaEnd() {
    this._line = NaN;
  }
  lineStart() {
    this._point = 0;
  }
  lineEnd() {
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  }
  point(t, r) {
    switch (t = +t, r = +r, this._point) {
      case 0: {
        this._point = 1, this._line ? this._context.lineTo(t, r) : this._context.moveTo(t, r);
        break;
      }
      case 1:
        this._point = 2;
      default: {
        this._x ? this._context.bezierCurveTo(this._x0 = (this._x0 + t) / 2, this._y0, this._x0, r, t, r) : this._context.bezierCurveTo(this._x0, this._y0 = (this._y0 + r) / 2, t, this._y0, t, r);
        break;
      }
    }
    this._x0 = t, this._y0 = r;
  }
}
function _u(e) {
  return new Cu(e, !0);
}
function wu(e) {
  return new Cu(e, !1);
}
function Ye() {
}
function Zn(e, t, r) {
  e._context.bezierCurveTo(
    (2 * e._x0 + e._x1) / 3,
    (2 * e._y0 + e._y1) / 3,
    (e._x0 + 2 * e._x1) / 3,
    (e._y0 + 2 * e._y1) / 3,
    (e._x0 + 4 * e._x1 + t) / 6,
    (e._y0 + 4 * e._y1 + r) / 6
  );
}
function Ba(e) {
  this._context = e;
}
Ba.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 3:
        Zn(this, this._x1, this._y1);
      case 2:
        this._context.lineTo(this._x1, this._y1);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._context.lineTo((5 * this._x0 + this._x1) / 6, (5 * this._y0 + this._y1) / 6);
      default:
        Zn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function Mn(e) {
  return new Ba(e);
}
function ku(e) {
  this._context = e;
}
ku.prototype = {
  areaStart: Ye,
  areaEnd: Ye,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x2, this._y2), this._context.closePath();
        break;
      }
      case 2: {
        this._context.moveTo((this._x2 + 2 * this._x3) / 3, (this._y2 + 2 * this._y3) / 3), this._context.lineTo((this._x3 + 2 * this._x2) / 3, (this._y3 + 2 * this._y2) / 3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x2, this._y2), this.point(this._x3, this._y3), this.point(this._x4, this._y4);
        break;
      }
    }
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._x2 = e, this._y2 = t;
        break;
      case 1:
        this._point = 2, this._x3 = e, this._y3 = t;
        break;
      case 2:
        this._point = 3, this._x4 = e, this._y4 = t, this._context.moveTo((this._x0 + 4 * this._x1 + e) / 6, (this._y0 + 4 * this._y1 + t) / 6);
        break;
      default:
        Zn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function Z1(e) {
  return new ku(e);
}
function vu(e) {
  this._context = e;
}
vu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3;
        var r = (this._x0 + 4 * this._x1 + e) / 6, i = (this._y0 + 4 * this._y1 + t) / 6;
        this._line ? this._context.lineTo(r, i) : this._context.moveTo(r, i);
        break;
      case 3:
        this._point = 4;
      default:
        Zn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function K1(e) {
  return new vu(e);
}
function Su(e, t) {
  this._basis = new Ba(e), this._beta = t;
}
Su.prototype = {
  lineStart: function() {
    this._x = [], this._y = [], this._basis.lineStart();
  },
  lineEnd: function() {
    var e = this._x, t = this._y, r = e.length - 1;
    if (r > 0)
      for (var i = e[0], n = t[0], a = e[r] - i, o = t[r] - n, s = -1, l; ++s <= r; )
        l = s / r, this._basis.point(
          this._beta * e[s] + (1 - this._beta) * (i + l * a),
          this._beta * t[s] + (1 - this._beta) * (n + l * o)
        );
    this._x = this._y = null, this._basis.lineEnd();
  },
  point: function(e, t) {
    this._x.push(+e), this._y.push(+t);
  }
};
const Q1 = function e(t) {
  function r(i) {
    return t === 1 ? new Ba(i) : new Su(i, t);
  }
  return r.beta = function(i) {
    return e(+i);
  }, r;
}(0.85);
function Kn(e, t, r) {
  e._context.bezierCurveTo(
    e._x1 + e._k * (e._x2 - e._x0),
    e._y1 + e._k * (e._y2 - e._y0),
    e._x2 + e._k * (e._x1 - t),
    e._y2 + e._k * (e._y1 - r),
    e._x2,
    e._y2
  );
}
function No(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
No.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x2, this._y2);
        break;
      case 3:
        Kn(this, this._x1, this._y1);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2, this._x1 = e, this._y1 = t;
        break;
      case 2:
        this._point = 3;
      default:
        Kn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const Tu = function e(t) {
  function r(i) {
    return new No(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
}(0);
function zo(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
zo.prototype = {
  areaStart: Ye,
  areaEnd: Ye,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 2: {
        this._context.lineTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5);
        break;
      }
    }
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._x3 = e, this._y3 = t;
        break;
      case 1:
        this._point = 2, this._context.moveTo(this._x4 = e, this._y4 = t);
        break;
      case 2:
        this._point = 3, this._x5 = e, this._y5 = t;
        break;
      default:
        Kn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const J1 = function e(t) {
  function r(i) {
    return new zo(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
}(0);
function Wo(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
Wo.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
        break;
      case 3:
        this._point = 4;
      default:
        Kn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const t2 = function e(t) {
  function r(i) {
    return new Wo(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
}(0);
function qo(e, t, r) {
  var i = e._x1, n = e._y1, a = e._x2, o = e._y2;
  if (e._l01_a > Cc) {
    var s = 2 * e._l01_2a + 3 * e._l01_a * e._l12_a + e._l12_2a, l = 3 * e._l01_a * (e._l01_a + e._l12_a);
    i = (i * s - e._x0 * e._l12_2a + e._x2 * e._l01_2a) / l, n = (n * s - e._y0 * e._l12_2a + e._y2 * e._l01_2a) / l;
  }
  if (e._l23_a > Cc) {
    var c = 2 * e._l23_2a + 3 * e._l23_a * e._l12_a + e._l12_2a, h = 3 * e._l23_a * (e._l23_a + e._l12_a);
    a = (a * c + e._x1 * e._l23_2a - t * e._l12_2a) / h, o = (o * c + e._y1 * e._l23_2a - r * e._l12_2a) / h;
  }
  e._context.bezierCurveTo(i, n, a, o, e._x2, e._y2);
}
function Bu(e, t) {
  this._context = e, this._alpha = t;
}
Bu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x2, this._y2);
        break;
      case 3:
        this.point(this._x2, this._y2);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3;
      default:
        qo(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const Au = function e(t) {
  function r(i) {
    return t ? new Bu(i, t) : new No(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
}(0.5);
function Lu(e, t) {
  this._context = e, this._alpha = t;
}
Lu.prototype = {
  areaStart: Ye,
  areaEnd: Ye,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 2: {
        this._context.lineTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5);
        break;
      }
    }
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1, this._x3 = e, this._y3 = t;
        break;
      case 1:
        this._point = 2, this._context.moveTo(this._x4 = e, this._y4 = t);
        break;
      case 2:
        this._point = 3, this._x5 = e, this._y5 = t;
        break;
      default:
        qo(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const e2 = function e(t) {
  function r(i) {
    return t ? new Lu(i, t) : new zo(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
}(0.5);
function Mu(e, t) {
  this._context = e, this._alpha = t;
}
Mu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
        break;
      case 3:
        this._point = 4;
      default:
        qo(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const r2 = function e(t) {
  function r(i) {
    return t ? new Mu(i, t) : new Wo(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
}(0.5);
function $u(e) {
  this._context = e;
}
$u.prototype = {
  areaStart: Ye,
  areaEnd: Ye,
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    this._point && this._context.closePath();
  },
  point: function(e, t) {
    e = +e, t = +t, this._point ? this._context.lineTo(e, t) : (this._point = 1, this._context.moveTo(e, t));
  }
};
function i2(e) {
  return new $u(e);
}
function wc(e) {
  return e < 0 ? -1 : 1;
}
function kc(e, t, r) {
  var i = e._x1 - e._x0, n = t - e._x1, a = (e._y1 - e._y0) / (i || n < 0 && -0), o = (r - e._y1) / (n || i < 0 && -0), s = (a * n + o * i) / (i + n);
  return (wc(a) + wc(o)) * Math.min(Math.abs(a), Math.abs(o), 0.5 * Math.abs(s)) || 0;
}
function vc(e, t) {
  var r = e._x1 - e._x0;
  return r ? (3 * (e._y1 - e._y0) / r - t) / 2 : t;
}
function hs(e, t, r) {
  var i = e._x0, n = e._y0, a = e._x1, o = e._y1, s = (a - i) / 3;
  e._context.bezierCurveTo(i + s, n + s * t, a - s, o - s * r, a, o);
}
function Qn(e) {
  this._context = e;
}
Qn.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = this._t0 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x1, this._y1);
        break;
      case 3:
        hs(this, this._t0, vc(this, this._t0));
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    var r = NaN;
    if (e = +e, t = +t, !(e === this._x1 && t === this._y1)) {
      switch (this._point) {
        case 0:
          this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
          break;
        case 1:
          this._point = 2;
          break;
        case 2:
          this._point = 3, hs(this, vc(this, r = kc(this, e, t)), r);
          break;
        default:
          hs(this, this._t0, r = kc(this, e, t));
          break;
      }
      this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t, this._t0 = r;
    }
  }
};
function Eu(e) {
  this._context = new Fu(e);
}
(Eu.prototype = Object.create(Qn.prototype)).point = function(e, t) {
  Qn.prototype.point.call(this, t, e);
};
function Fu(e) {
  this._context = e;
}
Fu.prototype = {
  moveTo: function(e, t) {
    this._context.moveTo(t, e);
  },
  closePath: function() {
    this._context.closePath();
  },
  lineTo: function(e, t) {
    this._context.lineTo(t, e);
  },
  bezierCurveTo: function(e, t, r, i, n, a) {
    this._context.bezierCurveTo(t, e, i, r, a, n);
  }
};
function Du(e) {
  return new Qn(e);
}
function Ou(e) {
  return new Eu(e);
}
function Ru(e) {
  this._context = e;
}
Ru.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x = [], this._y = [];
  },
  lineEnd: function() {
    var e = this._x, t = this._y, r = e.length;
    if (r)
      if (this._line ? this._context.lineTo(e[0], t[0]) : this._context.moveTo(e[0], t[0]), r === 2)
        this._context.lineTo(e[1], t[1]);
      else
        for (var i = Sc(e), n = Sc(t), a = 0, o = 1; o < r; ++a, ++o)
          this._context.bezierCurveTo(i[0][a], n[0][a], i[1][a], n[1][a], e[o], t[o]);
    (this._line || this._line !== 0 && r === 1) && this._context.closePath(), this._line = 1 - this._line, this._x = this._y = null;
  },
  point: function(e, t) {
    this._x.push(+e), this._y.push(+t);
  }
};
function Sc(e) {
  var t, r = e.length - 1, i, n = new Array(r), a = new Array(r), o = new Array(r);
  for (n[0] = 0, a[0] = 2, o[0] = e[0] + 2 * e[1], t = 1; t < r - 1; ++t) n[t] = 1, a[t] = 4, o[t] = 4 * e[t] + 2 * e[t + 1];
  for (n[r - 1] = 2, a[r - 1] = 7, o[r - 1] = 8 * e[r - 1] + e[r], t = 1; t < r; ++t) i = n[t] / a[t - 1], a[t] -= i, o[t] -= i * o[t - 1];
  for (n[r - 1] = o[r - 1] / a[r - 1], t = r - 2; t >= 0; --t) n[t] = (o[t] - n[t + 1]) / a[t];
  for (a[r - 1] = (e[r] + n[r - 1]) / 2, t = 0; t < r - 1; ++t) a[t] = 2 * e[t + 1] - n[t + 1];
  return [n, a];
}
function Iu(e) {
  return new Ru(e);
}
function Aa(e, t) {
  this._context = e, this._t = t;
}
Aa.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x = this._y = NaN, this._point = 0;
  },
  lineEnd: function() {
    0 < this._t && this._t < 1 && this._point === 2 && this._context.lineTo(this._x, this._y), (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line >= 0 && (this._t = 1 - this._t, this._line = 1 - this._line);
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
      default: {
        if (this._t <= 0)
          this._context.lineTo(this._x, t), this._context.lineTo(e, t);
        else {
          var r = this._x * (1 - this._t) + e * this._t;
          this._context.lineTo(r, this._y), this._context.lineTo(r, t);
        }
        break;
      }
    }
    this._x = e, this._y = t;
  }
};
function Pu(e) {
  return new Aa(e, 0.5);
}
function Nu(e) {
  return new Aa(e, 0);
}
function zu(e) {
  return new Aa(e, 1);
}
function ki(e, t, r) {
  this.k = e, this.x = t, this.y = r;
}
ki.prototype = {
  constructor: ki,
  scale: function(e) {
    return e === 1 ? this : new ki(this.k * e, this.x, this.y);
  },
  translate: function(e, t) {
    return e === 0 & t === 0 ? this : new ki(this.k, this.x + this.k * e, this.y + this.k * t);
  },
  apply: function(e) {
    return [e[0] * this.k + this.x, e[1] * this.k + this.y];
  },
  applyX: function(e) {
    return e * this.k + this.x;
  },
  applyY: function(e) {
    return e * this.k + this.y;
  },
  invert: function(e) {
    return [(e[0] - this.x) / this.k, (e[1] - this.y) / this.k];
  },
  invertX: function(e) {
    return (e - this.x) / this.k;
  },
  invertY: function(e) {
    return (e - this.y) / this.k;
  },
  rescaleX: function(e) {
    return e.copy().domain(e.range().map(this.invertX, this).map(e.invert, e));
  },
  rescaleY: function(e) {
    return e.copy().domain(e.range().map(this.invertY, this).map(e.invert, e));
  },
  toString: function() {
    return "translate(" + this.x + "," + this.y + ") scale(" + this.k + ")";
  }
};
ki.prototype;
var n2 = /* @__PURE__ */ d((e) => {
  var n;
  const { securityLevel: t } = pt();
  let r = ht("body");
  if (t === "sandbox") {
    const o = ((n = ht(`#i${e}`).node()) == null ? void 0 : n.contentDocument) ?? document;
    r = ht(o.body);
  }
  return r.select(`#${e}`);
}, "selectSvgElement");
function Ho(e) {
  return typeof e > "u" || e === null;
}
d(Ho, "isNothing");
function Wu(e) {
  return typeof e == "object" && e !== null;
}
d(Wu, "isObject");
function qu(e) {
  return Array.isArray(e) ? e : Ho(e) ? [] : [e];
}
d(qu, "toArray");
function Hu(e, t) {
  var r, i, n, a;
  if (t)
    for (a = Object.keys(t), r = 0, i = a.length; r < i; r += 1)
      n = a[r], e[n] = t[n];
  return e;
}
d(Hu, "extend");
function ju(e, t) {
  var r = "", i;
  for (i = 0; i < t; i += 1)
    r += e;
  return r;
}
d(ju, "repeat");
function Yu(e) {
  return e === 0 && Number.NEGATIVE_INFINITY === 1 / e;
}
d(Yu, "isNegativeZero");
var a2 = Ho, s2 = Wu, o2 = qu, l2 = ju, c2 = Yu, h2 = Hu, At = {
  isNothing: a2,
  isObject: s2,
  toArray: o2,
  repeat: l2,
  isNegativeZero: c2,
  extend: h2
};
function jo(e, t) {
  var r = "", i = e.reason || "(unknown reason)";
  return e.mark ? (e.mark.name && (r += 'in "' + e.mark.name + '" '), r += "(" + (e.mark.line + 1) + ":" + (e.mark.column + 1) + ")", !t && e.mark.snippet && (r += `

` + e.mark.snippet), i + " " + r) : i;
}
d(jo, "formatError");
function Kr(e, t) {
  Error.call(this), this.name = "YAMLException", this.reason = e, this.mark = t, this.message = jo(this, !1), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = new Error().stack || "";
}
d(Kr, "YAMLException$1");
Kr.prototype = Object.create(Error.prototype);
Kr.prototype.constructor = Kr;
Kr.prototype.toString = /* @__PURE__ */ d(function(t) {
  return this.name + ": " + jo(this, t);
}, "toString");
var Qt = Kr;
function $n(e, t, r, i, n) {
  var a = "", o = "", s = Math.floor(n / 2) - 1;
  return i - t > s && (a = " ... ", t = i - s + a.length), r - i > s && (o = " ...", r = i + s - o.length), {
    str: a + e.slice(t, r).replace(/\t/g, "→") + o,
    pos: i - t + a.length
    // relative position
  };
}
d($n, "getLine");
function En(e, t) {
  return At.repeat(" ", t - e.length) + e;
}
d(En, "padStart");
function Uu(e, t) {
  if (t = Object.create(t || null), !e.buffer) return null;
  t.maxLength || (t.maxLength = 79), typeof t.indent != "number" && (t.indent = 1), typeof t.linesBefore != "number" && (t.linesBefore = 3), typeof t.linesAfter != "number" && (t.linesAfter = 2);
  for (var r = /\r?\n|\r|\0/g, i = [0], n = [], a, o = -1; a = r.exec(e.buffer); )
    n.push(a.index), i.push(a.index + a[0].length), e.position <= a.index && o < 0 && (o = i.length - 2);
  o < 0 && (o = i.length - 1);
  var s = "", l, c, h = Math.min(e.line + t.linesAfter, n.length).toString().length, u = t.maxLength - (t.indent + h + 3);
  for (l = 1; l <= t.linesBefore && !(o - l < 0); l++)
    c = $n(
      e.buffer,
      i[o - l],
      n[o - l],
      e.position - (i[o] - i[o - l]),
      u
    ), s = At.repeat(" ", t.indent) + En((e.line - l + 1).toString(), h) + " | " + c.str + `
` + s;
  for (c = $n(e.buffer, i[o], n[o], e.position, u), s += At.repeat(" ", t.indent) + En((e.line + 1).toString(), h) + " | " + c.str + `
`, s += At.repeat("-", t.indent + h + 3 + c.pos) + `^
`, l = 1; l <= t.linesAfter && !(o + l >= n.length); l++)
    c = $n(
      e.buffer,
      i[o + l],
      n[o + l],
      e.position - (i[o] - i[o + l]),
      u
    ), s += At.repeat(" ", t.indent) + En((e.line + l + 1).toString(), h) + " | " + c.str + `
`;
  return s.replace(/\n$/, "");
}
d(Uu, "makeSnippet");
var u2 = Uu, f2 = [
  "kind",
  "multi",
  "resolve",
  "construct",
  "instanceOf",
  "predicate",
  "represent",
  "representName",
  "defaultStyle",
  "styleAliases"
], p2 = [
  "scalar",
  "sequence",
  "mapping"
];
function Gu(e) {
  var t = {};
  return e !== null && Object.keys(e).forEach(function(r) {
    e[r].forEach(function(i) {
      t[String(i)] = r;
    });
  }), t;
}
d(Gu, "compileStyleAliases");
function Xu(e, t) {
  if (t = t || {}, Object.keys(t).forEach(function(r) {
    if (f2.indexOf(r) === -1)
      throw new Qt('Unknown option "' + r + '" is met in definition of "' + e + '" YAML type.');
  }), this.options = t, this.tag = e, this.kind = t.kind || null, this.resolve = t.resolve || function() {
    return !0;
  }, this.construct = t.construct || function(r) {
    return r;
  }, this.instanceOf = t.instanceOf || null, this.predicate = t.predicate || null, this.represent = t.represent || null, this.representName = t.representName || null, this.defaultStyle = t.defaultStyle || null, this.multi = t.multi || !1, this.styleAliases = Gu(t.styleAliases || null), p2.indexOf(this.kind) === -1)
    throw new Qt('Unknown kind "' + this.kind + '" is specified for "' + e + '" YAML type.');
}
d(Xu, "Type$1");
var zt = Xu;
function zs(e, t) {
  var r = [];
  return e[t].forEach(function(i) {
    var n = r.length;
    r.forEach(function(a, o) {
      a.tag === i.tag && a.kind === i.kind && a.multi === i.multi && (n = o);
    }), r[n] = i;
  }), r;
}
d(zs, "compileList");
function Vu() {
  var e = {
    scalar: {},
    sequence: {},
    mapping: {},
    fallback: {},
    multi: {
      scalar: [],
      sequence: [],
      mapping: [],
      fallback: []
    }
  }, t, r;
  function i(n) {
    n.multi ? (e.multi[n.kind].push(n), e.multi.fallback.push(n)) : e[n.kind][n.tag] = e.fallback[n.tag] = n;
  }
  for (d(i, "collectType"), t = 0, r = arguments.length; t < r; t += 1)
    arguments[t].forEach(i);
  return e;
}
d(Vu, "compileMap");
function Jn(e) {
  return this.extend(e);
}
d(Jn, "Schema$1");
Jn.prototype.extend = /* @__PURE__ */ d(function(t) {
  var r = [], i = [];
  if (t instanceof zt)
    i.push(t);
  else if (Array.isArray(t))
    i = i.concat(t);
  else if (t && (Array.isArray(t.implicit) || Array.isArray(t.explicit)))
    t.implicit && (r = r.concat(t.implicit)), t.explicit && (i = i.concat(t.explicit));
  else
    throw new Qt("Schema.extend argument should be a Type, [ Type ], or a schema definition ({ implicit: [...], explicit: [...] })");
  r.forEach(function(a) {
    if (!(a instanceof zt))
      throw new Qt("Specified list of YAML types (or a single Type object) contains a non-Type object.");
    if (a.loadKind && a.loadKind !== "scalar")
      throw new Qt("There is a non-scalar type in the implicit list of a schema. Implicit resolving of such types is not supported.");
    if (a.multi)
      throw new Qt("There is a multi type in the implicit list of a schema. Multi tags can only be listed as explicit.");
  }), i.forEach(function(a) {
    if (!(a instanceof zt))
      throw new Qt("Specified list of YAML types (or a single Type object) contains a non-Type object.");
  });
  var n = Object.create(Jn.prototype);
  return n.implicit = (this.implicit || []).concat(r), n.explicit = (this.explicit || []).concat(i), n.compiledImplicit = zs(n, "implicit"), n.compiledExplicit = zs(n, "explicit"), n.compiledTypeMap = Vu(n.compiledImplicit, n.compiledExplicit), n;
}, "extend");
var d2 = Jn, g2 = new zt("tag:yaml.org,2002:str", {
  kind: "scalar",
  construct: /* @__PURE__ */ d(function(e) {
    return e !== null ? e : "";
  }, "construct")
}), m2 = new zt("tag:yaml.org,2002:seq", {
  kind: "sequence",
  construct: /* @__PURE__ */ d(function(e) {
    return e !== null ? e : [];
  }, "construct")
}), y2 = new zt("tag:yaml.org,2002:map", {
  kind: "mapping",
  construct: /* @__PURE__ */ d(function(e) {
    return e !== null ? e : {};
  }, "construct")
}), x2 = new d2({
  explicit: [
    g2,
    m2,
    y2
  ]
});
function Zu(e) {
  if (e === null) return !0;
  var t = e.length;
  return t === 1 && e === "~" || t === 4 && (e === "null" || e === "Null" || e === "NULL");
}
d(Zu, "resolveYamlNull");
function Ku() {
  return null;
}
d(Ku, "constructYamlNull");
function Qu(e) {
  return e === null;
}
d(Qu, "isNull");
var b2 = new zt("tag:yaml.org,2002:null", {
  kind: "scalar",
  resolve: Zu,
  construct: Ku,
  predicate: Qu,
  represent: {
    canonical: /* @__PURE__ */ d(function() {
      return "~";
    }, "canonical"),
    lowercase: /* @__PURE__ */ d(function() {
      return "null";
    }, "lowercase"),
    uppercase: /* @__PURE__ */ d(function() {
      return "NULL";
    }, "uppercase"),
    camelcase: /* @__PURE__ */ d(function() {
      return "Null";
    }, "camelcase"),
    empty: /* @__PURE__ */ d(function() {
      return "";
    }, "empty")
  },
  defaultStyle: "lowercase"
});
function Ju(e) {
  if (e === null) return !1;
  var t = e.length;
  return t === 4 && (e === "true" || e === "True" || e === "TRUE") || t === 5 && (e === "false" || e === "False" || e === "FALSE");
}
d(Ju, "resolveYamlBoolean");
function tf(e) {
  return e === "true" || e === "True" || e === "TRUE";
}
d(tf, "constructYamlBoolean");
function ef(e) {
  return Object.prototype.toString.call(e) === "[object Boolean]";
}
d(ef, "isBoolean");
var C2 = new zt("tag:yaml.org,2002:bool", {
  kind: "scalar",
  resolve: Ju,
  construct: tf,
  predicate: ef,
  represent: {
    lowercase: /* @__PURE__ */ d(function(e) {
      return e ? "true" : "false";
    }, "lowercase"),
    uppercase: /* @__PURE__ */ d(function(e) {
      return e ? "TRUE" : "FALSE";
    }, "uppercase"),
    camelcase: /* @__PURE__ */ d(function(e) {
      return e ? "True" : "False";
    }, "camelcase")
  },
  defaultStyle: "lowercase"
});
function rf(e) {
  return 48 <= e && e <= 57 || 65 <= e && e <= 70 || 97 <= e && e <= 102;
}
d(rf, "isHexCode");
function nf(e) {
  return 48 <= e && e <= 55;
}
d(nf, "isOctCode");
function af(e) {
  return 48 <= e && e <= 57;
}
d(af, "isDecCode");
function sf(e) {
  if (e === null) return !1;
  var t = e.length, r = 0, i = !1, n;
  if (!t) return !1;
  if (n = e[r], (n === "-" || n === "+") && (n = e[++r]), n === "0") {
    if (r + 1 === t) return !0;
    if (n = e[++r], n === "b") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (n !== "0" && n !== "1") return !1;
          i = !0;
        }
      return i && n !== "_";
    }
    if (n === "x") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (!rf(e.charCodeAt(r))) return !1;
          i = !0;
        }
      return i && n !== "_";
    }
    if (n === "o") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (!nf(e.charCodeAt(r))) return !1;
          i = !0;
        }
      return i && n !== "_";
    }
  }
  if (n === "_") return !1;
  for (; r < t; r++)
    if (n = e[r], n !== "_") {
      if (!af(e.charCodeAt(r)))
        return !1;
      i = !0;
    }
  return !(!i || n === "_");
}
d(sf, "resolveYamlInteger");
function of(e) {
  var t = e, r = 1, i;
  if (t.indexOf("_") !== -1 && (t = t.replace(/_/g, "")), i = t[0], (i === "-" || i === "+") && (i === "-" && (r = -1), t = t.slice(1), i = t[0]), t === "0") return 0;
  if (i === "0") {
    if (t[1] === "b") return r * parseInt(t.slice(2), 2);
    if (t[1] === "x") return r * parseInt(t.slice(2), 16);
    if (t[1] === "o") return r * parseInt(t.slice(2), 8);
  }
  return r * parseInt(t, 10);
}
d(of, "constructYamlInteger");
function lf(e) {
  return Object.prototype.toString.call(e) === "[object Number]" && e % 1 === 0 && !At.isNegativeZero(e);
}
d(lf, "isInteger");
var _2 = new zt("tag:yaml.org,2002:int", {
  kind: "scalar",
  resolve: sf,
  construct: of,
  predicate: lf,
  represent: {
    binary: /* @__PURE__ */ d(function(e) {
      return e >= 0 ? "0b" + e.toString(2) : "-0b" + e.toString(2).slice(1);
    }, "binary"),
    octal: /* @__PURE__ */ d(function(e) {
      return e >= 0 ? "0o" + e.toString(8) : "-0o" + e.toString(8).slice(1);
    }, "octal"),
    decimal: /* @__PURE__ */ d(function(e) {
      return e.toString(10);
    }, "decimal"),
    /* eslint-disable max-len */
    hexadecimal: /* @__PURE__ */ d(function(e) {
      return e >= 0 ? "0x" + e.toString(16).toUpperCase() : "-0x" + e.toString(16).toUpperCase().slice(1);
    }, "hexadecimal")
  },
  defaultStyle: "decimal",
  styleAliases: {
    binary: [2, "bin"],
    octal: [8, "oct"],
    decimal: [10, "dec"],
    hexadecimal: [16, "hex"]
  }
}), w2 = new RegExp(
  // 2.5e4, 2.5 and integers
  "^(?:[-+]?(?:[0-9][0-9_]*)(?:\\.[0-9_]*)?(?:[eE][-+]?[0-9]+)?|\\.[0-9_]+(?:[eE][-+]?[0-9]+)?|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$"
);
function cf(e) {
  return !(e === null || !w2.test(e) || // Quick hack to not allow integers end with `_`
  // Probably should update regexp & check speed
  e[e.length - 1] === "_");
}
d(cf, "resolveYamlFloat");
function hf(e) {
  var t, r;
  return t = e.replace(/_/g, "").toLowerCase(), r = t[0] === "-" ? -1 : 1, "+-".indexOf(t[0]) >= 0 && (t = t.slice(1)), t === ".inf" ? r === 1 ? Number.POSITIVE_INFINITY : Number.NEGATIVE_INFINITY : t === ".nan" ? NaN : r * parseFloat(t, 10);
}
d(hf, "constructYamlFloat");
var k2 = /^[-+]?[0-9]+e/;
function uf(e, t) {
  var r;
  if (isNaN(e))
    switch (t) {
      case "lowercase":
        return ".nan";
      case "uppercase":
        return ".NAN";
      case "camelcase":
        return ".NaN";
    }
  else if (Number.POSITIVE_INFINITY === e)
    switch (t) {
      case "lowercase":
        return ".inf";
      case "uppercase":
        return ".INF";
      case "camelcase":
        return ".Inf";
    }
  else if (Number.NEGATIVE_INFINITY === e)
    switch (t) {
      case "lowercase":
        return "-.inf";
      case "uppercase":
        return "-.INF";
      case "camelcase":
        return "-.Inf";
    }
  else if (At.isNegativeZero(e))
    return "-0.0";
  return r = e.toString(10), k2.test(r) ? r.replace("e", ".e") : r;
}
d(uf, "representYamlFloat");
function ff(e) {
  return Object.prototype.toString.call(e) === "[object Number]" && (e % 1 !== 0 || At.isNegativeZero(e));
}
d(ff, "isFloat");
var v2 = new zt("tag:yaml.org,2002:float", {
  kind: "scalar",
  resolve: cf,
  construct: hf,
  predicate: ff,
  represent: uf,
  defaultStyle: "lowercase"
}), pf = x2.extend({
  implicit: [
    b2,
    C2,
    _2,
    v2
  ]
}), S2 = pf, df = new RegExp(
  "^([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])$"
), gf = new RegExp(
  "^([0-9][0-9][0-9][0-9])-([0-9][0-9]?)-([0-9][0-9]?)(?:[Tt]|[ \\t]+)([0-9][0-9]?):([0-9][0-9]):([0-9][0-9])(?:\\.([0-9]*))?(?:[ \\t]*(Z|([-+])([0-9][0-9]?)(?::([0-9][0-9]))?))?$"
);
function mf(e) {
  return e === null ? !1 : df.exec(e) !== null || gf.exec(e) !== null;
}
d(mf, "resolveYamlTimestamp");
function yf(e) {
  var t, r, i, n, a, o, s, l = 0, c = null, h, u, f;
  if (t = df.exec(e), t === null && (t = gf.exec(e)), t === null) throw new Error("Date resolve error");
  if (r = +t[1], i = +t[2] - 1, n = +t[3], !t[4])
    return new Date(Date.UTC(r, i, n));
  if (a = +t[4], o = +t[5], s = +t[6], t[7]) {
    for (l = t[7].slice(0, 3); l.length < 3; )
      l += "0";
    l = +l;
  }
  return t[9] && (h = +t[10], u = +(t[11] || 0), c = (h * 60 + u) * 6e4, t[9] === "-" && (c = -c)), f = new Date(Date.UTC(r, i, n, a, o, s, l)), c && f.setTime(f.getTime() - c), f;
}
d(yf, "constructYamlTimestamp");
function xf(e) {
  return e.toISOString();
}
d(xf, "representYamlTimestamp");
var T2 = new zt("tag:yaml.org,2002:timestamp", {
  kind: "scalar",
  resolve: mf,
  construct: yf,
  instanceOf: Date,
  represent: xf
});
function bf(e) {
  return e === "<<" || e === null;
}
d(bf, "resolveYamlMerge");
var B2 = new zt("tag:yaml.org,2002:merge", {
  kind: "scalar",
  resolve: bf
}), Yo = `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=
\r`;
function Cf(e) {
  if (e === null) return !1;
  var t, r, i = 0, n = e.length, a = Yo;
  for (r = 0; r < n; r++)
    if (t = a.indexOf(e.charAt(r)), !(t > 64)) {
      if (t < 0) return !1;
      i += 6;
    }
  return i % 8 === 0;
}
d(Cf, "resolveYamlBinary");
function _f(e) {
  var t, r, i = e.replace(/[\r\n=]/g, ""), n = i.length, a = Yo, o = 0, s = [];
  for (t = 0; t < n; t++)
    t % 4 === 0 && t && (s.push(o >> 16 & 255), s.push(o >> 8 & 255), s.push(o & 255)), o = o << 6 | a.indexOf(i.charAt(t));
  return r = n % 4 * 6, r === 0 ? (s.push(o >> 16 & 255), s.push(o >> 8 & 255), s.push(o & 255)) : r === 18 ? (s.push(o >> 10 & 255), s.push(o >> 2 & 255)) : r === 12 && s.push(o >> 4 & 255), new Uint8Array(s);
}
d(_f, "constructYamlBinary");
function wf(e) {
  var t = "", r = 0, i, n, a = e.length, o = Yo;
  for (i = 0; i < a; i++)
    i % 3 === 0 && i && (t += o[r >> 18 & 63], t += o[r >> 12 & 63], t += o[r >> 6 & 63], t += o[r & 63]), r = (r << 8) + e[i];
  return n = a % 3, n === 0 ? (t += o[r >> 18 & 63], t += o[r >> 12 & 63], t += o[r >> 6 & 63], t += o[r & 63]) : n === 2 ? (t += o[r >> 10 & 63], t += o[r >> 4 & 63], t += o[r << 2 & 63], t += o[64]) : n === 1 && (t += o[r >> 2 & 63], t += o[r << 4 & 63], t += o[64], t += o[64]), t;
}
d(wf, "representYamlBinary");
function kf(e) {
  return Object.prototype.toString.call(e) === "[object Uint8Array]";
}
d(kf, "isBinary");
var A2 = new zt("tag:yaml.org,2002:binary", {
  kind: "scalar",
  resolve: Cf,
  construct: _f,
  predicate: kf,
  represent: wf
}), L2 = Object.prototype.hasOwnProperty, M2 = Object.prototype.toString;
function vf(e) {
  if (e === null) return !0;
  var t = [], r, i, n, a, o, s = e;
  for (r = 0, i = s.length; r < i; r += 1) {
    if (n = s[r], o = !1, M2.call(n) !== "[object Object]") return !1;
    for (a in n)
      if (L2.call(n, a))
        if (!o) o = !0;
        else return !1;
    if (!o) return !1;
    if (t.indexOf(a) === -1) t.push(a);
    else return !1;
  }
  return !0;
}
d(vf, "resolveYamlOmap");
function Sf(e) {
  return e !== null ? e : [];
}
d(Sf, "constructYamlOmap");
var $2 = new zt("tag:yaml.org,2002:omap", {
  kind: "sequence",
  resolve: vf,
  construct: Sf
}), E2 = Object.prototype.toString;
function Tf(e) {
  if (e === null) return !0;
  var t, r, i, n, a, o = e;
  for (a = new Array(o.length), t = 0, r = o.length; t < r; t += 1) {
    if (i = o[t], E2.call(i) !== "[object Object]" || (n = Object.keys(i), n.length !== 1)) return !1;
    a[t] = [n[0], i[n[0]]];
  }
  return !0;
}
d(Tf, "resolveYamlPairs");
function Bf(e) {
  if (e === null) return [];
  var t, r, i, n, a, o = e;
  for (a = new Array(o.length), t = 0, r = o.length; t < r; t += 1)
    i = o[t], n = Object.keys(i), a[t] = [n[0], i[n[0]]];
  return a;
}
d(Bf, "constructYamlPairs");
var F2 = new zt("tag:yaml.org,2002:pairs", {
  kind: "sequence",
  resolve: Tf,
  construct: Bf
}), D2 = Object.prototype.hasOwnProperty;
function Af(e) {
  if (e === null) return !0;
  var t, r = e;
  for (t in r)
    if (D2.call(r, t) && r[t] !== null)
      return !1;
  return !0;
}
d(Af, "resolveYamlSet");
function Lf(e) {
  return e !== null ? e : {};
}
d(Lf, "constructYamlSet");
var O2 = new zt("tag:yaml.org,2002:set", {
  kind: "mapping",
  resolve: Af,
  construct: Lf
}), Mf = S2.extend({
  implicit: [
    T2,
    B2
  ],
  explicit: [
    A2,
    $2,
    F2,
    O2
  ]
}), Ue = Object.prototype.hasOwnProperty, ta = 1, $f = 2, Ef = 3, ea = 4, us = 1, R2 = 2, Tc = 3, I2 = /[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x84\x86-\x9F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/, P2 = /[\x85\u2028\u2029]/, N2 = /[,\[\]\{\}]/, Ff = /^(?:!|!!|![a-z\-]+!)$/i, Df = /^(?:!|[^,\[\]\{\}])(?:%[0-9a-f]{2}|[0-9a-z\-#;\/\?:@&=\+\$,_\.!~\*'\(\)\[\]])*$/i;
function Ws(e) {
  return Object.prototype.toString.call(e);
}
d(Ws, "_class");
function de(e) {
  return e === 10 || e === 13;
}
d(de, "is_EOL");
function je(e) {
  return e === 9 || e === 32;
}
d(je, "is_WHITE_SPACE");
function Yt(e) {
  return e === 9 || e === 32 || e === 10 || e === 13;
}
d(Yt, "is_WS_OR_EOL");
function or(e) {
  return e === 44 || e === 91 || e === 93 || e === 123 || e === 125;
}
d(or, "is_FLOW_INDICATOR");
function Of(e) {
  var t;
  return 48 <= e && e <= 57 ? e - 48 : (t = e | 32, 97 <= t && t <= 102 ? t - 97 + 10 : -1);
}
d(Of, "fromHexCode");
function Rf(e) {
  return e === 120 ? 2 : e === 117 ? 4 : e === 85 ? 8 : 0;
}
d(Rf, "escapedHexLen");
function If(e) {
  return 48 <= e && e <= 57 ? e - 48 : -1;
}
d(If, "fromDecimalCode");
function qs(e) {
  return e === 48 ? "\0" : e === 97 ? "\x07" : e === 98 ? "\b" : e === 116 || e === 9 ? "	" : e === 110 ? `
` : e === 118 ? "\v" : e === 102 ? "\f" : e === 114 ? "\r" : e === 101 ? "\x1B" : e === 32 ? " " : e === 34 ? '"' : e === 47 ? "/" : e === 92 ? "\\" : e === 78 ? "" : e === 95 ? " " : e === 76 ? "\u2028" : e === 80 ? "\u2029" : "";
}
d(qs, "simpleEscapeSequence");
function Pf(e) {
  return e <= 65535 ? String.fromCharCode(e) : String.fromCharCode(
    (e - 65536 >> 10) + 55296,
    (e - 65536 & 1023) + 56320
  );
}
d(Pf, "charFromCodepoint");
var Nf = new Array(256), zf = new Array(256);
for (er = 0; er < 256; er++)
  Nf[er] = qs(er) ? 1 : 0, zf[er] = qs(er);
var er;
function Wf(e, t) {
  this.input = e, this.filename = t.filename || null, this.schema = t.schema || Mf, this.onWarning = t.onWarning || null, this.legacy = t.legacy || !1, this.json = t.json || !1, this.listener = t.listener || null, this.implicitTypes = this.schema.compiledImplicit, this.typeMap = this.schema.compiledTypeMap, this.length = e.length, this.position = 0, this.line = 0, this.lineStart = 0, this.lineIndent = 0, this.firstTabInLine = -1, this.documents = [];
}
d(Wf, "State$1");
function Uo(e, t) {
  var r = {
    name: e.filename,
    buffer: e.input.slice(0, -1),
    // omit trailing \0
    position: e.position,
    line: e.line,
    column: e.position - e.lineStart
  };
  return r.snippet = u2(r), new Qt(t, r);
}
d(Uo, "generateError");
function K(e, t) {
  throw Uo(e, t);
}
d(K, "throwError");
function Ni(e, t) {
  e.onWarning && e.onWarning.call(null, Uo(e, t));
}
d(Ni, "throwWarning");
var Bc = {
  YAML: /* @__PURE__ */ d(function(t, r, i) {
    var n, a, o;
    t.version !== null && K(t, "duplication of %YAML directive"), i.length !== 1 && K(t, "YAML directive accepts exactly one argument"), n = /^([0-9]+)\.([0-9]+)$/.exec(i[0]), n === null && K(t, "ill-formed argument of the YAML directive"), a = parseInt(n[1], 10), o = parseInt(n[2], 10), a !== 1 && K(t, "unacceptable YAML version of the document"), t.version = i[0], t.checkLineBreaks = o < 2, o !== 1 && o !== 2 && Ni(t, "unsupported YAML version of the document");
  }, "handleYamlDirective"),
  TAG: /* @__PURE__ */ d(function(t, r, i) {
    var n, a;
    i.length !== 2 && K(t, "TAG directive accepts exactly two arguments"), n = i[0], a = i[1], Ff.test(n) || K(t, "ill-formed tag handle (first argument) of the TAG directive"), Ue.call(t.tagMap, n) && K(t, 'there is a previously declared suffix for "' + n + '" tag handle'), Df.test(a) || K(t, "ill-formed tag prefix (second argument) of the TAG directive");
    try {
      a = decodeURIComponent(a);
    } catch {
      K(t, "tag prefix is malformed: " + a);
    }
    t.tagMap[n] = a;
  }, "handleTagDirective")
};
function Re(e, t, r, i) {
  var n, a, o, s;
  if (t < r) {
    if (s = e.input.slice(t, r), i)
      for (n = 0, a = s.length; n < a; n += 1)
        o = s.charCodeAt(n), o === 9 || 32 <= o && o <= 1114111 || K(e, "expected valid JSON character");
    else I2.test(s) && K(e, "the stream contains non-printable characters");
    e.result += s;
  }
}
d(Re, "captureSegment");
function Hs(e, t, r, i) {
  var n, a, o, s;
  for (At.isObject(r) || K(e, "cannot merge mappings; the provided source object is unacceptable"), n = Object.keys(r), o = 0, s = n.length; o < s; o += 1)
    a = n[o], Ue.call(t, a) || (t[a] = r[a], i[a] = !0);
}
d(Hs, "mergeMappings");
function lr(e, t, r, i, n, a, o, s, l) {
  var c, h;
  if (Array.isArray(n))
    for (n = Array.prototype.slice.call(n), c = 0, h = n.length; c < h; c += 1)
      Array.isArray(n[c]) && K(e, "nested arrays are not supported inside keys"), typeof n == "object" && Ws(n[c]) === "[object Object]" && (n[c] = "[object Object]");
  if (typeof n == "object" && Ws(n) === "[object Object]" && (n = "[object Object]"), n = String(n), t === null && (t = {}), i === "tag:yaml.org,2002:merge")
    if (Array.isArray(a))
      for (c = 0, h = a.length; c < h; c += 1)
        Hs(e, t, a[c], r);
    else
      Hs(e, t, a, r);
  else
    !e.json && !Ue.call(r, n) && Ue.call(t, n) && (e.line = o || e.line, e.lineStart = s || e.lineStart, e.position = l || e.position, K(e, "duplicated mapping key")), n === "__proto__" ? Object.defineProperty(t, n, {
      configurable: !0,
      enumerable: !0,
      writable: !0,
      value: a
    }) : t[n] = a, delete r[n];
  return t;
}
d(lr, "storeMappingPair");
function La(e) {
  var t;
  t = e.input.charCodeAt(e.position), t === 10 ? e.position++ : t === 13 ? (e.position++, e.input.charCodeAt(e.position) === 10 && e.position++) : K(e, "a line break is expected"), e.line += 1, e.lineStart = e.position, e.firstTabInLine = -1;
}
d(La, "readLineBreak");
function kt(e, t, r) {
  for (var i = 0, n = e.input.charCodeAt(e.position); n !== 0; ) {
    for (; je(n); )
      n === 9 && e.firstTabInLine === -1 && (e.firstTabInLine = e.position), n = e.input.charCodeAt(++e.position);
    if (t && n === 35)
      do
        n = e.input.charCodeAt(++e.position);
      while (n !== 10 && n !== 13 && n !== 0);
    if (de(n))
      for (La(e), n = e.input.charCodeAt(e.position), i++, e.lineIndent = 0; n === 32; )
        e.lineIndent++, n = e.input.charCodeAt(++e.position);
    else
      break;
  }
  return r !== -1 && i !== 0 && e.lineIndent < r && Ni(e, "deficient indentation"), i;
}
d(kt, "skipSeparationSpace");
function Qi(e) {
  var t = e.position, r;
  return r = e.input.charCodeAt(t), !!((r === 45 || r === 46) && r === e.input.charCodeAt(t + 1) && r === e.input.charCodeAt(t + 2) && (t += 3, r = e.input.charCodeAt(t), r === 0 || Yt(r)));
}
d(Qi, "testDocumentSeparator");
function Ma(e, t) {
  t === 1 ? e.result += " " : t > 1 && (e.result += At.repeat(`
`, t - 1));
}
d(Ma, "writeFoldedLines");
function qf(e, t, r) {
  var i, n, a, o, s, l, c, h, u = e.kind, f = e.result, p;
  if (p = e.input.charCodeAt(e.position), Yt(p) || or(p) || p === 35 || p === 38 || p === 42 || p === 33 || p === 124 || p === 62 || p === 39 || p === 34 || p === 37 || p === 64 || p === 96 || (p === 63 || p === 45) && (n = e.input.charCodeAt(e.position + 1), Yt(n) || r && or(n)))
    return !1;
  for (e.kind = "scalar", e.result = "", a = o = e.position, s = !1; p !== 0; ) {
    if (p === 58) {
      if (n = e.input.charCodeAt(e.position + 1), Yt(n) || r && or(n))
        break;
    } else if (p === 35) {
      if (i = e.input.charCodeAt(e.position - 1), Yt(i))
        break;
    } else {
      if (e.position === e.lineStart && Qi(e) || r && or(p))
        break;
      if (de(p))
        if (l = e.line, c = e.lineStart, h = e.lineIndent, kt(e, !1, -1), e.lineIndent >= t) {
          s = !0, p = e.input.charCodeAt(e.position);
          continue;
        } else {
          e.position = o, e.line = l, e.lineStart = c, e.lineIndent = h;
          break;
        }
    }
    s && (Re(e, a, o, !1), Ma(e, e.line - l), a = o = e.position, s = !1), je(p) || (o = e.position + 1), p = e.input.charCodeAt(++e.position);
  }
  return Re(e, a, o, !1), e.result ? !0 : (e.kind = u, e.result = f, !1);
}
d(qf, "readPlainScalar");
function Hf(e, t) {
  var r, i, n;
  if (r = e.input.charCodeAt(e.position), r !== 39)
    return !1;
  for (e.kind = "scalar", e.result = "", e.position++, i = n = e.position; (r = e.input.charCodeAt(e.position)) !== 0; )
    if (r === 39)
      if (Re(e, i, e.position, !0), r = e.input.charCodeAt(++e.position), r === 39)
        i = e.position, e.position++, n = e.position;
      else
        return !0;
    else de(r) ? (Re(e, i, n, !0), Ma(e, kt(e, !1, t)), i = n = e.position) : e.position === e.lineStart && Qi(e) ? K(e, "unexpected end of the document within a single quoted scalar") : (e.position++, n = e.position);
  K(e, "unexpected end of the stream within a single quoted scalar");
}
d(Hf, "readSingleQuotedScalar");
function jf(e, t) {
  var r, i, n, a, o, s;
  if (s = e.input.charCodeAt(e.position), s !== 34)
    return !1;
  for (e.kind = "scalar", e.result = "", e.position++, r = i = e.position; (s = e.input.charCodeAt(e.position)) !== 0; ) {
    if (s === 34)
      return Re(e, r, e.position, !0), e.position++, !0;
    if (s === 92) {
      if (Re(e, r, e.position, !0), s = e.input.charCodeAt(++e.position), de(s))
        kt(e, !1, t);
      else if (s < 256 && Nf[s])
        e.result += zf[s], e.position++;
      else if ((o = Rf(s)) > 0) {
        for (n = o, a = 0; n > 0; n--)
          s = e.input.charCodeAt(++e.position), (o = Of(s)) >= 0 ? a = (a << 4) + o : K(e, "expected hexadecimal character");
        e.result += Pf(a), e.position++;
      } else
        K(e, "unknown escape sequence");
      r = i = e.position;
    } else de(s) ? (Re(e, r, i, !0), Ma(e, kt(e, !1, t)), r = i = e.position) : e.position === e.lineStart && Qi(e) ? K(e, "unexpected end of the document within a double quoted scalar") : (e.position++, i = e.position);
  }
  K(e, "unexpected end of the stream within a double quoted scalar");
}
d(jf, "readDoubleQuotedScalar");
function Yf(e, t) {
  var r = !0, i, n, a, o = e.tag, s, l = e.anchor, c, h, u, f, p, g = /* @__PURE__ */ Object.create(null), m, y, x, b;
  if (b = e.input.charCodeAt(e.position), b === 91)
    h = 93, p = !1, s = [];
  else if (b === 123)
    h = 125, p = !0, s = {};
  else
    return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = s), b = e.input.charCodeAt(++e.position); b !== 0; ) {
    if (kt(e, !0, t), b = e.input.charCodeAt(e.position), b === h)
      return e.position++, e.tag = o, e.anchor = l, e.kind = p ? "mapping" : "sequence", e.result = s, !0;
    r ? b === 44 && K(e, "expected the node content, but found ','") : K(e, "missed comma between flow collection entries"), y = m = x = null, u = f = !1, b === 63 && (c = e.input.charCodeAt(e.position + 1), Yt(c) && (u = f = !0, e.position++, kt(e, !0, t))), i = e.line, n = e.lineStart, a = e.position, gr(e, t, ta, !1, !0), y = e.tag, m = e.result, kt(e, !0, t), b = e.input.charCodeAt(e.position), (f || e.line === i) && b === 58 && (u = !0, b = e.input.charCodeAt(++e.position), kt(e, !0, t), gr(e, t, ta, !1, !0), x = e.result), p ? lr(e, s, g, y, m, x, i, n, a) : u ? s.push(lr(e, null, g, y, m, x, i, n, a)) : s.push(m), kt(e, !0, t), b = e.input.charCodeAt(e.position), b === 44 ? (r = !0, b = e.input.charCodeAt(++e.position)) : r = !1;
  }
  K(e, "unexpected end of the stream within a flow collection");
}
d(Yf, "readFlowCollection");
function Uf(e, t) {
  var r, i, n = us, a = !1, o = !1, s = t, l = 0, c = !1, h, u;
  if (u = e.input.charCodeAt(e.position), u === 124)
    i = !1;
  else if (u === 62)
    i = !0;
  else
    return !1;
  for (e.kind = "scalar", e.result = ""; u !== 0; )
    if (u = e.input.charCodeAt(++e.position), u === 43 || u === 45)
      us === n ? n = u === 43 ? Tc : R2 : K(e, "repeat of a chomping mode identifier");
    else if ((h = If(u)) >= 0)
      h === 0 ? K(e, "bad explicit indentation width of a block scalar; it cannot be less than one") : o ? K(e, "repeat of an indentation width identifier") : (s = t + h - 1, o = !0);
    else
      break;
  if (je(u)) {
    do
      u = e.input.charCodeAt(++e.position);
    while (je(u));
    if (u === 35)
      do
        u = e.input.charCodeAt(++e.position);
      while (!de(u) && u !== 0);
  }
  for (; u !== 0; ) {
    for (La(e), e.lineIndent = 0, u = e.input.charCodeAt(e.position); (!o || e.lineIndent < s) && u === 32; )
      e.lineIndent++, u = e.input.charCodeAt(++e.position);
    if (!o && e.lineIndent > s && (s = e.lineIndent), de(u)) {
      l++;
      continue;
    }
    if (e.lineIndent < s) {
      n === Tc ? e.result += At.repeat(`
`, a ? 1 + l : l) : n === us && a && (e.result += `
`);
      break;
    }
    for (i ? je(u) ? (c = !0, e.result += At.repeat(`
`, a ? 1 + l : l)) : c ? (c = !1, e.result += At.repeat(`
`, l + 1)) : l === 0 ? a && (e.result += " ") : e.result += At.repeat(`
`, l) : e.result += At.repeat(`
`, a ? 1 + l : l), a = !0, o = !0, l = 0, r = e.position; !de(u) && u !== 0; )
      u = e.input.charCodeAt(++e.position);
    Re(e, r, e.position, !1);
  }
  return !0;
}
d(Uf, "readBlockScalar");
function js(e, t) {
  var r, i = e.tag, n = e.anchor, a = [], o, s = !1, l;
  if (e.firstTabInLine !== -1) return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = a), l = e.input.charCodeAt(e.position); l !== 0 && (e.firstTabInLine !== -1 && (e.position = e.firstTabInLine, K(e, "tab characters must not be used in indentation")), !(l !== 45 || (o = e.input.charCodeAt(e.position + 1), !Yt(o)))); ) {
    if (s = !0, e.position++, kt(e, !0, -1) && e.lineIndent <= t) {
      a.push(null), l = e.input.charCodeAt(e.position);
      continue;
    }
    if (r = e.line, gr(e, t, Ef, !1, !0), a.push(e.result), kt(e, !0, -1), l = e.input.charCodeAt(e.position), (e.line === r || e.lineIndent > t) && l !== 0)
      K(e, "bad indentation of a sequence entry");
    else if (e.lineIndent < t)
      break;
  }
  return s ? (e.tag = i, e.anchor = n, e.kind = "sequence", e.result = a, !0) : !1;
}
d(js, "readBlockSequence");
function Gf(e, t, r) {
  var i, n, a, o, s, l, c = e.tag, h = e.anchor, u = {}, f = /* @__PURE__ */ Object.create(null), p = null, g = null, m = null, y = !1, x = !1, b;
  if (e.firstTabInLine !== -1) return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = u), b = e.input.charCodeAt(e.position); b !== 0; ) {
    if (!y && e.firstTabInLine !== -1 && (e.position = e.firstTabInLine, K(e, "tab characters must not be used in indentation")), i = e.input.charCodeAt(e.position + 1), a = e.line, (b === 63 || b === 58) && Yt(i))
      b === 63 ? (y && (lr(e, u, f, p, g, null, o, s, l), p = g = m = null), x = !0, y = !0, n = !0) : y ? (y = !1, n = !0) : K(e, "incomplete explicit mapping pair; a key node is missed; or followed by a non-tabulated empty line"), e.position += 1, b = i;
    else {
      if (o = e.line, s = e.lineStart, l = e.position, !gr(e, r, $f, !1, !0))
        break;
      if (e.line === a) {
        for (b = e.input.charCodeAt(e.position); je(b); )
          b = e.input.charCodeAt(++e.position);
        if (b === 58)
          b = e.input.charCodeAt(++e.position), Yt(b) || K(e, "a whitespace character is expected after the key-value separator within a block mapping"), y && (lr(e, u, f, p, g, null, o, s, l), p = g = m = null), x = !0, y = !1, n = !1, p = e.tag, g = e.result;
        else if (x)
          K(e, "can not read an implicit mapping pair; a colon is missed");
        else
          return e.tag = c, e.anchor = h, !0;
      } else if (x)
        K(e, "can not read a block mapping entry; a multiline key may not be an implicit key");
      else
        return e.tag = c, e.anchor = h, !0;
    }
    if ((e.line === a || e.lineIndent > t) && (y && (o = e.line, s = e.lineStart, l = e.position), gr(e, t, ea, !0, n) && (y ? g = e.result : m = e.result), y || (lr(e, u, f, p, g, m, o, s, l), p = g = m = null), kt(e, !0, -1), b = e.input.charCodeAt(e.position)), (e.line === a || e.lineIndent > t) && b !== 0)
      K(e, "bad indentation of a mapping entry");
    else if (e.lineIndent < t)
      break;
  }
  return y && lr(e, u, f, p, g, null, o, s, l), x && (e.tag = c, e.anchor = h, e.kind = "mapping", e.result = u), x;
}
d(Gf, "readBlockMapping");
function Xf(e) {
  var t, r = !1, i = !1, n, a, o;
  if (o = e.input.charCodeAt(e.position), o !== 33) return !1;
  if (e.tag !== null && K(e, "duplication of a tag property"), o = e.input.charCodeAt(++e.position), o === 60 ? (r = !0, o = e.input.charCodeAt(++e.position)) : o === 33 ? (i = !0, n = "!!", o = e.input.charCodeAt(++e.position)) : n = "!", t = e.position, r) {
    do
      o = e.input.charCodeAt(++e.position);
    while (o !== 0 && o !== 62);
    e.position < e.length ? (a = e.input.slice(t, e.position), o = e.input.charCodeAt(++e.position)) : K(e, "unexpected end of the stream within a verbatim tag");
  } else {
    for (; o !== 0 && !Yt(o); )
      o === 33 && (i ? K(e, "tag suffix cannot contain exclamation marks") : (n = e.input.slice(t - 1, e.position + 1), Ff.test(n) || K(e, "named tag handle cannot contain such characters"), i = !0, t = e.position + 1)), o = e.input.charCodeAt(++e.position);
    a = e.input.slice(t, e.position), N2.test(a) && K(e, "tag suffix cannot contain flow indicator characters");
  }
  a && !Df.test(a) && K(e, "tag name cannot contain such characters: " + a);
  try {
    a = decodeURIComponent(a);
  } catch {
    K(e, "tag name is malformed: " + a);
  }
  return r ? e.tag = a : Ue.call(e.tagMap, n) ? e.tag = e.tagMap[n] + a : n === "!" ? e.tag = "!" + a : n === "!!" ? e.tag = "tag:yaml.org,2002:" + a : K(e, 'undeclared tag handle "' + n + '"'), !0;
}
d(Xf, "readTagProperty");
function Vf(e) {
  var t, r;
  if (r = e.input.charCodeAt(e.position), r !== 38) return !1;
  for (e.anchor !== null && K(e, "duplication of an anchor property"), r = e.input.charCodeAt(++e.position), t = e.position; r !== 0 && !Yt(r) && !or(r); )
    r = e.input.charCodeAt(++e.position);
  return e.position === t && K(e, "name of an anchor node must contain at least one character"), e.anchor = e.input.slice(t, e.position), !0;
}
d(Vf, "readAnchorProperty");
function Zf(e) {
  var t, r, i;
  if (i = e.input.charCodeAt(e.position), i !== 42) return !1;
  for (i = e.input.charCodeAt(++e.position), t = e.position; i !== 0 && !Yt(i) && !or(i); )
    i = e.input.charCodeAt(++e.position);
  return e.position === t && K(e, "name of an alias node must contain at least one character"), r = e.input.slice(t, e.position), Ue.call(e.anchorMap, r) || K(e, 'unidentified alias "' + r + '"'), e.result = e.anchorMap[r], kt(e, !0, -1), !0;
}
d(Zf, "readAlias");
function gr(e, t, r, i, n) {
  var a, o, s, l = 1, c = !1, h = !1, u, f, p, g, m, y;
  if (e.listener !== null && e.listener("open", e), e.tag = null, e.anchor = null, e.kind = null, e.result = null, a = o = s = ea === r || Ef === r, i && kt(e, !0, -1) && (c = !0, e.lineIndent > t ? l = 1 : e.lineIndent === t ? l = 0 : e.lineIndent < t && (l = -1)), l === 1)
    for (; Xf(e) || Vf(e); )
      kt(e, !0, -1) ? (c = !0, s = a, e.lineIndent > t ? l = 1 : e.lineIndent === t ? l = 0 : e.lineIndent < t && (l = -1)) : s = !1;
  if (s && (s = c || n), (l === 1 || ea === r) && (ta === r || $f === r ? m = t : m = t + 1, y = e.position - e.lineStart, l === 1 ? s && (js(e, y) || Gf(e, y, m)) || Yf(e, m) ? h = !0 : (o && Uf(e, m) || Hf(e, m) || jf(e, m) ? h = !0 : Zf(e) ? (h = !0, (e.tag !== null || e.anchor !== null) && K(e, "alias node should not have any properties")) : qf(e, m, ta === r) && (h = !0, e.tag === null && (e.tag = "?")), e.anchor !== null && (e.anchorMap[e.anchor] = e.result)) : l === 0 && (h = s && js(e, y))), e.tag === null)
    e.anchor !== null && (e.anchorMap[e.anchor] = e.result);
  else if (e.tag === "?") {
    for (e.result !== null && e.kind !== "scalar" && K(e, 'unacceptable node kind for !<?> tag; it should be "scalar", not "' + e.kind + '"'), u = 0, f = e.implicitTypes.length; u < f; u += 1)
      if (g = e.implicitTypes[u], g.resolve(e.result)) {
        e.result = g.construct(e.result), e.tag = g.tag, e.anchor !== null && (e.anchorMap[e.anchor] = e.result);
        break;
      }
  } else if (e.tag !== "!") {
    if (Ue.call(e.typeMap[e.kind || "fallback"], e.tag))
      g = e.typeMap[e.kind || "fallback"][e.tag];
    else
      for (g = null, p = e.typeMap.multi[e.kind || "fallback"], u = 0, f = p.length; u < f; u += 1)
        if (e.tag.slice(0, p[u].tag.length) === p[u].tag) {
          g = p[u];
          break;
        }
    g || K(e, "unknown tag !<" + e.tag + ">"), e.result !== null && g.kind !== e.kind && K(e, "unacceptable node kind for !<" + e.tag + '> tag; it should be "' + g.kind + '", not "' + e.kind + '"'), g.resolve(e.result, e.tag) ? (e.result = g.construct(e.result, e.tag), e.anchor !== null && (e.anchorMap[e.anchor] = e.result)) : K(e, "cannot resolve a node with !<" + e.tag + "> explicit tag");
  }
  return e.listener !== null && e.listener("close", e), e.tag !== null || e.anchor !== null || h;
}
d(gr, "composeNode");
function Kf(e) {
  var t = e.position, r, i, n, a = !1, o;
  for (e.version = null, e.checkLineBreaks = e.legacy, e.tagMap = /* @__PURE__ */ Object.create(null), e.anchorMap = /* @__PURE__ */ Object.create(null); (o = e.input.charCodeAt(e.position)) !== 0 && (kt(e, !0, -1), o = e.input.charCodeAt(e.position), !(e.lineIndent > 0 || o !== 37)); ) {
    for (a = !0, o = e.input.charCodeAt(++e.position), r = e.position; o !== 0 && !Yt(o); )
      o = e.input.charCodeAt(++e.position);
    for (i = e.input.slice(r, e.position), n = [], i.length < 1 && K(e, "directive name must not be less than one character in length"); o !== 0; ) {
      for (; je(o); )
        o = e.input.charCodeAt(++e.position);
      if (o === 35) {
        do
          o = e.input.charCodeAt(++e.position);
        while (o !== 0 && !de(o));
        break;
      }
      if (de(o)) break;
      for (r = e.position; o !== 0 && !Yt(o); )
        o = e.input.charCodeAt(++e.position);
      n.push(e.input.slice(r, e.position));
    }
    o !== 0 && La(e), Ue.call(Bc, i) ? Bc[i](e, i, n) : Ni(e, 'unknown document directive "' + i + '"');
  }
  if (kt(e, !0, -1), e.lineIndent === 0 && e.input.charCodeAt(e.position) === 45 && e.input.charCodeAt(e.position + 1) === 45 && e.input.charCodeAt(e.position + 2) === 45 ? (e.position += 3, kt(e, !0, -1)) : a && K(e, "directives end mark is expected"), gr(e, e.lineIndent - 1, ea, !1, !0), kt(e, !0, -1), e.checkLineBreaks && P2.test(e.input.slice(t, e.position)) && Ni(e, "non-ASCII line breaks are interpreted as content"), e.documents.push(e.result), e.position === e.lineStart && Qi(e)) {
    e.input.charCodeAt(e.position) === 46 && (e.position += 3, kt(e, !0, -1));
    return;
  }
  if (e.position < e.length - 1)
    K(e, "end of the stream or a document separator is expected");
  else
    return;
}
d(Kf, "readDocument");
function Go(e, t) {
  e = String(e), t = t || {}, e.length !== 0 && (e.charCodeAt(e.length - 1) !== 10 && e.charCodeAt(e.length - 1) !== 13 && (e += `
`), e.charCodeAt(0) === 65279 && (e = e.slice(1)));
  var r = new Wf(e, t), i = e.indexOf("\0");
  for (i !== -1 && (r.position = i, K(r, "null byte is not allowed in input")), r.input += "\0"; r.input.charCodeAt(r.position) === 32; )
    r.lineIndent += 1, r.position += 1;
  for (; r.position < r.length - 1; )
    Kf(r);
  return r.documents;
}
d(Go, "loadDocuments");
function z2(e, t, r) {
  t !== null && typeof t == "object" && typeof r > "u" && (r = t, t = null);
  var i = Go(e, r);
  if (typeof t != "function")
    return i;
  for (var n = 0, a = i.length; n < a; n += 1)
    t(i[n]);
}
d(z2, "loadAll$1");
function Qf(e, t) {
  var r = Go(e, t);
  if (r.length !== 0) {
    if (r.length === 1)
      return r[0];
    throw new Qt("expected a single document in the stream, but found more");
  }
}
d(Qf, "load$1");
var W2 = Qf, q2 = {
  load: W2
}, Jf = Object.prototype.toString, tp = Object.prototype.hasOwnProperty, Xo = 65279, H2 = 9, zi = 10, j2 = 13, Y2 = 32, U2 = 33, G2 = 34, Ys = 35, X2 = 37, V2 = 38, Z2 = 39, K2 = 42, ep = 44, Q2 = 45, ra = 58, J2 = 61, tC = 62, eC = 63, rC = 64, rp = 91, ip = 93, iC = 96, np = 123, nC = 124, ap = 125, qt = {};
qt[0] = "\\0";
qt[7] = "\\a";
qt[8] = "\\b";
qt[9] = "\\t";
qt[10] = "\\n";
qt[11] = "\\v";
qt[12] = "\\f";
qt[13] = "\\r";
qt[27] = "\\e";
qt[34] = '\\"';
qt[92] = "\\\\";
qt[133] = "\\N";
qt[160] = "\\_";
qt[8232] = "\\L";
qt[8233] = "\\P";
var aC = [
  "y",
  "Y",
  "yes",
  "Yes",
  "YES",
  "on",
  "On",
  "ON",
  "n",
  "N",
  "no",
  "No",
  "NO",
  "off",
  "Off",
  "OFF"
], sC = /^[-+]?[0-9_]+(?::[0-9_]+)+(?:\.[0-9_]*)?$/;
function sp(e, t) {
  var r, i, n, a, o, s, l;
  if (t === null) return {};
  for (r = {}, i = Object.keys(t), n = 0, a = i.length; n < a; n += 1)
    o = i[n], s = String(t[o]), o.slice(0, 2) === "!!" && (o = "tag:yaml.org,2002:" + o.slice(2)), l = e.compiledTypeMap.fallback[o], l && tp.call(l.styleAliases, s) && (s = l.styleAliases[s]), r[o] = s;
  return r;
}
d(sp, "compileStyleMap");
function op(e) {
  var t, r, i;
  if (t = e.toString(16).toUpperCase(), e <= 255)
    r = "x", i = 2;
  else if (e <= 65535)
    r = "u", i = 4;
  else if (e <= 4294967295)
    r = "U", i = 8;
  else
    throw new Qt("code point within a string may not be greater than 0xFFFFFFFF");
  return "\\" + r + At.repeat("0", i - t.length) + t;
}
d(op, "encodeHex");
var oC = 1, Wi = 2;
function lp(e) {
  this.schema = e.schema || Mf, this.indent = Math.max(1, e.indent || 2), this.noArrayIndent = e.noArrayIndent || !1, this.skipInvalid = e.skipInvalid || !1, this.flowLevel = At.isNothing(e.flowLevel) ? -1 : e.flowLevel, this.styleMap = sp(this.schema, e.styles || null), this.sortKeys = e.sortKeys || !1, this.lineWidth = e.lineWidth || 80, this.noRefs = e.noRefs || !1, this.noCompatMode = e.noCompatMode || !1, this.condenseFlow = e.condenseFlow || !1, this.quotingType = e.quotingType === '"' ? Wi : oC, this.forceQuotes = e.forceQuotes || !1, this.replacer = typeof e.replacer == "function" ? e.replacer : null, this.implicitTypes = this.schema.compiledImplicit, this.explicitTypes = this.schema.compiledExplicit, this.tag = null, this.result = "", this.duplicates = [], this.usedDuplicates = null;
}
d(lp, "State");
function Us(e, t) {
  for (var r = At.repeat(" ", t), i = 0, n = -1, a = "", o, s = e.length; i < s; )
    n = e.indexOf(`
`, i), n === -1 ? (o = e.slice(i), i = s) : (o = e.slice(i, n + 1), i = n + 1), o.length && o !== `
` && (a += r), a += o;
  return a;
}
d(Us, "indentString");
function ia(e, t) {
  return `
` + At.repeat(" ", e.indent * t);
}
d(ia, "generateNextLine");
function cp(e, t) {
  var r, i, n;
  for (r = 0, i = e.implicitTypes.length; r < i; r += 1)
    if (n = e.implicitTypes[r], n.resolve(t))
      return !0;
  return !1;
}
d(cp, "testImplicitResolving");
function qi(e) {
  return e === Y2 || e === H2;
}
d(qi, "isWhitespace");
function Qr(e) {
  return 32 <= e && e <= 126 || 161 <= e && e <= 55295 && e !== 8232 && e !== 8233 || 57344 <= e && e <= 65533 && e !== Xo || 65536 <= e && e <= 1114111;
}
d(Qr, "isPrintable");
function Gs(e) {
  return Qr(e) && e !== Xo && e !== j2 && e !== zi;
}
d(Gs, "isNsCharOrWhitespace");
function Xs(e, t, r) {
  var i = Gs(e), n = i && !qi(e);
  return (
    // ns-plain-safe
    (r ? (
      // c = flow-in
      i
    ) : i && e !== ep && e !== rp && e !== ip && e !== np && e !== ap) && e !== Ys && !(t === ra && !n) || Gs(t) && !qi(t) && e === Ys || t === ra && n
  );
}
d(Xs, "isPlainSafe");
function hp(e) {
  return Qr(e) && e !== Xo && !qi(e) && e !== Q2 && e !== eC && e !== ra && e !== ep && e !== rp && e !== ip && e !== np && e !== ap && e !== Ys && e !== V2 && e !== K2 && e !== U2 && e !== nC && e !== J2 && e !== tC && e !== Z2 && e !== G2 && e !== X2 && e !== rC && e !== iC;
}
d(hp, "isPlainSafeFirst");
function up(e) {
  return !qi(e) && e !== ra;
}
d(up, "isPlainSafeLast");
function Dr(e, t) {
  var r = e.charCodeAt(t), i;
  return r >= 55296 && r <= 56319 && t + 1 < e.length && (i = e.charCodeAt(t + 1), i >= 56320 && i <= 57343) ? (r - 55296) * 1024 + i - 56320 + 65536 : r;
}
d(Dr, "codePointAt");
function Vo(e) {
  var t = /^\n* /;
  return t.test(e);
}
d(Vo, "needIndentIndicator");
var fp = 1, Vs = 2, pp = 3, dp = 4, Er = 5;
function gp(e, t, r, i, n, a, o, s) {
  var l, c = 0, h = null, u = !1, f = !1, p = i !== -1, g = -1, m = hp(Dr(e, 0)) && up(Dr(e, e.length - 1));
  if (t || o)
    for (l = 0; l < e.length; c >= 65536 ? l += 2 : l++) {
      if (c = Dr(e, l), !Qr(c))
        return Er;
      m = m && Xs(c, h, s), h = c;
    }
  else {
    for (l = 0; l < e.length; c >= 65536 ? l += 2 : l++) {
      if (c = Dr(e, l), c === zi)
        u = !0, p && (f = f || // Foldable line = too long, and not more-indented.
        l - g - 1 > i && e[g + 1] !== " ", g = l);
      else if (!Qr(c))
        return Er;
      m = m && Xs(c, h, s), h = c;
    }
    f = f || p && l - g - 1 > i && e[g + 1] !== " ";
  }
  return !u && !f ? m && !o && !n(e) ? fp : a === Wi ? Er : Vs : r > 9 && Vo(e) ? Er : o ? a === Wi ? Er : Vs : f ? dp : pp;
}
d(gp, "chooseScalarStyle");
function mp(e, t, r, i, n) {
  e.dump = function() {
    if (t.length === 0)
      return e.quotingType === Wi ? '""' : "''";
    if (!e.noCompatMode && (aC.indexOf(t) !== -1 || sC.test(t)))
      return e.quotingType === Wi ? '"' + t + '"' : "'" + t + "'";
    var a = e.indent * Math.max(1, r), o = e.lineWidth === -1 ? -1 : Math.max(Math.min(e.lineWidth, 40), e.lineWidth - a), s = i || e.flowLevel > -1 && r >= e.flowLevel;
    function l(c) {
      return cp(e, c);
    }
    switch (d(l, "testAmbiguity"), gp(
      t,
      s,
      e.indent,
      o,
      l,
      e.quotingType,
      e.forceQuotes && !i,
      n
    )) {
      case fp:
        return t;
      case Vs:
        return "'" + t.replace(/'/g, "''") + "'";
      case pp:
        return "|" + Zs(t, e.indent) + Ks(Us(t, a));
      case dp:
        return ">" + Zs(t, e.indent) + Ks(Us(yp(t, o), a));
      case Er:
        return '"' + xp(t) + '"';
      default:
        throw new Qt("impossible error: invalid scalar style");
    }
  }();
}
d(mp, "writeScalar");
function Zs(e, t) {
  var r = Vo(e) ? String(t) : "", i = e[e.length - 1] === `
`, n = i && (e[e.length - 2] === `
` || e === `
`), a = n ? "+" : i ? "" : "-";
  return r + a + `
`;
}
d(Zs, "blockHeader");
function Ks(e) {
  return e[e.length - 1] === `
` ? e.slice(0, -1) : e;
}
d(Ks, "dropEndingNewline");
function yp(e, t) {
  for (var r = /(\n+)([^\n]*)/g, i = function() {
    var c = e.indexOf(`
`);
    return c = c !== -1 ? c : e.length, r.lastIndex = c, Qs(e.slice(0, c), t);
  }(), n = e[0] === `
` || e[0] === " ", a, o; o = r.exec(e); ) {
    var s = o[1], l = o[2];
    a = l[0] === " ", i += s + (!n && !a && l !== "" ? `
` : "") + Qs(l, t), n = a;
  }
  return i;
}
d(yp, "foldString");
function Qs(e, t) {
  if (e === "" || e[0] === " ") return e;
  for (var r = / [^ ]/g, i, n = 0, a, o = 0, s = 0, l = ""; i = r.exec(e); )
    s = i.index, s - n > t && (a = o > n ? o : s, l += `
` + e.slice(n, a), n = a + 1), o = s;
  return l += `
`, e.length - n > t && o > n ? l += e.slice(n, o) + `
` + e.slice(o + 1) : l += e.slice(n), l.slice(1);
}
d(Qs, "foldLine");
function xp(e) {
  for (var t = "", r = 0, i, n = 0; n < e.length; r >= 65536 ? n += 2 : n++)
    r = Dr(e, n), i = qt[r], !i && Qr(r) ? (t += e[n], r >= 65536 && (t += e[n + 1])) : t += i || op(r);
  return t;
}
d(xp, "escapeString");
function bp(e, t, r) {
  var i = "", n = e.tag, a, o, s;
  for (a = 0, o = r.length; a < o; a += 1)
    s = r[a], e.replacer && (s = e.replacer.call(r, String(a), s)), (ve(e, t, s, !1, !1) || typeof s > "u" && ve(e, t, null, !1, !1)) && (i !== "" && (i += "," + (e.condenseFlow ? "" : " ")), i += e.dump);
  e.tag = n, e.dump = "[" + i + "]";
}
d(bp, "writeFlowSequence");
function Js(e, t, r, i) {
  var n = "", a = e.tag, o, s, l;
  for (o = 0, s = r.length; o < s; o += 1)
    l = r[o], e.replacer && (l = e.replacer.call(r, String(o), l)), (ve(e, t + 1, l, !0, !0, !1, !0) || typeof l > "u" && ve(e, t + 1, null, !0, !0, !1, !0)) && ((!i || n !== "") && (n += ia(e, t)), e.dump && zi === e.dump.charCodeAt(0) ? n += "-" : n += "- ", n += e.dump);
  e.tag = a, e.dump = n || "[]";
}
d(Js, "writeBlockSequence");
function Cp(e, t, r) {
  var i = "", n = e.tag, a = Object.keys(r), o, s, l, c, h;
  for (o = 0, s = a.length; o < s; o += 1)
    h = "", i !== "" && (h += ", "), e.condenseFlow && (h += '"'), l = a[o], c = r[l], e.replacer && (c = e.replacer.call(r, l, c)), ve(e, t, l, !1, !1) && (e.dump.length > 1024 && (h += "? "), h += e.dump + (e.condenseFlow ? '"' : "") + ":" + (e.condenseFlow ? "" : " "), ve(e, t, c, !1, !1) && (h += e.dump, i += h));
  e.tag = n, e.dump = "{" + i + "}";
}
d(Cp, "writeFlowMapping");
function _p(e, t, r, i) {
  var n = "", a = e.tag, o = Object.keys(r), s, l, c, h, u, f;
  if (e.sortKeys === !0)
    o.sort();
  else if (typeof e.sortKeys == "function")
    o.sort(e.sortKeys);
  else if (e.sortKeys)
    throw new Qt("sortKeys must be a boolean or a function");
  for (s = 0, l = o.length; s < l; s += 1)
    f = "", (!i || n !== "") && (f += ia(e, t)), c = o[s], h = r[c], e.replacer && (h = e.replacer.call(r, c, h)), ve(e, t + 1, c, !0, !0, !0) && (u = e.tag !== null && e.tag !== "?" || e.dump && e.dump.length > 1024, u && (e.dump && zi === e.dump.charCodeAt(0) ? f += "?" : f += "? "), f += e.dump, u && (f += ia(e, t)), ve(e, t + 1, h, !0, u) && (e.dump && zi === e.dump.charCodeAt(0) ? f += ":" : f += ": ", f += e.dump, n += f));
  e.tag = a, e.dump = n || "{}";
}
d(_p, "writeBlockMapping");
function to(e, t, r) {
  var i, n, a, o, s, l;
  for (n = r ? e.explicitTypes : e.implicitTypes, a = 0, o = n.length; a < o; a += 1)
    if (s = n[a], (s.instanceOf || s.predicate) && (!s.instanceOf || typeof t == "object" && t instanceof s.instanceOf) && (!s.predicate || s.predicate(t))) {
      if (r ? s.multi && s.representName ? e.tag = s.representName(t) : e.tag = s.tag : e.tag = "?", s.represent) {
        if (l = e.styleMap[s.tag] || s.defaultStyle, Jf.call(s.represent) === "[object Function]")
          i = s.represent(t, l);
        else if (tp.call(s.represent, l))
          i = s.represent[l](t, l);
        else
          throw new Qt("!<" + s.tag + '> tag resolver accepts not "' + l + '" style');
        e.dump = i;
      }
      return !0;
    }
  return !1;
}
d(to, "detectType");
function ve(e, t, r, i, n, a, o) {
  e.tag = null, e.dump = r, to(e, r, !1) || to(e, r, !0);
  var s = Jf.call(e.dump), l = i, c;
  i && (i = e.flowLevel < 0 || e.flowLevel > t);
  var h = s === "[object Object]" || s === "[object Array]", u, f;
  if (h && (u = e.duplicates.indexOf(r), f = u !== -1), (e.tag !== null && e.tag !== "?" || f || e.indent !== 2 && t > 0) && (n = !1), f && e.usedDuplicates[u])
    e.dump = "*ref_" + u;
  else {
    if (h && f && !e.usedDuplicates[u] && (e.usedDuplicates[u] = !0), s === "[object Object]")
      i && Object.keys(e.dump).length !== 0 ? (_p(e, t, e.dump, n), f && (e.dump = "&ref_" + u + e.dump)) : (Cp(e, t, e.dump), f && (e.dump = "&ref_" + u + " " + e.dump));
    else if (s === "[object Array]")
      i && e.dump.length !== 0 ? (e.noArrayIndent && !o && t > 0 ? Js(e, t - 1, e.dump, n) : Js(e, t, e.dump, n), f && (e.dump = "&ref_" + u + e.dump)) : (bp(e, t, e.dump), f && (e.dump = "&ref_" + u + " " + e.dump));
    else if (s === "[object String]")
      e.tag !== "?" && mp(e, e.dump, t, a, l);
    else {
      if (s === "[object Undefined]")
        return !1;
      if (e.skipInvalid) return !1;
      throw new Qt("unacceptable kind of an object to dump " + s);
    }
    e.tag !== null && e.tag !== "?" && (c = encodeURI(
      e.tag[0] === "!" ? e.tag.slice(1) : e.tag
    ).replace(/!/g, "%21"), e.tag[0] === "!" ? c = "!" + c : c.slice(0, 18) === "tag:yaml.org,2002:" ? c = "!!" + c.slice(18) : c = "!<" + c + ">", e.dump = c + " " + e.dump);
  }
  return !0;
}
d(ve, "writeNode");
function wp(e, t) {
  var r = [], i = [], n, a;
  for (na(e, r, i), n = 0, a = i.length; n < a; n += 1)
    t.duplicates.push(r[i[n]]);
  t.usedDuplicates = new Array(a);
}
d(wp, "getDuplicateReferences");
function na(e, t, r) {
  var i, n, a;
  if (e !== null && typeof e == "object")
    if (n = t.indexOf(e), n !== -1)
      r.indexOf(n) === -1 && r.push(n);
    else if (t.push(e), Array.isArray(e))
      for (n = 0, a = e.length; n < a; n += 1)
        na(e[n], t, r);
    else
      for (i = Object.keys(e), n = 0, a = i.length; n < a; n += 1)
        na(e[i[n]], t, r);
}
d(na, "inspectNode");
function lC(e, t) {
  t = t || {};
  var r = new lp(t);
  r.noRefs || wp(e, r);
  var i = e;
  return r.replacer && (i = r.replacer.call({ "": i }, "", i)), ve(r, 0, i, !0, !0) ? r.dump + `
` : "";
}
d(lC, "dump$1");
function cC(e, t) {
  return function() {
    throw new Error("Function yaml." + e + " is removed in js-yaml 4. Use yaml." + t + " instead, which is now safe by default.");
  };
}
d(cC, "renamed");
var hC = pf, uC = q2.load;
/*! Bundled license information:

js-yaml/dist/js-yaml.mjs:
  (*! js-yaml 4.1.0 https://github.com/nodeca/js-yaml @license MIT *)
*/
var Pt = {
  aggregation: 17.25,
  extension: 17.25,
  composition: 17.25,
  dependency: 6,
  lollipop: 13.5,
  arrow_point: 4
  //arrow_cross: 24,
}, Ac = {
  arrow_point: 9,
  arrow_cross: 12.5,
  arrow_circle: 12.5
};
function vi(e, t) {
  if (e === void 0 || t === void 0)
    return { angle: 0, deltaX: 0, deltaY: 0 };
  e = wt(e), t = wt(t);
  const [r, i] = [e.x, e.y], [n, a] = [t.x, t.y], o = n - r, s = a - i;
  return { angle: Math.atan(s / o), deltaX: o, deltaY: s };
}
d(vi, "calculateDeltaAndAngle");
var wt = /* @__PURE__ */ d((e) => Array.isArray(e) ? { x: e[0], y: e[1] } : e, "pointTransformer"), fC = /* @__PURE__ */ d((e) => ({
  x: /* @__PURE__ */ d(function(t, r, i) {
    let n = 0;
    const a = wt(i[0]).x < wt(i[i.length - 1]).x ? "left" : "right";
    if (r === 0 && Object.hasOwn(Pt, e.arrowTypeStart)) {
      const { angle: p, deltaX: g } = vi(i[0], i[1]);
      n = Pt[e.arrowTypeStart] * Math.cos(p) * (g >= 0 ? 1 : -1);
    } else if (r === i.length - 1 && Object.hasOwn(Pt, e.arrowTypeEnd)) {
      const { angle: p, deltaX: g } = vi(
        i[i.length - 1],
        i[i.length - 2]
      );
      n = Pt[e.arrowTypeEnd] * Math.cos(p) * (g >= 0 ? 1 : -1);
    }
    const o = Math.abs(
      wt(t).x - wt(i[i.length - 1]).x
    ), s = Math.abs(
      wt(t).y - wt(i[i.length - 1]).y
    ), l = Math.abs(wt(t).x - wt(i[0]).x), c = Math.abs(wt(t).y - wt(i[0]).y), h = Pt[e.arrowTypeStart], u = Pt[e.arrowTypeEnd], f = 1;
    if (o < u && o > 0 && s < u) {
      let p = u + f - o;
      p *= a === "right" ? -1 : 1, n -= p;
    }
    if (l < h && l > 0 && c < h) {
      let p = h + f - l;
      p *= a === "right" ? -1 : 1, n += p;
    }
    return wt(t).x + n;
  }, "x"),
  y: /* @__PURE__ */ d(function(t, r, i) {
    let n = 0;
    const a = wt(i[0]).y < wt(i[i.length - 1]).y ? "down" : "up";
    if (r === 0 && Object.hasOwn(Pt, e.arrowTypeStart)) {
      const { angle: p, deltaY: g } = vi(i[0], i[1]);
      n = Pt[e.arrowTypeStart] * Math.abs(Math.sin(p)) * (g >= 0 ? 1 : -1);
    } else if (r === i.length - 1 && Object.hasOwn(Pt, e.arrowTypeEnd)) {
      const { angle: p, deltaY: g } = vi(
        i[i.length - 1],
        i[i.length - 2]
      );
      n = Pt[e.arrowTypeEnd] * Math.abs(Math.sin(p)) * (g >= 0 ? 1 : -1);
    }
    const o = Math.abs(
      wt(t).y - wt(i[i.length - 1]).y
    ), s = Math.abs(
      wt(t).x - wt(i[i.length - 1]).x
    ), l = Math.abs(wt(t).y - wt(i[0]).y), c = Math.abs(wt(t).x - wt(i[0]).x), h = Pt[e.arrowTypeStart], u = Pt[e.arrowTypeEnd], f = 1;
    if (o < u && o > 0 && s < u) {
      let p = u + f - o;
      p *= a === "up" ? -1 : 1, n -= p;
    }
    if (l < h && l > 0 && c < h) {
      let p = h + f - l;
      p *= a === "up" ? -1 : 1, n += p;
    }
    return wt(t).y + n;
  }, "y")
}), "getLineFunctionsWithOffset"), Zo = /* @__PURE__ */ d(({
  flowchart: e
}) => {
  var n, a;
  const t = ((n = e == null ? void 0 : e.subGraphTitleMargin) == null ? void 0 : n.top) ?? 0, r = ((a = e == null ? void 0 : e.subGraphTitleMargin) == null ? void 0 : a.bottom) ?? 0, i = t + r;
  return {
    subGraphTitleTopMargin: t,
    subGraphTitleBottomMargin: r,
    subGraphTitleTotalMargin: i
  };
}, "getSubGraphTitleMargins"), pC = /* @__PURE__ */ d((e) => {
  const { handDrawnSeed: t } = pt();
  return {
    fill: e,
    hachureAngle: 120,
    // angle of hachure,
    hachureGap: 4,
    fillWeight: 2,
    roughness: 0.7,
    stroke: e,
    seed: t
  };
}, "solidStateFill"), ri = /* @__PURE__ */ d((e) => {
  const t = dC([
    ...e.cssCompiledStyles || [],
    ...e.cssStyles || [],
    ...e.labelStyle || []
  ]);
  return { stylesMap: t, stylesArray: [...t] };
}, "compileStyles"), dC = /* @__PURE__ */ d((e) => {
  const t = /* @__PURE__ */ new Map();
  return e.forEach((r) => {
    const [i, n] = r.split(":");
    t.set(i.trim(), n == null ? void 0 : n.trim());
  }), t;
}, "styles2Map"), kp = /* @__PURE__ */ d((e) => e === "color" || e === "font-size" || e === "font-family" || e === "font-weight" || e === "font-style" || e === "text-decoration" || e === "text-align" || e === "text-transform" || e === "line-height" || e === "letter-spacing" || e === "word-spacing" || e === "text-shadow" || e === "text-overflow" || e === "white-space" || e === "word-wrap" || e === "word-break" || e === "overflow-wrap" || e === "hyphens", "isLabelStyle"), G = /* @__PURE__ */ d((e) => {
  const { stylesArray: t } = ri(e), r = [], i = [], n = [], a = [];
  return t.forEach((o) => {
    const s = o[0];
    kp(s) ? r.push(o.join(":") + " !important") : (i.push(o.join(":") + " !important"), s.includes("stroke") && n.push(o.join(":") + " !important"), s === "fill" && a.push(o.join(":") + " !important"));
  }), {
    labelStyles: r.join(";"),
    nodeStyles: i.join(";"),
    stylesArray: t,
    borderStyles: n,
    backgroundStyles: a
  };
}, "styles2String"), U = /* @__PURE__ */ d((e, t) => {
  var l;
  const { themeVariables: r, handDrawnSeed: i } = pt(), { nodeBorder: n, mainBkg: a } = r, { stylesMap: o } = ri(e);
  return Object.assign(
    {
      roughness: 0.7,
      fill: o.get("fill") || a,
      fillStyle: "hachure",
      // solid fill
      fillWeight: 4,
      hachureGap: 5.2,
      stroke: o.get("stroke") || n,
      seed: i,
      strokeWidth: ((l = o.get("stroke-width")) == null ? void 0 : l.replace("px", "")) || 1.3,
      fillLineDash: [0, 0],
      strokeLineDash: gC(o.get("stroke-dasharray"))
    },
    t
  );
}, "userNodeOverrides"), gC = /* @__PURE__ */ d((e) => {
  if (!e)
    return [0, 0];
  const t = e.trim().split(/\s+/).map(Number);
  if (t.length === 1) {
    const n = isNaN(t[0]) ? 0 : t[0];
    return [n, n];
  }
  const r = isNaN(t[0]) ? 0 : t[0], i = isNaN(t[1]) ? 0 : t[1];
  return [r, i];
}, "getStrokeDashArray"), Ko = {}, $t = {};
Object.defineProperty($t, "__esModule", { value: !0 });
$t.BLANK_URL = $t.relativeFirstCharacters = $t.whitespaceEscapeCharsRegex = $t.urlSchemeRegex = $t.ctrlCharactersRegex = $t.htmlCtrlEntityRegex = $t.htmlEntitiesRegex = $t.invalidProtocolRegex = void 0;
$t.invalidProtocolRegex = /^([^\w]*)(javascript|data|vbscript)/im;
$t.htmlEntitiesRegex = /&#(\w+)(^\w|;)?/g;
$t.htmlCtrlEntityRegex = /&(newline|tab);/gi;
$t.ctrlCharactersRegex = /[\u0000-\u001F\u007F-\u009F\u2000-\u200D\uFEFF]/gim;
$t.urlSchemeRegex = /^.+(:|&colon;)/gim;
$t.whitespaceEscapeCharsRegex = /(\\|%5[cC])((%(6[eE]|72|74))|[nrt])/g;
$t.relativeFirstCharacters = [".", "/"];
$t.BLANK_URL = "about:blank";
Object.defineProperty(Ko, "__esModule", { value: !0 });
var vp = Ko.sanitizeUrl = void 0, It = $t;
function mC(e) {
  return It.relativeFirstCharacters.indexOf(e[0]) > -1;
}
function yC(e) {
  var t = e.replace(It.ctrlCharactersRegex, "");
  return t.replace(It.htmlEntitiesRegex, function(r, i) {
    return String.fromCharCode(i);
  });
}
function xC(e) {
  return URL.canParse(e);
}
function Lc(e) {
  try {
    return decodeURIComponent(e);
  } catch {
    return e;
  }
}
function bC(e) {
  if (!e)
    return It.BLANK_URL;
  var t, r = Lc(e.trim());
  do
    r = yC(r).replace(It.htmlCtrlEntityRegex, "").replace(It.ctrlCharactersRegex, "").replace(It.whitespaceEscapeCharsRegex, "").trim(), r = Lc(r), t = r.match(It.ctrlCharactersRegex) || r.match(It.htmlEntitiesRegex) || r.match(It.htmlCtrlEntityRegex) || r.match(It.whitespaceEscapeCharsRegex);
  while (t && t.length > 0);
  var i = r;
  if (!i)
    return It.BLANK_URL;
  if (mC(i))
    return i;
  var n = i.trimStart(), a = n.match(It.urlSchemeRegex);
  if (!a)
    return i;
  var o = a[0].toLowerCase().trim();
  if (It.invalidProtocolRegex.test(o))
    return It.BLANK_URL;
  var s = n.replace(/\\/g, "/");
  if (o === "mailto:" || o.includes("://"))
    return s;
  if (o === "http:" || o === "https:") {
    if (!xC(s))
      return It.BLANK_URL;
    var l = new URL(s);
    return l.protocol = l.protocol.toLowerCase(), l.hostname = l.hostname.toLowerCase(), l.toString();
  }
  return s;
}
vp = Ko.sanitizeUrl = bC;
var Sp = typeof global == "object" && global && global.Object === Object && global, CC = typeof self == "object" && self && self.Object === Object && self, Te = Sp || CC || Function("return this")(), aa = Te.Symbol, Tp = Object.prototype, _C = Tp.hasOwnProperty, wC = Tp.toString, gi = aa ? aa.toStringTag : void 0;
function kC(e) {
  var t = _C.call(e, gi), r = e[gi];
  try {
    e[gi] = void 0;
    var i = !0;
  } catch {
  }
  var n = wC.call(e);
  return i && (t ? e[gi] = r : delete e[gi]), n;
}
var vC = Object.prototype, SC = vC.toString;
function TC(e) {
  return SC.call(e);
}
var BC = "[object Null]", AC = "[object Undefined]", Mc = aa ? aa.toStringTag : void 0;
function ii(e) {
  return e == null ? e === void 0 ? AC : BC : Mc && Mc in Object(e) ? kC(e) : TC(e);
}
function br(e) {
  var t = typeof e;
  return e != null && (t == "object" || t == "function");
}
var LC = "[object AsyncFunction]", MC = "[object Function]", $C = "[object GeneratorFunction]", EC = "[object Proxy]";
function Qo(e) {
  if (!br(e))
    return !1;
  var t = ii(e);
  return t == MC || t == $C || t == LC || t == EC;
}
var fs = Te["__core-js_shared__"], $c = function() {
  var e = /[^.]+$/.exec(fs && fs.keys && fs.keys.IE_PROTO || "");
  return e ? "Symbol(src)_1." + e : "";
}();
function FC(e) {
  return !!$c && $c in e;
}
var DC = Function.prototype, OC = DC.toString;
function Cr(e) {
  if (e != null) {
    try {
      return OC.call(e);
    } catch {
    }
    try {
      return e + "";
    } catch {
    }
  }
  return "";
}
var RC = /[\\^$.*+?()[\]{}|]/g, IC = /^\[object .+?Constructor\]$/, PC = Function.prototype, NC = Object.prototype, zC = PC.toString, WC = NC.hasOwnProperty, qC = RegExp(
  "^" + zC.call(WC).replace(RC, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
);
function HC(e) {
  if (!br(e) || FC(e))
    return !1;
  var t = Qo(e) ? qC : IC;
  return t.test(Cr(e));
}
function jC(e, t) {
  return e == null ? void 0 : e[t];
}
function _r(e, t) {
  var r = jC(e, t);
  return HC(r) ? r : void 0;
}
var Hi = _r(Object, "create");
function YC() {
  this.__data__ = Hi ? Hi(null) : {}, this.size = 0;
}
function UC(e) {
  var t = this.has(e) && delete this.__data__[e];
  return this.size -= t ? 1 : 0, t;
}
var GC = "__lodash_hash_undefined__", XC = Object.prototype, VC = XC.hasOwnProperty;
function ZC(e) {
  var t = this.__data__;
  if (Hi) {
    var r = t[e];
    return r === GC ? void 0 : r;
  }
  return VC.call(t, e) ? t[e] : void 0;
}
var KC = Object.prototype, QC = KC.hasOwnProperty;
function JC(e) {
  var t = this.__data__;
  return Hi ? t[e] !== void 0 : QC.call(t, e);
}
var t_ = "__lodash_hash_undefined__";
function e_(e, t) {
  var r = this.__data__;
  return this.size += this.has(e) ? 0 : 1, r[e] = Hi && t === void 0 ? t_ : t, this;
}
function mr(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
mr.prototype.clear = YC;
mr.prototype.delete = UC;
mr.prototype.get = ZC;
mr.prototype.has = JC;
mr.prototype.set = e_;
function r_() {
  this.__data__ = [], this.size = 0;
}
function $a(e, t) {
  return e === t || e !== e && t !== t;
}
function Ea(e, t) {
  for (var r = e.length; r--; )
    if ($a(e[r][0], t))
      return r;
  return -1;
}
var i_ = Array.prototype, n_ = i_.splice;
function a_(e) {
  var t = this.__data__, r = Ea(t, e);
  if (r < 0)
    return !1;
  var i = t.length - 1;
  return r == i ? t.pop() : n_.call(t, r, 1), --this.size, !0;
}
function s_(e) {
  var t = this.__data__, r = Ea(t, e);
  return r < 0 ? void 0 : t[r][1];
}
function o_(e) {
  return Ea(this.__data__, e) > -1;
}
function l_(e, t) {
  var r = this.__data__, i = Ea(r, e);
  return i < 0 ? (++this.size, r.push([e, t])) : r[i][1] = t, this;
}
function Ne(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
Ne.prototype.clear = r_;
Ne.prototype.delete = a_;
Ne.prototype.get = s_;
Ne.prototype.has = o_;
Ne.prototype.set = l_;
var ji = _r(Te, "Map");
function c_() {
  this.size = 0, this.__data__ = {
    hash: new mr(),
    map: new (ji || Ne)(),
    string: new mr()
  };
}
function h_(e) {
  var t = typeof e;
  return t == "string" || t == "number" || t == "symbol" || t == "boolean" ? e !== "__proto__" : e === null;
}
function Fa(e, t) {
  var r = e.__data__;
  return h_(t) ? r[typeof t == "string" ? "string" : "hash"] : r.map;
}
function u_(e) {
  var t = Fa(this, e).delete(e);
  return this.size -= t ? 1 : 0, t;
}
function f_(e) {
  return Fa(this, e).get(e);
}
function p_(e) {
  return Fa(this, e).has(e);
}
function d_(e, t) {
  var r = Fa(this, e), i = r.size;
  return r.set(e, t), this.size += r.size == i ? 0 : 1, this;
}
function Ve(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
Ve.prototype.clear = c_;
Ve.prototype.delete = u_;
Ve.prototype.get = f_;
Ve.prototype.has = p_;
Ve.prototype.set = d_;
var g_ = "Expected a function";
function Ji(e, t) {
  if (typeof e != "function" || t != null && typeof t != "function")
    throw new TypeError(g_);
  var r = function() {
    var i = arguments, n = t ? t.apply(this, i) : i[0], a = r.cache;
    if (a.has(n))
      return a.get(n);
    var o = e.apply(this, i);
    return r.cache = a.set(n, o) || a, o;
  };
  return r.cache = new (Ji.Cache || Ve)(), r;
}
Ji.Cache = Ve;
function m_() {
  this.__data__ = new Ne(), this.size = 0;
}
function y_(e) {
  var t = this.__data__, r = t.delete(e);
  return this.size = t.size, r;
}
function x_(e) {
  return this.__data__.get(e);
}
function b_(e) {
  return this.__data__.has(e);
}
var C_ = 200;
function __(e, t) {
  var r = this.__data__;
  if (r instanceof Ne) {
    var i = r.__data__;
    if (!ji || i.length < C_ - 1)
      return i.push([e, t]), this.size = ++r.size, this;
    r = this.__data__ = new Ve(i);
  }
  return r.set(e, t), this.size = r.size, this;
}
function ni(e) {
  var t = this.__data__ = new Ne(e);
  this.size = t.size;
}
ni.prototype.clear = m_;
ni.prototype.delete = y_;
ni.prototype.get = x_;
ni.prototype.has = b_;
ni.prototype.set = __;
var sa = function() {
  try {
    var e = _r(Object, "defineProperty");
    return e({}, "", {}), e;
  } catch {
  }
}();
function Jo(e, t, r) {
  t == "__proto__" && sa ? sa(e, t, {
    configurable: !0,
    enumerable: !0,
    value: r,
    writable: !0
  }) : e[t] = r;
}
function eo(e, t, r) {
  (r !== void 0 && !$a(e[t], r) || r === void 0 && !(t in e)) && Jo(e, t, r);
}
function w_(e) {
  return function(t, r, i) {
    for (var n = -1, a = Object(t), o = i(t), s = o.length; s--; ) {
      var l = o[++n];
      if (r(a[l], l, a) === !1)
        break;
    }
    return t;
  };
}
var k_ = w_(), Bp = typeof exports == "object" && exports && !exports.nodeType && exports, Ec = Bp && typeof module == "object" && module && !module.nodeType && module, v_ = Ec && Ec.exports === Bp, Fc = v_ ? Te.Buffer : void 0, Dc = Fc ? Fc.allocUnsafe : void 0;
function S_(e, t) {
  if (t)
    return e.slice();
  var r = e.length, i = Dc ? Dc(r) : new e.constructor(r);
  return e.copy(i), i;
}
var Oc = Te.Uint8Array;
function T_(e) {
  var t = new e.constructor(e.byteLength);
  return new Oc(t).set(new Oc(e)), t;
}
function B_(e, t) {
  var r = t ? T_(e.buffer) : e.buffer;
  return new e.constructor(r, e.byteOffset, e.length);
}
function A_(e, t) {
  var r = -1, i = e.length;
  for (t || (t = Array(i)); ++r < i; )
    t[r] = e[r];
  return t;
}
var Rc = Object.create, L_ = /* @__PURE__ */ function() {
  function e() {
  }
  return function(t) {
    if (!br(t))
      return {};
    if (Rc)
      return Rc(t);
    e.prototype = t;
    var r = new e();
    return e.prototype = void 0, r;
  };
}();
function Ap(e, t) {
  return function(r) {
    return e(t(r));
  };
}
var Lp = Ap(Object.getPrototypeOf, Object), M_ = Object.prototype;
function Da(e) {
  var t = e && e.constructor, r = typeof t == "function" && t.prototype || M_;
  return e === r;
}
function $_(e) {
  return typeof e.constructor == "function" && !Da(e) ? L_(Lp(e)) : {};
}
function tn(e) {
  return e != null && typeof e == "object";
}
var E_ = "[object Arguments]";
function Ic(e) {
  return tn(e) && ii(e) == E_;
}
var Mp = Object.prototype, F_ = Mp.hasOwnProperty, D_ = Mp.propertyIsEnumerable, oa = Ic(/* @__PURE__ */ function() {
  return arguments;
}()) ? Ic : function(e) {
  return tn(e) && F_.call(e, "callee") && !D_.call(e, "callee");
}, la = Array.isArray, O_ = 9007199254740991;
function $p(e) {
  return typeof e == "number" && e > -1 && e % 1 == 0 && e <= O_;
}
function Oa(e) {
  return e != null && $p(e.length) && !Qo(e);
}
function R_(e) {
  return tn(e) && Oa(e);
}
function I_() {
  return !1;
}
var Ep = typeof exports == "object" && exports && !exports.nodeType && exports, Pc = Ep && typeof module == "object" && module && !module.nodeType && module, P_ = Pc && Pc.exports === Ep, Nc = P_ ? Te.Buffer : void 0, N_ = Nc ? Nc.isBuffer : void 0, tl = N_ || I_, z_ = "[object Object]", W_ = Function.prototype, q_ = Object.prototype, Fp = W_.toString, H_ = q_.hasOwnProperty, j_ = Fp.call(Object);
function Y_(e) {
  if (!tn(e) || ii(e) != z_)
    return !1;
  var t = Lp(e);
  if (t === null)
    return !0;
  var r = H_.call(t, "constructor") && t.constructor;
  return typeof r == "function" && r instanceof r && Fp.call(r) == j_;
}
var U_ = "[object Arguments]", G_ = "[object Array]", X_ = "[object Boolean]", V_ = "[object Date]", Z_ = "[object Error]", K_ = "[object Function]", Q_ = "[object Map]", J_ = "[object Number]", tw = "[object Object]", ew = "[object RegExp]", rw = "[object Set]", iw = "[object String]", nw = "[object WeakMap]", aw = "[object ArrayBuffer]", sw = "[object DataView]", ow = "[object Float32Array]", lw = "[object Float64Array]", cw = "[object Int8Array]", hw = "[object Int16Array]", uw = "[object Int32Array]", fw = "[object Uint8Array]", pw = "[object Uint8ClampedArray]", dw = "[object Uint16Array]", gw = "[object Uint32Array]", bt = {};
bt[ow] = bt[lw] = bt[cw] = bt[hw] = bt[uw] = bt[fw] = bt[pw] = bt[dw] = bt[gw] = !0;
bt[U_] = bt[G_] = bt[aw] = bt[X_] = bt[sw] = bt[V_] = bt[Z_] = bt[K_] = bt[Q_] = bt[J_] = bt[tw] = bt[ew] = bt[rw] = bt[iw] = bt[nw] = !1;
function mw(e) {
  return tn(e) && $p(e.length) && !!bt[ii(e)];
}
function yw(e) {
  return function(t) {
    return e(t);
  };
}
var Dp = typeof exports == "object" && exports && !exports.nodeType && exports, Fi = Dp && typeof module == "object" && module && !module.nodeType && module, xw = Fi && Fi.exports === Dp, ps = xw && Sp.process, zc = function() {
  try {
    var e = Fi && Fi.require && Fi.require("util").types;
    return e || ps && ps.binding && ps.binding("util");
  } catch {
  }
}(), Wc = zc && zc.isTypedArray, el = Wc ? yw(Wc) : mw;
function ro(e, t) {
  if (!(t === "constructor" && typeof e[t] == "function") && t != "__proto__")
    return e[t];
}
var bw = Object.prototype, Cw = bw.hasOwnProperty;
function _w(e, t, r) {
  var i = e[t];
  (!(Cw.call(e, t) && $a(i, r)) || r === void 0 && !(t in e)) && Jo(e, t, r);
}
function ww(e, t, r, i) {
  var n = !r;
  r || (r = {});
  for (var a = -1, o = t.length; ++a < o; ) {
    var s = t[a], l = void 0;
    l === void 0 && (l = e[s]), n ? Jo(r, s, l) : _w(r, s, l);
  }
  return r;
}
function kw(e, t) {
  for (var r = -1, i = Array(e); ++r < e; )
    i[r] = t(r);
  return i;
}
var vw = 9007199254740991, Sw = /^(?:0|[1-9]\d*)$/;
function Op(e, t) {
  var r = typeof e;
  return t = t ?? vw, !!t && (r == "number" || r != "symbol" && Sw.test(e)) && e > -1 && e % 1 == 0 && e < t;
}
var Tw = Object.prototype, Bw = Tw.hasOwnProperty;
function Aw(e, t) {
  var r = la(e), i = !r && oa(e), n = !r && !i && tl(e), a = !r && !i && !n && el(e), o = r || i || n || a, s = o ? kw(e.length, String) : [], l = s.length;
  for (var c in e)
    (t || Bw.call(e, c)) && !(o && // Safari 9 has enumerable `arguments.length` in strict mode.
    (c == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
    n && (c == "offset" || c == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
    a && (c == "buffer" || c == "byteLength" || c == "byteOffset") || // Skip index properties.
    Op(c, l))) && s.push(c);
  return s;
}
function Lw(e) {
  var t = [];
  if (e != null)
    for (var r in Object(e))
      t.push(r);
  return t;
}
var Mw = Object.prototype, $w = Mw.hasOwnProperty;
function Ew(e) {
  if (!br(e))
    return Lw(e);
  var t = Da(e), r = [];
  for (var i in e)
    i == "constructor" && (t || !$w.call(e, i)) || r.push(i);
  return r;
}
function Rp(e) {
  return Oa(e) ? Aw(e, !0) : Ew(e);
}
function Fw(e) {
  return ww(e, Rp(e));
}
function Dw(e, t, r, i, n, a, o) {
  var s = ro(e, r), l = ro(t, r), c = o.get(l);
  if (c) {
    eo(e, r, c);
    return;
  }
  var h = a ? a(s, l, r + "", e, t, o) : void 0, u = h === void 0;
  if (u) {
    var f = la(l), p = !f && tl(l), g = !f && !p && el(l);
    h = l, f || p || g ? la(s) ? h = s : R_(s) ? h = A_(s) : p ? (u = !1, h = S_(l, !0)) : g ? (u = !1, h = B_(l, !0)) : h = [] : Y_(l) || oa(l) ? (h = s, oa(s) ? h = Fw(s) : (!br(s) || Qo(s)) && (h = $_(l))) : u = !1;
  }
  u && (o.set(l, h), n(h, l, i, a, o), o.delete(l)), eo(e, r, h);
}
function Ip(e, t, r, i, n) {
  e !== t && k_(t, function(a, o) {
    if (n || (n = new ni()), br(a))
      Dw(e, t, o, r, Ip, i, n);
    else {
      var s = i ? i(ro(e, o), a, o + "", e, t, n) : void 0;
      s === void 0 && (s = a), eo(e, o, s);
    }
  }, Rp);
}
function Pp(e) {
  return e;
}
function Ow(e, t, r) {
  switch (r.length) {
    case 0:
      return e.call(t);
    case 1:
      return e.call(t, r[0]);
    case 2:
      return e.call(t, r[0], r[1]);
    case 3:
      return e.call(t, r[0], r[1], r[2]);
  }
  return e.apply(t, r);
}
var qc = Math.max;
function Rw(e, t, r) {
  return t = qc(t === void 0 ? e.length - 1 : t, 0), function() {
    for (var i = arguments, n = -1, a = qc(i.length - t, 0), o = Array(a); ++n < a; )
      o[n] = i[t + n];
    n = -1;
    for (var s = Array(t + 1); ++n < t; )
      s[n] = i[n];
    return s[t] = r(o), Ow(e, this, s);
  };
}
function Iw(e) {
  return function() {
    return e;
  };
}
var Pw = sa ? function(e, t) {
  return sa(e, "toString", {
    configurable: !0,
    enumerable: !1,
    value: Iw(t),
    writable: !0
  });
} : Pp, Nw = 800, zw = 16, Ww = Date.now;
function qw(e) {
  var t = 0, r = 0;
  return function() {
    var i = Ww(), n = zw - (i - r);
    if (r = i, n > 0) {
      if (++t >= Nw)
        return arguments[0];
    } else
      t = 0;
    return e.apply(void 0, arguments);
  };
}
var Hw = qw(Pw);
function jw(e, t) {
  return Hw(Rw(e, t, Pp), e + "");
}
function Yw(e, t, r) {
  if (!br(r))
    return !1;
  var i = typeof t;
  return (i == "number" ? Oa(r) && Op(t, r.length) : i == "string" && t in r) ? $a(r[t], e) : !1;
}
function Uw(e) {
  return jw(function(t, r) {
    var i = -1, n = r.length, a = n > 1 ? r[n - 1] : void 0, o = n > 2 ? r[2] : void 0;
    for (a = e.length > 3 && typeof a == "function" ? (n--, a) : void 0, o && Yw(r[0], r[1], o) && (a = n < 3 ? void 0 : a, n = 1), t = Object(t); ++i < n; ) {
      var s = r[i];
      s && e(t, s, i, a);
    }
    return t;
  });
}
var Gw = Uw(function(e, t, r) {
  Ip(e, t, r);
}), Xw = "​", Vw = {
  curveBasis: Mn,
  curveBasisClosed: Z1,
  curveBasisOpen: K1,
  curveBumpX: _u,
  curveBumpY: wu,
  curveBundle: Q1,
  curveCardinalClosed: J1,
  curveCardinalOpen: t2,
  curveCardinal: Tu,
  curveCatmullRomClosed: e2,
  curveCatmullRomOpen: r2,
  curveCatmullRom: Au,
  curveLinear: Vn,
  curveLinearClosed: i2,
  curveMonotoneX: Du,
  curveMonotoneY: Ou,
  curveNatural: Iu,
  curveStep: Pu,
  curveStepAfter: zu,
  curveStepBefore: Nu
}, Zw = /\s*(?:(\w+)(?=:):|(\w+))\s*(?:(\w+)|((?:(?!}%{2}).|\r?\n)*))?\s*(?:}%{2})?/gi, Kw = /* @__PURE__ */ d(function(e, t) {
  const r = Np(e, /(?:init\b)|(?:initialize\b)/);
  let i = {};
  if (Array.isArray(r)) {
    const o = r.map((s) => s.args);
    Pn(o), i = Bt(i, [...o]);
  } else
    i = r.args;
  if (!i)
    return;
  let n = vo(e, t);
  const a = "config";
  return i[a] !== void 0 && (n === "flowchart-v2" && (n = "flowchart"), i[n] = i[a], delete i[a]), i;
}, "detectInit"), Np = /* @__PURE__ */ d(function(e, t = null) {
  var r, i;
  try {
    const n = new RegExp(
      `[%]{2}(?![{]${Zw.source})(?=[}][%]{2}).*
`,
      "ig"
    );
    e = e.trim().replace(n, "").replace(/'/gm, '"'), F.debug(
      `Detecting diagram directive${t !== null ? " type:" + t : ""} based on the text:${e}`
    );
    let a;
    const o = [];
    for (; (a = $i.exec(e)) !== null; )
      if (a.index === $i.lastIndex && $i.lastIndex++, a && !t || t && ((r = a[1]) != null && r.match(t)) || t && ((i = a[2]) != null && i.match(t))) {
        const s = a[1] ? a[1] : a[2], l = a[3] ? a[3].trim() : a[4] ? JSON.parse(a[4].trim()) : null;
        o.push({ type: s, args: l });
      }
    return o.length === 0 ? { type: e, args: null } : o.length === 1 ? o[0] : o;
  } catch (n) {
    return F.error(
      `ERROR: ${n.message} - Unable to parse directive type: '${t}' based on the text: '${e}'`
    ), { type: void 0, args: null };
  }
}, "detectDirective"), Qw = /* @__PURE__ */ d(function(e) {
  return e.replace($i, "");
}, "removeDirectives"), Jw = /* @__PURE__ */ d(function(e, t) {
  for (const [r, i] of t.entries())
    if (i.match(e))
      return r;
  return -1;
}, "isSubstringInArray");
function rl(e, t) {
  if (!e)
    return t;
  const r = `curve${e.charAt(0).toUpperCase() + e.slice(1)}`;
  return Vw[r] ?? t;
}
d(rl, "interpolateToCurve");
function zp(e, t) {
  const r = e.trim();
  if (r)
    return t.securityLevel !== "loose" ? vp(r) : r;
}
d(zp, "formatUrl");
var tk = /* @__PURE__ */ d((e, ...t) => {
  const r = e.split("."), i = r.length - 1, n = r[i];
  let a = window;
  for (let o = 0; o < i; o++)
    if (a = a[r[o]], !a) {
      F.error(`Function name: ${e} not found in window`);
      return;
    }
  a[n](...t);
}, "runFunc");
function il(e, t) {
  return !e || !t ? 0 : Math.sqrt(Math.pow(t.x - e.x, 2) + Math.pow(t.y - e.y, 2));
}
d(il, "distance");
function Wp(e) {
  let t, r = 0;
  e.forEach((n) => {
    r += il(n, t), t = n;
  });
  const i = r / 2;
  return nl(e, i);
}
d(Wp, "traverseEdge");
function qp(e) {
  return e.length === 1 ? e[0] : Wp(e);
}
d(qp, "calcLabelPosition");
var Hc = /* @__PURE__ */ d((e, t = 2) => {
  const r = Math.pow(10, t);
  return Math.round(e * r) / r;
}, "roundNumber"), nl = /* @__PURE__ */ d((e, t) => {
  let r, i = t;
  for (const n of e) {
    if (r) {
      const a = il(n, r);
      if (a === 0)
        return r;
      if (a < i)
        i -= a;
      else {
        const o = i / a;
        if (o <= 0)
          return r;
        if (o >= 1)
          return { x: n.x, y: n.y };
        if (o > 0 && o < 1)
          return {
            x: Hc((1 - o) * r.x + o * n.x, 5),
            y: Hc((1 - o) * r.y + o * n.y, 5)
          };
      }
    }
    r = n;
  }
  throw new Error("Could not find a suitable point for the given distance");
}, "calculatePoint"), ek = /* @__PURE__ */ d((e, t, r) => {
  F.info(`our points ${JSON.stringify(t)}`), t[0] !== r && (t = t.reverse());
  const n = nl(t, 25), a = e ? 10 : 5, o = Math.atan2(t[0].y - n.y, t[0].x - n.x), s = { x: 0, y: 0 };
  return s.x = Math.sin(o) * a + (t[0].x + n.x) / 2, s.y = -Math.cos(o) * a + (t[0].y + n.y) / 2, s;
}, "calcCardinalityPosition");
function Hp(e, t, r) {
  const i = structuredClone(r);
  F.info("our points", i), t !== "start_left" && t !== "start_right" && i.reverse();
  const n = 25 + e, a = nl(i, n), o = 10 + e * 0.5, s = Math.atan2(i[0].y - a.y, i[0].x - a.x), l = { x: 0, y: 0 };
  return t === "start_left" ? (l.x = Math.sin(s + Math.PI) * o + (i[0].x + a.x) / 2, l.y = -Math.cos(s + Math.PI) * o + (i[0].y + a.y) / 2) : t === "end_right" ? (l.x = Math.sin(s - Math.PI) * o + (i[0].x + a.x) / 2 - 5, l.y = -Math.cos(s - Math.PI) * o + (i[0].y + a.y) / 2 - 5) : t === "end_left" ? (l.x = Math.sin(s) * o + (i[0].x + a.x) / 2 - 5, l.y = -Math.cos(s) * o + (i[0].y + a.y) / 2 - 5) : (l.x = Math.sin(s) * o + (i[0].x + a.x) / 2, l.y = -Math.cos(s) * o + (i[0].y + a.y) / 2), l;
}
d(Hp, "calcTerminalLabelPosition");
function jp(e) {
  let t = "", r = "";
  for (const i of e)
    i !== void 0 && (i.startsWith("color:") || i.startsWith("text-align:") ? r = r + i + ";" : t = t + i + ";");
  return { style: t, labelStyle: r };
}
d(jp, "getStylesFromArray");
var jc = 0, rk = /* @__PURE__ */ d(() => (jc++, "id-" + Math.random().toString(36).substr(2, 12) + "-" + jc), "generateId");
function Yp(e) {
  let t = "";
  const r = "0123456789abcdef", i = r.length;
  for (let n = 0; n < e; n++)
    t += r.charAt(Math.floor(Math.random() * i));
  return t;
}
d(Yp, "makeRandomHex");
var ik = /* @__PURE__ */ d((e) => Yp(e.length), "random"), nk = /* @__PURE__ */ d(function() {
  return {
    x: 0,
    y: 0,
    fill: void 0,
    anchor: "start",
    style: "#666",
    width: 100,
    height: 100,
    textMargin: 0,
    rx: 0,
    ry: 0,
    valign: void 0,
    text: ""
  };
}, "getTextObj"), ak = /* @__PURE__ */ d(function(e, t) {
  const r = t.text.replace(ei.lineBreakRegex, " "), [, i] = Ra(t.fontSize), n = e.append("text");
  n.attr("x", t.x), n.attr("y", t.y), n.style("text-anchor", t.anchor), n.style("font-family", t.fontFamily), n.style("font-size", i), n.style("font-weight", t.fontWeight), n.attr("fill", t.fill), t.class !== void 0 && n.attr("class", t.class);
  const a = n.append("tspan");
  return a.attr("x", t.x + t.textMargin * 2), a.attr("fill", t.fill), a.text(r), n;
}, "drawSimpleText"), sk = Ji(
  (e, t, r) => {
    if (!e || (r = Object.assign(
      { fontSize: 12, fontWeight: 400, fontFamily: "Arial", joinWith: "<br/>" },
      r
    ), ei.lineBreakRegex.test(e)))
      return e;
    const i = e.split(" ").filter(Boolean), n = [];
    let a = "";
    return i.forEach((o, s) => {
      const l = Pe(`${o} `, r), c = Pe(a, r);
      if (l > t) {
        const { hyphenatedStrings: f, remainingWord: p } = ok(o, t, "-", r);
        n.push(a, ...f), a = p;
      } else c + l >= t ? (n.push(a), a = o) : a = [a, o].filter(Boolean).join(" ");
      s + 1 === i.length && n.push(a);
    }), n.filter((o) => o !== "").join(r.joinWith);
  },
  (e, t, r) => `${e}${t}${r.fontSize}${r.fontWeight}${r.fontFamily}${r.joinWith}`
), ok = Ji(
  (e, t, r = "-", i) => {
    i = Object.assign(
      { fontSize: 12, fontWeight: 400, fontFamily: "Arial", margin: 0 },
      i
    );
    const n = [...e], a = [];
    let o = "";
    return n.forEach((s, l) => {
      const c = `${o}${s}`;
      if (Pe(c, i) >= t) {
        const u = l + 1, f = n.length === u, p = `${c}${r}`;
        a.push(f ? c : p), o = "";
      } else
        o = c;
    }), { hyphenatedStrings: a, remainingWord: o };
  },
  (e, t, r = "-", i) => `${e}${t}${r}${i.fontSize}${i.fontWeight}${i.fontFamily}`
);
function Up(e, t) {
  return al(e, t).height;
}
d(Up, "calculateTextHeight");
function Pe(e, t) {
  return al(e, t).width;
}
d(Pe, "calculateTextWidth");
var al = Ji(
  (e, t) => {
    const { fontSize: r = 12, fontFamily: i = "Arial", fontWeight: n = 400 } = t;
    if (!e)
      return { width: 0, height: 0 };
    const [, a] = Ra(r), o = ["sans-serif", i], s = e.split(ei.lineBreakRegex), l = [], c = ht("body");
    if (!c.remove)
      return { width: 0, height: 0, lineHeight: 0 };
    const h = c.append("svg");
    for (const f of o) {
      let p = 0;
      const g = { width: 0, height: 0, lineHeight: 0 };
      for (const m of s) {
        const y = nk();
        y.text = m || Xw;
        const x = ak(h, y).style("font-size", a).style("font-weight", n).style("font-family", f), b = (x._groups || x)[0][0].getBBox();
        if (b.width === 0 && b.height === 0)
          throw new Error("svg element not in render tree");
        g.width = Math.round(Math.max(g.width, b.width)), p = Math.round(b.height), g.height += p, g.lineHeight = Math.round(Math.max(g.lineHeight, p));
      }
      l.push(g);
    }
    h.remove();
    const u = isNaN(l[1].height) || isNaN(l[1].width) || isNaN(l[1].lineHeight) || l[0].height > l[1].height && l[0].width > l[1].width && l[0].lineHeight > l[1].lineHeight ? 0 : 1;
    return l[u];
  },
  (e, t) => `${e}${t.fontSize}${t.fontWeight}${t.fontFamily}`
), Yr, lk = (Yr = class {
  constructor(t = !1, r) {
    this.count = 0, this.count = r ? r.length : 0, this.next = t ? () => this.count++ : () => Date.now();
  }
}, d(Yr, "InitIDGenerator"), Yr), mn, ck = /* @__PURE__ */ d(function(e) {
  return mn = mn || document.createElement("div"), e = escape(e).replace(/%26/g, "&").replace(/%23/g, "#").replace(/%3B/g, ";"), mn.innerHTML = e, unescape(mn.textContent);
}, "entityDecode");
function sl(e) {
  return "str" in e;
}
d(sl, "isDetailedError");
var hk = /* @__PURE__ */ d((e, t, r, i) => {
  var a;
  if (!i)
    return;
  const n = (a = e.node()) == null ? void 0 : a.getBBox();
  n && e.append("text").text(i).attr("text-anchor", "middle").attr("x", n.x + n.width / 2).attr("y", -r).attr("class", t);
}, "insertTitle"), Ra = /* @__PURE__ */ d((e) => {
  if (typeof e == "number")
    return [e, e + "px"];
  const t = parseInt(e ?? "", 10);
  return Number.isNaN(t) ? [void 0, void 0] : e === String(t) ? [t, e + "px"] : [t, e];
}, "parseFontSize");
function ol(e, t) {
  return Gw({}, e, t);
}
d(ol, "cleanAndMerge");
var pe = {
  assignWithDepth: Bt,
  wrapLabel: sk,
  calculateTextHeight: Up,
  calculateTextWidth: Pe,
  calculateTextDimensions: al,
  cleanAndMerge: ol,
  detectInit: Kw,
  detectDirective: Np,
  isSubstringInArray: Jw,
  interpolateToCurve: rl,
  calcLabelPosition: qp,
  calcCardinalityPosition: ek,
  calcTerminalLabelPosition: Hp,
  formatUrl: zp,
  getStylesFromArray: jp,
  generateId: rk,
  random: ik,
  runFunc: tk,
  entityDecode: ck,
  insertTitle: hk,
  isLabelCoordinateInPath: Gp,
  parseFontSize: Ra,
  InitIDGenerator: lk
}, uk = /* @__PURE__ */ d(function(e) {
  let t = e;
  return t = t.replace(/style.*:\S*#.*;/g, function(r) {
    return r.substring(0, r.length - 1);
  }), t = t.replace(/classDef.*:\S*#.*;/g, function(r) {
    return r.substring(0, r.length - 1);
  }), t = t.replace(/#\w+;/g, function(r) {
    const i = r.substring(1, r.length - 1);
    return /^\+?\d+$/.test(i) ? "ﬂ°°" + i + "¶ß" : "ﬂ°" + i + "¶ß";
  }), t;
}, "encodeEntities"), wr = /* @__PURE__ */ d(function(e) {
  return e.replace(/ﬂ°°/g, "&#").replace(/ﬂ°/g, "&").replace(/¶ß/g, ";");
}, "decodeEntities"), uL = /* @__PURE__ */ d((e, t, {
  counter: r = 0,
  prefix: i,
  suffix: n
}, a) => a || `${i ? `${i}_` : ""}${e}_${t}_${r}${n ? `_${n}` : ""}`, "getEdgeId");
function Wt(e) {
  return e ?? null;
}
d(Wt, "handleUndefinedAttr");
function Gp(e, t) {
  const r = Math.round(e.x), i = Math.round(e.y), n = t.replace(
    /(\d+\.\d+)/g,
    (a) => Math.round(parseFloat(a)).toString()
  );
  return n.includes(r.toString()) || n.includes(i.toString());
}
d(Gp, "isLabelCoordinateInPath");
const fk = Object.freeze({
  left: 0,
  top: 0,
  width: 16,
  height: 16
}), ca = Object.freeze({
  rotate: 0,
  vFlip: !1,
  hFlip: !1
}), Xp = Object.freeze({
  ...fk,
  ...ca
}), pk = Object.freeze({
  ...Xp,
  body: "",
  hidden: !1
}), dk = Object.freeze({
  width: null,
  height: null
}), gk = Object.freeze({
  ...dk,
  ...ca
}), mk = (e, t, r, i = "") => {
  const n = e.split(":");
  if (e.slice(0, 1) === "@") {
    if (n.length < 2 || n.length > 3) return null;
    i = n.shift().slice(1);
  }
  if (n.length > 3 || !n.length) return null;
  if (n.length > 1) {
    const s = n.pop(), l = n.pop(), c = {
      provider: n.length > 0 ? n[0] : i,
      prefix: l,
      name: s
    };
    return ds(c) ? c : null;
  }
  const a = n[0], o = a.split("-");
  if (o.length > 1) {
    const s = {
      provider: i,
      prefix: o.shift(),
      name: o.join("-")
    };
    return ds(s) ? s : null;
  }
  if (r && i === "") {
    const s = {
      provider: i,
      prefix: "",
      name: a
    };
    return ds(s, r) ? s : null;
  }
  return null;
}, ds = (e, t) => e ? !!((t && e.prefix === "" || e.prefix) && e.name) : !1;
function yk(e, t) {
  const r = {};
  !e.hFlip != !t.hFlip && (r.hFlip = !0), !e.vFlip != !t.vFlip && (r.vFlip = !0);
  const i = ((e.rotate || 0) + (t.rotate || 0)) % 4;
  return i && (r.rotate = i), r;
}
function Yc(e, t) {
  const r = yk(e, t);
  for (const i in pk) i in ca ? i in e && !(i in r) && (r[i] = ca[i]) : i in t ? r[i] = t[i] : i in e && (r[i] = e[i]);
  return r;
}
function xk(e, t) {
  const r = e.icons, i = e.aliases || /* @__PURE__ */ Object.create(null), n = /* @__PURE__ */ Object.create(null);
  function a(o) {
    if (r[o]) return n[o] = [];
    if (!(o in n)) {
      n[o] = null;
      const s = i[o] && i[o].parent, l = s && a(s);
      l && (n[o] = [s].concat(l));
    }
    return n[o];
  }
  return (t || Object.keys(r).concat(Object.keys(i))).forEach(a), n;
}
function Uc(e, t, r) {
  const i = e.icons, n = e.aliases || /* @__PURE__ */ Object.create(null);
  let a = {};
  function o(s) {
    a = Yc(i[s] || n[s], a);
  }
  return o(t), r.forEach(o), Yc(e, a);
}
function bk(e, t) {
  if (e.icons[t]) return Uc(e, t, []);
  const r = xk(e, [t])[t];
  return r ? Uc(e, t, r) : null;
}
const Ck = /(-?[0-9.]*[0-9]+[0-9.]*)/g, _k = /^-?[0-9.]*[0-9]+[0-9.]*$/g;
function Gc(e, t, r) {
  if (t === 1) return e;
  if (r = r || 100, typeof e == "number") return Math.ceil(e * t * r) / r;
  if (typeof e != "string") return e;
  const i = e.split(Ck);
  if (i === null || !i.length) return e;
  const n = [];
  let a = i.shift(), o = _k.test(a);
  for (; ; ) {
    if (o) {
      const s = parseFloat(a);
      isNaN(s) ? n.push(a) : n.push(Math.ceil(s * t * r) / r);
    } else n.push(a);
    if (a = i.shift(), a === void 0) return n.join("");
    o = !o;
  }
}
function wk(e, t = "defs") {
  let r = "";
  const i = e.indexOf("<" + t);
  for (; i >= 0; ) {
    const n = e.indexOf(">", i), a = e.indexOf("</" + t);
    if (n === -1 || a === -1) break;
    const o = e.indexOf(">", a);
    if (o === -1) break;
    r += e.slice(n + 1, a).trim(), e = e.slice(0, i).trim() + e.slice(o + 1);
  }
  return {
    defs: r,
    content: e
  };
}
function kk(e, t) {
  return e ? "<defs>" + e + "</defs>" + t : t;
}
function vk(e, t, r) {
  const i = wk(e);
  return kk(i.defs, t + i.content + r);
}
const Sk = (e) => e === "unset" || e === "undefined" || e === "none";
function Tk(e, t) {
  const r = {
    ...Xp,
    ...e
  }, i = {
    ...gk,
    ...t
  }, n = {
    left: r.left,
    top: r.top,
    width: r.width,
    height: r.height
  };
  let a = r.body;
  [r, i].forEach((m) => {
    const y = [], x = m.hFlip, b = m.vFlip;
    let _ = m.rotate;
    x ? b ? _ += 2 : (y.push("translate(" + (n.width + n.left).toString() + " " + (0 - n.top).toString() + ")"), y.push("scale(-1 1)"), n.top = n.left = 0) : b && (y.push("translate(" + (0 - n.left).toString() + " " + (n.height + n.top).toString() + ")"), y.push("scale(1 -1)"), n.top = n.left = 0);
    let v;
    switch (_ < 0 && (_ -= Math.floor(_ / 4) * 4), _ = _ % 4, _) {
      case 1:
        v = n.height / 2 + n.top, y.unshift("rotate(90 " + v.toString() + " " + v.toString() + ")");
        break;
      case 2:
        y.unshift("rotate(180 " + (n.width / 2 + n.left).toString() + " " + (n.height / 2 + n.top).toString() + ")");
        break;
      case 3:
        v = n.width / 2 + n.left, y.unshift("rotate(-90 " + v.toString() + " " + v.toString() + ")");
        break;
    }
    _ % 2 === 1 && (n.left !== n.top && (v = n.left, n.left = n.top, n.top = v), n.width !== n.height && (v = n.width, n.width = n.height, n.height = v)), y.length && (a = vk(a, '<g transform="' + y.join(" ") + '">', "</g>"));
  });
  const o = i.width, s = i.height, l = n.width, c = n.height;
  let h, u;
  o === null ? (u = s === null ? "1em" : s === "auto" ? c : s, h = Gc(u, l / c)) : (h = o === "auto" ? l : o, u = s === null ? Gc(h, c / l) : s === "auto" ? c : s);
  const f = {}, p = (m, y) => {
    Sk(y) || (f[m] = y.toString());
  };
  p("width", h), p("height", u);
  const g = [
    n.left,
    n.top,
    l,
    c
  ];
  return f.viewBox = g.join(" "), {
    attributes: f,
    viewBox: g,
    body: a
  };
}
const Bk = /\sid="(\S+)"/g, Ak = "IconifyId" + Date.now().toString(16) + (Math.random() * 16777216 | 0).toString(16);
let Lk = 0;
function Mk(e, t = Ak) {
  const r = [];
  let i;
  for (; i = Bk.exec(e); ) r.push(i[1]);
  if (!r.length) return e;
  const n = "suffix" + (Math.random() * 16777216 | Date.now()).toString(16);
  return r.forEach((a) => {
    const o = typeof t == "function" ? t(a) : t + (Lk++).toString(), s = a.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    e = e.replace(new RegExp('([#;"])(' + s + ')([")]|\\.[a-z])', "g"), "$1" + o + n + "$3");
  }), e = e.replace(new RegExp(n, "g"), ""), e;
}
function $k(e, t) {
  let r = e.indexOf("xlink:") === -1 ? "" : ' xmlns:xlink="http://www.w3.org/1999/xlink"';
  for (const i in t) r += " " + i + '="' + t[i] + '"';
  return '<svg xmlns="http://www.w3.org/2000/svg"' + r + ">" + e + "</svg>";
}
function ll() {
  return { async: !1, breaks: !1, extensions: null, gfm: !0, hooks: null, pedantic: !1, renderer: null, silent: !1, tokenizer: null, walkTokens: null };
}
var kr = ll();
function Vp(e) {
  kr = e;
}
var Di = { exec: () => null };
function ft(e, t = "") {
  let r = typeof e == "string" ? e : e.source, i = { replace: (n, a) => {
    let o = typeof a == "string" ? a : a.source;
    return o = o.replace(Ut.caret, "$1"), r = r.replace(n, o), i;
  }, getRegex: () => new RegExp(r, t) };
  return i;
}
var Ut = { codeRemoveIndent: /^(?: {1,4}| {0,3}\t)/gm, outputLinkReplace: /\\([\[\]])/g, indentCodeCompensation: /^(\s+)(?:```)/, beginningSpace: /^\s+/, endingHash: /#$/, startingSpaceChar: /^ /, endingSpaceChar: / $/, nonSpaceChar: /[^ ]/, newLineCharGlobal: /\n/g, tabCharGlobal: /\t/g, multipleSpaceGlobal: /\s+/g, blankLine: /^[ \t]*$/, doubleBlankLine: /\n[ \t]*\n[ \t]*$/, blockquoteStart: /^ {0,3}>/, blockquoteSetextReplace: /\n {0,3}((?:=+|-+) *)(?=\n|$)/g, blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm, listReplaceTabs: /^\t+/, listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g, listIsTask: /^\[[ xX]\] /, listReplaceTask: /^\[[ xX]\] +/, anyLine: /\n.*\n/, hrefBrackets: /^<(.*)>$/, tableDelimiter: /[:|]/, tableAlignChars: /^\||\| *$/g, tableRowBlankLine: /\n[ \t]*$/, tableAlignRight: /^ *-+: *$/, tableAlignCenter: /^ *:-+: *$/, tableAlignLeft: /^ *:-+ *$/, startATag: /^<a /i, endATag: /^<\/a>/i, startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i, endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i, startAngleBracket: /^</, endAngleBracket: />$/, pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/, unicodeAlphaNumeric: /[\p{L}\p{N}]/u, escapeTest: /[&<>"']/, escapeReplace: /[&<>"']/g, escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g, unescapeTest: /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig, caret: /(^|[^\[])\^/g, percentDecode: /%25/g, findPipe: /\|/g, splitPipe: / \|/, slashPipe: /\\\|/g, carriageReturn: /\r\n|\r/g, spaceLine: /^ +$/gm, notSpaceStart: /^\S*/, endingNewline: /\n$/, listItemRegex: (e) => new RegExp(`^( {0,3}${e})((?:[	 ][^\\n]*)?(?:\\n|$))`), nextBulletRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), hrRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), fencesBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}(?:\`\`\`|~~~)`), headingBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}#`), htmlBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}<(?:[a-z].*>|!--)`, "i") }, Ek = /^(?:[ \t]*(?:\n|$))+/, Fk = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/, Dk = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, en = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Ok = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, cl = /(?:[*+-]|\d{1,9}[.)])/, Zp = /^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/, Kp = ft(Zp).replace(/bull/g, cl).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/\|table/g, "").getRegex(), Rk = ft(Zp).replace(/bull/g, cl).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/table/g, / {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex(), hl = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Ik = /^[^\n]+/, ul = /(?!\s*\])(?:\\[\s\S]|[^\[\]\\])+/, Pk = ft(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label", ul).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Nk = ft(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, cl).getRegex(), Ia = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", fl = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, zk = ft("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))", "i").replace("comment", fl).replace("tag", Ia).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Qp = ft(hl).replace("hr", en).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Ia).getRegex(), Wk = ft(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Qp).getRegex(), pl = { blockquote: Wk, code: Fk, def: Pk, fences: Dk, heading: Ok, hr: en, html: zk, lheading: Kp, list: Nk, newline: Ek, paragraph: Qp, table: Di, text: Ik }, Xc = ft("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", en).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", "(?: {4}| {0,3}	)[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Ia).getRegex(), qk = { ...pl, lheading: Rk, table: Xc, paragraph: ft(hl).replace("hr", en).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Xc).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Ia).getRegex() }, Hk = { ...pl, html: ft(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", fl).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(), def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/, heading: /^(#{1,6})(.*)(?:\n+|$)/, fences: Di, lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/, paragraph: ft(hl).replace("hr", en).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Kp).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex() }, jk = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Yk = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, Jp = /^( {2,}|\\)\n(?!\s*$)/, Uk = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Pa = /[\p{P}\p{S}]/u, dl = /[\s\p{P}\p{S}]/u, td = /[^\s\p{P}\p{S}]/u, Gk = ft(/^((?![*_])punctSpace)/, "u").replace(/punctSpace/g, dl).getRegex(), ed = /(?!~)[\p{P}\p{S}]/u, Xk = /(?!~)[\s\p{P}\p{S}]/u, Vk = /(?:[^\s\p{P}\p{S}]|~)/u, Zk = ft(/link|code|html/, "g").replace("link", new RegExp("\\[(?:[^\\[\\]`]|(?<!`)(?<a>`+)[^`]+\\k<a>(?!`))*?\\]\\((?:\\\\[\\s\\S]|[^\\\\\\(\\)]|\\((?:\\\\[\\s\\S]|[^\\\\\\(\\)])*\\))*\\)")).replace("code", new RegExp("(?<!`)(?<b>`+)[^`]+\\k<b>(?!`)")).replace("html", /<(?! )[^<>]*?>/).getRegex(), rd = /^(?:\*+(?:((?!\*)punct)|[^\s*]))|^_+(?:((?!_)punct)|([^\s_]))/, Kk = ft(rd, "u").replace(/punct/g, Pa).getRegex(), Qk = ft(rd, "u").replace(/punct/g, ed).getRegex(), id = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)", Jk = ft(id, "gu").replace(/notPunctSpace/g, td).replace(/punctSpace/g, dl).replace(/punct/g, Pa).getRegex(), tv = ft(id, "gu").replace(/notPunctSpace/g, Vk).replace(/punctSpace/g, Xk).replace(/punct/g, ed).getRegex(), ev = ft("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)", "gu").replace(/notPunctSpace/g, td).replace(/punctSpace/g, dl).replace(/punct/g, Pa).getRegex(), rv = ft(/\\(punct)/, "gu").replace(/punct/g, Pa).getRegex(), iv = ft(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), nv = ft(fl).replace("(?:-->|$)", "-->").getRegex(), av = ft("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", nv).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), ha = /(?:\[(?:\\[\s\S]|[^\[\]\\])*\]|\\[\s\S]|`+[^`]*?`+(?!`)|[^\[\]\\`])*?/, sv = ft(/^!?\[(label)\]\(\s*(href)(?:(?:[ \t]*(?:\n[ \t]*)?)(title))?\s*\)/).replace("label", ha).replace("href", /<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), nd = ft(/^!?\[(label)\]\[(ref)\]/).replace("label", ha).replace("ref", ul).getRegex(), ad = ft(/^!?\[(ref)\](?:\[\])?/).replace("ref", ul).getRegex(), ov = ft("reflink|nolink(?!\\()", "g").replace("reflink", nd).replace("nolink", ad).getRegex(), Vc = /[hH][tT][tT][pP][sS]?|[fF][tT][pP]/, gl = { _backpedal: Di, anyPunctuation: rv, autolink: iv, blockSkip: Zk, br: Jp, code: Yk, del: Di, emStrongLDelim: Kk, emStrongRDelimAst: Jk, emStrongRDelimUnd: ev, escape: jk, link: sv, nolink: ad, punctuation: Gk, reflink: nd, reflinkSearch: ov, tag: av, text: Uk, url: Di }, lv = { ...gl, link: ft(/^!?\[(label)\]\((.*?)\)/).replace("label", ha).getRegex(), reflink: ft(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", ha).getRegex() }, io = { ...gl, emStrongRDelimAst: tv, emStrongLDelim: Qk, url: ft(/^((?:protocol):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/).replace("protocol", Vc).replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(), _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/, del: /^(~~?)(?=[^\s~])((?:\\[\s\S]|[^\\])*?(?:\\[\s\S]|[^\s~\\]))\1(?=[^~]|$)/, text: ft(/^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|protocol:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/).replace("protocol", Vc).getRegex() }, cv = { ...io, br: ft(Jp).replace("{2,}", "*").getRegex(), text: ft(io.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex() }, yn = { normal: pl, gfm: qk, pedantic: Hk }, mi = { normal: gl, gfm: io, breaks: cv, pedantic: lv }, hv = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }, Zc = (e) => hv[e];
function be(e, t) {
  if (t) {
    if (Ut.escapeTest.test(e)) return e.replace(Ut.escapeReplace, Zc);
  } else if (Ut.escapeTestNoEncode.test(e)) return e.replace(Ut.escapeReplaceNoEncode, Zc);
  return e;
}
function Kc(e) {
  try {
    e = encodeURI(e).replace(Ut.percentDecode, "%");
  } catch {
    return null;
  }
  return e;
}
function Qc(e, t) {
  var a;
  let r = e.replace(Ut.findPipe, (o, s, l) => {
    let c = !1, h = s;
    for (; --h >= 0 && l[h] === "\\"; ) c = !c;
    return c ? "|" : " |";
  }), i = r.split(Ut.splitPipe), n = 0;
  if (i[0].trim() || i.shift(), i.length > 0 && !((a = i.at(-1)) != null && a.trim()) && i.pop(), t) if (i.length > t) i.splice(t);
  else for (; i.length < t; ) i.push("");
  for (; n < i.length; n++) i[n] = i[n].trim().replace(Ut.slashPipe, "|");
  return i;
}
function yi(e, t, r) {
  let i = e.length;
  if (i === 0) return "";
  let n = 0;
  for (; n < i && e.charAt(i - n - 1) === t; )
    n++;
  return e.slice(0, i - n);
}
function uv(e, t) {
  if (e.indexOf(t[1]) === -1) return -1;
  let r = 0;
  for (let i = 0; i < e.length; i++) if (e[i] === "\\") i++;
  else if (e[i] === t[0]) r++;
  else if (e[i] === t[1] && (r--, r < 0)) return i;
  return r > 0 ? -2 : -1;
}
function Jc(e, t, r, i, n) {
  let a = t.href, o = t.title || null, s = e[1].replace(n.other.outputLinkReplace, "$1");
  i.state.inLink = !0;
  let l = { type: e[0].charAt(0) === "!" ? "image" : "link", raw: r, href: a, title: o, text: s, tokens: i.inlineTokens(s) };
  return i.state.inLink = !1, l;
}
function fv(e, t, r) {
  let i = e.match(r.other.indentCodeCompensation);
  if (i === null) return t;
  let n = i[1];
  return t.split(`
`).map((a) => {
    let o = a.match(r.other.beginningSpace);
    if (o === null) return a;
    let [s] = o;
    return s.length >= n.length ? a.slice(n.length) : a;
  }).join(`
`);
}
var ua = class {
  constructor(t) {
    mt(this, "options");
    mt(this, "rules");
    mt(this, "lexer");
    this.options = t || kr;
  }
  space(t) {
    let r = this.rules.block.newline.exec(t);
    if (r && r[0].length > 0) return { type: "space", raw: r[0] };
  }
  code(t) {
    let r = this.rules.block.code.exec(t);
    if (r) {
      let i = r[0].replace(this.rules.other.codeRemoveIndent, "");
      return { type: "code", raw: r[0], codeBlockStyle: "indented", text: this.options.pedantic ? i : yi(i, `
`) };
    }
  }
  fences(t) {
    let r = this.rules.block.fences.exec(t);
    if (r) {
      let i = r[0], n = fv(i, r[3] || "", this.rules);
      return { type: "code", raw: i, lang: r[2] ? r[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : r[2], text: n };
    }
  }
  heading(t) {
    let r = this.rules.block.heading.exec(t);
    if (r) {
      let i = r[2].trim();
      if (this.rules.other.endingHash.test(i)) {
        let n = yi(i, "#");
        (this.options.pedantic || !n || this.rules.other.endingSpaceChar.test(n)) && (i = n.trim());
      }
      return { type: "heading", raw: r[0], depth: r[1].length, text: i, tokens: this.lexer.inline(i) };
    }
  }
  hr(t) {
    let r = this.rules.block.hr.exec(t);
    if (r) return { type: "hr", raw: yi(r[0], `
`) };
  }
  blockquote(t) {
    let r = this.rules.block.blockquote.exec(t);
    if (r) {
      let i = yi(r[0], `
`).split(`
`), n = "", a = "", o = [];
      for (; i.length > 0; ) {
        let s = !1, l = [], c;
        for (c = 0; c < i.length; c++) if (this.rules.other.blockquoteStart.test(i[c])) l.push(i[c]), s = !0;
        else if (!s) l.push(i[c]);
        else break;
        i = i.slice(c);
        let h = l.join(`
`), u = h.replace(this.rules.other.blockquoteSetextReplace, `
    $1`).replace(this.rules.other.blockquoteSetextReplace2, "");
        n = n ? `${n}
${h}` : h, a = a ? `${a}
${u}` : u;
        let f = this.lexer.state.top;
        if (this.lexer.state.top = !0, this.lexer.blockTokens(u, o, !0), this.lexer.state.top = f, i.length === 0) break;
        let p = o.at(-1);
        if ((p == null ? void 0 : p.type) === "code") break;
        if ((p == null ? void 0 : p.type) === "blockquote") {
          let g = p, m = g.raw + `
` + i.join(`
`), y = this.blockquote(m);
          o[o.length - 1] = y, n = n.substring(0, n.length - g.raw.length) + y.raw, a = a.substring(0, a.length - g.text.length) + y.text;
          break;
        } else if ((p == null ? void 0 : p.type) === "list") {
          let g = p, m = g.raw + `
` + i.join(`
`), y = this.list(m);
          o[o.length - 1] = y, n = n.substring(0, n.length - p.raw.length) + y.raw, a = a.substring(0, a.length - g.raw.length) + y.raw, i = m.substring(o.at(-1).raw.length).split(`
`);
          continue;
        }
      }
      return { type: "blockquote", raw: n, tokens: o, text: a };
    }
  }
  list(t) {
    let r = this.rules.block.list.exec(t);
    if (r) {
      let i = r[1].trim(), n = i.length > 1, a = { type: "list", raw: "", ordered: n, start: n ? +i.slice(0, -1) : "", loose: !1, items: [] };
      i = n ? `\\d{1,9}\\${i.slice(-1)}` : `\\${i}`, this.options.pedantic && (i = n ? i : "[*+-]");
      let o = this.rules.other.listItemRegex(i), s = !1;
      for (; t; ) {
        let c = !1, h = "", u = "";
        if (!(r = o.exec(t)) || this.rules.block.hr.test(t)) break;
        h = r[0], t = t.substring(h.length);
        let f = r[2].split(`
`, 1)[0].replace(this.rules.other.listReplaceTabs, (b) => " ".repeat(3 * b.length)), p = t.split(`
`, 1)[0], g = !f.trim(), m = 0;
        if (this.options.pedantic ? (m = 2, u = f.trimStart()) : g ? m = r[1].length + 1 : (m = r[2].search(this.rules.other.nonSpaceChar), m = m > 4 ? 1 : m, u = f.slice(m), m += r[1].length), g && this.rules.other.blankLine.test(p) && (h += p + `
`, t = t.substring(p.length + 1), c = !0), !c) {
          let b = this.rules.other.nextBulletRegex(m), _ = this.rules.other.hrRegex(m), v = this.rules.other.fencesBeginRegex(m), w = this.rules.other.headingBeginRegex(m), C = this.rules.other.htmlBeginRegex(m);
          for (; t; ) {
            let S = t.split(`
`, 1)[0], D;
            if (p = S, this.options.pedantic ? (p = p.replace(this.rules.other.listReplaceNesting, "  "), D = p) : D = p.replace(this.rules.other.tabCharGlobal, "    "), v.test(p) || w.test(p) || C.test(p) || b.test(p) || _.test(p)) break;
            if (D.search(this.rules.other.nonSpaceChar) >= m || !p.trim()) u += `
` + D.slice(m);
            else {
              if (g || f.replace(this.rules.other.tabCharGlobal, "    ").search(this.rules.other.nonSpaceChar) >= 4 || v.test(f) || w.test(f) || _.test(f)) break;
              u += `
` + p;
            }
            !g && !p.trim() && (g = !0), h += S + `
`, t = t.substring(S.length + 1), f = D.slice(m);
          }
        }
        a.loose || (s ? a.loose = !0 : this.rules.other.doubleBlankLine.test(h) && (s = !0));
        let y = null, x;
        this.options.gfm && (y = this.rules.other.listIsTask.exec(u), y && (x = y[0] !== "[ ] ", u = u.replace(this.rules.other.listReplaceTask, ""))), a.items.push({ type: "list_item", raw: h, task: !!y, checked: x, loose: !1, text: u, tokens: [] }), a.raw += h;
      }
      let l = a.items.at(-1);
      if (l) l.raw = l.raw.trimEnd(), l.text = l.text.trimEnd();
      else return;
      a.raw = a.raw.trimEnd();
      for (let c = 0; c < a.items.length; c++) if (this.lexer.state.top = !1, a.items[c].tokens = this.lexer.blockTokens(a.items[c].text, []), !a.loose) {
        let h = a.items[c].tokens.filter((f) => f.type === "space"), u = h.length > 0 && h.some((f) => this.rules.other.anyLine.test(f.raw));
        a.loose = u;
      }
      if (a.loose) for (let c = 0; c < a.items.length; c++) a.items[c].loose = !0;
      return a;
    }
  }
  html(t) {
    let r = this.rules.block.html.exec(t);
    if (r) return { type: "html", block: !0, raw: r[0], pre: r[1] === "pre" || r[1] === "script" || r[1] === "style", text: r[0] };
  }
  def(t) {
    let r = this.rules.block.def.exec(t);
    if (r) {
      let i = r[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal, " "), n = r[2] ? r[2].replace(this.rules.other.hrefBrackets, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", a = r[3] ? r[3].substring(1, r[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : r[3];
      return { type: "def", tag: i, raw: r[0], href: n, title: a };
    }
  }
  table(t) {
    var s;
    let r = this.rules.block.table.exec(t);
    if (!r || !this.rules.other.tableDelimiter.test(r[2])) return;
    let i = Qc(r[1]), n = r[2].replace(this.rules.other.tableAlignChars, "").split("|"), a = (s = r[3]) != null && s.trim() ? r[3].replace(this.rules.other.tableRowBlankLine, "").split(`
`) : [], o = { type: "table", raw: r[0], header: [], align: [], rows: [] };
    if (i.length === n.length) {
      for (let l of n) this.rules.other.tableAlignRight.test(l) ? o.align.push("right") : this.rules.other.tableAlignCenter.test(l) ? o.align.push("center") : this.rules.other.tableAlignLeft.test(l) ? o.align.push("left") : o.align.push(null);
      for (let l = 0; l < i.length; l++) o.header.push({ text: i[l], tokens: this.lexer.inline(i[l]), header: !0, align: o.align[l] });
      for (let l of a) o.rows.push(Qc(l, o.header.length).map((c, h) => ({ text: c, tokens: this.lexer.inline(c), header: !1, align: o.align[h] })));
      return o;
    }
  }
  lheading(t) {
    let r = this.rules.block.lheading.exec(t);
    if (r) return { type: "heading", raw: r[0], depth: r[2].charAt(0) === "=" ? 1 : 2, text: r[1], tokens: this.lexer.inline(r[1]) };
  }
  paragraph(t) {
    let r = this.rules.block.paragraph.exec(t);
    if (r) {
      let i = r[1].charAt(r[1].length - 1) === `
` ? r[1].slice(0, -1) : r[1];
      return { type: "paragraph", raw: r[0], text: i, tokens: this.lexer.inline(i) };
    }
  }
  text(t) {
    let r = this.rules.block.text.exec(t);
    if (r) return { type: "text", raw: r[0], text: r[0], tokens: this.lexer.inline(r[0]) };
  }
  escape(t) {
    let r = this.rules.inline.escape.exec(t);
    if (r) return { type: "escape", raw: r[0], text: r[1] };
  }
  tag(t) {
    let r = this.rules.inline.tag.exec(t);
    if (r) return !this.lexer.state.inLink && this.rules.other.startATag.test(r[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && this.rules.other.endATag.test(r[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && this.rules.other.startPreScriptTag.test(r[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && this.rules.other.endPreScriptTag.test(r[0]) && (this.lexer.state.inRawBlock = !1), { type: "html", raw: r[0], inLink: this.lexer.state.inLink, inRawBlock: this.lexer.state.inRawBlock, block: !1, text: r[0] };
  }
  link(t) {
    let r = this.rules.inline.link.exec(t);
    if (r) {
      let i = r[2].trim();
      if (!this.options.pedantic && this.rules.other.startAngleBracket.test(i)) {
        if (!this.rules.other.endAngleBracket.test(i)) return;
        let o = yi(i.slice(0, -1), "\\");
        if ((i.length - o.length) % 2 === 0) return;
      } else {
        let o = uv(r[2], "()");
        if (o === -2) return;
        if (o > -1) {
          let s = (r[0].indexOf("!") === 0 ? 5 : 4) + r[1].length + o;
          r[2] = r[2].substring(0, o), r[0] = r[0].substring(0, s).trim(), r[3] = "";
        }
      }
      let n = r[2], a = "";
      if (this.options.pedantic) {
        let o = this.rules.other.pedanticHrefTitle.exec(n);
        o && (n = o[1], a = o[3]);
      } else a = r[3] ? r[3].slice(1, -1) : "";
      return n = n.trim(), this.rules.other.startAngleBracket.test(n) && (this.options.pedantic && !this.rules.other.endAngleBracket.test(i) ? n = n.slice(1) : n = n.slice(1, -1)), Jc(r, { href: n && n.replace(this.rules.inline.anyPunctuation, "$1"), title: a && a.replace(this.rules.inline.anyPunctuation, "$1") }, r[0], this.lexer, this.rules);
    }
  }
  reflink(t, r) {
    let i;
    if ((i = this.rules.inline.reflink.exec(t)) || (i = this.rules.inline.nolink.exec(t))) {
      let n = (i[2] || i[1]).replace(this.rules.other.multipleSpaceGlobal, " "), a = r[n.toLowerCase()];
      if (!a) {
        let o = i[0].charAt(0);
        return { type: "text", raw: o, text: o };
      }
      return Jc(i, a, i[0], this.lexer, this.rules);
    }
  }
  emStrong(t, r, i = "") {
    let n = this.rules.inline.emStrongLDelim.exec(t);
    if (!(!n || n[3] && i.match(this.rules.other.unicodeAlphaNumeric)) && (!(n[1] || n[2]) || !i || this.rules.inline.punctuation.exec(i))) {
      let a = [...n[0]].length - 1, o, s, l = a, c = 0, h = n[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (h.lastIndex = 0, r = r.slice(-1 * t.length + a); (n = h.exec(r)) != null; ) {
        if (o = n[1] || n[2] || n[3] || n[4] || n[5] || n[6], !o) continue;
        if (s = [...o].length, n[3] || n[4]) {
          l += s;
          continue;
        } else if ((n[5] || n[6]) && a % 3 && !((a + s) % 3)) {
          c += s;
          continue;
        }
        if (l -= s, l > 0) continue;
        s = Math.min(s, s + l + c);
        let u = [...n[0]][0].length, f = t.slice(0, a + n.index + u + s);
        if (Math.min(a, s) % 2) {
          let g = f.slice(1, -1);
          return { type: "em", raw: f, text: g, tokens: this.lexer.inlineTokens(g) };
        }
        let p = f.slice(2, -2);
        return { type: "strong", raw: f, text: p, tokens: this.lexer.inlineTokens(p) };
      }
    }
  }
  codespan(t) {
    let r = this.rules.inline.code.exec(t);
    if (r) {
      let i = r[2].replace(this.rules.other.newLineCharGlobal, " "), n = this.rules.other.nonSpaceChar.test(i), a = this.rules.other.startingSpaceChar.test(i) && this.rules.other.endingSpaceChar.test(i);
      return n && a && (i = i.substring(1, i.length - 1)), { type: "codespan", raw: r[0], text: i };
    }
  }
  br(t) {
    let r = this.rules.inline.br.exec(t);
    if (r) return { type: "br", raw: r[0] };
  }
  del(t) {
    let r = this.rules.inline.del.exec(t);
    if (r) return { type: "del", raw: r[0], text: r[2], tokens: this.lexer.inlineTokens(r[2]) };
  }
  autolink(t) {
    let r = this.rules.inline.autolink.exec(t);
    if (r) {
      let i, n;
      return r[2] === "@" ? (i = r[1], n = "mailto:" + i) : (i = r[1], n = i), { type: "link", raw: r[0], text: i, href: n, tokens: [{ type: "text", raw: i, text: i }] };
    }
  }
  url(t) {
    var i;
    let r;
    if (r = this.rules.inline.url.exec(t)) {
      let n, a;
      if (r[2] === "@") n = r[0], a = "mailto:" + n;
      else {
        let o;
        do
          o = r[0], r[0] = ((i = this.rules.inline._backpedal.exec(r[0])) == null ? void 0 : i[0]) ?? "";
        while (o !== r[0]);
        n = r[0], r[1] === "www." ? a = "http://" + r[0] : a = r[0];
      }
      return { type: "link", raw: r[0], text: n, href: a, tokens: [{ type: "text", raw: n, text: n }] };
    }
  }
  inlineText(t) {
    let r = this.rules.inline.text.exec(t);
    if (r) {
      let i = this.lexer.state.inRawBlock;
      return { type: "text", raw: r[0], text: r[0], escaped: i };
    }
  }
}, he = class no {
  constructor(t) {
    mt(this, "tokens");
    mt(this, "options");
    mt(this, "state");
    mt(this, "tokenizer");
    mt(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = t || kr, this.options.tokenizer = this.options.tokenizer || new ua(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = { inLink: !1, inRawBlock: !1, top: !0 };
    let r = { other: Ut, block: yn.normal, inline: mi.normal };
    this.options.pedantic ? (r.block = yn.pedantic, r.inline = mi.pedantic) : this.options.gfm && (r.block = yn.gfm, this.options.breaks ? r.inline = mi.breaks : r.inline = mi.gfm), this.tokenizer.rules = r;
  }
  static get rules() {
    return { block: yn, inline: mi };
  }
  static lex(t, r) {
    return new no(r).lex(t);
  }
  static lexInline(t, r) {
    return new no(r).inlineTokens(t);
  }
  lex(t) {
    t = t.replace(Ut.carriageReturn, `
`), this.blockTokens(t, this.tokens);
    for (let r = 0; r < this.inlineQueue.length; r++) {
      let i = this.inlineQueue[r];
      this.inlineTokens(i.src, i.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(t, r = [], i = !1) {
    var n, a, o;
    for (this.options.pedantic && (t = t.replace(Ut.tabCharGlobal, "    ").replace(Ut.spaceLine, "")); t; ) {
      let s;
      if ((a = (n = this.options.extensions) == null ? void 0 : n.block) != null && a.some((c) => (s = c.call({ lexer: this }, t, r)) ? (t = t.substring(s.raw.length), r.push(s), !0) : !1)) continue;
      if (s = this.tokenizer.space(t)) {
        t = t.substring(s.raw.length);
        let c = r.at(-1);
        s.raw.length === 1 && c !== void 0 ? c.raw += `
` : r.push(s);
        continue;
      }
      if (s = this.tokenizer.code(t)) {
        t = t.substring(s.raw.length);
        let c = r.at(-1);
        (c == null ? void 0 : c.type) === "paragraph" || (c == null ? void 0 : c.type) === "text" ? (c.raw += (c.raw.endsWith(`
`) ? "" : `
`) + s.raw, c.text += `
` + s.text, this.inlineQueue.at(-1).src = c.text) : r.push(s);
        continue;
      }
      if (s = this.tokenizer.fences(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.heading(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.hr(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.blockquote(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.list(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.html(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.def(t)) {
        t = t.substring(s.raw.length);
        let c = r.at(-1);
        (c == null ? void 0 : c.type) === "paragraph" || (c == null ? void 0 : c.type) === "text" ? (c.raw += (c.raw.endsWith(`
`) ? "" : `
`) + s.raw, c.text += `
` + s.raw, this.inlineQueue.at(-1).src = c.text) : this.tokens.links[s.tag] || (this.tokens.links[s.tag] = { href: s.href, title: s.title }, r.push(s));
        continue;
      }
      if (s = this.tokenizer.table(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.lheading(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      let l = t;
      if ((o = this.options.extensions) != null && o.startBlock) {
        let c = 1 / 0, h = t.slice(1), u;
        this.options.extensions.startBlock.forEach((f) => {
          u = f.call({ lexer: this }, h), typeof u == "number" && u >= 0 && (c = Math.min(c, u));
        }), c < 1 / 0 && c >= 0 && (l = t.substring(0, c + 1));
      }
      if (this.state.top && (s = this.tokenizer.paragraph(l))) {
        let c = r.at(-1);
        i && (c == null ? void 0 : c.type) === "paragraph" ? (c.raw += (c.raw.endsWith(`
`) ? "" : `
`) + s.raw, c.text += `
` + s.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = c.text) : r.push(s), i = l.length !== t.length, t = t.substring(s.raw.length);
        continue;
      }
      if (s = this.tokenizer.text(t)) {
        t = t.substring(s.raw.length);
        let c = r.at(-1);
        (c == null ? void 0 : c.type) === "text" ? (c.raw += (c.raw.endsWith(`
`) ? "" : `
`) + s.raw, c.text += `
` + s.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = c.text) : r.push(s);
        continue;
      }
      if (t) {
        let c = "Infinite loop on byte: " + t.charCodeAt(0);
        if (this.options.silent) {
          console.error(c);
          break;
        } else throw new Error(c);
      }
    }
    return this.state.top = !0, r;
  }
  inline(t, r = []) {
    return this.inlineQueue.push({ src: t, tokens: r }), r;
  }
  inlineTokens(t, r = []) {
    var s, l, c, h, u;
    let i = t, n = null;
    if (this.tokens.links) {
      let f = Object.keys(this.tokens.links);
      if (f.length > 0) for (; (n = this.tokenizer.rules.inline.reflinkSearch.exec(i)) != null; ) f.includes(n[0].slice(n[0].lastIndexOf("[") + 1, -1)) && (i = i.slice(0, n.index) + "[" + "a".repeat(n[0].length - 2) + "]" + i.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (n = this.tokenizer.rules.inline.anyPunctuation.exec(i)) != null; ) i = i.slice(0, n.index) + "++" + i.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; (n = this.tokenizer.rules.inline.blockSkip.exec(i)) != null; ) i = i.slice(0, n.index) + "[" + "a".repeat(n[0].length - 2) + "]" + i.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    i = ((l = (s = this.options.hooks) == null ? void 0 : s.emStrongMask) == null ? void 0 : l.call({ lexer: this }, i)) ?? i;
    let a = !1, o = "";
    for (; t; ) {
      a || (o = ""), a = !1;
      let f;
      if ((h = (c = this.options.extensions) == null ? void 0 : c.inline) != null && h.some((g) => (f = g.call({ lexer: this }, t, r)) ? (t = t.substring(f.raw.length), r.push(f), !0) : !1)) continue;
      if (f = this.tokenizer.escape(t)) {
        t = t.substring(f.raw.length), r.push(f);
        continue;
      }
      if (f = this.tokenizer.tag(t)) {
        t = t.substring(f.raw.length), r.push(f);
        continue;
      }
      if (f = this.tokenizer.link(t)) {
        t = t.substring(f.raw.length), r.push(f);
        continue;
      }
      if (f = this.tokenizer.reflink(t, this.tokens.links)) {
        t = t.substring(f.raw.length);
        let g = r.at(-1);
        f.type === "text" && (g == null ? void 0 : g.type) === "text" ? (g.raw += f.raw, g.text += f.text) : r.push(f);
        continue;
      }
      if (f = this.tokenizer.emStrong(t, i, o)) {
        t = t.substring(f.raw.length), r.push(f);
        continue;
      }
      if (f = this.tokenizer.codespan(t)) {
        t = t.substring(f.raw.length), r.push(f);
        continue;
      }
      if (f = this.tokenizer.br(t)) {
        t = t.substring(f.raw.length), r.push(f);
        continue;
      }
      if (f = this.tokenizer.del(t)) {
        t = t.substring(f.raw.length), r.push(f);
        continue;
      }
      if (f = this.tokenizer.autolink(t)) {
        t = t.substring(f.raw.length), r.push(f);
        continue;
      }
      if (!this.state.inLink && (f = this.tokenizer.url(t))) {
        t = t.substring(f.raw.length), r.push(f);
        continue;
      }
      let p = t;
      if ((u = this.options.extensions) != null && u.startInline) {
        let g = 1 / 0, m = t.slice(1), y;
        this.options.extensions.startInline.forEach((x) => {
          y = x.call({ lexer: this }, m), typeof y == "number" && y >= 0 && (g = Math.min(g, y));
        }), g < 1 / 0 && g >= 0 && (p = t.substring(0, g + 1));
      }
      if (f = this.tokenizer.inlineText(p)) {
        t = t.substring(f.raw.length), f.raw.slice(-1) !== "_" && (o = f.raw.slice(-1)), a = !0;
        let g = r.at(-1);
        (g == null ? void 0 : g.type) === "text" ? (g.raw += f.raw, g.text += f.text) : r.push(f);
        continue;
      }
      if (t) {
        let g = "Infinite loop on byte: " + t.charCodeAt(0);
        if (this.options.silent) {
          console.error(g);
          break;
        } else throw new Error(g);
      }
    }
    return r;
  }
}, fa = class {
  constructor(t) {
    mt(this, "options");
    mt(this, "parser");
    this.options = t || kr;
  }
  space(t) {
    return "";
  }
  code({ text: t, lang: r, escaped: i }) {
    var o;
    let n = (o = (r || "").match(Ut.notSpaceStart)) == null ? void 0 : o[0], a = t.replace(Ut.endingNewline, "") + `
`;
    return n ? '<pre><code class="language-' + be(n) + '">' + (i ? a : be(a, !0)) + `</code></pre>
` : "<pre><code>" + (i ? a : be(a, !0)) + `</code></pre>
`;
  }
  blockquote({ tokens: t }) {
    return `<blockquote>
${this.parser.parse(t)}</blockquote>
`;
  }
  html({ text: t }) {
    return t;
  }
  def(t) {
    return "";
  }
  heading({ tokens: t, depth: r }) {
    return `<h${r}>${this.parser.parseInline(t)}</h${r}>
`;
  }
  hr(t) {
    return `<hr>
`;
  }
  list(t) {
    let r = t.ordered, i = t.start, n = "";
    for (let s = 0; s < t.items.length; s++) {
      let l = t.items[s];
      n += this.listitem(l);
    }
    let a = r ? "ol" : "ul", o = r && i !== 1 ? ' start="' + i + '"' : "";
    return "<" + a + o + `>
` + n + "</" + a + `>
`;
  }
  listitem(t) {
    var i;
    let r = "";
    if (t.task) {
      let n = this.checkbox({ checked: !!t.checked });
      t.loose ? ((i = t.tokens[0]) == null ? void 0 : i.type) === "paragraph" ? (t.tokens[0].text = n + " " + t.tokens[0].text, t.tokens[0].tokens && t.tokens[0].tokens.length > 0 && t.tokens[0].tokens[0].type === "text" && (t.tokens[0].tokens[0].text = n + " " + be(t.tokens[0].tokens[0].text), t.tokens[0].tokens[0].escaped = !0)) : t.tokens.unshift({ type: "text", raw: n + " ", text: n + " ", escaped: !0 }) : r += n + " ";
    }
    return r += this.parser.parse(t.tokens, !!t.loose), `<li>${r}</li>
`;
  }
  checkbox({ checked: t }) {
    return "<input " + (t ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph({ tokens: t }) {
    return `<p>${this.parser.parseInline(t)}</p>
`;
  }
  table(t) {
    let r = "", i = "";
    for (let a = 0; a < t.header.length; a++) i += this.tablecell(t.header[a]);
    r += this.tablerow({ text: i });
    let n = "";
    for (let a = 0; a < t.rows.length; a++) {
      let o = t.rows[a];
      i = "";
      for (let s = 0; s < o.length; s++) i += this.tablecell(o[s]);
      n += this.tablerow({ text: i });
    }
    return n && (n = `<tbody>${n}</tbody>`), `<table>
<thead>
` + r + `</thead>
` + n + `</table>
`;
  }
  tablerow({ text: t }) {
    return `<tr>
${t}</tr>
`;
  }
  tablecell(t) {
    let r = this.parser.parseInline(t.tokens), i = t.header ? "th" : "td";
    return (t.align ? `<${i} align="${t.align}">` : `<${i}>`) + r + `</${i}>
`;
  }
  strong({ tokens: t }) {
    return `<strong>${this.parser.parseInline(t)}</strong>`;
  }
  em({ tokens: t }) {
    return `<em>${this.parser.parseInline(t)}</em>`;
  }
  codespan({ text: t }) {
    return `<code>${be(t, !0)}</code>`;
  }
  br(t) {
    return "<br>";
  }
  del({ tokens: t }) {
    return `<del>${this.parser.parseInline(t)}</del>`;
  }
  link({ href: t, title: r, tokens: i }) {
    let n = this.parser.parseInline(i), a = Kc(t);
    if (a === null) return n;
    t = a;
    let o = '<a href="' + t + '"';
    return r && (o += ' title="' + be(r) + '"'), o += ">" + n + "</a>", o;
  }
  image({ href: t, title: r, text: i, tokens: n }) {
    n && (i = this.parser.parseInline(n, this.parser.textRenderer));
    let a = Kc(t);
    if (a === null) return be(i);
    t = a;
    let o = `<img src="${t}" alt="${i}"`;
    return r && (o += ` title="${be(r)}"`), o += ">", o;
  }
  text(t) {
    return "tokens" in t && t.tokens ? this.parser.parseInline(t.tokens) : "escaped" in t && t.escaped ? t.text : be(t.text);
  }
}, ml = class {
  strong({ text: t }) {
    return t;
  }
  em({ text: t }) {
    return t;
  }
  codespan({ text: t }) {
    return t;
  }
  del({ text: t }) {
    return t;
  }
  html({ text: t }) {
    return t;
  }
  text({ text: t }) {
    return t;
  }
  link({ text: t }) {
    return "" + t;
  }
  image({ text: t }) {
    return "" + t;
  }
  br() {
    return "";
  }
}, ue = class ao {
  constructor(t) {
    mt(this, "options");
    mt(this, "renderer");
    mt(this, "textRenderer");
    this.options = t || kr, this.options.renderer = this.options.renderer || new fa(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.renderer.parser = this, this.textRenderer = new ml();
  }
  static parse(t, r) {
    return new ao(r).parse(t);
  }
  static parseInline(t, r) {
    return new ao(r).parseInline(t);
  }
  parse(t, r = !0) {
    var n, a;
    let i = "";
    for (let o = 0; o < t.length; o++) {
      let s = t[o];
      if ((a = (n = this.options.extensions) == null ? void 0 : n.renderers) != null && a[s.type]) {
        let c = s, h = this.options.extensions.renderers[c.type].call({ parser: this }, c);
        if (h !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "def", "paragraph", "text"].includes(c.type)) {
          i += h || "";
          continue;
        }
      }
      let l = s;
      switch (l.type) {
        case "space": {
          i += this.renderer.space(l);
          continue;
        }
        case "hr": {
          i += this.renderer.hr(l);
          continue;
        }
        case "heading": {
          i += this.renderer.heading(l);
          continue;
        }
        case "code": {
          i += this.renderer.code(l);
          continue;
        }
        case "table": {
          i += this.renderer.table(l);
          continue;
        }
        case "blockquote": {
          i += this.renderer.blockquote(l);
          continue;
        }
        case "list": {
          i += this.renderer.list(l);
          continue;
        }
        case "html": {
          i += this.renderer.html(l);
          continue;
        }
        case "def": {
          i += this.renderer.def(l);
          continue;
        }
        case "paragraph": {
          i += this.renderer.paragraph(l);
          continue;
        }
        case "text": {
          let c = l, h = this.renderer.text(c);
          for (; o + 1 < t.length && t[o + 1].type === "text"; ) c = t[++o], h += `
` + this.renderer.text(c);
          r ? i += this.renderer.paragraph({ type: "paragraph", raw: h, text: h, tokens: [{ type: "text", raw: h, text: h, escaped: !0 }] }) : i += h;
          continue;
        }
        default: {
          let c = 'Token with "' + l.type + '" type was not found.';
          if (this.options.silent) return console.error(c), "";
          throw new Error(c);
        }
      }
    }
    return i;
  }
  parseInline(t, r = this.renderer) {
    var n, a;
    let i = "";
    for (let o = 0; o < t.length; o++) {
      let s = t[o];
      if ((a = (n = this.options.extensions) == null ? void 0 : n.renderers) != null && a[s.type]) {
        let c = this.options.extensions.renderers[s.type].call({ parser: this }, s);
        if (c !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(s.type)) {
          i += c || "";
          continue;
        }
      }
      let l = s;
      switch (l.type) {
        case "escape": {
          i += r.text(l);
          break;
        }
        case "html": {
          i += r.html(l);
          break;
        }
        case "link": {
          i += r.link(l);
          break;
        }
        case "image": {
          i += r.image(l);
          break;
        }
        case "strong": {
          i += r.strong(l);
          break;
        }
        case "em": {
          i += r.em(l);
          break;
        }
        case "codespan": {
          i += r.codespan(l);
          break;
        }
        case "br": {
          i += r.br(l);
          break;
        }
        case "del": {
          i += r.del(l);
          break;
        }
        case "text": {
          i += r.text(l);
          break;
        }
        default: {
          let c = 'Token with "' + l.type + '" type was not found.';
          if (this.options.silent) return console.error(c), "";
          throw new Error(c);
        }
      }
    }
    return i;
  }
}, kn, Si = (kn = class {
  constructor(t) {
    mt(this, "options");
    mt(this, "block");
    this.options = t || kr;
  }
  preprocess(t) {
    return t;
  }
  postprocess(t) {
    return t;
  }
  processAllTokens(t) {
    return t;
  }
  emStrongMask(t) {
    return t;
  }
  provideLexer() {
    return this.block ? he.lex : he.lexInline;
  }
  provideParser() {
    return this.block ? ue.parse : ue.parseInline;
  }
}, mt(kn, "passThroughHooks", /* @__PURE__ */ new Set(["preprocess", "postprocess", "processAllTokens", "emStrongMask"])), mt(kn, "passThroughHooksRespectAsync", /* @__PURE__ */ new Set(["preprocess", "postprocess", "processAllTokens"])), kn), pv = class {
  constructor(...t) {
    mt(this, "defaults", ll());
    mt(this, "options", this.setOptions);
    mt(this, "parse", this.parseMarkdown(!0));
    mt(this, "parseInline", this.parseMarkdown(!1));
    mt(this, "Parser", ue);
    mt(this, "Renderer", fa);
    mt(this, "TextRenderer", ml);
    mt(this, "Lexer", he);
    mt(this, "Tokenizer", ua);
    mt(this, "Hooks", Si);
    this.use(...t);
  }
  walkTokens(t, r) {
    var n, a;
    let i = [];
    for (let o of t) switch (i = i.concat(r.call(this, o)), o.type) {
      case "table": {
        let s = o;
        for (let l of s.header) i = i.concat(this.walkTokens(l.tokens, r));
        for (let l of s.rows) for (let c of l) i = i.concat(this.walkTokens(c.tokens, r));
        break;
      }
      case "list": {
        let s = o;
        i = i.concat(this.walkTokens(s.items, r));
        break;
      }
      default: {
        let s = o;
        (a = (n = this.defaults.extensions) == null ? void 0 : n.childTokens) != null && a[s.type] ? this.defaults.extensions.childTokens[s.type].forEach((l) => {
          let c = s[l].flat(1 / 0);
          i = i.concat(this.walkTokens(c, r));
        }) : s.tokens && (i = i.concat(this.walkTokens(s.tokens, r)));
      }
    }
    return i;
  }
  use(...t) {
    let r = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return t.forEach((i) => {
      let n = { ...i };
      if (n.async = this.defaults.async || n.async || !1, i.extensions && (i.extensions.forEach((a) => {
        if (!a.name) throw new Error("extension name required");
        if ("renderer" in a) {
          let o = r.renderers[a.name];
          o ? r.renderers[a.name] = function(...s) {
            let l = a.renderer.apply(this, s);
            return l === !1 && (l = o.apply(this, s)), l;
          } : r.renderers[a.name] = a.renderer;
        }
        if ("tokenizer" in a) {
          if (!a.level || a.level !== "block" && a.level !== "inline") throw new Error("extension level must be 'block' or 'inline'");
          let o = r[a.level];
          o ? o.unshift(a.tokenizer) : r[a.level] = [a.tokenizer], a.start && (a.level === "block" ? r.startBlock ? r.startBlock.push(a.start) : r.startBlock = [a.start] : a.level === "inline" && (r.startInline ? r.startInline.push(a.start) : r.startInline = [a.start]));
        }
        "childTokens" in a && a.childTokens && (r.childTokens[a.name] = a.childTokens);
      }), n.extensions = r), i.renderer) {
        let a = this.defaults.renderer || new fa(this.defaults);
        for (let o in i.renderer) {
          if (!(o in a)) throw new Error(`renderer '${o}' does not exist`);
          if (["options", "parser"].includes(o)) continue;
          let s = o, l = i.renderer[s], c = a[s];
          a[s] = (...h) => {
            let u = l.apply(a, h);
            return u === !1 && (u = c.apply(a, h)), u || "";
          };
        }
        n.renderer = a;
      }
      if (i.tokenizer) {
        let a = this.defaults.tokenizer || new ua(this.defaults);
        for (let o in i.tokenizer) {
          if (!(o in a)) throw new Error(`tokenizer '${o}' does not exist`);
          if (["options", "rules", "lexer"].includes(o)) continue;
          let s = o, l = i.tokenizer[s], c = a[s];
          a[s] = (...h) => {
            let u = l.apply(a, h);
            return u === !1 && (u = c.apply(a, h)), u;
          };
        }
        n.tokenizer = a;
      }
      if (i.hooks) {
        let a = this.defaults.hooks || new Si();
        for (let o in i.hooks) {
          if (!(o in a)) throw new Error(`hook '${o}' does not exist`);
          if (["options", "block"].includes(o)) continue;
          let s = o, l = i.hooks[s], c = a[s];
          Si.passThroughHooks.has(o) ? a[s] = (h) => {
            if (this.defaults.async && Si.passThroughHooksRespectAsync.has(o)) return (async () => {
              let f = await l.call(a, h);
              return c.call(a, f);
            })();
            let u = l.call(a, h);
            return c.call(a, u);
          } : a[s] = (...h) => {
            if (this.defaults.async) return (async () => {
              let f = await l.apply(a, h);
              return f === !1 && (f = await c.apply(a, h)), f;
            })();
            let u = l.apply(a, h);
            return u === !1 && (u = c.apply(a, h)), u;
          };
        }
        n.hooks = a;
      }
      if (i.walkTokens) {
        let a = this.defaults.walkTokens, o = i.walkTokens;
        n.walkTokens = function(s) {
          let l = [];
          return l.push(o.call(this, s)), a && (l = l.concat(a.call(this, s))), l;
        };
      }
      this.defaults = { ...this.defaults, ...n };
    }), this;
  }
  setOptions(t) {
    return this.defaults = { ...this.defaults, ...t }, this;
  }
  lexer(t, r) {
    return he.lex(t, r ?? this.defaults);
  }
  parser(t, r) {
    return ue.parse(t, r ?? this.defaults);
  }
  parseMarkdown(t) {
    return (r, i) => {
      let n = { ...i }, a = { ...this.defaults, ...n }, o = this.onError(!!a.silent, !!a.async);
      if (this.defaults.async === !0 && n.async === !1) return o(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));
      if (typeof r > "u" || r === null) return o(new Error("marked(): input parameter is undefined or null"));
      if (typeof r != "string") return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(r) + ", string expected"));
      if (a.hooks && (a.hooks.options = a, a.hooks.block = t), a.async) return (async () => {
        let s = a.hooks ? await a.hooks.preprocess(r) : r, l = await (a.hooks ? await a.hooks.provideLexer() : t ? he.lex : he.lexInline)(s, a), c = a.hooks ? await a.hooks.processAllTokens(l) : l;
        a.walkTokens && await Promise.all(this.walkTokens(c, a.walkTokens));
        let h = await (a.hooks ? await a.hooks.provideParser() : t ? ue.parse : ue.parseInline)(c, a);
        return a.hooks ? await a.hooks.postprocess(h) : h;
      })().catch(o);
      try {
        a.hooks && (r = a.hooks.preprocess(r));
        let s = (a.hooks ? a.hooks.provideLexer() : t ? he.lex : he.lexInline)(r, a);
        a.hooks && (s = a.hooks.processAllTokens(s)), a.walkTokens && this.walkTokens(s, a.walkTokens);
        let l = (a.hooks ? a.hooks.provideParser() : t ? ue.parse : ue.parseInline)(s, a);
        return a.hooks && (l = a.hooks.postprocess(l)), l;
      } catch (s) {
        return o(s);
      }
    };
  }
  onError(t, r) {
    return (i) => {
      if (i.message += `
Please report this to https://github.com/markedjs/marked.`, t) {
        let n = "<p>An error occurred:</p><pre>" + be(i.message + "", !0) + "</pre>";
        return r ? Promise.resolve(n) : n;
      }
      if (r) return Promise.reject(i);
      throw i;
    };
  }
}, yr = new pv();
function dt(e, t) {
  return yr.parse(e, t);
}
dt.options = dt.setOptions = function(e) {
  return yr.setOptions(e), dt.defaults = yr.defaults, Vp(dt.defaults), dt;
};
dt.getDefaults = ll;
dt.defaults = kr;
dt.use = function(...e) {
  return yr.use(...e), dt.defaults = yr.defaults, Vp(dt.defaults), dt;
};
dt.walkTokens = function(e, t) {
  return yr.walkTokens(e, t);
};
dt.parseInline = yr.parseInline;
dt.Parser = ue;
dt.parser = ue.parse;
dt.Renderer = fa;
dt.TextRenderer = ml;
dt.Lexer = he;
dt.lexer = he.lex;
dt.Tokenizer = ua;
dt.Hooks = Si;
dt.parse = dt;
dt.options;
dt.setOptions;
dt.use;
dt.walkTokens;
dt.parseInline;
ue.parse;
he.lex;
function sd(e) {
  for (var t = [], r = 1; r < arguments.length; r++)
    t[r - 1] = arguments[r];
  var i = Array.from(typeof e == "string" ? [e] : e);
  i[i.length - 1] = i[i.length - 1].replace(/\r?\n([\t ]*)$/, "");
  var n = i.reduce(function(s, l) {
    var c = l.match(/\n([\t ]+|(?!\s).)/g);
    return c ? s.concat(c.map(function(h) {
      var u, f;
      return (f = (u = h.match(/[\t ]/g)) === null || u === void 0 ? void 0 : u.length) !== null && f !== void 0 ? f : 0;
    })) : s;
  }, []);
  if (n.length) {
    var a = new RegExp(`
[	 ]{` + Math.min.apply(Math, n) + "}", "g");
    i = i.map(function(s) {
      return s.replace(a, `
`);
    });
  }
  i[0] = i[0].replace(/^\r?\n/, "");
  var o = i[0];
  return t.forEach(function(s, l) {
    var c = o.match(/(?:^|\n)( *)$/), h = c ? c[1] : "", u = s;
    typeof s == "string" && s.includes(`
`) && (u = String(s).split(`
`).map(function(f, p) {
      return p === 0 ? f : "" + h + f;
    }).join(`
`)), o += u + i[l + 1];
  }), o;
}
var dv = {
  body: '<g><rect width="80" height="80" style="fill: #087ebf; stroke-width: 0px;"/><text transform="translate(21.16 64.67)" style="fill: #fff; font-family: ArialMT, Arial; font-size: 67.75px;"><tspan x="0" y="0">?</tspan></text></g>',
  height: 80,
  width: 80
}, so = /* @__PURE__ */ new Map(), od = /* @__PURE__ */ new Map(), gv = /* @__PURE__ */ d((e) => {
  for (const t of e) {
    if (!t.name)
      throw new Error(
        'Invalid icon loader. Must have a "name" property with non-empty string value.'
      );
    if (F.debug("Registering icon pack:", t.name), "loader" in t)
      od.set(t.name, t.loader);
    else if ("icons" in t)
      so.set(t.name, t.icons);
    else
      throw F.error("Invalid icon loader:", t), new Error('Invalid icon loader. Must have either "icons" or "loader" property.');
  }
}, "registerIconPacks"), ld = /* @__PURE__ */ d(async (e, t) => {
  const r = mk(e, !0, t !== void 0);
  if (!r)
    throw new Error(`Invalid icon name: ${e}`);
  const i = r.prefix || t;
  if (!i)
    throw new Error(`Icon name must contain a prefix: ${e}`);
  let n = so.get(i);
  if (!n) {
    const o = od.get(i);
    if (!o)
      throw new Error(`Icon set not found: ${r.prefix}`);
    try {
      n = { ...await o(), prefix: i }, so.set(i, n);
    } catch (s) {
      throw F.error(s), new Error(`Failed to load icon set: ${r.prefix}`);
    }
  }
  const a = bk(n, r.name);
  if (!a)
    throw new Error(`Icon not found: ${e}`);
  return a;
}, "getRegisteredIconData"), mv = /* @__PURE__ */ d(async (e) => {
  try {
    return await ld(e), !0;
  } catch {
    return !1;
  }
}, "isIconAvailable"), rn = /* @__PURE__ */ d(async (e, t, r) => {
  let i;
  try {
    i = await ld(e, t == null ? void 0 : t.fallbackPrefix);
  } catch (o) {
    F.error(o), i = dv;
  }
  const n = Tk(i, t), a = $k(Mk(n.body), {
    ...n.attributes,
    ...r
  });
  return se(a, Nt());
}, "getIconSVG");
function cd(e, { markdownAutoWrap: t }) {
  const i = e.replace(/<br\/>/g, `
`).replace(/\n{2,}/g, `
`), n = sd(i);
  return t === !1 ? n.replace(/ /g, "&nbsp;") : n;
}
d(cd, "preprocessMarkdown");
function hd(e, t = {}) {
  const r = cd(e, t), i = dt.lexer(r), n = [[]];
  let a = 0;
  function o(s, l = "normal") {
    s.type === "text" ? s.text.split(`
`).forEach((h, u) => {
      u !== 0 && (a++, n.push([])), h.split(" ").forEach((f) => {
        f = f.replace(/&#39;/g, "'"), f && n[a].push({ content: f, type: l });
      });
    }) : s.type === "strong" || s.type === "em" ? s.tokens.forEach((c) => {
      o(c, s.type);
    }) : s.type === "html" && n[a].push({ content: s.text, type: "normal" });
  }
  return d(o, "processNode"), i.forEach((s) => {
    var l;
    s.type === "paragraph" ? (l = s.tokens) == null || l.forEach((c) => {
      o(c);
    }) : s.type === "html" ? n[a].push({ content: s.text, type: "normal" }) : n[a].push({ content: s.raw, type: "normal" });
  }), n;
}
d(hd, "markdownToLines");
function ud(e, { markdownAutoWrap: t } = {}) {
  const r = dt.lexer(e);
  function i(n) {
    var a, o, s;
    return n.type === "text" ? t === !1 ? n.text.replace(/\n */g, "<br/>").replace(/ /g, "&nbsp;") : n.text.replace(/\n */g, "<br/>") : n.type === "strong" ? `<strong>${(a = n.tokens) == null ? void 0 : a.map(i).join("")}</strong>` : n.type === "em" ? `<em>${(o = n.tokens) == null ? void 0 : o.map(i).join("")}</em>` : n.type === "paragraph" ? `<p>${(s = n.tokens) == null ? void 0 : s.map(i).join("")}</p>` : n.type === "space" ? "" : n.type === "html" ? `${n.text}` : n.type === "escape" ? n.text : (F.warn(`Unsupported markdown: ${n.type}`), n.raw);
  }
  return d(i, "output"), r.map(i).join("");
}
d(ud, "markdownToHTML");
function fd(e) {
  return Intl.Segmenter ? [...new Intl.Segmenter().segment(e)].map((t) => t.segment) : [...e];
}
d(fd, "splitTextToChars");
function pd(e, t) {
  const r = fd(t.content);
  return yl(e, [], r, t.type);
}
d(pd, "splitWordToFitWidth");
function yl(e, t, r, i) {
  if (r.length === 0)
    return [
      { content: t.join(""), type: i },
      { content: "", type: i }
    ];
  const [n, ...a] = r, o = [...t, n];
  return e([{ content: o.join(""), type: i }]) ? yl(e, o, a, i) : (t.length === 0 && n && (t.push(n), r.shift()), [
    { content: t.join(""), type: i },
    { content: r.join(""), type: i }
  ]);
}
d(yl, "splitWordToFitWidthRecursion");
function dd(e, t) {
  if (e.some(({ content: r }) => r.includes(`
`)))
    throw new Error("splitLineToFitWidth does not support newlines in the line");
  return pa(e, t);
}
d(dd, "splitLineToFitWidth");
function pa(e, t, r = [], i = []) {
  if (e.length === 0)
    return i.length > 0 && r.push(i), r.length > 0 ? r : [];
  let n = "";
  e[0].content === " " && (n = " ", e.shift());
  const a = e.shift() ?? { content: " ", type: "normal" }, o = [...i];
  if (n !== "" && o.push({ content: n, type: "normal" }), o.push(a), t(o))
    return pa(e, t, r, o);
  if (i.length > 0)
    r.push(i), e.unshift(a);
  else if (a.content) {
    const [s, l] = pd(t, a);
    r.push([s]), l.content && e.unshift(l);
  }
  return pa(e, t, r);
}
d(pa, "splitLineToFitWidthRecursion");
function oo(e, t) {
  t && e.attr("style", t);
}
d(oo, "applyStyle");
async function gd(e, t, r, i, n = !1, a = Nt()) {
  const o = e.append("foreignObject");
  o.attr("width", `${10 * r}px`), o.attr("height", `${10 * r}px`);
  const s = o.append("xhtml:div"), l = Xr(t.label) ? await So(t.label.replace(ei.lineBreakRegex, `
`), a) : se(t.label, a), c = t.isNode ? "nodeLabel" : "edgeLabel", h = s.append("span");
  h.html(l), oo(h, t.labelStyle), h.attr("class", `${c} ${i}`), oo(s, t.labelStyle), s.style("display", "table-cell"), s.style("white-space", "nowrap"), s.style("line-height", "1.5"), s.style("max-width", r + "px"), s.style("text-align", "center"), s.attr("xmlns", "http://www.w3.org/1999/xhtml"), n && s.attr("class", "labelBkg");
  let u = s.node().getBoundingClientRect();
  return u.width === r && (s.style("display", "table"), s.style("white-space", "break-spaces"), s.style("width", r + "px"), u = s.node().getBoundingClientRect()), o.node();
}
d(gd, "addHtmlSpan");
function Na(e, t, r) {
  return e.append("tspan").attr("class", "text-outer-tspan").attr("x", 0).attr("y", t * r - 0.1 + "em").attr("dy", r + "em");
}
d(Na, "createTspan");
function md(e, t, r) {
  const i = e.append("text"), n = Na(i, 1, t);
  za(n, r);
  const a = n.node().getComputedTextLength();
  return i.remove(), a;
}
d(md, "computeWidthOfText");
function yv(e, t, r) {
  var o;
  const i = e.append("text"), n = Na(i, 1, t);
  za(n, [{ content: r, type: "normal" }]);
  const a = (o = n.node()) == null ? void 0 : o.getBoundingClientRect();
  return a && i.remove(), a;
}
d(yv, "computeDimensionOfText");
function yd(e, t, r, i = !1) {
  const a = t.append("g"), o = a.insert("rect").attr("class", "background").attr("style", "stroke: none"), s = a.append("text").attr("y", "-10.1");
  let l = 0;
  for (const c of r) {
    const h = /* @__PURE__ */ d((f) => md(a, 1.1, f) <= e, "checkWidth"), u = h(c) ? [c] : dd(c, h);
    for (const f of u) {
      const p = Na(s, l, 1.1);
      za(p, f), l++;
    }
  }
  if (i) {
    const c = s.node().getBBox(), h = 2;
    return o.attr("x", c.x - h).attr("y", c.y - h).attr("width", c.width + 2 * h).attr("height", c.height + 2 * h), a.node();
  } else
    return s.node();
}
d(yd, "createFormattedText");
function za(e, t) {
  e.text(""), t.forEach((r, i) => {
    const n = e.append("tspan").attr("font-style", r.type === "em" ? "italic" : "normal").attr("class", "text-inner-tspan").attr("font-weight", r.type === "strong" ? "bold" : "normal");
    i === 0 ? n.text(r.content) : n.text(" " + r.content);
  });
}
d(za, "updateTextContentAndStyles");
async function xd(e, t = {}) {
  const r = [];
  e.replace(/(fa[bklrs]?):fa-([\w-]+)/g, (n, a, o) => (r.push(
    (async () => {
      const s = `${a}:${o}`;
      return await mv(s) ? await rn(s, void 0, { class: "label-icon" }) : `<i class='${se(n, t).replace(":", " ")}'></i>`;
    })()
  ), n));
  const i = await Promise.all(r);
  return e.replace(/(fa[bklrs]?):fa-([\w-]+)/g, () => i.shift() ?? "");
}
d(xd, "replaceIconSubstring");
var Ze = /* @__PURE__ */ d(async (e, t = "", {
  style: r = "",
  isTitle: i = !1,
  classes: n = "",
  useHtmlLabels: a = !0,
  isNode: o = !0,
  width: s = 200,
  addSvgBackground: l = !1
} = {}, c) => {
  if (F.debug(
    "XYZ createText",
    t,
    r,
    i,
    n,
    a,
    o,
    "addSvgBackground: ",
    l
  ), a) {
    const h = ud(t, c), u = await xd(wr(h), c), f = t.replace(/\\\\/g, "\\"), p = {
      isNode: o,
      label: Xr(t) ? f : u,
      labelStyle: r.replace("fill:", "color:")
    };
    return await gd(e, p, s, n, l, c);
  } else {
    const h = t.replace(/<br\s*\/?>/g, "<br/>"), u = hd(h.replace("<br>", "<br/>"), c), f = yd(
      s,
      e,
      u,
      t ? l : !1
    );
    if (o) {
      /stroke:/.exec(r) && (r = r.replace("stroke:", "lineColor:"));
      const p = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/color:/g, "fill:");
      ht(f).attr("style", p);
    } else {
      const p = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/background:/g, "fill:");
      ht(f).select("rect").attr("style", p.replace(/background:/g, "fill:"));
      const g = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/color:/g, "fill:");
      ht(f).select("text").attr("style", g);
    }
    return f;
  }
}, "createText");
function gs(e, t, r) {
  if (e && e.length) {
    const [i, n] = t, a = Math.PI / 180 * r, o = Math.cos(a), s = Math.sin(a);
    for (const l of e) {
      const [c, h] = l;
      l[0] = (c - i) * o - (h - n) * s + i, l[1] = (c - i) * s + (h - n) * o + n;
    }
  }
}
function xv(e, t) {
  return e[0] === t[0] && e[1] === t[1];
}
function bv(e, t, r, i = 1) {
  const n = r, a = Math.max(t, 0.1), o = e[0] && e[0][0] && typeof e[0][0] == "number" ? [e] : e, s = [0, 0];
  if (n) for (const c of o) gs(c, s, n);
  const l = function(c, h, u) {
    const f = [];
    for (const b of c) {
      const _ = [...b];
      xv(_[0], _[_.length - 1]) || _.push([_[0][0], _[0][1]]), _.length > 2 && f.push(_);
    }
    const p = [];
    h = Math.max(h, 0.1);
    const g = [];
    for (const b of f) for (let _ = 0; _ < b.length - 1; _++) {
      const v = b[_], w = b[_ + 1];
      if (v[1] !== w[1]) {
        const C = Math.min(v[1], w[1]);
        g.push({ ymin: C, ymax: Math.max(v[1], w[1]), x: C === v[1] ? v[0] : w[0], islope: (w[0] - v[0]) / (w[1] - v[1]) });
      }
    }
    if (g.sort((b, _) => b.ymin < _.ymin ? -1 : b.ymin > _.ymin ? 1 : b.x < _.x ? -1 : b.x > _.x ? 1 : b.ymax === _.ymax ? 0 : (b.ymax - _.ymax) / Math.abs(b.ymax - _.ymax)), !g.length) return p;
    let m = [], y = g[0].ymin, x = 0;
    for (; m.length || g.length; ) {
      if (g.length) {
        let b = -1;
        for (let _ = 0; _ < g.length && !(g[_].ymin > y); _++) b = _;
        g.splice(0, b + 1).forEach((_) => {
          m.push({ s: y, edge: _ });
        });
      }
      if (m = m.filter((b) => !(b.edge.ymax <= y)), m.sort((b, _) => b.edge.x === _.edge.x ? 0 : (b.edge.x - _.edge.x) / Math.abs(b.edge.x - _.edge.x)), (u !== 1 || x % h == 0) && m.length > 1) for (let b = 0; b < m.length; b += 2) {
        const _ = b + 1;
        if (_ >= m.length) break;
        const v = m[b].edge, w = m[_].edge;
        p.push([[Math.round(v.x), y], [Math.round(w.x), y]]);
      }
      y += u, m.forEach((b) => {
        b.edge.x = b.edge.x + u * b.edge.islope;
      }), x++;
    }
    return p;
  }(o, a, i);
  if (n) {
    for (const c of o) gs(c, s, -n);
    (function(c, h, u) {
      const f = [];
      c.forEach((p) => f.push(...p)), gs(f, h, u);
    })(l, s, -n);
  }
  return l;
}
function nn(e, t) {
  var r;
  const i = t.hachureAngle + 90;
  let n = t.hachureGap;
  n < 0 && (n = 4 * t.strokeWidth), n = Math.round(Math.max(n, 0.1));
  let a = 1;
  return t.roughness >= 1 && (((r = t.randomizer) === null || r === void 0 ? void 0 : r.next()) || Math.random()) > 0.7 && (a = n), bv(e, n, i, a || 1);
}
class xl {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    return this._fillPolygons(t, r);
  }
  _fillPolygons(t, r) {
    const i = nn(t, r);
    return { type: "fillSketch", ops: this.renderLines(i, r) };
  }
  renderLines(t, r) {
    const i = [];
    for (const n of t) i.push(...this.helper.doubleLineOps(n[0][0], n[0][1], n[1][0], n[1][1], r));
    return i;
  }
}
function Wa(e) {
  const t = e[0], r = e[1];
  return Math.sqrt(Math.pow(t[0] - r[0], 2) + Math.pow(t[1] - r[1], 2));
}
class Cv extends xl {
  fillPolygons(t, r) {
    let i = r.hachureGap;
    i < 0 && (i = 4 * r.strokeWidth), i = Math.max(i, 0.1);
    const n = nn(t, Object.assign({}, r, { hachureGap: i })), a = Math.PI / 180 * r.hachureAngle, o = [], s = 0.5 * i * Math.cos(a), l = 0.5 * i * Math.sin(a);
    for (const [c, h] of n) Wa([c, h]) && o.push([[c[0] - s, c[1] + l], [...h]], [[c[0] + s, c[1] - l], [...h]]);
    return { type: "fillSketch", ops: this.renderLines(o, r) };
  }
}
class _v extends xl {
  fillPolygons(t, r) {
    const i = this._fillPolygons(t, r), n = Object.assign({}, r, { hachureAngle: r.hachureAngle + 90 }), a = this._fillPolygons(t, n);
    return i.ops = i.ops.concat(a.ops), i;
  }
}
class wv {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = nn(t, r = Object.assign({}, r, { hachureAngle: 0 }));
    return this.dotsOnLines(i, r);
  }
  dotsOnLines(t, r) {
    const i = [];
    let n = r.hachureGap;
    n < 0 && (n = 4 * r.strokeWidth), n = Math.max(n, 0.1);
    let a = r.fillWeight;
    a < 0 && (a = r.strokeWidth / 2);
    const o = n / 4;
    for (const s of t) {
      const l = Wa(s), c = l / n, h = Math.ceil(c) - 1, u = l - h * n, f = (s[0][0] + s[1][0]) / 2 - n / 4, p = Math.min(s[0][1], s[1][1]);
      for (let g = 0; g < h; g++) {
        const m = p + u + g * n, y = f - o + 2 * Math.random() * o, x = m - o + 2 * Math.random() * o, b = this.helper.ellipse(y, x, a, a, r);
        i.push(...b.ops);
      }
    }
    return { type: "fillSketch", ops: i };
  }
}
class kv {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = nn(t, r);
    return { type: "fillSketch", ops: this.dashedLine(i, r) };
  }
  dashedLine(t, r) {
    const i = r.dashOffset < 0 ? r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap : r.dashOffset, n = r.dashGap < 0 ? r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap : r.dashGap, a = [];
    return t.forEach((o) => {
      const s = Wa(o), l = Math.floor(s / (i + n)), c = (s + n - l * (i + n)) / 2;
      let h = o[0], u = o[1];
      h[0] > u[0] && (h = o[1], u = o[0]);
      const f = Math.atan((u[1] - h[1]) / (u[0] - h[0]));
      for (let p = 0; p < l; p++) {
        const g = p * (i + n), m = g + i, y = [h[0] + g * Math.cos(f) + c * Math.cos(f), h[1] + g * Math.sin(f) + c * Math.sin(f)], x = [h[0] + m * Math.cos(f) + c * Math.cos(f), h[1] + m * Math.sin(f) + c * Math.sin(f)];
        a.push(...this.helper.doubleLineOps(y[0], y[1], x[0], x[1], r));
      }
    }), a;
  }
}
class vv {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap, n = r.zigzagOffset < 0 ? i : r.zigzagOffset, a = nn(t, r = Object.assign({}, r, { hachureGap: i + n }));
    return { type: "fillSketch", ops: this.zigzagLines(a, n, r) };
  }
  zigzagLines(t, r, i) {
    const n = [];
    return t.forEach((a) => {
      const o = Wa(a), s = Math.round(o / (2 * r));
      let l = a[0], c = a[1];
      l[0] > c[0] && (l = a[1], c = a[0]);
      const h = Math.atan((c[1] - l[1]) / (c[0] - l[0]));
      for (let u = 0; u < s; u++) {
        const f = 2 * u * r, p = 2 * (u + 1) * r, g = Math.sqrt(2 * Math.pow(r, 2)), m = [l[0] + f * Math.cos(h), l[1] + f * Math.sin(h)], y = [l[0] + p * Math.cos(h), l[1] + p * Math.sin(h)], x = [m[0] + g * Math.cos(h + Math.PI / 4), m[1] + g * Math.sin(h + Math.PI / 4)];
        n.push(...this.helper.doubleLineOps(m[0], m[1], x[0], x[1], i), ...this.helper.doubleLineOps(x[0], x[1], y[0], y[1], i));
      }
    }), n;
  }
}
const Zt = {};
class Sv {
  constructor(t) {
    this.seed = t;
  }
  next() {
    return this.seed ? (2 ** 31 - 1 & (this.seed = Math.imul(48271, this.seed))) / 2 ** 31 : Math.random();
  }
}
const Tv = 0, ms = 1, th = 2, xn = { A: 7, a: 7, C: 6, c: 6, H: 1, h: 1, L: 2, l: 2, M: 2, m: 2, Q: 4, q: 4, S: 4, s: 4, T: 2, t: 2, V: 1, v: 1, Z: 0, z: 0 };
function ys(e, t) {
  return e.type === t;
}
function bl(e) {
  const t = [], r = function(o) {
    const s = new Array();
    for (; o !== ""; ) if (o.match(/^([ \t\r\n,]+)/)) o = o.substr(RegExp.$1.length);
    else if (o.match(/^([aAcChHlLmMqQsStTvVzZ])/)) s[s.length] = { type: Tv, text: RegExp.$1 }, o = o.substr(RegExp.$1.length);
    else {
      if (!o.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/)) return [];
      s[s.length] = { type: ms, text: `${parseFloat(RegExp.$1)}` }, o = o.substr(RegExp.$1.length);
    }
    return s[s.length] = { type: th, text: "" }, s;
  }(e);
  let i = "BOD", n = 0, a = r[n];
  for (; !ys(a, th); ) {
    let o = 0;
    const s = [];
    if (i === "BOD") {
      if (a.text !== "M" && a.text !== "m") return bl("M0,0" + e);
      n++, o = xn[a.text], i = a.text;
    } else ys(a, ms) ? o = xn[i] : (n++, o = xn[a.text], i = a.text);
    if (!(n + o < r.length)) throw new Error("Path data ended short");
    for (let l = n; l < n + o; l++) {
      const c = r[l];
      if (!ys(c, ms)) throw new Error("Param not a number: " + i + "," + c.text);
      s[s.length] = +c.text;
    }
    if (typeof xn[i] != "number") throw new Error("Bad segment: " + i);
    {
      const l = { key: i, data: s };
      t.push(l), n += o, a = r[n], i === "M" && (i = "L"), i === "m" && (i = "l");
    }
  }
  return t;
}
function bd(e) {
  let t = 0, r = 0, i = 0, n = 0;
  const a = [];
  for (const { key: o, data: s } of e) switch (o) {
    case "M":
      a.push({ key: "M", data: [...s] }), [t, r] = s, [i, n] = s;
      break;
    case "m":
      t += s[0], r += s[1], a.push({ key: "M", data: [t, r] }), i = t, n = r;
      break;
    case "L":
      a.push({ key: "L", data: [...s] }), [t, r] = s;
      break;
    case "l":
      t += s[0], r += s[1], a.push({ key: "L", data: [t, r] });
      break;
    case "C":
      a.push({ key: "C", data: [...s] }), t = s[4], r = s[5];
      break;
    case "c": {
      const l = s.map((c, h) => h % 2 ? c + r : c + t);
      a.push({ key: "C", data: l }), t = l[4], r = l[5];
      break;
    }
    case "Q":
      a.push({ key: "Q", data: [...s] }), t = s[2], r = s[3];
      break;
    case "q": {
      const l = s.map((c, h) => h % 2 ? c + r : c + t);
      a.push({ key: "Q", data: l }), t = l[2], r = l[3];
      break;
    }
    case "A":
      a.push({ key: "A", data: [...s] }), t = s[5], r = s[6];
      break;
    case "a":
      t += s[5], r += s[6], a.push({ key: "A", data: [s[0], s[1], s[2], s[3], s[4], t, r] });
      break;
    case "H":
      a.push({ key: "H", data: [...s] }), t = s[0];
      break;
    case "h":
      t += s[0], a.push({ key: "H", data: [t] });
      break;
    case "V":
      a.push({ key: "V", data: [...s] }), r = s[0];
      break;
    case "v":
      r += s[0], a.push({ key: "V", data: [r] });
      break;
    case "S":
      a.push({ key: "S", data: [...s] }), t = s[2], r = s[3];
      break;
    case "s": {
      const l = s.map((c, h) => h % 2 ? c + r : c + t);
      a.push({ key: "S", data: l }), t = l[2], r = l[3];
      break;
    }
    case "T":
      a.push({ key: "T", data: [...s] }), t = s[0], r = s[1];
      break;
    case "t":
      t += s[0], r += s[1], a.push({ key: "T", data: [t, r] });
      break;
    case "Z":
    case "z":
      a.push({ key: "Z", data: [] }), t = i, r = n;
  }
  return a;
}
function Cd(e) {
  const t = [];
  let r = "", i = 0, n = 0, a = 0, o = 0, s = 0, l = 0;
  for (const { key: c, data: h } of e) {
    switch (c) {
      case "M":
        t.push({ key: "M", data: [...h] }), [i, n] = h, [a, o] = h;
        break;
      case "C":
        t.push({ key: "C", data: [...h] }), i = h[4], n = h[5], s = h[2], l = h[3];
        break;
      case "L":
        t.push({ key: "L", data: [...h] }), [i, n] = h;
        break;
      case "H":
        i = h[0], t.push({ key: "L", data: [i, n] });
        break;
      case "V":
        n = h[0], t.push({ key: "L", data: [i, n] });
        break;
      case "S": {
        let u = 0, f = 0;
        r === "C" || r === "S" ? (u = i + (i - s), f = n + (n - l)) : (u = i, f = n), t.push({ key: "C", data: [u, f, ...h] }), s = h[0], l = h[1], i = h[2], n = h[3];
        break;
      }
      case "T": {
        const [u, f] = h;
        let p = 0, g = 0;
        r === "Q" || r === "T" ? (p = i + (i - s), g = n + (n - l)) : (p = i, g = n);
        const m = i + 2 * (p - i) / 3, y = n + 2 * (g - n) / 3, x = u + 2 * (p - u) / 3, b = f + 2 * (g - f) / 3;
        t.push({ key: "C", data: [m, y, x, b, u, f] }), s = p, l = g, i = u, n = f;
        break;
      }
      case "Q": {
        const [u, f, p, g] = h, m = i + 2 * (u - i) / 3, y = n + 2 * (f - n) / 3, x = p + 2 * (u - p) / 3, b = g + 2 * (f - g) / 3;
        t.push({ key: "C", data: [m, y, x, b, p, g] }), s = u, l = f, i = p, n = g;
        break;
      }
      case "A": {
        const u = Math.abs(h[0]), f = Math.abs(h[1]), p = h[2], g = h[3], m = h[4], y = h[5], x = h[6];
        u === 0 || f === 0 ? (t.push({ key: "C", data: [i, n, y, x, y, x] }), i = y, n = x) : (i !== y || n !== x) && (_d(i, n, y, x, u, f, p, g, m).forEach(function(b) {
          t.push({ key: "C", data: b });
        }), i = y, n = x);
        break;
      }
      case "Z":
        t.push({ key: "Z", data: [] }), i = a, n = o;
    }
    r = c;
  }
  return t;
}
function xi(e, t, r) {
  return [e * Math.cos(r) - t * Math.sin(r), e * Math.sin(r) + t * Math.cos(r)];
}
function _d(e, t, r, i, n, a, o, s, l, c) {
  const h = (u = o, Math.PI * u / 180);
  var u;
  let f = [], p = 0, g = 0, m = 0, y = 0;
  if (c) [p, g, m, y] = c;
  else {
    [e, t] = xi(e, t, -h), [r, i] = xi(r, i, -h);
    const O = (e - r) / 2, M = (t - i) / 2;
    let A = O * O / (n * n) + M * M / (a * a);
    A > 1 && (A = Math.sqrt(A), n *= A, a *= A);
    const B = n * n, E = a * a, L = B * E - B * M * M - E * O * O, W = B * M * M + E * O * O, X = (s === l ? -1 : 1) * Math.sqrt(Math.abs(L / W));
    m = X * n * M / a + (e + r) / 2, y = X * -a * O / n + (t + i) / 2, p = Math.asin(parseFloat(((t - y) / a).toFixed(9))), g = Math.asin(parseFloat(((i - y) / a).toFixed(9))), e < m && (p = Math.PI - p), r < m && (g = Math.PI - g), p < 0 && (p = 2 * Math.PI + p), g < 0 && (g = 2 * Math.PI + g), l && p > g && (p -= 2 * Math.PI), !l && g > p && (g -= 2 * Math.PI);
  }
  let x = g - p;
  if (Math.abs(x) > 120 * Math.PI / 180) {
    const O = g, M = r, A = i;
    g = l && g > p ? p + 120 * Math.PI / 180 * 1 : p + 120 * Math.PI / 180 * -1, f = _d(r = m + n * Math.cos(g), i = y + a * Math.sin(g), M, A, n, a, o, 0, l, [g, O, m, y]);
  }
  x = g - p;
  const b = Math.cos(p), _ = Math.sin(p), v = Math.cos(g), w = Math.sin(g), C = Math.tan(x / 4), S = 4 / 3 * n * C, D = 4 / 3 * a * C, P = [e, t], R = [e + S * _, t - D * b], $ = [r + S * w, i - D * v], z = [r, i];
  if (R[0] = 2 * P[0] - R[0], R[1] = 2 * P[1] - R[1], c) return [R, $, z].concat(f);
  {
    f = [R, $, z].concat(f);
    const O = [];
    for (let M = 0; M < f.length; M += 3) {
      const A = xi(f[M][0], f[M][1], h), B = xi(f[M + 1][0], f[M + 1][1], h), E = xi(f[M + 2][0], f[M + 2][1], h);
      O.push([A[0], A[1], B[0], B[1], E[0], E[1]]);
    }
    return O;
  }
}
const Bv = { randOffset: function(e, t) {
  return rt(e, t);
}, randOffsetWithRange: function(e, t, r) {
  return da(e, t, r);
}, ellipse: function(e, t, r, i, n) {
  const a = kd(r, i, n);
  return lo(e, t, n, a).opset;
}, doubleLineOps: function(e, t, r, i, n) {
  return Ge(e, t, r, i, n, !0);
} };
function wd(e, t, r, i, n) {
  return { type: "path", ops: Ge(e, t, r, i, n) };
}
function Fn(e, t, r) {
  const i = (e || []).length;
  if (i > 2) {
    const n = [];
    for (let a = 0; a < i - 1; a++) n.push(...Ge(e[a][0], e[a][1], e[a + 1][0], e[a + 1][1], r));
    return t && n.push(...Ge(e[i - 1][0], e[i - 1][1], e[0][0], e[0][1], r)), { type: "path", ops: n };
  }
  return i === 2 ? wd(e[0][0], e[0][1], e[1][0], e[1][1], r) : { type: "path", ops: [] };
}
function Av(e, t, r, i, n) {
  return function(a, o) {
    return Fn(a, !0, o);
  }([[e, t], [e + r, t], [e + r, t + i], [e, t + i]], n);
}
function eh(e, t) {
  if (e.length) {
    const r = typeof e[0][0] == "number" ? [e] : e, i = bn(r[0], 1 * (1 + 0.2 * t.roughness), t), n = t.disableMultiStroke ? [] : bn(r[0], 1.5 * (1 + 0.22 * t.roughness), nh(t));
    for (let a = 1; a < r.length; a++) {
      const o = r[a];
      if (o.length) {
        const s = bn(o, 1 * (1 + 0.2 * t.roughness), t), l = t.disableMultiStroke ? [] : bn(o, 1.5 * (1 + 0.22 * t.roughness), nh(t));
        for (const c of s) c.op !== "move" && i.push(c);
        for (const c of l) c.op !== "move" && n.push(c);
      }
    }
    return { type: "path", ops: i.concat(n) };
  }
  return { type: "path", ops: [] };
}
function kd(e, t, r) {
  const i = Math.sqrt(2 * Math.PI * Math.sqrt((Math.pow(e / 2, 2) + Math.pow(t / 2, 2)) / 2)), n = Math.ceil(Math.max(r.curveStepCount, r.curveStepCount / Math.sqrt(200) * i)), a = 2 * Math.PI / n;
  let o = Math.abs(e / 2), s = Math.abs(t / 2);
  const l = 1 - r.curveFitting;
  return o += rt(o * l, r), s += rt(s * l, r), { increment: a, rx: o, ry: s };
}
function lo(e, t, r, i) {
  const [n, a] = ah(i.increment, e, t, i.rx, i.ry, 1, i.increment * da(0.1, da(0.4, 1, r), r), r);
  let o = ga(n, null, r);
  if (!r.disableMultiStroke && r.roughness !== 0) {
    const [s] = ah(i.increment, e, t, i.rx, i.ry, 1.5, 0, r), l = ga(s, null, r);
    o = o.concat(l);
  }
  return { estimatedPoints: a, opset: { type: "path", ops: o } };
}
function rh(e, t, r, i, n, a, o, s, l) {
  const c = e, h = t;
  let u = Math.abs(r / 2), f = Math.abs(i / 2);
  u += rt(0.01 * u, l), f += rt(0.01 * f, l);
  let p = n, g = a;
  for (; p < 0; ) p += 2 * Math.PI, g += 2 * Math.PI;
  g - p > 2 * Math.PI && (p = 0, g = 2 * Math.PI);
  const m = 2 * Math.PI / l.curveStepCount, y = Math.min(m / 2, (g - p) / 2), x = sh(y, c, h, u, f, p, g, 1, l);
  if (!l.disableMultiStroke) {
    const b = sh(y, c, h, u, f, p, g, 1.5, l);
    x.push(...b);
  }
  return o && (s ? x.push(...Ge(c, h, c + u * Math.cos(p), h + f * Math.sin(p), l), ...Ge(c, h, c + u * Math.cos(g), h + f * Math.sin(g), l)) : x.push({ op: "lineTo", data: [c, h] }, { op: "lineTo", data: [c + u * Math.cos(p), h + f * Math.sin(p)] })), { type: "path", ops: x };
}
function ih(e, t) {
  const r = Cd(bd(bl(e))), i = [];
  let n = [0, 0], a = [0, 0];
  for (const { key: o, data: s } of r) switch (o) {
    case "M":
      a = [s[0], s[1]], n = [s[0], s[1]];
      break;
    case "L":
      i.push(...Ge(a[0], a[1], s[0], s[1], t)), a = [s[0], s[1]];
      break;
    case "C": {
      const [l, c, h, u, f, p] = s;
      i.push(...Lv(l, c, h, u, f, p, a, t)), a = [f, p];
      break;
    }
    case "Z":
      i.push(...Ge(a[0], a[1], n[0], n[1], t)), a = [n[0], n[1]];
  }
  return { type: "path", ops: i };
}
function xs(e, t) {
  const r = [];
  for (const i of e) if (i.length) {
    const n = t.maxRandomnessOffset || 0, a = i.length;
    if (a > 2) {
      r.push({ op: "move", data: [i[0][0] + rt(n, t), i[0][1] + rt(n, t)] });
      for (let o = 1; o < a; o++) r.push({ op: "lineTo", data: [i[o][0] + rt(n, t), i[o][1] + rt(n, t)] });
    }
  }
  return { type: "fillPath", ops: r };
}
function $r(e, t) {
  return function(r, i) {
    let n = r.fillStyle || "hachure";
    if (!Zt[n]) switch (n) {
      case "zigzag":
        Zt[n] || (Zt[n] = new Cv(i));
        break;
      case "cross-hatch":
        Zt[n] || (Zt[n] = new _v(i));
        break;
      case "dots":
        Zt[n] || (Zt[n] = new wv(i));
        break;
      case "dashed":
        Zt[n] || (Zt[n] = new kv(i));
        break;
      case "zigzag-line":
        Zt[n] || (Zt[n] = new vv(i));
        break;
      default:
        n = "hachure", Zt[n] || (Zt[n] = new xl(i));
    }
    return Zt[n];
  }(t, Bv).fillPolygons(e, t);
}
function nh(e) {
  const t = Object.assign({}, e);
  return t.randomizer = void 0, e.seed && (t.seed = e.seed + 1), t;
}
function vd(e) {
  return e.randomizer || (e.randomizer = new Sv(e.seed || 0)), e.randomizer.next();
}
function da(e, t, r, i = 1) {
  return r.roughness * i * (vd(r) * (t - e) + e);
}
function rt(e, t, r = 1) {
  return da(-e, e, t, r);
}
function Ge(e, t, r, i, n, a = !1) {
  const o = a ? n.disableMultiStrokeFill : n.disableMultiStroke, s = co(e, t, r, i, n, !0, !1);
  if (o) return s;
  const l = co(e, t, r, i, n, !0, !0);
  return s.concat(l);
}
function co(e, t, r, i, n, a, o) {
  const s = Math.pow(e - r, 2) + Math.pow(t - i, 2), l = Math.sqrt(s);
  let c = 1;
  c = l < 200 ? 1 : l > 500 ? 0.4 : -16668e-7 * l + 1.233334;
  let h = n.maxRandomnessOffset || 0;
  h * h * 100 > s && (h = l / 10);
  const u = h / 2, f = 0.2 + 0.2 * vd(n);
  let p = n.bowing * n.maxRandomnessOffset * (i - t) / 200, g = n.bowing * n.maxRandomnessOffset * (e - r) / 200;
  p = rt(p, n, c), g = rt(g, n, c);
  const m = [], y = () => rt(u, n, c), x = () => rt(h, n, c), b = n.preserveVertices;
  return o ? m.push({ op: "move", data: [e + (b ? 0 : y()), t + (b ? 0 : y())] }) : m.push({ op: "move", data: [e + (b ? 0 : rt(h, n, c)), t + (b ? 0 : rt(h, n, c))] }), o ? m.push({ op: "bcurveTo", data: [p + e + (r - e) * f + y(), g + t + (i - t) * f + y(), p + e + 2 * (r - e) * f + y(), g + t + 2 * (i - t) * f + y(), r + (b ? 0 : y()), i + (b ? 0 : y())] }) : m.push({ op: "bcurveTo", data: [p + e + (r - e) * f + x(), g + t + (i - t) * f + x(), p + e + 2 * (r - e) * f + x(), g + t + 2 * (i - t) * f + x(), r + (b ? 0 : x()), i + (b ? 0 : x())] }), m;
}
function bn(e, t, r) {
  if (!e.length) return [];
  const i = [];
  i.push([e[0][0] + rt(t, r), e[0][1] + rt(t, r)]), i.push([e[0][0] + rt(t, r), e[0][1] + rt(t, r)]);
  for (let n = 1; n < e.length; n++) i.push([e[n][0] + rt(t, r), e[n][1] + rt(t, r)]), n === e.length - 1 && i.push([e[n][0] + rt(t, r), e[n][1] + rt(t, r)]);
  return ga(i, null, r);
}
function ga(e, t, r) {
  const i = e.length, n = [];
  if (i > 3) {
    const a = [], o = 1 - r.curveTightness;
    n.push({ op: "move", data: [e[1][0], e[1][1]] });
    for (let s = 1; s + 2 < i; s++) {
      const l = e[s];
      a[0] = [l[0], l[1]], a[1] = [l[0] + (o * e[s + 1][0] - o * e[s - 1][0]) / 6, l[1] + (o * e[s + 1][1] - o * e[s - 1][1]) / 6], a[2] = [e[s + 1][0] + (o * e[s][0] - o * e[s + 2][0]) / 6, e[s + 1][1] + (o * e[s][1] - o * e[s + 2][1]) / 6], a[3] = [e[s + 1][0], e[s + 1][1]], n.push({ op: "bcurveTo", data: [a[1][0], a[1][1], a[2][0], a[2][1], a[3][0], a[3][1]] });
    }
  } else i === 3 ? (n.push({ op: "move", data: [e[1][0], e[1][1]] }), n.push({ op: "bcurveTo", data: [e[1][0], e[1][1], e[2][0], e[2][1], e[2][0], e[2][1]] })) : i === 2 && n.push(...co(e[0][0], e[0][1], e[1][0], e[1][1], r, !0, !0));
  return n;
}
function ah(e, t, r, i, n, a, o, s) {
  const l = [], c = [];
  if (s.roughness === 0) {
    e /= 4, c.push([t + i * Math.cos(-e), r + n * Math.sin(-e)]);
    for (let h = 0; h <= 2 * Math.PI; h += e) {
      const u = [t + i * Math.cos(h), r + n * Math.sin(h)];
      l.push(u), c.push(u);
    }
    c.push([t + i * Math.cos(0), r + n * Math.sin(0)]), c.push([t + i * Math.cos(e), r + n * Math.sin(e)]);
  } else {
    const h = rt(0.5, s) - Math.PI / 2;
    c.push([rt(a, s) + t + 0.9 * i * Math.cos(h - e), rt(a, s) + r + 0.9 * n * Math.sin(h - e)]);
    const u = 2 * Math.PI + h - 0.01;
    for (let f = h; f < u; f += e) {
      const p = [rt(a, s) + t + i * Math.cos(f), rt(a, s) + r + n * Math.sin(f)];
      l.push(p), c.push(p);
    }
    c.push([rt(a, s) + t + i * Math.cos(h + 2 * Math.PI + 0.5 * o), rt(a, s) + r + n * Math.sin(h + 2 * Math.PI + 0.5 * o)]), c.push([rt(a, s) + t + 0.98 * i * Math.cos(h + o), rt(a, s) + r + 0.98 * n * Math.sin(h + o)]), c.push([rt(a, s) + t + 0.9 * i * Math.cos(h + 0.5 * o), rt(a, s) + r + 0.9 * n * Math.sin(h + 0.5 * o)]);
  }
  return [c, l];
}
function sh(e, t, r, i, n, a, o, s, l) {
  const c = a + rt(0.1, l), h = [];
  h.push([rt(s, l) + t + 0.9 * i * Math.cos(c - e), rt(s, l) + r + 0.9 * n * Math.sin(c - e)]);
  for (let u = c; u <= o; u += e) h.push([rt(s, l) + t + i * Math.cos(u), rt(s, l) + r + n * Math.sin(u)]);
  return h.push([t + i * Math.cos(o), r + n * Math.sin(o)]), h.push([t + i * Math.cos(o), r + n * Math.sin(o)]), ga(h, null, l);
}
function Lv(e, t, r, i, n, a, o, s) {
  const l = [], c = [s.maxRandomnessOffset || 1, (s.maxRandomnessOffset || 1) + 0.3];
  let h = [0, 0];
  const u = s.disableMultiStroke ? 1 : 2, f = s.preserveVertices;
  for (let p = 0; p < u; p++) p === 0 ? l.push({ op: "move", data: [o[0], o[1]] }) : l.push({ op: "move", data: [o[0] + (f ? 0 : rt(c[0], s)), o[1] + (f ? 0 : rt(c[0], s))] }), h = f ? [n, a] : [n + rt(c[p], s), a + rt(c[p], s)], l.push({ op: "bcurveTo", data: [e + rt(c[p], s), t + rt(c[p], s), r + rt(c[p], s), i + rt(c[p], s), h[0], h[1]] });
  return l;
}
function bi(e) {
  return [...e];
}
function oh(e, t = 0) {
  const r = e.length;
  if (r < 3) throw new Error("A curve must have at least three points.");
  const i = [];
  if (r === 3) i.push(bi(e[0]), bi(e[1]), bi(e[2]), bi(e[2]));
  else {
    const n = [];
    n.push(e[0], e[0]);
    for (let s = 1; s < e.length; s++) n.push(e[s]), s === e.length - 1 && n.push(e[s]);
    const a = [], o = 1 - t;
    i.push(bi(n[0]));
    for (let s = 1; s + 2 < n.length; s++) {
      const l = n[s];
      a[0] = [l[0], l[1]], a[1] = [l[0] + (o * n[s + 1][0] - o * n[s - 1][0]) / 6, l[1] + (o * n[s + 1][1] - o * n[s - 1][1]) / 6], a[2] = [n[s + 1][0] + (o * n[s][0] - o * n[s + 2][0]) / 6, n[s + 1][1] + (o * n[s][1] - o * n[s + 2][1]) / 6], a[3] = [n[s + 1][0], n[s + 1][1]], i.push(a[1], a[2], a[3]);
    }
  }
  return i;
}
function Dn(e, t) {
  return Math.pow(e[0] - t[0], 2) + Math.pow(e[1] - t[1], 2);
}
function Mv(e, t, r) {
  const i = Dn(t, r);
  if (i === 0) return Dn(e, t);
  let n = ((e[0] - t[0]) * (r[0] - t[0]) + (e[1] - t[1]) * (r[1] - t[1])) / i;
  return n = Math.max(0, Math.min(1, n)), Dn(e, ir(t, r, n));
}
function ir(e, t, r) {
  return [e[0] + (t[0] - e[0]) * r, e[1] + (t[1] - e[1]) * r];
}
function ho(e, t, r, i) {
  const n = i || [];
  if (function(s, l) {
    const c = s[l + 0], h = s[l + 1], u = s[l + 2], f = s[l + 3];
    let p = 3 * h[0] - 2 * c[0] - f[0];
    p *= p;
    let g = 3 * h[1] - 2 * c[1] - f[1];
    g *= g;
    let m = 3 * u[0] - 2 * f[0] - c[0];
    m *= m;
    let y = 3 * u[1] - 2 * f[1] - c[1];
    return y *= y, p < m && (p = m), g < y && (g = y), p + g;
  }(e, t) < r) {
    const s = e[t + 0];
    n.length ? (a = n[n.length - 1], o = s, Math.sqrt(Dn(a, o)) > 1 && n.push(s)) : n.push(s), n.push(e[t + 3]);
  } else {
    const l = e[t + 0], c = e[t + 1], h = e[t + 2], u = e[t + 3], f = ir(l, c, 0.5), p = ir(c, h, 0.5), g = ir(h, u, 0.5), m = ir(f, p, 0.5), y = ir(p, g, 0.5), x = ir(m, y, 0.5);
    ho([l, f, m, x], 0, r, n), ho([x, y, g, u], 0, r, n);
  }
  var a, o;
  return n;
}
function $v(e, t) {
  return ma(e, 0, e.length, t);
}
function ma(e, t, r, i, n) {
  const a = n || [], o = e[t], s = e[r - 1];
  let l = 0, c = 1;
  for (let h = t + 1; h < r - 1; ++h) {
    const u = Mv(e[h], o, s);
    u > l && (l = u, c = h);
  }
  return Math.sqrt(l) > i ? (ma(e, t, c + 1, i, a), ma(e, c, r, i, a)) : (a.length || a.push(o), a.push(s)), a;
}
function bs(e, t = 0.15, r) {
  const i = [], n = (e.length - 1) / 3;
  for (let a = 0; a < n; a++)
    ho(e, 3 * a, t, i);
  return r && r > 0 ? ma(i, 0, i.length, r) : i;
}
const te = "none";
class ya {
  constructor(t) {
    this.defaultOptions = { maxRandomnessOffset: 2, roughness: 1, bowing: 1, stroke: "#000", strokeWidth: 1, curveTightness: 0, curveFitting: 0.95, curveStepCount: 9, fillStyle: "hachure", fillWeight: -1, hachureAngle: -41, hachureGap: -1, dashOffset: -1, dashGap: -1, zigzagOffset: -1, seed: 0, disableMultiStroke: !1, disableMultiStrokeFill: !1, preserveVertices: !1, fillShapeRoughnessGain: 0.8 }, this.config = t || {}, this.config.options && (this.defaultOptions = this._o(this.config.options));
  }
  static newSeed() {
    return Math.floor(Math.random() * 2 ** 31);
  }
  _o(t) {
    return t ? Object.assign({}, this.defaultOptions, t) : this.defaultOptions;
  }
  _d(t, r, i) {
    return { shape: t, sets: r || [], options: i || this.defaultOptions };
  }
  line(t, r, i, n, a) {
    const o = this._o(a);
    return this._d("line", [wd(t, r, i, n, o)], o);
  }
  rectangle(t, r, i, n, a) {
    const o = this._o(a), s = [], l = Av(t, r, i, n, o);
    if (o.fill) {
      const c = [[t, r], [t + i, r], [t + i, r + n], [t, r + n]];
      o.fillStyle === "solid" ? s.push(xs([c], o)) : s.push($r([c], o));
    }
    return o.stroke !== te && s.push(l), this._d("rectangle", s, o);
  }
  ellipse(t, r, i, n, a) {
    const o = this._o(a), s = [], l = kd(i, n, o), c = lo(t, r, o, l);
    if (o.fill) if (o.fillStyle === "solid") {
      const h = lo(t, r, o, l).opset;
      h.type = "fillPath", s.push(h);
    } else s.push($r([c.estimatedPoints], o));
    return o.stroke !== te && s.push(c.opset), this._d("ellipse", s, o);
  }
  circle(t, r, i, n) {
    const a = this.ellipse(t, r, i, i, n);
    return a.shape = "circle", a;
  }
  linearPath(t, r) {
    const i = this._o(r);
    return this._d("linearPath", [Fn(t, !1, i)], i);
  }
  arc(t, r, i, n, a, o, s = !1, l) {
    const c = this._o(l), h = [], u = rh(t, r, i, n, a, o, s, !0, c);
    if (s && c.fill) if (c.fillStyle === "solid") {
      const f = Object.assign({}, c);
      f.disableMultiStroke = !0;
      const p = rh(t, r, i, n, a, o, !0, !1, f);
      p.type = "fillPath", h.push(p);
    } else h.push(function(f, p, g, m, y, x, b) {
      const _ = f, v = p;
      let w = Math.abs(g / 2), C = Math.abs(m / 2);
      w += rt(0.01 * w, b), C += rt(0.01 * C, b);
      let S = y, D = x;
      for (; S < 0; ) S += 2 * Math.PI, D += 2 * Math.PI;
      D - S > 2 * Math.PI && (S = 0, D = 2 * Math.PI);
      const P = (D - S) / b.curveStepCount, R = [];
      for (let $ = S; $ <= D; $ += P) R.push([_ + w * Math.cos($), v + C * Math.sin($)]);
      return R.push([_ + w * Math.cos(D), v + C * Math.sin(D)]), R.push([_, v]), $r([R], b);
    }(t, r, i, n, a, o, c));
    return c.stroke !== te && h.push(u), this._d("arc", h, c);
  }
  curve(t, r) {
    const i = this._o(r), n = [], a = eh(t, i);
    if (i.fill && i.fill !== te) if (i.fillStyle === "solid") {
      const o = eh(t, Object.assign(Object.assign({}, i), { disableMultiStroke: !0, roughness: i.roughness ? i.roughness + i.fillShapeRoughnessGain : 0 }));
      n.push({ type: "fillPath", ops: this._mergedShape(o.ops) });
    } else {
      const o = [], s = t;
      if (s.length) {
        const l = typeof s[0][0] == "number" ? [s] : s;
        for (const c of l) c.length < 3 ? o.push(...c) : c.length === 3 ? o.push(...bs(oh([c[0], c[0], c[1], c[2]]), 10, (1 + i.roughness) / 2)) : o.push(...bs(oh(c), 10, (1 + i.roughness) / 2));
      }
      o.length && n.push($r([o], i));
    }
    return i.stroke !== te && n.push(a), this._d("curve", n, i);
  }
  polygon(t, r) {
    const i = this._o(r), n = [], a = Fn(t, !0, i);
    return i.fill && (i.fillStyle === "solid" ? n.push(xs([t], i)) : n.push($r([t], i))), i.stroke !== te && n.push(a), this._d("polygon", n, i);
  }
  path(t, r) {
    const i = this._o(r), n = [];
    if (!t) return this._d("path", n, i);
    t = (t || "").replace(/\n/g, " ").replace(/(-\s)/g, "-").replace("/(ss)/g", " ");
    const a = i.fill && i.fill !== "transparent" && i.fill !== te, o = i.stroke !== te, s = !!(i.simplification && i.simplification < 1), l = function(h, u, f) {
      const p = Cd(bd(bl(h))), g = [];
      let m = [], y = [0, 0], x = [];
      const b = () => {
        x.length >= 4 && m.push(...bs(x, u)), x = [];
      }, _ = () => {
        b(), m.length && (g.push(m), m = []);
      };
      for (const { key: w, data: C } of p) switch (w) {
        case "M":
          _(), y = [C[0], C[1]], m.push(y);
          break;
        case "L":
          b(), m.push([C[0], C[1]]);
          break;
        case "C":
          if (!x.length) {
            const S = m.length ? m[m.length - 1] : y;
            x.push([S[0], S[1]]);
          }
          x.push([C[0], C[1]]), x.push([C[2], C[3]]), x.push([C[4], C[5]]);
          break;
        case "Z":
          b(), m.push([y[0], y[1]]);
      }
      if (_(), !f) return g;
      const v = [];
      for (const w of g) {
        const C = $v(w, f);
        C.length && v.push(C);
      }
      return v;
    }(t, 1, s ? 4 - 4 * (i.simplification || 1) : (1 + i.roughness) / 2), c = ih(t, i);
    if (a) if (i.fillStyle === "solid") if (l.length === 1) {
      const h = ih(t, Object.assign(Object.assign({}, i), { disableMultiStroke: !0, roughness: i.roughness ? i.roughness + i.fillShapeRoughnessGain : 0 }));
      n.push({ type: "fillPath", ops: this._mergedShape(h.ops) });
    } else n.push(xs(l, i));
    else n.push($r(l, i));
    return o && (s ? l.forEach((h) => {
      n.push(Fn(h, !1, i));
    }) : n.push(c)), this._d("path", n, i);
  }
  opsToPath(t, r) {
    let i = "";
    for (const n of t.ops) {
      const a = typeof r == "number" && r >= 0 ? n.data.map((o) => +o.toFixed(r)) : n.data;
      switch (n.op) {
        case "move":
          i += `M${a[0]} ${a[1]} `;
          break;
        case "bcurveTo":
          i += `C${a[0]} ${a[1]}, ${a[2]} ${a[3]}, ${a[4]} ${a[5]} `;
          break;
        case "lineTo":
          i += `L${a[0]} ${a[1]} `;
      }
    }
    return i.trim();
  }
  toPaths(t) {
    const r = t.sets || [], i = t.options || this.defaultOptions, n = [];
    for (const a of r) {
      let o = null;
      switch (a.type) {
        case "path":
          o = { d: this.opsToPath(a), stroke: i.stroke, strokeWidth: i.strokeWidth, fill: te };
          break;
        case "fillPath":
          o = { d: this.opsToPath(a), stroke: te, strokeWidth: 0, fill: i.fill || te };
          break;
        case "fillSketch":
          o = this.fillSketch(a, i);
      }
      o && n.push(o);
    }
    return n;
  }
  fillSketch(t, r) {
    let i = r.fillWeight;
    return i < 0 && (i = r.strokeWidth / 2), { d: this.opsToPath(t), stroke: r.fill || te, strokeWidth: i, fill: te };
  }
  _mergedShape(t) {
    return t.filter((r, i) => i === 0 || r.op !== "move");
  }
}
class Ev {
  constructor(t, r) {
    this.canvas = t, this.ctx = this.canvas.getContext("2d"), this.gen = new ya(r);
  }
  draw(t) {
    const r = t.sets || [], i = t.options || this.getDefaultOptions(), n = this.ctx, a = t.options.fixedDecimalPlaceDigits;
    for (const o of r) switch (o.type) {
      case "path":
        n.save(), n.strokeStyle = i.stroke === "none" ? "transparent" : i.stroke, n.lineWidth = i.strokeWidth, i.strokeLineDash && n.setLineDash(i.strokeLineDash), i.strokeLineDashOffset && (n.lineDashOffset = i.strokeLineDashOffset), this._drawToContext(n, o, a), n.restore();
        break;
      case "fillPath": {
        n.save(), n.fillStyle = i.fill || "";
        const s = t.shape === "curve" || t.shape === "polygon" || t.shape === "path" ? "evenodd" : "nonzero";
        this._drawToContext(n, o, a, s), n.restore();
        break;
      }
      case "fillSketch":
        this.fillSketch(n, o, i);
    }
  }
  fillSketch(t, r, i) {
    let n = i.fillWeight;
    n < 0 && (n = i.strokeWidth / 2), t.save(), i.fillLineDash && t.setLineDash(i.fillLineDash), i.fillLineDashOffset && (t.lineDashOffset = i.fillLineDashOffset), t.strokeStyle = i.fill || "", t.lineWidth = n, this._drawToContext(t, r, i.fixedDecimalPlaceDigits), t.restore();
  }
  _drawToContext(t, r, i, n = "nonzero") {
    t.beginPath();
    for (const a of r.ops) {
      const o = typeof i == "number" && i >= 0 ? a.data.map((s) => +s.toFixed(i)) : a.data;
      switch (a.op) {
        case "move":
          t.moveTo(o[0], o[1]);
          break;
        case "bcurveTo":
          t.bezierCurveTo(o[0], o[1], o[2], o[3], o[4], o[5]);
          break;
        case "lineTo":
          t.lineTo(o[0], o[1]);
      }
    }
    r.type === "fillPath" ? t.fill(n) : t.stroke();
  }
  get generator() {
    return this.gen;
  }
  getDefaultOptions() {
    return this.gen.defaultOptions;
  }
  line(t, r, i, n, a) {
    const o = this.gen.line(t, r, i, n, a);
    return this.draw(o), o;
  }
  rectangle(t, r, i, n, a) {
    const o = this.gen.rectangle(t, r, i, n, a);
    return this.draw(o), o;
  }
  ellipse(t, r, i, n, a) {
    const o = this.gen.ellipse(t, r, i, n, a);
    return this.draw(o), o;
  }
  circle(t, r, i, n) {
    const a = this.gen.circle(t, r, i, n);
    return this.draw(a), a;
  }
  linearPath(t, r) {
    const i = this.gen.linearPath(t, r);
    return this.draw(i), i;
  }
  polygon(t, r) {
    const i = this.gen.polygon(t, r);
    return this.draw(i), i;
  }
  arc(t, r, i, n, a, o, s = !1, l) {
    const c = this.gen.arc(t, r, i, n, a, o, s, l);
    return this.draw(c), c;
  }
  curve(t, r) {
    const i = this.gen.curve(t, r);
    return this.draw(i), i;
  }
  path(t, r) {
    const i = this.gen.path(t, r);
    return this.draw(i), i;
  }
}
const Cn = "http://www.w3.org/2000/svg";
class Fv {
  constructor(t, r) {
    this.svg = t, this.gen = new ya(r);
  }
  draw(t) {
    const r = t.sets || [], i = t.options || this.getDefaultOptions(), n = this.svg.ownerDocument || window.document, a = n.createElementNS(Cn, "g"), o = t.options.fixedDecimalPlaceDigits;
    for (const s of r) {
      let l = null;
      switch (s.type) {
        case "path":
          l = n.createElementNS(Cn, "path"), l.setAttribute("d", this.opsToPath(s, o)), l.setAttribute("stroke", i.stroke), l.setAttribute("stroke-width", i.strokeWidth + ""), l.setAttribute("fill", "none"), i.strokeLineDash && l.setAttribute("stroke-dasharray", i.strokeLineDash.join(" ").trim()), i.strokeLineDashOffset && l.setAttribute("stroke-dashoffset", `${i.strokeLineDashOffset}`);
          break;
        case "fillPath":
          l = n.createElementNS(Cn, "path"), l.setAttribute("d", this.opsToPath(s, o)), l.setAttribute("stroke", "none"), l.setAttribute("stroke-width", "0"), l.setAttribute("fill", i.fill || ""), t.shape !== "curve" && t.shape !== "polygon" || l.setAttribute("fill-rule", "evenodd");
          break;
        case "fillSketch":
          l = this.fillSketch(n, s, i);
      }
      l && a.appendChild(l);
    }
    return a;
  }
  fillSketch(t, r, i) {
    let n = i.fillWeight;
    n < 0 && (n = i.strokeWidth / 2);
    const a = t.createElementNS(Cn, "path");
    return a.setAttribute("d", this.opsToPath(r, i.fixedDecimalPlaceDigits)), a.setAttribute("stroke", i.fill || ""), a.setAttribute("stroke-width", n + ""), a.setAttribute("fill", "none"), i.fillLineDash && a.setAttribute("stroke-dasharray", i.fillLineDash.join(" ").trim()), i.fillLineDashOffset && a.setAttribute("stroke-dashoffset", `${i.fillLineDashOffset}`), a;
  }
  get generator() {
    return this.gen;
  }
  getDefaultOptions() {
    return this.gen.defaultOptions;
  }
  opsToPath(t, r) {
    return this.gen.opsToPath(t, r);
  }
  line(t, r, i, n, a) {
    const o = this.gen.line(t, r, i, n, a);
    return this.draw(o);
  }
  rectangle(t, r, i, n, a) {
    const o = this.gen.rectangle(t, r, i, n, a);
    return this.draw(o);
  }
  ellipse(t, r, i, n, a) {
    const o = this.gen.ellipse(t, r, i, n, a);
    return this.draw(o);
  }
  circle(t, r, i, n) {
    const a = this.gen.circle(t, r, i, n);
    return this.draw(a);
  }
  linearPath(t, r) {
    const i = this.gen.linearPath(t, r);
    return this.draw(i);
  }
  polygon(t, r) {
    const i = this.gen.polygon(t, r);
    return this.draw(i);
  }
  arc(t, r, i, n, a, o, s = !1, l) {
    const c = this.gen.arc(t, r, i, n, a, o, s, l);
    return this.draw(c);
  }
  curve(t, r) {
    const i = this.gen.curve(t, r);
    return this.draw(i);
  }
  path(t, r) {
    const i = this.gen.path(t, r);
    return this.draw(i);
  }
}
var Y = { canvas: (e, t) => new Ev(e, t), svg: (e, t) => new Fv(e, t), generator: (e) => new ya(e), newSeed: () => ya.newSeed() }, et = /* @__PURE__ */ d(async (e, t, r) => {
  var u, f;
  let i;
  const n = t.useHtmlLabels || Lt((u = pt()) == null ? void 0 : u.htmlLabels);
  r ? i = r : i = "node default";
  const a = e.insert("g").attr("class", i).attr("id", t.domId || t.id), o = a.insert("g").attr("class", "label").attr("style", Wt(t.labelStyle));
  let s;
  t.label === void 0 ? s = "" : s = typeof t.label == "string" ? t.label : t.label[0];
  const l = await Ze(o, se(wr(s), pt()), {
    useHtmlLabels: n,
    width: t.width || ((f = pt().flowchart) == null ? void 0 : f.wrappingWidth),
    // @ts-expect-error -- This is currently not used. Should this be `classes` instead?
    cssClasses: "markdown-node-label",
    style: t.labelStyle,
    addSvgBackground: !!t.icon || !!t.img
  });
  let c = l.getBBox();
  const h = ((t == null ? void 0 : t.padding) ?? 0) / 2;
  if (n) {
    const p = l.children[0], g = ht(l), m = p.getElementsByTagName("img");
    if (m) {
      const y = s.replace(/<img[^>]*>/g, "").trim() === "";
      await Promise.all(
        [...m].map(
          (x) => new Promise((b) => {
            function _() {
              if (x.style.display = "flex", x.style.flexDirection = "column", y) {
                const v = pt().fontSize ? pt().fontSize : window.getComputedStyle(document.body).fontSize, w = 5, [C = Rh.fontSize] = Ra(v), S = C * w + "px";
                x.style.minWidth = S, x.style.maxWidth = S;
              } else
                x.style.width = "100%";
              b(x);
            }
            d(_, "setupImage"), setTimeout(() => {
              x.complete && _();
            }), x.addEventListener("error", _), x.addEventListener("load", _);
          })
        )
      );
    }
    c = p.getBoundingClientRect(), g.attr("width", c.width), g.attr("height", c.height);
  }
  return n ? o.attr("transform", "translate(" + -c.width / 2 + ", " + -c.height / 2 + ")") : o.attr("transform", "translate(0, " + -c.height / 2 + ")"), t.centerLabel && o.attr("transform", "translate(" + -c.width / 2 + ", " + -c.height / 2 + ")"), o.insert("rect", ":first-child"), { shapeSvg: a, bbox: c, halfPadding: h, label: o };
}, "labelHelper"), Cs = /* @__PURE__ */ d(async (e, t, r) => {
  var l, c, h, u, f, p;
  const i = r.useHtmlLabels || Lt((c = (l = pt()) == null ? void 0 : l.flowchart) == null ? void 0 : c.htmlLabels), n = e.insert("g").attr("class", "label").attr("style", r.labelStyle || ""), a = await Ze(n, se(wr(t), pt()), {
    useHtmlLabels: i,
    width: r.width || ((u = (h = pt()) == null ? void 0 : h.flowchart) == null ? void 0 : u.wrappingWidth),
    style: r.labelStyle,
    addSvgBackground: !!r.icon || !!r.img
  });
  let o = a.getBBox();
  const s = r.padding / 2;
  if (Lt((p = (f = pt()) == null ? void 0 : f.flowchart) == null ? void 0 : p.htmlLabels)) {
    const g = a.children[0], m = ht(a);
    o = g.getBoundingClientRect(), m.attr("width", o.width), m.attr("height", o.height);
  }
  return i ? n.attr("transform", "translate(" + -o.width / 2 + ", " + -o.height / 2 + ")") : n.attr("transform", "translate(0, " + -o.height / 2 + ")"), r.centerLabel && n.attr("transform", "translate(" + -o.width / 2 + ", " + -o.height / 2 + ")"), n.insert("rect", ":first-child"), { shapeSvg: e, bbox: o, halfPadding: s, label: n };
}, "insertLabel"), V = /* @__PURE__ */ d((e, t) => {
  const r = t.node().getBBox();
  e.width = r.width, e.height = r.height;
}, "updateNodeBounds"), tt = /* @__PURE__ */ d((e, t) => (e.look === "handDrawn" ? "rough-node" : "node") + " " + e.cssClasses + " " + (t || ""), "getNodeClasses");
function lt(e) {
  const t = e.map((r, i) => `${i === 0 ? "M" : "L"}${r.x},${r.y}`);
  return t.push("Z"), t.join(" ");
}
d(lt, "createPathFromPoints");
function Xe(e, t, r, i, n, a) {
  const o = [], l = r - e, c = i - t, h = l / a, u = 2 * Math.PI / h, f = t + c / 2;
  for (let p = 0; p <= 50; p++) {
    const g = p / 50, m = e + g * l, y = f + n * Math.sin(u * (m - e));
    o.push({ x: m, y });
  }
  return o;
}
d(Xe, "generateFullSineWavePoints");
function Yi(e, t, r, i, n, a) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, p = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: -p, y: -g });
  }
  return o;
}
d(Yi, "generateCirclePoints");
var Dv = /* @__PURE__ */ d((e, t) => {
  var r = e.x, i = e.y, n = t.x - r, a = t.y - i, o = e.width / 2, s = e.height / 2, l, c;
  return Math.abs(a) * o > Math.abs(n) * s ? (a < 0 && (s = -s), l = a === 0 ? 0 : s * n / a, c = s) : (n < 0 && (o = -o), l = o, c = n === 0 ? 0 : o * a / n), { x: r + l, y: i + c };
}, "intersectRect"), ai = Dv;
function Sd(e, t) {
  t && e.attr("style", t);
}
d(Sd, "applyStyle");
async function Td(e) {
  const t = ht(document.createElementNS("http://www.w3.org/2000/svg", "foreignObject")), r = t.append("xhtml:div"), i = pt();
  let n = e.label;
  e.label && Xr(e.label) && (n = await So(e.label.replace(ei.lineBreakRegex, `
`), i));
  const o = '<span class="' + (e.isNode ? "nodeLabel" : "edgeLabel") + '" ' + (e.labelStyle ? 'style="' + e.labelStyle + '"' : "") + // codeql [js/html-constructed-from-input] : false positive
  ">" + n + "</span>";
  return r.html(se(o, i)), Sd(r, e.labelStyle), r.style("display", "inline-block"), r.style("padding-right", "1px"), r.style("white-space", "nowrap"), r.attr("xmlns", "http://www.w3.org/1999/xhtml"), t.node();
}
d(Td, "addHtmlLabel");
var Ov = /* @__PURE__ */ d(async (e, t, r, i) => {
  let n = e || "";
  if (typeof n == "object" && (n = n[0]), Lt(pt().flowchart.htmlLabels)) {
    n = n.replace(/\\n|\n/g, "<br />"), F.info("vertexText" + n);
    const a = {
      isNode: i,
      label: wr(n).replace(
        /fa[blrs]?:fa-[\w-]+/g,
        (s) => `<i class='${s.replace(":", " ")}'></i>`
      ),
      labelStyle: t && t.replace("fill:", "color:")
    };
    return await Td(a);
  } else {
    const a = document.createElementNS("http://www.w3.org/2000/svg", "text");
    a.setAttribute("style", t.replace("color:", "fill:"));
    let o = [];
    typeof n == "string" ? o = n.split(/\\n|\n|<br\s*\/?>/gi) : Array.isArray(n) ? o = n : o = [];
    for (const s of o) {
      const l = document.createElementNS("http://www.w3.org/2000/svg", "tspan");
      l.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve"), l.setAttribute("dy", "1em"), l.setAttribute("x", "0"), r ? l.setAttribute("class", "title-row") : l.setAttribute("class", "row"), l.textContent = s.trim(), a.appendChild(l);
    }
    return a;
  }
}, "createLabel"), cr = Ov, Ke = /* @__PURE__ */ d((e, t, r, i, n) => [
  "M",
  e + n,
  t,
  // Move to the first point
  "H",
  e + r - n,
  // Draw horizontal line to the beginning of the right corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + r,
  t + n,
  // Draw arc to the right top corner
  "V",
  t + i - n,
  // Draw vertical line down to the beginning of the right bottom corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + r - n,
  t + i,
  // Draw arc to the right bottom corner
  "H",
  e + n,
  // Draw horizontal line to the beginning of the left bottom corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e,
  t + i - n,
  // Draw arc to the left bottom corner
  "V",
  t + n,
  // Draw vertical line up to the beginning of the left top corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + n,
  t,
  // Draw arc to the left top corner
  "Z"
  // Close the path
].join(" "), "createRoundedRectPathD"), Bd = /* @__PURE__ */ d(async (e, t) => {
  F.info("Creating subgraph rect for ", t.id, t);
  const r = pt(), { themeVariables: i, handDrawnSeed: n } = r, { clusterBkg: a, clusterBorder: o } = i, { labelStyles: s, nodeStyles: l, borderStyles: c, backgroundStyles: h } = G(t), u = e.insert("g").attr("class", "cluster " + t.cssClasses).attr("id", t.id).attr("data-look", t.look), f = Lt(r.flowchart.htmlLabels), p = u.insert("g").attr("class", "cluster-label "), g = await Ze(p, t.label, {
    style: t.labelStyle,
    useHtmlLabels: f,
    isNode: !0
  });
  let m = g.getBBox();
  if (Lt(r.flowchart.htmlLabels)) {
    const S = g.children[0], D = ht(g);
    m = S.getBoundingClientRect(), D.attr("width", m.width), D.attr("height", m.height);
  }
  const y = t.width <= m.width + t.padding ? m.width + t.padding : t.width;
  t.width <= m.width + t.padding ? t.diff = (y - t.width) / 2 - t.padding : t.diff = -t.padding;
  const x = t.height, b = t.x - y / 2, _ = t.y - x / 2;
  F.trace("Data ", t, JSON.stringify(t));
  let v;
  if (t.look === "handDrawn") {
    const S = Y.svg(u), D = U(t, {
      roughness: 0.7,
      fill: a,
      // fill: 'red',
      stroke: o,
      fillWeight: 3,
      seed: n
    }), P = S.path(Ke(b, _, y, x, 0), D);
    v = u.insert(() => (F.debug("Rough node insert CXC", P), P), ":first-child"), v.select("path:nth-child(2)").attr("style", c.join(";")), v.select("path").attr("style", h.join(";").replace("fill", "stroke"));
  } else
    v = u.insert("rect", ":first-child"), v.attr("style", l).attr("rx", t.rx).attr("ry", t.ry).attr("x", b).attr("y", _).attr("width", y).attr("height", x);
  const { subGraphTitleTopMargin: w } = Zo(r);
  if (p.attr(
    "transform",
    // This puts the label on top of the box instead of inside it
    `translate(${t.x - m.width / 2}, ${t.y - t.height / 2 + w})`
  ), s) {
    const S = p.select("span");
    S && S.attr("style", s);
  }
  const C = v.node().getBBox();
  return t.offsetX = 0, t.width = C.width, t.height = C.height, t.offsetY = m.height - t.padding / 2, t.intersect = function(S) {
    return ai(t, S);
  }, { cluster: u, labelBBox: m };
}, "rect"), Rv = /* @__PURE__ */ d((e, t) => {
  const r = e.insert("g").attr("class", "note-cluster").attr("id", t.id), i = r.insert("rect", ":first-child"), n = 0 * t.padding, a = n / 2;
  i.attr("rx", t.rx).attr("ry", t.ry).attr("x", t.x - t.width / 2 - a).attr("y", t.y - t.height / 2 - a).attr("width", t.width + n).attr("height", t.height + n).attr("fill", "none");
  const o = i.node().getBBox();
  return t.width = o.width, t.height = o.height, t.intersect = function(s) {
    return ai(t, s);
  }, { cluster: r, labelBBox: { width: 0, height: 0 } };
}, "noteGroup"), Iv = /* @__PURE__ */ d(async (e, t) => {
  const r = pt(), { themeVariables: i, handDrawnSeed: n } = r, { altBackground: a, compositeBackground: o, compositeTitleBackground: s, nodeBorder: l } = i, c = e.insert("g").attr("class", t.cssClasses).attr("id", t.id).attr("data-id", t.id).attr("data-look", t.look), h = c.insert("g", ":first-child"), u = c.insert("g").attr("class", "cluster-label");
  let f = c.append("rect");
  const p = u.node().appendChild(await cr(t.label, t.labelStyle, void 0, !0));
  let g = p.getBBox();
  if (Lt(r.flowchart.htmlLabels)) {
    const P = p.children[0], R = ht(p);
    g = P.getBoundingClientRect(), R.attr("width", g.width), R.attr("height", g.height);
  }
  const m = 0 * t.padding, y = m / 2, x = (t.width <= g.width + t.padding ? g.width + t.padding : t.width) + m;
  t.width <= g.width + t.padding ? t.diff = (x - t.width) / 2 - t.padding : t.diff = -t.padding;
  const b = t.height + m, _ = t.height + m - g.height - 6, v = t.x - x / 2, w = t.y - b / 2;
  t.width = x;
  const C = t.y - t.height / 2 - y + g.height + 2;
  let S;
  if (t.look === "handDrawn") {
    const P = t.cssClasses.includes("statediagram-cluster-alt"), R = Y.svg(c), $ = t.rx || t.ry ? R.path(Ke(v, w, x, b, 10), {
      roughness: 0.7,
      fill: s,
      fillStyle: "solid",
      stroke: l,
      seed: n
    }) : R.rectangle(v, w, x, b, { seed: n });
    S = c.insert(() => $, ":first-child");
    const z = R.rectangle(v, C, x, _, {
      fill: P ? a : o,
      fillStyle: P ? "hachure" : "solid",
      stroke: l,
      seed: n
    });
    S = c.insert(() => $, ":first-child"), f = c.insert(() => z);
  } else
    S = h.insert("rect", ":first-child"), S.attr("class", "outer").attr("x", v).attr("y", w).attr("width", x).attr("height", b).attr("data-look", t.look), f.attr("class", "inner").attr("x", v).attr("y", C).attr("width", x).attr("height", _);
  u.attr(
    "transform",
    `translate(${t.x - g.width / 2}, ${w + 1 - (Lt(r.flowchart.htmlLabels) ? 0 : 3)})`
  );
  const D = S.node().getBBox();
  return t.height = D.height, t.offsetX = 0, t.offsetY = g.height - t.padding / 2, t.labelBBox = g, t.intersect = function(P) {
    return ai(t, P);
  }, { cluster: c, labelBBox: g };
}, "roundedWithTitle"), Pv = /* @__PURE__ */ d(async (e, t) => {
  F.info("Creating subgraph rect for ", t.id, t);
  const r = pt(), { themeVariables: i, handDrawnSeed: n } = r, { clusterBkg: a, clusterBorder: o } = i, { labelStyles: s, nodeStyles: l, borderStyles: c, backgroundStyles: h } = G(t), u = e.insert("g").attr("class", "cluster " + t.cssClasses).attr("id", t.id).attr("data-look", t.look), f = Lt(r.flowchart.htmlLabels), p = u.insert("g").attr("class", "cluster-label "), g = await Ze(p, t.label, {
    style: t.labelStyle,
    useHtmlLabels: f,
    isNode: !0,
    width: t.width
  });
  let m = g.getBBox();
  if (Lt(r.flowchart.htmlLabels)) {
    const S = g.children[0], D = ht(g);
    m = S.getBoundingClientRect(), D.attr("width", m.width), D.attr("height", m.height);
  }
  const y = t.width <= m.width + t.padding ? m.width + t.padding : t.width;
  t.width <= m.width + t.padding ? t.diff = (y - t.width) / 2 - t.padding : t.diff = -t.padding;
  const x = t.height, b = t.x - y / 2, _ = t.y - x / 2;
  F.trace("Data ", t, JSON.stringify(t));
  let v;
  if (t.look === "handDrawn") {
    const S = Y.svg(u), D = U(t, {
      roughness: 0.7,
      fill: a,
      // fill: 'red',
      stroke: o,
      fillWeight: 4,
      seed: n
    }), P = S.path(Ke(b, _, y, x, t.rx), D);
    v = u.insert(() => (F.debug("Rough node insert CXC", P), P), ":first-child"), v.select("path:nth-child(2)").attr("style", c.join(";")), v.select("path").attr("style", h.join(";").replace("fill", "stroke"));
  } else
    v = u.insert("rect", ":first-child"), v.attr("style", l).attr("rx", t.rx).attr("ry", t.ry).attr("x", b).attr("y", _).attr("width", y).attr("height", x);
  const { subGraphTitleTopMargin: w } = Zo(r);
  if (p.attr(
    "transform",
    // This puts the label on top of the box instead of inside it
    `translate(${t.x - m.width / 2}, ${t.y - t.height / 2 + w})`
  ), s) {
    const S = p.select("span");
    S && S.attr("style", s);
  }
  const C = v.node().getBBox();
  return t.offsetX = 0, t.width = C.width, t.height = C.height, t.offsetY = m.height - t.padding / 2, t.intersect = function(S) {
    return ai(t, S);
  }, { cluster: u, labelBBox: m };
}, "kanbanSection"), Nv = /* @__PURE__ */ d((e, t) => {
  const r = pt(), { themeVariables: i, handDrawnSeed: n } = r, { nodeBorder: a } = i, o = e.insert("g").attr("class", t.cssClasses).attr("id", t.id).attr("data-look", t.look), s = o.insert("g", ":first-child"), l = 0 * t.padding, c = t.width + l;
  t.diff = -t.padding;
  const h = t.height + l, u = t.x - c / 2, f = t.y - h / 2;
  t.width = c;
  let p;
  if (t.look === "handDrawn") {
    const y = Y.svg(o).rectangle(u, f, c, h, {
      fill: "lightgrey",
      roughness: 0.5,
      strokeLineDash: [5],
      stroke: a,
      seed: n
    });
    p = o.insert(() => y, ":first-child");
  } else
    p = s.insert("rect", ":first-child"), p.attr("class", "divider").attr("x", u).attr("y", f).attr("width", c).attr("height", h).attr("data-look", t.look);
  const g = p.node().getBBox();
  return t.height = g.height, t.offsetX = 0, t.offsetY = 0, t.intersect = function(m) {
    return ai(t, m);
  }, { cluster: o, labelBBox: {} };
}, "divider"), zv = Bd, Wv = {
  rect: Bd,
  squareRect: zv,
  roundedWithTitle: Iv,
  noteGroup: Rv,
  divider: Nv,
  kanbanSection: Pv
}, Ad = /* @__PURE__ */ new Map(), qv = /* @__PURE__ */ d(async (e, t) => {
  const r = t.shape || "rect", i = await Wv[r](e, t);
  return Ad.set(t.id, i), i;
}, "insertCluster"), yL = /* @__PURE__ */ d(() => {
  Ad = /* @__PURE__ */ new Map();
}, "clear");
function Ld(e, t) {
  return e.intersect(t);
}
d(Ld, "intersectNode");
var Hv = Ld;
function Md(e, t, r, i) {
  var n = e.x, a = e.y, o = n - i.x, s = a - i.y, l = Math.sqrt(t * t * s * s + r * r * o * o), c = Math.abs(t * r * o / l);
  i.x < n && (c = -c);
  var h = Math.abs(t * r * s / l);
  return i.y < a && (h = -h), { x: n + c, y: a + h };
}
d(Md, "intersectEllipse");
var $d = Md;
function Ed(e, t, r) {
  return $d(e, t, t, r);
}
d(Ed, "intersectCircle");
var jv = Ed;
function Fd(e, t, r, i) {
  {
    const n = t.y - e.y, a = e.x - t.x, o = t.x * e.y - e.x * t.y, s = n * r.x + a * r.y + o, l = n * i.x + a * i.y + o, c = 1e-6;
    if (s !== 0 && l !== 0 && uo(s, l))
      return;
    const h = i.y - r.y, u = r.x - i.x, f = i.x * r.y - r.x * i.y, p = h * e.x + u * e.y + f, g = h * t.x + u * t.y + f;
    if (Math.abs(p) < c && Math.abs(g) < c && uo(p, g))
      return;
    const m = n * u - h * a;
    if (m === 0)
      return;
    const y = Math.abs(m / 2);
    let x = a * f - u * o;
    const b = x < 0 ? (x - y) / m : (x + y) / m;
    x = h * o - n * f;
    const _ = x < 0 ? (x - y) / m : (x + y) / m;
    return { x: b, y: _ };
  }
}
d(Fd, "intersectLine");
function uo(e, t) {
  return e * t > 0;
}
d(uo, "sameSign");
var Yv = Fd;
function Dd(e, t, r) {
  let i = e.x, n = e.y, a = [], o = Number.POSITIVE_INFINITY, s = Number.POSITIVE_INFINITY;
  typeof t.forEach == "function" ? t.forEach(function(h) {
    o = Math.min(o, h.x), s = Math.min(s, h.y);
  }) : (o = Math.min(o, t.x), s = Math.min(s, t.y));
  let l = i - e.width / 2 - o, c = n - e.height / 2 - s;
  for (let h = 0; h < t.length; h++) {
    let u = t[h], f = t[h < t.length - 1 ? h + 1 : 0], p = Yv(
      e,
      r,
      { x: l + u.x, y: c + u.y },
      { x: l + f.x, y: c + f.y }
    );
    p && a.push(p);
  }
  return a.length ? (a.length > 1 && a.sort(function(h, u) {
    let f = h.x - r.x, p = h.y - r.y, g = Math.sqrt(f * f + p * p), m = u.x - r.x, y = u.y - r.y, x = Math.sqrt(m * m + y * y);
    return g < x ? -1 : g === x ? 0 : 1;
  }), a[0]) : e;
}
d(Dd, "intersectPolygon");
var Uv = Dd, q = {
  node: Hv,
  circle: jv,
  ellipse: $d,
  polygon: Uv,
  rect: ai
};
function Od(e, t) {
  const { labelStyles: r } = G(t);
  t.labelStyle = r;
  const i = tt(t);
  let n = i;
  i || (n = "anchor");
  const a = e.insert("g").attr("class", n).attr("id", t.domId || t.id), o = 1, { cssStyles: s } = t, l = Y.svg(a), c = U(t, { fill: "black", stroke: "none", fillStyle: "solid" });
  t.look !== "handDrawn" && (c.roughness = 0);
  const h = l.circle(0, 0, o * 2, c), u = a.insert(() => h, ":first-child");
  return u.attr("class", "anchor").attr("style", Wt(s)), V(t, u), t.intersect = function(f) {
    return F.info("Circle intersect", t, o, f), q.circle(t, o, f);
  }, a;
}
d(Od, "anchor");
function fo(e, t, r, i, n, a, o) {
  const l = (e + r) / 2, c = (t + i) / 2, h = Math.atan2(i - t, r - e), u = (r - e) / 2, f = (i - t) / 2, p = u / n, g = f / a, m = Math.sqrt(p ** 2 + g ** 2);
  if (m > 1)
    throw new Error("The given radii are too small to create an arc between the points.");
  const y = Math.sqrt(1 - m ** 2), x = l + y * a * Math.sin(h) * (o ? -1 : 1), b = c - y * n * Math.cos(h) * (o ? -1 : 1), _ = Math.atan2((t - b) / a, (e - x) / n);
  let w = Math.atan2((i - b) / a, (r - x) / n) - _;
  o && w < 0 && (w += 2 * Math.PI), !o && w > 0 && (w -= 2 * Math.PI);
  const C = [];
  for (let S = 0; S < 20; S++) {
    const D = S / 19, P = _ + D * w, R = x + n * Math.cos(P), $ = b + a * Math.sin(P);
    C.push({ x: R, y: $ });
  }
  return C;
}
d(fo, "generateArcPoints");
async function Rd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = a.width + t.padding + 20, s = a.height + t.padding, l = s / 2, c = l / (2.5 + s / 50), { cssStyles: h } = t, u = [
    { x: o / 2, y: -s / 2 },
    { x: -o / 2, y: -s / 2 },
    ...fo(-o / 2, -s / 2, -o / 2, s / 2, c, l, !1),
    { x: o / 2, y: s / 2 },
    ...fo(o / 2, s / 2, o / 2, -s / 2, c, l, !0)
  ], f = Y.svg(n), p = U(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = lt(u), m = f.path(g, p), y = n.insert(() => m, ":first-child");
  return y.attr("class", "basic label-container"), h && t.look !== "handDrawn" && y.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && y.selectAll("path").attr("style", i), y.attr("transform", `translate(${c / 2}, 0)`), V(t, y), t.intersect = function(x) {
    return q.polygon(t, u, x);
  }, n;
}
d(Rd, "bowTieRect");
function Qe(e, t, r, i) {
  return e.insert("polygon", ":first-child").attr(
    "points",
    i.map(function(n) {
      return n.x + "," + n.y;
    }).join(" ")
  ).attr("class", "label-container").attr("transform", "translate(" + -t / 2 + "," + r / 2 + ")");
}
d(Qe, "insertPolygonShape");
async function Id(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = a.height + t.padding, s = 12, l = a.width + t.padding + s, c = 0, h = l, u = -o, f = 0, p = [
    { x: c + s, y: u },
    { x: h, y: u },
    { x: h, y: f },
    { x: c, y: f },
    { x: c, y: u + s },
    { x: c + s, y: u }
  ];
  let g;
  const { cssStyles: m } = t;
  if (t.look === "handDrawn") {
    const y = Y.svg(n), x = U(t, {}), b = lt(p), _ = y.path(b, x);
    g = n.insert(() => _, ":first-child").attr("transform", `translate(${-l / 2}, ${o / 2})`), m && g.attr("style", m);
  } else
    g = Qe(n, l, o, p);
  return i && g.attr("style", i), V(t, g), t.intersect = function(y) {
    return q.polygon(t, p, y);
  }, n;
}
d(Id, "card");
function Pd(e, t) {
  const { nodeStyles: r } = G(t);
  t.label = "";
  const i = e.insert("g").attr("class", tt(t)).attr("id", t.domId ?? t.id), { cssStyles: n } = t, a = Math.max(28, t.width ?? 0), o = [
    { x: 0, y: a / 2 },
    { x: a / 2, y: 0 },
    { x: 0, y: -a / 2 },
    { x: -a / 2, y: 0 }
  ], s = Y.svg(i), l = U(t, {});
  t.look !== "handDrawn" && (l.roughness = 0, l.fillStyle = "solid");
  const c = lt(o), h = s.path(c, l), u = i.insert(() => h, ":first-child");
  return n && t.look !== "handDrawn" && u.selectAll("path").attr("style", n), r && t.look !== "handDrawn" && u.selectAll("path").attr("style", r), t.width = 28, t.height = 28, t.intersect = function(f) {
    return q.polygon(t, o, f);
  }, i;
}
d(Pd, "choice");
async function Cl(e, t, r) {
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i;
  const { shapeSvg: a, bbox: o, halfPadding: s } = await et(e, t, tt(t)), l = (r == null ? void 0 : r.padding) ?? s, c = o.width / 2 + l;
  let h;
  const { cssStyles: u } = t;
  if (t.look === "handDrawn") {
    const f = Y.svg(a), p = U(t, {}), g = f.circle(0, 0, c * 2, p);
    h = a.insert(() => g, ":first-child"), h.attr("class", "basic label-container").attr("style", Wt(u));
  } else
    h = a.insert("circle", ":first-child").attr("class", "basic label-container").attr("style", n).attr("r", c).attr("cx", 0).attr("cy", 0);
  return V(t, h), t.calcIntersect = function(f, p) {
    const g = f.width / 2;
    return q.circle(f, g, p);
  }, t.intersect = function(f) {
    return F.info("Circle intersect", t, c, f), q.circle(t, c, f);
  }, a;
}
d(Cl, "circle");
function Nd(e) {
  const t = Math.cos(Math.PI / 4), r = Math.sin(Math.PI / 4), i = e * 2, n = { x: i / 2 * t, y: i / 2 * r }, a = { x: -(i / 2) * t, y: i / 2 * r }, o = { x: -(i / 2) * t, y: -(i / 2) * r }, s = { x: i / 2 * t, y: -(i / 2) * r };
  return `M ${a.x},${a.y} L ${s.x},${s.y}
                   M ${n.x},${n.y} L ${o.x},${o.y}`;
}
d(Nd, "createLine");
function zd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r, t.label = "";
  const n = e.insert("g").attr("class", tt(t)).attr("id", t.domId ?? t.id), a = Math.max(30, (t == null ? void 0 : t.width) ?? 0), { cssStyles: o } = t, s = Y.svg(n), l = U(t, {});
  t.look !== "handDrawn" && (l.roughness = 0, l.fillStyle = "solid");
  const c = s.circle(0, 0, a * 2, l), h = Nd(a), u = s.path(h, l), f = n.insert(() => c, ":first-child");
  return f.insert(() => u), o && t.look !== "handDrawn" && f.selectAll("path").attr("style", o), i && t.look !== "handDrawn" && f.selectAll("path").attr("style", i), V(t, f), t.intersect = function(p) {
    return F.info("crossedCircle intersect", t, { radius: a, point: p }), q.circle(t, a, p);
  }, n;
}
d(zd, "crossedCircle");
function Fe(e, t, r, i = 100, n = 0, a = 180) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, p = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: -p, y: -g });
  }
  return o;
}
d(Fe, "generateCirclePoints");
async function Wd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = a.width + (t.padding ?? 0), l = a.height + (t.padding ?? 0), c = Math.max(5, l * 0.1), { cssStyles: h } = t, u = [
    ...Fe(s / 2, -l / 2, c, 30, -90, 0),
    { x: -s / 2 - c, y: c },
    ...Fe(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...Fe(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: -s / 2 - c, y: -l / 2 },
    ...Fe(s / 2, l / 2, c, 20, 0, 90)
  ], f = [
    { x: s / 2, y: -l / 2 - c },
    { x: -s / 2, y: -l / 2 - c },
    ...Fe(s / 2, -l / 2, c, 20, -90, 0),
    { x: -s / 2 - c, y: -c },
    ...Fe(s / 2 + s * 0.1, -c, c, 20, -180, -270),
    ...Fe(s / 2 + s * 0.1, c, c, 20, -90, -180),
    { x: -s / 2 - c, y: l / 2 },
    ...Fe(s / 2, l / 2, c, 20, 0, 90),
    { x: -s / 2, y: l / 2 + c },
    { x: s / 2, y: l / 2 + c }
  ], p = Y.svg(n), g = U(t, { fill: "none" });
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const y = lt(u).replace("Z", ""), x = p.path(y, g), b = lt(f), _ = p.path(b, { ...g }), v = n.insert("g", ":first-child");
  return v.insert(() => _, ":first-child").attr("stroke-opacity", 0), v.insert(() => x, ":first-child"), v.attr("class", "text"), h && t.look !== "handDrawn" && v.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && v.selectAll("path").attr("style", i), v.attr("transform", `translate(${c}, 0)`), o.attr(
    "transform",
    `translate(${-s / 2 + c - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, v), t.intersect = function(w) {
    return q.polygon(t, f, w);
  }, n;
}
d(Wd, "curlyBraceLeft");
function De(e, t, r, i = 100, n = 0, a = 180) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, p = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: p, y: g });
  }
  return o;
}
d(De, "generateCirclePoints");
async function qd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = a.width + (t.padding ?? 0), l = a.height + (t.padding ?? 0), c = Math.max(5, l * 0.1), { cssStyles: h } = t, u = [
    ...De(s / 2, -l / 2, c, 20, -90, 0),
    { x: s / 2 + c, y: -c },
    ...De(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...De(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: s / 2 + c, y: l / 2 },
    ...De(s / 2, l / 2, c, 20, 0, 90)
  ], f = [
    { x: -s / 2, y: -l / 2 - c },
    { x: s / 2, y: -l / 2 - c },
    ...De(s / 2, -l / 2, c, 20, -90, 0),
    { x: s / 2 + c, y: -c },
    ...De(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...De(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: s / 2 + c, y: l / 2 },
    ...De(s / 2, l / 2, c, 20, 0, 90),
    { x: s / 2, y: l / 2 + c },
    { x: -s / 2, y: l / 2 + c }
  ], p = Y.svg(n), g = U(t, { fill: "none" });
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const y = lt(u).replace("Z", ""), x = p.path(y, g), b = lt(f), _ = p.path(b, { ...g }), v = n.insert("g", ":first-child");
  return v.insert(() => _, ":first-child").attr("stroke-opacity", 0), v.insert(() => x, ":first-child"), v.attr("class", "text"), h && t.look !== "handDrawn" && v.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && v.selectAll("path").attr("style", i), v.attr("transform", `translate(${-c}, 0)`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, v), t.intersect = function(w) {
    return q.polygon(t, f, w);
  }, n;
}
d(qd, "curlyBraceRight");
function Ft(e, t, r, i = 100, n = 0, a = 180) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, p = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: -p, y: -g });
  }
  return o;
}
d(Ft, "generateCirclePoints");
async function Hd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = a.width + (t.padding ?? 0), l = a.height + (t.padding ?? 0), c = Math.max(5, l * 0.1), { cssStyles: h } = t, u = [
    ...Ft(s / 2, -l / 2, c, 30, -90, 0),
    { x: -s / 2 - c, y: c },
    ...Ft(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...Ft(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: -s / 2 - c, y: -l / 2 },
    ...Ft(s / 2, l / 2, c, 20, 0, 90)
  ], f = [
    ...Ft(-s / 2 + c + c / 2, -l / 2, c, 20, -90, -180),
    { x: s / 2 - c / 2, y: c },
    ...Ft(-s / 2 - c / 2, -c, c, 20, 0, 90),
    ...Ft(-s / 2 - c / 2, c, c, 20, -90, 0),
    { x: s / 2 - c / 2, y: -c },
    ...Ft(-s / 2 + c + c / 2, l / 2, c, 30, -180, -270)
  ], p = [
    { x: s / 2, y: -l / 2 - c },
    { x: -s / 2, y: -l / 2 - c },
    ...Ft(s / 2, -l / 2, c, 20, -90, 0),
    { x: -s / 2 - c, y: -c },
    ...Ft(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...Ft(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: -s / 2 - c, y: l / 2 },
    ...Ft(s / 2, l / 2, c, 20, 0, 90),
    { x: -s / 2, y: l / 2 + c },
    { x: s / 2 - c - c / 2, y: l / 2 + c },
    ...Ft(-s / 2 + c + c / 2, -l / 2, c, 20, -90, -180),
    { x: s / 2 - c / 2, y: c },
    ...Ft(-s / 2 - c / 2, -c, c, 20, 0, 90),
    ...Ft(-s / 2 - c / 2, c, c, 20, -90, 0),
    { x: s / 2 - c / 2, y: -c },
    ...Ft(-s / 2 + c + c / 2, l / 2, c, 30, -180, -270)
  ], g = Y.svg(n), m = U(t, { fill: "none" });
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const x = lt(u).replace("Z", ""), b = g.path(x, m), v = lt(f).replace("Z", ""), w = g.path(v, m), C = lt(p), S = g.path(C, { ...m }), D = n.insert("g", ":first-child");
  return D.insert(() => S, ":first-child").attr("stroke-opacity", 0), D.insert(() => b, ":first-child"), D.insert(() => w, ":first-child"), D.attr("class", "text"), h && t.look !== "handDrawn" && D.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && D.selectAll("path").attr("style", i), D.attr("transform", `translate(${c - c / 4}, 0)`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, D), t.intersect = function(P) {
    return q.polygon(t, p, P);
  }, n;
}
d(Hd, "curlyBraces");
async function jd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = 80, s = 20, l = Math.max(o, (a.width + (t.padding ?? 0) * 2) * 1.25, (t == null ? void 0 : t.width) ?? 0), c = Math.max(s, a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = c / 2, { cssStyles: u } = t, f = Y.svg(n), p = U(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = l, m = c, y = g - h, x = m / 4, b = [
    { x: y, y: 0 },
    { x, y: 0 },
    { x: 0, y: m / 2 },
    { x, y: m },
    { x: y, y: m },
    ...Yi(-y, -m / 2, h, 50, 270, 90)
  ], _ = lt(b), v = f.path(_, p), w = n.insert(() => v, ":first-child");
  return w.attr("class", "basic label-container"), u && t.look !== "handDrawn" && w.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && w.selectChildren("path").attr("style", i), w.attr("transform", `translate(${-l / 2}, ${-c / 2})`), V(t, w), t.intersect = function(C) {
    return q.polygon(t, b, C);
  }, n;
}
d(jd, "curvedTrapezoid");
var Gv = /* @__PURE__ */ d((e, t, r, i, n, a) => [
  `M${e},${t + a}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`
].join(" "), "createCylinderPathD"), Xv = /* @__PURE__ */ d((e, t, r, i, n, a) => [
  `M${e},${t + a}`,
  `M${e + r},${t + a}`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`
].join(" "), "createOuterCylinderPathD"), Vv = /* @__PURE__ */ d((e, t, r, i, n, a) => [`M${e - r / 2},${-i / 2}`, `a${n},${a} 0,0,0 ${r},0`].join(" "), "createInnerCylinderPathD");
async function Yd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + t.padding, t.width ?? 0), l = s / 2, c = l / (2.5 + s / 50), h = Math.max(a.height + c + t.padding, t.height ?? 0);
  let u;
  const { cssStyles: f } = t;
  if (t.look === "handDrawn") {
    const p = Y.svg(n), g = Xv(0, 0, s, h, l, c), m = Vv(0, c, s, h, l, c), y = p.path(g, U(t, {})), x = p.path(m, U(t, { fill: "none" }));
    u = n.insert(() => x, ":first-child"), u = n.insert(() => y, ":first-child"), u.attr("class", "basic label-container"), f && u.attr("style", f);
  } else {
    const p = Gv(0, 0, s, h, l, c);
    u = n.insert("path", ":first-child").attr("d", p).attr("class", "basic label-container").attr("style", Wt(f)).attr("style", i);
  }
  return u.attr("label-offset-y", c), u.attr("transform", `translate(${-s / 2}, ${-(h / 2 + c)})`), V(t, u), o.attr(
    "transform",
    `translate(${-(a.width / 2) - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + (t.padding ?? 0) / 1.5 - (a.y - (a.top ?? 0))})`
  ), t.intersect = function(p) {
    const g = q.rect(t, p), m = g.x - (t.x ?? 0);
    if (l != 0 && (Math.abs(m) < (t.width ?? 0) / 2 || Math.abs(m) == (t.width ?? 0) / 2 && Math.abs(g.y - (t.y ?? 0)) > (t.height ?? 0) / 2 - c)) {
      let y = c * c * (1 - m * m / (l * l));
      y > 0 && (y = Math.sqrt(y)), y = c - y, p.y - (t.y ?? 0) > 0 && (y = -y), g.y += y;
    }
    return g;
  }, n;
}
d(Yd, "cylinder");
async function Ud(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = a.width + t.padding, l = a.height + t.padding, c = l * 0.2, h = -s / 2, u = -l / 2 - c / 2, { cssStyles: f } = t, p = Y.svg(n), g = U(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = [
    { x: h, y: u + c },
    { x: -h, y: u + c },
    { x: -h, y: -u },
    { x: h, y: -u },
    { x: h, y: u },
    { x: -h, y: u },
    { x: -h, y: u + c }
  ], y = p.polygon(
    m.map((b) => [b.x, b.y]),
    g
  ), x = n.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container"), f && t.look !== "handDrawn" && x.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && x.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${h + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))}, ${u + c + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, x), t.intersect = function(b) {
    return q.rect(t, b);
  }, n;
}
d(Ud, "dividedRectangle");
async function Gd(e, t) {
  var f, p;
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: o } = await et(e, t, tt(t)), l = a.width / 2 + o + 5, c = a.width / 2 + o;
  let h;
  const { cssStyles: u } = t;
  if (t.look === "handDrawn") {
    const g = Y.svg(n), m = U(t, { roughness: 0.2, strokeWidth: 2.5 }), y = U(t, { roughness: 0.2, strokeWidth: 1.5 }), x = g.circle(0, 0, l * 2, m), b = g.circle(0, 0, c * 2, y);
    h = n.insert("g", ":first-child"), h.attr("class", Wt(t.cssClasses)).attr("style", Wt(u)), (f = h.node()) == null || f.appendChild(x), (p = h.node()) == null || p.appendChild(b);
  } else {
    h = n.insert("g", ":first-child");
    const g = h.insert("circle", ":first-child"), m = h.insert("circle");
    h.attr("class", "basic label-container").attr("style", i), g.attr("class", "outer-circle").attr("style", i).attr("r", l).attr("cx", 0).attr("cy", 0), m.attr("class", "inner-circle").attr("style", i).attr("r", c).attr("cx", 0).attr("cy", 0);
  }
  return V(t, h), t.intersect = function(g) {
    return F.info("DoubleCircle intersect", t, l, g), q.circle(t, l, g);
  }, n;
}
d(Gd, "doublecircle");
function Xd(e, t, { config: { themeVariables: r } }) {
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.label = "", t.labelStyle = i;
  const a = e.insert("g").attr("class", tt(t)).attr("id", t.domId ?? t.id), o = 7, { cssStyles: s } = t, l = Y.svg(a), { nodeBorder: c } = r, h = U(t, { fillStyle: "solid" });
  t.look !== "handDrawn" && (h.roughness = 0);
  const u = l.circle(0, 0, o * 2, h), f = a.insert(() => u, ":first-child");
  return f.selectAll("path").attr("style", `fill: ${c} !important;`), s && s.length > 0 && t.look !== "handDrawn" && f.selectAll("path").attr("style", s), n && t.look !== "handDrawn" && f.selectAll("path").attr("style", n), V(t, f), t.intersect = function(p) {
    return F.info("filledCircle intersect", t, { radius: o, point: p }), q.circle(t, o, p);
  }, a;
}
d(Xd, "filledCircle");
async function Vd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = a.width + (t.padding ?? 0), l = s + a.height, c = s + a.height, h = [
    { x: 0, y: -l },
    { x: c, y: -l },
    { x: c / 2, y: 0 }
  ], { cssStyles: u } = t, f = Y.svg(n), p = U(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = lt(h), m = f.path(g, p), y = n.insert(() => m, ":first-child").attr("transform", `translate(${-l / 2}, ${l / 2})`);
  return u && t.look !== "handDrawn" && y.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && y.selectChildren("path").attr("style", i), t.width = s, t.height = l, V(t, y), o.attr(
    "transform",
    `translate(${-a.width / 2 - (a.x - (a.left ?? 0))}, ${-l / 2 + (t.padding ?? 0) / 2 + (a.y - (a.top ?? 0))})`
  ), t.intersect = function(x) {
    return F.info("Triangle intersect", t, h, x), q.polygon(t, h, x);
  }, n;
}
d(Vd, "flippedTriangle");
function Zd(e, t, { dir: r, config: { state: i, themeVariables: n } }) {
  const { nodeStyles: a } = G(t);
  t.label = "";
  const o = e.insert("g").attr("class", tt(t)).attr("id", t.domId ?? t.id), { cssStyles: s } = t;
  let l = Math.max(70, (t == null ? void 0 : t.width) ?? 0), c = Math.max(10, (t == null ? void 0 : t.height) ?? 0);
  r === "LR" && (l = Math.max(10, (t == null ? void 0 : t.width) ?? 0), c = Math.max(70, (t == null ? void 0 : t.height) ?? 0));
  const h = -1 * l / 2, u = -1 * c / 2, f = Y.svg(o), p = U(t, {
    stroke: n.lineColor,
    fill: n.lineColor
  });
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = f.rectangle(h, u, l, c, p), m = o.insert(() => g, ":first-child");
  s && t.look !== "handDrawn" && m.selectAll("path").attr("style", s), a && t.look !== "handDrawn" && m.selectAll("path").attr("style", a), V(t, m);
  const y = (i == null ? void 0 : i.padding) ?? 0;
  return t.width && t.height && (t.width += y / 2 || 0, t.height += y / 2 || 0), t.intersect = function(x) {
    return q.rect(t, x);
  }, o;
}
d(Zd, "forkJoin");
async function Kd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const n = 80, a = 50, { shapeSvg: o, bbox: s } = await et(e, t, tt(t)), l = Math.max(n, s.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(a, s.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = c / 2, { cssStyles: u } = t, f = Y.svg(o), p = U(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = [
    { x: -l / 2, y: -c / 2 },
    { x: l / 2 - h, y: -c / 2 },
    ...Yi(-l / 2 + h, 0, h, 50, 90, 270),
    { x: l / 2 - h, y: c / 2 },
    { x: -l / 2, y: c / 2 }
  ], m = lt(g), y = f.path(m, p), x = o.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container"), u && t.look !== "handDrawn" && x.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && x.selectChildren("path").attr("style", i), V(t, x), t.intersect = function(b) {
    return F.info("Pill intersect", t, { radius: h, point: b }), q.polygon(t, g, b);
  }, o;
}
d(Kd, "halfRoundedRectangle");
async function Qd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = a.height + (t.padding ?? 0), s = a.width + (t.padding ?? 0) * 2.5, { cssStyles: l } = t, c = Y.svg(n), h = U(t, {});
  t.look !== "handDrawn" && (h.roughness = 0, h.fillStyle = "solid");
  let u = s / 2;
  const f = u / 6;
  u = u + f;
  const p = o / 2, g = p / 2, m = u - g, y = [
    { x: -m, y: -p },
    { x: 0, y: -p },
    { x: m, y: -p },
    { x: u, y: 0 },
    { x: m, y: p },
    { x: 0, y: p },
    { x: -m, y: p },
    { x: -u, y: 0 }
  ], x = lt(y), b = c.path(x, h), _ = n.insert(() => b, ":first-child");
  return _.attr("class", "basic label-container"), l && t.look !== "handDrawn" && _.selectChildren("path").attr("style", l), i && t.look !== "handDrawn" && _.selectChildren("path").attr("style", i), t.width = s, t.height = o, V(t, _), t.intersect = function(v) {
    return q.polygon(t, y, v);
  }, n;
}
d(Qd, "hexagon");
async function Jd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.label = "", t.labelStyle = r;
  const { shapeSvg: n } = await et(e, t, tt(t)), a = Math.max(30, (t == null ? void 0 : t.width) ?? 0), o = Math.max(30, (t == null ? void 0 : t.height) ?? 0), { cssStyles: s } = t, l = Y.svg(n), c = U(t, {});
  t.look !== "handDrawn" && (c.roughness = 0, c.fillStyle = "solid");
  const h = [
    { x: 0, y: 0 },
    { x: a, y: 0 },
    { x: 0, y: o },
    { x: a, y: o }
  ], u = lt(h), f = l.path(u, c), p = n.insert(() => f, ":first-child");
  return p.attr("class", "basic label-container"), s && t.look !== "handDrawn" && p.selectChildren("path").attr("style", s), i && t.look !== "handDrawn" && p.selectChildren("path").attr("style", i), p.attr("transform", `translate(${-a / 2}, ${-o / 2})`), V(t, p), t.intersect = function(g) {
    return F.info("Pill intersect", t, { points: h }), q.polygon(t, h, g);
  }, n;
}
d(Jd, "hourglass");
async function tg(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = G(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), l = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, l ?? 0);
  const { shapeSvg: c, bbox: h, label: u } = await et(e, t, "icon-shape default"), f = t.pos === "t", p = s, g = s, { nodeBorder: m } = r, { stylesMap: y } = ri(t), x = -g / 2, b = -p / 2, _ = t.label ? 8 : 0, v = Y.svg(c), w = U(t, { stroke: "none", fill: "none" });
  t.look !== "handDrawn" && (w.roughness = 0, w.fillStyle = "solid");
  const C = v.rectangle(x, b, g, p, w), S = Math.max(g, h.width), D = p + h.height + _, P = v.rectangle(-S / 2, -D / 2, S, D, {
    ...w,
    fill: "transparent",
    stroke: "none"
  }), R = c.insert(() => C, ":first-child"), $ = c.insert(() => P);
  if (t.icon) {
    const z = c.append("g");
    z.html(
      `<g>${await rn(t.icon, {
        height: s,
        width: s,
        fallbackPrefix: ""
      })}</g>`
    );
    const O = z.node().getBBox(), M = O.width, A = O.height, B = O.x, E = O.y;
    z.attr(
      "transform",
      `translate(${-M / 2 - B},${f ? h.height / 2 + _ / 2 - A / 2 - E : -h.height / 2 - _ / 2 - A / 2 - E})`
    ), z.attr("style", `color: ${y.get("stroke") ?? m};`);
  }
  return u.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${f ? -D / 2 : D / 2 - h.height})`
  ), R.attr(
    "transform",
    `translate(0,${f ? h.height / 2 + _ / 2 : -h.height / 2 - _ / 2})`
  ), V(t, $), t.intersect = function(z) {
    if (F.info("iconSquare intersect", t, z), !t.label)
      return q.rect(t, z);
    const O = t.x ?? 0, M = t.y ?? 0, A = t.height ?? 0;
    let B = [];
    return f ? B = [
      { x: O - h.width / 2, y: M - A / 2 },
      { x: O + h.width / 2, y: M - A / 2 },
      { x: O + h.width / 2, y: M - A / 2 + h.height + _ },
      { x: O + g / 2, y: M - A / 2 + h.height + _ },
      { x: O + g / 2, y: M + A / 2 },
      { x: O - g / 2, y: M + A / 2 },
      { x: O - g / 2, y: M - A / 2 + h.height + _ },
      { x: O - h.width / 2, y: M - A / 2 + h.height + _ }
    ] : B = [
      { x: O - g / 2, y: M - A / 2 },
      { x: O + g / 2, y: M - A / 2 },
      { x: O + g / 2, y: M - A / 2 + p },
      { x: O + h.width / 2, y: M - A / 2 + p },
      { x: O + h.width / 2 / 2, y: M + A / 2 },
      { x: O - h.width / 2, y: M + A / 2 },
      { x: O - h.width / 2, y: M - A / 2 + p },
      { x: O - g / 2, y: M - A / 2 + p }
    ], q.polygon(t, B, z);
  }, c;
}
d(tg, "icon");
async function eg(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = G(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), l = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, l ?? 0);
  const { shapeSvg: c, bbox: h, label: u } = await et(e, t, "icon-shape default"), f = 20, p = t.label ? 8 : 0, g = t.pos === "t", { nodeBorder: m, mainBkg: y } = r, { stylesMap: x } = ri(t), b = Y.svg(c), _ = U(t, {});
  t.look !== "handDrawn" && (_.roughness = 0, _.fillStyle = "solid");
  const v = x.get("fill");
  _.stroke = v ?? y;
  const w = c.append("g");
  t.icon && w.html(
    `<g>${await rn(t.icon, {
      height: s,
      width: s,
      fallbackPrefix: ""
    })}</g>`
  );
  const C = w.node().getBBox(), S = C.width, D = C.height, P = C.x, R = C.y, $ = Math.max(S, D) * Math.SQRT2 + f * 2, z = b.circle(0, 0, $, _), O = Math.max($, h.width), M = $ + h.height + p, A = b.rectangle(-O / 2, -M / 2, O, M, {
    ..._,
    fill: "transparent",
    stroke: "none"
  }), B = c.insert(() => z, ":first-child"), E = c.insert(() => A);
  return w.attr(
    "transform",
    `translate(${-S / 2 - P},${g ? h.height / 2 + p / 2 - D / 2 - R : -h.height / 2 - p / 2 - D / 2 - R})`
  ), w.attr("style", `color: ${x.get("stroke") ?? m};`), u.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${g ? -M / 2 : M / 2 - h.height})`
  ), B.attr(
    "transform",
    `translate(0,${g ? h.height / 2 + p / 2 : -h.height / 2 - p / 2})`
  ), V(t, E), t.intersect = function(L) {
    return F.info("iconSquare intersect", t, L), q.rect(t, L);
  }, c;
}
d(eg, "iconCircle");
async function rg(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = G(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), l = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, l ?? 0);
  const { shapeSvg: c, bbox: h, halfPadding: u, label: f } = await et(
    e,
    t,
    "icon-shape default"
  ), p = t.pos === "t", g = s + u * 2, m = s + u * 2, { nodeBorder: y, mainBkg: x } = r, { stylesMap: b } = ri(t), _ = -m / 2, v = -g / 2, w = t.label ? 8 : 0, C = Y.svg(c), S = U(t, {});
  t.look !== "handDrawn" && (S.roughness = 0, S.fillStyle = "solid");
  const D = b.get("fill");
  S.stroke = D ?? x;
  const P = C.path(Ke(_, v, m, g, 5), S), R = Math.max(m, h.width), $ = g + h.height + w, z = C.rectangle(-R / 2, -$ / 2, R, $, {
    ...S,
    fill: "transparent",
    stroke: "none"
  }), O = c.insert(() => P, ":first-child").attr("class", "icon-shape2"), M = c.insert(() => z);
  if (t.icon) {
    const A = c.append("g");
    A.html(
      `<g>${await rn(t.icon, {
        height: s,
        width: s,
        fallbackPrefix: ""
      })}</g>`
    );
    const B = A.node().getBBox(), E = B.width, L = B.height, W = B.x, X = B.y;
    A.attr(
      "transform",
      `translate(${-E / 2 - W},${p ? h.height / 2 + w / 2 - L / 2 - X : -h.height / 2 - w / 2 - L / 2 - X})`
    ), A.attr("style", `color: ${b.get("stroke") ?? y};`);
  }
  return f.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${p ? -$ / 2 : $ / 2 - h.height})`
  ), O.attr(
    "transform",
    `translate(0,${p ? h.height / 2 + w / 2 : -h.height / 2 - w / 2})`
  ), V(t, M), t.intersect = function(A) {
    if (F.info("iconSquare intersect", t, A), !t.label)
      return q.rect(t, A);
    const B = t.x ?? 0, E = t.y ?? 0, L = t.height ?? 0;
    let W = [];
    return p ? W = [
      { x: B - h.width / 2, y: E - L / 2 },
      { x: B + h.width / 2, y: E - L / 2 },
      { x: B + h.width / 2, y: E - L / 2 + h.height + w },
      { x: B + m / 2, y: E - L / 2 + h.height + w },
      { x: B + m / 2, y: E + L / 2 },
      { x: B - m / 2, y: E + L / 2 },
      { x: B - m / 2, y: E - L / 2 + h.height + w },
      { x: B - h.width / 2, y: E - L / 2 + h.height + w }
    ] : W = [
      { x: B - m / 2, y: E - L / 2 },
      { x: B + m / 2, y: E - L / 2 },
      { x: B + m / 2, y: E - L / 2 + g },
      { x: B + h.width / 2, y: E - L / 2 + g },
      { x: B + h.width / 2 / 2, y: E + L / 2 },
      { x: B - h.width / 2, y: E + L / 2 },
      { x: B - h.width / 2, y: E - L / 2 + g },
      { x: B - m / 2, y: E - L / 2 + g }
    ], q.polygon(t, W, A);
  }, c;
}
d(rg, "iconRounded");
async function ig(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = G(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), l = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, l ?? 0);
  const { shapeSvg: c, bbox: h, halfPadding: u, label: f } = await et(
    e,
    t,
    "icon-shape default"
  ), p = t.pos === "t", g = s + u * 2, m = s + u * 2, { nodeBorder: y, mainBkg: x } = r, { stylesMap: b } = ri(t), _ = -m / 2, v = -g / 2, w = t.label ? 8 : 0, C = Y.svg(c), S = U(t, {});
  t.look !== "handDrawn" && (S.roughness = 0, S.fillStyle = "solid");
  const D = b.get("fill");
  S.stroke = D ?? x;
  const P = C.path(Ke(_, v, m, g, 0.1), S), R = Math.max(m, h.width), $ = g + h.height + w, z = C.rectangle(-R / 2, -$ / 2, R, $, {
    ...S,
    fill: "transparent",
    stroke: "none"
  }), O = c.insert(() => P, ":first-child"), M = c.insert(() => z);
  if (t.icon) {
    const A = c.append("g");
    A.html(
      `<g>${await rn(t.icon, {
        height: s,
        width: s,
        fallbackPrefix: ""
      })}</g>`
    );
    const B = A.node().getBBox(), E = B.width, L = B.height, W = B.x, X = B.y;
    A.attr(
      "transform",
      `translate(${-E / 2 - W},${p ? h.height / 2 + w / 2 - L / 2 - X : -h.height / 2 - w / 2 - L / 2 - X})`
    ), A.attr("style", `color: ${b.get("stroke") ?? y};`);
  }
  return f.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${p ? -$ / 2 : $ / 2 - h.height})`
  ), O.attr(
    "transform",
    `translate(0,${p ? h.height / 2 + w / 2 : -h.height / 2 - w / 2})`
  ), V(t, M), t.intersect = function(A) {
    if (F.info("iconSquare intersect", t, A), !t.label)
      return q.rect(t, A);
    const B = t.x ?? 0, E = t.y ?? 0, L = t.height ?? 0;
    let W = [];
    return p ? W = [
      { x: B - h.width / 2, y: E - L / 2 },
      { x: B + h.width / 2, y: E - L / 2 },
      { x: B + h.width / 2, y: E - L / 2 + h.height + w },
      { x: B + m / 2, y: E - L / 2 + h.height + w },
      { x: B + m / 2, y: E + L / 2 },
      { x: B - m / 2, y: E + L / 2 },
      { x: B - m / 2, y: E - L / 2 + h.height + w },
      { x: B - h.width / 2, y: E - L / 2 + h.height + w }
    ] : W = [
      { x: B - m / 2, y: E - L / 2 },
      { x: B + m / 2, y: E - L / 2 },
      { x: B + m / 2, y: E - L / 2 + g },
      { x: B + h.width / 2, y: E - L / 2 + g },
      { x: B + h.width / 2 / 2, y: E + L / 2 },
      { x: B - h.width / 2, y: E + L / 2 },
      { x: B - h.width / 2, y: E - L / 2 + g },
      { x: B - m / 2, y: E - L / 2 + g }
    ], q.polygon(t, W, A);
  }, c;
}
d(ig, "iconSquare");
async function ng(e, t, { config: { flowchart: r } }) {
  const i = new Image();
  i.src = (t == null ? void 0 : t.img) ?? "", await i.decode();
  const n = Number(i.naturalWidth.toString().replace("px", "")), a = Number(i.naturalHeight.toString().replace("px", ""));
  t.imageAspectRatio = n / a;
  const { labelStyles: o } = G(t);
  t.labelStyle = o;
  const s = r == null ? void 0 : r.wrappingWidth;
  t.defaultWidth = r == null ? void 0 : r.wrappingWidth;
  const l = Math.max(
    t.label ? s ?? 0 : 0,
    (t == null ? void 0 : t.assetWidth) ?? n
  ), c = t.constraint === "on" && t != null && t.assetHeight ? t.assetHeight * t.imageAspectRatio : l, h = t.constraint === "on" ? c / t.imageAspectRatio : (t == null ? void 0 : t.assetHeight) ?? a;
  t.width = Math.max(c, s ?? 0);
  const { shapeSvg: u, bbox: f, label: p } = await et(e, t, "image-shape default"), g = t.pos === "t", m = -c / 2, y = -h / 2, x = t.label ? 8 : 0, b = Y.svg(u), _ = U(t, {});
  t.look !== "handDrawn" && (_.roughness = 0, _.fillStyle = "solid");
  const v = b.rectangle(m, y, c, h, _), w = Math.max(c, f.width), C = h + f.height + x, S = b.rectangle(-w / 2, -C / 2, w, C, {
    ..._,
    fill: "none",
    stroke: "none"
  }), D = u.insert(() => v, ":first-child"), P = u.insert(() => S);
  if (t.img) {
    const R = u.append("image");
    R.attr("href", t.img), R.attr("width", c), R.attr("height", h), R.attr("preserveAspectRatio", "none"), R.attr(
      "transform",
      `translate(${-c / 2},${g ? C / 2 - h : -C / 2})`
    );
  }
  return p.attr(
    "transform",
    `translate(${-f.width / 2 - (f.x - (f.left ?? 0))},${g ? -h / 2 - f.height / 2 - x / 2 : h / 2 - f.height / 2 + x / 2})`
  ), D.attr(
    "transform",
    `translate(0,${g ? f.height / 2 + x / 2 : -f.height / 2 - x / 2})`
  ), V(t, P), t.intersect = function(R) {
    if (F.info("iconSquare intersect", t, R), !t.label)
      return q.rect(t, R);
    const $ = t.x ?? 0, z = t.y ?? 0, O = t.height ?? 0;
    let M = [];
    return g ? M = [
      { x: $ - f.width / 2, y: z - O / 2 },
      { x: $ + f.width / 2, y: z - O / 2 },
      { x: $ + f.width / 2, y: z - O / 2 + f.height + x },
      { x: $ + c / 2, y: z - O / 2 + f.height + x },
      { x: $ + c / 2, y: z + O / 2 },
      { x: $ - c / 2, y: z + O / 2 },
      { x: $ - c / 2, y: z - O / 2 + f.height + x },
      { x: $ - f.width / 2, y: z - O / 2 + f.height + x }
    ] : M = [
      { x: $ - c / 2, y: z - O / 2 },
      { x: $ + c / 2, y: z - O / 2 },
      { x: $ + c / 2, y: z - O / 2 + h },
      { x: $ + f.width / 2, y: z - O / 2 + h },
      { x: $ + f.width / 2 / 2, y: z + O / 2 },
      { x: $ - f.width / 2, y: z + O / 2 },
      { x: $ - f.width / 2, y: z - O / 2 + h },
      { x: $ - c / 2, y: z - O / 2 + h }
    ], q.polygon(t, M, R);
  }, u;
}
d(ng, "imageSquare");
async function ag(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), l = [
    { x: 0, y: 0 },
    { x: o, y: 0 },
    { x: o + 3 * s / 6, y: -s },
    { x: -3 * s / 6, y: -s }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = Y.svg(n), f = U(t, {}), p = lt(l), g = u.path(p, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && c.attr("style", h);
  } else
    c = Qe(n, o, s, l);
  return i && c.attr("style", i), t.width = o, t.height = s, V(t, c), t.intersect = function(u) {
    return q.polygon(t, l, u);
  }, n;
}
d(ag, "inv_trapezoid");
async function qa(e, t, r) {
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i;
  const { shapeSvg: a, bbox: o } = await et(e, t, tt(t)), s = Math.max(o.width + r.labelPaddingX * 2, (t == null ? void 0 : t.width) || 0), l = Math.max(o.height + r.labelPaddingY * 2, (t == null ? void 0 : t.height) || 0), c = -s / 2, h = -l / 2;
  let u, { rx: f, ry: p } = t;
  const { cssStyles: g } = t;
  if (r != null && r.rx && r.ry && (f = r.rx, p = r.ry), t.look === "handDrawn") {
    const m = Y.svg(a), y = U(t, {}), x = f || p ? m.path(Ke(c, h, s, l, f || 0), y) : m.rectangle(c, h, s, l, y);
    u = a.insert(() => x, ":first-child"), u.attr("class", "basic label-container").attr("style", Wt(g));
  } else
    u = a.insert("rect", ":first-child"), u.attr("class", "basic label-container").attr("style", n).attr("rx", Wt(f)).attr("ry", Wt(p)).attr("x", c).attr("y", h).attr("width", s).attr("height", l);
  return V(t, u), t.calcIntersect = function(m, y) {
    return q.rect(m, y);
  }, t.intersect = function(m) {
    return q.rect(t, m);
  }, a;
}
d(qa, "drawRect");
async function sg(e, t) {
  const { shapeSvg: r, bbox: i, label: n } = await et(e, t, "label"), a = r.insert("rect", ":first-child");
  return a.attr("width", 0.1).attr("height", 0.1), r.attr("class", "label edgeLabel"), n.attr(
    "transform",
    `translate(${-(i.width / 2) - (i.x - (i.left ?? 0))}, ${-(i.height / 2) - (i.y - (i.top ?? 0))})`
  ), V(t, a), t.intersect = function(l) {
    return q.rect(t, l);
  }, r;
}
d(sg, "labelRect");
async function og(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = Math.max(a.width + (t.padding ?? 0), (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0), (t == null ? void 0 : t.height) ?? 0), l = [
    { x: 0, y: 0 },
    { x: o + 3 * s / 6, y: 0 },
    { x: o, y: -s },
    { x: -(3 * s) / 6, y: -s }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = Y.svg(n), f = U(t, {}), p = lt(l), g = u.path(p, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && c.attr("style", h);
  } else
    c = Qe(n, o, s, l);
  return i && c.attr("style", i), t.width = o, t.height = s, V(t, c), t.intersect = function(u) {
    return q.polygon(t, l, u);
  }, n;
}
d(og, "lean_left");
async function lg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = Math.max(a.width + (t.padding ?? 0), (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0), (t == null ? void 0 : t.height) ?? 0), l = [
    { x: -3 * s / 6, y: 0 },
    { x: o, y: 0 },
    { x: o + 3 * s / 6, y: -s },
    { x: 0, y: -s }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = Y.svg(n), f = U(t, {}), p = lt(l), g = u.path(p, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && c.attr("style", h);
  } else
    c = Qe(n, o, s, l);
  return i && c.attr("style", i), t.width = o, t.height = s, V(t, c), t.intersect = function(u) {
    return q.polygon(t, l, u);
  }, n;
}
d(lg, "lean_right");
function cg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.label = "", t.labelStyle = r;
  const n = e.insert("g").attr("class", tt(t)).attr("id", t.domId ?? t.id), { cssStyles: a } = t, o = Math.max(35, (t == null ? void 0 : t.width) ?? 0), s = Math.max(35, (t == null ? void 0 : t.height) ?? 0), l = 7, c = [
    { x: o, y: 0 },
    { x: 0, y: s + l / 2 },
    { x: o - 2 * l, y: s + l / 2 },
    { x: 0, y: 2 * s },
    { x: o, y: s - l / 2 },
    { x: 2 * l, y: s - l / 2 }
  ], h = Y.svg(n), u = U(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const f = lt(c), p = h.path(f, u), g = n.insert(() => p, ":first-child");
  return a && t.look !== "handDrawn" && g.selectAll("path").attr("style", a), i && t.look !== "handDrawn" && g.selectAll("path").attr("style", i), g.attr("transform", `translate(-${o / 2},${-s})`), V(t, g), t.intersect = function(m) {
    return F.info("lightningBolt intersect", t, m), q.polygon(t, c, m);
  }, n;
}
d(cg, "lightningBolt");
var Zv = /* @__PURE__ */ d((e, t, r, i, n, a, o) => [
  `M${e},${t + a}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`,
  `M${e},${t + a + o}`,
  `a${n},${a} 0,0,0 ${r},0`
].join(" "), "createCylinderPathD"), Kv = /* @__PURE__ */ d((e, t, r, i, n, a, o) => [
  `M${e},${t + a}`,
  `M${e + r},${t + a}`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`,
  `M${e},${t + a + o}`,
  `a${n},${a} 0,0,0 ${r},0`
].join(" "), "createOuterCylinderPathD"), Qv = /* @__PURE__ */ d((e, t, r, i, n, a) => [`M${e - r / 2},${-i / 2}`, `a${n},${a} 0,0,0 ${r},0`].join(" "), "createInnerCylinderPathD");
async function hg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0), t.width ?? 0), l = s / 2, c = l / (2.5 + s / 50), h = Math.max(a.height + c + (t.padding ?? 0), t.height ?? 0), u = h * 0.1;
  let f;
  const { cssStyles: p } = t;
  if (t.look === "handDrawn") {
    const g = Y.svg(n), m = Kv(0, 0, s, h, l, c, u), y = Qv(0, c, s, h, l, c), x = U(t, {}), b = g.path(m, x), _ = g.path(y, x);
    n.insert(() => _, ":first-child").attr("class", "line"), f = n.insert(() => b, ":first-child"), f.attr("class", "basic label-container"), p && f.attr("style", p);
  } else {
    const g = Zv(0, 0, s, h, l, c, u);
    f = n.insert("path", ":first-child").attr("d", g).attr("class", "basic label-container").attr("style", Wt(p)).attr("style", i);
  }
  return f.attr("label-offset-y", c), f.attr("transform", `translate(${-s / 2}, ${-(h / 2 + c)})`), V(t, f), o.attr(
    "transform",
    `translate(${-(a.width / 2) - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + c - (a.y - (a.top ?? 0))})`
  ), t.intersect = function(g) {
    const m = q.rect(t, g), y = m.x - (t.x ?? 0);
    if (l != 0 && (Math.abs(y) < (t.width ?? 0) / 2 || Math.abs(y) == (t.width ?? 0) / 2 && Math.abs(m.y - (t.y ?? 0)) > (t.height ?? 0) / 2 - c)) {
      let x = c * c * (1 - y * y / (l * l));
      x > 0 && (x = Math.sqrt(x)), x = c - x, g.y - (t.y ?? 0) > 0 && (x = -x), m.y += x;
    }
    return m;
  }, n;
}
d(hg, "linedCylinder");
async function ug(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = l / 4, h = l + c, { cssStyles: u } = t, f = Y.svg(n), p = U(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = [
    { x: -s / 2 - s / 2 * 0.1, y: -h / 2 },
    { x: -s / 2 - s / 2 * 0.1, y: h / 2 },
    ...Xe(
      -s / 2 - s / 2 * 0.1,
      h / 2,
      s / 2 + s / 2 * 0.1,
      h / 2,
      c,
      0.8
    ),
    { x: s / 2 + s / 2 * 0.1, y: -h / 2 },
    { x: -s / 2 - s / 2 * 0.1, y: -h / 2 },
    { x: -s / 2, y: -h / 2 },
    { x: -s / 2, y: h / 2 * 1.1 },
    { x: -s / 2, y: -h / 2 }
  ], m = f.polygon(
    g.map((x) => [x.x, x.y]),
    p
  ), y = n.insert(() => m, ":first-child");
  return y.attr("class", "basic label-container"), u && t.look !== "handDrawn" && y.selectAll("path").attr("style", u), i && t.look !== "handDrawn" && y.selectAll("path").attr("style", i), y.attr("transform", `translate(0,${-c / 2})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) + s / 2 * 0.1 / 2 - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) - c / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, y), t.intersect = function(x) {
    return q.polygon(t, g, x);
  }, n;
}
d(ug, "linedWaveEdgedRect");
async function fg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = 5, h = -s / 2, u = -l / 2, { cssStyles: f } = t, p = Y.svg(n), g = U(t, {}), m = [
    { x: h - c, y: u + c },
    { x: h - c, y: u + l + c },
    { x: h + s - c, y: u + l + c },
    { x: h + s - c, y: u + l },
    { x: h + s, y: u + l },
    { x: h + s, y: u + l - c },
    { x: h + s + c, y: u + l - c },
    { x: h + s + c, y: u - c },
    { x: h + c, y: u - c },
    { x: h + c, y: u },
    { x: h, y: u },
    { x: h, y: u + c }
  ], y = [
    { x: h, y: u + c },
    { x: h + s - c, y: u + c },
    { x: h + s - c, y: u + l },
    { x: h + s, y: u + l },
    { x: h + s, y: u },
    { x: h, y: u }
  ];
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const x = lt(m), b = p.path(x, g), _ = lt(y), v = p.path(_, { ...g, fill: "none" }), w = n.insert(() => v, ":first-child");
  return w.insert(() => b, ":first-child"), w.attr("class", "basic label-container"), f && t.look !== "handDrawn" && w.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && w.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${-(a.width / 2) - c - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + c - (a.y - (a.top ?? 0))})`
  ), V(t, w), t.intersect = function(C) {
    return q.polygon(t, m, C);
  }, n;
}
d(fg, "multiRect");
async function pg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = l / 4, h = l + c, u = -s / 2, f = -h / 2, p = 5, { cssStyles: g } = t, m = Xe(
    u - p,
    f + h + p,
    u + s - p,
    f + h + p,
    c,
    0.8
  ), y = m == null ? void 0 : m[m.length - 1], x = [
    { x: u - p, y: f + p },
    { x: u - p, y: f + h + p },
    ...m,
    { x: u + s - p, y: y.y - p },
    { x: u + s, y: y.y - p },
    { x: u + s, y: y.y - 2 * p },
    { x: u + s + p, y: y.y - 2 * p },
    { x: u + s + p, y: f - p },
    { x: u + p, y: f - p },
    { x: u + p, y: f },
    { x: u, y: f },
    { x: u, y: f + p }
  ], b = [
    { x: u, y: f + p },
    { x: u + s - p, y: f + p },
    { x: u + s - p, y: y.y - p },
    { x: u + s, y: y.y - p },
    { x: u + s, y: f },
    { x: u, y: f }
  ], _ = Y.svg(n), v = U(t, {});
  t.look !== "handDrawn" && (v.roughness = 0, v.fillStyle = "solid");
  const w = lt(x), C = _.path(w, v), S = lt(b), D = _.path(S, v), P = n.insert(() => C, ":first-child");
  return P.insert(() => D), P.attr("class", "basic label-container"), g && t.look !== "handDrawn" && P.selectAll("path").attr("style", g), i && t.look !== "handDrawn" && P.selectAll("path").attr("style", i), P.attr("transform", `translate(0,${-c / 2})`), o.attr(
    "transform",
    `translate(${-(a.width / 2) - p - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + p - c / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, P), t.intersect = function(R) {
    return q.polygon(t, x, R);
  }, n;
}
d(pg, "multiWaveEdgedRectangle");
async function dg(e, t, { config: { themeVariables: r } }) {
  var b;
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i, t.useHtmlLabels || ((b = Nt().flowchart) == null ? void 0 : b.htmlLabels) !== !1 || (t.centerLabel = !0);
  const { shapeSvg: o, bbox: s, label: l } = await et(e, t, tt(t)), c = Math.max(s.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), h = Math.max(s.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), u = -c / 2, f = -h / 2, { cssStyles: p } = t, g = Y.svg(o), m = U(t, {
    fill: r.noteBkgColor,
    stroke: r.noteBorderColor
  });
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const y = g.rectangle(u, f, c, h, m), x = o.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container"), p && t.look !== "handDrawn" && x.selectAll("path").attr("style", p), n && t.look !== "handDrawn" && x.selectAll("path").attr("style", n), l.attr(
    "transform",
    `translate(${-s.width / 2 - (s.x - (s.left ?? 0))}, ${-(s.height / 2) - (s.y - (s.top ?? 0))})`
  ), V(t, x), t.intersect = function(_) {
    return q.rect(t, _);
  }, o;
}
d(dg, "note");
var Jv = /* @__PURE__ */ d((e, t, r) => [
  `M${e + r / 2},${t}`,
  `L${e + r},${t - r / 2}`,
  `L${e + r / 2},${t - r}`,
  `L${e},${t - r / 2}`,
  "Z"
].join(" "), "createDecisionBoxPathD");
async function gg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = a.width + t.padding, s = a.height + t.padding, l = o + s, c = 0.5, h = [
    { x: l / 2, y: 0 },
    { x: l, y: -l / 2 },
    { x: l / 2, y: -l },
    { x: 0, y: -l / 2 }
  ];
  let u;
  const { cssStyles: f } = t;
  if (t.look === "handDrawn") {
    const p = Y.svg(n), g = U(t, {}), m = Jv(0, 0, l), y = p.path(m, g);
    u = n.insert(() => y, ":first-child").attr("transform", `translate(${-l / 2 + c}, ${l / 2})`), f && u.attr("style", f);
  } else
    u = Qe(n, l, l, h), u.attr("transform", `translate(${-l / 2 + c}, ${l / 2})`);
  return i && u.attr("style", i), V(t, u), t.calcIntersect = function(p, g) {
    const m = p.width, y = [
      { x: m / 2, y: 0 },
      { x: m, y: -m / 2 },
      { x: m / 2, y: -m },
      { x: 0, y: -m / 2 }
    ], x = q.polygon(p, y, g);
    return { x: x.x - 0.5, y: x.y - 0.5 };
  }, t.intersect = function(p) {
    return this.calcIntersect(t, p);
  }, n;
}
d(gg, "question");
async function mg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0), (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0), (t == null ? void 0 : t.height) ?? 0), c = -s / 2, h = -l / 2, u = h / 2, f = [
    { x: c + u, y: h },
    { x: c, y: 0 },
    { x: c + u, y: -h },
    { x: -c, y: -h },
    { x: -c, y: h }
  ], { cssStyles: p } = t, g = Y.svg(n), m = U(t, {});
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const y = lt(f), x = g.path(y, m), b = n.insert(() => x, ":first-child");
  return b.attr("class", "basic label-container"), p && t.look !== "handDrawn" && b.selectAll("path").attr("style", p), i && t.look !== "handDrawn" && b.selectAll("path").attr("style", i), b.attr("transform", `translate(${-u / 2},0)`), o.attr(
    "transform",
    `translate(${-u / 2 - a.width / 2 - (a.x - (a.left ?? 0))}, ${-(a.height / 2) - (a.y - (a.top ?? 0))})`
  ), V(t, b), t.intersect = function(_) {
    return q.polygon(t, f, _);
  }, n;
}
d(mg, "rect_left_inv_arrow");
async function yg(e, t) {
  var D, P;
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  let n;
  t.cssClasses ? n = "node " + t.cssClasses : n = "node default";
  const a = e.insert("g").attr("class", n).attr("id", t.domId || t.id), o = a.insert("g"), s = a.insert("g").attr("class", "label").attr("style", i), l = t.description, c = t.label, h = s.node().appendChild(await cr(c, t.labelStyle, !0, !0));
  let u = { width: 0, height: 0 };
  if (Lt((P = (D = pt()) == null ? void 0 : D.flowchart) == null ? void 0 : P.htmlLabels)) {
    const R = h.children[0], $ = ht(h);
    u = R.getBoundingClientRect(), $.attr("width", u.width), $.attr("height", u.height);
  }
  F.info("Text 2", l);
  const f = l || [], p = h.getBBox(), g = s.node().appendChild(
    await cr(
      f.join ? f.join("<br/>") : f,
      t.labelStyle,
      !0,
      !0
    )
  ), m = g.children[0], y = ht(g);
  u = m.getBoundingClientRect(), y.attr("width", u.width), y.attr("height", u.height);
  const x = (t.padding || 0) / 2;
  ht(g).attr(
    "transform",
    "translate( " + (u.width > p.width ? 0 : (p.width - u.width) / 2) + ", " + (p.height + x + 5) + ")"
  ), ht(h).attr(
    "transform",
    "translate( " + (u.width < p.width ? 0 : -(p.width - u.width) / 2) + ", 0)"
  ), u = s.node().getBBox(), s.attr(
    "transform",
    "translate(" + -u.width / 2 + ", " + (-u.height / 2 - x + 3) + ")"
  );
  const b = u.width + (t.padding || 0), _ = u.height + (t.padding || 0), v = -u.width / 2 - x, w = -u.height / 2 - x;
  let C, S;
  if (t.look === "handDrawn") {
    const R = Y.svg(a), $ = U(t, {}), z = R.path(
      Ke(v, w, b, _, t.rx || 0),
      $
    ), O = R.line(
      -u.width / 2 - x,
      -u.height / 2 - x + p.height + x,
      u.width / 2 + x,
      -u.height / 2 - x + p.height + x,
      $
    );
    S = a.insert(() => (F.debug("Rough node insert CXC", z), O), ":first-child"), C = a.insert(() => (F.debug("Rough node insert CXC", z), z), ":first-child");
  } else
    C = o.insert("rect", ":first-child"), S = o.insert("line"), C.attr("class", "outer title-state").attr("style", i).attr("x", -u.width / 2 - x).attr("y", -u.height / 2 - x).attr("width", u.width + (t.padding || 0)).attr("height", u.height + (t.padding || 0)), S.attr("class", "divider").attr("x1", -u.width / 2 - x).attr("x2", u.width / 2 + x).attr("y1", -u.height / 2 - x + p.height + x).attr("y2", -u.height / 2 - x + p.height + x);
  return V(t, C), t.intersect = function(R) {
    return q.rect(t, R);
  }, a;
}
d(yg, "rectWithTitle");
function Ti(e, t, r, i, n, a, o) {
  const l = (e + r) / 2, c = (t + i) / 2, h = Math.atan2(i - t, r - e), u = (r - e) / 2, f = (i - t) / 2, p = u / n, g = f / a, m = Math.sqrt(p ** 2 + g ** 2);
  if (m > 1)
    throw new Error("The given radii are too small to create an arc between the points.");
  const y = Math.sqrt(1 - m ** 2), x = l + y * a * Math.sin(h) * (o ? -1 : 1), b = c - y * n * Math.cos(h) * (o ? -1 : 1), _ = Math.atan2((t - b) / a, (e - x) / n);
  let w = Math.atan2((i - b) / a, (r - x) / n) - _;
  o && w < 0 && (w += 2 * Math.PI), !o && w > 0 && (w -= 2 * Math.PI);
  const C = [];
  for (let S = 0; S < 20; S++) {
    const D = S / 19, P = _ + D * w, R = x + n * Math.cos(P), $ = b + a * Math.sin(P);
    C.push({ x: R, y: $ });
  }
  return C;
}
d(Ti, "generateArcPoints");
async function xg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = (t == null ? void 0 : t.padding) ?? 0, s = (t == null ? void 0 : t.padding) ?? 0, l = (t != null && t.width ? t == null ? void 0 : t.width : a.width) + o * 2, c = (t != null && t.height ? t == null ? void 0 : t.height : a.height) + s * 2, h = t.radius || 5, u = t.taper || 5, { cssStyles: f } = t, p = Y.svg(n), g = U(t, {});
  t.stroke && (g.stroke = t.stroke), t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = [
    // Top edge (left to right)
    { x: -l / 2 + u, y: -c / 2 },
    // Top-left corner start (1)
    { x: l / 2 - u, y: -c / 2 },
    // Top-right corner start (2)
    ...Ti(l / 2 - u, -c / 2, l / 2, -c / 2 + u, h, h, !0),
    // Top-left arc (2 to 3)
    // Right edge (top to bottom)
    { x: l / 2, y: -c / 2 + u },
    // Top-right taper point (3)
    { x: l / 2, y: c / 2 - u },
    // Bottom-right taper point (4)
    ...Ti(l / 2, c / 2 - u, l / 2 - u, c / 2, h, h, !0),
    // Top-left arc (4 to 5)
    // Bottom edge (right to left)
    { x: l / 2 - u, y: c / 2 },
    // Bottom-right corner start (5)
    { x: -l / 2 + u, y: c / 2 },
    // Bottom-left corner start (6)
    ...Ti(-l / 2 + u, c / 2, -l / 2, c / 2 - u, h, h, !0),
    // Top-left arc (4 to 5)
    // Left edge (bottom to top)
    { x: -l / 2, y: c / 2 - u },
    // Bottom-left taper point (7)
    { x: -l / 2, y: -c / 2 + u },
    // Top-left taper point (8)
    ...Ti(-l / 2, -c / 2 + u, -l / 2 + u, -c / 2, h, h, !0)
    // Top-left arc (4 to 5)
  ], y = lt(m), x = p.path(y, g), b = n.insert(() => x, ":first-child");
  return b.attr("class", "basic label-container outer-path"), f && t.look !== "handDrawn" && b.selectChildren("path").attr("style", f), i && t.look !== "handDrawn" && b.selectChildren("path").attr("style", i), V(t, b), t.intersect = function(_) {
    return q.polygon(t, m, _);
  }, n;
}
d(xg, "roundedRect");
async function bg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = (t == null ? void 0 : t.padding) ?? 0, l = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = -a.width / 2 - s, u = -a.height / 2 - s, { cssStyles: f } = t, p = Y.svg(n), g = U(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = [
    { x: h, y: u },
    { x: h + l + 8, y: u },
    { x: h + l + 8, y: u + c },
    { x: h - 8, y: u + c },
    { x: h - 8, y: u },
    { x: h, y: u },
    { x: h, y: u + c }
  ], y = p.polygon(
    m.map((b) => [b.x, b.y]),
    g
  ), x = n.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container").attr("style", Wt(f)), i && t.look !== "handDrawn" && x.selectAll("path").attr("style", i), f && t.look !== "handDrawn" && x.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${-l / 2 + 4 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-c / 2 + (t.padding ?? 0) - (a.y - (a.top ?? 0))})`
  ), V(t, x), t.intersect = function(b) {
    return q.rect(t, b);
  }, n;
}
d(bg, "shadedProcess");
async function Cg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = -s / 2, h = -l / 2, { cssStyles: u } = t, f = Y.svg(n), p = U(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = [
    { x: c, y: h },
    { x: c, y: h + l },
    { x: c + s, y: h + l },
    { x: c + s, y: h - l / 2 }
  ], m = lt(g), y = f.path(m, p), x = n.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container"), u && t.look !== "handDrawn" && x.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && x.selectChildren("path").attr("style", i), x.attr("transform", `translate(0, ${l / 4})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))}, ${-l / 4 + (t.padding ?? 0) - (a.y - (a.top ?? 0))})`
  ), V(t, x), t.intersect = function(b) {
    return q.polygon(t, g, b);
  }, n;
}
d(Cg, "slopedRect");
async function _g(e, t) {
  const r = {
    rx: 0,
    ry: 0,
    labelPaddingX: t.labelPaddingX ?? ((t == null ? void 0 : t.padding) || 0) * 2,
    labelPaddingY: ((t == null ? void 0 : t.padding) || 0) * 1
  };
  return qa(e, t, r);
}
d(_g, "squareRect");
async function wg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = a.height + t.padding, s = a.width + o / 4 + t.padding, l = o / 2, { cssStyles: c } = t, h = Y.svg(n), u = U(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const f = [
    { x: -s / 2 + l, y: -o / 2 },
    { x: s / 2 - l, y: -o / 2 },
    ...Yi(-s / 2 + l, 0, l, 50, 90, 270),
    { x: s / 2 - l, y: o / 2 },
    ...Yi(s / 2 - l, 0, l, 50, 270, 450)
  ], p = lt(f), g = h.path(p, u), m = n.insert(() => g, ":first-child");
  return m.attr("class", "basic label-container outer-path"), c && t.look !== "handDrawn" && m.selectChildren("path").attr("style", c), i && t.look !== "handDrawn" && m.selectChildren("path").attr("style", i), V(t, m), t.intersect = function(y) {
    return q.polygon(t, f, y);
  }, n;
}
d(wg, "stadium");
async function kg(e, t) {
  return qa(e, t, {
    rx: 5,
    ry: 5
  });
}
d(kg, "state");
function vg(e, t, { config: { themeVariables: r } }) {
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i;
  const { cssStyles: a } = t, { lineColor: o, stateBorder: s, nodeBorder: l } = r, c = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id), h = Y.svg(c), u = U(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const f = h.circle(0, 0, 14, {
    ...u,
    stroke: o,
    strokeWidth: 2
  }), p = s ?? l, g = h.circle(0, 0, 5, {
    ...u,
    fill: p,
    stroke: p,
    strokeWidth: 2,
    fillStyle: "solid"
  }), m = c.insert(() => f, ":first-child");
  return m.insert(() => g), a && m.selectAll("path").attr("style", a), n && m.selectAll("path").attr("style", n), V(t, m), t.intersect = function(y) {
    return q.circle(t, 7, y);
  }, c;
}
d(vg, "stateEnd");
function Sg(e, t, { config: { themeVariables: r } }) {
  const { lineColor: i } = r, n = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id);
  let a;
  if (t.look === "handDrawn") {
    const s = Y.svg(n).circle(0, 0, 14, pC(i));
    a = n.insert(() => s), a.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14);
  } else
    a = n.insert("circle", ":first-child"), a.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14);
  return V(t, a), t.intersect = function(o) {
    return q.circle(t, 7, o);
  }, n;
}
d(Sg, "stateStart");
async function Tg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = ((t == null ? void 0 : t.padding) || 0) / 2, s = a.width + t.padding, l = a.height + t.padding, c = -a.width / 2 - o, h = -a.height / 2 - o, u = [
    { x: 0, y: 0 },
    { x: s, y: 0 },
    { x: s, y: -l },
    { x: 0, y: -l },
    { x: 0, y: 0 },
    { x: -8, y: 0 },
    { x: s + 8, y: 0 },
    { x: s + 8, y: -l },
    { x: -8, y: -l },
    { x: -8, y: 0 }
  ];
  if (t.look === "handDrawn") {
    const f = Y.svg(n), p = U(t, {}), g = f.rectangle(c - 8, h, s + 16, l, p), m = f.line(c, h, c, h + l, p), y = f.line(c + s, h, c + s, h + l, p);
    n.insert(() => m, ":first-child"), n.insert(() => y, ":first-child");
    const x = n.insert(() => g, ":first-child"), { cssStyles: b } = t;
    x.attr("class", "basic label-container").attr("style", Wt(b)), V(t, x);
  } else {
    const f = Qe(n, s, l, u);
    i && f.attr("style", i), V(t, f);
  }
  return t.intersect = function(f) {
    return q.polygon(t, u, f);
  }, n;
}
d(Tg, "subroutine");
async function Bg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), l = -o / 2, c = -s / 2, h = 0.2 * s, u = 0.2 * s, { cssStyles: f } = t, p = Y.svg(n), g = U(t, {}), m = [
    { x: l - h / 2, y: c },
    { x: l + o + h / 2, y: c },
    { x: l + o + h / 2, y: c + s },
    { x: l - h / 2, y: c + s }
  ], y = [
    { x: l + o - h / 2, y: c + s },
    { x: l + o + h / 2, y: c + s },
    { x: l + o + h / 2, y: c + s - u }
  ];
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const x = lt(m), b = p.path(x, g), _ = lt(y), v = p.path(_, { ...g, fillStyle: "solid" }), w = n.insert(() => v, ":first-child");
  return w.insert(() => b, ":first-child"), w.attr("class", "basic label-container"), f && t.look !== "handDrawn" && w.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && w.selectAll("path").attr("style", i), V(t, w), t.intersect = function(C) {
    return q.polygon(t, m, C);
  }, n;
}
d(Bg, "taggedRect");
async function Ag(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = l / 4, h = 0.2 * s, u = 0.2 * l, f = l + c, { cssStyles: p } = t, g = Y.svg(n), m = U(t, {});
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const y = [
    { x: -s / 2 - s / 2 * 0.1, y: f / 2 },
    ...Xe(
      -s / 2 - s / 2 * 0.1,
      f / 2,
      s / 2 + s / 2 * 0.1,
      f / 2,
      c,
      0.8
    ),
    { x: s / 2 + s / 2 * 0.1, y: -f / 2 },
    { x: -s / 2 - s / 2 * 0.1, y: -f / 2 }
  ], x = -s / 2 + s / 2 * 0.1, b = -f / 2 - u * 0.4, _ = [
    { x: x + s - h, y: (b + l) * 1.4 },
    { x: x + s, y: b + l - u },
    { x: x + s, y: (b + l) * 0.9 },
    ...Xe(
      x + s,
      (b + l) * 1.3,
      x + s - h,
      (b + l) * 1.5,
      -l * 0.03,
      0.5
    )
  ], v = lt(y), w = g.path(v, m), C = lt(_), S = g.path(C, {
    ...m,
    fillStyle: "solid"
  }), D = n.insert(() => S, ":first-child");
  return D.insert(() => w, ":first-child"), D.attr("class", "basic label-container"), p && t.look !== "handDrawn" && D.selectAll("path").attr("style", p), i && t.look !== "handDrawn" && D.selectAll("path").attr("style", i), D.attr("transform", `translate(0,${-c / 2})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) - c / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, D), t.intersect = function(P) {
    return q.polygon(t, y, P);
  }, n;
}
d(Ag, "taggedWaveEdgedRectangle");
async function Lg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = Math.max(a.width + t.padding, (t == null ? void 0 : t.width) || 0), s = Math.max(a.height + t.padding, (t == null ? void 0 : t.height) || 0), l = -o / 2, c = -s / 2, h = n.insert("rect", ":first-child");
  return h.attr("class", "text").attr("style", i).attr("rx", 0).attr("ry", 0).attr("x", l).attr("y", c).attr("width", o).attr("height", s), V(t, h), t.intersect = function(u) {
    return q.rect(t, u);
  }, n;
}
d(Lg, "text");
var tS = /* @__PURE__ */ d((e, t, r, i, n, a) => `M${e},${t}
    a${n},${a} 0,0,1 0,${-i}
    l${r},0
    a${n},${a} 0,0,1 0,${i}
    M${r},${-i}
    a${n},${a} 0,0,0 0,${i}
    l${-r},0`, "createCylinderPathD"), eS = /* @__PURE__ */ d((e, t, r, i, n, a) => [
  `M${e},${t}`,
  `M${e + r},${t}`,
  `a${n},${a} 0,0,0 0,${-i}`,
  `l${-r},0`,
  `a${n},${a} 0,0,0 0,${i}`,
  `l${r},0`
].join(" "), "createOuterCylinderPathD"), rS = /* @__PURE__ */ d((e, t, r, i, n, a) => [`M${e + r / 2},${-i / 2}`, `a${n},${a} 0,0,0 0,${i}`].join(" "), "createInnerCylinderPathD");
async function Mg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o, halfPadding: s } = await et(
    e,
    t,
    tt(t)
  ), l = t.look === "neo" ? s * 2 : s, c = a.height + l, h = c / 2, u = h / (2.5 + c / 50), f = a.width + u + l, { cssStyles: p } = t;
  let g;
  if (t.look === "handDrawn") {
    const m = Y.svg(n), y = eS(0, 0, f, c, u, h), x = rS(0, 0, f, c, u, h), b = m.path(y, U(t, {})), _ = m.path(x, U(t, { fill: "none" }));
    g = n.insert(() => _, ":first-child"), g = n.insert(() => b, ":first-child"), g.attr("class", "basic label-container"), p && g.attr("style", p);
  } else {
    const m = tS(0, 0, f, c, u, h);
    g = n.insert("path", ":first-child").attr("d", m).attr("class", "basic label-container").attr("style", Wt(p)).attr("style", i), g.attr("class", "basic label-container"), p && g.selectAll("path").attr("style", p), i && g.selectAll("path").attr("style", i);
  }
  return g.attr("label-offset-x", u), g.attr("transform", `translate(${-f / 2}, ${c / 2} )`), o.attr(
    "transform",
    `translate(${-(a.width / 2) - u - (a.x - (a.left ?? 0))}, ${-(a.height / 2) - (a.y - (a.top ?? 0))})`
  ), V(t, g), t.intersect = function(m) {
    const y = q.rect(t, m), x = y.y - (t.y ?? 0);
    if (h != 0 && (Math.abs(x) < (t.height ?? 0) / 2 || Math.abs(x) == (t.height ?? 0) / 2 && Math.abs(y.x - (t.x ?? 0)) > (t.width ?? 0) / 2 - u)) {
      let b = u * u * (1 - x * x / (h * h));
      b != 0 && (b = Math.sqrt(Math.abs(b))), b = u - b, m.x - (t.x ?? 0) > 0 && (b = -b), y.x += b;
    }
    return y;
  }, n;
}
d(Mg, "tiltedCylinder");
async function $g(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = a.width + t.padding, s = a.height + t.padding, l = [
    { x: -3 * s / 6, y: 0 },
    { x: o + 3 * s / 6, y: 0 },
    { x: o, y: -s },
    { x: 0, y: -s }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = Y.svg(n), f = U(t, {}), p = lt(l), g = u.path(p, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && c.attr("style", h);
  } else
    c = Qe(n, o, s, l);
  return i && c.attr("style", i), t.width = o, t.height = s, V(t, c), t.intersect = function(u) {
    return q.polygon(t, l, u);
  }, n;
}
d($g, "trapezoid");
async function Eg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = 60, s = 20, l = Math.max(o, a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(s, a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), { cssStyles: h } = t, u = Y.svg(n), f = U(t, {});
  t.look !== "handDrawn" && (f.roughness = 0, f.fillStyle = "solid");
  const p = [
    { x: -l / 2 * 0.8, y: -c / 2 },
    { x: l / 2 * 0.8, y: -c / 2 },
    { x: l / 2, y: -c / 2 * 0.6 },
    { x: l / 2, y: c / 2 },
    { x: -l / 2, y: c / 2 },
    { x: -l / 2, y: -c / 2 * 0.6 }
  ], g = lt(p), m = u.path(g, f), y = n.insert(() => m, ":first-child");
  return y.attr("class", "basic label-container"), h && t.look !== "handDrawn" && y.selectChildren("path").attr("style", h), i && t.look !== "handDrawn" && y.selectChildren("path").attr("style", i), V(t, y), t.intersect = function(x) {
    return q.polygon(t, p, x);
  }, n;
}
d(Eg, "trapezoidalPentagon");
async function Fg(e, t) {
  var b;
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Lt((b = pt().flowchart) == null ? void 0 : b.htmlLabels), l = a.width + (t.padding ?? 0), c = l + a.height, h = l + a.height, u = [
    { x: 0, y: 0 },
    { x: h, y: 0 },
    { x: h / 2, y: -c }
  ], { cssStyles: f } = t, p = Y.svg(n), g = U(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = lt(u), y = p.path(m, g), x = n.insert(() => y, ":first-child").attr("transform", `translate(${-c / 2}, ${c / 2})`);
  return f && t.look !== "handDrawn" && x.selectChildren("path").attr("style", f), i && t.look !== "handDrawn" && x.selectChildren("path").attr("style", i), t.width = l, t.height = c, V(t, x), o.attr(
    "transform",
    `translate(${-a.width / 2 - (a.x - (a.left ?? 0))}, ${c / 2 - (a.height + (t.padding ?? 0) / (s ? 2 : 1) - (a.y - (a.top ?? 0)))})`
  ), t.intersect = function(_) {
    return F.info("Triangle intersect", t, u, _), q.polygon(t, u, _);
  }, n;
}
d(Fg, "triangle");
async function Dg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = l / 8, h = l + c, { cssStyles: u } = t, p = 70 - s, g = p > 0 ? p / 2 : 0, m = Y.svg(n), y = U(t, {});
  t.look !== "handDrawn" && (y.roughness = 0, y.fillStyle = "solid");
  const x = [
    { x: -s / 2 - g, y: h / 2 },
    ...Xe(
      -s / 2 - g,
      h / 2,
      s / 2 + g,
      h / 2,
      c,
      0.8
    ),
    { x: s / 2 + g, y: -h / 2 },
    { x: -s / 2 - g, y: -h / 2 }
  ], b = lt(x), _ = m.path(b, y), v = n.insert(() => _, ":first-child");
  return v.attr("class", "basic label-container"), u && t.look !== "handDrawn" && v.selectAll("path").attr("style", u), i && t.look !== "handDrawn" && v.selectAll("path").attr("style", i), v.attr("transform", `translate(0,${-c / 2})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) - c - (a.y - (a.top ?? 0))})`
  ), V(t, v), t.intersect = function(w) {
    return q.polygon(t, x, w);
  }, n;
}
d(Dg, "waveEdgedRectangle");
async function Og(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = 100, s = 50, l = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = l / c;
  let u = l, f = c;
  u > f * h ? f = u / h : u = f * h, u = Math.max(u, o), f = Math.max(f, s);
  const p = Math.min(f * 0.2, f / 4), g = f + p * 2, { cssStyles: m } = t, y = Y.svg(n), x = U(t, {});
  t.look !== "handDrawn" && (x.roughness = 0, x.fillStyle = "solid");
  const b = [
    { x: -u / 2, y: g / 2 },
    ...Xe(-u / 2, g / 2, u / 2, g / 2, p, 1),
    { x: u / 2, y: -g / 2 },
    ...Xe(u / 2, -g / 2, -u / 2, -g / 2, p, -1)
  ], _ = lt(b), v = y.path(_, x), w = n.insert(() => v, ":first-child");
  return w.attr("class", "basic label-container"), m && t.look !== "handDrawn" && w.selectAll("path").attr("style", m), i && t.look !== "handDrawn" && w.selectAll("path").attr("style", i), V(t, w), t.intersect = function(C) {
    return q.polygon(t, b, C);
  }, n;
}
d(Og, "waveRectangle");
async function Rg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = 5, h = -s / 2, u = -l / 2, { cssStyles: f } = t, p = Y.svg(n), g = U(t, {}), m = [
    { x: h - c, y: u - c },
    { x: h - c, y: u + l },
    { x: h + s, y: u + l },
    { x: h + s, y: u - c }
  ], y = `M${h - c},${u - c} L${h + s},${u - c} L${h + s},${u + l} L${h - c},${u + l} L${h - c},${u - c}
                M${h - c},${u} L${h + s},${u}
                M${h},${u - c} L${h},${u + l}`;
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const x = p.path(y, g), b = n.insert(() => x, ":first-child");
  return b.attr("transform", `translate(${c / 2}, ${c / 2})`), b.attr("class", "basic label-container"), f && t.look !== "handDrawn" && b.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && b.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${-(a.width / 2) + c / 2 - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + c / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, b), t.intersect = function(_) {
    return q.polygon(t, m, _);
  }, n;
}
d(Rg, "windowPane");
async function _l(e, t) {
  var ut, nt, gt, st;
  const r = t;
  if (r.alias && (t.label = r.alias), t.look === "handDrawn") {
    const { themeVariables: at } = Nt(), { background: ct } = at, yt = {
      ...t,
      id: t.id + "-background",
      look: "default",
      cssStyles: ["stroke: none", `fill: ${ct}`]
    };
    await _l(e, yt);
  }
  const i = Nt();
  t.useHtmlLabels = i.htmlLabels;
  let n = ((ut = i.er) == null ? void 0 : ut.diagramPadding) ?? 10, a = ((nt = i.er) == null ? void 0 : nt.entityPadding) ?? 6;
  const { cssStyles: o } = t, { labelStyles: s, nodeStyles: l } = G(t);
  if (r.attributes.length === 0 && t.label) {
    const at = {
      rx: 0,
      ry: 0,
      labelPaddingX: n,
      labelPaddingY: n * 1.5
    };
    Pe(t.label, i) + at.labelPaddingX * 2 < i.er.minEntityWidth && (t.width = i.er.minEntityWidth);
    const ct = await qa(e, t, at);
    if (!Lt(i.htmlLabels)) {
      const yt = ct.select("text"), Ct = (gt = yt.node()) == null ? void 0 : gt.getBBox();
      yt.attr("transform", `translate(${-Ct.width / 2}, 0)`);
    }
    return ct;
  }
  i.htmlLabels || (n *= 1.25, a *= 1.25);
  let c = tt(t);
  c || (c = "node default");
  const h = e.insert("g").attr("class", c).attr("id", t.domId || t.id), u = await Fr(h, t.label ?? "", i, 0, 0, ["name"], s);
  u.height += a;
  let f = 0;
  const p = [], g = [];
  let m = 0, y = 0, x = 0, b = 0, _ = !0, v = !0;
  for (const at of r.attributes) {
    const ct = await Fr(
      h,
      at.type,
      i,
      0,
      f,
      ["attribute-type"],
      s
    );
    m = Math.max(m, ct.width + n);
    const yt = await Fr(
      h,
      at.name,
      i,
      0,
      f,
      ["attribute-name"],
      s
    );
    y = Math.max(y, yt.width + n);
    const Ct = await Fr(
      h,
      at.keys.join(),
      i,
      0,
      f,
      ["attribute-keys"],
      s
    );
    x = Math.max(x, Ct.width + n);
    const xt = await Fr(
      h,
      at.comment,
      i,
      0,
      f,
      ["attribute-comment"],
      s
    );
    b = Math.max(b, xt.width + n);
    const vt = Math.max(ct.height, yt.height, Ct.height, xt.height) + a;
    g.push({ yOffset: f, rowHeight: vt }), f += vt;
  }
  let w = 4;
  x <= n && (_ = !1, x = 0, w--), b <= n && (v = !1, b = 0, w--);
  const C = h.node().getBBox();
  if (u.width + n * 2 - (m + y + x + b) > 0) {
    const at = u.width + n * 2 - (m + y + x + b);
    m += at / w, y += at / w, x > 0 && (x += at / w), b > 0 && (b += at / w);
  }
  const S = m + y + x + b, D = Y.svg(h), P = U(t, {});
  t.look !== "handDrawn" && (P.roughness = 0, P.fillStyle = "solid");
  let R = 0;
  g.length > 0 && (R = g.reduce((at, ct) => at + ((ct == null ? void 0 : ct.rowHeight) ?? 0), 0));
  const $ = Math.max(C.width + n * 2, (t == null ? void 0 : t.width) || 0, S), z = Math.max((R ?? 0) + u.height, (t == null ? void 0 : t.height) || 0), O = -$ / 2, M = -z / 2;
  h.selectAll("g:not(:first-child)").each((at, ct, yt) => {
    const Ct = ht(yt[ct]), xt = Ct.attr("transform");
    let vt = 0, le = 0;
    if (xt) {
      const ze = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(xt);
      ze && (vt = parseFloat(ze[1]), le = parseFloat(ze[2]), Ct.attr("class").includes("attribute-name") ? vt += m : Ct.attr("class").includes("attribute-keys") ? vt += m + y : Ct.attr("class").includes("attribute-comment") && (vt += m + y + x));
    }
    Ct.attr(
      "transform",
      `translate(${O + n / 2 + vt}, ${le + M + u.height + a / 2})`
    );
  }), h.select(".name").attr("transform", "translate(" + -u.width / 2 + ", " + (M + a / 2) + ")");
  const A = D.rectangle(O, M, $, z, P), B = h.insert(() => A, ":first-child").attr("style", o.join("")), { themeVariables: E } = Nt(), { rowEven: L, rowOdd: W, nodeBorder: X } = E;
  p.push(0);
  for (const [at, ct] of g.entries()) {
    const Ct = (at + 1) % 2 === 0 && ct.yOffset !== 0, xt = D.rectangle(O, u.height + M + (ct == null ? void 0 : ct.yOffset), $, ct == null ? void 0 : ct.rowHeight, {
      ...P,
      fill: Ct ? L : W,
      stroke: X
    });
    h.insert(() => xt, "g.label").attr("style", o.join("")).attr("class", `row-rect-${Ct ? "even" : "odd"}`);
  }
  let H = D.line(O, u.height + M, $ + O, u.height + M, P);
  h.insert(() => H).attr("class", "divider"), H = D.line(m + O, u.height + M, m + O, z + M, P), h.insert(() => H).attr("class", "divider"), _ && (H = D.line(
    m + y + O,
    u.height + M,
    m + y + O,
    z + M,
    P
  ), h.insert(() => H).attr("class", "divider")), v && (H = D.line(
    m + y + x + O,
    u.height + M,
    m + y + x + O,
    z + M,
    P
  ), h.insert(() => H).attr("class", "divider"));
  for (const at of p)
    H = D.line(
      O,
      u.height + M + at,
      $ + O,
      u.height + M + at,
      P
    ), h.insert(() => H).attr("class", "divider");
  if (V(t, B), l && t.look !== "handDrawn") {
    const at = l.split(";"), ct = (st = at == null ? void 0 : at.filter((yt) => yt.includes("stroke"))) == null ? void 0 : st.map((yt) => `${yt}`).join("; ");
    h.selectAll("path").attr("style", ct ?? ""), h.selectAll(".row-rect-even path").attr("style", l);
  }
  return t.intersect = function(at) {
    return q.rect(t, at);
  }, h;
}
d(_l, "erBox");
async function Fr(e, t, r, i = 0, n = 0, a = [], o = "") {
  const s = e.insert("g").attr("class", `label ${a.join(" ")}`).attr("transform", `translate(${i}, ${n})`).attr("style", o);
  t !== ec(t) && (t = ec(t), t = t.replaceAll("<", "&lt;").replaceAll(">", "&gt;"));
  const l = s.node().appendChild(
    await Ze(
      s,
      t,
      {
        width: Pe(t, r) + 100,
        style: o,
        useHtmlLabels: r.htmlLabels
      },
      r
    )
  );
  if (t.includes("&lt;") || t.includes("&gt;")) {
    let h = l.children[0];
    for (h.textContent = h.textContent.replaceAll("&lt;", "<").replaceAll("&gt;", ">"); h.childNodes[0]; )
      h = h.childNodes[0], h.textContent = h.textContent.replaceAll("&lt;", "<").replaceAll("&gt;", ">");
  }
  let c = l.getBBox();
  if (Lt(r.htmlLabels)) {
    const h = l.children[0];
    h.style.textAlign = "start";
    const u = ht(l);
    c = h.getBoundingClientRect(), u.attr("width", c.width), u.attr("height", c.height);
  }
  return c;
}
d(Fr, "addText");
async function Ig(e, t, r, i, n = r.class.padding ?? 12) {
  const a = i ? 0 : 3, o = e.insert("g").attr("class", tt(t)).attr("id", t.domId || t.id);
  let s = null, l = null, c = null, h = null, u = 0, f = 0, p = 0;
  if (s = o.insert("g").attr("class", "annotation-group text"), t.annotations.length > 0) {
    const b = t.annotations[0];
    await Bi(s, { text: `«${b}»` }, 0), u = s.node().getBBox().height;
  }
  l = o.insert("g").attr("class", "label-group text"), await Bi(l, t, 0, ["font-weight: bolder"]);
  const g = l.node().getBBox();
  f = g.height, c = o.insert("g").attr("class", "members-group text");
  let m = 0;
  for (const b of t.members) {
    const _ = await Bi(c, b, m, [b.parseClassifier()]);
    m += _ + a;
  }
  p = c.node().getBBox().height, p <= 0 && (p = n / 2), h = o.insert("g").attr("class", "methods-group text");
  let y = 0;
  for (const b of t.methods) {
    const _ = await Bi(h, b, y, [b.parseClassifier()]);
    y += _ + a;
  }
  let x = o.node().getBBox();
  if (s !== null) {
    const b = s.node().getBBox();
    s.attr("transform", `translate(${-b.width / 2})`);
  }
  return l.attr("transform", `translate(${-g.width / 2}, ${u})`), x = o.node().getBBox(), c.attr(
    "transform",
    `translate(0, ${u + f + n * 2})`
  ), x = o.node().getBBox(), h.attr(
    "transform",
    `translate(0, ${u + f + (p ? p + n * 4 : n * 2)})`
  ), x = o.node().getBBox(), { shapeSvg: o, bbox: x };
}
d(Ig, "textHelper");
async function Bi(e, t, r, i = []) {
  const n = e.insert("g").attr("class", "label").attr("style", i.join("; ")), a = Nt();
  let o = "useHtmlLabels" in t ? t.useHtmlLabels : Lt(a.htmlLabels) ?? !0, s = "";
  "text" in t ? s = t.text : s = t.label, !o && s.startsWith("\\") && (s = s.substring(1)), Xr(s) && (o = !0);
  const l = await Ze(
    n,
    Mo(wr(s)),
    {
      width: Pe(s, a) + 50,
      // Add room for error when splitting text into multiple lines
      classes: "markdown-node-label",
      useHtmlLabels: o
    },
    a
  );
  let c, h = 1;
  if (o) {
    const u = l.children[0], f = ht(l);
    h = u.innerHTML.split("<br>").length, u.innerHTML.includes("</math>") && (h += u.innerHTML.split("<mrow>").length - 1);
    const p = u.getElementsByTagName("img");
    if (p) {
      const g = s.replace(/<img[^>]*>/g, "").trim() === "";
      await Promise.all(
        [...p].map(
          (m) => new Promise((y) => {
            function x() {
              var b;
              if (m.style.display = "flex", m.style.flexDirection = "column", g) {
                const _ = ((b = a.fontSize) == null ? void 0 : b.toString()) ?? window.getComputedStyle(document.body).fontSize, w = parseInt(_, 10) * 5 + "px";
                m.style.minWidth = w, m.style.maxWidth = w;
              } else
                m.style.width = "100%";
              y(m);
            }
            d(x, "setupImage"), setTimeout(() => {
              m.complete && x();
            }), m.addEventListener("error", x), m.addEventListener("load", x);
          })
        )
      );
    }
    c = u.getBoundingClientRect(), f.attr("width", c.width), f.attr("height", c.height);
  } else {
    i.includes("font-weight: bolder") && ht(l).selectAll("tspan").attr("font-weight", ""), h = l.children.length;
    const u = l.children[0];
    (l.textContent === "" || l.textContent.includes("&gt")) && (u.textContent = s[0] + s.substring(1).replaceAll("&gt;", ">").replaceAll("&lt;", "<").trim(), s[1] === " " && (u.textContent = u.textContent[0] + " " + u.textContent.substring(1))), u.textContent === "undefined" && (u.textContent = ""), c = l.getBBox();
  }
  return n.attr("transform", "translate(0," + (-c.height / (2 * h) + r) + ")"), c.height;
}
d(Bi, "addText");
async function Pg(e, t) {
  var P, R;
  const r = pt(), i = r.class.padding ?? 12, n = i, a = t.useHtmlLabels ?? Lt(r.htmlLabels) ?? !0, o = t;
  o.annotations = o.annotations ?? [], o.members = o.members ?? [], o.methods = o.methods ?? [];
  const { shapeSvg: s, bbox: l } = await Ig(e, t, r, a, n), { labelStyles: c, nodeStyles: h } = G(t);
  t.labelStyle = c, t.cssStyles = o.styles || "";
  const u = ((P = o.styles) == null ? void 0 : P.join(";")) || h || "";
  t.cssStyles || (t.cssStyles = u.replaceAll("!important", "").split(";"));
  const f = o.members.length === 0 && o.methods.length === 0 && !((R = r.class) != null && R.hideEmptyMembersBox), p = Y.svg(s), g = U(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = l.width;
  let y = l.height;
  o.members.length === 0 && o.methods.length === 0 ? y += n : o.members.length > 0 && o.methods.length === 0 && (y += n * 2);
  const x = -m / 2, b = -y / 2, _ = p.rectangle(
    x - i,
    b - i - (f ? i : o.members.length === 0 && o.methods.length === 0 ? -i / 2 : 0),
    m + 2 * i,
    y + 2 * i + (f ? i * 2 : o.members.length === 0 && o.methods.length === 0 ? -i : 0),
    g
  ), v = s.insert(() => _, ":first-child");
  v.attr("class", "basic label-container");
  const w = v.node().getBBox();
  s.selectAll(".text").each(($, z, O) => {
    var W;
    const M = ht(O[z]), A = M.attr("transform");
    let B = 0;
    if (A) {
      const H = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(A);
      H && (B = parseFloat(H[2]));
    }
    let E = B + b + i - (f ? i : o.members.length === 0 && o.methods.length === 0 ? -i / 2 : 0);
    a || (E -= 4);
    let L = x;
    (M.attr("class").includes("label-group") || M.attr("class").includes("annotation-group")) && (L = -((W = M.node()) == null ? void 0 : W.getBBox().width) / 2 || 0, s.selectAll("text").each(function(X, H, ut) {
      window.getComputedStyle(ut[H]).textAnchor === "middle" && (L = 0);
    })), M.attr("transform", `translate(${L}, ${E})`);
  });
  const C = s.select(".annotation-group").node().getBBox().height - (f ? i / 2 : 0) || 0, S = s.select(".label-group").node().getBBox().height - (f ? i / 2 : 0) || 0, D = s.select(".members-group").node().getBBox().height - (f ? i / 2 : 0) || 0;
  if (o.members.length > 0 || o.methods.length > 0 || f) {
    const $ = p.line(
      w.x,
      C + S + b + i,
      w.x + w.width,
      C + S + b + i,
      g
    );
    s.insert(() => $).attr("class", "divider").attr("style", u);
  }
  if (f || o.members.length > 0 || o.methods.length > 0) {
    const $ = p.line(
      w.x,
      C + S + D + b + n * 2 + i,
      w.x + w.width,
      C + S + D + b + i + n * 2,
      g
    );
    s.insert(() => $).attr("class", "divider").attr("style", u);
  }
  if (o.look !== "handDrawn" && s.selectAll("path").attr("style", u), v.select(":nth-child(2)").attr("style", u), s.selectAll(".divider").select("path").attr("style", u), t.labelStyle ? s.selectAll("span").attr("style", t.labelStyle) : s.selectAll("span").attr("style", u), !a) {
    const $ = RegExp(/color\s*:\s*([^;]*)/), z = $.exec(u);
    if (z) {
      const O = z[0].replace("color", "fill");
      s.selectAll("tspan").attr("style", O);
    } else if (c) {
      const O = $.exec(c);
      if (O) {
        const M = O[0].replace("color", "fill");
        s.selectAll("tspan").attr("style", M);
      }
    }
  }
  return V(t, v), t.intersect = function($) {
    return q.rect(t, $);
  }, s;
}
d(Pg, "classBox");
async function Ng(e, t) {
  var C, S;
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const n = t, a = t, o = 20, s = 20, l = "verifyMethod" in t, c = tt(t), h = e.insert("g").attr("class", c).attr("id", t.domId ?? t.id);
  let u;
  l ? u = await Ce(
    h,
    `&lt;&lt;${n.type}&gt;&gt;`,
    0,
    t.labelStyle
  ) : u = await Ce(h, "&lt;&lt;Element&gt;&gt;", 0, t.labelStyle);
  let f = u;
  const p = await Ce(
    h,
    n.name,
    f,
    t.labelStyle + "; font-weight: bold;"
  );
  if (f += p + s, l) {
    const D = await Ce(
      h,
      `${n.requirementId ? `ID: ${n.requirementId}` : ""}`,
      f,
      t.labelStyle
    );
    f += D;
    const P = await Ce(
      h,
      `${n.text ? `Text: ${n.text}` : ""}`,
      f,
      t.labelStyle
    );
    f += P;
    const R = await Ce(
      h,
      `${n.risk ? `Risk: ${n.risk}` : ""}`,
      f,
      t.labelStyle
    );
    f += R, await Ce(
      h,
      `${n.verifyMethod ? `Verification: ${n.verifyMethod}` : ""}`,
      f,
      t.labelStyle
    );
  } else {
    const D = await Ce(
      h,
      `${a.type ? `Type: ${a.type}` : ""}`,
      f,
      t.labelStyle
    );
    f += D, await Ce(
      h,
      `${a.docRef ? `Doc Ref: ${a.docRef}` : ""}`,
      f,
      t.labelStyle
    );
  }
  const g = (((C = h.node()) == null ? void 0 : C.getBBox().width) ?? 200) + o, m = (((S = h.node()) == null ? void 0 : S.getBBox().height) ?? 200) + o, y = -g / 2, x = -m / 2, b = Y.svg(h), _ = U(t, {});
  t.look !== "handDrawn" && (_.roughness = 0, _.fillStyle = "solid");
  const v = b.rectangle(y, x, g, m, _), w = h.insert(() => v, ":first-child");
  if (w.attr("class", "basic label-container").attr("style", i), h.selectAll(".label").each((D, P, R) => {
    const $ = ht(R[P]), z = $.attr("transform");
    let O = 0, M = 0;
    if (z) {
      const L = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(z);
      L && (O = parseFloat(L[1]), M = parseFloat(L[2]));
    }
    const A = M - m / 2;
    let B = y + o / 2;
    (P === 0 || P === 1) && (B = O), $.attr("transform", `translate(${B}, ${A + o})`);
  }), f > u + p + s) {
    const D = b.line(
      y,
      x + u + p + s,
      y + g,
      x + u + p + s,
      _
    );
    h.insert(() => D).attr("style", i);
  }
  return V(t, w), t.intersect = function(D) {
    return q.rect(t, D);
  }, h;
}
d(Ng, "requirementBox");
async function Ce(e, t, r, i = "") {
  if (t === "")
    return 0;
  const n = e.insert("g").attr("class", "label").attr("style", i), a = pt(), o = a.htmlLabels ?? !0, s = await Ze(
    n,
    Mo(wr(t)),
    {
      width: Pe(t, a) + 50,
      // Add room for error when splitting text into multiple lines
      classes: "markdown-node-label",
      useHtmlLabels: o,
      style: i
    },
    a
  );
  let l;
  if (o) {
    const c = s.children[0], h = ht(s);
    l = c.getBoundingClientRect(), h.attr("width", l.width), h.attr("height", l.height);
  } else {
    const c = s.children[0];
    for (const h of c.children)
      h.textContent = h.textContent.replaceAll("&gt;", ">").replaceAll("&lt;", "<"), i && h.setAttribute("style", i);
    l = s.getBBox(), l.height += 6;
  }
  return n.attr("transform", `translate(${-l.width / 2},${-l.height / 2 + r})`), l.height;
}
d(Ce, "addText");
var iS = /* @__PURE__ */ d((e) => {
  switch (e) {
    case "Very High":
      return "red";
    case "High":
      return "orange";
    case "Medium":
      return null;
    case "Low":
      return "blue";
    case "Very Low":
      return "lightblue";
  }
}, "colorFromPriority");
async function zg(e, t, { config: r }) {
  var z, O;
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i || "";
  const a = 10, o = t.width;
  t.width = (t.width ?? 200) - 10;
  const {
    shapeSvg: s,
    bbox: l,
    label: c
  } = await et(e, t, tt(t)), h = t.padding || 10;
  let u = "", f;
  "ticket" in t && t.ticket && ((z = r == null ? void 0 : r.kanban) != null && z.ticketBaseUrl) && (u = (O = r == null ? void 0 : r.kanban) == null ? void 0 : O.ticketBaseUrl.replace("#TICKET#", t.ticket), f = s.insert("svg:a", ":first-child").attr("class", "kanban-ticket-link").attr("xlink:href", u).attr("target", "_blank"));
  const p = {
    useHtmlLabels: t.useHtmlLabels,
    labelStyle: t.labelStyle || "",
    width: t.width,
    img: t.img,
    padding: t.padding || 8,
    centerLabel: !1
  };
  let g, m;
  f ? { label: g, bbox: m } = await Cs(
    f,
    "ticket" in t && t.ticket || "",
    p
  ) : { label: g, bbox: m } = await Cs(
    s,
    "ticket" in t && t.ticket || "",
    p
  );
  const { label: y, bbox: x } = await Cs(
    s,
    "assigned" in t && t.assigned || "",
    p
  );
  t.width = o;
  const b = 10, _ = (t == null ? void 0 : t.width) || 0, v = Math.max(m.height, x.height) / 2, w = Math.max(l.height + b * 2, (t == null ? void 0 : t.height) || 0) + v, C = -_ / 2, S = -w / 2;
  c.attr(
    "transform",
    "translate(" + (h - _ / 2) + ", " + (-v - l.height / 2) + ")"
  ), g.attr(
    "transform",
    "translate(" + (h - _ / 2) + ", " + (-v + l.height / 2) + ")"
  ), y.attr(
    "transform",
    "translate(" + (h + _ / 2 - x.width - 2 * a) + ", " + (-v + l.height / 2) + ")"
  );
  let D;
  const { rx: P, ry: R } = t, { cssStyles: $ } = t;
  if (t.look === "handDrawn") {
    const M = Y.svg(s), A = U(t, {}), B = P || R ? M.path(Ke(C, S, _, w, P || 0), A) : M.rectangle(C, S, _, w, A);
    D = s.insert(() => B, ":first-child"), D.attr("class", "basic label-container").attr("style", $ || null);
  } else {
    D = s.insert("rect", ":first-child"), D.attr("class", "basic label-container __APA__").attr("style", n).attr("rx", P ?? 5).attr("ry", R ?? 5).attr("x", C).attr("y", S).attr("width", _).attr("height", w);
    const M = "priority" in t && t.priority;
    if (M) {
      const A = s.append("line"), B = C + 2, E = S + Math.floor((P ?? 0) / 2), L = S + w - Math.floor((P ?? 0) / 2);
      A.attr("x1", B).attr("y1", E).attr("x2", B).attr("y2", L).attr("stroke-width", "4").attr("stroke", iS(M));
    }
  }
  return V(t, D), t.height = w, t.intersect = function(M) {
    return q.rect(t, M);
  }, s;
}
d(zg, "kanbanItem");
async function Wg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: o, label: s } = await et(
    e,
    t,
    tt(t)
  ), l = a.width + 10 * o, c = a.height + 8 * o, h = 0.15 * l, { cssStyles: u } = t, f = a.width + 20, p = a.height + 20, g = Math.max(l, f), m = Math.max(c, p);
  s.attr("transform", `translate(${-a.width / 2}, ${-a.height / 2})`);
  let y;
  const x = `M0 0 
    a${h},${h} 1 0,0 ${g * 0.25},${-1 * m * 0.1}
    a${h},${h} 1 0,0 ${g * 0.25},0
    a${h},${h} 1 0,0 ${g * 0.25},0
    a${h},${h} 1 0,0 ${g * 0.25},${m * 0.1}

    a${h},${h} 1 0,0 ${g * 0.15},${m * 0.33}
    a${h * 0.8},${h * 0.8} 1 0,0 0,${m * 0.34}
    a${h},${h} 1 0,0 ${-1 * g * 0.15},${m * 0.33}

    a${h},${h} 1 0,0 ${-1 * g * 0.25},${m * 0.15}
    a${h},${h} 1 0,0 ${-1 * g * 0.25},0
    a${h},${h} 1 0,0 ${-1 * g * 0.25},0
    a${h},${h} 1 0,0 ${-1 * g * 0.25},${-1 * m * 0.15}

    a${h},${h} 1 0,0 ${-1 * g * 0.1},${-1 * m * 0.33}
    a${h * 0.8},${h * 0.8} 1 0,0 0,${-1 * m * 0.34}
    a${h},${h} 1 0,0 ${g * 0.1},${-1 * m * 0.33}
  H0 V0 Z`;
  if (t.look === "handDrawn") {
    const b = Y.svg(n), _ = U(t, {}), v = b.path(x, _);
    y = n.insert(() => v, ":first-child"), y.attr("class", "basic label-container").attr("style", Wt(u));
  } else
    y = n.insert("path", ":first-child").attr("class", "basic label-container").attr("style", i).attr("d", x);
  return y.attr("transform", `translate(${-g / 2}, ${-m / 2})`), V(t, y), t.calcIntersect = function(b, _) {
    return q.rect(b, _);
  }, t.intersect = function(b) {
    return F.info("Bang intersect", t, b), q.rect(t, b);
  }, n;
}
d(Wg, "bang");
async function qg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: o, label: s } = await et(
    e,
    t,
    tt(t)
  ), l = a.width + 2 * o, c = a.height + 2 * o, h = 0.15 * l, u = 0.25 * l, f = 0.35 * l, p = 0.2 * l, { cssStyles: g } = t;
  let m;
  const y = `M0 0 
    a${h},${h} 0 0,1 ${l * 0.25},${-1 * l * 0.1}
    a${f},${f} 1 0,1 ${l * 0.4},${-1 * l * 0.1}
    a${u},${u} 1 0,1 ${l * 0.35},${l * 0.2}

    a${h},${h} 1 0,1 ${l * 0.15},${c * 0.35}
    a${p},${p} 1 0,1 ${-1 * l * 0.15},${c * 0.65}

    a${u},${h} 1 0,1 ${-1 * l * 0.25},${l * 0.15}
    a${f},${f} 1 0,1 ${-1 * l * 0.5},0
    a${h},${h} 1 0,1 ${-1 * l * 0.25},${-1 * l * 0.15}

    a${h},${h} 1 0,1 ${-1 * l * 0.1},${-1 * c * 0.35}
    a${p},${p} 1 0,1 ${l * 0.1},${-1 * c * 0.65}
  H0 V0 Z`;
  if (t.look === "handDrawn") {
    const x = Y.svg(n), b = U(t, {}), _ = x.path(y, b);
    m = n.insert(() => _, ":first-child"), m.attr("class", "basic label-container").attr("style", Wt(g));
  } else
    m = n.insert("path", ":first-child").attr("class", "basic label-container").attr("style", i).attr("d", y);
  return s.attr("transform", `translate(${-a.width / 2}, ${-a.height / 2})`), m.attr("transform", `translate(${-l / 2}, ${-c / 2})`), V(t, m), t.calcIntersect = function(x, b) {
    return q.rect(x, b);
  }, t.intersect = function(x) {
    return F.info("Cloud intersect", t, x), q.rect(t, x);
  }, n;
}
d(qg, "cloud");
async function Hg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: o, label: s } = await et(
    e,
    t,
    tt(t)
  ), l = a.width + 8 * o, c = a.height + 2 * o, h = 5, u = `
    M${-l / 2} ${c / 2 - h}
    v${-c + 2 * h}
    q0,-${h} ${h},-${h}
    h${l - 2 * h}
    q${h},0 ${h},${h}
    v${c - 2 * h}
    q0,${h} -${h},${h}
    h${-l + 2 * h}
    q-${h},0 -${h},-${h}
    Z
  `, f = n.append("path").attr("id", "node-" + t.id).attr("class", "node-bkg node-" + t.type).attr("style", i).attr("d", u);
  return n.append("line").attr("class", "node-line-").attr("x1", -l / 2).attr("y1", c / 2).attr("x2", l / 2).attr("y2", c / 2), s.attr("transform", `translate(${-a.width / 2}, ${-a.height / 2})`), n.append(() => s.node()), V(t, f), t.calcIntersect = function(p, g) {
    return q.rect(p, g);
  }, t.intersect = function(p) {
    return q.rect(t, p);
  }, n;
}
d(Hg, "defaultMindmapNode");
async function jg(e, t) {
  const r = {
    padding: t.padding ?? 0
  };
  return Cl(e, t, r);
}
d(jg, "mindmapCircle");
var nS = [
  {
    semanticName: "Process",
    name: "Rectangle",
    shortName: "rect",
    description: "Standard process shape",
    aliases: ["proc", "process", "rectangle"],
    internalAliases: ["squareRect"],
    handler: _g
  },
  {
    semanticName: "Event",
    name: "Rounded Rectangle",
    shortName: "rounded",
    description: "Represents an event",
    aliases: ["event"],
    internalAliases: ["roundedRect"],
    handler: xg
  },
  {
    semanticName: "Terminal Point",
    name: "Stadium",
    shortName: "stadium",
    description: "Terminal point",
    aliases: ["terminal", "pill"],
    handler: wg
  },
  {
    semanticName: "Subprocess",
    name: "Framed Rectangle",
    shortName: "fr-rect",
    description: "Subprocess",
    aliases: ["subprocess", "subproc", "framed-rectangle", "subroutine"],
    handler: Tg
  },
  {
    semanticName: "Database",
    name: "Cylinder",
    shortName: "cyl",
    description: "Database storage",
    aliases: ["db", "database", "cylinder"],
    handler: Yd
  },
  {
    semanticName: "Start",
    name: "Circle",
    shortName: "circle",
    description: "Starting point",
    aliases: ["circ"],
    handler: Cl
  },
  {
    semanticName: "Bang",
    name: "Bang",
    shortName: "bang",
    description: "Bang",
    aliases: ["bang"],
    handler: Wg
  },
  {
    semanticName: "Cloud",
    name: "Cloud",
    shortName: "cloud",
    description: "cloud",
    aliases: ["cloud"],
    handler: qg
  },
  {
    semanticName: "Decision",
    name: "Diamond",
    shortName: "diam",
    description: "Decision-making step",
    aliases: ["decision", "diamond", "question"],
    handler: gg
  },
  {
    semanticName: "Prepare Conditional",
    name: "Hexagon",
    shortName: "hex",
    description: "Preparation or condition step",
    aliases: ["hexagon", "prepare"],
    handler: Qd
  },
  {
    semanticName: "Data Input/Output",
    name: "Lean Right",
    shortName: "lean-r",
    description: "Represents input or output",
    aliases: ["lean-right", "in-out"],
    internalAliases: ["lean_right"],
    handler: lg
  },
  {
    semanticName: "Data Input/Output",
    name: "Lean Left",
    shortName: "lean-l",
    description: "Represents output or input",
    aliases: ["lean-left", "out-in"],
    internalAliases: ["lean_left"],
    handler: og
  },
  {
    semanticName: "Priority Action",
    name: "Trapezoid Base Bottom",
    shortName: "trap-b",
    description: "Priority action",
    aliases: ["priority", "trapezoid-bottom", "trapezoid"],
    handler: $g
  },
  {
    semanticName: "Manual Operation",
    name: "Trapezoid Base Top",
    shortName: "trap-t",
    description: "Represents a manual task",
    aliases: ["manual", "trapezoid-top", "inv-trapezoid"],
    internalAliases: ["inv_trapezoid"],
    handler: ag
  },
  {
    semanticName: "Stop",
    name: "Double Circle",
    shortName: "dbl-circ",
    description: "Represents a stop point",
    aliases: ["double-circle"],
    internalAliases: ["doublecircle"],
    handler: Gd
  },
  {
    semanticName: "Text Block",
    name: "Text Block",
    shortName: "text",
    description: "Text block",
    handler: Lg
  },
  {
    semanticName: "Card",
    name: "Notched Rectangle",
    shortName: "notch-rect",
    description: "Represents a card",
    aliases: ["card", "notched-rectangle"],
    handler: Id
  },
  {
    semanticName: "Lined/Shaded Process",
    name: "Lined Rectangle",
    shortName: "lin-rect",
    description: "Lined process shape",
    aliases: ["lined-rectangle", "lined-process", "lin-proc", "shaded-process"],
    handler: bg
  },
  {
    semanticName: "Start",
    name: "Small Circle",
    shortName: "sm-circ",
    description: "Small starting point",
    aliases: ["start", "small-circle"],
    internalAliases: ["stateStart"],
    handler: Sg
  },
  {
    semanticName: "Stop",
    name: "Framed Circle",
    shortName: "fr-circ",
    description: "Stop point",
    aliases: ["stop", "framed-circle"],
    internalAliases: ["stateEnd"],
    handler: vg
  },
  {
    semanticName: "Fork/Join",
    name: "Filled Rectangle",
    shortName: "fork",
    description: "Fork or join in process flow",
    aliases: ["join"],
    internalAliases: ["forkJoin"],
    handler: Zd
  },
  {
    semanticName: "Collate",
    name: "Hourglass",
    shortName: "hourglass",
    description: "Represents a collate operation",
    aliases: ["hourglass", "collate"],
    handler: Jd
  },
  {
    semanticName: "Comment",
    name: "Curly Brace",
    shortName: "brace",
    description: "Adds a comment",
    aliases: ["comment", "brace-l"],
    handler: Wd
  },
  {
    semanticName: "Comment Right",
    name: "Curly Brace",
    shortName: "brace-r",
    description: "Adds a comment",
    handler: qd
  },
  {
    semanticName: "Comment with braces on both sides",
    name: "Curly Braces",
    shortName: "braces",
    description: "Adds a comment",
    handler: Hd
  },
  {
    semanticName: "Com Link",
    name: "Lightning Bolt",
    shortName: "bolt",
    description: "Communication link",
    aliases: ["com-link", "lightning-bolt"],
    handler: cg
  },
  {
    semanticName: "Document",
    name: "Document",
    shortName: "doc",
    description: "Represents a document",
    aliases: ["doc", "document"],
    handler: Dg
  },
  {
    semanticName: "Delay",
    name: "Half-Rounded Rectangle",
    shortName: "delay",
    description: "Represents a delay",
    aliases: ["half-rounded-rectangle"],
    handler: Kd
  },
  {
    semanticName: "Direct Access Storage",
    name: "Horizontal Cylinder",
    shortName: "h-cyl",
    description: "Direct access storage",
    aliases: ["das", "horizontal-cylinder"],
    handler: Mg
  },
  {
    semanticName: "Disk Storage",
    name: "Lined Cylinder",
    shortName: "lin-cyl",
    description: "Disk storage",
    aliases: ["disk", "lined-cylinder"],
    handler: hg
  },
  {
    semanticName: "Display",
    name: "Curved Trapezoid",
    shortName: "curv-trap",
    description: "Represents a display",
    aliases: ["curved-trapezoid", "display"],
    handler: jd
  },
  {
    semanticName: "Divided Process",
    name: "Divided Rectangle",
    shortName: "div-rect",
    description: "Divided process shape",
    aliases: ["div-proc", "divided-rectangle", "divided-process"],
    handler: Ud
  },
  {
    semanticName: "Extract",
    name: "Triangle",
    shortName: "tri",
    description: "Extraction process",
    aliases: ["extract", "triangle"],
    handler: Fg
  },
  {
    semanticName: "Internal Storage",
    name: "Window Pane",
    shortName: "win-pane",
    description: "Internal storage",
    aliases: ["internal-storage", "window-pane"],
    handler: Rg
  },
  {
    semanticName: "Junction",
    name: "Filled Circle",
    shortName: "f-circ",
    description: "Junction point",
    aliases: ["junction", "filled-circle"],
    handler: Xd
  },
  {
    semanticName: "Loop Limit",
    name: "Trapezoidal Pentagon",
    shortName: "notch-pent",
    description: "Loop limit step",
    aliases: ["loop-limit", "notched-pentagon"],
    handler: Eg
  },
  {
    semanticName: "Manual File",
    name: "Flipped Triangle",
    shortName: "flip-tri",
    description: "Manual file operation",
    aliases: ["manual-file", "flipped-triangle"],
    handler: Vd
  },
  {
    semanticName: "Manual Input",
    name: "Sloped Rectangle",
    shortName: "sl-rect",
    description: "Manual input step",
    aliases: ["manual-input", "sloped-rectangle"],
    handler: Cg
  },
  {
    semanticName: "Multi-Document",
    name: "Stacked Document",
    shortName: "docs",
    description: "Multiple documents",
    aliases: ["documents", "st-doc", "stacked-document"],
    handler: pg
  },
  {
    semanticName: "Multi-Process",
    name: "Stacked Rectangle",
    shortName: "st-rect",
    description: "Multiple processes",
    aliases: ["procs", "processes", "stacked-rectangle"],
    handler: fg
  },
  {
    semanticName: "Stored Data",
    name: "Bow Tie Rectangle",
    shortName: "bow-rect",
    description: "Stored data",
    aliases: ["stored-data", "bow-tie-rectangle"],
    handler: Rd
  },
  {
    semanticName: "Summary",
    name: "Crossed Circle",
    shortName: "cross-circ",
    description: "Summary",
    aliases: ["summary", "crossed-circle"],
    handler: zd
  },
  {
    semanticName: "Tagged Document",
    name: "Tagged Document",
    shortName: "tag-doc",
    description: "Tagged document",
    aliases: ["tag-doc", "tagged-document"],
    handler: Ag
  },
  {
    semanticName: "Tagged Process",
    name: "Tagged Rectangle",
    shortName: "tag-rect",
    description: "Tagged process",
    aliases: ["tagged-rectangle", "tag-proc", "tagged-process"],
    handler: Bg
  },
  {
    semanticName: "Paper Tape",
    name: "Flag",
    shortName: "flag",
    description: "Paper tape",
    aliases: ["paper-tape"],
    handler: Og
  },
  {
    semanticName: "Odd",
    name: "Odd",
    shortName: "odd",
    description: "Odd shape",
    internalAliases: ["rect_left_inv_arrow"],
    handler: mg
  },
  {
    semanticName: "Lined Document",
    name: "Lined Document",
    shortName: "lin-doc",
    description: "Lined document",
    aliases: ["lined-document"],
    handler: ug
  }
], aS = /* @__PURE__ */ d(() => {
  const t = [
    ...Object.entries({
      // States
      state: kg,
      choice: Pd,
      note: dg,
      // Rectangles
      rectWithTitle: yg,
      labelRect: sg,
      // Icons
      iconSquare: ig,
      iconCircle: eg,
      icon: tg,
      iconRounded: rg,
      imageSquare: ng,
      anchor: Od,
      // Kanban diagram
      kanbanItem: zg,
      //Mindmap diagram
      mindmapCircle: jg,
      defaultMindmapNode: Hg,
      // class diagram
      classBox: Pg,
      // er diagram
      erBox: _l,
      // Requirement diagram
      requirementBox: Ng
    }),
    ...nS.flatMap((r) => [
      r.shortName,
      ..."aliases" in r ? r.aliases : [],
      ..."internalAliases" in r ? r.internalAliases : []
    ].map((n) => [n, r.handler]))
  ];
  return Object.fromEntries(t);
}, "generateShapeMap"), Yg = aS();
function sS(e) {
  return e in Yg;
}
d(sS, "isValidShape");
var Ha = /* @__PURE__ */ new Map();
async function Ug(e, t, r) {
  let i, n;
  t.shape === "rect" && (t.rx && t.ry ? t.shape = "roundedRect" : t.shape = "squareRect");
  const a = t.shape ? Yg[t.shape] : void 0;
  if (!a)
    throw new Error(`No such shape: ${t.shape}. Please check your syntax.`);
  if (t.link) {
    let o;
    r.config.securityLevel === "sandbox" ? o = "_top" : t.linkTarget && (o = t.linkTarget || "_blank"), i = e.insert("svg:a").attr("xlink:href", t.link).attr("target", o ?? null), n = await a(i, t, r);
  } else
    n = await a(e, t, r), i = n;
  return t.tooltip && n.attr("title", t.tooltip), Ha.set(t.id, i), t.haveCallback && i.attr("class", i.attr("class") + " clickable"), i;
}
d(Ug, "insertNode");
var xL = /* @__PURE__ */ d((e, t) => {
  Ha.set(t.id, e);
}, "setNodeElem"), bL = /* @__PURE__ */ d(() => {
  Ha.clear();
}, "clear"), CL = /* @__PURE__ */ d((e) => {
  const t = Ha.get(e.id);
  F.trace(
    "Transforming node",
    e.diff,
    e,
    "translate(" + (e.x - e.width / 2 - 5) + ", " + e.width / 2 + ")"
  );
  const r = 8, i = e.diff || 0;
  return e.clusterNode ? t.attr(
    "transform",
    "translate(" + (e.x + i - e.width / 2) + ", " + (e.y - e.height / 2 - r) + ")"
  ) : t.attr("transform", "translate(" + e.x + ", " + e.y + ")"), i;
}, "positionNode"), oS = /* @__PURE__ */ d((e, t, r, i, n, a) => {
  t.arrowTypeStart && lh(e, "start", t.arrowTypeStart, r, i, n, a), t.arrowTypeEnd && lh(e, "end", t.arrowTypeEnd, r, i, n, a);
}, "addEdgeMarkers"), lS = {
  arrow_cross: { type: "cross", fill: !1 },
  arrow_point: { type: "point", fill: !0 },
  arrow_barb: { type: "barb", fill: !0 },
  arrow_circle: { type: "circle", fill: !1 },
  aggregation: { type: "aggregation", fill: !1 },
  extension: { type: "extension", fill: !1 },
  composition: { type: "composition", fill: !0 },
  dependency: { type: "dependency", fill: !0 },
  lollipop: { type: "lollipop", fill: !1 },
  only_one: { type: "onlyOne", fill: !1 },
  zero_or_one: { type: "zeroOrOne", fill: !1 },
  one_or_more: { type: "oneOrMore", fill: !1 },
  zero_or_more: { type: "zeroOrMore", fill: !1 },
  requirement_arrow: { type: "requirement_arrow", fill: !1 },
  requirement_contains: { type: "requirement_contains", fill: !1 }
}, lh = /* @__PURE__ */ d((e, t, r, i, n, a, o) => {
  var u;
  const s = lS[r];
  if (!s) {
    F.warn(`Unknown arrow type: ${r}`);
    return;
  }
  const l = s.type, h = `${n}_${a}-${l}${t === "start" ? "Start" : "End"}`;
  if (o && o.trim() !== "") {
    const f = o.replace(/[^\dA-Za-z]/g, "_"), p = `${h}_${f}`;
    if (!document.getElementById(p)) {
      const g = document.getElementById(h);
      if (g) {
        const m = g.cloneNode(!0);
        m.id = p, m.querySelectorAll("path, circle, line").forEach((x) => {
          x.setAttribute("stroke", o), s.fill && x.setAttribute("fill", o);
        }), (u = g.parentNode) == null || u.appendChild(m);
      }
    }
    e.attr(`marker-${t}`, `url(${i}#${p})`);
  } else
    e.attr(`marker-${t}`, `url(${i}#${h})`);
}, "addEdgeMarker"), xa = /* @__PURE__ */ new Map(), Dt = /* @__PURE__ */ new Map(), _L = /* @__PURE__ */ d(() => {
  xa.clear(), Dt.clear();
}, "clear"), _n = /* @__PURE__ */ d((e) => e ? e.reduce((r, i) => r + ";" + i, "") : "", "getLabelStyles"), cS = /* @__PURE__ */ d(async (e, t) => {
  let r = Lt(pt().flowchart.htmlLabels);
  const { labelStyles: i } = G(t);
  t.labelStyle = i;
  const n = await Ze(e, t.label, {
    style: t.labelStyle,
    useHtmlLabels: r,
    addSvgBackground: !0,
    isNode: !1
  });
  F.info("abc82", t, t.labelType);
  const a = e.insert("g").attr("class", "edgeLabel"), o = a.insert("g").attr("class", "label").attr("data-id", t.id);
  o.node().appendChild(n);
  let s = n.getBBox();
  if (r) {
    const c = n.children[0], h = ht(n);
    s = c.getBoundingClientRect(), h.attr("width", s.width), h.attr("height", s.height);
  }
  o.attr("transform", "translate(" + -s.width / 2 + ", " + -s.height / 2 + ")"), xa.set(t.id, a), t.width = s.width, t.height = s.height;
  let l;
  if (t.startLabelLeft) {
    const c = await cr(
      t.startLabelLeft,
      _n(t.labelStyle)
    ), h = e.insert("g").attr("class", "edgeTerminals"), u = h.insert("g").attr("class", "inner");
    l = u.node().appendChild(c);
    const f = c.getBBox();
    u.attr("transform", "translate(" + -f.width / 2 + ", " + -f.height / 2 + ")"), Dt.get(t.id) || Dt.set(t.id, {}), Dt.get(t.id).startLeft = h, Ai(l, t.startLabelLeft);
  }
  if (t.startLabelRight) {
    const c = await cr(
      t.startLabelRight,
      _n(t.labelStyle)
    ), h = e.insert("g").attr("class", "edgeTerminals"), u = h.insert("g").attr("class", "inner");
    l = h.node().appendChild(c), u.node().appendChild(c);
    const f = c.getBBox();
    u.attr("transform", "translate(" + -f.width / 2 + ", " + -f.height / 2 + ")"), Dt.get(t.id) || Dt.set(t.id, {}), Dt.get(t.id).startRight = h, Ai(l, t.startLabelRight);
  }
  if (t.endLabelLeft) {
    const c = await cr(t.endLabelLeft, _n(t.labelStyle)), h = e.insert("g").attr("class", "edgeTerminals"), u = h.insert("g").attr("class", "inner");
    l = u.node().appendChild(c);
    const f = c.getBBox();
    u.attr("transform", "translate(" + -f.width / 2 + ", " + -f.height / 2 + ")"), h.node().appendChild(c), Dt.get(t.id) || Dt.set(t.id, {}), Dt.get(t.id).endLeft = h, Ai(l, t.endLabelLeft);
  }
  if (t.endLabelRight) {
    const c = await cr(t.endLabelRight, _n(t.labelStyle)), h = e.insert("g").attr("class", "edgeTerminals"), u = h.insert("g").attr("class", "inner");
    l = u.node().appendChild(c);
    const f = c.getBBox();
    u.attr("transform", "translate(" + -f.width / 2 + ", " + -f.height / 2 + ")"), h.node().appendChild(c), Dt.get(t.id) || Dt.set(t.id, {}), Dt.get(t.id).endRight = h, Ai(l, t.endLabelRight);
  }
  return n;
}, "insertEdgeLabel");
function Ai(e, t) {
  pt().flowchart.htmlLabels && e && (e.style.width = t.length * 9 + "px", e.style.height = "12px");
}
d(Ai, "setTerminalWidth");
var hS = /* @__PURE__ */ d((e, t) => {
  F.debug("Moving label abc88 ", e.id, e.label, xa.get(e.id), t);
  let r = t.updatedPath ? t.updatedPath : t.originalPath;
  const i = pt(), { subGraphTitleTotalMargin: n } = Zo(i);
  if (e.label) {
    const a = xa.get(e.id);
    let o = e.x, s = e.y;
    if (r) {
      const l = pe.calcLabelPosition(r);
      F.debug(
        "Moving label " + e.label + " from (",
        o,
        ",",
        s,
        ") to (",
        l.x,
        ",",
        l.y,
        ") abc88"
      ), t.updatedPath && (o = l.x, s = l.y);
    }
    a.attr("transform", `translate(${o}, ${s + n / 2})`);
  }
  if (e.startLabelLeft) {
    const a = Dt.get(e.id).startLeft;
    let o = e.x, s = e.y;
    if (r) {
      const l = pe.calcTerminalLabelPosition(e.arrowTypeStart ? 10 : 0, "start_left", r);
      o = l.x, s = l.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
  if (e.startLabelRight) {
    const a = Dt.get(e.id).startRight;
    let o = e.x, s = e.y;
    if (r) {
      const l = pe.calcTerminalLabelPosition(
        e.arrowTypeStart ? 10 : 0,
        "start_right",
        r
      );
      o = l.x, s = l.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
  if (e.endLabelLeft) {
    const a = Dt.get(e.id).endLeft;
    let o = e.x, s = e.y;
    if (r) {
      const l = pe.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_left", r);
      o = l.x, s = l.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
  if (e.endLabelRight) {
    const a = Dt.get(e.id).endRight;
    let o = e.x, s = e.y;
    if (r) {
      const l = pe.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_right", r);
      o = l.x, s = l.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
}, "positionEdgeLabel"), uS = /* @__PURE__ */ d((e, t) => {
  const r = e.x, i = e.y, n = Math.abs(t.x - r), a = Math.abs(t.y - i), o = e.width / 2, s = e.height / 2;
  return n >= o || a >= s;
}, "outsideNode"), fS = /* @__PURE__ */ d((e, t, r) => {
  F.debug(`intersection calc abc89:
  outsidePoint: ${JSON.stringify(t)}
  insidePoint : ${JSON.stringify(r)}
  node        : x:${e.x} y:${e.y} w:${e.width} h:${e.height}`);
  const i = e.x, n = e.y, a = Math.abs(i - r.x), o = e.width / 2;
  let s = r.x < t.x ? o - a : o + a;
  const l = e.height / 2, c = Math.abs(t.y - r.y), h = Math.abs(t.x - r.x);
  if (Math.abs(n - t.y) * o > Math.abs(i - t.x) * l) {
    let u = r.y < t.y ? t.y - l - n : n - l - t.y;
    s = h * u / c;
    const f = {
      x: r.x < t.x ? r.x + s : r.x - h + s,
      y: r.y < t.y ? r.y + c - u : r.y - c + u
    };
    return s === 0 && (f.x = t.x, f.y = t.y), h === 0 && (f.x = t.x), c === 0 && (f.y = t.y), F.debug(`abc89 top/bottom calc, Q ${c}, q ${u}, R ${h}, r ${s}`, f), f;
  } else {
    r.x < t.x ? s = t.x - o - i : s = i - o - t.x;
    let u = c * s / h, f = r.x < t.x ? r.x + h - s : r.x - h + s, p = r.y < t.y ? r.y + u : r.y - u;
    return F.debug(`sides calc abc89, Q ${c}, q ${u}, R ${h}, r ${s}`, { _x: f, _y: p }), s === 0 && (f = t.x, p = t.y), h === 0 && (f = t.x), c === 0 && (p = t.y), { x: f, y: p };
  }
}, "intersection"), ch = /* @__PURE__ */ d((e, t) => {
  F.warn("abc88 cutPathAtIntersect", e, t);
  let r = [], i = e[0], n = !1;
  return e.forEach((a) => {
    if (F.info("abc88 checking point", a, t), !uS(t, a) && !n) {
      const o = fS(t, i, a);
      F.debug("abc88 inside", a, i, o), F.debug("abc88 intersection", o, t);
      let s = !1;
      r.forEach((l) => {
        s = s || l.x === o.x && l.y === o.y;
      }), r.some((l) => l.x === o.x && l.y === o.y) ? F.warn("abc88 no intersect", o, r) : r.push(o), n = !0;
    } else
      F.warn("abc88 outside", a, i), i = a, n || r.push(a);
  }), F.debug("returning points", r), r;
}, "cutPathAtIntersect");
function Gg(e) {
  const t = [], r = [];
  for (let i = 1; i < e.length - 1; i++) {
    const n = e[i - 1], a = e[i], o = e[i + 1];
    (n.x === a.x && a.y === o.y && Math.abs(a.x - o.x) > 5 && Math.abs(a.y - n.y) > 5 || n.y === a.y && a.x === o.x && Math.abs(a.x - n.x) > 5 && Math.abs(a.y - o.y) > 5) && (t.push(a), r.push(i));
  }
  return { cornerPoints: t, cornerPointPositions: r };
}
d(Gg, "extractCornerPoints");
var hh = /* @__PURE__ */ d(function(e, t, r) {
  const i = t.x - e.x, n = t.y - e.y, a = Math.sqrt(i * i + n * n), o = r / a;
  return { x: t.x - o * i, y: t.y - o * n };
}, "findAdjacentPoint"), pS = /* @__PURE__ */ d(function(e) {
  const { cornerPointPositions: t } = Gg(e), r = [];
  for (let i = 0; i < e.length; i++)
    if (t.includes(i)) {
      const n = e[i - 1], a = e[i + 1], o = e[i], s = hh(n, o, 5), l = hh(a, o, 5), c = l.x - s.x, h = l.y - s.y;
      r.push(s);
      const u = Math.sqrt(2) * 2;
      let f = { x: o.x, y: o.y };
      if (Math.abs(a.x - n.x) > 10 && Math.abs(a.y - n.y) >= 10) {
        F.debug(
          "Corner point fixing",
          Math.abs(a.x - n.x),
          Math.abs(a.y - n.y)
        );
        const p = 5;
        o.x === s.x ? f = {
          x: c < 0 ? s.x - p + u : s.x + p - u,
          y: h < 0 ? s.y - u : s.y + u
        } : f = {
          x: c < 0 ? s.x - u : s.x + u,
          y: h < 0 ? s.y - p + u : s.y + p - u
        };
      } else
        F.debug(
          "Corner point skipping fixing",
          Math.abs(a.x - n.x),
          Math.abs(a.y - n.y)
        );
      r.push(f, l);
    } else
      r.push(e[i]);
  return r;
}, "fixCorners"), dS = /* @__PURE__ */ d((e, t, r) => {
  const i = e - t - r, n = 2, a = 2, o = n + a, s = Math.floor(i / o), l = Array(s).fill(`${n} ${a}`).join(" ");
  return `0 ${t} ${l} ${r}`;
}, "generateDashArray"), gS = /* @__PURE__ */ d(function(e, t, r, i, n, a, o, s = !1) {
  var M;
  const { handDrawnSeed: l } = pt();
  let c = t.points, h = !1;
  const u = n;
  var f = a;
  const p = [];
  for (const A in t.cssCompiledStyles)
    kp(A) || p.push(t.cssCompiledStyles[A]);
  F.debug("UIO intersect check", t.points, f.x, u.x), f.intersect && u.intersect && !s && (c = c.slice(1, t.points.length - 1), c.unshift(u.intersect(c[0])), F.debug(
    "Last point UIO",
    t.start,
    "-->",
    t.end,
    c[c.length - 1],
    f,
    f.intersect(c[c.length - 1])
  ), c.push(f.intersect(c[c.length - 1])));
  const g = btoa(JSON.stringify(c));
  t.toCluster && (F.info("to cluster abc88", r.get(t.toCluster)), c = ch(t.points, r.get(t.toCluster).node), h = !0), t.fromCluster && (F.debug(
    "from cluster abc88",
    r.get(t.fromCluster),
    JSON.stringify(c, null, 2)
  ), c = ch(c.reverse(), r.get(t.fromCluster).node).reverse(), h = !0);
  let m = c.filter((A) => !Number.isNaN(A.y));
  m = pS(m);
  let y = Mn;
  switch (y = Vn, t.curve) {
    case "linear":
      y = Vn;
      break;
    case "basis":
      y = Mn;
      break;
    case "cardinal":
      y = Tu;
      break;
    case "bumpX":
      y = _u;
      break;
    case "bumpY":
      y = wu;
      break;
    case "catmullRom":
      y = Au;
      break;
    case "monotoneX":
      y = Du;
      break;
    case "monotoneY":
      y = Ou;
      break;
    case "natural":
      y = Iu;
      break;
    case "step":
      y = Pu;
      break;
    case "stepAfter":
      y = zu;
      break;
    case "stepBefore":
      y = Nu;
      break;
    default:
      y = Mn;
  }
  const { x, y: b } = fC(t), _ = V1().x(x).y(b).curve(y);
  let v;
  switch (t.thickness) {
    case "normal":
      v = "edge-thickness-normal";
      break;
    case "thick":
      v = "edge-thickness-thick";
      break;
    case "invisible":
      v = "edge-thickness-invisible";
      break;
    default:
      v = "edge-thickness-normal";
  }
  switch (t.pattern) {
    case "solid":
      v += " edge-pattern-solid";
      break;
    case "dotted":
      v += " edge-pattern-dotted";
      break;
    case "dashed":
      v += " edge-pattern-dashed";
      break;
    default:
      v += " edge-pattern-solid";
  }
  let w, C = t.curve === "rounded" ? Xg(Vg(m, t), 5) : _(m);
  const S = Array.isArray(t.style) ? t.style : [t.style];
  let D = S.find((A) => A == null ? void 0 : A.startsWith("stroke:")), P = !1;
  if (t.look === "handDrawn") {
    const A = Y.svg(e);
    Object.assign([], m);
    const B = A.path(C, {
      roughness: 0.3,
      seed: l
    });
    v += " transition", w = ht(B).select("path").attr("id", t.id).attr("class", " " + v + (t.classes ? " " + t.classes : "")).attr("style", S ? S.reduce((L, W) => L + ";" + W, "") : "");
    let E = w.attr("d");
    w.attr("d", E), e.node().appendChild(w.node());
  } else {
    const A = p.join(";"), B = S ? S.reduce((nt, gt) => nt + gt + ";", "") : "";
    let E = "";
    t.animate && (E = " edge-animation-fast"), t.animation && (E = " edge-animation-" + t.animation);
    const L = (A ? A + ";" + B + ";" : B) + ";" + (S ? S.reduce((nt, gt) => nt + ";" + gt, "") : "");
    w = e.append("path").attr("d", C).attr("id", t.id).attr(
      "class",
      " " + v + (t.classes ? " " + t.classes : "") + (E ?? "")
    ).attr("style", L), D = (M = L.match(/stroke:([^;]+)/)) == null ? void 0 : M[1], P = t.animate === !0 || !!t.animation || A.includes("animation");
    const W = w.node(), X = typeof W.getTotalLength == "function" ? W.getTotalLength() : 0, H = Ac[t.arrowTypeStart] || 0, ut = Ac[t.arrowTypeEnd] || 0;
    if (t.look === "neo" && !P) {
      const gt = `stroke-dasharray: ${t.pattern === "dotted" || t.pattern === "dashed" ? dS(X, H, ut) : `0 ${H} ${X - H - ut} ${ut}`}; stroke-dashoffset: 0;`;
      w.attr("style", gt + w.attr("style"));
    }
  }
  w.attr("data-edge", !0), w.attr("data-et", "edge"), w.attr("data-id", t.id), w.attr("data-points", g), t.showPoints && m.forEach((A) => {
    e.append("circle").style("stroke", "red").style("fill", "red").attr("r", 1).attr("cx", A.x).attr("cy", A.y);
  });
  let R = "";
  (pt().flowchart.arrowMarkerAbsolute || pt().state.arrowMarkerAbsolute) && (R = window.location.protocol + "//" + window.location.host + window.location.pathname + window.location.search, R = R.replace(/\(/g, "\\(").replace(/\)/g, "\\)")), F.info("arrowTypeStart", t.arrowTypeStart), F.info("arrowTypeEnd", t.arrowTypeEnd), oS(w, t, R, o, i, D);
  const $ = Math.floor(c.length / 2), z = c[$];
  pe.isLabelCoordinateInPath(z, w.attr("d")) || (h = !0);
  let O = {};
  return h && (O.updatedPath = c), O.originalPath = t.points, O;
}, "insertEdge");
function Xg(e, t) {
  if (e.length < 2)
    return "";
  let r = "";
  const i = e.length, n = 1e-5;
  for (let a = 0; a < i; a++) {
    const o = e[a], s = e[a - 1], l = e[a + 1];
    if (a === 0)
      r += `M${o.x},${o.y}`;
    else if (a === i - 1)
      r += `L${o.x},${o.y}`;
    else {
      const c = o.x - s.x, h = o.y - s.y, u = l.x - o.x, f = l.y - o.y, p = Math.hypot(c, h), g = Math.hypot(u, f);
      if (p < n || g < n) {
        r += `L${o.x},${o.y}`;
        continue;
      }
      const m = c / p, y = h / p, x = u / g, b = f / g, _ = m * x + y * b, v = Math.max(-1, Math.min(1, _)), w = Math.acos(v);
      if (w < n || Math.abs(Math.PI - w) < n) {
        r += `L${o.x},${o.y}`;
        continue;
      }
      const C = Math.min(t / Math.sin(w / 2), p / 2, g / 2), S = o.x - m * C, D = o.y - y * C, P = o.x + x * C, R = o.y + b * C;
      r += `L${S},${D}`, r += `Q${o.x},${o.y} ${P},${R}`;
    }
  }
  return r;
}
d(Xg, "generateRoundedPath");
function po(e, t) {
  if (!e || !t)
    return { angle: 0, deltaX: 0, deltaY: 0 };
  const r = t.x - e.x, i = t.y - e.y;
  return { angle: Math.atan2(i, r), deltaX: r, deltaY: i };
}
d(po, "calculateDeltaAndAngle");
function Vg(e, t) {
  const r = e.map((n) => ({ ...n }));
  if (e.length >= 2 && Pt[t.arrowTypeStart]) {
    const n = Pt[t.arrowTypeStart], a = e[0], o = e[1], { angle: s } = po(a, o), l = n * Math.cos(s), c = n * Math.sin(s);
    r[0].x = a.x + l, r[0].y = a.y + c;
  }
  const i = e.length;
  if (i >= 2 && Pt[t.arrowTypeEnd]) {
    const n = Pt[t.arrowTypeEnd], a = e[i - 1], o = e[i - 2], { angle: s } = po(o, a), l = n * Math.cos(s), c = n * Math.sin(s);
    r[i - 1].x = a.x - l, r[i - 1].y = a.y - c;
  }
  return r;
}
d(Vg, "applyMarkerOffsetsToPoints");
var mS = /* @__PURE__ */ d((e, t, r, i) => {
  t.forEach((n) => {
    ES[n](e, r, i);
  });
}, "insertMarkers"), yS = /* @__PURE__ */ d((e, t, r) => {
  F.trace("Making markers for ", r), e.append("defs").append("marker").attr("id", r + "_" + t + "-extensionStart").attr("class", "marker extension " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 1,7 L18,13 V 1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-extensionEnd").attr("class", "marker extension " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 1,1 V 13 L18,7 Z");
}, "extension"), xS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-compositionStart").attr("class", "marker composition " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-compositionEnd").attr("class", "marker composition " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
}, "composition"), bS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-aggregationStart").attr("class", "marker aggregation " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-aggregationEnd").attr("class", "marker aggregation " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
}, "aggregation"), CS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-dependencyStart").attr("class", "marker dependency " + t).attr("refX", 6).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 5,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-dependencyEnd").attr("class", "marker dependency " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L14,7 L9,1 Z");
}, "dependency"), _S = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-lollipopStart").attr("class", "marker lollipop " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("stroke", "black").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6), e.append("defs").append("marker").attr("id", r + "_" + t + "-lollipopEnd").attr("class", "marker lollipop " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("stroke", "black").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6);
}, "lollipop"), wS = /* @__PURE__ */ d((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-pointEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 5).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 8).attr("markerHeight", 8).attr("orient", "auto").append("path").attr("d", "M 0 0 L 10 5 L 0 10 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-pointStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 4.5).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 8).attr("markerHeight", 8).attr("orient", "auto").append("path").attr("d", "M 0 5 L 10 10 L 10 0 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
}, "point"), kS = /* @__PURE__ */ d((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-circleEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 11).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-circleStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", -1).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
}, "circle"), vS = /* @__PURE__ */ d((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-crossEnd").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", 12).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-crossStart").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", -1).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0");
}, "cross"), SS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-barbEnd").attr("refX", 19).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 14).attr("markerUnits", "userSpaceOnUse").attr("orient", "auto").append("path").attr("d", "M 19,7 L9,13 L14,7 L9,1 Z");
}, "barb"), TS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-onlyOneStart").attr("class", "marker onlyOne " + t).attr("refX", 0).attr("refY", 9).attr("markerWidth", 18).attr("markerHeight", 18).attr("orient", "auto").append("path").attr("d", "M9,0 L9,18 M15,0 L15,18"), e.append("defs").append("marker").attr("id", r + "_" + t + "-onlyOneEnd").attr("class", "marker onlyOne " + t).attr("refX", 18).attr("refY", 9).attr("markerWidth", 18).attr("markerHeight", 18).attr("orient", "auto").append("path").attr("d", "M3,0 L3,18 M9,0 L9,18");
}, "only_one"), BS = /* @__PURE__ */ d((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrOneStart").attr("class", "marker zeroOrOne " + t).attr("refX", 0).attr("refY", 9).attr("markerWidth", 30).attr("markerHeight", 18).attr("orient", "auto");
  i.append("circle").attr("fill", "white").attr("cx", 21).attr("cy", 9).attr("r", 6), i.append("path").attr("d", "M9,0 L9,18");
  const n = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrOneEnd").attr("class", "marker zeroOrOne " + t).attr("refX", 30).attr("refY", 9).attr("markerWidth", 30).attr("markerHeight", 18).attr("orient", "auto");
  n.append("circle").attr("fill", "white").attr("cx", 9).attr("cy", 9).attr("r", 6), n.append("path").attr("d", "M21,0 L21,18");
}, "zero_or_one"), AS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-oneOrMoreStart").attr("class", "marker oneOrMore " + t).attr("refX", 18).attr("refY", 18).attr("markerWidth", 45).attr("markerHeight", 36).attr("orient", "auto").append("path").attr("d", "M0,18 Q 18,0 36,18 Q 18,36 0,18 M42,9 L42,27"), e.append("defs").append("marker").attr("id", r + "_" + t + "-oneOrMoreEnd").attr("class", "marker oneOrMore " + t).attr("refX", 27).attr("refY", 18).attr("markerWidth", 45).attr("markerHeight", 36).attr("orient", "auto").append("path").attr("d", "M3,9 L3,27 M9,18 Q27,0 45,18 Q27,36 9,18");
}, "one_or_more"), LS = /* @__PURE__ */ d((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrMoreStart").attr("class", "marker zeroOrMore " + t).attr("refX", 18).attr("refY", 18).attr("markerWidth", 57).attr("markerHeight", 36).attr("orient", "auto");
  i.append("circle").attr("fill", "white").attr("cx", 48).attr("cy", 18).attr("r", 6), i.append("path").attr("d", "M0,18 Q18,0 36,18 Q18,36 0,18");
  const n = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrMoreEnd").attr("class", "marker zeroOrMore " + t).attr("refX", 39).attr("refY", 18).attr("markerWidth", 57).attr("markerHeight", 36).attr("orient", "auto");
  n.append("circle").attr("fill", "white").attr("cx", 9).attr("cy", 18).attr("r", 6), n.append("path").attr("d", "M21,18 Q39,0 57,18 Q39,36 21,18");
}, "zero_or_more"), MS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-requirement_arrowEnd").attr("refX", 20).attr("refY", 10).attr("markerWidth", 20).attr("markerHeight", 20).attr("orient", "auto").append("path").attr(
    "d",
    `M0,0
      L20,10
      M20,10
      L0,20`
  );
}, "requirement_arrow"), $S = /* @__PURE__ */ d((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-requirement_containsStart").attr("refX", 0).attr("refY", 10).attr("markerWidth", 20).attr("markerHeight", 20).attr("orient", "auto").append("g");
  i.append("circle").attr("cx", 10).attr("cy", 10).attr("r", 9).attr("fill", "none"), i.append("line").attr("x1", 1).attr("x2", 19).attr("y1", 10).attr("y2", 10), i.append("line").attr("y1", 1).attr("y2", 19).attr("x1", 10).attr("x2", 10);
}, "requirement_contains"), ES = {
  extension: yS,
  composition: xS,
  aggregation: bS,
  dependency: CS,
  lollipop: _S,
  point: wS,
  circle: kS,
  cross: vS,
  barb: SS,
  only_one: TS,
  zero_or_one: BS,
  one_or_more: AS,
  zero_or_more: LS,
  requirement_arrow: MS,
  requirement_contains: $S
}, FS = mS, DS = {
  common: ei,
  getConfig: Nt,
  insertCluster: qv,
  insertEdge: gS,
  insertEdgeLabel: cS,
  insertMarkers: FS,
  insertNode: Ug,
  interpolateToCurve: rl,
  labelHelper: et,
  log: F,
  positionEdgeLabel: hS
}, Ui = {}, Zg = /* @__PURE__ */ d((e) => {
  for (const t of e)
    Ui[t.name] = t;
}, "registerLayoutLoaders"), OS = /* @__PURE__ */ d(() => {
  Zg([
    {
      name: "dagre",
      loader: /* @__PURE__ */ d(async () => await import("./dagre-6UL2VRFP-bvvP-LX2.js"), "loader")
    },
    {
      name: "cose-bilkent",
      loader: /* @__PURE__ */ d(async () => await import("./cose-bilkent-S5V4N54A-CCvjAqDa.js"), "loader")
    }
  ]);
}, "registerDefaultLayoutLoaders");
OS();
var wL = /* @__PURE__ */ d(async (e, t) => {
  if (!(e.layoutAlgorithm in Ui))
    throw new Error(`Unknown layout algorithm: ${e.layoutAlgorithm}`);
  const r = Ui[e.layoutAlgorithm];
  return (await r.loader()).render(e, t, DS, {
    algorithm: r.algorithm
  });
}, "render"), kL = /* @__PURE__ */ d((e = "", { fallback: t = "dagre" } = {}) => {
  if (e in Ui)
    return e;
  if (t in Ui)
    return F.warn(`Layout algorithm ${e} is not registered. Using ${t} as fallback.`), t;
  throw new Error(`Both layout algorithms ${e} and ${t} are not registered.`);
}, "getRegisteredLayoutAlgorithm"), Kg = "comm", Qg = "rule", Jg = "decl", RS = "@import", IS = "@namespace", PS = "@keyframes", NS = "@layer", tm = Math.abs, wl = String.fromCharCode;
function em(e) {
  return e.trim();
}
function On(e, t, r) {
  return e.replace(t, r);
}
function zS(e, t, r) {
  return e.indexOf(t, r);
}
function Ir(e, t) {
  return e.charCodeAt(t) | 0;
}
function Jr(e, t, r) {
  return e.slice(t, r);
}
function _e(e) {
  return e.length;
}
function WS(e) {
  return e.length;
}
function wn(e, t) {
  return t.push(e), e;
}
var ja = 1, ti = 1, rm = 0, oe = 0, Tt = 0, si = "";
function kl(e, t, r, i, n, a, o, s) {
  return { value: e, root: t, parent: r, type: i, props: n, children: a, line: ja, column: ti, length: o, return: "", siblings: s };
}
function qS() {
  return Tt;
}
function HS() {
  return Tt = oe > 0 ? Ir(si, --oe) : 0, ti--, Tt === 10 && (ti = 1, ja--), Tt;
}
function ge() {
  return Tt = oe < rm ? Ir(si, oe++) : 0, ti++, Tt === 10 && (ti = 1, ja++), Tt;
}
function He() {
  return Ir(si, oe);
}
function Rn() {
  return oe;
}
function Ya(e, t) {
  return Jr(si, e, t);
}
function Gi(e) {
  switch (e) {
    case 0:
    case 9:
    case 10:
    case 13:
    case 32:
      return 5;
    case 33:
    case 43:
    case 44:
    case 47:
    case 62:
    case 64:
    case 126:
    case 59:
    case 123:
    case 125:
      return 4;
    case 58:
      return 3;
    case 34:
    case 39:
    case 40:
    case 91:
      return 2;
    case 41:
    case 93:
      return 1;
  }
  return 0;
}
function jS(e) {
  return ja = ti = 1, rm = _e(si = e), oe = 0, [];
}
function YS(e) {
  return si = "", e;
}
function _s(e) {
  return em(Ya(oe - 1, go(e === 91 ? e + 2 : e === 40 ? e + 1 : e)));
}
function US(e) {
  for (; (Tt = He()) && Tt < 33; )
    ge();
  return Gi(e) > 2 || Gi(Tt) > 3 ? "" : " ";
}
function GS(e, t) {
  for (; --t && ge() && !(Tt < 48 || Tt > 102 || Tt > 57 && Tt < 65 || Tt > 70 && Tt < 97); )
    ;
  return Ya(e, Rn() + (t < 6 && He() == 32 && ge() == 32));
}
function go(e) {
  for (; ge(); )
    switch (Tt) {
      case e:
        return oe;
      case 34:
      case 39:
        e !== 34 && e !== 39 && go(Tt);
        break;
      case 40:
        e === 41 && go(e);
        break;
      case 92:
        ge();
        break;
    }
  return oe;
}
function XS(e, t) {
  for (; ge() && e + Tt !== 57; )
    if (e + Tt === 84 && He() === 47)
      break;
  return "/*" + Ya(t, oe - 1) + "*" + wl(e === 47 ? e : ge());
}
function VS(e) {
  for (; !Gi(He()); )
    ge();
  return Ya(e, oe);
}
function ZS(e) {
  return YS(In("", null, null, null, [""], e = jS(e), 0, [0], e));
}
function In(e, t, r, i, n, a, o, s, l) {
  for (var c = 0, h = 0, u = o, f = 0, p = 0, g = 0, m = 1, y = 1, x = 1, b = 0, _ = "", v = n, w = a, C = i, S = _; y; )
    switch (g = b, b = ge()) {
      case 40:
        if (g != 108 && Ir(S, u - 1) == 58) {
          zS(S += On(_s(b), "&", "&\f"), "&\f", tm(c ? s[c - 1] : 0)) != -1 && (x = -1);
          break;
        }
      case 34:
      case 39:
      case 91:
        S += _s(b);
        break;
      case 9:
      case 10:
      case 13:
      case 32:
        S += US(g);
        break;
      case 92:
        S += GS(Rn() - 1, 7);
        continue;
      case 47:
        switch (He()) {
          case 42:
          case 47:
            wn(KS(XS(ge(), Rn()), t, r, l), l), (Gi(g || 1) == 5 || Gi(He() || 1) == 5) && _e(S) && Jr(S, -1, void 0) !== " " && (S += " ");
            break;
          default:
            S += "/";
        }
        break;
      case 123 * m:
        s[c++] = _e(S) * x;
      case 125 * m:
      case 59:
      case 0:
        switch (b) {
          case 0:
          case 125:
            y = 0;
          case 59 + h:
            x == -1 && (S = On(S, /\f/g, "")), p > 0 && (_e(S) - u || m === 0 && g === 47) && wn(p > 32 ? fh(S + ";", i, r, u - 1, l) : fh(On(S, " ", "") + ";", i, r, u - 2, l), l);
            break;
          case 59:
            S += ";";
          default:
            if (wn(C = uh(S, t, r, c, h, n, s, _, v = [], w = [], u, a), a), b === 123)
              if (h === 0)
                In(S, t, C, C, v, a, u, s, w);
              else {
                switch (f) {
                  case 99:
                    if (Ir(S, 3) === 110) break;
                  case 108:
                    if (Ir(S, 2) === 97) break;
                  default:
                    h = 0;
                  case 100:
                  case 109:
                  case 115:
                }
                h ? In(e, C, C, i && wn(uh(e, C, C, 0, 0, n, s, _, n, v = [], u, w), w), n, w, u, s, i ? v : w) : In(S, C, C, C, [""], w, 0, s, w);
              }
        }
        c = h = p = 0, m = x = 1, _ = S = "", u = o;
        break;
      case 58:
        u = 1 + _e(S), p = g;
      default:
        if (m < 1) {
          if (b == 123)
            --m;
          else if (b == 125 && m++ == 0 && HS() == 125)
            continue;
        }
        switch (S += wl(b), b * m) {
          case 38:
            x = h > 0 ? 1 : (S += "\f", -1);
            break;
          case 44:
            s[c++] = (_e(S) - 1) * x, x = 1;
            break;
          case 64:
            He() === 45 && (S += _s(ge())), f = He(), h = u = _e(_ = S += VS(Rn())), b++;
            break;
          case 45:
            g === 45 && _e(S) == 2 && (m = 0);
        }
    }
  return a;
}
function uh(e, t, r, i, n, a, o, s, l, c, h, u) {
  for (var f = n - 1, p = n === 0 ? a : [""], g = WS(p), m = 0, y = 0, x = 0; m < i; ++m)
    for (var b = 0, _ = Jr(e, f + 1, f = tm(y = o[m])), v = e; b < g; ++b)
      (v = em(y > 0 ? p[b] + " " + _ : On(_, /&\f/g, p[b]))) && (l[x++] = v);
  return kl(e, t, r, n === 0 ? Qg : s, l, c, h, u);
}
function KS(e, t, r, i) {
  return kl(e, t, r, Kg, wl(qS()), Jr(e, 2, -2), 0, i);
}
function fh(e, t, r, i, n) {
  return kl(e, t, r, Jg, Jr(e, 0, i), Jr(e, i + 1, -1), i, n);
}
function mo(e, t) {
  for (var r = "", i = 0; i < e.length; i++)
    r += t(e[i], i, e, t) || "";
  return r;
}
function QS(e, t, r, i) {
  switch (e.type) {
    case NS:
      if (e.children.length) break;
    case RS:
    case IS:
    case Jg:
      return e.return = e.return || e.value;
    case Kg:
      return "";
    case PS:
      return e.return = e.value + "{" + mo(e.children, i) + "}";
    case Qg:
      if (!_e(e.value = e.props.join(","))) return "";
  }
  return _e(r = mo(e.children, i)) ? e.return = e.value + "{" + r + "}" : "";
}
var JS = Ap(Object.keys, Object), tT = Object.prototype, eT = tT.hasOwnProperty;
function rT(e) {
  if (!Da(e))
    return JS(e);
  var t = [];
  for (var r in Object(e))
    eT.call(e, r) && r != "constructor" && t.push(r);
  return t;
}
var yo = _r(Te, "DataView"), xo = _r(Te, "Promise"), bo = _r(Te, "Set"), Co = _r(Te, "WeakMap"), ph = "[object Map]", iT = "[object Object]", dh = "[object Promise]", gh = "[object Set]", mh = "[object WeakMap]", yh = "[object DataView]", nT = Cr(yo), aT = Cr(ji), sT = Cr(xo), oT = Cr(bo), lT = Cr(Co), nr = ii;
(yo && nr(new yo(new ArrayBuffer(1))) != yh || ji && nr(new ji()) != ph || xo && nr(xo.resolve()) != dh || bo && nr(new bo()) != gh || Co && nr(new Co()) != mh) && (nr = function(e) {
  var t = ii(e), r = t == iT ? e.constructor : void 0, i = r ? Cr(r) : "";
  if (i)
    switch (i) {
      case nT:
        return yh;
      case aT:
        return ph;
      case sT:
        return dh;
      case oT:
        return gh;
      case lT:
        return mh;
    }
  return t;
});
var cT = "[object Map]", hT = "[object Set]", uT = Object.prototype, fT = uT.hasOwnProperty;
function xh(e) {
  if (e == null)
    return !0;
  if (Oa(e) && (la(e) || typeof e == "string" || typeof e.splice == "function" || tl(e) || el(e) || oa(e)))
    return !e.length;
  var t = nr(e);
  if (t == cT || t == hT)
    return !e.size;
  if (Da(e))
    return !rT(e).length;
  for (var r in e)
    if (fT.call(e, r))
      return !1;
  return !0;
}
var im = "c4", pT = /* @__PURE__ */ d((e) => /^\s*C4Context|C4Container|C4Component|C4Dynamic|C4Deployment/.test(e), "detector"), dT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./c4Diagram-YG6GDRKO-DgopwTcO.js");
  return { id: im, diagram: e };
}, "loader"), gT = {
  id: im,
  detector: pT,
  loader: dT
}, mT = gT, nm = "flowchart", yT = /* @__PURE__ */ d((e, t) => {
  var r, i;
  return ((r = t == null ? void 0 : t.flowchart) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" || ((i = t == null ? void 0 : t.flowchart) == null ? void 0 : i.defaultRenderer) === "elk" ? !1 : /^\s*graph/.test(e);
}, "detector"), xT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./flowDiagram-NV44I4VS-YqB3_P1q.js");
  return { id: nm, diagram: e };
}, "loader"), bT = {
  id: nm,
  detector: yT,
  loader: xT
}, CT = bT, am = "flowchart-v2", _T = /* @__PURE__ */ d((e, t) => {
  var r, i, n;
  return ((r = t == null ? void 0 : t.flowchart) == null ? void 0 : r.defaultRenderer) === "dagre-d3" ? !1 : (((i = t == null ? void 0 : t.flowchart) == null ? void 0 : i.defaultRenderer) === "elk" && (t.layout = "elk"), /^\s*graph/.test(e) && ((n = t == null ? void 0 : t.flowchart) == null ? void 0 : n.defaultRenderer) === "dagre-wrapper" ? !0 : /^\s*flowchart/.test(e));
}, "detector"), wT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./flowDiagram-NV44I4VS-YqB3_P1q.js");
  return { id: am, diagram: e };
}, "loader"), kT = {
  id: am,
  detector: _T,
  loader: wT
}, vT = kT, sm = "er", ST = /* @__PURE__ */ d((e) => /^\s*erDiagram/.test(e), "detector"), TT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./erDiagram-Q2GNP2WA-BpLIk0RR.js");
  return { id: sm, diagram: e };
}, "loader"), BT = {
  id: sm,
  detector: ST,
  loader: TT
}, AT = BT, om = "gitGraph", LT = /* @__PURE__ */ d((e) => /^\s*gitGraph/.test(e), "detector"), MT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./gitGraphDiagram-NY62KEGX-DMpYXXYj.js");
  return { id: om, diagram: e };
}, "loader"), $T = {
  id: om,
  detector: LT,
  loader: MT
}, ET = $T, lm = "gantt", FT = /* @__PURE__ */ d((e) => /^\s*gantt/.test(e), "detector"), DT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./ganttDiagram-LVOFAZNH-Qd4RjNjR.js");
  return { id: lm, diagram: e };
}, "loader"), OT = {
  id: lm,
  detector: FT,
  loader: DT
}, RT = OT, cm = "info", IT = /* @__PURE__ */ d((e) => /^\s*info/.test(e), "detector"), PT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./infoDiagram-F6ZHWCRC-B1TG-xI2.js");
  return { id: cm, diagram: e };
}, "loader"), NT = {
  id: cm,
  detector: IT,
  loader: PT
}, hm = "pie", zT = /* @__PURE__ */ d((e) => /^\s*pie/.test(e), "detector"), WT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./pieDiagram-ADFJNKIX-3Hqk3rdr.js");
  return { id: hm, diagram: e };
}, "loader"), qT = {
  id: hm,
  detector: zT,
  loader: WT
}, um = "quadrantChart", HT = /* @__PURE__ */ d((e) => /^\s*quadrantChart/.test(e), "detector"), jT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./quadrantDiagram-AYHSOK5B-Q_kMdi4f.js");
  return { id: um, diagram: e };
}, "loader"), YT = {
  id: um,
  detector: HT,
  loader: jT
}, UT = YT, fm = "xychart", GT = /* @__PURE__ */ d((e) => /^\s*xychart(-beta)?/.test(e), "detector"), XT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./xychartDiagram-PRI3JC2R-BA_Eo4sD.js");
  return { id: fm, diagram: e };
}, "loader"), VT = {
  id: fm,
  detector: GT,
  loader: XT
}, ZT = VT, pm = "requirement", KT = /* @__PURE__ */ d((e) => /^\s*requirement(Diagram)?/.test(e), "detector"), QT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./requirementDiagram-UZGBJVZJ-CwwYl0HY.js");
  return { id: pm, diagram: e };
}, "loader"), JT = {
  id: pm,
  detector: KT,
  loader: QT
}, tB = JT, dm = "sequence", eB = /* @__PURE__ */ d((e) => /^\s*sequenceDiagram/.test(e), "detector"), rB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./sequenceDiagram-WL72ISMW-BW5r5oRq.js");
  return { id: dm, diagram: e };
}, "loader"), iB = {
  id: dm,
  detector: eB,
  loader: rB
}, nB = iB, gm = "class", aB = /* @__PURE__ */ d((e, t) => {
  var r;
  return ((r = t == null ? void 0 : t.class) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" ? !1 : /^\s*classDiagram/.test(e);
}, "detector"), sB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./classDiagram-2ON5EDUG-CNb6AZ63.js");
  return { id: gm, diagram: e };
}, "loader"), oB = {
  id: gm,
  detector: aB,
  loader: sB
}, lB = oB, mm = "classDiagram", cB = /* @__PURE__ */ d((e, t) => {
  var r;
  return /^\s*classDiagram/.test(e) && ((r = t == null ? void 0 : t.class) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" ? !0 : /^\s*classDiagram-v2/.test(e);
}, "detector"), hB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./classDiagram-v2-WZHVMYZB-CNb6AZ63.js");
  return { id: mm, diagram: e };
}, "loader"), uB = {
  id: mm,
  detector: cB,
  loader: hB
}, fB = uB, ym = "state", pB = /* @__PURE__ */ d((e, t) => {
  var r;
  return ((r = t == null ? void 0 : t.state) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" ? !1 : /^\s*stateDiagram/.test(e);
}, "detector"), dB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./stateDiagram-FKZM4ZOC-Co181xO2.js");
  return { id: ym, diagram: e };
}, "loader"), gB = {
  id: ym,
  detector: pB,
  loader: dB
}, mB = gB, xm = "stateDiagram", yB = /* @__PURE__ */ d((e, t) => {
  var r;
  return !!(/^\s*stateDiagram-v2/.test(e) || /^\s*stateDiagram/.test(e) && ((r = t == null ? void 0 : t.state) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper");
}, "detector"), xB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./stateDiagram-v2-4FDKWEC3-D1kgi4sS.js");
  return { id: xm, diagram: e };
}, "loader"), bB = {
  id: xm,
  detector: yB,
  loader: xB
}, CB = bB, bm = "journey", _B = /* @__PURE__ */ d((e) => /^\s*journey/.test(e), "detector"), wB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./journeyDiagram-XKPGCS4Q-OsGmcbzl.js");
  return { id: bm, diagram: e };
}, "loader"), kB = {
  id: bm,
  detector: _B,
  loader: wB
}, vB = kB, SB = /* @__PURE__ */ d((e, t, r) => {
  F.debug(`rendering svg for syntax error
`);
  const i = n2(t), n = i.append("g");
  i.attr("viewBox", "0 0 2412 512"), jh(i, 100, 512, !0), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m411.313,123.313c6.25-6.25 6.25-16.375 0-22.625s-16.375-6.25-22.625,0l-32,32-9.375,9.375-20.688-20.688c-12.484-12.5-32.766-12.5-45.25,0l-16,16c-1.261,1.261-2.304,2.648-3.31,4.051-21.739-8.561-45.324-13.426-70.065-13.426-105.867,0-192,86.133-192,192s86.133,192 192,192 192-86.133 192-192c0-24.741-4.864-48.327-13.426-70.065 1.402-1.007 2.79-2.049 4.051-3.31l16-16c12.5-12.492 12.5-32.758 0-45.25l-20.688-20.688 9.375-9.375 32.001-31.999zm-219.313,100.687c-52.938,0-96,43.063-96,96 0,8.836-7.164,16-16,16s-16-7.164-16-16c0-70.578 57.422-128 128-128 8.836,0 16,7.164 16,16s-7.164,16-16,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m459.02,148.98c-6.25-6.25-16.375-6.25-22.625,0s-6.25,16.375 0,22.625l16,16c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688 6.25-6.25 6.25-16.375 0-22.625l-16.001-16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m340.395,75.605c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688 6.25-6.25 6.25-16.375 0-22.625l-16-16c-6.25-6.25-16.375-6.25-22.625,0s-6.25,16.375 0,22.625l15.999,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m400,64c8.844,0 16-7.164 16-16v-32c0-8.836-7.156-16-16-16-8.844,0-16,7.164-16,16v32c0,8.836 7.156,16 16,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m496,96.586h-32c-8.844,0-16,7.164-16,16 0,8.836 7.156,16 16,16h32c8.844,0 16-7.164 16-16 0-8.836-7.156-16-16-16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m436.98,75.605c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688l32-32c6.25-6.25 6.25-16.375 0-22.625s-16.375-6.25-22.625,0l-32,32c-6.251,6.25-6.251,16.375-0.001,22.625z"
  ), n.append("text").attr("class", "error-text").attr("x", 1440).attr("y", 250).attr("font-size", "150px").style("text-anchor", "middle").text("Syntax error in text"), n.append("text").attr("class", "error-text").attr("x", 1250).attr("y", 400).attr("font-size", "100px").style("text-anchor", "middle").text(`mermaid version ${r}`);
}, "draw"), Cm = { draw: SB }, TB = Cm, BB = {
  db: {},
  renderer: Cm,
  parser: {
    parse: /* @__PURE__ */ d(() => {
    }, "parse")
  }
}, AB = BB, _m = "flowchart-elk", LB = /* @__PURE__ */ d((e, t = {}) => {
  var r;
  return (
    // If diagram explicitly states flowchart-elk
    /^\s*flowchart-elk/.test(e) || // If a flowchart/graph diagram has their default renderer set to elk
    /^\s*(flowchart|graph)/.test(e) && ((r = t == null ? void 0 : t.flowchart) == null ? void 0 : r.defaultRenderer) === "elk" ? (t.layout = "elk", !0) : !1
  );
}, "detector"), MB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./flowDiagram-NV44I4VS-YqB3_P1q.js");
  return { id: _m, diagram: e };
}, "loader"), $B = {
  id: _m,
  detector: LB,
  loader: MB
}, EB = $B, wm = "timeline", FB = /* @__PURE__ */ d((e) => /^\s*timeline/.test(e), "detector"), DB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./timeline-definition-IT6M3QCI-CPSXtG2U.js");
  return { id: wm, diagram: e };
}, "loader"), OB = {
  id: wm,
  detector: FB,
  loader: DB
}, RB = OB, km = "mindmap", IB = /* @__PURE__ */ d((e) => /^\s*mindmap/.test(e), "detector"), PB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./mindmap-definition-VGOIOE7T-DjRwat61.js");
  return { id: km, diagram: e };
}, "loader"), NB = {
  id: km,
  detector: IB,
  loader: PB
}, zB = NB, vm = "kanban", WB = /* @__PURE__ */ d((e) => /^\s*kanban/.test(e), "detector"), qB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./kanban-definition-3W4ZIXB7-CTvSGFV4.js");
  return { id: vm, diagram: e };
}, "loader"), HB = {
  id: vm,
  detector: WB,
  loader: qB
}, jB = HB, Sm = "sankey", YB = /* @__PURE__ */ d((e) => /^\s*sankey(-beta)?/.test(e), "detector"), UB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./sankeyDiagram-TZEHDZUN-D2LwpHwb.js");
  return { id: Sm, diagram: e };
}, "loader"), GB = {
  id: Sm,
  detector: YB,
  loader: UB
}, XB = GB, Tm = "packet", VB = /* @__PURE__ */ d((e) => /^\s*packet(-beta)?/.test(e), "detector"), ZB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./diagram-S2PKOQOG-CDoNOsv3.js");
  return { id: Tm, diagram: e };
}, "loader"), KB = {
  id: Tm,
  detector: VB,
  loader: ZB
}, Bm = "radar", QB = /* @__PURE__ */ d((e) => /^\s*radar-beta/.test(e), "detector"), JB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./diagram-QEK2KX5R-BXv1tNm4.js");
  return { id: Bm, diagram: e };
}, "loader"), tA = {
  id: Bm,
  detector: QB,
  loader: JB
}, Am = "block", eA = /* @__PURE__ */ d((e) => /^\s*block(-beta)?/.test(e), "detector"), rA = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./blockDiagram-VD42YOAC-DQrfiDyt.js");
  return { id: Am, diagram: e };
}, "loader"), iA = {
  id: Am,
  detector: eA,
  loader: rA
}, nA = iA, Lm = "architecture", aA = /* @__PURE__ */ d((e) => /^\s*architecture/.test(e), "detector"), sA = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./architectureDiagram-VXUJARFQ-CqO71p_x.js");
  return { id: Lm, diagram: e };
}, "loader"), oA = {
  id: Lm,
  detector: aA,
  loader: sA
}, lA = oA, Mm = "treemap", cA = /* @__PURE__ */ d((e) => /^\s*treemap/.test(e), "detector"), hA = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./diagram-PSM6KHXK-BBF0cjK2.js");
  return { id: Mm, diagram: e };
}, "loader"), uA = {
  id: Mm,
  detector: cA,
  loader: hA
}, bh = !1, Ua = /* @__PURE__ */ d(() => {
  bh || (bh = !0, qn("error", AB, (e) => e.toLowerCase().trim() === "error"), qn(
    "---",
    // --- diagram type may appear if YAML front-matter is not parsed correctly
    {
      db: {
        clear: /* @__PURE__ */ d(() => {
        }, "clear")
      },
      styles: {},
      // should never be used
      renderer: {
        draw: /* @__PURE__ */ d(() => {
        }, "draw")
      },
      parser: {
        parse: /* @__PURE__ */ d(() => {
          throw new Error(
            "Diagrams beginning with --- are not valid. If you were trying to use a YAML front-matter, please ensure that you've correctly opened and closed the YAML front-matter with un-indented `---` blocks"
          );
        }, "parse")
      },
      init: /* @__PURE__ */ d(() => null, "init")
      // no op
    },
    (e) => e.toLowerCase().trimStart().startsWith("---")
  ), Ts(EB, zB, lA), Ts(
    mT,
    jB,
    fB,
    lB,
    AT,
    RT,
    NT,
    qT,
    tB,
    nB,
    vT,
    CT,
    RB,
    ET,
    CB,
    mB,
    vB,
    UT,
    XB,
    KB,
    ZT,
    nA,
    tA,
    uA
  ));
}, "addDiagrams"), fA = /* @__PURE__ */ d(async () => {
  F.debug("Loading registered diagrams");
  const t = (await Promise.allSettled(
    Object.entries(fr).map(async ([r, { detector: i, loader: n }]) => {
      if (n)
        try {
          Ms(r);
        } catch {
          try {
            const { diagram: a, id: o } = await n();
            qn(o, a, i);
          } catch (a) {
            throw F.error(`Failed to load external diagram with key ${r}. Removing from detectors.`), delete fr[r], a;
          }
        }
    })
  )).filter((r) => r.status === "rejected");
  if (t.length > 0) {
    F.error(`Failed to load ${t.length} external diagrams`);
    for (const r of t)
      F.error(r);
    throw new Error(`Failed to load ${t.length} external diagrams`);
  }
}, "loadRegisteredDiagrams"), pA = "graphics-document document";
function $m(e, t) {
  e.attr("role", pA), t !== "" && e.attr("aria-roledescription", t);
}
d($m, "setA11yDiagramInfo");
function Em(e, t, r, i) {
  if (e.insert !== void 0) {
    if (r) {
      const n = `chart-desc-${i}`;
      e.attr("aria-describedby", n), e.insert("desc", ":first-child").attr("id", n).text(r);
    }
    if (t) {
      const n = `chart-title-${i}`;
      e.attr("aria-labelledby", n), e.insert("title", ":first-child").attr("id", n).text(t);
    }
  }
}
d(Em, "addSVGa11yTitleDescription");
var ur, _o = (ur = class {
  constructor(t, r, i, n, a) {
    this.type = t, this.text = r, this.db = i, this.parser = n, this.renderer = a;
  }
  static async fromText(t, r = {}) {
    var c, h;
    const i = Nt(), n = vo(t, i);
    t = uk(t) + `
`;
    try {
      Ms(n);
    } catch {
      const u = D0(n);
      if (!u)
        throw new Eh(`Diagram ${n} not found.`);
      const { id: f, diagram: p } = await u();
      qn(f, p);
    }
    const { db: a, parser: o, renderer: s, init: l } = Ms(n);
    return o.parser && (o.parser.yy = a), (c = a.clear) == null || c.call(a), l == null || l(i), r.title && ((h = a.setDiagramTitle) == null || h.call(a, r.title)), await o.parse(t), new ur(n, t, a, o, s);
  }
  async render(t, r) {
    await this.renderer.draw(this.text, t, r, this);
  }
  getParser() {
    return this.parser;
  }
  getType() {
    return this.type;
  }
}, d(ur, "Diagram"), ur), Ch = [], dA = /* @__PURE__ */ d(() => {
  Ch.forEach((e) => {
    e();
  }), Ch = [];
}, "attachFunctions"), gA = /* @__PURE__ */ d((e) => e.replace(/^\s*%%(?!{)[^\n]+\n?/gm, "").trimStart(), "cleanupComments");
function Fm(e) {
  const t = e.match($h);
  if (!t)
    return {
      text: e,
      metadata: {}
    };
  let r = uC(t[1], {
    // To support config, we need JSON schema.
    // https://www.yaml.org/spec/1.2/spec.html#id2803231
    schema: hC
  }) ?? {};
  r = typeof r == "object" && !Array.isArray(r) ? r : {};
  const i = {};
  return r.displayMode && (i.displayMode = r.displayMode.toString()), r.title && (i.title = r.title.toString()), r.config && (i.config = r.config), {
    text: e.slice(t[0].length),
    metadata: i
  };
}
d(Fm, "extractFrontMatter");
var mA = /* @__PURE__ */ d((e) => e.replace(/\r\n?/g, `
`).replace(
  /<(\w+)([^>]*)>/g,
  (t, r, i) => "<" + r + i.replace(/="([^"]*)"/g, "='$1'") + ">"
), "cleanupText"), yA = /* @__PURE__ */ d((e) => {
  const { text: t, metadata: r } = Fm(e), { displayMode: i, title: n, config: a = {} } = r;
  return i && (a.gantt || (a.gantt = {}), a.gantt.displayMode = i), { title: n, config: a, text: t };
}, "processFrontmatter"), xA = /* @__PURE__ */ d((e) => {
  const t = pe.detectInit(e) ?? {}, r = pe.detectDirective(e, "wrap");
  return Array.isArray(r) ? t.wrap = r.some(({ type: i }) => i === "wrap") : (r == null ? void 0 : r.type) === "wrap" && (t.wrap = !0), {
    text: Qw(e),
    directive: t
  };
}, "processDirectives");
function vl(e) {
  const t = mA(e), r = yA(t), i = xA(r.text), n = ol(r.config, i.directive);
  return e = gA(i.text), {
    code: e,
    title: r.title,
    config: n
  };
}
d(vl, "preprocessDiagram");
function Dm(e) {
  const t = new TextEncoder().encode(e), r = Array.from(t, (i) => String.fromCodePoint(i)).join("");
  return btoa(r);
}
d(Dm, "toBase64");
var bA = 5e4, CA = "graph TB;a[Maximum text size in diagram exceeded];style a fill:#faa", _A = "sandbox", wA = "loose", kA = "http://www.w3.org/2000/svg", vA = "http://www.w3.org/1999/xlink", SA = "http://www.w3.org/1999/xhtml", TA = "100%", BA = "100%", AA = "border:0;margin:0;", LA = "margin:0", MA = "allow-top-navigation-by-user-activation allow-popups", $A = 'The "iframe" tag is not supported by your browser.', EA = ["foreignobject"], FA = ["dominant-baseline"];
function Sl(e) {
  const t = vl(e);
  return zn(), Z0(t.config ?? {}), t;
}
d(Sl, "processAndSetConfigs");
async function Om(e, t) {
  Ua();
  try {
    const { code: r, config: i } = Sl(e);
    return { diagramType: (await Im(r)).type, config: i };
  } catch (r) {
    if (t != null && t.suppressErrors)
      return !1;
    throw r;
  }
}
d(Om, "parse");
var _h = /* @__PURE__ */ d((e, t, r = []) => `
.${e} ${t} { ${r.join(" !important; ")} !important; }`, "cssImportantStyles"), DA = /* @__PURE__ */ d((e, t = /* @__PURE__ */ new Map()) => {
  var i;
  let r = "";
  if (e.themeCSS !== void 0 && (r += `
${e.themeCSS}`), e.fontFamily !== void 0 && (r += `
:root { --mermaid-font-family: ${e.fontFamily}}`), e.altFontFamily !== void 0 && (r += `
:root { --mermaid-alt-font-family: ${e.altFontFamily}}`), t instanceof Map) {
    const s = e.htmlLabels ?? ((i = e.flowchart) == null ? void 0 : i.htmlLabels) ? ["> *", "span"] : ["rect", "polygon", "ellipse", "circle", "path"];
    t.forEach((l) => {
      xh(l.styles) || s.forEach((c) => {
        r += _h(l.id, c, l.styles);
      }), xh(l.textStyles) || (r += _h(
        l.id,
        "tspan",
        ((l == null ? void 0 : l.textStyles) || []).map((c) => c.replace("color", "fill"))
      ));
    });
  }
  return r;
}, "createCssStyles"), OA = /* @__PURE__ */ d((e, t, r, i) => {
  const n = DA(e, r), a = my(t, n, e.themeVariables);
  return mo(ZS(`${i}{${a}}`), QS);
}, "createUserStyles"), RA = /* @__PURE__ */ d((e = "", t, r) => {
  let i = e;
  return !r && !t && (i = i.replace(
    /marker-end="url\([\d+./:=?A-Za-z-]*?#/g,
    'marker-end="url(#'
  )), i = wr(i), i = i.replace(/<br>/g, "<br/>"), i;
}, "cleanUpSvgCode"), IA = /* @__PURE__ */ d((e = "", t) => {
  var n, a;
  const r = (a = (n = t == null ? void 0 : t.viewBox) == null ? void 0 : n.baseVal) != null && a.height ? t.viewBox.baseVal.height + "px" : BA, i = Dm(`<body style="${LA}">${e}</body>`);
  return `<iframe style="width:${TA};height:${r};${AA}" src="data:text/html;charset=UTF-8;base64,${i}" sandbox="${MA}">
  ${$A}
</iframe>`;
}, "putIntoIFrame"), wh = /* @__PURE__ */ d((e, t, r, i, n) => {
  const a = e.append("div");
  a.attr("id", r), i && a.attr("style", i);
  const o = a.append("svg").attr("id", t).attr("width", "100%").attr("xmlns", kA);
  return n && o.attr("xmlns:xlink", n), o.append("g"), e;
}, "appendDivSvgG");
function wo(e, t) {
  return e.append("iframe").attr("id", t).attr("style", "width: 100%; height: 100%;").attr("sandbox", "");
}
d(wo, "sandboxedIframe");
var PA = /* @__PURE__ */ d((e, t, r, i) => {
  var n, a, o;
  (n = e.getElementById(t)) == null || n.remove(), (a = e.getElementById(r)) == null || a.remove(), (o = e.getElementById(i)) == null || o.remove();
}, "removeExistingElements"), NA = /* @__PURE__ */ d(async function(e, t, r) {
  var z, O, M, A, B, E;
  Ua();
  const i = Sl(t);
  t = i.code;
  const n = Nt();
  F.debug(n), t.length > ((n == null ? void 0 : n.maxTextSize) ?? bA) && (t = CA);
  const a = "#" + e, o = "i" + e, s = "#" + o, l = "d" + e, c = "#" + l, h = /* @__PURE__ */ d(() => {
    const W = ht(f ? s : c).node();
    W && "remove" in W && W.remove();
  }, "removeTempElements");
  let u = ht("body");
  const f = n.securityLevel === _A, p = n.securityLevel === wA, g = n.fontFamily;
  if (r !== void 0) {
    if (r && (r.innerHTML = ""), f) {
      const L = wo(ht(r), o);
      u = ht(L.nodes()[0].contentDocument.body), u.node().style.margin = 0;
    } else
      u = ht(r);
    wh(u, e, l, `font-family: ${g}`, vA);
  } else {
    if (PA(document, e, l, o), f) {
      const L = wo(ht("body"), o);
      u = ht(L.nodes()[0].contentDocument.body), u.node().style.margin = 0;
    } else
      u = ht("body");
    wh(u, e, l);
  }
  let m, y;
  try {
    m = await _o.fromText(t, { title: i.title });
  } catch (L) {
    if (n.suppressErrorRendering)
      throw h(), L;
    m = await _o.fromText("error"), y = L;
  }
  const x = u.select(c).node(), b = m.type, _ = x.firstChild, v = _.firstChild, w = (O = (z = m.renderer).getClasses) == null ? void 0 : O.call(z, t, m), C = OA(n, b, w, a), S = document.createElement("style");
  S.innerHTML = C, _.insertBefore(S, v);
  try {
    await m.renderer.draw(t, e, jl.version, m);
  } catch (L) {
    throw n.suppressErrorRendering ? h() : TB.draw(t, e, jl.version), L;
  }
  const D = u.select(`${c} svg`), P = (A = (M = m.db).getAccTitle) == null ? void 0 : A.call(M), R = (E = (B = m.db).getAccDescription) == null ? void 0 : E.call(B);
  Pm(b, D, P, R), u.select(`[id="${e}"]`).selectAll("foreignobject > *").attr("xmlns", SA);
  let $ = u.select(c).node().innerHTML;
  if (F.debug("config.arrowMarkerAbsolute", n.arrowMarkerAbsolute), $ = RA($, f, Lt(n.arrowMarkerAbsolute)), f) {
    const L = u.select(c + " svg").node();
    $ = IA($, L);
  } else p || ($ = Ur.sanitize($, {
    ADD_TAGS: EA,
    ADD_ATTR: FA,
    HTML_INTEGRATION_POINTS: { foreignobject: !0 }
  }));
  if (dA(), y)
    throw y;
  return h(), {
    diagramType: b,
    svg: $,
    bindFunctions: m.db.bindFunctions
  };
}, "render");
function Rm(e = {}) {
  var i;
  const t = Bt({}, e);
  t != null && t.fontFamily && !((i = t.themeVariables) != null && i.fontFamily) && (t.themeVariables || (t.themeVariables = {}), t.themeVariables.fontFamily = t.fontFamily), X0(t), t != null && t.theme && t.theme in Oe ? t.themeVariables = Oe[t.theme].getThemeVariables(
    t.themeVariables
  ) : t && (t.themeVariables = Oe.default.getThemeVariables(t.themeVariables));
  const r = typeof t == "object" ? G0(t) : Ih();
  ko(r.logLevel), Ua();
}
d(Rm, "initialize");
var Im = /* @__PURE__ */ d((e, t = {}) => {
  const { code: r } = vl(e);
  return _o.fromText(r, t);
}, "getDiagramFromText");
function Pm(e, t, r, i) {
  $m(t, e), Em(t, r, i, t.attr("id"));
}
d(Pm, "addA11yInfo");
var xr = Object.freeze({
  render: NA,
  parse: Om,
  getDiagramFromText: Im,
  initialize: Rm,
  getConfig: Nt,
  setConfig: Ph,
  getSiteConfig: Ih,
  updateSiteConfig: V0,
  reset: /* @__PURE__ */ d(() => {
    zn();
  }, "reset"),
  globalReset: /* @__PURE__ */ d(() => {
    zn(Gr);
  }, "globalReset"),
  defaultConfig: Gr
});
ko(Nt().logLevel);
zn(Nt());
var zA = /* @__PURE__ */ d((e, t, r) => {
  F.warn(e), sl(e) ? (r && r(e.str, e.hash), t.push({ ...e, message: e.str, error: e })) : (r && r(e), e instanceof Error && t.push({
    str: e.message,
    message: e.message,
    hash: e.name,
    error: e
  }));
}, "handleError"), Nm = /* @__PURE__ */ d(async function(e = {
  querySelector: ".mermaid"
}) {
  try {
    await WA(e);
  } catch (t) {
    if (sl(t) && F.error(t.str), ee.parseError && ee.parseError(t), !e.suppressErrors)
      throw F.error("Use the suppressErrors option to suppress these errors"), t;
  }
}, "run"), WA = /* @__PURE__ */ d(async function({ postRenderCallback: e, querySelector: t, nodes: r } = {
  querySelector: ".mermaid"
}) {
  const i = xr.getConfig();
  F.debug(`${e ? "" : "No "}Callback function found`);
  let n;
  if (r)
    n = r;
  else if (t)
    n = document.querySelectorAll(t);
  else
    throw new Error("Nodes and querySelector are both undefined");
  F.debug(`Found ${n.length} diagrams`), (i == null ? void 0 : i.startOnLoad) !== void 0 && (F.debug("Start On Load: " + (i == null ? void 0 : i.startOnLoad)), xr.updateSiteConfig({ startOnLoad: i == null ? void 0 : i.startOnLoad }));
  const a = new pe.InitIDGenerator(i.deterministicIds, i.deterministicIDSeed);
  let o;
  const s = [];
  for (const l of Array.from(n)) {
    if (F.info("Rendering diagram: " + l.id), l.getAttribute("data-processed"))
      continue;
    l.setAttribute("data-processed", "true");
    const c = `mermaid-${a.next()}`;
    o = l.innerHTML, o = sd(pe.entityDecode(o)).trim().replace(/<br\s*\/?>/gi, "<br/>");
    const h = pe.detectInit(o);
    h && F.debug("Detected early reinit: ", h);
    try {
      const { svg: u, bindFunctions: f } = await Hm(c, o, l);
      l.innerHTML = u, e && await e(c), f && f(l);
    } catch (u) {
      zA(u, s, ee.parseError);
    }
  }
  if (s.length > 0)
    throw s[0];
}, "runThrowsErrors"), zm = /* @__PURE__ */ d(function(e) {
  xr.initialize(e);
}, "initialize"), qA = /* @__PURE__ */ d(async function(e, t, r) {
  F.warn("mermaid.init is deprecated. Please use run instead."), e && zm(e);
  const i = { postRenderCallback: r, querySelector: ".mermaid" };
  typeof t == "string" ? i.querySelector = t : t && (t instanceof HTMLElement ? i.nodes = [t] : i.nodes = t), await Nm(i);
}, "init"), HA = /* @__PURE__ */ d(async (e, {
  lazyLoad: t = !0
} = {}) => {
  Ua(), Ts(...e), t === !1 && await fA();
}, "registerExternalDiagrams"), Wm = /* @__PURE__ */ d(function() {
  if (ee.startOnLoad) {
    const { startOnLoad: e } = xr.getConfig();
    e && ee.run().catch((t) => F.error("Mermaid failed to initialize", t));
  }
}, "contentLoaded");
typeof document < "u" && window.addEventListener("load", Wm, !1);
var jA = /* @__PURE__ */ d(function(e) {
  ee.parseError = e;
}, "setParseErrorHandler"), ba = [], ws = !1, qm = /* @__PURE__ */ d(async () => {
  if (!ws) {
    for (ws = !0; ba.length > 0; ) {
      const e = ba.shift();
      if (e)
        try {
          await e();
        } catch (t) {
          F.error("Error executing queue", t);
        }
    }
    ws = !1;
  }
}, "executeQueue"), YA = /* @__PURE__ */ d(async (e, t) => new Promise((r, i) => {
  const n = /* @__PURE__ */ d(() => new Promise((a, o) => {
    xr.parse(e, t).then(
      (s) => {
        a(s), r(s);
      },
      (s) => {
        var l;
        F.error("Error parsing", s), (l = ee.parseError) == null || l.call(ee, s), o(s), i(s);
      }
    );
  }), "performCall");
  ba.push(n), qm().catch(i);
}), "parse"), Hm = /* @__PURE__ */ d((e, t, r) => new Promise((i, n) => {
  const a = /* @__PURE__ */ d(() => new Promise((o, s) => {
    xr.render(e, t, r).then(
      (l) => {
        o(l), i(l);
      },
      (l) => {
        var c;
        F.error("Error parsing", l), (c = ee.parseError) == null || c.call(ee, l), s(l), n(l);
      }
    );
  }), "performCall");
  ba.push(a), qm().catch(n);
}), "render"), UA = /* @__PURE__ */ d(() => Object.keys(fr).map((e) => ({
  id: e
})), "getRegisteredDiagramsMetadata"), ee = {
  startOnLoad: !0,
  mermaidAPI: xr,
  parse: YA,
  render: Hm,
  init: qA,
  run: Nm,
  registerExternalDiagrams: HA,
  registerLayoutLoaders: Zg,
  initialize: zm,
  parseError: void 0,
  contentLoaded: Wm,
  setParseErrorHandler: jA,
  detectType: vo,
  registerIconPacks: gv,
  getRegisteredDiagramsMetadata: UA
}, GA = ee;
/*! Check if previously processed */
/*!
 * Wait for document loaded before starting the execution
 */
const vL = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: GA
}, Symbol.toStringTag, { value: "Module" }));
export {
  Yh as $,
  Mi as A,
  n0 as B,
  Sy as C,
  ol as D,
  Nt as E,
  Rh as F,
  ik as G,
  n2 as H,
  jl as I,
  hC as J,
  z0 as K,
  Xr as L,
  KA as M,
  Ra as N,
  ay as O,
  So as P,
  ec as Q,
  V1 as R,
  Mn as S,
  rk as T,
  Vi as U,
  py as V,
  Xi as W,
  j as X,
  J as Y,
  Xw as Z,
  d as _,
  by as a,
  Jt as a$,
  Y1 as a0,
  Po as a1,
  iL as a2,
  sL as a3,
  Mr as a4,
  _c as a5,
  Cc as a6,
  lL as a7,
  oL as a8,
  aL as a9,
  jw as aA,
  R_ as aB,
  Iw as aC,
  Qo as aD,
  xh as aE,
  yv as aF,
  U1 as aG,
  ZA as aH,
  rn as aI,
  gv as aJ,
  dv as aK,
  Do as aL,
  qe as aM,
  dc as aN,
  Sb as aO,
  Ii as aP,
  br as aQ,
  Yw as aR,
  Rp as aS,
  $a as aT,
  Oa as aU,
  la as aV,
  Pp as aW,
  Op as aX,
  _w as aY,
  G as aZ,
  kp as a_,
  eL as aa,
  rL as ab,
  hL as ac,
  nL as ad,
  cL as ae,
  qv as af,
  Ug as ag,
  CL as ah,
  fC as ai,
  Lt as aj,
  Ze as ak,
  Zo as al,
  xd as am,
  wr as an,
  jp as ao,
  it as ap,
  ke as aq,
  FS as ar,
  bL as as,
  _L as at,
  yL as au,
  V as av,
  xL as aw,
  gS as ax,
  hS as ay,
  cS as az,
  xy as b,
  xb as b0,
  Fo as b1,
  au as b2,
  Ki as b3,
  lu as b4,
  tL as b5,
  i0 as b6,
  Hw as b7,
  Rw as b8,
  k_ as b9,
  Uw as bA,
  Da as bB,
  vL as bC,
  Jo as ba,
  yw as bb,
  Gw as bc,
  tn as bd,
  ii as be,
  aa as bf,
  Aw as bg,
  rT as bh,
  Ji as bi,
  oa as bj,
  ww as bk,
  Lp as bl,
  T_ as bm,
  B_ as bn,
  nr as bo,
  zc as bp,
  A_ as bq,
  tl as br,
  S_ as bs,
  $_ as bt,
  ni as bu,
  Ve as bv,
  Oc as bw,
  el as bx,
  $p as by,
  bo as bz,
  pt as c,
  ht as d,
  jh as e,
  Bt as f,
  _y as g,
  Pe as h,
  se as i,
  vp as j,
  ei as k,
  F as l,
  Up as m,
  QA as n,
  kL as o,
  wy as p,
  ky as q,
  wL as r,
  Cy as s,
  uC as t,
  pe as u,
  sS as v,
  sk as w,
  uL as x,
  yy as y,
  JA as z
};
