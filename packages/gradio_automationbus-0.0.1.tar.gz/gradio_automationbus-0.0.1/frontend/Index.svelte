<script context="module">
	let _id = 0;
</script>

<script lang="ts">
	import type { Gradio } from "@gradio/utils";
	import { Block, BlockTitle } from "@gradio/atoms";
	import { StatusTracker } from "@gradio/statustracker";
	import type { LoadingStatus } from "@gradio/statustracker";
    import { afterUpdate, onMount } from "svelte";

    type Point = [number, number];

	export let gradio: Gradio<{
		change: never;
		input: never;
        release: any;
		clear_status: LoadingStatus;
	}>;
	export let elem_id = "";
	export let elem_classes: string[] = [];
	export let visible: boolean | "hidden" = true;
    export let value: any = [];
	let initial_value = value;

    export let label = "Automation";
	export let info: string | undefined = undefined;
	export let container = true;
	export let scale: number | null = null;
	export let min_width: number | undefined = undefined;

    // Axis bounds
    export let x_min: number = 0;
    export let x_max: number = 1;
    export let y_min: number = 0;
    export let y_max: number = 1;
    export let shade_enabled: boolean = true;
    export let shade_above_color: string = "rgba(250, 204, 21, 0.25)"; // yellow-400 @ 25%
    export let shade_below_color: string = "rgba(34, 197, 94, 0.25)"; // green-500 @ 25%
    export let top_label: string | null = null;
    export let bottom_label: string | null = null;
	export let show_label: boolean;
	export let interactive: boolean;
	export let loading_status: LoadingStatus;
	export let value_is_output = false;
	export let show_reset_button: boolean;

    const id = `automation_${_id++}`;
    const yMinId = `${id}_ymin`;
    const yMaxId = `${id}_ymax`;

    let canvas: HTMLCanvasElement;
    let ctx: CanvasRenderingContext2D | null = null;
    let width = 0;
    let height = 0;
    let devicePixelRatio = 1;
    let window_width: number = 0;

    let points: Point[] = [];
    let initial_points: Point[] = [];

    // Track props normalization (we now normalize once on mount)

    // Drag state for Command-drag to shift all points vertically
    let isDraggingAll = false;
    let dragStartPy = 0;
    let dragStartPoints: Point[] = [];

    // Hover/selection and single-point dragging
    let hoveredIndex: number | null = null;
    let selectedIndex: number | null = null;
    let isDraggingPoint = false;
    let dragPointIndex: number | null = null;
    const hoverRadiusPx = 6;

    function enforceYBounds(): void {
        if (y_min >= y_max) {
            // maintain a minimal range
            y_max = y_min + 1e-6;
        }
    }

    function clampPointsToY(): void {
        points = points.map(([x, y]) => [x, Math.max(y_min, Math.min(y_max, y))] as Point);
    }

    function normalizeIncomingValue(): void {
        // Value can be either points array or {points, audio_url, x_min, ...}
        if (Array.isArray(value)) {
            points = value as Point[];
        } else if (value && typeof value === "object") {
            if (Array.isArray(value.points)) points = value.points as Point[];
            if (typeof value.x_min === "number") x_min = value.x_min;
            if (typeof value.x_max === "number") x_max = value.x_max;
            if (typeof value.y_min === "number") y_min = value.y_min;
            if (typeof value.y_max === "number") y_max = value.y_max;
            if (typeof value.shade_enabled === "boolean") shade_enabled = value.shade_enabled;
            if (typeof value.shade_above_color === "string") shade_above_color = value.shade_above_color;
            if (typeof value.shade_below_color === "string") shade_below_color = value.shade_below_color;
            if (typeof value.top_label === "string") top_label = value.top_label;
            if (typeof value.bottom_label === "string") bottom_label = value.bottom_label;
        }
        // Sort and unique by x
        points = sortUniqueByX(points);
        // Ensure baseline if empty
        ensureBaseline();
        initial_points = points.map((p) => [p[0], p[1]] as Point);
    }

    function sortUniqueByX(arr: Point[]): Point[] {
        const map = new Map<number, number>();
        for (const [x, y] of arr) map.set(x, y);
        return Array.from(map.entries())
            .sort((a, b) => a[0] - b[0])
            .map(([x, y]) => [x, y]);
    }

	function handle_change(): void {
		gradio.dispatch("change");
		if (!value_is_output) {
			gradio.dispatch("input");
		}
	}

    function handle_release(): void {
        value_is_output = true;
        // sync component value so event inputs receive the latest points
        value = points;
        gradio.dispatch("release", points);
    }

	function handle_resize(): void {
		window_width = window.innerWidth;
        resizeCanvas();
        draw();
	}

	function reset_value(): void {
		points = [];
		ensureBaseline();
		draw();
		gradio.dispatch("change");
		handle_release();
	}

    function resizeCanvas(): void {
        if (!canvas) return;
        const rect = canvas.getBoundingClientRect();
        devicePixelRatio = window.devicePixelRatio || 1;
        width = Math.max(1, Math.floor(rect.width));
        height = Math.max(120, Math.floor(rect.height));
        canvas.width = Math.floor(width * devicePixelRatio);
        canvas.height = Math.floor(height * devicePixelRatio);
        if (!ctx) ctx = canvas.getContext("2d");
        if (ctx) ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
    }

    function toPxX(x: number): number {
        const span = x_max - x_min || 1;
        return ((x - x_min) / span) * width;
    }
    function toPxY(y: number): number {
        const span = y_max - y_min || 1;
        return height - ((y - y_min) / span) * height;
    }
    function fromPxX(px: number): number {
        const span = x_max - x_min || 1;
        return x_min + (px / width) * span;
    }
    function fromPxY(py: number): number {
        const span = y_max - y_min || 1;
        return y_min + ((height - py) / height) * span;
    }

    function drawGrid(): void {
        if (!ctx) return;
        ctx.clearRect(0, 0, width, height);
        ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue(
            "--background-fill-primary"
        ).trim() || "#ffffff";
        ctx.fillRect(0, 0, width, height);

        ctx.strokeStyle = "#e5e7eb"; // neutral-200
        ctx.lineWidth = 1;
        const numLines = 8;
        for (let i = 1; i < numLines; i++) {
            const y = (i / numLines) * height;
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(width, y);
            ctx.stroke();
        }

        // Draw top/bottom labels if provided
        ctx.fillStyle = "#374151"; // neutral-700
        ctx.font = "12px system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial";
        ctx.textBaseline = "top";
        if (top_label) {
            ctx.fillText(top_label, 8, 6);
        }
        if (bottom_label) {
            ctx.textBaseline = "bottom";
            ctx.fillText(bottom_label, 8, height - 6);
        }
    }

    // Waveform removed for now

    function drawShading(): void {
        if (!ctx) return;
        if (!(shade_enabled && points.length >= 2)) return;
        ctx.save();
        // Above
        ctx.beginPath();
        ctx.moveTo(0, 0);
        for (let i = 0; i < points.length; i++) {
            const [x, y] = points[i];
            const px = toPxX(x);
            const py = toPxY(y);
            if (i === 0) ctx.lineTo(px, 0);
            ctx.lineTo(px, py);
        }
        ctx.lineTo(width, 0);
        ctx.closePath();
        ctx.fillStyle = shade_above_color;
        ctx.fill();

        // Below
        ctx.beginPath();
        ctx.moveTo(0, height);
        for (let i = 0; i < points.length; i++) {
            const [x, y] = points[i];
            const px = toPxX(x);
            const py = toPxY(y);
            if (i === 0) ctx.lineTo(px, height);
            ctx.lineTo(px, py);
        }
        ctx.lineTo(width, height);
        ctx.closePath();
        ctx.fillStyle = shade_below_color;
        ctx.fill();
        ctx.restore();
    }

    function drawPoints(): void {
        if (!ctx) return;
        // Lines
        ctx.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue(
            "--slider-color"
        ).trim() || "#4f46e5";
        ctx.lineWidth = 2;
        ctx.beginPath();
        for (let i = 0; i < points.length; i++) {
            const [x, y] = points[i];
            const px = toPxX(x);
            const py = toPxY(y);
            if (i === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
        }
        ctx.stroke();

        // Points
        ctx.fillStyle = "#111827"; // neutral-900
        for (let i = 0; i < points.length; i++) {
            const [x, y] = points[i];
            const px = toPxX(x);
            const py = toPxY(y);
            ctx.beginPath();
            ctx.arc(px, py, 3, 0, Math.PI * 2);
            ctx.fill();
			// Label the y value near the point
			const label = (Math.round(y * 100) / 100).toFixed(2);
			ctx.font = "11px system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial";
			ctx.fillStyle = "#374151"; // neutral-700
			ctx.textBaseline = "bottom";
			ctx.fillText(label, px + 6, py - 4);
            // Outlines for hover/selected
            if (selectedIndex === i || hoveredIndex === i) {
                ctx.beginPath();
                ctx.arc(px, py, 6, 0, Math.PI * 2);
                ctx.lineWidth = 2;
                ctx.strokeStyle = selectedIndex === i ? "#ffffff" : "#9ca3af"; // white or neutral-400
                ctx.stroke();
            }
        }
    }

    function draw(): void {
        if (!canvas) return;
        drawGrid();
        // Draw shading only
        drawShading();
        drawPoints();
    }

    function ensureBaseline(): void {
        if (!Array.isArray(points) || points.length === 0) {
            const midY = y_min + (y_max - y_min) * 0.5;
            points = [
                [x_min, midY],
                [x_max, midY]
            ];
        }
    }

    function onPointerDown(e: PointerEvent): void {
        if (interactive === false) return;
        const rect = canvas.getBoundingClientRect();
        const px = e.clientX - rect.left;
        const py = e.clientY - rect.top;
        if (e.metaKey) {
            isDraggingAll = true;
            dragStartPy = py;
            dragStartPoints = points.map((p) => [p[0], p[1]] as Point);
            try { canvas.setPointerCapture(e.pointerId); } catch {}
            return;
        }
        // Check if clicking near an existing point to start dragging
        const hitIndex = findPointNear(px, py, hoverRadiusPx);
        if (hitIndex !== null) {
            selectedIndex = hitIndex;
            hoveredIndex = hitIndex;
            isDraggingPoint = true;
            dragPointIndex = hitIndex;
            try { canvas.setPointerCapture(e.pointerId); } catch {}
            draw();
            return;
        }
        // Otherwise, add/replace at x position
        const x = fromPxX(px);
        const y = fromPxY(py);
        const xpx = toPxX(x);
        const epsilon = 4; // px
        let replaced = false;
        for (let i = 0; i < points.length; i++) {
            const ppx = toPxX(points[i][0]);
            if (Math.abs(ppx - xpx) <= epsilon) {
                points[i] = [x, Math.max(y_min, Math.min(y_max, y))];
                replaced = true;
                selectedIndex = i;
                break;
            }
        }
        if (!replaced) {
            points.push([x, Math.max(y_min, Math.min(y_max, y))]);
            points = sortUniqueByX(points);
            // set selection to the inserted index
            selectedIndex = points.findIndex((p) => p[0] === x);
        } else {
            points = sortUniqueByX(points);
            selectedIndex = points.findIndex((p) => p[0] === x);
        }
        draw();
    }

    function onPointerMove(e: PointerEvent): void {
        if (interactive === false) return;
        const rect = canvas.getBoundingClientRect();
        const px = e.clientX - rect.left;
        const py = e.clientY - rect.top;
        if (isDraggingAll) {
            const deltaPy = py - dragStartPy;
            if (height <= 0) return;
            const dy = (-(deltaPy) / height) * (y_max - y_min);
            points = dragStartPoints.map(([x, y]) => {
                const ny = Math.max(y_min, Math.min(y_max, y + dy));
                return [x, ny] as Point;
            });
            draw();
            return;
        }
        if (isDraggingPoint && dragPointIndex !== null && selectedIndex !== null) {
            const x = fromPxX(px);
            const y = fromPxY(py);
            // Constrain x between neighbors to maintain order and uniqueness
            const prevX = selectedIndex > 0 ? points[selectedIndex - 1][0] : x_min;
            const nextX = selectedIndex < points.length - 1 ? points[selectedIndex + 1][0] : x_max;
            const minX = prevX + 1e-6;
            const maxX = nextX - 1e-6;
            const cx = Math.max(x_min, Math.min(x_max, Math.max(minX, Math.min(maxX, x))));
            const cy = Math.max(y_min, Math.min(y_max, y));
            points[selectedIndex] = [cx, cy];
            draw();
            return;
        }
        // Hover detection when not dragging
        hoveredIndex = findPointNear(px, py, hoverRadiusPx);
        draw();
    }

    function onPointerUp(e: PointerEvent): void {
        if (isDraggingAll) {
            isDraggingAll = false;
            dragStartPoints = [];
        }
        if (isDraggingPoint) {
            isDraggingPoint = false;
            dragPointIndex = null;
        }
        handle_release();
        try { canvas.releasePointerCapture(e.pointerId); } catch {}
    }

    function findPointNear(px: number, py: number, radius: number): number | null {
        const r2 = radius * radius;
        let hit: number | null = null;
        for (let i = 0; i < points.length; i++) {
            const [x, y] = points[i];
            const dx = toPxX(x) - px;
            const dy = toPxY(y) - py;
            if (dx * dx + dy * dy <= r2) {
                hit = i;
                break;
            }
        }
        return hit;
    }

    // Reactivity
    $: disabled = interactive === false;
    // When y bounds change, enforce validity, clamp points, and redraw
    $: {
        enforceYBounds();
        clampPointsToY();
        draw();
    }
    // Keep component's value in sync with points so events carry the latest data
    // Avoid forcing value on every change; we only send points via release/input events
    // $: value = points;
    $: points, handle_change();

    // Waveform reactive logic removed

    onMount(() => {
        normalizeIncomingValue();
        resizeCanvas();
        draw();
        const ro = new ResizeObserver(() => {
            resizeCanvas();
            draw();
        });
        ro.observe(canvas);
        window.addEventListener("resize", handle_resize);
        return () => {
            ro.disconnect();
            window.removeEventListener("resize", handle_resize);
        };
    });

    afterUpdate(() => {
        value_is_output = false;
        draw();
    });
</script>

<svelte:window on:resize={handle_resize} on:keydown={(e) => {
    if (!interactive) return;
    if ((e.key === 'Backspace' || e.key === 'Delete') && selectedIndex !== null) {
        // Keep at least baseline of two endpoints
        if (points.length <= 2) return;
        points.splice(selectedIndex, 1);
        selectedIndex = null;
        hoveredIndex = null;
        draw();
        handle_release();
    }
}} />

<Block {visible} {elem_id} {elem_classes} {container} {scale} {min_width}>
	<StatusTracker
		autoscroll={gradio.autoscroll}
		i18n={gradio.i18n}
		{...loading_status}
		on:clear_status={() => gradio.dispatch("clear_status", loading_status)}
	/>

	<div class="wrap">
		<div class="head">
			<label for={id}>
				<BlockTitle {show_label} {info}>{label}</BlockTitle>
			</label>
			<div class="tab-like-container">
				{#if show_reset_button}
					<button
						class="reset-button"
						on:click={reset_value}
						{disabled}
						aria-label="Reset to default value"
						data-testid="reset-button"
					>
						↺
					</button>
				{/if}
			</div>
		</div>

        <div class="bounds_row">
            <div class="bounds_group">
                <label class="bounds_label" for={yMinId}>Y min</label>
                <input id={yMinId} type="number" bind:value={y_min} class="bounds_input" />
            </div>
            <div class="bounds_group">
                <label class="bounds_label" for={yMaxId}>Y max</label>
                <input id={yMaxId} type="number" bind:value={y_max} class="bounds_input" />
            </div>
        </div>

        <div class="lane_container">
            <canvas
                bind:this={canvas}
                class="lane"
                on:pointerdown={onPointerDown}
                on:pointermove={onPointerMove}
                on:pointerup={onPointerUp}
                on:mouseleave={() => { if (!isDraggingAll && !isDraggingPoint) { hoveredIndex = null; draw(); } }}
            ></canvas>
		</div>
	</div>
</Block>

<style>
	.wrap {
		display: flex;
		flex-direction: column;
		width: 100%;
	}

	.head {
		margin-bottom: var(--size-2);
		display: flex;
		justify-content: space-between;
		align-items: flex-start;
		flex-wrap: wrap;
		width: 100%;
	}

	.head > label {
		flex: 1;
	}

	.head > .tab-like-container {
		margin-left: auto;
		order: 1;
	}

    .lane_container {
        display: block;
		width: 100%;
        height: 200px;
    }

    .bounds_row {
        display: flex;
        gap: var(--size-2);
        margin-bottom: var(--size-2);
        align-items: center;
        flex-wrap: wrap;
    }
    .bounds_group {
        display: flex;
        gap: var(--size-1);
        align-items: center;
    }
    .bounds_label {
        color: var(--body-text-color-subdued);
        font-size: var(--text-sm);
    }
    .bounds_input {
		outline: none;
		border: 1px solid var(--input-border-color);
		border-radius: var(--radius-sm);
		background: var(--input-background-fill);
        padding: var(--size-1) var(--size-2);
        height: var(--size-6);
		color: var(--body-text-color);
		font-size: var(--text-sm);
        width: 6rem;
    }

    .lane {
		width: 100%;
        height: 100%;
        display: block;
		background: transparent;
        border-radius: var(--radius-md);
        box-shadow: inset 0 0 0 1px var(--input-border-color);
        cursor: crosshair;
	}

	@media (max-width: 520px) {
		.head {
			gap: var(--size-3);
		}
	}

	@media (max-width: 420px) {
		.head .tab-like-container {
			margin-bottom: var(--size-4);
		}
	}

	.tab-like-container {
		display: flex;
		align-items: stretch;
		border: 1px solid var(--input-border-color);
		border-radius: var(--radius-sm);
		overflow: hidden;
		height: var(--size-6);
	}

	.reset-button {
		display: flex;
		align-items: center;
		justify-content: center;
		background: none;
		border: none;
		border-left: 1px solid var(--input-border-color);
		cursor: pointer;
		font-size: var(--text-sm);
		color: var(--body-text-color);
		padding: 0 var(--size-2);
		min-width: var(--size-6);
		transition: background-color 0.15s ease-in-out;
	}

	.reset-button:hover:not(:disabled) {
		background-color: var(--background-fill-secondary);
	}

	.reset-button:disabled {
		opacity: 0.5;
		cursor: not-allowed;
	}
</style>
