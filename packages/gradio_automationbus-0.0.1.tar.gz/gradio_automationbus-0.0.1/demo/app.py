
import gradio as gr
from gradio_automationbus import AutomationBus


def passthrough(points):
    return points


with gr.Blocks() as demo:
    gr.Markdown("## Automation Lane Demo")
    with gr.Row():
        audio = gr.Audio(label="Audio", sources=["upload", "microphone"], type="filepath")
    with gr.Row():
        lane = AutomationBus(
            label="Automation",
            x_min=0.0,
            x_max=1.0,
            y_min=0.0,
            y_max=1.0,
            top_label="prompt a",
            bottom_label="prompt b",
        )

    # Remove waveform linkage for now

    # Echo points on release
    out = gr.JSON(label="Current Points")
    lane.release(fn=passthrough, inputs=lane, outputs=out)


if __name__ == "__main__":
    demo.launch(share=True)
