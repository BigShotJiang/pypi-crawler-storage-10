from . import audio, text, vision  # noqa: F401
from .registry import ModalityRegistry as ModalityRegistry
