class InvalidJsonResponseException(Exception):
    pass
