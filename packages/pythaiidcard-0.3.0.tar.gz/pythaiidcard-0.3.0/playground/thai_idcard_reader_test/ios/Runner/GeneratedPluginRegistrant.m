//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<ccid/CcidPlugin.h>)
#import <ccid/CcidPlugin.h>
#else
@import ccid;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [CcidPlugin registerWithRegistrar:[registry registrarForPlugin:@"CcidPlugin"]];
}

@end
