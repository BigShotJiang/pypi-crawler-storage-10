package com.example.thai_idcard_reader_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
