"""Tests for pythaiidcard library."""
