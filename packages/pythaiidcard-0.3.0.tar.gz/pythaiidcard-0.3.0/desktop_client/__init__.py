"""Desktop client package for Thai ID Card Reader."""

__version__ = "1.0.0"
