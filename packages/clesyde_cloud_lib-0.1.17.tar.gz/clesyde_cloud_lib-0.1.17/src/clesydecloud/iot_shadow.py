from __future__ import annotations
import logging
from typing import TYPE_CHECKING

from typing import Optional
from dataclasses import dataclass
from dataclasses_json import dataclass_json, LetterCase, Undefined

_LOGGER = logging.getLogger(__name__)

if TYPE_CHECKING:
    from clesydecloud import ClesydeCloud, _ClientT

@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.EXCLUDE, )
@dataclass(frozen=True)
class ShadowContent:
    remote_cert_sn: Optional[str] = None

    def extract_existing_keys(self):
        return [key for key in self.__dict__ if self.__dict__[key] is not None]


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.EXCLUDE)
@dataclass(frozen=True)
class IotShadowGet:
    desired: ShadowContent
    delta: ShadowContent


class ProvisioningError(Exception):
    """Exception raised for errors in the provisioning process."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(self.message)


class ShadowManager:
    """Helper class to manage shadow scheduling."""

    def __init__(self, cloud: ClesydeCloud[_ClientT]) -> None:
        """Init the shadow."""
        self.cloud = cloud
        self.cloud.iot.register_on_connect(self.on_iot_connected)

    async def on_iot_connected(self):
        self.request_shadow_config()

    def request_shadow_config(self):
        config_shadow_topic = f"$aws/things/{self.cloud.client.device_sn}/shadow/name/config/get"
        _LOGGER.info(f"ShadowManager: Sending shadow get request to {config_shadow_topic}")
        self.cloud.iot.publish(config_shadow_topic,"", 0, False)

