# Model36EnumsEnvironment


## Enum

* `PRODUCTION` (value: `'production'`)

* `SANDBOX` (value: `'sandbox'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


