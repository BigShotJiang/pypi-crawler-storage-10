#cython: language_level=3

from pippi.soundbuffer cimport SoundBuffer

cdef extern from "pippicore.h":
    cdef enum Windows:
        WIN_NONE,
        WIN_SINE,
        WIN_SINEIN,
        WIN_SINEOUT,
        WIN_COS,
        WIN_TRI, 
        WIN_PHASOR, 
        WIN_HANN, 
        WIN_HANNIN, 
        WIN_HANNOUT, 
        WIN_RND,
        WIN_SAW,
        WIN_RSAW,
        WIN_USER,
        NUM_WINDOWS

    ctypedef double lpfloat_t

    ctypedef struct lpbuffer_t:
        size_t length
        int samplerate
        int channels
        lpfloat_t phase
        size_t boundry
        size_t range
        size_t pos
        size_t onset
        int is_looping
        lpfloat_t data[]

    ctypedef struct lpbuffer_factory_t:
        lpbuffer_t * (*create)(size_t, int, int)
        void (*copy)(lpbuffer_t *, lpbuffer_t *)
        lpfloat_t (*min)(lpbuffer_t * buf)
        lpfloat_t (*max)(lpbuffer_t * buf)
        lpfloat_t (*mag)(lpbuffer_t * buf)
        lpfloat_t (*avg)(lpbuffer_t * buf)
        void (*destroy)(lpbuffer_t *)

    ctypedef struct lpwindow_factory_t:
        lpbuffer_t * (*create)(int name, size_t length)
        void (*destroy)(lpbuffer_t*)

    ctypedef struct lpinterpolation_factory_t:
        lpfloat_t (*linear_pos)(lpbuffer_t *, lpfloat_t);
        lpfloat_t (*linear_pos2)(lpfloat_t *, size_t, lpfloat_t);
        lpfloat_t (*linear)(lpbuffer_t *, lpfloat_t);
        lpfloat_t (*linear_channel)(lpbuffer_t *, lpfloat_t, int);
        lpfloat_t (*hermite_pos)(lpbuffer_t *, lpfloat_t);
        lpfloat_t (*hermite)(lpbuffer_t *, lpfloat_t);

    extern const lpbuffer_factory_t LPBuffer
    extern const lpwindow_factory_t LPWindow
    extern const lpinterpolation_factory_t LPInterpolation

cdef extern from "oscs.shape.h":
    ctypedef struct lpshapeosc_t:
        lpbuffer_t * wt;
        lpfloat_t density;
        lpfloat_t periodicity;
        lpfloat_t stability;
        lpfloat_t phase;
        lpfloat_t freq;
        lpfloat_t minfreq;
        lpfloat_t maxfreq;
        lpfloat_t samplerate;

        lpfloat_t wtmin;
        lpfloat_t wtmax;
        lpfloat_t min;
        lpfloat_t max;

    ctypedef struct lpmultishapeosc_t:
        int numshapeosc;
        lpshapeosc_t ** shapeosc;
        lpfloat_t density;
        lpfloat_t periodicity;
        lpfloat_t stability;
        lpfloat_t minfreq;
        lpfloat_t maxfreq;
        lpfloat_t samplerate;
        lpfloat_t min;
        lpfloat_t max;

    ctypedef struct lpshapeosc_factory_t:
        lpshapeosc_t * (*create)(lpbuffer_t * wt);
        lpmultishapeosc_t * (*multi)(int numshapeosc, ...);
        lpfloat_t (*process)(lpshapeosc_t * s);
        lpfloat_t (*multiprocess)(lpmultishapeosc_t * m);
        void (*destroy)(lpshapeosc_t * s);
        void (*multidestroy)(lpmultishapeosc_t * m);

    extern const lpshapeosc_factory_t LPShapeOsc


#cpdef list onsets(double length, object density, object periodicity, object stability, double minfreq, double maxfreq)
cpdef SoundBuffer synth(object wt, double length=*, object density=*, object periodicity=*, object stability=*, double minfreq=*, double maxfreq=*, int samplerate=*, int channels=*)
#cdef double[:] _table(double[:] out, unsigned int length, double[:] wt, double[:] density, double[:] periodicity, double[:] stability, double[:] maxfreq, double[:] minfreq, int samplerate)
cpdef SoundBuffer win(object waveform, double lowvalue=*, double highvalue=*, double length=*, object density=*, object periodicity=*, object stability=*, object minfreq=*, object maxfreq=*, int samplerate=*)
cpdef SoundBuffer wt(object waveform, double lowvalue=*, double highvalue=*, double length=*, object density=*, object periodicity=*, object stability=*, object minfreq=*, object maxfreq=*, int samplerate=*)

