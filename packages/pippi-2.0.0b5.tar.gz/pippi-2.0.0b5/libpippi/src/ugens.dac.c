#include "ugens.dac.h"

lpfloat_t lpugen_dac_process(ugen_t * u) {
    if (u == NULL || u->type != UGEN_DAC) return 0.0f;
    
    // Get current parameter values
    lpfloat_t input = lpugen_get_param(u, UPARAM_A);  // Using UPARAM_A as the input parameter
    lpfloat_t gain = lpugen_get_param(u, UPARAM_GAIN);
    
    // Apply gain to input signal
    lpfloat_t output = input * gain;
    
    // Store for output retrieval
    u->params.dac.input_sample = output;
    
    // Update additional outputs
    u->outputs[0] = output;                           // Output signal
    u->outputs[1] = gain;                             // Current gain
    u->outputs[2] = (lpfloat_t)u->params.dac.channel; // Channel number
    
    return output;
}

lpfloat_t lpugen_dac_get_output_sample(ugen_t * u, int channel) {
    if (u != NULL && u->type == UGEN_DAC && u->params.dac.channel == channel) {
        return u->params.dac.input_sample;
    }
    return 0.0f;
}