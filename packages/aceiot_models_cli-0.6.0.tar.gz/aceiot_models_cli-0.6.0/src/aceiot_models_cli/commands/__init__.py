"""Dynamic command management system for aceiot-models-cli."""

# NOTE: Imports removed from __init__.py to avoid circular dependency issues
# when cli.py tries to import bridge_v2. Import directly from submodules instead:
#   from aceiot_models_cli.commands.base import BaseCommand
#   from aceiot_models_cli.commands.decorators import command

__all__ = [
    "BaseCommand",
    "ContextAwareCommand",
    "CommandRegistry",
    "command",
    "context_command",
    "repl_command",
]
