# celine-utils

Utilities library used in CELINE project