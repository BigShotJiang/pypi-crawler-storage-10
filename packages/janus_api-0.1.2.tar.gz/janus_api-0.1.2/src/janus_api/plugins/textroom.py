from .base import PluginBase, PluginRegistry


@PluginRegistry.register(name="textroom")
class TextRoomPlugin(PluginBase):

    async def create(self):
        ...

    async def list(self):
        ...

    async def setup(self):
        ...