BUS_NAME = "org.freedesktop.portal.Desktop"
OBJECT_PATH = "/org/freedesktop/portal/desktop"
REGISTRY_IFACE = "org.freedesktop.host.portal.Registry"
REQUEST_IFACE = "org.freedesktop.portal.Request"
SHORTCUT_IFACE = "org.freedesktop.portal.GlobalShortcuts"


HANDLE_TOKEN = "PySide6_GlobalHotkeys_Handle"
SESSION_HANDLE_TOKEN = "PySide6_GlobalHotkeys_Session_Handle"
