import os
import json

class Lab:
    def __init__(self):
        self.tasks = self._load_tasks()

    def _load_tasks(self):
        data_path = os.path.join(os.path.dirname(__file__), 'data', 'tasks.json')
        with open(data_path, 'r', encoding='utf-8') as f:
            return json.load(f)

    def getlab(self, n):
        lab_data = self.tasks.get(str(n))
        if lab_data is None:
            return "Задание не найдено"
        
        # Форматируем вывод лабораторной работы
        return self._format_lab(lab_data)
    
    def _format_lab(self, lab_data):
        """Форматирует данные лабораторной работы в читаемый текст"""
        result = []
        
        # Заголовок
        result.append(f"Лабораторная работа {lab_data['lab_number']}. {lab_data['title']}")
        result.append("=" * 60)
        
        # Цель работы
        result.append(f"ЦЕЛЬ РАБОТЫ: {lab_data['goal']}")
        result.append("")
        
        # Теоретическая часть
        if lab_data.get('theory'):
            result.append("ТЕОРЕТИЧЕСКАЯ ЧАСТЬ:")
            for theory_item in lab_data['theory']:
                result.append(f"  {theory_item['topic']}:")
                for item in theory_item['content']:
                    result.append(f"    • {item}")
            result.append("")
        
        # Практические задания
        if lab_data.get('tasks'):
            result.append("ПРАКТИЧЕСКИЕ ЗАДАНИЯ:")
            for task in lab_data['tasks']:
                result.append(f"  Задание {task['task_number']}. {task['title']}")
                result.append(f"    Цель: {task['goal']}")
                result.append("")
                
                # Примеры кода
                if task.get('code_examples'):
                    result.append("    Примеры кода:")
                    for example in task['code_examples']:
                        result.append(f"      {example['description']}:")
                        # Добавляем код с отступами
                        code_lines = example['code'].split('\n')
                        for line in code_lines:
                            result.append(f"        {line}")
                        result.append("")
                
                # Задачи для самостоятельного решения
                if task.get('problems'):
                    result.append("    Задачи для решения:")
                    for i, problem in enumerate(task['problems'], 1):
                        result.append(f"      {i}. {problem}")
                    result.append("")
            
            result.append("")
        
        # Контрольные вопросы
        if lab_data.get('control_questions'):
            result.append("КОНТРОЛЬНЫЕ ВОПРОСЫ:")
            for i, question in enumerate(lab_data['control_questions'], 1):
                result.append(f"  {i}. {question}")
        
        return "\n".join(result)
    
    def list_labs(self):
        """Возвращает список всех доступных лабораторных работ"""
        return list(self.tasks.keys())
    
    def get_lab_info(self, n):
        """Возвращает основную информацию о лабораторной работе"""
        lab_data = self.tasks.get(str(n))
        if lab_data is None:
            return None
        
        return {
            'number': lab_data['lab_number'],
            'title': lab_data['title'],
            'goal': lab_data['goal'],
            'task_count': len(lab_data.get('tasks', [])),
            'question_count': len(lab_data.get('control_questions', []))
        }