from sqlite3 import Connection
from typing_extensions import Self

class Cursor:
	def __init__(self, connection: Connection):
		self.connection = connection
		self.cursor = connection.cursor()
	
	def execute(self, command: str, *values: list[any]) -> Self:
		self.cursor.execute(command, tuple(values))
		return self

	def field(self, command: str, *values: list[any]) -> any:
		fetch = self.cursor.execute(command, tuple(values)).fetchone()
		return fetch[0] if fetch else None

	def column(self, command: str, *values: list[any]) -> list[any]:
		fetch = self.cursor.execute(command, tuple(values)).fetchall()
		return [row[0] for row in fetch]

	def row(self, command: str, *values: list[any]) -> tuple[any]:
		fetch = self.cursor.execute(command, tuple(values)).fetchone()
		return fetch

	def rows(self, command: str, *values: list[any]) -> list[tuple[any, ...]]:
		fetch = self.cursor.execute(command, tuple(values)).fetchall()
		return fetch

	def commit(self) -> Connection:
		self.connection.commit()

		return self.connection

	def finish(self) -> Connection:
		self.connection.commit()
		self.connection.close()

		return self.connection