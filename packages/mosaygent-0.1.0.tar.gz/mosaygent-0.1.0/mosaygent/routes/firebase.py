import json
import re
from pathlib import Path

import firebase_admin
from fastapi import APIRouter, HTTPException
from firebase_admin import auth, credentials
from pydantic import BaseModel, Field

from mosaygent.command_runner import run_command, run_command_streaming
from mosaygent.logger import get_logger
from mosaygent.services.environment import EnvironmentService

logger = get_logger(__name__)

router = APIRouter(
    prefix='/firebase',
    tags=['Firebase Routes'],
)

env_service = EnvironmentService()


@router.get("/cli-installed")
async def check_cli_installed() -> dict:
    """Check if Firebase CLI and Google Cloud CLI are installed."""
    logger.info("Checking if Firebase CLI and gcloud CLI are installed")

    # Check Firebase CLI
    firebase_result = await run_command(
        ["firebase", "--version"],
        timeout=5,
        raise_on_error=False
    )

    firebase_installed = firebase_result.success
    firebase_version = firebase_result.stdout.strip() if firebase_installed else None

    if firebase_installed:
        logger.info(f"Firebase CLI is installed: {firebase_version}")
    else:
        logger.warning("Firebase CLI is not installed")

    # Check gcloud CLI
    gcloud_result = await run_command(
        ["gcloud", "version"],
        timeout=5,
        raise_on_error=False
    )

    gcloud_installed = gcloud_result.success
    gcloud_version = None
    if gcloud_installed:
        version_output = gcloud_result.stdout.strip()
        # Extract main gcloud version from output like "Google Cloud SDK 123.0.0"
        version_match = re.search(r'Google Cloud SDK (\S+)', version_output)
        gcloud_version = version_match.group(1) if version_match else version_output.split('\n')[0]
        logger.info(f"gcloud CLI is installed: {gcloud_version}")
    else:
        logger.warning("gcloud CLI is not installed")

    return {
        "firebase": {
            "installed": firebase_installed,
            "version": firebase_version,
        },
        "gcloud": {
            "installed": gcloud_installed,
            "version": gcloud_version,
        }
    }


@router.get("/auth-status")
async def check_firebase_auth_status() -> dict:
    """Check Firebase CLI authentication status."""
    logger.info("Checking Firebase auth status")

    result = await run_command(
        ["firebase", "login:list"],
        timeout=10,
        raise_on_error=False
    )

    if result.success:
        output = result.stdout.strip()

        if "no authorized accounts" in output.lower() or not output:
            logger.warning("No Firebase accounts are logged in")
            return {
                "logged_in": False,
                "message": "Run 'firebase login' to authenticate",
            }

        logger.info("User is logged in to Firebase CLI")
        return {
            "logged_in": True,
            "output": output,
        }

    logger.warning("Failed to check Firebase auth status")
    return {
        "logged_in": False,
        "message": "Run 'firebase login' to authenticate",
    }


@router.post("/install-cli")
async def install_firebase_cli() -> dict:
    """Attempt to install Firebase CLI using npm."""
    logger.info("Attempting to install Firebase CLI via npm")

    npm_check = await run_command(
        ["npm", "--version"],
        timeout=5,
        raise_on_error=False
    )

    if not npm_check.success:
        logger.error("npm is not installed")
        raise HTTPException(
            status_code=500,
            detail="npm is required to install Firebase CLI. Please install Node.js and npm first."
        )

    logger.info(f"npm is available: {npm_check.stdout.strip()}")

    try:
        logger.info("Installing firebase-tools globally via npm")
        result = run_command_streaming(
            ["npm", "install", "-g", "firebase-tools"],
            timeout=300,
        )

        logger.info("Successfully installed Firebase CLI via npm")
        return {
            "installed": True,
            "method": "npm",
            "output": result.stdout.strip(),
        }
    except Exception as e:
        logger.error(f"npm install failed: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Installation failed: {str(e)}"
        )


@router.get("/login-instructions")
async def get_firebase_login_instructions() -> dict:
    """Get instructions for logging into Firebase CLI."""
    logger.info("Returning Firebase login instructions")

    return {
        "instructions": [
            "Open a terminal window",
            "Run the command: firebase login",
            "Follow the prompts to authenticate with your Google account",
            "Once logged in, return here to continue"
        ],
        "command": "firebase login",
        "note": "Make sure Firebase CLI is installed before running this command"
    }


class DeployRequest(BaseModel):
    """Request model for Firebase deployment."""
    project_id: str = Field(min_length=1, description="Firebase project ID")
    repo_path: str | None = Field(default=None, description="Optional repository path (defaults to configured project directory)")


@router.post("/deploy")
async def deploy_firebase(request: DeployRequest) -> dict:
    """Deploy Firebase project (assumes firebase.json exists in repo_path/firebase/)."""
    logger.info(f"Starting Firebase deployment for project: {request.project_id}")

    if request.repo_path:
        repo_path = Path(request.repo_path)
        logger.info(f"Using provided repo path: {repo_path}")
    elif env_service.project_dir:
        repo_path = env_service.project_dir
        logger.info(f"Using configured project directory: {repo_path}")
    else:
        logger.error("No repository path provided and project directory not configured")
        raise HTTPException(
            status_code=500,
            detail="No repo_path provided and project directory not configured"
        )

    firebase_dir = repo_path / "firebase"

    if not firebase_dir.exists():
        logger.error(f"Firebase directory not found: {firebase_dir}")
        raise HTTPException(
            status_code=404,
            detail=f"Firebase directory not found at {firebase_dir}."
        )

    firebase_json = firebase_dir / "firebase.json"
    if not firebase_json.exists():
        logger.error(f"firebase.json not found: {firebase_json}")
        raise HTTPException(
            status_code=404,
            detail=f"firebase.json not found at {firebase_json}"
        )

    logger.info(f"Found firebase.json at {firebase_json}")

    try:
        logger.info(f"Running firebase deploy --project {request.project_id}")
        result = run_command_streaming(
            ["firebase", "deploy", "--project", request.project_id],
            timeout=600,
            cwd=str(firebase_dir)
        )

        logger.info("Firebase deployment completed successfully")
        return {
            "success": True,
            "project_id": request.project_id,
            "firebase_dir": str(firebase_dir),
            "output": result.stdout.strip(),
        }
    except Exception as e:
        logger.exception(f"Firebase deployment failed: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Deployment failed: {str(e)}"
        )


class SetProjectRequest(BaseModel):
    """Request to set Firebase/GCloud project."""

    project_id: str = Field(min_length=1, description="GCloud project ID")


class FetchFirebaseConfigsRequest(BaseModel):
    """Request to fetch Firebase config files (Android, iOS, and Web)."""

    project_id: str = Field(min_length=1, description="Firebase project ID")
    flutter_app_path: str = Field(min_length=1, description="Path to Flutter app root")
    bundle_id: str = Field(min_length=1, description="Bundle ID used by all platforms (e.g., com.company.appname)")
    firebase_config_path: str | None = Field(
        default=None,
        description="Optional path to firebase_config.dart. Defaults to {flutter_app_path}/lib/backend/firebase/firebase_config.dart"
    )


async def _get_android_app_id(project_id: str, bundle_id: str) -> str:
    """Get Firebase Android app ID from bundle ID."""
    logger.info(f"Looking up Android app with bundle ID {bundle_id} in project {project_id}")

    result = await run_command(
        ["firebase", "apps:list", "--project", project_id, "--json"],
        timeout=30
    )

    try:
        apps_data = json.loads(result.stdout)
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse Firebase apps list: {e}")
        raise HTTPException(status_code=500, detail="Failed to parse Firebase apps list")

    if not apps_data or "result" not in apps_data:
        logger.error("No apps found in Firebase project")
        raise HTTPException(status_code=404, detail="No apps found in Firebase project")

    android_apps = [
        app for app in apps_data["result"]
        if app.get("platform") == "ANDROID" and app.get("appId")
    ]

    if not android_apps:
        logger.error("No Android apps found in Firebase project")
        raise HTTPException(status_code=404, detail="No Android apps found in project")

    matching_app = next(
        (app for app in android_apps if app.get("namespace") == bundle_id),
        None
    )

    if not matching_app:
        logger.error(f"No Android app found with bundle ID {bundle_id}")
        available_bundles = [app.get("namespace") for app in android_apps]
        raise HTTPException(
            status_code=404,
            detail=f"No Android app found with bundle ID {bundle_id}. Available: {available_bundles}"
        )

    app_id = matching_app["appId"]
    logger.info(f"Found Android app ID: {app_id}")
    return app_id


async def _get_ios_app_id(project_id: str, bundle_id: str) -> str:
    """Get Firebase iOS app ID from bundle ID."""
    logger.info(f"Looking up iOS app with bundle ID {bundle_id} in project {project_id}")

    result = await run_command(
        ["firebase", "apps:list", "--project", project_id, "--json"],
        timeout=30
    )

    try:
        apps_data = json.loads(result.stdout)
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse Firebase apps list: {e}")
        raise HTTPException(status_code=500, detail="Failed to parse Firebase apps list")

    if not apps_data or "result" not in apps_data:
        logger.error("No apps found in Firebase project")
        raise HTTPException(status_code=404, detail="No apps found in Firebase project")

    ios_apps = [
        app for app in apps_data["result"]
        if app.get("platform") == "IOS" and app.get("appId")
    ]

    if not ios_apps:
        logger.error("No iOS apps found in Firebase project")
        raise HTTPException(status_code=404, detail="No iOS apps found in project")

    matching_app = next(
        (app for app in ios_apps if app.get("namespace") == bundle_id),
        None
    )

    if not matching_app:
        logger.error(f"No iOS app found with bundle ID {bundle_id}")
        available_bundles = [app.get("namespace") for app in ios_apps]
        raise HTTPException(
            status_code=404,
            detail=f"No iOS app found with bundle ID {bundle_id}. Available: {available_bundles}"
        )

    app_id = matching_app["appId"]
    logger.info(f"Found iOS app ID: {app_id}")
    return app_id


async def _get_web_app_id(project_id: str) -> str:
    """Get Firebase Web app ID. Assumes only one Web app exists per project."""
    logger.info(f"Looking up Web app in project {project_id}")

    result = await run_command(
        ["firebase", "apps:list", "--project", project_id, "--json"],
        timeout=30
    )

    try:
        apps_data = json.loads(result.stdout)
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse Firebase apps list: {e}")
        raise HTTPException(status_code=500, detail="Failed to parse Firebase apps list")

    if not apps_data or "result" not in apps_data:
        logger.error("No apps found in Firebase project")
        raise HTTPException(status_code=404, detail="No apps found in Firebase project")

    web_apps = [
        app for app in apps_data["result"]
        if app.get("platform") == "WEB" and app.get("appId")
    ]

    if not web_apps:
        logger.error("No Web apps found in Firebase project")
        raise HTTPException(status_code=404, detail="No Web apps found in project")

    if len(web_apps) > 1:
        logger.warning(f"Multiple Web apps found ({len(web_apps)}), using the first one")

    web_app = web_apps[0]
    app_id = web_app["appId"]
    app_name = web_app.get("displayName", "Unknown")
    logger.info(f"Found Web app ID: {app_id} (name: {app_name})")
    return app_id


def _update_firebase_config_dart(file_path: Path, web_config: dict) -> None:
    """Update or create firebase_config.dart file with new web configuration values."""
    logger.info(f"Updating firebase_config.dart at {file_path}")

    if not file_path.exists():
        logger.info(f"firebase_config.dart not found at {file_path}, creating new file")

        # Ensure the directory exists
        file_path.parent.mkdir(parents=True, exist_ok=True)

        # Create a new firebase_config.dart file with template
        template_content = f'''import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {{
  static FirebaseOptions get currentPlatform {{
    if (kIsWeb) {{
      return web;
    }}
    switch (defaultTargetPlatform) {{
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for windows - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }}
  }}

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: "{web_config.get("apiKey", "")}",
    appId: "{web_config.get("appId", "")}",
    messagingSenderId: "{web_config.get("messagingSenderId", "")}",
    projectId: "{web_config.get("projectId", "")}",
    authDomain: "{web_config.get("authDomain", "")}",
    storageBucket: "{web_config.get("storageBucket", "")}",
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: "PLACEHOLDER_API_KEY",
    appId: "PLACEHOLDER_APP_ID",
    messagingSenderId: "{web_config.get("messagingSenderId", "")}",
    projectId: "{web_config.get("projectId", "")}",
    storageBucket: "{web_config.get("storageBucket", "")}",
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: "PLACEHOLDER_API_KEY",
    appId: "PLACEHOLDER_APP_ID",
    messagingSenderId: "{web_config.get("messagingSenderId", "")}",
    projectId: "{web_config.get("projectId", "")}",
    storageBucket: "{web_config.get("storageBucket", "")}",
    iosBundleId: "PLACEHOLDER_BUNDLE_ID",
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: "PLACEHOLDER_API_KEY",
    appId: "PLACEHOLDER_APP_ID",
    messagingSenderId: "{web_config.get("messagingSenderId", "")}",
    projectId: "{web_config.get("projectId", "")}",
    storageBucket: "{web_config.get("storageBucket", "")}",
    iosBundleId: "PLACEHOLDER_BUNDLE_ID",
  );
}}
'''
        file_path.write_text(template_content)
        logger.info(f"Created new firebase_config.dart at {file_path}")
        return

    # Update existing file
    content = file_path.read_text()

    replacements = {
        "apiKey": web_config.get("apiKey", ""),
        "authDomain": web_config.get("authDomain", ""),
        "projectId": web_config.get("projectId", ""),
        "storageBucket": web_config.get("storageBucket", ""),
        "messagingSenderId": web_config.get("messagingSenderId", ""),
        "appId": web_config.get("appId", ""),
    }

    for key, value in replacements.items():
        pattern = rf'{key}:\s*"[^"]*"'
        replacement = f'{key}: "{value}"'
        content = re.sub(pattern, replacement, content)
        logger.debug(f"Replaced {key} with {value}")

    file_path.write_text(content)
    logger.info(f"Successfully updated firebase_config.dart at {file_path}")


@router.get("/project")
async def get_project() -> dict:
    """Get the currently configured GCloud project."""
    logger.info("Fetching current GCloud project")

    result = await run_command(
        ["gcloud", "config", "get-value", "project"],
        timeout=5
    )

    project_id = result.stdout.strip()

    if not project_id:
        logger.warning("No GCloud project is currently set")
        return {"project_id": None}

    logger.info(f"Current project: {project_id}")
    return {"project_id": project_id}


@router.post("/set-project")
async def set_project(request: SetProjectRequest) -> dict:
    """Set the local GCloud project configuration."""
    logger.info(f"Setting GCloud project to: {request.project_id}")

    config_result = await run_command(
        ["gcloud", "config", "set", "project", request.project_id],
        timeout=10
    )
    logger.debug(f"gcloud config set project output: {config_result.stdout}")

    quota_result = await run_command(
        ["gcloud", "auth", "application-default", "set-quota-project", request.project_id],
        timeout=10
    )
    logger.debug(f"gcloud set-quota-project output: {quota_result.stdout}")

    logger.info(f"Successfully set project to: {request.project_id}")

    return {
        "project_id": request.project_id,
        "config_output": config_result.stdout.strip(),
        "quota_output": quota_result.stdout.strip(),
    }


class DisconnectProjectRequest(BaseModel):
    """Request model for disconnecting from projects."""
    repo_path: str | None = Field(default=None, description="Optional repository path for Firebase project disconnection")


@router.post("/disconnect-project")
async def disconnect_project(request: DisconnectProjectRequest) -> dict:
    """Disconnect from the currently selected Firebase and gcloud project."""
    logger.info("Disconnecting from current Firebase and gcloud project")

    # Determine working directory for Firebase commands
    if request.repo_path:
        firebase_cwd = request.repo_path
        logger.info(f"Using provided repo path for Firebase: {firebase_cwd}")
    elif env_service.project_dir:
        firebase_cwd = str(env_service.project_dir)
        logger.info(f"Using configured project directory for Firebase: {firebase_cwd}")
    else:
        firebase_cwd = None
        logger.info("No Firebase project directory specified")

    # Get current gcloud project
    current_gcloud_result = await run_command(
        ["gcloud", "config", "get-value", "project"],
        timeout=5,
        raise_on_error=False
    )

    previous_gcloud_project = current_gcloud_result.stdout.strip() if current_gcloud_result.success else None

    # Get current Firebase project (if in a Firebase directory)
    previous_firebase_project = None
    if firebase_cwd:
        firebase_use_result = await run_command(
            ["firebase", "use"],
            timeout=5,
            cwd=firebase_cwd,
            raise_on_error=False
        )

        if firebase_use_result.success:
            # Parse "Currently using project PROJECT_ID" or similar output
            firebase_output = firebase_use_result.stdout.strip()
            if "project" in firebase_output.lower():
                # Extract project ID from output like "Currently using project my-project-id"
                import re
                project_match = re.search(r'project\s+([^\s\)]+)', firebase_output)
                if project_match:
                    previous_firebase_project = project_match.group(1)

    if previous_gcloud_project:
        logger.info(f"Disconnecting from gcloud project: {previous_gcloud_project}")
    if previous_firebase_project:
        logger.info(f"Disconnecting from Firebase project: {previous_firebase_project}")

    # Disconnect Firebase CLI project (if in a Firebase directory)
    firebase_disconnected = False
    firebase_output = ""
    if firebase_cwd:
        firebase_clear_result = await run_command(
            ["firebase", "use", "--clear"],
            timeout=10,
            cwd=firebase_cwd,
            raise_on_error=False
        )

        if firebase_clear_result.success:
            firebase_disconnected = True
            firebase_output = firebase_clear_result.stdout.strip()
            logger.info("Successfully cleared Firebase project selection")
        else:
            logger.warning(f"Could not clear Firebase project: {firebase_clear_result.stderr}")
            firebase_output = firebase_clear_result.stderr

    # Unset the gcloud project
    gcloud_unset_result = await run_command(
        ["gcloud", "config", "unset", "project"],
        timeout=10,
        raise_on_error=False
    )

    if not gcloud_unset_result.success:
        logger.error(f"Failed to unset gcloud project: {gcloud_unset_result.stderr}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to unset gcloud project: {gcloud_unset_result.stderr}"
        )

    logger.info("Successfully unset gcloud project")

    # Also unset the quota project
    quota_unset_result = await run_command(
        ["gcloud", "config", "unset", "billing/quota_project"],
        timeout=10,
        raise_on_error=False
    )

    if quota_unset_result.success:
        logger.info("Successfully unset quota project")
    else:
        logger.debug(f"Could not unset quota project: {quota_unset_result.stderr}")

    logger.info("Successfully disconnected from Firebase and gcloud projects")

    return {
        "disconnected": True,
        "previous_gcloud_project": previous_gcloud_project,
        "previous_firebase_project": previous_firebase_project,
        "firebase_disconnected": firebase_disconnected,
        "gcloud_output": gcloud_unset_result.stdout.strip(),
        "firebase_output": firebase_output,
    }


@router.get("/auth-enabled")
async def check_auth_enabled() -> dict:
    """Check if Firebase Auth is enabled in the currently configured project."""
    logger.info("Checking if Firebase Auth is enabled")

    project_result = await run_command(
        ["gcloud", "config", "get-value", "project"],
        timeout=5,
        raise_on_error=False
    )

    if not project_result.success or not project_result.stdout.strip():
        logger.error("No GCloud project is currently configured")
        raise HTTPException(
            status_code=400,
            detail="No GCloud project configured. Set a project first using /set-project"
        )

    project_id = project_result.stdout.strip()
    logger.info(f"Checking Firebase Auth for project: {project_id}")

    result = await run_command(
        [
            "gcloud", "services", "list",
            "--enabled",
            "--project", project_id,
            "--filter=name:identitytoolkit.googleapis.com",
            "--format=value(name)"
        ],
        timeout=30,
        raise_on_error=False
    )

    if not result.success:
        logger.error(f"Failed to check Firebase Auth status: {result.stderr}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to check Firebase Auth status: {result.stderr}"
        )

    auth_enabled = "identitytoolkit.googleapis.com" in result.stdout

    if auth_enabled:
        logger.info(f"Firebase Auth is enabled in project {project_id}")
    else:
        logger.info(f"Firebase Auth is not enabled in project {project_id}")

    return {
        "project_id": project_id,
        "auth_enabled": auth_enabled,
    }


@router.get("/auth-users-count")
async def get_auth_users_count() -> dict:
    """Get the number of registered users in Firebase Auth using Application Default Credentials."""
    logger.info("Fetching Firebase Auth users count")

    try:
        app_name = "auth_count_default"

        try:
            app = firebase_admin.get_app(name=app_name)
            logger.debug("Using existing Firebase Admin app")
        except ValueError:
            logger.info("Initializing Firebase Admin SDK with Application Default Credentials")
            cred = credentials.ApplicationDefault()
            app = firebase_admin.initialize_app(cred, name=app_name)
            logger.info("Successfully initialized Firebase Admin SDK")

        project_id = app.project_id
        logger.info(f"Counting Firebase Auth users for project: {project_id}")

        logger.debug("Listing Firebase Auth users")
        user_count = 0
        page = auth.list_users(app=app)

        while page:
            user_count += len(page.users)
            logger.debug(f"Processed batch, current count: {user_count}")
            page = page.get_next_page()

        logger.info(f"Found {user_count} registered users in project {project_id}")

        return {
            "project_id": project_id,
            "user_count": user_count,
        }

    except auth.UnexpectedResponseError as e:
        logger.error(f"Firebase Auth API error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Firebase Auth API error: {str(e)}"
        )
    except Exception as e:
        logger.exception(f"Failed to count Firebase Auth users: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to count Firebase Auth users: {str(e)}"
        )


@router.get("/auth-users-summary")
async def get_auth_users_summary() -> dict:
    """Get detailed summary of all registered users in Firebase Auth."""
    logger.info("Fetching Firebase Auth users summary")

    try:
        app_name = "auth_summary_default"

        try:
            app = firebase_admin.get_app(name=app_name)
            logger.debug("Using existing Firebase Admin app")
        except ValueError:
            logger.info("Initializing Firebase Admin SDK with Application Default Credentials")
            cred = credentials.ApplicationDefault()
            app = firebase_admin.initialize_app(cred, name=app_name)
            logger.info("Successfully initialized Firebase Admin SDK")

        project_id = app.project_id
        logger.info(f"Fetching users summary for project: {project_id}")

        logger.debug("Listing Firebase Auth users with details")
        users_list = []
        page = auth.list_users(app=app)

        while page:
            for user in page.users:
                user_data = {
                    "uid": user.uid,
                    "email": user.email,
                    "phone_number": user.phone_number,
                    "display_name": user.display_name,
                    "photo_url": user.photo_url,
                    "disabled": user.disabled,
                    "email_verified": user.email_verified,
                    "provider_id": getattr(user, "provider_id", None),
                    "tenant_id": user.tenant_id,
                    "custom_claims": user.custom_claims,
                }

                if user.user_metadata:
                    user_data["metadata"] = {
                        "creation_timestamp": user.user_metadata.creation_timestamp,
                        "last_sign_in_timestamp": user.user_metadata.last_sign_in_timestamp,
                        "last_refresh_timestamp": getattr(user.user_metadata, "last_refresh_timestamp", None),
                    }
                else:
                    user_data["metadata"] = None

                if user.provider_data:
                    user_data["providers"] = [
                        {
                            "provider_id": provider.provider_id,
                            "uid": provider.uid,
                            "email": provider.email,
                            "display_name": provider.display_name,
                            "photo_url": provider.photo_url,
                            "phone_number": provider.phone_number,
                        }
                        for provider in user.provider_data
                    ]
                else:
                    user_data["providers"] = []

                if hasattr(user, "tokens_valid_after_timestamp"):
                    user_data["tokens_valid_after_timestamp"] = user.tokens_valid_after_timestamp
                else:
                    user_data["tokens_valid_after_timestamp"] = None

                users_list.append(user_data)

            logger.debug(f"Processed batch, current total: {len(users_list)}")
            page = page.get_next_page()

        logger.info(f"Retrieved details for {len(users_list)} users in project {project_id}")

        return {
            "project_id": project_id,
            "user_count": len(users_list),
            "users": users_list,
        }

    except auth.UnexpectedResponseError as e:
        logger.error(f"Firebase Auth API error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Firebase Auth API error: {str(e)}"
        )
    except Exception as e:
        logger.exception(f"Failed to fetch Firebase Auth users summary: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch Firebase Auth users summary: {str(e)}"
        )


@router.post("/fetch-firebase-configs")
async def fetch_firebase_configs(request: FetchFirebaseConfigsRequest) -> dict:
    """Fetch Firebase config files (Android, iOS, and Web) and save to Flutter app."""
    logger.info(
        f"Fetching Firebase configs for {request.bundle_id} "
        f"from project {request.project_id}"
    )

    android_app_id = await _get_android_app_id(request.project_id, request.bundle_id)
    ios_app_id = await _get_ios_app_id(request.project_id, request.bundle_id)
    web_app_id = await _get_web_app_id(request.project_id)

    logger.info(f"Downloading Android config for app ID: {android_app_id}")
    android_config_result = await run_command(
        ["firebase", "apps:sdkconfig", "android", android_app_id, "--project", request.project_id],
        timeout=30
    )

    if not android_config_result.stdout.strip():
        logger.error("Firebase returned empty Android config")
        raise HTTPException(status_code=500, detail="Firebase returned empty Android config")

    try:
        android_config_json = json.loads(android_config_result.stdout)
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse google-services.json: {e}")
        raise HTTPException(status_code=500, detail="Invalid Android config JSON received from Firebase")

    android_target_dir = Path(request.flutter_app_path) / "android" / "app"
    android_target_file = android_target_dir / "google-services.json"

    logger.info(f"Ensuring Android target directory exists: {android_target_dir}")
    android_target_dir.mkdir(parents=True, exist_ok=True)

    logger.info(f"Writing google-services.json to: {android_target_file}")
    android_target_file.write_text(json.dumps(android_config_json, indent=2))

    logger.info(f"Successfully saved google-services.json to {android_target_file}")

    logger.info(f"Downloading iOS config for app ID: {ios_app_id}")
    ios_config_result = await run_command(
        ["firebase", "apps:sdkconfig", "ios", ios_app_id, "--project", request.project_id],
        timeout=30
    )

    if not ios_config_result.stdout.strip():
        logger.error("Firebase returned empty iOS config")
        raise HTTPException(status_code=500, detail="Firebase returned empty iOS config")

    ios_target_dir = Path(request.flutter_app_path) / "ios" / "Runner"
    ios_target_file = ios_target_dir / "GoogleService-Info.plist"

    logger.info(f"Ensuring iOS target directory exists: {ios_target_dir}")
    ios_target_dir.mkdir(parents=True, exist_ok=True)

    logger.info(f"Writing GoogleService-Info.plist to: {ios_target_file}")
    ios_target_file.write_text(ios_config_result.stdout)

    logger.info(f"Successfully saved GoogleService-Info.plist to {ios_target_file}")

    logger.info(f"Downloading Web config for app ID: {web_app_id}")
    web_config_result = await run_command(
        ["firebase", "apps:sdkconfig", "web", web_app_id, "--project", request.project_id],
        timeout=30
    )

    if not web_config_result.stdout.strip():
        logger.error("Firebase returned empty Web config")
        raise HTTPException(status_code=500, detail="Firebase returned empty Web config")

    logger.debug(f"Raw web config output: {web_config_result.stdout[:500]}")

    # Try to parse as direct JSON first (newer Firebase CLI format)
    try:
        web_config_json = json.loads(web_config_result.stdout)
        logger.info("Successfully parsed web config as direct JSON")
    except json.JSONDecodeError:
        # Fallback to old format with firebase.initializeApp()
        logger.debug("Direct JSON parsing failed, trying firebase.initializeApp() pattern")
        config_match = re.search(r'firebase\.initializeApp\((\{[\s\S]*?\})\)', web_config_result.stdout)
        if not config_match:
            logger.error("Could not find firebase.initializeApp() in output and direct JSON parsing failed")
            logger.error(f"Raw output was: {web_config_result.stdout}")
            raise HTTPException(status_code=500, detail="Could not parse Web config from Firebase output")

        try:
            web_config_json = json.loads(config_match.group(1))
            logger.info("Successfully parsed web config from firebase.initializeApp() pattern")
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse Web config JSON: {e}")
            logger.error(f"Extracted config string: {config_match.group(1)}")
            raise HTTPException(status_code=500, detail="Invalid Web config JSON received from Firebase")

    if request.firebase_config_path:
        firebase_config_path = Path(request.firebase_config_path)
        if not firebase_config_path.is_absolute():
            firebase_config_path = Path(request.flutter_app_path) / firebase_config_path
    else:
        firebase_config_path = Path(request.flutter_app_path) / "lib" / "backend" / "firebase" / "firebase_config.dart"

    logger.info(f"Using firebase_config path: {firebase_config_path}")

    _update_firebase_config_dart(firebase_config_path, web_config_json)

    return {
        "message": "Firebase configs downloaded successfully",
        "android_file_path": str(android_target_file),
        "ios_file_path": str(ios_target_file),
        "web_config_path": str(firebase_config_path),
        "project_id": request.project_id,
        "bundle_id": request.bundle_id,
    }
