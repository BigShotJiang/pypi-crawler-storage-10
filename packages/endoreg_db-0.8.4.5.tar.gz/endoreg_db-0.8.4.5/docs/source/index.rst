.. EndoReg-DB documentation master file, created by
   sphinx-quickstart on Mon Apr 21 23:11:03 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

EndoReg-DB documentation
========================

Add your content using ``reStructuredText`` syntax. See the
`reStructuredText <https://www.sphinx-doc.org/en/master/usage/restructuredtext/index.html>`_
documentation for details.


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   models
   .. tests

