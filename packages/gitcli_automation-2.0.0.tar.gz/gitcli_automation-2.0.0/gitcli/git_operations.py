import subprocess
import os
from colorama import Fore
from yaspin import yaspin
from .helpers import (
    run_command, send_notification, get_current_branch,
    has_staged_changes, has_unstaged_changes, has_any_changes, has_remote, display_command,
    get_config, generate_commit_message, check_for_conflicts, validate_changes, check_large_files,
    run_formatter
)


def smart_save(commit_message=None):
    """
    Smart save command with configuration support:
    1. Check for conflicts and validate changes
    2. Automatically stage all changes
    3. Smart commit message with suggestions
    4. Configurable auto-push
    """
    branch = get_current_branch()
    config = get_config()
    
    # Check if there are any changes
    if not has_any_changes():
        # Check for unpushed commits
        if has_remote():
            ahead = run_command("git rev-list --count @{u}..HEAD 2>/dev/null")
            if ahead and int(ahead) > 0:
                print(Fore.CYAN + f"\n📤 You have {ahead} unpushed commit(s) on '{branch}'")
                
                if config.get("auto_push", True):
                    push = input("Push to remote? (Y/n): ").lower()
                    if push != "n":
                        push_changes()
                else:
                    print(Fore.YELLOW + "💡 Auto-push is disabled. Use 'gitcli push' to push manually.")
            else:
                print(Fore.GREEN + "\n✅ Everything is saved and up to date!")
        else:
            print(Fore.GREEN + "\n✅ No changes to save!")
        return
    
    # Step 0: Check for conflicts
    if check_for_conflicts():
        print(Fore.RED + "\n⚠️  Merge conflicts detected!")
        print(Fore.CYAN + "💡 You must resolve conflicts before saving.")
        resolve = input("Open conflict resolution helper? (Y/n): ").lower()
        if resolve != "n":
            from .git_conflicts import resolve_conflicts
            resolve_conflicts()
        return
    
    # Step 0.5: Auto-fix formatting
    if config.get("auto_fix_formatting", False):
        print(Fore.CYAN + "\n🎨 Auto-formatting code...")
        if run_formatter():
            print(Fore.GREEN + "✅ Code formatted!")
            # Re-check for changes after formatting
            if not has_any_changes():
                print(Fore.GREEN + "✅ No changes after formatting!")
                return
        else:
            print(Fore.YELLOW + "💡 No formatters found or nothing to format")
    
    # Step 0.6: Pre-save validation
    if config.get("pre_save_validation", True):
        print(Fore.CYAN + "\n🔍 Validating changes...")
        
        validation_rules = config.get("validation_rules", {})
        
        # Check for large files
        if validation_rules.get("check_large_files", True):
            large_files = check_large_files()
            if large_files:
                max_size = validation_rules.get("max_file_size_mb", 10)
                print(Fore.YELLOW + f"\n⚠️  Large files detected (>{max_size}MB):")
                for filepath, size_mb in large_files:
                    print(f"  • {filepath} ({size_mb:.1f} MB)")
                proceed = input(Fore.YELLOW + "Continue anyway? (y/N): ").lower()
                if proceed != "y":
                    print(Fore.CYAN + "🚫 Save canceled.")
                    return
        
        # Validate for issues
        is_valid, issues = validate_changes(validation_rules)
        if not is_valid:
            print(Fore.RED + "\n⚠️  Issues found:")
            for issue in issues:
                print(f"  • {Fore.YELLOW}{issue}")
            
            print(Fore.CYAN + "\nOptions:")
            print("  1. Fix issues and try again")
            print("  2. Continue anyway (not recommended)")
            print("  3. Cancel")
            
            choice = input("\nChoose option (1-3): ").strip()
            if choice == "2":
                print(Fore.YELLOW + "⚠️  Proceeding with issues...")
            else:
                print(Fore.CYAN + "🚫 Save canceled.")
                return
        else:
            print(Fore.GREEN + "✅ Validation passed!")
    
    # Step 1: Stage all changes
    if config.get("auto_stage", True):
        print(Fore.CYAN + "\n📦 Staging all changes...")
        with yaspin(text="Staging...", color="cyan") as spinner:
            run_command("git add .", capture_output=False)
            spinner.ok("✅")
        
        # Count staged files
        staged_files = run_command("git diff --cached --name-only")
        if staged_files:
            file_list = staged_files.strip().split('\n')
            file_count = len(file_list)
            print(Fore.GREEN + f"✅ {file_count} file(s) staged")
    
    # Step 2: Get commit message with smart suggestions
    if not commit_message:
        # Generate smart default message
        if config.get("learn_from_history", True):
            default_message = generate_commit_message()
        else:
            default_message = "Update files"
        
        print(Fore.CYAN + f"\n📝 Commit message (press Enter to use default):")
        print(Fore.YELLOW + f"Default: \"{default_message}\"")
        user_input = input(Fore.CYAN + "> " + Fore.WHITE).strip()
        
        if user_input:
            commit_message = user_input
        else:
            commit_message = default_message
            print(Fore.GREEN + f"✅ Using: \"{commit_message}\"")
    
    # Commit
    with yaspin(text="Committing...", color="cyan") as spinner:
        result = run_command(f'git commit -m "{commit_message}"', capture_output=False)
        if result is not None:
            spinner.ok("✅")
            print(Fore.GREEN + "✅ Changes committed!")
        else:
            spinner.fail("❌")
            return
    
    # Step 3: Push based on configuration
    if has_remote():
        if config.get("auto_push", True):
            # Auto-pull before push if enabled
            if config.get("auto_pull_before_push", True):
                print(Fore.CYAN + "\n⬇️  Pulling latest changes before push...")
                with yaspin(text="Pulling...", color="cyan") as spinner:
                    result = subprocess.run("git pull --rebase", shell=True, capture_output=True, text=True)
                    if result.returncode == 0:
                        spinner.ok("✅")
                        if "Already up to date" not in result.stdout:
                            print(Fore.GREEN + "✅ Pulled latest changes!")
                            # Show what changed
                            print(Fore.CYAN + "Changes from remote:")
                            subprocess.run("git log --oneline HEAD@{1}..HEAD", shell=True)
                        else:
                            print(Fore.GREEN + "✅ Already up to date!")
                    else:
                        spinner.fail("❌")
                        if "CONFLICT" in result.stdout or "CONFLICT" in result.stderr:
                            print(Fore.RED + "❌ Conflicts during pull!")
                            print(Fore.YELLOW + "💡 Resolve conflicts and try again.")
                            return
                        else:
                            print(Fore.YELLOW + f"⚠️  Pull failed: {result.stderr}")
                            proceed = input("Continue with push anyway? (y/N): ").lower()
                            if proceed != "y":
                                return
            
            push = input(Fore.CYAN + "\nPush to remote? (Y/n): ").lower()
            if push != "n":
                push_changes()
            else:
                print(Fore.GREEN + "\n✅ Staged and committed successfully!")
        else:
            print(Fore.GREEN + "\n✅ Staged and committed successfully!")
            print(Fore.YELLOW + "💡 Auto-push is disabled. Use 'gitcli push' to push manually.")
    else:
        print(Fore.YELLOW + "\n💡 No remote configured. Changes committed locally.")
        print(Fore.GREEN + "✅ Staged and committed successfully!")

def commit_changes():
    if not has_staged_changes():
        if has_unstaged_changes():
            print(Fore.CYAN + "📦 No staged changes. Staging all changes...")
            with yaspin(text="Staging all changes...", color="cyan") as spinner:
                run_command("git add .", capture_output=False)
                spinner.ok("✅")
            print(Fore.GREEN + "✅ All changes staged.")
        else:
            print(Fore.YELLOW + "⚠️  No changes to commit.")
            return
    
    print(Fore.CYAN + "\n📝 Enter commit message:")
    message = input("> ").strip()
    if not message:
        print(Fore.RED + "❌ Commit message cannot be empty.")
        return
    with yaspin(text="Committing changes...", color="cyan") as spinner:
        run_command(f'git commit -m "{message}"', capture_output=False)
        spinner.ok("✅")
    print(Fore.GREEN + f"✅ Changes committed with message: '{message}'")
    send_notification("GitCLI", f"Commit successful: {message[:30]}...")

def push_changes():
    branch = get_current_branch()
    config = get_config()
    
    if not has_remote():
        print(Fore.RED + "❌ No remote repository configured.")
        return
    
    # Check if there are uncommitted changes
    if has_unstaged_changes() or has_staged_changes():
        print(Fore.YELLOW + "⚠️  You have uncommitted changes. Commit them first or use 'qp' for quick push.")
        return
    
    # Now push (will push any commits that are ahead of remote)
    with yaspin(text=f"Pushing branch '{branch}'...", color="magenta") as spinner:
        result = subprocess.run("git push", shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            spinner.ok("🚀")
            print(Fore.GREEN + f"✅ Changes pushed to '{branch}'!")
            send_notification("GitCLI", f"Push to '{branch}' complete!")
        else:
            spinner.fail("❌")
            if "rejected" in result.stderr and "non-fast-forward" in result.stderr:
                print(Fore.YELLOW + "\n⚠️  Push rejected: Your branch is behind the remote branch.")
                
                # Check confirm_force_push config
                if config.get("confirm_force_push", True):
                    force = input(Fore.RED + "Do you want to force push and overwrite the remote? (yes/N): ").lower()
                    if force != "yes":
                        print(Fore.CYAN + "🚫 Force push canceled.")
                        return
                else:
                    print(Fore.YELLOW + "⚠️  Force pushing (confirm_force_push is disabled)...")
                
                with yaspin(text=f"Force pushing to '{branch}'...", color="red") as spinner2:
                    force_result = run_command("git push --force", capture_output=False)
                    if force_result is not None:
                        spinner2.ok("🚀")
                        print(Fore.GREEN + f"✅ Force pushed to '{branch}'!")
                        send_notification("GitCLI", f"Force push to '{branch}' complete!")
                    else:
                        spinner2.fail("❌")
            elif "no upstream" in result.stderr:
                print(Fore.YELLOW + "\n⚠️  No upstream branch set.")
                setup = input("Set upstream and push? (Y/n): ").lower()
                if setup != "n":
                    with yaspin(text="Setting upstream and pushing...", color="magenta") as spinner2:
                        result2 = run_command(f"git push -u origin {branch}", capture_output=False)
                        if result2 is not None:
                            spinner2.ok("🚀")
                            print(Fore.GREEN + f"✅ Pushed to '{branch}' and set upstream!")
                        else:
                            spinner2.fail("❌")
            else:
                print(Fore.RED + f"❌ Push failed: {result.stderr.strip()}")

def pull_changes():
    branch = get_current_branch()
    
    if not has_remote():
        print(Fore.RED + "❌ No remote repository configured.")
        return
    
    print(Fore.CYAN + f"\n⬇️  Pulling latest changes for '{branch}'...")
    with yaspin(text="Pulling...", color="cyan") as spinner:
        result = run_command("git pull", capture_output=False)
        if result is not None:
            spinner.ok("✅")
            print(Fore.GREEN + f"✅ Successfully pulled latest changes!")
            send_notification("GitCLI", f"Pull from '{branch}' complete!")
        else:
            spinner.fail("❌")

def stage_changes():
    """Stage changes with options"""
    if not has_unstaged_changes():
        print(Fore.YELLOW + "⚠️  No unstaged changes to stage.")
        return
    
    print(Fore.CYAN + "\n📂 Stage options:")
    print("  1. Stage all changes (git add .)")
    print("  2. Stage specific files")
    
    choice = input("Choose option (1/2): ").strip()
    
    if choice == "1":
        with yaspin(text="Staging all changes...", color="cyan") as spinner:
            run_command("git add .", capture_output=False)
            spinner.ok("✅")
        print(Fore.GREEN + "✅ All changes staged.")
    elif choice == "2":
        print(Fore.CYAN + "\nUnstaged files:")
        display_command("git diff --name-only")
        print(Fore.CYAN + "\nEnter file paths (space-separated):")
        files = input("> ").strip()
        if not files:
            print(Fore.RED + "❌ No files specified.")
            return
        with yaspin(text="Staging files...", color="cyan") as spinner:
            run_command(f"git add {files}", capture_output=False)
            spinner.ok("✅")
        print(Fore.GREEN + f"✅ Files staged: {files}")
    else:
        print(Fore.RED + "❌ Invalid option.")

def show_status():
    print(Fore.CYAN + "\n📊 Git Status:\n" + "-"*30)
    display_command("git status")

def show_log():
    print(Fore.CYAN + "\n📜 Recent Commits:\n" + "-"*30)
    display_command("git log --oneline --graph --decorate -10")

def show_diff():
    """Show unstaged changes"""
    if not has_unstaged_changes():
        print(Fore.YELLOW + "⚠️  No unstaged changes to show.")
        return
    print(Fore.CYAN + "\n📝 Unstaged Changes:\n" + "-"*30)
    display_command("git diff")

def show_diff_staged():
    """Show staged changes"""
    if not has_staged_changes():
        print(Fore.YELLOW + "⚠️  No staged changes to show.")
        return
    print(Fore.CYAN + "\n📝 Staged Changes:\n" + "-"*30)
    display_command("git diff --cached")

def sync_changes():
    """Pull then push changes"""
    branch = get_current_branch()
    
    if not has_remote():
        print(Fore.RED + "❌ No remote repository configured.")
        return
    
    # Pull first
    print(Fore.CYAN + f"\n🔄 Syncing '{branch}': Pull → Push")
    with yaspin(text="Pulling latest changes...", color="cyan") as spinner:
        result = subprocess.run("git pull", shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            spinner.fail("❌")
            print(Fore.RED + f"❌ Pull failed: {result.stderr.strip()}")
            return
        spinner.ok("✅")
    print(Fore.GREEN + "✅ Pull complete.")
    
    # Check if there's anything to push
    if not has_any_changes():
        # Check if local is ahead of remote
        ahead = run_command("git rev-list --count @{u}..HEAD")
        if ahead and int(ahead) > 0:
            print(Fore.CYAN + f"\n📤 Local branch is {ahead} commit(s) ahead. Pushing...")
        else:
            print(Fore.YELLOW + "⚠️  Already up to date. Nothing to push.")
            return
    
    # Push
    with yaspin(text=f"Pushing to '{branch}'...", color="magenta") as spinner:
        result = subprocess.run("git push", shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            spinner.ok("🚀")
            print(Fore.GREEN + f"✅ Sync complete!")
            send_notification("GitCLI", f"Sync to '{branch}' complete!")
        else:
            spinner.fail("❌")
            print(Fore.RED + f"❌ Push failed: {result.stderr.strip()}")

def fetch_changes():
    """Fetch updates from remote without merging"""
    if not has_remote():
        print(Fore.RED + "❌ No remote repository configured.")
        return
    
    print(Fore.CYAN + "\n📥 Fetching updates from remote...")
    with yaspin(text="Fetching...", color="cyan") as spinner:
        result = run_command("git fetch", capture_output=False)
        if result is not None:
            spinner.ok("✅")
            print(Fore.GREEN + "✅ Fetch complete.")
            
            # Show if branch is behind
            branch = get_current_branch()
            behind = run_command("git rev-list --count HEAD..@{u}")
            if behind and int(behind) > 0:
                print(Fore.YELLOW + f"⚠️  Your branch is {behind} commit(s) behind remote.")
                print(Fore.CYAN + "💡 Use 'pull' to merge remote changes.")
        else:
            spinner.fail("❌")

def clone_repository():
    """Clone a repository interactively"""
    print(Fore.CYAN + "\n📦 Clone Repository")
    url = input("Enter repository URL: ").strip()
    if not url:
        print(Fore.RED + "❌ URL cannot be empty.")
        return
    
    folder = input("Enter folder name (leave empty for default): ").strip()
    
    cmd = f"git clone {url}"
    if folder:
        cmd += f" {folder}"
    
    print(Fore.CYAN + f"\n⬇️  Cloning repository...")
    with yaspin(text="Cloning...", color="cyan") as spinner:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            spinner.ok("✅")
            print(Fore.GREEN + "✅ Repository cloned successfully!")
            if folder:
                print(Fore.CYAN + f"💡 Navigate to folder: cd {folder}")
            else:
                # Extract folder name from URL
                repo_name = url.rstrip('/').split('/')[-1].replace('.git', '')
                print(Fore.CYAN + f"💡 Navigate to folder: cd {repo_name}")
        else:
            spinner.fail("❌")
            print(Fore.RED + f"❌ Clone failed: {result.stderr}")

def quick_push():
    """Stage all, commit, and push in one command"""
    branch = get_current_branch()
    
    if not has_remote():
        print(Fore.RED + "❌ No remote repository configured.")
        return
    
    # Check if there are any changes
    if not has_any_changes():
        print(Fore.YELLOW + "⚠️  No changes to commit and push.")
        return
    
    # Stage all changes
    print(Fore.CYAN + "\n🚀 Quick Push: Stage → Commit → Push")
    with yaspin(text="Staging all changes...", color="cyan") as spinner:
        run_command("git add .", capture_output=False)
        spinner.ok("✅")
    print(Fore.GREEN + "✅ All changes staged.")
    
    # Get commit message
    print(Fore.CYAN + "\n📝 Enter commit message:")
    message = input("> ").strip()
    if not message:
        print(Fore.RED + "❌ Commit message cannot be empty. Quick push canceled.")
        return
    
    # Commit
    with yaspin(text="Committing changes...", color="cyan") as spinner:
        run_command(f'git commit -m "{message}"', capture_output=False)
        spinner.ok("✅")
    print(Fore.GREEN + f"✅ Changes committed with message: '{message}'")
    
    # Push
    with yaspin(text=f"Pushing to '{branch}'...", color="magenta") as spinner:
        result = subprocess.run("git push", shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            spinner.ok("🚀")
            print(Fore.GREEN + f"✅ Successfully pushed to '{branch}'!")
            send_notification("GitCLI", f"Quick push to '{branch}' complete!")
        else:
            spinner.fail("❌")
            if "rejected" in result.stderr and "non-fast-forward" in result.stderr:
                print(Fore.YELLOW + "\n⚠️  Push rejected: Your branch is behind the remote branch.")
                force = input(Fore.RED + "Do you want to force push and overwrite the remote? (yes/N): ").lower()
                if force == "yes":
                    with yaspin(text=f"Force pushing to '{branch}'...", color="red") as spinner2:
                        force_result = run_command("git push --force", capture_output=False)
                        if force_result is not None:
                            spinner2.ok("🚀")
                            print(Fore.GREEN + f"✅ Force pushed to '{branch}'!")
                            send_notification("GitCLI", f"Force push to '{branch}' complete!")
                        else:
                            spinner2.fail("❌")
                else:
                    print(Fore.CYAN + "🚫 Force push canceled.")
            else:
                print(Fore.RED + f"❌ Push failed: {result.stderr.strip()}")
