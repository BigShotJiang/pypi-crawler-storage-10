"""GitCLI - Git Operations Automation Tool"""

__version__ = "2.0.0"
__author__ = "Adelodun Peter"
__description__ = "User-friendly Git CLI automation tool with interactive menus and visual feedback"

from .cli import main

__all__ = ["main"]
