⚠️ THIS PROJECT 'nvidia-cuda-opencl-cu13' IS DEPRECATED.
Please use 'nvidia-cuda-opencl' instead.

To install the correct package, use:

    pip install nvidia-cuda-opencl

For more information, visit: https://pypi.org/project/nvidia-cuda-opencl/
