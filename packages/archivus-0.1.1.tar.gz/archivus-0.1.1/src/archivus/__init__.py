def main() -> None:
    print("Hello from archivus!")
