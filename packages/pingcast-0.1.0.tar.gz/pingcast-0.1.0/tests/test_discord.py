"""Comprehensive tests for Discord plugin functionality."""

import json
import os
from unittest.mock import AsyncMock, patch

import pytest

from notifier.plugins.discord import (
    AsyncDiscordWebhook,
    DiscordEmbed,
    DiscordInvalidColorError,
    DiscordPlugin,
    DiscordRateLimitError,
    DiscordWebhook,
    DiscordWebhookError,
    DiscordWebhookValidationError,
)


class DummyResponse:
    """Mock HTTP response for testing."""

    def __init__(self, status_code: int = 204, content: str = "", headers: dict = None):
        self.status_code = status_code
        self._content = content if isinstance(content, bytes) else content.encode()
        self.headers = headers or {}

    @property
    def content(self):
        return self._content

    def json(self):
        return json.loads(self._content)

    def raise_for_status(self):
        if self.status_code >= 400:
            raise Exception(f"HTTP {self.status_code}")

    async def aread(self):
        return self._content


# ============================================================================
# DiscordPlugin Tests
# ============================================================================


def test_discord_plugin_initialization():
    """Test Discord plugin can be initialized with webhook URL."""
    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    plugin = DiscordPlugin(webhook_url)

    assert plugin.webhook_url == webhook_url
    assert plugin.username == "NotifierBot"


def test_discord_plugin_initialization_with_username():
    """Test Discord plugin initialization with custom username."""
    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    plugin = DiscordPlugin(webhook_url, username="CustomBot")

    assert plugin.webhook_url == webhook_url
    assert plugin.username == "CustomBot"


def test_discord_plugin_send_basic(monkeypatch):
    """Test basic send functionality."""
    calls = []

    def fake_post(url, json=None, timeout=None, **kwargs):
        calls.append({"url": url, "json": json, "timeout": timeout, **kwargs})
        return DummyResponse(204)

    from notifier.plugins.discord import webhook

    monkeypatch.setattr(webhook.requests, "post", fake_post)

    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    plugin = DiscordPlugin(webhook_url)
    plugin.send("Test message")

    assert len(calls) == 1
    assert calls[0]["json"]["content"] == "Test message"


def test_discord_plugin_send_with_detail(monkeypatch):
    """Test send with additional detail dictionary."""
    calls = []

    def fake_post(url, json=None, timeout=None, **kwargs):
        calls.append({"url": url, "json": json, "timeout": timeout, **kwargs})
        return DummyResponse(204)

    from notifier.plugins.discord import webhook

    monkeypatch.setattr(webhook.requests, "post", fake_post)

    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    plugin = DiscordPlugin(webhook_url)
    plugin.send("Main message", detail={"key1": "value1", "key2": "value2"})

    assert len(calls) == 1
    content = calls[0]["json"]["content"]
    assert "Main message" in content
    assert "key1: value1" in content
    assert "key2: value2" in content


def test_discord_plugin_send_with_embed_dict(monkeypatch):
    """Test send with embed dictionary."""
    calls = []

    def fake_post(url, json=None, timeout=None, **kwargs):
        calls.append({"url": url, "json": json, "timeout": timeout, **kwargs})
        return DummyResponse(204)

    from notifier.plugins.discord import webhook

    monkeypatch.setattr(webhook.requests, "post", fake_post)

    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    plugin = DiscordPlugin(webhook_url)
    embed_dict = {"title": "Test Title", "description": "Test Description"}
    plugin.send("Test message", embed=embed_dict)

    assert len(calls) == 1
    assert "embeds" in calls[0]["json"]
    assert calls[0]["json"]["embeds"][0]["title"] == "Test Title"


def test_discord_plugin_send_with_embed_object(monkeypatch):
    """Test send with DiscordEmbed object."""
    calls = []

    def fake_post(url, json=None, timeout=None, **kwargs):
        calls.append({"url": url, "json": json, "timeout": timeout, **kwargs})
        return DummyResponse(204)

    from notifier.plugins.discord import webhook

    monkeypatch.setattr(webhook.requests, "post", fake_post)

    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    plugin = DiscordPlugin(webhook_url)
    embed = DiscordEmbed(title="Test Title", description="Test Description")
    plugin.send("Test message", embed=embed)

    assert len(calls) == 1
    assert "embeds" in calls[0]["json"]


@pytest.mark.asyncio
async def test_discord_plugin_send_async(monkeypatch):
    """Test async send functionality."""
    import importlib.util

    if importlib.util.find_spec("httpx") is None:
        pytest.skip("httpx not installed")

    # Mock httpx.AsyncClient
    mock_client = AsyncMock()
    mock_response = DummyResponse(204, json.dumps({}))
    mock_client.post = AsyncMock(return_value=mock_response)
    mock_client.aclose = AsyncMock()

    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    with patch(
        "notifier.plugins.discord.async_webhook.httpx.AsyncClient",
        return_value=mock_client,
    ):
        plugin = DiscordPlugin(webhook_url)
        await plugin.send_async("Async test message")

    assert mock_client.post.called


@pytest.mark.asyncio
async def test_discord_plugin_send_async_fallback_to_sync(monkeypatch):
    """Test async send falls back to sync when httpx not available."""
    # Unpatch httpx if it was imported
    import sys

    if "httpx" in sys.modules:
        del sys.modules["httpx"]
    # Also remove from any parent modules
    for mod_name in list(sys.modules.keys()):
        if mod_name.startswith("httpx"):
            del sys.modules[mod_name]

    def fake_post(url, json=None, timeout=None, **kwargs):
        import json as json_module

        return DummyResponse(204, json_module.dumps({"id": "123456789"}))

    from notifier.plugins.discord import webhook

    monkeypatch.setattr(webhook.requests, "post", fake_post)

    with patch("builtins.print"):
        webhook_url = os.getenv(
            "DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde"
        )
        plugin = DiscordPlugin(webhook_url)

        # Should fallback and not raise
        await plugin.send_async("Test message")


def test_discord_plugin_send_handles_error(monkeypatch):
    """Test that send handles errors gracefully."""

    def fake_post(url, json=None, timeout=None, **kwargs):
        return DummyResponse(400, "Bad Request")

    from notifier.plugins.discord import webhook

    monkeypatch.setattr(webhook.requests, "post", fake_post)

    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    plugin = DiscordPlugin(webhook_url)

    with pytest.raises(DiscordWebhookError):
        plugin.send("Test message")


# ============================================================================
# DiscordWebhook Tests
# ============================================================================


def test_discord_webhook_initialization():
    """Test Discord webhook can be initialized."""
    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    webhook = DiscordWebhook(webhook_url=webhook_url, username="TestBot", content="Test message")

    assert webhook.webhook_url == webhook_url
    assert webhook.username == "TestBot"
    assert webhook.content == "Test message"


def test_discord_webhook_requires_url():
    """Test that webhook requires a URL."""
    with pytest.raises(DiscordWebhookValidationError):
        DiscordWebhook(webhook_url="")


def test_discord_webhook_reads_env_url():
    """Test that webhook can read URL from environment."""
    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    webhook = DiscordWebhook(webhook_url=webhook_url, content="Test")
    assert webhook.webhook_url == webhook_url


def test_discord_webhook_set_content():
    """Test setting webhook content."""
    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    webhook = DiscordWebhook(webhook_url=webhook_url)
    webhook.set_content("New content")
    assert webhook.content == "New content"


def test_discord_webhook_set_username():
    """Test setting webhook username."""
    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    webhook = DiscordWebhook(webhook_url=webhook_url)
    webhook.set_username("NewUsername")
    assert webhook.username == "NewUsername"


def test_discord_webhook_add_embed():
    """Test adding embeds to webhook."""
    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    webhook = DiscordWebhook(webhook_url=webhook_url)
    embed = DiscordEmbed(title="Test", description="Test desc")
    webhook.add_embed(embed)

    assert len(webhook.embeds) == 1
    assert webhook.embeds[0]["title"] == "Test"


def test_discord_webhook_add_embed_dict():
    """Test adding embed dictionary."""
    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    webhook = DiscordWebhook(webhook_url=webhook_url)
    webhook.add_embed({"title": "Test", "description": "Test desc"})

    assert len(webhook.embeds) == 1
    assert webhook.embeds[0]["title"] == "Test"


def test_discord_webhook_add_embed_invalid_type():
    """Test adding invalid embed type raises error."""
    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    webhook = DiscordWebhook(webhook_url=webhook_url)

    with pytest.raises(DiscordWebhookValidationError):
        webhook.add_embed("invalid")


def test_discord_webhook_add_embed_limit():
    """Test that only 10 embeds are allowed."""
    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    webhook = DiscordWebhook(webhook_url=webhook_url)

    # Add 15 embeds
    for i in range(15):
        webhook.add_embed({"title": f"Test {i}"})

    # Should only have 10
    assert len(webhook.embeds) == 10


def test_discord_webhook_build_payload():
    """Test building webhook payload."""
    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    webhook = DiscordWebhook(webhook_url=webhook_url, username="TestBot", content="Test message")

    payload = webhook._build_payload()
    assert payload["username"] == "TestBot"
    assert payload["content"] == "Test message"


def test_discord_webhook_build_payload_with_embeds():
    """Test building payload with embeds."""
    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    webhook = DiscordWebhook(webhook_url=webhook_url)
    webhook.add_embed(DiscordEmbed(title="Test"))

    payload = webhook._build_payload()
    assert "embeds" in payload
    assert len(payload["embeds"]) == 1


def test_discord_webhook_build_payload_empty_raises_error():
    """Test that empty payload raises error."""
    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    webhook = DiscordWebhook(webhook_url=webhook_url)

    with pytest.raises(DiscordWebhookValidationError):
        webhook._build_payload()


def test_discord_webhook_execute_success(monkeypatch):
    """Test successful webhook execution."""

    def fake_post(url, json=None, timeout=None, **kwargs):
        import json as json_module

        return DummyResponse(204, json_module.dumps({"id": "123456789"}))

    from notifier.plugins.discord import webhook

    monkeypatch.setattr(webhook.requests, "post", fake_post)

    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    webhook_obj = DiscordWebhook(webhook_url=webhook_url, content="Test message")

    webhook_obj.execute()
    assert webhook_obj.message_id == "123456789"


def test_discord_webhook_execute_handles_error(monkeypatch):
    """Test webhook execution handles errors."""

    def fake_post(url, json=None, timeout=None, **kwargs):
        return DummyResponse(400, "Bad Request")

    from notifier.plugins.discord import webhook

    monkeypatch.setattr(webhook.requests, "post", fake_post)

    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    webhook_obj = DiscordWebhook(webhook_url=webhook_url, content="Test message")

    with pytest.raises(DiscordWebhookError):
        webhook_obj.execute()


def test_discord_webhook_execute_rate_limit(monkeypatch):
    """Test webhook execution handles rate limiting."""
    call_count = [0]

    def fake_post(url, json=None, timeout=None, **kwargs):
        import json as json_module

        call_count[0] += 1
        if call_count[0] == 1:
            return DummyResponse(429, json_module.dumps({"retry_after": 0.1}))
        return DummyResponse(204)

    from notifier.plugins.discord import webhook

    monkeypatch.setattr(webhook.requests, "post", fake_post)

    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    webhook_obj = DiscordWebhook(
        webhook_url=webhook_url, content="Test message", rate_limit_retry=True
    )

    # Should not raise, should retry
    webhook_obj.execute()


def test_discord_webhook_execute_rate_limit_no_retry(monkeypatch):
    """Test webhook raises rate limit error when retry disabled."""

    def fake_post(url, json=None, timeout=None, **kwargs):
        import json as json_module

        return DummyResponse(429, json_module.dumps({"retry_after": 1.0}))

    from notifier.plugins.discord import webhook

    monkeypatch.setattr(webhook.requests, "post", fake_post)

    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    webhook_obj = DiscordWebhook(
        webhook_url=webhook_url, content="Test message", rate_limit_retry=False
    )

    with pytest.raises(DiscordRateLimitError):
        webhook_obj.execute()


# ============================================================================
# AsyncDiscordWebhook Tests
# ============================================================================


@pytest.mark.asyncio
async def test_async_discord_webhook_requires_httpx(monkeypatch):
    """Test that async webhook requires httpx."""
    import sys

    # Remove httpx if imported
    if "httpx" in sys.modules:
        del sys.modules["httpx"]
    # Also remove from any parent modules
    for mod_name in list(sys.modules.keys()):
        if mod_name.startswith("httpx"):
            del sys.modules[mod_name]

    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    webhook = AsyncDiscordWebhook(webhook_url=webhook_url)

    # ImportError is raised when trying to get the client, not in __init__
    with pytest.raises(ImportError):
        await webhook._get_client()


@pytest.mark.asyncio
async def test_async_discord_webhook_context_manager():
    """Test async webhook can be used as context manager."""
    import importlib.util

    if importlib.util.find_spec("httpx") is None:
        pytest.skip("httpx not installed")

    # Mock httpx.AsyncClient
    mock_client = AsyncMock()
    mock_response = DummyResponse(204, json.dumps({}))
    mock_client.post = AsyncMock(return_value=mock_response)
    mock_client.aclose = AsyncMock()

    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    with patch(
        "notifier.plugins.discord.async_webhook.httpx.AsyncClient",
        return_value=mock_client,
    ):
        webhook = AsyncDiscordWebhook(webhook_url=webhook_url, content="Test message")

        async with webhook:
            pass

        mock_client.aclose.assert_called_once()


# ============================================================================
# DiscordEmbed Tests
# ============================================================================


def test_discord_embed_initialization():
    """Test Discord embed can be initialized."""
    embed = DiscordEmbed(title="Test Title", description="Test Description")

    assert embed.title == "Test Title"
    assert embed.description == "Test Description"


def test_discord_embed_initialization_with_color():
    """Test Discord embed with color."""
    embed = DiscordEmbed(title="Test", color="#FF0000")
    assert embed.color == 16711680  # 0xFF0000

    embed2 = DiscordEmbed(title="Test2", color=16711680)
    assert embed2.color == 16711680


def test_discord_embed_to_dict():
    """Test converting embed to dictionary."""
    embed = DiscordEmbed(title="Test", description="Test desc")
    data = embed.to_dict()

    assert data["title"] == "Test"
    assert data["description"] == "Test desc"


def test_discord_embed_set_color():
    """Test setting embed color."""
    embed = DiscordEmbed()
    embed.set_color("#00FF00")

    assert embed.color == 65280  # 0x00FF00


def test_discord_embed_set_color_invalid_range():
    """Test setting invalid color raises error."""
    embed = DiscordEmbed()

    with pytest.raises(DiscordInvalidColorError):
        embed.set_color(99999999)


def test_discord_embed_set_color_invalid_format():
    """Test setting invalid color format raises error."""
    embed = DiscordEmbed()

    with pytest.raises(DiscordInvalidColorError):
        embed.set_color("not-a-color")


def test_discord_embed_set_title():
    """Test setting embed title."""
    embed = DiscordEmbed()
    embed.set_title("New Title")
    assert embed.title == "New Title"


def test_discord_embed_set_description():
    """Test setting embed description."""
    embed = DiscordEmbed()
    embed.set_description("New Description")
    assert embed.description == "New Description"


def test_discord_embed_set_url():
    """Test setting embed URL."""
    embed = DiscordEmbed()
    embed.set_url("https://example.com")
    assert embed.url == "https://example.com"


def test_discord_embed_set_timestamp():
    """Test setting embed timestamp."""
    embed = DiscordEmbed()
    embed.set_timestamp()
    assert embed.timestamp is not None


def test_discord_embed_set_timestamp_with_value():
    """Test setting embed timestamp with value."""
    import time

    embed = DiscordEmbed()
    embed.set_timestamp(time.time())
    assert embed.timestamp is not None


def test_discord_embed_add_field():
    """Test adding field to embed."""
    embed = DiscordEmbed()
    embed.add_field("Field1", "Value1", inline=True)

    assert len(embed.fields) == 1
    assert embed.fields[0]["name"] == "Field1"
    assert embed.fields[0]["value"] == "Value1"


def test_discord_embed_set_footer():
    """Test setting embed footer."""
    embed = DiscordEmbed()
    embed.set_footer("Footer text", icon_url="https://example.com/icon.png")

    assert embed.footer["text"] == "Footer text"
    assert embed.footer["icon_url"] == "https://example.com/icon.png"


def test_discord_embed_set_thumbnail():
    """Test setting embed thumbnail."""
    embed = DiscordEmbed()
    embed.set_thumbnail("https://example.com/thumb.png")

    assert embed.thumbnail["url"] == "https://example.com/thumb.png"


def test_discord_embed_set_image():
    """Test setting embed image."""
    embed = DiscordEmbed()
    embed.set_image("https://example.com/image.png")

    assert embed.image["url"] == "https://example.com/image.png"


def test_discord_embed_set_author():
    """Test setting embed author."""
    embed = DiscordEmbed()
    embed.set_author(
        "Author Name",
        url="https://example.com",
        icon_url="https://example.com/icon.png",
    )

    assert embed.author["name"] == "Author Name"
    assert embed.author["url"] == "https://example.com"
    assert embed.author["icon_url"] == "https://example.com/icon.png"


def test_discord_embed_chaining():
    """Test that embed methods support method chaining."""
    embed = (
        DiscordEmbed()
        .set_title("Test")
        .set_description("Desc")
        .add_field("F1", "V1")
        .set_color("#FF0000")
    )

    assert embed.title == "Test"
    assert embed.description == "Desc"
    assert len(embed.fields) == 1
    assert embed.color == 16711680


# ============================================================================
# Integration Tests
# ============================================================================


def test_plugin_integration_with_webhook_and_embed(monkeypatch):
    """Test full integration of plugin, webhook, and embed."""
    calls = []

    def fake_post(url, json=None, timeout=None, **kwargs):
        calls.append(json)
        return DummyResponse(204)

    from notifier.plugins.discord import webhook

    monkeypatch.setattr(webhook.requests, "post", fake_post)

    webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/12345/abcde")
    plugin = DiscordPlugin(webhook_url)

    embed = DiscordEmbed(
        title="Test Title", description="Test Description", color="#FF0000"
    ).add_field("Status", "Success")

    plugin.send("Main message", detail={"key": "value"}, embed=embed)

    assert len(calls) == 1
    payload = calls[0]
    assert "embeds" in payload
    assert payload["embeds"][0]["title"] == "Test Title"
    assert len(payload["embeds"][0]["fields"]) == 1
