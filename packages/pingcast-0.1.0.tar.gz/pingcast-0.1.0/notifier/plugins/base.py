import asyncio
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional


class BasePlugin(ABC):
    """Abstract base class for notifier plugins."""

    @abstractmethod
    def send(self, message: str, detail: Optional[Dict[str, Any]] = None) -> None:
        """Send a notification message (synchronous)."""
        raise NotImplementedError

    async def send_async(self, message: str, detail: Optional[Dict[str, Any]] = None) -> None:
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self.send, message, detail)
