"""Custom exceptions for Discord webhook operations."""


class DiscordWebhookError(Exception):
    """Base exception for Discord webhook errors."""

    pass


class DiscordWebhookValidationError(DiscordWebhookError):
    """Raised when webhook validation fails."""

    pass


class DiscordRateLimitError(DiscordWebhookError):
    """Raised when rate limit is exceeded."""

    pass


class DiscordInvalidColorError(DiscordWebhookError):
    """Raised when embed color is invalid."""

    def __init__(self, color: object, message: "str | None" = None) -> None:
        if not message:
            message = (
                f"Color {color!r} is not valid. "
                "Valid colors are integers from 0 to 16777215 (0x000000 to 0xFFFFFF)"
            )
        super().__init__(message)
        self.color = color
