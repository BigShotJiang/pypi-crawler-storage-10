"""Discord plugin for sending notifications via webhooks."""

from typing import List, Optional, Union

from .async_webhook import AsyncDiscordWebhook
from .embed import DiscordEmbed
from .exceptions import (
    DiscordInvalidColorError,
    DiscordRateLimitError,
    DiscordWebhookError,
    DiscordWebhookValidationError,
)
from .webhook import DiscordWebhook

__all__ = [
    "DiscordPlugin",
    "DiscordWebhook",
    "AsyncDiscordWebhook",
    "DiscordEmbed",
    "DiscordWebhookError",
    "DiscordWebhookValidationError",
    "DiscordRateLimitError",
    "DiscordInvalidColorError",
]

from notifier.plugins.base import BasePlugin


class DiscordPlugin(BasePlugin):
    """
    Plugin to send notifications to Discord via webhook.

    Supports both synchronous and asynchronous sending with rich embed support.
    """

    def __init__(self, webhook_url: str, username: str = "NotifierBot"):
        """
        Initialize the DiscordPlugin.

        Args:
            webhook_url: The Discord webhook URL
            username: Optional username override for the webhook
        """
        super().__init__()
        self.webhook_url = webhook_url
        self.username = username

    def send(
        self,
        message: str,
        detail: Optional[dict] = None,
        embed: Optional[Union[dict, List[dict], DiscordEmbed]] = None,
    ) -> None:
        """
        Send a notification to Discord synchronously.

        Args:
            message: Main message text
            detail: Optional dict of additional details to append
            embed: Optional embed object or dict/list of embed dicts
        """
        # Create webhook client
        webhook = DiscordWebhook(
            webhook_url=self.webhook_url, username=self.username, content=message
        )

        # Add detail lines to content
        if detail:
            detail_lines = [f"{key}: {value}" for key, value in detail.items()]
            content_with_detail = message + "\n" + "\n".join(detail_lines)
            webhook.set_content(content_with_detail)

        # Add embed(s)
        if embed:
            # Convert dict(s) to DiscordEmbed or add directly
            if isinstance(embed, dict):
                webhook.add_embed(embed)
            elif isinstance(embed, list):
                for emb in embed:
                    webhook.add_embed(emb)
            elif isinstance(embed, DiscordEmbed):
                webhook.add_embed(embed.to_dict())

        # Execute and handle result
        try:
            webhook.execute()
            print("[Notifier] Discord message sent successfully")
        except Exception as e:
            print(f"[Notifier] Failed to send Discord notification: {e}")
            raise

    async def send_async(
        self,
        message: str,
        detail: Optional[dict] = None,
        embed: Optional[Union[dict, List[dict], DiscordEmbed]] = None,
    ) -> None:
        """
        Send a notification to Discord asynchronously.

        Args:
            message: Main message text
            detail: Optional dict of additional details to append
            embed: Optional embed object or dict/list of embed dicts
        """
        # Check for httpx availability
        try:
            import httpx  # noqa: F401
        except ImportError:
            # Fallback to base implementation if httpx not available
            print("[Notifier] httpx not available, falling back to sync execution")
            await super().send_async(message, detail)
            return

        # Create async webhook client
        webhook = AsyncDiscordWebhook(
            webhook_url=self.webhook_url, username=self.username, content=message
        )

        try:
            # Add detail lines
            if detail:
                detail_lines = [f"{key}: {value}" for key, value in detail.items()]
                content_with_detail = message + "\n" + "\n".join(detail_lines)
                webhook.set_content(content_with_detail)

            # Add embed(s)
            if embed:
                if isinstance(embed, dict):
                    webhook.add_embed(embed)
                elif isinstance(embed, list):
                    for emb in embed:
                        webhook.add_embed(emb)
                elif isinstance(embed, DiscordEmbed):
                    webhook.add_embed(embed.to_dict())

            # Execute
            await webhook.execute()
            print("[Notifier] Discord message sent successfully (async)")
        except Exception as e:
            print(f"[Notifier] Failed to send async Discord notification: {e}")
            raise
        finally:
            await webhook.close()
