"""Asynchronous Discord webhook implementation."""

import asyncio
import json
from typing import Any, Dict, Optional

from .exceptions import DiscordRateLimitError, DiscordWebhookError
from .webhook import DiscordWebhook


class AsyncDiscordWebhook(DiscordWebhook):
    """Asynchronous Discord webhook client using httpx."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """Initialize async webhook client."""
        super().__init__(*args, **kwargs)
        self._client: Optional[Any] = None

    async def _get_client(self) -> Any:
        """Get or create httpx client."""
        # Lazy import to keep httpx optional at runtime
        try:
            import httpx  # noqa: PLC0415
        except ImportError:
            raise ImportError(
                "httpx is required for async webhooks. Install it with: pip install httpx"
            ) from None

        if self._client is None:
            if self.proxies:
                # httpx AsyncClient uses 'proxy' for a single proxy or mounts for per-scheme
                self._client = httpx.AsyncClient(proxy=self.proxies, timeout=self.timeout)
            else:
                self._client = httpx.AsyncClient(timeout=self.timeout)
        return self._client

    async def close(self) -> None:
        """Close the httpx client."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def _execute_request(self) -> Any:
        """Execute the HTTP request asynchronously."""

        payload = self._build_payload()
        client = await self._get_client()

        print(
            f"[Notifier] Sending async to Discord webhook (URL ends with: ...{self.webhook_url[-20:]})"
        )

        return await client.post(self.webhook_url, json=payload)

    async def _handle_rate_limit(self, response: Any) -> Any:  # type: ignore[override]
        """Handle rate limit by retrying after delay (async)."""

        while response.status_code == 429:
            try:
                error_data = json.loads(response.content)
                retry_after = float(error_data.get("retry_after", 1.0)) + 0.15
            except (ValueError, json.JSONDecodeError):
                retry_after = 1.15

            print(f"[Notifier] Rate limited, retrying after {retry_after:.2f}s...")
            await asyncio.sleep(retry_after)
            response = await self._execute_request()

            if response.status_code in (200, 204):
                return response

        return response

    async def execute(self) -> Dict[str, Any]:  # type: ignore[override]
        """
        Execute the webhook asynchronously and send the message.

        Returns:
            Response data as dictionary

        Raises:
            DiscordWebhookError: If the request fails
            DiscordRateLimitError: If rate limited and retry is disabled
        """

        response = await self._execute_request()

        # Handle rate limiting
        if response.status_code == 429:
            if self.rate_limit_retry:
                response = await self._handle_rate_limit(response)
            else:
                raise DiscordRateLimitError(
                    "Rate limit exceeded. Enable rate_limit_retry to auto-retry."
                )

        # Handle errors
        if response.status_code >= 400:
            try:
                error_text = await response.aread()
                error_text = error_text.decode("utf-8")
            except Exception:
                error_text = "Unknown error"

            print(f"[Notifier] Discord error {response.status_code}: {error_text}")
            raise DiscordWebhookError(f"Discord API error {response.status_code}: {error_text}")

        print(f"[Notifier] Discord async response: {response.status_code}")

        # Extract message ID if available
        response_data: Dict[str, Any] = {}
        try:
            content = await response.aread()
            response_data = json.loads(content) if content else {}
            self.message_id = response_data.get("id")
        except (ValueError, json.JSONDecodeError):
            pass

        return response_data if response_data else {}

    async def __aenter__(self) -> "AsyncDiscordWebhook":
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Async context manager exit."""
        await self.close()
