"""Discord embed data structure for rich messages."""

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from .exceptions import DiscordInvalidColorError


class DiscordEmbed:
    """Represents a Discord embed object with various formatting options."""

    def __init__(
        self,
        title: Optional[str] = None,
        description: Optional[str] = None,
        color: Optional[Union[str, int]] = None,
        **kwargs: Any,
    ):
        """
        Initialize a Discord embed.

        Args:
            title: Embed title
            description: Embed description
            color: Color as hex string (e.g., "#FF0000") or integer
            **kwargs: Additional embed fields like url, timestamp, etc.
        """
        self.title = title
        self.description = description
        self.url = kwargs.get("url")
        self.color = self._parse_color(color)
        self.timestamp = kwargs.get("timestamp")
        self.footer = kwargs.get("footer")
        self.image = kwargs.get("image")
        self.thumbnail = kwargs.get("thumbnail")
        self.author = kwargs.get("author")
        self.fields: List[Dict[str, Any]] = kwargs.get("fields", [])

        # Auto-set timestamp if not provided
        if kwargs.get("auto_timestamp"):
            self.set_timestamp()

    def _parse_color(self, color: Optional[Union[str, int]]) -> Optional[int]:
        """Parse color from various formats to integer."""
        if color is None:
            return None

        if isinstance(color, str):
            # Remove # if present
            color = color.strip("#")
            return int(color, 16)

        return color

    def set_color(self, color: Union[str, int]) -> "DiscordEmbed":
        """Set the embed color."""
        try:
            self.color = self._parse_color(color)
            # Validate color range
            if self.color is not None and not (0 <= self.color <= 16777215):
                raise DiscordInvalidColorError(self.color)
        except (ValueError, TypeError) as e:
            raise DiscordInvalidColorError(color) from e

        return self

    def set_title(self, title: str) -> "DiscordEmbed":
        """Set the embed title."""
        self.title = title
        return self

    def set_description(self, description: str) -> "DiscordEmbed":
        """Set the embed description."""
        self.description = description
        return self

    def set_url(self, url: str) -> "DiscordEmbed":
        """Set the embed URL (makes title clickable)."""
        self.url = url
        return self

    def set_timestamp(
        self, timestamp: Optional[Union[datetime, float, str]] = None
    ) -> "DiscordEmbed":
        """Set the embed timestamp."""
        if timestamp is None:
            timestamp = datetime.now(timezone.utc)
        elif isinstance(timestamp, (float, int)):
            timestamp = datetime.fromtimestamp(timestamp, timezone.utc)

        self.timestamp = (
            timestamp.isoformat() if isinstance(timestamp, datetime) else str(timestamp)
        )
        return self

    def add_field(self, name: str, value: str, inline: bool = True) -> "DiscordEmbed":
        """Add a field to the embed."""
        self.fields.append({"name": name, "value": value, "inline": inline})
        return self

    def set_footer(self, text: str, icon_url: Optional[str] = None) -> "DiscordEmbed":
        """Set the embed footer."""
        self.footer = {"text": text}
        if icon_url:
            self.footer["icon_url"] = icon_url
        return self

    def set_thumbnail(self, url: str) -> "DiscordEmbed":
        """Set the embed thumbnail."""
        self.thumbnail = {"url": url}
        return self

    def set_image(self, url: str) -> "DiscordEmbed":
        """Set the embed image."""
        self.image = {"url": url}
        return self

    def set_author(
        self, name: str, url: Optional[str] = None, icon_url: Optional[str] = None
    ) -> "DiscordEmbed":
        """Set the embed author."""
        self.author = {"name": name}
        if url:
            self.author["url"] = url
        if icon_url:
            self.author["icon_url"] = icon_url
        return self

    def to_dict(self) -> Dict[str, Any]:
        """Convert embed to dictionary for API payload."""
        data: Dict[str, Any] = {}

        if self.title:
            data["title"] = self.title
        if self.description:
            data["description"] = self.description
        if self.url:
            data["url"] = self.url
        if self.color is not None:
            data["color"] = self.color
        if self.timestamp:
            data["timestamp"] = self.timestamp
        if self.footer:
            data["footer"] = self.footer
        if self.image:
            data["image"] = self.image
        if self.thumbnail:
            data["thumbnail"] = self.thumbnail
        if self.author:
            data["author"] = self.author
        if self.fields:
            data["fields"] = self.fields

        return data
