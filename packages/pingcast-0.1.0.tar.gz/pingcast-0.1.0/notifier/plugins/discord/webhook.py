"""Core Discord webhook implementation with synchronous HTTP requests."""

import json
import time
from typing import Any, Dict, List, Optional, Union

import requests

from .embed import DiscordEmbed
from .exceptions import (
    DiscordRateLimitError,
    DiscordWebhookError,
    DiscordWebhookValidationError,
)


class DiscordWebhook:
    """Synchronous Discord webhook client."""

    def __init__(
        self,
        webhook_url: str,
        username: Optional[str] = None,
        content: Optional[str] = None,
        embeds: Optional[List[Union[DiscordEmbed, Dict[str, Any]]]] = None,
        **kwargs: Any,
    ):
        """
        Initialize a Discord webhook client.

        Args:
            webhook_url: The Discord webhook URL
            username: Override the default webhook username
            content: Message content
            embeds: List of embed objects or dictionaries
            **kwargs: Additional webhook parameters (tts, wait, etc.)
        """
        if not webhook_url:
            raise DiscordWebhookValidationError("Webhook URL is required")

        self.webhook_url = webhook_url
        self.username = username
        self.content = content
        self.embeds: List[Dict[str, Any]] = []
        self.tts = kwargs.get("tts", False)
        self.wait = kwargs.get("wait", True)
        self.timeout = kwargs.get("timeout", 5.0)
        self.rate_limit_retry = kwargs.get("rate_limit_retry", False)
        self.proxies = kwargs.get("proxies")

        # Store message ID for edit/delete operations
        self.message_id: Optional[str] = None

        # Add initial embeds
        if embeds:
            for embed in embeds:
                self.add_embed(embed)

    def add_embed(self, embed: Union[DiscordEmbed, Dict[str, Any]]) -> "DiscordWebhook":
        """Add an embed to the webhook."""
        if isinstance(embed, DiscordEmbed):
            self.embeds.append(embed.to_dict())
        elif isinstance(embed, dict):
            self.embeds.append(embed)
        else:
            raise DiscordWebhookValidationError("Embed must be DiscordEmbed or dict")

        # Discord limits to 10 embeds max
        if len(self.embeds) > 10:
            self.embeds = self.embeds[:10]

        return self

    def set_content(self, content: str) -> "DiscordWebhook":
        """Set the message content."""
        self.content = content
        return self

    def set_username(self, username: str) -> "DiscordWebhook":
        """Set the webhook username."""
        self.username = username
        return self

    def _build_payload(self) -> Dict[str, Any]:
        """Build the payload for the webhook request."""
        payload: Dict[str, Any] = {}

        # Content
        if self.content:
            payload["content"] = self.content

        # Embeds
        if self.embeds:
            payload["embeds"] = self.embeds

        # Username
        if self.username:
            payload["username"] = self.username

        # TTS
        if self.tts:
            payload["tts"] = True

        # Validate that payload is not empty
        if not payload or (not payload.get("content") and not payload.get("embeds")):
            raise DiscordWebhookValidationError(
                "Webhook payload is empty. Provide at least content or embeds."
            )

        return payload

    def _handle_rate_limit(self, response: requests.Response) -> requests.Response:
        """Handle rate limit by retrying after delay."""
        while response.status_code == 429:
            try:
                error_data = response.json()
                retry_after = float(error_data.get("retry_after", 1.0)) + 0.15
            except (ValueError, json.JSONDecodeError):
                retry_after = 1.15

            print(f"[Notifier] Rate limited, retrying after {retry_after:.2f}s...")
            time.sleep(retry_after)
            response = self._execute_request()

            if response.status_code in (200, 204):
                return response

        return response

    def _execute_request(self) -> Any:
        """Execute the HTTP request."""
        payload = self._build_payload()

        print(f"[Notifier] Sending to Discord webhook (URL ends with: ...{self.webhook_url[-20:]})")
        print(f"[Notifier] Payload keys: {list(payload.keys())}")

        return requests.post(
            self.webhook_url, json=payload, timeout=self.timeout, proxies=self.proxies
        )

    def execute(self) -> Dict[str, Any]:
        """
        Execute the webhook and send the message.

        Returns:
            Response data as dictionary

        Raises:
            DiscordWebhookError: If the request fails
            DiscordRateLimitError: If rate limited and retry is disabled
        """
        response = self._execute_request()

        # Handle rate limiting
        if response.status_code == 429:
            if self.rate_limit_retry:
                response = self._handle_rate_limit(response)
            else:
                raise DiscordRateLimitError(
                    "Rate limit exceeded. Enable rate_limit_retry to auto-retry."
                )

        # Handle errors
        if response.status_code >= 400:
            try:
                error_text = response.text
            except:
                error_text = "Unknown error"

            print(f"[Notifier] Discord error {response.status_code}: {error_text}")
            raise DiscordWebhookError(f"Discord API error {response.status_code}: {error_text}")

        print(f"[Notifier] Discord response: {response.status_code}")

        # Extract message ID if available
        response_data: Dict[str, Any] = {}
        try:
            response_data = response.json()
            self.message_id = response_data.get("id")
        except (ValueError, json.JSONDecodeError, AttributeError):
            pass

        return response_data if response.content else {}
