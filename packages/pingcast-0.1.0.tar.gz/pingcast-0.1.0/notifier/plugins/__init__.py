# Plugins subpackage
from .discord import DiscordPlugin as Discord  # noqa: F401

# Note: discord is now a subdirectory with modular structure
