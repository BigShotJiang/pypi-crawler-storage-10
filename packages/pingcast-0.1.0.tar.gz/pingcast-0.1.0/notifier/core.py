import asyncio
import atexit
import logging
import sys
import threading
import traceback
from typing import Any, Dict, List, Optional, no_type_check

from notifier.plugins.base import BasePlugin
from notifier.plugins.discord import DiscordPlugin


class Notifier:
    """Main notifier class to manage notifications across configured plugins."""

    def __init__(self, *plugins: BasePlugin, **plugin_configs: Any):
        """
        Initialize Notifier with plugin instances or legacy config.

        New style:
            from notifier import Discord, Notifier
            discord = Discord('webhook url')
            notify = Notifier(discord)

        Legacy style (still supported):
            notify = Notifier(discord='webhook url')
        """
        self.plugins: List[BasePlugin] = []
        self._monitoring = False
        self._heartbeat_thread: Optional[threading.Thread] = None
        self._stop_event: Any = None
        self._failure_flag = False

        # New style: accept plugin instances
        for plugin in plugins:
            if hasattr(plugin, "send"):
                self.plugins.append(plugin)
            else:
                raise ValueError(f"Invalid plugin: {plugin}. Plugins must have a 'send' method.")

        # Legacy style: accept config dicts
        if "discord" in plugin_configs and plugin_configs["discord"]:
            url = plugin_configs["discord"]
            self.plugins.append(DiscordPlugin(url))

        if not self.plugins:
            raise ValueError(
                "Notifier must be initialized with at least one plugin. "
                "New style: Notifier(Discord('url')) "
                "Legacy style: Notifier(discord='url')"
            )

    def send(self, message: str, detail: Optional[Dict[str, Any]] = None) -> None:
        for plugin in self.plugins:
            try:
                plugin.send(message, detail)
                print(f"[Notifier] Successfully sent via {plugin.__class__.__name__}")
            except Exception as exc:
                print(f"[Notifier] Error sending through plugin {plugin.__class__.__name__}: {exc}")
                traceback.print_exc()

    async def send_async(self, message: str, detail: Optional[Dict[str, Any]] = None) -> None:
        tasks: List[Any] = []
        for plugin in self.plugins:
            try:
                coro = plugin.send_async(message, detail)
                if coro:
                    tasks.append(coro)
            except Exception as exc:
                print(f"[Notifier] Error scheduling async send for {plugin}: {exc}")
        if tasks:
            await asyncio.gather(*tasks)

    def everything(self, filter: Optional[Dict[str, Any]] = None, interval: int = 900) -> None:
        if self._monitoring:
            return
        self._monitoring = True

        log_level = logging.INFO
        if filter and "level" in filter:
            level_name = str(filter["level"]).upper()
            log_level = getattr(logging, level_name, logging.INFO)
        handler = _NotifierLogHandler(self)
        handler.setLevel(log_level)
        formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
        handler.setFormatter(formatter)
        root_logger = logging.getLogger()
        if root_logger.level > log_level:
            root_logger.setLevel(log_level)
        root_logger.addHandler(handler)

        self._stop_event = threading.Event()

        def _heartbeat_loop() -> None:
            while not self._stop_event.wait(interval):
                self.send(f"Status: still running after {interval} seconds...")

        self._heartbeat_thread = threading.Thread(target=_heartbeat_loop, daemon=True)
        self._heartbeat_thread.start()

        @atexit.register
        def _on_exit() -> None:
            if not self._failure_flag:
                self.send("✅ Task completed successfully!")
            if self._stop_event:
                self._stop_event.set()

        self._original_excepthook = sys.excepthook

        def _exception_hook(exc_type: Any, exc_value: Any, exc_tb: Any) -> None:
            self._failure_flag = True
            self.send(f"❌ Task failed with error: {exc_value}")
            if self._original_excepthook is not None:
                self._original_excepthook(exc_type, exc_value, exc_tb)

        sys.excepthook = _exception_hook


class _NotifierLogHandler(logging.Handler):
    def __init__(self, notifier: "Notifier") -> None:
        super().__init__()
        self.notifier = notifier

    def emit(self, record: logging.LogRecord) -> None:
        try:
            log_msg = self.format(record)
        except Exception:
            log_msg = record.getMessage()
        msg = f"[log]{record.levelname}: {log_msg}"
        self.notifier.send(msg)


# Async variant


class AsyncNotifier(Notifier):
    def __init__(self, *plugins: BasePlugin, **plugin_configs: Any):
        super().__init__(*plugins, **plugin_configs)

    async def send(self, message: str, detail: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
        await self.send_async(message, detail)

    def send_blocking(self, message: str, detail: Optional[Dict[str, Any]] = None) -> None:
        super().send(message, detail)

    @no_type_check
    async def everything(
        self, filter: Optional[Dict[str, Any]] = None, interval: int = 900
    ) -> None:
        if self._monitoring:
            return
        self._monitoring = True

        log_level = logging.INFO
        if filter and "level" in filter:
            level_name = str(filter["level"]).upper()
            log_level = getattr(logging, level_name, logging.INFO)
        handler = _NotifierLogHandler(self)  # uses send_blocking via emit
        handler.setLevel(log_level)
        formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
        handler.setFormatter(formatter)
        root_logger = logging.getLogger()
        if root_logger.level > log_level:
            root_logger.setLevel(log_level)
        root_logger.addHandler(handler)

        self._stop_event = asyncio.Event()

        async def heartbeat_loop() -> None:
            while True:
                try:
                    await asyncio.wait_for(self._stop_event.wait(), timeout=interval)
                    break
                except asyncio.TimeoutError:
                    await self.send(f"Status: still running after {interval} seconds...")
                    continue

        asyncio.create_task(heartbeat_loop())

        @atexit.register
        def _on_exit_async() -> None:
            if not self._failure_flag:
                self.send_blocking("✅ Task completed successfully!")
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    loop.call_soon_threadsafe(lambda: self._stop_event.set())
            except RuntimeError:
                pass

        self._original_excepthook = sys.excepthook

        def _exception_hook(exc_type: Any, exc_value: Any, exc_tb: Any) -> None:
            self._failure_flag = True
            self.send_blocking(f"❌ Task failed with error: {exc_value}")
            if self._original_excepthook is not None:
                self._original_excepthook(exc_type, exc_value, exc_tb)

        sys.excepthook = _exception_hook
