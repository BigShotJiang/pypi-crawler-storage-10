import Gui_creater as gc
root=gc.Windows()
root.add("-Window",name="1")
root.add("-Text","2",father_name="1",placewhere=("place",{"x":0,"y":0}),args={"text":"HELLO_GUI(你好，GUI)","bg":"red"})
root.add("-Button","3",father_name="1",placewhere=("place",{"x":100,"y":0}),args={"text":"HELLO(你好)","bg":"blue","command":lambda:print("HELLO GUI!")})
