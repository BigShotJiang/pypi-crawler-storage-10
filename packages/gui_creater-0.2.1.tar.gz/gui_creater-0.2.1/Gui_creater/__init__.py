from Gui_creater.gui_creater import *
from Gui_creater.gui_easily import *
def Create_new_widget():
    import Gui_creater.upload
