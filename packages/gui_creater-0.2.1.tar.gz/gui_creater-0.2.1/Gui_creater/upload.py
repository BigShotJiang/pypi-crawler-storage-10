import socket
import tkinter
def tkinter_running(data):
    import tkinter as tk
    root=tk.Tk()
    root.title("发送新控件")
    root.geometry("200x200")
    button=tk.Button(root,text="发送并更新扩展控件",command=lambda:start_client(root,mss=data))
    button.pack()
    root.mainloop()
 
def start_client(master:tkinter.Tk,host='192.168.1.8', port=65432,mss:str=""):
    import tkinter.messagebox as ms
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
            client_socket.connect((host, port))
            message = "add"
            client_socket.sendall(message.encode())
            message = mss
            import time
            time.sleep(2)
            client_socket.sendall(message.encode())
            data = client_socket.recv(1024)
            print(data)
            if data.decode()=="add finish @ code 1":
                ms.showinfo("提示","上传成功")
            else:
                ms.showinfo("提示","上传失败，请重试")
                return
            message = "get"
            client_socket.sendall(message.encode())
            data = client_socket.recv(1024)
            file_string=data.decode()
            with open("widget_data.py",mode="w") as f:
                f.write(file_string)
            ms.showinfo("提示","更新成功")
            client_socket.close()
            master.destroy()
            print("Connection closed.")
    except:
        ms.showerror("提示","服务器未工作，请换个时间再试")  

 
def upgrade(host='192.168.1.8', port=65432):
    import tkinter.messagebox as ms
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
            client_socket.connect((host, port))
            message = "get"
            client_socket.sendall(message.encode())
            data = client_socket.recv(1024)
            file_string=data.decode()
            with open("widget_data.py",mode="w",encoding="utf-8") as f:
                f.write(file_string)
            ms.showinfo("提示","更新成功")
            client_socket.close()
            print("Connection closed.")
    except:
        ms.showerror("提示","服务器未工作，请换个时间再试")

import Gui_creater.gui_creater as gc
import Gui_creater.gui_easily as ge

def Create_new_widget():
    def onbd():
        tkinter_running(root.run("inp","-get","1.0","end-1c"))
    def onb():
        try:
            dir=ge.openafileasdir()
            with open(dir,mode="r",encoding="utf-8") as f:
                data=f.read()
                root.run("inp","-insert","insert",data)
        except:
            ge.textbox("提示","未正确打开需要上传的控件的Gui-creater程序")
    root = gc.Windows()
    root.add("-Window","root")
    root.run("root","-geometry","600x500")
    root.run("root","-title","控件设计")
    root.add("-Text","txt","root",args={"text":"请输入程序"})
    root.add("-Button","b","root",placewhere=("pack",{"side":gc.UP}),args={"text":"打开文件","command":onb})
    root.add("-Button","bt","root",placewhere=("pack",{"side":gc.UP}),args={"text":"上传","command":onbd})
    root.add("-Input","inp","root",placewhere=("pack",{"side":gc.LEFT}),args={"width":80,"height":30})
    root.add("-Scrollbar","scb","root",placewhere=("pack",{"side":gc.RIGHT,"fill":"y"}),args={"command":
                                                                                            root.get_attr("inp","-yview")})
    root.run("inp","-configure",yscrollcommand=root.get_attr("scb","-set"))
    root.start()

Create_new_widget()

