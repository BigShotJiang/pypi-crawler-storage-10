# UCam FaaS Library

This project contains a support library and base Docker image to be used to
create Function as a Service (FaaS) applications intended to be deployed to a
GCP cloud run environment.

It is highly opinionated and non-configurable by design.

See the [full documentation][1] for more information.

[1]: https://uis.uniofcam.dev/devops/lib/ucam-faas-python/
