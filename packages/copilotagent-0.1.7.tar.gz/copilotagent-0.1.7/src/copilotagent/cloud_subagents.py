"""Cloud subagents using LangGraph Cloud deployed services.

This module provides factory functions for creating CompiledSubAgent instances
that connect to deployed LangGraph Cloud services via LangGraph SDK client.
"""

import logging
import os
from pathlib import Path
from typing import Any, TypedDict

from dotenv import load_dotenv
from langchain_core.runnables import Runnable
from langgraph_sdk import get_client

# Set up logging
logger = logging.getLogger(__name__)

# Try to load .env from multiple possible locations
env_locations = [
    Path.cwd() / ".env",  # Current working directory
    Path(__file__).parent.parent.parent.parent / ".env",  # copilot/.env
    Path(__file__).parent.parent.parent.parent / "agents" / "ITP-Princeton" / ".env",  # ITP-Princeton/.env
]

for env_path in env_locations:
    if env_path.exists():
        logger.info(f"Loading .env from: {env_path}")
        load_dotenv(env_path)
        break
else:
    logger.warning(f"No .env file found in any of these locations: {env_locations}")


class RemoteGraphRunnable(Runnable):
    """Wrapper to make LangGraph SDK client work as a Runnable.
    
    This adapter allows the new LangGraph SDK client API to work with
    the existing Runnable interface expected by SubAgentMiddleware.
    """
    
    def __init__(self, url: str, api_key: str, graph_id: str):
        """Initialize the remote graph runnable.
        
        Args:
            url: The URL of the deployed LangGraph service
            api_key: The API key for authentication
            graph_id: The graph ID to use (assistant_id)
        """
        self.url = url
        self.api_key = api_key
        self.graph_id = graph_id
        self._client = None
    
    @property
    def client(self):
        """Lazy initialization of the client."""
        if self._client is None:
            self._client = get_client(url=self.url, api_key=self.api_key)
        return self._client
    
    def invoke(self, input: dict[str, Any], config: dict[str, Any] | None = None) -> dict[str, Any]:
        """Synchronously invoke the remote graph.
        
        Args:
            input: The input state dictionary
            config: Optional configuration
            
        Returns:
            The final state from the remote graph execution
        """
        import asyncio
        return asyncio.run(self.ainvoke(input, config))
    
    async def ainvoke(self, input: dict[str, Any], config: dict[str, Any] | None = None) -> dict[str, Any]:
        """Asynchronously invoke the remote graph.
        
        Args:
            input: The input state dictionary
            config: Optional configuration
            
        Returns:
            The final state from the remote graph execution
        """
        # Use the runs.wait method to execute and wait for completion
        result = await self.client.runs.wait(
            thread_id=None,  # Create a new thread for each invocation
            assistant_id=self.graph_id,
            input=input,
        )
        # Return the final state from the result
        return result


class CompiledSubAgent(TypedDict):
    """A pre-compiled agent spec."""

    name: str
    """The name of the agent."""

    description: str
    """The description of the agent."""

    runnable: Runnable
    """The Runnable to use for the agent."""


def get_cute_linear_subagent() -> CompiledSubAgent:
    """Get cuteLinear cloud subagent for GUI data extraction.

    This agent performs automated GUI data extraction including:
    - Multi-step GUI navigation
    - Screenshot capture
    - OCR via AWS Textract
    - AI-powered name normalization
    - Human-in-the-loop review
    - SharedState reporting

    Returns:
        CompiledSubAgent dictionary with RemoteGraph runnable.
        
    Raises:
        ValueError: If API key environment variable is not set.
    """
    # Try multiple environment variable names (LangChain uses different names in different contexts)
    api_key = (
        os.getenv("LANGCHAIN_API_KEY") or 
        os.getenv("LANGSMITH_API_KEY") or 
        os.getenv("LANGGRAPH_API_KEY")
    )
    
    # Log environment variable status for debugging
    logger.info(f"LANGCHAIN_API_KEY present: {bool(os.getenv('LANGCHAIN_API_KEY'))}")
    logger.info(f"LANGSMITH_API_KEY present: {bool(os.getenv('LANGSMITH_API_KEY'))}")
    logger.info(f"LANGGRAPH_API_KEY present: {bool(os.getenv('LANGGRAPH_API_KEY'))}")
    logger.info(f"Current working directory: {Path.cwd()}")
    logger.info(f"All env vars with 'LANG': {[k for k in os.environ.keys() if 'LANG' in k]}")
    
    if not api_key:
        msg = (
            "API key environment variable is required for cloud subagents. "
            "Please ensure .env file exists with one of: LANGCHAIN_API_KEY, LANGSMITH_API_KEY, or LANGGRAPH_API_KEY. "
            f"Checked locations: {env_locations}"
        )
        logger.error(msg)
        raise ValueError(msg)

    logger.info(f"Creating RemoteGraphRunnable for cute-linear with API key: {api_key[:10]}...")
    client = RemoteGraphRunnable(
        url="https://cutelineargraph-ef1ae523c24e51ef94e330929a65833b.us.langgraph.app",
        api_key=api_key,
        graph_id="cuteLinearGraph",
    )

    return {
        "name": "cute-linear",
        "description": (
            "Coordinated Data Extraction Agent - Performs automated GUI data extraction "
            "including navigation, OCR via AWS Textract, and AI-powered name normalization. "
            "Extracts borrower names from GUI interface, sends for human review, and reports "
            "results back. Use this agent when you need to extract borrower names from the "
            "GUI system."
        ),
        "runnable": client,
    }


def get_cute_finish_itp_subagent() -> CompiledSubAgent:
    """Get cuteFinishITP cloud subagent for GUI automation.

    This agent executes a 25-step workflow for ITP document processing including:
    - Popup detection and handling
    - Form field navigation and filling
    - Document verification
    - Final document submission
    - Screenshot capture for verification

    Returns:
        CompiledSubAgent dictionary with RemoteGraph runnable.
        
    Raises:
        ValueError: If API key environment variable is not set.
    """
    # Try multiple environment variable names (LangChain uses different names in different contexts)
    api_key = (
        os.getenv("LANGCHAIN_API_KEY") or 
        os.getenv("LANGSMITH_API_KEY") or 
        os.getenv("LANGGRAPH_API_KEY")
    )
    
    # Log environment variable status for debugging
    logger.info(f"API key present: {bool(api_key)}")
    
    if not api_key:
        msg = (
            "API key environment variable is required for cloud subagents. "
            "Please ensure .env file exists with one of: LANGCHAIN_API_KEY, LANGSMITH_API_KEY, or LANGGRAPH_API_KEY. "
            f"Checked locations: {env_locations}"
        )
        logger.error(msg)
        raise ValueError(msg)

    logger.info(f"Creating RemoteGraphRunnable for cute-finish-itp with API key: {api_key[:10]}...")
    client = RemoteGraphRunnable(
        url="https://cutefinishitp-2d3fcf81a7e55dd09a66354c5c2b567c.us.langgraph.app",
        api_key=api_key,
        graph_id="cuteFinishITP",
    )

    return {
        "name": "cute-finish-itp",
        "description": (
            "Encompass GUI Automation Agent - Executes a 25-step workflow for ITP document "
            "processing including popup detection, form filling, document verification, and "
            "final submission. Use this agent when you need to complete the ITP document "
            "processing workflow in the Encompass GUI system."
        ),
        "runnable": client,
    }

