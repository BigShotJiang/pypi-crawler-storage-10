"""
EvenAge - A small-surface, high-abstraction distributed agent framework.

This package-level module is intentionally lightweight to avoid importing heavy
submodules during simple CLI invocations (e.g., `evenage init`).

Downstream code that needs core functionality should import from submodules
directly, e.g. `from evenage.core import Agent`.
"""

__version__ = "0.4.8"

# Do not import evenage.core here to keep package import light and avoid
# accidental ImportError during CLI usage when optional dependencies or
# experimental modules are absent. Expose only version at package import time.

__all__ = [
    "__version__",
]
