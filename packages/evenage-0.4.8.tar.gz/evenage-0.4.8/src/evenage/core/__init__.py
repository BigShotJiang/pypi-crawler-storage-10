"""
EvenAge Core module.

Expose only stable, lightweight symbols to avoid heavy imports at module import time.
"""

from .agent_runtime import Agent, AgentMemory
from .config import (
    AgentConfig,
    BackendFactory,
    EvenAgeConfig,
    PipelineConfig,
    ProjectConfig,
)
from .decorators import actor
from .runtime_entry import AgentRunner, run_agent
from .tooling import (
    Tool,
    ToolRegistry,
    bind_tools,
    create_tool_schema,
    discover_tools,
    register_mcp_tools,
    tool,
)

__all__ = [
    # Core runtime
    "Agent",
    "AgentMemory",
    "AgentRunner",
    "run_agent",
    # Decorators
    "actor",
    "tool",
    # Configuration
    "EvenAgeConfig",
    "AgentConfig",
    "ProjectConfig",
    "PipelineConfig",
    "BackendFactory",
    # Tooling
    "Tool",
    "ToolRegistry",
    "discover_tools",
    "bind_tools",
    "register_mcp_tools",
    "create_tool_schema",
]
