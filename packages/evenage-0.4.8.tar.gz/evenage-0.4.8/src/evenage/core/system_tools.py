"""
Built-in system tools for EvenAge runtime.

Minimal implementation for local runs; provides no-op catalog.
"""
from __future__ import annotations

from typing import Any, Dict, Callable


def create_system_tools(bus: Any, storage: Any) -> Dict[str, Callable]:
    """Return a dictionary of built-in tools.

    For minimal local execution, we provide no built-in tools by default.
    User-space tools can still be discovered and registered.
    """
    return {}
