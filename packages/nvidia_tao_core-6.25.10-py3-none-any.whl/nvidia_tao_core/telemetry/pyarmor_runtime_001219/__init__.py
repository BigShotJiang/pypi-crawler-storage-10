# Pyarmor 8.5.8 (basic), 001219, 2025-10-23T20:01:23.235866
from .pyarmor_runtime import __pyarmor__
