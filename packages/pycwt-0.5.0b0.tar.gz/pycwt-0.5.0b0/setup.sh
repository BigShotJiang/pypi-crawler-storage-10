# python setup.py build_sphinx
python3 setup.py sdist
# python3 setup.py bdist_wininst

# python3 setup.py register -r https://testpypi.python.org/pypi
# twine upload dist/* -r testpypi

# python3 setup.py register
twine upload dist/*
# python setup.py upload_sphinx
