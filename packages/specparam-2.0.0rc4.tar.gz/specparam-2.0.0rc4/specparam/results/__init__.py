"""Results sub-module."""
