from explain_exception import safe_run

def test_zero_division():
    a = 0
    print(10 / a)

safe_run(test_zero_division)
