import os 
from serverPaths import getServerPaths
import shutil
import glob

def list_all_files(root_path):
    """Returnerer alle filer (absolutte stier) rekursivt under root_path."""
    root_path = os.path.abspath(root_path)
    files = []
    for dirpath, _, filenames in os.walk(root_path):
        for fname in filenames:
            files.append(os.path.join(dirpath, fname))
    return files

def copyAllFiles(): 
    try: 
        serverPaths = getServerPaths()
    except Exception as e:
        raise e 
    
    destinationFolder = "C:\\Users\\" + os.getlogin() + "\\AppData\\Roaming\\Norconsult\\NorconsultPiPythonDevelop\\"
    destinationFolderAuth =  "C:\\Users\\" + os.getlogin() + "\\AppData\\Roaming\\Norconsult\\NorconsultPiPython_auth\\"

    if not os.path.exists(destinationFolder):
        os.makedirs(destinationFolder)
        
    if not os.path.exists(destinationFolderAuth):
        os.makedirs(destinationFolderAuth)

    try: 
        auth_python_Path = serverPaths["auth_python"]
        stubsPath = serverPaths["stubs"]
        femIntegratedServerPath = serverPaths["FemIntegrated"]
    except Exception as e:
        raise e

    # Hent alle filer rekursivt
    filesToCopy_auth_python = list_all_files(auth_python_Path)
    filesToCopyFemIntegrated = list_all_files(femIntegratedServerPath)

    directoryPiPython = os.path.dirname(os.path.abspath(__file__))

    # Finn nyeste .pyi (rekursivt i tilfelle flytting)
    stub_candidates = [f for f in list_all_files(stubsPath) if f.lower().endswith(".pyi")]
    if stub_candidates:
        stubsFileToCopy = max(stub_candidates, key=os.path.getctime)
        stubsFileDestination = os.path.join(directoryPiPython, "init.pyi")
        shutil.copy2(stubsFileToCopy, stubsFileDestination)
    else: 
        print("Unable to find a stub file for copying. This may result in outdated or missing code-help and IntelliSense.")

    # Kopier FemIntegrated-filer (beholder relativ struktur)
    for src in filesToCopyFemIntegrated:
        rel = os.path.relpath(src, femIntegratedServerPath)
        dest = os.path.join(destinationFolder, rel)
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        try:
            if requiresUpdate(src, dest):
                shutil.copy2(src, dest)
        except Exception as e:
            print(f"Unable to copy -> skipping {rel}. Error: {e}")

    # (Avkommenter hvis du �nsker � kopiere auth_python-filer ogs�)
    # for src in filesToCopy_auth_python:
    #     rel = os.path.relpath(src, auth_python_Path)
    #     dest = os.path.join(destinationFolderAuth, rel)
    #     os.makedirs(os.path.dirname(dest), exist_ok=True)
    #     if requiresUpdate(src, dest):
    #         shutil.copy2(src, dest)

def requiresUpdate(serverFilePath, destFilePath):
    if not os.path.isfile(serverFilePath):
        return False
    if not os.path.isfile(destFilePath):
        return True
    return os.path.getmtime(serverFilePath) > os.path.getmtime(destFilePath)