#!/usr/bin/env sh

pip uninstall -y pycrdt datalayer-pycrdt
pip install datalayer-pycrdt
