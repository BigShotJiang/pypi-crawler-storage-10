# master_key_manager.py
from cryptography.fernet import Fernet
from pathlib import Path

MASTER_KEY_FILE = Path("master.key")

def generate_master_key():
    key = Fernet.generate_key()
    MASTER_KEY_FILE.write_bytes(key)
    print("Master key generated and saved to master.key")

def load_master_key():
    return MASTER_KEY_FILE.read_bytes()

if __name__ == "__main__":
    generate_master_key()
