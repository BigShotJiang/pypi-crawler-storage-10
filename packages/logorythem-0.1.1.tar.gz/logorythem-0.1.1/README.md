# LOGORYTHEM

A lightweight Python library for simulating classic **Operating System (OS)** algorithms — including CPU scheduling and page replacement.

This project is designed as a **clean, importable library for academic and research use**, allowing you to easily run and compare different OS algorithms.

---

## Features

`logorythem` includes two primary modules:

### CPU Scheduling (`scheduling`)

Simulates process scheduling algorithms and calculates:

* Waiting Time
* Turnaround Time
* Completion Time

Available algorithms:

* First-Come, First-Served (FCFS)
* Round Robin (RR)
* Shortest Job First (SJF) – Non-Preemptive
* Shortest Remaining Time First (SRTF) – Preemptive SJF

---

### Page Replacement (`page_replacement`)

Simulates memory management algorithms and computes:

* Total Page Faults
* Page Replacement Sequence

Available algorithms:

* First-In, First-Out (FIFO)
* Least Recently Used (LRU)
* Optimal (OPT)

---

## Installation

`logorythem` is available on PyPI.
Install it using:

```bash
pip install logorythem
```

## Quick Usage

### Example – Round Robin Scheduling

```python
from logorythem import scheduling

processes = [
    {"pid": "P1", "arrival": 0, "burst": 5},
    {"pid": "P2", "arrival": 1, "burst": 3},
    {"pid": "P3", "arrival": 2, "burst": 8},
]

result = scheduling.round_robin(processes, quantum=2)
print(result)
```

### Example – LRU Page Replacement

```python
from logorythem import page_replacement

reference = [7, 0, 1, 2, 0, 3, 0, 4, 2, 3]
faults = page_replacement.lru(reference, frames=3)
print("Total Page Faults:", faults)
```

---

## Why Use LOGORYTHEM?

| Feature     | Description                                                              |
| ----------- | ------------------------------------------------------------------------ |
| Modular     | Each algorithm is a standalone function                                  |
| Educational | Ideal for learning OS concepts like CPU scheduling and memory management |
| Lightweight | Simple design, minimal dependencies                                      |
| Extensible  | Easy to add or modify algorithms                                         |

---

## Project Structure

```
logorythem/
├── src/
│   ├── page_replacement/
│   │   ├── __init__.py
│   │   ├── fifo.py
│   │   ├── lru.py
│   │   └── opt.py
│   ├── scheduling/
│   │   ├── __init__.py
│   │   ├── fcfs.py
│   │   ├── round_robin.py
│   │   ├── sjf_non_preemptive.py
│   │   └── sjf_preemptive.py
├── LICENSE
├── pyproject.toml
└── README.md

```

---

## License

Licensed under the **MIT License**.
You are free to use, modify, and distribute this project for learning and research purposes.

---

## Author

**Ammaar Abdul Rehman Bakshi**
Diploma in Computer Engineering
Anjuman-e-Islam Abdul Razzak Kalsekar Polytechnic
LinkedIn: [linkedin.com/in/ammaar-ic](https://linkedin.com/in/ammaar-ic)

---
