# src/os/fcfs.py

def calculate(processes):
    """
    Calculates FCFS scheduling metrics for a list of processes.

    Args:
        processes (list): A list of dictionaries, where each dictionary
                          represents a process and must contain:
                          - 'pid': Process ID
                          - 'arrival_time': Time the process arrives
                          - 'burst_time': Time the process needs to run

    Returns:
        dict: A dictionary containing two keys:
              - 'results': A list of process dictionaries with calculated metrics.
              - 'averages': A dictionary with 'avg_waiting_time' and 
                            'avg_turnaround_time'.
    """
    if not processes:
        return {"results": [], "averages": {"avg_waiting_time": 0, "avg_turnaround_time": 0}}

    # The core of FCFS: Sort processes by arrival time
    sorted_processes = sorted(processes, key=lambda p: p['arrival_time'])

    completion_time = 0
    total_waiting_time = 0
    total_turnaround_time = 0
    
    results = []

    for process in sorted_processes:
        # Check if the CPU is idle before this process arrives
        if completion_time < process['arrival_time']:
            completion_time = process['arrival_time']
        
        # Calculate times for the current process
        # Waiting Time = Start Time - Arrival Time
        waiting_time = completion_time - process['arrival_time']
        
        # Turnaround Time = Completion Time - Arrival Time
        turnaround_time = (completion_time + process['burst_time']) - process['arrival_time']
        
        # Update the overall completion time
        completion_time += process['burst_time']
        
        # Add to totals
        total_waiting_time += waiting_time
        total_turnaround_time += turnaround_time
        
        # Store the results for this process
        results.append({
            "pid": process['pid'],
            "arrival_time": process['arrival_time'],
            "burst_time": process['burst_time'],
            "waiting_time": waiting_time,
            "turnaround_time": turnaround_time,
            "completion_time": completion_time
        })

    # Calculate averages
    num_processes = len(processes)
    avg_waiting_time = total_waiting_time / num_processes
    avg_turnaround_time = total_turnaround_time / num_processes

    return {
        "results": results,
        "averages": {
            "avg_waiting_time": avg_waiting_time,
            "avg_turnaround_time": avg_turnaround_time
        }
    }