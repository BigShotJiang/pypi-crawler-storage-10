# src/os/round_robin.py

from collections import deque

def calculate(processes, time_quantum):
    """
    Calculates Round Robin scheduling metrics for a list of processes.

    Args:
        processes (list): A list of dictionaries, where each dictionary
                          represents a process and must contain:
                          - 'pid': Process ID
                          - 'arrival_time': Time the process arrives
                          - 'burst_time': Time the process needs to run
        time_quantum (int): The fixed time slice for each process.

    Returns:
        dict: A dictionary containing two keys:
              - 'results': A list of process dictionaries with calculated metrics.
              - 'averages': A dictionary with 'avg_waiting_time' and 
                            'avg_turnaround_time'.
    """
    if not processes:
        return {"results": [], "averages": {"avg_waiting_time": 0, "avg_turnaround_time": 0}}

    # Use a deque for an efficient ready queue (FIFO)
    ready_queue = deque()
    
    # Create a copy of processes to track remaining burst time
    # and sort by arrival time to add them correctly
    proc_list = sorted(processes, key=lambda p: p['arrival_time'])
    proc_map = {p['pid']: p.copy() for p in proc_list}
    for pid in proc_map:
        proc_map[pid]['remaining_burst_time'] = proc_map[pid]['burst_time']
        proc_map[pid]['waiting_time'] = 0 # Will be calculated

    results = []
    current_time = 0
    proc_index = 0 # To track adding new processes from proc_list
    
    total_waiting_time = 0
    total_turnaround_time = 0
    
    # Main simulation loop
    # Runs as long as there are processes in the queue or processes yet to arrive
    while ready_queue or proc_index < len(proc_list):

        # 1. Add newly arrived processes to the ready queue
        while proc_index < len(proc_list) and proc_list[proc_index]['arrival_time'] <= current_time:
            ready_queue.append(proc_list[proc_index]['pid'])
            proc_index += 1

        if not ready_queue:
            # CPU is idle. Jump time to the next process arrival.
            if proc_index < len(proc_list):
                current_time = proc_list[proc_index]['arrival_time']
            continue # Restart loop to add the newly arrived process

        # 2. Get the next process from the queue
        pid = ready_queue.popleft()
        process = proc_map[pid]
        
        # 3. Execute the process for one time quantum or its remaining time
        if process['remaining_burst_time'] <= time_quantum:
            # --- Process Finishes ---
            exec_time = process['remaining_burst_time']
            process['remaining_burst_time'] = 0
            
            current_time += exec_time
            
            # Calculate metrics
            completion_time = current_time
            turnaround_time = completion_time - process['arrival_time']
            waiting_time = turnaround_time - process['burst_time']

            total_waiting_time += waiting_time
            total_turnaround_time += turnaround_time
            
            # Add to final results
            results.append({
                "pid": process['pid'],
                "arrival_time": process['arrival_time'],
                "burst_time": process['burst_time'],
                "waiting_time": waiting_time,
                "turnaround_time": turnaround_time,
                "completion_time": completion_time
            })
            
        else:
            # --- Process is Preempted ---
            exec_time = time_quantum
            process['remaining_burst_time'] -= time_quantum
            current_time += exec_time

        # 4. CRITICAL: Add any processes that arrived *during* this execution slice
        while proc_index < len(proc_list) and proc_list[proc_index]['arrival_time'] <= current_time:
            ready_queue.append(proc_list[proc_index]['pid'])
            proc_index += 1
            
        # 5. If the process was preempted, add it back to the end of the queue
        if process['remaining_burst_time'] > 0:
            ready_queue.append(pid)

    # Calculate averages
    num_processes = len(processes)
    avg_waiting_time = total_waiting_time / num_processes
    avg_turnaround_time = total_turnaround_time / num_processes

    # Sort results by PID for a clean final output
    sorted_results = sorted(results, key=lambda p: p['pid'])

    return {
        "results": sorted_results,
        "averages": {
            "avg_waiting_time": avg_waiting_time,
            "avg_turnaround_time": avg_turnaround_time
        }
    }