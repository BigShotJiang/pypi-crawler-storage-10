# src/os/sjf_non_preemptive.py

def calculate(processes):
    """
    Calculates Shortest Job First (SJF) Non-Preemptive scheduling metrics.

    Args:
        processes (list): A list of process dictionaries with:
                          - 'pid': Process ID
                          - 'arrival_time': Time the process arrives
                          - 'burst_time': Time the process needs to run

    Returns:
        dict: A dictionary containing 'results' and 'averages'.
    """
    if not processes:
        return {"results": [], "averages": {"avg_waiting_time": 0, "avg_turnaround_time": 0}}

    num_processes = len(processes)
    # Create a copy to not mutate the original list
    proc_list = [p.copy() for p in processes]
    
    results = []
    current_time = 0
    completed_count = 0
    
    total_waiting_time = 0
    total_turnaround_time = 0

    while completed_count < num_processes:
        # Get all processes that have arrived and are not yet completed
        ready_queue = []
        for p in proc_list:
            if 'completion_time' not in p and p['arrival_time'] <= current_time:
                ready_queue.append(p)

        if not ready_queue:
            # CPU is idle. Find the next process that will arrive.
            next_arrival_time = float('inf')
            for p in proc_list:
                if 'completion_time' not in p:
                    next_arrival_time = min(next_arrival_time, p['arrival_time'])
            
            # If no processes are left, break (should be handled by completed_count)
            if next_arrival_time == float('inf'):
                break

            current_time = next_arrival_time
            continue # Restart loop to re-fill the ready queue

        # --- Core SJF Logic ---
        # Sort the ready queue by burst time to find the shortest job
        ready_queue.sort(key=lambda p: p['burst_time'])
        
        # Select the shortest job to run
        process_to_run = ready_queue[0]
        
        # --- Calculate metrics for this process ---
        completion_time = current_time + process_to_run['burst_time']
        turnaround_time = completion_time - process_to_run['arrival_time']
        waiting_time = turnaround_time - process_to_run['burst_time']

        total_waiting_time += waiting_time
        total_turnaround_time += turnaround_time
        
        # Store results
        results.append({
            "pid": process_to_run['pid'],
            "arrival_time": process_to_run['arrival_time'],
            "burst_time": process_to_run['burst_time'],
            "waiting_time": waiting_time,
            "turnaround_time": turnaround_time,
            "completion_time": completion_time
        })

        # Mark process as completed by adding completion_time
        # This is how we track which processes are done
        for p in proc_list:
            if p['pid'] == process_to_run['pid']:
                p['completion_time'] = completion_time
                break
        
        # Advance time to when this process finishes
        current_time = completion_time
        completed_count += 1

    # Calculate averages
    avg_waiting_time = total_waiting_time / num_processes
    avg_turnaround_time = total_turnaround_time / num_processes

    # Sort results by PID for a clean final output
    sorted_results = sorted(results, key=lambda p: p['pid'])
    
    return {
        "results": sorted_results,
        "averages": {
            "avg_waiting_time": avg_waiting_time,
            "avg_turnaround_time": avg_turnaround_time
        }
    }