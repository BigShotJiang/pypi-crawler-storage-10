from . import fcfs
from . import round_robin
from . import sjf_non_preemptive
from . import sjf_preemptive

__version__ = "0.1.0"