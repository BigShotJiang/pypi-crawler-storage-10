# src/os/sjf_preemptive.py

def calculate(processes):
    """
    Calculates SJF Preemptive (SRTF) scheduling metrics.

    Args:
        processes (list): A list of process dictionaries with:
                          - 'pid': Process ID
                          - 'arrival_time': Time the process arrives
                          - 'burst_time': Time the process needs to run

    Returns:
        dict: A dictionary containing 'results' and 'averages'.
    """
    if not processes:
        return {"results": [], "averages": {"avg_waiting_time": 0, "avg_turnaround_time": 0}}

    num_processes = len(processes)
    
    # Create a map to track remaining time and store original data
    proc_data = {}
    for p in processes:
        proc_data[p['pid']] = {
            'arrival_time': p['arrival_time'],
            'burst_time': p['burst_time'],
            'remaining_time': p['burst_time'],
            'completion_time': 0,
            'waiting_time': 0
        }

    current_time = 0
    completed_count = 0
    results = []
    
    total_waiting_time = 0
    total_turnaround_time = 0

    while completed_count < num_processes:
        # Find all processes that have arrived and are not finished
        ready_queue = []
        for pid, data in proc_data.items():
            if data['arrival_time'] <= current_time and data['remaining_time'] > 0:
                ready_queue.append(pid)
        
        if not ready_queue:
            # CPU is idle. Jump to the next process arrival.
            next_arrival_time = float('inf')
            for pid, data in proc_data.items():
                if data['remaining_time'] > 0:
                    next_arrival_time = min(next_arrival_time, data['arrival_time'])
            
            if next_arrival_time == float('inf'):
                break # All processes done

            current_time = next_arrival_time
            continue # Restart loop to re-fill ready queue

        # --- Core SRTF Logic ---
        # Find the process in the ready queue with the shortest *remaining* time
        shortest_pid = -1
        shortest_time = float('inf')
        for pid in ready_queue:
            if proc_data[pid]['remaining_time'] < shortest_time:
                shortest_time = proc_data[pid]['remaining_time']
                shortest_pid = pid
        
        # Run this process for 1 time unit
        # (This is a simple way to simulate. A more complex way finds the next event)
        proc_data[shortest_pid]['remaining_time'] -= 1
        current_time += 1

        # Check if this process just finished
        if proc_data[shortest_pid]['remaining_time'] == 0:
            completed_count += 1
            
            # --- Calculate metrics for this completed process ---
            completion_time = current_time
            turnaround_time = completion_time - proc_data[shortest_pid]['arrival_time']
            waiting_time = turnaround_time - proc_data[shortest_pid]['burst_time']

            total_waiting_time += waiting_time
            total_turnaround_time += turnaround_time

            # Store final results
            results.append({
                "pid": shortest_pid,
                "arrival_time": proc_data[shortest_pid]['arrival_time'],
                "burst_time": proc_data[shortest_pid]['burst_time'],
                "waiting_time": waiting_time,
                "turnaround_time": turnaround_time,
                "completion_time": completion_time
            })

    # Calculate averages
    avg_waiting_time = total_waiting_time / num_processes
    avg_turnaround_time = total_turnaround_time / num_processes

    # Sort results by PID for a clean final output
    sorted_results = sorted(results, key=lambda p: p['pid'])

    return {
        "results": sorted_results,
        "averages": {
            "avg_waiting_time": avg_waiting_time,
            "avg_turnaround_time": avg_turnaround_time
        }
    }