from . import fifo
from . import lru
from . import optimal

__version__ = "0.1.0"