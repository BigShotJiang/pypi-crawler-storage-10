# src/page_replacement/optimal.py

def calculate(page_references, num_frames):
    """
    Calculates page faults using the Optimal (OPT) algorithm.

    Args:
        page_references (list): The list of page reference numbers.
        num_frames (int): The number of available memory frames.

    Returns:
        dict: A dictionary containing 'page_faults' and 'frames' state.
    """
    
    frames = []
    page_faults = 0
    
    for i in range(len(page_references)):
        page = page_references[i]
        
        if page not in frames:
            # Page fault occurs
            page_faults += 1
            
            if len(frames) < num_frames:
                # Still have free frames
                frames.append(page)
            else:
                # No free frames, must replace
                # Look at all future page references
                future_references = page_references[i+1:]
                
                # Find the page in frames that is used furthest in the future
                page_to_remove = -1
                farthest_use = -1
                
                for frame in frames:
                    if frame not in future_references:
                        # This page is never used again, remove it
                        page_to_remove = frame
                        break
                    else:
                        # Find when this frame is next used
                        future_index = future_references.index(frame)
                        if future_index > farthest_use:
                            farthest_use = future_index
                            page_to_remove = frame
                
                # Replace the chosen page
                frame_index = frames.index(page_to_remove)
                frames[frame_index] = page
        
        # If page is already in frames, do nothing

    return {
        "algorithm": "Optimal",
        "page_faults": page_faults,
        "frames": frames
    }