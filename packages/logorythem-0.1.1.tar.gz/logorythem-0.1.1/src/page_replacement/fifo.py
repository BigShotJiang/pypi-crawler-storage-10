# src/page_replacement/fifo.py

from collections import deque

def calculate(page_references, num_frames):
    """
    Calculates page faults using the FIFO (First-In, First-Out) algorithm.

    Args:
        page_references (list): The list of page reference numbers.
        num_frames (int): The number of available memory frames.

    Returns:
        dict: A dictionary containing 'page_faults' and 'frames' state.
    """
    
    frames = []
    page_faults = 0
    # Use a deque as a queue to track which page entered first
    page_queue = deque()

    for page in page_references:
        if page not in frames:
            # Page fault occurs
            page_faults += 1
            
            if len(frames) < num_frames:
                # Still have free frames
                frames.append(page)
                page_queue.append(page)
            else:
                # No free frames, must replace
                # Get the first page that entered (FIFO)
                page_to_remove = page_queue.popleft()
                
                # Find its index in frames and replace it
                frame_index = frames.index(page_to_remove)
                frames[frame_index] = page
                
                # Add the new page to the queue
                page_queue.append(page)
        
        # If page is already in frames, do nothing
        
    return {
        "algorithm": "FIFO",
        "page_faults": page_faults,
        "frames": frames
    }