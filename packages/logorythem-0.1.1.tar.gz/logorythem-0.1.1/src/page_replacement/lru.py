# src/page_replacement/lru.py

def calculate(page_references, num_frames):
    """
    Calculates page faults using the LRU (Least Recently Used) algorithm.

    Args:
        page_references (list): The list of page reference numbers.
        num_frames (int): The number of available memory frames.

    Returns:
        dict: A dictionary containing 'page_faults' and 'frames' state.
    """
    
    frames = []
    page_faults = 0
    # Use a list to track recent use.
    # The end of the list is the most recent.
    # The beginning is the least recent.
    
    for page in page_references:
        if page not in frames:
            # Page fault occurs
            page_faults += 1
            
            if len(frames) < num_frames:
                # Still have free frames
                frames.append(page)
            else:
                # No free frames, must replace
                # Remove the least recently used (at the beginning)
                frames.pop(0)
                # Add the new page as most recently used (at the end)
                frames.append(page)
        
        else:
            # Page hit!
            # Move the accessed page to the end (most recent)
            frames.remove(page)
            frames.append(page)
            
    return {
        "algorithm": "LRU",
        "page_faults": page_faults,
        "frames": frames
    }