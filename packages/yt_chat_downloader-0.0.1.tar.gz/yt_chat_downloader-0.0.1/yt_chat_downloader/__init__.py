"""
YouTube Chat Downloader - Download live chat replays and comments from YouTube videos.
"""

__version__ = "0.0.1"
__author__ = "Dev Maker"
# __license__ = "MIT"

from .downloader import YouTubeChatDownloader

__all__ = ["YouTubeChatDownloader"]

