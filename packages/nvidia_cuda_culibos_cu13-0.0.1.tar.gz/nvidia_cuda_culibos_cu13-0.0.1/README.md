⚠️ THIS PROJECT 'nvidia-cuda-culibos-cu13' IS DEPRECATED.
Please use 'nvidia-cuda-culibos' instead.

To install the correct package, use:

    pip install nvidia-cuda-culibos

For more information, visit: https://pypi.org/project/nvidia-cuda-culibos/
