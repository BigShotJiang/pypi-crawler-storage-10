"""MoreStore CLI - Python client for MoreStore.ai API"""

__version__ = "0.1.1"

