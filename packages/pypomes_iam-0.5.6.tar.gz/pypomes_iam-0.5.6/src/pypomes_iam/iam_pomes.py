from flask import Request, Response, request
from typing import Any

from .iam_common import (
    IamServer, _iam_lock, _get_iam_registry,
    _iam_server_from_issuer  # _get_public_key
)
from .token_pomes import token_get_claims, token_validate


def jwt_required(func: callable) -> callable:
    """
    Create a decorator to authenticate service endpoints with JWT tokens.

    :param func: the function being decorated
    """
    # ruff: noqa: ANN003 - Missing type annotation for *{name}
    def wrapper(*args, **kwargs) -> Response:
        response: Response = __request_validate(request=request)
        return response if response else func(*args, **kwargs)

    # prevent a rogue error ("View function mapping is overwriting an existing endpoint function")
    wrapper.__name__ = func.__name__

    return wrapper


def __request_validate(request: Request) -> Response:
    """
    Verify whether the HTTP *request* has the proper authorization, as per the JWT standard.

    This implementation assumes that HTTP requests are handled with the *Flask* framework.

    :param request: the *request* to be verified
    :return: *None* if the *request* is valid, otherwise a *Response* reporting the error
    """
    # initialize the return variable
    result: Response | None = None

    # retrieve the authorization from the request header
    auth_header: str = request.headers.get("Authorization")

    # validate the authorization token
    bad_token: bool = True
    if auth_header and auth_header.startswith("Bearer "):
        # extract and validate the JWT access token
        token: str = auth_header.split(" ")[1]
        claims: dict[str, Any] = token_get_claims(token=token)
        if claims:
            issuer: str = claims["payload"].get("iss")
            recipient_attr: str | None = None
            recipient_id: str = request.values.get("user-id") or request.values.get("login")
            with _iam_lock:
                iam_server: IamServer = _iam_server_from_issuer(issuer=issuer,
                                                                errors=None,
                                                                logger=None)
                # public_key: str = _get_public_key(iam_server=iam_server,
                #                                   errors=errors,
                #                                   logger=logger)
                public_key = None

                # validate the token's recipient only if a user identification is provided
                if recipient_id:
                    registry: dict[str, Any] = _get_iam_registry(iam_server=iam_server,
                                                                 errors=None,
                                                                 logger=None)
                    recipient_attr = registry["recipient-attr"]

            # validate the token
            if token_validate(token=token,
                              issuer=issuer,
                              recipient_id=recipient_id,
                              recipient_attr=recipient_attr,
                              public_key=public_key):
                # token is valid
                bad_token = False

    # deny the authorization
    if bad_token:
        result = Response(response="Authorization failed",
                          status=401)
    return result
