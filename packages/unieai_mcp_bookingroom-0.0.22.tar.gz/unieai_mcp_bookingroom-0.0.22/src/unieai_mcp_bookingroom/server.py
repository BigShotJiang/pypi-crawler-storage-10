from fastmcp import FastMCP
from fastapi import HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional
import httpx
from datetime import datetime, timezone, timedelta

# ------------------------------------------------------
# 初始化 FastMCP (同時也是 FastAPI app)
# ------------------------------------------------------


def main():

    mcp = FastMCP(
        name="meeting-room-api"
    )
    #mcp = FastMCP("unieai-mcp-mysql-server")

    BASE_URL = "http://0.tcp.jp.ngrok.io:17735"

    # ------------------------------------------------------
    # 資料模型 (Pydantic)
    # ------------------------------------------------------
    class Room(BaseModel):
        id: int
        name: str
        capacity: int

    class ReservationRequest(BaseModel):
         room_id: int = Field(..., description="會議室 ID")
         start_time: str = Field(..., description="開始時間 (台灣時間格式: YYYY-MM-DD HH:MM)")
         end_time: str = Field(..., description="結束時間 (台灣時間格式: YYYY-MM-DD HH:MM)")
         reserved_by: str = Field(..., description="預約人姓名")

    class ReservationResponse(BaseModel):
        reservation_id: Optional[int]
        status: str

    class RoomReservation(BaseModel):
         id: int
         room_id: int
         start_time: str  # 台灣時間格式: YYYY-MM-DD HH:MM
         end_time: str    # 台灣時間格式: YYYY-MM-DD HH:MM
         reserved_by: str


     # ------------------------------------------------------
     # 時間轉換函數
     # ------------------------------------------------------
    def taiwan_to_iso(taiwan_time_str: str) -> str:
         """將台灣時間字串轉換為不含時區的 ISO 格式 YYYY-MM-DDTHH:MM:SS"""
         try:
             # 解析台灣時間 (YYYY-MM-DD HH:MM)
             dt = datetime.strptime(taiwan_time_str, "%Y-%m-%d %H:%M")
             # 設定為台灣時區 (UTC+8)
             taiwan_tz = timezone(timedelta(hours=8))
             dt = dt.replace(tzinfo=taiwan_tz)
             # 轉換為 UTC，並輸出不帶時區偏移，符合 Flask 的 '%Y-%m-%dT%H:%M:%S'
             return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
         except ValueError as e:
             raise ValueError(f"時間格式錯誤，請使用 YYYY-MM-DD HH:MM 格式: {e}")
     
    def iso_to_taiwan(iso_time_str: str) -> str:
         """將 ISO 格式轉換為台灣時間字串"""
         try:
             # 解析 ISO 時間
             dt = datetime.fromisoformat(iso_time_str.replace('Z', '+00:00'))
             # 轉換為台灣時區
             taiwan_tz = timezone(timedelta(hours=8))
             dt = dt.astimezone(taiwan_tz)
             # 格式化為台灣時間
             return dt.strftime("%Y-%m-%d %H:%M")
         except ValueError as e:
             raise ValueError(f"ISO 時間格式錯誤: {e}")

     # ------------------------------------------------------
     # 建立 HTTP 客戶端
     # ------------------------------------------------------


    # ------------------------------------------------------
    # API 實作
    # ------------------------------------------------------
    @mcp.tool()
    def list_rooms() -> List[Room]:
         """
         查詢所有會議室
         
         返回所有可用的會議室列表，包含：
         - id: 會議室 ID
         - name: 會議室名稱
         - capacity: 會議室容量（人數）
         
         使用範例：
         無需參數，直接調用 list_rooms()
         
         返回範例：
         [
             {"id": 1, "name": "會議室A", "capacity": 10},
             {"id": 2, "name": "會議室B", "capacity": 20}
         ]
         
        version = 0.0.22
        """
         with httpx.Client(timeout=10.0) as client:
            try:
                r = client.get(f"{BASE_URL}/rooms")
                r.raise_for_status()
                return r.json()
            except httpx.RequestError as e:
                raise HTTPException(status_code=500, detail=f"連線錯誤：{e}")
            except httpx.HTTPStatusError as e:
                raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


    @mcp.tool()
    def list_room_reservations(room_id: int) -> List[RoomReservation]:
         """
         查詢某間會議室的預約紀錄
         
         參數說明：
         - room_id (int): 會議室 ID，可透過 list_rooms() 查詢可用會議室
         
         使用範例：
         list_room_reservations(room_id=1)
         
         返回範例：
         [
             {
                 "id": 1,
                 "room_id": 1,
                 "start_time": "2024-01-15 14:30",
                 "end_time": "2024-01-15 16:00",
                 "reserved_by": "張三"
             }
         ]
         
         注意：返回的時間為台灣時間格式

        version = 0.0.22
        """
         with httpx.Client(timeout=10.0) as client:
            try:
                r = client.get(f"{BASE_URL}/rooms/{room_id}/reservations")
                r.raise_for_status()
                reservations = r.json()
                
                # 將返回的時間轉換為台灣時間
                for reservation in reservations:
                    if 'start_time' in reservation:
                        reservation['start_time'] = iso_to_taiwan(reservation['start_time'])
                    if 'end_time' in reservation:
                        reservation['end_time'] = iso_to_taiwan(reservation['end_time'])
                
                return reservations
            except httpx.RequestError as e:
                raise HTTPException(status_code=500, detail=f"連線錯誤：{e}")
            except httpx.HTTPStatusError as e:
                raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


    @mcp.tool()
    def create_reservation(room_id: int, start_time: str, end_time: str, reserved_by: str) -> ReservationResponse:
         """
         預約會議室
         
         參數說明：
         - room_id (int): 會議室 ID，可透過 list_rooms() 查詢可用會議室
         - start_time (str): 開始時間，台灣時間格式 "YYYY-MM-DD HH:MM"，例如 "2024-01-15 14:30"
         - end_time (str): 結束時間，台灣時間格式 "YYYY-MM-DD HH:MM"，例如 "2024-01-15 16:00"
         - reserved_by (str): 預約人姓名
         
         使用範例：
         create_reservation(
             room_id=1,
             start_time="2024-01-15 14:30",
             end_time="2024-01-15 16:00",
             reserved_by="張三"
         )
         
         返回：
         - reservation_id: 預約編號（成功時）
         - status: 預約狀態

        version = 0.0.22
        """
         with httpx.Client(timeout=10.0) as client:
            try:
                # 將台灣時間轉換為 ISO 格式
                req_data = {
                    'room_id': room_id,
                    'start_time': taiwan_to_iso(start_time),
                    'end_time': taiwan_to_iso(end_time),
                    'reserved_by': reserved_by
                }
                
                r = client.post(f"{BASE_URL}/reservations", json=req_data)
                r.raise_for_status()
                return r.json()
            except ValueError as e:
                raise HTTPException(status_code=400, detail=f"時間格式錯誤：{e}")
            except httpx.RequestError as e:
                raise HTTPException(status_code=500, detail=f"無法連線伺服器：{e}")
            except httpx.HTTPStatusError as e:
                raise HTTPException(status_code=e.response.status_code, detail=e.response.text)
    mcp.run()

# ------------------------------------------------------
# 執行入口
# ------------------------------------------------------

if __name__ == "__main__":
    main()
