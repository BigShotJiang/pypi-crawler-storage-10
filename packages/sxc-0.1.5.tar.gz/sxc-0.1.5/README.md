SXC is a Python library designed for academic and educational use, providing intuitive access to machine learning algorithms, nonparametric smoothing techniques, and classical statistical learning workflows. Inspired by Scikit-Learn’s clean API principles, SXC ensures that users can perform data analysis with consistent, modular, and user-friendly interfaces.


---

## Features

### Supervised Learning
- Decision Tree Classifier & Regressor
- Random Forest Classifier & Regressor
- K-Nearest Neighbors Classification & Regression
- Naive Bayes Classifier
- Support Vector Machines (Classification & Regression)
- Bagging for both Regression and Classification

### Nonparametric Regression & Smoothing
Located under `sxc.mdts.adv_reg`:
- Bin Smoother
- KNN Smoother
- Kernel Weighted Regression
- LOWESS (Locally Weighted Regression)
- LWR (Local Weighted Regression variants)

### Clustering
- K-Means clustering

### Utility
- Indexing helper for dataset preprocessing

---

## Installation

```bash
pip install sxc
``` 
This will install all core dependencies required to run the machine learning modules inside SXC.

##  Quick Start
```py
from sxc.mdts.decision_tree_classifier import DecisionTreeClassifier
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Load toy dataset
X, y = load_iris(return_X_y=True)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42
)

# Initialize the model
model = DecisionTreeClassifier()

# Fit and predict
model.fit(X_train, y_train)
preds = model.predict(X_test)
```

All algorithms included are intended for educational demonstrations and experiments. SXC facilitates rapid learning of:

Machine learning theory
Practical model building
Nonparametric regression foundations
For academic citation or publication:

## Patra, S. (2025).
SXC: Statistical & Explainable Computing (Version 0.1.x).
Python package available at PyPI.

# Contributing
Contributions are welcomed. Kindly create pull requests via GitHub or report issues to help improve stability, documentation, and performance.

## License
Licensed under the MIT License. Free to view, modify, and learn from.

## Acknowledgement
Developed with passion for the community of statisticians, data scientists, and research enthusiasts at St. Xavier’s College.

Keep experimenting. Keep learning. Keep computing elegantly.