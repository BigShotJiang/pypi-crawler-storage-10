import pkgutil
import inspect
import importlib
import pandas as pd
import sxc.mdts as mdts_pkg


def indexing():
    """
    Recursively scan sxc.mdts and return a DataFrame listing
    only the function names with their short descriptions.
    """

    records = []

    def scan(package, package_path):
        for _, module_name, is_pkg in pkgutil.iter_modules(package_path):
            full_mod = f"{package.__name__}.{module_name}"

            if is_pkg:
                sub_pkg = importlib.import_module(full_mod)
                scan(sub_pkg, sub_pkg.__path__)
                continue

            module = importlib.import_module(full_mod)

            for name, obj in inspect.getmembers(module, inspect.isfunction):
                if obj.__module__.startswith("sxc.mdts") and not name.startswith("_"):
                    doc = inspect.getdoc(obj)
                    short_desc = doc.split("\n")[0] if doc else "No description available"
                    records.append({
                        "Function": name,
                        "Description": short_desc
                    })

    scan(mdts_pkg, mdts_pkg.__path__)
    return pd.DataFrame(records).sort_values(by="Function").reset_index(drop=True)
