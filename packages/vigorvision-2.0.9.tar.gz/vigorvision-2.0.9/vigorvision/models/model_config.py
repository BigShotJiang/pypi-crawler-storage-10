# vigorvision/models/model_config.py
from vigorvision.utils import AutoAnchor as aa

"""
Scalable Vision Model Configurations for VigorVision
---------------------------------------------------
Each variant (n, s, m, l, x) scales both the width and depth
of the model consistently across backbone, neck, and head.

Variants:
  - vision-n (Nano)
  - vision-s (Small)
  - vision-m (Medium)
  - vision-l (Large)
  - vision-x (Extra Large)
"""

# Variant scaling definitions
model_variants = {
    "vision-n": {"depth_mult": 0.33, "width_mult": 0.50, "base_channels": 32},
    "vision-s": {"depth_mult": 0.50, "width_mult": 0.75, "base_channels": 48},
    "vision-m": {"depth_mult": 0.75, "width_mult": 1.00, "base_channels": 64},
    "vision-l": {"depth_mult": 1.00, "width_mult": 1.00, "base_channels": 64},
    "vision-x": {"depth_mult": 1.33, "width_mult": 1.25, "base_channels": 80},
}

model_variants_list = list(model_variants.keys())


def make_divisible(x, divisor=8):
    """Ensure channel numbers are divisible by divisor for hardware efficiency."""
    return int((x + divisor / 2) // divisor * divisor)


def get_scaled_config(variant: str, dataset: str):
    """
    Returns model config dictionary (backbone, neck, head) scaled according to variant.
    The scaling affects both channel width and depth (repetition count).
    """

    if variant not in model_variants:
        raise ValueError(f"Unsupported model variant '{variant}'. "
                         f"Available variants: {list(model_variants.keys())}")

    # Extract scaling parameters
    v = model_variants[variant]
    depth_mult = v["depth_mult"]
    width_mult = v["width_mult"]
    base = v["base_channels"]

    # Scaling helpers
    def c(ch):  # Channel scaling
        return make_divisible(ch * width_mult, 8)

    def d(n):  # Depth scaling
        return max(round(n * depth_mult), 1)

    # ---------------------------
    # BACKBONE CONFIGURATION
    # ---------------------------
    backbone_cfg = [
        ("conv",   3,      c(base),      d(1), {"stride": 2}),
        ("c3k2",   c(base), c(base * 2), d(1), {"stride": 2}),
        ("c4k2",   c(base * 2), c(base * 4), d(2), {"stride": 2}),
        ("a2c2f",  c(base * 4), c(base * 8), d(2), {"stride": 2}),
        ("c3k2",   c(base * 8), c(base * 16), d(1), {"stride": 2}),
        ("c4k2",   c(base * 16), c(base * 32), d(1), {"stride": 2}),
    ]

    # ---------------------------
    # NECK CONFIGURATION
    # ---------------------------
    neck_cfg = {
        "channels": [c(base * 8), c(base * 16), c(base * 32)],  # [C3, C4, C5]
        "use_se": True,
        "depthwise": False,
        "dropout": 0.1,
    }

    # ---------------------------
    # DETECTION HEAD CONFIGURATION
    # ---------------------------
    head_cfg = {
        "anchors": [
            [(10, 13), (16, 30), (33, 23)],        # P3
            [(30, 61), (62, 45), (59, 119)],       # P4
            [(116, 90), (156, 198), (373, 326)],   # P5
        ],
        "strides": [8, 16, 32],
    }

    # Full configuration
    return {
        "backbone": backbone_cfg,
        "neck": neck_cfg,
        "head": head_cfg,
    }


def model_configs(variant: str, dataset: str):
    """
    Wrapper to return validated configuration for model variant.
    Ensures correct scaling and compatibility.
    """
    return get_scaled_config(variant, dataset)
