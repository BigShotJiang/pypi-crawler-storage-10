// Shim for extensions/core/load3d/PreviewManager.ts
console.warn('[ComfyUI Notice] "extensions/core/load3d/PreviewManager.js" is an internal module, not part of the public API. Future updates may break this import.');
export const PreviewManager = window.comfyAPI.PreviewManager.PreviewManager;
