# Report Maker - GOST-7.32 Template
This repository stores configuration and templates
needed to satisfy [GOST-7.32] requirements while building a project.

Note that this will not work on its own,
and requires [report-maker] to run.

Also includes front pages for the [GUAP] University.

## Usage
1. Install via pip:
   ```
   pip install report-maker-template-gost-7.32
   ```
2. In your report composer config, set `composer.template: gost-7.32`.

### Built-in templates
This template also provides the following document templates:

`toc.docx`
:   A *static* document template for the Table of Contents.
    Requires manual reindexing after document rendering.

`guap-front-pages/front-page-lab.docx`
:   A *dynamic* document template
    for the homework task or lab task from the [GUAP] university.

Parameters:
* `department`: Discipline department name or ID
* `caption`: Report category
* `title:` Current report title
* `course`: Discipline full name
* `professor.title`: Professor's title, in the standard short form
* `professor.name`: Professor's name, in "F.M. LastName" form
* `author.id`: Author's internal ID
* `author.name`: Author's name, in "F.M. LastName" form
* `author.class`: Author's class ID

Example:
```hocon
attributes:
{
    department: 43
    caption: "Отчёт о лабораторной работе №"${lab_number}
    title: ${lab_title}
    course: "Основы программирования"
    
    professor.title: "к.т.н., доц."
    professor.name: "И.И. Иванов"
    
    author.id: "2023/1338"
    author.name: "П.О. Зайцев"
    author.class: "Z3431"
}
```


## Licensing
*see: [LICENSE.txt](./LICENSE.txt)*

[BSD-2 License].
Copyright (c) Peter Zaitcev, 2025.

[GOST-7.32]: https://cs.msu.ru/sites/cmc/files/docs/2021-11gost_7.32-2017.pdf
[report-maker]: https://gitlab.com/Hares-Lab/report-maker/report-maker
[GUAP]: https://guap.ru
