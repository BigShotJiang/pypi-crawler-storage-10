def main() -> None:
    print("Hello from goward!")
