# Author: Christian Brodbeck <christianbrodbeck@nyu.edu>
#
# Key constants for Datasets

INTERPOLATE_CHANNELS = "interpolate_channels"
