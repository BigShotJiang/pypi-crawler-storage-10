^^^^^^^^^^^^^^^^^^^^^^^^^^^
Temporal Response Functions
^^^^^^^^^^^^^^^^^^^^^^^^^^^
