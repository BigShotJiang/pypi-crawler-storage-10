^^^^^^^^^^^^
Data objects
^^^^^^^^^^^^

Objects commonly used to represent data:
:class:`Var` and :class:`Factor` for univariate variables,
:class:`NDVar` for n-dimensional data, and
:class:`Dataset` to group multiple variables describing the same cases.
