.. _examples:

********
Examples
********

.. currentmodule:: eelbrain
