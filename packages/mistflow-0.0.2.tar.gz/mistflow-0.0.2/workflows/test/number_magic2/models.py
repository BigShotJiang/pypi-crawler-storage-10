from pydantic import BaseModel

class Input(BaseModel):
    start_number: int
    