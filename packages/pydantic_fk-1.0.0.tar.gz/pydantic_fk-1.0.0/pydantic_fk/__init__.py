
from .links import LinkModelMetaclass
