from django.apps import AppConfig


class DecideHostConfig(AppConfig):
    name = "decide_host"
