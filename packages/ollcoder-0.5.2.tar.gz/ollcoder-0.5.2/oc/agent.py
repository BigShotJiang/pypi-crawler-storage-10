from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Callable

from .adaptive_builder import AdaptiveConfig, build_adaptive_context
from .checks import CheckResult, ChecksConfig, run_checks
from .context_cache import ContextCache
from .context_strategy import ContextFile
from .diff import apply_new_content, compute_unified_diff
from .indexer import read_file_safe
from .memory import TaskMemory, global_memory
from .security import scan as security_scan
from .predictor import analyze_git
from .providers.base import BaseProvider
from concurrent.futures import ThreadPoolExecutor

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class AgentConfig:
    root_dir: str
    task: str
    max_steps: int = 6
    apply_changes: bool = False
    model_max_tokens: Optional[int] = None
    include_files: int = 8  # number of high-priority files to include inline
    use_memory: bool = True  # use persistent memory
    session_id: Optional[str] = None  # explicit session ID
    cancel_check: Optional[Callable[[], bool]] = None  # cooperative cancel
    max_provider_retries: int = 2
    max_patch_failures: int = 3


@dataclass
class AgentStep:
    step: int
    plan: List[str] = field(default_factory=list)
    action: str = ""
    notes: str = ""
    edits_applied: List[str] = field(default_factory=list)
    diffs: List[str] = field(default_factory=list)
    checks: List[CheckResult] = field(default_factory=list)
    checks_status: int = 0
    security_issues: int = 0


@dataclass
class AgentResult:
    success: bool
    steps: List[AgentStep]
    final_message: str
    stats: Dict[str, Any] = field(default_factory=dict)


def _llm_response_text(resp: Any, provider: Any = None) -> Optional[str]:
    """Extract text from LLM response using centralized extraction if available."""
    if resp is None:
        return None
    
    # Use centralized extraction if provider is BaseProvider
    if provider and isinstance(provider, BaseProvider):
        try:
            content = provider.extract_content(resp, stream=False)
            return content if isinstance(content, str) and content.strip() else None
        except Exception:
            pass
    
    # Fallback to manual extraction for backward compatibility
    txt = getattr(resp, "text", None)
    if isinstance(txt, str) and txt.strip():
        return txt
    if isinstance(resp, dict):
        msg = resp.get("message")
        if isinstance(msg, dict):
            c = msg.get("content")
            if isinstance(c, str) and c.strip():
                return c
        c = resp.get("content")
        if isinstance(c, str) and c.strip():
            return c
    return None


def _extract_json_block(text: str) -> Optional[Dict[str, Any]]:
    if not text:
        return None
    # Try fenced json first
    m = re.search(r"```json\s*(\{[\s\S]*?\})\s*```", text, re.I)
    if m:
        try:
            return json.loads(m.group(1))
        except Exception:
            pass
    # Fallback: first {...} block heuristic
    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and end > start:
        blob = text[start : end + 1]
        try:
            return json.loads(blob)
        except Exception:
            pass
    return None


def _system_prompt() -> str:
    return (
        "You are a software engineer agent working in a tight loop: observe → plan → act → verify.\n"
        "Always respond with a single JSON object following this schema:\n\n"
        "{\n"
        "  \"plan\": [\"step\", ...],\n"
        "  \"action\": \"propose_patch|run_checks|ask_question|done\",\n"
        "  \"edits\": [{\"path\": \"string\", \"new_content\": \"string\"}],  // for propose_patch\n"
        "  \"reason\": \"short rationale\",\n"
        "  \"question\": \"ask user if needed\"\n"
        "}\n\n"
        "Rules:\n"
        "- Only change files inside the project root.\n"
        "- Prefer minimal diffs; keep style consistent.\n"
        "- After patches, suggest running checks to verify.\n"
        "- If verification fails, refine the plan and try again.\n"
    )


def _format_context(files: List[ContextFile], max_files: int) -> str:
    # Include a concise selection of highest-priority files inline
    # Prefer CRITICAL and HIGH, include SIGNATURES for larger files
    by_prio = sorted(files, key=lambda f: (f.priority.value, -len(f.content)))
    chosen = by_prio[:max_files]
    parts: List[str] = ["# Repository Context (selected files)"]
    for f in chosen:
        level = (f.meta or {}).get("level") or ""
        header = f"## {f.path} [{f.priority.name}] ({level}) — {f.reason}"
        # Trim content if extremely large
        body = f.content
        if len(body) > 8000:
            body = body[:8000] + "\n...\n"
        parts.append(header)
        # Avoid triple-backtick collision by using language-less fences
        parts.append("```\n" + body + "\n```")
    return "\n\n".join(parts)


def _context_for_task(root: str, task: str, provider: Any, model_max_tokens: Optional[int], include_files: int) -> Tuple[str, Dict[str, Any]]:
    cache = ContextCache(root)
    # Use predictor to bias context selection toward high-churn files
    mentions: List[str] = []
    try:
        preds = analyze_git(root)
        mentions = [p.path for p in preds[:10]]
    except Exception:
        mentions = []
    cfg = AdaptiveConfig(root_dir=root, query=task, model_max_tokens=model_max_tokens, mentioned_files=mentions)
    files, stats = build_adaptive_context(cfg, cache=cache, provider=provider)
    ctx_text = _format_context(files, include_files)
    return ctx_text, stats


def _summarize_verification(checks: List[CheckResult], sec_count: int) -> Tuple[str, int]:
    lines = ["# Verification Results"]
    worst = 0
    for r in checks:
        status = "OK" if r.ok else f"FAIL ({r.exit_code})"
        lines.append(f"$ {' '.join(r.cmd)} -> {status}")
        if not r.ok:
            # include only a small slice of output to keep context manageable
            snippet = (r.stdout or r.stderr or "").strip()
            if len(snippet) > 2000:
                snippet = snippet[:2000] + "\n..."
            if snippet:
                lines.append("```\n" + snippet + "\n```")
            worst = worst or r.exit_code or 1
    if sec_count:
        lines.append(f"Security issues detected: {sec_count}")
    return "\n".join(lines), worst


def run_agent(cfg: AgentConfig, *, provider: Any) -> AgentResult:
    if provider is None:
        raise RuntimeError("Agent requires an LLM provider; pass --provider/--model in CLI.")

    root = str(Path(cfg.root_dir).resolve())

    # Memory integration
    memory_store = global_memory() if cfg.use_memory else None
    session = memory_store.get_or_create_session(root, cfg.session_id) if memory_store else None

    # Build initial context
    ctx_text, ctx_stats = _context_for_task(root, cfg.task, provider, cfg.model_max_tokens, cfg.include_files)

    # Add memory context if available
    memory_context = ""
    if session and memory_store:
        memory_context = memory_store.get_relevant_memory(session.session_id, cfg.task)
        if memory_context:
            memory_context = "\n\n" + memory_context + "\n\n"

    messages: List[Dict[str, str]] = [
        {"role": "system", "content": _system_prompt()},
        {
            "role": "user",
            "content": (
                f"Task: {cfg.task}\n\n"
                f"{memory_context}"
                f"You have access to repository context below. Respond with JSON only.\n\n"
                f"{ctx_text}\n"
            ),
        },
    ]

    steps: List[AgentStep] = []
    final_msg = ""
    files_modified: List[str] = []
    lessons_learned: List[str] = []
    errors_encountered: List[str] = []

    patch_failures = 0
    for i in range(1, int(cfg.max_steps) + 1):
        # Cooperative cancellation
        try:
            if cfg.cancel_check and cfg.cancel_check():
                final_msg = "Cancelled by user"
                return AgentResult(success=False, steps=steps, final_message=final_msg, stats={"context": ctx_stats})
        except Exception:
            # Ignore cancel check failures
            pass
        step = AgentStep(step=i)
        # Provider call with limited retries
        plan_obj = {}
        text = ""
        err: Optional[Exception] = None
        for attempt in range(1, max(1, int(cfg.max_provider_retries)) + 1):
            try:
                resp = provider.chat(messages, stream=False)  # type: ignore[attr-defined]
                text = _llm_response_text(resp, provider) or ""
                plan_obj = _extract_json_block(text) or {}
                err = None
                break
            except Exception as e:
                err = e
                if attempt >= max(1, int(cfg.max_provider_retries)):
                    break
        if err is not None and not plan_obj:
            plan_obj = {}
            text = f"LLM call failed after {cfg.max_provider_retries} attempt(s): {err}"
            log.exception("Agent provider.chat failed")

        step.notes = text[:8000]
        step.plan = [str(x) for x in (plan_obj.get("plan") or [])][:10]
        step.action = str(plan_obj.get("action") or "").strip().lower()

        if step.action == "propose_patch":
            edits = plan_obj.get("edits") or []
            if not isinstance(edits, list):
                edits = []
            for ed in edits[:10]:
                pth = ed.get("path") if isinstance(ed, dict) else None
                new_content = ed.get("new_content") if isinstance(ed, dict) else None
                if not pth or new_content is None:
                    continue
                # Limit to project root
                abs_path = str((Path(root) / pth).resolve())
                if not abs_path.startswith(root):
                    step.diffs.append(f"Skip edit outside root: {pth}")
                    continue
                ok, old_text = read_file_safe(Path(abs_path))
                if not ok:
                    old_text = ""
                diff = compute_unified_diff(abs_path, old_text, new_content)
                step.diffs.append(diff)
                if cfg.apply_changes:
                    applied, msg = apply_new_content(abs_path, old_text, new_content)
                    if applied:
                        step.edits_applied.append(abs_path)
                        files_modified.append(abs_path)
                    else:
                        step.edits_applied.append(f"FAILED: {abs_path} ({msg})")
                        errors_encountered.append(f"Failed to apply edit to {abs_path}: {msg}")
                        patch_failures += 1
                        if patch_failures >= max(1, int(cfg.max_patch_failures)):
                            final_msg = "Too many patch failures; aborting."
                            steps.append(step)
                            return AgentResult(success=False, steps=steps, final_message=final_msg, stats={"context": ctx_stats})

        elif step.action == "run_checks":
            # fall through to verification below
            pass
        elif step.action == "ask_question":
            # No interactive loop in CLI; record and stop
            final_msg = str(plan_obj.get("question") or "")
            steps.append(step)
            return AgentResult(success=False, steps=steps, final_message=final_msg, stats={"context": ctx_stats})
        elif step.action == "done":
            final_msg = str(plan_obj.get("reason") or "done")
            steps.append(step)
            return AgentResult(success=True, steps=steps, final_message=final_msg, stats={"context": ctx_stats})

        # Verification phase (self-correction): run checks and a quick security scan in parallel
        chk_results: List[CheckResult] = []
        worst = 0
        sec_count = 0
        with ThreadPoolExecutor(max_workers=2) as ex:
            fut_checks = ex.submit(run_checks, ChecksConfig())
            fut_sec = ex.submit(security_scan, root)
            try:
                chk_results, worst = fut_checks.result()
            except Exception:
                chk_results, worst = ([], 0)
            try:
                issues = fut_sec.result()
                sec_count = len(issues)
            except Exception:
                sec_count = 0
        step.checks = chk_results
        step.checks_status = worst
        step.security_issues = sec_count

        ver_text, _ = _summarize_verification(chk_results, sec_count)
        messages.append({"role": "assistant", "content": f"Applied step {i} with action={step.action}.\n\n" + ver_text})

        # Decide if we are done or need another iteration
        if worst == 0:
            final_msg = "Verification passed (checks OK)."
            steps.append(step)
            lessons_learned.append(f"Successfully completed task '{cfg.task}' with {len(steps)} steps")
            
            # Save to memory
            if session and memory_store:
                task_mem = TaskMemory(
                    task=cfg.task,
                    timestamp=time.time(),
                    success=True,
                    steps_taken=len(steps),
                    files_modified=files_modified,
                    lessons_learned=lessons_learned,
                    errors_encountered=errors_encountered,
                    verification_results={"checks_status": worst, "security_issues": sec_count},
                    final_message=final_msg,
                )
                memory_store.add_task(session.session_id, task_mem)
            
            return AgentResult(success=True, steps=steps, final_message=final_msg, stats={"context": ctx_stats})

        # Provide feedback to the LLM for self-correction
        # Include a compact summary of the failing outputs
        messages.append(
            {
                "role": "user",
                "content": (
                    "Verification failed. Refine plan and try again. "
                    "Focus on the concrete errors above; propose minimal fixes."
                ),
            }
        )

        steps.append(step)

    # Out of steps
    final_msg = final_msg or "Reached max steps without all checks passing."
    errors_encountered.append("Reached max steps without completing task")
    
    # Save failed attempt to memory
    if session and memory_store:
        task_mem = TaskMemory(
            task=cfg.task,
            timestamp=time.time(),
            success=False,
            steps_taken=len(steps),
            files_modified=files_modified,
            lessons_learned=lessons_learned,
            errors_encountered=errors_encountered,
            verification_results={},
            final_message=final_msg,
        )
        memory_store.add_task(session.session_id, task_mem)
    
    return AgentResult(success=False, steps=steps, final_message=final_msg, stats={"context": ctx_stats})
