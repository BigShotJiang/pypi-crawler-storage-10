from __future__ import annotations

from pathlib import Path
from typing import Any

try:
    from textual.app import App, ComposeResult
    from textual.containers import Container, Horizontal, Vertical, ScrollableContainer
    from textual.widgets import (
        Header, Footer, DirectoryTree, Input, Static, Label, 
        Button, SelectionList, OptionList, ListView, ListItem, Markdown,
        TabbedContent, TabPane
    )
    from textual.widgets.option_list import Option
    from textual.binding import Binding
    from textual.screen import Screen, ModalScreen
    from textual import events
    from textual.message import Message
    TEXTUAL_AVAILABLE = True
except ImportError:
    TEXTUAL_AVAILABLE = False
    # Define minimal stubs so module can import without textual
    class App: ...
    class ComposeResult: ...
    class Container: ...
    class Horizontal: ...
    class Vertical: ...
    class ScrollableContainer: ...
    class Header: ...
    class Footer: ...
    class DirectoryTree:
        class FileSelected: ...
    class Input:
        class Submitted: ...
        def __init__(self, *args, **kwargs): pass
    class Static:
        def __init__(self, *args, **kwargs): pass
    class Label: ...
    class Button:
        class Pressed: ...
        def __init__(self, *args, **kwargs): pass
    class SelectionList: ...
    class OptionList:
        class OptionSelected: ...
        def __init__(self, *args, **kwargs): pass
    class ListView: ...
    class ListItem: ...
    class Markdown: ...
    class TabbedContent: ...
    class TabPane:
        def __init__(self, *args, **kwargs): pass
    class Option:
        def __init__(self, *args, **kwargs): pass
    class Binding:
        def __init__(self, *args, **kwargs): pass
    class Screen: ...
    class ModalScreen: ...
    class events: ...
    class Message: ...

import re


class ModelSelectorScreen(ModalScreen):
    """Screen to select AI provider and model."""
    
    def __init__(self, current_provider: str, current_model: str):
        super().__init__()
        self.current_provider = current_provider
        self.current_model = current_model
    
    def compose(self) -> ComposeResult:
        with Container(id="model-dialog"):
            yield Static("[bold cyan]Select AI Provider & Model[/bold cyan]", id="dialog-title")
            
            # Provider selection
            yield Label("Provider:")
            yield OptionList(
                Option("Ollama (local)", id="ollama"),
                Option("Gemini (cloud)", id="gemini"),
                Option("OpenAI (cloud)", id="openai"),
                Option("Anthropic (cloud)", id="anthropic"),
                id="provider-list"
            )
            
            # Model list (initially empty, populated when provider selected)
            yield Label("Model:")
            yield Static("Select a provider first", id="model-status")
            yield OptionList(id="model-list")
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Select", variant="primary", id="select-btn")
                yield Button("Refresh Models", variant="default", id="refresh-btn")
                yield Button("Cancel", variant="default", id="cancel-btn")
    
    def on_mount(self) -> None:
        """Load models for current provider on mount."""
        self.load_models_for_provider(self.current_provider)
    
    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        """Handle provider selection to load models."""
        if event.option_list.id == "provider-list":
            provider = event.option.id
            if provider:
                self.load_models_for_provider(provider)
    
    def load_models_for_provider(self, provider: str) -> None:
        """Load available models for the selected provider."""
        model_list = self.query_one("#model-list", OptionList)
        status = self.query_one("#model-status", Static)
        model_list.clear_options()
        
        try:
            if provider == "ollama":
                import subprocess
                result = subprocess.run(["ollama", "list"], capture_output=True, text=True, timeout=5)
                if result.returncode == 0:
                    lines = result.stdout.strip().split("\n")[1:]  # Skip header
                    for line in lines:
                        if line.strip():
                            model_name = line.split()[0]
                            model_list.add_option(Option(model_name, id=model_name))
                    status.update(f"[green]Found {len(lines)} Ollama models[/green]")
                else:
                    status.update("[red]Ollama not running or no models[/red]")
            elif provider == "gemini":
                # Common Gemini models
                models = ["gemini-1.5-pro-latest", "gemini-1.5-flash-latest", "gemini-2.0-flash-exp"]
                for m in models:
                    model_list.add_option(Option(m, id=m))
                status.update(f"[green]{len(models)} Gemini models[/green]")
            elif provider == "openai":
                # Common OpenAI models
                models = ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-3.5-turbo"]
                for m in models:
                    model_list.add_option(Option(m, id=m))
                status.update(f"[green]{len(models)} OpenAI models[/green]")
            elif provider == "anthropic":
                # Common Anthropic models
                models = ["claude-3-5-sonnet-latest", "claude-3-5-haiku-latest", "claude-3-opus-latest"]
                for m in models:
                    model_list.add_option(Option(m, id=m))
                status.update(f"[green]{len(models)} Anthropic models[/green]")
        except Exception as e:
            status.update(f"[red]Error: {e}[/red]")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "cancel-btn":
            self.dismiss(None)
        elif event.button.id == "refresh-btn":
            provider_list = self.query_one("#provider-list", OptionList)
            if provider_list.highlighted is not None:
                selected = provider_list.get_option_at_index(provider_list.highlighted)
                self.load_models_for_provider(selected.id)
        elif event.button.id == "select-btn":
            provider_list = self.query_one("#provider-list", OptionList)
            model_list = self.query_one("#model-list", OptionList)
            
            if provider_list.highlighted is not None and model_list.highlighted is not None:
                provider = provider_list.get_option_at_index(provider_list.highlighted)
                model = model_list.get_option_at_index(model_list.highlighted)
                if provider and model:
                    self.dismiss({"provider": provider.id, "model": model.id})
            else:
                # Show error if nothing selected
                status = self.query_one("#model-status", Static)
                status.update("[red]Please select both provider and model[/red]")


class CreateFileScreen(ModalScreen):
    """Screen to create a new file."""
    
    def compose(self) -> ComposeResult:
        with Container(id="create-dialog"):
            yield Static("[bold cyan]Create New File[/bold cyan]", id="dialog-title")
            yield Input(placeholder="Enter filename (e.g. notes.md)", id="filename-input")
            yield Input(placeholder="Enter initial content (optional)", id="content-input")
            yield Static("", id="create-error")
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Create", variant="primary", id="create-btn")
                yield Button("Cancel", variant="default", id="cancel-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "cancel-btn":
            self.dismiss(None)
        elif event.button.id == "create-btn":
            filename = self.query_one("#filename-input", Input).value.strip()
            content = self.query_one("#content-input", Input).value
            if filename:
                # Basic validation
                if '/' in filename or '\\' in filename or filename.startswith(".."):
                    err = self.query_one("#create-error", Static)
                    err.update("[red]Invalid name. Use a simple filename without paths.[/red]")
                    return
                self.dismiss({"filename": filename, "content": content})


class MCPServerScreen(ModalScreen):
    """Screen to manage MCP servers."""
    
    def compose(self) -> ComposeResult:
        with Container(id="mcp-dialog"):
            yield Static("[bold cyan]MCP Servers[/bold cyan]", id="dialog-title")
            
            try:
                from .mcp_config import load_mcp_servers
                servers = load_mcp_servers()
                
                if servers:
                    server_list = ScrollableContainer(id="server-list")
                    for name, config in servers.items():
                        server_list.mount(Static(f"[green]●[/green] {name}: {' '.join(config.command)}"))
                    yield server_list
                else:
                    yield Static("No MCP servers configured\n\nAdd servers to ~/.config/ollcoder/mcp_servers.json")
            except Exception as e:
                yield Static(f"Error loading MCP servers: {e}")
            
            yield Button("Close", variant="primary", id="close-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss()


class OnboardingScreen(ModalScreen):
    """First-run onboarding: trust + provider/model checks."""
    def __init__(self, root: str, provider_name: str, model: str):
        super().__init__()
        self.root = root
        self.provider_name = provider_name
        self.model = model

    def compose(self) -> ComposeResult:
        from .onboard import build_onboarding_plan
        plan = build_onboarding_plan(self.root, provider=self.provider_name, model=self.model)
        lines = [f"Project: {self.root}", f"Trust: {plan.trust_level}"]
        if plan.provider:
            pv = plan.provider
            status = "installed" if pv.installed else "not installed"
            avail = "available" if pv.model_available else "missing"
            lines.append(f"Provider: {pv.name} ({status}), model: {pv.model} ({avail})")
        else:
            lines.append("Provider: not configured")
        lines.append("")
        lines.append("Recommended actions:")
        for a in plan.actions[:5]:
            lines.append(f"- {a}")

        with Container(id="onboard-dialog"):
            yield Static("[bold cyan]Welcome to Ollcoder[/bold cyan]", id="dialog-title")
            yield Markdown("\n".join(lines), id="onboard-body")
            with Horizontal(id="dialog-buttons"):
                yield Button("Set TRUSTED", variant="primary", id="btn-trust")
                if plan.provider and plan.provider.name == "ollama" and plan.provider.installed and plan.provider.model and not plan.provider.model_available:
                    yield Button("Pull Model", variant="default", id="btn-pull")
                yield Button("Don't show again", variant="default", id="btn-hide")
                yield Button("Close", variant="default", id="btn-close")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        bid = event.button.id or ""
        if bid == "btn-close":
            self.dismiss(None)
        elif bid == "btn-hide":
            # Persist onboarding_done
            try:
                import json
                from pathlib import Path as _P
                settings_file = _P.home() / ".config" / "ollcoder" / "tui_settings.json"
                data = {}
                if settings_file.exists():
                    data = json.loads(settings_file.read_text())
                data["onboarding_done"] = True
                settings_file.parent.mkdir(parents=True, exist_ok=True)
                settings_file.write_text(json.dumps(data, indent=2))
            except Exception:
                pass
            self.dismiss(True)
        elif bid == "btn-trust":
            from .trusted_folders import global_trust, TrustLevel
            try:
                global_trust().set_level(self.root, TrustLevel.TRUSTED, persist=True)
                body = self.query_one("#onboard-body", Static)
                body.update("[green]Set TRUSTED for this project[/green]")
            except Exception as e:
                body = self.query_one("#onboard-body", Static)
                body.update(f"[red]Failed to set trust: {e}[/red]")
        elif bid == "btn-pull":
            # Best-effort ollama pull
            try:
                import subprocess
                subprocess.run(["ollama", "pull", self.model], timeout=300)
                body = self.query_one("#onboard-body", Static)
                body.update("[green]Model pull attempted. Reopen onboarding to refresh status.[/green]")
            except Exception as e:
                body = self.query_one("#onboard-body", Static)
                body.update(f"[red]Failed to pull: {e}[/red]")


class ProviderHealthScreen(ModalScreen):
    """Display provider health information."""
    def __init__(self, provider: Any, provider_name: str, model: str):
        super().__init__()
        self.provider = provider
        self.provider_name = provider_name
        self.model = model

    def compose(self) -> ComposeResult:
        with Container(id="health-dialog"):
            yield Static("[bold cyan]Provider Health[/bold cyan]", id="dialog-title")
            yield Static(self._health_text(), id="health-body")
            with Horizontal(id="dialog-buttons"):
                yield Button("Refresh", variant="primary", id="btn-refresh")
                yield Button("Close", variant="default", id="btn-close")

    def _health_text(self) -> str:
        try:
            if hasattr(self.provider, "health_check"):
                info = self.provider.health_check()
                return f"Provider: {self.provider_name}\nModel: {self.model}\nStatus: {info.get('status')}\nError: {info.get('error', '')}"
        except Exception as e:
            return f"Provider: {self.provider_name}\nModel: {self.model}\nStatus: error\nError: {e}"
        return f"Provider: {self.provider_name}\nModel: {self.model}\nStatus: unknown"

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-close":
            self.dismiss(None)
        elif event.button.id == "btn-refresh":
            body = self.query_one("#health-body", Static)
            body.update(self._health_text())

class CommandPaletteScreen(ModalScreen):
    """Screen to show command palette."""
    
    def compose(self) -> ComposeResult:
        with Container(id="command-dialog"):
            yield Static("[bold cyan]Command Palette[/bold cyan]", id="dialog-title")
            
            options = [
                Option("🔧 Change Model (Ctrl+M)", id="change_model"),
                Option("📄 New File (Ctrl+N)", id="new_file"),
                Option("💾 Export Chat (Ctrl+E)", id="export_chat"),
                Option("📋 Copy Last Reply (Ctrl+Y)", id="copy_last"),
                Option("❤️ Provider Health (Ctrl+H)", id="provider_health"),
                Option("🗑️  Clear Chat (Ctrl+L)", id="clear_chat"),
                Option("🔌 MCP Servers (Ctrl+S)", id="mcp_servers"),
                Option("🏗️  Context Builder (Ctrl+B)", id="context_builder"),
                Option("🤖 Run Agent (Ctrl+R)", id="run_agent"),
                Option("🔒 Trust Manager (Ctrl+T)", id="trust_manager"),
                Option("🔐 Security Scan (Ctrl+K)", id="security_scan"),
                Option("🧠 View Memory (Ctrl+Shift+M)", id="view_memory"),
                Option("⚙️  Settings (Ctrl+Comma)", id="settings"),
                Option("❌ Quit (Ctrl+Q)", id="quit"),
            ]
            yield OptionList(*options, id="command-list")
            
            yield Button("Cancel", variant="default", id="cancel-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss(None)
    
    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        self.dismiss(event.option.id)


class ChatMessage(Static):
    """A single chat message."""
    pass


class ChatPanel(ScrollableContainer):
    """Chat messages panel."""
    
    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.messages: list[tuple[str, str]] = []
    
    def add_message(self, role: str, content: str) -> None:
        """Add a message to the chat."""
        self.messages.append((role, content))
        
        role_style = "bold cyan" if role == "assistant" else "bold green"
        role_label = "🤖 Assistant" if role == "assistant" else "👤 You"
        
        # Create message with proper mounting
        msg_text = f"[{role_style}]{role_label}[/{role_style}]\n{content}\n"
        msg = ChatMessage(msg_text)
        self.mount(msg)
        msg.scroll_visible()


class OllcoderTUI(App):
    """Ollcoder Terminal User Interface."""
    
    CSS = """
    /* OLED Dark Theme */
    Screen {
        background: #000000;
    }
    
    Header {
        background: #0a0a0a;
        color: #00ff88;
    }
    
    Footer {
        background: #0a0a0a;
        color: #00ff88;
    }
    
    #sidebar {
        width: 30;
        background: #0a0a0a;
        border-right: solid #00ff88;
    }
    
    #chat-container {
        width: 1fr;
        background: #000000;
    }
    
    TabbedContent {
        height: 1fr;
    }
    
    ChatPanel {
        background: #000000;
        padding: 1;
    }
    
    #input-container {
        height: 3;
        background: #0a0a0a;
        padding: 0 1;
    }
    
    Input {
        background: #0a0a0a;
        color: #00ff88;
        border: solid #00ff88;
    }
    
    Input:focus {
        border: solid #00ff88;
    }
    
    DirectoryTree {
        padding: 1;
        background: #0a0a0a;
        color: #888888;
    }
    
    DirectoryTree:focus {
        border: solid #00ff88;
    }
    
    Tree > .tree--label {
        color: #888888;
    }
    
    Tree > .tree--cursor {
        background: #1a1a1a;
        color: #00ff88;
    }
    
    ChatMessage {
        margin-bottom: 1;
        background: #000000;
        color: #cccccc;
    }
    
    #info-panel {
        height: 5;
        background: #0a0a0a;
        padding: 1;
        margin-bottom: 1;
        border: solid #00ff88;
    }
    
    Static {
        color: #cccccc;
    }
    
    /* Modal Dialogs */
    ModalScreen {
        align: center middle;
    }
    
    #model-dialog, #create-dialog, #mcp-dialog {
        width: 60;
        height: auto;
        background: #0a0a0a;
        border: solid #00ff88;
        padding: 2;
    }
    
    #dialog-title {
        margin-bottom: 1;
        text-align: center;
    }
    
    #dialog-buttons {
        margin-top: 1;
        height: 3;
        align: center middle;
    }
    
    Button {
        margin: 0 1;
    }
    
    OptionList {
        height: 15;
        border: solid #00ff88;
        background: #000000;
    }
    
    #server-list {
        height: 20;
        border: solid #00ff88;
        background: #000000;
        padding: 1;
    }
    
    #command-dialog {
        width: 60;
        height: auto;
        background: #0a0a0a;
        border: solid #00ff88;
        padding: 2;
    }
    
    #command-list {
        height: 15;
        border: solid #00ff88;
        background: #000000;
        margin-bottom: 1;
    }
    """
    
    BINDINGS = [
        # Essential (shown in footer)
        Binding("ctrl+c", "quit", "Quit", priority=True),
        Binding("ctrl+p", "command_palette", "Commands", show=True),
        Binding("ctrl+m", "change_model", "Model", show=True),
        Binding("ctrl+r", "run_agent", "Agent", show=True),
        Binding("ctrl+y", "copy_last", "Copy", show=True),
        Binding("ctrl+h", "provider_health", "Health", show=True),
        Binding("ctrl+b", "context_builder", "Context", show=True),
        Binding("ctrl+t", "trust_manager", "Trust", show=True),
        # Hidden (accessible via Ctrl+P or keybind)
        Binding("ctrl+q", "quit", "Quit", show=False),
        Binding("ctrl+l", "clear_chat", "Clear", show=False),
        Binding("ctrl+n", "new_file", "New File", show=False),
        Binding("ctrl+s", "mcp_servers", "MCP", show=False),
        Binding("ctrl+e", "export_chat", "Export", show=False),
        Binding("ctrl+k", "security_scan", "Security", show=False),
        Binding("ctrl+w", "web_fetch", "Web", show=False),
        # Advanced features - Shift variants (all hidden)
        Binding("ctrl+shift+m", "view_memory", "Memory", show=False),
        Binding("ctrl+shift+s", "manage_sessions", "Sessions", show=False),
        Binding("ctrl+shift+f", "search_chat", "Search", show=False),
        Binding("ctrl+shift+e", "edit_file", "Edit", show=False),
        Binding("ctrl+shift+c", "checks_runner", "Checks", show=False),
        Binding("ctrl+shift+r", "multi_repo", "Multi-Repo", show=False),
        Binding("ctrl+shift+o", "eco_dashboard", "Eco", show=False),
        Binding("ctrl+shift+t", "ethics_scan", "Ethics", show=False),
        Binding("ctrl+shift+b", "blockchain_view", "Blockchain", show=False),
        # Settings
        Binding("ctrl+comma", "settings", "Settings", show=False),
    ]
    
    def __init__(self, root: str, provider: Any, model: str, provider_name: str = "ollama"):
        super().__init__()
        self.root = root
        self.provider = provider
        self.model = model
        self.provider_name = provider_name
        self.streaming_active: bool = False
        self.messages: list[dict[str, str]] = [
            {"role": "system", "content": (
                "You are a helpful coding assistant. Be conversational and concise.\n"
                "When the user asks about specific files or features, I will provide relevant code context.\n"
                "Only explain code details when asked."
            )},
        ]

    def _render_info_panel(self) -> str:
        """Build the info panel text including streaming state and git info."""
        status = "[yellow]Streaming...[/yellow]" if self.streaming_active else "[dim]Idle[/dim]"
        git_info = self._get_git_info()
        return (
            f"[bold cyan]🤖 Ollcoder[/bold cyan]\n"
            f"Provider: {self.provider_name}\n"
            f"Model: {self.model}\n"
            f"Project: {Path(self.root).name}\n"
            f"Status: {status}\n"
            f"{git_info}"
        )

    def _update_info_panel(self) -> None:
        """Refresh the info panel widget if present."""
        try:
            info_panel = self.query_one("#info-panel", Static)
            info_panel.update(self._render_info_panel())
        except Exception:
            pass
    
    def compose(self) -> ComposeResult:
        """Create child widgets."""
        yield Header()
        
        with Horizontal():
            with Vertical(id="sidebar"):
                yield Static(self._render_info_panel(), id="info-panel")
                yield DirectoryTree(self.root)
            
            with Vertical(id="chat-container"):
                with TabbedContent(initial="chat-1"):
                    with TabPane("Chat 1", id="chat-1"):
                        yield ChatPanel(id="chat-panel-1")
                    with TabPane("Chat 2", id="chat-2"):
                        yield ChatPanel(id="chat-panel-2")
                with Container(id="input-container"):
                    yield Input(placeholder="Type your message...", id="chat-input")
        
        yield Footer()
    
    def on_mount(self) -> None:
        """Handle app mount."""
        # Add welcome message to first tab
        chat_panel = self.query_one("#chat-panel-1", ChatPanel)
        chat_panel.add_message(
            "assistant",
            "👋 Welcome to Ollcoder!\n\n"
            "**Quick Actions:**\n"
            "• Ctrl+B - Build Context\n"
            "• Ctrl+R - Run Agent\n"
            "• Ctrl+T - Trust Manager\n"
            "• Ctrl+K - Security Scan\n"
            "• Ctrl+M - Change Model\n"
            "• Ctrl+P - Command Palette\n"
            "• Ctrl+Shift+M - View Memory\n"
            "• Ctrl+Comma - Settings\n\n"
            "What would you like to work on?"
        )
        self.query_one("#chat-input", Input).focus()

        # Show onboarding if needed
        try:
            import json
            settings_file = Path.home() / ".config" / "ollcoder" / "tui_settings.json"
            seen = False
            if settings_file.exists():
                try:
                    data = json.loads(settings_file.read_text())
                    seen = bool(data.get("onboarding_done"))
                except Exception:
                    seen = False
            from .trusted_folders import global_trust, TrustLevel
            trust_lvl = global_trust().get_level(self.root)
            needs_trust = trust_lvl == TrustLevel.UNTRUSTED
            needs_provider = self.provider is None
            if not seen and (needs_trust or needs_provider):
                async def show_onboarding():
                    await self.push_screen_wait(OnboardingScreen(self.root, self.provider_name, self.model))
                self.run_worker(show_onboarding())
        except Exception:
            pass
    
    def _get_active_chat_panel(self) -> ChatPanel:
        """Get the currently active chat panel."""
        tabbed = self.query_one(TabbedContent)
        active_tab = tabbed.active
        if active_tab == "chat-1":
            return self.query_one("#chat-panel-1", ChatPanel)
        else:
            return self.query_one("#chat-panel-2", ChatPanel)
    
    def on_directory_tree_file_selected(self, event: DirectoryTree.FileSelected) -> None:
        """Handle file selection in directory tree."""
        try:
            filepath = event.path
            # Read file content (limit to reasonable size)
            content = filepath.read_text(encoding='utf-8', errors='ignore')[:5000]
            
            chat_panel = self._get_active_chat_panel()
            chat_panel.add_message(
                "assistant",
                f"**File: {filepath.name}**\n\n```\n{content}\n```\n\nWhat would you like to know about this file?"
            )
        except Exception as e:
            chat_panel = self._get_active_chat_panel()
            chat_panel.add_message("assistant", f"❌ Error reading file: {e}")
    
    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle message submission."""
        if event.input.id != "chat-input":
            return
        
        user_input = event.value.strip()
        if not user_input:
            return
        
        # Clear input
        event.input.value = ""
        
        # Add user message to chat
        chat_panel = self._get_active_chat_panel()
        chat_panel.add_message("you", user_input)
        
        # Get AI response
        self.messages.append({"role": "user", "content": user_input})
        
        try:
            # Prepare a placeholder assistant message to update as we stream
            placeholder = ChatMessage("")
            chat_panel.mount(placeholder)

            async def stream_and_update():
                try:
                    from .tui_backend import StreamingBackend
                    backend = StreamingBackend(self.provider)
                    async def on_chunk(txt: str):
                        # Update the placeholder with streamed content
                        placeholder.update(f"[bold cyan]🤖 Assistant[/bold cyan]\n{txt}")
                    # Mark streaming active at first chunk dispatch
                    self.streaming_active = True
                    self._update_info_panel()
                    final_text = await backend.stream_response(self.messages, on_chunk)
                except Exception:
                    # Fallback to non-streaming
                    resp = self.provider.chat(self.messages, stream=False)
                    final_text = self._extract_response_text(resp)
                    placeholder.update(f"[bold cyan]🤖 Assistant[/bold cyan]\n{final_text}")
                # Record assistant message
                self.messages.append({"role": "assistant", "content": final_text})
                # Streaming complete
                self.streaming_active = False
                self._update_info_panel()

            self.run_worker(stream_and_update())
        except Exception as e:
            chat_panel.add_message("assistant", f"❌ Error: {e}")
    
    def action_clear_chat(self) -> None:
        """Clear the chat."""
        chat_panel = self._get_active_chat_panel()
        chat_panel.remove_children()
        chat_panel.messages.clear()
        self.messages = self.messages[:1]  # Keep system message
        chat_panel.add_message(
            "assistant",
            "Chat cleared! How can I help you?"
        )
    
    def action_change_model(self) -> None:
        """Open model and provider selector."""
        async def show_model_selector():
            result = await self.push_screen_wait(ModelSelectorScreen(self.provider_name, self.model))
            if result:
                from .providers.factory import create_provider
                new_provider_name = result["provider"]
                new_model = result["model"]
                
                # Update provider and model
                try:
                    # Get API key if needed
                    api_key = None
                    if new_provider_name == "gemini":
                        from .secrets import get_gemini_api_key
                        api_key = get_gemini_api_key(optional=True)
                    elif new_provider_name == "openai":
                        from .secrets import get_openai_api_key
                        api_key = get_openai_api_key(optional=True)
                    elif new_provider_name == "anthropic":
                        from .secrets import get_anthropic_api_key
                        api_key = get_anthropic_api_key(optional=True)
                    
                    self.provider = create_provider(new_provider_name, new_model, api_key)
                    self.provider_name = new_provider_name
                    self.model = new_model
                    
                    self._update_info_panel()
                    chat_panel = self._get_active_chat_panel()
                    chat_panel.add_message("assistant", f"✅ Switched to {new_provider_name}/{new_model}")
                except Exception as e:
                    chat_panel = self._get_active_chat_panel()
                    chat_panel.add_message("assistant", f"❌ Failed to switch provider: {e}")
        
        self.run_worker(show_model_selector())
    
    def action_new_file(self) -> None:
        """Create a new file."""
        async def show_create_dialog():
            result = await self.push_screen_wait(CreateFileScreen())
            if result:
                try:
                    filepath = Path(self.root) / result["filename"]
                    filepath.write_text(result["content"] or "")
                    chat_panel = self._get_active_chat_panel()
                    chat_panel.add_message("assistant", f"✅ Created file: {result['filename']}")
                    # Refresh directory tree
                    tree = self.query_one(DirectoryTree)
                    tree.reload()
                except Exception as e:
                    chat_panel = self._get_active_chat_panel()
                    chat_panel.add_message("assistant", f"❌ Error creating file: {e}")
        
        self.run_worker(show_create_dialog())
    
    def action_mcp_servers(self) -> None:
        """Show MCP servers."""
        async def show_mcp_dialog():
            await self.push_screen_wait(MCPServerScreen())
        
        self.run_worker(show_mcp_dialog())
    
    def action_command_palette(self) -> None:
        """Show command palette."""
        async def show_palette():
            result = await self.push_screen_wait(CommandPaletteScreen())
            if result:
                # Execute the selected command
                command_map = {
                    "change_model": self.action_change_model,
                    "new_file": self.action_new_file,
                    "export_chat": self.action_export_chat,
                    "copy_last": self.action_copy_last,
                    "provider_health": self.action_provider_health,
                    "clear_chat": self.action_clear_chat,
                    "mcp_servers": self.action_mcp_servers,
                    "context_builder": self.action_context_builder,
                    "run_agent": self.action_run_agent,
                    "trust_manager": self.action_trust_manager,
                    "security_scan": self.action_security_scan,
                    "view_memory": self.action_view_memory,
                    "settings": self.action_settings,
                    "quit": self.action_quit,
                }
                if result in command_map:
                    command_map[result]()
        
        self.run_worker(show_palette())
    
    def action_export_chat(self) -> None:
        """Export chat to markdown file."""
        try:
            from datetime import datetime
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"chat_export_{timestamp}.md"
            filepath = Path(self.root) / filename
            
            chat_panel = self._get_active_chat_panel()
            content = f"# Ollcoder Chat Export\n\nModel: {self.model}\nDate: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n---\n\n"
            
            for role, text in chat_panel.messages:
                role_name = "Assistant" if role == "assistant" else "You"
                content += f"## {role_name}\n\n{text}\n\n"
            
            filepath.write_text(content)
            chat_panel.add_message("assistant", f"✅ Chat exported to: {filename}")
        except Exception as e:
            chat_panel = self._get_active_chat_panel()
            chat_panel.add_message("assistant", f"❌ Error exporting: {e}")

    def action_copy_last(self) -> None:
        """Copy the last assistant reply to the clipboard or a cache file."""
        panel = self._get_active_chat_panel()
        if not panel.messages:
            return
        last = None
        for role, content in reversed(panel.messages):
            if role == "assistant" and content:
                last = content
                break
        if last is None:
            return
        try:
            import pyperclip  # type: ignore
            pyperclip.copy(last)
            panel.add_message("assistant", "[green]Copied last reply to clipboard[/green]")
        except Exception:
            from pathlib import Path as _P
            cache_dir = _P.home() / ".cache" / "ollcoder"
            try:
                cache_dir.mkdir(parents=True, exist_ok=True)
                out = cache_dir / "clipboard.txt"
                out.write_text(last)
                panel.add_message("assistant", f"[yellow]Clipboard unavailable; wrote to {out}[/yellow]")
            except Exception:
                panel.add_message("assistant", "[red]Failed to copy or write clipboard file[/red]")
    
    # ==================== Advanced Actions ====================
    
    def action_context_builder(self) -> None:
        """Open context builder."""
        from .tui_advanced import ContextBuilderScreen
        async def show_builder():
            await self.push_screen_wait(ContextBuilderScreen())
        self.run_worker(show_builder())
    
    def action_view_memory(self) -> None:
        """Open memory viewer."""
        from .tui_advanced import MemoryViewerScreen
        async def show_memory():
            await self.push_screen_wait(MemoryViewerScreen())
        self.run_worker(show_memory())

    def action_run_agent(self) -> None:
        """Open agent runner."""
        from .tui_advanced import AgentRunnerScreen
        async def show_agent():
            await self.push_screen_wait(AgentRunnerScreen(self.root, self.provider, apply_changes=False))
        self.run_worker(show_agent())

    def action_provider_health(self) -> None:
        """Show provider health modal."""
        async def show_health():
            await self.push_screen_wait(ProviderHealthScreen(self.provider, self.provider_name, self.model))
        self.run_worker(show_health())
    
    def action_security_scan(self) -> None:
        """Open security scanner."""
        from .tui_advanced import SecurityScannerScreen
        async def show_scanner():
            await self.push_screen_wait(SecurityScannerScreen())
        self.run_worker(show_scanner())
    
    def action_trust_manager(self) -> None:
        """Open trust manager."""
        from .tui_advanced import TrustManagerScreen
        async def show_trust():
            await self.push_screen_wait(TrustManagerScreen())
        self.run_worker(show_trust())
    
    def action_manage_sessions(self) -> None:
        """Open session manager."""
        from .tui_advanced import SessionSelectorScreen, SessionManager
        session_manager = SessionManager(self.root)
        async def show_sessions():
            result = await self.push_screen_wait(SessionSelectorScreen(session_manager))
            if result:
                chat_panel = self._get_active_chat_panel()
                chat_panel.add_message("assistant", f"Session action: {result.get('action')}")
        self.run_worker(show_sessions())
    
    def action_search_chat(self) -> None:
        """Open chat search."""
        from .tui_advanced import SearchScreen
        async def show_search():
            await self.push_screen_wait(SearchScreen())
        self.run_worker(show_search())
    
    def action_edit_file(self) -> None:
        """Open file editor for the currently selected file."""
        from .tui_advanced import FileEditorScreen
        try:
            tree = self.query_one(DirectoryTree)
            node = getattr(tree, "cursor_node", None)
            path_obj = getattr(node, "data", None).path if node and getattr(node, "data", None) else None
            if not path_obj or not Path(path_obj).is_file():
                chat_panel = self._get_active_chat_panel()
                chat_panel.add_message("assistant", "❌ No file selected in the tree.")
                return
            content = Path(path_obj).read_text(encoding="utf-8", errors="ignore")
            async def show_editor():
                result = await self.push_screen_wait(FileEditorScreen(str(path_obj), content))
                if isinstance(result, str):
                    Path(path_obj).write_text(result)
                    chat_panel = self._get_active_chat_panel()
                    chat_panel.add_message("assistant", f"✅ Saved changes to {Path(path_obj).name}")
            self.run_worker(show_editor())
        except Exception as e:
            chat_panel = self._get_active_chat_panel()
            chat_panel.add_message("assistant", f"❌ Error opening editor: {e}")
    
    def action_checks_runner(self) -> None:
        """Open checks runner."""
        from .tui_advanced import ChecksRunnerScreen
        async def show_checks():
            await self.push_screen_wait(ChecksRunnerScreen())
        self.run_worker(show_checks())
    
    def action_multi_repo(self) -> None:
        """Open multi-repo manager."""
        from .tui_advanced import MultiRepoScreen
        async def show_multi():
            await self.push_screen_wait(MultiRepoScreen())
        self.run_worker(show_multi())
    
    def action_eco_dashboard(self) -> None:
        """Open eco dashboard."""
        from .tui_advanced import EcoDashboardScreen
        async def show_eco():
            await self.push_screen_wait(EcoDashboardScreen())
        self.run_worker(show_eco())
    
    def action_ethics_scan(self) -> None:
        """Open ethics scanner."""
        from .tui_advanced import EthicsScannerScreen
        async def show_ethics():
            await self.push_screen_wait(EthicsScannerScreen())
        self.run_worker(show_ethics())
    
    def action_blockchain_view(self) -> None:
        """Open blockchain viewer."""
        from .tui_advanced import BlockchainViewerScreen
        async def show_blockchain():
            await self.push_screen_wait(BlockchainViewerScreen())
        self.run_worker(show_blockchain())
    
    def action_web_fetch(self) -> None:
        """Open web fetch panel."""
        from .tui_advanced import WebFetchScreen
        async def show_web():
            await self.push_screen_wait(WebFetchScreen())
        self.run_worker(show_web())
    
    def action_settings(self) -> None:
        """Open settings."""
        from .tui_advanced import SettingsScreen
        async def show_settings():
            await self.push_screen_wait(SettingsScreen())
        self.run_worker(show_settings())
    
    def _get_git_info(self) -> str:
        """Get git branch and status."""
        try:
            import subprocess
            # Get branch
            result = subprocess.run(
                ["git", "branch", "--show-current"],
                cwd=self.root,
                capture_output=True,
                text=True,
                timeout=2
            )
            if result.returncode == 0:
                branch = result.stdout.strip()
                
                # Get status
                status_result = subprocess.run(
                    ["git", "status", "--short"],
                    cwd=self.root,
                    capture_output=True,
                    text=True,
                    timeout=2
                )
                modified = len(status_result.stdout.strip().split("\n")) if status_result.stdout.strip() else 0
                
                return f"[dim]🌳 {branch} ({modified} modified)[/dim]"
        except Exception:
            pass
        return ""
    
    def _extract_response_text(self, resp: Any) -> str:
        """Extract text from provider response."""
        if resp is None:
            return ""
        
        # Ollama returns objects with .message.content attribute
        if hasattr(resp, "message"):
            msg = getattr(resp, "message")
            if msg and hasattr(msg, "content"):
                content = getattr(msg, "content")
                if isinstance(content, str) and content.strip():
                    return content
        
        # Gemini style
        txt = getattr(resp, "text", None)
        if isinstance(txt, str) and txt.strip():
            return txt
        
        # Dict style fallback
        if isinstance(resp, dict):
            msg = resp.get("message")
            if isinstance(msg, dict):
                c = msg.get("content")
                if isinstance(c, str) and c.strip():
                    return c
            c = resp.get("content")
            if isinstance(c, str) and c.strip():
                return c
        
        return ""


def run_tui(root: str, provider: Any, model: str, provider_name: str = "ollama") -> int:
    """Run the TUI application."""
    if not TEXTUAL_AVAILABLE:
        print("Error: Textual not installed. Run: pip install 'ollcoder[ui]'")
        return 1
    
    app = OllcoderTUI(root, provider, model, provider_name)
    app.run()
    return 0
