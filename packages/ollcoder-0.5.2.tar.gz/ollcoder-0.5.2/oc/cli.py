from __future__ import annotations

import argparse
import json
import os
import sys
from typing import List

from .adaptive_builder import AdaptiveConfig, build_adaptive_context
from .agent import AgentConfig, run_agent
from .config import AppConfig, load_config
from .context_cache import ContextCache
from .logging_util import setup_logging
from .providers.factory import create_provider
from .secrets import get_gemini_api_key, get_openai_api_key, get_anthropic_api_key
from .cli_modules.common import resolve_provider
from .cli_modules import trust as mod_trust
from .cli_modules import sandbox as mod_sandbox
from .cli_modules import security as mod_security
from .cli_modules import mcp as mod_mcp
from .cli_modules import chat as mod_chat
from .cli_modules import agent as mod_agent
from .cli_modules import build_context as mod_build
from .cli_modules import multi as mod_multi
from .cli_modules import shortcuts as mod_shortcuts
from .cli_modules import models as mod_models
from .cli_modules import eco as mod_eco
from .cli_modules import blockchain as mod_blockchain
from .cli_modules import ar as mod_ar
from .cli_modules import predict as mod_predict
from .cli_modules import ethics as mod_ethics
from .cli_modules import memory as mod_memory
from .cli_modules import watch as mod_watch
from .cli_modules import onboard_cli as mod_onboard
from .cli_modules import bench as mod_bench


def _add_build_context(sub: argparse._SubParsersAction) -> None:
    mod_build.add_build_context_subparser(sub)


def _add_trust(sub: argparse._SubParsersAction) -> None:
    mod_trust.add_trust_subparser(sub)


def _add_onboard(sub: argparse._SubParsersAction) -> None:
    mod_onboard.add_onboard_subparser(sub)


def _add_sandbox(sub: argparse._SubParsersAction) -> None:
    mod_sandbox.add_sandbox_subparser(sub)


def _add_shortcuts(sub: argparse._SubParsersAction) -> None:
    mod_shortcuts.add_shortcuts_subparser(sub)


def _add_checks(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("checks", help="Run linters and tests")
    sp = p.add_subparsers(dest="checks_cmd", required=True)
    sp.add_parser("run", help="Run ruff/mypy/pytest if available")


def _add_web(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("web", help="Fetch and extract web pages")
    sp = p.add_subparsers(dest="web_cmd", required=True)
    p_fetch = sp.add_parser("fetch", help="Fetch URL and print text")
    p_fetch.add_argument("--url", required=True)


def _add_security(sub: argparse._SubParsersAction) -> None:
    mod_security.add_security_subparser(sub)


def _add_models(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("models", help="Personalized models utilities")
    sp = p.add_subparsers(dest="model_cmd", required=True)
    sp.add_parser("prepare-dataset", help="Create JSONL dataset from codebase")
    sp.add_parser("modelfile", help="Print an Ollama Modelfile template")
    p_oai = sp.add_parser("openai-create", help="Create an OpenAI fine-tune job")
    p_oai.add_argument("--dataset", required=True, help="Path to JSONL dataset")
    p_oai.add_argument("--base", default="gpt-4o-mini")
    p_oai.add_argument("--suffix")


def _add_agent(sub: argparse._SubParsersAction) -> None:
    mod_agent.add_agent_subparser(sub)


def _add_eco(sub: argparse._SubParsersAction) -> None:
    mod_eco.add_eco_subparser(sub)


def _add_blockchain(sub: argparse._SubParsersAction) -> None:
    mod_blockchain.add_blockchain_subparser(sub)


def _add_ar(sub: argparse._SubParsersAction) -> None:
    mod_ar.add_ar_subparser(sub)


def _add_predict(sub: argparse._SubParsersAction) -> None:
    mod_predict.add_predict_subparser(sub)

def _add_reliability(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("reliability", help="Reliability harness")
    sp = p.add_subparsers(dest="rel_cmd", required=True)
    r = sp.add_parser("run", help="Run agent on a sample task and collect metrics")
    r.add_argument("--root", required=True)
    r.add_argument("--task", required=True)
    r.add_argument("--max-steps", dest="max_steps", type=int, default=6)
    r.add_argument("--apply", dest="apply", action="store_true")
    r.add_argument("--no-tests", dest="run_tests", action="store_false", default=True)
    r.add_argument("--pytest-args", dest="pytest_args", nargs=argparse.REMAINDER)
    r.add_argument("--fake-provider", dest="fake_provider", action="store_true", help="Use built-in fake provider (for CI)")

def _add_ethics(sub: argparse._SubParsersAction) -> None:
    mod_ethics.add_ethics_subparser(sub)


def _add_multi(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("multi", help="Multi-repo orchestration")
    sp = p.add_subparsers(dest="multi_cmd", required=True)
    p_bc = sp.add_parser("build-context", help="Build context across multiple roots")
    p_bc.add_argument("--root", action="append", required=True)
    p_bc.add_argument("--query", default="")
    p_bc.add_argument("--paste", action="store_true")
    p_share = sp.add_parser("share", help="Create or join a shared session across roots")
    p_share.add_argument("--session-id", required=True)
    p_share.add_argument("--root", action="append", required=True)


def _add_watch(sub: argparse._SubParsersAction) -> None:
    mod_watch.add_watch_subparser(sub)


def _add_memory(sub: argparse._SubParsersAction) -> None:
    mod_memory.add_memory_subparser(sub)


def _add_chat(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("chat", help="Interactive chat session with AI about your codebase")
    p.add_argument("--tui", action="store_true", help="Use full TUI interface (requires textual)")
    p.add_argument("--advanced", action="store_true", help="Use advanced TUI with all features (context builder, agent, security, etc.)")
    p.add_argument("--no-context", action="store_true", help="Disable context loading for maximum speed (pure chat mode)")


def main(argv: List[str] | None = None) -> int:
    # Load config and initialize logging before parsing subcommands (noisy libs may log during import)
    cfg: AppConfig = load_config()
    setup_logging(cfg.log_level, cfg.log_json, cfg.log_file)

    ap = argparse.ArgumentParser(prog="oc", description="Ollcoder CLI")
    # Global logging/provider overrides
    ap.add_argument("--log-level", dest="log_level", help="Override log level (DEBUG/INFO/WARNING/ERROR)")
    ap.add_argument("--log-json", dest="log_json", action="store_true", help="Enable JSON structured logs")
    ap.add_argument("--log-file", dest="log_file", help="Write logs to this file (instead of stderr)")
    ap.add_argument(
        "--provider",
        dest="provider",
        choices=["ollama", "gemini", "openai", "anthropic"],
        help="LLM provider for summarization",
    )
    ap.add_argument("--model", dest="model", help="Model for provider (e.g., mistral:latest, gemini-1.5-pro-latest)")
    ap.add_argument(
        "--api-key",
        dest="api_key",
        help="Provider API key (not recommended; prefer env like GEMINI_API_KEY)",
    )
    ap.add_argument("--no-provider", dest="no_provider", action="store_true", help="Disable LLM provider entirely")
    sp = ap.add_subparsers(dest="cmd", required=True)

    mod_chat.add_chat_subparser(sp)
    mod_build.add_build_context_subparser(sp)
    mod_agent.add_agent_subparser(sp)
    _add_trust(sp)
    _add_sandbox(sp)
    _add_shortcuts(sp)
    _add_checks(sp)
    _add_web(sp)
    _add_security(sp)
    _add_models(sp)
    _add_eco(sp)
    _add_blockchain(sp)
    _add_onboard(sp)
    _add_ar(sp)
    _add_predict(sp)
    _add_ethics(sp)
    _add_reliability(sp)
    mod_multi.add_multi_subparser(sp)
    mod_watch.add_watch_subparser(sp)
    mod_memory.add_memory_subparser(sp)
    mod_mcp.add_mcp_subparser(sp)
    # lightweight benchmarking
    p_bench = sp.add_parser("bench", help="Benchmark context builder")
    p_bench.add_argument("--json", dest="json_out", action="store_true")

    ns = ap.parse_args(argv)

    # Re-apply logging with CLI overrides if provided
    final_level = (ns.log_level or cfg.log_level) if hasattr(ns, "log_level") else cfg.log_level
    final_json = bool(getattr(ns, "log_json", False)) or bool(cfg.log_json)
    final_file = getattr(ns, "log_file", None) or cfg.log_file
    setup_logging(final_level, final_json, final_file)

    # Build provider using a single resolution path
    provider = None
    try:
        rname, rmodel, rkey = resolve_provider(ns, cfg)
        if rname:
            provider = create_provider(rname, rmodel, api_key=rkey)
            prov_name, prov_model = rname, rmodel
        else:
            prov_name, prov_model = "", None
    except Exception:
        provider = None
        prov_name, prov_model = "", None

    if ns.cmd == "chat":
        return mod_chat.handle_chat(ns, provider, prov_name, prov_model)

    if ns.cmd == "bench":
        from .cli_modules import bench as mod_bench
        return mod_bench.handle_bench(ns, provider)

    if ns.cmd == "build-context":
        return mod_build.handle_build_context(ns, provider)

    if ns.cmd == "agent":
        return mod_agent.handle_agent(ns, provider)

    if ns.cmd == "trust":
        return mod_trust.handle_trust(ns)

    if ns.cmd == "onboard":
        return mod_onboard.handle_onboard(ns)

    if ns.cmd == "sandbox":
        return mod_sandbox.handle_sandbox(ns)

    if ns.cmd == "shortcuts":
        return mod_shortcuts.handle_shortcuts(ns)

    if ns.cmd == "checks":
        return mod_checks.handle_checks(ns)

    if ns.cmd == "web":
        return mod_web.handle_web(ns)

    if ns.cmd == "security":
        return mod_security.handle_security(ns, os.getcwd(), provider)

    if ns.cmd == "models":
        return mod_models.handle_models(ns)

    if ns.cmd == "eco":
        return mod_eco.handle_eco(ns)

    if ns.cmd == "blockchain":
        return mod_blockchain.handle_blockchain(ns)

    if ns.cmd == "ar":
        return mod_ar.handle_ar(ns, provider)

    if ns.cmd == "predict":
        return mod_predict.handle_predict(ns)

    if ns.cmd == "ethics":
        return mod_ethics.handle_ethics(ns)

    if ns.cmd == "multi":
        return mod_multi.handle_multi(ns, provider)

    if ns.cmd == "watch":
        return mod_watch.handle_watch(ns)

    if ns.cmd == "memory":
        return mod_memory.handle_memory(ns)

    if ns.cmd == "mcp":
        return mod_mcp.handle_mcp(ns)

    if ns.cmd == "reliability" and ns.rel_cmd == "run":
        from .reliability import run_harness
        root = getattr(ns, "root")
        task = getattr(ns, "task")
        max_steps = int(getattr(ns, "max_steps", 6) or 6)
        apply_changes = bool(getattr(ns, "apply", False))
        run_tests = bool(getattr(ns, "run_tests", True))
        pytest_args = getattr(ns, "pytest_args", None)
        fake = bool(getattr(ns, "fake_provider", False))
        if provider is None and not fake:
            print("Provider required. Pass --provider and --model, or use --fake-provider.")
            return 2
        metrics = run_harness(root, task, provider=provider, max_steps=max_steps, apply_changes=apply_changes, run_tests=run_tests, pytest_args=pytest_args, fake_provider=fake)
        print(metrics.to_json())
        return 0

    return 1

def _add_mcp(sub: argparse._SubParsersAction) -> None:
    mod_mcp.add_mcp_subparser(sub)
