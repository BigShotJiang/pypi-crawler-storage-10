from .core import parse_data

__all__ = ["parse_data"]
__version__ = "0.1.0"
