from bs4 import BeautifulSoup

def parse_data(data, passbook_data, member_id, year):
    soup = BeautifulSoup(data, "html.parser")

    active_tab = soup.select_one("div.v-tab-content.active table.table-pb")
    rows = active_tab.select("tbody tr.va-middle1.color-black")

    passbook_data[member_id][year] = []
    for row in rows:
        cols = row.find_all("td")
        if len(cols) == 9:
            entry = {
                "wage_month": cols[0].get_text(strip=True),
                "transaction_date": cols[1].get_text(strip=True),
                "transaction_type": cols[2].get_text(strip=True),
                "particulars": cols[3].get_text(strip=True),
                "epf_wages": cols[4].get_text(strip=True),
                "eps_wages": cols[5].get_text(strip=True),
                "employee_share": cols[6].get_text(strip=True),
                "employer_share": cols[7].get_text(strip=True),
                "pension_share": cols[8].get_text(strip=True),
            }
            if entry["transaction_type"] == "+":
                passbook_data[member_id][year].append(entry)
    
    return passbook_data

