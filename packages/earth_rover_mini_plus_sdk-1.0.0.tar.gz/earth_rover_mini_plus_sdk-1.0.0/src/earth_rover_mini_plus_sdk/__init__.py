# imports here so users can just write: from earth_rover_mini_plus_sdk import API
from .api import API