import mcp.types as types
import dataclasses
from playwright.async_api import Page

@dataclasses.dataclass
class Property:
    name: str
    typ: str
    description: str
    required: bool = True

class ToolHandler:
    _sessions: dict[str, any] = {}
    _playwright: any = None
    name: str
    description: str
    inputSchema: list[Property]

    async def handle(self, name: str, arguments: dict | None) -> list[types.TextContent | types.ImageContent | types.EmbeddedResource]:
        raise NotImplementedError

    @classmethod
    def to_tool(cls) -> types.Tool:
        return types.Tool(
            name=cls.name,
            description=cls.description,
            inputSchema={
                "type": "object",
                "properties": {
                        property.name: {
                        "type": property.typ,
                        "description": property.description
                    }
                    for property in cls.inputSchema
                },
                "required": [property.name for property in cls.inputSchema if property.required]
            }
        )

    def get_page(self,) -> Page:
        session_id = list(self._sessions.keys())[-1]
        page = self._sessions[session_id]["page"]
        return page
