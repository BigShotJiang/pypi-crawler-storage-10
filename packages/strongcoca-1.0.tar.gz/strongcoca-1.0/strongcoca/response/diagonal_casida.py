import numpy as np
from . import CasidaResponse


def build_diagonal_casida(
        casida_response: CasidaResponse,
        name: str = 'Diagonal') -> CasidaResponse:
    """Builds a :class:`~strongcoca.response.CasidaResponse` instance in
    the diagonal representation from an existing non-diagonal
    representation.

    In the diagonal representation, the K matrix is zero and the
    eigenstates are on the diagonal.

    Parameters
    ----------
    casida_response
        Old Casida response.
    name
        Name of the new response.

    """
    omega_I = casida_response.excitations._energies
    mu_Iv = casida_response.excitations._transition_dipole_moments
    K_II = np.zeros((len(omega_I), len(omega_I)))
    broadening = casida_response.broadening
    return CasidaResponse(omega_I, K_II, mu_Iv, broadening=broadening,
                          units='au', name=name)
