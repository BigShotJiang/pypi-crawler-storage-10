import logging
from abc import ABC, abstractmethod
from typing import Optional

import numpy as np
from ase import Atoms

from .utilities import Broadening
from ..types import Array
from ..units import au_to_eV, eV_to_au, au_to_eA
from ..utilities import ClassFormatter

logger = logging.getLogger(__name__)


class BaseResponse(ABC):

    """Objects of this class hold response function of, e.g., nanoparticles or
    molecules, in several different representations. The latter include, e.g.,
    the polarizability tensor in the real or imaginary frequency domain.

    Parameters
    ----------
    broadening
        Broadening of the response.
    pbc
        True if underlying system is periodic.
    name
        Name of response function.
    """

    def __init__(self,
                 broadening: Broadening,
                 pbc: bool = False,
                 name: str = 'BaseResponse') -> None:
        logger.debug(f'Entering {self.__class__.__name__}.__init__')
        self._broadening = broadening
        self._pbc = pbc
        self._name = name
        self._atoms: Optional[Atoms] = None

    def __str__(self) -> str:
        """String representation."""
        fmt = ClassFormatter(self)
        fmt.append_class_name()

        fmt.append_attr('name')
        fmt.append_attr('pbc')
        fmt.append_attr('atoms')

        return fmt.to_string()

    @property
    def pbc(self) -> bool:
        """True if underlying system is periodic."""
        return self._pbc

    @property
    def broadening(self) -> Broadening:
        """Broadening of the response."""
        return self._broadening

    @property
    def name(self) -> str:
        """Name of response function."""
        return self._name

    @property
    def atoms(self) -> Optional[Atoms]:
        """Atomic structure associated with this response function.
        None if not available."""
        return self._atoms

    def _get_dipole_strength_function(self, frequencies: Array) -> np.ndarray:
        """Returns the dipole strength function.

        Parameters
        ----------
        frequencies
            List of frequencies at which the dipole strength function is calculated;
            in atomic units.

        Returns
        -------
        Dipole strength function at the given frequencies; in atomic units.
        """
        freq_w = np.asarray(frequencies)
        pol_wvv = self._get_dynamic_polarizability(frequencies)
        # Take diagonal
        pol_wv = pol_wvv[(Ellipsis, ) + np.diag_indices(3)]
        osc_wv = 2 / np.pi * freq_w[:, np.newaxis] * pol_wv.imag
        return osc_wv  # type: ignore

    def get_dipole_strength_function(self, frequencies: Array) -> np.ndarray:
        """Returns the dipole strength function.

        Parameters
        ----------
        frequencies
            List of frequencies at which the dipole strength function is calculated;
            in units of eV.

        Returns
        -------
        Dipole strength function at the given frequencies; in units of 1/eV.
        """
        freq_w = np.asarray(frequencies) * eV_to_au
        osc_wv = self._get_dipole_strength_function(freq_w)
        osc_wv = osc_wv / au_to_eV
        return osc_wv

    @abstractmethod
    def _get_dynamic_polarizability(self, frequencies: Array) -> np.ndarray:
        """Returns the dynamic polarizability in the real frequency domain.

        Parameters
        ----------
        frequencies
            List of frequencies at which the polarizability is calculated; in atomic units.

        Returns
        -------
        Dynamical polarizability tensor at the given frequencies; in atomic units.
        """
        raise NotImplementedError()

    def get_dynamic_polarizability(self, frequencies: Array) -> np.ndarray:
        """Returns the dynamic polarizability in the real frequency domain.

        Parameters
        ----------
        frequencies
            List of frequencies at which the polarizability is calculated; in units of eV.

        Returns
        -------
        Dynamical polarizability tensor at the given frequencies; in units of (eÅ)**2/eV.
        """
        freq_w = np.asarray(frequencies) * eV_to_au
        dm_wvv = self._get_dynamic_polarizability(freq_w)
        dm_wvv = dm_wvv * au_to_eA**2 / au_to_eV
        return dm_wvv

    @abstractmethod
    def _get_dynamic_polarizability_imaginary_frequency(
            self, frequencies: Array) -> np.ndarray:
        """Returns the dynamic polarizability in the imaginary frequency domain.

        Parameters
        ----------
        frequencies
            List of frequencies at which the polarizability is calculated; in atomic units.

        Returns
        -------
        Dynamical polarizability tensor at the given imaginary frequencies; in atomic units.
        """
        raise NotImplementedError()

    def get_dynamic_polarizability_imaginary_frequency(
            self, frequencies: Array) -> np.ndarray:
        """Returns the dynamic polarizability in the imaginary frequency domain.

        Parameters
        ----------
        frequencies
            List of frequencies at which the polarizability is calculated; in units of eV.

        Returns
        -------
        Dynamical polarizability tensor at the given imaginary frequencies; in units of (eÅ)**2/eV.
        """
        freq_w = np.asarray(frequencies) * eV_to_au
        dm_wvv = self._get_dynamic_polarizability_imaginary_frequency(freq_w)
        dm_wvv = dm_wvv * au_to_eA**2 / au_to_eV
        return dm_wvv
