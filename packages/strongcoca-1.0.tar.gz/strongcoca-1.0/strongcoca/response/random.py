import numpy as np
from .casida import CasidaResponse
from .utilities import Broadening, NoArtificialBroadening


def build_random_casida(n_states: int,
                        random_seed: int = 42,
                        broadening: Broadening = NoArtificialBroadening(),
                        name: str = 'Random') -> CasidaResponse:
    """Builds Casida response from random numbers.

    This is intended to be used for sandbox applications and testing.

    Parameters
    ----------
    n_states
        Number of states.
    random_seed
        Seed for the random number generator.
    broadening
        Artificial broadening used for the continuous response;
        defaults to no broadening.
    name
        Name of response function.

    Examples
    --------

    The following code snippet shows how to set up a randomized Casida matrix
    with 3 states.

        >>> from strongcoca.response import build_random_casida
        >>> response = build_random_casida(n_states=3, name='Elephant', random_seed=42)
    """
    if n_states < 1:
        raise ValueError('Number of states must be larger than zero')
    np.random.seed(seed=random_seed)
    D_n = np.random.rand(n_states) * n_states + 1
    K_nn = np.random.rand(n_states, n_states)
    K_nn = np.dot(K_nn, K_nn.T)  # make K positive semidefinite
    mu_nv = np.random.rand(n_states, 3)

    response = CasidaResponse(D_n, K_nn, mu_nv, broadening=broadening,
                              name=name, units='eVA')
    return response
