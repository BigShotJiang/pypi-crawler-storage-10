from typing import Any, List, Optional
import numpy as np


ValueAsName = object()


class ClassFormatter:
    """Utility class to simplify writing string representations of generic
    classes

    After initialization add lines to be printed to the buffer
      - :func:`append_class_name()` to buffer the name of the class
      - :func:`append_attr()` to buffer an attribute and its value
      - :func:`append_ndarray()` to buffer an attribute that is a numpy array

    Print the contents of the buffer using to_string()

    Parameters
    ----------
    cls
        Instance of the class to be formatted.
    width
        Maximum line width.
    pad
        Pad the column with attribute names with spaces until it is this wide.
    precision
        Value passed to :attr:`np.printoptions`.
    threshold
        Value passed to :attr:`np.printoptions`.

    Examples
    --------

    The following snippet illustrates how to write a string representation of
    dummy class DummyResponse:

        >>> import numpy as np
        >>> from strongcoca.utilities import ClassFormatter
        >>>
        >>> class DummyResponse():
        ...     def __init__(self, name, E_field):
        ...         self.name = name
        ...         self.E_field = E_field
        ...
        ...     def __str__(self):
        ...         fmt = ClassFormatter(self)
        ...         fmt.append_class_name()
        ...
        ...         fmt.append_attr('name')
        ...         fmt.append_attr('E_field', self.E_field, unit='V/Å')
        ...
        ...         return fmt.to_string()
        >>>
        >>> response = DummyResponse('Constant field', np.array([0.1, 0.0, 0.0]))
        >>> print(response)
        ---------------------- DummyResponse -----------------------
        name              : Constant field
        E_field (V/Å)     : [0.1 0.  0. ]
    """

    def __init__(self,
                 cls: object,
                 width: int = 60,
                 pad: int = 18,
                 precision: int = 5,
                 threshold: int = 10):
        self.cls = cls
        self.width = width
        self.pad = pad
        self.precision = precision
        self.threshold = threshold

        self.lines: List[str] = []

    def append_class_name(self) -> None:
        """Append the name of the class of `cls` to the print buffer.

        The print format is such that the class name is centered in a bar of width `width`.
        """
        line = ' {} '.format(self.cls.__class__.__name__).center(self.width, '-')
        self.lines.append(line)

    def append_attr(self,
                    name: str,
                    value: Any = ValueAsName,
                    unit: Optional[str] = None) -> None:
        """Append attribute name, value and optinally unit to print buffer.

        The print format is `name` or `name (unit)` in the left column of width `pad`,
        and `value` in the right column.

        Parameters
        ----------
        name
            Attribute name.
        value
            Value to print; if `None` the value of the attribute `name` of class `cls`
            is used.
        unit
            Optional unit of attribute; if not `None` it is printed in paranthesis after
            the attribute name.

            This parameter is used solely for formatting, and does not perform unit conversions
            of the value.
        """
        if value is ValueAsName:
            value = getattr(self.cls, name)

        if unit is not None:
            name = f'{name} ({unit})'

        if isinstance(value, np.ndarray):
            self.append_ndarray(name, value)
            return
        line = f'{name:<{self.pad}}: {value}'
        self.lines.append(line)

    def append_ndarray(self,
                       name: str,
                       arr: np.ndarray,
                       suffix: str = '') -> None:
        """Append attribute name and value to print buffer.

        The print format is `name` in the left column of width `pad`, and `value`
        in the right column. `value` must be a numpy array.

        Parameters
        ----------
        name
            Attribute name.
        value
            Value to print; if `None` the value of the attribute `name` of class `cls`
            is used.
        """
        prefix = f'{name:<{self.pad}}: '
        indent = len(prefix)

        if arr is ValueAsName:
            arr = getattr(self.cls, name)
        lines = format_ndarray(arr, width=self.width, prefix=prefix,
                               indent=indent, suffix=suffix,
                               precision=self.precision, threshold=self.threshold).split('\n')
        self.lines += lines

    def to_string(self) -> str:
        """Dumps the print buffer as a string."""
        return '\n'.join(self.lines)


def format_ndarray(arr: np.ndarray,
                   width: int = 60,
                   indent: int = 0,
                   prefix: str = '',
                   suffix: str = '',
                   **np_printoptions: Any) -> str:
    """Formats numpy array taking into account an indent, prefix and suffix.

    Parameters
    ----------
    arr
        Array to format.
    width
        Maximum width of any line.
    indent
        Pad the beginning of each line with this number of spaces.
    prefix
        Prepend this string at the begining of the first line; typically one would
        write the array name followed by a colon.
        The length of this string must be at most indent.
    suffix
        Append this string at the end of the last line; for example this could
        be a unit.
    **np_printoptions
        Options passed to np.printoptions.

        If linewidth is not one of these options it is automatically calculated
        from the indent, width and length of the suffix.

    Returns
    -------
    Formatted array.

    Raises
    ------
    ValueError
        If the lengths mismatch.

    Examples
    --------
        >>> from numpy.random import seed, rand
        >>> from strongcoca.utilities import format_ndarray
        >>>
        >>> seed(42)
        >>> arr = rand(3)
        >>> prefix = 'my_array: '
        >>> s = format_ndarray(arr, prefix=prefix, indent=len(prefix),
        ...                    precision=5, threshold=10)
        >>> print(s)
        my_array: [0.37454 0.95071 0.73199]

        >>> arr = rand(3,3)
        >>> prefix = 'matrix '
        >>> s = format_ndarray(arr, width=50, prefix=prefix, indent=16,
        ...                    precision=5, threshold=10)
        >>> print(s)
        matrix          [[0.59866 0.15602 0.15599]
                         [0.05808 0.86618 0.60112]
                         [0.70807 0.02058 0.96991]]

        >>> arr = rand(15,7)
        >>> prefix = 'D    : '
        >>> s = format_ndarray(arr, width=50, prefix=prefix, indent=len(prefix), suffix=' eV',
        ...                    precision=5, threshold=10)
        >>> print(s)
        D    : [[0.83244 0.21234 0.18182 ... 0.30424
                 0.52476 0.43195]
                [0.29123 0.61185 0.13949 ... 0.36636
                 0.45607 0.78518]
                [0.19967 0.51423 0.59241 ... 0.60754
                 0.17052 0.06505]
                ...
                [0.52273 0.42754 0.02542 ... 0.03143
                 0.63641 0.31436]
                [0.50857 0.90757 0.24929 ... 0.75555
                 0.2288  0.07698]
                [0.28975 0.16122 0.9297  ... 0.6334
                 0.87146 0.80367]] eV
    """

    if len(prefix) > indent:
        raise ValueError(f'The prefix cannot be longer than the indent. '
                         f'Prefix is {prefix} and indent {indent}.')

    linewidth = np_printoptions.get('linewidth', None)
    if linewidth is None:
        linewidth = width - indent - len(suffix)
        if linewidth <= 0:
            raise ValueError(f'When computing the linewidth, the sum of the indent '
                             f'and suffix length must be less than width.\n'
                             f'Current values are {indent}+{len(suffix)}'
                             f'>={width}')
        np_printoptions['linewidth'] = linewidth

    if indent + linewidth + len(suffix) > width:
        raise ValueError(f'The sum of the indent, linewidth, and suffix length '
                         f'must at most be width.\n'
                         f'Current values are {indent}+{linewidth}+{len(suffix)}'
                         f'>{width}')

    with np.printoptions(**np_printoptions):
        np_lines = str(arr).split('\n')

    # First line
    out_lines = [f'{prefix:<{indent}s}{np_lines[0]}']

    # Remaining lines
    out_lines += [f'{"":<{indent}}{line}' for line in np_lines[1:]]

    # Append suffix to last line
    out_lines[-1] += suffix

    return '\n'.join(out_lines)
