from pathlib import Path
from typing import Sequence, Union
import numpy as np

Vector = Union[np.ndarray, Sequence[float]]
Matrix = Union[np.ndarray, Sequence[Vector]]
Array = Union[np.ndarray, Sequence[float]]
ComplexArray = Union[np.ndarray, Sequence[complex]]
Path_str = Union[Path, str]
