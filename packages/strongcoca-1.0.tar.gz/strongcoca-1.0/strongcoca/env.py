from os import getenv


def strongcoca_getenv(variable) -> str:
    """ Get value of environment variable, or default.

    Possible environment variables are:

    - `STRONGCOCA_MAX_SOLVE_MEM` - Value in units of MiB. In the linear solve operation for the
      PolarizabilityCalculator, try to limit memory of intermediate matrices below this value.

    Parameters
    ----------
    variable
        Name of variable, without the ``'STRONGCOCA'`` prefix.

    Returns
    -------
    Value of variable as string.
    """

    defaults = {'MAX_SOLVE_MEM': '80',
                }

    if variable not in defaults.keys():
        allowed = '\n'.join([f'  STRONGCOCA_{var}' for var in defaults.keys()])
        raise ValueError(f'Environment variable STRONGCOCA_{variable} is unknown. '
                         f'Allowed variables are:\n{allowed}')

    return getenv(f'STRONGCOCA_{variable}', defaults[variable])


def get_float(variable) -> float:
    strvalue = strongcoca_getenv(variable)
    try:
        value = float(strvalue)
    except ValueError:
        raise ValueError(f'Expected environment variable STRONGCOCA_{variable} to '
                         f'be castable to float. Value is {strvalue!r}.')

    return value
