from abc import abstractmethod
from typing import Optional
import numpy as np
from .. import CoupledSystem
from ..response.base import BaseResponse
from ..response.utilities import Broadening
from ..units import au_to_eV


class BaseCalculator(BaseResponse):

    """Children of this class enable the calculation of correlation energy and
    spectrum of a coupled system.

    Parameters
    ----------
    coupled_system
        Coupled system for which to carry out calculations.
    broadening
        Broadening used.
    name
        Name of calculator.
    """

    def __init__(self,
                 coupled_system: CoupledSystem,
                 broadening: Broadening,
                 name: str = 'BaseCalculator') -> None:
        super().__init__(broadening=broadening, pbc=False, name=name)
        if not isinstance(coupled_system, CoupledSystem):
            raise TypeError(
                f'coupled_system must be of type CoupledSystem is {type(coupled_system)}.')
        self._coupled_system = coupled_system
        self._update_state()
        self._correlation_energy: Optional[float] = None

    def _update_state(self) -> None:
        """Update the internal variables that are used for determining whether
        the object 'is dirty'. This method is used internally to determine
        whether previous calculation results have become invalid.
        """
        self._positions = self._coupled_system.positions.copy()
        self._orientations = [pu.orientation for pu in self._coupled_system]
        self._responses = [pu.response for pu in self._coupled_system]

    def _verify_state(self) -> None:
        """Update state and discard previous calculation data if the object
        'is dirty'. Otherwise do nothing.
        """
        if not self.is_dirty():
            return
        self._update_state()
        self._discard_data()

    def _discard_data(self) -> None:
        """Discard all the data that becomes invalid when the system gets dirty."""
        self._correlation_energy = None

    @property
    def coupled_system(self) -> CoupledSystem:
        """Coupled system for which calculations are carried out."""
        return self._coupled_system

    def is_dirty(self) -> bool:
        """Returns True if the state of the underlying coupled system has
        changed since the last calculation.
        """
        if not np.allclose(self._positions, self._coupled_system.positions):  # type: ignore
            return True
        if any(not np.allclose(pu.orientation.as_quat(), o.as_quat())
               for pu, o in zip(self._coupled_system, self._orientations)):
            return True
        if not np.all([pu.response == rf
                       for pu, rf in zip(self._coupled_system, self._responses)]):
            return True
        return False

    def get_correlation_energy(self):
        """Return the correlation energy of the coupled system in units of eV."""
        return self._get_correlation_energy() * au_to_eV

    def _get_correlation_energy(self) -> float:
        """Return the correlation energy of the coupled system in atomic units."""
        self._verify_state()
        if self._correlation_energy is None:
            self._correlation_energy = float(self._calculate_correlation_energy())
        return self._correlation_energy

    @abstractmethod
    def _calculate_correlation_energy(self) -> float:
        raise NotImplementedError()
