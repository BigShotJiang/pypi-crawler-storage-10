import numpy as np


def get_dipole_dipole_tensor(distance_vector: np.ndarray) -> np.ndarray:
    r"""Returns the dipole-dipole tensor. The dipole-dipole tensor is defined as

    .. math:

        T_{i\mu j\nu} = \nabla_\mu \nabla_\nu \frac{1}{|\vec{R_{ij}}|}
        = \frac{\delta_{\mu\nu}}{|\vec{R_{ij}}|^3}
        - 3 \frac{R_{ij,\mu} R_{ij,\nu}}{|\vec{R_{ij}}|^5}

    Parameters
    ----------
    distance_vector
        Distance vector between the two subsystems.

    Example
    -------

    .. doctest:

        >>> get_dipole_dipole_tensor(np.array([1, 2, 3]))
        array([[ 0.01499936, -0.00818147, -0.0122722 ],
               [-0.00818147,  0.00272716, -0.0245444 ],
               [-0.0122722 , -0.0245444 , -0.01772651]])

    """
    assert distance_vector.shape == (3,), \
        f'distance_vector has the wrong shape ({distance_vector})'
    r = np.linalg.norm(distance_vector)
    T = np.eye(3) / r ** 3 - 3 * np.outer(distance_vector, distance_vector) / r ** 5
    return T  # type: ignore
