# This module contains components adapted from GPAW:
# gpaw.tddft.units
# https://gitlab.com/gpaw/gpaw/-/blob/aca9ed6f520d6a855013247119b50c630f5eebc9/gpaw/tddft/units.py
import numpy as np

from ase.units import Hartree, Bohr, _hbar, _eps0, _me, _e


# Conversion factors between atomic units and eV/as
_autime: float = _hbar**3 * (4 * np.pi * _eps0)**2 / (_me * _e**4)

au_to_as: float = _autime / 1e-18
as_to_au: float = 1 / au_to_as
au_to_fs: float = _autime / 1e-15
fs_to_au: float = 1 / au_to_fs

au_to_eV: float = Hartree
eV_to_au: float = 1 / au_to_eV

au_to_A: float = Bohr
A_to_au: float = 1 / au_to_A

au_to_eA: float = Bohr * 1
eA_to_au: float = 1 / au_to_eA

# force
au_to_eVA: float = Hartree / Bohr
eVA_to_au: float = 1 / au_to_eVA
