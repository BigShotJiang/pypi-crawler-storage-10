StrongCoCa
**********

**StrongCoca** is being developed as a sustainable, extensible,
flexible and computationally efficient package for simulating
coarse-grained many-body interactions in nano and mesoscale systems.
A detailed description of the functionality provided as well as tutorials can be found in the `user guide <https://strongcoca.materialsmodeling.org/>`_.

**StrongCoca** can be installed via `pip`::

    pip3 install strongcoca

[to be completed]


Development
-----------

The test suite is run using `pytest`::

  pytest tests/
