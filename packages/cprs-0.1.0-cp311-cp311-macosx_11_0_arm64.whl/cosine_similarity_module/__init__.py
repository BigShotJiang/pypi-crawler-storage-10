from .cosine_similarity_module import *

__doc__ = cosine_similarity_module.__doc__
if hasattr(cosine_similarity_module, "__all__"):
    __all__ = cosine_similarity_module.__all__