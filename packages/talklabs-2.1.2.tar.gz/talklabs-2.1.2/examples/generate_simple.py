#!/usr/bin/env python3
"""
Exemplo: Geração Simples (Síncrona)
Demonstra o uso básico do método generate() para síntese de voz.
"""
from talklabs import TalkLabsClient

def exemplo_geracao_simples():
    """
    Exemplo básico de geração de áudio com o método generate().

    Este método é síncrono e retorna o áudio completo de uma vez.
    Ideal para textos curtos e quando não há necessidade de streaming.
    """
    # Inicializar o cliente com sua chave API
    client = TalkLabsClient(api_key="tlk_live_xxxxx")  # Substitua pela sua chave

    # Texto para sintetizar
    text = "Olá! Bem-vindo ao TalkLabs. Este é um exemplo de síntese de voz."

    # Voz a ser utilizada (veja get_voices.py para listar todas)
    voice = "yasmin_alves"  # Voz feminina em português brasileiro

    # Gerar o áudio
    audio_bytes = client.generate(
        text=text,
        voice=voice,
        language="pt",  # Idioma: português
        speed=1.0       # Velocidade normal (0.5 a 2.0)
    )

    # Salvar o áudio em arquivo
    output_file = "output.wav"
    with open(output_file, "wb") as f:
        f.write(audio_bytes)

    print(f"✅ Áudio salvo em: {output_file}")
    print(f"📊 Tamanho: {len(audio_bytes):,} bytes")

if __name__ == "__main__":
    exemplo_geracao_simples()