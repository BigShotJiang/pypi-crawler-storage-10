#!/usr/bin/env python3
"""
Exemplo: Streaming HTTP
Demonstra o uso do método generate_stream() para receber áudio em chunks via HTTP.
"""
from talklabs import TalkLabsClient

def exemplo_streaming_http():
    """
    Exemplo de streaming HTTP com o método generate_stream().

    Este método retorna o áudio em chunks progressivamente via HTTP.
    Útil quando você quer começar a processar o áudio antes de ter o arquivo completo.
    """
    # Inicializar o cliente com sua chave API
    client = TalkLabsClient(api_key="tlk_live_xxxxx")  # Substitua pela sua chave

    # Texto para sintetizar
    text = """
    Este é um exemplo de streaming HTTP. O áudio é recebido em chunks,
    permitindo que você comece a reproduzir ou processar o áudio
    antes mesmo da síntese estar completa.
    """

    # Voz a ser utilizada
    voice = "adam_rocha"  # Voz masculina em português brasileiro

    # Coletar chunks durante o streaming
    chunks_received = []

    # Receber áudio em chunks via streaming HTTP
    for chunk in client.generate_stream(
        text=text,
        voice=voice,
        language="pt",
        speed=1.0
    ):
        chunks_received.append(chunk)
        # Aqui você poderia processar cada chunk conforme recebe
        # Por exemplo, enviar para um player de áudio ou buffer

    # Juntar todos os chunks
    full_audio = b"".join(chunks_received)

    # Salvar o áudio completo
    output_file = "output_stream.wav"
    with open(output_file, "wb") as f:
        f.write(full_audio)

    print(f"✅ Áudio salvo em: {output_file}")
    print(f"📊 Total de chunks: {len(chunks_received)}")
    print(f"📊 Tamanho total: {len(full_audio):,} bytes")

if __name__ == "__main__":
    exemplo_streaming_http()