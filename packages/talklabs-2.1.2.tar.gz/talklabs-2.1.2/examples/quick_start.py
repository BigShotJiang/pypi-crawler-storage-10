#!/usr/bin/env python3
"""
Exemplo: Quick Start - Teste Rápido
Script simples para testar rapidamente a conexão e síntese de voz.
"""
import asyncio
from talklabs import TalkLabsClient

async def teste_rapido():
    """
    Teste rápido para verificar se tudo está funcionando.
    Este é o exemplo mais simples para começar.
    """
    print("🚀 TalkLabs SDK - Teste Rápido\n")
    print("🔌 Conectando ao TalkLabs...")

    # Inicializar o cliente com sua chave API
    client = TalkLabsClient(api_key="tlk_live_xxxxx")  # Substitua pela sua chave

    # Criar uma sessão persistente para melhor performance
    session = await client.create_session(
        voice="yasmin_alves",  # Voz feminina em português
        language="pt",
        speed=1.0
    )

    print("✅ Conectado! Iniciando síntese...\n")

    # Textos de exemplo
    textos = [
        "Olá! Bem-vindo ao TalkLabs.",
        "Esta é uma demonstração de síntese de voz.",
        "A qualidade e velocidade são impressionantes!"
    ]

    for i, texto in enumerate(textos, 1):
        print(f"[{i}/{len(textos)}] Sintetizando: {texto}")

        # Coletar chunks de áudio
        chunks = []
        async for chunk in session.stream_text(texto):
            chunks.append(chunk)

        # Juntar e salvar o áudio
        audio_completo = b"".join(chunks)
        filename = f"quick_test_{i}.wav"

        with open(filename, "wb") as f:
            f.write(audio_completo)

        print(f"✅ Salvo: {filename} ({len(audio_completo):,} bytes)\n")

    # Fechar a sessão
    await session.close()

    print("🎉 Teste concluído com sucesso!")
    print("\n🎵 Para ouvir os áudios gerados:")
    print("   - No Linux/Mac: aplay quick_test_1.wav")
    print("   - No Windows: start quick_test_1.wav")
    print("   - Ou abra os arquivos .wav no seu player favorito")

def teste_simples_sincrono():
    """
    Exemplo ainda mais simples usando o método síncrono.
    Não requer async/await.
    """
    print("🚀 TalkLabs SDK - Teste Simples (Síncrono)\n")

    # Inicializar o cliente
    client = TalkLabsClient(api_key="tlk_live_xxxxx")  # Substitua pela sua chave

    # Gerar áudio de forma síncrona
    texto = "Este é o método mais simples para gerar áudio com TalkLabs."
    print(f"Gerando áudio para: {texto}")

    audio = client.generate(
        text=texto,
        voice="adam_rocha",  # Voz masculina em português
        language="pt"
    )

    # Salvar o áudio
    with open("teste_simples.wav", "wb") as f:
        f.write(audio)

    print("✅ Áudio salvo em: teste_simples.wav")
    print(f"📊 Tamanho: {len(audio):,} bytes")

if __name__ == "__main__":
    import sys

    print("=" * 60)
    print("TalkLabs SDK - Exemplos de Teste Rápido")
    print("=" * 60)
    print("\nEscolha o tipo de teste:")
    print("1. Teste assíncrono com sessão persistente (recomendado)")
    print("2. Teste síncrono simples")
    print()

    escolha = input("Digite 1 ou 2 (padrão: 1): ").strip() or "1"

    if escolha == "2":
        print("\n" + "=" * 60)
        teste_simples_sincrono()
    else:
        print("\n" + "=" * 60)
        asyncio.run(teste_rapido())