#!/usr/bin/env python3
"""
Exemplo: Streaming WebSocket
Demonstra o uso do método stream_text() para streaming via WebSocket com ultra-baixa latência.
"""
import asyncio
from talklabs import TalkLabsClient

async def exemplo_streaming_websocket():
    """
    Exemplo de streaming via WebSocket com o método stream_text().

    Este método oferece a menor latência possível (~200-500ms),
    ideal para aplicações em tempo real como chatbots e assistentes virtuais.
    """
    # Inicializar o cliente com sua chave API
    client = TalkLabsClient(api_key="tlk_live_xxxxx")  # Substitua pela sua chave

    # Texto para sintetizar
    text = """
    Este é um exemplo de streaming via WebSocket.
    A latência é ultra-baixa, permitindo que você ouça
    o áudio quase instantaneamente após o processamento.
    """

    # Voz a ser utilizada
    voice = "yasmin_alves"

    # Coletar chunks durante o streaming
    chunks_received = []
    first_chunk_time = None

    print("🔌 Conectando via WebSocket...")
    print(f"📝 Texto: {text[:50]}...")
    print(f"🎙️ Voz: {voice}\n")

    # Receber áudio em chunks via WebSocket
    async for chunk in client.stream_text(
        text=text,
        voice=voice,
        language="pt",
        speed=1.0
    ):
        if not first_chunk_time:
            print(f"⚡ Primeiro chunk recebido! (latência ultra-baixa)")
            first_chunk_time = True

        chunks_received.append(chunk)
        # Aqui você poderia enviar cada chunk diretamente para um player de áudio
        # para reprodução em tempo real

    # Juntar todos os chunks
    full_audio = b"".join(chunks_received)

    # Salvar o áudio completo
    output_file = "output_websocket.wav"
    with open(output_file, "wb") as f:
        f.write(full_audio)

    print(f"\n✅ Streaming completo!")
    print(f"📊 Total de chunks: {len(chunks_received)}")
    print(f"📊 Tamanho total: {len(full_audio):,} bytes")
    print(f"💾 Áudio salvo em: {output_file}")

async def exemplo_multiplas_sinteses():
    """
    Exemplo de múltiplas sínteses sequenciais via WebSocket.
    Cada síntese cria uma nova conexão (modo one-shot).
    """
    client = TalkLabsClient(api_key="tlk_live_xxxxx")  # Substitua pela sua chave

    # Lista de textos para sintetizar
    textos = [
        "Primeira mensagem do assistente virtual.",
        "Segunda resposta com informações adicionais.",
        "Terceira mensagem finalizando o atendimento."
    ]

    voice = "adam_rocha"

    for i, text in enumerate(textos, 1):
        print(f"\n[{i}/{len(textos)}] Sintetizando: {text}")

        chunks = []
        async for chunk in client.stream_text(
            text=text,
            voice=voice,
            language="pt"
        ):
            chunks.append(chunk)

        # Salvar cada áudio
        audio = b"".join(chunks)
        filename = f"output_{i}.wav"
        with open(filename, "wb") as f:
            f.write(audio)

        print(f"[{i}/{len(textos)}] ✅ Salvo em: {filename}")

if __name__ == "__main__":
    print("=" * 60)
    print("EXEMPLO: Streaming via WebSocket")
    print("=" * 60)

    # Executar exemplo de streaming único
    asyncio.run(exemplo_streaming_websocket())

    print("\n" + "=" * 60)
    print("EXEMPLO: Múltiplas Sínteses")
    print("=" * 60)

    # Executar exemplo de múltiplas sínteses
    asyncio.run(exemplo_multiplas_sinteses())