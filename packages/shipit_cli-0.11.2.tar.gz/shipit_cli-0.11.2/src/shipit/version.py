__all__ = ["version", "version_info"]


version = "0.11.2"
version_info = (0, 11, 2, "final", 0)
