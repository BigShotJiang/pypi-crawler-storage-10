
my_dpi = 300
