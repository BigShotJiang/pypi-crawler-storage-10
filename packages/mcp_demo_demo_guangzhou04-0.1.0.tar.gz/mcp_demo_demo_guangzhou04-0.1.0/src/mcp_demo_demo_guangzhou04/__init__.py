# 导入mcp的包
from mcp.server.fastmcp import FastMCP

# 创建一个FastMCP对象
mcp = FastMCP("guangzhou04")


# 注册一个加法工具
# 注意三点：1、添加工具的装饰器，2、函数一定要写注释。3、函数的参数的类型最好也写上。
@mcp.tool()
def add(a: int, b: int) -> int:
    """计算两个数的和"""
    return a + b


# 注册一个乘法工具
@mcp.tool()
def mul(a: int, b: int) -> int:
    """计算两个数的积"""
    return a * b


def main() -> None:
    mcp.run("stdio")
