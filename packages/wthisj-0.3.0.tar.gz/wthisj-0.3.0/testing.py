import wthisj
shear_section = wthisj.PunchingShearSection(col_width=24, 
                                            col_depth=24, 
                                            slab_avg_depth=12, 
                                            condition="W",
                                           	studrail_length = 48)
results = shear_section.solve(Vz = -100, Mx = 0, My = 400, 
                              gamma_vx = "auto", 
                              gamma_vy = 0.4,
                              consider_ecc=True)
fig = shear_section.plot_results()