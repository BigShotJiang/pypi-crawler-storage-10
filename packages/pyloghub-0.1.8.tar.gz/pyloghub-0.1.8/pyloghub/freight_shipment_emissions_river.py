import os
import pandas as pd
import logging
from typing import Optional
import warnings
logging.basicConfig(level=logging.INFO)
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'pyloghub')))
from save_to_platform import save_scenario_check, create_button
from input_data_validation import convert_dates, validate_and_convert_data_types, convert_to_float, convert_df_to_dict_excluding_nan
from sending_requests import post_method, create_headers, create_url, get_workspace_entities

def reverse_freight_shipment_emissions_river(coordinates: pd.DataFrame, parameters: dict, api_key: str, save_scenario = {}, show_buttons = False) -> Optional[pd.DataFrame]:
    """
    Perform reverse freight emissions by inland waterway on a list of from and to locations coordinates.

    This function takes a DataFrame of from and to locations coordinates and an API key, and performs reverse
    freight emissions by inland waterways using the Log-hub service. 

    Parameters:
    coordinates (pd.DataFrame): A pandas DataFrame containing the coordinates for calculating a CO2 footprint based on your shipments or route legs defined as separate shipments.
        Required columns and their types:
        - shipmentId (str): Unique identifier for each shipment.
        - shipmentDate (str): Dates related to the shipment (Format: YYYY-MM-DD)
        - fromLatitude (number): The latitude of the coordinate from which a shipment should be sent.
        - fromLongitude(number): The longitude of the coordinate from which a shipment should be sent.
        - toLatitude (number): The latitude of the coordinate to which a shipment should arrive at.
        - toLongitude (numebr): The longitude of the coordinate to which a shipment should arrive at.
        - isRefrigirated (str): A YES/NO option that specifies whether the content being transferred through the shipments is refrigirated or not. If not specified will be taken as NO.
        - distance: Distance between sender and recipient. It will be calculated if not provided
        - weight (number): The weight of the shipment.

    parameters (dict): A dictionary containing parameters:
        - shipType: enum 'motorVessels(0-50)', 'motorVessels(50-80)', 'motorVessels(80-110)', 'motorVessels(135)', 'coupledConvoys', 'pushedConvoy2Barges', 'pushedConvoy4/5Barges', 'pushedConvoy6Barges', 'tankerVessels', 'containerVessels(110)', 'containerVessels(135)', 'containerVesselsCoupledConvoys'
        - weightUnit: enum "kilograms" or "LBS" or "TEU"
        - refrigerantFactor: a number between 0 and 100

    api_key (str): The Log-hub API key for accessing the freight emissions service.

    save_scenario (dict): A dictionary containg information about saving scenario, empty by default. Allowed key vales are
                            'saveScenario' (boolean), 'overwriteScenario' (boolean), 'workspaceId' (str) and
                            'scenarioName' (str).
    
    show_buttons (boolean): If this parameter is set to True and the scenario is saved on the platform, the buttons linking to the output results, map, dashboard and the input table 
                           will be created. If the scenario is not saved, a proper message will be shown.

    Returns:
    Optional[pd.DataFrame]: A pandas DataFrame contains the original shipment information along 
                  with the calculated CO2 emissions. Returns None if the process fails.
    """
    def create_buttons():
        links = get_workspace_entities(save_scenario, api_key)
        create_button(links = [links['map'], links['dashboard'], links['inputDataset'], links['outputDataset']], texts = ["🌍 Open Map", "📊 Open Dashboard", "📋 Show Input Dataset", "📋 Show Output Dataset"])
    
    coordinates_columns = {'shipmentId': 'str', 'shipmentDate': 'str', 'fromLatitude': 'float', 'fromLongitude': 'float', 'toLatitude': 'float', 'toLongitude': 'float', 'weight': 'float'}
    coordinates_optional_columns = {'isRefrigirated': 'str'}
    coordinates_optional_floats = ['distance']

    # Validate and convert data types
    coordinates = validate_and_convert_data_types(coordinates, coordinates_columns, 'mandatory', 'un locodes')
    if not coordinates is None:
        coordinates = validate_and_convert_data_types(coordinates, coordinates_optional_columns, 'optional', 'un locodes')
        if not coordinates is None:
            coordinates = convert_dates(coordinates, ['shipmentDate'])
            coordinates = convert_to_float(coordinates, coordinates_optional_floats, 'optional')
            coordinates = convert_df_to_dict_excluding_nan(coordinates, coordinates_optional_floats)
    if coordinates is None:
        return None
    
    url = create_url("reverseco2emissionsriver")
    
    headers = create_headers(api_key)

    payload = {
        'freightShipmentEmissionsByReverseRiver': coordinates,
        'parameters': parameters
    }
    payload = save_scenario_check(save_scenario, payload)

    response_data = post_method(url, payload, headers, "reverse co2 emissions river")
    if response_data is None:
        return None
    else:
        freight_emissions_df = pd.DataFrame(response_data['freightShipmentEmissionOutputReverseRiver'])
        if (show_buttons and payload['saveScenarioParameters']['saveScenario']):
            create_buttons()
        if (not payload['saveScenarioParameters']['saveScenario'] and show_buttons):
            logging.info("Please, save the scenario in order to create the buttons for opening the results on the platform.")
        return freight_emissions_df

def reverse_freight_shipment_emissions_river_sample_data():
    warnings.simplefilter("ignore", category=UserWarning)
    data_path = os.path.join(os.path.dirname(__file__), 'sample_data', 'CO2RiverReverse.xlsx')
    coordinates_df = pd.read_excel(data_path, sheet_name='river', usecols='A:J').fillna("")
    parameters = {
        "shipType": "motorVessels(0-50)",
        "weightUnit": "kilograms",
        "refrigerantFactor": 12
    }
    save_scenario = {
        'saveScenario': False,
        'overwriteScenario': False,
        'workspaceId': 'Your workspace id',
        'scenarioName': 'Your scenario name'
    }
    return {'coordinates': coordinates_df, 'parameters': parameters, 'saveScenarioParameters': save_scenario} 