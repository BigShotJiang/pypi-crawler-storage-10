
# THIS FILE IS GENERATED FROM OASYS SETUP.PY
short_version = '1.0.24'
version = '1.0.24'
full_version = '1.0.24.dev0+9cc6324'
git_revision = '9cc63249bab727fd266cb1e68585adaa42faf9a1'
release = False

if not release:
    version = full_version
    short_version += ".dev"
