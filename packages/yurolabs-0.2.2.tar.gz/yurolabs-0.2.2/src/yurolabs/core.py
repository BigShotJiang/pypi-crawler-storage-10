"""
Core entrypoint that exposes the YuroClient for backwards compatibility.
"""

from .client import YuroClient
from .exceptions import (
    YuroHTTPError,
    YuroConfigError,
)

__all__ = [
    "YuroClient",
    "YuroHTTPError",
    "YuroConfigError",
]
