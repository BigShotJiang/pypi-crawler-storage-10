# pylint: skip-file
from operator import itemgetter
from typing import Any, Optional

from mysql_api.mysql_database import MySQLDatabase

from passive_server import models_class


def get_address_with_description(mysql: MySQLDatabase, description: str) -> Optional[dict[str, Any]]:
    """获取 MES 心跳地址信息.

    Args:
        mysql: 数据库实例.
        description:

    Returns:
       Optional[dict[str, Any]]: 返回 MES 心跳地址信息.
    """
    address_info_list = mysql.query_data(models_class.AddressList, {"description": description})
    if address_info_list:
        plc_type = mysql.query_data(models_class.EcList, {"ec_name": "plc_type"})[0]["value"]
        address_info = address_info_list[0]
        return get_address_info(plc_type, address_info)
    return None


def get_signal_address_list(mysql: MySQLDatabase) -> list[dict]:
    """获取所有的信号地址.

    Args:
        mysql: 数据库实例.

    Returns:
        list[dict]: 返回所有的信号地址.
    """
    address_info_list = mysql.query_data(models_class.SignalAddressList)
    return address_info_list


def get_signal_address_info(mysql: MySQLDatabase, plc_type: str, address: str) -> Optional[dict[str, Any]]:
    """获取信号地址信息.

    Args:
        mysql: 数据库实例.
        plc_type: plc 类型.
        address: 地址.

    Returns:
        Optional[dict[str, Any]]: 返回信号地址信息.
    """
    address_info_list = mysql.query_data(models_class.SignalAddressList, {"address": address})
    if address_info_list:
        address_info = address_info_list[0]
        return get_address_info(plc_type, address_info)
    return None


def get_signal_callbacks(mysql: MySQLDatabase, address: str) -> list:
    """获取信号的流程信息.

    Args:
        mysql: 数据库实例.
        address: 信号地址.

    Returns:
        list: 返回排序后的 call back 列表.
    """
    models_class_flow_func = models_class.FlowFunc
    filter_dict = {"associate_signal": address}
    callbacks_plc = mysql.query_data(models_class.PlcAddressList, filter_dict)
    callbacks_mes = mysql.query_data(models_class.MesAddressList, filter_dict)
    callbacks_flow_func = mysql.query_data(models_class_flow_func, filter_dict)
    callbacks = callbacks_plc + callbacks_mes + callbacks_flow_func
    callbacks_return = sorted(callbacks, key=itemgetter("step"))
    return callbacks_return


def get_address_info(plc_type: str, address_info: dict) -> dict[str, Any]:
    """根据数据库查询的地址信息获取整理后的地址信息.

    Args:
        plc_type: plc 类型.
        address_info: 数据库获取的地址信息

    Returns:
        dict[str, Any]: 整理后的地址信息.
    """
    if "tag" in plc_type:
        address_info_expect = {"address": address_info["address"], "data_type": address_info["data_type"]}
    elif "snap7" in plc_type:
        address_info_expect = {
            "address": address_info["address"], "data_type": address_info["data_type"],
            "size": address_info.get("size", 2), "db_num": address_info.get("db_num", 1998),
            "bit_index": address_info.get("bit_index", 0)
        }
    elif "mitsubishi" in plc_type:
        address_info_expect = {
            "address": address_info["address"], "data_type": address_info["data_type"],
            "size": address_info["size"]
        }
    elif "modbus" in plc_type:
        address_info_expect = {
            "address": address_info["address"], "data_type": address_info["data_type"],
            "size": address_info["size"], "bit_index": address_info["bit_index"]
        }
    else:
        address_info_expect = {}
    return address_info_expect
