# pylint: skip-file
"""Host 主机, 用来监控设备端 secs服务发上来的数据, 然后处理后再发给工厂."""
import logging
import threading
from typing import Callable

from secsgem.secs import functions
from secsgem import hsms, gem

from passive_server.common_func import get_secs_param_value


class ActiveHost:
    """ActiveHost class."""

    def __init__(self, passive_ips: list[str]):
        """ActiveHost 构造函数.

        Args:
            passive_ips: 要监控设备 secs 服务的 ip 和 端口列表.
        """
        self.logger = logging.getLogger("ActiveHost")
        self.passive_ips = passive_ips
        self._host_handlers = {}
        self._create_gem_host_handler()

    @property
    def host_handlers(self) -> dict[str, gem.GemHostHandler]:
        """监控设备 secs 服务的 GemHostHandler 实例字典."""
        return self._host_handlers

    def _create_gem_host_handler(self):
        """根据配置文件创建连接设备的客户端."""
        for equipment_ip_port in self.passive_ips:
            equipment_ip, port = equipment_ip_port.split(":")
            setting = hsms.HsmsSettings(
                address=equipment_ip,
                port=int(port),
                connect_mode=getattr(hsms.HsmsConnectMode, "ACTIVE"),
                device_type=hsms.DeviceType.HOST
            )
            host_handler = gem.GemHostHandler(setting)
            self._host_handlers[equipment_ip_port] = host_handler
            self.report_link_sv_or_dv(host_handler, equipment_ip, port)

    @staticmethod
    def report_link_sv_or_dv(host_handler: gem.GemHostHandler, equipment_ip: str, port: str):
        """将报告和 sv 或 dv 关联.

        Args:
            host_handler: GemHostHandler 实例.
            equipment_ip: host监控设备的 secs 服务 ip.
            port: host监控设备的 secs 服务端口.
        """
        from passive_server import factory, secs_config

        mysql = factory.get_mysql_instance(equipment_ip, f"{equipment_ip}:{port}")
        report_link_list = secs_config.get_report_link_info(mysql)
        for report_link in report_link_list:
            host_handler.report_subscriptions.update(report_link)

    def enable_host_handler(self):
        """启动监控设备 secs 服务的客户端"""
        for equipment_ip_port, host_handler in self._host_handlers.items():
            host_handler.enable()
            self.logger.info("已启动监控 %s 设备 secs 服务的 Active 客户端", equipment_ip_port)

    def set_call_back(self, ip_port: str, func_name: str, func: Callable):
        """设置监控到设备上报数据触发的回调函数.

        Args:
            ip_port: 监控的设备服务端的 ip port.
            func_name: 函数名称.
            func: 函数本体.
        """
        setattr(self.get_host_instance(ip_port).callbacks, func_name, func)

    def set_receive_event_callback(self, ip_port: str, func: Callable):
        """设置监控到设备上事件据触发的回调函数.

        Args:
            ip_port: 监控的设备服务端的 ip port.
            func: 函数本体.
        """
        host_handler = self.get_host_instance(ip_port)
        host_handler.protocol.events.collection_event_received += func

    def get_host_instance(self, ip_port: str) -> gem.GemHostHandler:
        """获取监控设备 secs 服务的 GemHostHandler.

        Args:
            ip_port: 监控设备 secs 服务的 ip 和 端口.

        Returns:
            gem.GemHostHandler: 返回 gem.GemHostHandler.
        """
        return self._host_handlers[ip_port]

    def send_sf(self, stream_num: int, function_num: int,  data_dict: dict):
        """给指定设备的 secs 服务下发流函数.

        Args:
            stream_num: stream num.
            function_num: function num.
            data_dict: S3F17 的数据字典.
        """
        for equipment_ip_port, host_handler in self._host_handlers.items():
            sf_instance = host_handler.stream_function(stream_num, function_num)()
            for param_name, param_value in data_dict.items():
                if param_name == "PARAMS":
                    param_value = get_secs_param_value(param_value)
                setattr(sf_instance, param_name, param_value)
            self.logger.info("已给设备 %s 下发流函数", equipment_ip_port)
            threading.Thread(
                target=self._fire_send_sf, args=(equipment_ip_port, host_handler, sf_instance), daemon=True
            ).start()

    def _fire_send_sf(self, equipment_ip_port: str, host_handler: gem.GemHostHandler, sf_instance: functions.StreamsFunctions):
        """Host 给设备端 secs 服务发送流函数.

        Args:
            equipment_ip_port: 设备端 secs 服务 ip 端口》
            host_handler: GemHostHandler 实例.
            sf_instance: StreamsFunctions 实例.
        """
        message = host_handler.send_and_waitfor_response(sf_instance)
        self.logger.info("设备 %s 已回复 %s", equipment_ip_port, f"s{message.header.stream}f{message.header.function}")
