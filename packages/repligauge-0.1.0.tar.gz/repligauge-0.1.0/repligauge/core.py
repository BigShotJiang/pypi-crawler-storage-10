import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import ks_2samp, chisquare
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder, LabelEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import accuracy_score, r2_score, f1_score
from sklearn.decomposition import PCA
from sklearn.neighbors import NearestNeighbors
import os
import warnings
from textwrap import dedent

# Suppress common warnings for cleaner output
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

class DataQualityComparator:
    """
    A class to compare the quality of a synthetic dataset against a real dataset.
    
    This class does NOT generate synthetic data. It only evaluates it.
    
    Key comparisons:
    1. Univariate Distribution Comparison (Statistical Tests)
    2. Multivariate Correlation Comparison (Visual + Statistical)
    3. Dimensionality Reduction Comparison (PCA)
    4. Machine Learning Utility (Train-Synthetic-Test-Real)
    5. Privacy Check (Nearest Neighbor Distance)
    """
    
    def __init__(self, real_df: pd.DataFrame, synthetic_df: pd.DataFrame):
        """
        Initializes the comparator with real and synthetic data.
        
        Args:
            real_df (pd.DataFrame): The original, real dataset.
            synthetic_df (pd.DataFrame): The generated, synthetic dataset.
        """
        print("Initializing DataQualityComparator...")
        self.real_df = real_df.copy()
        self.synthetic_df = synthetic_df.copy()
        self.results = {}
        
        self._validate_dataframes()
        self._identify_column_types()
        print(f"  > Found {len(self.numerical_cols)} numerical columns: {self.numerical_cols}")
        print(f"  > Found {len(self.categorical_cols)} categorical columns: {self.categorical_cols}")
        print("Initialization complete.")

    def _validate_dataframes(self):
        """Internal method to validate that dataframes are compatible."""
        if not isinstance(self.real_df, pd.DataFrame) or not isinstance(self.synthetic_df, pd.DataFrame):
            raise ValueError("Inputs must be pandas DataFrames.")
            
        if set(self.real_df.columns) != set(self.synthetic_df.columns):
            print("Warning: Column names do not match perfectly.")
            print(f"  Real cols: {set(self.real_df.columns)}")
            print(f"  Synth cols: {set(self.synthetic_df.columns)}")
            raise ValueError("Column sets must be identical for comparison.")
            
        # Reorder synthetic columns to match real
        self.synthetic_df = self.synthetic_df[self.real_df.columns]
        
        if self.real_df.shape[1] == 0:
            raise ValueError("DataFrames have no columns.")

    def _identify_column_types(self):
        """Identifies numerical and categorical columns."""
        self.numerical_cols = self.real_df.select_dtypes(include=np.number).columns.tolist()
        self.categorical_cols = self.real_df.select_dtypes(exclude=np.number).columns.tolist()
        
        # Refine categorical cols: if a numerical col has few unique values, treat as categorical
        for col in self.numerical_cols[:]: # Iterate on a copy
            if self.real_df[col].nunique() < 20:
                self.numerical_cols.remove(col)
                self.categorical_cols.append(col)
                # Ensure dtype is object for consistent processing
                self.real_df[col] = self.real_df[col].astype('category')
                self.synthetic_df[col] = self.synthetic_df[col].astype('category')

    def _get_preprocessed_data(self, for_privacy_check=False):
        """Helper to get fully preprocessed data for PCA and privacy checks."""
        
        # For privacy, we need to compare all columns.
        if for_privacy_check:
            num_features = self.numerical_cols
            cat_features = self.categorical_cols
            features = num_features + cat_features
        else:
            # For PCA, we usually exclude the target.
            # This is a heuristic; user might want to include target.
            # For simplicity, we'll process all columns and let PCA run on them.
            num_features = self.numerical_cols
            cat_features = self.categorical_cols
            features = num_features + cat_features
        
        if not features:
            print("Warning: No features found for preprocessing.")
            return None, None

        numeric_transformer = Pipeline(steps=[('scaler', StandardScaler())])
        categorical_transformer = Pipeline(steps=[('onehot', OneHotEncoder(handle_unknown='ignore'))])
        
        preprocessor = ColumnTransformer(
            transformers=[
                ('num', numeric_transformer, num_features),
                ('cat', categorical_transformer, cat_features)
            ],
            remainder='drop'
        )
            
        try:
            real_processed = preprocessor.fit_transform(self.real_df[features]).toarray()
            synth_processed = preprocessor.transform(self.synthetic_df[features]).toarray()
            return real_processed, synth_processed
        except Exception as e:
            print(f"Error during preprocessing: {e}")
            return None, None

    def compare_univariate_distributions(self) -> dict:
        """
        Compares univariate distributions using statistical tests.
        - Kolmogorov-Smirnov (K-S) test for numerical columns.
        - Chi-Squared test for categorical columns.
        
        Returns:
            dict: A dictionary containing test statistics and p-values for each column.
                  High p-values (e.g., > 0.05) suggest similar distributions.
        """
        stats_results = {'numerical': {}, 'categorical': {}}
        
        # Numerical columns: K-S Test
        num_p_values = []
        for col in self.numerical_cols:
            real_data = self.real_df[col].dropna()
            synth_data = self.synthetic_df[col].dropna()
            if len(real_data) == 0 or len(synth_data) == 0:
                continue
            ks_stat, p_value = ks_2samp(real_data, synth_data)
            stats_results['numerical'][col] = {'ks_statistic': ks_stat, 'p_value': p_value}
            num_p_values.append(p_value)
            
        # Categorical columns: Chi-Squared Test
        cat_p_values = []
        for col in self.categorical_cols:
            real_freq = self.real_df[col].value_counts()
            synth_freq = self.synthetic_df[col].value_counts()
            
            # Align categories
            all_categories = set(real_freq.index) | set(synth_freq.index)
            real_freq = real_freq.reindex(all_categories, fill_value=0)
            synth_freq = synth_freq.reindex(all_categories, fill_value=0)

            # Chi-Squared test requires non-zero observed frequencies
            if (real_freq == 0).all() or (synth_freq == 0).all():
                continue

            # Scale synthetic frequencies to match real data size for a fair comparison
            synth_freq_scaled = (synth_freq / synth_freq.sum()) * real_freq.sum()
            
            # Add 1 to avoid zeros in expected frequencies (real_freq)
            real_freq_plus_one = real_freq + 1
            synth_freq_scaled_plus_one = (synth_freq_scaled / synth_freq_scaled.sum()) * real_freq_plus_one.sum()

            try:
                chisq_stat, p_value = chisquare(f_obs=synth_freq_scaled_plus_one, f_exp=real_freq_plus_one)
                stats_results['categorical'][col] = {'chi2_statistic': chisq_stat, 'p_value': p_value}
                cat_p_values.append(p_value)
            except ValueError as e:
                print(f"Could not run Chi-Squared test for {col}: {e}")
                stats_results['categorical'][col] = {'error': str(e)}

        self.results['univariate_stats'] = stats_results
        # Store high-level averages for the report
        if num_p_values:
            self.results['avg_numerical_p_value'] = np.mean(num_p_values)
        if cat_p_values:
            self.results['avg_categorical_p_value'] = np.mean(cat_p_values)
            
        return stats_results

    def compare_correlation_matrices(self) -> float:
        """
        Compares the correlation matrices of numerical columns.
        
        Returns:
            float: The Frobenius norm of the difference between the two matrices.
                   A value closer to 0 is better.
        """
        if not self.numerical_cols:
            print("No numerical columns found to compare correlation.")
            return np.nan
            
        real_corr = self.real_df[self.numerical_cols].corr().fillna(0)
        synth_corr = self.synthetic_df[self.numerical_cols].corr().fillna(0)
        
        corr_diff = np.linalg.norm(real_corr - synth_corr, 'fro')
        self.results['correlation_difference'] = corr_diff
        return corr_diff

    def plot_correlation_heatmap(self, save_to_file: str = None):
        """
        Plots the correlation heatmaps for real and synthetic data side-by-side.
        """
        if not self.numerical_cols:
            print("No numerical columns found to plot correlation heatmap.")
            return

        real_corr = self.real_df[self.numerical_cols].corr()
        synth_corr = self.synthetic_df[self.numerical_cols].corr()

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 7))
        
        mask = np.triu(np.ones_like(real_corr, dtype=bool))
        
        sns.heatmap(real_corr, annot=True, fmt=".2f", cmap='vlag', vmin=-1, vmax=1, mask=mask, ax=ax1, cbar=False)
        ax1.set_title("Real Data Correlation Matrix", fontsize=16)
        
        sns.heatmap(synth_corr, annot=True, fmt=".2f", cmap='vlag', vmin=-1, vmax=1, mask=mask, ax=ax2)
        ax2.set_title("Synthetic Data Correlation Matrix", fontsize=16)
        
        plt.tight_layout()
        
        if save_to_file:
            plt.savefig(save_to_file, dpi=300)
            print(f"Correlation heatmap plot saved to {save_to_file}")
            plt.close(fig)
        else:
            plt.show()
            
        self.results['correlation_heatmap_file'] = save_to_file

    def plot_distribution_grid(self, save_to_file: str = None):
        """
        Plots the distributions for all columns in a grid.
        - Histograms/KDEs for numerical columns.
        - Count plots for categorical columns.
        
        Args:
            save_to_file (str, optional): Path to save the plot. If None, shows the plot.
        """
        all_cols = self.numerical_cols + self.categorical_cols
        if not all_cols:
            print("No columns to plot.")
            return

        n_cols = len(all_cols)
        # --- MODIFICATION: Changed from min(3, n_cols) to min(2, n_cols) ---
        n_plot_cols = min(2, n_cols)
        # --- End Modification ---
        
        n_plot_rows = int(np.ceil(n_cols / n_plot_cols))
        
        fig, axes = plt.subplots(n_plot_rows, n_plot_cols, figsize=(n_plot_cols * 8, n_plot_rows * 5)) # Increased fig size
        axes = np.array(axes).flatten()

        # Combine dataframes for easier plotting with seaborn
        combined_df = pd.concat([
            self.real_df.assign(source='Real'),
            self.synthetic_df.assign(source='Synthetic')
        ], ignore_index=True)

        for i, col in enumerate(all_cols):
            ax = axes[i]
            if col in self.numerical_cols:
                sns.histplot(data=combined_df, x=col, hue='source', ax=ax, kde=True, element='step', stat='density', common_norm=False)
                ax.set_title(f"Numerical: {col}", fontsize=14)
            elif col in self.categorical_cols:
                # --- FIX ---
                # Replaced countplot with histplot for consistent, independent normalization
                # This now matches the logic used for numerical plots.
                sns.histplot(data=combined_df, x=col, hue='source', ax=ax, 
                             stat='density', common_norm=False, discrete=True, shrink=0.8)
                # --- END FIX ---
                ax.set_title(f"Categorical: {col}", fontsize=14)
                ax.tick_params(axis='x', rotation=45)

        # Hide unused subplots
        for j in range(i + 1, len(axes)):
            axes[j].set_visible(False)
            
        plt.tight_layout()
        
        if save_to_file:
            plt.savefig(save_to_file, dpi=300)
            print(f"Distribution grid plot saved to {save_to_file}")
            plt.close(fig)
        else:
            plt.show()
        
        self.results['distribution_plot_file'] = save_to_file

    def plot_pca_comparison(self, save_to_file: str = None):
        """
        Performs PCA and plots the first two components for real and synthetic data.
        """
        print("Running PCA analysis...")
        real_processed, synth_processed = self._get_preprocessed_data()
        
        if real_processed is None or synth_processed is None:
            print("Skipping PCA plot: Preprocessing failed or no data.")
            self.results['pca_plot_file'] = 'Skipped'
            return

        if real_processed.shape[1] < 2:
             print("Skipping PCA plot: Need at least 2 features after preprocessing.")
             self.results['pca_plot_file'] = 'Skipped (not enough features)'
             return
             
        pca = PCA(n_components=2)
        real_pca = pca.fit_transform(real_processed)
        synth_pca = pca.transform(synth_processed)
        
        print(f"PCA Explained Variance: {pca.explained_variance_ratio_.sum() * 100:.2f}%")
        self.results['pca_explained_variance'] = pca.explained_variance_ratio_.sum()

        pca_df_real = pd.DataFrame(data=real_pca, columns=['PC1', 'PC2']).assign(source='Real')
        pca_df_synth = pd.DataFrame(data=synth_pca, columns=['PC1', 'PC2']).assign(source='Synthetic')
        pca_df = pd.concat([pca_df_real, pca_df_synth])

        plt.figure(figsize=(10, 7))
        sns.scatterplot(data=pca_df, x='PC1', y='PC2', hue='source', alpha=0.5, s=30)
        plt.title('PCA Component Comparison (2D Projection)', fontsize=16)
        plt.xlabel('Principal Component 1')
        plt.ylabel('Principal Component 2')
        plt.legend()
        plt.tight_layout()

        if save_to_file:
            plt.savefig(save_to_file, dpi=300)
            print(f"PCA comparison plot saved to {save_to_file}")
            plt.close()
        else:
            plt.show()
            
        self.results['pca_plot_file'] = save_to_file

    def _get_default_models(self, problem_type):
        """Returns default models for classification or regression."""
        if problem_type == 'classification':
            return [
                LogisticRegression(max_iter=1000, random_state=42),
                RandomForestClassifier(n_estimators=100, random_state=42)
            ]
        elif problem_type == 'regression':
            return [
                LinearRegression(),
                RandomForestRegressor(n_estimators=100, random_state=42)
            ]
        return []

    def evaluate_machine_learning_utility(self, target_col: str, models_to_test: list = None) -> dict:
        """
        Evaluates ML utility by training on one dataset and testing on another.
        """
        if target_col not in self.real_df.columns:
            raise ValueError(f"Target column '{target_col}' not in DataFrame.")

        # Identify features (X) and target (y)
        features = [col for col in self.real_df.columns if col != target_col]
        
        # Separate numerical and categorical features
        num_features = [col for col in self.numerical_cols if col != target_col]
        cat_features = [col for col in self.categorical_cols if col != target_col]
        
        # Create preprocessing pipeline
        numeric_transformer = Pipeline(steps=[('scaler', StandardScaler())])
        categorical_transformer = Pipeline(steps=[('onehot', OneHotEncoder(handle_unknown='ignore'))])
        
        preprocessor = ColumnTransformer(
            transformers=[
                ('num', numeric_transformer, num_features),
                ('cat', categorical_transformer, cat_features)
            ])
            
        # Prepare data
        X_real = self.real_df[features]
        y_real = self.real_df[target_col]
        X_synth = self.synthetic_df[features]
        y_synth = self.synthetic_df[target_col]

        # Determine problem type
        if y_real.dtype == 'object' or y_real.dtype.name == 'category' or y_real.nunique() < 20:
            problem_type = 'classification'
            scorer = f1_score
            scorer_params = {'average': 'weighted'}
            scorer_name = 'F1 Score (Weighted)'
            le = LabelEncoder()
            y_real = le.fit_transform(y_real)
            y_synth = le.transform(y_synth)
        else:
            problem_type = 'regression'
            scorer = r2_score
            scorer_params = {}
            scorer_name = 'R2 Score'
            
        if models_to_test is None:
            models = self._get_default_models(problem_type)
        else:
            models = models_to_test
            
        ml_results = {}
        
        print(f"Running ML utility tests for {problem_type} on target '{target_col}'...")
        
        # Pre-process all data first
        X_real_processed = preprocessor.fit_transform(X_real)
        X_synth_processed = preprocessor.transform(X_synth)
        
        # Scenario 1: Train Real, Test Real (Baseline)
        X_train_r, X_test_r, y_train_r, y_test_r = train_test_split(X_real_processed, y_real, test_size=0.3, random_state=42)
        
        # Scenario 2: Train Synthetic, Test Real (Full)
        X_train_s, y_train_s = X_synth_processed, y_synth
        X_test_sr, y_test_sr = X_real_processed, y_real # Test on full real dataset
        
        # Scenario 3: Train Real, Test Synthetic (Full)
        X_train_r_full, y_train_r_full = X_real_processed, y_real
        X_test_rs, y_test_rs = X_synth_processed, y_synth
        
        for model in models:
            model_name = model.__class__.__name__
            print(f"  > Testing model: {model_name}")
            ml_results[model_name] = {'Problem Type': problem_type, 'Metric': scorer_name}
            
            # 1. Train Real, Test Real
            model.fit(X_train_r, y_train_r)
            preds_rtr = model.predict(X_test_r)
            score_rtr = scorer(y_test_r, preds_rtr, **scorer_params)
            ml_results[model_name]['Train-Real-Test-Real'] = score_rtr
            
            # 2. Train Synthetic, Test Real
            model.fit(X_train_s, y_train_s)
            preds_tstr = model.predict(X_test_sr)
            score_tstr = scorer(y_test_sr, preds_tstr, **scorer_params)
            ml_results[model_name]['Train-Synth-Test-Real'] = score_tstr
            
            # 3. Train Real, Test Synthetic
            model.fit(X_train_r_full, y_train_r_full)
            preds_rts = model.predict(X_test_rs)
            score_rts = scorer(y_test_rs, preds_rts, **scorer_params)
            ml_results[model_name]['Train-Real-Test-Synth'] = score_rts

        self.results['ml_utility'] = ml_results
        
        # Save a high-level score for the summary report
        # We take the first model's TSTR score as the representative one
        first_model = list(ml_results.keys())[0]
        self.results['representative_ml_score'] = ml_results[first_model]['Train-Synth-Test-Real']
        self.results['representative_ml_baseline'] = ml_results[first_model]['Train-Real-Test-Real']
        self.results['representative_ml_metric'] = ml_results[first_model]['Metric']

        return ml_results

    def plot_ml_utility(self, ml_results: dict = None, save_to_file: str = None):
        """
        Plots the results from the ML utility evaluation.
        """
        if ml_results is None:
            ml_results = self.results.get('ml_utility')
            
        if not ml_results:
            print("No ML utility results to plot. Run evaluate_machine_learning_utility first.")
            return

        df = pd.DataFrame(ml_results).T
        metric_name = df['Metric'].iloc[0]
        df = df.drop(columns=['Problem Type', 'Metric'])
        
        ax = df.plot(kind='bar', figsize=(12, 7), rot=0)
        ax.set_title("Machine Learning Utility Comparison", fontsize=16)
        ax.set_ylabel(metric_name, fontsize=12)
        ax.set_xlabel("Model", fontsize=12)
        ax.legend(title="Scenario")
        plt.tight_layout()
        
        if save_to_file:
            plt.savefig(save_to_file, dpi=300)
            print(f"ML utility plot saved to {save_to_file}")
            plt.close()
        else:
            plt.show()

        self.results['ml_utility_plot_file'] = save_to_file

    def check_privacy_nearest_neighbor(self) -> dict:
        """
        Checks for data leakage by finding the nearest neighbor in the real data
        for each synthetic data point.
        
        Returns:
            dict: A dictionary with the mean distance and percentage of identical rows.
        """
        print("Running privacy check (Nearest Neighbor)...")
        real_processed, synth_processed = self._get_preprocessed_data(for_privacy_check=True)
        
        if real_processed is None or synth_processed is None:
            print("Skipping privacy check: Preprocessing failed.")
            return {'error': 'Preprocessing failed'}

        # Fit on real data
        nbrs = NearestNeighbors(n_neighbors=1, algorithm='auto').fit(real_processed)
        
        # Find distances for synthetic data
        distances, indices = nbrs.kneighbors(synth_processed)
        
        # Distances is a list of lists, get the first (and only) neighbor distance
        distances = distances.flatten()
        
        identical_rows_pct = (np.sum(distances == 0) / len(distances)) * 100
        mean_distance = np.mean(distances)
        
        privacy_results = {
            'mean_nearest_neighbor_distance': mean_distance,
            'identical_rows_percentage': identical_rows_pct
        }
        
        self.results['privacy_check'] = privacy_results
        return privacy_results

    def _format_report_string(self) -> str:
        """Formats the self.results dictionary into a printable string report."""
        
        report_lines = ["="*80, "      Data Quality Report for Synthetic vs. Real Data", "="*80, "\n"]
        
        # --- Executive Summary ---
        report_lines.append("\n" + "--- EXECUTIVE SUMMARY " + "-"*59)
        try:
            privacy_pct = self.results.get('privacy_check', {}).get('identical_rows_percentage', -1)
            ml_score = self.results.get('representative_ml_score', -1)
            ml_baseline = self.results.get('representative_ml_baseline', -1)
            ml_metric = self.results.get('representative_ml_metric', 'N/A')
            corr_diff = self.results.get('correlation_difference', -1)
            avg_p_val = np.mean([
                self.results.get('avg_numerical_p_value', 0),
                self.results.get('avg_categorical_p_value', 0)
            ])
            
            report_lines.append(f"  - Privacy Risk (Identical Rows): {privacy_pct:.2f}% (Lower is better)")
            report_lines.append(f"  - ML Utility (TSTR vs RTR):      {ml_score:.3f} vs {ml_baseline:.3f} ({ml_metric})")
            report_lines.append(f"  - Correlation Difference (Norm): {corr_diff:.3f} (Lower is better)")
            report_lines.append(f"  - Avg. Column Similarity (p-val):{avg_p_val:.3f} (Higher is better)")
        except Exception as e:
            report_lines.append(f"  Could not generate summary: {e}")
        report_lines.append("-" * 80 + "\n")
        
        
        report_lines.append(f"Real Data Shape:      {self.real_df.shape}")
        report_lines.append(f"Synthetic Data Shape: {self.synthetic_df.shape}\n")
        
        # --- Privacy Check ---
        report_lines.append("\n" + "-"*80 + "\n1. Privacy & Authenticity Check (Nearest Neighbor)\n" + "-"*80)
        privacy_res = self.results.get('privacy_check', {})
        if privacy_res:
            report_lines.append(f"  - Identical Rows Found:    {privacy_res.get('identical_rows_percentage', 'N/A'):.2f}%")
            report_lines.append(f"  - Avg. Distance to Real:   {privacy_res.get('mean_nearest_neighbor_distance', 'N/A'):.4f}")
            report_lines.append("  (A high % of identical rows indicates simple copying, a major privacy risk.)")
        else:
            report_lines.append("No privacy check was run.")

        # --- Univariate Stats ---
        report_lines.append("\n" + "-"*80 + "\n2. Univariate Distribution Comparison (p-values)\n" + "-"*80)
        report_lines.append("High p-values (e.g., > 0.05) suggest distributions are statistically similar.\n")
        
        stats = self.results.get('univariate_stats', {})
        if stats:
            report_lines.append("Numerical Columns (Kolmogorov-Smirnov Test):")
            report_lines.append(f"  - Average p-value: {self.results.get('avg_numerical_p_value', np.nan):.4f}")
            for col, res in stats.get('numerical', {}).items():
                report_lines.append(f"    - {col:<25} p-value: {res['p_value']:.4f}")
            
            report_lines.append("\nCategorical Columns (Chi-Squared Test):")
            report_lines.append(f"  - Average p-value: {self.results.get('avg_categorical_p_value', np.nan):.4f}")
            for col, res in stats.get('categorical', {}).items():
                if 'p_value' in res:
                    report_lines.append(f"    - {col:<25} p-value: {res['p_value']:.4f}")
                else:
                    report_lines.append(f"    - {col:<25} Error: {res.get('error')}")
        else:
            report_lines.append("No univariate statistics were calculated.")
            
        # --- Correlation ---
        report_lines.append("\n" + "-"*80 + "\n3. Correlation Matrix Comparison (Numerical Columns)\n" + "-"*80)
        corr_diff = self.results.get('correlation_difference')
        if corr_diff is not None:
            report_lines.append(f"Frobenius Norm of Correlation Matrix Difference: {corr_diff:.4f}")
            report_lines.append("(Closer to 0 is better)\n")
        else:
            report_lines.append("No correlation comparison was calculated (likely no numerical columns).")

        # --- PCA ---
        report_lines.append("\n" + "-"*80 + "\n4. Structural Comparison (PCA)\n" + "-"*80)
        pca_var = self.results.get('pca_explained_variance')
        if pca_var:
             report_lines.append(f"  - Explained variance (2 components): {pca_var * 100:.2f}%")
        else:
            report_lines.append("  - PCA analysis was not run or was skipped.")
            
        # --- ML Utility ---
        report_lines.append("\n" + "-"*80 + "\n5. Machine Learning Utility\n" + "-"*80)
        ml_results = self.results.get('ml_utility')
        if ml_results:
            df = pd.DataFrame(ml_results).T
            report_lines.append("Scores from different training/testing scenarios:\n")
            report_lines.append(df.to_string())
            report_lines.append(dedent("""
            
            Key Metrics:
            - 'Train-Real-Test-Real': Baseline score on real data.
            - 'Train-Synth-Test-Real': **Most important!** How well a model trained on
                                        synthetic data performs on real data.
            """))
        else:
            report_lines.append("No ML utility tests were run.")

        # --- File Locations ---
        report_lines.append("\n" + "-"*80 + "\n6. Generated Plots\n" + "-"*80)
        report_lines.append(f"  - Distribution Comparison Plot: {self.results.get('distribution_plot_file', 'Not generated')}")
        report_lines.append(f"  - Correlation Heatmap Plot:   {self.results.get('correlation_heatmap_file', 'Not generated')}")
        report_lines.append(f"  - PCA Comparison Plot:        {self.results.get('pca_plot_file', 'Not generated')}")
        report_lines.append(f"  - ML Utility Comparison Plot:   {self.results.get('ml_utility_plot_file', 'Not generated')}")
        
        report_lines.append("\n" + "="*80 + "\nEnd of Report\n" + "="*80)
        
        return "\n".join(report_lines)


    def generate_full_report(self, target_col: str, models: list = None, save_path: str = 'dq_report'):
        """
        Runs all comparison methods and generates a consolidated report.
        
        This method will:
        1. Create a directory specified by `save_path`.
        2. Run privacy checks.
        3. Run univariate statistical tests.
        4. Run correlation comparison.
        5. Generate and save all plots (distributions, correlations, PCA).
        6. Run the machine learning utility tests.
        7. Generate and save the ML utility plot.
        8. Save a `report.txt` file with all findings to the `save_path`.
        9. Print the text report to the console.
        
        Args:
            target_col (str): The target column for ML evaluation.
            models (list, optional): List of sklearn models for ML evaluation.
            save_path (str, optional): Directory to save plots and text report.
        
        Returns:
            dict: The self.results dictionary containing all raw results.
        """
        print(f"\n{'='*30} STARTING FULL DATA QUALITY REPORT {'='*30}")
        
        # 1. Create save directory
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        print(f"Report files will be saved to: {os.path.abspath(save_path)}")
        
        # 2. Run Privacy Check
        print("\n[1/7] Running privacy & authenticity checks...")
        self.check_privacy_nearest_neighbor()

        # 3. Run Univariate Stats
        print("\n[2/7] Running univariate statistical tests...")
        self.compare_univariate_distributions()
        
        # 4. Run Correlation Comparison
        print("\n[3/7] Comparing correlation matrices...")
        self.compare_correlation_matrices()
        
        # 5. Generate Plots
        print("\n[4/7] Generating distribution plots (2-column layout)...")
        dist_plot_file = os.path.join(save_path, 'distribution_comparison.png')
        self.plot_distribution_grid(save_to_file=dist_plot_file)
        
        print("\n[5/7] Generating correlation heatmap plots...")
        corr_plot_file = os.path.join(save_path, 'correlation_heatmap.png')
        self.plot_correlation_heatmap(save_to_file=corr_plot_file)

        print("\n[6/7] Generating PCA structural comparison plot...")
        pca_plot_file = os.path.join(save_path, 'pca_comparison.png')
        self.plot_pca_comparison(save_to_file=pca_plot_file)
        
        # 7. Run ML Utility
        print("\n[7/7] Evaluating machine learning utility...")
        ml_scores = self.evaluate_machine_learning_utility(target_col=target_col, models_to_test=models)
        
        # 8. Generate ML Plot
        print("\n[8/8] Generating ML utility plot...")
        ml_plot_file = os.path.join(save_path, 'ml_utility_comparison.png')
        self.plot_ml_utility(ml_results=ml_scores, save_to_file=ml_plot_file)
        
        # 9. Format, Save, and Print Text Report
        print("\nGenerating final report...")
        report_string = self._format_report_string()
        report_file = os.path.join(save_path, 'data_quality_report.txt')
        
        try:
            with open(report_file, 'w', encoding='utf-8') as f:
                f.write(report_string)
            print(f"Text report saved to {report_file}")
        except Exception as e:
            print(f"Error saving text report: {e}")
            
        print(report_string)
        print(f"{'='*32} REPORT GENERATION COMPLETE {'='*32}\n")
        
        return self.results


