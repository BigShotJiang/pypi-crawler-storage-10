# This file is part of pydidas.
#
# Copyright 2023 - 2025, Helmholtz-Zentrum Hereon
# SPDX-License-Identifier: GPL-3.0-only
#
# pydidas is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 3 as
# published by the Free Software Foundation.
#
# Pydidas is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Pydidas. If not, see <http://www.gnu.org/licenses/>.

"""
Module with access to pydidas icons.
"""

__author__ = "Malte Storm"
__copyright__ = "Copyright 2023 - 2025, Helmholtz-Zentrum Hereon"
__license__ = "GPL-3.0-only"
__maintainer__ = "Malte Storm"
__status__ = "Production"
__all__ = [
    "pydidas_logo_svg",
    "pydidas_error_svg",
]

import os

import qtpy


if qtpy.QT5:
    from qtpy.QtSvg import QSvgWidget
elif qtpy.QT6:
    from qtpy.QtSvgWidgets import QSvgWidget

from pydidas.resources.pydidas_icons import ICON_PATH


def pydidas_logo_svg() -> QSvgWidget:
    """
    Get the pydidas logo as QSvgWidget.

    Returns
    -------
    QSvgWidget
        The QSvgWidget with the pydidas logo.
    """
    return QSvgWidget(os.path.join(ICON_PATH, "pydidas_snakes.svg"))


def pydidas_error_svg() -> QSvgWidget:
    """
    Get the icon for a pydidas error.

    Returns
    -------
    QSvgWidget
        The QSvgWidget with the pydidas error image.
    """
    return QSvgWidget(os.path.join(ICON_PATH, "pydidas_error.svg"))
