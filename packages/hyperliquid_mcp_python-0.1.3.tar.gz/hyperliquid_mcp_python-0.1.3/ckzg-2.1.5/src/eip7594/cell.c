/*
 * Copyright 2024 Benjamin Edgington
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "eip7594/cell.h"
#include "common/bytes.h"

#include <stdio.h> /* For printf */

/**
 * Print Cell to the console.
 *
 * @param[in]   cell    The Cell to print
 */
void print_cell(const Cell *cell) {
    for (size_t i = 0; i < FIELD_ELEMENTS_PER_CELL; i++) {
        const Bytes32 *element_bytes = (const Bytes32 *)&cell->bytes[i * BYTES_PER_FIELD_ELEMENT];
        print_bytes32(element_bytes);
    }
}
