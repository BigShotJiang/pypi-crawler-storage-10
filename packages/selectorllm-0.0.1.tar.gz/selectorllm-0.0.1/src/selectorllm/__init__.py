from .main import get_selector

__version__ = "0.0.1"
__all__ = ["get_selector"]