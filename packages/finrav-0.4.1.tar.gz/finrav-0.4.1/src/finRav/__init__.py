"""
finRav – Advanced Quantitative Finance & Stochastic Simulation Toolkit
=====================================================================

finRav provides modular, extensible components for quantitative
finance research, including stochastic process simulation,
Monte Carlo engines, and unified price models.

Subpackages
-----------
- finRav.price_models : Unified GBM / fGBM and Bachelier / fBachelier models.
- finRav.monte_carlo  : Monte Carlo simulation engine.
- finRav.stoch        : Fractional Brownian motion & stochastic drivers.
- finRav.utils        : Time scaling and helper utilities.
- finRav.stats        : Useful statistical analysis for raw data.

Quick Example
-------------
>>> from finRav.price_models import LogNormalPriceModel
>>> from finRav.monte_carlo import MonteCarloSimulator
>>> model = LogNormalPriceModel(S0=100, mu=0.05, sigma=0.2, H=0.7)
>>> sim = MonteCarloSimulator(model, n_paths=1000, path_length=252, interval="1D", unit="1Y")
>>> t, S = sim.simulate_paths()
>>> S.shape
(1000, 252)
"""

from . import price_models, monte_carlo, stoch, utils, stats

__all__ = [
    "price_models",
    "monte_carlo",
    "stoch",
    "stats",
    "utils",
    "__version__",
]

# קריאת גרסת חבילה מתוך מטא־דאטה
try:
    from importlib.metadata import version, PackageNotFoundError
    try:
        __version__ = version("finRav")
    except PackageNotFoundError:
        __version__ = version("finrav")
except Exception:
    __version__ = "0.0.0"