"""
finRav.monte_carlo
==================

Monte Carlo simulation engine for stochastic price models.

This module provides tools to simulate multiple price paths
under both Brownian and fractional Brownian motion dynamics,
given any compatible price model.

Exposes
-------
- MonteCarloSimulator : Core Monte Carlo engine.
"""

from .simulator import MonteCarloSimulator

__all__ = ["MonteCarloSimulator"]