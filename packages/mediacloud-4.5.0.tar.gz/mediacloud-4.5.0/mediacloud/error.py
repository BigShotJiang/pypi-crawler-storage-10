import warnings


class MCException(Exception):
    def __init__(self, message, status_code=0):
        super().__init__()
        self.message = message
        self.status_code = status_code

class APIResponseError(RuntimeError):
    def __init__(self, response, params, data):
        self.response = response
        self.params = params
        self.data = data
        super().__init__(f"API Server Error {response.status_code}. MESSAGE: {data.get('note')}. PARAMS: {params}")

def deprecated(func):
    # This is a decorator which can be used to mark functions as deprecated. It will result in a
    # warning being emitted when the function is used.
    def new_func(*args, **kwargs):
        warnings.warn(f"Call to deprecated function {func.__name__}.", category=DeprecationWarning)
        return func(*args, **kwargs)
    new_func.__name__ = func.__name__
    new_func.__doc__ = func.__doc__
    new_func.__dict__.update(func.__dict__)
    return new_func
