# DatasetJoinKind


## Enum

* `INNER` (value: `'inner'`)

* `LEFT_OUTER` (value: `'left_outer'`)

* `OUTER` (value: `'outer'`)

* `RIGHT_OUTER` (value: `'right_outer'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


