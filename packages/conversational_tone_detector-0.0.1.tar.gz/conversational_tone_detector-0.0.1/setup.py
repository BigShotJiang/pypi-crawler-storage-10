from setuptools import setup, find_packages

# This reads the poster file (README.md) so it can show up on PyPI
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    # The official name of your package
    name="conversational-tone-detector",

    # This number changes every time you upload a new version
    version="0.0.1",

    # Your personal info
    author="Anushri Ranade",
    author_email="ranadeanushri@gmail.com",
    description="An advanced NLP tool for detecting conversational tone, sarcasm, and sentiment.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    license='MIT', 

    # This is where the code is (the folder you created)
    packages=find_packages(),

    # These are the other packages your code needs to work
    install_requires=[
        'nltk>=3.6', # We need this because your code uses nltk!
    ],

    # These are categories to help people find your package
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 3 - Alpha", 
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Text Processing :: Linguistic",
        "Intended Audience :: Developers",
    ],

    # Tells people your code needs Python 3.6 or newer
    python_requires='>=3.6',
)