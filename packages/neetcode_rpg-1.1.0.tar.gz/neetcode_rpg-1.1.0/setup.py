#!/usr/bin/env python3
"""
Setup script for NeetCode RPG - DSA Learning System
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

setup(
    name="neetcode-rpg",
    version="1.1.0",
    author="Neon",
    author_email="dmcbaditya@gmail.com",
    description="🎮 Transform DSA practice into an addictive RPG adventure! Level up from Coding Seedling to NeetCode Deity. Now with full Windows support!",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/addynoven/neetcode-rpg",
    project_urls={
        "Bug Reports": "https://github.com/addynoven/neetcode-rpg/issues",
        "Source": "https://github.com/addynoven/neetcode-rpg",
        "Documentation": "https://github.com/addynoven/neetcode-rpg#readme",
        "Author LinkedIn": "https://www.linkedin.com/in/aditya-sahu-34350b193/",
        "Author GitHub": "https://github.com/addynoven",
        "Discord": "https://discord.gg/pKySFQSKbw",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: Education",
        "Topic :: Education",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Games/Entertainment :: Role-Playing",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
        "Environment :: Console",
    ],
    keywords="dsa algorithms data-structures leetcode neetcode rpg gamification learning education cli",
    python_requires=">=3.8",
    install_requires=[
        "typer>=0.9.0",
        "rich>=13.0.0",
        "matplotlib>=3.5.0",
        "pillow>=9.0.0",
    ],
    entry_points={
        "console_scripts": [
            "neetcode-rpg=src.main:main",
            "dsa=src.main:main",  # Keep dsa as alias for convenience
        ],
    },
    include_package_data=True,
    package_data={
        "src": ["data/*.json", "templates/*.py"],
    },
    zip_safe=False,
)
