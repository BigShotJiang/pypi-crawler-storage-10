
import json
import time
from enum import Enum

import pandas as pd
import requests
from tqdm import tqdm


class S3ResultsLocation(Enum):
    SUCCESS = 'OutputLocation'
    FAILURE = 'FailureLocation'

class S3Operator():
    """
    A class to interact with the S3 bucket.
    """

    def __init__(self, username: str, halsted_api_key: str, base_api: str = 'https://api.halstedhealth.ai'):
        self.username = username
        self.halsted_api_key = halsted_api_key

        self.s3_upload_json_api = f'{base_api}/data/upload-json'
        self.s3_list_objects_api = f'{base_api}/data/list-objects'
        self.s3_get_file_api = f'{base_api}/data/get-file'
    
    def get_content_from_endpoint(self, response: dict) -> pd.DataFrame:
        """
        Get the content from the endpoint.

        Args:
            response (dict): The response from the endpoint.

        Returns:
            df (pd.DataFrame): The dataframe of the content.
        """
        success_location = response['body'][S3ResultsLocation.SUCCESS.value]
        failure_location = response['body'][S3ResultsLocation.FAILURE.value]
        inference_status = self.check_inference_status(success_location, failure_location)
        results_location = success_location if inference_status['Status'] == 'Complete' else failure_location
        content = self.get_file_from_s3(results_location)
        df = pd.DataFrame(json.loads(content))
        return df

    def upload_json_to_s3(self, extra_inputs: dict) -> int:
        """
        Uploads a dictionary to an S3 bucket.

        Args:
            extra_inputs (dict): The dictionary containing the extra inputs.

        Returns:
            status_code (int): The status code of the response.
        """

        inputs = {
            'username': self.username,
            'extra_inputs': extra_inputs,
        }    

        headers = {
            'Content-Type': 'application/json',
            'x-api-key': self.halsted_api_key
        }

        response = requests.post(
            self.s3_upload_json_api,
            headers=headers,
            data=json.dumps(inputs)
        )
        return response.json()['statusCode']

    def get_file_from_s3(self, path_to_s3_uri: str) -> str:
        """
        Gets a file from S3.
    
        Args:
            path_to_s3_uri (str): The path to the S3 file to get.

        Returns:
            content (str): The content of the file.
        """
        inputs = {
            'path_to_s3_uri': path_to_s3_uri,
        }
        headers = {
            'Content-Type': 'application/json',
            'x-api-key': self.halsted_api_key
        }
        response = requests.post(
            self.s3_get_file_api,
            headers=headers,
            data=json.dumps(inputs)
        )
        return response.json()['body']['content']

    def list_objects(self, path_to_s3_uri: str):
        """
        List objects in an S3 bucket.

        Args:
            path_to_s3_uri (str): The path to the S3 bucket to list objects from.

        Returns:
            response (dict): The response from the request indicating the availability of the objects.
        """
        inputs = {
            'path_to_s3_uri': path_to_s3_uri,
        }
        headers = {
            'Content-Type': 'application/json',
            'x-api-key': self.halsted_api_key
        }
        response = requests.post(
            self.s3_list_objects_api,
            headers=headers,
            data=json.dumps(inputs)
        )
        return response.json()['body']

    def check_inference_status(self, path_to_s3_results: str, path_to_s3_failure: str, wait_time: int = 10, timeout: int = 3600) -> dict:
        """
        Check the status of the inference process. 

        Args:
            path_to_s3_results (str): The path to the S3 bucket where the results of the inference are stored.
            path_to_s3_failure (str): The path to the S3 bucket where the failure of the inference is stored.
            wait_time (int): The time to wait between polling the S3 bucket.
            timeout (int): The maximum time to wait for the inference to complete.

        Returns:
            dict
                The status of the inference.
        """
        elapsed_time = 0
        pbar = tqdm(desc="Checking inference status", unit="step")

        while elapsed_time < timeout:
            response = self.list_objects(path_to_s3_results)
            if response['available'] == True:
                print('Inference complete!')
                return {'Status': 'Complete'}
            
            response = self.list_objects(path_to_s3_failure)
            if response['available'] == True:
                print('Inference failed!')
                return {'Status': 'Failed'}

            pbar.update(1)
            time.sleep(wait_time)
            elapsed_time += wait_time

        raise {'Status': 'Timeout'}