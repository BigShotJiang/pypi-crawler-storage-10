import uuid
import requests
import json

class VideoUploader:
    """
    A class to upload a video to the cloud storage.
    """

    def __init__(self, username: str, halsted_api_key: str, base_api: str = 'https://api.halstedhealth.ai'):
        self.halsted_api_key = halsted_api_key
        self.video_id = uuid.uuid4()
        self.username = username
        self.chunk_size = 1024 * 1024 * 5

        self.create_multipart_upload_api = f'{base_api}/create/invoke'
        self.upload_part_api = f'{base_api}/upload/invoke'
        self.complete_multipart_upload_api = f'{base_api}/complete/invoke'

    def create_multipart_upload(self) -> str:
        """
        Create a multipart upload to the cloud storage.
    
        Returns:
            upload_id (str): The upload ID.
        """
        payload = {
            'username': self.username,
            'video_id': str(self.video_id)
        }

        headers = {
            "Content-Type": "application/json",
            "x-api-key": self.halsted_api_key
        }

        response = requests.post(
            self.create_multipart_upload_api,
            headers=headers,
            data=json.dumps(payload)
        )
        upload_id = response.json()['body']['UploadId']
        return upload_id
    
    def upload_part(self, inputs: dict) -> str:
        """
        Upload a part of the video to the cloud storage.

        Args:
            inputs (dict): A dictionary containing the part number, the upload ID, and the chunk.

        Returns:
            etag (str): The ETag of the uploaded part.
        """
        payload = {
            "username": self.username,
            "video_id": str(self.video_id),
            'part_number': inputs['part_number'],
            'upload_id': inputs['upload_id'],
        }

        headers = {
            "Content-Type": "application/json",
            "x-api-key": self.halsted_api_key
        }

        response = requests.post(
            self.upload_part_api,
            headers=headers,
            data=json.dumps(payload)
        )

        presigned_url = response.json()['body']['url']

        response = requests.put(
            presigned_url,
            data=inputs['chunk'],
            headers={"Content-Length": str(len(inputs['chunk']))}
        )

        etag = response.headers['ETag']
        return etag
        
    def complete_multipart_upload(self, inputs: dict) -> int:
        """
        Complete a multipart upload to the cloud storage.

        Args:
            inputs (dict): A dictionary containing the upload ID and the parts.

        Returns:
            status_code (int): The status code of the response.
        """
        payload = {
            'username': self.username,
            'video_id': str(self.video_id),
            'upload_id': inputs['upload_id'],
            'parts': inputs['parts']
        }
        
        headers = {
            "Content-Type": "application/json",
            "x-api-key": self.halsted_api_key
        }
        
        response = requests.post(
            self.complete_multipart_upload_api,
            headers=headers,
            data=json.dumps(payload)
        )
        return response.json()['statusCode']

    def upload(self, local_file_path: str) -> int:
        """
        Upload local video file to S3.

        Args:
            local_file_path (str): Path to the local video file.

        Returns:
            status_code (int): The status code of the response.
        """
        upload_id = self.create_multipart_upload()

        with open(local_file_path, "rb") as file_stream:
            chunk: bytes = file_stream.read(self.chunk_size)
            part_number = 1
            parts = []
            while chunk:
                inputs = {
                    'part_number': part_number,
                    'upload_id': upload_id,
                    'chunk': chunk
                }
                etag = self.upload_part(inputs)
                part = {'PartNumber': part_number, 'ETag': etag}
                parts.append(part)
                part_number += 1
                chunk: bytes = file_stream.read(self.chunk_size)


        inputs = {
            'upload_id': upload_id,
            'parts': parts
        }
        status_code = self.complete_multipart_upload(inputs)
        if status_code != 200:
            raise Exception(f'Failed to complete multipart upload: {status_code}')