import pandas as pd

from halsted_sdk.s3 import S3Operator
from halsted_sdk.sagemaker import (SagemakerEndpoint,
                                   SagemakerEndpointInputProcessor,
                                   SagemakerEndpointType)
from halsted_sdk.upload import VideoUploader


class VideoProcessor:
    """
    A class to process a surgical video.
    """

    def __init__(self, username: str, halsted_api_key: str, base_api: str = 'https://api.halstedhealth.ai'):
        self.halsted_api_key = halsted_api_key

        self.video_uploader = VideoUploader(username, halsted_api_key, base_api)
        self.video_id = self.video_uploader.video_id

        self.sagemaker_endpoint_input_processor = SagemakerEndpointInputProcessor(username, self.video_id, halsted_api_key, base_api)
        self.sagemaker_endpoint_ffmpeg = SagemakerEndpoint(SagemakerEndpointType.FFMPEG, username, self.video_id, halsted_api_key, base_api)
        self.sagemaker_endpoint_processing = SagemakerEndpoint(SagemakerEndpointType.PROCESSING, username, self.video_id, halsted_api_key, base_api)

        self.s3_operator = S3Operator(username, halsted_api_key, base_api)

    def process_multiple_videos(self, inputs: list[dict]) -> pd.DataFrame:
        """
        Process multiple videos and return the predictions as a dataframe.

        Args:
            inputs (list[dict]): The list of inputs to process.

        Returns:
            df (pd.DataFrame): A dataframe of the predictions.
        """
        agg_df = pd.DataFrame()
        for processing_input in inputs:
            status_code = self.sagemaker_endpoint_input_processor.prepare(processing_input)
            if status_code != 200:
                raise Exception(f'Failed to process video: {status_code}')

            extra_inputs = {'clip_id': processing_input['clip_id']}
            response = self.sagemaker_endpoint_processing.invoke(extra_inputs=extra_inputs)
            df = self.s3_operator.get_content_from_endpoint(response)
            agg_df = pd.concat((agg_df, df),axis=0)
        df = agg_df.copy()

        return df

    def process(self, video_path: str) -> pd.DataFrame:
        """
        Process a video and return the predictions as a dataframe.

        Args:
            video_path (str): The local path to the video to process.

        Returns:
            df (pd.DataFrame): A dataframe of the predictions.
        """
        self.video_uploader.upload(video_path)
        ffmpeg_input = {'endpoint': SagemakerEndpointType.FFMPEG.name.lower(), 'video_id': str(self.video_id)}
        upload_status = self.sagemaker_endpoint_input_processor.prepare(ffmpeg_input)
        if upload_status != 200:
            raise Exception(f'Failed to process video: {upload_status}')

        response = self.sagemaker_endpoint_ffmpeg.invoke()
        df = self.s3_operator.get_content_from_endpoint(response)

        processing_inputs = self.sagemaker_endpoint_processing.get_inputs(self.video_id, df)
        df = self.process_multiple_videos(processing_inputs)

        return df