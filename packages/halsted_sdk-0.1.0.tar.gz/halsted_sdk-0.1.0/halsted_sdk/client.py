import pandas as pd

from halsted_sdk.process import VideoProcessor


class HalstedClient:
    """
    A client for the Halsted SDK.
    """
    
    def __init__(self, username: str, halsted_api_key: str, base_api: str = 'https://api.halstedhealth.ai'):
        self.video_processor = VideoProcessor(username, halsted_api_key, base_api)

    def process_video(self, filepath: str) -> pd.DataFrame:
        """
        Process a surgical video and return the predictions as a dataframe.

        Args:
            filepath (str): The local path to the video to process.

        Returns:
            df (pd.DataFrame): A dataframe of the predictions.
        """
        return self.video_processor.process(filepath)