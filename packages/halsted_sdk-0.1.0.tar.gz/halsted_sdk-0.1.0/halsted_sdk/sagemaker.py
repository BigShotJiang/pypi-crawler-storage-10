import json
import uuid
from enum import Enum
from typing import Optional

import pandas as pd
import requests

from halsted_sdk.s3 import S3Operator


class SagemakerEndpointType(Enum):
    PROCESSING = 'processing-v8-ModelEndpoint'
    FFMPEG = 'ffmpeg-v2-ModelEndpoint'

class SagemakerJobType(Enum):
    PROCESSING = 'processing'
    FFMPEG = 'ffmpeg'

class SagemakerEndpoint:
    """
    A class to invoke the sagemaker endpoint.
    """

    def __init__(self, endpoint_type: SagemakerEndpointType, username: str, video_id: uuid.UUID, halsted_api_key: str, base_api: str = 'https://api.halstedhealth.ai'):
        self.halsted_api_key = halsted_api_key
        self.endpoint_type = endpoint_type
        self.username = username
        self.video_id = video_id
        self.sagemaker_endpoint_api = f"{base_api}/process/invoke"

    def get_inputs(self, video_id: uuid.UUID, df: pd.DataFrame) -> list[dict]:
        """
        Get the processing inputs for the sagemaker endpoint.

        Args:
            df (pd.DataFrame): The dataframe containing the processing inputs.

        Returns:
            processing_inputs (list[dict]): The list of processing inputs.
        """
        processing_inputs = []
        for _, row in df.iterrows():
            processing_inputs.append({
                'endpoint': self.endpoint_type.name.lower(),
                "video_id": str(video_id),
                "clip_id": row['uuid'],
                "clip_start_time": row['Clip Start Time'],
                "clip_end_time": row['Clip End Time'],
                "task": "ease",
                "eval_category": "race",
                "inference_step_dur_list": [5],
            })
        return processing_inputs

    def invoke(self, extra_inputs: Optional[dict] = None) -> dict:
        """
        Invoke the sagemaker endpoint.

        Args:
            extra_inputs (dict): A dictionary containing the extra inputs.        
        
        Returns:
            response (dict): indicating status code and the response body of the request.
        """
        payload = {
            "username": self.username,
            "endpoint": self.endpoint_type.name.lower(),
            "extra_inputs": extra_inputs if extra_inputs else {},
        }

        headers = {
            "Content-Type": "application/json",
            "x-api-key": self.halsted_api_key
        }

        response = requests.post(
            self.sagemaker_endpoint_api,
            headers=headers,
            data=json.dumps(payload)
        )
        return response.json()
    

class SagemakerEndpointInputProcessor:
    """
    A class to process the input for the sagemaker endpoint.
    """

    def __init__(self, username: str, video_id: uuid.UUID, halsted_api_key: str, base_api: str = 'https://api.halstedhealth.ai'):
        self.s3_operator = S3Operator(username, halsted_api_key, base_api)

    def prepare(self, extra_inputs: dict) -> int:
        """
        Prepare the input for the sagemaker endpoint.

        Args:
            input (dict): The input dictionary.

        Returns:
            status_code (int): The status code of the response.
        """
        return self.s3_operator.upload_json_to_s3(extra_inputs=extra_inputs)