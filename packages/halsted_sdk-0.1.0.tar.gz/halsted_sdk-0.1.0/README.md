# Halsted SDK

A Python SDK for processing surgical videos using the Halsted Health API.

## Installation

```bash
pip install halsted-sdk
```

Or using Poetry:

```bash
poetry add halsted-sdk
```

## Quick Start

```python
from halsted_sdk import HalstedClient

# Initialize the client
client = HalstedClient(
    username='your_username',
    halsted_api_key='your_api_key'
)

# Process a video
df = client.process_video('/path/to/video.mp4')

# Work with the results DataFrame
print(df.head())
```

## Features

- Upload surgical videos to S3
- Process videos through SageMaker endpoints
- Retrieve and manage inference results
- Simple, Pythonic API

## API Reference

### HalstedClient

The main client class for interacting with the Halsted SDK.

#### Methods

- `process_video(filepath: str) -> pd.DataFrame`: Process a surgical video and return results as a DataFrame

## Requirements

- Python >= 3.12, < 3.15
- pandas >= 2.3.3
- tqdm >= 4.67.1

## License

See LICENSE.md

## Support

For any questions, please contact [Dani Kiyasseh](dani@halstedhealth.ai)

