from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.dynamic_tariff_get_dto import DynamicTariffGetDto
from ...models.longship_error import LongshipError
from ...models.organization_unit_patch_dto import OrganizationUnitPatchDto
from ...types import Response


def _get_kwargs(
    *,
    body: OrganizationUnitPatchDto,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v1/organizationalunits",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DynamicTariffGetDto | LongshipError | None:
    if response.status_code == 200:
        response_200 = DynamicTariffGetDto.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = LongshipError.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = LongshipError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = LongshipError.from_dict(response.json())

        return response_404

    if response.status_code == 500:
        response_500 = LongshipError.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DynamicTariffGetDto | LongshipError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: OrganizationUnitPatchDto,
) -> Response[DynamicTariffGetDto | LongshipError]:
    """Patches the OrganizationUnit.

     Patches the OrganizationUnit based on the id.

    Args:
        body (OrganizationUnitPatchDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DynamicTariffGetDto | LongshipError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: OrganizationUnitPatchDto,
) -> DynamicTariffGetDto | LongshipError | None:
    """Patches the OrganizationUnit.

     Patches the OrganizationUnit based on the id.

    Args:
        body (OrganizationUnitPatchDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DynamicTariffGetDto | LongshipError
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: OrganizationUnitPatchDto,
) -> Response[DynamicTariffGetDto | LongshipError]:
    """Patches the OrganizationUnit.

     Patches the OrganizationUnit based on the id.

    Args:
        body (OrganizationUnitPatchDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DynamicTariffGetDto | LongshipError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: OrganizationUnitPatchDto,
) -> DynamicTariffGetDto | LongshipError | None:
    """Patches the OrganizationUnit.

     Patches the OrganizationUnit based on the id.

    Args:
        body (OrganizationUnitPatchDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DynamicTariffGetDto | LongshipError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
