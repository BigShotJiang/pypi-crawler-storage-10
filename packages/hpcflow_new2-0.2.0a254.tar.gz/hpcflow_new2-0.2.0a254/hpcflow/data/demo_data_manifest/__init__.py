"""
Manifest for demonstration data.
"""
