"""
certs4mikrotik - Automated certificate management for MikroTik routers
"""

__version__ = "0.0.1"

from .cert2mikrotik import main

__all__ = ['main']
