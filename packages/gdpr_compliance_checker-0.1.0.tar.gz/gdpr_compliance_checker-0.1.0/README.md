# GDPR Compliance Checker

A Python package to analyze websites for GDPR (General Data Protection Regulation) compliance indicators.

## Installation
```bash
pip install gdpr-compliance-checker-dostogir
```

## Quick Start

### Command Line Usage
```bash
# Basic check
gdpr-check https://example.com

# Detailed analysis with HTML report
gdpr-check https://example.com --detailed --output report.html

# Batch processing
gdpr-check urls.txt --batch --output comparison.html
```

### Python API
```python
from gdpr_compliance_checker import GDPRChecker

# Initialize checker
checker = GDPRChecker()

# Analyze a website
result = checker.analyze_url("https://example.com")

# Display results
print(f"GDPR Score: {result.score}/100")
print(f"Grade: {result._get_grade()}")
print(f"Privacy Policy: {result.has_privacy_policy}")
print(f"Cookie Consent: {result.has_cookie_consent}")

# Generate reports
html_report = result.to_html()
json_report = result.to_json()
```

## Features

- Privacy Policy Detection
- Cookie Consent Analysis
- GDPR Compliance Scoring (0-100)
- Third-party Tracker Detection
- Data Rights Information Checking
- Multi-language Support
- Batch Processing for Multiple URLs
- Multiple Report Formats (HTML, JSON, CSV)

## Compliance Scoring

The tool evaluates websites based on:

- SSL/TLS Encryption (10 points)
- Privacy Policy (25 points)
- Cookie Consent (20 points)
- Data Subject Rights (20 points)
- Contact Information (10 points)
- Legal Basis (10 points)
- DPO Information (5 points)

## Advanced Usage

### Custom Compliance Rules
```python
from gdpr_compliance_checker import GDPRChecker, ComplianceRule

checker = GDPRChecker()

# Add custom rule
custom_rule = ComplianceRule(
    name="Custom Check",
    description="Check for specific requirements",
    keywords=["keyword1", "keyword2"],
    weight=10
)
checker.add_custom_rule(custom_rule)
```

### Batch Processing
```python
from gdpr_compliance_checker import BatchChecker

batch_checker = BatchChecker(max_workers=5)
results = batch_checker.check_urls(["site1.com", "site2.com"])
batch_checker.generate_comparison_report(results, "report.html")
```

## Disclaimer

This tool provides technical analysis only and should not be considered legal advice. For comprehensive GDPR compliance, consult with legal professionals.

## Author

Mohammad Golam Dostogir
- Website: https://dostogir.dev
- GitHub: https://github.com/dostogircse171
- PyPI: https://pypi.org/user/dostogircse171/

## License

MIT License