from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="gdpr-compliance-checker",  # Unique name with your identifier
    version="0.1.0",
    author="Mohammad Golam Dostogir",
    author_email="contact@dostogir.dev",
    description="A Python package to analyze websites for GDPR compliance indicators",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/dostogircse171/gdpr-compliance-checker",
    project_urls={
        "Bug Tracker": "https://github.com/dostogircse171/gdpr-compliance-checker/issues",
        "Documentation": "https://github.com/dostogircse171/gdpr-compliance-checker#readme",
        "Source Code": "https://github.com/dostogircse171/gdpr-compliance-checker",
        "Author Website": "https://dostogir.dev"
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Internet :: WWW/HTTP :: Site Management",
        "Topic :: Internet :: WWW/HTTP :: Dynamic Content :: Content Management System",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[
        "requests>=2.28.0",
        "beautifulsoup4>=4.11.0",
        "lxml>=4.9.0",
        "urllib3>=1.26.0",
        "selenium>=4.0.0",
        "webdriver-manager>=3.8.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=3.0.0",
            "black>=22.0.0",
            "flake8>=4.0.0",
        ]
    },
    entry_points={
        "console_scripts": [
            "gdpr-check=gdpr_compliance_checker.cli:main",
        ],
    },
    keywords="gdpr compliance privacy data-protection web-scraping django wagtail cms",
)
