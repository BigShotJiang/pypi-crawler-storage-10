"""
Batch processing functionality for checking multiple URLs.
"""

import concurrent.futures
import logging
from typing import List, Dict, Optional
from datetime import datetime
import json
import csv

from .checker import GDPRChecker
from .models import ComplianceResult, CheckerConfig
from .utils import generate_filename

logger = logging.getLogger(__name__)


class BatchChecker:
    """Handle batch processing of multiple URLs for GDPR compliance."""
    
    def __init__(self, config: Optional[CheckerConfig] = None, max_workers: int = 5):
        """
        Initialize the batch checker.
        
        Args:
            config: Configuration for the checker
            max_workers: Maximum number of concurrent workers
        """
        self.config = config or CheckerConfig()
        self.max_workers = max_workers
        
    def check_urls(self, urls: List[str], progress_callback=None) -> Dict[str, ComplianceResult]:
        """
        Check multiple URLs for GDPR compliance.
        
        Args:
            urls: List of URLs to check
            progress_callback: Optional callback function for progress updates
            
        Returns:
            Dictionary mapping URLs to ComplianceResult objects
        """
        results = {}
        total_urls = len(urls)
        completed = 0
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Submit all tasks
            future_to_url = {
                executor.submit(self._check_single_url, url): url 
                for url in urls
            }
            
            # Process completed tasks
            for future in concurrent.futures.as_completed(future_to_url):
                url = future_to_url[future]
                completed += 1
                
                try:
                    result = future.result()
                    results[url] = result
                    logger.info(f"Successfully checked {url} ({completed}/{total_urls})")
                    
                    if progress_callback:
                        progress_callback(completed, total_urls, url, result)
                        
                except Exception as e:
                    logger.error(f"Error checking {url}: {str(e)}")
                    results[url] = None
                    
                    if progress_callback:
                        progress_callback(completed, total_urls, url, None)
        
        return results
    
    def _check_single_url(self, url: str) -> ComplianceResult:
        """
        Check a single URL (internal method for threading).
        
        Args:
            url: URL to check
            
        Returns:
            ComplianceResult object
        """
        checker = GDPRChecker(config=self.config)
        return checker.analyze_url(url)
    
    def check_urls_from_file(self, filepath: str) -> Dict[str, ComplianceResult]:
        """
        Read URLs from a file and check them.
        
        Args:
            filepath: Path to file containing URLs (one per line)
            
        Returns:
            Dictionary mapping URLs to ComplianceResult objects
        """
        urls = []
        
        with open(filepath, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):  # Skip empty lines and comments
                    urls.append(line)
        
        logger.info(f"Loaded {len(urls)} URLs from {filepath}")
        return self.check_urls(urls)
    
    def generate_comparison_report(self, results: Dict[str, ComplianceResult], output_path: str):
        """
        Generate a comparison report for multiple URLs.
        
        Args:
            results: Dictionary of URL to ComplianceResult
            output_path: Path for the output report
        """
        if output_path.endswith('.html'):
            self._generate_html_comparison(results, output_path)
        elif output_path.endswith('.csv'):
            self._generate_csv_comparison(results, output_path)
        else:  # Default to JSON
            self._generate_json_comparison(results, output_path)
    
    def _generate_html_comparison(self, results: Dict[str, ComplianceResult], output_path: str):
        """Generate HTML comparison report."""
        html = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>GDPR Compliance Comparison Report</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
                h1 { color: #2c3e50; }
                table { width: 100%; border-collapse: collapse; background: white; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
                th { background: #3498db; color: white; padding: 12px; text-align: left; position: sticky; top: 0; }
                td { padding: 10px; border-bottom: 1px solid #ddd; }
                tr:hover { background: #f5f5f5; }
                .score { font-weight: bold; }
                .high { color: #27ae60; }
                .medium { color: #f39c12; }
                .low { color: #e74c3c; }
                .check { color: #27ae60; }
                .cross { color: #e74c3c; }
                .summary { background: white; padding: 20px; margin: 20px 0; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
                .chart { margin: 20px 0; }
            </style>
        </head>
        <body>
            <h1>GDPR Compliance Comparison Report</h1>
            <p>Generated: {timestamp}</p>
            
            <div class="summary">
                <h2>Summary Statistics</h2>
                <p>Total websites analyzed: {total}</p>
                <p>Average compliance score: {avg_score:.1f}/100</p>
                <p>Fully compliant (score ≥ 70): {compliant_count}</p>
                <p>Partially compliant (score 40-69): {partial_count}</p>
                <p>Non-compliant (score < 40): {non_compliant_count}</p>
            </div>
            
            <table>
                <tr>
                    <th>Website</th>
                    <th>Score</th>
                    <th>SSL</th>
                    <th>Privacy Policy</th>
                    <th>Cookie Consent</th>
                    <th>Data Rights</th>
                    <th>Contact Info</th>
                    <th>Legal Basis</th>
                    <th>DPO Info</th>
                    <th>Issues</th>
                </tr>
                {rows}
            </table>
            
            <div class="summary">
                <h2>Common Issues</h2>
                <ul>
                    {common_issues}
                </ul>
            </div>
        </body>
        </html>
        """
        
        # Calculate statistics
        valid_results = [r for r in results.values() if r is not None]
        total = len(valid_results)
        avg_score = sum(r.score for r in valid_results) / total if total > 0 else 0
        compliant_count = sum(1 for r in valid_results if r.score >= 70)
        partial_count = sum(1 for r in valid_results if 40 <= r.score < 70)
        non_compliant_count = sum(1 for r in valid_results if r.score < 40)
        
        # Generate table rows
        rows = []
        for url, result in results.items():
            if result is None:
                rows.append(f"""
                <tr>
                    <td>{url}</td>
                    <td colspan="9">Error checking URL</td>
                </tr>
                """)
            else:
                score_class = 'high' if result.score >= 70 else 'medium' if result.score >= 40 else 'low'
                rows.append(f"""
                <tr>
                    <td>{url}</td>
                    <td class="score {score_class}">{result.score}/100</td>
                    <td class="{'check' if result.has_ssl else 'cross'}">{'✓' if result.has_ssl else '✗'}</td>
                    <td class="{'check' if result.has_privacy_policy else 'cross'}">{'✓' if result.has_privacy_policy else '✗'}</td>
                    <td class="{'check' if result.has_cookie_consent else 'cross'}">{'✓' if result.has_cookie_consent else '✗'}</td>
                    <td class="{'check' if result.has_data_rights else 'cross'}">{'✓' if result.has_data_rights else '✗'}</td>
                    <td class="{'check' if result.has_contact_info else 'cross'}">{'✓' if result.has_contact_info else '✗'}</td>
                    <td class="{'check' if result.has_legal_basis else 'cross'}">{'✓' if result.has_legal_basis else '✗'}</td>
                    <td class="{'check' if result.has_dpo_info else 'cross'}">{'✓' if result.has_dpo_info else '✗'}</td>
                    <td>{len(result.issues)}</td>
                </tr>
                """)
        
        # Find common issues
        all_issues = []
        for result in valid_results:
            all_issues.extend(result.issues)
        
        issue_counts = {}
        for issue in all_issues:
            issue_counts[issue] = issue_counts.get(issue, 0) + 1
        
        common_issues = []
        for issue, count in sorted(issue_counts.items(), key=lambda x: x[1], reverse=True)[:5]:
            common_issues.append(f"<li>{issue} ({count} websites)</li>")
        
        # Fill template
        html_filled = html.format(
            timestamp=datetime.now().isoformat(),
            total=total,
            avg_score=avg_score,
            compliant_count=compliant_count,
            partial_count=partial_count,
            non_compliant_count=non_compliant_count,
            rows=''.join(rows),
            common_issues=''.join(common_issues) if common_issues else '<li>No common issues found</li>'
        )
        
        with open(output_path, 'w') as f:
            f.write(html_filled)
        
        logger.info(f"HTML comparison report saved to {output_path}")
    
    def _generate_csv_comparison(self, results: Dict[str, ComplianceResult], output_path: str):
        """Generate CSV comparison report."""
        with open(output_path, 'w', newline='') as csvfile:
            fieldnames = [
                'URL', 'Score', 'Grade', 'SSL', 'Privacy Policy', 'Cookie Consent',
                'Data Rights', 'Contact Info', 'Legal Basis', 'DPO Info',
                'Trackers Count', 'Issues Count', 'Timestamp'
            ]
            
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            
            for url, result in results.items():
                if result is None:
                    writer.writerow({'URL': url, 'Score': 'ERROR'})
                else:
                    writer.writerow({
                        'URL': url,
                        'Score': result.score,
                        'Grade': result._get_grade(),
                        'SSL': 'Yes' if result.has_ssl else 'No',
                        'Privacy Policy': 'Yes' if result.has_privacy_policy else 'No',
                        'Cookie Consent': 'Yes' if result.has_cookie_consent else 'No',
                        'Data Rights': 'Yes' if result.has_data_rights else 'No',
                        'Contact Info': 'Yes' if result.has_contact_info else 'No',
                        'Legal Basis': 'Yes' if result.has_legal_basis else 'No',
                        'DPO Info': 'Yes' if result.has_dpo_info else 'No',
                        'Trackers Count': len(result.trackers_found),
                        'Issues Count': len(result.issues),
                        'Timestamp': result.timestamp
                    })
        
        logger.info(f"CSV comparison report saved to {output_path}")
    
    def _generate_json_comparison(self, results: Dict[str, ComplianceResult], output_path: str):
        """Generate JSON comparison report."""
        report = {
            'metadata': {
                'generated': datetime.now().isoformat(),
                'total_urls': len(results),
                'successful_checks': sum(1 for r in results.values() if r is not None)
            },
            'results': {}
        }
        
        for url, result in results.items():
            if result is None:
                report['results'][url] = {'error': 'Failed to analyze'}
            else:
                report['results'][url] = result.get_detailed_report()
        
        with open(output_path, 'w') as f:
            json.dump(report, f, indent=2)
        
        logger.info(f"JSON comparison report saved to {output_path}")
