"""
Custom exceptions for the GDPR compliance checker.
"""


class GDPRCheckerException(Exception):
    """Base exception for GDPR Checker."""
    pass


class InvalidURLException(GDPRCheckerException):
    """Raised when an invalid URL is provided."""
    pass


class AnalysisException(GDPRCheckerException):
    """Raised when analysis fails."""
    pass


class ConfigurationException(GDPRCheckerException):
    """Raised when configuration is invalid."""
    pass


class NetworkException(GDPRCheckerException):
    """Raised when network-related errors occur."""
    pass


class ParsingException(GDPRCheckerException):
    """Raised when HTML parsing fails."""
    pass


class SeleniumException(GDPRCheckerException):
    """Raised when Selenium WebDriver encounters issues."""
    pass


class TimeoutException(GDPRCheckerException):
    """Raised when operation times out."""
    pass
