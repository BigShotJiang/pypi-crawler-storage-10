"""
Data models for the GDPR compliance checker.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
import json
from datetime import datetime


@dataclass
class CheckerConfig:
    """Configuration for the GDPR Checker."""
    timeout: int = 30
    use_selenium: bool = False
    headless: bool = True
    check_third_party: bool = True
    language: str = "en"
    strict_mode: bool = False
    max_depth: int = 2  # How many links deep to follow for privacy policy
    

@dataclass
class ComplianceRule:
    """Custom compliance rule definition."""
    name: str
    description: str
    keywords: List[str]
    weight: int = 5
    category: str = "custom"


@dataclass
class ComplianceResult:
    """Result of GDPR compliance analysis."""
    url: str
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    score: int = 0
    
    # Main compliance indicators
    has_ssl: bool = False
    has_privacy_policy: bool = False
    has_cookie_consent: bool = False
    has_data_rights: bool = False
    has_contact_info: bool = False
    has_legal_basis: bool = False
    has_dpo_info: bool = False
    
    # Detailed information
    privacy_policy_url: Optional[str] = None
    cookie_consent_details: Dict = field(default_factory=dict)
    data_rights_details: Dict = field(default_factory=dict)
    contact_details: Dict = field(default_factory=dict)
    legal_basis_details: Dict = field(default_factory=dict)
    dpo_details: Dict = field(default_factory=dict)
    
    # Additional findings
    trackers_found: List[str] = field(default_factory=list)
    custom_rules_passed: List[str] = field(default_factory=list)
    issues: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    
    def calculate_score(self) -> None:
        """Calculate the overall compliance score."""
        score = 0
        
        # SSL/TLS (10 points)
        if self.has_ssl:
            score += 10
        
        # Privacy Policy (25 points)
        if self.has_privacy_policy:
            score += 25
        
        # Cookie Consent (20 points)
        if self.has_cookie_consent:
            score += 10
            if self.cookie_consent_details.get('granular_control'):
                score += 5
            if self.cookie_consent_details.get('reject_option'):
                score += 5
        
        # Data Rights (20 points)
        if self.has_data_rights:
            rights_count = sum(1 for v in self.data_rights_details.values() if v)
            score += min(20, rights_count * 4)
        
        # Contact Information (10 points)
        if self.has_contact_info:
            score += 5
            if self.contact_details.get('privacy_email'):
                score += 5
        
        # Legal Basis (10 points)
        if self.has_legal_basis:
            score += 10
        
        # DPO Information (5 points)
        if self.has_dpo_info:
            score += 5
        
        # Custom rules (variable points)
        score += len(self.custom_rules_passed) * 2
        
        # Cap at 100
        self.score = min(100, score)
    
    def generate_issues_and_recommendations(self) -> None:
        """Generate list of compliance issues and recommendations."""
        self.issues = []
        self.recommendations = []
        
        if not self.has_ssl:
            self.issues.append("Website does not use HTTPS encryption")
            self.recommendations.append("Implement SSL/TLS certificate for secure data transmission")
        
        if not self.has_privacy_policy:
            self.issues.append("No privacy policy found")
            self.recommendations.append("Create and prominently display a comprehensive privacy policy")
        
        if not self.has_cookie_consent:
            self.issues.append("No cookie consent mechanism detected")
            self.recommendations.append("Implement a cookie consent banner with granular controls")
        elif not self.cookie_consent_details.get('reject_option'):
            self.issues.append("Cookie consent lacks clear reject option")
            self.recommendations.append("Add a clear 'Reject All' option to cookie consent")
        
        if not self.has_data_rights:
            self.issues.append("User data rights not clearly stated")
            self.recommendations.append("Document all GDPR data subject rights (access, rectification, erasure, portability, objection)")
        
        if not self.has_contact_info:
            self.issues.append("No clear contact information for data protection inquiries")
            self.recommendations.append("Provide dedicated contact information for privacy/data protection matters")
        
        if not self.has_legal_basis:
            self.issues.append("Legal basis for data processing not declared")
            self.recommendations.append("Clearly state the legal basis for each data processing activity")
        
        if not self.has_dpo_info:
            self.issues.append("No Data Protection Officer information found")
            self.recommendations.append("If required, appoint and publish DPO contact details")
        
        if len(self.trackers_found) > 5:
            self.issues.append(f"Multiple third-party trackers detected ({len(self.trackers_found)})")
            self.recommendations.append("Review and minimize third-party tracking; ensure all trackers have consent")
    
    def get_detailed_report(self) -> Dict[str, Any]:
        """Get a detailed report of the compliance analysis."""
        return {
            "summary": {
                "url": self.url,
                "timestamp": self.timestamp,
                "score": self.score,
                "grade": self._get_grade(),
                "compliant": self.score >= 70
            },
            "main_indicators": {
                "ssl_encryption": self.has_ssl,
                "privacy_policy": self.has_privacy_policy,
                "cookie_consent": self.has_cookie_consent,
                "data_rights": self.has_data_rights,
                "contact_info": self.has_contact_info,
                "legal_basis": self.has_legal_basis,
                "dpo_info": self.has_dpo_info
            },
            "details": {
                "privacy_policy_url": self.privacy_policy_url,
                "cookie_consent": self.cookie_consent_details,
                "data_rights": self.data_rights_details,
                "contact": self.contact_details,
                "legal_basis": self.legal_basis_details,
                "dpo": self.dpo_details
            },
            "trackers": self.trackers_found,
            "custom_rules_passed": self.custom_rules_passed,
            "issues": self.issues,
            "recommendations": self.recommendations
        }
    
    def _get_grade(self) -> str:
        """Convert score to letter grade."""
        if self.score >= 90:
            return "A"
        elif self.score >= 80:
            return "B"
        elif self.score >= 70:
            return "C"
        elif self.score >= 60:
            return "D"
        else:
            return "F"
    
    def to_json(self) -> str:
        """Export the result as JSON."""
        return json.dumps(self.get_detailed_report(), indent=2)
    
    def to_html(self) -> str:
        """Generate an HTML report."""
        report = self.get_detailed_report()
        
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>GDPR Compliance Report - {self.url}</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }}
                .container {{ background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
                h1 {{ color: #2c3e50; }}
                h2 {{ color: #34495e; border-bottom: 2px solid #3498db; padding-bottom: 10px; }}
                .score {{ font-size: 48px; font-weight: bold; color: {self._get_score_color()}; }}
                .grade {{ font-size: 36px; font-weight: bold; margin-left: 20px; }}
                .indicator {{ padding: 10px; margin: 5px 0; border-left: 4px solid; }}
                .indicator.pass {{ border-color: #27ae60; background: #d4edda; }}
                .indicator.fail {{ border-color: #e74c3c; background: #f8d7da; }}
                .issues {{ background: #fff3cd; padding: 15px; border-radius: 5px; margin: 10px 0; }}
                .recommendations {{ background: #d1ecf1; padding: 15px; border-radius: 5px; margin: 10px 0; }}
                ul {{ line-height: 1.8; }}
                .footer {{ margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; color: #666; font-size: 0.9em; }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>GDPR Compliance Report</h1>
                <p><strong>URL:</strong> {self.url}</p>
                <p><strong>Analyzed:</strong> {self.timestamp}</p>
                
                <div style="margin: 30px 0;">
                    <span class="score">{self.score}/100</span>
                    <span class="grade">Grade: {report['summary']['grade']}</span>
                </div>
                
                <h2>Compliance Indicators</h2>
                <div class="indicator {'pass' if self.has_ssl else 'fail'}">
                    SSL/TLS Encryption: {'✓' if self.has_ssl else '✗'}
                </div>
                <div class="indicator {'pass' if self.has_privacy_policy else 'fail'}">
                    Privacy Policy: {'✓' if self.has_privacy_policy else '✗'}
                    {f' - <a href="{self.privacy_policy_url}">{self.privacy_policy_url}</a>' if self.privacy_policy_url else ''}
                </div>
                <div class="indicator {'pass' if self.has_cookie_consent else 'fail'}">
                    Cookie Consent: {'✓' if self.has_cookie_consent else '✗'}
                </div>
                <div class="indicator {'pass' if self.has_data_rights else 'fail'}">
                    Data Rights Information: {'✓' if self.has_data_rights else '✗'}
                </div>
                <div class="indicator {'pass' if self.has_contact_info else 'fail'}">
                    Contact Information: {'✓' if self.has_contact_info else '✗'}
                </div>
                <div class="indicator {'pass' if self.has_legal_basis else 'fail'}">
                    Legal Basis Declaration: {'✓' if self.has_legal_basis else '✗'}
                </div>
                <div class="indicator {'pass' if self.has_dpo_info else 'fail'}">
                    DPO Information: {'✓' if self.has_dpo_info else '✗'}
                </div>
                
                {self._generate_issues_html()}
                {self._generate_recommendations_html()}
                {self._generate_trackers_html()}
                
                <div class="footer">
                    <p>This report provides a technical assessment of GDPR compliance indicators. 
                    It should not be considered as legal advice. For comprehensive GDPR compliance, 
                    consult with legal professionals.</p>
                </div>
            </div>
        </body>
        </html>
        """
        return html
    
    def _get_score_color(self) -> str:
        """Get color based on score."""
        if self.score >= 80:
            return "#27ae60"
        elif self.score >= 60:
            return "#f39c12"
        else:
            return "#e74c3c"
    
    def _generate_issues_html(self) -> str:
        """Generate HTML for issues section."""
        if not self.issues:
            return ""
        
        issues_list = "".join(f"<li>{issue}</li>" for issue in self.issues)
        return f"""
        <div class="issues">
            <h3>⚠️ Issues Found</h3>
            <ul>{issues_list}</ul>
        </div>
        """
    
    def _generate_recommendations_html(self) -> str:
        """Generate HTML for recommendations section."""
        if not self.recommendations:
            return ""
        
        rec_list = "".join(f"<li>{rec}</li>" for rec in self.recommendations)
        return f"""
        <div class="recommendations">
            <h3>💡 Recommendations</h3>
            <ul>{rec_list}</ul>
        </div>
        """
    
    def _generate_trackers_html(self) -> str:
        """Generate HTML for trackers section."""
        if not self.trackers_found:
            return ""
        
        trackers_list = "".join(f"<li>{tracker}</li>" for tracker in self.trackers_found)
        return f"""
        <h2>Third-Party Trackers</h2>
        <p>Found {len(self.trackers_found)} third-party tracking services:</p>
        <ul>{trackers_list}</ul>
        """
