"""
Main GDPR compliance checker module.
"""

import re
import json
import logging
from typing import Dict, List, Optional, Tuple
from urllib.parse import urljoin, urlparse
import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

from .models import ComplianceResult, CheckerConfig, ComplianceRule
from .exceptions import InvalidURLException, AnalysisException
from .patterns import GDPR_PATTERNS, TRACKER_PATTERNS
from .utils import normalize_url, extract_text_content, detect_language

logger = logging.getLogger(__name__)


class GDPRChecker:
    """Main class for analyzing GDPR compliance of websites."""
    
    def __init__(self, config: Optional[CheckerConfig] = None):
        """
        Initialize the GDPR Checker.
        
        Args:
            config: Optional configuration object
        """
        self.config = config or CheckerConfig()
        self.custom_rules: List[ComplianceRule] = []
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        if self.config.use_selenium:
            self._setup_selenium()
    
    def _setup_selenium(self):
        """Setup Selenium WebDriver for JavaScript-rendered content."""
        chrome_options = Options()
        if self.config.headless:
            chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        
        try:
            self.driver = webdriver.Chrome(
                ChromeDriverManager().install(),
                options=chrome_options
            )
        except Exception as e:
            logger.warning(f"Could not initialize Selenium: {e}")
            self.config.use_selenium = False
    
    def analyze_url(self, url: str) -> ComplianceResult:
        """
        Analyze a URL for GDPR compliance.
        
        Args:
            url: The URL to analyze
            
        Returns:
            ComplianceResult object containing the analysis
        """
        # Normalize and validate URL
        url = normalize_url(url)
        if not self._validate_url(url):
            raise InvalidURLException(f"Invalid URL: {url}")
        
        try:
            # Fetch the page content
            if self.config.use_selenium:
                content, page_source = self._fetch_with_selenium(url)
            else:
                content, page_source = self._fetch_with_requests(url)
            
            # Parse the HTML
            soup = BeautifulSoup(page_source, 'lxml')
            
            # Run compliance checks
            result = ComplianceResult(url=url)
            
            # 1. Check for SSL/TLS
            result.has_ssl = url.startswith('https://')
            
            # 2. Check for privacy policy
            privacy_check = self._check_privacy_policy(soup, url)
            result.has_privacy_policy = privacy_check[0]
            result.privacy_policy_url = privacy_check[1]
            
            # 3. Check for cookie consent
            cookie_check = self._check_cookie_consent(soup, page_source)
            result.has_cookie_consent = cookie_check[0]
            result.cookie_consent_details = cookie_check[1]
            
            # 4. Check for data rights information
            rights_check = self._check_data_rights(soup, page_source)
            result.has_data_rights = rights_check[0]
            result.data_rights_details = rights_check[1]
            
            # 5. Check for contact information
            contact_check = self._check_contact_info(soup, page_source)
            result.has_contact_info = contact_check[0]
            result.contact_details = contact_check[1]
            
            # 6. Check for third-party trackers
            if self.config.check_third_party:
                trackers = self._check_trackers(soup, page_source)
                result.trackers_found = trackers
            
            # 7. Check for legal basis
            legal_check = self._check_legal_basis(soup, page_source)
            result.has_legal_basis = legal_check[0]
            result.legal_basis_details = legal_check[1]
            
            # 8. Check for DPO information
            dpo_check = self._check_dpo_info(soup, page_source)
            result.has_dpo_info = dpo_check[0]
            result.dpo_details = dpo_check[1]
            
            # 9. Run custom rules
            for rule in self.custom_rules:
                if self._check_custom_rule(rule, page_source):
                    result.custom_rules_passed.append(rule.name)
            
            # Calculate compliance score
            result.calculate_score()
            
            # Generate issues and recommendations
            result.generate_issues_and_recommendations()
            
            return result
            
        except Exception as e:
            raise AnalysisException(f"Error analyzing {url}: {str(e)}")
        finally:
            if self.config.use_selenium and hasattr(self, 'driver'):
                self.driver.quit()
    
    def analyze_request(self, response: requests.Response) -> ComplianceResult:
        """
        Analyze a requests Response object for GDPR compliance.
        
        Args:
            response: The requests Response object
            
        Returns:
            ComplianceResult object containing the analysis
        """
        url = response.url
        page_source = response.text
        
        # Parse the HTML
        soup = BeautifulSoup(page_source, 'lxml')
        
        # Run the same compliance checks as analyze_url
        result = ComplianceResult(url=url)
        
        # Run all checks (similar to analyze_url but using the provided response)
        result.has_ssl = url.startswith('https://')
        
        privacy_check = self._check_privacy_policy(soup, url)
        result.has_privacy_policy = privacy_check[0]
        result.privacy_policy_url = privacy_check[1]
        
        cookie_check = self._check_cookie_consent(soup, page_source)
        result.has_cookie_consent = cookie_check[0]
        result.cookie_consent_details = cookie_check[1]
        
        rights_check = self._check_data_rights(soup, page_source)
        result.has_data_rights = rights_check[0]
        result.data_rights_details = rights_check[1]
        
        contact_check = self._check_contact_info(soup, page_source)
        result.has_contact_info = contact_check[0]
        result.contact_details = contact_check[1]
        
        if self.config.check_third_party:
            trackers = self._check_trackers(soup, page_source)
            result.trackers_found = trackers
        
        legal_check = self._check_legal_basis(soup, page_source)
        result.has_legal_basis = legal_check[0]
        result.legal_basis_details = legal_check[1]
        
        dpo_check = self._check_dpo_info(soup, page_source)
        result.has_dpo_info = dpo_check[0]
        result.dpo_details = dpo_check[1]
        
        for rule in self.custom_rules:
            if self._check_custom_rule(rule, page_source):
                result.custom_rules_passed.append(rule.name)
        
        result.calculate_score()
        result.generate_issues_and_recommendations()
        
        return result
    
    def _validate_url(self, url: str) -> bool:
        """Validate if the URL is properly formatted."""
        try:
            parsed = urlparse(url)
            return bool(parsed.netloc) and bool(parsed.scheme)
        except:
            return False
    
    def _fetch_with_requests(self, url: str) -> Tuple[str, str]:
        """Fetch page content using requests library."""
        response = self.session.get(url, timeout=self.config.timeout)
        response.raise_for_status()
        return response.text, response.text
    
    def _fetch_with_selenium(self, url: str) -> Tuple[str, str]:
        """Fetch page content using Selenium for JavaScript rendering."""
        self.driver.get(url)
        
        # Wait for potential cookie banners to load
        try:
            WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
        except:
            pass
        
        page_source = self.driver.page_source
        return page_source, page_source
    
    def _check_privacy_policy(self, soup: BeautifulSoup, base_url: str) -> Tuple[bool, Optional[str]]:
        """Check for privacy policy presence and accessibility."""
        privacy_keywords = GDPR_PATTERNS['privacy_policy']
        
        # Look for privacy policy links
        for link in soup.find_all('a', href=True):
            link_text = link.get_text().lower().strip()
            href = link['href'].lower()
            
            for keyword in privacy_keywords:
                if keyword in link_text or keyword in href:
                    full_url = urljoin(base_url, link['href'])
                    return True, full_url
        
        # Check meta tags
        meta_tags = soup.find_all('meta')
        for tag in meta_tags:
            if tag.get('name', '').lower() in ['privacy', 'privacy-policy']:
                return True, None
        
        return False, None
    
    def _check_cookie_consent(self, soup: BeautifulSoup, page_source: str) -> Tuple[bool, Dict]:
        """Check for cookie consent mechanisms."""
        consent_keywords = GDPR_PATTERNS['cookie_consent']
        details = {
            'banner_found': False,
            'granular_control': False,
            'reject_option': False
        }
        
        # Check for common cookie consent elements
        page_lower = page_source.lower()
        
        for keyword in consent_keywords:
            if keyword in page_lower:
                details['banner_found'] = True
                break
        
        # Look for consent management platforms
        cmp_indicators = ['cookiebot', 'onetrust', 'trustarc', 'cookieyes', 'termly']
        for cmp in cmp_indicators:
            if cmp in page_lower:
                details['banner_found'] = True
                details['cmp_detected'] = cmp
                break
        
        # Check for granular control options
        if 'necessary' in page_lower and 'functional' in page_lower:
            details['granular_control'] = True
        
        # Check for reject option
        if 'reject all' in page_lower or 'decline all' in page_lower:
            details['reject_option'] = True
        
        return details['banner_found'], details
    
    def _check_data_rights(self, soup: BeautifulSoup, page_source: str) -> Tuple[bool, Dict]:
        """Check for information about user data rights."""
        rights_keywords = GDPR_PATTERNS['data_rights']
        details = {
            'access': False,
            'rectification': False,
            'erasure': False,
            'portability': False,
            'object': False
        }
        
        page_lower = page_source.lower()
        
        # Check for each specific right
        if 'right to access' in page_lower or 'access your data' in page_lower:
            details['access'] = True
        
        if 'right to rectification' in page_lower or 'correct your data' in page_lower:
            details['rectification'] = True
        
        if 'right to erasure' in page_lower or 'right to be forgotten' in page_lower or 'delete your data' in page_lower:
            details['erasure'] = True
        
        if 'data portability' in page_lower or 'export your data' in page_lower:
            details['portability'] = True
        
        if 'right to object' in page_lower or 'opt-out' in page_lower:
            details['object'] = True
        
        # Check if any rights are mentioned
        has_rights = any(details.values())
        
        return has_rights, details
    
    def _check_contact_info(self, soup: BeautifulSoup, page_source: str) -> Tuple[bool, Dict]:
        """Check for data controller contact information."""
        details = {
            'email_found': False,
            'address_found': False,
            'phone_found': False
        }
        
        # Look for email addresses
        email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        emails = re.findall(email_pattern, page_source)
        if emails:
            details['email_found'] = True
            # Look specifically for privacy/DPO emails
            for email in emails:
                if 'privacy' in email.lower() or 'dpo' in email.lower() or 'protection' in email.lower():
                    details['privacy_email'] = email
                    break
        
        # Look for physical address patterns
        address_indicators = ['street', 'avenue', 'road', 'boulevard', 'registered office']
        page_lower = page_source.lower()
        for indicator in address_indicators:
            if indicator in page_lower:
                details['address_found'] = True
                break
        
        # Look for phone numbers
        phone_pattern = r'[\+]?[(]?[0-9]{1,4}[)]?[-\s\.]?[(]?[0-9]{1,4}[)]?[-\s\.]?[0-9]{1,4}[-\s\.]?[0-9]{1,4}'
        phones = re.findall(phone_pattern, page_source)
        if len(phones) > 0:
            details['phone_found'] = True
        
        has_contact = details['email_found'] or details['address_found']
        
        return has_contact, details
    
    def _check_trackers(self, soup: BeautifulSoup, page_source: str) -> List[str]:
        """Check for third-party tracking scripts."""
        trackers_found = []
        
        # Check scripts
        scripts = soup.find_all('script', src=True)
        for script in scripts:
            src = script['src'].lower()
            for tracker, pattern in TRACKER_PATTERNS.items():
                if pattern in src:
                    if tracker not in trackers_found:
                        trackers_found.append(tracker)
        
        # Check for tracking pixels
        imgs = soup.find_all('img', src=True)
        for img in imgs:
            src = img['src'].lower()
            if 'pixel' in src or 'track' in src or '1x1' in src:
                trackers_found.append('tracking_pixel')
                break
        
        return trackers_found
    
    def _check_legal_basis(self, soup: BeautifulSoup, page_source: str) -> Tuple[bool, Dict]:
        """Check for legal basis declarations."""
        legal_keywords = GDPR_PATTERNS['legal_basis']
        details = {
            'consent': False,
            'contract': False,
            'legal_obligation': False,
            'vital_interests': False,
            'public_task': False,
            'legitimate_interests': False
        }
        
        page_lower = page_source.lower()
        
        for keyword in legal_keywords:
            if keyword in page_lower:
                if 'consent' in keyword:
                    details['consent'] = True
                elif 'contract' in keyword:
                    details['contract'] = True
                elif 'legal obligation' in keyword:
                    details['legal_obligation'] = True
                elif 'vital' in keyword:
                    details['vital_interests'] = True
                elif 'public' in keyword:
                    details['public_task'] = True
                elif 'legitimate' in keyword:
                    details['legitimate_interests'] = True
        
        has_legal_basis = any(details.values())
        
        return has_legal_basis, details
    
    def _check_dpo_info(self, soup: BeautifulSoup, page_source: str) -> Tuple[bool, Dict]:
        """Check for Data Protection Officer information."""
        dpo_keywords = ['data protection officer', 'dpo', 'privacy officer']
        details = {
            'dpo_mentioned': False,
            'dpo_contact': None
        }
        
        page_lower = page_source.lower()
        
        for keyword in dpo_keywords:
            if keyword in page_lower:
                details['dpo_mentioned'] = True
                
                # Try to find DPO email
                pattern = f"{keyword}.*?([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{{2,}})"
                match = re.search(pattern, page_lower)
                if match:
                    details['dpo_contact'] = match.group(1)
                break
        
        return details['dpo_mentioned'], details
    
    def _check_custom_rule(self, rule: ComplianceRule, page_source: str) -> bool:
        """Check a custom compliance rule."""
        page_lower = page_source.lower()
        
        for keyword in rule.keywords:
            if keyword.lower() in page_lower:
                return True
        
        return False
    
    def add_custom_rule(self, rule: ComplianceRule):
        """Add a custom compliance rule."""
        self.custom_rules.append(rule)
    
    def set_config(self, config: CheckerConfig):
        """Update the configuration."""
        self.config = config
        if config.use_selenium:
            self._setup_selenium()
