"""
Utility functions for the GDPR compliance checker.
"""

import re
from urllib.parse import urlparse, urlunparse
from typing import Optional, List, Tuple
from bs4 import BeautifulSoup, NavigableString
import hashlib
import json


def normalize_url(url: str) -> str:
    """
    Normalize a URL to ensure consistency.
    
    Args:
        url: The URL to normalize
        
    Returns:
        Normalized URL string
    """
    # Add scheme if missing
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url
    
    # Parse the URL
    parsed = urlparse(url)
    
    # Reconstruct with lowercase domain
    normalized = urlunparse((
        parsed.scheme,
        parsed.netloc.lower(),
        parsed.path.rstrip('/'),
        parsed.params,
        parsed.query,
        ''  # Remove fragment
    ))
    
    return normalized


def extract_text_content(soup: BeautifulSoup) -> str:
    """
    Extract clean text content from BeautifulSoup object.
    
    Args:
        soup: BeautifulSoup object
        
    Returns:
        Extracted text content
    """
    # Remove script and style elements
    for script in soup(['script', 'style']):
        script.decompose()
    
    # Get text
    text = soup.get_text()
    
    # Clean up whitespace
    lines = (line.strip() for line in text.splitlines())
    chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
    text = ' '.join(chunk for chunk in chunks if chunk)
    
    return text


def detect_language(text: str) -> str:
    """
    Detect the language of the text (basic implementation).
    
    Args:
        text: Text to analyze
        
    Returns:
        Language code (e.g., 'en', 'de', 'fr')
    """
    # Simple language detection based on common words
    language_indicators = {
        'en': ['the', 'and', 'of', 'to', 'in', 'is', 'that', 'for', 'with', 'on'],
        'de': ['der', 'die', 'das', 'und', 'ist', 'von', 'mit', 'für', 'auf', 'den'],
        'fr': ['le', 'de', 'et', 'la', 'les', 'pour', 'dans', 'une', 'par', 'sur'],
        'es': ['el', 'la', 'de', 'y', 'en', 'los', 'las', 'por', 'con', 'para'],
        'it': ['il', 'di', 'e', 'la', 'che', 'per', 'in', 'un', 'con', 'da'],
        'nl': ['de', 'het', 'en', 'van', 'een', 'in', 'is', 'op', 'aan', 'met']
    }
    
    text_lower = text.lower()
    text_words = text_lower.split()
    
    scores = {}
    for lang, words in language_indicators.items():
        score = sum(1 for word in words if word in text_words)
        scores[lang] = score
    
    if scores:
        return max(scores, key=scores.get)
    return 'en'  # Default to English


def extract_domain(url: str) -> str:
    """
    Extract the domain from a URL.
    
    Args:
        url: The URL to extract domain from
        
    Returns:
        Domain string
    """
    parsed = urlparse(url)
    return parsed.netloc.lower()


def find_privacy_links(soup: BeautifulSoup) -> List[Tuple[str, str]]:
    """
    Find all privacy-related links in the page.
    
    Args:
        soup: BeautifulSoup object
        
    Returns:
        List of tuples (link_text, href)
    """
    privacy_keywords = [
        'privacy', 'datenschutz', 'confidentialité', 'privacidad', 
        'riservatezza', 'privacybeleid', 'data protection', 'gdpr'
    ]
    
    privacy_links = []
    
    for link in soup.find_all('a', href=True):
        link_text = link.get_text().lower().strip()
        href = link['href'].lower()
        
        for keyword in privacy_keywords:
            if keyword in link_text or keyword in href:
                privacy_links.append((link.get_text().strip(), link['href']))
                break
    
    return privacy_links


def calculate_text_similarity(text1: str, text2: str) -> float:
    """
    Calculate similarity between two texts (basic implementation).
    
    Args:
        text1: First text
        text2: Second text
        
    Returns:
        Similarity score between 0 and 1
    """
    # Convert to lowercase and split into words
    words1 = set(text1.lower().split())
    words2 = set(text2.lower().split())
    
    # Calculate Jaccard similarity
    intersection = words1.intersection(words2)
    union = words1.union(words2)
    
    if not union:
        return 0.0
    
    return len(intersection) / len(union)


def is_valid_email(email: str) -> bool:
    """
    Check if a string is a valid email address.
    
    Args:
        email: String to check
        
    Returns:
        True if valid email, False otherwise
    """
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(email_pattern, email))


def extract_emails(text: str) -> List[str]:
    """
    Extract all email addresses from text.
    
    Args:
        text: Text to search
        
    Returns:
        List of email addresses found
    """
    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
    emails = re.findall(email_pattern, text)
    return [email for email in emails if is_valid_email(email)]


def extract_phone_numbers(text: str) -> List[str]:
    """
    Extract phone numbers from text.
    
    Args:
        text: Text to search
        
    Returns:
        List of phone numbers found
    """
    # Basic pattern for international phone numbers
    phone_patterns = [
        r'[\+]?[(]?[0-9]{1,4}[)]?[-\s\.]?[(]?[0-9]{1,4}[)]?[-\s\.]?[0-9]{1,4}[-\s\.]?[0-9]{1,4}',
        r'[\+][0-9]{1,3}[-\s][0-9]{1,14}',
        r'[(][0-9]{1,4}[)][-\s]?[0-9]{1,4}[-\s]?[0-9]{1,4}'
    ]
    
    phone_numbers = []
    for pattern in phone_patterns:
        matches = re.findall(pattern, text)
        phone_numbers.extend(matches)
    
    # Remove duplicates and filter out too short numbers
    phone_numbers = list(set(num for num in phone_numbers if len(re.sub(r'[^\d]', '', num)) >= 7))
    
    return phone_numbers


def hash_url(url: str) -> str:
    """
    Generate a hash for a URL (useful for caching).
    
    Args:
        url: URL to hash
        
    Returns:
        Hash string
    """
    return hashlib.sha256(url.encode()).hexdigest()[:16]


def format_file_size(size_bytes: int) -> str:
    """
    Format file size in human-readable format.
    
    Args:
        size_bytes: Size in bytes
        
    Returns:
        Formatted string
    """
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.2f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.2f} TB"


def clean_html(html_content: str) -> str:
    """
    Clean HTML content for analysis.
    
    Args:
        html_content: Raw HTML content
        
    Returns:
        Cleaned HTML string
    """
    # Remove comments
    html_content = re.sub(r'<!--.*?-->', '', html_content, flags=re.DOTALL)
    
    # Remove excessive whitespace
    html_content = re.sub(r'\s+', ' ', html_content)
    
    return html_content


def extract_meta_tags(soup: BeautifulSoup) -> dict:
    """
    Extract meta tags from HTML.
    
    Args:
        soup: BeautifulSoup object
        
    Returns:
        Dictionary of meta tags
    """
    meta_tags = {}
    
    for tag in soup.find_all('meta'):
        if tag.get('name'):
            meta_tags[tag.get('name')] = tag.get('content', '')
        elif tag.get('property'):
            meta_tags[tag.get('property')] = tag.get('content', '')
    
    return meta_tags


def is_cookie_domain(domain: str) -> bool:
    """
    Check if a domain is commonly used for cookies/tracking.
    
    Args:
        domain: Domain to check
        
    Returns:
        True if likely a tracking domain
    """
    tracking_domains = [
        'doubleclick.net', 'google-analytics.com', 'googletagmanager.com',
        'facebook.com', 'twitter.com', 'linkedin.com', 'pinterest.com',
        'amazon-adsystem.com', 'googleadservices.com', 'googlesyndication.com'
    ]
    
    return any(tracking in domain for tracking in tracking_domains)


def generate_filename(url: str, extension: str = 'json') -> str:
    """
    Generate a filename based on URL.
    
    Args:
        url: URL to base filename on
        extension: File extension
        
    Returns:
        Generated filename
    """
    domain = extract_domain(url)
    domain_clean = re.sub(r'[^a-zA-Z0-9]', '_', domain)
    timestamp = hash_url(url)[:8]
    
    return f"gdpr_report_{domain_clean}_{timestamp}.{extension}"
