"""
Command-line interface for the GDPR compliance checker.
"""

import argparse
import sys
import json
import logging
from pathlib import Path

from .checker import GDPRChecker
from .batch import BatchChecker
from .models import CheckerConfig
from .utils import generate_filename

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def setup_argparser():
    """Setup command-line argument parser."""
    parser = argparse.ArgumentParser(
        prog='gdpr-check',
        description='Check websites for GDPR compliance indicators',
        epilog='Example: gdpr-check https://example.com --detailed --output report.json'
    )
    
    # Main argument
    parser.add_argument(
        'input',
        help='URL to check or path to file containing URLs (for batch processing)'
    )
    
    # Options
    parser.add_argument(
        '--detailed',
        action='store_true',
        help='Show detailed analysis results'
    )
    
    parser.add_argument(
        '--output', '-o',
        help='Save report to file (JSON, HTML, or CSV format based on extension)'
    )
    
    parser.add_argument(
        '--batch',
        action='store_true',
        help='Process multiple URLs from input file'
    )
    
    parser.add_argument(
        '--selenium',
        action='store_true',
        help='Use Selenium for JavaScript-rendered content (slower but more accurate)'
    )
    
    parser.add_argument(
        '--no-trackers',
        action='store_true',
        help='Skip checking for third-party trackers'
    )
    
    parser.add_argument(
        '--timeout',
        type=int,
        default=30,
        help='Request timeout in seconds (default: 30)'
    )
    
    parser.add_argument(
        '--workers',
        type=int,
        default=5,
        help='Number of parallel workers for batch processing (default: 5)'
    )
    
    parser.add_argument(
        '--quiet', '-q',
        action='store_true',
        help='Minimal output'
    )
    
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Verbose output'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version='%(prog)s 0.1.0'
    )
    
    return parser


def print_result(result, detailed=False):
    """Print analysis result to console."""
    if result is None:
        print("❌ Error: Failed to analyze URL")
        return
    
    # Print summary with colors
    print("\n" + "="*60)
    print(f"📊 GDPR Compliance Analysis")
    print("="*60)
    print(f"🌐 URL: {result.url}")
    print(f"📅 Timestamp: {result.timestamp}")
    print(f"🎯 Score: {result.score}/100 (Grade: {result._get_grade()})")
    
    # Compliance status
    if result.score >= 70:
        status = "✅ LIKELY COMPLIANT"
        color = "\033[92m"  # Green
    elif result.score >= 40:
        status = "⚠️  PARTIALLY COMPLIANT"
        color = "\033[93m"  # Yellow
    else:
        status = "❌ NON-COMPLIANT"
        color = "\033[91m"  # Red
    
    print(f"{color}Status: {status}\033[0m")
    
    print("\n📋 Compliance Indicators:")
    print(f"  {'✓' if result.has_ssl else '✗'} SSL/TLS Encryption")
    print(f"  {'✓' if result.has_privacy_policy else '✗'} Privacy Policy")
    if result.privacy_policy_url:
        print(f"     └─ {result.privacy_policy_url}")
    print(f"  {'✓' if result.has_cookie_consent else '✗'} Cookie Consent")
    print(f"  {'✓' if result.has_data_rights else '✗'} Data Rights Information")
    print(f"  {'✓' if result.has_contact_info else '✗'} Contact Information")
    print(f"  {'✓' if result.has_legal_basis else '✗'} Legal Basis Declaration")
    print(f"  {'✓' if result.has_dpo_info else '✗'} DPO Information")
    
    if result.trackers_found:
        print(f"\n🔍 Third-party Trackers ({len(result.trackers_found)} found):")
        for tracker in result.trackers_found[:5]:
            print(f"  • {tracker}")
        if len(result.trackers_found) > 5:
            print(f"  ... and {len(result.trackers_found) - 5} more")
    
    if result.issues:
        print("\n⚠️  Issues Found:")
        for issue in result.issues:
            print(f"  • {issue}")
    
    if result.recommendations:
        print("\n💡 Recommendations:")
        for rec in result.recommendations:
            print(f"  • {rec}")
    
    if detailed:
        print("\n📊 Detailed Analysis:")
        report = result.get_detailed_report()
        
        if result.cookie_consent_details:
            print("\n  Cookie Consent Details:")
            for key, value in result.cookie_consent_details.items():
                print(f"    - {key}: {value}")
        
        if result.data_rights_details:
            print("\n  Data Rights Coverage:")
            for right, present in result.data_rights_details.items():
                status = "✓" if present else "✗"
                print(f"    {status} {right.replace('_', ' ').title()}")
        
        if result.contact_details:
            print("\n  Contact Information:")
            for key, value in result.contact_details.items():
                if value and key != 'privacy_email':
                    print(f"    - {key.replace('_', ' ').title()}: {value}")
    
    print("\n" + "="*60)


def process_single_url(url, config, detailed=False):
    """Process a single URL."""
    print(f"🔍 Analyzing {url}...")
    
    try:
        checker = GDPRChecker(config=config)
        result = checker.analyze_url(url)
        return result
    except Exception as e:
        logger.error(f"Error analyzing {url}: {str(e)}")
        return None


def process_batch(filepath, config, output=None, workers=5):
    """Process multiple URLs from file."""
    if not Path(filepath).exists():
        print(f"❌ Error: File '{filepath}' not found")
        sys.exit(1)
    
    print(f"📂 Processing URLs from {filepath}...")
    
    batch_checker = BatchChecker(config=config, max_workers=workers)
    
    def progress_callback(completed, total, url, result):
        status = "✓" if result and result.score >= 70 else "⚠" if result and result.score >= 40 else "✗"
        print(f"[{completed}/{total}] {status} {url}")
    
    results = batch_checker.check_urls_from_file(filepath)
    
    # Print summary
    print("\n" + "="*60)
    print("📊 Batch Processing Summary")
    print("="*60)
    
    valid_results = [r for r in results.values() if r is not None]
    if valid_results:
        avg_score = sum(r.score for r in valid_results) / len(valid_results)
        compliant = sum(1 for r in valid_results if r.score >= 70)
        
        print(f"Total URLs processed: {len(results)}")
        print(f"Successful checks: {len(valid_results)}")
        print(f"Average compliance score: {avg_score:.1f}/100")
        print(f"Compliant websites: {compliant}/{len(valid_results)}")
    
    # Save report if requested
    if output:
        batch_checker.generate_comparison_report(results, output)
        print(f"\n✅ Report saved to {output}")
    
    return results


def main():
    """Main entry point for CLI."""
    parser = setup_argparser()
    args = parser.parse_args()
    
    # Setup logging level
    if args.quiet:
        logging.getLogger().setLevel(logging.ERROR)
    elif args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Create configuration
    config = CheckerConfig(
        timeout=args.timeout,
        use_selenium=args.selenium,
        check_third_party=not args.no_trackers
    )
    
    try:
        # Batch processing
        if args.batch:
            results = process_batch(
                args.input,
                config,
                args.output,
                args.workers
            )
        # Single URL processing
        else:
            result = process_single_url(args.input, config, args.detailed)
            
            if result:
                # Print to console
                if not args.quiet:
                    print_result(result, args.detailed)
                
                # Save to file if requested
                if args.output:
                    if args.output.endswith('.html'):
                        content = result.to_html()
                    elif args.output.endswith('.json'):
                        content = result.to_json()
                    else:
                        content = result.to_json()
                    
                    with open(args.output, 'w') as f:
                        f.write(content)
                    
                    print(f"\n✅ Report saved to {args.output}")
                
                # Exit with appropriate code
                sys.exit(0 if result.score >= 70 else 1)
            else:
                sys.exit(2)
    
    except KeyboardInterrupt:
        print("\n⚠️  Analysis interrupted by user")
        sys.exit(130)
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
