"""
GDPR-related patterns and keywords for detection.
"""

GDPR_PATTERNS = {
    'privacy_policy': [
        'privacy policy',
        'privacy statement',
        'privacy notice',
        'data protection',
        'datenschutz',
        'politique de confidentialité',
        'privacy',
        'privacidad',
        'riservatezza',
        'privacybeleid',
        'personvern'
    ],
    
    'cookie_consent': [
        'cookie consent',
        'cookie policy',
        'cookie notice',
        'we use cookies',
        'this site uses cookies',
        'accept cookies',
        'cookie preferences',
        'cookie settings',
        'manage cookies',
        'cookie banner',
        'cookie agreement',
        'necessary cookies',
        'functional cookies',
        'analytics cookies',
        'marketing cookies',
        'performance cookies',
        'targeting cookies'
    ],
    
    'data_rights': [
        'right to access',
        'right to rectification',
        'right to erasure',
        'right to be forgotten',
        'right to data portability',
        'right to object',
        'right to restrict',
        'data subject rights',
        'your rights',
        'your data rights',
        'gdpr rights',
        'access your data',
        'correct your data',
        'delete your data',
        'export your data',
        'opt-out',
        'unsubscribe',
        'withdraw consent'
    ],
    
    'legal_basis': [
        'legal basis',
        'lawful basis',
        'legitimate interest',
        'consent',
        'performance of contract',
        'legal obligation',
        'vital interests',
        'public task',
        'legitimate interests',
        'processing is necessary'
    ],
    
    'dpo': [
        'data protection officer',
        'dpo',
        'privacy officer',
        'chief privacy officer',
        'data protection team',
        'privacy team'
    ],
    
    'data_processing': [
        'how we use your data',
        'data processing',
        'personal data processing',
        'purposes of processing',
        'why we collect',
        'data collection',
        'information we collect',
        'data we collect',
        'types of data',
        'categories of data'
    ],
    
    'third_party': [
        'third party',
        'third-party',
        'service providers',
        'partners',
        'data sharing',
        'share your data',
        'disclose your data',
        'data recipients',
        'who we share with'
    ],
    
    'retention': [
        'retention period',
        'data retention',
        'how long we keep',
        'storage period',
        'delete after',
        'retain your data',
        'preservation period'
    ],
    
    'security': [
        'data security',
        'security measures',
        'technical measures',
        'organizational measures',
        'encryption',
        'secure',
        'protect your data',
        'safeguard',
        'data breach',
        'security incident'
    ],
    
    'international_transfers': [
        'international transfer',
        'cross-border',
        'data transfer',
        'outside the eu',
        'outside the eea',
        'third country',
        'adequacy decision',
        'appropriate safeguards',
        'standard contractual clauses',
        'binding corporate rules'
    ]
}

TRACKER_PATTERNS = {
    'Google Analytics': 'google-analytics.com',
    'Google Tag Manager': 'googletagmanager.com',
    'Facebook Pixel': 'facebook.com/tr',
    'Facebook SDK': 'connect.facebook.net',
    'Twitter Analytics': 'analytics.twitter.com',
    'LinkedIn Insight': 'snap.licdn.com',
    'Hotjar': 'hotjar.com',
    'Mixpanel': 'mixpanel.com',
    'Segment': 'segment.com',
    'Adobe Analytics': 'omtrdc.net',
    'Matomo': 'matomo',
    'Plausible': 'plausible.io',
    'Heap Analytics': 'heap.io',
    'Amplitude': 'amplitude.com',
    'Crazy Egg': 'crazyegg.com',
    'FullStory': 'fullstory.com',
    'Mouseflow': 'mouseflow.com',
    'Lucky Orange': 'luckyorange.com',
    'Intercom': 'intercom.io',
    'Drift': 'drift.com',
    'HubSpot': 'hubspot.com',
    'Marketo': 'marketo.com',
    'Salesforce': 'salesforce.com',
    'Amazon Ads': 'amazon-adsystem.com',
    'Google Ads': 'googleadservices.com',
    'Bing Ads': 'bat.bing.com',
    'Pinterest': 'pinterest.com',
    'TikTok Pixel': 'analytics.tiktok.com',
    'Snapchat Pixel': 'sc-static.net',
    'Reddit Pixel': 'reddit.com',
    'Quora Pixel': 'quora.com'
}

CONSENT_MANAGEMENT_PLATFORMS = {
    'OneTrust': ['onetrust.com', 'onetrust.io'],
    'Cookiebot': ['cookiebot.com', 'cookiebot.eu'],
    'TrustArc': ['trustarc.com', 'truste.com'],
    'Usercentrics': ['usercentrics.com', 'usercentrics.eu'],
    'Quantcast Choice': ['quantcast.com', 'quantcast.mgr.consensu.org'],
    'Didomi': ['didomi.io'],
    'Osano': ['osano.com'],
    'CookieYes': ['cookieyes.com'],
    'Termly': ['termly.io'],
    'iubenda': ['iubenda.com'],
    'Civic Cookie Control': ['civicuk.com'],
    'Cookie Script': ['cookie-script.com'],
    'GDPR Cookie Consent': ['gdpr-cookie-consent.com']
}

# Language-specific GDPR terms
GDPR_TERMS_BY_LANGUAGE = {
    'de': {  # German
        'privacy_policy': ['datenschutzerklärung', 'datenschutz', 'datenschutzrichtlinie'],
        'cookie_consent': ['cookie-einwilligung', 'cookies akzeptieren', 'cookie-hinweis'],
        'data_rights': ['ihre rechte', 'betroffenenrechte', 'auskunftsrecht', 'löschung']
    },
    'fr': {  # French
        'privacy_policy': ['politique de confidentialité', 'protection des données', 'confidentialité'],
        'cookie_consent': ['consentement aux cookies', 'accepter les cookies', 'gestion des cookies'],
        'data_rights': ['vos droits', 'droit d\'accès', 'droit de rectification', 'droit à l\'effacement']
    },
    'es': {  # Spanish
        'privacy_policy': ['política de privacidad', 'protección de datos', 'aviso de privacidad'],
        'cookie_consent': ['consentimiento de cookies', 'aceptar cookies', 'configuración de cookies'],
        'data_rights': ['sus derechos', 'derecho de acceso', 'derecho de rectificación', 'derecho de supresión']
    },
    'it': {  # Italian
        'privacy_policy': ['informativa sulla privacy', 'protezione dei dati', 'politica sulla riservatezza'],
        'cookie_consent': ['consenso ai cookie', 'accetta i cookie', 'gestione dei cookie'],
        'data_rights': ['i tuoi diritti', 'diritto di accesso', 'diritto di rettifica', 'diritto alla cancellazione']
    },
    'nl': {  # Dutch
        'privacy_policy': ['privacybeleid', 'privacyverklaring', 'gegevensbescherming'],
        'cookie_consent': ['cookietoestemming', 'cookies accepteren', 'cookiebeleid'],
        'data_rights': ['uw rechten', 'recht op inzage', 'recht op rectificatie', 'recht op verwijdering']
    }
}
