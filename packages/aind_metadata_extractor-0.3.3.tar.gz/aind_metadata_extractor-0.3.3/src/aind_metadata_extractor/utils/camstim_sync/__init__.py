"""CamStim utility methods"""
