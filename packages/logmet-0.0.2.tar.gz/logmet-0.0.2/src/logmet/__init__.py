"""The main package."""

from logmet.logmet import Context, logged

__authors__ = ["Narvin Singh"]
__project__ = "LogMet"
__version__ = "0.0.2"

__all__ = ["Context", "logged"]
