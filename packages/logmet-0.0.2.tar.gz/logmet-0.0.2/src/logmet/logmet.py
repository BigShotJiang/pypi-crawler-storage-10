"""The logging module."""

import enum
import functools
import logging
import time
from typing import TYPE_CHECKING, Self

if TYPE_CHECKING:
    from collections.abc import Callable
    from types import TracebackType


class _State(enum.IntEnum):
    INITED = 0
    ENTERED = 1
    EXITED = 2


class Context:
    """A logging context that may be used like a :class:`~logging.Logger`."""

    def __init__(self, name: str, logger: logging.Logger) -> None:
        """Initialize the context"""
        self._name = name
        self._logger = logger
        self._state = _State.INITED
        self._t0: int | None = None

    def __enter__(self) -> Self | None:
        """Enter the context."""
        self._t0 = time.perf_counter_ns()

        if self._state >= _State.ENTERED:
            self._logger.error("logger context can't be entered again")
            return None

        self._state = _State.ENTERED
        self._exc_type: type[BaseException] | None = None
        self._exc_val: BaseException | None = None
        self._exc_tb: TracebackType | None = None
        self.info("entered: %s", self._name)
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit the context."""
        t = time.perf_counter_ns()

        if self._state >= _State.EXITED:
            self.error("logger context can't be exited again")
            return

        self._state = _State.EXITED
        self._exc_type = exc_type
        self._exc_val = exc_val
        self._exc_tb = exc_tb
        duration_type, duration_s = (
            ("%.4f", (t - self._t0) / 1e9) if self._t0 is not None else ("%s", None)
        )
        self.info(
            "exited: %s"
            f"\n\tduration_s: {duration_type}"
            "\n\texc_type: %s"
            "\n\texc_val: %s"
            "\n\texc_tb: %s",
            self._name,
            duration_s,
            self._exc_type,
            self._exc_val,
            self._exc_tb,
        )

    def debug(
        self,
        msg: str,
        *args: object,
        exc_info: bool
        | tuple[type[BaseException], BaseException, TracebackType | None]
        | tuple[None, None, None]
        | BaseException
        | None = None,
        stack_info: bool = False,
        stacklevel: int = 1,
        extra: dict[str, object] | None = None,
    ) -> None:
        """Logs a message with level :data:`~logging.DEBUG` on this context's logger.

        The arguments are interpreted as for :meth:`~logging.Logger.debug`.
        """
        self._logger.debug(
            msg, *args, exc_info=exc_info, stack_info=stack_info, stacklevel=stacklevel, extra=extra
        )

    def info(
        self,
        msg: str,
        *args: object,
        exc_info: bool
        | tuple[type[BaseException], BaseException, TracebackType | None]
        | tuple[None, None, None]
        | BaseException
        | None = None,
        stack_info: bool = False,
        stacklevel: int = 1,
        extra: dict[str, object] | None = None,
    ) -> None:
        """Logs a message with level :data:`~logging.INFO` on this context's logger.

        The arguments are interpreted as for :meth:`~logging.Logger.debug`.
        """
        self._logger.info(
            msg, *args, exc_info=exc_info, stack_info=stack_info, stacklevel=stacklevel, extra=extra
        )

    def warning(
        self,
        msg: str,
        *args: object,
        exc_info: bool
        | tuple[type[BaseException], BaseException, TracebackType | None]
        | tuple[None, None, None]
        | BaseException
        | None = None,
        stack_info: bool = False,
        stacklevel: int = 1,
        extra: dict[str, object] | None = None,
    ) -> None:
        """Logs a message with level :data:`~logging.WARNING` on this context's logger.

        The arguments are interpreted as for :meth:`~logging.Logger.debug`.
        """
        self._logger.warning(
            msg, *args, exc_info=exc_info, stack_info=stack_info, stacklevel=stacklevel, extra=extra
        )

    def error(
        self,
        msg: str,
        *args: object,
        exc_info: bool
        | tuple[type[BaseException], BaseException, TracebackType | None]
        | tuple[None, None, None]
        | BaseException
        | None = None,
        stack_info: bool = False,
        stacklevel: int = 1,
        extra: dict[str, object] | None = None,
    ) -> None:
        """Logs a message with level :data:`~logging.ERROR` on this context's logger.

        The arguments are interpreted as for :meth:`~logging.Logger.debug`.
        """
        self._logger.error(
            msg, *args, exc_info=exc_info, stack_info=stack_info, stacklevel=stacklevel, extra=extra
        )

    def critical(
        self,
        msg: str,
        *args: object,
        exc_info: bool
        | tuple[type[BaseException], BaseException, TracebackType | None]
        | tuple[None, None, None]
        | BaseException
        | None = None,
        stack_info: bool = False,
        stacklevel: int = 1,
        extra: dict[str, object] | None = None,
    ) -> None:
        """Logs a message with level :data:`~logging.CRITICAL` on this context's logger.

        The arguments are interpreted as for :meth:`~logging.Logger.debug`.
        """
        self._logger.critical(
            msg, *args, exc_info=exc_info, stack_info=stack_info, stacklevel=stacklevel, extra=extra
        )

    def exception(
        self,
        msg: str,
        *args: object,
        exc_info: bool
        | tuple[type[BaseException], BaseException, TracebackType | None]
        | tuple[None, None, None]
        | BaseException
        | None = None,
        stack_info: bool = False,
        stacklevel: int = 1,
        extra: dict[str, object] | None = None,
    ) -> None:
        """Logs a message with level :data:`~logging.ERROR` on this context's logger.

        The arguments are interpreted as for :meth:`~logging.Logger.debug`.

        Exception info is added to the logging message. This method should only
        be called from an exception handler.
        """
        self._logger.exception(
            msg, *args, exc_info=exc_info, stack_info=stack_info, stacklevel=stacklevel, extra=extra
        )

    def log(  # noqa: PLR0913
        self,
        level: int,
        msg: str,
        *args: object,
        exc_info: bool
        | tuple[type[BaseException], BaseException, TracebackType | None]
        | tuple[None, None, None]
        | BaseException
        | None = None,
        stack_info: bool = False,
        stacklevel: int = 1,
        extra: dict[str, object] | None = None,
    ) -> None:
        """Logs a message with level ``level`` on this context's logger.

        The arguments are interpreted as for :meth:`~logging.Logger.debug`.
        """
        self._logger.log(
            level,
            msg,
            *args,
            exc_info=exc_info,
            stack_info=stack_info,
            stacklevel=stacklevel,
            extra=extra,
        )


def logged[TRet, **P](fn: Callable[P, TRet]) -> Callable[P, TRet]:
    """Inject a :class:`Context` into a callable.

    The callable must have a keyword-only parameter ``logger``. The value of
    ``logger`` will be replaced by a context that will collect information over
    the duration of the call.
    """

    @functools.wraps(fn)
    def logged_wrapper(*args: P.args, **kwargs: P.kwargs) -> TRet:
        with Context(fn.__name__, logging.getLogger(__name__)) as logger:
            kwargs["logger"] = logger
            return fn(*args, **kwargs)

    return logged_wrapper


LC = Context("DEFAULT", logging.getLogger())


if __name__ == "__main__":

    @logged
    def _my_fn(*, logger: Context = LC, flag: bool = True) -> None:
        logger.info("hello with flags: %s", flag)
        print(1 / 0)  # noqa: T201

    logging.basicConfig(level=logging.INFO)
    _my_fn()
    print("done")  # noqa: T201
