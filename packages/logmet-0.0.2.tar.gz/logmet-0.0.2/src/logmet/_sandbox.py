"""This is a sandbox module."""

import asyncio
import contextvars
import threading

# mypy: disable-error-code="no-untyped-call, no-untyped-def"
# ruff: noqa: ANN001, ANN202, T201

var = contextvars.ContextVar("var", default=10)


async def child(val):
    print("child", val, var.get())
    var.set(val)
    print("child", val, var.get())
    await asyncio.sleep(0)
    print("child", val, var.get())


def f(val):
    print("f", val, var.get())
    var.set(val)
    print("f", val, var.get())


async def run():
    var.set(1)
    print("run", var.get())
    t1 = threading.Thread(target=f, args=(4,))
    t2 = threading.Thread(target=f, args=(5,))
    t1.start()
    t2.start()
    await asyncio.gather(child(2), child(3))
    t1.join()
    t2.join()


if __name__ == "__main__":
    asyncio.run(run())
