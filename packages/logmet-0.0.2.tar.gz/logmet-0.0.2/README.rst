LogMet
######

LogMet is a Python logging framework.
