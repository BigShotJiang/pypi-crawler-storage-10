Tutorial
================

This is a gallery showcasing the different plots that `saiph.visualization` can generate.
