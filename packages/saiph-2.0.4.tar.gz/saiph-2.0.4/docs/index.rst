.. Saiph documentation master file, created by
   sphinx-quickstart on Fri Sep 24 09:52:44 2021.

Welcome to Saiph's documentation!
=================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   build/examples/plot_example
   source/reference


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
