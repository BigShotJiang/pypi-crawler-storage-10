import sys
from setuptools import setup

ERROR_MESSAGE = '''⚠️ THIS PROJECT 'nvidia-nvml-dev-cu13' IS DEPRECATED.
Please use 'nvidia-nvml-dev' instead.

To install the correct package, use:

    pip install nvidia-nvml-dev

For more information, visit: https://pypi.org/project/nvidia-nvml-dev/

'''

if any(arg in sys.argv for arg in ('bdist_wheel', 'bdist', 'wheel')):
    print(ERROR_MESSAGE, file=sys.stderr)
    sys.exit(1)

setup()
