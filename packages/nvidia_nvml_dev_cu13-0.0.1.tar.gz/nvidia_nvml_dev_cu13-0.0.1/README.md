⚠️ THIS PROJECT 'nvidia-nvml-dev-cu13' IS DEPRECATED.
Please use 'nvidia-nvml-dev' instead.

To install the correct package, use:

    pip install nvidia-nvml-dev

For more information, visit: https://pypi.org/project/nvidia-nvml-dev/
