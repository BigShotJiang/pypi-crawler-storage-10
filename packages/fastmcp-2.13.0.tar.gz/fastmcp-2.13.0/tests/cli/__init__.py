"""CLI test package."""
