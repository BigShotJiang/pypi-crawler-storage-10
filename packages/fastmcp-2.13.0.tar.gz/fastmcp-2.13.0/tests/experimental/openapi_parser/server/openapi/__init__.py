"""Tests for openapi_new server components."""
