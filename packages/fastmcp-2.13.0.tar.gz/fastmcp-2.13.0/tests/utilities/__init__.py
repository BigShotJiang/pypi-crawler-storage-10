"""Tests for utilities in the fastmcp package."""
