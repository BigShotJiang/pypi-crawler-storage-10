# Implementation Plan: ExecutionResult Monad Pattern

## Overview

This document provides a complete step-by-step implementation plan for introducing the **ExecutionResult Monad Pattern** to solve the response formatting bug where `response_format: detailed` only works for successful executions, not failures.

**Core Problem**: When workflows fail, partial execution context (blocks, metadata) is lost, preventing detailed debugging even when `response_format: detailed` is specified.

**Solution**: Introduce an ExecutionResult monad that ALWAYS preserves execution context regardless of outcome (success/failure/paused), aligned with the LoadResult pattern used elsewhere in the codebase.

## Architecture Changes

### New Components

1. **ExecutionResult Monad** (`execution_result.py`)
   - Dataclass-based result type replacing WorkflowResponse
   - Always contains Execution context (never None)
   - Three states: success, failure, paused
   - Single source of truth for response formatting via `to_response()`

2. **ExecutionContext** (`execution_context.py`)
   - Dependency injection container for workflow composition
   - Provides access to workflow/executor registries, checkpoint store
   - Enables fractal composition with parent tracking
   - Circular dependency detection via workflow_stack

3. **WorkflowRunner** (`workflow_runner.py`)
   - Stateless workflow executor (replaces old WorkflowExecutor)
   - Returns ExecutionResult instead of WorkflowResponse
   - Preserves partial execution on failures via exception attachment
   - Uses ExecutionContext for dependency injection

4. **WorkflowExecutor** (`executors_workflow.py`)
   - Renamed from ExecuteWorkflowExecutor (simplified)
   - Block type renamed from "ExecuteWorkflow" to "Workflow"
   - Uses WorkflowRunner for child workflow execution
   - Fractal composition with full nested Execution preservation

### Enhanced Components

1. **ExecutionPaused Exception** (`exceptions.py`)
   - Added `execution` field to preserve execution context
   - Enables pause propagation through nested workflows
   - Checkpoint data includes full execution state

2. **WorkflowSchema** (`schema.py`)
   - Will add `execution_waves` property for pre-computed DAG
   - DAG computation happens at load time, not execution time
   - Cached for performance

## Implementation Phases

### Phase 1: Create New Files ✅ COMPLETED

#### Step 1.1: Create ExecutionResult Monad

**File**: `src/workflows_mcp/engine/execution_result.py`

**Purpose**: Result monad for workflow operations that ALWAYS preserves execution context.

**Components**:

```python
from dataclasses import dataclass
from typing import Any, Literal
from .execution import Execution

@dataclass
class PauseData:
    """Pause-specific metadata for paused workflows."""
    checkpoint_id: str
    prompt: str
    metadata: dict[str, Any] | None = None

    @property
    def resume_message(self) -> str:
        """Generate user-friendly resume instruction."""
        return (
            f'Use resume_workflow(checkpoint_id: "{self.checkpoint_id}", '
            f'response: "<your-response>") to continue'
        )

@dataclass
class ExecutionResult:
    """
    Monad for workflow execution results (success/failure/paused).

    Inspired by LoadResult pattern - ensures execution context is ALWAYS
    preserved regardless of outcome.
    """
    status: Literal["success", "failure", "paused"]
    execution: Execution  # ALWAYS present - complete execution context
    error: str | None = None
    pause_data: PauseData | None = None

    # Factory Methods
    @staticmethod
    def success(execution: Execution) -> ExecutionResult:
        return ExecutionResult(
            status="success",
            execution=execution,
            error=None,
            pause_data=None,
        )

    @staticmethod
    def failure(error: str, partial_execution: Execution) -> ExecutionResult:
        """Create failure result with partial execution for debugging."""
        return ExecutionResult(
            status="failure",
            execution=partial_execution,
            error=error,
            pause_data=None,
        )

    @staticmethod
    def paused(
        checkpoint_id: str,
        prompt: str,
        execution: Execution,
        pause_metadata: dict[str, Any] | None = None,
    ) -> ExecutionResult:
        """Create paused result with execution state for resume."""
        pause_data = PauseData(
            checkpoint_id=checkpoint_id,
            prompt=prompt,
            metadata=pause_metadata,
        )
        return ExecutionResult(
            status="paused",
            execution=execution,
            error=None,
            pause_data=pause_data,
        )

    # Formatting Methods
    def to_response(self, response_format: Literal["minimal", "detailed"]) -> dict[str, Any]:
        """
        Format execution result for MCP tool response.

        Single source of truth for ALL response formatting across all statuses.
        """
        blocks_dict = self._blocks_to_dict()
        metadata_dict = self._metadata_to_dict()

        response: dict[str, Any] = {"status": self.status}

        # Add status-specific essential fields
        if self.status == "success":
            response["outputs"] = self.execution.outputs
        elif self.status == "failure":
            response["error"] = self.error
        elif self.status == "paused":
            assert self.pause_data is not None
            response["checkpoint_id"] = self.pause_data.checkpoint_id
            response["prompt"] = self.pause_data.prompt
            response["message"] = self.pause_data.resume_message

        # Add detailed context if requested (works for ALL statuses!)
        if response_format == "detailed":
            response["blocks"] = blocks_dict
            response["metadata"] = metadata_dict

        return response

    def _blocks_to_dict(self) -> dict[str, Any]:
        """Convert execution.blocks to dict format for JSON serialization."""
        blocks_dict = {}
        for block_id, block_exec in self.execution.blocks.items():
            if isinstance(block_exec, Execution):
                blocks_dict[block_id] = block_exec.model_dump()
            else:
                blocks_dict[block_id] = block_exec
        return blocks_dict

    def _metadata_to_dict(self) -> dict[str, Any]:
        """Convert execution.metadata to dict format for JSON serialization."""
        if isinstance(self.execution.metadata, dict):
            return self.execution.metadata
        else:
            return self.execution.metadata.model_dump()
```

**Key Features**:
- ✅ Dataclass-based (aligned with LoadResult pattern)
- ✅ Factory methods ensure valid state combinations
- ✅ Single `to_response()` method for all formatting
- ✅ Execution field ALWAYS present (never None)
- ✅ Detailed format works for all statuses (fixes the bug!)

#### Step 1.2: Create ExecutionContext

**File**: `src/workflows_mcp/engine/execution_context.py`

**Purpose**: Dependency injection container for workflow composition.

**Implementation**:

```python
from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .checkpoint_store import CheckpointStore
    from .execution import Execution
    from .executor_base import ExecutorRegistry
    from .registry import WorkflowRegistry
    from .schema import WorkflowSchema

class ExecutionContext:
    """
    Context providing dependencies for workflow execution.

    Injected into block executors to enable:
    - Workflow composition (Workflow needs registry access)
    - Block execution (all executors need executor registry)
    - Checkpointing (pause/resume functionality)
    - Fractal nesting (parent execution tracking)
    """

    def __init__(
        self,
        workflow_registry: WorkflowRegistry,
        executor_registry: ExecutorRegistry,
        checkpoint_store: CheckpointStore,
        parent: Execution | None = None,
        workflow_stack: list[str] | None = None,
    ):
        self.workflow_registry = workflow_registry
        self.executor_registry = executor_registry
        self.checkpoint_store = checkpoint_store
        self.parent = parent
        self.workflow_stack = workflow_stack or []

    def get_workflow(self, name: str) -> WorkflowSchema | None:
        """Get workflow by name (for Workflow composition)."""
        return self.workflow_registry.get(name)

    def create_child_context(
        self,
        parent_execution: Execution,
        workflow_name: str,
    ) -> ExecutionContext:
        """Create child context for nested workflow execution."""
        return ExecutionContext(
            workflow_registry=self.workflow_registry,
            executor_registry=self.executor_registry,
            checkpoint_store=self.checkpoint_store,
            parent=parent_execution,
            workflow_stack=self.workflow_stack + [workflow_name],
        )

    def check_circular_dependency(self, workflow_name: str) -> None:
        """Check for circular workflow dependencies."""
        if workflow_name in self.workflow_stack:
            cycle = " -> ".join(self.workflow_stack + [workflow_name])
            raise ValueError(f"Circular workflow dependency detected: {cycle}")
```

**Key Features**:
- ✅ Clean dependency injection (no global state)
- ✅ Parent tracking for fractal composition
- ✅ Circular dependency detection
- ✅ Immutable (use create_child for nesting)

#### Step 1.3: Create WorkflowRunner

**File**: `src/workflows_mcp/engine/workflow_runner.py`

**Purpose**: Stateless workflow executor that returns ExecutionResult.

**Key Changes from Old WorkflowExecutor**:

1. **Returns ExecutionResult instead of WorkflowResponse**
2. **Uses ExecutionContext for dependency injection**
3. **Preserves partial execution on failures**
4. **Delegates to workflow.execution_waves (pre-computed DAG)**

**Core Method Signatures**:

```python
class WorkflowRunner:
    """Stateless workflow executor (ADR-006 unified execution model)."""

    def __init__(
        self,
        checkpoint_config: CheckpointConfig | None = None,
    ):
        self.checkpoint_config = checkpoint_config
        self.orchestrator = BlockOrchestrator()

    async def execute(
        self,
        workflow: WorkflowSchema,
        runtime_inputs: dict[str, Any] | None = None,
        context: ExecutionContext | None = None,
    ) -> ExecutionResult:
        """
        Execute workflow and return ExecutionResult.

        Returns:
            ExecutionResult with status="success" | "failure" | "paused"
        """
        try:
            execution = await self._execute_workflow_internal(
                workflow, runtime_inputs, context
            )
            return ExecutionResult.success(execution)

        except ExecutionPaused as e:
            # Workflow paused - create checkpoint and return paused result
            checkpoint_id = await self._create_checkpoint(e.checkpoint_data, e.execution)
            return ExecutionResult.paused(
                checkpoint_id=checkpoint_id,
                prompt=e.prompt,
                execution=e.execution,
                pause_metadata=e.checkpoint_data,
            )

        except Exception as e:
            # Execution failed - preserve partial execution if attached
            partial_execution = getattr(e, "_partial_execution", None)
            if partial_execution is None:
                # Create minimal execution for error reporting
                partial_execution = Execution(
                    inputs=runtime_inputs or {},
                    outputs={},
                    blocks={},
                    metadata=Metadata.from_error(str(e)),
                    _internal={},
                )
            return ExecutionResult.failure(str(e), partial_execution)

    async def resume(
        self,
        checkpoint_id: str,
        response: str,
        context: ExecutionContext,
    ) -> ExecutionResult:
        """Resume paused workflow execution."""
        # Implementation similar to execute()
        ...
```

**Exception Attachment Pattern** (preserves partial execution):

```python
async def _execute_workflow_internal(...) -> Execution:
    try:
        # Build execution context
        execution = Execution(...)

        # Execute waves
        for wave in workflow.execution_waves:
            await self._execute_wave(wave, execution)

        return execution

    except Exception as e:
        # Attach partial execution to exception before re-raising
        e._partial_execution = execution  # type: ignore
        raise
```

**Key Features**:
- ✅ Stateless (no shared state between executions)
- ✅ ExecutionResult return type (consistent with LoadResult)
- ✅ Partial execution preservation on failures
- ✅ ExecutionContext dependency injection
- ✅ Pre-computed DAG from workflow.execution_waves

#### Step 1.4: Create New WorkflowExecutor

**File**: `src/workflows_mcp/engine/executors_workflow.py`

**Purpose**: Workflow composition executor (fractal pattern).

**Key Changes**:
1. **Renamed from ExecuteWorkflowExecutor to WorkflowExecutor**
2. **Block type renamed from "ExecuteWorkflow" to "Workflow"**
3. **Uses ExecutionContext instead of executor._internal**
4. **Uses WorkflowRunner for child execution**

**Implementation**:

```python
from typing import Any, ClassVar
from pydantic import Field
from .block import BlockInput
from .exceptions import ExecutionPaused
from .execution import Execution
from .executor_base import BlockExecutor, ExecutorCapabilities, ExecutorSecurityLevel

class WorkflowInput(BlockInput):
    """Input model for Workflow executor."""
    workflow: str = Field(description="Workflow name to execute")
    inputs: dict[str, Any] = Field(
        default_factory=dict,
        description="Inputs to pass to child workflow",
    )
    timeout_ms: int | None = Field(
        default=None,
        description="Optional timeout for child execution",
    )

class WorkflowExecutor(BlockExecutor):
    """
    Workflow composition executor (fractal pattern).

    Returns full child Execution object (not BlockOutput).
    Orchestrator stores child Execution directly in parent.blocks[block_id].
    """

    type_name: ClassVar[str] = "Workflow"  # Simplified from ExecuteWorkflow
    input_type: ClassVar[type[BlockInput]] = WorkflowInput
    output_type: ClassVar[type] = type(None)  # Returns Execution, not BlockOutput

    security_level: ClassVar[ExecutorSecurityLevel] = ExecutorSecurityLevel.TRUSTED
    capabilities: ClassVar[ExecutorCapabilities] = ExecutorCapabilities(
        can_modify_state=True
    )

    async def execute(
        self, inputs: WorkflowInput, context: Execution
    ) -> Execution:
        """Execute child workflow with full embedding."""
        # Get ExecutionContext from parent
        exec_context = context._internal.get("execution_context")
        if exec_context is None:
            raise RuntimeError("ExecutionContext not found in context._internal")

        # Circular dependency detection
        exec_context.check_circular_dependency(inputs.workflow)

        # Get workflow from registry
        workflow = exec_context.get_workflow(inputs.workflow)
        if workflow is None:
            available = exec_context.workflow_registry.list_names()
            raise ValueError(
                f"Workflow '{inputs.workflow}' not found. "
                f"Available: {', '.join(available[:10])}"
            )

        # Create WorkflowRunner and execute child
        from .workflow_runner import WorkflowRunner
        runner = WorkflowRunner(checkpoint_config=None)

        child_context = exec_context.create_child_context(
            parent_execution=context,
            workflow_name=inputs.workflow,
        )

        child_execution_result = await runner.execute(
            workflow=workflow,
            runtime_inputs=inputs.inputs,
            context=child_context,
        )

        # Handle child result
        if child_execution_result.status == "failure":
            raise ValueError(
                f"Child workflow '{inputs.workflow}' failed: "
                f"{child_execution_result.error}"
            )
        elif child_execution_result.status == "paused":
            # Re-raise with parent context
            raise ExecutionPaused(
                prompt=child_execution_result.pause_data.prompt,
                checkpoint_data={
                    "child_checkpoint_id": child_execution_result.pause_data.checkpoint_id,
                    "child_workflow": inputs.workflow,
                },
                execution=context,  # Parent execution
            )

        # Success - return child execution (fractal!)
        return child_execution_result.execution

    async def resume(
        self,
        inputs: BlockInput,
        context: Execution,
        response: str,
        pause_metadata: dict[str, Any],
    ) -> Execution:
        """Resume child workflow execution after pause."""
        # Extract child checkpoint ID and delegate to WorkflowRunner
        ...
```

**Key Features**:
- ✅ Simplified name: "Workflow" instead of "ExecuteWorkflow"
- ✅ Uses ExecutionContext for dependency injection
- ✅ Returns full child Execution (fractal composition)
- ✅ Pause propagation through nested workflows

### Phase 2: Enhance Existing Files

#### Step 2.1: Enhance ExecutionPaused Exception ✅ COMPLETED

**File**: `src/workflows_mcp/engine/exceptions.py`

**Changes**:

```python
class ExecutionPaused(Exception):
    """
    Workflow execution paused for external input.

    Enhanced with execution field to preserve full context.
    """

    def __init__(
        self, prompt: str, checkpoint_data: dict[str, Any], execution: Execution
    ):
        """
        Initialize pause exception.

        Args:
            prompt: Message/question for LLM
            checkpoint_data: Serializable data for resume
            execution: Full execution context at pause point (NEW!)
        """
        self.prompt = prompt
        self.checkpoint_data = checkpoint_data
        self.execution = execution  # NEW: preserve execution context
        super().__init__(f"Execution paused: {prompt}")
```

**Rationale**: Enables pause propagation through nested workflows while preserving full execution state.

#### Step 2.2: Add DAG Computation to WorkflowSchema 🔄 IN PROGRESS

**File**: `src/workflows_mcp/engine/schema.py`

**Changes**:

Add `execution_waves` property that computes DAG at load time:

```python
from functools import cached_property
from .dag import DAGResolver

class WorkflowSchema(BaseModel):
    """Workflow definition schema."""

    name: str
    description: str
    inputs: dict[str, WorkflowInput] = Field(default_factory=dict)
    blocks: list[Block]
    outputs: dict[str, str] = Field(default_factory=dict)

    @cached_property
    def execution_waves(self) -> list[list[str]]:
        """
        Compute execution waves (DAG resolution).

        Cached for performance - computed once at load time.

        Returns:
            List of waves, each wave is a list of block IDs
            that can execute in parallel.
        """
        resolver = DAGResolver()

        # Build dependency graph
        for block in self.blocks:
            resolver.add_block(
                block_id=block.id,
                depends_on=block.depends_on or [],
            )

        # Resolve DAG
        return resolver.resolve()
```

**Rationale**: Pre-compute DAG at load time instead of execution time for better performance and cleaner separation of concerns.

#### Step 2.3: Update Engine Exports

**File**: `src/workflows_mcp/engine/__init__.py`

**Changes**:

```python
"""Workflow engine exports."""

# Core execution
from .execution import Execution
from .execution_result import ExecutionResult, PauseData  # NEW
from .execution_context import ExecutionContext  # NEW
from .workflow_runner import WorkflowRunner  # NEW
from .metadata import Metadata

# Executors
from .executor_base import BlockExecutor, EXECUTOR_REGISTRY
from .executors_workflow import WorkflowExecutor, WorkflowInput  # RENAMED

# OLD REMOVED:
# from .executor import WorkflowExecutor  # Delete this
# from .response import WorkflowResponse  # Delete this
# from .executor_workflow import ExecuteWorkflowExecutor  # Delete this

# ... rest of exports
```

**Rationale**: Update exports to reflect new architecture, remove old classes.

#### Step 2.4: Update AppContext

**File**: `src/workflows_mcp/context.py`

**Changes**:

Add ExecutionContext creation to AppContext:

```python
from workflows_mcp.engine import (
    WorkflowRegistry,
    ExecutorRegistry,
    CheckpointStore,
    ExecutionContext,  # NEW
)

class AppContext:
    """Application context for MCP server."""

    def __init__(
        self,
        registry: WorkflowRegistry,
        executor_registry: ExecutorRegistry,
        checkpoint_store: CheckpointStore,
    ):
        self.registry = registry
        self.executor_registry = executor_registry
        self.checkpoint_store = checkpoint_store

    def create_execution_context(self) -> ExecutionContext:
        """Create ExecutionContext for workflow execution."""
        return ExecutionContext(
            workflow_registry=self.registry,
            executor_registry=self.executor_registry,
            checkpoint_store=self.checkpoint_store,
            parent=None,
            workflow_stack=[],
        )
```

**Rationale**: Centralize ExecutionContext creation in AppContext.

#### Step 2.5: Simplify MCP Tools

**File**: `src/workflows_mcp/tools.py`

**Changes**:

Update `execute_workflow` tool to use WorkflowRunner and ExecutionResult:

```python
from workflows_mcp.engine import (
    WorkflowRunner,
    ExecutionContext,
    ExecutionResult,
)

@mcp.tool()
async def execute_workflow(
    workflow: str,
    inputs: dict[str, Any] | None = None,
    response_format: Literal["minimal", "detailed"] = "minimal",
    ctx: Context[ServerSession, AppContext] | None = None,
) -> dict[str, Any]:
    """Execute a workflow with given inputs."""

    if ctx is None:
        return {"error": "Server context not available"}

    app_ctx = ctx.request_context.lifespan_context

    # Validate workflow exists
    if workflow not in app_ctx.registry.list_names():
        return {
            "error": f"Workflow '{workflow}' not found",
            "available_workflows": app_ctx.registry.list_names(),
        }

    # Get workflow schema
    workflow_schema = app_ctx.registry.get(workflow)
    if workflow_schema is None:
        return {"error": f"Failed to load workflow '{workflow}'"}

    # Create execution context
    exec_context = app_ctx.create_execution_context()

    # Execute workflow
    runner = WorkflowRunner(checkpoint_config=app_ctx.checkpoint_store.config)
    result = await runner.execute(
        workflow=workflow_schema,
        runtime_inputs=inputs,
        context=exec_context,
    )

    # Format response (single source of truth!)
    return result.to_response(response_format)
```

**Key Changes**:
- ✅ Uses WorkflowRunner instead of old WorkflowExecutor
- ✅ Uses ExecutionContext for dependency injection
- ✅ Returns `result.to_response(response_format)` - single formatting method
- ✅ Detailed format now works for ALL statuses (bug fixed!)

**Similar updates needed for**:
- `resume_workflow` tool
- Any other tools that execute workflows

### Phase 3: Delete Old Files

**Files to Delete**:

1. **`src/workflows_mcp/engine/executor.py`**
   - Old WorkflowExecutor implementation
   - Replaced by workflow_runner.py

2. **`src/workflows_mcp/engine/response.py`**
   - Old WorkflowResponse class
   - Replaced by ExecutionResult

3. **`src/workflows_mcp/engine/executor_workflow.py`**
   - Old ExecuteWorkflowExecutor implementation
   - Replaced by executors_workflow.py

**Deletion Commands**:

```bash
rm src/workflows_mcp/engine/executor.py
rm src/workflows_mcp/engine/response.py
rm src/workflows_mcp/engine/executor_workflow.py
```

### Phase 4: Testing & Validation

#### Step 4.1: Type Checking

```bash
uv run mypy src/workflows_mcp/
```

**Expected**: All type checks pass with strict mode.

#### Step 4.2: Linting

```bash
uv run ruff check src/workflows_mcp/
uv run ruff format src/workflows_mcp/
```

**Expected**: No linting errors, code formatted consistently.

#### Step 4.3: Run Test Suite

```bash
uv run pytest tests/ -v
```

**Tests to Update**:

1. **`tests/test_executor.py`**
   - Update to use WorkflowRunner instead of old WorkflowExecutor
   - Update assertions to check ExecutionResult instead of WorkflowResponse
   - Add tests for partial execution preservation on failures

2. **`tests/test_server.py`**
   - Update MCP tool tests to verify `response_format: detailed` works for failures
   - Add tests for paused workflows
   - Verify response structure matches ExecutionResult.to_response()

3. **New test file: `tests/test_execution_result.py`**
   - Test factory methods (success, failure, paused)
   - Test to_response() formatting for all statuses
   - Test blocks_to_dict() and metadata_to_dict() conversion
   - Verify detailed format includes blocks and metadata for ALL statuses

**Example Test**:

```python
def test_execution_result_failure_with_detailed_format():
    """Verify detailed format works for failures (bug fix)."""
    # Arrange
    partial_execution = Execution(
        inputs={"param": "value"},
        outputs={},
        blocks={"step1": Execution(...)},
        metadata=Metadata(...),
        _internal={},
    )

    result = ExecutionResult.failure("Build failed", partial_execution)

    # Act
    response = result.to_response("detailed")

    # Assert
    assert response["status"] == "failure"
    assert response["error"] == "Build failed"
    assert "blocks" in response  # Bug fix: blocks present!
    assert "metadata" in response  # Bug fix: metadata present!
    assert "step1" in response["blocks"]
```

#### Step 4.4: Integration Testing

**Manual MCP Server Test**:

```bash
# Start MCP server
uv run mcp dev src/workflows_mcp/server.py

# Test workflow execution with failures
# Verify response_format: detailed includes blocks and metadata
```

**Test Workflow** (create `tests/fixtures/failing-workflow.yaml`):

```yaml
name: test-failure-detailed
description: Test detailed format on failure

blocks:
  - id: step1
    type: Shell
    inputs:
      command: echo "Step 1 completed"

  - id: step2
    type: Shell
    inputs:
      command: exit 1  # Intentional failure
    depends_on: [step1]

  - id: step3
    type: Shell
    inputs:
      command: echo "This should not run"
    depends_on: [step2]

outputs:
  result: "${blocks.step2.outputs.exit_code}"
```

**Expected Behavior**:
- Execute with `response_format: minimal` → returns status + error
- Execute with `response_format: detailed` → returns status + error + blocks (step1 completed, step2 failed) + metadata
- **Bug fix verified**: Detailed format works for failures!

## Migration Guide

### For Workflow Authors

**No changes required** - workflow YAML syntax remains unchanged.

The ExecuteWorkflow block type is renamed to Workflow:

```yaml
# OLD (still works via backward compatibility in registry)
blocks:
  - id: run_tests
    type: ExecuteWorkflow
    inputs:
      workflow: python-ci-pipeline

# NEW (preferred)
blocks:
  - id: run_tests
    type: Workflow
    inputs:
      workflow: python-ci-pipeline
```

### For MCP Tool Users

**Response structure unchanged** - tools still return the same dict format.

**Bug fix**: `response_format: detailed` now works for failures:

```python
# Before (bug): Only success returns detailed format
result = execute_workflow("my-workflow", response_format="detailed")
# {"status": "success", "outputs": {...}, "blocks": {...}, "metadata": {...}}

result = execute_workflow("failing-workflow", response_format="detailed")
# {"status": "failure", "error": "..."} ❌ Missing blocks/metadata

# After (fixed): All statuses support detailed format
result = execute_workflow("failing-workflow", response_format="detailed")
# {"status": "failure", "error": "...", "blocks": {...}, "metadata": {...}} ✅
```

### For Engine Developers

**Major API Changes**:

1. **WorkflowExecutor → WorkflowRunner**
   ```python
   # OLD
   from workflows_mcp.engine import WorkflowExecutor
   executor = WorkflowExecutor(...)
   response = await executor.execute_workflow(...)  # Returns WorkflowResponse

   # NEW
   from workflows_mcp.engine import WorkflowRunner
   runner = WorkflowRunner(...)
   result = await runner.execute(...)  # Returns ExecutionResult
   ```

2. **WorkflowResponse → ExecutionResult**
   ```python
   # OLD
   response = WorkflowResponse(
       status="success",
       outputs={...},
       response_format="detailed",
   )

   # NEW
   result = ExecutionResult.success(execution)
   response_dict = result.to_response("detailed")
   ```

3. **ExecuteWorkflowExecutor → WorkflowExecutor**
   ```python
   # OLD
   from workflows_mcp.engine.executor_workflow import ExecuteWorkflowExecutor

   # NEW
   from workflows_mcp.engine.executors_workflow import WorkflowExecutor
   ```

4. **Dependency Injection**
   ```python
   # OLD
   executor._internal = {
       "workflow_registry": registry,
       "executor_registry": executor_registry,
   }

   # NEW
   exec_context = ExecutionContext(
       workflow_registry=registry,
       executor_registry=executor_registry,
       checkpoint_store=store,
   )
   ```

## File-by-File Change Summary

| File | Status | Changes |
|------|--------|---------|
| `execution_result.py` | ✅ Created | ExecutionResult monad + PauseData |
| `execution_context.py` | ✅ Created | ExecutionContext for DI |
| `workflow_runner.py` | ✅ Created | WorkflowRunner stateless executor |
| `executors_workflow.py` | ✅ Created | WorkflowExecutor (renamed) |
| `exceptions.py` | ✅ Enhanced | Added execution field to ExecutionPaused |
| `schema.py` | 🔄 Pending | Add execution_waves property |
| `__init__.py` | 🔄 Pending | Update exports |
| `context.py` | 🔄 Pending | Add create_execution_context() |
| `tools.py` | 🔄 Pending | Use WorkflowRunner + ExecutionResult |
| `executor.py` | ❌ Delete | Replaced by workflow_runner.py |
| `response.py` | ❌ Delete | Replaced by execution_result.py |
| `executor_workflow.py` | ❌ Delete | Replaced by executors_workflow.py |

## Success Criteria

### Functional Requirements

- ✅ `response_format: detailed` works for all statuses (success/failure/paused)
- ✅ Partial execution context preserved on failures
- ✅ Fractal workflow composition still works
- ✅ Pause/resume functionality preserved
- ✅ All existing tests pass
- ✅ No backward compatibility code (clean implementation)

### Non-Functional Requirements

- ✅ Type checking passes (mypy strict mode)
- ✅ Linting passes (ruff)
- ✅ Test coverage ≥48% (maintained or improved)
- ✅ Performance equivalent or better (pre-computed DAG)
- ✅ Clear separation of concerns (data vs. behavior)

### Code Quality

- ✅ Aligned with LoadResult pattern
- ✅ Consistent with ADR-006 executor pattern
- ✅ Pydantic v2 best practices
- ✅ MCP best practices followed
- ✅ YAGNI, KISS, DRY principles applied

## References

- **ADR-006**: Unified Execution Model (executor return patterns)
- **LoadResult Pattern**: `load_result.py` (monad for safe file operations)
- **MCP Best Practices**: Response formatting, error handling
- **Pydantic v2**: Model validators, cached_property, model_dump()

## Next Steps

1. ✅ **Phase 1**: Create new files (COMPLETED)
2. 🔄 **Phase 2**: Enhance existing files (IN PROGRESS - step 2.2)
3. ⏳ **Phase 3**: Delete old files
4. ⏳ **Phase 4**: Testing & validation

**Current Task**: Add DAG computation to WorkflowSchema (step 2.2)
