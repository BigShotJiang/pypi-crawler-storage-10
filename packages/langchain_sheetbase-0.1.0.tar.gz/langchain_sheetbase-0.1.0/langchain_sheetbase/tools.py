"""
LangChain Tools for SheetBase.

Provides BaseTool implementations for CRUD operations on Google Sheets.
"""

from typing import Optional, Type, List
from pydantic import BaseModel, Field
from langchain_core.tools import BaseTool
from langchain_core.callbacks import CallbackManagerForToolRun

from .client import SheetBaseClient
from .exceptions import SheetBaseError


# ═══════════════════════════════════════════════════════════════════
# Input Schemas
# ═══════════════════════════════════════════════════════════════════

class SearchInput(BaseModel):
    """Input schema for search tool."""
    query: str = Field(description="Keywords to search (space-separated, OR supported)")
    limit: int = Field(default=10, description="Maximum number of results")


class CreateInput(BaseModel):
    """Input schema for create tool."""
    data: dict = Field(description="Dictionary with column names as keys and values to insert")


class UpdateInput(BaseModel):
    """Input schema for update tool."""
    row_number: int = Field(description="Row number to update (from __row field)")
    updates: dict = Field(description="Dictionary with fields to update")


class DeleteInput(BaseModel):
    """Input schema for delete tool."""
    row_number: int = Field(description="Row number to delete (from __row field)")


# ═══════════════════════════════════════════════════════════════════
# Tool Implementations
# ═══════════════════════════════════════════════════════════════════

class SheetBaseSearchTool(BaseTool):
    """Tool for searching records in Google Sheets with fuzzy keyword matching."""
    
    name: str = "sheetbase_search"
    description: str = (
        "Search Google Sheets database with keywords. "
        "Returns matching records with relevance scores. "
        "Use space for AND logic, OR for alternatives. "
        "Example: 'laptop budget 1000' or 'mouse OR keyboard wireless'"
    )
    args_schema: Type[BaseModel] = SearchInput
    client: SheetBaseClient
    
    def _run(
        self,
        query: str,
        limit: int = 10,
        run_manager: Optional[CallbackManagerForToolRun] = None
    ) -> str:
        """Execute search operation."""
        try:
            results = self.client.search(query=query, limit=limit)
            
            if not results:
                return f"No results found for query: {query}"
            
            formatted = [f"Row {r.get('__row', '?')}: {r}" for r in results]
            return f"Found {len(results)} results:\n" + "\n".join(formatted)
            
        except SheetBaseError as e:
            return f"Search failed: {str(e)}"


class SheetBaseCreateTool(BaseTool):
    """Tool for creating new records in Google Sheets."""
    
    name: str = "sheetbase_create"
    description: str = (
        "Create a new record in Google Sheets. "
        "Provide a dictionary with column names as keys. "
        "Returns success message with created row number. "
        "Example: {'Product Name': 'USB Cable', 'Price': '9.99', 'Stock': 200}"
    )
    args_schema: Type[BaseModel] = CreateInput
    client: SheetBaseClient
    
    def _run(self, data: dict, run_manager: Optional[CallbackManagerForToolRun] = None) -> str:
        """Execute create operation."""
        try:
            result = self.client.create(values=data)
            
            if result.get('success'):
                row_num = result.get('rowNumber', '?')
                return f"✅ Record created successfully at row {row_num}: {data}"
            else:
                return f"❌ Create failed: {result.get('message', 'Unknown error')}"
                
        except SheetBaseError as e:
            return f"Create operation failed: {str(e)}"


class SheetBaseUpdateTool(BaseTool):
    """Tool for updating existing records in Google Sheets."""
    
    name: str = "sheetbase_update"
    description: str = (
        "Update an existing record in Google Sheets. "
        "Provide row_number (from __row field) and updates dictionary. "
        "Only specified fields will be updated. "
        "Example: row_number=5, updates={'Price': '29.99', 'Stock': 150}"
    )
    args_schema: Type[BaseModel] = UpdateInput
    client: SheetBaseClient
    
    def _run(
        self,
        row_number: int,
        updates: dict,
        run_manager: Optional[CallbackManagerForToolRun] = None
    ) -> str:
        """Execute update operation."""
        try:
            result = self.client.update(row_number=row_number, updates=updates)
            
            if result.get('success'):
                return f"✅ Row {row_number} updated successfully: {updates}"
            else:
                return f"❌ Update failed: {result.get('message', 'Unknown error')}"
                
        except SheetBaseError as e:
            return f"Update operation failed: {str(e)}"


class SheetBaseDeleteTool(BaseTool):
    """Tool for deleting records from Google Sheets."""
    
    name: str = "sheetbase_delete"
    description: str = (
        "Delete a record from Google Sheets. "
        "Provide row_number (from __row field in search results). "
        "⚠️ This operation is permanent and cannot be undone. "
        "Example: row_number=123"
    )
    args_schema: Type[BaseModel] = DeleteInput
    client: SheetBaseClient
    
    def _run(self, row_number: int, run_manager: Optional[CallbackManagerForToolRun] = None) -> str:
        """Execute delete operation."""
        try:
            result = self.client.delete(row_number=row_number)
            
            if result.get('success'):
                return f"✅ Row {row_number} deleted successfully"
            else:
                return f"❌ Delete failed: {result.get('message', 'Unknown error')}"
                
        except SheetBaseError as e:
            return f"Delete operation failed: {str(e)}"


# ═══════════════════════════════════════════════════════════════════
# Factory Function
# ═══════════════════════════════════════════════════════════════════

def create_sheetbase_tools(
    mode: str = 'appsscript',
    google_sheets_url: Optional[str] = None,
    apps_script_url: Optional[str] = None,
    include_write_tools: bool = True
) -> List[BaseTool]:
    """
    Create and return all SheetBase tools.
    
    Args:
        mode: Connection mode ('simple' or 'appsscript')
        google_sheets_url: Google Sheets URL (for simple mode)
        apps_script_url: Apps Script URL (for appsscript mode)
        include_write_tools: Whether to include create/update/delete tools
        
    Returns:
        List of BaseTool instances ready for use with agents
    """
    client = SheetBaseClient(
        mode=mode,
        google_sheets_url=google_sheets_url,
        apps_script_url=apps_script_url
    )
    
    tools = [SheetBaseSearchTool(client=client)]
    
    if include_write_tools and mode == 'appsscript':
        tools.extend([
            SheetBaseCreateTool(client=client),
            SheetBaseUpdateTool(client=client),
            SheetBaseDeleteTool(client=client)
        ])
    
    return tools
