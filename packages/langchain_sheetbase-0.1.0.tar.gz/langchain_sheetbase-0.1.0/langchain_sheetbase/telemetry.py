"""
Telemetry and usage tracking for SheetBase.

Tracks tool usage statistics locally and optionally via LangSmith.
All telemetry respects user privacy and can be disabled.
"""

import logging
import time
import json
from typing import Dict, Optional, Any
from pathlib import Path
from datetime import datetime
from collections import defaultdict
from threading import Lock

logger = logging.getLogger(__name__)


class UsageTracker:
    """Thread-safe local usage statistics tracker."""
    
    def __init__(self, enabled: bool = True, persist_path: Optional[Path] = None):
        self.enabled = enabled
        self._lock = Lock()
        
        if persist_path is None:
            persist_path = Path.home() / '.sheetbase' / 'stats.json'
        
        self.persist_path = persist_path
        self.persist_path.parent.mkdir(parents=True, exist_ok=True)
        
        self.stats: Dict[str, Any] = {
            'session_start': datetime.utcnow().isoformat(),
            'total_invocations': 0,
            'operations': defaultdict(lambda: {
                'count': 0, 'success': 0, 'failure': 0, 'total_duration_ms': 0.0
            }),
            'errors': defaultdict(int),
            'modes': defaultdict(int)
        }
        
        self._load_stats()
    
    def track_operation(
        self, operation: str, success: bool, duration_ms: float, 
        mode: str, error: Optional[str] = None
    ) -> None:
        if not self.enabled:
            return
        
        with self._lock:
            self.stats['total_invocations'] += 1
            
            op_stats = self.stats['operations'][operation]
            op_stats['count'] += 1
            op_stats['total_duration_ms'] += duration_ms
            
            if success:
                op_stats['success'] += 1
            else:
                op_stats['failure'] += 1
                if error:
                    self.stats['errors'][error] += 1
            
            self.stats['modes'][mode] += 1
        
        if self.stats['total_invocations'] % 10 == 0:
            self._save_stats()
    
    def get_summary(self) -> Dict[str, Any]:
        with self._lock:
            summary = {
                'total_invocations': self.stats['total_invocations'],
                'session_start': self.stats['session_start'],
                'operations': {}
            }
            
            for op, stats in self.stats['operations'].items():
                if stats['count'] > 0:
                    summary['operations'][op] = {
                        'count': stats['count'],
                        'success_rate': stats['success'] / stats['count'] * 100,
                        'avg_duration_ms': stats['total_duration_ms'] / stats['count']
                    }
            
            summary['modes'] = dict(self.stats['modes'])
            summary['top_errors'] = dict(
                sorted(self.stats['errors'].items(), key=lambda x: x[1], reverse=True)[:5]
            )
            
            return summary
    
    def _save_stats(self) -> None:
        try:
            with open(self.persist_path, 'w') as f:
                serializable = {
                    'session_start': self.stats['session_start'],
                    'total_invocations': self.stats['total_invocations'],
                    'operations': dict(self.stats['operations']),
                    'errors': dict(self.stats['errors']),
                    'modes': dict(self.stats['modes'])
                }
                json.dump(serializable, f, indent=2)
        except Exception as e:
            logger.warning(f"Failed to save usage stats: {e}")
    
    def _load_stats(self) -> None:
        if not self.persist_path.exists():
            return
        
        try:
            with open(self.persist_path, 'r') as f:
                loaded = json.load(f)
                self.stats.update(loaded)
                
                self.stats['operations'] = defaultdict(
                    lambda: {'count': 0, 'success': 0, 'failure': 0, 'total_duration_ms': 0.0},
                    loaded.get('operations', {})
                )
                self.stats['errors'] = defaultdict(int, loaded.get('errors', {}))
                self.stats['modes'] = defaultdict(int, loaded.get('modes', {}))
        except Exception as e:
            logger.warning(f"Failed to load usage stats: {e}")
    
    def reset(self) -> None:
        with self._lock:
            self.stats = {
                'session_start': datetime.utcnow().isoformat(),
                'total_invocations': 0,
                'operations': defaultdict(lambda: {
                    'count': 0, 'success': 0, 'failure': 0, 'total_duration_ms': 0.0
                }),
                'errors': defaultdict(int),
                'modes': defaultdict(int)
            }
        self._save_stats()


_global_tracker: Optional[UsageTracker] = None

def get_tracker() -> UsageTracker:
    global _global_tracker
    if _global_tracker is None:
        _global_tracker = UsageTracker(enabled=True)
    return _global_tracker


def track_operation(operation_name: str):
    """Decorator to automatically track operation metrics."""
    def decorator(func):
        def wrapper(self, *args, **kwargs):
            tracker = get_tracker()
            start_time = time.time()
            success = False
            error = None
            
            try:
                result = func(self, *args, **kwargs)
                success = True
                return result
            except Exception as e:
                error = type(e).__name__
                raise
            finally:
                duration_ms = (time.time() - start_time) * 1000
                mode = getattr(self, 'mode', 'unknown')
                
                tracker.track_operation(
                    operation=operation_name,
                    success=success,
                    duration_ms=duration_ms,
                    mode=mode,
                    error=error
                )
        
        return wrapper
    return decorator


def configure_langsmith(api_key: Optional[str] = None, project: str = "sheetbase-tracking") -> None:
    """Configure LangSmith tracing for production monitoring."""
    try:
        import os
        if api_key:
            os.environ['LANGSMITH_API_KEY'] = api_key
        os.environ['LANGSMITH_TRACING'] = 'true'
        os.environ['LANGSMITH_PROJECT'] = project
        logger.info(f"✅ LangSmith tracing enabled for project: {project}")
    except ImportError:
        logger.warning("LangSmith not available. Install with: pip install langsmith")


def print_usage_stats() -> None:
    """Print formatted usage statistics to console."""
    tracker = get_tracker()
    summary = tracker.get_summary()
    
    print("\n" + "="*60)
    print("📊 SheetBase Usage Statistics")
    print("="*60)
    print(f"\n🕐 Session Start: {summary['session_start']}")
    print(f"📈 Total Invocations: {summary['total_invocations']}")
    
    if summary['operations']:
        print("\n🔧 Operations:")
        for op, stats in summary['operations'].items():
            print(f"  • {op.upper()}")
            print(f"    Count: {stats['count']}")
            print(f"    Success Rate: {stats['success_rate']:.1f}%")
            print(f"    Avg Duration: {stats['avg_duration_ms']:.2f}ms")
    
    if summary['modes']:
        print("\n🔌 Connection Modes:")
        for mode, count in summary['modes'].items():
            print(f"  • {mode}: {count} calls")
    
    if summary['top_errors']:
        print("\n⚠️  Top Errors:")
        for error, count in summary['top_errors'].items():
            print(f"  • {error}: {count} occurrences")
    
    print("\n" + "="*60 + "\n")


if __name__ == '__main__':
    print_usage_stats()
