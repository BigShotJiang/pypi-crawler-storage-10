"""Utility functions for SheetBase."""

from typing import List, Dict, Any
import csv
from io import StringIO

def parse_csv_to_json(csv_text: str) -> List[Dict[str, Any]]:
    """
    Parse CSV text to list of dictionaries.
    
    Args:
        csv_text: Raw CSV string
        
    Returns:
        List of record dictionaries
    """
    reader = csv.DictReader(StringIO(csv_text))
    return [dict(row) for row in reader]

def fuzzy_search(records: List[Dict], query: str, threshold: float = 0.2) -> List[Dict]:
    """
    Simple fuzzy search implementation.
    
    Args:
        records: List of record dictionaries
        query: Search keywords
        threshold: Match sensitivity (lower = stricter)
        
    Returns:
        Filtered and scored records
    """
    keywords = query.lower().split()
    results = []
    
    for record in records:
        text = str(record).lower()
        score = sum(1 for kw in keywords if kw in text) / len(keywords)
        
        if score >= threshold:
            record_copy = record.copy()
            record_copy['_score'] = score
            results.append(record_copy)
    
    return sorted(results, key=lambda x: x['_score'], reverse=True)
