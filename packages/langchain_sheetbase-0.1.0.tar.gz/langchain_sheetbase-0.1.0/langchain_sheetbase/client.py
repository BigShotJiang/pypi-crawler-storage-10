"""
SheetBase Client - Core API wrapper for Google Sheets operations.
"""

from typing import Dict, List, Optional, Any
import logging
import re
import requests
from urllib.parse import urlencode

from .exceptions import SheetBaseError, ConnectionError, InvalidURLError, OperationError
from .utils import parse_csv_to_json, fuzzy_search
from .telemetry import track_operation

logger = logging.getLogger(__name__)


class SheetBaseClient:
    """
    Client for interacting with SheetBase API.
    
    Supports two connection modes:
    - simple: Read-only via public Google Sheets CSV export
    - appsscript: Full CRUD via Google Apps Script deployment
    """
    
    def __init__(
        self,
        mode: str = 'simple',
        google_sheets_url: Optional[str] = None,
        apps_script_url: Optional[str] = None,
        api_base_url: str = 'http://localhost:3001',
        timeout: int = 30,
        max_retries: int = 3
    ) -> None:
        self.mode = mode
        self.timeout = timeout
        self.max_retries = max_retries
        self.api_base_url = api_base_url
        
        if mode == 'simple':
            if not google_sheets_url:
                raise InvalidURLError("google_sheets_url required for simple mode")
            self.sheet_id = self._extract_sheet_id(google_sheets_url)
            self.base_url = f"{api_base_url}/api/{self.sheet_id}/0"
            logger.info(f"Initialized SheetBase client in simple mode: {self.base_url}")
            
        elif mode == 'appsscript':
            if not apps_script_url:
                raise InvalidURLError("apps_script_url required for appsscript mode")
            if not apps_script_url.endswith('/exec'):
                raise InvalidURLError("Apps Script URL must end with /exec")
            self.base_url = apps_script_url
            logger.info(f"Initialized SheetBase client in appsscript mode")
            
        else:
            raise ValueError(f"Invalid mode: {mode}. Use 'simple' or 'appsscript'")
    
    def _extract_sheet_id(self, url: str) -> str:
        match = re.search(r'/d/([a-zA-Z0-9-_]+)', url)
        if not match:
            raise InvalidURLError(
                f"Could not extract sheet ID from URL: {url}. "
                "Expected format: https://docs.google.com/spreadsheets/d/SHEET_ID/edit"
            )
        return match.group(1)
    
    def _make_request(self, method: str, url: str, **kwargs: Any) -> Dict[str, Any]:
        kwargs.setdefault('timeout', self.timeout)
        
        for attempt in range(self.max_retries):
            try:
                response = requests.request(method, url, **kwargs)
                response.raise_for_status()
                return response.json()
            except requests.RequestException as e:
                logger.warning(f"Request failed (attempt {attempt + 1}/{self.max_retries}): {e}")
                if attempt == self.max_retries - 1:
                    raise ConnectionError(
                        f"Failed to connect to SheetBase after {self.max_retries} attempts: {e}"
                    )
        
        raise ConnectionError("Unexpected error in request retry logic")
    
    @track_operation('get_all')
    def get_all(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        logger.info("Fetching all records")
        response = self._make_request('GET', self.base_url)
        
        data = response.get('data', [])
        if limit:
            data = data[:limit]
        
        logger.info(f"Retrieved {len(data)} records")
        return data
    
    @track_operation('search')
    def search(self, query: str, user_id: Optional[str] = None, limit: int = 10) -> List[Dict[str, Any]]:
        logger.info(f"Searching with query: {query}")
        
        search_query = query
        if user_id:
            search_query = f"{query} {user_id}"
        
        if self.mode == 'simple':
            url = f"{self.base_url}/search-advanced"
            params = {'q': search_query, 'fuzzy': '0.2', 'limit': str(limit)}
        else:
            params = {'q': search_query, 'limit': str(limit)}
            url = f"{self.base_url}?{urlencode(params)}"
        
        response = self._make_request('GET', url)
        data = response.get('data', [])
        
        logger.info(f"Found {len(data)} matching records")
        return data
    
    @track_operation('create')
    def create(self, values: Dict[str, str]) -> Dict[str, Any]:
        if self.mode == 'simple':
            raise OperationError("Create operation not supported in simple mode")
        
        logger.info(f"Creating new record: {values}")
        
        payload = {'operation': 'create', 'values': values}
        response = self._make_request('POST', self.base_url, json=payload)
        logger.info(f"Record created successfully")
        return response
    
    @track_operation('update')
    def update(self, row_number: int, updates: Dict[str, str]) -> Dict[str, Any]:
        if self.mode == 'simple':
            raise OperationError("Update operation not supported in simple mode")
        
        logger.info(f"Updating row {row_number}: {updates}")
        
        payload = {'operation': 'update', 'rowNumber': row_number, 'updates': updates}
        response = self._make_request('POST', self.base_url, json=payload)
        logger.info(f"Row {row_number} updated successfully")
        return response
    
    @track_operation('delete')
    def delete(self, row_number: int) -> Dict[str, Any]:
        if self.mode == 'simple':
            raise OperationError("Delete operation not supported in simple mode")
        
        logger.info(f"Deleting row {row_number}")
        
        payload = {'operation': 'delete', 'rowNumber': row_number}
        response = self._make_request('POST', self.base_url, json=payload)
        logger.info(f"Row {row_number} deleted successfully")
        return response
