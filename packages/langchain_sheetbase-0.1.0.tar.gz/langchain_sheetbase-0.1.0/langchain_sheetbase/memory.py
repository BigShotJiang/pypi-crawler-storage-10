"""
LangChain Memory implementation for SheetBase.

Stores conversation history in Google Sheets with schema:
- timestamp
- user_id
- user_request
- agent_response

Note: This is a simplified memory implementation that doesn't inherit from
deprecated BaseMemory. For production use with LangGraph, see examples.
"""

from typing import Dict, List, Any, Optional
from datetime import datetime
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage

from .client import SheetBaseClient


class SheetBaseMemory:
    """
    Conversational memory stored in Google Sheets.
    
    This is a lightweight memory implementation that stores conversations
    in Google Sheets without relying on deprecated BaseMemory class.
    
    Schema:
        - timestamp: ISO 8601 datetime
        - user_id: User identifier
        - user_request: User message
        - agent_response: AI response
    
    Examples:
        >>> memory = SheetBaseMemory(
        ...     apps_script_url='https://script.google.com/macros/s/ID/exec',
        ...     user_id='user_123'
        ... )
        >>> 
        >>> # Save a conversation turn
        >>> memory.save_context(
        ...     {"input": "What laptops do you have?"},
        ...     {"output": "We have 5 gaming laptops..."}
        ... )
        >>> 
        >>> # Load conversation history
        >>> history = memory.load_memory_variables({})
        >>> print(history['history'])
    """
    
    def __init__(
        self,
        apps_script_url: Optional[str] = None,
        google_sheets_url: Optional[str] = None,
        user_id: str = "default_user",
        memory_key: str = "history",
        return_messages: bool = True,
        max_history: int = 10
    ):
        """
        Initialize SheetBase memory.
        
        Args:
            apps_script_url: Google Apps Script URL (for write access)
            google_sheets_url: Google Sheets URL (for read-only)
            user_id: User identifier for filtering conversations
            memory_key: Key for memory in chain inputs
            return_messages: Whether to return messages or strings
            max_history: Maximum conversation turns to load
        """
        mode = 'appsscript' if apps_script_url else 'simple'
        
        self.client = SheetBaseClient(
            mode=mode,
            apps_script_url=apps_script_url,
            google_sheets_url=google_sheets_url
        )
        
        self.user_id = user_id
        self.memory_key = memory_key
        self.return_messages = return_messages
        self.max_history = max_history
    
    @property
    def memory_variables(self) -> List[str]:
        """Return memory variables."""
        return [self.memory_key]
    
    def load_memory_variables(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """
        Load conversation history from Google Sheets.
        
        Args:
            inputs: Current chain inputs (unused but kept for compatibility)
            
        Returns:
            Dictionary with conversation history under memory_key
        """
        try:
            # Search for user's conversation history
            records = self.client.search(
                query=self.user_id,
                user_id=self.user_id,
                limit=self.max_history
            )
            
            if self.return_messages:
                messages: List[BaseMessage] = []
                for record in records:
                    user_msg = record.get('user_request', '')
                    ai_msg = record.get('agent_response', '')
                    
                    if user_msg:
                        messages.append(HumanMessage(content=user_msg))
                    if ai_msg:
                        messages.append(AIMessage(content=ai_msg))
                
                return {self.memory_key: messages}
            else:
                # Return as formatted string
                history_str = "\n".join([
                    f"User: {r.get('user_request', '')}\nAI: {r.get('agent_response', '')}"
                    for r in records
                ])
                return {self.memory_key: history_str}
                
        except Exception:
            # Return empty history on error
            return {self.memory_key: [] if self.return_messages else ""}
    
    def save_context(self, inputs: Dict[str, Any], outputs: Dict[str, Any]) -> None:
        """
        Save conversation turn to Google Sheets.
        
        Args:
            inputs: User inputs (should contain 'input' key)
            outputs: AI outputs (should contain 'output' key)
        """
        if self.client.mode == 'simple':
            # Cannot save in read-only mode
            return
        
        user_request = inputs.get('input', '')
        agent_response = outputs.get('output', '')
        
        if not user_request and not agent_response:
            return
        
        try:
            record = {
                'timestamp': datetime.utcnow().isoformat(),
                'user_id': self.user_id,
                'user_request': user_request,
                'agent_response': agent_response
            }
            
            self.client.create(values=record)
            
        except Exception as e:
            import logging
            logging.warning(f"Failed to save conversation to SheetBase: {e}")
    
    def clear(self) -> None:
        """
        Clear memory (note: does not delete from Google Sheets).
        
        To delete records from Google Sheets, use client.delete() manually
        with the row numbers.
        """
        pass
    
    def get_conversation_history(self) -> List[Dict[str, Any]]:
        """
        Get raw conversation history records.
        
        Returns:
            List of conversation records from Google Sheets
        """
        try:
            return self.client.search(
                query=self.user_id,
                user_id=self.user_id,
                limit=self.max_history
            )
        except Exception:
            return []
