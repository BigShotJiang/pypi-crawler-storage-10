"""Custom exceptions for SheetBase operations."""

class SheetBaseError(Exception):
    """Base exception for all SheetBase errors."""
    pass

class ConnectionError(SheetBaseError):
    """Raised when connection to SheetBase fails."""
    pass

class InvalidURLError(SheetBaseError):
    """Raised when URL format is invalid."""
    pass

class OperationError(SheetBaseError):
    """Raised when an operation fails or is not supported."""
    pass
