"""
LangChain Retriever implementation for SheetBase.

Enables RAG (Retrieval-Augmented Generation) using Google Sheets as knowledge base.
"""

from typing import List, Optional
from langchain_core.retrievers import BaseRetriever
from langchain_core.documents import Document
from langchain_core.callbacks import CallbackManagerForRetrieverRun
from pydantic import Field

from .client import SheetBaseClient


class SheetBaseRetriever(BaseRetriever):
    """
    Retriever for Google Sheets using fuzzy keyword search.
    
    Converts sheet records to LangChain Documents for RAG pipelines.
    
    Examples:
        >>> retriever = SheetBaseRetriever(
        ...     google_sheets_url='https://docs.google.com/spreadsheets/d/ID/edit',
        ...     content_column='Description',
        ...     metadata_columns=['Product Name', 'Price']
        ... )
        >>> 
        >>> from langchain.chains import RetrievalQA
        >>> from langchain_openai import ChatOpenAI
        >>> 
        >>> qa = RetrievalQA.from_chain_type(
        ...     llm=ChatOpenAI(),
        ...     retriever=retriever
        ... )
        >>> answer = qa.invoke({"query": "What gaming laptops are available?"})
    """
    
    client: SheetBaseClient = Field(default=None)
    content_column: str = Field(default="content")
    metadata_columns: List[str] = Field(default_factory=list)
    max_results: int = Field(default=5)
    
    def __init__(
        self,
        google_sheets_url: Optional[str] = None,
        apps_script_url: Optional[str] = None,
        content_column: str = "content",
        metadata_columns: Optional[List[str]] = None,
        max_results: int = 5,
        **kwargs
    ):
        """
        Initialize SheetBase retriever.
        
        Args:
            google_sheets_url: Google Sheets URL (read-only mode)
            apps_script_url: Apps Script URL (for write access)
            content_column: Column name to use as document content
            metadata_columns: Columns to include as document metadata
            max_results: Maximum documents to return per query
        """
        # Determine mode
        mode = 'appsscript' if apps_script_url else 'simple'
        
        # Create client
        client = SheetBaseClient(
            mode=mode,
            google_sheets_url=google_sheets_url,
            apps_script_url=apps_script_url
        )
        
        if metadata_columns is None:
            metadata_columns = []
        
        super().__init__(
            client=client,
            content_column=content_column,
            metadata_columns=metadata_columns,
            max_results=max_results,
            **kwargs
        )
    
    def _get_relevant_documents(
        self,
        query: str,
        *,
        run_manager: Optional[CallbackManagerForRetrieverRun] = None
    ) -> List[Document]:
        """
        Retrieve relevant documents from Google Sheets.
        
        Args:
            query: Search query
            run_manager: Callback manager
            
        Returns:
            List of LangChain Documents
        """
        try:
            # Search Google Sheets
            records = self.client.search(query=query, limit=self.max_results)
            
            documents = []
            for record in records:
                # Extract content
                content = str(record.get(self.content_column, ''))
                
                # If content column doesn't exist, use all fields
                if not content or content == '':
                    content = ' | '.join([
                        f"{k}: {v}" for k, v in record.items() 
                        if not k.startswith('_')
                    ])
                
                # Extract metadata
                metadata = {
                    'source': 'google_sheets',
                    'row': record.get('__row', 0),
                    'score': record.get('_score', 0.0)
                }
                
                # Add specified metadata columns
                for col in self.metadata_columns:
                    if col in record:
                        metadata[col] = record[col]
                
                documents.append(Document(
                    page_content=content,
                    metadata=metadata
                ))
            
            return documents
            
        except Exception as e:
            # Return empty list on error
            import logging
            logging.error(f"SheetBase retriever failed: {e}")
            return []
