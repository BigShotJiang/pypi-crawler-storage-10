"""CLI entry point for SheetBase utilities."""

import sys
from .telemetry import print_usage_stats

def main():
    """Main CLI handler."""
    if len(sys.argv) > 1 and sys.argv[1] == 'stats':
        print_usage_stats()
    else:
        print("SheetBase CLI")
        print("\nUsage:")
        print("  python -m langchain_sheetbase stats    # View usage statistics")

if __name__ == '__main__':
    main()
