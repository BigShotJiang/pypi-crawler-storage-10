"""
LangChain SheetBase - Google Sheets as LangChain Database and Memory.

Author: Charles Lepoittevin
License: MIT
"""

__version__ = "0.1.0"

from .client import SheetBaseClient
from .tools import (
    SheetBaseSearchTool,
    SheetBaseCreateTool,
    SheetBaseUpdateTool,
    SheetBaseDeleteTool,
    create_sheetbase_tools
)
from .memory import SheetBaseMemory
from .retriever import SheetBaseRetriever
from .telemetry import (
    UsageTracker,
    get_tracker,
    configure_langsmith,
    print_usage_stats
)
from .exceptions import (
    SheetBaseError,
    ConnectionError,
    InvalidURLError,
    OperationError
)

__all__ = [
    # Client
    'SheetBaseClient',
    
    # Tools
    'SheetBaseSearchTool',
    'SheetBaseCreateTool',
    'SheetBaseUpdateTool',
    'SheetBaseDeleteTool',
    'create_sheetbase_tools',
    
    # Memory & Retriever
    'SheetBaseMemory',
    'SheetBaseRetriever',
    
    # Telemetry
    'UsageTracker',
    'get_tracker',
    'configure_langsmith',
    'print_usage_stats',
    
    # Exceptions
    'SheetBaseError',
    'ConnectionError',
    'InvalidURLError',
    'OperationError',
]
