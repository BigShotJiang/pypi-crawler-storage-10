"""MCP resources for Katana Manufacturing ERP.

This module contains resource implementations that provide read-only access
to Katana data.
"""

__all__ = []
