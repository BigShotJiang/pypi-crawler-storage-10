# StatsNB - Flexible Naive Bayes Classifiers

[![PyPI version](https://badge.fury.io/py/statsnb.svg)](https://badge.fury.io/py/statsnb)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Naive Bayes classifiers using **any** scipy.stats continuous distribution, fully compatible with scikit-learn.

## What is StatsNB?

`GaussianNB` from scikit-learn assumes Gaussian (normal) distributions. But what if your data follows a different distribution?

**StatsNB** provides two classifiers:
- **`MomentNB`**: Fast Method of Moments estimation with GaussianNB-like features
- **`StatsNB`**: Flexible MLE estimation supporting 80+ distributions

## When to Use Which?

| Use Case | Recommendation |
|----------|----------------|
| Speed + incremental learning needed | `MomentNB` |
| Need sample weights | `MomentNB` |
| Large datasets (>10K samples) | `MomentNB` |
| Exotic distributions (beta, cauchy, lognorm) | `StatsNB` |
| Small datasets with flexible distribution needs | `StatsNB` |
| Need to fix parameters during fitting | `StatsNB` |

## Installation
```bash
pip install statsnb
```

## Quick Start

### MomentNB: Fast with GaussianNB Features
```python
from statsnb import MomentNB
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split

X, y = load_iris(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=42)

# Supports: 'norm', 'gamma', 'expon', 'laplace'
clf = MomentNB(dist='gamma', var_smoothing=1e-9)
clf.fit(X_train, y_train)
print(f"Accuracy: {clf.score(X_test, y_test):.3f}")

# ✅ Supports incremental learning
for X_batch, y_batch in batches:
    clf.partial_fit(X_batch, y_batch, classes=[0, 1, 2])

# ✅ Supports sample weights
clf.fit(X_train, y_train, sample_weight=weights)
```

### StatsNB: Maximum Flexibility
```python
from statsnb import StatsNB

# Use any scipy.stats distribution
clf = StatsNB(dist='t')  # Student's t-distribution
clf.fit(X_train, y_train)

# Try different distributions
for dist in ['norm', 't', 'laplace', 'cauchy', 'lognorm']:
    clf = StatsNB(dist=dist)
    clf.fit(X_train, y_train)
    print(f"{dist:10s}: {clf.score(X_test, y_test):.3f}")
```

## Performance Comparison

| Feature | GaussianNB | MomentNB | StatsNB |
|---------|-----------|----------|---------|
| **Speed** | ⚡ Fastest | ⚡ Fast (~same) | 🐌 5-10x slower |
| **Incremental learning** | ✅ Yes | ✅ Yes | ❌ No |
| **Sample weights** | ✅ Yes | ✅ Yes | ❌ No |
| **Distributions** | Normal only | 4 distributions | 80+ distributions |
| **Numerical stability** | ✅ var_smoothing | ✅ var_smoothing | ⚠️ Data-dependent |

**MomentNB** uses analytical Method of Moments formulas (like GaussianNB), making it ~100x faster than StatsNB's numerical optimization.

## Advanced Features

### MomentNB: Variance Smoothing
```python
# Prevent numerical errors with small variances
clf = MomentNB(dist='gamma', var_smoothing=1e-9)
clf.fit(X_train, y_train)
```

### StatsNB: Fix Parameters During Fitting
```python
# Fix degrees of freedom for t-distribution
clf = StatsNB(dist='t', fit_args={'fdf': 5})
clf.fit(X_train, y_train)

# Fix location for exponential distribution
clf = StatsNB(dist='expon', fit_args={'floc': 0})
clf.fit(X_train, y_train)
```

### StatsNB: Use Method of Moments (When Available)
```python
# MM is faster than MLE for some distributions
clf = StatsNB(dist='norm', fit_args={'method': 'MM'})
clf.fit(X_train, y_train)
```

### Custom Priors (Both Classifiers)
```python
# Specify class prior probabilities
clf = MomentNB(dist='gamma', priors=[0.2, 0.3, 0.5])
clf.fit(X_train, y_train)
```

## Supported Distributions

### MomentNB (Fast, MM-based)
- `'norm'` - Normal (Gaussian)
- `'gamma'` - Gamma
- `'expon'` - Exponential
- `'laplace'` - Laplace

### StatsNB (Flexible, MLE-based)
All continuous distributions from scipy.stats, including:
- `'t'` - Student's t (robust to outliers)
- `'cauchy'` - Cauchy (very heavy-tailed)
- `'lognorm'` - Log-normal (skewed positive data)
- `'beta'` - Beta (bounded [0,1] data)
- `'weibull_min'` - Weibull
- See [scipy.stats documentation](https://docs.scipy.org/doc/scipy/reference/stats.html) for complete list

## When to Use StatsNB?

**Use StatsNB (not GaussianNB) when:**
- Your data is heavy-tailed (try `t` or `cauchy` distributions)
- Your data is bounded (try `beta` distribution)
- Your data is strictly positive and skewed (try `gamma` or `lognorm`)
- You want to experiment with different distributions

**Use MomentNB when:**
- You need speed comparable to GaussianNB
- You need incremental learning or sample weights
- Your distribution is norm, gamma, expon, or laplace

## API Compatibility

Both classifiers are fully compatible with scikit-learn:
```python
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV

# Use in pipelines
pipe = Pipeline([
    ('scaler', StandardScaler()),
    ('clf', StatsNB())
])
pipe.fit(X_train, y_train)

# Use in grid search
param_grid = {'clf__dist': ['norm', 't', 'laplace']}
grid = GridSearchCV(pipe, param_grid, cv=5)
grid.fit(X_train, y_train)
print(f"Best distribution: {grid.best_params_}")
```

## Examples

See the [`examples/`](examples/) directory for more:
- `comparison_moment_vs_mle.py` - Performance comparison
- `incremental_learning.py` - Using MomentNB's partial_fit
- `distribution_selection.py` - Choosing the right distribution

## Requirements

- Python ≥ 3.8
- numpy ≥ 1.20.0
- scipy ≥ 1.7.0
- scikit-learn ≥ 1.0.0

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

MIT License - see [LICENSE](LICENSE) file for details.

## Citation

If you use StatsNB in your research, please cite:
```bibtex
@software{statsnb2025,
  author = {Your Name},
  title = {StatsNB: Flexible Naive Bayes Classifiers},
  year = {2025},
  url = {https://github.com/yourusername/statsnb}
}
```

## Acknowledgments

- Built on top of [scikit-learn](https://scikit-learn.org/) and [scipy](https://scipy.org/)
- Inspired by the flexibility needs of real-world data science