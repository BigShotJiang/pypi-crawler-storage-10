# tests/test_all_distributions.py

import numpy as np
import pytest
import warnings
from scipy import stats
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import pandas as pd
from collections import defaultdict

from statsnb import StatsNB


class TestAllSciPyDistributions:

    @pytest.fixture(scope='class')
    def complex_dataset(self):
        """
        创建复杂的、不平衡的、多样化的数据集
        
        特点：
        - 10000 样本
        - 30 特征
        - 5 类别，不平衡
        - 特征类型多样：连续、离散、正值、负值
        """
        np.random.seed(42)

        # 基础分类数据
        X_base, y = make_classification(
            n_samples=10000,
            n_features=30,
            n_classes=5,
            n_informative=20,
            n_redundant=5,
            n_clusters_per_class=2,
            weights=[0.1, 0.15, 0.25, 0.3, 0.2],  # 不平衡
            flip_y=0.01,
            random_state=42
        )

        # 创建多样化的特征
        X = X_base.copy()
        n_samples, n_features = X.shape

        # 特征 0-9: 标准正态分布（有正有负）
        X[:, 0:10] = StandardScaler().fit_transform(X[:, 0:10])

        # 特征 10-14: 仅正值（指数分布风格）
        X[:, 10:15] = np.abs(X[:, 10:15]) + 0.5

        # 特征 15-19: 大范围正值（对数正态风格）
        X[:, 15:20] = np.exp(X[:, 15:20] * 0.5)

        # 特征 20-24: [0, 1] 范围（Beta 分布风格）
        from sklearn.preprocessing import MinMaxScaler
        X[:, 20:25] = MinMaxScaler().fit_transform(X[:, 20:25])

        # 特征 25-29: 离散值（模拟计数）
        X[:, 25:30] = np.round(np.abs(X[:, 25:30]) * 10)

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.3, random_state=42, stratify=y
        )

        return X_train, X_test, y_train, y_test

    @pytest.fixture(scope='class')
    def all_continuous_distributions(self):
        """
        获取所有 scipy.stats 连续分布
        
        排除：
        - 离散分布
        - 多变量分布
        - 已废弃的分布
        """
        all_dists = []

        # 遍历 scipy.stats.__all__
        for name in dir(stats):
            if name.startswith('_'):
                continue

            obj = getattr(stats, name)

            # 检查是否是连续分布
            if hasattr(obj, 'pdf') and hasattr(obj, 'fit') and hasattr(obj, 'numargs'):
                # 排除一些特殊的分布
                if name not in [
                    'rv_continuous',  # 基类
                    'rv_discrete',    # 离散分布基类
                    'rv_histogram',   # 直方图分布
                ]:
                    all_dists.append(name)

        return sorted(all_dists)

    def test_list_all_distributions(self, all_continuous_distributions):
        """列出所有将要测试的分布"""
        print(f"\n{'='*70}")
        print(f"Found {len(all_continuous_distributions)} continuous distributions")
        print(f"{'='*70}")

        for i, dist_name in enumerate(all_continuous_distributions, 1):
            print(f"{i:3d}. {dist_name}")

        print(f"{'='*70}\n")

        assert len(all_continuous_distributions) > 50, "Should find many distributions"

    @pytest.mark.slow
    def test_all_distributions_comprehensive(
            self,
            complex_dataset,
            all_continuous_distributions
    ):
        """
        全面测试所有分布
        
        记录：
        1. 成功/失败状态
        2. 失败原因
        3. 准确率（如果成功）
        4. 拟合时间
        5. 参数数量
        6. 数值问题（NaN/Inf）
        """
        X_train, X_test, y_train, y_test = complex_dataset

        results = {
            'success': [],
            'fit_failed': [],
            'predict_failed': [],
            'numerical_issues': [],
            'poor_performance': [],
        }

        detailed_results = []

        print(f"\n{'='*80}")
        print(f"Testing {len(all_continuous_distributions)} distributions")
        print(f"{'='*80}\n")

        for i, dist_name in enumerate(all_continuous_distributions, 1):
            result = {
                'name': dist_name,
                'status': 'unknown',
                'error': None,
                'score': None,
                'n_params': None,
                'has_nan': False,
                'has_inf': False,
            }

            try:
                # 创建分类器
                clf = StatsNB(dist=dist_name)

                # 获取参数数量
                dist_obj = getattr(stats, dist_name)
                result['n_params'] = dist_obj.numargs + 2

                # 拟合
                with warnings.catch_warnings():
                    warnings.filterwarnings('ignore')
                    clf.fit(X_train, y_train)

                result['status'] = 'fit_success'

                # 预测
                y_pred = clf.predict(X_test)
                y_proba = clf.predict_proba(X_test)

                # 检查数值问题
                if np.any(np.isnan(y_proba)):
                    result['has_nan'] = True
                    result['status'] = 'numerical_nan'
                    results['numerical_issues'].append(dist_name)

                if np.any(np.isinf(y_proba)):
                    result['has_inf'] = True
                    result['status'] = 'numerical_inf'
                    results['numerical_issues'].append(dist_name)

                # 计算准确率
                if not result['has_nan'] and not result['has_inf']:
                    score = clf.score(X_test, y_test)
                    result['score'] = score
                    result['status'] = 'success'

                    # 分类性能
                    random_baseline = 0.2  # 5类，最大类30%
                    if score > random_baseline:
                        results['success'].append(dist_name)
                    else:
                        results['poor_performance'].append(dist_name)
                        result['status'] = 'poor_performance'

                    # 打印进度
                    status_symbol = '✓' if score > random_baseline else '○'
                    print(f"{status_symbol} {i:3d}/{len(all_continuous_distributions)} "
                          f"{dist_name:20s} score={score:.3f}")
                else:
                    results['predict_failed'].append(dist_name)
                    print(f"✗ {i:3d}/{len(all_continuous_distributions)} "
                          f"{dist_name:20s} numerical issues")

            except ValueError as e:
                result['status'] = 'fit_failed'
                result['error'] = str(e)
                results['fit_failed'].append(dist_name)
                print(f"✗ {i:3d}/{len(all_continuous_distributions)} "
                      f"{dist_name:20s} fit failed: {str(e)[:50]}")

            except Exception as e:
                result['status'] = 'unknown_error'
                result['error'] = str(e)
                results['fit_failed'].append(dist_name)
                print(f"✗ {i:3d}/{len(all_continuous_distributions)} "
                      f"{dist_name:20s} error: {type(e).__name__}")

            detailed_results.append(result)

        # 生成详细报告
        self._print_summary_report(results, detailed_results)
        self._save_detailed_results(detailed_results)

        # 基本断言：至少应该有一些分布能工作
        assert len(results['success']) > 10, \
            f"Too few successful distributions: {len(results['success'])}"

    def _print_summary_report(self, results, detailed_results):
        """打印汇总报告"""
        print(f"\n{'='*80}")
        print("SUMMARY REPORT")
        print(f"{'='*80}\n")

        total = sum(len(v) for v in results.values())

        print(f"Total distributions tested: {total}")
        print(f"✓ Successful:              {len(results['success'])} "
              f"({len(results['success'])/total*100:.1f}%)")
        print(f"✗ Fit failed:              {len(results['fit_failed'])} "
              f"({len(results['fit_failed'])/total*100:.1f}%)")
        print(f"✗ Predict failed:          {len(results['predict_failed'])} "
              f"({len(results['predict_failed'])/total*100:.1f}%)")
        print(f"⚠ Numerical issues:        {len(results['numerical_issues'])} "
              f"({len(results['numerical_issues'])/total*100:.1f}%)")
        print(f"○ Poor performance:        {len(results['poor_performance'])} "
              f"({len(results['poor_performance'])/total*100:.1f}%)")

        # Top performers
        successful = [r for r in detailed_results if r['status'] == 'success']
        if successful:
            successful_sorted = sorted(successful, key=lambda x: x['score'], reverse=True)

            print(f"\n{'='*80}")
            print("TOP 10 PERFORMING DISTRIBUTIONS")
            print(f"{'='*80}")
            for i, r in enumerate(successful_sorted[:10], 1):
                print(f"{i:2d}. {r['name']:20s} score={r['score']:.4f} "
                      f"(params={r['n_params']})")

            print(f"\n{'='*80}")
            print("BOTTOM 10 PERFORMING DISTRIBUTIONS (but still working)")
            print(f"{'='*80}")
            for i, r in enumerate(successful_sorted[-10:], 1):
                print(f"{i:2d}. {r['name']:20s} score={r['score']:.4f} "
                      f"(params={r['n_params']})")

        # Failed distributions
        if results['fit_failed']:
            print(f"\n{'='*80}")
            print("FAILED TO FIT (sample)")
            print(f"{'='*80}")
            for name in results['fit_failed'][:10]:
                r = next(r for r in detailed_results if r['name'] == name)
                error_msg = r['error'][:60] if r['error'] else 'Unknown'
                print(f"  • {name:20s} - {error_msg}")
            if len(results['fit_failed']) > 10:
                print(f"  ... and {len(results['fit_failed'])-10} more")

        # Numerical issues
        if results['numerical_issues']:
            print(f"\n{'='*80}")
            print("NUMERICAL ISSUES (NaN/Inf)")
            print(f"{'='*80}")
            for name in results['numerical_issues'][:10]:
                r = next(r for r in detailed_results if r['name'] == name)
                issues = []
                if r['has_nan']:
                    issues.append('NaN')
                if r['has_inf']:
                    issues.append('Inf')
                print(f"  • {name:20s} - {', '.join(issues)}")

        print(f"\n{'='*80}\n")

    def _save_detailed_results(self, detailed_results):
        """保存详细结果到 CSV"""
        try:
            df = pd.DataFrame(detailed_results)
            filename = 'distribution_test_results.csv'
            df.to_csv(filename, index=False)
            print(f"Detailed results saved to: {filename}\n")
        except ImportError:
            print("pandas not available, skipping CSV export\n")

    @pytest.mark.slow
    def test_distribution_categories(self, complex_dataset, all_continuous_distributions):
        """
        按特性分类测试分布
        
        分析哪些类型的分布更容易成功
        """
        X_train, X_test, y_train, y_test = complex_dataset

        categories = {
            'simple': ['norm', 'laplace', 'uniform', 'logistic'],
            'heavy_tailed': ['t', 'cauchy', 'levy', 'levy_stable'],
            'positive_only': ['gamma', 'expon', 'chi2', 'lognorm', 'weibull_min'],
            'bounded': ['beta', 'uniform', 'truncnorm'],
            'skewed': ['gamma', 'lognorm', 'chi2', 'expon'],
        }

        category_results = defaultdict(lambda: {'success': 0, 'total': 0})

        print(f"\n{'='*80}")
        print("DISTRIBUTION CATEGORIES ANALYSIS")
        print(f"{'='*80}\n")

        for category, dist_names in categories.items():
            print(f"\n{category.upper()} distributions:")

            for dist_name in dist_names:
                if dist_name not in all_continuous_distributions:
                    continue

                category_results[category]['total'] += 1

                try:
                    clf = StatsNB(dist=dist_name)
                    with warnings.catch_warnings():
                        warnings.filterwarnings('ignore')
                        clf.fit(X_train, y_train)

                    score = clf.score(X_test, y_test)

                    if score > 0.2 and not np.isnan(score):
                        category_results[category]['success'] += 1
                        print(f"  ✓ {dist_name:20s} score={score:.3f}")
                    else:
                        print(f"  ○ {dist_name:20s} score={score:.3f} (poor)")

                except Exception as e:
                    print(f"  ✗ {dist_name:20s} failed: {type(e).__name__}")

        # 打印分类汇总
        print(f"\n{'='*80}")
        print("CATEGORY SUCCESS RATES")
        print(f"{'='*80}")

        for category in sorted(category_results.keys()):
            results = category_results[category]
            success_rate = results['success'] / results['total'] * 100 if results['total'] > 0 else 0
            print(f"{category:20s}: {results['success']}/{results['total']} "
                  f"({success_rate:.1f}%)")


class TestDistributionStressTest:
    """压力测试：极端情况"""

    @pytest.mark.slow
    def test_all_distributions_extreme_cases(self):
        """
        测试所有分布在极端情况下的表现
        
        极端情况：
        - 非常小的样本
        - 高度不平衡
        - 常数特征
        - 异常值
        """
        # 获取所有分布
        all_dists = []
        for name in dir(stats):
            obj = getattr(stats, name)
            if hasattr(obj, 'pdf') and hasattr(obj, 'fit') and hasattr(obj, 'numargs'):
                if not name.startswith('_') and name not in ['rv_continuous', 'rv_discrete']:
                    all_dists.append(name)

        # 极端数据集
        X_extreme = np.random.randn(50, 5)  # 很小的样本
        X_extreme[0, 0] = 1000  # 异常值
        X_extreme[:, 1] = 1.0   # 常数特征
        y_extreme = np.array([0]*5 + [1]*40 + [2]*5)  # 高度不平衡

        robust_dists = []
        fragile_dists = []

        print(f"\n{'='*80}")
        print("EXTREME CASE STRESS TEST")
        print(f"{'='*80}\n")

        for dist_name in all_dists[:20]:  # 测试前20个作为样本
            try:
                clf = StatsNB(dist=dist_name)
                with warnings.catch_warnings():
                    warnings.filterwarnings('ignore')
                    clf.fit(X_extreme, y_extreme)
                    clf.predict(X_extreme)

                robust_dists.append(dist_name)
                print(f"✓ {dist_name:20s} - robust")

            except Exception:
                fragile_dists.append(dist_name)
                print(f"✗ {dist_name:20s} - fragile")

        print(f"\n{'='*80}")
        print(f"Robust distributions:  {len(robust_dists)}/{len(all_dists[:20])}")
        print(f"Fragile distributions: {len(fragile_dists)}/{len(all_dists[:20])}")
        print(f"{'='*80}\n")


if __name__ == '__main__':
    # 运行测试并生成详细报告
    pytest.main([
        __file__,
        '-v',
        '-s',
        '--tb=short',
        '-m', 'slow',
    ])