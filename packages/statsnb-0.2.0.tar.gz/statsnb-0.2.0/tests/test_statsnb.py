import numpy as np
import pytest
from sklearn.datasets import load_iris, make_classification
from sklearn.model_selection import train_test_split
from sklearn.exceptions import NotFittedError

from statsnb import StatsNB


class TestStatsNBBasic:
    """基本功能测试"""

    def test_initialization(self):
        """测试初始化"""
        clf = StatsNB()
        assert clf.dist == "norm"
        assert clf.priors is None
        assert clf.fit_args is None

    def test_invalid_distribution(self):
        """测试无效的分布名"""
        clf = StatsNB(dist='invalid_dist_name')
        X, y = make_classification(n_samples=50, n_features=4, random_state=42)

        with pytest.raises(ValueError, match="not supported by scipy.stats"):
            clf.fit(X, y)

    def test_fit_creates_attributes(self):
        """测试 fit 后创建必要的属性"""
        clf = StatsNB(dist='norm')
        X, y = make_classification(
            n_samples=100,
            n_features=4,
            n_classes=3,
            n_informative=3,
            n_redundant=0,
            random_state=42
        )

        clf.fit(X, y)

        # 检查必要的属性
        assert hasattr(clf, 'classes_')
        assert hasattr(clf, 'theta_')
        assert hasattr(clf, 'class_prior_')
        assert hasattr(clf, 'log_priors_')
        assert hasattr(clf, 'n_features_in_')
        assert hasattr(clf, 'dist_')

    def test_not_fitted_error(self):
        """测试未拟合就预测会报错"""
        clf = StatsNB()
        X = np.random.randn(10, 4)

        with pytest.raises(NotFittedError):
            clf.predict(X)


class TestStatsNBTrickyDistributions:
    """测试刁钻的分布 - 核心测试"""

    @pytest.fixture
    def real_data(self):
        """使用真实数据（不做任何变换）"""
        X, y = make_classification(
            n_samples=300,
            n_features=10,
            n_classes=3,
            n_informative=8,
            n_redundant=0,
            random_state=42
        )
        # 保持原始数据，可能有负数
        return train_test_split(X, y, test_size=0.3, random_state=42)

    def test_t_distribution(self, real_data):
        """
        t分布测试 - 重尾分布

        挑战：
        - 有自由度参数需要估计
        - 对异常值敏感
        - 数值优化可能不稳定
        """
        X_train, X_test, y_train, y_test = real_data

        clf = StatsNB(dist='t')
        clf.fit(X_train, y_train)

        # 参数检查：t分布有3个参数 (df, loc, scale)
        assert clf.theta_.shape[2] == 3

        # df (自由度) 应该为正
        df_params = clf.theta_[:, :, 0]
        assert np.all(df_params > 0), "Degrees of freedom must be positive"

        # scale 应该为正
        scale_params = clf.theta_[:, :, 2]
        assert np.all(scale_params > 0), "Scale must be positive"

        # 预测应该正常工作
        y_pred = clf.predict(X_test)
        assert y_pred.shape == y_test.shape

        # 概率预测不应该有 NaN 或 Inf
        y_proba = clf.predict_proba(X_test)
        assert not np.any(np.isnan(y_proba)), "t-dist produced NaN probabilities"
        assert not np.any(np.isinf(y_proba)), "t-dist produced Inf probabilities"
        assert np.allclose(y_proba.sum(axis=1), 1.0)

        # 准确率应该合理（至少比随机好）
        score = clf.score(X_test, y_test)
        random_baseline = 1.0 / len(np.unique(y_test))
        assert score > random_baseline, \
            f"t-dist score {score:.3f} not better than random {random_baseline:.3f}"

        print(f"\nt-distribution score: {score:.3f}")

    def test_cauchy_distribution(self, real_data):
        """
        Cauchy分布测试 - 最刁钻的分布

        挑战：
        - 没有均值和方差（不存在）
        - 极端的重尾
        - MLE 非常困难
        - 数值优化经常失败
        """
        X_train, X_test, y_train, y_test = real_data

        clf = StatsNB(dist='cauchy')

        try:
            clf.fit(X_train, y_train)

            # 如果能成功拟合，检查参数
            assert clf.theta_.shape[2] == 2  # loc, scale

            # scale 必须为正
            scale_params = clf.theta_[:, :, 1]
            assert np.all(scale_params > 0), "Cauchy scale must be positive"

            # 尝试预测
            y_pred = clf.predict(X_test)
            y_proba = clf.predict_proba(X_test)

            # Cauchy 很难拟合，但至少不应该崩溃
            assert not np.any(np.isnan(y_proba)), "Cauchy produced NaN"
            assert not np.any(np.isinf(y_proba)), "Cauchy produced Inf"

            score = clf.score(X_test, y_test)
            print(f"\nCauchy distribution score: {score:.3f}")

            # Cauchy 效果可能很差，但应该能运行
            assert score >= 0, "Cauchy score should be non-negative"

        except ValueError as e:
            # Cauchy 拟合可能失败，这是可以接受的
            pytest.skip(f"Cauchy fitting failed (expected): {str(e)}")

    def test_gamma_distribution(self, real_data):
        """
        Gamma分布测试 - 支撑集为正数

        挑战：
        - 需要正数据（通过 loc/scale 调整）
        - 有形状参数需要估计
        - 对负数和零敏感
        """
        X_train, X_test, y_train, y_test = real_data

        clf = StatsNB(dist='gamma')
        clf.fit(X_train, y_train)

        # Gamma 有3个参数 (shape, loc, scale)
        assert clf.theta_.shape[2] == 3

        # shape 应该为正
        shape_params = clf.theta_[:, :, 0]
        assert np.all(shape_params > 0), "Gamma shape must be positive"

        # scale 应该为正
        scale_params = clf.theta_[:, :, 2]
        assert np.all(scale_params > 0), "Gamma scale must be positive"

        # 检查 loc 是否合理调整了数据范围
        # Gamma 应该通过 loc 来处理负数
        loc_params = clf.theta_[:, :, 1]
        print(f"\nGamma loc range: [{loc_params.min():.3f}, {loc_params.max():.3f}]")

        # 预测
        y_pred = clf.predict(X_test)
        y_proba = clf.predict_proba(X_test)

        assert not np.any(np.isnan(y_proba)), "Gamma produced NaN"
        assert not np.any(np.isinf(y_proba)), "Gamma produced Inf"

        score = clf.score(X_test, y_test)
        random_baseline = 1.0 / len(np.unique(y_test))
        assert score > random_baseline, \
            f"Gamma score {score:.3f} not better than random {random_baseline:.3f}"

        print(f"Gamma distribution score: {score:.3f}")

    def test_beta_distribution(self, real_data):
        """
        Beta分布测试 - 支撑集为 [0, 1]

        挑战：
        - 需要数据在 [0, 1] 范围（通过 loc/scale 调整）
        - 有两个形状参数
        - 边界敏感
        """
        X_train, X_test, y_train, y_test = real_data

        clf = StatsNB(dist='beta')
        clf.fit(X_train, y_train)

        # Beta 有4个参数 (a, b, loc, scale)
        assert clf.theta_.shape[2] == 4

        # a, b 都应该为正
        a_params = clf.theta_[:, :, 0]
        b_params = clf.theta_[:, :, 1]
        assert np.all(a_params > 0), "Beta parameter a must be positive"
        assert np.all(b_params > 0), "Beta parameter b must be positive"

        # scale 应该为正
        scale_params = clf.theta_[:, :, 3]
        assert np.all(scale_params > 0), "Beta scale must be positive"

        # 检查 loc 和 scale 是否合理调整了数据范围
        loc_params = clf.theta_[:, :, 2]
        print(f"\nBeta loc range: [{loc_params.min():.3f}, {loc_params.max():.3f}]")
        print(f"Beta scale range: [{scale_params.min():.3f}, {scale_params.max():.3f}]")

        # 预测
        y_pred = clf.predict(X_test)
        y_proba = clf.predict_proba(X_test)

        assert not np.any(np.isnan(y_proba)), "Beta produced NaN"
        assert not np.any(np.isinf(y_proba)), "Beta produced Inf"

        score = clf.score(X_test, y_test)
        random_baseline = 1.0 / len(np.unique(y_test))
        assert score > random_baseline, \
            f"Beta score {score:.3f} not better than random {random_baseline:.3f}"

        print(f"Beta distribution score: {score:.3f}")

    def test_lognorm_distribution(self, real_data):
        """
        对数正态分布测试 - 支撑集为正数

        挑战：
        - 需要正数据
        - 参数估计可能不稳定
        - 高度右偏
        """
        X_train, X_test, y_train, y_test = real_data

        clf = StatsNB(dist='lognorm')
        clf.fit(X_train, y_train)

        # Lognorm 有3个参数 (s, loc, scale)
        assert clf.theta_.shape[2] == 3

        # s (shape) 应该为正
        s_params = clf.theta_[:, :, 0]
        assert np.all(s_params > 0), "Lognorm s parameter must be positive"

        # scale 应该为正
        scale_params = clf.theta_[:, :, 2]
        assert np.all(scale_params > 0), "Lognorm scale must be positive"

        # 预测
        y_pred = clf.predict(X_test)
        y_proba = clf.predict_proba(X_test)

        assert not np.any(np.isnan(y_proba)), "Lognorm produced NaN"
        assert not np.any(np.isinf(y_proba)), "Lognorm produced Inf"

        score = clf.score(X_test, y_test)
        random_baseline = 1.0 / len(np.unique(y_test))
        assert score > random_baseline, \
            f"Lognorm score {score:.3f} not better than random {random_baseline:.3f}"

        print(f"Lognorm distribution score: {score:.3f}")


class TestStatsNBFitArgs:
    """测试 fit_args 参数"""

    def test_fixed_location(self):
        """测试固定位置参数"""
        X, y = make_classification(n_samples=100, n_features=4, random_state=42)

        # 固定 loc=0
        clf = StatsNB(dist='norm', fit_args={'floc': 0})
        clf.fit(X, y)

        # 检查 loc 参数都是 0
        locs = clf.theta_[:, :, 0]
        assert np.allclose(locs, 0), "Fixed loc should be 0"

    def test_fixed_degrees_of_freedom(self):
        """测试固定 t 分布的自由度"""
        X, y = make_classification(n_samples=100, n_features=4, random_state=42)

        fixed_df = 5.0
        clf = StatsNB(dist='t', fit_args={'fdf': fixed_df})
        clf.fit(X, y)

        # 检查 df 参数都是固定值
        df_params = clf.theta_[:, :, 0]
        assert np.allclose(df_params, fixed_df), f"Fixed df should be {fixed_df}"

        print(f"\nFixed df: all parameters = {fixed_df}")

    def test_method_of_moments(self):
        """测试矩估计方法（对支持的分布）"""
        X, y = make_classification(n_samples=100, n_features=4, random_state=42)

        # 测试 norm 的 MM
        clf_mm = StatsNB(dist='norm', fit_args={'method': 'MM'})
        clf_mm.fit(X, y)

        # MM 应该成功拟合
        assert clf_mm.theta_.shape[2] == 2

        # 检查参数合理性
        scales = clf_mm.theta_[:, :, 1]
        assert np.all(scales > 0), "MM scales should be positive"


class TestStatsNBNumericalStability:
    """数值稳定性测试 - 极端情况"""

    def test_constant_features(self):
        """测试常数特征（方差为0）"""
        X = np.ones((100, 3))  # 所有特征都是常数
        X[:, 1] = 2.0  # 第二个特征也是常数但值不同
        y = np.random.choice([0, 1, 2], size=100)

        clf = StatsNB(dist='norm')

        # 应该能处理或给出明确错误
        try:
            clf.fit(X, y)
            # 如果成功，检查预测不会崩溃
            y_pred = clf.predict(X)
            assert len(y_pred) == len(y)
        except (ValueError, RuntimeWarning) as e:
            pytest.skip(f"Constant features caused expected error: {str(e)}")

    def test_extreme_values(self):
        """测试极端值"""
        X = np.random.randn(100, 4)
        X[0, 0] = 1e10   # 极大值
        X[1, 1] = -1e10  # 极小值
        y = np.random.choice([0, 1], size=100)

        clf = StatsNB(dist='t')  # t 分布应该对异常值鲁棒
        clf.fit(X, y)

        y_pred = clf.predict(X)
        y_proba = clf.predict_proba(X)

        # 不应该产生 NaN
        assert not np.any(np.isnan(y_proba)), "Extreme values caused NaN"

    def test_small_sample_size(self):
        """测试小样本"""
        X = np.random.randn(15, 3)  # 每类只有5个样本
        y = np.array([0]*5 + [1]*5 + [2]*5)

        clf = StatsNB(dist='norm')
        clf.fit(X, y)

        # 应该能拟合
        assert clf.theta_.shape == (3, 3, 2)

        # 应该能预测
        y_pred = clf.predict(X)
        assert len(y_pred) == 15


class TestStatsNBPriors:
    """测试先验概率"""

    def test_empirical_priors(self):
        """测试经验先验"""
        X = np.random.randn(100, 3)
        y = np.array([0]*30 + [1]*50 + [2]*20)

        clf = StatsNB(dist='norm')
        clf.fit(X, y)

        expected_priors = np.array([0.3, 0.5, 0.2])
        assert np.allclose(clf.class_prior_, expected_priors)

    def test_custom_priors(self):
        """测试自定义先验"""
        X = np.random.randn(100, 3)
        y = np.random.choice([0, 1, 2], size=100)

        custom_priors = [0.2, 0.3, 0.5]
        clf = StatsNB(dist='norm', priors=custom_priors)
        clf.fit(X, y)

        assert np.allclose(clf.class_prior_, custom_priors)


class TestStatsNBRealData:
    """真实数据测试"""

    def test_iris_with_tricky_distributions(self):
        """在 Iris 数据集上测试刁钻分布"""
        X, y = load_iris(return_X_y=True)
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.3, random_state=42
        )

        distributions = ['norm', 't', 'gamma', 'beta', 'lognorm']
        scores = {}

        for dist in distributions:
            clf = StatsNB(dist=dist)

            try:
                clf.fit(X_train, y_train)
                score = clf.score(X_test, y_test)
                scores[dist] = score

                print(f"\n{dist:10s}: accuracy = {score:.3f}")

                # 所有分布都应该比随机好
                assert score > 0.33, f"{dist} should beat random (0.33)"

            except Exception as e:
                pytest.skip(f"{dist} failed on Iris (may be expected): {str(e)}")

        # 至少应该有一个分布工作得很好
        if scores:
            best_score = max(scores.values())
            assert best_score > 0.7, f"Best score {best_score:.3f} too low"


class TestStatsNBComparison:
    """与其他方法的对比测试"""

    def test_compare_distributions_on_same_data(self):
        """比较不同分布在同一数据集上的表现"""
        X, y = make_classification(
            n_samples=200,
            n_features=5,
            n_classes=3,
            n_informative=3,
            random_state=42
        )
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.3, random_state=42
        )

        distributions = ['norm', 't', 'laplace']
        results = {}

        print("\n" + "="*50)
        print("Distribution Comparison")
        print("="*50)

        for dist in distributions:
            clf = StatsNB(dist=dist)
            clf.fit(X_train, y_train)
            score = clf.score(X_test, y_test)
            results[dist] = score

            print(f"{dist:10s}: {score:.3f}")

        # 所有分布都应该有合理的表现
        for dist, score in results.items():
            assert score > 0.3, f"{dist} score {score:.3f} too low"

        print("="*50)


if __name__ == '__main__':
    pytest.main([__file__, '-v', '-s'])