"""
StatsNB - Flexible Naive Bayes classifiers using scipy.stats distributions.
"""

from .naive_bayes import StatsNB,MomentNB

__version__ = "0.2.0"
__all__ = ["StatsNB","MomentNB"]