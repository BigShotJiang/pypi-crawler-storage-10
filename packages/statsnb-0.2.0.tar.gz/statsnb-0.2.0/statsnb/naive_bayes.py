import warnings
from abc import ABCMeta, abstractmethod

import numpy as np
from scipy.special import logsumexp
from scipy import stats

from sklearn.base import BaseEstimator, ClassifierMixin, _fit_context
from sklearn.naive_bayes import GaussianNB
from scipy.special import gammaln
from sklearn.utils.validation import (
    check_is_fitted,
    validate_data,
)

__all__ = [
    "StatsNB",
    "MomentNB"
]
class _BaseNB(ClassifierMixin, BaseEstimator, metaclass=ABCMeta):
    """Abstract base class for naive Bayes estimators"""

    @abstractmethod
    def _joint_log_likelihood(self, X):
        """Compute the unnormalized posterior log probability of X

        I.e. ``log P(c) + log P(x|c)`` for all rows x of X, as an array-like of
        shape (n_samples, n_classes).

        Public methods predict, predict_proba, predict_log_proba, and
        predict_joint_log_proba pass the input through _check_X before handing it
        over to _joint_log_likelihood. The term "joint log likelihood" is used
        interchangibly with "joint log probability".
        """

    @abstractmethod
    def _check_X(self, X):
        """To be overridden in subclasses with the actual checks.

        Only used in predict* methods.
        """

    def predict_joint_log_proba(self, X):
        """Return joint log probability estimates for the test vector X.

        For each row x of X and class y, the joint log probability is given by
        ``log P(x, y) = log P(y) + log P(x|y),``
        where ``log P(y)`` is the class prior probability and ``log P(x|y)`` is
        the class-conditional probability.

        Parameters
        ----------
        X : array-like of shape (n_samples, n_features)
            The input samples.

        Returns
        -------
        C : ndarray of shape (n_samples, n_classes)
            Returns the joint log-probability of the samples for each class in
            the model. The columns correspond to the classes in sorted
            order, as they appear in the attribute :term:`classes_`.
        """
        check_is_fitted(self)
        X = self._check_X(X)
        return self._joint_log_likelihood(X)

    def predict(self, X):
        """
        Perform classification on an array of test vectors X.

        Parameters
        ----------
        X : array-like of shape (n_samples, n_features)
            The input samples.

        Returns
        -------
        C : ndarray of shape (n_samples,)
            Predicted target values for X.
        """
        check_is_fitted(self)
        X = self._check_X(X)
        jll = self._joint_log_likelihood(X)
        return self.classes_[np.argmax(jll, axis=1)]

    def predict_log_proba(self, X):
        """
        Return log-probability estimates for the test vector X.

        Parameters
        ----------
        X : array-like of shape (n_samples, n_features)
            The input samples.

        Returns
        -------
        C : array-like of shape (n_samples, n_classes)
            Returns the log-probability of the samples for each class in
            the model. The columns correspond to the classes in sorted
            order, as they appear in the attribute :term:`classes_`.
        """
        check_is_fitted(self)
        X = self._check_X(X)
        jll = self._joint_log_likelihood(X)
        # normalize by P(x) = P(f_1, ..., f_n)
        log_prob_x = logsumexp(jll, axis=1)
        return jll - np.atleast_2d(log_prob_x).T

    def predict_proba(self, X):
        """
        Return probability estimates for the test vector X.

        Parameters
        ----------
        X : array-like of shape (n_samples, n_features)
            The input samples.

        Returns
        -------
        C : array-like of shape (n_samples, n_classes)
            Returns the probability of the samples for each class in
            the model. The columns correspond to the classes in sorted
            order, as they appear in the attribute :term:`classes_`.
        """
        return np.exp(self.predict_log_proba(X))
class StatsNB(_BaseNB):
    """
    Naive Bayes classifier using any scipy.stats continuous dist_.
    ## Performance Note
    Unlike `GaussianNB`, which uses analytical solutions for maximum speed,
    `StatsNB` must numerically compute log-likelihoods for each feature.
    This makes it ~5-10x slower than `GaussianNB`, but still efficient for
    most datasets. The flexibility to use any distribution is worth the
    modest performance cost.
    Parameters
    ----------
    priors : array-like of shape (n_classes,), default=None
        Prior probabilities of the classes. If specified, the priors are not
        adjusted according to the data.

    dist : str, default="norm"
        Name of the scipy.stats continuous dist_ to use.

    Attributes
    ----------
    class_count_ : ndarray of shape (n_classes,)
        number of training samples observed in each class.

    class_prior_ : ndarray of shape (n_classes,)
        Probability of each class.

    classes_ : ndarray of shape (n_classes,)
        Class labels known to the classifier.

    n_features_in_ : int
        Number of features seen during fit.

    feature_names_in_ : ndarray of shape (`n_features_in_`,)
        Names of features seen during :term:`fit`. Defined only when `X`
        has feature names that are all strings.

    theta_ : ndarray of shape (n_classes, n_features, n_params)
        Fitted parameters for each feature in each class.

    log_priors_ : ndarray of shape (n_classes,)
        Log probability of each class.
    """
    _parameter_constraints: dict = {
        "priors": ["array-like", None],
        "dist":[str],
        "fit_args": [dict, None],
    }

    def __init__(self, *, priors=None, dist="norm",fit_args=None):
        self.priors = priors
        self.dist = dist
        self.fit_args = fit_args

    def _joint_log_likelihood(self, X):
        """Compute joint log likelihood log P(c) + log P(x|c)."""
        n_samples = X.shape[0]
        n_classes = len(self.classes_)
        n_features = self.n_features_in_

        jll = np.tile(self.log_priors_, (n_samples, 1))

        for ci in range(n_classes):
            for fi in range(n_features):
                jll[:, ci] += self.dist_.logpdf(X[:, fi], *self.theta_[ci, fi, :])
        return jll

    @_fit_context(prefer_skip_nested_validation=True)
    def fit(self, X, y, sample_weight=None):
        """Fit T-dist_ Naive Bayes according to X and y.

        Parameters
        ----------
        X : array-like of shape (n_samples, n_features)
            Training vectors.
        y : array-like of shape (n_samples,)
            Target values.
        sample_weight : array-like of shape (n_samples,), default=None
            Per-sample weights.
        Returns
        -------
        self : object
            Fitted estimator.
        """
        X, y = self._validate_data(X, y)
        try:
            self.dist_=getattr(stats, self.dist)
            param_num=self.dist_.numargs + 2
        except AttributeError:
            raise ValueError(f"{self.dist} is not supported by scipy.stats")
        self.classes_=np.unique(y)
        n_classes=len(self.classes_)
        n_features=self.n_features_in_
        n_samples=X.shape[0]
        self.theta_=np.zeros([n_classes,n_features,param_num])
        fit_kwargs=self.fit_args if self.fit_args is not None else {}

        for ci,c in enumerate(self.classes_):
            X_i=X[y==c]
            for fi in range(n_features):
                try:
                    params = self.dist_.fit(X_i[:, fi],**fit_kwargs)
                    self.theta_[ci,fi,:]=params
                except Exception as e:
                    raise ValueError(f"Cannot fit '{self.dist}' for class {c}, feature {fi}. "
                                     f"Error: {str(e)}")

        if self.priors is not None:
            self.class_prior_ = np.asarray(self.priors)
            # Validate priors
            if len(self.class_prior_) != n_classes:
                raise ValueError("Number of priors must match number of classes.")
            if not np.isclose(self.class_prior_.sum(), 1.0):
                raise ValueError("The sum of the priors should be 1.")
            if (self.class_prior_ < 0).any():
                raise ValueError("Priors must be non-negative.")
        else:
            _, self.class_counts_ = np.unique(y, return_counts=True)
            self.class_prior_ = self.class_counts_ / n_samples

        self.log_priors_ = np.log(self.class_prior_)
        return self

    def _check_X(self, X):
        """Validate X, used only in predict* methods."""
        return validate_data(self, X, reset=False)

class MomentNB(GaussianNB):
    _SUPPORTED_DISTS = ['norm', 'gamma', 'expon', 'laplace']

    def __init__(self, *, dist='norm', priors=None, var_smoothing=1e-9):
        if dist not in self._SUPPORTED_DISTS:
            raise ValueError(
                f"'{dist}' is not supported. "
                f"Supported distributions: {self._SUPPORTED_DISTS}. "
                f"For other distributions, use MLEDistNB."
            )
        self.dist = dist
        self.priors = priors
        self.var_smoothing = var_smoothing

    def _joint_log_likelihood(self, X):
        jll_funcs = {
        'norm': self._jll_normal,
        'gamma': self._jll_gamma,
        'expon': self._jll_exponential,
        'laplace': self._jll_laplace,
    }
        return jll_funcs[self.dist](X)


    def _jll_normal(self, X):
        """Normal distribution"""
        joint_log_likelihood = []

        for i in range(len(self.classes_)):
            jointi = np.log(self.class_prior_[i])
            mu = self.theta_[i, :]
            var = self.var_[i, :]

            n_ij = -0.5 * np.sum(np.log(2.0 * np.pi * var))
            n_ij -= 0.5 * np.sum(((X - mu) ** 2) / var, axis=1)

            joint_log_likelihood.append(jointi + n_ij)

        return np.array(joint_log_likelihood).T

    def _jll_gamma(self, X):
        """Gamma distribution"""
        joint_log_likelihood = []

        for i in range(len(self.classes_)):
            jointi = np.log(self.class_prior_[i])
            mu = self.theta_[i, :]
            var = self.var_[i, :]

            shape = mu ** 2 / var
            scale = var / mu

            log_likelihood = np.zeros(X.shape[0])

            for j in range(X.shape[1]):
                k = shape[j]
                theta = scale[j]
                x = np.maximum(X[:, j], 1e-10)

                log_likelihood += (
                        (k - 1) * np.log(x)
                        - x / theta
                        - k * np.log(theta)
                        - gammaln(k)
                )

            joint_log_likelihood.append(jointi + log_likelihood)

        return np.array(joint_log_likelihood).T

    def _jll_exponential(self, X):
        """Exponential distribution"""
        joint_log_likelihood = []

        for i in range(len(self.classes_)):
            jointi = np.log(self.class_prior_[i])
            mu = self.theta_[i, :]

            log_likelihood = -np.sum(np.log(mu)) - np.sum(X / mu, axis=1)

            joint_log_likelihood.append(jointi + log_likelihood)

        return np.array(joint_log_likelihood).T

    def _jll_laplace(self, X):
        """Laplace distribution"""
        joint_log_likelihood = []

        for i in range(len(self.classes_)):
            jointi = np.log(self.class_prior_[i])
            mu = self.theta_[i, :]
            var = self.var_[i, :]
            b = np.sqrt(var / 2)

            n_ij = -np.sum(np.log(2 * b))
            n_ij -= np.sum(np.abs(X - mu) / b, axis=1)

            joint_log_likelihood.append(jointi + n_ij)

        return np.array(joint_log_likelihood).T