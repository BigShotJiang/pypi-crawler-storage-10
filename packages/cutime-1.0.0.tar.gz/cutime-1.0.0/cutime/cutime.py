def gettime(_func = None, *, output = False, verbose = True):
    import time
    def decorator(func):
        def wrapper(*args, **kwargs):
            funcTime = time.perf_counter()
            results = func(*args, **kwargs)
            funcTime = time.perf_counter() - funcTime
            if verbose:
                print(f"{func.__name__} took {funcTime}s.")
            if output:
                return (funcTime, results)
            return results
        return wrapper
    if callable(_func):
        return decorator(_func)
    return decorator

def avgtime(_func = None, *, output = False, verbose = True, itterations = 1000):
    import time
    def decorator(func):
        def wrapper(*args, **kwargs):
            avg = 0
            results = None
            for i in range(1, itterations + 1):
                funcTime = time.perf_counter()
                results = func(*args, **kwargs)
                funcTime = time.perf_counter() - funcTime
                avg = ( ( avg * ( i - 1 ) ) + funcTime ) / i
            if verbose:
                print(f"{itterations} itteration(s) of {func.__name__} took an average of {avg}s.")
            if output:
                return (avg, results)
            return results
        return wrapper
    if callable(_func):
        return decorator(_func)
    return decorator

def sumtime(_func = None, *, output = False, verbose = True, itterations = 1000):
    import time
    def decorator(func):
        def wrapper(*args, **kwargs):
            total = 0
            results = None
            for _ in range(itterations):
                funcTime = time.perf_counter()
                results = func(*args, **kwargs)
                total += time.perf_counter() - funcTime
            if verbose:
                print(f"{itterations} itteration(s) of {func.__name__} took a total of {total}s.")
            if output:
                return (total, results)
            return results
        return wrapper
    if callable(_func):
        return decorator(_func)
    return decorator
