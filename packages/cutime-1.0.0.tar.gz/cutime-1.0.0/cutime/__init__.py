from .cutime import gettime, avgtime, sumtime

__version__ = "1.0.0"
__all__ = ["gettime", "avgtime", "sumtime"]
