# cutime

Simple python decorators for measuring function execution times.

---

### Installation
```bash
pip install cutime
```

---

### Usage
```python
from cutime import gettime, avgtime, sumtime

@gettime
def hello():
    print("Hello World!")

hello()
```

---

### Build & Install Locally

In the same directory as `setup.py`, run:

```bash
pip install build
python -m build
```

### Publishing

#### Step 1 - Install needed Tools
```bash
pip install hatch twine
```

#### Step 2 - Build
```bash
hatch build
```

#### Step 3 - Test with TestPyPI
```bash
python -m twine upload --repository testpypi dist/*
```

#### Step 4 - Test the Test
```bash
pip install -i https://test.pypi.org/simple/ cutime
```

#### Step 5 - Real Upload
```bash
python -m twine upload dist/*
```

### Expansions

#### New Decorators

| Category                    | Ideas                                                   |
| --------------------------- | ------------------------------------------------------- |
| **Better output control**   | Add options for logging results to file, CSV, or JSON.  |
| **Context manager support** | Add `with` syntax to measure arbitrary code blocks.     |
| **Pretty printing**         | Use `tabulate` or `rich` for formatted terminal output. |
| **Statistical summaries**   | Track mean, median, std deviation across runs.          |
| **Async support**           | Add timing decorators for `async def` functions.        | 
| **Profiling integration**   | Integrate with Python’s `cProfile` or `timeit`.         |
| **Custom reporting hooks**  | Allow users to supply callbacks for each timing.        |

#### Better Packaging

| Area          | Expansion                                                |
| ------------- | -------------------------------------------------------- |
| **CLI tool**  | Add a command-line utility: `python -m cutime script.py` |
| **Docs site** | Add documentation via MkDocs or Sphinx                   |
| **Tests**     | Add pytest-based test suite                              |
| **Badges**    | Add shields.io badges (version, license, PyPI)           |

