from ashborn_sparky.utils.shell_utils import get_folder
from ashborn_sparky.utils.shell_utils import get_file
from ashborn_sparky.utils.shell_utils import remove_folder

available = {'0 ' : "DLBDA",
             '-1' : "Remove Folder"}

def echo(name = None, open = False):
    try:
        if name is not None:
            name = str(name)
        if name in ['0']    :   get_folder("DLBDA", loc = True)
        elif name in ['-1'] :   remove_folder("DLBDA")
        else:
            for k, v in available.items():
                sep = " : " if v else ""
                print(k,v,sep = sep)
    except Exception as error:
        print(error)