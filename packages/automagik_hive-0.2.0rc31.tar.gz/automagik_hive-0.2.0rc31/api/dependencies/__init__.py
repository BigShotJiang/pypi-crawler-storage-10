"""API dependencies module."""

from .agentos import get_agentos_service

__all__ = ["get_agentos_service"]
