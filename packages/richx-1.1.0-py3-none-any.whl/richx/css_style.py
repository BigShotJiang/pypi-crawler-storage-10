"""

A small utility to load a CSS-like `.richstyle` stylesheet and convert it
into a `richx.theme.Theme` or a mapping of style names -> style strings usable
by the `rich` library.

Features:
- Simple CSS-like syntax (selectors + block of declarations)
- Variables (like `--primary: #ff0000;`) with substitution
- Basic properties: color, background-color, fg, bg, bold, italic, underline,
  dim, strike, blink, reverse, uppercase, lowercase (transform is informational)
- CLI: `python rich_css_style.py path/to/styles.richstyle` prints a small summary

Usage (in the file):
- `from rich_css_style import load_stylesheet, theme_from_stylesheet`
- `theme = theme_from_stylesheet("./styles.richstyle")`
- `console = Console(theme=theme)`

Note: This aims to be small and dependency-free. It is NOT a complete CSS
implementation but a pragmatic translator from a human-friendly .richstyle
file into `rich` style strings and a Theme.

"""
from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Dict, Tuple, Optional

from richx.style import Style
from richx.theme import Theme

# --------------------------- Parsing utilities --------------------------- #

_SELECTOR_REGEX = re.compile(r"(?P<selector>[^{]+)\{(?P<body>[^}]+)\}", re.DOTALL)
_DECLARATION_REGEX = re.compile(r"(?P<prop>[^:]+):(?P<val>[^;]+);?")
_VAR_REGEX = re.compile(r"--(?P<name>[A-Za-z0-9_-]+)\s*:\s*(?P<value>[^;]+);?")


def _strip(s: str) -> str:
    return s.strip()


def _parse_declarations(block_text: str) -> Dict[str, str]:
    """Return dict of property -> value for text inside { ... }."""
    props: Dict[str, str] = {}
    for match in _DECLARATION_REGEX.finditer(block_text):
        prop = _strip(match.group("prop")).lower()
        val = _strip(match.group("val"))
        props[prop] = val
    return props


# --------------------------- Stylesheet parser --------------------------- #

class StylesheetParseError(Exception):
    pass


def parse_richstyle(text: str) -> Tuple[Dict[str, str], Dict[str, Dict[str, str]]]:
    """
    Parse .richstyle text.

    Returns (variables, rules) where:
      - variables: mapping of var_name -> value (strings, no leading '--')
      - rules: mapping of selector -> { prop: value }
    """
    variables: Dict[str, str] = {}
    rules: Dict[str, Dict[str, str]] = {}

    # First scan for variables defined at top-level (or anywhere)
    for vm in _VAR_REGEX.finditer(text):
        variables[vm.group("name")] = _strip(vm.group("value"))

    # Now find selector blocks
    for m in _SELECTOR_REGEX.finditer(text):
        selector = _strip(m.group("selector"))
        body = m.group("body")
        decls = _parse_declarations(body)
        # Substitute variables in declarations
        for k, v in list(decls.items()):
            decls[k] = _substitute_vars(v, variables)
        # Add rule
        rules[selector] = decls

    return variables, rules


def _substitute_vars(value: str, variables: Dict[str, str]) -> str:
    """Replace occurrences of var(...) and --var references in value."""
    # var(--name)
    def repl_var(m: re.Match) -> str:
        name = m.group("name")
        return variables.get(name, "")

    # var\(\s*--name\s*\)
    value = re.sub(r"var\(\s*--(?P<name>[A-Za-z0-9_-]+)\s*\)", repl_var, value)
    # direct --name usage
    value = re.sub(r"--(?P<name>[A-Za-z0-9_-]+)", lambda m: variables.get(m.group("name"), ""), value)
    return value


# --------------------------- Declaration -> rich style --------------------------- #

def _decls_to_style_string(decls: Dict[str, str]) -> str:
    """Convert declaration dict to a `rich` style string.

    Accepts properties:
      - color / fg
      - background-color / bg / bgcolor
      - bold: true | false
      - italic: true | false
      - underline: true | false
      - dim: true | false
      - strike / strikethrough: true | false
      - blink: true | false
      - reverse: true | false

    Values can be color names or hex like `#ff00aa`.
    """
    parts = []

    # Colors
    color = decls.get("color") or decls.get("fg")
    bgcolor = decls.get("background-color") or decls.get("bg") or decls.get("bgcolor")
    if color:
        parts.append(color)
    if bgcolor:
        parts.append("on "+bgcolor)

    # Boolean properties
    bool_props = [
        ("bold", "bold"),
        ("italic", "italic"),
        ("underline", "underline"),
        ("dim", "dim"),
        ("strike", "strike"),
        ("strikethrough", "strike"),
        ("blink", "blink"),
        ("reverse", "reverse"),
    ]

    for prop_name, token in bool_props:
        if prop_name in decls:
            val = decls[prop_name].lower()
            if val in ("1", "true", "on", "yes"):
                parts.append(token)
            # allow explicit 'false' to remove - do nothing on false

    # Additional shorthand: weight or font-style
    weight = decls.get("font-weight")
    if weight is not None:
        w = weight.strip().lower()
        if w in ("bold", "700", "800", "900"):
            parts.append("bold")

    # text-transform (informational only) - not reflected in style string

    return " ".join(parts).strip()


# --------------------------- Public API --------------------------- #


def load_stylesheet(path: str | Path) -> Tuple[Dict[str, str], Dict[str, Dict[str, str]]]:
    """Load and parse a .richstyle file from disk."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Stylesheet not found: {p}")
    text = p.read_text(encoding="utf8", errors='ignore')
    return parse_richstyle(text)


def theme_from_stylesheet(path: str | Path, selector_prefix: Optional[str] = None) -> Theme:
    """Compile a richx.Theme from a .richstyle file.

    If `selector_prefix` is provided, selectors will be prefixed (useful to
    scope rules to a namespace).
    """
    _, rules = load_stylesheet(path)
    mapping: Dict[str, str] = {}
    for selector, decls in rules.items():
        # We use the selector string as the theme key. Allow simple selectors only.
        key = selector.strip()
        if selector_prefix:
            key = f"{selector_prefix}.{key}"
        style_str = _decls_to_style_string(decls)
        # Validate style by trying to parse it with rich
        try:
            Style.parse(style_str)  # type: ignore
        except Exception:
            # If style_str is empty or invalid, fallback to empty string.
            if style_str:
                print(f"Warning: invalid style for selector '{selector}': '{style_str}'", file=sys.stderr)
            style_str = ""
        mapping[key] = style_str
    return Theme(mapping)


def compile_stylesheet_to_dict(path: str | Path) -> Dict[str, str]:
    """Return a mapping selector -> style string (already compiled)."""
    _, rules = load_stylesheet(path)
    out: Dict[str, str] = {}
    for selector, decls in rules.items():
        out[selector] = _decls_to_style_string(decls)
    return out


TEMPLATE_FOLDER = Path(__file__).parent / "template"

def _load_available_templates() -> dict:
    """Scan the template/ folder for all .richstyle files and load them."""
    templates = {}
    if TEMPLATE_FOLDER.exists():
        sys.path.insert(0, str(TEMPLATE_FOLDER))
        for i, file in enumerate(TEMPLATE_FOLDER.glob("*.richstyle"), start=1):
            try:
                sys.path.insert(i, str(file))
                theme_name = file.stem.upper().replace('.', '_') + "_THEME"
                templates[theme_name] = theme_from_stylesheet(file)
            except Exception as e:
                print(f"[RichX] Warning: Failed to load template {file.name}: {e}")
    return templates

_RICHX_TEMPLATES = _load_available_templates()

# --------------------------- Small CLI --------------------------- #
if __name__ == "__main__":
    import argparse
    from richx.console import Console
    import json

    parser = argparse.ArgumentParser(description="Compile a .richstyle file into a rich Theme or JSON mapping.")
    parser.add_argument("path", help=".richstyle file to compile")
    parser.add_argument("--json", action="store_true", help="print mapping as JSON")
    parser.add_argument("--show", action="store_true", help="show a demo using rich Console")
    args = parser.parse_args()

    try:
        mapping = compile_stylesheet_to_dict(args.path)
    except Exception as e:
        print(f"Error parsing stylesheet: {e}")
        raise

    if args.json:
        print(json.dumps(mapping, indent=2))
        sys.exit(0)

    if args.show:
        console = Console()
        console.rule("Stylesheet Preview")
        for sel, style in mapping.items():
            console.print(f"{sel}: {style}", style=style)
        console.rule("End Preview")
        sys.exit(0)

    # Default: print a short summary
    print(f"Compiled {len(mapping)} selectors from {args.path}")
    for sel, style in mapping.items():
        print(f"- {sel}: {style}")




