"""lazy_helper — utilities for lazy imports.

This package provides a small utility class, :class:`Lazy`, that lets
projects declare imports that are only resolved when first accessed.

See the project README for full usage examples and the generated-stub
CLI for creating `.pyi` stubs from lazy declarations.

Quick example::

    from lazy_helper import Lazy

    __lazy__ = Lazy()
    __lazy__("typing", "TypedDict")

    __getattr__ = __lazy__.__getattr__
    __dir__ = __lazy__.__dir__
    __all__ = __lazy__.__all__

The public API is intentionally small. Exported symbols:

- ``Lazy`` — main helper class

"""

import importlib
from dataclasses import dataclass, field
from functools import cache


ModuleName = str
AttributeName = str
LazyImport = tuple[ModuleName, AttributeName | None]


@dataclass
class Lazy:
    imports: dict[str, LazyImport] = field(default_factory=dict)

    def __call__(
        self,
        module_name: str,
        attr_name: str | None = None,
        /,
        *,
        as_: str | None = None,
    ) -> None:
        """Register a lazy import with the given module and optional attribute.

        Args:
            module_name: The module to import from (e.g., "typing").
            attr_name: Optional attribute to import from the module (e.g., "TypedDict").
            as_: Optional alias to use for the import.
        """
        match module_name, attr_name, as_:
            case module_name, None, None:
                self.imports[module_name] = (module_name, None)
            case module_name, None, alias:
                self.imports[alias] = (module_name, None)
            case module_name, attr_name, None:
                self.imports[attr_name] = (module_name, attr_name)
            case module_name, attr_name, alias:
                self.imports[alias] = (module_name, attr_name)
            case _:
                assert False

    def __hash__(self) -> int:
        return hash(id(self))

    @property
    def __all__(self) -> tuple[str, ...]:
        return tuple(self.imports.keys())

    @cache
    def __getattr__(self, name: str) -> object:
        if name not in self.imports:
            raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

        module_name, attr_name = self.imports[name]
        val = importlib.import_module(module_name, __name__)
        if attr_name is None:
            return val
        for attr in attr_name.split("."):
            val = getattr(val, attr)
        return val

    def __dir__(self) -> list[str]:
        return list(self.imports.keys())

    def _stubgen(self):
        for alias, (module, attribute) in self.imports.items():
            full_path = f"{module}.{attribute}" if attribute else module
            from_, _, import_ = full_path.rpartition(".")
            import_ = f"{import_} as {alias}" if import_ != alias else import_

            if from_:
                yield f"from {from_} import {import_}"
            else:
                yield f"import {import_}"

        yield ""

        yield "__all__ = ["
        for key in self.imports.keys():
            yield f'    "{key}",'
        yield "]"
        yield ""

    def stubgen(self) -> str:
        return "\n".join(self._stubgen())


__all__ = ("Lazy",)

