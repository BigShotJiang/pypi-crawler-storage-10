import importlib.util
from pathlib import Path

import typer

from lazy_helper import Lazy


app = typer.Typer()


def load_lazy(path: Path) -> Lazy:
    spec = importlib.util.spec_from_file_location("my_module", path)
    if not (spec and spec.loader):
        raise ValueError(f"Unable to load {path} as python module")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.__lazy__


def write_stub(original_path: Path, lazy: Lazy) -> None:
    new_path = original_path.parent / f"{original_path.name}i"
    new_path.write_text(lazy.stubgen())


@app.command()
def stubgen(files: list[Path]) -> None:
    for path in files:
        assert path.name.endswith(".py")
        write_stub(path, load_lazy(path))
