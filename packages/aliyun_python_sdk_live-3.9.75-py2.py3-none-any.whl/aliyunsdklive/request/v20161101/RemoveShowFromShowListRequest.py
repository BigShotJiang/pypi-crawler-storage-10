# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from aliyunsdkcore.request import RpcRequest
from aliyunsdklive.endpoint import endpoint_data

class RemoveShowFromShowListRequest(RpcRequest):

	def __init__(self):
		RpcRequest.__init__(self, 'live', '2016-11-01', 'RemoveShowFromShowList','live')
		self.set_method('POST')

		if hasattr(self, "endpoint_map"):
			setattr(self, "endpoint_map", endpoint_data.getEndpointMap())
		if hasattr(self, "endpoint_regional"):
			setattr(self, "endpoint_regional", endpoint_data.getEndpointRegional())

	def get_isBatchMode(self): # Boolean
		return self.get_query_params().get('isBatchMode')

	def set_isBatchMode(self, isBatchMode):  # Boolean
		self.add_query_param('isBatchMode', isBatchMode)
	def get_showIdLists(self): # RepeatList
		return self.get_query_params().get('showIdList')

	def set_showIdLists(self, showIdList):  # RepeatList
		for depth1 in range(len(showIdList)):
			self.add_query_param('showIdList.' + str(depth1 + 1), showIdList[depth1])
	def get_CasterId(self): # String
		return self.get_query_params().get('CasterId')

	def set_CasterId(self, CasterId):  # String
		self.add_query_param('CasterId', CasterId)
	def get_OwnerId(self): # Long
		return self.get_query_params().get('OwnerId')

	def set_OwnerId(self, OwnerId):  # Long
		self.add_query_param('OwnerId', OwnerId)
	def get_ShowId(self): # String
		return self.get_query_params().get('ShowId')

	def set_ShowId(self, ShowId):  # String
		self.add_query_param('ShowId', ShowId)
