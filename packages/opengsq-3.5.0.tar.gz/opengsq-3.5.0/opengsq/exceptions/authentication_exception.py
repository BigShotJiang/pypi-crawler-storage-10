class AuthenticationException(Exception):
    pass
