class ServerNotFoundException(Exception):
    pass
