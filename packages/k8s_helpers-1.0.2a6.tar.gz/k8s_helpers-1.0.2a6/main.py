def main():
    print("Hello from k8s-utils!")


if __name__ == "__main__":
    main()
