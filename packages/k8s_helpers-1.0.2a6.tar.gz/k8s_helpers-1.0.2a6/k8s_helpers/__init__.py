"""k8s-utils: Collection of Kubernetes command-line utilities"""

__version__ = "0.1.0"
