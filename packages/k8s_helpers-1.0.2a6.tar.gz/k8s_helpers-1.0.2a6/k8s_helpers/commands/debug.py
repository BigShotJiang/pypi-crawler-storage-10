from podcount import podcount


if __name__ == "__main__":
    podcount(context=None, node_labels=[], sort="Node")