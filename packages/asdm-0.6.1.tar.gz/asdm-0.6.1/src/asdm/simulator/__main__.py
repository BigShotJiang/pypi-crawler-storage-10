# src/asdm/simulator/__main__.py

from .app import main

if __name__ == "__main__":
    main()
