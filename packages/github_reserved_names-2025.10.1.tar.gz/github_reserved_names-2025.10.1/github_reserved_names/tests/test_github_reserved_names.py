import github_reserved_names


def test_it_works():
    assert "sponsors" in github_reserved_names.ALL
