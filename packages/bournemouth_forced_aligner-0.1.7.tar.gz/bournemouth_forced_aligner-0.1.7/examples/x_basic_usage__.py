
import torch
import time
import json
#from bournemouth_aligner import PhonemeTimestampAligner
import sys
sys.path.append('.')
from bournemouth_aligner.core import PhonemeTimestampAligner




def plot_mel_phonemes(mel, compress_framesed, save_path="mel_phonemes.png"):
    """
    Plot mel spectrogram with phoneme IDs overlaid directly on the spectrogram
    
    Args:
        mel: Mel spectrogram tensor [frames, mel_bins]
        phn_frame_ids: List of phoneme IDs aligned to frames
        phn_frame_counts: List of counts for each phoneme ID
        save_path: Path to save the plot
    """
    import matplotlib.pyplot as plt
    
    assert mel.dim() == 2, f"Expected 2D mel tensor, got {mel.dim()}D"
    phn_frame_ids = [phoneme_id for phoneme_id, _ in compress_framesed]
    phn_frame_counts = [count for _, count in compress_framesed]

    # Create single plot - make it twice as wide
    fig, ax = plt.subplots(1, 1, figsize=(30, 8))
    
    # Convert mel to numpy for plotting
    mel_np = mel.cpu().numpy() if isinstance(mel, torch.Tensor) else mel
    
    # Add statistics to title instead of overlaying on spectrum
    unique_phonemes = len(set(phn_frame_ids))
    stats_text = f"Frames: {sum(phn_frame_counts)} | Unique Phonemes: {unique_phonemes} | Mel Bins: {mel.shape[1]}"
    title_text = f'Mel Spectrogram with Phoneme Alignment\n{stats_text}'
    
    # Plot mel spectrogram
    im = ax.imshow(mel_np.T, aspect='auto', origin='lower', 
                    cmap='viridis', interpolation='nearest')
    ax.set_ylabel('Mel Bins')
    ax.set_xlabel('Frame Index')
    ax.set_title(title_text)
    plt.colorbar(im, ax=ax, label='Magnitude')
    
    # Overlay phoneme information
    frame_pos = 0
    for phn_id, count in zip(phn_frame_ids, phn_frame_counts):
        # Draw vertical boundary lines (except for first segment)
        if frame_pos > 0:
            ax.axvline(x=frame_pos-0.5, color='red', linestyle='-', alpha=0.8, linewidth=2)
        
        # Add phoneme ID text at the top of the spectrogram
        if count > 1:  # Only add text if segment is wide enough
            text_x = frame_pos + count/2
            text_y = mel.shape[1] - 2  # Near the top of the mel bins
            
            # Add text with background for visibility
            ax.text(text_x, text_y, str(phn_id), 
                    ha='center', va='center', fontsize=12, fontweight='bold',
                    color='white', 
                    bbox=dict(boxstyle='round,pad=0.3', facecolor='red', alpha=0.8))
        
        frame_pos += count
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"Mel-phoneme alignment plot saved to: {save_path}")
    
    return save_path


def example_audio_timestamps():

    text_sentence = "Alright. TCB! Sure you don't want some."
    audio_path = "EN_B00000_S00010_W000000.mp3"
    print(text_sentence)
    #model_name = "en_libri1000_uj01d_e199_val_GER=0.2307.ckpt" 
    #cupe_ckpt_path = "p1cupe/ua01b/m_ua01b_epoch=2_step=9732_val_GER=0.2238.ckpt" # new model, will be realesed with v0.1.7
    extractor = PhonemeTimestampAligner(preset='en-us', duration_max=120, device='cpu', silence_anchors=0, boost_targets=True, enforce_all_targets=True, ignore_noise=True)
    
    # remove '
    text_sentence = text_sentence.replace("'", "")

    phonemes = extractor.phonemize_sentence(text_sentence)
    print("Expected phonemes:", phonemes['ipa'])
    
    full_clip_wav = extractor.load_audio(audio_path) # can replace it with custom audio source

    start = 0
    end= -1

    start = int(start * extractor.resampler_sample_rate)
    end = int(end * extractor.resampler_sample_rate)
    #full_clip_wav = full_clip_wav[:, start:end]


    t0 = time.time()

    timestamps = extractor.process_sentence(text_sentence, full_clip_wav, ts_out_path=None, extract_embeddings=False, vspt_path=None, do_groups=False, debug=False)

    t1 = time.time()
    print(f"Processing time: {t1 - t0:.2f} seconds")

    print("Timestamps:")
    print(json.dumps(timestamps, indent=4))
    
    # Extract Mel-Spectrum
    # Use the same config to generate mel-spectrum as bigvan vocoder model, so that the mel-spectrum can be converted back to audio easily.
    vocoder_config = {'num_mels': 80, 'num_freq': 1025, 'n_fft': 1024, 'hop_size': 256, 'win_size': 1024, 'sampling_rate': 22050, 'fmin': 0, 'fmax': 8000, 'model': 'nvidia/bigvgan_v2_22khz_80band_fmax8k_256x'}

    # we just need to extract the mel-spectrogram for the segment 0
    segment_start_frame = int(timestamps['segments'][0]['start'] * extractor.resampler_sample_rate)
    segment_end_frame = int(timestamps['segments'][0]['end'] * extractor.resampler_sample_rate)
    segment_wav = full_clip_wav[segment_start_frame:segment_end_frame]
    mel_spec = extractor.extract_mel_spectrum(segment_wav, wav_sample_rate=extractor.resampler_sample_rate, vocoder_config=vocoder_config)


    # Assort phonemes into frame steps to match the mel-spectrogram hop-size
    segment_duration = timestamps['segments'][0]['end'] - timestamps['segments'][0]['start']

    
    
    total_frames = mel_spec.shape[0]
    frames_per_second = total_frames / segment_duration
    frames_assorted = extractor.framewise_assortment(aligned_ts=timestamps['segments'][0]['phoneme_ts'], total_frames=total_frames, frames_per_second=frames_per_second, gap_contraction=4, select_key="phoneme_idx")
    # convert phoneme IDs to labels
    frames_assorted = [extractor.phoneme_id_to_label[phoneme_id] for phoneme_id in frames_assorted]

    compress_framesed = extractor.compress_frames(frames_assorted)


    plot_mel_phonemes(mel_spec, compress_framesed, save_path="mel_phonemes.png")

if __name__ == "__main__":
    torch.random.manual_seed(42)
    example_audio_timestamps()















'''output

Alright. TCB! Sure you don't want some.
Model available at: /root/.cache/huggingface/hub/models--Tabahi--CUPE-2i/snapshots/f4716f5da56e327ff65213db1a133b78c6c13c33/ckpt/en_libri1000_uj01d_e199_val_GER=0.2307.ckpt
Setting espeak backend for language: en-us
Expected phonemes: ['ɔ', 'l', 'ɹ', 'aɪ', 't', 'SIL', 'SIL', 't', 'i:', 's', 'i:', 'b', 'i:', 'SIL', 'SIL', 'ʃ', 'ʊ', 'ɹ', 'j', 'u:', 'd', 'oʊ', 'n', 't', 'w', 'ɔ', 'n', 't', 's', 'ʌ', 'm', 'SIL', 'SIL']
Resampling EN_B00000_S00010_W000000.mp3 from 24000Hz to 16000Hz
Processing time: 2.19 seconds
Timestamps:
{
    "segments": [
        {
            "start": 0.0,
            "end": 3.158,
            "text": "Alright. TCB! Sure you dont want some.",
            "ph66": [
                17,
                56,
                59,
                23,
                30,
                0,
                0,
                30,
                2,
                36,
                2,
                29,
                2,
                0,
                0,
                40,
                13,
                59,
                60,
                12,
                31,
                26,
                53,
                30,
                61,
                17,
                53,
                30,
                36,
                10,
                52,
                0,
                0
            ],
            "pg16": null,
            "coverage_analysis": {
                "target_count": 19,
                "aligned_count": 19,
                "missing_count": 0,
                "extra_count": 0,
                "coverage_ratio": 1.0,
                "missing_phonemes": [],
                "extra_phonemes": []
            },
            "ipa": [
                "\u0254",
                "l",
                "\u0279",
                "a\u026a",
                "t",
                "SIL",
                "SIL",
                "t",
                "i:",
                "s",
                "i:",
                "b",
                "i:",
                "SIL",
                "SIL",
                "\u0283",
                "\u028a",
                "\u0279",
                "j",
                "u:",
                "d",
                "o\u028a",
                "n",
                "t",
                "w",
                "\u0254",
                "n",
                "t",
                "s",
                "\u028c",
                "m",
                "SIL",
                "SIL"
            ],
            "word_num": [
                0,
                0,
                0,
                0,
                0,
                1,
                2,
                3,
                3,
                3,
                3,
                3,
                3,
                4,
                5,
                6,
                6,
                6,
                7,
                7,
                8,
                8,
                8,
                8,
                9,
                9,
                9,
                9,
                10,
                10,
                10,
                11,
                12
            ],
            "words": [
                "Alright",
                "<sil>",
                "<sil>",
                "TCB",
                "<sil>",
                "<sil>",
                "Sure",
                "you",
                "dont",
                "want",
                "some",
                "<sil>",
                "<sil>"
            ],
            "phoneme_ts": [
                {
                    "phoneme_idx": 17,
                    "phoneme_label": "\u0254",
                    "start_ms": 0.0,
                    "end_ms": 16.62105369567871,
                    "confidence": 0.00138755957596004
                },
                {
                    "phoneme_idx": 56,
                    "phoneme_label": "l",
                    "start_ms": 66.48421478271484,
                    "end_ms": 83.10526275634766,
                    "confidence": 0.0007388984668068588
                },
                {
                    "phoneme_idx": 59,
                    "phoneme_label": "\u0279",
                    "start_ms": 99.726318359375,
                    "end_ms": 149.5894775390625,
                    "confidence": 0.6946465373039246
                },
                {
                    "phoneme_idx": 23,
                    "phoneme_label": "a\u026a",
                    "start_ms": 265.9368591308594,
                    "end_ms": 282.5578918457031,
                    "confidence": 0.035514816641807556
                },
                {
                    "phoneme_idx": 30,
                    "phoneme_label": "t",
                    "start_ms": 432.1473693847656,
                    "end_ms": 465.3894958496094,
                    "confidence": 0.14466047286987305
                },
                {
                    "phoneme_idx": 0,
                    "phoneme_label": "SIL",
                    "start_ms": 465.3894958496094,
                    "end_ms": 482.0105285644531,
                    "confidence": 0.025935767218470573
                },
                {
                    "phoneme_idx": 0,
                    "phoneme_label": "SIL",
                    "start_ms": 531.8737182617188,
                    "end_ms": 565.1157836914062,
                    "confidence": 0.1822948157787323
                },
                {
                    "phoneme_idx": 30,
                    "phoneme_label": "t",
                    "start_ms": 614.9789428710938,
                    "end_ms": 631.6000366210938,
                    "confidence": 0.9210434556007385
                },
                {
                    "phoneme_idx": 2,
                    "phoneme_label": "i:",
                    "start_ms": 764.5684204101562,
                    "end_ms": 781.1895141601562,
                    "confidence": 0.743901789188385
                },
                {
                    "phoneme_idx": 36,
                    "phoneme_label": "s",
                    "start_ms": 864.2947387695312,
                    "end_ms": 914.1578979492188,
                    "confidence": 0.6543107628822327
                },
                {
                    "phoneme_idx": 2,
                    "phoneme_label": "i:",
                    "start_ms": 1113.6104736328125,
                    "end_ms": 1130.2315673828125,
                    "confidence": 0.680704653263092
                },
                {
                    "phoneme_idx": 29,
                    "phoneme_label": "b",
                    "start_ms": 1263.2000732421875,
                    "end_ms": 1296.442138671875,
                    "confidence": 0.5139046907424927
                },
                {
                    "phoneme_idx": 2,
                    "phoneme_label": "i:",
                    "start_ms": 1362.9263916015625,
                    "end_ms": 1412.78955078125,
                    "confidence": 0.1929096132516861
                },
                {
                    "phoneme_idx": 0,
                    "phoneme_label": "SIL",
                    "start_ms": 1778.45263671875,
                    "end_ms": 1811.69482421875,
                    "confidence": 0.049359098076820374
                },
                {
                    "phoneme_idx": 0,
                    "phoneme_label": "SIL",
                    "start_ms": 2094.252685546875,
                    "end_ms": 2127.494873046875,
                    "confidence": 0.022397782653570175
                },
                {
                    "phoneme_idx": 40,
                    "phoneme_label": "\u0283",
                    "start_ms": 2343.568603515625,
                    "end_ms": 2376.810546875,
                    "confidence": 0.4603399336338043
                },
                {
                    "phoneme_idx": 13,
                    "phoneme_label": "\u028a",
                    "start_ms": 2376.810546875,
                    "end_ms": 2393.431640625,
                    "confidence": 0.001984702656045556
                },
                {
                    "phoneme_idx": 59,
                    "phoneme_label": "\u0279",
                    "start_ms": 2509.779052734375,
                    "end_ms": 2543.021240234375,
                    "confidence": 0.2862449884414673
                },
                {
                    "phoneme_idx": 60,
                    "phoneme_label": "j",
                    "start_ms": 2592.88427734375,
                    "end_ms": 2609.50537109375,
                    "confidence": 0.025075314566493034
                },
                {
                    "phoneme_idx": 12,
                    "phoneme_label": "u:",
                    "start_ms": 2609.50537109375,
                    "end_ms": 2642.747314453125,
                    "confidence": 0.025433458387851715
                },
                {
                    "phoneme_idx": 31,
                    "phoneme_label": "d",
                    "start_ms": 2642.747314453125,
                    "end_ms": 2692.61083984375,
                    "confidence": 0.8578530550003052
                },
                {
                    "phoneme_idx": 26,
                    "phoneme_label": "o\u028a",
                    "start_ms": 2692.61083984375,
                    "end_ms": 2709.231689453125,
                    "confidence": 0.7281172275543213
                },
                {
                    "phoneme_idx": 53,
                    "phoneme_label": "n",
                    "start_ms": 2759.0947265625,
                    "end_ms": 2775.7158203125,
                    "confidence": 0.3691890835762024
                },
                {
                    "phoneme_idx": 30,
                    "phoneme_label": "t",
                    "start_ms": 2775.7158203125,
                    "end_ms": 2792.3369140625,
                    "confidence": 0.025063930079340935
                },
                {
                    "phoneme_idx": 61,
                    "phoneme_label": "w",
                    "start_ms": 2792.3369140625,
                    "end_ms": 2808.9580078125,
                    "confidence": 0.00018689906573854387
                },
                {
                    "phoneme_idx": 17,
                    "phoneme_label": "\u0254",
                    "start_ms": 2842.199951171875,
                    "end_ms": 2858.821044921875,
                    "confidence": 0.4445822834968567
                },
                {
                    "phoneme_idx": 53,
                    "phoneme_label": "n",
                    "start_ms": 2858.821044921875,
                    "end_ms": 2941.926513671875,
                    "confidence": 0.8950247764587402
                },
                {
                    "phoneme_idx": 30,
                    "phoneme_label": "t",
                    "start_ms": 2941.926513671875,
                    "end_ms": 2958.547607421875,
                    "confidence": 0.11733847856521606
                },
                {
                    "phoneme_idx": 36,
                    "phoneme_label": "s",
                    "start_ms": 2958.547607421875,
                    "end_ms": 2991.78955078125,
                    "confidence": 0.9913116693496704
                },
                {
                    "phoneme_idx": 52,
                    "phoneme_label": "m",
                    "start_ms": 3058.273681640625,
                    "end_ms": 3074.89501953125,
                    "confidence": 0.0036529514472931623
                },
                {
                    "phoneme_idx": 10,
                    "phoneme_label": "\u028c",
                    "start_ms": 3091.51611328125,
                    "end_ms": 3108.136962890625,
                    "confidence": 0.7344768047332764
                }
            ],
            "group_ts": [
                {
                    "group_idx": 3,
                    "group_label": "back_vowels",
                    "start_ms": 49.8631591796875,
                    "end_ms": 66.48421478271484,
                    "confidence": 0.0003239610232412815
                },
                {
                    "group_idx": 13,
                    "group_label": "laterals",
                    "start_ms": 66.48421478271484,
                    "end_ms": 83.10526275634766,
                    "confidence": 0.001447127666324377
                },
                {
                    "group_idx": 14,
                    "group_label": "rhotics",
                    "start_ms": 99.726318359375,
                    "end_ms": 149.5894775390625,
                    "confidence": 0.6770860552787781
                },
                {
                    "group_idx": 5,
                    "group_label": "diphthongs",
                    "start_ms": 265.9368591308594,
                    "end_ms": 315.8000183105469,
                    "confidence": 0.9742445349693298
                },
                {
                    "group_idx": 6,
                    "group_label": "voiceless_stops",
                    "start_ms": 432.1473693847656,
                    "end_ms": 465.3894958496094,
                    "confidence": 0.42606353759765625
                },
                {
                    "group_idx": 0,
                    "group_label": "SIL",
                    "start_ms": 465.3894958496094,
                    "end_ms": 482.0105285644531,
                    "confidence": 0.01617104932665825
                },
                {
                    "group_idx": 0,
                    "group_label": "SIL",
                    "start_ms": 531.8737182617188,
                    "end_ms": 565.1157836914062,
                    "confidence": 0.1942201554775238
                },
                {
                    "group_idx": 6,
                    "group_label": "voiceless_stops",
                    "start_ms": 614.9789428710938,
                    "end_ms": 631.6000366210938,
                    "confidence": 0.9075990915298462
                },
                {
                    "group_idx": 1,
                    "group_label": "front_vowels",
                    "start_ms": 764.5684204101562,
                    "end_ms": 814.4315795898438,
                    "confidence": 0.6932955384254456
                },
                {
                    "group_idx": 8,
                    "group_label": "voiceless_fricatives",
                    "start_ms": 864.2947387695312,
                    "end_ms": 914.1578979492188,
                    "confidence": 0.7555153965950012
                },
                {
                    "group_idx": 1,
                    "group_label": "front_vowels",
                    "start_ms": 1113.6104736328125,
                    "end_ms": 1146.852783203125,
                    "confidence": 0.8980683088302612
                },
                {
                    "group_idx": 7,
                    "group_label": "voiced_stops",
                    "start_ms": 1263.2000732421875,
                    "end_ms": 1296.442138671875,
                    "confidence": 0.5484481453895569
                },
                {
                    "group_idx": 1,
                    "group_label": "front_vowels",
                    "start_ms": 1346.305419921875,
                    "end_ms": 1545.758056640625,
                    "confidence": 0.669446587562561
                },
                {
                    "group_idx": 0,
                    "group_label": "SIL",
                    "start_ms": 1778.45263671875,
                    "end_ms": 1811.69482421875,
                    "confidence": 0.032783761620521545
                },
                {
                    "group_idx": 0,
                    "group_label": "SIL",
                    "start_ms": 2094.252685546875,
                    "end_ms": 2127.494873046875,
                    "confidence": 0.009631210938096046
                },
                {
                    "group_idx": 8,
                    "group_label": "voiceless_fricatives",
                    "start_ms": 2343.568603515625,
                    "end_ms": 2393.431640625,
                    "confidence": 0.9427853226661682
                },
                {
                    "group_idx": 3,
                    "group_label": "back_vowels",
                    "start_ms": 2509.779052734375,
                    "end_ms": 2526.400146484375,
                    "confidence": 0.012789662927389145
                },
                {
                    "group_idx": 14,
                    "group_label": "rhotics",
                    "start_ms": 2526.400146484375,
                    "end_ms": 2543.021240234375,
                    "confidence": 0.38930803537368774
                },
                {
                    "group_idx": 15,
                    "group_label": "glides",
                    "start_ms": 2592.88427734375,
                    "end_ms": 2609.50537109375,
                    "confidence": 0.014067650772631168
                },
                {
                    "group_idx": 3,
                    "group_label": "back_vowels",
                    "start_ms": 2609.50537109375,
                    "end_ms": 2642.747314453125,
                    "confidence": 0.06230585649609566
                },
                {
                    "group_idx": 7,
                    "group_label": "voiced_stops",
                    "start_ms": 2675.98974609375,
                    "end_ms": 2692.61083984375,
                    "confidence": 0.8236076831817627
                },
                {
                    "group_idx": 5,
                    "group_label": "diphthongs",
                    "start_ms": 2692.61083984375,
                    "end_ms": 2709.231689453125,
                    "confidence": 0.8179426789283752
                },
                {
                    "group_idx": 12,
                    "group_label": "nasals",
                    "start_ms": 2742.473876953125,
                    "end_ms": 2792.3369140625,
                    "confidence": 0.7530093193054199
                },
                {
                    "group_idx": 6,
                    "group_label": "voiceless_stops",
                    "start_ms": 2792.3369140625,
                    "end_ms": 2808.9580078125,
                    "confidence": 0.004402738530188799
                },
                {
                    "group_idx": 15,
                    "group_label": "glides",
                    "start_ms": 2825.5791015625,
                    "end_ms": 2842.199951171875,
                    "confidence": 3.344766446389258e-05
                },
                {
                    "group_idx": 3,
                    "group_label": "back_vowels",
                    "start_ms": 2842.199951171875,
                    "end_ms": 2858.821044921875,
                    "confidence": 0.562126100063324
                },
                {
                    "group_idx": 12,
                    "group_label": "nasals",
                    "start_ms": 2858.821044921875,
                    "end_ms": 2941.926513671875,
                    "confidence": 0.909604549407959
                },
                {
                    "group_idx": 6,
                    "group_label": "voiceless_stops",
                    "start_ms": 2941.926513671875,
                    "end_ms": 2958.547607421875,
                    "confidence": 0.06869638711214066
                },
                {
                    "group_idx": 8,
                    "group_label": "voiceless_fricatives",
                    "start_ms": 2958.547607421875,
                    "end_ms": 2991.78955078125,
                    "confidence": 0.9953100085258484
                },
                {
                    "group_idx": 2,
                    "group_label": "central_vowels",
                    "start_ms": 3091.51611328125,
                    "end_ms": 3108.136962890625,
                    "confidence": 0.75223708152771
                },
                {
                    "group_idx": 12,
                    "group_label": "nasals",
                    "start_ms": 3108.136962890625,
                    "end_ms": 3158.0,
                    "confidence": 0.014739771373569965
                }
            ],
            "words_ts": [
                {
                    "word": "Alright",
                    "start_ms": 0.0,
                    "end_ms": 465.3894958496094,
                    "confidence": 0.1753896569716744,
                    "ph66": [
                        17,
                        56,
                        59,
                        23,
                        30
                    ],
                    "ipa": [
                        "\u0254",
                        "l",
                        "\u0279",
                        "a\u026a",
                        "t"
                    ]
                },
                {
                    "word": "<sil>",
                    "start_ms": 465.3894958496094,
                    "end_ms": 482.0105285644531,
                    "confidence": 0.025935767218470573,
                    "ph66": [
                        0
                    ],
                    "ipa": [
                        "SIL"
                    ]
                },
                {
                    "word": "<sil>",
                    "start_ms": 531.8737182617188,
                    "end_ms": 565.1157836914062,
                    "confidence": 0.1822948157787323,
                    "ph66": [
                        0
                    ],
                    "ipa": [
                        "SIL"
                    ]
                },
                {
                    "word": "TCB",
                    "start_ms": 614.9789428710938,
                    "end_ms": 1412.78955078125,
                    "confidence": 0.6177958274881045,
                    "ph66": [
                        30,
                        2,
                        36,
                        2,
                        29,
                        2
                    ],
                    "ipa": [
                        "t",
                        "i:",
                        "s",
                        "i:",
                        "b",
                        "i:"
                    ]
                },
                {
                    "word": "<sil>",
                    "start_ms": 1778.45263671875,
                    "end_ms": 1811.69482421875,
                    "confidence": 0.049359098076820374,
                    "ph66": [
                        0
                    ],
                    "ipa": [
                        "SIL"
                    ]
                },
                {
                    "word": "<sil>",
                    "start_ms": 2094.252685546875,
                    "end_ms": 2127.494873046875,
                    "confidence": 0.022397782653570175,
                    "ph66": [
                        0
                    ],
                    "ipa": [
                        "SIL"
                    ]
                },
                {
                    "word": "Sure",
                    "start_ms": 2343.568603515625,
                    "end_ms": 2543.021240234375,
                    "confidence": 0.2495232082437724,
                    "ph66": [
                        40,
                        13,
                        59
                    ],
                    "ipa": [
                        "\u0283",
                        "\u028a",
                        "\u0279"
                    ]
                },
                {
                    "word": "you",
                    "start_ms": 2592.88427734375,
                    "end_ms": 2642.747314453125,
                    "confidence": 0.025254386477172375,
                    "ph66": [
                        60,
                        12
                    ],
                    "ipa": [
                        "j",
                        "u:"
                    ]
                },
                {
                    "word": "dont",
                    "start_ms": 2642.747314453125,
                    "end_ms": 2792.3369140625,
                    "confidence": 0.49505582405254245,
                    "ph66": [
                        31,
                        26,
                        53,
                        30
                    ],
                    "ipa": [
                        "d",
                        "o\u028a",
                        "n",
                        "t"
                    ]
                },
                {
                    "word": "want",
                    "start_ms": 2792.3369140625,
                    "end_ms": 2958.547607421875,
                    "confidence": 0.3642831093966379,
                    "ph66": [
                        61,
                        17,
                        53,
                        30
                    ],
                    "ipa": [
                        "w",
                        "\u0254",
                        "n",
                        "t"
                    ]
                }
            ]
        }
    ]
}
Resampling waveform from 16000 to 22050 for vocoder compatibility
Mel-phoneme alignment plot saved to: mel_phonemes.png
'''