from fastapi import FastAPI
from mineru_flow.internal.middleware.content_type import ContentTypeMiddleware
from mineru_flow.internal.middleware.tracing import TracingMiddleWare


def add_middleware(app: FastAPI):
    app.add_middleware(TracingMiddleWare)
    app.add_middleware(ContentTypeMiddleware)
