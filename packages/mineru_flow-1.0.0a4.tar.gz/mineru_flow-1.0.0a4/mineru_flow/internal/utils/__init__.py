from .config import update_sys_info

__all__ = ["update_sys_info"]
