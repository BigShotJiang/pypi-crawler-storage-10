import{j as t,O as s}from"./index-qMrAuFFG.js";function a(){return t.jsx("div",{className:"container mx-auto py-8 px-4",children:t.jsx(s,{})})}export{a as component};
