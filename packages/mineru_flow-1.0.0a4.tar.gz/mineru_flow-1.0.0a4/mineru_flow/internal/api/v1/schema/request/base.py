from pydantic import BaseModel


# ============ 基础请求模板 ============
class BaseRequest(BaseModel):
    """基础请求模板"""

    pass
