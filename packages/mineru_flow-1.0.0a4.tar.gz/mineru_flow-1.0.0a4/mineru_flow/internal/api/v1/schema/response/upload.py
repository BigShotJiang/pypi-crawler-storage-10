from typing import Any, Dict

from pydantic import Field

from .base import BaseResponse


# ============ Upload响应 ============
class UploadResponse(BaseResponse):
    """文件上传响应"""

    data: Dict[str, str] = Field(..., description="包含上传路径信息")
