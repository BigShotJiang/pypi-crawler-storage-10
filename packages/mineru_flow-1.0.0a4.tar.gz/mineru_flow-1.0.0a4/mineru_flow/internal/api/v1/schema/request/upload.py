from pydantic import BaseModel

from .base import BaseRequest


# ============ Upload Request Schemas ============
class UploadRequest(BaseRequest):
    """文件上传请求"""

    # FastAPI会自动处理文件上传，这里主要用于文档
    pass
