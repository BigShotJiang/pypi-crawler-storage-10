from .base import BaseRequest


# ============ System Request Schemas ============
class SystemInfoRequest(BaseRequest):
    """系统信息请求"""

    # 通常不需要参数
    pass


class HealthCheckRequest(BaseRequest):
    """健康检查请求"""

    # 通常不需要参数
    pass
