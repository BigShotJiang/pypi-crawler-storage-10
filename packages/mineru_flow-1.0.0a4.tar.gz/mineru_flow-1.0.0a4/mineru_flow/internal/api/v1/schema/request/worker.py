from .base import BaseRequest


# ============ Worker Request Schemas ============
class WorkerStatsRequest(BaseRequest):
    """Worker状态请求"""

    # 通常不需要参数，这里用于一致性
    pass
