from enum import StrEnum


class MIME_TYPE(StrEnum):
    PDF = "application/pdf"
    JPG = "image/jpeg"
    PNG = "image/png"
    JPEG = "image/jpeg"
    DOC = "application/msword"
    DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    PPT = "application/vnd.ms-powerpoint"
    PPTX = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
