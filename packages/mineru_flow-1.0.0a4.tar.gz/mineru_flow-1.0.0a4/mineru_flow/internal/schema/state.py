from enum import StrEnum


class State(StrEnum):
    ENABLED = "enabled"
    DISABLED = "disabled"


class Phase(StrEnum):
    PARSE = "parse"
    CHUNK = "chunk"
    IMPORT = "import"


class JobStatus(StrEnum):
    WAITING = "waiting"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"
