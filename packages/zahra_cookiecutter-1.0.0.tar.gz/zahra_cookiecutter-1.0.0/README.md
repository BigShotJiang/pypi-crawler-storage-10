# zahra-cookiecutter

![PyPI version](https://img.shields.io/pypi/v/zahra-cookiecutter.svg)
[![Documentation Status](https://readthedocs.org/projects/zahra-cookiecutter/badge/?version=latest)](https://zahra-cookiecutter.readthedocs.io/en/latest/?version=latest)

the best package in teh world

* PyPI package: https://pypi.org/project/zahra-cookiecutter/
* Free software: MIT License
* Documentation: https://zahra-cookiecutter.readthedocs.io.

## Features

* TODO

## Credits

This package was created with [Cookiecutter](https://github.com/audreyfeldroy/cookiecutter) and the [audreyfeldroy/cookiecutter-pypackage](https://github.com/audreyfeldroy/cookiecutter-pypackage) project template.
