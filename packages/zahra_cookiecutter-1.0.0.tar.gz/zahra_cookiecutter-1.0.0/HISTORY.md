# History

## 1.0.0 (2025-10-27)

* First release on PyPI.
