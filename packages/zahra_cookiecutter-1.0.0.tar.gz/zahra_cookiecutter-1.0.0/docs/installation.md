# Installation

## Stable release

To install zahra-cookiecutter, run this command in your terminal:

```sh
uv add zahra-cookiecutter
```

Or if you prefer to use `pip`:

```sh
pip install zahra-cookiecutter
```

## From source

The source files for zahra-cookiecutter can be downloaded from the [Github repo](https://github.com/ahra3/zahra_cookiecutter).

You can either clone the public repository:

```sh
git clone git://github.com/ahra3/zahra_cookiecutter
```

Or download the [tarball](https://github.com/ahra3/zahra_cookiecutter/tarball/master):

```sh
curl -OJL https://github.com/ahra3/zahra_cookiecutter/tarball/master
```

Once you have a copy of the source, you can install it with:

```sh
cd zahra_cookiecutter
uv pip install .
```
