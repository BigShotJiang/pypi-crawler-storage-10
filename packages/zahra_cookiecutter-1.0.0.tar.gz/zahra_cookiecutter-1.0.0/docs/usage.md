# Usage

To use zahra-cookiecutter in a project:

```python
import zahra_cookiecutter
```
