"""Console script for zahra_cookiecutter."""

import typer
from rich.console import Console

from zahra_cookiecutter import utils

app = typer.Typer()
console = Console()


@app.command()
def main():
    """Console script for zahra_cookiecutter."""
    console.print("Replace this message by putting your code into "
               "zahra_cookiecutter.cli.main")
    console.print("See Typer documentation at https://typer.tiangolo.com/")
    utils.do_something_useful()


if __name__ == "__main__":
    app()
