"""Top-level package for zahra-cookiecutter."""

__author__ = """MAROUF Zohra"""
__email__ = 'z.marouf@esi-sba.dz'
