from setuptools import setup

setup(
    name="test_transformers",
    version="0.2.0",
    py_modules=["test_transformers"],   # since it's a single .py file
    author="Your Name",
    description="A test package for learning PyPI uploads",
    python_requires=">=3.8",
)
