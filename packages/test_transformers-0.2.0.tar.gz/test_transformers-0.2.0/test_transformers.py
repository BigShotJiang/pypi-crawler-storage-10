def DL():
    code = """\ 
import torch
import torch.nn as nn
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay

# Load CSV
df = pd.read_csv('data.csv')
values = df['value'].values.astype(float)

def create_sequences(data, seq_len):
    xs, ys = [], []
    for i in range(len(data)-seq_len):
        xs.append(data[i:i+seq_len])
        ys.append(data[i+seq_len])
    return np.array(xs), np.array(ys)

SEQ_LEN = 5
X, y = create_sequences(values, SEQ_LEN)
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, shuffle=False)

X_train = torch.tensor(X_train, dtype=torch.float32).unsqueeze(-1)
X_val = torch.tensor(X_val, dtype=torch.float32).unsqueeze(-1)
y_train = torch.tensor(y_train, dtype=torch.float32)
y_val = torch.tensor(y_val, dtype=torch.float32)

class RNNModel(nn.Module):
    def __init__(self, input_size=1, hidden_size=32):
        super().__init__()
        self.rnn = nn.RNN(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, 1)
    def forward(self, x):
        out, _ = self.rnn(x)
        return self.fc(out[:, -1, :])

model = RNNModel()
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.01)

train_losses, val_losses = [], []
for epoch in range(100):
    model.train()
    optimizer.zero_grad()
    out = model(X_train)
    loss = criterion(out.squeeze(), y_train)
    loss.backward()
    optimizer.step()

    model.eval()
    with torch.no_grad():
        val_pred = model(X_val)
        val_loss = criterion(val_pred.squeeze(), y_val)
    train_losses.append(loss.item())
    val_losses.append(val_loss.item())

# Train vs Val loss
plt.figure(figsize=(8,4))
plt.plot(train_losses, label='Train Loss')
plt.plot(val_losses, label='Validation Loss')
plt.title('RNN Train vs Validation Loss')
plt.legend()
plt.show()

# Predicted vs Actual
with torch.no_grad():
    preds = model(X_val).squeeze().numpy()
plt.figure(figsize=(8,4))
plt.plot(y_val, label='Actual')
plt.plot(preds, label='Predicted')
plt.title('RNN Predictions vs Actual')
plt.legend()
plt.show()

#  Residuals and Histogram
residuals = y_val.numpy() - preds
plt.figure(figsize=(8,4))
plt.plot(residuals, color='r')
plt.axhline(0, color='black', linestyle='--')
plt.title('Prediction Residuals')
plt.show()

plt.figure(figsize=(6,4))
sns.histplot(residuals, bins=30, kde=True, color='teal')
plt.title('Residual Error Distribution')
plt.show()

# Correlation heatmap of input sequences
corr = pd.DataFrame(X_val.squeeze().numpy()).corr()
plt.figure(figsize=(6,5))
sns.heatmap(corr, annot=False, cmap='coolwarm')
plt.title('Input Sequence Correlation')
plt.show()

# Confusion matrix (convert regression to discrete bins)
bins = np.linspace(min(values), max(values), 5)
y_true_binned = np.digitize(y_val, bins)
y_pred_binned = np.digitize(preds, bins)
cm = confusion_matrix(y_true_binned, y_pred_binned)
disp = ConfusionMatrixDisplay(confusion_matrix=cm)
disp.plot(cmap='Purples')
plt.title('Confusion Matrix (Discretized Regression)')
plt.show()

##Autoencoder 
import torch
import torch.nn as nn
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
import numpy as np

# Load data
df = pd.read_csv('data.csv')
X = torch.tensor(df.values, dtype=torch.float32)

class AE(nn.Module):
    def __init__(self, input_dim):
        super().__init__()
        self.encoder = nn.Sequential(nn.Linear(input_dim, 16), nn.ReLU(), nn.Linear(16, 4))
        self.decoder = nn.Sequential(nn.Linear(4, 16), nn.ReLU(), nn.Linear(16, input_dim))
    def forward(self, x): return self.decoder(self.encoder(x))
    def encode(self, x): return self.encoder(x)

model = AE(X.shape[1])
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.01)

losses = []
for epoch in range(100):
    optimizer.zero_grad()
    output = model(X)
    loss = criterion(output, X)
    loss.backward()
    optimizer.step()
    losses.append(loss.item())

# Loss curve
plt.plot(losses, label='Training Loss')
plt.title('Autoencoder Loss Curve')
plt.legend()
plt.show()

# Reconstruction comparison
with torch.no_grad():
    rec = model(X).numpy()
err = X.numpy() - rec

plt.plot(X[:,0], label='Original')
plt.plot(rec[:,0], label='Reconstructed')
plt.legend(); plt.title('Original vs Reconstructed (Feature 1)')
plt.show()

# Error heatmap
sns.heatmap(err, cmap='coolwarm', center=0)
plt.title('Reconstruction Error Heatmap')
plt.show()

# Error histogram
sns.histplot(err.flatten(), bins=50, kde=True)
plt.title('Reconstruction Error Distribution')
plt.show()



# Confusion matrix (error region classification)
bins = np.linspace(err.min(), err.max(), 5)
true_binned = np.digitize(X[:,0], bins)
pred_binned = np.digitize(rec[:,0], bins)
cm = confusion_matrix(true_binned, pred_binned)
ConfusionMatrixDisplay(confusion_matrix=cm).plot(cmap='Reds')
plt.title('Confusion Matrix (Binned Reconstruction)')
plt.show()

##RNN Text file 
import torch, torch.nn as nn, seaborn as sns, matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
import numpy as np

# Load and encode text
text = open('text.txt','r',encoding='utf-8').read()
chars = sorted(list(set(text)))
c2i = {c:i for i,c in enumerate(chars)}
i2c = {i:c for i,c in enumerate(chars)}
enc = [c2i[c] for c in text]
SEQ_LEN = 40
X, y = [], []
for i in range(len(enc)-SEQ_LEN):
    X.append(enc[i:i+SEQ_LEN])
    y.append(enc[i+SEQ_LEN])
X, y = torch.tensor(X), torch.tensor(y)

class CharRNN(nn.Module):
    def __init__(self, vocab, hidden=128):
        super().__init__()
        self.embed = nn.Embedding(vocab, hidden)
        self.rnn = nn.RNN(hidden, hidden, batch_first=True)
        self.fc = nn.Linear(hidden, vocab)
    def forward(self, x):
        e = self.embed(x)
        out,_ = self.rnn(e)
        return self.fc(out[:,-1,:])

vocab = len(chars)
model = CharRNN(vocab)
opt = torch.optim.Adam(model.parameters(), lr=0.003)
crit = nn.CrossEntropyLoss()
losses, accs = [], []

for epoch in range(30):
    opt.zero_grad()
    out = model(X)
    loss = crit(out, y)
    losses.append(loss.item())
    preds = torch.argmax(out, dim=1)
    acc = (preds == y).float().mean().item()
    accs.append(acc)
    loss.backward()
    opt.step()
    if (epoch+1)%5==0:
        print(f'Epoch {epoch+1}: Loss={loss.item():.4f}, Acc={acc:.2f}')

# Loss & Accuracy
fig,ax=plt.subplots(1,2,figsize=(10,4))
ax[0].plot(losses); ax[0].set_title('Loss')
ax[1].plot(accs); ax[1].set_title('Accuracy')
plt.show()

# Confusion matrix (chars)
cm = confusion_matrix(y.numpy(), preds.numpy(), labels=list(range(vocab)))
ConfusionMatrixDisplay(cm, display_labels=chars).plot(cmap='Blues')
plt.title('Character Confusion Matrix')
plt.xticks(rotation=90)
plt.show()

# Probability heatmap
probs = torch.softmax(out, dim=1).detach().numpy()
sns.heatmap(probs[:50], cmap='YlGnBu')
plt.title('Character Probability Heatmap (First 50 Samples)')
plt.xlabel('Character Index')
plt.ylabel('Sample Index')
plt.show()


    """

def CV():
    code = """\ 
    import cv2
import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Tuple


def morphological_skeleton(img: np.ndarray) -> np.ndarray:
    img = img.copy().astype(np.uint8)
    skel = np.zeros(img.shape, np.uint8)
    kernel = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
    while True:
        eroded = cv2.erode(img, kernel)
        opened = cv2.dilate(eroded, kernel)
        temp = cv2.subtract(img, opened)
        skel = cv2.bitwise_or(skel, temp)
        img = eroded.copy()
        if cv2.countNonZero(img) == 0:
            break
    return (skel * 255).astype(np.uint8)


def zhang_suen_thinning(img: np.ndarray, max_iter: int = -1) -> np.ndarray:
    thinned = img.copy().astype(np.uint8)
    rows, cols = thinned.shape
    iteration = 0
    changed = True

    def neighbours(i, j):
        return [
            thinned[i - 1, j], thinned[i - 1, j + 1], thinned[i, j + 1], thinned[i + 1, j + 1],
            thinned[i + 1, j], thinned[i + 1, j - 1], thinned[i, j - 1], thinned[i - 1, j - 1]
        ]

    def transitions(neigh):
        return sum((neigh[k] == 0 and neigh[(k + 1) % 8] == 1) for k in range(8))

    while changed and (max_iter < 0 or iteration < max_iter):
        changed = False
        pixels_to_remove = []
        # Step 1
        for i in range(1, rows - 1):
            for j in range(1, cols - 1):
                if thinned[i, j] != 1:
                    continue
                neigh = neighbours(i, j)
                nwhite = sum(neigh)
                if not (2 <= nwhite <= 6):
                    continue
                if transitions(neigh) != 1:
                    continue
                if neigh[0] * neigh[2] * neigh[4] != 0:
                    continue
                if neigh[2] * neigh[4] * neigh[6] != 0:
                    continue
                pixels_to_remove.append((i, j))
        if pixels_to_remove:
            changed = True
            for i, j in pixels_to_remove:
                thinned[i, j] = 0
        iteration += 1
        if max_iter >= 0 and iteration >= max_iter:
            break
        pixels_to_remove = []
        # Step 2
        for i in range(1, rows - 1):
            for j in range(1, cols - 1):
                if thinned[i, j] != 1:
                    continue
                neigh = neighbours(i, j)
                nwhite = sum(neigh)
                if not (2 <= nwhite <= 6):
                    continue
                if transitions(neigh) != 1:
                    continue
                if neigh[0] * neigh[2] * neigh[6] != 0:
                    continue
                if neigh[0] * neigh[4] * neigh[6] != 0:
                    continue
                pixels_to_remove.append((i, j))
        if pixels_to_remove:
            changed = True
            for i, j in pixels_to_remove:
                thinned[i, j] = 0
        iteration += 1
    return (thinned * 255).astype(np.uint8)


def load_image(path: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    colour = cv2.imread(path, cv2.IMREAD_COLOR)
    if colour is None:
        raise FileNotFoundError(f"Cannot read image at '{path}'")
    gray = cv2.cvtColor(colour, cv2.COLOR_BGR2GRAY)
    _, binary_u8 = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    binary = binary_u8 > 0
    return colour, gray, binary


def binary_morphology(binary: np.ndarray) -> Dict[str, np.ndarray]:
    bin_int = binary.astype(np.uint8)
    results = {}
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))

    eroded = cv2.erode(bin_int, kernel)
    dilated = cv2.dilate(bin_int, kernel)
    opening = cv2.morphologyEx(bin_int, cv2.MORPH_OPEN, kernel)
    closing = cv2.morphologyEx(bin_int, cv2.MORPH_CLOSE, kernel)
    gradient = cv2.morphologyEx(bin_int, cv2.MORPH_GRADIENT, kernel)
    white_tophat = cv2.morphologyEx(bin_int, cv2.MORPH_TOPHAT, kernel)
    black_tophat = cv2.morphologyEx(bin_int, cv2.MORPH_BLACKHAT, kernel)
    hit_kernel = np.array([[0, 1, 0],
                           [1, -1, 1],
                           [0, 1, 0]], dtype=np.int8)
    hitmiss = cv2.morphologyEx(bin_int, cv2.MORPH_HITMISS, hit_kernel)

    skeleton = morphological_skeleton(bin_int)
    thinned_full = zhang_suen_thinning(bin_int)
    thinned_partial = zhang_suen_thinning(bin_int, max_iter=25)

    pruned = None
    if HAS_PLANTCV:
        skel_u8 = skeleton.copy()
        pcv.params.debug = None
        pruned_skel, _, _ = pcv.morphology.prune(skel_img=skel_u8, size=50)
        pruned = pruned_skel.astype(np.uint8)

    gray = (bin_int * 255).astype(np.uint8)
    orb = cv2.ORB_create(nfeatures=500)
    keypoints, _ = orb.detectAndCompute(gray, None)
    orb_vis = cv2.drawKeypoints(gray, keypoints, None, color=(0, 255, 0))

    def to_display(img):
        if img.dtype == bool:
            return (img.astype(np.uint8) * 255)
        if img.max() <= 1:
            return (img * 255).astype(np.uint8)
        return img.astype(np.uint8)

    results['Binary'] = to_display(bin_int)
    results['Erosion'] = to_display(eroded)
    results['Dilation'] = to_display(dilated)
    results['Opening'] = to_display(opening)
    results['Closing'] = to_display(closing)
    results['Gradient'] = to_display(gradient)
    results['White Top-hat'] = to_display(white_tophat)
    results['Black Top-hat'] = to_display(black_tophat)
    results['Hit-or-Miss'] = to_display(hitmiss)
    results['Skeleton'] = to_display(skeleton)
    results['Thinned (full)'] = to_display(thinned_full)
    results['Thinned (partial)'] = to_display(thinned_partial)
    if pruned is not None:
        results['Pruned Skeleton'] = to_display(pruned)
    results['ORB Keypoints'] = orb_vis.astype(np.uint8)
    return results


def gray_morphology(gray: np.ndarray) -> Dict[str, np.ndarray]:
    results = {}
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))
    opened = cv2.morphologyEx(gray, cv2.MORPH_OPEN, kernel)
    closed = cv2.morphologyEx(gray, cv2.MORPH_CLOSE, kernel)
    white_tophat = cv2.morphologyEx(gray, cv2.MORPH_TOPHAT, kernel)
    black_tophat = cv2.morphologyEx(gray, cv2.MORPH_BLACKHAT, kernel)
    gradient = cv2.morphologyEx(gray, cv2.MORPH_GRADIENT, kernel)
    results['Grayscale'] = gray
    results['Opening'] = opened
    results['Closing'] = closed
    results['White Top-hat'] = white_tophat
    results['Black Top-hat'] = black_tophat
    results['Gradient'] = gradient
    return results


def plot_results(title: str, results: Dict[str, np.ndarray], max_cols: int = 4) -> None:
    n_results = len(results)
    n_cols = min(max_cols, n_results)
    n_rows = int(np.ceil(n_results / n_cols))
    plt.figure(figsize=(4 * n_cols, 4 * n_rows))
    plt.suptitle(title, fontsize=16)
    for idx, (name, img) in enumerate(results.items(), start=1):
        plt.subplot(n_rows, n_cols, idx)
        if img.ndim == 3 and img.shape[2] in (3, 4):
            plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        else:
            plt.imshow(img, cmap='gray')
        plt.title(name, fontsize=10)
        plt.axis('off')
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.show()


def main(image_path: str):
    colour, gray, binary = load_image(image_path)
    bin_results = binary_morphology(binary)
    gray_results = gray_morphology(gray)
    plot_results('Binary Morphology Results', bin_results, max_cols=4)
    plot_results('Grayscale Morphology Results', gray_results, max_cols=3)


# Example usage
if __name__ == "__main__":
    image_path = '/content/Screenshot 2023-12-08 211529.png'
    main(image_path)

    



import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage.feature import graycomatrix, graycoprops, local_binary_pattern
from skimage.color import rgb2gray
from skimage.util import img_as_ubyte
import argparse
import textwrap

def imread_rgb(path):
    img_bgr = cv2.imread(path, cv2.IMREAD_COLOR)
    if img_bgr is None:
        raise FileNotFoundError(f"Could not read image at: {path}")
    return cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)

def to_gray_u8(rgb):
    g = rgb2gray(rgb)  # float64 in [0,1]
    return img_as_ubyte(g)  # uint8 [0,255]

def draw_keypoints(rgb, kps, color=(255, 0, 0), size=2):
    out = rgb.copy()
    for kp in kps:
        x, y = int(kp.pt[0]), int(kp.pt[1])
        cv2.circle(out, (x, y), max(2, int(kp.size/4)) if hasattr(kp, 'size') else size, color, 1, cv2.LINE_AA)
    return out

def annotate_points(rgb, pts, color=(0, 255, 0), radius=3):
    out = rgb.copy()
    if pts is None:
        return out
    for p in pts:
        x, y = int(p[0][0]), int(p[0][1])
        cv2.circle(out, (x, y), radius, color, 1, cv2.LINE_AA)
    return out

def harris_corners(gray_u8, blockSize=2, ksize=3, k=0.04, thresh_ratio=0.01):
    g = np.float32(gray_u8)
    dst = cv2.cornerHarris(g, blockSize, ksize, k)
    dst = cv2.dilate(dst, None)
    # threshold
    thr = thresh_ratio * dst.max()
    ys, xs = np.where(dst > thr)
    return np.column_stack([xs, ys]), dst

def shi_tomasi(gray_u8, maxCorners=500, qualityLevel=0.01, minDistance=8, blockSize=3, useHarrisDetector=False, k=0.04):
    corners = cv2.goodFeaturesToTrack(gray_u8, maxCorners=maxCorners, qualityLevel=qualityLevel,
                                      minDistance=minDistance, blockSize=blockSize,
                                      useHarrisDetector=useHarrisDetector, k=k)
    return corners

def simple_blob_detector(gray_u8):
    params = cv2.SimpleBlobDetector_Params()
    params.filterByArea = True
    params.minArea = 20
    params.maxArea = 1e5
    params.filterByCircularity = False
    params.filterByConvexity = False
    params.filterByInertia = False
    params.minThreshold = 10
    params.maxThreshold = 220
    params.thresholdStep = 10
    detector = cv2.SimpleBlobDetector_create(params)
    kps = detector.detect(gray_u8)
    return kps

def sift_keypoints(gray_u8):
    sift = None
    if hasattr(cv2, "SIFT_create"):
        sift = cv2.SIFT_create()
    else:
        # try xfeatures2d (older OpenCV contrib)
        try:
            sift = cv2.xfeatures2d.SIFT_create()
        except Exception:
            sift = None
    if sift is None:
        return None, None
    kps, des = sift.detectAndCompute(gray_u8, None)
    return kps, des

def surf_keypoints(gray_u8, hessianThreshold=400):
    # SURF is often unavailable unless built with contrib/nonfree
    try:
        surf = cv2.xfeatures2d.SURF_create(hessianThreshold=hessianThreshold)
        kps, des = surf.detectAndCompute(gray_u8, None)
        return kps, des
    except Exception:
        return None, None

def orb_keypoints(gray_u8, nfeatures=1000, scaleFactor=1.2, nlevels=8, edgeThreshold=31, patchSize=31):
    orb = cv2.ORB_create(nfeatures=nfeatures, scaleFactor=scaleFactor, nlevels=nlevels,
                         edgeThreshold=edgeThreshold, patchSize=patchSize)
    kps, des = orb.detectAndCompute(gray_u8, None)
    return kps, des

def glcm_features(gray_u8, distances=(1, 2), angles=(0, np.pi/4, np.pi/2, 3*np.pi/4), levels=256, symmetric=True, normed=True):
    glcm = graycomatrix(gray_u8, distances=distances, angles=angles, levels=levels, symmetric=symmetric, normed=normed)
    feats = {}
    # standard props
    props = ["contrast", "dissimilarity", "homogeneity", "energy", "correlation", "ASM"]
    for p in props:
        feats[p] = graycoprops(glcm, p)
    return glcm, feats, distances, angles

def lbp_texture(gray_u8, P=8, R=1.0, method='uniform'):
    lbp = local_binary_pattern(gray_u8, P=P, R=R, method=method)
    # normalized histogram (for quick summary)
    n_bins = int(lbp.max() + 1)
    hist, _ = np.histogram(lbp.ravel(), bins=n_bins, range=(0, n_bins), density=True)
    return lbp, hist

def format_glcm_table(feats, distances, angles):
    # Create a simple string table for printing
    lines = []
    angle_deg = [int(np.rad2deg(a)) for a in angles]
    for name, arr in feats.items():
        lines.append(f"\n{name.upper()}:")
        for i, d in enumerate(distances):
            row = f"  d={d:>2} | " + "  ".join([f"{name[:4]}[{d},{ang:>3}°]={arr[i, j]: .4f}" for j, ang in enumerate(angle_deg)])
            lines.append(row)
    return "\n".join(lines)

def show_all(rgb, gray_u8, results):
    plt.figure(figsize=(18, 20))
    idx = 1

    # Original
    plt.subplot(5, 3, idx); idx += 1
    plt.imshow(rgb); plt.title("Original (RGB)"); plt.axis('off')

    # Gray
    plt.subplot(5, 3, idx); idx += 1
    plt.imshow(gray_u8, cmap='gray'); plt.title("Grayscale"); plt.axis('off')

    # Harris heatmap
    harris_pts, harris_resp = results['harris']
    plt.subplot(5, 3, idx); idx += 1
    plt.imshow(harris_resp, cmap='magma'); plt.title("Harris Response"); plt.axis('off')

    # Harris overlay
    rgb_harris = rgb.copy()
    for x, y in harris_pts:
        cv2.circle(rgb_harris, (int(x), int(y)), 2, (255, 0, 0), 1, cv2.LINE_AA)
    plt.subplot(5, 3, idx); idx += 1
    plt.imshow(rgb_harris); plt.title(f"Harris Corners (N={len(harris_pts)})"); plt.axis('off')

    # Shi-Tomasi overlay
    shi_pts = results['shi']
    overlay_shi = annotate_points(rgb, shi_pts, color=(0, 255, 0), radius=3)
    n_shi = 0 if shi_pts is None else shi_pts.shape[0]
    plt.subplot(5, 3, idx); idx += 1
    plt.imshow(overlay_shi); plt.title(f"Shi–Tomasi Corners (N={n_shi})"); plt.axis('off')

    # Blobs (SimpleBlobDetector)
    blob_kps = results['blobs']
    overlay_blob = draw_keypoints(rgb, blob_kps, color=(255, 0, 255), size=3) if blob_kps else rgb
    n_blob = 0 if blob_kps is None else len(blob_kps)
    plt.subplot(5, 3, idx); idx += 1
    plt.imshow(overlay_blob); plt.title(f"Blobs (SimpleBlobDetector) N={n_blob}"); plt.axis('off')

    # SIFT
    sift_kps = results['sift'][0]
    if sift_kps is not None:
        overlay_sift = draw_keypoints(rgb, sift_kps, color=(255, 255, 0), size=2)
        title = f"SIFT keypoints (N={len(sift_kps)})"
    else:
        overlay_sift = rgb
        title = "SIFT not available in this OpenCV build"
    plt.subplot(5, 3, idx); idx += 1
    plt.imshow(overlay_sift); plt.title(title); plt.axis('off')

    # SURF
    surf_kps = results['surf'][0]
    if surf_kps is not None:
        overlay_surf = draw_keypoints(rgb, surf_kps, color=(0, 255, 255), size=2)
        title = f"SURF keypoints (N={len(surf_kps)})"
    else:
        overlay_surf = rgb
        title = "SURF not available (requires contrib/nonfree)"
    plt.subplot(5, 3, idx); idx += 1
    plt.imshow(overlay_surf); plt.title(title); plt.axis('off')

    # ORB
    orb_kps = results['orb'][0]
    overlay_orb = draw_keypoints(rgb, orb_kps, color=(0, 255, 0), size=2)
    plt.subplot(5, 3, idx); idx += 1
    plt.imshow(overlay_orb); plt.title(f"ORB keypoints (N={len(orb_kps)})"); plt.axis('off')

    # LBP image
    lbp_img = results['lbp'][0]
    plt.subplot(5, 3, idx); idx += 1
    plt.imshow(lbp_img, cmap='gray'); plt.title("LBP (P=8, R=1, uniform)"); plt.axis('off')

    # GLCM heatmap (aggregate one angle/distance for demo)
    glcm, glcm_feats, distances, angles = results['glcm']
    # Pick first distance & angle to visualize co-occurrence
    glcm_vis = glcm[:, :, 0, 0]
    plt.subplot(5, 3, idx); idx += 1
    plt.imshow(glcm_vis, cmap='inferno'); plt.title(f"GLCM d={distances[0]}, θ={int(np.rad2deg(angles[0]))}°"); plt.axis('off')

    # Text panel for GLCM stats
    glcm_text = format_glcm_table(glcm_feats, distances, angles)
    plt.subplot(5, 3, idx); idx += 1
    plt.axis('off')
    wrapped = textwrap.fill(glcm_text, width=90, subsequent_indent='   ')
    plt.text(0, 0.9, "GLCM Summary (across distances & angles):", fontsize=11, va='top', family='monospace')
    plt.text(0, 0.85, wrapped, fontsize=9, va='top', family='monospace')

    plt.tight_layout()
    plt.show()

def run_all(image_path):
    rgb = imread_rgb(image_path)
    gray_u8 = to_gray_u8(rgb)

    # Corners
    harris_pts, harris_resp = harris_corners(gray_u8, blockSize=2, ksize=3, k=0.04, thresh_ratio=0.01)
    shi_pts = shi_tomasi(gray_u8, maxCorners=600, qualityLevel=0.01, minDistance=6, blockSize=3)

    # Blobs
    blob_kps = simple_blob_detector(gray_u8)

    # SIFT / SURF / ORB
    sift_kps, sift_des = sift_keypoints(gray_u8)
    surf_kps, surf_des = surf_keypoints(gray_u8)
    orb_kps, orb_des = orb_keypoints(gray_u8)

    # Texture: GLCM + LBP
    glcm = glcm_features(gray_u8, distances=(1, 2), angles=(0, np.pi/4, np.pi/2, 3*np.pi/4))
    lbp_img, lbp_hist = lbp_texture(gray_u8, P=8, R=1.0, method='uniform')

    # Print concise numeric summaries to console
    print(f"Shi–Tomasi corners: {0 if shi_pts is None else shi_pts.shape[0]}")
    print(f"Harris corners (thresholded): {len(harris_pts)}")
    print(f"Blobs (SimpleBlobDetector): {0 if blob_kps is None else len(blob_kps)}")
    print(f"SIFT: {'available' if sift_kps is not None else 'NOT available'}, keypoints={0 if sift_kps is None else len(sift_kps)}")
    print(f"SURF: {'available' if surf_kps is not None else 'NOT available'}, keypoints={0 if surf_kps is None else len(surf_kps)}")
    print(f"ORB keypoints: {len(orb_kps)}")
    print(f"LBP histogram bins: {len(lbp_hist)}, sum={lbp_hist.sum():.3f}")

    results = {
        'harris': (harris_pts, harris_resp),
        'shi': shi_pts,
        'blobs': blob_kps,
        'sift': (sift_kps, sift_des),
        'surf': (surf_kps, surf_des),
        'orb': (orb_kps, orb_des),
        'glcm': glcm,  # (glcm, feats, distances, angles)
        'lbp': (lbp_img, lbp_hist)
    }
    show_all(rgb, gray_u8, results)

if __name__ == "__main__":
    run_all("/content/Screenshot 2023-12-08 211529.png")

    """