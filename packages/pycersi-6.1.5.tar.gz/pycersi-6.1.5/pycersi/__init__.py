# __init__.py

__name__ = 'PyCersi'
__version__ = '6.1.5'
__author__ = 'Subhra Chakraborti'
__author_email__ = 'mail@subhrachakraborti.com'

from .pycersi import *