from subsurface import StructuredData


class OctreeMesh:
    """
    TODO: implement as Dom discussed with data frames to track the levels.
    """

    def __init__(self, data: StructuredData):
        raise NotImplementedError
