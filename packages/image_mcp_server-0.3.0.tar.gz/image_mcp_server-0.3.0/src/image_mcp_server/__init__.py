"""
Image MCP Server

一个完整的 MCP 服务器，支持图片分析和生成。
- 分析：支持本地文件、HTTP URL 和剪贴板图片，基于 qwen3-vl-plus 模型
- 生成：使用 qwen-image-plus 模型根据文本描述生成图片
基于阿里云 DashScope 服务。
"""

__version__ = "0.3.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .server import main

__all__ = ["main", "__version__"]