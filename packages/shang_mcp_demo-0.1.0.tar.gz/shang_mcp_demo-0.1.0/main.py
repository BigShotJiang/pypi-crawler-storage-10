def main():
    print("Hello from shang-mcp-demo!")


if __name__ == "__main__":
    main()
