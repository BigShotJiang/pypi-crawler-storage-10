from enum import Enum


class DetailType(Enum):
    """
        Enum for starting details type
    """
    CONFIG_WEAKNESS_COMP = "config_weakness_comp"
    CONFIG_WEAKNESS_ATTACKER = "config_weakness_attacker"
    CONFIG_WEAKNESS_CONDITION = "config_weakness_condition"
    CONFIG_ATTACKER_IMPACT = "config_attacker_impact"
    CONFIG_CAUSE_ATTACKER = "config_cause_attacker"
    CONFIG_CAUSE_WEAKNESS = "config_cause_weakness"
    CONFIG_CONDITION_CAUSE = "config_condition_cause"
    CONFIG_CAUSE_CONDITION = "config_cause_condition"
    WEAKNESS_COMP_CONFIG = "weakness_comp_config"
    WEAKNESS_CONFIG_COMP = "weakness_config_comp"
    WEAKNESS_CONFIG_ATTACKER = "weakness_config_attacker"
    WEAKNESS_CONFIG_VECTOR = "weakness_config_vector"
    WEAKNESS_CONFIG_CAUSE = "weakness_config_cause"
    WEAKNESS_CONFIG_CONDITION = "weakness_config_condition"
    COMPONENT_CONFIG_WEAKNESS = "comp_config_weakness"
    COMPONENT_CONFIG_ATTACKER = "comp_config_attacker"
    COMPONENT_CONFIG_CAUSE = "comp_config_cause"
    COMPONENT_CONFIG_CONDITION = "comp_config_condition"
