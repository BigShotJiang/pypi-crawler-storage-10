"""Module for some error mappings."""
