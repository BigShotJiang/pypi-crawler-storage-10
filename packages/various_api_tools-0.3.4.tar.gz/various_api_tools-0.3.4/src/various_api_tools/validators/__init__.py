"""Module for various API validators."""
