from setuptools import setup, find_packages

setup(
    name="rdash_sdk",
    version="0.1.0",
    description="A Python library for RDash SDK",
    author="RDash",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[
        "requests>=2.28,<3.0",
    ],
)