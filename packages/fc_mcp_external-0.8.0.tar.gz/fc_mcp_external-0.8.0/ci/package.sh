#!/usr/bin/env bash

set -x

declare ROOT_HOME="$(cd "$(cd "$(dirname "$0")"; pwd -P)"/..; pwd)"

python3 $ROOT_HOME/setup.py clean
python3 $ROOT_HOME/setup.py sdist fc_server
python3 $ROOT_HOME/setup.py sdist fc_guarder
python3 $ROOT_HOME/setup.py sdist fc_client
python3 $ROOT_HOME/setup.py sdist fc_client_docker
python3 $ROOT_HOME/setup.py sdist fc_agent
python3 $ROOT_HOME/setup.py sdist fc_mcp_external
