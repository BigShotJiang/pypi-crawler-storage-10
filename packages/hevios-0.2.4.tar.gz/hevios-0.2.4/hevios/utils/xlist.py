class XList:
    @staticmethod
    def subtraction(subtrahend, minuend):
        '''
        列表减法计算，注意可能涉及到类型转换，比如字符串类型1比较是不相等的。

        :param subtrahend: 减数列表.
        :param minuend: 被减数列表.
        :return: 存在减数列表且不在被减数列表中的元素.
        '''
        return [item for item in subtrahend if item not in minuend]