
import importlib, importlib.util, os
from ..core.logger import Logger

class SetX:
    _log = Logger.default()

    def __init__(self, log=None):
        if log is not None:
            self._log = log
        else:
            self._log = Logger.default(False)
        if self.check_pip("subprocess") is False:
            os.system("pip install subprocess -i https://pypi.tuna.tsinghua.edu.cn/simple")

    def check_pip(self, package):
        return importlib.util.find_spec(package) is not None

    def with_pips(self, packages):
        for package in packages:
            self.with_pip(package=package)

    def with_pip(self, package):
        import subprocess
        if self.check_pip(package) is False:
            self._log.info(f"Install packages: {package}")
            subprocess.call(f'pip install {package} -i https://pypi.tuna.tsinghua.edu.cn/simple',
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            self._log.info(f"Install packages: {package} Exist!", green_color=True)
