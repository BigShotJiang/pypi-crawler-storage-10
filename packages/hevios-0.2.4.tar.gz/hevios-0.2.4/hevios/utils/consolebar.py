import sys
import threading
import time
from typing import Optional


class ConsoleBar:
    def __init__(self, total: int, package_name: str = "未知包", bar_length: int = 40,
                 min_refresh_interval: float = 0.1):
        """
        初始化apt风格的进度条（优化闪烁问题）

        :param total: 总进度值
        :param package_name: 包名称
        :param bar_length: 进度条长度（字符数）
        :param min_refresh_interval: 最小刷新间隔（秒），控制闪烁频率
        """
        self.total = total
        self.package_name = package_name
        self.bar_length = bar_length
        self.min_refresh_interval = min_refresh_interval  # 限制刷新频率

        self.current = 0
        self.lock = threading.Lock()
        self._last_lines = 0
        self._is_complete = False
        self._last_draw_time = 0  # 上次绘制时间
        self._pending_status = "正在处理"  # 待更新的状态（避免频繁刷新）

    def update(self, increment: int = 1, status: Optional[str] = None) -> None:
        """更新进度，带频率控制"""
        with self.lock:
            if self._is_complete:
                return

            # 更新进度和状态（先缓存，不立即绘制）
            self.current = min(self.current + increment, self.total)
            if status:
                self._pending_status = status

            # 检查是否需要刷新（满足时间间隔或进度变化显著）
            now = time.time()
            should_refresh = (
                    now - self._last_draw_time >= self.min_refresh_interval  # 时间间隔够了
                    or self.current >= self.total  # 完成时强制刷新
                    or (self.total > 0 and self._get_percent() % 5 == 0)  # 每5%强制刷新一次
            )

            if should_refresh:
                self._draw()
                self._last_draw_time = now

            # 检查是否完成
            if self.current >= self.total:
                self._is_complete = True

    def _get_percent(self) -> int:
        """计算当前进度百分比"""
        return int((self.current / self.total) * 100) if self.total != 0 else 100

    def _draw(self) -> None:
        """优化绘制逻辑，减少不必要的清屏操作"""
        # 清除上一次的进度条
        if self._last_lines > 0:
            # 上移光标并清除当前行及以下内容（减少闪烁）
            sys.stdout.write(f"\033[{self._last_lines}A\033[J")

        # 构建进度条
        percent = self._get_percent()
        filled = int(self.bar_length * (self.current / self.total)) if self.total != 0 else self.bar_length
        bar = '=' * filled + ('>' if filled < self.bar_length else '')
        bar = bar.ljust(self.bar_length)

        # 构建apt风格输出
        status_line = f"状态: {self._pending_status}"
        progress_line = (
            f"进度 {self.package_name}: "
            f"[{bar}] {percent}% "
            f"({self.current}/{self.total})"
        )

        # 输出并刷新
        sys.stdout.write(f"{status_line}\n{progress_line}\n")
        sys.stdout.flush()
        self._last_lines = 2

    def done(self, message: str = "操作完成") -> None:
        """完成时强制刷新并显示结果"""
        with self.lock:
            self._is_complete = True
            if self._last_lines > 0:
                sys.stdout.write(f"\033[{self._last_lines}A\033[J")

            sys.stdout.write(f"成功：{message}\n")
            sys.stdout.flush()
            self._last_lines = 1