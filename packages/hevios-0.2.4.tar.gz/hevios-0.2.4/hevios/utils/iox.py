import os
from typing import List, Optional
class Iox:
    @staticmethod
    def get_files(
            directory: str,
            filter: Optional[str] = None,
            toponly: bool = False
    ) -> List[str]:
        """
        获取目录中所有文件的路径列表

        :param directory: 目标目录路径
        :param filter: 文件类型过滤（如 '.txt' 只获取txt文件，None则不过滤）
        :param toponly: 是否只获取顶层目录文件（True：不递归子目录，False：递归所有子目录）
        :return: 文件路径列表（绝对路径）
        """
        if not os.path.isdir(directory):
            raise ValueError(f"目录不存在或不是有效目录: {directory}")

        file_paths = []
        # 遍历目录（toponly控制是否递归）
        walk_generator = os.walk(directory)

        for root, _, files in walk_generator:
            for file in files:
                # 构建文件绝对路径
                file_path = os.path.abspath(os.path.join(root, file))

                # 应用文件类型过滤
                if filter is not None:
                    # 统一处理后缀名格式（确保以.开头）
                    if not filter.startswith('.'):
                        filter = f'.{filter}'
                    if not file.endswith(filter):
                        continue  # 跳过不符合类型的文件

                file_paths.append(file_path)

            # 如果只获取顶层目录，遍历一次后退出
            if toponly:
                break

        return file_paths

    @staticmethod
    def mkdirs(dir, exist_ok=True, mask=0o777):
        """
        创建多级目录的方法.

        :param dir: 需要创建的目录路径.
        :param exist_ok: 如果目录已经存在，是否忽略错误.
        :param mask: 目录的权限掩码.
        """
        os.makedirs(dir, exist_ok=exist_ok, mode=mask)

    @staticmethod
    def get_directories(directory: str, name_filter: Optional[str] = None, toponly: bool = False) -> List[str]:
        """
        获取目录中所有子目录的路径列表

        :param directory: 目标目录路径
        :param name_filter: 目录名称过滤（支持模糊匹配，如包含"test"的目录；None则不过滤）
        :param toponly: 是否只获取顶层目录（True：不递归子目录，False：递归所有子目录）
        :return: 目录路径列表（绝对路径）
        """
        if not os.path.isdir(directory):
            raise ValueError(f"目录不存在或不是有效目录: {directory}")

        dir_paths = []
        # 遍历目录（toponly控制是否递归）
        walk_generator = os.walk(directory)

        for root, dirs, _ in walk_generator:
            for dir_name in dirs:
                # 构建目录绝对路径
                dir_path = os.path.abspath(os.path.join(root, dir_name))

                # 应用目录名称过滤（模糊匹配）
                if name_filter is not None:
                    if name_filter not in dir_name:
                        continue  # 跳过名称不包含过滤字符的目录

                dir_paths.append(dir_path)

            # 如果只获取顶层目录，遍历一次后退出
            if toponly:
                break

        return dir_paths