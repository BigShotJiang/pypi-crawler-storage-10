import platform,sys,os
from .logger import Logger
from ..utils import SetX
class Runtime:
    logger: Logger = Logger().default(False)
    @staticmethod
    def use_virtual(use: bool):
        """
        是否使用虚拟环境，注意此方法目前有Bug，不能使用
        :param use: 是否使用
        :return:
        """
        set = SetX()
        set.with_pip('uv')
        env_name = Runtime.random_str(10)
        os.system(f'uv venv {env_name}')

    @staticmethod
    def random_str(length: int = 10):
        """
            生成随机字符串，规则[A-Za-z]+[A-Za-z0-9]+

            Args:
                length (int): 字符串长度，必须大于0

            Returns:
                str: 生成的随机字符串

            Raises:
                ValueError: 当长度小于1时抛出异常
            """
        if length < 1:
            raise ValueError("字符串长度必须大于0")
        set = SetX()
        set.with_pips(['string', 'random'])
        import string, random
        # 定义字符集：大小写字母和数字
        letters = string.ascii_letters  # 包含大小写字母
        digits = string.digits  # 包含数字

        # 第一个字符必须是字母（不能是数字）
        first_char = random.choice(letters)

        # 剩余字符可以从字母和数字中随机选择
        if length > 1:
            remaining_chars = random.choices(letters + digits, k=length - 1)
            return first_char + ''.join(remaining_chars)
        else:
            return first_char
    """运行时环境检测类"""
    @staticmethod
    def get_os_info():
        """获取详细的操作系统信息"""
        return {
            'system': platform.system(),
            'release': platform.release(),
            'version': platform.version(),
            'machine': platform.machine(),
            'processor': platform.processor()
        }

    @staticmethod
    def is_windows():
        """判断是否为Windows系统"""
        return platform.system().lower() == 'windows'

    @staticmethod
    def is_linux():
        """判断是否为Linux系统"""
        return platform.system().lower() == 'linux'

    @staticmethod
    def is_macos():
        """判断是否为macOS系统"""
        return platform.system().lower() == 'darwin'

    @staticmethod
    def get_windows_version():
        """获取Windows版本信息"""
        if not Runtime.is_windows():
            return None

        # 获取详细版本信息
        version = sys.getwindowsversion()
        return {
            'major': version.major,
            'minor': version.minor,
            'build': version.build,
            'platform': version.platform,
            'service_pack': version.service_pack
        }

    @staticmethod
    def get_linux_distribution():
        """获取Linux发行版信息"""
        if not Runtime.is_linux():
            return None

        try:
            # 尝试读取 /etc/os-release
            with open('/etc/os-release', 'r') as f:
                lines = f.readlines()
                info = {}
                for line in lines:
                    if '=' in line:
                        key, value = line.strip().split('=', 1)
                        info[key] = value.strip('"')
                return info
        except FileNotFoundError:
            # 备用方法
            try:
                import distro
                return {
                    'id': distro.id(),
                    'name': distro.name(),
                    'version': distro.version(),
                    'like': distro.like()
                }
            except ImportError:
                return None

    @staticmethod
    def get_macos_version():
        """获取macOS版本信息"""
        if not Runtime.is_macos():
            return None

        try:
            # 使用 platform.mac_ver() 获取版本
            version = platform.mac_ver()[0]
            return version
        except:
            return None

    @classmethod
    def get_platform_specific_paths(cls):
        """获取平台特定的路径"""
        if cls.is_windows():
            return {
                'home': os.path.expanduser('~'),
                'temp': os.environ.get('TEMP', ''),
                'appdata': os.environ.get('APPDATA', ''),
                'program_files': os.environ.get('ProgramFiles', '')
            }
        elif cls.is_linux():
            return {
                'home': os.path.expanduser('~'),
                'temp': '/tmp',
                'config': os.path.expanduser('~/.config'),
                'cache': os.path.expanduser('~/.cache')
            }
        elif cls.is_macos():
            return {
                'home': os.path.expanduser('~'),
                'temp': '/tmp',
                'applications': '/Applications',
                'library': os.path.expanduser('~/Library')
            }
        else:
            return {}

    @classmethod
    def get_environment_summary(cls):
        """获取完整的环境摘要"""
        return {
            'os_info': cls.get_os_info(),
            'platform_paths': cls.get_platform_specific_paths(),
            'python_version': sys.version,
            'architecture': platform.architecture()
        }
    @staticmethod
    def sys_time():
        import datetime
        return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
