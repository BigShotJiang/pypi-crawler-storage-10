try:
    import requests
    from typing import Dict, Any, Optional, Union
except ModuleNotFoundError as e :
    from .utils import SetX
    _set = SetX()
    _set.with_pips(['requests','typing'])

class WebX:
    def __init__(self):
        self._url = ""
        self._method = "GET"
        self._headers = {}
        self._cookies = {}
        self._params = {}
        self._data = {}
        self._json_data = {}
        self._timeout = 30
        self._session = requests.Session()

    def get(self, url: str, params: Optional[Dict] = None):
        """设置GET请求"""
        self._url = url
        self._method = "GET"
        if params:
            self._params = params
        return self

    def post(self, url: str, data: Optional[Union[Dict, str]] = None, json_data: Optional[Dict] = None):
        """设置POST请求"""
        self._url = url
        self._method = "POST"
        if data:
            self._data = data
        if json_data:
            self._json_data = json_data
        return self

    def with_header(self, header: Dict[str, str]):
        """添加请求头"""
        self._headers.update(header)
        return self

    def with_cookies(self, cookies: Dict[str, str]):
        """添加Cookie"""
        self._cookies.update(cookies)
        return self

    def with_timeout(self, timeout: int):
        """设置超时时间"""
        self._timeout = timeout
        return self

    def with_params(self, params: Dict[str, Any]):
        """设置查询参数"""
        self._params.update(params)
        return self

    def _prepare_request(self):
        """准备请求参数"""
        kwargs = {
            'headers': self._headers,
            'cookies': self._cookies,
            'timeout': self._timeout
        }

        if self._method == "GET":
            kwargs['params'] = self._params
        elif self._method == "POST":
            if self._json_data:
                kwargs['json'] = self._json_data
            elif self._data:
                kwargs['data'] = self._data

        return kwargs

    def down_stream(self, url: Optional[str] = None):
        """下载流式响应，适用于大文件"""
        target_url = url or self._url
        if not target_url:
            raise ValueError("URL is required")

        kwargs = self._prepare_request()
        kwargs['stream'] = True

        try:
            response = self._session.request(self._method, target_url, **kwargs)
            response.raise_for_status()
            return response
        except requests.RequestException as e:
            raise Exception(f"Request failed: {str(e)}")

    def down_str(self) -> str:
        """获取响应文本"""
        kwargs = self._prepare_request()

        try:
            response = self._session.request(self._method, self._url, **kwargs)
            response.raise_for_status()
            return response.text
        except requests.RequestException as e:
            raise Exception(f"Request failed: {str(e)}")

    def down_file(self, file_path: str, chunk_size: int = 8192):
        """下载文件到本地"""
        response = self.down_stream()

        try:
            with open(file_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=chunk_size):
                    if chunk:
                        f.write(chunk)
            return True
        except Exception as e:
            raise Exception(f"File download failed: {str(e)}")

    def down_json(self) -> Dict[str, Any]:
        """获取JSON响应"""
        kwargs = self._prepare_request()

        try:
            response = self._session.request(self._method, self._url, **kwargs)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            raise Exception(f"Request failed: {str(e)}")

    def close(self):
        """关闭会话"""
        self._session.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()