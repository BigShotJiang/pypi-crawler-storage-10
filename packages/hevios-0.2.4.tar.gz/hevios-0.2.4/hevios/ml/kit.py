from ..utils import SetX
from ..core.osx import Runtime

def imports():
    set = SetX(Runtime.logger)
    set.with_pips(['pandas','matplotlib','seaborn','numpy','sklearn'])