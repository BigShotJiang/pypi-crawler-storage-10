from hevios.core.logger import Logger
from hevios.core.osx import Runtime
from hevios.utils import SetX
class CvX():
    """
    OpenCV扩展库
    """
    def __init__(self, log:Logger= None):
        if log is None:
            self._log = Runtime.logger
        else:
            self._log = log

        set = SetX(self._log)
        set.with_pips(['opencv-python','opencv-contrib-python'])