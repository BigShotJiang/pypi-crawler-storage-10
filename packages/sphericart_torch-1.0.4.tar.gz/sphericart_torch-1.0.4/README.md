# TorchScript bindings to sphericart

This package contains the TorchScript-compatible version of sphericart. See the
[sphericart documentation](https://sphericart.readthedocs.io/en/latest/) for
more information.
