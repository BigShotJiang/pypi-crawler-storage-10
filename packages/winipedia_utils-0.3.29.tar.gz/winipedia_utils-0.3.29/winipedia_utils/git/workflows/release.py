"""Contains the release workflow.

This workflow is used to create a release on GitHub.
"""

from typing import Any

from winipedia_utils.git.workflows.base.base import Workflow


class ReleaseWorkflow(Workflow):
    """Release workflow.

    This workflow is triggered by a push to the main branch.
    It creates a tag for the release and builds a changelog.
    With tag and changelog it creates a release on GitHub
    """

    def get_workflow_triggers(self) -> dict[str, Any]:
        """Get the workflow triggers."""
        return {"push": {"branches": ["main"]}}

    def get_permissions(self) -> dict[str, Any]:
        """Get the workflow permissions."""
        return {
            "contents": "write",
        }

    def get_jobs(self) -> dict[str, Any]:
        """Get the workflow jobs."""
        return self.get_standard_job(
            "release",
            steps=[
                *(
                    self.get_poetry_setup_steps(
                        install_dependencies=True,
                        fetch_depth=0,
                    )
                ),
                self.get_pre_commit_step(),
                *self.get_release_steps(),
            ],
        )
