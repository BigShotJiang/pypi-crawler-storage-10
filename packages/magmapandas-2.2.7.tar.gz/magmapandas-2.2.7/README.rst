.. image:: https://zenodo.org/badge/496640400.svg
  :target: https://zenodo.org/badge/latestdoi/496640400

===========
MagmaPandas
===========

MagmaPandas is a `Pandas <https://pandas.pydata.org/>`_ based tool set for geochemical calculations and modelling.
It makes working with geochemical data easier by extending the Pandas DataFrame
with methods for common calculations, including those for:

   * mole and cation conversion,
   * mineral composition by stoichiometry,
   * melt thermometry,
   * melt Fe speciation,
   * oxygen fugacity,
   * melt volatile (CO\ :sub:`2`\-H\ :sub:`2`\O) saturation pressure
   * mineral-melt element partition coefficients,


MagmaPandas can be combined with `MagmaPEC <https://github.com/TDGerve/MagmaPEC>`_ for post-entrapment crystallisation correction of olivine hosted melt inclusions.

Documentation
-------------
Code documentation and working examples are available at `magmapandas.readthedocs.io <https://magmapandas.readthedocs.io>`_


How to cite MagmaPandas
------------------------------
If you used MagmaPandas in your research, please reference `this <http://dx.doi.org/10.1029/2025GC012420>`_ paper published in Geochemistry, Geophysics, Geosystems. To ensure reproducibility, please also mention the release version of MagmaPandas and reference the specific models you used (see `documentation <https://magmapandas.readthedocs.io/en/latest/code_documentation.html#references>`_).



Installation
------------
MagmaPandas versions 2.0.0 and above can be installed with pip by running:

.. code-block:: bash

    pip install magmapandas

in a terminal.
If you want to install from a specific git branch or release, use:

.. code-block:: bash

    pip install git+https://github.com/TDGerve/MagmaPandas.git@tag

where *tag* should be replaced by the release tag or branch name (e.g. *v2.2.6* or *development*)


