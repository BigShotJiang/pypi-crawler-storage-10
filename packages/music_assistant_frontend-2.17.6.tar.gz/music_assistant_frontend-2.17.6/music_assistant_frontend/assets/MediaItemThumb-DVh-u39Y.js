import{cb as o}from"./index-BnMCR6my.js";import{_ as a}from"./_plugin-vue_export-helper-DlAUqK2U.js";const t=a(o,[["__scopeId","data-v-565bc716"]]);export{t as M};
