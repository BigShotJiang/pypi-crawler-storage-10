/* empty css              */import{cO as r}from"./index-BnMCR6my.js";const e=r("v-spacer","div","VSpacer");export{e as V};
