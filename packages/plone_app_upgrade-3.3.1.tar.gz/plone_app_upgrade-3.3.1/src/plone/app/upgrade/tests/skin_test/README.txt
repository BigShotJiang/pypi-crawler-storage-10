Recursive skin
