Overview
========

This package contains the upgrade machinery to upgrade a Plone site to a newer version.

Version compatibility
---------------------

- To update to Plone 4.x please use plone.app.upgrade versions up to 1.3.x.
- To update to Plone 5.x, use plone.app.upgrade version 2.x.
- To update to Plone 6.x, use plone.app.upgrade version 3.x.
