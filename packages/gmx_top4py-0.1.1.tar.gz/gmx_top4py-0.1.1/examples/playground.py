# %%
from pathlib import Path
from copy import deepcopy
import random
# %%
from kimmdy.topology.topology import Topology as KimmdyTopology
from kimmdy.parsing import read_top as kimmdy_read_top

from grappa import Grappa
from grappa.utils.kimmdy_utils import GrappaParameterizer

from gmx_top4py.topology.topology import Topology
from gmx_top4py.parsing import read_top, write_top
from gmx_top4py.parameterizing import Parameterizer
from gmx_top4py.topology.atomic import Dihedral
from gmx_top4py.topology.utils import get_residue_by_bonding
# %%
top_path = "urea-times-2.top"

top = read_top(Path(top_path))
topology = Topology(top) # Alternatively: topology = Topology.from_path(Path(top_path))
# topology.to_path("urea-times-2_ada.top")

top = kimmdy_read_top(Path(top_path))  # , ffdir=Path("../tests/test_files/assets/amber99sb-star-ildnp.ff")
ktopology = KimmdyTopology(top)

# ktopology.to_path("urea-times-2_kim.top")
# %%
top_dict = read_top(Path("urea-times-2.top"))
out_path = Path("pytest_urea.top")
write_top(top_dict, out_path)


# %%
print("KimmdyTopology moleculetypes:")
print(ktopology.moleculetypes)
print("Topology moleculetypes:")
print(topology.moleculetypes)
# %%
print("KimmdyTopology atoms:")
print(ktopology.atoms)
# print(topology.atoms) # Won't work as atoms of selected MoleculteType are not linked to top
print(topology.moleculetypes["Urea"].atoms)
# assert ktopology.atoms == topology.moleculetypes["Urea"].atoms
# %%
topology.parametrizer = GrappaParameterizer(grappa_instance=grappa)
# topology.update_parameters()

topology.needs_parameterization =True
write_top(topology.to_dict(), "urea_grappa.top")

# %%
######################## Examples #############################
hexala_top_dict = read_top(Path("hexala.top"), ffdir=Path("../tests/test_files/assets/amber99sb-star-ildnp.ff"))
original_top = Topology(hexala_top_dict)
a = original_top.atoms["1"]
res = get_residue_by_bonding(a, original_top.atoms)
res

# %%
