# %%
from pathlib import Path
from copy import deepcopy
import importlib

if not importlib.util.find_spec("grappa"):
    raise ModuleNotFoundError("Grappa not found. Please install grappa to run this example. You can install grappa from pypi via pip: pip install grappa-ff or via uv pip: uv pip install grappa-ff")
from grappa import Grappa
from grappa.utils.kimmdy_utils import GrappaParameterizer

from gmx_top4py.topology.topology import Topology
from gmx_top4py.parsing import read_top, write_top


# %%
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! CURRENTLY NOT WORKING !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# Example: Parameterize a topology with GRAPPA

# Read topology file and instantiate Topology object
top_dict = read_top(Path("hexala.top"), ffdir=Path("amber99sb-star-ildnp.ff"))
original_top = Topology(top_dict)



# Load GRAPPA model and instantiate parameterizer
grappa_model = Grappa.from_tag("grappa-1.4.1-light")
grappa_parameterizer = GrappaParameterizer(grappa_instance=grappa_model)

# Parameterize with GRAPPA
top_grappa = deepcopy(original_top)
top_grappa.parametrizer = grappa_parameterizer
top_grappa.needs_parameterization = True
# Write out the parameterized topology
write_top(top_grappa.to_dict(), "hexala_grappa.top")