"""
Differential Geometry Module for Coordinate System Package

This module provides tools for discrete differential geometry computations on surfaces,
using the Intrinsic Gradient Operator framework.

Key Concepts:
- Intrinsic Gradient Operator: G_μ = (c(u+h) - c(u))/h
- Unified computation of curvature via intrinsic gradient operators
- Separation of intrinsic and embedding frames

Performance Note:
    The coord3 class includes optimized implementations for:
    - compute_metric_det(): Fast metric tensor determinant computation
    - connection_operator(): Optimized connection operator calculation
    - lie_bracket(): Fast Lie bracket computation

Author: PanGuoJun
Version: 3.0.0
Date: 2025-10-30
"""

import numpy as np
from typing import Tuple, Optional, Callable
from .coordinate_system import coord3, vec3

# Define constants locally to avoid circular import
def _coord3_scalar_mul(c: coord3, scalar: float) -> coord3:
    """
    Multiply coord3 by a scalar (workaround for C++ binding limitation)
    """
    scaled_s = vec3(c.s.x * scalar, c.s.y * scalar, c.s.z * scalar)
    return coord3(c.o, scaled_s, c.ux, c.uy, c.uz)

ZERO3 = vec3(0.0, 0.0, 0.0)
UNITX = vec3(1.0, 0.0, 0.0)
UNITY = vec3(0.0, 1.0, 0.0)
UNITZ = vec3(0.0, 0.0, 1.0)
ONE3 = vec3(1.0, 1.0, 1.0)
ONEC = coord3(ZERO3, UNITX, UNITY, UNITZ)


# ========== Intrinsic Gradient Operator Framework ==========

class IntrinsicGradientOperator:
    """
    Intrinsic Gradient Operator: G_μ = (c(u+h) - c(u))/h
    
    This is the core operator for all geometric computations in our framework.
    It captures the intrinsic geometric changes of the surface.
    """

    def __init__(self, surface: 'Surface', step_size: float = 1e-4):
        """
        Initialize intrinsic gradient operator

        Args:
            surface: Surface object
            step_size: Finite difference step size
        """
        self.surface = surface
        self.h = step_size

    def compute_intrinsic_frame(self, u: float, v: float) -> coord3:
        """
        Compute intrinsic frame c(u,v) - orthonormalized local coordinate system
        
        The intrinsic frame represents the pure geometric structure without
        embedding information.
        """
        # Compute tangent vectors
        r_u = self.surface.tangent_u(u, v)
        r_v = self.surface.tangent_v(u, v)

        # Gram-Schmidt orthogonalization for intrinsic frame
        e1 = r_u.normcopy()  # First basis vector: normalized r_u

        # Second basis vector: projection of r_v onto orthogonal complement of e1
        r_v_orth = r_v - e1 * r_v.dot(e1)
        e2 = r_v_orth.normcopy()

        # Third basis vector: normal vector
        n = e1.cross(e2).normcopy()

        return coord3(e1, e2, n)

    def compute_embedding_frame(self, u: float, v: float) -> coord3:
        """
        Compute embedding frame C(u,v) - preserves metric information
        
        The embedding frame contains information about how the surface
        is embedded in the ambient space.
        """
        # Compute tangent vectors
        r_u = self.surface.tangent_u(u, v)
        r_v = self.surface.tangent_v(u, v)

        # Gram-Schmidt orthogonalization preserving metric information
        e1 = r_u.normcopy()
        e1_length = (r_u.x**2 + r_u.y**2 + r_u.z**2) ** 0.5

        # Projection of r_v onto orthogonal complement of e1
        proj = r_v.dot(e1)
        r_v_orth = r_v - e1 * proj
        e2 = r_v_orth.normcopy()
        e2_length = (r_v_orth.x**2 + r_v_orth.y**2 + r_v_orth.z**2) ** 0.5

        # Normal vector
        n = e1.cross(e2).normcopy()

        # Create embedding frame with metric information
        origin = self.surface.position(u, v)
        scale = vec3(e1_length, e2_length, 1.0)

        return coord3(origin, scale, e1, e2, n)

    def compute(self, u: float, v: float, direction: str = 'u') -> coord3:
        """
        Compute intrinsic gradient operator G_μ
        
        Core formula: G_μ = (c(u+h) - c(u))/h
        
        This operator captures the intrinsic geometric derivative.
        """
        # Compute frames at current point
        c_center = self.compute_intrinsic_frame(u, v)
        C_center = self.compute_embedding_frame(u, v)

        # Compute frames at shifted point
        if direction == 'u':
            c_shifted = self.compute_intrinsic_frame(u + self.h, v)
            C_shifted = self.compute_embedding_frame(u + self.h, v)
        elif direction == 'v':
            c_shifted = self.compute_intrinsic_frame(u, v + self.h)
            C_shifted = self.compute_embedding_frame(u, v + self.h)
        else:
            raise ValueError(f"direction must be 'u' or 'v', got: {direction}")

        # Compute intrinsic gradient operator using our unified formula
        # G = (c_shifted/c_center)/C_shifted - I/C_center
        G_prime = (c_shifted / c_center) / C_shifted - ONEC / C_center

        # Apply finite difference scaling
        if abs(self.h) > 1e-14:
            h_inv = 1.0 / self.h
            scaled_s = vec3(G_prime.s.x * h_inv, G_prime.s.y * h_inv, G_prime.s.z * h_inv)
            G_raw = coord3(G_prime.o, scaled_s, G_prime.ux, G_prime.uy, G_prime.uz)
        else:
            G_raw = G_prime

        # Apply metric correction to eliminate parametrization dependence
        metric = MetricTensor.from_coord3(C_center)
        correction = metric.correction_factor()
        
        corrected_s = vec3(G_raw.s.x * correction, G_raw.s.y * correction, G_raw.s.z * correction)
        G = coord3(G_raw.o, corrected_s, G_raw.ux, G_raw.uy, G_raw.uz)

        return G

    def compute_both(self, u: float, v: float) -> Tuple[coord3, coord3]:
        """
        Compute both directional intrinsic gradient operators
        """
        G_u = self.compute(u, v, 'u')
        G_v = self.compute(u, v, 'v')
        return G_u, G_v


# ========== Surface Base Class ==========

class Surface:
    """
    Base class for parametric surfaces r(u, v)
    """

    def __init__(self, h: float = 1e-6):
        self.h = h

    def position(self, u: float, v: float) -> vec3:
        raise NotImplementedError("Subclass must implement position(u, v)")

    def tangent_u(self, u: float, v: float) -> vec3:
        r_plus = self.position(u + self.h, v)
        r_minus = self.position(u - self.h, v)
        return (r_plus - r_minus) * (1.0 / (2.0 * self.h))

    def tangent_v(self, u: float, v: float) -> vec3:
        r_plus = self.position(u, v + self.h)
        r_minus = self.position(u, v - self.h)
        return (r_plus - r_minus) * (1.0 / (2.0 * self.h))

    def normal(self, u: float, v: float) -> vec3:
        r_u = self.tangent_u(u, v)
        r_v = self.tangent_v(u, v)
        n = r_u.cross(r_v)
        length = (n.x**2 + n.y**2 + n.z**2) ** 0.5
        if length > 1e-10:
            return n * (1.0 / length)
        else:
            return UNITZ


# ========== Common Surface Types ==========

class Sphere(Surface):
    def __init__(self, radius: float = 1.0, h: float = 1e-6):
        super().__init__(h)
        self.R = radius

    def position(self, u: float, v: float) -> vec3:
        import math
        x = self.R * math.sin(u) * math.cos(v)
        y = self.R * math.sin(u) * math.sin(v)
        z = self.R * math.cos(u)
        return vec3(x, y, z)


class Torus(Surface):
    def __init__(self, major_radius: float = 3.0, minor_radius: float = 1.0, h: float = 1e-6):
        super().__init__(h)
        self.R = major_radius
        self.r = minor_radius

    def position(self, u: float, v: float) -> vec3:
        import math
        x = (self.R + self.r * math.cos(u)) * math.cos(v)
        y = (self.R + self.r * math.cos(u)) * math.sin(v)
        z = self.r * math.sin(u)
        return vec3(x, y, z)


# ========== Metric Tensor ==========

class MetricTensor:
    """
    First fundamental form (metric tensor) of a surface
    """

    def __init__(self, E: float, F: float, G: float):
        self.E = E
        self.F = F
        self.G = G
        self.det = E * G - F * F

    @classmethod
    def from_coord3(cls, C: coord3) -> 'MetricTensor':
        VX = C.VX()
        VY = C.VY()
        E = VX.dot(VX)
        F = VX.dot(VY)
        G = VY.dot(VY)
        return cls(E, F, G)

    @classmethod
    def from_surface(cls, surface: Surface, u: float, v: float) -> 'MetricTensor':
        r_u = surface.tangent_u(u, v)
        r_v = surface.tangent_v(u, v)
        E = r_u.dot(r_u)
        F = r_u.dot(r_v)
        G = r_v.dot(r_v)
        return cls(E, F, G)

    def determinant(self) -> float:
        return self.det

    def correction_factor(self) -> float:
        if self.det > 1e-10:
            return 1.0 / (self.det ** 0.5)
        else:
            return 1.0

    def is_orthogonal(self, tol: float = 1e-6) -> bool:
        return abs(self.F) < tol

    def __repr__(self) -> str:
        return f"MetricTensor(E={self.E:.6f}, F={self.F:.6f}, G={self.G:.6f}, det={self.det:.6f})"


# ========== Unified Curvature Computation ==========

class IntrinsicGradientCurvatureCalculator:
    """
    Unified curvature calculator using intrinsic gradient operators
    
    This class replaces the old ConnectionOperator and provides a unified
    framework for all curvature computations using intrinsic gradient operators.
    """

    def __init__(self, surface: Surface, step_size: float = 1e-4):
        self.surface = surface
        self.h = step_size
        self.intrinsic_grad = IntrinsicGradientOperator(surface, step_size)

    def compute_second_fundamental_form(self, u: float, v: float) -> Tuple[float, float, float]:
        """
        Compute second fundamental form using intrinsic gradient operators
        
        Formulas:
        L = -∂n/∂u · r_u = -G_u.uz · r_u
        M = -1/2(∂n/∂u · r_v + ∂n/∂v · r_u)  
        N = -∂n/∂v · r_v = -G_v.uz · r_v
        """
        # Compute intrinsic gradient operators
        G_u, G_v = self.intrinsic_grad.compute_both(u, v)

        # Compute tangent vectors
        r_u = self.surface.tangent_u(u, v)
        r_v = self.surface.tangent_v(u, v)

        # Extract normal derivatives from intrinsic gradient operators
        dn_du = vec3(G_u.uz.x, G_u.uz.y, G_u.uz.z)
        dn_dv = vec3(G_v.uz.x, G_v.uz.y, G_v.uz.z)

        # Compute second fundamental form coefficients
        L = -dn_du.dot(r_u)
        M1 = -dn_du.dot(r_v)
        M2 = -dn_dv.dot(r_u)
        M = (M1 + M2) / 2.0
        N = -dn_dv.dot(r_v)

        return L, M, N

    def compute_gaussian_curvature_via_second_form(self, u: float, v: float) -> float:
        """
        Compute Gaussian curvature using second fundamental form
        
        Formula: K = (LN - M²) / det(g)
        """
        # Compute embedding frame and metric
        C = self.intrinsic_grad.compute_embedding_frame(u, v)
        metric = MetricTensor.from_coord3(C)

        # Compute second fundamental form
        L, M, N = self.compute_second_fundamental_form(u, v)

        # Gaussian curvature
        if abs(metric.det) > 1e-14:
            K = (L * N - M * M) / metric.det
        else:
            K = 0.0

        return K

    def compute_gaussian_curvature_via_curvature_tensor(self, u: float, v: float) -> float:
        """
        Compute Gaussian curvature using curvature tensor
        
        Formula: K = R_12_antisym / det(g)
        """
        # Compute curvature tensor using intrinsic gradient operators
        R_uv = self.compute_curvature_tensor(u, v)

        # Compute metric
        metric = MetricTensor.from_coord3(self.intrinsic_grad.compute_embedding_frame(u, v))

        # Extract antisymmetric part of curvature tensor
        R_01 = R_uv.ux.y
        R_10 = R_uv.uy.x
        R_12_antisym = (R_01 - R_10) / 2.0

        # Gaussian curvature
        if abs(metric.det) > 1e-10:
            K = R_12_antisym / metric.det
        else:
            K = 0.0

        return K

    def compute_curvature_tensor(self, u: float, v: float) -> coord3:
        """
        Compute curvature tensor using intrinsic gradient operators
        
        Formula: R_uv = [G_u, G_v] - G_{[u,v]}
        where [G_u, G_v] is the Lie bracket and G_{[u,v]} is the Lie derivative
        """
        # Compute intrinsic gradient operators
        G_u, G_v = self.intrinsic_grad.compute_both(u, v)

        # Lie bracket: [G_u, G_v] = G_u @ G_v - G_v @ G_u
        commutator = G_u * G_v - G_v * G_u

        # Lie derivative term: G_{[u,v]} = ∂G_v/∂u - ∂G_u/∂v
        # Compute using finite differences of intrinsic gradient operators
        G_v_plus_u = self.intrinsic_grad.compute(u + self.h, v, 'v')
        G_v_minus_u = self.intrinsic_grad.compute(u - self.h, v, 'v')
        dGv_du = _coord3_scalar_mul(G_v_plus_u - G_v_minus_u, 1.0 / (2.0 * self.h))

        G_u_plus_v = self.intrinsic_grad.compute(u, v + self.h, 'u')
        G_u_minus_v = self.intrinsic_grad.compute(u, v - self.h, 'u')
        dGu_dv = _coord3_scalar_mul(G_u_plus_v - G_u_minus_v, 1.0 / (2.0 * self.h))

        lie_derivative = dGv_du - dGu_dv

        # Curvature tensor
        R_uv = commutator - lie_derivative

        return R_uv

    def compute_mean_curvature(self, u: float, v: float) -> float:
        """
        Compute mean curvature using second fundamental form
        
        Formula: H = (EN - 2FM + GL) / (2·det(g))
        """
        # Compute embedding frame and metric
        C = self.intrinsic_grad.compute_embedding_frame(u, v)
        metric = MetricTensor.from_coord3(C)

        # Compute second fundamental form
        L, M, N = self.compute_second_fundamental_form(u, v)

        # Mean curvature
        if abs(metric.det) > 1e-14:
            H = (metric.G * L - 2 * metric.F * M + metric.E * N) / (2 * metric.det)
        else:
            H = 0.0

        return H

    def compute_all_curvatures(self, u: float, v: float) -> dict:
        """
        Compute all curvature quantities using unified intrinsic gradient framework
        """
        # Compute using both methods for verification
        K_via_second_form = self.compute_gaussian_curvature_via_second_form(u, v)
        K_via_tensor = self.compute_gaussian_curvature_via_curvature_tensor(u, v)
        H = self.compute_mean_curvature(u, v)
        
        # Principal curvatures
        discriminant = max(0, H * H - K_via_second_form)
        sqrt_disc = discriminant ** 0.5
        k1 = H + sqrt_disc
        k2 = H - sqrt_disc

        # Second fundamental form
        L, M, N = self.compute_second_fundamental_form(u, v)

        # Metric
        metric = MetricTensor.from_coord3(self.intrinsic_grad.compute_embedding_frame(u, v))

        return {
            'gaussian_curvature_second_form': K_via_second_form,
            'gaussian_curvature_tensor': K_via_tensor,
            'mean_curvature': H,
            'principal_curvatures': (k1, k2),
            'second_fundamental_form': (L, M, N),
            'metric_tensor': metric,
            'curvature_tensor': self.compute_curvature_tensor(u, v)
        }


# ========== Simplified Interface Functions ==========

def compute_intrinsic_gradient(
    surface: Surface,
    u: float,
    v: float,
    direction: str = 'u',
    step_size: float = 1e-4
) -> coord3:
    """
    Compute intrinsic gradient operator (simplified interface)
    """
    intrinsic_grad = IntrinsicGradientOperator(surface, step_size)
    return intrinsic_grad.compute(u, v, direction)

def compute_gaussian_curvature(
    surface: Surface,
    u: float,
    v: float,
    method: str = 'tensor',
    step_size: float = 1e-4
) -> float:
    """
    Compute Gaussian curvature using intrinsic gradient operators
    """
    calculator = IntrinsicGradientCurvatureCalculator(surface, step_size)
    
    if method == 'second_form':
        return calculator.compute_gaussian_curvature_via_second_form(u, v)
    else:  # 'tensor' method (default)
        return calculator.compute_gaussian_curvature_via_curvature_tensor(u, v)

def compute_curvature_tensor(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-4
) -> coord3:
    """
    Compute curvature tensor using intrinsic gradient operators
    """
    calculator = IntrinsicGradientCurvatureCalculator(surface, step_size)
    return calculator.compute_curvature_tensor(u, v)

def compute_all_curvatures(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-4
) -> dict:
    """
    Compute all curvature quantities using intrinsic gradient framework
    """
    calculator = IntrinsicGradientCurvatureCalculator(surface, step_size)
    return calculator.compute_all_curvatures(u, v)


# ========== Export ==========

__all__ = [
    # Core classes
    'Surface',
    'Sphere', 
    'Torus',
    'MetricTensor',
    'IntrinsicGradientOperator',
    'IntrinsicGradientCurvatureCalculator',
    
    # Simplified interfaces
    'compute_intrinsic_gradient',
    'compute_gaussian_curvature', 
    'compute_curvature_tensor',
    'compute_all_curvatures',
]