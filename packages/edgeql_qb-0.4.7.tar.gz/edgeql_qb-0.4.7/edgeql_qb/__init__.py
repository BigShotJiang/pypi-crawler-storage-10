from edgeql_qb.queries import EdgeDBModel

__all__ = ['EdgeDBModel']
