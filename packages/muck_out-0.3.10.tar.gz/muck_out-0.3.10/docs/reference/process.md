:::muck_out.process
