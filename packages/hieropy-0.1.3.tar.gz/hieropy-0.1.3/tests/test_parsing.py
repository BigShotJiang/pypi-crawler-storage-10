import unittest

from hieropy import UniParser
from hieropy import copy_group
from hieropy.unitransform import chars_from
from hieropy.options import Options

@unittest.skip("Temporarily skipping this test class")
class TestParsing(unittest.TestCase):
	def test_one(self):
		return
		myparser = UniParser()
		parsed = myparser.parse('\U00013000\U00013430\U00013001')
		parsed_str = str(parsed)
		parsed_list = list(parsed_str)
		self.assertEqual(parsed_list, [chr(0x13000), chr(0x13430), chr(0x13001)])
		parsed_repr = repr(parsed)
		self.assertEqual(parsed_repr, 'A1:A2')

	def test_file(self):
		myparser = UniParser()
		with open('tests/data/testsuite.txt', 'r') as f:
			lines = f.readlines()
		for line in lines:
			line = line.strip()
			parsed = myparser.parse(line)
			line_parsed = str(parsed)
			self.assertEqual(line, line_parsed)

	def test_copying(self):
		myparser = UniParser()
		with open('tests/data/testsuite.txt', 'r') as f:
			lines = f.readlines()
		for line in lines:
			line = line.strip()
			parsed = myparser.parse(line)
			chars = chars_from(parsed)
			copy = copy_group(parsed)
			line_parsed = str(parsed)
			self.assertEqual(line, line_parsed)

	def test_format(self):
		myparser = UniParser()
		options_pdf = Options(imagetype='pdf')
		options_svg = Options(imagetype='svg')
		options_pil = Options(imagetype='pdf')
		with open('tests/data/testsuite.txt', 'r') as f:
			lines = f.readlines()
		for line in lines:
			line = line.strip()
			parsed = myparser.parse(line)
			parsed.print(options_pdf)
			parsed.print(options_svg)
			parsed.print(options_pil)

	def test_bracket(self):
		myparser = UniParser()
		parsed = myparser.parse('\U00013258')
		parsed_repr = repr(parsed)
		self.assertEqual(parsed_repr, 'O6a')

	def test_error1(self):
		myparser = UniParser()
		parsed = myparser.parse('\U00013000\U00013430')
		self.assertEqual(myparser.last_error, 'Unexpected end of input')

	def test_error2(self):
		myparser = UniParser()
		parsed = myparser.parse('\U00013430\U00013000\U00013430')
		self.assertEqual(myparser.last_error, 'Syntax error at position 0')

if __name__ == '__main__':
	unittest.main()
