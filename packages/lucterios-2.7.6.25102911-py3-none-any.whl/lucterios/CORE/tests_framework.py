# -*- coding: utf-8 -*-
'''
Unit test class for Lucterios framework

@author: Laurent GAY
@organization: sd-libre.fr
@contact: info@sd-libre.fr
@copyright: 2015 sd-libre.fr
@license: This file is part of Lucterios.

Lucterios is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Lucterios is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Lucterios.  If not, see <http://www.gnu.org/licenses/>.
'''

from __future__ import unicode_literals

from lucterios.framework.test import LucteriosTest
from lucterios.framework.xfergraphic import XFER_DBOX_WARNING, XferContainerCustom
from lucterios.framework.tools import WrapAction

from lucterios.CORE.models import Parameter, LucteriosGroup
from lucterios.CORE.parameters import Params
from lucterios.CORE.views import ParamSave


class GenericTest(LucteriosTest):

    def __init__(self, methodName):
        LucteriosTest.__init__(self, methodName)
        self.xfer = None

    def setUp(self):
        self.xfer_class.url_text = "customer/details"
        self.xfer_class.is_view_right = ''
        self.xfer_class.short_icon = 'mdi:mdi-circle-small'
        LucteriosTest.setUp(self)
        self.value = False
        self.xfer = XferContainerCustom()
        Params.clear()

    def callparam(self):
        self.factory.xfer = self.xfer
        self.calljson("/", {}, False)

    def test_help(self):
        response = self.client.get('/Docs', {})
        self.assertEqual(response.status_code, 200, "HTTP error:" + str(response.status_code))
        help_content = str(response.content.decode('utf-8'))
        self.assertGreaterEqual(help_content.find('<html>'), 17, help_content)
        self.assertLessEqual(help_content.find('<html>'), 21, help_content)

    def test_help_json(self):
        self.calljson('/Docs', {'json': ''}, 'GET')
        self.assertEqual(len(self.response_json), 6)
        self.assertEqual(self.response_json['title'], 'Lucterios standard')
        self.assertEqual(self.response_json['subtitle'], 'Application générique de gestion')
        self.assertEqual(self.response_json['applogo'][:21], 'data:image/png;base64')
        self.assertEqual(self.response_json['version'][:4], '2.7.')
        self.assertEqual(self.response_json['lang'], 'fr')
        self.assertEqual(self.response_json['menus'], [['lucterios.standard', 'Lucterios standard'], ['lucterios.dummy', 'My Dummy'], ['lucterios.CORE', 'Cœur Lucterios']])

    def test_simple(self):
        self.calljson('/customer/details', {'id': 12, 'value': 'abc'}, False)
        self.assert_observer('core.acknowledge', 'customer', 'details')
        self.assertEqual(len(self.json_context), 2)
        self.assertEqual(self.json_context['id'], '12')
        self.assertEqual(self.json_context['value'], 'abc')
        self.assertEqual(self.response_json['close'], None)

    def test_close(self):
        def fillresponse_close():
            self.factory.xfer.set_close_action(
                WrapAction("close", 'mdi:mdi-circle-small', "customer", "list"))
        self.factory.xfer.fillresponse = fillresponse_close
        self.calljson('/customer/details', {}, False)
        self.assert_observer('core.acknowledge', 'customer', 'details')
        self.assertEqual(len(self.json_context), 0)
        self.assertEqual(len(self.json_actions), 0)
        self.assertTrue('close' in self.response_json.keys())
        self.assert_action_equal('POST', self.response_json['close'], ("close", None, "customer", "list", 1, 1, 1))

    def test_redirect(self):
        def fillresponse_redirect():
            self.factory.xfer.redirect_action(WrapAction("redirect", 'mdi:mdi-circle-small', "customer", "list"))
        self.factory.xfer.fillresponse = fillresponse_redirect
        self.calljson('/customer/details', {}, False)
        self.assert_observer('core.acknowledge', 'customer', 'details')
        self.assertEqual(len(self.json_context), 0)
        self.assertEqual(len(self.json_actions), 0)
        self.assertTrue('action' in self.response_json.keys())
        self.assert_action_equal('POST', self.response_json['action'], ("redirect", None, "customer", "list", 1, 1, 1))

    def test_confirme(self):
        self.value = False

        def fillresponse_confirme():
            if self.factory.xfer.confirme("Do you want?"):
                self.value = True
        self.factory.xfer.fillresponse = fillresponse_confirme
        self.calljson('/customer/details', {}, False)
        self.assertEqual(self.value, False)
        self.assert_observer('core.dialogbox', 'customer', 'details')
        self.assert_json_equal('', 'type', '2')
        self.assert_json_equal('', 'text', 'Do you want?')
        self.assertEqual(len(self.json_actions), 2)
        self.assert_action_equal('POST', self.json_actions[0], ('Oui', 'mdi:mdi-check', 'customer', 'details', 1, 1, 1, {'CONFIRME': "YES"}))
        self.assert_action_equal('POST', self.json_actions[1], ('Non', 'mdi:mdi-cancel'))

        self.calljson('/customer/details', {'CONFIRME': 'YES'}, False)
        self.assertEqual(self.value, True)
        self.assertEqual(self.json_meta['observer'], 'core.acknowledge')

    def test_message(self):
        def fillresponse_message():
            self.factory.xfer.message("Finished!", XFER_DBOX_WARNING)
        self.factory.xfer.fillresponse = fillresponse_message
        self.calljson('/customer/details', {}, False)
        self.assert_observer('core.dialogbox', 'customer', 'details')
        self.assert_json_equal('', 'type', '3')
        self.assert_json_equal('', 'text', 'Finished!')
        self.assertEqual(len(self.json_actions), 1)
        self.assert_action_equal('POST', self.json_actions[0], ('Ok', 'mdi:mdi-check'))

    def test_traitment(self):
        self.value = False

        def fillresponse_traitment():
            if self.factory.xfer.traitment("mdi:mdi-timer-sand", "Traitment{[br/]}Wait...", "Done"):
                self.value = True
        self.factory.xfer.fillresponse = fillresponse_traitment
        self.calljson('/customer/details', {}, False)
        self.assertEqual(self.value, False)
        self.assert_observer('core.custom', 'customer', 'details')
        self.assertEqual(len(self.json_context), 1)
        self.assertEqual(self.json_context['RELOAD'], 'YES')
        self.assert_count_equal('', 3)
        self.assert_json_equal('LABELFORM', "info", '{[br/]}Traitment{[br/]}Wait...')
        self.assert_json_equal('IMAGE', "img_title", 'mdi:mdi-timer-sand')
        self.assert_action_equal('POST', self.json_comp['Next']['action'], ('Traitement...', None, 'customer', 'details', 1, 1, 1, {'RELOAD': "YES"}))
        self.assert_attrib_equal('Next', 'javascript', 'parent.refresh()')
        self.assertEqual(len(self.json_actions), 1)
        self.assert_action_equal('POST', self.json_actions[0], ('Annuler', 'mdi:mdi-cancel'))

        self.calljson('/customer/details', {'RELOAD': 'YES'}, False)
        self.assertEqual(self.value, True)
        self.assert_observer('core.custom', 'customer', 'details')
        self.assertEqual(len(self.json_context), 1)
        self.assertEqual(self.json_context['RELOAD'], 'YES')
        self.assert_count_equal('', 2)
        self.assert_json_equal('IMAGE', "img_title", 'mdi:mdi-timer-sand')
        self.assert_json_equal('LABELFORM', "info", 'Done')
        self.assert_action_equal('POST', self.json_actions[0], ('Fermer', 'mdi:mdi-close'))

    def test_parameters_text(self):
        param = Parameter.objects.create(name='param_text', typeparam=0)
        param.args = "{'Multi':False}"
        param.value = 'my value'
        param.save()

        Params.fill(self.xfer, ['param_text'], 1, 1, True)
        self.callparam()
        self.assert_count_equal('', 1)
        self.assert_json_equal('LABELFORM', "param_text", 'my value')

        Params.fill(self.xfer, ['param_text'], 1, 1, False)
        self.callparam()
        self.assert_count_equal('', 1)
        self.assert_json_equal('EDIT', "param_text", 'my value')

        self.factory.xfer = ParamSave()
        self.calljson('/CORE/paramSave', {'params': 'param_text', 'param_text': 'new value'}, False)
        self.assert_observer('core.acknowledge', 'CORE', 'paramSave')
        self.assertEqual(Params.getvalue('param_text'), 'new value')

    def test_parameters_memo(self):
        param = Parameter.objects.create(name='param_memo', typeparam=0)
        param.args = "{'Multi':True}"
        param.value = 'other value'
        param.save()

        Params.fill(self.xfer, ['param_memo'], 1, 1, True)
        self.callparam()
        self.assert_count_equal('', 1)
        self.assert_json_equal('LABELFORM', "param_memo", 'other value')

        Params.fill(self.xfer, ['param_memo'], 1, 1, False)
        self.callparam()
        self.assert_count_equal('', 1)
        self.assert_json_equal('MEMO', "param_memo", 'other value')

        self.factory.xfer = ParamSave()
        self.calljson('/CORE/paramSave', {'params': 'param_memo', 'param_memo': 'new special value'}, False)
        self.assert_observer('core.acknowledge', 'CORE', 'paramSave')
        self.assertEqual(Params.getvalue('param_memo'), 'new special value')

    def test_parameters_int(self):
        param = Parameter.objects.create(name='param_int', typeparam=1)
        param.args = "{'Min':5, 'Max':25}"
        param.value = '5'
        param.save()

        Params.fill(self.xfer, ['param_int'], 1, 1, True)
        self.callparam()
        self.assert_count_equal('', 1)
        self.assert_json_equal('LABELFORM', "param_int", '5')

        Params.fill(self.xfer, ['param_int'], 1, 1, False)
        self.callparam()
        self.assert_count_equal('', 1)
        self.assert_json_equal('FLOAT', "param_int", '5')
        self.assert_attrib_equal("param_int", 'min', '5.0')
        self.assert_attrib_equal("param_int", 'max', '25.0')
        self.assert_attrib_equal("param_int", 'prec', '0')

        self.factory.xfer = ParamSave()
        self.calljson('/CORE/paramSave', {'params': 'param_int', 'param_int': '13'}, False)
        self.assert_observer('core.acknowledge', 'CORE', 'paramSave')
        self.assertEqual(Params.getvalue('param_int'), 13)

    def test_parameters_float(self):
        param = Parameter.objects.create(name='param_float', typeparam=2)
        param.args = "{'Min':20, 'Max':30, 'Prec':2}"
        param.value = '22.25'
        param.save()

        Params.fill(self.xfer, ['param_float'], 1, 1, True)
        self.callparam()
        self.assert_count_equal('', 1)
        self.assert_json_equal('LABELFORM', "param_float", '22.25')

        Params.fill(self.xfer, ['param_float'], 1, 1, False)
        self.callparam()
        self.assert_count_equal('', 1)
        self.assert_json_equal('FLOAT', "param_float", '22.25')
        self.assert_attrib_equal("param_float", 'min', '20.0')
        self.assert_attrib_equal("param_float", 'max', '30.0')
        self.assert_attrib_equal("param_float", 'prec', '2')

        self.factory.xfer = ParamSave()
        self.calljson('/CORE/paramSave', {'params': 'param_float', 'param_float': '26.87'}, False)
        self.assert_observer('core.acknowledge', 'CORE', 'paramSave')
        self.assertEqual(Params.getvalue('param_float'), 26.87)

    def test_parameters_bool(self):
        param = Parameter.objects.create(name='param_bool', typeparam=3)
        param.args = "{}"
        param.value = 'False'
        param.save()

        Params.fill(self.xfer, ['param_bool'], 1, 1, True)
        self.callparam()
        self.assert_count_equal('', 1)
        self.assert_json_equal('LABELFORM', "param_bool", 'Non')

        Params.fill(self.xfer, ['param_bool'], 1, 1, False)
        self.callparam()
        self.assert_count_equal('', 1)
        self.assert_json_equal('CHECK', "param_bool", '0')

        self.factory.xfer = ParamSave()
        self.calljson('/CORE/paramSave', {'params': 'param_bool', 'param_bool': '1'}, False)
        self.assert_observer('core.acknowledge', 'CORE', 'paramSave')
        self.assertEqual(Params.getvalue('param_bool'), True)

    def test_parameters_select(self):
        param = Parameter.objects.create(name='param_select', typeparam=4)
        param.args = "{'Enum':4}"
        param.value = '2'
        param.save()

        Params.fill(self.xfer, ['param_select'], 1, 1, True)
        self.callparam()
        self.assert_count_equal('', 1)
        self.assert_json_equal('LABELFORM', "param_select", 'param_select.2')

        Params.fill(self.xfer, ['param_select'], 1, 1, False)
        self.callparam()
        self.assert_count_equal('', 1)
        self.assert_json_equal('SELECT', "param_select", '2')
        self.assert_select_equal("param_select", {0: 'param_select.0', 1: 'param_select.1', 2: 'param_select.2', 3: 'param_select.3'})

        self.factory.xfer = ParamSave()
        self.calljson('/CORE/paramSave', {'params': 'param_select', 'param_select': '1'}, False)
        self.assert_observer('core.acknowledge', 'CORE', 'paramSave')
        self.assertEqual(Params.getvalue('param_select'), 1)

    def test_parameters_meta(self):
        LucteriosGroup.objects.create(name='group #1')
        grp2 = LucteriosGroup.objects.create(name='group #2')

        param = Parameter.objects.create(name='param_meta', typeparam=1)
        param.args = ""
        param.value = '0'
        param.metaselect = '("CORE","LucteriosGroup","django.db.models.Q()", "id", False)'
        param.save()

        Params.fill(self.xfer, ['param_meta'], 1, 1, True)
        self.callparam()
        self.assert_count_equal('', 1)
        self.assert_json_equal('LABELFORM', "param_meta", '---')

        Params.fill(self.xfer, ['param_meta'], 1, 1, False)
        self.callparam()
        self.assert_count_equal('', 1)
        self.assert_json_equal('SELECT', "param_meta", '0')
        self.assert_select_equal("param_meta", {0: None, 1: "# Coeur (administration)", 2: 'group #1', 3: 'group #2'})

        self.factory.xfer = ParamSave()
        self.calljson('/CORE/paramSave', {'params': 'param_meta', 'param_meta': '3'}, False)
        self.assert_observer('core.acknowledge', 'CORE', 'paramSave')

        Params.fill(self.xfer, ['param_meta'], 1, 1, False)
        self.callparam()
        self.assert_json_equal('SELECT', "param_meta", '3')

        Params.fill(self.xfer, ['param_meta'], 1, 1, True)
        self.callparam()
        self.assert_count_equal('', 1)
        self.assert_json_equal('LABELFORM', "param_meta", 'group #2')

        self.assertEqual(Params.getvalue('param_meta'), 3)
        self.assertEqual(Params.getobject('param_meta'), grp2)
