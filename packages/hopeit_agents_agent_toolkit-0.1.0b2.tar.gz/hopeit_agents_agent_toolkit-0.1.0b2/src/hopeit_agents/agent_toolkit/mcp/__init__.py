"""Utilities that integrate the agent toolkit with the MCP client."""
