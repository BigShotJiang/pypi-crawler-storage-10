import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from . import gym_pb2 as _gym_pb2
from . import session_pb2 as _session_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class WatchReq(_message.Message):
    __slots__ = ("session_id",)
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    def __init__(self, session_id: _Optional[str] = ...) -> None: ...

class DescribeReq(_message.Message):
    __slots__ = ("session_id",)
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    def __init__(self, session_id: _Optional[str] = ...) -> None: ...

class DescribeRes(_message.Message):
    __slots__ = ("env", "num_envs")
    ENV_FIELD_NUMBER: _ClassVar[int]
    NUM_ENVS_FIELD_NUMBER: _ClassVar[int]
    env: _gym_pb2.EnvSpec
    num_envs: int
    def __init__(self, env: _Optional[_Union[_gym_pb2.EnvSpec, _Mapping]] = ..., num_envs: _Optional[int] = ...) -> None: ...

class GetResultsReq(_message.Message):
    __slots__ = ("session_id",)
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    def __init__(self, session_id: _Optional[str] = ...) -> None: ...

class GetResultsRes(_message.Message):
    __slots__ = ("score", "duration", "timestamp")
    SCORE_FIELD_NUMBER: _ClassVar[int]
    DURATION_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    score: float
    duration: float
    timestamp: _timestamp_pb2.Timestamp
    def __init__(self, score: _Optional[float] = ..., duration: _Optional[float] = ..., timestamp: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ListRegionsReq(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListRegionsRes(_message.Message):
    __slots__ = ("regions",)
    REGIONS_FIELD_NUMBER: _ClassVar[int]
    regions: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, regions: _Optional[_Iterable[str]] = ...) -> None: ...

class ListEnvironmentsReq(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListEnvironmentsRes(_message.Message):
    __slots__ = ("packages",)
    class PackagesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: PackageEnvs
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[PackageEnvs, _Mapping]] = ...) -> None: ...
    PACKAGES_FIELD_NUMBER: _ClassVar[int]
    packages: _containers.MessageMap[str, PackageEnvs]
    def __init__(self, packages: _Optional[_Mapping[str, PackageEnvs]] = ...) -> None: ...

class PackageEnvs(_message.Message):
    __slots__ = ("env_ids",)
    ENV_IDS_FIELD_NUMBER: _ClassVar[int]
    env_ids: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, env_ids: _Optional[_Iterable[str]] = ...) -> None: ...

class CreateSessionReq(_message.Message):
    __slots__ = ("interactive", "internal_benchmark", "external_benchmark", "train")
    INTERACTIVE_FIELD_NUMBER: _ClassVar[int]
    INTERNAL_BENCHMARK_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_BENCHMARK_FIELD_NUMBER: _ClassVar[int]
    TRAIN_FIELD_NUMBER: _ClassVar[int]
    interactive: _session_pb2.InteractiveSessionSpec
    internal_benchmark: _session_pb2.InternalBenchmarkSessionSpec
    external_benchmark: _session_pb2.ExternalBenchmarkSessionSpec
    train: _session_pb2.TrainSessionSpec
    def __init__(self, interactive: _Optional[_Union[_session_pb2.InteractiveSessionSpec, _Mapping]] = ..., internal_benchmark: _Optional[_Union[_session_pb2.InternalBenchmarkSessionSpec, _Mapping]] = ..., external_benchmark: _Optional[_Union[_session_pb2.ExternalBenchmarkSessionSpec, _Mapping]] = ..., train: _Optional[_Union[_session_pb2.TrainSessionSpec, _Mapping]] = ...) -> None: ...
