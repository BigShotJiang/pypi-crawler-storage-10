from google.protobuf import struct_pb2 as _struct_pb2
from . import env_pb2 as _env_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class EnvRecorder(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    UNSPECIFIED: _ClassVar[EnvRecorder]
    NONE: _ClassVar[EnvRecorder]
    ACTION: _ClassVar[EnvRecorder]
    MINARI: _ClassVar[EnvRecorder]
    FRAME: _ClassVar[EnvRecorder]
UNSPECIFIED: EnvRecorder
NONE: EnvRecorder
ACTION: EnvRecorder
MINARI: EnvRecorder
FRAME: EnvRecorder

class InternalClientHello(_message.Message):
    __slots__ = ("package", "gym_id", "num_envs", "seed", "kwargs", "sess_id", "restricted_mode", "recorder")
    PACKAGE_FIELD_NUMBER: _ClassVar[int]
    GYM_ID_FIELD_NUMBER: _ClassVar[int]
    NUM_ENVS_FIELD_NUMBER: _ClassVar[int]
    SEED_FIELD_NUMBER: _ClassVar[int]
    KWARGS_FIELD_NUMBER: _ClassVar[int]
    SESS_ID_FIELD_NUMBER: _ClassVar[int]
    RESTRICTED_MODE_FIELD_NUMBER: _ClassVar[int]
    RECORDER_FIELD_NUMBER: _ClassVar[int]
    package: str
    gym_id: str
    num_envs: int
    seed: int
    kwargs: _struct_pb2.Struct
    sess_id: str
    restricted_mode: bool
    recorder: EnvRecorder
    def __init__(self, package: _Optional[str] = ..., gym_id: _Optional[str] = ..., num_envs: _Optional[int] = ..., seed: _Optional[int] = ..., kwargs: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., sess_id: _Optional[str] = ..., restricted_mode: bool = ..., recorder: _Optional[_Union[EnvRecorder, str]] = ...) -> None: ...

class InternalClientMsg(_message.Message):
    __slots__ = ("hello", "proxied_msg")
    HELLO_FIELD_NUMBER: _ClassVar[int]
    PROXIED_MSG_FIELD_NUMBER: _ClassVar[int]
    hello: InternalClientHello
    proxied_msg: _env_pb2.ClientMsg
    def __init__(self, hello: _Optional[_Union[InternalClientHello, _Mapping]] = ..., proxied_msg: _Optional[_Union[_env_pb2.ClientMsg, _Mapping]] = ...) -> None: ...

class InternalSaveHighlightsReq(_message.Message):
    __slots__ = ("sess_id", "package", "gym_id", "num_envs", "seed", "kwargs")
    SESS_ID_FIELD_NUMBER: _ClassVar[int]
    PACKAGE_FIELD_NUMBER: _ClassVar[int]
    GYM_ID_FIELD_NUMBER: _ClassVar[int]
    NUM_ENVS_FIELD_NUMBER: _ClassVar[int]
    SEED_FIELD_NUMBER: _ClassVar[int]
    KWARGS_FIELD_NUMBER: _ClassVar[int]
    sess_id: str
    package: str
    gym_id: str
    num_envs: int
    seed: int
    kwargs: _struct_pb2.Struct
    def __init__(self, sess_id: _Optional[str] = ..., package: _Optional[str] = ..., gym_id: _Optional[str] = ..., num_envs: _Optional[int] = ..., seed: _Optional[int] = ..., kwargs: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class HighlightedEpisode(_message.Message):
    __slots__ = ("video_key", "video_path")
    VIDEO_KEY_FIELD_NUMBER: _ClassVar[int]
    VIDEO_PATH_FIELD_NUMBER: _ClassVar[int]
    video_key: str
    video_path: str
    def __init__(self, video_key: _Optional[str] = ..., video_path: _Optional[str] = ...) -> None: ...

class InternalSaveHighlightsRes(_message.Message):
    __slots__ = ("episodes",)
    EPISODES_FIELD_NUMBER: _ClassVar[int]
    episodes: _containers.RepeatedCompositeFieldContainer[HighlightedEpisode]
    def __init__(self, episodes: _Optional[_Iterable[_Union[HighlightedEpisode, _Mapping]]] = ...) -> None: ...
