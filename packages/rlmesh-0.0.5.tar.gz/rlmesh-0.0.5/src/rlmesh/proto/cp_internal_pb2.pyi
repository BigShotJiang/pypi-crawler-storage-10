from . import gym_pb2 as _gym_pb2
from . import env_pb2 as _env_pb2
from . import session_pb2 as _session_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class InternalDescribeSessionReq(_message.Message):
    __slots__ = ("session_id", "token")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    token: str
    def __init__(self, session_id: _Optional[str] = ..., token: _Optional[str] = ...) -> None: ...

class InternalDescribeSessionRes(_message.Message):
    __slots__ = ("env", "num_envs", "seed", "type", "state")
    ENV_FIELD_NUMBER: _ClassVar[int]
    NUM_ENVS_FIELD_NUMBER: _ClassVar[int]
    SEED_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    env: _gym_pb2.EnvSpec
    num_envs: int
    seed: int
    type: _session_pb2.SessionType
    state: _session_pb2.SessionState
    def __init__(self, env: _Optional[_Union[_gym_pb2.EnvSpec, _Mapping]] = ..., num_envs: _Optional[int] = ..., seed: _Optional[int] = ..., type: _Optional[_Union[_session_pb2.SessionType, str]] = ..., state: _Optional[_Union[_session_pb2.SessionState, str]] = ...) -> None: ...

class SessionResult(_message.Message):
    __slots__ = ("score", "duration", "episodes")
    SCORE_FIELD_NUMBER: _ClassVar[int]
    DURATION_FIELD_NUMBER: _ClassVar[int]
    EPISODES_FIELD_NUMBER: _ClassVar[int]
    score: float
    duration: float
    episodes: _containers.RepeatedCompositeFieldContainer[_env_pb2.EpisodeResult]
    def __init__(self, score: _Optional[float] = ..., duration: _Optional[float] = ..., episodes: _Optional[_Iterable[_Union[_env_pb2.EpisodeResult, _Mapping]]] = ...) -> None: ...

class InternalUpdateSessionReq(_message.Message):
    __slots__ = ("session_id", "token", "state", "result", "user_token")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    RESULT_FIELD_NUMBER: _ClassVar[int]
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    token: str
    state: _session_pb2.SessionState
    result: SessionResult
    user_token: str
    def __init__(self, session_id: _Optional[str] = ..., token: _Optional[str] = ..., state: _Optional[_Union[_session_pb2.SessionState, str]] = ..., result: _Optional[_Union[SessionResult, _Mapping]] = ..., user_token: _Optional[str] = ...) -> None: ...

class InternalUpdateSessionRes(_message.Message):
    __slots__ = ("session", "highlight_upload_urls")
    class HighlightUploadUrlsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    SESSION_FIELD_NUMBER: _ClassVar[int]
    HIGHLIGHT_UPLOAD_URLS_FIELD_NUMBER: _ClassVar[int]
    session: _session_pb2.Session
    highlight_upload_urls: _containers.ScalarMap[str, str]
    def __init__(self, session: _Optional[_Union[_session_pb2.Session, _Mapping]] = ..., highlight_upload_urls: _Optional[_Mapping[str, str]] = ...) -> None: ...
