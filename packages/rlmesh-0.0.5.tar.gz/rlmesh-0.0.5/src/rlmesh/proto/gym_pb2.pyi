from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class DType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DTYPE_UNSPECIFIED: _ClassVar[DType]
    UINT8: _ClassVar[DType]
    INT32: _ClassVar[DType]
    INT64: _ClassVar[DType]
    FLOAT32: _ClassVar[DType]
    FLOAT64: _ClassVar[DType]

class SpaceKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    UNSPECIFIED_SPACE: _ClassVar[SpaceKind]
    BOX: _ClassVar[SpaceKind]
    DISCRETE: _ClassVar[SpaceKind]
    MULTIBINARY: _ClassVar[SpaceKind]
    MULTIDISCRETE: _ClassVar[SpaceKind]
    TEXT: _ClassVar[SpaceKind]
    TUPLE: _ClassVar[SpaceKind]
    DICT: _ClassVar[SpaceKind]
DTYPE_UNSPECIFIED: DType
UINT8: DType
INT32: DType
INT64: DType
FLOAT32: DType
FLOAT64: DType
UNSPECIFIED_SPACE: SpaceKind
BOX: SpaceKind
DISCRETE: SpaceKind
MULTIBINARY: SpaceKind
MULTIDISCRETE: SpaceKind
TEXT: SpaceKind
TUPLE: SpaceKind
DICT: SpaceKind

class BoxSpec(_message.Message):
    __slots__ = ("unbounded", "lo_scalar", "hi_scalar", "lo_broadcast", "hi_broadcast")
    UNBOUNDED_FIELD_NUMBER: _ClassVar[int]
    LO_SCALAR_FIELD_NUMBER: _ClassVar[int]
    HI_SCALAR_FIELD_NUMBER: _ClassVar[int]
    LO_BROADCAST_FIELD_NUMBER: _ClassVar[int]
    HI_BROADCAST_FIELD_NUMBER: _ClassVar[int]
    unbounded: bool
    lo_scalar: float
    hi_scalar: float
    lo_broadcast: _containers.RepeatedScalarFieldContainer[float]
    hi_broadcast: _containers.RepeatedScalarFieldContainer[float]
    def __init__(self, unbounded: bool = ..., lo_scalar: _Optional[float] = ..., hi_scalar: _Optional[float] = ..., lo_broadcast: _Optional[_Iterable[float]] = ..., hi_broadcast: _Optional[_Iterable[float]] = ...) -> None: ...

class DiscreteSpec(_message.Message):
    __slots__ = ("n", "start")
    N_FIELD_NUMBER: _ClassVar[int]
    START_FIELD_NUMBER: _ClassVar[int]
    n: int
    start: int
    def __init__(self, n: _Optional[int] = ..., start: _Optional[int] = ...) -> None: ...

class MultiBinarySpec(_message.Message):
    __slots__ = ("n",)
    N_FIELD_NUMBER: _ClassVar[int]
    n: int
    def __init__(self, n: _Optional[int] = ...) -> None: ...

class MultiDiscreteSpec(_message.Message):
    __slots__ = ("nvec",)
    NVEC_FIELD_NUMBER: _ClassVar[int]
    nvec: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, nvec: _Optional[_Iterable[int]] = ...) -> None: ...

class TextSpec(_message.Message):
    __slots__ = ("min_length", "max_length", "charset")
    MIN_LENGTH_FIELD_NUMBER: _ClassVar[int]
    MAX_LENGTH_FIELD_NUMBER: _ClassVar[int]
    CHARSET_FIELD_NUMBER: _ClassVar[int]
    min_length: int
    max_length: int
    charset: str
    def __init__(self, min_length: _Optional[int] = ..., max_length: _Optional[int] = ..., charset: _Optional[str] = ...) -> None: ...

class DictSpec(_message.Message):
    __slots__ = ("keys", "spaces")
    KEYS_FIELD_NUMBER: _ClassVar[int]
    SPACES_FIELD_NUMBER: _ClassVar[int]
    keys: _containers.RepeatedScalarFieldContainer[str]
    spaces: _containers.RepeatedCompositeFieldContainer[SpaceSpec]
    def __init__(self, keys: _Optional[_Iterable[str]] = ..., spaces: _Optional[_Iterable[_Union[SpaceSpec, _Mapping]]] = ...) -> None: ...

class TupleSpec(_message.Message):
    __slots__ = ("spaces",)
    SPACES_FIELD_NUMBER: _ClassVar[int]
    spaces: _containers.RepeatedCompositeFieldContainer[SpaceSpec]
    def __init__(self, spaces: _Optional[_Iterable[_Union[SpaceSpec, _Mapping]]] = ...) -> None: ...

class SpaceSpec(_message.Message):
    __slots__ = ("kind", "dtype", "shape", "box", "discrete", "multi_binary", "multi_discrete", "text", "dict", "tuple")
    KIND_FIELD_NUMBER: _ClassVar[int]
    DTYPE_FIELD_NUMBER: _ClassVar[int]
    SHAPE_FIELD_NUMBER: _ClassVar[int]
    BOX_FIELD_NUMBER: _ClassVar[int]
    DISCRETE_FIELD_NUMBER: _ClassVar[int]
    MULTI_BINARY_FIELD_NUMBER: _ClassVar[int]
    MULTI_DISCRETE_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    DICT_FIELD_NUMBER: _ClassVar[int]
    TUPLE_FIELD_NUMBER: _ClassVar[int]
    kind: SpaceKind
    dtype: DType
    shape: _containers.RepeatedScalarFieldContainer[int]
    box: BoxSpec
    discrete: DiscreteSpec
    multi_binary: MultiBinarySpec
    multi_discrete: MultiDiscreteSpec
    text: TextSpec
    dict: DictSpec
    tuple: TupleSpec
    def __init__(self, kind: _Optional[_Union[SpaceKind, str]] = ..., dtype: _Optional[_Union[DType, str]] = ..., shape: _Optional[_Iterable[int]] = ..., box: _Optional[_Union[BoxSpec, _Mapping]] = ..., discrete: _Optional[_Union[DiscreteSpec, _Mapping]] = ..., multi_binary: _Optional[_Union[MultiBinarySpec, _Mapping]] = ..., multi_discrete: _Optional[_Union[MultiDiscreteSpec, _Mapping]] = ..., text: _Optional[_Union[TextSpec, _Mapping]] = ..., dict: _Optional[_Union[DictSpec, _Mapping]] = ..., tuple: _Optional[_Union[TupleSpec, _Mapping]] = ...) -> None: ...

class GymSpaces(_message.Message):
    __slots__ = ("obs", "action")
    OBS_FIELD_NUMBER: _ClassVar[int]
    ACTION_FIELD_NUMBER: _ClassVar[int]
    obs: SpaceSpec
    action: SpaceSpec
    def __init__(self, obs: _Optional[_Union[SpaceSpec, _Mapping]] = ..., action: _Optional[_Union[SpaceSpec, _Mapping]] = ...) -> None: ...

class GymMetadata(_message.Message):
    __slots__ = ("render_modes", "render_fps")
    RENDER_MODES_FIELD_NUMBER: _ClassVar[int]
    RENDER_FPS_FIELD_NUMBER: _ClassVar[int]
    render_modes: _containers.RepeatedScalarFieldContainer[str]
    render_fps: int
    def __init__(self, render_modes: _Optional[_Iterable[str]] = ..., render_fps: _Optional[int] = ...) -> None: ...

class EnvSpec(_message.Message):
    __slots__ = ("package", "gym_id", "spaces", "metadata")
    PACKAGE_FIELD_NUMBER: _ClassVar[int]
    GYM_ID_FIELD_NUMBER: _ClassVar[int]
    SPACES_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    package: str
    gym_id: str
    spaces: GymSpaces
    metadata: GymMetadata
    def __init__(self, package: _Optional[str] = ..., gym_id: _Optional[str] = ..., spaces: _Optional[_Union[GymSpaces, _Mapping]] = ..., metadata: _Optional[_Union[GymMetadata, _Mapping]] = ...) -> None: ...
