from typing import Any

import gymnasium as gym
from gymnasium.vector.utils import batch_space

from rlmesh.env.env_transport import AsyncEnvTransport
from rlmesh.proto import gym_pb2
from rlmesh.gym import deserialize_space
from rlmesh.utils import LoopRunner


class RemoteVectorEnv(gym.vector.VectorEnv):
    metadata: dict[str, Any]

    def __init__(
        self,
        env_spec: gym_pb2.EnvSpec,
        num_envs: int,
        *,
        transport_addr: str,
        transport_metadata: list,
    ):
        super().__init__()

        self.num_envs = num_envs
        self.metadata = {
            "render_modes": list(env_spec.metadata.render_modes),
            "render_fps": int(env_spec.metadata.render_fps or 30),
        }

        self.single_observation_space = deserialize_space(env_spec.spaces.obs)
        self.observation_space = batch_space(self.single_observation_space, num_envs)

        self.single_action_space = deserialize_space(env_spec.spaces.action)
        self.action_space = batch_space(self.single_action_space, num_envs)

        self._runner = LoopRunner()
        self._tx = AsyncEnvTransport(transport_addr, transport_metadata)
        self._runner.run(self._tx.start())
        self._closed = False

        self._obs = None
        self._is_ale = env_spec.package == "ale_py"

    def reset(self, *, seed: int | None = None, options: dict | None = None):
        if self._closed:
            raise RuntimeError("env closed")

        obs, infos = self._runner.run(self._tx.reset(seed=seed, options=options))

        self._obs = obs
        return obs, infos

    def step(self, actions):
        if self._closed:
            raise RuntimeError("env closed")
        if not self.action_space.contains(actions):
            raise ValueError("action outside action_space")

        obs, rewards, terms, truns, infos = self._runner.run(self._tx.step(actions))
        self._obs = obs
        return obs, rewards, terms, truns, infos

    def render(self):
        if self._closed:
            raise RuntimeError("env closed")

        # Special Case for ALE Environment
        # - since we know the obs is the rgb_array, we can skip sending it over twice
        if self._is_ale and self._obs is not None:
            return self._obs

        frame = self._runner.run(self._tx.render())
        return frame

    def close(self):
        if not self._closed:
            try:
                self._runner.run(self._tx.close())
            finally:
                self._runner.stop()
                self._closed = True
