from typing import Optional

import json
from importlib.metadata import Distribution, version


def is_editable_install(package_name: str) -> bool:
    try:
        direct_url = Distribution.from_name(package_name).read_text("direct_url.json")
        if direct_url is None:
            return False

        pkg_is_editable = (
            json.loads(direct_url).get("dir_info", {}).get("editable", False)
        )
        return pkg_is_editable
    except Exception:
        return False


def get_package_version(package_name: str) -> Optional[str]:
    try:
        return version(package_name)
    except Exception:
        return None
