import gymnasium as gym
import time


def check_env(env: gym.Env):
    print("-- Env Check --")
    print(
        "1) " + "Instance of gym.Env" if isinstance(env, gym.Env) else "Not a gym.Env"
    )
    print(f"2) Gym ID -> {env.spec.id if env.spec else 'N/A'}")
    print(f"3) Obs Space -> {str(env.observation_space)}")
    print(f"4) Action Space -> {str(env.action_space)}")


def test_env(env: gym.Env, max_timesteps=1000):
    env = gym.wrappers.TimeLimit(env, max_episode_steps=max_timesteps)

    obs, info = env.reset(seed=42)

    done = False
    score = 0.0
    steps = 0

    start = time.time()
    while not done:
        action = env.action_space.sample()
        obs, r, term, trunc, info = env.step(action)
        score += float(r)
        done = term or trunc
        steps += 1

    end = time.time()
    elapsed = end - start
    sps = steps / elapsed

    print("-- Results --")
    print("Score:", score)
    print("Steps:", steps)
    print("Time (s):", elapsed)
    print("SPS:", sps)
