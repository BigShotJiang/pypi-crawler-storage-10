import time

import numpy as np
from sklearn.ensemble import (
    GradientBoostingClassifier,
    GradientBoostingRegressor,
    BaggingClassifier,
    BaggingRegressor
)
from sklearn.ensemble._gb import set_huber_delta, _update_terminal_regions
from sklearn._loss.loss import HuberLoss
from sklearn.utils._param_validation import StrOptions
from sklearn.linear_model import RidgeCV

from .base import RulesExtractorMixin
from .extractors import QuantileDecisionTreeRegressor
from .utils import compute_staibility_criterion

class QuantileGradientBoostingClassifier(GradientBoostingClassifier):
    """
    GradientBoostingClassifier of scikit -learn with the "quantile" spliiter option.
    Used for GradientBoostingClassifier in GbExtractorClassifier
    """

    _parameter_constraints: dict = {**GradientBoostingClassifier._parameter_constraints}
    _parameter_constraints["splitter"] = [StrOptions({"best", "random", "quantile"})]

    def __init__(
        self,
        *,
        loss="log_loss",
        learning_rate=0.1,
        n_estimators=100,
        subsample=1.0,
        criterion="friedman_mse",
        min_samples_split=2,
        min_samples_leaf=1,
        min_weight_fraction_leaf=0.0,
        max_depth=3,
        min_impurity_decrease=0.0,
        init=None,
        random_state=None,
        max_features=None,
        verbose=0,
        max_leaf_nodes=None,
        warm_start=False,
        validation_fraction=0.1,
        n_iter_no_change=None,
        tol=1e-4,
        ccp_alpha=0.0,
        splitter="quantile",
    ):
        super().__init__(
            loss=loss,
            learning_rate=learning_rate,
            n_estimators=n_estimators,
            criterion=criterion,
            min_samples_split=min_samples_split,
            min_samples_leaf=min_samples_leaf,
            min_weight_fraction_leaf=min_weight_fraction_leaf,
            max_depth=max_depth,
            init=init,
            subsample=subsample,
            max_features=max_features,
            random_state=random_state,
            verbose=verbose,
            max_leaf_nodes=max_leaf_nodes,
            min_impurity_decrease=min_impurity_decrease,
            warm_start=warm_start,
            validation_fraction=validation_fraction,
            n_iter_no_change=n_iter_no_change,
            tol=tol,
            ccp_alpha=ccp_alpha,
        )
        self.splitter = splitter

    def _fit_stage(
        self,
        i,
        X,
        y,
        raw_predictions,
        sample_weight,
        sample_mask,
        random_state,
        X_csc=None,
        X_csr=None,
    ):
        """Fit another stage of ``n_trees_per_iteration_`` trees."""
        original_y = y

        if isinstance(self._loss, HuberLoss):
            set_huber_delta(
                loss=self._loss,
                y_true=y,
                raw_prediction=raw_predictions,
                sample_weight=sample_weight,
            )
        # TODO: Without oob, i.e. with self.subsample = 1.0, we could call
        # self._loss.loss_gradient and use it to set train_score_.
        # But note that train_score_[i] is the score AFTER fitting the i-th tree.
        # Note: We need the negative gradient!
        neg_gradient = -self._loss.gradient(
            y_true=y,
            raw_prediction=raw_predictions,
            sample_weight=None,  # We pass sample_weights to the tree directly.
        )
        # 2-d views of shape (n_samples, n_trees_per_iteration_) or (n_samples, 1)
        # on neg_gradient to simplify the loop over n_trees_per_iteration_.
        if neg_gradient.ndim == 1:
            neg_g_view = neg_gradient.reshape((-1, 1))
        else:
            neg_g_view = neg_gradient

        for k in range(self.n_trees_per_iteration_):
            if self._loss.is_multiclass:
                y = np.array(original_y == k, dtype=np.float64)

            # induce regression tree on the negative gradient
            tree = QuantileDecisionTreeRegressor(
                criterion=self.criterion,
                splitter=self.splitter,  ## ici
                max_depth=self.max_depth,
                min_samples_split=self.min_samples_split,
                min_samples_leaf=self.min_samples_leaf,
                min_weight_fraction_leaf=self.min_weight_fraction_leaf,
                min_impurity_decrease=self.min_impurity_decrease,
                max_features=self.max_features,
                max_leaf_nodes=self.max_leaf_nodes,
                random_state=random_state,
                ccp_alpha=self.ccp_alpha,
            )

            if self.subsample < 1.0:
                # no inplace multiplication!
                sample_weight = sample_weight * sample_mask.astype(np.float64)

            X = X_csc if X_csc is not None else X
            tree.fit(
                X, neg_g_view[:, k], sample_weight=sample_weight, check_input=False
            )

            # update tree leaves
            X_for_tree_update = X_csr if X_csr is not None else X
            _update_terminal_regions(
                self._loss,
                tree.tree_,
                X_for_tree_update,
                y,
                neg_g_view[:, k],
                raw_predictions,
                sample_weight,
                sample_mask,
                learning_rate=self.learning_rate,
                k=k,
            )

            # add tree to ensemble
            self.estimators_[i, k] = tree

        return raw_predictions
    
class BaggingExtractorClassifier(RulesExtractorMixin, BaggingClassifier):
    def __init__(
        self,
        estimator=QuantileGradientBoostingClassifier(n_estimators=10),
        n_estimators=100,
        max_samples=1.0,
        max_features=1.0,
        bootstrap=True,
        bootstrap_features=False,
        oob_score=False,
        warm_start=False,
        n_jobs=None,
        random_state=None,
        verbose=0,
        p0=0.01,
        num_rule=25,
        quantile=10,
        to_not_binarize_colindexes=None,
        starting_index_one_hot=None,
    ):
        super().__init__(
            estimator=estimator,
            n_estimators=n_estimators,
            max_samples=max_samples,
            max_features=max_features,
            bootstrap=bootstrap,
            bootstrap_features=bootstrap_features,
            oob_score=oob_score,
            warm_start=warm_start,
            n_jobs=n_jobs,
            random_state=random_state,
            verbose=verbose,
        )
        self.p0 = p0
        self.num_rule = num_rule
        self.quantile = quantile
        self.to_not_binarize_colindexes = to_not_binarize_colindexes
        self.starting_index_one_hot = starting_index_one_hot

    def fit(self, X, y, sample_weight=None):
        start = time.time()
        self._fit_quantile_classifier(X, y, sample_weight)
        all_possible_rules_list = []
        for boosted_trees in self.estimators_:  ## iterate over the bagged estimators
            for dtree in boosted_trees.estimators_[
                :, 0
            ]:  # iterate over the boosted trees
                ##[:,0] because of sklearn outputs (see n_tree_per_iter = 1)
                tree = dtree.tree_
                curr_tree_rules = self._extract_single_tree_rules(tree)
                if (
                    len(curr_tree_rules) > 0 and len(curr_tree_rules[0]) > 0
                ):  # to avoid empty rules
                    # Boosting may produce trees with no splits, for example when the number of estimators is high
                    all_possible_rules_list.extend(curr_tree_rules)
        self._fit_rules(X, y, all_possible_rules_list, sample_weight)
        end = time.time()
        print(f"All fit took {end - start:.4f} seconds")
        compute_staibility_criterion(self)


class BaggingExtractorRegressor(RulesExtractorMixin, BaggingClassifier):
    def __init__(
        self,
        estimator=QuantileGradientBoostingClassifier(n_estimators=10),
        n_estimators=100,
        max_samples=1.0,
        max_features=1.0,
        bootstrap=True,
        bootstrap_features=False,
        oob_score=False,
        warm_start=False,
        n_jobs=None,
        random_state=None,
        verbose=0,
        p0=0.01,
        num_rule=25,
        quantile=10,
        to_not_binarize_colindexes=None,
        starting_index_one_hot=None,
    ):
        super().__init__(
            estimator=estimator,
            n_estimators=n_estimators,
            max_samples=max_samples,
            max_features=max_features,
            bootstrap=bootstrap,
            bootstrap_features=bootstrap_features,
            oob_score=oob_score,
            warm_start=warm_start,
            n_jobs=n_jobs,
            random_state=random_state,
            verbose=verbose,
        )
        self.p0 = p0
        self.num_rule = num_rule
        self.quantile = quantile
        self.to_not_binarize_colindexes = to_not_binarize_colindexes
        self.starting_index_one_hot = starting_index_one_hot

    def fit(self, X, y, sample_weight=None):
        start = time.time()
        self._fit_quantile_classifier(X, y, sample_weight)
        all_possible_rules_list = []
        for boosted_trees in self.estimators_:  ## iterate over the bagged estimators
            for dtree in boosted_trees.estimators_[
                :, 0
            ]:  # iterate over the boosted trees
                ##[:,0] because of sklearn outputs (see n_tree_per_iter = 1)
                tree = dtree.tree_
                curr_tree_rules = self._extract_single_tree_rules(tree)
                if (
                    len(curr_tree_rules) > 0 and len(curr_tree_rules[0]) > 0
                ):  # to avoid empty rules
                    # Boosting may produce trees with no splits, for example when the number of estimators is high
                    all_possible_rules_list.extend(curr_tree_rules)
        self._fit_rules(X, y, all_possible_rules_list, sample_weight)
        end = time.time()
        print(f"All fit took {end - start:.4f} seconds")
        compute_staibility_criterion(self)