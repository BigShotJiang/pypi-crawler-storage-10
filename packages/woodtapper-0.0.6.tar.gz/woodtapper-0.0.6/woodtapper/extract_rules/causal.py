import time

import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import (
    RandomForestClassifier,
)
from sklearn.ensemble._forest import ForestClassifier
from sklearn.utils._param_validation import StrOptions

from econml.grf._base_grf import BaseGRF,GRFTree
from econml.grf import CausalForest
from econml._ensemble import BaseEnsemble


from .base import RulesExtractorMixin
from .utils import compute_staibility_criterion

from .Splitter.QuantileSplitter import QuantileBestSplitter
from econml.tree import _splitter
import econml.tree._tree_classes
# Override the SPLITTERS dictionary to include the QuantileBestSplitter
econml.tree._tree_classes.SPLITTERS ={
    "best": _splitter.BestSplitter,
    "random": _splitter.BestSplitter,
    "quantile": QuantileBestSplitter,
}


class SirusCausalClassifier(RulesExtractorMixin, CausalForest):
    """
    SIRUS class applied with a RandomForestClassifier.

    Parameters
    ----------
    n_estimators : int, default=100
        The number of trees in the forest.
    criterion : {"gini", "entropy", "log_loss"}, default="gini"
        The function to measure the quality of a split. Supported criteria are
        "gini" for the Gini impurity, "entropy" for the information gain and
        "log_loss" for the reduction in log loss.
    max_depth : int, default=2
        The maximum depth of the tree. If None, then nodes are expanded until
        all leaves are pure or until all leaves contain less than min_samples_split samples.
    class_weight : {"balanced", "balanced_subsample"}, default=None
        Weights associated with classes in the form {class_label: weight}.
        If None, all classes are supposed to have weight one.
    splitter : {"best", "random", "quantile"}, default="quantile"
        The strategy used to choose the split at each node. Supported strategies
        are "best" to choose the best split and "random" to choose the best random
        split. "quantile" is similar to "best" but the split point is chosen to
        be a a value in the training set and not the beetween to values as for best and random.
    p0 : float, default=0.01
        The threshold for rule selection.
    num_rule : int, default=25
        The maximum number of rules to extract.
    quantile : int, default=10
        The number of quantiles to use for the "quantile" splitter.
    to_not_binarize_colindexes : list of int, default=None
        List of column indexes to not binarize when extracting the rules.
    starting_index_one_hot : int, default=None
        Index of the first one-hot encoded variable in the dataset (to handle correctly the binarization of the rules).
    Attributes
    ----------
    all_possible_rules_list : list
        List of all possible rules extracted from the forest.


    """

    #_parameter_constraints: dict = {**CausalForest._parameter_constraints}
    #_parameter_constraints["splitter"] = [StrOptions({"best", "random", "quantile"})]

    def __init__(self,
                n_estimators=100, *,
                criterion="mse",
                max_depth=None,
                min_samples_split=10,
                min_samples_leaf=5,
                min_weight_fraction_leaf=0.,
                min_var_fraction_leaf=None,
                min_var_leaf_on_val=False,
                max_features="auto",
                min_impurity_decrease=0.,
                max_samples=.45,
                min_balancedness_tol=.45,
                honest=True,
                inference=True,
                fit_intercept=True,
                subforest_size=4,
                n_jobs=-1,
                random_state=None,
                verbose=0,
                warm_start=False,
                splitter="quantile",
                p0=0.01,
                num_rule=25,
                quantile=10,
                to_not_binarize_colindexes=None,
                starting_index_one_hot=None,
        ):
        ##BaseGRF

        self.criterion = criterion
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.min_samples_leaf = min_samples_leaf
        self.min_weight_fraction_leaf = min_weight_fraction_leaf
        self.min_var_fraction_leaf = min_var_fraction_leaf
        self.min_var_leaf_on_val = min_var_leaf_on_val
        self.max_features = max_features
        self.min_impurity_decrease = min_impurity_decrease
        self.min_balancedness_tol = min_balancedness_tol
        self.honest = honest
        self.inference = inference
        self.fit_intercept = fit_intercept
        self.subforest_size = subforest_size
        self.n_jobs = n_jobs
        self.random_state = random_state
        self.verbose = verbose
        self.warm_start = warm_start
        self.max_samples = max_samples
        super(BaseGRF,self).__init__(
            base_estimator=GRFTree(),
            n_estimators=n_estimators,
            estimator_params=("criterion", "max_depth", "min_samples_split",
                              "min_samples_leaf", "min_weight_fraction_leaf",
                              "min_var_leaf", "min_var_leaf_on_val",
                              "max_features", "min_impurity_decrease", "honest",
                              "min_balancedness_tol",
                              "random_state"))
        ##BaseGRF

        #self.splitter = splitter
        self.p0 = p0
        self.num_rule = num_rule
        self.quantile = quantile
        self.to_not_binarize_colindexes = to_not_binarize_colindexes
        self.starting_index_one_hot = starting_index_one_hot  # index of the first one-hot encoded variable in the dataset (to handle correctly the binarization of the rules)

    def fit(self, X, y, sample_weight=None, check_input=True):
        """
        Fit the SIRUS model.
        Parameters
        ----------
        X : array-like of shape (n_samples, n_features)
            The training input samples.
        y : array-like of shape (n_samples,)
            The target values (class labels) as integers or strings.
        sample_weight : array-like of shape (n_samples,), default=None

        Returns
        -------
        self : object
            Fitted estimator.

        """
        start = time.time()
        self._fit_quantile_classifier(X, y, sample_weight)
        all_possible_rules_list = []
        for dtree in self.estimators_:  ## extraction  of all trees rules
            tree = dtree.tree_
            all_possible_rules_list.extend(self._extract_single_tree_rules(tree))
        self._fit_rules(X, y, all_possible_rules_list, sample_weight)
        end = time.time()
        print(f"All fit took {end - start:.4f} seconds")
        compute_staibility_criterion(self)