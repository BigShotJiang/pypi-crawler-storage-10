"""
Kousuan Skill - A Python package for mental arithmetic calculation skills

This package provides various techniques and methods for improving
mental arithmetic calculation abilities.
"""

__version__ = "0.1.0"
__author__ = "liandong"

import sys
import os

from .core import (
    add_numbers,
    subtract_numbers,
    multiply_numbers,
    divide_numbers,
    calculate_percentage,
    quick_addition,
    quick_multiplication,
    number_decomposition,
    get_multiplication_table,
    mental_math_tricks
)