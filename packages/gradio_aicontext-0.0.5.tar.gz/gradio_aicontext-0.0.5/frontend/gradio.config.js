export default {
  plugins: [],
  svelte: {
    preprocess: [],
  },
  build: {
    target: "modules",
  },
};