__version__ = "1.2.2"

from .bashimu import run_repl

__all__ = ["run_repl", "__version__"]
