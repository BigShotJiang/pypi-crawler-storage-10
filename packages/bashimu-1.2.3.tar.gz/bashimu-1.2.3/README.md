<img src="img/bashimu.jpeg" alt="drawing" width="200"/>

# Bashimu

A command-line LLM chat tool that supports multiple AI providers with customizable personas.

## Features

- **Multiple AI Providers**: OpenAI, Anthropic Claude, Google Gemini, and Ollama
- **Customizable Personas**: Define AI behavior and conversation styles
- **Interactive REPL**: Rich terminal interface with markdown rendering
- **Non-Interactive Mode**: Send queries directly from command line
- **Conversation Management**: Save, edit, and review chat history
- **Provider & Model Switching**: Change providers and models on the fly

## Installation

```bash
pip install bashimu
```

## Quick Start

### Interactive Mode

Launch the interactive chat:

```bash
bashimu-cli
```

### Non-Interactive Mode

Send a single query and get the response:

```bash
bashimu-cli "What is the capital of France?"
```

Use with specific provider or persona:

```bash
bashimu-cli --provider anthropic "Explain Python decorators"
bashimu-cli --persona coding_mentor "Review this code: def foo(): pass"
```

Perfect for scripting and piping:

```bash
bashimu-cli "Generate a JSON list of 5 colors" | jq '.'
```

## Configuration

On first run, bashimu creates configuration files at:
- Config: `~/.config/llm-chat/config.json`
- Personas: `~/.config/llm-chat/personas/`

Edit the config file to add your API keys:

```json
{
  "default_provider": "openai",
  "default_persona": "default",
  "providers": {
    "openai": {
      "name": "OpenAI",
      "api_key": "YOUR_OPENAI_API_KEY",
      "default_model": "gpt-4o"
    },
    "anthropic": {
      "name": "Anthropic",
      "api_key": "YOUR_ANTHROPIC_API_KEY",
      "default_model": "claude-3-haiku-20240307"
    }
  }
}
```

## Interactive Commands

When in interactive mode, use these commands:

- `/help` - Show help message
- `/clear` - Clear conversation history
- `/history` - Show conversation history
- `/save` - Save conversation to JSON file
- `/edit` - Edit and resend your last message
- `/provider [name]` - Switch AI provider
- `/models` - List available models
- `/model [name]` - Switch model
- `/personas` - List available personas
- `/persona [name]` - Switch persona (clears chat)
- `/quit`, `/q`, `/exit` - Exit the chat

## Creating Custom Personas

Create JSON files in `~/.config/llm-chat/personas/`:

```json
{
  "name": "Code Reviewer",
  "provider": "anthropic",
  "model": "claude-3-opus-20240229",
  "user_identity": "A developer seeking code review",
  "ai_identity": "An expert code reviewer",
  "conversation_goal": "To review code for bugs, style, and best practices",
  "response_style": "Technical, thorough, and constructive"
}
```

## Command-Line Options

```
bashimu-cli [query] [options]

Positional Arguments:
  query                Optional query to send (non-interactive mode)

Options:
  --provider PROVIDER  Override the default provider
  --persona PERSONA    Override the default persona
  --config CONFIG      Path to a custom config file
  -h, --help          Show help message
```

## License

MIT License - see LICENSE file for details

## Links

- Homepage: https://github.com/wiktorjl/bashimu
- Issues: https://github.com/wiktorjl/bashimu/issues
