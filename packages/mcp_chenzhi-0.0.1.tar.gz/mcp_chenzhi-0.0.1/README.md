# mcp-chenzhi

辰知MCP工具 (Chenzhi MCP Tool)

这是一个基于 [MCP](https://github.com/agi-merge/mcp) 框架的工具服务器，提供了查询天气和计算加法的功能。

## 功能

- **查询天气**: 通过 `query_weather` 工具，输入城市名称获取实时天气信息。
- **计算加法**: 通过 `add` 工具，计算两个整数的和。

## 安装

1.  克隆本项目到本地:
    ```bash
    git clone https://github.com/chris666-sys/mcp-chenzhi.git
    cd mcp-chenzhi
    ```

2.  安装依赖:
    建议在虚拟环境中使用 pip 安装项目依赖。
    ```bash
    pip install .
    ```
    或者
    ```bash
    pip install -r requirements.txt 
    ```
    (如果项目提供了 `requirements.txt` 文件)

## 使用

直接运行以下命令启动服务:
```bash
mcp-chenzhi
```

## MCP 服务器配置
```json
{
    "mcpServers": {
        "mcp-chenzhi": {
            "command": "uvx",
            "args": [
                "mcp-chenzhi"
            ]
        }
    }
}
```

服务启动后，MCP Agent 就可以连接到此服务器并使用注册的工具。
