from mcpMain import main

main()
