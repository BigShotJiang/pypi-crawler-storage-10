# The functions need to be defined outside the if __name__ block 
# so they are available when called.

# Note: The functions are still implicitly relying on the global variables 
# N and board being defined later, which works in this structure.

def is_attack(i, j):
    for k in range(N):
        if board[i][k] == 1 or board[k][j] == 1:
            return True

        for l in range(N):
            if (k + l == i + j) or (k - l == j - i):
                if board[k][l] == 1:
                    return True
    return False


def solve_queens(n):
    if n == 0:
        return True
    for i in range(N):
        for j in range(N):
            if board[i][j] == 0 and not is_attack(i, j):
                board[i][j] = 1
                if solve_queens(n - 1):
                    return True
                board[i][j] = 0
    return False


# --- Standard Python Entry Point ---

if __name__ == "__main__":
    # The setup logic (which defines the global variables N and board) 
    # is placed inside this block.

    print("enter no of queens:")
    N = int(input())
    board = [[0] * N for _ in range(N)]

    # Now call the main function
    if solve_queens(N):
        for row in board:
            print(row)
    else:
        print("no solution")