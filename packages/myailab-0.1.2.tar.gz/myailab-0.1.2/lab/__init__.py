# Import the 'main' function from each of your lab files
from .eightqueen import main as main_8queen
from .alphabeta import main as main_alphabeta
from .aostar import main as main_aostar
from .astar import main as main_astar
from .best import main as main_best
from .bfs import main as main_bfs
from .crop import main as main_crop
from .dfs import main as main_dfs
from .jug import main as main_jug
from .meeting import main as main_meeting
from .unification import main as main_unification

# --- Create Your Simple Functions ---
# Now, create user-friendly function names that "point"
# to those imported main functions.

def eightqueen():
    """Runs Lab Program 1"""
    print("--- [Executing Lab 1] ---")
    main_8queen()
    print("--- [Lab 1 Finished] ----")

def alphabeta():
    """Runs Lab Program 2"""
    print("--- [Executing Lab 2] ---")
    main_alphabeta()
    print("--- [Lab 2 Finished] ----")
    
def aostar():
    """Runs Lab Program 3"""
    print("--- [Executing Lab 3] ---")
    main_aostar()
    print("--- [Lab 3 Finished] ----")
def astar():
    """Runs Lab Program 3"""
    print("--- [Executing Lab 3] ---")
    main_astar()
    print("--- [Lab 3 Finished] ----")
def best():
    """Runs Lab Program 3"""
    print("--- [Executing Lab 3] ---")
    main_best()
    print("--- [Lab 3 Finished] ----")
def bfs():
    """Runs Lab Program 3"""
    print("--- [Executing Lab 3] ---")
    main_bfs()
    print("--- [Lab 3 Finished] ----")
def crop():
    """Runs Lab Program 3"""
    print("--- [Executing Lab 3] ---")
    main_crop()
    print("--- [Lab 3 Finished] ----")
def dfs():
    """Runs Lab Program 3"""
    print("--- [Executing Lab 3] ---")
    main_dfs()
    print("--- [Lab 3 Finished] ----")
def jug():
    """Runs Lab Program 3"""
    print("--- [Executing Lab 3] ---")
    main-jug()
    print("--- [Lab 3 Finished] ----")
def meeting():
    """Runs Lab Program 3"""
    print("--- [Executing Lab 3] ---")
    main_meeting()
    print("--- [Lab 3 Finished] ----")
def unification():
    """Runs Lab Program 3"""
    print("--- [Executing Lab 3] ---")
    main_unification()
    print("--- [Lab 3 Finished] ----")
# Add all your other programs here...