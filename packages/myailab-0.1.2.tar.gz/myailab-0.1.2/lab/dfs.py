graph={
    '5':['7','4'],
    '7':['2','8'],
    '4':[],
    '2':['8'],
    '8':[]
}
visited=set()

def dfs(visited, graph, node):
    if node not in visited :
        print(node,end="  ")
        visited.add(node)
        for node in graph[node]:
            dfs(visited, graph, node)

if __name__ == "__main__":
  print("following is dfs")
dfs(visited,graph,'5')


