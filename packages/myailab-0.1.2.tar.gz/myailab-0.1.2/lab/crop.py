facts={
    "soiltype":None,
    'temp':None,
    'water':None,
    'season':None,
}
rules=[
    ({"soiltype":'black','temp':'low','water':'high','season':'monsoon',},'rice'),
    ({"soiltype": 'red', 'temp': 'high', 'water': 'low', 'season': 'summer', }, 'maize'),
    ({"soiltype": 'sandy', 'temp': 'low', 'water': 'high', 'season': 'summer', }, 'ragi'),
    ({"soiltype": 'black', 'temp': 'medium', 'water': 'high', 'season': 'monsoon', }, 'hkj')
]
def inferenceengine(facts,rules):
    recoendations=[]
    for conditions,crops in rules:
        match=True
        for key,values in conditions.items():
            if facts.get(key)!=values:
                match=False
                break
            if match:
               recoendations.append(crops)
        return recoendations
if __name__ == "__main__":
  print('expert system')
#facts['soiltype']=input('enter soiltype').lower()
#facts['temp']=input('enter temp').lower()
#facts['water']=input('enter water').lower()
#facts['season']=input('enter season').lower()
facts['soiltype'] = input('Enter soiltype: ').lower()
facts['temp'] = input('Enter temp: ').lower()
facts['water'] = input('Enter water: ').lower()
facts['season'] = input('Enter season: ').lower()

result=inferenceengine(facts,rules)
if result:
   print('recomendation crops:',','.join(result))


