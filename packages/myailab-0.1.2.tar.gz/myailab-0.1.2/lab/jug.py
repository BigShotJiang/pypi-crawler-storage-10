jug1,jug2,goal=4,3,2
visited=[[False for _ in range(jug2+1)] for _ in range(jug1+1)]
def waterjug(vol1,vol2):
    if(vol1==goal and vol2==0) or (vol2==goal and vol1==0):
        print(vol1 ,'\t',vol2)
        print('solution found')
        return True
    if visited[vol1][vol2]:
        return False
    visited[vol1][vol2]=True
    print(vol1, '\t', vol2)
    return (
            waterjug(jug1, vol2) or
            waterjug(vol1, jug2) or
        waterjug(0 ,vol2)  or
        waterjug(vol1,0 ) or

        waterjug(vol1 + min(vol2,(jug1 - vol1)),vol2 - min(vol2,(jug1 - vol1))) or
        waterjug(vol1 - min(vol1, (jug2 - vol2)), vol2 +min(vol1, (jug2 - vol2)))
    )
if __name__ == "__main__":
  print('steps')
  print('jug1 \t jug2')
waterjug(0, 0)