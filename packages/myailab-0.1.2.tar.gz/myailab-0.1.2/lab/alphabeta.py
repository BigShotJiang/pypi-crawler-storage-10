import math
def alphabeta(depth,inx,is_max,values,alpha,beta,max_depth):
    if depth==max_depth:
        return values[inx]
    if is_max:
        for i in range(2):
            vals=alphabeta(depth+1,inx*2+i,False,values,alpha,beta,max_depth)
            alpha=max(alpha,vals)
            if alpha>=beta:
                break
        return alpha
    else:
        for i in range(2):
            vals=alphabeta(depth+1,inx*2+i,True,values,alpha,beta,max_depth)
            beta=min(beta,vals)
            if beta<=alpha:
                break
        return beta
if __name__ == "__main__":

  vals = [3, 5, 6, 9, 1, 2, 0, -1]

  results=alphabeta(0,0,True,vals,-math.inf,math.inf,3)
  print(f'optimal solution:{results}')
