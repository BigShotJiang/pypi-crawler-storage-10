availability = {
    "Alice":   [("Monday", "10AM", "Room A"), ("Tuesday", "2PM", "Room B")],
    "Bob":     [("Monday", "10AM", "Room A"), ("Wednesday", "11AM", "Room C")],
    "Charlie": [("Monday", "10AM", "Room A"), ("Tuesday", "2PM", "Room B")],
    "David":   [("Monday", "10AM", "Room A"), ("Thursday", "4PM", "Room D")],
    "Eve":     [("Tuesday", "2PM", "Room B")]

}
def schedule(avail):
    slotcount={}
    for person,slots in avail.items():
        for slot in slots:
            slotcount[slot]=slotcount.get(slot,0)+1
        bestslot=max(slotcount,key=slotcount.get)
        participants=[P for P ,slots in avail.items() if bestslot in slots]
        return bestslot,participants
if __name__ == "__main__":
  slot,participants=schedule(availability)
print('meeting schedule succesfully')
print(f'day:{slot[0]}')
print(f'time:{slot[1]}')
print(f'place:{slot[2]}')
print(f'participants:{participants}')



