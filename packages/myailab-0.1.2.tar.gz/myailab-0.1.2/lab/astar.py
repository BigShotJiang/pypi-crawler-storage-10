
from queue import PriorityQueue
def astar(graph,h,start,goal):
    pq = PriorityQueue()
    g={start:0}
    pq.put((h[start],start))
    while not pq.empty():
        f,node = pq.get()
        print(f"Visiting {node} (f:{f},g:{g[node]},h:{h[node]})")
        if node == goal:
            print("goal reached")
            return True
        for n,cost in graph[node]:
            new_g=g[node]+cost
            if n not in g or new_g<g[n]:
               g[n]=new_g
               pq.put((new_g+h[n],n))
    print("not reachable")
    return False
if __name__ == "__main__":
  graph = {
    'A': [('B', 7), ('C', 8)],
    'B': [('D', 9), ('E', 10)],
    'C': [('F', 11), ('G', 12)],
    'D': [], 'E': [], 'F': [], 'G': []
}
  h = {'A':1, 'B':2, 'C':3, 'D':4, 'E':5, 'F':6, 'G':0}

  astar(graph, h, 'A', 'G')


