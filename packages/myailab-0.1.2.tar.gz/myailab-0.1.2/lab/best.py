from queue import PriorityQueue
def best(graph,heurestic,start,goal):
    visited=set()
    pq=PriorityQueue()
    pq.put((heurestic[start],start))
    while not pq.empty():
        h,node=pq.get()
        print(f"visiting:{node}")
        if node==goal:
            print("goal reached")
            return True
        visited.add(node)
        for neighbour in graph[node]:
            if neighbour not in visited:
                pq.put((heurestic[neighbour],neighbour))
    print("goal not reached")
    return False
if __name__ == "__main__":
  graph={
    'A':['B','C'],
    'B':['D','E'],
    'C':['F','G'],
    'D':[],
    'E':[],
    'F':[],
    'G':[]
}
  heurestic={
    'A':1,
    'B':2,
    'C':3,
    'D':4,
    'E':5,
    'F':6,
    'G':0
}
  best(graph,heurestic,'A','G')

