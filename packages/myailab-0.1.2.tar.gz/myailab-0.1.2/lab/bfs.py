def unify(expr1, expr2):
    # Store substitutions (variable replacements)
    subs = {}

    # Both expressions must have same outer symbol
    if expr1[0] != expr2[0]:
        return None

    args1 = expr1[1]
    args2 = expr2[1]

    # Arguments count must match
    if len(args1) != len(args2):
        return None

    # Compare each argument
    for a, b in zip(args1, args2):
        if a == b:
            continue
        elif a.islower():   # if a is a variable (like 'x')
            subs[a] = b
        elif b.islower():   # if b is a variable
            subs[b] = a
        else:
            return None     # can't unify constants or different functions

    return subs
expr1=('knows',['?X','jhon'])
expr2=('knows',['mary','?Y'])
print("Unification:", unify(expr1,expr2 ))
