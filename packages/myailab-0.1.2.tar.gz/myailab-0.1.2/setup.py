import setuptools
import io

# 1. Read the README.md file safely with UTF-8 encoding
try:
    # Use io.open for consistent encoding across different operating systems
    with io.open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()
except FileNotFoundError:
    long_description = ""

# 2. Setup Configuration
setuptools.setup(
    # --- REQUIRED METADATA ---
    name='myailab',  # e.g., 'my-awesome-lib' (used for 'pip install')
    version='0.1.2',  # Start with a low version number
    author='harsha537',
    author_email='harshavardanreddykadapala@gmail.com',
    description='[A short, one-sentence description of your library.]',
    long_description=long_description,
    long_description_content_type="text/markdown",
    url='https://pypi.org/project/myailab/',

    # --- PACKAGE STRUCTURE ---
    # Finds the directory containing __init__.py (e.g., 'my_awesome_lib/')
    packages=setuptools.find_packages(),

    # --- DEPENDENCIES ---
    install_requires=[
        # List external libraries your project needs here:
        # e.g., 'requests>=2.25.1',
        # e.g., 'pandas',
    ],

    # --- CLASSIFIERS & LICENSE ---
    license='MIT',  # Must match the license in your LICENSE file

    # Helps users find your library on PyPI
    classifiers=[
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],

    # --- MINIMUM PYTHON VERSION ---
    python_requires='>=3.8',
)