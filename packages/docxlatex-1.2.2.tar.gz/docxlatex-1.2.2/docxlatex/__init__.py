__version__ = "1.2.2"

from docxlatex.docxlatex import Document
from docxlatex.parser import utils
from docxlatex import cleaners
