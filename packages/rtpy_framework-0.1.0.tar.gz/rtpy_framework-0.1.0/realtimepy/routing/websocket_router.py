"""WebSocket routing utilities."""

# For now, use FastAPI's @app.websocket() directly
# Future: Add custom dispatch, multiplexing, or protocol handlers
