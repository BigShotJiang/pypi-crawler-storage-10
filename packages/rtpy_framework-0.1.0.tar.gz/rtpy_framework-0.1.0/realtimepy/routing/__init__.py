"""Routing helpers."""

# Currently using FastAPI's routing directly
# Future: Add custom WebSocket/HTTP router extensions here
