"""HTTP routing utilities."""

# For now, use FastAPI's @app.get/post/etc. directly
# Future: Add custom REST conventions, auto-generated CRUD
