"""Prometheus metrics integration."""

import logging

logger = logging.getLogger(__name__)


def setup_metrics(app):
    """Setup Prometheus metrics."""
    try:
        from prometheus_fastapi_instrumentator import Instrumentator

        Instrumentator().instrument(app).expose(app)
        logger.info("Prometheus metrics enabled at /metrics")
    except ImportError:
        logger.warning(
            "prometheus-fastapi-instrumentator not installed. "
            "Install with: pip install prometheus-fastapi-instrumentator"
        )
