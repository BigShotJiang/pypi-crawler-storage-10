"""Health check endpoints."""

from fastapi import APIRouter

router = APIRouter(tags=["health"])


@router.get("/health")
async def health_check():
    """Basic health check."""
    return {"status": "ok"}


@router.get("/health/ready")
async def readiness_check():
    """Readiness check for k8s/docker."""
    return {"status": "ready"}


@router.get("/health/live")
async def liveness_check():
    """Liveness check for k8s/docker."""
    return {"status": "alive"}
