"""Tests for state manager."""

import pytest

from realtimepy.core.state import StateManager


@pytest.fixture
def state():
    return StateManager()


def test_join_room(state):
    """Test joining a room."""
    ws = object()
    state.join("general", ws, "alice")

    assert "general" in state.all_rooms()
    assert "alice" in state.users("general")


def test_leave_room(state):
    """Test leaving a room."""
    ws = object()
    state.join("general", ws, "alice")
    state.leave("general", ws)

    assert "alice" not in state.users("general")


def test_multiple_users(state):
    """Test multiple users in a room."""
    ws1, ws2 = object(), object()
    state.join("general", ws1, "alice")
    state.join("general", ws2, "bob")

    users = state.users("general")
    assert len(users) == 2
    assert "alice" in users
    assert "bob" in users
