"""Tests for JWT authentication."""

import jwt

from realtimepy.middleware.jwt_auth import create_access_token


def test_create_token():
    """Test JWT token creation."""
    token = create_access_token({"username": "alice"})
    assert isinstance(token, str)
    assert len(token) > 0


def test_decode_token():
    """Test JWT token decode."""
    from realtimepy.middleware.jwt_auth import ALGORITHM, SECRET_KEY

    token = create_access_token({"username": "alice"})
    payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])

    assert payload["username"] == "alice"
    assert "exp" in payload
