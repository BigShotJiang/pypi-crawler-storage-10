"""Tests for database models."""

import pytest
from tortoise import Tortoise

from realtimepy.db.models import Message, Room, User


@pytest.mark.asyncio
async def test_user_crud():
    """Test user CRUD operations."""
    await Tortoise.init(db_url="sqlite://:memory:", modules={"models": ["realtimepy.db.models"]})
    await Tortoise.generate_schemas()

    # Create
    user = await User.create(username="alice", email="alice@example.com")
    assert user.id is not None

    # Read
    fetched = await User.get(username="alice")
    assert fetched.email == "alice@example.com"

    # Update
    fetched.is_active = False
    await fetched.save()

    # Delete
    await fetched.delete()

    await Tortoise.close_connections()


@pytest.mark.asyncio
async def test_room_message_flow():
    """Test room and message creation."""
    await Tortoise.init(db_url="sqlite://:memory:", modules={"models": ["realtimepy.db.models"]})
    await Tortoise.generate_schemas()

    user = await User.create(username="alice")
    room = await Room.create(name="general")

    msg = await Message.create(room=room, user=user, content="Hello!")

    messages = await Message.filter(room=room)
    assert len(messages) == 1
    assert messages[0].content == "Hello!"

    await Tortoise.close_connections()
