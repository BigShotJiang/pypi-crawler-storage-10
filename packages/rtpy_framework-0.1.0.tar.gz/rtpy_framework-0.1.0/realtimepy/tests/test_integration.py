"""End-to-end integration tests."""

import pytest
from fastapi.testclient import TestClient

from realtimepy import RealtimePyApp


@pytest.fixture
def app():
    app = RealtimePyApp()

    @app.get("/")
    def root():
        return {"hello": "realtimepy"}

    return app


def test_basic_http(app):
    """Test basic HTTP endpoint."""
    client = TestClient(app)
    response = client.get("/")

    assert response.status_code == 200
    assert response.json() == {"hello": "realtimepy"}
