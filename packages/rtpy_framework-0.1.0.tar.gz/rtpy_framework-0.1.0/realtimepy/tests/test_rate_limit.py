"""Tests for rate limiting."""

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from realtimepy.middleware.rate_limit import SimpleRateLimiter


@pytest.fixture
def app():
    app = FastAPI()
    app.add_middleware(SimpleRateLimiter, limit_per_sec=2)

    @app.get("/test")
    def test_endpoint():
        return {"ok": True}

    return app


def test_rate_limit(app):
    """Test rate limiting."""
    client = TestClient(app)

    # First 2 requests should succeed
    assert client.get("/test").status_code == 200
    assert client.get("/test").status_code == 200

    # 3rd request within 1 second should be rate limited
    response = client.get("/test")
    assert response.status_code == 429
