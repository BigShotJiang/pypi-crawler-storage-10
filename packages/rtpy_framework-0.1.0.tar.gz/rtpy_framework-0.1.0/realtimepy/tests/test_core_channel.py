"""Tests for async channel."""

import pytest

from realtimepy.core.channel import AsyncChannel


@pytest.mark.asyncio
async def test_pub_sub():
    """Test publish/subscribe."""
    channel = AsyncChannel()
    received = []

    async def callback(msg):
        received.append(msg)

    await channel.subscribe("test", callback)
    await channel.publish("test", "hello")

    # Give async tasks time to run
    import asyncio

    await asyncio.sleep(0.1)

    assert "hello" in received


@pytest.mark.asyncio
async def test_unsubscribe():
    """Test unsubscribe."""
    channel = AsyncChannel()
    received = []

    async def callback(msg):
        received.append(msg)

    await channel.subscribe("test", callback)
    await channel.unsubscribe("test", callback)
    await channel.publish("test", "hello")

    import asyncio

    await asyncio.sleep(0.1)

    assert len(received) == 0
