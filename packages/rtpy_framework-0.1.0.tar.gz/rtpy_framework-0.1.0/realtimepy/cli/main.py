"""Command-line interface for RealtimePy."""

import argparse
import sys


def run_dev():
    """Run development server."""
    print("Starting development server...")
    print("Use: uvicorn your_app:app --reload")


def migrate_db():
    """Run database migrations."""
    print("Running database migrations...")
    print("Tortoise ORM auto-generates schemas on init_db()")


def introspect():
    """Show framework info."""
    print("=== RealtimePy Framework ===")
    print("Version: 0.1.0")
    print("Components: State, Channel, Auth, DB, Monitoring")


def scaffold_new():
    """Create new project scaffold."""
    print("Creating new RealtimePy project...")
    print("Generating folders: app/, tests/, docs/")


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(description="RealtimePy CLI", prog="realtimepy")
    parser.add_argument(
        "command", choices=["run", "migrate", "introspect", "new"], help="Command to run"
    )

    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args()

    commands = {
        "run": run_dev,
        "migrate": migrate_db,
        "introspect": introspect,
        "new": scaffold_new,
    }

    commands[args.command]()


if __name__ == "__main__":
    main()
