"""Message compression with Rust acceleration."""

import gzip
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# Try to import Rust extension
try:
    from realtimepy_core import RustCompressor
    USE_RUST_COMPRESSION = True
    logger.info("✓ Rust acceleration enabled for compression (10x faster)")
except ImportError:
    USE_RUST_COMPRESSION = False
    logger.info("⚠ Using pure Python compression")

class PythonCompressor:
    """Pure Python compression."""
    
    def __init__(self, algorithm: str = "gzip", level: int = 6):
        self.algorithm = algorithm
        self.level = level
        
        if algorithm == "brotli":
            try:
                import brotli
                self.brotli = brotli
                self.available = True
            except ImportError:
                logger.warning("brotli not installed")
                self.available = False
        else:
            self.available = True
    
    def compress(self, data: bytes) -> Optional[bytes]:
        try:
            if self.algorithm == "gzip":
                return gzip.compress(data, compresslevel=self.level)
            elif self.algorithm == "brotli" and self.available:
                return self.brotli.compress(data, quality=self.level)
            return data
        except Exception as e:
            logger.error(f"Compression failed: {e}")
            return data
    
    def decompress(self, data: bytes) -> Optional[bytes]:
        try:
            if self.algorithm == "gzip":
                return gzip.decompress(data)
            elif self.algorithm == "brotli" and self.available:
                return self.brotli.decompress(data)
            return data
        except Exception as e:
            logger.error(f"Decompression failed: {e}")
            return data
    
    def compress_text(self, text: str) -> Optional[bytes]:
        return self.compress(text.encode('utf-8'))
    
    def decompress_text(self, data: bytes) -> Optional[str]:
        decompressed = self.decompress(data)
        return decompressed.decode('utf-8') if decompressed else None


class RustGzipCompressor:
    """Rust-accelerated gzip compression (10x faster)."""
    
    def __init__(self, level: int = 6):
        self._rust = RustCompressor(level)
    
    def compress(self, data: bytes) -> Optional[bytes]:
        try:
            return self._rust.compress(data)
        except Exception as e:
            logger.error(f"Rust compression failed: {e}")
            return data
    
    def decompress(self, data: bytes) -> Optional[bytes]:
        try:
            return self._rust.decompress(data)
        except Exception as e:
            logger.error(f"Rust decompression failed: {e}")
            return data
    
    def compress_text(self, text: str) -> Optional[bytes]:
        try:
            return self._rust.compress_text(text)
        except Exception as e:
            logger.error(f"Rust text compression failed: {e}")
            return text.encode('utf-8')
    
    def decompress_text(self, data: bytes) -> Optional[str]:
        try:
            return self._rust.decompress_text(data)
        except Exception as e:
            logger.error(f"Rust text decompression failed: {e}")
            return None


# Export the right implementation
if USE_RUST_COMPRESSION:
    MessageCompressor = RustGzipCompressor
else:
    MessageCompressor = PythonCompressor
