"""RealtimePy - Production-ready real-time web framework for Python."""

from .app import RealtimePyApp

# Core components
try:
    from .core.state import StateManager
except ImportError:
    StateManager = None

# Persistence
try:
    from .persistence.history import InMemoryHistory, DatabaseHistory, MessageHistory
except ImportError:
    InMemoryHistory = None
    DatabaseHistory = None
    MessageHistory = None

# Streaming
try:
    from .streaming.sse import SSEManager, sse_endpoint
except ImportError:
    SSEManager = None
    sse_endpoint = None

# GraphQL
try:
    from .graphql.subscriptions import GraphQLSubscriptionManager
except ImportError:
    GraphQLSubscriptionManager = None

# Uploads
try:
    from .uploads.handler import FileUploadHandler
except ImportError:
    FileUploadHandler = None

# Serialization
try:
    from .serialization.protobuf import ProtobufSerializer
except ImportError:
    ProtobufSerializer = None

# Compression
try:
    from .compression.compressor import MessageCompressor
except ImportError:
    MessageCompressor = None

# Errors
try:
    from .errors.exceptions import (
        RealtimePyError,
        StateError,
        ChannelError,
        AuthenticationError,
        ValidationError,
    )
except ImportError:
    RealtimePyError = None
    StateError = None
    ChannelError = None
    AuthenticationError = None
    ValidationError = None

# Validation
try:
    from .validation.validators import (
        validate_username,
        validate_room_name,
        validate_message,
    )
except ImportError:
    validate_username = None
    validate_room_name = None
    validate_message = None

# Middleware
try:
    from .middleware.jwt_auth import JWTBearer, create_access_token
except ImportError:
    JWTBearer = None
    create_access_token = None

__version__ = "0.1.0"
__all__ = [
    # Core
    "RealtimePyApp",
    "StateManager",
    
    # Persistence
    "InMemoryHistory",
    "DatabaseHistory",
    "MessageHistory",
    
    # Streaming
    "SSEManager",
    "sse_endpoint",
    
    # GraphQL
    "GraphQLSubscriptionManager",
    
    # Uploads
    "FileUploadHandler",
    
    # Serialization
    "ProtobufSerializer",
    
    # Compression
    "MessageCompressor",
    
    # Errors
    "RealtimePyError",
    "StateError",
    "ChannelError",
    "AuthenticationError",
    "ValidationError",
    
    # Validation
    "validate_username",
    "validate_room_name",
    "validate_message",
    
    # Middleware
    "JWTBearer",
    "create_access_token",
]
