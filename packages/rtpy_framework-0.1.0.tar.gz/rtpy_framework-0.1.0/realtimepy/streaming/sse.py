"""Server-Sent Events (SSE) implementation."""

import asyncio
import json
from typing import AsyncGenerator, Optional
from fastapi import Request
from fastapi.responses import StreamingResponse
import logging

logger = logging.getLogger(__name__)


class SSEManager:
    """Manages Server-Sent Events connections."""
    
    def __init__(self):
        self.connections = set()
    
    async def connect(self, request: Request) -> AsyncGenerator[str, None]:
        """Create SSE connection."""
        queue = asyncio.Queue()
        self.connections.add(queue)
        
        try:
            while True:
                # Check if client disconnected
                if await request.is_disconnected():
                    break
                
                # Wait for message with timeout
                try:
                    message = await asyncio.wait_for(queue.get(), timeout=30.0)
                    yield f"data: {json.dumps(message)}\n\n"
                except asyncio.TimeoutError:
                    # Send keepalive
                    yield ": keepalive\n\n"
        
        finally:
            self.connections.discard(queue)
    
    async def broadcast(self, message: dict):
        """Broadcast message to all SSE connections."""
        disconnected = set()
        
        for queue in self.connections:
            try:
                await queue.put(message)
            except Exception as e:
                logger.error(f"Failed to send to connection: {e}")
                disconnected.add(queue)
        
        # Clean up disconnected
        self.connections -= disconnected


def sse_endpoint(manager: SSEManager):
    """Create SSE endpoint."""
    async def endpoint(request: Request):
        return StreamingResponse(
            manager.connect(request),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",
            }
        )
    return endpoint
