"""Main application class."""

from fastapi import FastAPI

from .core.extensions import ExtensionManager
from .core.state import StateManager


class RealtimePyApp(FastAPI):
    """RealtimePy application - extends FastAPI with real-time features."""

    def __init__(self, config: dict | None = None, **kwargs):
        super().__init__(**kwargs)
        self.config = config or {}
        # Use different name to avoid conflict with FastAPI's state
        self.state_manager = StateManager()
        self.extension_manager = ExtensionManager()

    @property
    def rtpy_state(self):
        """Access RealtimePy state manager."""
        return self.state_manager

    @property
    def extensions(self):
        """Access extension manager."""
        return self.extension_manager
