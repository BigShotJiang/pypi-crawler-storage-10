"""GraphQL subscription support."""

from .subscriptions import GraphQLSubscriptionManager

__all__ = ["GraphQLSubscriptionManager"]
