"""GraphQL subscription implementation."""

import asyncio
import json
from typing import Dict, Set, Callable, Any
from fastapi import WebSocket
import logging

logger = logging.getLogger(__name__)


class GraphQLSubscriptionManager:
    """Manages GraphQL subscriptions over WebSocket."""
    
    def __init__(self):
        self.subscriptions: Dict[str, Set[WebSocket]] = {}
        self.connection_subs: Dict[WebSocket, Set[str]] = {}
    
    async def handle_connection(self, websocket: WebSocket):
        """Handle GraphQL subscription connection."""
        await websocket.accept()
        self.connection_subs[websocket] = set()
        
        try:
            while True:
                message = await websocket.receive_json()
                await self._handle_message(websocket, message)
        
        except Exception as e:
            logger.error(f"Subscription error: {e}")
        
        finally:
            await self._cleanup_connection(websocket)
    
    async def _handle_message(self, websocket: WebSocket, message: dict):
        """Handle GraphQL subscription message."""
        msg_type = message.get("type")
        
        if msg_type == "connection_init":
            await websocket.send_json({"type": "connection_ack"})
        
        elif msg_type == "start":
            sub_id = message.get("id")
            query = message.get("payload", {}).get("query")
            
            # Extract subscription name from query
            # In real implementation, parse GraphQL query
            sub_name = self._extract_subscription_name(query)
            
            self.subscriptions.setdefault(sub_name, set()).add(websocket)
            self.connection_subs[websocket].add(sub_name)
            
            logger.info(f"Started subscription {sub_name} for {sub_id}")
        
        elif msg_type == "stop":
            sub_id = message.get("id")
            # Remove subscription
            logger.info(f"Stopped subscription {sub_id}")
    
    def _extract_subscription_name(self, query: str) -> str:
        """Extract subscription name from GraphQL query."""
        # Simplified extraction
        if "subscription" in query.lower():
            parts = query.split()
            for i, part in enumerate(parts):
                if part.lower() == "subscription" and i + 1 < len(parts):
                    return parts[i + 1].strip("{")
        return "unknown"
    
    async def publish(self, subscription: str, data: dict):
        """Publish data to subscription."""
        connections = self.subscriptions.get(subscription, set())
        
        for ws in list(connections):
            try:
                await ws.send_json({
                    "type": "data",
                    "payload": {"data": data}
                })
            except Exception as e:
                logger.error(f"Failed to publish: {e}")
                connections.discard(ws)
    
    async def _cleanup_connection(self, websocket: WebSocket):
        """Clean up connection subscriptions."""
        subs = self.connection_subs.pop(websocket, set())
        
        for sub_name in subs:
            if sub_name in self.subscriptions:
                self.subscriptions[sub_name].discard(websocket)
