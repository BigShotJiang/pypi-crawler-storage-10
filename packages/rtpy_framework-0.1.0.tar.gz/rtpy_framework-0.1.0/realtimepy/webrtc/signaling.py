"""WebRTC signaling server for peer-to-peer connections."""

import json
import logging
from typing import Dict, Set
from fastapi import WebSocket
from datetime import datetime

logger = logging.getLogger(__name__)


class WebRTCSignalingManager:
    """
    Manages WebRTC signaling for voice, video, and screen sharing.
    Handles SDP offers/answers and ICE candidates exchange.
    """
    
    def __init__(self):
        # Room -> Set of connections
        self.rooms: Dict[str, Set[WebSocket]] = {}
        # WebSocket -> user_id mapping
        self.connections: Dict[WebSocket, str] = {}
    
    async def handle_connection(self, websocket: WebSocket, room: str, user_id: str):
        """Handle WebRTC signaling connection."""
        await websocket.accept()
        
        # Add to room
        if room not in self.rooms:
            self.rooms[room] = set()
        
        self.rooms[room].add(websocket)
        self.connections[websocket] = user_id
        
        # Notify others about new peer
        await self._broadcast(room, {
            "type": "peer_joined",
            "userId": user_id,
            "timestamp": datetime.now().isoformat()
        }, exclude=websocket)
        
        try:
            while True:
                message = await websocket.receive_json()
                await self._handle_message(websocket, room, user_id, message)
        
        except Exception as e:
            logger.error(f"WebRTC signaling error: {e}")
        
        finally:
            await self._cleanup(websocket, room, user_id)
    
    async def _handle_message(self, websocket: WebSocket, room: str, user_id: str, message: dict):
        """Handle signaling messages."""
        msg_type = message.get("type")
        
        if msg_type == "offer":
            # Forward SDP offer to target peer
            target_id = message.get("targetId")
            await self._send_to_peer(room, target_id, {
                "type": "offer",
                "sdp": message.get("sdp"),
                "fromUserId": user_id
            })
        
        elif msg_type == "answer":
            # Forward SDP answer to target peer
            target_id = message.get("targetId")
            await self._send_to_peer(room, target_id, {
                "type": "answer",
                "sdp": message.get("sdp"),
                "fromUserId": user_id
            })
        
        elif msg_type == "ice_candidate":
            # Forward ICE candidate to target peer
            target_id = message.get("targetId")
            await self._send_to_peer(room, target_id, {
                "type": "ice_candidate",
                "candidate": message.get("candidate"),
                "fromUserId": user_id
            })
        
        elif msg_type == "start_screen_share":
            # Notify room about screen sharing
            await self._broadcast(room, {
                "type": "screen_share_started",
                "userId": user_id
            }, exclude=websocket)
        
        elif msg_type == "stop_screen_share":
            # Notify room about screen sharing stopped
            await self._broadcast(room, {
                "type": "screen_share_stopped",
                "userId": user_id
            }, exclude=websocket)
    
    async def _send_to_peer(self, room: str, target_id: str, message: dict):
        """Send message to specific peer."""
        for ws in self.rooms.get(room, set()):
            if self.connections.get(ws) == target_id:
                try:
                    await ws.send_json(message)
                except Exception as e:
                    logger.error(f"Failed to send to peer {target_id}: {e}")
    
    async def _broadcast(self, room: str, message: dict, exclude=None):
        """Broadcast message to all peers in room."""
        for ws in self.rooms.get(room, set()):
            if ws != exclude:
                try:
                    await ws.send_json(message)
                except Exception as e:
                    logger.error(f"Broadcast failed: {e}")
    
    async def _cleanup(self, websocket: WebSocket, room: str, user_id: str):
        """Clean up connection."""
        if room in self.rooms:
            self.rooms[room].discard(websocket)
        
        if websocket in self.connections:
            del self.connections[websocket]
        
        # Notify others
        await self._broadcast(room, {
            "type": "peer_left",
            "userId": user_id
        })
