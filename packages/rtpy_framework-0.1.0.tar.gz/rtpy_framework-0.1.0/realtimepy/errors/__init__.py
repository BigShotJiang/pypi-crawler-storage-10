"""Custom exceptions and error handlers."""

from .exceptions import (
    RealtimePyError,
    StateError,
    ChannelError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
)
from .handlers import setup_error_handlers

__all__ = [
    "RealtimePyError",
    "StateError",
    "ChannelError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
    "setup_error_handlers",
]
