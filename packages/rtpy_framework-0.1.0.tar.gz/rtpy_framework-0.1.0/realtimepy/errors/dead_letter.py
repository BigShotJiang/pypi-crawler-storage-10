"""Dead letter queue for failed messages."""

import asyncio
import logging
from typing import Any, Dict, List
from datetime import datetime
from collections import deque

logger = logging.getLogger(__name__)


class DeadLetterQueue:
    """Queue for messages that failed processing."""
    
    def __init__(self, max_size: int = 10000):
        self.max_size = max_size
        self.queue: deque = deque(maxlen=max_size)
        self.stats = {
            "total_failed": 0,
            "total_retried": 0,
            "total_success": 0,
        }
    
    def add(self, message: Any, error: Exception, context: Dict = None):
        """Add failed message to queue."""
        entry = {
            "message": message,
            "error": str(error),
            "error_type": error.__class__.__name__,
            "context": context or {},
            "timestamp": datetime.now().isoformat(),
            "retry_count": 0,
        }
        
        self.queue.append(entry)
        self.stats["total_failed"] += 1
        
        logger.error(
            f"Message added to dead letter queue: {error}",
            extra={"context": context}
        )
    
    async def retry_failed(self, handler, max_retries: int = 3) -> int:
        """Retry failed messages."""
        retried = 0
        failed_again = []
        
        while self.queue and retried < len(self.queue):
            entry = self.queue.popleft()
            
            if entry["retry_count"] >= max_retries:
                logger.warning(f"Message exceeded max retries: {entry}")
                continue
            
            try:
                await handler(entry["message"])
                self.stats["total_success"] += 1
                retried += 1
            except Exception as e:
                entry["retry_count"] += 1
                entry["last_error"] = str(e)
                failed_again.append(entry)
                logger.error(f"Retry failed: {e}")
        
        # Re-add failed messages
        for entry in failed_again:
            self.queue.append(entry)
        
        self.stats["total_retried"] += retried
        return retried
    
    def get_failed_messages(self, limit: int = 100) -> List[Dict]:
        """Get failed messages."""
        return list(self.queue)[:limit]
    
    def clear(self):
        """Clear dead letter queue."""
        count = len(self.queue)
        self.queue.clear()
        logger.info(f"Cleared {count} messages from dead letter queue")
        return count
    
    def get_stats(self) -> Dict:
        """Get queue statistics."""
        return {
            **self.stats,
            "current_queue_size": len(self.queue),
            "max_size": self.max_size,
        }
