"""Custom exception types."""

from typing import Any, Optional


class RealtimePyError(Exception):
    """Base exception for RealtimePy framework."""
    
    def __init__(
        self,
        message: str,
        status_code: int = 500,
        details: Optional[dict] = None
    ):
        self.message = message
        self.status_code = status_code
        self.details = details or {}
        super().__init__(self.message)


class StateError(RealtimePyError):
    """Error in state management."""
    
    def __init__(self, message: str, details: Optional[dict] = None):
        super().__init__(message, status_code=500, details=details)


class ChannelError(RealtimePyError):
    """Error in pub/sub channel."""
    
    def __init__(self, message: str, details: Optional[dict] = None):
        super().__init__(message, status_code=500, details=details)


class AuthenticationError(RealtimePyError):
    """Authentication failed."""
    
    def __init__(self, message: str = "Authentication failed", details: Optional[dict] = None):
        super().__init__(message, status_code=401, details=details)


class RateLimitError(RealtimePyError):
    """Rate limit exceeded."""
    
    def __init__(self, message: str = "Too many requests", details: Optional[dict] = None):
        super().__init__(message, status_code=429, details=details)


class ValidationError(RealtimePyError):
    """Input validation failed."""
    
    def __init__(self, message: str, field: Optional[str] = None, details: Optional[dict] = None):
        details = details or {}
        if field:
            details["field"] = field
        super().__init__(message, status_code=422, details=details)


class WebSocketError(RealtimePyError):
    """WebSocket connection error."""
    
    def __init__(self, message: str, details: Optional[dict] = None):
        super().__init__(message, status_code=400, details=details)


class DatabaseError(RealtimePyError):
    """Database operation error."""
    
    def __init__(self, message: str, details: Optional[dict] = None):
        super().__init__(message, status_code=500, details=details)
