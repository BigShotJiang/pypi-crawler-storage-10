"""Database connection and management."""

import logging

from tortoise import Tortoise

logger = logging.getLogger(__name__)


async def init_db(db_url: str = "sqlite://db.sqlite3") -> None:
    """Initialize database connection."""
    try:
        await Tortoise.init(db_url=db_url, modules={"models": ["realtimepy.db.models"]})
        await Tortoise.generate_schemas()
        logger.info("Database initialized successfully")
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
        raise


async def close_db() -> None:
    """Close database connections."""
    try:
        await Tortoise.close_connections()
        logger.info("Database connections closed")
    except Exception as e:
        logger.error(f"Error closing database: {e}")
