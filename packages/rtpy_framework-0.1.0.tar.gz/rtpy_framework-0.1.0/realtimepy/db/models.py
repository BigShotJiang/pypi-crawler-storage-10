"""Database models using Tortoise ORM."""

from tortoise import fields, models


class User(models.Model):
    """User model."""

    id = fields.IntField(pk=True)
    username = fields.CharField(max_length=50, unique=True)
    email = fields.CharField(max_length=255, unique=True, null=True)
    password_hash = fields.CharField(max_length=255, null=True)
    joined_at = fields.DatetimeField(auto_now_add=True)
    is_active = fields.BooleanField(default=True)

    class Meta:
        table = "users"

    def __str__(self):
        return self.username


class Room(models.Model):
    """Room model."""

    id = fields.IntField(pk=True)
    name = fields.CharField(max_length=50, unique=True)
    description = fields.TextField(null=True)
    created_at = fields.DatetimeField(auto_now_add=True)
    is_active = fields.BooleanField(default=True)

    class Meta:
        table = "rooms"

    def __str__(self):
        return self.name


class Message(models.Model):
    """Message model."""

    id = fields.IntField(pk=True)
    room = fields.ForeignKeyField("models.Room", related_name="messages")
    user = fields.ForeignKeyField("models.User", related_name="messages")
    content = fields.TextField()
    timestamp = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "messages"
        ordering = ["-timestamp"]

    def __str__(self):
        return f"{self.user.username}: {self.content[:50]}"
