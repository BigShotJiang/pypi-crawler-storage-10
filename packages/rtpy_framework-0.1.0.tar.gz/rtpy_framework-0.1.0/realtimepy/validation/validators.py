"""Input validators and sanitizers."""

import re
import html
from typing import Optional
from ..errors.exceptions import ValidationError


def validate_username(username: str) -> str:
    """Validate and sanitize username."""
    if not username or not isinstance(username, str):
        raise ValidationError("Username is required", field="username")
    
    # Strip whitespace
    username = username.strip()
    
    # Length check
    if len(username) < 2:
        raise ValidationError("Username must be at least 2 characters", field="username")
    
    if len(username) > 50:
        raise ValidationError("Username must be less than 50 characters", field="username")
    
    # Alphanumeric check (allow underscores and hyphens)
    if not re.match(r'^[a-zA-Z0-9_-]+$', username):
        raise ValidationError(
            "Username can only contain letters, numbers, underscores, and hyphens",
            field="username"
        )
    
    return username


def validate_room_name(room: str) -> str:
    """Validate and sanitize room name."""
    if not room or not isinstance(room, str):
        raise ValidationError("Room name is required", field="room")
    
    room = room.strip()
    
    if len(room) < 1:
        raise ValidationError("Room name must be at least 1 character", field="room")
    
    if len(room) > 100:
        raise ValidationError("Room name must be less than 100 characters", field="room")
    
    # Allow alphanumeric, spaces, underscores, hyphens
    if not re.match(r'^[a-zA-Z0-9_ -]+$', room):
        raise ValidationError(
            "Room name can only contain letters, numbers, spaces, underscores, and hyphens",
            field="room"
        )
    
    return room


def validate_message(message: str, max_length: int = 5000) -> str:
    """Validate and sanitize message content."""
    if not message or not isinstance(message, str):
        raise ValidationError("Message is required", field="message")
    
    message = message.strip()
    
    if len(message) < 1:
        raise ValidationError("Message cannot be empty", field="message")
    
    if len(message) > max_length:
        raise ValidationError(
            f"Message must be less than {max_length} characters",
            field="message"
        )
    
    # Sanitize HTML to prevent XSS
    message = sanitize_html(message)
    
    return message


def sanitize_html(text: str) -> str:
    """Sanitize HTML to prevent XSS attacks."""
    # Escape HTML entities
    text = html.escape(text)
    
    # Remove potentially dangerous patterns
    dangerous_patterns = [
        r'<script.*?</script>',
        r'javascript:',
        r'on\w+\s*=',  # Event handlers like onclick=
        r'<iframe.*?</iframe>',
    ]
    
    for pattern in dangerous_patterns:
        text = re.sub(pattern, '', text, flags=re.IGNORECASE)
    
    return text


def sanitize_input(text: str, allow_html: bool = False) -> str:
    """General input sanitization."""
    if not text:
        return ""
    
    # Strip whitespace
    text = text.strip()
    
    # Remove null bytes
    text = text.replace('\x00', '')
    
    # Sanitize HTML if not allowed
    if not allow_html:
        text = sanitize_html(text)
    
    return text


def validate_email(email: str) -> str:
    """Validate email address."""
    email = email.strip().lower()
    
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    
    if not re.match(email_pattern, email):
        raise ValidationError("Invalid email address", field="email")
    
    if len(email) > 255:
        raise ValidationError("Email too long", field="email")
    
    return email


def validate_json_message(data: dict, required_fields: list = None) -> dict:
    """Validate JSON message structure."""
    if not isinstance(data, dict):
        raise ValidationError("Message must be a JSON object")
    
    if required_fields:
        for field in required_fields:
            if field not in data:
                raise ValidationError(f"Missing required field: {field}", field=field)
    
    return data
