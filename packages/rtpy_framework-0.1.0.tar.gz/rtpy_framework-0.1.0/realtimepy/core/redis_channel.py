"""Redis-based pub/sub channel for distributed deployments."""

import logging
from typing import Any, Callable

logger = logging.getLogger(__name__)


class RedisChannel:
    """Redis pub/sub adapter."""

    def __init__(self, url: str = "redis://localhost"):
        self.url = url
        self.redis = None
        self._init_redis()

    def _init_redis(self):
        """Initialize Redis connection."""
        try:
            import aioredis

            self.redis = aioredis.from_url(self.url)
        except ImportError:
            logger.error("aioredis not installed. Install with: pip install aioredis")
            raise

    async def publish(self, topic: str, message: str) -> None:
        """Publish message to Redis topic."""
        if self.redis:
            await self.redis.publish(topic, message)

    async def subscribe(self, topic: str, callback: Callable[[Any], None]) -> None:
        """Subscribe to Redis topic."""
        if not self.redis:
            return

        pubsub = self.redis.pubsub()
        await pubsub.subscribe(topic)

        async for msg in pubsub.listen():
            if msg and msg["type"] == "message":
                await callback(msg["data"])
