"""Extension/plugin system."""

import logging
from typing import Any, List

logger = logging.getLogger(__name__)


class ExtensionManager:
    """Manages framework extensions/plugins."""

    def __init__(self):
        self.plugins: List[Any] = []

    def register(self, plugin: Any) -> None:
        """Register a plugin."""
        self.plugins.append(plugin)
        logger.info(f"Registered plugin: {plugin.__class__.__name__}")

    def dispatch(self, event: str, *args, **kwargs) -> None:
        """Dispatch event to all plugins."""
        for plugin in self.plugins:
            handler = getattr(plugin, f"on_{event}", None)
            if handler and callable(handler):
                try:
                    handler(*args, **kwargs)
                except Exception as e:
                    logger.error(f"Plugin {plugin.__class__.__name__} failed on {event}: {e}")
