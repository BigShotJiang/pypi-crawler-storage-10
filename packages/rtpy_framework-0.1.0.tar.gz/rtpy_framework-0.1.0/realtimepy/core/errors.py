"""Custom exceptions and error handlers."""


class RealtimePyError(Exception):
    """Base exception for RealtimePy."""

    pass


class StateError(RealtimePyError):
    """Error in state management."""

    pass


class ChannelError(RealtimePyError):
    """Error in pub/sub channel."""

    pass


class AuthenticationError(RealtimePyError):
    """Authentication failed."""

    pass
