"""State manager with optional Rust acceleration."""

from typing import Any, Dict, Set
import logging

logger = logging.getLogger(__name__)

# Try to import Rust extension
try:
    from realtimepy_core import RustStateManager, is_rust_available
    USE_RUST = is_rust_available()
    logger.info("✓ Rust acceleration enabled for state management")
except ImportError:
    USE_RUST = False
    logger.info("⚠ Using pure Python state manager (install Rust for 10x performance)")


class PythonStateManager:
    """Pure Python fallback state manager."""

    def __init__(self):
        self.rooms: Dict[str, Set[Any]] = {}
        self.usernames: Dict[Any, str] = {}
        self.room_users: Dict[str, Set[str]] = {}
        self._next_id = 0

    def join(self, room: str, ws: Any, username: str) -> None:
        try:
            self.rooms.setdefault(room, set()).add(ws)
            self.usernames[ws] = username
            self.room_users.setdefault(room, set()).add(username)
            logger.info(f"User {username} joined room {room}")
        except Exception as e:
            logger.error(f"Error joining room: {e}")
            raise

    def leave(self, room: str, ws: Any) -> None:
        try:
            username = self.usernames.pop(ws, None)
            if room in self.rooms:
                self.rooms[room].discard(ws)
            if username and room in self.room_users:
                self.room_users[room].discard(username)
            if username:
                logger.info(f"User {username} left room {room}")
        except Exception as e:
            logger.error(f"Error leaving room: {e}")

    def users(self, room: str) -> list[str]:
        return list(self.room_users.get(room, set()))

    def all_rooms(self) -> list[str]:
        return list(self.rooms.keys())

    def get_connections(self, room: str) -> Set[Any]:
        return self.rooms.get(room, set())


# Wrapper for Rust implementation with Python-compatible interface
class RustStateManagerWrapper:
    """Wrapper around Rust state manager for Python compatibility."""
    
    def __init__(self):
        self._rust = RustStateManager()
        self._ws_to_id: Dict[Any, int] = {}
        self._id_to_ws: Dict[int, Any] = {}
    
    def join(self, room: str, ws: Any, username: str) -> None:
        conn_id = self._rust.join(room, username)
        self._ws_to_id[ws] = conn_id
        self._id_to_ws[conn_id] = ws
    
    def leave(self, room: str, ws: Any) -> None:
        if ws in self._ws_to_id:
            conn_id = self._ws_to_id.pop(ws)
            self._id_to_ws.pop(conn_id, None)
            self._rust.leave(room, conn_id)
    
    def users(self, room: str) -> list[str]:
        return self._rust.users(room)
    
    def all_rooms(self) -> list[str]:
        return self._rust.all_rooms()
    
    def get_connections(self, room: str) -> Set[Any]:
        conn_ids = self._rust.get_connections(room)
        return {self._id_to_ws.get(cid) for cid in conn_ids if cid in self._id_to_ws}


# Export the right implementation
if USE_RUST:
    StateManager = RustStateManagerWrapper
else:
    StateManager = PythonStateManager
