"""Async pub/sub channel implementation."""

import asyncio
import logging
from typing import Any, Callable, Dict, Set

logger = logging.getLogger(__name__)


class AsyncChannel:
    """Async pub/sub for real-time messaging."""

    def __init__(self, dead_letter_cb: Callable | None = None):
        self.subscribers: Dict[str, Set[Callable]] = {}
        self.dead_letter_cb = dead_letter_cb

    async def subscribe(self, topic: str, callback: Callable[[Any], None]) -> None:
        """Subscribe to a topic."""
        self.subscribers.setdefault(topic, set()).add(callback)
        logger.debug(f"Subscribed to topic: {topic}")

    async def unsubscribe(self, topic: str, callback: Callable[[Any], None]) -> None:
        """Unsubscribe from a topic."""
        self.subscribers.get(topic, set()).discard(callback)
        logger.debug(f"Unsubscribed from topic: {topic}")

    async def publish(self, topic: str, message: Any) -> None:
        """Publish message to topic."""
        callbacks = self.subscribers.get(topic, set())
        logger.debug(f"Publishing to {len(callbacks)} subscribers on topic: {topic}")

        for callback in callbacks:
            asyncio.create_task(self._dispatch(callback, message))

    async def _dispatch(self, callback: Callable, message: Any) -> None:
        """Dispatch message to callback with error handling."""
        try:
            await callback(message)
        except Exception as e:
            logger.error(f"Callback failed: {e}")
            if self.dead_letter_cb:
                await self.dead_letter_cb(message)
