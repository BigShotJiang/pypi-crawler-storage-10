"""File upload validators."""

import os
import re
from typing import List


def is_safe_filename(filename: str) -> bool:
    """
    Check if filename is safe (no path traversal, special chars).
    
    Args:
        filename: The filename to validate
        
    Returns:
        True if safe, False otherwise
    """
    if not filename:
        return False
    
    # Remove any path components
    filename = os.path.basename(filename)
    
    # Check for path traversal attempts
    if ".." in filename or "/" in filename or "\\" in filename:
        return False
    
    # Check for null bytes
    if "\x00" in filename:
        return False
    
    # Allow alphanumeric, dots, hyphens, underscores
    if not re.match(r'^[a-zA-Z0-9._-]+$', filename):
        return False
    
    # Must have at least one character before extension
    if filename.startswith('.'):
        return False
    
    return True


def get_file_extension(filename: str) -> str:
    """
    Get file extension in lowercase.
    
    Args:
        filename: The filename
        
    Returns:
        File extension without dot (e.g., 'jpg', 'pdf')
    """
    if not filename or '.' not in filename:
        return ""
    
    return filename.rsplit('.', 1)[1].lower()


def validate_file_type(extension: str, allowed_extensions: List[str]) -> bool:
    """
    Validate file type against allowed extensions.
    
    Args:
        extension: File extension (without dot)
        allowed_extensions: List of allowed extensions
        
    Returns:
        True if allowed, False otherwise
    """
    if not extension:
        return False
    
    return extension.lower() in [ext.lower() for ext in allowed_extensions]


def validate_file_size(size: int, max_size: int) -> bool:
    """
    Validate file size.
    
    Args:
        size: File size in bytes
        max_size: Maximum allowed size in bytes
        
    Returns:
        True if within limit, False otherwise
    """
    return 0 < size <= max_size


def get_mime_type(extension: str) -> str:
    """
    Get MIME type from file extension.
    
    Args:
        extension: File extension
        
    Returns:
        MIME type string
    """
    mime_types = {
        # Images
        "jpg": "image/jpeg",
        "jpeg": "image/jpeg",
        "png": "image/png",
        "gif": "image/gif",
        "webp": "image/webp",
        "svg": "image/svg+xml",
        
        # Documents
        "pdf": "application/pdf",
        "doc": "application/msword",
        "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "txt": "text/plain",
        "md": "text/markdown",
        "csv": "text/csv",
        "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        
        # Video
        "mp4": "video/mp4",
        "webm": "video/webm",
        "mov": "video/quicktime",
        "avi": "video/x-msvideo",
        
        # Audio
        "mp3": "audio/mpeg",
        "wav": "audio/wav",
        "ogg": "audio/ogg",
        "m4a": "audio/mp4",
        
        # Archives
        "zip": "application/zip",
        "tar": "application/x-tar",
        "gz": "application/gzip",
        "rar": "application/x-rar-compressed",
    }
    
    return mime_types.get(extension.lower(), "application/octet-stream")


def is_image(extension: str) -> bool:
    """Check if file is an image."""
    return extension.lower() in ["jpg", "jpeg", "png", "gif", "webp", "svg"]


def is_video(extension: str) -> bool:
    """Check if file is a video."""
    return extension.lower() in ["mp4", "webm", "mov", "avi"]


def is_document(extension: str) -> bool:
    """Check if file is a document."""
    return extension.lower() in ["pdf", "doc", "docx", "txt", "md", "csv", "xlsx"]
