"""Upload utility functions."""

import os
from typing import Dict


def format_file_size(size_bytes: int) -> str:
    """
    Format file size in human-readable format.
    
    Args:
        size_bytes: Size in bytes
        
    Returns:
        Formatted string (e.g., "1.5 MB")
    """
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    
    return f"{size_bytes:.1f} PB"


def get_storage_stats(upload_dir: str) -> Dict:
    """
    Get storage directory statistics.
    
    Args:
        upload_dir: Upload directory path
        
    Returns:
        Dict with file count and total size
    """
    if not os.path.exists(upload_dir):
        return {"file_count": 0, "total_size": 0}
    
    file_count = 0
    total_size = 0
    
    for filename in os.listdir(upload_dir):
        file_path = os.path.join(upload_dir, filename)
        if os.path.isfile(file_path):
            file_count += 1
            total_size += os.path.getsize(file_path)
    
    return {
        "file_count": file_count,
        "total_size": total_size,
        "total_size_formatted": format_file_size(total_size),
    }
