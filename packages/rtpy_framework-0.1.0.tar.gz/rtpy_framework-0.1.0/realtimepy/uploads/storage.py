"""Storage backends for file uploads."""

import os
import time
from abc import ABC, abstractmethod
from typing import Optional
import aiofiles
import logging

logger = logging.getLogger(__name__)


class StorageBackend(ABC):
    """Abstract storage backend."""
    
    @abstractmethod
    async def save(self, filename: str, content: bytes) -> str:
        """Save file and return path/URL."""
        pass
    
    @abstractmethod
    async def get(self, filename: str) -> Optional[bytes]:
        """Retrieve file content."""
        pass
    
    @abstractmethod
    async def delete(self, filename: str) -> bool:
        """Delete file."""
        pass
    
    @abstractmethod
    async def cleanup_old(self, max_age_days: int) -> int:
        """Clean up old files."""
        pass


class LocalStorage(StorageBackend):
    """Local filesystem storage."""
    
    def __init__(self, upload_dir: str = "uploads"):
        self.upload_dir = upload_dir
        os.makedirs(upload_dir, exist_ok=True)
    
    async def save(self, filename: str, content: bytes) -> str:
        """Save file to local filesystem."""
        file_path = os.path.join(self.upload_dir, filename)
        
        async with aiofiles.open(file_path, 'wb') as f:
            await f.write(content)
        
        return file_path
    
    async def get(self, filename: str) -> Optional[bytes]:
        """Read file from local filesystem."""
        file_path = os.path.join(self.upload_dir, filename)
        
        if not os.path.exists(file_path):
            return None
        
        async with aiofiles.open(file_path, 'rb') as f:
            return await f.read()
    
    async def delete(self, filename: str) -> bool:
        """Delete file from local filesystem."""
        file_path = os.path.join(self.upload_dir, filename)
        
        if os.path.exists(file_path):
            os.remove(file_path)
            return True
        
        return False
    
    async def cleanup_old(self, max_age_days: int) -> int:
        """Delete files older than max_age_days."""
        count = 0
        current_time = time.time()
        max_age_seconds = max_age_days * 24 * 60 * 60
        
        for filename in os.listdir(self.upload_dir):
            file_path = os.path.join(self.upload_dir, filename)
            
            if os.path.isfile(file_path):
                file_age = current_time - os.path.getmtime(file_path)
                
                if file_age > max_age_seconds:
                    try:
                        os.remove(file_path)
                        count += 1
                        logger.info(f"Deleted old file: {filename}")
                    except Exception as e:
                        logger.error(f"Failed to delete {filename}: {e}")
        
        return count


class CloudStorage(StorageBackend):
    """
    Cloud storage backend (S3, GCS, Azure Blob).
    
    This is a template - implement based on your cloud provider.
    """
    
    def __init__(self, bucket_name: str, provider: str = "s3"):
        self.bucket_name = bucket_name
        self.provider = provider
        # Initialize cloud client here
    
    async def save(self, filename: str, content: bytes) -> str:
        """Upload file to cloud storage."""
        # Implement cloud upload
        # Return public URL or path
        raise NotImplementedError("Cloud storage not implemented")
    
    async def get(self, filename: str) -> Optional[bytes]:
        """Download file from cloud storage."""
        raise NotImplementedError("Cloud storage not implemented")
    
    async def delete(self, filename: str) -> bool:
        """Delete file from cloud storage."""
        raise NotImplementedError("Cloud storage not implemented")
    
    async def cleanup_old(self, max_age_days: int) -> int:
        """Clean up old files from cloud storage."""
        raise NotImplementedError("Cloud storage not implemented")
