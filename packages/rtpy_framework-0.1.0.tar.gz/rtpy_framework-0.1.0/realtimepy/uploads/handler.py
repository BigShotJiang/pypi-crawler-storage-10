"""Main file upload handler with validation and storage."""

import os
import uuid
import hashlib
from typing import Optional, Dict, List
from fastapi import UploadFile
import aiofiles
import logging

from .validators import (
    validate_file_type,
    validate_file_size,
    get_file_extension,
    is_safe_filename,
)
from .storage import LocalStorage, StorageBackend
from ..errors.exceptions import ValidationError

logger = logging.getLogger(__name__)


class FileUploadHandler:
    """Handle file uploads with validation and storage."""
    
    # Allowed file types
    ALLOWED_TYPES = {
        "image": ["jpg", "jpeg", "png", "gif", "webp", "svg"],
        "document": ["pdf", "doc", "docx", "txt", "md", "csv", "xlsx"],
        "video": ["mp4", "webm", "mov", "avi"],
        "audio": ["mp3", "wav", "ogg", "m4a"],
        "archive": ["zip", "tar", "gz", "rar"],
    }
    
    def __init__(
        self,
        upload_dir: str = "uploads",
        max_size: int = 10 * 1024 * 1024,  # 10MB default
        allowed_types: List[str] = None,
        storage_backend: StorageBackend = None,
    ):
        self.upload_dir = upload_dir
        self.max_size = max_size
        self.allowed_types = allowed_types or list(self.ALLOWED_TYPES.keys())
        self.storage = storage_backend or LocalStorage(upload_dir)
        
        # Create upload directory if using local storage
        if isinstance(self.storage, LocalStorage):
            os.makedirs(upload_dir, exist_ok=True)
    
    async def save_file(
        self,
        file: UploadFile,
        user_id: Optional[str] = None,
        metadata: Optional[Dict] = None
    ) -> Optional[Dict]:
        """
        Save uploaded file with validation.
        
        Returns:
            Dict with file info on success, None on failure
        """
        try:
            # Validate filename
            if not is_safe_filename(file.filename):
                raise ValidationError(
                    f"Invalid filename: {file.filename}",
                    field="filename"
                )
            
            # Read file content
            content = await file.read()
            
            # Validate file size
            if not validate_file_size(len(content), self.max_size):
                raise ValidationError(
                    f"File too large. Max size: {self.max_size // (1024*1024)}MB",
                    field="file_size"
                )
            
            # Validate file type
            file_ext = get_file_extension(file.filename)
            allowed_extensions = []
            for category in self.allowed_types:
                allowed_extensions.extend(self.ALLOWED_TYPES.get(category, []))
            
            if not validate_file_type(file_ext, allowed_extensions):
                raise ValidationError(
                    f"File type not allowed: {file_ext}",
                    field="file_type"
                )
            
            # Generate unique filename
            unique_name = self._generate_unique_filename(file.filename)
            
            # Calculate file hash for deduplication
            file_hash = hashlib.sha256(content).hexdigest()
            
            # Save file using storage backend
            file_path = await self.storage.save(unique_name, content)
            
            # Prepare metadata
            file_info = {
                "original_filename": file.filename,
                "saved_filename": unique_name,
                "path": file_path,
                "size": len(content),
                "content_type": file.content_type,
                "extension": file_ext,
                "hash": file_hash,
                "user_id": user_id,
                "metadata": metadata or {},
            }
            
            logger.info(f"File uploaded successfully: {unique_name}")
            return file_info
        
        except ValidationError:
            raise
        
        except Exception as e:
            logger.error(f"File upload failed: {e}")
            raise ValidationError(f"Upload failed: {str(e)}")
    
    async def delete_file(self, filename: str) -> bool:
        """Delete uploaded file."""
        try:
            return await self.storage.delete(filename)
        except Exception as e:
            logger.error(f"File deletion failed: {e}")
            return False
    
    async def get_file(self, filename: str) -> Optional[bytes]:
        """Retrieve file content."""
        try:
            return await self.storage.get(filename)
        except Exception as e:
            logger.error(f"File retrieval failed: {e}")
            return None
    
    def _generate_unique_filename(self, original_filename: str) -> str:
        """Generate unique filename preserving extension."""
        file_ext = get_file_extension(original_filename)
        unique_id = uuid.uuid4().hex
        return f"{unique_id}.{file_ext}" if file_ext else unique_id
    
    async def cleanup_old_files(self, max_age_days: int = 30) -> int:
        """
        Clean up files older than specified days.
        
        Returns:
            Number of files deleted
        """
        return await self.storage.cleanup_old(max_age_days)
