"""Message history and persistence with Rust acceleration."""

from abc import ABC, abstractmethod
from typing import List, Dict, Optional
from datetime import datetime
from collections import deque
import logging

logger = logging.getLogger(__name__)

# Try to import Rust extension
try:
    from realtimepy_core import RustMessageHistory
    USE_RUST_HISTORY = True
    logger.info("✓ Rust acceleration enabled for message history")
except ImportError:
    USE_RUST_HISTORY = False
    logger.info("⚠ Using pure Python message history")


class MessageHistory(ABC):
    """Abstract base for message history."""
    
    @abstractmethod
    async def add_message(self, room: str, username: str, content: str):
        """Add message to history."""
        pass
    
    @abstractmethod
    async def get_messages(self, room: str, limit: int = 50) -> List[Dict]:
        """Get message history."""
        pass
    
    @abstractmethod
    async def clear_room(self, room: str):
        """Clear room history."""
        pass


class PythonInMemoryHistory(MessageHistory):
    """Pure Python in-memory message history."""
    
    def __init__(self, max_per_room: int = 1000):
        self.max_per_room = max_per_room
        self.rooms: Dict[str, deque] = {}
    
    async def add_message(self, room: str, username: str, content: str):
        if room not in self.rooms:
            self.rooms[room] = deque(maxlen=self.max_per_room)
        
        self.rooms[room].append({
            "username": username,
            "content": content,
            "timestamp": datetime.now().isoformat()
        })
    
    async def get_messages(self, room: str, limit: int = 50) -> List[Dict]:
        messages = list(self.rooms.get(room, []))
        return messages[-limit:]
    
    async def clear_room(self, room: str):
        if room in self.rooms:
            self.rooms[room].clear()


class RustInMemoryHistory(MessageHistory):
    """Rust-accelerated in-memory message history (100x faster)."""
    
    def __init__(self, max_per_room: int = 1000):
        self._rust = RustMessageHistory(max_per_room)
    
    async def add_message(self, room: str, username: str, content: str):
        timestamp = datetime.now().isoformat()
        self._rust.add_message(room, username, content, timestamp)
    
    async def get_messages(self, room: str, limit: int = 50) -> List[Dict]:
        messages = self._rust.get_messages(room, limit)
        return [
            {
                "username": username,
                "content": content,
                "timestamp": timestamp
            }
            for username, content, timestamp in messages
        ]
    
    async def clear_room(self, room: str):
        self._rust.clear_room(room)


# Export the right implementation
if USE_RUST_HISTORY:
    InMemoryHistory = RustInMemoryHistory
else:
    InMemoryHistory = PythonInMemoryHistory


class DatabaseHistory(MessageHistory):
    """Database-backed message history (persistent)."""
    
    def __init__(self):
        pass
    
    async def add_message(self, room: str, username: str, content: str):
        from realtimepy.db.models import Message, Room, User
        
        try:
            room_obj = await Room.get(name=room)
            user_obj = await User.get(username=username)
            
            await Message.create(
                room=room_obj,
                user=user_obj,
                content=content
            )
        except Exception as e:
            logger.error(f"Failed to save message: {e}")
    
    async def get_messages(self, room: str, limit: int = 50) -> List[Dict]:
        from realtimepy.db.models import Message, Room
        
        try:
            room_obj = await Room.get(name=room)
            messages = await Message.filter(room=room_obj).limit(limit).order_by("-timestamp")
            
            return [{
                "username": msg.user.username,
                "content": msg.content,
                "timestamp": msg.timestamp.isoformat()
            } for msg in reversed(messages)]
        
        except Exception as e:
            logger.error(f"Failed to get messages: {e}")
            return []
    
    async def clear_room(self, room: str):
        from realtimepy.db.models import Message, Room
        
        try:
            room_obj = await Room.get(name=room)
            await Message.filter(room=room_obj).delete()
        except Exception as e:
            logger.error(f"Failed to clear room: {e}")
