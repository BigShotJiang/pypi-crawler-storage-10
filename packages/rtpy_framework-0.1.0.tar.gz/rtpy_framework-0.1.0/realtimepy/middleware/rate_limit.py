"""Rate limiting middleware."""

import logging
import time

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

logger = logging.getLogger(__name__)


class SimpleRateLimiter(BaseHTTPMiddleware):
    """Simple in-memory rate limiter."""

    def __init__(self, app, limit_per_sec: int = 10):
        super().__init__(app)
        self.calls: dict = {}
        self.limit_per_sec = limit_per_sec

    async def dispatch(self, request: Request, call_next):
        user = request.headers.get("authorization") or str(request.client.host)
        now = time.time()

        timestamps = self.calls.get(user, [])
        timestamps = [t for t in timestamps if now - t < 1]

        if len(timestamps) >= self.limit_per_sec:
            logger.warning(f"Rate limit exceeded for {user}")
            return JSONResponse({"detail": "Too many requests"}, status_code=429)

        self.calls[user] = timestamps + [now]
        return await call_next(request)
