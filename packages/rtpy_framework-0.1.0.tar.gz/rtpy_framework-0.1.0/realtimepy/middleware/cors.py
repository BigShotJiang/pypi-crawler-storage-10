"""CORS configuration helper."""

from fastapi.middleware.cors import CORSMiddleware


def setup_cors(app, origins: list[str] = None):
    """Configure CORS middleware."""
    if origins is None:
        origins = ["*"]

    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
