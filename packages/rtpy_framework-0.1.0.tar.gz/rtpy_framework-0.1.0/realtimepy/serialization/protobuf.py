"""Protocol Buffers serialization."""

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)


class ProtobufSerializer:
    """Serialize/deserialize Protocol Buffers."""
    
    def __init__(self):
        try:
            import google.protobuf
            self.available = True
        except ImportError:
            logger.warning("protobuf not installed. Install with: pip install protobuf")
            self.available = False
    
    def serialize(self, message: Any) -> Optional[bytes]:
        """Serialize protobuf message to bytes."""
        if not self.available:
            return None
        
        try:
            return message.SerializeToString()
        except Exception as e:
            logger.error(f"Protobuf serialization failed: {e}")
            return None
    
    def deserialize(self, data: bytes, message_type: Any) -> Optional[Any]:
        """Deserialize bytes to protobuf message."""
        if not self.available:
            return None
        
        try:
            message = message_type()
            message.ParseFromString(data)
            return message
        except Exception as e:
            logger.error(f"Protobuf deserialization failed: {e}")
            return None
