"""Binary serialization support."""

from .protobuf import ProtobufSerializer

__all__ = ["ProtobufSerializer"]
