def main() -> None:
    print("Hello from poouli!")
