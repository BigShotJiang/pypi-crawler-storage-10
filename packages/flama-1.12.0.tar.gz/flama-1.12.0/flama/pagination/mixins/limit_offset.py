import functools
import inspect
import typing as t

from flama import http, schemas

__all__ = ["LimitOffsetMixin", "LimitOffsetResponse"]

from flama.pagination.decorators import PaginationDecoratorFactory


class LimitOffsetResponse(http.APIResponse):
    """
    Response paginated based on a limit of elements and an offset.

    First 10 elements:
        /resource?offset=0&limit=10
    Elements 20-30:
        /resource?offset=20&limit=10
    """

    default_limit = 10

    def __init__(
        self,
        schema: t.Any,
        offset: int | str | None = None,
        limit: int | str | None = None,
        count: bool | None = True,
        **kwargs,
    ):
        self.offset = int(offset) if offset is not None else 0
        self.limit = int(limit) if limit is not None else self.default_limit
        self.count = count
        super().__init__(schema=schema, **kwargs)

    def render(self, content: t.Sequence[t.Any]):
        init = self.offset
        end = self.offset + self.limit
        return super().render(
            {
                "meta": {"limit": self.limit, "offset": self.offset, "count": len(content) if self.count else None},
                "data": content[init:end],
            }
        )


class LimitOffsetDecoratorFactory(PaginationDecoratorFactory):
    PARAMETERS = [
        inspect.Parameter(
            name="limit", default=None, annotation=int | None, kind=inspect.Parameter.POSITIONAL_OR_KEYWORD
        ),
        inspect.Parameter(
            name="offset", default=None, annotation=int | None, kind=inspect.Parameter.POSITIONAL_OR_KEYWORD
        ),
        inspect.Parameter(
            name="count", default=False, annotation=bool | None, kind=inspect.Parameter.POSITIONAL_OR_KEYWORD
        ),
    ]

    @classmethod
    def _decorate_async(cls, func: t.Callable, schema: t.Any) -> t.Callable:
        @functools.wraps(func)
        async def decorator(
            *args,
            limit: int | None = None,
            offset: int | None = None,
            count: bool | None = False,
            **kwargs,
        ):
            return LimitOffsetResponse(
                schema=schema, limit=limit, offset=offset, count=count, content=await func(*args, **kwargs)
            )

        return decorator

    @classmethod
    def _decorate_sync(cls, func: t.Callable, schema: t.Any) -> t.Callable:
        @functools.wraps(func)
        def decorator(
            *args,
            limit: int | None = None,
            offset: int | None = None,
            count: bool | None = False,
            **kwargs,
        ):
            return LimitOffsetResponse(
                schema=schema, limit=limit, offset=offset, count=count, content=func(*args, **kwargs)
            )

        return decorator


class LimitOffsetMixin:
    schemas: dict[str, t.Any]

    def _paginate_limit_offset(self, func: t.Callable) -> t.Callable:
        """
        Decorator for adding pagination behavior to a view. That decorator produces a view based on limit-offset and
        it adds three query parameters to control the pagination: limit, offset and count. Offset has a default value of
        zero to start with the first element of the collection, limit default value is defined in
        :class:`LimitOffsetResponse` and count defines if the response will
        define the total number of elements.

        The output field is also modified by :class:`LimitOffsetSchema`,
        creating a new field based on it but using the old output field as the content of its data field.

        :param schema_name: Name used for output field.
        :return: Decorated view.
        """
        schema = schemas.Schema.from_type(inspect.signature(func).return_annotation)

        try:
            module, schema_class = schema.name.rsplit(".", 1)
            name = f"LimitOffsetPaginated{schema_class}"
        except ValueError:  # pragma: no cover
            module = None
            name = f"LimitOffsetPaginated{schema.name}"

        paginated_schema = schemas.Schema.build(
            name,
            module,
            schema=schemas.schemas.LimitOffset,
            fields=[schemas.Field("data", schema.unique_schema, multiple=True)],
        )

        decorator = LimitOffsetDecoratorFactory.decorate(func, paginated_schema.unique_schema)

        self.schemas.update({schema.name: schema.unique_schema, paginated_schema.name: paginated_schema.unique_schema})

        return decorator
