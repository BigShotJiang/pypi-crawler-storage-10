# Web Base

> Esse material passa por atualizações periódicas. Você pode acompanhar as notas de alterações [aqui](./docs/changelog.md).


![PyPI - Version](https://img.shields.io/badge/pypi-0.1.0-orange)
![Python](https://img.shields.io/badge/language-Python-blue?logo=python)
![Cobertura de Testes](https://img.shields.io/badge/cobertura-80%25-brightgreen?logo=pytest)
[![Supported Python versions](https://img.shields.io/pypi/pyversions/fastapi.svg?color=%2334D058)](https://pypi.org/project/fastapi)

# Descrição

Metodos úteis para configuração e utilização do selenium de forma simplificada.
