from web_base.config import ElementsPressents, WebBase

__author__ = 'MatheusLPolidoro'
__version__ = '0.1.1'
__all__ = ['WebBase', 'ElementsPressents']
