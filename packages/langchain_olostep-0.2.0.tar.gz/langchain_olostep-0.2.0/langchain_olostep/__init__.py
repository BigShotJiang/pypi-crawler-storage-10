"""
LangChain Olostep Integration

A LangChain integration package for the Olostep web scraping API.
Provides powerful tools for web scraping with LangChain and LangGraph.
"""

from .tools import (
    scrape_website,
    scrape_batch,
    scrape_with_answer,
    scrape_with_map
)

__version__ = "0.2.0"
__all__ = [
    "scrape_website",
    "scrape_batch",
    "scrape_with_answer",
    "scrape_with_map"
]
