import abjad

import nauert


def test_QuantizationJob___init___01():
    job_id = 1
    definition = {2: {2: {2: None}, 3: None}, 5: None}
    search_tree = nauert.UnweightedSearchTree(definition)
    q_event_proxies = [
        nauert.QEventProxy(
            nauert.SilentQEvent(abjad.duration.offset(0), ["A"], index=1),
            abjad.duration.offset(0),
            abjad.duration.offset(1),
        ),
        nauert.QEventProxy(
            nauert.SilentQEvent(abjad.duration.offset(1, 5), ["B"], index=2),
            abjad.duration.offset(0),
            abjad.duration.offset(1),
        ),
        nauert.QEventProxy(
            nauert.SilentQEvent(abjad.duration.offset(1, 4), ["C"], index=3),
            abjad.duration.offset(0),
            abjad.duration.offset(1),
        ),
        nauert.QEventProxy(
            nauert.SilentQEvent(abjad.duration.offset(1, 3), ["D"], index=4),
            abjad.duration.offset(0),
            abjad.duration.offset(1),
        ),
        nauert.QEventProxy(
            nauert.SilentQEvent(abjad.duration.offset(2, 5), ["E"], index=5),
            abjad.duration.offset(0),
            abjad.duration.offset(1),
        ),
        nauert.QEventProxy(
            nauert.SilentQEvent(abjad.duration.offset(1, 2), ["F"], index=6),
            abjad.duration.offset(0),
            abjad.duration.offset(1),
        ),
        nauert.QEventProxy(
            nauert.SilentQEvent(abjad.duration.offset(3, 5), ["G"], index=7),
            abjad.duration.offset(0),
            abjad.duration.offset(1),
        ),
        nauert.QEventProxy(
            nauert.SilentQEvent(abjad.duration.offset(2, 3), ["H"], index=8),
            abjad.duration.offset(0),
            abjad.duration.offset(1),
        ),
        nauert.QEventProxy(
            nauert.SilentQEvent(abjad.duration.offset(3, 4), ["I"], index=9),
            abjad.duration.offset(0),
            abjad.duration.offset(1),
        ),
        nauert.QEventProxy(
            nauert.SilentQEvent(abjad.duration.offset(4, 5), ["J"], index=10),
            abjad.duration.offset(0),
            abjad.duration.offset(1),
        ),
        nauert.QEventProxy(
            nauert.SilentQEvent(abjad.duration.offset(1), ["K"], index=11),
            abjad.duration.offset(0),
            abjad.duration.offset(1),
        ),
    ]
    job = nauert.QuantizationJob(job_id, search_tree, q_event_proxies)
    assert job.job_id == job_id
    assert job.search_tree == search_tree
    assert job.q_event_proxies == tuple(q_event_proxies)
