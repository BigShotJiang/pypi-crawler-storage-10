udsonip.client
==============

.. automodule:: udsonip.client
   :members:
   :undoc-members:
   :show-inheritance:
