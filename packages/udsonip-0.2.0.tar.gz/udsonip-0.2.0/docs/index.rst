.. python-udsonip documentation master file, created by
   sphinx-quickstart on Sat Oct 25 15:55:36 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

python-udsonip documentation
============================

Add your content using ``reStructuredText`` syntax. See the
`reStructuredText <https://www.sphinx-doc.org/en/master/usage/restructuredtext/index.html>`_
documentation for details.


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   client
   connection
   discovery
   exceptions
   multi_ecu
