# Copyright (c) Meta Platforms, Inc. and affiliates

from .chat.chat_generator import MetaLlamaChatGenerator

__all__ = ["MetaLlamaChatGenerator"]
