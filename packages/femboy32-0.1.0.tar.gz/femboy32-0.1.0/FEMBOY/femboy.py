import os
import serial
import webbrowser

port = None  
com_base = 'COM1'
commands = ["connect", "disconnect", "clean", "send", "help", "github", "close"]
commands_help = [
    "",
    "connect [port] - Connect your device to the referenced port",
    "disconnect [port] - Disconnects your device with the referenced port",
    "clean - Clean CLI interface",
    "send - Send commands to FEMBOY",
    "github - Open FEMBOY GitHub page",
    "help - Display this message",
    "close - Close CLI interface",
    "",
]
def clean():
    os.system('cls' if os.name == 'nt' else 'clear')

def connect(com=com_base):
    global port
    print("Initializing FEMBOY...")
    try:
        port = serial.Serial(com, baudrate=9600, timeout=1)
        print("Connected with success!")
    except serial.SerialException as e:
        print("Error on connection:", e)

def disconnect():
    global port
    print("Turning off FEMBOY...")
    if port and port.is_open:
        port.close()
        print("FEMBOY off :3")
    else:
        print("No active connection to close.")

def send(command):
    if port and port.is_open:
        port.write(command.encode())  
    else:
        print("No active connection.")

while True:
    line = input("> ").strip()
    
    if line.startswith("connect"):
        parts = line.split()
        if len(parts) > 1:
            connect(parts[1])
        else:
            connect()

    elif line.startswith("disconnect"):
        disconnect()

    elif line.startswith("clean"):
        clean()

    elif line.startswith("send"):
        if port and port.is_open:
            command = line[len("send "):]
            send(command)
        else:
            print("No active connection.")

    elif line.startswith("help"):
        for help_commands in commands_help:
            print(help_commands)

    elif line.startswith("github"):
        print("Opening GitHub page...")
        webbrowser.open("https://github.com/renpyuser/FEMBOY")

    elif line.startswith("close"):
        disconnect()
        break

    else:
        print("Invalid command. Type 'help'")


