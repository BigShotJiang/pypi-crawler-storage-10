
def hello():
    print("Hello Mars")
