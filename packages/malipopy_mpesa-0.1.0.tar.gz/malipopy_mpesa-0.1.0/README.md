# malipopy-mpesa

A Python M-Pesa payments library (Daraja API wrapper).

## Installation

```bash
pip install malipopy-mpesa
