select implementation details of distoptica
===========================================

.. autosummary::
   :toctree: _autosummary
   :template: custom_module_template.rst
   :recursive:
