.. _examples_sec:

Examples
========

You can find examples of using the ``distoptica`` library in the notebook
located at ``<root>/examples/basic_usage.ipynb``, where ``<root>`` is the root
of the ``distoptica`` repository. You can find the repository `here
<https://github.com/mrfitzpa/distoptica>`_.
