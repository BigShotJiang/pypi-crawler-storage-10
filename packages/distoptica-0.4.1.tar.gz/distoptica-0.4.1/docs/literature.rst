Literature
==========

Below is a list of references that are cited in the ``distoptica``
documentation.

.. [Brázda1] |nbspc|"Accurate lattice parameters from 3D electron diffraction
                    data. I. Optical distortions", L. Brázda, M. Klementová,
		    Y. Krysiaka, L. Palatinusa, IUCrj **9**, p. 735-755 (2022),
	            :doi:`10.1107/S2052252522007904`

.. |nbspc| unicode:: U+00A0 .. non-breaking space
