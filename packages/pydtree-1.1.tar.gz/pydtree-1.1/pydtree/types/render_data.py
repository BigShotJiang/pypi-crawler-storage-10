from dataclasses import dataclass


@dataclass
class RenderData:
    is_endpoint: bool
