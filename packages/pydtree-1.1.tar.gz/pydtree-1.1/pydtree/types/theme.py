from dataclasses import dataclass


@dataclass
class Theme:
    vertical: str
    branch: str
    corner: str
    tab: str
