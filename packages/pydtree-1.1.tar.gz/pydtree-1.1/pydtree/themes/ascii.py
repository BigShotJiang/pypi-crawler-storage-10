from ..types import Theme

Ascii = Theme(
    vertical='|   ',
    branch='+-- ',
    corner='`-- ',
    tab='    '
)
