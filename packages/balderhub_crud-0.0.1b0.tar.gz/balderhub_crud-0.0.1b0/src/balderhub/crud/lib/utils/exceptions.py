

class CallbackExecutionError(Exception):
    pass
