# API

```{toctree}
:maxdepth: 2

api/methods
api/evaluation
api/aggregation
```
