# Evaluation and Visualization

```{eval-rst}
.. module:: scembed
.. currentmodule:: scembed

.. autosummary::
    :toctree: ../generated

    IntegrationEvaluator
```
