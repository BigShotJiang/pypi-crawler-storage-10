#!/usr/bin/env bash
set -euo pipefail

# Determina la ruta del directorio infra para ejecutar los comandos
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INFRA_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

print_usage() {
    cat <<'USAGE'
Uso: deploy.sh [comando]

Comandos disponibles:
  start|up      Construye las imágenes necesarias y levanta la pila en segundo plano.
  stop|down     Detiene y elimina los contenedores creados para la pila.
  restart       Reinicia la pila ejecutando primero "stop" y después "start".
  logs          Muestra los logs combinados de los servicios y sigue la salida en tiempo real.
  status|ps     Lista el estado actual de los contenedores administrados.
  help|-h|--help  Muestra este mensaje de ayuda.

Por defecto se utiliza el comando "start".
USAGE
}

ensure_compose() {
    if command -v docker >/dev/null 2>&1; then
        if docker compose version >/dev/null 2>&1; then
            echo "docker compose"
            return 0
        fi
    fi
    if command -v docker-compose >/dev/null 2>&1; then
        echo "docker-compose"
        return 0
    fi
    echo "Error: no se encontró ni 'docker compose' ni 'docker-compose' en el PATH." >&2
    echo "Instala Docker Desktop o el plugin de Docker Compose antes de continuar." >&2
    exit 1
}

load_env_args() {
    local env_file
    env_file="${INFRA_DIR}/.env"
    if [[ -n "${COBRA_ENV_FILE:-}" ]]; then
        env_file="${COBRA_ENV_FILE}"
    fi

    if [[ -f "${env_file}" ]]; then
        echo "--env-file" "${env_file}"
    fi
}

main() {
    local command
    command="${1:-start}"

    case "${command}" in
        help|-h|--help)
            print_usage
            return 0
            ;;
        start|up|stop|down|restart|logs|status|ps)
            ;;
        *)
            echo "Comando desconocido: ${command}" >&2
            print_usage >&2
            exit 1
            ;;
    esac

    local compose_cmd
    compose_cmd="$(ensure_compose)"

    local compose_args
    compose_args=("-f" "${INFRA_DIR}/docker-compose.yml")

    local env_args
    IFS=$'\n' read -r -d '' -a env_args < <(load_env_args && printf '\0') || true
    if [[ ${#env_args[@]} -gt 0 ]]; then
        compose_args+=("${env_args[@]}")
    fi

    pushd "${INFRA_DIR}" >/dev/null

    case "${command}" in
        start|up)
            "${compose_cmd}" "${compose_args[@]}" up --build -d
            ;;
        stop|down)
            "${compose_cmd}" "${compose_args[@]}" down
            ;;
        restart)
            "${compose_cmd}" "${compose_args[@]}" down
            "${compose_cmd}" "${compose_args[@]}" up --build -d
            ;;
        logs)
            "${compose_cmd}" "${compose_args[@]}" logs -f
            ;;
        status|ps)
            "${compose_cmd}" "${compose_args[@]}" ps
            ;;
    esac

    popd >/dev/null
}

main "$@"
