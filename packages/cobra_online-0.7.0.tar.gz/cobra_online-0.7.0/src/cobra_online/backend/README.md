# Cobra_Online API (backend)

Este directorio contiene el servicio FastAPI principal de Cobra_Online. A partir de
esta iteración el backend puede empaquetarse e instalarse como un paquete Python,
lo que simplifica los despliegues y automatizaciones descritos en la fase 4 del
roadmap.

## Requisitos

- Python 3.11 o superior.
- Dependencias listadas en `pyproject.toml` (se instalan automáticamente al
  ejecutar `pip install .`).

## Instalación como paquete

Desde esta carpeta puedes construir e instalar el servicio con `pip`:

```bash
pip install .
```

Para entornos de desarrollo puedes incluir las dependencias opcionales:

```bash
pip install .[dev]
```

## Ejecución

La distribución expone un comando `cobra-online-api` que inicia la aplicación
usando Uvicorn y los parámetros definidos en las variables de entorno
`API_HOST` y `API_PORT` (o sus valores por defecto `0.0.0.0:8000`).

Para que la gestión de API keys sea segura en entornos de producción, define la
variable `API_KEY_MASTER_SECRET` con un valor robusto antes de iniciar el
servicio.

```bash
cobra-online-api
```

También puedes seguir utilizando Uvicorn manualmente:

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## Ejecución de pruebas

Las pruebas automáticas siguen disponibles mediante `pytest`:

```bash
pytest
```

## Notas

- El paquete incluye los submódulos existentes dentro de `app/` sin cambios en
  su estructura de importación.
- La configuración se gestiona mediante `pydantic-settings` y puede cargarse
  desde un archivo `.env` en este mismo directorio.
- El módulo `app.db.manager` crea el motor SQLAlchemy adecuado para SQLite
  (sqliteplus-enhanced), PostgreSQL, Amazon Redshift, MySQL/MariaDB, SQL Server,
  Oracle, Snowflake y dialectos basados en HTTP como Trino, Databricks SQL,
  ClickHouse o BigQuery. Puedes ajustar `DATABASE_POOL_SIZE`,
  `DATABASE_MAX_OVERFLOW`, `DATABASE_POOL_RECYCLE`,
  `DATABASE_STATEMENT_TIMEOUT_MS`, `DATABASE_APPLICATION_NAME` o `DATABASE_SSL_MODE`
  para integrarte con servicios gestionados de terceros.
- El módulo `app.db.sqliteplus` expone la clase `SQLitePlusDatabase`, que permite
  ejecutar scripts completos, adjuntar bases externas, generar copias de
  seguridad, replicar el fichero de datos y exportar tablas en CSV utilizando la
  librería sqliteplus-enhanced como backend predeterminado.
- Las variables `SQLITE_AUTO_OPTIMIZE`, `SQLITE_VACUUM_ON_STARTUP`,
  `SQLITE_WAL_CHECKPOINT` y `SQLITE_INTEGRITY_CHECK` controlan las tareas de
  mantenimiento aplicadas con sqliteplus-enhanced.
