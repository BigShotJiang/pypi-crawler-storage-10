"""Punto de entrada para la aplicación FastAPI de Cobra Online."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

import sys
from pathlib import Path

from fastapi import FastAPI
import uvicorn

if __package__ is None or __package__ == "":  # pragma: no cover - ejecución como script directo
    package_root = Path(__file__).resolve().parent
    project_root = package_root.parent
    sys.path.insert(0, str(project_root))
    __package__ = package_root.name

from app.api.v1.router import api_router
from app.core.config import settings
from app.db import init_db


def create_application() -> FastAPI:
    """Crea y configura una instancia de la aplicación FastAPI."""
    application = FastAPI(
        title=settings.project_name,
        version=settings.version,
        description=settings.description,
    )
    application.include_router(api_router, prefix=settings.api_v1_prefix)
    init_db()
    return application


app = create_application()


def main() -> None:
    """Lanza la API usando Uvicorn con la configuración del proyecto."""

    uvicorn.run(
        "app.main:app",
        host=settings.api_host,
        port=settings.api_port,
        reload=False,
    )


if __name__ == "__main__":
    main()
