"""Modelos de datos de Cobra Online."""


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from app.models.analytics import (
    AnalyticsEngine,
    AnalyticsPipeline,
    AnalyticsPipelineMode,
    AnalyticsPipelineStatus,
)
from app.models.base import Base
from app.models.compute import ComputeInstance, ComputeInstanceStatus
from app.models.database import (
    DatabaseEngine,
    DatabaseInstance,
    DatabaseInstanceStatus,
)
from app.models.ml import (
    MachineLearningFramework,
    MachineLearningModel,
    MachineLearningModelStatus,
)
from app.models.network import (
    NetworkLoadBalancer,
    NetworkLoadBalancerProtocol,
    NetworkLoadBalancerStatus,
)
from app.models.security import ApiKey
from app.models.storage import StorageBucket

__all__ = [
    "AnalyticsEngine",
    "AnalyticsPipeline",
    "AnalyticsPipelineMode",
    "AnalyticsPipelineStatus",
    "Base",
    "ComputeInstance",
    "ComputeInstanceStatus",
    "DatabaseEngine",
    "DatabaseInstance",
    "DatabaseInstanceStatus",
    "NetworkLoadBalancer",
    "NetworkLoadBalancerProtocol",
    "NetworkLoadBalancerStatus",
    "MachineLearningFramework",
    "MachineLearningModel",
    "MachineLearningModelStatus",
    "ApiKey",
    "StorageBucket",
]
