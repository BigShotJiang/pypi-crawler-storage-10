"""Modelos relacionados con pipelines de análisis de datos."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from datetime import datetime
from enum import Enum

from sqlalchemy import DateTime, Enum as SqlEnum, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class AnalyticsEngine(str, Enum):
    """Motores soportados para ejecutar pipelines de análisis."""

    SPARK = "spark"
    DASK = "dask"
    NIFI = "nifi"


class AnalyticsPipelineStatus(str, Enum):
    """Estados posibles para la ejecución de un pipeline."""

    DRAFT = "draft"
    SCHEDULED = "scheduled"
    RUNNING = "running"
    FAILED = "failed"
    COMPLETED = "completed"


class AnalyticsPipelineMode(str, Enum):
    """Modos de orquestación soportados para los pipelines."""

    BATCH = "batch"
    STREAMING = "streaming"


class AnalyticsPipeline(Base):
    """Representa un pipeline de análisis de datos dentro de Cobra Online."""

    __tablename__ = "analytics_pipelines"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(
        String(63),
        unique=True,
        index=True,
        nullable=False,
        doc="Nombre único del pipeline definido por el usuario.",
    )
    engine: Mapped[AnalyticsEngine] = mapped_column(
        SqlEnum(AnalyticsEngine),
        nullable=False,
        doc="Motor distribuido seleccionado para ejecutar el pipeline.",
    )
    mode: Mapped[AnalyticsPipelineMode] = mapped_column(
        SqlEnum(AnalyticsPipelineMode),
        default=AnalyticsPipelineMode.BATCH,
        server_default=AnalyticsPipelineMode.BATCH.value,
        nullable=False,
        doc="Define si el pipeline opera en modo batch o streaming.",
    )
    schedule: Mapped[str | None] = mapped_column(
        String(64),
        nullable=True,
        doc="Expresión de programación (por ejemplo cron) opcional.",
    )
    description: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
        doc="Descripción legible para el equipo de datos.",
    )
    status: Mapped[AnalyticsPipelineStatus] = mapped_column(
        SqlEnum(AnalyticsPipelineStatus),
        default=AnalyticsPipelineStatus.DRAFT,
        nullable=False,
        doc="Estado operativo actual del pipeline.",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
        doc="Momento en el que se registró el pipeline.",
    )
