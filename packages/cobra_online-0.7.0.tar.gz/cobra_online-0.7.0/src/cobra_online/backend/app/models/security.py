"""Modelos relacionados con la seguridad de la plataforma."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class ApiKey(Base):
    """Representa una API key administrada por Cobra Online."""

    __tablename__ = "api_keys"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(
        String(64),
        nullable=False,
        doc="Nombre descriptivo asignado a la API key.",
    )
    key_prefix: Mapped[str] = mapped_column(
        String(12),
        nullable=False,
        index=True,
        doc="Prefijo corto utilizado para identificar la API key.",
    )
    hashed_key: Mapped[str] = mapped_column(
        String(128),
        unique=True,
        nullable=False,
        doc="Huella criptográfica de la API key almacenada para verificación.",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
        doc="Momento de creación de la API key.",
    )
    expires_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        doc="Fecha opcional de expiración de la API key.",
    )
    last_used_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        doc="Última vez que la API key fue utilizada correctamente.",
    )
    revoked: Mapped[bool] = mapped_column(
        Boolean,
        default=False,
        nullable=False,
        doc="Indica si la API key fue revocada por un administrador.",
    )

