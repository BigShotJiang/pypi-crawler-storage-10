"""Clases base de SQLAlchemy para los modelos de Cobra Online."""
from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    """Declarative base compartida por todos los modelos."""

    pass
