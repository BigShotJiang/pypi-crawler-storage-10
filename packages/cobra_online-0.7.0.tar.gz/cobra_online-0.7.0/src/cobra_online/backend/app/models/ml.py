"""Modelos relacionados con servicios de IA y Machine Learning."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from datetime import datetime
from enum import Enum

from sqlalchemy import DateTime, Enum as SqlEnum, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class MachineLearningFramework(str, Enum):
    """Frameworks soportados para entrenar y servir modelos."""

    TENSORFLOW = "tensorflow"
    PYTORCH = "pytorch"
    SCIKIT_LEARN = "scikit-learn"
    XGBOOST = "xgboost"


class MachineLearningModelStatus(str, Enum):
    """Estados posibles para el ciclo de vida de un modelo."""

    DRAFT = "draft"
    TRAINING = "training"
    READY = "ready"
    FAILED = "failed"
    ARCHIVED = "archived"


class MachineLearningModel(Base):
    """Representa un modelo de machine learning gestionado por Cobra Online."""

    __tablename__ = "ml_models"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(
        String(63),
        unique=True,
        index=True,
        nullable=False,
        doc="Nombre único asignado al modelo por el usuario.",
    )
    framework: Mapped[MachineLearningFramework] = mapped_column(
        SqlEnum(MachineLearningFramework),
        nullable=False,
        doc="Framework utilizado para entrenar o servir el modelo.",
    )
    version: Mapped[str] = mapped_column(
        String(32),
        nullable=False,
        doc="Versión del modelo o conjunto de pesos registrado.",
    )
    description: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
        doc="Descripción legible para el equipo de datos o ciencia.",
    )
    status: Mapped[MachineLearningModelStatus] = mapped_column(
        SqlEnum(MachineLearningModelStatus),
        default=MachineLearningModelStatus.DRAFT,
        server_default=MachineLearningModelStatus.DRAFT.value,
        nullable=False,
        doc="Estado operativo actual del modelo.",
    )
    endpoint_url: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
        doc="Ubicación del endpoint o servicio que expone el modelo.",
    )
    last_trained_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        doc="Fecha de la última sesión de entrenamiento exitoso.",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
        doc="Momento en el que se registró el modelo.",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
        doc="Última vez que se actualizaron los metadatos del modelo.",
    )
