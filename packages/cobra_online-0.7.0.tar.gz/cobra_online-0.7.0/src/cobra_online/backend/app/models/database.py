"""Modelos relacionados con el módulo de bases de datos administradas."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from datetime import datetime
from enum import Enum

from sqlalchemy import DateTime, Enum as SqlEnum, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class DatabaseEngine(str, Enum):
    """Motores de bases de datos compatibles en el MVP."""

    POSTGRESQL = "postgresql"
    MYSQL = "mysql"


class DatabaseInstanceStatus(str, Enum):
    """Estados posibles para una base de datos administrada."""

    PROVISIONING = "provisioning"
    AVAILABLE = "available"
    FAILED = "failed"


class DatabaseInstance(Base):
    """Representa una instancia de base de datos administrada por Cobra Online."""

    __tablename__ = "database_instances"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(
        String(63),
        unique=True,
        index=True,
        nullable=False,
        doc="Nombre único del clúster de base de datos.",
    )
    engine: Mapped[DatabaseEngine] = mapped_column(
        SqlEnum(DatabaseEngine),
        nullable=False,
        doc="Motor de base de datos seleccionado.",
    )
    version: Mapped[str] = mapped_column(
        String(16),
        nullable=False,
        doc="Versión del motor desplegada.",
    )
    region: Mapped[str] = mapped_column(
        String(32),
        nullable=False,
        doc="Región donde se hospeda la base de datos.",
    )
    storage_gb: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        doc="Almacenamiento asignado en GiB.",
    )
    status: Mapped[DatabaseInstanceStatus] = mapped_column(
        SqlEnum(DatabaseInstanceStatus),
        default=DatabaseInstanceStatus.PROVISIONING,
        nullable=False,
        doc="Estado operativo actual del servicio.",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
        doc="Momento de creación del recurso.",
    )
