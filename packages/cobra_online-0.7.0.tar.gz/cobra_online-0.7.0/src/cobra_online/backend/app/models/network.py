"""Modelos relacionados con servicios de red."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from datetime import datetime
from enum import Enum

from sqlalchemy import CheckConstraint, DateTime, Enum as SqlEnum, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class NetworkLoadBalancerProtocol(str, Enum):
    """Protocolos soportados por los balanceadores de carga."""

    HTTP = "http"
    HTTPS = "https"
    TCP = "tcp"


class NetworkLoadBalancerStatus(str, Enum):
    """Estados operativos posibles de un balanceador de carga."""

    PROVISIONING = "provisioning"
    ACTIVE = "active"
    FAILED = "failed"


class NetworkLoadBalancer(Base):
    """Representa un balanceador de carga definido dentro de Cobra Online."""

    __tablename__ = "network_load_balancers"
    __table_args__ = (
        CheckConstraint("port BETWEEN 1 AND 65535", name="ck_network_lb_port_range"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(
        String(63),
        unique=True,
        index=True,
        nullable=False,
        doc="Nombre único del balanceador de carga.",
    )
    protocol: Mapped[NetworkLoadBalancerProtocol] = mapped_column(
        SqlEnum(NetworkLoadBalancerProtocol),
        nullable=False,
        doc="Protocolo que balancea el recurso.",
    )
    port: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        doc="Puerto de servicio balanceado.",
    )
    region: Mapped[str] = mapped_column(
        String(32),
        nullable=False,
        doc="Región lógica o física del balanceador.",
    )
    status: Mapped[NetworkLoadBalancerStatus] = mapped_column(
        SqlEnum(NetworkLoadBalancerStatus),
        default=NetworkLoadBalancerStatus.PROVISIONING,
        nullable=False,
        doc="Estado actual del balanceador.",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
        doc="Momento de creación del recurso.",
    )
