"""Modelos relacionados con el módulo de almacenamiento de objetos."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from datetime import datetime

from sqlalchemy import DateTime, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class StorageBucket(Base):
    """Representa un bucket compatible con S3 dentro de Cobra Online."""

    __tablename__ = "storage_buckets"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    name: Mapped[str] = mapped_column(
        String(63),
        unique=True,
        index=True,
        nullable=False,
        doc="Nombre único del bucket visible para los usuarios.",
    )
    region: Mapped[str] = mapped_column(
        String(32),
        nullable=False,
        doc="Región lógica o física donde reside el bucket.",
    )
    description: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
        doc="Descripción opcional para los usuarios.",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
        doc="Momento de creación del bucket.",
    )
