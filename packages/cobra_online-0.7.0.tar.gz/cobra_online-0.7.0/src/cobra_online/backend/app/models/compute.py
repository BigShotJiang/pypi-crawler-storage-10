"""Modelos relacionados con el módulo de cómputo."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from datetime import datetime
from enum import Enum

from sqlalchemy import DateTime, Enum as SqlEnum, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class ComputeInstanceStatus(str, Enum):
    """Estados posibles para una instancia de cómputo."""

    PROVISIONING = "provisioning"
    RUNNING = "running"
    STOPPED = "stopped"


class ComputeInstance(Base):
    """Representa una instancia virtual administrada por Cobra Online."""

    __tablename__ = "compute_instances"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(
        String(63),
        unique=True,
        index=True,
        nullable=False,
        doc="Nombre amigable de la instancia.",
    )
    image: Mapped[str] = mapped_column(
        String(128),
        nullable=False,
        doc="Identificador de la imagen de sistema utilizada.",
    )
    region: Mapped[str] = mapped_column(
        String(32),
        nullable=False,
        doc="Región lógica o física de la instancia.",
    )
    vcpus: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        doc="Número de vCPU asignadas.",
    )
    memory_gb: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        doc="Cantidad de memoria RAM en GiB.",
    )
    status: Mapped[ComputeInstanceStatus] = mapped_column(
        SqlEnum(ComputeInstanceStatus),
        default=ComputeInstanceStatus.PROVISIONING,
        nullable=False,
        doc="Estado operativo actual de la instancia.",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
        doc="Momento de creación del recurso.",
    )
