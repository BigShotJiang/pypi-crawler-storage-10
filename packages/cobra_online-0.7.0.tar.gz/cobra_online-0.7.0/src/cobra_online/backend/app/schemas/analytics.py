"""Esquemas Pydantic para pipelines de análisis de datos."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from app.models import (
    AnalyticsEngine,
    AnalyticsPipelineMode,
    AnalyticsPipelineStatus,
)


class AnalyticsPipelineBase(BaseModel):
    """Valores comunes necesarios para describir un pipeline de análisis."""

    name: str = Field(
        ..., min_length=3, max_length=63, pattern=r"^[a-z0-9-]+$",
        description="Nombre único del pipeline dentro del catálogo.",
    )
    engine: AnalyticsEngine = Field(
        ..., description="Motor distribuido que ejecutará el pipeline.",
    )
    mode: AnalyticsPipelineMode = Field(
        default=AnalyticsPipelineMode.BATCH,
        description="Modo de orquestación (batch o streaming).",
    )
    schedule: str | None = Field(
        default=None,
        min_length=3,
        max_length=64,
        description="Expresión de programación (por ejemplo cron) opcional.",
    )
    description: str | None = Field(
        default=None,
        max_length=255,
        description="Descripción breve para la operación del pipeline.",
    )


class AnalyticsPipelineCreate(AnalyticsPipelineBase):
    """Carga útil para registrar un pipeline de análisis."""

    status: AnalyticsPipelineStatus | None = Field(
        default=None,
        description="Estado inicial opcional del pipeline.",
    )


class AnalyticsPipelineUpdate(BaseModel):
    """Campos permitidos para actualizar un pipeline existente."""

    name: str | None = Field(
        default=None,
        min_length=3,
        max_length=63,
        pattern=r"^[a-z0-9-]+$",
        description="Nombre único del pipeline dentro del catálogo.",
    )
    engine: AnalyticsEngine | None = Field(
        default=None,
        description="Motor distribuido que ejecutará el pipeline.",
    )
    mode: AnalyticsPipelineMode | None = Field(
        default=None,
        description="Modo de orquestación (batch o streaming).",
    )
    schedule: str | None = Field(
        default=None,
        min_length=3,
        max_length=64,
        description="Expresión de programación (por ejemplo cron) opcional.",
    )
    description: str | None = Field(
        default=None,
        max_length=255,
        description="Descripción breve para la operación del pipeline.",
    )
    status: AnalyticsPipelineStatus | None = Field(
        default=None,
        description="Estado operativo del pipeline.",
    )


class AnalyticsPipelineRead(AnalyticsPipelineBase):
    """Representación utilizada para devolver un pipeline vía API."""

    id: int
    status: AnalyticsPipelineStatus
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class AnalyticsPipelineSummary(BaseModel):
    """Métrica agregada del estado del catálogo de pipelines."""

    total: int = Field(ge=0, description="Número total de pipelines registrados.")
    by_status: dict[str, int] = Field(
        default_factory=dict,
        description="Distribución de pipelines por estado operativo.",
    )
    by_engine: dict[str, int] = Field(
        default_factory=dict,
        description="Distribución de pipelines por motor de ejecución.",
    )
    by_mode: dict[str, int] = Field(
        default_factory=dict,
        description="Distribución de pipelines por modo de orquestación.",
    )
