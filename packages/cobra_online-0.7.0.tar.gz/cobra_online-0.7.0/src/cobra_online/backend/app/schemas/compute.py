"""Esquemas Pydantic para el módulo de cómputo."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from datetime import datetime

from pydantic import BaseModel, Field
from pydantic import ConfigDict

from app.models import ComputeInstanceStatus


class ComputeInstanceBase(BaseModel):
    """Valores comunes para describir una instancia."""

    name: str = Field(
        ..., min_length=3, max_length=63, pattern=r"^[a-z0-9-]+$",
        description=(
            "Nombre único de la instancia. Solo se permiten letras minúsculas, "
            "números y guiones."
        ),
    )
    image: str = Field(
        ..., min_length=3, max_length=128, description="Imagen base utilizada."
    )
    region: str = Field(
        ..., min_length=2, max_length=32, description="Región de despliegue."
    )
    vcpus: int = Field(..., ge=1, le=128, description="Cantidad de vCPU asignadas.")
    memory_gb: int = Field(
        ..., ge=1, le=2048, description="Memoria RAM asignada en GiB."
    )


class ComputeInstanceCreate(ComputeInstanceBase):
    """Carga útil para crear una instancia."""

    status: ComputeInstanceStatus | None = Field(
        default=None,
        description="Estado inicial opcional. Si no se envía se usará provisioning.",
    )


class ComputeInstanceUpdate(BaseModel):
    """Carga útil para actualizar parcialmente una instancia."""

    name: str | None = Field(
        default=None,
        min_length=3,
        max_length=63,
        pattern=r"^[a-z0-9-]+$",
        description=(
            "Nombre único de la instancia. Solo se permiten letras minúsculas, "
            "números y guiones."
        ),
    )
    image: str | None = Field(
        default=None,
        min_length=3,
        max_length=128,
        description="Imagen base utilizada.",
    )
    region: str | None = Field(
        default=None,
        min_length=2,
        max_length=32,
        description="Región de despliegue.",
    )
    vcpus: int | None = Field(
        default=None,
        ge=1,
        le=128,
        description="Cantidad de vCPU asignadas.",
    )
    memory_gb: int | None = Field(
        default=None,
        ge=1,
        le=2048,
        description="Memoria RAM asignada en GiB.",
    )
    status: ComputeInstanceStatus | None = Field(
        default=None,
        description="Estado operativo actual de la instancia.",
    )


class ComputeInstanceRead(ComputeInstanceBase):
    """Representación de lectura de una instancia."""

    id: int
    status: ComputeInstanceStatus
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)
