"""Esquemas utilizados en la API de Cobra Online."""


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from app.schemas.analytics import (
    AnalyticsPipelineCreate,
    AnalyticsPipelineRead,
    AnalyticsPipelineSummary,
    AnalyticsPipelineUpdate,
)
from app.schemas.compute import (
    ComputeInstanceCreate,
    ComputeInstanceRead,
    ComputeInstanceUpdate,
)
from app.schemas.database import (
    DatabaseInstanceCreate,
    DatabaseInstanceRead,
    DatabaseInstanceUpdate,
)
from app.schemas.health import ApiKeyMetrics, HealthMetrics, HealthStatus, ResourceMetrics
from app.schemas.ml import (
    MachineLearningModelCreate,
    MachineLearningModelRead,
    MachineLearningModelSummary,
    MachineLearningModelUpdate,
)
from app.schemas.network import (
    NetworkLoadBalancerCreate,
    NetworkLoadBalancerRead,
    NetworkLoadBalancerUpdate,
)
from app.schemas.security import ApiKeyCreate, ApiKeyRead, ApiKeyWithSecret
from app.schemas.storage import (
    StorageBucketCreate,
    StorageBucketRead,
    StorageBucketUpdate,
)

__all__ = [
    "AnalyticsPipelineCreate",
    "AnalyticsPipelineRead",
    "AnalyticsPipelineSummary",
    "AnalyticsPipelineUpdate",
    "ComputeInstanceCreate",
    "ComputeInstanceRead",
    "ComputeInstanceUpdate",
    "DatabaseInstanceCreate",
    "DatabaseInstanceRead",
    "DatabaseInstanceUpdate",
    "ApiKeyMetrics",
    "HealthMetrics",
    "HealthStatus",
    "ResourceMetrics",
    "NetworkLoadBalancerCreate",
    "NetworkLoadBalancerRead",
    "NetworkLoadBalancerUpdate",
    "MachineLearningModelCreate",
    "MachineLearningModelRead",
    "MachineLearningModelSummary",
    "MachineLearningModelUpdate",
    "ApiKeyCreate",
    "ApiKeyRead",
    "ApiKeyWithSecret",
    "StorageBucketCreate",
    "StorageBucketRead",
    "StorageBucketUpdate",
]
