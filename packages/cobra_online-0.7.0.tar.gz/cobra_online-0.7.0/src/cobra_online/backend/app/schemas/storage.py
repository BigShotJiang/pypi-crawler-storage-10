"""Esquemas Pydantic para el módulo de almacenamiento de objetos."""
from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field
from pydantic import ConfigDict


class StorageBucketBase(BaseModel):
    """Valores comunes para representar un bucket."""

    name: str = Field(
        ..., min_length=3, max_length=63, pattern=r"^[a-z0-9-]+$",
        description=(
            "Nombre único del bucket. Debe contener letras minúsculas, números "
            "o guiones."
        ),
    )
    region: str = Field(..., min_length=2, max_length=32, description="Región del bucket.")
    description: str | None = Field(
        default=None, max_length=255, description="Descripción opcional del bucket."
    )


class StorageBucketCreate(StorageBucketBase):
    """Carga útil para crear un bucket."""

    pass


class StorageBucketUpdate(BaseModel):
    """Carga útil para actualizar un bucket."""

    name: str | None = Field(
        default=None,
        min_length=3,
        max_length=63,
        pattern=r"^[a-z0-9-]+$",
        description=(
            "Nombre único del bucket. Debe contener letras minúsculas, números "
            "o guiones."
        ),
    )
    region: str | None = Field(
        default=None,
        min_length=2,
        max_length=32,
        description="Región del bucket.",
    )
    description: str | None = Field(
        default=None,
        max_length=255,
        description="Descripción opcional del bucket.",
    )


class StorageBucketRead(StorageBucketBase):
    """Representación de lectura de un bucket."""

    id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)
