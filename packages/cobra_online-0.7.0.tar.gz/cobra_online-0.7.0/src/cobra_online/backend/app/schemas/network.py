"""Esquemas Pydantic para los servicios de red."""

if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from datetime import datetime

from pydantic import BaseModel, Field
from pydantic import ConfigDict

from app.models import (
    NetworkLoadBalancerProtocol,
    NetworkLoadBalancerStatus,
)


class NetworkLoadBalancerBase(BaseModel):
    """Valores comunes para describir un balanceador de carga."""

    name: str = Field(
        ..., min_length=3, max_length=63, pattern=r"^[a-z0-9-]+$",
        description=(
            "Nombre único del balanceador. Solo se permiten letras minúsculas, "
            "números y guiones."
        ),
    )
    protocol: NetworkLoadBalancerProtocol = Field(
        ..., description="Protocolo de capa de aplicación o transporte balanceado.",
    )
    port: int = Field(
        ..., ge=1, le=65535, description="Puerto objetivo balanceado.",
    )
    region: str = Field(
        ..., min_length=2, max_length=32, description="Región lógica del balanceador.",
    )


class NetworkLoadBalancerCreate(NetworkLoadBalancerBase):
    """Carga útil para crear un balanceador de carga."""

    status: NetworkLoadBalancerStatus | None = Field(
        default=None,
        description="Estado inicial opcional. Si no se especifica se usará provisioning.",
    )


class NetworkLoadBalancerUpdate(BaseModel):
    """Carga útil para actualizar parcialmente un balanceador."""

    name: str | None = Field(
        default=None,
        min_length=3,
        max_length=63,
        pattern=r"^[a-z0-9-]+$",
        description=(
            "Nombre único del balanceador. Solo se permiten letras minúsculas, "
            "números y guiones."
        ),
    )
    protocol: NetworkLoadBalancerProtocol | None = Field(
        default=None,
        description="Protocolo de capa de aplicación o transporte balanceado.",
    )
    port: int | None = Field(
        default=None,
        ge=1,
        le=65535,
        description="Puerto objetivo balanceado.",
    )
    region: str | None = Field(
        default=None,
        min_length=2,
        max_length=32,
        description="Región lógica del balanceador.",
    )
    status: NetworkLoadBalancerStatus | None = Field(
        default=None,
        description="Estado operativo actual del balanceador.",
    )


class NetworkLoadBalancerRead(NetworkLoadBalancerBase):
    """Representación de lectura de un balanceador de carga."""

    id: int
    status: NetworkLoadBalancerStatus
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)
