"""Esquemas Pydantic para los endpoints de salud."""
from __future__ import annotations

from datetime import datetime

from pydantic import AnyHttpUrl, BaseModel, ConfigDict, Field


class HealthStatus(BaseModel):
    """Respuesta del endpoint de estado básico."""

    status: str = Field(default="ok", description="Estado general de la API.")
    service: str = Field(description="Nombre público del servicio expuesto.")
    timestamp: datetime = Field(description="Instante en el que se generó la respuesta.")
    locale: str = Field(description="Código ISO 639-1 utilizado en la respuesta.")
    message: str = Field(description="Descripción localizada del estado del servicio.")
    documentation_url: AnyHttpUrl = Field(
        description="Ruta a la documentación recomendada para el idioma solicitado."
    )


class ResourceMetrics(BaseModel):
    """Conteos agregados de los principales catálogos de la plataforma."""

    storage_buckets: int = Field(ge=0, description="Número de buckets registrados.")
    compute_instances: int = Field(ge=0, description="Número de instancias de cómputo.")
    database_instances: int = Field(ge=0, description="Número de bases de datos administradas.")
    network_load_balancers: int = Field(ge=0, description="Número de balanceadores de carga.")
    analytics_pipelines: int = Field(ge=0, description="Número de pipelines analíticos.")
    ml_models: int = Field(ge=0, description="Número de modelos de IA/ML registrados.")


class ApiKeyMetrics(BaseModel):
    """Métricas operativas relacionadas con las API keys administradas."""

    total: int = Field(ge=0, description="Total de API keys registradas.")
    active: int = Field(ge=0, description="API keys activas y utilizables.")
    revoked: int = Field(ge=0, description="API keys marcadas como revocadas.")
    expiring_soon: int = Field(
        ge=0,
        description="API keys activas que expirarán dentro del umbral configurado.",
    )


class HealthMetrics(BaseModel):
    """Resumen completo de métricas de salud del servicio."""

    timestamp: datetime = Field(description="Instante en el que se recopilaron las métricas.")
    resources: ResourceMetrics
    api_keys: ApiKeyMetrics
    locale: str = Field(description="Idioma aplicado a los textos de la respuesta.")
    summary: str = Field(
        description="Descripción localizada del contenido devuelto para monitoreo."
    )
    documentation_url: AnyHttpUrl = Field(
        description="Ruta a la documentación recomendada para el idioma solicitado."
    )

    model_config = ConfigDict(extra="forbid")

