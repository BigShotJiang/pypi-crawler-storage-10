"""Esquemas Pydantic para el módulo de bases de datos administradas."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from datetime import datetime

from pydantic import BaseModel, Field
from pydantic import ConfigDict

from app.models import DatabaseEngine, DatabaseInstanceStatus


class DatabaseInstanceBase(BaseModel):
    """Valores comunes para describir una instancia de base de datos."""

    name: str = Field(
        ..., min_length=3, max_length=63, pattern=r"^[a-z0-9-]+$",
        description="Nombre único para la base de datos administrada.",
    )
    engine: DatabaseEngine = Field(
        ..., description="Motor de base de datos a desplegar."
    )
    version: str = Field(
        ..., min_length=1, max_length=16, description="Versión específica del motor."
    )
    region: str = Field(
        ..., min_length=2, max_length=32, description="Región donde se hospedará el servicio."
    )
    storage_gb: int = Field(
        ..., ge=10, le=16384, description="Almacenamiento asignado en GiB."
    )


class DatabaseInstanceCreate(DatabaseInstanceBase):
    """Carga útil para crear un servicio de base de datos."""

    status: DatabaseInstanceStatus | None = Field(
        default=None,
        description="Estado inicial opcional. Por defecto es provisioning.",
    )


class DatabaseInstanceUpdate(BaseModel):
    """Carga útil para actualizar parcialmente una instancia administrada."""

    name: str | None = Field(
        default=None,
        min_length=3,
        max_length=63,
        pattern=r"^[a-z0-9-]+$",
        description="Nombre único para la base de datos administrada.",
    )
    engine: DatabaseEngine | None = Field(
        default=None,
        description="Motor de base de datos a desplegar.",
    )
    version: str | None = Field(
        default=None,
        min_length=1,
        max_length=16,
        description="Versión específica del motor.",
    )
    region: str | None = Field(
        default=None,
        min_length=2,
        max_length=32,
        description="Región donde se hospedará el servicio.",
    )
    storage_gb: int | None = Field(
        default=None,
        ge=10,
        le=16384,
        description="Almacenamiento asignado en GiB.",
    )
    status: DatabaseInstanceStatus | None = Field(
        default=None,
        description="Estado operativo de la base de datos.",
    )


class DatabaseInstanceRead(DatabaseInstanceBase):
    """Representación de lectura de un servicio de base de datos."""

    id: int
    status: DatabaseInstanceStatus
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)
