"""Esquemas Pydantic para los módulos de seguridad."""
from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class ApiKeyBase(BaseModel):
    """Campos comunes para describir una API key."""

    name: str = Field(
        ..., min_length=3, max_length=64, description="Nombre descriptivo de la API key."
    )
    expires_at: datetime | None = Field(
        default=None,
        description="Fecha opcional en la que la API key dejará de ser válida.",
    )


class ApiKeyCreate(ApiKeyBase):
    """Carga útil necesaria para crear una API key nueva."""


class ApiKeyRead(ApiKeyBase):
    """Representación de lectura de una API key almacenada."""

    id: int
    key_prefix: str = Field(
        ..., min_length=4, max_length=12, description="Prefijo identificador de la API key."
    )
    created_at: datetime
    last_used_at: datetime | None = None
    revoked: bool

    model_config = ConfigDict(from_attributes=True)


class ApiKeyWithSecret(ApiKeyRead):
    """Respuesta utilizada al crear una API key que incluye el secreto completo."""

    secret: str = Field(
        ..., min_length=32, description="Valor completo de la API key. Se muestra solo una vez."
    )

