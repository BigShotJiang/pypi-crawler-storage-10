"""Esquemas Pydantic para modelos de IA y Machine Learning."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from datetime import datetime, timezone

from pydantic import BaseModel, ConfigDict, Field, field_serializer

from app.models import (
    MachineLearningFramework,
    MachineLearningModelStatus,
)


class MachineLearningModelBase(BaseModel):
    """Campos comunes para describir un modelo de IA/ML."""

    name: str = Field(
        ...,
        min_length=3,
        max_length=63,
        pattern=r"^[a-z0-9-]+$",
        description=(
            "Nombre único del modelo. Debe usar minúsculas, números o guiones para "
            "facilitar su despliegue en endpoints."
        ),
    )
    framework: MachineLearningFramework = Field(
        ..., description="Framework empleado para entrenar o servir el modelo."
    )
    version: str = Field(
        ...,
        min_length=1,
        max_length=32,
        description="Versión o etiqueta que identifica el artefacto del modelo.",
    )
    description: str | None = Field(
        default=None,
        max_length=255,
        description="Descripción legible del modelo y su propósito.",
    )
    endpoint_url: str | None = Field(
        default=None,
        max_length=255,
        description="Endpoint opcional donde se publica el modelo para inferencias.",
    )


class MachineLearningModelCreate(MachineLearningModelBase):
    """Carga útil para registrar un nuevo modelo."""

    status: MachineLearningModelStatus | None = Field(
        default=None,
        description="Estado inicial del modelo. Si no se proporciona se usa 'draft'.",
    )
    last_trained_at: datetime | None = Field(
        default=None,
        description="Fecha de la última sesión de entrenamiento exitosa si aplica.",
    )


class MachineLearningModelUpdate(BaseModel):
    """Carga útil para actualizar parcialmente un modelo."""

    name: str | None = Field(
        default=None,
        min_length=3,
        max_length=63,
        pattern=r"^[a-z0-9-]+$",
        description="Nombre único del modelo.",
    )
    framework: MachineLearningFramework | None = Field(
        default=None,
        description="Framework empleado para entrenar o servir el modelo.",
    )
    version: str | None = Field(
        default=None,
        min_length=1,
        max_length=32,
        description="Versión o etiqueta del modelo.",
    )
    description: str | None = Field(
        default=None,
        max_length=255,
        description="Descripción legible del modelo.",
    )
    endpoint_url: str | None = Field(
        default=None,
        max_length=255,
        description="Endpoint donde se publica el modelo para inferencias.",
    )
    status: MachineLearningModelStatus | None = Field(
        default=None,
        description="Estado operativo actual del modelo.",
    )
    last_trained_at: datetime | None = Field(
        default=None,
        description="Fecha de la última sesión de entrenamiento exitosa.",
    )


class MachineLearningModelRead(MachineLearningModelBase):
    """Representación completa de un modelo registrado."""

    id: int
    status: MachineLearningModelStatus
    last_trained_at: datetime | None
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)

    @field_serializer("last_trained_at", when_used="json")
    def serialize_last_trained_at(
        self, value: datetime | None
    ) -> str | None:
        """Devuelve el valor en formato ISO conservando la zona horaria UTC."""

        if value is None:
            return None
        if value.tzinfo is None or value.tzinfo.utcoffset(value) is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc).isoformat()


class MachineLearningModelSummary(BaseModel):
    """Métricas agregadas del catálogo de modelos de IA/ML."""

    total: int = Field(
        ge=0,
        description="Número total de modelos registrados en la plataforma.",
    )
    by_status: dict[str, int] = Field(
        default_factory=dict,
        description="Distribución de modelos por estado operativo.",
    )
    by_framework: dict[str, int] = Field(
        default_factory=dict,
        description="Distribución de modelos por framework utilizado.",
    )
