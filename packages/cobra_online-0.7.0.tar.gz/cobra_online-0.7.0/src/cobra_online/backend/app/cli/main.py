"""CLI enriquecida para Cobra Online usando FletPlus."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

import json
import logging
import subprocess
import sys
import threading
import time
import webbrowser
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Sequence
from urllib import error, request

_OPTIONAL_DEPENDENCIES = {"flet", "fletplus"}

try:
    import flet as ft
    from fletplus import (
        FletPlusApp,
        FloatingActionButton,
        InfoButton,
        PrimaryButton,
        SecondaryButton,
        SmartTable,
        SuccessButton,
        WarningButton,
        show_notification,
    )
    from fletplus.components.accessibility_panel import (
        AccessibilityPanel,
        AccessibilityPreferences,
    )
    from fletplus.themes.theme_manager import ThemeManager
except ModuleNotFoundError as exc:  # pragma: no cover - depende del entorno de ejecución
    missing = (exc.name or "").partition(".")[0] or str(exc)
    if missing in _OPTIONAL_DEPENDENCIES:
        message = (
            "La CLI de Cobra Online requiere las dependencias opcionales "
            "'flet' y 'fletplus'. Instálalas con `pip install cobra-online-api[cli]` "
            "o añádelas manualmente antes de ejecutar la interfaz gráfica."
        )
        raise ModuleNotFoundError(message, name=missing) from exc
    raise
from sqlalchemy import text

if __package__ is None or __package__ == "":  # pragma: no cover - ejecución directa
    package_root = Path(__file__).resolve().parents[1]
    project_root = package_root.parent
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))
    __package__ = package_root.name

from app.api import deps
from app.core import i18n
from app.core.config import settings
from app.db import init_db

_BACKEND_ROOT = Path(__file__).resolve().parents[1]


@dataclass
class CliState:
    """Estado compartido entre los componentes de la CLI."""

    page: ft.Page | None = None
    server_process: subprocess.Popen[bytes] | None = None
    status_text: ft.Text | None = None
    status_icon: ft.Icon | None = None
    db_status_text: ft.Text | None = None
    health_status_text: ft.Text | None = None
    health_message_text: ft.Text | None = None
    health_doc_link: ft.TextButton | None = None
    health_updated_text: ft.Text | None = None
    metrics_table: SmartTable | None = None
    metrics_container: ft.Container | None = None
    log_view: ft.ListView | None = None
    theme_manager: ThemeManager | None = None
    theme_status_chip: ft.Chip | None = None
    accessibility_preferences: AccessibilityPreferences = field(
        default_factory=AccessibilityPreferences
    )
    log_entries: list[str] = field(default_factory=list)
    command_palette: object | None = None
    auto_refresh_switch: ft.Switch | None = None
    auto_refresh_status_text: ft.Text | None = None
    health_interval_slider: ft.Slider | None = None
    health_interval_text: ft.Text | None = None
    auto_health_enabled: bool = False
    auto_health_interval: int = 90
    _auto_refresh_thread: threading.Thread | None = None
    _auto_refresh_stop_event: threading.Event = field(default_factory=threading.Event)
    lock: threading.Lock = field(default_factory=threading.Lock)

    def attach_page(self, page: ft.Page) -> None:
        self.page = page
        self.append_log("CLI inicializada correctamente.")
        if self.page is not None:

            def _on_close(_event: ft.ControlEvent | None = None) -> None:
                self.disable_auto_refresh()
                self.stop_server(silent=True)

            self.page.on_close = _on_close

    def bind_theme_manager(self, theme: ThemeManager) -> None:
        """Guarda una referencia al gestor de temas activo."""

        self.theme_manager = theme

    def register_command_palette(self, palette: object) -> None:
        """Permite abrir la paleta de comandos desde el estado."""

        self.command_palette = palette

    # ------------------------------------------------------------------
    def append_log(self, message: str) -> None:
        timestamp = datetime.now().strftime("%H:%M:%S")
        entry = f"[{timestamp}] {message}"
        with self.lock:
            self.log_entries.append(entry)
            if len(self.log_entries) > 250:
                self.log_entries = self.log_entries[-250:]
        if self.log_view is not None:
            self.log_view.controls.append(ft.Text(entry))
            self.log_view.update()

    # ------------------------------------------------------------------
    def _notify(self, title: str, body: str) -> None:
        try:
            show_notification(title, body)
        finally:
            if self.page is not None:
                self.page.snack_bar = ft.SnackBar(ft.Text(body), bgcolor=ft.Colors.BLUE_GREY_700)
                self.page.snack_bar.open = True
                self.page.update()

    def open_command_palette(self, _event: ft.ControlEvent | None = None) -> None:
        """Abre la paleta de comandos contextual."""

        if self.page is None or self.command_palette is None:
            self.append_log("No hay paleta de comandos disponible.")
            return

        try:
            self.command_palette.open(self.page)  # type: ignore[attr-defined]
        except AttributeError:
            logging.getLogger(__name__).warning("Paleta de comandos incompatible con la página actual.")

    # ------------------------------------------------------------------
    def bind_status(self, text: ft.Text, icon: ft.Icon) -> None:
        self.status_text = text
        self.status_icon = icon
        self._refresh_status_label()

    def bind_db_status(self, text: ft.Text) -> None:
        self.db_status_text = text

    def bind_theme_status(self, chip: ft.Chip) -> None:
        self.theme_status_chip = chip
        self._refresh_theme_chip()

    def bind_auto_refresh_switch(self, switch: ft.Switch) -> None:
        self.auto_refresh_switch = switch
        self._update_auto_refresh_status()

    def bind_auto_refresh_status(self, text: ft.Text) -> None:
        self.auto_refresh_status_text = text
        self._update_auto_refresh_status()

    def bind_health_interval_slider(self, slider: ft.Slider) -> None:
        self.health_interval_slider = slider
        if getattr(slider, "page", None) is not None:
            slider.value = float(self.auto_health_interval)
            slider.update()

    def bind_health_interval_text(self, text: ft.Text) -> None:
        self.health_interval_text = text
        self._update_interval_text()

    def _refresh_theme_chip(self) -> None:
        if self.theme_status_chip is None:
            return

        dark_mode = bool(getattr(self.theme_manager, "dark_mode", False))
        label = "Tema oscuro" if dark_mode else "Tema claro"
        icon_name = ft.icons.DARK_MODE if dark_mode else ft.icons.LIGHT_MODE
        color = ft.Colors.AMBER_300 if dark_mode else ft.Colors.BLUE_300
        self.theme_status_chip.label = ft.Text(label)
        self.theme_status_chip.avatar = ft.Icon(icon_name, color=color)
        if getattr(self.theme_status_chip, "page", None) is not None:
            self.theme_status_chip.update()

    def _refresh_metrics_table(self) -> None:
        if self.metrics_table is None or self.metrics_container is None:
            return

        self.metrics_container.content = self.metrics_table.build()
        if getattr(self.metrics_container, "page", None) is not None:
            self.metrics_container.update()

    def bind_health_widgets(
        self,
        status_text: ft.Text,
        message_text: ft.Text,
        doc_link: ft.TextButton,
        table: SmartTable,
        table_container: ft.Container,
        updated_text: ft.Text,
    ) -> None:
        self.health_status_text = status_text
        self.health_message_text = message_text
        self.health_doc_link = doc_link
        self.metrics_table = table
        self.metrics_container = table_container
        self.health_updated_text = updated_text
        self._refresh_metrics_table()

    def bind_log_view(self, log_view: ft.ListView) -> None:
        self.log_view = log_view
        for entry in self.log_entries:
            self.log_view.controls.append(ft.Text(entry))
        self.log_view.update()

    def _update_interval_text(self) -> None:
        if self.health_interval_text is None:
            return
        self.health_interval_text.value = (
            f"Intervalo automático: {self.auto_health_interval} segundos"
            if self.auto_health_enabled
            else f"Intervalo preferido: {self.auto_health_interval} segundos"
        )
        if getattr(self.health_interval_text, "page", None) is not None:
            self.health_interval_text.update()

    def _update_auto_refresh_status(self) -> None:
        if self.auto_refresh_switch is not None:
            self.auto_refresh_switch.value = self.auto_health_enabled
            if getattr(self.auto_refresh_switch, "page", None) is not None:
                self.auto_refresh_switch.update()
        if self.auto_refresh_status_text is not None:
            status = "activada" if self.auto_health_enabled else "desactivada"
            color = (
                ft.Colors.GREEN_400 if self.auto_health_enabled else ft.Colors.ON_SURFACE_VARIANT
            )
            self.auto_refresh_status_text.value = f"Auto-actualización {status}."
            self.auto_refresh_status_text.color = color
            if getattr(self.auto_refresh_status_text, "page", None) is not None:
                self.auto_refresh_status_text.update()

    # ------------------------------------------------------------------
    def _refresh_status_label(self) -> None:
        if self.status_text is None or self.status_icon is None:
            return
        if self.server_process is not None and self.server_process.poll() is None:
            self.status_text.value = "API en ejecución"
            self.status_text.color = ft.Colors.GREEN_400
            self.status_icon.name = ft.icons.PLAY_CIRCLE_FILL_OUTLINED
            self.status_icon.color = ft.Colors.GREEN_400
        else:
            self.status_text.value = "API detenida"
            self.status_text.color = ft.Colors.RED_400
            self.status_icon.name = ft.icons.STOP_CIRCLE_OUTLINED
            self.status_icon.color = ft.Colors.RED_400
        self.status_text.update()
        self.status_icon.update()

    # ------------------------------------------------------------------
    def toggle_dark_mode(self, _event: ft.ControlEvent | None = None) -> None:
        if self.theme_manager is None:
            self.append_log("No hay gestor de temas disponible para alternar el modo.")
            return

        self.theme_manager.toggle_dark_mode()
        mode_label = "oscuro" if getattr(self.theme_manager, "dark_mode", False) else "claro"
        self.append_log(f"Tema alternado al modo {mode_label}.")
        self._refresh_theme_chip()
        if self.page is not None:
            self._notify("Tema actualizado", f"Modo {mode_label} activado.")

    # ------------------------------------------------------------------
    def clear_logs(self, _event: ft.ControlEvent | None = None) -> None:
        with self.lock:
            self.log_entries.clear()
        if self.log_view is not None:
            self.log_view.controls.clear()
            self.log_view.update()
        self.append_log("Registro limpiado manualmente.")
        self._notify("Registro", "Se vació el historial de mensajes.")

    def copy_base_url(self, _event: ft.ControlEvent | None = None) -> None:
        base_url = self._base_url()
        if self.page is not None:
            try:
                self.page.set_clipboard(base_url)
            except AttributeError:
                logging.getLogger(__name__).debug("Clipboard no disponible en la página actual.")
        self.append_log(f"URL base copiada al portapapeles: {base_url}")
        self._notify("URL copiada", "La dirección de la API está lista para compartir.")

    # ------------------------------------------------------------------
    def start_server(self, _event: ft.ControlEvent | None = None) -> None:
        if self.server_process is not None and self.server_process.poll() is None:
            self.append_log("Se ignoró el arranque: la API ya está activa.")
            self._notify("Cobra Online", "La API ya se encuentra en ejecución.")
            return

        command = [
            sys.executable,
            "-m",
            "uvicorn",
            "app.main:app",
            "--host",
            settings.api_host,
            "--port",
            str(settings.api_port),
        ]
        self.append_log("Iniciando API con Uvicorn...")
        try:
            self.server_process = subprocess.Popen(
                command,
                cwd=str(_BACKEND_ROOT),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
            )
        except OSError as exc:  # pragma: no cover - depende del sistema
            self.append_log(f"Error al iniciar la API: {exc}")
            self._notify("Error", f"No se pudo iniciar la API: {exc}")
            return

        threading.Thread(target=self._stream_process_logs, daemon=True).start()
        self._refresh_status_label()
        self._notify("Cobra Online", "API iniciada correctamente.")

    # ------------------------------------------------------------------
    def stop_server(self, _event: ft.ControlEvent | None = None, *, silent: bool = False) -> None:
        if self.server_process is None or self.server_process.poll() is not None:
            if not silent:
                self.append_log("No hay procesos activos de Uvicorn.")
                self._notify("Cobra Online", "La API ya está detenida.")
            return

        self.append_log("Deteniendo API...")
        self.server_process.terminate()
        try:
            self.server_process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            self.append_log("Tiempo de espera agotado. Forzando cierre.")
            self.server_process.kill()
            self.server_process.wait(timeout=5)
        finally:
            self.server_process = None
        self._refresh_status_label()
        if not silent:
            self._notify("Cobra Online", "API detenida exitosamente.")

    # ------------------------------------------------------------------
    def restart_server(self, _event: ft.ControlEvent | None = None) -> None:
        self.append_log("Reiniciando API...")
        self.stop_server(silent=True)
        time.sleep(0.2)
        self.start_server()
        self._notify("Cobra Online", "API reiniciada correctamente.")

    # ------------------------------------------------------------------
    def _stream_process_logs(self) -> None:
        proc = self.server_process
        if proc is None or proc.stdout is None:
            return
        for line in iter(proc.stdout.readline, b""):
            text = line.decode(errors="replace").rstrip()
            if text:
                self.append_log(text)
        self.append_log("Proceso de API finalizado.")
        self.server_process = None
        self._refresh_status_label()

    # ------------------------------------------------------------------
    def export_logs(self, _event: ft.ControlEvent | None = None) -> None:
        if not self.log_entries:
            self._notify("Registro", "Todavía no hay mensajes para exportar.")
            return

        logs_dir = _BACKEND_ROOT / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        filename = f"cli-log-{datetime.now():%Y%m%d-%H%M%S}.txt"
        file_path = logs_dir / filename
        file_path.write_text("\n".join(self.log_entries), encoding="utf-8")
        self.append_log(f"Registro exportado a {file_path}.")
        self._notify("Registro", f"Se guardó un archivo con los logs en {file_path}.")

    # ------------------------------------------------------------------
    def open_documentation(self, _event: ft.ControlEvent | None = None) -> None:
        locale = "es"
        url = i18n.documentation_url(locale)
        webbrowser.open(url, new=2, autoraise=True)
        self.append_log(f"Documentación abierta en el navegador: {url}")
        self._notify("Cobra Online", "Documentación abierta en el navegador predeterminado.")

    # ------------------------------------------------------------------
    def _base_url(self) -> str:
        host = settings.api_host
        if host in {"0.0.0.0", "::"}:
            host = "127.0.0.1"
        return f"http://{host}:{settings.api_port}{settings.api_v1_prefix}"

    def run_health_check(
        self, _event: ft.ControlEvent | None = None, *, silent: bool = False
    ) -> None:
        status_url = f"{self._base_url()}/health/"
        metrics_url = f"{self._base_url()}/health/metrics?expiring_within_days=7"
        self.append_log(f"Solicitando estado de salud en {status_url}...")
        try:
            status_payload = _http_json(status_url)
            message = status_payload.get("message", "")
            summary = status_payload.get("status", "desconocido").capitalize()
            documentation_url = status_payload.get("documentation_url")
            self.append_log(f"Estado de la API: {summary} - {message}")
            self._update_health(status_payload)
            if not silent:
                self._notify(
                    "Salud de Cobra Online", message or "Estado recuperado correctamente."
                )
        except RuntimeError as exc:
            self.append_log(str(exc))
            if not silent:
                self._notify("Error de salud", str(exc))
            return

        try:
            metrics_payload = _http_json(metrics_url)
        except RuntimeError as exc:
            self.append_log(str(exc))
            if not silent:
                self._notify("Error de métricas", str(exc))
            return
        self._update_metrics(metrics_payload)
        self.append_log("Métricas de salud actualizadas.")

        if self.health_updated_text is not None:
            self.health_updated_text.value = f"Última actualización: {datetime.now():%H:%M:%S}"
            self.health_updated_text.update()

    def update_health_interval(self, seconds: int) -> None:
        seconds = max(30, min(seconds, 600))
        if seconds == self.auto_health_interval:
            self._update_interval_text()
            return
        self.auto_health_interval = seconds
        if self.health_interval_slider is not None:
            self.health_interval_slider.value = float(seconds)
            if getattr(self.health_interval_slider, "page", None) is not None:
                self.health_interval_slider.update()
        self._update_interval_text()
        self.append_log(f"Intervalo de diagnóstico ajustado a {seconds} segundos.")
        if self.auto_health_enabled:
            self._restart_auto_refresh_thread()
        self._notify("Diagnóstico", f"El intervalo automático ahora es de {seconds} s.")

    def _restart_auto_refresh_thread(self) -> None:
        stop_event = self._auto_refresh_stop_event
        stop_event.set()
        thread = self._auto_refresh_thread
        if thread is not None and thread.is_alive():
            thread.join(timeout=0.5)
        self._auto_refresh_stop_event = threading.Event()
        if self.auto_health_enabled:
            self._start_auto_refresh_thread()

    def _start_auto_refresh_thread(self) -> None:
        stop_event = self._auto_refresh_stop_event

        def _worker() -> None:
            while not stop_event.wait(self.auto_health_interval):
                self.run_health_check(silent=True)
            if not self.auto_health_enabled:
                self.append_log("Auto-actualización de salud detenida.")

        thread = threading.Thread(target=_worker, daemon=True)
        self._auto_refresh_thread = thread
        thread.start()

    def toggle_auto_health_refresh(
        self,
        _event: ft.ControlEvent | None = None,
        *,
        enabled: bool | None = None,
        silent: bool = False,
    ) -> None:
        desired_state = self.auto_health_enabled if enabled is None else bool(enabled)
        if enabled is None:
            desired_state = not self.auto_health_enabled

        if desired_state and not self.auto_health_enabled:
            self.auto_health_enabled = True
            self.append_log(
                f"Auto-actualización de salud activada cada {self.auto_health_interval} segundos."
            )
            self.run_health_check(silent=True)
            self._auto_refresh_stop_event = threading.Event()
            self._start_auto_refresh_thread()
            if not silent:
                self._notify(
                    "Diagnóstico",
                    "Auto-actualización de métricas activada en segundo plano.",
                )
        elif not desired_state and self.auto_health_enabled:
            self.auto_health_enabled = False
            self._auto_refresh_stop_event.set()
            thread = self._auto_refresh_thread
            if thread is not None and thread.is_alive():
                thread.join(timeout=0.5)
            self._auto_refresh_thread = None
            self._auto_refresh_stop_event = threading.Event()
            self.append_log("Auto-actualización de salud desactivada.")
            if not silent:
                self._notify("Diagnóstico", "Auto-actualización desactivada.")

        self._update_auto_refresh_status()
        self._update_interval_text()

    def disable_auto_refresh(self) -> None:
        self.toggle_auto_health_refresh(enabled=False, silent=True)

    def apply_accessibility_preferences(
        self, preferences: AccessibilityPreferences
    ) -> None:
        """Aplica las preferencias de accesibilidad seleccionadas por la persona usuaria."""

        self.accessibility_preferences = preferences
        if self.page is None:
            return

        preferences.apply(self.page, self.theme_manager)
        self.append_log("Preferencias de accesibilidad aplicadas.")
        self._notify(
            "Accesibilidad",
            "Se actualizaron las opciones de contraste, texto y ayudas visuales.",
        )

    def _update_health(self, payload: dict[str, object]) -> None:
        if self.health_status_text is None or self.health_message_text is None:
            return
        status = payload.get("status", "desconocido")
        message = payload.get("message", "Sin descripción disponible.")
        doc_url = payload.get("documentation_url")
        self.health_status_text.value = str(status).upper()
        self.health_status_text.color = ft.Colors.GREEN_400 if status == "ok" else ft.Colors.AMBER_400
        self.health_message_text.value = str(message)
        if self.health_doc_link is not None:
            self.health_doc_link.url = str(doc_url) if doc_url else ""
            self.health_doc_link.disabled = not bool(doc_url)
        self.health_status_text.update()
        self.health_message_text.update()
        if self.health_doc_link is not None:
            self.health_doc_link.update()

    def _update_metrics(self, payload: dict[str, object]) -> None:
        if self.metrics_table is None:
            return
        rows: list[ft.DataRow] = []
        for key, value in sorted(payload.items()):
            if key in {"summary", "documentation_url", "locale"}:
                continue
            rows.append(
                ft.DataRow(
                    cells=[
                        ft.DataCell(ft.Text(key.replace("_", " ").title())),
                        ft.DataCell(ft.Text(str(value))),
                    ]
                )
            )
        self.metrics_table.rows = rows
        self.metrics_table.total_rows = len(rows)
        self.metrics_table.current_page = 0
        self._refresh_metrics_table()

    # ------------------------------------------------------------------
    def check_database(self, _event: ft.ControlEvent | None = None) -> None:
        init_db()
        self.append_log("Verificando conexión a la base de datos...")
        try:
            with deps.SessionLocal() as session:
                session.execute(text("SELECT 1"))
            if self.db_status_text is not None:
                self.db_status_text.value = "Conexión verificada"
                self.db_status_text.color = ft.Colors.GREEN_400
                self.db_status_text.update()
            self.append_log("Base de datos accesible correctamente.")
            self._notify("Base de datos", "Conexión verificada satisfactoriamente.")
        except Exception as exc:  # pragma: no cover - depende de la configuración local
            if self.db_status_text is not None:
                self.db_status_text.value = "Error de conexión"
                self.db_status_text.color = ft.Colors.RED_400
                self.db_status_text.update()
            self.append_log(f"Error al verificar la base de datos: {exc}")
            self._notify("Base de datos", f"No fue posible verificar la conexión: {exc}")


# ----------------------------------------------------------------------
def _http_json(url: str, *, timeout: int = 5) -> dict[str, object]:
    """Realiza una petición GET y devuelve la respuesta decodificada."""

    req = request.Request(url, headers={"Accept": "application/json"})
    try:
        with request.urlopen(req, timeout=timeout) as response:
            raw = response.read().decode()
    except error.URLError as exc:  # pragma: no cover - depende del entorno
        raise RuntimeError(f"No se pudo obtener {url}: {exc.reason}") from exc
    except error.HTTPError as exc:  # pragma: no cover - depende del entorno
        raise RuntimeError(f"La petición a {url} falló con código {exc.code}") from exc

    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:  # pragma: no cover - depende de la API
        raise RuntimeError("La respuesta no contiene JSON válido.") from exc


# ----------------------------------------------------------------------
class CobraCliApp(FletPlusApp):
    """Aplicación principal que construye la interfaz usando FletPlus."""

    def __init__(self, page: ft.Page, state: CliState) -> None:
        self.state = state
        routes = {
            "panel": self._build_dashboard,
            "configuracion": self._build_configuration,
            "diagnostico": self._build_diagnostics,
            "accesibilidad": self._build_accessibility,
        }
        sidebar_items = [
            {"title": "Panel", "icon": ft.icons.DASHBOARD_OUTLINED},
            {"title": "Configuración", "icon": ft.icons.SETTINGS_OUTLINED},
            {"title": "Diagnóstico", "icon": ft.icons.HEALTH_AND_SAFETY},
            {"title": "Accesibilidad", "icon": ft.icons.ACCESSIBILITY_NEW},
        ]
        commands = {
            "Iniciar API": lambda: self.state.start_server(),
            "Detener API": lambda: self.state.stop_server(),
            "Reiniciar API": lambda: self.state.restart_server(),
            "Exportar registro": lambda: self.state.export_logs(),
            "Abrir documentación": lambda: self.state.open_documentation(),
            "Comprobar salud": lambda: self.state.run_health_check(),
            "Verificar base de datos": lambda: self.state.check_database(),
            "Alternar tema": lambda: self.state.toggle_dark_mode(),
            "Copiar URL base": lambda: self.state.copy_base_url(),
            "Limpiar registro": lambda: self.state.clear_logs(),
            "Activar auto diagnóstico": lambda: self.state.toggle_auto_health_refresh(
                enabled=True
            ),
            "Desactivar auto diagnóstico": lambda: self.state.toggle_auto_health_refresh(
                enabled=False
            ),
            "Mostrar accesibilidad": lambda: self.navigate_to("accesibilidad"),
            "Paleta de comandos": lambda: self.state.open_command_palette(),
        }
        theme_config = {
            "palette": "blue",
            "tokens": {
                "color_scheme_seed": ft.Colors.BLUE_500,
                "use_material3": True,
            },
        }
        super().__init__(
            page,
            routes,
            sidebar_items=sidebar_items,
            commands=commands,
            title="CLI de Cobra Online",
            theme_config=theme_config,
        )
        self.state.bind_theme_manager(self.theme)
        self.state.register_command_palette(self.command_palette)
        page.floating_action_button = FloatingActionButton(
            ft.icons.SEARCH,
            label="Comandos",
            theme=self.theme,
            tooltip="Abrir paleta de comandos (Ctrl+K)",
            on_click=lambda _: self.state.open_command_palette(),
        )
        page.floating_action_button_location = ft.FloatingActionButtonLocation.END_FLOAT

        self.shortcuts.register("s", lambda: self.state.start_server(), ctrl=True)
        self.shortcuts.register("x", lambda: self.state.stop_server(), ctrl=True)
        self.shortcuts.register("r", lambda: self.state.restart_server(), ctrl=True)
        self.shortcuts.register("e", lambda: self.state.export_logs(), ctrl=True)
        self.shortcuts.register("b", lambda: self.state.check_database(), ctrl=True)
        self.shortcuts.register("t", lambda: self.state.toggle_dark_mode(), ctrl=True)
        self.shortcuts.register(
            "a", lambda: self.navigate_to("accesibilidad"), ctrl=True
        )
        self.shortcuts.register(
            "c", lambda: self.state.copy_base_url(), ctrl=True, shift=True
        )
        self.shortcuts.register(
            "l", lambda: self.state.clear_logs(), ctrl=True, shift=True
        )
        self.shortcuts.register(
            "h",
            lambda: self.state.toggle_auto_health_refresh(),
            ctrl=True,
            shift=True,
        )

        self.state.attach_page(page)

    # ------------------------------------------------------------------
    def navigate_to(self, route: str) -> None:
        """Carga la ruta solicitada si existe."""

        if route not in self._routes_order:
            logging.getLogger(__name__).warning("Ruta desconocida: %s", route)
            return
        index = self._routes_order.index(route)
        self._activate_route(index)

    # ------------------------------------------------------------------
    def _build_dashboard(self) -> ft.Control:
        status_icon = ft.Icon(name=ft.icons.STOP_CIRCLE_OUTLINED, color=ft.Colors.RED_400, size=36)
        status_text = ft.Text("API detenida", size=20, weight=ft.FontWeight.W_600)
        self.state.bind_status(status_text, status_icon)

        start_button = PrimaryButton(
            "Iniciar API",
            icon=ft.icons.PLAY_ARROW_ROUNDED,
            theme=self.theme,
            on_click=self.state.start_server,
        )
        stop_button = WarningButton(
            "Detener API",
            icon=ft.icons.STOP_CIRCLE,
            theme=self.theme,
            on_click=self.state.stop_server,
        )
        restart_button = SecondaryButton(
            "Reiniciar API",
            icon=ft.icons.REPLAY_CIRCLE_FILLED,
            theme=self.theme,
            on_click=self.state.restart_server,
        )
        health_button = InfoButton(
            "Comprobar salud",
            icon=ft.icons.MONITOR_HEART,
            theme=self.theme,
            on_click=self.state.run_health_check,
        )
        docs_button = SecondaryButton(
            "Abrir documentación",
            icon=ft.icons.DESCRIPTION_OUTLINED,
            theme=self.theme,
            on_click=self.state.open_documentation,
        )
        export_button = SecondaryButton(
            "Guardar registro",
            icon=ft.icons.SAVE_ALT,
            theme=self.theme,
            on_click=self.state.export_logs,
        )
        copy_url_button = SuccessButton(
            "Copiar URL base",
            icon=ft.icons.CONTENT_COPY,
            theme=self.theme,
            on_click=self.state.copy_base_url,
        )
        clear_log_button = WarningButton(
            "Limpiar registro",
            icon=ft.icons.CLEAR_ALL,
            theme=self.theme,
            on_click=self.state.clear_logs,
        )
        theme_button = SecondaryButton(
            "Alternar tema",
            icon=ft.icons.DARK_MODE,
            theme=self.theme,
            on_click=self.state.toggle_dark_mode,
        )
        palette_button = InfoButton(
            "Paleta de comandos",
            icon=ft.icons.TRAVEL_EXPLORE,
            theme=self.theme,
            on_click=self.state.open_command_palette,
        )

        theme_chip = ft.Chip(label=ft.Text("Tema claro"), avatar=ft.Icon(ft.icons.LIGHT_MODE, color=ft.Colors.BLUE_300))
        self.state.bind_theme_status(theme_chip)

        log_view = ft.ListView(expand=True, spacing=6, auto_scroll=True)
        self.state.bind_log_view(log_view)

        controls: Sequence[ft.Control] = [
            ft.Text(
                "Panel de operaciones",
                size=26,
                weight=ft.FontWeight.W_700,
            ),
            ft.Text(
                "Administra el ciclo de vida de la API y accede a herramientas rápidas.",
                size=14,
                color=ft.Colors.ON_SURFACE_VARIANT,
            ),
            ft.Container(
                content=ft.Row(
                    [status_icon, status_text],
                    spacing=12,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                padding=ft.padding.all(16),
                bgcolor=ft.Colors.with_opacity(0.08, ft.Colors.BLUE_200),
                border_radius=ft.border_radius.all(18),
            ),
            ft.Row(
                [
                    start_button,
                    stop_button,
                    restart_button,
                    health_button,
                    docs_button,
                ],
                spacing=12,
                wrap=True,
            ),
            ft.Row(
                [
                    theme_chip,
                    theme_button,
                    palette_button,
                    export_button,
                    copy_url_button,
                    clear_log_button,
                ],
                spacing=12,
                wrap=True,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            ft.Text("Registro en vivo", size=16, weight=ft.FontWeight.W_600),
            ft.Container(
                content=log_view,
                bgcolor=ft.Colors.with_opacity(0.04, ft.Colors.BLACK),
                border_radius=ft.border_radius.all(12),
                padding=ft.padding.symmetric(vertical=12, horizontal=16),
                height=260,
            ),
        ]
        return ft.Column(controls, expand=True, spacing=18)

    # ------------------------------------------------------------------
    def _build_configuration(self) -> ft.Control:
        info_rows = []
        for key, value in [
            ("Nombre", settings.project_name),
            ("Descripción", settings.description),
            ("Versión", settings.version),
            ("Host", settings.api_host),
            ("Puerto", settings.api_port),
            ("Prefijo API", settings.api_v1_prefix),
            ("Base de datos", settings.database_url),
        ]:
            info_rows.append(
                ft.Container(
                    content=ft.Column(
                        [
                            ft.Text(key, size=12, color=ft.Colors.ON_SURFACE_VARIANT),
                            ft.Text(str(value), size=16, weight=ft.FontWeight.W_500),
                        ]
                    ),
                    padding=ft.padding.symmetric(vertical=12, horizontal=18),
                    bgcolor=ft.Colors.with_opacity(0.04, ft.Colors.BLUE_GREY_200),
                    border_radius=ft.border_radius.all(16),
                )
            )

        db_status = ft.Text("Sin verificar", color=ft.Colors.ON_SURFACE_VARIANT)
        self.state.bind_db_status(db_status)
        check_button = SuccessButton(
            "Verificar conexión",
            icon=ft.icons.DATABASE,
            theme=self.theme,
            on_click=self.state.check_database,
        )

        return ft.Column(
            [
                ft.Text("Configuración activa", size=26, weight=ft.FontWeight.W_700),
                ft.Text(
                    "Resumen de parámetros cargados desde las variables de entorno.",
                    size=14,
                    color=ft.Colors.ON_SURFACE_VARIANT,
                ),
                ft.ResponsiveRow(
                    [
                        ft.Column(info_rows, spacing=12, expand=True),
                    ]
                ),
                ft.Divider(),
                ft.Row(
                    [
                        ft.Column(
                            [
                                ft.Text("Estado de la base de datos", size=16, weight=ft.FontWeight.W_600),
                                db_status,
                            ],
                            spacing=6,
                        ),
                        check_button,
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                ),
            ],
            spacing=18,
            expand=True,
        )

    # ------------------------------------------------------------------
    def _build_diagnostics(self) -> ft.Control:
        status_text = ft.Text("Sin datos", size=16, weight=ft.FontWeight.W_600)
        message_text = ft.Text("Pulsa \"Comprobar salud\" para obtener el estado más reciente.")
        doc_button = ft.TextButton("Ver documentación", url="", disabled=True)
        last_updated = ft.Text(
            "Última actualización: --",
            size=12,
            color=ft.Colors.ON_SURFACE_VARIANT,
        )
        metrics_table = SmartTable(
            columns=["Métrica", "Valor"],
            rows=[],
            page_size=6,
        )
        metrics_container = ft.Container(content=metrics_table.build(), expand=True)
        self.state.bind_health_widgets(
            status_text,
            message_text,
            doc_button,
            metrics_table,
            metrics_container,
            last_updated,
        )

        auto_status = ft.Text("", size=12, color=ft.Colors.ON_SURFACE_VARIANT)
        auto_switch = ft.Switch(
            label="Actualizar automáticamente",
            value=self.state.auto_health_enabled,
            on_change=lambda e: self.state.toggle_auto_health_refresh(
                enabled=bool(e.control.value)
            ),
        )
        interval_slider = ft.Slider(
            min=30,
            max=300,
            divisions=9,
            value=float(self.state.auto_health_interval),
            label="{value} s",
            on_change=lambda e: self.state.update_health_interval(int(e.control.value)),
        )
        interval_text = ft.Text("", size=12, color=ft.Colors.ON_SURFACE_VARIANT)
        refresh_now = SuccessButton(
            "Actualizar ahora",
            icon=ft.icons.REFRESH_ROUNDED,
            theme=self.theme,
            on_click=self.state.run_health_check,
        )

        self.state.bind_auto_refresh_status(auto_status)
        self.state.bind_auto_refresh_switch(auto_switch)
        self.state.bind_health_interval_slider(interval_slider)
        self.state.bind_health_interval_text(interval_text)

        auto_refresh_controls = ft.Container(
            content=ft.Column(
                [
                    ft.Row(
                        [auto_switch, auto_status],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    interval_slider,
                    interval_text,
                    ft.Row(
                        [refresh_now],
                        alignment=ft.MainAxisAlignment.START,
                    ),
                ],
                spacing=10,
            ),
            padding=ft.padding.all(18),
            bgcolor=ft.Colors.with_opacity(0.05, ft.Colors.GREEN_200),
            border_radius=ft.border_radius.all(18),
        )

        return ft.Column(
            [
                ft.Text("Diagnóstico del servicio", size=26, weight=ft.FontWeight.W_700),
                ft.Text(
                    "Consulta el estado general y las métricas expuestas por la API.",
                    size=14,
                    color=ft.Colors.ON_SURFACE_VARIANT,
                ),
                ft.Container(
                    content=ft.Column(
                        [
                            ft.Row(
                                [
                                    ft.Icon(ft.icons.MONITOR_HEART, color=ft.Colors.TEAL_300, size=28),
                                    status_text,
                                ],
                                spacing=12,
                                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                            ),
                            message_text,
                            doc_button,
                        ]
                    ),
                    padding=ft.padding.all(18),
                    bgcolor=ft.Colors.with_opacity(0.05, ft.Colors.TEAL_200),
                    border_radius=ft.border_radius.all(18),
                ),
                ft.Row(
                    [
                        ft.Text("Métricas recientes", size=16, weight=ft.FontWeight.W_600),
                        ft.IconButton(
                            icon=ft.icons.REFRESH,
                            tooltip="Actualizar métricas",
                            on_click=self.state.run_health_check,
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                ),
                auto_refresh_controls,
                metrics_container,
                last_updated,
                ft.Text(
                    "Activa la actualización automática o usa los accesos directos para refrescar manualmente.",
                    size=12,
                    color=ft.Colors.ON_SURFACE_VARIANT,
                ),
            ],
            spacing=18,
            expand=True,
        )


    # ------------------------------------------------------------------
    def _build_accessibility(self) -> ft.Control:
        panel = AccessibilityPanel(
            preferences=self.state.accessibility_preferences,
            theme=self.theme,
            on_change=self.state.apply_accessibility_preferences,
        )

        shortcuts = ft.Column(
            [
                ft.Text("Atajos disponibles", size=16, weight=ft.FontWeight.W_600),
                ft.Text("Ctrl+S: iniciar API"),
                ft.Text("Ctrl+X: detener API"),
                ft.Text("Ctrl+R: reiniciar API"),
                ft.Text("Ctrl+T: alternar tema"),
                ft.Text("Ctrl+A: abrir accesibilidad"),
                ft.Text("Ctrl+K: paleta de comandos"),
                ft.Text("Ctrl+Shift+C: copiar URL base"),
                ft.Text("Ctrl+Shift+L: limpiar registro"),
                ft.Text("Ctrl+Shift+H: alternar auto diagnóstico"),
            ],
            spacing=4,
        )

        return ft.Column(
            [
                ft.Text("Preferencias de accesibilidad", size=26, weight=ft.FontWeight.W_700),
                ft.Text(
                    "Ajusta contraste, tamaño del texto, animaciones y ayudas visuales sin salir de la CLI.",
                    size=14,
                    color=ft.Colors.ON_SURFACE_VARIANT,
                ),
                ft.Container(
                    content=panel,
                    bgcolor=ft.Colors.with_opacity(0.04, ft.Colors.PURPLE_200),
                    border_radius=ft.border_radius.all(18),
                    padding=ft.padding.all(18),
                ),
                ft.Divider(),
                ft.Text("Consejos rápidos", size=16, weight=ft.FontWeight.W_600),
                ft.Text(
                    "El botón flotante y la paleta de comandos facilitan acceder a cualquier acción con lector de pantalla.",
                    size=12,
                    color=ft.Colors.ON_SURFACE_VARIANT,
                ),
                shortcuts,
            ],
            spacing=18,
            expand=True,
        )


# ----------------------------------------------------------------------
def launch() -> None:
    """Punto de entrada para lanzar la CLI con Flet."""

    state = CliState()

    def _run(page: ft.Page) -> None:
        CobraCliApp(page, state).build()

    ft.app(target=_run)


def main() -> None:
    """Alias para mantener compatibilidad al ejecutarse como script."""

    launch()


if __name__ == "__main__":  # pragma: no cover - ejecución directa
    main()
