"""Punto de entrada seguro para la CLI opcional de Cobra Online."""
from __future__ import annotations

import sys
from importlib import import_module
from types import ModuleType
from typing import Any, Callable

__all__ = [
    "CliUnavailableError",
    "availability_error",
    "is_available",
    "launch",
]

_OPTIONAL_DEPENDENCIES = {"flet", "fletplus"}

_CLI_MODULE: ModuleType | None = None
_CLI_ERROR: CliUnavailableError | None = None


class CliUnavailableError(RuntimeError):
    """Se lanza cuando faltan dependencias opcionales para la CLI."""

    def __init__(self, missing_dependency: str) -> None:
        self.missing_dependency = missing_dependency
        message = (
            "La CLI de Cobra Online requiere el paquete opcional "
            f"'{missing_dependency}'. "
            "Instálalo con `pip install cobra-online-api[cli]` o añade `flet` y "
            "`fletplus` manualmente a tu entorno antes de volver a intentar la ejecución."
        )
        super().__init__(message)


def _load_cli_module() -> ModuleType:
    """Importa perezosamente ``app.cli.main`` y memoriza el resultado."""

    global _CLI_MODULE, _CLI_ERROR

    if _CLI_MODULE is not None:
        return _CLI_MODULE

    if _CLI_ERROR is not None:
        raise _CLI_ERROR

    try:
        module = import_module("app.cli.main")
    except ModuleNotFoundError as exc:
        missing = (exc.name or "").partition(".")[0] or str(exc)
        if missing in _OPTIONAL_DEPENDENCIES:
            sys.modules.pop("app.cli.main", None)
            _CLI_ERROR = CliUnavailableError(missing)
            raise _CLI_ERROR from exc
        raise
    else:
        _CLI_MODULE = module
        return module


def availability_error() -> CliUnavailableError | None:
    """Devuelve el último error de disponibilidad detectado (si existe)."""

    return _CLI_ERROR


def is_available() -> bool:
    """Indica si la CLI puede utilizarse en el entorno actual."""

    try:
        _load_cli_module()
    except CliUnavailableError:
        return False
    return True


def launch(*args: Any, **kwargs: Any) -> None:
    """Ejecuta la CLI si las dependencias opcionales están disponibles."""

    module = _load_cli_module()
    launcher: Callable[..., None] = getattr(module, "launch")
    launcher(*args, **kwargs)

