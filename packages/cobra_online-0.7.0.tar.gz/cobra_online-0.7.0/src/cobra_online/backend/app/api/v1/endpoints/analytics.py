"""Endpoints para gestionar pipelines de análisis de datos."""

if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.models import (
    AnalyticsEngine,
    AnalyticsPipelineMode,
    AnalyticsPipelineStatus,
)
from app.schemas import (
    AnalyticsPipelineCreate,
    AnalyticsPipelineRead,
    AnalyticsPipelineSummary,
    AnalyticsPipelineUpdate,
)
from app.services import analytics as analytics_service

router = APIRouter()


@router.get(
    "/",
    response_model=list[AnalyticsPipelineRead],
    summary="Listar pipelines de análisis",
)
def list_analytics_pipelines(
    engine: AnalyticsEngine | None = Query(
        default=None,
        description="Filtra por motor de ejecución.",
    ),
    status: AnalyticsPipelineStatus | None = Query(
        default=None,
        description="Filtra por estado operativo.",
    ),
    name: str | None = Query(
        default=None,
        min_length=3,
        max_length=63,
        pattern=r"^[a-z0-9-]+$",
        description="Filtra por nombre exacto del pipeline.",
    ),
    mode: AnalyticsPipelineMode | None = Query(
        default=None,
        description="Filtra por modo de orquestación.",
    ),
    db: Session = Depends(get_db),
) -> list[AnalyticsPipelineRead]:
    """Devuelve los pipelines registrados en el catálogo."""

    return analytics_service.list_pipelines(
        db, engine=engine, status=status, name=name, mode=mode
    )


@router.get(
    "/summary",
    response_model=AnalyticsPipelineSummary,
    summary="Obtener métricas agregadas de pipelines",
)
def summarize_analytics_pipelines(db: Session = Depends(get_db)) -> AnalyticsPipelineSummary:
    """Calcula el resumen estadístico de los pipelines registrados."""

    return analytics_service.summarize_pipelines(db)


@router.post(
    "/",
    response_model=AnalyticsPipelineRead,
    status_code=status.HTTP_201_CREATED,
    summary="Registrar un pipeline de análisis",
)
def create_analytics_pipeline(
    payload: AnalyticsPipelineCreate, db: Session = Depends(get_db)
) -> AnalyticsPipelineRead:
    """Crea un pipeline de análisis evitando duplicados por nombre."""

    try:
        pipeline = analytics_service.create_pipeline(
            db,
            name=payload.name,
            engine=payload.engine,
            mode=payload.mode,
            schedule=payload.schedule,
            description=payload.description,
            status=payload.status,
        )
    except analytics_service.AnalyticsPipelineAlreadyExistsError as error:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Ya existe un pipeline con el nombre '{error.args[0]}'.",
        ) from error

    return pipeline


@router.get(
    "/{pipeline_id}",
    response_model=AnalyticsPipelineRead,
    summary="Obtener detalles de un pipeline",
)
def read_analytics_pipeline(
    pipeline_id: int, db: Session = Depends(get_db)
) -> AnalyticsPipelineRead:
    """Recupera la información de un pipeline específico."""

    try:
        return analytics_service.get_pipeline(db, pipeline_id)
    except analytics_service.AnalyticsPipelineNotFoundError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe un pipeline con el id '{error.args[0]}'.",
        ) from error


@router.patch(
    "/{pipeline_id}",
    response_model=AnalyticsPipelineRead,
    summary="Actualizar un pipeline",
)
def update_analytics_pipeline(
    pipeline_id: int,
    payload: AnalyticsPipelineUpdate,
    db: Session = Depends(get_db),
) -> AnalyticsPipelineRead:
    """Actualiza los campos suministrados de un pipeline existente."""

    update_data = payload.model_dump(exclude_unset=True)

    try:
        if not update_data:
            return analytics_service.get_pipeline(db, pipeline_id)
        pipeline = analytics_service.update_pipeline(db, pipeline_id, **update_data)
    except analytics_service.AnalyticsPipelineNotFoundError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe un pipeline con el id '{error.args[0]}'.",
        ) from error
    except analytics_service.AnalyticsPipelineAlreadyExistsError as error:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Ya existe un pipeline con el nombre '{error.args[0]}'.",
        ) from error
    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        ) from error

    return pipeline


@router.delete(
    "/{pipeline_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Eliminar un pipeline",
)
def delete_analytics_pipeline(
    pipeline_id: int, db: Session = Depends(get_db)
) -> Response:
    """Elimina un pipeline del catálogo."""

    try:
        analytics_service.delete_pipeline(db, pipeline_id)
    except analytics_service.AnalyticsPipelineNotFoundError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe un pipeline con el id '{error.args[0]}'.",
        ) from error

    return Response(status_code=status.HTTP_204_NO_CONTENT)
