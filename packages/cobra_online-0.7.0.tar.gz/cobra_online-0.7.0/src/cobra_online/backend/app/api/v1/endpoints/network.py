"""Endpoints para gestionar balanceadores de carga."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.models import (
    NetworkLoadBalancerProtocol,
    NetworkLoadBalancerStatus,
)
from app.schemas import (
    NetworkLoadBalancerCreate,
    NetworkLoadBalancerRead,
    NetworkLoadBalancerUpdate,
)
from app.services import network as network_service

router = APIRouter()


@router.get(
    "/",
    response_model=list[NetworkLoadBalancerRead],
    summary="Listar balanceadores de carga registrados",
)
def list_network_load_balancers(
    protocol: NetworkLoadBalancerProtocol | None = Query(
        default=None,
        description="Filtra por protocolo de escucha.",
    ),
    status: NetworkLoadBalancerStatus | None = Query(
        default=None,
        description="Filtra por estado operativo.",
    ),
    region: str | None = Query(
        default=None,
        min_length=2,
        max_length=32,
        description="Filtra por región del balanceador.",
    ),
    name: str | None = Query(
        default=None,
        min_length=3,
        max_length=63,
        pattern=r"^[a-z0-9-]+$",
        description="Filtra por nombre exacto del balanceador.",
    ),
    db: Session = Depends(get_db),
) -> list[NetworkLoadBalancerRead]:
    """Recupera todos los balanceadores registrados."""

    return network_service.list_load_balancers(
        db, protocol=protocol, status=status, region=region, name=name
    )


@router.post(
    "/",
    response_model=NetworkLoadBalancerRead,
    status_code=status.HTTP_201_CREATED,
    summary="Crear un balanceador de carga",
)
def create_network_load_balancer(
    payload: NetworkLoadBalancerCreate, db: Session = Depends(get_db)
) -> NetworkLoadBalancerRead:
    """Crea un balanceador de carga validando el nombre único."""

    try:
        load_balancer = network_service.create_load_balancer(
            db,
            name=payload.name,
            protocol=payload.protocol,
            port=payload.port,
            region=payload.region,
            status=payload.status,
        )
    except network_service.NetworkLoadBalancerAlreadyExistsError as error:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Ya existe un balanceador con el nombre '{error.args[0]}'.",
        ) from error

    return load_balancer


@router.get(
    "/{load_balancer_id}",
    response_model=NetworkLoadBalancerRead,
    summary="Obtener detalles de un balanceador de carga",
)
def read_network_load_balancer(
    load_balancer_id: int, db: Session = Depends(get_db)
) -> NetworkLoadBalancerRead:
    """Devuelve la información de un balanceador específico."""

    try:
        return network_service.get_load_balancer(db, load_balancer_id)
    except network_service.NetworkLoadBalancerNotFoundError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe un balanceador con el id '{error.args[0]}'.",
        ) from error


@router.patch(
    "/{load_balancer_id}",
    response_model=NetworkLoadBalancerRead,
    summary="Actualizar un balanceador de carga",
)
def update_network_load_balancer(
    load_balancer_id: int,
    payload: NetworkLoadBalancerUpdate,
    db: Session = Depends(get_db),
) -> NetworkLoadBalancerRead:
    """Actualiza los campos indicados de un balanceador de carga."""

    update_data = payload.model_dump(exclude_unset=True)

    try:
        if not update_data:
            return network_service.get_load_balancer(db, load_balancer_id)
        load_balancer = network_service.update_load_balancer(
            db, load_balancer_id, **update_data
        )
    except network_service.NetworkLoadBalancerNotFoundError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe un balanceador con el id '{error.args[0]}'.",
        ) from error
    except network_service.NetworkLoadBalancerAlreadyExistsError as error:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Ya existe un balanceador con el nombre '{error.args[0]}'.",
        ) from error
    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        ) from error

    return load_balancer


@router.delete(
    "/{load_balancer_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Eliminar un balanceador de carga",
)
def delete_network_load_balancer(
    load_balancer_id: int, db: Session = Depends(get_db)
) -> Response:
    """Elimina un balanceador de carga registrado."""

    try:
        network_service.delete_load_balancer(db, load_balancer_id)
    except network_service.NetworkLoadBalancerNotFoundError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe un balanceador con el id '{error.args[0]}'.",
        ) from error

    return Response(status_code=status.HTTP_204_NO_CONTENT)
