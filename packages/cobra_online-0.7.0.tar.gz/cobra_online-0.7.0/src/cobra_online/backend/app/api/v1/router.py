"""Enrutador principal para la versión 1 de la API."""

if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from fastapi import APIRouter, Depends

from app.api.deps import require_api_key
from app.api.v1.endpoints import (
    analytics,
    compute,
    database,
    health,
    ml,
    network,
    security,
    storage,
)


api_router = APIRouter()
api_router.include_router(health.router, prefix="/health", tags=["health"])
protected_dependencies = [Depends(require_api_key)]
api_router.include_router(
    storage.router,
    prefix="/storage/buckets",
    tags=["storage"],
    dependencies=protected_dependencies,
)
api_router.include_router(
    compute.router,
    prefix="/compute/instances",
    tags=["compute"],
    dependencies=protected_dependencies,
)
api_router.include_router(
    database.router,
    prefix="/databases/instances",
    tags=["databases"],
    dependencies=protected_dependencies,
)
api_router.include_router(
    network.router,
    prefix="/network/load-balancers",
    tags=["network"],
    dependencies=protected_dependencies,
)
api_router.include_router(
    analytics.router,
    prefix="/analytics/pipelines",
    tags=["analytics"],
    dependencies=protected_dependencies,
)
api_router.include_router(
    ml.router,
    prefix="/ml/models",
    tags=["ml"],
    dependencies=protected_dependencies,
)
api_router.include_router(
    security.router,
    prefix="/security/api-keys",
    tags=["security"],
    dependencies=protected_dependencies,
)
