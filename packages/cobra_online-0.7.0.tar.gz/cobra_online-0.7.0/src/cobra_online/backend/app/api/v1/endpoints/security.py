"""Endpoints para gestionar la seguridad de la API."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.schemas import ApiKeyCreate, ApiKeyRead, ApiKeyWithSecret
from app.services import security as security_service

router = APIRouter()


@router.get("/", response_model=list[ApiKeyRead], summary="Listar API keys registradas")
def list_api_keys(db: Session = Depends(get_db)) -> list[ApiKeyRead]:
    """Devuelve todas las API keys administradas en la plataforma."""

    return security_service.list_api_keys(db)


@router.post(
    "/",
    response_model=ApiKeyWithSecret,
    status_code=status.HTTP_201_CREATED,
    summary="Crear una API key nueva",
)
def create_api_key(payload: ApiKeyCreate, db: Session = Depends(get_db)) -> ApiKeyWithSecret:
    """Genera una API key persistente y devuelve el secreto una única vez."""

    api_key, secret = security_service.create_api_key(
        db, name=payload.name, expires_at=payload.expires_at
    )
    return ApiKeyWithSecret.model_validate(
        {
            "id": api_key.id,
            "name": api_key.name,
            "key_prefix": api_key.key_prefix,
            "created_at": api_key.created_at,
            "expires_at": api_key.expires_at,
            "last_used_at": api_key.last_used_at,
            "revoked": api_key.revoked,
            "secret": secret,
        }
    )


@router.post(
    "/{api_key_id}/revoke",
    response_model=ApiKeyRead,
    summary="Revocar una API key",
)
def revoke_api_key(api_key_id: int, db: Session = Depends(get_db)) -> ApiKeyRead:
    """Revoca una API key activa e impide su uso posterior."""

    try:
        api_key = security_service.revoke_api_key(db, api_key_id)
    except security_service.ApiKeyNotFoundError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe una API key con el id '{error.args[0]}'.",
        ) from error
    except security_service.ApiKeyAlreadyRevokedError as error:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"La API key con id '{error.args[0]}' ya fue revocada.",
        ) from error

    return api_key

