"""Dependencias comunes para los endpoints de la API."""

if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from collections.abc import Generator

from typing import Annotated

from fastapi import Depends, Header, HTTPException, Query, status
from sqlalchemy.orm import Session, sessionmaker

from app.core import i18n
from app.core.config import settings
from app.db.external import external_integrations
from app.db.manager import database_configurator
from app.services import security as security_service

engine = database_configurator.create_engine(settings)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

external_integrations.configure_from_settings(settings)


def get_db() -> Generator[Session, None, None]:
    """Proporciona una sesión de base de datos para operaciones transaccionales."""

    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def require_api_key(
    x_api_key: str | None = Header(default=None, alias="X-API-Key"),
    db: Session = Depends(get_db),
) -> str | None:
    """Valida la cabecera ``X-API-Key`` cuando hay llaves configuradas."""

    enforce_security = bool(settings.api_keys)
    if not enforce_security:
        enforce_security = security_service.any_active_api_keys(db)

    if not enforce_security:
        return x_api_key

    if x_api_key is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Falta la API key requerida.",
        )

    if x_api_key in settings.api_keys:
        return x_api_key

    if security_service.verify_api_key(db, x_api_key) is not None:
        return x_api_key

    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="La API key proporcionada no es válida.",
    )


def get_locale(
    lang: Annotated[
        str | None,
        Query(
            description="Idioma preferido en formato ISO 639-1.",
        ),
    ] = None,
    accept_language: Annotated[
        str | None,
        Header(
            alias="Accept-Language",
            convert_underscores=False,
            description="Cabecera HTTP estándar con preferencias de idioma",
        ),
    ] = None,
) -> str:
    """Resuelve el idioma que debe usarse en la respuesta de la API."""

    return i18n.resolve_locale(lang=lang, accept_language=accept_language)
