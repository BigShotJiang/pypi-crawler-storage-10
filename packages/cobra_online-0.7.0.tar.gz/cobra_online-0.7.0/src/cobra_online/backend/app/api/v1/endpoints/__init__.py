"""Endpoints disponibles para la versión 1 de la API."""


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from app.api.v1.endpoints import (
    analytics,
    compute,
    database,
    health,
    ml,
    network,
    security,
    storage,
)

__all__ = [
    "analytics",
    "compute",
    "database",
    "health",
    "ml",
    "network",
    "security",
    "storage",
]
