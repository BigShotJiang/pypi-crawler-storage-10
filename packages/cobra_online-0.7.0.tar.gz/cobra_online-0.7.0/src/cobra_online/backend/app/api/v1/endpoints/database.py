"""Endpoints para gestionar bases de datos administradas."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.models import DatabaseEngine, DatabaseInstanceStatus
from app.schemas import (
    DatabaseInstanceCreate,
    DatabaseInstanceRead,
    DatabaseInstanceUpdate,
)
from app.services import database as database_service

router = APIRouter()


@router.get(
    "/",
    response_model=list[DatabaseInstanceRead],
    summary="Listar bases de datos administradas registradas",
)
def list_database_instances(
    engine: DatabaseEngine | None = Query(
        default=None,
        description="Filtra por motor de base de datos.",
    ),
    status: DatabaseInstanceStatus | None = Query(
        default=None,
        description="Filtra por estado operativo.",
    ),
    region: str | None = Query(
        default=None,
        min_length=2,
        max_length=32,
        description="Filtra por región de despliegue.",
    ),
    name: str | None = Query(
        default=None,
        min_length=3,
        max_length=63,
        pattern=r"^[a-z0-9-]+$",
        description="Filtra por nombre exacto de la instancia.",
    ),
    db: Session = Depends(get_db),
) -> list[DatabaseInstanceRead]:
    """Recupera todas las instancias de base de datos registradas."""

    return database_service.list_instances(
        db, engine=engine, status=status, region=region, name=name
    )


@router.post(
    "/",
    response_model=DatabaseInstanceRead,
    status_code=status.HTTP_201_CREATED,
    summary="Crear una instancia de base de datos",
)
def create_database_instance(
    payload: DatabaseInstanceCreate, db: Session = Depends(get_db)
) -> DatabaseInstanceRead:
    """Crea una instancia de base de datos validando el nombre único."""

    try:
        instance = database_service.create_instance(
            db,
            name=payload.name,
            engine=payload.engine,
            version=payload.version,
            region=payload.region,
            storage_gb=payload.storage_gb,
            status=payload.status,
        )
    except database_service.DatabaseInstanceAlreadyExistsError as error:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Ya existe una instancia de base de datos con el nombre '{error.args[0]}'.",
        ) from error

    return instance


@router.get(
    "/{instance_id}",
    response_model=DatabaseInstanceRead,
    summary="Obtener detalles de una base de datos administrada",
)
def read_database_instance(
    instance_id: int, db: Session = Depends(get_db)
) -> DatabaseInstanceRead:
    """Devuelve la información de una instancia administrada específica."""

    try:
        return database_service.get_instance(db, instance_id)
    except database_service.DatabaseInstanceNotFoundError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe una instancia de base de datos con el id '{error.args[0]}'.",
        ) from error


@router.patch(
    "/{instance_id}",
    response_model=DatabaseInstanceRead,
    summary="Actualizar una base de datos administrada",
)
def update_database_instance(
    instance_id: int,
    payload: DatabaseInstanceUpdate,
    db: Session = Depends(get_db),
) -> DatabaseInstanceRead:
    """Actualiza los campos indicados de una instancia administrada."""

    update_data = payload.model_dump(exclude_unset=True)

    try:
        if not update_data:
            return database_service.get_instance(db, instance_id)
        instance = database_service.update_instance(db, instance_id, **update_data)
    except database_service.DatabaseInstanceNotFoundError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe una instancia de base de datos con el id '{error.args[0]}'.",
        ) from error
    except database_service.DatabaseInstanceAlreadyExistsError as error:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                "Ya existe una instancia de base de datos con el nombre "
                f"'{error.args[0]}'."
            ),
        ) from error
    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        ) from error

    return instance


@router.delete(
    "/{instance_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Eliminar una base de datos administrada",
)
def delete_database_instance(
    instance_id: int, db: Session = Depends(get_db)
) -> Response:
    """Elimina una instancia administrada registrada."""

    try:
        database_service.delete_instance(db, instance_id)
    except database_service.DatabaseInstanceNotFoundError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe una instancia de base de datos con el id '{error.args[0]}'.",
        ) from error

    return Response(status_code=status.HTTP_204_NO_CONTENT)
