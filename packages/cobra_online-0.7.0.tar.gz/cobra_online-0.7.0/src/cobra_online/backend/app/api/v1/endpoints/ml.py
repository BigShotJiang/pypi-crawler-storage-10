"""Endpoints para gestionar modelos de IA y Machine Learning."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.models import MachineLearningFramework, MachineLearningModelStatus
from app.schemas import (
    MachineLearningModelCreate,
    MachineLearningModelRead,
    MachineLearningModelSummary,
    MachineLearningModelUpdate,
)
from app.services import ml as ml_service

router = APIRouter()


@router.get(
    "/",
    response_model=list[MachineLearningModelRead],
    summary="Listar modelos de IA/ML registrados",
)
def list_ml_models(
    framework: MachineLearningFramework | None = Query(
        default=None,
        description="Filtra por framework del modelo.",
    ),
    status: MachineLearningModelStatus | None = Query(
        default=None,
        description="Filtra por estado operativo del modelo.",
    ),
    name: str | None = Query(
        default=None,
        min_length=3,
        max_length=63,
        pattern=r"^[a-z0-9-]+$",
        description="Filtra por nombre exacto del modelo.",
    ),
    db: Session = Depends(get_db),
) -> list[MachineLearningModelRead]:
    """Recupera todos los modelos disponibles aplicando filtros opcionales."""

    return ml_service.list_models(db, framework=framework, status=status, name=name)


@router.get(
    "/summary",
    response_model=MachineLearningModelSummary,
    summary="Obtener métricas agregadas de modelos",
)
def summarize_ml_models(db: Session = Depends(get_db)) -> MachineLearningModelSummary:
    """Devuelve estadísticas globales del catálogo de modelos."""

    return ml_service.summarize_models(db)


@router.post(
    "/",
    response_model=MachineLearningModelRead,
    status_code=status.HTTP_201_CREATED,
    summary="Registrar un modelo de IA/ML",
)
def create_ml_model(
    payload: MachineLearningModelCreate, db: Session = Depends(get_db)
) -> MachineLearningModelRead:
    """Crea un modelo si el nombre no existe previamente."""

    try:
        model = ml_service.create_model(
            db,
            name=payload.name,
            framework=payload.framework,
            version=payload.version,
            description=payload.description,
            endpoint_url=payload.endpoint_url,
            status=payload.status,
            last_trained_at=payload.last_trained_at,
        )
    except ml_service.MachineLearningModelAlreadyExistsError as error:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Ya existe un modelo con el nombre '{error.args[0]}'.",
        ) from error
    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        ) from error

    return model


@router.get(
    "/{model_id}",
    response_model=MachineLearningModelRead,
    summary="Obtener detalles de un modelo",
)
def read_ml_model(model_id: int, db: Session = Depends(get_db)) -> MachineLearningModelRead:
    """Recupera la información de un modelo específico."""

    try:
        return ml_service.get_model(db, model_id)
    except ml_service.MachineLearningModelNotFoundError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe un modelo con el id '{error.args[0]}'.",
        ) from error


@router.patch(
    "/{model_id}",
    response_model=MachineLearningModelRead,
    summary="Actualizar un modelo existente",
)
def update_ml_model(
    model_id: int,
    payload: MachineLearningModelUpdate,
    db: Session = Depends(get_db),
) -> MachineLearningModelRead:
    """Actualiza los campos proporcionados para un modelo."""

    update_data = payload.model_dump(exclude_unset=True)

    try:
        if not update_data:
            return ml_service.get_model(db, model_id)
        model = ml_service.update_model(db, model_id, **update_data)
    except ml_service.MachineLearningModelNotFoundError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe un modelo con el id '{error.args[0]}'.",
        ) from error
    except ml_service.MachineLearningModelAlreadyExistsError as error:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Ya existe un modelo con el nombre '{error.args[0]}'.",
        ) from error
    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        ) from error

    return model


@router.delete(
    "/{model_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Eliminar un modelo",
)
def delete_ml_model(model_id: int, db: Session = Depends(get_db)) -> Response:
    """Elimina un modelo registrado."""

    try:
        ml_service.delete_model(db, model_id)
    except ml_service.MachineLearningModelNotFoundError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe un modelo con el id '{error.args[0]}'.",
        ) from error

    return Response(status_code=status.HTTP_204_NO_CONTENT)
