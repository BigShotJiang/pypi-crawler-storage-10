"""Endpoints para gestionar instancias de cómputo."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.models import ComputeInstanceStatus
from app.schemas import (
    ComputeInstanceCreate,
    ComputeInstanceRead,
    ComputeInstanceUpdate,
)
from app.services import compute as compute_service

router = APIRouter()


@router.get(
    "/",
    response_model=list[ComputeInstanceRead],
    summary="Listar instancias de cómputo registradas",
)
def list_compute_instances(
    region: str | None = Query(
        default=None,
        min_length=2,
        max_length=32,
        description="Filtra por la región de la instancia.",
    ),
    status: ComputeInstanceStatus | None = Query(
        default=None,
        description="Filtra por estado operativo.",
    ),
    image: str | None = Query(
        default=None,
        min_length=1,
        max_length=64,
        description="Filtra por imagen base utilizada.",
    ),
    name: str | None = Query(
        default=None,
        min_length=3,
        max_length=63,
        pattern=r"^[a-z0-9-]+$",
        description="Filtra por nombre exacto de la instancia.",
    ),
    db: Session = Depends(get_db),
) -> list[ComputeInstanceRead]:
    """Recupera todas las instancias registradas."""

    return compute_service.list_instances(
        db, region=region, status=status, image=image, name=name
    )


@router.post(
    "/",
    response_model=ComputeInstanceRead,
    status_code=status.HTTP_201_CREATED,
    summary="Crear una instancia de cómputo",
)
def create_compute_instance(
    payload: ComputeInstanceCreate, db: Session = Depends(get_db)
) -> ComputeInstanceRead:
    """Crea una instancia de cómputo validando nombre único."""

    try:
        instance = compute_service.create_instance(
            db,
            name=payload.name,
            image=payload.image,
            region=payload.region,
            vcpus=payload.vcpus,
            memory_gb=payload.memory_gb,
            status=payload.status,
        )
    except compute_service.ComputeInstanceAlreadyExistsError as error:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Ya existe una instancia con el nombre '{error.args[0]}'.",
        ) from error

    return instance


@router.get(
    "/{instance_id}",
    response_model=ComputeInstanceRead,
    summary="Obtener detalles de una instancia de cómputo",
)
def read_compute_instance(
    instance_id: int, db: Session = Depends(get_db)
) -> ComputeInstanceRead:
    """Devuelve la información de una instancia específica."""

    try:
        return compute_service.get_instance(db, instance_id)
    except compute_service.ComputeInstanceNotFoundError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe una instancia con el id '{error.args[0]}'.",
        ) from error


@router.patch(
    "/{instance_id}",
    response_model=ComputeInstanceRead,
    summary="Actualizar una instancia de cómputo",
)
def update_compute_instance(
    instance_id: int,
    payload: ComputeInstanceUpdate,
    db: Session = Depends(get_db),
) -> ComputeInstanceRead:
    """Actualiza los campos proporcionados de una instancia."""

    update_data = payload.model_dump(exclude_unset=True)

    try:
        if not update_data:
            return compute_service.get_instance(db, instance_id)
        instance = compute_service.update_instance(db, instance_id, **update_data)
    except compute_service.ComputeInstanceNotFoundError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe una instancia con el id '{error.args[0]}'.",
        ) from error
    except compute_service.ComputeInstanceAlreadyExistsError as error:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Ya existe una instancia con el nombre '{error.args[0]}'.",
        ) from error
    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        ) from error

    return instance


@router.delete(
    "/{instance_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Eliminar una instancia de cómputo",
)
def delete_compute_instance(instance_id: int, db: Session = Depends(get_db)) -> Response:
    """Elimina una instancia registrada."""

    try:
        compute_service.delete_instance(db, instance_id)
    except compute_service.ComputeInstanceNotFoundError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe una instancia con el id '{error.args[0]}'.",
        ) from error

    return Response(status_code=status.HTTP_204_NO_CONTENT)
