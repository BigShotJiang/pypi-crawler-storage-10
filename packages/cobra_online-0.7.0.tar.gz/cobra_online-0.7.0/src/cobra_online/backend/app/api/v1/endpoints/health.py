"""Endpoints de salud básicos para comprobar el estado del servicio."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.api.deps import get_db, get_locale
from app.core import i18n
from app.core.config import settings
from app.schemas import HealthMetrics, HealthStatus
from app.services import health as health_service

router = APIRouter()


@router.get("/", response_model=HealthStatus, summary="Verificar estado del servicio")
def read_health_status(locale: str = Depends(get_locale)) -> HealthStatus:
    """Devuelve información mínima de estado."""

    return HealthStatus(
        status="ok",
        service=settings.project_name,
        timestamp=datetime.now(tz=timezone.utc),
        locale=locale,
        message=i18n.translate("health.status_message", locale),
        documentation_url=i18n.documentation_url(locale),
    )


@router.get(
    "/metrics",
    response_model=HealthMetrics,
    summary="Obtener métricas agregadas del servicio",
)
def read_health_metrics(
    expiring_within_days: int = Query(
        default=7,
        ge=1,
        le=90,
        description=(
            "Número de días hacia adelante a considerar para detectar API keys que"
            " expiran pronto."
        ),
    ),
    db: Session = Depends(get_db),
    locale: str = Depends(get_locale),
) -> HealthMetrics:
    """Compila métricas operativas para monitoreo y pruebas de carga."""

    metrics = health_service.collect_metrics(
        db, expiring_within_days=expiring_within_days
    )
    metrics.update(
        {
            "locale": locale,
            "summary": i18n.translate("health.metrics_summary", locale),
            "documentation_url": i18n.documentation_url(locale),
        }
    )
    return HealthMetrics.model_validate(metrics)
