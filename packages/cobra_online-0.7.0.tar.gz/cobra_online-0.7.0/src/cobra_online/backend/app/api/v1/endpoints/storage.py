"""Endpoints para la gestión de buckets de almacenamiento."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.schemas import StorageBucketCreate, StorageBucketRead, StorageBucketUpdate
from app.services import storage as storage_service

router = APIRouter()


@router.get(
    "/",
    response_model=list[StorageBucketRead],
    summary="Listar buckets registrados",
)
def list_storage_buckets(
    region: str | None = Query(
        default=None,
        min_length=2,
        max_length=32,
        description="Filtra por región del bucket.",
    ),
    name: str | None = Query(
        default=None,
        min_length=3,
        max_length=63,
        pattern=r"^[a-z0-9-]+$",
        description="Filtra por nombre exacto del bucket.",
    ),
    db: Session = Depends(get_db),
) -> list[StorageBucketRead]:
    """Recupera todos los buckets disponibles en el catálogo."""

    return storage_service.list_buckets(db, region=region, name=name)


@router.post(
    "/",
    response_model=StorageBucketRead,
    status_code=status.HTTP_201_CREATED,
    summary="Crear un bucket nuevo",
)
def create_storage_bucket(
    payload: StorageBucketCreate, db: Session = Depends(get_db)
) -> StorageBucketRead:
    """Crea un bucket de almacenamiento si el nombre no existe."""

    try:
        bucket = storage_service.create_bucket(
            db,
            name=payload.name,
            region=payload.region,
            description=payload.description,
        )
    except storage_service.StorageBucketAlreadyExistsError as error:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Ya existe un bucket con el nombre '{error.args[0]}'.",
        ) from error

    return bucket


@router.get(
    "/{bucket_id}",
    response_model=StorageBucketRead,
    summary="Obtener detalles de un bucket",
)
def read_storage_bucket(
    bucket_id: int, db: Session = Depends(get_db)
) -> StorageBucketRead:
    """Recupera la información de un bucket específico."""

    try:
        return storage_service.get_bucket(db, bucket_id)
    except storage_service.StorageBucketNotFoundError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe un bucket con el id '{error.args[0]}'.",
        ) from error


@router.patch(
    "/{bucket_id}",
    response_model=StorageBucketRead,
    summary="Actualizar un bucket existente",
)
def update_storage_bucket(
    bucket_id: int,
    payload: StorageBucketUpdate,
    db: Session = Depends(get_db),
) -> StorageBucketRead:
    """Actualiza los campos indicados de un bucket."""

    update_data = payload.model_dump(exclude_unset=True)

    try:
        if not update_data:
            return storage_service.get_bucket(db, bucket_id)
        bucket = storage_service.update_bucket(db, bucket_id, **update_data)
    except storage_service.StorageBucketNotFoundError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe un bucket con el id '{error.args[0]}'.",
        ) from error
    except storage_service.StorageBucketAlreadyExistsError as error:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Ya existe un bucket con el nombre '{error.args[0]}'.",
        ) from error
    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        ) from error

    return bucket


@router.delete(
    "/{bucket_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Eliminar un bucket",
)
def delete_storage_bucket(bucket_id: int, db: Session = Depends(get_db)) -> Response:
    """Elimina un bucket registrado."""

    try:
        storage_service.delete_bucket(db, bucket_id)
    except storage_service.StorageBucketNotFoundError as error:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe un bucket con el id '{error.args[0]}'.",
        ) from error

    return Response(status_code=status.HTTP_204_NO_CONTENT)
