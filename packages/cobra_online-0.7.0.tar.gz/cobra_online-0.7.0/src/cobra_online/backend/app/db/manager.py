"""Utilidades para gestionar configuraciones multi-motor de bases de datos."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Dict

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.engine.url import URL, make_url
from sqlalchemy.pool import NullPool

from app.db.sqliteplus import SQLiteMaintenanceOptions, configure_sqlite_engine


logger = logging.getLogger(__name__)


@dataclass
class EngineConfiguration:
    """Parámetros utilizados para instanciar un ``Engine`` de SQLAlchemy."""

    connect_args: dict[str, Any] = field(default_factory=dict)
    engine_kwargs: dict[str, Any] = field(default_factory=dict)
    post_configure: list[Callable[[Engine], None]] = field(default_factory=list)


BackendFactory = Callable[["SettingsProtocol", URL], EngineConfiguration]


class SettingsProtocol:
    """Protocolo mínimo requerido por el configurador."""

    database_url: str
    database_pool_size: int | None
    database_max_overflow: int | None
    database_pool_timeout: float
    database_pool_recycle: int | None
    database_pool_pre_ping: bool
    database_echo: bool
    database_statement_timeout_ms: int | None
    database_application_name: str | None
    database_ssl_mode: str | None
    database_ssl_root_cert: str | None
    sqlite_encryption_key: str | None
    sqlite_require_encryption: bool
    sqlite_journal_mode: str
    sqlite_foreign_keys: bool
    sqlite_busy_timeout_ms: int | None
    sqlite_auto_optimize: bool
    sqlite_vacuum_on_startup: bool
    sqlite_wal_checkpoint: str | None
    sqlite_integrity_check: bool


class DatabaseConfigurator:
    """Registra y aplica configuraciones específicas por backend."""

    def __init__(self) -> None:
        self._backends: Dict[str, BackendFactory] = {}
        self._register_builtin_backends()

    def _register_builtin_backends(self) -> None:
        self.register_backend("sqlite", self._configure_sqlite)
        self.register_backend("postgresql", self._configure_postgresql)
        self.register_backend("postgresql+psycopg", self._configure_postgresql)
        self.register_backend("redshift", self._configure_postgresql)
        self.register_backend("redshift+psycopg2", self._configure_postgresql)
        self.register_backend("mysql", self._configure_mysql)
        self.register_backend("mysql+pymysql", self._configure_mysql)
        self.register_backend("mariadb", self._configure_mysql)
        self.register_backend("mssql", self._configure_mssql)
        self.register_backend("mssql+pyodbc", self._configure_mssql)
        self.register_backend("oracle", self._configure_oracle)
        self.register_backend("oracle+cx_oracle", self._configure_oracle)
        self.register_backend("snowflake", self._configure_snowflake)
        self.register_backend("snowflake.sqlalchemy", self._configure_snowflake)
        self.register_backend("trino", self._configure_http_sqlalchemy)
        self.register_backend("databricks", self._configure_http_sqlalchemy)
        self.register_backend("clickhouse+http", self._configure_http_sqlalchemy)
        self.register_backend("bigquery", self._configure_http_sqlalchemy)

    def register_backend(self, key: str, factory: BackendFactory) -> None:
        """Registra una nueva factoría para un backend específico."""

        self._backends[key] = factory

    def available_backends(self) -> list[str]:
        """Devuelve los backends configurados."""

        return sorted(self._backends)

    def create_engine(self, settings: SettingsProtocol) -> Engine:
        """Construye un ``Engine`` siguiendo la configuración actual."""

        url = make_url(settings.database_url)
        backend = url.get_backend_name()
        candidate_keys = [backend]
        if "+" in backend:
            candidate_keys.append(backend.split("+")[0])

        configuration: EngineConfiguration | None = None
        for key in candidate_keys:
            factory = self._backends.get(key)
            if factory is not None:
                configuration = factory(settings, url)
                break

        if configuration is None:
            logger.info(
                "Backend '%s' sin configuración específica. Se usarán opciones genéricas.",
                backend,
            )
            configuration = EngineConfiguration()

        base_engine_kwargs: dict[str, Any] = {
            "echo": settings.database_echo,
            "future": True,
        }

        if settings.database_pool_pre_ping:
            base_engine_kwargs["pool_pre_ping"] = True

        if settings.database_pool_timeout is not None:
            base_engine_kwargs["pool_timeout"] = settings.database_pool_timeout

        if settings.database_pool_size is not None and settings.database_pool_size > 0:
            base_engine_kwargs["pool_size"] = settings.database_pool_size
        if settings.database_max_overflow is not None:
            base_engine_kwargs["max_overflow"] = settings.database_max_overflow
        if settings.database_pool_recycle is not None:
            base_engine_kwargs["pool_recycle"] = settings.database_pool_recycle

        engine_kwargs = {**base_engine_kwargs, **configuration.engine_kwargs}
        poolclass = engine_kwargs.get("poolclass")
        if poolclass is NullPool:
            for key in ("pool_size", "max_overflow", "pool_recycle", "pool_timeout"):
                engine_kwargs.pop(key, None)
        connect_args = configuration.connect_args

        engine = create_engine(
            settings.database_url,
            connect_args=connect_args,
            **engine_kwargs,
        )

        for callback in configuration.post_configure:
            try:
                callback(engine)
            except Exception:  # pragma: no cover - depende de terceros
                logger.exception("No se pudo ejecutar la configuración adicional del backend %s", backend)

        return engine

    # --- Configuraciones específicas por backend ---------------------------------

    def _configure_sqlite(self, settings: SettingsProtocol, url: URL) -> EngineConfiguration:
        connect_args = {"check_same_thread": False}
        engine_kwargs: dict[str, Any] = {"poolclass": NullPool}

        maintenance = SQLiteMaintenanceOptions(
            optimize=settings.sqlite_auto_optimize,
            wal_checkpoint=settings.sqlite_wal_checkpoint,
            vacuum=settings.sqlite_vacuum_on_startup,
            integrity_check=settings.sqlite_integrity_check,
        )

        def _post_configure(engine: Engine) -> None:
            configure_sqlite_engine(
                engine,
                cipher_key=settings.sqlite_encryption_key,
                require_encryption=settings.sqlite_require_encryption,
                journal_mode=settings.sqlite_journal_mode,
                enable_foreign_keys=settings.sqlite_foreign_keys,
                busy_timeout_ms=settings.sqlite_busy_timeout_ms,
                maintenance=maintenance,
            )

        return EngineConfiguration(
            connect_args=connect_args,
            engine_kwargs=engine_kwargs,
            post_configure=[_post_configure],
        )

    def _configure_postgresql(self, settings: SettingsProtocol, url: URL) -> EngineConfiguration:
        connect_args: dict[str, Any] = {}
        if settings.database_ssl_mode:
            connect_args["sslmode"] = settings.database_ssl_mode
            if settings.database_ssl_root_cert:
                connect_args["sslrootcert"] = settings.database_ssl_root_cert

        def _post_configure(engine: Engine) -> None:
            statement_timeout = settings.database_statement_timeout_ms
            application_name = settings.database_application_name
            with engine.connect() as connection:
                if application_name:
                    connection.execute(text("SET application_name = :name"), {"name": application_name})
                if statement_timeout is not None:
                    connection.execute(
                        text("SET statement_timeout = :timeout"),
                        {"timeout": statement_timeout},
                    )

        return EngineConfiguration(connect_args=connect_args, post_configure=[_post_configure])

    def _configure_mysql(self, settings: SettingsProtocol, url: URL) -> EngineConfiguration:
        engine_kwargs: dict[str, Any] = {}
        if settings.database_pool_recycle is None:
            engine_kwargs["pool_recycle"] = 1800
        return EngineConfiguration(engine_kwargs=engine_kwargs)

    def _configure_mssql(self, settings: SettingsProtocol, url: URL) -> EngineConfiguration:
        connect_args: dict[str, Any] = {}
        if settings.database_application_name:
            connect_args["application_name"] = settings.database_application_name
        return EngineConfiguration(connect_args=connect_args)

    def _configure_oracle(self, settings: SettingsProtocol, url: URL) -> EngineConfiguration:
        engine_kwargs: dict[str, Any] = {"poolclass": NullPool}

        def _post_configure(engine: Engine) -> None:
            if not settings.database_application_name:
                return
            try:
                with engine.connect() as connection:
                    connection.execute(
                        text(
                            "BEGIN DBMS_APPLICATION_INFO.SET_MODULE(:module, NULL); END;"
                        ),
                        {"module": settings.database_application_name},
                    )
            except Exception:  # pragma: no cover - depende del driver Oracle disponible
                logger.debug("No fue posible configurar DBMS_APPLICATION_INFO", exc_info=True)

        return EngineConfiguration(engine_kwargs=engine_kwargs, post_configure=[_post_configure])

    def _configure_snowflake(self, settings: SettingsProtocol, url: URL) -> EngineConfiguration:
        connect_args: dict[str, Any] = {}
        engine_kwargs: dict[str, Any] = {"poolclass": NullPool}

        if settings.database_application_name:
            connect_args["application"] = settings.database_application_name

        def _post_configure(engine: Engine) -> None:
            timeout_ms = settings.database_statement_timeout_ms
            if timeout_ms is None:
                return
            seconds = max(0, int(round(timeout_ms / 1000)))
            try:
                with engine.connect() as connection:
                    connection.execute(
                        text("ALTER SESSION SET STATEMENT_TIMEOUT_IN_SECONDS = :seconds"),
                        {"seconds": seconds},
                    )
            except Exception:  # pragma: no cover - depende del dialecto de Snowflake instalado
                logger.debug(
                    "No fue posible aplicar STATEMENT_TIMEOUT_IN_SECONDS en Snowflake", exc_info=True
                )

        return EngineConfiguration(
            connect_args=connect_args,
            engine_kwargs=engine_kwargs,
            post_configure=[_post_configure],
        )

    def _configure_http_sqlalchemy(self, settings: SettingsProtocol, url: URL) -> EngineConfiguration:
        """Configura backends que utilizan drivers basados en API HTTP."""

        engine_kwargs: dict[str, Any] = {"poolclass": NullPool}

        def _post_configure(engine: Engine) -> None:
            # Los motores basados en HTTP suelen respetar el parámetro ``application_name``
            # a través de encabezados personalizados. Intentamos enviarlo mediante
            # ``SET`` si el dialecto lo soporta, pero ignoramos cualquier fallo.
            application_name = settings.database_application_name
            if not application_name:
                return
            try:
                with engine.connect() as connection:
                    connection.execute(text("SET application_name = :name"), {"name": application_name})
            except Exception:  # pragma: no cover - depende del dialecto instalado
                logger.debug(
                    "No fue posible propagar application_name al backend HTTP %s", url,
                    exc_info=True,
                )

        return EngineConfiguration(engine_kwargs=engine_kwargs, post_configure=[_post_configure])


database_configurator = DatabaseConfigurator()

