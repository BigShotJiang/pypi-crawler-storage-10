"""Integraciones de SQLitePlus con el motor de SQLAlchemy."""
from __future__ import annotations

from contextlib import contextmanager, nullcontext
from dataclasses import dataclass
import logging
from pathlib import Path
import sqlite3
from typing import Any, Iterable, Iterator, Sequence

from sqlalchemy import event, text
from sqlalchemy.engine import Engine

# ``sqliteplus-enhanced`` es una dependencia opcional utilizada para aplicar
# optimizaciones sobre conexiones SQLite. Durante las pruebas del proyecto la
# librería puede no estar instalada, lo que provocaba un ``ModuleNotFoundError``
# en los imports anteriores. Para mantener el mismo comportamiento público y a
# la vez permitir la ejecución sin la dependencia externa, proporcionamos una
# implementación mínima de respaldo.
try:  # pragma: no cover - la rama principal se ejercita en la librería real
    from sqliteplus.utils.database_manager_sync import (
        DatabaseManager as SQLitePlusDatabaseManager,
    )
    from sqliteplus.utils.replication_sync import (
        SQLiteReplication as SQLitePlusReplication,
    )
    from sqliteplus.utils.sqliteplus_sync import (
        SQLitePlus,
        SQLitePlusCipherError,
        SQLitePlusQueryError,
        apply_cipher_key,
    )
except ModuleNotFoundError:  # pragma: no cover - sólo se ejecuta en ausencia del paquete
    import threading

    class SQLitePlusCipherError(RuntimeError):
        """Error genérico que imita a ``sqliteplus`` cuando falla el cifrado."""


    class SQLitePlusQueryError(RuntimeError):
        """Error que envuelve fallos de ejecución sobre SQLite."""


    def apply_cipher_key(connection, cipher_key: str | None) -> None:
        """Aplica de forma básica la clave de cifrado sobre la conexión.

        Esta versión de respaldo no ofrece cifrado real, pero mantiene la
        interfaz esperada por el resto del módulo ejecutando el pragma ``key``
        cuando se facilita una clave. De este modo se evita que el resto del
        código falle por la ausencia de ``sqliteplus-enhanced`` durante las
        pruebas o en entornos reducidos.
        """

        if not cipher_key:
            return

        cursor = connection.cursor()
        try:
            cursor.execute("PRAGMA key=?", (cipher_key,))
        finally:
            cursor.close()


    class SQLitePlusDatabaseManager:  # pragma: no cover - respaldo ligero
        """Implementación mínima para entornos sin ``sqliteplus-enhanced``."""

        def __init__(self, base_dir: str | Path = "databases") -> None:
            self.base_dir = Path(base_dir).expanduser().resolve()
            self.base_dir.mkdir(parents=True, exist_ok=True)
            self._connections: dict[str, sqlite3.Connection] = {}
            self.locks: dict[str, threading.Lock] = {}

        def _resolve_path(self, db_name: str) -> Path:
            target = Path(db_name)
            if not target.suffix:
                target = target.with_suffix(".db")
            db_path = (self.base_dir / target).resolve()
            if self.base_dir not in db_path.parents:
                raise ValueError("Nombre de base de datos fuera del directorio permitido")
            return db_path

        def execute_query(self, db_name: str, query: str, params: tuple[Any, ...] | tuple[()] = ()) -> Any:
            db_path = self._resolve_path(db_name)
            with sqlite3.connect(db_path) as connection:
                cursor = connection.cursor()
                try:
                    cursor.execute(query, params)
                    connection.commit()
                    return cursor.lastrowid
                finally:
                    cursor.close()

        def fetch_query(self, db_name: str, query: str, params: tuple[Any, ...] | tuple[()] = ()) -> list[tuple[Any, ...]]:
            db_path = self._resolve_path(db_name)
            with sqlite3.connect(db_path) as connection:
                cursor = connection.cursor()
                try:
                    cursor.execute(query, params)
                    return cursor.fetchall()
                finally:
                    cursor.close()

        def get_connection(self, db_name: str) -> sqlite3.Connection:
            """Devuelve una conexión persistente para la base ``db_name``."""

            db_path = self._resolve_path(db_name)
            key = db_path.stem
            connection = self._connections.get(key)
            if connection is None:
                connection = sqlite3.connect(db_path, check_same_thread=False)
                self._connections[key] = connection
                self.locks[key] = threading.Lock()
            return connection

        def close_connections(self) -> None:
            """Cierra todas las conexiones vivas creadas por el gestor."""

            for connection in self._connections.values():
                try:
                    connection.close()
                except Exception:  # pragma: no cover - limpieza defensiva
                    logger.debug("No se pudo cerrar una conexión SQLite de respaldo", exc_info=True)
            self._connections.clear()
            self.locks.clear()


    class SQLitePlusReplication:  # pragma: no cover - respaldo ligero
        """Utilidad básica de replicación y exportación."""

        def __init__(
            self,
            db_path: str | Path | None = None,
            backup_dir: str | Path = "backups",
            cipher_key: str | None = None,
        ) -> None:
            self.db_path = Path(db_path or "").expanduser().resolve()
            self.backup_dir = Path(backup_dir).expanduser().resolve()
            self.cipher_key = cipher_key
            self.backup_dir.mkdir(parents=True, exist_ok=True)

        def export_to_csv(self, table_name: str, output_file: str | Path) -> None:
            output_path = Path(output_file).expanduser().resolve()
            with sqlite3.connect(self.db_path) as connection:
                apply_cipher_key(connection, self.cipher_key)
                cursor = connection.cursor()
                try:
                    cursor.execute(f'SELECT * FROM "{table_name}"')
                    rows = cursor.fetchall()
                    headers = [column[0] for column in cursor.description or ()]
                finally:
                    cursor.close()

            import csv

            output_path.parent.mkdir(parents=True, exist_ok=True)
            with output_path.open("w", newline="", encoding="utf-8") as stream:
                writer = csv.writer(stream)
                if headers:
                    writer.writerow(headers)
                writer.writerows(rows)

        def backup_database(self) -> str:
            backup_path = self.backup_dir / f"backup_{_timestamp()}.db"
            return self.replicate_database(backup_path)

        def replicate_database(self, target_db_path: str | Path) -> str:
            target_path = Path(target_db_path).expanduser().resolve()
            target_path.parent.mkdir(parents=True, exist_ok=True)
            with sqlite3.connect(self.db_path) as source:
                apply_cipher_key(source, self.cipher_key)
                with sqlite3.connect(target_path) as replica:
                    apply_cipher_key(replica, self.cipher_key)
                    source.backup(replica)

            for suffix in ("-wal", "-shm"):
                source_side = self.db_path.with_name(f"{self.db_path.name}{suffix}")
                if source_side.exists():
                    replica_side = target_path.with_name(f"{target_path.name}{suffix}")
                    try:
                        if replica_side.exists():
                            replica_side.unlink()
                        import shutil

                        shutil.copy2(source_side, replica_side)
                    except Exception:  # pragma: no cover - operación best-effort
                        logger.debug(
                            "No se pudo replicar el archivo auxiliar %s", source_side, exc_info=True
                        )

            return str(target_path)


    class SQLitePlus:  # pragma: no cover - respaldo ligero
        """Implementación mínima de la API síncrona de SQLitePlus."""

        def __init__(self, db_path: str | Path, cipher_key: str | None = None) -> None:
            self.db_path = Path(db_path).expanduser().resolve()
            self.cipher_key = cipher_key
            self.lock = threading.Lock()
            self._initialize_db()

        def _initialize_db(self) -> None:
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            with sqlite3.connect(self.db_path) as connection:
                apply_cipher_key(connection, self.cipher_key)
                cursor = connection.cursor()
                try:
                    cursor.execute(
                        """
                        CREATE TABLE IF NOT EXISTS logs (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            action TEXT,
                            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                        )
                        """
                    )
                    connection.commit()
                finally:
                    cursor.close()

        def get_connection(self) -> sqlite3.Connection:
            connection = sqlite3.connect(self.db_path, check_same_thread=False)
            apply_cipher_key(connection, self.cipher_key)
            return connection

        def execute_query(self, query: str, params: Sequence[Any] | tuple[Any, ...] = ()) -> Any:
            with self.lock:
                with self.get_connection() as connection:
                    cursor = connection.cursor()
                    try:
                        cursor.execute(query, params)
                        connection.commit()
                        return cursor.lastrowid
                    except sqlite3.DatabaseError as exc:
                        raise SQLitePlusQueryError(exc) from exc
                    finally:
                        cursor.close()

        def fetch_query(self, query: str, params: Sequence[Any] | tuple[Any, ...] = ()) -> list[tuple[Any, ...]]:
            with self.lock:
                with self.get_connection() as connection:
                    cursor = connection.cursor()
                    try:
                        cursor.execute(query, params)
                        return cursor.fetchall()
                    except sqlite3.DatabaseError as exc:
                        raise SQLitePlusQueryError(exc) from exc
                    finally:
                        cursor.close()

        def log_action(self, action: str) -> int:
            return int(self.execute_query("INSERT INTO logs (action) VALUES (?)", (action,)))


logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class SQLiteMaintenanceOptions:
    """Opciones avanzadas aplicadas por SQLitePlus Enhanced."""

    optimize: bool = True
    wal_checkpoint: str | None = "TRUNCATE"
    vacuum: bool = False
    integrity_check: bool = False


@dataclass(frozen=True)
class SQLitePlusDatabase:
    """Acceso de alto nivel a bases SQLite gestionadas mediante SQLitePlus."""

    manager: SQLitePlusDatabaseManager
    name: str
    cipher_key: str | None = None

    def execute(self, query: str, params: Iterable[Any] | None = None) -> Any:
        """Ejecuta una sentencia de modificación devolviendo el ``lastrowid``."""

        return self.manager.execute_query(self.name, query, tuple(params or ()))

    def fetchall(self, query: str, params: Iterable[Any] | None = None) -> list[tuple[Any, ...]]:
        """Ejecuta una consulta de lectura y devuelve todos los registros."""

        return self.manager.fetch_query(self.name, query, tuple(params or ()))

    def fetchone(self, query: str, params: Iterable[Any] | None = None) -> tuple[Any, ...] | None:
        """Devuelve el primer registro de la consulta o ``None`` si está vacío."""

        rows = self.fetchall(query, params)
        return rows[0] if rows else None

    def fetchmany(
        self,
        query: str,
        params: Iterable[Any] | None = None,
        *,
        size: int = 100,
    ) -> list[tuple[Any, ...]]:
        """Obtiene un subconjunto de resultados sin cargar toda la tabla."""

        if size <= 0:
            raise ValueError("El parámetro 'size' debe ser positivo")

        with _locked_connection(self.manager, self.name, self.cipher_key) as connection:
            cursor = connection.cursor()
            try:
                cursor.execute(query, tuple(params or ()))
                return cursor.fetchmany(size)
            finally:
                cursor.close()

    def execute_many(
        self,
        query: str,
        parameters: Iterable[Sequence[Any]],
    ) -> int:
        """Ejecuta operaciones masivas de inserción o actualización."""

        with _locked_connection(self.manager, self.name, self.cipher_key) as connection:
            cursor = connection.cursor()
            try:
                batch = list(parameters)
                if not batch:
                    return 0
                cursor.executemany(query, batch)
                connection.commit()
                return cursor.rowcount if cursor.rowcount is not None else len(batch)
            finally:
                cursor.close()

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        """Proporciona un contexto transaccional seguro con rollback automático."""

        with _locked_connection(self.manager, self.name, self.cipher_key) as connection:
            cursor = connection.cursor()
            try:
                cursor.execute("BEGIN")
                yield connection
                connection.commit()
            except Exception:
                connection.rollback()
                raise
            finally:
                cursor.close()

    def stream_query(
        self,
        query: str,
        params: Iterable[Any] | None = None,
        *,
        chunk_size: int = 100,
    ) -> Iterator[tuple[Any, ...]]:
        """Genera resultados en bloques para procesarlos de manera incremental."""

        if chunk_size <= 0:
            raise ValueError("El parámetro 'chunk_size' debe ser positivo")

        with _locked_connection(self.manager, self.name, self.cipher_key) as connection:
            cursor = connection.cursor()
            try:
                cursor.execute(query, tuple(params or ()))
                while True:
                    rows = cursor.fetchmany(chunk_size)
                    if not rows:
                        break
                    for row in rows:
                        yield row
            finally:
                cursor.close()

    def executescript(self, script: str) -> None:
        """Ejecuta varias sentencias SQL en un único bloque."""

        db_path = _resolve_manager_path(self.manager, self.name)
        with sqlite3.connect(db_path) as connection:
            apply_cipher_key(connection, self.cipher_key)
            connection.executescript(script)

    def attach_database(self, alias: str, file_path: str | Path) -> None:
        """Adjunta una base de datos externa usando ``ATTACH DATABASE``."""

        normalized_alias = _normalize_identifier(alias)
        db_path = Path(file_path).expanduser().resolve()
        main_path = _resolve_manager_path(self.manager, self.name)
        connection = self.manager.get_connection(self.name)
        lock_ctx = _get_manager_lock(self.manager, main_path)
        with lock_ctx:
            cursor = connection.cursor()
            try:
                cursor.execute(
                    f"ATTACH DATABASE ? AS {normalized_alias}",
                    (str(db_path),),
                )
                connection.commit()
            finally:
                cursor.close()

    def detach_database(self, alias: str) -> None:
        """Elimina una base de datos adjunta previamente."""

        normalized_alias = _normalize_identifier(alias)
        main_path = _resolve_manager_path(self.manager, self.name)
        connection = self.manager.get_connection(self.name)
        lock_ctx = _get_manager_lock(self.manager, main_path)
        with lock_ctx:
            cursor = connection.cursor()
            try:
                cursor.execute(f"DETACH DATABASE {normalized_alias}")
                connection.commit()
            finally:
                cursor.close()

    def backup(self, backup_dir: str | Path | None = None) -> Path:
        """Genera una copia de seguridad física utilizando SQLitePlus."""

        replication = _create_replication(self.manager, self.name, backup_dir, self.cipher_key)
        return Path(replication.backup_database())

    def replicate_to(self, destination: str | Path) -> Path:
        """Replica la base actual en ``destination``."""

        replication = _create_replication(self.manager, self.name, None, self.cipher_key)
        return Path(replication.replicate_database(str(destination)))

    def export_table(self, table_name: str, output_file: str | Path) -> Path:
        """Exporta una tabla completa a CSV utilizando las utilidades oficiales."""

        replication = _create_replication(self.manager, self.name, None, self.cipher_key)
        replication.export_to_csv(table_name, str(output_file))
        return Path(output_file).expanduser().resolve()

    def list_tables(self) -> list[str]:
        """Devuelve las tablas de usuario ordenadas alfabéticamente."""

        rows = self.fetchall(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name;"
        )
        return [row[0] for row in rows if row]

    def pragma(self, pragma_sql: str) -> list[tuple[Any, ...]]:
        """Ejecuta sentencias ``PRAGMA`` personalizadas y devuelve su resultado."""

        return self.fetchall(pragma_sql)

    def log_action(self, action: str) -> int:
        """Almacena una acción en la bitácora gestionada por SQLitePlus."""

        sqliteplus = _create_sqliteplus_instance(self.manager, self.name, self.cipher_key)
        result = sqliteplus.log_action(action)
        if result is not None:
            return int(result)

        last_entry = self.fetchone("SELECT id FROM logs ORDER BY id DESC LIMIT 1")
        return int(last_entry[0]) if last_entry else 0

    def fetch_logs(
        self,
        *,
        limit: int | None = 100,
        newest_first: bool = True,
    ) -> list[tuple[Any, Any, Any]]:
        """Recupera registros de auditoría generados con ``log_action``."""

        _create_sqliteplus_instance(self.manager, self.name, self.cipher_key)
        order = "DESC" if newest_first else "ASC"
        sql = f"SELECT id, action, timestamp FROM logs ORDER BY id {order}"
        params: tuple[Any, ...] = ()
        if limit is not None:
            if limit <= 0:
                raise ValueError("El parámetro 'limit' debe ser positivo")
            sql += " LIMIT ?"
            params = (limit,)
        return self.fetchall(sql, params)

    def clear_logs(self) -> int:
        """Vacía la bitácora de SQLitePlus devolviendo el número de filas afectadas."""

        _create_sqliteplus_instance(self.manager, self.name, self.cipher_key)
        with _locked_connection(self.manager, self.name, self.cipher_key) as connection:
            cursor = connection.cursor()
            try:
                cursor.execute("DELETE FROM logs")
                connection.commit()
                return cursor.rowcount or 0
            finally:
                cursor.close()


def _ensure_database_directory(engine: Engine) -> None:
    """Crea el directorio contenedor de la base SQLite si aplica."""

    database = engine.url.database
    if not database or database == ":memory:":
        return

    db_path = Path(database).expanduser().resolve()
    try:
        db_path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:  # pragma: no cover - depende del sistema de ficheros
        logger.warning(
            "No se pudo crear el directorio para la base de datos SQLite '%s': %s",
            db_path.parent,
            exc,
        )


def _get_sqliteplus_manager(engine: Engine) -> tuple[SQLitePlusDatabaseManager, str] | None:
    """Devuelve una instancia del gestor de SQLitePlus y el nombre de la base."""

    database = engine.url.database
    if not database or database == ":memory:":
        return None

    db_path = Path(database).expanduser().resolve()
    manager = SQLitePlusDatabaseManager(base_dir=db_path.parent)
    return manager, db_path.name


def _resolve_manager_path(manager: SQLitePlusDatabaseManager, db_name: str) -> Path:
    """Calcula la ruta absoluta a un fichero gestionado por ``manager``."""

    base_dir = Path(getattr(manager, "base_dir", "")).expanduser().resolve()
    candidate = Path(db_name)
    if not candidate.suffix:
        candidate = candidate.with_suffix(".db")
    db_path = (base_dir / candidate).resolve()
    if base_dir and base_dir not in db_path.parents:
        raise ValueError("Nombre de base de datos fuera del directorio permitido")
    return db_path


def _get_manager_lock(manager: SQLitePlusDatabaseManager, db_path: Path):
    """Obtiene el cerrojo asociado al gestor o un ``nullcontext``."""

    locks = getattr(manager, "locks", None)
    if not locks:
        return nullcontext()
    canonical = db_path.stem
    lock = locks.get(canonical)
    return lock if lock is not None else nullcontext()


@contextmanager
def _locked_connection(
    manager: SQLitePlusDatabaseManager,
    db_name: str,
    cipher_key: str | None,
) -> Iterator[sqlite3.Connection]:
    """Proporciona una conexión sincronizada respetando las claves de cifrado."""

    db_path = _resolve_manager_path(manager, db_name)
    connection = manager.get_connection(db_name)
    lock_ctx = _get_manager_lock(manager, db_path)
    with lock_ctx:
        _apply_cipher(connection, cipher_key)
        yield connection


def _create_replication(
    manager: SQLitePlusDatabaseManager,
    db_name: str,
    backup_dir: str | Path | None,
    cipher_key: str | None,
) -> SQLitePlusReplication:
    """Inicializa una utilidad de replicación respetando la configuración actual."""

    db_path = _resolve_manager_path(manager, db_name)
    if backup_dir is None:
        backup_dir = db_path.parent / "backups"
    return SQLitePlusReplication(db_path=db_path, backup_dir=backup_dir, cipher_key=cipher_key)


def _apply_cipher(connection: sqlite3.Connection, cipher_key: str | None) -> None:
    """Aplica la clave de cifrado comprobando los errores comunes."""

    try:
        apply_cipher_key(connection, cipher_key)
    except SQLitePlusCipherError as exc:  # pragma: no cover - depende de SQLCipher real
        raise RuntimeError("No se pudo aplicar la clave de cifrado configurada.") from exc


def _create_sqliteplus_instance(
    manager: SQLitePlusDatabaseManager,
    db_name: str,
    cipher_key: str | None,
) -> SQLitePlus:
    """Crea un objeto ``SQLitePlus`` enlazado a la base de datos actual."""

    db_path = _resolve_manager_path(manager, db_name)
    return SQLitePlus(db_path=db_path, cipher_key=cipher_key)


def _normalize_identifier(raw_identifier: str) -> str:
    """Valida y normaliza identificadores SQL sencillos."""

    candidate = raw_identifier.strip()
    if not candidate:
        raise ValueError(f"Identificador SQL inválido: {raw_identifier!r}")
    normalized = candidate.replace("$", "_")
    if not normalized.isidentifier():
        raise ValueError(f"Identificador SQL inválido: {raw_identifier!r}")
    return candidate


def _timestamp() -> str:
    from datetime import datetime

    return datetime.utcnow().strftime("%Y%m%d_%H%M%S")


def _apply_maintenance(engine: Engine, options: SQLiteMaintenanceOptions) -> None:
    """Ejecuta tareas de mantenimiento asistidas por SQLitePlus."""

    manager_info = _get_sqliteplus_manager(engine)
    if manager_info is None:
        return

    manager, db_name = manager_info
    normalized_checkpoint = (
        options.wal_checkpoint.strip().upper() if options.wal_checkpoint else None
    )

    try:
        if normalized_checkpoint:
            manager.fetch_query(db_name, f"PRAGMA wal_checkpoint({normalized_checkpoint});")
        if options.optimize:
            manager.fetch_query(db_name, "PRAGMA optimize;")
        if options.vacuum:
            manager.execute_query(db_name, "VACUUM;")
        if options.integrity_check:
            result = manager.fetch_query(db_name, "PRAGMA quick_check;")
            status = result[0][0] if result else "unknown"
            if status != "ok":
                raise RuntimeError(
                    f"La comprobación de integridad de SQLite ha fallado: {status}"
                )
    except RuntimeError:
        raise
    except Exception:  # pragma: no cover - depende del backend real
        logger.exception("No se pudieron aplicar las tareas de mantenimiento de SQLitePlus")


def configure_sqlite_engine(
    engine: Engine,
    *,
    cipher_key: str | None,
    require_encryption: bool,
    journal_mode: str,
    enable_foreign_keys: bool,
    busy_timeout_ms: int | None,
    maintenance: SQLiteMaintenanceOptions | None = None,
) -> None:
    """Aplica mejoras de SQLitePlus al motor SQLAlchemy proporcionado."""

    _ensure_database_directory(engine)

    normalized_journal = journal_mode.strip().upper() if journal_mode else ""
    timeout_value = busy_timeout_ms if busy_timeout_ms is not None else None

    def _configure_connection(dbapi_connection, connection_record) -> None:  # type: ignore[override]
        if require_encryption and not cipher_key:
            raise RuntimeError(
                "Se requiere una clave de cifrado para las conexiones SQLite, "
                "pero no se proporcionó ninguna."
            )

        try:
            apply_cipher_key(dbapi_connection, cipher_key)
        except SQLitePlusCipherError as exc:  # pragma: no cover - depende de SQLCipher
            raise RuntimeError(
                "No se pudo aplicar la clave de cifrado configurada para SQLite."
            ) from exc

        cursor = dbapi_connection.cursor()
        try:
            if normalized_journal:
                cursor.execute(f"PRAGMA journal_mode={normalized_journal}")
            if enable_foreign_keys:
                cursor.execute("PRAGMA foreign_keys=ON")
            if timeout_value is not None:
                cursor.execute(f"PRAGMA busy_timeout={int(timeout_value)}")
        finally:
            cursor.close()

    event.listen(engine, "connect", _configure_connection)

    if maintenance is None:
        maintenance = SQLiteMaintenanceOptions()
    _apply_maintenance(engine, maintenance)


def gather_sqlite_diagnostics(engine: Engine) -> dict[str, Any]:
    """Recopila métricas del motor SQLite utilizando SQLitePlus Enhanced."""

    diagnostics: dict[str, Any] = {}
    if not engine.url.drivername.startswith("sqlite"):
        return diagnostics

    with engine.connect() as connection:
        diagnostics["journal_mode"] = connection.execute(text("PRAGMA journal_mode;")).scalar()
        diagnostics["foreign_keys"] = connection.execute(text("PRAGMA foreign_keys;")).scalar()
        diagnostics["busy_timeout"] = connection.execute(text("PRAGMA busy_timeout;")).scalar()

    manager_info = _get_sqliteplus_manager(engine)
    if manager_info is None:
        return diagnostics

    manager, db_name = manager_info
    try:
        page_count = manager.fetch_query(db_name, "PRAGMA page_count;")
        freelist = manager.fetch_query(db_name, "PRAGMA freelist_count;")
        if page_count:
            diagnostics["page_count"] = page_count[0][0]
        if freelist:
            diagnostics["freelist"] = freelist[0][0]
        sqlite_db = SQLitePlusDatabase(manager=manager, name=db_name)
        diagnostics["tables"] = sqlite_db.list_tables()
        db_path = _resolve_manager_path(manager, db_name)
        try:
            diagnostics["file_size_bytes"] = db_path.stat().st_size
        except OSError:  # pragma: no cover - depende del sistema de ficheros
            diagnostics["file_size_bytes"] = None
    except Exception:  # pragma: no cover - depende del backend real
        logger.debug("No se pudieron recopilar métricas extendidas de SQLitePlus", exc_info=True)

    return diagnostics


def get_sqliteplus_database(
    engine: Engine,
    *,
    cipher_key: str | None = None,
) -> SQLitePlusDatabase | None:
    """Devuelve un ``SQLitePlusDatabase`` asociado al ``Engine`` proporcionado."""

    manager_info = _get_sqliteplus_manager(engine)
    if manager_info is None:
        return None

    manager, db_name = manager_info
    return SQLitePlusDatabase(manager=manager, name=db_name, cipher_key=cipher_key)

