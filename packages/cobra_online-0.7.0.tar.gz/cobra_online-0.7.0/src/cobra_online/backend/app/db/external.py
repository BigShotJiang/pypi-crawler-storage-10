"""Conectores para APIs y bases de datos de terceros."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

import importlib
import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Mapping, MutableMapping
from urllib.parse import urlparse

import httpx

try:  # pragma: no cover - compatibilidad opcional para tipos de autenticación
    from httpx import Auth as HTTPXAuth, BaseTransport
except ImportError:  # pragma: no cover - httpx siempre está instalado pero mantenemos seguridad
    HTTPXAuth = object  # type: ignore[misc,assignment]
    BaseTransport = object  # type: ignore[misc,assignment]

if False:  # pragma: no cover - sólo para comprobaciones de tipos
    from app.core.config import Settings


logger = logging.getLogger(__name__)


@dataclass(slots=True)
class RESTAPIConfig:
    """Parámetros mínimos para inicializar un cliente REST."""

    base_url: str
    headers: MutableMapping[str, str] = field(default_factory=dict)
    timeout: float = 30.0
    auth: HTTPXAuth | tuple[str, str] | None = None


class RESTAPIClient:
    """Cliente síncrono basado en httpx para APIs REST convencionales."""

    def __init__(
        self,
        config: RESTAPIConfig,
        *,
        transport: BaseTransport | None = None,
    ) -> None:
        self._config = config
        self._client = httpx.Client(
            base_url=config.base_url,
            headers=dict(config.headers),
            timeout=config.timeout,
            auth=config.auth,
            transport=transport,
        )

    @property
    def base_url(self) -> str:
        return str(self._client.base_url)

    @property
    def timeout(self) -> float:
        return float(self._client.timeout)

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        json: Any = None,
        data: Any = None,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
    ) -> httpx.Response:
        """Realiza una petición HTTP genérica devolviendo la respuesta original."""

        response = self._client.request(
            method,
            path,
            params=params,
            json=json,
            data=data,
            headers=headers,
            timeout=timeout or self._client.timeout,
        )
        response.raise_for_status()
        return response

    def get(
        self,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
    ) -> httpx.Response:
        return self.request("GET", path, params=params, headers=headers, timeout=timeout)

    def post(
        self,
        path: str,
        *,
        json: Any = None,
        data: Any = None,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
    ) -> httpx.Response:
        return self.request("POST", path, json=json, data=data, headers=headers, timeout=timeout)

    def put(
        self,
        path: str,
        *,
        json: Any = None,
        data: Any = None,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
    ) -> httpx.Response:
        return self.request("PUT", path, json=json, data=data, headers=headers, timeout=timeout)

    def patch(
        self,
        path: str,
        *,
        json: Any = None,
        data: Any = None,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
    ) -> httpx.Response:
        return self.request("PATCH", path, json=json, data=data, headers=headers, timeout=timeout)

    def delete(
        self,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
    ) -> httpx.Response:
        return self.request("DELETE", path, params=params, headers=headers, timeout=timeout)

    def close(self) -> None:
        self._client.close()


@dataclass(slots=True)
class GraphQLAPIConfig:
    """Configuración para clientes GraphQL vía HTTP."""

    endpoint: str
    base_url: str | None = None
    headers: MutableMapping[str, str] = field(default_factory=dict)
    timeout: float = 30.0
    auth: HTTPXAuth | tuple[str, str] | None = None


class GraphQLAPIClient:
    """Cliente sencillo para ejecutar consultas GraphQL."""

    def __init__(
        self,
        config: GraphQLAPIConfig,
        *,
        transport: BaseTransport | None = None,
    ) -> None:
        base_url = config.base_url or config.endpoint
        self._endpoint = config.endpoint
        self._client = httpx.Client(
            base_url=base_url,
            headers=dict(config.headers),
            timeout=config.timeout,
            auth=config.auth,
            transport=transport,
        )

    @property
    def endpoint(self) -> str:
        return self._endpoint

    def execute(
        self,
        query: str,
        *,
        variables: Mapping[str, Any] | None = None,
        operation_name: str | None = None,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
    ) -> Mapping[str, Any]:
        """Realiza una llamada GraphQL devolviendo el payload JSON resultante."""

        payload: dict[str, Any] = {"query": query, "variables": dict(variables or {})}
        if operation_name:
            payload["operationName"] = operation_name
        response = self._client.post(
            self._endpoint,
            json=payload,
            headers=headers,
            timeout=timeout or self._client.timeout,
        )
        response.raise_for_status()
        return response.json()

    def close(self) -> None:
        self._client.close()


@dataclass(slots=True)
class DatabaseConnectionConfig:
    """Datos necesarios para inicializar un cliente de base de datos externo."""

    driver: str
    url: str
    options: MutableMapping[str, Any] = field(default_factory=dict)


class ThirdPartyDatabaseRegistry:
    """Registro de factorías para bases de datos populares no SQL."""

    def __init__(self) -> None:
        self._factories: dict[str, tuple[Callable[..., Any], tuple[str, ...]]] = {}
        self._connections: dict[str, DatabaseConnectionConfig] = {}
        self._register_builtin_databases()

    # ------------------------------------------------------------------
    # Registro de factorías
    def _register_builtin_databases(self) -> None:
        self.register_database("mongodb", self._create_mongodb_client, required_packages=("pymongo",))
        self.register_database("redis", self._create_redis_client, required_packages=("redis",))
        self.register_database("cassandra", self._create_cassandra_session, required_packages=("cassandra-driver",))
        self.register_database("elasticsearch", self._create_elasticsearch_client, required_packages=("elasticsearch",))
        self.register_database("dynamodb", self._create_dynamodb_resource, required_packages=("boto3",))
        self.register_database("influxdb", self._create_influxdb_client, required_packages=("influxdb-client",))

    def register_database(
        self,
        key: str,
        factory: Callable[..., Any],
        *,
        required_packages: Iterable[str] | None = None,
    ) -> None:
        """Registra una nueva factoría de conexiones externas."""

        packages = tuple(required_packages or ())
        self._factories[key] = (factory, packages)

    def available_drivers(self) -> list[str]:
        return sorted(self._factories)

    # ------------------------------------------------------------------
    # Gestión de conexiones declaradas por nombre
    def register_connection(self, alias: str, driver: str, url: str, **options: Any) -> None:
        """Asocia un alias a la configuración necesaria para abrir la conexión."""

        self._connections[alias] = DatabaseConnectionConfig(driver=driver, url=url, options=dict(options))

    def available_connections(self) -> list[str]:
        return sorted(self._connections)

    def get_connection_config(self, alias: str) -> DatabaseConnectionConfig:
        try:
            return self._connections[alias]
        except KeyError as exc:  # pragma: no cover - depende de uso externo
            raise KeyError(f"No existe una conexión externa registrada con el alias '{alias}'.") from exc

    def connect(self, alias: str) -> Any:
        """Crea una instancia del cliente asociado al alias proporcionado."""

        config = self.get_connection_config(alias)
        return self.create_database(config.driver, url=config.url, options=config.options)

    # ------------------------------------------------------------------
    # Construcción directa usando el driver
    def create_database(
        self,
        driver: str,
        *,
        url: str,
        options: Mapping[str, Any] | None = None,
    ) -> Any:
        try:
            factory, required = self._factories[driver]
        except KeyError as exc:
            raise KeyError(f"El driver externo '{driver}' no está registrado.") from exc

        for package in required:
            self._ensure_dependency(package, driver)
        return factory(url=url, **dict(options or {}))

    @staticmethod
    def _ensure_dependency(package: str, driver: str) -> None:
        try:
            importlib.import_module(package)
        except ModuleNotFoundError as exc:
            raise ModuleNotFoundError(
                f"El driver '{driver}' requiere instalar el paquete opcional '{package}'."
            ) from exc

    # ------------------------------------------------------------------
    # Implementaciones de factorías por defecto
    @staticmethod
    def _create_mongodb_client(*, url: str, **options: Any) -> Any:
        from pymongo import MongoClient  # type: ignore[import-not-found]

        return MongoClient(url, **options)

    @staticmethod
    def _create_redis_client(*, url: str, **options: Any) -> Any:
        from redis import Redis  # type: ignore[import-not-found]

        return Redis.from_url(url, **options)

    @staticmethod
    def _create_cassandra_session(*, url: str, **options: Any) -> Any:
        from cassandra.cluster import Cluster  # type: ignore[import-not-found]

        parsed = urlparse(url)
        contact_points = [host for host in parsed.netloc.split(",") if host]
        keyspace = parsed.path.lstrip("/") or None
        cluster = Cluster(contact_points, **options)
        return cluster.connect(keyspace)

    @staticmethod
    def _create_elasticsearch_client(*, url: str, **options: Any) -> Any:
        from elasticsearch import Elasticsearch  # type: ignore[import-not-found]

        return Elasticsearch(url, **options)

    @staticmethod
    def _create_dynamodb_resource(*, url: str, **options: Any) -> Any:
        import boto3  # type: ignore[import-not-found]

        return boto3.resource("dynamodb", endpoint_url=url, **options)

    @staticmethod
    def _create_influxdb_client(*, url: str, **options: Any) -> Any:
        from influxdb_client import InfluxDBClient  # type: ignore[import-not-found]

        return InfluxDBClient(url=url, **options)


class ExternalIntegrationManager:
    """Orquestador de integraciones REST, GraphQL y bases de datos externas."""

    def __init__(self) -> None:
        self._rest_clients: dict[str, RESTAPIClient] = {}
        self._graphql_clients: dict[str, GraphQLAPIClient] = {}
        self.databases = ThirdPartyDatabaseRegistry()

    # ------------------------------------------------------------------
    # Gestión REST
    def register_rest_api(
        self,
        name: str,
        *,
        base_url: str,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
        auth: HTTPXAuth | tuple[str, str] | None = None,
    ) -> RESTAPIClient:
        config = RESTAPIConfig(
            base_url=base_url,
            headers=dict(headers or {}),
            timeout=timeout if timeout is not None else 30.0,
            auth=auth,
        )
        client = RESTAPIClient(config)
        previous = self._rest_clients.get(name)
        if previous is not None:
            previous.close()
        self._rest_clients[name] = client
        return client

    def get_rest_api(self, name: str) -> RESTAPIClient:
        try:
            return self._rest_clients[name]
        except KeyError as exc:  # pragma: no cover - depende de uso en runtime
            raise KeyError(f"No existe una API REST registrada con el nombre '{name}'.") from exc

    def available_rest_apis(self) -> list[str]:
        return sorted(self._rest_clients)

    # ------------------------------------------------------------------
    # Gestión GraphQL
    def register_graphql_api(
        self,
        name: str,
        *,
        endpoint: str,
        base_url: str | None = None,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
        auth: HTTPXAuth | tuple[str, str] | None = None,
    ) -> GraphQLAPIClient:
        config = GraphQLAPIConfig(
            endpoint=endpoint,
            base_url=base_url,
            headers=dict(headers or {}),
            timeout=timeout if timeout is not None else 30.0,
            auth=auth,
        )
        client = GraphQLAPIClient(config)
        previous = self._graphql_clients.get(name)
        if previous is not None:
            previous.close()
        self._graphql_clients[name] = client
        return client

    def get_graphql_api(self, name: str) -> GraphQLAPIClient:
        try:
            return self._graphql_clients[name]
        except KeyError as exc:  # pragma: no cover - depende de uso en runtime
            raise KeyError(f"No existe un endpoint GraphQL registrado como '{name}'.") from exc

    def available_graphql_apis(self) -> list[str]:
        return sorted(self._graphql_clients)

    # ------------------------------------------------------------------
    # Configuración a partir de Settings
    def configure_from_settings(self, settings: "Settings") -> None:
        """Aplica las definiciones declaradas en la configuración global."""

        for name, raw_config in settings.external_api_endpoints.items():
            config = _normalize_rest_config(raw_config, section="external_api_endpoints", name=name)
            self.register_rest_api(name, **config)

        for name, raw_config in settings.graphql_api_endpoints.items():
            config = _normalize_graphql_config(raw_config, section="graphql_api_endpoints", name=name)
            self.register_graphql_api(name, **config)

        for alias, raw_config in settings.third_party_databases.items():
            config = _ensure_mapping(raw_config, section="third_party_databases", name=alias)
            driver = config.get("driver")
            url = config.get("url")
            if not driver or not url:
                logger.warning(
                    "Se ignoró la conexión '%s' por no definir 'driver' y 'url'.", alias
                )
                continue
            options = config.get("options")
            self.databases.register_connection(alias, str(driver), str(url), **dict(options or {}))

    # ------------------------------------------------------------------
    # Limpieza
    def close_all(self) -> None:
        """Cierra los clientes HTTP registrados para liberar recursos."""

        for client in self._rest_clients.values():
            client.close()
        for client in self._graphql_clients.values():
            client.close()

    # ------------------------------------------------------------------
    # Información auxiliar
    def summary(self) -> dict[str, Any]:
        """Devuelve una vista resumida de las integraciones activas."""

        return {
            "rest_apis": self.available_rest_apis(),
            "graphql_apis": self.available_graphql_apis(),
            "database_aliases": self.databases.available_connections(),
            "database_drivers": self.databases.available_drivers(),
        }


def _ensure_mapping(
    raw_value: Any,
    *,
    section: str,
    name: str,
) -> Mapping[str, Any]:
    if isinstance(raw_value, Mapping):
        return raw_value
    if isinstance(raw_value, str):
        return {"base_url": raw_value} if "api" in section else {"url": raw_value}
    raise TypeError(
        f"La entrada '{name}' de '{section}' debe ser un objeto JSON mapeable, se recibió: {type(raw_value)!r}."
    )


def _normalize_rest_config(
    raw_value: Any,
    *,
    section: str,
    name: str,
) -> dict[str, Any]:
    config = dict(_ensure_mapping(raw_value, section=section, name=name))
    base_url = config.get("base_url") or config.get("url")
    if not base_url:
        raise ValueError(f"La API REST '{name}' debe definir 'base_url'.")
    headers = config.get("headers") or {}
    timeout = config.get("timeout")
    auth = config.get("auth")
    return {
        "base_url": str(base_url),
        "headers": dict(headers),
        "timeout": float(timeout) if timeout is not None else None,
        "auth": auth,
    }


def _normalize_graphql_config(
    raw_value: Any,
    *,
    section: str,
    name: str,
) -> dict[str, Any]:
    config = dict(_ensure_mapping(raw_value, section=section, name=name))
    endpoint = config.get("endpoint") or config.get("url")
    if not endpoint:
        raise ValueError(f"El endpoint GraphQL '{name}' debe definir 'endpoint'.")
    headers = config.get("headers") or {}
    timeout = config.get("timeout")
    base_url = config.get("base_url")
    auth = config.get("auth")
    return {
        "endpoint": str(endpoint),
        "base_url": str(base_url) if base_url else None,
        "headers": dict(headers),
        "timeout": float(timeout) if timeout is not None else None,
        "auth": auth,
    }


external_integrations = ExternalIntegrationManager()
