"""Configuración central de la aplicación Cobra Online."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


# Ruta absoluta al directorio ``backend`` del proyecto.
_BACKEND_DIR = Path(__file__).resolve().parent.parent.parent
# Directorio donde se almacenará la base de datos SQLite por defecto.
_DEFAULT_DATA_DIR = _BACKEND_DIR / "data"
# Garantizamos que el directorio exista incluso en entornos de pruebas limpios.
_DEFAULT_DATA_DIR.mkdir(parents=True, exist_ok=True)
_DEFAULT_DB_PATH = _DEFAULT_DATA_DIR / "cobra.db"


class Settings(BaseSettings):
    """Parámetros base de configuración cargados desde variables de entorno."""

    project_name: str = Field(
        default="Cobra Online API",
        description="Nombre legible de la plataforma.",
    )
    description: str = Field(
        default=(
            "API principal de Cobra Online, plataforma abierta para servicios "
            "de Big Data y nube."
        ),
        description="Descripción corta de la API.",
    )
    version: str = Field(default="0.1.0", description="Versión del servicio.")
    api_host: str = Field(
        default="0.0.0.0",
        description="Interfaz en la que se expondrá la API cuando se ejecute desde la CLI.",
    )
    api_port: int = Field(
        default=8000,
        description="Puerto TCP utilizado por la API al ejecutarse desde la CLI.",
    )
    api_v1_prefix: str = Field(
        default="/api/v1",
        description="Prefijo raíz para las rutas versionadas de la API.",
    )
    database_url: str = Field(
        default=f"sqlite:///{_DEFAULT_DB_PATH.as_posix()}",
        description="Cadena de conexión a la base de datos principal.",
    )
    database_pool_size: int | None = Field(
        default=10,
        ge=0,
        description=(
            "Tamaño del pool de conexiones utilizado para bases de datos que "
            "soportan pooling nativo. Usa 0 para delegar en SQLAlchemy o deja "
            "None para aceptar el valor por defecto del driver."
        ),
    )
    database_max_overflow: int | None = Field(
        default=20,
        ge=0,
        description=(
            "Número máximo de conexiones adicionales que se pueden abrir "
            "temporalmente sobre el tamaño del pool."
        ),
    )
    database_pool_timeout: float = Field(
        default=30.0,
        ge=0.0,
        description=(
            "Tiempo (en segundos) que SQLAlchemy esperará antes de lanzar un "
            "timeout al solicitar una conexión del pool."
        ),
    )
    database_pool_recycle: int | None = Field(
        default=None,
        ge=0,
        description=(
            "Tiempo (en segundos) tras el cual se reciclan conexiones "
            "inactivas. Útil para MySQL o MariaDB cuando existe un "
            "`wait_timeout` agresivo."
        ),
    )
    database_pool_pre_ping: bool = Field(
        default=True,
        description=(
            "Activa la verificación `pre_ping` de SQLAlchemy para descartar "
            "conexiones colgadas antes de entregarlas a la aplicación."
        ),
    )
    database_echo: bool = Field(
        default=False,
        description=(
            "Habilita el modo `echo` de SQLAlchemy para registrar las "
            "consultas emitidas. Útil para depuración."
        ),
    )
    database_statement_timeout_ms: int | None = Field(
        default=None,
        ge=0,
        description=(
            "Tiempo máximo (en ms) para consultas SQL en PostgreSQL y "
            "motores compatibles."
        ),
    )
    database_application_name: str | None = Field(
        default=None,
        description=(
            "Nombre de aplicación aplicado a la sesión para facilitar el "
            "trazado en motores que lo soportan (PostgreSQL, SQL Server)."
        ),
    )
    database_ssl_mode: str | None = Field(
        default=None,
        description=(
            "Modo SSL/TLS para conexiones PostgreSQL (`require`, `verify-full`, "
            "etc.)."
        ),
    )
    database_ssl_root_cert: str | None = Field(
        default=None,
        description=(
            "Ruta al certificado raíz a utilizar en conexiones TLS cuando el "
            "driver lo permite."
        ),
    )
    sqlite_encryption_key: str | None = Field(
        default=None,
        validation_alias=AliasChoices("sqlite_encryption_key", "SQLITE_DB_KEY"),
        description=(
            "Clave opcional de SQLCipher aplicada a conexiones SQLite cuando se "
            "utiliza SQLitePlus."
        ),
    )
    sqlite_require_encryption: bool = Field(
        default=False,
        description=(
            "Si es verdadero se exige que exista una clave de cifrado para las "
            "bases de datos SQLite."
        ),
    )
    sqlite_journal_mode: str = Field(
        default="WAL",
        description="Modo de journal para las bases SQLite gestionadas con SQLitePlus.",
    )
    sqlite_foreign_keys: bool = Field(
        default=True,
        description="Activa el cumplimiento de claves foráneas en conexiones SQLite.",
    )
    sqlite_busy_timeout_ms: int | None = Field(
        default=5000,
        ge=0,
        description="Tiempo de espera en milisegundos para bloqueos SQLite (0 para desactivar).",
    )
    sqlite_auto_optimize: bool = Field(
        default=True,
        description=(
            "Ejecuta `PRAGMA optimize` al inicializar la conexión SQLite usando "
            "SQLitePlus Enhanced."
        ),
    )
    sqlite_vacuum_on_startup: bool = Field(
        default=False,
        description="Ejecuta `VACUUM` al iniciar el motor SQLite.",
    )
    sqlite_wal_checkpoint: str | None = Field(
        default="TRUNCATE",
        description=(
            "Modo de `wal_checkpoint` a aplicar automáticamente. Usa `None` "
            "para omitirlo."
        ),
    )
    sqlite_integrity_check: bool = Field(
        default=False,
        description=(
            "Realiza `PRAGMA quick_check` al iniciar SQLite y detiene la "
            "aplicación si falla."
        ),
    )
    external_api_endpoints: dict[str, dict[str, object]] = Field(
        default_factory=dict,
        description=(
            "Listado de APIs REST de terceros disponibles. Cada entrada debe "
            "especificar al menos `base_url` y puede incluir `headers`, "
            "`timeout` y credenciales de autenticación. El valor se pasa como "
            "JSON en la variable de entorno `EXTERNAL_API_ENDPOINTS`."
        ),
    )
    graphql_api_endpoints: dict[str, dict[str, object]] = Field(
        default_factory=dict,
        description=(
            "Listado de endpoints GraphQL gestionados por la plataforma. Cada "
            "elemento acepta las claves `endpoint`, `base_url`, `headers` y "
            "`timeout`."
        ),
    )
    third_party_databases: dict[str, dict[str, object]] = Field(
        default_factory=dict,
        description=(
            "Configuraciones para conexiones a bases de datos externas como "
            "MongoDB, Redis o DynamoDB. Cada entrada requiere al menos `driver` "
            "y `url`, pudiendo añadir `options` adicionales. Se espera un JSON "
            "válido en la variable `THIRD_PARTY_DATABASES`."
        ),
    )
    api_keys: list[str] = Field(
        default_factory=list,
        description=(
            "Listado de claves válidas para acceder a la API. Si se deja vacío "
            "la API permanece abierta."
        ),
    )
    api_key_master_secret: str = Field(
        default="cobra-online-insecure-secret",
        min_length=16,
        description=(
            "Secreto maestro utilizado para firmar y almacenar de forma segura las "
            "API keys gestionadas desde la plataforma."
        ),
    )

    model_config = SettingsConfigDict(env_file=".env", case_sensitive=True)


@lru_cache
def get_settings() -> Settings:
    """Devuelve una instancia cacheada de la configuración."""

    return Settings()


settings = get_settings()
