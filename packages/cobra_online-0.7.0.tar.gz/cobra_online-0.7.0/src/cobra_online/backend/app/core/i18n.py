from __future__ import annotations

"""Herramientas básicas de internacionalización para la API."""

from functools import lru_cache
from typing import Final

DEFAULT_LOCALE: Final[str] = "es"
SUPPORTED_LOCALES: Final[set[str]] = {"es", "en", "pt"}

_TRANSLATIONS: Final[dict[str, dict[str, str]]] = {
    "es": {
        "health.status_message": "Servicio operativo. Cobra_Online responde correctamente.",
        "health.metrics_summary": (
            "Resumen agregado de recursos, API keys y su ventana de expiración configurable."
        ),
        "docs.health": "https://github.com/cobra-online/cobra_online/blob/main/docs/README.md",
        "docs.health.en": "https://github.com/cobra-online/cobra_online/blob/main/docs/README.en.md",
    },
    "en": {
        "health.status_message": "Service operating normally. Cobra_Online is responding as expected.",
        "health.metrics_summary": (
            "Aggregated overview for resources, API keys and the configurable expiration window."
        ),
        "docs.health": "https://github.com/cobra-online/cobra_online/blob/main/docs/README.en.md",
        "docs.health.en": "https://github.com/cobra-online/cobra_online/blob/main/docs/README.en.md",
    },
    "pt": {
        "health.status_message": "Serviço operacional. Cobra_Online está respondendo corretamente.",
        "health.metrics_summary": (
            "Resumo agregado de recursos, chaves de API e da janela configurável de expiração."
        ),
        "docs.health": "https://github.com/cobra-online/cobra_online/blob/main/docs/README.pt.md",
    },
}


def _normalise_locale(value: str | None) -> str | None:
    """Convierte un valor arbitrario a un código ISO 639-1 válido."""

    if not value:
        return None

    cleaned = value.strip().lower()
    if not cleaned:
        return None

    for separator in ("-", "_"):
        if separator in cleaned:
            cleaned = cleaned.split(separator, 1)[0]
            break

    if cleaned in SUPPORTED_LOCALES:
        return cleaned
    return None


def resolve_locale(*, lang: str | None = None, accept_language: str | None = None) -> str:
    """Selecciona el idioma más adecuado en base a parámetros y cabeceras."""

    candidate = _normalise_locale(lang)
    if candidate:
        return candidate

    if accept_language:
        for part in accept_language.split(","):
            token = part.strip()
            if not token:
                continue
            main = token.split(";", 1)[0].strip()
            candidate = _normalise_locale(main)
            if candidate:
                return candidate

    return DEFAULT_LOCALE


@lru_cache(maxsize=32)
def translate(key: str, locale: str) -> str:
    """Obtiene una cadena traducida con retroceso al idioma por defecto."""

    normalized = _normalise_locale(locale) or DEFAULT_LOCALE
    translations = _TRANSLATIONS.get(normalized, {})
    if key in translations:
        return translations[key]

    fallback = _TRANSLATIONS[DEFAULT_LOCALE]
    if key not in fallback:
        raise KeyError(f"No existe la clave de traducción '{key}'.")

    return fallback[key]


def documentation_url(locale: str) -> str:
    """Devuelve la URL de documentación más apropiada para el idioma solicitado."""

    normalized = _normalise_locale(locale) or DEFAULT_LOCALE
    if normalized == "en":
        return _TRANSLATIONS["en"]["docs.health"]
    if normalized == "pt":
        return _TRANSLATIONS["pt"]["docs.health"]

    return _TRANSLATIONS["es"]["docs.health"]
