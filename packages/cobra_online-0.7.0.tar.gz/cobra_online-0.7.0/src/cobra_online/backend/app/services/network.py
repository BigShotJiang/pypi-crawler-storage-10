"""Servicios de dominio para los módulos de red."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from typing import Any

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models import (
    NetworkLoadBalancer,
    NetworkLoadBalancerProtocol,
    NetworkLoadBalancerStatus,
)


class NetworkLoadBalancerAlreadyExistsError(Exception):
    """Se lanza cuando se intenta registrar un balanceador con nombre duplicado."""


class NetworkLoadBalancerNotFoundError(Exception):
    """Se lanza cuando el balanceador solicitado no existe."""


def list_load_balancers(
    db: Session,
    *,
    protocol: NetworkLoadBalancerProtocol | None = None,
    status: NetworkLoadBalancerStatus | None = None,
    region: str | None = None,
    name: str | None = None,
) -> list[NetworkLoadBalancer]:
    """Devuelve los balanceadores aplicando filtros opcionales."""

    statement = select(NetworkLoadBalancer).order_by(NetworkLoadBalancer.created_at.asc())
    if protocol is not None:
        statement = statement.where(NetworkLoadBalancer.protocol == protocol)
    if status is not None:
        statement = statement.where(NetworkLoadBalancer.status == status)
    if region is not None:
        statement = statement.where(NetworkLoadBalancer.region == region)
    if name is not None:
        statement = statement.where(NetworkLoadBalancer.name == name)
    return list(db.scalars(statement))


def get_load_balancer(db: Session, load_balancer_id: int) -> NetworkLoadBalancer:
    """Obtiene un balanceador específico o lanza un error si no existe."""

    load_balancer = db.get(NetworkLoadBalancer, load_balancer_id)
    if load_balancer is None:
        raise NetworkLoadBalancerNotFoundError(load_balancer_id)
    return load_balancer


def create_load_balancer(
    db: Session,
    *,
    name: str,
    protocol: NetworkLoadBalancerProtocol,
    port: int,
    region: str,
    status: NetworkLoadBalancerStatus | None = None,
) -> NetworkLoadBalancer:
    """Crea un nuevo balanceador de carga."""

    load_balancer = NetworkLoadBalancer(
        name=name,
        protocol=protocol,
        port=port,
        region=region,
    )
    if status is not None:
        load_balancer.status = status

    db.add(load_balancer)
    try:
        db.commit()
    except IntegrityError as exc:  # pragma: no cover - se relanza con contexto claro
        db.rollback()
        raise NetworkLoadBalancerAlreadyExistsError(name) from exc
    db.refresh(load_balancer)
    return load_balancer


def delete_load_balancer(db: Session, load_balancer_id: int) -> None:
    """Elimina un balanceador existente si está registrado."""

    load_balancer = get_load_balancer(db, load_balancer_id)
    db.delete(load_balancer)
    db.commit()


def update_load_balancer(
    db: Session, load_balancer_id: int, **changes: Any
) -> NetworkLoadBalancer:
    """Actualiza los campos suministrados de un balanceador."""

    load_balancer = get_load_balancer(db, load_balancer_id)
    if not changes:
        return load_balancer

    allowed_fields = {"name", "protocol", "port", "region", "status"}
    invalid_fields = set(changes) - allowed_fields
    if invalid_fields:
        raise ValueError(
            "Se intentaron actualizar campos no soportados: " + ", ".join(sorted(invalid_fields))
        )

    for field, value in changes.items():
        if field in allowed_fields:
            setattr(load_balancer, field, value)

    try:
        db.commit()
    except IntegrityError as exc:  # pragma: no cover - se relanza con contexto claro
        db.rollback()
        if "name" in changes:
            raise NetworkLoadBalancerAlreadyExistsError(changes["name"]) from exc
        raise

    db.refresh(load_balancer)
    return load_balancer
