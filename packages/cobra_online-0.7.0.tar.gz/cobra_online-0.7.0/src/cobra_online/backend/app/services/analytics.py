"""Servicios de dominio para pipelines de análisis de datos."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from typing import Any

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models import (
    AnalyticsEngine,
    AnalyticsPipeline,
    AnalyticsPipelineMode,
    AnalyticsPipelineStatus,
)


class AnalyticsPipelineAlreadyExistsError(Exception):
    """Se lanza al intentar registrar un pipeline con un nombre duplicado."""


class AnalyticsPipelineNotFoundError(Exception):
    """Se lanza cuando se consulta un pipeline inexistente."""


def list_pipelines(
    db: Session,
    *,
    engine: AnalyticsEngine | None = None,
    status: AnalyticsPipelineStatus | None = None,
    name: str | None = None,
    mode: AnalyticsPipelineMode | None = None,
) -> list[AnalyticsPipeline]:
    """Recupera los pipelines aplicando filtros opcionales."""

    statement = select(AnalyticsPipeline).order_by(AnalyticsPipeline.created_at.asc())
    if engine is not None:
        statement = statement.where(AnalyticsPipeline.engine == engine)
    if status is not None:
        statement = statement.where(AnalyticsPipeline.status == status)
    if name is not None:
        statement = statement.where(AnalyticsPipeline.name == name)
    if mode is not None:
        statement = statement.where(AnalyticsPipeline.mode == mode)
    return list(db.scalars(statement))


def get_pipeline(db: Session, pipeline_id: int) -> AnalyticsPipeline:
    """Obtiene un pipeline específico o lanza un error si no existe."""

    pipeline = db.get(AnalyticsPipeline, pipeline_id)
    if pipeline is None:
        raise AnalyticsPipelineNotFoundError(pipeline_id)
    return pipeline


def create_pipeline(
    db: Session,
    *,
    name: str,
    engine: AnalyticsEngine,
    mode: AnalyticsPipelineMode = AnalyticsPipelineMode.BATCH,
    schedule: str | None = None,
    description: str | None = None,
    status: AnalyticsPipelineStatus | None = None,
) -> AnalyticsPipeline:
    """Crea un pipeline de análisis en la base de datos."""

    pipeline = AnalyticsPipeline(
        name=name,
        engine=engine,
        mode=mode,
        schedule=schedule,
        description=description,
    )
    if status is not None:
        pipeline.status = status

    db.add(pipeline)
    try:
        db.commit()
    except IntegrityError as exc:  # pragma: no cover - se relanza con contexto claro
        db.rollback()
        raise AnalyticsPipelineAlreadyExistsError(name) from exc

    db.refresh(pipeline)
    return pipeline


def delete_pipeline(db: Session, pipeline_id: int) -> None:
    """Elimina un pipeline del catálogo."""

    pipeline = get_pipeline(db, pipeline_id)
    db.delete(pipeline)
    db.commit()


def update_pipeline(db: Session, pipeline_id: int, **changes: Any) -> AnalyticsPipeline:
    """Actualiza los campos proporcionados para un pipeline."""

    pipeline = get_pipeline(db, pipeline_id)
    if not changes:
        return pipeline

    allowed_fields = {"name", "engine", "mode", "schedule", "description", "status"}
    invalid_fields = set(changes) - allowed_fields
    if invalid_fields:
        raise ValueError(
            "Se intentaron actualizar campos no soportados: " + ", ".join(sorted(invalid_fields))
        )

    for field, value in changes.items():
        if field in allowed_fields:
            setattr(pipeline, field, value)

    try:
        db.commit()
    except IntegrityError as exc:  # pragma: no cover - se relanza con contexto claro
        db.rollback()
        if "name" in changes:
            raise AnalyticsPipelineAlreadyExistsError(changes["name"]) from exc
        raise

    db.refresh(pipeline)
    return pipeline


def summarize_pipelines(db: Session) -> dict[str, dict[str, int] | int]:
    """Devuelve métricas agregadas de los pipelines registrados."""

    summary: dict[str, dict[str, int] | int] = {
        "total": 0,
        "by_status": {},
        "by_engine": {},
        "by_mode": {},
    }

    summary["total"] = db.scalar(select(func.count()).select_from(AnalyticsPipeline)) or 0

    status_rows = db.execute(
        select(AnalyticsPipeline.status, func.count())
        .group_by(AnalyticsPipeline.status)
        .order_by(AnalyticsPipeline.status)
    ).all()
    summary["by_status"] = {
        status.value if hasattr(status, "value") else str(status): count
        for status, count in status_rows
    }

    engine_rows = db.execute(
        select(AnalyticsPipeline.engine, func.count())
        .group_by(AnalyticsPipeline.engine)
        .order_by(AnalyticsPipeline.engine)
    ).all()
    summary["by_engine"] = {
        engine.value if hasattr(engine, "value") else str(engine): count
        for engine, count in engine_rows
    }

    mode_rows = db.execute(
        select(AnalyticsPipeline.mode, func.count())
        .group_by(AnalyticsPipeline.mode)
        .order_by(AnalyticsPipeline.mode)
    ).all()
    summary["by_mode"] = {
        mode.value if hasattr(mode, "value") else str(mode): count
        for mode, count in mode_rows
    }

    return summary
