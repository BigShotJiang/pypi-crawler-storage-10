"""Servicios relacionados con la gestión de API keys."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

import hmac
from datetime import datetime, timezone
from secrets import token_urlsafe
from typing import Any

from sqlalchemy import Select, and_, func, select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models import ApiKey


class ApiKeyNotFoundError(Exception):
    """Se lanza cuando se consulta una API key inexistente."""


class ApiKeyAlreadyRevokedError(Exception):
    """Se lanza si se intenta revocar una API key ya revocada."""


def _hash_api_key(raw_key: str) -> str:
    """Calcula una huella criptográfica usando un HMAC con SHA-256."""

    import hashlib

    secret = settings.api_key_master_secret.encode("utf-8")
    digest = hmac.new(secret, raw_key.encode("utf-8"), hashlib.sha256)
    return digest.hexdigest()


def _active_keys_statement(*extra_filters: Any) -> Select[tuple[ApiKey]]:
    """Construye una consulta que filtra únicamente API keys activas."""

    now = datetime.now(tz=timezone.utc)
    conditions = [ApiKey.revoked.is_(False)]
    conditions.append(
        (ApiKey.expires_at.is_(None)) | (ApiKey.expires_at > now)  # type: ignore[operator]
    )
    conditions.extend(extra_filters)
    return select(ApiKey).where(and_(*conditions)).order_by(ApiKey.created_at.asc())


def any_active_api_keys(db: Session) -> bool:
    """Indica si existe al menos una API key activa almacenada."""

    stmt = _active_keys_statement().limit(1)
    count = db.scalar(select(func.count()).select_from(stmt.subquery()))
    return bool(count and count > 0)


def list_api_keys(db: Session) -> list[ApiKey]:
    """Devuelve todas las API keys registradas ordenadas por creación."""

    return list(db.scalars(select(ApiKey).order_by(ApiKey.created_at.asc())))


def create_api_key(
    db: Session, *, name: str, expires_at: datetime | None = None
) -> tuple[ApiKey, str]:
    """Genera una nueva API key persistente y devuelve su valor en claro."""

    secret = token_urlsafe(32)
    prefix = secret[:12]
    api_key = ApiKey(
        name=name,
        key_prefix=prefix,
        hashed_key=_hash_api_key(secret),
        expires_at=expires_at,
    )
    db.add(api_key)
    db.commit()
    db.refresh(api_key)
    return api_key, secret


def get_api_key(db: Session, api_key_id: int) -> ApiKey:
    """Obtiene una API key por identificador."""

    api_key = db.get(ApiKey, api_key_id)
    if api_key is None:
        raise ApiKeyNotFoundError(api_key_id)
    return api_key


def revoke_api_key(db: Session, api_key_id: int) -> ApiKey:
    """Revoca una API key activa para impedir su uso posterior."""

    api_key = get_api_key(db, api_key_id)
    if api_key.revoked:
        raise ApiKeyAlreadyRevokedError(api_key_id)
    api_key.revoked = True
    api_key.last_used_at = datetime.now(tz=timezone.utc)
    db.add(api_key)
    db.commit()
    db.refresh(api_key)
    return api_key


def verify_api_key(db: Session, raw_key: str) -> ApiKey | None:
    """Valida una API key y actualiza sus metadatos si es correcta."""

    hashed = _hash_api_key(raw_key)
    stmt = _active_keys_statement(ApiKey.hashed_key == hashed)
    api_key = db.scalar(stmt)
    if api_key is None:
        return None

    api_key.last_used_at = datetime.now(tz=timezone.utc)
    db.add(api_key)
    db.commit()
    db.refresh(api_key)
    return api_key

