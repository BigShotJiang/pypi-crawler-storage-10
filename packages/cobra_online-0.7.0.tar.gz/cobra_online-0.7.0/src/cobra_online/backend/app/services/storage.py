"""Servicios de dominio para el módulo de almacenamiento."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from typing import Any

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models import StorageBucket


class StorageBucketAlreadyExistsError(Exception):
    """Se lanza cuando se intenta crear un bucket con un nombre duplicado."""


class StorageBucketNotFoundError(Exception):
    """Se lanza cuando el bucket solicitado no existe."""


def list_buckets(
    db: Session,
    *,
    region: str | None = None,
    name: str | None = None,
) -> list[StorageBucket]:
    """Devuelve los buckets registrados aplicando filtros opcionales."""

    statement = select(StorageBucket).order_by(StorageBucket.created_at.asc())
    if region is not None:
        statement = statement.where(StorageBucket.region == region)
    if name is not None:
        statement = statement.where(StorageBucket.name == name)
    return list(db.scalars(statement))


def get_bucket(db: Session, bucket_id: int) -> StorageBucket:
    """Obtiene un bucket específico o lanza un error si no existe."""

    bucket = db.get(StorageBucket, bucket_id)
    if bucket is None:
        raise StorageBucketNotFoundError(bucket_id)
    return bucket


def create_bucket(
    db: Session,
    *,
    name: str,
    region: str,
    description: str | None = None,
) -> StorageBucket:
    """Crea un bucket nuevo en la base de datos."""

    bucket = StorageBucket(name=name, region=region, description=description)
    db.add(bucket)
    try:
        db.commit()
    except IntegrityError as exc:  # pragma: no cover - se relanza con contexto claro
        db.rollback()
        raise StorageBucketAlreadyExistsError(name) from exc
    db.refresh(bucket)
    return bucket


def delete_bucket(db: Session, bucket_id: int) -> None:
    """Elimina un bucket existente si está registrado."""

    bucket = get_bucket(db, bucket_id)
    db.delete(bucket)
    db.commit()


def update_bucket(db: Session, bucket_id: int, **changes: Any) -> StorageBucket:
    """Actualiza los campos proporcionados de un bucket."""

    bucket = get_bucket(db, bucket_id)
    if not changes:
        return bucket

    allowed_fields = {"name", "region", "description"}
    invalid_fields = set(changes) - allowed_fields
    if invalid_fields:
        raise ValueError(
            "Se intentaron actualizar campos no soportados: " + ", ".join(sorted(invalid_fields))
        )

    for field, value in changes.items():
        if field in allowed_fields:
            setattr(bucket, field, value)

    try:
        db.commit()
    except IntegrityError as exc:  # pragma: no cover - se relanza con contexto claro
        db.rollback()
        if "name" in changes:
            raise StorageBucketAlreadyExistsError(changes["name"]) from exc
        raise

    db.refresh(bucket)
    return bucket
