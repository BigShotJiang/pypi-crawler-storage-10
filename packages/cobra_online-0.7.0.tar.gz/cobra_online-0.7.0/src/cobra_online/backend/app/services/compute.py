"""Servicios de dominio para el módulo de cómputo."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from typing import Any

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models import ComputeInstance, ComputeInstanceStatus


class ComputeInstanceAlreadyExistsError(Exception):
    """Se lanza cuando se intenta registrar una instancia con nombre duplicado."""


class ComputeInstanceNotFoundError(Exception):
    """Se lanza cuando la instancia solicitada no existe."""


def list_instances(
    db: Session,
    *,
    region: str | None = None,
    status: ComputeInstanceStatus | None = None,
    image: str | None = None,
    name: str | None = None,
) -> list[ComputeInstance]:
    """Devuelve las instancias aplicando filtros opcionales."""

    statement = select(ComputeInstance).order_by(ComputeInstance.created_at.asc())
    if region is not None:
        statement = statement.where(ComputeInstance.region == region)
    if status is not None:
        statement = statement.where(ComputeInstance.status == status)
    if image is not None:
        statement = statement.where(ComputeInstance.image == image)
    if name is not None:
        statement = statement.where(ComputeInstance.name == name)
    return list(db.scalars(statement))


def get_instance(db: Session, instance_id: int) -> ComputeInstance:
    """Obtiene una instancia específica o lanza un error si no existe."""

    instance = db.get(ComputeInstance, instance_id)
    if instance is None:
        raise ComputeInstanceNotFoundError(instance_id)
    return instance


def create_instance(
    db: Session,
    *,
    name: str,
    image: str,
    region: str,
    vcpus: int,
    memory_gb: int,
    status: ComputeInstanceStatus | None = None,
) -> ComputeInstance:
    """Crea una nueva instancia de cómputo."""

    instance = ComputeInstance(
        name=name,
        image=image,
        region=region,
        vcpus=vcpus,
        memory_gb=memory_gb,
    )
    if status is not None:
        instance.status = status

    db.add(instance)
    try:
        db.commit()
    except IntegrityError as exc:  # pragma: no cover - se relanza con contexto claro
        db.rollback()
        raise ComputeInstanceAlreadyExistsError(name) from exc
    db.refresh(instance)
    return instance


def delete_instance(db: Session, instance_id: int) -> None:
    """Elimina una instancia existente si está registrada."""

    instance = get_instance(db, instance_id)
    db.delete(instance)
    db.commit()


def update_instance(db: Session, instance_id: int, **changes: Any) -> ComputeInstance:
    """Actualiza los campos suministrados de una instancia."""

    instance = get_instance(db, instance_id)
    if not changes:
        return instance

    allowed_fields = {"name", "image", "region", "vcpus", "memory_gb", "status"}
    invalid_fields = set(changes) - allowed_fields
    if invalid_fields:
        raise ValueError(
            "Se intentaron actualizar campos no soportados: " + ", ".join(sorted(invalid_fields))
        )

    for field, value in changes.items():
        if field in allowed_fields:
            setattr(instance, field, value)

    try:
        db.commit()
    except IntegrityError as exc:  # pragma: no cover - se relanza con contexto claro
        db.rollback()
        if "name" in changes:
            raise ComputeInstanceAlreadyExistsError(changes["name"]) from exc
        raise

    db.refresh(instance)
    return instance
