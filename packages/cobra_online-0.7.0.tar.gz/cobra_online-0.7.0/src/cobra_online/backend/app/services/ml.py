"""Servicios de dominio para modelos de IA y Machine Learning."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from datetime import datetime, timezone
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models import (
    MachineLearningFramework,
    MachineLearningModel,
    MachineLearningModelStatus,
)


class MachineLearningModelAlreadyExistsError(Exception):
    """Se lanza cuando ya existe un modelo con el mismo nombre."""


class MachineLearningModelNotFoundError(Exception):
    """Se lanza al consultar un modelo inexistente."""


def _normalize_last_trained_at(value: datetime | None) -> datetime | None:
    """Asegura que la marca temporal conserve información de zona horaria."""

    if value is None:
        return None

    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            value = datetime.fromisoformat(candidate)
        except ValueError as exc:  # pragma: no cover - validación negativa
            raise ValueError(
                "El campo 'last_trained_at' debe utilizar el formato ISO 8601."
            ) from exc

    if value.tzinfo is None or value.tzinfo.utcoffset(value) is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def list_models(
    db: Session,
    *,
    framework: MachineLearningFramework | None = None,
    status: MachineLearningModelStatus | None = None,
    name: str | None = None,
) -> list[MachineLearningModel]:
    """Recupera modelos de IA/ML aplicando filtros opcionales."""

    statement = select(MachineLearningModel).order_by(MachineLearningModel.created_at.asc())
    if framework is not None:
        statement = statement.where(MachineLearningModel.framework == framework)
    if status is not None:
        statement = statement.where(MachineLearningModel.status == status)
    if name is not None:
        statement = statement.where(MachineLearningModel.name == name)
    results = list(db.scalars(statement))
    for model in results:
        model.last_trained_at = _normalize_last_trained_at(model.last_trained_at)
    return results


def get_model(db: Session, model_id: int) -> MachineLearningModel:
    """Obtiene un modelo por identificador."""

    model = db.get(MachineLearningModel, model_id)
    if model is None:
        raise MachineLearningModelNotFoundError(model_id)
    model.last_trained_at = _normalize_last_trained_at(model.last_trained_at)
    return model


def create_model(
    db: Session,
    *,
    name: str,
    framework: MachineLearningFramework,
    version: str,
    description: str | None = None,
    endpoint_url: str | None = None,
    status: MachineLearningModelStatus | None = None,
    last_trained_at: datetime | None = None,
) -> MachineLearningModel:
    """Registra un modelo de IA/ML en la base de datos."""

    normalized_last_trained_at = _normalize_last_trained_at(last_trained_at)

    model = MachineLearningModel(
        name=name,
        framework=framework,
        version=version,
        description=description,
        endpoint_url=endpoint_url,
        last_trained_at=normalized_last_trained_at,
    )
    if status is not None:
        model.status = status

    db.add(model)
    try:
        db.commit()
    except IntegrityError as exc:  # pragma: no cover - se relanza con detalle
        db.rollback()
        raise MachineLearningModelAlreadyExistsError(name) from exc

    db.refresh(model)
    model.last_trained_at = _normalize_last_trained_at(model.last_trained_at)
    return model


def update_model(db: Session, model_id: int, **changes: Any) -> MachineLearningModel:
    """Actualiza los metadatos de un modelo existente."""

    model = get_model(db, model_id)
    if not changes:
        return model

    allowed_fields = {
        "name",
        "framework",
        "version",
        "description",
        "endpoint_url",
        "status",
        "last_trained_at",
    }
    invalid_fields = set(changes) - allowed_fields
    if invalid_fields:
        raise ValueError(
            "Se intentaron actualizar campos no soportados: " + ", ".join(sorted(invalid_fields))
        )

    for field, value in changes.items():
        if field == "last_trained_at":
            value = _normalize_last_trained_at(value)
        setattr(model, field, value)

    try:
        db.commit()
    except IntegrityError as exc:  # pragma: no cover - se relanza con detalle
        db.rollback()
        if "name" in changes:
            raise MachineLearningModelAlreadyExistsError(changes["name"]) from exc
        raise

    db.refresh(model)
    model.last_trained_at = _normalize_last_trained_at(model.last_trained_at)
    return model


def delete_model(db: Session, model_id: int) -> None:
    """Elimina un modelo del catálogo."""

    model = get_model(db, model_id)
    db.delete(model)
    db.commit()


def summarize_models(db: Session) -> dict[str, dict[str, int] | int]:
    """Calcula métricas agregadas del catálogo de modelos."""

    summary: dict[str, dict[str, int] | int] = {
        "total": 0,
        "by_status": {},
        "by_framework": {},
    }

    summary["total"] = (
        db.scalar(select(func.count()).select_from(MachineLearningModel)) or 0
    )

    status_rows = db.execute(
        select(MachineLearningModel.status, func.count())
        .group_by(MachineLearningModel.status)
        .order_by(MachineLearningModel.status)
    ).all()
    summary["by_status"] = {
        status.value if hasattr(status, "value") else str(status): count
        for status, count in status_rows
    }

    framework_rows = db.execute(
        select(MachineLearningModel.framework, func.count())
        .group_by(MachineLearningModel.framework)
        .order_by(MachineLearningModel.framework)
    ).all()
    summary["by_framework"] = {
        framework.value if hasattr(framework, "value") else str(framework): count
        for framework, count in framework_rows
    }

    return summary
