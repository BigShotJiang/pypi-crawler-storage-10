"""Servicios auxiliares para métricas de salud del sistema."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models import (
    AnalyticsPipeline,
    ApiKey,
    ComputeInstance,
    DatabaseInstance,
    MachineLearningModel,
    NetworkLoadBalancer,
    StorageBucket,
)


def _count_rows(db: Session, model: type[Any]) -> int:
    """Devuelve el número de registros para el modelo proporcionado."""

    return int(db.scalar(select(func.count()).select_from(model)) or 0)


def collect_metrics(db: Session, *, expiring_within_days: int = 7) -> dict[str, object]:
    """Genera un resumen con conteos agregados de los recursos y API keys."""

    now = datetime.now(tz=timezone.utc)
    window_end = now + timedelta(days=expiring_within_days)

    resources = {
        "storage_buckets": _count_rows(db, StorageBucket),
        "compute_instances": _count_rows(db, ComputeInstance),
        "database_instances": _count_rows(db, DatabaseInstance),
        "network_load_balancers": _count_rows(db, NetworkLoadBalancer),
        "analytics_pipelines": _count_rows(db, AnalyticsPipeline),
        "ml_models": _count_rows(db, MachineLearningModel),
    }

    total_api_keys = _count_rows(db, ApiKey)

    active_api_keys = int(
        db.scalar(
            select(func.count())
            .select_from(ApiKey)
            .where(
                ApiKey.revoked.is_(False),
                (ApiKey.expires_at.is_(None))
                | (ApiKey.expires_at > now),  # type: ignore[operator]
            )
        )
        or 0
    )

    revoked_api_keys = int(
        db.scalar(
            select(func.count())
            .select_from(ApiKey)
            .where(ApiKey.revoked.is_(True))
        )
        or 0
    )

    expiring_soon_api_keys = int(
        db.scalar(
            select(func.count())
            .select_from(ApiKey)
            .where(
                ApiKey.revoked.is_(False),
                ApiKey.expires_at.is_not(None),
                ApiKey.expires_at > now,
                ApiKey.expires_at <= window_end,
            )
        )
        or 0
    )

    return {
        "timestamp": now,
        "resources": resources,
        "api_keys": {
            "total": total_api_keys,
            "active": active_api_keys,
            "revoked": revoked_api_keys,
            "expiring_soon": expiring_soon_api_keys,
        },
    }

