"""Servicios de dominio para el módulo de bases de datos administradas."""
from __future__ import annotations


if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    current_path = Path(__file__).resolve()
    for candidate in current_path.parents:
        if (candidate / "backend").is_dir() and (candidate / "app").is_dir():
            repo_root = candidate
            break
    else:  # pragma: no cover - respaldo en caso de estructura inesperada
        repo_root = current_path.parent

    repo_path = str(repo_root)
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

from typing import Any

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models import DatabaseEngine, DatabaseInstance, DatabaseInstanceStatus


class DatabaseInstanceAlreadyExistsError(Exception):
    """Se lanza cuando se intenta crear una instancia con nombre duplicado."""


class DatabaseInstanceNotFoundError(Exception):
    """Se lanza cuando la instancia de base de datos no existe."""


def list_instances(
    db: Session,
    *,
    engine: DatabaseEngine | None = None,
    status: DatabaseInstanceStatus | None = None,
    region: str | None = None,
    name: str | None = None,
) -> list[DatabaseInstance]:
    """Devuelve las instancias de base de datos aplicando filtros opcionales."""

    statement = select(DatabaseInstance).order_by(DatabaseInstance.created_at.asc())
    if engine is not None:
        statement = statement.where(DatabaseInstance.engine == engine)
    if status is not None:
        statement = statement.where(DatabaseInstance.status == status)
    if region is not None:
        statement = statement.where(DatabaseInstance.region == region)
    if name is not None:
        statement = statement.where(DatabaseInstance.name == name)
    return list(db.scalars(statement))


def get_instance(db: Session, instance_id: int) -> DatabaseInstance:
    """Obtiene una instancia administrada específica."""

    instance = db.get(DatabaseInstance, instance_id)
    if instance is None:
        raise DatabaseInstanceNotFoundError(instance_id)
    return instance


def create_instance(
    db: Session,
    *,
    name: str,
    engine: DatabaseEngine,
    version: str,
    region: str,
    storage_gb: int,
    status: DatabaseInstanceStatus | None = None,
) -> DatabaseInstance:
    """Crea una instancia administrada de base de datos."""

    instance = DatabaseInstance(
        name=name,
        engine=engine,
        version=version,
        region=region,
        storage_gb=storage_gb,
    )
    if status is not None:
        instance.status = status

    db.add(instance)
    try:
        db.commit()
    except IntegrityError as exc:  # pragma: no cover - se relanza con contexto claro
        db.rollback()
        raise DatabaseInstanceAlreadyExistsError(name) from exc
    db.refresh(instance)
    return instance


def delete_instance(db: Session, instance_id: int) -> None:
    """Elimina una instancia administrada existente."""

    instance = get_instance(db, instance_id)
    db.delete(instance)
    db.commit()


def update_instance(db: Session, instance_id: int, **changes: Any) -> DatabaseInstance:
    """Actualiza los campos proporcionados de una instancia de base de datos."""

    instance = get_instance(db, instance_id)
    if not changes:
        return instance

    allowed_fields = {"name", "engine", "version", "region", "storage_gb", "status"}
    invalid_fields = set(changes) - allowed_fields
    if invalid_fields:
        raise ValueError(
            "Se intentaron actualizar campos no soportados: " + ", ".join(sorted(invalid_fields))
        )

    for field, value in changes.items():
        if field in allowed_fields:
            setattr(instance, field, value)

    try:
        db.commit()
    except IntegrityError as exc:  # pragma: no cover - se relanza con contexto claro
        db.rollback()
        if "name" in changes:
            raise DatabaseInstanceAlreadyExistsError(changes["name"]) from exc
        raise

    db.refresh(instance)
    return instance
