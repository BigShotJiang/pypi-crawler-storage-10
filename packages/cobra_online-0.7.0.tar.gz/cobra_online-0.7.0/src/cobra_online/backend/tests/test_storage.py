"""Pruebas para el módulo de buckets de almacenamiento."""
from __future__ import annotations

if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    _repo_root = str(Path(__file__).resolve().parents[2])
    if _repo_root not in sys.path:
        sys.path.insert(0, _repo_root)

    del _repo_root

from fastapi.testclient import TestClient

from app.main import app


def test_can_create_bucket() -> None:
    """Crear un bucket debe devolver el recurso creado."""

    client = TestClient(app)
    payload = {"name": "datos-criticos", "region": "us-east-1", "description": "Backups"}

    response = client.post("/api/v1/storage/buckets/", json=payload)

    assert response.status_code == 201
    body = response.json()
    assert body["name"] == payload["name"]
    assert body["region"] == payload["region"]
    assert body["description"] == payload["description"]
    assert "id" in body
    assert "created_at" in body


def test_cannot_create_bucket_with_duplicate_name() -> None:
    """Se debe obtener un estado 409 al repetir el nombre de un bucket."""

    client = TestClient(app)
    payload = {"name": "reportes", "region": "eu-west-1"}

    first = client.post("/api/v1/storage/buckets/", json=payload)
    assert first.status_code == 201

    second = client.post("/api/v1/storage/buckets/", json=payload)
    assert second.status_code == 409
    assert "Ya existe" in second.json()["detail"]


def test_list_buckets_returns_all_entries() -> None:
    """La lista de buckets debe reflejar lo almacenado en la base de datos."""

    client = TestClient(app)

    client.post(
        "/api/v1/storage/buckets/",
        json={"name": "ingesta", "region": "us-central-1"},
    )
    client.post(
        "/api/v1/storage/buckets/",
        json={"name": "laboratorio", "region": "us-central-1"},
    )

    response = client.get("/api/v1/storage/buckets/")

    assert response.status_code == 200
    body = response.json()
    names = [bucket["name"] for bucket in body]
    assert "ingesta" in names
    assert "laboratorio" in names


def test_can_retrieve_single_bucket() -> None:
    """Se debe poder obtener la información puntual de un bucket."""

    client = TestClient(app)
    create_response = client.post(
        "/api/v1/storage/buckets/",
        json={"name": "datasets", "region": "us-east-2"},
    )
    bucket_id = create_response.json()["id"]

    detail = client.get(f"/api/v1/storage/buckets/{bucket_id}")

    assert detail.status_code == 200
    assert detail.json()["id"] == bucket_id
    assert detail.json()["name"] == "datasets"


def test_get_bucket_returns_404_when_missing() -> None:
    """Consultar un bucket inexistente debe devolver 404."""

    client = TestClient(app)

    response = client.get("/api/v1/storage/buckets/999")

    assert response.status_code == 404


def test_can_update_bucket() -> None:
    """Actualizar un bucket debe reflejar los cambios solicitados."""

    client = TestClient(app)
    create_response = client.post(
        "/api/v1/storage/buckets/",
        json={"name": "archivos", "region": "us-west-1", "description": "Inicial"},
    )
    bucket_id = create_response.json()["id"]

    update_response = client.patch(
        f"/api/v1/storage/buckets/{bucket_id}",
        json={"region": "us-east-2", "description": "Actualizado"},
    )

    assert update_response.status_code == 200
    body = update_response.json()
    assert body["id"] == bucket_id
    assert body["region"] == "us-east-2"
    assert body["description"] == "Actualizado"
    assert body["name"] == "archivos"


def test_update_bucket_returns_404_when_missing() -> None:
    """Actualizar un bucket inexistente debe devolver 404."""

    client = TestClient(app)

    response = client.patch(
        "/api/v1/storage/buckets/999",
        json={"description": "Nada"},
    )

    assert response.status_code == 404


def test_update_bucket_conflict_on_duplicate_name() -> None:
    """Renombrar un bucket usando un nombre existente debe devolver 409."""

    client = TestClient(app)
    first = client.post(
        "/api/v1/storage/buckets/",
        json={"name": "catalogo", "region": "us-east-1"},
    )
    second = client.post(
        "/api/v1/storage/buckets/",
        json={"name": "respaldo", "region": "us-east-1"},
    )

    conflict = client.patch(
        f"/api/v1/storage/buckets/{second.json()['id']}",
        json={"name": first.json()["name"]},
    )

    assert conflict.status_code == 409
    assert "Ya existe" in conflict.json()["detail"]


def test_can_delete_bucket() -> None:
    """Eliminar un bucket debe devolver 204 y no permitir consultarlo luego."""

    client = TestClient(app)
    create_response = client.post(
        "/api/v1/storage/buckets/",
        json={"name": "logs-archivados", "region": "us-west-1"},
    )
    bucket_id = create_response.json()["id"]

    delete_response = client.delete(f"/api/v1/storage/buckets/{bucket_id}")

    assert delete_response.status_code == 204
    assert client.get(f"/api/v1/storage/buckets/{bucket_id}").status_code == 404


def test_delete_bucket_returns_404_when_missing() -> None:
    """Eliminar un bucket inexistente debe devolver 404."""

    client = TestClient(app)

    response = client.delete("/api/v1/storage/buckets/999")

    assert response.status_code == 404


def test_bucket_name_validation_requires_lowercase() -> None:
    """Los nombres con mayúsculas deben ser rechazados por la validación."""

    client = TestClient(app)

    response = client.post(
        "/api/v1/storage/buckets/",
        json={"name": "DatosInvalidos", "region": "us-east-1"},
    )

    assert response.status_code == 422


def test_list_buckets_can_filter_by_region() -> None:
    """El listado debe aceptar filtros por región para reducir resultados."""

    client = TestClient(app)
    client.post(
        "/api/v1/storage/buckets/",
        json={"name": "etl-data", "region": "us-east-1"},
    )
    client.post(
        "/api/v1/storage/buckets/",
        json={"name": "backups", "region": "eu-west-1"},
    )

    response = client.get("/api/v1/storage/buckets/?region=us-east-1")

    assert response.status_code == 200
    body = response.json()
    assert len(body) == 1
    assert body[0]["name"] == "etl-data"
    assert body[0]["region"] == "us-east-1"
