"""Pruebas para los endpoints de balanceadores de carga."""

if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    _repo_root = str(Path(__file__).resolve().parents[2])
    if _repo_root not in sys.path:
        sys.path.insert(0, _repo_root)

    del _repo_root

from fastapi.testclient import TestClient

from app.main import app


def test_can_create_load_balancer() -> None:
    """Crear un balanceador debe devolver el recurso persistido."""

    client = TestClient(app)
    payload = {
        "name": "edge-balancer",
        "protocol": "http",
        "port": 80,
        "region": "us-east-1",
    }

    response = client.post("/api/v1/network/load-balancers/", json=payload)

    assert response.status_code == 201
    body = response.json()
    assert body["name"] == payload["name"]
    assert body["protocol"] == payload["protocol"]
    assert body["port"] == payload["port"]
    assert body["region"] == payload["region"]
    assert body["status"] == "provisioning"
    assert "id" in body
    assert "created_at" in body


def test_cannot_create_load_balancer_with_duplicate_name() -> None:
    """Duplicar el nombre debe devolver un estado 409."""

    client = TestClient(app)
    payload = {
        "name": "api-balancer",
        "protocol": "https",
        "port": 443,
        "region": "eu-west-1",
    }

    first = client.post("/api/v1/network/load-balancers/", json=payload)
    assert first.status_code == 201

    second = client.post("/api/v1/network/load-balancers/", json=payload)
    assert second.status_code == 409
    assert "Ya existe" in second.json()["detail"]


def test_list_load_balancers_returns_all_entries() -> None:
    """La lista debe contener los balanceadores creados previamente."""

    client = TestClient(app)
    client.post(
        "/api/v1/network/load-balancers/",
        json={
            "name": "ingress-a",
            "protocol": "http",
            "port": 80,
            "region": "us-central-1",
        },
    )
    client.post(
        "/api/v1/network/load-balancers/",
        json={
            "name": "ingress-b",
            "protocol": "tcp",
            "port": 9000,
            "region": "us-central-1",
        },
    )

    response = client.get("/api/v1/network/load-balancers/")

    assert response.status_code == 200
    body = response.json()
    names = [load_balancer["name"] for load_balancer in body]
    assert "ingress-a" in names
    assert "ingress-b" in names


def test_can_retrieve_single_load_balancer() -> None:
    """Se debe poder consultar un balanceador específico por su id."""

    client = TestClient(app)
    create_response = client.post(
        "/api/v1/network/load-balancers/",
        json={
            "name": "edge-x",
            "protocol": "https",
            "port": 443,
            "region": "us-east-2",
        },
    )
    load_balancer_id = create_response.json()["id"]

    detail = client.get(f"/api/v1/network/load-balancers/{load_balancer_id}")

    assert detail.status_code == 200
    assert detail.json()["id"] == load_balancer_id
    assert detail.json()["name"] == "edge-x"


def test_get_load_balancer_returns_404_when_missing() -> None:
    """Consultar un balanceador inexistente debe devolver 404."""

    client = TestClient(app)

    response = client.get("/api/v1/network/load-balancers/999")

    assert response.status_code == 404


def test_can_update_load_balancer() -> None:
    """Actualizar un balanceador debe modificar los campos seleccionados."""

    client = TestClient(app)
    create_response = client.post(
        "/api/v1/network/load-balancers/",
        json={
            "name": "web-front",
            "protocol": "http",
            "port": 80,
            "region": "us-west-1",
        },
    )
    load_balancer_id = create_response.json()["id"]

    update_response = client.patch(
        f"/api/v1/network/load-balancers/{load_balancer_id}",
        json={"port": 8080, "status": "active"},
    )

    assert update_response.status_code == 200
    body = update_response.json()
    assert body["id"] == load_balancer_id
    assert body["port"] == 8080
    assert body["status"] == "active"
    assert body["name"] == "web-front"


def test_update_load_balancer_returns_404_when_missing() -> None:
    """Actualizar un balanceador inexistente debe devolver 404."""

    client = TestClient(app)

    response = client.patch(
        "/api/v1/network/load-balancers/999",
        json={"status": "failed"},
    )

    assert response.status_code == 404


def test_update_load_balancer_conflict_on_duplicate_name() -> None:
    """Renombrar un balanceador con un nombre ocupado debe devolver 409."""

    client = TestClient(app)
    first = client.post(
        "/api/v1/network/load-balancers/",
        json={
            "name": "core-routing",
            "protocol": "tcp",
            "port": 7000,
            "region": "us-east-1",
        },
    )
    second = client.post(
        "/api/v1/network/load-balancers/",
        json={
            "name": "edge-routing",
            "protocol": "tcp",
            "port": 7000,
            "region": "us-east-1",
        },
    )

    conflict = client.patch(
        f"/api/v1/network/load-balancers/{second.json()['id']}",
        json={"name": first.json()["name"]},
    )

    assert conflict.status_code == 409
    assert "Ya existe" in conflict.json()["detail"]


def test_can_delete_load_balancer() -> None:
    """Eliminar un balanceador debe devolver 204 y evitar consultas posteriores."""

    client = TestClient(app)
    create_response = client.post(
        "/api/v1/network/load-balancers/",
        json={
            "name": "transient",
            "protocol": "http",
            "port": 8080,
            "region": "us-west-2",
        },
    )
    load_balancer_id = create_response.json()["id"]

    delete_response = client.delete(f"/api/v1/network/load-balancers/{load_balancer_id}")

    assert delete_response.status_code == 204
    assert (
        client.get(f"/api/v1/network/load-balancers/{load_balancer_id}").status_code
        == 404
    )


def test_delete_load_balancer_returns_404_when_missing() -> None:
    """Eliminar un balanceador inexistente debe devolver 404."""

    client = TestClient(app)

    response = client.delete("/api/v1/network/load-balancers/999")

    assert response.status_code == 404


def test_list_load_balancers_can_filter_by_protocol() -> None:
    """El listado debe aceptar filtros por protocolo de escucha."""

    client = TestClient(app)
    client.post(
        "/api/v1/network/load-balancers/",
        json={
            "name": "edge-http",
            "protocol": "http",
            "port": 80,
            "region": "us-east-1",
        },
    )
    client.post(
        "/api/v1/network/load-balancers/",
        json={
            "name": "edge-https",
            "protocol": "https",
            "port": 443,
            "region": "us-east-1",
        },
    )

    response = client.get("/api/v1/network/load-balancers/?protocol=https")

    assert response.status_code == 200
    body = response.json()
    assert len(body) == 1
    assert body[0]["name"] == "edge-https"
    assert body[0]["protocol"] == "https"


def test_load_balancer_name_validation_requires_lowercase() -> None:
    """Los nombres con mayúsculas deben ser rechazados por la API."""

    client = TestClient(app)

    response = client.post(
        "/api/v1/network/load-balancers/",
        json={
            "name": "EdgeBalancer",
            "protocol": "http",
            "port": 80,
            "region": "us-east-1",
        },
    )

    assert response.status_code == 422


def test_load_balancer_requires_valid_port_range() -> None:
    """Los puertos fuera del rango válido deben ser rechazados."""

    client = TestClient(app)

    response = client.post(
        "/api/v1/network/load-balancers/",
        json={
            "name": "invalid-port",
            "protocol": "tcp",
            "port": 70000,
            "region": "us-east-1",
        },
    )

    assert response.status_code == 422
