"""Configuración compartida para las pruebas del backend."""
from __future__ import annotations

import os

import pytest

@pytest.fixture(autouse=True)
def reset_database() -> None:
    """Reinicia las tablas antes de cada prueba para garantizar aislamiento."""

    # Para SQLite en disco es más seguro eliminar el archivo y recrear las tablas.
    # Esto evita que datos residuales de ejecuciones anteriores afecten los tests.
    from app.api.deps import engine
    from app.models import Base

    engine.dispose()

    if engine.url.database and engine.url.drivername.startswith("sqlite"):
        db_path = engine.url.database
        if os.path.exists(db_path):
            os.remove(db_path)
        Base.metadata.create_all(bind=engine)
        yield
        return

    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    yield
