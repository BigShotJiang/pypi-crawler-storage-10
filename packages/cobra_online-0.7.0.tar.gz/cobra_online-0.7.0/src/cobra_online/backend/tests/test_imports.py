"""Pruebas para garantizar la compatibilidad de importaciones absolutas."""
from __future__ import annotations

if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    _repo_root = str(Path(__file__).resolve().parents[2])
    if _repo_root not in sys.path:
        sys.path.insert(0, _repo_root)

    del _repo_root

import importlib
import sys
from pathlib import Path


def test_app_package_is_importable_from_repo_root(monkeypatch) -> None:
    """``python -m app.main`` debe funcionar desde la raíz del proyecto."""

    repo_root = Path(__file__).resolve().parents[2]
    backend_dir = repo_root / "backend"

    new_path = [str(repo_root)]
    for entry in list(sys.path):
        resolved = Path(entry).resolve()
        if resolved in {backend_dir.resolve(), (backend_dir / "app").resolve()}:
            continue
        new_path.append(entry)

    removed_modules = {
        name: sys.modules.pop(name)
        for name in list(sys.modules)
        if name == "app" or name.startswith("app.")
    }

    try:
        with monkeypatch.context() as patcher:
            patcher.setattr(sys, "path", new_path, raising=False)
            module = importlib.import_module("app.main")
            assert hasattr(module, "create_application")
    finally:
        sys.modules.update(removed_modules)
