"""Pruebas para validar la seguridad basada en API keys."""
from __future__ import annotations

if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    _repo_root = str(Path(__file__).resolve().parents[2])
    if _repo_root not in sys.path:
        sys.path.insert(0, _repo_root)

    del _repo_root

from fastapi.testclient import TestClient

from app.core.config import settings
from app.main import app


def test_protected_routes_require_api_key_when_configured() -> None:
    """Las rutas protegidas deben rechazar peticiones sin una API key válida."""

    client = TestClient(app)
    original_keys = list(settings.api_keys)
    settings.api_keys = ["test-secret"]
    try:
        response = client.get("/api/v1/storage/buckets/")
        assert response.status_code == 401
        assert response.json()["detail"] == "Falta la API key requerida."

        response = client.get(
            "/api/v1/storage/buckets/", headers={"X-API-Key": "invalid"}
        )
        assert response.status_code == 403
        assert response.json()["detail"] == "La API key proporcionada no es válida."

        response = client.get(
            "/api/v1/storage/buckets/", headers={"X-API-Key": "test-secret"}
        )
        assert response.status_code == 200
    finally:
        settings.api_keys = original_keys


def test_health_endpoint_remains_public() -> None:
    """El endpoint de salud debe ser accesible incluso con API keys configuradas."""

    client = TestClient(app)
    original_keys = list(settings.api_keys)
    settings.api_keys = ["test-secret"]
    try:
        response = client.get("/api/v1/health/")
        assert response.status_code == 200
    finally:
        settings.api_keys = original_keys


def test_can_manage_persistent_api_keys() -> None:
    """Se debe poder crear y revocar API keys administradas desde la API."""

    client = TestClient(app)
    original_keys = list(settings.api_keys)
    settings.api_keys = ["bootstrap"]
    try:
        create_response = client.post(
            "/api/v1/security/api-keys/",
            json={"name": "token-ci"},
            headers={"X-API-Key": "bootstrap"},
        )
        assert create_response.status_code == 201
        created_body = create_response.json()
        assert created_body["secret"].startswith(created_body["key_prefix"])

        list_response = client.get(
            "/api/v1/security/api-keys/",
            headers={"X-API-Key": "bootstrap"},
        )
        assert list_response.status_code == 200
        assert any(item["id"] == created_body["id"] for item in list_response.json())

        new_key = created_body["secret"]
        allowed_response = client.get(
            "/api/v1/storage/buckets/",
            headers={"X-API-Key": new_key},
        )
        assert allowed_response.status_code == 200

        revoke_response = client.post(
            f"/api/v1/security/api-keys/{created_body['id']}/revoke",
            headers={"X-API-Key": "bootstrap"},
        )
        assert revoke_response.status_code == 200
        assert revoke_response.json()["revoked"] is True

        forbidden_response = client.get(
            "/api/v1/storage/buckets/",
            headers={"X-API-Key": new_key},
        )
        assert forbidden_response.status_code == 403
    finally:
        settings.api_keys = original_keys
