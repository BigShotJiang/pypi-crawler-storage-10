"""Pruebas para la ejecución de la API desde la línea de comandos."""
from __future__ import annotations

if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    _repo_root = str(Path(__file__).resolve().parents[2])
    if _repo_root not in sys.path:
        sys.path.insert(0, _repo_root)

    del _repo_root

import importlib
import sys

import pytest


def test_main_inicia_uvicorn_con_la_configuracion(monkeypatch) -> None:
    """La función ``main`` debe delegar en ``uvicorn.run`` con los parámetros esperados."""

    from app import main as app_main

    llamadas: dict[str, object] = {}

    def _fake_run(
        app: str,
        *,
        host: str,
        port: int,
        reload: bool,
        **_: object,
    ) -> None:
        llamadas.update({
            "app": app,
            "host": host,
            "port": port,
            "reload": reload,
        })

    monkeypatch.setattr(app_main.settings, "api_host", "127.0.0.1", raising=False)
    monkeypatch.setattr(app_main.settings, "api_port", 9100, raising=False)
    monkeypatch.setattr(app_main.uvicorn, "run", _fake_run, raising=True)

    app_main.main()

    assert llamadas["app"] == "app.main:app"
    assert llamadas["host"] == "127.0.0.1"
    assert llamadas["port"] == 9100
    assert llamadas["reload"] is False


def test_cli_avisa_si_faltan_dependencias() -> None:
    """``app.cli`` debe manejar la falta de dependencias opcionales con elegancia."""

    original_cli = sys.modules.pop("app.cli", None)
    original_cli_main = sys.modules.pop("app.cli.main", None)

    try:
        cli = importlib.import_module("app.cli")
        assert cli.is_available() is False

        error = cli.availability_error()
        assert isinstance(error, cli.CliUnavailableError)
        assert error.missing_dependency in {"flet", "fletplus"}

        with pytest.raises(cli.CliUnavailableError):
            cli.launch()
    finally:
        if original_cli is not None:
            sys.modules["app.cli"] = original_cli
        else:
            sys.modules.pop("app.cli", None)
        if original_cli_main is not None:
            sys.modules["app.cli.main"] = original_cli_main
        else:
            sys.modules.pop("app.cli.main", None)
