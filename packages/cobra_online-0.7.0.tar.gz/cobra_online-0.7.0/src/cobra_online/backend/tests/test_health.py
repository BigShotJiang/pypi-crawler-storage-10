"""Pruebas básicas para los endpoints de salud."""
from __future__ import annotations

if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    _repo_root = str(Path(__file__).resolve().parents[2])
    if _repo_root not in sys.path:
        sys.path.insert(0, _repo_root)

    del _repo_root

from datetime import datetime, timedelta, timezone
from uuid import uuid4

from fastapi.testclient import TestClient

from app.main import app


def test_health_endpoint_returns_ok_status() -> None:
    """El endpoint de salud debe devolver estado ok y datos mínimos."""

    client = TestClient(app)
    response = client.get("/api/v1/health/")
    payload = response.json()

    assert response.status_code == 200
    assert payload["status"] == "ok"
    assert payload["service"] == app.title
    assert payload["locale"] == "es"
    assert (
        payload["message"]
        == "Servicio operativo. Cobra_Online responde correctamente."
    )
    assert payload["documentation_url"].endswith("docs/README.md")
    # El timestamp debe poder convertirse a un objeto datetime válido.
    datetime.fromisoformat(payload["timestamp"])


def test_health_metrics_include_resource_and_api_key_counts() -> None:
    """El endpoint de métricas debe reflejar incrementos tras registrar recursos."""

    client = TestClient(app)

    initial_metrics = client.get("/api/v1/health/metrics").json()

    unique_suffix = uuid4().hex[:8]

    client.post(
        "/api/v1/storage/buckets/",
        json={
            "name": f"metrics-bucket-{unique_suffix}",
            "region": "us-east-1",
            "description": "Bucket para pruebas de métricas",
        },
    )

    client.post(
        "/api/v1/compute/instances/",
        json={
            "name": f"metrics-compute-{unique_suffix}",
            "image": "ubuntu-22-04-lts",
            "region": "us-east-1",
            "vcpus": 2,
            "memory_gb": 4,
        },
    )

    client.post(
        "/api/v1/databases/instances/",
        json={
            "name": f"metrics-db-{unique_suffix}",
            "engine": "postgresql",
            "version": "15",
            "region": "us-east-1",
            "storage_gb": 20,
        },
    )

    client.post(
        "/api/v1/network/load-balancers/",
        json={
            "name": f"metrics-lb-{unique_suffix}",
            "protocol": "http",
            "port": 80,
            "region": "us-east-1",
        },
    )

    client.post(
        "/api/v1/analytics/pipelines/",
        json={
            "name": f"metrics-pipeline-{unique_suffix}",
            "engine": "spark",
            "schedule": "0 0 * * *",
            "description": "Pipeline de métricas",
        },
    )

    client.post(
        "/api/v1/ml/models/",
        json={
            "name": f"metrics-model-{unique_suffix}",
            "framework": "pytorch",
            "version": "v1",
            "description": "Modelo para pruebas de métricas",
        },
    )

    expiration = datetime.now(tz=timezone.utc) + timedelta(days=3)
    first_key_response = client.post(
        "/api/v1/security/api-keys/",
        json={"name": f"metrics-key-{unique_suffix}", "expires_at": expiration.isoformat()},
    )
    first_key_payload = first_key_response.json()

    second_key_response = client.post(
        "/api/v1/security/api-keys/",
        json={"name": f"metrics-key-revoked-{unique_suffix}"},
        headers={"X-API-Key": first_key_payload["secret"]},
    )
    second_key_payload = second_key_response.json()

    client.post(
        f"/api/v1/security/api-keys/{second_key_payload['id']}/revoke",
        headers={"X-API-Key": first_key_payload["secret"]},
    )

    metrics_response = client.get("/api/v1/health/metrics")
    metrics_payload = metrics_response.json()

    assert metrics_response.status_code == 200
    datetime.fromisoformat(metrics_payload["timestamp"])
    assert metrics_payload["locale"] == "es"
    assert metrics_payload["summary"].startswith("Resumen agregado")
    assert metrics_payload["documentation_url"].endswith("docs/README.md")

    initial_resources = initial_metrics["resources"]
    resources = metrics_payload["resources"]
    assert resources["storage_buckets"] == initial_resources["storage_buckets"] + 1
    assert resources["compute_instances"] == initial_resources["compute_instances"] + 1
    assert resources["database_instances"] == initial_resources["database_instances"] + 1
    assert (
        resources["network_load_balancers"]
        == initial_resources["network_load_balancers"] + 1
    )
    assert resources["analytics_pipelines"] == initial_resources["analytics_pipelines"] + 1
    assert resources["ml_models"] == initial_resources["ml_models"] + 1

    initial_keys = initial_metrics["api_keys"]
    keys_payload = metrics_payload["api_keys"]
    assert keys_payload["total"] == initial_keys["total"] + 2
    assert keys_payload["active"] == initial_keys["active"] + 1
    assert keys_payload["revoked"] == initial_keys["revoked"] + 1
    assert keys_payload["expiring_soon"] >= initial_keys["expiring_soon"] + 1


def test_health_status_accepts_accept_language_header() -> None:
    """El endpoint de salud debe respetar la cabecera ``Accept-Language``."""

    client = TestClient(app)
    response = client.get(
        "/api/v1/health/", headers={"Accept-Language": "en-US,en;q=0.9"}
    )
    payload = response.json()

    assert response.status_code == 200
    assert payload["locale"] == "en"
    assert (
        payload["message"]
        == "Service operating normally. Cobra_Online is responding as expected."
    )
    assert payload["documentation_url"].endswith("docs/README.en.md")


def test_health_status_accepts_portuguese_locale() -> None:
    """El endpoint de salud debe soportar traducción al portugués vía parámetro."""

    client = TestClient(app)
    response = client.get("/api/v1/health/", params={"lang": "pt"})
    payload = response.json()

    assert response.status_code == 200
    assert payload["locale"] == "pt"
    assert (
        payload["message"]
        == "Serviço operacional. Cobra_Online está respondendo corretamente."
    )
    assert payload["documentation_url"].endswith("docs/README.pt.md")


def test_health_metrics_respect_portuguese_accept_language() -> None:
    """Las métricas deben localizarse en portugués cuando se solicita por cabecera."""

    client = TestClient(app)
    response = client.get(
        "/api/v1/health/metrics", headers={"Accept-Language": "pt-BR,pt;q=0.9"}
    )
    payload = response.json()

    assert response.status_code == 200
    assert payload["locale"] == "pt"
    assert (
        payload["summary"]
        == "Resumo agregado de recursos, chaves de API e da janela configurável de expiração."
    )
    assert payload["documentation_url"].endswith("docs/README.pt.md")
