"""Pruebas para la gestión de modelos de IA/ML."""
from __future__ import annotations

if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    _repo_root = str(Path(__file__).resolve().parents[2])
    if _repo_root not in sys.path:
        sys.path.insert(0, _repo_root)

    del _repo_root

from datetime import datetime, timezone

from fastapi.testclient import TestClient

from app.main import app


def test_can_register_ml_model() -> None:
    """Crear un modelo debe devolver el recurso recién creado."""

    client = TestClient(app)
    payload = {
        "name": "fraud-detector",
        "framework": "pytorch",
        "version": "v1",
        "description": "Modelo para detectar fraude en tiempo real",
        "endpoint_url": "https://ml.local/fraud-detector",
    }

    response = client.post("/api/v1/ml/models/", json=payload)

    assert response.status_code == 201
    body = response.json()
    assert body["name"] == payload["name"]
    assert body["framework"] == payload["framework"]
    assert body["version"] == payload["version"]
    assert body["description"] == payload["description"]
    assert body["endpoint_url"] == payload["endpoint_url"]
    assert body["status"] == "draft"
    assert body["last_trained_at"] is None
    assert "id" in body


def test_cannot_register_duplicate_ml_model() -> None:
    """Duplicar el nombre de un modelo debe devolver 409."""

    client = TestClient(app)
    payload = {
        "name": "recommendation-engine",
        "framework": "tensorflow",
        "version": "2025.01",
    }

    first = client.post("/api/v1/ml/models/", json=payload)
    assert first.status_code == 201

    second = client.post("/api/v1/ml/models/", json=payload)
    assert second.status_code == 409
    assert "Ya existe" in second.json()["detail"]


def test_list_ml_models_allows_filters() -> None:
    """El listado debe aceptar filtros por framework y estado."""

    client = TestClient(app)
    ready_model = client.post(
        "/api/v1/ml/models/",
        json={
            "name": "vision-classifier",
            "framework": "tensorflow",
            "version": "1.0",
        },
    )
    ready_id = ready_model.json()["id"]
    client.patch(
        f"/api/v1/ml/models/{ready_id}",
        json={"status": "ready"},
    )
    client.post(
        "/api/v1/ml/models/",
        json={
            "name": "forecasting-service",
            "framework": "scikit-learn",
            "version": "0.3",
            "status": "training",
        },
    )

    framework_response = client.get("/api/v1/ml/models/?framework=tensorflow")
    assert framework_response.status_code == 200
    assert len(framework_response.json()) == 1
    assert framework_response.json()[0]["name"] == "vision-classifier"

    status_response = client.get("/api/v1/ml/models/?status=ready")
    assert status_response.status_code == 200
    assert len(status_response.json()) == 1
    assert status_response.json()[0]["status"] == "ready"


def test_ml_models_summary_returns_distributions() -> None:
    """El resumen debe reflejar totales y distribuciones por estado y framework."""

    client = TestClient(app)
    client.post(
        "/api/v1/ml/models/",
        json={
            "name": "vision-classifier",
            "framework": "tensorflow",
            "version": "1.0",
            "status": "ready",
        },
    )
    client.post(
        "/api/v1/ml/models/",
        json={
            "name": "text-analyzer",
            "framework": "pytorch",
            "version": "2.0",
        },
    )
    client.post(
        "/api/v1/ml/models/",
        json={
            "name": "forecasting-service",
            "framework": "scikit-learn",
            "version": "0.3",
            "status": "training",
        },
    )

    response = client.get("/api/v1/ml/models/summary")

    assert response.status_code == 200
    body = response.json()
    assert body["total"] == 3
    assert body["by_status"]["ready"] == 1
    assert body["by_status"]["draft"] == 1
    assert body["by_status"]["training"] == 1
    assert body["by_framework"]["tensorflow"] == 1
    assert body["by_framework"]["pytorch"] == 1
    assert body["by_framework"]["scikit-learn"] == 1


def test_can_retrieve_single_ml_model() -> None:
    """Se debe poder consultar un modelo por su identificador."""

    client = TestClient(app)
    created = client.post(
        "/api/v1/ml/models/",
        json={
            "name": "nlp-analyzer",
            "framework": "pytorch",
            "version": "1.2",
        },
    )
    model_id = created.json()["id"]

    detail = client.get(f"/api/v1/ml/models/{model_id}")
    assert detail.status_code == 200
    assert detail.json()["id"] == model_id
    assert detail.json()["name"] == "nlp-analyzer"


def test_get_ml_model_returns_404_when_missing() -> None:
    """Consultar un modelo inexistente debe devolver 404."""

    client = TestClient(app)
    response = client.get("/api/v1/ml/models/999")
    assert response.status_code == 404


def test_can_update_ml_model() -> None:
    """Actualizar un modelo debe reflejar los cambios proporcionados."""

    client = TestClient(app)
    created = client.post(
        "/api/v1/ml/models/",
        json={
            "name": "timeseries-engine",
            "framework": "xgboost",
            "version": "0.1",
        },
    )
    model_id = created.json()["id"]
    trained_at = datetime(2025, 1, 15, 9, 30, tzinfo=timezone.utc).isoformat()

    response = client.patch(
        f"/api/v1/ml/models/{model_id}",
        json={
            "status": "ready",
            "endpoint_url": "https://ml.local/timeseries",
            "last_trained_at": trained_at,
        },
    )

    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ready"
    assert body["endpoint_url"] == "https://ml.local/timeseries"
    returned = body["last_trained_at"]
    normalized_returned = returned.replace("Z", "+00:00") if returned else returned
    assert normalized_returned == trained_at


def test_update_ml_model_accepts_zulu_timestamp() -> None:
    """Las fechas con sufijo ``Z`` deben normalizarse correctamente."""

    client = TestClient(app)
    created = client.post(
        "/api/v1/ml/models/",
        json={
            "name": "speech-engine",
            "framework": "tensorflow",
            "version": "1.0",
        },
    )
    model_id = created.json()["id"]

    response = client.patch(
        f"/api/v1/ml/models/{model_id}",
        json={"last_trained_at": "2025-03-01T12:00:00Z"},
    )

    assert response.status_code == 200
    body = response.json()
    assert body["last_trained_at"].endswith("+00:00")


def test_update_ml_model_rejects_invalid_timestamp() -> None:
    """Tiempos con formato inválido deben devolver un error legible."""

    client = TestClient(app)
    created = client.post(
        "/api/v1/ml/models/",
        json={
            "name": "text-generator",
            "framework": "pytorch",
            "version": "3.0",
        },
    )
    model_id = created.json()["id"]

    response = client.patch(
        f"/api/v1/ml/models/{model_id}",
        json={"last_trained_at": "ayer a las cinco"},
    )

    assert response.status_code == 422
    detail = response.json()["detail"]
    assert isinstance(detail, list)
    assert any("datetime" in item.get("msg", "").lower() for item in detail)


def test_can_delete_ml_model() -> None:
    """Eliminar un modelo debe impedir consultas posteriores."""

    client = TestClient(app)
    created = client.post(
        "/api/v1/ml/models/",
        json={
            "name": "anomaly-detector",
            "framework": "scikit-learn",
            "version": "1.0",
        },
    )
    model_id = created.json()["id"]

    delete_response = client.delete(f"/api/v1/ml/models/{model_id}")
    assert delete_response.status_code == 204

    detail = client.get(f"/api/v1/ml/models/{model_id}")
    assert detail.status_code == 404
