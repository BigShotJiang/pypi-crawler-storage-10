"""Pruebas específicas de la integración SQLitePlus."""
from __future__ import annotations

if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    _repo_root = str(Path(__file__).resolve().parents[2])
    if _repo_root not in sys.path:
        sys.path.insert(0, _repo_root)

    del _repo_root

import pytest
from sqlalchemy import text

from app.api.deps import engine
from app.core.config import settings
from app.db.sqliteplus import gather_sqlite_diagnostics, get_sqliteplus_database


@pytest.mark.skipif(
    not engine.url.drivername.startswith("sqlite"),
    reason="Las optimizaciones sólo aplican a motores SQLite",
)
def test_sqlite_engine_applies_sqliteplus_pragmas() -> None:
    """Las conexiones SQLite deben exponer los PRAGMAs configurados."""

    with engine.connect() as connection:
        journal_mode = connection.execute(text("PRAGMA journal_mode; ")).scalar_one()
        foreign_keys = connection.execute(text("PRAGMA foreign_keys; ")).scalar_one()
        busy_timeout = connection.execute(text("PRAGMA busy_timeout; ")).scalar_one()

    assert journal_mode.lower() == settings.sqlite_journal_mode.lower()
    expected_fk = 1 if settings.sqlite_foreign_keys else 0
    assert foreign_keys == expected_fk
    expected_timeout = settings.sqlite_busy_timeout_ms or 0
    assert busy_timeout == expected_timeout


@pytest.mark.skipif(
    not engine.url.drivername.startswith("sqlite"),
    reason="Los diagnósticos ampliados sólo aplican a motores SQLite",
)
def test_sqlite_diagnostics_returns_extended_metadata() -> None:
    """Se debe exponer información extendida usando SQLitePlus Enhanced."""

    diagnostics = gather_sqlite_diagnostics(engine)

    assert diagnostics["journal_mode"].lower() == settings.sqlite_journal_mode.lower()
    assert "page_count" in diagnostics
    assert "tables" in diagnostics
    assert isinstance(diagnostics["tables"], list)
    assert "file_size_bytes" in diagnostics


@pytest.mark.skipif(
    not engine.url.drivername.startswith("sqlite"),
    reason="Los asistentes sólo aplican a motores SQLite",
)
def test_sqliteplus_database_helpers(tmp_path) -> None:
    """La clase de ayuda debe ofrecer operaciones de mantenimiento básicas."""

    sqlite_db = get_sqliteplus_database(engine, cipher_key=settings.sqlite_encryption_key)
    assert sqlite_db is not None

    sqlite_db.executescript(
        """
        CREATE TABLE IF NOT EXISTS demo_ops (id INTEGER PRIMARY KEY, name TEXT);
        DELETE FROM demo_ops;
        """
    )
    row_id = sqlite_db.execute("INSERT INTO demo_ops (name) VALUES (?)", ["cobra"])
    assert row_id

    single_row = sqlite_db.fetchone("SELECT id, name FROM demo_ops WHERE id=?", [row_id])
    assert single_row is not None
    assert single_row[1] == "cobra"

    sqlite_db.execute_many(
        "INSERT INTO demo_ops (name) VALUES (?)",
        [("alpha",), ("beta",)],
    )

    subset = sqlite_db.fetchmany(
        "SELECT id, name FROM demo_ops ORDER BY id", size=2
    )
    assert len(subset) == 2

    streamed = list(
        sqlite_db.stream_query("SELECT name FROM demo_ops ORDER BY id", chunk_size=1)
    )
    assert any(name == "cobra" for (name,) in streamed)

    with sqlite_db.transaction() as connection:
        connection.execute("INSERT INTO demo_ops (name) VALUES (?)", ("transactional",))

    tables = sqlite_db.list_tables()
    assert "demo_ops" in tables

    pragma_result = sqlite_db.pragma("PRAGMA table_info('demo_ops');")
    assert any(column[1] == "name" for column in pragma_result)

    export_path = tmp_path / "demo_ops.csv"
    sqlite_db.export_table("demo_ops", export_path)
    assert export_path.exists()

    backup_dir = tmp_path / "backups"
    backup_path = sqlite_db.backup(backup_dir)
    assert backup_path.exists()

    replica_path = tmp_path / "replica.db"
    replica = sqlite_db.replicate_to(replica_path)
    assert replica.exists()

    sqlite_db.attach_database("aux_db", replica)
    try:
        db_list = sqlite_db.pragma("PRAGMA database_list;")
        assert any(row[1] == "aux_db" for row in db_list)
    finally:
        sqlite_db.detach_database("aux_db")
        sqlite_db.executescript("DROP TABLE IF EXISTS demo_ops;")

    log_id = sqlite_db.log_action("Tabla demo_ops modificada")
    assert isinstance(log_id, int)
    logs = sqlite_db.fetch_logs(limit=10)
    assert logs
    sqlite_db.clear_logs()
    assert sqlite_db.fetch_logs(limit=1) == []

