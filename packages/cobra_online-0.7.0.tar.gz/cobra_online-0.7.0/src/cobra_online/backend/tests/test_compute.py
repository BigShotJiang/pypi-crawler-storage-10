"""Pruebas para el módulo de cómputo."""
from __future__ import annotations

if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    _repo_root = str(Path(__file__).resolve().parents[2])
    if _repo_root not in sys.path:
        sys.path.insert(0, _repo_root)

    del _repo_root

from fastapi.testclient import TestClient

from app.main import app


def test_can_create_compute_instance() -> None:
    """Crear una instancia debe devolver el recurso con todos los campos."""

    client = TestClient(app)
    payload = {
        "name": "worker-01",
        "image": "ubuntu-22-04-lts",
        "region": "us-east-1",
        "vcpus": 4,
        "memory_gb": 16,
    }

    response = client.post("/api/v1/compute/instances/", json=payload)

    assert response.status_code == 201
    body = response.json()
    assert body["name"] == payload["name"]
    assert body["image"] == payload["image"]
    assert body["region"] == payload["region"]
    assert body["vcpus"] == payload["vcpus"]
    assert body["memory_gb"] == payload["memory_gb"]
    assert body["status"] == "provisioning"
    assert "id" in body
    assert "created_at" in body


def test_cannot_create_instance_with_duplicate_name() -> None:
    """Duplicar nombre debe devolver un estado 409."""

    client = TestClient(app)
    payload = {
        "name": "analytics-node",
        "image": "debian-12",
        "region": "eu-west-1",
        "vcpus": 2,
        "memory_gb": 8,
    }

    first = client.post("/api/v1/compute/instances/", json=payload)
    assert first.status_code == 201

    second = client.post("/api/v1/compute/instances/", json=payload)
    assert second.status_code == 409
    assert "Ya existe" in second.json()["detail"]


def test_list_instances_returns_all_entries() -> None:
    """La lista debe contener las instancias creadas previamente."""

    client = TestClient(app)
    client.post(
        "/api/v1/compute/instances/",
        json={
            "name": "etl-01",
            "image": "ubuntu-22-04-lts",
            "region": "us-central-1",
            "vcpus": 8,
            "memory_gb": 32,
        },
    )
    client.post(
        "/api/v1/compute/instances/",
        json={
            "name": "etl-02",
            "image": "ubuntu-22-04-lts",
            "region": "us-central-1",
            "vcpus": 8,
            "memory_gb": 32,
        },
    )

    response = client.get("/api/v1/compute/instances/")

    assert response.status_code == 200
    body = response.json()
    names = [instance["name"] for instance in body]
    assert "etl-01" in names
    assert "etl-02" in names


def test_can_retrieve_single_compute_instance() -> None:
    """Se debe poder consultar una instancia específica por su id."""

    client = TestClient(app)
    create_response = client.post(
        "/api/v1/compute/instances/",
        json={
            "name": "pipeline-01",
            "image": "ubuntu-22-04-lts",
            "region": "us-east-2",
            "vcpus": 4,
            "memory_gb": 16,
        },
    )
    instance_id = create_response.json()["id"]

    detail = client.get(f"/api/v1/compute/instances/{instance_id}")

    assert detail.status_code == 200
    assert detail.json()["id"] == instance_id
    assert detail.json()["name"] == "pipeline-01"


def test_get_compute_instance_returns_404_when_missing() -> None:
    """Consultar una instancia inexistente debe devolver 404."""

    client = TestClient(app)

    response = client.get("/api/v1/compute/instances/999")

    assert response.status_code == 404


def test_can_update_compute_instance() -> None:
    """Actualizar una instancia debe modificar los campos seleccionados."""

    client = TestClient(app)
    create_response = client.post(
        "/api/v1/compute/instances/",
        json={
            "name": "processing-node",
            "image": "ubuntu-22-04-lts",
            "region": "us-west-1",
            "vcpus": 4,
            "memory_gb": 8,
        },
    )
    instance_id = create_response.json()["id"]

    update_response = client.patch(
        f"/api/v1/compute/instances/{instance_id}",
        json={"vcpus": 6, "status": "running"},
    )

    assert update_response.status_code == 200
    body = update_response.json()
    assert body["id"] == instance_id
    assert body["vcpus"] == 6
    assert body["status"] == "running"
    assert body["memory_gb"] == 8


def test_update_compute_instance_returns_404_when_missing() -> None:
    """Actualizar una instancia inexistente debe devolver 404."""

    client = TestClient(app)

    response = client.patch(
        "/api/v1/compute/instances/999",
        json={"status": "stopped"},
    )

    assert response.status_code == 404


def test_update_compute_instance_conflict_on_duplicate_name() -> None:
    """Renombrar una instancia usando un nombre existente debe fallar."""

    client = TestClient(app)
    first = client.post(
        "/api/v1/compute/instances/",
        json={
            "name": "analytics-a",
            "image": "ubuntu-22-04-lts",
            "region": "us-east-1",
            "vcpus": 4,
            "memory_gb": 8,
        },
    )
    second = client.post(
        "/api/v1/compute/instances/",
        json={
            "name": "analytics-b",
            "image": "ubuntu-22-04-lts",
            "region": "us-east-1",
            "vcpus": 4,
            "memory_gb": 8,
        },
    )

    conflict = client.patch(
        f"/api/v1/compute/instances/{second.json()['id']}",
        json={"name": first.json()["name"]},
    )

    assert conflict.status_code == 409
    assert "Ya existe" in conflict.json()["detail"]


def test_can_delete_compute_instance() -> None:
    """Eliminar una instancia debe devolver 204 y evitar consultas posteriores."""

    client = TestClient(app)
    create_response = client.post(
        "/api/v1/compute/instances/",
        json={
            "name": "temporary-node",
            "image": "debian-12",
            "region": "us-west-2",
            "vcpus": 2,
            "memory_gb": 4,
        },
    )
    instance_id = create_response.json()["id"]

    delete_response = client.delete(f"/api/v1/compute/instances/{instance_id}")

    assert delete_response.status_code == 204
    assert client.get(f"/api/v1/compute/instances/{instance_id}").status_code == 404


def test_list_instances_can_filter_by_status() -> None:
    """El listado debe aceptar filtros por estado de la instancia."""

    client = TestClient(app)
    client.post(
        "/api/v1/compute/instances/",
        json={
            "name": "etl-runner",
            "image": "ubuntu-22-04-lts",
            "region": "us-east-1",
            "vcpus": 4,
            "memory_gb": 16,
            "status": "running",
        },
    )
    client.post(
        "/api/v1/compute/instances/",
        json={
            "name": "spark-worker",
            "image": "ubuntu-22-04-lts",
            "region": "us-east-1",
            "vcpus": 8,
            "memory_gb": 32,
            "status": "stopped",
        },
    )

    response = client.get("/api/v1/compute/instances/?status=running")

    assert response.status_code == 200
    body = response.json()
    assert len(body) == 1
    assert body[0]["name"] == "etl-runner"
    assert body[0]["status"] == "running"


def test_delete_compute_instance_returns_404_when_missing() -> None:
    """Eliminar una instancia inexistente debe devolver 404."""

    client = TestClient(app)

    response = client.delete("/api/v1/compute/instances/999")

    assert response.status_code == 404


def test_compute_instance_name_validation_requires_lowercase() -> None:
    """Los nombres con mayúsculas no deben ser aceptados por la API."""

    client = TestClient(app)

    response = client.post(
        "/api/v1/compute/instances/",
        json={
            "name": "WorkerInvalid",
            "image": "ubuntu-22-04-lts",
            "region": "us-east-1",
            "vcpus": 4,
            "memory_gb": 16,
        },
    )

    assert response.status_code == 422
