"""Pruebas para el módulo de bases de datos administradas."""
from __future__ import annotations

if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    _repo_root = str(Path(__file__).resolve().parents[2])
    if _repo_root not in sys.path:
        sys.path.insert(0, _repo_root)

    del _repo_root

from fastapi.testclient import TestClient

from app.main import app


def test_can_create_database_instance() -> None:
    """Crear una instancia debe devolver el recurso persistido."""

    client = TestClient(app)
    payload = {
        "name": "analytics-db",
        "engine": "postgresql",
        "version": "14",
        "region": "us-east-1",
        "storage_gb": 100,
    }

    response = client.post("/api/v1/databases/instances/", json=payload)

    assert response.status_code == 201
    body = response.json()
    assert body["name"] == payload["name"]
    assert body["engine"] == payload["engine"]
    assert body["version"] == payload["version"]
    assert body["region"] == payload["region"]
    assert body["storage_gb"] == payload["storage_gb"]
    assert body["status"] == "provisioning"
    assert "id" in body
    assert "created_at" in body


def test_cannot_create_database_instance_with_duplicate_name() -> None:
    """Duplicar el nombre debe devolver un estado 409."""

    client = TestClient(app)
    payload = {
        "name": "transactions-db",
        "engine": "postgresql",
        "version": "15",
        "region": "eu-west-1",
        "storage_gb": 200,
    }

    first = client.post("/api/v1/databases/instances/", json=payload)
    assert first.status_code == 201

    second = client.post("/api/v1/databases/instances/", json=payload)
    assert second.status_code == 409
    assert "Ya existe" in second.json()["detail"]


def test_list_database_instances_returns_all_entries() -> None:
    """La lista debe contener las instancias creadas previamente."""

    client = TestClient(app)

    client.post(
        "/api/v1/databases/instances/",
        json={
            "name": "etl-db",
            "engine": "postgresql",
            "version": "14",
            "region": "us-central-1",
            "storage_gb": 150,
        },
    )
    client.post(
        "/api/v1/databases/instances/",
        json={
            "name": "ml-db",
            "engine": "mysql",
            "version": "8",
            "region": "us-central-1",
            "storage_gb": 120,
        },
    )

    response = client.get("/api/v1/databases/instances/")

    assert response.status_code == 200
    body = response.json()
    names = [instance["name"] for instance in body]
    assert "etl-db" in names
    assert "ml-db" in names


def test_can_retrieve_single_database_instance() -> None:
    """Se debe poder consultar una instancia específica de base de datos."""

    client = TestClient(app)
    create_response = client.post(
        "/api/v1/databases/instances/",
        json={
            "name": "analytics-warehouse",
            "engine": "postgresql",
            "version": "15",
            "region": "us-east-2",
            "storage_gb": 250,
        },
    )
    instance_id = create_response.json()["id"]

    detail = client.get(f"/api/v1/databases/instances/{instance_id}")

    assert detail.status_code == 200
    assert detail.json()["id"] == instance_id
    assert detail.json()["name"] == "analytics-warehouse"


def test_get_database_instance_returns_404_when_missing() -> None:
    """Consultar una base de datos inexistente debe devolver 404."""

    client = TestClient(app)

    response = client.get("/api/v1/databases/instances/999")

    assert response.status_code == 404


def test_can_update_database_instance() -> None:
    """Actualizar una base de datos administrada debe modificar sus valores."""

    client = TestClient(app)
    create_response = client.post(
        "/api/v1/databases/instances/",
        json={
            "name": "research-db",
            "engine": "postgresql",
            "version": "15",
            "region": "us-west-1",
            "storage_gb": 120,
        },
    )
    instance_id = create_response.json()["id"]

    update_response = client.patch(
        f"/api/v1/databases/instances/{instance_id}",
        json={"storage_gb": 240, "status": "available"},
    )

    assert update_response.status_code == 200
    body = update_response.json()
    assert body["id"] == instance_id
    assert body["storage_gb"] == 240
    assert body["status"] == "available"
    assert body["name"] == "research-db"


def test_update_database_instance_returns_404_when_missing() -> None:
    """Actualizar una base de datos inexistente debe devolver 404."""

    client = TestClient(app)

    response = client.patch(
        "/api/v1/databases/instances/999",
        json={"status": "failed"},
    )

    assert response.status_code == 404


def test_update_database_instance_conflict_on_duplicate_name() -> None:
    """Renombrar una base de datos con un nombre ocupado debe dar 409."""

    client = TestClient(app)
    first = client.post(
        "/api/v1/databases/instances/",
        json={
            "name": "catalog-db",
            "engine": "postgresql",
            "version": "15",
            "region": "us-east-1",
            "storage_gb": 150,
        },
    )
    second = client.post(
        "/api/v1/databases/instances/",
        json={
            "name": "logs-db",
            "engine": "mysql",
            "version": "8",
            "region": "us-east-1",
            "storage_gb": 150,
        },
    )

    conflict = client.patch(
        f"/api/v1/databases/instances/{second.json()['id']}",
        json={"name": first.json()["name"]},
    )

    assert conflict.status_code == 409
    assert "Ya existe" in conflict.json()["detail"]


def test_can_delete_database_instance() -> None:
    """Eliminar una instancia debe devolver 204 y bloquear consultas futuras."""

    client = TestClient(app)
    create_response = client.post(
        "/api/v1/databases/instances/",
        json={
            "name": "temporal-db",
            "engine": "mysql",
            "version": "8",
            "region": "us-west-1",
            "storage_gb": 80,
        },
    )
    instance_id = create_response.json()["id"]

    delete_response = client.delete(f"/api/v1/databases/instances/{instance_id}")

    assert delete_response.status_code == 204
    assert client.get(f"/api/v1/databases/instances/{instance_id}").status_code == 404


def test_delete_database_instance_returns_404_when_missing() -> None:
    """Eliminar una instancia inexistente debe responder 404."""

    client = TestClient(app)

    response = client.delete("/api/v1/databases/instances/999")

    assert response.status_code == 404


def test_list_database_instances_can_filter_by_engine() -> None:
    """El listado debe aceptar filtros por motor de base de datos."""

    client = TestClient(app)
    client.post(
        "/api/v1/databases/instances/",
        json={
            "name": "analytics-cluster",
            "engine": "postgresql",
            "version": "15",
            "region": "us-east-1",
            "storage_gb": 100,
        },
    )
    client.post(
        "/api/v1/databases/instances/",
        json={
            "name": "cache-cluster",
            "engine": "redis",
            "version": "7",
            "region": "us-east-1",
            "storage_gb": 20,
        },
    )

    response = client.get("/api/v1/databases/instances/?engine=postgresql")

    assert response.status_code == 200
    body = response.json()
    assert len(body) == 1
    assert body[0]["name"] == "analytics-cluster"
    assert body[0]["engine"] == "postgresql"


def test_database_instance_name_validation_requires_lowercase() -> None:
    """Los nombres con mayúsculas deben ser rechazados."""

    client = TestClient(app)

    response = client.post(
        "/api/v1/databases/instances/",
        json={
            "name": "AnalyticsDB",
            "engine": "postgresql",
            "version": "16",
            "region": "us-east-1",
            "storage_gb": 100,
        },
    )

    assert response.status_code == 422
