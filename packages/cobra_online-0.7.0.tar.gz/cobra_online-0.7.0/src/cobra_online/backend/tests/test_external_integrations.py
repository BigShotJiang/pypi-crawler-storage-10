if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    _repo_root = str(Path(__file__).resolve().parents[2])
    if _repo_root not in sys.path:
        sys.path.insert(0, _repo_root)

    del _repo_root

import json
import types

import pytest
import httpx

from app.db.external import (
    ExternalIntegrationManager,
    GraphQLAPIClient,
    GraphQLAPIConfig,
    RESTAPIClient,
    RESTAPIConfig,
)


def test_rest_api_client_uses_mock_transport() -> None:
    """El cliente REST debe aceptar un transport personalizado para pruebas."""

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/status"
        return httpx.Response(200, json={"ok": True})

    transport = httpx.MockTransport(handler)
    client = RESTAPIClient(RESTAPIConfig(base_url="https://example.org"), transport=transport)

    response = client.get("/status")
    assert response.json() == {"ok": True}


def test_graphql_client_executes_queries_with_mock_transport() -> None:
    """El cliente GraphQL debe poder ejecutar consultas contra un mock."""

    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode())
        variables = payload.get("variables", {})
        return httpx.Response(200, json={"data": {"echo": variables.get("value")}})

    transport = httpx.MockTransport(handler)
    client = GraphQLAPIClient(
        GraphQLAPIConfig(endpoint="https://example.org/graphql"),
        transport=transport,
    )

    result = client.execute("query($value: String!){ echo(value: $value) }", variables={"value": "cobra"})
    assert result["data"]["echo"] == "cobra"


def test_external_manager_configures_resources_from_settings() -> None:
    """El gestor debe registrar APIs y bases de datos declaradas en Settings."""

    manager = ExternalIntegrationManager()
    fake_settings = types.SimpleNamespace(
        external_api_endpoints={
            "github": {"base_url": "https://api.github.com", "timeout": 10},
        },
        graphql_api_endpoints={
            "countries": {"endpoint": "https://countries.example/graphql"},
        },
        third_party_databases={
            "analytics": {"driver": "mongodb", "url": "mongodb://example"},
        },
    )

    manager.configure_from_settings(fake_settings)

    assert manager.available_rest_apis() == ["github"]
    assert manager.available_graphql_apis() == ["countries"]
    assert manager.databases.available_connections() == ["analytics"]
    config = manager.databases.get_connection_config("analytics")
    assert config.driver == "mongodb"
    assert config.url == "mongodb://example"


def test_database_registry_requires_optional_dependencies() -> None:
    """Las bases externas deben advertir cuando falta la librería correspondiente."""

    manager = ExternalIntegrationManager()

    with pytest.raises(ModuleNotFoundError) as exc:
        manager.databases.create_database("mongodb", url="mongodb://localhost/test")

    assert "pymongo" in str(exc.value)
    assert "mongodb" in str(exc.value)
