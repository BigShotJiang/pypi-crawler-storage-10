"""Pruebas para el módulo de pipelines de análisis."""
from __future__ import annotations

if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    _repo_root = str(Path(__file__).resolve().parents[2])
    if _repo_root not in sys.path:
        sys.path.insert(0, _repo_root)

    del _repo_root

from fastapi.testclient import TestClient

from app.main import app


def test_can_create_pipeline() -> None:
    """Crear un pipeline debe devolver el recurso recién creado."""

    client = TestClient(app)
    payload = {
        "name": "daily-etl",
        "engine": "spark",
        "schedule": "0 2 * * *",
        "description": "Ingesta nocturna",
    }

    response = client.post("/api/v1/analytics/pipelines/", json=payload)

    assert response.status_code == 201
    body = response.json()
    assert body["name"] == payload["name"]
    assert body["engine"] == payload["engine"]
    assert body["mode"] == "batch"
    assert body["schedule"] == payload["schedule"]
    assert body["description"] == payload["description"]
    assert body["status"] == "draft"
    assert "id" in body
    assert "created_at" in body


def test_cannot_create_pipeline_with_duplicate_name() -> None:
    """Duplicar el nombre de un pipeline debe dar como resultado un 409."""

    client = TestClient(app)
    payload = {
        "name": "realtime-stream",
        "engine": "dask",
        "schedule": "*/5 * * * *",
    }

    first = client.post("/api/v1/analytics/pipelines/", json=payload)
    assert first.status_code == 201

    second = client.post("/api/v1/analytics/pipelines/", json=payload)
    assert second.status_code == 409
    assert "Ya existe" in second.json()["detail"]


def test_list_pipelines_returns_all_entries() -> None:
    """La lista de pipelines debe incluir los registros existentes."""

    client = TestClient(app)
    client.post(
        "/api/v1/analytics/pipelines/",
        json={
            "name": "batch-a",
            "engine": "spark",
            "schedule": "0 1 * * 1",
        },
    )
    client.post(
        "/api/v1/analytics/pipelines/",
        json={
            "name": "batch-b",
            "engine": "dask",
            "schedule": "30 3 * * 1",
            "mode": "streaming",
        },
    )

    response = client.get("/api/v1/analytics/pipelines/")

    assert response.status_code == 200
    body = response.json()
    names = [pipeline["name"] for pipeline in body]
    assert "batch-a" in names
    assert "batch-b" in names


def test_list_pipelines_can_filter_by_status() -> None:
    """El listado debe aceptar filtros por estado del pipeline."""

    client = TestClient(app)
    created = client.post(
        "/api/v1/analytics/pipelines/",
        json={
            "name": "batch-success",
            "engine": "spark",
            "schedule": "0 1 * * *",
        },
    )
    pipeline_id = created.json()["id"]
    client.patch(
        f"/api/v1/analytics/pipelines/{pipeline_id}",
        json={"status": "completed", "mode": "streaming"},
    )
    client.post(
        "/api/v1/analytics/pipelines/",
        json={
            "name": "batch-pending",
            "engine": "dask",
            "schedule": "30 2 * * *",
        },
    )

    response = client.get("/api/v1/analytics/pipelines/?status=completed")

    assert response.status_code == 200
    body = response.json()
    assert len(body) == 1
    assert body[0]["name"] == "batch-success"
    assert body[0]["status"] == "completed"
    assert body[0]["mode"] == "streaming"


def test_list_pipelines_can_filter_by_mode_and_engine() -> None:
    """El listado debe poder combinar filtros de modo y motor."""

    client = TestClient(app)
    client.post(
        "/api/v1/analytics/pipelines/",
        json={
            "name": "batch-reference",
            "engine": "spark",
            "schedule": "0 6 * * *",
        },
    )
    streaming = client.post(
        "/api/v1/analytics/pipelines/",
        json={
            "name": "stream-monitoring",
            "engine": "nifi",
            "mode": "streaming",
        },
    )

    response = client.get("/api/v1/analytics/pipelines/?mode=streaming&engine=nifi")

    assert response.status_code == 200
    body = response.json()
    assert len(body) == 1
    assert body[0]["id"] == streaming.json()["id"]
    assert body[0]["mode"] == "streaming"
    assert body[0]["engine"] == "nifi"


def test_pipeline_summary_returns_expected_counters() -> None:
    """El resumen agregado debe incluir totales por estado y motor."""

    client = TestClient(app)
    client.post(
        "/api/v1/analytics/pipelines/",
        json={
            "name": "etl-alpha",
            "engine": "spark",
            "schedule": "0 1 * * *",
        },
    )
    second = client.post(
        "/api/v1/analytics/pipelines/",
        json={
            "name": "etl-beta",
            "engine": "spark",
            "schedule": "30 1 * * *",
        },
    )
    client.post(
        "/api/v1/analytics/pipelines/",
        json={
            "name": "etl-gamma",
            "engine": "dask",
            "schedule": "15 2 * * *",
            "mode": "streaming",
        },
    )

    pipeline_id = second.json()["id"]
    client.patch(
        f"/api/v1/analytics/pipelines/{pipeline_id}",
        json={"status": "completed"},
    )

    response = client.get("/api/v1/analytics/pipelines/summary")

    assert response.status_code == 200
    body = response.json()
    assert body["total"] == 3
    assert body["by_engine"] == {"spark": 2, "dask": 1}
    assert body["by_status"]["completed"] == 1
    assert body["by_status"]["draft"] == 2
    assert body["by_mode"] == {"batch": 2, "streaming": 1}


def test_can_retrieve_single_pipeline() -> None:
    """Se debe poder consultar un pipeline específico por su id."""

    client = TestClient(app)
    create_response = client.post(
        "/api/v1/analytics/pipelines/",
        json={
            "name": "analytics-nightly",
            "engine": "spark",
            "schedule": "0 0 * * *",
        },
    )
    pipeline_id = create_response.json()["id"]

    detail = client.get(f"/api/v1/analytics/pipelines/{pipeline_id}")

    assert detail.status_code == 200
    assert detail.json()["id"] == pipeline_id
    assert detail.json()["name"] == "analytics-nightly"
    assert detail.json()["mode"] == "batch"


def test_get_pipeline_returns_404_when_missing() -> None:
    """Consultar un pipeline inexistente debe devolver 404."""

    client = TestClient(app)

    response = client.get("/api/v1/analytics/pipelines/999")

    assert response.status_code == 404


def test_can_update_pipeline() -> None:
    """Actualizar un pipeline debe reflejar los cambios solicitados."""

    client = TestClient(app)
    create_response = client.post(
        "/api/v1/analytics/pipelines/",
        json={
            "name": "daily-report",
            "engine": "spark",
            "schedule": "0 4 * * *",
        },
    )
    pipeline_id = create_response.json()["id"]

    update_response = client.patch(
        f"/api/v1/analytics/pipelines/{pipeline_id}",
        json={
            "schedule": "15 4 * * *",
            "status": "scheduled",
            "description": "Actualizado",
            "mode": "streaming",
        },
    )

    assert update_response.status_code == 200
    body = update_response.json()
    assert body["id"] == pipeline_id
    assert body["schedule"] == "15 4 * * *"
    assert body["status"] == "scheduled"
    assert body["description"] == "Actualizado"
    assert body["mode"] == "streaming"


def test_update_pipeline_returns_404_when_missing() -> None:
    """Actualizar un pipeline inexistente debe devolver 404."""

    client = TestClient(app)

    response = client.patch(
        "/api/v1/analytics/pipelines/999",
        json={"status": "failed"},
    )

    assert response.status_code == 404


def test_update_pipeline_conflict_on_duplicate_name() -> None:
    """Renombrar un pipeline con un nombre ocupado debe devolver 409."""

    client = TestClient(app)
    first = client.post(
        "/api/v1/analytics/pipelines/",
        json={
            "name": "morning-etl",
            "engine": "spark",
            "schedule": "0 6 * * *",
        },
    )
    second = client.post(
        "/api/v1/analytics/pipelines/",
        json={
            "name": "evening-etl",
            "engine": "dask",
            "schedule": "0 18 * * *",
        },
    )

    conflict = client.patch(
        f"/api/v1/analytics/pipelines/{second.json()['id']}",
        json={"name": first.json()["name"]},
    )

    assert conflict.status_code == 409
    assert "Ya existe" in conflict.json()["detail"]


def test_can_delete_pipeline() -> None:
    """Eliminar un pipeline debe devolver 204 y bloquear consultas posteriores."""

    client = TestClient(app)
    create_response = client.post(
        "/api/v1/analytics/pipelines/",
        json={
            "name": "temporal-etl",
            "engine": "spark",
            "schedule": "0 10 * * *",
        },
    )
    pipeline_id = create_response.json()["id"]

    delete_response = client.delete(f"/api/v1/analytics/pipelines/{pipeline_id}")

    assert delete_response.status_code == 204
    assert client.get(f"/api/v1/analytics/pipelines/{pipeline_id}").status_code == 404


def test_delete_pipeline_returns_404_when_missing() -> None:
    """Eliminar un pipeline inexistente debe devolver 404."""

    client = TestClient(app)

    response = client.delete("/api/v1/analytics/pipelines/999")

    assert response.status_code == 404


def test_pipeline_name_validation_requires_lowercase() -> None:
    """Los nombres con mayúsculas deben ser rechazados."""

    client = TestClient(app)

    response = client.post(
        "/api/v1/analytics/pipelines/",
        json={
            "name": "DailyETL",
            "engine": "spark",
            "schedule": "0 5 * * *",
        },
    )

    assert response.status_code == 422


def test_pipeline_schedule_requires_min_length() -> None:
    """Las expresiones de programación demasiado cortas deben fallar."""

    client = TestClient(app)

    response = client.post(
        "/api/v1/analytics/pipelines/",
        json={
            "name": "tiny-schedule",
            "engine": "spark",
            "schedule": "*",
        },
    )

    assert response.status_code == 422


def test_pipeline_requires_valid_engine() -> None:
    """Los motores no soportados deben ser rechazados por validación."""

    client = TestClient(app)

    response = client.post(
        "/api/v1/analytics/pipelines/",
        json={
            "name": "unknown-engine",
            "engine": "hadoop",
            "schedule": "0 7 * * *",
        },
    )

    assert response.status_code == 422
