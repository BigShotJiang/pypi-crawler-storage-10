"""Compatibilidad para importar el paquete ``app`` desde la raíz del repositorio."""
from __future__ import annotations

import importlib
import sys
from types import ModuleType

# Al trabajar directamente con el repositorio el paquete ``app`` reside dentro de
# ``backend``. Esto provoca que ejecutar ``python -m app.main`` desde la raíz
# falle con ``ModuleNotFoundError``. Para evitarlo importamos el paquete real y
# registramos un alias que expone los mismos módulos.
_backend_app: ModuleType = importlib.import_module("backend.app")

# Propagamos los atributos públicos para mantener el mismo comportamiento
# observable que ``backend.app`` cuando se importa ``app``.
globals().update({name: getattr(_backend_app, name) for name in dir(_backend_app)})

# Sustituimos este módulo por el paquete original para que las importaciones de
# submódulos funcionen de forma transparente.
sys.modules[__name__] = _backend_app
