# Cobra_Online

Cobra_Online é uma plataforma Open Source de Big Data e serviços em nuvem semelhante à AWS, Azure e GCP. Ela oferece uma solução escalável, modular e multiplataforma que pode ser instalada em qualquer servidor, máquina virtual ou hospedagem na nuvem.

## Funcionalidades

- **Armazenamento de Objetos** (compatível com S3)
- **Computação Virtualizada**
- **Bancos de Dados Gerenciados** (SQL/NoSQL)
- **Análise de Big Data** (gestão de pipelines ETL com Spark/Dask)
- **Inteligência Artificial e Machine Learning**
- **Gestão de modelos IA/ML** (registro, rastreamento e publicação de endpoints)
- **Serviços de Rede**

## Objetivo

O objetivo de Cobra_Online é democratizar as capacidades avançadas de nuvem e Big Data, permitindo que qualquer pessoa implemente seu próprio ecossistema na infraestrutura de sua escolha.

## Contribuições

Cobra_Online está aberto a contribuições! Consulte o arquivo [CONTRIBUTING.md](CONTRIBUTING.md) para mais detalhes.

> Prefere a documentação em espanhol ou inglês? Consulte as versões disponíveis em
> [docs/README.md](README.md) e [docs/README.en.md](README.en.md) com um resumo
> das informações principais em cada idioma.

## Executar com Docker Compose

Para iniciar rapidamente a API e um banco de dados PostgreSQL local, utilize o arquivo `infra/docker-compose.yml`.

1. Acesse a pasta `infra` e suba os serviços:
   ```bash
   cd infra
   docker compose up --build
   ```
2. A API ficará disponível em `http://localhost:8000`.
3. Se preferir continuar usando SQLite, não defina `DATABASE_URL`. Para usar PostgreSQL, exporte variáveis como `POSTGRES_DB`, `POSTGRES_USER`, `POSTGRES_PASSWORD` e `DATABASE_URL` antes de executar `docker compose`.
4. Caso vá administrar API keys pela plataforma, sobrescreva a variável
   `API_KEY_MASTER_SECRET` para personalizar o segredo mestre utilizado ao
   armazenar as chaves de forma cifrada.

### Script de implantação automatizado

A pasta `infra/scripts/` inclui o arquivo `deploy.sh`, que encapsula as ações mais comuns sobre a pilha Docker Compose.

```bash
./infra/scripts/deploy.sh start   # Constrói e sobe a pilha
./infra/scripts/deploy.sh stop    # Interrompe e remove os contêineres
./infra/scripts/deploy.sh logs    # Acompanha os logs combinados da API e do banco de dados
./infra/scripts/deploy.sh status  # Consulta o estado dos serviços
```

Se existir um arquivo `infra/.env` (ou se a variável de ambiente `COBRA_ENV_FILE`
apontar para outro caminho), o script irá aplicá-lo automaticamente ao invocar o Docker Compose. Isso facilita manter configurações específicas por ambiente sem repetir comandos manualmente.

## Instalação do backend como pacote Python

Dentro da pasta `backend/` é possível instalar a API como um pacote Python graças ao arquivo `pyproject.toml` incluído. Isso facilita a distribuição em ambientes onde Docker não é uma opção.

```bash
cd backend
pip install .
```

O pacote expõe o comando `cobra-online-api`, que inicia o serviço utilizando os valores configurados nas variáveis de ambiente `API_HOST` e `API_PORT`.

## Internacionalização dos endpoints de saúde

Os endpoints públicos `/health/` e `/health/metrics` aceitam o parâmetro de consulta `lang` e o cabeçalho padrão `Accept-Language`. A resposta inclui o idioma aplicado, uma mensagem localizada e o link para a documentação correspondente.

## Plano de lançamentos e comunidade

A fase de manutenção contínua conta com um calendário de versões e um plano para expandir a comunidade. Consulte os detalhes e próximos marcos em [`docs/RELEASE_AND_COMMUNITY_PLAN.md`](RELEASE_AND_COMMUNITY_PLAN.md).

## Licença

Este projeto é licenciado sob a Licença Apache 2.0. Consulte o arquivo [LICENSE](../LICENSE) para mais informações.

## Camada de banco de dados com SQLitePlus Enhanced

O SQLite continua sendo o banco de dados padrão, reforçado pela distribuição
[sqliteplus-enhanced](https://pypi.org/project/sqliteplus-enhanced/). As
conexões administradas pela API aplicam automaticamente criptografia opcional,
`PRAGMAs` de desempenho (`journal_mode`, `foreign_keys`, `busy_timeout`) e
tarefas de manutenção como `PRAGMA optimize`, `wal_checkpoint` e `VACUUM`, todas
configuráveis via variáveis de ambiente. A classe utilitária
`SQLitePlusDatabase` reúne operações frequentes: execução de scripts com várias
sentenças, anexação/remoção de bancos externos, exportação de tabelas para CSV,
replicação do arquivo e criação de backups sob demanda.

O helper `gather_sqlite_diagnostics` agora inclui métricas adicionais, como a
lista de tabelas e o tamanho em disco, facilitando a construção de painéis de
observabilidade.

O configurador `app.db.manager.DatabaseConfigurator` gera engines do SQLAlchemy
ajustados para provedores populares:

- **SQLite** com sqliteplus-enhanced e `NullPool` para evitar bloqueios.
- **PostgreSQL / Amazon Redshift** com suporte a `statement_timeout`,
  `application_name` e parâmetros TLS (`sslmode`, `sslrootcert`).
- **MySQL / MariaDB** com `pool_recycle` automático para respeitar o
  `wait_timeout` típico.
- **SQL Server** propagando `application_name` para diagnóstico corporativo.
- **Oracle Database** usando `DBMS_APPLICATION_INFO` para rotular sessões.
- **Snowflake** encaminhando o campo `application` e configurando
  `STATEMENT_TIMEOUT_IN_SECONDS` a partir do `.env`.
- **Provedores SQL via HTTP** (Trino, Databricks SQL, ClickHouse HTTP, Google
  BigQuery) desativando o pool de conexões e propagando `application_name` quando
  o dialeto oferece suporte a `SET` padrão.

Novos motores podem ser registrados dinamicamente com
`DatabaseConfigurator.register_backend(...)`, mantendo o projeto aberto para
APIs REST ou dialetos proprietários sem alterar os módulos centrais.
