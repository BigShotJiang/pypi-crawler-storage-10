# Roadmap resumido

El proyecto sigue las fases descritas en el documento **PROYECTO COBRA_CLOUD.pdf**. La siguiente lista resume los hitos y su estado actual.

1. **Fase 1 – Planificación y diseño (Completada)**
   - Arquitectura modular definida.
   - Estructura inicial del repositorio creada.
   - Documentación base publicada.
2. **Fase 2 – MVP (En progreso)**
   - ✅ API de salud.
   - ✅ Catálogo inicial de buckets S3 (CRUD parcial).
   - ✅ Servicios de cómputo.
   - ✅ Bases de datos administradas (CRUD básico).
   - ✅ Servicios de red básicos (balanceadores de carga).
   - ✅ Pipelines de análisis de datos (CRUD básico).
   - ✅ Endpoints de lectura y eliminación para recursos del MVP.
   - ✅ Infraestructura mínima: orquestación con Docker Compose para la API y PostgreSQL.
3. **Fase 3 – Pruebas y optimización (En progreso)**
   - ✅ Filtros de catálogos en la API para optimizar las consultas.
   - ✅ Pruebas de carga y seguridad (autenticación mediante API keys, gestión centralizada con almacenamiento cifrado y nuevo endpoint `/health/metrics` para monitoreo).
   - ✅ Optimización de pipelines de datos.
4. **Fase 4 – Lanzamiento Beta (En progreso)**
   - ✅ Guía inicial de contribución publicada.
   - ✅ Empaquetado del backend para despliegues (`pip install cobra-online-api`).
   - ✅ Script de despliegue automatizado para Docker Compose (`infra/scripts/deploy.sh`).
   - ✅ Documentación centralizada de canales comunitarios y gobernanza (`docs/COMMUNITY.md`).
   - Publicación en GitHub.
   - Creación de comunidad.
5. **Fase 5 – Funcionalidades avanzadas (En progreso)**
   - ✅ Integraciones IA/ML y Big Data avanzadas (compatibilidad con motores Spark, Dask y NiFi en pipelines de análisis y catálogo inicial de modelos IA/ML disponible).
   - ✅ Métricas agregadas del catálogo de modelos IA/ML expuestas vía API.
   - ✅ Internacionalización y documentación avanzada (es, en y soporte añadido en pt para los endpoints de salud).
6. **Fase 6 – Mantenimiento continuo (En progreso)**
   - ✅ Calendario de lanzamientos documentado en `docs/RELEASE_AND_COMMUNITY_PLAN.md`.
   - ✅ Estrategia de crecimiento de la comunidad definida (ver `docs/RELEASE_AND_COMMUNITY_PLAN.md`).
