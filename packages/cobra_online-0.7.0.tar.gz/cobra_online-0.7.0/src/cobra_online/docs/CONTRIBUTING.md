# Guía de contribución a Cobra_Online

¡Gracias por tu interés en colaborar con Cobra_Online! Este proyecto busca construir una
plataforma abierta de servicios de nube y Big Data, por lo que las contribuciones de la
comunidad son fundamentales. Este documento resume los pasos y estándares mínimos
para proponer cambios con éxito.

## Código de conducta

* Respeta a los demás colaboradores y mantén un lenguaje profesional.
* Prioriza la claridad en las discusiones. Si encuentras un problema, describe el contexto y
  los pasos para reproducirlo.
* Evita compartir credenciales reales o datos sensibles en issues, commits o PRs.

## Preparación del entorno

1. **Requisitos básicos**
   - Python 3.11 o superior.
   - Git y un entorno virtual (``venv`` o ``conda``) recomendados.
   - Docker y Docker Compose opcionales para ejecutar la pila completa descrita en `infra/`.
2. **Clona el repositorio y crea una rama**
   ```bash
   git clone https://github.com/<tu-usuario>/cobra_online.git
   cd cobra_online
   git checkout -b feat/mi-aporte
   ```
3. **Crea y activa un entorno virtual (opcional pero recomendado)**
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # En Windows usa `.venv\Scripts\activate`
   ```
4. **Instala las dependencias del backend**
   ```bash
   pip install -r backend/requirements.txt
   ```
5. **Configura la base de datos**
   - La API usa SQLite por defecto (`backend/data/cobra.db`). Se crea automáticamente al
     iniciar la aplicación o ejecutar los tests, por lo que no requiere pasos adicionales.
   - Si prefieres PostgreSQL, revisa las variables documentadas en `docs/README.md` y el
     archivo `infra/docker-compose.yml`.

## Ejecutar la API localmente

Desde la carpeta `backend` puedes lanzar la API con Uvicorn:

```bash
cd backend
uvicorn app.main:app --reload
```

La documentación interactiva estará disponible en `http://localhost:8000/docs`.

## Ejecutar las pruebas

Antes de abrir un Pull Request (PR) ejecuta toda la batería de pruebas:

```bash
cd backend
pytest
```

Asegúrate de que no falle ningún test y que los cambios introduzcan coberturas
relevantes para la funcionalidad añadida o corregida.

## Estándares de código

* Utiliza _type hints_ en todas las funciones y clases nuevas.
* Emplea docstrings y comentarios en español, siguiendo el estilo del proyecto.
* Prefiere `from __future__ import annotations` en módulos nuevos de Python para
  mantener consistencia con el código existente.
* Reutiliza los servicios y esquemas Pydantic ya definidos cuando añadas endpoints
  nuevos.
* Si agregas rutas o modificas la API, actualiza `docs/API.md` y añade/ajusta pruebas en
  `backend/tests/`.
* Procura mantener los imports ordenados y sin alias innecesarios; sigue el estilo
  predominante en los módulos actuales.

## Flujo para proponer cambios

1. Asegúrate de que tu rama esté actualizada con `main` (`git pull --rebase origin main`).
2. Realiza commits pequeños y descriptivos.
3. Ejecuta las pruebas localmente antes de subir tu trabajo (`pytest`).
4. Abre un PR indicando claramente el problema que resuelves o la funcionalidad que
   añades. Incluye pasos de verificación manual si aplica.
5. Responde a los comentarios de revisión y ajusta tu PR hasta obtener aprobación.

## Reporte de errores y solicitudes de mejora

* Usa la sección de Issues para reportar fallos o proponer nuevas características.
* Antes de crear un issue, busca si ya existe uno similar.
* Incluye información relevante: versión de Python, comandos utilizados, logs y
  capturas de pantalla si ayudan a diagnosticar el problema.

## Documentación

* Cada nueva funcionalidad debe acompañarse de documentación en la carpeta `docs/`.
* Actualiza `docs/ROADMAP.md` si tu cambio impacta el estado de algún hito.
* Aporta ejemplos de uso cuando sea posible para facilitar la adopción de la plataforma.

¡Gracias por ayudar a que Cobra_Online crezca! Tu contribución hace la diferencia.
