# Comunidad de Cobra_Online

Este documento describe los canales oficiales y el proceso de gobernanza que
acompañan al lanzamiento Beta del proyecto, conforme al plan detallado en
[`docs/RELEASE_AND_COMMUNITY_PLAN.md`](RELEASE_AND_COMMUNITY_PLAN.md).

## Canales oficiales

- **GitHub Discussions** (`https://github.com/cobra-online/cobra_online/discussions`):
  Espacio principal para soporte técnico, propuestas y debates sobre la hoja de ruta.
- **Servidor de Discord** (`https://discord.gg/placeholder`):
  Comunicación en tiempo real para sesiones de co-creación, _bug bashes_ y anuncios rápidos.
- **Boletín mensual** (`https://example.com/boletin`):
  Recopila las novedades destacadas, próximos hitos del roadmap y llamadas a contribuciones.

> **Nota:** Los enlaces de Discord y del boletín sirven como marcadores hasta que se
> publiquen los canales definitivos. Actualízalos tras la activación oficial.

## Gobernanza y moderación

1. **Código de conducta:** Todos los canales se rigen por las pautas generales
   descritas en [`docs/CONTRIBUTING.md`](CONTRIBUTING.md). Cualquier incumplimiento
   debe reportarse a los administradores del repositorio.
2. **Moderadores:**
   - Equipo núcleo del proyecto (mantenedores con permisos de escritura).
   - Miembros destacados de la comunidad designados por consenso en Discussions.
3. **Escalado de incidencias:**
   - Los conflictos que no puedan resolverse entre las partes se documentarán en un
     hilo dedicado de Discussions para transparencia.
   - Las decisiones finales se registrarán en el _changelog_ de la versión
     correspondiente cuando impliquen cambios funcionales.

## Ciclo de feedback

1. **Recolección:**
   - Cuestionario trimestral compartido a través del boletín.
   - Hilos etiquetados como `feedback` en Discussions.
2. **Prioridad:**
   - Se revisa en la reunión comunitaria mensual; los acuerdos se documentan en un
     comentario fijado dentro del hilo correspondiente.
3. **Seguimiento:**
   - Se crean issues en GitHub con etiquetas `community` y `needs-triage` para las
     acciones que requieran trabajo.
   - Las acciones aceptadas se programan en el siguiente ciclo de lanzamiento y se
     reflejan en `docs/ROADMAP.md` cuando aplique.

## Eventos recurrentes

- **Reunión abierta mensual:** Se comparte agenda y acta en un hilo de Discussions
  con etiqueta `meeting-notes` y se registra el evento usando la plantilla
  [`Evento comunitario`](../.github/ISSUE_TEMPLATE/community_event.md) para dar
  visibilidad a la organización y documentación posterior.
- **Hackathons trimestrales:** Las reglas y objetivos se publican con al menos dos
  semanas de antelación. Abre un issue con la plantilla de eventos para adjuntar
  las dinámicas, materiales y responsables. Los resultados se resumen en el
  boletín.
- **Programa de mentoring:**
  - Formularios de inscripción en el boletín y en Discussions.
  - Sesiones de bienvenida cada primer lunes del mes; documenta cada edición con
    la plantilla de eventos para centralizar notas y acciones.

## Próximos pasos

1. Activar los enlaces definitivos para Discord y el boletín.
2. Evaluar la necesidad de plantillas adicionales (por ejemplo, reportes de
   mentoring) y ampliarlas sobre la base del formato de eventos.
3. Revisar este documento cada ciclo de lanzamiento para reflejar cambios en la
   gobernanza o canales activos, actualizando los enlaces a issues creados con la
   plantilla comunitaria cuando corresponda.
