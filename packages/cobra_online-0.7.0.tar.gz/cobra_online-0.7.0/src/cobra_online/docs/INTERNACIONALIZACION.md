# Internacionalización en Cobra_Online

Este documento resume las pautas para añadir soporte multilingüe en la API y en
la documentación del proyecto.

## Idiomas soportados actualmente

- Español (`es`): Idioma por defecto.
- Inglés (`en`): Traducción enfocada a la comunidad internacional.
- Portugués (`pt`): Cobertura para contribuidores de Brasil y otros países lusófonos.

## Salud del servicio

Los endpoints `/api/v1/health/` y `/api/v1/health/metrics` aceptan dos fuentes
para determinar el idioma final de la respuesta:

1. Parámetro de consulta `lang` (`?lang=en`).
2. Cabecera HTTP estándar `Accept-Language`.

El idioma proporcionado se normaliza a códigos ISO 639-1 y, en caso de que no se
encuentre un valor soportado, se utiliza el español como valor por defecto. Ambos
endpoints exponen los siguientes campos adicionales:

- `locale`: Código ISO 639-1 aplicado a la respuesta.
- `message` / `summary`: Descripciones localizadas del estado o las métricas.
- `documentation_url`: Enlace a la documentación recomendada en el idioma
  correspondiente.

## Añadir nuevos idiomas

1. Define las traducciones en `backend/app/core/i18n.py` siguiendo la estructura
   existente.
2. Amplía las pruebas automáticas en `backend/tests/test_health.py` para validar
   la nueva localización.
3. Actualiza la documentación (por ejemplo, creando `docs/README.<idioma>.md`).
   Ya contamos con `docs/README.pt.md` como referencia en portugués.
4. Refleja el soporte en `docs/ROADMAP.md` o en las notas de la versión
   correspondiente.

## Buenas prácticas

- Mantén los mensajes concisos para facilitar su traducción.
- Prefiere enlaces canónicos que estén disponibles públicamente (por ejemplo,
  archivos dentro del repositorio).
- Añade siempre pruebas que verifiquen el idioma por defecto y el idioma nuevo.
- Reutiliza las claves de traducción existentes cuando sea posible.

Con estas pautas, Cobra_Online sigue avanzando hacia una plataforma accesible
para la comunidad global.
