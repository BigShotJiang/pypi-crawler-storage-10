# Cobra_Online

Cobra_Online es una plataforma Open Source de Big Data y servicios en la nube similar a AWS, Azure y GCP. Ofrece una solución escalable, modular y multiplataforma que puede ser instalada en cualquier servidor, máquina virtual o alojamiento en la nube.

## Funcionalidades

- **Almacenamiento de Objetos** (compatibilidad S3)
- **Cómputo Virtualizado**
- **Bases de Datos Administradas** (SQL/NoSQL)
- **Análisis de Big Data** (gestión de pipelines ETL con Spark/Dask)
- **Inteligencia Artificial y Machine Learning**
- **Gestión de modelos IA/ML** (registro, seguimiento y publicación de endpoints)
- **Servicios de Red**
- **Compatibilidad extendida de bases de datos** para conectar proveedores SQL
  gestionados y APIs de terceros mediante el configurador multi-motor.

## Objetivo

El objetivo de Cobra_Online es democratizar las capacidades avanzadas de la nube y Big Data, permitiendo a cualquiera implementar su propio ecosistema en infraestructura de su elección.

## Contribuir

¡Cobra_Online está abierto a contribuciones! Consulta el archivo [CONTRIBUTING.md](docs/CONTRIBUTING.md) para más detalles.

> ¿Prefieres la documentación en otro idioma? Consulta las versiones
> extendidas en [docs/README.en.md](README.en.md) para inglés y
> [docs/README.pt.md](README.pt.md) para portugués, ambas con un resumen de
> la información principal.

## Ejecutar con Docker Compose

Para levantar rápidamente la API y una base de datos PostgreSQL local puedes utilizar el archivo `infra/docker-compose.yml`.

1. Sitúate en la carpeta `infra` y arranca los servicios:
   ```bash
   cd infra
   docker compose up --build
   ```
2. La API quedará disponible en `http://localhost:8000`.
3. Si prefieres seguir usando SQLite, no definas `DATABASE_URL`. Para usar PostgreSQL puedes exportar variables como `POSTGRES_DB`, `POSTGRES_USER`, `POSTGRES_PASSWORD` y `DATABASE_URL` antes de ejecutar `docker compose`.
4. Si vas a administrar API keys desde la plataforma, sobrescribe la variable
   `API_KEY_MASTER_SECRET` para personalizar el secreto maestro utilizado al
   almacenar las claves de forma cifrada.

### Script de despliegue automatizado

La carpeta `infra/scripts/` incluye el archivo `deploy.sh`, que encapsula las
acciones más comunes sobre la pila de Docker Compose.

```bash
./infra/scripts/deploy.sh start   # Construye y levanta la pila
./infra/scripts/deploy.sh stop    # Detiene y elimina los contenedores
./infra/scripts/deploy.sh logs    # Sigue los logs combinados de la API y la base de datos
./infra/scripts/deploy.sh status  # Consulta el estado de los servicios
```

Si existe un archivo `infra/.env` (o se define la variable de entorno
`COBRA_ENV_FILE` apuntando a otra ruta), el script lo aplicará automáticamente
al invocar Docker Compose. Esto facilita mantener configuraciones distintas por
entorno sin repetir comandos manualmente.

## Instalación del backend como paquete Python

Desde la carpeta `backend/` ahora es posible instalar la API como un paquete Python
gracias al archivo `pyproject.toml` incluido. Esto facilita la distribución en
entornos donde Docker no es una opción.

```bash
cd backend
pip install .
```

El paquete expone el comando `cobra-online-api`, que inicia el servicio utilizando
los valores configurados en las variables de entorno `API_HOST` y `API_PORT`.

## Internacionalización de los endpoints de salud

Los endpoints públicos `/health/` y `/health/metrics` aceptan el parámetro de
consulta `lang` y la cabecera estándar `Accept-Language`. La respuesta incluye
el idioma aplicado, un mensaje localizado y el enlace a la documentación
correspondiente.

## Plan de lanzamientos y comunidad

La fase de mantenimiento continuo cuenta con un calendario de versiones y un
plan para escalar la comunidad. Consulta los detalles y próximos hitos en
[`docs/RELEASE_AND_COMMUNITY_PLAN.md`](RELEASE_AND_COMMUNITY_PLAN.md).

## Licencia

Este proyecto está licenciado bajo la Licencia Apache 2.0. Consulta el archivo [LICENSE](LICENSE) para más información.
## Bases de datos mejoradas con SQLitePlus Enhanced

SQLite sigue siendo la base de datos predeterminada, reforzada con la
distribución [sqliteplus-enhanced](https://pypi.org/project/sqliteplus-enhanced/).
Las conexiones gestionadas por la API aplican automáticamente cifrado opcional,
`PRAGMA` de rendimiento (`journal_mode`, `foreign_keys`, `busy_timeout`) y
tareas de mantenimiento como `PRAGMA optimize`, `wal_checkpoint` y `VACUUM`
configurables mediante variables de entorno. La nueva clase de ayuda
`SQLitePlusDatabase` encapsula operaciones frecuentes: ejecutar scripts
multi-sentencia, adjuntar o desacoplar bases externas, lanzar copias de
seguridad (`backup`), replicar el fichero (`replicate_to`) y exportar tablas a
CSV (`export_table`). Estas utilidades aprovechan las capacidades oficiales de
sqliteplus-enhanced, incluyendo la compatibilidad con SQLCipher. A partir de
esta iteración se añadieron métodos para cubrir escenarios reales de uso:

- `fetchone`, `fetchmany` y `stream_query` permiten leer resultados de forma
  incremental sin cargar toda la tabla en memoria.
- `execute_many` facilita cargas masivas con `executemany` nativo y devuelve el
  número de filas afectadas.
- `transaction()` expone un contexto seguro que aplica `BEGIN/COMMIT` y revierte
  automáticamente ante errores.
- `log_action`, `fetch_logs` y `clear_logs` delegan en la bitácora integrada de
  sqliteplus-enhanced para auditar cambios relevantes.

La función `gather_sqlite_diagnostics` expuesta en `app.db.sqliteplus` ahora
recoge métricas adicionales como el número de tablas disponibles y el tamaño del
fichero en disco, lo que facilita instrumentar paneles de observabilidad o
alertas proactivas.

El configurador `app.db.manager.DatabaseConfigurator` crea instancias de
SQLAlchemy optimizadas para motores SQL populares y proveedores externos:

- **SQLite:** usa `sqliteplus-enhanced` para cifrado y mantenimiento, desactiva
  el pool compartido con `NullPool` para evitar bloqueos y mantiene la
  compatibilidad con `:memory:`.
- **PostgreSQL / Amazon Redshift:** admite `statement_timeout`,
  `application_name` y opciones TLS (`sslmode`, `sslrootcert`) para integrarse
  con Supabase, Render, Aurora u otros servicios gestionados.
- **MySQL / MariaDB:** aplica automáticamente `pool_recycle` para respetar el
  `wait_timeout` típico de PlanetScale, HeatWave o Azure Database.
- **SQL Server:** añade soporte de `application_name` y mantiene un espacio para
  ampliar credenciales u opciones `ODBC` personalizadas.
- **Oracle Database:** inicializa sesiones mediante `DBMS_APPLICATION_INFO` para
  etiquetar la aplicación y opera con `NullPool`, evitando conflictos con pools
  corporativos existentes.
- **Snowflake:** transmite `application` y ajusta `STATEMENT_TIMEOUT_IN_SECONDS`
  usando los parámetros de configuración estándar del proyecto.
- **Trino, Databricks SQL, ClickHouse (HTTP) y Google BigQuery:** desactivan el
  pool de conexiones y, cuando es posible, propagan `application_name` mediante
  un `SET` estándar, habilitando integraciones con API SQL accesibles por HTTP.

El configurador expone el método `register_backend` para integrar otros motores
(CockroachDB, TiDB, servicios REST propietarios, etc.) sin modificar el núcleo
del proyecto. Puedes consultar los backends registrados en tiempo de ejecución
con `DatabaseConfigurator.available_backends()` y ajustar los parámetros genéricos
de pool (`pool_size`, `max_overflow`, `pool_timeout`, `pool_recycle`,
`pool_pre_ping`, `echo`) desde el archivo `.env`.

### Integraciones con APIs y bases de datos externas

El módulo `app.db.external` centraliza los conectores hacia servicios de
terceros. Expone clientes HTTP reutilizables (`RESTAPIClient` y
`GraphQLAPIClient`) basados en `httpx`, que admiten cabeceras personalizadas,
timeouts configurables y `MockTransport` para pruebas unitarias sin depender de
la red. El registro `ExternalIntegrationManager` permite consultar en tiempo de
ejecución las APIs disponibles y cerrarlas cuando ya no se necesitan.

Para bases de datos externas se introdujo `ThirdPartyDatabaseRegistry`, un
registro extensible con factorías para los motores NoSQL y de analytics más
habituales: MongoDB, Redis, Cassandra, Elasticsearch, DynamoDB e InfluxDB.
Cada entrada verifica la presencia de sus dependencias opcionales y ofrece
mensajes claros en caso de que falten paquetes como `pymongo` o `redis`.

La configuración se controla mediante tres estructuras JSON leídas por
`pydantic`:

- `EXTERNAL_API_ENDPOINTS`: diccionario de APIs REST (`base_url`, `headers`,
  `timeout`, credenciales opcionales).
- `GRAPHQL_API_ENDPOINTS`: endpoints GraphQL (`endpoint`, cabeceras, timeout y
  autenticación).
- `THIRD_PARTY_DATABASES`: conexiones NoSQL (`driver`, `url` y parámetros
  adicionales).

Estas colecciones se cargan automáticamente al inicializar la API (`app.api.deps`)
gracias a `external_integrations.configure_from_settings(settings)`, manteniendo
un repositorio centralizado de recursos externos listo para consumo desde los
servicios o tasks del proyecto.
