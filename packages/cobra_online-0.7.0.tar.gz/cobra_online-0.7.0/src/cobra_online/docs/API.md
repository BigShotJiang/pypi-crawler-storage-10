# Documentación de la API

La API de Cobra_Online sigue el prefijo `{{base_url}}/api/v1`.

## Autenticación

Las rutas de catálogo requieren la cabecera `X-API-Key` cuando en la configuración
del servicio (`API_KEYS`) se han definido claves. Si el listado está vacío, la API
permanece abierta. Un ejemplo de encabezado sería:

```http
X-API-Key: mi-clave-super-segura
```

El endpoint de salud no necesita autenticación para facilitar la monitorización.

> **Nota de seguridad:** Las API keys administradas mediante la API se almacenan
> utilizando un HMAC con el secreto maestro definido en la variable de entorno
> `API_KEY_MASTER_SECRET`. Cambia este valor en despliegues reales para garantizar
> que las huellas almacenadas no puedan ser reproducidas por terceros.

## Endpoints disponibles

### Salud del servicio

- **GET `/health/`**
  - **Descripción:** Devuelve información básica del estado del servicio.
  - **Query params opcionales:** `lang` (cadena ISO 639-1) para forzar el idioma de la respuesta. También se respeta la cabecera estándar `Accept-Language`.
  - **Idiomas disponibles:** español (`es`), inglés (`en`) y portugués (`pt`).
  - **Respuesta 200:**
    ```json
    {
      "status": "ok",
      "service": "Cobra Online API",
      "timestamp": "2025-01-01T00:00:00.000000+00:00",
      "locale": "es",
      "message": "Servicio operativo. Cobra_Online responde correctamente.",
      "documentation_url": "https://github.com/cobra-online/cobra_online/blob/main/docs/README.md"
    }
    ```
- **GET `/health/metrics`**
  - **Descripción:** Expone métricas agregadas para monitoreo y validaciones de carga.
  - **Query params opcionales:** `expiring_within_days` (entero, entre 1 y 90, por defecto 7) para ajustar el umbral de expiración de API keys consideradas, y `lang` para seleccionar el idioma de los textos auxiliares.
  - **Idiomas disponibles:** español (`es`), inglés (`en`) y portugués (`pt`).
  - **Respuesta 200:**
    ```json
    {
      "timestamp": "2025-01-01T00:00:00.000000+00:00",
      "resources": {
        "storage_buckets": 4,
        "compute_instances": 6,
        "database_instances": 2,
        "network_load_balancers": 3,
        "analytics_pipelines": 5,
        "ml_models": 4
      },
      "api_keys": {
        "total": 8,
        "active": 6,
        "revoked": 2,
        "expiring_soon": 1
      },
      "locale": "es",
      "summary": "Resumen agregado de recursos, API keys y su ventana de expiración configurable.",
      "documentation_url": "https://github.com/cobra-online/cobra_online/blob/main/docs/README.md"
    }
    ```

### Almacenamiento de objetos

Prefijo: `/storage/buckets/`

- **GET `/`**
  - **Descripción:** Lista todos los buckets registrados. Admite filtros opcionales.
  - **Query params opcionales:** `region` (cadena) y `name` (cadena en minúsculas).
  - **Respuesta 200:**
    ```json
    [
      {
        "id": 1,
        "name": "datos-criticos",
        "region": "us-east-1",
        "description": "Backups principales",
        "created_at": "2025-01-01T00:00:00.000000+00:00"
      }
    ]
    ```
- **GET `/{bucket_id}`**
  - **Descripción:** Recupera la información de un bucket específico.
  - **Respuesta 200:**
    ```json
    {
      "id": 1,
      "name": "datos-criticos",
      "region": "us-east-1",
      "description": "Backups principales",
      "created_at": "2025-01-01T00:00:00.000000+00:00"
    }
    ```
  - **Respuesta 404:** Se devuelve cuando el identificador no existe.
- **PATCH `/{bucket_id}`**
  - **Descripción:** Actualiza los metadatos de un bucket existente.
  - **Cuerpo de solicitud:**
    ```json
    {
      "region": "us-east-2",
      "description": "Backups secundarios"
    }
    ```
  - **Respuesta 200:** Objeto del bucket actualizado.
  - **Respuesta 404:** Se devuelve cuando el identificador no existe.
  - **Respuesta 409:** Se devuelve cuando el nuevo nombre ya existe.
- **POST `/`**
  - **Descripción:** Crea un bucket nuevo. Los nombres deben ser únicos y estar en minúsculas.
  - **Cuerpo de solicitud:**
    ```json
    {
      "name": "datos-criticos",
      "region": "us-east-1",
      "description": "Backups principales"
    }
    ```
  - **Respuesta 201:** Objeto del bucket recién creado.
  - **Respuesta 409:** Se devuelve cuando el nombre ya existe.
- **DELETE `/{bucket_id}`**
  - **Descripción:** Elimina un bucket existente.
  - **Respuesta 204:** Se devuelve cuando la eliminación se completa.
  - **Respuesta 404:** Se devuelve cuando el identificador no existe.

### Servicios de cómputo

Prefijo: `/compute/instances/`

- **GET `/`**
  - **Descripción:** Lista las instancias virtuales registradas. Admite filtros opcionales.
  - **Query params opcionales:** `region`, `status`, `image` y `name`.
  - **Respuesta 200:**
    ```json
    [
      {
        "id": 1,
        "name": "worker-01",
        "image": "ubuntu-22-04-lts",
        "region": "us-east-1",
        "vcpus": 4,
        "memory_gb": 16,
        "status": "provisioning",
        "created_at": "2025-01-01T00:00:00.000000+00:00"
      }
    ]
    ```
- **GET `/{instance_id}`**
  - **Descripción:** Recupera la información de una instancia específica.
  - **Respuesta 200:** Objeto de la instancia solicitada.
  - **Respuesta 404:** Se devuelve cuando el identificador no existe.
- **PATCH `/{instance_id}`**
  - **Descripción:** Actualiza parcialmente una instancia de cómputo existente.
  - **Cuerpo de solicitud:**
    ```json
    {
      "vcpus": 8,
      "status": "running"
    }
    ```
  - **Respuesta 200:** Objeto de la instancia actualizada.
  - **Respuesta 404:** Se devuelve cuando el identificador no existe.
  - **Respuesta 409:** Se devuelve cuando el nuevo nombre ya existe.
- **POST `/`**
  - **Descripción:** Registra una instancia nueva. El nombre debe ser único.
  - **Cuerpo de solicitud:**
    ```json
    {
      "name": "worker-01",
      "image": "ubuntu-22-04-lts",
      "region": "us-east-1",
      "vcpus": 4,
      "memory_gb": 16
    }
    ```
  - **Respuesta 201:** Objeto de la instancia recién creada.
  - **Respuesta 409:** Se devuelve cuando el nombre ya existe.
- **DELETE `/{instance_id}`**
  - **Descripción:** Elimina una instancia registrada.
  - **Respuesta 204:** Se devuelve cuando la eliminación se completa.
  - **Respuesta 404:** Se devuelve cuando el identificador no existe.

### Bases de datos administradas

Prefijo: `/databases/instances/`

- **GET `/`**
  - **Descripción:** Lista las instancias de bases de datos administradas. Admite filtros opcionales.
  - **Query params opcionales:** `engine`, `status`, `region` y `name`.
  - **Respuesta 200:**
    ```json
    [
      {
        "id": 1,
        "name": "analytics-cluster",
        "engine": "postgresql",
        "version": "15",
        "region": "us-east-1",
        "storage_gb": 100,
        "status": "available",
        "created_at": "2025-01-01T00:00:00.000000+00:00"
      }
    ]
    ```
- **GET `/{instance_id}`**
  - **Descripción:** Recupera la información de una instancia administrada específica.
  - **Respuesta 200:** Objeto de la instancia solicitada.
  - **Respuesta 404:** Se devuelve cuando el identificador no existe.
- **PATCH `/{instance_id}`**
  - **Descripción:** Actualiza parcialmente una instancia administrada existente.
  - **Cuerpo de solicitud:**
    ```json
    {
      "storage_gb": 200,
      "status": "available"
    }
    ```
  - **Respuesta 200:** Objeto de la instancia actualizada.
  - **Respuesta 404:** Se devuelve cuando el identificador no existe.
  - **Respuesta 409:** Se devuelve cuando el nuevo nombre ya existe.
- **POST `/`**
  - **Descripción:** Registra una instancia administrada nueva. Los nombres deben ser únicos, en minúsculas y con guiones.
  - **Cuerpo de solicitud:**
    ```json
    {
      "name": "analytics-cluster",
      "engine": "postgresql",
      "version": "15",
      "region": "us-east-1",
      "storage_gb": 100
    }
    ```
    El atributo `status` es opcional y por defecto queda en `provisioning`.
  - **Respuesta 201:** Objeto de la instancia recién creada.
  - **Respuesta 409:** Se devuelve cuando el nombre ya existe.
- **DELETE `/{instance_id}`**
  - **Descripción:** Elimina una instancia administrada registrada.
  - **Respuesta 204:** Se devuelve cuando la eliminación se completa.
  - **Respuesta 404:** Se devuelve cuando el identificador no existe.

#### Motores soportados y configuración

La API utiliza el nuevo `DatabaseConfigurator` interno para detectar el motor de
base de datos a partir de la variable `DATABASE_URL` y aplicar ajustes
especializados:

- **SQLite (`sqlite://`)** es el valor predeterminado. Usa
  `sqliteplus-enhanced` para cifrado opcional (`SQLITE_ENCRYPTION_KEY`) y permite
  ajustar el mantenimiento (`SQLITE_AUTO_OPTIMIZE`, `SQLITE_WAL_CHECKPOINT`,
  `SQLITE_VACUUM_ON_STARTUP`, `SQLITE_INTEGRITY_CHECK`). Los asistentes
  `fetchone`, `fetchmany`, `stream_query`, `execute_many` y `transaction()` del
  helper `SQLitePlusDatabase` cubren lecturas incrementales, cargas masivas y
  transacciones seguras, mientras que `log_action`/`fetch_logs` facilitan
  auditoría ligera sobre la base predeterminada.
- **PostgreSQL (`postgresql+psycopg://`)** añade soporte para `DATABASE_SSL_MODE`,
  `DATABASE_SSL_ROOT_CERT`, `DATABASE_STATEMENT_TIMEOUT_MS` y
  `DATABASE_APPLICATION_NAME` para integrarse con servicios como Railway, Heroku
  o Neon.
- **MySQL/MariaDB (`mysql://`, `mysql+pymysql://`, `mariadb://`)** aplica un
  `pool_recycle` compatible con PlanetScale, Aiven o RDS MySQL.
- **SQL Server (`mssql://`)** replica la cabecera `application_name` y puede
  ampliarse mediante `register_backend` para proveedores como Azure SQL o
  Babelfish.

Las opciones de pool (`DATABASE_POOL_SIZE`, `DATABASE_MAX_OVERFLOW`,
`DATABASE_POOL_TIMEOUT`, `DATABASE_POOL_RECYCLE`, `DATABASE_POOL_PRE_PING`) están
disponibles para cualquier backend soportado y se definen en el `.env` del
backend.

Además, `external_integrations.configure_from_settings(settings)` carga y expone
APIs y bases de datos externas declaradas en `EXTERNAL_API_ENDPOINTS`,
`GRAPHQL_API_ENDPOINTS` y `THIRD_PARTY_DATABASES`. Cada entrada acepta formato
JSON y activa clientes reutilizables basados en `httpx`, así como factorías para
MongoDB, Redis, Cassandra, Elasticsearch, DynamoDB o InfluxDB.

### Servicios de red

Prefijo: `/network/load-balancers/`

- **GET `/`**
  - **Descripción:** Lista los balanceadores de carga registrados. Admite filtros opcionales.
  - **Query params opcionales:** `protocol`, `status`, `region` y `name`.
  - **Respuesta 200:**
    ```json
    [
      {
        "id": 1,
        "name": "edge-balancer",
        "protocol": "http",
        "port": 80,
        "region": "us-east-1",
        "status": "provisioning",
        "created_at": "2025-01-01T00:00:00.000000+00:00"
      }
    ]
    ```
- **GET `/{load_balancer_id}`**
  - **Descripción:** Recupera la información de un balanceador específico.
  - **Respuesta 200:** Objeto del balanceador solicitado.
  - **Respuesta 404:** Se devuelve cuando el identificador no existe.
- **PATCH `/{load_balancer_id}`**
  - **Descripción:** Actualiza parcialmente un balanceador de carga existente.
  - **Cuerpo de solicitud:**
    ```json
    {
      "port": 8080,
      "status": "active"
    }
    ```
  - **Respuesta 200:** Objeto del balanceador actualizado.
  - **Respuesta 404:** Se devuelve cuando el identificador no existe.
  - **Respuesta 409:** Se devuelve cuando el nuevo nombre ya existe.
- **POST `/`**
  - **Descripción:** Crea un balanceador nuevo. Los nombres deben ser únicos y estar en minúsculas.
  - **Cuerpo de solicitud:**
    ```json
    {
      "name": "edge-balancer",
      "protocol": "https",
      "port": 443,
      "region": "us-east-1"
    }
    ```
    El atributo `status` es opcional y por defecto queda en `provisioning`.
  - **Respuesta 201:** Objeto del balanceador recién creado.
  - **Respuesta 409:** Se devuelve cuando el nombre ya existe.
- **DELETE `/{load_balancer_id}`**
  - **Descripción:** Elimina un balanceador de carga existente.
  - **Respuesta 204:** Se devuelve cuando la eliminación se completa.
  - **Respuesta 404:** Se devuelve cuando el identificador no existe.

### Pipelines de análisis de datos

Prefijo: `/analytics/pipelines/`

- Motores soportados: `spark`, `dask` y `nifi`.
- Modos disponibles: `batch` y `streaming`.

- **GET `/`**
  - **Descripción:** Lista los pipelines de análisis registrados. Admite filtros opcionales.
  - **Query params opcionales:** `engine`, `status`, `mode` y `name`.
  - **Respuesta 200:**
    ```json
    [
      {
        "id": 1,
        "name": "daily-etl",
        "engine": "spark",
        "mode": "batch",
        "schedule": "0 2 * * *",
        "description": "Ingesta nocturna",
        "status": "draft",
        "created_at": "2025-01-01T00:00:00.000000+00:00"
      }
    ]
    ```
- **GET `/summary`**
  - **Descripción:** Devuelve métricas agregadas del catálogo de pipelines.
  - **Respuesta 200:**
    ```json
    {
      "total": 5,
      "by_status": {
        "draft": 3,
        "completed": 2
      },
      "by_engine": {
        "spark": 3,
        "dask": 1,
        "nifi": 1
      },
      "by_mode": {
        "batch": 3,
        "streaming": 2
      }
    }
    ```
- **GET `/{pipeline_id}`**
  - **Descripción:** Recupera la información de un pipeline específico.
  - **Respuesta 200:** Objeto del pipeline solicitado.
  - **Respuesta 404:** Se devuelve cuando el identificador no existe.
- **PATCH `/{pipeline_id}`**
  - **Descripción:** Actualiza parcialmente un pipeline existente.
  - **Cuerpo de solicitud:**
    ```json
    {
      "schedule": "15 2 * * *",
      "status": "scheduled",
      "mode": "streaming"
    }
    ```
  - **Respuesta 200:** Objeto del pipeline actualizado.
  - **Respuesta 404:** Se devuelve cuando el identificador no existe.
  - **Respuesta 409:** Se devuelve cuando el nuevo nombre ya existe.
- **POST `/`**
  - **Descripción:** Crea un pipeline nuevo. Los nombres deben ser únicos y contener solo minúsculas y guiones.
  - **Cuerpo de solicitud:**
    ```json
    {
      "name": "daily-etl",
      "engine": "spark",
      "schedule": "0 2 * * *",
      "description": "Ingesta nocturna",
      "mode": "batch"
    }
    ```
    Los atributos `status` y `mode` son opcionales; sus valores predeterminados son `draft` y `batch`, respectivamente.
  - **Respuesta 201:** Objeto del pipeline recién creado.
  - **Respuesta 409:** Se devuelve cuando el nombre ya existe.
- **DELETE `/{pipeline_id}`**
  - **Descripción:** Elimina un pipeline de análisis existente.
  - **Respuesta 204:** Se devuelve cuando la eliminación se completa.
  - **Respuesta 404:** Se devuelve cuando el identificador no existe.

### Modelos de IA/ML

Prefijo: `/ml/models/`

- **GET `/`**
  - **Descripción:** Lista los modelos de IA/ML registrados. Admite filtros opcionales.
  - **Query params opcionales:** `framework`, `status` y `name` (exacto, en minúsculas).
  - **Respuesta 200:**
    ```json
    [
      {
        "id": 1,
        "name": "fraud-detector",
        "framework": "pytorch",
        "version": "v1",
        "description": "Modelo para detección de fraude",
        "endpoint_url": "https://ml.cobra/api/fraud-detector",
        "status": "ready",
        "last_trained_at": "2025-01-01T10:00:00+00:00",
        "created_at": "2025-01-01T00:00:00+00:00",
        "updated_at": "2025-01-01T00:00:00+00:00"
      }
    ]
    ```
- **GET `/summary`**
  - **Descripción:** Devuelve métricas agregadas del catálogo de modelos.
  - **Respuesta 200:**
    ```json
    {
      "total": 3,
      "by_status": {
        "draft": 1,
        "ready": 1,
        "training": 1
      },
      "by_framework": {
        "pytorch": 1,
        "scikit-learn": 1,
        "tensorflow": 1
      }
    }
    ```
- **GET `/{model_id}`**
  - **Descripción:** Recupera la información de un modelo específico.
  - **Respuesta 200:** Objeto del modelo solicitado.
  - **Respuesta 404:** Se devuelve cuando el identificador no existe.
- **POST `/`**
  - **Descripción:** Registra un modelo nuevo. Los nombres deben ser únicos y en minúsculas.
  - **Cuerpo de solicitud:**
    ```json
    {
      "name": "fraud-detector",
      "framework": "pytorch",
      "version": "v1",
      "description": "Modelo para detección de fraude",
      "endpoint_url": "https://ml.cobra/api/fraud-detector"
    }
    ```
  - **Respuesta 201:** Objeto del modelo recién creado.
  - **Respuesta 409:** Se devuelve cuando el nombre ya existe.
- **PATCH `/{model_id}`**
  - **Descripción:** Actualiza parcialmente un modelo existente.
  - **Cuerpo de solicitud:**
    ```json
    {
      "status": "training",
      "last_trained_at": "2025-01-15T09:30:00+00:00"
    }
    ```
  - **Respuesta 200:** Objeto del modelo actualizado.
  - **Respuesta 404:** Se devuelve cuando el identificador no existe.
  - **Respuesta 409:** Se devuelve cuando el nuevo nombre ya existe.
- **DELETE `/{model_id}`**
  - **Descripción:** Elimina un modelo registrado.
  - **Respuesta 204:** Se devuelve cuando la eliminación se completa.
  - **Respuesta 404:** Se devuelve cuando el identificador no existe.

### Seguridad de la API

Prefijo: `/security/api-keys/`

- **GET `/`**
  - **Descripción:** Lista las API keys administradas, mostrando sus metadatos (prefijo, fecha de creación, expiración y último uso).
  - **Respuesta 200:**
    ```json
    [
      {
        "id": 1,
        "name": "token-ci",
        "key_prefix": "abcd1234wxyz",
        "created_at": "2025-01-01T00:00:00+00:00",
        "expires_at": null,
        "last_used_at": "2025-01-01T12:00:00+00:00",
        "revoked": false
      }
    ]
    ```
- **POST `/`**
  - **Descripción:** Crea una API key nueva almacenando únicamente su huella criptográfica. El valor completo solo se muestra en esta respuesta.
  - **Cuerpo de solicitud:**
    ```json
    {
      "name": "token-ci",
      "expires_at": "2025-12-31T23:59:59+00:00"
    }
    ```
  - **Respuesta 201:**
    ```json
    {
      "id": 1,
      "name": "token-ci",
      "key_prefix": "abcd1234wxyz",
      "created_at": "2025-01-01T00:00:00+00:00",
      "expires_at": "2025-12-31T23:59:59+00:00",
      "last_used_at": null,
      "revoked": false,
      "secret": "abcd1234wxyz..."
    }
    ```
- **POST `/{api_key_id}/revoke`**
  - **Descripción:** Revoca una API key existente para impedir futuros accesos.
  - **Respuesta 200:** Devuelve los metadatos actualizados de la API key revocada.
  - **Respuesta 404:** Se devuelve cuando el identificador no existe.
  - **Respuesta 409:** Se devuelve cuando la API key ya había sido revocada.
