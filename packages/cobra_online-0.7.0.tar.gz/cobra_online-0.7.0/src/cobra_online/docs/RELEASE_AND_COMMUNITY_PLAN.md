# Plan de lanzamientos y crecimiento de la comunidad

Este documento describe el calendario de versiones previsto para Cobra_Online y
las iniciativas comunitarias que darán soporte a la fase de mantenimiento
continuo definida en el roadmap del proyecto.

## Calendario de lanzamientos

El objetivo es mantener un ritmo estable que permita a la comunidad planificar
migraciones y validar nuevas funcionalidades con antelación. Cada hito incluye
una ventana de _feature freeze_ para garantizar la estabilidad.

| Versión | Ventana estimada | Objetivos principales |
| --- | --- | --- |
| **v0.5.0 – Beta pública** | Mes 9 desde el arranque del proyecto | Publicación oficial del repositorio, documentación mínima para despliegues y habilitación del seguimiento de incidencias. |
| **v0.6.0 – Beta mejorada** | Mes 10-11 | Iteraciones rápidas sobre el feedback recibido: mejoras de UX en el dashboard, ampliación de pruebas automatizadas y estabilización de pipelines de datos. |
| **v1.0.0 – GA (General Availability)** | Mes 12 | Conjunto completo de servicios básicos (almacenamiento, cómputo, bases de datos, IA/ML) con documentación exhaustiva y ejemplos de uso listos para producción. |
| **v1.1.x – Mantenimiento** | Cada 6 semanas | Corrección de errores priorizados por la comunidad y pequeñas mejoras de rendimiento. |
| **v1.2.0 y posteriores** | Cada 3-4 meses | Nuevas capacidades avanzadas (integraciones externas, automatizaciones adicionales e internacionalización extendida). |

### Flujo para nuevas versiones

1. **Planificación** (2 semanas antes): definición del alcance y responsables.
2. **Implementación**: desarrollo y revisión de PRs siguiendo la guía de
   contribución.
3. **Congelación de características** (1 semana antes): solo se aceptan
   correcciones de errores críticos.
4. **Publicación**: generación de changelog, etiqueta en Git y anuncio en los
   canales comunitarios.
5. **Soporte post-lanzamiento**: seguimiento activo de incidencias durante 2
   semanas tras cada lanzamiento mayor.

## Crecimiento de la comunidad

La adopción del proyecto depende de una comunidad activa y bien informada. Las
siguientes acciones permiten consolidar dicho ecosistema.

### Canales oficiales

Los canales activos y las pautas de gobernanza se documentan de forma centralizada
en [`docs/COMMUNITY.md`](COMMUNITY.md). A continuación se resume su propósito:

- **GitHub Discussions**: espacio principal para soporte técnico, propuestas y
  debates sobre la hoja de ruta.
- **Servidor de Discord**: coordinación en tiempo real para sesiones de
  co-creación, _bug bashes_ y anuncios rápidos.
- **Boletín mensual**: resumen de novedades, roadmap y convocatoria a eventos.

### Actividades recurrentes

- **Reunión abierta mensual**: presentación del estado del proyecto, demos y
  espacio para preguntas.
- **Hackathons trimestrales**: enfoque en funcionalidades priorizadas por la
  comunidad.
- **Programa de _mentoring_**: acompañamiento a nuevos contribuidores durante
  su primer PR.

### Indicadores de éxito

- Tiempo medio de respuesta en issues y discusiones menor a 72 horas.
- Crecimiento mensual del 15 % en participantes activos en los canales.
- Al menos dos contribuciones externas aceptadas por ciclo de lanzamiento.

## Próximos pasos

1. Configurar los canales descritos (Discussions, Discord y boletín) antes de la
   publicación de la versión Beta.
2. Documentar en el repositorio los procesos de gobernanza comunitaria
   (moderación, plantillas para eventos y recopilación de feedback).
3. Revisar y ajustar el calendario de lanzamientos cada seis meses según la
   capacidad del equipo y el interés de la comunidad.
