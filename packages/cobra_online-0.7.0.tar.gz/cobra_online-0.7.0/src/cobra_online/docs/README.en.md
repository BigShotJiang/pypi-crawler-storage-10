# Cobra_Online

Cobra_Online is an open-source cloud and Big Data platform inspired by providers
such as AWS, Azure and GCP. It delivers a scalable, modular and multi-platform
solution that can be deployed on bare metal servers, virtual machines or public
cloud infrastructure.

## Features

- **Object Storage** (S3-compatible)
- **Virtual Compute** services
- **Managed Databases** (SQL/NoSQL)
- **Big Data Analytics** (ETL orchestration with Spark/Dask)
- **Artificial Intelligence and Machine Learning** workflows
- **Model management** (registry, tracking and endpoint publishing)
- **Networking services**

## Goal

The project aims to democratise advanced cloud and Big Data capabilities,
enabling anybody to run the ecosystem on the infrastructure of their choice.

## Contribute

Cobra_Online is open to contributions! Please check the Spanish contribution
guide in [`docs/CONTRIBUTING.md`](CONTRIBUTING.md).

> Looking for other languages? You can read the Spanish overview in
> [docs/README.md](README.md) and the Portuguese version in
> [docs/README.pt.md](README.pt.md).

## Run with Docker Compose

To quickly run the API together with a PostgreSQL database you can use the
`infra/docker-compose.yml` file.

1. Move to the `infra` folder and start the services:
   ```bash
   cd infra
   docker compose up --build
   ```
2. The API will be available at `http://localhost:8000`.
3. If you prefer to keep using SQLite, avoid setting `DATABASE_URL`. To work
   with PostgreSQL define `POSTGRES_DB`, `POSTGRES_USER`, `POSTGRES_PASSWORD`
   and `DATABASE_URL` before running `docker compose`.
4. When administering API keys through the platform override the
   `API_KEY_MASTER_SECRET` environment variable to customise the master secret
   used to store the keys encrypted at rest.

### Automated deployment script

The `infra/scripts/` directory includes the `deploy.sh` helper script which
bundles the most common tasks for the Docker Compose stack.

```bash
./infra/scripts/deploy.sh start   # Build and start the stack
./infra/scripts/deploy.sh stop    # Stop and remove the containers
./infra/scripts/deploy.sh logs    # Tail the combined API and database logs
./infra/scripts/deploy.sh status  # Check the current state of the services
```

When an `infra/.env` file exists (or the `COBRA_ENV_FILE` environment variable
points to a different location) the script will automatically load it before
invoking Docker Compose. This makes it easy to maintain environment-specific
configuration without repeating commands manually.

## Backend installation as a Python package

Inside the `backend/` folder the API can now be installed as a Python package
thanks to the `pyproject.toml` file. This simplifies distribution in
environments where Docker is not an option.

```bash
cd backend
pip install .
```

The package exposes the `cobra-online-api` command which starts the service
using the values configured in the `API_HOST` and `API_PORT` environment
variables.

## Internationalised health endpoints

Starting from this iteration the public health endpoints support the
`lang` query parameter and the standard `Accept-Language` header. Both
endpoints return additional metadata indicating the language used and a link to
further documentation in that language.

## Release and community plan

The continuous maintenance phase now has a documented release calendar and
community growth initiatives. See [`docs/RELEASE_AND_COMMUNITY_PLAN.md`](RELEASE_AND_COMMUNITY_PLAN.md)
for detailed milestones and next steps.

## Licence

This project is released under the Apache 2.0 License. See the
[`LICENSE`](../LICENSE) file for more information.

## SQLitePlus enhanced database layer

SQLite remains the default database engine, strengthened with the
[sqliteplus-enhanced](https://pypi.org/project/sqliteplus-enhanced/) package.
Connections managed by the API automatically apply optional encryption, tuning
`PRAGMA`s (`journal_mode`, `foreign_keys`, `busy_timeout`) and maintenance tasks
such as `PRAGMA optimize`, `wal_checkpoint` or `VACUUM`, all controlled through
environment variables. The helper class `SQLitePlusDatabase` groups common
operations (multi-statement scripts, database attachments, CSV exports, file
replication and on-demand backups) reusing the official sqliteplus APIs. New
methods were added to cover everyday workflows:

- `fetchone`, `fetchmany` and `stream_query` provide incremental reads without
  loading entire tables in memory.
- `execute_many` wraps efficient bulk operations and reports affected rows.
- `transaction()` exposes a safe context manager that automatically rolls back
  on exceptions.
- `log_action`, `fetch_logs` and `clear_logs` plug into the sqliteplus audit
  trail for lightweight observability.

The `gather_sqlite_diagnostics` helper now reports additional metrics including
table listings and on-disk size, making it easier to feed observability panels.

`app.db.manager.DatabaseConfigurator` has also been extended to provide tailored
SQLAlchemy engines for popular cloud providers:

- **SQLite** via sqliteplus-enhanced and `NullPool` to avoid locking issues.
- **PostgreSQL / Amazon Redshift** with support for `statement_timeout`,
  `application_name` and TLS parameters (`sslmode`, `sslrootcert`).
- **MySQL / MariaDB** with automatic `pool_recycle` to honour typical
  `wait_timeout` defaults.
- **SQL Server** adding `application_name` propagation.
- **Oracle Database** labelling sessions through `DBMS_APPLICATION_INFO` while
  delegating pooling to the upstream infrastructure.
- **Snowflake** forwarding the `application` attribute and configuring
  `STATEMENT_TIMEOUT_IN_SECONDS` from environment variables.
- **HTTP-based SQL providers** (Trino, Databricks SQL, ClickHouse HTTP, Google
  BigQuery) disabling connection pooling and attempting to propagate
  `application_name` via standard `SET` commands.

Custom providers can be registered at runtime through
`DatabaseConfigurator.register_backend(...)`, keeping the project open to REST
APIs or vendor-specific dialects without modifying the core modules.

### External APIs and third-party databases

`app.db.external` now centralises third-party integrations. Reusable HTTP
clients (`RESTAPIClient`, `GraphQLAPIClient`) built on top of `httpx` accept
custom headers, tuned timeouts and `MockTransport` objects, making unit tests
fully deterministic. The accompanying `ExternalIntegrationManager` keeps track
of available APIs and ensures clients are closed when no longer needed.

For external databases the new `ThirdPartyDatabaseRegistry` ships factory
implementations for popular NoSQL and analytics systems such as MongoDB, Redis,
Cassandra, Elasticsearch, DynamoDB and InfluxDB. Each driver validates the
presence of its optional dependency (`pymongo`, `redis`, etc.) and raises a
clear error if it is missing.

Three JSON-driven settings feed these registries:

- `EXTERNAL_API_ENDPOINTS` for REST APIs (`base_url`, headers, timeout and
  optional credentials).
- `GRAPHQL_API_ENDPOINTS` for GraphQL endpoints (`endpoint`, optional
  `base_url`, headers and timeout).
- `THIRD_PARTY_DATABASES` for NoSQL connectors (`driver`, `url` and additional
  options).

`external_integrations.configure_from_settings(settings)` is invoked during API
startup, providing a single source of truth for all external resources exposed
by Cobra Online.
