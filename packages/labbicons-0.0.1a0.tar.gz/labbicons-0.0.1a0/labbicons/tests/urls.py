"""URLs for testing."""

urlpatterns = []
