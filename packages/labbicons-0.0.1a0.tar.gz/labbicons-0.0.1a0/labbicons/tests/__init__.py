"""Tests for labbicons."""
