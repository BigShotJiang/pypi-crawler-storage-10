from pelican import signals
import requests

WIDGET_JS_URL = "https://www.skynettechnologies.com/accessibility/js/all-in-one-accessibility-js-widget-minify.js?"
API_SAVE_URL ="https://ada.skynettechnologies.us/api/widget-setting-update-platform"

config_cache = {}

# ==============================
# VALIDATE CONFIG
# ==============================

REQUIRED_CONFIG_KEYS = [
    "WIDGET_COLOR_CODE",
    "WIDGET_ICON_SIZE",
    "WIDGET_POSITION",
    "WIDGET_ICON_TYPE",
]

def validate_config(settings):
    # Only validate if plugin is enabled
    if not settings.get("ACCESSIBILITY_WIDGET_ENABLE", True):
        return  # Skip validation if disabled

    # Check for missing required keys
    missing = [key for key in REQUIRED_CONFIG_KEYS if not settings.get(key)]
    if missing:
        raise ValueError(f"Missing required config settings: {', '.join(missing)}")

    # Validate WIDGET_POSITION_RIGHT_PX
    if settings.get("ENABLE_WIDGET_CUSTOM_POSITION", False):
        right_px = settings.get("WIDGET_POSITION_RIGHT_PX", 0)
        if not (0 <= int(right_px) <= 250):
            raise ValueError("WIDGET_POSITION_RIGHT_PX must be between 0 and 250")

        bottom_px = settings.get("WIDGET_POSITION_BOTTOM_PX", 0)
        if not (0 <= int(bottom_px) <= 250):
            raise ValueError("WIDGET_POSITION_BOTTOM_PX must be between 0 and 250")

    # Validate WIDGET_ICON_SIZE_CUSTOM
    if settings.get("ENABLE_WIDGET_CUSTOM_SIZE", False):
        icon_size = settings.get("WIDGET_ICON_SIZE_CUSTOM", 0)
        if not (20 <= int(icon_size) <= 150):
            raise ValueError("WIDGET_ICON_SIZE_CUSTOM must be between 20 and 150")


# ==============================
# RENDER WIDGET SCRIPT
# ==============================
def render_widget_script():
    return f'<script id="aioa-adawidget" src="{WIDGET_JS_URL}"></script>'

# ==============================
# BUILD PAYLOAD TO PUSH
# ==============================
def build_payload(settings):
    domain = settings.get("SITEURL", "").strip()
    if not domain:
        raise ValueError("SITEURL must be set in pelicanconf.py")

    # Flags for optional behavior
    enable_widget_custom_position = settings.get('ENABLE_WIDGET_CUSTOM_POSITION', False)
    enable_widget_custom_size = settings.get('ENABLE_WIDGET_CUSTOM_SIZE', False)

    data = {
        "u": domain,
        "widget_color_code": settings.get('WIDGET_COLOR_CODE', ''),
        "is_widget_custom_position": int(enable_widget_custom_position),
        "is_widget_custom_size": int(enable_widget_custom_size),
    }

    # Icon positioning
    if not enable_widget_custom_position:
        data.update({
            "widget_position_top": 0,
            "widget_position_right": 0,
            "widget_position_bottom": 0,
            "widget_position_left": 0,
            "widget_position": settings.get('WIDGET_POSITION', 'bottom_right'),
        })
    else:
        # Positioning logic
        widget_position = {
            "widget_position_top": 0,
            "widget_position_right": 0,
            "widget_position_bottom": 0,
            "widget_position_left": 0,
        }

        # Horizontal alignment
        widget_position_right = settings.get('WIDGET_POSITION_RIGHT', '')
        widget_position_right_px = int(settings.get('WIDGET_POSITION_RIGHT_PX', '0'))

        if widget_position_right == "to_the_left":
            widget_position["widget_position_left"] = widget_position_right_px
        elif widget_position_right == "to_the_right":
            widget_position["widget_position_right"] = widget_position_right_px

        # Vertical alignment
        widget_position_bottom = settings.get('WIDGET_POSITION_BOTTOM', '')
        widget_position_bottom_px = int(settings.get('WIDGET_POSITION_BOTTOM_PX', '0'))

        if widget_position_bottom == "to_the_bottom":
            widget_position["widget_position_bottom"] = widget_position_bottom_px
        elif widget_position_bottom == "to_the_top":
            widget_position["widget_position_top"] = widget_position_bottom_px

        data.update(widget_position)
        data["widget_position"] = ""  

    # Icon size 
    if not enable_widget_custom_size:
        data.update({
            "widget_icon_size": settings.get('WIDGET_ICON_SIZE', ''),
            "widget_icon_size_custom": 0,
        })
    else:
        data.update({
            "widget_icon_size": "",
            "widget_icon_size_custom": int(settings.get('WIDGET_ICON_SIZE_CUSTOM', '0')),
        })

    # Widget size toggle (oversize = 1)
    widget_size_value = 1 if settings.get('WIDGET_SIZE', '') == 'oversize' else 0

    data.update({
        "widget_size": widget_size_value,
        "widget_icon_type": settings.get('WIDGET_ICON_TYPE', ''),
    })

    return data



# ==============================
# PUSH TO API
# ==============================
def push_to_api(settings):
    data = build_payload(settings)
    try:
        response = requests.post(API_SAVE_URL, data=data)
        response.raise_for_status()
    except requests.RequestException as e:
        if response is not None:
            try:
                error_content = response.json()
            except Exception:
                error_content = response.text
        else:
            error_content = str(e)

# ==============================
# INIT PLUGIN
# ==============================

api_pushed = False

def initialize_plugin(generator):
    global api_pushed

    settings = generator.settings
    # Inject script
    generator.env.globals["accessibility_widget_script"] = render_widget_script()

    # Only proceed with validation and API push if the plugin is explicitly enabled
    if not settings.get("ACCESSIBILITY_WIDGET_ENABLE", False):
        return

    # Validate required settings
    validate_config(settings)

    # Ensure API push runs only once
    if not api_pushed:
        push_to_api(settings)
        api_pushed = True

def register():
    """Register the plugin with Pelican."""
    signals.generator_init.connect(initialize_plugin)







