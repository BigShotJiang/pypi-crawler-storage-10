from .all_in_one_accessibility import register
