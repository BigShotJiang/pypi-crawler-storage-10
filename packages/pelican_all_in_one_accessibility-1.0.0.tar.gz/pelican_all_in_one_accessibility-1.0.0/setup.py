import io
from setuptools import setup, find_namespace_packages

with io.open('README.md', 'rt', encoding="utf8") as f:
    readme = f.read()

setup(
    name="pelican-all-in-one-accessibility",
    version="1.0.0",
    description="Website accessibility widget for improving WCAG 2.0, 2.1, 2.2 and ADA compliance!",
    author='Skynet Technologies USA LLC',
    author_email='developer3@skynettechnologies.com',
    license='BSD',
    long_description=readme,
    long_description_content_type='text/markdown',
    # url='',
    packages=find_namespace_packages(include=['pelican.plugins.*']),
    include_package_data=True,
    install_requires=[
        "pelican>=4.9.0",   
        "requests",         
    ],
    classifiers=[
        'Environment :: Web Environment',
        'Framework :: Pelican',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: BSD License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
        'Topic :: Internet :: WWW/HTTP',
        'Topic :: Software Development :: Libraries :: Python Modules',
    ],
    python_requires='>=3.9,<3.14',
)


