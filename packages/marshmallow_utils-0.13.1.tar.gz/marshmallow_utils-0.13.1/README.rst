..
    Copyright (C) 2020 CERN.

    Marshmallow-Utils is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

===================
 Marshmallow-Utils
===================

.. image:: https://img.shields.io/travis/inveniosoftware/marshmallow-utils.svg
        :target: https://travis-ci.org/inveniosoftware/marshmallow-utils

.. image:: https://img.shields.io/coveralls/inveniosoftware/marshmallow-utils.svg
        :target: https://coveralls.io/r/inveniosoftware/marshmallow-utils

.. image:: https://img.shields.io/github/tag/inveniosoftware/marshmallow-utils.svg
        :target: https://github.com/inveniosoftware/marshmallow-utils/releases

.. image:: https://img.shields.io/pypi/dm/marshmallow-utils.svg
        :target: https://pypi.python.org/pypi/marshmallow-utils

.. image:: https://img.shields.io/github/license/inveniosoftware/marshmallow-utils.svg
        :target: https://github.com/inveniosoftware/marshmallow-utils/blob/master/LICENSE

Extras and utilities for Marshmallow

Further documentation is available on
https://marshmallow-utils.readthedocs.io/
