"""Core database and models."""
