#!/bin/bash
# Xiang Wang(ramwin@qq.com)

redis-cli lpush image_tasks '{"url":"https://a.com/1.jpg","width":800}'
redis-cli lpush image_tasks '{"url":"https://bad.com/2.jpg","width":400}'
redis-cli lpush image_tasks '{"url":"https://c.com/3.jpg","width":600}'
