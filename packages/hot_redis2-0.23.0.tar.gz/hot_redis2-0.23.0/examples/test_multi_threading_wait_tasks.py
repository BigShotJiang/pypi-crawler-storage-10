#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Xiang Wang <ramwin@qq.com>

import logging
import redis
import time
from hot_redis.multi_threading_wait_tasks import RedisWorker

# 使用方自己配置日志
handlers=[logging.StreamHandler()]
handlers[0].setLevel(logging.INFO)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=handlers,
)

class ImageTaskWorker(RedisWorker[dict]):
    def parse_task(self, raw: str) -> dict:
        import json
        return json.loads(raw)

    def process_task(self, item: dict) -> None:
        url = item["url"]
        width = item["width"]
        logging.info("[Image] %s -> width=%s", url, width)
        time.sleep(2)
        if "bad" in url:
            logging.error("遇到处理错误的任务: %s", url)
            raise RuntimeError(f"Bad image: {url}")


if __name__ == "__main__":
    rc = redis.Redis(host="localhost", decode_responses=True)
    worker = ImageTaskWorker(redis_client=rc, queue_key="image_tasks")
    worker.run()  # 任何异常都会抛到最外层

