from __future__ import annotations

import logging
import os
import signal
import threading
import time
from concurrent.futures import ThreadPoolExecutor, Future
from typing import Generic, TypeVar, List

LOGGER = logging.getLogger(__name__)

T = TypeVar("T")


class RedisWorker(Generic[T]):
    """
    同步多线程 Redis 列表消费器（Redis ≥ 6.2，不兼容集群）
    1. redis_client 外部创建并传入
    2. 不配置日志
    3. 异常立即抛，已提交任务全部完成后退出
    4. 全程 debug 日志：任务内容、线程名、结果/异常
    """

    def __init__(
        self,
        redis_client,  # redis.Redis (>=6.2)
        queue_key: str,
        max_workers: int = 10,
    ) -> None:
        self.redis_client = redis_client
        self.queue_key = queue_key
        self.max_workers = max_workers

        self._sem = threading.Semaphore(max_workers)
        self._shutdown = False
        self._futures: List[Future[None]] = []

        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

    # ---------- 子类必须实现 ----------
    def parse_task(self, raw: str) -> T:
        raise NotImplementedError

    def process_task(self, item: T) -> None:
        raise NotImplementedError

    # ---------- 公共入口 ----------
    def run(self) -> None:
        LOGGER.debug("Worker started (PID=%s)", os.getpid())
        with ThreadPoolExecutor(max_workers=self.max_workers) as pool:
            while not self._shutdown:
                # ✅ 每轮必扫：异常立即抛，不依赖新任务
                done = [ff for ff in self._futures if ff.done()]
                for ff in done:
                    ff.result()
                    self._futures.remove(ff)

                if not self._sem.acquire(timeout=0.1):
                    continue

                # 裸调，异常直接抛
                result = self.redis_client.blpop(self.queue_key, timeout=1)
                if not result:
                    self._sem.release()
                    continue
                _, payload = result
                LOGGER.info("Got task: %s", payload)
                task = self.parse_task(payload)

                fut = pool.submit(self._worker_wrapper, task)
                self._futures.append(fut)

            LOGGER.debug("Stop taking new tasks; waiting for running ones...")
            for ff in self._futures[:]:
                ff.result()
            pool.shutdown(wait=True)
        LOGGER.debug("Worker finished")

    # ---------- 内部辅助 ----------
    def _worker_wrapper(self, item: T) -> None:
        try:
            LOGGER.debug(
                "[thread-%s] Start processing",
                threading.current_thread().name,
            )
            self.process_task(item)
            LOGGER.debug(
                "[thread-%s] Done",
                threading.current_thread().name,
            )
        except Exception as e:
            LOGGER.error(
                "[thread-%s] Exception: %s",
                threading.current_thread().name,
                e,
            )
            raise
        finally:
            self._sem.release()
        LOGGER.info("处理 %s 成功", item)

    def _signal_handler(self, sig, frame) -> None:
        LOGGER.info("Shutdown signal received")
        self._shutdown = True
