# stt-bench
cli utility for benchmarking transcription models on Indic Datasets
