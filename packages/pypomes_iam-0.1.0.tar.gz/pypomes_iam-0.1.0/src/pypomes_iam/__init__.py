from .jusbr_pomes import (
    jusbr_setup, jusbr_get_token, jusbr_set_scope
)
from .provider_pomes import (
    provider_register, provider_get_token
)

__all__ = [
    # jusbr_pomes
    "jusbr_setup", "jusbr_get_token", "jusbr_set_scope",
    # provider_pomes
    "provider_register", "provider_get_token"
]

from importlib.metadata import version
__version__ = version("pypomes_iam")
__version_info__ = tuple(int(i) for i in __version__.split(".") if i.isdigit())
