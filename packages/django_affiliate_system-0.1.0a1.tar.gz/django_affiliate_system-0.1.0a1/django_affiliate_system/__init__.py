from .__version__ import __version__

default_app_config = "django_affiliate_system.apps.DjangoAffiliateSystemConfig"

__all__ = ["__version__"]
