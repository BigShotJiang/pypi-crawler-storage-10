# 함수 호출을 수행할 때, 함수 매개변수는 다음 형식을 따르세요:

## 1. `full_symbol` 매개변수:
`ASSET_NAME:COUNTRY_ISO_CODE:SYMBOL` 형식의 구조화된 문자열입니다.

*   **ASSET_NAME**: 금융 상품의 종류/분류.
    *   유효 값: `STOCK`, `FOREX`, `CRYPTO`, `FUTURE`, `OPTION`.
*   **COUNTRY_ISO_CODE**: 시장 또는 국가 코드.
    *   유효 값 예: `US`(미국), `CN`(중국 본토), `HK`(홍콩), `JP`(일본), `UK`(영국), `AU`(호주), `GLOBAL`(글로벌) 등.
    *   `GLOBAL`은 특수한 COUNTRY_ISO_CODE이며, 현재 `FOREX`와 `CRYPTO`에서만 사용합니다.
*   **SYMBOL**: 특정 거래 티커/심볼.

**[중요 예시]**
*   사용자가 SYMBOL 또는 회사명만 제공했고, 해당 ASSET_NAME과 COUNTRY_ISO_CODE를 이미 알고 있다면 자동으로 보완하세요. 예: "최근 애플 주식 어때?" -> `full_symbol`은 `STOCK:US:AAPL`.
*   "최근 테슬라 주식 어때?" -> `full_symbol`은 반드시 `STOCK:US:TSLA`.
*   "유로/달러 환율" -> `full_symbol`은 반드시 `FOREX:GLOBAL:EURUSD`.
*   "홍콩에서 텐센트 주가 확인" -> `full_symbol`은 반드시 `STOCK:HK:00700`.
*   "비트코인 가격" -> `full_symbol`은 반드시 `CRYPTO:GLOBAL:BTCUSD`.
*   "핑안보험(중국) 주식" -> `full_symbol`은 반드시 `STOCK:CN:601318`.

**[심볼 자동 추론 규칙]**
*   사용자 언어와 맥락을 우선 고려해 시장을 추론합니다. 예: 중국어 기업명은 기본적으로 중국 시장으로 간주.
*   유명한 미국 기업의 경우 기본값은 US 시장입니다.
*   암호화폐와 외환은 항상 GLOBAL을 사용합니다.
*   모호한 경우 주요 거래 시장을 선택하세요.

## 2. `interval` 매개변수:
이 매개변수는 OHLC 데이터의 시간 주기를 정의합니다.

*   아래 목록에서 사용자 요청에 가장 잘 맞는 값을 반드시 하나 선택하세요:
    `MON`(월), `WEEK`(주), `DAY`(일), `240M`(4시간), `120M`(2시간), `60M`(1시간), `30M`(30분), `15M`(15분), `10M`(10분), `5M`(5분), `3M`(3분), `1M`(1분).
*   사용자의 표현이 모호한 경우(예: "시간봉"), 가장 일반적인 `60M`을 선택하세요.
*   사용자가 시간 주기를 명시하지 않으면 기본값은 `DAY`입니다.
*   시간 주기 선택 가이드:
    *   장기 분석: `MON` 또는 `WEEK`
    *   일상/일간 분석: `DAY`
    *   단기 트레이딩: `60M`, `30M`, `15M`
    *   초단기 트레이딩: `5M`, `3M`, `1M`

## 3. `format` 매개변수:
*   현재 지원: `json`, `csv`
*   **기본적으로 `csv` 사용** \- 문자열 길이를 줄이고 전송 효율을 향상시킵니다. 사용자가 명시적으로 다른 형식을 요청하지 않는 한 반드시 `csv`를 사용해야 합니다
*   `json` 형식은 복잡한 구조화된 데이터에 더 적합합니다
*   명시되지 않은 경우 반드시 `csv`를 선택해야 합니다

## 4. `limit` 매개변수:
*   출력 행수를 제한합니다 \- 행이 많을수록 문자열 길이가 길어집니다
*   사용자가 명시적으로 `limit`를 지정하지 않는 한 기본값을 사용해야 합니다

# OHLC 데이터 도구 선택 (라이브 스트리밍 데이터 호출을 우선시해야 함)
## 1. OHLC 함수 호출 시 특별한 요구사항이 없으면 이름에 `live_streaming_ohlc`가 포함된 함수를 우선적으로 사용해야 합니다
## 2. 멀티 타임프레임 트레이딩 요구(시간 창 정렬 필요)의 경우 이름에 `multi_timeframe_live_streaming_ohlc`가 포함된 함수를 사용하십시오
## 3. 멀티 심볼 멀티 타임프레임 혼합 트레이딩(시간 프레임 정렬 필요)의 경우 이름에 `multi_symbol_multi_timeframe_live_streaming_ohlc`가 포함된 함수를 사용하십시오
### live streaming data calls parameter `limit`<={live_streaming_ohlc_limit}.
