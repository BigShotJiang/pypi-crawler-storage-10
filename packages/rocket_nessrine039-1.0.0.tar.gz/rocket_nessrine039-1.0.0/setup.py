from setuptools import setup

setup(
   name='rocket-nessrine039',
   version='1.0.0',
   author='<Nessrine>',
   author_email='n.mehda@esi-sba.dz',
   py_modules=['rocket'],
   url='http://localhost/rocket',
   license='LICENSE.txt',
   description='A simple rocket simulator package',
   long_description=open('README.md').read(),
   long_description_content_type="text/markdown",
   install_requires=[],
)