from .detector import macs_detector
import matplotlib.pyplot as plt
import time
from typing import List, Optional, Tuple
import numpy as np


def _macs_cpd_base(
    series,
    window_sizes: List[int],
    n_perm: int = 300,
    alpha_q: float = 1.0,
    seed: int = 123,
    tol: Optional[int] = None,
    workers: Optional[int] = 8,
    backend: str = "thread",
    threshold: float = 0.5,
    change_type: str = "mean",   # "mean" | "var" | "meanvar"
    eps: float = 1e-12,
) -> Tuple[List[int], float]:
    """
    Core MACS CPD wrapper that screens with Wasserstein and refines by `change_type`,
    then filters by leader scores >= threshold.

    Returns 1-based indices of accepted change points and elapsed seconds.
    """
    if tol is None:
        tol = int(min(window_sizes))

    t0 = time.perf_counter()
    res = macs_detector(
        series=np.asarray(series, dtype=float),
        window_sizes=window_sizes,
        n_perm=n_perm,
        alpha_q=alpha_q,
        seed=seed,
        tol=tol,
        workers=workers,
        backend=backend,
        change_type=change_type,
        eps=eps,
    )

    # Till this point of the algorithm, we have been working with indices, but time series index starts at t=1
    cpts = [k + 1 for k, v in res["out"]["leaders_scores"].items() if v >= threshold]
    elapsed = time.perf_counter() - t0
    return cpts, elapsed


def macs_cpd_mean(
    series,
    window_sizes: List[int],
    n_perm: int = 300,
    alpha_q: float = 1.0,
    seed: int = 123,
    tol: Optional[int] = None,
    workers: Optional[int] = 8,
    backend: str = "thread",
    threshold: float = 0.5,
    eps: float = 1e-12,
):
    """
    Mean-shift refinement via CUSUM (default path).
    """
    return _macs_cpd_base(
        series=series,
        window_sizes=window_sizes,
        n_perm=n_perm,
        alpha_q=alpha_q,
        seed=seed,
        tol=tol,
        workers=workers,
        backend=backend,
        threshold=threshold,
        change_type="mean",
        eps=eps,
    )


def macs_cpd_var(
    series,
    window_sizes: List[int],
    n_perm: int = 300,
    alpha_q: float = 1.0,
    seed: int = 123,
    tol: Optional[int] = None,
    workers: Optional[int] = 8,
    backend: str = "thread",
    threshold: float = 0.5,
    eps: float = 1e-12,
):
    """
    Variance-change refinement (pooled mean; NLL-based).
    """
    return _macs_cpd_base(
        series=series,
        window_sizes=window_sizes,
        n_perm=n_perm,
        alpha_q=alpha_q,
        seed=seed,
        tol=tol,
        workers=workers,
        backend=backend,
        threshold=threshold,
        change_type="var",
        eps=eps,
    )


def macs_cpd_meanvar(
    series,
    window_sizes: List[int],
    n_perm: int = 300,
    alpha_q: float = 1.0,
    seed: int = 123,
    tol: Optional[int] = None,
    workers: Optional[int] = 8,
    backend: str = "thread",
    threshold: float = 0.5,
    eps: float = 1e-12,
):
    """
    Joint mean+variance-change refinement (segment-mean SSE; NLL-based).
    """
    return _macs_cpd_base(
        series=series,
        window_sizes=window_sizes,
        n_perm=n_perm,
        alpha_q=alpha_q,
        seed=seed,
        tol=tol,
        workers=workers,
        backend=backend,
        threshold=threshold,
        change_type="meanvar",
        eps=eps,
    )




def plot_detected_changepoints(series, cpts, title="Detected Change Points", figsize=(10, 4)):
    """
    Plot a time series with detected change points marked by vertical dashed lines.

    Parameters
    ----------
    series : array-like
        The input time series.
    cpts : list[int]
        Detected change point indices (0-based or 1-based).
    title : str, default="Detected Change Points"
        Title for the plot.
    figsize : tuple, default=(10, 4)
        Size of the matplotlib figure.
    """
    plt.style.use("seaborn-v0_8-whitegrid")
    plt.figure(figsize=figsize)

    # Plot series
    plt.plot(series, color="#1f77b4", lw=2, label="Series")

    # Mark change points
    for i, c in enumerate(cpts):
        plt.axvline(x=c, color="#d62728", linestyle="--", lw=1.8, alpha=0.8,
                    label="Change Point" if i == 0 else None)

    plt.title(title, fontsize=13, fontweight="semibold")
    plt.xlabel("Time Index", fontsize=11)
    plt.ylabel("Value", fontsize=11)
    plt.legend(frameon=True, loc="upper left")
    plt.tight_layout()
    plt.show()