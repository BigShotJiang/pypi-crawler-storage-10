import matplotlib.pyplot as plt

def plot_detected_changepoints(series, cpts, title="Detected Change Points", figsize=(10, 4)):
    """
    Plot a time series with detected change points marked by vertical dashed lines.

    Parameters
    ----------
    series : array-like
        The input time series.
    cpts : list[int]
        Detected change point indices (0-based or 1-based).
    title : str, default="Detected Change Points"
        Title for the plot.
    figsize : tuple, default=(10, 4)
        Size of the matplotlib figure.
    """
    plt.style.use("seaborn-v0_8-whitegrid")
    plt.figure(figsize=figsize)

    # Plot series
    plt.plot(series, color="#1f77b4", lw=2, label="Series")

    # Mark change points
    for i, c in enumerate(cpts):
        plt.axvline(x=c, color="#d62728", linestyle="--", lw=1.8, alpha=0.8,
                    label="Change Point" if i == 0 else None)

    plt.title(title, fontsize=13, fontweight="semibold")
    plt.xlabel("Time Index", fontsize=11)
    plt.ylabel("Value", fontsize=11)
    plt.legend(frameon=True, loc="upper left")
    plt.tight_layout()
    plt.show()