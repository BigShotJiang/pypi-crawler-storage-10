# Change Point Detection using Wasserstein Distance

macs-py is a change point detection method based on 1-wasserstein distance and permutation test to detect changes in mean, variance, and both mean and variance.\
For more information see the paper .................

#  MACS — Wasserstein-Adaptive Change-Point Detection

**MACS** is a fast, non-parametric change-point detection framework that uses  
1-Wasserstein distance and a permutation test for detecting shifts in mean, variance,  
or joint mean + variance using an ensemble model accross a set of assigned windows.

---

##  Installation

```bash
pip install macs-py
```

---

##  Overview

MACS detects change points in univariate time series using three refinement modes:

| Function | Detects | Refinement method |
|-----------|----------|------------------|
| `macs_cpd_mean()` | Mean shifts | CUSUM |
| `macs_cpd_var()` | Variance shifts | Negative Log Likelihood (NLL) |
| `macs_cpd_meanvar()` | Mean + variance shifts | Segment-specific NLL |

Each function combines:
1. Online change point detection method    
2. **Refinement** – localizes the change point using CUSUM or NLL minimization.  
3. **Voting / aggregation** – merges results across window sizes and reports the
most significant (“leader”) change points.

---

##  Quick Start Examples

Detect a **mean shift** in a univariate time series using `macs_cpd_mean()`.

```python
import numpy as np
from macs import macs_cpd_mean

# Generate synthetic data with a mean shift at t = 300
rng = np.random.default_rng(123)
n = 500
x = np.r_[rng.normal(0.0, 1.0, 300), rng.normal(2.0, 1.0, 200)]

# Run MACS Change Point Detection
cpts, elapsed = macs_cpd_mean(
    series=x,
    window_sizes=[30, 40, 50],
    n_perm=400,     
    alpha_q=1.0,    # 1% two-sided tail (as percent)
    seed=7,
    threshold=0.5
)

print("Detected change points (1-based):", cpts)
print(f"Elapsed time: {elapsed:.3f} seconds")
```

**Output (approximate):**
```
Detected change points (1-based): [301]
Elapsed time: 0.22 seconds
```

Detect a **variance shift** in a univariate time series using `macs_cpd_var()`.

```python
import numpy as np
from macs import macs_cpd_var

rng = np.random.default_rng(123)
n = 500

x = np.r_[rng.normal(0.0, 1.0, 300), rng.normal(0.0, 2.0, 200)]

cpts, elapsed = macs_cpd_var(
    series=x,
    window_sizes=[30, 40, 50],
    n_perm=400,
    alpha_q=1, 
    seed=7,
    threshold=0.5
)
print("CPs (1-based):", cpts, "elapsed:", round(elapsed, 3), "s")
```

**Output (approximate):**
```
Detected change points (1-based): [301]
Elapsed time: 0.22 seconds
```

Detect a  **shift in both mean and variance** in a univariate time series using `macs_cpd_meanvar()`.

```python
import numpy as np
from macs import macs_cpd_meanvar


rng = np.random.default_rng(91)
n = 450
# joint change at t=250: mean up, variance up
x = np.r_[rng.normal(0.0, 0.8, 250), rng.normal(1.0, 1.6, 200)]

cpts, elapsed = macs_cpd_meanvar(
    series=x,
    window_sizes=[24, 32, 40],
    n_perm=500,
    alpha_q=1.0,   
    threshold=0.50,
)
print("CPs (1-based):", cpts, "elapsed:", round(elapsed, 3), "s")
```
