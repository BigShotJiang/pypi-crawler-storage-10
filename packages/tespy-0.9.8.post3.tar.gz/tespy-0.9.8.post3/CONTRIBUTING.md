The developer rules can be found in the
[online documentation](https://tespy.readthedocs.io/).
