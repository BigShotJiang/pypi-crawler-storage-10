"""Sample tasks."""

from __future__ import annotations

from hud.samples.browser import BrowserTask

__all__ = ["BrowserTask"]
