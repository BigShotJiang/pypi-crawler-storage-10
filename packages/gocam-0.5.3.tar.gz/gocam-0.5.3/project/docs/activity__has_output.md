
# Slot: has_output

The output molecules that are directly produced by the activity

URI: [gocam:activity__has_output](https://w3id.org/gocam/activity__has_output)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [MoleculeAssociation](MoleculeAssociation.md)

## Parents


## Children


## Used by

 * [Activity](Activity.md)
