
# Slot: enabled_by

The gene product or complex that carries out the activity

URI: [gocam:activity__enabled_by](https://w3id.org/gocam/activity__enabled_by)


## Domain and Range

None &#8594;  <sub>0..1</sub> [EnabledByAssociation](EnabledByAssociation.md)

## Parents


## Children


## Used by

 * [Activity](Activity.md)
