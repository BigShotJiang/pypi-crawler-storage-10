
# Slot: predicate

The RO relation that represents the type of relationship

URI: [gocam:causalAssociation__predicate](https://w3id.org/gocam/causalAssociation__predicate)


## Domain and Range

None &#8594;  <sub>0..1</sub> [PredicateTermObject](PredicateTermObject.md)

## Parents


## Children


## Used by

 * [CausalAssociation](CausalAssociation.md)
