
# Slot: id

The identifier of the model. Should be in gocam namespace.

URI: [gocam:model__id](https://w3id.org/gocam/model__id)


## Domain and Range

None &#8594;  <sub>1..1</sub> [Uriorcurie](types/Uriorcurie.md)

## Parents


## Children


## Used by

 * [Model](Model.md)
