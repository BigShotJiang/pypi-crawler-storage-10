
# Slot: part_of

Optional extension allowing hierarchical nesting of BPs

URI: [gocam:biologicalProcessAssociation__part_of](https://w3id.org/gocam/biologicalProcessAssociation__part_of)


## Domain and Range

None &#8594;  <sub>0..1</sub> [BiologicalProcessAssociation](BiologicalProcessAssociation.md)

## Parents


## Children


## Used by

 * [BiologicalProcessAssociation](BiologicalProcessAssociation.md)
