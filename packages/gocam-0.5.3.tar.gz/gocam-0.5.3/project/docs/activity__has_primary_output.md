
# Slot: has_primary_output

The primary output molecule that is directly produced by the activity

URI: [gocam:activity__has_primary_output](https://w3id.org/gocam/activity__has_primary_output)


## Domain and Range

None &#8594;  <sub>0..1</sub> [MoleculeAssociation](MoleculeAssociation.md)

## Parents


## Children


## Used by

 * [Activity](Activity.md)
