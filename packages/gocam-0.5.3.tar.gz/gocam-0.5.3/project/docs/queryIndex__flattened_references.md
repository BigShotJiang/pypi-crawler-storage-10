
# Slot: flattened_references

All publication objects from the model across different levels combined in one place

URI: [gocam:queryIndex__flattened_references](https://w3id.org/gocam/queryIndex__flattened_references)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [PublicationObject](PublicationObject.md)

## Parents


## Children


## Used by

 * [QueryIndex](QueryIndex.md)
