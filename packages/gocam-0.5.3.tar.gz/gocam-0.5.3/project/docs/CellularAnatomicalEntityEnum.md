
# Enum: CellularAnatomicalEntityEnum

A term from the subset of the cellular anatomical entity branch of GO CC

URI: [gocam:CellularAnatomicalEntityEnum](https://w3id.org/gocam/CellularAnatomicalEntityEnum)


## Permissible Values

| Text | Description | Meaning | Other Information |
| :--- | :---: | :---: | ---: |
