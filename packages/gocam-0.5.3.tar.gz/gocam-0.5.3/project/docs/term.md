
# Slot: term

A generic slot for ontology terms

URI: [gocam:term](https://w3id.org/gocam/term)


## Domain and Range

None &#8594;  <sub>0..1</sub> [TermObject](TermObject.md)

## Parents


## Children


## Used by


## Other properties

|  |  |  |
| --- | --- | --- |
| **Mappings:** | | gocam:term |
