
# Slot: model_activity_molecular_function_terms

All MF terms for all activities

URI: [gocam:queryIndex__model_activity_molecular_function_terms](https://w3id.org/gocam/queryIndex__model_activity_molecular_function_terms)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [TermObject](TermObject.md)

## Parents


## Children


## Used by

 * [QueryIndex](QueryIndex.md)
