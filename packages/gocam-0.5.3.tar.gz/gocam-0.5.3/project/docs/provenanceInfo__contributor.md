
# Slot: contributor



URI: [gocam:provenanceInfo__contributor](https://w3id.org/gocam/provenanceInfo__contributor)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [ProvenanceInfo](ProvenanceInfo.md)

## Other properties

|  |  |  |
| --- | --- | --- |
| **Mappings:** | | dct:contributor |
