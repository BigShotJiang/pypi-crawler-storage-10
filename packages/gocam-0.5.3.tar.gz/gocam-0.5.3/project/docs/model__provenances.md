
# Slot: provenances

Model-level provenance information

URI: [gocam:model__provenances](https://w3id.org/gocam/model__provenances)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [ProvenanceInfo](ProvenanceInfo.md)

## Parents


## Children


## Used by

 * [Model](Model.md)
