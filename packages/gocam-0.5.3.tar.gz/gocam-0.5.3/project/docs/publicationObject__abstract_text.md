
# Slot: abstract_text



URI: [gocam:publicationObject__abstract_text](https://w3id.org/gocam/publicationObject__abstract_text)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [PublicationObject](PublicationObject.md)
