
# Slot: model_activity_part_of_closure

The reflexive transitive closure of `model_activity_part_of_terms`, over the is_a and part_of relationship type

URI: [gocam:queryIndex__model_activity_part_of_closure](https://w3id.org/gocam/queryIndex__model_activity_part_of_closure)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [TermObject](TermObject.md)

## Parents


## Children


## Used by

 * [QueryIndex](QueryIndex.md)
