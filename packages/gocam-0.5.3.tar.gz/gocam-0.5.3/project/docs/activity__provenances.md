
# Slot: provenances

Provenance information for the activity

URI: [gocam:activity__provenances](https://w3id.org/gocam/activity__provenances)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [ProvenanceInfo](ProvenanceInfo.md)

## Parents


## Children


## Used by

 * [Activity](Activity.md)
