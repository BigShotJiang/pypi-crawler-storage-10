
# Slot: full_text



URI: [gocam:publicationObject__full_text](https://w3id.org/gocam/publicationObject__full_text)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [PublicationObject](PublicationObject.md)
