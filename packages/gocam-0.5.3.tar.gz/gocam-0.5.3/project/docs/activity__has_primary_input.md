
# Slot: has_primary_input

The primary input molecule that is directly consumed by the activity

URI: [gocam:activity__has_primary_input](https://w3id.org/gocam/activity__has_primary_input)


## Domain and Range

None &#8594;  <sub>0..1</sub> [MoleculeAssociation](MoleculeAssociation.md)

## Parents


## Children


## Used by

 * [Activity](Activity.md)
