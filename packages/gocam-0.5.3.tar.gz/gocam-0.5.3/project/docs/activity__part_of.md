
# Slot: part_of

The larger biological process in which the activity is a part

URI: [gocam:activity__part_of](https://w3id.org/gocam/activity__part_of)


## Domain and Range

None &#8594;  <sub>0..1</sub> [BiologicalProcessAssociation](BiologicalProcessAssociation.md)

## Parents


## Children


## Used by

 * [Activity](Activity.md)
