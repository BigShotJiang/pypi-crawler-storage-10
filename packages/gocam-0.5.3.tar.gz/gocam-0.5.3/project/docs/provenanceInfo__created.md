
# Slot: created



URI: [gocam:provenanceInfo__created](https://w3id.org/gocam/provenanceInfo__created)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [ProvenanceInfo](ProvenanceInfo.md)

## Other properties

|  |  |  |
| --- | --- | --- |
| **Mappings:** | | dct:created |
