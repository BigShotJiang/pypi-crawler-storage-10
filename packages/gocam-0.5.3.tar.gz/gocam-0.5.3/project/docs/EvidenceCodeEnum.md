
# Enum: EvidenceCodeEnum

A term from the subset of ECO that maps up to a GAF evidence code

URI: [gocam:EvidenceCodeEnum](https://w3id.org/gocam/EvidenceCodeEnum)


## Permissible Values

| Text | Description | Meaning | Other Information |
| :--- | :---: | :---: | ---: |
