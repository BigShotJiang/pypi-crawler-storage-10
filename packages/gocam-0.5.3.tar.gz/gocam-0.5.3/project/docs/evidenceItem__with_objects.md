
# Slot: with_objects

Supporting database entities or terms

URI: [gocam:evidenceItem__with_objects](https://w3id.org/gocam/evidenceItem__with_objects)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [Object](Object.md)

## Parents


## Children


## Used by

 * [EvidenceItem](EvidenceItem.md)

## Other properties

|  |  |  |
| --- | --- | --- |
| **Aliases:** | | with |
|  | | with/from |
