
# Slot: part_of

A generic slot for part-of relationships

URI: [gocam:part_of](https://w3id.org/gocam/part_of)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by


## Other properties

|  |  |  |
| --- | --- | --- |
| **Mappings:** | | gocam:part_of |
