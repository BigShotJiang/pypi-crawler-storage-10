
# Slot: members

The gene products that are part of the complex

URI: [gocam:enabledByProteinComplexAssociation__members](https://w3id.org/gocam/enabledByProteinComplexAssociation__members)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [GeneProductTermObject](GeneProductTermObject.md)

## Parents


## Children


## Used by

 * [EnabledByProteinComplexAssociation](EnabledByProteinComplexAssociation.md)
