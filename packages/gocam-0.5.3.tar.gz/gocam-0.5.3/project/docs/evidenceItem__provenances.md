
# Slot: provenances

Provenance about the assertion, e.g. who made it

URI: [gocam:evidenceItem__provenances](https://w3id.org/gocam/evidenceItem__provenances)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [ProvenanceInfo](ProvenanceInfo.md)

## Parents


## Children


## Used by

 * [EvidenceItem](EvidenceItem.md)
