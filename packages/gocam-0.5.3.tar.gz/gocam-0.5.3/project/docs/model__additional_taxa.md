
# Slot: additional_taxa

Additional taxa that the model is about

URI: [gocam:model__additional_taxa](https://w3id.org/gocam/model__additional_taxa)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [TaxonTermObject](TaxonTermObject.md)

## Parents


## Children


## Used by

 * [Model](Model.md)
