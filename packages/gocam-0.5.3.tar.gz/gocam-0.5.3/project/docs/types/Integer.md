
# Type: integer

An integer

URI: [linkml:Integer](https://w3id.org/linkml/Integer)

|  |  |  |
| --- | --- | --- |
| Root (builtin) type | | **int** |

## Other properties

|  |  |  |
| --- | --- | --- |
| **Exact Mappings:** | | schema:Integer |
