
# Type: decimal

A real number with arbitrary precision that conforms to the xsd:decimal specification

URI: [linkml:Decimal](https://w3id.org/linkml/Decimal)

|  |  |  |
| --- | --- | --- |
| Root (builtin) type | | **Decimal** |

## Other properties

|  |  |  |
| --- | --- | --- |
| **Broad Mappings:** | | schema:Number |
