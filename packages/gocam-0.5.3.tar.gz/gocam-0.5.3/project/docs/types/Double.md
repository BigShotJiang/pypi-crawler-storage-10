
# Type: double

A real number that conforms to the xsd:double specification

URI: [linkml:Double](https://w3id.org/linkml/Double)

|  |  |  |
| --- | --- | --- |
| Root (builtin) type | | **float** |

## Other properties

|  |  |  |
| --- | --- | --- |
| **Close Mappings:** | | schema:Float |
