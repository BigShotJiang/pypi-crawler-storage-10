
# Type: boolean

A binary (true or false) value

URI: [linkml:Boolean](https://w3id.org/linkml/Boolean)

|  |  |  |
| --- | --- | --- |
| Root (builtin) type | | **Bool** |
| Representation | | bool |

## Other properties

|  |  |  |
| --- | --- | --- |
| **Exact Mappings:** | | schema:Boolean |
