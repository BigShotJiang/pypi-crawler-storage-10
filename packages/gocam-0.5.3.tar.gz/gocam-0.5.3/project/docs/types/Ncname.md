
# Type: ncname

Prefix part of CURIE

URI: [linkml:Ncname](https://w3id.org/linkml/Ncname)

|  |  |  |
| --- | --- | --- |
| Root (builtin) type | | **NCName** |
| Representation | | str |
