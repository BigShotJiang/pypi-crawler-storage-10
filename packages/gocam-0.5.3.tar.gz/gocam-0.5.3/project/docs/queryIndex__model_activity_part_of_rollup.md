
# Slot: model_activity_part_of_rollup

The rollup of `model_activity_part_of_closure` to a GO subset or slim.

URI: [gocam:queryIndex__model_activity_part_of_rollup](https://w3id.org/gocam/queryIndex__model_activity_part_of_rollup)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [TermObject](TermObject.md)

## Parents


## Children


## Used by

 * [QueryIndex](QueryIndex.md)
