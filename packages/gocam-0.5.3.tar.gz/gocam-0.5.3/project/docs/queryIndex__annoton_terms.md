
# Slot: annoton_terms



URI: [gocam:queryIndex__annoton_terms](https://w3id.org/gocam/queryIndex__annoton_terms)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [TermObject](TermObject.md)

## Parents


## Children


## Used by

 * [QueryIndex](QueryIndex.md)
