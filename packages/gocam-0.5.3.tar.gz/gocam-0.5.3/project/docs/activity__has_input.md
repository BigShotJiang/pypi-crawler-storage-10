
# Slot: has_input

The input molecules that are directly consumed by the activity

URI: [gocam:activity__has_input](https://w3id.org/gocam/activity__has_input)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [MoleculeAssociation](MoleculeAssociation.md)

## Parents


## Children


## Used by

 * [Activity](Activity.md)
