
# Slot: taxon

The primary taxon that the model is about

URI: [gocam:model__taxon](https://w3id.org/gocam/model__taxon)


## Domain and Range

None &#8594;  <sub>0..1</sub> [TaxonTermObject](TaxonTermObject.md)

## Parents


## Children


## Used by

 * [Model](Model.md)
