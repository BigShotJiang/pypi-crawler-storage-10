
# Slot: title

The human-readable descriptive title of the model

URI: [gocam:model__title](https://w3id.org/gocam/model__title)


## Domain and Range

None &#8594;  <sub>1..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Model](Model.md)

## Other properties

|  |  |  |
| --- | --- | --- |
| **Mappings:** | | dct:title |
