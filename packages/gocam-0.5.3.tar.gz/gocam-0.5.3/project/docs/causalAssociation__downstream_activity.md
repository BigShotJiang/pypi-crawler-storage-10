
# Slot: downstream_activity

The activity unit that is downstream of this one

URI: [gocam:causalAssociation__downstream_activity](https://w3id.org/gocam/causalAssociation__downstream_activity)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Activity](Activity.md)

## Parents


## Children


## Used by

 * [CausalAssociation](CausalAssociation.md)

## Other properties

|  |  |  |
| --- | --- | --- |
| **Aliases:** | | object |
