
# Enum: PhaseEnum

A term from either the phase branch of GO or the phase branch of an anatomy ontology

URI: [gocam:PhaseEnum](https://w3id.org/gocam/PhaseEnum)


## Permissible Values

| Text | Description | Meaning | Other Information |
| :--- | :---: | :---: | ---: |
