
# Slot: date



URI: [gocam:provenanceInfo__date](https://w3id.org/gocam/provenanceInfo__date)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [ProvenanceInfo](ProvenanceInfo.md)

## Other properties

|  |  |  |
| --- | --- | --- |
| **Mappings:** | | dct:date |
