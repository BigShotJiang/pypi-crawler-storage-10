
# Slot: comments

Curator-provided comments about the model

URI: [gocam:model__comments](https://w3id.org/gocam/model__comments)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Model](Model.md)

## Other properties

|  |  |  |
| --- | --- | --- |
| **Mappings:** | | rdfs:comment |
