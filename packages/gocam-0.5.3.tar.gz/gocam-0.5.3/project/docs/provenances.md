
# Slot: provenances

A generic slot for provenance information

URI: [gocam:provenances](https://w3id.org/gocam/provenances)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [ProvenanceInfo](ProvenanceInfo.md)

## Parents


## Children


## Used by


## Other properties

|  |  |  |
| --- | --- | --- |
| **Mappings:** | | gocam:provenances |
