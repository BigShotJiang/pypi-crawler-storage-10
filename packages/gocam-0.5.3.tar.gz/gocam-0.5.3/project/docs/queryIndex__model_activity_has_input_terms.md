
# Slot: model_activity_has_input_terms

All direct input terms for all activities

URI: [gocam:queryIndex__model_activity_has_input_terms](https://w3id.org/gocam/queryIndex__model_activity_has_input_terms)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [TermObject](TermObject.md)

## Parents


## Children


## Used by

 * [QueryIndex](QueryIndex.md)
