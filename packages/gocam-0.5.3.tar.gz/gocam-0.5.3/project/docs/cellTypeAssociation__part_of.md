
# Slot: part_of



URI: [gocam:cellTypeAssociation__part_of](https://w3id.org/gocam/cellTypeAssociation__part_of)


## Domain and Range

None &#8594;  <sub>0..1</sub> [GrossAnatomyAssociation](GrossAnatomyAssociation.md)

## Parents


## Children


## Used by

 * [CellTypeAssociation](CellTypeAssociation.md)
