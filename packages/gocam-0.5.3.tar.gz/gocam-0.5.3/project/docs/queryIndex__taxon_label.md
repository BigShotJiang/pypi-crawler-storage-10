
# Slot: taxon_label

The label of the primary taxon for the model

URI: [gocam:queryIndex__taxon_label](https://w3id.org/gocam/queryIndex__taxon_label)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [QueryIndex](QueryIndex.md)
