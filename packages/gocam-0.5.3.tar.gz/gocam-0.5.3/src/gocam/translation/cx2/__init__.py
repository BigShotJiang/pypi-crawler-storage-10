from gocam.translation.cx2.main import model_to_cx2 as model_to_cx2
