def main():
    print("Hello from sajdflkaowjalgpaj!")


if __name__ == "__main__":
    main()
