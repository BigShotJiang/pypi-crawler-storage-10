from numpy import inf, nan
from packaging import version
from sklearn.linear_model import RidgeCV as Op

import lale
from lale.docstrings import set_docstrings
from lale.operators import make_operator, sklearn_version


class _RidgeCVImpl:
    def __init__(self, **hyperparams):
        self._hyperparams = hyperparams
        self._wrapped_model = Op(**self._hyperparams)

    def fit(self, X, y=None):
        if y is not None:
            self._wrapped_model.fit(X, y)
        else:
            self._wrapped_model.fit(X)
        return self

    def predict(self, X):
        return self._wrapped_model.predict(X)


_hyperparams_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "description": "inherited docstring for RidgeCV    Ridge regression with built-in cross-validation.",
    "allOf": [
        {
            "type": "object",
            "required": [
                "alphas",
                "fit_intercept",
                "normalize",
                "scoring",
                "cv",
                "gcv_mode",
                "store_cv_values",
            ],
            "relevantToOptimizer": [
                "fit_intercept",
                "normalize",
                "scoring",
                "cv",
                "gcv_mode",
                "store_cv_values",
            ],
            "additionalProperties": False,
            "properties": {
                "alphas": {
                    "type": "array",
                    "items": {"type": "number"},
                    "default": [0.1, 1.0, 10.0],
                    "description": "Array of alpha values to try",
                },
                "fit_intercept": {
                    "type": "boolean",
                    "default": True,
                    "description": "Whether to calculate the intercept for this model",
                },
                "normalize": {
                    "type": "boolean",
                    "default": False,
                    "description": "This parameter is ignored when ``fit_intercept`` is set to False",
                },
                "scoring": {
                    "anyOf": [
                        {"laleType": "callable", "forOptimizer": False},
                        {"enum": ["accuracy", None]},
                    ],
                    "default": None,
                    "description": "A string (see model evaluation documentation) or a scorer callable object / function with signature ``scorer(estimator, X, y)``.",
                },
                "cv": {
                    "description": """Cross-validation as integer or as object that has a split function.
                        The fit method performs cross validation on the input dataset for per
                        trial, and uses the mean cross validation performance for optimization.
                        This behavior is also impacted by handle_cv_failure flag.
                        If integer: number of folds in sklearn.model_selection.StratifiedKFold.
                        If object with split function: generator yielding (train, test) splits
                        as arrays of indices. Can use any of the iterators from
                        https://scikit-learn.org/stable/modules/cross_validation.html#cross-validation-iterators.""",
                    "anyOf": [
                        {
                            "type": "integer",
                            "minimum": 1,
                            "default": 5,
                            "minimumForOptimizer": 3,
                            "maximumForOptimizer": 4,
                            "distribution": "uniform",
                        },
                        {"laleType": "Any", "forOptimizer": False},
                    ],
                },
                "gcv_mode": {
                    "enum": [None, "auto", "svd", "eigen"],
                    "default": None,
                    "description": "Flag indicating which strategy to use when performing Generalized Cross-Validation",
                },
                "store_cv_values": {
                    "type": "boolean",
                    "default": False,
                    "description": "Flag indicating if the cross-validation values corresponding to each alpha should be stored in the ``cv_values_`` attribute (see below)",
                },
            },
        },
        {
            "XXX TODO XXX": "Parameter: store_cv_values > only compatible with cv=none (i"
        },
    ],
}
_input_fit_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "description": "Fit Ridge regression model",
    "type": "object",
    "required": ["X", "y"],
    "properties": {
        "X": {
            "type": "array",
            "items": {"type": "array", "items": {"type": "number"}},
            "description": "Training data",
        },
        "y": {
            "anyOf": [
                {"type": "array", "items": {"type": "number"}},
                {
                    "type": "array",
                    "items": {"type": "array", "items": {"type": "number"}},
                },
            ],
            "description": "Target values",
        },
        "sample_weight": {
            "anyOf": [
                {"type": "number"},
                {"type": "array", "items": {"type": "number"}},
            ],
            "description": "Sample weight",
        },
    },
}
_input_predict_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "description": "Predict using the linear model",
    "type": "object",
    "required": ["X"],
    "properties": {
        "X": {
            "anyOf": [
                {
                    "type": "array",
                    "items": {"laleType": "Any", "XXX TODO XXX": "item type"},
                    "XXX TODO XXX": "array_like or sparse matrix, shape (n_samples, n_features)",
                },
                {
                    "type": "array",
                    "items": {"type": "array", "items": {"type": "number"}},
                },
            ],
            "description": "Samples.",
        }
    },
}
_output_predict_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "description": "Returns predicted values.",
    "type": "array",
    "items": {"type": "number"},
}
_combined_schemas = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "description": "Combined schema for expected data and hyperparameters.",
    "documentation_url": "https://scikit-learn.org/0.20/modules/generated/sklearn.linear_model.RidgeCV#sklearn-linear_model-ridgecv",
    "import_from": "sklearn.linear_model",
    "type": "object",
    "tags": {"pre": [], "op": ["estimator"], "post": []},
    "properties": {
        "hyperparams": _hyperparams_schema,
        "input_fit": _input_fit_schema,
        "input_predict": _input_predict_schema,
        "output_predict": _output_predict_schema,
    },
}
RidgeCV = make_operator(_RidgeCVImpl, _combined_schemas)

if sklearn_version >= version.Version("1.2"):
    # old: https://scikit-learn.org/1.1/modules/generated/sklearn.linear_model.Ridge.html
    # new: https://scikit-learn.org/1.2/modules/generated/sklearn.linear_model.Ridge.html

    RidgeCV = RidgeCV.customize_schema(
        normalize=None,
        set_as_available=True,
    )

if sklearn_version >= version.Version("1.5"):
    RidgeCV = RidgeCV.customize_schema(
        store_cv_values={
            "anyOf": [
                {
                    "type": "boolean",
                },
                {"enum": ["deprecated"]},
            ],
            "default": "deprecated",
            "description": "Deprecated.  Use store_cv_results instead.",
        },
        store_cv_results={
            "type": "boolean",
            "default": False,
            "description": "Flag indicating if the cross-validation values corresponding to each alpha should be stored in the ``cv_values_`` attribute (see below)",
        },
        set_as_available=True,
    )

if sklearn_version >= version.Version("1.7"):
    RidgeCV = RidgeCV.customize_schema(
        store_cv_values=None,
        set_as_available=True,
    )


set_docstrings(RidgeCV)
