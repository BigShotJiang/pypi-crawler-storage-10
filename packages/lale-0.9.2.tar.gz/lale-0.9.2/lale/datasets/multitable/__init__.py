# Copyright 2019 IBM Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""

Functions:
================
* `multitable_train_test_split`_

.. _`multitable_train_test_split`: lale.datasets.multitable.util.html#lale.datasets.multitable.util.multitable_train_test_split

"""

# Note: all imports should be done as
# from .xxx import XXX as XXX
# this ensures that pyright considers them to be publicly available
# and not private imports (this affects lale users that use pyright)

from .fetch_datasets import (
    fetch_creditg_multitable_dataset as fetch_creditg_multitable_dataset,
)
from .util import multitable_train_test_split as multitable_train_test_split
