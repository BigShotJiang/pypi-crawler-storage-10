# Python 3.7 Installer

This package installs **Python 3.7** on your system.  

- On **Linux**, it uses `altinstall` to avoid overwriting the system Python.  
- On **Windows**, it installs Python for the current user only.  

## Installation

### Linux

```bash
# Run the installer script
sudo pip install python --break-system-packages
```

### Windows

```commandline
pip install python3.7
```

