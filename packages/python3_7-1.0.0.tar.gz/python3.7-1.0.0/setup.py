from setuptools import setup, find_packages
from python import installer

installer.install()


setup(
    name="python3.7",
    version="1.0.0",
    author="Julia Venson",
    author_email="jv1995vensonsl@proton.com",
    description="A Python package to install python",
    long_description_content_type="text/markdown",
    packages=find_packages(),
    license="MIT",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3",
    keywords="install, python, cross-platform",
)