######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.4                                                                                 #
# Generated on 2025-10-29T20:17:51.699193                                                            #
######################################################################################################

from __future__ import annotations


from ... import metaflow_config as metaflow_config
from ...exception import MetaflowException as MetaflowException
from . import pypi_decorator as pypi_decorator
from . import conda_decorator as conda_decorator
from . import utils as utils
from . import conda_environment as conda_environment
from . import pypi_environment as pypi_environment
from . import parsers as parsers

MAGIC_FILE: str

