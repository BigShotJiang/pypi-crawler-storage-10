######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.4                                                                                 #
# Generated on 2025-10-29T20:17:51.737532                                                            #
######################################################################################################

from __future__ import annotations

import metaflow
import typing
if typing.TYPE_CHECKING:
    import metaflow.exception

from ...exception import MetaflowException as MetaflowException

class MetaflowGSPackageError(metaflow.exception.MetaflowException, metaclass=type):
    ...

