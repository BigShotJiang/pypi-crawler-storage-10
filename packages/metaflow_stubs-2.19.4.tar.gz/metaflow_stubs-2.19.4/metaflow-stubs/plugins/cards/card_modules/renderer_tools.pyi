######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.4                                                                                 #
# Generated on 2025-10-29T20:17:51.739245                                                            #
######################################################################################################

from __future__ import annotations


from .basic import SerializationErrorComponent as SerializationErrorComponent

def render_safely(func):
    """
    This is a decorator that can be added to any `MetaflowCardComponent.render`
    The goal is to render subcomponents safely and ensure that they are JSON serializable.
    """
    ...

