######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.4                                                                                 #
# Generated on 2025-10-29T20:17:51.703881                                                            #
######################################################################################################

from __future__ import annotations


from . import uv_environment as uv_environment

