"""Utilities for conditional Weights & Biases logging."""

from __future__ import annotations

import os
from contextlib import contextmanager
from dataclasses import asdict
from typing import Any, Dict, Iterator, Optional

from ferret.config.models import WandBConfig
from ferret.utils.logging import get_logger

LOGGER = get_logger(__name__)


def _env_disabled() -> bool:
    flag = os.getenv("FERRET_WANDB_DISABLED")
    if flag is None:
        return False
    return flag.strip().lower() in {"1", "true", "yes", "on"}


def should_enable_wandb(
    config: Optional[WandBConfig],
    override: Optional[bool] = None,
) -> bool:
    if _env_disabled():
        return False
    if override is not None:
        return override
    return bool(config and config.enabled)


def _build_init_kwargs(config: WandBConfig) -> Dict[str, Any]:
    payload = asdict(config)
    payload.pop("enabled", None)
    # wandb ignores ``None`` entries but keeping this tidy avoids warnings.
    return {key: value for key, value in payload.items() if value is not None}


def init_wandb(
    config: Optional[WandBConfig],
    *,
    override: Optional[bool] = None,
    run_config: Optional[Dict[str, Any]] = None,
) -> "wandb.sdk.wandb_run.Run" | None:
    if not should_enable_wandb(config, override=override):
        return None
    try:
        import wandb
    except ImportError:  # pragma: no cover
        LOGGER.warning("wandb enabled but package not installed; skipping logging.")
        return None

    config_obj = config or WandBConfig(enabled=True)
    init_kwargs = _build_init_kwargs(config_obj)
    if run_config is not None:
        init_kwargs.setdefault("config", {}).update(run_config)
    return wandb.init(**init_kwargs)


@contextmanager
def wandb_run(
    config: Optional[WandBConfig],
    *,
    override: Optional[bool] = None,
    run_config: Optional[Dict[str, Any]] = None,
) -> Iterator["wandb.sdk.wandb_run.Run" | None]:
    run = init_wandb(config, override=override, run_config=run_config)
    try:
        yield run
    finally:
        if run is not None:
            try:
                run.finish()
            except Exception:  # pragma: no cover - best effort
                LOGGER.exception("Failed to close wandb run cleanly.")
