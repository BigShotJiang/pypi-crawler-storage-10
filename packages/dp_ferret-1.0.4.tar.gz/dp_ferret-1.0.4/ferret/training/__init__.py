"""Training utilities exposed by the FERRET package."""

from __future__ import annotations

from typing import Any, Optional

__all__: list[str] = []

FERRETSFTTrainer: Optional[Any]

try:
    from .trainers import FERRETSFTTrainer  # type: ignore
except ModuleNotFoundError:
    FERRETSFTTrainer = None
else:  # pragma: no cover - import side effect
    __all__.append("FERRETSFTTrainer")
