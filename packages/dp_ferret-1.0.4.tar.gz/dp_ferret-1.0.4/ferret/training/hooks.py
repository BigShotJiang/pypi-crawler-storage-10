"""Trainer callbacks for FERRET."""

from __future__ import annotations

from typing import TYPE_CHECKING

from transformers.trainer_callback import TrainerCallback, TrainerControl, TrainerState
from transformers.training_args import TrainingArguments

try:
    import wandb  # type: ignore
except ImportError:  # pragma: no cover
    wandb = None

from ferret.utils.logging import get_logger, rich_status

if TYPE_CHECKING:  # pragma: no cover - avoid circular import at runtime
    from ferret.training.trainers import FERRETSFTTrainer


LOGGER = get_logger(__name__)


class PrivacyBudgetCallback(TrainerCallback):
    """Logs privacy budget usage at the end of training."""

    def on_train_end(
        self,
        args: TrainingArguments,
        state: TrainerState,
        control: TrainerControl,
        **kwargs,
    ) -> TrainerControl:
        trainer: "FERRETSFTTrainer" | None = kwargs.get("trainer")
        if trainer is not None:
            trainer.log_privacy_diagnostics()
        return control


class ConsoleMetricsCallback(TrainerCallback):
    """Pretty-print training metrics whenever the trainer logs."""

    def on_log(
        self,
        args: TrainingArguments,
        state: TrainerState,
        control: TrainerControl,
        logs: dict[str, float],
        **kwargs,
    ) -> TrainerControl:
        if not logs:
            return control
        step = state.global_step or 0
        step_display = f"{step:,}"

        def _fmt(key: str, value: float) -> str:
            if isinstance(value, (int, float)):
                return f"{key}={value:.4f}"
            return f"{key}={value}"

        eval_metrics = {k: v for k, v in logs.items() if k.startswith("eval_")}
        train_metrics = {k: v for k, v in logs.items() if not k.startswith("eval_")}

        if eval_metrics:
            metric_str = " • ".join(_fmt(k.replace("eval_", ""), v) for k, v in eval_metrics.items())
            LOGGER.info("🧪 [bold yellow]Eval[/bold yellow] step=%s | %s", step_display, metric_str)

        if train_metrics:
            metric_str = " • ".join(_fmt(k, v) for k, v in train_metrics.items())
            LOGGER.info("📈 [bold green]Train[/bold green] step=%s | %s", step_display, metric_str)
        return control


class WandbMetricsCallback(TrainerCallback):
    """Streams Trainer logs to Weights & Biases."""

    def __init__(self) -> None:
        if wandb is None:
            raise RuntimeError("wandb is not installed but WandbMetricsCallback was created")

    def on_log(
        self,
        args: TrainingArguments,
        state: TrainerState,
        control: TrainerControl,
        logs: dict[str, float],
        **kwargs,
    ) -> TrainerControl:
        if wandb is None or not logs:
            return control
        if state.is_local_process_zero:
            wandb.log(dict(logs), step=state.global_step)
        return control
