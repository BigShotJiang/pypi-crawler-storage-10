"""Training loop integration for the FERRET mechanism."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Iterable, List, Optional, Sequence

import torch
from transformers import TrainingArguments
from transformers.trainer_utils import has_length
from trl import SFTTrainer

from ferret.config.models import FERRETConfig
from ferret.mechanisms.sign_update import FERRETMechanism
from ferret.privacy.accountant import FERRETPrivacyAccountant
from ferret.training.hooks import ConsoleMetricsCallback, PrivacyBudgetCallback
from ferret.utils.logging import get_logger


LOGGER = get_logger(__name__)


@dataclass
class TrainingContext:
    expected_total_updates: float


class FERRETSFTTrainer(SFTTrainer):
    """Drop-in SFTTrainer that applies FERRET sign updates before optimizer steps."""

    def __init__(
        self,
        ferret_config: FERRETConfig,
        *args: Any,
        dependency_matrix: Optional[torch.Tensor] = None,
        ferret_seed: Optional[int] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        self._debug_watchdog = False
        self._budget_exhausted = False

        args_obj: TrainingArguments = self.args
        train_dataset = self.train_dataset
        if not has_length(train_dataset):
            raise ValueError("FERRETSFTTrainer requires a finite-length train dataset.")

        steps_per_epoch = max(
            1,
            len(train_dataset)
            // (args_obj.per_device_train_batch_size * args_obj.gradient_accumulation_steps),
        )
        total_steps = max(1, int(args_obj.num_train_epochs * steps_per_epoch))
        dataset_size = ferret_config.dataset_size or len(train_dataset)

        self.privacy_accountant = FERRETPrivacyAccountant(
            model=self.model,
            total_steps=total_steps,
            epsilon_target=ferret_config.epsilon_target,
            batch_size=args_obj.per_device_train_batch_size * args_obj.gradient_accumulation_steps,
            dataset_size=dataset_size,
            clipping_norm=ferret_config.clipping_norm,
            gradient_accumulation_steps=args_obj.gradient_accumulation_steps,
            param_norm_bound=ferret_config.param_norm_bound,
            dependency_matrix=dependency_matrix,
            max_p_value=ferret_config.max_p_value,
            dynamic_buckets=ferret_config.dynamic_buckets,
        )

        seed = ferret_seed or ferret_config.ferret_seed
        self.mechanism = FERRETMechanism(
            model=self.model,
            param_groups=self.privacy_accountant.param_groups,
            p_values=dict(self.privacy_accountant.p_values),
            clipping_norm=ferret_config.clipping_norm,
            dynamic_buckets=self.privacy_accountant.dynamic_buckets,
            seed=seed,
        )

        self.context = TrainingContext(
            expected_total_updates=self.privacy_accountant.total_steps
            * sum(self.privacy_accountant.p_values.values()),
        )

        LOGGER.info(
            "🚀 [bold magenta]FERRET trainer ready[/bold magenta] steps=%d | ε=%.3f | updates≈%.0f",
            total_steps,
            ferret_config.epsilon_target,
            self.context.expected_total_updates,
        )
        self.add_callback(PrivacyBudgetCallback())
        self.add_callback(ConsoleMetricsCallback())

    # ------------------------------------------------------------------
    def _freeze_except(self, selected_params: Iterable[torch.nn.Parameter]) -> dict[int, bool]:
        selected = {id(param) for param in selected_params}
        original: dict[int, bool] = {}
        for param in self.model.parameters():
            original[id(param)] = param.requires_grad
            param.requires_grad = id(param) in selected
        return original

    def _restore_requires_grad(self, snapshot: dict[int, bool]) -> None:
        for param in self.model.parameters():
            if id(param) in snapshot:
                param.requires_grad = snapshot[id(param)]

    # ------------------------------------------------------------------
    def training_step(self, model: torch.nn.Module, inputs: dict[str, Any]) -> torch.Tensor:
        self._maybe_mark_budget_exhausted()

        model.train()
        inputs = self._prepare_inputs(inputs)

        if self._budget_exhausted:
            selected_groups: Sequence[str] = []
            selected_params: set[torch.nn.Parameter] = set()
        else:
            mechanism_state = self.mechanism.sample_groups()
            selected_groups = mechanism_state.selected_groups
            selected_params = mechanism_state.selected_params

        requires_snapshot = self._freeze_except(selected_params)

        with self.compute_loss_context_manager():
            loss = self.compute_loss(model, inputs)
        if self.args.n_gpu > 1:
            loss = loss.mean()
        if self.args.gradient_accumulation_steps > 1 and not self.deepspeed:
            loss = loss / self.args.gradient_accumulation_steps

        if selected_params:
            loss.backward()
            if (
                self.privacy_accountant.accumulation_counter + 1
                >= self.privacy_accountant.gradient_accumulation_steps
            ):
                self.mechanism.project_selected_gradients(selected_groups)

            for param in model.parameters():
                if param.grad is not None and param not in selected_params:
                    param.grad = None

        self.privacy_accountant.step(selected_groups)
        self._restore_requires_grad(requires_snapshot)

        return loss.detach()

    # ------------------------------------------------------------------
    def log(self, logs: dict[str, Any]) -> None:  # type: ignore[override]
        """Override default HF logging to avoid duplicate console dumps."""

        if not self.is_world_process_zero():
            return

        logs = dict(logs)
        logs.setdefault("step", self.state.global_step)
        self.state.log_history.append(logs)
        self.callback_handler.on_log(self.args, self.state, self.control, logs)

    # ------------------------------------------------------------------
    def _maybe_mark_budget_exhausted(self) -> None:
        if self._budget_exhausted:
            return
        total_updates = sum(self.privacy_accountant.update_counts.values())
        if total_updates >= self.context.expected_total_updates:
            LOGGER.warning(
                "FERRET privacy budget exhausted; suppressing further parameter updates.",
                extra={
                    "total_updates": total_updates,
                    "expected_total_updates": self.context.expected_total_updates,
                },
            )
            self._budget_exhausted = True

    # ------------------------------------------------------------------
    def log_privacy_diagnostics(self) -> None:
        self.privacy_accountant.log_post_training_diagnostics()

    # ------------------------------------------------------------------
    def train(self, *args: Any, **kwargs: Any) -> Any:
        output = super().train(*args, **kwargs)
        self.log_privacy_diagnostics()
        return output
