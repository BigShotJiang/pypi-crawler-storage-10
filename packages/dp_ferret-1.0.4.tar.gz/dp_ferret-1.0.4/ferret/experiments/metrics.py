"""Evaluation metrics for FERRET experiments."""

from __future__ import annotations

import math
from typing import Iterable, Optional, Tuple

import numpy as np
import torch
from datasets import Dataset
from torch.utils.data import DataLoader
from transformers import PreTrainedModel, PreTrainedTokenizerBase


def sequence_nll(logits: torch.Tensor, input_ids: torch.Tensor, pad_token_id: int) -> torch.Tensor:
    """Token-level negative log-likelihood per sequence, ignoring padding."""

    logp = torch.log_softmax(logits, dim=-1)
    tgt = input_ids[:, 1:]
    logp_next = logp[:, :-1, :].gather(2, tgt.unsqueeze(-1)).squeeze(-1)
    mask = (tgt != pad_token_id).float()
    return -(logp_next * mask).sum(dim=1) / mask.sum(dim=1).clamp_min(1.0)


@torch.no_grad()
def compute_perplexity(
    dataset: Dataset,
    model: PreTrainedModel,
    tokenizer: PreTrainedTokenizerBase,
    *,
    batch_size: int = 8,
    max_length: int = 512,
    text_field: str = "text",
) -> float:
    """Compute corpus-level perplexity."""

    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False)
    total_nll = 0.0
    total_tokens = 0.0

    model.eval()
    for batch in loader:
        texts = batch[text_field] if isinstance(batch, dict) else batch
        enc = tokenizer(
            texts,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=max_length,
        ).to(model.device)

        logits = model(**enc).logits
        nll = sequence_nll(logits, enc["input_ids"], tokenizer.pad_token_id)

        token_mask = (enc["input_ids"][:, 1:] != tokenizer.pad_token_id).sum(dim=1)
        total_nll += torch.dot(nll, token_mask.float()).item()
        total_tokens += token_mask.sum().item()

    return math.exp(total_nll / max(total_tokens, 1.0))
