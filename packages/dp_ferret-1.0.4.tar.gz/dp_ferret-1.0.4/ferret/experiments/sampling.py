"""Text sampling utilities for FERRET evaluation."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Optional, Sequence

import torch

from ferret.utils.logging import get_logger

LOGGER = get_logger(__name__)

try:  # pragma: no cover - optional dependency
    from vllm import LLM, SamplingParams  # type: ignore

    HAS_VLLM = True
except ImportError:  # pragma: no cover
    LLM = None
    SamplingParams = None
    HAS_VLLM = False


@dataclass
class SamplingConfig:
    num_samples: int = 100
    max_new_tokens: int = 128
    temperature: float = 0.8
    top_p: float = 0.95
    batch_size: int = 8
    use_vllm: bool = True


def _split_batches(items: Sequence[str], batch_size: int) -> Iterable[Sequence[str]]:
    for start in range(0, len(items), batch_size):
        yield items[start : start + batch_size]


def _strip_completion(prompt: str, generated: str) -> str:
    if generated.startswith(prompt):
        return generated[len(prompt) :].lstrip()
    return generated


def _generate_with_hf(
    model,
    tokenizer,
    prompts: Sequence[str],
    *,
    max_new_tokens: int,
    temperature: float,
    top_p: float,
    batch_size: int,
) -> List[dict[str, str]]:
    if model is None or tokenizer is None:
        raise ValueError("Hugging Face generation requires model and tokenizer instances.")

    device = model.device if hasattr(model, "device") else torch.device("cpu")
    model.eval()

    outputs: List[dict[str, str]] = []
    for batch in _split_batches(prompts, batch_size):
        encodings = tokenizer(
            list(batch),
            return_tensors="pt",
            padding=True,
            truncation=True,
        )
        input_ids = encodings["input_ids"].to(device)
        attention_mask = encodings.get("attention_mask")
        if attention_mask is not None:
            attention_mask = attention_mask.to(device)

        with torch.no_grad():
            generated = model.generate(
                input_ids=input_ids,
                attention_mask=attention_mask,
                max_new_tokens=max_new_tokens,
                temperature=temperature,
                top_p=top_p,
                do_sample=True,
                pad_token_id=getattr(tokenizer, "pad_token_id", None),
            )

        decoded = tokenizer.batch_decode(generated, skip_special_tokens=True)
        for prompt, text in zip(batch, decoded):
            outputs.append({"prompt": prompt, "completion": _strip_completion(prompt, text)})
    return outputs


def _generate_with_vllm(
    model_path: str,
    prompts: Sequence[str],
    *,
    max_new_tokens: int,
    temperature: float,
    top_p: float,
    hf_token: Optional[str],
) -> List[dict[str, str]]:
    if not HAS_VLLM or LLM is None or SamplingParams is None:  # pragma: no cover
        raise RuntimeError("vLLM is not available.")

    if hf_token and "HF_TOKEN" not in os.environ:
        os.environ["HF_TOKEN"] = hf_token

    llm = LLM(
        model=model_path,
        tokenizer=model_path,
        trust_remote_code=True,
        dtype="auto",
        tokenizer_mode="auto",
    )
    sampling_params = SamplingParams(
        temperature=temperature,
        top_p=top_p,
        max_tokens=max_new_tokens,
    )
    generations = llm.generate(list(prompts), sampling_params, use_tqdm=False)
    outputs: List[dict[str, str]] = []
    for prompt, response in zip(prompts, generations):
        text = ""
        if response.outputs:
            text = response.outputs[0].text
        outputs.append({"prompt": prompt, "completion": text.strip()})
    return outputs


def generate_text_samples(
    prompts: Sequence[str],
    *,
    model_path: str | Path | None,
    model,
    tokenizer,
    config: SamplingConfig,
    hf_token: Optional[str] = None,
) -> List[dict[str, str]]:
    if not prompts:
        return []

    str_model_path = str(model_path) if model_path is not None else None
    if config.use_vllm and HAS_VLLM and str_model_path is not None:
        try:
            return _generate_with_vllm(
                str_model_path,
                prompts,
                max_new_tokens=config.max_new_tokens,
                temperature=config.temperature,
                top_p=config.top_p,
                hf_token=hf_token,
            )
        except Exception as exc:  # pragma: no cover - best effort fallback
            LOGGER.warning(
                "vLLM sampling failed (%s). Falling back to Hugging Face generation.", exc
            )

    return _generate_with_hf(
        model,
        tokenizer,
        prompts,
        max_new_tokens=config.max_new_tokens,
        temperature=config.temperature,
        top_p=config.top_p,
        batch_size=config.batch_size,
    )
