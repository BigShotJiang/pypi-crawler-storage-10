"""Experiment orchestration for FERRET."""

from __future__ import annotations

import dataclasses
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Optional

import numpy as np
import torch
from datasets import Dataset
from transformers import AutoModelForCausalLM, AutoTokenizer

from ferret.config.models import RunConfig, dataclass_to_dict
from ferret.data.datasets import load_text_datasets
from ferret.experiments.metrics import compute_perplexity
from ferret.experiments.mia import (
    AttackMetrics,
    extract_confidence_features,
    extract_reference_features,
    run_advanced_attack,
)
from ferret.experiments.storage import ResultStore
from ferret.training.factory import prepare_trainer_artifacts
from ferret.training.hooks import WandbMetricsCallback
from ferret.training.trainers import FERRETSFTTrainer
from ferret.training.variants import resolve_variant
from ferret.utils.logging import get_logger
from ferret.utils.wandb import wandb_run


LOGGER = get_logger(__name__)


@dataclass
class ExperimentSpec:
    model_name: str
    epsilon: float
    epochs: int
    variant: str = "MAX"
    run_mia: bool = True
    reference_model_name: Optional[str] = None
    notes: str = ""


@dataclass
class ExperimentResult:
    experiment_id: str
    train_metrics: dict
    eval_perplexity: float
    attack_metrics: Optional[AttackMetrics] = None


class ExperimentRunner:
    def __init__(
        self,
        base_config: RunConfig,
        result_store: ResultStore,
        *,
        hf_token: Optional[str] = None,
        wandb_override: Optional[bool] = None,
    ) -> None:
        self.base_config = base_config
        self.result_store = result_store
        self.hf_token = hf_token or os.getenv("HF_TOKEN")
        self.wandb_override = wandb_override

    def run(self, specs: Iterable[ExperimentSpec]) -> List[ExperimentResult]:
        results: List[ExperimentResult] = []
        for spec in specs:
            results.append(self.run_single(spec))
        return results

    def run_single(self, spec: ExperimentSpec) -> ExperimentResult:
        LOGGER.info(
            "Running FERRET experiment",
            extra={
                "model": spec.model_name,
                "epsilon": spec.epsilon,
                "epochs": spec.epochs,
                "variant": spec.variant,
            },
        )

        experiment_id = self._experiment_id(spec)
        run_config = dataclasses.replace(self.base_config)
        run_config.model_name = spec.model_name
        run_config.ferret.epsilon_target = spec.epsilon
        run_config.training.num_train_epochs = spec.epochs
        variant_key = spec.variant.upper().replace("FERRET-", "")
        run_config.ferret.dynamic_buckets = resolve_variant(variant_key)
        run_config.ferret.dataset_size = run_config.ferret.dataset_size or None

        run_metadata = {
            "experiment_id": experiment_id,
            "model_name": spec.model_name,
            "epsilon": spec.epsilon,
            "epochs": spec.epochs,
            "variant": spec.variant,
            "notes": spec.notes,
            "config": dataclass_to_dict(run_config),
        }

        with wandb_run(run_config.wandb, override=self.wandb_override, run_config=run_metadata) as wb:
            if wb is not None and run_config.wandb and not run_config.wandb.run_name:
                wb.name = experiment_id

            train_dataset, eval_dataset = load_text_datasets(run_config.dataset)
            run_config.ferret.dataset_size = run_config.ferret.dataset_size or len(train_dataset)

            tokenizer = self._load_tokenizer(run_config.model_name)
            model = self._load_model(run_config)
            if tokenizer.pad_token is None:
                tokenizer.pad_token = tokenizer.eos_token or tokenizer.unk_token or "<pad>"
                tokenizer.pad_token_id = tokenizer.convert_tokens_to_ids(tokenizer.pad_token)
                model.config.pad_token_id = tokenizer.pad_token_id

            artifacts = prepare_trainer_artifacts(run_config)
            output_dir = Path(run_config.training.output_dir) / experiment_id
            artifacts.training_arguments.output_dir = str(output_dir)
            trainer = FERRETSFTTrainer(
                ferret_config=run_config.ferret,
                model=model,
                args=artifacts.training_arguments,
                train_dataset=train_dataset,
                eval_dataset=eval_dataset,
                tokenizer=tokenizer,
                dataset_text_field=run_config.dataset.text_field,
                ferret_seed=run_config.ferret.ferret_seed,
            )
            if wb is not None:
                trainer.add_callback(WandbMetricsCallback())
                wb.log({f"privacy_pre/{k}": v for k, v in trainer.privacy_accountant.pre_training_diagnostics().items()})

            train_output = trainer.train()
            trainer.save_model()

            perplexity = compute_perplexity(
                eval_dataset,
                model,
                tokenizer,
                batch_size=run_config.training.per_device_eval_batch_size,
                text_field=run_config.dataset.text_field,
            )

            attack_metrics = None
            if spec.run_mia:
                attack_metrics = self._run_mia(
                    train_dataset,
                    eval_dataset,
                    model,
                    tokenizer,
                    reference_model_name=spec.reference_model_name,
                    text_field=run_config.dataset.text_field,
                )

            if wb is not None:
                payload = {
                    **{f"train/{k}": v for k, v in (train_output.metrics or {}).items()},
                    "eval/perplexity": perplexity,
                }
                privacy_post = trainer.privacy_accountant.post_training_diagnostics()
                payload.update({f"privacy_post/{k}": v for k, v in privacy_post.items()})
                if attack_metrics:
                    payload.update({f"mia/{k}": v for k, v in dataclasses.asdict(attack_metrics).items()})
                wb.log(payload)

            metrics_path = self.result_store.save_metrics(
                experiment_id,
                {
                    "train_metrics": train_output.metrics,
                    "perplexity": perplexity,
                    "epsilon": spec.epsilon,
                    "variant": spec.variant,
                    "notes": spec.notes,
                },
            )
            if wb is not None:
                wb.save(str(metrics_path))

            metadata = {
                "model_name": spec.model_name,
                "epochs": spec.epochs,
                "ferret_variant": spec.variant,
                "reference_model": spec.reference_model_name,
                "dataset_config": dataclasses.asdict(run_config.dataset),
            }
            if attack_metrics:
                metadata["attack_metrics"] = dataclasses.asdict(attack_metrics)

            self.result_store.save_metadata(experiment_id, metadata)

            return ExperimentResult(
                experiment_id=experiment_id,
                train_metrics=train_output.metrics,
                eval_perplexity=perplexity,
                attack_metrics=attack_metrics,
            )

    def _experiment_id(self, spec: ExperimentSpec) -> str:
        variant = spec.variant.lower()
        epsilon_str = str(spec.epsilon).replace(".", "_")
        return f"{spec.model_name.split('/')[-1]}__{variant}__eps_{epsilon_str}"

    def _load_model(self, config: RunConfig) -> torch.nn.Module:
        return AutoModelForCausalLM.from_pretrained(config.model_name, token=self.hf_token)

    def _load_tokenizer(self, model_name: str):
        return AutoTokenizer.from_pretrained(model_name, token=self.hf_token)

    def _run_mia(
        self,
        train_dataset: Dataset,
        eval_dataset: Dataset,
        model: torch.nn.Module,
        tokenizer,
        *,
        reference_model_name: Optional[str] = None,
        text_field: str = "text",
    ) -> AttackMetrics:
        member_target = extract_confidence_features(
            train_dataset,
            model,
            tokenizer,
            text_field=text_field,
        )
        non_member_target = extract_confidence_features(
            eval_dataset,
            model,
            tokenizer,
            text_field=text_field,
        )
        target_features = np.vstack([member_target, non_member_target])
        labels = np.concatenate(
            [np.ones(len(member_target), dtype=int), np.zeros(len(non_member_target), dtype=int)]
        )

        reference_features = None
        if reference_model_name is not None:
            ref_tokenizer = AutoTokenizer.from_pretrained(reference_model_name, token=self.hf_token)
            ref_model = AutoModelForCausalLM.from_pretrained(reference_model_name, token=self.hf_token)
            reference_member = extract_reference_features(
                train_dataset,
                ref_model,
                ref_tokenizer,
                text_field=text_field,
            )
            reference_non_member = extract_reference_features(
                eval_dataset,
                ref_model,
                ref_tokenizer,
                text_field=text_field,
            )
            reference_features = np.vstack([reference_member, reference_non_member])

        scores, metrics, _ = run_advanced_attack(target_features, reference_features, labels)
        LOGGER.info(
            "Membership inference attack complete",
            extra={"roc_auc": metrics.roc_auc, "advantage": metrics.advantage},
        )
        return metrics
