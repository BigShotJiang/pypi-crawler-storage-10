"""Dataset utilities for FERRET experiments."""

from __future__ import annotations

from dataclasses import is_dataclass
from typing import Optional, Tuple

from datasets import Dataset, load_dataset

from ferret.config.models import DatasetConfig
from ferret.utils.logging import get_logger


LOGGER = get_logger(__name__)


def _format_prompt_response(
    prompt: Optional[str],
    response: Optional[str],
    *,
    prompt_prefix: str = "Human:",
    response_prefix: str = "Assistant:",
) -> str:
    prompt_str = (prompt or "").strip()
    response_str = (response or "").strip()

    if prompt_str and response_str:
        return f"{prompt_prefix} {prompt_str}\n\n{response_prefix} {response_str}"
    if response_str:
        return f"{response_prefix} {response_str}"
    return prompt_str


def load_text_datasets(config: DatasetConfig | dict) -> Tuple[Dataset, Dataset]:
    """Load and split dataset as specified by ``config``."""

    if not is_dataclass(config):
        config = DatasetConfig(**config)

    LOGGER.info(
        "📦 [bold cyan]Loading dataset[/bold cyan] %s [dim](split=%s, max=%s, seed=%d)[/dim]",
        config.dataset_name,
        config.split,
        config.max_records if config.max_records is not None else "all",
        config.seed,
    )

    dataset = load_dataset(config.dataset_name, split=config.split)

    if config.max_records is not None:
        dataset = dataset.select(range(config.max_records))

    text_field = getattr(config, "text_field", "text")
    prompt_field = getattr(config, "prompt_field", None)
    response_field = getattr(config, "response_field", None)

    if prompt_field and response_field:
        LOGGER.info(
            "✍️ [bold blue]Formatting dataset[/bold blue] using prompt='%s' and response='%s' → %s",
            prompt_field,
            response_field,
            text_field,
        )

        def _builder(example: dict) -> dict:
            prompt = example.get(prompt_field)
            response = example.get(response_field)
            return {text_field: _format_prompt_response(prompt, response)}

        dataset = dataset.map(_builder, desc="Formatting conversation transcripts")

    if text_field not in dataset.column_names:
        raise KeyError(
            f"Dataset '{config.dataset_name}' does not provide a '{text_field}' column "
            f"and no prompt/response fields were specified. Available columns: {dataset.column_names}"
        )

    train_size = int(len(dataset) * config.train_fraction)
    shuffled = dataset.shuffle(seed=config.seed)
    train_dataset = shuffled.select(range(train_size))
    eval_dataset = shuffled.select(range(train_size, len(dataset)))

    LOGGER.info(
        "✅ [bold green]Dataset ready[/bold green] train=%d eval=%d examples",
        len(train_dataset),
        len(eval_dataset),
    )

    return train_dataset, eval_dataset
