"""FERRET sign-update mechanism."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Set

import torch

from ferret.utils.logging import get_logger
from ferret.utils.seed import make_torch_generator


LOGGER = get_logger(__name__)


@dataclass
class MechanismState:
    """Holds information about the most recent sampling step."""

    selected_groups: List[str]
    selected_params: Set[torch.nn.Parameter]


class FERRETMechanism:
    """Implements the sign projection and masking described in the FERRET paper."""

    def __init__(
        self,
        *,
        model: torch.nn.Module,
        param_groups: Dict[str, List[torch.nn.Parameter]],
        p_values: Dict[str, float],
        clipping_norm: float,
        dynamic_buckets: Optional[int] = None,
        seed: Optional[int] = None,
    ) -> None:
        self.model = model
        self.param_groups = param_groups
        self.p_values = p_values
        self.clipping_norm = clipping_norm
        self.dynamic_buckets = dynamic_buckets

        self.static_buckets = (
            self._build_dynamic_buckets(dynamic_buckets)
            if dynamic_buckets is not None
            else param_groups
        )
        self.seed = seed or torch.randint(0, 2**63 - 1, ()).item()

        self.cpu_generator = make_torch_generator(self.seed, device=torch.device("cpu"))
        self.cuda_generators: Dict[str, torch.Generator] = {}
        if torch.cuda.is_available():
            for idx in range(torch.cuda.device_count()):
                device_str = f"cuda:{idx}"
                self.cuda_generators[device_str] = make_torch_generator(
                    self.seed, device=torch.device(device_str)
                )

        LOGGER.info(
            "🎯 [bold magenta]FERRET mechanism ready[/bold magenta] buckets=%d | C=%.2f | seed=%d",
            len(self.static_buckets),
            self.clipping_norm,
            self.seed,
        )

    def _build_dynamic_buckets(self, bucket_count: int) -> Dict[str, List[torch.nn.Parameter]]:
        trainable_params = [
            parameter
            for params in self.param_groups.values()
            for parameter in params
        ]
        if not trainable_params:
            raise ValueError("No trainable parameters available for FERRET dynamic buckets.")

        effective_count = max(1, min(bucket_count, len(trainable_params)))
        buckets: Dict[str, List[torch.nn.Parameter]] = {f"dyn_{i}": [] for i in range(effective_count)}
        for idx, parameter in enumerate(trainable_params):
            bucket_name = f"dyn_{idx % effective_count}"
            buckets[bucket_name].append(parameter)
        return buckets

    def _rng_for_device(self, device: torch.device) -> torch.Generator:
        if device.type == "cuda":
            return self.cuda_generators.get(str(device), self.cpu_generator)
        return self.cpu_generator

    def _bernoulli(self, probability: float, generator: torch.Generator) -> bool:
        device = generator.device if hasattr(generator, "device") else torch.device("cpu")
        return torch.rand((), generator=generator, device=device).item() < probability

    def sample_groups(self) -> MechanismState:
        selected_groups: List[str] = []
        selected_params: Set[torch.nn.Parameter] = set()

        for group_name, params in self.static_buckets.items():
            p = self.p_values.get(group_name)
            if p is None or p <= 0.0:
                continue

            # All parameters within a group share device/dtype; use first for RNG
            first_param = params[0]
            generator = self._rng_for_device(first_param.device)
            if self._bernoulli(p, generator):
                selected_groups.append(group_name)
                selected_params.update(params)

        return MechanismState(selected_groups=selected_groups, selected_params=selected_params)

    def project_gradients(self, group_name: str, params: Sequence[torch.nn.Parameter]) -> None:
        if not params:
            return

        device = params[0].device
        dtype = params[0].dtype
        generator = self._rng_for_device(device)

        dim = sum(p.numel() for p in params)
        direction = torch.randn(dim, device=device, dtype=torch.float32, generator=generator)
        direction /= direction.norm(p=2) + 1e-12

        dot = torch.tensor(0.0, device=device, dtype=torch.float32)
        offset = 0
        for param in params:
            if param.grad is None:
                offset += param.numel()
                continue
            count = param.numel()
            grad_view = param.grad.view(-1)
            if grad_view.dtype != torch.float32:
                grad_view = grad_view.to(torch.float32)
            direction_slice = direction[offset : offset + count]
            dot = dot + torch.dot(grad_view, direction_slice)
            offset += count

        sigma = 1.0 if dot.item() >= 0 else -1.0
        direction.mul_(sigma * self.clipping_norm)

        offset = 0
        for param in params:
            if param.grad is None:
                continue
            count = param.numel()
            direction_slice = direction[offset : offset + count]
            if param.grad.dtype != direction_slice.dtype:
                direction_slice = direction_slice.to(param.grad.dtype)
            param.grad.copy_(direction_slice.view_as(param))
            offset += count

    def project_selected_gradients(self, selected_group_names: Iterable[str]) -> None:
        for group_name in selected_group_names:
            params = self.static_buckets.get(group_name)
            if params is None:
                raise KeyError(f"Group '{group_name}' not found in FERRETMechanism.")
            self.project_gradients(group_name, params)
