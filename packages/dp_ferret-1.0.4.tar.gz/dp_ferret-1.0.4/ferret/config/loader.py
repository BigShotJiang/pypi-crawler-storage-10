"""Convenience helpers for working with FERRET configuration."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping, Optional

from .models import RunConfig, dataclass_to_dict, load_dataclass, load_yaml


def from_mapping(mapping: Mapping[str, Any], *, base: Optional[RunConfig] = None) -> RunConfig:
    """Create a ``RunConfig`` from a mapping, optionally overlaying on ``base``."""

    base_config = base or RunConfig()
    merged = dataclass_to_dict(base_config)
    merged.update(mapping)
    return load_dataclass(RunConfig, merged)


def from_yaml(path: Path | str, *, base: Optional[RunConfig] = None) -> RunConfig:
    """Load configuration from YAML file with optional base overlay."""

    data = load_yaml(path)
    return from_mapping(data, base=base)


def to_yaml(config: RunConfig, path: Path | str) -> None:
    """Persist configuration to YAML."""

    import yaml

    with open(path, "w", encoding="utf-8") as handle:
        yaml.safe_dump(dataclass_to_dict(config), handle, sort_keys=False)
