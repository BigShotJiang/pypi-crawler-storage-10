"""Bundled configuration presets for FERRET."""

from __future__ import annotations

__all__ = ["DEFAULT_PRESET"]

DEFAULT_PRESET = "defaults.yaml"
