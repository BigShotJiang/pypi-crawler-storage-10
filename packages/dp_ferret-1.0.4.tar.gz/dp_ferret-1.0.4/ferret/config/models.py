"""Configuration dataclasses used across FERRET."""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from importlib import resources
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Optional, Type, TypeVar, Union, get_args, get_origin, get_type_hints

import yaml

T = TypeVar("T")


def _asdict_factory(data: Iterable[tuple[str, Any]]) -> Dict[str, Any]:
    """Custom dict factory that drops keys with ``None`` values."""

    return {key: value for key, value in data if value is not None}


def dataclass_to_dict(instance: Any) -> Dict[str, Any]:
    """Convert a dataclass instance to a dictionary, pruning ``None`` entries."""

    if not dataclasses.is_dataclass(instance):
        raise TypeError("dataclass_to_dict expects a dataclass instance")
    return dataclasses.asdict(instance, dict_factory=_asdict_factory)


def _convert_value(field_type: Any, value: Any) -> Any:
    if value is None:
        return None

    origin = get_origin(field_type)
    if dataclasses.is_dataclass(field_type):
        if isinstance(value, Mapping):
            return _convert_dataclass(field_type, value)
        return value

    if origin is Union:
        args = [arg for arg in get_args(field_type) if arg is not type(None)]
        for arg in args:
            try:
                return _convert_value(arg, value)
            except (TypeError, ValueError):
                continue
        return value

    return value


def _convert_dataclass(cls: Type[T], raw: Mapping[str, Any]) -> T:
    """Recursively convert mapping ``raw`` into an instance of ``cls``."""

    type_hints = get_type_hints(cls)
    kwargs: Dict[str, Any] = {}
    for field_info in dataclasses.fields(cls):
        key = field_info.name
        if key not in raw:
            continue
        value = raw[key]
        field_type = type_hints.get(key, field_info.type)
        if isinstance(value, Mapping) and dataclasses.is_dataclass(field_type):
            kwargs[key] = _convert_dataclass(field_type, value)
        else:
            kwargs[key] = _convert_value(field_type, value)
    return cls(**kwargs)  # type: ignore[arg-type]


def load_dataclass(cls: Type[T], data: Mapping[str, Any]) -> T:
    """Instantiate dataclass ``cls`` from mapping ``data``."""

    return _convert_dataclass(cls, data)


def load_yaml(path: Path | str) -> Dict[str, Any]:
    """Load ``path`` as YAML into a dictionary."""

    with open(path, "r", encoding="utf-8") as handle:
        return yaml.safe_load(handle) or {}


def _load_bundled_yaml(name: str) -> Dict[str, Any]:
    """Load a YAML file shipped with the package."""

    package = "ferret.config.presets"
    try:
        resource = resources.files(package).joinpath(name)
    except ModuleNotFoundError as exc:  # pragma: no cover - defensive
        raise FileNotFoundError(f"Bundled config package '{package}' is unavailable.") from exc

    if not resource.is_file():
        raise FileNotFoundError(f"Bundled config '{name}' not found.")

    with resource.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle) or {}


@dataclass
class DatasetConfig:
    dataset_name: str = "TinyPixel/orca-mini"
    split: str = "train"
    train_fraction: float = 0.5
    seed: int = 42
    max_records: Optional[int] = 20_000
    text_field: str = "text"
    prompt_field: Optional[str] = None
    response_field: Optional[str] = None


@dataclass
class OptimizerConfig:
    learning_rate: float = 2e-4
    weight_decay: float = 1e-3
    optim: str = "adamw_torch"
    max_grad_norm: float = 0.3
    lr_scheduler_type: str = "constant"
    warmup_ratio: float = 0.03


@dataclass
class TrainingConfig:
    output_dir: str = "./results"
    num_train_epochs: int = 3
    per_device_train_batch_size: int = 5
    per_device_eval_batch_size: int = 5
    gradient_accumulation_steps: int = 10
    gradient_checkpointing: bool = False
    fp16: bool = False
    bf16: bool = False
    max_steps: int = -1
    group_by_length: bool = True
    save_strategy: str = "no"
    save_steps: Optional[int] = None
    save_total_limit: Optional[int] = 1
    logging_steps: int = 25
    report_to: str = "tensorboard"


@dataclass
class FERRETConfig:
    epsilon_target: float = 1.0
    clipping_norm: float = 1.0
    dataset_size: Optional[int] = None
    dynamic_buckets: Optional[str | int] = "eighth"
    param_norm_bound: float = 1.0
    max_p_value: float = 0.99
    ferret_seed: Optional[int] = None


@dataclass
class WandBConfig:
    enabled: bool = False
    project: Optional[str] = None
    entity: Optional[str] = None
    run_name: Optional[str] = None
    tags: Optional[list[str]] = None
    notes: Optional[str] = None
    mode: Optional[str] = None  # online/offline/disabled


@dataclass
class RunConfig:
    model_name: str = "openai-community/gpt2"
    dataset: DatasetConfig = field(default_factory=DatasetConfig)
    optimizer: OptimizerConfig = field(default_factory=OptimizerConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)
    ferret: FERRETConfig = field(default_factory=FERRETConfig)
    output_dir: Optional[str] = None
    seed: int = 0
    wandb: Optional[WandBConfig] = None


def load_run_config(path: Path | str) -> RunConfig:
    """Load ``RunConfig`` from a YAML file."""

    path_obj = Path(path)
    if path_obj.is_file():
        data = load_yaml(path_obj)
        return load_dataclass(RunConfig, data)

    candidates: list[str] = []
    if path_obj.suffix:
        candidates.append(path_obj.name)
    else:
        candidates.extend([f"{path_obj.name}.yaml", path_obj.name])

    for candidate in candidates:
        try:
            data = _load_bundled_yaml(candidate)
        except FileNotFoundError:
            continue
        else:
            return load_dataclass(RunConfig, data)

    raise FileNotFoundError(
        f"Could not locate run config '{path}'. Checked filesystem path '{path_obj}' and bundled presets."
    )
