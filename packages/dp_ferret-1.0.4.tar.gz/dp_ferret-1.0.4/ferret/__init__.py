"""FERRET package."""

from importlib.metadata import PackageNotFoundError, version

from ferret.config.models import RunConfig, dataclass_to_dict, load_run_config
from ferret.data.datasets import load_text_datasets
from ferret.experiments.metrics import compute_perplexity
from ferret.experiments.mia import (
    AttackMetrics,
    extract_confidence_features,
    extract_reference_features,
    run_advanced_attack,
    run_confidence_attack,
)
from ferret.experiments.runner import ExperimentRunner, ExperimentSpec
from ferret.experiments.sampling import SamplingConfig, generate_text_samples
from ferret.experiments.storage import ResultStore
from ferret.training import FERRETSFTTrainer
from ferret.training.factory import prepare_trainer_artifacts
from ferret.training.hooks import WandbMetricsCallback
from ferret.training.variants import resolve_variant
from ferret.utils.logging import configure_logging, get_logger, rich_status
from ferret.utils.wandb import wandb_run

try:  # pragma: no cover - during local development package may be editable
    __version__ = version("dp-ferret")
except PackageNotFoundError:  # pragma: no cover
    __version__ = "0.0.0"

__all__ = [
    "__version__",
    "FERRETSFTTrainer",
    "RunConfig",
    "ExperimentRunner",
    "ExperimentSpec",
    "ResultStore",
    "SamplingConfig",
    "AttackMetrics",
    "configure_logging",
    "get_logger",
    "rich_status",
    "wandb_run",
    "WandbMetricsCallback",
    "prepare_trainer_artifacts",
    "resolve_variant",
    "load_run_config",
    "dataclass_to_dict",
    "load_text_datasets",
    "compute_perplexity",
    "generate_text_samples",
    "extract_confidence_features",
    "extract_reference_features",
    "run_confidence_attack",
    "run_advanced_attack",
]
