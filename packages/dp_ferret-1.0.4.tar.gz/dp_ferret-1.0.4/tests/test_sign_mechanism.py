from __future__ import annotations

import torch
import pytest

from ferret.mechanisms.sign_update import FERRETMechanism


class ToyModel(torch.nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.linear = torch.nn.Linear(3, 2, bias=False)


def test_sign_projection_sets_grad_norm() -> None:
    model = ToyModel()
    params = list(model.parameters())
    param_groups = {"group_linear": params}
    p_values = {"group_linear": 1.0}

    mechanism = FERRETMechanism(
        model=model,
        param_groups=param_groups,
        p_values=p_values,
        clipping_norm=0.5,
    )

    params[0].grad = torch.ones_like(params[0])
    mechanism.project_selected_gradients(["group_linear"])

    grad = params[0].grad
    norm = grad.norm().item()
    assert pytest.approx(norm, rel=1e-4) == 0.5
