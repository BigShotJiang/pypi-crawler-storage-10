from __future__ import annotations

import sys
import types

import pytest

from ferret.config.models import WandBConfig
from ferret.utils import wandb as wandb_utils


def _install_dummy_wandb(monkeypatch: pytest.MonkeyPatch) -> types.SimpleNamespace:
    dummy = types.SimpleNamespace()

    class DummyRun:
        finished = False

        def finish(self) -> None:
            self.finished = True

    def init(**kwargs):
        dummy.kwargs = kwargs
        run = DummyRun()
        dummy.last_run = run
        return run

    dummy.init = init
    dummy.kwargs = None
    dummy.last_run = None

    monkeypatch.setitem(sys.modules, "wandb", dummy)
    return dummy


def test_should_enable_wandb_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("FERRET_WANDB_DISABLED", raising=False)
    config = WandBConfig(enabled=True)
    assert wandb_utils.should_enable_wandb(config) is True


def test_should_enable_wandb_override(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("FERRET_WANDB_DISABLED", "1")
    config = WandBConfig(enabled=True)
    assert wandb_utils.should_enable_wandb(config) is False
    assert wandb_utils.should_enable_wandb(config, override=True) is False
    monkeypatch.delenv("FERRET_WANDB_DISABLED", raising=False)
    assert wandb_utils.should_enable_wandb(config, override=False) is False
    assert wandb_utils.should_enable_wandb(config, override=True) is True


def test_init_wandb_merges_config(monkeypatch: pytest.MonkeyPatch) -> None:
    dummy = _install_dummy_wandb(monkeypatch)
    config = WandBConfig(enabled=True, project="ferret")
    run = wandb_utils.init_wandb(config, run_config={"foo": "bar"})
    assert run is dummy.last_run
    assert dummy.kwargs["project"] == "ferret"
    assert dummy.kwargs["config"]["foo"] == "bar"


def test_wandb_run_finishes(monkeypatch: pytest.MonkeyPatch) -> None:
    dummy = _install_dummy_wandb(monkeypatch)
    config = WandBConfig(enabled=True)
    with wandb_utils.wandb_run(config) as run:
        assert run is dummy.last_run
        assert run.finished is False
    assert dummy.last_run.finished is True
