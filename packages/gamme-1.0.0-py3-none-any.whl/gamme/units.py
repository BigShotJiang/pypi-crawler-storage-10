# -*- coding: utf-8 -*-

"""Physical quantities with units.

This module provides a Quantity class which is defined
by a value and an unit. An unit can be defined by a base
unit or a composition of base units.

There are four types of composition:
- ScaleUnit, an unit defined by a scale between this unit
and another unit, e.g., meter and kilometer,
- OffsetUnit, an unit defined by a difference (offset)
between this unit and another unit, e.g., kelvin and celsius,
- ExponentUnit, an unit raised to an exponent, e.g. square meter,
- MultipliesUnit, an unit defined by the product of two units.

See module gamme.quantities to see predefined units.

You can use an instance of UnitsDict to create a dictionary
with useful operations (definition of a quantity by its value
and its symbol, automatic conversion to known units...).

"""

import copy, math, sys, warnings
from functools import total_ordering
try:
    unicode('')
except NameError:
    unicode = str
    
class Unit(object):

    """The Unit class is the base class for all composed units and also
    represents a base unit (meter, kilogram... in the MKSA system).

    The dimensions of each unit is automatically determined by
    construction. We can also determine a conversion factor.

    A conversion factor is a couple with a scaling factor and
    an offset factor. The conversion factor (s,o) of an unit u
    is defined by the following convention : when we want
    to convert a value x from the base unit of u to u, we do
    the following operation y = x / s + o. If we want to convert
    the value y from u to the base unit, we do s * (y - o).
    """

    def __init__(self, symbol):
        """Build a base unit defined by a symbol.

        The symbol may be None if it is possible to determine it by
        composition of other units. If it is not a composition,
        i.e a base unit, a RuntimeError exception is raised.

        Args:
            symbol (str): The symbol of this unit.

        Raises:
            RuntimeError

        """
        if symbol is None and type(self) == Unit:
            raise RuntimeError("Symbol can't be None")
        self._symbol = symbol
        self._dimensions = None
        self.__has_metre_radian = False
        if symbol == 'metrerad':
            self.__has_metre_radian = True

    @property
    def symbol(self):
        """Return the symbol of this unit."""
        return self._symbol

    def _has_metre_radian(self):
        return self.__has_metre_radian

    def _init_dimensions(self):
        """Initialize the dimensions of this unit.

        Must be overloaded by all children of this class.
        """
        self._dimensions = {}
        self._dimensions[self] = 1

    @property
    def dimensions(self):
        """Return the dimensions of this unit.

        This method call _init_dimensions to initialize the corresponding
        attribute.

        Returns:
            A dictionary with base units as keys and dimensions as values.
        """
        if self._dimensions is None:
            self._init_dimensions()
        return self._dimensions

    def scale(self):
        """Return the scaling factor from this unit to the base unit."""
        return 1.

    def offset(self):
        """Return the offset factor from this unit to the base unit."""
        return 0.

    def conversion_factor(self, unit = None):
        """Return the conversion factor from this unit to another unit.

        If unit is not specified, it returns the conversion factor
        from this unit to the base unit.

        If unit is specified but it is not commensurable with this unit,
        a TypeError exception is raised.

        Kwargs:
            unit (Unit): Another unit

        Returns:
            (float, float): a couple (scaling factor, offset factor).

        Raises:
            TypeError

        If the conversion factor of this unit is (s1, o1) and
        the conversion factor of the another unit is (s2, o2),
        to convert y from this unit to the another unit, we must
        convert y from this unit to the base unit and then from
        the base unit to the another unit.
           s1 * (y - o1) / s2 + o2

        We want to determine the conversion factor (S, O) such that
        S * (y - O) converts y from this unit to the another unit.
         = s1 / s2 * (y - o1) + s1 / s2 * s2 / s1 * o2
         = s1 / s2 * (y - o1 + s2 / s1 * o2)
         = s1 / s2 * (y - (o1 - o2 * s2 / s1))
        thus, the conversion factor is (s1 / s2, o1 - o2 * s2 / s1).

        """
        if unit is None:
            return (self.scale(), self.offset())
        else:
            if not self.is_commensurable(unit):
                raise TypeError('Units %s and %s are incommensurable' % (self.symbol, unit.symbol))
            scale = self.scale() / unit.scale()
            offset = self.offset() - unit.offset() * unit.scale() / self.scale()
            return (scale, offset)

    def is_commensurable(self, unit):
        """Return True if this unit and another unit are commensurable.

        Two units are commensurable if their dimensions are equal.
        """
        return self.dimensions == unit.dimensions
        #dims1 = dict([(k,v) for (k, v) in self.dimensions.items() if v != 0])
        #dims2 = dict([(k,v) for (k, v) in unit.dimensions.items() if v != 0])
        #return dims1 == dims2

    def is_angle(self):
        return self._has_metre_radian()
        #for dim in self.dimensions.values():
        #   if dim != 0:
        #        return False
        #return _get_metre_radian_unit() in self.dimensions

    def is_dimension_less(self):
        """Return True if this unit is dimensionless.

        A unit is dimensionless if each dimension of this unit is null.
        """
        return len(self.dimensions) == 0
        #for dim in self.dimensions.values():
        #    if dim != 0:
        #      return False
        #return True

    def __rmul__(self, other):
        """Return a quantity with the left operand as the value and the
        right operand as the unit.
        """
        return Quantity(other, self)

    def __eq__(self, other):
        """Return True if this unit is equal to another unit.

        Two units are equal if they are commensurable and their conversion
        factor are equal.
        """
        if not self.is_commensurable(other):
            return False
        if self.scale() != other.scale():
            return False
        if self.offset() != other.offset():
            return False
        return True

    __hash__ = object.__hash__

class ScaleUnit(Unit):

    """Unit defined by a scale between this unit and another unit.

    We convert a value y from another unit to this unit by doing
    the following operation : y / scale.

    Example:
    >>> meter = Unit('m')
    >>> kilometer = ScaleUnit('km', meter, 1000.)
    >>> d = 1. * kilometer
    >>> print d
    1.0 km
    >>> print d.as_unit(meter)
    1000.0 m

    Given an unit U defined by the conversion factor (s, o).
    To convert a value z from this unit to the base unit, we must convert
    z from this unit to U and then from U to the base unit.
       s * ( (scale * z) - o)

    We want to determine the conversion factor (S, O) such that S * (z - O)
    converts z from this unit to the base unit.
     = s * scale / scale * (scale * z - o)
     = s * scale * (z - o / scale)
     = (s * scale) * (z - o / scale)
    thus, S = s * scale, O = o / scale

    """

    def __init__(self, symbol, unit, scale):
        """Build a scale unit defined by an other unit and a scale.

        By definition, scale can't be null. Otherwise, an Arithmetic exception
        is raised.

        Args:
            symbol (str): symbol of this unit
            unit (Unit): another unit
            scale (float): scale

        Raises:
            ArithmeticError

        """
        super(ScaleUnit, self).__init__(symbol)
        if scale == 0.:
            raise ArithmeticError("scale can't be zero")
        self.__unit = unit
        self.__scale = scale

    @property
    def symbol(self):
        if self._symbol is None:
            self._symbol = str(self.__scale) + '.' + self.__unit.symbol
        return self._symbol

    def _has_metre_radian(self):
        return self.__unit._has_metre_radian()

    def _init_dimensions(self):
        self._dimensions = copy.copy(self.__unit.dimensions)

    def scale(self):
        return self.__unit.scale() * self.__scale

    def offset(self):
        return self.__unit.offset() / self.__scale


class OffsetUnit(Unit):

    """Unit defined by a difference between this unit and another unit.

    We convert a value y from another unit to this unit by doing
    the following operation : y + offset.

    Example:
    >>> kelvin = Unit('K')
    >>> celsius = OffsetUnit('°C', kelvin, -273.15)
    >>> t = 0. * celsius
    >>> print t
    0.0 °C
    >>> print t.as_unit(kelvin)
    273.15 K

    Given an unit U defined by the conversion factor (s, o).

    To convert a value z from this unit to the base unit, we must convert z from
    this unit to U and then from U to the base unit.
       s * ( (z - offset) - o)

    We want to determine the conversion factor (S, O) such that S * (z - O)
    converts z from this unit to the base unit.
     = s * (z - (o + offset) )
    thus, S = s, O = o + offset

    """

    def __init__(self, symbol, unit, offset):
        super(OffsetUnit, self).__init__(symbol)
        self.__unit = unit
        self.__offset = offset

    @property
    def symbol(self):
        if self._symbol is None:
            self._symbol = '(' + self.__unit.symbol + '+' + str(self.__offset) + ')'
        return self._symbol

    def _has_metre_radian(self):
        return self.__unit._has_metre_radian()

    def _init_dimensions(self):
        self._dimensions = copy.copy(self.__unit.dimensions)

    def scale(self):
        return self.__unit.scale()

    def offset(self):
        return self.__unit.offset() + self.__offset


class ExponentUnit(Unit):

    """Unit raised to an exponent.

    We convert a value y from another unit to this unit by doing the following operation :
       y ** exponent

    Example:
    >>> from gamme.units import Unit, ExponentUnit, Quantity as Q
    >>> meter = Unit('m')
    >>> square_meter = ExponentUnit('m²', meter, 2)
    >>> area = Q(10., meter) * Q(10., meter)
    >>> print area
    100.0 m.m
    >>> print area.as_unit(square_meter)
    100.0 m²

    Given an unit U defined by the conversion factor (s, o).
    To convert a value x from the base unit to this unit, we must convert x from
    the base unit to U and then from U to this unit.
       (x / s + o) ** exponent

    We want to determine the conversion factor (S, O) such that x ** exponent / S + O
    converts x from the base unit to this unit. It must be an expression with
    x ** exponent to ensure commensurability but it is not possible to find such
    a conversion factor if the offset is not null.
     = (x / s) ** exponent and offset == 0
     = x ** exponent / s ** exponent + 0. and offset == 0
    thus S = s ** exponent, O = 0.

    """

    def __init__(self, symbol, unit, exponent):
        super(ExponentUnit, self).__init__(symbol)
        self.__unit = unit
        self.__exponent = exponent

    @property
    def symbol(self):
        if self._symbol is None:
            self._symbol = '(' + self.__unit.symbol + ')^' + str(self.__exponent)
        return self._symbol

    def _has_metre_radian(self):
        return self.__unit._has_metre_radian()

    def _init_dimensions(self):
        self._dimensions = dict([(t, self.__exponent * c) for (t, c) in self.__unit.dimensions.items()])

    def scale(self):
        return self.__unit.scale() ** self.__exponent

    def offset(self):
        if self.__unit.offset() != 0.:
            raise ArithmeticError("Can't exponentiate an unit with an offset")
        return 0.


class MultipliesUnit(Unit):

    """Unit defined by the product of two units.

    Example:
    >>> from gamme.units import Unit as U, ExponentUnit as E
    >>> from gamme.units import MultipliesUnit as M, Quantity as Q
    >>> kilogram = U('kg')
    >>> meter = U('m')
    >>> second = U('s')
    >>> newton = M('N', kilogram, M(None, meter, E(None, second, -2)))
    >>> force = Q(1., kilogram) * Q(1., meter) / Q(2., second) ** 2
    >>> print force
    0.25 kg.m.((s)^2)^-1
    >>> print force.as_unit(newton)
    0.25 N

    Given an unit U1 defined by the conversion factor (s1, o1) and an unit U2
    defined by the conversion factor (s2, o2). We create a value z in this unit
    by multiplying a value y1 expressed in U1 by a value y2 expressed in U2.
       y1 * y2
     = (x1 / s1 + o1) * (x2 / s2 + o2)
     = (x1 * x2 / (s1 * s2) + o2 * x1 / s1 + o1 * x2 / s2 + o1 * o2
    This expression is commensurable with U1.U2 if both offsets are null.

    We want to determine the conversion factor (S, O) such that x1 * x2 / S + O
    converts z from this unit to the base unit.
     = x1 * x2 / (s1 * s2) + 0. and o1 == 0 and o2 == 0
    thus S = s1 * s2, O = 0.

    """

    def __init__(self, symbol, unit1, unit2):
        super(MultipliesUnit, self).__init__(symbol)
        self.__unit1 = unit1
        self.__unit2 = unit2

    @property
    def symbol(self):
        if self._symbol is None:
            self._symbol = self.__unit1.symbol + '.' + self.__unit2.symbol
        return self._symbol

    def _has_metre_radian(self):
        return self.__unit1._has_metre_radian() or self.__unit2._has_metre_radian()

    def _init_dimensions(self):
        self._dimensions = copy.copy(self.__unit1.dimensions)
        for k,v in self.__unit2.dimensions.items():
            try:
                self._dimensions[k] += v
                if self._dimensions[k] == 0:
                    del self._dimensions[k]
            except KeyError:
                self._dimensions[k] = v

    def scale(self):
        return self.__unit1.scale() * self.__unit2.scale()

    def offset(self):
        if self.__unit1.offset() != 0. or self.__unit2.offset() != 0:
            raise ArithmeticError("Can't multiply units with an offset")
        return 0.


@total_ordering
class Quantity(object):

    """Quantity class represents a physical quantity with a value and an unit.

    It is possible to add and subtract quantities if their units are
    commensurable, multiply or divide them and apply some mathematical
    operations on it (pow...). A quantity can be converted to another unit.

    """

    def __init__(self, value, unit=None):
        """Build a Quantity object.

        Args:
            value (float): value
            unit (str): an ASCII symbol representing the unit
            unit (unicode): a unicode symbol representing the unit
            unit (Unit): an unit

        ASCII or unicode texts are symbols of units registered
        through a UnitsDict instance.

        """
        if unit is None:
            assert isinstance(value, str) or (sys.version_info.major == 2 and isinstance(value, unicode))
            values = value.split()
            if len(values) != 2:
                raise ValueError("Can't decode " + value + " to build a quantity")
            self.__value = float(values[0])
            unit = values[1]
        else:
            self.__value = value
        if isinstance(unit, str) or (sys.version_info.major == 2 and isinstance(unit, unicode)):
            unit = _find_unit(unit)
        self.__unit = unit

    @classmethod
    def value_of(cls, s):
        if isinstance(s, Quantity):
            return s
        return Quantity(s)

    @classmethod
    def to_json(cls, q):
        if q is None:
            return None
        return str(q)

    def __copy__(self):
        """Return a copy of this object."""
        return Quantity(self.__value, self.__unit)

    def __deepcopy__(self, memo):
        """Return a deep copy of this object."""
        return Quantity(self.__value, self.__unit)

    def value(self, unit=None):
        """Return the value of this object."""
        if unit is None:
            warnings.simplefilter('always', DeprecationWarning)
            warnings.warn("The use of value() without any argument is deprecated. Please, specify the unit.".format(__name__),
                          category=DeprecationWarning,
                          stacklevel=2
                          )
            warnings.simplefilter('default', DeprecationWarning)
            return self.__value
        else:
            return self.as_unit(unit).__value

    @property
    def unit(self):
        """Return the unit of this object."""
        return self.__unit

    def __hash__(self):
        return (self.__value, self.__unit).__hash__()

    def __str__(self):
        if sys.version_info.major == 2:
            return unicode(self).encode(sys.stdout.encoding or 'utf-8', 'replace')
        else:
            return self.__unicode__()

    def __unicode__(self):
        return str(self.__value) + u' ' + self.unit.symbol

    def __format__(self, spec):
        return format(self.__value, spec) + u' ' + self.unit.symbol

    def __repr__(self):
        if sys.version_info.major == 2:
            return '<gamme.units.Quantity ' + str(self.__value) + ' ' + self.unit.symbol.encode(sys.stdout.encoding or 'utf-8', 'replace') + '>'
        else:
            return '<gamme.units.Quantity ' + str(self.__value) + ' ' + self.unit.symbol + '>'

    def __add(self, other, sign1, sign2):
        """Private method to add or subtract quantities according to signs.

        Args:
            other (Quantity): right operand
            sign1 (int): sign to apply at the left operand
            sign2 (int): sign to apply at the right operand

        Raises
            TypeError

        """
        q = other.as_unit(self.unit)
        q.__value = sign1 * self.__value + sign2 * q.__value
        return q

    def __add__(self, other):
        assert isinstance(other, Quantity)
        return self.__add(other, 1, 1)

    __radd__ = __add__

    def __sub__(self, other):
        return self.__add(other, 1, -1)

    def __rsub__(self, other):
        return self.__add(other, -1, 1)

    def __eq__(self, other):
        if isinstance(other, Quantity):
            diff = self.__sub__(other)
            return abs(diff.__value) < 1e-10
        else:
            return False

    def __ne__(self, other):
        return not self.__eq__(other)

    def __cmp__(self, other):
        diff = self.__sub__(other)
        return cmp(diff.__value, 0.)

    def __lt__(self, other):
        diff = self.__sub__(other)
        return diff.__value < 0.

    def __mul__(self, other):
        if isinstance(other, Quantity):
            value = self.__value * other.__value
            unit = MultipliesUnit(None, self.unit, other.unit)
            unit = _find_unit_or_keep_this_one(unit)
        else:
            value = self.__value * other
            unit = self.unit
        if self.is_angle() and (self.unit._has_metre_radian() or other.unit._has_metre_radian()):
            return Quantity(value, unit)
        elif unit.is_dimension_less():
            return value * unit.scale() + unit.offset()
        else:
            return Quantity(value, unit)

    __rmul__ = __mul__

    def __div__(self, other):
        if isinstance(other, Quantity):
            value = self.__value / other.__value
            unit = MultipliesUnit(None, self.unit, ExponentUnit(None, other.unit, -1))
            unit = _find_unit_or_keep_this_one(unit)
        else:
            value = self.__value / other
            unit = self.unit
        if unit.is_angle() and (self.unit._has_metre_radian() or other.unit._has_metre_radian()):
            return Quantity(value, unit)
        elif unit.is_dimension_less():
            return value * unit.scale() + unit.offset()
        else:
            return Quantity(value, unit)

    __truediv__ = __div__

    def __floordiv__(self, other):
        if isinstance(other, Quantity):
            other = other.as_unit(self.unit)
            return self.__value // other.__value
        else:
            raise TypeError('Floor division is only between commensurable quantities')

    def __rdiv__(self, other):
        if isinstance(other, Quantity):
            value = other.__value / self.__value
            unit = MultipliesUnit(None, other.unit, ExponentUnit(None, self.unit, -1))
            unit = _find_unit_or_keep_this_one(unit)
        else:
            value = other / self.__value
            unit = ExponentUnit(None, self.unit, -1)
            unit = _find_unit_or_keep_this_one(unit)
        if self.is_angle() and (self.unit._has_metre_radian() or other.unit._has_metre_radian()):
            return Quantity(value, unit)
        elif unit.is_dimension_less():
            return value * unit.scale() + unit.offset()
        else:
            return Quantity(value, unit)

    __rtruediv__ = __rdiv__

    def __pos__(self):
        return self

    def __neg__(self):
        return Quantity(-self.__value, self.unit)

    def __pow__(self, exponent):
        value = self.__value ** exponent
        unit = ExponentUnit(None, self.unit, exponent)
        unit = _find_unit_or_keep_this_one(unit)
        return Quantity(value, unit)

    def __abs__(self):
        return Quantity(abs(self.__value), self.unit)

    def sqrt(self):
        value = math.sqrt(self.__value)
        unit = ExponentUnit(None, self.unit, 1. / 2)
        unit = _find_unit_or_keep_this_one(unit)
        return Quantity(value, unit)

    def is_angle(self):
        return self.unit.is_angle()

    def cos(self):
        if self.is_angle():
            return math.cos(self.as_unit(_get_angle_unit()).__value)
        else:
            raise TypeError('Argument of cos must be an angle')

    def sin(self):
        if self.is_angle():
            return math.sin(self.as_unit(_get_angle_unit()).__value)
        else:
            raise TypeError('Argument of sin must be an angle')

    def tan(self):
        if self.is_angle():
            return math.tan(self.as_unit(_get_angle_unit()).__value)
        else:
            raise TypeError('Argument of tan must be an angle')

    def convert_to_unit(self, unit):
        """Convert this quantity to another unit.

        If unit is not commensurable to the unit of this quantity,
        an exception TypeError is raised.

        Args:
            unit (Unit): unit to which this quantity must be converted.

        Raises:
            TypeError

        """
        unit = _find_unit(unit)
        (s, o) = self.unit.conversion_factor(unit)
        self.__value = s * (self.__value - o)
        self.__unit = unit

    def as_unit(self, unit):
        """Return a copy of this quantity converted to another unit."""
        quantity = self.__copy__()
        quantity.convert_to_unit(unit)
        return quantity


_units = {}
_rad_unit = None
_metre_radian_unit = None

def _add_unit(unit):
    symbol = unit.symbol
    if symbol in _units:
        raise KeyError("An unit with symbol %s has already been registered" % symbol)
    _units[symbol] = unit

def _find_unit(symbol):
    if isinstance(symbol, Unit):
        for u in _units.values():
            if symbol == u:
                return u
        return None
    else:
        name = symbol.strip()
        return _units[name]

def _find_unit_or_keep_this_one(unit):
    new_unit = _find_unit(unit)
    return new_unit is None and unit or new_unit;

def _get_angle_unit():
    global _rad_unit
    if _rad_unit is None:
        _rad_unit = _find_unit('rad')
        if _rad_unit is None:
            raise RuntimeError("Can't find a radian unit (symbol 'rad')")
    return _rad_unit

def _get_metre_radian_unit():
    global _metre_radian_unit
    if _metre_radian_unit is None:
        _metre_radian_unit = _find_unit('metrerad')
        if _metre_radian_unit is None:
            raise RuntimeError("Can't find a metreradian unit (symbol 'metrerad')")
    return _metre_radian_unit

class UnitsDict(type):

    """Unit dictionary

    An unit dictionary allows useful operations with quantities.
    - a quantity can be built with the symbol of an unit
    - when multiplying or dividing quantities, an anonymous unit is built.
    Thanks to an unit dictionary, this unit can be replaced by a known unit.

    Example:
    >>> f
    >>> from gamme.units import Unit, ScaleUnit, MultipliesUnit, ExponentUnit
    >>> class Units(object):
            __metaclass__ = UnitsDict
            meter = Unit('m')
            nautical_mile = ScaleUnit('NM', meter, 1852.)
            hour = Unit('h')
            knot = MultipliesUnit('kt', nautical_mile, ExponentUnit(None, hour, -1))
    >>> d = Q(20., 'NM')
    >>> t = Q(0.5, 'h')
    >>> v = d / t
    >>> print v
    40.0 kt

    """

    def __new__(cls, name, parent, attributes):
        for name, attr in attributes.items():
            if isinstance(attr, Unit):
                _add_unit(attr)
        return super(UnitsDict, cls).__new__(cls, name, parent, attributes)

    def __setattr__(metacls, name, value): #@NoSelf
        if name in metacls.__dict__:
            raise KeyError("Can't rebind unit %s" % name)
        metacls.__dict__[name] = value
