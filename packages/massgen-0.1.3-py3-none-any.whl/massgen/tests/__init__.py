"""
MassGen Tests

Test suite for MassGen functionality including:
- Basic agent functionality
- Tool handling
- Orchestrator coordination
- Multi-agent scenarios
- Frontend displays
"""
