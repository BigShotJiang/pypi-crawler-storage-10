# -*- coding: utf-8 -*-
"""Basic tools."""

from ._two_num_tool import two_num_tool

__all__ = [
    "two_num_tool",
]
