# -*- coding: utf-8 -*-
"""Utility functions for adapters."""
