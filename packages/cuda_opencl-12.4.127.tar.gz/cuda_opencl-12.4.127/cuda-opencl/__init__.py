"""
cuda-opencl - A useful Python package
"""

def hello_world():
    """A simple greeting function"""
    return "Hello from cuda-opencl!"

def add_numbers(a, b):
    """Add two numbers together"""
    return a + b

def get_package_info():
    """Return basic package information"""
    return {
        "name": "cuda-opencl",
        "version": "12.4.127",
        "description": "A useful Python package"
    }

# Package version
__version__ = "12.4.127"
