# cuda-opencl

A useful Python package with utility functions.

## Installation

```bash
pip install cuda-opencl
```

## Usage

```python
import cuda-opencl

print(cuda-opencl.hello_world())
result = cuda-opencl.add_numbers(5, 3)
print(result)
```
