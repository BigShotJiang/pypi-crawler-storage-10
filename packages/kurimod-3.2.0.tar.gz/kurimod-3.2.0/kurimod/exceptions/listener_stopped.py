class ListenerStopped(Exception):
    pass
