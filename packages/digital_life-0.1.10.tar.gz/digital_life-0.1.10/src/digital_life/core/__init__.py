from .biography import BiographyGenerate
from .digital_avatar import DigitalAvatar
from .memorycard import MemoryCardManager
from .chat import ChatBox