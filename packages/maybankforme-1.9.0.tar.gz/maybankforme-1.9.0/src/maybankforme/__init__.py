"""Maybank For Me - Credit card statement PDF to CSV converter.

This package provides tools for converting Maybank credit card statement
PDF files to CSV format, available as both a CLI tool and a web API.
"""

from ._version import __version__  # noqa: F401

__all__ = ["__version__"]
