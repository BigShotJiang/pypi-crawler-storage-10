from .monkey_patch import apply_liger_kernel_to_qwen2_audio

__all__ = ["apply_liger_kernel_to_qwen2_audio"]
