Getting Started
===============

Learn how to set up and use LMMs Engine for your first training job.

.. toctree::
   :maxdepth: 2

   introduction
   quick_start
   train
