# Performance Optimization

## Flash Attention Installation

```bash
cd ~

git clone https://github.com/Dao-AILab/flash-attention.git

cd hopper
python setup.py install
```