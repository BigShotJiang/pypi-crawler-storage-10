Reference
=========

API reference and technical documentation.

.. toctree::
   :maxdepth: 2

   api
   design_principle
   video_configuration
