Models
======

Documentation for available models and model architectures.

.. toctree::
   :maxdepth: 2

   bagel
   qwenvl
