
app_requires = [
    "django_static_fontawesome",
]
