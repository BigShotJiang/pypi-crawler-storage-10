# HTMX Theme (Coming in v0.67.0)

This theme is not yet implemented. It will include:

- HTMX for dynamic interactions without heavy JavaScript
- Alpine.js for lightweight reactivity
- Modern CSS with Tailwind (optional)
- Server-side rendering with Django templates

**Status**: Planned for release v0.67.0

**To use**: This theme will be available via `quickscale init myproject --theme starter_htmx`
