.. include:: ../refs.rst

.. _user_manual:

===========
User Manual
===========

.. todo::

    User manual intro

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   organization
   permissions
   howto
