.. include:: ../../refs.rst

.. autoclass:: slm.defines.SiteLogStatus
   :members:
   :undoc-members:
   :show-inheritance:
