.. include:: ../../refs.rst

.. autoclass:: slm.defines.EquipmentState
   :members:
   :undoc-members:
   :show-inheritance:
