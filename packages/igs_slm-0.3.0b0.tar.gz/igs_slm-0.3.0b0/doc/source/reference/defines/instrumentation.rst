.. include:: ../../refs.rst

.. autoclass:: slm.defines.Instrumentation
   :members:
   :undoc-members:
   :show-inheritance:
