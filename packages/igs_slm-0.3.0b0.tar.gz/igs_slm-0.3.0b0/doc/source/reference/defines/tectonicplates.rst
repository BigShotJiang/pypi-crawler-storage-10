.. include:: ../../refs.rst

.. autoclass:: slm.defines.TectonicPlates
   :members:
   :undoc-members:
   :show-inheritance:
