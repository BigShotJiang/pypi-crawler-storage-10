.. include:: ../../refs.rst

.. autoclass:: slm.defines.GeodesyMLVersion
   :members:
   :undoc-members:
   :show-inheritance:
