.. include:: ../../refs.rst

.. autoclass:: slm.defines.AntennaFeatures
   :members:
   :undoc-members:
   :show-inheritance:
