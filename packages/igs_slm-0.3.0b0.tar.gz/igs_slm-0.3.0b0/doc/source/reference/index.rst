.. include:: ../refs.rst

.. _reference:

=========
Reference
=========

.. automodule:: slm


.. toctree::
   :maxdepth: 2
   :caption: Modules:

   settings
   ./defines/index
   signals
   validators
