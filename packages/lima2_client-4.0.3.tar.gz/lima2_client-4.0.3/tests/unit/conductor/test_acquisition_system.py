# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

"""Test suite for the acquisition system module (lima2/conductor/acquisition_system.py)"""

import asyncio
import json
from unittest.mock import Mock
from uuid import UUID, uuid1

import pytest

from lima2.common.exceptions import (
    Lima2BackendError,
    Lima2BadCommand,
    Lima2Conflict,
    Lima2NotFound,
    Lima2ParamError,
)
from lima2.common.progress_counter import ProgressCounter
from lima2.common.state import DeviceState, RunState, State
from lima2.conductor import processing
from lima2.conductor.acquisition_system import AcquisitionSystem, DisconnectedError
from lima2.conductor.processing import failing, legacy, smx, xpcs
from lima2.conductor.processing.pipeline import PipelineErrorEvent
from lima2.conductor.topology import DynamicDispatch, RoundRobin

from .mock_devices import MockControl, MockPipeline, MockReceiver


@pytest.fixture
def control():
    return MockControl()


receiver_factory = pytest.mark.parametrize(
    "receiver_factory",
    [
        # NOTE: we have to wrap a lambda around the receivers
        # so that they are instantiated once every test.
        lambda: [MockReceiver(idx=i) for i in range(1)],
        lambda: [MockReceiver(idx=i) for i in range(4)],
        lambda: [MockReceiver(idx=i) for i in range(9)],
        lambda: [MockReceiver(idx=i) for i in range(16)],
    ],
)


@pytest.mark.asyncio
@receiver_factory
async def test_system_ping_all(control, receiver_factory):
    receivers = receiver_factory()
    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=RoundRobin(
            num_receivers=len(receivers), ordering=list(range(len(receivers)))
        ),
        tango_timeout_s=1,
    )

    await system.ping_all()


@pytest.mark.asyncio
@receiver_factory
async def test_system_ping_all_error(control, receiver_factory):
    receivers = receiver_factory()
    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=RoundRobin(
            num_receivers=len(receivers), ordering=list(range(len(receivers)))
        ),
        tango_timeout_s=1,
    )

    receivers[0].connected = False
    with pytest.raises(DisconnectedError):
        await system.ping_all()


@pytest.mark.asyncio
@receiver_factory
async def test_system_device_states(control, receiver_factory):
    receivers = receiver_factory()
    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=RoundRobin(
            num_receivers=len(receivers), ordering=list(range(len(receivers)))
        ),
        tango_timeout_s=1,
    )

    assert control.state == DeviceState.IDLE
    assert all([rcv.state == DeviceState.IDLE for rcv in receivers])

    states = await system.device_states()

    assert states == [DeviceState.IDLE for dev in [control, *receivers]]

    control.connected = False
    states = await system.device_states()

    assert states == [DeviceState.OFFLINE] + [DeviceState.IDLE] * len(receivers)


@pytest.mark.asyncio
@receiver_factory
async def test_system_state(control, receiver_factory):
    receivers = receiver_factory()
    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=RoundRobin(
            num_receivers=len(receivers), ordering=list(range(len(receivers)))
        ),
        tango_timeout_s=1,
    )

    state = await system.state()
    assert state == State.IDLE

    receivers[0].connected = False
    state = await system.state()
    assert state == State.DISCONNECTED


def mock_pipeline_from_uuid(uuid, topology, tango_timeout_s):
    return MockPipeline()


@pytest.mark.asyncio
async def test_system_user_command():
    class MockAcqSys:
        def __init__(self):
            self.user_lock = asyncio.Lock()
            self._state = State.IDLE

        async def state(self) -> State:
            return self._state

    @AcquisitionSystem.user_command(allowed_states=[State.PREPARED])
    async def salute(self):
        return "👋"

    acqsys = MockAcqSys()

    with pytest.raises(Lima2BadCommand):
        await salute(acqsys)

    acqsys._state = State.PREPARED
    assert await salute(acqsys) == "👋"

    # Concurrency protection
    with pytest.raises(Lima2Conflict):
        async with acqsys.user_lock:
            await salute(acqsys)


@pytest.mark.asyncio
@receiver_factory
async def test_system_prepare(control, receiver_factory, monkeypatch):
    receivers = receiver_factory()
    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=RoundRobin(
            num_receivers=len(receivers), ordering=list(range(len(receivers)))
        ),
        tango_timeout_s=1,
    )

    monkeypatch.setattr(processing, "from_uuid", mock_pipeline_from_uuid)
    mock_finalize_params = Mock()
    monkeypatch.setattr(legacy, "finalize_params", mock_finalize_params)

    ctl_params = {"prepare_fail": False, "start_fail": False}
    acq_params = {"acq": {"nb_frames": 1337}}
    proc_params = {
        "🍉": {"filename_rank": 0},
        "statistics": {},
        "profiles": {},
        "class_name": "LimaProcessingLegacy",
    }

    acq_id = await system.prepare(
        ctl_params=ctl_params,
        acq_params=acq_params,
        proc_params=proc_params,
    )

    assert await system.state() == State.PREPARED
    assert isinstance(system.current_pipeline, MockPipeline)

    await system.current_pipeline.signal_error(
        PipelineErrorEvent(uuid=acq_id, device_name="cafe", error_msg="oh no")
    )
    assert system.runstate & RunState.PROC_EXCEPTION
    system.runstate ^= RunState.PROC_EXCEPTION

    await system.current_pipeline.signal_finished(errors=[])
    assert system.runstate & RunState.PROC_DONE
    system.runstate ^= RunState.PROC_DONE

    await system.current_pipeline.signal_finished(errors=["nonono"])
    assert system.runstate == RunState.IDLE


@pytest.mark.asyncio
@receiver_factory
async def test_system_prepare_raw_save(control, receiver_factory, monkeypatch):
    receivers = receiver_factory()
    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=DynamicDispatch(num_receivers=len(receivers)),
        tango_timeout_s=1,
    )

    monkeypatch.setattr(processing, "from_uuid", mock_pipeline_from_uuid)

    for proc_name, proc_module in (
        ("LimaProcessingLegacy", legacy),
        ("LimaProcessingXpcs", xpcs),
        ("LimaProcessingSmx", smx),
        ("LimaProcessingFailing", failing),
    ):
        mock_finalize = Mock()
        monkeypatch.setattr(proc_module, "finalize_params", mock_finalize)

        ctl_params = {"prepare_fail": False, "start_fail": False}
        acq_params = {"acq": {"nb_frames": 1337}, "saving": {"???": 123}}
        proc_params = {
            "🍉": {"filename_rank": 0},
            "statistics": {},
            "profiles": {},
            "class_name": proc_name,
        }
        await system.prepare(
            ctl_params=ctl_params,
            acq_params=acq_params,
            proc_params=proc_params,
        )
        assert len(mock_finalize.mock_calls) == len(receivers)


@pytest.mark.asyncio
@receiver_factory
async def test_system_prepare_validation_error(control, receiver_factory, monkeypatch):
    receivers = receiver_factory()

    def mock_schema():
        return json.dumps(
            {"properties": {"cafe": {"type": "integer"}}, "required": ["cafe"]}
        )

    monkeypatch.setattr(processing, "from_uuid", mock_pipeline_from_uuid)
    mock_finalize = Mock()
    monkeypatch.setattr(legacy, "finalize_params", mock_finalize)

    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=RoundRobin(
            num_receivers=len(receivers), ordering=list(range(len(receivers)))
        ),
        tango_timeout_s=1,
    )

    ctl_params = {"prepare_fail": False, "start_fail": False}
    acq_params = {"acq": {"nb_frames": 1337}}
    proc_params = {
        "🍉": {"filename_rank": 0},
        "statistics": {},
        "profiles": {},
        "class_name": "LimaProcessingLegacy",
    }

    # Control param validation error
    with monkeypatch.context() as mpatch:
        mpatch.setattr(control, "fetch_params_schema", mock_schema)
        with pytest.raises(Lima2ParamError) as e:
            await system.prepare(
                ctl_params=ctl_params,
                acq_params=acq_params,
                proc_params=proc_params,
            )
        assert "cafe" in str(e.value)
        assert "control params" in str(e.value)

    # Receiver param validation error
    with monkeypatch.context() as mpatch:
        mpatch.setattr(receivers[-1], "fetch_params_schema", mock_schema)
        with pytest.raises(Lima2ParamError) as e:
            await system.prepare(
                ctl_params=ctl_params,
                acq_params=acq_params,
                proc_params=proc_params,
            )
        assert "cafe" in str(e.value)
        assert f"acquisition params for receiver {len(receivers) - 1}" in str(e.value)

    # Processing param validation error
    with monkeypatch.context() as mpatch:

        def mock_proc_schema(proc_class):
            return json.dumps(
                {"properties": {"cafe": {"type": "integer"}}, "required": ["cafe"]}
            )

        mpatch.setattr(receivers[-1], "fetch_proc_schema", mock_proc_schema)
        with pytest.raises(Lima2ParamError) as e:
            await system.prepare(
                ctl_params=ctl_params,
                acq_params=acq_params,
                proc_params=proc_params,
            )
        assert "cafe" in str(e.value)
        assert f"processing params for receiver {len(receivers) - 1}" in str(e.value)


@pytest.mark.asyncio
@receiver_factory
async def test_system_prepare_fail(control, receiver_factory, monkeypatch):
    receivers = receiver_factory()
    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=RoundRobin(
            num_receivers=len(receivers), ordering=list(range(len(receivers)))
        ),
        tango_timeout_s=1,
    )

    monkeypatch.setattr(processing, "from_uuid", mock_pipeline_from_uuid)
    mock_finalize_params = Mock()
    monkeypatch.setattr(legacy, "finalize_params", mock_finalize_params)

    ctl_params = {"prepare_fail": True, "start_fail": False}
    acq_params = {}
    proc_params = {"🍉": {"filename_rank": 0}, "class_name": "LimaProcessingLegacy"}

    with pytest.raises(Lima2BackendError):
        await system.prepare(
            ctl_params=ctl_params,
            acq_params=acq_params,
            proc_params=proc_params,
        )

    assert await system.state() == State.IDLE
    assert system.current_pipeline is None


@pytest.mark.asyncio
@receiver_factory
async def test_system_start(control, receiver_factory):
    receivers = receiver_factory()
    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=RoundRobin(
            num_receivers=len(receivers), ordering=list(range(len(receivers)))
        ),
        tango_timeout_s=1,
    )

    for dev in [control, *receivers]:
        dev.state = DeviceState.PREPARED

    system.current_pipeline = MockPipeline()

    await system.start()
    assert await system.state() == State.RUNNING
    assert system.runstate == RunState.RUNNING


@pytest.mark.asyncio
@receiver_factory
async def test_system_start_fail(control, receiver_factory):
    receivers = receiver_factory()
    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=RoundRobin(
            num_receivers=len(receivers), ordering=list(range(len(receivers)))
        ),
        tango_timeout_s=1,
    )

    for dev in [control, *receivers]:
        dev.state = DeviceState.PREPARED

    system.current_pipeline = MockPipeline()

    receivers[0].fail_on_start = True
    with pytest.raises(Lima2BackendError):
        await system.start()


@pytest.mark.asyncio
@receiver_factory
async def test_system_trigger(control, receiver_factory):
    receivers = receiver_factory()
    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=RoundRobin(
            num_receivers=len(receivers), ordering=list(range(len(receivers)))
        ),
        tango_timeout_s=1,
    )

    assert system.runstate == RunState.IDLE
    await system.trigger()
    assert control.num_triggers == 0  # ignored (not running)

    system.runstate = RunState.RUNNING
    await system.trigger()
    assert control.num_triggers == 1


@pytest.mark.asyncio
@receiver_factory
async def test_system_reset(control, receiver_factory):
    receivers = receiver_factory()
    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=RoundRobin(
            num_receivers=len(receivers), ordering=list(range(len(receivers)))
        ),
        tango_timeout_s=1,
    )

    for dev in [control, *receivers]:
        dev.state = DeviceState.FAULT

    system.runstate = RunState.RUNNING
    await system.reset()
    assert system.runstate == RunState.IDLE

    assert all([dev.state == DeviceState.IDLE for dev in [control, *receivers]])


@pytest.mark.asyncio
@receiver_factory
async def test_system_stop(control, receiver_factory):
    receivers = receiver_factory()
    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=RoundRobin(
            num_receivers=len(receivers), ordering=list(range(len(receivers)))
        ),
        tango_timeout_s=1,
    )
    system.current_pipeline = MockPipeline()

    control.state = DeviceState.RUNNING
    receivers[0].state = DeviceState.RUNNING
    system.runstate = RunState.RUNNING

    await system.stop()

    assert control.state == DeviceState.STOPPED
    assert receivers[0].state == DeviceState.IDLE


@pytest.mark.asyncio
@receiver_factory
async def test_system_abort(control, receiver_factory):
    receivers = receiver_factory()
    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=RoundRobin(
            num_receivers=len(receivers), ordering=list(range(len(receivers)))
        ),
        tango_timeout_s=1,
    )
    system.current_pipeline = MockPipeline()

    control.state = DeviceState.RUNNING
    receivers[0].state = DeviceState.RUNNING
    system.runstate = RunState.RUNNING

    await system.update_runstate(event=RunState.PROC_EXCEPTION)
    for rcv in receivers:
        assert rcv.state == DeviceState.IDLE
    assert control.state == DeviceState.STOPPED


@pytest.mark.asyncio
@receiver_factory
async def test_system_update_runstate(control, receiver_factory):
    receivers = receiver_factory()
    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=RoundRobin(
            num_receivers=len(receivers), ordering=list(range(len(receivers)))
        ),
        tango_timeout_s=1,
    )
    system.current_pipeline = MockPipeline()

    control.state = DeviceState.RUNNING
    system.runstate = RunState.RUNNING

    await system.update_runstate(RunState.ACQ_DONE)
    await system.update_runstate(RunState.PROC_DONE)

    assert control.state == DeviceState.IDLE

    await system.update_runstate(RunState.ACQ_EXCEPTION)
    assert system.runstate & RunState.FAULT

    system.runstate = RunState.RUNNING
    await system.update_runstate(RunState.PROC_EXCEPTION)
    assert system.runstate & RunState.FAULT

    # ACQ_DONE after FAULT
    control.state = DeviceState.RUNNING
    system.runstate = RunState.RUNNING
    await system.update_runstate(RunState.PROC_EXCEPTION)
    await system.update_runstate(RunState.ACQ_DONE)
    assert control.state == DeviceState.IDLE

    # PROC_DONE after ACQ_EXCEPTION
    system.runstate = RunState.ACQ_FAILED
    await system.update_runstate(RunState.PROC_DONE)
    assert system.runstate == RunState.FAULT


@pytest.mark.asyncio
@receiver_factory
async def test_system_get_pipeline(control, receiver_factory, monkeypatch):
    receivers = receiver_factory()
    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=RoundRobin(
            num_receivers=len(receivers), ordering=list(range(len(receivers)))
        ),
        tango_timeout_s=1,
    )

    acq_id0 = uuid1()
    pipeline = MockPipeline()
    system.cached_pipelines[acq_id0] = pipeline

    with pytest.raises(Lima2NotFound):
        await system.get_pipeline(uuid="current")

    assert await system.get_pipeline(uuid=acq_id0) == pipeline

    with pytest.raises(Lima2NotFound):
        await system.get_pipeline(uuid1())

    def mock_from_uuid(uuid, topology, tango_timeout_s) -> MockPipeline:
        p = MockPipeline(uuid, topology)
        return p

    monkeypatch.setattr(
        processing, "pipeline_classes", {"LimaProcessingMock": MockPipeline}
    )
    monkeypatch.setattr(processing, "from_uuid", mock_from_uuid)

    acq_id1 = uuid1()
    for rcv in receivers:
        rcv.pipelines.append(str(acq_id1))
    pipeline = await system.get_pipeline(acq_id1)

    assert pipeline == (await system.get_pipeline(str(acq_id1)))

    # Required because system.abort() calls current_pipeline.abort()
    system.current_pipeline = pipeline

    assert (await system.get_pipeline(uuid="current")).uuid == pipeline.uuid

    await pipeline.signal_error(
        evt=PipelineErrorEvent(uuid=acq_id1, device_name="cafe", error_msg="deca")
    )


@pytest.mark.asyncio
@receiver_factory
async def test_system_clear_pipelines(control, receiver_factory, monkeypatch):
    receivers = receiver_factory()
    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=RoundRobin(
            num_receivers=len(receivers), ordering=list(range(len(receivers)))
        ),
        tango_timeout_s=1,
    )

    def mock_from_uuid(uuid, topology, on_finished, on_error) -> MockPipeline:
        p = MockPipeline(uuid, topology, on_finished, on_error)
        return p

    # monkeypatch.setattr(pipelines, "pipeline_classes", {"LimaProcessingMock": MockPipeline})
    monkeypatch.setattr(processing, "from_uuid", mock_from_uuid)

    # Add some pipelines
    acq_ids = []
    for _ in range(5):
        acq_id = uuid1()
        acq_ids.append(acq_id)
        for rcv in receivers:
            rcv.pipelines.append(str(acq_id))
        pipeline = MockPipeline(uuid=acq_id)
        system.cached_pipelines[acq_id] = pipeline

    cleared = await system.clear_previous_pipelines()
    assert set(UUID(uuid) for uuid in cleared) == set(acq_ids)
    assert system.cached_pipelines == {}

    # Repeat with a current_pipeline
    for _ in range(5):
        acq_id = uuid1()
        for rcv in receivers:
            rcv.pipelines.append(str(acq_id))
        pipeline = MockPipeline(uuid=acq_id)
        system.cached_pipelines[acq_id] = pipeline

    # Take last acq_id as the current pipeline
    system.current_pipeline = system.cached_pipelines[acq_id]

    await system.clear_previous_pipelines()

    assert set(UUID(uuid) for uuid in cleared) == set(acq_ids) - set(
        [system.current_pipeline.uuid]
    )
    assert system.cached_pipelines == {
        system.current_pipeline.uuid: system.current_pipeline
    }


@pytest.mark.asyncio
@receiver_factory
async def test_system_info(control, receiver_factory):
    receivers = receiver_factory()
    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=RoundRobin(
            num_receivers=len(receivers), ordering=list(range(len(receivers)))
        ),
        tango_timeout_s=1,
    )

    assert await system.nb_frames_acquired() == await control.nb_frames_acquired()
    assert await system.nb_frames_xferred() == ProgressCounter(
        name="nb_frames_xferred",
        counters=[await rcv.nb_frames_xferred() for rcv in receivers],
    )
    assert await system.det_info() == await control.det_info()
    assert await system.det_status() == await control.det_status()
    assert await system.det_capabilities() == await control.det_capabilities()


@pytest.mark.asyncio
@receiver_factory
async def test_system_register_event_callbacks(control, receiver_factory):
    receivers = receiver_factory()
    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=RoundRobin(
            num_receivers=len(receivers), ordering=list(range(len(receivers)))
        ),
        tango_timeout_s=1,
    )
    system.current_pipeline = MockPipeline()

    await control.signal_state_change(new_state=DeviceState.TERMINATE)  # cover only

    system.runstate = RunState.RUNNING
    await receivers[0].signal_state_change(new_state=DeviceState.FAULT)  # aborts acq
    assert system.runstate & RunState.FAULT

    system.runstate = RunState.RUNNING
    assert system.finished_receivers == set()
    for rcv in receivers:
        await rcv.signal_state_change(new_state=DeviceState.IDLE)
        assert rcv in system.finished_receivers

    assert system.runstate & RunState.ACQ_DONE


@pytest.mark.asyncio
@receiver_factory
async def test_system_errors(control, receiver_factory):
    receivers = receiver_factory()
    system = AcquisitionSystem(
        control=control,
        receivers=receivers,
        topology=RoundRobin(
            num_receivers=len(receivers), ordering=list(range(len(receivers)))
        ),
        tango_timeout_s=1,
    )

    errors = await system.errors()
    assert len(errors) == len(receivers)
    for rcv, err in zip(receivers, errors, strict=True):
        assert rcv.name in err
        assert (await rcv.last_error()) in err
