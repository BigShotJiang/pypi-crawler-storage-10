# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.


"""
Test suite for the conductor /acquisition endpoints
(lima2/conductor/webservice/acquisition.py).
"""

import contextlib
import json
from typing import Any
from uuid import UUID, uuid1

import jsonschema_default
import pytest
from starlette.applications import Starlette
from starlette.testclient import TestClient

from lima2.common.exceptions import Lima2ValueError
from lima2.common.progress_counter import ProgressCounter, SingleCounter
from lima2.common.state import RunState
from lima2.conductor.webservice import acquisition


class MockAcquisitionSystem:
    def __init__(self):
        self.runstate = RunState.IDLE
        self.prepare_called = False
        self.start_called = False
        self.trigger_called = False
        self.stop_called = False
        self.reset_called = False

        class MockControl:
            def fetch_params_schema(self) -> str:
                return json.dumps(
                    {
                        "type": "object",
                        "properties": {"cafe": {"type": "string", "default": "deca"}},
                    }
                )

        class MockReceiver:
            def fetch_params_schema(self) -> str:
                return json.dumps(
                    {
                        "type": "object",
                        "properties": {"cafe": {"type": "string", "default": "1234"}},
                    }
                )

        self.control = MockControl()
        self.receivers = [MockReceiver()]

    async def prepare(
        self,
        ctl_params: dict[str, Any],
        acq_params: dict[str, Any],
        proc_params: dict[str, Any],
    ) -> UUID:
        self.prepare_called = True
        self.ctl_params = ctl_params
        self.acq_params = acq_params
        self.proc_params = proc_params
        return uuid1()

    async def start(self) -> None:
        self.start_called = True
        self.runstate = RunState.RUNNING

    async def trigger(self) -> None:
        self.trigger_called = True

    async def stop(self) -> None:
        self.stop_called = True
        self.runstate |= RunState.ACQ_DONE

    async def reset(self) -> None:
        self.reset_called = True
        self.runstate = RunState.IDLE

    async def nb_frames_acquired(self) -> SingleCounter:
        return SingleCounter(name="nb_frames_acquired", value=123, source="dev/control")

    async def nb_frames_xferred(self) -> ProgressCounter:
        return ProgressCounter(
            name="nb_frames_acquierd",
            counters=[
                SingleCounter(
                    name="nb_frames_xferred", value=42 + i, source=f"dev/receiver{i}"
                )
                for i in range(4)
            ],
        )

    async def errors(self) -> list[str]:
        return ["first error", "second error"]


@contextlib.asynccontextmanager
async def mock_lifespan(app: Starlette):
    lima2 = app.state.lima2
    yield {"lima2": lima2}


lima2 = MockAcquisitionSystem()
app = Starlette(routes=acquisition.routes, lifespan=mock_lifespan)
app.state.lima2 = lima2

ctl_params = {"hello": "world"}
acq_params = {"cafe": "deca"}
proc_params = {"bye": "now"}


def test_commands():
    """Test control route handlers."""

    with TestClient(app) as client:
        client.post(
            "/prepare",
            json={
                "uuid": str(uuid1()),
                "control": ctl_params,
                "receiver": acq_params,
                "processing": proc_params,
            },
        )
        assert client.get("/state").json() == {
            "name": RunState.IDLE.name,
            "value": RunState.IDLE.value,
        }
        client.post("/start")
        assert client.get("/state").json() == {
            "name": RunState.RUNNING.name,
            "value": RunState.RUNNING.value,
        }
        client.post("/trigger")

        client.post("/stop")
        assert client.get("/state").json() == {
            "name": RunState.WAITING_FOR_PROC.name,
            "value": RunState.WAITING_FOR_PROC.value,
        }
        client.post("/reset")
        assert client.get("/state").json() == {
            "name": RunState.IDLE.name,
            "value": RunState.IDLE.value,
        }

    assert lima2.prepare_called
    assert lima2.ctl_params == ctl_params
    assert lima2.acq_params == acq_params
    assert lima2.proc_params == proc_params

    assert lima2.start_called
    assert lima2.trigger_called
    assert lima2.stop_called
    assert lima2.reset_called


def test_control_prepare_missing_params():
    """Prepare with missing key."""

    with TestClient(app) as client:
        with pytest.raises(Lima2ValueError):
            _ = client.post(
                "/prepare",
                json={
                    "receiver": acq_params,
                    "processing": proc_params,
                },
            )


def test_params():
    with TestClient(app) as client:
        schema = client.get("/params_schema").json()
        params = client.get("/default_params").json()

        assert params["receiver"] == jsonschema_default.create_from(schema["receiver"])
        assert params["control"] == jsonschema_default.create_from(schema["control"])


def test_counters():
    with TestClient(app) as client:
        nb_frames_acquired = client.get("/nb_frames_acquired").json()
        nb_frames_xferred = client.get("/nb_frames_xferred").json()

    assert nb_frames_acquired == {
        "name": "nb_frames_acquired",
        "value": 123,
        "source": "dev/control",
    }

    for key in ("min", "max", "avg", "sum", "counters"):
        assert key in nb_frames_xferred


def test_errors():
    with TestClient(app) as client:
        errors = client.get("/errors").json()

    assert errors == ["first error", "second error"]
