# Detector

::: lima2.client.services.Detector
    options:
      show_root_heading: true
      show_if_no_docstring: true
      summary:
        modules: false
        functions: true
      filters:
      - "!^_"
      members_order: source
