.. _reference_guide_sec:

embeam reference guide
======================

.. autosummary::
   :toctree: _autosummary
   :template: custom_module_template.rst
   :recursive:

   embeam
