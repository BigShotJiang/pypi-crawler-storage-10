"""Onyx API enumerations."""
