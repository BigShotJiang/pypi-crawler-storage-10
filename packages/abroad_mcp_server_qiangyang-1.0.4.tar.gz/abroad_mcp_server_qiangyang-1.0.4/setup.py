"""
MCP框架安装脚本
"""
from setuptools import setup, find_packages
from pathlib import Path

# 兼容从任意工作目录执行构建：始终相对本文件定位 README
base_dir = Path(__file__).parent
readme_path = base_dir / "docs" / "README.md"
long_description = readme_path.read_text(encoding="utf-8") if readme_path.exists() else ""

setup(
    name="abroad-mcp-server-qiangyang",
    version="1.0.4",
    author="IFLYTEK",
    author_email="example@iflytek.com",
    description="一个规范、可扩展的MCP（Model Capability Protocol）工具开发框架",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/username/mcp_framework",
    # 重要：setup.py 位于包目录内，因此需用 package_dir 将当前目录映射为包根
    package_dir={"mcp_framework": "."},
    packages=[
        "mcp_framework",
        "mcp_framework.business",
        "mcp_framework.business.aigc",
        "mcp_framework.business.analysis",
        "mcp_framework.business.plans",
        "mcp_framework.business.flow",
        "mcp_framework.business.market",
        "mcp_framework.business.project",
        "mcp_framework.config",
        "mcp_framework.mcp_tools",
        "mcp_framework.utils",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.10",
    install_requires=[
        "mcp>=1.2.0",
        "httpx>=0.24.0",
        "loguru>=0.7.0",
    ],
    entry_points={
        "console_scripts": [
            "abroad-mcp-server=mcp_framework.mcp_server:run_mcp_server",
        ],
    },
) 