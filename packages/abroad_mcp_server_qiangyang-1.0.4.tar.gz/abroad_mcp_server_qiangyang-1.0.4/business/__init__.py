"""
业务逻辑模块 - 封装与DSP业务系统的交互
"""
from .api_client import api_client

# 避免在包导入阶段就急切导入子模块，防止循环依赖
# 需要时由各调用方显式导入具体子模块（如 business.plans、business.analysis 等）

__all__ = ['api_client', 'plans', 'analysis', 'project', 'flow', 'market']