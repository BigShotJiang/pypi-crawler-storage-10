"""
plans 包初始化
"""


