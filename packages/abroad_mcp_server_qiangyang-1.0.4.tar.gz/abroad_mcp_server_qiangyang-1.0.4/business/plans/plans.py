"""
引擎模块 - 计划相关业务逻辑
"""
from typing import Dict, Any, List, Optional
from loguru import logger

from mcp_framework.business.api_client import api_client

async def get_plan_info(plan_id: str) -> Dict[str, Any]:
    """获取计划详细配置信息
    
    Args:
        plan_id: 计划ID
        
    Returns:
        计划详情配置数据，包含以下信息：
        - 基本信息：ID、名称、状态、投放账号ID等
        - 投放设置：投放周期、时段、预算等
        - 出价信息：出价方式、出价、深度出价等
        - 定向设置：操作系统、地域、人群、媒体等
        - 监测设置：监测URL、Deeplink等
        - 创意信息：广告形式、模板等
    """
    params = {
        "id": plan_id
    }
    
    # 调用API客户端发送请求到新的接口
    result = await api_client.request("plans", "get", params)
    
    if not result.get("success"):
        logger.error(f"获取计划配置信息失败: {result.get('error')}")
    
    return result