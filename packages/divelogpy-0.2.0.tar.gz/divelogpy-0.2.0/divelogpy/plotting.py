"""Plotting helpers for dive visualisations."""

from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Iterable, List, Mapping, Sequence
from .filters import DiveFilter, SensorFilter, FilterOperators as _fo
import matplotlib.pyplot as plt

try:  # optional dependency
    import plotly.graph_objects as go
except ImportError:  # pragma: no cover - optional dependency
    go = None

import pandas as _pd
import numpy as np

from .models import Dive
import pandas as pd


@dataclass
class _ScaleField:
    field: str
    label: str | None = None
    color: str | None = None
    dash: str | None = None
    width: float | None = None


@dataclass
class _ScaleGroup:
    fields: List[_ScaleField]
    title: str | None = None
    side: str | None = None
    range: Sequence[float] | None = None
    axis: Mapping[str, object] | None = None


def _ensure_plotly():
    if go is None:  # pragma: no cover - depends on optional dependency
        raise RuntimeError("Plotly is required for interactive timeseries plotting. Install it with 'pip install plotly'.")


def _normalise_scale_groups(scale_groups: Sequence[object] | None) -> List[_ScaleGroup]:
    if not scale_groups:
        return []

    palette = [
        "#FF851B",
        "#FF4136",
        "#2ECC40",
        "#FFDC00",
        "#0074D9",
        "#B10DC9",
    ]

    palette_index = 0

    result: List[_ScaleGroup] = []
    for group in scale_groups:
        if isinstance(group, str):
            group_map: Mapping[str, object] = {"fields": [group]}
        elif isinstance(group, Mapping):
            group_map = group
        elif isinstance(group, Sequence) and not isinstance(group, (bytes, bytearray)):
            group_map = {"fields": list(group)}
        else:
            raise TypeError(
                "Each scale group must be a mapping of options, a list/tuple of field names, or a single field name."
            )

        raw_fields = group_map.get("fields")
        if not raw_fields:
            raise ValueError("Scale group requires a non-empty 'fields' list.")

        normalised_fields: List[_ScaleField] = []
        for payload in raw_fields:
            if isinstance(payload, str):
                payload_map = {"field": payload}
            elif isinstance(payload, Mapping):
                payload_map = dict(payload)
            else:
                raise TypeError("Scale group fields must be either field names or mapping descriptors.")

            field_name = payload_map.get("field")
            if not field_name:
                raise ValueError("Scale group field descriptors must include a 'field' entry.")

            color = payload_map.get("color")
            if color is None:
                color = palette[palette_index % len(palette)]
                palette_index += 1

            normalised_fields.append(
                _ScaleField(
                    field=field_name,
                    label=payload_map.get("label"),
                    color=color,
                    dash=payload_map.get("dash"),
                    width=payload_map.get("width"),
                )
            )

        result.append(
            _ScaleGroup(
                fields=normalised_fields,
                title=group_map.get("title"),
                side=group_map.get("side"),
                range=group_map.get("range"),
                axis=group_map.get("axis"),
            )
        )

    return result


import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

def plot_sensor_strip(
    df: pd.DataFrame,
    sensor_cols: tuple[str, str, str] = (
        "sensor1_millivolts",
        "sensor2_millivolts",
        "sensor3_millivolts",
    ),
    *,
    template: str = "plotly_dark",
    figure_title: str | None = "Lag-1 Scatter: Sensors",
    marker_size: int = 5,
    marker_opacity: float = 0.8,
    show_identity_line: bool = True,
    identity_line_width: int = 1,
    identity_line_dash: str = "dash",
) -> "go.Figure":
    """
    Plot 3-panel lag-1 scatter (y[t] vs y[t-1]) for the given sensor columns.

    Parameters
    ----------
    df:
        DataFrame containing sensor millivolt columns.
    sensor_cols:
        Tuple of exactly three column names (sensor1, sensor2, sensor3).
    template / figure_title:
        Plotly template and optional title.
    marker_* / identity_*:
        Styling for points and the y=x reference line.
    """

    # Basic column presence check (lightweight; fail fast)
    missing = [c for c in sensor_cols if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns in df: {', '.join(missing)}")

    # Build per-sensor lag-1 DataFrames and aggregate for global axis range
    lagged_frames = []
    all_x, all_y = [], []
    for c in sensor_cols:
        s = pd.to_numeric(df[c], errors="coerce")
        d = pd.DataFrame({"x": s.shift(1), "y": s}).dropna()
        lagged_frames.append((c, d))
        if not d.empty:
            all_x.append(d["x"].values)
            all_y.append(d["y"].values)

    # Global symmetric axis range across all panels
    if all_x:
        all_x = np.concatenate(all_x)
        all_y = np.concatenate(all_y)
        lim_min = float(np.nanmin([all_x.min(), all_y.min()]))
        lim_max = float(np.nanmax([all_x.max(), all_y.max()]))
        pad = 0.03 * (lim_max - lim_min if lim_max > lim_min else 1.0)
        axis_range = [lim_min - pad, lim_max + pad]
    else:
        axis_range = None

    fig = make_subplots(
        rows=1, cols=3,
        horizontal_spacing=0.06,
        subplot_titles=[c.replace("_", " ") for c in sensor_cols],
    )

    for i, (c, d) in enumerate(lagged_frames, start=1):
        # Scatter points
        fig.add_trace(
            go.Scatter(
                x=d["x"], y=d["y"],
                mode="markers",
                name=c, showlegend=False,
                marker=dict(size=marker_size, opacity=marker_opacity),
                hovertemplate=f"{c}[t-1]=%{{x:.6g}}<br>{c}[t]=%{{y:.6g}}<extra></extra>",
            ),
            row=1, col=i
        )

        # Identity line
        if show_identity_line and axis_range is not None:
            fig.add_trace(
                go.Scatter(
                    x=axis_range, y=axis_range,
                    mode="lines",
                    name="y = x",
                    line=dict(width=identity_line_width, dash=identity_line_dash),
                    hoverinfo="skip",
                    showlegend=(i == 1),  # show once
                ),
                row=1, col=i
            )

        # Correlation annotation in the subplot title
        if not d.empty and d["x"].std(ddof=1) > 0 and d["y"].std(ddof=1) > 0:
            rho = float(np.corrcoef(d["x"], d["y"])[0, 1])
            fig.layout.annotations[i-1].text = f"{c.replace('_',' ')} (ρ = {rho:.3f})"

        # Axes (equal aspect)
        fig.update_xaxes(
            title_text=f"{c}[t-1]",
            zeroline=False, showgrid=False,
            range=axis_range,
            row=1, col=i
        )
        fig.update_yaxes(
            title_text=f"{c}[t]" if i == 1 else None,
            zeroline=False, showgrid=False,
            scaleanchor=f"x{i}", scaleratio=1,
            range=axis_range,
            row=1, col=i
        )

    fig.update_layout(
        template=template,
        title=figure_title or "Lag-1 Scatter: Sensors",
        legend=dict(orientation="h", y=1.05, x=0.5, xanchor="center"),
        margin=dict(l=50, r=20, t=60, b=40),
    )
    return fig


def plot_timeseries(
    timeseries,
    *,
    include_depth: bool = True,
    depth_field: str | None = None,
    depth_label: str | None = None,
    depth_color: str = "#1f77b4",
    depth_fillcolor: str = "rgba(31, 119, 180, 0.25)",
    depth_side: str = "left",
    include_deco_ceiling: bool = False,
    deco_ceiling_units: str | None = None,
    deco_ceiling_color: str = "#FF4136",
    deco_ceiling_fillcolor: str = "rgba(255, 65, 54, 0.25)",
    scale_groups: Sequence[Mapping[str, object]] | None = None,
    template: str = "plotly_dark",
    time_units: str = "minutes",
    time_axis_label: str | None = None,
    figure_title: str | None = None,
) -> "go.Figure":
    """Render an interactive Plotly figure for a dive timeseries.

    Parameters
    ----------
    timeseries:
        Either a :class:`divelogpy.timeseries.DiveTimeSeries` instance or any
        object that exposes ``to_df`` with a matching signature.
    include_depth:
        When True (default) the depth trace is added as the primary axis.
    depth_field:
        Optional override for the depth column to display. When omitted the
        function prefers ``depth_ft`` then ``depth_m`` if present.
    depth_label:
        Custom axis label for depth. If omitted a label derived from the depth
        field is used.
    depth_color / depth_fillcolor:
        Styling for the depth trace and area fill.
    depth_side:
        Position of the depth axis (``'left'`` or ``'right'``).
    include_deco_ceiling:
        When True, overlay the decompression ceiling using the same depth axis.
    deco_ceiling_units:
        Optional override for the ceiling units (``'ft'``/``'m'``). Defaults to
        matching the depth axis when available.
    deco_ceiling_color / deco_ceiling_fillcolor:
        Styling for the deco ceiling trace and shaded area.
    scale_groups:
        Sequence describing additional y-axes. Each element may be one of:

        * A single field name (``"average_ppo2"``)
        * A list/tuple of field names (``["average_ppo2", "ppo2_setpoint"]``)
        * A mapping with ``fields`` and optional styling keys (``{"fields": [...], "title": "ppO₂"}``).

        Field descriptors within a mapping can override ``label``, ``color``,
        ``dash`` and ``width`` for each trace. Group-level options include
        ``title`` (axis label), ``side`` (``"left"``/``"right"``), ``range`` and
        ``axis`` (dict of raw Plotly axis layout overrides, e.g. ``{"overlaying": None}``).
        When omitted no additional axes are drawn.
    template:
        Plotly template, defaults to ``plotly_dark``.
    time_units:
        Units for the x-axis; either ``'minutes'`` (default) or ``'seconds'``.
    time_axis_label:
        Optional label for the x-axis. If omitted a label is derived from
        ``time_units``.
    figure_title:
        Optional figure title.
    """

    _ensure_plotly()

    groups = _normalise_scale_groups(scale_groups)

    df = _coerce_timeseries_dataframe(timeseries, None)
    available_set = set(df.reset_index().columns)


    depth_candidates: Iterable[str]
    if depth_field:
        depth_candidates = (depth_field,)
    else:
        depth_candidates = ("depth_ft", "depth_m", "depth")

    chosen_depth_field = None
    derived_label = depth_label
    if include_depth:
        for candidate in depth_candidates:
            if candidate is None:
                continue
            if available_set is not None and candidate not in available_set:
                continue
            chosen_depth_field = candidate
            break
        if chosen_depth_field is None:
            raise ValueError("Depth data was requested but no depth field was supplied or discovered.")

    depth_unit: str | None = None
    if include_depth and chosen_depth_field:
        if chosen_depth_field.endswith("_ft"):
            depth_unit = "ft"
        elif chosen_depth_field.endswith("_m"):
            depth_unit = "m"

    deco_field: str | None = None
    deco_unit: str | None = None
    if include_deco_ceiling:
        normalized_units = (deco_ceiling_units or "auto").lower()

        def _preferred_units() -> list[str]:
            if normalized_units in {"auto", ""}:
                if depth_unit == "ft":
                    return ["ft", "m"]
                if depth_unit == "m":
                    return ["m", "ft"]
                return ["ft", "m"]
            if normalized_units in {"ft", "feet", "imperial"}:
                return ["ft", "m"]
            if normalized_units in {"m", "meter", "meters", "metric"}:
                return ["m", "ft"]
            raise ValueError("deco_ceiling_units must be 'auto', 'ft', or 'm'.")

        available_columns = set(df.reset_index().columns)
        for unit in _preferred_units():
            candidate = "deco_ceiling_ft" if unit == "ft" else "deco_ceiling_m"
            if candidate in available_columns:
                deco_field = candidate
                deco_unit = unit
                break
        if deco_field is None:
            fallback = next((col for col in ("deco_ceiling_ft", "deco_ceiling_m") if col in available_columns), None)
            if fallback is not None:
                deco_field = fallback
                deco_unit = "ft" if fallback.endswith("_ft") else "m"
        if deco_field is None or deco_unit is None:
            raise ValueError("Deco ceiling was requested but no deco ceiling field is present in the timeseries data.")

    required_fields = {field.field for group in groups for field in group.fields}
    if include_depth and chosen_depth_field:
        required_fields.add(chosen_depth_field)
    if include_deco_ceiling and deco_field:
        required_fields.add(deco_field)

    if not required_fields:
        raise ValueError("No fields were provided to plot. Supply scale groups or enable depth.")

    subset_columns = [*sorted(required_fields)]
    if df.index.name != "time":
        df.set_index("time")
    missing_subset = [col for col in subset_columns if col not in df.reset_index().columns]
    if missing_subset:
        raise ValueError(f"Timeseries data is missing required columns: {', '.join(missing_subset)}")


    if df.index.isnull().all():
        raise ValueError("Timeseries data is missing valid time information.")
    seconds_series = df.index.map(lambda t: t.timestamp() - df.index[0].timestamp()).to_series()

    time_units_normalised = time_units.lower()
    if time_units_normalised == "seconds":
        time_values = seconds_series
        xaxis_title = time_axis_label or "Time (s)"
    elif time_units_normalised == "minutes":
        time_values = seconds_series / 60.0
        xaxis_title = time_axis_label or "Time (min)"
    else:
        raise ValueError("time_units must be either 'seconds' or 'minutes'.")

    fig = go.Figure()

    depth_side_normalised = depth_side.lower()
    if depth_side_normalised not in {"left", "right"}:
        raise ValueError("depth_side must be either 'left' or 'right'.")

    if include_depth and chosen_depth_field:
        if chosen_depth_field not in df.columns:
            raise ValueError(f"Depth field '{chosen_depth_field}' is not present in the timeseries data.")
        derived_label = depth_label
        if derived_label is None:
            if chosen_depth_field.endswith("_ft"):
                derived_label = "Depth (ft)"
            elif chosen_depth_field.endswith("_m"):
                derived_label = "Depth (m)"
            else:
                derived_label = "Depth"

        fig.add_trace(
            go.Scatter(
                x=time_values,
                y=df[chosen_depth_field],
                mode="lines",
                name=derived_label,
                line=dict(color=depth_color, width=2),
                fill="tozeroy",
                fillcolor=depth_fillcolor,
                hovertemplate="%{y:.2f}<extra>" + derived_label + "</extra>",
            )
        )

    deco_trace_added = False
    deco_hover_unit = depth_unit or deco_unit
    deco_display_label: str | None = None

    if include_deco_ceiling and deco_field:
        ceiling_series = _pd.to_numeric(df[deco_field], errors="coerce")
        if depth_unit and deco_unit and depth_unit != deco_unit:
            if depth_unit == "ft" and deco_unit == "m":
                ceiling_series = ceiling_series * 3.28084
                deco_hover_unit = "ft"
            elif depth_unit == "m" and deco_unit == "ft":
                ceiling_series = ceiling_series * 0.3048
                deco_hover_unit = "m"
        elif deco_hover_unit is None:
            deco_hover_unit = deco_unit

        positive_mask = ceiling_series > 0
        if positive_mask.any():
            ceiling_values = ceiling_series.where(positive_mask, other=np.nan)
            if deco_hover_unit in {"ft", "feet"}:
                deco_display_label = "Deco ceiling (ft)"
            elif deco_hover_unit in {"m", "meter", "meters"}:
                deco_display_label = "Deco ceiling (m)"
            else:
                deco_display_label = "Deco ceiling"
            hover_suffix = f" {deco_hover_unit}" if deco_hover_unit else ""
            fig.add_trace(
                go.Scatter(
                    x=time_values,
                    y=ceiling_values,
                    mode="lines",
                    name=deco_display_label,
                    line=dict(color=deco_ceiling_color, width=2, shape="hv"),
                    fill="tozeroy",
                    fillcolor=deco_ceiling_fillcolor,
                    hovertemplate=f"{deco_display_label}: %{{y:.1f}}{hover_suffix}<extra></extra>",
                    connectgaps=False,
                )
            )
            deco_trace_added = True

    axis_layout: dict[str, object] = {
        "template": template,
        "xaxis": dict(title=xaxis_title, zeroline=False),
        "legend": dict(orientation="h", y=1.05, x=0.5, xanchor="center"),
    }

    has_primary_axis = include_depth and chosen_depth_field is not None
    if has_primary_axis:
        axis_layout["yaxis"] = dict(title=depth_label or derived_label, autorange="reversed", side=depth_side_normalised)
    else:
        fallback_title = "Value"
        if deco_trace_added and deco_display_label:
            fallback_title = deco_display_label
        axis_layout["yaxis"] = dict(title=fallback_title, autorange="reversed", side="left")

    next_axis_index = 2 if has_primary_axis else 1

    for idx, group in enumerate(groups):
        if not has_primary_axis and idx == 0:
            axis_name = "y"
            axis_key = "yaxis"
            axis_config = {"side": (group.side or "left").lower()}
        else:
            axis_name = f"y{next_axis_index}"
            axis_key = f"yaxis{next_axis_index}"
            axis_config = {"overlaying": "y", "side": (group.side or "right").lower()}
            axis_layout[axis_key] = {}
            next_axis_index += 1

        if group.title:
            axis_config["title"] = group.title
        if group.range:
            axis_config["range"] = list(group.range)
        if group.axis:
            axis_config.update(group.axis)

        overlaying_value = axis_config.get("overlaying", None)
        if overlaying_value is None:
            axis_config.pop("overlaying", None)

        axis_layout.setdefault(axis_key, {}).update(axis_config)

        for field in group.fields:
            column = field.field
            if column not in df.columns:
                raise ValueError(f"Field '{column}' is not available in the timeseries DataFrame.")
            trace_kwargs = dict(
                x=time_values,
                y=df[column],
                mode="lines",
                name=field.label or column,
                line=dict(color=field.color, dash=field.dash, width=field.width or 2),
            )
            if axis_name != "y":
                trace_kwargs["yaxis"] = axis_name
            fig.add_trace(go.Scatter(**trace_kwargs))

    if figure_title:
        axis_layout["title"] = figure_title

    fig.update_layout(**axis_layout)

    return fig


def plot_po2_millivolts_scatter(
    timeseries,
    *,
    average_field: str = "average_ppo2",
    sensor_fields: Sequence[str] | None = None,
    include_setpoint: bool = True,
    template: str = "plotly_dark",
    figure_title: str | None = None,
) -> "go.Figure":
    """Plot sensor millivolts against average ppO₂ for correlation checks.

    Parameters
    ----------
    timeseries:
        Dive timeseries object (with ``to_df``/``available_fields``) or a
        Pandas DataFrame containing the requested columns along with a
        ``time_seconds`` column.
    average_field:
        Column name to use for the ppO₂ value on the x-axis. Defaults to
        ``"average_ppo2"``.
    sensor_fields:
        Optional list of sensor millivolt columns. When omitted the function
        automatically discovers columns matching ``sensor*_millivolts``.
    include_setpoint:
        When True, a hover column for ``ppo2_setpoint`` is added when present.
    template:
        Plotly template for styling.
    figure_title:
        Optional title for the figure.
    """

    _ensure_plotly()

    df = _coerce_timeseries_dataframe(timeseries, None, )
    available_columns = set(df.columns)

    if sensor_fields is None:
        sensor_fields = sorted(
            field
            for field in available_columns
            if isinstance(field, str) and field.startswith("sensor") and field.endswith("_millivolts")
        )

    if not sensor_fields:
        raise ValueError("No sensor millivolt columns were supplied or discovered.")

    missing_sensors = [field for field in sensor_fields if field not in available_columns]
    if missing_sensors:
        raise ValueError(f"Sensor fields not present in timeseries: {', '.join(missing_sensors)}")

    if average_field not in available_columns:
        raise ValueError(f"Average field '{average_field}' is not present in the timeseries data.")

    hover_fields: list[str] = []
    if include_setpoint and "ppo2_setpoint" in available_columns:
        hover_fields.append("ppo2_setpoint")

    subset_columns = [average_field, *sensor_fields, *hover_fields]
    missing_subset = [col for col in subset_columns if col not in df.columns]
    if missing_subset:
        raise ValueError(f"Timeseries data is missing required columns: {', '.join(missing_subset)}")

    df = df[subset_columns].copy()
    df["time_seconds"] = df.index.map(lambda t: t.timestamp() - df.index[0].timestamp())

    drop_columns = [average_field, *sensor_fields]
    df = df.dropna(subset=drop_columns).copy()
    if df.empty:
        raise ValueError("No rows remain after dropping NA values for the selected fields.")

    long_frames = []
    for field in sensor_fields:
        sensor_label = field.replace("_millivolts", "").replace("sensor", "Sensor ")
        frame = df[[average_field, field, "time_seconds", *hover_fields]].copy()
        frame["sensor"] = sensor_label
        frame.rename(columns={field: "millivolts"}, inplace=True)
        long_frames.append(frame)

    combined = _pd.concat(long_frames, ignore_index=True)

    fig = go.Figure()

    palette = [
        "#FF851B",
        "#FF4136",
        "#2ECC40",
        "#FFDC00",
        "#0074D9",
        "#B10DC9",
    ]

    for idx, (sensor, group) in enumerate(combined.groupby("sensor", sort=False)):
        color = palette[idx % len(palette)]
        hovertemplate = "Average ppO₂: %{x:.3f}<br>Millivolts: %{y:.1f}<br>Time: %{customdata[0]:.0f}s"
        customdata = group[["time_seconds"] + hover_fields].to_numpy()
        fig.add_trace(
            go.Scatter(
                x=group[average_field],
                y=group["millivolts"],
                mode="markers",
                name=sensor,
                marker=dict(color=color, size=6, opacity=0.65),
                customdata=customdata,
                hovertemplate=hovertemplate + ("<br>Setpoint: %{customdata[1]:.2f}" if hover_fields else "") + "<extra></extra>",
            )
        )

    fig.update_layout(
        template=template,
        title=figure_title or "Sensor Millivolts vs Average ppO₂",
        xaxis=dict(title="Average ppO₂ (ATA)", zeroline=False),
        yaxis=dict(title="Sensor millivolts (mV)", zeroline=False),
        legend=dict(orientation="h", y=1.05, x=0.5, xanchor="center"),
    )

    return fig

def plot_sensor_millivolts_by_ppo2_heatmap(
    dive_client,
    *,
    dive_filter: DiveFilter | None = None,
    sensor: int | str = "sensor1_millivolts",
    start: str | _pd.Timestamp | None = None,
    end: str | _pd.Timestamp | None = None,
    bin_size: float = 0.1,
    template: str = "plotly_dark",
    figure_title: str | None = None,
) -> "go.Figure":
    """Display a ppO₂-bin heatmap for the first CCR dive of each day."""

    _ensure_plotly()

    if isinstance(sensor, int):
        if sensor < 1:
            raise ValueError("Sensor index must be >= 1.")
        sensor_field = f"sensor{sensor}_millivolts"
    else:
        sensor_field = str(sensor)

    if bin_size <= 0:
        raise ValueError("bin_size must be positive.")

    start_day = _normalize_date(start)
    end_day = _normalize_date(end)

    ccr_dives = [
        dive
        for dive in dive_client.get_primary_computer_dives(dive_filter=dive_filter)
        if getattr(dive, "mode", "").lower() == "ccr"
    ]

    records: list[_pd.Series] = []
    ppo2_min, ppo2_max = float('inf'), float('-inf')

    for dive in ccr_dives:
        if dive.timeseries is None:
            continue
        try:
            ts = _coerce_timeseries_dataframe(dive.timeseries, [sensor_field, "average_ppo2"])
        except (ValueError, TypeError):
            continue

        ts = ts[[sensor_field, "average_ppo2"]].dropna()
        if ts.empty:
            continue

        ts["ppo2_bin"] = np.round(np.floor(ts["average_ppo2"] / bin_size) * bin_size, 3)
        grouped = ts.groupby("ppo2_bin")[sensor_field].mean()
        if grouped.empty:
            continue

        ppo2_min = min(ppo2_min, grouped.index.min())
        ppo2_max = max(ppo2_max, grouped.index.max())

        series = grouped.copy()
        series.name = _pd.Timestamp(dive.start)
        records.append(series)

    if not records:
        raise ValueError("No CCR dives with the requested sensor data were found.")

    matrix = _pd.DataFrame(records)
    matrix.index = _pd.to_datetime(matrix.index)
    matrix.index.name = "start"
    matrix = matrix.dropna(how="all")

    if start_day is not None or end_day is not None:
        matrix = matrix.loc[start_day:end_day]

    if matrix.empty:
        raise ValueError("No data is available within the requested date range.")

    first_per_day = (
        matrix.sort_index()
        .groupby(matrix.index.normalize())
        .first()
    )

    bin_start = np.floor(ppo2_min / bin_size) * bin_size
    bin_end = np.ceil(ppo2_max / bin_size) * bin_size
    bins = np.round(np.arange(bin_start, bin_end + bin_size, bin_size), 3)

    first_per_day = first_per_day.reindex(columns=bins, fill_value=np.nan)

    labels = first_per_day.index.strftime("%Y-%m-%d").tolist()
    Z = first_per_day.to_numpy().T

    fig = go.Figure(
        data=go.Heatmap(
            x=labels,
            y=bins,
            z=Z,
            colorscale="Viridis",
            colorbar=dict(title="mV"),
            hovertemplate="Date: %{x}<br>ppO₂: %{y:.2f}<br>mV: %{z:.1f}<extra></extra>",
        )
    )

    fig.update_layout(
        template=template,
        title=figure_title or f"{sensor_field} millivolts by ppO₂ bin",
        xaxis=dict(type="category", title="Date", categoryorder="array", categoryarray=labels),
        yaxis=dict(title="ppO₂ (ATA)"),
        height=520,
        width=980,
        margin=dict(l=60, r=60, t=60, b=40),
    )

    return fig


def plot_sensor_calibration_decay(
    dive_client,
    *,
    calibration_computer_name: str | None = None,
    sensor_open_dates: Mapping[int, str | _pd.Timestamp] | Sequence[str | _pd.Timestamp] | None = None,
    dive_filter: DiveFilter | None = None,
    sensor_indices: Sequence[int] = (1, 2, 3),
    include_prediction: bool = False,
    threshold_ratio: float = 0.9,
    target_ppo2: float = 1.0,
    start: str | _pd.Timestamp | None = None,
    end: str | _pd.Timestamp | None = None,
    as_of: str | _pd.Timestamp | None = None,
    template: str = "plotly_dark",
    layout: str | None = None,
) -> tuple[dict[int, go.Figure], str] | tuple[go.Figure, str]:
    """Build per-sensor calibration decay plots with optional projections.

    Parameters
    ----------
    dive_client:
        Instance of :class:`divelogpy.client.DiveLogClient` providing access
        to logged dives.
    calibration_computer_name:
        Restrict calibrations to dives recorded by this computer name.
        When omitted, all primary computer dives are considered.
    sensor_open_dates:
        Mapping or sequence of sensor indices to the date the current sensor
        was installed. Used to cap projections at one year of age. Accepts
        anything coercible by :class:`pandas.Timestamp`.
    dive_filter:
        Optional :class:`DiveFilter` applied when fetching primary dives.
    sensor_indices:
        Collection of 1-based sensor indices to include. Defaults to (1, 2, 3).
    include_prediction:
        When True, adds a dashed projection from *today* to the estimated
        intersection with the replacement threshold (or one-year age cap).
    threshold_ratio:
        Multiplier applied to the first observed millivolt value to derive the
        replacement threshold (defaults to 90% of the opening calibration).
    target_ppo2:
        ppO₂ setpoint used when calling ``predict_millivolts`` on each sensor.
    start / end:
        Optional bounds limiting calibration dates considered.
    as_of:
        Logical "today" for the projection. Defaults to the current UTC date.
        Calibrations after this date are ignored, and projections begin from
        this snapshot point so results can be reproduced later.
    template:
        Plotly template for styling.

    Returns
    -------
    dict[int, go.Figure]
        Mapping of sensor index to its calibration decay figure.
    """

    _ensure_plotly()

    if not sensor_indices:
        raise ValueError("sensor_indices must contain at least one sensor.")
    if threshold_ratio <= 0:
        raise ValueError("threshold_ratio must be positive.")
    if target_ppo2 <= 0:
        raise ValueError("target_ppo2 must be positive.")

    def _coerce_timestamp(value: object) -> _pd.Timestamp | None:
        if value is None:
            return None
        ts = _pd.Timestamp(value)
        if _pd.isna(ts):
            return None
        if ts.tzinfo is not None:
            try:
                ts = ts.tz_convert(None)
            except TypeError:
                ts = ts.tz_localize(None)
        return ts

    normalized_indices = sorted({int(idx) for idx in sensor_indices if int(idx) >= 1})
    if not normalized_indices:
        raise ValueError("sensor_indices must include at least one valid (>=1) sensor index.")

    start_ts = _coerce_timestamp(start)
    end_ts = _coerce_timestamp(end)

    as_of_ts = _coerce_timestamp(as_of) or _coerce_timestamp(_pd.Timestamp.utcnow())
    if as_of_ts is None:
        as_of_ts = _pd.Timestamp.now()
    as_of_ts = as_of_ts.normalize()

    layout_mode = (layout or "").lower() or "separate"
    if layout_mode not in {"separate", "rows", "cols", "columns", "single"}:
        raise ValueError("layout must be 'separate', 'rows', 'columns', 'cols', or 'single'.")

    open_date_map: dict[int, _pd.Timestamp] = {}
    if sensor_open_dates:
        if isinstance(sensor_open_dates, Mapping):
            iterable = sensor_open_dates.items()
        else:
            iterable = zip(normalized_indices, sensor_open_dates)
        for idx_raw, raw_date in iterable:
            idx = int(idx_raw)
            ts = _coerce_timestamp(raw_date)
            if ts is None:
                continue
            open_date_map[idx] = ts.normalize()

    records: dict[int, list[tuple[_pd.Timestamp, float]]] = {idx: [] for idx in normalized_indices}

    dives = dive_client.get_primary_computer_dives(dive_filter=dive_filter)
    for dive in dives:
        if calibration_computer_name and dive.computer_name != calibration_computer_name:
            continue
        payload = getattr(dive, "payload", None)
        calibration_payload = getattr(payload, "calibration", None) if payload else None
        if not calibration_payload or not isinstance(calibration_payload, Mapping):
            continue

        calibration_date = _coerce_timestamp(calibration_payload.get("date"))
        if calibration_date is None:
            calibration_date = _coerce_timestamp(getattr(dive, "start", None))
        if calibration_date is None:
            continue
        if calibration_date > as_of_ts:
            continue
        if start_ts and calibration_date < start_ts:
            continue
        if end_ts and calibration_date > end_ts:
            continue

        for sensor_index in normalized_indices:
            open_ts = open_date_map.get(sensor_index)
            if open_ts and calibration_date < open_ts:
                continue
            try:
                sensor = dive.sensors[sensor_index - 1]
            except IndexError:
                continue
            predicted_mv = sensor.predict_millivolts(target_ppo2)
            if predicted_mv is None:
                continue
            records[sensor_index].append((calibration_date, float(predicted_mv)))

    sensor_palette = [
        "#FF4136",
        "#2ECC40",
        "#0074D9",
        "#B10DC9",
        "#FF851B",
        "#7FDBFF",
    ]
    projection_palette = [
        "#FFB347",
        "#7FDBB6",
        "#80BFFF",
        "#D291FF",
        "#FFC68C",
        "#B3E5FF",
    ]
    threshold_color = "#888888"

    figures: dict[int, go.Figure] = {}

    def _compute_projection(
        dates: _pd.Series,
        values: _pd.Series,
        threshold: float,
        *,
        one_year_cap: _pd.Timestamp | None,
        as_of_dt: _pd.Timestamp,
    ) -> tuple[list[_pd.Timestamp], list[float], dict[str, object]] | None:
        if len(dates) == 0:
            return None
        start_value = float(values.iloc[-1])
        if start_value <= 0:
            return None
        first_value = float(values.iloc[0])
        if first_value <= 0:
            return None
        if as_of_dt < dates.iloc[0]:
            return None
        total_years = (as_of_dt - dates.iloc[0]) / _pd.Timedelta(days=365.25)
        total_years = float(total_years)
        if total_years <= 0.0:
            return None

        total_rate = (start_value / first_value) - 1.0
        annual_rate = total_rate / total_years
        if abs(annual_rate) < 1e-9:
            return None

        start_dt = as_of_dt
        origin_for_expiry = one_year_cap if one_year_cap is not None else dates.iloc[0] + _pd.Timedelta(days=365.25)
        if origin_for_expiry <= start_dt:
            return None

        remaining_years = (origin_for_expiry - start_dt) / _pd.Timedelta(days=365.25)
        remaining_years = float(remaining_years)
        if remaining_years <= 0.0:
            return None

        end_dt = origin_for_expiry
        end_value = start_value * (1.0 + annual_rate * remaining_years)
        hit_threshold = False
        threshold_dt: _pd.Timestamp | None = None

        if annual_rate < 0.0 and threshold < start_value:
            if start_value <= 0:
                return None
            years_to_threshold = (threshold / start_value - 1.0) / annual_rate
            if 0.0 < years_to_threshold < remaining_years:
                threshold_dt = start_dt + _pd.Timedelta(days=years_to_threshold * 365.25)
                end_dt = threshold_dt
                end_value = start_value * (1.0 + annual_rate * years_to_threshold)
                hit_threshold = True

        end_value = max(end_value, 0.0)
        if end_dt <= start_dt:
            return None

        return (
            [start_dt, end_dt],
            [start_value, end_value],
            {"hit_threshold": hit_threshold, "threshold_date": threshold_dt, "expiry_date": origin_for_expiry},
        )

    status_entries: list[dict[str, object]] = []

    for idx, points in records.items():
        if not points:
            continue
        df = _pd.DataFrame(points, columns=["date", "millivolts"]).dropna(subset=["millivolts"])
        if df.empty:
            continue

        df = (
            df.groupby("date", as_index=False)["millivolts"]
            .mean()
            .sort_values("date")
            .reset_index(drop=True)
        )
        if df.empty:
            continue

        initial_value = float(df["millivolts"].iloc[0])
        threshold_value = initial_value * threshold_ratio
        if idx in open_date_map:
            expiry_anchor = open_date_map[idx]
        else:
            expiry_anchor = df["date"].iloc[0]
        one_year_cap = expiry_anchor + _pd.Timedelta(days=365)

        projection_result = _compute_projection(
            df["date"],
            df["millivolts"],
            threshold_value,
            one_year_cap=one_year_cap,
            as_of_dt=as_of_ts,
        )
        projection_segment = None
        projection_meta: dict[str, object] | None = None
        if projection_result:
            projection_segment = (projection_result[0], projection_result[1])
            projection_meta = projection_result[2]

        current_value = float(df["millivolts"].iloc[-1])
        expiry_dt = expiry_anchor + _pd.Timedelta(days=365)

        if current_value <= threshold_value:
            status_kind = "fail"
            status_message = f"Sensor {idx}: ❌ change now! Do not dive!"
        else:
            hit_threshold = bool(projection_meta.get("hit_threshold")) if projection_meta else False
            threshold_dt = projection_meta.get("threshold_date") if projection_meta else None
            if hit_threshold and isinstance(threshold_dt, _pd.Timestamp):
                status_kind = "warn"
                status_message = f"Sensor {idx}: ⚠️ Sensor is good to dive; suggest early swap"
            else:
                status_kind = "ok"
                if isinstance(expiry_dt, _pd.Timestamp):
                    status_message = f"Sensor {idx}: ✅ change by {expiry_dt.strftime('%Y-%m-%d')} (1y since open)"
                else:
                    status_message = f"Sensor {idx}: ✅ change by (1y since open)"

        status_entries.append({"sensor": idx, "kind": status_kind, "message": status_message})

        threshold_extent_candidates = [
            df["date"].iloc[0],
            df["date"].iloc[-1],
            as_of_ts,
        ]
        if projection_segment:
            threshold_extent_candidates.append(projection_segment[0][-1])
        if isinstance(expiry_dt, _pd.Timestamp):
            threshold_extent_candidates.append(expiry_dt)

        threshold_x_end = max(threshold_extent_candidates)
        threshold_trace_x = [df["date"].iloc[0], threshold_x_end]

        sensor_color = sensor_palette[(idx - 1) % len(sensor_palette)]
        proj_color = projection_palette[(idx - 1) % len(projection_palette)]

        fig = go.Figure()
        fig.add_trace(
            go.Scatter(
                x=df["date"],
                y=df["millivolts"],
                mode="lines+markers",
                name=f"Sensor {idx}",
                line=dict(color=sensor_color, width=2),
                marker=dict(color=sensor_color, size=7),
                hovertemplate="Date: %{x|%Y-%m-%d}<br>mV: %{y:.1f}<extra></extra>",
            )
        )

        fig.add_trace(
            go.Scatter(
                x=threshold_trace_x,
                y=[threshold_value, threshold_value],
                mode="lines",
                name=f"Threshold ({threshold_ratio:.0%})",
                line=dict(color=threshold_color, dash="dot", width=2),
                hovertemplate="Replacement threshold: %{y:.1f} mV<extra></extra>",
                showlegend=True,
            )
        )

        if include_prediction and projection_segment:
            fig.add_trace(
                go.Scatter(
                    x=projection_segment[0],
                    y=projection_segment[1],
                    mode="lines+markers",
                    name="Projected decay",
                    line=dict(color=proj_color, dash="dash"),
                    marker=dict(color=proj_color, size=8, symbol="x"),
                    hovertemplate="Projected: %{x|%Y-%m-%d}<br>mV: %{y:.1f}<extra></extra>",
                )
            )

        fig.update_layout(
            template=template,
            title=f"Sensor {idx} calibration millivolts",
            xaxis=dict(title="Calibration date"),
            yaxis=dict(title="Millivolts (mV)", rangemode="tozero"),
            legend=dict(orientation="h", y=1.1, x=0.5, xanchor="center"),
            margin=dict(l=65, r=45, t=70, b=50),
        )

        figures[idx] = fig

    if not figures:
        raise ValueError("No calibration data was found for the requested sensors.")

    heading = "Sensor status"
    if any(entry["kind"] in {"fail", "warn"} for entry in status_entries):
        heading = "Sensor expiries"
    lines = [f"### {heading}", ""]
    for entry in sorted(status_entries, key=lambda e: e["sensor"]):
        lines.append(f"- {entry['message']}")
    warn_sensors = [entry["sensor"] for entry in status_entries if entry["kind"] == "warn"]
    if warn_sensors:
        sensor_list = ", ".join(str(s) for s in warn_sensors)
        lines.append("")
        lines.append(f"**Early swap suggested for sensor(s) {sensor_list}.**")
        lines.append(
            "Sensors should be discarded one year since first exposing to air, but sometimes their useful age might end sooner. "
            "The rate of output decrease in this case suggests that while your sensor is OK to dive now, it might not produce enough "
            "current to report oxygen levels accurately after the suggested swap date."
        )
    caption = "\n".join(lines)

    if layout_mode == "separate":
        return figures, caption

    from plotly.subplots import make_subplots

    ordered = [figures[idx] for idx in sorted(figures)]
    if not ordered:
        raise ValueError("No calibration data was found for the requested sensors.")

    if layout_mode in {"columns", "cols"}:
        subplot_fig = make_subplots(rows=1, cols=len(ordered), shared_yaxes=True, horizontal_spacing=0.05)
        for col_index, fig in enumerate(ordered, start=1):
            for trace in fig.data:
                subplot_fig.add_trace(trace, row=1, col=col_index)
        subplot_fig.update_xaxes(title_text="Calibration date", row=1, col=1)
        subplot_fig.update_yaxes(title_text="Millivolts (mV)", row=1, col=1)
    else:
        subplot_fig = make_subplots(rows=len(ordered), cols=1, shared_xaxes=True, vertical_spacing=0.06)
        for row_index, fig in enumerate(ordered, start=1):
            for trace in fig.data:
                subplot_fig.add_trace(trace, row=row_index, col=1)
        subplot_fig.update_xaxes(title_text="Calibration date", row=len(ordered), col=1)
        subplot_fig.update_yaxes(title_text="Millivolts (mV)", row=1, col=1)

    subplot_fig.update_layout(
        template=template,
        title="Sensor calibration millivolts",
        legend=dict(orientation="h", y=1.12, x=0.5, xanchor="center"),
        margin=dict(l=65, r=45, t=80, b=50),
        height=420 * (1 if layout_mode in {"columns", "cols"} else len(ordered)),
    )

    return subplot_fig, caption


def plot_sensor_mv_ppo2_timeseries(
    dive_client,
    *,
    computer_name: str,
    sensor_indices: Sequence[int] = (1, 2, 3),
    sensor_start_inclusion_dates: Mapping[int, str | _pd.Timestamp] | None = None,
    min_ppo2: float = 1.0,
    ppo2_step: float = 0.1,
    bin_width: float = 0.02,
    as_of: str | _pd.Timestamp | None = None,
    template: str = "plotly_dark",
) -> "go.Figure":
    """Visualise sensor millivolts across dives aggregated by ppO₂ bins.

    Parameters
    ----------
    dive_client:
        Client capable of returning dives via :meth:`get_dives`.
    computer_name:
        Dive computer name used to restrict the dataset.
    sensor_indices:
        1-based indices of sensors to include.
    sensor_start_inclusion_dates:
        Optional mapping of sensor indices to their first valid date.
    min_ppo2:
        Lower ppO₂ bound to retain.
    ppo2_step:
        Distance in ATA between successive ppO₂ bins.
    bin_width:
        Tolerance (± ATA) around each ppO₂ bin when averaging millivolts.
    as_of:
        Optional cutoff; dives starting after this timestamp are ignored.
    template:
        Plotly template for styling.
    """

    _ensure_plotly()

    if not hasattr(dive_client, "get_dives"):
        raise TypeError("dive_client must expose a 'get_dives' method.")
    if not computer_name:
        raise ValueError("computer_name is required.")
    if ppo2_step <= 0:
        raise ValueError("ppo2_step must be positive.")
    if bin_width <= 0:
        raise ValueError("bin_width must be positive.")
    if not sensor_indices:
        raise ValueError("sensor_indices must contain at least one entry.")

    sensor_indices = tuple(sorted({int(idx) for idx in sensor_indices if int(idx) >= 1}))
    if not sensor_indices:
        raise ValueError("sensor_indices must contain at least one valid (>=1) sensor index.")

    min_ppo2 = float(min_ppo2)
    ppo2_step = float(ppo2_step)
    bin_width = float(bin_width)

    sensor_start_map: dict[int, _pd.Timestamp] = {}
    if sensor_start_inclusion_dates:
        for raw_idx, raw_date in sensor_start_inclusion_dates.items():
            idx = int(raw_idx)
            if idx not in sensor_indices:
                continue
            ts = _pd.Timestamp(raw_date)
            if _pd.isna(ts):
                continue
            if ts.tzinfo is not None:
                try:
                    ts = ts.tz_convert(None)
                except TypeError:
                    ts = ts.tz_localize(None)
            sensor_start_map[idx] = ts.normalize()

    start_cutoff = max(sensor_start_map.values()) if sensor_start_map else None

    if as_of is None:
        as_of_ts = _pd.Timestamp.utcnow()
    else:
        as_of_ts = _pd.Timestamp(as_of)
    if _pd.isna(as_of_ts):
        raise ValueError("Invalid as_of timestamp provided.")
    if as_of_ts.tzinfo is not None:
        try:
            as_of_ts = as_of_ts.tz_convert(None)
        except TypeError:
            as_of_ts = as_of_ts.tz_localize(None)

    def _to_naive_timestamp(value: object) -> _pd.Timestamp | None:
        if value is None:
            return None
        ts = _pd.Timestamp(value)
        if _pd.isna(ts):
            return None
        if ts.tzinfo is not None:
            try:
                ts = ts.tz_convert(None)
            except TypeError:
                ts = ts.tz_localize(None)
        return ts

    def _series_exceeds_threshold(series) -> bool:
        if series is None:
            return False
        values = pd.Series(series, dtype=float)
        if values.empty:
            return False
        return values.gt(min_ppo2).any()

    sensor_threshold = SensorFilter(ppo2=_fo.custom(_series_exceeds_threshold))

    def _collection_has_high_ppo2(collection) -> bool:
        if collection is None:
            return False
        filter_method = getattr(collection, "filter", None)
        if filter_method is None:
            return False
        filtered = filter_method(sensor_threshold)
        try:
            return len(filtered) > 0
        except TypeError:  # pragma: no cover - defensive
            return any(True for _ in filtered)

    filter_payload: dict[str, object] = {"computer_name": computer_name}
    if start_cutoff is not None:
        filter_payload["start"] = _fo.gt(start_cutoff.to_pydatetime())
    filter_payload["sensors"] = _fo.custom(_collection_has_high_ppo2)

    dive_filter = DiveFilter(**filter_payload)
    dives_collection = dive_client.get_dives(dive_filter=dive_filter)

    sensor_field_map = {idx: f"sensor{idx}_millivolts" for idx in sensor_indices}

    candidate_dives: list[tuple[_pd.Timestamp, Dive]] = []
    for dive in dives_collection:
        start_ts = _to_naive_timestamp(getattr(dive, "start", None))
        if start_ts is None or start_ts > as_of_ts:
            continue
        timeseries = getattr(dive, "timeseries", None)
        if timeseries is None or not hasattr(timeseries, "to_df"):
            continue
        candidate_dives.append((start_ts, dive))

    candidate_dives.sort(key=lambda item: item[0])

    processed_dives: list[tuple[_pd.Timestamp, pd.DataFrame, dict[int, str]]] = []
    overall_max: float | None = None

    for start_ts, dive in candidate_dives:
        timeseries = getattr(dive, "timeseries", None)
        if timeseries is None or not hasattr(timeseries, "to_df"):
            continue
        try:
            raw_df = timeseries.to_df()
        except Exception:
            continue
        if raw_df.empty or "average_ppo2" not in raw_df.columns:
            continue

        sensor_cols_present: dict[int, str] = {
            idx: col_name for idx, col_name in sensor_field_map.items() if col_name in raw_df.columns
        }
        if not sensor_cols_present:
            continue

        time_columns = [name for name in ("time_seconds", "time") if name in raw_df.columns]

        working_df = raw_df[[*time_columns, "average_ppo2", *sensor_cols_present.values()]].copy()
        working_df = working_df.apply(pd.to_numeric, errors="coerce")
        working_df = working_df.dropna(subset=["average_ppo2"])
        working_df = working_df.loc[working_df["average_ppo2"] >= min_ppo2]
        if working_df.empty:
            continue

        value_cols = list(sensor_cols_present.values())
        working_df = working_df.dropna(subset=value_cols, how="all")
        if working_df.empty:
            continue

        max_value = float(working_df["average_ppo2"].max())
        overall_max = max_value if overall_max is None else max(overall_max, max_value)

        processed_dives.append((start_ts, working_df, sensor_cols_present))

    if overall_max is None or not processed_dives:
        raise ValueError("No qualifying ppO₂ samples were found for the requested filters.")

    try:
        from decimal import Decimal

        decimals = max(0, -Decimal(str(ppo2_step)).as_tuple().exponent)
    except Exception:  # pragma: no cover - Decimal fallback
        decimals = max(1, int(np.ceil(-np.log10(abs(ppo2_step)))) if ppo2_step < 1 else 0)

    target_bins = np.arange(min_ppo2, overall_max + ppo2_step / 2.0, ppo2_step)
    target_bins = np.round(target_bins, decimals)

    records: list[dict[str, object]] = []

    for start_ts, working_df, sensor_cols_present in processed_dives:
        for sensor_idx, col_name in sensor_cols_present.items():
            sensor_cutoff = sensor_start_map.get(sensor_idx)
            if sensor_cutoff is not None and start_ts < sensor_cutoff:
                continue

            sensor_cols = ["average_ppo2", col_name]
            if time_columns:
                sensor_cols = [*time_columns, "average_ppo2", col_name]
            sensor_frame = working_df[sensor_cols].dropna()
            if sensor_frame.empty:
                continue

            sort_columns = time_columns or ["average_ppo2"]
            sensor_frame = sensor_frame.sort_values(sort_columns[0])

            avg_series = sensor_frame["average_ppo2"].astype(float)
            mv_series = sensor_frame[col_name].astype(float)

            valid_mask = avg_series.ge(min_ppo2) & mv_series.notna()
            avg_values = avg_series[valid_mask].to_numpy()
            mv_values = mv_series[valid_mask].to_numpy()
            if avg_values.size == 0:
                continue

            max_reached = float(np.max(avg_values))
            half_width = float(bin_width) / 2.0

            bin_results: list[tuple[float, float]] = []

            for bin_value in target_bins:
                if bin_value > max_reached + 1e-9:
                    break
                if bin_value < min_ppo2 - 1e-9:
                    continue

                lower = bin_value - half_width
                upper = bin_value + half_width
                mask = (avg_values >= lower) & (avg_values <= upper)

                if mask.any():
                    mv_value = float(np.mean(mv_values[mask]))
                    bin_results.append((float(bin_value), mv_value))
                    continue

                below_mask = avg_values < bin_value
                above_mask = avg_values > bin_value
                if not below_mask.any() or not above_mask.any():
                    continue

                below_idx = np.where(below_mask)[0][-1]
                above_idx = np.where(above_mask)[0][0]

                pp_low = avg_values[below_idx]
                mv_low = mv_values[below_idx]
                pp_high = avg_values[above_idx]
                mv_high = mv_values[above_idx]

                if not (np.isfinite(pp_low) and np.isfinite(pp_high) and np.isfinite(mv_low) and np.isfinite(mv_high)):
                    continue
                if pp_high <= pp_low:
                    continue

                position = (bin_value - pp_low) / (pp_high - pp_low)
                mv_interp = mv_low + position * (mv_high - mv_low)
                bin_results.append((float(bin_value), float(mv_interp)))

            if not bin_results:
                continue

            bin_results.sort(key=lambda pair: pair[0])
            for bin_value, mv_value in bin_results:
                records.append(
                    {
                        "sensor": sensor_idx,
                        "ppo2_bin": bin_value,
                        "date": start_ts,
                        "millivolts": mv_value,
                    }
                )

    if not records:
        raise ValueError("No qualifying ppO₂ data found after binning.")

    df_records = _pd.DataFrame.from_records(records)
    df_records["date"] = _pd.to_datetime(df_records["date"])

    df_records = df_records.groupby(["sensor", "ppo2_bin"]).filter(
        lambda frame: frame["date"].nunique() >= 2
    )

    if df_records.empty:
        raise ValueError("No ppO₂ bins appeared in more than one dive; nothing to plot.")

    bins_sorted = sorted(df_records["ppo2_bin"].unique())

    try:
        from plotly.colors import sample_colorscale

        palette = sample_colorscale(
            "Viridis",
            [i / (max(len(bins_sorted) - 1, 1)) for i in range(len(bins_sorted))],
        )
        color_map = {bin_value: palette[idx] for idx, bin_value in enumerate(bins_sorted)}
    except Exception:  # pragma: no cover - optional dependency issues
        fallback_palette = [
            "#FF851B",
            "#FF4136",
            "#2ECC40",
            "#0074D9",
            "#B10DC9",
            "#FFDC00",
            "#7FDBFF",
            "#39CCCC",
            "#01FF70",
            "#F012BE",
        ]
        color_map = {
            bin_value: fallback_palette[idx % len(fallback_palette)]
            for idx, bin_value in enumerate(bins_sorted)
        }

    sensor_to_col = {sensor_idx: position for position, sensor_idx in enumerate(sensor_indices, start=1)}

    fig = make_subplots(
        rows=1,
        cols=len(sensor_indices),
        shared_xaxes=True,
        subplot_titles=[f"Sensor {idx}" for idx in sensor_indices],
        horizontal_spacing=0.06,
    )

    df_records.sort_values(by=["date", "ppo2_bin"], inplace=True)

    for sensor_idx in sensor_indices:
        column = sensor_to_col[sensor_idx]
        sensor_frame = df_records[df_records["sensor"] == sensor_idx]
        if sensor_frame.empty:
            continue
        for bin_value in bins_sorted:
            subset = sensor_frame.loc[sensor_frame["ppo2_bin"] == bin_value]
            if subset.empty:
                continue
            fig.add_trace(
                go.Scatter(
                    x=subset["date"],
                    y=subset["millivolts"],
                    mode="lines+markers",
                    name=f"{bin_value:.{decimals}f} ATA",
                    legendgroup=f"ppo2-{bin_value:.{decimals}f}",
                    line=dict(color=color_map[bin_value], width=2),
                    marker=dict(color=color_map[bin_value], size=6),
                    showlegend=(column == 1),
                    hovertemplate=(
                        "Date: %{x|%Y-%m-%d}<br>"
                        f"ppO₂: {bin_value:.{decimals}f} ATA<br>"
                        "mV: %{y:.1f}<extra></extra>"
                    ),
                ),
                row=1,
                col=column,
            )

        fig.update_xaxes(title_text="Dive date", row=1, col=column)
        fig.update_yaxes(
            title_text="Millivolts (mV)" if column == 1 else None,
            rangemode="tozero",
            row=1,
            col=column,
        )

    legend_padding = 0.11 + 0.05 * (len(sensor_indices) - 1)
    legend_y = min(1.2, legend_padding)

    fig.update_layout(
        template=template,
        title="Sensor millivolts by ppO₂ bin over time",
        legend=dict(orientation="h", y=legend_y, yanchor="bottom", x=0.5, xanchor="center"),
        margin=dict(l=65, r=45, t=80, b=50),
    )

    return fig


def plot_sensor_usage_decay_heatmap(
    dive_client,
    *,
    target_ppo2: float = 1.2,
    bin_width_minutes: int = 30,
    min_total_ccr_minutes: float = 120.0,
    sensor_fields: Sequence[str] | None = None,
    start: str | _pd.Timestamp | None = None,
    end: str | _pd.Timestamp | None = None,
    template: str = "plotly_dark",
    figure_title: str | None = None,
) -> "go.Figure":
    """Display a cumulative CCR usage heatmap for sensor drift analysis."""

    _ensure_plotly()

    if bin_width_minutes <= 0:
        raise ValueError("bin_width_minutes must be positive.")
    if min_total_ccr_minutes < 0:
        raise ValueError("min_total_ccr_minutes must be non-negative.")

    start_day = _normalize_date(start)
    end_day = _normalize_date(end)

    ccr_dives = [
        dive
        for dive in dive_client.get_primary_computer_dives()
        if getattr(dive, "mode", "").lower() == "ccr"
    ]
    ccr_dives.sort(key=lambda d: d.start)

    if not ccr_dives:
        raise ValueError("No CCR dives found.")

    dives_by_day: dict[_pd.Timestamp, list[Dive]] = {}
    for dive in ccr_dives:
        day = _pd.Timestamp(dive.start).normalize()
        dives_by_day.setdefault(day, []).append(dive)

    totals = {
        day: sum((float(getattr(d, "duration_seconds", 0.0)) or 0.0) / 60.0 for d in dives)
        for day, dives in dives_by_day.items()
    }

    qualifying_days = {
        day
        for day, total in totals.items()
        if total >= min_total_ccr_minutes
        and (start_day is None or day >= start_day)
        and (end_day is None or day <= end_day)
    }

    if not qualifying_days:
        raise ValueError("No days meet the CCR usage threshold within the requested range.")

    if sensor_fields is None:
        sensor_fields = ["sensor1_millivolts", "sensor2_millivolts", "sensor3_millivolts"]
    sensor_fields = list(sensor_fields)

    target_bin = round(target_ppo2 * 10) / 10

    records: list[dict[str, object]] = []

    for day, dives in dives_by_day.items():
        if day not in qualifying_days:
            continue

        dives_sorted = sorted(dives, key=lambda d: d.start)
        offsets: dict[str, float] = {}
        cumulative = 0.0
        for dive in dives_sorted:
            offsets[dive.dive_id] = cumulative
            cumulative += (float(getattr(dive, "duration_seconds", 0.0)) or 0.0) / 60.0

        for dive in dives_sorted:
            if dive.timeseries is None:
                continue

            required = sensor_fields + ["average_ppo2"]
            try:
                ts = _coerce_timeseries_dataframe(dive.timeseries, required)
            except (ValueError, TypeError):
                continue

            ts = ts.dropna(subset=["average_ppo2"] + sensor_fields)
            if ts.empty:
                continue

            ts["usage_min"] = ts["time_seconds"].astype(float) / 60.0 + offsets.get(dive.dive_id, 0.0)
            ts["ppo2_bin"] = np.round(np.floor(ts["average_ppo2"] * 10) / 10, 1)
            ts["sensor_avg"] = ts[sensor_fields].mean(axis=1)

            ts_target = ts.loc[ts["ppo2_bin"] == round(target_bin, 1), ["sensor_avg", "usage_min"]]
            if ts_target.empty:
                continue

            ts_target["usage_bin_min"] = (
                np.floor(ts_target["usage_min"] / bin_width_minutes) * bin_width_minutes
            ).astype(int)

            grouped = ts_target.groupby("usage_bin_min")["sensor_avg"].mean()
            if grouped.empty:
                continue

            day_label = day.strftime("%Y-%m-%d")
            for usage_bin, mv in grouped.items():
                records.append({"day": day_label, "usage_bin_min": usage_bin, "mv": mv})

    if not records:
        raise ValueError("No qualifying data found for the requested ppO₂ bin and usage thresholds.")
    

    matrix = _pd.DataFrame.from_records(records)
    heat = (
        matrix.pivot_table(index="usage_bin_min", columns="day", values="mv", aggfunc="mean")
        .sort_index()
    )

    heat = heat.reindex(sorted(heat.index), axis=0)
    heat = heat.reindex(sorted(heat.columns, key=_pd.Timestamp), axis=1)

    y_bins = heat.index.to_list()
    x_labels = heat.columns.to_list()
    Z = heat.values

    fig = go.Figure(
        data=go.Heatmap(
            x=x_labels,
            y=y_bins,
            z=Z,
            colorscale="Viridis",
            colorbar=dict(title="mV"),
            hovertemplate="Day: %{x}<br>Usage: %{y} min<br>mV: %{z:.1f}<extra></extra>",
        )
    )

    fig.update_layout(
        template=template,
        title=figure_title
        or (
            f"Sensor average mV decay at ppO₂={target_ppo2:.1f}"
            f" (bins {bin_width_minutes}-min, days ≥ {min_total_ccr_minutes:.0f} min CCR)"
        ),
        xaxis=dict(type="category", title="Day"),
        yaxis=dict(title="Cumulative CCR usage (min)"),
        height=560,
        width=980,
        margin=dict(l=65, r=65, t=70, b=40),
    )

    return fig



def plot_what_if_setpoint(time_series: pd.DataFrame, setpoint: float, unlock_time_in_seconds: float):
    df = time_series.copy()
    # df = df.reset_index().set_index('time_seconds')
    df["atms"] = 1 + (df.depth_ft / 33)
    df["new_fo2"] = setpoint/ df.atms
    df["new_po2"] = df.loc[df.index[0]+pd.Timedelta(seconds=unlock_time_in_seconds) :].apply(
        lambda row: (
            df.loc[df.index[0]+pd.Timedelta(seconds=unlock_time_in_seconds)]["new_fo2"] * row["atms"] if row.name >= df.index[0]+pd.Timedelta(seconds=unlock_time_in_seconds) else setpoint
        ),
        axis=1,
    )
    df.loc[: df.index[0]+pd.Timedelta(seconds=unlock_time_in_seconds), "new_po2"] = setpoint
    return plot_timeseries(
        df,
        scale_groups=[
            [
                "average_ppo2",
                "new_po2",
            ],  
        ],
    )

__all__ = [
    "plot_timeseries",
    "plot_po2_millivolts_scatter",
    "plot_sensor_millivolts_by_ppo2_heatmap",
    "plot_sensor_calibration_decay",
    "plot_sensor_mv_ppo2_timeseries",
    "plot_sensor_usage_decay_heatmap",
    "plot_what_if_setpoint",
    "plot_sensor_strip"
]
def _coerce_timeseries_dataframe(
    timeseries_or_df,
    required_fields: Sequence[str] | None = None,


) -> _pd.DataFrame:
    fields_list = sorted(set(required_fields)) if required_fields else None

    if isinstance(timeseries_or_df, _pd.DataFrame):
        df = timeseries_or_df.copy()
        if required_fields:
            missing = set(required_fields) - set(df.columns)
            if missing:
                raise ValueError(
                    f"Timeseries DataFrame is missing required columns: {', '.join(sorted(missing))}"
                )
        # if include_time and "time_seconds" not in df.columns:
        #     if "time_seconds" in df.index.names:
        #         df = df.reset_index()
        #     else:
        #         raise ValueError("Timeseries DataFrame must include a 'time_seconds' column when include_time is True.")
        return df

    if hasattr(timeseries_or_df, "to_df"):
        df = timeseries_or_df.to_df(fields_list)
        if df.empty:
            raise ValueError("The requested timeseries fields contain no data.")
        # if include_time and "time_seconds" not in df.index.names and "time_seconds" not in df.columns:
            # raise ValueError("Timeseries export must include 'time_seconds'.")
        # if include_time and "time_seconds" not in df.columns:
            # df = df.reset_index().rename(columns={"time_seconds": "time_seconds"})
        if required_fields:
            missing = set(required_fields) - set(df.columns)
            if missing:
                raise ValueError(
                    f"Timeseries export is missing required columns: {', '.join(sorted(missing))}"
                )
        return df

    raise TypeError("timeseries_or_df must be either a DataFrame or expose a 'to_df' method.")
def _normalize_date(value):
    if value is None:
        return None
    ts = _pd.Timestamp(value)
    if _pd.isna(ts):
        return None
    return ts.normalize()


def plot_noise_share(summary: pd.DataFrame, *, template: str = "plotly_dark") -> go.Figure:
    """
    Interactive pie chart showing how much of total noise variance
    each sensor contributes.
    Expects 'noise_var' column in summary DataFrame.
    """

    if "noise_var" not in summary.columns:
        raise ValueError("summary must include a 'noise_var' column")

    noise_share = summary["noise_var"] / summary["noise_var"].sum()

    fig = go.Figure(
        data=[
            go.Pie(
                labels=noise_share.index,
                values=noise_share,
                textinfo="label+percent",
                hovertemplate="<b>%{label}</b><br>Share: %{percent:.1%}<br>Noise Var: %{value:.2e}<extra></extra>",
                hole=0.3,
            )
        ]
    )

    fig.update_layout(
        title="Share of Total Noise Variance",
        template=template,
        showlegend=True,
        legend=dict(orientation="h", y=-0.1, x=0.5, xanchor="center"),
        margin=dict(l=40, r=40, t=60, b=40),
    )

    return fig


def plot_noise_share_timeseries(
    dives: Sequence[Dive] | Iterable[Dive],
    *,
    filter_low_setpoint: bool = False,
    template: str = "plotly_dark",
) -> "go.Figure":
    """
    Visualise how each sensor's share of the noise variance evolves across dives.

    Parameters
    ----------
    dives:
        Iterable of :class:`divelogpy.models.Dive` objects.
    filter_low_setpoint:
        Forwarded to the sensor preprocessing routine; set to True to discard
        samples taken below the low setpoint.
    template:
        Plotly template name for styling.
    """

    _ensure_plotly()

    if dives is None:
        raise ValueError("dives must be provided.")

    dive_list = list(dives)
    if not dive_list:
        raise ValueError("No dives were supplied.")

    def _coerce_timestamp(value: object) -> _pd.Timestamp | None:
        if value is None:
            return None
        ts = _pd.Timestamp(value)
        if _pd.isna(ts):
            return None
        if ts.tzinfo is not None:
            try:
                ts = ts.tz_convert(None)
            except TypeError:
                ts = ts.tz_localize(None)
        return ts

    def _sensor_label(raw: str) -> str:
        if raw.endswith("_millivolts"):
            raw = raw[: -len("_millivolts")]
        match = re.search(r"sensor(\d+)", raw)
        if match:
            return f"Sensor {int(match.group(1))}"
        return raw.replace("_", " ").title()

    def _dive_label(dive: Dive) -> str:
        label_attr = getattr(dive, "display_name", None)
        if callable(label_attr):
            try:
                label = label_attr()
            except Exception:  # pragma: no cover - defensive
                label = None
        else:
            label = label_attr
        if label:
            return str(label)
        dive_id = getattr(dive, "dive_id", None)
        if dive_id:
            return str(dive_id)
        start = getattr(dive, "start", None)
        ts = _coerce_timestamp(start)
        if ts is not None:
            return ts.strftime("%Y-%m-%d %H:%M")
        return "Dive"

    records: list[dict[str, object]] = []

    for dive in dive_list:
        timestamp = _coerce_timestamp(getattr(dive, "start", None))
        if timestamp is None:
            continue

        sensors = getattr(dive, "sensors", None)
        if sensors is None or len(sensors) == 0:
            continue

        try:
            _, summary = sensors.remove_first_principal_component(
                use_depth_residuals=True,
                remove_autocorrelations=True,
                filter_low_setpoint=filter_low_setpoint,
            )
        except Exception:  # pragma: no cover - defensive
            continue

        if "noise_var" not in summary.columns:
            continue

        noise_var = summary["noise_var"].astype(float)
        noise_var = noise_var.dropna()
        total_noise = noise_var.sum()
        if total_noise <= 0:
            continue

        shares = noise_var / total_noise
        dive_label = _dive_label(dive)
        dive_id = getattr(dive, "dive_id", None)

        for raw_sensor, share in shares.items():
            if not np.isfinite(share):
                continue
            records.append(
                {
                    "timestamp": timestamp,
                    "sensor_label": _sensor_label(str(raw_sensor)),
                    "share": float(share),
                    "dive_label": dive_label,
                    "dive_id": dive_id,
                }
            )

    if not records:
        raise ValueError("No noise share data available for the supplied dives.")

    df_records = _pd.DataFrame.from_records(records)
    df_records.sort_values("timestamp", inplace=True)

    dive_labels = df_records.groupby("timestamp")[["dive_label", "dive_id"]].first()

    wide = (
        df_records.pivot_table(
            index="timestamp",
            columns="sensor_label",
            values="share",
            aggfunc="first",
        )
        .sort_index()
        .fillna(0.0)
    )

    if wide.empty:
        raise ValueError("Noise share timeseries pivot produced no data.")

    def _sensor_sort_key(label: str) -> tuple[int, str]:
        match = re.search(r"(\d+)", label)
        if match:
            return (int(match.group(1)), label)
        return (int(1e9), label)

    ordered_columns = sorted(wide.columns, key=_sensor_sort_key)
    wide = wide.reindex(columns=ordered_columns, fill_value=0.0)

    dive_labels = dive_labels.reindex(wide.index)
    dive_names = dive_labels["dive_label"].fillna("").to_numpy(dtype=object).reshape(-1, 1)

    fig = go.Figure()

    for label in ordered_columns:
        series = wide[label].astype(float)
        fig.add_trace(
            go.Scatter(
                x=wide.index,
                y=series,
                mode="lines",
                name=label,
                stackgroup="noise",
                customdata=dive_names,
                hovertemplate=f"Dive: %{{customdata[0]}}<br>{label}: %{{y:.1%}}<extra></extra>",
            )
        )

    fig.update_layout(
        template=template,
        title="Sensor Noise Share Over Time",
        xaxis=dict(title="Dive start", type="date"),
        yaxis=dict(title="Noise share", range=[0, 1], tickformat=".0%"),
        hovermode="x unified",
        legend=dict(orientation="h", y=-0.15, x=0.5, xanchor="center"),
        margin=dict(l=65, r=45, t=80, b=60),
    )

    return fig


def plot_noise_variance_timeseries(
    dives: Sequence[Dive] | Iterable[Dive],
    *,
    filter_low_setpoint: bool = False,
    include_temperature: bool = False,
    template: str = "plotly_dark",
) -> "go.Figure":
    """
    Track absolute noise variance per sensor across dives.

    This complements :func:`plot_noise_share_timeseries` by showing whether
    the overall amount of noise is increasing and which sensors contribute most.
    """

    _ensure_plotly()

    if dives is None:
        raise ValueError("dives must be provided.")

    dive_list = list(dives)
    if not dive_list:
        raise ValueError("No dives were supplied.")

    def _coerce_timestamp(value: object) -> _pd.Timestamp | None:
        if value is None:
            return None
        ts = _pd.Timestamp(value)
        if _pd.isna(ts):
            return None
        if ts.tzinfo is not None:
            try:
                ts = ts.tz_convert(None)
            except TypeError:
                ts = ts.tz_localize(None)
        return ts

    def _sensor_label(raw: str) -> str:
        if raw.endswith("_millivolts"):
            raw = raw[: -len("_millivolts")]
        match = re.search(r"sensor(\d+)", raw)
        if match:
            return f"Sensor {int(match.group(1))}"
        return raw.replace("_", " ").title()

    def _dive_label(dive: Dive) -> str:
        label_attr = getattr(dive, "display_name", None)
        if callable(label_attr):
            try:
                label = label_attr()
            except Exception:  # pragma: no cover - defensive
                label = None
        else:
            label = label_attr
        if label:
            return str(label)
        dive_id = getattr(dive, "dive_id", None)
        if dive_id:
            return str(dive_id)
        start = getattr(dive, "start", None)
        ts = _coerce_timestamp(start)
        if ts is not None:
            return ts.strftime("%Y-%m-%d %H:%M")
        return "Dive"

    records: list[dict[str, object]] = []
    temperature_records: list[dict[str, object]] = []

    for dive in dive_list:
        timestamp = _coerce_timestamp(getattr(dive, "start", None))
        if timestamp is None:
            continue

        sensors = getattr(dive, "sensors", None)
        if sensors is None or len(sensors) == 0:
            continue

        ambient_temp = getattr(dive, "temp", None)
        if ambient_temp is None and include_temperature:
            timeseries = getattr(dive, "timeseries", None)
            if timeseries is not None and hasattr(timeseries, "to_df"):
                try:
                    temp_df = timeseries.to_df(["water_temp_f"])
                    ambient_temp = _pd.to_numeric(temp_df.get("water_temp_f"), errors="coerce").dropna().median()
                except Exception:  # pragma: no cover - depends on availability
                    ambient_temp = None

        try:
            _, summary = sensors.remove_first_principal_component(
                use_depth_residuals=True,
                remove_autocorrelations=True,
                filter_low_setpoint=filter_low_setpoint,
            )
        except Exception:  # pragma: no cover - defensive
            continue

        if "noise_var" not in summary.columns:
            continue

        noise_var = summary["noise_var"].astype(float).dropna()
        if noise_var.empty:
            continue

        dive_label = _dive_label(dive)
        dive_id = getattr(dive, "dive_id", None)

        for raw_sensor, value in noise_var.items():
            if not np.isfinite(value):
                continue
            records.append(
                {
                    "timestamp": timestamp,
                    "sensor_label": _sensor_label(str(raw_sensor)),
                    "noise_var": float(value),
                    "dive_label": dive_label,
                    "dive_id": dive_id,
                }
            )

        if include_temperature and ambient_temp is not None:
            try:
                ambient_value = float(ambient_temp.value)
            except (TypeError, ValueError):
                ambient_value = None
            if ambient_value is not None and np.isfinite(ambient_value):
                temperature_records.append(
                    {
                        "timestamp": timestamp,
                        "temperature": ambient_value,
                        "dive_label": dive_label,
                        "dive_id": dive_id,
                    }
                )

    if not records:
        raise ValueError("No noise variance data available for the supplied dives.")

    df_records = _pd.DataFrame.from_records(records)
    df_records.sort_values("timestamp", inplace=True)

    dive_labels = df_records.groupby("timestamp")[["dive_label", "dive_id"]].first()

    wide = (
        df_records.pivot_table(
            index="timestamp",
            columns="sensor_label",
            values="noise_var",
            aggfunc="first",
        )
        .sort_index()
        .fillna(0.0)
    )

    if wide.empty:
        raise ValueError("Noise variance timeseries pivot produced no data.")

    def _sensor_sort_key(label: str) -> tuple[int, str]:
        match = re.search(r"(\d+)", label)
        if match:
            return (int(match.group(1)), label)
        return (int(1e9), label)

    ordered_columns = sorted(wide.columns, key=_sensor_sort_key)
    wide = wide.reindex(columns=ordered_columns, fill_value=0.0)

    totals = wide.sum(axis=1)

    dive_labels = dive_labels.reindex(wide.index)
    dive_names = dive_labels["dive_label"].fillna("").to_numpy(dtype=object).reshape(-1, 1)

    fig = go.Figure()

    for label in ordered_columns:
        series = wide[label].astype(float)
        fig.add_trace(
            go.Bar(
                x=wide.index,
                y=series,
                name=label,
                customdata=dive_names,
                hovertemplate=f"Dive: %{{customdata[0]}}<br>{label}: %{{y:.3e}}<extra></extra>",
            )
        )

    fig.update_traces(marker_line_width=0, selector=dict(type="bar"))
    fig.update_layout(barmode="relative")

    fig.add_trace(
        go.Scatter(
            x=totals.index,
            y=totals.astype(float),
            mode="lines",
            name="Total noise variance",
            line=dict(color="#FFFFFF", width=2, dash="dot"),
            hovertemplate="Total noise variance: %{y:.3e}<extra></extra>",
        )
    )

    layout_kwargs: dict = dict(
        template=template,
        title="Sensor Noise Variance Over Time",
        xaxis=dict(title="Dive start", type="date"),
        yaxis=dict(title="Noise variance (mV²)", rangemode="tozero"),
        hovermode="x unified",
        legend=dict(orientation="h", y=-0.18, x=0.5, xanchor="center"),
        margin=dict(l=65, r=45, t=80, b=65),
    )

    if include_temperature and temperature_records:
        temp_df = (
            _pd.DataFrame.from_records(temperature_records)
            .sort_values("timestamp")
            .dropna(subset=["temperature"])
        )
        if not temp_df.empty:
            fig.add_trace(
                go.Scatter(
                    x=temp_df["timestamp"],
                    y=temp_df["temperature"].astype(float),
                    mode="lines+markers",
                    name="Ambient temperature",
                    line=dict(color="#FFA500", width=2),
                    marker=dict(size=5),
                    yaxis="y2",
                    customdata=temp_df["dive_label"]
                    .fillna("")
                    .to_numpy(dtype=object)
                    .reshape(-1, 1),
                    hovertemplate="Dive: %{customdata[0]}<br>Temp: %{y:.1f} °F<extra></extra>",
                )
            )
            layout_kwargs["yaxis2"] = dict(
                title="Temperature (°F)",
                overlaying="y",
                side="right",
                showgrid=False,
            )

    fig.update_layout(**layout_kwargs)

    return fig
