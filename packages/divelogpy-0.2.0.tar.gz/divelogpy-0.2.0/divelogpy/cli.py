"""Command line entry points for the divelogpy package."""

from __future__ import annotations

import argparse
import getpass
import json
import sys
from pathlib import Path
from typing import Dict, Sequence

from .calibration_store import (
    add_entry,
    calibration_file_path,
    export_store,
    import_store,
)
from .calibration_importer import extract_computer_data_from_images
from .config import get_config_dir
from .openai_client import delete_api_key, load_api_key, save_api_key
from .sensor_report import ReportGenerationError, generate_sensor_report


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="divelogpy", description="Dive log analysis utilities.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    report = subparsers.add_parser(
        "sensor-report",
        help="Generate the sensor dashboard PDF report.",
    )
    report.add_argument("database", help="Path to the .db file or directory containing Shearwater exports.")
    report.add_argument(
        "-o",
        "--output",
        help="Destination PDF path. Defaults to <database>/sensor-report.pdf.",
    )
    report.add_argument("--dive-id", help="Explicit dive id to render.")
    report.add_argument(
        "--dive-index",
        type=int,
        default=-1,
        help="Select the Nth most recent CCR dive when no dive id is given (default: -1).",
    )

    report.add_argument("--start", help="Override the report start date (YYYY-MM-DD).")
    report.add_argument("--end", help="Override the report end date (YYYY-MM-DD).")
    report.add_argument(
        "--image-scale",
        type=float,
        default=1.0,
        help="Scale factor applied when rasterising Plotly figures (default: 1.0).",
    )
    report.add_argument(
        "--pdf-dpi",
        type=int,
        default=50,
        help="DPI to use for embedding plot images into the PDF (default: 150).",
    )

    calibration = subparsers.add_parser(
        "calibration",
        help="Manage manual calibrations for dive computers.",
    )
    cal_subparsers = calibration.add_subparsers(dest="calibration_command", required=True)

    cal_add = cal_subparsers.add_parser(
        "add",
        help="Add a calibration entry using key=value assignments.",
    )
    cal_add.add_argument(
        "assignments",
        nargs="+",
        metavar="key=value",
        help="Calibration fields (serial, sensors, po2/fo2/altitude, timestamp/date).",
    )

    cal_export = cal_subparsers.add_parser(
        "export",
        help="Export manual calibrations to a JSON file or stdout.",
    )
    cal_export.add_argument(
        "path",
        nargs="?",
        default="-",
        help="Destination path or '-' for stdout (default).",
    )

    cal_import = cal_subparsers.add_parser(
        "import",
        help="Replace the calibration store with data from a JSON file.",
    )
    cal_import.add_argument("path", help="Path to a calibration JSON document.")

    cal_images = cal_subparsers.add_parser(
        "import-images",
        help="Extract calibrations from calibration screenshots using OpenAI.",
    )
    cal_images.add_argument(
        "serial",
        help="Dive computer serial number to assign to extracted calibrations.",
    )
    cal_images.add_argument("images", nargs="+", help="Paths to calibration screenshots.")
    cal_images.add_argument(
        "--dry-run",
        action="store_true",
        help="Do not update the calibration store; only print the merged result.",
    )

    openai_parser = subparsers.add_parser(
        "openai",
        help="Manage OpenAI authentication for automated features.",
    )
    openai_subparsers = openai_parser.add_subparsers(dest="openai_command", required=True)

    openai_auth = openai_subparsers.add_parser("auth", help="Store an OpenAI API key for later use.")
    openai_auth.add_argument("--api-key", help="API key value. If omitted, you will be prompted securely.")

    openai_subparsers.add_parser("whoami", help="Display the configured OpenAI key (masked).")
    openai_subparsers.add_parser("logout", help="Remove any stored OpenAI API key.")

    return parser


def _run_sensor_report(args: argparse.Namespace) -> int:
    try:
        result = generate_sensor_report(
            args.database,
            output=args.output,
            dive_id=args.dive_id,
            dive_index=args.dive_index,
            start=args.start,
            end=args.end,
            image_scale=args.image_scale,
            pdf_dpi=args.pdf_dpi,
        )
    except (FileNotFoundError, ReportGenerationError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    print(f"Report written to {result.output_path}")
    if result.warnings:
        print("Warnings:")
        for warning in result.warnings:
            print(f"  - {warning}")

    return 0


def _parse_assignment_tokens(tokens: Sequence[str]) -> Dict[str, str]:
    assignments: Dict[str, str] = {}
    for token in tokens:
        if "=" not in token:
            raise ValueError(f"Invalid assignment {token!r} (expected key=value).")
        key, value = token.split("=", 1)
        key = key.strip().lower()
        value = value.strip()
        if not key:
            raise ValueError("Assignment keys cannot be empty.")
        assignments[key] = value
    return assignments


def _normalise_serial(value: str | None) -> str:
    if value is None:
        return ""
    return value.strip()


def _parse_sensors(value: str | None) -> Sequence[float]:
    if value is None:
        return []
    if not value:
        return []
    parts = [item for chunk in value.split(",") for item in chunk.split()]
    sensors: list[float] = []
    for part in parts:
        text = part.strip()
        if not text:
            continue
        try:
            sensors.append(float(text))
        except ValueError as exc:
            raise ValueError(f"Unable to parse sensor value {text!r}.") from exc
    return sensors


def _parse_optional_float(assignments: Dict[str, str], *aliases: str) -> float | None:
    for alias in aliases:
        if alias in assignments:
            try:
                return float(assignments[alias])
            except ValueError as exc:
                raise ValueError(f"Unable to parse {alias} value {assignments[alias]!r}.") from exc
    return None


def _run_calibration(args: argparse.Namespace) -> int:
    command = args.calibration_command

    if command == "import":
        try:
            import_store(Path(args.path))
        except (OSError, ValueError) as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1
        print(f"Imported calibrations into {calibration_file_path()}")
        return 0

    if command == "export":
        destination = args.path
        try:
            content = export_store(None if destination == "-" else Path(destination))
        except OSError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1
        if content is None:
            print(f"Exported calibrations to {destination}")
        else:
            print(content)
        return 0

    if command == "add":
        try:
            assignments = _parse_assignment_tokens(args.assignments)
        except ValueError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1

        serial = _normalise_serial(
            assignments.get("serial")
            or assignments.get("computer-serial-number")
            or assignments.get("computer_serial_number")
        )
        if not serial:
            print("error: 'serial' (or computer-serial-number) is required.", file=sys.stderr)
            return 1

        try:
            sensors = _parse_sensors(assignments.get("sensors"))
        except ValueError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1
        if not sensors:
            print("error: 'sensors' must include at least one value.", file=sys.stderr)
            return 1

        try:
            po2 = _parse_optional_float(assignments, "po2", "calibration_po2", "ppo2", "calibration_ppo2")
            fo2 = _parse_optional_float(assignments, "fo2", "calibration_fo2")
            altitude = _parse_optional_float(assignments, "altitude", "calibration_mbar")
        except ValueError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1

        if po2 is None and not (fo2 is not None and altitude is not None):
            print("error: 'po2' is required unless both 'fo2' and 'altitude' are provided.", file=sys.stderr)
            return 1

        timestamp = assignments.get("timestamp") or assignments.get("date")

        try:
            entry = add_entry(
                serial,
                sensors,
                po2=po2,
                fo2=fo2,
                altitude=altitude,
                timestamp=timestamp,
            )
        except (ValueError, OSError) as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1

        print(
            "Added calibration for "
            f"{serial} at {entry.timestamp.isoformat().replace('+00:00', 'Z')} -> "
            f"{', '.join(f'{value:.2f}' for value in entry.sensors)}"
        )
        print(f"Stored in {calibration_file_path()}")
        return 0

    if command == "import-images":
        serial_raw = args.serial.strip()
        if "=" in serial_raw:
            serial_raw = serial_raw.split("=", 1)[1]
        serial = serial_raw.strip()
        if not serial:
            print("error: serial is required", file=sys.stderr)
            return 1

        image_paths = [Path(item) for item in args.images]

        def override(entry: Dict[str, object]) -> Dict[str, object]:
            entry = dict(entry)
            entry["serial"] = serial
            if entry.get("po2") is None:
                entry["po2"] = 1.0
            return entry

        try:
            result = extract_computer_data_from_images(
                image_paths,
                update_store=not args.dry_run,
                override_fields=override,
            )
        except (OSError, ValueError, RuntimeError) as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1
        print(json.dumps(result, indent=2, sort_keys=True))
        if args.dry_run:
            print("(Dry run) Calibration store not updated.")
        else:
            print(f"Updated {calibration_file_path()}")
        return 0

    print("error: unknown calibration command", file=sys.stderr)
    return 1


def _run_openai(args: argparse.Namespace) -> int:
    command = args.openai_command

    if command == "auth":
        api_key = args.api_key
        if not api_key:
            try:
                api_key = getpass.getpass("OpenAI API key: ")
            except (EOFError, KeyboardInterrupt):
                print("", file=sys.stderr)
                return 1
        api_key = api_key.strip()
        if not api_key:
            print("error: API key cannot be empty", file=sys.stderr)
            return 1
        try:
            save_api_key(api_key)
        except ValueError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1
        key_path = get_config_dir() / "openai.json"
        print(f"API key stored in {key_path}")
        return 0

    if command == "whoami":
        api_key = load_api_key()
        if not api_key:
            print("No OpenAI API key configured.")
            return 0
        masked = f"{api_key[:4]}...{api_key[-4:]}" if len(api_key) > 8 else "(hidden)"
        print(f"OpenAI key: {masked}")
        return 0

    if command == "logout":
        delete_api_key()
        key_path = get_config_dir() / "openai.json"
        print(f"Removed stored OpenAI API key (expected location {key_path}).")
        return 0

    print("error: unknown openai command", file=sys.stderr)
    return 1


def main(argv: Sequence[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.command == "sensor-report":
        return _run_sensor_report(args)
    if args.command == "calibration":
        return _run_calibration(args)
    if args.command == "openai":
        return _run_openai(args)

    parser.print_help()
    return 1


if __name__ == "__main__":  # pragma: no cover - CLI entry point
    sys.exit(main())
