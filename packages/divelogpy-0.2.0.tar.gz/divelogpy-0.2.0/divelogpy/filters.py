"""Filtering helpers for dive log collections."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import (
    Any,
    Callable,
    ClassVar,
    Generic,
    Iterable,
    Mapping,
    Sequence,
    TYPE_CHECKING,
    TypeVar,
)

T = TypeVar("T")


Predicate = Callable[[Any], bool]
class FilterOperators:
    """Factory helpers for common predicate shapes."""

    @staticmethod
    def custom(func: Callable[[Any], bool]) -> Predicate:
        return func
    @staticmethod
    def eq(expected: Any) -> Predicate:
        return lambda value: value == expected

    @staticmethod
    def ne(expected: Any) -> Predicate:
        return lambda value: value != expected

    @staticmethod
    def gt(expected: Any) -> Predicate:
        # if not isinstance(expected,(DateClass,pd.Timestamp))
        return lambda value: value is not None and value > expected

    @staticmethod
    def ge(expected: Any) -> Predicate:
        return lambda value: value is not None and value >= expected

    @staticmethod
    def lt(expected: Any) -> Predicate:
        return lambda value: value is not None and value < expected

    @staticmethod
    def le(expected: Any) -> Predicate:
        return lambda value: value is not None and value <= expected

    @staticmethod
    def contains(member: Any) -> Predicate:
        return lambda value: member in value if value is not None else False

    @staticmethod
    def in_(members: Sequence[Any]) -> Predicate:
        members_set = set(members)
        return lambda value: value in members_set

    @staticmethod
    def not_in(members: Sequence[Any]) -> Predicate:
        members_set = set(members)
        return lambda value: value not in members_set

    @staticmethod
    def between(lower: Any, upper: Any, *, inclusive: bool = True) -> Predicate:
        if inclusive:
            return lambda value: value is not None and lower <= value <= upper
        return lambda value: value is not None and lower < value < upper

    @staticmethod
    def is_none() -> Predicate:
        return lambda value: value is None

    @staticmethod
    def not_none() -> Predicate:
        return lambda value: value is not None

    @staticmethod
    def all_(*predicates: Predicate) -> Predicate:
        normalized = [p for p in predicates if p is not None]
        if not normalized:
            return lambda value: True
        return lambda value: all(predicate(value) for predicate in normalized)

    @staticmethod
    def any_(*predicates: Predicate) -> Predicate:
        normalized = [p for p in predicates if p is not None]
        if not normalized:
            return lambda value: False
        return lambda value: any(predicate(value) for predicate in normalized)

    def is_true() -> Predicate:
        return lambda value: bool(value) is True
    def is_false() -> Predicate:
        return lambda value: bool(value) is False

class Filter(ABC, Generic[T]):
    """Generic predicate driven filter base class."""

    SUPPORTED_FIELDS: ClassVar[Sequence[str]] = ()

    def __init__(self, **criteria: Mapping[str, Predicate | Any]) -> None:
        unsupported = sorted(set(criteria) - set(self.SUPPORTED_FIELDS))
        if unsupported:
            raise ValueError(f"Unsupported filter fields for {self.__class__.__name__}: {', '.join(unsupported)}")

        self._criteria: dict[str, Predicate] = {}
        for field, predicate in criteria.items():
            self._criteria[field] = self._normalize_predicate(predicate)

    def matches(self, item: T) -> bool:
        """Return True when *item* satisfies all configured predicates."""

        for field, predicate in self._criteria.items():
            value = self.resolve_field(item, field)
            if not predicate(value):
                return False
        return True

    def resolve_field(self, item: T, field: str) -> Any:
        """Resolve *field* on *item* (override for custom lookups)."""
        return getattr(item, field, None)

    def is_empty(self) -> bool:
        return not self._criteria

    @staticmethod
    def _normalize_predicate(predicate: Predicate | Any) -> Predicate:
        if callable(predicate):
            return predicate
        return FilterOperators.eq(predicate)


class Filterable(Generic[T], ABC):
    """Mixin that exposes filtering helpers for collections."""

    @abstractmethod
    def _from_iterable(self, items: Iterable[T]) -> "Filterable[T]":
        """Return a new instance built from *items*."""

    @abstractmethod
    def __iter__(self):
        ...

    def filter(self, filter_obj: Filter[T] | None = None) -> "Filterable[T]":
        """Return a new collection filtered by *filter_obj*."""
        items = list(self)
        if filter_obj is None or getattr(filter_obj, "is_empty", lambda: True)():
            return self._from_iterable(items)
        return self._from_iterable(item for item in items if filter_obj.matches(item))  # type: ignore[arg-type]


class DiveFilter(Filter["Dive"]):
    """Filter helper targeted at :class:`Dive` instances."""

    SUPPORTED_FIELDS: ClassVar[Sequence[str]] = (
        "dive_id",
        "computer_name",
        "start",
        "end",
        "duration_seconds",
        "is_air_integrated",
        "mode",
        "temp",
        "max_depth",
        "computer_names",
        "payload",
        "primary_computer",
        "controller",
        "monitor",
        "secondary_computer",
        "gas_profiles",
        "tank_data",
        "linked_dives",
        "sensors"
        
    )


class SensorFilter(Filter["Sensor"]):
    """Filter helper targeted at :class:`Sensor` instances."""

    SUPPORTED_FIELDS: ClassVar[Sequence[str]] = (
        "sensor_index",
        "calibration_ppo2",
        "timeseries",
        "calibration_mv",
        "milivolts",
        "ppo2",
    )


class AIFilter(Filter["AirIntegrationSeries"]):
    """Filter helper targeted at :class:`AirIntegrationSeries` instances."""

    SUPPORTED_FIELDS: ClassVar[Sequence[str]] = (
        "name",
        "tank_index",
        "start_pressure",
        "end_pressure",
        "tank_size",
        "samples",
        "default_script_term",
        "transmitter_serial",
        "is_enabled",
        "gas_profile",
        "depth_ft",
        "time",
        "sensor_field",
        "tank",
        "pressure_drop",
        "sample_count",
        "start_time_seconds",
        "end_time_seconds",
    )

    def resolve_field(self, item: "AirIntegrationSeries", field: str) -> Any:
        # Allow access to both dataclass fields and computed properties.
        if hasattr(item.__class__, field):
            attr = getattr(item.__class__, field)
            if isinstance(attr, property):
                return getattr(item, field)
        return super().resolve_field(item, field)


if TYPE_CHECKING:  # pragma: no cover - hints only
    from .models import AirIntegrationSeries, Dive, Sensor
