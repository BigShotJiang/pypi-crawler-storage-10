"""Shared helpers for divelogpy configuration directories."""

from __future__ import annotations

import os
from pathlib import Path


def get_config_dir() -> Path:
    """Return the configuration directory used for persistent state."""

    base = os.environ.get("DIVELOGPY_CONFIG_DIR")
    if base:
        return Path(base).expanduser()
    return Path.home() / ".divelogpy"


def ensure_config_dir() -> Path:
    """Ensure the configuration directory exists and return it."""

    config_dir = get_config_dir()
    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir
