# pip install moviepy==1.0.3 pillow pandas numpy

from __future__ import annotations

import os
import math
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Tuple, Type
from abc import ABC, abstractmethod

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont
from moviepy.editor import VideoFileClip, concatenate_videoclips

import importlib.resources as pkg_resources
import divelogpy.assets  # must contain Petrel3.png


# ========================= Base Template =========================

class ComputerOverlayTemplate(ABC):
    """
    Abstract base for all computer overlay templates.
    Child classes define:
      - class constants for layout, fonts, colors, etc.
      - classmethod to_dataframe(dive) -> DataFrame with expected columns and DatetimeIndex
    """

    # ---- Asset & style (override in child) ----
    OVERLAY_ASSET: str = ""  # e.g., "Petrel3.png"
    GREEN_RGB: Tuple[int, int, int] = (0, 255, 90)
    GLOW_RGB: Tuple[int, int, int] = (0, 120, 40)
    FONT_SIZE: int = 82
    FONT_PATH: str = "/System/Library/Fonts/Supplemental/Arial.ttf"
    OVERLAY_MARGIN_PX: int = 24

    # ---- Grid geometry (overlay-relative) ----
    SCREEN_LEFT: int = 0
    SCREEN_RIGHT: int = 0
    ROW1_Y: int = 0
    ROW12_SPACING: int = 0
    ROW23_SPACING: int = 0

    ROW1_CELLS: int = 0
    ROW2_CELLS: int = 0
    ROW3_CELLS: int = 0

    ROW1_FIELDS: List[str | None] = []
    ROW2_FIELDS: List[str | None] = []
    ROW3_FIELDS: List[str | None] = []

    CENTER_IN_CELL: bool = True

    # Row-3 tweaks
    ROW3_SHIFT_X: int = 0
    ROW3_COLUMN_OFFSETS: List[int] | None = None  # length must match ROW3_CELLS when provided

    # ---- Required API ----
    @classmethod
    @abstractmethod
    def to_dataframe(cls, dive) -> pd.DataFrame:
        """
        Return a DataFrame indexed by timestamps with all required columns for this template.
        At minimum for Petrel CC:
          depth_ft, next_stop_depth_ft, s1_ppo2, s2_ppo2, s3_ppo2,
          gas_o2_percent, gas_he_percent, gradient_factor_99, time_to_surface_raw
        """
        raise NotImplementedError

    # ---- Helpers (common across templates) ----
    @classmethod
    def overlay_path(cls) -> Path:
        return Path(pkg_resources.files(divelogpy.assets) / cls.OVERLAY_ASSET)

    @classmethod
    def _default_font(cls, size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
        try:
            return ImageFont.truetype(cls.FONT_PATH, size)
        except Exception:
            return ImageFont.load_default()

    @classmethod
    def _cell_centers(cls, n_cells: int, x_left: int, x_right: int) -> List[int]:
        if n_cells <= 1:
            return [int((x_left + x_right) / 2)]
        return [int(x) for x in np.linspace(x_left, x_right, n_cells)]

    @classmethod
    def build_field_positions(cls) -> Dict[str, Tuple[int, int]]:
        """Return {field_name: (x_center, y_baseline)} for all rows."""
        pos: Dict[str, Tuple[int, int]] = {}

        # Row 1
        r1_y = cls.ROW1_Y
        r1_xc = cls._cell_centers(cls.ROW1_CELLS, cls.SCREEN_LEFT, cls.SCREEN_RIGHT)
        for field, xc in zip(cls.ROW1_FIELDS, r1_xc):
            if field:
                pos[field] = (xc, r1_y)

        # Row 2 (align under first 3 columns of row 1 if that pattern is desired)
        r2_y = cls.ROW1_Y + cls.ROW12_SPACING
        r2_xc = cls._cell_centers(cls.ROW2_CELLS, cls.SCREEN_LEFT, cls.SCREEN_RIGHT)
        for field, xc in zip(cls.ROW2_FIELDS, r2_xc):
            if field:
                pos[field] = (xc, r2_y)

        # Row 3 (start from row1 centers, then adjust)
        r3_y = r2_y + cls.ROW23_SPACING
        if cls.ROW3_CELLS == cls.ROW1_CELLS:
            base_xc = r1_xc[:]
        else:
            base_xc = cls._cell_centers(cls.ROW3_CELLS, cls.SCREEN_LEFT, cls.SCREEN_RIGHT)

        if cls.ROW3_COLUMN_OFFSETS:
            r3_xc = [int(x + cls.ROW3_SHIFT_X + off) for x, off in zip(base_xc, cls.ROW3_COLUMN_OFFSETS)]
        else:
            r3_xc = [int(x + cls.ROW3_SHIFT_X) for x in base_xc]

        for field, xc in zip(cls.ROW3_FIELDS, r3_xc):
            if field:
                pos[field] = (xc, r3_y)

        return pos


# ========================= Petrel-3 CC Template =========================

class Petrel3CCOverlay(ComputerOverlayTemplate):
    OVERLAY_ASSET   = "Petrel3.png"
    GREEN_RGB       = (0, 255, 90)
    GLOW_RGB        = (0, 120, 40)
    FONT_SIZE       = 82
    FONT_PATH       = "/System/Library/Fonts/Supplemental/Arial.ttf"
    OVERLAY_MARGIN_PX = 24

    SCREEN_LEFT     = 325
    SCREEN_RIGHT    = 820
    ROW1_Y          = 530
    ROW12_SPACING   = 130
    ROW23_SPACING   = 210

    ROW1_CELLS      = 4
    ROW2_CELLS      = 3
    ROW3_CELLS      = 4

    ROW1_FIELDS = ["depth_ft", "elapsed_minutes", "next_stop_depth_ft", None]
    ROW2_FIELDS = ["s1_ppo2", "s2_ppo2", "s3_ppo2"]
    ROW3_FIELDS = ["cc_indicator", "gas_mix", "gradient_factor_99", "time_to_surface_raw"]

    ROW3_SHIFT_X = -10
    ROW3_COLUMN_OFFSETS = [-15, -10, +16, +36]  # [CC, gas, GF99, TTS]

    @classmethod
    def to_dataframe(cls, dive) -> pd.DataFrame:
        """
        Default mapping for your Petrel CC overlay.
        Expects `dive.timeseries.to_df()` to return a DataFrame with a DatetimeIndex
        and the necessary columns. Add/compute any missing ones here.
        """
        df = dive.timeseries.to_df().copy()


        s1, s2, s3 = dive.sensors
        df['s1_ppo2'] = np.round(s1.predict_ppo2(df['sensor1_millivolts']), 2)
        df['s2_ppo2'] = np.round(s2.predict_ppo2(df['sensor2_millivolts']), 2)
        df['s3_ppo2'] = np.round(s3.predict_ppo2(df['sensor3_millivolts']), 2)
        for col in [
            "depth_ft",
            "next_stop_depth_ft",
            "s1_ppo2", "s2_ppo2", "s3_ppo2",
            "gas_o2_percent", "gas_he_percent",
            "gradient_factor_99",
            "time_to_surface_raw",
        ]:
            if col not in df.columns:
                df[col] = np.nan

        return df


# Template registry (classes, not instances)
TEMPLATES: Dict[str, Type[ComputerOverlayTemplate]] = {
    "petrel3_cc": Petrel3CCOverlay,
}


# ========================= Rendering Helpers =========================

def _render_text_pil(
    text: str,
    *,
    color: Tuple[int, int, int],
    glow_color: Tuple[int, int, int],
    font_path: str,
    font_size: int,
    glow: bool = True,
) -> np.ndarray:
    font = _safe_font(font_path, font_size)
    # Measure text
    probe = Image.new("RGBA", (10, 10), (0, 0, 0, 0))
    d = ImageDraw.Draw(probe)
    bbox = d.textbbox((0, 0), text, font=font)
    w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]

    pad = int(font_size * 0.25)
    img = Image.new("RGBA", (w + 2 * pad, h + 2 * pad), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    if glow:
        for dx, dy, alpha in [(-1, 0, 80), (1, 0, 80), (0, -1, 80), (0, 1, 80)]:
            draw.text((pad + dx, pad + dy), text, font=font, fill=(*glow_color, alpha))

    draw.text((pad, pad), text, font=font, fill=(*color, 255))
    return np.array(img)

def _render_text_pil_tight(
    text: str,
    *,
    color: Tuple[int, int, int],
    font_path: str,
    font_size: int,
    spacing: int = -8,  # negative = tighter; used for "CC"
) -> np.ndarray:
    """Render with adjustable character spacing (tracking)."""
    font = _safe_font(font_path, font_size)

    char_imgs: List[Image.Image] = []
    total_w = 0
    max_h = 0

    for ch in text:
        canvas = Image.new("RGBA", (font_size * 2, font_size * 2), (0, 0, 0, 0))
        d = ImageDraw.Draw(canvas)
        d.text((0, 0), ch, font=font, fill=color)
        bbox = canvas.getbbox()
        if bbox:
            w, h = bbox[2], bbox[3]
            crop = canvas.crop((0, 0, w, h))
        else:
            w = h = font_size
            crop = canvas
        char_imgs.append(crop)
        total_w += w + spacing
        max_h = max(max_h, h)

    total_w = max(1, total_w - spacing)
    final_img = Image.new("RGBA", (total_w, max_h), (0, 0, 0, 0))
    x = 0
    for im in char_imgs:
        final_img.alpha_composite(im, (x, 0))
        x += im.size[0] + spacing

    return np.array(final_img)

def _safe_font(path: str, size: int):
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()

def _resolve_video_start_timestamp(
    video_path: str,
    provided_ts: pd.Timestamp | None,
    df_index: pd.DatetimeIndex,
) -> pd.Timestamp:
    """
    Use user-provided timestamp when available; otherwise derive it from the video file's
    creation time (falling back to modification time). Align the timezone with the dive data.
    """
    if provided_ts is not None:
        ts = pd.Timestamp(provided_ts)
    else:
        stat = Path(video_path).stat()
        ts_epoch = getattr(stat, "st_birthtime", None)
        if ts_epoch is None:
            ts_epoch = stat.st_mtime
        ts = pd.Timestamp(datetime.fromtimestamp(ts_epoch, tz=timezone.utc))

    if isinstance(df_index, pd.DatetimeIndex) and df_index.tz is not None:
        if ts.tzinfo is None:
            ts = ts.tz_localize(df_index.tz)
        else:
            ts = ts.tz_convert(df_index.tz)
    return ts

def _slice_df_to_video_window(
    df: pd.DataFrame,
    video_start_ts: pd.Timestamp,
    video_duration_s: float,
) -> pd.DataFrame:
    """Return df rows within [video_start_ts, video_start_ts + duration), plus t_sec from video start."""
    df2 = df.copy()
    if not isinstance(df2.index, pd.DatetimeIndex):
        df2.index = pd.to_datetime(df2.index)

    # tz alignment
    if video_start_ts.tzinfo is None and df2.index.tz is not None:
        video_start_ts = video_start_ts.tz_localize(df2.index.tz)
    if video_start_ts.tzinfo is not None and df2.index.tz is None:
        df2.index = df2.index.tz_localize(video_start_ts.tzinfo)

    start_ts = video_start_ts
    end_ts = start_ts + pd.to_timedelta(video_duration_s, unit="s")

    window = df2.loc[(df2.index >= start_ts) & (df2.index <= end_ts)].copy()

    if window.empty:
        prev = df2.loc[df2.index < start_ts].tail(1)
        if prev.empty:
            return window
        window = prev.copy()

    prev_row = df2.loc[df2.index < start_ts].tail(1)
    if not prev_row.empty:
        window = pd.concat([prev_row, window])

    if start_ts not in window.index:
        if not prev_row.empty:
            start_values = prev_row.iloc[0]
        else:
            start_values = window.iloc[0]
        window.loc[start_ts] = start_values

    window = window.sort_index()
    window = window.loc[(window.index >= start_ts) & (window.index < end_ts)].copy()

    if window.empty:
        return window

    window["t_sec"] = (window.index - start_ts).total_seconds()
    return window

def _iter_spans(df_excerpt: pd.DataFrame, clip_duration: float):
    """Yield (i, start, dur). Duration extends to next row or clip end."""
    t = df_excerpt["t_sec"].to_numpy()
    n = len(df_excerpt)
    for i in range(n):
        start = float(t[i])
        stop = float(t[i + 1]) if i + 1 < n else clip_duration
        dur = max(0.0, stop - start)
        if dur > 0:
            yield i, start, dur


class _OverlayRenderer:
    """Stateful helper that composites the static overlay plus dynamic text onto each frame."""

    _EPS = 1e-6

    def __init__(
        self,
        *,
        template_cls: Type[ComputerOverlayTemplate],
        overlay_rgba: np.ndarray,
        overlay_position: Tuple[int, int],
        field_positions: Dict[str, Tuple[int, int]],
        field_segments: Dict[str, List[Tuple[float, float, str]]],
        text_cache: Dict[Tuple[str, str], Image.Image],
    ):
        self.template_cls = template_cls
        self.overlay_position = overlay_position
        self.field_positions = field_positions
        self.field_segments = field_segments
        self.text_cache = text_cache

        self.fields = list(field_positions.keys())
        self._base_overlay_image = Image.fromarray(overlay_rgba)
        self._current_overlay_rgba = np.array(overlay_rgba, copy=True)
        self._current_overlay_rgb_float = self._current_overlay_rgba[..., :3].astype(np.float32)
        alpha = self._current_overlay_rgba[..., 3].astype(np.float32) / 255.0
        self._current_overlay_alpha = alpha[..., None]
        self._current_state_key: Tuple[str | None, ...] | None = None

        self._indices = {field: 0 for field in self.fields}
        self._last_t = -np.inf

    def _reset_indices(self):
        for field in self.fields:
            self._indices[field] = 0
        self._last_t = -np.inf

    def _state_at(self, t: float) -> Dict[str, str | None]:
        """Return {field: text_or_None} for time t."""
        if t + self._EPS < self._last_t:
            self._reset_indices()
        self._last_t = t

        state: Dict[str, str | None] = {}
        for field in self.fields:
            segments = self.field_segments.get(field, [])
            if not segments:
                state[field] = None
                continue

            idx = self._indices[field]
            while idx < len(segments) and t >= segments[idx][1] - self._EPS:
                idx += 1
            self._indices[field] = idx

            if idx >= len(segments):
                state[field] = None
                continue

            start, end, text = segments[idx]
            if start - self._EPS <= t < end - self._EPS:
                state[field] = text
            else:
                state[field] = None
        return state

    def _build_overlay_patch(self, state: Dict[str, str | None]) -> np.ndarray:
        patch = self._base_overlay_image.copy()
        for field in self.fields:
            text = state.get(field)
            if not text:
                continue
            key = (field, text)
            text_img = self.text_cache.get(key)
            if text_img is None:
                continue

            x_center, y_baseline = self.field_positions[field]
            w, h = text_img.size
            if self.template_cls.CENTER_IN_CELL:
                x = x_center - w // 2
            else:
                x = x_center
            y = y_baseline - int(h * 0.70)

            patch.paste(text_img, (x, y), text_img)

        patch_arr = np.asarray(patch)
        return patch_arr

    def _ensure_overlay_patch(self, state: Dict[str, str | None]) -> np.ndarray:
        key = tuple(state.get(field) for field in self.fields)
        if key != self._current_state_key:
            self._current_overlay_rgba = self._build_overlay_patch(state)
            self._current_overlay_rgb_float = self._current_overlay_rgba[..., :3].astype(np.float32)
            alpha = self._current_overlay_rgba[..., 3].astype(np.float32) / 255.0
            self._current_overlay_alpha = alpha[..., None]
            self._current_state_key = key
        return self._current_overlay_rgba

    def _composite_overlay(self, frame: np.ndarray, overlay_rgba: np.ndarray) -> np.ndarray:
        frame_out = np.array(frame, copy=True)
        x0, y0 = self.overlay_position
        oh, ow = overlay_rgba.shape[0], overlay_rgba.shape[1]

        if oh <= 0 or ow <= 0:
            return frame_out

        y1, x1 = y0 + oh, x0 + ow
        if y1 > frame_out.shape[0] or x1 > frame_out.shape[1]:
            return frame_out

        sub = frame_out[y0:y1, x0:x1]
        alpha = self._current_overlay_alpha
        if alpha.size == 0 or not np.any(alpha):
            return frame_out

        overlay_rgb = self._current_overlay_rgb_float
        sub[:] = (overlay_rgb * alpha + sub.astype(np.float32) * (1.0 - alpha)).astype(np.uint8)
        return frame_out

    def apply(self, frame: np.ndarray, t: float) -> np.ndarray:
        state = self._state_at(float(t))
        overlay_rgba = self._ensure_overlay_patch(state)
        return self._composite_overlay(frame, overlay_rgba)

# ========================= Public API =========================

def overlay_computer(
    *,
    video_path: str,
    dive,
    video_start_ts: pd.Timestamp | None = None,
    template_cls: Type[ComputerOverlayTemplate] = Petrel3CCOverlay,
    out_path: str | None = None,
    test_mode: bool = False,
    test_total_duration: float = 15.0,
    test_segment_duration: float = 5.0,
    overlay_opacity: float = 1.0,
) -> str:
    """
    Render the video with an overlay defined by `template_cls`.

    Args:
        video_path: Path to the source video file.
        dive: Dive object compatible with the template's `to_dataframe`.
        video_start_ts: Optional explicit timestamp for the first video frame.
            When omitted, the file creation time (falling back to modification time)
            is used, aligned to the dive data's timezone.
        template_cls: Overlay layout/template class.
        out_path: Optional output path. Default is `<stem>_with_overlay.mp4`.
        test_mode: When True, render a diagnostic clip by sampling short segments
            throughout the dive so the output lasts about `test_total_duration` seconds.
        test_total_duration: Target runtime in seconds for the diagnostic output.
        test_segment_duration: Duration of each sampled segment in seconds.
        overlay_opacity: Multiplier applied to the overlay PNG alpha channel (0.0–1.0).
            Values below 1.0 make the bezel more transparent while keeping the text crisp.
    """
    if not (0.0 <= overlay_opacity <= 1.0):
        raise ValueError("overlay_opacity must be within [0.0, 1.0].")

    df = template_cls.to_dataframe(dive)
    df_index = df.index if isinstance(df.index, pd.DatetimeIndex) else pd.DatetimeIndex(pd.to_datetime(df.index))

    resolved_start_ts = _resolve_video_start_timestamp(video_path, video_start_ts, df_index)

    base_clip = VideoFileClip(video_path)
    base_duration = base_clip.duration
    fps = base_clip.fps

    df_ex = _slice_df_to_video_window(df, resolved_start_ts, base_duration)
    if df_ex.empty:
        base_clip.close()
        raise ValueError(
            "No data rows fall within the video window. "
            "Verify the inferred video start time and your dive data."
        )

    overlay_rgba = np.array(Image.open(str(template_cls.overlay_path())).convert("RGBA"))
    if overlay_opacity < 1.0:
        overlay_rgba = overlay_rgba.copy()
        alpha = overlay_rgba[..., 3].astype(np.float32) * overlay_opacity
        overlay_rgba[..., 3] = np.clip(alpha, 0, 255).astype(np.uint8)

    vx, vy = base_clip.w, base_clip.h
    oy, ox = overlay_rgba.shape[0], overlay_rgba.shape[1]
    overlay_pos_xy = (vx - ox - template_cls.OVERLAY_MARGIN_PX, vy - oy - template_cls.OVERLAY_MARGIN_PX)

    field_pos = template_cls.build_field_positions()

    t0_ts = df_ex.index[0]

    field_segments: Dict[str, List[Dict[str, float | str]]] = {name: [] for name in field_pos}
    active_segments: Dict[str, Dict[str, float | str]] = {}

    def push_segment(field: str, text: str | None, start: float, dur: float):
        if field not in field_segments:
            return

        if text is None:
            active_segments.pop(field, None)
            return

        last = active_segments.get(field)
        if last and last["text"] == text and abs((last["start"] + last["dur"]) - start) < 1e-6:
            last["dur"] += dur
        else:
            segment = {"text": text, "start": start, "dur": dur}
            field_segments[field].append(segment)
            active_segments[field] = segment

    for i, start, dur in _iter_spans(df_ex, clip_duration=base_duration):
        row = df_ex.iloc[i]
        ts_i = df_ex.index[i]

        if "depth_ft" in row and pd.notna(row["depth_ft"]):
            push_segment("depth_ft", f"{float(row['depth_ft']):.0f}", start, dur)
        else:
            push_segment("depth_ft", None, start, dur)

        elapsed_min = int((float(row['time_seconds']) // 60))
        push_segment("elapsed_minutes", f"{elapsed_min:d}", start, dur)

        if ("next_stop_depth_ft" in row
            and pd.notna(row["next_stop_depth_ft"])
            and float(row["next_stop_depth_ft"]) != 0):
            push_segment("next_stop_depth_ft", f"{float(row['next_stop_depth_ft']):.0f}", start, dur)
        else:
            push_segment("next_stop_depth_ft", None, start, dur)

        for col in ("s1_ppo2", "s2_ppo2", "s3_ppo2"):
            if col in row and pd.notna(row[col]):
                push_segment(col, f"{float(row[col]):.2f}", start, dur)
            else:
                push_segment(col, None, start, dur)

        if "cc_indicator" in field_pos:
            push_segment("cc_indicator", "CC", start, dur)

        if ("gas_o2_percent" in row and "gas_he_percent" in row
            and pd.notna(row["gas_o2_percent"]) and pd.notna(row["gas_he_percent"])):
            o2 = int(row["gas_o2_percent"])
            he = int(row["gas_he_percent"])
            mix = f"{o2:02d}/{he:02d}"
            push_segment("gas_mix", mix, start, dur)
        else:
            push_segment("gas_mix", None, start, dur)

        if ("gradient_factor_99" in row and pd.notna(row["gradient_factor_99"])
            and not (float(row["gradient_factor_99"]) == 255.0)):
            push_segment("gradient_factor_99", f"{int(row['gradient_factor_99'])}", start, dur)
        else:
            push_segment("gradient_factor_99", None, start, dur)

        if "time_to_surface_raw" in row and pd.notna(row["time_to_surface_raw"]):
            push_segment("time_to_surface_raw", f"{int(row['time_to_surface_raw'])}", start, dur)
        else:
            push_segment("time_to_surface_raw", None, start, dur)

    text_cache: Dict[Tuple[str, str], Image.Image] = {}

    def render_text_image(field: str, text: str) -> Image.Image:
        key = (field, text)
        if key in text_cache:
            return text_cache[key]

        if field == "cc_indicator":
            img = _render_text_pil_tight(
                text,
                color=template_cls.GREEN_RGB,
                font_path=template_cls.FONT_PATH,
                font_size=template_cls.FONT_SIZE,
                spacing=0,
            )
        else:
            img = _render_text_pil(
                text,
                color=template_cls.GREEN_RGB,
                glow_color=template_cls.GLOW_RGB,
                font_path=template_cls.FONT_PATH,
                font_size=template_cls.FONT_SIZE,
            )
        text_cache[key] = Image.fromarray(img)
        return text_cache[key]

    field_segment_tuples: Dict[str, List[Tuple[float, float, str]]] = {}
    for field, segments in field_segments.items():
        tuples: List[Tuple[float, float, str]] = []
        for segment in segments:
            text = segment.get("text")
            if not isinstance(text, str):
                continue
            start = float(segment["start"])
            dur = float(segment["dur"])
            end = start + dur
            tuples.append((start, end, text))
            render_text_image(field, text)
        field_segment_tuples[field] = tuples

    renderer = _OverlayRenderer(
        template_cls=template_cls,
        overlay_rgba=overlay_rgba,
        overlay_position=overlay_pos_xy,
        field_positions=field_pos,
        field_segments=field_segment_tuples,
        text_cache=text_cache,
    )

    render_clip = base_clip
    sampled_clips: List[VideoFileClip] = []
    timeline_segments: List[Tuple[float, float, float]] = [(0.0, base_duration, 0.0)]

    if (
        test_mode
        and base_duration > 0
        and test_total_duration > 0
        and test_segment_duration > 0
        and base_duration > test_total_duration
    ):
        target_total = min(test_total_duration, base_duration)
        seg_len = min(test_segment_duration, target_total)
        num_segments = max(1, int(math.ceil(target_total / seg_len)))

        segments: List[Tuple[float, float]] = []
        if num_segments == 1:
            segments.append((0.0, seg_len))
        else:
            spacing = (base_duration - seg_len) / max(1, num_segments - 1)
            cumulative = 0.0
            for idx in range(num_segments):
                start = min(idx * spacing, max(0.0, base_duration - seg_len))
                end = min(start + seg_len, base_duration)
                duration = end - start
                if cumulative + duration > target_total:
                    end = start + max(0.0, target_total - cumulative)
                    duration = end - start
                if duration > 0:
                    segments.append((start, end))
                    cumulative += duration
                if cumulative >= target_total - 1e-6:
                    break

        subclips = [base_clip.subclip(seg_start, seg_end) for seg_start, seg_end in segments if seg_end > seg_start]
        if subclips:
            sampled_clips = subclips
            render_clip = concatenate_videoclips(subclips, method="compose")
            timeline_segments = []
            rel_start = 0.0
            for (seg_start, seg_end), subclip in zip(segments, subclips):
                duration = seg_end - seg_start
                timeline_segments.append((rel_start, rel_start + duration, seg_start))
                rel_start += duration

            if not timeline_segments:
                timeline_segments = [(0.0, base_duration, 0.0)]

    def map_time(t: float, segments: List[Tuple[float, float, float]] = timeline_segments) -> float:
        if not segments:
            return t
        rel_start, rel_end, origin_start = segments[-1]
        for seg_rel_start, seg_rel_end, seg_origin in segments:
            if seg_rel_start <= t < seg_rel_end or math.isclose(t, seg_rel_end, rel_tol=0.0, abs_tol=1e-6):
                return seg_origin + (t - seg_rel_start)
        return origin_start + (t - rel_start)

    final_clip = None
    try:
        final_clip = render_clip.fl(lambda gf, t: renderer.apply(gf(t), map_time(t)))
        if render_clip.audio:
            final_clip = final_clip.set_audio(render_clip.audio)

        if out_path is None:
            p = Path(video_path)
            out_path = str(p.with_name(p.stem + "_with_overlay.mp4"))

        final_clip.write_videofile(
            out_path,
            codec="libx264",
            audio_codec="aac",
            fps=fps,
            preset="faster",
            threads=os.cpu_count(),
        )
    finally:
        if final_clip is not None:
            final_clip.close()
        render_clip.close()
        for clip in sampled_clips:
            clip.close()
        if render_clip is not base_clip:
            base_clip.close()

    return out_path
