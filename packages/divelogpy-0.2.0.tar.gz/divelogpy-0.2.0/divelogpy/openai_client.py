"""Utilities for authenticating and working with the OpenAI API."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

try:  # pragma: no cover - optional dependency
    from openai import OpenAI
except ImportError:  # pragma: no cover - optional dependency
    OpenAI = None  # type: ignore[misc,assignment]

from .config import ensure_config_dir, get_config_dir

_OPENAI_CONFIG_FILE = "openai.json"


def _config_path() -> Path:
    return get_config_dir() / _OPENAI_CONFIG_FILE


def save_api_key(api_key: str) -> None:
    if not api_key or not api_key.strip():
        raise ValueError("API key must be non-empty")
    ensure_config_dir()
    payload = {"api_key": api_key.strip()}
    _config_path().write_text(json.dumps(payload), encoding="utf-8")


def load_api_key() -> Optional[str]:
    env_key = _get_env_api_key()
    if env_key:
        return env_key
    path = _config_path()
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:  # pragma: no cover - defensive
        raise ValueError(f"Unable to parse OpenAI configuration: {exc}") from exc
    key = data.get("api_key")
    if key and isinstance(key, str):
        return key
    return None


def delete_api_key() -> None:
    path = _config_path()
    if path.exists():
        path.unlink()


def _get_env_api_key() -> Optional[str]:
    import os

    candidates = [
        os.environ.get("OPENAI_API_KEY"),
        os.environ.get("OPENAI_APIKEY"),
    ]
    for item in candidates:
        if item and item.strip():
            return item.strip()
    return None


def get_client() -> "OpenAI":
    if OpenAI is None:  # pragma: no cover - optional dependency
        raise RuntimeError(
            "The 'openai' package is required for this feature. Install it with 'pip install openai'."
        )
    api_key = load_api_key()
    if not api_key:
        raise RuntimeError(
            "No OpenAI API key configured. Run 'divelogpy openai auth' or set OPENAI_API_KEY."
        )
    return OpenAI(api_key=api_key)
