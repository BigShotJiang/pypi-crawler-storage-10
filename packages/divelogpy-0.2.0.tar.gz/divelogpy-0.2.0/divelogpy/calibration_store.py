"""Utilities for managing user-specified sensor calibrations."""

from __future__ import annotations

import json
from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence

from .config import ensure_config_dir, get_config_dir

DEFAULT_MAX_AGE_DAYS = 2


def calibration_file_path() -> Path:
    """Return the path of the calibration store JSON file."""

    return get_config_dir() / "calibrations.json"


def _optional_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def parse_timestamp(value: datetime | str) -> datetime:
    """Parse a timestamp or date value into a UTC datetime."""

    if isinstance(value, datetime):
        parsed = value
    else:
        raw = value.strip()
        if raw.endswith("Z"):
            parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        else:
            parsed = datetime.fromisoformat(raw)

    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    else:
        parsed = parsed.astimezone(timezone.utc)
    return parsed


def _coerce_timestamp(value: datetime | str | None, *, default: Callable[[], datetime]) -> datetime:
    if value is None:
        return default()
    return parse_timestamp(value)


def _calibration_file() -> Path:
    return calibration_file_path()


@dataclass
class CalibrationEntry:
    serial: str
    sensors: List[float]
    timestamp: datetime
    import_timestamp: datetime
    po2: Optional[float] = None
    fo2: Optional[float] = None
    altitude_mbar: Optional[float] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CalibrationEntry | None":
        serial = data.get("serial")
        sensors = data.get("sensors")
        timestamp = data.get("timestamp")
        if not serial or not isinstance(serial, str):
            return None
        if not isinstance(sensors, Iterable):
            return None
        try:
            sensors_list = [float(value) for value in sensors]
        except (TypeError, ValueError):
            return None
        if not sensors_list:
            return None
        if not timestamp:
            return None
        try:
            parsed_ts = parse_timestamp(timestamp)
        except ValueError:
            return None

        po2 = _optional_float(data.get("po2")) or _optional_float(data.get("ppo2")) or _optional_float(
            data.get("calibration_po2")
        )
        fo2 = _optional_float(data.get("fo2")) or _optional_float(data.get("calibration_fo2"))
        altitude = _optional_float(data.get("altitude")) or _optional_float(data.get("calibration_mbar"))

        import_raw = data.get("import_timestamp")
        if import_raw:
            try:
                import_ts = parse_timestamp(import_raw)
            except ValueError:
                import_ts = parsed_ts
        else:
            import_ts = parsed_ts

        return cls(
            serial=serial.strip(),
            sensors=sensors_list,
            timestamp=parsed_ts,
            import_timestamp=import_ts,
            po2=po2,
            fo2=fo2,
            altitude_mbar=altitude,
        )

    def to_dict(self) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "serial": self.serial,
            "sensors": self.sensors,
            "timestamp": self.timestamp.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
            "import_timestamp": self.import_timestamp.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
        }
        if self.po2 is not None:
            payload["po2"] = self.po2
        if self.fo2 is not None:
            payload["fo2"] = self.fo2
        if self.altitude_mbar is not None:
            payload["altitude"] = self.altitude_mbar
        return payload

    def to_calibration_payload(self) -> Dict[str, Any]:
        sensors_map = {f"sensor{index + 1}": round(value, 2) for index, value in enumerate(self.sensors)}
        payload: Dict[str, Any] = {"calibration_mv": sensors_map}
        payload['date']=self.timestamp
        if self.fo2 is not None:
            payload["calibration_fo2"] = round(self.fo2, 2)
        if self.po2 is not None:
            payload["calibration_ppo2"] = round(self.po2, 2)
        if self.altitude_mbar is not None:
            payload["calibration_mbar"] = round(self.altitude_mbar, 2)
            payload["calibration_ata"] = round(self.altitude_mbar / 1013.25, 2)

        return payload


def _load_raw_store() -> Dict[str, Any]:
    path = _calibration_file()
    if not path.exists():
        return {"calibrations": []}
    try:
        with path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
    except json.JSONDecodeError as exc:  # pragma: no cover - defensive
        raise ValueError(f"Unable to parse calibration store: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError("Calibration store must be a JSON object.")
    data.setdefault("calibrations", [])
    return data


def load_entries() -> List[CalibrationEntry]:
    store = _load_raw_store()
    entries: List[CalibrationEntry] = []
    for item in store.get("calibrations", []):
        if isinstance(item, dict):
            entry = CalibrationEntry.from_dict(item)
            if entry is not None:
                entries.append(entry)
    entries.sort(key=lambda entry: (entry.timestamp, entry.import_timestamp))
    return entries


def save_entries(entries: Iterable[CalibrationEntry]) -> None:
    ensure_config_dir()
    sorted_entries = sorted(entries, key=lambda e: (e.timestamp, e.import_timestamp))
    payload = {"calibrations": [entry.to_dict() for entry in sorted_entries]}
    path = _calibration_file()
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)


def create_entry(
    serial: str,
    sensors: Sequence[float],
    *,
    po2: float | None = None,
    fo2: float | None = None,
    altitude: float | None = None,
    timestamp: datetime | str | None = None,
    import_timestamp: datetime | str | None = None,
) -> CalibrationEntry:
    serial_value = serial.strip()
    if not serial_value:
        raise ValueError("serial must be provided")

    sensors_list = [float(value) for value in sensors]
    if not sensors_list:
        raise ValueError("sensors must include at least one value")

    now = datetime.now(tz=timezone.utc)
    timestamp_value = _coerce_timestamp(timestamp, default=lambda: now)
    import_value = _coerce_timestamp(import_timestamp, default=lambda: datetime.now(tz=timezone.utc))

    return CalibrationEntry(
        serial=serial_value,
        sensors=sensors_list,
        timestamp=timestamp_value,
        import_timestamp=import_value,
        po2=po2,
        fo2=fo2,
        altitude_mbar=altitude,
    )


def merge_entries(
    existing: Iterable[CalibrationEntry],
    new_entries: Iterable[CalibrationEntry],
) -> List[CalibrationEntry]:
    merged: Dict[tuple[str, datetime], CalibrationEntry] = {}
    for entry in existing:
        merged[(entry.serial, entry.timestamp)] = entry
    for entry in new_entries:
        key = (entry.serial, entry.timestamp)
        candidate = entry
        while key in merged:
            candidate = replace(candidate, timestamp=candidate.timestamp + timedelta(milliseconds=1))
            key = (candidate.serial, candidate.timestamp)
        merged[key] = candidate
    return sorted(merged.values(), key=lambda e: (e.timestamp, e.import_timestamp))


def add_entry(
    serial: str,
    sensors: Iterable[float],
    *,
    po2: float | None = None,
    fo2: float | None = None,
    altitude: float | None = None,
    timestamp: datetime | str | None = None,
    import_timestamp: datetime | str | None = None,
) -> CalibrationEntry:
    entry = create_entry(
        serial,
        list(sensors),
        po2=po2,
        fo2=fo2,
        altitude=altitude,
        timestamp=timestamp,
        import_timestamp=import_timestamp,
    )
    merged = merge_entries(load_entries(), [entry])
    save_entries(merged)
    return entry


def export_store(path: Path | None = None) -> str | None:
    entries = load_entries()
    content = json.dumps({"calibrations": [entry.to_dict() for entry in entries]}, indent=2, sort_keys=True)
    if path is None:
        return content
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(content, encoding="utf-8")
    return None


def import_store(path: Path) -> None:
    with Path(path).open("r", encoding="utf-8") as handle:
        raw = json.load(handle)
    if not isinstance(raw, dict) or "calibrations" not in raw:
        raise ValueError("Calibration import expects an object with a 'calibrations' array.")
    entries: List[CalibrationEntry] = []
    for item in raw.get("calibrations", []):
        if not isinstance(item, dict):
            continue
        entry = CalibrationEntry.from_dict(item)
        if entry is None:
            continue
        entries.append(entry)
    save_entries(entries)


def apply_new_entries(new_entries: Iterable[CalibrationEntry], *, commit: bool = True) -> List[CalibrationEntry]:
    merged = merge_entries(load_entries(), new_entries)
    if commit:
        save_entries(merged)
    return merged


def find_recent_calibration(
    serial: str,
    reference: datetime,
    *,
    max_age_days: int = DEFAULT_MAX_AGE_DAYS,
) -> Dict[str, Any] | None:
    if not serial or reference is None:
        return None

    serial_normalised = serial.strip()
    if not serial_normalised:
        return None

    reference_utc = parse_timestamp(reference)
    threshold = reference_utc - timedelta(days=max_age_days)

    candidates = [
        entry for entry in load_entries() if entry.serial == serial_normalised and entry.timestamp <= reference_utc
    ]
    if not candidates:
        return None
    latest = max(candidates, key=lambda entry: (entry.timestamp, entry.import_timestamp))
    if latest.timestamp < threshold:
        return None
    return latest.to_calibration_payload()
