"""Domain models used by the dive log client."""

from __future__ import annotations
import pandas as pd
import numpy as np
from dataclasses import dataclass, field
import math
from datetime import datetime
from typing import (
    Any,
    Dict,
    Iterable,
    Iterator,
    List,
    Mapping,
    Sequence,
    Optional,
    Tuple,
    TYPE_CHECKING,
    Union,
    cast,
)
from enum import Enum

from .filters import (
    Filterable,
    SensorFilter,
    AIFilter,
    DiveFilter,
    FilterOperators as fo,
)

# --- Units & constants ---
PSI_PER_BAR = 14.5038
L_PER_CUFT = 28.3168


if TYPE_CHECKING:  # pragma: no cover - type hints only
    from .timeseries import DiveTimeSeries


class UnitMeasure:
    """Wrap a numeric value with unit conversion helpers."""

    _CONVERSIONS = {
        ("F", "C"): lambda value: (value - 32.0) * 5.0 / 9.0,
        ("C", "F"): lambda value: value * 9.0 / 5.0 + 32.0,
    }

    def __init__(self, value: float | None, unit: str) -> None:
        self._value = value
        self._unit = unit.upper() if unit else unit

    @property
    def value(self) -> float | None:
        return self._value

    @property
    def unit(self) -> str:
        return self._unit

    @property
    def available_units(self) -> Sequence[str]:
        units = set()
        if self._unit:
            units.add(self._unit)
        for base, target in self._CONVERSIONS:
            units.add(base)
            units.add(target)
        return sorted(u for u in units if u)

    def as_unit(self, target_unit: str) -> float | None:
        """Return the value converted to *target_unit* (if possible)."""
        if self._value is None:
            return None
        target = target_unit.upper()
        if target == self._unit:
            return self._value
        key = (self._unit, target)
        if key not in self._CONVERSIONS:
            raise ValueError(f"Unsupported conversion {self._unit} -> {target}")
        return self._CONVERSIONS[key](self._value)

    def convert(self, target_unit: str) -> "UnitMeasure":
        """Return a new :class:`UnitMeasure` in the requested unit."""
        return UnitMeasure(self.as_unit(target_unit), target_unit)

    def __repr__(self) -> str:  # pragma: no cover - convenience only
        return f"UnitMeasure(value={self._value!r}, unit='{self._unit}')"


class Sensor:
    """PO₂ sensor samples for a single sensor."""

    sensor_index: int
    calibration_ppo2: float | None
    timeseries: pd.DataFrame
    calibration_mv: float | None = None
    milivolts: pd.Series
    ppo2: pd.Series

    def __init__(
        self,
        sensor_index: int,
        timeseries: pd.DataFrame,
        calibration_ppo2: float | None = None,
        calibration_mv: float | None = None,
    ):
        self.sensor_index = sensor_index
        self.timeseries = timeseries
        self.calibration_ppo2 = calibration_ppo2 or 0.99
        self.calibration_mv = (
            calibration_mv
            or self.timeseries.reset_index()
            .set_index("average_ppo2")
            .loc[self.calibration_ppo2][f"sensor{self.sensor_index}_millivolts"]
            .mean()
            if not self.timeseries.empty
            else None
        )
        self.milivolts = (
            self.timeseries[f"sensor{self.sensor_index}_millivolts"]
            if f"sensor{self.sensor_index}_millivolts" in self.timeseries
            else pd.Series(dtype=float)
        )
        self.ppo2 = (
            (self.milivolts / self.calibration_mv * self.calibration_ppo2)
            if self.calibration_mv
            else pd.Series(dtype=float)
        )

    def predict_millivolts(self, ppo2: float) -> float | None:
        """Predict the millivolt reading for a given PO₂ based on calibration."""
        if self.calibration_ppo2 is None or self.calibration_mv is None:
            return None
        return (ppo2 / self.calibration_ppo2) * self.calibration_mv
    def predict_ppo2(self, millivolts: float) -> float | None:
        """Predict the PO₂ reading for a given millivolt based on calibration."""
        if self.calibration_ppo2 is None or self.calibration_mv is None:
            return None
        return (millivolts / self.calibration_mv) * self.calibration_ppo2
    def to_df(self, include_depth=False):  # pragma: no cover - convenience alias
        fields = [f"sensor{self.sensor_index}_millivolts"]
        if include_depth and "depth_ft" in self.timeseries:
            fields.insert(0, "depth_ft")
        return self.timeseries[fields]

    def plot(self):
        from .plotting import plot_timeseries

        return plot_timeseries(
            self.timeseries, scale_groups=[[f"sensor{self.sensor_index}_millivolts"]]
        )

    def to_process(
        self, include_depth=False, filter_low_setpoint=False
    ) -> pd.DataFrame:
        fields = [f"sensor{self.sensor_index}_millivolts"]
        df = self.timeseries.copy()
        if include_depth and "depth_ft" in df:
            fields.insert(0, "depth_ft")
            df = (
                df.where(df["depth_ft"] != np.inf)
                .where(df["depth_ft"] > 0)
                .dropna(subset=["depth_ft"])
            )
        if filter_low_setpoint:
            df = df[df[f"ppo2_setpoint"] == df[f"ppo2_setpoint"].max()]
        df_chgs = np.log(df[fields]) - np.log(df[fields].shift(1)).dropna()
        df_chgs = df_chgs.iloc[1:]
        return df_chgs

    def extract_residuals(
        self, independent_vars=["depth_ft"], filter_low_setpoint=False
    ) -> pd.DataFrame:
        import pandas as pd
        import statsmodels.api as sm

        df = self.to_process(
            include_depth=True, filter_low_setpoint=filter_low_setpoint
        )
        df = df.copy()
        df.index.name = "time"
        sensor_col = f"sensor{self.sensor_index}_millivolts"
        residuals = pd.DataFrame(index=df.index)
        X = sm.add_constant(df[independent_vars])
        y = df[sensor_col]
        model = sm.OLS(y, X).fit()
        residuals[sensor_col] = model.resid
        residuals[independent_vars] = df[independent_vars]
        return residuals


class SensorCollection(Filterable[Sensor], Sequence[Sensor]):
    """Thin wrapper that offers helpers across all sensor series."""

    def __init__(self, series: Iterable[Sensor]):
        self._series: List[Sensor] = list(series)

    def __getitem__(self, index):
        return self._series[index]

    def __len__(self) -> int:
        return len(self._series)

    def __iter__(self) -> Iterator[Sensor]:  # pragma: no cover - trivial
        return iter(self._series)

    def _from_iterable(self, items: Iterable[Sensor]) -> "SensorCollection":
        return SensorCollection(items)

    def filter(self, sensor_filter: SensorFilter | None = None) -> "SensorCollection":
        if sensor_filter is not None and not isinstance(sensor_filter, SensorFilter):
            raise TypeError("sensor_filter must be a SensorFilter or None")
        return cast(SensorCollection, super().filter(sensor_filter))

    def to_df(self):  # pragma: no cover - convenience only
        df = pd.concat(
            [
                sensor.timeseries[[f"sensor{sensor.sensor_index}_millivolts"]]
                for sensor in self._series
            ],
            axis=1,
        ).assign(depth_ft=self._series[0].timeseries["depth_ft"])
        def vote_ppo2(row):
            po2s = []
            for s in self._series:
                po2s.append(s.predict_ppo2(row[f"sensor{s.sensor_index}_millivolts"]))
            #remove val that is furthest appart
            po2s.sort()
            if po2s[1]-po2s[0]>po2s[2]-po2s[1]:
                po2s=po2s[1:]
            else:
                po2s=po2s[:1]
            return sum(po2s)/len(po2s)
        def average_ppo2(row):
            po2s = []
            for s in self._series:
                po2s.append(s.predict_ppo2(row[f"sensor{s.sensor_index}_millivolts"]))
            return sum(po2s)/len(po2s)
        df["voted_ppo2"] = df.apply(vote_ppo2, axis=1)
        df["average_ppo2"] = df.apply(average_ppo2, axis=1)
        return df
        

    def plot(self):
        from .plotting import plot_timeseries

        return plot_timeseries(
            self.to_df(),
            scale_groups=[
                [
                    f"sensor{sensor_index}_millivolts"
                    for sensor_index in range(1, len(self) + 1)
                ]
            ],
        )

    def plot_po2_millivolts_scatter(self,average_field='average_ppo2'):
        from .plotting import plot_po2_millivolts_scatter

        # return plot_po2_millivolts_scatter(self.to_df().assign(average_ppo2=self._series[0].timeseries['average_ppo2'] if 'average_ppo2' in self._series[0].timeseries else np.nan))
        return plot_po2_millivolts_scatter(
            self.to_df(),average_field=average_field)

    def to_process(
        self, include_depth=False, filter_low_setpoint=False
    ) -> pd.DataFrame:
        df = pd.concat(
            [
                sensor.to_process(
                    include_depth=include_depth, filter_low_setpoint=filter_low_setpoint
                )
                for sensor in self._series
            ],
            axis=1,
        )
        if include_depth:
            df = df.loc[:, ~df.columns.duplicated()]
        return df

    def extract_residuals(
        self, independent_vars=["depth_ft"], filter_low_setpoint=False
    ) -> pd.DataFrame:
        import pandas as pd
        import statsmodels.api as sm

        df = self.to_process(
            include_depth=True, filter_low_setpoint=filter_low_setpoint
        )
        df = df.copy()
        if "depth_ft" in df.columns:
            if df.at[df.index[0], "depth_ft"] == np.inf:
                df = df.iloc[1:]
        df.index.name = "time_seconds"
        sensor_cols = [
            f"sensor{sensor.sensor_index}_millivolts" for sensor in self._series
        ]
        residuals = pd.DataFrame(index=df.index)
        X = sm.add_constant(df[independent_vars])
        for s in sensor_cols:
            y = df[s]
            model = sm.OLS(y, X).fit()
            residuals[s] = model.resid
        residuals[independent_vars] = df[independent_vars]
        return residuals

    def remove_first_principal_component(
        self,
        use_depth_residuals=True,
        remove_autocorrelations=True,
        filter_low_setpoint=False,
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """ """
        import numpy as np
        import pandas as pd
        from sklearn.decomposition import PCA

        df: pd.DataFrame = pd.DataFrame()
        if use_depth_residuals:
            df = self.extract_residuals(
                independent_vars=["depth_ft"], filter_low_setpoint=filter_low_setpoint
            )
        else:
            df = self.to_process()
        df = df.copy()
        cols = df.columns
        X = df[cols].astype(float).dropna()
        X_std = (X - X.mean()) / X.std(ddof=1)
        pca = PCA()
        Z = pca.fit_transform(X_std)

        pc1 = Z[:, 0]

        # 2) Per-sensor regression on pc1 -> fitted shared + residual (sensor units)
        A = np.c_[np.ones(len(X)), pc1]
        F = pd.DataFrame(index=X.index, columns=cols, dtype=float)  # fitted (shared)
        R = pd.DataFrame(
            index=X.index, columns=cols, dtype=float
        )  # residuals (sensor noise, in original units)

        noise_var = {}
        total_var = {}
        noise_fraction = {}
        r2 = {}

        for c in [cx for cx in cols if cx not in ["depth_ft"]]:
            y = X[c].values
            beta, *_ = np.linalg.lstsq(A, y, rcond=None)
            yhat = A @ beta
            resid = y - yhat

            F[c] = yhat
            R[c] = resid

            # TSS/RSS using unbiased variances (ddof=1); factors cancel in the ratio
            v_total = np.var(y, ddof=1)
            v_noise = np.var(resid, ddof=1)

            total_var[c] = v_total
            noise_var[c] = v_noise
            noise_fraction[c] = v_noise / v_total  # == 1 - R^2
            r2[c] = 1.0 - noise_fraction[c]

        summary = pd.DataFrame(
            {
                "total_var": pd.Series(total_var),
                "noise_var": pd.Series(noise_var),
                "noise_fraction": pd.Series(noise_fraction),
                "R2_vs_PC1": pd.Series(r2),
            }
        )
        R = R.drop(columns=["depth_ft"], errors="ignore")
        if remove_autocorrelations:

            def ar1_innovations(s: pd.Series) -> pd.Series:
                y = s.dropna().astype(float)
                if len(y) < 5:
                    return y * np.nan  # not enough data
                y0, y1 = y.shift(1).dropna().align(y.dropna(), join="inner")
                # OLS phi1 = cov/var = corr * (std_y/std_y) -> here simpler as:
                phi1 = np.cov(y1, y0, bias=False)[0, 1] / np.var(y0, ddof=1)
                e = y - phi1 * y.shift(1)
                return e.dropna().rename(f"{s.name}")

            innov_df = pd.concat([ar1_innovations(R[c]) for c in R.columns], axis=1)
            return innov_df, summary

        return R, summary

    def plot_sensor_noise(self, filter_low_setpoint=False):
        from .plotting import plot_sensor_strip

        return plot_sensor_strip(
            df=self.remove_first_principal_component(
                use_depth_residuals=True,
                remove_autocorrelations=True,
                filter_low_setpoint=filter_low_setpoint,
            )[0]
        )

    def plot_noise_share(self, filter_low_setpoint=False):
        from .plotting import plot_noise_share

        return plot_noise_share(
            self.remove_first_principal_component(
                use_depth_residuals=True,
                remove_autocorrelations=True,
                filter_low_setpoint=filter_low_setpoint,
            )[1]
        )


class PressureUnit:
    PSI = "PSI"
    BAR = "BAR"


class VolumeUnit:
    CUFT = "CUFT"
    LITER = "LITER"


class PressureReading:
    """A single pressure sample from a wireless transmitter."""

    value: float
    unit: PressureUnit

    def __init__(self, value: float, unit: PressureUnit = PressureUnit.PSI):
        self.value = value
        self.unit = unit

    @property
    def psi(self) -> float:
        if self.unit == PressureUnit.PSI:
            return self.value
        if self.unit == PressureUnit.BAR:
            return self.value * PSI_PER_BAR
        raise ValueError(f"Unsupported pressure unit: {self.unit}")

    @property
    def bar(self) -> float:
        if self.unit == PressureUnit.BAR:
            return self.value
        if self.unit == PressureUnit.PSI:
            return self.value / PSI_PER_BAR
        raise ValueError(f"Unsupported pressure unit: {self.unit}")

    def __repr__(self) -> str:  # pragma: no cover
        return f"PressureReading(value={self.value!r}, unit='{self.unit}')"

    def __sub__(self, other: "PressureReading") -> "PressureReading":
        if not isinstance(other, PressureReading):
            return NotImplemented
        return PressureReading(self.psi - other.psi, PressureUnit.PSI)


class Volume:
    value: float
    unit: VolumeUnit

    def __init__(self, value: float, unit: VolumeUnit = VolumeUnit.CUFT):
        self.value = float(value)
        self.unit = unit

    @property
    def cuft(self) -> float:
        if self.unit == VolumeUnit.CUFT:
            return self.value
        if self.unit == VolumeUnit.LITER:
            return self.value / L_PER_CUFT
        raise ValueError(f"Unsupported volume unit: {self.unit}")

    @property
    def liter(self) -> float:
        if self.unit == VolumeUnit.LITER:
            return self.value
        if self.unit == VolumeUnit.CUFT:
            return self.value * L_PER_CUFT
        raise ValueError(f"Unsupported volume unit: {self.unit}")

    def __repr__(self):
        return f"Volume (CUFT={self.cuft!r}, LITER={self.liter!r})"


@dataclass(frozen=True)
class TankSize:
    """
    Two conventions:
      • Physical:   3 L @ 1 bar  -> liters_per_bar = 3
      • Marketing:  80 cuft @ 3000 psi -> cuft_per_psi = 80/3000
    """

    volume: Volume
    rated_pressure: Optional[PressureReading] = None

    # Liters per bar (physical spec). If rated BAR is 1, it's exactly `volume.liter`.
    def liters_per_bar(self) -> Optional[float]:
        return self.volume.liter / self.rated_pressure.bar

    def cuft_per_psi(self) -> Optional[float]:
        return self.volume.cuft / self.rated_pressure.psi

    def cuft_per_bar(self) -> Optional[float]:
        return self.volume.cuft / self.rated_pressure.bar

    def liters_per_psi(self) -> Optional[float]:
        return self.volume.liter / self.rated_pressure.psi
    
    def __div__(self,other):
        if isinstance(other,PressureReading):
            if other.unit==PressureUnit.BAR:
                return Volume(value=self.liters_per_bar()*other.value,unit=VolumeUnit.LITER)
            else:
                return Volume(value=self.liters_per_psi()*other.value,unit=VolumeUnit.LITER)
        return NotImplemented
    def __truediv__(self,other):
        return self.__div__(other)

@dataclass(frozen=True)
class ChemicalElement:
    name: str
    symbol: str
    atomic_number: int
    atomic_weight: float
    density_g_per_l: float
    melting_point_c: float
    boiling_point_c: float
    electronegativity: float
    is_narcotic: bool
class PureGas:
    OXYGEN = ChemicalElement(name='oxygen',
                        symbol='O2',
                        atomic_number=8,
                        atomic_weight=15.999,
                        density_g_per_l=1.429,
                        melting_point_c=-218.79,
                        boiling_point_c=-182.962,
                        electronegativity=3.44,
                        is_narcotic=True
                     )
    NITROGEN = ChemicalElement(name='nitrogen',
                        symbol='N2',
                        atomic_number=7,
                        atomic_weight=14.007,
                        density_g_per_l=1.251,
                        melting_point_c=-210.00,
                        boiling_point_c=-195.79,
                        electronegativity=3.04,
                        is_narcotic=True
                     )
    HELIUM = ChemicalElement(name='helium',
                        symbol='He',
                        atomic_number=2,
                        atomic_weight=4.002602,
                        density_g_per_l=0.1786,
                        melting_point_c=-272.20,
                        boiling_point_c=-268.928,
                        electronegativity=0.0,
                        is_narcotic=False
                        )
    
class GasMixture:
    """A breathing gas mixture defined by its fractional components."""
    fractions: Dict[Element, float]  # fraction by component (0.0 - 1.0)
    def __init__(self, fractions: Dict[Element, float]):
        total_fraction = sum(fractions.values())
        if not np.isclose(total_fraction, 1.0):
            raise ValueError(f"Gas fractions must sum to 1.0 (got {total_fraction})")
        self.fractions = fractions
    def fraction_of(self, element: Element) -> float:
        return self.fractions.get(element, 0.0)
    def fraction_narcotic(self) -> float:
        return sum(f for e, f in self.fractions.items() if e.is_narcotic)
    def fraction_non_narcotic(self) -> float:
        return sum(f for e, f in self.fractions.items() if not e.is_narcotic)

class GasBlends:
    AIR = GasMixture({
        PureGas.OXYGEN: 0.21,
        PureGas.NITROGEN: 0.79
    })
    EAN32 = GasMixture({
        PureGas.OXYGEN: 0.32,
        PureGas.NITROGEN: 0.68
    })
    EAN36 = GasMixture({
        PureGas.OXYGEN: 0.36,
        PureGas.NITROGEN: 0.64
    })

class Tank:
    fill_pressure: PressureReading
    gas_mixture: GasMixture
    tank_size: TankSize
    def __init__(self, fill_pressure: PressureReading, gas_mixture: GasMixture, tank_size: TankSize):
        self.fill_pressure = fill_pressure if isinstance(fill_pressure, PressureReading) else None
        self.gas_mixture = gas_mixture if isinstance(gas_mixture, GasMixture) else None
        self.tank_size = tank_size if isinstance(tank_size, TankSize) else None
        if not self.fill_pressure:
            raise ValueError("fill_pressure is required to be of type PressureReading")
        if not self.gas_mixture:
            raise ValueError("gas_mixture is required to be of type GasMixture")
        if not self.tank_size:
            raise ValueError("tank_size is required to be of type TankSize")
    @property
    def surface_gas_volume(self) -> Volume:
        return Volume(self.fill_pressure.bar*self.tank_size.liters_per_bar(), VolumeUnit.LITER)



class TankStyle:
    # AL80: 80 cuft at 3000 psi
    AL80 = TankSize(
        volume=Volume(80, VolumeUnit.CUFT),
        rated_pressure=PressureReading(3000, PressureUnit.PSI),
    )
    # HP100: 100 cuft at 3442 psi
    STEEL100 = TankSize(
        volume=Volume(100, VolumeUnit.CUFT),
        rated_pressure=PressureReading(3442, PressureUnit.PSI),
    )
    # CCR 3L: define as 3 L PER BAR (rated = 1 bar)
    CCR3L = TankSize(
        volume=Volume(3, VolumeUnit.LITER),
        rated_pressure=PressureReading(1, PressureUnit.BAR),
    )
    Double100s = TankSize(
        volume=Volume(200, VolumeUnit.CUFT),
        rated_pressure=PressureReading(3442, PressureUnit.PSI),
    )



@dataclass()
class AirIntegrationSeries:
    """Metadata and samples for a wireless air-integration transmitter."""

    name: str
    tank_index: int | None
    start_pressure: PressureReading | None
    end_pressure: PressureReading | None
    tank_size: Volume | None = None  # legacy (keep to avoid breaking callers)
    samples: Tuple[Tuple[float, float], ...] = field(
        default_factory=tuple
    )  # (time_s, pressure_psi)
    default_script_term: str | None = None
    transmitter_serial: str | None = None
    is_enabled: bool | None = None
    gas_profile: Mapping[str, Any] | None = None
    depth_ft: Optional[pd.Series] = None
    time: Optional[pd.Series] = None
    sensor_field: str | None = None
    dive_start: datetime | None = None

    # New: optional full tank definition
    tank: Optional[TankSize] = None

    def _time_index_from_seconds(self, time_seconds: pd.Series) -> pd.DatetimeIndex:
        numeric_seconds = pd.to_numeric(time_seconds, errors="coerce")
        deltas = pd.to_timedelta(numeric_seconds, unit="s")
        if self.dive_start is not None:
            base = pd.Timestamp(self.dive_start)
            values = base + deltas
        else:
            base = pd.Timestamp(0, unit="s")
            values = base + deltas
        return pd.DatetimeIndex(values, name="time")

    @property
    def pressure_drop(self) -> PressureReading | None:
        if self.start_pressure is None or self.end_pressure is None:
            return None
        return self.start_pressure - self.end_pressure

    @property
    def sample_count(self) -> int:
        return len(self.samples)

    @property
    def start_time_seconds(self) -> float | None:
        return self.samples[0][0] if self.samples else None

    @property
    def end_time_seconds(self) -> float | None:
        return self.samples[-1][0] if self.samples else None

    def to_dataframe(self) -> pd.DataFrame:  # pragma: no cover
        df = pd.DataFrame(self.samples, columns=["time_seconds", "pressure_psi"])
        if df.empty:
            df["pressure_bar"] = pd.Series(dtype=float)
        else:
            df["pressure_bar"] = df["pressure_psi"] / PSI_PER_BAR

        time_index = self._time_index_from_seconds(
            df["time_seconds"] if "time_seconds" in df else pd.Series(dtype=float)
        )
        # df.insert(1, "time", pd.Series(time_index, index=df.index))
        df.index = time_index
        df.index.name = "time"

        if self.depth_ft is not None and isinstance(self.depth_ft, pd.Series):
            df["depth_ft"] = self.depth_ft.reindex(time_index).to_numpy()
        else:
            df["depth_ft"] = np.nan

        # if self.time is not None and isinstance(self.time, pd.Series):
        # Preserve any precomputed time series if provided.
        # df["time"] = pd.Series(self.time.reindex(time_index), index=df.index).fillna(df["time"])

        return df

    def to_df(self) -> pd.DataFrame:  # pragma: no cover
        return self.to_dataframe()

    # --- Stats property (builds SACStats bound to this AI) ---
    @property
    def sac(self) -> "SACStats":
        return self.get_sac(self.tank)

    def get_sac(self, tank: Optional[TankSize]) -> "SACStats":
        if not tank:
            tank = self.tank
        return SACStats(_ai=self, tank=tank)


class AICollection(Filterable[AirIntegrationSeries], Sequence[AirIntegrationSeries]):
    """Collection wrapper offering convenience helpers for air integration data."""

    def __init__(self, series: Iterable[AirIntegrationSeries]):
        self._series: Tuple[AirIntegrationSeries, ...] = tuple(series)

    def __getitem__(self, index):
        return self._series[index]

    def __len__(self) -> int:
        return len(self._series)

    def __iter__(self):
        return iter(self._series)

    def _from_iterable(self, items: Iterable[AirIntegrationSeries]) -> "AICollection":
        return AICollection(items)

    def filter(self, ai_filter: AIFilter | None = None) -> "AICollection":
        if ai_filter is not None and not isinstance(ai_filter, AIFilter):
            raise TypeError("ai_filter must be an AIFilter or None")
        return cast(AICollection, super().filter(ai_filter))

    def to_tuple(self) -> Tuple[AirIntegrationSeries, ...]:
        return self._series


@dataclass
class SACStats:
    """
    Bound to a single AirIntegrationSeries via AI.sac property.
    Produces a DataFrame with datetime index ('time'), 'ata', 'depth_ft',
    and SAC columns in psi/bar/cuft/liter per minute (and rolling).
    """

    _ai: AirIntegrationSeries
    tank: TankSize | None = None
    win_sec: int = 60
    shallow_ft: Optional[float] = 3.0  # None disables shallow filtering

    _df: pd.DataFrame = field(init=False, repr=False)

    def plot(self,scale_groups=None,unit:Optional[Union[VolumeUnit, PressureUnit]]=None):  # pragma: no cover - convenience only
        from .plotting import plot_timeseries

        if scale_groups is None:
            if str(unit) in (PressureUnit.PSI,):
                scale_groups = [[ "sac_psi_per_min"]]
            elif str(unit) in (PressureUnit.BAR,):
                scale_groups = [[ "sac_bar_per_min"]]
            elif str(unit) in (VolumeUnit.CUFT,):
                scale_groups = [[ "sac_cuft_per_min"]]
            elif str(unit) in (VolumeUnit.LITER,):
                scale_groups = [[ "sac_liter_per_min"]]
            else:
                scale_groups = [
                    ['sac_liter_per_min']
                ]
            
        return plot_timeseries(self._df, scale_groups=scale_groups)
    @classmethod
    def extract_sac_stats(
        cls,
        dives: DiveCollection,
        *,
        tank_size: Optional[TankSize] = None,
        dive_id_to_tank_map: Optional[Dict[str, TankSize]] = None,
        cut_off_depth_threshold: float = 0.0,
        start_from: Optional[pd.Timedelta] = pd.Timedelta("0min"),
        report_relative: bool = False,
        unit: Optional[Union[VolumeUnit, PressureUnit]] = None,
    ) -> pd.DataFrame:
        dives = dives.filter(
            DiveFilter(is_air_integrated=fo.is_true(), mode=fo.ne("ccr"))
        )
        if tank_size:
            sacs = [dive.air_integration[0].get_sac(tank_size) for dive in dives]
        elif dive_id_to_tank_map:
            sacs = [
                dive.air_integration[0].get_sac(dive_id_to_tank_map.get(dive.dive_id))
                for dive in dives
            ]
        else:
            raise ValueError("Either tank_size or dive_id_to_tank_map must be provided")
        if report_relative:
            if unit not in (PressureUnit.PSI, PressureUnit.BAR):
                unit = PressureUnit.PSI
        else:
            if unit not in (VolumeUnit.CUFT, VolumeUnit.LITER):
                unit = VolumeUnit.CUFT
        res = []
        for sac in sacs:
            df = sac.to_df()
            if df.empty or f"sac_{unit.lower()}_per_min" not in df.columns:
                continue
            df = df[
                (df["depth_ft"] > cut_off_depth_threshold * df["depth_ft"].mean())
                | (df["depth_ft"] < cut_off_depth_threshold * df["depth_ft"].mean())
            ].loc[df.index[0] + start_from :]
            normal_rate = df[f"sac_{unit.lower()}_per_min"].quantile(0.5)
            excerted_rate = df[f"sac_{unit.lower()}_per_min"].quantile(0.95)
            res.append((normal_rate, excerted_rate))
        dfres = pd.DataFrame(res, columns=[f"{unit.lower()}_per_min_normal_rate", f"{unit.lower()}_per_min_excerted_rate"])
        return dfres.describe()

    def __post_init__(self):
        df = self._ai.to_df().copy()
        if df.empty:
            df.index.name = "time"
            self._df = df
            return

        # Ambient ATA
        if "depth_ft" not in df.columns:
            df["depth_ft"] = np.nan
        df["ata"] = (df["depth_ft"].fillna(0) / 33.0) + 1.0

        # Sampling interval
        df = df.resample("1min").mean().interpolate()  # interpolate missing

        # psi/min over window (positive consumption)
        delta_psi = -(df["pressure_psi"].diff())
        psi_per_min = delta_psi

        # Surface-normalized
        ata_mean = df["ata"].rolling(1, min_periods=1).mean()
        sac_psi = psi_per_min / ata_mean  # .clip(lower=0)
        sac_bar = sac_psi / PSI_PER_BAR

        # Tank conversions
        tank = self.tank if self.tank else self._ai.tank
        cuft_per_psi = tank.cuft_per_psi() if tank else None
        liters_per_bar = tank.liters_per_bar() if tank else None

        # Fallbacks if no TankSize given but legacy tank_size Volume is present
        if tank is None and self._ai.tank_size is not None:
            if self._ai.tank_size.unit == VolumeUnit.LITER:
                liters_per_bar = self._ai.tank_size.liter  # 3 L per bar style
            # If CUFT only and no rated PSI, can’t resolve cuft/min — leave NaN

        # Volume SACs
        sac_cuft = (
            sac_psi * cuft_per_psi
            if cuft_per_psi is not None
            else (
                sac_bar * (liters_per_bar / L_PER_CUFT)
                if liters_per_bar is not None
                else pd.Series(np.nan, index=df.index)
            )
        )
        sac_liter = (
            sac_bar * liters_per_bar
            if liters_per_bar is not None
            else (
                sac_psi * cuft_per_psi * L_PER_CUFT
                if cuft_per_psi is not None
                else pd.Series(np.nan, index=df.index)
            )
        )

        # Store raw + rolling
        df["sac_psi_per_min"] = sac_psi
        df["sac_bar_per_min"] = sac_bar
        df["sac_cuft_per_min"] = sac_cuft
        df["sac_liter_per_min"] = sac_liter

        self._df = df

    # --- Public API ---
    def to_df(self) -> pd.DataFrame:
        cols = [
            "pressure_psi",
            "pressure_bar",
            "depth_ft",
            "ata",
            "sac_psi_per_min",
            "sac_bar_per_min",
            "sac_cuft_per_min",
            "sac_liter_per_min",
        ]
        return self._df[[c for c in cols if c in self._df.columns]].copy()

    # Means (rolling, valid samples)
    @property
    def mean_sac_psi_per_min(self) -> float:
        s = self._df.loc[self._df["_valid_mask"], "sac_psi_per_min_roll"]
        return float(s.mean()) if len(s) else float("nan")

    @property
    def mean_sac_bar_per_min(self) -> float:
        s = self._df.loc[self._df["_valid_mask"], "sac_bar_per_min_roll"]
        return float(s.mean()) if len(s) else float("nan")

    @property
    def mean_sac_cuft_per_min(self) -> float:
        s = self._df.loc[self._df["_valid_mask"], "sac_cuft_per_min_roll"]
        return float(s.mean()) if len(s) else float("nan")

    @property
    def mean_sac_liter_per_min(self) -> float:
        s = self._df.loc[self._df["_valid_mask"], "sac_liter_per_min_roll"]
        return float(s.mean()) if len(s) else float("nan")

    def get_percentile_sac(
        self, p: float, unit: str = "cuft_per_min", use_rolling: bool = True
    ) -> float:
        """
        p: percentile (e.g., 95)
        unit: {'psi_per_min','bar_per_min','cuft_per_min','liter_per_min'}
        """
        base = f"sac_{unit}"
        col = base
        if col not in self._df.columns:
            raise ValueError(f"Unsupported unit '{unit}'")

        # Valid mask
        if self.shallow_ft is not None:
            mask = (self._df["depth_ft"] >= self.shallow_ft) & np.isfinite(
                self._df["sac_cuft_per_min"]
            )
        else:
            mask = np.isfinite(self._df["sac_cuft_per_min"])
        self._df["_valid_mask"] = mask
        s = self._df.loc[self._df["_valid_mask"], col].dropna()
        return s.quantile(p) if len(s) else float("nan")


@dataclass(frozen=True)
class DivePayload:
    """Container for raw computer payloads and decoded helpers."""

    data_bytes_1: bytes | None = None
    decompressed_bytes_1: bytes | None = None
    floats_1: Sequence[float] = field(default_factory=tuple)
    frames_1: Sequence[Tuple[float, ...]] = field(default_factory=tuple)
    samples: Sequence[Dict[str, Any]] = field(default_factory=tuple)
    sample_records_raw: Sequence[bytes] = field(default_factory=tuple)
    data_bytes_2: Dict[str, Any] = field(default_factory=dict)
    data_bytes_3: Dict[str, Any] = field(default_factory=dict)
    calibration: Dict[str, Any] | None = None
    calibration_raw: Dict[str, Any] | None = None
    timeseries: "DiveTimeSeries" | None = None


@dataclass(frozen=True)
class Dive:
    """A dive event aggregated across matching computers."""

    dive_id: str
    computer_name: str
    start: datetime | None
    end: datetime | None
    duration_seconds: float | None
    mode: str
    temp: UnitMeasure
    max_depth: float | None
    computer_names: Sequence[str]
    payload: DivePayload | None = None
    primary_computer: "Dive" | None = None
    controller: "Dive" | None = None
    monitor: "Dive" | None = None
    secondary_computer: "Dive" | None = None
    gas_profiles: Sequence[Dict[str, Any]] = field(default_factory=tuple)
    tank_data: Sequence[Dict[str, Any]] = field(default_factory=tuple)
    linked_dives: Tuple["Dive", ...] = field(default_factory=tuple)

    def __repr__(self) -> str:  # pragma: no cover - convenience only
        primary = self._link_label(self.primary_computer)
        return (
            "Dive("
            f"id={self.dive_id!r}, mode={self.mode!r}, start={self.start}, duration_seconds={self.duration_seconds}, "
            f"primary={primary!r}, computers={list(self.computer_names)}"
            ")"
        )

    def display_name(self) -> str:
        """Return a friendly label for the dive's computer."""

        return self.computer_name

    @property
    def timeseries(self) -> "DiveTimeSeries | None":
        if self.payload:
            return self.payload.timeseries
        return None

    @property
    def sensors(self) -> SensorCollection:
        sensors = []
        if self.timeseries:
            for sensor_index in range(1, 4):
                series = self.timeseries.to_df()
                sensors.append(Sensor(sensor_index=sensor_index, 
                                      timeseries=series, 
                                      calibration_ppo2=self.payload.calibration.get('calibration_ppo2',None) if self.payload and self.payload.calibration else None,
                                      calibration_mv=self.payload.calibration.get('calibration_mv').get(f'sensor{sensor_index}',None) if self.payload and self.payload.calibration else None))
            return SensorCollection(sensors)
        return SensorCollection([])

    def plot(self, **kwargs):
        """Convenience helper that proxies to :func:`plot_timeseries`."""
        if self.timeseries is None:
            raise ValueError("This dive does not include timeseries data.")
        from .plotting import plot_timeseries

        return plot_timeseries(self.timeseries, **kwargs)

    def get_sensors(
        self, sensor_filter: SensorFilter | None = None
    ) -> SensorCollection:
        collection = self.sensors
        if sensor_filter is None:
            return collection
        if not isinstance(sensor_filter, SensorFilter):
            raise TypeError("sensor_filter must be a SensorFilter or None")
        if sensor_filter.is_empty():
            return collection
        return collection.filter(sensor_filter)

    @property
    def is_air_integrated(self) -> bool:
        return _select_tank_entries(self.tank_data) != []

    @property
    def air_integration(self) -> Tuple[AirIntegrationSeries, ...]:
        if not self.tank_data:
            return ()
        samples = (
            self.payload.samples if (self.payload and self.payload.samples) else ()
        )
        depth_df: pd.DataFrame | None = None
        if self.timeseries:
            depth_df = self.timeseries.to_df(
                ["depth_ft"],
            )[["depth_ft", "time_seconds"]]
        ai = _build_air_integration_entries(
            self.tank_data,
            samples,
            depth_ft=depth_df,
            dive_start=self.start,
        )
        return ai

    def get_air_integration(self, ai_filter: AIFilter | None = None) -> AICollection:
        collection = AICollection(self.air_integration)
        if ai_filter is None:
            return collection
        if not isinstance(ai_filter, AIFilter):
            raise TypeError("ai_filter must be an AIFilter or None")
        if ai_filter.is_empty():
            return collection
        return collection.filter(ai_filter)

    @staticmethod
    def _link_label(link: "Dive" | None) -> str | None:
        if isinstance(link, Dive):
            return link.display_name()
        if isinstance(link, str):  # backwards compatibility
            return link
        return None

    @property
    def primary_label(self) -> str | None:
        return self._link_label(self.primary_computer)

    @property
    def primary_computer_name(self) -> str | None:
        return self.primary_label

    @property
    def controller_label(self) -> str | None:
        return self._link_label(self.controller)

    @property
    def controller_name(self) -> str | None:
        return self.controller_label

    @property
    def monitor_label(self) -> str | None:
        return self._link_label(self.monitor)

    @property
    def monitor_name(self) -> str | None:
        return self.monitor_label

    @property
    def secondary_label(self) -> str | None:
        return self._link_label(self.secondary_computer)

    @property
    def secondary_computer_name(self) -> str | None:
        return self.secondary_label


class DiveCollection(Filterable["Dive"], Sequence["Dive"]):
    """Sequence wrapper that exposes filtering helpers for Dive records."""

    def __init__(self, dives: Iterable["Dive"]):
        self._dives: Tuple["Dive", ...] = tuple(dives)

    def __getitem__(self, index):
        return self._dives[index]

    def __len__(self) -> int:
        return len(self._dives)

    def __iter__(self):
        return iter(self._dives)

    def _from_iterable(self, items: Iterable["Dive"]) -> "DiveCollection":
        return DiveCollection(items)

    def filter(self, dive_filter: DiveFilter | None = None) -> "DiveCollection":
        if dive_filter is not None and not isinstance(dive_filter, DiveFilter):
            raise TypeError("dive_filter must be a DiveFilter or None")
        return cast(DiveCollection, super().filter(dive_filter))

    def to_list(self) -> List["Dive"]:
        return list(self._dives)


_TANK_INDEX_CANDIDATE_FIELDS: Dict[int, Tuple[str, ...]] = {
    0: ("wai_sensor0_pressure",),
    1: ("wai_sensor1_pressure",),
    2: ("wai_sensor2_pressure",),
    3: ("wai_sensor3_pressure",),
}

_SENTINEL_PRESSURES = {0, 65535, 65534}

_PRESSURE_FIELD_SCALE: Dict[str, float] = {
    "wai_sensor0_pressure": 2.0,
    "wai_sensor1_pressure": 2.0,
    "wai_sensor2_pressure": 2.0,
    "wai_sensor3_pressure": 2.0,
}


def _select_first_available_field(
    samples: Sequence[Dict[str, Any]] | None,
    candidates: Sequence[str],
) -> str | None:
    if not candidates:
        return None
    if not samples:
        return candidates[0]

    for field in candidates:
        for sample in samples:
            value = _retrieve_sample_value(sample, field)
            if value not in (None, 0, 65535, 65534):
                return field
    return candidates[0]


def _build_air_integration_entries(
    tank_entries: Sequence[Dict[str, Any]],
    samples: Sequence[Dict[str, Any]] | None,
    depth_ft: pd.DataFrame | None = None,
    *,
    dive_start: datetime | None = None,
) -> Tuple[AirIntegrationSeries, ...]:
    selected = _select_tank_entries(tank_entries)
    if not selected:
        return tuple()

    sample_series_cache: Dict[str, Tuple[Tuple[float, float], ...]] = {}
    results: List[AirIntegrationSeries] = []

    for entry in selected:
        transmitter = entry.get("DiveTransmitter") or {}
        tank_index = transmitter.get("TankIndex")
        candidates = _TANK_INDEX_CANDIDATE_FIELDS.get(tank_index, tuple())
        sensor_field = _select_first_available_field(samples, candidates)
        if sensor_field is None:
            continue
        if sensor_field not in sample_series_cache:
            sample_series_cache[sensor_field] = _extract_pressure_series(
                samples, sensor_field
            )
        series = sample_series_cache[sensor_field]

        depth_series = (
            depth_ft["depth_ft"]
            if depth_ft is not None and "depth_ft" in depth_ft
            else None
        )
        time_series = (
            depth_ft["time"] if depth_ft is not None and "time" in depth_ft else None
        )

        results.append(
            AirIntegrationSeries(
                name=_resolve_transmitter_name(transmitter, tank_index),
                tank_index=tank_index,
                start_pressure=PressureReading(
                    _coerce_pressure(entry.get("StartPressurePSI")), PressureUnit.PSI
                ),
                end_pressure=PressureReading(
                    _coerce_pressure(entry.get("EndPressurePSI")), PressureUnit.PSI
                ),
                samples=series,
                default_script_term=transmitter.get("DefaultScriptTerm"),
                transmitter_serial=transmitter.get("UnformattedSerialNumber"),
                is_enabled=transmitter.get("IsOn"),
                gas_profile=entry.get("GasProfile"),
                sensor_field=sensor_field,
                depth_ft=depth_series,
                time=time_series,
                dive_start=dive_start,
            )
        )

    results.sort(
        key=lambda item: (item.tank_index if item.tank_index is not None else 99)
    )
    return tuple(results)


def _select_tank_entries(
    tank_entries: Sequence[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    best: Dict[Any, Dict[str, Any]] = {}
    for entry in tank_entries or []:
        transmitter = entry.get("DiveTransmitter") or {}
        if not transmitter.get("IsOn"):
            continue
        key = transmitter.get("TankIndex")
        if key is None:
            script_term = transmitter.get("DefaultScriptTerm")
            if not script_term:
                continue
            key = script_term

        current = best.get(key)
        if current is None or _entry_score(entry) > _entry_score(current):
            best[key] = entry

    ordered_keys = sorted(
        best.keys(), key=lambda value: value if isinstance(value, int) else 99
    )
    return [best[key] for key in ordered_keys]


def _entry_score(entry: Dict[str, Any]) -> Tuple[int, int, int]:
    transmitter = entry.get("DiveTransmitter") or {}
    is_on = 1 if transmitter.get("IsOn") else 0
    start = 1 if _coerce_pressure(entry.get("StartPressurePSI")) is not None else 0
    end = 1 if _coerce_pressure(entry.get("EndPressurePSI")) is not None else 0
    return (is_on, start, end)


def _resolve_transmitter_name(
    transmitter: Dict[str, Any], tank_index: int | None
) -> str:
    name = transmitter.get("Name") if isinstance(transmitter, dict) else None
    if isinstance(name, str):
        cleaned = name.replace("\x00", "").strip()
        if cleaned:
            return cleaned
    if tank_index is not None:
        return f"Tank {tank_index + 1}"
    term = (
        transmitter.get("DefaultScriptTerm") if isinstance(transmitter, dict) else None
    )
    if isinstance(term, str) and term:
        return term.rsplit("/", 1)[-1]
    return "Unknown Tank"


def _coerce_pressure(value: Any) -> float | None:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        if isinstance(value, float) and math.isnan(value):
            return None
        if value in _SENTINEL_PRESSURES:
            return None
        return float(value)
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return None
        try:
            numeric = float(stripped)
        except ValueError:
            return None
        if numeric in _SENTINEL_PRESSURES:
            return None
        return numeric
    return None


def _extract_pressure_series(
    samples: Sequence[Dict[str, Any]] | None,
    field: str,
) -> Tuple[Tuple[float, float], ...]:
    if not samples:
        return tuple()

    series: List[Tuple[float, float]] = []
    for sample in samples:
        raw_value = _retrieve_sample_value(sample, field)
        pressure = _coerce_pressure(raw_value)
        if pressure is not None:
            pressure *= _PRESSURE_FIELD_SCALE.get(field, 1.0)
        if pressure is None:
            continue
        time_value = sample.get("time_seconds")
        if isinstance(time_value, (int, float)):
            series.append((float(time_value), pressure))

    return tuple(series)


def _retrieve_sample_value(sample: Dict[str, Any], field: str) -> Any:
    return sample.get(field)


def build_tank_alias_map(
    tank_entries: Sequence[Dict[str, Any]] | None,
) -> Tuple[Dict[str, Tuple[str, str]], Tuple[Tuple[str, str], ...]]:
    """Return alias lookups for active wireless transmitters."""

    alias_map: Dict[str, Tuple[str, str]] = {}
    display_order: List[Tuple[str, str]] = []
    seen_fields: set[str] = set()

    for entry in tank_entries or []:
        transmitter = entry.get("DiveTransmitter") or {}
        if not transmitter.get("IsOn"):
            continue

        index = transmitter.get("TankIndex")
        sensor_field = _select_first_available_field(
            None, _TANK_INDEX_CANDIDATE_FIELDS.get(index, tuple())
        )
        if sensor_field is None:
            continue

        display_name = _resolve_transmitter_name(transmitter, index)
        if sensor_field not in seen_fields:
            display_order.append((display_name, sensor_field))
            seen_fields.add(sensor_field)

        for alias in _iter_tank_aliases(transmitter, index, display_name):
            normalized = alias.strip().lower()
            if normalized:
                alias_map[normalized] = (sensor_field, display_name)

    return alias_map, tuple(display_order)


def _iter_tank_aliases(
    transmitter: Dict[str, Any], index: int | None, display_name: str
) -> Iterable[str]:
    aliases = set()

    if isinstance(display_name, str) and display_name:
        aliases.add(display_name)

    name = transmitter.get("Name") if isinstance(transmitter, dict) else None
    if isinstance(name, str):
        aliases.add(name.replace("\x00", ""))

    if index is not None:
        aliases.add(f"tank{index + 1}")
        aliases.add(f"tank_{index + 1}")

    script_term = transmitter.get("DefaultScriptTerm")
    if isinstance(script_term, str) and script_term:
        aliases.add(script_term)
        aliases.add(script_term.rsplit("/", 1)[-1])

    serial = transmitter.get("UnformattedSerialNumber")
    if serial is not None:
        aliases.add(str(serial))

    return aliases
