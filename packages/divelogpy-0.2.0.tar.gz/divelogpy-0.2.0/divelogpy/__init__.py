"""Convenience entry points for the dive log library."""

import os
from pathlib import Path
from .client import get_client, DiveLogClient
from .models import (
    Dive,
    DiveCollection,
    UnitMeasure,
    Sensor,
    SensorCollection,
    AICollection,
    TankStyle, Volume, VolumeUnit,
    PressureReading,
    TankSize,Tank,GasBlends,GasMixture,PureGas,ChemicalElement,PressureUnit
)
from .plotting import (
    plot_timeseries,
    plot_sensor_strip,
    plot_noise_share,
    plot_noise_share_timeseries,
    plot_noise_variance_timeseries,
)
from .calibration_importer import extract_computer_data_from_images
from .decoders import (
    decode_petrel_raw_floats,
    decode_petrel_frames,
    decompress_petrel_blob,
    decode_metadata_blob,
)
from .pnf_decoder import decode_petrel_v14
from .pnf_constants import PNF_V14_CONSTANTS
from .timeseries import DiveTimeSeries
from .filters import FilterOperators, DiveFilter, SensorFilter, AIFilter

def get_latest_db_file_from(db_location: str | Path) -> Path:
    db_files = list(Path(db_location).glob("**/*.db"))
    return max(db_files, key=os.path.getctime)

__all__ = [
    "get_client",
    "DiveLogClient",
    "TankStyle",
    "TankSize",
    "Tank",
    "Volume",
    "PressureReading",
    "PressureUnit",
    "VolumeUnit",
    "GasBlends",
    "GasMixture",
    "PureGas",
    "ChemicalElement",
    "Dive",
    "DiveCollection",
    "UnitMeasure",
    "Sensor",
    "SensorCollection",
    "AICollection",
    "FilterOperators",
    "DiveFilter",
    "SensorFilter",
    "AIFilter",
    "decode_petrel_raw_floats",
    "decode_petrel_frames",
    "decompress_petrel_blob",
    "decode_metadata_blob",
    "decode_petrel_v14",
    "PNF_V14_CONSTANTS",
    "DiveTimeSeries",
    "plot_timeseries",
    "plot_sensor_strip",
    "plot_noise_share",
    "plot_noise_share_timeseries",
    "plot_noise_variance_timeseries",
    "extract_computer_data_from_images",
]
