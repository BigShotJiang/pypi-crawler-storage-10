"""Import manual calibrations from screenshots using OpenAI."""

from __future__ import annotations

import base64
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Sequence

from .calibration_store import apply_new_entries, create_entry, parse_timestamp
from .openai_client import get_client

ImageResponder = Callable[[Path, str, str], str]

_SYSTEM_PROMPT = (
    "You are an expert dive computer assistant. "
    "Detect if the provided screenshot is a Shearwater calibration summary or detail screen. "
    "If it is not related to calibrations, respond with an empty JSON object {}. "
    "Otherwise extract every passed calibration shown. Ignore or omit any rows that indicate calibration failure (for example: a row in red font starting with 'F' (failed) rather than 'P' (passed)."
    "Always output valid JSON with this schema:\n"
    "{\n  \"screen_type\": \"summary|detail\",\n  \"calibrations\": [\n    {\n      \"serial\": string,\n      \"calibration_date\": \"YYYY-MM-DD\",\n      \"timestamp\": optional ISO 8601 string,\n      \"sensors\": [mV_sensor1, mV_sensor2, mV_sensor3],\n      \"po2\": number,\n      \"fo2\": optional number,\n      \"altitude\": optional number\n    }\n  ]\n}\n"
    "Return JSON only, with no commentary."
)

_MIME_MAP = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".heic": "image/heic",
    ".heif": "image/heif",
}


def extract_computer_data_from_images(
    image_paths: Sequence[Path | str],
    *,
    update_store: bool = False,
    model: str = "gpt-4o-mini",
    responder: ImageResponder | None = None,
    override_fields: Callable[[Dict[str, object]], Dict[str, object]] | None = None,
) -> Dict[str, List[Dict[str, object]]]:
    if not image_paths:
        raise ValueError("At least one image is required.")

    normalized_paths = [Path(path) for path in image_paths]
    for path in normalized_paths:
        if not path.exists():
            raise FileNotFoundError(f"Image not found: {path}")

    openai_client = get_client() if responder is None else None

    extracted: List[Dict[str, object]] = []
    for path in normalized_paths:
        mime = _MIME_MAP.get(path.suffix.lower(), "application/octet-stream")
        payload = _invoke_responder(path, mime, model, responder, openai_client)
        if not payload:
            continue
        data = _load_json(payload)
        calibrations = data.get("calibrations") if isinstance(data, dict) else None
        if not calibrations:
            continue
        if not isinstance(calibrations, list):
            raise ValueError("OpenAI response contained an invalid calibrations payload.")
        extracted.extend(calibrations)

    if not extracted:
        return {"calibrations": [entry.to_dict() for entry in apply_new_entries([], commit=False)]}

    entries = _build_entries(extracted, override_fields=override_fields)
    merged = apply_new_entries(entries, commit=update_store)
    return {"calibrations": [entry.to_dict() for entry in merged]}


def _invoke_responder(
    path: Path,
    mime: str,
    model: str,
    responder: ImageResponder | None,
    client,
) -> str:
    if responder is not None:
        return responder(path, mime, model)

    encoded = _encode_file(path)
    image_url = f"data:{mime};base64,{encoded}"

    response = client.responses.create(
        model=model,
        input=[
            {
                "role": "system",
                "content": [{"type": "input_text", "text": _SYSTEM_PROMPT}],
            },
            {
                "role": "user",
                "content": [
                    {
                        "type": "input_text",
                        "text": "Extract every calibration record shown in this screenshot.",
                    },
                    {
                        "type": "input_image",
                        "image_url": image_url,
                    },
                ],
            },
        ],
        temperature=0.2,
    )

    if hasattr(response, "output_text"):
        return response.output_text
    # Fallback for older client versions
    try:  # pragma: no cover - compatibility
        return response.choices[0].message.content  # type: ignore[index]
    except Exception as exc:  # pragma: no cover - defensive
        raise RuntimeError(f"Unexpected OpenAI response format: {exc}") from exc


def _encode_file(path: Path) -> str:
    data = path.read_bytes()
    return base64.b64encode(data).decode("ascii")


def _load_json(payload: str) -> Dict[str, object]:
    try:
        return json.loads(payload)
    except json.JSONDecodeError:
        start = payload.find("{")
        end = payload.rfind("}")
        if start == -1 or end == -1 or end <= start:
            raise ValueError("OpenAI response did not contain valid JSON.")
        return json.loads(payload[start : end + 1])


def _build_entries(
    items: Iterable[Dict[str, object]],
    *,
    override_fields: Callable[[Dict[str, object]], Dict[str, object]] | None = None,
) -> List:
    prepared: List = []
    for raw in items:
        if not isinstance(raw, dict):
            continue
        serial = raw.get("serial") or raw.get("device_serial")
        sensors = raw.get("sensors") or raw.get("sensor_mv")
        if not serial or sensors is None:
            continue
        sensors_list = _coerce_sensor_list(sensors)
        if not sensors_list:
            continue

        status = str(raw.get("status") or raw.get("result") or "").strip().lower()
        if status in {"f", "fail", "failed", "failure"}:
            continue
        if str(raw.get("passed") or "").lower() in {"false", "0"}:
            continue
        if bool(raw.get("failed")):
            continue

        timestamp = (
            raw.get("timestamp")
            or raw.get("calibration_timestamp")
            or raw.get("calibration_time")
            or raw.get("calibration_date")
            or raw.get("date")
        )
        po2 = _optional_float(raw.get("po2")) or _optional_float(raw.get("calibration_po2"))
        fo2 = _optional_float(raw.get("fo2")) or _optional_float(raw.get("calibration_fo2"))
        altitude = _optional_float(raw.get("altitude")) or _optional_float(raw.get("calibration_mbar"))

        entry_dict: Dict[str, object] = {
            "serial": str(serial),
            "sensors": sensors_list,
            "timestamp": timestamp,
            "po2": po2,
            "fo2": fo2,
            "altitude": altitude,
        }

        screen_type = (raw.get("screen_type") or raw.get("type") or "").lower()
        if screen_type in {"summary", "list"} and entry_dict["po2"] is None:
            entry_dict["po2"] = 1.0

        if override_fields is not None:
            entry_dict = override_fields(dict(entry_dict))

        if not entry_dict.get("serial"):
            continue

        if entry_dict.get("po2") is None:
            raise ValueError("Calibration entries must include 'po2'. Provide one via override_fields.")

        prepared.append(entry_dict)

    if not prepared:
        return []

    prepared.sort(key=lambda item: _sort_key(item["timestamp"]))
    base_time = datetime.now(tz=timezone.utc)
    entries = []
    for index, item in enumerate(prepared):
        import_timestamp = base_time + timedelta(milliseconds=index)
        entry = create_entry(
            item["serial"],
            item["sensors"],
            po2=item.get("po2"),
            fo2=item.get("fo2"),
            altitude=item.get("altitude"),
            timestamp=item.get("timestamp"),
            import_timestamp=import_timestamp,
        )
        entries.append(entry)
    return entries


def _coerce_sensor_list(value: object) -> List[float]:
    if isinstance(value, str):
        parts = [part.strip() for chunk in value.split(",") for part in chunk.split()]
    elif isinstance(value, Iterable):
        parts = list(value)  # type: ignore[arg-type]
    else:
        return []

    sensors: List[float] = []
    for part in parts:
        if part in ("", None):
            continue
        try:
            sensors.append(float(part))
        except (TypeError, ValueError):
            return []
    return sensors


def _sort_key(timestamp: object) -> datetime:
    if timestamp is None:
        return datetime.min.replace(tzinfo=timezone.utc)
    try:
        return parse_timestamp(timestamp)  # type: ignore[arg-type]
    except Exception:
        return datetime.min.replace(tzinfo=timezone.utc)


def _optional_float(value: object) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None
