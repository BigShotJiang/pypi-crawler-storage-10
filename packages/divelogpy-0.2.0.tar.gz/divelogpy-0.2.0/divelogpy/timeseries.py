"""Time series helpers for decoded dive samples."""

from __future__ import annotations

from dataclasses import dataclass
import datetime
import math
from typing import Iterable, List, Mapping, Optional, Sequence, Tuple

try:  # optional dependency
    import pandas as _pd
except ImportError:  # pragma: no cover - handled dynamically
    _pd = None


_SENTINEL_PRESSURES = {0, 65535, 65534}


def _normalize_pressure(value) -> float | None:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        if isinstance(value, float) and math.isnan(value):
            return None
        if value in _SENTINEL_PRESSURES:
            return None
        return float(value) * 2.0
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return None
        try:
            numeric = float(stripped)
        except ValueError:
            return None
        if numeric in _SENTINEL_PRESSURES:
            return None
        return numeric * 2.0
    return None


@dataclass
class DiveTimeSeries:
    """Expose decoded sample metrics with DataFrame helpers."""

    samples: Sequence[dict]
    raw_records: Sequence[bytes]
    tank_alias_map: Mapping[str, Tuple[str, str]] | None = None
    tank_display_order: Tuple[Tuple[str, str], ...] = tuple()
    dive_start: Optional[datetime.datetime] = None

    @property
    def available_fields(self) -> Sequence[str]:
        if not self.samples:
            return []
        keys = set()
        for sample in self.samples:
            keys.update(sample.keys())
            extension = sample.get("extension")
            if isinstance(extension, dict):
                keys.update(f"extension.{name}" for name in extension.keys())
        return sorted(keys)

    def _time_index_from_seconds(self, time_seconds: "_pd.Series") -> "_pd.DatetimeIndex":
        numeric_seconds = _pd.to_numeric(time_seconds, errors="coerce")
        deltas = _pd.to_timedelta(numeric_seconds, unit="s")
        if self.dive_start is not None:
            base = _pd.Timestamp(self.dive_start)
            values = base + deltas
        else:
            base = _pd.Timestamp(0, unit="s")
            values = base + deltas
        return _pd.DatetimeIndex(values, name="time")

    def to_df(self, fields: Iterable[str] | None = None, *, include_time: bool = True):
        """Return a DataFrame with the requested metric fields.

        Parameters
        ----------
        fields:
            Iterable of metric names. Supports dot-notation for extension values,
            e.g. ``extension.hp_o2_pressure``. When omitted, all available fields
            are included.
        include_time:
            Whether to include the ``time_seconds`` column (if present) as the
            first column.
        """

        if _pd is None:  # pragma: no cover - environment dependent
            raise RuntimeError("pandas is required for timeseries operations")

        if not self.samples:
            return _pd.DataFrame()

        all_fields = self.available_fields
        if fields is None:
            selected = [name for name in all_fields if name != "extension" and not name.startswith("extension.")]
            extension_fields = [name for name in all_fields if name.startswith("extension.")]
            selected.extend(extension_fields)
        else:
            selected = list(fields)

        rows: List[dict] = []
        time_values: List[float | int | None] = []
        for sample in self.samples:
            row: dict = {}
            time_value = sample.get("time_seconds")
            if isinstance(time_value, (int, float)):
                time_values.append(float(time_value))
            else:
                time_values.append(None)
            if include_time and "time_seconds" in sample:
                row["time_seconds"] = sample["time_seconds"]
            for field in selected:
                if field.startswith("extension."):
                    _, key = field.split(".", 1)
                    ext = sample.get("extension") or {}
                    row[field] = ext.get(key)
                else:
                    row[field] = sample.get(field)
            rows.append(row)

        df = _pd.DataFrame(rows)
        if df.empty:
            # if include_time:
            #     df.index = _pd.DatetimeIndex([], name="time")
            #     df["time_seconds"] = _pd.Series(dtype=float)
            #     # df["time"] = _pd.Series(dtype="datetime64[ns]")
            #     # df = df[["time_seconds", "time", *[col for col in df.columns if col not in {"time_seconds", "time"}]]]
            # else:
            #     df.index = _pd.DatetimeIndex([], name="time")
            return df

        time_series = _pd.Series(time_values, dtype=float)
        if time_series.notna().any():
            time_index = self._time_index_from_seconds(time_series)
            df.index = time_index
            df.index.name = "time"
            # if include_time:
            #     df["time_seconds"] = time_series.to_numpy()
            #     # df["time"] = _pd.Series(time_index, index=df.index)
            #     # ordered_columns = ["time_seconds", "time", *[col for col in df.columns if col not in {"time_seconds", "time"}]]
            #     # df = df[ordered_columns]
            # else:
            #     df = df.drop(columns=["time_seconds"], errors="ignore")
        else:
            df.index = _pd.DatetimeIndex([_pd.NaT] * len(df), name="time")
            # if include_time:
            #     df["time_seconds"] = time_series.to_numpy()
            #     # df["time"] = _pd.Series(df.index, index=df.index)
            #     # ordered_columns = ["time_seconds", "time", *[col for col in df.columns if col not in {"time_seconds", "time"}]]
            #     # df = df[ordered_columns]
        return df

    def __getattr__(self, name: str):
        if name in {"samples", "raw_records"}:
            return super().__getattribute__(name)
        if name not in self.available_fields:
            raise AttributeError(name)
        return self.to_df([name])

    @property
    def available_tanks(self) -> Sequence[str]:
        """Return human-friendly tank names discovered in the samples."""

        return [name for name, _ in self.tank_display_order]

    def get_tank_data(self, tank_name: str):
        """Return a DataFrame of pressure samples for *tank_name*.

        The lookup accepts the user-visible transmitter name (e.g. ``"O2"``)
        or canonical labels like ``"tank1"``/``"tank_1"``.
        """

        if _pd is None:  # pragma: no cover - environment dependent
            raise RuntimeError("pandas is required for timeseries operations")

        if not self.tank_alias_map:
            raise KeyError("No wireless air-integration tanks are available for this dive")

        key = (tank_name or "").strip().lower()
        sensor_info = self.tank_alias_map.get(key)
        if sensor_info is None:
            available = ", ".join(self.available_tanks) or "none"
            raise KeyError(f"Unknown tank '{tank_name}'. Available: {available}")

        sensor_field, display_name = sensor_info
        label = display_name or sensor_field

        rows: List[Tuple[float, float]] = []
        for sample in self.samples:
            time_value = sample.get("time_seconds")
            if not isinstance(time_value, (int, float)):
                continue

            raw_value = sample.get(sensor_field)

            pressure = _normalize_pressure(raw_value)
            if pressure is None:
                continue

            rows.append((float(time_value), pressure))

        df = _pd.DataFrame(rows, columns=["time_seconds", label])
        time_series = _pd.to_numeric(df["time_seconds"], errors="coerce")
        time_index = self._time_index_from_seconds(time_series)
        df.insert(1, "time", _pd.Series(time_index, index=df.index))
        df.index = time_index
        df.index.name = "time"
        return df


__all__ = ["DiveTimeSeries"]
