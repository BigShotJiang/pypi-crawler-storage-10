﻿from datasets import load_dataset
from transformers import AutoTokenizer

# === Paths ===
train_path = "packs/train.jsonl"
val_path   = "packs/val.jsonl"
out_dir    = "packs/tokenized"

# === Load raw JSONL datasets ===
dataset = load_dataset(
    "json",
    data_files={"train": train_path, "validation": val_path},
)

# === Tokenizer ===
tokenizer = AutoTokenizer.from_pretrained("mistralai/Mistral-7B-v0.1", use_fast=True)
tokenizer.pad_token = tokenizer.eos_token

# === Handle multi-field entries ===
def format_text(example):
    if "text" in example:
        return example["text"]
    elif "instruction" in example and "output" in example:
        return f"Instruction: {example['instruction']}\nResponse: {example['output']}"
    elif "prompt" in example and "completion" in example:
        return f"{example['prompt']}\n{example['completion']}"
    else:
        return str(example)

# === Tokenization ===
def tokenize_fn(batch):
    texts = [format_text(e) for e in batch]
    return tokenizer(
        texts,
        truncation=True,
        padding="max_length",
        max_length=2048,
        return_tensors=None,
    )

tokenized = dataset.map(
    lambda e: tokenize_fn(e["text"]) if "text" in e else tokenize_fn(e),
    batched=True,
    remove_columns=dataset["train"].column_names,
)

tokenized.save_to_disk(out_dir)
print(f"✅ Tokenized dataset saved at: {out_dir}")
