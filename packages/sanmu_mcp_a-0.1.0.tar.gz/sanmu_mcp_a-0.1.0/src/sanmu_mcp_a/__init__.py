def main() -> None:
    print("Hello from sanmu-mcp-a!")
