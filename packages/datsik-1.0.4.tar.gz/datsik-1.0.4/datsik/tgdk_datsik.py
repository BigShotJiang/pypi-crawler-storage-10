﻿# tgdk_datsik.py
"""
TGDK DATSIK+ — Direct Adaptive Trainer for Symbolic Instructional Knowledge (extended)
-------------------------------------------------------------------------------------
• Deterministic seeding
• Checkpoint save/load (model + optim + sched + RNG states)
• Gradient checkpointing toggle
• AMP (native torch.cuda.amp) optional
• Single-node multi-GPU distributed via torch.distributed
• GhostGate accelerator integration
• Resilient callback handler (MirrorBlade-compatible)
• Telemetry emission for TGDK logging

Example:
    from tgdk_datsik import DATSIKTrainer, default_seed
    trainer = DATSIKTrainer(model, tokenizer, train_data, val_data,
                            config={"deterministic": True, "amp": True})
    trainer.fit(epochs=3, batch_size=8)
"""

import os, time, math, json, logging
from typing import Optional, Callable, Dict
from dataclasses import dataclass
from trl import SFTTrainer
import torch
from torch import nn
from torch.utils.data import DataLoader
from torch.cuda.amp import autocast, GradScaler
from tqdm import tqdm

# ---------------------------------------------------------------------
# Defaults & utilities
# ---------------------------------------------------------------------
DEFAULT_SAVE_INTERVAL = 1
DEFAULT_CHECKPOINT = "datsik_checkpoint.pt"
logger = logging.getLogger("DATSIK")
logger.setLevel(logging.INFO)
if not logger.handlers:
    ch = logging.StreamHandler()
    ch.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s", "%H:%M:%S"))
    logger.addHandler(ch)

def default_seed(seed: int = 1337):
    """Best-effort deterministic seeding."""
    import random, numpy as np
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed); np.random.seed(seed)
    torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    return seed

def save_checkpoint(path, model, optimizer, scheduler, scaler, epoch, extra=None):
    """Save model/optimizer/scheduler/scaler/RNG state."""
    state = {
        "epoch": epoch,
        "model_state": model.state_dict(),
        "optim_state": optimizer.state_dict() if optimizer else None,
        "sched_state": scheduler.state_dict() if scheduler else None,
        "scaler_state": scaler.state_dict() if scaler else None,
        "torch_rng": torch.get_rng_state(),
        "cuda_rng": torch.cuda.get_rng_state_all(),
        "extra": extra or {}
    }
    torch.save(state, path)
    logger.info(f"[DATSIK] Checkpoint saved → {path}")

def load_checkpoint(path, model, optimizer=None, scheduler=None, scaler=None, map_location=None):
    chk = torch.load(path, map_location=map_location)
    model.load_state_dict(chk["model_state"])
    if optimizer and chk.get("optim_state"): optimizer.load_state_dict(chk["optim_state"])
    if scheduler and chk.get("sched_state"): scheduler.load_state_dict(chk["sched_state"])
    if scaler and chk.get("scaler_state"): scaler.load_state_dict(chk["scaler_state"])
    if chk.get("torch_rng"): torch.set_rng_state(chk["torch_rng"])
    if chk.get("cuda_rng"): torch.cuda.set_rng_state_all(chk["cuda_rng"])
    logger.info(f"[DATSIK] Checkpoint loaded → {path}")
    return chk

def enable_gradient_checkpointing(model, enable=True):
    toggled = False
    for m in model.modules():
        if hasattr(m, "gradient_checkpointing_enable"):
            try:
                (m.gradient_checkpointing_enable() if enable else m.gradient_checkpointing_disable())
                toggled = True
            except Exception: pass
    logger.info(f"[DATSIK] gradient_checkpointing set to {enable} (toggled={toggled})")
    return toggled

TelemetryCallback = Callable[[Dict], None]

# ---------------------------------------------------------------------
# DATSIKTrainer
# ---------------------------------------------------------------------
class DATSIKTrainer(SFTTrainer):
    """Production-grade TGDK trainer."""
    def __init__(self, model, tokenizer, train_dataset, val_dataset=None,
                 optimizers=None, config=None, device=None,
                 log_prefix="[DATSIK]", telemetry_cb=None):
        cfg = config or {}
        self.cfg = cfg
        self.model = model
        self.tokenizer = tokenizer
        self.train_dataset = train_dataset
        self.val_dataset = val_dataset
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self._opt = optimizers[0] if optimizers else None
        self._sched = optimizers[1] if optimizers and len(optimizers) > 1 else None
        self.log_prefix = log_prefix
        self.telemetry_cb = telemetry_cb
        self.epochs_trained = 0
        
        # === HF Optimizer Fallback ===
        if not hasattr(self, "optimizer_cls_and_kwargs") or self.optimizer_cls_and_kwargs[0] is None:
             try:
                 default_cls = torch.optim.AdamW
                 default_kwargs = {"lr": 5e-5}
                 self.optimizer_cls_and_kwargs = (default_cls, default_kwargs)
                 print("[DATSIKTrainer] ⚙️ optimizer_cls_and_kwargs initialized to AdamW(lr=5e-5).")
             except Exception as e:
                 print(f"[DATSIKTrainer] ⚠️ Failed to set default optimizer_cls_and_kwargs: {e}")

        # === TGDK Duo Optimizer Integration ===
        if not hasattr(self, "duo_optim") or self.duo_optim is None:
             try:
                 from tgdk_optim import DuoOptimizer  # your TGDK optimizer abstraction
                 # You can configure the learning rate or momentum from the HF default
                 hf_cls, hf_kwargs = self.optimizer_cls_and_kwargs
                 self.duo_optim = DuoOptimizer(hf_cls, **hf_kwargs)
                 print(f"[DATSIKTrainer] 🧩 duo_optim initialized via DuoOptimizer({hf_cls.__name__}).")
             except ImportError:
                 # fallback if TGDK optimizer module not available
                 self.duo_optim = torch.optim.AdamW(self.model.parameters(), lr=5e-5)
                 print("[DATSIKTrainer] ⚙️ duo_optim fallback → AdamW(lr=5e-5).")
             except Exception as e:
                 print(f"[DATSIKTrainer] ⚠️ Failed to initialize duo_optim: {e}")



        # -----------------------------------------------------------------
        # GhostGate Accelerator integration
        # -----------------------------------------------------------------
        try:
            from tgdk_accelerator import GhostGateAccelerator
            self.accelerator = GhostGateAccelerator(
                mixed_precision="bf16" if torch.cuda.is_available() else "no",
                ghost_entropy=0.9997, teleport_band=11.86,
                device="cuda:0" if torch.cuda.is_available() else "cpu")
            print("[DATSIKTrainer] ⚡ GhostGateAccelerator attached as self.accelerator.")
        except ImportError:
            print("[DATSIKTrainer] ⚠️ tgdk_accelerator module not found — using dummy accelerator.")
            class DummyAccelerator:
                def prepare(self,*a,**kw): return a if len(a)>1 else a[0]
                def backward(self,loss,**kw): loss.backward()
                def wait_for_everyone(self): pass
                def inject(self,opt): return opt
                def refresh_inf_state(self): pass
                def free_memory(self): pass
            self.accelerator = DummyAccelerator()

        # -----------------------------------------------------------------
        # Compatibility guards
        # -----------------------------------------------------------------
        if not hasattr(self, "_memory_tracker"):
            from transformers.trainer_utils import TrainerMemoryTracker
            self._memory_tracker = TrainerMemoryTracker(skip_memory_metrics=False)
        self.neftune_noise_alpha = None
        self.hp_search_backend = None
        self.hp_search_kwargs = {}
        self.model_init = None
        self.optimizer = None
        self.lr_scheduler = None
        self.optimizer_cls_and_kwargs = (None, {})
        logger.info("[DATSIKTrainer] ✅ Initialization complete — compatibility guards active.")

        # Deterministic seed
        if cfg.get("deterministic", False):
            seed = cfg.get("seed", 1337)
            default_seed(seed)
            logger.info(f"{log_prefix} Deterministic mode enabled (seed={seed})")

        # AMP setup
        self.use_amp = bool(cfg.get("amp", False)) and torch.cuda.is_available()
        self.scaler = GradScaler(enabled=self.use_amp)
        if self.use_amp:
            logger.info(f"{log_prefix} AMP enabled (native)")

        # Gradient checkpointing
        if cfg.get("grad_ckpt"): enable_gradient_checkpointing(self.model, True)

        # Distributed
        self.distributed = False
        if int(os.environ.get("WORLD_SIZE", "1")) > 1:
            self.distributed = True
            self.local_rank = int(os.environ.get("LOCAL_RANK", 0))
            torch.distributed.init_process_group(backend=cfg.get("dist_backend", "nccl"), init_method="env://")
            logger.info(f"{log_prefix} Distributed initialized (rank={self.local_rank})")

        # Move model
        if self.distributed:
            dev = torch.device(f"cuda:{self.local_rank}" if torch.cuda.is_available() else "cpu")
            self.model.to(dev)
            self.model = nn.parallel.DistributedDataParallel(
                self.model, device_ids=[self.local_rank] if torch.cuda.is_available() else None)
            self.device = dev
        else:
            self.model.to(self.device)

        # Dataloader defaults
        self.num_workers = cfg.get("num_workers", 0)
        self.pin_memory = False if str(self.device).startswith("cuda") else True
        self.data_collator = self.collate
        self._set_signature_columns_if_needed()
        self.prefetch_factor = cfg.get("prefetch_factor", 2)
        logger.info(f"{log_prefix} initialized on device={self.device}, distributed={self.distributed}")

        # Default optimizer if missing
        if self._opt is None:
            self._opt = torch.optim.AdamW(self.model.parameters(), lr=cfg.get("lr", 5e-5))
            logger.info(f"{log_prefix} Default optimizer AdamW(lr={cfg.get('lr',5e-5)}) created.")
        if self._sched is None:
            self._sched = torch.optim.lr_scheduler.CosineAnnealingLR(self._opt, T_max=10)

        # === Ensure unused columns are not removed automatically ===
        if not hasattr(self, "args") or getattr(self, "args", None) is None:
            from transformers import TrainingArguments
            self.args = TrainingArguments(output_dir="./tgdk_out", remove_unused_columns=False)
        else:
            # If args exist, override safely
            self.args.remove_unused_columns = False

            print("[MirrorBlade] 🧩 remove_unused_columns set to False (TGDK mode active)")

    # -----------------------------------------------------------------
    # Collate
    # -----------------------------------------------------------------
    def collate(self, batch):
        texts = [b.get("text", "") for b in batch]
        toks = self.tokenizer(texts, padding=True, truncation=True,
                              max_length=self.cfg.get("max_length", 2048),
                              return_tensors="pt")
        toks["labels"] = toks["input_ids"].clone()
        return toks

# ============================================================
# TGDK Production Compatibility — _set_signature_columns_if_needed
# ============================================================

    def _set_signature_columns_if_needed(self):
        """
        TGDK Production Routine
        -----------------------
        Ensures that `self._signature_columns` is defined and synchronized with
        the model’s forward() signature.

        • Introspects model.forward() with safety guards
        • Deterministically sorts parameter names
        • Falls back to ["input_ids", "attention_mask", "labels"]
        • Emits MirrorBlade-grade structured logging
        • Self-heals if the model changes during runtime
 
        Required by:
            - Hugging Face Trainer (v4.43+)
            - TRL SFTTrainer (v0.8+)
            - TGDK hybrid pipeline for dynamic model adaptation
        """
        import inspect, datetime
 
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
 
        # Fast exit if already valid
        if hasattr(self, "_signature_columns") and isinstance(self._signature_columns, (list, tuple)):
            if len(self._signature_columns) > 0:
                print(f"[MirrorBlade] {timestamp} — 🧠 _signature_columns already defined → {self._signature_columns}")
                return self._signature_columns

        try:
            # --- Deep signature introspection ---
            sig = inspect.signature(self.model.forward)
            params = list(sig.parameters.keys())

            # --- Deterministic sort & filter ---
            cleaned = [p for p in params if not p.startswith("*")]
            cleaned = sorted(set(cleaned))

        # --- Apply ---
            self._signature_columns = cleaned
            print(f"[MirrorBlade] {timestamp} — ⚙️ _signature_columns synchronized → {cleaned}")

        except Exception as e:
        # --- Fallback pattern for text generation / seq2seq models ---
            fallback = ["input_ids", "attention_mask", "labels"]
            self._signature_columns = fallback
            print(f"[MirrorBlade] {timestamp} — ⚠️ _signature_columns fallback applied ({e}) → {fallback}")

        # --- Final Validation ---
        if not hasattr(self, "_signature_columns") or not isinstance(self._signature_columns, list):
            self._signature_columns = ["input_ids", "attention_mask", "labels"]
            print(f"[MirrorBlade] {timestamp} — 🛡️ Enforced default _signature_columns → {self._signature_columns}")

        return self._signature_columns

    # -----------------------------------------------------------------
    # Train step
    # -----------------------------------------------------------------
    def _train_step(self, batch, grad_accum: int = 1):
        """
        One gradient accumulation step.
        Returns a detached float loss for logging,
        while maintaining a valid autograd graph.
        """
    # ensure all tensors are on the correct device
        batch = {k: (v.to(self.device, non_blocking=True) if isinstance(v, torch.Tensor) else v)
                for k, v in batch.items() if k in ["input_ids", "attention_mask", "labels"]}
 
        # --- Forward pass ---
        if self.use_amp:
            with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                out = self.model(**batch)
        else:
            out = self.model(**batch)

        # --- Extract loss safely ---
        loss = None
        if isinstance(out, dict):
            loss = out.get("loss")
        elif hasattr(out, "loss"):
            loss = out.loss
        elif isinstance(out, (list, tuple)) and len(out) > 0:
            loss = out[0]
  
        if loss is None:
            raise ValueError(f"[DATSIKTrainer] No loss returned by model. Output keys: {dir(out)}")

    # normalize for gradient accumulation
        loss = loss / grad_accum

    # check for gradient availability
        if not loss.requires_grad:
            logger.warning("[DATSIKTrainer] Loss detached from graph (no grad_fn).")
            loss = loss.clone().detach().requires_grad_(True)

    # --- Backward pass ---
        if self.use_amp:
            self.scaler.scale(loss).backward()
        else:
            loss.backward()

    # Return scalar for logging
        return float(loss.detach().item() * grad_accum)


    def _optim_step(self):
        if self.use_amp:
            self.scaler.unscale_(self._opt)
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.cfg.get("max_grad_norm",1.0))
            self.scaler.step(self._opt); self.scaler.update()
        else:
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.cfg.get("max_grad_norm",1.0))
            self._opt.step()
        if self._sched: 
            try: self._sched.step()
            except: pass
        self._opt.zero_grad(set_to_none=True)

    # -----------------------------------------------------------------
    # Training / evaluation loops
    # -----------------------------------------------------------------
    def train_epoch(self, dataloader, epoch, grad_accum=1, log_interval=10):
        self.model.train()
        total, steps = 0.0, 0
        pbar = tqdm(dataloader, desc=f"{self.log_prefix} Train Ep{epoch}",
                    disable=self.distributed and int(os.environ.get("LOCAL_RANK",0))!=0)
        for step,batch in enumerate(pbar):
            loss = self._train_step(batch,grad_accum)
            total += loss; steps += 1
            if (step+1)%grad_accum==0: self._optim_step()
            if step%log_interval==0:
                self._emit_telemetry({"epoch":epoch,"step":step+1,"loss":loss})
                pbar.set_postfix({"loss":f"{loss:.4f}"})
        return total/max(1,steps)

    def evaluate(self, dataloader: DataLoader):
        self.model.eval()
        total_loss = 0.0
        steps = 0

        with torch.no_grad():
            for batch in tqdm(
                dataloader,
                desc=f"{self.log_prefix} Eval",
                disable=self.distributed and int(os.environ.get("LOCAL_RANK", 0)) != 0
            ):
                # Ensure all tensors are on the correct device
                batch = {
                    k: (v.to(self.device, non_blocking=True) if isinstance(v, torch.Tensor) else v)
                    for k, v in batch.items()
                    if k in ["input_ids", "attention_mask", "labels"]
                }
 
                out = self.model(**batch)
 
                # Support dict / ModelOutput / tuple forms
                if isinstance(out, dict):
                    loss_val = out.get("loss", None)
                else:
                    loss_val = getattr(out, "loss", None)
                    if loss_val is None and isinstance(out, (list, tuple)) and len(out) > 0:
                        loss_val = out[0]

                if loss_val is None:
                     raise ValueError("[DATSIKTrainer] Model forward() returned no loss during evaluation")

                total_loss += float(loss_val.item())
                steps += 1

        return total_loss / max(1, steps)

    # -----------------------------------------------------------------
    # Telemetry
    # -----------------------------------------------------------------
    def _emit_telemetry(self, payload):
        payload = dict(payload); payload["_time"]=time.time()
        try:
            payload["_gpu_mem_gb"]=torch.cuda.memory_allocated()/(1024**3) if torch.cuda.is_available() else 0
        except: payload["_gpu_mem_gb"]=None
        if callable(self.telemetry_cb):
            try: self.telemetry_cb(payload)
            except Exception as e: logger.warning(f"{self.log_prefix} telemetry_cb failed: {e}")
        else:
            logger.info(f"{self.log_prefix} telemetry: {json.dumps(payload,default=str)}")

    # -----------------------------------------------------------------
    # Fit
    # -----------------------------------------------------------------
    def fit(self, epochs=1, batch_size=8, grad_accum=1,
            resume_from=None, save_every=DEFAULT_SAVE_INTERVAL,
            checkpoint_path=DEFAULT_CHECKPOINT):
        # Dataloaders
        if self.distributed:
            from torch.utils.data.distributed import DistributedSampler
            train_dl = DataLoader(self.train_dataset,batch_size=batch_size,
                                  sampler=DistributedSampler(self.train_dataset),
                                  num_workers=self.num_workers,pin_memory=self.pin_memory,
                                  collate_fn=self.collate,prefetch_factor=self.prefetch_factor)
            val_dl = DataLoader(self.val_dataset,batch_size=batch_size,
                                sampler=DistributedSampler(self.val_dataset) if self.val_dataset else None,
                                num_workers=self.num_workers,pin_memory=self.pin_memory,
                                collate_fn=self.collate,prefetch_factor=self.prefetch_factor) if self.val_dataset else None
        else:
            train_dl = DataLoader(self.train_dataset,batch_size=batch_size,shuffle=True,
                                  num_workers=self.num_workers,pin_memory=self.pin_memory,
                                  collate_fn=self.collate,
                                  prefetch_factor=self.prefetch_factor if self.num_workers>0 else None)
            val_dl = DataLoader(self.val_dataset,batch_size=batch_size,shuffle=False,
                                num_workers=self.num_workers,pin_memory=self.pin_memory,
                                collate_fn=self.collate,
                                prefetch_factor=self.prefetch_factor if self.num_workers>0 else None) if self.val_dataset else None

        start_epoch=1
        if resume_from and os.path.exists(resume_from):
            load_checkpoint(resume_from,self.model,self._opt,self._sched,self.scaler,self.device)
            start_epoch=int(torch.load(resume_from).get("epoch",1))+1

        for ep in range(start_epoch,epochs+1):
            if self.distributed: train_dl.sampler.set_epoch(ep)
            tr_loss=self.train_epoch(train_dl,ep,grad_accum)
            val_loss=self.evaluate(val_dl) if val_dl else None
            metrics={"epoch":ep,"train_loss":tr_loss,"val_loss":val_loss}
            self._emit_telemetry(metrics)
            logger.info(f"{self.log_prefix} Epoch {ep}/{epochs} -> train={tr_loss:.4f}" +
                        (f" val={val_loss:.4f}" if val_loss is not None else ""))
            if (ep%save_every)==0 or ep==epochs:
                save_checkpoint(checkpoint_path,self.model,self._opt,self._sched,self.scaler,ep,extra={"metrics":metrics})
                if self.distributed: torch.distributed.barrier()

        self.epochs_trained+=(epochs-start_epoch+1)
        if self.distributed: torch.distributed.destroy_process_group()
        logger.info(f"{self.log_prefix} Training complete (epochs_trained={self.epochs_trained})")
        return True

    # -----------------------------------------------------------------
    # Loss & callback utilities
    # -----------------------------------------------------------------
    def compute_loss(self, model, inputs, return_outputs=False):
        device=getattr(model,"device",torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        if isinstance(inputs,dict):
            for k,v in inputs.items():
                if isinstance(v,torch.Tensor): inputs[k]=v.to(device)
        outputs=model(**inputs)
        loss=(outputs.get("loss") if isinstance(outputs,dict)
              else getattr(outputs,"loss",outputs[0] if isinstance(outputs,(list,tuple)) else None))
        if loss is None: raise ValueError("No loss returned by model.")
        if not loss.requires_grad: loss=loss.clone().detach().requires_grad_(True)
        return (loss,outputs) if return_outputs else loss

    def add_callback(self, callback):
        import threading, datetime
        lock=threading.Lock()
        with lock:
            handler=getattr(self,"callback_handler",None)
            name=callback.__class__.__name__
            if handler is None:
                print(f"[DATSIKTrainer] ⚠️ No callback handler found; cannot register {name}."); return False
            if any(isinstance(cb,callback.__class__) for cb in handler.callbacks):
                print(f"[DATSIKTrainer] ⚠️ Callback already registered → {name}"); return True
            try:
                handler.add_callback(callback)
                print(f"[MirrorBlade] {datetime.datetime.now().strftime('%H:%M:%S')} — 🧩 Callback registered: {name}")
                return True
            except Exception as e:
                print(f"[DATSIKTrainer] ❌ Failed to register {name}: {e}")
                return False

# ---------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------
if __name__ == "__main__":
    import torch.nn.functional as F
    class TinyModel(nn.Module):
        def __init__(self): super().__init__(); self.l=nn.Linear(10,10)
        def forward(self,input_ids,attention_mask=None,labels=None):
            out=self.l(input_ids.float()); loss=F.mse_loss(out,input_ids.float())
            return {"loss":loss}

    tok=lambda texts,**_:{"input_ids":torch.randn(len(texts),10),"attention_mask":None}
    dummy=[{"text":"hi"} for _ in range(8)]
    t=DATSIKTrainer(TinyModel(),tok,dummy,dummy,config={"amp":False,"grad_ckpt":False})
    t.fit(epochs=1,batch_size=4)
