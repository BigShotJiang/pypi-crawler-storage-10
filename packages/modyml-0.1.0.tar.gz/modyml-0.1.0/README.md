# ModYml

## 📦 Project Introduction

ModYml is a lightweight Python configuration management library designed for modular and reusable configurations. With YAML file support, it enables configuration inheritance, parameter overriding, and alias systems, making complex configuration management simple and intuitive.

## ✨ Key Features

- **Modular Configs**: Split configurations into reusable modules
- **Dynamic Inheritance**: Reference other configs using `$module.key` syntax
- **Parameter Overriding**: Modify parameters at runtime with `$module.key(param=value)`
- **Alias System**: Create short aliases for config items `key(alias)`
- **Namespace Isolation**: Automatic namespace management for config items
- **Dot-access**: Returns `EasyDict` objects for attribute-style access

## ⚙️ Installation

```bash
pip install modyml
```

## 🚀 Quick Start

1. Create module config (`modules/optimizers.yml`):

```yaml
adam:
  type: Adam
  params:
    learning_rate(lr): 0.001
    weight_decay(wd): 0.0001
```

2. Create experiment config (`experiments/E01.yml`):

```yaml
training:
  base_optimizer: $optimizers.adam
  custom_optimizer: $optimizers.adam(lr=0.002)
  special_optimizer($optimizers.adam):
    params:
      wd: 0.01
```

3. Load configuration:

```python
from modyml import load

config = load(
    "experiments/E01.yml",
    module_files=["modules/optimizers.yml"],
    base_dir="configs/"
)

print(config.training.base_optimizer.params.lr)  # Output: 0.001
print(config.training.custom_optimizer.params.lr)  # Output: 0.002
print(config.training.special_optimizer.params.wd)  # Output: 0.01
```

## 🧪 Testing

```bash
pytest tests/
```

---

**Author**: Yuyao Huang (Sam)
**License**: MIT
