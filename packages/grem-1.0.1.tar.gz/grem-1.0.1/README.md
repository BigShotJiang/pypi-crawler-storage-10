# grem

A nested command-line utility that helps you manage repositories hosted on Git
service providers.

## License

Copyright (C) 2025 Garrett HE <garrett.he@outlook.com>

The BSD 3-Clause License, see [LICENSE](./LICENSE).
