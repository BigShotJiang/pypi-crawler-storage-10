.. _examples_sec:

Examples
========

Below are links to some code examples that show how one can use the ``emicroml``
library. It is recommended that users go through each example so that they can
see all the different features that have been implemented in ``emicroml``.

.. toctree::

   examples/modelling/cbed.rst
