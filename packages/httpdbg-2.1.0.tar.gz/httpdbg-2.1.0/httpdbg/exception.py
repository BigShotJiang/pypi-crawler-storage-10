# -*- coding: utf-8 -*-


class HttpdbgException(Exception):
    """An issue occurred in httpdbg."""

    pass
