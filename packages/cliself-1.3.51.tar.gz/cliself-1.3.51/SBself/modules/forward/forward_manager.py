# CliSelf/modules/forward_manager.py

import asyncio
import urllib.parse as up
from pyrogram import Client
from ...core.logger import get_logger

logger = get_logger("forward")

class ForwardManager:
    """
    ForwardManager
    ---------------
    مدیریت فوروارد پیام‌ها بین چت‌ها.
    شامل:
        - resolve_chat_id(): تشخیص و تبدیل ورودی (id, username, t.me link)
        - forward_all(): فوروارد تمام پیام‌ها از منبع به مقصد
    """

    def __init__(self, client: Client):
        self.client = client
        logger.info("ForwardManager initialized successfully.")

    # ----------------------------------------------------------
    # 🔹 تشخیص خودکار چت بر اساس ورودی (id, username, t.me link)
    # ----------------------------------------------------------
    async def resolve_chat_id(self, ident: str):
        """
        تشخیص و برگرداندن chat_id از انواع ورودی‌ها:
        - عددی (chat_id)
        - username یا لینک t.me
        - 'me' برای پیام به خود شخص
        """
        if not ident:
            return None
        ident = ident.strip()
        if ident.lower() == "me":
            return "me"

        if "t.me/" in ident:
            ident = up.urlparse(ident).path.strip("/")

        if ident.lstrip("-").isdigit():
            num = int(ident)
            try:
                c = await self.client.get_chat(num)
                return c.id
            except:
                try:
                    u = await self.client.get_users(num)
                    return u.id
                except:
                    return None

        try:
            c = await self.client.get_chat(ident)
            return c.id
        except:
            try:
                u = await self.client.get_users(ident)
                return u.id
            except:
                return None

    # ----------------------------------------------------------
    # 🔹 فوروارد تمام پیام‌ها از SRC به DEST
    # ----------------------------------------------------------
    async def forward_all(self, src: str, dst: str):
        """
        فوروارد تمام پیام‌ها از چت منبع (src) به چت مقصد (dst).
        پشتیبانی از ID، username، لینک t.me و 'me'.
        """
        src_id = await self.resolve_chat_id(src)
        dst_id = await self.resolve_chat_id(dst)

        if not src_id or not dst_id:
            logger.warning("SRC یا DEST نامعتبر است.")
            raise ValueError("SRC یا DEST نامعتبر است.")

        count = 0
        try:
            logger.info(f"🚀 Starting forward: {src} → {dst}")

            # --- تاریخچه را صفحه‌به‌صفحه بگیریم و لیست آیدی‌ها را با ترتیب قدیمی→جدید بسازیم
            ids = []
            offset_id = 0
            page_size = 200  # می‌تونی 100-200 بذاری؛ بیشتر برابر ریسک بالاتر FloodWait
            while True:
                # get_chat_history پیام‌ها را به‌صورت جدید→قدیم برمی‌گرداند
                batch = await self.client.get_chat_history(
                    chat_id=src_id,
                    offset_id=offset_id,
                    limit=page_size
                )
                if not batch:
                    break

                # برای ارسال به ترتیب قدیمی→جدید، این صفحه را معکوس کن
                batch.reverse()
                ids.extend(m.id for m in batch)

                # برای صفحه بعدی، قدیمی‌ترین پیام همین صفحه را به‌عنوان offset بگذاریم
                offset_id = batch[0].id

            if not ids:
                logger.info("هیچ پیامی برای فوروارد وجود ندارد.")
                return "❌ پیامی برای فوروارد نیست."

            # ids هم‌اکنون به ترتیب قدیمی→جدید است
            chunk_size = 90   # کمتر از 100 تا با محدودیت‌ها سازگارتر باشد
            delay_sec = 0.2   # مکث کوتاه بین چانک‌ها برای کاهش FloodWait

            for i in range(0, len(ids), chunk_size):
                chunk = ids[i:i + chunk_size]
                try:
                    # تلاش برای فوروارد گروهی
                    await self.client.forward_messages(
                        chat_id=dst_id,
                        from_chat_id=src_id,
                        message_ids=chunk
                    )
                    count += len(chunk)
                    logger.info(f"✅ Forwarded {len(chunk)} messages ({count} total).")
                except Exception as e:
                    # اگر ارسال گروهی شکست خورد (مثلاً به خاطر protected content در بینشان)،
                    # دانه‌دانه تلاش می‌کنیم تا حد ممکن ارسال شود.
                    logger.warning(f"⚠️ Chunk forward failed: {type(e).__name__} - {e} | falling back to single sends")
                    for mid in chunk:
                        try:
                            await self.client.forward_messages(dst_id, src_id, mid)
                            count += 1
                        except Exception as ee:
                            # پیام‌های محافظت‌شده/حذف‌شده/نامجاز را رد می‌کنیم
                            logger.debug(f"↪️ skip msg {mid}: {type(ee).__name__} - {ee}")
                            continue

                # مکث کوتاه برای کاهش ریسک FloodWait
                await asyncio.sleep(delay_sec)

            logger.info(f"✅ Forward complete: {count} messages from {src} → {dst}")
            return f"✅ {count} پیام از {src} به {dst} فوروارد شد."

        except Exception as e:
            logger.error(f"💥 Error during forward_all: {type(e).__name__} - {e}")
            raise
