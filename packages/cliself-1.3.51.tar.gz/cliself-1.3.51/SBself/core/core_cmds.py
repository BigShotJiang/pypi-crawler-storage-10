# -*- coding: utf-8 -*-
# File: CliSelf/SBself/core/core_cmds.py
"""
Ultra‑Status v6 — خوانا برای همه (بدون اصطلاحات فنی) + تمیزتر

تغییرات نسبت به v5:
- حالت «human» برای خروجی ساده و قابل‌فهم برای همه (بدون مخفف‌های فنی)
- حذف کامل owner از گزارش
- برچسب‌های فارسیِ روشن + توضیح کوتاه کنار هر مورد
- چیدمان مرتب با بخش‌های واضح (وضعیت برنامه، سیستم، اینترنت، قابلیت‌ها، دسترسی‌ها، رخدادها، سلامت، هشدارها)
- نگه‌داشتن حالت‌های قبلی (plain / md / json) برای استفادهٔ فنی
"""
from __future__ import annotations

import os
import sys
import time
import json
import gc
import socket
import platform
import asyncio
import locale
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, Iterable, List, Tuple, DefaultDict

try:
    import importlib.metadata as importlib_metadata  # py3.8+
except Exception:  # pragma: no cover
    import importlib_metadata  # type: ignore

# Optional psutil
try:  # pragma: no cover
    import psutil  # type: ignore
except Exception:  # pragma: no cover
    psutil = None  # type: ignore

# Optional pyrogram
try:  # pragma: no cover
    from pyrogram import Client
except Exception:  # pragma: no cover
    Client = None  # type: ignore

from ..config import AllConfig, _reset_state_to_defaults

START_TIME = time.time()

# =============================
# 🔧 Helpers
# =============================

def _read_version_from_repo() -> str:
    try:
        here = os.path.abspath(os.path.dirname(__file__))
        root = os.path.abspath(os.path.join(here, "..", "..", ".."))
        for p in (
            os.path.join(root, "version.txt"),
            os.path.join(root, "CliSelf", "version.txt"),
        ):
            if os.path.isfile(p):
                with open(p, "r", encoding="utf-8", errors="ignore") as f:
                    v = f.read().strip()
                    if v:
                        return v
    except Exception:
        pass
    for dist_name in ("cliself", "CliSelf"):
        try:
            return importlib_metadata.version(dist_name)
        except Exception:
            continue
    return "unknown"


def _git_info() -> Dict[str, Any]:
    info = {"branch": None, "short_sha": None, "dirty": None}
    try:
        here = os.path.abspath(os.path.dirname(__file__))
        root = os.path.abspath(os.path.join(here, "..", "..", ".."))
        head = os.path.join(root, ".git", "HEAD")
        if os.path.isfile(head):
            with open(head, "r", encoding="utf-8", errors="ignore") as f:
                line = f.read().strip()
            if line.startswith("ref:"):
                ref = line.split(" ", 1)[1].strip()
                info["branch"] = ref.rsplit("/", 1)[-1]
                ref_path = os.path.join(root, ".git", ref)
                if os.path.isfile(ref_path):
                    with open(ref_path, "r", encoding="utf-8", errors="ignore") as f:
                        sha = f.read().strip()
                        info["short_sha"] = sha[:7]
            else:
                info["short_sha"] = line[:7]
            try:
                idx = os.path.join(root, ".git", "index")
                info["dirty"] = bool(os.path.getmtime(idx))
            except Exception:
                info["dirty"] = None
    except Exception:
        pass
    return info


def _human_dt(seconds: float) -> str:
    if seconds < 0:
        seconds = 0
    d, rem = divmod(int(seconds), 86400)
    h, rem = divmod(rem, 3600)
    m, s = divmod(rem, 60)
    parts = []
    if d:
        parts.append(f"{d}d")
    parts.append(f"{h:02}h")
    parts.append(f"{m:02}m")
    parts.append(f"{s:02}s")
    return " ".join(parts)


def _fmt_bool(x: Any) -> str:
    return "✅" if bool(x) else "❌"


def _fmt_bytes(n: Optional[float]) -> str:
    if n is None:
        return "—"
    units = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    n = float(n)
    while n >= 1024 and i < len(units) - 1:
        n /= 1024.0
        i += 1
    return f"{n:.1f} {units[i]}"


def _kv_list(items: Iterable[Tuple[str, str]]) -> str:
    # Proper newlines between rows
    return "".join(f"- {k}: {v}" for k, v in items)


def _safe_get(d: Dict[str, Any], key: str, default=None):
    try:
        return d.get(key, default)
    except Exception:
        return default


def _truncate_list(items: List[Any], limit: int = 6) -> str:
    items = list(items or [])
    if not items:
        return "—"
    if len(items) <= limit:
        return "  ".join(map(str, items))
    return "  ".join(map(str, items[:limit])) + f"  …(+{len(items)-limit})"


def _env_safe_snapshot(whitelist_prefixes=("PYTHON", "TZ", "HTTP_", "HTTPS_", "ALL_PROXY", "NO_PROXY", "TG_", "PROXY", "LANG")) -> List[Tuple[str, str]]:
    rows: List[Tuple[str, str]] = []
    for k, v in sorted(os.environ.items()):
        if any(k.startswith(p) for p in whitelist_prefixes):
            val = v
            if any(x in k for x in ("TOKEN", "KEY", "SECRET", "PASS")):
                val = "***"
            rows.append((k, val))
    return rows


def _process_mem_mb() -> Optional[float]:
    if psutil is not None:
        try:
            return psutil.Process(os.getpid()).memory_info().rss / (1024 * 1024)
        except Exception:
            pass
    try:
        import resource  # type: ignore
        usage = resource.getrusage(resource.RUSAGE_SELF)
        rss_kb = float(usage.ru_maxrss)
        if sys.platform == "darwin":
            rss_mb = rss_kb / (1024 * 1024)
        else:
            rss_mb = rss_kb / 1024.0
        return max(rss_mb, 0.0)
    except Exception:
        pass
    try:
        with open("/proc/self/statm", "r") as f:
            pages = int(f.read().split()[1])
        page_size = os.sysconf("SC_PAGE_SIZE")
        return pages * page_size / (1024 * 1024)
    except Exception:
        return None

# =============================
# 🛰️ Latency probes
# =============================
async def _probe_api_latency(client: Optional[Client], trials: int = 3) -> float:
    if not client:
        return float("nan")
    results = []
    for _ in range(max(1, trials)):
        t0 = time.perf_counter()
        try:
            await client.get_me()
        except Exception:
            pass
        results.append((time.perf_counter() - t0) * 1000.0)
        await asyncio.sleep(0.05)
    results.sort()
    return results[len(results)//2] if results else float("nan")


async def _probe_chat_action_latency(client: Optional[Client], chat_id: Optional[int]) -> Optional[float]:
    if not client or not chat_id:
        return None
    t0 = time.perf_counter()
    try:
        await client.send_chat_action(chat_id, "typing")
    except Exception:
        return None
    return (time.perf_counter() - t0) * 1000.0

# =============================
# 🧰 Core commands
# =============================
async def ping(client: Optional[Client] = None, chat_id: Optional[int] = None) -> str:
    parts = ["PONG"]
    api_ms = await _probe_api_latency(client, trials=3)
    chat_ms = await _probe_chat_action_latency(client, chat_id)
    if api_ms == api_ms:
        parts.append(f"• API: {api_ms:.0f} ms")
    if chat_ms is not None:
        parts.append(f"• ChatAction: {chat_ms:.0f} ms")
    return "".join(parts)


async def uptime() -> str:
    return f"⏱ Uptime: {_human_dt(time.time() - START_TIME)}"


async def restart() -> str:
    try:
        return _reset_state_to_defaults()
    except Exception as e:
        return f"⚠️ Restart error: {e}"


async def shutdown() -> str:
    os._exit(0)  # pragma: no cover
    return "🛑 Shutting down..."

# =============================
# 🧾 Collectors + Deep collectors
# =============================

def _collect_environment() -> List[Tuple[str, str]]:
    py_ver = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    p_ver = getattr(sys.modules.get("pyrogram"), "__version__", "?")
    version = _read_version_from_repo()
    tz = time.tzname[0] if time.tzname else "?"
    loc = ",".join(filter(None, [*(locale.getlocale() or (None, None))])) or "?"
    host = socket.gethostname()
    git = _git_info()
    rows = [
        ("version", version),
        ("python", py_ver),
        ("pyrogram", p_ver),
        ("platform", f"{platform.system()} {platform.release()}"),
        ("hostname", host),
        ("pid", str(os.getpid())),
        ("uptime", _human_dt(time.time() - START_TIME)),
        ("timezone", tz),
        ("locale", loc),
        ("workdir", os.getcwd()),
        ("git.branch", str(git.get("branch"))),
        ("git.sha", str(git.get("short_sha"))),
        ("git.dirty", str(git.get("dirty"))),
    ]
    mem_mb = _process_mem_mb()
    if mem_mb is not None:
        rows.append(("proc.mem", f"{mem_mb:.1f} MB"))
    if psutil is not None:
        try:
            bt = psutil.boot_time()
            rows.append(("boot_time", datetime.fromtimestamp(bt).isoformat(timespec="seconds")))
        except Exception:
            pass
    return rows


def _collect_runtime() -> List[Tuple[str, str]]:
    rows: List[Tuple[str, str]] = []
    loop = None
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        pass
    rows.append(("asyncio.loop", loop.__class__.__name__ if loop else "—"))
    try:
        rows.append(("asyncio.policy", asyncio.get_event_loop_policy().__class__.__name__))
    except Exception:
        pass
    try:
        rows.append(("asyncio.debug", _fmt_bool(asyncio.get_event_loop_policy().get_event_loop().get_debug())))
    except Exception:
        pass
    if loop:
        try:
            tasks = len(asyncio.all_tasks(loop))
            rows.append(("asyncio.tasks", str(tasks)))
        except Exception:
            pass
    rows.append(("argv", " ".join(sys.argv[:8]) + (" …" if len(sys.argv) > 8 else "")))
    try:
        stats = gc.get_stats()
        rows.append(("gc.gen0", str(stats[0].get("collections", 0))))
        rows.append(("gc.gen1", str(stats[1].get("collections", 0))))
        rows.append(("gc.gen2", str(stats[2].get("collections", 0))))
    except Exception:
        pass
    if psutil is not None:
        try:
            p = psutil.Process(os.getpid())
            rows.append(("threads", str(p.num_threads())))
            rows.append(("fds.open", str(p.num_fds()) if hasattr(p, "num_fds") else "?"))
        except Exception:
            pass
    return rows


def _collect_system() -> List[Tuple[str, str]]:
    rows: List[Tuple[str, str]] = []
    if psutil is not None:
        try:
            rows.append(("cpu%", f"{psutil.cpu_percent(interval=0.0):.0f}%"))
        except Exception:
            pass
        try:
            vm = psutil.virtual_memory()
            rows.extend([
                ("mem.used", _fmt_bytes(vm.used)),
                ("mem.free", _fmt_bytes(vm.available)),
            ])
        except Exception:
            pass
        try:
            net = psutil.net_io_counters(pernic=True)
            for nic, st in net.items():
                rows.append((f"net.{nic}.tx", _fmt_bytes(st.bytes_sent)))
                rows.append((f"net.{nic}.rx", _fmt_bytes(st.bytes_recv)))
        except Exception:
            pass
    else:
        try:
            la1, la5, la15 = os.getloadavg()
            rows.append(("loadavg", f"{la1:.2f} {la5:.2f} {la15:.2f}"))
        except Exception:
            pass
    try:
        st = os.statvfs(os.getcwd())
        total = st.f_frsize * st.f_blocks
        free = st.f_frsize * st.f_bavail
        used = total - free
        rows.append(("disk.total", _fmt_bytes(total)))
        rows.append(("disk.used", _fmt_bytes(used)))
        rows.append(("disk.free", _fmt_bytes(free)))
        if total and free/total < 0.10:
            rows.append(("disk.alert", "⚠️ low free space <10%"))
    except Exception:
        pass
    return rows


def _collect_network_proxy() -> List[Tuple[str, str]]:
    rows = []
    try:
        rows.append(("dns.hostname", socket.getfqdn()))
        rows.append(("dns.host_ip", socket.gethostbyname(socket.gethostname())))
    except Exception:
        pass
    for k, v in _env_safe_snapshot():
        rows.append((k, v))
    try:
        with open("/proc/net/route") as f:
            for line in f.read().splitlines()[1:]:
                parts = line.split()[:3]
                if len(parts) >= 3 and parts[1] == '00000000':
                    rows.append(("net.default_gw", parts[0]))
                    break
    except Exception:
        pass
    return rows


def _collect_access(cfg: Dict[str, Any]) -> List[Tuple[str, str]]:
    admin = cfg.setdefault("admin", {})
    admins = admin.get("admins", []) or []
    # owner ها طبق درخواست کاربر حذف شدند
    return [
        ("admins", str(len(admins))),
        ("admins.sample", _truncate_list(admins, 5)),
    ]


def _ratio(ok: int, err: int) -> str:
    total = ok + err
    if total <= 0:
        return "—"
    pct = 100.0 * ok / total
    return f"{pct:.0f}%"


def _eta(queue_len: int, rate_per_sec: float) -> str:
    if not rate_per_sec:
        return "—"
    return _human_dt(queue_len / rate_per_sec)


def _collect_features_from_config(cfg: Dict[str, Any]) -> List[Tuple[str, str]]:
    spammer = cfg.setdefault("spammer", {})
    mention = cfg.setdefault("mention", {})
    enemy = cfg.setdefault("enemy", {})
    backup = cfg.setdefault("backup", {})
    media = cfg.setdefault("media", {})
    timer = cfg.setdefault("timer", {})
    text = cfg.setdefault("text", {})
    forwarder = cfg.setdefault("forward", cfg.setdefault("forwarder", {}))
    rate = cfg.setdefault("rate_limit", {})

    rows: List[Tuple[str, str]] = []
    sent = int(spammer.get("sent_count", 0) or 0)
    errs = int(spammer.get("error_count", 0) or 0)
    qlen = len(spammer.get("queue", []) or [])
    rps = float(spammer.get("rate_per_sec", 0) or 0)
    rows.extend([
        ("spammer.enabled", _fmt_bool(spammer.get("enabled", spammer.get("on", False)))),
        ("spammer.typing", _fmt_bool(spammer.get("typing_on", False))),
        ("spammer.schedule", _fmt_bool(_safe_get(spammer, "via_schedule", {}).get("enabled", False))),
        ("spammer.sent", str(sent)),
        ("spammer.errors", str(errs)),
        ("spammer.success%", _ratio(sent, errs)),
        ("spammer.queue", str(qlen)),
        ("spammer.eta", _eta(qlen, rps)),
        ("spammer.targets", _truncate_list(spammer.get("targets", []))),
    ])

    f_sent = int(forwarder.get("sent_count", 0) or 0)
    f_errs = int(forwarder.get("error_count", 0) or 0)
    rows.extend([
        ("forward.enabled", _fmt_bool(forwarder.get("enabled", forwarder.get("on", False)))),
        ("forward.mode", str(forwarder.get("mode", "—"))),
        ("forward.routes", _truncate_list(forwarder.get("routes", []))),
        ("forward.queue", str(len(forwarder.get("queue", []) or []))),
        ("forward.sent", str(f_sent)),
        ("forward.errors", str(f_errs)),
        ("forward.success%", _ratio(f_sent, f_errs)),
    ])

    rows.extend([
        ("mention.enabled", _fmt_bool(mention.get("is_menshen", False))),
        ("mention.group", _fmt_bool(mention.get("group_menshen", False))),
        ("enemy.enabled", _fmt_bool(enemy.get("enabled", enemy.get("on", False)))),
        ("enemy.blocked", str(len(enemy.get("blocked", []) or []))),
    ])

    rows.extend([
        ("backup.enabled", _fmt_bool(backup.get("enabled", backup.get("on", False)))),
        ("backup.dir", str(backup.get("dir", "—"))),
        ("media.enabled", _fmt_bool(media.get("enabled", media.get("on", False)))),
        ("media.paths", _truncate_list(media.get("paths", []))),
    ])

    rows.extend([
        ("timer.enabled", _fmt_bool(timer.get("on", timer.get("enabled", False)))),
        ("timer.targets", _truncate_list(timer.get("targets", []))),
        ("timer.next", str(timer.get("next_run", "—"))),
        ("text.lines", str(len(text.get("lines", []) or []))),
        ("text.caption", (text.get("caption", "")[:40] + "…") if len(text.get("caption", "")) > 40 else (text.get("caption", "") or "—")),
    ])

    if rate:
        rows.extend([
            ("rate.window", str(rate.get("window", "—"))),
            ("rate.budget", str(rate.get("budget", "—"))),
            ("rate.remaining", str(rate.get("remaining", "—"))),
            ("rate.reset_in", _human_dt(max(0, float(rate.get("reset_in", 0) or 0)))),
        ])

    metrics = cfg.get("metrics", {}) or {}
    for k, v in sorted(metrics.items()):
        rows.append((f"metrics.{k}", str(v)))

    return rows


def _collect_pyrogram(client: Optional[Client]) -> List[Tuple[str, str]]:
    rows: List[Tuple[str, str]] = []
    if not client:
        return [("client", "—")]
    try:
        rows.append(("client.name", getattr(client, "name", "?")))
        rows.append(("client.connected", _fmt_bool(getattr(client, "is_connected", False))))
    except Exception:
        pass
    try:
        me = getattr(client, "me", None)
        if me:
            rows.append(("me.id", str(getattr(me, "id", "?"))))
            uname = getattr(me, "username", None)
            rows.append(("me.username", f"@{uname}" if uname else "—"))
    except Exception:
        pass
    return rows


def _collect_storage_stats(cfg: Dict[str, Any], *, top_n: int = 10) -> List[Tuple[str, str]]:
    rows: List[Tuple[str, str]] = []
    bdir = _safe_get(cfg.setdefault("backup", {}), "dir", None)
    if bdir and os.path.isdir(bdir):
        total = 0
        try:
            for root, _, files in os.walk(bdir):
                for fn in files:
                    fp = os.path.join(root, fn)
                    try:
                        total += os.path.getsize(fp)
                    except Exception:
                        pass
            rows.append(("backup.size", _fmt_bytes(total)))
        except Exception:
            pass
    try:
        sizes = []
        total = 0
        for fn in os.listdir("."):
            try:
                if os.path.isfile(fn):
                    sz = os.path.getsize(fn)
                    sizes.append((sz, fn))
                    total += sz
            except Exception:
                pass
        rows.append(("cwd.files.size", _fmt_bytes(total)))
        sizes.sort(reverse=True)
        for sz, fn in sizes[:max(1, top_n)]:
            rows.append((f"cwd.top.{fn}", _fmt_bytes(sz)))
    except Exception:
        pass
    try:
        if psutil is not None:
            for part in psutil.disk_partitions(all=False):
                try:
                    usage = psutil.disk_usage(part.mountpoint)
                    rows.append((f"mnt.{part.mountpoint}.used", _fmt_bytes(usage.used)))
                    rows.append((f"mnt.{part.mountpoint}.free", _fmt_bytes(usage.free)))
                except Exception:
                    pass
    except Exception:
        pass
    return rows


def _collect_events(cfg: Dict[str, Any]) -> List[Tuple[str, str]]:
    ev = cfg.get("events", []) or []
    if not ev:
        return []
    from collections import defaultdict
    grp: DefaultDict[str, Dict[str, Any]] = defaultdict(lambda: {"count": 0, "last": 0})
    for e in ev[-200:]:
        t = str(e.get('type','?'))
        ts = float(e.get('ts', 0) or 0)
        grp[t]["count"] += 1
        grp[t]["last"] = max(grp[t]["last"], ts)
    lines = [f"{k}: {v['count']} (last {datetime.fromtimestamp(v['last']).isoformat(timespec='seconds')})" for k, v in grp.items()]
    if not lines:
        return []
    pretty = " - " + " - ".join(sorted(lines))
    return [("recent", pretty)]


def _collect_health(cfg: Dict[str, Any]) -> List[Tuple[str, str]]:
    rows: List[Tuple[str, str]] = []
    checks = cfg.get("health_checks", {}) or {}
    for name, spec in checks.items():
        try:
            ok = bool(spec.get("ok", True)) if isinstance(spec, dict) else bool(spec)
            msg = spec.get("msg", "") if isinstance(spec, dict) else ""
            rows.append((f"{name}", f"{_fmt_bool(ok)} {msg}".strip()))
        except Exception:
            rows.append((f"{name}", "❌"))
    return rows


def _collect_security() -> List[Tuple[str, str]]:
    rows: List[Tuple[str, str]] = []
    try:
        rows.append(("uid", str(os.getuid())))  # type: ignore[attr-defined]
        rows.append(("euid", str(os.geteuid())))  # type: ignore[attr-defined]
        rows.append(("gid", str(os.getgid())))  # type: ignore[attr-defined]
        rows.append(("is_root", _fmt_bool(os.geteuid() == 0)))  # type: ignore[attr-defined]
    except Exception:
        pass
    return rows


def _collect_warnings(sections: Dict[str, List[Tuple[str, str]]]) -> List[Tuple[str, str]]:
    rows: List[Tuple[str, str]] = []
    # Disk low space
    for k, v in sections.get("System", []):
        if k == "disk.alert":
            rows.append(("فضای دیسک", "⚠️ فضای خالی کمتر از ۱۰٪ است. ممکن است برنامه کند یا متوقف شود."))
    return rows


def _tail_logs(cfg: Dict[str, Any], lines: int = 0, max_bytes: int = 64_000) -> str:
    if lines <= 0:
        return ""
    log_file = _safe_get(cfg.setdefault("app", {}), "log_file", None)
    if not log_file or not os.path.isfile(log_file):
        return ""
    try:
        with open(log_file, "rb") as f:
            f.seek(0, os.SEEK_END)
            end = f.tell()
            read = min(max_bytes, end)
            f.seek(end - read)
            data = f.read(read)
        text = data.decode("utf-8", errors="ignore").splitlines()[-lines:]
        redacted = []
        for line in text:
            for key in ("TOKEN", "SECRET", "API_HASH", "API_ID", "SESSION"):
                if key in line:
                    line = line.split(key)[0] + key + "=***"
            redacted.append(line)
        return "".join(redacted)
    except Exception:
        return ""


def _section(title: str, rows: Iterable[Tuple[str, str]]) -> str:
    rows = list(rows)
    if not rows:
        return ""
    return f"{title}{_kv_list(rows)}"


def _as_json(sections: Dict[str, List[Tuple[str, str]]]) -> str:
    out: Dict[str, Dict[str, Any]] = {}
    for name, rows in sections.items():
        obj: Dict[str, Any] = {}
        for k, v in rows:
            if k in obj:
                if not isinstance(obj[k], list):
                    obj[k] = [obj[k]]
                obj[k].append(v)
            else:
                obj[k] = v
        out[name] = obj
    return json.dumps(out, ensure_ascii=False, indent=2)

# =============================
# 🧾 STATUS — mega report
# =============================
async def status(
    client: Optional[Client] = None,
    chat_id: Optional[int] = None,
    *,
    verbose: bool = True,
    include_logs: int = 0,
    mode: str = "plain",
    deep: bool = False,
    top_n: int = 10,
    warn: bool = True,
    include_config: bool = False,
    audience: str = "tech",
) -> str:
    cfg: Dict[str, Any] = AllConfig

    env_rows = _collect_environment()
    rt_rows = _collect_runtime()
    sys_rows = _collect_system()

    api_ms = await _probe_api_latency(client, trials=3)
    chat_ms = await _probe_chat_action_latency(client, chat_id)
    lat_rows: List[Tuple[str, str]] = []
    if api_ms == api_ms:
        lat_rows.append(("latency.api", f"{api_ms:.0f} ms"))
    if chat_ms is not None:
        lat_rows.append(("latency.chat", f"{chat_ms:.0f} ms"))

    access_rows = _collect_access(cfg)
    features_rows = _collect_features_from_config(cfg)
    pyro_rows = _collect_pyrogram(client)
    stor_rows = _collect_storage_stats(cfg, top_n=top_n)
    net_rows = _collect_network_proxy() if verbose else []
    sec_rows = _collect_security()
    ev_rows = _collect_events(cfg)
    health_rows = _collect_health(cfg)

    # Deep extras
    deep_rows: List[Tuple[str, str]] = []
    if deep and psutil is not None:
        try:
            p = psutil.Process(os.getpid())
            io = p.io_counters() if hasattr(p, 'io_counters') else None
            if io:
                deep_rows.extend([
                    ("io.read", _fmt_bytes(getattr(io, 'read_bytes', 0))),
                    ("io.write", _fmt_bytes(getattr(io, 'write_bytes', 0))),
                ])
            cs = p.num_ctx_switches() if hasattr(p, 'num_ctx_switches') else None
            if cs:
                deep_rows.extend([
                    ("ctx.voluntary", str(getattr(cs, 'voluntary', '?'))),
                    ("ctx.involuntary", str(getattr(cs, 'involuntary', '?'))),
                ])
            try:
                of = p.open_files()[:top_n]
                for f in of:
                    deep_rows.append(("open.file", f.path))
            except Exception:
                pass
            try:
                conns = p.connections(kind='inet')[:top_n]
                for c in conns:
                    deep_rows.append(("sock", f"{c.laddr}->{getattr(c, 'raddr', '')} {c.status}"))
            except Exception:
                pass
        except Exception:
            pass

    # Config snapshot (sanitized)
    cfg_rows: List[Tuple[str, str]] = []
    if include_config:
        try:
            def _redact(key: str, val: Any) -> Any:
                key_u = key.upper()
                if any(x in key_u for x in ("TOKEN", "SECRET", "PASS", "KEY", "SESSION", "COOKIE")):
                    return "***"
                return val
            for k, v in sorted(cfg.items()):
                if isinstance(v, (dict, list, tuple)):
                    v_short = json.dumps(v)[:200].replace('',' ')
                else:
                    v_short = str(v)
                cfg_rows.append((k, str(_redact(k, v_short))))
        except Exception:
            pass

    sections = {
        "Environment": env_rows + lat_rows,
        "Runtime": rt_rows,
        "System": sys_rows,
        "Security": sec_rows,
        "Access": access_rows,
        "Features": features_rows,
        "Pyrogram": pyro_rows,
        "Storage": stor_rows,
        "Network": net_rows,
        "Events": ev_rows,
        "Health": health_rows,
        "Deep": deep_rows,
        "Config": cfg_rows,
    }

    warn_rows = _collect_warnings(sections) if warn else []

    if audience == "human":
        return _render_human(AllConfig, sections, _collect_warnings(sections) if warn else [], include_logs)

    if mode == "json":
        # include warnings in JSON too
        if warn_rows:
            sections["Warnings"] = warn_rows
        return _as_json(sections)

    # ---------- Render (plain / md) ----------
    title = "🧰 CliSelf • Ultra‑Status v5"
    if mode == "md":
        parts = [f"# {title}"]
        for name, pretty in [
            ("🔺 Environment", sections["Environment"]),
            ("🧠 Runtime", sections["Runtime"]),
            ("🖥️ System", sections["System"]),
            ("🔐 Security", sections["Security"]),
            ("📦 Access", sections["Access"]),
            ("🧩 Features", sections["Features"]),
            ("📡 Pyrogram", sections["Pyrogram"]),
            ("💾 Storage", sections["Storage"]),
            ("🌐 Network / Proxy (sanitized)", sections["Network"]),
            ("🗒️ Events", sections["Events"]),
            ("💚 Health", sections["Health"]),
            ("🧩 Deep", sections["Deep"]),
            ("⚙️ Config (sanitized)", sections["Config"]),
            ("⚠️ Warnings", warn_rows),
        ]:
            if pretty:
                parts.append(f"{name}" + _kv_list(pretty))
        if include_logs:
            logs = _tail_logs(cfg, include_logs)
            if logs:
                parts.append(" 🧯 Logs (tail)" + logs)
        return "".join(parts).rstrip()

    # plain
    parts = [title, ""]
    for name, pretty in [
        ("🔺 Environment", sections["Environment"]),
        ("🧠 Runtime", sections["Runtime"]),
        ("🖥️ System", sections["System"]),
        ("🔐 Security", sections["Security"]),
        ("📦 Access", sections["Access"]),
        ("🧩 Features", sections["Features"]),
        ("📡 Pyrogram", sections["Pyrogram"]),
        ("💾 Storage", sections["Storage"]),
        ("🌐 Network / Proxy (sanitized)", sections["Network"]),
        ("🗒️ Events", sections["Events"]),
        ("💚 Health", sections["Health"]),
        ("🧩 Deep", sections["Deep"]),
        ("⚙️ Config (sanitized)", sections["Config"]),
        ("⚠️ Warnings", warn_rows),
    ]:
        if pretty:
            parts.append(_section(name, pretty))
    if include_logs:
        logs = _tail_logs(cfg, include_logs)
        if logs:
            parts.append("🧯 Logs (tail)" + logs + "")
    return "".join(parts).rstrip()


async def help_text() -> str:
    return (
        "📖 راهنمای دستورات:"
        "- ping → تست اتصال + پینگ واقعی"
        "- uptime → نمایش زمان اجرا"
        "- restart → ریستارت نرم (بازنشانی وضعیت)"
        "- shutdown → خاموش کردن"
        "- status([... , mode='plain|md|json', audience='tech|human']) → وضعیت کامل برنامه"
        "- help → نمایش همین راهنما"
    )

# =============================
# 🧍 Human-friendly renderer
# =============================

def _pair(k: str, v: str) -> str:
    return f"• {k}: {v}"


def _val(x: str) -> str:
    return x if x and x != "—" else "نامشخص"


def _render_human(cfg: Dict[str, Any], sections: Dict[str, List[Tuple[str, str]]], warn_rows: List[Tuple[str, str]], include_logs: int) -> str:
    labels = {
        "version": "نسخهٔ برنامه",
        "python": "نسخهٔ پایتون",
        "pyrogram": "کتابخانهٔ پای‌روگرام",
        "platform": "سیستم‌عامل",
        "hostname": "نام دستگاه",
        "pid": "شناسهٔ فرایند",
        "uptime": "مدت اجرای برنامه",
        "timezone": "منطقهٔ زمانی",
        "locale": "زبان/کدگذاری",
        "workdir": "محل اجرای برنامه",
        "git.branch": "شاخهٔ گیت",
        "git.sha": "شناسهٔ آخرین تغییر",
        "git.dirty": "تغییرات ذخیره‌نشده",
        "proc.mem": "حافظهٔ مصرفی برنامه",
        "boot_time": "زمان روشن‌شدن سیستم",
        "latency.api": "تاخیر ارتباط با سرور",
        "latency.chat": "تاخیر ارسال حرکت تایپ",
        "cpu%": "درصد استفاده از پردازنده",
        "mem.used": "حافظهٔ درحال استفاده",
        "mem.free": "حافظهٔ آزاد",
        "disk.total": "حجم کل دیسک",
        "disk.used": "حجم استفاده‌شده",
        "disk.free": "حجم آزاد",
        "admins": "تعداد مدیرها",
        "admins.sample": "نمونهٔ مدیرها",
        "spammer.enabled": "ارسال‌کنندهٔ خودکار فعال است",
        "spammer.typing": "نمایش در حال تایپ",
        "spammer.schedule": "زمان‌بندی ارسال فعال است",
        "spammer.sent": "تعداد پیام‌های ارسال‌شده",
        "spammer.errors": "تعداد خطاهای ارسال",
        "spammer.success%": "درصد موفقیت",
        "spammer.queue": "تعداد پیام‌های در صف",
        "spammer.eta": "زمان تقریبی پایان صف",
        "spammer.targets": "مخاطبان هدف",
        "forward.enabled": "فوروارد خودکار فعال است",
        "forward.mode": "حالت فوروارد",
        "forward.routes": "مسیرهای فوروارد",
        "forward.queue": "صف فوروارد",
        "forward.sent": "تعداد فوروارد موفق",
        "forward.errors": "فوروارد ناموفق",
        "forward.success%": "درصد موفقیت فوروارد",
        "mention.enabled": "پاسخ به منشن‌ها",
        "mention.group": "منشن گروهی",
        "enemy.enabled": "مسدودسازی خودکار",
        "enemy.blocked": "تعداد مسدودشده‌ها",
        "backup.enabled": "پشتیبان‌گیری فعال است",
        "backup.dir": "محل ذخیرهٔ پشتیبان",
        "media.enabled": "مدیریت رسانه فعال است",
        "media.paths": "مسیرهای رسانه",
        "timer.enabled": "زمان‌بندی کلی فعال است",
        "timer.targets": "هدف‌های زمان‌بندی",
        "timer.next": "اجرای بعدی",
        "text.lines": "تعداد متن‌های آماده",
        "text.caption": "کپشن پیش‌فرض",
        "rate.window": "پنجرهٔ محدودیت سرعت",
        "rate.budget": "بودجهٔ باقیمانده",
        "rate.remaining": "تعداد مجاز باقیمانده",
        "rate.reset_in": "زمان تا بازنشانی",
        "dns.hostname": "نام دامنه/میزبان",
        "dns.host_ip": "آی‌پی میزبان",
        "net.default_gw": "درگاه پیش‌فرض شبکه",
    }

    def pick(sec: str, keys: List[str]) -> List[str]:
        kv = {k: v for k, v in sections.get(sec, [])}
        out = []
        for k in keys:
            if k in kv:
                out.append(_pair(labels.get(k, k), _val(kv[k])))
        return out

    blocks: List[str] = []
    blocks.append("# وضعیت کلی برنامه" + "".join(pick("Environment", ["version","uptime","latency.api","latency.chat"])))
    blocks.append("" + "".join(pick("Environment", ["platform","hostname","boot_time","proc.mem"]) + pick("System", ["cpu%","mem.used","mem.free","disk.total","disk.used","disk.free"])))
    blocks.append("" + "".join(pick("Network", ["dns.hostname","dns.host_ip","net.default_gw"])))

    feat_keys = ["spammer.enabled","spammer.queue","spammer.eta","forward.enabled","forward.queue","forward.success%","mention.enabled","enemy.enabled","backup.enabled","timer.enabled"]
    kv_feat = {k: v for k, v in sections.get("Features", [])}
    feat_lines = [_pair(labels.get(k, k), _val(kv_feat[k])) for k in feat_keys if k in kv_feat]
    if feat_lines:
        blocks.append("" + "".join(feat_lines))

    blocks.append("" + "".join(pick("Access", ["admins","admins.sample"])) )

    ev = sections.get("Events", [])
    if ev:
        blocks.append("" + "".join(v for _, v in ev))
    hl = sections.get("Health", [])
    if hl:
        blocks.append("" + "".join(_pair(k, v) for k, v in hl))

    if warn_rows:
        blocks.append("" + "".join(_pair(k, v) for k, v in warn_rows))

    if include_logs:
        logs = _tail_logs(cfg, include_logs)
        if logs:
            blocks.append("" + logs)

    return "".join(blocks).strip()