# Copyright (c) OpenMMLab. All rights reserved.
import functools
import hashlib
import json
import os
import os.path as osp
import re
import subprocess
import tarfile
import typing
from collections import defaultdict
from importlib import metadata as importlib_metadata
from typing import Any, List, Optional, Sequence, Tuple, Union
from urllib.parse import unquote, urlparse

import click
import requests
from packaging import version as packaging_version
from pip._vendor.packaging import version
from requests.exceptions import InvalidURL, RequestException, Timeout
from requests.models import Response

from .default import PKG2PROJECT
from .progress_bars import rich_progress_bar

try:
    import torch
    import torch_npu  # noqa: F401

    IS_NPU_AVAILABLE = hasattr(
        torch, 'npu') and torch.npu.is_available()  # type: ignore
except Exception:
    IS_NPU_AVAILABLE = False


def parse_url(url: str) -> Tuple[str, str]:
    """Parse username and repo from url.

    Args:
        url (str): Url for parsing username and repo name.

    Example:
        >>> parse_url('https://github.com/vbti-development/onedl-mmcv.git')
        'open-mmlab', 'mmcv'
        >>> parse_ulr('git@github.com:vbti-development/onedl-mmcv.git')
        'open-mmlab', 'mmcv'
    """
    if url.startswith('git@'):
        res = url.split(':')[-1].split('/')
    elif 'git' in url:
        res = url.split('/')[-2:]
    else:
        raise ValueError(highlighted_error(f'{url} is invalid.'))

    username = res[0]
    repo = res[1].split('.')[0]
    return username, repo


def is_installed(package: str) -> bool:
    """Check package whether installed.

    Args:
        package (str): Name of package to be checked.
    """
    try:
        importlib_metadata.distribution(package)
        return True
    except importlib_metadata.PackageNotFoundError:
        return False


def ensure_installation(func):
    """A decorator to make sure a package has been installed.

    Before invoking those functions which depend on installed package, the
    decorator makes sure the package has been installed.
    """

    @functools.wraps(func)
    def wrapper(package):
        if not is_installed(package):
            raise RuntimeError(
                highlighted_error(f'{package} is not installed.'))
        return func(package)

    return wrapper


@ensure_installation
def parse_home_page(package: str) -> Optional[str]:
    """Parse home page from package metadata.

    Args:
        package (str): Package to parse home page.
    """
    try:
        dist = importlib_metadata.distribution(package)
        # Get project URLs from metadata
        project_urls = dist.metadata.get_all('Project-URL')
        if project_urls:
            for project_url in project_urls:
                label, url_ = project_url.split(',', 1)
                if label.strip().lower() == 'repository':
                    return url_.strip().lower()
    except importlib_metadata.PackageNotFoundError:
        pass
    return None


def get_github_url(package: str) -> str:
    """Get github url.

    Args:
        package (str): Name of package, like onedl-mmpretrain.

    Example:
        >>> get_github_url('onedl-mmpretrain')
        'https://github.com/vbti-development/onedl-mmclassification.git'
    """
    home_page = None
    if is_installed(package):
        home_page = parse_home_page(package)

    if not home_page:
        try:
            pkg_info = get_package_info_from_pypi(package)
            home_page = pkg_info['info'].get('project_urls',
                                             {}).get('Repository', '').lower()
        except Exception:
            pass

    if home_page:
        if home_page.endswith('.git'):
            github_url = home_page
        elif home_page.endswith('.com'):
            github_url = home_page.replace('.com', '.git')
        else:
            github_url = home_page + '.git'
        return github_url
    else:
        raise ValueError(
            highlighted_error(f'Failed to get github url of {package}.'))


def get_content_from_url(url: str,
                         timeout: int = 15,
                         stream: bool = False,
                         check_certificate: bool = True) -> Response:
    """Get content from url.

    Args:
        url (str): Url for getting content.
        timeout (int): Set the socket timeout. Default: 15.
        check_certificate (bool): Whether to check the ssl certificate.
            Default: True.
    """
    try:
        response = requests.get(
            url, timeout=timeout, stream=stream, verify=check_certificate)
    except InvalidURL as err:
        raise highlighted_error(err)  # type: ignore
    except Timeout as err:
        raise highlighted_error(err)  # type: ignore
    except RequestException as err:
        raise highlighted_error(err)  # type: ignore
    except Exception as err:
        raise highlighted_error(err)  # type: ignore
    return response


@typing.no_type_check
def download_from_file(url: str,
                       dest_path: str,
                       hash_prefix: Optional[str] = None,
                       check_certificate: bool = True) -> None:
    """Download object at the given URL to a local path.

    Args:
        url (str): URL of the object to download.
        dest_path (str): Path where object will be saved.
        hash_prefix (string, optional): If not None, the SHA256 downloaded
            file should start with `hash_prefix`. Default: None.
        check_certificate (bool): Whether to check the ssl certificate.
            Default: True.
    """
    if hash_prefix is not None:
        sha256 = hashlib.sha256()

    response = get_content_from_url(
        url, stream=True, check_certificate=check_certificate)
    size = int(response.headers.get('content-length'))
    with open(dest_path, 'wb') as fw:
        content_iter = response.iter_content(chunk_size=1024)
        for chunk in rich_progress_bar(content_iter, size=size):
            if chunk:
                fw.write(chunk)
                fw.flush()
                if hash_prefix is not None:
                    sha256.update(chunk)

    if hash_prefix is not None:
        digest = sha256.hexdigest()
        if digest[:len(hash_prefix)] != hash_prefix:
            raise RuntimeError(
                highlighted_error(
                    f'invalid hash value, expected "{hash_prefix}", but got '
                    f'"{digest}"'))


def split_package_version(package: str) -> Tuple[str, ...]:
    """Split the package which maybe contains version info.

    Args:
        package (str): Name of package to split.

    Example:
        >>> split_package_version('onedl-mmpretrain')
        'onedl-mmpretrain', ''
        >>> split_package_version('onedl-mmpretrain=0.11.0')
        'onedl-mmpretrain', '0.11.0'
        >>> split_package_version('onedl-mmpretrain==0.11.0')
        'onedl-mmpretrain', '0.11.0'
    """
    if '=' in package:
        return tuple(re.split(r'=+', package))
    else:
        return package, ''


def get_package_version(repo_root: str) -> Tuple[str, str]:
    """Get package and version from local repo.

    Args:
        repo_root (str): Directory of repo.
    """
    for file_name in os.listdir(repo_root):
        version_path = osp.join(repo_root, file_name, 'version.py')
        if osp.exists(version_path):
            with open(version_path, encoding='utf-8') as f:
                exec(compile(f.read(), version_path, 'exec'))
            return file_name, locals()['__version__']

    return '', ''


@ensure_installation
def get_installed_version(package: str) -> str:
    """Get the version of package from local environment.

    Args:
        package (str): Name of package.
    """
    return importlib_metadata.version(package)


def get_package_info_from_pypi(package: str, timeout: int = 15) -> dict:
    """Get package information from pypi.

    Args:
        package (str): Package to get information.
        timeout (int): Set the socket timeout. Default: 15.
    """
    pkg_url = f'https://pypi.org/pypi/{package}/json'
    response = get_content_from_url(pkg_url, timeout)
    return response.json()


def get_release_version(package: str, timeout: int = 15) -> List[str]:
    """Get release version from pypi.

    The return list of versions is sorted by ascending order.

    Args:
        package (str): Package to get version.
        timeout (int): Set the socket timeout. Default: 15.
    """
    pkg_info = get_package_info_from_pypi(package, timeout)
    releases = pkg_info['releases']
    return sorted(releases, key=packaging_version.parse)


def get_latest_version(package: str, timeout: int = 15) -> str:
    """Get latest version of package.

    Args:
        package (str): Package to get latest version.
        timeout (int): Set the socket timeout. Default: 15.

    Example:
        >>> get_latest_version('onedl-mmcv')
            '0.11.0'
    """
    release_version = get_release_version(package, timeout)
    return release_version[-1]


def is_version_equal(version1: str, version2: str) -> bool:
    return version.parse(version1) == version.parse(version2)


@ensure_installation
def package2module(package: str):
    """Infer module name from package.

    Args:
        package (str): Package to infer module name.
    """
    try:
        dist = importlib_metadata.distribution(package)
        # Try to get top-level packages
        top_level = dist.read_text('top_level.txt')
        if top_level:
            return top_level.split('\n')[0].strip()
    except (importlib_metadata.PackageNotFoundError, FileNotFoundError):
        pass

    raise ValueError(
        highlighted_error(f'can not infer the module name of {package}'))


@ensure_installation
def get_installed_path(package: str) -> str:
    """Get installed path of package.

    Args:
        package (str): Name of package.

    Example:
        >>> get_installed_path('onedl-mmpretrain')
        >>> '.../lib/python3.10/site-packages/onedl-mmpretrain'
    """
    dist = importlib_metadata.distribution(package)

    # Try to read direct_url.json for editable installs
    try:
        direct_url_text = dist.read_text('direct_url.json')
        if direct_url_text:
            direct_url_dict: dict = json.loads(direct_url_text)
            pkg_is_editable = direct_url_dict.get('dir_info',
                                                  {}).get('editable', False)

            if pkg_is_editable:
                possible_path = direct_url_dict.get('url', '')
                return osp.normpath(unquote(urlparse(possible_path).path))
    except FileNotFoundError:
        pass

    # Get the location from files
    if dist.files:
        # Get the first file's parent directory
        first_file = str(dist.files[0])
        possible_path = osp.join(
            dist.locate_file('.'),
            first_file.split('/')[0])
    else:
        # Fallback: construct path
        site_packages = str(dist.locate_file('.'))
        possible_path = osp.join(site_packages, package)
        if not osp.exists(possible_path):
            possible_path = osp.join(site_packages, package2module(package))

    return possible_path


def is_npu_available() -> bool:
    """Returns True if Ascend PyTorch and npu devices exist."""
    return IS_NPU_AVAILABLE


def get_npu_version() -> str:
    """Returns the version of NPU when npu devices exist."""
    if not is_npu_available():
        return ''
    ascend_home_path = os.environ.get('ASCEND_HOME_PATH', None)
    if not ascend_home_path or not os.path.exists(ascend_home_path):
        raise RuntimeError(
            highlighted_error(
                f'ASCEND_HOME_PATH:{ascend_home_path} does not exists when '
                'installing OpenMMLab projects on Ascend NPU.'
                "Please run 'source set_env.sh' in the CANN installation path."
            ))
    npu_version = torch.version.cann
    return npu_version


def get_torch_device_version() -> Tuple[str, str, str]:
    """Get PyTorch version and CUDA/NPU version if it is available.

    Example:
        >>> get_torch_device_version()
        '1.8.0', 'cpu', ''
        >>> get_torch_device_version()
        '1.8.0', 'cuda', '102'
        >>> get_torch_device_version()
        '1.11.0', 'ascend', '602'
    """
    try:
        import torch
    except ImportError as err:
        raise err

    torch_v = torch.__version__
    if '+' in torch_v:  # 1.8.1+cu111 -> 1.8.1
        torch_v = torch_v.split('+')[0]

    if torch.version.cuda is not None:
        device = 'cuda'
        # torch.version.cuda like 10.2 -> 102
        device_v = ''.join(torch.version.cuda.split('.'))
    elif is_npu_available():
        device = 'ascend'
        device_v = get_npu_version()
        device_v = ''.join(device_v.split('.'))
    else:
        device = 'cpu'
        device_v = ''
    return torch_v, device, device_v


def cast2lowercase(input: Union[list, tuple, str]) -> Any:
    """Cast input into lowercase.

    Example:
        >>> cast2lowercase('Hello World')
        'hello world'
        >>> cast2lowercase(['Hello', 'World'])
        ['hello', 'world']
    """
    inputs = []
    outputs = []
    if isinstance(input, str):
        inputs = [input]
    else:
        inputs = input  # type: ignore

    for _input in inputs:
        outputs.append(_input.lower())

    if isinstance(input, str):
        return outputs[0]
    elif isinstance(input, tuple):
        return tuple(outputs)
    else:
        return outputs


def recursively_find(root: str, base_name: str, followlinks=False) -> list:
    """Recursive list a directory, return all files with a given base_name.

    Args:
        root (str): The root directory to list.
        base_name (str): The base_name.
        followlinks (bool): Follow symbolic links. Defaults to False.

    Return:
        Files with given base_name.
    """
    files = []
    for _root, _, _files in os.walk(root, followlinks=followlinks):
        if base_name in _files:
            files.append(osp.join(_root, base_name))

    return files


def highlighted_error(msg: Union[str, Exception]) -> str:
    return click.style(msg, fg='red', bold=True)  # type: ignore


def color_echo(msg: str, color: str) -> None:
    click.echo(click.style(msg, fg=color))  # type: ignore


def echo_error(msg: Union[str, Exception]) -> None:
    color_echo(msg=msg, color='red')  # type: ignore


def echo_warning(msg: Union[str, Exception]) -> None:
    color_echo(msg=msg, color='yellow')  # type: ignore


def echo_success(msg: str) -> None:
    color_echo(msg=msg, color='green')


def exit_with_error(msg: Union[str, Exception]) -> None:
    echo_error(msg)
    exit(1)


def call_command(cmd: list) -> None:
    try:
        subprocess.check_call(cmd)
        return 0
    except subprocess.CalledProcessError as e:
        highlighted_error(e)
        return e.returncode
    except Exception as e:
        raise highlighted_error(e)  # type: ignore


def string2args(text: str) -> dict:
    """Parse string to arguments.

    Args:
        text (str): The string to be parsed, which should be of the format:
            "--arg1 value1 value2 --arg2 value1 ... --argn value1".
            Using '=' is also OK, like "--argn=value1". It also support flag
            args like "--arg1".

    Return:
        A dictionary that contains parsed args. Note that the type of values
        will all be strings.

    Example:
        >>> text = '--arg1 value1 value2 --arg2 value3 --arg3 value4'
        >>> string2args(text)
        args = {
            'arg1': [value1, value2],
            'arg2': [value3],
            'arg3': [value4]
        }
    """

    ret: dict = defaultdict(list)
    name = None
    items = text.split()
    for item in items:
        if name is None:
            assert item.startswith('--')
        if item.startswith('--'):
            if name is not None and ret[name] == []:
                ret[name] = bool
            if '=' in item:
                name, value = item[2:].split('=')
                ret[name] = [value]
                name = None
            else:
                name = item[2:]
        else:
            ret[name].append(item)
    if name is not None and ret[name] == []:
        ret[name] = bool
    return ret


def args2string(args: dict) -> str:
    """Convert args dictionary to a string.

    Args:
        args (dict): A dictionary that contains parsed args.

    Return:
        A converted string.

    Example:
        >>> args = {
            'arg1': [value1, value2],
            'arg2': [value3],
            'arg3': [value4]
        }
        >>> args2string(args)
        '--arg1 value1 value2 --arg2 value3 --arg3 value4'
    """
    text = []
    for k in args:
        text.append(f'--{k}')
        if args[k] is not bool:
            text.extend([str(x) for x in args[k]])
    return ' '.join(text)


def get_config(cfg, name):
    """Given the argument name, read the value from the config file.

    The name can be multi-level, like 'optimizer.lr'
    """

    name = name.split('.')
    suffix = ''
    for item in name:
        if isinstance(cfg, Sequence) and not isinstance(cfg, str):
            cfg = cfg[int(item)]
        else:
            assert item in cfg, f'attribute {item} not cfg{suffix}'
            cfg = cfg[item]
        suffix += f'.{item}'
    return cfg


def set_config(cfg, name, value):
    """Given the argument name and value, set the value of the config file.

    The name can be multi-level, like 'optimizer.lr'
    """

    name = name.split('.')
    suffix = ''
    for item in name[:-1]:
        if isinstance(cfg, Sequence) and not isinstance(cfg, str):
            cfg = cfg[int(item)]
        else:
            assert item in cfg, f'attribute {item} not cfg{suffix}'
            cfg = cfg[item]
        suffix += f'.{item}'

    assert name[-1] in cfg, f'attribute {item} not cfg{suffix}'
    cfg[name[-1]] = value


def extract_tar(tar_path: str, dst: str) -> None:
    """Extract file from tar.

    Args:
        tar_path (str): Path for extracting.
        dst (str): Destination to save file.
    """
    assert tarfile.is_tarfile(tar_path), f'{tar_path} is an invalid path.'

    with tarfile.open(tar_path, 'r') as tar_file:
        tar_file.extractall(dst)


def module_full_name(abbr: str) -> str:
    """Get the full name of the module given abbreviation.

    Args:
        abbr (str): The abbreviation, should be the sub-string of one
            (and only one) supported module.

    Return:
        str: The full name of the corresponding module. If abbr is the
            sub-string of zero / multiple module names, return empty string.
    """
    names = [x for x in PKG2PROJECT if abbr in x]
    if len(names) == 1:
        return names[0]
    elif abbr in names or is_installed(abbr):
        return abbr
    return ''
