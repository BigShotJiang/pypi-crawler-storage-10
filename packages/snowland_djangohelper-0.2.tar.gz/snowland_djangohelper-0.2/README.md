# snowland-djangohelper

[![version](https://img.shields.io/pypi/v/snowland-djangohelper.svg)](https://pypi.python.org/pypi/snowland-djangohelper)
[![gitee](https://gitee.com/snowlandltd/snowland-djangohelper/badge/star.svg)](https://gitee.com/snowlandltd/snowland-djangohelper/stargazers)
[![download](https://img.shields.io/pypi/dm/snowland-djangohelper.svg)](https://pypi.org/project/snowland-djangohelper)
[![wheel](https://img.shields.io/pypi/wheel/snowland-djangohelper.svg)](https://pypi.python.org/pypi/snowland-djangohelper)
![status](https://img.shields.io/pypi/status/snowland-djangohelper.svg)

1. install

from pypi:
    pip install snowland-djangohelper
or
from source code:
    download code from https://gitee.com/snowlandltd/snowland-djangohelper, you can choose a release version
    pip install -r requirements.txt
    python setup.py install

2. dirs
    - auth(package)
        support authentication methods for commercial passwords
    - contrib
        some general applications.
    - db
        Expanded the database functionality of Django.
    - middleware(package)
        the middlewares
    - pagination(package)
        expanded the paging function of DRF
    - requests(package)
        api store
    - viewhelper(package)
        pageinator
    - viewset(package)
        expanded the viewset function of DRF
    - views(package)
        same templates.
    - common(file)
        global define in djangohelper
    - project2lines(file)
        write code in a file
    - number_tool
        for generating random string
    - util(file)
        tool for django

    WAITING...

### quick use
    WAITING FOR UPDATE



### 参考资料

[1] https://github.com/ASTARCHEN/astartool

[2] https://github.com/astar-club/astar-devopstool-python

    