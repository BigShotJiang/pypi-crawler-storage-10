"""
Module for the effects and nodes that are made by
putting different nodes together.
"""
from yta_editor_nodes_gpu.processor import _NodeComplexGPU
from typing import Union


# TODO: This is special as it is not a node itself
class DisplayOverAtNodeComplexGPU(_NodeComplexGPU):
    """
    The overlay input is positioned with the given position,
    rotation and size, and then put as an overlay of the
    also given base input.

    Information:
    - The scene size is `(1920, 1080)`, so provide the
    `position` parameter according to it, where it is
    representing the center of the texture.
    - The `rotation` is in degrees, where `rotation=90`
    means rotating 90 degrees to the right.
    - The `size` parameter must be provided according to
    the previously mentioned scene size `(1920, 1080)`.

    TODO: This has no inheritance, is special and we need
    to be able to identify it as a valid one.
    """

    def process(
        self,
        opengl_context: Union['moderngl.Context', None],
        output_size: Union[tuple[int, int], None],
        base_input: Union['moderngl.Texture', 'np.ndarray', None],
        overlay_input: Union['moderngl.Texture', 'np.ndarray'],
        position: tuple[int, int] = (1920 / 2, 1080 / 2),
        size: tuple[int, int] = (1920 / 2, 1080 / 2),
        rotation: int = 0
    ):
        """
        By default, the texture overlayed will be displayed in
        the center of the scene, with half of the scene size
        and no rotation.
        """
        from yta_editor_nodes_gpu.processor import DisplacementWithRotationNodeCompositorGPU
        from yta_editor_nodes_gpu.processor.blender import AlphaBlenderGPU

        displacement_node_processor = DisplacementWithRotationNodeCompositorGPU(
            opengl_context = opengl_context,
            output_size = output_size
        )
        output = displacement_node_processor.process(
            #base_input = background_as_numpy,
            base_input = None,
            #overlay_input = background_as_numpy,
            overlay_input = overlay_input,
            output_size = None,
            position = position,
            size = size,
            rotation = rotation
            #rotation = 0.785398 # 0.785398 = 45deg
        )

        if base_input is not None:
            #  TODO: Add just as an overlay
            blender = AlphaBlenderGPU(
                opengl_context = opengl_context,
                output_size = output_size,
            )
            output = blender.process(
                # We don't need to care about the size because OpenGL
                # handles it
                base_input = base_input,
                overlay_input = output,
                mix_weight = 1.0,
                blend_strength = 1.0
            )

        return output