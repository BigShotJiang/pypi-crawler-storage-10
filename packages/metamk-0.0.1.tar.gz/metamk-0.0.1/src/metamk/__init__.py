"""metamk - A minimal framework for defining phase structure around a main action.

Separates the focused operation from setup and verification steps.
"""

from aaa import Mark, Phase, PhaseError

__all__ = ["Mark", "Phase", "PhaseError"]
