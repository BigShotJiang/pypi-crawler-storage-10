"""
Tests for Recorder component.

This file is originally from homeassistant/core and modified by pytest-homeassistant-custom-component.
"""

import pytest

pytest.register_assert_rewrite("tests.components.recorder.common")
