"""
A collection of custom integrations used when running tests.

This file is originally from homeassistant/core and modified by pytest-homeassistant-custom-component.
"""
