"""Account models for the MontyCloud SDK."""

from typing import List

from pydantic import BaseModel, ConfigDict, Field


class GenerateOnboardingTemplateInput(BaseModel):
    """Pydantic model for input of Generate Onboarding Template API.

    Attributes:
        account_type: Type of AWS account to onboard: STANDALONE or MANAGEMENT
        regions: List of AWS regions to onboard
    """

    account_type: str = Field(
        ...,
        alias="AccountType",
        description="Type of AWS account to onboard: STANDALONE or MANAGEMENT",
    )
    regions: List[str] = Field(
        default_factory=list,
        alias="Regions",
        description="List of AWS regions to onboard - Required for Assessment Feature type (Audit Permissions), not supported by other feature types (AutomatedCloudOps, ContinuousVisibility)",
    )


class AccountItem(BaseModel):
    """Details of an account.

    Attributes:
        number: AWS account number
        name: Account name
        status: Current status of the account
        type: Type of the account
        permission_model: Permission model used for the account
        onboarded_date: Date when the account was onboarded
    """

    number: str = Field(alias="Number")
    name: str = Field(alias="Name")
    status: str = Field(alias="Status")
    type: str = Field(alias="Type")
    permission_model: str = Field(alias="PermissionModel")
    onboarded_date: str = Field(alias="OnboardedDate")

    # Allow extra fields
    model_config = ConfigDict(extra="allow")


class GenerateOnboardingTemplateOutput(BaseModel):
    """Output of generate_onboarding_template operation.

    Attributes:
        account_id: The account ID for the onboarding template
        onboarding_template_url: URL to the generated onboarding template
    """

    account_id: str = Field(
        ...,
        alias="AccountId",
        description="The account ID for the onboarding template",
    )
    onboarding_template_url: str = Field(
        ...,
        alias="OnboardingTemplateURL",
        description="URL to the generated onboarding template",
    )


class ListAccountsOutput(BaseModel):
    """Output model for ListAccounts API.

    Attributes:
        accounts: List of account details
        has_more: Whether there are more pages of results
        page_number: Current page number
    """

    accounts: List[AccountItem] = Field(alias="Accounts", default=[])
    has_more: bool = Field(alias="HasMore", default=False)
    page_number: int = Field(alias="PageNumber")

    # Allow extra fields
    model_config = ConfigDict(extra="allow")
