"""Data models for the MontyCloud DAY2 SDK."""

from day2.models.account import (
    AccountItem,
)
from day2.models.account import (
    GenerateOnboardingTemplateInput as AWSGenerateOnboardingTemplateInput,
)
from day2.models.account import (
    GenerateOnboardingTemplateOutput as AWSGenerateOnboardingTemplateOutput,
)
from day2.models.account import (
    ListAccountsOutput,
)
from day2.models.assessment import (
    Assessment,
    CreateAssessmentInput,
    CreateAssessmentOutput,
    GenerateAssessmentReportInput,
    GenerateAssessmentReportOutput,
    GetAssessmentOutput,
    ListAssessmentsOutput,
    RunAssessmentInput,
    RunAssessmentOutput,
)
from day2.models.azure_account import (
    GenerateOnboardingCommandOutput as AzureGenerateOnboardingCommandOutput,
)
from day2.models.azure_assessment import Assessment as AzureAssessment
from day2.models.azure_assessment import (
    CreateAssessmentInput as AzureCreateAssessmentInput,
)
from day2.models.azure_assessment import (
    CreateAssessmentOutput as AzureCreateAssessmentOutput,
)
from day2.models.azure_assessment import Finding as AzureFinding
from day2.models.azure_assessment import (
    ListAssessmentsOutput as AzureListAssessmentsOutput,
)
from day2.models.azure_assessment import ListFindingsOutput as AzureListFindingsOutput
from day2.models.bot import (
    ComplianceBotFinding,
    ListComplianceBotFindingsOutput,
    ListComplianceBotPolicyGroupsOutput,
    ListComplianceBotResourceTypesOutput,
    Policy,
    ResourceType,
)
from day2.models.cost import GetCostByChargeTypeOutput
from day2.models.report import (
    DeleteReportInput,
    DeleteReportOutput,
    GetReportDetailsOutput,
    GetReportOutput,
    ListReportsOutput,
)
from day2.models.resource import (
    GetInventorySummaryOutput,
    InventorySummaryByAccountNumber,
    InventorySummaryByRegion,
    InventorySummaryByResourceType,
    ListRegionsOutput,
    ListResourceTypesOutput,
)
from day2.models.tenant import (
    CreateTenantInput,
    CreateTenantOutput,
    ListTenantCategoriesOutput,
    ListTenantsOutput,
    OptionalFeaturesModel,
    TenantCategory,
    TenantDetails,
)
from day2.models.user import ListUsersOutput, User

__all__ = [
    "AccountItem",
    "ListAccountsOutput",
    "TenantDetails",
    "TenantCategory",
    "CreateTenantInput",
    "CreateTenantOutput",
    "OptionalFeaturesModel",
    "ListTenantsOutput",
    "AWSGenerateOnboardingTemplateInput",
    "AWSGenerateOnboardingTemplateOutput",
    "AzureGenerateOnboardingCommandOutput",
    "ListUsersOutput",
    "ListTenantCategoriesOutput",
    "User",
    "Assessment",
    "AzureAssessment",
    "AzureFinding",
    "ListAssessmentsOutput",
    "AzureListAssessmentsOutput",
    "AzureListFindingsOutput",
    "CreateAssessmentInput",
    "CreateAssessmentOutput",
    "AzureCreateAssessmentInput",
    "AzureCreateAssessmentOutput",
    "GetAssessmentOutput",
    "GetCostByChargeTypeOutput",
    "RunAssessmentInput",
    "RunAssessmentOutput",
    "GenerateAssessmentReportInput",
    "GenerateAssessmentReportOutput",
    "GetReportDetailsOutput",
    "GetReportOutput",
    "ListReportsOutput",
    "Policy",
    "ResourceType",
    "ComplianceBotFinding",
    "ListComplianceBotFindingsOutput",
    "ListComplianceBotResourceTypesOutput",
    "ListComplianceBotPolicyGroupsOutput",
    "GetInventorySummaryOutput",
    "ListRegionsOutput",
    "ListResourceTypesOutput",
    "InventorySummaryByAccountNumber",
    "InventorySummaryByRegion",
    "InventorySummaryByResourceType",
    "DeleteReportInput",
    "DeleteReportOutput",
]
