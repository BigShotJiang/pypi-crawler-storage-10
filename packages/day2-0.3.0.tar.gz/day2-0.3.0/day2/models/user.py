"""User models for the MontyCloud SDK."""

from typing import List

from pydantic import BaseModel, ConfigDict, Field


class User(BaseModel):
    """Details of a user in a tenant.

    Attributes:
        name: Name of the user
        email: Email address of the user
        user_id: Unique identifier of the user
    """

    name: str = Field(alias="Name")
    email: str = Field(alias="Email")
    user_id: str = Field(alias="UserId")

    # Allow extra fields
    model_config = ConfigDict(extra="allow")


class ListUsersOutput(BaseModel):
    """Output model for ListUsers API.

    Attributes:
        users: List of users in the tenant
    """

    users: List[User] = Field(alias="Users", default=[])

    # Allow extra fields
    model_config = ConfigDict(extra="allow")
