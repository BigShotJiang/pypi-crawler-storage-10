"""User commands for the MontyCloud DAY2 CLI."""

from typing import Optional

import click
from rich.console import Console

from day2.exceptions import Day2Error, ProfileNotFoundError
from day2_cli.utils.context import get_enhanced_context, with_common_options
from day2_cli.utils.exit_codes import handle_error_with_exit
from day2_cli.utils.output_formatter import format_list_output

console = Console()


@click.group()
def user() -> None:
    """User commands."""


@user.command("list")
@with_common_options(include_tenant_id=True)
def list_users(
    output: Optional[str] = None,
    profile: Optional[str] = None,
    tenant_id: Optional[str] = None,
) -> None:
    """List users associated with a specific tenant.

    This command lists all the users in the tenant.
    """
    try:
        # Get enhanced context
        context = get_enhanced_context(
            output=output, profile=profile, tenant_id=tenant_id, require_tenant=True
        )
        session = context["session"]
        resolved_tenant_id = context["tenant_id"]
        output_format = context["output_format"]

        result = session.user.list_users(resolved_tenant_id)

        if not result.users:
            console.print("[yellow]No users found.[/yellow]")
            return

        # Convert user objects to dictionaries for output
        user_list = []
        for user_item in result.users:
            user_dict = {
                "name": user_item.name,
                "email": user_item.email,
                "user_id": user_item.user_id,
            }
            user_list.append(user_dict)

        # Define columns for table output
        columns = {
            "name": "Name",
            "email": "Email",
            "user_id": "User ID",
        }

        # Format and output the user list
        format_list_output(
            user_list,
            f"Users for Tenant: {resolved_tenant_id}",
            columns,
            output_format,
        )

    except (Day2Error, ProfileNotFoundError) as e:
        handle_error_with_exit(e)
