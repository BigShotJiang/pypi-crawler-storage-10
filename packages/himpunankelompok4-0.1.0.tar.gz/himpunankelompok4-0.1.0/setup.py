import pathlib
from setuptools import setup, find_packages

HERE = pathlib.Path(__file__).parent

# Read long description from README if present
long_description = ""
readme_file = HERE / "README.md"
if readme_file.exists():
    long_description = readme_file.read_text(encoding="utf-8")

# Import version from package (single source of truth)
pkg_version = "0.0.0"
version_ns = {}
init_file = HERE / "himpunan" / "__init__.py"
if init_file.exists():
    for line in init_file.read_text(encoding="utf-8").splitlines():
        if line.startswith("__version__"):
            # execute the line to populate version_ns
            exec(line, version_ns)
            pkg_version = version_ns.get("__version__", pkg_version)
            break

setup(
    name='himpunankelompok4',
    version=pkg_version,
    packages=find_packages(),
    description='Implementasi konsep himpunan menggunakan Python list dan magic methods.',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='Discrete Mathematics Kelompok 4',
    license='MIT',
    python_requires='>=3.7',
    include_package_data=True,
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)
