# himpunankelompok4

Implementasi sederhana kelas `Himpunan` untuk menggambarkan operasi himpunan dasar (gabungan, irisan, selisih, komplemen, power set, cartesian product) menggunakan Python.

Fitur utama:
- Representasi himpunan dengan magic methods
- Operasi himpunan: union, intersection, difference, symmetric difference
- Power set dan Cartesian product

Instalasi lokal dari distribution:

```powershell
python -m pip install --upgrade build
python -m build
python -m pip install dist\himpunankelompok4-0.1.0-py3-none-any.whl
```

Penggunaan singkat:

```python
from himpunan import Himpunan

a = Himpunan(1,2,3)
b = Himpunan(2,3,4)
print(a + b)  # gabungan
```
