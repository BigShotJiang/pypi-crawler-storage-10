import math

import numpy as np

from ..modelFit_Gaussian import (
    _build_prior,
    fit_gaussian,
)


def test_beta_prior_evaluation_matches_closed_form():
    """Beta prior evaluation should match analytical log density."""
    theta0 = np.array([0.5])
    prior = _build_prior(
        mode="map",
        theta0=theta0,
        prior_distribution="beta",
        prior_mean=None,
        prior_variance=None,
        prior_prob=None,
        prior_rate=None,
        prior_alpha=np.array([2.0]),
        prior_beta=np.array([3.0]),
    )
    theta = np.array([0.4])
    log_prior = prior.evaluate(theta)
    expected = (
        (2.0 - 1.0) * np.log(0.4)
        + (3.0 - 1.0) * np.log(0.6)
        - (math.lgamma(2.0) + math.lgamma(3.0) - math.lgamma(5.0))
    )
    assert np.isclose(log_prior, expected, atol=1e-6)


def test_binomial_fit_produces_probability_metrics():
    """Fitting a binomial likelihood should expose log-loss in metrics."""
    x = np.zeros((4, 1))
    y = np.array([1.0, 0.0, 1.0, 1.0])

    def model_fn(theta: np.ndarray, x_data: np.ndarray) -> np.ndarray:
        return np.full(x_data.shape[0], theta[0])

    result = fit_gaussian(
        model_fn,
        x,
        y,
        initial_params=np.array([0.0]),
        output_distribution="binomial",
        mode="mle",
    )
    assert result.success
    assert "log_loss" in result.metrics.extra
    assert result.metrics.extra["log_loss"] >= 0.0


def test_poisson_fit_reports_deviance_metric():
    """Poisson likelihood should compute deviance in metrics."""
    x = np.zeros((5, 1))
    y = np.array([0.0, 1.0, 0.0, 2.0, 1.0])

    def model_fn(theta: np.ndarray, x_data: np.ndarray) -> np.ndarray:
        return np.full(x_data.shape[0], theta[0])

    result = fit_gaussian(
        model_fn,
        x,
        y,
        initial_params=np.array([0.0]),
        output_distribution="poisson",
        mode="mle",
    )
    assert result.success
    assert "deviance" in result.metrics.extra
    assert result.metrics.extra["deviance"] >= 0.0
